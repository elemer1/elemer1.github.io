# #301 – AMA #59: Inflammation: its impact on aging and disease risk, and how to identify, prevent, and reduce it

**Source:** [https://peterattiamd.com/ama59/](https://peterattiamd.com/ama59/)

---

In this “Ask Me Anything” (AMA) episode, Peter delves into the often misunderstood concept of inflammation. He first defines inflammation and differentiates between acute inflammation and chronic inflammation, the latter of which is linked to aging and a plethora of age-related diseases. Peter breaks down the intricate relationship between chronic inflammation, obesity, and metabolic health, and highlights the signs that might suggest someone may be suffering from chronic inflammation. From there, the conversation centers on actionable advice and practical steps one can take to manage and minimize chronic inflammation. He explores how diet plays a crucial role, including the potential benefits of elimination diets, and he examines the impact of lifestyle factors such as exercise, sleep, and stress management. Additionally, he discusses the relevance of food inflammatory tests and concludes by examining the potential benefits and drawbacks of drugs and supplements in managing inflammation.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #59 show notes page](https://peterattiamd.com/ama59). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Defining inflammation (and the cultural impact of Napoleon Dynamite) [1:45];
- Acute vs chronic inflammation [8:00];
- The connection between chronic inflammation, aging, and age-related diseases [11:00];
- The impact of inflammation on metabolic health [18:30];
- Understanding and diagnosing chronic inflammation: blood tests and other approaches, and challenges with measurement [20:00];
- Factors that contribute to low level chronic inflammation [28:00];
- Minimizing inflammation through diet [29:45];
- The important role of fiber for gut health and inflammation [33:45];
- A closer look at the impact of trans fats and saturated fats on overall health [34:45];
- Why Peter prefers dietary fiber from food sources over supplements [38:30];
- Debunking “superfoods”: emphasizing proven methods over marketing claims for reducing inflammation [39:00];
- Is there any value in over-the-counter food inflammatory tests? [42:30];
- Food elimination diets: how they work, symptoms and markers to watch, challenges and limitations [45:15];
- Identifying dietary triggers for gut-related symptoms through low-FODMAP diets like the “carnivore diet” [51:15];
- Dairy: the complex role of dairy on inflammation and individual responses [55:00];
- Wheat: the complexities and conflicting evidence around wheat’s inflammatory effects [57:45];
- How exercise influences inflammation [1:02:00];
- How sleep quality and duration impacts inflammation [1:07:00];
- The potential impact of chronic psychological stressors on inflammation [1:13:00];
- The impact of oral health on inflammation and overall well-being [1:15:00];
- The role of medications in managing chronic inflammation [1:18:15];
- Supplements: evaluating the efficacy of various anti-inflammatory supplements [1:22:15];
- Parting thoughts and takeaways [1:27:00]; and
- More.

§

The Peter Attia Drive

Inflammation: its impact on aging and disease risk, and how to identify, prevent, and reduce it

§

## Show Notes

§

## Defining inflammation (and the cultural impact of Napoleon Dynamite) [1:45]

- Peter is in a good mood as he is “reflecting on 20 years almost since Napoleon Dynamite came out and just reflecting on what an important contribution that was to mankind”
- Peter says (in a tongue-in-cheek manner) that “Tina the llama is on a low FODMAP diet” and that “those chickens were large, probably due to some of the inflammatory changes in the talons.”

![](https://peterattiamd.com/wp-content/uploads/2024/05/f1-ama59.png)

**Figure 1.** Tina the llama getting fed by Napoleon Dynamite. Source: [napoleondynamite.fandom.com](https://napoleondynamite.fandom.com/wiki/Tina)

**Defining inflammation**

- Inflammation is just such a buzzword that gets thrown around so much with no meaning
  - it is important that people have a very clear understanding of what we’re talking about and what is often misconstrued in popular circles
- Inflammation is a biological response of the immune system to defend against some sort of stimulus, usually harmful, but not always, and to eliminate the cause of injury.
- Inflammation is not always bad—oftentimes, inflammation is essential—it is the fundamental issue for tissue repair for the clearance of infectious pathogens, and obviously, the immune response plays a very important role in that
- You have the acute inflammatory response (i.e., things get red, things get swollen, things get sore, etc.)
  - That, of course, results from both the infection and also the response of the body
- But there’s something that is more chronic in its nature, and truthfully that’s really where we’re going to spend our time today
- If acute inflammation goes unresolved then becomes chronic, then we should talk about that, but again, what we’re here to really talk about today is the **maladaptive side of inflammation**

## Acute vs chronic inflammation [8:00]

Acute inflammation

- Anybody who’s had a mosquito bite or who’s cut themself knows what acute inflammation is
- If you think about a mosquito bite, it’s going to be warm, it’s going to be painful, it’s going to be swollen. You might even have loss of function.
- This is a very important aspect of healing the insult or inflammation

Chronic inflammation

- What we’re here to talk about is chronic inflammation which can be something that lasts from months into years
- You don’t tend to have the same physical signs or symptoms, the redness, the swelling, the pain, the obvious things
- Oftentimes, we think of this as low-grade inflammation
- It’s often asymptomatic, although there are some examples of maybe where it’s not, for instance, when it’s diet-induced
- Chronic inflammation is important because of the role that this plays in disease and ultimately in life

*What do we know about why acute inflammation is a “good” thing but then becomes a bad thing in the context of chronic inflammation after the acute trigger is gone?*

- Acute inflammation is essential to heal the body, so we have an innate immune system that is able to react immediately with soluble antibodies to harmful infectious pathogens
  - example, if you have injury, tissue is damaged, so damaged tissue needs to be cleared
  - All of these things have to happen really, really quickly and very efficiently, and anything that inhibits that process, by the way, is often quite deleterious.
- People who have shortcomings in their immune system, especially for that type of acute stuff, are going to have significant problems
  - There are, of course, certain disease states that do that.
- It’s when inflammation becomes more chronic, even after the acute problem has resolved or sometimes when it lingers, that it becomes maladaptive and the balance tips against the organism or the host, which is us
- A prolonged immune activation can lead to a persistent release of inflammatory cytokines or mediators
  - That can also damage healthy tissue.

> “Inflammation really becomes chronic once it’s persisted for several months, but it can persist for much longer than that.” —Peter Attia

## The connection between chronic inflammation, aging, and age-related diseases [11:00]

***What do we know about the connection between chronic inflammation, aging, and age-related diseases?***

- We’ve discussed the [hallmarks of aging](https://peterattiamd.com/mattkaeberlein2/) before on the podcast
- Typically they are discussed as as targets for geroprotective drugs that don’t target specific diseases, but instead target these cellular mechanisms
- When you think about these, again, decreased nutrient sensing, cellular senescence, genomic instability, epigenetic remodeling or epigenetic change, we know that inflammation or low grade inflammation is actually one of those things.

![](https://peterattiamd.com/wp-content/uploads/2024/05/f2-ama59-hallmarks-of-aging.png)

**Figure 2. Hallmarks of aging.** Source: [López-Otín et al. 2013](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3836174/) and featured on [Ep. 175](https://peterattiamd.com/mattkaeberlein2/)

- Out of the gate, we just recognize this as something that happens more with aging
- We also understand that the association between chronic inflammation and the four horsemen, so the atherosclerotic diseases, cancer, neurodegenerative diseases, and metabolic disease, is incredibly high

There was one observational [study](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0116206) that looked at 160,000 participants—

- If they had a high degree of inflammation as measured by just two biomarkers, high C-reactive protein and low serum albumin, it asked the question, *what was their relationship to all-cause mortality or disease-specific mortality*?
- If you look at people with very high C-reactive protein (above 10 milligrams per liter):
  - Their hazard ratio for all-cause mortality is 2.7, meaning they have 171% increase in the risk of all-cause mortality (meaning at any given year they have 171% increase in the risk of death from any cause relative to someone with a low CRP.)
  - When it comes to cancer mortality, that hazard ratio is 3.16
  - cardiovascular mortality, 2.33
  - cerebrovascular mortality 2.17
  - In other words, for every one of these things, there’s more than a doubling in the risk of all-cause mortality
- Does that mean that inflammation is *causing* that? ⇒ No, but again, when you look at epidemiology and it’s so consistently finding these things and the magnitude of these findings is so significant, it becomes very difficult to dismiss them.
  - It is generally regarded that there is a causal relationship between inflammation and disease

*Why is this important to understand?*

- When things are causal, they are targets of therapy
- When things are associative but not causal, well, it’s great to know that, but it doesn’t mean it’s a target for therapy
- If you believe that high inflammation plays a causal role in these diseases, then reducing inflammation should therefore reduce the risk of those things

*Looking at potential causality*:

One other way that one could go about trying to understand the role of causality here would be to try to effectively treat inflammation and see if by proxy you reduced the incidence of any of these conditions

The [CANTOS trial](https://www.nejm.org/doi/full/10.1056/NEJMoa1707914) tested a monoclonal antibody against interleukin-1 beta

- The monoclonal antibody, the name of which is irrelevant, but it’s canakinumab, was used to do what’s called the secondary prevention trial in patients with significant ASCVD.
- It took 10,000 patients who had previously suffered heart attacks, so we’re talking about people who are very, very high risk for a subsequent event and who had a HSCRP (highly sensitive C-reactive protein) above 2 milligrams per liter (normal is below 1)
- They were randomized to either a placebo or a dose escalation of this antibody, and they were treated every three months for a period of about four years

What did the study find?

- They actually found that at a median followup of just under four years, the incidence of MACE, major adverse cardiac events, so remember non-fatal mI, stroke, or death from either of those things, was lower in the treatment group than in the placebo group
- It actually didn’t really seem to be that dose-dependent
- There was a little bit of an improvement by dose, and this was not true in the 50 milligram
  - it was only true in the two higher doses, and there was really no difference between them
- The point is when they reduced CRP in response to this drug, they reduced events.
- With that said… the reduction was not enormous, but it was a reasonable reduction of about 15% with the two higher doses (The lower dose did not reach statistical significance)
- Given the size of the problem, a 15% relative reduction was reasonable, however, the drug was never approved because those patients went on to experience higher incidences of infections and even very serious infections called sepsis
- This is a bit of an interesting study in that it’s a cool proof of principle that says if you target inflammation, at least this one very, very narrow component of inflammation, which is interleukin-1 beta, you could reduce MACE in a very susceptible population
- The drawback was you made them less robust against an infection, and truthfully, that’s a cautionary tale
- What that says is that
  - 1) be very careful of how you target inflammation, and
  - 2) holistic ways to target inflammation are probably the better way to go as opposed to pharmacologic hammers that really get at, in this case, one kind of isolated pathway

## The impact of inflammation on metabolic health [18:30]

When we hear inflammation talked about, we often hear it talked about in the context of obesity, fat mass, metabolic health…

*What do we know about the relationship between metabolic health and inflammation?*

- There’s a very clear relationship between inflammation and excess adiposity that lives outside of the subcutaneous space
- When you look at even small amounts of ectopic and visceral fat, that appears to promote far more inflammation than subcutaneous fat (SubQ fat)
- SubQ fat is the fat none of us like because we see it in the mirror. It’s the fat that exists under the skin and obviously has whatever aesthetic components it has
- But it’s the visceral fat, it’s the organ fat that we don’t see that’s really driving the inflammatory response we want to avoid.
- That’s why there’s such an association, a strong association between obesity and chronic disease
- It’s really less about the SubQ fat, it’s just that the more SubQ fat you have, the more likely you are to have these other stores of fat
- That relationship is not “one-to-one”, so that’s why we have sometimes the obesity paradox where we have people who are obese, but their risk of disease seems to be normal
- Those tend to be people that don’t have these topic and visceral stores
- Conversely, you have lean people who at least on the outside look lean, but on the inside they’re quite fat and, lo and behold, their risk of disease is much higher as is their inflammation

## Understanding and diagnosing chronic inflammation: blood tests and other approaches, and challenges with measurement [20:00]

***What do we know about someone’s ability to understand if they have chronic inflammation that they are dealing with?***

- There are some easy-to-identify things like:
  - An autoimmune condition—by definition they’re dealing with inflammation,
  - Or people who have chronic infections, you’re going to see obvious examples
- But the reality of it is that there are no clear and direct symptoms that can be used to diagnose chronic subtle inflammation in folks who might suspect that
- Furthermore, there’s not a really clear established set of biomarkers that indicate any sort of specific immune pathway
- This is obviously one of the real challenges of the field is we have biomarkers for inflammation such as C-reactive protein which are quite sensitive, but completely lacking in specificity
  - For example, Peter checks, HSC-reactive protein in every patient with every blood draw
  - It’s amazing how many times it will just show up elevated, and I can sort of say it depends on the magnitude of that inflammation we can sometimes guess what’s going on
  - If a person has a huge elevation who is otherwise normal, you almost assuredly know that they had an infection at the time of the blood draw or they’re getting over a cold or something like that
  - Once a person has like a CRP of 1.7 or 2.1, which is at least 2X what we consider normal, we have absolutely no sense of what is going on
- Unfortunately, that’s why addressing chronic inflammation is so challenging because you have to basically go down the path of serially eliminating potential causative factors
- That’s a lot harder than if you had specificity of a biomarker

***Are there certain blood-based tests that people can do to test for inflammation?***

- CRP is the most ubiquitous, but there are others
- For a better understanding, Peter will look at erythrocyte sedimentation rate (ESR)
- Complete blood cell count (CBC), allows you to see changes in both platelets and white blood cells that can be indicative of inflammation.
- Ferritin (normally something that we look at in the context of iron stores) also serves another role, which is that it is an acute phase protein that rises with inflammation and autoimmune conditions
- Looking at the CBC, there are data that suggests that individuals who are at the low end of normal have better mortality outcomes than people at the high end of normal
- If anybody’s got a complete blood cell count, they’ll notice that the reference range for white blood cell count is somewhere between 4 and 11
  - Values below this range can indicate issues with the bone marrow, while values above it can suggest infections or other conditions like leukemia.
- If you just took people who appear to be completely healthy and over periods of time, one person is constantly in the 4 to 5 range, the other person’s in the 9 to 10 range, well, that in and of itself might actually suggest some differences in inflammation levels.
- So those are the most common tests that you can get, the CRP or the HSCRP, ferritin, ESR, and then the examination of the CBC.

There are some more specialty tests that are not commonly done—certain labs that do them but you have to be careful by labs, so sometimes these are done through CLIA-based labs, so they’re more validated tests. Sometimes they’re not. Sometimes these are just done in research settings

- Additional markers include interleukin-6 (IL-6), interleukin-11 (IL-11), and tumor necrosis factor (TNF alpha), which are used selectively in high-risk patients for conditions like Alzheimer’s disease.
- Generally, the further one gets from core markers, the less validated the tests are.
- Peter focuses on basic, validated tests and appropriate interventions rather than expanding the use of multiple, less specific biomarkers.

***What are we NOT currently able to measure in terms of inflammation?***

*Are there certain things as it relates to inflammation that we know we are not able to measure?*

- One of the biggest things, which is true of a lot of things we do measure, is that we can’t continuously measure these things, therefore, we miss fluctuations
  - Cytokines, for example, fluctuate wildly over the course of a day, and that can be in response to good things as well
    - After exercising you would have seen huge excursions of inflammatory markers that have probably already returned to normal
    - That type of information, theoretically if you had it, would be valuable because then you would kind of understand what is in response to something versus what is chronic.
- But for the most part, we lack specificity around tissues, and that would be really helpful
- It would be very helpful if a person had a chronically low-grade elevation of CRP, which is very common, and you could say,
  - “Oh, based on this test, we know that that’s originating from their gut”; Or…
  - “We know that this is originating from this other organ, their liver. It’s really due to liver fat accumulation”
- There are a couple of tests that Peter uses for brain inflammation
  - They’re not really fully yet validated, but neurofilament light chain test and glial fibrillary acid protein are two tests, GFAP and NFL, that he will look at in patients to see if there’s any signs of inflammation in the brain
  - Peter uses that to not necessarily predict risk, but as a way to target intervention
    - When Peter sees a reduction in elevated biomarkers in high-risk patients following dietary, exercise, and sleep improvements, it boosts his confidence that these changes are effectively reducing inflammation.
  - “*The ideal state would be if we could do that for every organ and, therefore, we could more effectively track what we’re doing*.”

## Factors that contribute to low level chronic inflammation [28:00]

- Most things that you do to reduce inflammation are things that you should be doing regardless to improve your health
  - Exercise
  - Sleep
  - Energy balance
- It really appears that most of the things that are triggering inflammation are things that even absent the inflammation you wouldn’t really want to be doing
- The predisposing factors, things like chronic infections, inactivity, obesity, dysbiosis, poor diet, chronic stress, isolation, disturbed sleep, etc.
- Those things tend to then drive the outcomes.
- So we don’t want to see metabolic syndrome, type 2 diabetes, cardiovascular disease, cancer, depression, autoimmune disease, neurodegenerative disease, sarcopenia and osteoporosis in old people and even immunosenescence

## Minimizing inflammation through diet [29:45]

***Are there dietary guidance that everyone should be mindful of to minimize inflammation?***

- The most important thing with respect to nutrition as it pertains to inflammation is not how much of this superfood you eat or how much sugar you eat—it’s **energy balance**
  - The more energy imbalance you have, the more likely you are to have inflammation

> “All things equal, the more energy imbalance you have, the more likely you are to have inflammation.” —Peter Attia

- This might not be intuitive to most people who might think, “As long as I’m eating superfoods, I’m okay,”
- But any amount of excess fat, especially when it trickles out of the SubQ space and into those ectopic locations, is remarkably perilous
- The first thing Peter wants to do when working with patients is the following:
  - Are you adequately muscled or under muscled?
  - Are you overnourished or undernourished or adequately nourished?
  - Are you metabolically healthy or not?
- If someone’s showing up and their VAT is at the 50th percentile and their body fat is at the 60th percentile and they’ve got inflammation, all roads point to, first and foremost, let’s fix that problem.
  - Most of that is going to be controlled on the energy intake side
  - It’s not going to be about more exercise from an energy expenditure standpoint
  - We’re going to absolutely do more exercise because that’ll increase insulin sensitivity and whole bunch of other things
  - But you’re primarily now falling back into the calorie restriction, time restriction, dietary restriction template, all of which are in service of energy reduction.

**Sugar and alcohol**

- There’s a lot of data out there that absolutely implicates and speaks to this idea that sugar is uniquely inflammatory and that any diet that reduces sugar intake is going to reduce inflammation
  - The truth of it is it’s very difficult to make that claim absent the impact of sugar reduction on energy balance
  - It’s clear that for many people eating a diet that is high in sugar leads to eating more calories in general, and by that logic, reducing the amount of sugar you consume does indeed seem to reduce the amount of total calories consumed
  - It begs a philosophical question, which is, is sugar an inflammatory food or not?
    - Well, isocalorically the answer appears to be no
    - Through the lens of efficacy purely controlled, the answer is no, but maybe through the lens of effectiveness, which is in the free living world, the answer is yes
- The same is true with alcohol
  - Most people know that when we consume alcohol, we tend to make poorer food choices, and so eliminating alcohol, which in and of itself is highly caloric, generally results in a cleanup of the diet that results in less inflammation
  - That doesn’t necessarily mean that the molecule of ethanol is any more or less inflammatory that the molecule of fructose or the molecule of glucose

## The important role of fiber for gut health and inflammation [33:45]

- Another thing that’s really worth talking about from a nutrition standpoint is the role of **insoluble fiber**
- Gut dysbiosis, when the bacteria of the gut are not in a healthy equilibrium, a lot of things can actually become problematic that wouldn’t otherwise be problematic
- For example, SIBO, which we’ll talk about
- Therefore, anything that you’re doing to feed your gut bacteria more of their favorite food is going to be beneficial
- Peter talked about this at length in the [podcast with Colleen Cutcliffe](https://peterattiamd.com/colleencutcliffe/)
  - See section titled “*The important role of fiber for promoting gut health through the production of butyrate*“

> “One of the things I took away from that podcast…is I’ve always paid attention to fiber intake. I think I just pay more attention to it now. I’m almost thinking like this is a very important part of my gut’s health.” —Peter Attia

## A closer look at the impact of trans fats and saturated fats on overall health [34:45]

**Trans fats**

- Trans fats are a type of unsaturated fat and they usually stem from polyunsaturated fats, but the double bond is such that the carbons that continue the chain go on opposite sides as opposed to cis fats, which occur in nature
- You can think trans fats as two types: naturally occurring versus industrial
  - Naturally occurring trans fats are generally found in small amount in the meat of ruminant animals
    - Interestingly, those trans fats [do not have the negative associations](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2596737/#:~:text=The%20results%20from%20observational%20studies,risk%20of%20CHD%20(19).) we’ve seen with cardiovascular health that were found in the industrial version of their counterpart
  - When partially hydrogenated oils were created, which were vegetable oils that were further hydrogenated to make them more shelf-stable, that created kind of an industrial class of these trans fats
    - It turned out that even having [2% of your total energy coming from these industrial trans fats was increasing your risk of heart attack and cardiovascular mortality by 20 to 30%](https://pubmed.ncbi.nlm.nih.gov/19424218/#:~:text=A%20meta%2Danalysis%20of%20prospective%20studies%20indicated%2024%2C,death%20for%20every%202%%20energy%20of%20TFA)
    - We may never know the answer to the question of, how causal was that finding?
    - Or was it more associated with the fact that 2% of your energy from industrial trans fat, you had to by definition be eating a lot of partially hydrogenated oils, which meant you were consuming a lot of junk food?
- But as of January 2020, U.S. manufacturers are no longer anything with a partially hydrogenated oil in it anyway
- In that sense, this is now a moot discussion for people in the United States (and Peter suspects it’s the same in Europe)
- Now, we see that the only trans fats you’re eating are going to be trans fats that are naturally occurring from ruminant animals which never had the association with disease anyway

***So what’s making up the delta on trans fats?***

- Well, for most people it’s now just been more *saturated fat* intake
- There’s some mixed data on the role of saturated fats in inflammation
- Part of the problem, again, is that diets that are high in saturated fat tend to be lower in fiber, and there’s some evidence that suggests that that reduces the integrity of the gut wall and, therefore, can increase the uptake of lipopolysaccharide
  - Lipopolysaccharide is a toxin from gram-negative bacteria, so anything that allows for more translocation of what’s called LPS is potentially harmful.
- T*he takeaway here may be*: when it comes to specific foods or fats, the data points far more towards a negative dietary pattern than it points toward a negative food per se

## Why Peter prefers dietary fiber from food sources over supplements [38:30]

*How Peter is getting his fiber intake*:

- It’s just foods, not supplements
- It doesn’t make sense to try to hack the system too much here

> “Nature’s way of doing this was for us to eat high-fiber foods, and I think that’s just where we need to be turning for that nutrition.” —Peter Attia

## Debunking “superfoods”: emphasizing proven methods over marketing claims for reducing inflammation [39:00]

The term “superfoods,” gets thrown around all the time through marketing and labels. *Do any of these superfoods have anti-inflammatory effects where they are worth people going out of their way to consume?*

- Peter says that this entire concept is a marketing buffoonery
- Yes, it is mechanistically possible that certain foods could help in combating inflammation—presumably these would be foods that are very high in antioxidants or polyphenols and fiber.
- There are foods that are high in polyphenols and foods that are high in fiber and that those foods obviously are beneficial
- But the idea that if you just “drink a liter of pomegranate juice or goji berry juice every day, everything is going to be okay” is a fallacy
- In other words if you consume supraphysiologic doses of these “superfoods,” it’s going to fix your inflammation
- First of all, there’s no evidence that that is true, yet, there’s an infinite amount of marketing that says it’s true
- It just tends to be void of evidence so, at best, what we can do is say mechanistically it makes sense. It’s plausible.
- There’s a reason to think that oxidative stress is a bad thing, which we know it clearly is under certain circumstances, not always, and that consuming antioxidants would reduce oxidative stress and presumably consuming lots of antioxidants might reduce excessive oxidative stress

In short:

- Again, there is no clear experimental evidence that these “super foods” will move the needle significantly
- What concerns Peter is the subset of individuals who need to have inflammation reduced and who rather than turning to the tried and true methods that we’re going to talk about such as energy balance, exercise, sleep, elimination diets, instead just pound superfoods
- Note that half the time they are laced with sugar, are calorie-dense, and drive a poor eating habit along the way

## Is there any value in over-the-counter food inflammatory tests? [42:30]

***Is any value in listeners/viewers using a food inflammatory test to learn more about themselves?***

You can think of these as two types of tests

- 1 – There’s the over-the-counter test
- 2 – and then there’s the type of test you do with an allergist

Let’s first discuss the food allergy tests:

- Peter did a [podcast with Dr. Kari Nadeau](https://peterattiamd.com/karinadeau/), who’s an allergist, and talked about food allergies
- This is a real deal, you absolutely want to see a physician to make sure you do not have a food allergy if you have any symptoms
- For example, Peter’s friend had a little bit of eggplant and he felt like his throat was kind of swelling a little bit
- The next time it happened, it got even worse
- So this is a scenario where you need to see an allergist and you want them to do an in-office food challenge to look for an IgE-mediated response, and you have to determine if you have a legitimate allergy to that food.
- To be clear, that’s not what we’re talking about here

Food inflammatory testing

- What we’re talking about here is these food allergy tests or food sensitivity tests that are looking at IgG and they basically do a blood test and tell you about your IgG levels in response to various foods.
- Peter often have patients show up to his office on a weird diet based on the results of an over the counter food test
- The short answer is there’s just no evidence that these over-the-counter IgG blood tests have any bearing on what’s reality
- The most compelling example: If the test results correlate with an existing symptom
  - This would clearly point Peter in the direction of where he would want to start them with an elimination diet
  - In other words, if I had a person who said, “Boy, every time I eat X, I get abdominal pain or bloating or headache or some for, of indigestion, and it really seems to be tightly correlated with X
  - Then, I did this test and it said X was problematic.”
  - Peter would then say, “Okay, let’s do an elimination diet with X.”
- A contrasting example:
  - When someone says, “I have no symptoms or nothing seems to be wrong, but I did this test and it said I shouldn’t be eating these 10 things,
  - Peter says, “I think the probability that those 10 things are problematic for you is as close to zero as one can be in biology”
  - These things, whenever studied rigorously don’t point to utility or value, and so for that reason, Peter steers most patients away from this and instead points them to the old-fashioned way of doing this, which is through **elimination diets**

## Food elimination diets: how they work, symptoms and markers to watch, challenges and limitations [45:15]

**A guide to food elimination diets**:

- First make a hypothesis: E.g. the hypothesis is food item X is causing these symptoms and/or these signs
- Remember, symptoms are things you feel, signs are things you measure
- So you’re either experiencing the symptoms or maybe you feel fine but your C-reactive protein has always been between 2 and 3 and the case can be made that a C-reactive protein that’s chronically elevated like that is bad

*Example elimination diet process:*

- Let’s say you make a hypothesis that there are two possible food candidates that are causing that effect
- First of all, you have to do this one by one, which kind of makes it pretty time-consuming because it typically takes about four weeks for the gut lining to regenerate
  - Given that we think most of the effect of dietary-induced inflammation is a gut response, you obviously have to wait for the gut to regenerate
- Typically Peter has people eliminate alcohol out of the gate and pick the next one that you think is most culpable
- Having now been a part of watching many, many patients do this over the past 12 years, Peter almost always begin with wheat or dairy as the first hypothesis
- Let’s say you pick wheat, so now you’re going to take out alcohol and take out wheat completely for four weeks
- If we’re chasing a biomarker like CRP, we would then recheck the biomarker at that point in time
- If we’re doing it on a symptom, we just assess where you are symptom-wise
- Then, you begin to reintroduce it, and you initially start sort of small, and again, you look for a flareup (This is in some ways easier on the symptom side than on the blood test side. You can iterate much further)
- Nevertheless, we will do this in succession for various things
- If after they come off the wheat for a month or even six weeks, there’s no change in the CRP, then we know that it wasn’t wheat
- From there you go back to eating wheat, and now we try again with milk, yogurt, eggs, or any other hypothesis you have

Peter explains:

- When this works, it’s really awesome
- When you find the single thing that is causing the problem, it’s really, really satisfying
- But truthfully, sometimes it doesn’t find the answer and that can be very frustrating
- What’s also frustrating is when you get the answer and it’s not the answer you want
  - Wheat, for example, is a very difficult thing to eliminate (typically more so than other things like dairy, eggs, etc.)
  - But, if the magnitude of the improvement is significant enough, which it clearly is in the most extreme case like celiac disease, well then it’s a no-brainer

*If you’re chasing symptoms over the CRP and you’re defining if it works, how obvious is that?*

- It’s really dependent on the individual
- Peter has seen all spectrums of this
- Like the person whose chief complaint is their symptoms with or without an elevated biomarker
  - If that patient’s gets better symptom-wise with or without the biomarker change, we’ve moved in the right direction and away we go
- You then see people less commonly who say, “I feel totally fine,” but their biomarkers off
  - We go after chasing the biomarker, we fix the biomarker, and they also say, “I actually feel better, I didn’t realize,” and they’ll say things that are usually kind of vague
  - They’ll say like, “Boy, I realize now I was kind of under a fog.”
  - Of course, this is most obvious when you reintroduce the thing that you just took out because usually the improvement takes a while, but the reintroduction creates the symptom again.
  - They’ll say, “I thought I was fine, and I kind of thought I got better, but I couldn’t quite tell, but then when we reintroduce that thing, oh my God, I went back to feeling such-and-such.”
- But it’s definitely easier when there is a symptom involved

Parting thoughts:

- At the end of the day, we talk a lot about this stuff through the lens of lifespan — i.e., inflammation is bad because it increases the four horsemen, etc.
- But healthspan is just as important
- “*If you feel better by eliminating certain foods, by all means eliminate said foods, even if it doesn’t change your inflammation markers… if it improves your quality of life, meaning the benefit you get is in excess of the detriment of giving up that thing, I think it’s worth it*.”

## Identifying dietary triggers for gut-related symptoms through low-FODMAP diets like the “carnivore diet” [51:15]

- Friends of Peter have experimented with the carnivore diet, either as part of an elimination diet or as a new dietary approach, which acts as an ultimate low-FODMAP diet.
- FODMAPs are fermentable oligosaccharides, disaccharides, monosaccharides, and polysaccharides, which are poorly absorbed carbohydrates that can cause bacterial overgrowth and GI symptoms if one has gut dysbiosis.
- High-FODMAP foods (broccoli, onions, garlic, apples, berries, watermelons, beans, wheat, milk, soft cheeses) are restricted, while low-FODMAP foods (meat, fish, seafood, eggs, tofu, potatoes, carrots, tomatoes) are encouraged to reduce these symptoms.
- The effectiveness of the diet is evaluated by reintroducing high-FODMAP foods gradually to see if symptoms reoccur, determining whether to continue avoiding certain foods.
- The aim is to maintain a diverse diet, recognizing that humans are naturally opportunistic omnivores.
- There is limited robust data supporting the elimination of nightshades (tomatoes, eggplants, peppers, potatoes) for GI issues, but empirical trials of elimination and reintroduction may still be worthwhile to identify personal triggers.

## Dairy: the complex role of dairy on inflammation and individual responses [55:00]

*Previously, Peter mentioned dairy and wheat as two foods that often get chosen for elimination diets*

*Starting with dairy, why is that? What is so special about dairy that it can cause issues for people around inflammation?*

- First of all, dairy is a hot button topic
- That said, if you’re NOT having digestive problems and you don’t have an unexplained persistent elevation of CRP, you do not need to go down the dairy-free rabbit hole
- It’s really clear that at the population level, dairy is actually probably net beneficial on anti-inflammatory effects
- [Studies](https://pubmed.ncbi.nlm.nih.gov/26287637/) that look at moderate consumption of dairy actually tend to find less inflammation
- So really what we’re trying to do is tease out people who at the individual level are exceptions to that rule (and there are many exceptions)

*What does it come down to?*

- There’s a couple of things going on with dairy
- One of them is just lactose intolerance, which is in some ways increasingly prevalent as we age, so this inability to digest a milk-based sugar, but that’s slightly different
  - But you can have lactose intolerance, but have no inflammation
- What we’re talking about are people who experience an unexpected or unexplained inflammatory response to a peptide found within dairy, and it’s typically beta casein
- The forms of milk proteins are whey protein and casein protein
  - These proteins are peptides, and what do peptides do? … They potentially elicit an immune response, and so that’s really what we’re talking about here
- So again, we’re not talking about lactose intolerance, which may be reason enough for certain people to avoid dairy or at least some kinds of dairy, for example milk and soft cheese, but not so much yogurt or hard cheese
- What we’re talking about here is you’re that person, let’s say without symptoms but with high CRP, we’re going down the pathway to figure this out
- Again, it’s a straight-up elimination thing
- But on one level it shouldn’t be that surprising
- Dairy is high in protein—that’s one of the reasons we like dairy—but some of those proteins can do what proteins can do, which is they elicit an immune response if they generate an antibody.

## Wheat: the complexities and conflicting evidence around wheat’s inflammatory effects [57:45]

***What do we know about wheat and why that can also cause effects for people?***

- The amount of conflicting evidence around the potential inflammatory nature of wheat is quite staggering
  - There’s some literature out there that actually shows isocaloric whole-grain diets reduce inflammation
  - And there are studies that even suggest the opposite
- If there’s going to be a negative inflammatory response, it’s usually going to be in response to a protein
- There are a couple of proteins in wheat, gluten and gliadin, that play a clear role in extreme states like celiac disease and even some patients with inflammatory bowel syndrome
- However, human trials showing gluten increases inflammatory markers are actually kind of lacking
- So the idea here is if you exclude the people that have a clear disease in response to wheat and just look at those of us don’t…
  - Is gluten still inflammatory? ⇒ It’s not clear
- There’s also the problem of cases where people are experiencing negative side effects to wheat…
  - Is it the wheat itself?
  - Or is it other elements of the wheat?
- Peter says that subjectively there seems to be a difference in consuming wheat that is grown in the United States versus wheat that is grown in Europe
  - Some people have attributed that to the use of pesticides, but it might actually be that the difference is maybe more due to the strain of wheat that’s grown, and obviously different strains are going to have different peptides

An example of [one small study](https://pubmed.ncbi.nlm.nih.gov/25734566/)

- Four groups of subjects of five or six people in it
  - 1) The first group was people who had celiac disease, but it was active disease
  - 2) Another group had celiac disease in remission
  - 3) Another group didn’t have celiac disease, but self-reported gluten sensitivity
  - 4) another group were non-celiac controls that reported no wheat sensitivity
- They took duodenal biopsies and then they did a bunch of ex vivo experiments where they exposed those duodenal epithelial cells to wheat antigens and basically asked the question, “What happened to the permeability relative to a control solution?”
  - In all of these cases, gut permeability increased in the presence of wheat antigens or wheat proteins
  - Of course, the study is so poorly done, the control media doesn’t exactly necessarily pose the right controls, so you just don’t know
- If you look at this… *Is the implication that everybody experiences translocation of LPS or anything else that is negative that happens with gut permeability going up*?
  - Or is it that “*no, this was just a bad study*?”
- Again, on the one hand, we just don’t really have good studies that demonstrate that in non-celiac, non-IBS patients wheat is causing trouble
- Then, you have studies like this that suggest, “Oh no, maybe there’s a problem.”

Peter’s take:

- Peter’s take on this is very similar to his take on dairy
- He’s seen a spectrum of results with patients who eliminate wheat
- You have patients who are having unexplained GI distress
  - They don’t test positive for any of the traditional markers that you would think about for celiac or IBD, and yet when you take wheat out of their diet, everything gets magically better
- Conversely, you have patients who have no symptoms at all, but they have this unexplained chronic inflammation, and when you take out wheat, the chronic inflammation goes away
  - In one situation, you’re improving healthspan clearly by quality of life, maybe lifespan for another reason
  - In the other one, you’re not really changing their quality of life—You might actually be reducing it technically by taking food away from them, but you will reduce their risk of chronic disease we believe
- All of those things have to be kind of weighed out, but unfortunately the way to go about doing this is that tried and true way of an elimination test
- Hopefully folks listening to this who want to attempt that will have physicians who are themselves supportive of the repeat CRP test every four to six weeks as you go through this exercise.

## How exercise influences inflammation [1:02:00]

***What do we know about exercise, physical activity, and inflammation? Is there any relationship there between the two?***

- Inactivity significantly increases inflammation, while physical activity generally improves it through various mechanisms.
- Exercise reduces inflammation by:
  - Decreasing visceral fat.
  - Producing anti-inflammatory cytokines (myokines) from muscles.
  - Lowering the expression of toll-like receptors on macrophages and monocytes.
- Acute bouts of exercise temporarily raise inflammatory markers like interleukin-6 and CRP, which typically return to baseline within an hour.
- The temporary inflammation from exercise might be related to tissue damage or a drop in muscle glycogen content.
- Exercise can also trigger anti-inflammatory effects through the release of catecholamines and glucocorticoids.

Takeaway: There isn’t clear evidence that increasing exercise in already active individuals reduces inflammation further, but it is effective in reducing inflammation in inactive individuals.

Regarding CRP tests:

- It is not necessary to fast before a CRP test, but fasting is typical for metabolic panels to accurately measure glucose, insulin, and triglycerides.
- Avoid exercising right before a CRP blood draw to prevent transient increases in inflammation markers.
- Peter shares a personal anecdote highlighting fluctuating biomarkers in response to intense workouts, affecting levels of triglycerides and potentially other markers like CRP and fibrinogen.

## How sleep quality and duration impacts inflammation [1:07:00]

***What do we know about sleep and the role that that can play in inflammation?***

Peter compares the impact of sleep on inflammation to that of exercise on inflammation

- When you remove it, inflammation goes up.
- When you add it, it takes a while to fix
- Absence of sleep or sleep reduction is a really pro-inflammatory state

**The most elegant thing to do would be to look at this one** [**study**](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0004589)

- This was a study that tried to mimic the idea of getting lousy sleep during the week and then trying to make up for it on the weekends
- It took 13 healthy young men and it subjected them to four hours of sleep for five nights and then two nights at eight hours of sleep
- Then, they had six controls that just slept eight hours a night throughout the whole study
- Meals were controlled, no napping
- It was a very well-done study
- You had a relatively small sample size because you’re asking something quite draconian of people

*What were they measuring?*

They were basically looking at various markers, inflammatory cytokines

![](https://peterattiamd.com/wp-content/uploads/2024/05/f3-ama59.png)

**Figure 3.** Source: [Van Leeuwen et al. PLoS One 2009](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0004589)

- First thing you see here is you’re looking at five different biomarkers, so C-reactive protein, IL-6, IL-1 beta, IL-17, and tumor necrosis factor alpha
  - You have white bars, which are the controls
  - And you have black bars, which are the experimental group
- For CRP, they’re just measuring the protein
- For the others, they also measure the mRNA and the protein, and in one case that’s actually a bit discordant, which is on the IL-1 beta

*What are you seeing here?*

- There’s two bars for every section
- There’s the sleep reduction and the recovery phase
  - That’s why the control bars are always looking the same
- So let’s look at the experimental group:
  - During the sleep restriction phase, they had about a 50% increase in their CRP, and that was statistically significant
    - Here’s what’s really interesting: During the recovery phase, it kept going up. It doubled
  - When you look at interleukin-6, you saw that relative to baseline, they had about a doubling of IL-6 actual protein measurement during sleep restriction and it didn’t go down a lick during recovery (At least at that ratio of 5:2, it wasn’t enough.)
  - The same was true for IL-17, though the magnitude was a little bit less than that
  - You saw an increase that was statistically significant in IL-1 beta
  - And tumor necrosis factor went down statistically significant
- There was a [follow-up study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5067189/) that was done the same as this, but they did it three weeks repeated, so you went 5:2, 5:2, 5:2, 5:2.
- It showed that the inflammatory responses to sleep restriction did not habituate after these repeated cycles despite the subjects gradually habituating to how they felt

> “This was a very interesting study because you can imagine what this means for the average person who lives this way.” —Peter Attia

This is a really important point:

- If you’re that person who’s burning the midnight oil really hard Monday through Friday and then saying, “I’m going to make up for it on weekends” and “I feel fine”
- Peter would say “I believe you because the data show that you will habituate to that sleep restriction.”
- But Peter would hope to convince that person through sharing this data that just because you “feel fine” and can “make up for it on the weekends” it doesn’t mean you’re free and clear

*What if there is someone who has inflammation, but already is exercising really well and sleeping really well? Will doing both of those more may not have the same effect, correct?*

- Yeah, exactly, we don’t tend to push too much harder on those things unless we see that there’s a clear issue going on
- “T*o be clear, a lot of people are not exercising sufficiently and sleeping sufficiently, so it’s a very important area to be exploring*.” says Peter

## The potential impact of chronic psychological stressors on inflammation [1:13:00]

*Chronic stress is something that could easily be a part of that, whether it’s family, work, life, whatever it may be. What do we know about stress and inflammation?*

- We know surprisingly little (in humans, at least)
- We do know that persistent psychological stress disrupts the glucocorticoid pathway, potentially downregulating anti-inflammatory responses.
- Chronic high cortisol levels can lead to decreased immune system sensitivity, increasing chronic inflammation.
- [Systematic reviews](https://pubmed.ncbi.nlm.nih.gov/26799456/) of randomized controlled trials (RCTs) indicate that meditation and mindfulness practices can reduce various inflammatory markers, though much of this data derives from animal models using social isolation to induce stress and inflammation
- The causal relationship between chronic stress and inflammation lacks robust experimental data, resulting in less clarity.

Stress and immune system and wellbeing

- Regardless of its direct impact on inflammation, reducing chronic stress is beneficial as it may weaken the immune system, making one more susceptible to other diseases.
- Addressing chronic stress is important not just for potentially controlling inflammation but also for overall health and susceptibility to various disease states.

## The impact of oral health on inflammation and overall well-being [1:15:00]

*If someone has kind of persistent infections or dealing with something of that nature, is that something that can affect inflammation and they should be thinking about as they’re trying to look through causes and solutions?*

- Persistent infections can significantly impact inflammation, particularly chronic inflammation where pathogens are involved and the body struggles to clear them.
- An important example of such chronic inflammation is found in oral health, especially periodontal disease, which can be challenging to manage if oral hygiene is lacking.
- Regular dental check-ups and good oral hygiene practices like daily flossing and brushing are crucial; they can significantly influence inflammation levels.
- Peter often asks patients about their last dental visit and oral hygiene practices to link potential inflammation issues with oral health conditions.
- There are cases where dental interventions have significantly lowered inflammatory markers like CRP in patients with previously unexplained chronic inflammation.
- While there’s a strong correlation between poor oral health and major health issues (the “four horsemen”: cardiovascular disease, diabetes, chronic respiratory diseases, and cancer), the causal relationship isn’t fully proven.
- Maintaining good oral health is recommended not just for potential life extension but for significantly improving quality of life, especially in older age.
- Peter emphasizes personal diligence in oral care, not just for disease prevention but for ensuring quality of life over the long term.

⇒ See [episode with Patricia Corby](https://peterattiamd.com/patriciacorby/) all about oral health

## The role of medications in managing chronic inflammation [1:18:15]

***Are there anti-inflammatory drugs that are effective that people should be thinking about going to their doctor and asking about these?***

- The short answer is no with maybe one exception
- NSAIDs:
  - While valuable for various medical issues, NSAIDs are not recommended for long-term management of chronic inflammation due to lack of efficacy in this specific context.
- Canakinumab:
  - Discussed as a proof of concept, Canakinumab was tested to see if it could prevent secondary MACE in post-heart attack patients
  - It showed a potential improvement in risk reduction at higher doses but was associated with increased risks of severe infections and sepsis, leading to its discontinuation.
- Colchicine:
  - Colchicine, a long-standing medication primarily used to treat acute gout attacks, has been recognized for its anti-inflammatory properties.
  - It has been approved by the FDA for reducing residual cardiovascular risk in high-risk patients after myocardial infarction (heart attack).
  - However, its use is limited to very high-risk patients and is not broadly applied for reducing inflammation across all patient groups.
- Glucose-lowering drugs that are used to treat type 2 diabetes:
  - Various diabetes medications, including SGLT2 inhibitors, GLP-1 agonists, DPP-4 inhibitors, thiazides, sulfonylureas, and particularly Metformin, have shown to reduce inflammation.
  - These effects might be due to direct anti-inflammatory actions or indirectly through improvements in metabolic health and weight loss.
- Metformin and Geroprotection:
  - One of the arguments of people who believe that metformin is geroprotective is that this is one of the pathways that metformin targets is directly targeting inflammation
  - This characteristic of Metformin is viewed as extending beyond its primary role in blood sugar regulation, possibly affecting processes like cellular senescence and systemic inflammation.

## Supplements: evaluating the efficacy of various anti-inflammatory supplements [1:22:15]

*Another industry where there’s tons of marketing around lots of anti-inflammatory supplements that people can buy over the counter, what do we know about supplements and their potential effect on inflammation?*

- It’s not terribly unlike the pharma world except you have worse clinical trials and there’s more claims that are being made because people just say whatever they want to say,
- Rather than just focus on the noise, let’s try to talk about signal

Curcumin:

- Curcumin probably has the strongest anti-inflammatory effect and it probably has the best evidence as well
- Curcumin, a polyphenol that gives turmeric its yellow color, really does appear to have potent anti-inflammatory effects
- One [meta-analysis from 2021](https://pubmed.ncbi.nlm.nih.gov/34586711/#:~:text=hs%2DCRP%20concentration%20in%20the,;%20hs%2DCRP;%20inflammation.) found that curcumin reduced CRP by 3.67 milligrams per liter. That’s a reasonable chunk of change depending on where you’re starting, and that was typically at does of 1,000 to 2,000 milligrams.
- Interestingly, in patients who were obese as a subset of that analysis, the effect wasn’t present, though the effect was more pronounced in people with rheumatoid arthritis
- It certainly suggests that there may be a differential effect of reducing inflammation because, again, the inflammation in somebody with rheumatoid arthritis is autoimmune in nature
- Whereas, the inflammation in the person with obesity is reactive in response to the adiposity
- The good news is curcumin is a relatively safe compound, assuming you can assure purity, which is not that hard to do because there are a number of really reputable companies selling it
- No side effects, relatively inexpensive, probably a reasonable thing to try.

Theracumin:

- Theracumin is actually significantly more expensive
- And it is much more bioavailable
- Peter typically does recommend Theracumin to patients if they are higher risk patients—patients higher risk for neurodegenerative disease
- Patients who have an APOE4 gene, for example, or a family history of Alzheimer’s disease, he would typically recommend Theracumin
- Peter also personally takes theracumin and he’s happy to pay the extra money for it
- Typically, doses are going to be anywhere from 1,000 to 2,000 milligrams per day (CORRECTION: Please note that this statement was a misspeak and refers to doses of curcumin rather than theracurmin. While typical doses of curcumin range from 1,000 to 2,000 milligrams per day, doses of theracurmin are typically 30-90 milligrams per day.)
- Generally up to three times that amount, people are tolerating that pretty easily
- This would be probably the most important supplement on the list

Omega-3 Fatty Acids (EPA & DHA):

- EPA and DHA are essential in the resolution phase of acute inflammation, acting as precursors to anti-inflammatory molecules.
- In terms of their effectiveness in reducing inflammation…
  - Studies indicate that DHA and EPA supplementation can reduce inflammatory markers, but many don’t measure baseline omega-3 levels, making it unclear whether benefits are due to correcting a deficiency or the inherent properties of omega-3s.
- Recommended daily intake of EPA and DHA is typically 2 to 3 grams. Higher doses (5-10 grams) may increase the risk of atrial fibrillation (AFib) and are not advised.
- Monitoring Omega-3 Levels: Red blood cell EPA/DHA incorporation is monitored to ensure levels remain within a safe range, ideally between 10% and 12%.

Other Anti-Inflammatory Compounds:

- Ginger, quercetin, and green tea are often mentioned for their potential anti-inflammatory effects
- But systematic reviews and meta-analyses have not consistently supported their effectiveness

**Overall**: Due to inconsistent findings, supplements like ginger and quercetin are not recommended as strongly as curcumin, Theracumin, or EPA and DHA for anti-inflammatory purposes.

## Parting thoughts and takeaways [1:27:00]

**Chronic vs. Acute Inflammation**: The focus is on chronic inflammation, which persists unnecessarily beyond its initial beneficial phase in contrast to acute inflammation needed for healing.

**Identifying Inflammation**: Often, there are no symptoms; instead, inflammation is indicated through biomarkers such as CRP, fibrinogen, white blood cell count, or ESR.

**Checklist for Addressing Inflammation**:

- Diet: Check if energy balance is addressed, reduce intake of potentially inflammatory items like saturated fats and fried foods, and consider elimination diets, starting with dairy or wheat and eliminating alcohol.
- Oral Health: Ensure good oral hygiene with regular brushing and flossing, monitor gum health, and visit the dentist for thorough check-ups.
- Sleep: Prioritize quality sleep, as poor sleep has proven negative effects on health, even if sleep is caught up on weekends.
- Exercise: Incorporate regular physical activity as the fourth step in reducing inflammation.
- Psychological Stress: Although evidence linking stress to inflammation is weaker, reducing stress is beneficial for overall health.

**Supplementation**:

- Curcumin and Theracumin: Consider using these supplements, known for their anti-inflammatory properties, at discussed dosages.
- Omega-3s (EPA and DHA): Ensure adequate levels, preferably through diet or high-quality supplements like those from Carlson’s to avoid high capsule consumption.

§

## Selected Links / Related Material

**Movie mentioned by Peter**: [Napoleon Dynamite](https://en.wikipedia.org/wiki/Napoleon_Dynamite) | (wikipedia.org) [2:00]

**Episode of The Drive describing the hallmarks of aging**: [#175 – Matt Kaeberlein, Ph.D.: The biology of aging, rapamycin, and other interventions that target the aging process](https://peterattiamd.com/mattkaeberlein2/) | Peter Attia (peterattiamd.com) [11:45}

**Observational study that looked at 160,000 participants which asked the question about the relationship between inflammation and all-cause mortality or disease-specific mortality**: [Systemic Inflammation Predicts All-Cause Mortality: A Glasgow Inflammation Outcome Study](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0116206) (Proctor et al., 2015) [12:15]

**The CANTOS trial that tested canakinumab, a monoclonal antibody, targeting interleukin-1 beta**: [Antiinflammatory Therapy with Canakinumab for Atherosclerotic Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa1707914) (Ridker et al., 2017) [14:45]

**Episode of The Drive with Colleen Cutcliffe discussion the importance of fiber for gut health**: [#283 ‒ Gut health & the microbiome: improving and maintaining the microbiome, probiotics, prebiotics, innovative treatments, and more | Colleen Cutcliffe, Ph.D.](https://peterattiamd.com/colleencutcliffe/) | Peter Attia (peterattiamd.com) [35:00]

**Trans fats found in ruminant animal meat do not seem to have the negative associations we’ve seen with cardiovascular health that were found in the industrial version of their counterpart**: [Ruminant and industrially produced trans fatty acids: health aspects](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2596737/#:~:text=The%20results%20from%20observational%20studies,risk%20of%20CHD%20(19).) (Stender et al., 2008) [36:00]

**Study finding that if 2% of your total energy comes from** ***industrial*** **trans fats it was increasing the risk of heart attack and cardiovascular mortality by 20 to 30%**: [Health effects of trans-fatty acids: experimental and observational evidence](https://pubmed.ncbi.nlm.nih.gov/19424218/#:~:text=A%20meta%2Danalysis%20of%20prospective%20studies%20indicated%2024%2C,death%20for%20every%202%%20energy%20of%20TFA) (Mozaffarian et al., 2009) [36:00]

**Episode of The Drive about food allergies**: [#277 ‒ Food allergies: causes, prevention, and treatment with immunotherapy | Kari Nadeau, M.D., Ph.D.](https://peterattiamd.com/karinadeau/) | Peter Attia (peterattiamd.com) [43:00]

**Studies that look at moderate consumption of dairy actually tend to find less inflammation**: [Dairy products and inflammation: A review of the clinical evidence](https://pubmed.ncbi.nlm.nih.gov/26287637/) (Bordoni et al., 2017) [55:45]

**Small study that found increased intestinal permeability from wheat intake**: [Effect of gliadin on permeability of intestinal biopsy explants from celiac disease patients and patients with non-celiac gluten sensitivity](https://pubmed.ncbi.nlm.nih.gov/25734566/) (Hollon et al., 2015) [59:30]

**Study that tried to mimic the idea of getting lousy sleep during the week and then trying to make up for it on the weekends to see the impact on inflammation**: [Sleep Restriction Increases the Risk of Developing Cardiovascular Diseases by Augmenting Proinflammatory Responses through IL-17 and CRP](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0004589) (Van Leeuwen et al, 2009) [1:08:00]

**Study that showed that the inflammatory responses to sleep restriction did not habituate after these repeated cycles despite the subjects gradually habituating to how they felt**: [Repeating patterns of sleep restriction and recovery: Do we get used to it?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5067189/) (Simpson et al., 2016) [1:11:00]

**A systematic review of RCTs that report that meditation and mindfulness practices reduce various inflammatory markers**: [Mindfulness meditation and the immune system: a systematic review of randomized controlled trials](https://pubmed.ncbi.nlm.nih.gov/26799456/) (Black and Slavich, 2016) [1:14:00]

**Episode of The Drive about the importance of oral health and the association between poor oral health and the “four horsemen”**: [#166 – Patricia Corby, D.D.S.: Importance of oral health, best hygiene practices, and the relationship between poor oral health and systemic disease](https://peterattiamd.com/patriciacorby/) | Peter Attia (peterattiamd.com) [1:17:00]

**Episode of The Drive with Nir Barzilai about metformin**: [#204 – Centenarians, metformin, and longevity | Nir Barzilai, M.D.](https://peterattiamd.com/nirbarzilai2/) | Peter Attia (peterattiamd.com) [1:22:00]

**One meta-analysis from 2021 found that curcumin reduced CRP by 3.67 milligrams per liter typically at does of 1,000 to 2,000 milligrams**: [Effect of curcumin on C-reactive protein as a biomarker of systemic inflammation: An updated meta-analysis of randomized controlled trials](https://pubmed.ncbi.nlm.nih.gov/34586711/#:~:text=hs%2DCRP%20concentration%20in%20the,;%20hs%2DCRP;%20inflammation.) (Gorabi et al., 2022) [1:23:00]

§

## People Mentioned

- [Robert (Bob) Montgomery](https://en.wikipedia.org/wiki/Robert_Montgomery_(physician)) [3:00]
- [Colleen Cutcliffe](https://pendulumlife.com/pages/story) [35:00]
- [Kari Nadeau](https://en.wikipedia.org/wiki/Kari_Nadeau) [43:00]
- [Nir Barzilai](https://en.wikipedia.org/wiki/Nir_Barzilai) [1:22:00]

§