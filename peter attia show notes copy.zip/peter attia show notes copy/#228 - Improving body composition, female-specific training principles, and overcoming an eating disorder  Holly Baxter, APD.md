# #228 ‒ Improving body composition, female-specific training principles, and overcoming an eating disorder | Holly Baxter, APD

**Source:** [https://peterattiamd.com/hollybaxter/](https://peterattiamd.com/hollybaxter/)

---

Holly Baxter is an accredited practicing dietician (APD), competitive bodybuilder, fitness and nutrition educator, and coach. In this episode, Holly discusses her experience as an athlete and competitive bodybuilder. She also opens up about her struggles with mental health, her long battle with an eating disorder, and the important steps she’s taken in her road to recovery. From there, she explains how she would design a nutrition and training program for a hypothetical female client wanting to improve her physique through the addition of lean muscle and loss of body fat. She explains reasonable expectations for gaining muscle and the value of a “reverse diet” for maintaining weight loss, and she shares her favorite exercises. She also talks through some female-specific training considerations such as programming, reps, volume, hormone replacement therapy, and more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/hollybaxter/the_Drive_public.png)

Play

#228 ‒ Improving body composition, female-specific training principles, and overcoming an eating disorder | Holly Baxter, APD

#228 ‒ Improving body composition, female-specific training principles, and overcoming an eating disorder | Holly Baxter, APD

1x15s30s

0:002:15:24

## We discuss:

- Holly’s background and passion for sports and nutrition [2:00];
- Holly’s struggle with depression and an eating disorder [4:30];
- Reflecting on her eating disorder, body image, and a wake up call [18:15];
- Road to recovery: therapy, meditation, self-compassion, and a breakthrough [27:45];
- The effect of competitive bodybuilding on women [39:00];
- Holly’s competition prep and how she guides her clients wanting to improve their physique [46:45];
- Training principles for muscle hypertrophy [57:00];
- Training advice for an inexperienced person wanting to build muscle [1:01:30];
- Training program for a hypothetical woman wanting to add lean muscle and lose body fat [1:04:15];
- Lower body lifts: Holly’s approach to leg workouts with clients [1:14:00];
- Upper body exercises: Holly’s approach with her clients [1:24:45];
- Importance of nutrition and protein during the muscle building phase [1:34:00];
- Changes to nutrition and training during a fat loss phase [1:40:30];
- A “reverse diet” after a cutting phase to help prevent weight gain [1:49:45];
- Female-specific training considerations: programming, reps, volume, sex hormones, and more [1:53:15];
- Holly’s future in bodybuilding and helping struggling women [2:05:45];
- Looking forward: Holly’s focus on longevity, bone mineral density, and wellness [2:08:15]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Holly Baxter is an accredited practicing dietician, a competitive bodybuilder, a physique coach, and a personal trainer
  - She’s also a fitness educator and a competition coach
- In this episode we talk about Holly’s background and her interest in nutrition
- She opens up in detail about her struggle with an eating disorder
- From there we dive into a case study of a typical female patient Holly may work with
  - What Holly may think about as she works with her on training to improve her physique
  - Holly builds out what a training and nutrition program might look like for this female who wants to gain 5 lbs of muscle and lose 5 lbs of fat
- We then talk about female-specific principles when it comes to training
- Even if you’re not aspiring to be a bodybuilder, everybody is somewhat interested in improving their physique, and therefore there is a lot of value in this episode about building muscle (particularly for females)
  - Which is important for longevity

## Holly’s background and passion for sports and nutrition [2:00]

- Holly grew up in Tasmania, Australia
  - This is the little island that sits just south of the mainland, it’s a pretty small place
- She’s now in Florida
- Part of her evolution was just a big open mind
- She didn’t want to stay in Tasmania
- She moved to Melbourne to go to college at Deakin University
  - Where she did a BS in Food Science Nutrition, and then a MS in Dietetics

**Tasmania by landmass looks pretty big, but is has a tiny population**

- The population now is about 500,000
- When she grew up in Launceston, it had a population of about 90,000

**Holly ran track as a kid**

- She started track at about age 8 and continued through age 18
- She ran track in both high school and college
- She was finished with track by her 2nd or 3rd year of university
  - This was the point where she had to choose between a sports career or academics
- In Australia, there isn’t a lot of opportunity for females to have a successful career in sports
  - Maybe now that social media has grown females may have more opportunity
- Academics seemed like her only option at the time

**What did she run in track?**

- She was a sprinter
- She ran the 100 meters, long jump, and triple jump

> “*Lots of fast twitch, anything explosive and powerful and short*”‒ Holly Baxter

**Did she lift weights in high school?**

- She started lifting weights in probably grade 11
- That was when she was part of the Tasmanian Institute of Sports
- Her coach at the time, Peter Fortune, was also the coach of Olympic 400 meter runner, [Kathy Freeman](https://en.wikipedia.org/wiki/Cathy_Freeman)
  - She won the gold medal in the 2000 Olympics, and everybody loved her
- Holly worked with Peter Fortune and that’s where she had a lot of her experience in track sprinting

## Holly’s struggle with depression and an eating disorder [4:30]

- Holly got into sport because of her desire for control over her nutrition
- She has only recently overcome a 15 year eating disorder
- She struggled with anorexia for a short time and went on to binge eating and bulimia
- Even before she thought about going off to college, she was in the depths of that disorder
- She was also struggling a lot with depression
- At age 16 she had already attempted suicide twice
- She was hospitalized for a good part of grade 11
- Looking back at that now, it’s really sad
  - She just didn’t have the support or mentors
- This escalated into adulthood and only very recently has she started to work on her mental health
- A lot of her advances have come as she has developed a sense of purpose in life
  - And ultimately finding happiness

**When her eating disorder began, did that proceed to depression or were the two intertwined, hand in hand?**

- They came on simultaneously for multiple reasons
- Her mother was an incredible woman, she basically raised Holly and her sister
  - She has just 1 sibling, a younger sister
- Her dad was around but was a very hard worker, very disciplined and focused on his career
  - So she and her sister were kind of invisible to him
- Her mom had grown up in a similar situation where her mother was completely absent
  - She grew up having to do it all for herself
  - She was also into athletics
- Holly’s relationship with her mother was strained
  - She felt her mom wanted to control her, protect her
  - This created a lot of friction
  - Up until she was 10 years old, she wasn’t allowed to have a sleepover at a friend’s without there being serious arguments
- She had a lot of hostility and confrontation growing up

**In 10th grade was she 15?  Was the focus before that age on just academics and sports?**

- Yes
- She did dance (tap, jazz, and ballet) and music (piano, guitar, and drums)
- She was into basketball and athletics
- She did a lot of activities
- The only kind of praise and recognition or feeling of being cared for came from excelling at something
  - If she came home from school with really good grades, this was the only time she would get, “*Oh wow. We really love you*” or “*Well done*”
- She knows her mom loves her, but how people communicate is so important

***She grew up with the idea that unless she was the best at something, or did everything and excelled at everything, she didn’t really have value as a human***

- This is one aspect of where the depression and eating disorder came from
- She also experienced some sexual trauma around that age
- There were 2 instances, and it happened with people she really respected and trusted
- That coupled with a toxic home environment
  - She felt she couldn’t go to her parents
  - She had a fear of being judged from the community
  - Everything was about keeping up with appearances
- She tried to talk to her mom about what happened
  - But instead of having her ask, “*Are you okay? Talk to me*”
  - Her mom was more like, “*Well, what did you do to deserve that?  Well, what were you wearing?  How were you dressed?  What kind of makeup did you have on?*”
- He mom didn’t know how to support her
- Her mom tried to look for therapy, but Holly was so far down the rabbit hole of depression and feeling like a lost cause that nothing worked
  - Behavioral therapy was ineffective
  - Medication actually made things significantly worse, so consequently she came off that

**Holly’s struggle with bulimia [9:30]**

*Do you have a sense of how often eating disorders afflict young women versus young men?*

- The prevalence is a lot greater in females than males
- But in the last 10 years it’s increasing in young boys
- Holly recalls something on the order of 60% of high school girls in the US have reported to struggle with low confidence and a negative sense of self and body image
- The prevalence of eating disorders is lower but but it’s still scarily high, see the figure below
- Eating disorders in younger children is also higher than it should be

![](https://peterattiamd.com/wp-content/uploads/2022/10/f1-hollybaxter-1024x694.png)

**Figure 1.  Prevalence of eating disorders in the US by age**.  Image credit: [*JAMA Network* 2019](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2752577)

**Holly mentioned it started first with anorexia, before binging and purging.  Did she gain a sense of control by limiting what you were eating?**

*In the short-term, did this satisfy something inside you?*

- It did
- Maybe because she was so athletic
- She thinks back to the amount of training she was doing
  - With in-school sports
  - Hours of practice after school, 6 days a week and maybe on Sunday
- With these energy demands she couldn’t sustain the restriction
- She was frustrated with how famished and hungry she was
- She didn’t connect the dots and struggled with the question, “*Why can’t I control what I put in my body?*”
  - She didn’t know anything about appetite regulating hormones
  - Or the energy requirements for the sports she was doing
- She would act out these behaviors of binge eating and then purging
  - It was just constant
  - There was a point where it was probably every day of the week for 5 years
    - Which is terrifying to think about considering the risks
- It slowed down when she got to university
  - Probably because she had to work 3 jobs and the requirements for study gave her less opportunity to do that

> “*I just remember feeling I wanted to be able to control things, but at the same token, I had no control, because my body was doing what it’s meant to do, which is to protect you from starvation, essentially*”‒ Holly Baxter

**Complications associated with bulimia**

*With the constant flow of acidity up and down the esophagus, did she have any issues with her teeth?  Any electrolyte abnormalities?*

- Interestingly, no
- She doesn’t know about electrolyte abnormalities because she never had routine blood work back then
  - That was not something she prioritized as a young, naive student
- Thankfully she never had any esophageal erosion for the acid
  - She thinks a risk for developing cancers of the throat and olfactory
  - It’s a scary thought

**How did this progress?  Did anybody in her life recognize this was going on?**

- No
- Holly moved away for college, her family wasn’t in the same state and they didn’t travel to see her very often
- She didn’t have the family support
  - She never had a close relationship with her sister
  - They just moved in different directions in life
  - She didn’t  have any kind of relationship with her father
  - So she didn’t have anyone to go to for guidance
- None of her boyfriends knew this was happening
  - Out of shame, she may have communicated it to 1 boyfriend
- She thinks about the stigma associated with mental health issues
- To have depression and also to have an eating disorder was hard for her as a perfectionist, high achiever, driven woman

> “*There was no way I wanted to share this weakness*”‒ Holly Baxter

- She was terrified to tell anybody
  - Especially given she was educated
  - She had done a bachelor’s in Food science and a master’s in Nutrition
- She felt she should be able to control this
- She suffered in silence, and it probably went on for 10 years

**Was she training during that time?  Did she look as fit as you do today?**

- Peter notes that part of the stereotype of someone with an eating disorder we picture someone with anorexia as incredibly thin
  - Conversely, with bulimia, we usually think of someone whose a little overweight
- Holly was right in the middle
- Probably because of the amount of activity she was doing, it prevented her from being anorexic
- She never got to the point where she was dangerously low body weight
- She was a healthy weight, still training for track, still sprinting
- She had above average muscularity
- She remembers [Les Mills classes](https://try.lesmillsondemand.com/?gclid=CjwKCAjwp9qZBhBkEiwAsYFsb9AxbyhTHt-n3DD2G0adrmOkjiMIwUErTwBwhZqgyTwQXsGVXu8D1hoCkQQQAvD_BwE&gclsrc=aw.ds) at the gym
  - Combat class or kickboxing or body pump
- She was doing some light resistance training
- Her interest in body building didn’t start until much later after college
- She thinks the research on people who suffer with binging disorder and bulimia, they tend to be normal weight to above normal weight

***She was right in the normal, no one would have known***

**Holly attempted suicide at 16.** ***How was this not a wake up call to her parents?***

- It was, but this was also really disappointing and just enhanced the sadness
- Just to outline how incapable her father was of communicating, and he’s not a bad person
  - He lost his mom to breast cancer at age 13
  - He was raised by an alcoholic father with 4 brothers and was beaten
- She remembers her mom being very upset when it happened
- Her dad came into her room and told her, “*You’re a fucking idiot*” and then walked out
  - To have somebody who you thought loved and cared about you say that…
  - He was never somebody that would have had a clue where to start
- Her mother was overbearing and that was the problem, even though Holly knew she was trying to help
- This in combination with the sexual assaults and some things her coach said about her training led to the eating disorder
- Her mom wanted to do everything for her, live vicariously through her sports
  - She understands and has forgiven her
- Her mom tried to get her in tough with the right health professionals
  - But the lack of knowledge, resources and not having good connections… she just didn’t have the tools
- It was about that time that she went away to college
- So the ability of her mom to control and manage what she did with her health was a lot harder
- In some ways, Holly is really grateful that she stepped away from Tasmania and took on opportunities that didn’t require her mom’s support
- Moving away and stepping out from that control allowed her to learn life skills
  - How to step out and take risks
  - How to not be afraid of failure

## Reflecting on her eating disorder, body image, and a wake up call [18:15]

**When you look back, did your self image of your body seem inaccurate with what you know now?**

*Does everyone with an eating disorder also have a skewed view of their body image?*

*Or can the eating disorder simply be a controlled tool unrelated to body image?*

***Holly thinks it’s dysfunctional thoughts***

- She thinks it really depends on the individual
- Each eating disorder is slightly different in its own way
- For her, it wasn’t body image she was concerned about, it was control
- It became obsessive compulsive for some things
- Anytime she felt stressed, anxious, etc, the desire to control came back
- She crafted an environment that shielded her from stresses, potential triggers so she could live in control, and that gave her comfort
- Becoming an adult is a reality check
  - You have to be flexible and noble and pivot and learn to adapt under stress
- She felt like her life was extremely stressful for a lot of reasons

> “*But I just had no coping skills*”‒ Holly Baxter

***It didn’t start as a negative body image.  It was simply the desire for control.***

- As she became more involved in sports, her physique did change
- She started to connect the dots with her athletic performance, superior physique, low body fat, more muscle
- Then the praise she would get externally from people became the obsession

***She became obsessed with how she looked, and that was where she found her self-worth***

- That was where I felt valued and appreciated, and respected
- And for a good part of her life, it became her identity, and that just fueled the disorder

**How do you break that cycle**

- Through a lot of hard work and regular therapy
  - Once every 6 weeks is not enough
- When her mom got her into therapy at age 16, she saw a therapist once every 6 weeks
  - She had to travel from her home in Launceston to Hobart (a 2.5 hour drive)
  - She saw a specialist who worked with women’s health issues, eating disorders and nutrition
  - She remembers this as special time with her mom, feeling that her mom cares
  - Otherwise she never felt like anyone cared about her outside of credentials

**In her post-college life, did she think she had things under control, or did she think of it as a dirty little secret that was totally out of control?**

- It came in waves, like any condition that works along a spectrum
- She had periods where she felt like she was managing the symptoms and feelings
- But as soon as things became stressful, or if she had extra assignments due, or if she needed to work 2 full weekends back to back for financial reasons
  - She just lost it and coped with extreme binging, purging

> “*Secret eating was really something that I struggled with*”‒ Holly Baxter

- She would go out for dinner with friends and try to enjoy herself and partake in the food
  - But because she would restrict so aggressively, anytime she went outside of her 4 walls of comfort foods and things on her list of okay to eat, she was terrified
- She had no control to slow down her eating
  - She ate extremely fast
- Many of her longtime friends as adults have said to her, “Y*eah, you really eat fast, but I’ve noticed a massive change for the last few years*”
- She would eat extremely quickly and almost binge eat
- Then she would order something else to go with the idea of having it tomorrow
  - But she would just go home and binge eat more

> “*It was absolutely spiraled out of control…. The only way I knew how to manage stress was to eat*”‒ Holly Baxter

- And this completely countered her goals for sports and training

**What was the wakeup call?**

- It probably wasn’t until she was 25, she had finished her schooling in Melbourne and moved to the Gold Coast where she opened her own business
- She had a new clinical practice
  - 50% of her work week was in-person training
- She had discovered her love for resistance training
- Her business was crazy busy
- She began to have some success in the bodybuilding space
- She got to a point where her anxiety was so hard
  - She didn’t know what anxiety was and couldn’t put a word to the feeling she had, which sounds silly
- She was stressed with the amount of work she had to do and got to the point in her business where she was experiencing some burnout
- That was the point when she took herself to a therapist
- She ended up admitting herself to rehab
  - She traveled back to Melbourne to a very well known rehabilitation therapy  place in country Victoria
  - This incorporated counseling, yoga practices, different types of relaxation techniques
  - One of the owners worked through nutrition
  - It was an intense 7-day stay

**How difficult was it for her to make the decision to shut down work for 7 days**?

- Terrifying
- The therapy was quite expensive, but it was worth it

## Road to recovery: therapy, meditation, self-compassion, and a breakthrough [27:45]

**How much impact did that 7 days of inpatient rehab have on you?**

- Not as much as she would have hoped
- To think anything that short in duration is going to cure you is foolish

***But, it opened her eyes to the benefits of relaxation, meditation, and the value of communication and being transparent and open***

- These were all behaviors that she was not very good at
- For the period 10 years prior to this, she was very closed off, very reserved and private
  - She didn’t share many things
- She saw the value in what it’s like to work through issues rather than suppress them

***Once she moved to America she got herself into weekly therapy… it got her on the right path***

- She’s had a therapy session every week since 2016
  - She’s only missed maybe 20 weeks through travel and business

**What were the breakthroughs that occurred with that type of more consistent therapy?**

- It made her accountable
- It made her speak, talk, and reflect back on her past
  - Which she had never done
  - She had never given 2 thoughts about her upbringing
  - So much of what she experienced was bottled up in past traumas and different styles of communication
- She gained appreciation and understanding of why she felt the way she did
  - This was incredibly valuable
- She started discussing, “*What are some of the dysfunctions in these beliefs?*”
  - She started deconstructing different sets of thoughts
  - And talked about how they might look differently for a healthy mind
- This was a time of a lot of self development, reading, and finding herself spiritually

***It really helped her to understand that she was enough as a human, she was loved, despite her accolades and sports accomplishments***

- She realized she didn’t need to keep proving herself to all the people in her life
  - This was a huge weight lifted off her shoulders

**Holly’s spiritual awakening**

- She had only been to church once before
  - With a boyfriend whose family was Christian
- Her experience with religion was not negative
- She grew up agnostic
- She went to a progressive, non-denominational church
  - The pastor was incredible
  - Each week, every message was so relatable
  - She got a lot of good information out of it

> “*This is what I’ve been missing my whole life*”‒ Holly Baxter

- For a long time she felt like she didn’t have a purpose
- Part of her decision to keep moving and traveling was to find what was missing
  - She thought, maybe it will be better here
  - Maybe the people will be different and she would resonate with them better

***But it was something inside her that was missing, and going to church and reading was one thing that changed her life***

- Since then, she’s never been happier

**Peter’s takeaway**:

- There are 2 things here that are important for anybody struggling
- 1 – Improvements don’t happen quickly
  - And it’s non-linear
  - The 7 day intensive rehab helped but not as much as she needed
  - It was years until she was in weekly therapy
- When he thinks of his addictions and struggles
- Let’s pick alcohol as an easy example for people to identify with
  - They say an alcoholic is always an alcoholic
  - It’s just a question of if you’re in recovery or not
  - If an alcoholic commits to no longer drinking, they still need to be mindful of their behaviors, and still need to be cognitive of the fact that they can slip back into drinking
  - That doesn’t mean they can’t be around people who are drinking, but they have to understand themselves and understand those limits
- Peter know what his addictions are and how they need to be managed
  - They’re always there
  - You’re in recovery

“*I don’t think that anybody truly recovers, like you said, once an addict, always an addict*.”‒ Holly Baxter

- Holly points out with alcohol, there are physiological symptoms that need to be managed because of the chemical dependence

***But for something psychological, there is a strong need for your desire to change and improve***

- It wasn’t until she committed to herself to never purge again (until she really believed that), that she never purged again
- This happened during a contest prep, one of the most difficult things you could ever do
  - She was getting extremely lean
  - The struggle with trying to control your body and it trying to control you
  - She was sitting on her bathroom floor, bawling, emotionally exhausted, physically exhausted
  - She remembers saying, “*You’re not going to do this anymore*”
  - That’s when things started to change
- She wasn’t going to do this anymore
  - She talked about it with her therapist
  - She wasn’t going to overcompensate with activity
    - If she didn’t purge she would feel guilty and anxious if she didn’t go and do a 10 K run

***Once she didn’t have these outlets, it forced her to get real with her intention for eating***

- It forced her to be mindful, to slow down, to become present with her meals and really listen to what her body was saying
- This is really hard, because if you’ve restrained from certain foods, alcohol, or drugs for a long period of time, all you do is think about that thing
- She would restrict ice cream, cookies, fun cereals, normal foods
  - She just couldn’t control herself around them anymore
  - It was difficult because she felt like she was going crazy
- Years into therapy she asked her therapist, “*Why do I still want to eat the entire tub of ice cream? I feel like I can’t just make myself one serving. I want to eat the whole thing.*”
  - It’s because she restricted for 10 years
  - Her therapist said, “*What makes you think that you’re going to cure this desire overnight when it’s been something that you’ve built a habit that’s ingrained over your lifetime with this disorder?*”
- After this she started having a little more compassion for herself and forgiveness
  - Reducing the amount of judgment she had for herself

***Once she started being kinder to herself, she started to make more progress***

- She hated the outcome of going through that initial transformation because she gained so much weight
- At this point she hadn’t really tackled the underlying cause of why
- She was just trying to stop the binging and purging
- It made her really uncomfortable to see her weight exceed 70 kg (154 lbs)
  - She’s now 63 kg (139 lb)
  - At her peak during recovery she was 75 kg (154 lbs)

**Was the therapeutic instruction, “*****You need to sit in the discomfort of this weight gain?*****”**

- Yes
- This was 1 of the first strategies she had to work through for her anxiety
- At this point she had also developed a social anxiety
- Holly recalls, “*It was just like the lid had been taken off and all these things were immersing themselves in front of me, and I had no idea how to manage them”*
- Now part of that process was discussing the feelings and starting to identify the new feeling she had, now that she’d gained weight
- This led to horrible thoughts about herself
  - *I feel horrible*
  - *I’m disgusting*
  - *This is so unhealthy*
  - *I hate myself*
- Around this time her therapist asked her, “*What would you say to a client?*”
  - Holly was a practicing dietician and had been for 10+ years
- She had to think about what she would say to a client if they said that
- This led her to start treating herself like she would her clients

> “*There was a big shift then, just that compassion that I had for myself*”‒ Holly Baxter

**A shift in thinking, the Rick Elias Test**

- Peter calls this the [Ric Elias](https://peterattiamd.com/ricelias/) test after his friend who describes it as even one step further‒ “*What would you say to your best friend if they were saying these things, if they were in this situation?*”
  - It’s amazing how much this totally changes and softens the tone
- Holly agrees and the first thing that springs to her mind is, “*But what about your physical appearance?*”
  - What does friendship have to do with your physical appearance? Nothing
  - She realized she didn’t have any logical reasoning for believing this was true
  - Clients would say they want to lose weight before a holiday and they catch up with old friends they haven’t seen in a long time or before a wedding or some other special event
  - She asked them, “*Do you think you wouldn’t be invited if you were 10 kg (22 lb) heavier?*”
  - Those relationships aren’t built on your aesthetic, they’re built on your character
  - So when Holly started talking to herself that way, she realized she can still have fun and it has nothing to do with the weight on the scale or her body fat percentage

## The effect of competitive bodybuilding on women [39:00]

- What Peter finds so interesting about her story and so hard to reconcile is her passion for bodybuilding as a hobby
  - In many ways it’s the pinnacle of exercise and nutrition as it pertains to aesthetics
  - And she chose to do it in the drug-free category
    - She doesn’t get to rely on any additional biochemistry
    - She just has to do it through training and nutrition
- It’s been a really long journey for Holly
- There was a point a few years ago where she questioned her decisions to remain a coach and to be in the nutrition and exercise space because of the hypocrisy she felt with what she was coaching
- For the 1st 10 years of her practice she believed she needed to be lean
  - To be successful in business, to support others, she believed she needed to not only talk the talk, but walk the walk
  - She felt uncomfortable that whole time

**What body fat is she on stage?**

- She competed in figure for [IFBB](https://ifbb.com/), which is non-drug tested federation
  - Those girls are 10% body fat
- Now she competes in the fitness category for a different federation
  - It’s a slightly smaller body, but still very muscular and very lean
  - She probably gets down to 10-11% body fat

**At 10-11% body fat, does your menstrual cycle still continue?**

- For the majority of her competition history, it would completely stop
- For about 5 years she didn’t have a period
  - That was even with the return of calories back to a normal amount and the return of body fat back to normal, healthy levels
  - She attributes it to the years of binging and purging
- A lot of people will ask if it is a healthy sport, if it’s dangerous to get that lean
  - And it depends
  - There are a lot of females in the sport that don’t have a desire for a family, so fertility isn’t an issue
- Peter notes, from an evolutionary standpoint, evolution has 1 purpose, to procreate, and she wasn’t fit enough to do this
- Holly notes, “*It’s not a great thing for females to be that lean. We’re not meant to be that lean*.”
- Holly points out that all women don’t lose their menstrual cycle when they compete, but it does become irregular
- In her last competition she was getting a cycle every 2 weeks for about 16 weeks of contest prep, which was really bizarre
- It took her a few years to recover her period through a process of reverse dieting
- A recovery diet allowed her to gain some body fat and have an off season where she got a good amount of calories to fuel her body to the point where her hormones were functioning as they should
- But 50% of women do completely lose their cycle

**If you were to go back in time and talk to yourself when you were 18, would you tell yourself “*****Just stay away from the fitness industry.  Stay away from body building.  Get a degree in economics or business, something like that?*****”**

*Even though you’ve ended up on a path to recovery, do you feel that you were just flying too close to the sun all of this time?*

- She’s asked herself this question a lot
- She is in a place right now where she’s good with herself wherever she is in the spectrum of body fat and in competition (on season/ off season)
- The things that would limit her from getting to the point of obesity or an unhealthy body weight would be extreme habits
  - Taking anything to the limits where you’re just careless with food and exercise
- She doesn’t think she would allow herself to get to that place because it wouldn’t feel good anymore
- She really tries to be conscious of
  - What makes you feel happy
  - What is good for your body
  - How do you feel best
  - Where do you perform best
  - How do you think and function best

> “*A lot of people are not doing the work that is required to shift the why”*‒ Holly Baxter

- This is really important for people that are moving into the space of body building

## Holly’s competition prep and how she guides her clients wanting to improve their physique [46:45]

**A walk through the training and the nutrition for the entire prep for a competition**

- Holly had a contest a couple weeks ago
- 6-months leading up to the contest you have a bulk building phase, then a cutting phase, and then a recovery diet phase
- She is competing at the highest level of professional bodybuilding competition, world federation

But for someone listening, say a woman who wants to look her best at her wedding and wants to do it in a way that’s not harmful

- The process is no different for professional athletes versus your stay at home mom who wants to look good for a girls trip or a wedding
- Holly begins with the goal, “*What do you ideally want to look like?*”
  - Sometimes it’s health goals as well
  - But the majority of people coming to her are looking to change their physique
- A lot of women are terrified of getting too bulky
- The approach comes down to the individual’s definition of what’s bulky to them
- Most of her clients don’t think she’s too bulky

![](https://peterattiamd.com/wp-content/uploads/2022/10/f2-hollybaxter-671x1024.png)

**Figure 2.  Holly Baxter**.  Image credit: [HB Nutrition](https://hbnutrition.com.au/about/)

- A different physique ideal exists for an endurance athlete versus somebody that very anaerobic, so she wants to identify the client’s ideal first
- It’s unlikely that women will get to the point where they look like a female bodybuilder
  - These things don’t happen naturally
  - Her physique isn’t obtained without great genetics, extreme training, and perfect nutrition
- It’s taken her 7 years of consistent nutrition and training to get to her level of muscularity
  - She probably missed less than 10 weeks a year of training in the past 10 years
- You can’t grow muscle like this without some serious consistency

**How does Holly help clients identify their goals?**

- She is pretty granular even compared to their other coaches but the principles at the end of the day are the same
- To get a better understanding of a client’s goals, she will often ask them, “*Is there somebody that you follow on social media or that you’ve seen in magazines that you really like their physique?*”
- She plots a trajectory based on their scale weight and their current body fat % (determined by a [DEXA scan](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry))
  - See [AMA #40](https://peterattiamd.com/ama40) for more on DEXA scans

**What are the limits for a woman who wants to gain muscle?**

- It’s a little lower than for males

***In and 8-week period natural athletes were able to acquire somewhere under 1 kg (2.2 lbs) of fat-free mass***

- This includes increases in skeletal tissue and other things like water
- Peter notes this is his record, in his best year he gained 13 lbs of fat-free mass in 12 months

**Is this the same for men and women?**

- It will depend on the individual and how much time they are willing to invest in this goal
- It comes down to ***training volume and diet***

**What is the largest amount of lean mass Holly has put on in 1 year?**

- She doesn’t know about 1 year, but between 2 competitions she put on about ***6 kg (13 lbs)***
  - The first competition was at the beginning of the year and the second one towards the end of the last quarter
  - This was when she was going to the University of South Florida
  - She was doing [BMR](https://en.wikipedia.org/wiki/Basal_metabolic_rate) testing and muscle fitness testing
    - These are fairly accurate methods of determining hypertrophy
  - This blew her mind, but then she does put on muscle very easily
    - There may be a genetic component to that
  - She was also very regimented with training
  - During this time she also allowed herself to put on a lot of body fat
  - She was also in a position where she could step back from other obligations and priorities to focus on this

**With 6 kg of lean tissue, how much fat tissue was gained?**

- Probably 30%, so 2-2.5 kg (4-5 lbs)
- Her body fat went up a little as she puto n a lot more lean mass
- Peter remarks, “*That’s kind of amazing… If a guy made that change drug-free, that would be considered impressive*”
- Let’s just posit that Holly has great genetics
  - It gives us a range that for women with lesser genetics, they might be able to do half of that in a year
  - They might be able to put on 3 kg (6-7 lb)

**Holly’s training for gaining this amount of lean mass**

- Holly recalls going through a training block of [progressive overloading](https://en.wikipedia.org/wiki/Progressive_overload)
  - The first week of this cycle might have been 3 sets of everything on her list of 6-7 exercises
  - By week 6, she would be pushing 5 working hard sets, high intensity training
    - [REPs (rate of perceived exertion)](https://en.wikipedia.org/wiki/Rating_of_perceived_exertion) of 8-9 of her 1st 3 exercises, then 4 of everything else

> “*The volume I was getting up to was insane*”‒ Holly Baxter

**How many hours was Holly spending in the gym at the beginning of the build phase versus the end?**

- She would hit it hard pretty quickly, early on
- She had a bit more of a reactive style to deloads
  - Normally she would plan intentional deloads
- The whole purpose of this build was to get as much muscle on her as possible in a very short timeframe
- The volume probably went up by 50% within the first 12 weeks and then continued to grow

***The time she would spend in the gym varied from 90 minutes in the earlier part of that build phase all the way to 2.5 hours a day***

- She was doing 5 session a week; it was a big commitment
- She was doing minimal cardio
  - Cardio was not part of the equation
  - But she hit a daily step target of 10,000 steps
- So it was about 15 hours in the gym per week

## Training principles for muscle hypertrophy [57:00]

**Explain what RPE is; this is an important concept as we talk about resistance training**

- [RPE](https://en.wikipedia.org/wiki/Rating_of_perceived_exertion) stands for a rate of perceived exertion
- It’s a measure of training intensity
- And training intensity is one of the principles that needs to be increased over your training lifespan in order to facilitate [hypertrophy](https://en.wikipedia.org/wiki/Hypertrophy)
- Holly reflects back on her early training days and she didn’t even have a training RPE
  - There was no training intensity
- Another measure which she uses on workout builder programs is the **RIR (repetitions in reserve)**
  - An RIR of 3 would mean that you’ve got three repetitions in reserve all the way up to an RIR of 0 (where you’re hitting failure)
  - At a RIR of 0, whatever weight or load you select for your lift, you are essentially going to your drop
- When she first started lifting, the weight was so low, she never challenged herself
- She is grateful for the time she spent powerlifting because that style of training threw her into understanding training intensity and what her true strength was
  - There was a lot of carryover to how quickly she was able to select weights for her bodybuilding style of workouts
  - And that advanced her quickly
- Peter clarifies, “*Just to make sure I understand, you’re saying when you were younger and you were doing fitness training and even training for track and field, you were never pushing yourself in the weight room. Your RPE was below 5, your RIR was above 5.*”
  - Yes
  - She was never given instruction on training intensity
  - It was simply, do 3 sets of 12
- So now when she is in a building phase, when she says RPE 8, this means she stopped when she had only 2 more reps she could have potentially squeezed out
  - RPE 8-9 are near failure sets all the way through

**How would she split those among 5 days? Was it a leg day, a push pull day?**

- #1 is exercise specificity
  - You have to be training in a way that is going to get you to the desired outcome
  - In building muscle, you chose the muscle groups that you want to build in that timeframe
- For her it was glute hypertrophy
  - This is the main area that most women want to improve
  - It has a lot of benefits from normal day-to-day activities (bending down, squatting) to improving strength across all sports
- She focused a lot on glute hypertrophy and shoulder hypertrophy
  - She wanted to create the cap shoulders and the illusion of a  narrower waist
- Thinking back to that build, most of the training she was doing was lower body

***She did 4 lower body sessions per week and 1 upper body session, it sounds crazy***

**For those four lower body sessions, was she still dividing the legs up or was she hitting the same muscles of the legs all 4 days?**

- Her programs varied
- She would triage to give her body the recovery it needed
  - It was a very reactive style of deload
- She would start on Monday doing a quad, hamstring, glute, calf, quad, hamstring
- Her second day might look like‒ glute, hamstring, quad
  - Or she would prioritize the muscle groups she wanted to build
- Then she would have a rest day, because 2 days of back-to-back leg days is pretty intense
- Then she would probably incorporate an upper body session to give herself a second day of complete rest for her legs.
- She would finish out the week by doing a Friday session of lower body
- Then 2 days off, come back in and train on a Sunday, another lower body session
- Holly points out, “*I would never do that for somebody that was brand new to training. That volume would be radically reduced*.”

## Training advice for an inexperienced person wanting to build muscle [1:01:30]

**Training for a person who has some exercise background**

- Say they go to [OrangeTheory Fitness](https://en.wikipedia.org/wiki/Orangetheory_Fitness) twice a week
- They’re a relatively active person, but they don’t have any power lifting experience
- They don’t know the difference between RPE 9 and RPE 5
- But they still have this ambition of building, of putting on 5 lbs of muscle in the next year and losing 3 lbs of fat
- #1 find somebody that can be evidence-based with you in the gym one-on-one

***There is so much value in spending one-on-one time with someone that has more knowledge than you in that space***

- This helps with developing optimal training techniques, developing the right movement pathways
- Another plus is if you can find somebody that does powerlifting or has done bodybuilding and powerlifting
  - There’s not a lot of these people out there

***Incorporating that evidence-based approach with experience with women and powerlifting and bodybuilding, that’s the perfect ideal***

**What is different about experience with women?**

- You have to connect with the person you’re working with
- A male who is extremely experienced in all of those things can be great
- But it helps to have gone through different body image issues
  - To have an understanding and appreciation for body dysmorphia
  - To have an appreciation for the menstrual cycle and the implications it can have on strength, performance, mood, your psychological state, etc
- Holly thinks women tend to do better with female trainers, but they are harder to come by

## Training program for a hypothetical woman wanting to add lean muscle and lose body fat [1:04:15]

**Training program for a hypothetical woman wanting to gain 5 lbs of muscle and lose 5 lbs of fat in a year**:

- So their weight remains the same
- But within 1 year they want their body composition to change dramatically
- Holly’s first question is, “*What realistically can we gain in an 8 month timeframe?*”

***8 months is the period of time you want to build up***

- If this is somebody that has not done a whole lot of resistance training, begin with a fairly low training volume

**Week 1**

- Start by selecting the muscle groups and the exercises that target the areas they want to build, and we would progressively overload that training
- So, it might start with ***1 working set for every exercise*** in week 1
- Typically she starts with a program that is 30-40 minutes maximum
- Do ***1-2 warmup sets*** to get to the working set
  - This will also help with demonstration of technique and understanding the movement pattern
- Start with a set of 10 weighted to a ***RPE of 6-7***
  - This means you’re going to do 10 reps but if your life depended on it you could get to 13-14 reps with the weight you selected
- Start by training 3 days a week
- Holly notes, “*We’ve got to incorporate the person’s ability to sacrifice time for their training*”

**Is it better that she does 1 set of leg extensions, 1 set of leg curls, 1 set of single leg RDL, 1 set of leg press, etc, instead of just doing 5 sets of leg presses?**

- The idea being 1 set of each would give her the education on this, then next you could build on that
  - You’re learning what exercises target certain muscle groups
  - You’re also minimizing the risk of injury or extreme delayed onset muscle soreness

> “*The last thing that you want to do is put together a program that is too difficult and the next day they can’t even walk*”‒ Holly Baxter

- We want to have good adherence from the get-go
- Diversity in the program is also more interesting

**How many days a week are you doing this?  And are you mixing upper and lower body on the same day at the beginning?**

- It doesn’t really matter if you do a lower body or an upper body or a full body training session
- The primary driver of how Holly would put together that workout would be training volume
- What’s more important is a training program you can stick to

**How many weeks are you in that phase?**

- 4-6 weeks
- The decision for 4 weeks versus 6 weeks is the person’s ability to adhere to the same program for that amount of time
- When Holly started she thought it was extremely boring to do the same program for more than 2-3 weeks
  - Even if it was working
- So there’s a lot of personal preference when it come to putting these programs together
- Holly writes her programs for 6 weeks
  - She can handle anything for 6 weeks
- It’s repetitive but you have somewhere between 3-5 programs depending on the individuals experience level
  - So there is still quite a bit of diversity within a 7-day period

**Lower body exercises for a newbie (not a total novice)**

- Her favorites for compound lifts are always going to be the typical powerlifting movements
- Some kind of squat or hinging variation or deadlift
  - The degree of flexibility just with those exercises alone is enormous
- There are so many variations of squats
  - [Heels elevated squats](https://www.youtube.com/watch?v=GPzRf3sfpbU)
  - [Smith machine squats](https://www.youtube.com/watch?v=oBwhrRcNWyM)
  - [Box squats](https://www.youtube.com/watch?v=ZJrUiIprYVw)
  - [Paused squats](https://www.youtube.com/watch?v=gAIJl0eGeKw)
  - [Anderson squats](https://www.youtube.com/watch?v=XXG12P4LmRE)

**If you have a woman who’s never squatted would you start her with a goblet squat, or a back squat to a box squat?**

- The first thing would be a [bodyweight squat](https://youtu.be/ax3eO8xBZVU)
- Holly is looking at the movement pattern to begin with before adding load
- She typically starts with a barbell, her preference is low bar squatting
  - But this depends on the person’s anatomical makeup
  - A high bar squat might be better suited to an individual who has very short femurs compared to somebody with extremely long femurs (like Holly)
- Holly explains, “*For low squatting, and I’m basically leaning over, looking at the ground when I squat, just to clear my hips*”
  - So keeping it basic

*When you say low, high, you mean the position on the trap?*

- Yes, position on the back
- There are advantages of having a low bar squat if you hold a weight plate right in front of you that’s 20 lbs
  - You can probably do it for a long period of time
  - If you extend your arms out, you won’t be able to hold that 20 lb weight very long
- Similar hypothesis when we put the squat bar lower to our center of gravity, we tend to have a little bit more strength and power
  - And that was a big difference for her as somebody that had crazy long levers
  - She was a terrible high bar squatter
  - Her  strength went up 50% by shifting to that low bar position because her femurs are so long
    - She also has a long spine, a very long torso
    - So she wants to bring that barbell back closer to her center of gravity
    - So she’s very low on the back

**Is there any woman you look at and say “*****You’re never going to be a powerlifter, it’s not worth the risk, I don’t want you squatting?*****”**

- This would be somebody with serious injuries
  - A history of hip injury or knee injury
- But her area of expertise is not in rehabilitation
- She normally works in conjunction with a physical therapist or chiropractor

**Do you find women who have never done this kind of intimidated by the idea of that big 45 pound Olympic bar going on their back?**

- Absolutely
- Peter thinks it looks really scary if you’ve not done that before
- Holly adds, “*People’s fear is that the bar’s going to come down on top of them*”
- When you’re first starting, you’re not going to be loading the bar that heavy, but work with the catch bars on
- The [Anderson squat](https://www.youtube.com/watch?v=XXG12P4LmRE) is a technique she would incorporate into a new person’s program
  - You basically start with the bar on the catche
  - You start in a low position, a horizontal position at the bottom of the squat
    - The thighs are parallel to the ground
  - The rep is up, down
    - You push up
  - It’s a really empowering exercise that helps build confidence
  - Holly will do that in conjunction with other squat variations
  - It’s such a big movement
  - You’re using multi-joint, big muscle groups
- Squats are going to help contribute positively to energy expenditure compared to just doing isolation exercises like triceps and biceps

**Holly rarely programs arms for women anymore**

- It depends on their goals
- If they’re a kayaker or something and need arm strength, she will do it
- But for aesthetic reasons alone, when most women get rid of the body fat, they’ve got great arms just by way of muscle engagement during these big compound lifts

**What’s your preferred deadlift?  How do you think about navigating trap bar, versus traditional, versus sumo?**

- This depends on the anatomical structure of the individual
- People that have exceptionally long arms are extremely good dealifters because they basically don’t have to lean forwards very far to have the bar in their hands
- A [traditional deadlift](https://www.youtube.com/watch?v=WAn7OPr2RdE) is painful for her
  - This is feet together
- But Holly notes, “*When I do deadlift, I do sumo because by widening my stance, I can now get lower to the bar and then I don’t have to be so horizontal to get down to reach*.”
- She has an extremely long spine so her deadlift is ugly
  - Technically it looks disgusting, but she’s doing all the right things
  - A little bit of spinal curvature in a deadlift is okay if you’re activating your core and keeping tight
- She prefers a [sumo deadlift](https://www.youtube.com/watch?v=GMQ5wsP9ui8) because it enables her to get closer to the bar and she feels like she’s in a better position to execute

**Peter’s takeaway:**

- Out of the gate, we’re going to take a woman who’s never done these things before and we’re going to program in some getting to know the squat
- Getting to know the deadlift
- You’re going to also include isolation exercise
- You’ll start with the prime movers and the combined [hip hinges](https://youtu.be/Dn3GexXx228)
- And then you’ll move to [leg extensions,](https://www.youtube.com/watch?v=Zlu2BOHPyD4) [leg curls](https://www.youtube.com/watch?v=JeVJowz5rps)

## Lower body lifts: Holly’s approach to leg workouts with clients [1:14:00]

**Where does split squatting and lunging fit in?**

- She will typically incorporate at max, 2 large compound multi-joint exercises
- Usually the 1st 6-8 sets are your best sets
  - They are working sets
  - You start to have diminishing returns from the volume that’s accrued after those 1st 8 working sets
- Holly recommends doing the big movers 1st, isolation/ accessory exercises second
- The way she would structure in something like [lunges](https://www.youtube.com/watch?v=Es49QJkx3JE), or [leg extensions](https://www.youtube.com/watch?v=Zlu2BOHPyD4), or [hamstring curls](https://www.youtube.com/watch?v=oFxEDkppbSQ), or [calf raises](https://www.youtube.com/watch?v=wQhCg0t5xxY) depends on what that person wants to build

***Looking at the total set number, the minimum dose for hypertrophy is somewhere in the range of 10-15 per muscle group***

**When you say per muscle group, are you counting quads distinct from hamstrings, distinct from glutes?**

- Yes

*Distinct from calves?*

- Certain movements do use both
- So often she will count an exercise for 2 muscle groups
- Peter notes, “*A deadlift is going to triple everything. It’s hitting everything. But when you do the leg extension, it only counts for quads*.”
  - Leg curls only count for hamstrings
  - Holly agrees

**So by the end of this workout we want to have 10-15 boxes checked for each of those muscle groups.  What are your favorite exercises for glutes?**

- She was recently looking at a [systematic review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7039033/) on glute hypertrophy using muscle activation as opposed to true muscle thickness testing to measure hypertrophy
- Step-ups were as good at glute activation as hip thrusts and squats
  - Particularly some of the [horizontal style step-ups](https://www.youtube.com/watch?v=e_zx8hSKWek) or lunges where you’re coming across the body
  - Such as a [cross bench step-up](https://www.youtube.com/watch?v=-vmnavyhzVc) where where you are taking the foot down one side and then coming back up
    - There’s a lot of stretch and lengthening taking place in the glute
- Good exercises for glute hypertrophy are a [hip thrust](https://www.youtube.com/watch?v=jQkKeL4Cg8M), a hinge or some sort of bridge, and some kind of [abduction](https://youtu.be/G_8LItOiZ0Q)
  - An *abduction* is basically taking your knees out
  - As opposed to *adduction*, which is bringing them together
  - She’ll find different machines that enable that and also do those on the cables as well with an ankle attachment

**Peter’s takeaway**: *Deadlifts, squats, hipthrusters, step-ups, and abduction.  That’s a lot. You got to get 10.  You don’t have to be doing all of them every time*.

- Holly adds, as the individual progresses over a 7-day training block, they may be working up to 30 sets on each individual muscle group (for someone who is advanced)
  - They may be able to execute that over a 7-day period because of their training frequency
- For a beginner, they may get 10-15 sets with their 3-4 training sessions
- But remember, “*There’s a point where we have diminishing returns where the inflammatory response to that training just makes it impossible to continue making progress, in which case we have to deload*”
- Peter notes that a lot of what she mentioned is going to hit the quads
  - Certainly the squat, the deadlift to some extent, and the step-up
  - RDL wont, abduction won’t

**Will you then add in some dedicated stuff like leg extensions?**

- Yes, [leg extensions](https://www.youtube.com/watch?v=Zlu2BOHPyD4) are a really simple one
  - Minimal set-up, straight on the machine
- She likes different [leg press](https://www.youtube.com/watch?v=7H-KpNTYw_k) variations and different squat variations that get our knee into a position where there’s far more forward knee travel
- There’s a lot of contradictions, she used to hear all the time, “*Don’t put your knee over your toe, it’s dangerous for your knee*”
- Now, if someone’s had a history of knee injuries, that’s something that you would want to take very slowly and very progressively
- But anything where we can get the knee traveling past the toes
  - So by [elevating your heels](https://www.youtube.com/watch?v=GPzRf3sfpbU) in something like a [barbell squat](https://youtu.be/o5WxCJfT6WM)
- Her preference is on a [Smith machine](https://www.youtube.com/watch?v=oBwhrRcNWyM) because it really controls the movement pattern and you only go forward
  - Just so people know, the Smith machine is the squat bar that has the hooks on it that’s in tracks; the path is vertical and it’s controlled perfectly
- There is also foot positioning on the leg press
  - You’re looking to have at the bottom of the movement where your quads are in a lengthened position, you want to have lots of forward knee travel
  - She won’t be specific in where you should put your feet because feet placement honestly depends on the machine that you’ve got access to
    - She’s had some where she’s had to put her feet up quite high because of the movement plane
    - It’s less where the feet go and it’s more where the knees and toes are in relation to each other in the bottom position
- You to work to your level of comfort in getting knees over your toes in the leg press and that’s going to maximize quad development
  - And obviously you’re going to work the back of the leg in the opposite position
- There are a lot of benefits to doing single leg work too
  - This helps with imbalances
- Holly was doing some single leg squats, just sitting to a box, then standing on the box and going to the floor
  - It’s very easy with lots of repeat training, lots of repeating the same movements where we have a bit of a discrepancy
- She likes to incorporate at least 1 single leg exercise for every session
- If you start adding too many single, all-leg movements, your program will end up extremely long
  - So that’s real consideration

**What are some of your favorite hamstring hits?** [1:20:00]

***Holly’s favorite is a*** [***seated hamstring curl***](https://www.youtube.com/watch?v=oFxEDkppbSQ)

- The reason for that is it is better able to isolate your hamstrings than say a prone hamstring curl where you’re laying on your stomach and you’re kind of curling the machine in towards your hamstrings
  - Part of that is just because of the position of the movement
  - When you’re in a seated hamstring machine, you’ve already got tension on the hamstrings because we’re sitting in this upright position
  - It’s a lot more tension on the hamstrings than if you’re in a prone position where your hips are far more open
  - We don’t get the same kind of shortening of the hamstrings, so her preference is to do a lot more volume on a seated machine
  - She’s not saying don’t do any prone work, but she’ll do less of that exercise
- The [hamstring tie-in](https://www.youtube.com/watch?v=OMb1VFQK9Tk) is another exercise she loves for hamstrings and glutes
- You’ll see the bikini competitors specifically have these incredibly tight hamstring attachments to their glutes
  - A lot of that is conditioning
  - Which basically just means getting rid of all the body fat
  - But RDLs (Romanian deadlift) and banded RDLs

**A Romanian deadlift (RDL)**

- A [RDL](https://www.youtube.com/watch?v=0Sd1AZZ77aw&t=127s) a hinging exercise and you’re shifting your hips back to lengthen the hamstrings
- You are loading the hamstrings in that exercise

- You can do it with dumbbells, barbells, or kettlebells

*Does she prefer to do these single leg?*

- She will do both
- For a for a compound movement, if she’s trying to hammer her hamstrings, she probably will start with an RDL because it’s a big, multi-joint movement

*When you do it with 2 legs, are you loading on your back?*

- No, the barbell hangs in front
- When you first start, it’s crazy how quickly you can progress if you work at it
  - She remembers picking up 25 lb dumbbells to do her first set of RDLs (a set of 12)
  - Now, she’s all the way up to 90 lb dumbbells (for a set of 12 RDLs)
    - 90 lb in each hand
    - She would have never thought she could do that
    - She credits her time in powerlifting to help her identify what she is really capable of
- Peter notes, “*What impresses me is not your hamstring strength to do that, but your grip strength to do that. Most men cannot hold two 90 pound dumbbells*.”
  - She’s using grips
  - People will say that’s cheating, but the point of the exercise is to hit your hamstrings
  - So grips are a no-brainer for her

**When you do single-leg, do you do contralateral weight or ipsilateral weight?  In other words, if your left leg is on the ground, are you going to hold the weight in your left hand or right hand?**

- For a beginner, she would do opposing because you’re going to have greater stability
- As you become more advanced, use the same leg, same arm
  - It challenges you in different ways
  - It calls upon different muscle groups to help with stabilizing

**Back to the person who wants to gain muscle and has some experience**

- Over the course of the 2nd or 3rd training mesocycles, they might incorporate the more advanced variation of a single leg RDL
- They might start opposing to leg and then as they advance, move to a single leg over that 18-week, 24-week period

**What are you doing for calves?**

- Originally she wasn’t doing any calf work because from an aesthetic perspective, it’s not something that you see a whole lot of
- 6 sets per week seated or standing
  - For someone who is brand-new, 3 sets
- Research shows [seated calf presses](https://www.youtube.com/watch?v=VHs8aGFjYGk) tends to be a little bit better for hypertrophy outcomes
- There was a [study](https://pubmed.ncbi.nlm.nih.gov/32735428/) she did a post on recently looking at different feet positions
- She used to do toes-in, pigeon toe style calf raises
  - They are pointless and don’t really yield any meaningful results
- Neutral stance and toes facing out tend to do better for optimizing hypertrophy of different aspects of your calf

## Upper body exercises: Holly’s approach with her clients [1:24:45]

- Peter is surprised to hear that she’s not doing a lot of upper body for women
- Instead, losing fat allows the muscles to show

**What do you have women do in 1 day for chest, back, shoulders, and arms?**

- Holly explains, “*One of the main things again that does differ between men and women’s training programs is chest volume*”
- Typically men want to have jacked biceps, triceps, and a big chest
  - For women, there is less emphasis on that
- Women, even in the fitness category seem to be judged on glutes, hamstrings, shoulders, quads
  - Back is less important
- Holly defers to the client for chest training
- She loves the bench press
  - She loves trying to hit a 1-rep max on a bench press
- For her powerlifting is so empowering

**For the woman who has no interest in her strength on a bench but wants to look great in a dress**

- Some people need a lot of chest training or conversely back training to correct their posture
- If they’re hunched forward, [kyphotic](https://en.wikipedia.org/wiki/Kyphosis) and have that rounding, they probably have extremely tight pectorals and weak back musculature
  - Here she would do a lot more volume on the back and probably wouldn’t spend any time on chest work
  - For that 1 final training session, she might have the hit 15 sets of back and no chest
  - She would target wide back, mid back with:
    - [Wide grip pull downs](https://www.youtube.com/watch?v=5gL2XgHghLY)
    - [Wide grip pull-ups](https://www.youtube.com/watch?v=dWB-hEfgMD4)
    - For a beginner, she would start with [assisted pull-ups](https://www.youtube.com/watch?v=5rR_bzBc1NA) and then progress to body weight pull-ups, then [weighted pull-ups](https://www.youtube.com/watch?v=7FjX1RODKzQ)
  - Over the course of 9 months of consistent training, there’s a good chance they could go from doing no body weight pull-ups to weighted pull-ups to reps

> “*I’d say that probably 90% of females would not be able to do a single body weight pull-up*”‒ Holly Baxter

- For pull-ups, Holly’s last AMRAP (as many reps as possible) was 20
  - She used some weight but not a lot
- Peter adds, that [Beth Lewis](https://bodyevolvednyc.com/us/#:~:text=Beth%20is%20currently%20a%20Strength,instructor%20education%20and%20writes%20programming.) is convinced that you can get any human being to do a bodyweight pull-up
- Holly agrees, “*I was that person. I could never do a pull-up. I remember when I first got into lifting, I started with bands.*”
  - She used the thickest green band possible with her feet into it to help her, and she could do about 5 reps
  - She programed pull-ups into every single program for years
  - It was always the most intimidating exercise
  - She hated it, but always put it first
  - She went from not being able to do any body weight to being able to do 20 over the span of 5 years

**Was the progression using less and less resistance on the bands but always targeting a certain rep number for pull-ups?**

- She would pick somewhere in the hypertrophy range, anywhere from 8-12
- Once she could do 12 reps with a certain band, she would progress to the next lighter resistance
- Once she got to 12 body weight pull-ups she added the weight belt with a l little 2.5 lb kettlebell

**How much are you varying your hand position for both yourself and then obviously for the client in this situation?**

- Her goal was primarily aesthetic, she wanted to widen her lats
- So she would use a more prone grip to target her rhomboids more
  - This is a close grip pull-up
  - She didn’t do a whole lot of those
  - Sometimes she would change her variation, if she had 3 sets programmed to failure
    - She would do her 1st set to failure using a wide grip to target the muscle group she wanted to work the most
    - Then she would switch to a neutral grip
    - Then she might switch to an underhand grip

**How much time do you need between sets to failure on pull-ups?**

- A long time, sometimes it would take 5 minutes between sets

> “*I think that’s where a lot of people find themselves not being able to make progress, and not just with pull-ups, but for training in general. They go way too fast*.”‒ Holly Baxter

- ***If you go too fast, you’re not recovered when you start your next working set and so you’re not able to execute the next working set to the same number of reps***
  - Or you might have to switch to a lighter weight
- She used to do this as a trainer on the floor with only 60 minutes with a client
- But you need to slow down your workouts
  - ***Her rule of thumb is to get her heart rate back below 100 beats per minute before thinking about the next set***
  - Males tend to have a slightly lower heart rate than females

**Holly’s take on arms‒** ***If you like arms, do arms. If you don’t like arms, don’t worry about it.***

- Peter finds this paradoxical looking at her arms
- She hasn’t done a bicep curl or tricep extension in 12 months
- So her arms are simply the result of all the stuff she carries
  - Lifting heavy things for deadlifts and RDLs
  - Coupled with getting rid of fat
- Peter adds, “*You can joke and say look, biceps and triceps are not the most functional muscles in the world, but being able to do a pull-up, being able to do a deadlift, that confers great benefit to life skills*”
- In some ways her body building training mirrors more function training than Peter would have expected

**Is Holly genetically inclined to have big muscles in her arms and that’s why she can get away with this?**

- Thinking about her parents, her dad is freakishly muscular for somebody that doesn’t do anything in the gym
  - He grew up doing jobs that require manual labor
  - He’s always been extremely lean
  - He has short humerus (like her) and that creates an illusion of more muscle
    - If you think about a long muscle, it requires much more growth to make it look big
- But she thinks this is possible for other people too

**Shoulder training**

- She does lots of training for the shoulders
- One of her favorites is the [scrape the rack shoulder press](https://www.youtube.com/watch?v=2TXGyv26SaI)
  - You are up against a squat rack with a barbell on
  - You can do it kneeling or standing (she likes kneeling because it eliminates the ability to cheat, when you’re standing you can use a bit of momentum to keep pushing)
  - You’re basically driving that barbell into the rack
  - You’re extended pretty vertically
  - You have to have a good range of motion and mobility for your shoulders
- Another favorite is the [behind the neck shoulder press, on a Smith machine](https://www.youtube.com/watch?v=MWV_2cOVfs8)
  - She doesn’t do this with everybody
  - She does it because she has a lot of mobility with her shoulders
  - She only does it on the Smith machine because it keeps her in a very safe, fixed plane
    - She’s not using dumbbells where she’s swerving everywhere (or free barbells)
  - She likes this one because she’s had some shoulder injuries

**What does she recommend for somebody who can’t really press overhead due to shoulder injuries or impingements?**

- Rehabilitation is not her area of expertise, for this she would work with a specialist
- [Lateral raises](https://youtu.be/b4TJyYBuKqc) are another thing people can do to improve their medial shoulder and rear delts
- You can do a [reverse pec fly](https://youtu.be/MOBQn99Z1T4) where you’re kind of pushing away
- If you have access to cables, you can do a [cable crossover](https://youtu.be/JENKmsEZQO8) to hit your rear delts
- [Face pulls](https://youtu.be/KC8mlDOYJ2I) are another exercise

## Importance of nutrition and protein during the muscle building phase [1:34:00]

- Back to the woman who wants to lose 5 lbs of fat and gain 5 lbs of muscle
- She’s 8 months in and has hit her hypertrophy goals
  - She’s progressed the intensity of all of this, she’s overloaded
- She does another DEXA scan and has gained 5 lbs of muscle

**How much fat do you think has changed at this point?**

- This really depends on diet
- You can go through a period of progressive overload with an intentional building phase and do all the right things when it comes to the resistance training, but the other key piece to the success of that build is diet

> “*How much was the client able to adhere to their dietary requirements during that time is probably 50% of the outcome*”‒ Holly Baxter

- Just to create a stereotype, let’s say she has a reasonable total energy intake but is deficient in protein relative to her goal

**What would Holly’s protein goals be for her?**

- It’s the same for males as females
- The only difference is the absolute total target  for females is a little lower

***To optimize hypertrophy you need to take in anywhere from 1.8 g protein/ kg lean body mass to 3 g/kg***

- This also depends on the individuals dietary preferences and what food they like
  - Some people love protein and for others it’s a real struggle
- There isn’t one number that is better than another, but consistency is important
- You don’t want your protein intake to be bouncing all over the place for a couple of reasons
  - This can potentially reduce or limit your potential
  - It impacts your energy balance because protein has a far higher thermogenic effect than carbohydrates or fat
  - To shift your diet such that 90% of your calories are now coming from protein might shift your energy balance in a negative direction
- Let’s say this hypothetical woman is 140 lbs and she’s okay being 140 lbs in the end but that 10 lb swap in body composition is important (lose 5 lb fat and gain 5 lb muscle)

**Do you basically keep her calories stable and just switch the macros around to increase protein?**

- Initially, absolutely
- Holly would look at what her current dietary intake is and if it’s below the recommended reference range
- She would pick a number that aligned with her lean body mass and her ability to nail that number consistently
- Then progressively through the building phase, she would want to slowly add in calories

**Overfeeding studies**

- There is not as much information available about overfeeding as there is for weight loss
- If you compare somebody who has a surplus of 20% above their maintenance calories versus 40%, versus 60%, you tend to see that the most muscle mass is gained around that 20% mark
  - You see excess body fat gain going up to 40% or 60% above maintenance calories
  - “*It doesn’t continue to get better the more you eat.*”

**If she is eating 2000 kcal coming in, would Holly put her on a surplus even though she doesn’t want to gain weight?  She just wants to gain lean mass.**

- For the initial week, Holly wants to see the data to see if what they are eating matches what they report
- If 2000 kcal was her maintenance calories, that’s not optimal
- She would us a small surplus, 10-20% surplus
- Part of this decision is based on the individual’s comfort with adding body fat
  - This is difficult for females
  - She’s usually working with a more restrictive calorie surplus with females
  - But 20% surplus is optimal
  - Most women won’t adhere to this so she would be more realistic and go with a 10% increase above their maintenance

**How would this change if she was 140 lbs and she wanted to weigh 130 next year?**

- Now she wants to lose 10 pounds of fat
- She doesn’t want to lose any muscle
  - Functionally this means putting on some muscle to offset the fat loss

*Would you then not put her in a calorie surplus during the building phase?*

- Holly would still use a calorie surplus because acquiring that new tissue is going to be energetically demanding
- Now, if somebody is starting with a higher body fat % (they have an energy reserve), and we can petition that stored body fat, she many not need to put them in a major surplus
  - That’s the whole concept behind body recomposition
- This is client dependent
- If they were 20% body fat, she might just have them nail their calories for the next 6 months, and overtime they would see some positive changes because they have enough body fat available to help with building the foundation of that new skeletal tissue

## Changes to nutrition and training during a fat loss phase [1:40:30]

*Back to our hypothetical client…*

- At 8 months in, the hypothetical female is two-thirds of the way to her goal
  - She’s on target for lean mass
  - She has added a little bit of fat mass
- She had 4 months to get that fat off and keep the lean tissue on

**What changes in her nutrition?  What changes in the gym?**

- Changes in the gym are negligible

> “*I think there’s a misconception that suddenly everything changes when you start dieting*”‒ Holly Baxter

- The goal of dieting is to keep as high calories as possible with as little increase in activity as possible, while still achieving a targeted rate of weekly weight loss
- Training may be exactly the same
  - She may do a couple tweaks if they’re bored
- The principles of that training program and structure do not change unless suddenly they decide they no longer want those giant glutes
- From a diet perspective, she picks a target date for weight loss and does a back calculation to pick a targeted, weekly rate of weight loss that does not exceed more than 1.5% of their body weight (per week)
- Peter notes, “*That still sounds like a lot… That could be 2 lbs a week*.”
- You’ve got to be realistic with how much can be achieved in a seven-day period for that person
- When extreme dietary interventions are carried out that push weight loss beyond those numbers, you increase the risk of metabolic adaptations
  - Your self-defense system really ramps up and you become far more efficient
- You want to keep your BMR (basal metabolic rate) nice and high
  - It’s protective of your muscle mass

***Beyond a loss of 1.5% body weight/ week, people start losing a greater % of muscle mass and lean tissue (as opposed to fat)***

- A lot of people will argue with her in the first few weeks, they want to lose weight more rapidly
- She asks them if it would be okay if they lost 2 kg (4.4 lb) but not of it was fat, it was all lean tissue
- You have to be realistic with what you can do in a week and how it might impact muscle loss, and then determine what calorie deficit that actually requires
- There is a wonderful calculation in the book‒ [*The Complete Contest Prep Guide*](https://www.amazon.com/Complete-Contest-Guide-Female-Cover/dp/1726256936/ref=sr_1_1?crid=332KJKS4IR4FT&keywords=The+Complete+Contest+Prep+Guide&qid=1664389114&qu=eyJxc2MiOiIxLjk2IiwicXNhIjoiMS45NCIsInFzcCI6IjEuOTAifQ%3D%3D&sprefix=the+complete+contest+prep+guide%2Caps%2C229&sr=8-1)  also in [*Fat Loss Forever*](https://www.amazon.com/Fat-Loss-Forever-Lose-KEEP/dp/1794510109/ref=sr_1_1?crid=KLR43KOPIW1X&keywords=fat+loss+forever&qid=1664389152&qu=eyJxc2MiOiIwLjg3IiwicXNhIjoiMC41NyIsInFzcCI6IjAuNTQifQ%3D%3D&sprefix=fat+loss+forever%2Caps%2C92&sr=8-1))
  - It outlines what amount of calories is required to lose a certain amount of body weight in grams
  - This can forecast exactly what someone could lose

**Practical applications of calculating calories to lose weight**

*It’s difficult to use a scale to weigh everything, so how do you reach that level of precision without a scale?*

- There is so much value in dedicating time to weighing your food and learning what a 4-oz piece of chicken looks like
  - To learn what X food weighs on a scale and understand what it represents from a caloric perspective and macronutrient perspective
  - Knowledge is power
- It’s a lifelong skill that might take you 6 months to get the hang of
- Holly has been doing this for over 12 years and now she can estimate/ eyeball anything
- She does a lot of accountability coaching, homework tasks, getting clients practical tools and resources to learn how to do this
  - This is part of a client’s weekly check-in

**Let’s say our hypothetical woman is 4 weeks out from the wedding.  Where does she need to be 1 month out to hit her goals?**

- Holly can tell when the client gets within 3-5% of their goal body fat %
  - There’s a lot of photo exchange
  - She collects a lot of data for a client to make an accurate analysis, but there are many benefits of also having pictures
- It’s not always feasible to look at somebody’s DEXA scan every 6 weeks as they are working toward their goal
- So it comes down to tracking their macros, watching their weight trends
  - This coupled with their pictures provides a good picture of what body fat loss is happening

**For this hypothetical woman who is 140 lbs and loses 5 lbs of fat while she gains 5 lbs of muscle, how visible is that change?**

- Probably not as much as you would think

*So maybe this goal wasn’t ambitious enough?*

- For somebody to develop the muscularity of an elite fitness profession is a 10-year process for some people
- So this 5 lb switch is a realistic goal
- But how noticeable it is will depend on where they started and how lean they get at the end

> “*Sometimes the first attempt at fat loss doesn’t get you to the goal*”‒ Holly Baxter

- Often it takes multiple attempts of coming out of this diet process, through recovery diets, and then fat loss again, and then another recovery diet, before we really start to kind of achieve the ideal that that client is wanting

**Let’s say she hit her goal and is pleased.  Now she wants to be even leaner a year from now but doesn’t want to be as restrictive in her diet while she’s on her honeymoon.**

*How does she recover from the work she put in over the past year without undoing all the good she achieved?*

- Some longitudinal studies show what happens with fat loss during a dietary intervention
  - People don’t necessarily have a difficult time losing weight, it’s the inability to keep it off
- Often the reason it is difficult to keep the fat off is because people do things in such extremes
- Maybe they did everything wrong during their diet phase, and as a consequence they’ve lost a lot of muscle mass along with the fat
  - That negatively impacts their basal metabolic rate
  - Now their body’s requirement for energy are a lot less
  - They’re coming up against hormonal changes that impact their appetite-regulating hormones
- Most people experience some form of [hyperphagia](https://en.wikipedia.org/wiki/Polyphagia) or excessive, extreme desire to eat more than is physiologically required by their body after dieting

***So if you’re not conscious of this happening, and not aware of these hormonal changes, the natural inclination post-diet is to go back to what you were doing before***

- This is especially true if you haven’t chosen a dietary approach that works for your food preferences
- This is where a lot of people struggle and say, “*Oh, I’ve tried this diet. It didn’t work, tried this one, it didn’t work*.”
  - They end up going back to what they like

***You can avoid this by slowly reintroducing calories post-diet and, unfortunately, that means that the whole process still feels like a diet***

## A “reverse diet” after a cutting phase to help prevent weight gain [1:49:45]

- Holly relates, as somebody who just finished a competition a few weeks ago, “*I didn’t get as lean, so the hunger response was not as severe as it’s been in the past, but it’s still there*”
- She notes how hard it is to continue to regulate your diet when the goal is out of sight
- After a competition she does a reverse diet
  - This is hard because you’re not getting a positive visual response
  - The change is intrinsic, you can’t see your metabolism improving
  - ***The only evidence of a reverse diet is a small, little increase in calories, something like 100 calories more a week***
  - It takes a good number of weeks to get your calories back to a point where it makes a meaningful difference
  - She can now have a couple of glasses of wine with friends and has been able to have desert again

**How long does the reverse diet last?**

- Rule #1 for setting a reverse diet after you’ve finished being in a deficit is simply finding your new maintenance calories
- You can assess that by looking a how much weight you lost over the final weeks of the fat-loss phase
- For this woman, if her maintenance was 2000 coming in, it’s probably going to be a lot lower
  - Peter thought it would be higher because she has more muscle
  - Holly points out, “*It depends on how lean she wants to get*”
  - If she’s happy to stay at 140 for the next 6 months before she begins her next cycle
  - It depends on her fat-loss phase and how extreme, how much deficit she needed to lose weight
    - Did she do a lot of cardio to create the deficit?
    - What was the intensity of the cardio like?
    - She could have lost some muscle during the fat-loss phase

> “*You will always lose muscle mass when you attempt a fat-loss phase, but the leaner you get, the greater the risk of that muscle loss is, because you no longer have that caloric cushioning to support that*”‒ Holly Baxter

- Her metabolism when we go back to her new maintenance calories, after she’s added more muscle, will require fewer calories than at the start of that reverse diet
- There may be some work that needs to be done reversing to get her back to that 2000 calories she was on
  - She may not be able to go straight back to that
  - It takes weeks

***The way to do it is with slow, incremental increases week-by-week***

- Observe the weight gain and adjust accordingly

## Female-specific training considerations: programming, reps, volume, sex hormones, and more [1:53:15]

**Differences between men and women**

- Men and women may have a preference for targeting different muscles groups
- People may have actually heard somewhere along their fitness journey that women tend to do better with higher rep ranges, and males do better with lower rep ranges
- Part of that is due to differences in sex hormones, and that has an impact on muscle fiber type
- Females have a greater % of [Type I muscle fibers](https://en.wikipedia.org/wiki/Skeletal_muscle#Fiber_types) than males
- The positive consequence of that difference there for females is that it means that we are better able to transport nutrients into the tissues and also clear different metabolites during activities

***The benefit is that women tend fatigable less when it comes to training***

- Women also tend to do better utilizing fatty acids
  - In both the fed and fasted state
  - This means women are less reliant on glycolytic pathways or anaerobic processes
  - This means women do better when it come to recovery

**Holly’s recommendations for women**

- When building a training program, Holly would opt for a little more strength-specific training
- For **strength training**, the rep ranges between 1-6
- The **moderate rep ranges** are called the **hypertrophy rep range** is 8-12 reps

***Holly will use more moderate rep ranges for women and strength training rep ranges for men***

- For **endurance strength training**, the rep range is 15-20 reps
- Some women enjoy endurance strength training, and tolerate it better than strength-based training

***Actual differences in women come down to muscle fiber type, higher levels of estrogen, and more estrogen receptors in their skeletal tissue***

- That’s a benefit for nutrient transport

**Would that suggest that women may have an easier time training without ingestion of glucose, at least in theory?**

- Some women don’t like to train on an empty stomach but other do
  - It’s really subjective

> “*The science can always say certain things, but we’ve also then got to take into account individuals’ perception, and it is very subjective*”‒ Holly Baxter

- Holly has struggled with irritable bowel syndrome for the last 10 years
- She can’t think of anything worse than trying to train with anything in her stomach
- She might have a couple cups of coffee in the morning
- She would rather train hungry than with a full stomach
- The differences may come down to exercise type
  - Endurance training is very different from anaerobic training
  - The resistance training Holly does is more anaerobic
- There has been more information recently on effects of the menstrual cycle on hypertrophy outcomes and strength training
- 4 studies come to mind ([reviewed here](https://pubmed.ncbi.nlm.nih.gov/35471634/)) and half of them show that during the second phase (the luteal phase) of the [menstrual cycle](https://en.wikipedia.org/wiki/Menstrual_cycle) (see the figure below), that strength *decreases* for females during training
  - This is when progesterone is high and estrogen is low

![](https://peterattiamd.com/wp-content/uploads/2022/10/f3-hollybaxter-1024x972.png)

**Figure 3.  Hormone levels during the menstrual cycle.**  Image credit: [By Isometrik on Wikipedia](https://commons.wikimedia.org/w/index.php?curid=8703107)

- When progesterone is low, about 50% of women report feeling a lot better with their training
  - Their performance is better and strength is *improved*

***When it comes to programming for females, as a default Holly will set deloads on or around their menstrual cycle***

> “*I’m guessing that’s something a lot of male trainers don’t think about*”‒ Peter Attia

- So she may upload for 2 weeks then download for 2 weeks
  - This depends on how serious the client is about their progression
- Many things can be impacted by your menstrual cycle
  - Your ability to be adherent
  - Your energy, mood, sleep
  - Constipation is another common symptoms of menes

**How many times has Holly found herself training clients post-pregnancy and menopause?**

- More recently her clientele has shifted to middle age
  - Most of her clients are between 35-65
- The transition from higher levels of sex hormones (testerone and estrogen) to low levels during menopause is really hard on females
- Funny story, Holly’s mom did not know there were symptoms that came along with menopause
  - For her, she was so upset and just frustrated that she didn’t have any energy, or she didn’t want to go for walks anymore, or go to her Pilates classes, or whatever she was doing
- There is so much benefit to getting your hormone levels tested
- Getting somebody back into the normal reference ranges with [hormone replacement therapy](https://peterattiamd.com/caroltavris-avrumbluming/) has huge benefits for their quality of life
  - People are much more motivated to be active

**Does she see a difference in clients (menopausal women) who are not on hormone replacement therapy versus those who are?  A difference in body composition and work tolerance?**

- Absolutely
- Women who aren’t proactive and on some kind of hormone replacement therapy tend to come in with extremely low calorie intake and extreme exercise output
  - It’s like they’re burning the candle at both ends
  - They’re feeling frustrated because the eat nothing, train multiple times a day, and can’t lose fat
- It’s difficult when you’ve been dealing with those negative symptoms for a long period of time
- Naturally, if you don’t feel good, you’re not going to train

> “*People’s quality of exercise goes down. Now they’re losing lean body mass*.”‒ Holly Baxter

- Aging tends to gravitate towards more indulgent foods and a different lifestyle that keeps you less active, unless you’re very proactive about it
- So, people gain a lot of weight during that time
- Holly defers to the experts for hormone replacement therapy but integrates it with the reverse diet to get the client’s calories back up to something that feels manageable

**What about women after they have kids? Is there any difference between a 40-year-old woman who has never had kids and one who has 3 kids?  They’re both premenopausal.  What differences does Holly notice?**

- The first one is simply the time they have for their goals
- Holly has some clients who have all the time in the world to pursue their physique or health goals
  - Either their kids are grown or they never had kids
- For people with children, it’s really hard and this comes back to managing expectations

***There are major differences in what can be achieved realistically***

- This is why looking at someone’s lifestyle is so important
- Women don’t’ give themselves enough credit for the amount of time they spend on these other obligations

**For the 40-year-old mom of 3 who’s got 10 lbs she can’t shed, how important is dietary restriction versus increased activity?  Hormonally, which one is best for her?**

- Peter notes that one of the things his practice doesn’t put an emphasis on is body composition
  - They aim to make patients as metabolically healthy as possible
  - But that won’t necessarily come with an improvement in body composition
  - It won’t take them to their pre-pregnancy weight
- Many of Holly’s clients also want to be healthier but they want to be able to fit into clothes they were wearing 2 years ago
  - That’s tough
- Holly has said multiple times to women, “*You need to get a new wardrobe*”
  - It’s the easiest way to instantly feel better about yourself
  - Once you have clothes that are more flattering for you now-physique, it’s going to improve your mental health
    - You’re not constantly pulling and tugging on clothing, which makes you think about your body
- Is it realistic for somebody to get back to their pre-pregnancy body weight?  Maybe
- But for a lot of women, if you have partaken in some kind of exercise, anything that has applied some kind of load and resistance, you’ve probably added a lot of muscle since you were pregnant
  - So to expect to see the same number on the scale is often not realistic
  - You would have to lose some muscle to get back to that

***Back to the question of differences between men and women, even from a hormonal perspective, there are not many***

- With proper nutrition intervention to optimize metabolism, there is a true adaptation that takes place
  - Through the process of reverse dieting, we want to sit right on the edge of that every week
  - We’re trying to positively adapt and get their metabolism to move up, and that can be done without any changes in lean body mass

***This just means it’s going to take a mom of 3 kids a lot longer to get to their goal***

## Holly’s future in bodybuilding and helping struggling women [2:05:45]

**Does Holly plan to continue bodybuilding?**

- She’s not sure
- Part of her feels compelled to stay in the industry and keep showing up on a yearly basis
  - To be an advocate for people suffering in silence
- So many people have difficulties sharing their struggles, reaching out for help, getting support
- She has seen a massive shift in the type of work she’s doing
  - She is sharing education
  - If you can’t keep making progress or you never really work on the psychological dysfunction it can be a really hard life to live
    - It can be very unrewarding and can feel like, “*What’s the point?*”
- She feels very conflicted about coming back and staying because she doesn’t have the same feeling towards competing anymore
- She no longer desires the leanness
- She can do the process
  - She was worried in this last competition about how it would be without the eating disorder
  - She was worried if she had what it takes to execute
  - It was nerve-wracking, but she was able to do it
- But now she’s no longer attached to the body

***She wants to be an advocate to help people realize what they can do if  they do the work***

> “*I think you can do a bodybuilding show, and not have some kind of eating disorder, but also recognize that it’s an extreme sport, and it requires a lot of sacrifice*”‒ Holly Baxter

- Currently she is so passionate about mental health
- She may potentially step back from everything that she does in the fitness industry and go back to school to do a PhD in the area of neuropsychology or mental health and eating disorders
- She wants to help people
- She knows there are so many women that would benefit from learning that she struggled with all of these feelings and low self-confidence and low self-esteem
  - Learning that there’s another way, aside from calorie restriction and dietary restriction, that can lead to the same positive outcomes and value as a human

## Looking forward: Holly’s focus on longevity, bone mineral density, and wellness [2:08:15]

- Her approach now is all about longevity
- If you had asked her 2 years ago, she would still say, “*Oh, I’m still going to look amazing*”
- Her ideals about what life should be to be truly happy doesn’t involve slaving away in the gym anymore
  - It doesn’t look like being a lifelong competitor
- This doesn’t mean she will let herself go and not have any interest in exercise
- She wants to remain functionally fit
- She thinks her training will gravitate away from the gym some and incorporate more hobbies that keep her active and functioning well
- But she will always lift because she knows the benefits of resistance training

**Are you okay with the changes that will come with that, with not being 12% body fat?**

- Absolutely
- She thinks even in 6 weeks, she will no longer look like she does now
- She’s very content with the idea that she can still be healthy at a much higher body fat %
  - As long as she has muscle mass underneath that body fat

**Protective effects of increased muscle mass**

- Muscle mass is protective in so many ways
  - Reducing risk of bone degenerative conditions like [osteoporosis](https://peterattiamd.com/ama37/)
- Resistance training, anything that applies tension and stress on the bone, to get those little bone-creating cells to ramp up

***Training has given her greater bone density***

- Peter adds, “*That’s kind of the message we give to our patients, both men and women. But I think it’s more important for women to hear because I think sometimes women are a little bit more governed by the scale than by what’s underneath*.”
- Holly’s dad struggles severely with osteoporosis and arthritis
  - He needs a double shoulder reconstruction, and he won’t do it
- Peter is much more concerned about how much muscle mass his patients can put on and how much they can increased the density of their bones than their weight
- If your weight is predominately lean tissue, and you’re maintaining the integrity of your skeletal structure, you’re going to live a better life
- Not to stereotype ladies, but the first thing Holly has women do is let go of some of that identity and belief that they need to look a certain way
  - It’s one thing to feel comfortable and confident
  - But let’s focus on the important things of life
- For Holly, having gone through all of this, she will always be a recovering person with an eating disorder
  - But there are so many other things that are more important to her now
  - Her long-term health is important
- Mentally, she’s probably going to stay active because of all the benefits for mental health

> “*Staying so fixated on the scale and body fat and cellulite, it’s the least of my concerns right now, which is a really weird thing for me to say, as someone that used to feel… unless I stayed lean year ’round, I was not a worthy human*”‒ Holly Baxter

- Holly adds, “*There needs to be a big shift in what we are delivering to our patients and to our clients. Because, if we look at social media, it’s really easy to get engrossed in social media’s thin ideals and filters. And the best step that I ever took was just unfollow all the accounts that are only focused on the aesthetic*”
- She doesn’t look at these social media accounts anymore
- She reads about the things she wants to learn about
- If she wants to feel happy, she has 100 books she’s read on how to change your mind
  - How to be happy
  - What is life’s purpose
  - How to break habits
- This is where she spends her time now
  - She’s looking to optimize herself as a human
  - And this means there’s less need for the aesthetic stuff

§

## Selected Links / Related Material

**Calculation of calories required to lose X amount of weight**:

- [The Complete Contest Prep Guide](https://www.amazon.com/Complete-Contest-Guide-Female-Cover/dp/1726256936/ref=sr_1_1?crid=332KJKS4IR4FT&keywords=The+Complete+Contest+Prep+Guide&qid=1664389114&qu=eyJxc2MiOiIxLjk2IiwicXNhIjoiMS45NCIsInFzcCI6IjEuOTAifQ%3D%3D&sprefix=the+complete+contest+prep+guide%2Caps%2C229&sr=8-1) by Layne Norton and Peter Baker (2018) | [1:43:30]
- [Fat Loss Forever: How to Lose Fat and KEEP it Off](https://www.amazon.com/Fat-Loss-Forever-Lose-KEEP/dp/1794510109/ref=sr_1_1?crid=KLR43KOPIW1X&keywords=fat+loss+forever&qid=1664389152&qu=eyJxc2MiOiIwLjg3IiwicXNhIjoiMC41NyIsInFzcCI6IjAuNTQifQ%3D%3D&sprefix=fat+loss+forever%2Caps%2C92&sr=8-1) by Layne Norton and Peter Baker (2019) | [1:43:30]

**Systematic review on glute hypertrophy using muscle activation to measure hypertrophy**: [Gluteus Maximus Activation during Common Strength and Hypertrophy Exercises: A Systematic Review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7039033/) | *Journal of Sports Science & Medicine* (WK Neto et al. 2020) | [1:16:00]

**The effect of foot position during calf presses**: [Different Foot Positioning During Calf Training to Induce Portion-Specific Gastrocnemius Muscle Hypertrophy](https://pubmed.ncbi.nlm.nih.gov/32735428/) | *Journal of Strength Conditioning and Research* (JP Nunes et al. 2020) | [1:24:45]

**Women’s strength may be less in the luteal phase of menstrual cycle**: [Effects of Follicular and Luteal Phase-Based Menstrual Cycle Resistance Training on Muscle Strength and Mass](https://pubmed.ncbi.nlm.nih.gov/35471634/) | *Sports Medicine* (J Kissow et al. 2022) | [1:57:45]

§

## People Mentioned

- [Ric Elias](https://peterattiamd.com/ricelias/) (survivor of Flight 1549 and cofounder of Red Ventures) [37:44]
- [Beth Lewis](https://bodyevolvednyc.com/us/#:~:text=Beth%20is%20currently%20a%20Strength,instructor%20education%20and%20writes%20programming.) (movement and training coach) [1:27:30]

§

![](https://peterattiamd.com/wp-content/uploads/2022/10/bio-image-hollybaxter-500x500.png)

##### Holly Baxter, APD

Holly Baxter earned a BS in Food Science and Nutrition with distinction and a MS in Dietetics from Deakin University.  She is an accredited practicing dietician (APD), nutrition educator, and founder of [Bia Body](https://bia-body.com/).  She is also a physique coach, personal trainer, and competition coach.  Holly has a strong background in athletics as a successful sprinter in high school and carried this success over into her competitive bodybuilding career. She is a two time world level champion fitness model in the Natural Universe and Natural Olympia competitions (2015) and recently achieved pro status with the WBFF.

Instagram: [hollytbaxter](https://www.instagram.com/hollytbaxter/?hl=en)

Website: <https://bia-body.com>

Contact: coaching@biabody.com