# #311 ‒ Longevity 101: a foundational guide to Peter’s frameworks for longevity, and understanding CVD, cancer, neurodegenerative disease, nutrition, exercise, sleep, and more

**Source:** [https://peterattiamd.com/longevity101/](https://peterattiamd.com/longevity101/)

---

In this special episode, Peter provides a comprehensive introduction to longevity, perfect for newcomers or those looking to refresh their knowledge. He lays out the foundational concepts of lifespan, healthspan, and the marginal decade. Additionally, Peter discusses the four main causes of death and their prevention, as well as detailing the five key strategies in his longevity toolkit to improve lifespan and healthspan. Detailed show notes provide links for deeper exploration of these topics, making it an ideal starting point for anyone interested in understanding and improving their longevity.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/longevity101/the_Drive_public.png)

Play

#311 ‒ Longevity 101: a foundational guide to Peter's frameworks for longevity, and understanding CVD, cancer, neurodegenerative disease, nutrition, exercise, sleep, and more

#311 ‒ Longevity 101: a foundational guide to Peter's frameworks for longevity, and understanding CVD, cancer, neurodegenerative disease, nutrition, exercise, sleep, and more

1x15s30s

0:001:25:25

## We discuss:

- Overview of episode topics and structure [1:45];
- How Peter defines longevity [3:45];
- Why healthspan is a crucial component of longevity [11:15];
- The evolution of medicine from medicine 1.0 to 2.0, and the emergence of medicine 3.0 [15:30];
- Overview of atherosclerotic diseases: the 3 pathways of ASCVD, preventative measures, and the impact of metabolic health [26:00];
- Cancer: genetic and environmental factors, treatment options, and the importance of early and aggressive screening [33:15];
- Neurodegenerative diseases: causes, prevention, and the role of genetics and metabolic health [39:30];
- The spectrum of metabolic diseases [43:15];
- Why it’s never too late to start thinking about longevity [44:15];
- The 5 components of the longevity toolkit [46:30];
- Peter’s framework for exercise—The Centenarian Decathlon [47:45];
- Peter’s nutritional framework: energy balance, protein intake, and more [58:45];
- Sleep: the vital role of sleep in longevity, and how to improve sleep habits [1:08:30];
- Drugs and supplements: Peter’s framework for thinking about drugs and supplements as tools for enhancing longevity [1:13:30];
- Why emotional health is a key component of longevity [1:17:00];
- Advice for newcomers on where to start on their longevity journey [1:19:30]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Welcome to a special episode of *The Drive* where we do something a little different
  - This is an episode that reads more like an AMA where Peter will be answering a set of questions
  - It’s going to be available to everyone, not just to our subscribers
- Typically our episodes are a deep dive conversation, but we get a lot of questions from maybe people who haven’t been listening for long, asking something akin to, “*Where do I begin?*”
- Today’s conversation is really intended to serve as a starting point
  - It’s also a great thing to share if you have a friend who you’re trying to introduce to these topics
- This is a great longevity 101
- We lay the foundation for how Peter thinks about longevity and the structure he applies to it
- Peter explains the various concepts of lifespan, healthspan, the 4 horsemen of death, the marginal decade
- We talk a little about the 5 tactics: exercise, nutrition, sleep, drugs and supplements, and emotional health
- Since the scope of this is a rather superficial treatment of these concepts, the show notes are going to be quite detailed
  - They will point you in the deeper direction of anything that is covered
- If you’re feeling overwhelmed about some of our content, we hope this is an episode that is going to help give some of the foundational information that allows you to then appreciate some of the deeper dives that we are more commonly doing

## Overview of episode topics and structure [1:45]

- This is a special episode focused on longevity where we will go through lifespan and healthspan and touch on the core frameworks to give people a foundation to think about longevity
- As you listen to this podcast, you can think about how these different pieces fit together
- If you’ve listened since episode one, you might not need to listen to this one
  - But it might be an episode you share with someone as an example of what Peter talks about
- We’re going to hit all 5 tactics and answer some basic questions

## How Peter defines longevity [3:45]

**How do you define the word longevity?** [3:45] new section

- It’s a word that gets thrown around a lot, and it means different things to different people
- Peter tends to think of thing mathematically, and longevity is made up of 2 vectors: lifespan and healthspan
- **Lifespan** is much easier to understand because it is discrete, it is binary, it is objective
  - For the most part, you’re either alive or you’re dead
  - Think of it through the lens of a death certificate
  - An edge-case would be an individual who is brain-dead but being kept alive (we could debate whether that person is dead or alive)
- Notice that lifespan says nothing about the quality of a person’s life
- Lifespan is one of the vectors of longevity
- In as much as we want to increase longevity, we presumably want to have something to do with increasing lifespan
- The second vector that makes up this longevity function is the healthspan vector
- **Healthspan** is far more complicated to explain
  - It is far more subjective
  - It is analog as opposed to digital, meaning it is not discrete on, off
  - It is variable
  - Peter likes to think about it as having 3 components: a physical component, a cognitive component, and an emotional component
- In an early version of [*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZc3hWLITcnTc7B2P76ivh285q3LcpZmR8KEgNoEJuv1Zqxeouda-RMCf4k8e11ye-8-8baLYdnwPtSSwii3VQUlQyEAgDd_kSLgVMXkuSNhXa0XZnOvx4niMVZvo7j50qwJLAN-LzVptqJC67rNqR2vj7XvYEnkMkum6F5fYkqOIQareCM3YQ8ABta6croTyXn-WqR2sc6knnGp9Fs3nSWE.zzsFKRXtqKaubUYCWM8sabGF0asdx5aQgMO-2WAD_CU&qid=1717002766&sr=8-1) (not the final version that got published), Peter went to great lengths to describe the cardiorespiratory death as type I death
- Then he went into great machinations to talk about the 3 types of decline in healthspan as physical, cognitive, and emotional death
  - Everybody really pushed back on that (for good reason), and they thought it was a little too morbid to talk about physical death as the death of your exoskeleton and cognitive decline
  - Peter thinks they were right, that death was probably too strong a word there
  - His point was: a person can be robbed of all of those things and still be technically alive, although their quality of life has been sapped
- Thinks of **3 subvectors of the vector of healthspan**: physical health, cognitive health, and emotional health
  - There are ways we can quantify each of these
  - Ultimately people will have their own subjective assessment of what it means to be physically healthy or what it means to be cognitively healthy, or what it means to be emotionally healthy
- 2 of 3 of these subvectors decline with age: the physical and cognitive components
  - That doesn’t mean that everybody’s decline at the same rate
  - That doesn’t mean that for everybody, the decline reaches a level that is “pathological”
- Peter was thinking about this in the gym today, “*Wow, it is really so obvious to me with each passing day that I am completely past my prime physically and cognitively. And I will never again be as physically strong, fit, flexible, free of pain… I will never again reach the pinnacles that I had reached in my late teens and 20s.*”
- Similarly cognitively, he is a moron compared to the person he used to be in terms of processing speed, problem-solving, raw intellectual horsepower
  - Those things are going to decline even further
- Now, there is more nuance to this because there are certain things physically today that he thinks he actually does better than he did before
  - In other words, you take advantage of the fact that as you’re getting less explosive, less powerful
  - You can still maintain strength, and if you learn to move more intelligently, you can actually become more effective
- Similarly, as our intelligence transitions from a more fluid form when we’re young to a more crystallized experiential form when we’re older, we still have remarkable ability to contribute
  - [Peter discussed fluid and crystallized intelligence with Arthur Brooks in [episode #226](https://peterattiamd.com/arthurbrooks/)]
- There’s no denying that on some of the prime levers against which you would evaluate these, we’re in a state of decline
- Conversely, the 3rd part of healthspan (which is emotional health), it actually doesn’t really tie to age much at all
- Depending on how you evaluate it, emotional health almost seems to have a U-shaped curve
  - Not a really big obvious U, but a dip in, I think statistically, probably the late 40s, and then a gradual rising again
- One of the things that Peter always tries to remind himself and his patients is this is something we can really look forward to, provided we do the work: “*I can be emotionally better off in a decade than I am today, and I am certainly better off today than I was a decade ago.*”

***At the highest level, Peter describes longevity as a combination of lifespan and healthspan (comprised of physical, cognitive, and emotional health)***

- If your definition of longevity is “*I want to live to be 200,*” Peter wouldn’t be able to help you

> “*The way I think about it is longevity means how do we live longer? I think that means years longer, a decade longer. It doesn’t mean a doubling of lifespan. And how do we reduce the rate of decline of healthspan?*”‒ Peter Attia

## Why healthspan is a crucial component of longevity [11:15]

**Why do you think it’s so important for someone to not only care about how long they live (the lifespan side), but also the healthspan side of how well they live?**

- First, think of this at the level of a thought experiment
- In the [book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZc3hWLITcnTc7B2P76ivh285q3LcpZmR8KEgNoEJuv1Zqxeouda-RMCf4k8e11ye-8-8baLYdnwPtSSwii3VQUlQyEAgDd_kSLgVMXkuSNhXa0XZnOvx4niMVZvo7j50qwJLAN-LzVptqJC67rNqR2vj7XvYEnkMkum6F5fYkqOIQareCM3YQ8ABta6croTyXn-WqR2sc6knnGp9Fs3nSWE.zzsFKRXtqKaubUYCWM8sabGF0asdx5aQgMO-2WAD_CU&qid=1717002766&sr=8-1), Peter writes about the Greek god [Tithonus](https://en.wikipedia.org/wiki/Tithonus) and how he wished for immortality
  - He was granted his wish, but because he had forgot to ask for eternal youth
  - He became this indefinitely suffering human being who continued to age in perpetuity while his body declined
- Theoretically, anybody who thinks about it for long enough would realize that any desire to live longer has to be accompanied by a desire to preserve healthspan
  - Anybody who thinks they want to live to be 200, implicit within that is the desire to function as someone who is much younger
- Second, healthspan by itself is valuable at any age
  - For your age, to have a better physical body, a better cognitive mind, and better emotional health always exceeds being below your age for these metrics
    - It’s so self-evident, it doesn’t require stating it

*All the things you do to improve your healthspan are “two-fers*”

- Which means you’re getting 2 for the price of 1: when you do all those things to improve your healthspan, you are also improving your lifespan

***Roughly three-quarters of the benefits you can get towards a longer life, come solely from pursuing better health***

- If you never thought once about trying to live a longer life and focused relentlessly on: how can I improve my strength, my endurance, my stamina, and again, all the nuance around these things, my balance, my coordination, my processing speed, my working memory, my emotional health, my happiness, my relationships…
- If you only focused on those things and never once thought about heart disease, cancer, Alzheimer’s disease specifically, Peter still believes you would capture three-quarters of the way towards optimizing your lifespan
  - It’s a bold statement
  - He can’t confirm that that’s exactly correct, and that’s not a studyable question

> “*My conviction is quite strong that pursuit of health span is valuable in its own right, even if it didn’t lengthen life at all. And the fact is, it probably does, and it probably does to a greater effect than all of the efforts that largely medicine 2.0 puts directly into lifespan extension*.”‒ Peter Attia

## The evolution of medicine from medicine 1.0 to 2.0, and the emergence of medicine 3.0 [15:30]

- **Medicine 1.0** is the type of medicine that dominated for virtually all of human existence
- If we argue that *homo sapiens* have been around about 250,000 years from the arrival of our species until the latter part of the 19th century, we were practicing this thing called medicine 1.0
  - Which truthfully wasn’t medicine in the way that we think about it today
  - It wasn’t scientific in the way that we understand science today
  - It was the best that humans could do, missing this tool of inference and relied on a belief about perhaps gods, spirits, humors
  - And to be just blunt, it was largely ineffective
  - The doctor of the past didn’t have any tools, in large part because they didn’t have any understanding of what was going on in terms of disease processes
- It’s not surprising that with medicine 1.0, humans didn’t live that long on average
  - The **median life expectancy** would’ve been into the late 30s or early 40s
  - The **causes of death** were typically related to communicable diseases, infections, and death associated with child mortality and maternal mortality
    - Just the process of having a baby was incredibly dangerous to both the mother and the baby, and obviously, that heavily skews lifespan data
    - Couple that with infections, communicable diseases, and trauma, and most people aren’t surprised that’s pretty much how people died

*After the Civil War and we move into the latter part of the 19th century, a couple of things start to come together*

- The first of these actually happened in the 17th century, but it wouldn’t become germane to medicine until 200 years later: [Francis Bacon](https://en.wikipedia.org/wiki/Francis_Bacon) codifying the [scientific method](https://en.wikipedia.org/wiki/Scientific_method)
  - This is something we take for granted today
  - This idea that you would make an observation (which is what science is all about), you form a hypothesis about why it is happening, you design an experiment that is equipped to test the hypothesis, you conduct the experiment and measure the outcome, and you compare the results of the experiment to the prediction of the hypothesis
  - That is effectively the framework for what science is
- With that as the scaffolding upon which people could begin to make inference, you now layer on some other remarkable discoveries and insights
- The creation of the light microscope, the advent of [germ theory](https://en.wikipedia.org/wiki/Germ_theory_of_disease), and ultimately the development of antimicrobial agents
- The practice of sanitation
- All of these things collectively led to a remarkable change in the trajectory of human lifespan
- It’s so remarkable that if you fast forward 100 years from the late 1800s (which again is a sliver of time across a 250,000-year timeline), **human lifespan approximately doubled**
  - 3, 4, 5 generations to double human lifespan that had previously been unchanged for hundreds of generations is a remarkable feat

***We call this new system of medicine medicine 2.0***

*There’s lots of more nuance to get into medicine 2.0*

- 2.0 ultimately developed even more remarkable statistical tools that allowed for things called [randomized controlled experiments](https://en.wikipedia.org/wiki/Randomized_controlled_trial) (or RCTs, randomized controlled trials), and this really allowed medicine 2.0 to flourish and become supercharged
- For the most part, medicine 1.0 was completely displaced by this
  - Now, that doesn’t mean that there aren’t still some quacks out there that practice witchcraft
- For the most part, when a person has an infection, when a person has congestive heart failure, when a person is in renal failure, when a person has appendicitis and needs to have their appendix removed, when a woman has a complicated pregnancy, ***all of these things now for people who are in the developed world are really easy things to manage using the toolkit of medicine 2.0***
- Medicine 2.0 was and remains an enormous success, and Peter certainly wouldn’t be sitting here talking without medicine 2.0.(he would likely have been dead already, as would you have)

*So why do we need to go any further? Why do we need medicine 3.0?*

- For all of the successes of medicine 2.0, it has indeed had a couple of obvious and notable failures
- The most obvious is that lifespan has largely faltered
  - There really has not been any extension of lifespan beyond that which came from the eradication of the conditions that led to the demise of most people between the Civil War and the end of the First World War

***In particular, the types of diseases that kill people today are very different types of diseases from those that killed people 150 years ago***

- The **leading causes of death** (which Peter describes as the 4 horsemen of death), are the diseases of [atherosclerosis](https://peterattiamd.com/category/diseases/heart-disease-prevention/) (so coronary artery disease and cerebrovascular disease), [cancer](https://peterattiamd.com/category/diseases/cancer-prevention/), the [neurodegenerative diseases and dementing diseases](https://peterattiamd.com/category/diseases/neurodegenerative-disease-prevention/) (so Alzheimer’s disease, Parkinson’s disease, Lewy body dementia, vascular dementia, frontotemporal dementia, all of those diseases), and the slew of [metabolic diseases](https://peterattiamd.com/category/diseases/metabolic-disease/) that, while directly not responsible for an enormous number of lives lost compared to the other categories, indirectly contribute immensely by amplifying all of these
- There are a couple of other things Peter hasn’t mentioned at the population level
  - [Chronic obstructive pulmonary disease](https://en.wikipedia.org/wiki/Chronic_obstructive_pulmonary_disease) is also an enormous cause of death, but its cause is almost exclusively related to cigarette smoking
    - Peter doesn’t really hold medicine 2.0 particularly responsible for the failure of mitigating that
    - That’s really more of a public health question
    - If people don’t smoke, they don’t get COPD, even though COPD is one of the leading causes of death
  - There are, of course, **accidental deaths**, and we can spend some time talking about those later because there’s an enormous spread of what those look like across lifespan and by geography

***In essence, the purpose of medicine 3.0 is to try to address where medicine 2.0 has fallen short; it’s not to replace medicine 2.0***

- From time to time, Peter hears feedback from people who misunderstand the arguments he’s tried to lay out ‒ no where is he suggesting that we need to do away with medicine 2.0

> “*What I argue is that we need to shift resources away from solely focusing on medicine 2.0 to focusing on what we’ll talk about in a minute, which is medicine 3.0.*””‒ Peter Attia

- If we’re putting 100 units of resources today into medicine 2.0, Peter thinks most economists would argue that’s still too many units of economic input
  - In other words, healthcare makes up far too big a section of the economy
- So maybe instead of it being 100 units that go into healthcare, it really ought to be closer to 60 units that go into healthcare
- Peter would argue further, maybe 30 of those units should be aimed towards medicine 3.0 and 30 of those units should be aimed towards medicine 2.0 because when it hits the fan and something goes really wrong, trauma, infection, heart attack, by all means, you want medicine 2.0 there to backstop those things

***Medicine 3.0’s job is to make those encounters with medicine 2.0 less frequent, less severe, and later in life. That is effectively the difference.***

*Medicine 3.0 really has 2 main hallmarks*

- 1 – It is aimed at **preventing** rather than treating chronic disease by acting early, acting aggressively, and tailoring the therapies to the individuals based on the best available evidence
  - Which is not necessarily going to be derivable from randomized control trials
- 2 – **Healthspan** is to be given at least as much effort and attention as lifespan
- This is again another enormous difference between medicine 2.0 and 3.0: medicine 2.0 does not place emphasis on healthspan
  - Its emphasis on healthspan is anywhere from zero to very small, depending on the subspecialty
- There are certainly some physicians whose practices do take them a little bit into the arena of healthspan
- But outside of, for example, physicians or healthcare providers who work specifically in the arena of mental health, again, it’s relatively low
  - Obviously, orthopedic surgery is a discipline of medicine that is more squarely featured in the healthspan arena
  - For the most part, most of the healthcare dollars are spent on addressing and trying to elongate lifespan

***Peter would argue that we need to be putting just as much effort into healthspan as we do lifespan***

## Overview of atherosclerotic diseases: the 3 pathways of ASCVD, preventative measures, and the impact of metabolic health [26:00]

**Talk a little bit about each and what we know about prevention**

*How do you think about our knowledge of those diseases as it relates to someone who is trying to live as long as possible?*

- The **atherosclerotic diseases**, along with the 4th horseman (which is the **metabolic diseases**), are probably the 2 that we have the most insight into as far as what are the pathophysiologic driver
  - And therefore we either theoretically or, in some cases, practically have the best insight into how to prevent them
- [ASCVD](https://peterattiamd.com/category/diseases/heart-disease-prevention/) is a disease that has both a genetic component and an environmental component, but it really doesn’t have much of a component of luck (as far as we can tell)
  - So stochastic processes involving mutations doesn’t seem to play a role
  - There’s just pure causality from the standpoint of environmental triggers and from genetic inheritance
- Both of those factors play through **3 pathways of ASCVD**, all of which are important
  - 1 – Is a lipoprotein pathway
  - 2 – Is an endothelial pathway
  - 3 – Is an inflammatory pathway

*To put this into English, the 3 things that have to happen for atherosclerotic disease are as follows*

- 1 – The first is a molecule called a lipoprotein, which carries cholesterol through the body, and it’s specifically a lipoprotein that has an apoB protein on it
  - Because there are lipoproteins that don’t have apoBs on them, and we don’t have to worry about those
- The lipoproteins that have [apoBs](https://en.wikipedia.org/wiki/Apolipoprotein_B) on them can enter the artery wall when the endothelium is intact, but they do so more prevalently and more easily when the endothelium is damaged
  - The endothelium is simply the lining of cells on the innermost membrane, closest to the artery or outermost from the standpoint of the artery wall
    - The one that is most in contact with the circulation
- If those apoB-wrapped lipoproteins get trapped inside the endothelial layer, a chemical process known as oxidation takes place, and that leads to inflammation
  - What that means is the body thinks something is wrong, and it needs to fight it
    - Just as when you get an infection, a healthy immune system detects the inflammation caused by the microbial agent, and it sends the troops there to get rid of it
    - But in this case, the insult does not come from an infection
    - It comes from the oxidation of the cholesterol contained within the apoB particle as it sits in the endothelium
- That process initiates a devastating cascade of events that ultimately can create so much damage in the wall of the artery that it can lead to a rupture of the plaque, which is the repairing process
  - The rupture of that plaque acutely leads to blood loss and ultimately oxygen loss to the muscles of the heart beyond the point of that blockage
  - That process is known as a [heart attack](https://en.wikipedia.org/wiki/Myocardial_infarction), and about 50% of the time, it is fatal the first time a person has one
- If you want to think about [preventing ischemic cardiovascular disease](https://peterattiamd.com/category/diseases/heart-disease-prevention/), you have to have an insight into all of those things
  - [Peter explains the causes of heart disease in more detail in [AMA #34](https://peterattiamd.com/ama34/))
- You have to be thinking about, “*How do I have fewer apoB particles*,” because the more of those particles you have, the more of them that are going to enter the endothelial space
  - The data on this is as unambiguous as any data are in medicine from [clinical trials](https://en.wikipedia.org/wiki/Clinical_trial), [epidemiologic trials](https://en.wikipedia.org/wiki/Epidemiology), and [Mendelian randomization](https://en.wikipedia.org/wiki/Mendelian_randomization)
    - In other words, you have the only 3 layers of evidence you can ever look to, experimental data, MR, and clinical epidemiology, and they all say the same thing: ***there is a log-linear reduction in ASCVD as apoB goes down***
- 2 – The second thing you have to do is you have to protect your [endothelium](https://en.wikipedia.org/wiki/Endothelium)
- Anything that aggravates and weakens, and makes the endothelium more vulnerable to penetration by apoB is problematic
- The most common factors that we think are doing that are smoking, [blood pressure](https://peterattiamd.com/category/diseases/high-blood-pressure/), and very likely the [metabolic conditions](https://peterattiamd.com/category/diseases/metabolic-disease/) that cluster with insulin resistance, hyperinsulinemia, and type 2 diabetes
  - So some combination of elevated glucose, elevated insulin, and other metabolic byproducts such as [homocysteine](https://en.wikipedia.org/wiki/Homocysteine), [uric acid](https://en.wikipedia.org/wiki/Uric_acid), all of these things serve to weaken the endothelium along with elevated blood pressure and smoking
  - And that creates a greater susceptibility

***It’s not surprising that all of those things pose about an equal risk to cardiovascular disease as does the presence of elevated apoB***

- 3 – The third piece of the puzzle, and the one for which we really don’t do much directly in the way of treatment, is the higher the inflammation, the more likely the higher this is going to be

**Treating each of these 3 pathways**

- We clearly therapeutically address the first 2: we therapeutically lower apoB, we manage blood pressure, we tell people to not smoke, we use exercise and nutrition to manage metabolic health and even pharmacology
- But directly from a pharmacologic standpoint, we don’t really manage inflammation
- We can, there are a couple of agents that are used
  - Somewhat not impressively, and maybe somewhat on the margins impressively

***Most of the evidence around reducing inflammation probably comes from doing things much more broadly around*** [***nutrition***](https://peterattiamd.com/category/nutritional-biochemistry/)***,*** [***sleep***](https://peterattiamd.com/category/sleep/)***, and*** [***exercise***](https://peterattiamd.com/category/exercise/) ***(that we’ve talked about elsewhere)***

- It’s for that reason that Peter often makes a very bold statement, which is **even though cardiovascular disease is the leading cause of death in men and women in the United States, but also in the world, it doesn’t need to be**

> “*It is a very bizarre tragedy that 19 million people a year still die from cardiovascular disease, given how much we know about what causes it and how many tools we have to prevent it*.”‒ Peter Attia

## Cancer: genetic and environmental factors, treatment options, and the importance of early and aggressive screening [33:15]

**You mentioned 2 of the horsemen. How do you think about prevention of neurodegenerative diseases and cancer?**

- [Cancer](https://peterattiamd.com/category/diseases/cancer-prevention/) would be the next most deadly of the horsemen, and here is one where a lot of what Peter said with respect to heart disease is actually quite different
- With heart disease, we really have a pretty clear sense of what the genetics look like
  - There are a handful of genetic things like familial hypercholesterolemia, which is a very, very heterogeneous condition that raises apolipoprotein B, Lp(a) (which we’ll save for another time)
    - We’ve got lots of content on that [see the “selected links” section at the end of these notes]
- When it comes to cancer, we know that there are some really clear and obvious **genetic drivers of cancer** (a handful of genes)
  - Some that many people have heard of, such as [*BRCA1* or *BRCA2*](https://en.wikipedia.org/wiki/BRCA_mutation), which are heavily associated with breast cancer, or [Lynch syndrome](https://en.wikipedia.org/wiki/Hereditary_nonpolyposis_colorectal_cancer), which would be heavily associated with colon cancer and other types of cancer
- But for the most part, when we say that cancer runs in a person’s family, we still aren’t really even able to identify the genes through which this is transmitted
  - It appears to be very polygenic
- Furthermore, while we know of at least **2 significant environmental triggers for cancer**: smoking and obesity
- We actually have very little to say about many other triggers
  - Despite what people would have you believe, we have very little insight about, if at all, specific foods at isocaloric amounts
    - We can talk about an abundance of food because that factors into the obesity trigger
    - But if we’re talking about a bunch of people eating an isocaloric energy-balanced diet, again, despite all of the propaganda around this, “*Oh, red meat this or soy that, or whatever,*” there’s actually just the scantest of evidence to suggest that any of these are promoting cancer in the slightest way

***When you take all of this together, you realize that smoking is clearly driving cancer and obesity is clearly driving cancer***

- About ⅔ of cancers have a very strong tie to obesity (not all cancers)
- If you look under the hood of that, you’ll realize it’s probably not the excess fat per se or the adiposity that’s driving cancer, rather it’s the growth factors that are doing it
  - Obesity comes with more inflammation, comes with more growth factors, such as [insulin](https://en.wikipedia.org/wiki/Insulin) and [IGF](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1), and it seems more likely that those are the things that are actually leading the increase in cancer
- But that leaves a bit of a vacancy in terms of what else explains it
- This is where a scientist like [Bert Vogelstein](https://profiles.hopkinsmedicine.org/provider/Bert+Vogelstein/2777618) and others would suggest that there’s actually just a component of really bad luck here: there are **mutations** that occur
  - Every cancer begins with a mutation, and most of those are somatic mutations
    - That means that most of those are mutations that occur in cells that were developed normally
    - So these are your germ line, the cells you inherited; these were normal cells, but then mutations were acquired
- Mutations fall into 1 of 2 categories: these are either mutations that are tumor-promoting (so [oncogenic](https://en.wikipedia.org/wiki/Oncogene) mutations) or they are mutations of [tumor suppression](https://en.wikipedia.org/wiki/Tumor_suppressor_gene)
  - We have genes that are set out to suppress cancer, and if you get a mutation in one of those, the body loses the ability to suppress cancer
  - And then we get mutations in genes that turn cancer on
  - And again, a number of these are inherited, but many of them, most of them are acquired
- The what is vexing us still, and the best working hypothesis is that bad luck plays a lot of role in that
- It would be a topic for an entirely different podcast to look at other things that may be triggering those mutations
  - In some cases, we know that viruses play a role in those mutations

***What Peter is really talking about is where do the majority of these mutations come from? That’s an area of huge interest.***

**The other problem with cancer that also is not afforded to cardiovascular disease is the treatment options that are less effective**

- A person today who has advanced cardiovascular disease has a much better prognosis than a person today who has very advanced cancer

***A person today with stage IV, metastatic endothelial tumors has about the same 10-year survival as a person did with that tumor 50 years ago***

- So that means a solid organ tumor like breast, lung, pancreas, prostate, colon, one of the, quote-unquote, “bread and butter tumors”
- A person today who has one of those cancers that has spread from its original site to a distant site: that’s metastatic or stage IV cancer
- They have a much longer median survival
  - They will live longer
  - They might live for 5 years instead of 1 year
- But they’re not cured at any higher rate, and obviously, that’s a discouraging statistic

> “*As we think about cancer, we obviously think the first and most important thing is to do everything you can to avoid getting it.*”‒ Peter Attia

- But as Peter alluded to, that playbook is not as thick as the don’t get heart disease playbook
- And that leads to a very controversial thing that I talk about, which is the **importance of early and aggressive screening**
  - We’ve already devoted tons of content to the arguments for and against that approach, but hopefully this explains why that is still a position Peter holds

## Neurodegenerative diseases: causes, prevention, and the role of genetics and metabolic health [39:30]

**Alzheimer’s disease is something we get asked about a lot. How does that look in terms of what you discussed on cancer and cardiovascular disease as it relates to prevention?**

- It’s a little bit in the middle
- In other words, Peter thinks we actually have a slightly better sense of some of the causes
  - Not in all cases, but certainly, with [Alzheimer’s disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease), we are getting a much better sense of which people are susceptible, what genes play a role from a genetic susceptibility standpoint
    - And genes do play a pretty big role there
    - And we also understand the other factors
- There’s a very simple but surprisingly accurate adage which states, “*What’s good for the heart is good for the brain*,” and study after study after study have demonstrated the following

***Every intervention that we take to lower the risk of atherosclerotic cardiovascular disease also reduces the risk of dementia***

- And that means Alzheimer’s disease and vascular dementia (which are the two main ones), but also other forms of dementia
- That means having better metabolic health, having lower apoB, having lower blood pressure, not smoking, those things dramatically reduce your risk of cardiovascular disease, and they dramatically reduce your risk of Alzheimer’s disease
- An area where dementia has an even bigger positive impact in intervention than cardiovascular disease is with that of [exercise](https://peterattiamd.com/category/exercise/)
- So it’s no surprise that exercise improves a person’s odds of not getting and/or surviving cardiovascular disease, cancer, dementia

> “*I would say that the evidence for the benefits of exercise are both greater in magnitude and greater in confidence when it comes to the prevention of neurodegenerative disease.*”‒ Peter Attia

- It’s interesting because many people fear dementia more than any other condition, and there are very obvious reasons why that would be the case
- And it might be that in Peter’s practice, we’re a bit more optimistic than most based on just the nature of what we do and the types of people that are in our practice
  - Meaning people who really study prevention and really look at these early, early signs of dementia and look at how specific interventions can make a difference
- Unfortunately, the flip side of that is that of all the chronic diseases, the dementing and neurodegenerative diseases are the ones for which we have at this time virtually no viable therapeutic options
- So the real name of the game with neurodegenerative diseases (specifically the dementing diseases) is that avoiding them is the 1st, 2nd, and 3rd priority on a list of 3 priorities
  - The only other one Peter will really mention here briefly is [Parkinson’s disease](https://en.wikipedia.org/wiki/Parkinson%27s_disease) because it’s the most prevalent movement disorder
- Once we get into treatment land it’s not very promising (at least at this point in time)
- These are both diseases where having as high a reserve as you can make a big difference
  - [discussed further in [episode #236](https://peterattiamd.com/kellyannniotis/)]

***The higher your cognitive reserve and the higher your movement reserve, the more resilient you are to the effects of these conditions***

## The spectrum of metabolic diseases [43:15]

**We shouldn’t ignore the 4th horseman: the spectrum of metabolic diseases**

- Along with cardiovascular disease, we really have a pretty clear sense mechanistically of what’s driving this

***This appears to be primarily a consequence of overnutrition***

- Energy imbalance is really the driving factor of insulin resistance
- And insulin resistance is really the driving factor of the downstream effects that ultimately lead to everything from [fatty liver disease](https://en.wikipedia.org/wiki/Fatty_liver_disease), [type 2 diabetes](https://en.wikipedia.org/wiki/Type_2_diabetes)
  - These diseases, in their own right, are quite harmful and devastating

***The real danger of them is the effect that they’re having on the other 3 horsemen, where they’re increasing your risk by 25-50% ‒ they really are gasoline on the fire of the other diseases***

## Why it’s never too late to start thinking about longevity [44:15]

- We just talked a lot about the importance of prevention
- If anyone younger is listening, hopefully it encourages them to play that longer game

**What would you say to the person who is thinking, “*****I wonder if it’s too late for me to start thinking about my longevity?*****”**

- There’s the theoretical answer and the practical answer
- The theoretical answer is, look, while you still have breath in your lungs, it’s not too late to do something
- But we’re also all in a car driving towards the edge of a cliff
  - It’s a lot easier to slow the car down and make sure that you either avoid the cliff altogether or, at a minimum, slow your route to the cliff’s edge dramatically if you begin the slowing process before you get there
- In other words, everybody understands that when you see a red light, you have to be applying the brakes before you reach the actual light
  - So at some point, it is very difficult to back out of a situation
  - But Peter also thinks that that’s the rare exception and not the rule
- Peter has written in the [book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZc3hWLITcnTc7B2P76ivh285q3LcpZmR8KEgNoEJuv1Zqxeouda-RMCf4k8e11ye-8-8baLYdnwPtSSwii3VQUlQyEAgDd_kSLgVMXkuSNhXa0XZnOvx4niMVZvo7j50qwJLAN-LzVptqJC67rNqR2vj7XvYEnkMkum6F5fYkqOIQareCM3YQ8ABta6croTyXn-WqR2sc6knnGp9Fs3nSWE.zzsFKRXtqKaubUYCWM8sabGF0asdx5aQgMO-2WAD_CU&qid=1717002766&sr=8-1) about individuals who are in their 70s before they take their first committed step towards health
  - And these are individuals that, in their 80s now, are doing better than they were in their 60s from a health perspective, from a movement perspective
- For that person listening, wondering if it’s too late

> “*I would say it’s not too late*.”‒ Peter Attia

- You’ll have to make concessions
- You need to start slower
- You need to make sure you’re not getting injured
- There’s an entire playbook, and we actually have a podcast [[#307 – Exercise for aging people](https://peterattiamd.com/exerciseforagingpeople/)] around what would an exercise program for the elderly look like
- Peter adds, “*But I definitely would be very disappointed if anyone thought I was communicating that once you reach a certain age, it’s all bets are off.*”

## The 5 components of the longevity toolkit [46:30]

**List the 5 tactics in your “longevity toolkit”**

- Peter lists things in buckets, and he wouldn’t say this is collectively exhaustive
- There are other things that he thinks don’t warrant a bucket in his view, or maybe he should come up with a 6th bucket that he would put every other thing into

***The big 5 buckets are: nutrition, exercise, sleep, pharmacology, and emotional health***

- We could talk about a 6th bucket, which would be pollution, radical temperature exposure, behaviors to avoid harmful accidents or automotive accidents, things like that
- He mostly talk about the first 5

## Peter’s framework for exercise—The Centenarian Decathlon [47:45]

**This framework of the “centenarian decathlon” gives some grounding and foundation to how you think about exercise compared to how others may talk about it**

- [[Episode #261](https://peterattiamd.com/training-for-the-centenarian-decathlon/) explains the centenarian decathlon]
- **Exercise is Peter’s favorite bucket** because he thinks the data are very clear that exercise, if leveraged to its capacity, has a greater impact on your lifespan (remember, that’s the how long you live piece) and your healthspan (that’s the how well you live piece) than any of the others
  - With the only exception potentially being emotional health
    - There’s clearly going to be the case of the individual whose emotional health is in such ruins that until that is addressed, no amount of physical health matters. And in fact, anything else is just prolongation of agony

> “*Exercise really is the king of interventions.*”‒ Peter Attia

- The centenarian decathlon is one of Peter’s favorite topics, and people who have read the [book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZc3hWLITcnTc7B2P76ivh285q3LcpZmR8KEgNoEJuv1Zqxeouda-RMCf4k8e11ye-8-8baLYdnwPtSSwii3VQUlQyEAgDd_kSLgVMXkuSNhXa0XZnOvx4niMVZvo7j50qwJLAN-LzVptqJC67rNqR2vj7XvYEnkMkum6F5fYkqOIQareCM3YQ8ABta6croTyXn-WqR2sc6knnGp9Fs3nSWE.zzsFKRXtqKaubUYCWM8sabGF0asdx5aQgMO-2WAD_CU&qid=1717002766&sr=8-1) understand what this means
- But the purpose of this podcast is to get someone new to this up to speed

*The centenarian decathlon is an idea that came to Peter in the summer of 2018*

- It’s an idea that occurred in an instant, but it was really he result of 4 years of suffering
  - The suffering started at the end of 2014 when he decided to stop competitively cycling
    - Not only did he stop cycling, but he was not going to go back to any other sports
- All he wanted to do was exercise for the sake of exercise, and this was a foreign idea because from the age of 13 until that point in time (in which he was 41 or 42), he had never trained without a specific purpose
- Now for the first time ever he was wondering what he should do in the gym today ‒ it was a totally rudderless existence
- It stayed that way until the summer of 2018 when he was at the funeral of the parent of one of his best friends
  - Apologies for repeating this, because he wrote about this in the book
- At that funeral, he realized that while his friend’s mom had died at a relatively old age (about 89), her physical life had demised so significantly in the past decade that her actual death was almost just a matter of formality
  - She had lost the ability to do the things that mattered to her most a decade earlier
    - She couldn’t play golf any more because of her shoulder
    - She couldn’t garden because of her knees and hips, and back
    - She couldn’t even play with her grandkids
  - She spent most of the last decade of her life largely uninvolved in anything and did come down with dementia in the final year of her life, and that’s what ultimately took her life
- Peter was totally blown away by this person that he once remembered as being completely vibrant, losing everything, and spending this last year in this state
- He realized in that moment, as he literally sat in a church pew: first of all, this is really common, and secondly, this is what he wants to train for
  - For the first time in 4 years, he realized, “*Aha, the thing I want to train for is to avoid this. I want to come up with an athletic event that will be done at the end of my life, and everything between now and then will be training for it.*”

***Peter came up with this idea called the centenarian decathlon, not because it implies that one has to live to a 100 to compete, or not even to imply that it has to have 10 events, but simply as a mental model to say, what are the most important activities, both activities of daily living and activities of performance, that I want to be able to do at the end of my life?***

- Peter explains, “*And that has become obviously a huge obsession of mine.*”
- How well can I define them?
- How well can I understand the physical traits that will be necessary to execute them?
- Then how much can I reverse from there (or backcast from there) what I need to be doing today to increase the probability of doing those things tomorrow to the highest level?
- Peter with a couple of other folks has started a company around this called [10 Squared](https://10squared.com/), which is geared towards training people to do this
- The best model for how to train if your goal is not something very specific
  - If you’re training for a jiu-jitsu tournament coming up in 6 months, that’s a very specific type of training you need to be doing to compete there
  - Peter’s wife is running the Boston Marathon next year, and she wants to run a certain time
    - She will will have nothing to do with training her Centenarian Decathlon
    - She is going to be doing very, very specific running workouts to make sure she hits her goals
- Ultimately, what people really want to be training for is to be the most kick-ass versions of themselves in the last decade of their life
  - If that means you’re 80-90 years are functioning like you’re a really good 70-year-old, that’s a totally different experience from what most people go through

**Let’s say someone is focused on training for the centenarian decathlon. What are the 4 components you think are important?**

*1 – It starts on the foundation: you have to have* [*stability*](https://peterattiamd.com/peter-on-stability-the-foundation-of-the-4-exercise-components/)

- You have to have the chassis and the tires
- You have to have every aspect of the motor control, coordination, ability to dissipate force, ability to receive force, ability to balance
- There’s so much that goes into stability that it got a full half-chapter in the book
- It’s far and away the most complicated to explain, but it’s really obvious to see it when it’s not there

> “*Every one of us is lacking in stability, and it was the biggest reeducation for me as I pivoted to this way of training.*”‒ Peter Attia

- It’s everything from learning how to appropriately pressurize your intra-abdominal space to how to unlock your ribs, maintain an appropriate center of gravity, how to be able to isometrically contract muscles as necessary, how to be able to do it under control, how to have good foot mechanics
- Peter has dedicated podcasts on this because each component of this stability game is quite nuanced [see episodes [#131](https://peterattiamd.com/bethlewis/) and [#152](https://peterattiamd.com/michaelrintala/)]

***And the good news is, while most of us show up to the middle part of our life with enormous deficits here, they’re all retrainable. We’re actually still quite plastic in our old age.***

*2 – The 2nd component is strength, and a subcomponent of strength is power*

- Even  though we lose power very quickly as we age, the more we can maintain it, the better
- And you can’t have power without strength and stability

*3 – The 3rd and 4th components are part of a continuum of cardiorespiratory fitness*

- Peter talks about this as being a triangle [see the figure below]

![](https://peterattiamd.com/wp-content/uploads/2024/07/f1-longevity101.png)

**Figure 1. The size of the fitness triangle relates zone 2 to zone 5 training**.

- The **base of the triangle** is the aerobic efficiency, and this is the maximum fat oxidation
  - This is your all-day pace
  - We want that to be as wide as possible
- The **peak of the triangle** is the [VO2 max](https://peterattiamd.com/category/exercise/vo2-max/)
  - That’s most adequately thought of as the engine size; that’s the peak aerobic output
  - [You want that to be as tall as possible]
- One of the exercises Peter does with both his patients and clients in [10 Squared](https://10squared.com/) is once you have a person’s Centenarian Decathlon goals, you break them down into what is required
  - We can take that list and we can say, “*Oh, this requires a VO**2* *max of 31 milliliters per kilogram per minute; this requires an ability to sit this way; or this requires this much strength in this domain; this requires this type of hip loading, etc.*”
  - Then we can evaluate where a person is today and then say, “*Okay, well, obviously today you can do all of those things, but here’s the predicted trajectory of decline on each of those things, and will you be above your benchmarks in 40 years or will you be below them?*”
- And for most of us (Peter included), at least on some of those dimensions, you’re actually considerably below them at your target, and therefore you have to raise the performance currently to make sure you hit the targets in the future

For more information, see links to podcasts, articles, etc. in the “selected links” section at the end of these notes

## Peter’s nutritional framework: energy balance, protein intake, and more [58:45]

- Peter doesn’t necessarily think about nutrition as some people talk about it, which is this diet is best

**Walk people through your framework and how you assess nutrition and where someone is at in their nutritional state**

- Nutrition is a very complicated thing to study; it’s the messiest of all the pillars
  - Probably even messier than emotional health, although maybe that’s debatable
- For that reason, there are very few things that can be stated in this field with a high degree of certainty

> “*The challenge in nutrition is you have a lot of people that speak with such insane conviction, and they talk about something as though it is absolutely correct, even though if you were putting an error bar on their statement, it would dwarf anything they’re saying.*”‒ Peter Attia

- And truthfully, Peter has been guilty of this
  - 12 years ago he was talking about nutrition with a level of certainty that he doesn’t think was warranted
- And so, as the adage goes, “*The further you get from the shore, the deeper the water*,” and in Peter’s old age, he’s actually quite far out from the shore, and he realizes the water is awfully deep out here

***There aren’t a lot of things that can be stated at a high enough degree of certainty that you should act on them with almost blind faith***

*There are 2 things Peter can tell you with a very, very high degree of certainty*

- 1 – The single most important input from nutrition to a person’s overall health is **energy balance**
  - Stated another way, the energy input of food is the first-order determinant of health
  - The total calories you consume would be the most important thing, not the only thing
    - He does not want to suggest that a thousand calories of Tic Tacs is the same as a thousand calories of broccoli (it is not)
    - He is also talking about this through the lens of common sense,  and the truth of it is, if you subside on a diet of Tic Tacs, you’re going to eat a lot more than a thousand calories of them because they’re not satiating and they’re junk, and they’re hollow

***Peter wants to be very clear that the primary input is total energy, but it is also impacted by many other things, including diet quality, processing, and macronutrient distribution***

- 2 – The second thing that is abundantly clear is that [protein](https://peterattiamd.com/category/nutritional-biochemistry/protein/) is the macronutrient we should be least flexible on
  - Stated another way, we can be quite flexible on how much carbohydrate and fat we consume to fill our energy needs, but because protein is not consumed for the purpose of ATP generation (which is the principal reason we consume carbohydrates and fats, although fats are also essential for some structural purposes), we cannot be too flexible or compromising in our protein requirements
  - In other words, if you really wanted to just come up with a single number to give people, I would say on average, about **1.6 grams of protein per kilogram of body weight should be consumed by everybody**
    - Peter hates saying that because there’s truly nothing you can say across the board
    - There are clearly people who, based on what they’re eating, will need more protein
    - And there are probably people who can get away with a little bit less
    - If you took a perfectly high-quality [PDCAAS](https://en.wikipedia.org/wiki/Protein_digestibility_corrected_amino_acid_score) 1.0 protein in a person who’s not that active, they could probably get away with 1.2 g or even 1.0 g, but anything below that and you start to really miss out
    - \*\*As you age, those requirements go up due to anabolic resistance [discussed in episodes [#299](https://peterattiamd.com/lucvanloon/), [#227](https://peterattiamd.com/ama40/), & [#224](https://peterattiamd.com/donlayman/)]
- We can talk all day about every diet under the sun and every religion, and every faction of every religion around every dietary tribe, but the truth of it is, it’s really hard to find an actual nutrition scientist
  - He’s talking about actual people who work in labs doing nutrition who will disagree with that statement
    - There are some, but they are in the huge minority
  - And interestingly, they tend to avoid using human data when they talk about those things
- When you limit yourself to experimental data on humans (not rodents), 2 things seem to matter the most
  - 1 – How many calories are you getting? (not too little, not too much)
  - 2 – Are you getting enough protein?
- Obviously, there are other terms
  - We certainly want to make sure you’re getting enough micronutrients as well and that you’re avoiding toxins
    - That tends to be less of an issue today than it was a hundred years ago
    - Of course, that’s also really interesting
- When Peter is looking at a patient, given how important those things are to him, it makes sense to be evaluating those things at the outset

**A DEXA scan can help you answer 3 questions**

- 1 – Are you overnourished or undernourished?
  - And that really comes down to energy balance
  - How much fat do you have on your body, and how well is it distributed throughout your body? Where is it distributed?
- 2 – Are you adequately muscled or are you undermuscled?
- 3 – Are you metabolically healthy or not?
- A [DEXA scan](https://peterattiamd.com/improving-body-composition/) will show how much subcutaneous fat someone has, how much visceral fat  and how much muscle mass
- We can do a lot of advanced blood work and see how metabolically healthy they are
  - How well they dispose of glucose, all these other things

***When you can answer those 3 questions (which you can in a very short period of time with a relatively small amount of data), that tells you: does this person need to eat more, less, or the same total energy, the same amount of protein or less, and how important and what type of exercise should they be doing to augment our findings***

- Because we’re talking about nutrition, Peter will close this out by saying that when most people do this, they come out slightly in the **overnourished** category
  - That’s just another way of saying most people are overweight or obese
  - The numbers are probably 70% of the population are overnourished or significantly overnourished
- Therefore, most people, when you go through that whole treatment algorithm, are going to be in the “I need to eat less” camp

**If you are in the “I need to eat less” camp, you now have 3 ways to do that (3 strategies)**

- 1 – Directly **reducing caloric intake**
  - That says, agnostic to what or when I eat, I will simply eat less
  - This is the most direct way to do it
  - It has lots of pluses and minuses, which have been discussed in so much detail on other [podcasts](https://peterattiamd.com/mattkaeberlein3/) [see more in the “selected links” section at the end of these notes]
- 2 – The 2nd method is **dietary restriction**: something or some set of things in the diet that I will remove from the diet, and I will restrict them
  - The more restrictive the elements of your diet, the more effective this technique is
    - If you only choose to restrict lettuce, this will have no effect
    - If you restrict everything but potatoes, meaning if the only thing you allow yourself to eat is potatoes, this will have an enormous effect
- 3 – The 3rd strategy is **time restriction**, where you limit the window in which you eat
  - The narrower and narrower that window, the greater the likelihood that you will overall induce a caloric deficit
- There’s a lot more Peter can say about nutrition
- We could get into the nuances of which type of fats are better: saturated fats, monounsaturated, polyunsaturated fats
  - Is a Mediterranean diet more efficacious than a low-carb diet or a low-fat diet?
  - He’s [written](https://peterattiamd.com/is-a-mediterranean-diet-best-for-preventing-heart-disease/) and [spoken](https://peterattiamd.com/ama21/) about all of those things
- But from the standpoint of what are the most important things, Peter think’s you’ve got it

Nick asks, “*Have you remembered what you ate for lunch yet? That’s, I think, the only thing from the nutrition conversation that’s missing*.”

- Peter scarfed down some leftover spaghetti squash, had a container of blackberries and some venison

## Sleep: the vital role of sleep in longevity, and how to improve sleep habits [1:08:30]

- [Sleep](https://peterattiamd.com/category/sleep/) is something Peter has written about, were he takes it much more seriously now than he used to in the past

**Talk about why you think sleep is such an important component of not just lifespan but also healthspan**

- The data really make the case more compellingly than Peter needs to
- Fortunately, short-term sleep deprivation is easy to study, and it unequivocally demonstrates a remarkable negative impact on cognition, on physical performance, on physical markers of health, such as insulin resistance, on appetite

> “*Everything that can go wrong in the human body goes wrong when you are sleep-deprived.*”‒ Peter Attia

- What’s nice about this is you don’t need to do 5-year studies to figure this out
  - You can do 2-week, 3-week studies where you take people down to 4 hours a night of sleep and you can absolutely destroy them in every physiologic measure during the wakeful period of their lives
- We can then extrapolate from there that if you’re only sleeping 5.5-6 hours a night, you’re probably not getting as much of the negative effects
  - But when we see and measure other effects that are negative, to a lesser extent, it seems pretty easy to attribute them to the reduction of sleep
  - In other words, when you look at a person who’s not sleeping as inadequately as people are typically studied in short-term studies geared towards identifying the risks, they get many of the same problems, but just not as extreme, **suggesting there’s a dose effect to sleep reduction**
- Peter thinks this is something society is far more willing to entertain today than 10 years ago
- [Matt Walker](https://www.sleepdiplomat.com/) (who’s also Peter’s close personal friend) has had a lot to do with this
- [Arianna Huffington](https://www.ariannahuffington.com/) has brought a lot of attention to this
- There are many people out there that are saying, “*I’ll sleep when I’m dead*,” (which used to be Peter’s mantra)
  - You’re going to be dead quicker if you adopt that mantra
- Peter doesn’t think this one requires a lot of convincing, but it is a little more complicated
- The good news is there’s really a lot of wonderful behavioral tools, and ultimately, for some people, pharmacology or mechanical assistance (such as [CPAP](https://en.wikipedia.org/wiki/Continuous_positive_airway_pressure), if a person has apnea)
  - There are technologies, both pharmacologic and otherwise, that can really help here

***For most people, the behavioral tools work***

- This is really one of those things where very few people need to see a physician to help them sleep or to troubleshoot a sleep problem
- And when you do, fortunately, there’s an entire branch of medicine dedicated to sleep physiology
  - There are actual physicians who specialize in this, and we’re certainly not afraid to use them when it’s necessary

*There’s also a field of behavioral therapy called* [*cognitive behavioral therapy for insomnia*](https://en.wikipedia.org/wiki/Cognitive_behavioral_therapy_for_insomnia)

- That is an entire discipline that is dedicated towards the cognitive tools that you can use during periods of insomnia
- Peter always gets patients in his practice who just have what can only be described as the most abjectly horrible sleep

> “*And of all the problems we face, this is the one that I tend to be most optimistic about our ability to help in a relatively short period of time*.”‒ Peter Attia

- We have a whole [AMA](https://peterattiamd.com/ama42/) dedicated to sleep, along with multiple Matt Walker episodes [see the “selected links” section at the end of these notes]

**For someone who needs to take more awareness of their sleep and do more to get better sleep, what are some of the things they can look at and evaluate?**

*The quick answer*

- Try to go to bed at the same time and wake up at the same time every day
- Give yourself about 8 hours to be in bed
- Make the room as dark as possible, as cold as possible, and detach yourself from anything stimulating, especially upsetting
  - Which is work, social media, that kind of stuff, for 2 hours before bed
- Try to not eat or drink any alcohol for 3 hours before bed

***Those would be the no-risk, no-regret moves to try to fix your sleep; and that’s a lot, by the way. Peter is not suggesting that would be easy to do for someone who’s doing none of them.***

- If you gave him 100 people who were complaining of poor sleep and/or objectively had measurements of poor sleep and all 100 of them did that, Peter thinks 80 of them would get better

## Drugs and supplements: Peter’s framework for thinking about drugs and supplements as tools for enhancing longevity [1:13:30]

- We have an insane amount of [content on supplements](https://peterattiamd.com/category/treatments/), and it’s impossible to answer all the questions that come in

**Help people understand what their relationship with drugs and supplements should be and how to think about it**

*How do you talk to patients about that, who come into the practice with a list of 20 supplements they are on?*

- That is definitely one phenotype
- There are 2 extremes
  - Some people think everything is solved by drugs and supplements
  - Other people think you should never take a drug and supplement

*Peter tries to remind people that drugs and supplements are just a tool*

- To say, “*I never want to take a drug,*” is like telling a contractor, “*Hey, please do a good job building my house, but just never use the hammer or never use the Phillips screwdriver. You can use the Robertson, but not the Phillips*.”
- You just want to have tools
- The best contractor, carpenter, and tradesman is going to have the most tools and the most facility, with knowing how and when to use them
- We have a framework because there’s an infinite number of supplements
  - There’s a finite number of regulated drugs, but a non-finite number of supplements

*Peter’s framework for thinking about supplements*

- 1 – The 1st question he is always asking himself with any exogenous molecule is: is this a molecule that is being taken to lengthen lifespan or improve healthspan?
  - You would be amazed at how many times he asks somebody who’s taking a supplement which of those two they’re taking it for
    - Usually, you get a very blank stare
    - Or, “*I’m taking it because fill-in the blank influencer told me to take it.*”
- Let’s say we can establish that you are taking this for one of those reasons
  - It’s either going to make me live longer and/or it’s going to improve my physical, cognitive, or emotional health
- 2 – The next question Peter would ask is, “*Okay, if this is a lifespan enhancer, if this is going to make you live longer, is it doing it by targeting a specific disease, or is it a broad geroprotective molecule? Similarly, if you’re telling me this is a health span enhancer, is it specifically enhancing cognitive health, physical performance, emotional health, or is it acting through some mechanism we don’t understand?*”
- 3 – He would ask if we have safety data on this
- 4 – He would ask if we have efficacy data in humans and/or in animals
  - If not, and if in animals, how relatable is it?
  - If it’s a supplement, I would ask, how can we control for purity?
    - How do we know that what the bottle says is in it is actually what’s in it and that nothing that’s not supposed to be in it isn’t in it?
- There are a few more questions, but that’s the long and short of it

***One needs to go through that type of exercise and put that type of filter to everything, and only then should we go down the path of, okay, what supplements do we want to use? Where do we want to turn to pharmacology, hormones, those things?***

## Why emotional health is a key component of longevity [1:17:00]

- Emotional health fits in the healthspan bucket
- When people think about longevity, emotional health is not something that usually comes up a lot

**What would you say to someone who is taking the steps in their  nutrition, exercise, sleep, drugs, and supplements, but not necessarily focusing on their emotional health?**

- There are 2 components
- There is enough evidence that a person who’s managing their stress better, who’s happier, and who has better relationships probably lives longer
  - Certainly the epidemiology suggests all of that
  - However, that would be very difficult to demonstrate causality
    - People could be happier and have better relationships, and all those things because their health is better; so it could be reverse causality
  - Peter thinks there’s actually enough evidence that there’s at least bidirectional causality there
- Let’s pretend that being miserable, lonely, and angry helped you live longer, and that if you were happy and you had great relationships, and you were in harmony, you would live shorter
  - Who would choose the former when you frame it that way?
  - Outside of extremes, like, okay, happy people can’t live past 30, miserable people can live to 100
    - Sure, a lot of people would say, “*Well, I’d rather be miserable at 100.*”
  - But the truth of it is, even framed that way, it seems ridiculous
- All of that is to say, as a thought experiment, just forget the lifespan piece of this
  - Just think of it through the lens of common sense: Why would you ever choose to be unhappy? (it doesn’t make sense)

***A big insight for Peter late in life is that you can do something about this***

- Everybody’s got a story, everybody’s got a history, everybody’s got a background that brings them to the table, but it’s all modifiable
- The point is: the software can be modified
- We’ve got so much [content](https://peterattiamd.com/category/mental-health/) on this that Peter couldn’t go into it in any detail here

***The most important thing for the purpose of this discussion is that this entire area is as important, potentially more important than all of the others because without this one in check, the other ones don’t matter***

## Advice for newcomers on where to start on their longevity journey [1:19:30]

- As we mentioned on the outset, the idea is not to get into the super-intense details on everything (we’ll link to that), but we cover high-level longevity 101 and how Peter thinks about some core aspects for people who are newer, people who need a refresher

**If someone is new and maybe feels a little bio overwhelmed, where should they start?**

- Pick one: lifespan, healthspan, different diseases, different tactics
- Finding something you think you’re going to be successful in would be the best first place to start
- If after listening to everything we just talked about, you think, “*You know what really resonates with me? My sleep probably sucks,*” then work on the stuff we talk about on sleep
  - Don’t do anything else
    - Change nothing in your nutrition, exercise
    - Don’t buy a supplement
- Because, if you get that better, it’s going to do 2 things
  - It’s going to make it easier for you to address the other things

And it’s going to give you the confidence and agency that says, “*Hey, I actually have control over this thing. It’s not out of my hands.*”

§

## Selected Links / Related Material

**Peter’s book**: [Outlive](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZc3hWLITcnTc7B2P76ivh285q3LcpZmR8KEgNoEJuv1Zqxeouda-RMCf4k8e11ye-8-8baLYdnwPtSSwii3VQUlQyEAgDd_kSLgVMXkuSNhXa0XZnOvx4niMVZvo7j50qwJLAN-LzVptqJC67rNqR2vj7XvYEnkMkum6F5fYkqOIQareCM3YQ8ABta6croTyXn-WqR2sc6knnGp9Fs3nSWE.zzsFKRXtqKaubUYCWM8sabGF0asdx5aQgMO-2WAD_CU&qid=1717002766&sr=8-1) by Peter Attia with Bill Gifford (2023) | [6:30, 11:45, 45:30, 49:15]

**More content about atherosclerosis**: [Cardiovascular disease](https://peterattiamd.com/category/diseases/heart-disease-prevention/) | peterattiamd.com (2024) | [26:00]

**Episode of** ***The Drive*** **that explains the causes of heart disease**: [#203 – AMA #34: What Causes Heart Disease?](https://peterattiamd.com/ama34/) (April 18, 2022) | [29:45]

**More content about high blood pressure**: [High blood pressure](https://peterattiamd.com/category/diseases/high-blood-pressure/) | peterattiamd.com (2024) | [31:00]

**Content on Lp(a)**: [33:45]

- [High Lp(a) warrants intervention, even without other cardiovascular risk factors](https://peterattiamd.com/high-lpa-risk-factors/) | PeterAttiaMD.com (K Birkenbach, T Dayspring, P Attia 2024)
- [#238 – AMA #43: Understanding apoB, LDL-C, Lp(a), and insulin as risk factors for cardiovascular disease](https://peterattiamd.com/ama43/) (January 16, 2023)
- [Reassuring new data on statin-induced Lp(a) elevation](https://peterattiamd.com/statin-induced-lpa-elevation/) | PeterAttiaMD.com (K Birkenbach, T Dayspring, P Attia 2022)
- [Lp(a) and CVD risk & clinical tests to measure Lp(a)](https://peterattiamd.com/lpa-and-cvd-risk-clinical-tests-to-measure-lpa/) | PeterAttiaMD.com (2022)
- [Peter’s approach to managing patients with high Lp(a)](https://peterattiamd.com/managing-patients-with-high-lpa/) | PeterAttiaMD.com (2022)
- [#210 – Lp(a) and its impact on heart disease | Benoît Arsenault, Ph.D.](https://peterattiamd.com/benoitarsenault/) (June 13, 2022)
- [#24 – Tom Dayspring, M.D., FACP, FNLA – Part V of V: Lp(a), inflammation, oxLDL, remnants, and more](https://peterattiamd.com/tomdayspring5/) (October 19, 2018)
- [#07 – Deep Dive: Lp(a) — what every doctor, and the 10-20% of the population at risk, needs to know](https://peterattiamd.com/lpa/) (July 30, 2018)

**More content about cancer**: [Cancer](https://peterattiamd.com/category/diseases/cancer-prevention/) | peterattiamd.com (2024) | [33:30]

**More content about neurodegenerative disease**: [Cognitive health & neurodegenerative disease](https://peterattiamd.com/category/diseases/neurodegenerative-disease-prevention/) | peterattiamd.com (2024) | [39:30]

**More content about metabolic disease**: [Metabolic disease](https://peterattiamd.com/category/diseases/metabolic-disease/) | peterattiamd.com (2024) | [43:15]

**Episode of** ***The Drive*** **about neurodegenerative disease**: [#236 ‒ Neurodegenerative disease: pathology, screening, and prevention | Kellyann Niotis, M.D.](https://peterattiamd.com/kellyannniotis/) (January 2, 2023) | [43:00]

**Episode of** ***The Drive*** **about how elderly should begin an exercise program**: [#307 ‒ Exercise for aging people: where to begin, and how to minimize risk while maximizing potential | Peter Attia, M.D.](https://peterattiamd.com/exerciseforagingpeople/) (June 24, 2024) | [46:15]

**Episode of** ***The Drive*** **about the centenarian decathlon**: [#261 ‒ Training for The Centenarian Decathlon: zone 2, VO2 max, stability, and strength | Peter Attia, M.D.](https://peterattiamd.com/training-for-the-centenarian-decathlon/) (July 10, 2023) | [47:45]

**Peter’s company geared for training people for the centenarian decathlon**: [10 Squared](https://10squared.com/) | [53:45]

**Episodes of** ***The Drive*** **focused on stability**: [55:45]

- [#152 – Michael Rintala, D.C.: Principles of Dynamic Neuromuscular Stabilization](https://peterattiamd.com/michaelrintala/) (DNS) (March 8, 2021)
- [#131 – Beth Lewis: The Art of Stability: Learning about pain, mitigating injury, and moving better through life](https://peterattiamd.com/bethlewis/) (October 5, 2020)

**Premium newsletter about the benefits of a high VO****2** **max**: [The [almost] unbelievable effects of a high maximal aerobic capacity on all-cause mortality](https://peterattiamd.com/all-things-vo2-max/) | PeterAttiaMD.com (S Lipman, K Birkenbach, P Attia 2024) | [58:45]

**Newsletter about the outcomes of exercise**: [With exercise, results matter more than “time served”](https://peterattiamd.com/how-much-time-should-you-spend-exercising/)  PeterAttiaMD.com (K Birkenbach, P Attia 2024) | [58:45]

**More content on the benefits of exercise**: [Exercise & Physical Health](https://peterattiamd.com/category/exercise/) | PeterAttiaMD.com (2024) | [58:45]

**More content on nutrition**: [Nutritional Biochemistry](https://peterattiamd.com/category/nutritional-biochemistry/) | PeterAttiaMD.com (2024) | [59:00]

**More content on protein**: [Protein](https://peterattiamd.com/category/nutritional-biochemistry/protein/) | PeterAttiaMD.com (2024) | [1:03:00]

**Episodes of** ***The Drive*** **that discussed anabolic resistance that occurs with aging**: [1:03:30]

- [#299 ‒ Optimizing muscle protein synthesis: the crucial impact of protein quality and quantity, and the key role of resistance training | Luc van Loon, Ph.D.](https://peterattiamd.com/lucvanloon/) (April 22, 2024)
- [#227 – AMA #40: Body composition, protein, time-restricted feeding, fasting, DEXA scans, and more](https://peterattiamd.com/ama40/) (October 17, 2022)
- [#224 ‒ Dietary protein: amount needed, ideal timing, quality, and more | Don Layman, Ph.D.](https://peterattiamd.com/donlayman/) (September 26, 2022)

**Understanding DEXA and body composition**: [Body composition: impact on disease risk and how to assess and improve it](https://peterattiamd.com/improving-body-composition/) | PeterAttiaMD.com (E Donahue, K Birkenbach, P Attia 2024) | [1:05:00]

**Content on reducing calorie intake**: | [1:07:00]

- [#222 ‒ How nutrition impacts longevity | Matt Kaeberlein, Ph.D.](https://peterattiamd.com/mattkaeberlein3/) (September 2022)
- [Is alternate-day fasting superior to calorie restriction for fat loss in lean adults?](https://peterattiamd.com/is-alternate-day-fasting-superior-to-calorie-restriction-for-fat-loss-in-lean-adults/) | PeterAttiaMD.com (2021)
- [Calorie Restriction, Part I: What Does Restricting Calories Have to Do With Longevity?](https://peterattiamd.com/what-does-restricting-calories-have-to-do-with-longevity/) | PeterAttiaMD.com (2018)
- [Calorie Restriction, Part II: Monkey Studies](https://peterattiamd.com/calorie-restriction-part-iia-monkey-studies/) | PeterAttiaMD.com (2018)

**Content on dietary restriction**: [1:07:15]

- [Different effects of fat- vs. carbohydrate-restriction on neural reward signaling](https://peterattiamd.com/fat-vs-carbohydrate-restriction/) | eterAttiaMD.com (K Birkenbach, P Attia 2022)
- [#162 – Sarah Hallberg, D.O., M.S.: Challenging the status quo of treating metabolic disease, and a personal journey through a grim cancer diagnosis](https://peterattiamd.com/sarahhallberg/) (May 17, 2021)
- [#157 – AMA #22: Losing fat and gaining fat: the lessons of fat flux](https://peterattiamd.com/ama22/) (April 12, 2021)
- [#120 – AMA with Dom D’Agostino, Ph.D., Part II of II: Ketosis for cancer and chronic disease, hyperbaric oxygen therapy, and the effect of ketosis on female health](https://peterattiamd.com/domdagostinoama02/) (July 20, 2020)
- [#116 – AMA with Dom D’Agostino, Ph.D., Part I of II: Ketogenic diet, exogenous ketones, and exercise](https://peterattiamd.com/domdagostinoama01/) (June 22, 2020)

**Content on time restricted eating**: [1:07:30]

- [Does time-restricted eating increase the risk of cardiovascular death?](https://peterattiamd.com/time-restricted-eating-and-ascvd/) | PeterAttiaMD.com (S Lipman, S Kornweiss, Peter Attia 2024)
- [Time-restricted eating: efficacy versus effectiveness](https://peterattiamd.com/time-restricted-eating-efficacy-versus-effectiveness/) | PeterAttiaMD.com (2020)

**Content on the Mediterranean diet**: | [1:08:00]

- [The MIND diet on trial: can diet choices impact cognitive health?](https://peterattiamd.com/diet-choices-and-cognitive-health/) | PeterAttiaMD.com (K Birkenbach, P Attia 2023)
- [#153 – AMA #21: Deep dive into olive oil, high-intensity exercise, book update, and more](https://peterattiamd.com/ama21/) (March 15, 2021)
- [Is a Mediterranean diet best for preventing heart disease?](https://peterattiamd.com/is-a-mediterranean-diet-best-for-preventing-heart-disease/) | PeterAttiaMD.com (2013)

**More content on sleep**: [Sleep](https://peterattiamd.com/category/sleep/) | PeterAttiaMD.com (2024) | [1:08:30]

**AMA on sleep**: [#233 – AMA #42: Optimizing sleep – bedtime routine, molecule regimen, sleep trackers, sauna, & more](https://peterattiamd.com/ama42/) (December 5, 2022) | [1:12:15]

**Matt Walker episodes on sleep**: [1:12:15]

- [#221 ‒ Understanding sleep and how to improve it](https://peterattiamd.com/understanding-sleep/) (September 5, 2022)
- [#127 – AMA #3 with sleep expert, Matthew Walker, Ph.D.: Fasting, gut health, blue light, caffeine, REM sleep, and more](https://peterattiamd.com/matthewwalkerama3/) (September 7, 2020)
- [#126 – Matthew Walker, Ph.D.: Sleep and immune function, chronotypes, hygiene tips, and addressing questions about his book](https://peterattiamd.com/matthewwalker4/) (August 1, 2020)
- [#77 – AMA #2 with sleep expert, Matthew Walker, Ph.D.: short sleep mutants, optimal sleep environment, sleep apnea, & rapid fire questions](https://peterattiamd.com/matthewwalkerama2/) (October 18, 2019)
- [#58 – AMA with sleep expert, Matthew Walker, Ph.D.: Strategies for sleeping more, sleeping better, and avoiding things that are disrupting sleep](https://peterattiamd.com/matthewwalkerama/) (June 17, 2019)
- [#49 – Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep](https://peterattiamd.com/matthewwalker3/) (April 15, 2019)
- [#48 – Matthew Walker, Ph.D., on sleep – Part II of III: Heart disease, cancer, sexual function, and the causes of sleep disruption (and tips to correct it)](https://peterattiamd.com/matthewwalker2/) (April 8, 2019)
- [#47 – Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, memory consolidation, and more](https://docs.google.com/document/d/1XBnqUisgieXL6DfbJYTUaPGOVtEyGNTohPhcmwOzMS4/edit#47%20%E2%80%93%20Matthew%20Walker,%20Ph.D.,%20on%20sleep%20%E2%80%93%20Part%20I%20of%20III:%20Dangers%20of%20poor%20sleep,%20Alzheimer%E2%80%99s%20risk,%20mental%20health,%20memory%20consolidation,%20and%20more) (April 1, 2019)

**More content on supplements**: [Medications, Supplements & Other Treatments](https://peterattiamd.com/category/treatments/) | PeterAttiaMD.com (2024) | [1:13:45]

**More content on emotional health**: [Mental & Emotional Health](https://peterattiamd.com/category/mental-health/) | PeterAttiaMD.com (2024) | [1:19:15]

§

## People Mentioned

- [Bert Vogelstein](https://profiles.hopkinsmedicine.org/provider/Bert+Vogelstein/2777618) (Professor of Oncology at Johns Hopkins) [36:15]
- [Matt Walker](https://www.sleepdiplomat.com/) (Professor of Neuroscience and Psychology at UC Berkeley, founder and Director of the [Center for Human Sleep Science](https://www.humansleepscience.com/), and author of [*Why We Sleep*](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.AOq6jBQ2pnDvCepg4IDk8ABIj_mqd3ODcguxu8mI-qKNGIrbcm5pCvQ5v6adp_dVsxRmeNJ49fhFwGhS6fOHu52BFCM3vZV3Kc5F6GZQ18pOkZbHz4GzZFD9zUneG798VYYh5zNLBag1_F0GqmU79lU4QzSzE75IJvZgIPKbCJNGLcJqmpMww4XGDCcphyO3I4-RxJf6uBBqVXrhrHfuKSQTsqX8iCl_3N-oVH84xBc.cNBMk74seNSXqaNxornD9gzr2W9ZeaZKPdunGYJzHtI&qid=1717174505&sr=1-1)) [31:00, 1:10:15]
- [Arianna Huffington](https://www.ariannahuffington.com/) (Founder of *The Huffington Post* and author of [*Thrive*](https://www.amazon.com/Thrive-Redefining-Success-Creating-Well-Being/dp/0804140847/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.UBDhn3U5z_EDGvCzUP8bYJq4ZIqP5mqT2ONLMH8iGUNfbdixFd5qAJAYcp5LdQ7thlQGxkn6G45fudmCjHecQioGpTGDiQn-AxKkZpZvkT5BlLMcbCf4QZi9IyQ_70ul41N9AHzyhzIO1MIAaPAczpiFdanlz_8fx2REn7h-W5ji4TjQPUFIQX6JZbDmNcChAsdmOr-JkOACca21ew3P3dP_V2J5v_eJ0mXqla9CS_Q.7GIAh4VPL0e7Jbf6ZiyTFtL0LPTdOm1479aSqKMVNMg&qid=1717172888&sr=8-1) and [*The Sleep Revolution*](https://www.amazon.com/Sleep-Revolution-Transforming-Your-Night/dp/1101904003/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)) [1:10:30]

§