# #51 – Robert Sapolsky, Ph.D.: The pervasive effect of stress – is it killing you?

**Source:** [https://peterattiamd.com/robertsapolsky/](https://peterattiamd.com/robertsapolsky/)

---

In this episode, Robert Sapolsky, Ph.D., discusses the widespread impact of stress on our physical and emotional health as well as the mechanisms by which it can precipitate chronic illness, dementia, depression, and more. He also provides insight into the factors that contribute to the stress response (and our ability to handle it) such as social rank, personality, environment, and genetics. Lastly, we discuss how our behavior is altered in the face of stress and how that not only has a pervasive effect on a personal level, but also on society as a whole in how we interact with each other.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/robertsapolsky/the_Drive_public.png)

Play

#51 - Robert Sapolsky, Ph.D.: The pervasive effect of stress - is it killing you?

#51 - Robert Sapolsky, Ph.D.: The pervasive effect of stress - is it killing you?

1x15s30s

0:002:18:32

## We discuss:

- Background, interest in stress, and Robert’s time in Kenya studying baboons [7:00];
- Physiology of a stress response, and why it’s ingrained in our DNA [14:00];
- Individual variation in the response to stress, and how everyone has a different optimal level [24:00];
- How social rank and personality differences affect our stress response [30:15];
- What’s happening in the brain when faced with stressful situations? [39:15];
- What makes the human brain different than all other species? [48:15];
- Imprinting stress to your kids epigenetically [52:00];
- The role of stress on memory and the consequences of hypercortisolemia [57:15];
- The impact of subjective socioeconomic status and social media on stress levels and health [1:01:45];
- Tips for managing stress in the modern world [1:17:45];
- What Robert learned about himself studying the social behavior of baboons [1:29:30];
- The multilayered factors behind every human behavior, the context of “good and bad”, and exploring the human capacity of the wild extremes of violence and altruism from moment to moment [1:34:30];
- PMS: How two women with identical hormone levels can have completely different emotional experiences [1:39:00];
- How much of a role do genes play in depression and other emotional states? [1:42:45];
- Why is cortisol elevated under sleep deprivation? [1:50:15];
- The impact of stress on cancer [1:54:30];
- The impact of stress on atherosclerosis, dementia, addiction, and depression [2:01:15];
- Impulsiveness, impaired judgement, and lack of empathy in times of stress [2:05:45];
- What advice would Robert give his 25-year-old self? [2:12:45]; and
- More.

§

## Show Notes

## Background, interest in stress, and Robert’s time in Kenya studying baboons [7:00]

> “I actually don’t think stress kills you outright very often, but it sure makes other things that kill you more effective at doing it.”

Time in Kenya

- Knew he wanted to be a [primatologist](https://en.wikipedia.org/wiki/Primatology) since he was 8 years old
- For last 30 years spent summers studying the population of wild baboons in the National Park in East Africa (specifically one troop in the Serengeti in Southwest Kenya)
- He’s been trying to answer questions like:
  - What does your social rank have to do with patterns of stress-related disease?
  - What about personality?
  - What does patterns of social affiliation have on stress?
- Robert calls it a “counterbalance to the lab” where he spends the rest of his time studying the effects of cortisol on the brain (among other things)

![](https://peterattiamd.com/wp-content/uploads/2019/04/robert-with-baboon-772x1024.png)

**Figure 1. Robert with a baboon from the troop he studied for decades.** Image credit: [stanford.edu](https://news.stanford.edu/news/2007/march7/sapolskysr-030707.html)

Credentials

- Rockefeller University for PhD
- Postdoc at Salk Institute in San Diego
- Been working at Stanford for 31 years
- Wrote [Why Zebras Don’t Get Ulcers](https://www.amazon.com/Why-Zebras-Dont-Ulcers-Third/dp/0805073698) in 1994

## Physiology of a stress response, and why it’s ingrained in our DNA [14:00]

Stress causes changes in hormones in our body, the 2 most importantly include:

1. [Adrenaline](https://en.wikipedia.org/wiki/Adrenaline)  ⇒ “It’s on the scene in your bloodstream within one, two seconds after all hell breaks loose.”
2. [Glucocorticoids](https://en.wikipedia.org/wiki/Glucocorticoid) (human version called [cortisol](https://en.wikipedia.org/wiki/Cortisol)) ⇒ comes out of the adrenal glands, stressful situation causes hypothalamus to secrete [CRH](https://en.wikipedia.org/wiki/Corticotropin-releasing_hormone) which goes to your pituitary to release [ACTH](https://en.wikipedia.org/wiki/Adrenocorticotropic_hormone) which goes to your adrenals when kicks out cortisol

Sympathetic vs. parasympathetic system

- These two systems are autonomic (aka not under your conscious control)
- [Sympathetic](https://en.wikipedia.org/wiki/Sympathetic_nervous_system) ⇒ fight or flight, all hell breaking loose, alarms going off
- [Parasympathetic](https://en.wikipedia.org/wiki/Parasympathetic_nervous_system) ⇒ calm, vegetative function, stress turns OFF parasympathetic

**Adrenaline vs. cortisol**

They work hand in hand, they synergize

- Metaphor: “Adrenaline in two seconds is handing guns out of the gun locker into whoever’s gonna defend you. Glucocorticoids are building the aircraft carriers that a year from now are gonna be essential. It does some of the slower components in the stress response, stretching out over minutes to hours.”

*Is one of these 2 systems more primitive that the other?*

- Adrenaline (i.e. epinephrine and [norepinephrine](https://en.wikipedia.org/wiki/Norepinephrine)) is technically more primitive
- However, glucocorticoids/cortisol are also part of our ancient wiring
  - “It’s system that’s been serving vertebrates, doing a lot of help for them for an awful long time and it’s been very recent modification to instead secrete them in response to thinking about taxes.”

*What is it that cortisol was doing 10,000 years ago that was serving our interests?*

⇒ In the case of life or death (i.e. running from a predator)

- Adrenaline comes in immediately and triggers fight or flight for those initial few seconds
- But 30 seconds later (or minutes later), then glucocorticoids come in
- They increase vigilant thinking (in terms of smart evasion of the predator)
- The are bolstering the same process that epinephrine is boosting:
  - Increasing glucose levels in your bloodstream
  - Going to storage sites throughout your body (liver, muscle) and breaking stuff down
- Additionally, glucocorticoids shut down everything that’s not essential to surviving the next five minutes of this massive physical challenge
  - Digestion is impaired
  - Growth hormones are turned off
  - Reproduction is shut off

Diseases where people are unable to turn on their endocrine stress response:

- [Addison’s disease](https://en.wikipedia.org/wiki/Addison%27s_disease) (JFK has Addison’s disease)
- [Shy-Drager syndrome](https://en.wikipedia.org/wiki/Multiple_system_atrophy)
- “*These are diseases where somebody goes running after their commuter bus and they drop dead from hypoglycemic shock*.”

## Individual variation in the response to stress, and how everyone has a different optimal level [24:00]

Small window of tolerance

- Too much cortisol, it will kill you eventually and make you miserable as hell on the way
- Too little of it will kill you quite quickly
- We don’t hate stress, *we hate the wrong amount of stress*
- When it’s the optimal amount, we call it stimulation (roller coasters, scary movies)

Individual variation

- Some people find bird watching super stimulating
- Others need to be a mercenary in Yemen because that’s when they feel alive and awake
- So not only is it a narrow range, but we differ so much as to what each person’s optimum amount

**Hormone receptors**

*Can people also have different levels of* ***physiologic benefit or harm*** *at the same level of cortisol?*

- Robert says “yes”
- Peter is surprised: “*That’s not intuitive to me.*”
- In many ways, the level of **receptors of the hormones**, rather than the level of hormone itself, are more consequential

> “Individual differences in levels of receptors, what version you have, how well that works, how avidly it holds onto the hormone, what it is then coupled with afterward downstream inside the cell, that whole world turns out to be as central to understanding individual differences as part of the levels of hormones themselves, and as sensitive to all those things ranging from genes to prenatal environment to early development to psychological factors and so on.”

- Peter relates it to insulin: “You could have two people with the exact same level of insulin, completely different physiologic response because of insulin sensitivity.” (i.e. cortisol sensitive/resistant)
- Robert: It’s not only *“how loudly you speak hormone,* ***but how effectively your cells list to hormone.***”

## How social rank and personality differences affect our stress response [30:15]

*When did our species start seeing levels of stress that were unhealthy?*

- Robert thinks it predates our species
- It is a feature of smart social mammals (primates, cetaceans, elephants, etc.)

**Studying baboons**

- Baboons in the Serengeti in East Africa have a great life and a fantastic ecosystem
- They have no natural predators trying to kill them
- Their infant mortality rate is actually better than the neighboring human tribe ([Maasai people](https://en.wikipedia.org/wiki/Maasai_people))
- They can find their day’s calories in just 3 hours
- That leaves the rest of the day to “free time” which often times leads to **stressful social interactions** with other baboons
- “*They are well-off enough in our Westernized sense that they can sit around and generate psychological stress for each other*.”

Social rank and status in baboons

- In baboons, the higher rank in your troop, you have [lower levels of glucocorticoid](https://www.ncbi.nlm.nih.gov/pubmed/?term=Sapolsky+RM%5BAuthor%5D+new+world), lower blood pressure, etc.
- But what matters far more, is the **contextual meaning of your rank** (i.e. what the rank means in your particular troop)
  - The same exact rank means different things in different sorts of baboon cultures
  - One troop may have more members who display more aggression on you, grooming, food getting stolen from you, etc.
- In general, lower status equates to lower health

What about in humans?

- We also see a similar correlation to rank status and health
- But interestingly, we belong to **multiple hierarchies at once** and we can have very different ranks in them (family, work, sports team, hobby, etc.)
- You could be the lowest ranking employee at your company but be the deacon of your church, for example
- We are very good psychologically at deciding at whichever hierarchy were highest in and that’s the one we define ourselves by

**The impact of personality differences on stress levels**

- It’s more than just social rank… personality differences make a huge impact
- *For example, take two high ranking baboons*: The rival baboon sneezes 100 yards away and one of the high ranking baboons takes that as a sign of aggression and starts getting agitated while the other similar rank baboon just continues about his business, well those baboons will have very different glucocorticoid levels
- Similarly, the highest ranking baboon can have much higher stress levels than a number 10 or 20 in the troop based on his personality differences

## What’s happening in the brain when faced with stressful situations? [39:15]

**The amygdala**

- In a brain scanner, if you flash pictures of neutral faces in front of people, the people who see those neutral faces as threatening (reviewed [here](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3060967/)) tend to have an amygdala that is:
  - Physically larger in size
  - Higher metabolic rate
  - More electrophysiological

*Why is the amygdala referred to as the “reptilian” brain?*

- The amygdala is one of the anchors of what’s called the limbic system in the brain (emotional brain)
- Mammals have a whole lot more limbic development than fish, for example
- The limbic system is arousal, fear, anger, lust, love, mother/infant bonding, etc.
- Amygdala is involved in fear, anxiety, and aggression ⇒ “So your amygdala is absolutely central to some of our worst human moments.”

The brain has ~3 parts

1. This brainstem (handles everything we don’t have to think about ever i.e. breathing)
2. Midbrain (amygdala is the “mayor”, emotions happening beneath consciousness)
3. The cortex (where we “live” and think our thoughts)

     “As the complexity of the organism evolved, so too did that hierarchy.”

*Top down influence:*

- Humans can do something that no other species can do which is… we can use our cortex to think about something stressful (the fact that we will die someday), and this will go all the way down and affect our brainstem (heart rate increases, breathing increases)

*Bottom to top influence*:

- “What’s far more interesting and underappreciated . . . is how those **lower levels can influence what’s going on up above**.”

⇒ Example of bottom-to-top influence: [Classic study from 1973](https://pdfs.semanticscholar.org/ad1e/6dac677b7793836585405076e63839e99b22.pdf)

- A group of heterosexual male volunteers
- Guys walk across a really [scary suspended bridge](https://en.wikipedia.org/wiki/Capilano_Suspension_Bridge#Popular_culture)
- The guys would encounter an attractive female either halfway across the bridge, or when they were safely standing on the other side of the bridge
- They would then be asked to evaluate the attractiveness of the female
- They would rate her **more attractively in the middle of the bridge** (when they’re heart was racing)
- Then do the same experiment but give the males a [beta blocker](https://www.mayoclinic.org/diseases-conditions/high-blood-pressure/in-depth/beta-blockers/art-20044522) (blocks their heart from racing) and the increase in attractiveness was eliminated
- A great example of the “*boring, reptilian regulatory stuff helping influence what you think your emotions are.*”

![](https://peterattiamd.com/wp-content/uploads/2019/04/Capilano_Suspension_Bridge_Vancouver_Canada_July_2016_1-1-1024x575.jpg)

**Figure 2. A photo of Capilano Suspension Bridge, the site of the famous 1974 study.** Image credit: [wikipedia.org](https://en.wikipedia.org/wiki/Capilano_Suspension_Bridge)

## What makes the human brain different than all other species? [48:15]

- You can’t differentiate the neuron of a human and the neuron of some other organism (fish) when you look at it at the single cell level
- Same neurotransmitters, same enzymes, same gene regulation (We share 98% of our DNA with a chimp or bonobo)
- We have the same signal transduction pathways and neurons as you see in a fruit fly (You can take one of their genes or one of our genes and stick it in the other one and it functions just fine)

What is the key difference?

- For every neuron that a fruit fly has, we have 100 million ⇒ “**With enough quantity, you invent quality.**”
- [Emergent properties of complex systems](https://en.wikipedia.org/wiki/Emergence) … example:
  - You take one ant and you put it on a table and nothing that it does makes a huge amount of sense
  - You put 10,000 and they build a colony and complex adaptive stuff emerges

> “We’ve got more ants that are coming together in our heads than does a fruit fly and you get more complex emergent stuff happening.”

## Imprinting stress to your kids epigenetically [52:00]

Peter [read something that frightened him](https://www.sciencedaily.com/releases/2011/08/110830144630.htm): If a mother is under great stress, she could imprint epigenetically into the child and alter many features about them as they would age (i.e. propensity to be depressed)

*Does Robert believe this to be true?*

- “Absolutely.”
- Just look at childhood adversity versus childhood security and the very different trajectories
- Huge mechanistic challenge for the field? ⇒  *Understanding what is it about being in a scary neighborhood/unstable home versus having a parent read to you in a safe zone*
- In other words, what are the nuts and bolts changes that occurs in the kid that makes the adult “30- fold more likely than the next person” for certain things to happen to them?

**Epigenetics**

- Early experience, doesn’t change your actual genes/DNA sequence
- But your early experience can change the **regulation of your genes** (how easily you turn certain genes on/off in different parts of your body/brain)

⇒ For example, [non-genetic (non-Mendelian) transmission of traits](https://en.wikipedia.org/wiki/Non-Mendelian_inheritance):

- A fetal rat inside a mother who’s highly stressed
- She’s secreting a lot of rat glucocorticoids, which get into the circulation through the placenta, into the fetal circulation, into the kid’s brain
- One of the things that it does is it causes an epigenetic change in the amygdala (a bigger amygdala, more excitable, more prone towards interpreting a neutral situation as a threatening one)
- That new rat will have elevated levels of glucocorticoids because the world is “full of menace that only you were seeing”
- That rat gets pregnant and during pregnancy as a result, the new fetus is exposed to elevated glucocorticoid levels (so now the phenotype is being passed generation to generation through parallel expression)

⇒ In humans:

- There is a ripple effect from generation to generation
- “In other words, individual differences are rising not only from experience, **but from the multi-generational transmission of some of the consequences of experience**, which is just mind boggling that that can work that way.”

## The role of stress on memory and the consequences of hypercortisolemia [57:15]

How hypercortisolemia will impact the brain

- The [hippocampus](https://en.wikipedia.org/wiki/Hippocampus) (important for memory and learning) is extremely sensitive to glucocorticoids
- Why? 2 reasons:
  - One, to have a feedback loop
  - Two, so the hippocampus remembers stuff for you:
    - We can’t remember everything, so our memory processes has to come with a filter deciding what is important to remember
    - And **cortisol (along with epinephrine and norepinephrine) amplifies memory consolidation**

[Stress Effects on Neuronal Structure: Hippocampus, Amygdala, and Prefrontal Cortex](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4677120/)

⇒ Impact of stress on memory:

- The optimal amount of glucocorticoids (something that is moderately “stressful” or stimulating), great stuff to your hippocampus:
  - It increases blood delivery, glucose, and oxygen
  - It makes the synapses (the connections between neurons) more excitable
  - A little bit of arousal/alertness is a good thing for learning and memory
- Too much stress (i.e. you are stressed 24/7 ever since you were like 10 years old) … now the glucocorticoids are out of the optimal range and they do exactly the opposite to the hippocampus:
  - They decrease oxygen and glucose delivery to the hippocampus
  - They make neurons less excitable
  - They disconnect synapses
  - they cause the processes in neurons to shrivel
  - they block the birth of new neurons
- If you were stressed out of your mind, memory doesn’t work as well
- And if you are exposed to excessive glucocorticoid levels for many years, [your hippocampus will age more quickly](https://www.ncbi.nlm.nih.gov/pubmed/3527687)

## The impact of subjective socioeconomic status and social media on stress levels and health [1:01:45]

> “When you look at the source of variability in health among humans on this planet, socioeconomic differences, differences in absolute levels, differences in degrees of inequality within cultures and within communities are an enormous predictor of health. You want to look at the most medically impacted low ranking primates you could find on earth? Look at poor humans because when humans invented socio economic status and the capacity to be poor, they invented a way to subordinate the have-nots like no chimp on earth could ever dream of doing.”

Peter’s [podcast with Dr. Tom Catena](https://peterattiamd.com/tomcatena/)

- Tom is an amazing physician practicing in the Nuba Mountains (South Sudan) as the only doctor to a million people
- The Nuba people are being bombed and killed by [al-Bashir](https://en.wikipedia.org/wiki/Omar_al-Bashir), an evil dictator
- But despite their hardships, the Nuba people almost never commit suicide
- Their life and existence would be considered abysmal to the western countries
- Yet Peter would think their cortisol is lower than ours

⇒ *What would Robert hypothesize explains that positive mental health?*

- Probably a combination of a strong sense of community and little subjective status disparity
- The quarter poorest places on earth, indeed people don’t live very long and are generally miserable
- But once you get above the subsistence level, *there’s not a great relationship between the wealth of the country (GDP per capita) and levels of happiness or life expectancy*

**What explains the poor health/mental health of westernized countries?**

In the westernized world, there is a health/socioeconomic gradient ⇒ The poorer you are, the worse your health will be on the average (and when you get a disease, the more impactful it is)

*But why does this relationship occur?*

Hypothesis #1: If you’re not healthy, it’s very hard to pull off being the CEO of a company

- In other words, poor health precedes and gives rise to poor socioeconomic status
- But this turns out to explain only a tiny percentage of the variability
- What about the other way around?
- When a child is raised in a home low on the level of socioeconomic status that is a predictor of their likelihood of diabetes half a century later
- So, yes, the socioeconomic status comes first in explaining the vast percentage of the variability

Hypothesis #2: Maybe everybody is equally healthy, but the really poor people are just really unhealthy (i.e. a [step function](https://en.wikipedia.org/wiki/Step_function))

- This is not true, says Robert
- With every step down starting from the ultra wealthy (i.e. Bill Gates), there is statistically lower health as you go down every rung

Hypothesis #3: Lack of healthcare access (neo-materialist explanation)

- The poorer you are, you don’t have healthcare access, you don’t have health insurance, you can’t go to the doctors readily, your carer is more lousy
- That explains *virtually none* of the variability in the data because you see the gradient nonetheless in countries with socialized medicine and universal healthcare
- So, *it’s not healthcare access*

**Subjective status and stress**

- From there, you then look cross culturally and you see wildly different income levels and wildly different levels of healthcare access, yet you see very similar life spans across these countries and very similar gradients
- Turns out, it’s got *very little to do with the material aspects of wealth or poverty*, it’s got to do with the **psychological aspects, it’s got to do with the stress**

\*[First key finding out of UCSF by Nancy Adler](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4171062/)\*

- Your socioeconomic status, your wealth, your objective measure of wealth, is indeed a predictor of your health
- But it turns out at least as good of a predictor is your **subjective socioeconomic status**
- When you look at people around you, *how are you doing compared to other people?*
- Asking this way allows for the person to consider the community that’s most pertinent to them (*Who’s the comparison group?*)
- “It turns out your **subjective socioeconomic status** is at least as good of a predictor of your health as is your objective socioeconomic status.”

⇒ Example:

- One guy is assistant manager of the mail room ⇒ And to him, that’s an incredibly status filled position in his opinion
- And there’s another guy who’s number 2 in the whole company who was just passed over to be number 1 ⇒ And the only pertinent thing in his mind is not the 99,000 employees and he’s higher ranking but that there’s still somebody ahead him
- “In other words, **it’s not being poor, it’s feeling poor**.”

\*The next critical piece is work from [Richard Wilkinson](https://en.wikipedia.org/wiki/Richard_G._Wilkinson) in the UK\*

- He looked at… *what’s the best, most effective way to make somebody feel poor, independent of their absolute levels of income*?
  - Surround them by inequality
  - Surround them by reminders of all the people who were doing better than them

**Technology, social media, and the modern world**

- Social media is the amplifier to all amplifiers of this
- You can’t go 10 minutes without looking at somebody who’s obviously better looking, obviously smarter, obviously richer, obviously having more fun, says Peter
- Robert points out that it could be even as simple as seeing a nice car come speeding past you on the road leading to you feeling crappy and diminished and like a less successful human
- Local inequality is more impactful, yet technology and social media has allowed for an expansion of the definition of “local”

> “This is unheard of in the history of humans or primates of being able to feel socially subordinated and you don’t even interact with the person.”

Social media as an amplifier

- No matter what century you grew up in, it is possible to experience the corrosive effects of being the last one picked for the game, the least popular kid, etc.
- But in today’s environment, you can spend 24/7 wallowing toxically in evidence of a gazillion other people who are better looking than you, more popular, etc.
- Social media and technology **makes the vulnerable more damaged than in the past**

## Tips for managing stress in the modern world  [1:17:45]

Of all the things that portend good health (nutrition, exercise, sleep, stress), Peter says he’s most worried about stress (it drives him crazy, he says)

Example:

- Peter says his highest blood glucose (besides immediately follow a meal) is always in the morning (according to his CGM that he wears 24/7)
- Once after not eating in over 24 hours, he had a glucose of 110 milligrams per deciliter when he woke up
- With CGM, Peter says you get this insight into this “horrible thing that’s happening when we think we’re sleeping and nothing else is going on, but we’re [ruminating](https://en.wikipedia.org/wiki/Rumination_(psychology))”

Is it the “dawn effect?”

- This could be explained by the “dawn effect”, which is basically your body’s release of cortisol to help you wake up and get your body started
- Peter says it just seems like it’s disproportionate, it must be more than that:
- e.g. People with type 2 diabetes have an amplified “dawn effect” ⇒ *Why is that someone who already has glucose dysregulation would have an even higher cortisol response in the morning?*

Peter’s point:

- This seems like this a harder problem to fix
- We don’t have a pill to fix [hypercortisolemia](https://en.wikipedia.org/wiki/Cushing%27s_syndrome)
- It’s one of the most complicated endocrine situations that also happens to be innately wired into us

**What should someone be doing to combat this?**

- Robert says he also struggles with this ⇒ “I’m mostly good at telling you what’s going to happen if you don’t get stuff under control rather than how to get things under control.”
- What do you see when you look at the literature closely?
  - First off, you must practice regularly with set aside time (i.e. you can’t do your stress management on the weekends, or for the 30 seconds your on hold on the phone)
  - In other words, like exercise you need hours per week of time set aside
  - Same with nutritional interventions as well as putting a premium on sleep
- If you want to combat hypercortisolemia … “*It ain’t a 20 minute a week thing.*”
- **80/20 rule**: Robert says simply deciding that you are going to start doing something to manage your distress gets you 80% of the way there

Why daily is better than weekly:

- Robert says that 10 minutes of deliberate mindful practice of meditation **daily** would be better than one hour **once a week**
- If you do it daily, you are sitting in the aftermath of having done that versus only one time a week (the recovery period)
- In the same way, one awful hour long stressor a week versus punctuated episodes of it throughout the week … without question, the latter is worse because you’ve now got umpteen different times that you have to recover from having turned on the stress response and *that’s where a lot of the damage occurs* (in the recovery period)

Email is a stress trigger for Peter

- He was getting agitated seeing his fluctuations in glucose each time he looked at his email
- Resting heart rate would be higher in the morning even after regular exercise that should improve his resting HR
- He changed to only looking at email for two 30-minute blocks per day and it really helped
- “We just have to figure out ways to figure out what those triggers are for us individually”

## What Robert learned about himself studying the social behavior of baboons [1:29:30]

- Robert is a very driven, accomplished person (which comes with stress)
- He won the [MacArthur award in 1987](https://www.macfound.org/fellows/313/) for his work as a neuroendocrinologist and primatologist

What did Robert learn about himself over the past 30 years going back his days in Kenya?

- As a field biologist, Robert was spending 3-4 months per year living alone in a tent without speaking to another human for 12 hours per day
- He was studying the benefits of social behavior of baboons
- He started to realize the irony of the situation

Meeting his wife

- Eventually he met his now wife and they started a family
- He now calls his family a “refuge and a sanctuary from the world’s madness”
- He says, 20 years ago “I could not have predicted sort of how much of my equilibrium at this point turns out to be due to interacting with the right two or three other primates”

## The multilayered factors behind every human behavior, the context of “good and bad”, and exploring the human capacity of the wild extremes of violence and altruism from moment to moment [1:34:30]

**Robert’s book**: [Behave: The Biology of Humans at Our Best and Worst](https://www.amazon.com/Behave-Biology-Humans-Best-Worst/dp/1594205078)

- The book was about trying to make sense of the biology of a puzzling thing about us as a behaving species, which is *we are simultaneously the most miserably violent species on earth and the most altruistic and cooperative and empathic*
- Any given human is capable of incredible gyrations in wonderful and awful behavior (and everything in between)

The context of the behavior

- And whether the behavior counts as good or bad is incredibly dependent on what culture they happen to be doing it in
- Pulling a trigger: Sometimes pulling a trigger can be one of the most awful things a human can do… and sometimes it could be one of the most wondrous ones if you’re suicidally drawing fire from innocent people and you’re sacrificing yourself
- Lovingly touching someone: In one setting you put your hand on somebody else’s and that could be a moment of incredible compassion… or you do the exact same thing with your primate muscles and that’s the first step of betraying a loved one

Multilayered factors of every behavior

⇒ To make sense of human behavior you got to factor in:

- What your neurons did one second ago (as well as the environmental triggers that caused that 30 seconds ago)
- Hormone levels were like this morning
- Neuroplasticity you’ve done over the last two seasons
- What your adolescence was like, your childhood, even your fetal life
- Your genes
- What sort of culture were your ancestors inventing centuries ago because that influenced the way you were raised within minutes of birth
- What things you value
- What things your amygdala does, or does not, respond to
- And finally evolution (i.e. why we’re in some ways like chimps and in some ways like bonobos, but we’re not either of those)

\*To understand this stuff, you’ve got to consider everything from **one second before to a hundred million years before**, and how all of these levels interact\*

> “What’s most startling about us is most of us have the capacity to do something that we would be stunned and sickened that we were capable of doing it. And most of us are capable of in some circumstance of doing something that is so damn heroic. And most of us spending most of our time doing things that instead are ambiguous and multilayered and full of ulterior motives. And you look at the worst of us and the best of us and there’s not a whole lot of really reliable predictors beforehand.”

## PMS: How two women with identical hormone levels can have completely different emotional experiences [1:39:00]

- Peter sees PMS purely through the len of the endocrine system (estrogen and progesterone levels fluctuating)
- What’s fascinating is that 2 women could have the exact same peak and valley in hormones yet report totally different experiences
- Peter says it could have something to do with “progesterone receptors”

Does Robert have any additional insight into this?

Robert wife observed this in baboons…

- Two baboons having the same menstrual cycle
- One of them is a totally irritable, awful jerk to all the other females around her for three days afterward
- The other baboon instead withdraws and become socially isolated
- What’s the difference?
  - One of them is high ranking ⇒ She could afford to be a jerk to everybody else and get away with it… the other baboon was low ranking
  - So it’s not just your hormone levels, it’s what sort of position in your society you have
- For example, women in collectivist cultures react differently on average to people in individualistic cultures ⇒ Are you in a culture where it’s culturally acceptable to bitch and moan to all your best friends when you’re not feeling well or are you in a culture where when you’re feeling lousy, what you’re supposed to do is reach out affiliative-ly and reify your like social values?

## How much of a role do genes play in depression and other emotional states? [1:42:45]

Robert’s high-level perspective on the role of genes

- In the school of genes get overrated in terms of their impact
- When you get to genetic influences on behavior and our internal lives, genes are important, but overwhelmingly these are genes that **modify vulnerability** to certain environments

**Genes implicated in depression**

- The single most important gene is the [serotonin transporter](https://en.wikipedia.org/wiki/Serotonin_transporter) (targeted with [SSRI](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor)/Prozac)
- The gene comes in a few different variants, one of which appears to make you more at risk for major depression

[Classic study by Avshalom Caspi](https://www.ncbi.nlm.nih.gov/pubmed/12869766)

- 17,000 people followed from birth to age 25
- About 20% of the study population has the “bad” variant of the gene
- What they saw is that there was *no increase in risk having the bad variant*
- However, if *coupled with a lot of childhood stress, there was about a 20x increase*
- The same childhood stressors to people *without* the “bad” gene variant had only a moderate increase in depression incidence
- It turns out these different gene variants are regulated in different ways by glucocorticoids (so stress has an impact)

[Study looking at genetics of aggression](https://www.ncbi.nlm.nih.gov/pubmed/12161658/)

- The gene is [monoamine oxidase](https://en.wikipedia.org/wiki/Monoamine_oxidase) and it comes in several variants
- Same study population as the depression study
- Just having that variant doesn’t get you a higher risk of antisocial, violent behavior by age 25 *unless it was coupled with childhood abuse growing up*

> “These are all genes about vulnerability and potentialities, and tendencies that are emerging only in certain environments and not in others. They’re the factors that are inseparable.”

## Why is cortisol elevated under sleep deprivation? [1:50:15]

- When we are sleep deprived, our cortisol levels are elevated
- Peter says, this is counterintuitive
- Peter’s possible explanation: if you’re sleep deprived, you’re body is assuming there is a good reason for it so you want cortisol to keep you awake and alert

⇒ Robert’s take: If you’re a basic mammal and you are wide awake when you’re supposed to be asleep… this does not happen by chance… the *odds are you have something stressful going on*

**The subtle interplay of sleep, sleep quality, and cortisol**

What we know now…

- Circadian peak of glucocorticoids are around the time you wake up
- An hour before you wake up, levels begin to rise, not for dealing with a stressor that has already commenced, but in **preparation** for having to get up and function

Interesting [sleep study](https://www.nature.com/articles/16166?platform=oscar&draft=collection):

- Take a group of volunteers
- The first night, tell them that this night we’re going to wake you up at 4 AM
  - The result? ⇒ Around 3 AM their glucocorticoid levels start rising
- Then, the next night you tell them I’m going to wake you up at some point during the night and that’s the end of your night’s sleep
  - Result? ⇒ After 90 minutes (one sleep cycle), their cortisol rises and stays high for the rest of the night
- So, not only is it bad not to get enough sleep, and not only is it bad if that insufficient sleep is fragmented, but the **worst is if it’s fragmented unpredictably**

“*And that’s like every medical resident in history.*”

In med school, Peter will literally tape a pager to his forehead because he was worried about sleeping through the call

“It’s wildly destructive.”

It turns out if you have elevated glucocorticoid levels while you’re asleep:

- You have less delta sleep time (restorative sleep)
- You make less adenosine stores in your brain
- The sleep quality is going to be horrible

## The impact of stress on cancer [1:54:30]

- There’s a common perception that stress can play a very substantial role in the onset of cancer, in coming out of remission, and rates of tumor growth
- However, the actual evidence is very, very minimal, says Robert
- Most human studies have too many confounding factors

When you look at the [animal studies](https://www.ncbi.nlm.nih.gov/pubmed/4017953)…

- Typically, you experimentally induce a tumor
- Under those circumstances, you can accelerate the growth of the tumor by increasing stress, *but those are circumstances of cancer acquisition that are virtually irrelevant to human cancer*
- And when you induce a cancer and induce a lot of stress you likely will alter some other parameter (What it eats, how much it’s sleeps, the quality of its sleep)
- “*So it becomes difficult to disentangle cortisol.*”

What about injecting glucocorticoid to a rat that already has cancer? In other words, you don’t actually increase the stress level, you just increase the readout state of stress?

- “You accelerate the tumor growth.”
- A cancer cell will upregulate the [GLUT4](https://en.wikipedia.org/wiki/GLUT4) glucose transporter (which is further upregulated by glucocorticoids) so it’s just “shoveling energy over those cells”
- Peter says this strikes him as reasonable evidence that cortisol can play a role in cancer
- Robert walks back this assumption: “Yes, but again, these are types of cancers where this was virally induced transformation of cells that are then transplanted in very artificial systems that turned out not to be terribly applicable to human cancers.”

Are glucocorticoids immunosuppressive?

- Yes, they be potently immunosuppressive
- But, usually by the time you have a tumor growing, that’s *long past the point where it’s an immunological problem*
- The focus shifts to how to keep the tumor from growing a whole bunch of capillaries, from stealing all sorts of energy, turning off cell death programs…  “*It’s no longer in the immune realm.*”

*The takeaway about stress and cancer*:

- Hard to make the case that acute bouts of stress can really have any impact on cancer development
- Easier to make the case that an acute disruption the immune system might lead to getting a cold
- A message from Robert:
  - The massive take home message is not to blame your stress for your cancer and think it’s all your fault
  - And anyone who is selling a “stress management will stop your tumor”, or make it “disappear” entirely, *watch your wallet*

*What is something that has been shown to increase effectiveness of cancer therapy?*

⇒ [Work out of Stanford from David Spiegel](https://www.latimes.com/archives/la-xpm-1989-05-11-mn-3291-story.html)

- Showed that things like [*supportive group therapy* among cancer patients enhances survival](https://www.ncbi.nlm.nih.gov/pubmed/2571815)
- W*hat is the mechanism of that*?
- One might think it reduced stress and therefore the decrease in cortisol lead to a positive cascade
- However, turns out that people in supportive cancer therapy with other people going through the same hell, they become more compliant with their medical regimes
- “When you’re surrounded by people who are going through the same thing and understand, you’re more likely to be compliant. I think that winds up explaining an awful lot of that effect.”

## The impact of stress on atherosclerosis, dementia, addiction, and depression [2:01:15]

**Atherosclerosis**

> “The damage of hypercortisolemia and the accelerated stress response are probably most demonstrated in cardiovascular disease and atherosclerosis.”

*The damage of hypercortisolemia*: Hypertension, both macro and micro vasculature, endothelial disruption, adhesion of cells

**Dementia**

- I would expect that it’s playing a role in dementia, says Peter
- Perhaps not in isolation but *in combination with other factors*

⇒ For example,

- Cortisol inhibits melatonin secretion
- Someone with hypercortisolemia generally has higher than normal cortisol during sleep which means their melatonin levels will be suppressed
- Melatonin is a a pro-neurogenic molecule, so having less of that is less restorative to the brain

*What other lines of evidence do you see that stress can damage the brain?*

Hippocampus

- Basically everything we talked about with the hippocampus applies in the adult brain as well
- We first see changes to the hippocampus in terms of [damaging memory capacity](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4677120/)
- Stress and lots of [glucocorticoids can accelerate hippocampal aging](https://www.ncbi.nlm.nih.gov/pubmed/3527687) (neuron loss, memory problems, and the extent of [reactive gliosis](https://en.wikipedia.org/wiki/Gliosis))

Amygdala

- Is there a direct correlation between amygdala size and dementia?
- You generally see expansion of the amygdala and you see atrophy of the hippocampus ([especially in PTSD](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5951719/))
- Glucocorticoids probably play the driving role in both

In the hippocampus:

- Stress and glucocorticoids cause:
- Neurons to not work as well
- Neural networks don’t work as well
- The overall size decreases

In the amygdala:

- It’s the exact opposite story…
- Neurons work better than they should
- Neurons become more excitable
- Form denser networks
- And the amygdala gets bigger in size

What are the implications of this?

- In the hippocampus: Your memory goes down the tubes
- In the amygdala: It leads to [anxiety disorders and fear](https://www.ncbi.nlm.nih.gov/pubmed/18391224/)

**Dopamine, depression and addiction**

- Dopamine is the neurotransmitter most famously associated with reward pleasure
- But a much more accurate, subtle picture is that dopamine is actually more about the **anticipation of pleasure** than it is about pleasure itself (goal directed behavior, i.e. what you’re willing to do in anticipation of reward)
- Stress and glucocorticoids mess with the dopamine system

A messed up dopamine system predisposes us towards the two big psychiatric diseases:

- 1) Addiction
  - More vulnerability to addiction
  - Harder to get off of addictive substances
- 2) Depression
  - Depression is a disease of on a certain level, dopamine depletion.
  - Depression is a disease of inability to feel pleasure and [hedonia](https://en.wikipedia.org/wiki/Hedonism)

That’s neurochemistry of the link between chronic stress and why that increases the likelihood of the first three, four episodes of major depression

## Impulsiveness, impaired judgement, and lack of empathy in times of stress [2:05:45]

**The frontal cortex**

Impulse control and judgement

- Robert says what’s most interesting to him is what stress and glucocorticoids do to the [frontal cortex](https://en.wikipedia.org/wiki/Prefrontal_cortex)
- Stress will impact judgment, impulse control, executive function, long term planning, strategizing, to name a few
- During moments of extreme emotional arousal (especially aversive ones) we make terrible, terrible decisions that seem brilliant at the time
- In those extreme moments, your *amygdala overpowers your frontal cortex*

*Lack of empathy*

- When we’re very stressed, it’s hard for the frontal cortex to do one of it’s harder jobs **which is to take the view of the world from somebody else’s perspective**
- In both rats and humans, [when you are stressed, you are less empathic towards strangers](https://www.ncbi.nlm.nih.gov/pubmed/25601547) when they’re in pain
- But if you block glucocorticoid release, you don’t get that effect anymore
- Glucocorticoids narrow the window as to who counts as an “us”

> “The fact that stress makes people crappier to each other, and less empathic, and more parochial, and more xenophobic, and more impulsive with the worst of our impulses. That’s the stuff that really interests me these days.”

Criminal justice system

- Both Peter and Robert agree that these findings have big implications in the world criminal justice reform
- A lot of these things that people have wound up in prison for are really **impulsive, horrible decisions, as opposed to decades of sinister planning**
- And it’s not clear that **the environment in there is reducing cortisol levels to the level that would enable rehabilitation**
- “It really strikes me as the exception and not the rule that people are able to emerge from that environment and go on to be successful outside.”

For more on this topic, check out [an episode of The Drive with a reformed prisoner named Corey McCarthy](https://peterattiamd.com/coreymccarthy/)

## What advice would Robert give his 25-year-old self? [2:12:45]

***How has Robert managed to have such a successful career to this point?***

“Just damn luck. Every bit of neurosis, every bit of affective instability that I’ve got, every childhood trauma I’ve got tucked away, I’ve titrated in just the right way and I’ve turned it into more productivity.

My capacity to sublimate emotion into intellectual pursuits, into really, really, really wanting to understand something. . .I’ve gotten just the right levels of all sorts of tumult, that have synergized most productively. In other words, just huge amounts of luck.”

***The cost of ambition***:

Robert says there is a cost associated with each ambition, and as he ages he starts to more carefully analyze those costs to make better decisions

***What advice would you give the 25 year-old Robert as he was just finishing that PHD at Rockefeller?***

“Be less ambitious.”

§

## Selected Links / Related Material

**Books written by Robert**: [4:00]

- [Why Zebras Don’t Get Ulcers](https://www.amazon.com/Why-Zebras-Dont-Ulcers-Third/dp/0805073698/ref=sr_1_1?crid=11GT1EE2ZUOM9&keywords=why+zebras+dont+get+ulcers&qid=1556157150&s=gateway&sprefix=why+zebra%2Caps%2C159&sr=8-1) [13:30]
- [A Primate’s Memoir: A Neuroscientist’s Unconventional Life Among the Baboons](https://www.amazon.com/gp/product/0743202414/ref=dbs_a_def_rwt_bibl_vppi_i2)
- [The Trouble with Testosterone: And Other Essays on the Biology of the Human Predicament](https://www.amazon.com/gp/product/0684838915/ref=dbs_a_def_rwt_bibl_vppi_i3)
- [Behave: The Biology of Humans at Our Best and Worst](https://www.amazon.com/gp/product/0143110918/ref=dbs_a_def_rwt_bibl_vppi_i0) [1:34:45]

**Robert was the MacArthur Award (a.k.a. The Genius Grant) in 1987**: [Robert Morris Sapolsky, Neuroendocrinologist and Primatologist | Class of 1987](https://www.macfound.org/fellows/313/) | (macfound.org) [5:00, 1:29:45]

**Higher ranked primates are less stressed (on the average)**: [Are subordinates always stressed? A comparative analysis of rank differences in cortisol levels among primates.](https://www.ncbi.nlm.nih.gov/pubmed/?term=Sapolsky+RM%5BAuthor%5D+new+world) (Abbott et al., 2003) [34:00]

**Individual differences in response to facial expressions**: [Abnormal structure or function of the amygdala is a common component of neurodevelopmental disorders](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3060967/) (Schumann et al., 2010) [39:15]

**Individual differences in response to facial expressions**: [Perceiving facial affective ambiguity: A behavioral and neural comparison of adolescents and adults](https://www.ncbi.nlm.nih.gov/pubmed/30628818) (Lee et al., 2019) [40:00]

**Classic study where male volunteers rate women as more attractive when they meet them in the middle of a scary suspension bridge**: [Some evidence for heightened sexual attraction under conditions of high anxiety.](https://pdfs.semanticscholar.org/ad1e/6dac677b7793836585405076e63839e99b22.pdf) (Dutton et al., 1974) [45:45]

**Movie where Keanu Reeves and Sandra Bullock fall in love in a stressful situation**: [Speed (1994 film)](https://en.wikipedia.org/wiki/Speed_(1994_film)) | (wikipedia.org) [47:45]

**Parents can imprint stress into a child’s genes**: [Parents’ stress leaves lasting marks on children’s genes, researchers find](https://www.sciencedaily.com/releases/2011/08/110830144630.htm) | (sciencedaily.com) [52:00]

**The impact of stress on the brain**: [Stress Effects on Neuronal Structure: Hippocampus, Amygdala, and Prefrontal Cortex](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4677120/) (McEwen et al., 2016) [57:15]

**Stress will age the brain more quickly**: [The neuroendocrinology of stress and aging: the glucocorticoid cascade hypothesis.](https://www.ncbi.nlm.nih.gov/pubmed/3527687) (Sapolsky et al., 1986) [1:01:00, 2:02:45]

**Episode of The Drive with Tom Catena, the American doctor in South Sudan**: [#40 – Tom Catena, M.D.: The world’s most important doctor – to nearly a million patients – saving countless lives in the war-torn and remote villages of Sudan](https://peterattiamd.com/tomcatena/) | Peter Attia (peterattiamd.com) [1:03:45]

**Nancy Adler’s work showing that your perception of your own social status is more impactful on your health than actual wealth or status**: [SUBJECTIVE SOCIOECONOMIC STATUS AND](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4171062/)

**Classic study which suggested gene variant only increases depression when combined with life stress in childhood**: [Influence of life stress on depression: moderation by a polymorphism in the 5-HTT gene.](https://www.ncbi.nlm.nih.gov/pubmed/12869766) (Caspi et al., 2003) [1:44:30]

**Study looking at the variant of monoamine oxidase as a predictor of aggression and found it only to be the case in combination with childhood trauma/abuse**: [Role of genotype in the cycle of violence in maltreated children.](https://www.ncbi.nlm.nih.gov/pubmed/12161658/) (Caspi et al., 2002) [1:46:30]

**Hormone levels rising in anticipation of waking**: [Timing the end of nocturnal sleep](https://www.nature.com/articles/16166?platform=oscar&draft=collection) [[PDF](https://www.researchgate.net/profile/Matthias_Moelle/publication/13397464_Timing_the_end_of_nocturnal_sleep/links/00463521dd4df63d28000000.pdf)] (Born et al., 1999) [1:46:30]

**Robert’s experiment in rats showing glucocorticoids accelerated tumor growth**: [Vulnerability to stress-induced tumor growth increases with age in rats: role of glucocorticoids.](https://www.ncbi.nlm.nih.gov/pubmed/4017953) (Sapolsky et al., 1985) [1:55:30]

**Supportive group therapy among cancer patients enhances survival**: [Effect of psychosocial treatment on survival of patients with metastatic breast cancer.](https://www.ncbi.nlm.nih.gov/pubmed/2571815) (Spiegel et al., 1989) [1:58:30]

**NY Times article on David Spiegel’s finding that supportive group therapy enhances cancer survival**: [Study Says Cancer Survival Rises With Group Therapy](https://www.latimes.com/archives/la-xpm-1989-05-11-mn-3291-story.html) | Janny Scott (nytimes.com) [1:59:00]

**PTSD and atrophy of the hippocampus**: [Smaller Hippocampal Volume in Posttraumatic Stress Disorder: A Multisite ENIGMA-PGC Study: Subcortical Volumetry Results From Posttraumatic Stress Disorder Consortia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5951719/) (Logue et al., 2018) [2:03:30]

**Robert’s study showing that when you are stressed, you are less empathic towards strangers**: [Reducing social stress elicits emotional contagion of pain in mouse and human strangers.](https://www.ncbi.nlm.nih.gov/pubmed/25601547) (Martin et al., 2015) [2:07:15]

**Peter podcast about his visit to a maximum security prison with a program led by Catherine Hoke**: [#12 – Corey McCarthy: Overcoming trauma, dealing with shame, finding meaning, changing the self-narrative, redemption, and the importance of gratitude](https://peterattiamd.com/coreymccarthy/) | Peter Attia (peterattiamd.com) [2:08:30, 2:11:45]

**Sam Harris’s book questioning whether or not we have free will**: [Free Will](https://www.amazon.com/Free-Will-Deckle-Edge-Harris/dp/1451683405) by Sam Harris | (amazon.com) [2:12:30]

§

## People Mentioned

- [Wylie Vale](https://en.wikipedia.org/wiki/Wylie_Vale) (Robert did postdoc with him) [12:15]
- [JFK](https://en.wikipedia.org/wiki/John_F._Kennedy) (Addison’s disease) [22:15]
- [Tom Catena](https://en.wikipedia.org/wiki/Tom_Catena) (physician practicing in Nuba mountains of Sudan) [1:03:45]
- [Omar al-Bashir](https://en.wikipedia.org/wiki/Omar_al-Bashir) (dictator of North Sudan) [1:04:00]
- [Jeff Bezos](https://en.wikipedia.org/wiki/Jeff_Bezos) (rich and healthy) [1:08:15]
- [Bill Gates](https://en.wikipedia.org/wiki/Bill_Gates) (rich and healthy) [1:08:15]
- [Nancy Adler](https://en.wikipedia.org/wiki/Nancy_Adler) (subjective socioeconomic status and health) [1:09:45]
- [Warren Buffett](https://en.wikipedia.org/wiki/Warren_Buffett) [1:10:30]
- [Richard Wilkinson](https://en.wikipedia.org/wiki/Richard_G._Wilkinson) (showed the most effective way to make somebody feel poor is to surround them by reminders of all the people who were doing better than them) [1:11:45]
- [Avshalom Caspi](https://en.wikipedia.org/wiki/Avshalom_Caspi) (depression gene and stress) [1:44:30]
- [Matthew Walker](https://twitter.com/sleepdiplomat?lang=en) (sleep expert, previous guest on [The Drive](https://peterattiamd.com/matthewwalker1/)) [1:50:15]
- [David Spiegel](https://med.stanford.edu/profiles/david-spiegel) (survival rates in cancer support groups) [1:58:30]
- [Jeffrey Mogil](https://www.mcgill.ca/psychology/jeffrey-mogil) (empathy and stress) [2:07:15]
- [Catherine Hoke](https://twitter.com/catherine_hoke?lang=en) (prison rehabilitation program) [2:08:30]
- [Corey McCarthy](https://twitter.com/coreymccarthyie?lang=en) (reformed prisoner, guest on The Drive) [2:11:45]
- [Sam Harris](https://twitter.com/SamHarrisOrg?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (Free Will) [2:12:30]

§

![](https://peterattiamd.com/wp-content/uploads/2019/04/Screen-Shot-2019-04-25-at-10.29.51-PM-500x500.png)

##### Robert Sapolsky Ph.D.

Robert Sapolsky is an American neuroendocrinologist and author. He is currently a professor of biology, and professor of neurology and neurological sciences at Stanford University. In addition, he is a research associate at the Institute of Primate Research operated by the National Museums of Kenya in Nairobi. For the last 30 years, Sapolsky has spent summers in Kenya studying a population of wild baboons in order to identify the sources of stress in their environment, and the relationship between personality and patterns of stress-related disease in these animals.

Sapolsky has received numerous honors and awards for his work, including the prestigious MacArthur Fellowship Genius Grant in 1987.

He has also written several acclaimed books, some of which include [Why Zebras Don’t Get Ulcers](https://www.amazon.com/Why-Zebras-Dont-Ulcers-Third/dp/0805073698) in 1994, and more recently, [Behave: The Biology of Humans at Our Best and Worst](https://www.amazon.com/Behave-Biology-Humans-Best-Worst/dp/1594205078) in 2017.

In 1978, Sapolsky received his B.A. in biological anthropology summa cum laude from Harvard University. Later he received his Ph.D. in neuroendocrinology at Rockefeller University working in the lab of endocrinologist Bruce McEwen. [[wikipedia.org](https://en.wikipedia.org/wiki/Robert_Sapolsky)]