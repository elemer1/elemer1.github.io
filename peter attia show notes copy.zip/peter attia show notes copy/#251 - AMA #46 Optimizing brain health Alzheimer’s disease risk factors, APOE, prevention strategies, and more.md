# #251 – AMA #46: Optimizing brain health: Alzheimer’s disease risk factors, APOE, prevention strategies, and more

**Source:** [https://peterattiamd.com/ama46/](https://peterattiamd.com/ama46/)

---

In this “Ask Me Anything” (AMA) episode, Peter goes into depth on the topic of brain health, starting with how Alzheimer’s disease is diagnosed, the significance of blood-based biomarkers in diagnosis, and what the various APOE gene variants mean in terms of a person’s risk of developing Alzheimer’s disease. Next, Peter discusses the various strategies for preventing Alzheimer’s disease and neurodegeneration. He touches briefly on exercise as a potent tool, but focuses more on lesser-known factors that could impact brain health, such as nutrition supplementation, lipid management, brain games, sauna, oral health, hearing loss, and more.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #46 show notes page](https://peterattiamd.com/ama46). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Diagnosing Alzheimer’s disease [2:45];
- Biomarkers for Alzheimer’s disease, the C2N test, and other tools for diagnosis [7:30];
- Genetic component of Alzheimer’s disease: genes that confer risk [12:45];
- Understanding your APOE status and why it’s important to know [17:15];
- The prevalence of Alzheimer’s disease and other forms of dementia, and who is at higher risk [21:15];
- Can the risk of Alzheimer’s disease be decreased with behavioral changes? [24:15];
- Overview of modifiable behaviors that potentially play a role in risk reduction of neurodegeneration [30:15];
- Things that clearly impact brain health: smoking, alcohol, sleep, head injuries, blood pressure, and more [34:15];
- How nutrition impacts brain health: common diets, metabolic health, energy balance, and more [46:15];
- Comparing common diets: data showing the association between the incidence of Alzheimer’s disease and specific diets [59:45];
- Supplements: EPA and DHA, vitamin D, and B vitamins [1:13:00];
- Supplements: theracurmin, cocoa flavonols, and magnesium L-threonate [1:25:15];
- Impact of exercise on brain health, minimum effective dose, and the most important types of exercise [1:33:00];
- Challenging the mind with brain games—does it impact neurodegeneration? [1:43:00];
- The data on sauna and brain health [1:49:45];
- Oral health and its association with brain health [1:52:45];
- How reducing lipids can improve brain health and prevent neurodegeneration [1:55:30];
- The potential impact of hearing loss on brain health and neurodegeneration [2:04:30]; and
- More.

§

The Peter Attia Drive

Optimizing brain health: Alzheimer's disease risk factors, APOE, prevention strategies, and more

§

## Show Notes

§

## Diagnosing Alzheimer’s disease [2:45]

\*Previous podcasts on this topic:

- [#234 with Chris Hemsworth](https://peterattiamd.com/chrishemsworth/)
- [#18 with Richard Isaacson](https://peterattiamd.com/richardisaacson/)
- [#138 with Lauren Rogen and Richard Isaacson](https://peterattiamd.com/laurenmillerrogen-richardisaacson/)
- [#147 with Hussein Yassine](https://peterattiamd.com/husseinyassine/)
- [#164 with Amanda Smith](https://peterattiamd.com/amandasmith/)
- And [more](https://peterattiamd.com/category/diseases/neurodegenerative-disease-prevention/)

> “Anyone who has a brain is at risk for this.” —Richard Isaacson [[episode #18](https://peterattiamd.com/richardisaacson/)]

**Diagnosing Alzheimer’s disease [4:45]**

- A lot of what we’re going to talk about today is around Alzheimer’s disease because Alzheimer’s disease is both the *most common* neurodegenerative disease and the most common cause of dementia
- Some other causes of dementia:
  - vascular dementia, which would be quite prevalent
  - Lewy body dementia
  - Parkinson’s disease
- As it pertains to the diagnosis of AD, unfortunately, it’s not a neat and tidy diagnosis the way we would have for breast cancer, for instance
- For AD, it really starts with a clinical diagnosis made by a neurologist
- They will assess various symptoms such as:
  - Difficulty remembering events
  - difficulty concentrating
  - planning or problem solving
  - confusion with location
  - temporal confusion (confused about different events over time)
  - language problems
  - reduction in vocabulary, speech, writing, etc.
- There may be some sort of mental status exam or neuropsychological tests
- There will also be some lab tests done to rule out other causes
  - For instance, a patient looks like they have all of the signs and symptoms of Alzheimer’s disease, but you come to find out that they’re profoundly hypothyroid, or they have B12 and B6 deficiencies or things like that
- The bottom line is this diagnosis really isn’t definitively made until an autopsy
  - That said, there are other biomarkers that are increasing in the sensitivity for this
  - we now have the ability to look at serum, amyloid, and tau, and those can be coupled with the things described above, in addition to things like amyloid PET
- A really good diagnostician can probably be almost assured that a patient indeed has Alzheimer’s disease based on the presentation

## Biomarkers for Alzheimer’s disease, the C2N test, and other tools for diagnosis [7:30]

**When you talk about cardiovascular disease, you have ApoE as kind of a biomarker that’s kind of a predictor of risk.** ***Is there anything equivalent to that for Alzheimer’s or neurodegeneration?***

- No, Alzheimer’s is much more complicated in this regard
- We do have biomarkers like amyloid and tau
- Historically, and for the purposes of research, these were typically drawn from CSF (cerebral spinal fluid) which can be accessed via a lumbar puncture
  - But this is very impractical in the real world—these are not benign procedures, and they’re certainly not things that we want to subject patients to rapidly

**C2N scores**

- We now look at other scores like the C2N developed amyloid score
- This score is a combination of things:
  - It uses a patient’s ApoE variant, “Is this patient three a 3, 3/4, 4/4, etc.?”
  - Then it looks at the ratio of two variants of amyloid beta, so amyloid beta 42 and amyloid beta 40
  - Then also looks at their age
  - With that info, it predicts the probability of AD pathology
- Note that we are still in very early days of knowing what to make of these data
- But Peter has two reasons that it makes sense to look at that data from C2N
  - 1 – it’s one more piece of information that helps us understand risk that can be looked at in combination with family history, genotype, metabolic health, ApoE status, cognitive testing
    - And it allows us to say, “Okay, is risk higher? Lower?”
- 2 – More importantly, as we make interventions/take steps to reduce risk, we would look to see what happened to that C2N score. Did it go up or down?
  - If it goes down, it’s NOT going down because their ApoE status changed, and it’s NOT going down because their age got younger, *it can only go down because the ratio of AB 42 to AB 40 changed*
  - And is that predictive of an improvement? … “I don’t know the answer.”

For the sake of completeness, we do also have amyloid PET scans, but it is not something Peter uses clinically—they’re typically done in a research setting

**More about the C2N test [10:45]**

Nick asks, “*Are you really only using that on very high risk, based on all the other factors?*”

- Peter says “yes” and that because you have to think every test has a sensitivity and a specificity
- When you take a sensitivity and specificity, you want to be able to say, “This has high positive predictive value and high negative predictive value”
- So if it comes back positive or negative, you want to be able to trust that it means something
- In addition to the sensitivity and specificity, which are fixed for a test, the way that you as a physician or person administering the test can increase the odds in your favor is by applying this test to patients with what we would call the “highest pre-test probability”

> “In other words, if you applied the C2N test willy-nilly across everybody, my fear is you would probably get a lot of noise and you’re going to get a lower positive predictive value.” —Peter Attia

- We have tremendous uncertainty about this C2N test, unlike, for example, ApoB, where we have really clear relationship between at least population risk and marker, therefore Peter is much more comfortable checking ApoB on everybody
- But when it comes to this C2N test, we have to reserve this for people who are at the highest risk

⇒ For anyone who wants to dive deeper on that sensitivity, specificity, positive/negative predictive value, check out [AMA #25](https://peterattiamd.com/ama25)

## Genetic component of Alzheimer’s disease: genes that confer risk [12:45]

***What do we know about genetic testing and what those results can mean in someone’s long- term risk of developing AD or dementia?***

- There is a strong genetic component to Alzheimer’s disease
- several genes that are implicated in this, but the three most penetrant genes are: PSEN1, PSEN2, and APP
- These genes are as close to what we would call *deterministic* as any genes are
- Fortunately, they are very rare and only account for 1% of AD cases
- Those patients get Alzheimer’s disease very early—it’s not uncommon for these patients to be afflicted in their 50s

Let’s focus on the other 99% of cases of AD

- So 99% of patients who go on to develop Alzheimer’s disease do not have one of the “deterministic genes”
- Of those patients, about two thirds have at least one copy of the ApoE4 gene
  - To put that in context, about 25% of the general population has at least one copy of the ApoE4 gene (most of them are just one copy)
  - Two copies of e4 is pretty rare—about 2% of the population
  - But that 25% of the population makes up two thirds of all cases of Alzheimer’s disease.
- So out of the gate, you realize, before you jump into the minutiae on this, clearly this gene is highly associated with Alzheimer’s disease
  - But this is not a deterministic gene
  - There are plenty of patients with ApoE4, one copy or even two, who never go on to develop dementia
  - There are even centenarians walking around with E4s, meaning there are people who make it to a 100 with no signs of dementia who are carrying E4s

There are other genes at play that can amplify risk and others that can attenuate risk.

- One variant of klotho, KLVS, attenuates risk in E4s
  - So an E3/4 carrier that has the klotho KLVS variant, their risk returns to that of a 3/3
  - A 4/4 carrier who has a klotho KLVS, their risk returns to almost a 3/3
- Conversely, the wrong mitochondrial haplotype will amplify risk
  - TGF-beta would be another one that amplifies risk
  - [TOMM40](https://en.wikipedia.org/wiki/TOMM40) would be another one that amplifies risk

*Testing for these genes*

- Some of these genes and SNPs can be identified on regular, call it, commercial over-the-counter tests such as [23andMe](https://www.23andme.com/)
- But truthfully, for most of Peter’s patients, they are doing whole genome sequencing on this particular topic because the error rate is lower and most of the genes that we care about are not genes that are showing up on the shorter SNP tests

## Understanding your APOE status and why it’s important to know [17:15]

***If someone gets their ApoE checked, what are the different combos that they could even see on that test?***

- There are three alleles for the APOE gene
- APOE is a gene which codes for a protein, unsurprisingly called ApoE
- But we have three different versions of that gene circulating in our gene pool
- E2 (most rare)
- E3 (most common)
- E4 (second most common)

These genes can therefore be combined in up to six ways, because you’re going to get one copy from your mom and one copy from your dad

- 2/2
- 2/3
- 2/4
- 3/3
- 3/4
- 4/4

Prevalence of these combos:

- 3/3 is most common at about 50-55%
- 3/4 accounts for about 25%
- 2/4 is the next most common at about 5-10%.
- 2/2 is the rarest
- 4/4 is the second rarest
- 2/3 is not that uncommon

*How easy is it to go about getting these other genetic tests to look for genes beyond ApoE4? Because ApoE4 is pretty easy to get checked.*

- The short answer is it’s really hard
- There is still no turnkey solution for looking at the entire suite of genes that are involved in Alzheimer’s disease, even kind of the 12 most relevant.
- For now, Peter works with Richard Isaacson and his team and brute force it by literally going through the whole genome sequence trying to identify these
- There’s a huge opportunity there to streamline this process, which again, wouldn’t be interesting if not for what we’re about to talk about today.
- In other words, I don’t know that this would matter a whole heck of a lot, unless you believed you could do something about it, which I think comes back to kind of a broader issue around ApoE4 testing

When the [Limitless](https://www.imdb.com/title/tt11714334/?ref_=fn_al_tt_1) show came out, there was a surprising amount of backlash against how irresponsible it was to test for ApoE in [Chris Hemsworth](https://en.wikipedia.org/wiki/Chris_Hemsworth)

- Peter says this is a meritless criticism, but at the same time, he can understand where it came from if you believed that having a copy of an ApoE4 gene, or two copies, was deterministic
- In other words, if you believed that having those genes means you’re going to get Alzheimer’s disease and nothing can be done about it, then at least you could entertain the argument of why know it now?
  - “Even if that were the case”, says Peter, “I still think that’s incorrect. I think knowing something allows you to plan accordingly”
  - “But I don’t even believe that premise. I do believe there’s a lot that can be done to delay onset and/or reduce risk.”

## The prevalence of Alzheimer’s disease and other forms of dementia, and who is at higher risk [21:15]

- Globally, the prevalence of AD is 2 to 1 in favor of women to men—so women are literally twice as likely to get Alzheimer’s disease as men.
- Interestingly, we see the reverse in Parkinson’s disease

![](https://peterattiamd.com/wp-content/uploads/2023/04/f1-ama46-1024x777.png)

**Figure 1.** Source: [Rasmussen et al. CMAJ Sept. 2018](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6148649/)

- Each figure is showing you men and women, so the women are in red, the men are in green
- The first column is showing you the risk of Alzheimer’s disease, the 10-year risk
  - So for a given age, what is the subsequent decade’s risk?
- Looking at the columns
  - So in the first column, that’s for Alzheimer’s disease
  - In the second column, that’s for vascular dementia, which is the second most prevalent form of dementia
  - The final column is just 10-year risk of all dementias (So that would include Alzheimer’s plus vascular, plus Lewi body, frontal, etc.)
- If you go by rows, you’re just looking at the decade in which we look
  - the top row is people in their 60s
  - The next row is people in their 70s
  - The final row is people 80 and up
- So not surprisingly, as you move down the rows, the numbers get bigger
- And not surprisingly, the third column has to be greater than the sum of the first two columns, because it includes both of them plus other things
- Lastly, each box shows the six genotypes, the six combinations
  - it always goes the same direction, E2/2, 3/2, 3/3, 4/2, 4/3 and 4/4, which is more or less in the order of risk
  - Although you’ll see that when it comes to Alzheimer’s disease, specifically, the 3/2 is the lowest risk.
  - In all cause dementia, 2/2 is the lowest risk
    - That probably has to do with the impact of the E2 genotype in Lewy body and other dementias. But we’ll put that aside for a moment.

Takeaways:

- What’s really obvious when looking at this is that the 4/4 has a significantly higher risk than everything else — and then the 3/4 and the 4/2 are kind of next
- We think of the 3/3 as the baseline, since that’s the most common genotype we see in the population, so everything gets compared to the 3/3
- You’ll also notice that at any point in time, women seem about 20% more likely in a given decade to get Alzheimer’s disease than men
- And what that suggests is that the 2 to 1 prevalence is probably a function of that coupled with the fact that women are living longer

## Can the risk of Alzheimer’s disease be decreased with behavioral changes? [24:15]

***How robust is the idea that prevention is possible for AD? And what more do we know about that side of it?***

- The bulk of today’s AMA is going to be around: *What are the measures that we can take? What are the modifiable behaviors that factor into risk reduction or prevention?*
- Here’s the problem, it is really difficult to do this directly with control trials, given the time course
- There are a couple of examples where we can pretty convincingly take a causal view, but unfortunately, much of the data here is epidemiologic

**Looking at the** [**Chicago Health and Aging Project**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8484773/)**:**

*Subjects*

- It followed nearly 4,000 individuals who underwent regular clinical and cognitive assessment from the early ’90s to about 2012
- These patients were 65 and older
- They had no Alzheimer’s disease at the outset
- They were all cognitively tested, and the bottom 10% of non-AD patients, in terms of cognition, were excluded
- They also excluded any patients who were 4/4s
- The goal was to remove subjects who were the most susceptible
- So if a patient is E4, you’re going to see that the data are divided between E4 and non-E4
- So the E4 segment is just 2/4s and 3/4s, and that was about a third of the sample
- And a third of the sample had no E4

*Study info*

- There was no intervention
- And Peter notes this study is full of limitations
- They looked at how these patients did over the subsequent 15 to 20 years based on the number of healthy lifestyle factors they engaged in
  - So healthy lifestyle factors are all the usual stuff (not smoking, getting good sleep, exercise, nutrition, etc)
- And they broke these folks into two buckets
  - Subjects were either were doing 0 to 1 healthy factors or 4 to 5 healthy factors
  - So they wanted to kind of create a gap

![](https://peterattiamd.com/wp-content/uploads/2023/04/f2-ama46-1024x596.png)

**Figure 2.** Source: [Dhana et al. Am J Epidemiol. July 2021](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8484773/)

- on the X axis is time
- on the Y axis is cognitive score
- On the left-hand side, you see the ApoE cohort
  - That means these are the third of the patients who were E4
- and then on the right-hand side, you see the patients who had no E4
- The solid line shows you the people who were in the zero to one healthy lifestyle factor
- and the dotted line is the four to five
- You might be asking, “Well, why is this such a straight line?”
  - it’s because this is a linear model of cognitive decline based on this global cognition score done from four tests over the 17 years
- The shaded areas, your 95% confidence interval
- These models were adjusted for all the usual suspects, age, sex, race, ethnicity, total education, presence of other diseases such as cardiovascular disease, etc

**Takeaway**:

At the beginning of the study, all four groups had about the same cognitive score

What happens is two things:

- 1 – The E4s, even with healthy behaviors still fall faster than the non-E4s with healthy behaviors
  - So it really speaks to the risk of E4 later in life
- 2 – But the other thing of course that stands out is healthy behaviors offset much of that risk
  - So in other words, the rate of decline of the E4s doing the healthy things seems to be identical to the non-E4s who are not engaging in the healthy behaviors
  - In other words, this suggests that **you have some control over this. This is malleable**.

Other observations:

- If you look at the left-hand graph in the dotted line, including that confidence interval, it’s basically identical to the solid line on the right
- Another way to look at this is: *healthy behaviors have a greater impact on E4s than non-E4s*
- The lift that you can get with healthy behaviors seems to be even greater as an E4, than as an E3.

## Overview of modifiable behaviors that potentially play a role in risk reduction of neurodegeneration [30:15]

- We’re now going to spend the rest of this AMA with the true focus of what are these things that you can do to prevent Alzheimer’s dementia and work to keep your brain as healthy as possible?
- The most valuable thing would be to talk about the non-obvious things
- We’ve got like 13 things on the list that we think play a role, potentially, in risk reduction
- But we believe that five of them are so obvious that we are not going to spend much time on it at all, other than to maybe demonstrate the risk associated with the behaviors

So the five that we’re going to spend scant time on are smoking, alcohol consumption, sleep, head injuries, and blood pressure control

- It shouldn’t come as a surprise to anybody that:
  - Not smoking is better for your risk of Alzheimer’s
  - Less alcohol consumption is better for your risk
  - Adequate sleep is better for risk
  - fewer head injuries
  - and well-controlled blood pressure

What we will spend a little bit more time on are the other things that are less obvious, or at least the way the questions are framed makes them less obvious

- Exercise is one of the things in that bucket, although Peter would argue that exercise is the most obvious thing of them all
  - What we’re going to talk about there is minimum effective dose
- We’ll also talk about:
  - Lipids
  - type 2 diabetes
  - Nutrition
  - Supplements
  - Learning and cognitive activity
  - Brain games
  - Hearing loss
  - Sauna
  - and oral health

**Casual vs. associative**

- Virtually everything we’re about to talk about today has an associative relationship to brain health, either positive or negative
- But for the most part, the evidence is not really strong enough to determine if that relationship rises to the level of causality
- In Peter’s estimation, the only ones where we can really draw clear causal relationships of the soft ones are probably exercise, hearing loss, lipid management, and probably type 2 diabetes
- A lot of the other things we’re going to talk about are going to be associative, and therefore there’s going to be a lot to interpret

## Things that clearly impact brain health: smoking, alcohol, sleep, head injuries, blood pressure, and more [34:15]

**Smoking**

- When it comes to smoking, we don’t really have great experimental data that smoking is bad for you. No one’s doing the randomized trial to demonstrate that smoking causes lung cancers
- But the epidemiology is pretty overwhelming and dementia is no exception, although admittedly, the risk of smoking to dementia is less than the risk of smoking to lung cancer and heart disease
- The bottom line is we’re talking about a roughly 60% increase in the risk—so at any point in time, a smoker compared to a non-smoker is going to have about a 60% higher chance of all-cause dementia
- Here’s the best news: it seems that once you have quit for at least nine years, your risk falls to that of a non-smoker
- If you’re 50 years old and you’re smoking, stop it because by the time you’re 59, at least from the standpoint of this risk factor, you will be back to baseline and that’s fantastic news.

**Alcohol**

- There’s an [alcohol paradox](https://nutrition.org/french-paradox-really-wine/)
  - Some people have claimed that there is a backwards J-shaped morbidity curve associated with alcohol
  - The lowest risk is at a couple drinks a week and then risk goes way up
  - But if you go down to no alcohol, risk goes up
  - It turns out that that’s almost entirely confounded by the population of people that are consuming zero alcohol

*Epidemiology data*

- If you do want to take the epidemiology at its nameplate face value, the answer would be you will have about a 30% risk reduction of all-cause dementia if you are consuming less than 12 drinks a week versus if you’re consuming more than 12 drinks per week
  - “Do I take that to mean that it’s okay to drink up to 10 drinks a week? ⇒ I don’t think so. I would say that 12 drinks a week is probably too much”
- When you look at the Mendelian randomization…
  - Peter goes back to where we were earlier, which is he thinks that 7 to 8 drinks a week should probably be considered the max and there shouldn’t be more than two in a day

*Alcohol and ApoE4*

- There’s a tiny bit of evidence from one [cohort study](https://www.bmj.com/content/329/7465/539?ecoll=) that patients who have E4 may be slightly more susceptible to alcohol than patients with E3
- This was a relatively small study with about a thousand subjects age 65 to 80
- It’s not that well done in that it didn’t really do a great job of keeping track of exactly how much people drank—the buckets were pretty broad:
  - It was never
  - Infrequently (once per month)
  - Frequently (several times per month)
- By that metric, “virtually everybody I know, including myself, is a frequent drinker because I certainly drink more than several times in a month”
- It was a long follow up, 20, 23 years
- When you compare the E4 carriers who never drank to those who drank infrequently, infrequently meaning not that much, there was still a 2.3X difference in the risk of dementia
- When you compared the never drinkers in E4 to the frequent drinkers in E4, there was a 3.6X delta. That’s 260% difference in the risk of dementia
- There was no difference in this analysis when it was determined between non-E4s
- Peter wishes that the study could have been done where we had much more gradation on the alcohol consumed
- But again, it’s very hard to make a case that alcohol is good for Alzheimer’s disease

**Sleep [39:30]**

- Sleep suffers from a lot of the epidemiologic baggage that comes with things that aren’t easy to study prospectively
- But it’s easier epidemiologically to study than things like exercise and things like nutrition because the intervention itself is so straightforward and it’s generally much easier for people to recall how long they sleep than what they ate, for example
- When it comes to Alzheimer’s disease risk…
- we’re seeing about a 60% increase when it comes to all-cause dementia,
- we’re seeing about a 20% increase for people who have disturbed sleep versus not disturbed sleep
- When we start to get into short sleep, comparing people with less than five hours of sleep to people with more than seven hours of sleep, you’re talking about a hazard ratio of 2.6, meaning 160% difference in all-cause dementia

⇒ See [episodes with Matt Walker](https://peterattiamd.com/matthewwalker1/) for more

**Head injury [40:45]**

- Head injury is something we’re becoming much more aware of lately
- It looks pretty clear that head injury does increase relative risk
- The risk looks like it’s about an 80% increase for all comers
  - Does that include someone who just got a concussion? Probably not
  - Does this include repeated blows to the head? Probably
  - Does this rise to the level of a TBI? Probably – Peter thinks we’re talking about severe head injury that would increase risk

One of the biggest questions Peter has is: Do E4s stand at higher risk in the context of head injury?

- Why is this a relevant question? Well, for young people who are E4, it might impact the choice of sports that they might play, for example (e.g., football vs. track)
- Animal models certainly suggest that E4s will generate more neurodegenerative pathology, specifically hyperphosphorylated tau pathology in the presence of TBI, traumatic brain injury, than E3s

*Hyperbaric oxygen as a therapy for TBI*

- The evidence that hyperbaric oxygen for TBI therapy is currently not very strong, but it is emerging
- The downside of hyperbaric oxygen for this application is lower than the upside is higher
- [Dom D’Agostino](https://peterattiamd.com/domdagostino/) has got a lot of experience on this and Peter reached out to him
  - What he told Peter is that the current protocols that they’re using for TBI are 40 to 80 sessions over eight to six weeks at one and a half atmospheres for 60 minutes per session
  - That’s a pretty big commitment of time if you think about that—That’s 10 hours of your week if it’s half an hour to drive to and from the chamber
  - It’s a big cost, both financially and terms of opportunity cost
- *Would Peter do it if he had a TBI?* — “I would and I would do it even with the paucity of data we have now because I think this is asymmetric”

**Blood pressure management [43:45]**

- We know that blood pressure plays a big role in vascular health and vascular health plays a big role in brain health
- Anything that reduces blood flow, anything that reduces oxygenation, anything that reduces availability of nutrient is going to be very bad for the brain.

*The best study to look at this was the* [*SPRINT MIND trial*](https://jamanetwork.com/journals/jama/fullarticle/2723256)

- Subjects and design
  - This trial that compared two different blood pressure lowering targets
  - one group that had a target of systolic blood pressure below 120
  - and another group that was targeted to 140
  - followed these two groups for almost three and a half years
  - just under 10,000 subjects
- The question was, *how many of them developed incident dementia or cognitive impairment in that period of time*?
  - three years of treatment with a median follow-up time of about five years
  - The risk reduction if you were lowered to 120 instead of 140 was about 16% was the relative risk reduction
  - The absolute risk reduction was 0.6%

*Is an ARR of 0.6% not worth caring about?*

- that might not sound like a lot because at 0.6% you would need to treat, oh, I don’t know, doing the math, 180 people to prevent one case of dementia
- Peter always cautions people when they jump too quickly to the conclusion that a low ARR isn’t worth paying attention to because **you have to look at the time course**
  - This intervention period was only three years and the follow-up was only five years
  - When you’re talking about chronic diseases like this, you have to really ask the question, over time, is this likely to get bigger or smaller?
    - Answer’s pretty clear. It’s going to get bigger
  - If you had adequate blood pressure control over 10 years or 20 years and your follow-up period was the duration of life, how much is that ARR and RR going to be?

## How nutrition impacts brain health: common diets, metabolic health, energy balance, and more [46:15]

***As we think about nutrition and as they think about brain health, what are the most important considerations they should think about there?***

- There’s a fundamental problem here, which is not to suggest that nutrition isn’t important
- Peter is going to suggest is that it’s probably less important than people realize beyond the really big issue of energy balance and most importantly, type 2 diabetes
- The way we really want to go about answering this question is: *we want to look at what the increase in risk is for patients who have type 2 diabetes*
  - It’s very difficult to assume that that risk isn’t real, that it’s not causal
- Then we want to ask the question: *How big is that compared to the magnitude of the benefit from following any one of these “magical” diets*?
  - “My hypothesis is none of the benefits of those diets will be nearly as big as the detriment associated with having type 2 diabetes”
  - The implication of that is that n**ot having diabetes, not being insulin-resistant and being in energy balance has more benefit than anything else**
  - And therefore the right diet is whatever diet keeps you insulin-sensitive in energy balance, and obviously therefore, not having type 2 diabetes

**Prospective cohort** [**study**](https://jamanetwork.com/journals/jama/fullarticle/2779197) **in the UK**

- They take a cohort of 10,000 people and at least followed them prospectively, but there’s not an intervention
- 16.9% of the patients went on to develop type 2 diabetes.
- 6.3% of the participants went on to develop dementia
- This now becomes a very elegant way to look at the Venn diagram of who had diabetes, who didn’t, who had dementia, who didn’t
- The hazard ratio here for lifetime exposure was 1.58, meaning there’s a 58% increase in the risk of dementia if you develop type 2 diabetes
- Now at age 70, every five year younger age at onset of type 2 diabetes was associated with a hazard ratio of 1.24—That’s saying if you look at five-year chunks, your risk is 24% in five-year chunks
- The other takeaway from this when you look at the development was that the earlier you got type 2 diabetes and the longer you had it, the greater your risk of dementia
  - “That’s a very important finding in the epidemiology”
  - The [Austin Bradford-Hill criteria](https://en.wikipedia.org/wiki/Bradford_Hill_criteria) are basically nine things that give you a sense of how much do you believe your epidemiology
  - Among those criteria are things like strength of the association, reproducibility, dose effect and timing, etc.
  - Peter says we see strong examples of all of those things in the [UK cohort study](https://jamanetwork.com/journals/jama/fullarticle/2779197)
- This study also looked at patients who made it to the age of 70 without developing diabetes, and then they compared them to age-matched people who were at least 10 years with diabetes
  - In other words, we’re going to take a group of 70-year-olds and we’re going to compare them to people who have had diabetes since they were younger than 60
  - Here you saw an even greater hazard ratio than just the all-cause—these folks had a 2.32 hazard ratio
  - That means there’s 132% greater chance of developing dementia

> “The bottom line here is the earlier you were diagnosed with type 2 diabetes, the higher your risk of dementia.” —Peter Attia

**Differential E4 Risk**:

- ApoE4 significantly modified the risk for AD in diabetic subjects in the Honolulu-Asia Aging [study](https://diabetesjournals.org/diabetes/article/51/4/1256/34635/Type-2-Diabetes-APOE-Gene-and-the-Risk-for) (2574 Japanese American men).
- The joint effect of diabetes and ApoE4 was synergistic, causing a more than five-fold increase in the risk for AD for subjects with diabetes and ApoE4 compared with those without the two risk factors.
- The hazard ratio was 5.5
- It’s important to understand that this relative risk increase, this 5.5 increase in risk, which was for the ApoE4s that had diabetes was in the context of a study that wasn’t a very high prevalence
- This was a group of E4 subjects whose total Alzheimer’s risk in this study was 1.8. So in other words, if you take all the people with E4, their total increased risk here was 1. 8 was their hazard ratio, all-cause dementia by the way was 1.5
- but when you also combined it with type 2 diabetes, that risk nearly tripled to 5.5

**Obesity**

\*Check out the [episode with Stephan Guyenet](https://peterattiamd.com/stephanguyenet/) and with [David Allison](https://peterattiamd.com/davidallison/) where they discussed the [obesity paradox](https://en.wikipedia.org/wiki/Obesity_paradox)

- We can pretty safely say that getting type 2 diabetes is really bad for your risk of Alzheimer’s disease and it might be even worse if you carry an E4 gene
- But what about obesity *without* type 2 diabetes?
  - It seems to be that there’s a bit of a paradox here

**Let’s look at this** [**meta-analysis**](https://onlinelibrary.wiley.com/doi/10.1111/j.1467-789X.2010.00825.x)**…**

- Looked at 16 studies and it looked at people who were obese
- In midlife, so people age 40 to 60, the relative risk increase for developing AD was 2.04
- You have a 100% increase in the risk of developing Alzheimer’s disease
- When it comes to any form of dementia, it was still enormous, 1.64, meaning a 64% increase in risk.

*Here’s where it gets a little bit interesting…*

- Later in life, we didn’t see quite the same finding
- Low BMI is not necessarily protective, but obesity doesn’t seem to be as harmful
- In fact, if you look at late life obesity, it was non-significant
- The hazard ratio is 1.46, which looks like a 46% increase, but the hazard ratio was 0.97 to 2.21, which means it was almost statistically significant, but not quite
- It was even a broader confidence interval for any form of dementia
- The hazard ratio here was actually quite small, 1.11 and the confidence interval 0.8 to 1.55

*Now, let’s go back to the relative risk for Alzheimer’s disease and obesity late in life…*

- When your confidence interval is 0.97 to 2.21, you could argue you were underpowered to see a difference and the trend is very close and maybe there’s a difference
- Alternatively, and this is where the obesity paradox comes in, once you get later in life, lower BMI patients are actually dragging down the health of the “non-obese”
- This is because you’re going to see more sarcopenia, more chronic disease, more COPD, more end-stage renal disease
- A lot of the chronic diseases are things that show up late in life and are probably increasing your risk of dementia as well indirectly, just through poor nutrition, poor exercise, all the other things, and they’re going to be low BMI states
- This is why Peter believes we see this “obesity paradox” show up later in life
- The biggest problem here is that BMIs are a crappy metric b/c it doesn’t capture what you care about most
- If we did these data by ALMI, visceral fat, or even body fat, we’d likely get a totally different answer

> “But absent that, what I think we can say very comfortably, type 2 diabetes, you just want to avoid that all day long.” —Peter Attia

## Comparing common diets: data showing the association between the incidence of Alzheimer’s disease and specific diets [59:45]

We’re now going to double click on some diets and talk about a few in particular

People do ask a lot of questions such as, “Are there specific diet or nutrition recommendations that you think would be helpful?”

- Peter says, “from where I sit, it’s not clear, but let’s just look at what the data are and we can decide how much weight to put on these”

[**PREDIMED study**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4339461/)

- PREDIMED is probably the best nutrition study that’s ever been done
- It was a study that was done in Spain and it was scheduled to be maybe a five to seven-year study
- It was halted at four and a half years when its primary endpoint was met, which was a reduction in cardiac disease
- It had three groups in it
  - 1) low-fat group
  - 2) Mediterranean diet with olive oil as the main fat
  - 3) Mediterranean diet with nuts as the main fat
- What makes the study pretty good is that the adherence to the diet seems to be pretty good
- Right out of the gate, there’s a little bit of a problem in study design because the low-fat group didn’t get an equivalent low-fat food—This is something called performance bias
- The other major issue with this study was that there turned out to be after publication, a realization that the randomization was not purely random. People who were in the same house who enrolled in the same study were not randomized and it required a statistical adjustment
- When that statistical adjustment was done, the results were unchanged, but it hangs as a little black cloud over that study

[Cognition portion of the PREDIMED study](https://jnnp.bmj.com/content/84/12/1318.short)

- Investigators carved out a fraction of the studies
- There were like 7,500 subjects in that study, so 2,500 in each group, but they carved out a little over 500 of them in the upper echelon of age (about 75 years old)
- They were also tested for global cognition using the [Mini Mental State Exam](https://cgatoolkit.ca/Uploads/ContentDocuments/MMSE.pdf) (MMSE) as well as the [clock drawing test](https://www.verywellhealth.com/the-clock-drawing-test-98619)
- The big challenge here is they didn’t do this at the outset, likely because they didn’t realize how good the study was going to be, so they don’t have baseline tests on those folks
- So you’ve got these ~500 people who were put into each of these groups—adjusted for age, sex, education, APOE, family history, dyslipidemia, diabetes, alcohol intake
- They compared the controls to just the olive oil group at the completion of the study and there was a significant difference in mini mental status exam and clock drawing test—they were *significantly better*
  - The same was true when you compared the nuts group to the control group
- There was no difference, by the way, between the nuts group and the olive oil group, which was the exact same as we saw in the study
- But again, it was a relatively small sample size and don’t have baseline cognitive function, so take that for what it’s worth

*Peter’s struggle with the “this diet vs. that diet” arguments:*

- I struggle so much with named diets because I don’t know what they mean
- Some of them are very specific
  - A keto diet has strict enough markers, but even that, even a keto diet is such a dumb name. You can go on a keto diet where you’re eating lots of vegetables and you can go on a keto diet when you’re not eating lots of vegetables
    - Are those two the same diet? — I hardly think they are
  - Similarly, a Mediterranean diet can have a lot of different meanings, and including in this study
    - One is basically all olive oil, the others all nuts

Outside of PREDIMED, let’s just talk about the **three named diets** that seem to get most of the attention

- 1 – DASH diet
- 2 – Mediterranean Diet
- 3 – MIND diet

![](https://peterattiamd.com/wp-content/uploads/2023/04/f3.-Mind-diet-study-points-table-ama46.png)

**Figure 3.** Dietary component servings and maximum scores for the DASH, Mediterranean and MIND diet scores. [[Morris et al., 2016](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4532650/)]

**Diet Takeaway**

- One of the biggest things that stands out is the MIND diet is very liberal on red meat whereas the Mediterranean is really restrictive on red meat
- The mind is also very much encouraging you on the berry side of it
- MIND and Mediterranean are both heavily fixated on the amount of olive oil that one consumes.

![](https://peterattiamd.com/wp-content/uploads/2023/04/f4-ama46.png)

**Figure 4.** Proportional hazards ratios (HR) and 95% confidence intervals (CI) of estimated effects of MIND diet score on time to incident Alzheimer disease in age-adjusted (n=923; 151 AD cases) and basic-adjusted\* (n=789; 135 AD cases) models in MAP participants over a mean 4.5 years of follow-up, 2004-2013. [[Morris et al., 2016](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4532650/)]

*So what can we say about these things?*

- In a [cohort study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4532650/) of just under a thousand subjects, dietary questionnaires—so right off the bat we’re struggling with this—were used to determine basically each subject’s adherence to each of the three diets
- And you get points for everything in the diet — you tally up the number of points to show adherence
- They did two neuropsychological assessments at the beginning to ensure that the patients didn’t have Alzheimer’s disease at baseline
- over the course of 4.5 years, 144 of the 923 participants went on to develop Alzheimer’s disease
- And this was done in an older cohort
- For each diet, participants were divided into tertiles based on their dietary score—meaning how adherent were they to the diet
- Both the second and highest tertiles of the MIND diet scores—meaning the top two most adherent of the MIND scores—had lower rates of Alzheimer’s disease compared to the first tertile
- But only the highest of either the Mediterranean or the DASH had reduced rates of AD compared to the lowest tertile
- The takeaway from that is if you’re consuming the MIND diet, you don’t have to be quite as diligent and compliant as you do the Mediterranean or DASH
- Again, high adherence to all three of these diets seem to reduce the risk of AD and moderate adherence to the MIND diet may have also done the same
- Was the magnitude of reduction enormous? ⇒ It depends if you believe the data
- If you look at the highest tertile, it looks like a 50% reduction
- If you look at the top two tertiles for the MIND diet, it was about a 35% reduction.
- This is interesting in that you’re starting with a patient population that was obviously very high risk if you’re getting 144 cases of AD in four and a half years out of 923 participants
  - Does this make the case for this MIND diet? — “I’m not sure”
- The most compelling evidence Peter sees is probably for the use of olive oil
  - Why? Probably due to some of the phytochemicals that are in it

*Other observations*:

- If you look back at what’s in the MIND diet, you’ll notice it’s not very heavy on fish
- The Mediterranean diet is the diet that says you got to have fish basically every day whereas the mind diet says you just need it once a week
- The other thing that’s interesting is the Mediterranean diet says you can only have red meat once a week, whereas the MIND diet says you can have red meat and red meat products four times per week
- The biggest difference here is the MIND diet’s greater focus on greeny, leafy vegetables, less whole grains, more red meat, less fish, and they’re very explicit in calling out fast and fried food, and olive oil is your primary oil

Peter’s thoughts:

“*I’m not sure what to make of this. Ithink I’m back at the point of: maintain energy balance, stay insulin resistant. We’ll talk about the lack of clear causality there, but I think the reason I just don’t like talking about this is I don’t really know what to say*.”

Current Nutritional intervention [RCT](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8042655/) for the MIND diet

- 3-year study of 604 individuals ages 65 to 84 years were randomized to either the MIND diet with mild caloric restriction or their usual diet with mild caloric restriction
- foods featured as key components of the MIND diet (i.e. extra-virgin olive oil, blueberries, and nuts) provided for participants
- MRI scans of brain structure and volume that may provide potential mechanistic evidence on the effects of the diet
- No outcome data published yet

## Supplements: EPA and DHA, vitamin D, and B vitamins [1:13:00]

**EPA and DHA, vitamin D and B vitamins**

- If you have true deficiencies in these things, you do have a problem
- \*The following is true for EPA and DHA, this is true for vitamin D, and this is true for B vitamins:
- We have no idea if these biomarkers themselves—or the things that they change such as B vitamins and their relationship on homocystine—are causal or not
- I’m going to make you a compelling case for why there’s **epidemiologic** data for all of these things, but if it’s NOT causal, then fixing it doesn’t fix the problem. If it IS causal, then fixing it does fix the problem
- For instance, we know APOB is **causally** related to cardiovascular disease, and we know smoking is **causally** related to cancer, and *that’s why targeting causal metrics fixes problems.*

**EPA and DHA – what do we know?**

- We know that EPA and DHA are able to cross the blood-brain barrier
- We *think* that APOE4 carriers might benefit from higher levels of Omega-3’s before the onset of disease
- So DHA is present in large amounts in neurons, specifically the membranes of phospholipids where it’s involved in kind of a number of things
- If you look at a [mouse model of AD](https://www.jneurosci.org/content/25/12/3032.short), overall plaque burden is reduced by a lot, 40% in mice who are on a diet that’s enriched with DHA compared to a placebo.
- However, if you look at the *human* data, it’s not quite as clear

Here’s one six-month [RCT](https://pubmed.ncbi.nlm.nih.gov/17030655/) in humans:

- The study found no difference
- it’s a tiny short study, takes 174 patients with mild to moderate AD and it randomizes them to placebo or a group getting 1.7 grams of DHA and 0.6 grams of EPA and found that in the six months that they were followed, there was no difference in the rate of decline for cognitive function
- “That’s silly.” says Peter
- A study like this should have more patients and you’d need a longer study
- And Peter isn’t so sure that 1.7 grams of DHA and 0.6 of EPA is the right dose
- But of the three things where they didn’t do a good job on the study:
  - duration is the biggest problem,
  - sample size next, and
  - then the dose is probably a bit low

Another six-month RCT in humans:

- It looked at AD patients treated with EPA and DHA
- They didn’t look at cognitive outcomes, they looked at inflammatory markers like interleukin-1, interleukin-6, and a number of other markers of inflammation
- They found that there was a reduction in those markers over six months
- So is that relevant? — “I don’t know. Maybe there’s a benefit to using EPA and DHA as a means of reducing inflammation. This is pretty indirect.”
- We believe that the release of interleukin 1B and IL6 and TNF alpha from microglia cells in the brain can lead to dysfunction of neurons in the brain
- But this study looked at a reduction in inflammatory markers secreted by peripheral blood mononuclear cells, PBMC’s
- “So there’s a leap of faith here we have to take, and I’m not convinced that there’s a benefit”
- Peter states that he, personally, still takes EPA and DHA as a supplement, but he doesn’t push this on every patient because there’s a small, but non-zero, risk of Afib that comes with high doses of EPA and DHA

Hopeful study on EPA and DHA in the future:

- Peter says we need a study that has the right patient population—presumably you want to do this in a patient that’s high enough at risk that over a period of a decade or so you would see a meaningful difference
- But again, logistically, not a lot of interest in funding such work

**Vitamin D [1:18:00]**

- Vitamin D is a contentious topic within all of medicine
- Vitamin D levels are correlated with low levels of vitamin D are very correlated with poor health and poor cognitive outcomes
- The question is, is that association causal?

**Measuring vitamin D levels in people**

When you measure vitamin D levels in people, there’s two variables:

- 1 – Exposure to sun
- 2 – The genetics of the conversion, which varies by individual, varies by race, all sorts of things
- And of course exposure to sun is itself a function of multiple variables—outdoor activity and where you live
- You could take two people that are equally active, but they live at different latitudes and obviously they’re going to have different sun exposures even if they’re outside the same
- Similarly, you can have people of different genes, inclusive of skin color by the way, but not exclusive to that, and you’re going to see different conversion levels
- All that is complicating the hell out of the problem before you even introduce the idea of then adding supplemental vitamin D

**Data**

Basically all the studies are sort of saying the same thing, which is when you measure low levels of vitamin D in people, the risk of AD seems to be higher

![](https://peterattiamd.com/wp-content/uploads/2023/04/f5.-vit-D-table-ama46.png)

**Figure 5.** Links: Health ABC [Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3989387/), Multiethnic [Cohort](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5023277/) of Older Adults, Elderly U.S. [Population](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3011960/)

**The jugular question**: *Is giving vitamin D going to fix the problem?*

- The few times this has been asked in a clinical trial, the answer has been no
- Peter would argue it’s been “no”, because the trials haven’t been asking the question correctly
- They haven’t been asked the question correctly because they haven’t been long enough
- They usually give a very low dose of vitamin D. A typical study is 2000, maybe at the outside 4,000 IU per day
- Perhaps most importantly, the biggest studies that have looked at this haven’t been personalized in the way that they administer vitamin D, meaning they’re not dosing based on level, they’re dosing just based on the treatment arm you wind up in

*A better way to study vitamin D*

- A more interesting study would be, you take a whole bunch of people who are walking around naturally at 20 to 30 nanograms per milliliter of vitamin D
- You would randomize them into two groups such that one group stays the course and the other group gets supplemented up to a sizable difference, call it 60 nanograms per milliliter
- And for some people that might only require 2000. For some people that might require 4,000 IU so it that it might be different dosing to get people there
- Then you follow them for outcomes.

*Why Peter is skeptical of vitamin D as the “panacea of health”*

- Peter takes vitamin D in the winter he is not getting a lot of sun, but he admits that he has no idea if it’s doing anything

> “I think deep down I have this nagging belief that vitamin D is kind of a marker for people who are outside doing things that are physically demanding. —Peter Attia

- Usually, if you’re outside in this day and age, it’s by choice—you’re working outside, you’re exercising, you’re playing, you’re doing something outside, and there are health benefits that come from that
- He just thinks that that’s probably where we see the strength of the association, which doesn’t mean that supplementing won’t play a role, but we don’t yet have the studies to properly assess that

In short,

- Peter has a very “lukewarm” recommendation on this (same with EPA and DHA), which is that there is probably no downside in supplementing to physiologic upper levels
- Most lab tests would consider 30 to 100 as normal, but Peter thinks 40 to 60 might be closer to “normal”

**B vitamins [1:22:30]**

- When it comes to the B vitamins, we’re really going to talk about the *methylated B vitamins, typically B methyl folate, B12, B6, B1, etc*.
- We don’t know if homocysteine is **causally** versus non causally related to brain health
- Everything we think about when we think about using B vitamins, and specifically methylated B vitamins, is that they reduce homocysteine… **that is undeniable**
- Peter tracks homocysteine in patients and he uses methylated B vitamins to lower it
- He wants to see the patients’ homocysteine below 9, and he sees people that sometimes show up with a homocystine of 20

*Is there a relationship between homocysteine and brain health?*

- Yes, it’s pretty clear
- Homocysteine is a pretty significant marker for white matter damage
- Homocysteine in the plasma levels that are a standard deviation above the mean show greater white matter hyper-intensity volumes on MRI than people who have normal levels
- There’s lots of epidemiology that’s equally interesting around other things with homocysteine such as cardiovascular disease

**Studies around memory**

- Epidemiological and prospective longitudinal [studies](https://pubmed.ncbi.nlm.nih.gov/16254972/) suggest a link between Hcy and cognitive impairment
- A study with 2200 subjects with memory deficits based on an object learning test
- If you basically divided people up by deficit, the ones that had more deficit had higher homocysteine
- So the risk of memory deficit increased in according to the quintiles of homocysteine at both baseline and follow up
- Again, says Peter, “I don’t know if that’s *causal*”
- It could be that homocysteine is a marker for something else that is causal and that if you change homocysteine, you’re not changing that underlying thing.
- Peter says that, again, he has a “lukewarm” recommendation around B vitamins

*When he gives it to patients*

- Methylated B vitamins are especially important in people who have MTHFR genotypes that make it difficult to methylate
- We do use homocysteine as the biomarker just as we use vitamin D levels and RBC levels of EPA and DHA for the previous two supplements
- So we know how to dose these things to get the desired outcome either in the tissue or as a related biomarker
- We don’t know if these are *causal*

## Supplements: theracurmin, cocoa flavonols, and magnesium L-threonate [1:25:15]

**Supplements**

- 1) Cocoa Flavanols
- 2) Theracumin
- 3) Magtein: a specific supplement called magtein which is magnesium with L-threonate (which is a transporter)
- You’re not going to get these from food—you can really think of these as almost drugs
- Internally, Peter’s team gives these a score on a scale of 1 to 10 of how much confidence we have that they’re doing something

**Theracurmin**

- Theracumin, we would give the highest score to, at about a 6 out of 10
- You can make the case for patients who have inflammation or maybe even patients who are in the earliest stages of MCI

Studies

- The first is an [18-month study](https://www.sciencedirect.com/science/article/pii/S1064748117305110)
  - 40 subjects
    - Half of subjects randomized to 90 milligrams of Theracurmin twice a day
    - and then an equal number assigned to a placebo
  - These people were deemed to have kind of normal aging or MCI but not have dementia
  - The outcome of this test was looking at amyloid PET scans
  - Over a relatively short period of time, which was 18 months, the amyloid PET scans showed that behavioral and cognitive benefits were associated with either a decrease in plaque entangle accumulation in the brain regions that modulated mood and memory—which was mostly the amygdala—or a suspension of further plaque entangle accumulation in the hypothalamus
  - That’s probably why we would give this our “least bad” assessment
  - This is one of the supplements Peter takes
- Looking at a six-month retrospective [study](https://pubmed.ncbi.nlm.nih.gov/34939543/) of patients treated who had AD
  - 19 of them had Alzheimer’s disease
  - 17 had mild cognitive impairment
  - 57 were controls
  - The two treatment groups were treated with 180 milligrams per day
  - they saw that the cognitive scores and activities of daily living scores decreased in the AD patients not treated with Theracurmin, whereas the scores were stable in those with Theracurmin
  - In other words, the patients with disease remained stable on the Theracurmin, but if they were not on the Theracurmin, they continued their decline
  - “Based on this, we say maybe there’s something to [Theracurmin]”

**Cocoa flavanols [1:28:30]**

- Cocoa flavanols probably work through sort of vascular means
- There’s something called nitric oxide synthase—it’s an enzyme that makes nitric oxide
- By the way, this is how homocysteine is working and it **might** be causal through this pathway
- Homocysteine also inhibits something called asymmetric dimethyl arginine, and that plays a role in impairing nitric oxide synthase
- So if you reduce nitric oxide synthase, you produce less nitric oxide, you have less vascular dilation
- So Cocoa Flavonoids seem to increase the bioavailability of nitric oxide by increasing the activity of the sort of endothelium derived nitric oxide synthase.

*Studies with cocoa flavanols*

- [Study](https://pubmed.ncbi.nlm.nih.gov/22892813/) looking at older individuals with mild cognitive impairment
  - Subjects were randomized to consume basically three doses
    - 990 milligrams
    - 520 milligrams
    - or the low dose of 45 milligrams (basically the placebo)
  - After just eight weeks, both flavanol groups (990 mg and 520 mg) showed improved cognition which was measured by faster time to complete neuropsychological tests that measured processing speed, executive function, and language
- There were similar results that were found in a [2015 study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4340060/)
  - It’s interesting that in both of these studies, there was also an improvement in blood pressure and insulin resistance
  - Blood pressure was not that big an improvement about two to three percent, but insulin resistance was a pretty big 20% to 40% reduction and a reduction in oxidative stress
  - “*I think there’s some proof of concept here. Maybe there’s something to be said for these indirect mechanisms that are contributing*.” says Peter
- [Cosmos Mind study](https://alz-journals.onlinelibrary.wiley.com/doi/full/10.1002/alz.12767)
  - 2200 subjects
  - It found that there may be a dose-dependent effect
  - At 500 milligrams there was no cognitive benefit
  - At over 900 milligrams per day there was a benefit
- Peter says that it may be the case that this benefit was only in those with hypertension or insulin resistance

> “So again, this is not a particularly clean story, but none of these supplements are clean stories if you turn the lights on all the way.” —Peter Attia

⇒ Peter wrote about the Cosmos Mind Study [here](https://peterattiamd.com/can-cocoa-help-prevent-cardiovascular-death/)

**Magtein (magnesium with L-threonate ) [1:31:15]**

- In [animal studies](https://www.bw.edu/Assets/academics/andrew-mickley/chronic-dietary-magnesium-l-threonate.pdf), rats demonstrate an increase of brain magnesium as measured by magnesium and cerebral spinal fluid
- We can’t do this in humans, so we’re kind of taking a leap of faith that this is working in humans, as well
- Magnesium by itself doesn’t really cross the blood-brain barrier, but when you bind it to L-threonate you’re going to get better crossing into the brain.
- This is the biggest stretch here — Peter only gives this a 2 out of 10 which means if you’re completely cost agnostic (it’s not cheap) and you’re looking for just every possible inch, maybe there is something to it
- In terms of helping with sleep, you can get far more bang for your buck with things like glycine, ashwagandha, and even phosphatidylserine just on the sleep front between nutrition and supplements (See [AMA #42](https://peterattiamd.com/ama42/))

## Impact of exercise on brain health, minimum effective dose, and the most important types of exercise [1:33:00]

Exercise is a very broad drug which exerts its benefits across so many channels

- It increases growth factors that neurons love, like BDNF and IGF1
- It regulates inflammatory cytokines, it relieves oxidative stress, increases cerebral blood flow, and overall blood flow, reduces amyloid beta concentration, inhibits, tao phosphorylation, all sorts of things

**The premise**: *Let’s say people have three hours a week for exercise, what should they be focusing on? How should they break it up?*

- First, consider why we’re talking about 3 hours per week — the data are pretty clear that going from a hundred percent inactivity to just three, really well thought out hours a week is almost a 50% reduction in mortality
- Meaning, at any point in time, your risk of dying is half what it once was for the subsequent year
- But again, you have to structure that time well

We took a look at a [2022 systematic review](https://www.sciencedirect.com/science/article/pii/S209525462100051X) and network meta-analysis

- It compared the relative efficacy of different types of exercise interventions on cognitive function for patients with MCI or dementia
- It found that the most important types of exercise were aerobic exercise, resistance exercise, and exercise they described as mind-body exercise or “multicomponent exercise”

So, if you only have three hours (although Peter would encourage more), do three different things with each hour – diversity and novelty is key:

- 1 hour of strength training
- 1 hour of Zone 2 (relatively low intensity aerobic, that’s high enough intensity that you’re uncomfortable speaking, but not so high that you can’t speak)
- 1 hour of something high intensity with coordinated movement (e.g., shadowboxing, active dance class, etc.)

Peter summary:

- “*So in an ideal world, you’re not just doing a mindless HIIT workout where you’re doing sprints on a treadmill and burpees, because we want a little bit more coordination than that if we’re going to be critical of how we can maximize this time.*”
- “*I would call this the minimum effective dose to improve blood pressure, insulin resistance, and try to get in some of the coordination…*”

**4 pillars of exercise**

Is there anything outside of your “4 pillars” of exercise that would also be beneficial for brain health?

- The 4 pillars would include: i) stability (the foundation), ii) strength, iii) aerobic / zone 2 training, & iv) VO2 max / zone 5 training.
- This is where we translate into the combination of cognition with exercise
- For example, something like reaction type games
- One might be little things on the floor or wall that light up and you have to run around and touch them

So how do you combine these things?

- Truthfully, the data for this stuff is not amazing says Peter

[Meta-analysis](https://link.springer.com/article/10.1007/s41465-018-0103-2) of dance interventions

- in theory, dance makes a lot of sense because it’s physical—you’re on your feet, you’re moving around and it’s maybe not as strenuous as zone two, but it’s certainly more strenuous than walking
- more importantly, the movements are not always completely identical
  - If you’re on a stationary bike just riding around turning the cranks, it’s very easy to turn your brain off
  - You can’t really turn your brain off when you’re dancing
- The meta-analysis is not good (full of limitations), but it’s all we’ve got
- It looked at dance interventions that spanned as little as 10 weeks as long as 18 months in older adults.
- Limitations:
  - First of all, of these seven studies, three of them included studies that used a control group that isn’t an appropriate control. If you want to compare dance to something else, it has to be equally strenuous physically, but without the cognitive component
  - In other words, what you’d really want to do is compare dance to walking on a treadmill at the same level of output
  - Three of these seven studies, one had no intervention. That’s not helpful
  - One had a non-dance intervention control group
  - They met in person for the same amount of time, but they had no physical activity and one did health education as the control
  - You might say three of those studies have no control groups, only four do
  - Of the others with controls, the controls, some of them use tai chi balance training for fall prevention and health-related exercises
    - Those to me would be the right ones
- Basically, there was total heterogeneity of outcomes here
- This is the problem of “a thousand sow’s ears makes not a pearl necklace” — All the studies you can put into a meta-analysis don’t necessarily guarantee a good outcome.
- The bottom line was that there was some evidence that that dance was more cognitively engaging than running on a treadmill or using a stationary bike
- Peter would expect that, but unfortunately it just wasn’t clear if this moved the needle in terms of a real outcome
- They were trying to look at things like cognitive flexibility, motor cognitive function, verbal short-term memory, verbal long-term memory, even auditory verbal learning tests
- Each study had its own little niche thing that indirectly or directly found some evidence of benefit
- **Bottom line** is: “I’m going to add this to the list of things that I would like to see done more rigorously”
- A real theme of today is that prevention studies are not interesting studies to fund.
- So much of what we’re talking about today are really important questions and yet, outside of NIH, there’s no natural owner to these studies. There’s no company that’s going to fund this stuff.
- “*I don’t think it’s rocket science to design the studies that are necessary to learn this stuff, but I don’t think that the current body of literature is very helpful*.”

## Challenging the mind with brain games—does it impact neurodegeneration? [1:43:00]

There’s no shortage of people marketing different brain games with the idea of challenging your brain in that way and can it even help in the prevention of dementia

*What do we know about this concept?*

- We don’t have great answers for it
- We DO know that there is something else going on besides the pathology and the relationship between neuropathology and clinical symptoms of dementia is not straightforward
- Autopsies show that there are cases where people with less neuropathology experience worse symptoms than those with more
- You even have people who have a lot of amyloid and had no clinical symptoms whatsoever—*How do we explain that?*
  - One of the reasons is called [cognitive reserve](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3507991/)
  - Cognitive reserve suggests that some individuals are better able to tolerate brain damage and continue to function normally due to having a higher cognitive capacity

![](https://peterattiamd.com/wp-content/uploads/2023/04/f6-ama46.png)

**Figure 6.** Source: [Stern Lancet Neurol. Nov 2012](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3507991/)

- Cognitive test score is shown on the Y-axis.
- The extent of neuropathology is shown on the X-axis
- and there’s a threshold—The threshold is the horizontal fine dotted line
- Once you go below that threshold, you will have the clinical indication of Alzheimer’s disease
- Now we’re going to show you two types of individuals.
- Someone with a high cognitive reserve and someone with a low cognitive reserve.
- In both of these cases, they march along until they start to see a reduction in cognitive scores as their neuropathology increases.
- Both of them are decreasing in response to accumulating neuropathology, but you’ll notice that for any given amount of neuropathology, they have a very different amount of cognitive capacity.
- In other words, these people will for an equal amount of damage to the brain, have a different output.
- So we do think that cognitive reserve plays a big role in dementia
- We also think that **movement reserve** plays a big role in Parkinson’s disease
- Some of the most important things that people can do to reduce their risk for neurodegenerative diseases is to have both very high cognitive reserve and very high physical or movement reserve.

***What about brain games like crosswords, sudoku, or apps like Lumosity?***

Is there a benefit to switching up brain games or if you just play the same game, are you going to see the same benefit and there’s no need to switch it up and to challenge your brain in that way?

- We can draw an analog here with training—if you only ever do bicep curls, you will get very good at bicep curls and you will have big biceps, but you’re not going to be good at much else
- The same is probably true here
- A certain type of cognitive puzzle that might be very challenging at first, if that’s all you’re doing, you’re just going to become better and better at that.
- There’s a company called Lumos Labs which had an app called Lumosity
- They actually had a [$50 million judgment](https://www.ftc.gov/news-events/news/press-releases/2016/01/lumosity-pay-2-million-settle-ftc-deceptive-advertising-charges-its-brain-training-program) against them for false advertising because of  unfounded claims that were made that Luminosity games were able to help people perform better at work in school and may even reduce or delay cognitive impairment
- There’s no evidence that that’s the case

[2016 journal article](https://journals.sagepub.com/doi/abs/10.1177/1529100616661983?forwardService=showFullText&tokenAccess=hK6Y5zBI1Rv.M&tokenDomain=rbtfl&journalCode=psia)

- Huge analysis that looked at brain training games and review hundreds of papers on brain games being used to improve cognition
- Summary of the findings were basically:
- You got better at playing the game, but the improvements didn’t transfer to the general mental skills found in everyday life
- If you practice memory, you did get better at memory, but it didn’t have that leak into other things
- And there was little evidence that training enhances performance on anything that was distant to what you were actually doing in the game.

**In short**, a variety of cognitive activities may be more beneficial in improving general cognitive skills, and it is important to consider the opportunity cost of time spent playing brain games

> “Bottom line, if you like playing brain games like Sudoku, great. Play it, but don’t dilute yourself into thinking that this is reducing your risk of Alzheimer’s disease. I don’t see you have any evidence that it is.” —Peter Attia

## The data on sauna and brain health [1:49:45]

***Do we know anything about saunas as it relates to brain health?***

- For this, all we have is the epidemiology
- Fortunately, the epidemiology for sauna uses good epidemiology in that it’s consistent— it all points in the same direction
- It’s got plausibility, but it has a lot of problems to it—healthy user bias and a socioeconomic bias
- In places like Finland where most of these data come from, however, there’s less of a socioeconomic difference between people who sauna and people who don’t
- If you look at one of the largest [studies](https://academic.oup.com/ageing/article/46/2/245/2654230?login=false), they’re going to basically say,
  - “Compared to one sauna session per week week, if you’re going to be in the sauna four to five times or four to seven times per week, you’re going to have 50% reduction in the absolute risk of Alzheimer’s disease.”
  - That’s a 3% absolute risk reduction
  - That’s 6% to 3%, so it is 50% relative
  - Basically your number needed to treat is only 30
  - If you look at overall dementia, including vascular, et cetera, the same comparison, one sauna session per week to four to seven is like a 60% reduction.
    - You’re going from 10% to 4%, which again means your number needed to treat here is about 15 people

Another [Finnish study](https://www.sciencedirect.com/science/article/pii/S2211335520301790) in 2020

- Looked at about 14,000 men and women.
- Again, these are still retrospective studies, so you’ve got all these problems
- Found that if you compared people who were in sauna less than four times a month, that’s once a week versus people who are 9 to 12 times per month, you had about a 24% relative reduction
- In short, it found that you only had a significant effect of sauna on incident dementia when done 9-12 times per month

Summary:

- Is there a mechanism of action here that’s plausible? ⇒ Yeah, probably, and it probably overlaps most closely with the exercise benefit
- It might be that sauna is a little bit of an exercise mimetic
- But Peter states that the effects of exercise are much more potent so sauna should not “replace” exercise
- More importantly, exercise factors in much more to the quality of life/healthspan

> “Sauna is probably beneficial, but from an opportunity cost, I can think of other places where I would invest time if time were limited.” —Peter Attia

⇒ For more on sauna, check out [AMA #16](https://peterattiamd.com/ama16/)

## Oral health and its association with brain health [1:52:45]

⇒ See previous [episode](https://peterattiamd.com/patriciacorby/) on oral health with Dr. Pat Corby

\*\*\*

- Peter believes there is something going on here in terms of oral health and overall health
- periodontal disease is a problem not just for the obvious, which is your mouth, but also for inflammation and how that inflammation may factor into at least two other diseases, cardiovascular disease and neurodegenerative disease, specifically Alzheimer’s disease
- And we know that most people aren’t doing enough
- The recommendation is basically two minutes a day, twice a day with an electric toothbrush
  - A survey in 2018 found that only 70% of Americans even brush twice a day, and they’re not doing it for the full two minutes, and only 41% of Americans are using electric toothbrush
- Interproximal cleaning is at least as important, if not more than brushing
- Flossing is super important—if you floss and your gums hurt or bleed, good, keep flossing, that’s the sign that you have inflammation in the gums and you’ve got to just work through that
- Peter also likes using those little brushes that have a “little fuzziness” on them

What else does Peter do?

- Peter said he’s heard enough anecdotal evidence that he has a tongue scraping ritual — he will scrape his tongue in the morning before brushing his teeth
- Then he brushes his teeth, which, of course, includes brushing his tongue
- About three or four times a week he does an “oil pulling” — You can just buy oil for teeth pulling and you just swish it around in your mouth for 10 minutes and spit it into the trash
- The mouth is an area that warrants a lot of attention

Bottom line: “*if doing all this stuff doesn’t help you one bit in reducing your risk of Alzheimer’s disease, the fact that you might have your teeth in your mouth when you’re 90 years old should be reason enough to do this stuff*”

## How reducing lipids can improve brain health and prevent neurodegeneration [1:55:30]

**Lipids and causality**

- There are not many things for which we think there’s a causal relationship, but this is one of them, along with exercise, type 2 diabetes, and insulin resistance
- Lower lipids is better for brain health than higher lipids

*Lipophilic vs. hydrophilic statins*

- But a more nuanced conversation is about the difference between lipophilic and hydrophilic statins
- There are roughly seven statins on the market right now
- Two of them are hydrophilic, meaning they’re soluble in water but not fat—those being Rosuvastatin and pravastatin
- Five of them are lipophilic—those being atorvastatin (Lipitor), simvastatin, lovastatin, pitavastatin, and fluvastatin
- Peter says, of the lipophilic, he only use atorvastatin (Lipitor) and pitavastatin with patients (and he uses rosuvastatin and pravastatin—hydrophilic—with patients as well)
- The question: is there a difference in them?
- All statins cross the blood-brain barrier. We know that, but at least theoretically you could argue that lipophilic statins do so more easily.

The question that Peter sought to answer was:

- In patients who, for example, have an ApoE4 who might be at higher risk for Alzheimer’s disease… If we’re trying to address their dyslipidemia, *should we preferentially be using a hydrophilic statin?*
- In other words, if a patient has ApoE4, should you be using pravastatin and rosuvastatin, which is Crestor preferentially over Lipitor and pitavastatin which is Livalo?

**Let’s take a look at the two largest meta-analyses that sought to address this**

![](https://peterattiamd.com/wp-content/uploads/2023/04/f7-ama46-1024x364.png)

**Figure 7.** Source: [Chu et al. Sci. Rep. April 2018](https://www.nature.com/articles/s41598-018-24248-8#citeas)

- These are prospective studies that are looking at statins and comparing hydrophilic to lipophilic statins on all-cause dementia
  - That’s the figure on the left of this page, figure A
- And then looking at hydrophilic versus lipophilic, statins on AD
  - That’s on the right side of this page, figure C
- The idea is that we’re looking at a list of all the studies that were included and trying to look at whether hydrophilic statins increase or decrease the risk of all-cause dementia
  - For example, if you look at the Baltimore study from 2012,
    - it says the risk ratio was 0.89, so there’s an 11% reduction in the risk of all-cause dementia
    - However, the confidence interval was 0.612 to 1.29
    - go over to look at the P value and we know it’s greater than .05 because it crosses unity and it’s way greater than 0.05
    - That’s represented on the forest plot as a wide line that crosses one.
    - That’s NOT significant, so we’re not going to pay attention to that one
  - Then we’re going to look at the next one
    - This is looking specifically at atorvastatin 2010 study
    - This had a 15.1% reduction
    - You can see the lower and upper limit of the confidence interval is fully below one so you know the P value is less than .05, and sure enough, it’s .01
  - Same is true for the next one
  - But then the next one crosses
  - And the next one crosses
  - The next one, pretty much touches — it’s a .055
  - And the next one touches
- When you put them all together you get a much tighter group represented by the diamond
  - In the middle of the diamond is where it lies, and the tips of the diamond are the confidence interval
  - The overall risk ratio is .877
  - That’s a 12.3% reduction, which is statistically significant
  - Okay, that means the hydrophilic statins were not increasing the risk…they were actually decreasing the risk of dementia
- If you go through the same exercise for the lipophilic statins, you see that there was no significance
  - Now it’s a trend towards lower because the risk ratio is .738. That means that the lipophilic statins were about 26.2% lower in risk
  - But you see the triangle is so wide that it’s crossing the Y, so your P value is .176
  - What that means in English is even though this study said that there’s about a 26.2% lower risk of lipophilic statins, it’s saying that, basically, this is not entirely precise, but it’s close enough
  - It’s saying like, “There’s a 17.6% chance that that result is statistical fluke.”
- When we go and do this on Alzheimer’s dementia specifically, do the same exercise on the hydrophilic, we get a 38.1% reduction in risk that just meets statistical significance
- And for the lipophilic statins, we get a 36.1% reduction in risk—that is statistically significant.

> “There is no scenario here in which patients taking statins, either hydrophilic or lipophilic, are seeing anything that remotely resembles an increase in the risk of Alzheimer’s disease or all-cause dementia.” —Peter Attia

- In fact, only in the patients taking lipophilic statins do we see statistically no difference in the risk of all-cause dementia with the trend towards it being a reduction
- So, when people say, “*Oh man, statins cause dementia*.” … you have to ask “*What data are they looking at?*”

**Now let’s look at a** [**2022 paper**](https://academic.oup.com/eurjpc/article/29/5/804/6454065)

![](https://peterattiamd.com/wp-content/uploads/2023/04/f8-ama46-1024x667.png)

**Figure 8. Slide 5.** Source: [Olmastroni et al. Eur J Prev Cardiol. May 2022](https://academic.oup.com/eurjpc/article/29/5/804/6454065)

- This figure, while hard to look at, illustrates the point that there’s just no ambiguity here
- Here we’re looking at a ton more studies that are asking the question, when you take a hydrophilic statin, what happens to your risk of dementia?
  - The answer is 20% reduction in all causes of dementia
- What if you ask the question, what happens specifically to Alzheimer’s disease?
  - The answer is 41% reduction in Alzheimer’s disease
- But what about the “bad” lipophilic statins?
  - They have an 18% reduction in incident dementia risk
  - When you go over to Alzheimer’s disease, recall that the hydrophilic statins were at .59, 41% reduction, and lo and behold, this is also .59

Two things are actually unambiguously clear from this analysis

- 1) Statins reduce the risk of dementia and reduce the risk of Alzheimer’s disease specifically
- 2) It’s unambiguously clear that lipophilic statins are not harmful relative to hydrophilic statins. Both statins are equally efficacious

## The potential impact of hearing loss on brain health and neurodegeneration [2:04:30]

\*\*\*

- Currently, we do not yet have causal data that hearing loss impacts dementia because the experiment has not been done
- The experiment would be taking people with varying degrees of hearing loss and randomizing them to interventions that are restorative for hearing, and then you would assess the differences in the development or progression of neurodegenerative disease or dementia specifically
- The good news is that this experiment is being done—there is at least one randomized control trial that is looking at the development of dementia in the presence of corrected hearing loss
- What we do know is that hearing loss comes with a very large risk
  - It carries a 90% increase in the risk of dementia and is therefore viewed, at least, according to the 2020 Lancet Commission as one of the most critical modifiable variables in the prevention of neurodegenerative disease

You see this in multiple cohorts. The best example of this is the [Baltimore Longitudinal Study of Aging](https://pubmed.ncbi.nlm.nih.gov/21320988/)

- This was looking at the risk of dementia and how it changed with the severity of hearing loss
- Remember that dose response in epidemiology is one of the things that makes us believe there might be some causality there
- It looked at over 600 patients, followed up for a medium of about 12 years
- If you looked at people with mild hearing loss, and this was people who were defined as having a hearing threshold of 25 to 40 decibels—hese people had an 89% increase in the risk of dementia
- If you look at folks who had a hearing threshold of 41 to 70 decibels, their risk was 200% higher
- If you looked at people whose hearing threshold was above 70 decibels, the hazard ratio was 4.94.
  - That’s nearly 400% increase in the risk of dementia

There are at least two plausible mechanisms of action here that makes sense

- 1 One is the increased cognitive load from hearing loss
  - For a person who’s experiencing this amount of hearing loss, it requires greater attention and concentration to understand speech, and that’s diverting cognitive resources from other tasks
- 2 There’s also this thing called the cascade hypothesis
  - Think of this as the use it or lose it hypothesis?

> “Our view on this is that if our patients have hearing loss, we want it corrected right away. I’m not going to wait for the results of the RCT to recommend that patients have their hearing loss corrected, because if nothing else, it’s still improving quality of life.” —Peter Attia

§

## Selected Links / Related Material

**TV series where Peter had Chris Hemsworth get is APOE genes tested**: [Limitless](https://disneyplusoriginals.disney.com/show/limitless-with-chris-hemsworth) | (disney.com) [0:30, 15:15, 20:15]]

**Previous podcasts on the topic of brain health, Alzheimer’s disease, etc.**: [0:03:15]

- [#234 ‒ Chris Hemsworth on Limitless, longevity, and happiness](https://peterattiamd.com/chrishemsworth/) | Peter Attia (peterattiamd.com)
- [#18 – Richard Isaacson, M.D.: Alzheimer’s prevention](https://peterattiamd.com/richardisaacson/) | Peter Attia (peterattiamd.com)
- [#138 – Lauren Miller Rogen and Richard Isaacson, M.D.: Alzheimer’s disease prevention—patient and doctor perspectives](https://peterattiamd.com/laurenmillerrogen-richardisaacson/) | Peter Attia (peterattiamd.com)
- [#147 – Hussein Yassine, M.D.: Deep dive into the “Alzheimer’s gene” (APOE), brain health, and omega-3s](https://peterattiamd.com/husseinyassine/) | Peter Attia (peterattiamd.com)
- [#164 – Amanda Smith, M.D.: Diagnosing, preventing, and treating Alzheimer’s disease, and what we can all learn from patients with dementia](https://peterattiamd.com/amandasmith/) | Peter Attia (peterattiamd.com)

**Episode of The Drive with a dive deeper on sensitivity, specificity, positive, negative predictive value**: [#170 – AMA #25: Navigating the complexities and nuances of cancer screening](https://peterattiamd.com/ama25/) | Peter Attia (peterattiamd.com) [12:30]

**Peter’s book**: [OUTLIVE: The Science & Art of Longevity](https://peterattiamd.com/outlive/) by Peter Attia | (peterattiamd.com) [15:30, 54:00]

**Data suggesting Alzheimer’s disease risk is modifiable from the Chicago Health and Aging Project**: [Impact of the Apolipoprotein E ε4 Allele on the Relationship Between Healthy Lifestyle and Cognitive Decline: A Population-Based Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8484773/) (Dhana et al., 2021) [25:15]

**Evidence from one finished cohort study that patients who have ApoE4 may be slightly more susceptible to alcohol than patients with ApoE3**: [Alcohol drinking in middle age and subsequent risk of mild cognitive impairment and dementia in old age: a prospective population based study](https://www.bmj.com/content/329/7465/539?ecoll=) (Anttila et al., 2004) [38:00]

Find more about the impact of sleep on brain health in the episodes of The Drive with Matt Walker: [#47 – Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, memory consolidation, and more](https://peterattiamd.com/matthewwalker1/) | Peter Attia (peterattiamd.com) [40:30]

**SPRINT MIND trial about blood pressure and dementia**: [Effect of Intensive vs Standard Blood Pressure Control on Probable Dementia](https://jamanetwork.com/journals/jama/fullarticle/2723256) (The SPRINT MIND Investigators for the SPRINT Research Group, 2019) [44:15]

**Prospective cohort study in the UK looking at type 2 diabetes and dementia**: [Association Between Age at Diabetes Onset and Subsequent Risk of Dementia](https://jamanetwork.com/journals/jama/fullarticle/2779197) (Amidei et al., 2021) [49:30]

**Nine criteria that basically give you a sense of how much do you believe your epidemiology**: [Austin Bradford-Hill criteria](https://en.wikipedia.org/wiki/Bradford_Hill_criteria) | (wikipedia.org) [52:00]

**The Honolulu-Asia Aging Study looking at the differential risk for ApoE4s**: [Type 2 Diabetes, APOE Gene, and the Risk for Dementia and Related Pathologies: The Honolulu-Asia Aging Study](https://diabetesjournals.org/diabetes/article/51/4/1256/34635/Type-2-Diabetes-APOE-Gene-and-the-Risk-for) (Peila et al., 2002) [54:00]

**Episodes of The Drive that discussed the “obesity paradox”**: [55:00]

- [#197 – The science of obesity & how to improve nutritional epidemiology | David Allison, Ph.D.](https://peterattiamd.com/davidallison/) | Peter Attia (peterattiamd.com)
- [#212 – The neuroscience of obesity | Stephan Guyenet, Ph.D.](https://peterattiamd.com/stephanguyenet/) | Peter Attia (peterattiamd.com)

**Meta-analysis that we looked at obesity in midlife and the relative risk increase for developing AD**: [Body mass index in midlife and late-life as a risk factor for dementia: a meta-analysis of prospective studies](https://onlinelibrary.wiley.com/doi/10.1111/j.1467-789X.2010.00825.x) (Anstey et al., 2011) [55:30]

**PREDIMED: One of the best nutrition epidemiology studies**: [“The Mediterranean Diet, its Components, and Cardiovascular Disease”](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4339461/) (Widmer et al., 2016) [1:00:15]

**Carve out of the PREDIMED study looking at cognitive function**: [Mediterranean diet improves cognition: the PREDIMED-NAVARRA randomised trial](https://jnnp.bmj.com/content/84/12/1318.short) (Martinez-Lapiscina) [1:02:45]

**Cohort study comparing common diets showing MIND diet might reduce AD risk most**: [MIND Diet Associated with Reduced Incidence of Alzheimer’s Disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4532650/) (Morris et al., 2016) [1:07:45]

**Current Nutritional intervention RCT for the MIND diet**: [Mediterranean-DASH Intervention for Neurodegenerative Delay (MIND) Study: Rationale, Design and Baseline Characteristics of a Randomized Control Trial of the MIND Diet on Cognitive Decline](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8042655/) (Liu et al., 2022) [1:12:15]

**Six-month RCT looking at EPA and DHA in patients with AD**: [Omega-3 fatty acid treatment in 174 patients with mild to moderate Alzheimer disease: OmegAD study: a randomized double-blind trial](https://pubmed.ncbi.nlm.nih.gov/17030655/) (Freund-Levi) [1:15:30]

**Epidemiological and prospective longitudinal studies suggest a link between Hcy and cognitive impairment**: [Plasma total homocysteine and memory in the elderly: the Hordaland Homocysteine Study](https://pubmed.ncbi.nlm.nih.gov/16254972/) (Nurk) [1:23:45]

**18-month study on patients given Theracurmin**: [Memory and Brain Amyloid and Tau Effects of a Bioavailable Form of Curcumin in Non-Demented Adults: A Double-Blind, Placebo-Controlled 18-Month Trial](https://www.sciencedirect.com/science/article/pii/S1064748117305110) (Small et al., 2018) [1:26:15]

**A six-month retrospective study of patients treated with Theracurmin who had AD or MCI**: [Theracurmin Supplementation May be a Therapeutic Option for Older Patients with Alzheimer’s Disease: A 6-Month Retrospective Follow-Up Study](https://pubmed.ncbi.nlm.nih.gov/34939543/) (Dost et at., 2021) [1:27:00]

**Study looking at older individuals with mild cognitive impairment who were given cocoa flavanols**: [Benefits in cognitive function, blood pressure, and insulin resistance through cocoa flavanol consumption in elderly subjects with mild cognitive impairment: the Cocoa, Cognition, and Aging (CoCoA) study](https://pubmed.ncbi.nlm.nih.gov/22892813/) (Desideri et al., 2012) [1:29:15]

**2015 study with cocoa flavonols**: [Cocoa flavanol consumption improves cognitive function, blood pressure control, and metabolic profile in elderly subjects: the Cocoa, Cognition, and Aging (CoCoA) Study—a randomized controlled trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4340060/) (Mastroiacovo et al., 2015) [1:30:00]

**Cosmos Mind Study on cocoa flavanols**: [Effects of cocoa extract and a multivitamin on cognitive function: A randomized clinical trial](https://alz-journals.onlinelibrary.wiley.com/doi/full/10.1002/alz.12767) (Baker et al., 2022) [1:30:15]

**Peter wrote about the Cosmos Mind Study here**: [Can cocoa help prevent cardiovascular death?](https://peterattiamd.com/can-cocoa-help-prevent-cardiovascular-death/) | Peter Attia (peterattiamd.com) [1:30:15]

**Animal study that demonstrated an increase of brain magnesium as measured by magnesium and cerebral spinal fluid**: [Chronic dietary magnesium-L-threonate speeds extinction and reduces spontaneous recovery of a conditioned taste aversion](https://www.bw.edu/Assets/academics/andrew-mickley/chronic-dietary-magnesium-l-threonate.pdf) (Mickley et al., 2013) [1:31:30]

**2022 systematic review which compared the relative efficacy of different types of exercise interventions on cognitive function for patients with MCI or dementia**: [Comparative efficacy of various exercise interventions on cognitive function in patients with mild cognitive impairment or dementia: A systematic review and network meta-analysis](https://www.sciencedirect.com/science/article/pii/S209525462100051X) (Huang et al., 2022) [1:34:45]

**Meta-analysis of dance interventions as a form of exercise for brain health**: [Effects of Dancing on Cognition in Healthy Older Adults: a Systematic Review](https://link.springer.com/article/10.1007/s41465-018-0103-2) (Predovan et al., 2018) [1:38:45]

**$50 million judgment against Lumosity for false claims**: [Lumosity to Pay $2 Million to Settle FTC Deceptive Advertising Charges for Its “Brain Training” Program](https://www.ftc.gov/news-events/news/press-releases/2016/01/lumosity-pay-2-million-settle-ftc-deceptive-advertising-charges-its-brain-training-program) | (ftc.gov) [1:47:15]

**Journal article that reviewed hundreds of papers on brain games being used to improve cognition**: [Do “Brain-Training” Programs Work?](https://journals.sagepub.com/doi/abs/10.1177/1529100616661983?forwardService=showFullText&tokenAccess=hK6Y5zBI1Rv.M&tokenDomain=rbtfl&journalCode=psia) (Simons et al., 2016) [1:48:00]

**One of the largest studies on sauna**: [Sauna bathing is inversely associated with dementia and Alzheimer’s disease in middle-aged Finnish men](https://academic.oup.com/ageing/article/46/2/245/2654230?login=false) (Laukkanen et al., 2016) [1:50:30]

**2020 Finnish study about sauna**: [Does sauna bathing protect against dementia?](https://www.sciencedirect.com/science/article/pii/S2211335520301790) (Knekt et al., 2020) [1:51:15]

**Episode of The Drive on oral health**: [#166 – Patricia Corby, D.D.S.: Importance of oral health, best hygiene practices, and the relationship between poor oral health and systemic disease](https://peterattiamd.com/patriciacorby/)  | Peter Attia (peterattiamd.com) [1:52:45]

**Two largest meta-analyses on lipids, statins, and brain health**: [1:57:30]

- [Use of statins and the risk of dementia and mild cognitive impairment: A systematic review and meta-analysis](https://www.nature.com/articles/s41598-018-24248-8#citeas) (Chu et al., 2018)
- [Statin use and risk of dementia or Alzheimer’s disease: a systematic review and meta-analysis of observational studies](https://academic.oup.com/eurjpc/article/29/5/804/6454065) (Olmastroni et al., 2022) [2:02:15]

**Study looking at the risk of dementia and how it changed with the severity of hearing loss**: [Hearing loss and incident dementia](https://pubmed.ncbi.nlm.nih.gov/21320988/) (Lin et al., 2011) [2:06:00]

§

## People Mentioned

- [Chris Hemsworth](https://en.wikipedia.org/wiki/Chris_Hemsworth) [0:30]
- [Richard Isaacson](https://www.fau.edu/newsdesk/articles/isaacson-brain-health.php) [2:00, 4:00, 19:45]
- [Dom D’Agostino](https://health.usf.edu/medicine/mpp/faculty/ddagosti) [42:30]
- [Layne Norton](https://biolayne.com/) [47:30]
- [Bob Kaplan](https://en.wikipedia.org/wiki/Bob_Kaplan) [1:04:30]
- [Matt Walker](https://www.sleepdiplomat.com/) [1:12:00]

§