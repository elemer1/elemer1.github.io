# #282 – AMA #54: Magnesium: risks of deficiency, how to correct it, supplement options, potential cognitive and sleep benefits, and more

**Source:** [https://peterattiamd.com/ama54/](https://peterattiamd.com/ama54/)

---

In this “Ask Me Anything” (AMA) episode, Peter tackles essential questions about magnesium, beginning with the important roles it plays in the body and why maintaining proper levels is crucial. Peter discusses the harms of magnesium deficiency, how to determine if you’re deficient, potential causes of deficiency, and how diet and supplementation can be used to increase magnesium levels. Peter unravels the confusion surrounding magnesium supplementation, discussing the optimal forms and recommended daily intake while addressing concerns about excess consumption. He also explores the potential cognitive and sleep benefits associated with magnesium supplementation. Finally, Peter concludes with a look into his recent experimentation with new exercises to serve as benchmarks to assess his progress and fitness levels as he navigates the aging process.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #54 show notes page](https://peterattiamd.com/ama54). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- The important roles of magnesium in the body [2:45];
- How to determine if you might be deficient in magnesium [10:15];
- Addressing migraines related to low magnesium [14:45];
- The prevalence of magnesium deficiency [16:30];
- Various conditions and drugs that can negatively impact magnesium levels [21:30];
- Magnesium-rich foods and factors that impact absorption of magnesium [24:30];
- Daily targets for magnesium supplementation and whether it’s possible to take too much [30:15];
- The different forms of supplemental magnesium [34:00];
- How absorption of magnesium from food compares to absorption from supplements [36:15];
- Choosing the right magnesium supplements for optimal absorption [37:15];
- The unique ability of magnesium L-threonate to increase brain magnesium concentration [40:15];
- Potential cognitive benefits of magnesium [43:00];
- Potential sleep benefits of magnesium [48:45];
- Takeaways on magnesium and a look into Peter’s personal protocol [53:15];
- Peter’s new benchmarks related to exercise and age [58:30]; and
- More.

§

The Peter Attia Drive

Magnesium: risks of deficiency, how to correct it, supplement options, potential cognitive and sleep benefits, and more

§

## Show Notes

§

## The important roles of magnesium in the body [2:45]

“*There’s no shortage of magnesium supplements out there, but in order to talk about this subject intelligently, it does help to set the stage and get into all the things magnesium does*.” – Peter

**Magnesium overview**

- Magnesium is a cofactor in at least 300 enzymatic systems in the body. It is very important as a co-transporter for the movement of potassium and calcium across membranes
- But there are three big systems where magnesium matters the most:
  - 1) bone health
  - 2) nerve transmission
  - 3) glucose control and insulin metabolism

***But first, what is magnesium?***

- So magnesium is a cation—that means it’s a positively charged ion, so it has two positive charges.
- And just like potassium is a cation with one positive charge and calcium is a cation with two positive charges, these things often have to move in opposition to each other.

**Bone health**

- The bones basically reflect the largest total body pool of magnesium—60% of the magnesium in your body resides within your bones
- Not surprisingly, therefore, magnesium deficiency is a significant problem when it comes to bone health
- Bones are basically in a constant state of building and breaking
  - The building cells are called osteoblasts
  - The breaking cells are osteoclasts
- There’s a balance between the osteoblasts and the osteoclasts — if that balance moves too far in the direction of bone breakdown, you get osteopenia and ultimately osteoporosis
- It turns out that magnesium plays a very important role in that both directly and indirectly
  - directly through the upregulation and downregulation of osteoblasts and osteoclast
  - indirectly through the metabolism of calcium, PTH, parathyroid hormone and vitamin D
- “*I just want to point out that magnesium deficiency is very bad for bones*.”

⇒ Check out [AMA #37 on bone health](https://peterattiamd.com/ama37)

**Glucose control and insulin metabolism**

- Magnesium helps with glucose control and insulin metabolism
- Magnesium is involved in the regulation of insulin secretion in the pancreatic beta cells in addition to the phosphorylation of the insulin receptor in the target cell
- This was discussed in great detail in the [podcast with Gerry Shulman](https://peterattiamd.com/geraldshulman/) — when insulin hits the insulin receptor, that leads to an intracellular kinase that phosphorylates and ultimately leads to the movement of the glute transporters that move across the cell membrane and allow glucose to flow in
- And so metabolism obviously therefore heavily impacted by that
- So in addition to increasing glucose movement into the cell and facilitating the effects of insulin (i.e driving insulin sensitivity), it’s also a co-factor in carbohydrate oxidation
- A number of clinical studies, though not all, suggest that supplementing with magnesium and a magnesium rich diet can [improve insulin sensitivity and fasting glucose](https://www.mdpi.com/2072-6643/14/9/1714)
- However, the extent to which magnesium can help in a given area, whether it be bone health with respect to metabolism, is largely a function of magnesium deficiency

> “In other words, the more deficient you are in magnesium, the more you will be helped by supplementing magnesium.” —Peter Attia

**The effect that magnesium plays in nerve transmission and muscle function**

- Magnesium is an antagonist of the NMDA receptor and a GABA agonist
- How nerve transduction works:
  - Imagine a couple of big proteins that sit spanning across the membrane of a cell and they create a pore, and the pore is what allows the ions that participate in the action potential to move
  - These things are taking stored energy in the form of the charges of the ion, and as they move one way across the channel, that creates a polarization of the cell and it’s the sequential firing of those action potentials that leads to signal transduction down a cell
- It turns out that magnesium sits right smack in the middle of that receptor and it must be removed for the excitatory signal to occur
- So when magnesium is deficient, this is a contributing factor to things like mood and other neurologic conditions, even potentially a contributor to migraines
- The point here is that magnesium sits very much in the center, both literally and figuratively, for a lot of the action as we think about signal transduction across nerves, across muscles and various other cells
- It all factors into the movement of these other cations like sodium, potassium, calcium, etc.

## How to determine if you might be deficient in magnesium [10:15]

Interesting story from Peter:

- In residency, there are certain things that you’re measuring on hospitalized patients relentlessly and one of them is potassium (measured in plasma)
- It’s very important because if it was too low or too high, it was problematic or even fatal
- And it’s a very narrow range—a normal physiologic potassium level might be between 3.5-5.0 units per liter
- It’s not uncommon in hospitalized patients that you have to replace potassium, but if ever replaced too much potassium you could throw them into a fatal heart rhythm
- Even if you thought the lab made a mistake, you were immediately rechecking it and taking corrective actions
- Similarly, if the levels are too low, you’re going to changes in heart rhythm (though less likely to be fatal)
- Suffice it to say you would not be replacing potassium in a patient without having measured the level first

Contrast that with magnesium…

- Most chief residents would scream at you if you ever measured a magnesium level in a patient with normal kidneys before giving them magnesium
- The reason was because 1) it costs more and 2) it’s not altering management
- More importantly, the measurement of serum magnesium is not really indicative of total body magnesium and you have an enormous buffer for overshooting
- It’s also true that most of the potassium in a person is not in the extracellular space in the plasma, but rather in the cells
- But because potassium and the difference between what’s in the cell and out of the cell is a very important electrical gradient, if you overshoot what’s out of the cell a little too much, it can be fatal
- That’s not the case with magnesium because magnesium is not used to set the charge across the cell

**Measuring magnesium levels**

- The other point to make is that we don’t have great ways to measure magnesium
- Also, we don’t tend to care about it very much clinically because unless a person’s kidneys are really compromised and the kidneys become the acute place in where magnesium regulation happens, we don’t care about overdoing it

There are few ways to do this:

- You can measure plasma levels and that’s a test that’s commercially available (e.g., LabCorp or Quest)
- If you’re **really** concerned about magnesium deficiency though, you have to do these other types of tests
- One of them is a urinary test where you collect the urine that is made over a period of time, say 24 hours, and you look at the amount of magnesium in the urine and that gives you a sense of magnesium deficiency
  - The less magnesium in the urine, the more likely the person is to be deficient and that because it tells you those kidneys are really holding on to magnesium
  - We have a sense of how much magnesium should come out of a person in a day state of “equilibrium”, and if the amount of magnesium that’s coming out is really low, you would surmise that that person truly has total body deficiency
- The other way you do it is a more elaborate version of this test where you load the patient with magnesium intravenously
  - Then you also measure the urinary excretion
- Peter has never done either of those and he points out that in a person with normal renal function, you tend to err on the side of assuming people are magnesium deficient
- And if you have any reason to believe it based on symptoms or signs, i.e.:
  - Low bone density
  - Preventricular contractions, so relatively benign, skipped heartbeats, things of that nature
  - Cramps would be a very common thing that would give you reason to believe a person is magnesium deficient
- Peter would just go ahead and replace the magnesium without measuring it first

## Addressing migraines related to low magnesium [14:45]

**Migraines and low magnesium**

- Magnesium plays an important role in inhibiting the glutamate excitatory pathway of the NMDA receptor in the brain
- Migraines are associated with more excitation
- So the thinking would be that if you are deficient in magnesium, you have less inhibition of an excitatory neurotransmission pathway, and therefore, you might see more migraines in people who are susceptible

[2016 meta-analysis](https://pubmed.ncbi.nlm.nih.gov/26752497/) of all the RCTs that were done for acute migraines

- It found that intravenous magnesium of 2-4 grams provided significant short-term relief, i.e. within 15 to 45 minutes, and up to 24 hours post administration
- Again, that’s intravenous magnesium, but oral magnesium is the way most people are going to get magnesium and it’s unlikely that oral magnesium is going to be able to provide relief **acutely** for this
- Oral magnesium treatments may reduce the frequency and the severity of attacks, but really provides very little relief in the acute setting

## The prevalence of magnesium deficiency [16:30]

***What do we know about how common magnesium deficiency is?***

- This is the million-dollar question
- The short answer is we really don’t know
- If you base it on the serum level, which is defined as less than 0.75 millimole per liter, about a quarter of the population meets criteria for magnesium deficiency
- But again, this is very misleading because serum magnesium amounts to about 1% of the total body pool of magnesium
- And therefore, serum levels don’t really reflect what’s happening both intracellularly and in the bone
- A bit of an oversimplification, but it’s about 60% bone, 39% in the cell, 1% out of the cell in the serum

***Do we know anything about why we’re so frequently deficient in magnesium?***

Several things contributing to this:

1 – Food is one of them

- In theory, you should be able to get all the magnesium you need through your diet, and there’s just a deficiency in terms of how much magnesium we’re getting through food
- Peter says he wouldn’t be surprised if food itself is less rich in magnesium that it used to be
- And this is likely due to the health of the soil in which the food is grown
- If you think “healthy soil produce healthy plant, healthy plant produce healthy animal, healthy animal produce healthy consumer of the animal” … then anywhere on that chain, if there’s a deficiency there could be issues

\*Peter wants to do a deep dive on for a podcast on the topic of regenerative agriculture and soil health and how the absence of regenerative ag and the very unhealthy soil that tends to permeate our system today probably leads to just the deficiency of magnesium in the food itself

2 – Drugs people take can impact magnesium levels

- There are a lot of drugs that people take, pharmacologic agents, diuretics, blood pressure drugs, certain types of medications that we’ll talk a little bit more about that also probably impair reabsorption of magnesium in the kidney

3 – Loss of magnesium due to normal body function

- Under normal circumstances, your magnesium is being filtered through your kidneys
- The process of the kidney is basically to throw everything out and then pull back in what you actually need—so the kidneys throw all the magnesium out and then pull back about 95% of it
- You’re losing about 100 milligrams per day just through urinary excretion.
- You lose about another 20 milligrams per day through your intestine
- So that’s 120 milligrams a day is being lost through normal body function
- And that goes back to why if a person’s urinary levels are significantly beneath that, you would be very suspicious that they’re indeed magnesium deficient.

***How much Mg should be in our diet?***

- The RDA for men is 420 milligrams, and for women it is 320 milligrams (with an additional 40 milligrams during pregnancy)
- It turns out that if you look at dietary surveys, without supplements, the average person in the US is about 250 milligrams per day in dietary intake
- Just based on that, you would assume that the average person is about 100 to 150 milligrams per day light in magnesium
- And that assumes that you believe the food is as high as we have historically found it to be
- Peter says “I don’t know that the food today when it says it has X amount of 95 milligrams of magnesium per hundred grams of food, I’m not convinced that that’s necessarily the case.”

> “All of this points towards the need for supplementation.” —Peter Attia

## Various conditions and drugs that can negatively impact magnesium levels [21:30]

**The possible conditions or drugs that people might be using and which could cause magnesium deficiency**

Proton pump inhibitors

- The most common class of drug that probably does this are proton pump inhibitors
- proton pump inhibitors are very frequently used drug class
- used for reflux, heartburn, treatment of peptic ulcer disease, et cetera
- they change the pH within the gut and it’s at least speculated, I don’t think it’s completely known, that that changes magnesium absorption

Alcohol impact

- More commonly and the thing that people need to really think about is the role of alcohol
- Alcohol is a diuretic—it inhibits the hormone ADH, the antidiuretic hormone
- That’s why, by the way, if you drink alcohol before bed, you’re going to be waking up to pee at night
- But what that also does is it increases magnesium excretion from the kidney—so instead of 100 milligrams a day of magnesium being lost, you might be losing 150 or 200 milligrams per day

Another class of drug are loop diuretics

- These are drugs that are used to treat blood pressure and they have the same effect
- They basically increase magnesium excretion through the kidney and that’s loss.

Diarrhea

- Any chronic state of diarrhea, sorts of GI diseases, those things are going to be significant

Does exercise affect magnesium?

- What’s interesting is the relative lack of long-term effect that exercise has on magnesium requirement
- It’s well understood how much sodium is lost through exercise through perspiration, but that doesn’t appear to be the case with magnesium
- Exercise results in a [redistribution of magnesium](https://pubmed.ncbi.nlm.nih.gov/17172008/#:~:text=Strenuous%20exercise%20apparently%20increases%20urinary,in%20a%20magnesium%2Ddeficient%20status) in the body
- So roughly 39% of magnesium exists within cells and about half of that is within muscle cells
- Very short-term, high intensity exercise actually transiently increases plasma magnesium concentrations by about 5-15%
- And it’s not clear why: That could be due to plasma volume shifts or it could be just due to magnesium moving from muscle into extracellular fluids
- Endurance exercise transiently also shows to decrease serum magnesium and that’s attributed to movement of magnesium from plasma into adipocytes or skeletal muscle
- The more important point is that none of these things appear to be long-term, they all seem to go back to normal after time.
- Peter used to believe that one of the reasons we needed to replace magnesium was because we were losing magnesium in the way we lost sodium through perspiration but it turns out that that’s not really the case

## Magnesium-rich foods and factors that impact absorption of magnesium [24:30]

![](https://peterattiamd.com/wp-content/uploads/2023/12/f1-ama54.png)

**Figure 1. Note: The magnesium content listed next to “Pumpkin seeds” in the table above is for whole pumpkin seeds. The magnesium content of pumpkin seed kernels (also called pepitas) is approximately 150 mg of magnesium per 1 ounce serving.**

- The top few things on here are nuts, Brazil nuts, chia seeds, cashews, almonds
- We normalize these each to a one ounce serving
- You’re talking about 107, 95, 83, and 80 milligrams of elemental magnesium from those servings
- What else is on the list? Pumpkin seeds, spinach, dark chocolate, black beans and avocado
- If your goal is to get 400 milligrams of magnesium a day, you could bang that out with four ounces of Brazil nuts *if you believe that those data actually reflect the Brazil nuts grown today*

The other question is, ***how much of that is absorbed?***

- It turns out that that varies greatly depending on how much magnesium you need
- The body really, really regulates magnesium absorption based on state of magnesium need
- And we are not entirely sure how because if you think about it, how does an enterocyte know how to make the absorption? Or maybe that’s not where the regulation is. Maybe the regulation is all done at the kidney and in which case it’s all fully absorbed, but the net absorption is down
- But the point is, somewhere between 25 and 75% of dietary magnesium actually gets net absorbed, and that range, which is enormous, is a function of total body magnesium.
- So if you are replete with magnesium, you may only absorb 25% of your dietary magnesium
- Conversely, if you’re deficient, you might only absorb or you might absorb up to 75%
- 75% is an enormous amount, in fact, of all the types of supplemental magnesium out there, 80% absorption is considered “Herculean”

Balance of magnesium in the body

![](https://peterattiamd.com/wp-content/uploads/2023/12/f2-ama54.png)

**Figure 2.** Source: [Jahnen-Dechent and Kettler Clin Kidney J. Feb. 2012](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4455825/)

- The big stores on the right-hand side of this page: bones, muscle, other tissue
- So we’re saying average size person, you’ve got about 12.9 grams of magnesium, 12,900 milligrams within the bone
- Muscle, 6.5 grams, other tissues just under five grams of magnesium
- Again, that’s 60% of total body mass is in the bone and the other 40% is essentially divided between muscle and tissue, with only 1% being accounted for in the plasma

Now, let’s look at the flow chart of what’s happening

- As you take in 360 milligrams, you’re going to lose roughly 260 milligrams of that through fecal loss and 100 milligrams through kidney loss while you net absorb 100
- So in the intestine, the absorption is only going to be 120, there’s another secretion of 20 so that gets you to the net of 100
- And then look at where the kidneys work
- They’re filtering an enormous amount, not the total body pool, but quite a bit, and they’re going to filter 2,400 out—so they dump 2,400 milligrams out and they reabsorb 300 milligrams.
- This represents a person in normal and healthy magnesium balance, and because I think most people are not, we need a higher intake here
- The point is, if you overshoot it, the excess is going to come out in the body either through GI loss or kidney loss
- Caution: The times that you need to be careful of this is if you take a person who’s got very, very compromised kidneys, there’s at least a risk that you’ll get too much magnesium accumulation, which can lead to fatal cardiac arrhythmias (although very rare compared to say potassium excess)

## Daily targets for magnesium supplementation and whether it’s possible to take too much [30:15]

***How much magnesium should someone even target in a daily supplement?***

- The answer is a bit complicated because the real question you have to be contemplating is: how much **absorbed** magnesium should I be targeting?
  - Not, how much magnesium on the label should I be targeting?
- But at a minimum, one should target at least 400 milligrams of magnesium per day being absorbed
- But if there’s any reason that you should be higher, for example, if you’re a person who has migraines, you should easily be pushing the boundaries of that to 600 or more
  - If you’re drinking alcohol, if you’re taking loop diuretics, if you have any of these other things that we’ve talked about that might increase your magnesium turnover, you’ve got to be higher.
- Peter personally aims for probably 600 to 800 milligrams per day (although that was based on his erroneous believe that he was losing it through perspiration from exercise)
- That said, unless you have kidney failure, you want to err on the side of overdoing it
- The biggest thing you have to be mindful to know if you should reduce intake would be GI distress

*Can you take too much magnesium in a supplement?*

- The short answer is, of course, you can take too much of anything in a supplement
- Don’t assume that because something is over the counter that it is completely safe
  - Extreme example: Tylenol is over the counter. It is an absolutely fatal drug. At even 10x, and certainly at 20x the recommended dose, you will be dead in two to three days
- Magnesium is demonstrably safer than those and demonstrably safer than mucking around with sodium and potassium
  - Sodium is very important at regulating the osmolality of plasma, the osmolarity, and also it regulates how much water you have in and around cells—so too much or too little sodium can be very problematic (especially on the too little side)
  - Potassium plays such an important role in regulating the charge difference across a cell, too much or too little is problematic (especially too much)
- Magnesium doesn’t have that issue, and therefore, you just have a much larger buffer of how much you can take
- When most people overdo it on the magnesium front, they don’t get into trouble with cardiac arrhythmia, they get into trouble with explosive diarrhea

## The different forms of supplemental magnesium [34:00]

**What are the different forms of supplemental magnesium and what are those different forms used for?**

- There are many forms of magnesium supplements and they certainly vary significantly in their bioavailability or absorption
- So deciding which ones you need are a function of understanding why you want the magnesium
- Peter takes three different magnesium supplements (to be explained in a moment)

Broadly speaking, you would divide them into organic and inorganic

- The two most common inorganic salts of magnesium would be magnesium oxide and magnesium chloride
  - Interestingly, magnesium chloride is very highly absorbed and it has a very slow transit through the GI tract whereas the magnesium oxide is very poorly absorbed providing almost no elemental magnesium and has very limited bioavailability, but serves as, arguably, the single best tool that you can use to regulate bowel function
- On the other end of the spectrum, you have these organic sources
  - magnesium glycinate, magnesium citrate, magnesium lactate, and so on
  - these are generally much more well absorbed, and therefore, we typically turn to these in addition to mag chloride as the ways that we are going to replace magnesium.
  - Again, food has an absorption roughly between about 25 and 75% and that’s what you’ll typically see from these organic sources
  - the organic sources of magnesium, when you buy these things online or at your drugstore, you should assume that whatever amount of magnesium it says on the back of that, you’re getting somewhere between 70 to 80% of that

## How absorption of magnesium from food compares to absorption from supplements [36:15]

*What do we know about the absorption of magnesium and food compared to the absorption in supplements?*

- Absorption tends to be better in small doses than large doses
- So if you take a 500 milligram tablet of magnesium citrate, optimistically, you would expect to get somewhere between 350 to 400 milligrams of magnesium out of it
- assume that you’re going to get greater absorption if you took 500 milligrams of dietary magnesium spread out over three or four meals during the day
- In that sense, spreading your magnesium supplement out over at least twice a day
- Is one attempt to increase or maximize absorption

## Choosing the right magnesium supplements for optimal absorption [37:15]

- There are no shortage of brands out there
- If you go on Amazon and search magnesium, you’re going to get reams and reams of pages

But here are the most common forms of magnesium:

![](https://peterattiamd.com/wp-content/uploads/2023/12/f3-ama54.png)

**Figure 3.**

So the inorganic ones, the salts, magnesium oxide, magnesium chloride

- The typical doses you’re going to see are 400 to 500 milligrams on the oxide
- And the chloride, the 143 mg dose is referring to the brand Peter likes called [SlowMag](https://slowmag.com/)
  - SlowMag has a coat on it that makes it very delayed in its release from the stomach, and therefore, it causes much less GI distress
  - So two tablets of SlowMag contain 143 milligrams of elemental magnesium, and you would expect to absorb about 80% of that without any of the GI distress
  - Conversely, if you take a 400 milligram of mag oxide, you’re getting somewhere between 16, maybe 20 milligrams of magnesium, and you’re going to get a lot of GI distress in certain people
- Peter also takes 400 to 500 milligrams of magnesium oxide before bed every night as well as something called magnesium L-threonate (to be discussed)

If we look at the organics

- The most common by far are citrate and glycinate, and you can see the typical doses there, 150-500, 100-400
- Here we have potentially very high absorption. Again, remember, the absorption here is in part a function of your magnesium state.
- So if you have plenty already, you’d expect that you’re going to be pooping and voiding out a lot of magnesium and you will not be keeping 80% of it in you
- Magnesium L-threonate, another organic variant, which we will discuss because it has a unique issue, also an 80%

**Determining how much you should supplement**

- When you look at how much magnesium you get in food, you can do the math and say, how many of those high magnesium foods do I eat?
- Then you can optimistically assume that you’re getting 50% absorption of that mg from the food.
- And then look at your supplements (with their associated absorption) and you can try to figure out if you’re getting 500 to 600 milligrams of magnesium a day (which is what Peter thinks you should aim for if you have healthy kidneys)

## The unique ability of magnesium L-threonate to increase brain magnesium concentration [40:15]

**How magnesium L-threonate differs from other formulations of magnesium**

- Magnesium L-threonate is a very highly absorbed form of magnesium, so it’s right up there with magnesium chloride, in that 80 plus percent potential absorption
- In rats, it’s found to increase serum magnesium levels higher than mag chloride, but it’s not clear that we could extrapolate that to humans
- The reason we’re talking about it is NOT that it’s probably the most highly absorbed form of magnesium, it’s the fact that it has a seemingly higher capacity to cross the blood-brain barrier, thereby increasing the concentration of magnesium in the CSF more than other magnesium formulations
- And when you think about one of the most important needs for magnesium is, of course, in the central nervous system
- One very interesting [rat study](https://www.academia.edu/70008110/Neurobehavioral_and_biochemical_effects_of_magnesium_chloride_MgCl2_magnesium_sulphate_MgSO4_and_magnesium_L_threonate_MgT_supplementation_in_rats_A_dose_dependent_comparative_study) that demonstrated L-threonate increased brain magnesium levels as measured by looking at CSF more so than other magnesium-controlled supplements
- In summary, we believe that magnesium L-threonate is getting into the brain about 70% more than even the other most highly absorbed forms of magnesium

## Potential cognitive benefits of magnesium [43:00]

***What do we know about what that means for sleep or cognition? Does the fact that L-threonate can cross the blood-brain barrier have an impact on that?***

- 10 years ago, what brought L-threonate to Peter’s attention was some data suggesting that magnesium L-threonate, an over-the-counter supplement, could actually delay progression of patients with mild cognitive impairment to dementia
- That was the first indication

There was a more recent [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4927823/) in 2016 that looked at 44 adults somewhere between 50 and 70 years of age with self-reported complaints of cognitive impairment

- The study was powered to show a 50% reduction in anxiety based on something called the Hamilton Anxiety Score, but not improvements in cognitive tests.
- So both magnesium and the placebo groups had a reduction in anxiety by this metric, but there was no statistical significance between the groups
- So the magnesium group did have a significant improvement in something called the Trail Making Test B, which is a measure of executive function at six weeks that was maintained at 12 weeks.
- Worth pointing out that the dose in this study was either 1.5 or 2 grams per day
- And it’s very important, the dosing on this stuff is really confusing
- This is the dose of magnesium L-threonate
- Now, if you go online and you look up magnesium L-threonate, you’re going to get a lot of different brands, but if you look at the back, they all contain something called **Magtein**, and that’s how you know you’re getting the actual magnesium L-threonate compound
- And you will notice that the most typical serving size is like three big capsules which is two grams of magnesium L-threonate
- But notice, of course, that that’s only 144 milligrams of magnesium
- Most of that 2 grams is the L-threonate—it’s the transporter that increases the selective absorption or transport of magnesium into the CSF
- So again, these people are taking two to three of those L-threonate capsules
- Also, remember that all these participants in this study had mild cognitive impairment based on their Trail Making Test B scores, or what’s called TMT-B scores, but the improvement in the mag threonate group was indeed considered significant and it eliminated the deficit between the magnesium group and what were considered normative data from age matched subjects
- So that’s not a perfect test because you’re comparing people who weren’t in the study, but there was also a statistically significant finding in another cognitive composite score that combined four other validated cognitive tests (the TMTB, the digit span, which is a short-term memory, the flaker test, and then face name recognition)

There was a [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9786204/) in 2022 of 100 healthy Chinese adults

- Ages spanning 18 to 65 that showed that participants who were above the age of 45 had a significant improvement in memory findings using magnesium L-threonate compared to the younger participants
  - in other words, the younger participants didn’t get the benefit from it that the older participants, those over 45 did
- We could go into all the details of what the different tests were that they looked at, but they used standardized learning tests and there’s no doubt about it, that people got better on them as they were older, which may reflect that older people had more of a magnesium deficiency
- It may reflect that supernormal levels of magnesium in the case of people who are already experiencing some decline are beneficial
- “These are very interesting questions. I would love to see more follow-up on this because, of course, I view these as largely pilot studies that don’t really offer the great mechanistic insight, but the real issue here is the dosing.”

- But the most notable finding was in something called the memory quotient or the MQ cognition score, which is adjusted for age and education. And there’s no doubt about it, that the Magtein group had a dramatic improvement in the memory quotient study

Peter’s takeaways:

“*Just to reiterate the point here. I think there’s something here. I think it’s very interesting. I would love to better understand the mechanism. And more importantly, I think I would better love to understand patient selection…*

*…Is this indeed a true cognition booster that all of us can benefit from, or is it something that you only benefit from if you’re magnesium deficient and or something you only benefit from when you’re above a certain age and or only something you benefit from if indeed you have cognitive impairment? …*

*All of these questions, of course, are relevant and would have enormous implications for, I think, how we could use something as available and as low in toxicity as a simple magnesium supplement.*”

## Potential sleep benefits of magnesium [48:45]

⇒ Check out [AMA #42](https://peterattiamd.com/ama42) for more on magnesium L-threonate and sleep

***What do we know about the benefit of magnesium L-threonate as it relates specifically to sleep?***

- We know less than we do on cognition
- It’s unclear how big the effect is on sleep beyond the examples of where people are magnesium deprived

**Existing data**

- If you look at studies where at least based on serum levels, people do not have deficiency (and that’s a big if), there’s no reported effect of dietary intake of magnesium on sleep

This [2002 study](https://www.researchgate.net/publication/11222762_Oral_Mg2_Supplementation_Reverses_Age-Related_Neuroendocrine_and_Sleep_EEG_Changes_in_Humans) was placebo controlled and had a crossover

- It’s a very small study, but a rigorous study of 12 patients ages 60-80, six men and women, each serving as their own control
- They undergo a polysomnography before a three-week treatment of magnesium
- This study has a bit of a problem to it, which is they used magnesium oxide
  - They used 400 milligrams of magnesium oxide three times daily
  - First of all, that’s a really big dose so Peter is surprised they weren’t giving too much GI distress
  - More importantly, that’s not a ton of magnesium overall
  - That’s like 30 milligrams of supplemental magnesium above dietary effect per day
- Another big drawback of the study was they weren’t keeping track of dietary magnesium levels
  - Now, presumably they weren’t changing significantly, and since each patient is acting as their own control, that can sort of be forgiven
  - But we don’t really have a sense of whether or not these people magnesium deficient
- So *what did the study find*?
  - Slow wave sleep had a significant increase in that using polysomnography going from roughly 10 minutes per night to 16.5 minutes per night
  - It’s also a 6.5 minute increase in slow wave sleep when, if you consider the entire population, average slow wave sleep is 70 to 90 minutes per night, but it declines steeply with age
- Overall, Peter is not sure what to make of this
  - On the one hand it says that people who are 60 to 80 years old are clearly coming in with badly, badly deteriorated slow wave sleep, and that Magtein is significantly increasing it by 65%.
  - But is it clinically significant? … Peter doesn’t know
- Another question would be: What would be the implication for people who have disrupted slow wave sleep who are significantly younger, who might have a higher potential for slow wave sleep?
  - We don’t know, but Peter would really like to see it studied
- The other thing that was noted here was that cortisol levels decreased in the first few hours of sleep and that both renin and aldosterone increased in the later part of the night
  - This was done by measuring something called the cortisol AUC (area under the curve), and it was decreased by about 30-35%
  - It’s unclear if it’s clinically significant but it’s certainly moving in the right direction

> “I find this stuff pretty fascinating. I tend to err on the side of this is a relatively low risk proposition.” —Peter Attia

From a risk perspective, the biggest risk is to your pocketbook

- These magnesium L-threonate supplements are not cheap relative to more traditional magnesium supplements

More studies on magnesium and sleep:

- [Abbasi et al., 2012](https://pdfs.semanticscholar.org/d3e2/31c5d5fd4983766865c3dac729d388f0a6c3.pdf)
- [Nielsen et al., 2010](https://www.ncbi.nlm.nih.gov/pubmed/21199787)
- [Saba et al., 2022](https://pubmed.ncbi.nlm.nih.gov/36354243/)
- [Abbasi et al., 2013](https://www.researchgate.net/publication/344441857_Effect_of_Magnesium_Supplementation_on_Mental_Health_in_Elderly_Subjects_with_Insomnia_a_Double-blind_Randomized_Clinical_Trial)
- [Abbasi et al., 2012](https://www.ncbi.nlm.nih.gov/pmc/articles/pmid/23853635/)
- [Hornyak et al., 2006](https://onlinelibrary.wiley.com/doi/abs/10.1097/01.ALC.0000145695.52747.BE)

## Takeaways on magnesium and a look into Peter’s personal protocol [53:15]

- Magnesium is very important and it’s probably not an accident that there are hundreds, if not more, supplements that are available
- We have the fortune of it being not just important, but something where you have an asymmetric ability to overshoot it
- you can really overshoot it in the context of most clinical scenarios, i.e. modestly normal kidney function, and the worst thing that’s going to happen to you is you’re going to get a belly ache and maybe some diarrhea
- That said, most people are probably woefully deficient if they are not supplementing and they might not notice the effects of it
- When Peter does DEXA scans on patients and when he sees Z-scores and T-scores that are not up to par, Peter gets very aggressive with magnesium supplementation
- It’s a no-brainer move when replacing magnesium or getting magnesium to the right level

> “The amounts of magnesium are probably variable based on the quality of the food itself, and therefore, I think most of us end up in a situation where we’re going to need to replace it with supplements, over the counter supplements.” —Peter Attia

- Broadly speaking, magnesium supplements are divided into two categories, inorganic and organic,
- And for the most part, with the exception of magnesium oxide (which is primarily a tool you should use to regulate bowel function and not to “replace” magnesium), the others are quite bioavailable, up to 80% absorbed if you’re in a reasonably deficient state
- And basically, the one you take is *a function of how much GI tolerance you can take*

**Peter’s personal protocol**:

- Peter is a big fan of [SlowMag](https://slowmag.com/) which he’s been using for more than a decade
  - Peter will typically take 2 or 3 (and sometimes 4 if he’s cramping up) in the morning
- Peter’s nighttime routine is a mag oxide
  - He will take 400-500 milligrams, plus the full dose of **magnesium L-threonate**, which isn’t providing that much (about 144 milligrams of magnesium)
- So overall Peter is aiming for about 600 to 800 mg per day
  - That may sound like a lot, but he believes people can tolerate even more than that (hospitalized patients can often get 2-4 grams of intravenous magnesium without any issues)

As far as the benefits of magnesium go…

- Peter’s view is that for a healthy, active person, the real benefits are probably on mitigating PVCs, pre-ventricular contractions and muscle cramps
- And anyone who’s susceptible to headaches and migraines probably benefits greatly, at least in terms of prevention
  - Intravenous magnesium has great efficacy, but it’s not really a practical solution for someone in the moment, but it suggests that magnesium levels, if high enough, can reduce both frequency and severity of these things
- Peter thinks that the most important thing here is the impact of magnesium on cognition and sleep
  - The data looks slightly promising for both of those, maybe slightly more promising on the cognition side, but it comes with all of the caveats and questions that remain unanswered such as…
    - Is this true only in people who are elderly?
    - Is it only true in people who are deficient?
    - Or is it only true in people who already have some sort of cognitive decline?
    - “*All of these questions to me remain unanswered, and I think are ripe for further study*.” says Peter

> “Magnesium supplementation is one of the most common supplements found within our patient population. And if they’re not taking it when they come to us, we’re generally putting them on it when they’re in our practice.” —Peter Attia

## Peter’s new benchmarks related to exercise and age [58:30]

**Peter’s recent thinking around exercise and benchmarks**

- Peter has been working out a lot with his brother [Paul Attia](https://twitter.com/Paul_Attia)
- They started thinking about some universal metrics and wondering how long they would be able to continue them as they age

*One example using VO2 max and age*:

- What is the longest you can go where your VO2 max in milliliters per kilogram per minute is still higher than your age?
- So at 50, your VO2 max would need to be greater than 50 milliliters per kilogram per minute (pretty challenging)
- For context, Peter is 50 years old and he estimates his VO2 max to be between 52 and 56
- This obviously gets harder as you age—would be hard to find many 60 year olds with a 60+ VO2 max but a 30 year old would have big problems if their VO2 max was less than 30 (which unfortunately isn’t that rare)

*Another benchmark example*:

- - Loading up a trap bar with your body weight
  - Carry it for 30 seconds, put it down for 30 seconds, carry it for 30 seconds, put it down for 30 seconds, and so on for 20 minutes
  - Peter can do that pretty easily today, but the question is… *how long will that continue to be easy and at what point will it become impossible?*

- *At what point will I simply not be able to carry my body weight 30 seconds on, 30 seconds off, 20 times?*

- This is a huge test of grip strength, core strength, stability, balance, and a whole bunch of things
- “I think it’s a great benchmark test of strength and health, but at some point, I will fall below a body weight based metric.” says Peter

*Another benchmark–Standing broad jump:*

- [Andy Galpin](https://www.andygalpin.com/) mentioned this one to Peter
- Up until what point will I be able to do a standing broad jump that is in excess of my height?
- Peter loves standing broad jumps and includes them at least once per week as part of his warm up
- In one movement, you get an enormous test of your concentric strength and your eccentric strength
- It’s concentric strength, explosive power and strength to get you off the ground and you have to stick the landing
- You actually have to be able to land and apply the brakes, and that’s an enormous test of your eccentric strength
- The question is, *how long will I be able to continue to do that where my jump is further than my height laying down*?

**Dead hangs and grip strength**

Pre-shoulder surgery, Peter was doing a lot of dead hangs. Is he back doing dead hangs now?

- He is nowhere near his pre-shoulder strength levels because…
  - A) he had shoulder surgery in March of ’22, and that meant six months of no dead hanging at all and
  - B) his hands and grip are more fatigued nowadays because he’s doing so much more farmer walks than before so he never shows up somewhat rested to a dead hang day

Peter’s best dead hang prior to shoulder surgery was 4 min 35 secs

- Now, he usually stops at 3 minutes because he’s in “obscene amounts of pain” at 3 minutes
- He hasn’t gone to failure for 1.5 years (since surgery)
- Peter says he would never go to failure more than once a month because you really pay a price for it
- Failure means you go until you fall off the bar, not until it hurts a lot, you go until you fall off that bar
- You don’t need to do that very often, but it’s a good test set
- In fact, if you’re doing dead hangs on a regular basis, they shouldn’t be to true failure, rather you should be doing volume sets

More about his PR on the dead hang

- The day Peter set his personal record he did a relatively light workout prior which was a lower body workout without much carrying or deadlifting so he felt relatively fresh
- These days, his hands are almost in a constant state of fatigue based on all the farmers carries he is doing

Nick wonders whether Peter’s grip might actually be stronger than it was pre surgery and it may just be that he’s more fatigued based on his current routine and therefore if he was fresh he might actually be able to beat his 4:35 dead hang time. What does Peter think?

- Peter is not sure
- While he feels like he’s bounced back in every way imaginable from shoulder surgery, the dead hang is extremely challenging

Peter had a goal of hitting 5 minutes on the dead hang inspired by the [9c strength test](https://www.trycrawl.com/common-questions/the-ultimate-climbing-test-the-9c-strength-test)

§

## Selected Links / Related Material

**AMA episode of The Drive on bone health**: [#214 – AMA #37: Bone health—everything you need to know](https://peterattiamd.com/ama37/) | Peter Attia (peterattiamd.com) [6:45, 54:15]

**Episode of The Drive with Gerry Shulman**: [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) | Peter Attia (peterattiamd.com) [7:15]

**There are a number of clinical studies, though not all of them, that suggest that supplementing with magnesium and a magnesium rich diet can improve insulin sensitivity and fasting glucose**: [The Role of Magnesium in the Pathogenesis of Metabolic Disorders](https://www.mdpi.com/2072-6643/14/9/1714) (Pelczynska et al., 2022) [7:45]

**Meta-analysis found that magnesium can help reduce migraines**: [Effects of Intravenous and Oral Magnesium on Reducing Migraine: A Meta-analysis of Randomized Controlled Trials](https://pubmed.ncbi.nlm.nih.gov/26752497/) (Chiu et al., 2016) [15:30]

**Exercise results in a redistribution of magnesium in the body**: [Update on the relationship between magnesium and exercise](https://pubmed.ncbi.nlm.nih.gov/17172008/#:~:text=Strenuous%20exercise%20apparently%20increases%20urinary,in%20a%20magnesium%2Ddeficient%20status) (Nielsen and Lukaski, 2006) [22:15]

**Meta analysis looking at magnesium for reducing migraines**: [Effects of Intravenous and Oral Magnesium on Reducing Migraine: A Meta-analysis of Randomized Controlled Trials](https://pubmed.ncbi.nlm.nih.gov/26752497/) (Chiu et al., 2016) [41:30]

**Magnesium L-threonate increases magnesium levels in the brain more so than other forms**: [Neurobehavioral and biochemical effects of magnesium chloride (MgCl2), magnesium sulphate (MgSO4) and magnesium-L-threonate (MgT) supplementation in rats: A dose dependent comparative study](https://www.academia.edu/70008110/Neurobehavioral_and_biochemical_effects_of_magnesium_chloride_MgCl2_magnesium_sulphate_MgSO4_and_magnesium_L_threonate_MgT_supplementation_in_rats_A_dose_dependent_comparative_study) (Sadia Sadir, 2019) [41:30]

**2016 study found that magnesium improved cognitive function in older adults**: [Efficacy and Safety of MMFS-01, a Synapse Density Enhancer, for Treating Cognitive Impairment in Older Adults: A Randomized, Double-Blind, Placebo-Controlled Trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4927823/) (Liu et al., 2016) [43:30]

**A study of 100 healthy Chinese adults spanning 18 to 65 showed that participants who were above the age of 45 had a significant improvement in memory using magnesium L-threonate**: [Efficacy and Safety of MMFS-01, a Synapse Density Enhancer, for Treating Cognitive Impairment in Older Adults: A Randomized, Double-Blind, Placebo-Controlled Trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9786204/) (Zhang et al., 2022) [46:15]

**AMA episode of The Drive discussing magnesium L-threonate**: [#233 – AMA #42: Optimizing sleep – bedtime routine, molecule regimen, sleep trackers, sauna, & more](https://peterattiamd.com/ama42/) | Peter Attia (peterattiamd.com) [48:45]

**Study finding magnesium increased slow wave sleep in 60-80 year old patients**: [Oral Mg2+ Supplementation Reverses Age-Related Neuroendocrine and Sleep EEG Changes in Humans](https://www.researchgate.net/publication/11222762_Oral_Mg2_Supplementation_Reverses_Age-Related_Neuroendocrine_and_Sleep_EEG_Changes_in_Humans) (Held et al., 2002) [49:00]

**More studies involving magnesium’s impact on sleep**: [49:00]

- [Abbasi et al., 2012](https://pdfs.semanticscholar.org/d3e2/31c5d5fd4983766865c3dac729d388f0a6c3.pdf)
- [Nielsen et al., 2010](https://www.ncbi.nlm.nih.gov/pubmed/21199787)
- [Saba et al., 2022](https://pubmed.ncbi.nlm.nih.gov/36354243/)
- [Abbasi et al., 2013](https://www.researchgate.net/publication/344441857_Effect_of_Magnesium_Supplementation_on_Mental_Health_in_Elderly_Subjects_with_Insomnia_a_Double-blind_Randomized_Clinical_Trial)
- [Abbasi et al., 2012](https://www.ncbi.nlm.nih.gov/pmc/articles/pmid/23853635/)
- [Hornyak et al., 2006](https://onlinelibrary.wiley.com/doi/abs/10.1097/01.ALC.0000145695.52747.BE)

**The brand of magnesium chloride Peter prefers**: [SlowMag](https://slowmag.com/) | (slowmag.com) [55:30]

§

## People Mentioned

- [Gerald Shulman](https://medicine.yale.edu/profile/gerald-shulman/) [7:15]
- [Paul Attia](https://twitter.com/Paul_Attia) (Peter’s brother) [58:45]
- [Andy Galpin](https://www.andygalpin.com/) [1:01:30]

§