# #148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program

**Source:** [https://peterattiamd.com/richardmiller/](https://peterattiamd.com/richardmiller/)

---

Richard Miller is a professor of pathology and the Director of the Center for Aging Research at the University of Michigan. He is one of the architects of the NIA-funded Interventions Testing Programs (ITPs) animal study test protocol. In this episode, Rich goes through the results of the long list of molecules tested by the ITP—including rapamycin, metformin, nicotinamide riboside, an SGLT-2 inhibitor called canagliflozin, and more. Many of the discussed outcomes have had surprising outcomes—both positive and negative findings.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/richardmiller/the_Drive_public.png)

Play

#148 - Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program

#148 - Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program

1x15s30s

0:002:14:14

## We discuss:

- Rich’s interest in aging, and how Hayflick’s hypothesis skewed aging research (3:45);
- Dispelling the myth that aging can’t be slowed (15:00);
- The Interventions Testing Program—A scientific framework for testing whether drugs extend lifespan in mice (29:00);
- Testing aspirin in the first ITP cohort (38:45);
- Rapamycin: results from ITP studies, dosing considerations, and what it tells us about early- vs. late-life interventions (44:45);
- Acarbose as a potential longevity agent by virtue of its ability to block peak glucose levels (1:07:15);
- Resveratrol: why it received so much attention as a longevity agent, and the takeaways from the negative results of the ITP study (1:15:45);
- The value in negative findings: ITP studies of green tea extract, methylene blue, curcumin, and more (1:24:15);
- 17α-Estradiol: lifespan effects in male mice, and sex-specific effects of different interventions (1:27:00);
- Testing ursolic acid and hydrogen sulfide: rationale and preliminary results (1:33:15);
- Canagliflozin (an SGLT2 inhibitor): exploring the impressive lifespan results in male mice (1:35:45);
- The failure of metformin: reconciling negative results of the ITP with data in human studies (1:42:30);
- Nicotinamide riboside: insights from the negative results of the ITP study (1:48:45);
- The three most important takeaways from the ITP studies (1:55:30);
- Philosophies on studying the aging process: best model organisms, when to start interventions, which questions to ask, and more (1:59:30);
- Seven reasons why pigs can’t fly (2:08:00); and
- More.

§

## Show Notes

## Rich’s interest in aging, and how Hayflick’s hypothesis skewed aging research [3:45]

**Upbringing, education, and interest in aging**

- Born in Philadelphia and raised in Cheltenham Township, the northern suburbs of Philadelphia with his parents and two brothers
- He took an interest in science at age 5
- “*I decided early on that aging was bad for you. It made people sick and then die. I was kind of against that. And the best way to fight against that was to learn something about aging and to develop ways of slowing the aging process down*.”
- Got his MD and Ph.D. Degrees at Yale in the 1970s

*Refining his focus on aging*

- Rich always wanted to work on aging so his initial Ph.D. project involved somatic cell hybridization
- He wanted to mix together two kinds of cells—one that could divide and one that couldn’t divide—and immortalize the T lymphocytes that couldn’t divide
- But the more he learned about the [Hayflick hypothesis](https://en.wikipedia.org/wiki/Hayflick_limit) and all of that cell senescence stuff, the more convinced he was that **it wasn’t going to teach him anything about aging**
- He switched focus and became an immunologist in order to study immunology and how aging modified the immune system
- Starting about 1990, he gradually transitioned into focusing on aging more broadly
- Today, he does very little immunology: His focus is now on **what is controlling the aging process and using that information to develop interventions**

**History around division of cells [7:30]**

- History of the Hayflick hypothesis and how it skewed aging research
- The phenomenon that Hayflick more or less discovered was that if you take normal, non cancer, human cells and you let them grow in tissue culture, they will divide but only a limited number of times (about 50) and then they will stop
- Hayflick decided that was akin to aging and that he had found a way to study aging in culture — “*Now that’s nuts. It’s nothing like aging in the slightest*.” says Rich
- But people were really excited by tissue culture and a whole generation of superb cell biologists spent their life investigating the Hayflick system under the illusion that they were studying aging
- About 20 years after this, Rich spoke to [Vittorio Defendi](https://pubmed.ncbi.nlm.nih.gov/?term=Defendi%20V%5BAuthor%5D&cauthor=true&cauthor_uid=4322080), an old colleague of Hayflick:
  - On one occasion, Hayflick had been complaining to Defendi that his cells in culture “already stopped growing”
  - Defendi (allegedly) told Hayflick in a joking manner, “Maybe they’re just getting old.”
  - Hayflick, whose sense of humor is notoriously absent, did not understand he was being joshed
  - He thought it was a scientific hypothesis, and after a while, he persuaded himself that it was HIS hypothesis and then that it was the *correct* hypothesis
- It later became established that the limitation of growth—the [Hayflick limit](https://en.wikipedia.org/wiki/Hayflick_limit)—was actually due to the *shortening of telomeres*
  - This was a very important, and true, finding
  - However, people convinced themselves that, because they thought it was like aging, the telomeres were something to do with aging too
- Now a whole new generation of people bought into the Hayflick idea and the telomeres concept as a central cause of the aging process, *despite all the evidence to the contrary*

⇒ A prime example of how the line of thinking has skewed our thoughts is a [recent study](https://pubmed.ncbi.nlm.nih.gov/33206062/) from Israel on the anti-aging effect of HBOT:

- This story is being sold as the most rigorous study in the history of humans demonstrating the anti-aging benefits of hyperbaric oxygen
- A group of volunteers were exposed to hyperbaric oxygen and their telomeres lengthened a bit and therefore, many believe, hyperbaric oxygen is the “fountain of youth”
- The problem, of course, is that **aging and telomere length are not the same thing**

*Rich points out*:

- It’s entirely possible that hyperbaric oxygen could well have health benefits under certain circumstances — “*There’s no evidence that that statement is true, but it’s also not silly.*”
- “I*f you want to prove that hyperbaric conditions, suitable doses, and at suitable time intervals, et cetera, might be good for you, that’s a very plausible idea worth testing. It’s just that you don’t test it by measuring telomeres*.”

The exciting part about telomere research:

- The work that Blackburn did is really amazing biology (and worthy of a [Nobel Prize](https://www.nobelprize.org/prizes/medicine/2009/illustrated-information/)), but it doesn’t really explain aging — “And those two statements can co-exist.” says Peter
- Telomere biology is also a critical element in cancer biology — the telomere story is a fundamental advance in our understanding of cancer in people
- And it may also have an interesting sidelight in evolutionary biology (some species, mice, for instance, have extremely long telomeres)
- [Vera Gorbunova’s work](https://www.sas.rochester.edu/bio/labs/Gorbunova/2017/03/27/dr-vera-gorbunova/) looks at how different species with different body sizes and lifespans differ in their ways of stopping the cancer process
- So, telomere research may be a fundamental step in our understanding of cancer biology in people and the way in which anti-cancer defenses evolve
- However, “*the notion that it’s sort of a shortcut for actually working on aging in my view does not hold up very long*”

## Dispelling the myth that aging can’t be slowed [15:00]

**Rich’s role in starting the ITP (**[**Interventions Testing Program**](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp)**)**

- The [National Institute on Aging](https://www.nia.nih.gov/) (NIA) has a division of aging biology, which at that time was headed by a visionary guy named [Huber Warner](https://www.nia.nih.gov/news/nia-mourns-loss-dr-huber-warner) about 18 years ago
- Warner commissioned a committee of about 12 of to sit down with him and [Nancy Nadon](https://orwh.od.nih.gov/research/sex-gender/research-spotlights/nancy-nadon) to discuss what the NIA might do to develop a program in which potential interventions were tested directly
- Together with [Arlan Richardson](https://www.ouhsc.edu/roca/Our-People/Profile-Page/arlan-richardson-phd-1), Rich put together what they viewed would be the best way to do this focusing on mice which they presented (successfully) to Warner

⇒ See [An aging Interventions Testing Program: study design and interim report](https://onlinelibrary.wiley.com/doi/10.1111/j.1474-9726.2007.00311.x)

**Dispelling the myth that aging can’t be slowed**

Around the same time (2002), Rich wrote [Extending Life: Scientific Prospects and Political Obstacles](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2690099/)

- Rich was asked to give a talk at the law school at the University of Michigan which became the basis
- Rich laid out the basic thesis of the paper, “Look, discussions of anti-aging medicine aren’t silly. The development of an anti-aging strategy is starting to make headway and further work here would be worthwhile.”
- Rich adds, “It’s still an evolving process. We’re not there yet. But 18 years ago, we certainly weren’t even close to there.”

Around that time, Rich attended a [Gordon Research Conference on Aging](https://www.grc.org/biology-of-aging-conference/) where he got into a disagreement with his friend, [George Martin](https://depts.washington.edu/mbwc/about/profile/george-martin)

The argument was around the idea of whether aging:

- A) Could be considered a single process—suggesting a drug might slow that process down; Or
- B) was a very complex spaghetti bowl of different processes, each one of which had its own independent control
  - They took a poll of the 120+ scientists and the average person agreed more closely with B (aging being too complex to slow)
  - Note: Rich was in favor of A

> “Very few people at that time, even among the sophisticated, best-educated professional aging researchers would check the box that said, ‘yeah, there’s a single aging process.’ And until you check that box, the notion that you could interrupt the process makes no sense—because if there is no process then interrupting it is a hopeless goal.” —Rich Miller

- You mush view aging as a unitary process in order to devote much time to trying to slow that process down
- But it is confusing because there are hundreds of things that go wrong in old age and learning about any one of them can be very productive (the one that leads to cataracts, the one that leads to muscle failure, etc.)
- But once you believe the concept that there’s some **underlying mechanism** that speeds them or slows them down, then suddenly it becomes permissible to think about ways to slow it down

At the time, there was some reason to have “hope”…

- Such as the [vast literature on caloric restriction](https://peterattiamd.com/dr01/) (CR) that, almost without exception, showed some form of caloric restriction could extend life
- That being the work of [Cynthia Kenyon](https://en.wikipedia.org/wiki/Cynthia_Kenyon) on C. elegans (worms) whose first [paper](https://pubmed.ncbi.nlm.nih.gov/8247153/) made two big discoveries:
  - One was the mutants of DAF-2 (analog of the IGF receptor) extended lifespan
  - And that mutants of DAF-16 blocked the receptor from being turned on
  - Later, it was discovered you could [combine with CR and then get a better outcome](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3001308/)

*Why this was relevant as a proof of principle*:

- Interestingly, Nature published a very erudite detailed [six-page paper](https://www.nature.com/articles/362305a0) in 1993 by Linda Partridge “proving” that there could never be a single gene mutation that extended lifespan
- But 6 months later, [Cynthia’s paper](https://pubmed.ncbi.nlm.nih.gov/8247153/) demonstrated that a single gene mutation could extend longevity dramatically in a worm
- When Linda Partridge was asked to comment on it she argued, “C. elegans is different…But there could never ever be in any other species a gene that does this, trust me on that.”
- About 3 years later, Andrzej Bartke’s [paper](https://pubmed.ncbi.nlm.nih.gov/8900272/) with Holly Brown-Borg showed that the Ames dwarf mutation could extend lifespan by about 45% in a mouse

> “*Once it was true for mice and true for worms, the idea that there might be something to this, became defensible.*” —Rich Miller

Even so, about 2 years after the Ames dwarf paper, Rich was at another conference:

- [Robin Holiday](https://en.wikipedia.org/wiki/Robin_Holliday), a very well-respected Australian scientist, gave a keynote lecture explaining why you could **never** have a gene that had slowed the aging process and extended longevity
- Rich raised his hand and pointed to the existing evidence in worms and mice
- But Robin just repeated that “*there could never be a single gene mutation that could extend longevity*.”
- Rich points out that many people still are reluctant to accept the general principle that there are aging processes which can be slowed down if you consider them as a unitary group of changes with a common controlling factor

**Many smart people are fixating on the wrong point**

- Many smart people are fixating on the wrong point which is whether or not it’s a single gene or multiple genes
- The bigger point is **whether aging is malleable, yes or no?**
- Furthermore, everybody was focused on ‘*what is the cause of aging?*’
- But the more appropriate question is ‘***what is it that can slow aging?***’

**Rich’s framework for what is causing aging**

- Aging is caused by an awful lot of different things
- Some cells die, some cells become mutant, some tissue structures get cross-linked, or heavy metals accumulate in a key cell.
- All of those are really bad for you and as they accumulate and accumulate, and you start to feel older and then more diseased
- **The key point:** There are biological processes that can postpone all of that stuff together, that can postpone it for five decades in people, or almost a year in a mouse, or 25 years in a chimp

> “I don’t really care what causes aging. What I care about is ‘what is the process that can postpone all the different aspects of aging?’” —Rich Miller

**Why we need to rephrase the question**:

- “If you don’t ask the right question, you are guaranteed to flail.” says Peter
- “If you ask the right question, you may still flail, but it’s the difference between starting on your own 20-yard line and the other guy’s 20-yard line.”

## The Interventions Testing Program—A scientific framework for testing whether drugs extend lifespan in mice [29:00]

[**Interventions Testing Program**](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp) (ITP)

- Peter calls the ITP an amazing scientific framework that is the gold standard by which we test drug interventions in a robust, rigorous manner
- The goal of the ITP, per Rich, is to develop a fundamentally sound way of testing one question: ***Does this drug extend mouse lifespan?***
- And designing the program in ways so that the results will be reliable, reproducible, and believable
- For example, they use large sums of mice because that gives them a lot of [statistical power](https://peterattiamd.com/studying-studies-part-v-power-and-significance/) — “*We want to be sure that we will have enough mice present that if a particular drug extends lifespan by 8% or 10%, we’ll pick it up 80% or 90% of the time.*”
- For the drugs in the ITP to be successful, they’ve got to be at least three times better than a complete conquest of cancer
  - It’s been [estimated](https://pubmed.ncbi.nlm.nih.gov/2237414/) that if we abolish cancer in people, human lifespan goes up by only 3%
  - If you abolish atherosclerosis and cancer it’s about a 7% bump
  - If you got rid of cancer, heart disease, stroke, and diabetes, it’s about an 18% bump

**Four principles of the ITP**

**1 – Power**

- From a statistical standpoint, the studies in the ITP ensure a power to detect an 8-10% life extension 80-90% of the time — this basically means they use an awful lot of mice
- Each of the three sites will have 50 males and 50 females on each drug
- Also, they will have 100 male controls and 100 female controls — they double the number of controls because it gives us a lot better statistical power at relatively little cost

**2 – multiple sites doing parallel studies**

- They run the same designed study in parallel at three sites:
  - Miller Lab is doing this at Michigan
  - The Strong Lab is doing this in UT San Antonio
  - Harrison is doing this at Jackson labs
- Doing it at all three sites not only gives us power, but it also tells us if we’re getting an effect that is reproducible at three sites.
- For instance, if we get a drug that does terrific at one of the sites, but not at all at the other two, something may have gone wrong — That’s a *methodologic* issue.
- But if you get a drug that works pretty darn well at all three sites, that is sort of **instantaneous reproducibility** and a major reason for doing it at three sites

**3 – They use genetically** ***heterogeneous*** **mice**

*Why use the genetically heterogeneous (and not homogeneous) mice?*

- About 90% of the work in aging with mice (and actually all of medical research with mice) uses a single inbred genotype—[black 6 mice](https://en.wikipedia.org/wiki/C57BL/6)—where there’s no variation from mouse to mouse in their genetics as well as being inbred which means they have bizarre peculiarities like blindness and deafness, etc.

The impetus for developing a genetically heterogeneous stock was to..

- i) Not trick ourselves into picking a drug that only worked on black 6 mice
- ii) And conversely, to not miss a really good drug that just happened not to work on black 6 mice

About the heterogeneous mice:

- The [HET3 mice](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp/itp-collaborative-interactions-program-faqs), obtained from Jackson Laboratories, is two different kinds of mice which represent four different inbred grandparents
- When they are crossed them together, each one of those children is genetically unique, but each one will share half of its genes with all the others

Peter asks: *What fraction of research is utilizing genetically heterogeneous mice in the fashion you describe?*

- Much less than 10%.
- And the reason is that when people want to work in aging, they called the NIA for mice and all they have available is homogeneous mice

**4 – Open invitation to suggest a molecule to be studied**

- Anybody can make a suggestion for a molecule that may have some longevity properties

The first cohort of the ITP studied for molecules

- Aspirin
- Nordihydroguiaretic acid (NDGA) — this “worked” at all 3 sites (although, only in males)
- Nitroflurbiprofen (NFP)
- 4-OH-α-phenyl-N-tert-butyl nitrone (4-OH-PBN)

**ITP Paper with Cohort 1 results**: [Nordihydroguaiaretic acid and aspirin increase lifespan of genetically heterogeneous male mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2695675/) (Strong et al., 2008)

\*\*\*

**Below is a summary of all results to date from the ITP studies**:

(*click images to zoom in)*

[![](https://peterattiamd.com/wp-content/uploads/2021/02/ITP1-1024x370.png)](https://peterattiamd.com/wp-content/uploads/2021/02/ITP1.png)

**Figure 1.**

[![](https://peterattiamd.com/wp-content/uploads/2021/02/ITP2-1024x376.png)](https://peterattiamd.com/wp-content/uploads/2021/02/ITP2.png)

**Figure 2.**

![](https://peterattiamd.com/wp-content/uploads/2021/02/ITP3-1024x386.png)

**Figure 3.**

## Testing aspirin in the first ITP cohort [38:45]

- Aspirin initially [showed that it worked in males](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2695675/), but ultimately is was decided that it was not worth pursuing further for the ITP
- The initial dose of aspirin was very low based on the recommendation of the “sponsor” who recommended testing aspirin and gave strong rationale for why this dose — it was 1/100th of the dose a person would take, even if adjusted for mouse body weight
- The initial study showed an 8-10% increase in males only
- But several years later the thought was that perhaps the dose was too low so they tried a higher dose approximates the 83 milligrams a day that a lot of people take to prevent heart attacks
- The results showed no longevity extension

*Why not try again at various doses?*

- By that point, “we had enough things that really worked great, that we weren’t about to devote additional time and energy to trying intermediate doses”

**The ITP budget**

- The total program budget each year, in direct costs, is about a million dollars
- That means that they can test about 6 new molecules per year at $500,000 each
- Now, they have enough money—because the NIA has been extremely generous—to test 5 or 6 drugs each year for the first time, and then also go back and recheck one or two of these a year
- So, in the aspirin case, if they were to decide to try aspirin at a few more doses, they would be eliminating from our program some other drugs that have never been tested, but look really promising

## Rapamycin: results from ITP studies, dosing considerations, and what it tells us about early- vs. late-life interventions [44:45]

**In 2005, rapamycin was one of the candidate drugs in** [**cohort 2**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/)

- [Dave Sharp](https://www.uthscsa.edu/academics/biomedical-sciences/faculty/profile/0V71EC0KB/Sharp%2C-Zelton-D), an expert on TOR (the target of rapamycin) the one who suggested rapamycin
- At the time, there was [data in worms](https://www.nature.com/articles/426620a) and [in flies](https://pubmed.ncbi.nlm.nih.gov/15186745/) showing that a mutation that inhibited the function of the enzyme led to longevity increases in these two invertebrate species
- Before giving it to mice, they had to reformulate the rapamycin by coating it in kind of a shell that would get it through the stomach into the small intestine where it would be absorbed (in the usual form, 90-95% of it was eaten up in the stomach)
- This year of reformulation is the reason why, in the first round of testing, the mice were about 20 months of age (instead of 4 months which they planned)
- **The result from the** [**ITP stud**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/)**y**: A very strong signal in both males and females (and still the only drug the ITP has tested that gives a very strong signal in **females**)

**Paper published in Nature**: [Rapamycin fed late in life extends lifespan in genetically heterogeneous mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/)

*Why the age of mice is important*:

- A mouse that is 20 months old is roughly the equivalent to a 60 year old human
- This is very interesting because the gold standard intervention for treating mice, caloric restriction, typically only works when initiated **earlier in life**
- [Richard Weindruch](https://www.worldsciencefestival.com/participants/richard_weindruch/#:~:text=Richard%20Weindruch%20has%20devoted%20decades,co%2Dfounder%20of%20LifeGen%20Technologies.) found that caloric restriction works great when started at 4 months of age, still works at 12 months but not as well, but fails to extend life if you start as late as 19 or 20 months

*So now we have evidence that the processes of aging at age 20 months in a mouse are* ***reversible dependent upon inhibition of TOR signals***:

> “Giving rapamycin to a 20 month old mouse extends longevity dramatically, just as dramatically as if you had started the rapamycin at a much younger age. That’s a fundamental reformulation of how we thought aging worked.” —Rich Miller

\*\*\*

**Difference bt median vs maximum survival [50:00]**

- Median survival is the age at which half of the subjects have died and half of them haven’t died yet
- Maximum survival is a “folk notion”
- Basically, how long has the oldest mouse or a person who’s ever lived
- And that’s a value with very limited statistical appeal because the oldest person in a group of 100 people is not going to live as long as the oldest person in a group of 1,000,000 people or 100 million, and so on

A better statistic/best substitute for the oldest subject that lived is: **what is the age at which 90% of the subjects have lived?**

- This 90% threshold, it what’s crudely referred to that as “maximum lifespan”
- It’s an important concept in terms of understanding how to interpret survival statistics and survival curves

*Let’s say we have a group of animals that are dying in the 30s, 40s, and 50s (in human equivalent years)…*

- Then an intervention extends their **median lifespan** up to 60
- That becomes a great public health benefit (think immunizations that we all get, why people don’t smoke, etc.)
- But those types of median life changing interventions haven’t had any real effect on how much longer you’re going to live when you’re 70
- So drugs that only extend the median—and don’t affect the age at death that the longest lived 5% or 10%—might be interesting in some ways, but they are considered less plausible as candidates for anti-aging drugs

*Interventions that affect “maximum lifespan”*

- But if you had a drug, or a diet, or some intervention that authentically slowed the aging process, then it would extend expectancy of additional healthy years of life, even for those who are already quite old
- And THAT will modify the age of death at the 90th percentile.
- In other words, if you have a drug that’s authentically slowing aging, one of the things you most want to see is that the **very oldest animals in this drug treated group are living longer than the very oldest animals in the untreated control group**

\*\*\*

**Looking at the rapamycin data from the** [**2009 ITP paper**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/)**:**

*The median extension*—the age at which half the animals have died—

- Increased by 13% in males and 20% in females
- Interestingly, when you give the same dose of rapamycin in chow, the blood levels in the females are three times higher than the males, but *we don’t know why*

*In total lifespan (aka P90 lifespan)—*

- The P90 lifespan extension was ~9% in *males* and ~14% in *females*
- Note: This is NOT incremental lifespan extension, this is TOTAL lifespan
- These numbers are “huge” says Peter

![](https://peterattiamd.com/wp-content/uploads/2021/02/rapa-females-SA-1024x686.png)

**Figure 4. Survival analysis of female mice.** [[source](https://phenome.jax.org/itp/surv/Rapa/C2005)]

![](https://peterattiamd.com/wp-content/uploads/2021/02/rapa-males-SA-1024x689.png)

**Figure 5. Survival analysis of male mice.** [[source](https://phenome.jax.org/itp/surv/Rapa/C2005)]

**Explaining the total lifespan increase**

- The 9% or 14% more life basically translates to 25% more life once you’ve reached mid-life in terms of the number of additional years or months of life after you give the drug
- However, Rich says that statistic is not ”terribly informative”
- Thought experiment: Someone on a ventilator that is on death’s doorstep. Without the ventilator, they’re going to die today. And you leave them on the ventilator for one more day and then you give up and they die. So you’ve doubled their lifespan.  — “*not a very useful statistic to calculate*”
- But in terms of the biology and pathobiology, the change in the **overall median** is important.

*⇒ One exception to that*:

- If you start a drug really, really late, at an age when 35 %or 40% of the animals have already died, you’re asking a lot of that drug to extend the *median* lifespan
- If you get any extension of the median lifespan, it sort of had to start working immediately
- That’s the situation where the statistics on how many of them make it to the *90th percentile (i.e. “maximum lifespan”)*  become more informative than a percentage change in median

**Drugs tested late in life by the ITP**

*The ITP has tested 3 drugs “late in life” and found them to be successful in extending lifespan*

- Rapamycin works just as well late in life as starting it early;
- [Acarbose](https://en.wikipedia.org/wiki/Acarbose) works about *half as well* as an early start; and
- [17α-Estradiol](https://en.wikipedia.org/wiki/17%CE%B1-Estradiol) seems to work just as well in late middle age;
  - See this [ITP paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3954939/) on acarbose and 17α-Estradiol

Acarbose

- The [initial paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3954939/) was giving acarbose starting at four or five months of age
- Then they [repeated the study](https://pubmed.ncbi.nlm.nih.gov/27312235/) it but starting at 16 months of age
- It worked **half as well** as acarbose started in youth
- There was statistically significant change in the **maximum life span** in both sexes
- And a statistically significant change in the males with **median lifespan**

17α-Estradiol

- 17α-Estradiol only works in **males**
- The newest findings from the ITP—just now at the last stages of revision—shows that **if you start it at 16 months of age in males, it’s just as good as if you start it at an earlier age**
- Additionally, Mike Garratt, Sharlene Day, and John Herrera have already [published a paper](https://pubmed.ncbi.nlm.nih.gov/30740872/) using these same mice treated with 17α-Estradiol, where they started at 16 months
  - It resulted in their muscles getting stronger, improved glucose tolerance, and positive changes in muscular structure

**Back to the rapamycin ITP studies [58:45]**

*Dosing*

- The dosing in the ITP studies was done daily — the rapamycin was in the chow and the mice could eat all they wanted daily
- This daily dosing regimen that led to the extension of life span of the mice is an interesting detail to Peter because…
  - what we’ve learned about rapamycin since that time, is it inhibits two complexes of TOR, complex 1 and complex 2
  - today we believe most of the longevity benefits of rapamycin come from the inhibition of complex 1, not complex 2
  - furthermore, we believe that some of the negative consequences of constitutive of use of rapamycin come from its inhibition of complex 2

⇒ See [episode of The Drive with David Sabatini](https://peterattiamd.com/davidsabatini/)

*Data on the intermittent dosing strategy*

- Some of the more recent human data using rapalogs, such as everolimus, seem to favor an intermittent strategy
  - See the following episodes of The Drive:
    - [#114 – Eileen White](https://peterattiamd.com/eileenwhite/)
    - [#118 – Lloyd Klickstein](https://peterattiamd.com/lloydklickstein/)
    - [#123 – Joan Mannick & Nir Barzilai](https://peterattiamd.com/joanmannick-nirbarzilai/)
- For example, dosing rapamycin weekly—with a big enough dose—is enough to inhibit complex 1 but not enough to inhibit complex 2
- With that said, Peter’s always found the ITP studies in HET3 mice to be interesting that the study worked given the daily dosing of rapamycin

*What are Rich’s thoughts on that?*

- First, rapamycin does not directly inhibit mTOR complex 2
  - What it does is it leads to feedback circuits which destabilize mTOR complex 2 and eventually cause it to be degraded
  - So it may well differ from cell type to cell type (something that pharmacologists need to work out carefully)
- Secondly, [work by Gonzalo Garcia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4298324/) has very carefully looked at TOR complex 1 and TOR complex 2 activity for the last three or four years in *mutant mic*e that have one of two mutations (Snell dwarf mutation and the growth hormone receptor knockout mutation) extend longevity by 30%
  - Gonzalo found something very interesting ⇒ Both of those mutations move TOR complex 1 down (what we think of as good), but the mutations also **move to complex 2** ***up***
  - This raises the possibility that it is actually the **elevation of TOR complex 2** in these mutant mice that’s good for them
  - And to add to that, Gonzalo has also found several examples of mice where there’s a mutation that blocks the mTOR complex 2 elevation and they do not live a long time
- Recently, in a not-yet-published paper by Gonzalo, he has taken these drug treated mice—rapamycin or acarbose or 17-α Estradiol—and evaluated what’s happening there with mTOR complex 1 and mTOR complex 2
  - There are changes with rapamycin, both males and females;
  - There are changes with acarbose, both males and females; and
  - There are changes with 17-α Estradiol, but it’s the males only

**Rich summarizes this complex situation**:

- First, knocking down TOR complex 1 might be a good thing, and knocking down TOR complex 2 might be a bad thing — “*That’s a good initial, sound foundation for further work*”
- But the interactions between them—the ways in which different cell types may have different responses—is going to be much more complicated in that

⇒ For example, mTOR complex 2 has four different substrates

- What Gonzalo found is that the good stuff turns on three of these targets for mTOR complex 2 and turns the other one off
- If he’s right, the important change is not so much in the amount of TOR complex 2, but in its target’s specificity — i.e., which particular substrates it modifies and which ones it stops modifying

> “That’s a subtlety that may be the whole story as to why changes in mTOR complex 2 should be a part of any sophisticated study of this drug and other drugs.” —Rich Miller

**The ITP repeated the rapamycin study one year later in cohort 3:** [Rapamycin, But Not Resveratrol or Simvastatin, Extends Life Span of Genetically Heterogeneous Mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3021372/)

- The average age of treatment was now **9 months** instead of 20
- This is interesting in that,
  - A) you’re going to repeat a very important finding, and
  - B) you’re going to see if the age effect was significant
- The late start group had a lower *median extension*
- But the maximum extension in males went from 9% to 11%, and in females, it went from 14% to 16%
- So again, females had an advantage with rapamycin, but both of these numbers are really quite impressive
- These are pretty significant increases in lifespan and you’re now functionally starting this in people in their early thirties, basically

![](https://peterattiamd.com/wp-content/uploads/2021/02/rapa-2-females-SA-1024x690.png)

**Figure 6. Survival analysis in female mice in cohort 3.** [[source](https://phenome.jax.org/itp/surv/Rapa/C2006)]

![](https://peterattiamd.com/wp-content/uploads/2021/02/rapa-2-males-SA-1024x693.png)

**Figure 7. Survival analysis in male mice in cohort 3.** [[source](https://phenome.jax.org/itp/surv/Rapa/C2006)]

*Two points worth mentioning*:

- First, the slight increase in median lifespan for the early start (9 months) compared to the late start (20 months) were statistically indistinguishable (i.e., no statistical difference between the early start mice and the late start mice)
- Secondly, the females had a bigger response but we don’t know why
  - Randy Strong and Marty Javors and their colleagues at the University of Texas did a really [useful study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4032600/) where they gave rapamycin for a short period of time to male and female mice, and then took blood samples and they found the **rapamycin blood content in the female mice was two or three times higher than it was in the male mice** (and it stayed up longer)
  - Why this is the case is still unknown — But when you’re comparing two curves at the same dose in food and the females do a bit longer than the males, get a bigger benefit than the males, it’s hard to know how that comparison would come out if you’re actually adjusted them to the same blood level.
  - H*as Rich ever seen that with any other drug where you have the same quantity going in yet you see a 3X difference in plasma level*?
    - No, says Rich, although they don’t often do this type of study with drugs (although he would like to)
    - To do that type of study can get very involved and expensive but it can be done, it’s just not done on a routine basis

⇒ Check out another ITP paper on rapamycin: [Rapamycin slows aging in mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3434687/)

## Acarbose as a potential longevity agent by virtue of its ability to block peak glucose levels [1:07:15]

**What is acarbose?**

- Acarbose is an off-the-shelf drug typically used in people with diabetes
- It basically blocks the absorption of glucose in the gut
- It’s more or less well tolerated unless you take too much of it—in which case, you’re going to get some GI distress
- Peter sometimes uses it as his “cheat meal drug” — If he is going to eat pizza, he might take 100 milligrams of acarbose to manage or prevent his glucose from spiking
- “They should give it away with every pizza, I agree. That’s a good marketing strategy.” says Rich half-jokingly

**What was the thinking going into the study?**

- The acarbose application came in from [David Alison](https://en.wikipedia.org/wiki/David_B._Allison) and [Daniel Smith](https://scholars.uab.edu/display/dsmithjr)
- Their rationale was that “Caloric restriction is good for you” and acarbose is sort of like caloric restriction (CR) in that it blocks the digestion of starches to sugars
- Peter points out that there are really two different hypotheses that you could be testing:
  - One is that you will functionally consume or absorb fewer calories, and therefore it’s like CR
  - Another could be that the animal will continue to eat the same calories, but they will have lower glucose (which is a good thing for long-term health)

**Three ITP acarbose cohorts — C2009, C2012, C2013**:

1. [Initial paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3954939/) from Cohort 5 in 2009 (published 2014) — Extended mouse lifespan preferentially in males
2. [Repeated the study](https://pubmed.ncbi.nlm.nih.gov/27312235/) with Cohort 8 in 2012 with same dose but starting at 16 months of age — worked about **half as well** as acarbose started in youth
3. A [2019 paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6413665/#acel12898-bib-0031) showed results from using various doses and starting at 8 months — both sexes has significant improvement in lifespan but more so in the males; From the abstract: “*The acarbose results confirm and extend our original report, prompt further attention to the effects of transient periods of high blood glucose on aging and the diseases of aging, including cancer, and should motivate studies of acarbose and other glucose‐control drugs in humans*.”

![](https://peterattiamd.com/wp-content/uploads/2021/02/acarbose1-females-SA-1024x685.png)

**Figure 8. Survival analysis of female mice in the initial ITP study published in 2009.** [[source](https://phenome.jax.org/itp/surv/ACA/C2009)]

![](https://peterattiamd.com/wp-content/uploads/2021/02/acarbose1-males-SA-1024x696.png)

**Figure 9. Survival analysis of male mice in the initial ITP study published in 2009.** [[source](https://phenome.jax.org/itp/surv/ACA/C2009)]

**What is Rich’s hypothesis on why it extends lifespan?**

- Rich’s current interpretation of the life extension benefits is that it is blocking the very highest levels of glucose
- In humans, we often look at hemoglobin A1C, which gives you a measure of avg. blood glucose over the last few weeks
- And if a person with diabetes takes acarbose, that hemoglobin A1C goes down — signifying that it’s working in a person
- But in mice, it turns out that HbA1c does NOT go down
- So it’s probably not an overall change in the amount of glucose that gets in, **but a change in the kinetics**
- *Take the following example*: If I eat five slices of pizza, my blood glucose is going to shoot way up and then come down. But if I’ve taken a lot of acarbose first, blood glucose will go up, it’ll just go up slow. It won’t reach that big peak, it’ll stay up longer overall, but it won’t hit the big peak.

*In summary*:

- Rich’s guess is that acarbose was working by **blocking the peak glucose**
  - Another drug, [canagliflozin](https://en.wikipedia.org/wiki/Canagliflozin#:~:text=Canagliflozin%2C%20sold%20under%20the%20brand,together%20with%20exercise%20and%20diet.)—which is also used for diabetes in people—blocks peak glucose in mice (and in people) and, as shown in the [ITP study](https://insight.jci.org/articles/view/140019), extends lifespan preferentially in male mice
- In short, **acarbose and canagliflozin are working by eliminating the huge peak of glucose you get after you eat a meal with a lot of starch in it**

**Any GI distress in the mice?**

- They didn’t stop eating or show obvious signs of distress
- Their GI tract and our GI tract are very different, so a direct one-to-one comparisons for what our GI tract can handle and theirs may be kind of tricky.

**Changes in weight?**

- Acarbose led to weight loss (or a lack of weight gain) in the original ITP paper
- But that is seen in some populations, but not all
- For example, in Rich’s lab, he made a batch of acarbose-treated mice for another purpose and they didn’t see a dramatic change in weight — “*We really don’t know why. So it’s a little bit frustrating*.”

*Aside question: Did rapamycin-treated mice have a difference in weight vs. controls?*

- It’s complicated, and depends on the age at which you start the drug
- If you start in youth, then when the mice are still gaining weight, the mice on rapamycin do not gain weight as much as the control mice (not surprising given rapamycin stops or slows cell growth and cell division)
- If you start in late age, like 20 months of age, you have a whole series of factors going on:
- Mice, when they get old, they often get sick, and when they get sick, they often lose weight
- So if rapamycin is extending their lifespan, then they’re getting sick later, so they’re not losing weight because they’re healthier

**Acarbose as a candidate for human trials**

- Since acarbose is FDA-approved and has a long safety history—hundreds of thousands of people take it, particularly in Asia and in some parts of Europe—it’s an obvious candidate for human clinical trial
- So if one was thinking about what drug that works pretty well in mice would be safe for human clinical trial, acarbose has to be on that list
- Rich is urging [Matt Kaeberlein](https://kaeberleinlab.org/people/matt-kaeberlein)—who is [studying rapamycin in dogs](https://dogagingproject.org/)—to study acarbose in dogs as well

## Resveratrol: why it received so much attention as a longevity agent, and the takeaways from the negative results of the ITP study [1:15:45]

**Resveratrol as a longevity agent**

- The resveratrol story “caught the world by storm”
- [David Sinclair](https://twitter.com/davidasinclair?lang=en) published a [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4990206/) suggesting longevity benefits of resveratrol in mice — showing that when resveratrol was given to metabolically-ill mice, it produced a longevity benefit in part by activating [sirtuins](https://en.wikipedia.org/wiki/Sirtuin)

*The problem with these studies*:

- The mice in question were being given a diet consisting of 60% coconut oil — “*they were being poisoned*”
- The mice were dying because their livers got so big, so filled with fat, that it compressed the chest cavity and crushed the lungs
- “S*o they’re not really studying aging, they’re studying a bizarre pathological process where the liver gets so fat that it crushes the lungs*.”
- In addition, there was a statistically significant increase in *median lifespan*, but only in the animals that were on this highly toxic diet
- When you look at other indices of maximum lifespan, resveratrol had no benefit
- And when you look at the lifespan affects in the mice that were not on this toxic diet, there weren’t any

***In short***, the original [Nature paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4990206/) was widely misinterpreted as a demonstration of a drug that slowed aging, but in reality did not extend maximum lifespan except in mice that were dying of this extremely unusual lipid specific poisoning

**The ITP’s test of resveratrol**

*How did this influence the ITP’s decision to test resveratrol?*

- Rich says they were “ordered” to test it by [Richard Hodes](https://www.nia.nih.gov/about/staff/hodes-richard#:~:text=Biography-,Richard%20J.,head%20the%20NIA%20in%201993.), the Director of the National Institute on Aging
- In other words, resveratrol did not go through the usual screening process

*-Study design and dosing*

- Rich called David Sinclair and David recommended a much higher dose (5x-20x higher)
- The ITP went on to test resveratrol in very high doses and at two different ages—12 months ([cohort 3](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3021372/)) and then at 4 months ([cohort 4](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3598361/))

**–***Results*: It had **no effect on longevity** — no change in median or maximum lifespan (see Survival Analysis of [cohort 3](https://phenome.jax.org/itp/surv/Res/C2007) and [cohort 4](https://phenome.jax.org/itp/surv/Res/C2007))

- The ITP studies were the first of several studies to show that resveratrol given to mice on a normal diet **does not extend their lifespan**

**What was the response to these negative results?**

- Rich says he was very irritated at the response (or lack thereof)
- There are people who were making a living by selling stuff that was related to resveratrol, and since consumers rarely read papers, they’re sales were really impacted
- In fact, a company called [Sirtris](https://en.wikipedia.org/wiki/Sirtris_Pharmaceuticals)—who pushed the resveratrol story—sold to [GlaxoSmithKline](https://en.wikipedia.org/wiki/GlaxoSmithKline) for $600+ million for pushing sirtuin inhibitors

*Wine not a good source of resveratrol*:

- It was becoming clear that resveratrol was not a important component of wine (e.g., “to get the mouse dose of resveratrol, you’d have to drink 600 bottles of wine a day”)
- David Sinclair’s [review article](https://www.med.upenn.edu/baurlab/pdfs/Therapeutic_potential_of_resveratrol.pdf) suggested getting resveratrol from [rhubarb](https://en.wikipedia.org/wiki/Rhubarb)
- Satirical New Yorker article: [Mouse Au Vin](https://www.newyorker.com/magazine/2009/01/26/mouse-au-vin)

**Resveratrol and Sirtuins**

- There’s been a lot of controversy as to whether the sirtuins are important or not in the aging process
- “I don’t think there’s any evidence yet that resveratrol is good for you or that sirtuin activators slow the aging process.” says Rich
- See the book, [The Youth Pill](https://www.amazon.com/Youth-Pill-Scientists-Anti-Aging-Revolution/dp/1617230081) by David Stipp, for the Sirtris resveratrol story
- Rich actually gave a talk at a Sirtris conference where he talked about rapamycin
- After the talk he spoke to the director of Sitris and Rich asked him about resveratrol and the director has essentially said he was moving away from it and going to work for a company that works on TOR inhibitors — “*he knew that it was time to move on to inhibitors or compounds that had a greater likelihood of actually working*”

## The value in negative findings: ITP studies of green tea extract, methylene blue, curcumin, and more [1:24:15]

**Green tea extract**

*What was your expectation going into that ITP?*

- Every suggested molecule to test is first evaluated by a group of five scientists, and a small handful get approved for testing
- In general, the ITP strongly prefers single purified, synthetic compounds as opposed to complex mixtures
- That said, sometimes there are grounds for testing a complex mixture, one that may be that five or six or seven things in balanced amounts might together be good for you (even if no one of them used singly might be beneficial)

**ITP study (cohort 4)**: [Evaluation of Resveratrol, Green Tea Extract, Curcumin, Oxaloacetic Acid, and Medium-Chain Triglyceride Oil on Life Span of Genetically Heterogeneous Mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3598361/)

*But in the case of green tea…*

- Those who were recommending green tea extract say there’s a central compound that’s probably the main player in green tea extract
- It’s also conventional wisdom that green tea is “good for you” — e.g., it’s part of traditional Chinese medicine — and they like to test things that have acquired a popular reputation for being helpful
- The thinking is that If they test it and it works, *great!* … And if it doesn’t work, then they’ve *done a public service*
- The [ITP results](https://phenome.jax.org/itp/surv/GTE/C2007) **did not** produce a significant longevity effect
- The results of their testing didn’t necessary “prove” green tea isn’t good for you, however, Rich says he hopes that they may be able to “slightly take the wind out of the sails of that discussion” if they demonstrate that, when given it to animals, it didn’t do any good to them.

**Other molecules that didn’t “work”:**

*Methylene blue*

- Peter says he was surprised at the [negative result](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3954939/) for this one (see [Survival Analysis](https://phenome.jax.org/itp/surv/MB/C2009))
- But notes that “the failures are just as important as the successes”

*Curcumin*

- [No median or maximum life extension](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3598361/) in males or females
- (see [Survival Analysis](https://phenome.jax.org/itp/surv/Cur/C2007))

**The “poster children” of the ITP**

- Rapamycin
- Canagliflozin

## 17α-Estradiol: lifespan effects in male mice, and sex-specific effects of different interventions [1:27:00]

**17α-Estradiol**

*What was the genesis behind the plan to investigate 17α-Estradiol?*

- A pharmacologist named James Simpkins has studied estrogen receptors and suggested investigating 17α-Estradiol
- He had tried to make a compound that was like estrogen—17 beta-estradiol—generically crudely referred to as estrogen
- 17 beta-estradiol had much lower affinity for the classical receptors for the estrogens, ER, alpha and beta
- He synthesized 17α-Estradiol—very much the same compound except for one of the bonds tilts up instead of tilting down
- And mostly in tissue culture cells, he found that yes, it was tenfold less active compared to 17 beta-estradiol
- When he gave it to mice, he found it was [non-feminizing](https://pubmed.ncbi.nlm.nih.gov/27818250/):  So when you give it to male mice, it did not induce the secondary sexual characteristics that the stronger estrogens, like 17 beta- estradiol, estrogen would do
- His idea was that giving estrogen to male mice might make them live as long as female mice (female mice live 5-10% longer than males) AND this compound called 17α-Estradiol will be good for males because “no man wants to look feminine.”

**ITP studies – 17α-Estradiol**

- The first attempt—[cohort 5](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3954939/)—used a low dose (4.8 ppm) and it extended **median survival** in males, but not maximum
- In the ITP study—[cohort 7](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5013015/)—they then gave a dose 3x higher (14.4 parts per million) and it extended the measure of **maximum longevity**, as well as **median longevity** at *all three sites* for **male mice,** but not for females
  - In fact, the males not only lived longer than regular old males, they lived longer than regular females
  - They have some clues as to why it works only in males, but they don’t know for sure
  - The hope is that they can try to figure out a way to get around that obstacle and to get it to work in females as well
- The results from [**cohort 12**](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp/compounds-testing) have yet to be published

![](https://peterattiamd.com/wp-content/uploads/2021/02/estradiol-cohort-7-males-SA-1024x689.png)

**Figure 10. Survival analysis of male mice which had an increase the measure of maximum longevity, as well as median longevity.** [[source](https://phenome.jax.org/itp/surv/17aE2/C2011)]

*what’s the menopausal situation of mice? How long are the female mice exposed to estrogen, to 17 beta-estradiol?*

- I don’t know about when the estrous cycle ceases in mice. It depends a lot on the strain
- In general, production of new healthy pups tends to slow down when the females are eight, or nine, or 10, or 11 months of age and the cycles start to get irregular and then to stretch out and then to cease altogether

*Is there an actual molecule of 17 alpha-estradiol? Is there an IND for this?*

- The answer is not really well-known
- An obscure [paper](https://academic.oup.com/endo/article/146/9/3843/2500254) in 2005 said they had detected 17 alpha-estradiol in the brain — they said that they had isolated, in the brain, a receptor called ER-X that was relatively specific for 17 alpha-estradiol
- Following-up with a few American scientists—steroid chemists and who spend their whole life synthesizing various derivatives—Rich asked them, “What is 17 alpha-estradiol, is it anywhere? Does it do anything?” And they all said, “Good question. I don’t know.”
- So apparently it’s distinctly under investigated

***So even after the impressive ITP findings, it hasn’t been pursued as an investigational new drug?***

- “I don’t know” says Rich, “Certainly nothing has come to my attention about its being investigated.”
- There is an awful lot of attention to developing novel estrogenic compounds
- “I’ll bet a great chunk of it is kept quiet by pharmaceutical firms”

## Testing ursolic acid and hydrogen sulfide: rationale and preliminary results [1:33:15]

**Ursolic acid**

Here’s the [ITP paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6413665/) (cohort 9) showing results of ursolic acid

*The rationale for testing ursolic acid*:

- A [paper](https://pubmed.ncbi.nlm.nih.gov/17521389/) from Gretchen Darlington and some of her colleagues, said that the long live mice (Ames dwarf mice) had turned on a whole bunch of genes that related to bile acids — and the bile acids work through some molecules related to the [retinoic acid receptor](https://en.wikipedia.org/wiki/Retinoic_acid_receptor)
- So ursolic acid was proposed as a way of getting at the bile acid issue
- Peter remembers some human-based supplement for this that was all predicated around improving body composition — but Peter’s recollection is that it was not orally bioavailable rendering it unhelpful
- The [ITP study](https://phenome.jax.org/itp/surv/UA/C2013) did not show significant longevity benefits

**Hydrogen sulfide**

- Proposed by Jay Mitchell, the idea was that [hydrogen sulfide might be an important controlling element in the aging process](https://pubmed.ncbi.nlm.nih.gov/31735592/)
- He suggested that when a drug called **SGI002** was given to mice, it would break down to produce hydrogen sulfide
- In the ITP’s first attempt (cohort 12), the process was botched with the wrong control food
- So they are repeating the testing now but the data won’t be ready for another year+
  - Cohort 14 – midlife start (18 months)
  - Cohort 15 – early start (6 months)

## Canagliflozin (an SGLT2 inhibitor): exploring the impressive lifespan results in male mice [1:35:45]

**SGLT2 inhibitors**

- [Canagliflozin](https://en.wikipedia.org/wiki/Canagliflozin#:~:text=Canagliflozin%2C%20sold%20under%20the%20brand,together%20with%20exercise%20and%20diet.) is in the class of drugs known as SGLT2 inhibitors
- SGLT2 inhibitors has been around for a while and is used pretty readily in patients with type 2 diabetes as it blocks the re-uptake of glucose so that more glucose is excreted in the urine
- It affects the process in the kidney that deals with very high glucose levels without having much scope for causing toxicity

**Results of the ITP study**

[Canagliflozin extends life span in genetically heterogeneous male but not female mice](https://insight.jci.org/articles/view/140019)

- Increased median lifespan in the **male** mice by 14%, maximum extension of 9%
- But had **no effect on the females**

![](https://peterattiamd.com/wp-content/uploads/2021/02/cana-results-1024x497.png)

**Figure 11. Lifespan statistics for Cana and control mice.** [[source](https://insight.jci.org/articles/view/140019)]

*Any insight into differential plasma levels between the males and females?*

- The females actually had [slightly higher levels than the males](https://insight.jci.org/articles/view/140019/figure/2), meaning the absence of an effect in females is not explicable on the idea that they don’t get the drug into their blood

*What could explain the sex-specific difference in the effect?*

- “*Gosh, I wish I knew*” says Rich
- When you take this together with the acarbose results, you’re led to the inference that something about aging in the male mice depends a lot on staying away from really high glucose levels
- But whether that means that high glucose in the males triggers a circuit in the hypothalamus, which is bad for you or something, is just a hypothesis

***Cancer in mice***

- Cancer is the predominant cause of death in these mice (about 80% of deaths)
- The leading cause for both males and females is [hematopoietic cancers](https://en.wikipedia.org/wiki/Tumors_of_the_hematopoietic_and_lymphoid_tissues)
- For females,
  - the second leading cause is mammary cancer
  - the third leading cause is either liver cancer or a fiber sarcoma
- In the males,
  - the second is lung cancer
  - And third is also liver cancer or fiber sarcoma (like the females)

*-How much is hematopoietic in each?*

- About [30% of the deaths](https://insight.jci.org/articles/view/140019/table/2)
- Peter calls this facts to be counterintuitive based on human data: in humans, the mammary cancers would be quite glucose and insulin sensitive, whereas the lung would not be, so you would actually expect the opposite if that were true in mice (meaning you’d think the females to disproportionally have the benefit)

*-Do we have molecular data about PI3K activity or IGF activity in these animals, as it pertains to their cancer risk?*

- Really good question, says Rich
- Rich says one line of thinking is that the glucose aspect of this works on the cancers
- But it’s also possible that the glucose excursions are working on an anti-cancer defense, some aspect of immune defenses
- Or… it could be—and this is Rich’s hope—that the glucose specific excursions are modifying some fundamental, still undiscovered element of the aging process in the hypothalamus

![](https://peterattiamd.com/wp-content/uploads/2021/02/cana-graphical-abstract-1024x720.png)

**Figure 12. Graphical abstract of blood glucose response.** [[source](https://insight.jci.org/articles/view/140019)]

- Maybe it has to do with the susceptibility of the hypothalamus to inflammatory change differentially in males than in females
- And that this nebulous change has an impact on the cancer, or an impact on anti-cancer defenses or something
- In Rich’s view, these hypotheses are equally likely to be true, but at present, none of it gives us much of a hint as to **why these drugs have a much more striking effect in the male mice**

*-Did you see the same effect here that you did with acarbose in that the hemoglobin A1C was unaffected?*

- Rich’s recollection is that there was no difference in the effect on hemoglobin A1C
- This is surprising because it is affected in human diabetics

**Summarizing what we know about canagliflozin**:

- We don’t know whether the positive effect of canagliflozin is due to its impact on glucose, SGLT2, or SGLT1
- The [literature](https://cardiab.biomedcentral.com/articles/10.1186/s12933-020-01071-y) is showing, for example, that SLGT-2 inhibitors have an effect on tumors specifically, and other things like heart attacks, **independent** of whatever’s happening in terms of glycemic control
- The shortest, simplest explanation—that the benefits are due to canagliflozin’s effect on glucose—may not be right. — “*There are other ideas that deserve a lot of exploration*.”
- *Peter reiterates his excitement around canagliflozin*: “We are very excited about this class of drugs clinically in our practice; the cardioprotection, renal protection, obviously the glycaemic benefits are all pretty exciting.”

## The failure of metformin: reconciling negative results of the ITP with data in human studies [1:42:30]

**Metformin**

- Peter says the biggest surprise of the ITP is the [failure of metformin](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5013015/) to extend life in mice
  - NOTE: when given with rapamycin it did extend life
- Rich says that he is not surprised because there are all sorts of reasons in which metformin failure is unsurprising:
  - 1 – It might be really good for people and not good for mice
  - 2 – It’s also possible that they used the wrong dose
  - 3 – The dosing schedule may need adjusting, e.g., if we had given it for a few months and then taken it away for a month, and then given it for a few months, that might’ve worked
- In the [ITP study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5013015/), they gave it at one dose with one continuous dosing schedule, and it did not produce a significant effect — “but that’s not to say that it could not work in mice”

**Metformin studies in mice**

[One study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3736576/) by Rafael de Cabo showed metformin extended life in mice

- That study produced no effect in females, but showed a significant effect in the males
- However, the p-value was .046… “so it was really close”
- Furthermore, that study didn’t not use the logrank test to determine p-value
- Instead, they used another test that gives special weight to early deaths
- Rich’s hunch is that it didn’t work with the logrank — “*So they went statistics shopping*”
- In any case, whether or not his was just over or just under the border of statistical significance, it was a small effect at best

The [ITP study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5013015/): Cohort 7: C2011

- When given alone, metformin led to [no significant lifespan extension](https://phenome.jax.org/itp/surv/Met/C2011) in either males or in females

**Compelling metformin data in humans**

- In metformin, we have undeniable data showing the benefits when taken by diabetics compared to diabetics that don’t take it
- The principal stimulus for the interest in metformin came from this [paper](https://pubmed.ncbi.nlm.nih.gov/25041462/)
  - The point of the paper was not so much that metformin was good for diabetics (everybody knew it was)… it was that the mortality risk of diabetics on metformin was actually **better than non-diabetics** of the same age and sex
  - Important note: It was an observational study, not a controlled, randomized clinical trial
  - Rich says that doesn’t prove that metformin is good for non-diabetics, but it’s certainly a hint in that direction
  - In other words, the paper suggests if you’re a non-diabetic and you’re NOT taking metformin, your chances of death over a wide range of ages are actually worse than a diabetic person being protected by metformin
- Rich’s view is that metformin may well be pretty good for non-diabetic people as well so studying that in terms of a randomized clinical trial is totally justified

⇒ Rich and Peter are very interested in the results of the ongoing [TAME study](https://www.afar.org/tame-trial)

## Nicotinamide riboside: insights from the negative results of the ITP study [1:48:45]

NAD = [Nicotinamide adenine dinucleotide](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide)

Precursors to NAD:

- NR = [Nicotinamide riboside](https://en.wikipedia.org/wiki/Nicotinamide_riboside)
- [NMN =](/does-nmn-improve-metabolic-health-in-humans/) Nicotinamide mononucleotide

**Backstory**

- Peter compares today’s hype of NAD (and its derivatives NR and [NMN](/does-nmn-improve-metabolic-health-in-humans/)) to the hype around resveratrol in the early 2000s
- Rich says if you had to make a short list of molecules that are part of intermediary metabolism that may well be a really important elements in the control of aging rate, NAD and it’s a chemical derivatives would surely be on that list
- There is a great deal of pretty strong data suggesting that aspects of aging and age-associated diseases can be altered by making NAD more or less available;
  - See the following episodes of The Drive:
    - [#27 – David Sinclair, Ph.D.](https://peterattiamd.com/davidsinclair/)
    - [#70 – David Sinclair, Ph.D. (Part 2)](https://peterattiamd.com/davidsinclair2/)
    - [#46 – Chris Masterjohn, Ph.D.](https://peterattiamd.com/chrismasterjohn/)
- But it’s mainly gotten so much attention is because of clever marketing
- More than a few companies are making a lot of money selling NR as a nutritional supplement

**How NR got recommended to the ITP**

- NR is more orally bioavailable and more stable than some of the other ways that have been proposed by mouth
- One of the companies looking to make an NR supplement for humans recommended NR to be tested by the ITP

**The results of the ITP study** (data not yet published)

- The study used a dose suggested by the company
- The mice were 8 months old (equivalent to a human in his 20s)
- *The early results*: **NR did not extend lifespan** in the mice
- They did try to detect NAD in various tissues: A collaborator looked at the brains, muscles, and hearts but they were not able to demonstrate a consistent major change in NAD levels in these tissues
- All the usual caveats:
  - A higher dose or lower dose may have worked better
  - Perhaps they would have seen something different if the mice were fasted
  - Or they it’s possible that they should have gotten the blood out in a different way
- But in any case, Rich is confident that, at the dose tested, it did not produce a lifespan effect

*Did it produce any benefit at all?*

- We would have to go and check for other things
- But typically, in a study with a new drug, lifespan is the only thing measured
- Rich would love to be able to measure immune function, vision, hearing, cardiovascular function, etc. — but they generally reserve those health outcomes only for those drugs that give a lifespan benefit

**Why testing for lifespan changes can be tricky when picking a dose**

- If there are doses that are often given of drug X…
- But doses of drug X are typically given to people for a month or two
- And in that short time frame, it doesn’t produce side effects
- You still worry that might not work for mice because if you’re going to give it to them their whole lifespan and side effects may accrue
- For that reason, they typically keep the dose pretty low because if they’re going to be on it from four months of age until death, keeping the dose nice and low is probably an important precaution against unanticipated side effects that might not be seen in an acute treatment

*How often do you guys see unanticipated consequences?*

- Surprisingly, the ITP has not yet found any drugs to cause a significant shortening of the lifespan
- Now, there could be some side effects that we don’t look for (Maybe the mice have problems with hearing or sight or memory or muscle function but they wouldn’t see this unless they were specifically looking for them)

## The three most important takeaways from the ITP studies [1:55:30]

**Rich’s three most important takeaways from the ITP studies to date**:

1 – You actually can put something in the food that extends healthy lifespan with enormous effect

- This is a fundamental imagining of where medical research ought to go
- The ITP program shows that what we should be thinking about is finding drugs that slow aging — “*But most of my friends, scientific and non-scientific, they haven’t decided that that’s the case. So, I would take that as the first most important take home message*.”

2 – Most of the drugs that extend lifespan will work even when you start them in middle age

- That’s really important in terms of both the understanding of aging and also thinking about transition to human usage

3 – Most drugs that extend lifespan only do it for males OR females

- “I *would’ve guessed any drug that works is going to work in both sexes, and that’s mostly wrong*.”
- Only two drugs, rapamycin and the amino acid [glycine](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6516426/), have equally strong effects in males and females
  - (glycine has only a [tiny effect](https://phenome.jax.org/itp/surv/Gly/C2014) so it’s not talked about much)

> “But the sex specificity and the ability to start in late life were both surprises and open up new ideas about how can you discover why it’s working in old age and how can you discover why it’s working in one sex, but not both.” —Rich Miller

**BONUS takeaway**: Specific molecular clues; Such as:

1. mTOR is important
2. Glucose (less is better than more)
3. Sex-specific steroid hormones probably do something relevant

- In fact, any post-doc or grad student who comes into Rich’s lab will work on one of the above
- “That’s the cutting edge of turning this into a molecular and cellular understanding of what slows the aging process and where we ought to pay attention when we want to find new drugs that will work in just the same way.”

**Summary of the three more general points**: i) That it works at all, ii) that it can work late in life, and iii) that it’s often sex-specific

> “They fundamentally rearrange our ideas about aging, about late life disease and about what one ought to do if one was, say, in charge of America or the universe’s medical research apparatus.” —Rich Miller

## Philosophies on studying the aging process: best model organisms, when to start interventions, which questions to ask, and more [1:59:30]

**Peter asks Rich**: *What would you choose as the best model organism that would give you the trade-off of duration and closeness to humans?*

- Peter points to the very famous caloric restriction experiments in rhesus monkeys in the ’80s, ’90s and 2000s as an example of a species closer to humans

**Rich’s response**:

- Rich says he favors studying the mouse
- But he says it’s a “bad” question: “*The tool that I select depends upon the problem I have to solve*”
- Each of the major experimental animals that is currently receiving a lot of attention is doing something good, says Rich
- They are molecular and genetic questions that are best addressed by flies and worms, for example
- Rich says that [rhesus monkeys](https://en.wikipedia.org/wiki/Rhesus_macaque) are losing favor in experiments; A better option is [marmosets](https://en.wikipedia.org/wiki/Marmoset) because marmosets are primates, they are organized much like humans, but they have an average lifespan of 8-10 years (compared to ~30 years for rhesus)
- The 8-10 year lifespan is a little long for experiments, but like dogs, it’s short enough that you can complete an experiment within a decade
- Obviously, work has to be done in humans, too

**Why Rich favors mice**

- If Rick had to pick one animal to study, he would pick the mouse
- They’re extremely like people: they have the hypothalamus, pancreas, beta cells — There are very few organs or cells or circuits or hormones that mice have but people don’t have, or vice versa

**Peter’s rebuttal**

*Nutritional studies*

- There are some profound differences, such as being herbivores versus omnivores
- This causes particular issues with studying nutritional interventions
- This might be relevant in the context of acarbose, which is a nutritional intervention in some ways, making it hard to extrapolate results to humans

*Cause of death*

- 80% of mice die of cancers, a third of which are hematologic
- All humans [die *with* atherosclerosis](https://peterattiamd.com/heart-disease-begin-tell-us-prevention/), and about a third die *from* it

**Peter personal philosophy on extending lifespan**:

- We must address atherosclerosis — *“Any effort to thwart human aging must be able to punch atherosclerosis squarely between the eyes.”*

*Rich’s response to Peter’s philosophy*:

- When giving mice rapamycin, they euthanized them at 22 months (most of them were still alive and fairly healthy)
- After death, they looked at dozens of different organs as well as their tendons
  - Their tendons were youthful.
  - Their kidneys were youthful.
  - They did not have changes in the heart.
  - They did not have changes in the endometrium.
  - They did not have changes in the liver.
  - And they did not have changes in the adrenal that were characteristic of 22 month old control mice
- Some changes produce cancer in mice and in people (and we don’t know which ones they are)
- Some changes produce atherosclerosis or strokes or diabetes in people, and in a small fraction of mice (and we don’t know which ones they are)

**From Rich’s perspective…**

“*The details of what you’re going to die of, whether it’s mostly a stroke, mostly atherosclerotic in nature, or mostly neoplastic, they’re certainly important if you’ve got a patient, you want to help that patient, or if you’re looking for disease-specific drugs. But my interest is not related to that, it’s to ‘****what can we do to slow the aging process?****’*”

- Rich says it’s a very plausible idea that, when you slow the aging, whatever diseases afflict the members of that species will be slowed down as well.
- For example:
  - Alzheimer’s disease does not ordinarily occur in mice but it’s a major issue for people
  - Yet, if you make a mouse that has some aspects of Alzheimer’s disease and you give them these drugs, the disease is postponed
  - So that’s consistent with the notion that whatever diseases aging leads to in either species, anti- aging medications will help retard

> “Cause of death is an important wrinkle, but only an elaboration of the aging process in a species specifically.” —Rich Miller

**Should studies start interventions in younger or older subjects?**

- Peter says given the ability of “anit-aging” drugs to slow so many aspect of aging (tendons, nephrons, cardiac myocytes, neurons, etc.) it speaks to this importance of, whenever possible, starting younger
- That said, rapamycin “flies in the face of that”

*Rich adds some context to Peter’s point*:

- One has to answer the question of when to start treatment directly, point, by point, by point:
- The fact that giving 17-α Estradiol, acarbose, or rapamycin to middle-aged mice still gives a nice postponement of the different aging processes, is evidence against the notion that all interventions (or most) have to start early
- In addition, in Mike Garratt’s [paper](https://pubmed.ncbi.nlm.nih.gov/30740872/) with Jon Herrera and Sharlene Day, they started treating some old mice with 17-α Estradiol and it postponed (or maybe reversed) muscle changes, muscle grip strength changes, the ability to stand on a rotating rod, and changes in glucose tolerance with age

> It may be that, despite my personal intuition, the evidence starts to suggest that some aspects of aging can be reversed or prevented even if you’re starting in late middle age. That would be cool if it was true. I would have bet against it, but I may be wrong.” —Rich Miller

## Seven reasons why pigs can’t fly [2:08:00]

[**“Flying Pigs” letter to MIT Technology Review**](https://www.richmillerlab.com/flying-pigs)

- 15 years ago, Rich wrote something “really hilarious” at the MIT Technology review
- “I just felt in the mood to be mean, so I wrote the piece.” says Rich
- “After hearing Aubrey de Grey  speak over and over and over and over again for many years. I fantasized that he had made a television appearance and I wanted to enlist his help.”

\*\*\*

**Excerpt from the article**:

Dear Aubrey,

I saw you on TV the other day, and was hoping that now that the aging problem has been solved, you might have time to help me in my publicity campaign to solve a similar engineering challenge, one that has been too long ignored by the ultra-conservative, fraidy-cat mainstream scientific community, the problem of producing flying pigs.

A theoretical analysis of the problem, using the fastest available modern computers, shows that there are a mere seven reasons why pigs cannot, at present, fly.

1. They do not have wings.
2. They are too heavy to get off the ground.
3. The so-called “law” of gravity.
4. They cannot climb trees.
5. Hair, instead of feathers.
6. They do not wish to fly.
7. They do not tweet.

\*\*\*

Peter reaction,

“This is *really a great example of who you are, which is you’re grounded in reality and you don’t buy into this idea that that immortality is in our future. And you view it as an enormous win if there’s a drug out there that can extend human life by 25%.*

*I’ve seen nothing to suggest that immortality is in our future. And frankly, I’m not sure it should be, even if we were ever given the choice. But boy, 10 to 15% improvement in our lifespan and healthspan would be a remarkable achievement. And if there were molecules that can do that, I’m glad you’re working on them.*”

§

## Selected Links / Related Material

**Study from Israel that received a lot of hype that looked at the potential anti-aging benefits of hyperbaric oxygen**: [Hyperbaric oxygen therapy increases telomere length and decreases immunosenescence in isolated blood cells: a prospective trial](https://pubmed.ncbi.nlm.nih.gov/33206062/) (Hachmo et al., 2020) [10:45]

**Nobel Prize for the elucidation of telomeres**: [The Nobel Prize in Physiology or Medicine 2009](https://www.nobelprize.org/prizes/medicine/2009/illustrated-information/) | (nobelprize.org) [12:45]

**The home page of the Interventions Testing Program (ITP)**: [Interventions Testing Program (ITP)](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp) | (nia.nih.gov) [15:45, 29:00]

**Rich’s article about the framework for the ITP**: [An aging Interventions Testing Program: study design and interim report](https://onlinelibrary.wiley.com/doi/10.1111/j.1474-9726.2007.00311.x) (Miller et al., 2007) [16:45]

**Rich’s 2002 paper which argued that anti-aging medicines were a real possibility worth exploring**: [Extending Life: Scientific Prospects and Political Obstacles](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2690099/) (Richard A Miller, 2002) [17:45]

**Conference that Rich has spoken at**: [Gordon Research Conference on Aging](https://www.grc.org/biology-of-aging-conference/) | (grc.org) [19:00]

**Vast literature on caloric restriction and longevity**: [21:00]

- [Calorie restriction: Part I – an introduction](https://peterattiamd.com/dr01/) | Peter Attia (peterattiamd.com)
- [Calorie restriction: Part IIA – monkey studies](https://peterattiamd.com/calorie-restriction-part-iia-monkey-studies/)  | Peter Attia (peterattiamd.com)

**Cynthia Kenyon’s first paper showing a single gene mutation in worms could extend their life**: [A C. elegans mutant that lives twice as long as wild type](https://pubmed.ncbi.nlm.nih.gov/8247153/) (Kenyon et al., 1993) [21:15]

- *DAF-2 ended up being the analog for the IGF receptor*: [The first long-lived mutants: discovery of the insulin/IGF-1 pathway for ageing](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3001308/) (Kenyon, 2011) [22:00]

**Nature published a paper in 1993 by Linda Partridge “proving” that there could never be a single gene mutation that extended lifespan**: [Optimally, mutation and the evolution of ageing](https://www.nature.com/articles/362305a0) (Partridge and Barton, 1993) [22:45]

**Paper showing the Ames dwarf mutation could extend lifespan by about 40% in a mouse**: [Dwarf mice and the ageing process](https://pubmed.ncbi.nlm.nih.gov/8900272/) (Brown-Borg et al., 1996) [24:15]

**Paper showing the effects on longevity if cancer was abolished**: [In search of Methuselah: estimating the upper limits to human longevity](https://pubmed.ncbi.nlm.nih.gov/2237414/) (Olshansky et al., 1990) [30:30]

**Most common lab mice used in studies**: [black 6 mice](https://en.wikipedia.org/wiki/C57BL/6) | (wikipedia.org) [33:30]

**ITP Paper with Cohort 1 results looking at NDGA and aspirin**: [Nordihydroguaiaretic acid and aspirin increase lifespan of genetically heterogeneous male mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2695675/) (Strong et al., 2008) [38:00]

**First rapamycin study by the ITP (cohort 2) showing a very strong signal in both males and females**: [Rapamycin fed late in life extends lifespan in genetically heterogeneous mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) (Harrison et al., 2009) [44:45, 52:30]

**Invertebrate data in worms showing if you had a mutant that inhibited the function of mTOR that led to longevity increases**: [Genetics: Influence of TOR kinase on lifespan in C. elegans](https://www.nature.com/articles/426620a) (Vellai et al., 2003) [45:00]

- *And in flies*: [Regulation of lifespan in Drosophila by modulation of genes in the TOR signaling pathway](https://pubmed.ncbi.nlm.nih.gov/15186745/) (Kapahi et al., 2004)

**Caloric restriction extends life in mice when started in early life but not so much when started in mid to late life**: [The retardation of aging in mice by dietary restriction: longevity, cancer, immunity and lifetime energy intake](https://pubmed.ncbi.nlm.nih.gov/3958810/) (Weindruch et al., 1986) [47:00]

**The mice developed for the ITP studies**: [HET3 mice](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp/itp-collaborative-interactions-program-faqs) | (nia.nih.gov) [48:00]

**Initial ITP paper on acarbose starting at four months**: [Acarbose, 17-α-estradiol, and nordihydroguaiaretic acid extend mouse lifespan preferentially in males](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3954939/) (Harrison et al., 2014) [56:30, 1:07:15]

**Second ITP paper on acarbose starting at 16 months of age**: [Longer lifespan in male mice treated with a weakly estrogenic agonist, an antioxidant, an α-glucosidase inhibitor or a Nrf2-inducer](https://pubmed.ncbi.nlm.nih.gov/27312235/) (Strong et al., 2016) [56:30, 1:07:15]

**Mice treated with 17-α Estradiol at 16 months resulted in their muscles getting stronger, improved glucose tolerance, and positive changes in muscular structure**: [17-α estradiol ameliorates age-associated sarcopenia and improves late-life physical function in male mice but not in females or castrated males](https://pubmed.ncbi.nlm.nih.gov/30740872/) (Garratt et al., 2019) [58:00, 2:06:15]

**Recent human data using rapalogs, such as everolimus, seem to favor an intermittent dosing strategy**: [59:30]

- [#118 – Lloyd Klickstein, M.D., Ph.D.: Rapamycin, mTOR inhibition, and the biology of aging](https://peterattiamd.com/lloydklickstein/) | Peter Attia (peterattiamd.com)
- [#123 – Joan Mannick, M.D. & Nir Barzilai, M.D.: Rapamycin and metformin—longevity, immune enhancement, and COVID-19](https://peterattiamd.com/joanmannick-nirbarzilai/) | Peter Attia (peterattiamd.com)
- [#114 – Eileen White, Ph.D.: Autophagy, fasting, and promising new cancer therapies](https://peterattiamd.com/eileenwhite/) | Peter Attia (peterattiamd.com)

**Gonzalo Garcia has shown that mice with a Snell dwarf mutation and the growth hormone receptor knockout mutation have extended longevity by 30% via its action on the TOR complex pathways**: [Regulation of mTOR Activity in Snell Dwarf and GH Receptor Gene-Disrupted Mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4298324/) (Dominick et al., 2015) [1:00:45]

**The second rapamycin study by the ITP starting the intervention at 9 months**: [Rapamycin, But Not Resveratrol or Simvastatin, Extends Life Span of Genetically Heterogeneous Mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3021372/) (Miller et al., 2011) [1:03:15]

**Rapamycin blood content in the female mice is 2-3x times higher than male mice**: [Rapamycin-mediated lifespan increase in mice is dose and sex dependent and metabolically distinct from dietary restriction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4032600/) (Miller et al., 2014) [1:05:15]

**The 2013 ITP paper on rapamycin**: [Rapamycin slows aging in mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3434687/) (Wilkinson et al., 2013) [1:05:30]

**ITP study on acarbose using various doses and starting at 8 months**: [Acarbose improves health and lifespan in aging HET3 mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6413665/#acel12898-bib-0031) (Harrison et al., 2019) [1:07:15]

**Matt Kaeberlein is studying rapamycin in dogs**:

- [A randomized controlled trial to establish effects of short-term rapamycin treatment in 24 middle-aged companion dogs](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5411365/) (Urfer et al., 2017) [1:14:30]
- Dog Aging Project: <https://dogagingproject.org/>

**The famous paper by David Sinclair suggesting resveratrol extended life in mice**: [Resveratrol improves health and survival of mice on a high-calorie diet](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4990206/) (Baur et al., 2006) [1:16:15]

- Subsequent paper published in Cell: [Resveratrol delays age-related deterioration and mimics transcriptional aspects of dietary restriction without extending lifespan](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2538685/) (Pearson et al., 2009) [1:17:00]

**First ITP study of resveratrol starting at 12 months of age**: [Rapamycin, But Not Resveratrol or Simvastatin, Extends Life Span of Genetically Heterogeneous Mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3021372/) (Miller et al., 2011) [1:20:15]

**Second ITP study of resveratrol starting at 4 months of age**: [Evaluation of Resveratrol, Green Tea Extract, Curcumin, Oxaloacetic Acid, and Medium-Chain Triglyceride Oil on Life Span of Genetically Heterogeneous Mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3598361/) (Strong et al., 2013) [1:20:15]

**A company called Sirtris sold to Glaxo for ~600 million dollars for pushing sirtuin inhibitors**: [Sirtris Pharmaceuticals](https://en.wikipedia.org/wiki/Sirtris_Pharmaceuticals) | (wikipedia.org) [1:21:15]

**Rhubarb is a good source of resveratrol (as opposed to wine)**: [Therapeutic potential of resveratrol: the in vivo evidence](https://www.med.upenn.edu/baurlab/pdfs/Therapeutic_potential_of_resveratrol.pdf) (Baur and Sinclair, 2006) [1:22:00]

**Satirical article in the New Yorker about what it’s like to be a mouse drinking 600 bottles of wine (for resveratrol)**: [Mouse Au Vin](https://www.newyorker.com/magazine/2009/01/26/mouse-au-vin) | Noah Baumbach (newyorker.com) [1:22:30]

**David Stipp’s book about the Sirtris resveratrol story**: [The Youth Pill](https://www.amazon.com/Youth-Pill-Scientists-Anti-Aging-Revolution/dp/1617230081) by David Stipp | (amazon.com) [1:23:15]

**ITP paper showing negative results of green tea and curcumin**: [Evaluation of Resveratrol, Green Tea Extract, Curcumin, Oxaloacetic Acid, and Medium-Chain Triglyceride Oil on Life Span of Genetically Heterogeneous Mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3598361/) (Strong et al., 2013) [1:24:15]

**James Simpkins work showing 17α-Estradiol did not induce the secondary sexual characteristics that the stronger estrogens, like 17 beta- estradiol and estrogen would**: [A novel mechanism of non-feminizing estrogens in neuroprotection](https://pubmed.ncbi.nlm.nih.gov/27818250/) (Engler-Chiurazzi et al., 2017) [1:27:45]

**ITP studies on 17α-Estradiol**: [1:29:00]

- Cohort 5 used a low dose (4.8 ppm) and it extended median survival in males, but not maximum: [Acarbose, 17-α-estradiol, and nordihydroguaiaretic acid extend mouse lifespan preferentially in males](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3954939/) (Harrison et al., 2014)
- Cohort 7 used a 3x higher dose and it extended maximum longevity, as well as median longevity and at all three sites: [Longer lifespan in male mice treated with a weakly estrogenic agonist, an antioxidant, an α‐glucosidase inhibitor or a Nrf2‐inducer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5013015/) (Strong et al., 2016) [1:30:00]

**Obscure paper that claimed they had detected 17 alpha-estradiol, but only in the brain**: [17α-Estradiol: A Brain-Active Estrogen?](https://academic.oup.com/endo/article/146/9/3843/2500254) (Toran-Allerand et al., 2005) [1:31:30]

**Paper claiming that Ames dwarf mice had turned on a whole bunch of genes that related to bile acids (which work through some molecules related to the retinoid acid receptor)**: [Alterations in xenobiotic metabolism in the long-lived Little mice](https://pubmed.ncbi.nlm.nih.gov/17521389/) (Amador-Noguez et al., 2007) [1:33:30]

**Hydrogen sulfide was suggested to the ITP by James Mitchell whose work suggests it might be an important controlling element in the aging process**: [Selective Persulfide Detection Reveals Evolutionarily Conserved Antiaging Effects of S-Sulfhydration](https://pubmed.ncbi.nlm.nih.gov/31735592/) (Zivanovic et al., 2019) [1:34:30]

**ITP paper showing canagliflozin increased median lifespan in the male mice by 14%, maximum extension of 9%, but it had no effect on the females**: [Canagliflozin extends life span in genetically heterogeneous male but not female mice](https://insight.jci.org/articles/view/140019) (Miller et al., 2020) [1:36:00]

**Reports suggests that SGLT-2 inhibitors may have an effect on tumors, heart attacks, and more independent of whatever’s happening in terms of glycemic control**: [SGLT2i: beyond the glucose-lowering effect](https://cardiab.biomedcentral.com/articles/10.1186/s12933-020-01071-y) (Ni et al., 2020) [1:42:00]

**Metformin study (that Rich is critical of) showing a longevity effect in mice**: [Metformin improves healthspan and lifespan in mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3736576/) (Martin-Montalvo et al., 2014) [1:44:00]

**ITP study showing metformin given alone did not extend life in mice**: [Longer lifespan in male mice treated with a weakly estrogenic agonist, an antioxidant, an α‐glucosidase inhibitor or a Nrf2‐inducer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5013015/) (Strong et al., 2016) [1:44:00]

**Non-human literature showing the powerful longevity effect of rapamycin from worms, fruit flies, mice, & yeast**: [Rapamycin: An InhibiTOR of Aging Emerges From the Soil of Easter Island](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4906330/) (Apelo and Lamming, 2016) [1:45:30]

**Matt Kaeberlein’s work studying rapamycin in dogs**: [#10 – Matt Kaeberlein, Ph.D.: rapamycin and dogs — man’s best friends? — living longer, healthier lives and turning back the clock on aging and age-related diseases](https://peterattiamd.com/mattkaeberlein/) [1:45:30]

**The TAME study which is looking at the potential longevity benefit of metformin in humans**: [The Targeting Aging with Metformin (TAME) Trial](https://www.afar.org/tame-trial) | (afar.org) [1:46:30]

**Epidemiology study that showed the mortality risk of diabetics on metformin was actually better than non-diabetics of the same age and sex**: [Can people with type 2 diabetes live longer than those without? A comparison of mortality in people initiated with metformin or sulphonylurea monotherapy and matched, non-diabetic controls](https://pubmed.ncbi.nlm.nih.gov/25041462/) (Bannister et al., 2014) [1:47:00]

**Strong data suggesting that aspects of aging and age-associated diseases can be altered by making NAD more available**: [1:49:45]

- [#27 – David Sinclair, Ph.D.: Slowing aging – sirtuins, NAD, and the epigenetics of aging](https://peterattiamd.com/davidsinclair/) | Peter Attia (peterattiamd.com)
- [#70 – David Sinclair, Ph.D.: How cellular reprogramming could slow our aging clock (and the latest research on NAD)](https://peterattiamd.com/davidsinclair2/) | Peter Attia (peterattiamd.com)
- [#46 – Chris Masterjohn, Ph.D.: Navigating the many pathways to health and disease – NAD and sirtuins, methylation, MTHFR and COMT, choline deficiency and NAFLD, TMAO, creatine and more](https://peterattiamd.com/chrismasterjohn/) | Peter Attia (peterattiamd.com)

**Glycine showed a small boost in lifespan in an ITP study**: [Glycine supplementation extends lifespan of male and female mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6516426/) (Miller et al., 2019) [1:57:45]

**Famous caloric restriction experiments at Wisconsin and NIA**: [1:59:45]

- [Dietary restriction and aging in rhesus monkeys: the University of Wisconsin study](https://pubmed.ncbi.nlm.nih.gov/11113597/) (Ramsey et al., 2000)
- [Impact of caloric restriction on health and survival in rhesus monkeys: the NIA study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3832985/) (Mattison et al., 2013)

**All humans die with atherosclerosis**: [When does heart disease begin (and what this tells us about prevention)?](https://peterattiamd.com/heart-disease-begin-tell-us-prevention/) | Peter Attia (peterattiamd.com) [2:02:45]

**Rich’s satirical article for the MIT Technology review**: [“Flying Pigs” letter to MIT Technology Review](https://www.richmillerlab.com/flying-pigs) | Richard Miller (richmillerlab.com) [2:08:15]

§

## People Mentioned

- [Bnot Netanya](https://en.wikipedia.org/wiki/Bnot_Netanya_F.C.) [4:15]
- [Reggie Jackson](https://en.wikipedia.org/wiki/Reggie_Jackson) [4:15]
- [Leonard Hayflick](https://en.wikipedia.org/wiki/Leonard_Hayflick) [7:30]
- [Vittorio Defendi](https://pubmed.ncbi.nlm.nih.gov/?term=Defendi%20V%5BAuthor%5D&cauthor=true&cauthor_uid=4322080) [8:45]
- [Joan Mannick](https://peterattiamd.com/joanmannick-nirbarzilai/) [11:00]
- [Matt Kaeberlein](https://kaeberleinlab.org/people/matt-kaeberlein) [11:00, 1:45:30]
- [Elizabeth H. Blackburn](https://en.wikipedia.org/wiki/Elizabeth_Blackburn) [12:45]
- [Vera Gorbunova](https://www.sas.rochester.edu/bio/labs/Gorbunova/2017/03/27/dr-vera-gorbunova/) [13:45]
- [Huber Warner](https://www.nia.nih.gov/news/nia-mourns-loss-dr-huber-warner) [15:45]
- [Nancy Nadon](https://orwh.od.nih.gov/research/sex-gender/research-spotlights/nancy-nadon) [16:00]
- [Arlan Richardson](https://www.ouhsc.edu/roca/Our-People/Profile-Page/arlan-richardson-phd-1) [16:00]
- [David Harrison](https://www.jax.org/research-and-faculty/faculty/dave-harrison) [17:00]
- [Randy Strong](https://www.uthscsa.edu/academics/medicine/profile/strong) [17:00, 1:05:15]
- [George Martin](https://depts.washington.edu/mbwc/about/profile/george-martin) [19:00]
- [Cynthia Kenyon](https://en.wikipedia.org/wiki/Cynthia_Kenyon) [21:15]
- [Tom Johnson](https://www.colorado.edu/iphy/people/professors/thomas-e-johnson) [22:00]
- [Gary Ruvkun](https://en.wikipedia.org/wiki/Gary_Ruvkun) [22:00]
- [Andrzej Bartke](https://www.siumed.edu/im/faculty/andrzej-bartke.html#:~:text=Andrzej%20Bartke%2C%20Ph.,control%20of%20aging%20in%20mammals.)
- [Holly Brown-Borg](https://und.edu/directory/holly.brown.borg) [24:15]
- [Robin Holiday](https://en.wikipedia.org/wiki/Robin_Holliday) [24:45]
- [S. Jay Olshansky](https://en.wikipedia.org/wiki/S._Jay_Olshansky) [30:30]
- [Bruce Carnes](https://www.researchgate.net/profile/Bruce_Carnes) [30:30]
- [Richard Hodes](https://www.nia.nih.gov/about/staff/hodes-richard#:~:text=Biography-,Richard%20J.,head%20the%20NIA%20in%201993.) [37:15]
- [Dave Sharp](https://barshopinstitute.uthscsa.edu/team-member/sharp-dave/) [45:00]
- [Richard Weindruch](https://www.worldsciencefestival.com/participants/richard_weindruch/#:~:text=Richard%20Weindruch%20has%20devoted%20decades,co%2Dfounder%20of%20LifeGen%20Technologies.) [47:00]
- [Mike Garratt](https://www.otago.ac.nz/bms/expertise/profile/index.html?id=2975) [58:00, 2:06:15]
- [Sharlene Day](https://www.the-asci.org/controllers/asci/AsciProfileController.php?pid=501505#:~:text=Sharlene%20Day%20graduated%20from%20the,at%20the%20University%20of%20Michigan.) [58:00, 2:06:15]
- [Jonathan Herrera](https://www.researchgate.net/profile/Jonathan_Herrera) [58:00, 2:06:15]
- [Gonzalo Garcia](https://scholar.google.com.mx/citations?user=UjQd3aQAAAAJ&hl=es) [1:00:45]
- [Scott Pletcher](https://medicine.umich.edu/dept/molecular-integrative-physiology/scott-pletcher-phd) [1:04:30]
- [Martin Javors](https://www.uthscsa.edu/academics/biomedical-sciences/faculty/profile/0U10PFDAY/Javors%2C-Martin-A) [1:05:15]
- [David Allison](https://en.wikipedia.org/wiki/David_B._Allison) [1:07:45]
- [Daniel Smith](https://scholars.uab.edu/display/dsmithjr) [1:07:45]
- [Matt Kaeberlein](https://kaeberleinlab.org/people/matt-kaeberlein) [1:14:30]
- [David Sinclair](https://genetics.med.harvard.edu/sinclair/people/sinclair.php) [1:16:00, 1:22:00]
- [Rafael de Cabo](https://en.wikipedia.org/wiki/Rafael_de_Cabo) [1:19:15, 1:44:00]
- [David Stipp](https://www.scientificamerican.com/author/david-stipp/) [1:23:15]
- [James (Jim) Simpkins](https://directory.hsc.wvu.edu/Profile/38338) [1:27:15]
- [Gretchen Darlington](https://allpeople.com/gretchen+j+darlington+ph+d_baylor-college-of-medicine_296i-us) [1:33:30]
- [James Mitchell](https://lsi.princeton.edu/news-seminars/seminars/james-mitchell-harvard-th-chan-school-public-health) [1:34:00]
- [Nir Barzalai](https://en.wikipedia.org/wiki/Nir_Barzilai) [1:46:15]
- [J. Erby Wilkinson](https://animalcare.umich.edu/department/staff/j-erby-wilkinson-dvm-phd-dacvp) [2:02:30]
- [Aubrey de Grey](https://en.wikipedia.org/wiki/Aubrey_de_Grey) [2:08:30]

§

![](https://peterattiamd.com/wp-content/uploads/2021/02/1x1-richard-miller-500x500.jpeg)

##### Richard Miller, M.D., Ph.D.

Richard A. Miller, M.D., Ph.D., is a Professor of Pathology at the University of Michigan.  He received the BA degree in 1971 from Haverford College, and MD and PhD degrees from Yale University in 1976-1977.  After postdoctoral studies at Harvard and Sloan-Kettering, he began his faculty career at Boston University in 1982 and then moved to his current position at Michigan in 1990.

Dr. Miller has served in a variety of editorial and advisory positions on behalf of the American Federation for Aging Research and the National Institute on Aging, and served as one of the Editors-in-Chief of Aging Cell.  He is the recipient of the Nathan Shock Award, the AlliedSignal Award, the Irving Wright Award, an award from the Glenn Foundation, and the Kleemeier Award for aging research.  He has been a Senior Scholar of the Ellison Medical Foundation, and is a Fellow of the American Association for the Advancement of Science and a member of the American Association of Physicians.  At Michigan, he directs the Paul Glenn Center for Aging Research.

His research program includes ongoing studies of the mechanisms that link stress, nutrients, and hormones to delayed aging in mice, development of new approaches to slow aging and disease through drugs and targeted mutations, and studies of the ways in which cells from long-lived birds, rodents, and primates differ from those of short-lived species.

For fun he sometimes photographs wildlife or landscapes; you can check it out [here](https://richardmiller.zenfolio.com/).