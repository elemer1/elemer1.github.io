# #324 ‒ Metabolism, energy balance, and aging: How diet, calorie restriction, and macronutrients influence longevity and metabolic health | Eric Ravussin, Ph.D.

**Source:** [https://peterattiamd.com/ericravussin/](https://peterattiamd.com/ericravussin/)

---

Eric Ravussin is a world-renowned expert on obesity, metabolism, and aging whose pioneering research has shaped much of what we understand today about energy balance and caloric restriction. In this episode, Eric shares insights from his cutting-edge work on energy expenditure—a critical factor in understanding how our bodies regulate weight and appetite. He discusses methods for measuring energy output, energy balance, food intake, and appetite regulation, and explores key studies on macronutrient manipulation. Eric then delves into the CALERIE study on caloric restriction, highlighting insights related to biomarkers of both primary and secondary aging. The conversation also covers the potential of GLP-1 agonists to replicate these effects and looks ahead to how AI and technology could transform metabolic research in the coming years.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/ericravussin/the_Drive_public.png)

Play

#324 ‒ Metabolism, energy balance, and aging: How diet, calorie restriction, and macronutrients influence longevity and metabolic health | Eric Ravussin, Ph.D.

#324 ‒ Metabolism, energy balance, and aging: How diet, calorie restriction, and macronutrients influence longevity and metabolic health | Eric Ravussin, Ph.D.

1x15s30s

0:002:09:23

## We discuss:

- Eric’s background and current work metabolism and measuring energy expenditure [3:00];
- The science behind metabolic chambers for measuring energy expenditure, and the complexities of indirect and direct calorimetry [8:00];
- The body’s regulatory systems for maintaining energy balance and the primary influence of energy intake on body weight [18:30];
- The epidemic of obesity and a discussion of resting metabolic rate [24:45];
- The impact of exercise, appetite, gut hormones, and eating patterns on weight regulation [28:45];
- Experiments looking at how macronutrient composition affects energy expenditure [38:45];
- The challenges of studying diet in real-life settings, the potential of personalized nutrition, and how public health policy could play a role in guiding nutritional habits [51:00];
- The importance of protein in the diet, the limitations of dietary data collection, and how AI could potentially transform nutrition science [1:08:15];
- How Eric’s interest in caloric restriction (CR) began with Biosphere 2, metabolic efficiency’s role in aging, and goals of the CALERIE study [1:15:15];
- The CALERIE study: exploring the real-world impact of caloric restriction [1:28:00];
- Notable findings from the CALERIE study after two years: sustained weight loss, participant retention, and more [1:40:00];
- The effect of caloric restriction on the hallmarks of aging [1:47:00];
- The challenge of applying CR to the general population, the potential of drugs and exercise to mimic the effects of CR [1:55:45];
- Upcoming study comparing caloric restriction to time-restricting eating, and Peter’s takeaways from the discussion [2:02:45]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Eric Ravussin is the director of the Nutrition Obesity Research Center at Louisiana State University’s Pennington Biomedical Research Center
  - Where he also serves as the Douglas L. Gordon Chair in Diabetes and Metabolism
- Having published over 600 peer-reviewed manuscripts, Eric is regarded as a world expert in obesity, metabolism, and aging
- He has received numerous awards for his contributions to these fields
- As discussed in the beginning of this podcast, Eric and Peter worked together for about 4 years, roughly 15 years ago
  - During that period of time, Peter came to have such an admiration for Eric, his curiosity and intellect when it comes to this field
- We talk about Eric’s background and his extensive experience in metabolic research
  - In particular, when it comes to measuring energy expenditure, which turns out to be a very technically demanding problem
  - We go through the various methods that this is done, including what is regarded today as the gold standard
    - This is necessary, because if you want to understand energy balance, you must be able to measure energy expenditure
- We discuss energy balance, energy expenditure, food intake, how we regulate appetite, and the findings of a very important [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4962163/) that Eric did
  - This study looked at the impact of manipulating the ratio of macronutrients to see if it would change the energy expenditure
  - Disclosure: Peter was involved in the funding of that study
- We then delve into the [CALERIE study](https://calerie.duke.edu/), which looked at caloric restriction
  - We discuss its insights as it pertains to biomarkers of both primary and secondary aging
- We speak about the implications of GLP-1 agonists and similar drugs in replicating the benefits of caloric restriction
- We look to the future of this research and see how new technology advancements like AI might come into play

## Eric’s background and current work metabolism and measuring energy expenditure [3:00]

**Eric and Peter worked together at NuSI**

- Peter was part of an organization called [NuSI](https://garytaubes.com/the-dissolution-of-the-nutrition-science-initiative/), and Eric was 1 of 6 of the principal investigators for a very audacious experiment and part of something called the Energy Balance Consortium, along with [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin), [Steve Smith](https://www.adventhealthresearchinstitute.com/team/steven-smith), [Rudy Leibel](https://www.ihn.cuimc.columbia.edu/profile/rudolph-l-leibel-md#research), [Mike Rosenbaum](https://www.nynorc.cuimc.columbia.edu/profile/michael-rosenbaum-md#research), and [Marc Reitman](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/reitman-marc)
- It was a once in a lifetime opportunity to do something that had never been done before, which was a multi-center indirect calorimetry inpatient study that was really aimed at trying to at least pilot what would be necessary to do the definitive experiment to answer a question which has to do with the nature of calories and weight gain
- For 4 years, they had the pleasure of working together and really getting into the weeds of how one technically tries to measure these things and how difficult it is and all of the challenges and potential pitfalls of this

**Give folks a sense of your life’s work and your life’s passion**

- Eric has been at [Pennington Biomedical Research](https://www.pbrc.edu/about/) for 24 years
  - He was the Associate Executive Director for Clinical Science
- He joined Pennington after spending 2.5 years at Eli Lilly
- Before that, he was 15 years at the NIH (intramural research)

> “*The reason I came to this country was to build the first metabolic chamber or indirect calorimetry chamber to measure energy expenditure in people over periods of hours and days.*”‒ Eric Ravussin

*Tell folks a little bit about what it means to be intramural versus extramural NIH*

- The NIH budget is about $33-35 billion, but there is a group which is intramural
- Most of the money (80-85%) goes to all the academic institutions doing biomedical research in the country (extramural research)
- In intramural research you are an employee of the NIH, you work at the NIH campus, and your funding comes from the organization that you work for
- Eric was intramural based in Phoenix Arizona
- He worked a lot with the Pima Indians ‒ they have the highest prevalence of type 2 diabetes and the second-highest prevalence of obesity in the world
- What Eric likes about intramural research is that you are judged after the fact
  - You have a budget and you can do whatever you want, and every 3 years you are judged
- Whereas extramural, we chase these grants and you have to basically provide preliminary data, hypothesis, and you are judged before doing the study
- Eric thinks you can be much more creative being intramural than extramural

**Pennington is a pretty unique institution**

- It’s becoming the largest institution for research in nutrition and obesity
- We concentrate mostly on nutrition and obesity
- We have about 500 people working at Pennington and everybody is doing research
  - We have no formal teaching (yes, we have postdocs and things like that)
- We do research and we have maybe a functional budget of $80 million per year
  - 50% or 45% of that is NIH extramural money coming to Pennington
  - We do some sponsored project for pharma or biotech
  - We have grants from associations like the American Diabetes Association or American Heart Association and so on
- We do basic science, clinical science, and population science
  - Basically, which is to reach the community and implement some of the discovery into the community

## The science behind metabolic chambers for measuring energy expenditure, and the complexities of indirect and direct calorimetry [8:00]

- There’s 2 things: [indirect calorimetry](https://en.wikipedia.org/wiki/Indirect_calorimetry) and [direct calorimetry](https://en.wikipedia.org/wiki/Food_energy#Direct_calorimetry_of_combustion)
- You generate your energy metabolism or ATP by oxidative process, and you oxidize carbohydrate, fat, and a little protein
- The build up these ATPs which are used for generation or maintenance of the cells or activity and so on
- Now, when you have this metabolism, you produce heat
  - If you have no exercise, no external work, all the energy which is provided in generating this ATP is lost as heat
  - And this is direct calorimetry
- Eric was fortunate when he did his Ph.D. back in Lausanne, Switzerland to have access to both indirect and direct calorimetry
  - You can really do fantastic studies
  - We did a study of measuring *in vivo* what we call the P/O ratio
    - How many oxygen do you need to generate 1 ATP and all these kinds of things, by the combination of these 2 techniques
- When you’re doing **direct calorimetry** on something like food, if you want to know the energy content of food, you can burn the food and measure the heat
- It is also possible to do direct calorimetry in humans, and Eric was fortunate to be at a place which had 1 of the 2 direct calorimeters
  - At the time, there was one in Bethesda (it doesn’t exist anymore, nor does the one in Switzerland)
- A **direct calorimeter** a little bit bigger than a cubic meter box, and you recover all the heat and you have dry heat by convection and you have a gradient layer capturing the heat production
  - You collect the evaporative heat losses from perspiration, expiration and so on, and you merge all that and you have a complete heat balance of the person

***With direct calorimetry, we measure these 2 kinds of heat, and this is basically equal to your metabolic rate***

- You generate energy by oxidation of substrate and the byproduct is heat
- And without exercise or external work, energy in is equal energy out
- Eric did a lot of these studies during his Ph.D.
- Now going to **indirect calorimetry**, this is an easier one than direct

*A metabolic chamber is like a hotel room in which you can live 1-2 days*

- Peter stayed in one of these rooms at Pennington in Baton Rouge
- Here we measure oxygen consumption and CO2 production
  - Oxygen is used to oxidize the substrate; it produces CO2 and water

***Knowing oxygen consumption and CO******2*** ***production, you can calculate the energy expenditure or the energy generated by this oxidative process; and you can also calculate the substrate that you oxidize***

- If the ratio between the VCO2, the CO2 production and the oxygen consumption is 1, you oxidize carbohydrate
- If the ratio is 0.7, you oxidize fat
- And protein is something in between (0.82) depending on the protein

**Peter summarizes**:

- By measuring just these 2 things: the concentration of oxygen consumed and the rate at which it’s being consumed, and the same with the production of CO2
- You can infer the **total energy consumption** (total calories consumed, kcal)
- And by looking at the ratio of VCO2 and VO2,  you can calculate what fraction of that is coming from **oxidizing carbohydrate versus fat**
- Peter explains, “*Having spent probably a total of eight days of my life inside metabolic chambers across a period of a couple of years, it never ceases to amaze me, never just how accurately these rooms work*.”
- Peter uses an indirect calorimeter all the time [measuring VO2 max](https://vo2master.com/)
  - It’s basically the same technology, but it’s easier because you’re strapping the mask to your face, so you have perfect access to exactly the O2 consumption and the CO2 production
  - It’s doing the exact same calculation
  - It’s going to tell you exactly how much energy you’re utilizing and where the substrate comes from
  - In that situation, you’re interested in knowing the maximum amount of VO2 or O2 consumption

**What would you estimate is the error on the hotel room sized indirect calorimeter where you don’t have the luxury of just slapping a mask to the person’s face for a few days?**

- When Eric was at the NIH, they did a lot of reliability testing in the same person
- You can also calibrate the system with standard gas that you know the exact concentration
- You can also mimic someone by burning alcohol or propane and you can vary the rate of burning
- When Eric did a study with 4 different chambers, they validated the chambers, ones against the other one, and we accepted to have 3% deviation for CO2 or oxygen
- Based on stoichiometry, you know exactly how much alcohol or propane you burn, you know how much CO2 should be produced, and how much oxygen has been consumed
  - And this is what we did
- The indirect calorimeter is very, very precise and you don’t have the inconvenience of the mask
  - You couldn’t measure with a mask for 24 hours or 2 days
- When Peter as in that chamber for a couple of days (on separate occasions), we were trying to replicate his life as much as possible
  - He had 3 meals prepared
  - He had an exercise bike, weights, and equipment
- We were very interested in seeing how that would compare with what we knew Peter was experiencing in the outside world based on when we could put a mask on him.
- We also spent about 10 days using [doubly labeled water](https://en.wikipedia.org/wiki/Doubly_labeled_water) (which we’ll talk about at some point)

***All of that is to say that scientists such as yourself have some pretty high fidelity tools to measure energy expenditure; but it comes with a caveat, which is it has to be done under this very controlled setting***

- These people need to be in a metabolic ward inside a chamber
  - Which  is basically a NASA grade gas chamber with O2 and CO2 sensors

Peter asks, “*How many sensors… would be in a particular chamber?*”

- We don’t need many because we need to homogenize the air in the room
- We have to measure humidity
- We have to measure temperature because you have to do this correction, what we call STPD, which is standard pressure, et cetera, to calculate the energy generated by this oxygen

***It’s quite phenomenal the accuracy of those ‒ the accuracy or the precision is about 2.5%***

- Now if you repeat yourself 5x and myself, there’s a little bit more variability because we vary from one day to another one and so on
- But this is quite amazing that we can calculate so precisely your energy expenditure during a day or two days and so on

**The accuracy of calories consumed**

- Eric adds, “*I wish we had the same system to calculate the energy that we put in.*”
- Outside of having food prepared in a metabolic kitchen, Peter thinks at best we’re probably ±10%
- When you do that under supervision and you provide all the meals like [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin) is doing, like we’re doing, then you have a good estimate and you subtract what is returned on the plate or these kind of things, but it’s not normal life

***It’s very difficult to estimate energy intake; as soon as you go to normal life and free living conditions, things are falling apart***

## The body’s regulatory systems for maintaining energy balance and the primary influence of energy intake on body weight [18:30]

- 99% of people out there aren’t weighing every single morsel of food they eat every single time they open their mouth
- People are going to have enormous variability in what they’re eating
- Peter puts himself in that category ‒ he eats according to his appetite
  - Sometimes he overeats and sometimes he is really busy and doesn’t get around to eating that much
- What’s interesting is that Peter’s weight lives within a 2 lb. variation (for years), and he doesn’t think he’s unique in this

**Do you agree that this is a common phenomenon?**

- Yes
- But if you take Peter’s lifetime history, maybe he is an exception
- Eric has gained some weight over the last 50 years
  - When he got married in 1975 he weighed 69 kilos and now he weighs close to 77 (152 to 170 lbs.)
  - There is also a change in body composition

***It’s very rare that people are staying the same constantly, so maybe Peter is an exception***

- Peter has probably had more variation in his weight than what Eric is describing over the period of time, but what he’s getting at is the following question

**How does the body regulate energy storage, which is effectively what is determining our weight?**

*Is it how much we are storing as fat? How much are we storing as lean tissue?*

- Peter thinks that seems very regulated despite very little control over the input and the output
  - We are free living animals who live in an environment with endless inputs
  - We have to somehow regulate that and frankly, very little reason to do deliberate outputs
  - The majority of our energy expenditure is based on essential function of life, just the necessary ATP production for cellular function
  - It’s not like most of us are out there expending energy, deliberately exercising and moving necessarily to expend energy
- So as we enter this discussion of the energy balance model, let’s just talk about energy balance

*Why are we so largely able to conserve mass despite very noisy inputs and outputs into the black box?*

***Eric doesn’t have an answer***

**Leptin**

- When [leptin](https://en.wikipedia.org/wiki/Leptin) was discovered, it was an ah-ha moment

***It’s a signal which comes from the energy storage and therefore it seems to regulate food intake, also energy expenditure and all that***

- Eric was fortunate to have access to the 3 Turkish leptin-deficient people that they [measured](https://pubmed.ncbi.nlm.nih.gov/20061423/) in these chambers in Baton Rouge
- He thought that we would have a clue and it was not the case
- We know that leptin is very good to defend against the loss of weight when it becomes extreme, but it doesn’t work on the other side of the equation when you creep up with your weight because you become leptin-resistant and your leptin is not telling you to stop eating

Eric explains, “*I think that we learn a lot about the biology of energy balance thanks to leptin, but then we need to think that we have also signals coming from the fat-free mass.*”

**What is fat-free mass?**

- We measure it as everything but the fat, and we call that fat-free mass
  - It’s liver, it’s skeletal muscle, it’s everything but the fat

***There are signals that we are still chasing***

- [John Blundell](https://medicinehealth.leeds.ac.uk/psychology/staff/1183/professor-john-blundell-) showed that we eat according to our **fat-free mass**, which is basically we eat according to our **resting metabolic rate** because fat-free mass is the major determinant of your resting metabolic rate
- But what are the signals?
- Eric still doesn’t know
- We have to be modest here and say there are still things that we don’t understand when it comes to this energy balance
  - [The figure below summarizes signals that contribute to energy balance]

![](https://peterattiamd.com/wp-content/uploads/2024/11/f1-ericravussin-669x1024.jpeg)

**Figure 1. Current summary of signals that contribute to energy balance**. Image credit: [*The American Journal of Clinical Nutrition* 2022](https://pubmed.ncbi.nlm.nih.gov/35134825/)

**Back to Peter’s question about the stability of his weight**

- Eric can understand that why you don’t gain 5 kg over this coming year because in response to creeping up your weight, you burn more energy
- If you do the same physical activity, this extra 5 kilos (or 10 pounds) is going to cost you more energy
- Your resting metabolic rate is creeping up and basically you offset that

*Why are we so good at maintaining within a couple of pounds over a year or two years or three years or five years?*

***Eric thinks we’re still missing some signals***

- When [FGF-21](https://en.wikipedia.org/wiki/Fibroblast_growth_factor_21) (which is a signal coming from the liver) was discovered, he thought maybe that’s it
- Or when you have some of the myokines coming from the skeletal muscle, he thought maybe this is it
- It’s not been it

***We have to be modest and say, “Hey, we still have things to discover when it comes to this regulation of energy balance.”***

## The epidemic of obesity and a discussion of resting metabolic rate [24:45]

**How our weight as a population has changed over recent decades**

- We have not been very good
- From the 1980s to 2010, the American population has gained 10 kilograms (22 pounds in 30 years)

***It means that the major driver is this environment and the change in the environment has been the trigger of this weight gain***

- Of course, some people are successful, some are less; and this is a problem
- Now we have an **epidemic of obesity** ‒ it has replaced the contagious disease of the past
  - Now we have all these consolation of conditions which are associated with obesity

**Peter thinks the best we can do is informed guessing**

Peter asks, “*How much of the regulation do you think is occurring on the appetite side, meaning feedback from whatever is happening in the system?*”

- Let’s posit that it’s coming from the lean part of the system
  - All but the adipose tissue, and that is working to feed into the appetitive system

*Or do you think the balance is more on the expenditure system where those signals are feeding to make us move a little bit more?*

*Or is it simply the extra weight you have to move around?*

**When Eric first joined the NIH he did a study in the Pima Indians**

- They are very prone to weight gain
- We [measured](https://pubmed.ncbi.nlm.nih.gov/3340128/) in 150 people the 24-hour energy expenditure as well as the resting metabolic rate
- We found that there was large variability between people after adjusting for their body size, fat-free mass and fat mass
- Now we do better because we have organ size and we do MRI and all these kind of things
- There is variability and this variability is associated with family membership (there is a genetic background to that)

***What we found was that those people in the lower tertile of this metabolic rate adjusted for body size were at much higher risk of gaining weight***

![](https://peterattiamd.com/wp-content/uploads/2024/11/f2-ericravussin.png)

**Figure 2. Cumulative weight gain in subjects grouped by resting metabolic rate (RMR)**. Image credit: [*NEJM* 1988](https://pubmed.ncbi.nlm.nih.gov/3340128/)

***When we try to attribute the weight gain either to energy expenditure being low or the other side of the equation (intake being high), intake was 80%***

**There are so many systems which are basically regulating energy expenditure and food intake**

- [Nicotine](https://en.wikipedia.org/wiki/Nicotine) for example, nicotine is a stimulant of energy expenditure
- Smokers have higher metabolic rate, but they have less appetite
- Take the activity of your [sympathetic nervous system](https://en.wikipedia.org/wiki/Sympathetic_nervous_system): it is also thermogenic, but it cuts appetite
- We have to understand better these 2 systems

Eric explains, “*To answer your question, I would say 80% is on the side of the energy intake.*”

## The impact of exercise, appetite, gut hormones, and eating patterns on weight regulation [28:45]

**We know that exercise is pretty bad for weight loss**

- [Donnelly](https://lifespan.ku.edu/people/joseph-donnelly) at University of Kansas has done ton of study like that

> “*Physical activity for weight loss is a B minus at best in term of evidence that it plays a role.*”‒ Eric Ravussin

**Talk about why, because it is counterintuitive**

- Peter preaches this to his patients, “*That exercise is the single most important thing we need to do for health*.”
- But he’s quick to follow that up with, “*But it’s not the tool you’re going to use to regulate body weight.*”

***Energy intake, nutrition is the more important tool to regulate body weight***

- First of all, if you try to put calories on your exercise
  - It’s easy on a bicycle, you know the efficiency, 25%, you know the workload and so on, and you can calculate or you can use your mask and measure oxygen consumption
- There is a compensation: **very vigorous exercise is anorectic**
  - You don’t want to eat after you finish a marathon
  - Peter interviewed [George Brooks](https://vcresearch.berkeley.edu/faculty/george-brooks) from Berkeley recently [[episode #312](https://peterattiamd.com/georgebrooks/)], and he shared something Peter didn’t know: that lactate specifically is probably partially driving the anorexia we experience following intense exercise
    - That might not be present with low intensity exercise
    - Peter thought that was an interesting way to connect a fact that most people appreciate, which is go out and do interval training, and the last thing you want to do for the next hour or so is eat

***Light exercise has the opposite effect, it drives appetite***

[**Tim Church**](https://www.truehealthinitiative.org/council_member/tim-church/)**, who was at Pennington did a study called** [**E-MECHANIC**](https://pubmed.ncbi.nlm.nih.gov/31172175/)

- Basically they measured every calorie spent on exercise on a treadmill, on the bicycle, ergometer and all that
- They looked at the weight of the people with these different doses of exercise
- They found there was a compensation
- Now what it didn’t measure was to use doubly labeled water
- Did they compensate by being less active out of their periods of exercise?
  - You have 90 minutes of exercise, but then you relax a little bit more rather than fidgeting or moving and so on, or you sleep a little bit longer
  - This, it didn’t measure

***With exercise there was this compensation with food intake***

Eric adds, “*First of all, I didn’t say that exercise is not good for health… because I’m an aficionado of exercise. I know how good it is for health. But it’s not as good for weight control in general.*”

**There is a difference here that people understand**

- You have to do the calculation of how many calories are burned when you run a K or a mile and so on, versus how quickly you can ingest the calories the same amount (or much more)

***Exercise and physical activity is the key for weight loss maintenance***

- [The Weight Registry](http://www.nwcr.ws/) (from [Rena Wing](https://vivo.brown.edu/display/rwingphd#Research) and [Jim Hill](https://scholars.uab.edu/6698-james-hill)) [showed](https://pubmed.ncbi.nlm.nih.gov/16741274/) that those who were successful at maintaining the weight loss at 5 years after the intervention were those who engage in more physical activity

> “*I still believe that a nutritional approach to weight loss without physical activity or exercise prescribed is not a good strategy. We should implement both and try to have people enjoying the exercise.*”‒ Eric Ravussin

- [Richard Bergman](https://researchers.cedars-sinai.edu/Richard.Bergman) said, “*I would never exercise. I’d rather be sitting in a cold bathtub to generate some heat rather than exercise*.”
- And there are some people who cannot exercise
- You take the taste of exercise from childhood, and you become more physically active in the rest of your life
- It’s not at the age of 40 because you have too much weight that they can tell you, “*Oh, you have to do your 150 minutes per week of moderate to vigorous activity and all that.*”
  - It doesn’t work in genera)

***Physical activity is a key point in metabolic health in general***

- Peter agrees, and when he looks at the data from Jim Hill, he’s always found it difficult to infer the **direction of causality**
  - It could be that doing a lot of exercise is a valuable tool to drive weight maintenance, i.e, maintenance of energy balance
  - Alternatively, it could be the people who metabolically get fixed through weight loss are the ones that have an easier time exercising
- Peter is curious how robust the data are
- Peter knows that you could go ride your bike for an hour and you could burn 600 kcal and you can eat 600 kcal in way less than an hour

**Two things Peter has noticed**

- 1 – Exercise seems to sharpen your appetite to a point that makes you a more responsible eater
  - It hones your appetitive signals
- 2 – The one thing you as the individual have to do is just be mindful of the speed at which you eat so that you give the brain a moment to recognize what is happening

**Peter’s example**

- If he does a zone 2 bike ride for an hour, he’s going to expend about 750-800 kcal (total) (call it 800 to make the math easy)
- If he waits an hour before he eats and he doesn’t eat very quickly, he won’t overeat and he’ll be fine for the rest of the day
  - He won’t have a hyperbolic appetite
- Conversely, if he eats within 20-30 minutes and pays no attention to the speed at which he eats, he can easily consume 1,000 calories in that 1 sitting and abrogate the entire energy effect of the exercise
  - Obviously he’s still getting all the benefits of the exercise

**Have you seen this?**

*Do you have any insight into the effect of exercise on how we subsequently regulate appetite and how we might sense the hunger hormones, everything from* [*leptin*](https://en.wikipedia.org/wiki/Leptin)*,* [*ghrelin*](https://en.wikipedia.org/wiki/Ghrelin) *and even* [*GLP-1*](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1)*?*

- Eric doesn’t have an answer because energy intake is not his field
- Gut hormones: [GLP-1](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1), [GIP](https://en.wikipedia.org/wiki/Gastric_inhibitory_polypeptide), [CCK](https://en.wikipedia.org/wiki/Cholecystokinin), [PYY](https://en.wikipedia.org/wiki/Peptide_YY), [glucagon](https://en.wikipedia.org/wiki/Glucagon), [insulin](https://en.wikipedia.org/wiki/Insulin)
  - We are starting to know more because they are such good targets for weight management

***There’s no question in Eric’s mind that the speed at which you deliver this food in the stomach and it leaves the stomach is very important for the kinetic of these gut hormones which are important for the regulation of your food intake in general***

**This is one thing that these GLP-1 and combination of peptides is shedding light on**

- They are potent modulators of your intake
- Eric doesn’t know how the interaction between the exercise that you do before and the meal that you have 20 minutes after and the speed of the meal and all that works
  - But it would be a very good topic of research
  - The interaction between a bout of exercise, the speed at which you ingest calories, and the delivery of these gut hormones

## Experiments looking at how macronutrient composition affects energy expenditure [38:45]

*To make the experiment more interesting, Peter suggests*

- Introduce a 4th variable which would be the macronutrient composition of the meal itself at isocaloric substitutions

Questions worth answering

- When Peter met Eric, they were interested in a very specific question
- Peter likes specific questions, because the more specific the question, the easier it is to design an experiment to test it and the more likely you are to get an answer that you can interpret as highly probable

**The question we were trying to ask was, under isocaloric conditions does varying the macronutrient composition specifically between carbohydrate and fat while holding protein constant have any bearing on non-deliberate energy expenditure?**

- Isocaloric is the important word

*And can you do that in everyday life not under isocaloric conditions but what you want to eat?*

- Most people felt the answer was known
- If you give an individual meals on subsequent days or weeks where you don’t change the number of calories (or the amount of protein); you simply **manipulate the ratio of carbohydrate to fat** such that when one goes up the other goes down

***The null hypothesis should be that their energy expenditure doesn’t change***

- Why would holding a fixed number of calories in this system change the number of calories that the system expends?
- It’s important that we held protein constant because we know about the thermogenic effect of protein, so that can actually sway things if you change protein a lot
- The **alternative hypothesis** that was being tested was, “*No, actually if you really swing fat and carbohydrate a lot, you could indeed change energy expenditure.*”
  - This was a question and we were a little bit skeptical
- It was the start of the [carbohydrate-insulin model](https://en.wikipedia.org/wiki/Carbohydrate%E2%80%93insulin_model)
- It was a good question
- If Eric had to redesign this study, he would do it differently

**Tell people how the** [**study**](https://pubmed.ncbi.nlm.nih.gov/27385608/) **was done and then tell people what you would do different because this is probably an experiment that might be worth redoing under improved conditions**

- We had the baseline diet: the SAD diet (standard American diet)
- Following this was a low carbohydrate (ketogenic) diet for 4 weeks

![](https://peterattiamd.com/wp-content/uploads/2024/11/f3-ericravussin.png)

**Figure 3. Overview of the study design**. Image credit: [*The American Journal of Clinical Nutrition* 2016](https://www.sciencedirect.com/science/article/pii/S0002916522045440?via%3Dihub)

- The **carbohydrate-insulin model** says that you create an uptake of these substrates from the blood into storage (mostly adipose tissue and maybe some in the liver), and if you deplete energy substrate from circulation, it puts you in a state of semi-starvation
  - Your brain will shut down energy expenditure and increase your appetite
- Now if we switch to a diet which is going to be less conducive to storage ([ketogenic diet] i.e, less insulin secretion because it was less than 10% carbohydrate, between 5 and 10%), we would cause basically this semi-starvation condition in the systemic circulation and this would increase your energy expenditure

*Hypothesis: energy expenditure increases when eating a ketogenic diet*

- At the time, [David Ludwig](https://www.drdavidludwig.com/) already had some data using [doubly labeled water](https://en.wikipedia.org/wiki/Doubly_labeled_water) that there was an increase in energy expenditure
  - But the argument was that doubly labeled water is not precise enough
- They tested it in a metabolic chamber

***To Eric’s surprise, there was an increase in energy expenditure (at least early on)***

![](https://peterattiamd.com/wp-content/uploads/2024/11/f4-ericravussin.png)

**Figure 4. Changes in total daily energy expenditure, sleeping energy expenditure (SEE) and respiratory quotient (RQ)**. Image credit: [*The American Journal of Clinical Nutrition* 2016](https://www.sciencedirect.com/science/article/pii/S0002916522045440?via%3Dihub)

- They tested every week for 2 days for the 4 weeks
- In the 1st and maybe 2nd week there was an increase which was significantly higher in sleeping metabolic rate as well as 24 hour energy expenditure under the ketogenic diet

**The question remains, was it a significant physiological increase?**

- We can argue about that when we talk about metabolic adaptation
- We always say we need at least 150 calories
- In the study, we achieve statistical significance, but it was just above 100 calories per day
  - Eric was surprised of that
- Now we didn’t measure the appetite of the people
  - Were they less hungry under the ketogenic diet?

**It brings us to all the weight loss studies which have been done either with a low-fat diet or low-carbohydrate diet**

- If you do a [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/38125726/), it seems that there is a slight advantage to the ketogenic diet for the weight loss period
- Eric was surprised that there was this effect, but it disappeared at the 3rd and 4th week

**Peter’s summary of this** [**study**](https://pubmed.ncbi.nlm.nih.gov/27385608/)

- This was a very well-designed study in that there were maybe 16 subjects
  - Obviously this sounds like a very small number (and it is), but given the complexity and cost of keeping 16 subjects housed in a hospital for a month and then also putting them in metabolic chambers every few days, this isn’t a study that you’re going to do with 500 patients
- To increase the statistical power of the study, it was a **crossover study** which meant that every patient was their own control and that’s what allows you to get away with having so few subjects

***It’s safe to say that the effect size was large enough that it suggested a signal but not so large that it positively answered the question***

- In many ways it served as fodder for more questions
  - Which is not uncommon in research
  - It’s very rare that one experiment gives you the definitive answer and rather it just points you in a slightly different direction and gives you more questions

**If resources were not a limit, what would be the follow-up experiment to that?**

- Eric wishes he had an answer
- He’s tortured between very well controlled studies
  - Like he does
  - Like what [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin) does, where you know exactly what you feed them and you look at outcomes
- But then how do you transpose that in real life?
- One of Eric’s mentors, [JP Flatt](https://onlinelibrary.wiley.com/doi/full/10.1002/oby.22362) said, “*Obesity scientists, they have a tendency to either look at the expenditure side of the equation or the energy intake, but they never put the two together.*”
- He was right, because a lot of studies you have an outcome which is on this side or on this side and you maintain the other one

***First, his study would be designed in free-living conditions***

- It would need a lot of people
  - You know you can prescribe all you want to people, but at the end of the day, they’re going to do whatever they want
- If you screen participants very carefully, they are going to be much more compliant and adhere to the instruction

*In the* [*study*](https://pubmed.ncbi.nlm.nih.gov/27385608/) *discussed earlier*

- We changed the composition of the 2 diets (not the calories): 10% carbohydrate versus 45-50% carbohydrate
  - We concentrated only on the energy expenditure
- We didn’t ask very much on the visual analog scale if they were more hungry or all these kinds of things
- We kind of ignored the food intake that we were clamping, and this is not real life

***If you do something and you talk about engaging on physical activity regimen or exercise and all that, you have to look at the impact on the other side; and this is the question Eric has***

- We have good tools to **measure energy expenditure**
- We have reasonably good tools to measure where the **calories** come from

**But we have no tools to measure energy intake**

- But it’s going to come
- Within a couple of decades we’ll have a collar which is going to measure your calories coming from fat, carbohydrate, or protein
- Peter thinks we’ll get there as image recognition gets better and better with AI
  - Within a decade, if not less
  - We are at the point where if you can weigh something and take a photograph of it, we should have enough training data that you should be able to know exactly what is in it
- Now that doesn’t account for how much of that thing you eat, but assuming you have something that you weigh and you can photograph and you say, “*I ate all of it or I ate half of it*,” we should be able to do better than 10%
  - We should be able to do within 5% determine the caloric density of that food and the macronutrient breakdown
- 5 years ago, Peter would’ve said that’s impossible, but given what he’s seeing with image recognition in AI, that has to be the future for nutrition research in a free living environment

## The challenges of studying diet in real-life settings, the potential of personalized nutrition, and how public health policy could play a role in guiding nutritional habits [51:00]

**Eric is the PI for 1 of 6 clinical sites for** [**Nutrition for Precision Health**](https://nutritionforprecisionhealth.org/)

- This is an ancillary study of All of Us
- [All of Us](https://allofus.nih.gov/news-events/announcements/nih-launches-largest-precision-nutrition-research-effort-its-kind) is a study of 1 million American who are providing bio samples, access to electronic health records
- This sub-study is to look at the intersection between their health and their nutrition
- There are 3 modules
- 1 – In 10,000 people a little camera sitting on your glasses will measure exactly what you’re eating; there is also a system which is measuring if you are chewing or not
  - It’s not enough to see the food going in, but is it chewed?
  - Eric agrees with Peter about tracking food intake, but he was thinking about something much more like a [CGM](https://en.wikipedia.org/wiki/Continuous_glucose_monitor)
- Who was dreaming of CGM 30 years ago when he was working with the Pima Indians?
  - We were not thinking about that
  - Now you have CGM and you can measure probably your insulin from contact lenses and things like that
  - This progress are going to help us
- Eric asks, “*Now are we going to be smarter designing the study? I’m not so sure, but we’ll have the tools to be a little bit more real life rather than incarceration in a metabolic ward.*”
- Peter’s intuition is that the questions are complicated enough that the difference between **efficacy** and **effectiveness** have to be separated in studies

**The question of isocaloric macronutrient manipulation impacting energy expenditure is to be put to rest**

- It can only answer that question
- It cannot attempt to answer the impact of **appetite** as a movable variable
- It can do it as a swing variable, meaning as you said, you can force people to eat a clamped amount of food and then measure subjectively or even using [PYY](https://en.wikipedia.org/wiki/Peptide_YY) and [ghrelin](https://en.wikipedia.org/wiki/Ghrelin) and other hormones
  - So somewhat objectively, somewhat subjectively measure the appetitive response to that

**What Peter thinks was the biggest mistake of the previous** [**study**](https://pubmed.ncbi.nlm.nih.gov/27385608/)

- Not creating a big enough divide in the macronutrients
  - As an efficacy study that was testing a theory
- In retrospect, it should have been more extreme in the carbohydrate and fat differences
  - If the carbohydrate-insulin model was being tested, one should have been a very, very, very high insulin diet and a very, very low insulin diet that were isocaloric
- Let’s assume you do that experiment and you get a difference of 250 kcal a day
- You still don’t know if a ketogenic diet is a better diet in a free living environment because you’re probably not comparing it to somebody who’s eating 80% carbohydrates
- So then you still have to do the next experiment, which is maybe the one we did
- And then ultimately you have to be able to do the free living experiment where people make their own choices based on appetite
- That has to be sequenced to answer the questions
- These are difficult and costly experiments to do

**One thing on Eric’s mind: all the studies from Europe about modulating the composition of the diet, looking at the impact on the matching of oxidation to the intake**

- Even [Steve Smith](https://www.adventhealthresearchinstitute.com/team/steven-smith) did this study called [ADAPT](https://pubmed.ncbi.nlm.nih.gov/16007256/)
- The [study](https://pubmed.ncbi.nlm.nih.gov/27385608/) he did with Eric was isocaloric all across, but all of a sudden you continue with more fat, the FQ (food quotient) of the diet was decreased
  - Then it takes days to basically have a matching of your RQ to the FQ, which means you oxidize what you eat
  - Whereas if you do the contrary, you increase carbohydrate ‒ it takes 1 day [to match the RQ to the FQ]
- Back in Switzerland, Eric did this [study](https://pubmed.ncbi.nlm.nih.gov/3900133/) where we were giving extra fat as LCT, long-chain triglyceride or MCT (because the MCTs are oxidized quicker)
  - ***We found that the culprit is always the fat***
- We are very good at matching carbohydrate oxidation to carbohydrate intake
  - It’s very difficult
  - First of all, you have about 500 grams of glycogen stores: 100 in the liver and 300-500 in the muscle
  - It means if you have a lot of carbohydrate, that’s a huge signal
- It’s the same thing for protein
  - You know how difficult it is to build up your muscle mass or your protein mass in the body by just eating more protein
  - You have to exercise or you have to take anabolic steroids or whatever

***The fat is the one which is not regulated, and that’s why Eric has this problem with the carbohydrate-insulin model***

- A ketogenic diet seems to work better for weight loss than a low fat diet
  - Let’s say there was a slight increase in energy expenditure
- But this diet in your entire life, Eric doesn’t think it works
  - And piling the fat
- Peter ate a ketogenic diet for 3 years

**Peter intuition is that there’s so much heterogeneity between individuals, both genetically and environmentally, that we have to release our agenda from this idea that there is a perfect diet for everyone**

- Even though it sounds like a cop-out and he hates it when people say it
- Nevermind health, even when it comes to weight maintenance
- Let’s pick a simpler variable, which is nothing but a subset of health: weight maintenance as one piece of the health puzzle

Peter explains, “*It strikes me as impossible to suggest that there is a true diet that is good for everybody. I think that again, based on the person’s genetics and their own living evolution, i.e, their epigenetics and their environment and other factors, psychological factors, which of course can be quite genetic.*”

**Peter’s view on dieting**

- There are either several or few dietary options that are easiest for a person to adhere to, to maintain weight balance
- Carbohydrate restriction, especially extreme carbohydrate restriction happens to be one of the more efficacious ways for individuals to restrict something in the larger service of restricting calories
- Because at the end of the day, whatever you choose to restrict, whether it be certain macronutrients, alcohol, the time during which you allow yourself to eat or just directly the number of calories, ***some form of restriction is necessary for weight balance*** in an infinite food environment
- This is the environment we have now found ourselves living in for the past 0.01% of our genetic existence as a species

> “*It’s a very new problem that we have to be so surrounded by infinite nutrition and therefore it requires some degree of restriction, and you just have to pick your poison.*”‒ Peter Attia

- You can directly restrict calories
- You can restrict the timing in which you eat (time restriction)
- You can pick some boogeymen within the diet and say they’re the bad guys
  - Fat or animal protein or whatever
  - If you do that enough, you’re also going to restrict energy intake

**In this era of precision medicine or personalized medicine**

- This is what the NIH is embarking on when they do this [Nutrition for Precision Health](https://nutritionforprecisionhealth.org/), when they study molecular transducers of physical activity to look at in lieu of your genetic background, your environment, your socio-economical status

***One size does not fit all***

Eric explains, “*We have the dietary guidelines. They are applied for the entire nation and they tell you every time it’s* [*Mediterranean diet*](https://en.wikipedia.org/wiki/Mediterranean_diet) *or the* [*DASH diet*](https://en.wikipedia.org/wiki/DASH_diet)*, which are the best and all these kind of things, but not for all.*”

- This is where we are going to have a huge development
- Eric doesn’t think it’s going to be individualized

***Instead, groups of people will have the same different strategies and restriction has to be one of that***

**But now how do you restrict?**

- Do you restrict by public policies by taxing things?
- Peter feels strongly against that
  - He doesn’t think long-term compliance and trust on the part of the public will come through that type of environment

***One answer is better education ‒ better advocacy and education from the scientific and medical community***

- To explain, “*Hey, you’re not broken, you’re not defective, but you might be one of the people for whom the average approach is not going to work. But step one is every one of us needs to accept that in exchange for living in the greatest period of civilization, which is where we all live… Different people will have to do a greater amount of restriction.*”
- None of us would trade places with the King of France or the King of England 500 years ago
  - Peter would rather be the most average human being in 2024 than the single most important person in 1400
- So we just have to accept the fact that we are all so shockingly privileged to be alive at this moment
- But that privilege comes with a couple of expenses, comes with some costs, and one of the costs is we live in an environment that has a little bit of toxicity with respect to things like food
- And we have to pay a price

***We’re going to have to make a trade-off and a restriction***

**Step #1 – different people will have to do a greater amount of restriction**

- Not everybody has the same IQ
- Not everybody has the same athleticism
- Not everybody has the same emotional intelligence
- And not everybody has the same metabolism
- Some people just have to be somewhat mindful of what they eat and the cards fall into place
  - Barely think about anything, and it all works out
  - That’s Peter’s wife
- You get people in the middle who have to think about it every day
  - Not crazy, but can’t eat on autopilot
  - That’s Peter
- There are people who are even further where they have to be very mindful and restrictive of what they eat in lieu of potentially using drugs like [GLP-1 agonists](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist)

**Step #2 – we need technological breakthrough that allow people to become their own laboratory animals**

- This goes to Eric’s point about personalized precision nutrition
- This would allow people in the real world (in a free-living environment) to do the empirical stuff they’re talking about
  - To test the hypotheses, how much fat and protein and carbohydrate should one be eating to optimize their appetite?
    - To optimize and regulate appetite and energy expenditure
- We don’t have the tool that allows the person to do that test with any degree of accuracy
- That has to be the direction we go in, as opposed to continuing to try to answer the what is the best diet question (a futile question)

**When you say the word “diet,” people think weight loss**

- They think some miracle is going to happen to them
- In this new [study](https://nutritionforprecisionhealth.org/) Eric is a part of, it aims to know what you eat in relationship with your health and your genetic makeup and your environment and all these kinds of things

**Back to public health policies**

- Eric is pessimistic, he always says education is a major cornerstone, but we are also going to need public health policies
- It’s been done with [trans fat](https://en.wikipedia.org/wiki/Trans_fat)
- It’s being done now in South America with a black label on ultra processed food
- Peter is not opposed to labeling things
- He worries about excise taxes on things, although he does support excise taxes on tobacco
  - He thinks alcohol and tobacco should be taxed to cover their consequences on the back end
  - Maybe he needs to revisit his thinking on this
- Peter has lost faith in the government to determine on the margin what’s healthy and what’s not healthy
  - Is butter healthy or not healthy?
  - Should butter be taxed disproportionately relative to bread?

**Eric thinks the government should work very closely with the nutrition companies**

- The nutrition companies have been masters at doing 2 things: produce very palatable and very cheap food
- Eric remembers [John Blundell](https://medicinehealth.leeds.ac.uk/psychology/staff/1183/professor-john-blundell-) saying, “*Those are the two things that people don’t compromise on. It is to be tasty. They need to enjoy it and it needs to be cheap*.”
- This is what we have now: a lot of added sugar, a lot of fat, and it’s very delicious
- We have to reverse some of that, and Eric thinks that now we know enough about that
- He was at a conference a month ago in Sao Paulo, [the International Congress of Obesity](https://www.worldobesity.org/training-and-events/events/international-congress-on-obesity), and they have been very, very active in South America when it comes to ultra-processed food
- Eric was impressed to see even the protein content of all the ultra-processed food is on the side of 12-13%
- Whereas we need something between 15-18%
  - And if you believe in the [protein leverage theory](https://pubmed.ncbi.nlm.nih.gov/31339001/#:~:text=This%20model%2C%20called%20protein%20leverage,a%20high%20proportion%20of%20protein.), this is an important factor

## The importance of protein in the diet, the limitations of dietary data collection, and how AI could potentially transform nutrition science [1:08:15]

**Tell folks what the protein leverage theory is**

- Peter doesn’t think there’s any one theory, it’s an amalgamation of theory; but he thinks there’s some validity to it

***In simple words, we eat for a given amount of protein, which is proportional to our body size***

- Eric remembers when he was studying, we were saying during a low calorie diet, you need 1.2 gram of protein per kilogram of body weight
- But the experiment started with insects and then they went in rodents, and they manipulated the content of protein of the diet and they found out that basically the intake was all to gravitate around a protein content which was sufficient for the weight of the animal
- And this is called the protein leverage theory

**Now Eric is a little bit more skeptical when** [**Simpson**](https://www.sydney.edu.au/science/about/our-people/academic-staff/stephen-simpson.html#collapseprofileresearchinterest) **and the two guys in Australia are saying the pandemic of obesity has been paralleled by a decrease in the protein content of the diet, and this is what has triggered the increased caloric intake to get the same amount of protein**

- They’re arguing that protein density within food has gone down (especially in processed foods), so people are seeking more calories to subconsciously get more protein
- Peter has reviewed these data in huge detail for a previous podcast [[AMA #62](https://peterattiamd.com/ama62/)]
  - The data from rodents is staggeringly compelling; it’s unambiguous
    - A rodent will consume to its level of protein in the studies where this has been tested, even if it means eating way more calories
- Peter thinks humans must be more complicated because the human literature isn’t quite as clear
- Eric points out that you can feed rodents whatever you want; with people, you don’t
- He remembers [Dr. George Bray](https://www.pbrc.edu/research-and-faculty/emeritus/bray-george-MD.aspx) saying, “*This dietary recall [food frequency questionnaires] are not worth the paper on which you write the data*.” (Peter agrees)

**This is where we lack tools; we need better ways of measuring what people eat and what is the content of their meal and all these kinds of things**

- And that’s why it’s so easy to do that in rodents because you feed them with this or these 3 diets or 5 diets and you look at how much they eat, you weigh the food and the calories
- Peter points out that [John Ioannidis](https://profiles.stanford.edu/john-ioannidis) has famously said that the food frequency questionnaire belongs in the wastebasket
- Yet the food frequency questionnaire is the backbone, is the scaffolding of nutritional epidemiology

**Do you as an experimental scientist, have concern at how much food policy is being driven by nutritional epidemiology, rather than experimental science**

- We understand why there’s an effort around nutritional epidemiology because these questions are otherwise difficult to answer
- Given the fidelity of the data, i.e. the thing you put in the system to calculate, isn’t worth the paper it’s written on according to basically anybody who understands how it works

*How do we reconcile this problem?*

*The role of ultra-processed food?*

- Those are determinations from epidemiology
- Epidemiology is hinting to us that ultra-processed foods on balance are bad
  - That confirms what most people would intuit

*Where do we draw the line between what we are letting nutritional epidemiology tell us from a health policy perspective to where maybe it’s overstepping and getting things wrong because of the data integrity problem?*

- Eric thinks the problem is jumping from nutritional epidemiology to policies or labeling or dietary guidelines

***We are now at a point that the epidemiology should provide us with hypotheses to be tested in better controlled situations and maybe in domiciled with full feeding of people***

**These studies are expensive, but we’re missing a step**

- Again, these new studies from NIH, this consortia of [Nutrition for Precision Health](https://nutritionforprecisionhealth.org/), are going towards this direction
- Eric explains, “*You are right, the food frequency questionnaire is here every day for 10 days in this module one of the study. But then there are these other ways. There is the remote photography system that you take a picture with your phone of the plates, you have these cameras and all that*.”

***Eric hopes that we’re not going to make policy or guidelines only based on nutritional epidemiology, but also on studies basically testing some hypothesis related to what the nutrition epidemiology has shown***

**Peter thinks all roads, both from a personal health perspective and from a nutrition science perspective, need to point towards AI**

- AI is valuable for a lot of the unsexy stuff: image recognition and radiology, insurance, billing, reconciliation, and this.
- In biomedical research, the ability of AI to predict protein folding is truly magnificent
  - That will absolutely shave some time and money off drug discovery
- In nutrition science, could AI solve this “simple problem” (simple conceptually not technically) that has vexed us for hundreds of years?
- Peter hopes somebody out there who’s got serious AI chops is listening to this and thinking this is an area to pursue

## How Eric’s interest in caloric restriction (CR) began with Biosphere 2, metabolic efficiency’s role in aging, and goals of the CALERIE study [1:15:15]

- Eric was 1 of 4 PIs on the [CALERIE stud](https://calerie.duke.edu/)y who drove the write-up and design of the study

> “*It was funded by the National Institute on Aging and it was really the first attempt to look at the impact of caloric restriction on biomarkers of aging.*”‒ Eric Ravussin

- There’s still a lot of discussion around what the **biomarkers of aging** are
  - Your fasting insulin going up with life
  - Your VO2 max going down
  - It’s not your gray hair, lack of hair, or these kinds of things
  - You have some more sophisticated protein [glycation](https://en.wikipedia.org/wiki/Glycation) and production of [isoprostane](https://en.wikipedia.org/wiki/Isoprostane) and all that

Peter asks, “*How much banked serum do you still have that is available for analysis in 5 years or 10 years, when better and better tools or biomarkers become available? Has it all been spoken for and has it all been tested or are there still some banked samples?*”

- There is a [CALERIE Legacy Study](https://ctv.veeva.com/study/the-calerie-legacy-study), a follow-up of these people
- There is also a a [biorepository](https://calerie.duke.edu/biorepository) of all the plasma samples, muscle biopsies, fat biopsies at Duke, which was the coordinating center
  - The PI of that is [Bill Krauss](https://dmpi.duke.edu/william-kraus-md), he’s a cardiologist at Duke
- Another colleague, [Deep Dixit](https://medicine.yale.edu/profile/vishwa-dixit/) at Yale has mined the transcriptomes form adipose tissue of participants in the CALERIE study and just published a paper in [*Science*](https://pubmed.ncbi.nlm.nih.gov/35143297/) on this
  - He found a gene [[*Pla2g7*](https://en.wikipedia.org/wiki/Lipoprotein-associated_phospholipase_A2)] which is related to the immune function
  - And if you knock out this gene in mice, they are resistant to weight gain ‒  this is like a calorie restriction mimetic and they improve the immune function

***The goldmine of these studies is really to be able to bank biosamples***

**Eric became interested in caloric restriction because of** [**Biosphere 2**](https://biosphere2.org/)

![](https://peterattiamd.com/wp-content/uploads/2024/11/f5-ericravussin.png)

**Figure 5. Exterior of Biosphere 2**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Biosphere_2)

- It was a glass and steel structure southeast of Phoenix (in between Phoenix and Tucson), and 8 people went into this biosphere
- It was about 3 acres and had 7 different biomes: desert, marsh, ocean, agriculture…
- It’s called Biosphere 2 because biosphere 1 is the earth
- Among the 8 people that entered was a faculty from UCLA, [Roy Walford](https://senate.universityofcalifornia.edu/_files/inmemoriam/html/roywalford.htm), who wrote the [textbook](https://www.amazon.com/Retardation-Aging-Disease-Dietary-Restriction/dp/0398054967) with [Rick Weindruch](https://experts.news.wisc.edu/experts/richard-weindruch) on caloric restriction
- While they were in the biosphere, Roy called Eric about doing measurements of energy expenditure
- Eric [measured](https://pubmed.ncbi.nlm.nih.gov/11010936/) their free-living energy expenditure using [doubly labeled water](https://en.wikipedia.org/wiki/Doubly_labeled_water)
- These people stayed in Biosphere 2 for 8 years (from 1991-1993)
- Roy Walford was a physician of the group, but he was very, very interested in caloric restriction
- Things went south ‒ the agriculture, they had pests, they couldn’t control some of the insects, they had goats dying and very quickly they didn’t have enough food and they lost on average 15% of their weight
- None of them except one was maybe a BMI of 26 or 27
  - They were all between 20 and 25
- They became calorie restricted, and you had the guy who was writing the textbook on calorie restriction being the physician in the Biosphere 2
- Eric and Roy started to collaborate, and then when this RFA came out in the early 2000 from the NRA (request for application grant), immediately Eric called Roy about the study they did on energy expenditure
- 5 of them came and stayed in the chamber for 1 day, right when they came out of the biosphere
- Eric asked Roy to be a consultant and to write a grant which was going to be competitive in aging research (he accepted)

Peter asked, “W*hat did you find of their energy expenditure when they were in the chamber?*”

- It was very low because of their caloric restriction
- We had to compare to a group of 72 people
- They were about 200 calories below what you would expect for their weight and body composition
- The 5 of them that came back 6 months after leaving Biosphere 2 had regained their weight
  - They were a normal weight and their energy expenditure normalized [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2024/11/f6-ericravussin.png)

**Figure 6. Body weight and energy expenditure 1 week and 6 months after exit from Biosphere 2 compared to 152 control subjects (\******P*** **< 0.05, \*\******P*** **< 0.01)**. Image credit: [*The American Journal of Clinical Nutrition* 2000](https://ajcn.nutrition.org/article/S0002-9165(23)06805-3/fulltext)

**Roy passed away prematurely**

- He blamed it on Biosphere a little bit because they were supposed to be totally independent except for light from the rest of the world
- But a few times they had to purge CO2 and influx O2, but he said there was probably gasses
- Eric doesn’t know how true it was, but he said that he was intoxicated by gas in the biosphere

**Roy and Eric’s grant to test caloric restriction (CR)**

- Eric was convinced of the [benefits of CR](https://pubmed.ncbi.nlm.nih.gov/20518700/) by 2 things
- 1 – [The rate of living theory](https://en.wikipedia.org/wiki/Rate-of-living_theory): the higher your metabolism the shorter your life
  - The elephant has a very low metabolism per unit of tissue compared to a shrew
- 2 – [Oxidative stress](https://en.wikipedia.org/wiki/Oxidative_stress) theories
- Eric and Roy brainstormed for 3-4 days to write a 7-year grant
- The 1st 2 years you show that you can recruit people and maintain them in calorie restriction
  - They can be overweight but not obese
- The second is to design a two-year intervention

*The first study was basically to test if caloric restriction would decrease your energy metabolism more than what you would expect on the basis of the body weight*

- In other words, do you become more efficient?

***The answer is yes, the metabolism of non-obese people become more efficient after CR***

**Metabolic adaptation where energy metabolism becomes more efficient**

- This sounds like a good thing, but it’s not when it comes to **weight maintenance** (it’s the exact opposite)
  - In an ideal world, you want to be the most inefficient consumer of calories
- Eric did efficiency [studies of athletes](https://pubmed.ncbi.nlm.nih.gov/1996628/) to ask if they have a more efficient resting metabolic rate and therefore can have more energy for exercise
- You cannot win both sides
  - You are better at controlling your weight when you are a little bit more inefficient
  - But you have less **performance** when you are more inefficient

*Eric’s takeaways*

- 1 – Potentially energy efficiency can be very good for longevity
  - The [Baltimore Longitudinal Study](https://www.blsa.nih.gov/) [showed](https://pubmed.ncbi.nlm.nih.gov/18693224/) that some people with lower metabolic rate were living longer
- 2 – On the other hand, energy efficiency is a liability for weight gain, for example, because you are more efficient and you are more prone to weight gain
- It’s a balance between the two

***Eric think’s there is no right answer, but having a high metabolic rate can be a liability because associated with a generation of ATP is the production of*** [***reactive oxygen species***](https://en.wikipedia.org/wiki/Reactive_oxygen_species)

- In other words, the efficiency of the transfer of oxygen into ATP is not perfect and sometimes you have some reactive oxygen species being generated by the mitochondria, and these reactive oxygen species can damage not only your DNA but your protein, your lipids and so on
- This is **one theory of aging**: too many reactive oxygen species and therefore a higher degree of [oxidative stress](https://en.wikipedia.org/wiki/Oxidative_stress)

## The CALERIE study: exploring the real-world impact of caloric restriction [1:28:00]

**The first part of our CALERIE study [phase 1 at Pennington]**

- It was a [6-month intervention](https://pubmed.ncbi.nlm.nih.gov/16595757) consisting of 4 groups
  - 1 – An ad libitum group
  - 2 – 25% caloric restriction
  - 3 – 25% energy deficient, but half by caloric restriction (12.5%) and half by increasing energy expenditure by exercise
  - 4 – The last group was weight loss, 10% with a very low calorie diet and maintenance of this weight loss
    - It means you are in calorie restriction compared to that baseline
    - This was the only group where the target was weight reduction
    - Groups 1-3 used a target of energy intake and/or energy expenditure
- Peter thinks this sounds like a brilliant experiment, but he wonders how Eric ever did this
  - Those are seismic changes to take a 100 kilo person down to 90 kilos (a 190 pound person is going to be 170 pounds when that experiment is done)
    - That’s meaningful
  - The caloric restriction of 25% is enormous one way or the other
  - You’re doing this in the real world over years

Peter asks, “*How did you think about tools for compliance to see that you could hit even close to those targets?*”

- It was a lot of work with our psychology group who insisted that they [screen](https://pubmed.ncbi.nlm.nih.gov/22981898/) the people
  - Screen them for bias to the intervention for adherence and so on
- If Eric recalls correctly, for the 2-year study, they screened more than 5,000 people to enroll 225
  - 5% of the people screened were included in the study
- There was web screening, telephone screening, in-person screening visit
  - There were 5 screening visits to make sure that they show up
  - If they don’t show up for the screening visit, forget them

**In the first** [**study**](https://pubmed.ncbi.nlm.nih.gov/16595757/) **published in** ***JAMA*****, we did find that there was metabolic adaptation or you become more efficient, and we had also some indication of less oxidative stress**

- We did what we call a **comet assay**
  - You look at damage of DNA in nucleated blood cells and we measure isoprostane and all that

**Three study sites for phase 1 of the CALERIE study**

- 1 – Washington University with [John Holloszy](https://medicine.wustl.edu/news/obituary-john-o-holloszy-former-director-of-applied-physiology-85/)
- 2 – Tufts in Boston with [Susan Roberts](https://internationalweightcontrolregistry.org/about/people/susan-b-roberts-phd/)
- 3 – Eric in [Baton Rouge](https://calerie.pbrc.edu/index.html)
- Eric’s [preliminary study](https://pubmed.ncbi.nlm.nih.gov/16595757) was 6 months and theirs were 1 year
  - [publications listed in the “Selected Links” section at the end of these notes]

![](https://peterattiamd.com/wp-content/uploads/2024/11/f7-ericravussin.png)

**Figure 7. Three sites where phase 1 of the CALERIE study was completed and percent CR studied**. Image credit: [*Antioxidants & Redox Signaling* 2011](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3014770/)

- After 2 years when we analyzed the data and all that, we started to design the study which was going to be the same for the 3 sites [for the phase 2 CALERIE study]
  - [publications on design of the phase 2 study listed in the “Selected Links” section at the end of these notes]

Peter asks, “*Was the only difference in the short study the duration of the study and the sample size to just confirm the technical doings of the study?*”

- No, they were all different
- Eric insisted on having these 4 groups ourselves in the preliminary study
- Boston had only 2 groups: low glycemic index versus higher glycemic index in the diet of the caloric restriction
- WashU, Eric doesn’t remember the details, but there was a component of physical activity in their study
  - [John Holloszy](https://medicine.wustl.edu/news/obituary-john-o-holloszy-former-director-of-applied-physiology-85/) was a biochemist of exercise and all that
- After that, we compared our endpoints and our intervention, and we designed the study
- The [RFA](https://www.investopedia.com/terms/r/request-for-application.asp) was specifying that they have to be non-obese
- In Eric’s preliminary study, we didn’t want to go because of this 10% weight loss
  - If you start with a BMI of 26, you are 70 kilos (154 lbs.) and you have to lose 7 kilos (15 lbs.), you become thin
  - We decided about the range of BMI and we decided for the study to go from 22 to 27.9 of BMI for admission (means normal weight)
  - We knew that they were going to lose at least 10% and therefore you cannot take somebody with a BMI of 20 to start with
    - You would have problems with bone mineral density and may have safety concerns
- They used men and women

Peter asks, “*How long did they have to lose the 10% body weight?*”

- This wasn’t specified in the final protocol, but in the preliminary protocol, it was over 3 months
- It was a low-calorie liquid diet, around 800 calories per day, provided by Pennington
  - But we could do muffins and things
  - It’s called the [Health One diet](https://hnthealth.com/), and it’s still on the market
- In the 2-year study, they agreed to do the rate of living/oxidative stress **first end point**

**The subjects**

- Age 21-47 for women and 55 for men
- BMI 22-28
- And then going through a lot of screening to make sure that they were going to stick with u
- We randomized 2 to 25% caloric restriction for every 1 to [ad libitum](https://en.wikipedia.org/wiki/Ad_libitum#:~:text=In%20biology%20and%20nutrition%2C%20the%20phrase%20is%20used%20to%20describe%20feeding%20without%20restriction)
- We had 95% completion in the ad libitum group and 85% in the calorie restriction
- Eric explains, “*It’s amazing for a two-year study. And the retention was spectacular.*”
- Unlike the preliminary study we did in which we fed them entirely, they came to Pennington to basically learn how to cook whatever diet they wanted
  - It could be a low-fat diet, a low-carbohydrate diet, a Mediterranean diet

**In the CR group the target was 25% CR**

- It was based on 2 measurements of doubly labeled water
- The average energy requirement was 2,400
- It means on average they were cut by a little bit more than 500-600 calories for 2 years
- In the first 3 months, they could come whenever they wanted to learn to cook, and they were also provided some of the meal if they needed to

**End points**

- After that we had a lot of measurements about resting metabolic rate, about oxidative stress
- The end points were really the first [RMR](https://en.wikipedia.org/wiki/Resting_metabolic_rate), the second [ROS](https://en.wikipedia.org/wiki/Reactive_oxygen_species) formation
- After that, it was CVD markers, it was insulin sensitivity, immune function, neuroendocrine parameters, quality of life, and cognitive function

**What was the average percent weight loss of the individuals in the treatment group?**

- At 1 year, the average was 12%
- At 2 years, it was 10.4%

![](https://peterattiamd.com/wp-content/uploads/2024/11/f8-ericravussin-505x1024.jpeg)

**Figure 8. Caloric restriction (% CR) and weight change over 24 months of the CALERIE study**. Image credit: [*The Journals of Gerontology Series A* 2015](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4841173/)

- The caloric restriction was estimated by [doubly labeled water](https://en.wikipedia.org/wiki/Doubly_labeled_water), it’s called the **intake-balance method**
  - You measure energy expenditure, you measure change in body composition
- We had about almost 20% of CR for the first 6 months and this is where the weight was lost [shown in the figure above]
- After that, that CR started to decrease to close to 15% at 1 year
- Then at the end of the 2 years, the overall CR was 12.5%

***The amount of CR achieved was about half of what they were asking for (not bad)***

**What was the budget for just the Pennington part of this?**

*Meaning the preparation, planning, the study, analysis for the first publications, etc.*

- Eric’s original grant was 10.4 million and it was in 2003
- After that, because we were recruiting so well, they asked us to boost up our recruitment and they gave us another million and a half

***Close to $13 million in total costs (including indirect costs)***

- Peter applies a little inflation to say that’s $20 million in today’s dollars

*Peter puts this figure in perspective*

- That sounds like a lot of money, but when you think about the fact that the NIH budget is on the order of $35 billion for both intra and extramural
- And the extramural budget (of which this was part of) is on the order of $28 billion
- $20 million on a $28 billion budget is a drop in the bucket
  - It’s less than a 10th of a percent
- And yet this is a very important question

> “*I think it’s the single best study that’s even attempted to look at the effects of caloric restriction in a free-living environment.*”‒ Peter Attia

- Peter think’s Eric’s recruiting was exceptional an their hands-on ability to work with the subjects longitudinally is what made the difference
  - Eric’s group did all the unsexy stuff so well, and that’s why they got something so remarkable
- As they talk about the results, Peter worries that the NIH is funding some stuff that’s not that interesting and relevant compared to the jugular questions of human health
- In Peter’s view, this is a great example of the kind of work that should be getting much more funding

## Notable findings from the CALERIE study after two years: sustained weight loss, participant retention, and more [1:40:00]

**Notable findings aside from weight loss was the amazing retention rate**

- Peter thinks it can’t be pleasant to be that calorically restricted for 2 years

Peter asks, “*What did the subjects tell you? Why did they stay in this study?*”

- Eric is now following up with these people studied from 2005-2008, and they are part of this [CALERIE legacy study](https://ctv.veeva.com/study/the-calerie-legacy-study)
- They built a team between the investigators and the study coordinators and study managers and all that and the people
- They also provided the study volunteers with some of the results
  - Normally you don’t do this, but it wasn’t going to change their behavior to tell them about their total cholesterol or body composition
- Study volunteers loved seeing their DEXA scan results
  - Percent body fat went from 15 to 12 on one guy
- They had a Mardis Gras with the volunteers
- Every 2 months they had a reception
- They sent out postcards for birthdays

***All these kinds of things are part of the retention and building a team between the investigators and study volunteers***

- The screening was essential
- Eric remembers the first person they randomized, she ended up in the ad-lib group
  - She came to his office and said in tears, “*I want to do this study because I have read about what it does to your metabolic health, to your cholesterol, to your body composition, and I’m in the control group.*”
  - He explained they were going to give her the data and afterward they will offer her help with caloric restriction
- 2 years later they still see the study volunteers, but not on a regular basis like during the study

**What improved with CR?**

*Talk about the changes in markers of insulin sensitivity and body composition*

- Peter is also very curious about the subjective markers of satisfaction because most people would say, “*Look, if you told me I have to restrict my calories by 20 or 25%, there’s no amount of benefit to my health that could justify the unhappiness and unpleasantness of that experience.*”

*Where were they psychologically as that trial progressed into its second year?*

- There was a lot of press around the study at the time it was done, and most of the people liked to be part of a key study
- The second thing was really building this relationship between the investigators and the study volunteers and also the return of results and the sharing of experience with other people
- In terms of **suffering with hunger**: for most people after 1 month it was totally manageable

***We taught them to increase the volume and decrease the fat content to satisfy on a volumetric basis how much food they were eating with less fat and less calorie density in the diet (against the ketogenic diet here)***

**Do you have a sense of how their macronutrients shifted?**

- This is [published](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9052419/)

![](https://peterattiamd.com/wp-content/uploads/2024/11/f9-ericravussin.png)

**Figure 9. Diet macronutrient composition from the CALERIE trials**. Image credit: [*Expert Review of Endocrinology & Metabolism* 2021](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9052419/)

- Eric doesn’t remember exactly if there was a clear-cut impact of being in the caloric restriction group versus the ad-lib group
- Surprisingly, there are some people that did not regain all the weight, after more than 15 years (a lot of them)
  - They are still using what they learned during those 2 years

*When was the last time you took blood, gathering any sort of data on those people besides weight?*

*In other words, is there any way to infer whether 2 years of caloric restriction 20 years ago had any lasting difference relative to the controls?*

- The [Legacy Study](https://ctv.veeva.com/study/the-calerie-legacy-study) is targeting all the people; Eric is not sure how many
  - [Dr. Redman](https://www.pbrc.edu/research-and-faculty/faculty/Redman-Leanne-PhD.aspx) is the PI
- We don’t have the results yet; this study is ongoing now
- They did a 6-month [follow-up study](https://pubmed.ncbi.nlm.nih.gov/28275127/) at Pennington: it was a game changer for their lifestyle for these people
  - [Eric confirmed via email that he was referring to a follow-up of the phase 2 CALERIE study, 2 years later. There was not a formal follow-up of the 6-month intervention that was the phase 1 CALERIE study]

## The effect of caloric restriction on the hallmarks of aging [1:47:00]

**What do you think from an anti-aging perspective were the most important biomarkers that changed?**

*For example, did you do* [*OGTTs*](https://en.wikipedia.org/wiki/Glucose_tolerance_test#:~:text=oral%20glucose%20tolerance%20test%20(OGTT)) *or euglycemic clamps?*

- They didn’t do clamps

*There are 2 kinds of aging*

- 1 – **Primary aging**: senescence or mitochondrial dysfunction, leaky membrane
- 2 – **Secondary aging**: the impact of your environment and your lifestyle
  - Insulin sensitivity or cardiovascular factors are secondary aging
  - They did a lot of measures
- [Bill Kraus](https://dmpi.duke.edu/william-kraus-md) published a [study](https://pubmed.ncbi.nlm.nih.gov/31303390/) on the cardiometabolic risk factors, and everything was tremendously improved despite the fact that these people were healthy to begin with
  - BMI 22 to 27.9 and so on
  - Remarkable improvement in all these markers of secondary aging

![](https://peterattiamd.com/wp-content/uploads/2024/11/f10-A-ericravussin.png)

**Figure 10-A. Change in cardiometabolic risk factors after CR**. Image credit: [*The Lancet Diabetes & Endocrinology* 2019](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6707879/)

![](https://peterattiamd.com/wp-content/uploads/2024/11/f10-B-ericravussin.png)

**Figure 10-B. Change in cardiometabolic risk factors after CR**. Image credit: [*The Lancet Diabetes & Endocrinology* 2019](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6707879/)

![](https://peterattiamd.com/wp-content/uploads/2024/11/f10-C-ericravussin.png)

**Figure 10-C. Change in cardiometabolic risk factors after CR**. Image credit: [*The Lancet Diabetes & Endocrinology* 2019](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6707879/)

![](https://peterattiamd.com/wp-content/uploads/2024/11/f10-D-ericravussin.png)

**Figure 10-D. Change in cardiometabolic risk factors after CR**. Image credit: [*The Lancet Diabetes & Endocrinology* 2019](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6707879/)

![](https://peterattiamd.com/wp-content/uploads/2024/11/f10-E-ericravussin.png)

**Figure 10-E. Change in cardiometabolic risk factors after CR**. Image credit: [*The Lancet Diabetes & Endocrinology* 2019](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6707879/)

![](https://peterattiamd.com/wp-content/uploads/2024/11/f10-F-ericravussin.png)

**Figure 10-F. Change in cardiometabolic risk factors after CR**. Image credit: [*The Lancet Diabetes & Endocrinology* 2019](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6707879/)

- When it comes to **primary aging**, that’s a different story because it’s much more difficult to measure autophagy, to measure mitochondrial function, to measure leakiness of a cell membrane in these people
- What we ended up to measuring was really some of these hallmarks of aging [shown in the figure below]
  - You’ve probably seen the papers, one was published in 2012 [actually in [2013](https://pubmed.ncbi.nlm.nih.gov/23746838/)] and another 10 years later [[2023](https://pubmed.ncbi.nlm.nih.gov/36599349/)]

![](https://peterattiamd.com/wp-content/uploads/2024/11/f11-ericravussin.png)

**Figure 11. 12 hallmarks of aging**. Image credit: [*Cell* 2023](https://pubmed.ncbi.nlm.nih.gov/36599349/)

- We measured mitochondrial biogenesis by looking at the relationship between nuclear markers and mitochondrial DNA
  - We observed in humans an increase in mitochondrial biogenesis
- Despite the fact that you use less energy, you become more efficient, you increase your biogenesis of mitochondria
  - Which is quite spectacular because the [ROS](https://en.wikipedia.org/wiki/Reactive_oxygen_species) production or these reactive oxygen species are produced by older mitochondria
  - The new mitochondria are much more efficient; they don’t produce as many ROS

***People in the CR group had a greater turnover of mitochondria in their skeletal muscle***

**Peter’s takeaway**:

- We would expect that people who were calorically restricted would have lower ROS generation
- The reason we would expect for that is lower substrate utilization
- You are saying this might be due to increased mitochondrial biogenesis and simply they were using newer machinery for substrate utilization

**Could it be that both of those things are reducing ROS?**

- Absolutely, Eric think’s it’s both
- When it comes to [mitophagy](https://en.wikipedia.org/wiki/Mitophagy), these old mitochondria, this is improved with CR
  - It’s been shown in insects and rodents
- [Autophagy](https://en.wikipedia.org/wiki/Autophagy), of course, all these organelles in the cells; but they didn’t measure any of the tubules or anything for autophagy

***Eric measured mitochondrial turnover by this method and found that it was increased with caloric restriction, and he thinks there’s both mechanisms: less energy requirement, but also more efficient mitochondria***

**Today, if you were to do this study, are there any other biomarkers you would be able to look at today today vis-à-vis the hallmarks of aging?**

*In terms of inflammatory markers, how much of a suite of the interleukins, TNF and things of that nature did you look at?*

- We looked at 6, 12, 24 months
- We had the whole panel of inflammation and [high sensitivity CRP](https://en.wikipedia.org/wiki/C-reactive_protein#:~:text=high%20sensitivity%20CRP%20(hs%2DCRP)) and then all the [interleukin](https://en.wikipedia.org/wiki/Interleukin), [TNF-α](https://en.wikipedia.org/wiki/Tumor_necrosis_factor) and all that

***Everything improved***

*One thing which was spectacular when it comes to immune function, we did some imaging of the thymus and there was loss of fat*

![](https://peterattiamd.com/wp-content/uploads/2024/11/f12-ericravussin.png)

**Figure 12. Significant increase in thymic mass after sustained CR for 2 years (*****P*** **< 0.05)**. Image credit: [*Science* 2023](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10061495/)

- [Deep Dixit](https://medicine.yale.edu/profile/vishwa-dixit/) was excited by that and this is why he pursued all the immune responses from transcriptomics in different tissues

*Other important findings*

- [Chronic inflammation](https://pubmed.ncbi.nlm.nih.gov/35143297/) was not abnormal to begin with, but there was tremendous improvement
- [Bill Kraus](https://dmpi.duke.edu/william-kraus-md) in the discussion of his [paper](https://pubmed.ncbi.nlm.nih.gov/31303390/) used the [Framingham Index](https://en.wikipedia.org/wiki/Framingham_Risk_Score#) of cardiometabolic health and found an improvement

> “*It was quite spectacular. It was like they were gaining 10 years in 2 years*.”‒ Eric Ravussin

**Peter’s takeaways and questions**

- “*I think it’s very interesting and I think it is hands down the best experimental evidence we have that caloric restriction for those who can do it may indeed be a great tool*.”
- Questions that can’t be answered by this study based on its duration and the age of the subjects
  - Would those benefits extend into the 8th decade of life, a period of time when sarcopenia becomes a significant driver of not just mortality but truly morbidity?
  - And would we indeed see a trade-off in lean muscle?
    - The answer is not necessarily that you would
    - One could indeed consume fewer calories without any restriction of protein, and while doing all of the necessary strength training
- Peter thinks there’s a deliberate way to do this
  - If one were just to restrict calories and lose lean mass
  - The subjects got lighter and obviously their body composition improved, meaning they disproportionately lost fat to muscle

Peter asks, “*Do you recall if there was also a meaningful reduction in lean tissue independent of the improvement in body composition?*”

- Eric would have to go back to the publication to say exactly, but it was less than a quarter
  - This is the limit Peter recommends for loss of lean body mass to total weight
  - [[see Table 2](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6707879/) and also this [review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9052419/)]
- In terms of exercise, Eric explains, “*We didn’t restrict physical activity, but to be enrolled, they had to be screened for not being regular exercisers*.”

**The CRONies (Calorie Restriction Optimal Nutrition Society)**

- There is about 200 self-imposed calorie-restricted people
- They are afraid of exercise
  - They don’t exercise at all because they are afraid that exercise is going to increase their appetite and food intake
- To Peter’s question about [sarcopenia](https://en.wikipedia.org/wiki/Sarcopenia), when you start with people with a BMI of 24 and you lose your 10, 12% and you keep this 12% off and you go in your 70s and 80s, ***what is happening to your muscle mass and these kinds of things?***
  - We don’t have an answer

## The challenge of applying CR to the general population, the potential of drugs and exercise to mimic the effects of CR [1:55:45]

> “*Your tissue and serum samples provide a very compelling case of you can take healthy people, CR them for a couple of years and make them better across the board by every objective measure of both primary and secondary aging.*”‒ Peter Attia

- The effects [of CR] on secondary aging are so obvious it’s not even worth talking about
  - People interested can go back and look at the papers and see the lipid profiles and the insulin sensitivity [summarized in the figure below]
    - [see publications in the “Selected Links” section at the end of these notes]

![](https://peterattiamd.com/wp-content/uploads/2024/11/f13-ericravussin.png)

**Figure 13. Long-term effects of calorie restriction observed in CALERIE 2 study**. Image credit: [*Nutrition Reviews* 2021](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7727025/)

- The primary markers of aging are very interesting
- Peter had forgotten (or didn’t know) about the thymic fat reduction

**The question is**

- You were dealing with a very narrow population
- You started with 2,500 people and through intensive psychological profiling, you winnowed out it down to the 5% of people who were going to be able to most adhere to this
- And then on top of that, you provided arguably the most robust support for those people during this journey
  - The kind of support they couldn’t buy outside
  - Those people as regular people on the outside world couldn’t have purchased the level of care and support and encouragement they got for that 2-year study
- This is not a criticism of the study, it’s to simply say those were the necessary steps to get such exceptional compliance, which is what was necessary to get such a meaningful answer
- If we want to ask the question, “*How would you help the 99% of people who on their own could not adhere to that?*”
- The answer of course becomes [CR mimetic drugs](https://en.wikipedia.org/wiki/Caloric_restriction_mimetic) (this is the question that is on everybody’s mind)

> “*Eric, you’ve convinced me that CR to this extent will absolutely help me live a longer, better life, but I just can’t do it.*”‒  Peter Attia

***Will a GLP-1 agonist give me the same benefit?***

***Will rapamycin give me the same benefit?***

***Will acarbose give me the same benefit?***

***Will an SGLT2 inhibitor give me the same benefit?***

***Will metformin give me the same benefit?***

- Those studies are much easier to do
- We can easily put people on those drugs for 2 years and do the exact same analysis
- Eric given us the gold standard, the template
- Now we just need to compare every single marker Eric’s team measured plus some they haven’t

***Peter really wants to see the epigenome in these subjects pre and post***

Peter asks, “*Is it just me that feels this way or is that also screaming out to you as the most interesting question to come out of this?*”

- For Eric, it’s been a little bit of a rollercoaster
  - The [CR mimetics](https://en.wikipedia.org/wiki/Caloric_restriction_mimetic)
  - The [SIRT1](https://en.wikipedia.org/wiki/Sirtuin_1) stories
- Notice that Peter picked something very carefully, only drugs that were winners of the ITP
  - With the exception of GLP-1 agonists
- SIRT1s are garbage ‒ they were a scam story that never materialized
  - It was never the mechanism by which CR worked
  - [discussed in previous episodes of *The Drive* listed in the “selected links” section at the end]
  - Peter talked to [Matt Kaeberlein](https://kaeberlein.org/lab-members/matt-kaeberlein/) who did the first study [[AMA #35](https://peterattiamd.com/preview-207-ama-35-anti-aging-drugs-nad-metformin-rapamycin/)]
    - He has gone through every experiment that was done in that lab
    - There is zero evidence that SIRT’s supposed efficacy was mediated through CR
  - SIRT1s have no efficacy post-yeast
- Peter doesn’t think [Metformin](https://en.wikipedia.org/wiki/Metformin) is a CR mimetic but that we should include it
- Eric agrees that [GLP-1](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist) [receptor agonists] are so potent when it comes to weight loss and  metabolic health
  - Every week there’s a new paper on GLP-1
- Peter just read a [paper](https://pubmed.ncbi.nlm.nih.gov/39084707/) on blood pressure and [tirzepatide](https://en.wikipedia.org/wiki/Tirzepatide)

Eric asks, “*Why would that be? Because when you calorie restrict yourself, you eat less and therefore, you stimulate less of these GI peptides.*”

- Peter replies that none of it makes sense

Eric asks, “*Are* *they true calorie restriction mimetics and do they decrease oxidative stress? Do they improve insulin sensitivity and all that? Among the ones you cited there’s a lot of those. Now the question is how do you go about to test that?*”

**For Eric, the impact on secondary aging is what we should target first**

- The impact of your lifestyle and your environment
- For primary aging, he likes to hear David Clark talk about autophagy

***What do you have to do to have more*** [***autophagy***](https://en.wikipedia.org/wiki/Autophagy) ***or more*** [***mitophagy***](https://en.wikipedia.org/wiki/Mitophagy)***? Eric doesn’t know***

- Peter explains, “*We know exercise does it. I mean, we know that autophagy is not just fueled by caloric restriction, but exercise is an incredibly potent driver of that, for similar mechanisms.*”
- You could argue that it’s basically a substrate utilization problem
  - It’s the input, it’s the output
  - And when you transiently deprive the output, if you drive more output and you transiently create a deficit of energy
    - At the cellular level the body is not concerned with, “*Am I short on what’s coming in, or am I short because too much is going out?*”
    - It doesn’t have to be an either or

**Peter thinks these particular geroprotective agents are probably not going to be as impressive on the secondary markers of aging**

- With the expectation of the [GLP-1 agonists](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist) (because of the obvious weight loss
- The other drugs ([metformin](https://en.wikipedia.org/wiki/Metformin), [rapa](https://en.wikipedia.org/wiki/Sirolimus), [SGLT2s](https://en.wikipedia.org/wiki/Sodium/glucose_cotransporter_2), [acarbose](https://en.wikipedia.org/wiki/Acarbose)), none of them resulted in weight loss in the [ITP](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp)
- The hypothesis of [David Allison](https://news.iu.edu/live/profiles/945-david-allison) who proposed ascarbose is, “*This is going to be a CR mimetic that induces weight loss because of bad absorption*.”
  - Those mice weighed the exact same amount
  - They just lived longer, suggesting it was actually the glucose metabolism that gave the benefit

## Upcoming study comparing caloric restriction to time-restricting eating, and Peter’s takeaways from the discussion [2:02:45]

**Peter’s final takeaways**

- Peter thinks what Eric and his incredible team has done is amazing
- He hopes that through this podcast, we’re giving people an appreciation for how hard it is to do nutrition science if you’re an experimentalist
  - Anybody can do epidemiology, and Peter shares the view of [George](https://www.pbrc.edu/research-and-faculty/emeritus/bray-george-MD.aspx) and [John](https://profiles.stanford.edu/john-ioannidis) and the people who think that it is a very, very limited use
    - Not of no use
    - There is a case, but we over-index on that stuff
- What we really need to be doing is doubling down on the kind of work Eric does, because that’s the only place we’re going to get causal information and information that we could make people’s lives better with

**Eric invites us to stay tuned**

- Now there is a study which is going to be implementing a 1 or 2 or 5-year intervention testing calorie restriction versus time-restricted eating
- The protocol is not finalized
- It’s one of these exercises where we were part of one of the studies and now you put all the brains together
- The time restriction is probably going to be eight hours a day
  - Peter would vote to make it more restrictive
- The first [study](https://pubmed.ncbi.nlm.nih.gov/31339000/) Eric did was 6 hours
- Peter thinks if you really want to see if there’s a signal independent of calorie restriction, the goal has to be you’re going to have to match their calories
  - This is the isocaloric difference between CR and time-restricted feeding
- In Peter’s experience, 8 hours will give you a null answer
- He’d be very curious about 4-6 hours
- Eric’s study of [time-restricted feeding](https://pubmed.ncbi.nlm.nih.gov/31339000/) was the first in humans, and they used 6 hours
  - [Courtney Peterson](https://scholars.uab.edu/3393-courtney-peterson) did that
  - People said it would be easier with 8 hours
  - If Eric recalls correctly, after 2 weeks, people were perfectly fine with 6 hours
    - Even if at the exit interview they said it would be easier for 8 hours

§

## Selected Links / Related Material

**A comparison of 2 isocaloric diets (high-carb versus keto) and the effect on energy expenditure**: [Energy expenditure and body composition changes after an isocaloric ketogenic diet in overweight and obese men](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4962163/) | *The American Journal of Clinical Nutrition* (K Hall et al. 2016) | [1:15, 39:15]

**CALERIE study, Duke University**: [calerie](https://calerie.duke.edu/) | Duke Univeristy School of Medicine (2024) | [1:30, 1:15:15]

**CALERIE study, Pennington Biomedical Research Center**: [calerie](https://calerie.pbrc.edu/index.html) | Pennington Biomedical Research Center (2002)

**CALERIE study, review**:

- [Effects of caloric restriction on human physiological, psychological, and behavioral outcomes: highlights from CALERIE phase 2](https://pubmed.ncbi.nlm.nih.gov/32940695/) | *Nutrition Reviews* (J Dorling, et al 2021)
- [Beyond weight loss: current perspectives on the impact of calorie restriction on healthspan and lifespan](https://pubmed.ncbi.nlm.nih.gov/33957841/) | *Expert Review of Endocrinology & Metabolism* (M Kebbe et al. 2021)

**Portable mask to measure VO****2** **max**: [VO2 Master](https://vo2master.com/) | [13:45]

**Leptin-deficient people measured in the metabolic chamber**: [Leptin replacement prevents weight loss-induced metabolic adaptation in congenital leptin-deficient patients](https://pubmed.ncbi.nlm.nih.gov/20061423/) | *The Journal of Clinical Endocrinology and Metabolism* (J Galgani et al. 2010) | [22:15]

**Study of energy expenditure in Pima Indians**: [Reduced rate of energy expenditure as a risk factor for body-weight gain](https://pubmed.ncbi.nlm.nih.gov/3340128/) | *NEJM* (E Ravussin et al. 1988) | [26:45]

**Episode of** ***The Drive*** **with George Brooks**: [#312 – A masterclass in lactate: Its critical role as metabolic fuel, implications for diseases, and therapeutic potential from cancer to brain health and beyond | George A. Brooks, Ph.D.](https://peterattiamd.com/georgebrooks/) (August 5, 2024) | [30:30]

**E-MECHANIC study**: [Effect of different doses of supervised exercise on food intake, metabolism, and non-exercise physical activity: The E-MECHANIC randomized controlled trial](https://pubmed.ncbi.nlm.nih.gov/31172175/) | *American Journal of Clinical Nutrition* (C Martin et al. 2019) | [31:15]

**The Weight Registry**: [32:45]

- [The National Weight Control Registry](http://www.nwcr.ws/) (2024)
- [A descriptive study of individuals successful at long-term maintenance of substantial weight loss](https://pubmed.ncbi.nlm.nih.gov/9250100/) | *American Journal of Clinical Nutrition* (M Klem et al. 1997)
- [Are the eating and exercise habits of successful weight losers changing?](https://pubmed.ncbi.nlm.nih.gov/16741274/) | *Obesity* (S Phelan et al. 2006)

**Experiment varying carbohydrate and fat in an isocaloric diet, and the effect on energy expenditure**: [Energy expenditure and body composition changes after an isocaloric ketogenic diet in overweight and obese men](https://pubmed.ncbi.nlm.nih.gov/27385608/) | *American Journal of Clinical Nutrition* (K Hall et al. 2016) [38:56, 50:37, 55:15]

**Meta-analysis of ketogenic diet for weight loss**: [Effect of carbohydrate restriction on body weight in overweight and obese adults: a systematic review and dose-response meta-analysis of 110 randomized controlled trials](https://pubmed.ncbi.nlm.nih.gov/38125726/) | *Frontiers in Nutrition* (S Soltani et al. 2023) | [45:30]

**Nutrition for precision health study**: [51:00, 1:00:30, 1:13:15, 1:44:00]

- [Can a personalized diet help improve health and prevent chronic diseases?](https://nutritionforprecisionhealth.org/) | Nutrition for Precision Health (2024)
- [All of Us Research Program](https://allofus.nih.gov/news-events/announcements/nih-launches-largest-precision-nutrition-research-effort-its-kind) (2023)

**ADAPT study**: [Dynamic changes in fat oxidation in human primary myocytes mirror metabolic characteristics of the donor](https://pubmed.ncbi.nlm.nih.gov/16007256/) | *The Journal of Clinical Investigation* (B Ukropcova, et al 2005) | [55:15]

**Study of oxidation rates when different fats (LCT or MCT) are added to the diet**: [Effects of dietary fat on postprandial substrate oxidation and on carbohydrate and fat balances](https://pubmed.ncbi.nlm.nih.gov/3900133/) | *Journal of Clinical Investigation* (J Flatt et al. 1985) | [55:45]

**Episode of** ***The Drive*** **that discusses data behind the protein leverage theory**: [#313 – AMA #62: Protein’s impact on appetite and weight management, and uric acid’s link to disease and how to manage levels](https://peterattiamd.com/ama62/) (August 12, 2024) | [1:09:45]

**CALERIE Legacy Study (in progress)**: [The CALERIE™ Legacy Study](https://ctv.veeva.com/study/the-calerie-legacy-study) | CTV by Veeva Systems (2024) | [1:16:45, 1:41:00, 1:51:00]

**Analysis of transcriptomes from adipose tissue of CALERIE participants reveal effects of caloric restriction on immune function**: [Caloric restriction in humans reveals immunometabolic regulators of health span](https://pubmed.ncbi.nlm.nih.gov/35143297/) | *Science* (O Spadaro, et al 2022) | [1:17:15]

**Energy expenditure of inhabitants of Biosphere 2**: [Energy metabolism after 2 y of energy restriction: the biosphere 2 experiment](https://pubmed.ncbi.nlm.nih.gov/11010936/) | *American Journal of Clinical Nutrition* (C Weyer et al. 2000) | [1:20:00]

**Review of benefits of caloric restriction and CALERIE phase 1 study** : [Caloric Restriction in Humans: Impact on Physiological, Psychological, and Behavioral Outcomes](https://pubmed.ncbi.nlm.nih.gov/20518700/) | *Antioxidants & Redox Signaling* (L Redman, E Ravussin 2011) | [1:24:00]

**Resting metabolic rate in athletes**: [Effect of endurance training on sedentary energy expenditure measured in a respiratory chamber](https://pubmed.ncbi.nlm.nih.gov/1996628/) | *American Journal of Physiology* (L Schulz et al 1991) | [1:26:00]

**Baltimore Longitudinal study showed people with lower metabolic rate living longer**: [1:26:30]

- [High basal metabolic rate is a risk factor for mortality: the Baltimore Longitudinal Study of Aging](https://pubmed.ncbi.nlm.nih.gov/18693224/) | *The Journals of Gerontology Series A* (C Ruggiero et al. 2008)
- [“IDEAL” aging is associated with lower resting metabolic rate: the Baltimore Longitudinal Study of Aging](https://pubmed.ncbi.nlm.nih.gov/24635835/) | Journal of the American Geriatrics Society (J Schrack et al. 2014)

**Review of 6-month findings of the CALERIE phase 1 study at Pennington:** [Caloric Restriction in Humans: Impact on Physiological, Psychological, and Behavioral Outcomes](https://pubmed.ncbi.nlm.nih.gov/20518700/) | *Antioxidants & Redox Signaling* (L Redman, E Ravussin 2011) **|** [1:28:00, 1:46:45]

**Screening and recruitment for CALERIE phase 2 study**: [Comprehensive Assessment of Long-term Effects of Reducing Intake of Energy Phase 2 (CALERIE Phase 2) screening and recruitment: methods and results](https://pubmed.ncbi.nlm.nih.gov/22981898/) | *Contemporary Clinical Trials* (T Stewart et al. 2013) | [1:29:30, 1:42:15]

**Results from phase 1 of the CALERIE study**: [1:31:00]

- Ravussin at Pennington: [Effect of 6-month calorie restriction on biomarkers of longevity, metabolic adaptation, and oxidative stress in overweight individuals: a randomized controlled trial](https://pubmed.ncbi.nlm.nih.gov/16595757) | *JAMA* (L Heilbronn et al. 2006)
- Ravussin at Pennington: [Effect of calorie restriction with or without exercise on insulin sensitivity, beta-cell function, fat cell size, and ectopic lipid in overweight subjects](https://pubmed.ncbi.nlm.nih.gov/16732018/) | *Diabetes Care* (D Larson-Meyer, et al 2006)
- Holloszy at Washington University, St. Louis: [One year of caloric restriction in humans: feasibility and effects on body composition and abdominal adipose tissue](https://pubmed.ncbi.nlm.nih.gov/16960025) | *The Journals of Gerontology Series A* (S Racette et al. 2006)
- Roberts at Tufts: [Long-term effects of 2 energy-restricted diets differing in glycemic load on dietary adherence, body composition, and metabolism in CALERIE: a 1-y randomized controlled trial](https://pubmed.ncbi.nlm.nih.gov/17413101) | *American Journal of Clinical Nutrition* (S Das et al. 2007) Roberts at Tufts
- Holloszy at Washington University, St. Louis: [Improvements in glucose tolerance and insulin action induced by increasing energy expenditure or decreasing energy intake: a randomized controlled trial](https://pubmed.ncbi.nlm.nih.gov/17093155) | *American Journal of Clinical Nutrition* (E Weiss et al. 2006)

**Phase 2 design of the CALERIE study**: [1:31:15]

- [Design and conduct of the CALERIE study: comprehensive assessment of the long-term effects of reducing intake of energy](https://pubmed.ncbi.nlm.nih.gov/20923909) | *The Journals of Gerontology Series A* (J Rochon et al. 2010)
- [The CALERIE Study: design and methods of an innovative 25% caloric restriction intervention](https://pubmed.ncbi.nlm.nih.gov/21767664/) | *Contemporary Clinical Trials* (A Rickman et al. 2011)

**Health one diet**: [Health One](https://hnthealth.com/) (2024) | [1:34:00]

**Results from phase 2 of the CALERIE study**: [1:37:00]

- [A 2-year randomized controlled trial of human caloric restriction: feasibility and effects on predictors of health span and longevity](https://pubmed.ncbi.nlm.nih.gov/26187233) | *The Journals of Gerontology Series A* (E Ravussin et al. 2015)
- [2 years of calorie restriction and cardiometabolic risk (CALERIE): exploratory outcomes of a multicentre, phase 2, randomised controlled trial](https://pubmed.ncbi.nlm.nih.gov/31303390/) | *The Lancet Diabetes & Endocrinology* (W Kraus et al. 2019)

**Additional publications from the CALERIE study**: [calerie: Publications](https://calerie.duke.edu/publications) (2024)

**Follow-up of CALERIE participants**: [Persistence of weight loss and acquired behaviors 2 y after stopping a 2-y calorie restriction intervention](https://pubmed.ncbi.nlm.nih.gov/28275127/) | *The American Journal of Clinical Nutrition* (K Marlatt et al. 2017) | [1:46:45]

**CALERIE study: effects on cardiometabolic risk factors**: [1:47:45]

- Review: [Caloric Restriction: Implications for Human Cardiometabolic Health](https://journals.lww.com/jcrjournal/abstract/2013/07000/caloric_restriction__implications_for_human.1.aspx) | *Journal of Cardiopulmonary Rehabilitation and Prevention* (C Bales, W Kraus 2013)
- [A 2-year randomized controlled trial of human caloric restriction: feasibility and effects on predictors of health span and longevity](https://pubmed.ncbi.nlm.nih.gov/26187233) | *The Journals of Gerontology Series A* (E Ravussin et al. 2015)
- [2 years of calorie restriction and cardiometabolic risk (CALERIE): exploratory outcomes of a multicentre, phase 2, randomised controlled trial](https://pubmed.ncbi.nlm.nih.gov/31303390/) | *The Lancet Diabetes & Endocrinology* (W Kraus et al. 2019)
- [Calorie restriction improves lipid-related emerging cardiometabolic risk factors in healthy adults without obesity: Distinct influences of BMI and sex from CALERIE™ a multicentre, phase 2, randomised controlled trial.](https://pubmed.ncbi.nlm.nih.gov/35028547/) | *E Clinical Medicine* (K Huffman et al. 2022)

**CALERIE study and effects on other hallmarks of aging**: [1:48:15, 1:56:09]

- [Calorie restriction increases muscle mitochondrial biogenesis in healthy humans](https://pubmed.ncbi.nlm.nih.gov/17341128/) | *PLoS Medicine* (A Civitarese et al. 2007) | analysis of data from 6 months of CR in the CALERIE phase 1 study
- [The effect of caloric restriction and glycemic load on measures of oxidative stress and antioxidants in humans: results from the CALERIE Trial of Human Caloric Restriction](https://pubmed.ncbi.nlm.nih.gov/21623467/) | *The Journal of Nutrition, Health & Aging* (M Meydani et al. 2011) | 6 months of CR
- [Effects of 12 Months of Caloric Restriction on Muscle Mitochondrial Function in Healthy Individuals](https://pubmed.ncbi.nlm.nih.gov/27778643/) | *The Journal of Clinical Endocrinology and Metabolism* (L Sparks et al. 2017)
- [Change in the Rate of Biological Aging in Response to Caloric Restriction: CALERIE Biobank Analysis](https://pubmed.ncbi.nlm.nih.gov/28531269/) | *The Journals of Gerontology Series A* (D Belsky et al. 2017)
- [Caloric restriction in humans reveals immunometabolic regulators of health span](https://pubmed.ncbi.nlm.nih.gov/35143297/) | *Science* (O Spadaro, et al 2022)
- [Epigenome-wide Association Study Analysis of Calorie Restriction in Humans, CALERIETM Trial Analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9799188/) | *The Journals of Gerontology Series A* (M Ramaker et al. 2022)
- [Calorie restriction modulates the transcription of genes related to stress response and longevity in human muscle: The CALERIE study](https://pubmed.ncbi.nlm.nih.gov/37823711/) | *Aging Cell* (J Kumar Das, et al 2023)
- [Effect of long-term caloric restriction on DNA methylation measures of biological aging in healthy adults from the CALERIE trial](https://pubmed.ncbi.nlm.nih.gov/37118425/) | *Nature Aging* (R Waziry et al. 2023)

**Hallmarks of aging**: [1:48:30]

- [The hallmarks of aging](https://pubmed.ncbi.nlm.nih.gov/23746838/) | *Cell* (C Lopez-Otin et al. 2013)
- [Hallmarks of aging: An expanding universe](https://pubmed.ncbi.nlm.nih.gov/36599349/) | *Cell* (C Lopez-Otin et al. 2023)

**Mitochondrial biogenesis in CALERIE study participants**: [1:49:00]

- [Calorie restriction increases muscle mitochondrial biogenesis in healthy humans](https://pubmed.ncbi.nlm.nih.gov/17341128/) | *PLoS Medicine* (A Civitarese et al. 2007)
- [Effects of 12 Months of Caloric Restriction on Muscle Mitochondrial Function in Healthy Individuals](https://pubmed.ncbi.nlm.nih.gov/27778643/) | *The Journal of Clinical Endocrinology and Metabolism* (L Sparks et al. 2017)

**Thymus imaging and assessment of chronic inflammation (CALERIE study)**: [Caloric restriction in humans reveals immunometabolic regulators of health span](https://pubmed.ncbi.nlm.nih.gov/35143297/) | *Science* (O Spadaro, et al 2022) | [1:52:00]

**CALERIE phase 2 study showed CR improves cardiometabolic health**: [2 years of calorie restriction and cardiometabolic risk (CALERIE): exploratory outcomes of a multicentre, phase 2, randomised controlled trial](https://pubmed.ncbi.nlm.nih.gov/31303390/) | *Lancet Diabetes Endocrinology* (W Kraus, et al 2019) | [1:52:45]

**SIRT1 mini review**: [SIRT1, resveratrol and aging](https://pubmed.ncbi.nlm.nih.gov/38784035/) | *Frontiers in Genetics* (B Rogina and H Tissenbaum, 2024) | [1:58:30]

**SIRT1 commentary**: [Sirtuins are Not Conserved Longevity Genes](https://pubmed.ncbi.nlm.nih.gov/37035412/) | *Life Metabolism* (C Brenner 2022) | [1:58:30]

**Episodes of** ***The Drive*** **that discuss SIRT1 or Resveratrol**: [1:58:45]

- [#27 – David Sinclair, Ph.D.: Slowing aging – sirtuins, NAD, and the epigenetics of aging](https://peterattiamd.com/davidsinclair/) (November 5, 2018)
- [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) (February 8, 2021)
- [#207 – AMA #35: “Anti-Aging” Drugs — NAD+, metformin, & rapamycin](https://peterattiamd.com/preview-207-ama-35-anti-aging-drugs-nad-metformin-rapamycin/) (May 16, 2022)
- [#281 ‒ Longevity drugs, aging biomarkers, and updated findings from the Interventions Testing Program (ITP) | Rich Miller, M.D., Ph.D.](https://peterattiamd.com/richardmiller2/) (December 4, 2023)
- [#300 – Special episode: Peter on exercise, fasting, nutrition, stem cells, geroprotective drugs, and more — promising interventions or just noise?](https://peterattiamd.com/ep-300-exercise-nutrition-fasting-more/) (May 6, 2024)

**Tirzepatide reduces blood pressure**: [Tirzepatide and blood pressure reduction: stratified analyses of the SURMOUNT-1 randomised controlled trial](https://pubmed.ncbi.nlm.nih.gov/39084707/) | *Heart* (H Krumholz et al. 2024) | [2:00:00]

**Eric’s study of time-restricted eating using a 6-hour eating window**: [Early Time-Restricted Feeding Reduces Appetite and Increases Fat Oxidation But Does Not Affect Energy Expenditure in Humans](https://pubmed.ncbi.nlm.nih.gov/31339000/) | *Obesity* (E Ravussin et al. 2019) | [2:04:30]

§

## People Mentioned

- [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin) (Section Chief of Integrative Physiology Section, Laboratory of Biological Modeling  at NIDDK) [3:45, 18:00, 47:30]
- [Steven Smith](https://www.adventhealthresearchinstitute.com/team/steven-smith) (Chief Scientific Officer and Senior Vice President of Advent Health Research Institute) [3:45, 55:15]
- [Rudolph (Rudy) Leibel](https://www.ihn.cuimc.columbia.edu/profile/rudolph-l-leibel-md#research) (Professor of Diabetes Research and Professor of Pediatrics and Medicine; Co-Director, Naomi Berrie Diabetes Center, and Chief of Pediatric Molecular Genetics at Columbia University) [3:45]
- [Michael Rosenbaum](https://www.nynorc.cuimc.columbia.edu/profile/michael-rosenbaum-md#research) (Professor of Pediatrics and Medicine at Columbia University) [3:45]
- [Marc Reitman](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/reitman-marc) (Senior Investigator and Branch Chief at NIDDK [3:45]
- [John Blundell](https://medicinehealth.leeds.ac.uk/psychology/staff/1183/professor-john-blundell-) (Professor and Chair of psychoBiology at the University of Leeds, expert in appetite and energy balance) [23:15, 1:07:15]
- [Joseph Donnelly](https://lifespan.ku.edu/people/joseph-donnelly) (Professor of Internal Medicine, Division Director of Physical Activity and Weight Management, and Director of the Energy Balance Laboratory and Kansas Weight Management Programs at The University of Kansas) [28:45]
- [George Brooks](https://vcresearch.berkeley.edu/faculty/george-brooks) (Professor of Integrative Biology at UC Berkeley and expert in lactate metabolism) [30:30]
- [Tim Church](https://www.truehealthinitiative.org/council_member/tim-church/) (Adjunct Professor of Preventative Medicine at Pennington Biomedical Research Center where he was the PI of [The LIFE Study](https://www.pbrc.edu/news/media/archives/LIFE-Study-Elderly-Walking-Publication-2014.aspx), part of the True Health Initiative, Chief Medical Officer of Wondr Health [[Wichita State University](https://www.wichita.edu/profiles/academics/health_professions/CHP_Dean_Advisory_Council/Church-Tim.php)], Medical Director of [Genetic Direction](https://geneticdirection.com/tim-church-m-d-m-p-h-ph-d-medical-director/)) [32:15]
- [Rena Wing](https://vivo.brown.edu/display/rwingphd#Research) (Professor of Psychiatry and Human Behavior at Brown University, expert in type 2 diabetes, co-founder of the [National Weight Control Registry](http://www.nwcr.ws/)) [31:45]
- [James (Jim) Hill](https://scholars.uab.edu/6698-james-hill) (Professor of Nutritions Sciences and Director of the UAB Nutrition Obesity Research Center at the University of Alabama at Birmingham, co-founder of the [National Weight Control Registry](http://www.nwcr.ws/)) [30:45]
- [Richard Bergman](https://researchers.cedars-sinai.edu/Richard.Bergman) (Professor of Biomedical Sciences and Medicine at Cedars Sinai, expert in obesity, insulin resistance, and diabetes) [33:30]
- [David Ludwig](https://www.drdavidludwig.com/) (Endocrinologist and researcher at Boston Children’s Hospital, Professor of Pediatrics at Harvard Medical School and Professor of Nutrition at Harvard School of Public Health) [43:45]
- [Jean-Pierre (JP) Flatt](https://onlinelibrary.wiley.com/doi/full/10.1002/oby.22362) (1933-2018, was Professor Emeritus of Biochemistry at University of Massachusetts Medical School, expert in obesity and weight loss) [49:45]
- [Stephen Simpson](https://www.sydney.edu.au/science/about/our-people/academic-staff/stephen-simpson.html#collapseprofileresearchinterest) (Professor  of Life and Environmental Sciences and Academic Director of the Charles Perkins Centre at the University of Sydney; expert in protein leverage theory) [1:09:15]
- [George Bray](https://www.pbrc.edu/research-and-faculty/emeritus/bray-george-MD.aspx) (Professor Emeritus of Clinical Science at Pennington Biomedical Research Center, Louisiana State University) [1:10:15]
- [John Ioannidis](https://profiles.stanford.edu/john-ioannidis) (Professor of Medicine and Epidemiology and Population Health at Stanford) [1:11:15]
- [William (Bill) Kraus](https://dmpi.duke.edu/william-kraus-md) (Distinguished Professor of Medicine in the division of Cardiology Medicine and the Duke MOlecular Physiology Institute at Duke University; PI on the CALERIE study) [1:17:00, 1:47:45]
- [Deep Dixit](https://medicine.yale.edu/profile/vishwa-dixit/) (Professor of Pathology and Immunology a nd Director of the Yale Center for Research on Aging at Yale University) [1:17:30, 1:52:15]
- [Roy Walford](https://senate.universityofcalifornia.edu/_files/inmemoriam/html/roywalford.htm) (1924-2004, was a Professor of Pathology and Laboratory Medicine at UCLA, leading authority on the biology of aging and caloric restriction) [1:19:45]
- [Rick Weindruch](https://experts.news.wisc.edu/experts/richard-weindruch) (Professor of Medicine, Geriatrics and Gerontology at the University of Wisconsin-Madison, expert in caloric restriction and aging)  [1:19:45]
- [John Holloszy](https://medicine.wustl.edu/news/obituary-john-o-holloszy-former-director-of-applied-physiology-85/) (1933-2018, was a Professor of Medicine at Washington University School of Medicine in St. Louis, expert in biochemical and anatomical adaptations to exercise and calorie restriction) [1:31:00]
- [Susan Roberts](https://internationalweightcontrolregistry.org/about/people/susan-b-roberts-phd/) (Professor of Medicine and Epidemiology and Senior Associate Dean of Foundational Research at [Dartmouth Geisel School of Medicine](https://geiselmed.dartmouth.edu/faculty/facultydb/view.php/?uid=8496), Adjunct Professor of Nutrition at [Tufts University](https://facultyprofiles.tufts.edu/susan-roberts), co-founder of [International Weight Control Registry](https://internationalweightcontrolregistry.org/about/people/) [1:31:00]
- [Leanne Redman](https://www.pbrc.edu/research-and-faculty/faculty/Redman-Leanne-PhD.aspx) (Professor of Clinical science and Director of Nutrition Obesity Research Center at Pennington Biomedical Research Center, Louisiana State University; PI on the CALERIE legacy study) [1:47:00]
- [Matt Kaeberlein](https://kaeberlein.org/lab-members/matt-kaeberlein/) (Professor of Pathology at the University of Washington, Co-Director of the UW Nathan Shock Center of Excellence in the Basic Biology of aging, Co-Director of the Dog Aging Project) [1:59:00]
- [David Allison](https://news.iu.edu/live/profiles/945-david-allison) (Dean and Distinguished Professor at the Indiana University School of Public Health-Bloomington, expert in obesity, energetics, nutrition and research rigor) [2:02:30]
- [Courtney Peterson](https://scholars.uab.edu/3393-courtney-peterson) (Associate Professor of Nutrition Sciences, expert in intermittent fasting) [2:05:00]

§

![](https://peterattiamd.com/wp-content/uploads/2024/11/bio-ericravussin-500x500.png)

##### Eric Ravussin, Ph.D.

Dr. Eric Ravussin is a world expert in the conduct of translational research in obesity and type 2 diabetes. Over his more than 35 year career, he has conducted numerous clinical investigations on measures of energy expenditure, body composition, carbohydrate metabolism and biomarkers of aging in health and disease states. More specifically over the past 20 years he has established a wet lab studying skeletal muscle and adipose tissue cross talks and the relationship of these two tissues on inflammation, nutrient partitioning and insulin sensitivity. He has published more than 450 peer reviewed manuscripts in the field of obesity, type 2 diabetes and aging. He has mentored more than 60 postdoctoral fellows. Over the past 15 years he has conducted translational research on the impact of caloric restriction on biomarkers of aging, looked at the impact of weight loss and weight gain (overfeeding) in the cross talk between adipose and skeletal muscle and has conducted randomized clinical trial on the impact of dietary, activity, surgical and pharmacological interventions on insulin sensitivity.

Dr. Ravussin is the director of the Nutrition Obesity Research Center at the Pennington Biomedical Research Center at Louisiana State University. There he serves as the Douglas L. Gordon Chair in Diabetes and Metabolism and is the Boyd Professor of Metabolic Chambers and Human Translational Physiology. [[Pennington Biomedical Research Center](https://www.pbrc.edu/research-and-faculty/faculty/Ravussin-Eric-PhD.aspx)]