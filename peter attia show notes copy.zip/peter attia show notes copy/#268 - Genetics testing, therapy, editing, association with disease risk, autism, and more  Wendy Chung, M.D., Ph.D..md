# #268 ‒ Genetics: testing, therapy, editing, association with disease risk, autism, and more | Wendy Chung, M.D., Ph.D.

**Source:** [https://peterattiamd.com/wendychung/](https://peterattiamd.com/wendychung/)

---

Wendy Chung is a board-certified clinical and molecular geneticist with more than 25 years of experience in human genetic disease research. In this episode, Wendy delves deep into the world of genetics by first exploring the historical landscape of genetics prior to decoding the human genome, contrasting it with what we know today thanks to whole genome and exome sequencing. She provides an overview of genetic testing by differentiating between various genetic tests such as direct-to-consumer, clinical, whole genome sequencing, and more. Additionally, Wendy unravels the genetic underpinnings of conditions such as PKU, breast cancer, obesity, autism, and cardiovascular disease. Finally, Wendy goes in depth on the current state and exciting potential of gene therapy while also contemplating the economic implications and ethical nature of gene editing.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/wendychung/the_Drive_public.png)

Play

#268 ‒ Genetics: testing, therapy, editing, association with disease risk, autism, and more | Wendy Chung, M.D., Ph.D.

#268 ‒ Genetics: testing, therapy, editing, association with disease risk, autism, and more | Wendy Chung, M.D., Ph.D.

1x15s30s

0:002:27:29

## We discuss:

- Wendy’s interest in genetics and work as a physician-scientist [2:45];
- The genetics of phenylketonuria (PKU), a rare inherited disorder [5:15];
- The evolution of genetic research: from DNA structure to whole genome sequencing [18:30];
- Insights and surprises that came out of the Human Genome Project [28:30];
- Overview of various types of genetic tests: direct-to-consumer, clinical, whole genome sequencing, and more [34:00];
- Whole genome sequencing [39:30];
- Germline mutations and the implications for older parents [45:15];
- Whole exome sequencing and the importance of read depth [50:30];
- Genetic testing for breast cancer [54:00];
- What information does direct-to-consumer testing provide (from companies like 23andMe and Ancestry.com)? [1:01:30];
- The GUARDIAN study and newborn genetic screening [1:06:30];
- Treating genetic disease with gene therapy [1:18:00];
- How gene therapy works, and the tragic story of Jesse Gelsinger [1:22:00];
- Use cases for gene therapy, gene addition vs. gene editing, CRISPR, and more [1:28:00];
- Two distinct gene editing strategies for addressing Tay-Sachs and fragile X syndrome [1:37:00];
- Exploring obesity as a polygenic disease: heritability, epigenetics, and more [1:41:15];
- The genetics of autism [1:48:45];
- The genetics of cardiovascular disease [2:01:45];
- The financial costs and economic considerations of gene therapy [2:06:15];
- The ethics of gene editing [2:12:00];
- The future of clinical genetics [2:21:00]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Wendy Chung is a board certified, clinical and molecular geneticist and the new [Chief of Pediatrics at Boston Children’s Hospital](https://www.childrenshospital.org/newsroom/news-and-events/2023/boston-childrens-wendy-chung-pediatrics-chief)
- Wendy earned her PhD in genetics from Rockefeller University and an MD from Cornell University Medical College
- She completed her residency in pediatrics and her fellowship in molecular and clinical genetics at Columbia’s New York Presbyterian Hospital
  - Where she then served as a [Professor of Pediatrics](https://wchunglab.com/) and directed her research programs towards the genetics of obesity, diabetes, breast cancer, autism, and rare diseases
- Wendy has received numerous awards for her research, as well as for her clinical and teaching contributions, including being elected to the National Academy of Medicine
- In this conversation with Wendy, we focus on genetics from a variety of angles
- We talk about what science and genetics looked like before we could decode the human genome, as well as what we know currently, when it comes to whole genome and exome sequencing
  - This includes an understanding of the difference between clinical genetic testing and what’s available commercially
- We also speak about genetics and newborn screening, as well as a project that Wendy is involved in called [The GUARDIAN Study](https://guardian-study.org/overview/)
- We talk about genetics as it relates to a variety of conditions, including [PKU](https://en.wikipedia.org/wiki/Phenylketonuria), breast cancer, obesity, autism, and cardiovascular disease
  - Some of you may have noticed on a diet soda can, it says, “*If you have PKU, don’t drink this*”
- We ultimately talk about gene therapy, how it works, and what’s required to change a gene
  - And, of course, the future and ethics of gene therapy

## Wendy’s interest in genetics and work as a physician-scientist [2:45]

- Wendy is moving from New York to boston
- She’s going to be the Chair of Pediatrics at Boston Children’s Hospital and will be at Harvard Medical School

**You’re both an MD and a PhD, how do you balance your time between the lab and clinical practice?**

- They split about 20% clinical, 80% research, but truth be told, they’re really together
- When she thinks about things, it starts with a patient and ends with a patient
- It starts with a patient in terms of clinical seeing them
- Many times the answers aren’t obvious, and so it becomes a research question
- And at the end of the day, it has to go back to the patient
- Within that split, it signifies how much we have to learn and why research is so important to improve clinical care

**Wendy’s education**

*Did you do a combined MD-PhD or MSTP program?*

*You did your PhD first and then went to medical school*

- Wendy did a combined program between Cornell and Rockefeller
  - Since Rockefeller doesn’t have a medical school, that is done at Cornell
- She knew she wanted to be a physician scientist

**What drew you to your current field of genetics? How would you describe to somebody what it is you do in the lab?**

- Wendy was fortunate enough, early in her career, to be exposed to the National Institutes of Health
  - As an undergraduate, she was able to spend summers there
- She was a biochemistry major as an undergrad and had the ability to work on [phenylketonuria (PKU)](https://rarediseases.info.nih.gov/diseases/7383/phenylketonuria) (mostly in the laboratory)
- She was able to spend time at NIH at the hospital and seeing patients, and realized this whole paradigm, which today is really how she does things
  - Thinking about how these pieces fit together

> “*I couldn’t really think about the science without thinking about the patients, and I couldn’t move forward and fill the gaps in our knowledge for patients unless I did the science.*”‒ Wendy Chung

- She happened to be good at both, and so it was natural for her to do both
- She was young and not so worried about the number of gray hairs by the time she finished
- So she set out on this relatively long training path, but one that suited her extremely well

## The genetics of phenylketonuria (PKU), a rare inherited disorder [5:15]

**PKU is a good introduction to a genetic disease**

*Tell folks what it is and how frequently it occurs*

- [PKU](https://en.wikipedia.org/wiki/Phenylketonuria) stands for phenylketonuria and it was how we started newborn screening
- It was a paradigm in terms of patients and families really working together to improve care and being very much partners in that
- As a biochemistry major in the late ‘80s, Wendy was interested in the biochemistry of PKU, but she realized that a lot of what she was doing was genetic sequencing to understand the genetic basis of this what we call a [Mendelian](https://en.wikipedia.org/wiki/Mendelian_inheritance#Mendelian_trait) or [single gene](https://en.wikipedia.org/wiki/Genetic_disorder#Single-gene) condition
- In this particular case, we did know the gene responsible for PKU
- But there were so many other things that we were seeing that we didn’t yet know the genes for these underlying conditions
- It was coincidental and fortuitous that the year she started her MD-PhD program was the year the [Human Genome Project](https://www.genome.gov/human-genome-project) was announced
- She had the foresight (or good luck) to be able to see that it was going to be a brand new future, when we would have that entire encyclopedia of information to be able to think about human disease differently
  - And thinking about opportunities in the future and what one could do with the information when we had it
- She really planned her career in thinking about what she’d be able to do 10 or 20 years after she started
- She’s spent a lot of her time using that information and trying to apply it to health

**What is the clinical manifestation of PKU?**

- Phenylketonuria is a bittersweet condition, in the sense that it can be associated with intellectual disabilities, if not treated early
  - Early detection allows treatment with a diet that is restricted in [phenylalanine](https://en.wikipedia.org/wiki/Phenylalanine) (one of the amino acids that we see in proteins)
- Individuals with PKU can’t digest phenylalanine and get rid of the toxic byproducts
- If we restrict that, we can prevent those toxic byproducts from building up in the body and essentially poisoning the brain
- It’s tragic because Wendy has identified individuals who weren’t picked up through newborn screening
  - For instance, she has picked up through some of her research studies, teenagers who had irreversible intellectual disabilities
- But we can prevent those types of problems, if these children are identified as newborns
- That is what our whole newborn screening program was originally predicated on: early diagnosis, early intervention, changing lives, improving lives
  - And we do that extremely well for most individuals with PKU

**Is PKU a dominant gene and is it fully penetrant or is there any variability in that?**

- It’s a [recessive condition](https://en.wikipedia.org/wiki/Genetic_disorder#Autosomal_recessive), meaning it takes two to tango, both your parents are carriers for that condition
- Within this, there is a spectrum, so we have individuals that are what we call hyperphenylalaninemic: so they don’t technically have PKU, they’re not symptomatic, they wouldn’t have problems with intellectual disabilities, but it’s a spectrum of severity
- Beyond a certain threshold, you have too much of the toxic buildup, and that’s when you end up with the problems in terms of brain function
- But there are some individuals who have subclinical phenotypes, that is you could see it if you bothered to measure the amount of phenylalanine in their blood, but they have enough of the enzyme to be able to clear the toxic byproduct

***That becomes one of the tricky things for us to do in screening newborns, is to decide where that threshold is, to adjudicate this and figure out who needs treatment***

**Is the screening that’s done on newborns a genetic screen where you’re looking for two copies of the gene?**

- - The traditional method, in the very old days, was based on looking at bacteria and how they would grow on agar that was depleted of phenylalanine
    - From a heel prick on a baby, you would use a little dried blood and spot that onto a bacterial lawn and see where the bacteria would grow
    - This was how the screen was done in the late ‘60s, early ‘70s
  - We’ve gotten more sophisticated in our ability to directly measure phenylalanine and we now do it with a process called [tandem mass spectrometry](https://en.wikipedia.org/wiki/Tandem_mass_spectrometry)
    - This still uses that dried blood spot from a heel prick
  - In a program recently started called [GUARDIAN](https://guardian-study.org/overview/), there is an orthogonal way of being able to screen based on looking at the DNA
  - So now there are two different data streams coming in to help with the adjudication of deciding who needs treatment and what is that threshold
    - This helps improve the test parameters, both sensitivity and specificity, to allow them to identify with greater certainty the babies who need treatment

- **Peter’s takeaway** ‒ the reason you don’t just rely on say a genome sequence at the moment is because that wouldn’t tell you about the [phenotype](https://en.wikipedia.org/wiki/Phenotype) fully

- - Even though you know what gene to look for
  - The phenotype is just as important (maybe more) as the [genotype](https://en.wikipedia.org/wiki/Genotype) as you make a clinical decision about dietary restriction

**Wendy agrees that’s very insightful, and it might be a subtle thing for some people so she’s going to repeat it**

- We are really good (not perfect) at reading out the DNA sequence
- So being able to decide based on the DNA sequence alone of the relevant gene (phenylalanine hydroxylase) if you have disease, we’re not able to perfectly make that one-to-one correlation about whether or not you’ll be beyond the threshold of disease (in terms of phenylalanine levels)
- The phenotype is the level of phenylalanine in the blood, and we have to have that phenotype before we get to the phenotype of intellectual disabilities
  - And intellectual disabilities is what we’re trying to prevent
- Phenotype alone is also imperfect ‒ depending on what you’ve eaten, your phenylalanine levels fluctuate during the course of the day
- Phenylalanine levels are measured as a cross-sectional, one time, and you might happen to get a baby at just the wrong time or just a sort of higher level
- And so, being able to have both of those data streams (genotype and phenotype) come in allow us to be even better in terms of the accuracy

**Is the amount of phenylalanine in a Diet Coke clinically significant?**

- If you look at a can of soda or anything with aspartame in it, it always presents this warning, “*If you have PKU, beware.*”
- The absolute amount of phenylalanine in a minuscule amount of aspartame in Diet Coke or something seems really small

*Are even milligrams of this amino acid problematic for those afflicted with PKU?*

- People with PKU have to be really careful
- They have a very special diet
  - No diet soda
  - Nothing with aspartame
  - It’s not a fun diet to be on, and many people don’t want to be on that diet for life (it’s not the tastiest)
- In particular, when women become pregnant, not only are they influencing their own body, but that of the fetus developing inside
  - They have to be quite careful with their diet
- Because of that, from a labeling point of view, we want to make sure they’re aware of what’s in different food products
  - Because they won’t feel the effect right away
    - It’s not as if they’d get a headache or something
    - We don’t want to see the effects on the developing fetus later on

*Amino acids show up in all sorts of places. Are there actual protein sources that are completely void of phenylalanine?*

- We don’t exclude 100% phenylalanine, so it’s a low-protein diet in general
- We still need some protein, and you must have some essential amino acids for your body to be able to grow
  - You need to make muscle, especially as a developing child, so we don’t completely restrict
- It’s actually a titration
- We make dietary interventions and we check, and then we go back and forth to be able to get it just right
  - It’s a lifelong treatment in that way
  - It becomes even more critical for young children, as both their brain is developing, their body is developing
    - We have to get it just right
    - It’s not trivial to do, but on the other hand, when we’re good about it, children grow up very healthy

**If you come off the diet later in life, will you still suffer cognitive changes or are you most sensitive to those during development (childhood and adolescence)?**

- You’re most sensitive during childhood when the brain is growing and when you’re making those synapses and connections and being able to develop all of the things you’re learning to do
- Some people (adults in particular) will tell Wendy about differences that they have in terms of clarity of their thinking and other things, if they’re totally off the diet and not restricted whatsoever
- But it is different in the sense that you don’t crash and burn instantaneously, it’s more subtle in terms of what you feel, how your body feels

**Are there any benefits in having one copy of this gene [the disease variant that causes PKU]?**

- Peter notes that for some recessive conditions (such as [sickle cell anemia](https://en.wikipedia.org/wiki/Sickle_cell_disease)), having one copy of the disease gene (and therefore not having the full phenotype) poses an advantage and helps to explain the propagation of the gene

*Is there any analogy to be made here?*

- Not that we know of
- Wendy doesn’t think that we know everything, but it’s not so obvious in terms of the frequency of these mutations
- Obviously, there are huge detriments to having two copies of this gene
- There are historical reasons where we see PKU in certain parts of the world versus others

***As far as we know, there is no selective advantage to the PKU gene variant***

**Is there an ethnic distribution of PKU?**

- There is, we tend to see PKU more frequently in Ireland
  - Sub-Saharan Africa is an example that has to do with historical reasons where variants occurred, migration patterns of how people migrated around the world
- We see PKU in all four corners of the world, everywhere
- Newborn screening for PKU is pretty universal throughout the world

**Just to paint the contours of it, in Ireland, what’s the frequency that a child is born with this?**

- Wendy would have to look this up but guesses it’s on the order of 1 in 5,000 or so [[GeneReviews](https://www.ncbi.nlm.nih.gov/books/NBK1504/#pku.Clinical_Characteristics) states a prevalence of 1 in 4,500]
- In the US is is a little bit less than that, maybe 1 in 10,000
  - Which is still a pretty common condition, relatively speaking

**In your career, do you think PKU will be a target of gene therapy?**

- This is something Wendy thinks about a lot
- Inborn errors of metabolism are conditions like PKU, but also other things that have to do with the way the body digests/ processes/ metabolizes food
- And some are easier targets for gene therapy
- Many of these genes are expressed in the liver
  - Think of the liver as the metabolic “brain” of the body or the metabolic “clearinghouse”
- The liver is a relatively easy place for gene therapy to target
- For certain conditions that are recessive conditions characterized by the loss of function, you have to add back the missing enzyme (or protein), but you probably don’t have to get it to 100%
- Peter alluded to carriers for these conditions
  - Individuals who have one copy of the gene that’s working fine but one copy of the gene that is not [it’s the recessive disease variant]
  - Carriers tend to be fine, and this means for gene therapy, “*You don’t have to be perfect, you have to get some in there… (enough) but you don’t have to get 100%.*”
- These types of conditions are interesting as gene therapy targets, given that the treatment is lifelong (that kind of stinks)
  - Gene therapy could be transformational in terms of quality of life for many of these metabolic disorders

***Wendy would not be surprised if within our lifetimes people will be trying genetic therapies for PKU***

## The evolution of genetic research: from DNA structure to whole genome sequencing [18:30]

**How did you do genetic work during your PhD?**

- Wendy got her PhD in the early ‘90s about a decade before the human genome was sequenced
- We obviously understood the structure of DNA and that DNA was a template that was used to make RNA, and that RNA was then used to make protein (the axiomatic principle of life)

*Explain the differences between sequencing, protein gels, and what the state of science was a decade before the human genome was sequenced*.

*And also, if you can remember, speculate on what was believed to be the outcome of the human genome sequence and how that differed from what was actually found.*

- When Wendy first started her PhD, they didn’t have machines that would cycle between the three different temperatures needed for PCR
  - [PCR (polymerase chain reaction)](https://en.wikipedia.org/wiki/Polymerase_chain_reaction) is a molecular xerox machine we use to amplify DNA to then use it for sequencing and other things
  - Automated [thermocyclers](https://en.wikipedia.org/wiki/Thermal_cycler) are used to change the temperature for different stages of this amplification process
    - Heat it up to denature the DNA
    - The enzyme [polymerase](https://en.wikipedia.org/wiki/Taq_polymerase) would work at a different temperature, so you’d have to bring the temperature down
    - There were three different temperatures that you would go through for 30 cycles
  - Imagine the cheapest labor as a graduate student: you’d have an ice bucket, a heating block, and a water bath to provide these three temperatures
    - You’d essentially be a robot literally moving samples
- The early days of DNA sequencing used radioactivity
  - We’d have these gels and we’d be reading out these ladders of sequence
  - It was all very manual and not very high throughput
  - Wendy certainly did that, reading out the phenylalanine hydroxylase gene to be able to see all of this

**Technological advances were necessary for the Human Genome Project**

- But if you think about scale and what was necessary to do this for three billion base pairs, there was no way that that could be scaled
- Whole industries evolved in terms of being able to do this in a more automated way, and really the whole world organized itself around ways to do this massive project
- In the early days, we had different chromosomes that were designed to different areas
  - So Columbia used to be the chromosome 13 center of the universe, in terms of being in charge of that
  - That meant that chromosomes are ordered by largest, so chromosome one is the largest chromosome
  - So you’d have some groups that had bigger jobs than others, but we would spread these around, and different groups would come together from around the world for a chromosome 13 meeting, for instance, and try and compare notes
- We would have things that we called [yeast artificial chromosomes](https://en.wikipedia.org/wiki/Yeast_artificial_chromosome), in which we’d literally, under a microscope, dissect out these chromosomes and put these into these constructs, so that we could make more of the DNA and be able to go through and sequence these
- There have been transformational technologies that have allowed us to go through in terms of higher throughput, greater processivity

***But one of the things that the Human Genome Project did in the early days that was really important was data sharing***

- Data access, really being able to make the world come together by allowing large groups of people to work together
- It wasn’t every person for themselves, it really was a scientific enterprise collectively, and that’s a fundamental principle in which many of us as genomicists believe very firmly in
  - Data sharing, privacy, and protecting individual patients, individual participants
  - But yet, be able to make data freely available as immediately as we can, so that we can all use it and get smarter together and learn from each other and be able to advance science as quickly as possible

**The history of the structure of DNA**

- Peter remembers one of the most interesting books he read in medical school was [*Double Helix*](https://www.amazon.com/Double-Helix-Scribner-Classics-Watson/dp/0684852799/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1690915266&sr=8-1)
  - It’s a short but fascinating and gripping story of the discovery of the structure of DNA
- Peter thinks that now we are so far removed from how much ingenuity was required to figure out that structure
  - And how that laid the foundation for all that came
- The structure was solved in 1953
- In the early days, there were arguments about whether humans had 46 or 48 total chromosomes because it was hard to visualize them
  - Eventually we were able to separate them by size and banding pattern and understand that there were 23 pairs of chromosomes
- Credit for the structure of DNA is typically given to [Watson and Crick](https://en.wikipedia.org/wiki/Molecular_Structure_of_Nucleic_Acids:_A_Structure_for_Deoxyribose_Nucleic_Acid), but really there were four people that played a pivotal role in this

*What was the breakthrough that allowed them to under the structure of this molecule [DNA]?*

- This is not Wendy’s speciality
- They had to get a high enough resolution of the crystallography structure
- It was quite technical and there were some unsung heroes in this story
- It’s remarkable to look at the 2-D images that were captured and understand the mathematics and the picture to understand that this had to be a double helix
- It’s interesting when you go back and look at some of the other proposed ideas
  - Each one had a shortcoming
  - Each one made sense, until you realized it wouldn’t project in this way or that way

**What was the first human gene identified?**

*How long after the structure of DNA?*

*More importantly, what were the methods used to identify a gene, long before we had sequencing?*

- There were biochemical things that were done
- For example, with [sickle cell disease](https://en.wikipedia.org/wiki/Sickle_cell_disease) we knew about proteins and used [protein electrophoresis](https://en.wikipedia.org/wiki/Gel_electrophoresis_of_proteins) to be able to see that
  - We understood this at the protein level well before we knew it at the DNA level
- Other cases we knew based on enzymatic activity, and we could see biochemically in a test tube the reaction that was run
- We knew about many of those things before we knew the exact DNA sequence or what genetic variants caused those conditions

**When you were a graduate student, how much resolution did you have into what a gene looked like?**

- This was before the human genome was sequenced
- It was around the time that [Rudy Leibel](https://www.ihn.cuimc.columbia.edu/profile/rudolph-l-leibel-md) was figuring out what [leptin](https://en.wikipedia.org/wiki/Leptin) is
- Wendy remarks, “*It was pretty painful at the time.*”
- We would use these things called [linkage maps](https://en.wikipedia.org/wiki/Genetic_linkage#Linkage_map) to try and figure out what chromosome a condition was on
  - Linkage analysis allowed you to get to the right neighborhood, the right zip code, eventually the right address
- When we did this, we didn’t have great sign posts, to be able to even figure out where we were within this
- We didn’t have things like structures of genes, references
- As you were doing this, you were sequencing not just one person with a disease, but also you had to sequence “normal” people (or average people) for comparison
  - We didn’t have that as something you could just look up online
- At the time, we didn’t have the internet to be able to have investigators work together from around the world
- It was much more sort of old school, passing papers back and forth, and meeting in various locations

***It was a lot slower, a lot more laborious***

- Peter mentioned Ruby Leibel, he did have this big, bold idea in terms of cloning a gene for obesity
- And the first time he put in a grant putting out that idea, people thought it was totally ridiculous
  - The idea that you could identify a gene solely based on its position within the genome (we called it [positional cloning)](https://en.wikipedia.org/wiki/Genetic_screen#Positional_cloning)
  - Understanding and not requiring of the biology or physiology, but just purely based on genetics and genetic mapping
    - People thought it was impossible to do, but subsequently, a whole generation of scientists found diseases that way
  - If you can imagine that process was often a decades long process or longer
    - This was not something you did very quickly
- Wendy often tells people, “*The first gene that she cloned took eight years. The last gene she cloned took eight hours.*”
  - So this is just absolutely astronomically different in terms of how we now find disease genes
- Peter notes, “*The speed that you’re describing even exceeds* [*Moore’s Law*](https://en.wikipedia.org/wiki/Moore%27s_law)*. It’s on a Moore’s Law trajectory with an enormous step-function when high-throughput sequencing came along (which we can probably get to later)*.”

**What was the first organism for which we had a whole genome sequence?**

- It was certainly a microorganism
- Wendy doesn’t remember if it was *E. coli*, but it was definitely a very small organism [[Wikipedia](https://en.wikipedia.org/wiki/Whole_genome_sequencing#:~:text=The%20first%20organism%20whose%20entire,to%20their%20small%20genome%20size.)]
- Yeast were another important part of our library
- Being able to understand those small organisms is easier
- When it comes to the human genome, even though the [Human Genome Project](https://www.genome.gov/human-genome-project) has been finished, there are still things we have to discover
  - Only recently have we been able to sequence [telomere](https://en.wikipedia.org/wiki/Telomere) to telomere, including some of the cryptic portions of the chromosome that are hard to read through
- The sequence of the human genome was first announced around the year 2000

## Insights and surprises that came out of the Human Genome Project [28:30]

**Based on the understanding of how many genes far simpler organisms had, what was the expectation of how many genes the human genome would have?**

- Some people thought it would have as many as 100,000 genes

***Current estimates are about 20,000 genes***

- But the complexity at the level of an individual gene is probably more complicated than we appreciated
- Our ability to have different versions of genes (what we call isoforms)
  - The way genes are cut and pasted together
  - Or how they’re utilized in different ways over time and space by different organs or cell type
  - Any one gene could be made into a dozen or more different gene products

***And so, some of that complexity was not at the level of the individual gene, but how that gene is reused in slightly different ways***

- It was shocking the first time we appreciated that it was about 20,000 genes in the genome
  - There were definitely people that were surprised by that
- Peter adds, “*It seems like such a small number given the variation between individuals.*”
  - Outside of identical twins, we have about eight billion people on this planet, all with distinct genomes

**And yet, how similar are we all, genetically?**

- We’re all 99.9% the same
- Wendy adds, “ *About 1 in 1,000 base pairs is what you and I probably differ by, on average*.”
  - Most genetic variants (differences that we have) are not meaningful
  - Most of these variations don’t cause any differences in the way our bodies function
- On the other had, something as subtle as 1 in 3 billion base pairs can be the difference between life and death
  - The difference in the way the body or the brain functions

***So, small nucleotide differences can be profound depending on what genes and when those genes work***

**Peter’s takeaway** ‒ the human genome has 3 billion base pairs, 20,000 genes, with 46 chromosomes providing the hierarchy of organization

**Explain the difference between coding and noncoding portions of the gene**

- When you think about all of those A’s, T’s, G’s and C’s that you talked about, it’s a relatively small portion of that information that gets moved from the DNA to the protein
  - The portions of the DNA that are made into the proteins are about 1.5% all of that DNA sequence (an easy round number)
- For that other 98.5%, there’s a lot of it that we have no idea what it does
  - There’s certain portions we do understand they’re very important for regulation, to know where and when and how much that gene is expressed
  - There may be other things that are subtle in terms of being able to attract binding factors, transcription factors, other things that may modify the DNA (make biochemical changes to the DNA itself) which may affect [gene expression](https://en.wikipedia.org/wiki/Gene_expression)
  - There are repetitive sequences that probably don’t do anything positive for us but get carried along in the ride that people have called “*junk DNA*”
  - ***We don’t know everything about this and there may even be disease causing variations in that space that we haven’t recognized yet***

> “*It’s a small minority [of the human genome] that actually encodes ultimately what we think of as most of what forms the body, physically forms the body in terms of proteins.*”‒ Wendy Chung

**In 2000, when the Human Genome Project results were announced, what fraction of those 3 billion base pairs were identified?**

- Wendy estimates the answer to be around around 70% or so

*Did that include all of the coding segments or was it not yet understood at that time what fraction of those were coding and non-coding?*

- The majority of the coding sequence was identified at that time
- There were a few portions of the genome that were hard to read out for various reasons
  - Or hard to map and put the pieces together
- One of the things for the listener to realize is that there was a bit of a jigsaw puzzle
  - When we did (and when we do) the sequencing in many cases were not sequencing telomere to telomere (or end-to-end along the chromosome)
  - So it’s not as if we get one continuous strand of the DNA sequence that comes off the sequencers where we can just read through it
  - In many cases, we have pieces of it and we have to informally put the pieces back together and put it back into the right order
    - In some cases, that’s because we have overlap between those pieces and so we can see based on overlap, this is the first piece, that must be the second piece, that the third piece based on the overlaps
    - And so we make these things called [contigs](https://en.wikipedia.org/wiki/Contig) (or contiguous sequences of DNA) and put the puzzle and the pieces together in that way
- There are certain regions of the genome that are complicated called repetitive sequences
  - And they may not be unique
  - And it may be hard to even sequence through those regions
  - So putting those pieces back together in the right order in some cases has been challenging to do
- Sometimes you’ll hear some of us as geneticists say there’s “*dark matter*” or there’s some “*cryptic regions*” of the genome that we haven’t been able to really dig into, and that’s because of some of these complexities of the sequences there and our ability to sequence through them

***So even despite what you’re saying in terms of knowing the genes or even knowing portions of the sequences, we didn’t necessarily know that it was all part of one gene or that we had all the pieces or put it all together yet***

- As a result, some genes and some disease were easier to crack than others

## Overview of various types of genetic tests: direct-to-consumer, clinical, whole genome sequencing, and more [34:00]

**What’s the difference between someone who goes out and gets a whole genome sequence and someone that goes to one of the over-the-counter sequencing services like 23and Me?**

*What’s the difference in the analysis and what’s the difference in the information?*

- Wendy points out, “*This is an important question, and if people are listening, this is time to perk up and listen closely.*”

***There’s a big difference and not all genetic testing is the same***

- Wendy is not being critical of any of the companies, but realize they’re trying to serve a different purpose
- Using [23andMe](https://www.23andme.com/) as an example (or [ancestry.com](https://www.ancestry.com/?_gl=1*1rux2ry*_up*MQ..&gclid=CKDI6eWYvoADFSoRiAkdII8N8A&gclsrc=ds)) those are not medically targeted
  - They’re not trying to answer a specific medical question of:
    - Do you have an increased risk of breast cancer?
    - Do you have an increased risk of heart attack?
  - They’re really not getting at that level of detail
- Ancestry.com is very good at being able to understand your heritage
  - Literally where your family is from, where your ancestors are from
  - It’s quite detailed at this point in terms of being able to say what part of the world your family comes from
  - For example, if you were adopted and don’t know about your heritage or ancestry, it would be able to give you some of that.
  - If you’re trying to find this out, you may identify some of your blood relatives, some people who you would know from a family reunion and some people you might not know for some reason
  - Even people who are adopted can sometimes find their birth parents that way
  - But this not for the intention of identifying information for a medical purpose
- About these over-the-counter services, Wendy emphasizes, “***I just want to warn the listeners that if you get something back, or more importantly if you don’t get something back from those tests, it doesn’t mean an all clear for your health. It doesn’t mean that you’re free of cancer or won’t have any increased risk.***”

**There are other tests that are really designed for a medical purpose**

- Many listeners may have gotten a test for instance, if they were thinking about having children (**family planning**) and wanted to know if they were at increased risk of having a child with something like [Tay-Sachs disease](https://en.wikipedia.org/wiki/Tay%E2%80%93Sachs_disease) or [cystic fibrosis](https://en.wikipedia.org/wiki/Cystic_fibrosis)
  - One of those other recessive conditions that we alluded to
  - This is not necessarily about abortion, but this is about being able to care for a child long-term and think about reproductive options
- Another common use-case is for thinking about **cancer risk**
- Some people may have a family history of cancer
- People may be concerned due to their particular heritage (Jewish ancestry for instance) because they know there’s a higher chance of having a [*BRCA1*](https://en.wikipedia.org/wiki/BRCA1) or [*BRCA2*](https://en.wikipedia.org/wiki/BRCA2) mutation [which increases the risk of breast cancer]
  - Some people will do a very targeted test to answer a very specific clinical question
- It’s answering that question, it’s not necessarily giving a genetic “clean bill of health” for everything
  - It’s focused

**The difference between a whole genome sequencing and exome sequencing [37:30]**

- Genomic includes all the [genes](https://en.wikipedia.org/wiki/Gene)
  - It’s not focused on just a handful of genes
  - It’s focused on the genes in the genome (those 20,000 genes)
- You can look at the coding regions (discussed earlier)
  - Looking at the regions of DNA that encodes protein sequence, we call in that aggregate an [exome](https://en.wikipedia.org/wiki/Exome)
  - The littles pieces that code the genes are called [exons](https://en.wikipedia.org/wiki/Exon), and all of them together in aggregate is called the exome
- Other individuals are interested in knowing all 3 billion of their base pairs (their entire genetic sequence, and we call that a [genome](https://en.wikipedia.org/wiki/Genome)
  - That will include everything, bot the coding and noncoding regions
- Wendy thinks of a **genome sequence** as being in some ways THE genetic test; it’s all encompassing
- One can blind yourself to look at very focused subsets of genes based on a clinical indication, or you can look at everything
- Maybe you want to look at everything about your health or maybe you don’t know all of the genes for your particular symptoms and you have
  - There are many conditions that are genetically heterogeneous (or have many different genes that can cause them), and so we want to be all encompassing in terms of looking at that

**Even though we can sequence all that data right now, we can’t interpret it all**

- Out of those 20,000 genes, we have now assigned functions with disease for about 7,000
  - That still means that for over 50% of those genes we don’t know of a gene-disease association
- This happens to Wendy with fair frequency, “*Even when I think I know about an association of a gene with a disease, if we study it further we’ll realize that they don’t map just one-to-one. There may be more than one disease associated with a gene. And so there’s still things that we’re figuring out about what those genes do*.”

## Whole genome sequencing [39:30]

**Peter has had a whole genome sequence done**

- It used one or two tubes of blood, 10 cc at the most
- It was sequenced at a university as part of a clinical trial

*What did that university do with his blood to read the 3 billion base pairs that make up his whole genome?*

- Wendy is guessing they took the [white blood cells](https://en.wikipedia.org/wiki/White_blood_cell) in that tube of blood and extracted what we call the [**genomic DNA**](https://en.wikipedia.org/wiki/Genomic_DNA)
  - The DNA included in each nuclei of those white blood cells
- Depending on how they did this, they may have captured out specific fragments and then read through all of that using what we call [short read sequencing](https://en.wikipedia.org/wiki/Massive_parallel_sequencing)
  - That short read sequencing was probably less than 100 nucleotides for each little fragment
- As they did that, they then had to do that informatic computational step of putting all of those pieces together
  - And in most cases, they were probably able to do that because they had a reference sequence (they knew what the average person looked like) and they put your sequence right on top of that
  - And to the extent that those mapped uniquely, they could put that all together
  - There may have been some of Peter’s sequence where they didn’t know where it fit, and that got put aside in an area that they didn’t even analyze
- Whole genome sequencing is very technical, and we’re not perfect at doing this
  - There are times when there is information put to the side that hasn’t been used
- As they were able to read out the sequence and put the pieces together, depending on the purpose of the analysis they could say:
  - Whether or not you have PKU by looking at the phenylalanine hydroxylase gene
- As mentioned earlier, everyone has differences in sequence about every 1 in 1,000 base pairs
- They can see a difference, then they have to do an interpretation

***The interpretation is actually a lot more sophisticated than one might imagine because there are literally tens of thousands of genetic variants in your genome, and what they mean, and whether or not they do anything whatsoever is hard to know***

> “*Each of us has what people think of as mutations or genetic variants that are associated with disease and cause a problem*.”‒ Wendy Chung

- Some of these genetic variants are very, very powerful, and some that are kind of wimpy and they infer some very small risk
- But in the aggregate, you put together a lot of these little wimpy genetic variants, and it may amount to something more substantial

**Wendy’s conclusion:** depending on when your genome was sequenced, when it was most recently interpreted, you might’ve gotten really profound powerful information in terms of taking care of yourself or you might’ve gotten the sort of, “*We don’t see much here… you go on your merry way.*”

- For the average middle age person the outcome of whole genome sequencing is mostly, “*We don’t see much here*.”
  - Because you’ve survived, hopefully as a relatively healthy person to this point, and you’ve essentially made it through some of the most devastating things we can see in the genome

**One thing Peter learned from his whole genome sequence**

- Because this was part of a clinical trial, Peter learned that he was a mosaic for a certain gene
- Everyone in his family was sequenced, and one of his children has a full copy of the gene (which they got from Peter), but he was a mosaic for it and didn’t have very much of it

**Can you explain what that means?**

- This can come up in a couple of different ways
- You would think that every cell in your body is exactly the same, but in fact, that’s not true
  - Your listeners will realize this when we think of cancer
- Our genomes are not stable over our life course from the point of conception to the point of death
  - And when you think about every cell division, if you have to copy over 3 billion letters, we’re not perfect, and we have spellcheckers to try and catch these things, but our body doesn’t always catch them
  - Over time, mutations can accumulate in the body (and of course as they accumulate) and this may lead to a variant cell growth, which is essentially what cancer is
- Cancer is at the heart a genetic disease
  - Oftentimes not from the genes you’re born with, but the changes that happen over your life course
- In certain individuals, this will be true not just of your skin cells (for instance, if there’s too much UV damage to your skin in the summertime) but this can happen in your [germline](https://en.wikipedia.org/wiki/Germline) as well (the egg and the sperm)
  - Mutations in the skin (non-germline cells) are [somatic mutations](https://en.wikipedia.org/wiki/Somatic_mutation)
- Mutations  in the germline can be passed down to the next generation
- You can have what we call a **germline mosaic**
- A mosaic is just like a tile pattern where you have some color tiles one color and some other tiles another color
  - They’re a different pattern because some cells have the mutation and some don’t
- In the same way you can have what we call **gonadal mosaics**, meaning that the germline is affected
- In some cases you can see that mosaicism in the blood as well

***So what you were talking about in terms of getting a blood sample, you might see that a certain fraction of the cells have those mutations in the blood, and then if you see them in the next generation as well, you’ll know that it was transmitted through the germline***

## Germline mutations and the implications for older parents [45:15]

**An interesting factoid: the number of mutations in the gemline actually increases over the life course**

- If you think about the biological process for spermatogenesis with men, those sperm continue to divide over the life course
  - And those mutations can continue to accumulate over the life course
- In fact, some of the conditions that are associated with de novo mutations (or new mutations), we see the frequency of that being greater for parents who are older parents at the time of conception than for parents who are younger at the time of conception
  - It’s not that it’s astronomically exponentially higher, it’s a linear process for those types of mutations
  - But we do see those increasing over the life course

**Historically, we would assume that women are more susceptible to that via age. Why is that?**

- Peter notes that the rate of either [aneuploidy](https://en.wikipedia.org/wiki/Aneuploidy) or [mutation](https://en.wikipedia.org/wiki/Mutation) seems to rise more sharply with women at an earlier age, starting in the mid- to late-30s

*Is the egg more impacted by that than sperm?*

- Meiosis in the two sexes is different, and it is susceptible to different underlying biological processes
- For women, if you look at the curve in terms of problems (aneuploidy or **chromosome differences**, namely [Down syndrome](https://en.wikipedia.org/wiki/Down_syndrome) is what many people think about), it increases with advanced maternal age
  - Essentially, that has to do essentially with the stickiness of the chromosomes at meiosis and the ability to separate or not
  - The curve that is associated with that is not a linear relationship with maternal age, but in the mid-30s it starts to increase more significantly
  - There’s a whole medical way that we can follow women when they’re pregnant to try and pick up those particular chromosome issues
- When it comes to **DNA sequence differences** (not whole chromosomes but single letters) we’re thinking about that process of being able to have the cell divide and replicate (copy over that information that happens every single cell division)
  - There is a probability that DNA sequence differences [mutations] will occur
  - That’s a linear relationship in ben based on the biology
  - From a reproductive point of view, men may have children over a larger period of time
  - We can see greater differences across men as they’re reproducing

**Do you have a clear sense why you see more of these myotic differences with age?**

*What fundamental characteristic of aging is driving that?*

- Peter doesn’t want to anthropomorphize evolution, but is it like evolution saying, “*Well, I don’t care because I don’t want you to reproduce after a certain age.. Therefore, I’m not going to preserve the integrity of your genome beyond a certain age.*”
  - This seems to be an explanation but not the reason
- Wendy has not thought of the question quite that way
- Throughout all of human history, the age at which people were reproducing and having children has skewed much younger than it is in terms of current society
- Wendy thinks we have pushed the boundaries to a certain extent in terms of what the biology historically has been
- She doesn’t know if we had a “use before date” in terms of ovaries and gonads, but she thinks this is just historically has been what’s happened
- The **fundamental biology for women** has been proteins that are responsible in terms of meiosis and separating of the chromosomes
  - If you remember when meiosis starts in females, it actually is starting way, way early in gestation, even during fetal life
  - And so those proteins have to be working/ in intact before a fetus is even born and lasting all the way through until that pregnancy is conceived
    - This is essentially when those gametes are finally dividing
  - So that could be 30, 40 or more years for that process to have to work, and that’s kind of asking a lot when you think about the biology
- For **men**, another interesting factoid is that for some of these mutations that arise during the process of [gametogenesis](https://en.wikipedia.org/wiki/Gametogenesis), there are what we call “selfish” sperm mutations
  - Certain mutations may give a selective advantage to those spermatocytes where they may have a reproductive division advantage
  - And so we may see more of those in terms of the biology of what we see in the next generation because of the effect they have directly on the sperm

## Whole exome sequencing and the importance of read depth [50:30]

- One step down from whole genome sequencing is whole exome sequencing

**If one wanted the whole exome sequence, are they actually doing the whole genome sequence and just reporting out the exome? Or is it something technically different?**

- You have to read the fine print on your genetic test report or your clinical trial consent or whatever it is
  - Wendy doesn’t know the answer without knowing that
- It certainly was the case that a few years ago, it was so expensive to sequence a genome that we rarely did
  - It was really just cost prohibitive
- The exome was a really good shortcut because we didn’t know what a lot of the other information meant anyway, so it would’ve been just throwing it away
- Increasingly, we have a better sense of what the non-coding regions do
  - We have a better ability to interpret and recognize genetic variants

***As the sequencing costs have been coming down, there’s more of a shift to going to genomes rather than exomes, but truly most of what is medically used at this point is in the coding space***

- So even if you’re sequencing a genome, it’s still focused on the coding regions

**On a research basis it’s very different**

- And of course, we have to do research before we can apply it clinically
- A lot of the research now is understanding what all of those regions do and being able to eventually use that information clinically
- Wendy thinks within the next decade we’re going to see a shift (and we may even shift from this) from what we call **short read sequencing** of these 100 base pair fragments, to things that are much longer in terms of accuracy,
  - To be able to read through some of the areas that are more complex and probably that we’ve been missing out on before

**What’s the technical limitation for making that longer [than 100 base pairs]?**

- There is just lower and lower fidelity for each base pair that you do
- So at some point you start getting errors within your readout

***You don’t want to have too many errors because you can’t distinguish between what are true biology versus what are artifacts of what you’re doing in the laboratory***

**How are you correcting the errors?**

- If you’re getting even one error in one short read sequence, given that we only differ from each other by 1.5% of those base pairs
  - For example, you wouldn’t be able to use this information in court
  - How do we preserve the fidelity of this to make such bold claims as, “*Hey, we found this blood at the scene of the crime and we absolutely know positively it belongs to this individual?*”
- Sequencing is not done just once
- We have a term called **read depth:** ***it’s how many times we look at any one nucleotide in the genome, and we don’t look at each position just once***
  - Depending on how much we want to spend doing it we might look at the read depth of 30x, so we might look at every one position on average 30 times
    - And if you see out of the 30 times 29 of 1 nucleotide, 1 of the other, you say, “*Oh, that one, the oddball there, that’s probably just a sequencing error. That’s an artifact of our method in the lab. The other 29 or the ones that we want to pay attention to*.”
- For example, in cancer, it becomes very important to know those somatic mutations that weren’t there from birth that
  - They may be there in a small number of cells, but cells that can be very, very dangerous for cancer
  - And so we may increase the read depth to be very, very high
    - We may go up to 1,000x in terms of read depth to make sure we’ve got the accuracy to see something reproducibly even in 10% of cells
  - But again, you need 10% of a large number to have the assurance that what you’re seeing is in fact representative of the underlying biology, not an artifact

## Genetic testing for breast cancer [54:00]

- [BRCA1](https://en.wikipedia.org/wiki/BRCA1) and [BRCA2](https://en.wikipedia.org/wiki/BRCA2) was mentioned earlier

**When a person wants to be tested for breast cancer genetics, is the DNA still taken from white blood cells?**

- These days we do things lots of different ways
- We’ve tried to make everything we do more accessible
- We can do things from cheek swabs, from saliva samples, from blood samples
- We try to make it less invasive and easier to do (even potentially from home)

**When we do a breast cancer genetic screen, how many known genes are we looking for?**

- It’s your choice either as a doctor ordering the test or as a patient getting the test
  - It’s a little bit a la carte
- In some cases you know you have a family history of *BRCA* mutation and so we may know the exact address to go to
  - It’s a very simple plus/ minus readout
  - And we don’t have to do a whole genome sequence for that
  - We just need to look at one gene and say yay/ nay for that particular variant
- Certain variants are seen in certain communities
- For example, if you happen to be [Ashkenazi Jewish](https://en.wikipedia.org/wiki/Ashkenazi_Jews#Medical_genetics), there are three different spots in *BRCA1* or *2* that account for the vast majority of all mutations in those two genes
  - And if you know that, we can take a shortcut and for literally a small fraction of the cost of sequencing a genome, we look at those three spots
    - We get yay/ nay, and you’ve got most of the information that you need
- There’s some people who come in with a family history of breast cancer and they say, “*But I want to be careful,*” and so in that circumstance we may do a panel of 50 different genes
  - 50 different genes that’ll cover most of the genes that we see for hereditary, not just breast cancer, but ovarian cancer, colon cancer, the most common cancers that we see that are driven by germline or inherited genetic factors

***So for round numbers, 50 [genes] is a good number when you’re trying to be really comprehensive; if you said, “Just give me the focused breast cancer things” it might be more like 10***

**5% of cancer is accounted for by germline mutations, while 95% of cancer is accounted for by somatic mutations. Is that still accurate?**

- Wendy is going to modify that just a little bit for genes she’ll call **monogenic highly penetrant**
  - Monogenic means single gene
  - Highly penetrant means there’s a high probability that over the life course you’ll develop cancer if you have this particular genetic variant
- So when you limit yourself to that, yes, about 5% of cancers are due to those powerful single genes, high probability of cancer
- Now, on the other hand, over time we’ve realized that there are additional genes that I’ll call **moderate risk genes**
  - Many of those genes may confer something like a two to threefold increased risk as opposed to something like a tenfold increased risk
- So there’s another probably 5% or so that are due to those [moderate risk genes]
- Then there’s this other thing that we call **polygenic risk**
  - Poly meaning multiple and genetic means genes
  - This refers to multiple genes
  - The number of genes we often look at in those circumstances may be anywhere from 100 to hundreds, or even thousands of genetic variants
    - All mathematically summed together to understand what the risk is associated with that package

> “*All of us have genetic variants that go into that polygenic risk.*”‒ Wendy Chung

- Part of the question is: along a distribution, are you at the high end of that risk curve or are you at the low end or at the average end?
- And so within that, this is now something that is *not* clinically being utilized routinely, but we are on a research point of view trying to understand clinical implementation for now ‒ those polygenic risks for cancer
- Peter assume this may amount to maybe 10% of cases, so you can say 20% of cancer has a genetic component
  - And that’s broken down into these three categories: monogenic and highly penetrant, monogenic moderate risk, and polygenic

**Back to the woman who wants to do a deep dive on breast cancer, why is it that you don’t need to look directly at breast cells?**

- Four women in this woman’s family have died of breast cancer
  - But we don’t know which genes it is because they’re deceased

*Why is it that we can infer that what we see in a cheek cell (an epithelial cell or in a monocyte in the blood) is also captured in mammary tissue?*

- Good question
- The answer is, it’s probably not
- What you’re doing with these samples is your getting at the germline
  - Mostly what you were born with
  - Inherited susceptibility
- As we talked about, your genes are changing over your life course
- Your cells are changing over your life course, and cancer doesn’t happen overnight
  - You don’t go from a normal cell to a cancer cell overnight
  - There’s a progression in terms of going through this
- There are other ways that people have thought about that called a **liquid biopsy** [see more on [episode #267 with Keith Flaherty](https://peterattiamd.com/keithflaherty2/)]
  - It’s a slightly different test than what was discussed before
- Liquid biopsies look for these somatic mutations, but when you’re looking for that “needle in a haystack”, if you’ve got a tumor that’s going to slough off some of that DNA into the circulation, you might be able to see some of that fragmented DNA floating around and you might be able to pick up some of those mutations that might be reflective of that mammary cell that’s either gone awry and is a cancer, but maybe not something that you’re detecting on mammography or something else
- In some ways, this has been the holy grail of being able to do cancer screening
- It’s not quite ready for prime time yet
- Right now, people are thinking about liquid biopsies for recurrence of cancer
  - How to monitor someone who had a previous cancer diagnosis
- The other use-case people have thought about is someone who might be at high risk of cancer
  - Someone who is identified for whatever reason (based on exposure or genetic profile)
- But liquid biopsies are not ready yet for population screening, in terms of being able to pick up cancers at an earlier stage

## What information does direct-to-consumer testing provide (from companies like 23andMe and Ancestry.com)? [1:01:30]

- Based on cost, these companies are obviously doing something far less than a whole genome sequence or even a whole exome sequence

**What are they technically doing with the epithelial cell of your cheek (or the saliva) or the white blood cells that they get?**

- Wendy advises, “*Read the fine print of what you sign on the consent form.*”
- It may change over time
- She doesn’t represent any of those companies and doesn’t want to misspeak about what they are doing
- In general, they’re *not* trying to:
  - Detect cancer
  - Not trying to read out the genome for the purpose of getting you medical information or “news you can use” to manage your own healthcare
- They’re reading the genome in a way that Wendy calls more “recreational”
- For example, with 23andMe you may find out something about:
  - If you were to eat asparagus, what your urine might smell like
  - What your earwax might be like
  - If you’re lactose intolerant
  - Things related to how the biology of your body works
    - They are related to genetic variants
- But they’re not telling you based on your earwax if you’re going to have major problems with hearing loss down the road or cancer risk or things like that

*But what are they doing technically?*

- This depends on the company
- Oftentimes they’re reading out what we call [**single nucleotide polymorphisms (SNPs)**](https://en.wikipedia.org/wiki/Single-nucleotide_polymorphism)
- They’re not reading out the entirety of your genome
- They’re selectively going in and asking, “*At this exact address, do you have an A or do you have G? At this other address here, do you have a C or do you have a G?*”
  - And based on that, they may selectively look at those particular variants and say with your profile:
    - I know that your family originally came from Egypt or wherever it is in terms of being able to look at ancestry
    - I know this particular genetic variant may predispose you to be lactose intolerant
  - That’s generally the type of thing they’re reporting out

**SNPs**

- Peter asks, “*If a gene differs by more than one nucleotide, a SNP is not of much use unless you sample two SNPs in the same gene?*”
- This gets tricky because technically a SNP could be a genetic variant that has a big effect on a gene and from a medical point of view be very impactful
- It’s not just that size matters, as some people would say “*location, location, location*”
  - It’s like real estate
  - It all matters which variant we’re talking about

***In general, the variants these companies are looking at are not the ones that are medically impactful; they’re just the normal variants that are innocent bystanders but help us understand where our ancestors came from***

**Variants of** ***APOE*** **gene**

- Peter notes that they do comment on some important ones, such as the [*APOE* gene](https://en.wikipedia.org/wiki/Apolipoprotein_E)
- Isoforms were mentioned earlier as normal variants, and the *APOE* gene has three common isoforms that would all be considered **normal variants**
  - The 4th isoform is not relatively common, but it is one variant comes with a much higher risk of neurodegenerative disease and 23andMe does read out that prediction
- Peter reasons that if these variants differ by only one base pair, then there’s only one place they need to sample
- In 10 years, Peter has seen several instances of a SNP read that does *not* match the more rigorous exome sequence

**Why do you think that’s the case? Does that surprise you**

- Wendy is not someone who has been asked to do quality control or anything like that for laboratories
- She knows of things as simple as these are done in plates (oftentimes 12 x 8 plates), and if you flip the plate the other way, you can have sample switches
  - And you’ve got a different person being read out for a different thing
  - It can be something as simple as a logistic like that
  - She has seen this lab error before
  - There can be sample switches at multiple places

**Wendy’s takeaway ‒** ***At the end of the day, if you are going to make a major healthcare decision, before you do something irreversible (such as having a mastectomy) and you are doing something from the recreational side, get a second opinion***

## The GUARDIAN study and newborn genetic screening [1:06:30]

- Wendy has always been wanting to be able to get information that people could use to be able to maximize health and to just be the best person they could be
- She started out in the space of PKU in 1996
- For a decade, she has been studying a disease with colleagues called [spinal muscular atrophy (SMA)](https://en.wikipedia.org/wiki/Spinal_muscular_atrophy)
  - This is a neurodegenerative condition and used to be the most common genetic cause of death for children less than two years of age
- Starting in 2016, Wendy realized that we were just at the cusp of a treatment that potentially might slow down or stop the neurodegeneration
- Yet tragically, if we didn’t identify babies before they started showing symptoms, it would be too late
- We had this window of opportunity
- They started a newborn screening program for SMA
- Babies that were identified through that had the option (if they wanted to) of going to a clinical trial
  - That ended up being quite synergistic in the sense that they did identify babies who would’ve been predicted to have the most severe type of SMA
  - They got into early clinical trials right away and benefited
- That helped in terms of the ultimate evidence that was necessary to show the efficacy of those treatments
- And because we were able to show that we could do it technically and that people wanted it, SMA has been added to the recommended universal screening panel for babies across the United States
- So now 4 million babies born each year in the United States are screened for SMA, and we have three FDA approved treatments including a one-and-done gene therapy
- This got Wendy thinking on a larger scale
- Since then, they did a newborn screening study for [Duchenne muscular dystrophy (DMD)](https://en.wikipedia.org/wiki/Duchenne_muscular_dystrophy)
  - And actually just recently the FDA approved a treatment for DMD
- Wendy is getting more impatient and doesn’t want to do these one by one
- She started thinking about, “*How could we do these at scale for population health, but not just for one condition at a time, but how could we do it for dozens or hundreds or potentially even more conditions?*”
- The [GUARDIAN study](https://guardian-study.org/overview/) stands for: **G**enomic **U**niform screening **A**gainst **R**are **D**iseases **I**n **A**ll **N**ewborns

***The idea behind that is to take that same newborn screening dried blood spot that we use already for PKU and sequence the genome***

- We don’t need to read out everything in the genome
- We only read out the genes that we consent people to read
- Wendy calls those genes, “*news we can use*”
  - Information that has treatments immediately available
- In planning this study for just over four years with families, we had many, many iterations about what they wanted us to screen for
  - What should enable them to be the best parents and give their children the best chance at a healthy life
- We also thought about this dynamic change in what we’d have treatments for
  - The fact that the world is changing rapidly
  - And we wanted the flexibility that if a new treatment became approved tomorrow, boom, we could instantly change the screen and be able to implement that
    - We wouldn’t have to wait a decade to gather the evidence to do that
  - We wanted to be nimble and flexible

***The reason for using the genome as the backbone is it gives us that infinite flexibility to be able to adapt and to be able to move the field forward***

- We’ve been doing the GUARDIAN study in New York City since September, 2022, and right now have screened just over 3000 babies
- It has been remarkable to Wendy in terms of being able to see the broad support from our community in doing this
- Most of the listeners probably realize the wonderful diversity we have in New York City, that is  the people who participate
  - It’s not just White folks
  - It’s not just people who are from Ireland, earlier we were talking about Irish individuals and PKU
  - It’s people from around the world
  - We have about a quarter of people of European ancestry, of Latina ancestry, of Black ancestry, of Asian and other ancestry
  - It’s representative of the world
- It’s also geared to leave no baby behind because newborn screening is this one universal thing where everyone goes through the health system in the same way
- And by making this free and being able to allow everyone to enter if they so choose, we can really see also what information people want and what they don’t want
  - Within this one of the things that’s been refreshing to see that about 74% of parents that we approach and offer this to decide they want to do this
  - When we did this for SMA, the number was 93%, and when we did this for Duchenne muscular dystrophy, it was 84%
  - It’s not 100% of people who want any of these genetic screens, and that’s perfectly fine
  - But it’s also *not* 10%

> “*The majority of parents are saying yes, if there’s something I can do to ensure that I have a healthier child, give it to me. Help me be a better parent. Why would I not want to do this?*”‒ Wendy Chung

**Newborn screening**

- We realize that traditional newborn screening isn’t perfect
  - Wendy never thought it was, nothing ever is
- But we realize that adding this additional dimension helps us to do a better job
  - And we’ve even done it for PKU within this study
- For example, part of newborn screening identifies some children with [severe combined immunodeficiency (SCID)](https://en.wikipedia.org/wiki/Severe_combined_immunodeficiency), but a treatments is available including a bone marrow transplant
  - This is a problem where you can have an overwhelming infection and die
  - So because of that, we have, as part of newborn screening, a way to screen and identify some, but not all children that
  - We’ve now added this genome sequencing to enrich and improve that
  - In fact, we identified a baby that was missed by our traditional newborn screening for SCID
    - And now there is the opportunity to intervene at an early stage when a bone marrow transplant will be most effective
- There are numerous examples where we’ve identified disease
  - Whether it’s [Wilson’s disease,](https://en.wikipedia.org/wiki/Wilson%27s_disease) whether it’s severe combined immunodeficiency, whether it’s [achondroplasia](https://en.wikipedia.org/wiki/Achondroplasia)
  - Other conditions that are treatable, that we just needed to identify those babies
- Because Wendy has been practicing in New York City for 25 years, she knows how people navigate the system and how they get through, and we’ve been able to really get to many of the people who are usually unfortunately left behind
  - These people may be immigrants, they don’t speak the language, they don’t have the same health insurance
  - The individuals that we’re seeing come out positive for this are very, very different in terms of reflecting our community than the people who navigate the healthcare system and get in to see us

***Based on other studies that we’ve done, most of these children would’ve been diagnosed on average somewhere between 8-10 years of age, and we’re able to identify them literally a decade earlier, before a lot of damage has been done to their body***

- This is just the beginning
- Having screened 3000 babies is great
  - It demonstrates that we can do this
  - It tells us what our community wants out of this
  - It shows us some pitfalls in terms of how it’s hard to do and what we need to do, to do it better
- Groups are working on therapies and there is now an opportunity for treatment
- This is a powerful way of moving health equity forward at least for children for the next generation

**Is this something that’s done only at Columbia or is it a multicenter New York Hospital endeavor?**

- This is being done through the New York Presbyterian hospital system
  - It’s not just Columbia, but it’s through this hospital network
- Bases on the success of this, they are figuring out how to expand this more broadly
- Integrating within the public health infrastructure is not trivial to do on this scale
- For example, if we were to do this for every baby in New York state, we’d need to do it for about 210,000 babies a year

***This something that we’re gaining the experience to know what the pain points are and how to solve for them***

**Is this all funded by the NIH?**

- As you can imagine, this is *not* inexpensive to do
- None of this is funded by the NIH

> “*This ends up being about two orders of magnitude larger in costs than anything the NIH can fund.*”‒ Wendy Chung

***It’s a challenge as you think about big, bold, new transformative ideas, how do we as a scientific community accomplish these?***

- They’ve done this by putting together many different stakeholders
  - No one group could be able to take this on
- And they’re not completely there with the funding
- They need to demonstrate that they can do this with hopefully 100,000 babies
  - They need this sample size to be able to see some of these rare conditions, and to know what the outcomes are, and to know that they can really screen for them

**What is the actual cost of doing the sequence for each baby? To look at those 250-some odd conditions?**

- They started out with a round number of $1,000 per baby
  - Thinking about generating the data, interpreting the data, getting it back to folks
- The goal is to be able to do this and get it down by an order of magnitude ($100 per baby)
- And in doing that, can we think about the economic impact, most importantly, the health impact for the baby?
- We are doing the economic analysis to understand how we think about this as a society, how to be able to afford doing this
- The good thing is sequencing costs are decreasing
- More of this can be done in automated ways as we understand what normal variation is for people around the world
  - And one of the critical factors is doing that around the world
- Peter reacts, “*$1,000 is a fully loaded cost. That’s the interpretation, that’s the overhead, that’s the PI time and such. That sequencing cost must be significantly less than that given that Illumina could do a whole genome sequence for $1,000 now. Is that right?*”
- Even over the course of this study, the sequencing costs have come down
- The study began in September, 2022 (less than a year ago), but already the sequencing costs have come down
  - Wendy expects they’ll continue to come down
- So data generation certainly can be done for less than $1,000 now
- But part of it is the interpretation and the study staff who explain the study to everyone, explain results
  - It includes multiple pieces

## Treating genetic disease with gene therapy [1:18:00]

**How many of these single gene, highly penetrant conditions that children are born with have FDA-approved gene therapies already?**

- At the outset of this discussion, you mentioned that SMA has a successful gene therapy

***Not very many of them***

- The shining example is [SMA (spinal muscular atrophy)](https://en.wikipedia.org/wiki/Spinal_muscular_atrophy)
- There are very few gene therapies that are now approved
  - Examples include: [Duchenne muscular dystrophy](https://en.wikipedia.org/wiki/Duchenne_muscular_dystrophy), [hemophilia](https://en.wikipedia.org/wiki/Haemophilia), and a few other conditions
- Others have treatments available
- One example that we’ve had through the GUARDIAN study, is a condition called [Wilson Syndrome](https://en.wikipedia.org/wiki/Wilson%27s_disease)
  - That ultimately leads to liver failure and need for liver transplant
  - The treatment that we give children for this is zinc
    - We can simply use zinc to outcompete copper and make sure that we don’t end up with a copper overload situation
  - So it’s something that doesn’t require gene therapy, it doesn’t need anything that fancy
  - Treatment is very well tolerated, pennies a day in terms of doing this, and we hope extremely effective

> “*Although gene therapy is wonderful, I want to underscore we don’t always need gene therapy as long as we have that early diagnosis.*”‒ Wendy Chung

**If you could wave a magic wand, what would be the three diseases you would want to put high on the list of gene therapy targets?**

*What diseases that you see in the pediatric practice would be most amenable to gene therapy in terms of some aggregate score of the technical nature of doing the gene therapy and the lack of alternative therapies elsewhere, and the number of kids afflicted?*

- Great question; Wendy hasn’t ever thought it through in exactly that way
- There are a lot of neurological conditions
- In terms of places that we are woefully behind in terms of treatments, one shining example is [Tay-Sachs disease](https://en.wikipedia.org/wiki/Tay%E2%80%93Sachs_disease)
  - Because there’s no treatment, the way many individuals have dealt with this is simply not having children or not having children together or going through other reproductive options
  - Things like Tay-Sachs disease is just a terrible condition, and it has relatively high population prevalence and has really nothing available in terms of treatment today
  - Those children are born healthy, normal children and die within the first few years of life with a degenerative course oftentimes associated with epilepsy
- [Fragile X](https://en.wikipedia.org/wiki/Fragile_X_syndrome) is another similar condition, although we still need to understand treatability
  - It is similar in terms of high frequency and really nothing in terms of treatability at this point
  - Gene therapy for this is a little bit tricker
    - From a technical point of view, it would take a different strategy
- There is a large group of inborn errors that primarily affect the liver and cause liver disease
  - Whether you’re talking about something like [maple syrup urine disease](https://en.wikipedia.org/wiki/Maple_syrup_urine_disease) or [propionic acidemia](https://en.wikipedia.org/wiki/Propionic_acidemia)
  - We have good programs in place to identify those children, but our treatments are not as good as they should be

## How gene therapy works, and the tragic story of Jesse Gelsinger [1:22:00]

- Peter recalls, “*Probably 23 years ago we had a tragedy in one of the most highly publicized examples of early gene therapy. The tragedy of course, really didn’t have to do directly with the gene therapy. It had to do with the vector that was used to deliver it.*”
- The young man ([Jesse Gelsinger](https://en.wikipedia.org/wiki/Jesse_Gelsinger)) who received that gene had an inborn error of metabolism, a urea cycle defect called [ornithine transcarbamylase deficiency](https://en.wikipedia.org/wiki/Ornithine_transcarbamylase_deficiency)
- He was part of a clinical trial at the University of Pennsylvania in 1999
- They used an adenovirus

**Explain what that means**

*Contrast what was state of the art 25 years ago with what’s being done today*

- [Adenoviruses](https://en.wikipedia.org/wiki/Adenoviridae) cause the common cold, whether it’s adenovirus or [adeno-associated virus](https://en.wikipedia.org/wiki/Adeno-associated_virus)
- We often use that as the vector or the delivery vehicle to deliver genes
- Within this, the viruses are manipulated, they’re engineered, so to speak, so that they’re not going to be contagious
  - So even though you might get a cold or pass it along to someone, you’re not going to do that with gene therapy yet
- There are problems with this because the common cold is common, and so people may have been infected with adenoviruses and their body may try and mount an immune response when it’s infected (as it would be with a cold)
  - And that’s where a lot of the mischief comes in
- Unfortunately, it hasn’t ended with Jesse and Jesse’s death
  - There have been other deaths in the gene therapy space with others that have had a response to the vectors
    - Oftentimes an immunological response to that
- In Jesse Gelsinger case, the vector and the gene therapy was targeted at the liver
- Sometimes there can be an overwhelming response from the liver, where the liver starts to fail, where there’s an immune response that goes on
  - This has not been solved completely at this point
- There have been other genetic therapies, other diseases, not just liver diseases, but where there have been similar responses
- One of the things that we’ve learned from this is we have to be very careful with people with underlying liver disease when it comes to this, because a fragile liver can get tipped over, especially with adenovirus
- We also have to be careful about who’s been exposed to those viruses
  - Sometimes we do screens to be able to see who might have one of these responses
- Ultimately and partly because of that, people have also been trying to figure out other delivery systems, other vehicles, other ways of being able to get those genes into cells that may not be as toxic or problematic

**Why did Jesse have such a harsh response to gene therapy?**

- Adenovirus is very common, and Peter presumes that Jesse had already been exposed to some antigen related to this
  - He already had memory B cells and memory T cells that were ready to mount a healthy immune response, should he be exposed to that adenovirus again

*Was his response because of the dose of adenovirus that he received, or does it imply that he wouldn’ve had some catastrophic multisystem organ failure had he been exposed to that exact adenovirus as a cold and this was just a function of his underlying health?*

- It’s a very tricky situation
- Peter is right, there is a dose response in terms of the immunological response
  - So you don’t want to go too high on the dose because you don’t want to have too big a response
- On the other hand, with these gene therapies, you often get one chance at this in terms of doing this
  - Because once you’ve given the therapy, the body is going to mount an immune response to that and would neutralize that same therapy if you were to give that again
- So the tricky thing about this is you don’t want to go too high and you don’t want to go too low
  - If you underdose it, and if you don’t get enough in and that’s your one shot on goal, you’ve burned it
- As it is with many clinical trials when you’re first in human, you don’t know
- Oftentimes there is research in non-human primates in terms of trying to figure out as much as you can, but it’s still not a person
  - And each person is unique
- When you do the first person, you learn and you figure out from there whether you’re going to go higher or lower, but there is someone who’s going to be the first person

**Is there no way to engineer the adenovirus to make it invisible to the immune system while still able to insert its DNA package into the cell?**

- There are certainly things that we do to try and do this better
- For instance, one of the advantages with SMA is we’re dosing them at a week or two of life
  - They haven’t had the common cold, they haven’t been exposed to these things
  - They’ve got a fresh immune system, so the likelihood they’re going to have a response like this is much lower
- So we haven’t been seeing those types of things with newborns that we’ve been treating with SMA
- There are other vectors and other delivery vehicles that we use that are not viruses
  - In terms of developing new technologies, things that may not pose the same problems
  - With the experience we’ve had from the COVID vaccine, from mRNA vaccines and having delivery systems that were basically lipid nanoparticles to deliver nucleic acids to cells, we’ve learned a tremendous amount from millions of people who have been treated with that

## Use cases for gene therapy, gene addition vs. gene editing, CRISPR, and more [1:28:00]

**What is required to change a gene?**

*For example, if you wanted to use gene therapy to fix* [*sickle cell anemia*](https://en.wikipedia.org/wiki/Sickle_cell_disease) *(a one amino acid change)*

- The 8th amino acid in [hemoglobin beta](https://en.wikipedia.org/wiki/Hemoglobin_subunit_beta), there are two different variations (1 amino acid difference), and one causes sickle cell disease
- Peter points out, “*It’s not enough to do it in the red blood cells that are floating around in the bloodstream because they’re going to be trashed in the spleen a couple of months from now. You must change the DNA of the stem cells in the marrow, correct?*”
- That’s exactly right
  - You have to get those progenitor cells from which the future generations of red cells will be derived
- It’s not hard to get the correct gene sequence, and we can put that into a virus

**Why are viruses great vehicles?**

- A virus was designed by mother nature to infect ourselves, and it’s pretty good at being able to do that
- The viruses discussed are often helpful for **gene addition**
  - Where you have a protein product that isn’t working (loss of function) and you need it to be present
  - You need to be able to deliver or add back that gene
    - It may not be integrated into your genome, and there are some advantages if it’s not
- The virus can bring a gene into cells
- Many times that means bringing it into stem cells so they can have the longevity of continuing to populate the body over time

**Is it safe to say that the real challenge is that step, figuring out how to get that virus to selectively infect a progenitor stem cell within the bone marrow?**

*Is that why we don’t yet have genetic therapy for sickle cell anemia?*

- Sickle cell is interesting in that there are a couple different strategies people think of
- One is **gene editing** ‒ fixing the gene where it is
  - Not adding a gene but actually fixing the gene that’s present
- Another strategy that people think about (for the aficionados who are thinking about that), there’s also [fetal hemoglobin](https://en.wikipedia.org/wiki/Fetal_hemoglobin) that’s made in utero
  - Hemoglobin beta is the adult form of hemoglobin
  - Fetal hemoglobin can substitute for adult hemoglobin quite efficiently
    - It actually has a very tight binding of oxygen because the fetus needs to be able to get oxygen from the maternal blood
  - One thing to do is turn up the amount of fetal hemoglobin expression and essentially be the in situ version of your gene therapy
    - It’s just manipulating gene expression for a gene that’s already present
- These different strategies are very technically different in terms of what we administer to people and what we’re changing in terms of gene therapy

**If you were to add a gene for a corrected version of beta hemoglobin, would you actually run into a problem now where you’re making too much hemoglobin and half of it is appropriate and half of it is sickle?**

*Is this the real reason why nobody’s interested in doing an addition therapy for sickle cell anemia?*

- That’s exactly right

***We don’t use the gene addition strategy for sickle cell anemia because we’d have to dilute out (so to speak) so much of the hemoglobin with the sickling that physiologically we run into other problems***

*Would gene editing be the best solution for a situation like that?*

- From a simplistic way of thinking about this, you want to go in and in situ be able to correct the genetic variant

**Single nucleotide variants are the easiest ones to edit**

- There’s just one single base pair that need to be flipped
- It actually matters what that base pair is if you have to change an A to a G or a C to a T
  - Believe it or not, there are different base editors that can do different types of nucleotide switches
- But there are many mutations that are not just single nucleotides
  - There may be multiple nucleotides, there may be multiple repeats
- These are the complex things that we talked about with [fragile X](https://en.wikipedia.org/wiki/Fragile_X_syndrome)
  - There may be entire chunks of chromosomes
  - They get very complicated
- Furthermore, when you think about population genetics, you may have a mutation distribution across a gene that may be quite heterogeneous

***In contrast, sickle cell disease is easy because you’re talking about the same position for everyone with sickle cell disease, a couple different nucleic acids, but it’s the same position essentially***

- Whereas other genetic conditions, it may be that almost everyone has a different mutation
  - So you have lots of different things you need to edit and that may be easier or more difficult to do

**Nuances of gene editing and gene therapy [1:34:15]**

**Downsides of gene editing with CRISPR/Cas9**

- [CRISPR/Cas9](https://en.wikipedia.org/wiki/CRISPR_gene_editing) is something that many will know because [Nobel laureates](https://www.nobelprize.org/prizes/chemistry/2020/press-release/) were awarded for this amazing discovery
  - Which was by the way, really good science with creative women who are thinking about other ways to use it
- The discovery was not made with the intention of doing genetic engineering or genetic manipulations, but really smart people thinking about it
- The CRISPR/Cas9 system makes changes to the genome using a double-stranded DNA break
  - For this system to be able to make a correction, it has to cut both strands of the DNA
  - Fundamentally, that leads to some instability as the cell repairs that process
  - Earlier, Peter used the word fidelity, and it really is all about **fidelity and potential off-target effects** where you inadvertently introduce genetic changes other than the intended correction
    - And sometimes those other genetic changes can cause mischief
    - We call them off-target effects
- Off-target effects refer to changes CRISPR/Cas9 may inadvertently cause to other genes that you weren’t even trying to target
  - It can lead to problems of essentially promiscuity or inaccuracy or low fidelity, and Wendy points out, “*This is to me, in my opinion, the Achilles heel in terms of that particular system.*”

**Prime editing is another gene editing strategy**

- [Prime editing](https://en.wikipedia.org/wiki/Prime_editing) has the advantage of using a single-stranded DNA break
  - It’s nick just one of the two strands of a chromosome
  - The cellular machinery used for this repair is a much higher fidelity system
  - So there are lower off target effects, lower error rates
  - It tends to be a more robust system
- This is still very, very early in terms of doing this
- There are lots of other complexities in terms of the machinery to go in and make the changes

***Prime editing has strategies to be able to do just not single nucleotides, but also fix much more complex mutations***

**Best use and timing of gene therapy**

- You want to use gene therapy/ gene editing early enough before the damage is done to the body
- It’s being able to get to the part of the body safely that you need to
- It’s multiple pieces of the puzzle that have to all be solved simultaneously to get the whole package to work, and we’re not quite there yet
- Wendy is optimistic that we are realizing that this may be one solution eventually when all the components are there that may be scalable to deal with many different types of genetic conditions

## Two distinct gene editing strategies for addressing Tay-Sachs and fragile X syndrome [1:37:00]

- [Tay-Sachs](https://en.wikipedia.org/wiki/Tay%E2%80%93Sachs_disease) is due to an enzyme that’s missing
- It’s a recessive condition
- This is a degenerative condition, and so you want to be able to get in early for all the reasons that we’ve talked about
- You could do a gene addition
  - The gene, the enzyme is missing so you can just pop it back in
  - It doesn’t have to integrate, and that strategy would be a good strategy
- The tough part as you’re thinking about the delivery system, is you need to get it into the brain

**What does that mean? Would you introduce an intranasal virus?**

*Where does this enzyme normally get made? In glial cells, in neurons?*

- There are multiple ways to access the brain
- The [blood-brain barrier](https://en.wikipedia.org/wiki/Blood%E2%80%93brain_barrier) makes it a protected space
- Wendy doubts we’re going to be able to do it with [intranasal](https://en.wikipedia.org/wiki/Intranasal_drug_delivery), although there is some that you use the intranasal route
- In some cases we do [intrathecal](https://en.wikipedia.org/wiki/Intrathecal_administration)
  - For example, women who’ve had an epidural, this is basically the same way we access the space for an epidural
- For anyone who’s thought about chemotherapy that we give for brain cancer, sometimes we actually have to administer it into the ventricle
  - This sounds a little bit barbaric, but do injections through the skull
- Wendy’s point is it’s not as simple as an intravenous infusion
  - We can’t just give it peripherally and get it to the brain where we need it to go

**Difficulties to overcome when targeting the brain**

- In some cases we need to get throughout the brain even into deep nuclei or different parts of the brain
- For example, if you were to inject it and you had a high concentration on the left, but it didn’t get to the right, that would be a problem
  - You need to be able to get even distribution
- With Tay-Sachs, you probably don’t need to get to 100% of the protein or the enzyme that’s there
  - Even 50% is enough
  - And it’s possible you could get down to 20% and that would be just fine, and so that’s one strategy

**Treating Fragile X syndrome**

- Fragile X is a little bit more complicated
- The actual mutation itself is what we call a [trinucleotide repeat](https://en.wikipedia.org/wiki/Trinucleotide_repeat_expansion), a repeat that’s too big, and so we need to be able to make it smaller
- It also has the same problems in terms of being in the brain
- But it’s not just simply adding back some additional fragile X protein
  - So we can’t just make it a gene addition strategy
- We’ve got to really think about the gene editing to shrink the size of that repeat back down to the normal size

*What’s unknown*

- One of the things we don’t know until we do it in people is, “*What is that window of treatability?*”
- Just to be provocative to let the listeners think about this: even if GUARDIAN worked perfectly and we could identify these babies within the first week of life, “*Is that early enough?*”
  - Wendy hopes that for many conditions that will be
  - It’s possible that we’ll need to go even earlier, and there are some people that have thought about in utero gene therapy/ genetic treatments
    - For some conditions (not all of them) it might be necessary to treat during fetal development, to have the maximal effect
    - Wendy is not saying we’re going there anytime soon, but just thinking through that

***There may be imperfect solutions unless one gets to the right time and the right place, and, the right cell type even***

**Fragile X is a recessive condition. Presumably it can only impact women because you would need both copies of the X?**

- Fragile X is [X-linked recessive](https://en.wikipedia.org/wiki/X-linked_recessive_inheritance), but what that means is that mostly males are affected
  - Because they only have one X
  - It’s much more unusual for a female to be affected, because they would need to have gotten the X from their father as well

## Exploring obesity as a polygenic disease: heritability, epigenetics, and more [1:41:15]

**How much do we understand about the genetics of obesity and does genetic therapy play any role there?**

- We have ways of calculating [heritability](https://en.wikipedia.org/wiki/Heritability), and that gives us scientific insight into how genetic is a certain condition
  - You can do this by looking at twins (identical twins and fraternal twins) and see how similar they are in terms of body mass index, adiposity
- Obesity ends up being highly heritable
  - It’s not the most heritable factor, but is highly heritable
- To give it a round number, the heritability of obesity is somewhere around 50% (or 0.5)
- Other conditions that are extremely heritable are closer to 1.0
- For comparison, type-2 diabetes (non-insulin-dependent diabetes) is more heritable, there is a stronger genetic component
  - Type-1 diabetes is less heritable; it’s a complex interaction of both the genetics that govern your immune system and what you’re exposed to

**On the other hand, there are environmental differences**

- You can look at what’s happened to the average body mass index of the average American over the last generation
  - Our genes haven’t changed, but by most measures you can see that we’re more prosperous and in general, the average body mass index has increased
- There have been some interesting studies looking at particular groups of [Pima Native Americans](https://en.wikipedia.org/wiki/Akimel_O%27odham)
  - They have genetically the same genes
  - They come from the same original community, but they live in different environments
    - One in which it’s more sort of a traditional environment in terms of the amount of access to calorically dense foods and the amount of physical energy that’s expended on a day-to-day basis
  - And those same original groups, but in two different environments, you see much more obesity in the one group that has easy access to obesogenic foods versus the other that doesn’t

***This strongly suggests that it’s not just the genes in terms of obesity***

**Genetics of leptin and the leptin receptor**

- This goes back to [Rudy Leibel](https://www.ihn.cuimc.columbia.edu/profile/rudolph-l-leibel-md) and his original work in terms of identifying [leptin](https://en.wikipedia.org/wiki/Leptin) and the [leptin receptor](https://en.wikipedia.org/wiki/Leptin_receptor) through positional cloning methods
- Mutations in leptin and the leptin receptor do not account for the vast majority of obesity (they’re very rare)
  - Wendy has had patients with these conditions, but that’s just because of the nature of her work, but it’s very rare and most people would not have seen this

***On the other hand, understanding the fundamental biology of how body rate is regulated and governed is critical in terms of understanding those two molecule***

- Wendy’s point is, “*I don’t know if it’s going to be for obesity, but it may be for other conditions (like myocardial infarctions or coronary artery disease) that knowing about the biology and the final common mechanism or the final common pathway through which the biology is regulated, one may have ways of either pharmacologically or some will say in terms of gene therapy being able to make permanent manipulations.*”

**Statins as an example**

- In terms of treatment for [hypercholesterolemia](https://en.wikipedia.org/wiki/Hypercholesterolemia), there may be various different genetic mechanisms by which one has an increased risk for a heart attack
- Yet statins seem to work for a lot of different people
- Some have thought that rather than using statins as a medication, would there be a way of genetically making a manipulation?
  - It’s a one-time therapy
- Wendy is not saying that this is exactly where obesity treatment is going to be going, and she is excited (in a good way) that we certainly have better treatments for obesity now than we had five or 50 years ago

**Epigenetics adds another layer of complexity to understanding obesity [1:45:30]**

**Explain what the epigenome is and how it changes not just over a person’s life, but perhaps more importantly from one generation to the next**

*Peter wonders if epigenetics is playing a role in the propagation of obesity across generations*

- The bottom line is we don’t know
- To break down the term [epigenetics](https://en.wikipedia.org/wiki/Epigenetics): epi means above, and then genetics the genes
  - This refers to chemical modifications that happen to the genome, which are used to affect gene regulation
- Some of those chemical modifications include [methylation](https://en.wikipedia.org/wiki/DNA_methylation), and those are dynamic
  - They can change over the life course, they can change by cell type, and they’re ways to be able to coordinate regulation of potentially groups of genes
- They’re tricky to analyze from a methodological point of view
  - Scientifically, they’re tricky because they do vary over the life course and they vary by cell type or tissue
- For example, using a blood sample as a matter of trying to get the epigenetic profile for what’s going on in your brain or your pancreas doesn’t always work
  - And it’s hard to even know whether or not it works because not as if we’re going in and doing pancreatic or brain biopsies on most people
- You can do things in animal models, you can get some indirect evidence, but it’s hard to know for sure whether or not this is truly answering the question you’re trying to answer

**Wendy’s conclusion,** ***“There’s a lot of conjecture in the area of epigenetics and hard to know for sure exactly what that is.”***

**What we know from a mouse model of obesity (the agouti mouse)**

- Depending on how much folate you give that mouse, while the dam (the mother mouse) is carrying her pregnancy, her little mice, the amount of folate in her diet does affect the epigenetics
- Folate is used for methylation of the DNA
- You can see a readout in the agouti mouse, a change in coat color and obesity in these mice and their progeny
- For **transgenerational effects**, we don’t entirely know the mechanism of how that might be occurring, whether it’s epigenetics or other things
  - There are things that we can see, but these are complicated
  - Wendy don’t feel like scientifically we have all the evidence to make definitive conclusions at this point
  - But one wonders about what many different contributors could be
  - She would have to guess that this is not going to be the major major, driver

## The genetics of autism [1:48:45]

- [Autism](https://en.wikipedia.org/wiki/Autism_spectrum) is in the news all the time, it seems and certainly appears as though it’s increasing in frequency, and it’s unclear how much of that is due to an increase in diagnosis and recognition versus how much of that is triggered by other environmental factors
- But there doesn’t seem to be much confusion around the fact that there’s a strong genetic component to it

**Based on all of the twin studies, what is the heritability of autism?**

- [Autism](https://en.wikipedia.org/wiki/Autism_spectrum) is a spectrum (as the name indicated); it’s not just one condition
- It goes from severe, what some people will call profound autism and can be associated with intellectual disabilities to other individuals at the “milder end,” who are quite talented in many ways, yet have social challenges

***So within that entire spectrum, if one includes everything within that, the heritability is estimated to be approximately 0.8, although some individuals will say in as high as 0.9***

- The point within that though is that it’s not 100% and in fact we do know of times over the life course in particular prenatal and early childhood that are important to the developing brain and where changes in exposure beyond the genes can play a role
- As an example, prematurity is one of the more common exposures in terms of what happens to developing brain, and if you are born when you’re 26 weeks old, there is a much higher probability of autism than if you’re born at term at 40 weeks

***There are other factors beyond just the genes that are involved, but clearly the other point that Wendy makes about heritability is one calculates heritability as a measure of the inherited genetic factors***

- One of the factors in autism is that there are **de novo or new genetic variants** that occur for the first time in the individual with autism, and those individuals aren’t captured in that measure of heritability because heritability is fundamentally trying to get transmitted genetic variants that are going from parent to child
  - And those de novo genetic events are new in the child
  - So there are genetic aspects not included in heritability

**What are the genes that seem to be responsible for autism?**

- This depends on who you ask and how you want to define this
- Everyone would agree, there are at least **100 genes** that have been identified with high confidence as being associated with autism
  - Depending on how rigorous you want to be about this process, some people would say that we estimate that there are at least a **1000 genes**, and we probably are about a third of the way there in terms of having some sense of those genes
- Not surprisingly, those genes are genes that are expressed in the brain and they function in the brain
- Many of those genes are especially active during intrauterine fetal development within the brain

*What do they code for? How many of those genes would be genes in the exome versus the intron?*

- Most of the ones we recognize are in the coding sequence, but that’s a limitation of what we recognize
- Statistically we realize that there is a signal in the noncoding space [of the genome]
- But we have less evidence to implicate specific genes or specific genetic variants individually in the noncoding space because the effect size or how powerful they are is somewhat reduced compared to those coding sequences
- The other issue is not just *where* in the genes, but *what* genes are involved

***The genes that are involved fundamentally can be genes that function at the synapse ‒ the connections between brain cells and communicate between brain cells (that’s quite important)***

***They can be genes that are important in regulation of genes and gene networks, and many of them are transcription factors, histone modifiers***

- Some of those genes may be responsible for epigenetic changes
- Often they have multiple downstream genes they affect
- Instead of having a focused effect, they have more of a universal effect on brain function and cognition
- These genes may not only be associated with autism but also intellectual disabilities, epilepsy, and they may be associated with more global effects on brain function

**The SPARK study**

- Wendy runs a very large autism study called [SPARK](https://sparkforautism.org/portal/homepage/)
- Within SPARK they identified a teenage young man who actually has his autism as a responsible of undiagnosed PKU
  - Even autism can be caused by full circle an inborn error of metabolism where there are toxic things that build up in the brain that then caused dysfunction of the brain
    - Things that can diffuse to and have an effect on the function of the brain
- Peter clarifies, “*Autism is a* ***clinical diagnosis*** *in the same way that familial hypercholesterolemia is a phenotypic diagnosis, it’s a diagnosis in the case of FH, where LDL cholesterol has to be above 190 milligrams per deciliter off treatment. And it’s incredibly heterogeneous in terms of the genes that are responsible. To my last count, I think there were more than 3,500 genes that could produce that phenotype of high LDL cholesterol.* ***So autism is the same, right? The diagnosis is clinical, it’s a phenotypic defined disease, and maybe up to 1000 genes involved in that or 1000 different ways to get there or more, right?***”
- Exactly right, it’s a DSM diagnosis in terms of clinical behavioral criteria
- This gets confusing, but one can have a gene that’s identified as causal, but the diagnosis is still a behavioral diagnosis
  - It’s simply a gene associated with that
  - And as you said, not just one single gene (it doesn’t map one to one)

> “*In fact, no one gene or genetic factor accounts for more than 1% of individuals who have that clinical diagnosis of autism. So incredibly heterogeneous.*”‒ Wendy Chung

**What’s the approximate prevalence of autism today?**

- To give it a round number, ***2%***, but this number has fluctuated over time

*Is this a function of greater awareness?*

- Wendy thinks it a function of several things
- It doesn’t help that the definition has changed over time
  - Literally the DSM diagnostic criteria have changed over time
- Not surprisingly, the prevalence has changed over time
- In a good way, there is greater recognition and diagnosis as Peter alluded to
  - We’ve seen this in particular for underserved individuals that are more frequently diagnosed now
    - Disparities are decreasing, and that’s a good thing

**But there are also things that are changes in terms of society**

- Is this changing the biology, Wendy doesn’t know
- There are possible contributing factors with that
- There’s also a motivation to a certain extent in terms of the way our society works to be able to access resources
  - So people that may not have been motivated to get a label per se, they may still have known it
  - People may have thought it to themselves, but they didn’t necessarily seek a diagnosis or a label except that there were resources, educational resources, support resources that were important
  - And we want to make sure those individuals get those resources

**What are some other, both neurologic and non-neurologic sequelae of autism or call it comorbid conditions with autism?**

- Wendy thinks this is a good way to phrase it
- Comorbid conditions is one of the things that she thinks about
- For example, some individuals will have epilepsy associated with their autism
  - For some individuals, [epilepsy](https://en.wikipedia.org/wiki/Epilepsy) will be recognized very early
  - For some individuals that won’t come until the teenage years or adolescents, but that can be incredibly important
- Within this, there are behavioral co-occurring diagnoses
- For instance of anxiety is quite frequent
- [ADHD](https://en.wikipedia.org/wiki/Attention_deficit_hyperactivity_disorder) or attention issues are quite frequent
- And some things we’re just beginning to understand
- For example, most of what we know about autism is based on individuals below the age of 20
  - Those are the individuals who’ve been studied most
- There is a whole lot we don’t know about adults with autism
- Some conditions are associated with degenerative conditions, and when people are adults, there may be a particular subtype of autism that is **neurodegenerative** because the genes that are involved are responsible for maintenance
  - Being able to sustain the brain and continue functioning
  - And when they’re not functioning at some point, people start having things associated like Parkinsonism
- Some subtypes of autism may be associated with increased risk of obesity

> “*Believe it or not, some of these same genes may also predispose to obesity*”‒ Wendy Chung

- Some of the medication we use to treat some of these behavioral conditions increase the metabolic effects and weight gain and diabetes associated with subtypes of autism
- There may be more things that are under recognized and we have more gaps in our knowledge
- They mentioned **precision medicine** earlier, but 2% is a large percentage of the population and there is heterogeneity

***Everyone doesn’t need to have the same rules that they’re following or the same management guidelines, and how do we get greater specificity to not overburden people, but yet to be able to also allow them to achieve their full potential and lead their healthiest lives?***

- Most of what we know about autism is based on studying people who are up to but below typically 20 years old

**Does that suggest that prior to about the year 2000 there was nobody really studying this?**

- #1 many adults with autism were not diagnosed as having autism
  - They may have had some of these challenges, but things have changed over time
  - Having a label (a diagnosis) has changed with society
- #2 other individuals who were studied 20 years ago have not been followed longitudinally
  - Although there have been some epidemiological studies like [Framingham](https://en.wikipedia.org/wiki/Framingham_Heart_Study) that have followed individuals over long periods of time, it’s hard to be able to do that
    - People move, investigators lose funding, people die, lots of things that happen
- Just knowing what someone looked like at 2 and that same person at 22, there are very few studies in terms of children, what that looks like

**What is the heritability for other DSM conditions such as bipolar disorder?**

- Peter is shocked to hear that the heritability for autism is as high as 0.8-0.9
- This is one of the highest heritability factors in terms of behavioral health or psychiatric conditions
- Bipolar disorder and schizophrenia are certainly much lower, in the neighborhood of 0.5-0.6
- Things like depression, major depression are lower still (maybe 0.3)

**If the heritability is 0.8-0.9, does that imply that a person with autism will have an autistic child?**

- Wendy replies, “*That’s only half the equation, right? It takes two to tango in terms of making a child. So both individuals are contributing genetic factors as we’re thinking about this, and it’s the combination of those factors together within that combination.*”

**You said 100-1,000 genes seem to be implicated in autism, even if we’re not talking about polygenic combination, some individuals with autism may only have one of those genes, correct?**

- Absolutely
- Some of them may have only one gene that’s the predominant contributor in terms of this
- Some will be more of that polygenic combination of factors

*But a single gene individual has a 50% chance of passing that gene onto their offspring, and assuming it’s fully penetrant, they would have effectively a 40 to 50% chance of transmitting autism to their offspring?*

- That’s correct
- For the types of genes that you mentioned, many of those individuals actually won’t go on to have their own families
  - One of the factors within this is that those highly penetrant, single gene factors, many individuals, for instance if they’re not living independently, if they’re not verbal, they won’t pass those genes down

## The genetics of cardiovascular disease [2:01:45]

**Let’s pivot for a moment to cardiovascular disease and discuss the genetic perspective**

- [FH (familial hypercholesterolemia)](https://en.wikipedia.org/wiki/Familial_hypercholesterolemia)
- Another is [Lp(a)](https://en.wikipedia.org/wiki/Lipoprotein(a)) (attached to the *LPA* gene), roughly 1 in 10 people have an atherogenic condition genetically associated with elevated Lp(a)
  - The most prevalent atherogenic condition
  - Peter adds, “*That would be another great example of how gene addition therapy would be of no use because you’d want to be gene editing that.*”

**How much of the rest of ASCVD appears to be heritable?**

*Beyond those two special cases of elevated Lp(a) and familial hypercholesterolemia*

- When we think about myocardial infarctions, hyperlipidemia, and that sort of cardiovascular health, there may be genetic factors that are numerous
- But from a therapeutic point of view, we may not target all of those genetic contributors
  - There may be final common biology

> “*There may be final common biology, and so I think that’s a theme that I see most in terms of thinking about coronary artery disease, myocardial infarction, things like that.*”‒ Wendy Chung

***Cardiomyopathies is one example***

- [Cardiomyopathies](https://en.wikipedia.org/wiki/Cardiomyopathy) affect on average about 1 in 500 individuals
  - It’s not 1 in a million; it’s not 10% of the population; it’s somewhere in the middle
- Wendy has been waiting to see the data come out, but we’ve known about many of those genes for a long time
  - We’ve known about the mutations, we’ve known about frequency, we’ve known about natural history, and we’re waiting to see whether or not genetic therapies would be effective for those conditions
- Therapy is not yet in people, but the early data in animal models are looking promising, in terms of being able to reverse this or prevent this
- Wendy thinks the heart is a tricky organ to be fussing with, “*It always makes me a little bit nervous because electrical things can happen very suddenly and it can be quite dangerous. So that always makes me a little bit nervous to think about genetic therapies for the heart*.”
- This is a common condition that otherwise oftentimes we treat with transplant when the heart finally fails
  - It’s be lovely if didn’t have to wait for hearts for transplant

**Back to ASCVD**

- It sounds to Peter like Wendy is saying that if genetic therapies and treatments are going to be deployed against conditions like FH, you would really do it more to mimic the drug than you would to try to correct the defect
  - That makes a lot of sense in the case of FH because of the heterogeneity ‒ to have 5,000 different gene therapies for the 5,000 different genes that can be altered in the result of hyperlipidemia is a bad idea
  - Whereas if you can simply knock out [*PCSK9*](https://en.wikipedia.org/wiki/PCSK9) as a gene, you basically take care of everyone

*Let’s talk about what that means technically*

- Presumably there are genetic therapies that are already in the works targeting *PCSK9*
- PCSK9 inhibitors as a class of drug have been perhaps the most exciting drug class introduced in the last decade, and the results have lived up to the hype
- Peter remembers reading the [papers](https://www.nejm.org/doi/full/10.1056/nejmoa054013) 15 years about when [Helen Hobbs](https://utswmed.org/doctors/helen-hobbs/) first made the discovery of individuals that were both hyper and hypofunctioning PCSK9
  - He thought, “*This is too good to be true. This will not pan out,*” and he was wrong

**What does gene therapy to silence a gene but without creating some unintended consequence look like?**

- It’s going to start out with not just the average person who might have a higher risk
- It’s going to start out at the extreme
- We talked about Jesse Gelsinger, someone who’s going to be willing to be the first brave person and try this
- Wendy won’t claim that she’s designed the clinical trial that goes with this, but it’s going to start at that extreme and there are going to be a lot of complexities

## The financial costs and economic considerations of gene therapy [2:06:15]

**Many listeners are thinking gene therapy is cost prohibitive right now**

- It’s not uncommon for current gene therapies to cost $3 million
  - The range of genetic therapies currently cost between $1-3 million
- We can’t afford to spend $3 million per person with the number of people who are at risk in the US population
- To put this in perspective, Peter points out, “*It’s not uncommon to spend a million dollars on chemotherapy at the end of life for a year’s worth of life extension, and if you contrast that with a million dollar gene therapy in infancy that gives 80 or 90 years of life extension, it at least puts those two treatments in context.*”
  - He’s not going to advocate one way or another
- Wendy agrees

**Health economists have been trying to get at the cost of gene therapy in terms of the value**

- She’s not going to pit one against the other in terms of this, but you do have to think about it
- There’s a lot of cost that goes into this if you do the economic analysis accurately
  - Not just the healthcare system cost to the person, but the societal cost to the family, to the community
- To say that it might be worthwhile in one case, you  have to think about scaling
- To throw a number out there, **10% of the US population has a rare genetic condition (they may or may not know it)**
  - This is true in terms of monogenic factors [single gene] that we’ve been talking about
- If you now think about the percentage of the population that has obesity or type 2 diabetes or some of these other common conditions, that someday might be treated by these one-and-done types of things, then it becomes in terms of a society, what can we afford to do?
  - What are the competing other healthcare costs or other societal costs in general that we have and how are we going to right size these?
- Wendy is confident that as we have more ability to understand how to do this, there’s a lot of fixed cost, but the marginal cost is not nearly as high
  - In terms of both what it takes to design the clinical trials, to do the manufacturing, to do the monitoring
  - All of these things won’t scale linearly, and Wendy thinks we’ll have some cost realization that we can recoup

***The big questions that we think about is how are we going to afford this and what are the key things that we need to do to enable doing this on scale? What are the competing alternatives?***

- With a medication you’re taking every day, if you can’t get to a good point in terms of MI risk or risk of heart health, stroke health, other things
- All of these will be factored in
- Eventually a health economist will price this out and figure out what a reasonable fee is to charge for such therapies

**Thinking about the costs of gene therapy relative to gene sequencing, is gene therapy still in its infancy?**

- Absolutely
- The Jesse Gelsinger case was more than 20 years ago, and we are still at our infancy in terms of being able to realize all the potential
- Peter points out, “*In the year 2000,  it cost $1 billion to sequence a human genome. Today it costs $1,000. So that’s a six log reduction in cost in part through Moore’s Law, in part through the step-function change of high throughput sequencing. We don’t need a six log reduction in the cost of gene therapy to make it readily available.*”

**Do you think a two log reduction in the cost of gene therapy is feasible in the next two decades?**

- Yes
- There are going to be certain catalytic transformative breakthroughs that will make and enable those changes that we’re talking about
- Wendy goes back to what we did with the COVID vaccines
  - It was incumbent upon everyone to be able to come up with solutions
  - The solutions that allowed for the adaptability and even changing the vaccine on the fly were remarkable, at least from a scientific point of view
- If you could think about the same way with delivering an mRNA vaccine and doing the same thing and realize that it’s different for genetic gene addition and doing it, but it’s not entirely different in terms of how to do this
  - Wendy calls this “*rinse and repeat*,”
  - But it’s being able to do this and having the infrastructure, the delivery system, the regulatory system, the manufacturing process, all of those things
- Once you get this down, there are ways to scale this and to be able to do it repeatedly
  - If the gene fits, if it’s a certain size, if there’s certain mutations

***Wendy has hope that we’re going to see a step-function and it’s not going to be linear***

## The ethics of gene editing [2:12:00]

- Last year Peter read [Walter Isaacson’s](https://en.wikipedia.org/wiki/Walter_Isaacson) [biography](https://www.amazon.com/Code-Breaker-Jennifer-Doudna-Editing/dp/1982115858/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1691594700&sr=8-1) of [Jennifer Doudna](https://chemistry.berkeley.edu/faculty/chem/doudna) and the story of the discovery of CRISPR
  - A fantastic [book](https://www.amazon.com/Code-Breaker-Jennifer-Doudna-Editing/dp/1982115858/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1691594700&sr=8-1) that he can’t recommend highly enough
- There was a fantastic discussion of the ethics of this and once you realize the power of gene editing, you very quickly start to pivot away from the discussion we are having today, which is a child is born with Tay-Sachs disease, this child is going to be dead in a couple of years and it’s a very ugly death
  - There’s really nobody in their right mind that wouldn’t be in favor of a therapy there
- If a woman is born with a *BRCA* mutation and she has a choice between a gene edit to fix it or a mastectomy to remove her breast, we’d probably prefer the former if for no other reason than it ends the gene there and her daughter won’t get it or her son won’t get it

**How can people think about the next layer of complexity [genes that confer disease susceptibility]?**

- For example, should we take a person who has an [*APOE4* isoform](https://en.wikipedia.org/wiki/Apolipoprotein_E#Polymorphisms) and turn that into an *APOE3* or *APOE2* isoform?
  - Either would come with significant protection against neurodegenerative disease

***This is slightly different because the penetrance and risk profile is different***

- Wendy points out, “*One thing I think we universally agree on (I hope) is that we’re not doing gene editing, gene manipulation to affect the next generation.*”
  - We’re not looking for things that are transmissible in the germline
  - We’re not trying to create superhuman where we’re trying to fiddle with the genes to either correct them or to be able to enhance them that is transmissible

***The consensus among the scientific community is that you would treat the body of the person that might be at risk or have those diseases, but you wouldn’t try and do manipulations that would be transmissible to the next generation***

- Peter realizes his argument for *BRCA* is only partially correct
- Wendy continues, “*The other part of it is this tricky thing that you’re talking about, which is enhancement in terms of it’s not correcting something that’s problematic, it’s enhancing the body the way it is or trying to, in some sense, prevent a disease process.*”
- Enhancement is a trigger word for, “*We shouldn’t go there.*”
- Part of that is we’re not as smart as we think we are
  - We can think that something’s not going to have off target effects, that it’s not going to disrupt a gene inadvertently
- In the short term, what saves us is that the risk profile given the uncertainty in the long term is so high that there aren’t going to be either scientists or people who are going to go for things that are trivial in terms of enhancements

**The** ***APOE2, 3, 4*** **situation is one that people think about**

- The average listener here is more sophisticated about this
- The average person walking down Broadway is not going to think about this in the same way
  - They’re going to think about things that will be **enhancements**: being able to increase your earning potential, being able to be taller, more athletic, funnier

***Just to be an enhancement is a line that people are not crossing and this is really about disease and being able to make people healthier***

- There are certain medical industries that are not covered by insurance, that are not regulated
- There are certain parts of the world that do things differently where people can go and seek certain things
- Wendy hopes that there is a consensus scientifically about places we don’t go because otherwise there will be ways that people will find to do things

**The story of the initial blowup around CRISPR, what took place in China, and how that brought the scientific community closer around this consensus**

- Wendy thought this [circumstance in China](https://en.wikipedia.org/wiki/He_Jiankui) was a little unusual
- The [*CCR5* gene](https://en.wikipedia.org/wiki/CCR5#HIV) was manipulated to try and prevent children from getting infected with [HIV](https://en.wikipedia.org/wiki/HIV)
  - This would not cure a disease or prevent a disease
  - It was preventing transmission of infectious agent that those children were at increased risk for HIV
    - But it wasn’t a foregone conclusion that they would be HIV positive
- Peter points out that there was very little chance they would be infected because these children were born of IVF
  - The sperm from the HIV positive father were washed
  - The mother was HIV negative

*Wasn’t this a situation where it was almost entirely possible to prevent the transmission of HIV to the offspring?*

- This was Wendy’s point, “*I don’t think heroic measures needed to be made*.”
  - There were reasonable ways available that are very effective
- Scientifically, it was an odd selection of a use-case

***The scientific community rallied around this line that had been crossed, that this was essentially a form of enhancement***

- It wasn’t something that was saving a life
- It wasn’t something for which there were no other treatments or anything else

**Wendy worries**

- The world is global and scientists are in all sorts of places, and it only takes one person to be able to do something that’s crossing a line
- There is medical tourism in places
- It is important for people to uphold certain ethical standards and for us to have those guiding principles so that people know where those lines are

**Do you think it would’ve been different if the first use of CRISPR in humans was to do something that we could all agree on would be a great use-case?**

*Would the field be in a different place today?*

- It was 2018 that the Chinese scientist [[He Jiankui](https://en.wikipedia.org/wiki/He_Jiankui)] used CRISPR to edit the genome of human embryos
- Peter asks, “*What would have been that perfect use-case?*”
  - Sickle cell, Tay-Sachs?
  - You could use gene editing to fix the gene and produce a phenotype that could have a normal life expectancy
    - The technology would be the same, but a far better application
- Wendy points out that most people in the field would take a different approach if you’re at the stage of an embryo with in vitro fertilization
  - Rather than trying to dittle with the genes, you can simply do selection of an embryo that doesn’t have that genetic risk
    - Therefore you’re not increasing the risk of something off target, and you’re still accomplishing what you set out to achieve
- Some ethicists make the argument that if there were a very limited number of embryos and that were not possible to do, would that be a circumstance in which direct therapy for a very bad disease would be ethical (knowing that that would affect the germline)?
  - In a situation where the couple had no other alternative in terms of having a biological child knowing that that would affect the germline
  - This is different from what was discussed earlier
  - If this were not a routine therapy in terms of the intention to do this in a universal way
  - This is something that gets us close to the edge of thinking about the use-case

## The future of clinical genetics [2:21:00]

**If you had a crystal ball and you could look into the future in 2040, and you’re looking back at a 40+ year career in this space that has probably seen more transformation than most fields in all of medicine. What would you** ***not*** **be surprised to see happening in 2040 in this field?**

- At this time, you’re probably coming to the end of your career, you’re thinking about retiring
- Wendy would not be surprised that ***diagnosis is trivial***
  - She hopes that we’re getting to that point not just with the cost of sequencing decreasing, but with machine learning, artificial intelligence, the ability to ingest huge amounts of information (genomic information, clinical information, other information), and the diagnostic ability in medicine in general
  - Not limited just to genetics and genomics, but is especially true in this field, diagnostics will be hopefully trivialized

***She hopes from an equity point of view that we’ll be more accessible to more people around the world just because of that cost barrier will decrease***

- Wendy is not sure about the therapeutic point of view and how much of that we will have realized within 20 years
- She’s optimistic we will have gotten a lot of that done, but is not sure how much of it will penetrate parts of society in the US or globally
- It’s very hard to predict timing
  - Within some point in the next 100 years, we’ll get to this point
  - Wendy is not sure if it’s the next 20 years or not, and what percentage of individuals we will have been able to serve

***Gene therapy will progress in step-function; these transformative things are hard to predict, especially given that we got stuck for the last 20 years***

- We are gaining momentum, but it doesn’t take much in society and in science to get us stuck
  - A word of caution ‒ Wendy hates to make things about COVID, but she would not have predicted societies response in the last 10 years and some of the trajectories we’ve had

§

## Selected Links / Related Material

**The GUARDIAN Study**: [What is the GUARDIAN study?](https://guardian-study.org/overview/) | The GUARDIAN Study (2021) | [9:30, 1:06:30, 1:09:00, 1:18:45]

**Book recounting the discovery of the structure of DNA**: [Double Helix](https://www.amazon.com/Double-Helix-Scribner-Classics-Watson/dp/0684852799/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1690915266&sr=8-1) by James Watson (1998) [22:45]

**SPARK autism study**: [SPARK: Understanding Autism](https://sparkforautism.org/portal/homepage/) (2023) | [1:53:45]

**Biography of Jennifer Doudna and the discovery of CRISPR**: [The Code Breaker: Jennifer Doudna, Gene Editing, and the Future of the Human Race](https://www.amazon.com/Code-Breaker-Jennifer-Doudna-Editing/dp/1982115858/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1691594700&sr=8-1) by Walter Isaacson (March 2021) | [2:12:00]

§

## People Mentioned

- [Rudolph (Rudy) Leibel](https://www.ihn.cuimc.columbia.edu/profile/rudolph-l-leibel-md)  (Professor of Pediatrics at Columbia University, co-discovered leptin) [25:30, 1:43:45]
- [Helen Hobbs](https://utswmed.org/doctors/helen-hobbs/) (Professor of Internal Medicine and Molecular Genetics at the University of Texas Southwestern Medical Center and PCSK9 expert) [2:05:30]
- [Jennifer Doudna](https://chemistry.berkeley.edu/faculty/chem/doudna) (Nobel laureate and Professor of Chemistry at UC Berkeley) [2:12:00]
- [He Jiankui](https://en.wikipedia.org/wiki/He_Jiankui) (Chinese scientist jailed for using CRISPR on human embryos) [2:19:15]

§

![](https://peterattiamd.com/wp-content/uploads/2023/08/bio-wendychung-500x500.png)

##### Wendy Chung, M.D., Ph.D.

Wendy Chung earned her BA in biochemistry and economics at Cornell University. She then entered a MD-PhD program where she earned her PhD from Rockefeller University and her MD from Cornell University. She was a graduate student of Dr. Rudy Leibel. She completed an internship, residency, and fellowship at the Columbia University Medical School, New York-Presbyterian Hospital. Her residency focused on pediatrics, and her two fellowships focused on molecular genetics and clinical genetics. [[Wikipedia](https://en.wikipedia.org/wiki/Wendy_Chung)]

Dr. Chung stayed at Columbia University Medical School as a Professor of Pediatrics. She was named the Kennedy Family Professor of Pediatrics (in Medicine). She served as the Chief of Clinical Genetics Division in the Department of Pediatrics, the Medical Director of Columbia’s Genetic Counseling Graduate Program, the Associate Director for Education at the Herbert Irving Comprehensive Cancer Center, and Co-Director of the Precision Medicine Resource within the Irving Institute for Clinical and Translational Research. In May of 2023, Dr. Chung accepted a position at Harvard Medical school, Boston Children’s hospital. [[Columbia](https://www.irvinginstitute.columbia.edu/news/departure-esteemed-faculty-member-wendy-chung)]

Recently Dr. Chung has been named Boston Children’s Hospital next Chief of the Department of Pediatrics. Harvard Medical School, Boston Children’s Hospital. She will also serve as the Mary Ellen Avery Professor at Harvard Medical School (HMS), and President of the Children’s Hospital Pediatric Associates. [[Boston Children’s Hospital](https://www.childrenshospital.org/newsroom/news-and-events/2023/boston-childrens-wendy-chung-pediatrics-chief)]

Dr. Chung’s [research](https://wchunglab.com/) focuses on the genetic basis of a variety of human diseases such as obesity, type 2 diabetes, congenital heart disease, cardiomyopathies, arrhythmias, Long QT syndrome, pulmonary hypertension, endocrinopathies, congenital diaphragmatic hernias, cleft lip/cleft palate, seizures, intellectual disabilities, autism, inherited metabolic conditions, rare disorders, and breast and pancreatic cancer susceptibility. She also works on the implementation of genomic and precision medicine. Dr. Chung has identified over 50 new genetic conditions and has authored over 500 scientific papers.

Dr. Chung directs NIH funded research programs in human genetics of birth defects. She is the Principle Investigator of the [GUARDIAN study](https://guardian-study.org/who-we-are/). This is a research study that screens newborns for over 250 genetic conditions not currently included as part of standard newborn screening.

Dr. Chung is also the Principle Investigator of [SPARK](https://sparkforautism.org/), a long-term autism research study. This is a study of over 100,000 people with autism and 175,000 of their family members. Over 100 genes have been linked to autism, and this study aims to better understand the genetic basis of this disease.

Dr. Chung has received numerous awards. She is a member of the National Academy of Medicine and American Association of Physicians. She was the recipient of the NY Academy of Medicine Medal for Distinguished Contributions in Biomedical Science, the Rare Impact Award from the National Organization of Rare Disorders, and the Presidential Award for Outstanding Teaching. Dr. Chung is rated one of *New York Magazine’s* best doctors and received the Castle Connolly Top Doctors’ award. [[GUARDIAN study](https://guardian-study.org/who-we-are/)]