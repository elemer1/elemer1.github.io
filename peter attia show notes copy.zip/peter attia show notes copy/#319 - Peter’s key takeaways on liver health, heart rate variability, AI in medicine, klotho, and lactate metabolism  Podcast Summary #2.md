# #319 ‒ Peter’s key takeaways on liver health, heart rate variability, AI in medicine, klotho, and lactate metabolism | Podcast Summary #2

**Source:** [https://peterattiamd.com/qps2/](https://peterattiamd.com/qps2/)

---

In this podcast summary episode, Peter summarizes his biggest takeaways from the last three months of guest interviews on the podcast. Peter shares key insights from each episode, covering diverse topics such as liver health with Julia Wattacheril, heart rate variability with Joel Jamieson, artificial intelligence with Zak Kohane, klotho for brain health with Dena Dubal, and lactate and lactate metabolism with George Brooks. Additionally, Peter shares any personal behavioral adjustments or modifications to his patient care practices that have arisen from these engaging discussions.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [episode #319 show notes page](https://peterattiamd.com/qps2/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Overview of topics, and the positive feedback on the podcast summary format [2:00];
- Julia Wattacheril episode: liver health and disease [4:00];
- Noninvasive methods to diagnose liver conditions, and how to manage and improve liver health [16:00];
- Joel Jamieson episode: heart rate variability (HRV) for training and health [27:15];
- Practical tools for measuring HRV and how it informs training and recovery decisions [37:00];
- Zak Kohane episode: artificial intelligence and medicine [47:15];
- The current role of AI in medicine and how it could revolutionize medicine in the future [53:45];
- The limitations and concerns pertaining to AI [1:00:15];
- Dena Dubal episode: the potential benefits of klotho for brain health [1:05:00];
- Animal studies on klotho and brain health [1:11:00];
- Genetics-based variations in klotho levels in humans and their impact on cognition, disease risk, and longevity [1:14:15];
- Testing klotho levels, the significance of the KL-VS variant, the role of exercise in increasing klotho, and more [1:17:30];
- The potential of klotho as a treatment for cognitive decline and Alzheimer’s disease [1:23:15];
- George Brooks episode: a new paradigm to think about lactate and lactate metabolism [1:27:45];
- The potential for lactate infusions to aid in brain recovery following a head injury [1:34:00];
- The relationship between lactate and cancer, and the impact of exercise on lactate levels and cancer risk [1:36:30]; and
- More.

§

The Peter Attia Drive

Peter's key takeaways on liver health, heart rate variability, AI in medicine, klotho, and lactate metabolism

§

## Show Notes

§

\***Notes from intro**:

- This episode is the second of what we’re now calling the podcast summary
- We did the first episode of this back in June, and the feedback was overwhelmingly positive
  - Peter doesn’t think we’ve ever received more feedback on the day of a podcast release than we did for the [podcast summary #1](https://peterattiamd.com/qps1/)
- We’re going to continue to do this format because people really seem to like it, and it’s a lot of fun for Peter
- These podcast summaries will look back at recent episodes released typically over the last quarter, and Peter will discuss what he learned from the interview
  - And what he thinks are some of the most important insights
  - As well as any changes in his behavior or thinking
- In todays episode, we will cover interviews with Julia Wattacheril, Joel Jamieson, Zak Kohane, Dena Dubal, and George Brooks
- Throughout this we speak on topics such as liver health, heart rate variability, the emergence of AI and its potential impact on medicine, the gene and protein klotho and its potential to treat Alzheimer’s disease, and all things related to lactate
- If you’re a subscriber and would like to watch the full video of this podcast, you can find it on the show notes page
- If you’re not a subscriber, you can watch a sneak-peak of the video on our YouTube page

## Overview of topics, and the positive feedback on the podcast summary format [2:00]

- This is the second podcast summary we’ve done
- We released the first one in June and received really positive feedback
- In this conversation, we’re going to look recent episodes of *The Drive* and Peter will share
  - His key takeaways
  - Anything that has changed as a result
    - Be that his behavior or how he is thinking about things
- In this episode we’ll cover topics such as the liver and liver health, heart rate variability and training, AI in medicine, klotho and Alzheimer’s disease, lactate, and more

Positive feedback

- After the release of [Podcast Summary #1](https://peterattiamd.com/qps1/), listeners expressed that they appreciated the recap of key takeaways from various episodes, which encouraged many to revisit or explore episodes they missed
- They plan to make these summaries a regular feature

## Julia Wattacheril episode: liver health and disease [4:00]

[#302 – Confronting a metabolic epidemic: understanding liver health and how to prevent, diagnose, and manage MAFLD and liver disease | Julia Wattacheril, M.D., M.P.H.](https://peterattiamd.com/juliawattacheril/) (May 20, 2024)

\*\*\*

**Julia discussed liver health, liver disease (NAFLD, MASLD), everything as it relates to the liver**

- This was at times a technical episode
  - This is a classic episode of *The Drive*, meaning you don’t expect to turn on a podcast and walk into a graduate level seminar on the liver, but if you take a step back and think about it, we kind of need to
- The liver is arguably one of the most important organs in the body
- It is an organ for which we have no extracorporeal support
  - Meaning if your kidneys fail (God forbid, that’s very bad), at least you have the option of dialysis
  - If your lungs fail, at least you have a ventilator
  - Even if your heart temporarily fails, we have ways to support that outside the body
  - Remarkably we don’t have this for the liver
- If a person goes into liver failure, their only solution is a liver transplant
- And that speaks to the diversity and complexity of function in this organ

*We talk about the function of the liver in 3 categories: metabolism, protein synthesis, and detoxification*

- There simply is no parallel for those things

**Then talked about the role of alcohol**

- Everybody’s aware that alcohol is metabolized by the liver and therefore that excess alcohol is toxic
- We talk a little bit about the how and the why
- The metabolite of ethanol known as [acetaldehyde](https://en.wikipedia.org/wiki/Acetaldehyde) basically causes all of the downstream problems by overwhelming the redox potential of cells in the liver
  - And that creates the attraction of free radicals and inflammatory cells
- We did a great job talking about dose makes the poison here
  - So if a standard drink contains about 14-15 grams of ethanol, that will usually be found in about 12 ounces of a regular beer
    - Interestingly, Peter’s favorite beer contains 10% alcohol, and you would get that 14 g in far less volume
  - 14-15 g ethanol is also contained in
    - 5 oz. of wine contains
    - 1.5 oz. liquor

![](https://peterattiamd.com/wp-content/uploads/2024/09/f1-qps2.png)

**Figure 1. Examples of a standard drink that contain 14 grams of alcohol**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Standard_drink)

***It’s not intuitive for people to think about how many grams of ethanol they’re consuming***

- The [show notes](https://peterattiamd.com/juliawattacheril/) give more details on the toxicity of ethanol based on how many grams per day or grams per week you’re consuming

**MASLD or metabolic dysfunction-associated steatotic liver disease**

> “*We talk about NAFLD, and that’s something that’s been talked about for the last 20 years. It’s the fastest growing form of liver disease in the developed world. And it’s probably poised in its long-term sequelae to be the leading indication for liver transplant within the next decade.*”‒ Peter Attia

- The name has changed from NAFLD to [MASLD](https://en.wikipedia.org/wiki/Metabolic_dysfunction%E2%80%93associated_steatotic_liver_disease) to make the name more encompassing
  - NAFLD has the intuitive point of saying it’s a fatty liver disease that does not result from the consumption of alcohol because [AFLD (or alcoholic fatty liver disease)](https://en.wikipedia.org/wiki/Alcoholic_liver_disease) would be the sister disease
- This idea of MASLD (or metabolic dysfunction-associated steatotic liver disease) speaks to the complete overlap of insulin resistance metabolic syndrome type 2 diabetes
  - The overlap is so strong that Peter doesn’t know that it matters that much
    - According to Julia, 99.6% of people who meet criteria for NAFLD will also have the diagnosis of MASLD
- The diagnosis is based on metabolic dysfunction

*The key requirements for MASLD diagnosis*

- You have to have insulin resistance
- It also requires that at least 5% of the hepatocytes (liver cells, it’s the functional unit of the liver) contain fat
- But it does not require fibrosis

**In this podcast Peter remembered things he once knew but had forgotten**

*The difference between kids and adults is the pattern of fibrosis they have*

- In **kids**, it’s more circulated around the portal vein
  - The portal vein is the vein that brings the majority of the nutrients to the liver
  - The portal vein is formed by the confluence of 2 enormous veins in the abdomen (the [superior mesenteric vein](https://en.wikipedia.org/wiki/Superior_mesenteric_vein) and the [splenic vein](https://en.wikipedia.org/wiki/Splenic_vein))
  - In that sense, the liver has 2 blood flows that are coming into it: 1 through the portal vein and 1 through the hepatic artery
- The implication is what do you see from a diagnosis perspective, and in kids, you’re going to see an earlier increase in [ALT, AST and GGT](https://en.wikipedia.org/wiki/Liver_function_tests#)

**You often hear ALT, AST, and GGT referred to as liver function tests**

- We talk about how we accept that as terminology, but the reality of it is they really tell us nothing about liver function
- They are enzymes that are associated with liver or hepatocyte health
- When those enzymes go up, we generally understand that some sort of injury has taken place (we’ll talk about that more in a moment)

**Pattern of fibrosis and steatosis in adults**

- In adults, the fibrosis and steatosis tends to occur closer to the central vein
- As a result of that, you see a delay in the enzyme elevation
- So what does that mean clinically?
  - It means that if you’re an adult and you’re developing steatosis and fibrosis, it could actually be taking place for quite a while before you see it
- And that’s why **another huge takeawa**y (which we’ll get to in a moment) is that this reliance on [elevations of the transaminases](https://en.wikipedia.org/wiki/Elevated_transaminases) (which are the technical names for ALT and AST), and using that as your threshold for concern might be waiting a little bit too long

**The top three causes of liver injury in the form of steatosis and fibrosis are:** #1 MASLD, followed by alcoholic liver disease, and finally, infections (hepatitis is the most common)

- The fact that MASLD is now #1 is something that wasn’t even close to true 20, 30, 40 years ago
  - There is an older [episode with Chris Sonnenday](https://peterattiamd.com/chrissonnenday/) on organ transplantation that talks about the liver

**In** ***Outlive*****, Peter recounts a story when he was an intern more than 20 years ago doing pre-op on a patient**

- Among those things is understanding how much alcohol they consume
  - Because when a patient is undergoing major abdominal surgery, alcohol withdrawal is a very serious medical complication
- So patients who are drinking 3 or 4 drinks a day when they’re in the hospital will either need to have a continuous infusion of ethanol or they’ll have to have more benzodiazepines to cope with the withdrawal
  - Withdrawal can actually be fatal

***The point is you better understand how much alcohol your patient drinks***

- Peter is talking to this guy the night before surgery and he says he doesn’t drink anything
- In the operating room, this guy’s liver looks like it’s a piece of fat
- At the time, everybody assumed Peter was a moron for not finding this out ahead of time, and once they realized Peter had asked, they thought he was lying
- What Peter realizes now is that they never gave it another thought
- Looking back this guy clearly had what they would have at the time called, NAFLD

***20, 25 years ago MASLD was not something that was recognized, although it was probably far more prevalent than believed***

- By 2010 to 2012, most people felt like this is an epidemic and this is going to be an enormous burden on the healthcare system as far as liver transplantation
- Getting back to the point at the outset, which is that extracorporeal support of a dysfunctional liver is not possible

**Hep B and Hep C**

- For hepatitis B, we do have a [vaccine](https://www.cdc.gov/vaccines/vpd/hepb/index.html) today
- For hepatitis C, we do not
- Conversely, for hepatitis C, we have a [treatment](https://www.who.int/news-room/fact-sheets/detail/hepatitis-c#:~:text=Antiviral%20medications%2C%20including%20sofosbuvir%20and,needed%20for%20chronic%20hepatitis%20C.), whereas for hepatitis B, we do not [clarification, while there is not treatment for acute Hep B, there are [antivirals](https://www.who.int/news-room/fact-sheets/detail/hepatitis-b#:~:text=Chronic%20hepatitis%20B%20infection%20can%20be%20treated%20with%20oral%20medicines%2C%20including%20tenofovir%20or%20entecavir. "https://www.who.int/news-room/fact-sheets/detail/hepatitis-b#:~:text=Chronic%20hepatitis%20B%20infection%20can%20be%20treated%20with%20oral%20medicines%2C%20including%20tenofovir%20or%20entecavir.")available to treat chronic Hep B]
- If you’re a teenager today, you’re probably going to have a hepatitis B vaccination, which is going to protect you from that
- Should you contract hepatitis C, you’re going to have a treatment
- However, there are many people for whom hepatitis B was acquired before a vaccination was prevalent

*We care about it for 2 reasons*

- 1 – The risk of liver failure and all of the things we talk about through this pathway of steatosis fibrosis and ultimately what is called cirrhosis
- [Cirrhosis](https://www.niddk.nih.gov/health-information/liver-disease/cirrhosis/symptoms-causes) is the irreversible fibrotic change of the liver
- 2 – Hepatocellular carcinoma
  - This is a deadly type of cancer if not caught very, very early

***The cancer risk here is a greater issue from the infectious side; so you always want to be screening patients for Hep C and Hep B regardless of the workup***

**The other thing to keep in mind here is that MASLD and alcoholic liver disease are also increasing the risk of hepatocellular carcinoma**

- So it’s not just Hep B and Hep C

***And as a general rule, as the degree of scarring and fibrosis increases, so too does the risk of cance***r

- This was something Peter learned in the podcast
- Clarification: for **Hep B, the cancer risk** is present regardless of disease progression
  - You’re going to see 3-5% per year cancer risk regardless of where you are in the disease
  - Fortunately we have a vaccine to reduce your risk
  - For the other causes, the risk of cancer goes up with the progression of disease

## Noninvasive methods to diagnose liver conditions, and how to manage and improve liver health [16:00]

**How do you make the diagnosis**

- The gold standard for this is to do a biopsy
- It’s not that a liver biopsy is as complicated as a cardiac biopsy or even a lung biopsy, but that’s not a procedure you would just go and do willy-nilly to stick a needle into the liver with its risk of bleeding primarily or also infection

*Non-invasive diagnosis*

- We’re really talking about blood-based biomarkers and radiographic or imaging modalities
- 1 – The 2 most common blood-based biomarkers are the [transaminases ALT and AST](https://en.wikipedia.org/wiki/Elevated_transaminases)
- Unfortunately we cannot diagnose MASLD/NAFLD with those biomarkers
- The reason that we see an elevation of these during fat accumulation and/or fibrosis in the liver, is that these are enzymes made by the hepatocytes that are released into plasma when the liver is stressed

***As you see more ALT and AST, that indicates more stress [on the liver]***

- But it gets a little complicated because AST is also found in muscle
  - Therefore as you exercise, you will also see more AST increased into the plasma
- Peter’s AST is always higher than his ALT
  - His ALT is typically in the mid to high 20s and his AST is typically in the low to mid-30s
  - That is also the typical pattern for many of his patients, and that is a pattern that is pretty typical of people who are doing quite a bit of exercise

***The general rule of thumb is that you would like to see an AST and ALT both below about 30 IU/L***

- Again, Peter’s AST is typically a little bit above that
  - He’s not concerned about that, but being a curious person, he’s done some more imaging stuff to make sure there’s nothing going on
- Ultimately you have to handle each of these situations clinically

*There are also pharmacologic things that will raise AST and ALT*

- Lipid lowering drugs are a very common offender and will raise AST and ALT

*The threshold at which you should be concerned*

- Somewhere between 1.5 and 2-fold persistent increase would justify investigation
- Even if it’s in response to a drug, it would probably justify stopping that drug
  - For example, if you’re on a statin and this is happening, that’s probably reason to stop a statin (even though the guidelines might suggest you tolerate a higher level of increase)

**When you say stop a statin, do you abandon treatment or look at other potential drugs to lower CVD risk?**

- It would be the latter
- We treat the CVD or ASCVD risk using the tools that are available
- We include elevations of transaminases in the suite of things that we would view as a contraindication
- There’s not a doctor out there who would say, “*I’m going to give my patient a statin, but if they develop debilitating muscle pain, we’re just going to keep hammering them with it*.”
  - 4-5% of patients will develop significant myopathy for a statin use
    - It’s reversible, but obviously you’re going to stop the drug and find an alternative

*The big 3 things we always look to get people off a statin*

- Or at least off one statin onto another or just off the class altogether
- 1 – Muscle pain
- 2 – Significant elevation in transaminases
- 3 – A change in insulin sensitivity

**Let’s talk about what maybe is a better test**

- Measuring transaminases lacks sensitivity and specificity
- If a physician really wants to understand if their patient has MASLD and make that diagnosis, they really want to understand how much fat and how much fibrosis (if any) is present

***The gold standard is probably magnetic resonance elastography and proton density fat fraction (or PDFF)***

- That’s sort of looking at an MRI to make the diagnosis
- Now the problem with this is that it’s costly and it’s not a widely available test
  - You can’t just go to an MRI and get that done
  - That’s a very specific protocol

***From a practical standpoint, the more common tools are ultrasound and vibration methods that are less expensive, easier to do in a clinic***

*There’s a branded version of this that we typically use called* [*FibroScan*](https://www.echosens.com/en-us/)

- It’s a vibration controlled transient elastography, and it uses both vibration and ultrasound to basically give what’s called a [CAP score](https://www.mskcc.org/cancer-care/patient-education/understanding-your-fibroscan-results)
- This CAP score is called **c**ontrolled **a**ttenuation **p**arameter and we actually want to see that number
- So now we’re actually able to quantify the degree of fat and fibrosis in the liver
- And now we have a biomarker that we’re treating

**The real question here is what are we doing when we have this information?**

- You’ve now confirmed your patient or you as the individual have fat or fibrosis in your liver. Now what?
- Well here’s the thing, it’s not a really clear indication for a drug per se
- This is something that is going to respond most favorably to a reduction in excess adipose tissue and an improvement in insulin sensitivity
  - And depending on the etiology, a removal of the insulting agent

*What are we doing when we see this in patients?*

- 1 – We’re getting our patients to lose weight
  - Simple in concept can be challenging in practice, although at times it relies on drugs like [GLP-1 agonists](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist#Approved)
- 2 – We’re also being mindful of taking things away
  - If a patient, let’s say is drinking 5-6 drinks a week (which would not be considered excessive), but their FibroScan score comes back showing modest steatosis and/or fibrosis
    - We’re going to take all alcohol out of their diet
    - Because why would you add any additional insult?
- 3 – The other thing we’re going to do is remove liquid fructose from their diet
  - Although we have far less data for this
  - Everytime a study has been attempted to look at the isocaloric impact of liquid fructose, it has been unable to discern if that is different from isocaloric glucose because the subjects usually end up losing weight

***Liquid fructose and alcohol should probably be minimized if not avoided in people with MASLD/NAFLD***

**If someone is curious about the state of their liver, you mentioned ultrasound might be the easiest and most widely available thing**

*Do you have all your patients get ultrasounds to test their liver or is it only if you see potentially other things that are concerning that you want to see the state of it?*

- We do not do it for everybody
- We generally want to see some reason for investigation
  - Meaningful insulin resistance
  - We’re seeing something in the transaminases that doesn’t make sense
- Even though Peter was 99.9% sure he didn’t have this, with his AST usually being in the 30s (as opposed to the 20s), should he look?
  - No

**For someone who finds out they have MASLD or NAFLD, it can be reversed**

- The liver is a very flexible organ and unless you get to end-stage disease, it can recover
- It can recover from NASH [non-alcoholic steatohepatitis, now [MASH](https://en.wikipedia.org/wiki/Metabolic_dysfunction%E2%80%93associated_steatotic_liver_disease)]

*The liver is arguably the most resilient organ in the body from a regeneration standpoint*

- For example, you have 2 kidneys, and if you decided to donate one, you wouldn’t grow a second kidney
  - Your glomerular filtration rate, the marker of kidney function would permanently go down in the presence of you donating the kidney
- If you donated a lung to somebody for a lung transplant or if you had an injury that resulted in the loss of 1 of your lungs, the other lung does not pick up the full slack
- The liver, totally unlike that
  - If you donated half of your liver, probably even 2/3s of your liver to a person through surgery, or if you ended up undergoing surgery to remove 2/3s of your liver (say you were in a trauma or something like that)
  - Provided the architecture of your liver is healthy to begin with, the entire liver will physically regrow and resume full function within weeks to months

***Liver fat and liver fibrosis in the early stages is reversible; liver fibrosis in the late stage is what we call cirrhosis and is not reversible***

- If you find out you maybe have some fat in your liver, it’s not the end of the world
- It just means you want to take action against it

**Has anyone donated a liver multiple times based on the fact that it can grow back?**

- No
- The morbidity of that operation is so significant
- It’s not like going to the blood bank to give blood
- If you’re donating a liver, you’re donating to a loved one and you’re probably not signing up to donate a liver a year

## Joel Jamieson episode: heart rate variability (HRV) for training and health [27:15]

[#305 ‒ Heart rate variability: how to measure, interpret, and utilize HRV for training and health optimization | Joel Jamieson](https://peterattiamd.com/joeljamieson/) (June 10, 2024)

\*\*\*

- This podcast began by reminding everybody what [HRV](https://en.wikipedia.org/wiki/Heart_rate_variability) is
- It’s worth spending a moment on understanding that we have 2 nervous systems: 1 that we control and 1 that we don’t control
- The 1 we don’t control is called the [autonomic nervous system](https://en.wikipedia.org/wiki/Autonomic_nervous_system), and it has 2 branches: a [parasympathetic](https://en.wikipedia.org/wiki/Parasympathetic_nervous_system) and a [sympathetic](https://en.wikipedia.org/wiki/Sympathetic_nervous_system) branch
- Joel did a really good job of explaining that we typically speak of these as binary digital zero one type thing

*Sympathetic is fight-or-flight, parasympathetic is rest and digest; and while we think of it as one or the other, that’s not at all how it works*

***You want to think of these as actually quite analog and not digital ‒ think of them as knobs that get dialed up or down, somewhat dependently***

> “*Therefore, the best way to think of HRV (which I’ll define in a moment) is as a tool to help measure the relative amount that each of those knobs is being turned up or down.*”‒ Peter Attia

- A **high HRV** means the sympathetic knob is generally dialing down and the parasympathetic knob is dialing up and the reverse is true
- As we age, we lose that variability
- If you look at a graph where age is on the X-axis and heart rate variability on the Y-axis, this is an amazing decay curve
  - Using morning heart rate variability or stationary, midday (you lay down and put an EKG on)
  - Measuring it at consistent times
- It decays very significantly

**Why is that decay happening?**

- This becomes another **hallmark of aging** that we don’t spend a lot of time talking about: as we lose variability or as we lose plasticity of the autonomic nervous system, we see a contraction of HRV

**HRV definition**

- If anybody’s ever had an EKG, they can probably remember and picture the classic wave form, which is you have this flat line and then a little bump called the P wave and then a little flat line, and then a Q is a little dip down and then a big spike, RS, and then another T wave [shown below]

![](https://peterattiamd.com/wp-content/uploads/2024/09/f2-qps2.png)

**Figure 2. Labeled EKG readout where the time of the R-R interval is the beat-to-beat interval**. Image credit: [Morpheus](https://support.trainwithmorpheus.com/support/solutions/articles/4000202439-intro-to-heart-rate-variability)

- The PQRST is the electrical signal that we measure of a heartbeat
- You just pick a point on there and we pick the R wave, because that’s this big huge spike, and you measure literally the time between the beats
- So if a person’s heart is 60 beats per minute, you would have about 1000 milliseconds between each beat (which is 1 second)
- But even if they’re at a constant 60 beats per minute, it’s not actually an exact 1000 milliseconds
  - It might be 890 one time; it might be 1,107 another time

***The variability in that RR interval, is the definition of HRV***

**Mathematical ways to determine HRV**

- If you’re using a wearable, it’s reporting it in milliseconds
  - Usually what they’re not telling you is which algorithm they’re using, but you can always find out

***The most common one is called the RMSSD or root-mean-square of standard deviation***

- It’s obtained by first calculating each successive time difference between heartbeats in milliseconds
- If you run a string of 2 minutes of testing, you would literally measure in milliseconds each of those things
- Each of those values is squared, then averaged, and then the square root of the total is obtained (really simple math)
- You could do this in Excel if you had all the data

*It’s important to understand that not everybody is using this method*

- We talked a lot about a device that Peter uses, the [Morpheus device](https://trainwithmorpheus.com/)
  - Which Joel happens to be the CEO and founder of
  - Peter has no affiliation with them, but he’s a huge proponent and we talked about it at length

***Morpheus uses a different mathematical transformation called a log-normal transformation to make the data look normally distributed***

- It’s not really an issue as to whether one of these methods is better than the other
- Peter likes the log-normal distribution better because he thinks it gives a broader array of values and makes for variability within the HRV to be more present
- The most important thing is not to worry about whether you’re using an RMSSD algorithm or a log-normal transformation. The most important thing is, “*What is the variation for you as the individual?*”

***That variation is even more important than your actual number***

- You want to have a sense of what your baseline is and how is it changing in response to various things

**How do you measure HRV?**

- 1 – The gold standard is to measure off an electrical signal of the heart itself, and the gold standard for that would be an EKG
  - A 3 or 6-lead EKG on the chest, lay there, and get heart rate variability
- For many purposes in research, that’s how it’s done
- This is important because so much of what we say about HRV, we say on the basis of what we learned from these research studies
- But nobody (Peter included) is walking around with a 3 or 6-lead EKG on their chest all day trying to infer this
- 2 – The next thing you can do that would be right under that in terms of real value would be using a chest strap device and looking at the polarization of the chambers in the heart as they’re beating off a single chest lead
  - This is also very good
  - For the purpose of the real world, this should be considered the gold standard
  - If you put a Polar chest strap on and measure HRV, you will be within 1 millisecond of what your HRV is if you were using an EKG lead
  - And everything else besides that is a step away
- 3 – The next best thing you can use to measure HRV would be an optical sensor high on the forearm
- Optical sensors are notoriously inaccurate, but if you can give them a large look at blood vessels, they get a lot more accurate
  - Peter discussed on the podcast with Joel that on his  body, he does this all the time where he’ll wear the chest lead (Polar chest strap, gold standard polar), and then he’ll also wear an optical sensor on his forearm and he’ll see both numbers side by side
    - The chest is the more accurate one
    - The forearm optical sensor would be within 2-3 beats per minute, and sometimes it’s right on, depending on how much my heart rate is moving
- Go down the wrist and throw an optical sensor on the wrist (a Garmin sports watch) ‒ it’s just not accurate enough

***You cannot rely on a wrist-based optical sensor for heart rate data; it’s not accurate enough in to be a tool to study HRV***

- Peter can’t speak to every wrist device, only sports watches that he typically uses for other things to track GPS and speed
  - He’s tried (and failed) to get a good enough wrist-based device to provide remotely accurate heart rate data
- He’s very skeptical that an optical sensor on the wrist is going to be sufficient for really accurate heart rate variability
- The closer you can be to the heart, the better, and the only exception he’s found to that is an optical sensor that works on the forearm
  - Because in the antecubital fossa, the size and closeness of the blood vessels to the skin make this actually quite good

**High and low can be different for people and someone at a 50 can be high and someone out of 50 can be low, and so it’s more about measuring against your baseline as opposed to measuring against your spouse’s HRV**

- What matters to Peter more is, “*How does my HRV change from day to day?*”
- Peter uses an [Eight Sleep](https://www.eightsleep.com/), and the Eight Sleep is very accurate at measuring HRV because it’s getting the electrical signal off your heart as well
  - It’s like using a mattress cover as a chest strap
  - It’s measuring it in RMSSD
- Then every morning he uses Morpheus
  - It’s using that log-normal transformation, and those numbers are totally different from RMSSD
- *Peter’s disclosure*: he is an advisor to Eight Sleep, but he does not have an affiliation with Morpheus

## Practical tools for measuring HRV and how it informs training and recovery decisions [37:00]

**Peter’s numbers**

- On the Eight Sleep (which is RMSSD) his heart rate variability is in the low 30’s, maybe 32, 33
  - This is the overnight variability, so it’s measuring an average of based on sampling overnight
- If he’s in the 20s, something is really off
- Conversely, his Morpheus number was 80, 81 milliseconds today
  - It’s very different because they’re using a different mathematical feature to calculate the data

***He’s never comparing numbers from the Eight Sleep to Morpheus, nor would he compare his numbers to someone else’s***

**Why it’s best to measure HRV 1st thing in the morning**

- This is better than checking over the course of the night
- Joel explained a really elegant way to think about this
  - Sleep is probably the single most important thing you’re doing to recover
  - And so if sleep is the recovery, then you measure the output of the recovery first thing in the morning
- That’s why laying there for 2-3 minutes to do that HRV test in the morning is basically measuring the efficacy of the behavior you just did to recover
- For Peter, that just really solidified how he now thinks about it
- He’s directing most patients who want to be using data in this way to lean towards the Morpheus if they’re looking for that type of guidance

**What do you look for in terms of a difference in numbers?**

*Let’s say your baseline HRV is 50, and one day you wake up and it’s 48, another day it’s 52, one day it’s 35. When do you start to think, “Maybe I’m not fully recovered”?*

- This is where it gets quite complicated
- This podcast was not a commercial for Morpheus
  - It’s just hard to talk to somebody who’s as knowledgeable about this as Joel without also talking about this product that he’s created that Peter thinks is incredibly valuable
- Peter has tested all of the products and finds them all to be utterly unhelpful (standard wearables that give you a recovery score)
  - He has spent years looking at that recovery score and trying to see if it predicts his performance
    - The answer is, it does not
- 2 years ago, he started looking at Morpheus, and it’s technically doing a better job measuring HRV than all these devices
- Joel’s work was looking at a smoothing function of HRV data
  - Not just HRV but HRV variability
  - Looking at the 1st derivative and the 2nd derivative, and how those things are changing

***Morpheus gives you 3 heart rate zones ‒ Peter and Beth Lewis realized that what it’s spitting out as the zone 1, zone 2 border should be your zone 2 heart rate that day***

- And those numbers change every single day
- Peter thought there was zero chance that this device was going to be good enough to predict his zone 2 heart rate for a given day, so he started recording it every single day (and still does to this day)
  - For every bike ride he records: power, average watts, Morpeeus-predicted heart rate for zone 2, the heart rate he actually went to based on [RPE](https://en.wikipedia.org/wiki/Rating_of_perceived_exertion), and lactate at the end of the ride

***While it’s far from perfect, if we rely on the gold standard which is lactate, the Morpheus heart rate prediction is better than anything else (it’s not even close)***

- That’s a long-winded way of saying that Peter finds this to be a very favorable tool
- Today, even though he had a high HRV (in the 80s), his recovery score was actually very low (68%)
  - That was based on not just today, but where it was in the overall arc of his HRV
  - Morpheus spit out a heart rate of 130 as his target heart rate for zone 2
    - That’s way lower than he would normally ride to
    - But he rode the bike and tried to stay at 130
    - He finished the ride at 134, and his lactate was 2.1 (a little higher than it should have been)
    - Really, he wanted to finish that ride at a lactate at 1.8, 1.9
  - There’s other times when he’ll do a ride at 140 beats per minute and his lactate will be 1.6

> “*I do think that for people who want a little bit of direction on how the day-to-day variability of their recovery is factoring into it, I find this type of tool infinitely more valuable than, ‘Hey, my sleep tracker told me my recovery score is 81 today.’*”‒ Peter Attia

**Peter uses Morpheus for multiple things**

- 1 – Understanding HRV and recovery
- 2 – Determining the target heart rate for zone 2 exercise
- Again, he has not affiliation with Morpheus

*Other ways to determine zone 2*

- Testing for lactate sucks and little things can cause it to go wrong
- A lot of times people will do the talk test [[discussed here](https://peterattiamd.com/how-to-find-your-zone-2-without-using-a-lactate-meter/)]
- Maybe 180-age for a target heart rate

**What a low HRV means**

- A low HRV generally means you are not recovered enough, and your training might not be as beneficial as it would other be
  - Your performance might not be as good as it would otherwise be
  - There may be costs associated with training hard that day
- You don’t want low HRV to have the implication that you can’t go out and train or train hard that day

*How low would HRV need to be for you to get it checked-out by your doctor?*

- In Morpheus, if you are consistently in the 40s
- Using an RMSSD calculator, if you’re consistently 10, 11, 12
- That doesn’t mean there is anything wrong; it just means it might be worth looking into

**HRV provides information about recovery**

- A low HRV doesn’t mean you shouldn’t work-out, but maybe you’re not pushing hard that day
- Peter has never taken a day off training as a result of anything the Morpheus has ever said
- He’s training hard for an old man, but he’s not training the way he used to train many years ago

**What causes you not to train in a day?**

- Peter doesn’t schedule days off; he does exercise 7 days a week
- But at least once or twice a month he can’t do a workout due to travel
  - The last time it happened was when he was flying back from Europe
    - His day started at 5 in the morning in Europe, and by the time he landed back in the US after a connection, it was probably 5:00 PM
    - He wasn’t going to come home and work out, and he clearly wasn’t going to get a workout during that day
  - He doesn’t lose sleep over that stuff

## Zak Kohane episode: artificial intelligence and medicine [47:15]

[#309 ‒ AI in medicine: its potential to revolutionize disease prediction, diagnosis, and outcomes, causes for concern in medicine and beyond, and more | Isaac Kohane, M.D., Ph.D.](https://peterattiamd.com/isaackohane/) (July 15, 2024)

\*\*\*

- AI is a topic Peter didn’t know much and his learning was enormous through this podcast
- The **first wave of AI** was in the 1950s, the advent of the computing era post-World War II
- This was when people were using the [Turing test](https://en.wikipedia.org/wiki/Turing_test) as the metric (more on this in a minute)
- The **second wave** was in the ‘80s, and both of these waves were unsuccessful
- Zak was a part of the wave in the ‘80s due to his background in computer science and medicine
- The goalpost for what artificial intelligence is has been a constantly moving target
- Peter remembers back when he was in college, when we talked about this, we just said the goalpost was the Turing test
  - If a computer can pass the Turing Test, we have achieved AI
- The **Turing test** basically says, “*Can a computer mimic its side of a conversation with a human without revealing that it was a computer?*”
  - In other words, could you engage in a discussion with a computer where the responses are such that you believe that they’re human responses?
  - And the truth of it is we’ve long passed the Turing test

**The question is, have we really achieved what we think of as AI?**

- That’s not something Peter is going to attempt to answer  here
- It’s just worth understanding that passing the Turing test and intelligence, superintelligence, all of these things are pretty different and it’s obviously a continuum
- But clearly intelligence and self-awareness are correlated, and they’re a separate phenomenon
  - A bird can recognize itself in the mirror, so it has self-awareness, but it’s not a superintelligent being

**3 things were necessary to enable the current heyday and what we call this third wave of AI**

- What was interesting is how we got here
- 1 – Data advancement
  - AI has to be trained on Data
  - It wasn’t until the mid-90s that we began to see an explosion of data vis-a-vis the internet to create a large enough training set
- 2 – The advancement in development of deep neural networks (a theoretical idea)
  - And the idea that you could stack these neural networks on top of each other, so you had now parallel neural networks that could foster learning in a much deeper way
- 3 – Computational
  - The development of these graphical processing units (or GPUs) which actually came about for the development of video games
  - They led to the enormous calculating power required for AI

**As a personal aside here, Peter has had various car simulators for the last 10 years**

- He’s always needed whatever the most powerful GPU that’s available at the time to run the simulator for a car, because car simulator games are about as demanding as anything you’ll ever do
  - Much more demanding than flight simulators because of the speed with which things are going by
  - You need a very, very high refresh rate
- What became clear was how much the availability of these things was getting harder and harder to get in the last few years
  - Both mining for crypto and AI have made the availability of top-end GPUs more and more difficult to get
- What’s cool about these GPUs is that there was really interesting matrix algebra that Peter was learning in undergrad that was used in video games to calculate the weight of edges between things in a simulation that are the exact same math
  - This type of linear algebra is what’s used in these deep neural networks

**The other real prerequisite for AI success was something called the transformer**

- This fell out of the massive investment into AI that was made after all these prior decades
- There’s a very, very famous paper, which Peter recommends everybody go and look at
  - Even though most of us don’t understand it in enough detail to get anything out of it
  - It’s called [*Attention Is All You Need*](https://arxiv.org/html/1706.03762v7), and it was Google publication from 2017
  - It’s basically what allowed words to be turned into mathematical models, language-based models
- Without the transformer, we wouldn’t have GPT

**One little stat on this that is just remarkable**

- Everybody understands what linear algebra is, or we can remember what it was if we go back in time
- So you might have a linear algebraic equation that is A1, X1 + A2, X2 + A3, X3
  - Where X1, X2, X3 down to XN are variables that you put into the equation
  - And then A1, A2, A3 down to AN are constants (those are things that have been fit on the line)
- To give you an example, if you said, “*Hey Peter, can you build me an equation for what my water bill is going to be next month?*”
  - Sure, you’re water bill is going to be a function of your fixed flat rate plus how much water you use during the month
  - It’s a very simple equation: it’s AX + B
    - With B being your fixed rate and A being some multiple of X, the amount of water you use per month
- Then if you said, “*Well, Peter, that’s easy. Okay, thank you for that. Can you tell me what my electrical bill is going to be?*”
  - That’s a more complicated equation, but it’s the same thing
  - You’ve got this constant piece and then you’ve got usage pieces, but the usage pieces vary on what time of day
    - So if you’re using during this time of day, the rate is this
    - If you’re using during this time of day, the rate is that, etc. So that might have like 4 or 5 variables in it
- It turns out that [ChatGPT](https://openai.com/index/chatgpt/) is also a linear algebraic equation, except it has 1 trillion variables in it
  - Think about that for a moment
  - When you go into ChatGPT and type something in, that language gets converted into linear algebra that runs an equation with a trillion variables
  - Peter finds this to be the most amazing thing ever

## The current role of AI in medicine and how it could revolutionize medicine in the future [53:45]

**Where does medicine fit into all of this?**

- When you hear people talk about AI, there’s a lot of hype, but there’s also some skepticism
- This didn’t come up in the podcast with Zak because it came out after, but *The Wall Street Journal* wrote an interesting [article](https://www.wsj.com/tech/ai/the-ai-revolution-is-already-losing-steam-a93478b1) about this in June where they talked about AI is really under-delivering at the moment relative to its investment
  - When you look at the amount of dollars that are flowing into AI and you look at the returns, they’re very poor
- The 1st place AI is going to impact medicine, and it’s already having some effect, is in **image recognition**

***You’re really talking about 3 fields of medicine that AI would heavily impact: radiology, dermatology, and pathology***

**The idea that even in those areas, AI could replace physicians is not likely because image recognition by itself is insufficient**

- You have to have basically the clinical information that goes with it

*Most people have already interacted with AI and medicine without realizing it*

- When Zak pointed this out, Peter never really thought of it that way
- Anyone who’s ever had an EKG, if you look at the report, it spits out a diagnosis at the top
  - For example, it might say: “*Sinus bradycardia, left bundle branch block,*” and the computer figured that out
  - It’s been doing that for 40 years
  - That’s an example of image recognition

**If we talk about radiology, dermatology and pathology, you’re now getting into much more complicated image recognition**

- One of the stories Zak shared that Peter found mind-boggling was the story of how he fed one of the [images](https://www.nejm.org/image-challenge?ci=20231005) from *The New England Journal of Medicine’s* Weekly images in medicine articles in
  - It was a very complicated skin lesion [shown below]
  - It showed an image and gave a few details, “*This is a patient who in the last week did X, Y and Z, and they had eaten some mushrooms.*”
  - AI spits out 2 explanations for this: either reaction to a very obscure drug or consumption of this very rare type of mushroom
  - That’s pretty remarkable, but will probably be improved by the use of clinical inputs

![](https://peterattiamd.com/wp-content/uploads/2024/09/f3-qps2.png)

**Figure 3. NEJM Image challenge from October 5, 2023**. Image credit: [*NEJM*](https://www.nejm.org/image-challenge?ci=20231005)

**The second area where Peter thinks we really want to see AI in medicine is when we use visual and language data as the inputs**

- This is really the bread and butter of what medicine is from a diagnostic perspective
- So this is where we would want to be able to put everything in there
- For example, a person walks in the ER and they have symptoms, they’re having this type of pain or this type of rash, and then you also have imaging information and then a whole bunch about them
  - This is their age, their sex, their smoking history, their oxygen saturation, these are their blood levels
  - How can you put all of that in?

***The truth of it is this is mostly just a training problem at this point. In other words, we actually have the data to do this right now. What needs to be done is the training of the system.***

- Peter thinks that’s generally something to be optimistic about
- **Electronic medical records (EMRs)** are obviously going to play an important role in this
- Peter gets asked this question all the time, “*Hey Peter, we have EMRs now*.”
  - With the passage of the Affordable Care Act, EMRs became mandatory, so we should have at least a decade’s worth of EMR data
  - That’s true, but data quality also matters
- A lot of what’s in EMRs is scanned documents that would still need to be optical character recognized
- You don’t have the correlations between necessarily this happened and that happened
- You don’t have great follow- up data on the outcomes

***Zak was optimistic that this is going to be done, that we will train on these EMRs, but he does think it will be much harder in the US than in other countries because one of the advantages that other countries have over the US is they have a unified health system, therefore a unified EMR system***

- In the US, anybody who’s interacted with the US healthcare system knows even if everybody’s on an EMR, they’re all different and they’re all quite user hostile

**Within a decade, Zak believes AI will be able to carry out certain types of surgeries more effectively than even a surgeon**

- One of the examples he gave was a **radical prostatectomy**
- This is very hard for Peter to wrap his mind around that
  - If you told him 25 years ago that no one will undergo an open prostatectomy anymore, and it will all be done by a surgeon sitting down in the corner of the OR using a robot, it’s not that he wouldn’t have believed it
  - He would’ve thought of all the reasons why that would’ve been hard
    - And it turned out the robot is a much better way to do that operation
    - So it’s not really the biggest leap to say, “*Well, if the robot is doing this operation with input from the surgeon and the surgeon is basically using visual cues to make decisions, why can’t that be trained?*”

**Zak also said there’s no reason to assume that AI won’t someday be able to look at changes in gait, voice, eye movement, and other clinical data and diagnose say, neurodegenerative diseases 20 years ahead of when they show up**

- Again, it all comes back to training, training, training
- How are we going to train these data sets to do this and how much longitudinal data do we need with the individuals to gather this?

## The limitations and concerns pertaining to AI [1:00:15]

**It’s very tempting to think AI is going to solve all these problems**

- One of the questions Peter gets asked all the time is, “*Peter, when are you going to just set AI loose and have it replace all of your analysts?*”

***The truth of the matter is, his analysts job security is better than ever because AI is so bad at doing what analysts do***

*It’s actually alarming how bad it is*

- For example, it doesn’t take a brilliant analyst to read a paper and sort of synthesize and summarize what the findings of the paper are
- And AI is very good at doing that right now, but that’s not actually the job of an analyst

***The job of an analyst is to bring judgment and discernment over what you’re reading (and AI is bad at this)***

- Peter thinks it’s safe to say (and he knows this sounds hyperbolic, but it’s probably true) that 70-90% of published research is either wrong or mostly irrelevant
  - Based on data that look back at citations and things of that nature
    - How often is research actually cited going forward if you exclude auto-citation?
- That means that the real skill is not reading a paper and summarizing it or doing a book report
- It’s knowing if it’s relevant and if it is worth changing your practice based on

**Peter has had a couple of follow-up interactions with Zak about 2 big concerns**

- 1 – The first is, why is AI such a pathological confounding liar at times?
- Meaning, Peter will ask an AI a question and it will produce an answer, it will give a reference from a journal that will look totally official and he will realize that that is not even a real journal
  - It has made up the entire story
  - There is no journal of “fill in the blank” and there certainly is no reference
  - Therefore, everything it just said is incorrect
- When Peter asked Zak about this, he goes, “*Yeah, that is one of the challenges of AI is it can’t say ‘I don’t know’.*”
- 2 – Peter and Zak have sat there on the screen and going into their favorite AIs and asked questions they know the answer to that are very complicated
- For example, *What is the case for and against Metformin as a geroprotective agent?*
  - That’s a question that everybody needs to know the answer to
  - Give me the pros and cons surveying all of the literature for whether or not [metformin](https://en.wikipedia.org/wiki/Metformin) is or is not geroprotective
  - You wouldn’t believe the nonsense this thing spit out
    - Even if you assume everything it said was technically true and it wasn’t lying to
  - Its answer was of no value
  - Peter can say that because he knows how nuanced a question that is, and he knows that to answer that question, you have to be able to distinguish between the Bannister paper and the Keys paper [discussed in [episode #270](https://peterattiamd.com/andrewhuberman2/) and a previous [newsletter](https://peterattiamd.com/a-recent-metformin-study-casts-doubts-on-longevity-indications/)]
  - And then you would look at some of the experimental stuff
- If someone asked Peterthat question, he would start with the epidemiology of Bannister and Keys, and then look at the experimental data and also the mechanistic data

**Peter’s takeaway**

- We have a long way for AI to really replace critical thought in medicine
- But he’s really excited about the potential for AI taking some of the really heavy lifting off data interpretation and trend identification
  - And ultimately probably coming up with ways to impact behavior through smarter ways to present data to people to identify things that people can be doing to change
- But when it comes to answering deep questions that require expertise, domain expertise and critical thought, Peter thinks we’re further away than he thought

## Dena Dubal episode: the potential benefits of klotho for brain health [1:05:00]

[#303 – A breakthrough in Alzheimer’s disease: the promising potential of klotho for brain health, cognitive decline, and as a therapeutic tool for Alzheimer’s disease | Dena Dubal, M.D., Ph.D.](https://peterattiamd.com/denadubal/) (May 27, 2024)

\*\*\*

- This is another technical episode, but it’s something Peter is very excited about
- If there was 1 topic Peter most wanted to talk about in the past quarter, it’s be tough to say there was something more than [klotho](https://en.wikipedia.org/wiki/Klotho_(biology))
- Peter’s disclosure: he’s an investor in a company that has licensed Dena’s technology from UCSF to try to bring this into human clinical trials
- Dena is a physician scientist, a neurologist at UCSF, who has played a significant prominent role in not the discovery of klotho, but the discovery of what it can do in the brain

**Klotho was discovered in 1997 while another scientist was manipulating mice genomes to study hypertension**

- He was making small changes in amino acids and base pairs, which would alter amino acids in mice trying to alter a sodium transporters or something
- And one of the subsets of mice in which he made these genetic mutations became incredibly short-lived
  - A mouse should live about 2.5 years
  - These things were living for 3 months and they were rapidly aging after 2 weeks
  - He investigated the cause and found he had disrupted a single gene and that gene he named *klotho*
  - And of course to really know if manipulating that gene or that that’s a longevity gene, you have to overexpress the gene to see if it has a benefit
    - It clearly looks like a longevity gene in the negative, meaning you take the gene away, you’re going to die very quickly
- Sure enough, overexpressing the *klotho* gene in mice enhanced lifespan by 30%
  - Which is a really big deal in terms of lifespan

**What is klotho?**

- It’s a protein that is made by this *klotho* gene
- It’s a pretty decent sized protein, about a 1000 amino acids
- It’s produced mostly by the kidneys, but also some in the choroid plexus of the brain
- What’s interesting (and this is not uncommon): a lot of times the body makes a protein, but then the protein gets cut and it’s the piece that gets cut that is the active one
  - Of course the obvious example of this that every medical student will tell you about is insulin
  - Insulin is secreted as a prohormone by the pancreas, it gets cut, and then insulin goes away and does its thing
    - And then the C peptide doesn’t do anything, but we can measure it

*Klotho is a transmembrane protein*

- It’s made by the kidney and it spans the membrane once, and then the outer portion is clipped (and that soluble fraction is the active component)
- The soluble part is the hormone, that’s the equivalent thing to what we think of as insulin, and it travels through the body
- Peter emphasizes, “*I really want to be clear this summary is absolutely not a substitute for the podcast because there’s just so much to go through the story here.*”

**The punchline here is klotho does not cross the blood-brain barrier**

- The question then becomes, “*Well, wait a minute, how is it going to do all the stuff that we’re going to talk about in the next few minutes if it doesn’t even get into the brain and yet, all of these benefits that at least the ones we discussed with Dina seem to be in the brain?*”

**There are actually a lot of benefits of klotho in the body, but we focus this one on the brain**

- It turns out that after some discovery, it appears that what klotho does (among other things) is it increases in the periphery, something called [platelet factor four (PF4)](https://en.wikipedia.org/wiki/Platelet_factor_4), and PF4 does indeed cross the blood-brain barrier
- What happens next is not a 100% settled, but it looks pretty good that PF4 binds to something called the [GluN2B subunit](https://en.wikipedia.org/wiki/GRIN2B) of the [NMDA receptor](https://en.wikipedia.org/wiki/NMDA_receptor#Structure), and that changes the influx of calcium to increase synaptic maturation and promote plasticity
  - Oh, boy, that’s a lot
  - What the heck does that mean in English?
  - Synapses are the spaces between neurons, and when you think about the parts of your brain that are most important for memory consolidation, working memory, and ultimately parts of your brain that succumb to dementia, they happen to have a lot of these receptors called NMDA receptors
  - Those receptors happen to have a subunit where calcium gets released, and the release of calcium turns out to facilitate the plasticity and the development of the connections that are important in this part of the brain

***To simplify what klotho appears to be doing, klotho appears to protect that part of the brain***

*Now here’s where it gets a little bit confusing*

- If you block PF4, klotho is still working
- So that means that PF4 is sufficient but not necessary, and that there are probably multiple pathways through which klotho works towards brain health

**Dena talked about another very interesting finding**

- This is in parallel to her work in her lab
- Looking at the impact of klotho on PF4 and the impact of that on brain health
- 2 other groups independently were looking at how exercise and transfusion of young animal blood was doing the exact same thing

***The common factor was an increase in PF4 ‒ this occurred in response to klotho, exercise, and transfusion of young blood to older animals***

## Animal studies on klotho and brain health [1:11:00]

**We talked at length about the clinical or animal clinical literature**

*Looking at the effect of peripheral klotho administration in mice and ultimately primates for either disease prevention or cognitive enhancement*

- What’s interesting is that if you took mice that were genetically predisposed to get Alzheimer’s disease
  - There are many models of mice that are genetically predisposed to get Alzheimer’s disease, but one of them is called the [J20 mouse](https://www.alzforum.org/research-models/j20-pdgf-appswind)
    - This is an analog of the APP genetic variation in human dementia
    - APP is very rare; about 1% of people with Alzheimer’s disease have it through the APP pathway, which is one of the few deterministic pathways of Alzheimer’s disease
- These mice develop very early and aggressive burden of amyloid
- When a human being has an APP mutation, they’re going to get Alzheimer’s disease very early in life (typically in their 50s)
- These mice will typically have synaptic loss within 3 months of life, and they’ll be cognitively compromised by 3-4  months of life
- So it’s even more aggressive in mice than humans
- Interestingly, when you change klotho expression in these mice and you increase the levels to 3-4X where they are
  - By the way, this is just returning them to what they were at birth
- We are born with high levels of klotho and it declines as we age
  - In my 50s, my klotho levels are probably ¼-⅙th what they were at birth
- In this experiment, when you restore klotho to the levels that they were at birth, the disease does not take hold despite the fact that the amyloid and tau are laid down in the brain

***In other words, klotho overexpression doesn’t undo the insult; it makes the brain less susceptible to the insult, and that’s pretty remarkable***

**We talk a lot more about other animal models in here, but the most important are the primates (the macaques)**

- Lots of things work in mice, and then they don’t work in primates
- Dena and her colleagues [studied](https://pubmed.ncbi.nlm.nih.gov/37400721/) this in rhesus macaques
- Interestingly here, we’re not looking at a cognitive deficit model
- We’re looking at enhanced cognition in a normal animal ‒ after basically 1 single injection of klotho, which just gave them a high physiologic level
  - This was like taking the equivalent of a 30 or 40-year-old monkey, and you inject him with enough klotho that it replicates what he would’ve had as a child

***Within 4 hours of the injection, he has improved cognition in spatial memory, and it stayed that way for 3-4 weeks***

- The effect size gets bigger as the task difficulty increases
- All of that is a prelude to what we care about here, which is in humans

## Genetics-based variations in klotho levels in humans and their impact on cognition, disease risk, and longevity [1:14:15]

- We have roughly a 6X reduction between birth and adulthood in klotho
- We also know that klotho levels change throughout the day
  - So you might have higher levels in the morning, and then your nadir is probably around midnight
  - You peak first thing in the morning
  - You nadir at midnight
  - In that sense, it sort of parallels cortisol
    - Although paradoxically high cortisol probably reduces klotho

**Genetic variations in klotho in humans and the** ***KL-VS*** **variant**

- A very interesting observation emerged ‒ not everybody walks around with the same amount of klotho
- There’s one variant known as *KL-VS*: it’s a substitute of 2 amino acids
- In people who are the wild type (meaning people who have the normal version of *klotho*), they produce X amount of klotho

***But if you have 1 of the altered versions of KL-VS, you have about 15% more klotho***

- [These individuals are heterozygous for *KL-VS*, meaning they have 1 copy of *KL-VS* and 1 copy of the wild type *klotho* gene]
- No one knows why this is the case because it’s counterintuitive
- Dena speculated that if you have 1 copy of the variant gene, which we know makes a less effective protein, the other gene overcompensates for it and it might be that it’s just overshooting
- Therefore, those who are homozygous (meaning those that have 2 copies of the *KL-VS* variant), they actually have a 30% reduction in klotho
  - That’s also associated with worse cognition and a shorter life

> “*In humans, klotho is indeed a longevity gene. More klotho from the gene means longer life, better cognition. Take it away, shorter life, worse cognition.*”‒ Peter Attia

- What came out of an enormous [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/32282020/) at Stanford, is if you look at people by APOE4 status and you overlay on those data, the *KL-VS* heterozygosity ‒ it abrogates the effect of APOE4
  - We know what the risk of Alzheimer’s disease in people with APOE4

***To put that in English, what it means is if you have the good gene for KL-VS, it erases your APOE4 risk for Alzheimer’s disease***

**In addition to that, the benefits of klotho appear to extend beyond brain health**

- If you look at those people that have the *KL-VS* heterozygosity, they don’t just have a reduction in cognitive poor outcomes, it’s also associated with lower all-cause mortality
  - There aren’t that many of them; it’s maybe 20% of the population
    - It’s a reasonable number, but it’s not a huge number
- We talked about this [one study](https://pubmed.ncbi.nlm.nih.gov/21474560/) where if you had 30% less klotho at any given time, you had a 30% increase in all-cause mortality over the next 5 years
  - And it was primarily through heart disease and cancer
  - These were people in their 50s and older

## Testing klotho levels, the significance of the KL-VS variant, the role of exercise in increasing klotho, and more [1:17:30]

- Peter doesn’t think he’s ever received more inbound text messages from friends, and patients and emails as after this podcast

*1 – How do I test my klotho levels?*

- There is no CLIA-approved assay for testing klotho levels yet
- Dena can test a klotho level, but she’s only able to test it in a person who is part of a study that she is running
- There are apparently people out there claiming that they can measure their klotho levels

***It is very important to understand that there is no agreed upon standard for how that works***

- Just because you go online and there’s somebody saying they can measure your klotho levels, there is no laboratory certified method to do that
- And that’s very different from if you want to go out and measure your testosterone level or your sodium level or your white blood cell count
  - Because when you do that, you can go to any lab that is accredited and know that there are standards in place to do it, and that is not the case for klotho

***Buyer beware: if you’re going out there measuring your klotho levels, God only knows what you’re measuring***

*2 – How do I measure if I have the KL-VS variant?*

- This is measuring the [SNPs](https://en.wikipedia.org/wiki/Single-nucleotide_polymorphism) that define the *KL-VS* variant
- So what does *KL-VS* stand for?
  - The KL stands for klotho, and the VS stands for valine and serine
  - Both SNPs are in the coding region, and therefore they change 2 amino acids in the klotho protein
    - The VS in this means that the valine results from the first SNP, and the serine results from the second SNP
  - Now, both of these SNPs travel together
    - It’s what’s called the positive linkage disequilibrium
    - And therefore, reading either one will give you the same thing [you only need to determine 1 SNP]
- The **1st SNP** goes by rs9536314, and that’s for F352V
  - This is how you can query this if you’re looking at your data
  - A phenylalanine is changed to a valine at amino acid position 352
  - Genetic sequence TT is the wild type, while TG is the *KL-VS*
- The **second SNP** goes by rs9527025 for C370S
  - C370S means a cysteine is changed to a serine at the position of 370
  - Genetic sequence GG is the wild type, while CG is the *KL-VS*
- Both of those are heterozygous
- Then there is a *KL-VS* homozygous [genotype]

***Peter is hearing from people that you’re able to check this on*** [***Ancestry***](https://www.ancestry.com/) ***and*** [***23and Me***](https://www.23andme.com/)

*3 – What are the things I can do to increase my klotho levels?*

- We talked about those in the podcast

***Exercise appears to be the biggest thing that can increase it***

- It’s hard to know how much of this is in lifetime exercising versus you capture all the benefit as a chronic exercise and then it goes away, it’s not clear
- The largest [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/36266389/) that we discussed on the podcast looked at 12 weeks of relatively intense exercise, and it showed an average of about a 30% increase in klotho levels
  - It’s worth pointing out, that’s more than the increase in klotho that you see from the *KL-VS* variant
- ***KL-VS*** **heterozygosity** results in 15-20% increase in klotho, it’s going to eliminate your APOE4 risk, and it’s going to reduce your all-cause mortality
- Exercise can increase klotho by almost twice that amount to 30%

> “*I think of that to mean that’s just more proof that exercise is hands down the most potent intervention we have to improve lifespan.*”‒ Peter Attia

*4 – Question about* [*rapamycin*](https://en.wikipedia.org/wiki/Sirolimus)*: Does mTOR inhibition increase klotho levels?*

- The data here are not great; the studies have not been done to look at this
- In one [study](https://pubmed.ncbi.nlm.nih.gov/21672148/), they looked at human proximal tubule kidney cells in culture
  - These are the cells that make klotho
  - When they gave rapamycin, it increased klotho mRNA and protein levels by about 1.5 to 2-fold in a dose dependent manner
- Again, this has not been documented in vivo
- If you look at [rats with chronic renal failure](https://pubmed.ncbi.nlm.nih.gov/26061549/), rapamycin treatment increases circulating klotho levels
- In [kidney transplant patients](https://pubmed.ncbi.nlm.nih.gov/33758105/) who were taking everolimus (which is an mTOR inhibitor that’s almost identical to rapamycin) had a bigger increase in klotho following the transplant
  - But of course, that doesn’t prove anything
  - It could be that they’re better off and that’s why they higher klotho, as opposed to they have higher klotho and that’s why they’re better off

***The short answer is there are much better ways to study the impact of rapa, but it is interesting to note that rapa seems associated with an increase in klotho***

## The potential of klotho as a treatment for cognitive decline and Alzheimer’s disease [1:23:15]

- Human studies need to be done, and we’re still a little bit away before we know more
- There is hope that klotho has the potential to prevent cognitive impairment and Alzheimer’s disease, and maybe reverse it

**In an ideal world, if everything works out with klotho, what’s the potential there?**

- First and foremost, you want to be able to create a drug out of this where you’re literally injecting people with klotho, just as Dena has demonstrated and others have demonstrated you can inject mice and monkeys with it
- The first population you would start with are those who are either on the precipice of [MCI](https://en.wikipedia.org/wiki/Mild_cognitive_impairment), have MCI, or maybe even those that are already in the stages of dementia
- It’s hard to say what would be the impact once a person already has dementia

***At a minimum, we would want to use this in high-risk individuals as a prophylaxis, and potentially a treatment in the early stages***

- Just as GLP-1 agonists are now the drug de jour for weight loss, that’s not how it came about
  - These are drugs that were developed to treat people with type 2 diabetes
  - But it became clear that not only was it effective at treating type 2 diabetes, it was highly efficacious in reducing food intake
  - Now off-label, Peter would argue that these drugs will have a much bigger impact through weight loss
- There’s a parallel scenario here where if klotho administration was beneficial at reducing the risk of disease, there might indeed emerge another indication around cognitive enhancement
- Peter doesn’t think it would be as clean an indication because normal cognitive aging is not a disease, whereas obesity is a disease
  - That’s probably a regulatory question that’s well above his pay grade
- You can imagine many scenarios where people who do not have dementia still want enhancement with klotho, and say, “*Look, I would like to have the klotho levels that I had when I was 10 years old instead of the levels I have today when I’m 60.*”

**Again, assuming everything with studies is positive, how long are we out before something like this is maybe in the market? Is that years, decades?**

- The biggest risk to the development of klotho for a pharmaceutical agent, hand down is the uncertainty around the mechanism of action
  - It’s understandable that the FDA is not terribly excited about approving drugs for which the mechanism of action is unknown

***We really like to know how a drug works***

- When you give somebody a [PCSK9 inhibitor](https://en.wikipedia.org/wiki/PCSK9#As_a_drug_target), it binds to this epitope of the PCSK9 protein
  - And when it does that, the protein becomes degraded and it fails to disrupt the LDL receptor on the liver, which then clears more apoB out of circulation
- We can tell you in minute detail how many drugs work

***When you don’t know how a drug works, that creates another hurdle to approval***

*On the positive side*

- Klotho is a naturally produced protein in the body, and that gives it a huge boost in terms of the regulatory space
- It has no known toxicity
- And it’s really easy to make
- Now, there are lots of drugs out there for which we have no idea how they work
  - Nobody has the first clue how Tylenol works
  - We really don’t understand how metformin works if we’re being brutally honest
- Peter is involved with a company called Jocasta Neurosciences, and their goal is to get this into patients for phase I testing by 2025

***There’s a real scenario where by the end of this decade, klotho could be one of the treatments that are used to manage people with MCI or early dementia***

## George Brooks episode: a new paradigm to think about lactate and lactate metabolism [1:27:45]

[#312 – A masterclass in lactate: Its critical role as metabolic fuel, implications for diseases, and therapeutic potential from cancer to brain health and beyond](https://peterattiamd.com/georgebrooks/) | George A. Brooks, Ph.D. (August 5, 2024)

\*\*\*

- We talk a lot about lactate biochemistry
- George even corrects Peter at the outset of this podcast to say, “*Hey, we often talk about lactate and lactic acid synonymously. Let’s not do that.*”
- Lactate is the thing we want to focus on
- It is a byproduct of glucose metabolism
- It gets a bad name because people assume that anytime lactate is present, you’ve got lactic acid
  - The idea that lactic acid is bad because my muscles gets stiff and sore is overly simplistic
- Glucose metabolism is regulated in a very complicated way, and changes in ADP (which is one step removed from ATP) is really important in cell signaling
  - When the **ratio of ATP to ADP is low**, it tells you ATP is being consumed really quickly, and this signals to accelerate glycolysis and it produces more lactate
- You make all this lactate in cells and it leaves via [MCTs](https://en.wikipedia.org/wiki/Monocarboxylate_transporter)
  - These are transporters on the cell membrane, and it takes lactate out of the cell back into the circulation, where it goes to the liver
- In the liver, lactate is basically reorganized into glucose
  - Lactate and glucose are close cousins
  - You can take a couple molecules of lactate and make glucose via something called [gluconeogenesis](https://en.wikipedia.org/wiki/Gluconeogenesis)

**What Peter didn’t know until this discussion is that you also have MCTs on the mitochondrial membrane**

- Not only is the cell shuttling lactate into circulation to go back to the liver as fuel for other parts of the body (we’ll come back to this), but it can also shuttle lactate into the mitochondria to aid with the [electron transport chain](https://en.wikipedia.org/wiki/Oxidative_phosphorylation)

**From a signaling perspective**

- The other thing to know is that when lactate is abundant, it tells the cell that energy needs are high and the velocity of energy need is also high, and therefore it’s not a time to oxidize fat

***Therefore, high lactate levels also suppress fat oxidation***

- During exercise, about 80% of carbon flux comes from previously stored glycogen
- Muscles store most of our glucose, and the glucose that’s stored in muscles [as glycogen] cannot escape the muscle
- Therefore, during exercise, we are relying very heavily on muscle glycogen, in addition to fat, to fuel the muscle so that blood glucose is preserved for the brain

**What Peter learned**

1 – The importance of fat oxidation as a fuel in recovery

- That’s why it important to refeed with not just carbohydrates but fat as you’re recovering

2 – This idea that these transient elevations in lactate impair fat oxidation

- Peter never thought of that, but it makes sense
- When you’re doing really high intensity work, you’re not doing high fat oxidation work
- If you think back to what Peter talked about earlier around lactate testing in zone 2, why is it that this zone 2 lactate level of about 2 mmol (plasma level) ‒ why does that seem to correspond to maximum fat oxidation?
  - 2 mmol represents a flux of lactate, where lactate is being produced and cleared at a rate such that the steady state is about 2
  - It’s because that’s not so high a level of lactate that the cell is freaking out and saying, “*Hey, shut down fat oxidation. Focus everything on glycolytic activation.*”
- Once serum lactate levels are higher than 2 mmol, we know that you are not going to be able to sustain that level of activity indefinitely
- If your lactate level is 4 or 5 mmol, that tells us lactate is being produced at a rate that is sufficiently high enough that we’re not going to be able to clear that quickly
- At some point that lactate binds with a hydrogen
  - Not covalently, but through sort of anion and cation relationships
  - And you create something called **lactic acid**
    - That’s a hydrogen ion associated with lactate that effectively paralyzes the actin and myosin filaments in muscle contraction, and it makes it harder for those two to disaggregate
    - And that’s the stiffness and the burning that we feel with intense exercises
    - Again, it’s not lactate that’s doing this

3 – Lactate can cross the blood brain barrier and it reduces [ghrelin](https://en.wikipedia.org/wiki/Ghrelin) secretion in the hypothalamus

- This reduces appetite acutely

4 – Type II muscle fibers produce a lot of lactate and shuttle lactate to type I fibers

- Type I muscle fibers can more efficiently utilize lactate; they have many more mitochondria
- The difference in mitochondria is why type I fibers are whiter and type II fibers are more red, more glycolytic
  - [muscle fiber types were discussed extensively with Andy Galpin in [episode #250](https://peterattiamd.com/andygalpin2/)]
- You basically have this symbiosis between your type I and type II fibers where these fast-twitch fibers [type II fibers] that don’t have mitochondria or don’t have much mitochondria are generating a ton of lactate, but then they’re shipping it to the type I [slow-twitch fibers]

5 – All things equal, the upper body muscles tend to have more type II fibers

- They type II fibers are more glycolytic, quicker to fatigue, [fast-twitch muscle fibers]
- George gave a funny example, which is how quickly do your arms get sore when you’re changing a light bulb over your head?
- It’s because these glycolytic fibers have reduced [lactate] clearance and it’s harder to pump blood to your arms when they’re over your head

## The potential for lactate infusions to aid in brain recovery following a head injury [1:34:00]

**The most interesting thing in this podcast was the relationship of lactate in the brain**

> “*I really hope that people out there are listening to this and that there’s some entrepreneur who’s thinking about a way to use lactate infusions to study TBI.*”‒ Peter Attia

- George made an argument for why lactate is the preferred fuel of many tissues
- In particular, we focused on the brain, and especially when the brain is injured
- A [PET scan](https://en.wikipedia.org/wiki/Positron_emission_tomography) takes a molecule of glucose, it puts a radio label on it, it injects it into the body, and then you measure where that tracer went
- A PET scan is not an imaging study, meaning it doesn’t show you great anatomic detail of the person, but what it’s showing you is functional information
  - It’s showing you where the glucose is going
- If you took a person and did a PET scan of them, you would immediately notice that their brain lights up like a Christmas tree
  - Let’s say they don’t have cancer or something else that’s going to disproportionately take the glucose
  - Certain other organs do as well: the kidneys really tend to light up
- The reason for that is something we’ve talked about a lot, which is the brain is a very greedy organ when it comes to glucose
- If Nick goes into the PET scanner and gets an injection, his brain will light up like a light bulb
- Now if he comes out of the scanner and steps onto the football field, takes a hit to the head that causes a concussion, then goes back into the scanner
  - His brain doesn’t light up as much

**One of the fundamental issues is this profound hypometabolism in the brain after injury**

- We talked about this a lot with [Micky Collins](https://peterattiamd.com/mickycollins/) last year when we did a concussion discussion
- There is this profound hypometabolism in the brain, paradoxically at the time it needs the most energy
- There are reasons for that that we don’t have to get into

*The more interesting point here is what happens if you give that person lactate?*

- According to some research that George cited, the lactate is still going to go to the brain, and the brain will prefer lactate if it’s available
  - The Brain will even prefer lactate more when it’s injured to when it is not injured

***All of this leads to the question, should we be giving people lactate infusions following a TBI?***

- Apparently there are some people looking at that
- Peter didn’t come away from this episode thinking that there was enough effort and activity being done in that regard

## The relationship between lactate and cancer, and the impact of exercise on lactate levels and cancer risk [1:36:30]

**The role of lactate in metabolic health ‒ how did this conversation add to Peter’s opinion on lactate or did it influence any behavior change?**

**Lactate production in cancer**

- Lactate production is going to go up during cancer
- There’s something called the [Warburg effect](https://en.wikipedia.org/wiki/Warburg_effect_(oncology)) that we’ve talked about many times [episodes [#187](https://peterattiamd.com/samapple/) & [#201](https://peterattiamd.com/inigosanmillan2/)]

*At the surface you might think, if the Warburg effect produces more lactate, and one of the things that we talked about on this podcast was that lactate stimulates* [*EGFR*](https://en.wikipedia.org/wiki/Epidermal_growth_factor_receptor) *(which drives* [*RAS*](https://en.wikipedia.org/wiki/Ras_GTPase#Ras_in_cancer) *and* [*PI3-kinase*](https://en.wikipedia.org/wiki/Phosphoinositide_3-kinase)*), does that mean that lactate is driving cancer and therefore people with cancer shouldn’t be exercising?*

- This is another example of how sometimes a reductionist approach to things makes it easy to get misled
- It is true that exercise increases lactate production, but what it does disproportionately is increases lactate consumption and lactate flux

***What exercise is really doing is lowering basal lactate levels, and that’s probably the reason why exercise has positive effect on cancer patients and not a negative effect***

- Another way to think about this is if you take a fasting level of lactate on a very fit person versus a not fit person, it could be a 3 or 4X delta easily
  - In other words, a fit person might have a fasted resting lactate level of 0.3-0.5 mmol, whereas a person who is somewhat insulin resistant or unfit will easily be 3-4 times that

***It’s probably the basal level of lactate at elevation that may be playing a role in the propagation of cancer, not the transient spike you get while you’re exercising***

Peter explains, “*The moral of the story here is absolutely not to avoid exercise for fear of lactate induced cancer or anything like that. It’s we want to exercise so we can get that basal level lower and lower, just in the way that we think a very fit person has a lower resting heart rate, even though their heart rate gets higher during the day*.”

**Peter walked away from this episode even more interested in lactate than he was before**

- Measuring lactate is a pain, but Peter still pokes his finger all the time and checks his lactate, and he can’t wait for continuous lactate monitors to be out
- We can think of all the reasons why they may or may not be interesting

*What Peter really wants to see regarding lactate*

- 1 –  Someone go after lactate for cognitive health, especially in the trauma setting
- 2 – A continuous lactate monitor
- 3 – He wants to see lactate become a biomarker we pay more attention to in metabolic health
- The technology for a continuous lactate monitor is very straightforward; it’s just a market question
  - It’s no more difficult than measuring glucose or ketones or anything like that that we can measure easily

**There’s one other episode that is worth discussing**

- But we can probably kick it to the next one because we’ve taken a little more time than we expected

It was a short episode [[#310 with Ted Schaeffer](https://peterattiamd.com/tedschaeffer3/)] on the role of testosterone and TRT (or testosterone replacement therapy) in prostate cancer

§

## Selected Links / Related Material

**First podcast summary episode**: [#304 – NEW: Introducing podcast summaries – Peter shares his biggest takeaways on muscle protein synthesis, VO2 max, toe strength, gut health, and more](https://peterattiamd.com/qps1/) (June 3, 2024) | [0:30]

**Episode of** ***The Drive*** **with Julia Wattacheril**: [#302 – Confronting a metabolic epidemic: understanding liver health and how to prevent, diagnose, and manage MAFLD and liver disease](https://peterattiamd.com/juliawattacheril/) | Julia Wattacheril, M.D., M.P.H. (May 20, 2024) | [4:00]

**Episode of** ***The Drive*** **with Chris Sonneday**: [#155 – Chris Sonnenday, M.D.: The history, challenges, and gift of organ transplantation (March 29, 2021)](https://peterattiamd.com/chrissonnenday/) | [11:15]

**Episode of** ***The Drive*** **with Joel Jamieson**: [#305 ‒ Heart rate variability: how to measure, interpret, and utilize HRV for training and health optimization | Joel Jamieson](https://peterattiamd.com/joeljamieson/) (June 10, 2024) | [27:15]

**FibroScan for determining liver fat and fibrosis**: [FibroScan, the  non-invasive solution for liver disease](https://www.echosens.com/en-us/) | [21:00]

**Morpheus device for measuring HRV**: [Morpheus heart rate training system](https://trainwithmorpheus.com/) | [31:30]

**Episode of** ***The Drive*** **with Zak Kohane**: [#309 ‒ AI in medicine: its potential to revolutionize disease prediction, diagnosis, and outcomes, causes for concern in medicine and beyond, and more | Isaac Kohane, M.D., Ph.D.](https://peterattiamd.com/isaackohane/) (July 15, 2024) | [47:15]

**Google research paper on transformer**: [Attention is All You Need](https://arxiv.org/abs/1706.03762) | *arXiv* (A Vaswani et al 2017) | [51:30]

**The Wall Street Journal article on AI**: [The AI Revolution is Already Losing Steam](https://www.wsj.com/tech/ai/the-ai-revolution-is-already-losing-steam-a93478b1) | Christopher Mims, *The Wall Street Journal* (May 31, 2024) | [54:15]

**Discussion of Bannister and Keys papers on whether or not metformin is geroprotective**: [1:04:00]

- [A recent metformin study casts doubts on longevity indications](https://peterattiamd.com/a-recent-metformin-study-casts-doubts-on-longevity-indications/) | PeterAttiaMD.com (K Birkenbach, P Attia 2023)
- [#270 ‒ Journal club with Andrew Huberman: metformin as a geroprotective drug, the power of belief, and how to read scientific papers](https://peterattiamd.com/andrewhuberman2/) (September 11, 2023)

**Episode of** ***The Drive*** **with Dena Dubal**: [#303 – A breakthrough in Alzheimer’s disease: the promising potential of klotho for brain health, cognitive decline, and as a therapeutic tool for Alzheimer’s disease | Dena Dubal, M.D., Ph.D.](https://peterattiamd.com/denadubal/) (May 27, 2024) | [1:05:00]

**Meta-analysis:** ***KL-VS*** **heterozygosity reduces Alzheimer’s risk in** ***APOE4*** **carriers**: [Association of Klotho-VS Heterozygosity With Risk of Alzheimer Disease in Individuals Who Carry APOE4](https://pubmed.ncbi.nlm.nih.gov/32282020/) | *JAMA Neurology* (M Belloy et al 2020) | [1:16:00]

**Increased all-cause mortality in people with 30% less klotho**: [Plasma klotho and mortality risk in older community-dwelling adults](https://pubmed.ncbi.nlm.nih.gov/21474560/) | *The Journals of Gerontology* (R Semba et al 2011) | [1:17:00]

**Exercise increases klotho levels**: [A systematic review and meta-analysis demonstrating Klotho as an emerging exerkine](https://pubmed.ncbi.nlm.nih.gov/36266389/) | *Scientific Reports* (H Correa et al 2022) | [1:21:30]

**Rapamycin increases klotho expression in human proximal tubule kidney cells**: [Rapamycin-induced hypophosphatemia and insulin resistance are associated with mTORC2 activation and Klotho expression](https://pubmed.ncbi.nlm.nih.gov/21672148/) | *American Journal of Transplantation* (T Tataranni et al 2011) | [1:22:30]

**Rapamycin increases klotho expression in a rat model of chronic renal failure**: [Mammalian target of rapamycin signaling inhibition ameliorates vascular calcification via Klotho upregulation](https://pubmed.ncbi.nlm.nih.gov/26061549/) | *Kidney International* (Y Zhao et al 2015) | [1:22:45]

**Klotho increased in kidney transplant patients taking everolimus (mTOR inhibitor)**: [mTOR inhibition improves mitochondria function/biogenesis and delays cardiovascular aging in kidney transplant recipients with chronic graft dysfunction](https://pubmed.ncbi.nlm.nih.gov/33758105/) | *Aging* (B Infante et al 2021) | [1:22:45]

**Episode of** ***The Drive*** **with George Brooks**: [#312 – A masterclass in lactate: Its critical role as metabolic fuel, implications for diseases, and therapeutic potential from cancer to brain health and beyond | George A. Brooks, Ph.D.](https://peterattiamd.com/georgebrooks/) (August 5, 2024) | [1:27:45]

**Episode of** ***The Drive*** **with Micky Collins about concussions**: [#263 ‒ Concussions and head trauma: symptoms, treatment, and recovery | Micky Collins, Ph.D.](https://peterattiamd.com/mickycollins/) (July 24, 2023) | [1:35:30]

**Episodes of** ***The Drive*** **that discuss the Warburg effect**: [1:36:45]

- [#187 – Sam Apple: The Warburg Effect—Otto Warburg’s cancer metabolism theory](https://peterattiamd.com/samapple/) (December 13, 2021)
- [#201 – Deep dive back into Zone 2 | Iñigo San-Millán, Ph.D. (Pt. 2)](https://peterattiamd.com/inigosanmillan2/) (March 28, 2022)

**Episode of** ***The Drive*** **about the role of testosterone in prostate cancer**: [#310 – The relationship between testosterone and prostate cancer, testosterone replacement therapy, and tools for predicting cancer aggressiveness and guiding therapy | Ted Schaeffer, M.D., Ph.D.](https://peterattiamd.com/tedschaeffer3/) (July 22, 2024) | [1:39:45]

§