# #143 – John Ioannidis, M.D., D.Sc.: Why most biomedical research is flawed, and how to improve it

**Source:** [https://peterattiamd.com/johnioannidis/](https://peterattiamd.com/johnioannidis/)

---

John Ioannidis is a physician, scientist, writer, and a Stanford University professor who studies scientific research itself, a process known as meta-research. In this episode, John discusses his staggering finding that the majority of published research is actually incorrect. Using nutritional epidemiology as the poster child for irreproducible findings, John describes at length the factors that play into these false positive results and offers numerous insights into how science can course correct.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/johnioannidis/the_Drive_public.png)

Play

#143 - John Ioannidis, M.D., D.Sc.: Why most biomedical research is flawed, and how to improve it

#143 - John Ioannidis, M.D., D.Sc.: Why most biomedical research is flawed, and how to improve it

1x15s30s

0:001:52:01

## We discuss:

- John’s background, and the synergy of mathematics, science, and medicine (2:40);
- Why most published research findings are false (10:00);
- The bending of data to reach ‘statistical significance’, and the how bias impacts results (19:30);
- The problem of power: How over- and under-powered studies lead to false positives (26:00);
- Contrasting nutritional epidemiology with genetics research (31:00);
- How to improve nutritional epidemiology and get more answers on efficacy (38:45);
- How pre-existing beliefs impact science (52:30);
- The antidote to questionable research practices infected with bias and bad incentive structures (1:03:45);
- The different roles of public, private, and philanthropic sectors in funding high-risk research that asks the important questions (1:12:00);
- Case studies demonstrating the challenge of epidemiology and how even the best studies can have major flaws (1:21:30);
- Results of John’s study looking at the seroprevalence of SARS-CoV-2, and the resulting vitriol revealing the challenge of doing science in a hyper-politicized environment (1:31:00);
- John’s excitement about the future (1:47:45); and
- More.

§

## Show Notes

## John’s background, and the synergy of mathematics, science, and medicine [2:40]

**Overview**

- John considers himself a “scientist in the works”
- “*I’m trying to be a scientist. I think that this is not an easy job. It means that you need to reinvent yourself all the time. You need to search for new frontiers, for new questions, for new ways to correct errors and to correct your previous self, in some way*.”
- Background in mathematics and he bring mathematics to the study of science
- Born in New York City, but I grew up in Athens
- Both of his parents were physician scientists — he heard their stories of clinical exposure but also saw them working on their research

*How did you decide to also pursue something in the* ***biological sciences*** *in parallel, as opposed to staying purely in the natural or* ***philosophical sciences of mathematics****?*

- Medicine had the attraction of being a profession where you can save lives: “*The ability to make a difference for human beings and to save lives, to improve their quality of life, seem to be something that was worthwhile pursuing*.”
- But mathematics is critical: “*mathematics are the foundation of so many things and they can really transform our approach to questions that, without mathematics, it would be very difficult to make much progress*.”

**How mathematics, science, and medicine synergize**

- John sees mathematics and science and medicine as complementary of each other
- In fact to do something very meaningful, you need all three otherwise you risk “losing the whole”
  - **Medicine** is amazing in terms of its possibilities to help people
  - However, the [**scientific method**](https://en.wikipedia.org/wiki/Scientific_method) must be applied if you want to get reliable evidence (see Richard Feynman’s [famous explanation](https://www.youtube.com/watch?v=EYPapE-3FRw&t=292s) of the scientific method)
  - You also need quantitative approaches (i.e., **mathematics**)

> “I think that none of them is possible to dispense without really losing the whole, and losing the opportunity to do something that really matters eventually.” —John Ioannidis

**John’s studies**:

- John won the highest honor that a graduating college student could win in mathematics in Greece at the time
- John finished medical school in Athens at the National University of Athens
- He went to Harvard for residency training
- Then to Tufts Medical Center for training in infectious diseases
- At the same time, he was also doing joint training in healthcare research

**People that shaped John’s thinking**:

- Professor of Epidemiology at Harvard, [Dimitrios Trichopoulos](https://en.wikipedia.org/wiki/Dimitrios_Trichopoulos)
- In residency training, a great physician scientist in infectious diseases, [Bob Moellering](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4068561/), who was the physician-in-chief and a professor of medical research at Harvard— “an amazing personality in terms of his clinical acumen and his approach to patients”
- At the end of residency training (1992), John had a “revelation” after meeting [Tom Chalmers](https://en.wikipedia.org/wiki/Thomas_C._Chalmers) and [Joseph Lau](https://vivo.brown.edu/display/jl122) at Tufts who were the ones advancing the frontiers of [evidence-based medicine](https://en.wikipedia.org/wiki/Evidence-based_medicine)

> “It was a revelation for me because somehow what they were proposing was mixing mathematics’ rigorous methods, evidence, and medicine in one coherent whole. . . [until that point] I was just seeing lots of clinical exposures where there was very little evidence to guide us. There was no data, or very poor data, and a lot of expert based opinion guiding everything that was being done.” —John Ioannidis

## Why most published research findings are false [10:00]

John came onto Peter’s radar around 2005 when John published this paper: [Why Most Published Research Findings Are False](https://journals.plos.org/plosmedicine/article?id=10.1371/journal.pmed.0020124)

- The paper suggested that more than half of scientific papers claiming to have found a statistically significant signal were actually just a “false positive”
- Peter was blown away by this paper, but he was “primed” to believe it because his mentor in post-doc training had once told him that ~70% of published papers were never cited again (outside of auto citation) suggesting that most papers are either irrelevant or wrong

**John describing his** [**2005 paper**](https://journals.plos.org/plosmedicine/article?id=10.1371/journal.pmed.0020124)

- The paper used a mathematical model to match empirical data that had accumulated over time to understand the validity of different pieces of research that was being produced
- The impetus for this paper was that many scientists had been disillusioned that when a evidence-based medicine started that we now had a tool to be able to get very reliable evidence for decision making
- But they quickly realized that the vast majority of the results were unreliable and could not be replicated— “It was the rule that we had either unreliable evidence or, perhaps even more commonly, no evidence.”
- The mathematical construct would try to: i)  explain what is going on, and ii) predict what might happen if some of the circumstances would change in terms of how we do research
- The first question being explored is the chances of a statistically significant result is indeed a “non-null” effect (or is it just a “[red herring](https://en.wikipedia.org/wiki/Red_herring)”?)

*In order to calculate this, you need to take into account*:

*1—****The field of research***:

- Some fields probably have a higher chance of making discoveries compared to others
- Some may be unlucky to be in a field where there’s almost nothing to be discovered
- Other fields that may be rich in discovery, both the field and the tools, the methods, and the designs of the studies that we throw at trying to answer these questions can be informative

*2—****Power***

- Is the study large enough to be able to detect non-null effects of some size of interest?
- Maybe there are true effects out there, but our studies are very small and therefore they’re not able to detect these effects
- In my experience, there are lots of very small studies floating around with results that were very questionable that could not be matched with larger studies
- Power is important not only because **if you don’t have enough power, you cannot detect things that exist** but what probably worse, is that **if you operate in an environment of low power, when you do get something detected, it is likely to be false**.

*3—****Bias***

- Bias in another big factor that is compounding the situation
- Bias means that you could have conscious, unconscious, or subconscious reasons why a result that should have been null somehow is transformed into a significant signal
- Bias could take many forms (publication bias, selective reporting bias, information bias, and more)

*4—The* ***universe of the scientific workforce***

- You have to take into account the universe of the scientific workforce
- It’s not just a single scientist or a single team — currently, about 35 million people who have co authored at least one scientific paper
- Many scientists are trying to attack the same scientific question, and each one of them is contributing to that evidence
- However, there’s an interplay of all these biases with all of these scientists
- Some you must take into account the multi-scientist environment, multi-effort environment
- For example, say what are the chances that at least one of the scientists will find some significant signal? — This is a very different situation compared to just having one person just taking a single shot

**Results of the paper**

- The model in the paper attempted to put all these factors together and then try to see what you get under realistic circumstances
- Again, these factors would vary from one field to another (e.g., if we’re talking about exploratory research with observational data versus small randomized trials, or massive testing versus highly focused testing)
- The model shows that, in most circumstances, if you get a nominally statistically significant signal with a traditional p-value of slightly less than 0.05, you are seeing a red herring
- In other words, the chances that your significantly significant finding is actually not true (i.e., a false positive) is greater than 50%

> “In most circumstances, the chances that you got it wrong are pretty high.” —John Ioannidis

## The bending of data to reach ‘statistical significance’, and the how bias impacts results [19:30]

**Explaining p- value, and statistical significance vs. clinical significance**

What we care in medicine is **clinical** significance, i.e.:

- Would this thing make a difference to my patient?
- Does it make a difference?
- Does it matter?
- Is it big enough that is worth the cost, the potential harms, the implementation effort, etc.?
- And how does that compare to these alternatives? Are they better or cheaper, easier to implement, or have fewer harms?

**The unfortunate reality**

- Unfortunately, most of the time we’re stuck with trying to answer very plain, [frequentist](https://stats.stackexchange.com/questions/22/bayesian-and-frequentist-reasoning-in-plain-english#:~:text=A%20Frequentist%20is%20someone%20that,talk%20about%20long%20run%20frequencies.) approach question, which boils down to [statistical significance](https://en.wikipedia.org/wiki/Statistical_significance)
- For most scientific fields, we generally look to a p-value threshold of 0.05 to establish statistical significance
- John and others have advocated for a more stringent threshold for certain fields (e.g., a threshold of 0.005 instead of 0.05)
- The problem, however, is that most scientists are trained to finagle their results to reach significance — to basically use some statistical test that gives you some statistic that eventually translates to a p-value you need
- What that p-value really needs to be interpreted as is “what are the chances that if I had an infinite number of studies like this one, I would get a result that would be as extreme or more extreme”
- But even that interpretation of the meaning of p-value is not a complete definition because **it does not take into account bias**
- With some of the large databases of data, we can easily get to astronomically small p-values
- But, it could just mean that you have bias, and this is why you get all these astronomically low p-values

*Should we stop using “statistical significance” in science?*

- Many people advocate for diminishing the emphasis on statistical significance
- Many great methodologists have even suggested that we completely abandon the term statistical significance and just focus on effect sizes, focus on how much uncertainty we have about effect sizes, focus on perhaps basing interpretation of research
- John is reluctant about adopting the “ban statistical significance” approach
- Why? Millions of scientists are not only improperly trained to understand statistical significance, but they’re completely not trained at all to understand anything else that would replace it

**John’s approach**

- John argues that we should rather emphasize the “rules of the game” —
  - “*if you pre-specify, and if you are very careful in registering your hypothesis, and you have a protocol, and you have worked through this to where it makes sense that your hypothesis is clinically important, that the effect size that you’re trying to pick is clinically meaningful, it is clinically significant, then I would argue that statistical significance and using a p-value threshold, whatever that is, depending on how you design the study, makes perfect sense*.”
  - “*But if you remove these ‘rules of the game’ after the fact in these situations, it may make things worse because you will have a situation where people will just get some results and then they will be completely open to interpret them as they wish*.”
- For other types of research, I’m willing to promote better ways of interpreting results
- We need to find ways that will
  - minimize the harm
  - minimize the error and maximize,
  - And in medicine, bring forward only the clinically significant pieces

> “Most scientists are not really well-trained in statistics, and they will misuse and misinterpret and misapply statistics, unfortunately.” —John Ioannidis

## The problem of power: How over- and under-powered studies lead to false positives [26:00]

The other side of that statistical field is **power** which can lead to both **false negatives** AND **false positives**

*False negatives*:

- If you underpower a study, e.g., too few samples, too few subjects, and you fail to reach statistical significance…
- It’s not clear that you failed to reach statistical significance because you should be rejecting the null hypothesis, or because you didn’t have a large enough sample size
- In other words, the fear is that you get a **false negative**

*False positives*:

- In an underpowered environment, you run the risk of having higher rates of false positives if you take the performance of the field at large
- Even if you manage to detect the real signals that that do exist, if these signals are detected in an underpowered environment their estimates will be **exaggerated** compared to what the true magnitude is
- It’s not important so much to find whether there’s some signal at all, which is what a null hypothesis is trying to work around, but rather to understand: *how big is the signal?*
- If a treatment has a minuscule benefit, we wouldn’t use it because the cost and the harms and everything on the other side of the balance is not making it worth it

**Why most fields are operating in underpowered environments**

⇒ See John’s paper: [Power failure: why small sample size undermines the reliability of neuroscience](https://www.nature.com/articles/nrn3475)

- First of all, we have a very large number of scientists
- And there are very limited resources
- And scientists are competitive
- To continue to advance their career and continue to be funded, scientists feel the need to prove that they can get significant results
- So they are stuck in a situation where they need to promote seemingly statistically significant results even if they are not.
- Because of the limited resources,
- i) they are forced to to do very small/underpowered studies
- ii) And then they must do even more small studies (rather than aim to do a more definitive, large study)
- There’s even a disincentive towards refuting results that are not correct, because that means that you feel that you’re back to square zero.
- All this leads to very high rates of results that are either completely false positives, or they may be pointing to some real signal but the estimate of the magnitude of the signal is **grossly exaggerated**

**Overpowered studies**

- Recently, we have started seeing the opposite phenomenon—**overpowered studies**
- Big data are creating this and it’s likely that the growth of this type of problem will be faster compared to the growth of the problem of small underpowered studies
- You can get statistically significant results that have **no clinical meaning** (or any meaning really)
- In many cases, these “significant” signals can be brought about with just a tiny little bit of bias

> “So you’re just measuring bias. You’re just getting a big scale assessment of the distribution of bias in your datasets.” —John Ioannidis

## Contrasting nutritional epidemiology with genetics research [31:00]

**Genetics research**

- Genetics was something that John was very interested in from my early years—it was a new frontier for quantitative approaches
- There was a new opportunity with genetics to give some new insights with much larger scale evidence in genetics compared especially after the [genome was decoded](https://en.wikipedia.org/wiki/Human_Genome_Project)
- However, early on John realized through genetics that the approach that we had been following in most traditional epidemiology, like looking at one risk factor at the time and trying to see whether it is associated with some disease outcome was not getting very far
- Most of the genetics papers were just getting “false positives” —many papers were looking at one or a few genes at the time with association with some outcome in an attempt to cross the threshold of statistical significance and then claiming success

⇒ **John’s paper regarding the GWAS studies**: [Replication validity of genetic association studies](https://www.nature.com/articles/ng749z)

*Genetics researchers took some steps to remedy this*

- They decided to do **very large studies**
- To look at the entire genome and look at all the factors rather than one at a time
- The research community joined forces, as opposed to having each scientist try to publish their results alone
- They decided to
  - share everything
  - Have a common protocol
  - And put all the data together to maximize power, to maximize standardization, to maximize transparency
  - report the cumulative results

> “*This is a recipe that I think should be followed by many other fields, especially fields that work with observational data in epidemiology*.” —John Ioannidis

**Nutritional epidemiology** *– the “antithesis” of genetics research*

- Peter calls [nutritional epidemiology](https://en.wikipedia.org/wiki/Nutritional_epidemiology) the antithesis of genetics research, and it continues to propagate subpar information

*Why haven’t they been able to adopt better standards?*

1-Genetics has better tools

- Genetics developed platforms that could measure the entire variability more or less in the human genome with pretty high accuracy
- Nutrition on the other hand is where the traditional tools have been questionnaires or survey tools that have very high biases, very high recall bias, very low accuracy.
- They also do not really capture the diversity of nutritional factors with equal granularity as we can capture the genetics in their totality of the human genome.

2-Nutritional beliefs are like a religion

- In genetics, there were no strong priors, no strong beliefs, no strong opinions, no strong experts who would fight with their lives for one gene variant versus another.
- In nutrition, you have a very strong expert opinion base of people who have created careers around their beliefs — e.g., “*THIS type of diet is saving lives and should have policy implications. It should change the world*.”
- Many of these nutrition beliefs are interspersed with religious, cultural, or non-scientific beliefs in shaping what we think is good diet
- You can be more neutral with genetics research because of this objectivity

3-Methodologically in genetics advanced faster

- Nutrition has been stuck mostly in the era of using p-values of 0.05 thresholds in mostly post-hoc research that is selectively presented

4-Nutritional scientists are typically trained in a way that they need to play with the data to try to unearth interesting associations

- In some cases, like the [Cornell case](https://www.sciencemag.org/news/2018/09/cornell-nutrition-scientist-resigns-after-retractions-and-research-misconduct-finding), it becomes fraudulent
- Nutrition has some standards and methods that are pretty suboptimal compared to what genetics has adopted

**Research protocols being used in the field of genetics**

1. Genetics is not going to claim success with a p-value of 0.05 but rather a p-value closer to 10 to the -8 (e.g., 0.000000005)
2. Created large coalitions of researchers who would all share their data
3. Standardize the analysis, i.e., perform analysis in a very specific way
4. Have two or three analyst teams analyze the same data and make sure that they get the same results

> “So there’s multiple scientific and behavioral and cultural and statistical and methodological reasons why these fields have not progressed at the same pace of revolutionizing their research practices.” —John Ioannidis

## How to improve nutritional epidemiology and get more answers on efficacy [38:45]

**Austin Bradford Hill and his famous “criteria”**

- [Austin Bradford Hill](https://en.wikipedia.org/wiki/Austin_Bradford_Hill) was one of the fathers of epidemiology
- John says he was “spot on” in coming up with good questions and asking the important questions
- He came up with what’s known as the [Bradford Hill criteria](https://en.wikipedia.org/wiki/Bradford_Hill_criteria) —but even Hill would cation that none of the items in his criteria are really bulletproof
- Indeed, in science there’s hardly anything that is bulletproof
- John takes a similar cautious approach with his own work: “*I think that we have not been very cautious in moving forward with many of our observational associations and the claims that we have made about them*”
- John also points out that we DO have some very solid evidence for many observational associations — e.g., There’s not the slightest doubt that tobacco is killing people

**The Bradford Hill Criteria** ([source](https://en.wikipedia.org/wiki/Bradford_Hill_criteria))

1. Strength (effect size)
2. Consistency (reproducibility)
3. Specificity
4. Temporality
5. Biological gradient (dose-response relationship)
6. Plausibility
7. Coherence
8. Experiment
9. Analogy
10. Reversibility

*⇒ Example, the association between tobacco and lung cancer*

- This link is the ultimate in terms of strength and consistency
- John says, “We do not see odd ratios of 10, 20 and 30 (as we see with tobacco) with many types of cancer and with other outcomes like cardiovascular disease.”
- With cigarette smoking, see signals that are **highly replicable** and that’s the *exception*
- In fact, in epidemiology if John sees an odd ratio of 20 he’s almost certain that something is wrong with the calculation
- In genetics, for example, they are dealing with odds ratios of 1.01 all the time
- And an odds ratio of 1.01 may still be real, but it’s unlikely to be clinically relevant
- The tobacco studies in the 50s and 60s by contrasts, were all moving in the same direction resulting in an average of about 14x

*What about the other criteria?*

- If you have such strength and such consistency (like with smoking), John says he would probably not worry that much about the rest of the criteria
- Criteria likes specificity, or analogy, are far more soft in terms of what they would convey
- We also just “don’t know the nature of nature in how it operates” — Many phenomena may be very specific, but it doesn’t have to be so.
- We should not take it for granted that we should see perfect specificity or low specificity.
- We see many situations where you have multidimensional situations of causality, you have multiple factors affecting some outcome, or you have one factor affecting multiple outcomes
- The density of the webs of causality can be highly unpredictable

![](https://peterattiamd.com/wp-content/uploads/2021/01/table-I-ioannidis-1024x522.png)

**Figure 1. “*****To summarize, we have the following. Strength: I think that large effects are almost always due to error and bias. When I come across a large effect, I ask my fellows to go back, and we practically always find an error. Causal effects are far more likely to be small and probably far more likely to be tiny. This is not bad necessarily; some of these effects may still be clinically relevant and public-health relevant, but most are probably tiny. Consistency: Consistency in replication is something that I love. I think it is indeed important, but there is still the possibility of false non-replication or perpetuated fallacies sometimes, and we have to sort out how commonly that happens. Specificity: I think causal effects are probably rarely specific. Good or bad, that is what I see mostly. Temporality: It makes sense, of course, but it is very difficult to document and model. Biological gradient: It is unclear really what this means and why nature should behave in linear or stepwise terms or otherwise. Plausibility: In most cases, evocation of plausibility has been misleading. There may exist some fields where it has been helpful, but I think they are the minority. Coherence: It is largely unclear even what it means nowadays. Experiment: It is the strongest of all criteria – most epidemiology to date, based on experimental evidence, has been misleading unfortunately. Analogy: In most cases, evocation of analogy has led to creation of bubbles of low yield, self-perpetuating disciplines. Table 1 shows an overall summary on the nine criteria and whether they work.***

***To conclude, I am grateful that Bradford Hill led us with his thinking and put us into the mode of trying to find out what is going on with establishing causality. He has been extremely influential in shaping our approach to epidemiology over half a century. Empirical evidence has accumulated from millions of studies that can allow an evolving re-appraisal of their performance. As Bradford Hill wisely suspected, none of the criteria have absolute value on its own. In the current research environment, several of the criteria have very little predictive ability for causality. Some even decrease (at least to my mind) the probability of causality. I think that we need more empirical meta-research studies [39,40] to continue to monitor evidence on these pivotal issues, because things may change in the future.*****”** [[Ioannidis, 2015](https://onlinelibrary.wiley.com/doi/abs/10.1002/sim.6825)]

**What to do when you don’t have strength and consistency?**

- In most cases, we’ll get an odds ratio of 1.14 (a 14% relative increase)
- And those are situations where strength and consistency are not there, which is *essentially true of everything in nutritional epidemiology* (the exception being a major deficiency like [thiamine deficiency](https://en.wikipedia.org/wiki/Thiamine_deficiency))

*So what do we do when you don’t have strength and consistency?*

- Prioritize experimental evidence — “*The top priority is whether you can get experimental evidence*.”
- In some circumstances, when you know that you’re dealing with highly likely harmful factors, you cannot really have equipoise to do randomized trials
- But for most situations in nutrition, you can do randomized trials
  - And it’s not like we’re not doing randomized trials in nutrition (many thousands have been done)
  - It’s that most of them are small and underpowered and are selectively reported with no pre-registration and with kind of haphazardly done analysis and reporting
- We do actually have 200+ very large randomized trials in nutrition
- Most of those focused on specific nutrients or supplementations, and some are looking at diets like [Mediterranean diet](https://en.wikipedia.org/wiki/Mediterranean_diet)
- But with very few exceptions, they do not really show the benefits that were suspected or were proposed in the observational data
- That suggests that most of the observational signals are **false positives** or **substantially exaggerated**
- *“I think that this means that we need to do* ***more*** *trials.*” says John

**The argument** ***against*** **doing MORE large trials**: Large randomized trials, especially with long-term followup, means people will often not adhere to what you tell them to do with their diet or nutrient intake or supplementation

- **John’s response to that argument**: My response to this is that when it comes to getting evidence about what people should eat, that lack of adherence is part of the game, it’s part of real life, so if a specific diet is in theory better than another, but people cannot adhere to that, it’s not really better because people cannot use it.”
- **Peter’s counter to John’s point**:
  - In a world of so much ambiguity and misinformation, I do think it’s important to separate [efficacy](https://en.wikipedia.org/wiki/Efficacy) from effectiveness

- He gets what John is saying, in the real world, only effectiveness matters
- “But I still think there is a time and a place for efficacy. . .We do have to know what is the optimal treatment under perfect circumstances if we want to have any chance at, for example, informing policy.”
- Take the example of food stamps:
  - Should food stamps, preferentially target the use of certain foods over others?
  - If you had really efficacious data saying this type of food is worse than that type of food, you could steer people towards healthier foods.
  - It could impact the way we subsidize certain foods.
  - In other words, it’s really all about changing the food environment
- Peter concludes with: “*It is very hard to follow any diet that is not the standard American diet. And I think a big part of that is because there is still so much ambiguity around what the optimal nutritional strategies are.* ***We haven’t answered the efficacy question because I think we keep trying to answer the effectiveness question***.”

⇒ See John’s paper: [Implausible results in human nutrition research](https://www.bmj.com/content/347/bmj.f6698)

**How to get more answers on efficacy:**

- John says he would not abandon efforts to get some insights on [efficacy](https://en.wikipedia.org/wiki/Efficacy)

*There are options to get better efficacy data*:

- 1–The experimental approach
  - So you can still randomized trials, but you can do them under very controlled, supervised circumstances that people are in a physiology or metabolism clinic
- 2–[Mendelian randomization studies](https://en.wikipedia.org/wiki/Mendelian_randomization) which is “between the observational and the randomized world”
  - With the admin of genetics, we have lots of genetic instruments that may be used to create designs that are fairly equivalent to a randomized design
  - They go a step forward in terms of the credibility of the signals that you get
- 3–A type of observational evidence using [environment-wide association](https://en.wikipedia.org/wiki/Environment-wide_association_study)
  - We need to interrupt observational data very cautiously and we use some of the “machinery” that we have learned to deploy in other fields
  - For example, environment-wide or [exposure-wide association testing](https://onlinelibrary.wiley.com/doi/abs/10.1002/sim.6825)
    - You run an analysis of all the nutrients that you have collected information on, and you can also do it for all the outcomes that you have collected information on.
    - Then you report the results taking into account the multiplicity, and also the correlation structure between all these different exposures and outcomes
    - You get a far more transparent and complete picture
    - If you get signals that seem to be recurrent and replicable across multiple datasets, multiple cohorts that you run these analysis you start having higher chances of these signals to be reflecting some reality

> “It’s not going to be perfect, but it is better compared to what we do now where we just go after finding yet one more association, one at a time, and coming up with yet another paper that is likely to be very low in credibility.” —John Ioannidis

## How pre-existing beliefs impact science [52:30]

\*\*\*

**A few of John’s popular papers**:

- [2005 paper](https://journals.plos.org/plosmedicine/article?id=10.1371/journal.pmed.0020124): Why Most Published Research Findings Are False – has close to 10,000 citations.
- [John’s most cited paper](https://www.bmj.com/content/339/bmj.b2700): The PRISMA statement for reporting systematic reviews and meta-analyses of studies that evaluate healthcare interventions: explanation and elaboration
- Per Peter, John’s [most entertaining paper](https://academic.oup.com/ajcn/article/97/1/127/4576988) is from 2012: Is everything we eat associated with cancer? A systematic cookbook review

\*\*\*

**Details of the** [**systematic cookbook review**](https://academic.oup.com/ajcn/article/97/1/127/4576988):

- John’s paper randomly selected 50 ingredients from the cookbook trying to map how many of those have had published studies in the scientific literature in terms of their association with cancer risk.
- And not surprisingly, almost all of them had published studies associating them with cancer risk

![](https://peterattiamd.com/wp-content/uploads/2021/01/cancer-link-to-ingredients-ioannidis-744x1024.png)

**Figure 2. Effect estimates reported in the literature by malignancy type (top) or ingredient (bottom). Only ingredients with $10 studies are shown.** [[Schoenfeld and Ioannidis, 2012](https://watermark.silverchair.com/127.pdf?token=AQECAHi208BE49Ooan9kkhW_Ercy7Dm3ZL_9Cf3qfKAc485ysgAAAp8wggKbBgkqhkiG9w0BBwagggKMMIICiAIBADCCAoEGCSqGSIb3DQEHATAeBglghkgBZQMEAS4wEQQMy5wPRibRE9Di7U_KAgEQgIICUvcoE9BR34DMW3cDrZop83rs8MiUJID3c_W74QVXqKPPKwV95KoKfcsf6_fjwmPm4KdBIyGuGBegCuJyz-AzJCr_k_j4ilU3rSAH2DJvS25IekgKXbdHx40koEqyTdt-G8fL7t7vyRrN-OM1Z8sKNmUspcfSZJ3NpnpqHME6ARS-rixKT-rWo0HGLqmkucuHqnxSdTBbYmFmI8TJAurjNd_nt-2rIYS80uyknsy62ZNB9brCXX2KM9uvS5zWs7sVe8nTYqndQgisgeCzWB6bF-Gxh4UJ98UbXEJOWUQGujFfLqsWbcC-848zh19yJvSZLxSsCzRNJs6tjOF10LY3O0fVSHJICU-pRWS7T1DqrrN27MNHzUWDrx_U3Lh4vLb-EHXEfZZuEFdrEcyQT4TIP2kiun8an-8-M_qx3RFXYw9XZAWRwFGiYaRrgBzsJwilpW171RfQfWM8U3ad-RDsCTu6QCDYazEIlOZmZ3gnPq0ZQSZuNsLHGJsQ9uOQrNKNpPoYm2yi_fz7-oNULmxR2lMPAg0rFrhJD4Z1cIF-XAGtW4TMO5st7Yei4UTez4KPNbFPIOdP87Mfu88F5P_D9VaL8pICINmHsWvUdEm8Cy-rMvla2O2lnlIZozeM-gvmft-mSMl_yKnQRcwVowchuJPMVj-7eDdCu88mbJTtoMbSGbbPL8FK0CqbrgoR57TGDs0YoWjFMTHT7GmYde8bUECOeB2XRNrmWZY_pgcozV6MVbpzkqmosV2OLCJ4PNUwbZpwjYsKFUR-oNci7-2EM-12og)]

*How was this paper received by the nutritional epidemiology community?*

- It created lots of enemies and lots of friends
- But the good news is that most people realize that we have a problem
- And even people who disagree with John are generally well intentioned
- That said, it should be feasible to reach some synthesis of these different approaches in these different trends

Improving standards but with more work to do…

- John says that even people who have used traditional methods are beginning to use some of the methods that he has proposed such as the exposure-wide approaches or trying to come up with large consortia and a meta-analyses of multiple cohorts to strengthen the results and the standardization of the results
- However, John still has concerns around the transparency of these efforts
- Ideally, if you can have large scale meta-analyses of multiple teams, you have all the teams joining forces and publishing a common analysis with **common standards**
- *But here’s what goes wrong*: The invitation goes to other investigators who have already found results that square with the beliefs of the inviting investigator
- Then these data are cleaned, combined and analyzed in the way that has found the significant association already
- And you have a conclusion with an astronomically low p-value which says, “*We have concluded that our claim for a significant association is indeed true. And here’s a large meta-analyses*.”
- This is equally misleading, or even more misleading, than the single studies because you have cherry-picked studies based on what you already know to be the case

> “Magnitude and amount of evidence alone does not make things better. Actually, it can make things worse. You need to ask, ‘What is the foundational construct of how that evidence has been generated and identified and synthesized?’” —John Ioannidis

**Problems with with pre-existing beliefs**

- Even institutions like Harvard can have very strong points of view on nutritional epidemiology which inhibit their ability to do objective research
- “This is unavoidable”, says John
- There are schools of thought in any scientific field, and Harvard has an amazing team of nutritional epidemiologists
- But we should look beyond the personal differences or opinion differences, says John
- “*I’m arguing is for better data, for better evidence, for better synthesis, and more unbiased steps in generating the evidence, synthesizing the evidence, and interpreting it*.”
- John emphasises that he’s not committed to any particular result: “*I would be extremely happy if we do these steps and we come up with a conclusion that 99% of the nutritional associations that were proposed were actually correct*.”

**The challenge of overcoming prior beliefs**

- When an individual has made an entire career of a set of beliefs, it requires a very special person to be able to say that may have been incorrect
- As an example, Peter brings up a documentary he just watched about the [D.B. Cooper case](https://en.wikipedia.org/wiki/D._B._Cooper)
  - It’s the only unsolved act of U.S. aviation crime
  - This guy hijacks an airplane with a bomb and requests the plane be landed while they pick up $200,000 and four parachutes. He then gets the plane to take back off, and jumps out the back with the money. He’s never been found.
  - In the documentary, they interviewed a bunch of people all of whom were convinced that someone they knew (the uncle, grandfather, etc.) was in fact D.B. Cooper
  - Peter says this a great example of human nature… which is that every one of those people truly believes that it was their relative or friend or whomever who was D.B. Cooper, and yet all of them are most certainly wrong
- That part of human nature is actually a big problem when it comes to science: “*I don’t think science should be able to be that way. That’s the problem I think I have with epidemiology, is that I guess I’m just not convinced it’s a science in the way that we talk about science*.”

John’s take:

- “We have to be cautious, because we are human and scientists have beliefs. I think that there’s nothing wrong with having beliefs.”
- “I think the issue is, can we map these beliefs? Can we be transparent? Can we be as much restrained about how these beliefs are influencing the contact of our research and the way that we interpret our findings?”
- Aiming to be perfect is not tenable, John says,
- But at a minimum, we should try to impose as many safeguards in the process so as to **minimize the chances that we will fool ourselves**
- This is not easy in fields that have a very deeply entrenched belief system, and nutrition is one such field
- That’s not to say that we don’t have some people with bad intentions and a very high penetrance of financial conflicts– e.g., big food and industry who want to promote their products and sell whatever they produce
- “*But I think that non-financial conflicts can also be important, and at a minimum, we should try to be transparent about them*.”

## The antidote to questionable research practices infected with bias and bad incentive structures [1:03:45]

**The case of** [**Brian Wansink**](https://en.wikipedia.org/wiki/Brian_Wansink) **at Cornell**

- This professor practically urged his students to cut corners and to torture the data until they would get some nice looking result
- He was then packaging nice looking results as soon as they would become available based on that data torturing process
- In turn, he was generating dozens of papers that were creating a lot of interest, and probably they were very influential, many of them in terms of decision-making
- “But if you create results and significance in that fashion, the chances that these would be reproducible results is very, very limited.” says John

Makes you wonder, ‘*How often is this happening by someone who is much less prominent*?’

- 35 million people are authors on easily 5 million papers every year
- And very few of those papers are both valid and useful
- Research practices are substandard in most scientific fields for most of the research being done
- Fortunately, John believes that deliberate fraud is uncommon: “I *don’t think that it is a major threat in terms of the frequency. It is a threat in terms of the visibility that it gets and the damage that it does to the reputation of science as an enterprise, but it’s not common*.”
- But, what is **extremely common** is questionable research practices which means cutting corners in different ways
- In fact, the percentage of people who might be cutting corners at some point is extremely high
- It may be approaching even 100% if you define it very broadly and if you include situations where people are not really cognizant about the damage that they do, or the suboptimal character of the approach that they’re taking and how it subverts the results and or the conclusions of the study

*Now, how do you deal with that?*

- You need to work through training
- through sensitizing the community,
- having a grassroots movement about realizing what the problems are,
- how you can avoid these traps,
- how you can use better methods,
- how you can use better inference tools,
- how you can enhance the credibility of your field at large

*Perfection is not possible*

- No scientific field is perfect
- It’s an evolution process, it is a continuous struggle, and every day you can do things better, or you can do things worse

*Of those 35 million authors, how many are “principal investigators” dictating what gets researched and how it’s done and interpreted?*

- At a global level, if you take all sciences into account, probably they’re less than one million
- And of those one million or so, it’s very hard to know their level of training, how familiar they are with best methods, and their prior beliefs and biases
- Based on this, some argue that we need less research and to be more demanding in asking for credentials and for training and for methodological rigor
- But John thinks less research is a bad idea because you’re just creating more limited resources further incentivizing scientists to publish “significant results” —you would end up with:
  - more incentive to cut corners
  - to come up with striking, splashing results
  - then you have an even more unreliable literature

> “I think that research and science is the best thing that has happened to humans.” —John Ioannidis

*What is the solution?*

- Improved standards,
- improved circumstances of doing research,
- and improved environment of doing research is probably what we should struggle for
- Creating the background where someone who’s really a great scientist and knows what he or she is doing will get support and will be allowed to thrive.
- Also, people should be allowed to look at things that have a higher risk of failing
- If we continue incentivizing people to get significant results, we are incentivizing people to do the wrong thing
- We should incentivize them to try really interesting ideas and to have a high chance of failing
- “*I think if you don’t fail, you’re not going to succeed.*”

## The different roles of public, private, and philanthropic sectors in funding high-risk research that asks the important questions [1:12:00]

**The enormous gap for risk**

*Private (i.e., big industry)*

- Big industry has a very clear risk appetite that is going to be **driven by a financial return**
- What doesn’t happen here in taking risks for the sake of discovery

*Publics (i.e., Government)*

- Government in the pure public sector may seem like the one to be funding risk
- However, given the legislative process by which that money is given out, and the lack of scientific training that is in the people who are ultimately decision-makers for that money, it also seems like a suboptimal place to generate risk

*Philanthropy*

- Peter says this leaves an enormous gap for risk, which almost has to be filled with philanthropic work
- John agrees to some degree: “No strings attached philanthropy can really be catalytic in generating science that would be very difficult to fund otherwise.”

**John’s take on where and how we can fund risk**

- Philanthropy is very important
- But public funding is also essential, and we can make a convincing case that public funding should increase, not decrease
- We really need to realign some of our priorities on what is being funded with each one of these mechanisms (private, public, philanthropy)

*Reversing the roles of industry and public funding*

- Much of public funding is given to generate translational products that are then exploited immediately by companies who make money out of them
- The **testing** of these products is paid by the industry which creates a tremendous conflict — The industry is financing and controlling the studies judging whether these products that they’re making money off of are going to be promoted, used, become blockbusters, etc.
- Instead, the **industry** should really pay more for the *translational research* for developing products through the early phases, and then **public funding** should go to *testing* whether these products have benefits, have low risk of harm, etc.

*Philanthropy’s role*: The major role of philanthropy should be allowing people to pursue high risk ideas with a strong likelihood of failure

*Busting the narrative about what taxpayers should fund*:

- Public funds should also go to high risk ideas which is counter to the traditional narrative that money from taxpayers are used only for paying research grants that produces important deliverables
- John posits that this is a false narrative because most grants, *if they really look at interesting questions*, they will deliver nothing
- “*Finding nothing should be a very valid conclusion*.”
- In the end, out of 1,000 grants, maybe we get 5 that find something, and that’s what makes the difference.

> “It’s not that each one of them made a huge contribution. It is these five out of a thousand in some fields, and in other fields obviously maybe a higher yield, that eventually transform the world.” —John Ioannidis

**How do we change the narrative that publicly funded research can’t take on high risk research? [1:16:45]**

- The problem right now is we have a communications problem
- If you look at other high risk public projects that were successful, they were backed by the public
  - E.g., The [Manhattan Project](https://en.wikipedia.org/wiki/Manhattan_Project) and the [Space Race](https://en.wikipedia.org/wiki/Space_Race), — These were upsettingly high risk projects, and yet the public was standing behind those
  - There was a much better communication model is how scientists talked about their work
- Scientists need to lead and that starts with being better communicators with the public, which is no small task
- It can be very tricky especially In environments that are polarized (seemingly every environment today), ones that inherent conflicts such as lots of stakeholders trying to achieve the most for themselves and for their own benefits
- Scientists do have a voice, but that voice is often drowned in the middle of all the screams of social media, and even mainstream media, by people with agendas backed by lobbyists

*So how do we strengthen that communication?*

- One option is to use the same tricks as lobbies do
- The other option is to “*stick to our guns and behave as scientists*”
- The problem with the former option is that John feels very uneasy about the idea that scientists must try to become communicators that are lobbying
- Option 2 is more appealing because…
  - You want to avoid exaggeration and be able to say, “I don’t know. I’m doing research because I don’t know…but these are questions that could make a difference for you.”
  - We need to be able to set expectations that we will most likely fail to “find something” in most cases but it’s part of the discovery process
  - We need to keep our honesty
  - We need make communication clear cut
  - We need to fight against people who are not scientists and who are promising too much

> “We need to defend our method. We need to defend our principles. We need to defend the honesty of science in trying to communicate it rather than build exaggerated promises or narratives that are not realistic.” —John Ioannidis

![](https://peterattiamd.com/wp-content/uploads/2021/01/feyman-quote-ioannidis-1024x483.png)

**Figure 3 Famous Richard Feynman quote.** [[source](https://www.azquotes.com/quote/95368)]

**Humans weren’t build to think scientifically**

- It’s so much fun to be able to talk about this process of discovery and to remind ourselves that it’s not an innate skill
- This methodology of science didn’t exist 500 years ago
- Keeping this in mind gives us a little bit of empathy for people who have no training
- But if the good scientists aren’t the ones speaking, then it’s either going to be the bad ones and or the charlatans who will

⇒ See Peter’s post on this topic: [Why we’re not wired to think scientifically (and what can be done about it)](https://peterattiamd.com/wired-think-scientifically-can-done/)

## Case studies demonstrating the challenge of epidemiology and how even the best studies can have major flaws [1:21:30]

**John’s 2018 paper**: [The Challenge of Reforming Nutritional Epidemiologic Research](https://jamanetwork.com/journals/jama/article-abstract/2698337)

- John looked at single foods and the claims that emerged in terms of epidemiology
- Many of them were simply absurd:
  - Eating 12 hazelnuts per day extended life by 12 years
  - Drinking three cups of coffee extended life by 12 years
  - Eating one Mandarin orange per day could extend lifespan by 5 years
  - Consuming one egg would shorten life by 6 years
  - Two strips of bacon would shorten life by a decade

*How do you explain these results and what does it tell us about this epidemiological process?*

- Using relative risks, they’re a very crude translation of what the average person in the community would get if they see the numbers that are reported
- The true translation to change in life expectancy would be much smaller if not in the opposite direction
- It just shows the magnitude of the problem we have—if you have a system that is so complicated, with so inaccurate measurements, with so convoluted and overtly correlated variables, with selective reporting and biases superimposed, you get a situation where you get an implausible big picture, where you’re talking about huge effects that are unlikely to be true
- It reiterates our need to bring better methods, better training, and better inferences to that land of irreproducible results

**The original PREDIMED publication in 2013**: [Primary Prevention of Cardiovascular Disease with a Mediterranean Diet](https://www.nejm.org/doi/full/10.1056/NEJMoa1200303)

- The study was seemingly set up quite well as a clinical trial with three arms and relying on hard outcomes (meaning mortality or morbidity)
- It compared a low-fat arm and two types of Mediterranean diets (one with olive oil, the other with nuts)
- The authors selected people that were sick enough that within five years they ended up stopping this study given that the the Mediterranean groups performed significantly better than the low-fat group

*John’s initial reaction and evolving take on the results*

- For many years, John was touting these results as “here’s how you can do it the right way and show clinically relevant results”
- It was both statistically and clinically very significant
- However, it was eventually realized that unfortunately, this trial was not really a randomized trial
  - A number of people had not actually been randomized because of problems in the way that they were recruited, and therefore the data were problematic
  - Some of the trial was actually observational
- New England Journal of Medicine [retracted and republished the study](https://www.nejm.org/doi/full/10.1056/NEJMc1806491) trying to correct for the imposed observational nature of some of the data
- But the results did not change much

⇒ See John’s take on the PREDIMED study: [PREDIMED trial of Mediterranean diet: retracted, republished, still trusted?](https://pubmed.ncbi.nlm.nih.gov/30733217/)

*John’s takeaways*:

- 1-“It creates a very uneasy feeling that if the ‘creme de la creme trial’, the one that I adored and I admired, had such a major problem, such a major, basic, unbelievably simple problem in its very fundamental structure of how it was run… ‘How much trust can you put on other aspects of the trial that require even more sophistication and even more care?’”
- 2-It doesn’t mean that Mediterranean diet does not work, but it just gives one example of how things can go wrong even when you have good intentions

*John’s other points…*

- One has to take into account that in such an experiment, you have a very large number of people who are involved, and their level of methodological training and their ability to understand what needs to be done may vary quite a bit
- It’s very difficult to know that everyone involved in all the sites involved in the trial would do the right thing
- This is an issue also for other randomized trials that are multicenter trials
- Also, there’s very little funding from public agencies, and so most of the multicenter trials are done by the industry
- They try to impose some rigor and some standards but oftentimes there are teams that have no expertise in clinical research
- You end up with situations where a lot of the data were collected by people who are not trained, who have no expertise

> “You can have severe bias interfere even in studies that seemingly appear to be like the creme de la creme of large scale experimental research.” —John Ioannidis

## Results of John’s study looking at the seroprevalence of SARS-CoV-2, and the resulting vitriol revealing the challenge of doing science in a hyper-politicized environment [1:31:00]

John participated in two studies—[one in Los Angeles County](https://jamanetwork.com/journals/jama/fullarticle/2766367), and the [other one in Santa Clara](https://www.medrxiv.org/content/10.1101/2020.04.14.20062463v2)— looking at the seroprevalence of SARS-CoV-2

- The study design aimed to collect a substantial number of participants and try to see how many of them had antibodies to the SARS-CoV-2 virus (meaning that they had been infected)
- These were the first studies to suggest that basically the seropositivity was **much higher** than the confirmed cases.
- John says the studies were very well done and provided very useful data to tell us more about how widely spread this virus really is

*John’s thinking going into the studies*

- “Personally, I was open to the possibility of any results”
- “I had no clue how widely spread the virus would be, and this is why I thought these studies were so essential”

*The potential implications*:

- If it’s very widely spread, the infection fatality rate per person is much lower.
- If it is a very limited in its spread, it means that fewer people are affected, but the infection fatality rate would be very high

*The results*:

- Turned out that the virus was very widely spread, far more common compared to what we thought based on the number of tests that we were doing and the number of PCR documented cases at that time
- In fact, it was about 50 times more common than we thought based on the documented cases

**Public reaction to the results**

- It generated a lot of animosity because people have **very strong priors** and because we are unfortunately in a **highly polarized, toxic, political environment**
- That said, John comments that he is grateful for the constructive criticism because “*these were very delicate results that we had to be sure that we had the strongest documentation for what we were saying*”

*Validated results*

- Several months later, the results are practically completely validated by more studies such as shown in a [Lancet paper](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(20)32009-2/fulltext) which included a dataset of hemodialysis patients and the infection rates
- Remember, in the early days before testing was common was when we had the highest level of underascertainment
- But if you translate the Lancet results to an infection fatality rate, it is exactly identical to what John’s studies had observed in early April
- So the study has been validated, it has proven that the virus is a very rapidly and very widely spreading virus

**Estimate of prevalence**

- - John’s estimate is that by early December 2020, we probably have close to 1 billion people who have already been infected

- *Steep risk gradient*

- - A lot of people have practically no risk, or minimal risk, of having a bad outcome
  - And there are some people who have tremendous risk of being devastated
  - For example, people in nursing homes have about a [25% infection fatality rate](https://www.who.int/bulletin/online_first/BLT.20.265892.pdf)

**The resulting vitriol revealing the challenge of doing science in a hyper-politicized environment**

John calls this “one of the most interesting experiences in my career” —

- both from the fascination about seeing these results,
- and also the fascination and some of the intimidation tactics people used in response to these results in a very toxic environment

*What forces were the most critical and where did most of the vitriol came from?*

- Many scientists who made useful comments
- And then there were many people in social media, that includes some scientists who actually were not epidemiologist

*What do you think was at the root of this anger?*

- Most of the animosity was related to the toxic political environment from people who believed we should take harsher lock down strategies

> “It is extremely important to completely dissociate science from politics. Science should be free to say what has been found with all the limitations and all the caveats, but be precise and accurate.
>
> I would never want to think about what a politician is saying in a given time or given circumstances, and then modify my findings based on what one politician or another politician is saying.” —John Ioannidis

**Attacks against John**

- One of the attacks against John was that he had a conservative ideology that skewed his study results
  - Which is the most stupendous claim that I can think of given John’s personal stances on climate change, guns, etc.
- The other accusation was that he was paid off by airline companies
  - An airline had contributed $5,000 to Stanford
  - John was not even aware of this contribution
  - Nor did he get any of it
- “*We have received $0 for OUR research, but tons of smearing*.”
- He got a lot of hate mail and threatening messages to his family
- A hoax even got circulated that his 86 year old mother died of COVID-19
- “These people really had a very toxic response that did a lot of damage to me and to my family and to others as well.”

**The need to protect our scientists**

- “*For me, the most major problem is ‘How do we protect scientists?’ It’s not about me. It is about other scientist*s.”
- John’s says younger, less prominent scientist will be very afraid to disseminate their scientific findings objectively if they have to wonder what the reaction will be
  - We need to protect people who would be very much afraid to talk and they would be silenced
  - We need to be tolerant
  - We need to give science an opportunity to do its job, to find useful information, to correct mistakes,  and improve on methods
- The vicious vitriol is very dangerous, says John
- “*Regardless of whether it comes from people in one or another political party or one in another ideology, it ends up being the same. It ends up being populist attacks of the worst possible sort*.”

*The incompatibility of science and politics*

- In everyday life, especially in politics, it’s viewed as unwise to have a changing opinion
- In science, someone who can change their mind in the presence of new information is a core competency of doing good science
- Much of the problem of today has to do with not being able to update your priors and change your mind in the face of new information

*The lack of scientific knowledge*

- The pandemic has brought science to the limelight
- Science  has become a topic of great interest as people see that their lives depend on science
- Suddenly we have had hundreds of millions, if not billions, of people become interested in science acutely
- Most of those unfortunately, have no science education and they use the tools of their traditional society discourse, which is largely political and sectorized, to try to deal with scientific questions—And this is an “explosive mix”
- The antidote to this is better communication about science and better methods used in science

> “Science is a hostage of these lobbying forces and all of this turmoil that is happening in the community.” —John Ioannidis

\*\*\*

Other COVID-19 papers by John:

- [Coronavirus disease 2019: The harms of exaggerated information and non‐evidence‐based measures](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7163529/) (Ioannidis, 2020a)
- [Forecasting for COVID-19 has failed](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7447267/?fbclid=IwAR25u820a2hYtbfOzp_fHkHXwvFbK5V5K70fEu7YK8QG5uV3Q5ExVXqyMhA) (Ioannidis et al., 2020a)
- [Infection fatality rate of COVID-19 inferred from seroprevalence data](https://www.who.int/bulletin/online_first/BLT.20.265892.pdf) (John P A Ioannidis, 2020)

## John’s excitement about the future [1:47:45]

**What is John most excited and optimistic about in terms of the future of science and the type of work that he’s looking to advance?**

“*Every day I realize that there’s even more things that I don’t know…things that I thought were so, but actually they were wrong, and I need to…find ways to correct them*.”

“*I really look forward to a good future for science and a good future for humans…We’re just at the beginning of knowledge, and I feel like a little kid who just wants to learn a little bit more, a little bit more each time*.”

§

## Selected Links / Related Material

**John’s paper where he uses a mathematical model to show that most published research in the biomedical field is incorrect**: [Why Most Published Research Findings Are False](https://journals.plos.org/plosmedicine/article?id=10.1371/journal.pmed.0020124) (Ioannidis, 2005) [1:45, 10:15, 54:30]

**Genetic studies mentioned – “GWAS” studies**: [Genome-wide association study](https://en.wikipedia.org/wiki/Genome-wide_association_study) | (wikipedia.org) [31:00]

**John’s paper regarding the GWAS studies**: [Replication validity of genetic association studies](https://www.nature.com/articles/ng749z) (Ioannidis et al., 2001) [31:00]

**Science article about the fraud involving the Cornell professor**: [Cornell nutrition scientist resigns after retractions and research misconduct finding](https://www.sciencemag.org/news/2018/09/cornell-nutrition-scientist-resigns-after-retractions-and-research-misconduct-finding) | Kelly Servick (sciencemag.org)  [36:45, 1:03:45]

**Austin Bradford Hill’s criteria for doing good science**: [38:45]

- *The paper*: [The Environment and Disease: Association or Causation?](https://www.edwardtufte.com/tufte/hill) | Proceedings of the Royal Society of Medicine, 58 (1965), 295-300. By Sir Austin Bradford Hill (edwardtufte.com)
- *Wiki page*: [Bradford Hill criteria](https://en.wikipedia.org/wiki/Bradford_Hill_criteria) | (wikipedia.org)

**John’s take on the “Exposure-wide” approach of doing studies**: [Exposure‐wide epidemiology: revisiting Bradford Hill](https://onlinelibrary.wiley.com/doi/abs/10.1002/sim.6825) (Ioannidis, 2015) [51:00]

**John’s most cited paper**: [The PRISMA statement for reporting systematic reviews and meta-analyses of studies that evaluate healthcare interventions: explanation and elaboration](https://www.bmj.com/content/339/bmj.b2700) (Liberati et al., 2009) [52:45]

**John’s “most entertaining” paper looking at cookbook ingredients and their purported link to cancer**: [Is everything we eat associated with cancer? A systematic cookbook review](https://academic.oup.com/ajcn/article/97/1/127/4576988) (Schoenfeld and Ioannidis, 2012) [53:00]

**Documentary about D.B. Cooper that Peter mentioned**: [The Mystery of D.B. Cooper](https://www.hbo.com/documentaries/the-mystery-of-db-cooper) | (hbo.com) [59:45]

**John’s 2018 paper**: [The Challenge of Reforming Nutritional Epidemiologic Research](https://jamanetwork.com/journals/jama/article-abstract/2698337) (Ioannidis, 2018) [1:21:30]

**The original PREDIMED publication in 2013**: [Primary Prevention of Cardiovascular Disease with a Mediterranean Diet](https://www.nejm.org/doi/full/10.1056/NEJMoa1200303) (Estruch et al., 2013) [1:24:00]

- New England Journal of Medicine retracted and republished the study in 2018: [Retraction and Republication: Primary Prevention of Cardiovascular Disease with a Mediterranean Diet.](https://www.nejm.org/doi/full/10.1056/NEJMc1806491) [1:26:15]
- Wiki page: [Predimed](https://en.wikipedia.org/wiki/Predimed)

**John’s take on the PREDIMED study**: [PREDIMED trial of Mediterranean diet: retracted, republished, still trusted?](https://pubmed.ncbi.nlm.nih.gov/30733217/) [1:24:00]

**John participated in two studies looking at the seroprevalence of SARS-CoV-2**: [1:31:00]

- [Seroprevalence of SARS-CoV-2–Specific Antibodies Among Adults in Los Angeles County, California, on April 10-11, 2020](https://jamanetwork.com/journals/jama/fullarticle/2766367) (Sood et al., 2020)
- [COVID-19 Antibody Seroprevalence in Santa Clara County, California](https://www.medrxiv.org/content/10.1101/2020.04.14.20062463v2) (Bendavid et al., 2020)

**The results found in John’s seroprevalence studies were validated by more studies such as shown in a Lancet paper which included a dataset of hemodialysis patients and the infection rates**: [Prevalence of SARS-CoV-2 antibodies in a large nationwide sample of patients on dialysis in the USA: a cross-sectional study](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(20)32009-2/fulltext) (Anand et al., 2020) [1:36:30]

**John estimates that people in nursing homes have a 25% infection fatality rate from COVID-19**: [Infection fatality rate of COVID-19 inferred from seroprevalence data](https://www.who.int/bulletin/online_first/BLT.20.265892.pdf) (John P A Ioannidis, 2020) [1:37:30]

§

## People Mentioned

- [Dimitrios Trichopoulos](https://pubmed.ncbi.nlm.nih.gov/25773754/#:~:text=Dimitrios%20Trichopoulos%20was%20Professor%20of,Hellenic%20Health%20Foundation%20in%20Greece.) [7:15]
- [Bob Moellering](https://aac.asm.org/content/58/7/3583) [7:45]
- [Tom Chalmers](https://en.wikipedia.org/wiki/Thomas_C._Chalmers) [8:30]
- [Joe Lau](https://vivo.brown.edu/display/jl122) [8:30]
- [David Sackett](https://en.wikipedia.org/wiki/David_Sackett) [8:30]
- [Gordon Guyatt](https://en.wikipedia.org/wiki/Gordon_Guyatt) [8:30]
- [Pat Brown](https://en.wikipedia.org/wiki/Patrick_O._Brown) [10:40]
- [Austin Bradford Hill](https://en.wikipedia.org/wiki/Austin_Bradford_Hill) [38:45]
- [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) [1:02:30, 1:20:15]
- [Brian Wansink](https://en.wikipedia.org/wiki/Brian_Wansink) [1:03:45]
- [Teddy Roosevelt](https://en.wikipedia.org/wiki/Theodore_Roosevelt) [1:17:45]
- [Albert Einstein](https://en.wikipedia.org/wiki/Albert_Einstein) [1:17:45]
- [David Alison](https://en.wikipedia.org/wiki/David_B._Allison) [1:31:15]
- [Eran Bendavid](https://profiles.stanford.edu/eran-bendavid) [1:32:45]
- [Jay Bhattacharya](https://healthpolicy.fsi.stanford.edu/people/jay_bhattacharya) [1:32:45]
- [Tony Fauci](https://en.wikipedia.org/wiki/Anthony_Fauci) [1:43:15]

§

![](https://peterattiamd.com/wp-content/uploads/2021/01/bio-image-ioannidis-500x500.png)

##### John Ioannidis, M.D., D.Sc.

John Ioannidis is a physician-scientist, writer and Stanford University professor who has made contributions to evidence-based medicine, epidemiology, and clinical research. Ioannidis studies scientific research itself, meta-research primarily in clinical medicine and the social sciences. He’s one of the world’s foremost experts on the credibility of medical research. He’s the Co-director of the Meta-research Innovation Center at Stanford.

Ioannidis’ paper on “Why Most Published Research Findings are False” has been the most-accessed article in the history of Public Library of Science (over 3 million views in 2020).