# #66 – Vamsi Mootha, M.D.: Aging, type 2 diabetes, cancer, Alzheimer’s disease, and Parkinson’s disease – do all roads lead to mitochondria?

**Source:** [https://peterattiamd.com/vamsimootha/](https://peterattiamd.com/vamsimootha/)

---

In this episode, Dr. Vamsi Mootha, an expert in mitochondrial biology and an investigator at the Howard Hughes Medical Institute, shares his breadth of knowledge on the mitochondrion organelle: its history, function, genome architecture, and his research of rare mitochondrial dysfunction. Vamsi is currently focused on finding clinical treatments for the 300-some identified rare mitochondrial disorders, but in this work there is a wealth of potential implications for longevity and chronic disease. In this conversation, Vamsi elucidates how the latest research could give insight into conditions related to aging, including but not limited to Alzheimer’s, Parkinson’s, insulin resistance and type 2 diabetes, cancer, and much more. We also explore some of the most exciting potential therapies for mitochondrial diseases such as hypoxia (oxygen deprivation), how exercise affects the mitochondria, the use of hyperbaric chambers for cancer therapy, and the mechanisms by which metformin might confer longevity benefits in a non-diabetic individual.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/vamsimootha/the_Drive_public.png)

Play

#66 - Vamsi Mootha, M.D.: Aging, type 2 diabetes, cancer, Alzheimer's disease, and Parkinson's disease – do all roads lead to mitochondria?

#66 - Vamsi Mootha, M.D.: Aging, type 2 diabetes, cancer, Alzheimer's disease, and Parkinson's disease – do all roads lead to mitochondria?

1x15s30s

0:002:27:53

## We discuss:

- The Broad Institute of MIT and Harvard [8:00];
- Vamsi’s academic background [10:30];
- Advice for college students and med students considering a career in medicine and/or medical research [15:30];
- Vamsi’s focus on mitochondria and mitochondrial disorders [20:00];
- The mitochondrial genome: Lineage, endosymbiosis, and reductive evolution [23:15];
- How many diseases can be attributed to mitochondrial mutations? [28:45];
- Nuclear DNA and mtDNA: Roles, interaction, communication, and biogenesis [31:30];
- Which cells have the most mitochondrial DNA? And how often does mitochondria turn-over in a cell? [37:30];
- Does ALL of your mitochondrial DNA come from your mother? [40:00];
- Mitochondria 101: The powerhouse of the cell, electron transport chain, and the NADH/NAD ratio [44:00];
- NAD and NADH: Role in the mitochondria, decline of NAD levels with age, and what it means to age at a mitochondrial level [51:30];
- Mitochondrial diseases Vamsi studies in his lab [55:15];
- Mitochondria and oxygen: Poor oxygen utilization and excess oxygen contributes to the pathology seen in some of the rare mitogenic diseases [1:02:00];
- What VO2 max can tell us about mitochondrial function, insulin resistance, type 2 diabetes, and more [1:10:00];
- Can studying mitochondrial disease provide insights into the common forms of aging?  [1:18:45];
- Could muscle cell inflammation (a signature of aging) be caused by mtDNA damage being confused as foreign bacteria? [1:22:00];
- Exercise and mitochondrial health: Is there an optimal exercise strategy to slow the aging process? [1:27:00];
- What autophagy means in the context of mitochondria [1:36:15];
- Metformin’s impact on exercise and lactate levels [1:40:15];
- How might metformin confer longevity benefits? [1:48:15];
- Hypoxia as a potential therapeutic option for mitochondrial disease [1:52:45];
- Cancer prevention and treatment: hyperbaric oxygen chambers, targeting single carbon metabolism of the mitochondria, and more [2:00:00];
- Chronic diseases have altered mitochondria: Evidence for mitochondrial dysfunction causing Parkinson’s Disease  [2:04:30];
- Why Vamsi is very optimistic about the possibility of targeting mitochondrial proteins as therapies [2:09:30];
- Is it theoretically possible to genetically engineer a better functioning mitochondria? [2:14:30];
- Vamsi’s fantasy experiment in an unconstrained world [2:20:15]; and
- More.

§

## Show Notes

## The Broad Institute of MIT and Harvard [8:00]

- Creation and vision for the [Broad Institute](https://en.wikipedia.org/wiki/Broad_Institute) was “an experiment” by [Eric Lander](https://www.broadinstitute.org/bios/eric-s-lander) – one of the leaders of the [human genome sequencing project](https://www.genome.gov/human-genome-project)
- Lander wanted to create an institute that could utilize genomics for the improvement of biomedicine
- It is joint between Harvard and MIT and includes all the hospitals in Boston
- It is a forum where researchers can collaborate and pursue research that they would not be able to do in their individual laboratories
- Either researchers are employed by the institute or employed elsewhere (as is the case for Vamsi) as their primary appointment, but spend time at the institute working on collaborative projects

## Vamsi’s academic background [10:30]

- Growing up, he was convinced that he wanted to be a doctor
- When he was in high school, he fell in love with math and went to Stanford as a math and computer science major
- As a college student, his advisor introduced him to the work of [Sam Karlin](https://en.wikipedia.org/wiki/Samuel_Karlin) – a statistician who developed some of the underlying methods for biomolecular sequence analysis
  - Vamsi worked on a DNA sequence analysis as a college student: writing code to analyze DNA and protein sequences.
  - He fell in love with the research and his advisor suggested that he consider a career in medicine
- He applied simultaneously to PhD programs in mathematical biology and also applied to a joint program between Harvard and MIT ([HST](https://meded.hms.harvard.edu/health-sciences-technology)): an interdisciplinary program that brings together engineering, physical, and biological sciences
- Completed his residency in internal medicine at Brigham and Women’s Hospital in Boston

## Advice for college students and med students considering a career in medicine and/or medical research [15:30]

> “The advice that I’d gotten when I was in college was that the reason to go to medical school, if you’re interested in research, is that it’s one of the best curricula for understanding physiology, how all of the parts come together and operate, and [for] trying to understand how an entire living system operates. If you don’t go through all of medical school, if you don’t learn anatomy, if you don’t learn histology, if you don’t learn cardiovascular physiology, it’s a bit tough”

- There are two junctures:
  - At the college juncture and interested in medical research: Is there a benefit to doing an MD?
  - At the post-medical school juncture and want to pursue research: Is there a benefit to doing a residency?
- The guidance
  - In college and undecided about medical school, lean towards a PhD
  - Going to medical school is one of the best ways to understand human physiology
  - In medical school and presumably at least somewhat interested in medicine still, do an internal medicine residency
    - At least do an internship in order to have a license and can prescribe medicine

> “And one of my advisers actually said to at least do an internship because then you’ll be licensed. You can prescribe medicines at that point. And there is something special about caring for patients. There’s something very special about going through the process of residency with your colleagues. And again, you really get to see the human living system at some of its extremes. And so I think it’s a great way of continuing to learn physiology and pharmacology as well”

## Vamsi’s focus on mitochondria and mitochondrial disorders [20:00]

> “You’ve seen image of mitochondria in the muscle, it’s just beautiful and there’s just something that really captivated me and I kind of got hooked on that organelle that first semester of medical school”

- Vamsi no longer sees patient and now focuses on research full time
  - He leads a research group that focuses on [mitochondria](https://en.wikipedia.org/wiki/Mitochondrion) and mitochondrial disorders
  - The long term goal is for his research to impact patients: rather than care for them directly he works to develop new diagnostics and drugs, which will be used in front-line patient treatment
- He was drawn to the organelle as a first-year medical student
  - A lecture on myopathies (muscular diseases) in a medical school histology and pathology class brought to his attention that there is a rare form of myopathies that are due to mutations in the mitochondrial DNA
  - He found a book on the mitochondria organelle on the bookshelf at his dad’s cousin’s house where he spent the night and started reading it

## The mitochondrial genome: Lineage, endosymbiosis, and reductive evolution [23:15]

- *How did these bacteria find their way into the eukaryotic cell*?
  - The bacteria organism had a full electron transport chain and was likely capable of doing aerobic metabolism using oxygen as a terminal electron acceptor
  - The current theory of origin is a process known as  [endosymbiosis](https://en.wikipedia.org/wiki/Symbiogenesis): a bacteria organism resembling a modern [gram-negative rods](https://en.wikipedia.org/wiki/Gram-negative_bacteria) (a bacteria shaped like a rod that is gram-negatively stained for identification) that merged with a modern-day archaea species
  - The hypothesis is that the bacteria merged with modern-day archaea, giving rise to eukaryotes with a nuclei (three domains of life: [Archaea, Bacteria, Eukaryote](https://en.wikipedia.org/wiki/Domain_(biology))), around 1.5 billion years ago
- Endosymbiosis (the merging of bacteria and archaea) of the mitochondrion only took place once
  - The theory proposes that the bacteria [electron transport chain](https://en.wikipedia.org/wiki/Electron_transport_chain) was similar to that of present-day mitochondria
  - Almost all eukaryotes have mitochondria and the DNA analysis of those mitochondria support the theory that it was a monophyletic event
  - Comparatively, the [chloroplast](https://en.wikipedia.org/wiki/Chloroplast) in a plant arose through serial endosymbiosis – which took place at least two independent times in evolution

![](https://peterattiamd.com/wp-content/uploads/2019/08/vamsi-figure-1-1024x578.png)

**Figure 1. Endosymbiotic theory for the origin of eukaryotic cells.** Image credit: [Khanacademy.org](https://www.khanacademy.org/science/high-school-biology/hs-cells/hs-prokaryotes-and-eukaryotes/a/chloroplasts-and-mitochondria)

**The mitochondrial genome**

- The original gram-negative rod (bacterium) had about 1,000-2,000 genes and the (archaea) species it merged with had around 2,000 genes
- The two merging species had a comparable number of genes and yet today, humans have 20,000 to 30,000 genes inside of the nucleus, with 13 genes inside the mitochondria
- The mitochondrial genome is the product of [reductive evolution](https://www.oxfordreference.com/view/10.1093/oi/authority.20110803100409663)
  - Modern day mitochondria represent a mosaic: about 1,000 proteins make the mitochondria, some of which are attributable to the original bacterial ancestor and others are brand new proteins that the original bacterium did not have
  - On the reductive side: approximately 1,000 genes from the original bacteria have been lost or transferred to the nuclear genome
  - The nuclear genome is tiny: in animals, only about 16,000 bases encode for 13 proteins in the mitochondria
- There are a lot of different eukaryotes (not just animals) so there is a lot of mitochondrial diversity
  - For example, malaria is a eukaryote with a mitochondrion that encodes three proteins
  - In another example, [Giardia](https://www.mayoclinic.org/diseases-conditions/giardia-infection/symptoms-causes/syc-20372786) has lost its mitochondrial DNA altogether

## How many diseases can be attributed to mitochondrial mutations? [28:45]

**13 proteins of the mitochondria function and mutation**

- The mitochondrial genome encodes two ribosomal RNAs, 22 tRNAs and then 13 proteins
- There is a good sense of the function of each mitochondrial protein
- There are about 250 different syndromes (particular mutation associated with a clinical phenotype) of the mitochondrial DNA (mtDNA)
  - That number of mutation only refers to mitochondrial DNA disorders
- There is not a solid understanding of whether mtDNA mutations have a higher or lower frequency on a probability basis (with 16,000 base pairs) compared to the nuclear genome
- There is [ascertainment bias](https://catalogofbias.org/biases/ascertainment-bias/) in clinical medicine regarding mitochondrial disease
- Mitochondrial disease is largely attributed to maternal inheritance
- mtDNA is smaller and easy to sequence
  - The nuclear genome was sequenced in 2001 but the mitochondrial DNA was sequenced 20 years earlier in 1981
  - From 1988 when the first two papers ([1](https://www.ncbi.nlm.nih.gov/pubmed/2830540), [2](https://www.ncbi.nlm.nih.gov/pubmed/3201231)) were published, reporting first mtDNA mutations with the disease phenotype, it has been relatively easy to sequence it and its associated mutations
  - That is why there is about 250 of the mtDNA mutation clinical phenotype mappings
- Comparatively, the research community has identified about 300 genes in the nuclear genome that underlie mtDNA disorders (since 2001)
  - But then there are different allelic variants as well

## Nuclear DNA and mtDNA: Roles, interaction, communication, and biogenesis [31:30]

- Beginning soon after the sequencing of the human genome, it was understood that the human genome encodes about 22,000 proteins
- The question became: *which of the nuclear DNA proteins find their way into the mitochondria*?
  - About 1,100 proteins that are made by the nuclear genome find their way into the mitochondrion
  - Those 1,100 proteins have to work with the 13 mtDNA proteins within the organelle

**Biogenesis: mtDNA and nuclear DNA communication in the mitochondrion**

- Some mechanisms are known and many are not
- For example, in response to exercise there is a transcriptional program response
  - within the organelle, replication factors turn on in the organelle that essentially says: “make more of the nuclear DNA components, mitochondrial DNA components and mitochondrial DNA-encoded proteins”
  - The transcription program increases mitochondrial density in a given cell
  - Within a myocyte (muscle cell), physiologic-level signalling instruct a cell to make more DNA in response to exercise
- One important signal that induces mitochondrial biogenesis is [AMP kinase](https://en.wikipedia.org/wiki/AMP-activated_protein_kinase): change in the ATP:ADP ratio
  - There is sensing of [ATP:ADP ratio](https://www.cellsignal.com/contents/science-cst-pathways-cellular-metabolism/ampk-signaling/pathways-ampk) decrease that promotes an increase in AMPK activity

![](https://peterattiamd.com/wp-content/uploads/2019/08/vamsi-figure-2-1-979x1024.png)

**Figure 2. Activated protein kinase (AMPK) plays a key role as a master regulator of cellular energy homeostasis. The kinase is activated in response to stresses that deplete cellular ATP supplies.** Image credit: [cellsignal.com](https://www.cellsignal.com/contents/science-cst-pathways-cellular-metabolism/ampk-signaling/pathways-ampk)

- It is still an open question as to how exactly the number of mitochondria is sensed and regulated but some of the inputs have been identified
- [Metformin](https://en.wikipedia.org/wiki/Metformin) administration activates AMPK but that does not necessarily mean that mitochondrial density is altered
- This is because AMP activation is an important signal for mitochondrial biogenesis but it is not sufficient
- Some other mitochondrial biogenesis signals (aside from exercise):
  - Calcium
  - Disease states in which there is a massive proliferation of malfunctioning mitochondria
  - Androgens and testosterone can influence the amount of mitochondria (see Vamsi’s 2005 [study](https://mootha.med.harvard.edu/PubPDFs/Pitteloud2005.pdf) on how androgens and testosterone can influence mitochondrial density)
  - Nutrients: NAD is an important signal
    - Transcriptional cofactor [PGA-1α](https://en.wikipedia.org/wiki/PPARGC1A) regulates mitochondria biogenesis
    - [SIRT1](https://en.wikipedia.org/wiki/Sirtuin_1), which utilizes NAD as a cofactor directly affects PGC-1α activity through deacetylation
    - For more on how NAD is used as a substrate in certain chemical reactions, checkout a [previous episode of The Drive with David Sinclair](https://peterattiamd.com/davidsinclair/) (specifically starting at 31:00)

## Which cells have the most mitochondrial DNA? And how often does mitochondria turn-over in a cell? [37:30]

- Talking about the number of mitochondria in a muscle cell, for example, is ambiguous because they are not quantal units
- Mitochondria constantly undergo fusion and fission so there can be a different “number” of mitochondria in a cell
- MtDNA, on the other hand, is a quantal unit
  - mitochondrial genomes per nuclear genome in a cell type can be quantified
  - A fibroblast, for example, have a few hundred to 1,000 copies of the mitochondrial genome for each copy of its nuclear genome, but there is a lot of variation
  - The cell type with the highest number of copies of the mitochondrial genome is the unfertilized egg – it has half a million copies of mitochondrial DNA
  - Sperm has up to a few hundred mtDNA
  - Red blood cells have no mtDNA
- The mitochondrial turnover dynamics of dividing and nondividing cells are different
  - In most non-dividing tissues (e.g muscles and neurons), the half-life of mitochondria is on the order of a few days
  - A dividing cell needs to double the number of mitochondria then partition the replication and repeat

## Does ALL of your mitochondrial DNA come from your mother? [40:00]

- The textbook teaching is that mtDNA is transmitted exclusively via maternal lineage
- Mechanistically, mtDNA is passed on from mom to child for two primary reasons

1. maternal mtDNA grossly outnumbers paternal mtDNA
   1. This is due to [sexual dimorphism](https://en.wikipedia.org/wiki/Sexual_dimorphism): by sheer dilution (because the egg is so huge – having millions of copies of mtDNA compared to sperm mtDNA that has few hundred copies), it’s difficult for the dad’s mtDNA to get transmitted
2. paternal mtDNA are actively destroyed after fertilization
   1. Sperm mtDNA are encoded by [ubiquitin](https://en.wikipedia.org/wiki/Ubiquitin), which marks them for active elimination once fertilized inside of the egg

- However, in a rare exception, [one case report of a biopsy](https://www.nejm.org/doi/full/10.1056/NEJMoa020350)  reported mtDNA molecules of an individual with two differential haplotypes and concluded paternal mtDNA transmission
- [Another paper](https://www.pnas.org/content/115/51/13039) claimed a few families in which mtDNA paternal transmission occurred
- While paternal mtDNA transmission is a rare event, it is an active area of research
- If the results are not a technical artifact, there is an opportunity to learn about the mechanisms of maternal transmission

## Mitochondria 101: The powerhouse of the cell, electron transport chain, and the NADH/NAD ratio [44:00]

> “I like to think of the mitochondria as being the key place where there’s energy transformations. So in order for a cell to work, it needs energy, but in the same way that, in order to live our lives, we need to have one type of battery for our iPhone, a different type of battery for a laptop, a different type of battery for our automobile. We need energy packaged in different ways. So this is sort of the charm of the mitochondria”

- The mitochondria is the key place where energy transformations take place

![](https://peterattiamd.com/wp-content/uploads/2019/08/vamsi-figure-3-928x1024.png)

**Figure 3.** [**Cellular Respiration**](https://en.wikipedia.org/wiki/Cellular_respiration)**. Glycolysis oxidizes glucose molecules. It is followed by the Krebs cycle and oxidative phosphorylation to produce ATP.** Image credit: [lumenlearning](https://courses.lumenlearning.com/boundless-biology/chapter/glycolysis/)

- A cell takes in glucose, free fatty acid, substrate for energy and in 10 steps glucose gets turned into [pyruvate](https://en.wikipedia.org/wiki/Pyruvic_acid)

![](https://peterattiamd.com/wp-content/uploads/2019/08/fig-4-revised-1024x867.png)

**Figure 4.** [**Glycolysis**](https://en.wikipedia.org/wiki/Glycolysis) **metabolic pathway (the first in cellular respiration) that, in aerobic conditions, produces pyruvate and, in anaerobic conditions, producing lactate. In aerobic conditions, the process converts one molecule of glucose into two molecules of pyruvate (pyruvic acid), generating energy in the form of two net molecules of ATP.** Image credit: [wikispaces](https://wikispaces.psu.edu/display/230/Glycolysis%2C+Fermentation+and+the+Citric+Acid+Cycle)

- Once glucose gets turned into pyruvate, there are two scenarios dependent on oxygen availability and ATP demand:

1. if oxygen is scarce relative to ATP demand, the “inefficient” route is that pyruvate gets turned into lactate
2. With low ATP demand and sufficient oxygen, pyruvate converts into Acetyl-CoA, a substrate for the electron transport chain

**The** [**electron transport chain**](https://en.wikipedia.org/wiki/Electron_transport_chain) **in the mitochondria: The NADH/NAD ratio is essential for mitochondrial function**

> “…think of a mitochondria as partially being a battery” – Peter Attia

![](https://peterattiamd.com/wp-content/uploads/2019/08/fig-5-revised-1024x866.png)

**Figure 5.  The electron transport chain is present in multiple copies in the inner mitochondrial membrane of eukaryotes and it is the last component of cellular aerobic respiration. The electron transport chain is a series of electron transporters embedded in the inner mitochondrial membrane that shuttles electrons from NADH and FADH2 to molecular oxygen, using  a proton pump to create a proton gradient across a membrane. In the process, protons are pumped from the mitochondrial matrix to the intermembrane space, and oxygen is reduced to form water.** Image credit: [lumenlearning.com](https://courses.lumenlearning.com/wm-biology1/chapter/reading-electron-transport-chain/)

- One type of energy in the mitochondria is the [electromotive force](https://www.dummies.com/education/science/biology/the-proton-motive-force/)
  - Energy from food: the mitochondria takes fats, carbohydrates and proteins and breaks down the energy forms, harnessing the electrons
- The [NADH/NAD ratio](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide) is an electron carrier that can power certain types of enzymes
- Alternatively, the NADH/NAD ratio can also be converted to a gradient, or voltage, across the inner mitochondrial membrane that can drive transport
  - Chemical bonds from food are broken and energy is released, creating an electron gradient
  - The gradient powers the phosphorylation of ADP (putting a phosphate group onto the ADP), creating ATP
- Voltage is an energy potential gradient created by disproportionate placement of electrons (across the membrane)
- The ability to keep a difference in charge across the membrane powers the “work”

> “And so you could have an electromotive force. You could have proton motive force. And then you can dissipate that battery to basically catalyze the formation of ATP, which most people know is the energy form that used to power muscle when you exercise. So the mitochondrion is doing all of these elaborate energy transformations from electrical potentials to proton potentials to phosphorylation potentials and different enzymes and processes and machines in your cells will use one or the other”

![](https://peterattiamd.com/wp-content/uploads/2019/08/fig-6-revised-1024x650.png)

**Figure 6. The enthalpy is the energy required to break a chemical bond expressed in units as kJ mol-1.** Image credit: [kentchemistry.com](https://www.kentchemistry.com/links/Kinetics/BondEnergy.htm)

## NAD and NADH: Role in the mitochondria, decline of NAD levels with age, and what it means to age at a mitochondrial level [51:30]

![](https://peterattiamd.com/wp-content/uploads/2019/08/vamsi-figure-7.png)

**Figure 7. The oxidized form of the electron carrier (NAD+) is shown on the left and the reduced form (NADH) is shown on the right. The nitrogenous base in NADH has one more hydrogen ion and two more electrons than in NAD+** **.** Image credit: [lumenlearning.com](https://courses.lumenlearning.com/ivytech-bio1-1/chapter/reading-electrons-and-energy/)

- The classical teaching is that NAD is the oxidized form (without two electrons) electron carrier
- When NAD has two electrons it will be in NADH form – holding energy that can catalyze reactions
  - Electrons are transferred from NADH to the electron transport chain that “conducts” the electron until they hit oxygen and make water
  - During that process, protons are pumped across the inner mitochondrial membrane generating about 150 MV that can be used to do work – including catalyzing conversion of ADP to ATP ([oxidative phosphorylation](https://en.wikipedia.org/wiki/Oxidative_phosphorylation))

![](https://peterattiamd.com/wp-content/uploads/2019/08/vamsi-figure-8-1024x680.png)

**Figure 8. The energy released as electrons are pumped through the electron transport chain is used to pump protons out of the mitochondrial matrix. The electrochemical gradient formed is the electromotive force that drives ATP synthesis, or oxidative phosphorylation.** Image credit: [khanacademy.org](https://www.khanacademy.org/science/biology/cellular-respiration-and-fermentation/intro-to-cellular-respiration/a/intro-to-cellular-respiration-and-redox)

- In addition to the role of NAD as an electron carrier,  the **NAD molecule can also be used as a substrate for other reactions**
  - NAD as a cofactor is used by sirtuins and PARPs in the DNA damage response pathways
  - If there is a cell with damaged DNA, the NAD can decline rapidly
  - NAD is an electron carrier, the cell’s ability to carry charge degrades

**What does it mean to age at a mitochondrial level?**

- NAD levels decline with age and elicits some key questions:
  - *Is that due to greater demand for it?*

- - Is that due to reduction in (NAD) production?

- - And the clinical question is if there is any benefit to replacing it?

- Comparing a muscle biopsy of individuals of various ages, there will be a gradual decline as a function of age in:
  - NAD content
  - quantity of mitochondria
  - the VO2 max of skeletal muscle
- The big question in the field is: *does “old and sick” tissue mean “sick” mitochondria, or will targeting the mitochondria actually somehow alleviate age-associated decline in tissue function?*

## Mitochondrial diseases Vamsi studies in his lab [55:15]

- His lab studies rare inborn errors of mitochondrial metabolism; typically single gene disorders of a mitochondrion that is defective at birth due to:
  - Recessive mutations in the nuclear genome
  - Mutations in the mitochondrial genome
- There are about 300 mitogenic disorders of the mitochondria and he studies the consequences of these mutations
- The phenotypic spectrum of these mutations follow a bimodal distribution:
  - Recessive mutations in the nuclear genome – where Vamsi’s lab spends more time – present early in infancy and are more severe
  - Mutations in the mitochondrial genome present a bit later life

**Example:** [**Leigh syndrome**](https://en.wikipedia.org/wiki/Leigh_syndrome)

- There are about 80 different genes that can be mutated to give rise to the syndrome
- A subacute degeneration of gray matter – rapid neurodegeneration
- Most children are born developmentally okay and within the first couple of months of life contract a stressor that will put them into a neurometabolic crisis
- MRI scans reveal lesions in the brainstem, brainstem, spinal cord, which corresponding to legions of necrosis
- The community of researchers studying the disease are looking to identify what it is about the broken mitochondria that gives rise to the  aforementioned phenotype
- Genes in the nuclear genome have been mapped – some of which are in the mtDNA – but there is not yet a clear answer
- One possible similarity that Peter puts forth: other forms of neurodegeneration, such as [Alzheimer’s disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease), have been recently argued to be neuronal energy crises
- Mitochondrial disorders impact almost any organ system and Leigh syndrome represents one type of clinical manifestation of a mitochondrial disease
  - Another set of disorders impact the skeletal muscle
  - It is not clear why mutations in one subunit of the electron transport chain gives rise to brain disease while mutation in a neighboring subunit in the same complex gives rise to muscle disease.
- Patients need new treatments and therapies but there are also mutations, of which the study will inform more common forms of aging (the link between mitochondrial decline and aging)

## Mitochondria and oxygen: Poor oxygen utilization and excess oxygen contributes to the pathology seen in some of the rare mitogenic diseases [1:02:00]

- When mitochondria and oxygen are discussed, [ROS](https://en.wikipedia.org/wiki/Reactive_oxygen_species) signaling commonly comes to mind
  - mitochondria are an important source of ROS – an essential signaling molecule

⇒ For more on reactive oxygen species (ROS) check out a [previous episode of The Drive with Nav Chandel](https://peterattiamd.com/navchandel/) (specifically starting at 20:00)

- The “dogma” is that when the “powerhouse” of the cell is “broken,” the pathogenesis equates to not enough ATP produced inside of the cell
- But, in addition to producing ATP, the mitochondria also **consume oxygen**
- In fact, most of the oxygen in a cell is consumed by the mitochondria
  - When a patient has a birth defect of the mitochondria, in addition to not being able to produce sufficient ATP, they also have **excess oxygen**
  - Oxygen delivery to the cell is typically not a problem but the *oxygen utilization* is poor

*How does oxygen even get to the mitochondria?*

![](https://peterattiamd.com/wp-content/uploads/2019/08/vamsi-figure-9.png)

**Figure 9. Oxygen transport**. Image credit: [harvard.edu](https://sitn.hms.harvard.edu/flash/2012/issue121/)

- Oxygen is not water soluble so carrier protein hemoglobin, found in red blood cells, get “loaded” with oxygen in the lungs
- From the lungs, the red blood cells get delivered to peripheral tissues and oxygen gets extracted from the fluid (mostly by diffusion and hemoglobin will “offload” its oxygen)
- Diffusion mechanistically carriers oxygen into the cell from the surrounding fluid
- Once inside the cytoplasm, the utilization of oxygen by the mitochondria inside a cell creates something like a vacuum, like a sink. This is why there is an oxygen gradient in the cell
- In certain skeletal tissues, like skeletal muscle and the heart, there are oxygen carriers like [myoglobin](https://en.wikipedia.org/wiki/Myoglobin)
- The final pathway of the electron transport chain utilizes oxygen to generate water and CO2 which have to exit the mitochondria and out of the cell

**Mitochondrial pathogenesis**:

- It may not be just about ATP production… it’s also about excess, unused oxygen
- One of the consequences of mitochondrial dysfunction is excess, unused oxygen
- If a mitochondrion is failing to do its job, oxygen utilization will be failing
- They hypothesis is that some of the excess, unused oxygen contributes to the pathology seen in some of the rare mitogenic diseases
  - [Dioxygen toxicity](https://chem.libretexts.org/Bookshelves/Inorganic_Chemistry/Book%3A_Bioinorganic_Chemistry_(Bertini_et_al.)/5%3A_Dioxygen_Reactions/Dioxygen_Toxicity)
  - Hypothesis: Enzymes are programed to operate within an oxygen range inside of the cell. When the mitochondrion is not functioning properly and oxidation levels rise, and the excess dioxygen can oxidize and damage enzymes
- In people with mitochondrial disorder, in which oxygen is not efficiently utilized, there is not a correction in gradient pressure, or sink, toward the mitochondrion in a cell
- To diagnose patients, [Ron Haller](https://profiles.utsouthwestern.edu/profile/12906/ronald-haller.html) has proposed measuring oxygen extraction to look for patients with high venous oxygen

## What VO2 max can tell us about mitochondrial function, insulin resistance, type 2 diabetes, and more [1:10:00]

- On a treadmill, in order to stress the system, two things would be measured
  - The amount of oxygen going in
  - The concentration of oxygen coming out
  - The difference is the extraction (of oxygen)
- Although Vamsi’s lab does not do [VO2 max](https://en.wikipedia.org/wiki/VO2_max) studies, Ron Haller will use such a physiological study to look at cardiac output as well as the oxygen tensions on the arterial and venous sides
  - Assessment of an oxygen mass balance:
    - Can quantify the number of O2 molecules – being delivered, extracted as well as returned to the venous system
- For patients with inherited mitochondrial disease, cardiac output is high and oxygen extraction is low
  - Ron Haller would suggest that high oxygen venous levels in conjunction with high lactate levels (oxygen is low so pyruvate gets converted to lactate rather than Acetyl-CoA) is suggestive of a mitochondrial myopathy
- In a healthy individual, oxygen will be delivered to the system as needed: the system adapts to oxygen extraction

**Mitochondrial Myopathy Hypothesis for type 2 diabetes**

- [Iñigo San Millán](https://www.ucdenver.edu/academics/colleges/medicine/sportsmed/cusm_physicians/Pages/sanmillan.aspx) (researcher at the U of Colorado) is looking at type 2 diabetes as an early indicator of mitochondrial myopathy
- [In early states of insulin resistance the muscle becomes inefficient at oxidative phosphorylation](https://escholarship.org/content/qt5cz1v976/qt5cz1v976.pdf) (marked by high levels of resting lactate)

A series of papers in early 2000s ([1](https://mootha.med.harvard.edu/PubPDFs/MoothaNatGen2003.pdf),[2](https://mootha.med.harvard.edu/PubPDFs/MoothaPNAS2004.pdf),[3](https://www.ncbi.nlm.nih.gov/pubmed/16284649))

- Demonstrated that skeletal muscles from individuals with prediabetes, as well as biopsies of healthy individuals with a family history of diabetes, have a reduced number of mitochondria
- 1000 genes required for mitochondria are suppressed as an entire pathway (not any one gene)
- Vo2 max for these individuals is also low

\*It is still not clear if mitochondrial dysfunction is causal for diabetes or if it is an early, secondary symptom  that precedes mitochondria gene expression

**Explaining Mendelian randomization**

- There is a [mendelian randomization](https://en.wikipedia.org/wiki/Mendelian_randomization) that takes place at birth
- Population variation associated with a particular marker can be turned into a bell curve, based on population genetics. For example LDL-C levels and cardiovascular disease

![](https://peterattiamd.com/wp-content/uploads/2019/08/vamsi-figure-10-1024x524.png)

**Figure 10. Comparison of a Mendelian Randomisation study and a conventional trial. If genetic variants that either alter the level of, or imitate the biological effects of, a modifiable biomarker that is causal in disease, then these genetic variants should also be associated with disease risk to the extent predicted by the effect of the genetic variant with the biomarker.** Image credit: [heart.bmj.com](https://heart.bmj.com/content/103/18/1400)

- This method requires caution when asserting correlation
  - Genes under investigation could control something else related to the disease that could have a counterbalancing effect
  - What is called [reverse causation](https://www.pritikin.com/what-is-reverse-causation)
- Methods like mendelian randomization are becoming viable to answer cause-effect pathways of mitochondrial function but requires heavily genotyped individuals biomarkers for mitochondrial function

## Can studying mitochondrial disease provide insights into the common forms of aging?  [1:18:45]

**Rare genetic disorders reveal pathology pathogenesis of the organelle that can potentially be applied to common aging phenomena**

- Implications of understanding mitochondrial disease pathway (e.g., whether it directly causes conditions like type 2 diabetes or if there is a predetermining factor upstream of mitochondrial gene expression) are significant both for chronic and risk reduction of chronic disease
- The mitochondrion is a highly reactive organelle: if other processes in the cell fail then the mitochondrion is also at risk for failing
- The big question in the field of rare mitogenetic disorders: *which forms of the pathogenesis bears any relevance to the common aging process?*
  - The 300 different forms of monogenic mitochondrial disease are terrible diseases for which therapies are needed
  - there is also a hope that some of them may bear some relevance to the common form of aging

## Could muscle cell inflammation (a signature of aging) be caused by mtDNA damage being confused as foreign bacteria? [1:22:00]

- Another signature of time is inflammation within muscle cells
  - Muscles become more inflamed as they age
- *What is drawing inflammatory cells into muscle as we age?*
- - A [recent paper](https://nature.com/articles/s41586-018-0287-8) used [STING pathway](https://en.wikipedia.org/wiki/Stimulator_of_interferon_genes) to block the ability of a cell to sense breakdown in nucleic acid

![](https://peterattiamd.com/wp-content/uploads/2019/08/figure-11-revised-1024x794.png)

**Figure 11. Mitochondria as regulators of innate immune response.** Image credit: ([Sun et al., 2016](https://www.sciencedirect.com/science/article/pii/S1097276516000812#fig4))

- - The hypothesis:
    - mtDNA is bacterial in origin and a loose fragment of bacterial DNA in a cell would produce an immunogenic reaction (the immune system interpreting the mtDNA is foreign)
    - With increased mitochondrial damage in a cell results in elevated exposure of the mtDNA, eliciting an immunogenic response
  - To test the hypothesis, STING pathway was utilized – blocking the ability of a cell to sense general nucleic acid (independent of nuclear or mitochondrial origins)
- [Another study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2843437/) finding supported inflammation in response to mtDNA and formulated peptides
  - Fractionation identified that sterile crush injury (in which skin is not broken but there is a massive inflammatory response) inflammation was in response to mitochondrial derived molecules

**Protein Translation: Eukaryotes and Bacteria**

- In eukaryotes, protein translation begins with methionine residue
- In bacteria it is a modified molecule called [formylmethionine](https://en.wikipedia.org/wiki/N-Formylmethionine)
  - it is a signature of a bacterial derived protein
  - mitochondria, with bacterial origins, have 13 proteins that begin with formylmethionine
- Humans have receptors to detect formulated peptides as a screen for infection
  - If mtDNA remains in the mitochondrion, they are protected from immune-detection and response
  - In certain injuries mtDNA can escape and incite an inflammatory response
  - In the two examples – either by mitochondrial damage or acute injury – there is an inflammatory response due to the exposure of mtDNA, interpreted by the immune system as bacterial

## Exercise and mitochondrial health: Is there an optimal exercise strategy to slow the aging process? [1:27:00]

*If the aging inflammatory phenotype is not beneficial, could preventing or rejuvenating broken mitochondria slow the aging process?*

- Exercise is one of the best ways to turn over bad mitochondria and induce mitochondrial biogenesis
- But exercise does a lot of things, so positive mitochondrial impact does not adequately answer the aging-mitochondrial health relationship

**Is there an optimal exercise strategy for mitochondrial health?**

*At the center of the optimal exercise question is understanding the role of exercise in mitochondrial health*

- Three types of (loose) exercise buckets being

1. strength training
2. aerobic training requiring maximum mitochondrial output with minimal generation of lactate
3. anaerobic training that demands ATP and favors the lactate production pathway

More about exercise…

- Each form of exercise are beneficial but it is hard to differentiate cardiometabolic benefit versus protective due to other factors associated with a given age profile (frailty, for example, in older age guarded against with weight-bearing exercise)
- Quantity and quality of exercise also matters
- As it pertains to exercise, Peter is most interested in understanding how exercise can be optimally tailored, or prescribed, to impact all causes of mortality
- Although the proven relationship is not yet clear, there are predicted non-linear dynamics of mitochondria as a function of both age and exercise
  - Suspending use of skeletal muscle leads to lean mass and mitochondria loss:
  - Measurable VO2 max degradation after 10 days of hospitalized bed rest, which takes about six weeks to recover
- The programs that turn on mitochondria during exercise are elaborate
  - 17 different inputs into the system through exercise may all be necessary, with the right dynamics, and the right off rates to induce mitobiogenesis
  - The [ragged-red fiber](https://medcell.med.yale.edu/histology/cell_lab/red_ragged_fibers.php) of muscle disorders represents an accumulation of poorly functioning mitochondria
    - Only a two to three of necessary inputs may be adequate to produce more malfunctioning mitochondria, but all 17 inputs may be necessary to produce healthy mitochondria
- The [PGC-1 alpha program](https://jcs.biologists.org/content/125/21/4963) turns on mitochondrial biogenesis while simultaneously turns on [autophagy](https://en.wikipedia.org/wiki/Mitophagy) programs – turning over bad mitochondria while creating more healthy mitochondria
- Many diseases are ultimately reduced by exercise

## What autophagy means in the context of mitochondria [1:36:15]

- With proper exercise regimes, there have been observed transcriptional programs with multiple inputs that will turn on all 1,000 proteins to produce more mitochondria and induce old mitochondrial turnover
- Supporting the complicated dynamics of mitobiogenesis, [a study](https://www.ncbi.nlm.nih.gov/pubmed/19433800) finding revealed that antioxidants in conjunction with exercise erases some of the beneficial effects of exercise
  - The study concluded that ROS play an important role in mitobiogenesis signaling and also turning over old mitochondria that are not beneficial
  - Similarly, and as discussed with [Nav Chandel](https://www.chandellab.com/), ROS plays an important role in selectively targeting a cancer cell, so blocking ROS with antioxidants in a cancer patient would be detrimental

## Metformin’s impact on exercise and lactate levels [1:40:15]

- As discussed with [Nir Barzilai](https://www.einstein.yu.edu/faculty/484/nir-barzilai/),individuals with diabetes and also those who are insulin resistant are benefited by metformin
- Nir’s work with [TAME](https://www.afar.org/research/TAME/) looks at the effect of taking metformin on non-diabetic, non-insulin resistant individuals

⇒ For more on TAME check out a [previous episode of The Drive with Nir Barzilai](https://peterattiamd.com/nirbarzilai/) (specifically starting at 57:00)

- Peter self-experiments to observe the effects of metformin on exercise
  - His [lactate performance curve (LPC)](https://www.lactate.com/pitesbas.html) comparison reveals higher lactate levels when on metformin
  - His resting lactate level on Metformin also increased
  - Hypothesis for increased lactate
    - Metformin inhibits complex one, the body may preferentially opt against shuttling pyruvate into the mitochondria, disproportionately keeping pyruvate outside of the organelle and turning it into lactate
  - Rather than using blood in the finger to measure lactate, Vamsi suggests [metabolics](https://en.wikipedia.org/wiki/Metabolomics)
  - The next comparison to observe is what metformin does to lactate level performance in a diabetic or insulin resistant individual compared to their baseline

![](https://peterattiamd.com/wp-content/uploads/2019/08/vamsi-figure-12.png)

**Figure 12. An example of a lactate performance curve**. Image credit: [lactate.com](https://www.lactate.com/pitesbas.html)

- Vamsi published [a study](https://www.pnas.org/content/early/2017/07/12/1703338114.abstract) of healthy individuals and patients with mitochondrial disease who did an exercise test on a treadmill
  - The study compared resting, peak, and recovery metabolomic response to the exercise
  - The mitochondrial disease patients began with a high resting lactate and displayed, in response to and post exercise, a parallel rise in lactate levels seen in healthy individuals
  - The study could be replicated to compare impaired complex one deficiency patient group as a result of taking Metformin, rather than having complex one inhibition due to mitochondrial dysfunction

## How might metformin confer longevity benefits? [1:48:15]

- When [Complex I](https://en.wikipedia.org/wiki/Electron_transport_chain#Complex_I) is blocked, the body senses it and there is a homeostatic response
- Blocking the Complex may turn on 15 of the 17 inputs needed to induce mitobiogenesis and other parts of the cell as well
- Experiments ([1](https://www.ncbi.nlm.nih.gov/pubmed/16103914),[2](https://www.ncbi.nlm.nih.gov/pubmed/22829775),[3](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3062502/)) in worms did RNAi screens to look for genes that would lead to a longevity phenotype when disrupted
  - One of the gene sets most associated with a longevity phenotype was the mitochondrial electron transport chain
  - However, one of the gene sets associated with a reduced lifespan was the mitochondria electron transport chain
  - The subsets were distinct – 90 genes total are required for the electron transport chain and oxidative phosphorylation

*Why do the loss of some genes lead to longevity and others lead to decreased lifespan?*

- One hypothesis has to do with the strength of the allele: gently blocking the ETC (as metformin may do) rather than significantly inhibiting the ETC encoding
- metformin may block the ETC such that it elicits a homeostatic response that is net adaptive
- Vamsi submits that metformin is beneficial for a subset of the population who have type 2 diabetes
- There are rare cases with drugs related to metformin, like Phenoformin, that can result in fatal lactic acidosis
- An experiment evaluating the cross product of exercise and metformin – like that similar to the [Ron Kahn](https://projects.iq.harvard.edu/kahnlaboratory/people) [study](https://projects.iq.harvard.edu/kahnlaboratory/publications/coordinated-reduction-genes-oxidative-metabolism-humans-insulin) – would help inform whether the addition of metformin offers incremental benefit or counteracts the benefit of optimized exercise, sleep, and nutrition\

## Hypoxia as a potential therapeutic option for mitochondrial disease [1:52:45]

- There have been observations where too much oxygen can be damaging
- In some rare mitochondrial disorders studied
  - ATP levels are defended by glycolysis (i.e., not a disorder of energy deficiency)
  - there are high levels of unused oxygen observed (despite high energy output a high level of oxygen returns to the lungs)
- Vamsi’s lab now investigates ways to limit or reduce the delivery of oxygen
  - Using hypoxia chambers in mouse model studies in which air is diluted with nitrogen (21% oxygen reduced to 11%)
  - In some of the models with mitochondrial disease there has been a measured benefit
  - In an example:
    - [A mouse model with Leigh syndrome](https://www.pnas.org/content/114/21/E4241#ref-11) (a recessive loss of one of the nuclear subunits of Complex I) has an archetype disease process observed
      - Mouse is born looking healthy
      - Within 30-35 days begins to display symptoms
      - By day 55, among other symptoms, it has lesions on the brain MRI and the initial cause of death is probably brain driven, although other tissues are also affected
    - If the mice were grown at 11% rather than 21%, they survive to a median of one year (half of their normal, 2-year lifespan) and looked well
- Previously, hyperbaric oxygen has been proposed as a treatment for mitochondrial rejuvenation
  - Vamsi’s lab [experimented](https://science.sciencemag.org/content/352/6281/54?ijkey=9f28b6e3de0ce50cdc7475f78f20720ba9c94cd5&keytype2=tf_ipsecsha) with hyperoxia conditions as well
    - 55% oxygen conditions, as is the saturation in an operating room
    - The mice with Leigh Syndrome die within a few days of exposure
  - There have been some anecdotes that suggest high oxygen levels on a broken electron transport chain can be very damaging, in line with the experimental findings in mice

> “I think there’s some anecdotes that suggest that super high oxygen levels on a broken electron transport chain can be very damaging in humans.”

## Cancer prevention and treatment: hyperbaric oxygen chambers, targeting single carbon metabolism of the mitochondria, and more [2:00:00]

- There is a subset of tumors – where there may be mitochondrial mutations to begin with – for which Vamsi’s lab is exploring hyperoxic exposure
- Hyperbaric oxygen has been proposed as a cancer therapy in the past
  - there have been mixed signals of efficacy
  - It may be that with precise targeting, (based on mitochondria markers) hyperbaric oxygen can be effectively used for certain cancer treatments

⇒ For more on targeted cancer treatment check out a [previous episode of The Drive with Keith Flaherty](https://peterattiamd.com/keithflaherty/) (specifically starting at 1:12:00)

**Other learnings that could be applied to cancer prevention or treatment**

- A series of projects in Vamsi’s lab took data sets from cancers to see which metabolic pathways were consistently altered
  - There are about 1500 metabolic enzymes in the human genome
  - Revealed a few mitochondrial enzymes in the [folate pathways](https://www.researchgate.net/figure/Simplified-overview-of-folate-metabolism-pathway-highlighting-enzymes-with-polymorphisms_fig1_236207511) that are consistently [upregulated](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4106362/) across all cancers (also found to be the case in research conducted by [David Sabbitini](https://sabatinilab.wi.mit.edu/), [Josh Rabbinowitz](https://scholar.princeton.edu/rabinowitz))
    - Suggests that mitochondria are not being utilized for energy in cancer but acts as biosynthetic machines for cancer
    - [Findings](https://science.sciencemag.org/content/324/5930/1029) consistent with the hypothesis that the [Warburg effect](https://en.wikipedia.org/wiki/Warburg_effect) is the result of a cancer cell favoring a throughput of substrate rather than an inability to undergo oxidative phosphorylation
- It is an open ended question if targeting single carbon metabolism of the mitochondria will be beneficial in cancer treatment, but it is an upregulated pathway in cancer states

![](https://peterattiamd.com/wp-content/uploads/2019/08/vamsi-figure-13-1024x690.png)

**Figure 13. Cancer cells preferentially undergo glycolysis rather than Oxphos (e.g., The Warburg Effect)** Image Credit: [Medium](about:blank)

## Chronic diseases have altered mitochondria: Evidence for mitochondrial dysfunction causing Parkinson’s Disease  [2:04:30]

- Not clear if dysfunctional mitochondria is the cause or part of the disease effect
- Systems biology and insights taken from rare disease research may inform a subset of chronic disease understanding
- The causal hypothesis for [Parkinson’s Disease](https://www.mayoclinic.org/diseases-conditions/parkinsons-disease/symptoms-causes/syc-20376055) is particularly compelling
  - The pathology of rare monogenic mitochondrial disease resembles molecular features of mitochondrial dysfunction seen in Parkinson’s Disease
  - In some Parkinson’s Disease cases, the root cause is mitochondrial toxicity that results in dopamine loss (via herbicide or insecticide exposure, which are toxic to Complex I)
- Evidence for direct toxicity to mitochondria in humans can give rise to Parkinson-like disease phenotype
- Mouse models given a high does of [rotenone](https://en.wikipedia.org/wiki/Rotenone) – a Complex I poison – has been used as a model for Parkinson’s Disease

## Why Vamsi is very optimistic about the possibility of targeting mitochondrial proteins as therapies [2:09:30]

- In the laboratory, mitochondrial disease can be alleviated in a preclinical way using hypoxia
- Another preclinical approach uses [protein prosthesis](https://pubs.acs.org/doi/10.1021/ja026114n)
  - proteins from other organisms are transplanted into human cells (ex-vivo) with mitochondrial disease and effectively rescue the cells
- As a result of reductive evolution, certain organisms lost parts of their ETC and others, their entire ETC
- One way organisms who have lost their entire ETC may be able to survive is because they gained a new protein in replacement
- These isolated proteins placed in a human cell can poison the mitochondria in five different ways but the cell will reproduce
  - Hypothesis that prosthesis corrects part of the redox imbalance but not the full proton pump capability of the ETC
  - Has potential to be used to either bypass or augment some broken functions of the mitochondria in disease like fatty liver and diabetes
- In addition to bypassing a mitochondrial malfunction, protein prosthesis could feasibly enhance mitochondrial function
- One drug [FG4592](https://en.wikipedia.org/wiki/Roxadustat) tricks the system into thinking it is hypoxic and thus produces more EPO

## Is it theoretically possible to genetically engineer a better functioning mitochondria? [2:14:30]

- In biology, it is easy to break a system by one think but it is hard to enhance it with one thing
- Drugs like statins, metformin, rapamycin all act on multiple “switches” at the same time that are net beneficial
- It is no coincidence that most effective, potent clinical agents, that involve such “multi-pronged” inputs within a system, come from naturally occurring substances
- Natural products are chemistries that have evolved over hundreds of millions of years to target physiological systems

## Vamsi’s fantasy experiment in an unconstrained world [2:20:15]

Context

- One possible experiment would be motivated by his lab’s recent work on oxygen and mitochondrial dysfunction
- In preclinical models, oxygen depleted air seems to be beneficial
- In normal aging, when there is a subtle decline in mitochondrial activity, *is there excess oxygen and would breathing thinner air be beneficial*?

Experimental Design

- Crossover study with two treatment groups at different elevation
- large participant cohort
- Treatment length in the order of months to years
- Compare biomarkers of aging and age associated disorders
- To test the idea that thin air might be beneficial for chronic disease

This type of natural experiment has actually been reported in [one paper from the early 1970s](https://www.ncbi.nlm.nih.gov/pubmed/334677/), published by the Indian army

- The study reported on health outcomes of more than 100,000 troops deployed to the Indo-China border
- One group was at extremely high altitude and another group was not for a number of years
- Although other parameters – such as food, temperature, activity – were not controlled for, the altitudes and therefore oxygen saturation between the two locations were different
- Health consequences
  - Death from infection were much higher at altitude
  - Chronic diseases were reduced during the time living at altitude

§

## Selected Links / Related Material

**Vamsi is a lead investigator and part of a research group of clinicians, computer scientists, and biologists, who work collaboratively**: [The Broad Institute](https://www.broadinstitute.org/) | (broadinstitute.org) [8:00]

**Identifying and mapping all genes in the human genome, completed in 2003:** [The Human Genome Sequencing Project](https://www.genome.gov/human-genome-project) | (www.genome.gov/human-genome-project) [8:00]

**Vamsi’s primary appointment:** [Mass General Hospital](https://www.massgeneral.org/) and [Howard Hughes Medical Institute](https://www.hhmi.org/)  |  (www.massgeneral.org/) (www.hhmi.org/) [9:30]

**Vamsi did his undergraduate degree in Mathematical and Computational Science:** [Stanford University](https://www.stanford.edu/) |  (www.stanford.edu/)[10:30]

**Vamsi applied to the Harvard-MIT program in Health Sciences and Technology:** [HST](https://meded.hms.harvard.edu/health-sciences-technology) Program  |  (meded.hms.harvard.edu) [12:15]

**Pencil brand mentioned by Vamsi and Peter:** [Dixon Ticonderoga number two pencils](https://www.amazon.com/Ticonderoga-Wood-Cased-Graphite-Pencils-13872/dp/B00125Q75Y)  |  (amazon.com) [15:15]

**An organelle found in most eukaryotic organisms:** [Mitochondria](https://en.wikipedia.org/wiki/Mitochondrion) | (wikipedia.org/) [19:30]

**Theory of the origin of eukaryotic cell from prokaryotic organisms:** [Endosymbiosis](https://en.wikipedia.org/wiki/Symbiogenesis) | (wikipedia.org/) [23:30; 25:30; 26:00]

**In the Endosymbiotic Theory, a bacteria organism resembling a modern gram-negative rod (a bacteria shaped like a rod that is gram-negatively stained for identification) that merged with a modern-day archaea species:** [Gram-negative rods](https://en.wikipedia.org/wiki/Gram-negative_bacteria) | (wikipedia.org) [23:30]

**Gram-negative bacteria species:** [Rickettia Species](https://en.wikipedia.org/wiki/Rickettsia) | (wikipedia.org) [23:30]

**Prior to endosymbiosis, bacteria were capable of aerobic metabolism using oxygen as a terminal electron acceptor:** [Cellular Respiration](https://en.wikipedia.org/wiki/Cellular_respiration) | (wikipedia.org)  [24:00]

**Three domains of life:** [Archaea, Bacteria, Eukaryote](https://en.wikipedia.org/wiki/Domain_(biology)) | (wikipedia.org)  [24:00]

**A series of redox reactions in complexes across the mitochondrial membrane that transfer electrons from donors to acceptors, along with the transfer of protons, driving the synthesis of ATP:** [Electron Transport Chain](https://en.wikipedia.org/wiki/Electron_transport_chain)  | (wikipedia.org) [24:00; 44:45; 52:30; 1:00:30; 1:49:15; 1:50:15; 1:50:45; 1:51:30; 1:59:15; 2:11:00; 2:11:15; 2:12:00]

**The site of photosynthesis, by which the plant organelle converts energy from sunlight to chemical energy in the form of ATP and NADH:** [Chloroplast](https://en.wikipedia.org/wiki/Chloroplast) | (wikipedia.org)  [26:15]

**Example of a one-celled parasitic species that has lost  its mitochondrial DNA altogether:** [Giardia](https://www.mayoclinic.org/diseases-conditions/giardia-infection/symptoms-causes/syc-20372786) | (mayoclinic.org) [28:30]

**The modern mitochondrial genome is the product of loss of genes rendered non-essential:** [Reductive Evolution](https://www.oxfordreference.com/view/10.1093/oi/authority.20110803100409663)  | (oxfordreference.com) [27:15; 27:30; 2:11:00]

**A bias related to sampling and selection biases, in which data collected has inherent skew. In conversation, Vamsi notes that mitochondrial DNA as maternally inherited could be the result of**:  [Ascertainment Bias](https://catalogofbias.org/biases/ascertainment-bias/)  | (catalogofbias.org)  [30:00]

**The mitochondrial DNA was sequenced in 1981. The first two papers reporting on the first discovered mutations in the mitochondrial DNA were published in 1988:**

- **The first demonstration that heteroplasmic, large-scale rearrangements of the mitochondrial genome could cause human disease:** [Deletions of muscle mitochondrial DNA in patients with mitochondrial myopathies](https://www.ncbi.nlm.nih.gov/pubmed/2830540) (IJ Holt et al., 1988) [30:15]
- **This paper describes the first example of a single-nucleotide change in the mitochondrial genome (11778G>A) as the cause of a maternally inherited, neurological disorder in multiple families:** [Mitochondrial DNA mutation associated with Leber’s hereditary optic neuropathy](https://www.ncbi.nlm.nih.gov/pubmed/3201231) (DC Wallace et al., 1988) [30:15]

**Methods used to identify 1100 proteins made by the nuclear genome, which find their way into the mitochondrion:** [proteomics](https://en.wikipedia.org/wiki/Proteomics), [GFP tagging](https://en.wikipedia.org/wiki/Green_fluorescent_protein), [microscopy](https://en.wikipedia.org/wiki/Microscopy), [computation](https://en.wikipedia.org/wiki/Computation)  | (wikipedia.org) [31:45]

**One important signal that induces mitochondrial biogenesis:** [AMP Kinase](https://en.wikipedia.org/wiki/AMP-activated_protein_kinase)| (wikipedia.org)  [34:00]

**Cytosolic ATP/ADP ratio is a key feature that determines if cell metabolism is predominantly oxidative or glycolytic. This kinase is activated in response to ATP depletion, thereby positively regulating signalling pathways that replenish cellular ATP:** [ATP/ADP ratio in the AMPK cascade](https://www.cellsignal.com/contents/science-cst-pathways-cellular-metabolism/ampk-signaling/pathways-ampk)  | (cellsignal.com)   [34:00]

**Administration activates AMPK but that does not necessarily mean that mitochondrial density is altered:** [Metformin](https://en.wikipedia.org/wiki/Metformin) | (wikipedia.org)   [34:45]

**Vamsi’s 2005 study on how androgens and testosterone can influence mitochondrial density:** [Relationship Between Testosterone Levels, Insulin Sensitivity, and Mitochondrial Function in Men](https://mootha.med.harvard.edu/PubPDFs/Pitteloud2005.pdf) (Pitteloud, Mootha et al., 2005) [36:00]

**The NADH/NAD ratio is an electron carrier that can power certain types of enzymes. The ratio can also be converted to a gradient, or voltage, across the inner mitochondrial membrane that can drive transport:** [NAD/NADH](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide) | (wikipedia.org) [36:00; 46:15]

**Transcriptional regulator. In muscles, for instance, PGC-1α coactivates genes that promote glucose clearance and fiber-type switching and improves mitochondrial oxidative capacity:** [PGC-1alpha](https://en.wikipedia.org/wiki/PPARGC1A) | (wikipedia.org) [36:00]

**Upstream from PGC-1α is SIRT1 which uses NAD (participate as a substrate) as a cofactor:** [SIRT1](https://en.wikipedia.org/wiki/Sirtuin_1)  | (wikipedia.org) [36:00]

**The Drive episode which discussed the role of sirtuins and NAD in health and diseases:** #27 – [David Sinclair: Slowing aging – sirtuins, NAD, and the epigenetics of aging](https://peterattiamd.com/davidsinclair/) | Peter Attia (peterattiamd.com) [36:30; 53:00]

**New York Times Article mentioning Irisin:** [Brown fat, triggered by cold or exercise, may yield a key to weight control](https://www.nytimes.com/2012/01/25/health/brown-fat-burns-ordinary-fat-study-finds.html) | Gina Kolata, *New York Times* [37:00]

**The unfertilized egg is the “gold champion” of mtdna:** [Michael Phelps](https://en.wikipedia.org/wiki/Michael_Phelps)  | (wikipedia.org) [39:00]

**Mtdna in the unfertilized egg outnumbers paternal mtDNA in the sperm:** [Sexual dimorphism](https://en.wikipedia.org/wiki/Sexual_dimorphism) | (wikipedia.org) [41:15]

**Mitochondria from the sperm are coded with a protein, detected by a surveillance program for elimination upon fertilization:** [Ubiquitin](https://en.wikipedia.org/wiki/Ubiquitin) | (wikipedia.org) [41:45]

**Case published in the New England Journal of Medicine that reported on mtDNA molecules with two differential haplotypes, supporting paternal transmission of mtDNA:** [Paternal Inheritance of Mitochondrial DNA](https://www.nejm.org/doi/full/10.1056/NEJMoa020350) (Schwartz, Vissing., 2002)  [42:15]

**A paper reporting  mtDNA paternal transmission:** [Biparental Inheritance of Mitochondrial DNA in Humans](https://www.pnas.org/content/115/51/13039) (Luo et al., 2018) [42:45]

**The Drive episode which discussed whether antioxidants are helpful or harmful:** [#31 – Navdeep Chandel: metabolism, mitochondria, and metformin in health and disease](https://peterattiamd.com/navchandel/) | Peter Attia (peterattiamd.com) [44:30; 1:02:30]

**A metabolic pathway in cellular respiration that can occur with or without the presence of oxygen. Aerobic conditions produce pyruvate (anaerobic conditions produce lactate):** [Glycolysis](https://en.wikipedia.org/wiki/Glycolysis) | (wikipedia.org) [44:30]

**The branching point for either Fermentation or the Citric Acid Cycle:** [Pyruvate](https://en.wikipedia.org/wiki/Pyruvic_acid) | (wikipedia.org) [44:45]

**Electron transport and oxidative phosphorylation creates electromotive power. The electromotive force generated through proton transport provides the energy necessary for the fifth mitochondrial complex, the ATP synthase, to convert ADP to ATP:** [Electromotive force](https://www.dummies.com/education/science/biology/the-proton-motive-force/)  | (dummies.com)[46:15]

**One kind of electron carrier that shuttles electrons to the electron transport chain is NADH. The reactions in which NAD+ gain or lose electrons are examples of redox reactions. NADH is an electron carrier:**  [Redox Carrier](https://www.phschool.com/science/biology_place/biocoach/cellresp/closer2.html)  | (phschool.com) [52:30]

**A clinical syndrome of mitochondrial disease studied by Vamsi’s research group:** [Leigh Syndrome](https://en.wikipedia.org/wiki/Leigh_syndrome) | (wikipedia.org) [57:30; 58:45; 1:00:00; 1:02:45; 1:56:15]

**One example of a neurological degeneration disease that research is beginning to suggest is the result of neuronal energy crisis:** [Alzheimer’s Disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease) | (wikipedia.org) [59:00; 2:04:30; 2:06:45]

**Mitochondria are an important source of ROS; an essential signaling molecule:** [Reactive Oxygen Species (ROS)](https://en.wikipedia.org/wiki/Reactive_oxygen_species) | (wikipedia.org) [1:02:15]

**Oxygen Carrier:** [Myoglobin](https://en.wikipedia.org/wiki/Myoglobin) | (wikipedia.org) [1:05:30]

**A screening revealed that one of the consequences of mitochondrial dysfunction is excess, unused oxygen:**  [CRISPR](https://en.wikipedia.org/wiki/CRISPR) | (wikipedia.org) [1:07:00]

**If a mitochondrion fails to do its job, there will be oxygen accumulation, hypothesized to contribute to mitochondrial disease pathology:** [Dioxygen toxicity](https://chem.libretexts.org/Bookshelves/Inorganic_Chemistry/Book%3A_Bioinorganic_Chemistry_(Bertini_et_al.)/5%3A_Dioxygen_Reactions/Dioxygen_Toxicity) | (libretexts.org) [1:08:00]

**There is a gradual decline in VO2 max in skeletal muscle as a function of age. Relatedly, there’s this gradual decline in NAD and in mitochondrial activity as a function of age:** [VO2 Max](https://en.wikipedia.org/wiki/VO2_max)  | (wikipedia.org) [54:15; 1:10:00; 1:14:00; 1:33:30; 1:34:45]

**A series of papers reporting on skeletal muscle from pre-diabetics, and that of healthy individuals with a family history of prediabetes, that has a reduced number of mitochondrial gene expression, affecting VO2 max. This finding supports the mitochondrial hypothesis for Type 2 Diabetes:**

- [PGC-1α responsive genes involved in oxidative phosphorylation are coordinately downregulated in human diabetes](https://mootha.med.harvard.edu/PubPDFs/MoothaNatGen2003.pdf) (VK Mootha et al., 2003)  [1:13:30]
- [Errα and Gabpa/b specify PGC-1α dependent oxidative phosphorylation gene expression that is altered in diabetic muscle](https://mootha.med.harvard.edu/PubPDFs/MoothaPNAS2004.pdf) (VK Mootha et al., 2004)  [1:13:30]
- [Coordinated reduction of genes of oxidative metabolism in humans with insulin resistance and diabetes: Potential role of PGC1 and NRF1](https://projects.iq.harvard.edu/kahnlaboratory/publications/coordinated-reduction-genes-oxidative-metabolism-humans-insulin) (ME Patti et al., 2003)  [1:13:30]
- [Reduced mitochondrial density and increased IRS-1 serine phosphorylation in muscle of insulin-resistant offspring of type 2 diabetic parents](https://www.ncbi.nlm.nih.gov/pubmed/16284649) (K Morino et al., 2005)  [1:13:30]
- [Impaired mitochondrial activity in the insulin-resistant offspring of patients with type 2 diabetes](https://www.ncbi.nlm.nih.gov/pubmed/14960743) (KF Petersen et al., 2004) [1:13:30]

**Joslin Diabetes Center**: [Joslin Diabetes Center](https://www.joslin.org/) | (joslin.org) [1:13:30]

**Biopharmaceutical company mentioned in the context of David Alstchuler, on the leadership board:** [Vertex](https://www.vrtx.com/) | (vrtx.com) [1:13:30]

***Is a reduced number of mitochondria part of the causal path for diabetes onset or is there an upstream cause?*** **Current methods to inform the mitochondria dysfunction theory for Type II Diabetes is a current area of research:** [Mendelian Randomization](https://en.wikipedia.org/wiki/Mendelian_randomization) | (wikipedia.org) [1:15:15]

**Where the disease itself causes alterations in a biomarker:** [Reverse Causation](https://www.pritikin.com/what-is-reverse-causation)  | (pritikin.com) [1:18:15]

**Adaptor protein that is a central part of the recognition of bacterial and viral DNA as well as endogenous DNA (e.g., mitochondrial DNA)** : [STING (stimulator of interferon genes)](https://en.wikipedia.org/wiki/Stimulator_of_interferon_genes) | (wikipedia.org) [1:22:00]

**A metastudy review on how DNA damage trigger cGAS activation, serving as a link from DNA damage to inflammation:** [The cGAS–cGAMP–STING pathway connects DNA damage to inflammation, senescence, and cancer](https://jem.rupress.org/content/215/5/1287#ref-62) (Li and Chen, 2018)

**There was a paper that came out about a year ago that used STING to basically block the ability of a cell to sense breakdown in mitochondrial DNA**: [Parkin and PINK1 mitigate STING-induced inflammation](https://www.nature.com/articles/s41586-018-0448-9/) (Sliter et al., 2018) [1:22:00]

**Mitochondria as regulators of innate immune response**: [The Mitochondrial Basis of Aging](https://www.sciencedirect.com/science/article/pii/S1097276516000812#fig4) (Sun et al., 2016) [1:22:30]

**Study that found mitochondrial DAMPs (damage-associated molecular patterns), which include formyl peptides and mitochondrial DNA, activate an immune response due to the evolutionarily conserved similarities between the mitochondrial and bacterial molecular patterns:**  [Circulating Mitochondrial DAMPs Cause Inflammatory Responses to Injury](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2843437/) (Zhang et al., 2010) [1:22:30]

**Beth Israel Deaconess Medical Center:** [Beth Israel Deaconess](https://www.bidmc.org/)  | (bidmc.org)  [1:22:30]

**Bacterial protein translation doesn’t begin with a methionine. It begins with the formylmethionine:** [Prokaryotic translation](https://en.wikipedia.org/wiki/Prokaryotic_translation) | (wikipedia.org) [1:22:15]

**Amino acid that initiates prokaryotic protein translation:** [formylmethionine](https://en.wikipedia.org/wiki/N-Formylmethionine)  | (wikipedia.org)  [1:22:15; 1:25:15]

**A review article on mtdna damage in which components are released and act as danger signals when recognized by innate immune receptors:** [Mitochondria: An Organelle of Bacterial Origin Controlling Inflammation](https://www.frontiersin.org/articles/10.3389/fimmu.2018.00536/full) (Meyer et al., 2018)

**The non-linear dynamics of mitochondria as a function of age, as a function of exercise (e.g., VO2  max degradation following hospitalized bed rest, from which lost fitness requires more than six weeks to recover):** [Hysteresis](https://en.wikipedia.org/wiki/Hysteresis) | (wikipedia.org) [1:34:45]

**Represents an accumulation of poorly functioning mitochondria visually apparent with staining due to the accumulation of abnormal mitochondria below the plasma membrane of the muscle fiber:** [ragged-red fiber](https://medcell.med.yale.edu/histology/cell_lab/red_ragged_fibers.php) | (medcell.med.yale.edu) [1:35:30]

**Program for mitochondrial biogenesis and turnover (autophagy):** [PGC-1 alpha program](https://jcs.biologists.org/content/125/21/4963) | (jcs.biologists.org)  [1:36:00]

**Cell (e.g., mitochondrial turnover) -observation that exercise regimes turn-on, or induce,  transcriptional programs with multiple inputs to produce more and replace old mitochondria:** [mitophagy](https://en.wikipedia.org/wiki/Mitophagy) | (wikipedia.org)  [1:36:00]

**Antioxidants in addition to exercise voids beneficial effects of exercise; reactive oxygen species play an important signaling role:** [Antioxidants prevent health-promoting effects of physical exercise in humans](https://www.ncbi.nlm.nih.gov/pubmed/19433800) (M Ristow et al., 2009) [1:38:00]

**The Drive episode which discussed metformin, TAME study, and aging:** [#35 – Nir Barzilai: how to tame aging](https://peterattiamd.com/nirbarzilai/) | Peter Attia (peterattiamd.com) [1:40:45]

**Clinical trial that tests whether metformin can delay the onset of age-related diseases and conditions including cancer, cardiovascular disease and Alzheimer’s disease:** [Targeting Aging with Metformin (TAME)](https://www.afar.org/research/TAME/) | (afar.org)[1:40:45]

**Plot of blood lactate as a function of speed/effort:** [Lactate Performance Curve (LPC)](https://www.lactate.com/pitesbas.html) | (lactate.com) [1:42:30]

**Evaluating impact of metformin on the ability of exercise to improve the phenotype (Peter N(1) study):** [Metabolomics](https://en.wikipedia.org/wiki/Metabolomics)  | (wikipedia.org)  [1:43:15]

**Potentially inhibited by metformin; recessive loss of one of the nuclear subunits that gives rise to mitochondrial disease: Leigh Syndrome; evidence of herbicide poisoning that leads to Parkinson’s Disease:** [Complex 1](https://en.wikipedia.org/wiki/Electron_transport_chain#Complex_I)  | (wikipedia.org)  [1:48:15; 1:56:15; 2:07:00; 2:08:15]

**Vamsi’s paper using applied metabolic profiling to systematically interrogate mitochondrial disorders at rest and with exercise:** [Metabolic profiles of exercise in patients with McArdle disease or mitochondrial myopathy](https://www.pnas.org/content/early/2017/07/12/1703338114.abstract) (Delaney et al., 2017) [1:47:00]

 **RNAi screens to look for genes which when disrupted would lead to a longevity phenotype** [1:49:15]:

- [New genes tied to endocrine, metabolic, and dietary regulation of lifespan from a Caenorhabditis elegans genomic RNAi screen](https://www.ncbi.nlm.nih.gov/pubmed/16103914) (Hansen et al., 2005)
- [Induction of cytoprotective pathways is central to the extension of lifespan conferred by multiple longevity pathways](https://www.ncbi.nlm.nih.gov/pubmed/22829775) (DE Shore et al., 2012)
- [The Cell Non-Autonomous Nature of Electron Transport Chain-Mediated Longevity](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3062502/) (Durieux et al., 2011)

**Research and development company focused on the biology of aging:** [Calico](https://www.calicolabs.com/) | (calicolabs.com)  [1:49:15]

**Vamsi’s published studies on the therapeutic potentials of hypoxia in preventing mitochondrial disease**  [1:59:15]:

- [Hypoxia treatment reverses neurodegenerative disease in a mouse model of Leigh syndrome](https://www.pnas.org/content/114/21/E4241#ref-11) (Mootha et al., 2017)
- [Hypoxia as a therapy for mitochondrial disease](https://science.sciencemag.org/content/352/6281/54?ijkey=9f28b6e3de0ce50cdc7475f78f20720ba9c94cd5&keytype2=tf_ipsecsha) (Mootha et al., 2016)

**Mitochondrial enzymes in the folate pathway are consistently upregulated across all cancers:** [Metabolic enzyme expression highlights a key role for MTHFD2 and the mitochondrial folate pathway in cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4106362/) (Nilsson, Sheppard, et al., 2014) [2:01:45]

**Enzymes of the mitochondrial folate metabolic pathway, which are ordinarily low or absent in normal adult tissues, are highly upregulated in cancer:** [Folate Pathway](https://www.researchgate.net/figure/Simplified-overview-of-folate-metabolism-pathway-highlighting-enzymes-with-polymorphisms_fig1_236207511) | (researchgate.net) [2:01:45]

**Hypotheses that the Warburg effect is less a deficit of the cancer cell due to defective mitochondria or inability to undergo oxphos but the result of a cancer cell wanting to get a higher throughput of substrate to foster growth:** [Warburg Effect](https://en.wikipedia.org/wiki/Warburg_effect)  | (wikipedia.org)[2:03:00]

**Certain cancer-associated mutations enable cancer cells to acquire and metabolize nutrients in a manner conducive to proliferation rather than efficient ATP production**: [Understanding the Warburg effect: the metabolic requirements of cell proliferation](https://science.sciencemag.org/content/324/5930/1029) (Vander Heiden MG et al., 2009) [2:03:00]

**Dysfunctional mitochondria causal hypothesis:** [Parkinson’s Disease](https://www.mayoclinic.org/diseases-conditions/parkinsons-disease/symptoms-causes/syc-20376055) | (mayoclinic.org) [2:04:45; 2:07:00]

**STING pathway and the mitochondrial basis for parkinson’s disease**: [Parkin and PINK1 mitigate STING-induced inflammation](https://www.nature.com/articles/s41586-018-0448-9/) (Sliter et al., 2018) [2:07:30]

**Complex I poison used in mouse-models for Parkinson’s Disease process:** [Rotenone](https://en.wikipedia.org/wiki/Rotenone) | (wikipedia.org) [2:08:15]

**One preclinical approach uses protein prostheses where proteins from other organisms are transplanted into human cells (ex-vivo) with mitochondrial disease and effectively rescue the cells**: [Protein Prosthesis](https://pubs.acs.org/doi/10.1021/ja026114n)  | (pubs.acs.org)  [2:10:00; 2:12:45]

**In addition to bypassing a mitochondrial malfunction protein prostheses could feasibly enhance mitochondrial function by tricking the system into thinking it is hypoxic and thus, produces more EPO**: [Roxadustat (FG-4592)](https://en.wikipedia.org/wiki/Roxadustat) | (wikipedia.org) [2:13:15]

**Vamsi’s dream experiment is a model of a published paper from the early 1970s, published by the Indian army**:  [Effects of high altitude stay on the incidence of common diseases in man](https://www.ncbi.nlm.nih.gov/pubmed/334677/) (Singh et al., 1977) [2:24:15]

§

## People Mentioned

- [Eric Lander](https://www.broadinstitute.org/bios/eric-s-lander) (Founding Director of the Broad Institute of MIT and Harvard) [8:00]
- Venkataramana Rao (Vamsi’s father, a retired surgeon) [10:30]
- [Sam Karlin](https://en.wikipedia.org/wiki/Samuel_Karlin)  (American Mathematician who developed some of the underlying methods for biomolecular sequence analysis and whose work was introduced to Vamsi during his undergraduate degree research) [11:00]
- Vamsi’s cousin (hosted him for an evening, where Vamsi found a book on the mitochondria organelle) [21:15]
- [David Sinclair](https://genetics.med.harvard.edu/sinclair/people/sinclair.php) (previous guest on The Drive; Slowing aging – sirtuins, NAD, and the epigenetics of aging) | (genetics.med.harvard.edu)[36:30; 53:00]
- [Navdeep Chandel](https://www.chandellab.com/) (previous guest on The Drive, metabolism, mitochondria, and metformin in health and disease) [44:30; 1:02:30]
- [Ron Haller](https://profiles.utsouthwestern.edu/profile/12906/ronald-haller.html) ( of the University of Texas Southwestern Medical Center has proposed diagnosing patients with mitochondrial diseases in part by evaluating oxygen extraction on a treadmill. Patients with mitochondrial myopathies will often have high venous oxygen) [1:09:15; 1:11:15; 1:12:15]
- [Iñigo San Millán](https://www.ucdenver.edu/academics/colleges/medicine/sportsmed/cusm_physicians/Pages/sanmillan.aspx) (researcher looking at type 2 diabetes as an early indicator of mitochondrial myopathy) [1:12:30]
- [Leif Groop](https://www.ludc.lu.se/leif-groop-senior-professor) (Principal investigator at Genomics, Diabetes and Endocrinology;Director of Lund University Diabetes Centre)  [1:13:30]
- [David Altschuler](https://www.vrtx.com/leadership/david-altshuler-md-phd) (Co-Founder and Former Broad Institute Researcher now at Vertex) [1:13:30]
- [Ron Kahn](https://projects.iq.harvard.edu/kahnlaboratory/people) (Former President of The Joslin Diabetes Center) [1:13:30; 1:38:00; 1:52:13]
- [Gerald Shulman](https://medicine.yale.edu/bbs/people/gerald_shulman.profile) (Yale Researcher; Co-Director of the Yale Diabetes Research Center) [1:13:30]
- [Sreekumaran Nair, M.D., PH.D.](https://www.mayo.edu/research/faculty/nair-k-sreekumaran-m-d-ph-d/bio-00086363) (Mayo Clinic researcher focused on the role of energy metabolism and the importance of altered protein turnover in diabetes and aging) [1:13:30]
- [Michael Ristow](https://hest.ethz.ch/en/studies/health-sciences-and-technology/master-hst/majors/tutors/tutors-a-z/michael-ristow.html) (studies and reports on health-promoting effects associated with increased formation of reactive oxygenating species (ROS) within the mitochondria)  [1:38:00]
- [Nir Barzilai](https://www.einstein.yu.edu/faculty/484/nir-barzilai/) (previous guest on The Drive, genetics of longevity, metformin and the TAME study) [1:40:45]
- [Gary Ruvkun](https://molbio.mgh.harvard.edu/laboratories/ruvkun) (uses C. elegans molecular genetics and genomics to study miRNA and RNAi pathways) [1:49:15]
- [Cynthia Kenyon](https://www.calicolabs.com/cynthia-kenyon/) (Calico VP of of aging research; uses C. elegans model organism for her research on aging) [1:49:15]
- [Paul Attia](https://twitter.com/papaalphablog?lang=en) (Peter’s brother; Effect of Altitude anecdote) [1:55:30]
- [Keith Flaherty](https://www.dfhcc.harvard.edu/insider/member-detail/member/keith-t-flaherty-md/) (previous guest on The Drive; Deep dive into cancer— History of oncology, novel approaches to treatment, and the exciting and hopeful future ) | (harvard.edu)  [2:00:45]
- [Matt Vander Heiden](https://vanderheiden.scripts.mit.edu/) (cell metabolism research) [2:03:00]
- [Josh Rabinowitz](https://scholar.princeton.edu/rabinowitz) (utilizes metabolomics in studying cellular metabolism) [2:03:45]
- [David Sabatini](https://sabatinilab.wi.mit.edu/) (utilizes RNAI screening in studying cellular metabolism)  [2:03:45]

§

![](https://peterattiamd.com/wp-content/uploads/2019/08/bio-image-vamsi.jpg)

##### Vamsi Mootha, M.D.

Vamsi Mootha is an Investigator of the Howard Hughes Medical Institute and a Professor of Systems Biology and of Medicine at Harvard Medical School. His laboratory is based in the Department of Molecular Biology and Center for Genome Medicine at Massachusetts General Hospital. Dr. Mootha leads a research team dedicated to mitochondrial biology.

Dr. Mootha received his B.S. (with honors, with distinction) in Mathematical and Computational Science at Stanford University. He then received his M.D. (cum laude) from the Harvard-MIT Division of Health Sciences and Technology, where his thesis research focused on mitochondrial energetics. Following an internship and residency in Internal Medicine at Brigham and Women’s Hospital, he pursued postdoctoral training in genomics at the Whitehead Institute.

His research group consists of clinicians, computer scientists, and biologists, who work collaboratively to elucidate the network properties of mitochondria, and how these properties go awry in human disease. His work has led to the discovery of nearly 20 Mendelian disease genes, to the discovery that mitochondrial dysfunction is associated with the common form of type 2 diabetes mellitus, and to the discovery of all of the molecular components of the mitochondrial calcium uniporter.  His team has also developed generic, computational tools that have been widely used in biomedical research.

Dr. Mootha has received a number of honors, including a MacArthur Foundation Fellowship, the Judson Daland Prize of the American Philosophical Society, the Keilin Medal of the Biochemical Society, a Padma Shri from the Government of India, and election to the National Academy of Sciences. [[mootha.med.harvard.edu](https://mootha.med.harvard.edu/members_vm.html)]