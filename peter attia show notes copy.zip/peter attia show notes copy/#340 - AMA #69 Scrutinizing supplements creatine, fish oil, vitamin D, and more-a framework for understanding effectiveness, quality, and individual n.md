# #340 – AMA #69: Scrutinizing supplements: creatine, fish oil, vitamin D, and more—a framework for understanding effectiveness, quality, and individual need

**Source:** [https://peterattiamd.com/ama69/](https://peterattiamd.com/ama69/)

---

In this “Ask Me Anything” (AMA) episode, Peter explores the complex world of supplements by introducing a practical framework for evaluating their effectiveness and relevance to individual health needs. Rather than providing a simple list of recommendations, Peter aims to equip listeners with the tools to critically assess supplements on their own. He then applies this framework to discuss research on several popular supplements, including creatine, fish oil, vitamin D, B vitamins, and ashwagandha. Additionally, he covers key factors in assessing supplement quality, helping listeners develop a deeper understanding of how to make informed decisions based on their personal health goals.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #69 show notes page](https://peterattiamd.com/ama69). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Overview of episode topics [1:45];
- How Peter evaluates patients’ supplement regimens, and common misconceptions about supplements vs. pharmaceuticals [3:00];
- A framework for evaluating supplements [6:15];
- Evaluating creatine: purpose of supplementation, dosing, and mechanism of action [10:00];
- Creatine: proven benefits for muscle performance, potential cognitive benefits, and why women may benefit more [15:15];
- Creatine: risk vs. reward, kidney concerns, and choosing the right supplement [18:45];
- Evaluating fish oil: its primary purpose as a supplement and how to track levels [20:45];
- Fish oil: how omega-3s impact inflammation, heart health, and brain function, and the strengths and limitations of current research [26:30];
- Fish oil: the risks of supplementation, guidance on selecting high-quality products, and how to determine whether supplementation is appropriate [37:30];
- Evaluating vitamin D: understanding deficiency and optimal levels [45:15];
- Vitamin D: role in bone health, immune function, potential longevity impact, and biomarker limitations [51:15];
- Vitamin D: efficacy, safety, and balancing risk vs. reward [58:15];
- Evaluating B vitamins: function, consequences of deficiency, and key biomarkers to assess whether supplementation is necessary [1:02:15];
- B vitamins: risks for CVD and dementia associated with deficiency, and limited evidence for general population supplementation [1:07:15];
- Evaluating ashwagandha: background, uses, and mechanism of action [1:15:30];
- Ashwagandha: current evidence for its effects on sleep, stress, and anxiety [1:19:15];
- Ashwagandha: evaluating supplement quality, safety profile, and the risk-reward balance [1:22:15];
- The importance of using a structured evaluation framework to assess any supplement [1:26:30]; and
- More.

---

The Peter Attia Drive

#340 – AMA #69: Scrutinizing supplements: creatine, fish oil, vitamin D, and more—a framework for understanding effectiveness, quality, and individual need

---

## Show Notes


---

## Overview of episode topics [1:45]

**Main topic**: Supplements

- The challenge with the topic of supplements is that it’s so variable person to person – a variety of supplements and doses
- Today, Peter has instead decided to explain a framework for how one should think about supplements
- Additionally, Peter will go through case studies of a variety of supplements to talk through it and allow listeners to then be able to apply it in their own life
- Peter will go through case studies for:
  - Creatine
  - fish oil
  - vitamin D
  - B vitamins
  - ashwagandha

## How Peter evaluates patients’ supplement regimens, and common misconceptions about supplements vs. pharmaceuticals [3:00]

**Assessing Patients’ Supplement Use**

- When patients enter the practice, their full medical history is gathered, including:
  - Prescription medications
  - Over-the-counter supplements
  - Hormones
  - Any other exogenous molecules they consume
- There is a wide range in supplement usage among patients:
  - Some take absolutely nothing—no prescription medications or supplements.
  - Others take no medications but have a supplement list that is two pages long.
  - Most patients fall somewhere in between.
- The mental model for evaluation:
  - Supplements are analyzed using a process similar to how the kidney filters glucose, sodium, and potassium:
  - Everything is “dumped out” first, and then the question is asked: What should be added back in?
  - This doesn’t mean literally stopping everything, but it serves as a thought process for analysis.

**Patients Often Don’t Know Why They Take Certain Supplements**

- Many patients don’t have a clear reason for why they are taking certain supplements.
- Common responses when asked why they take a supplement:
  - “I saw someone on Instagram talking about it.”
  - “A doctor recommended it years ago, but I don’t remember why.”
- This lack of clarity reinforces the need for a structured evaluation framework.

**The Misconception About “Natural” Supplements vs. Pharmaceuticals**

- Some patients strongly prefer supplements over medications and express views such as:
  - “I don’t believe in taking medicine—only natural supplements.”
- Peter’s response: There is a difference between supplements and pharmaceuticals, but patients should truly understand that difference instead of making assumptions.
  - The key distinction is regulation, not necessarily effectiveness or safety.

**Regulatory Differences Between Supplements & Pharmaceuticals**

- Supplements:
  - Not regulated by the FDA in the same way as pharmaceuticals.
  - Are generally classified as “GRAS” (Generally Regarded as Safe) by the FDA.
  - The process for determining safety is not rigorous and lacks formal oversight.
- Pharmaceuticals:
  - While not perfect, they undergo a more stringent approval process.
  - Must clear regulatory hurdles before being prescribed.

**Overlapping Ingredients Between Supplements & Pharmaceuticals**

- Some supplements contain active ingredients found in prescription drugs.
- Example: Red rice yeast vs. Statins
  - Some patients refuse to take a statin (e.g., pravastatin) to lower ApoB.
  - However, they are comfortable taking red rice yeast, not realizing that:
    - High doses of red rice yeast function similarly to a modest dose of pravastatin.
- Key lesson: The natural vs. pharmaceutical distinction is often misleading, and all molecules should be evaluated through the same lens.

**Purpose of the Framework Discussion**

- The goal is to analyze supplements objectively rather than emotionally or ideologically.
- Today’s discussion focuses on over-the-counter supplements because:
  - It’s the most common area of patient confusion.
  - It is harder to evaluate compared to pharmaceuticals due to lack of regulation.
- The framework being introduced will help patients critically assess any supplement they take.

## A framework for evaluating supplements [6:15]

**Introduction to the Supplement Evaluation Framework**

- Peter emphasizes that the **most important takeaway** from the episode is this framework.
  - While going through case studies is useful, understanding the evaluation questions is the “punchline.”
- Anytime considering a supplement (or when someone recommends one), ask these key questions.

**The Six Key Questions for Evaluating a Supplement**

Q1: *Are you correcting a deficiency or trying to achieve supramaximal levels?*

- Why are you taking this supplement?
- Are you correcting a deficiency (i.e., replacing something your body lacks)?
- Or are you trying to achieve supraphysiologic levels in hopes of enhancing function?
- Example: Taking vitamin D to correct a deficiency vs. taking creatine to achieve supranormal levels.

Q2: *Are you taking it for lifespan or healthspan?*

- Is the supplement intended to improve your lifespan, healthspan, or both?
  - Lifespan focus → Aimed at increasing longevity and reducing risk of disease.
  - Healthspan focus → Aimed at improving quality of life (physical performance, cognition, emotional health).
  - Some supplements may support both (e.g., fish oil for cardiovascular health).

Q3: *If lifespan, is it targeting a specific disease or broadly geroprotective?*

- If it’s taken for lifespan benefits, is it:
  - Targeting a specific disease (e.g., reducing risk of heart disease or neurodegeneration)?
  - Broadly geroprotective (i.e., slowing down the aging process in a general way)?
  - Examples:
    - Targeting a disease: Taking statins for cardiovascular disease prevention.
    - Geroprotective approach: Rapamycin, which may broadly delay aging processes.

Q4: *Is there a biomarker that you can track to suggest that the supplement is having the desired effect?*

- Is there a biomarker to track effectiveness?
  - A biomarker allows you to measure whether a supplement is working as intended.
  - Example biomarkers:
    - Omega-3 index for fish oil effectiveness.
    - 25-hydroxy vitamin D for vitamin D levels.
    - Creatinine levels for kidney function when taking creatine.
  - If no biomarker exists, effectiveness must be judged subjectively or indirectly.

Q5: *Do we understand the mechanism of action?*

- How does the supplement work?
- Understanding how a supplement functions in the body helps assess its potential benefits and risks.
- Important note: You don’t need to fully understand the mechanism to justify use.
  - Example: Some medications are widely used without a complete understanding of their mechanisms.
- However, the stronger the understanding of its action, the more confidence one can have in using it.

Q6: *What is the balance of risk to reward, including potential side effects, the magnitude of the effect, and the quality of a supplement?*

- How do the risks compare to the potential benefits?
  - This includes:
    - Side effects
    - Magnitude of effect (how much benefit you can reasonably expect)
    - Confidence in available data
    - Quality of the supplement itself (manufacturing, purity, contamination risks)
  - Example considerations:
    - Low risk, high reward: Creatine monohydrate (strong evidence, minimal risk).
    - Unclear risk-reward ratio: Some herbal supplements with limited human data.

**The Importance of Quality in Supplements**

- Supplement quality varies widely due to lack of regulatory oversight.
  - Supplements are far less regulated than pharmaceuticals.
  - Even in the pharmaceutical industry, quality control is imperfect, especially with generics.
- Previous [podcast with Katherine Eban](https://peterattiamd.com/katherineeban/) (referenced for further discussion).
  - Covers quality concerns in pharmaceuticals and supplements.
  - The supplement industry likely has 10x or 100x the issues seen in the pharma space.
- **Key takeaway**: Always verify supplement quality using third-party testing and reputable brands.

*Structure of the Episode & Study Citations*

- To keep the discussion engaging, they will not dive too deeply into every study during the conversation.
- Instead, show notes will contain full details, including:
  - Citations for clinical studies on the discussed supplements.
  - More in-depth explanations for those wanting to go beyond the episode.
- Encouragement for listeners:
  - If you just want to understand the framework, follow the episode.
  - If you want deep study analysis, check the show notes.

## Evaluating creatine: purpose of supplementation, dosing, and mechanism of action [10:00]

**Introduction to Creatine Supplementation**

- Creatine is not used to correct a deficiency but rather to achieve supraphysiologic levels for potential benefits.
- Most people taking creatine do so for athletic performance and possibly cognitive benefits.
- Research suggests that 3-5 grams per day is enough to maximize muscle stores.
  - Loading phases (20 grams per day) were previously common but are no longer necessary.

**Creatine’s Role in Lifespan vs. Healthspan**

- No **direct** evidence suggests creatine extends lifespan.
- However, creatine may improve healthspan by:
  - Enhancing muscle function & exercise performance.
  - Potentially supporting cognitive function.
- Lifespan benefits could be indirect:
  - If creatine helps maintain strength & brain health, it could reduce age-related decline.

***Is There a Biomarker for Tracking Creatine Effectiveness?***

- No direct biomarker exists for creatine supplementation.
- Biomarkers in other contexts:
  - Blood pressure can track anti-hypertensive medication effectiveness.
  - ApoB levels can track cholesterol-lowering drugs.
- Creatine levels in muscle tissue would be the ideal biomarker, but there is no commercial test available.
- Because of this, creatine supplementation is based on adherence to a standard dosing protocol rather than tracking levels.

***Mechanism of Action: How Does Creatine Work?***

- Physical Performance & Energy Production
  - Creatine plays a key role in ATP (adenosine triphosphate) regeneration, which is the body’s energy currency.
  - ATP provides energy by losing a phosphate group, becoming ADP (adenosine diphosphate).
  - Phosphocreatine acts as a phosphate donor, allowing ADP to quickly regenerate into ATP.

![](https://peterattiamd.com/wp-content/uploads/2025/03/creatine-mechanism-1024x366.png)

**Figure 1.** [Source](https://open.oregonstate.education/aandp/chapter/10-3-muscle-fiber-excitation-contraction-and-relaxation/).

- Creatine supplementation increases phosphocreatine stores, which can:
  - Boost energy production for short, intense physical activities (e.g., sprinting, weightlifting).
  - Support anaerobic metabolism (high-intensity, short-duration activity).
  - Likely does not improve aerobic performance (oxidative phosphorylation).
- Cognitive Function & Brain Health
  - A small amount of creatine is synthesized in the brain and can cross the blood-brain barrier.
  - Brain creatine uptake is lower than muscle uptake, which might mean:
    - Higher doses could be necessary for cognitive effects.
    - More research is needed to determine optimal dosing for brain health.
  - Some evidence suggests creatine may help cognition, but this remains an open question.

## Creatine: proven benefits for muscle performance, potential cognitive benefits, and why women may benefit more [15:15]

**Overview of Research on Creatine Efficacy**

- Creatine is one of the most well-studied supplements with extensive research on its benefits.
- Consistent evidence [supports](https://www.mdpi.com/2072-6643/16/21/3665) improvements in muscle performance across multiple studies.
- Effects are not minor—creatine supplementation typically provides a 5-15% improvement in areas like:
  - Power output
  - Muscle hypertrophy (growth)
  - Muscle endurance in short, intense efforts
- Primary mechanisms behind muscle growth (hypertrophy):
  - Increased myofibril thickness (actual muscle fiber growth).
  - Increased water retention within the muscle (which still counts as lean mass).

**Applicability to Different Types of Exercise**

- Best suited for high-intensity and anaerobic activities.
  - Helps in weightlifting, sprinting, and explosive movements.
- Not effective for endurance training in trained athletes.
  - A [meta-analysis](https://link.springer.com/article/10.1007/s40279-023-01823-2) found no significant improvements in endurance athletes.
  - However, untrained individuals may benefit, suggesting creatine could help those new to aerobic training.
- Possible injury prevention and recovery benefits.
  - A [2017 review](https://jissn.biomedcentral.com/articles/10.1186/s12970-017-0173-z) suggested that creatine may aid in injury prevention and muscle recovery.

**Cognitive Benefits and Meta-Analyses**

- Growing body of evidence suggests creatine may enhance cognition.
  - A [recent meta-analysis](https://pmc.ncbi.nlm.nih.gov/articles/PMC11275561/) of 16 RCTs (randomized controlled trials) found positive effects on memory.
  - More research is needed to determine optimal dosing for cognitive function.

![](https://peterattiamd.com/wp-content/uploads/2025/03/creatine-table-1024x775.png)

**Figure 2.**

**SPECIAL CONSIDERATIONS FOR WOMEN:**

- Women may experience greater benefits from creatine than men.
  - Women have [lower baseline creatine stores](https://www.mdpi.com/2072-6643/13/3/877) due to:
    - Less overall muscle mass (primary creatine storage site).
    - Lower dietary creatine intake (many women consume less red meat and fish).
  - Hypothesis: Women may respond more strongly to supplementation because their baseline levels are lower.
- Possible benefits for depression in women.
  - Some [weak evidence](https://pmc.ncbi.nlm.nih.gov/articles/PMC6769464/) suggests creatine may reduce depression symptoms.
  - More studies are needed to confirm this.

**Creatine’s Potential Role in Hormonal Changes**

- May help [offset](https://www.mdpi.com/2072-6643/13/3/877) negative effects of hormonal fluctuations.
  - Possible benefits during:
    - Menstrual cycles
    - Pregnancy
    - Perimenopause & menopause
- Mechanism:
  - Creatine & phosphocreatine pathways are impacted by hormonal shifts.
  - Rapid hormonal changes may influence creatine metabolism, making supplementation potentially beneficial.

**Creatine Use During Pregnancy**

*Frequently asked question: Is creatine safe for pregnancy?*

- Current stance:
  - Likely safe, but insufficient human data to provide a strong recommendation.
  - General medical approach: Avoid unnecessary supplementation during pregnancy.
- Peters’s general practice recommendation:
  - For pregnant women, stop any supplement that is not absolutely necessary.
  - Even if creatine is likely safe, the conservative approach is to avoid it during pregnancy unless future research confirms safety.

**Dosing considerations for women**:

- Women can take the same doses as men (3-5g per day).
- May get greater benefits per gram due to lower baseline stores.

## Creatine: risk vs. reward, kidney concerns, and choosing the right supplement [18:45]

**Overall Risk-Reward Balance of Creatine**

- Categorized as “low risk, modest reward.”
  - Strong safety data supports creatine’s use.
  - Consistent benefits in muscle performance and potential cognitive benefits.
- Minimal downside for most people, provided kidney function is normal.

**Key Safety Considerations: Kidney Function & Creatinine Tests**

- Creatine is metabolized by the liver and excreted by the kidneys.
  - If muscle stores are already full, the body naturally clears excess creatine.
- Important note for those with impaired kidney function:
  - If you have kidney disease or compromised kidney function, consult a doctor before using creatine.
- Impact on blood tests:
  - Creatine supplementation can elevate serum creatinine levels.
  - Creatinine is a key marker used to assess kidney function, and elevated levels may mislead doctors into thinking kidney function has declined.
  - Practice recommendation:
    - If a patient is taking creatine and needs a kidney function test, they should stop taking creatine for 1-2 weeks before testing.

**Best Type of Creatine to Take**

- Creatine **monohydrate** is the gold standard.
  - No need to take other forms (e.g., creatine phosphate, creatine ethyl ester).
  - Other forms do not provide additional benefits.
- Creatine monohydrate is:
  - Backed by the most research.
  - Highly effective.
  - Inexpensive.
- What to look for in a creatine supplement:
  - Pure creatine monohydrate.
  - No fillers or additives.
  - Unflavored unless you want added flavoring.

**How to Take Creatine**

- Mix with any liquid (e.g., water or electrolyte drink).
- No need for special formulations or blends.
- Dosing:
  - 3-5 grams per day is the standard maintenance dose.

## Evaluating fish oil: its primary purpose as a supplement and how to track levels [20:45]

**Purpose of Fish Oil Supplementation**: Correcting Deficiency, Not Achieving Supermaximal Levels

- Fish oil supplementation aims to correct a deficiency, not to create supraphysiologic levels.
- Recommended dietary intake:
  - 16 ounces (two 8-ounce servings) of fatty fish per week (e.g., salmon, mackerel, sardines, anchovies).
  - Many people do not meet this intake requirement, making supplementation useful.
  - Some epidemiological data suggest even higher intake may be ideal.
- Main beneficial components:
  - Omega-3 fatty acids: Polyunsaturated fats with double bonds at the third carbon (n-3).
  - Key Omega-3s:
    - DHA (Docosahexaenoic acid): Essential for brain function and cell membrane integrity.
    - EPA (Eicosapentaenoic acid): Known for anti-inflammatory and cardiovascular benefits.
  - DHA and EPA levels in fatty fish:
    - 8-ounce wild salmon:
      - ~3.25 grams of DHA
      - ~1 gram of EPA
    - Farmed fish may have slightly higher levels, depending on diet.

**Primary Health Benefits: Lifespan & Healthspan Considerations**

- Potential lifespan benefits:
  - Cardiovascular Disease (CVD) Prevention:
    - Fish oil has been extensively studied in the context of reducing heart disease risk.
    - EPA and DHA lower triglycerides, reduce inflammation, and may stabilize arterial plaques.
  - Neurodegenerative Disease Prevention:
    - Evidence suggests DHA plays a role in brain health and may reduce the risk of cognitive decline.
- Uncertainty around all-cause mortality:
  - While evidence supports CVD and neurodegenerative disease prevention, it’s unclear whether this translates to a definitive increase in overall lifespan.

**Biomarker for Measuring Fish Oil Levels:** [*Omega-3 Index*](https://www.amazon.com/Omega-3-Index-Basic-Original-Blood/dp/B07B5HX8Z4)

- There is no direct biomarker that shows fish oil “working,” but there are biomarkers that indicate Omega-3 levels.
- Best biomarker: Omega-3 Index (measures EPA & DHA in red blood cell membranes).
  - More reliable than plasma tests because it reflects long-term intake rather than recent dietary fluctuations.
  - Drawback: Slow to change—takes ~3 months for new RBCs to reflect dietary adjustments.
- Alternative but less reliable biomarkers:
  - Plasma Omega-3 tests: Affected by recent meals or supplement timing.
- Optimal Omega-3 Index Levels:
  - Target range: 8–12%
  - Low levels: Below 5.5% (common in individuals who don’t supplement or eat fatty fish).
  - Excessively high levels: Above 12%
    - Once a patient exceeds ~14%, Peter typically recommends reducing supplementation to avoid overconsumption.

## Fish oil: how omega-3s impact inflammation, heart health, and brain function, and the strengths and limitations of current research [26:30]

**Closing the Omega-3 Deficiency Gap: Observational Study Findings**

- A [study](https://www.sciencedirect.com/science/article/abs/pii/S0952327818302254?dgcid=coauthor) examined Omega-3 index levels in individuals with varying fish intake and supplementation habits.
- Findings:
  - Individuals consuming no fish & no supplements → Average Omega-3 Index ~4.1%
    - Many people fall into this category due to dietary preferences or aversions.
  - Individuals consuming fish 3x per week & taking some Omega-3 supplements → Average Omega-3 Index ~8.1%
    - These individuals fall within the recommended range (8-12%).
- Takeaway:
  - Even three meals of fish per week may not be enough to reach optimal Omega-3 levels without supplementation.
  - Higher-risk individuals (e.g., those with APOE4 genetic variant) may benefit from aiming toward 12% Omega-3 Index through dietary intake or supplementation.

**Importance of EPA vs. DHA: Unclear Optimal Ratios**

- The Omega-3 Index is the sum of EPA & DHA—the test provides a breakdown of both levels.
  - Example: 8.1% total Omega-3 Index
    - DHA: 5.1%
    - EPA: 3.0%
- Unclear ideal targets for DHA vs. EPA individually
  - [APOE4 carriers may benefit from higher DHA levels](https://link.springer.com/article/10.14283/jpad.2023.77)
  - DHA is crucial for brain health and membrane integrity, particularly for Alzheimer’s prevention.
- Clinical Approach:
  - For higher-risk patients, the goal is to reach 12% Omega-3 Index (via diet or supplements).
  - No preference for EPA vs. DHA-heavy supplements—as long as the total Omega-3 intake reaches recommended levels.

**Mechanism of Action: How Omega-3s Work in Disease Prevention**

- Primary benefits come from anti-inflammatory & oxidative stress pathways.
- Key Mechanisms:
  - [Inhibits NF-κB pathway](https://pmc.ncbi.nlm.nih.gov/articles/PMC3257651/) (reduces inflammation).
  - Reduces VLDL (very low-density lipoprotein) production and enhances hepatic fatty acid oxidation.
  - Lowers triglycerides, but less important today
    - Pharmacologic interventions (e.g., prescription drugs) are more effective for triglyceride reduction.
    - Dietary strategies to reduce excess energy intake are also effective.
- Cardiovascular Benefits:
  - Enhances nitric oxide production → increases vasodilation (widening of blood vessels).
  - Acts as a mild blood thinner → reduces platelet aggregation (lower clotting risk).

**Fish Oil for Cardiovascular Disease (CVD):** What the Data Says

- Two types of studies:
  - EPA + DHA combination supplements
  - EPA monotherapy (pharmaceutical-grade EPA only)
- Evidence supports secondary prevention, but primary prevention is less clear.
  - Secondary prevention (people with existing CVD):
    - Fish oil supplementation reduces major adverse cardiac events (MACE).
    - Per a [2021 analysis](https://www.thelancet.com/journals/eclinm/article/PIIS2589-5370(21)00277-7/fulltext), EPA monotherapy showed an 18% reduction in mortality (but based on only three trials).
    - [REDUCE-IT trial](https://www.nejm.org/doi/full/10.1056/NEJMoa1812792): One of the key studies, but its placebo (mineral oil) may have skewed results.
    - Even after excluding REDUCE-IT, data suggests a ~20% reduction in CVD risk.
  - Primary prevention (people without known CVD):
    - [VITAL](https://www.nejm.org/doi/full/10.1056/NEJMoa1811403) and [ASCEND](https://www.nejm.org/doi/full/10.1056/NEJMoa1804989) trials found no clear benefit.
    - Potential issue: Studies used only 1 gram of fish oil—may not be a sufficient dose.
    - Lack of biomarker tracking: Studies didn’t adjust dose based on individual Omega-3 levels.

**Fish Oil for Cognitive Decline & Alzheimer’s Disease**

- Alzheimer’s prevention is difficult to study in RCTs due to the slow onset of disease.
- Mixed results in small clinical trials:
  - [OmegAD Study](https://pubmed.ncbi.nlm.nih.gov/17030655/) (200 participants, 6 months):
    - DHA: 1.7 g/day, EPA: 0.6 g/day.
    - No overall cognitive benefit except in patients with mild Alzheimer’s.
  - [PUFA Trial](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2821809) (100 participants, 3 years):
    - EPA: <1 g/day, DHA: ~0.75 g/day.
    - No reduction in white matter lesions.
    - APOE4 carriers showed better neuronal integrity.
- [Observational studies](https://www.sciencedirect.com/science/article/pii/S0002916523463204) show a 20% reduction in dementia risk with higher Omega-3 intake.
  - Potential confounders:
    - People who eat more fish or take supplements tend to be more health-conscious.
    - Difficult to isolate Omega-3 effects from other lifestyle factors.
- APOE4 Carriers & DHA:
  - APOE4 reduces the ability to increase plasma DHA levels from supplementation.
  - [DHA Brain Delivery Pilot Trial](https://www.thelancet.com/journals/ebiom/article/PIIS2352-3964(20)30266-8/fulltext):
    - 2+ g/day of DHA led to a 28% increase in CSF DHA levels (shows high doses may be necessary).
  - Ongoing study ([PreventE4](https://link.springer.com/article/10.14283/jpad.2023.77) by Hussein Yassine):
    - Testing 2 g/day of DHA in APOE4 carriers before dementia onset.
    - Results could clarify long-term cognitive benefits.

## Fish oil: the risks of supplementation, guidance on selecting high-quality products, and how to determine whether supplementation is appropriate [37:30]

**Potential Risks of Fish Oil Supplementation**

- Main concern: Increased risk of atrial fibrillation (AFib).
- [2021 meta-analysis](https://pmc.ncbi.nlm.nih.gov/articles/PMC9109217/) of 7 RCTs found a small increased risk of AFib.
  - Risk was dose-dependent:
    - Doses >1g/day → 49% increased risk (HR: 1.49)
    - Doses <1g/day → 12% increased risk (HR: 1.12)
  - Absolute risk increase:
    - All doses: 0.63% increase in risk.
    - High-dose group only: 1.1% absolute risk increase (≈1 in 100 people).
  - Context: High-risk cardiovascular disease (CVD) patients.
    - 6 of the 7 studies were in high-risk CVD patients.
    - VITAL trial (only study in low-risk individuals) showed no AFib association.
    - Uncertainty: Is this risk exclusive to high-risk CVD patients or universal?
- Possible Mechanism Behind AFib Risk
  - Unclear cause of AFib risk with fish oil.
  - Speculative reasons:
    - Membrane alterations affecting cardiac electrical activity.
    - Changes in ion channel function or cellular signaling.
    - More research is needed to determine a precise mechanism.

**Fish Oil and Blood Thinners: Potential Complications**

- EPA & DHA have inherent blood-thinning effects.
  - May interact with anticoagulants (e.g., warfarin, aspirin, DOACs).
  - Can increase risk of bleeding (GI bleeds, cerebral hemorrhage).
- Challenges of managing blood thinners & fish oil together:
  - Balancing stroke prevention vs. bleeding risk is already complex.
  - Adding fish oil makes it harder to determine optimal anticoagulation levels.
- Recommendation:
  - Monitor individuals on blood thinners closely if they take fish oil.
  - Consult with a physician before starting fish oil if on anticoagulants.

**How to Choose a High-Quality Fish Oil Supplement**

- Avoid low-quality, rancid fish oil supplements.
  - Poor-quality supplements are common and may contain oxidized oils or contaminants.
- Key factors for choosing a high-quality fish oil:
  - 1) Formulation:
    - Prefer triglyceride (TG) or phospholipid forms → More bioavailable than ethyl ester forms.
  - 2) Fish source:
    - Prefer small fatty fish: Sardines, herring, mackerel, anchovies.
    - Avoid large fish (e.g., tuna) → Higher risk of heavy metal contamination.
  - 3) Beware of plant-based Omega-3 sources (e.g., flaxseed, walnuts).
    - Contain ALA (alpha-linolenic acid), which has poor conversion to EPA/DHA.
    - Conversion rate is extremely low (~5% or less).
- Top Recommended Brands
  - Three brands recommended due to third-party testing & transparency:
    - [Nordic Naturals](https://www.nordic.com/)
    - [Thorne](https://www.thorne.com/)
    - [Carlson Labs](https://carlsonlabs.com/)
  - These brands provide:
    - Certificates of analysis (showing purity, potency, and absence of contaminants).
    - Third-party testing (ensuring accurate labeling & safety).
  - \**No affiliation with these brands—just based on trust in quality*.

**Summary**: Balancing Risk & Reward of Fish Oil Supplementation

- Step 1: Assess Your Baseline Omega-3 Levels
  - Measure [Omega-3 Index (OmegaQuant)](https://www.amazon.com/Omega-3-Index-Basic-Original-Blood/dp/B07B5HX8Z4) using an RBC membrane test.
  - If levels are below 5.5%, supplementation is likely beneficial.
- Step 2: Assess Cardiovascular Risk Factors
  - Do you have signs of atherosclerotic cardiovascular disease (ASCVD)?
    - Elevated CRP (inflammation marker)?
    - High blood pressure?
    - Uncontrolled lipid profile?
    - Elevated triglycerides?
- Step 3: Assess Atrial Fibrillation Risk
  - Key risk factors for AFib:
    - Age
    - History of endurance exercise (e.g., high aerobic load).
    - Existing heart conditions.
- Step 4: Consider APOE4 Status & Cognitive Risk
  - APOE4 carriers & family history of dementia:
    - Higher DHA levels may be protective against Alzheimer’s.
- Step 5: Weigh the Risks & Benefits
  - If high ASCVD risk & low Omega-3 Index:
    - Fish oil supplementation likely beneficial.
  - If high AFib risk & already on blood thinners:
    - Be cautious—monitor for complications.
  - For cognitive protection in APOE4 carriers:
    - High DHA levels may be worth pursuing.
- Final takeaway:
  - In clinical practice, the risk-benefit analysis often favors using high-quality EPA/DHA supplements.
  - However, personalized risk assessment is crucial before supplementation.

## Evaluating vitamin D: understanding deficiency and optimal levels [45:15]

**Purpose of Vitamin D Supplementation: Deficiency vs. Supramaximal Levels**

- Primary reason for supplementation: Correcting deficiency, not achieving supramaximal levels.
- Defining deficiency and insufficiency is complex:
  - Deficiency = Well-agreed upon, but insufficiency is debated.
- Vitamin D synthesis from sunlight exposure is difficult to quantify.
  - Too many variables (time of day, skin type, latitude, UV intensity).
  - No reliable formula to estimate how much Vitamin D sunlight provides.

**Sources of Vitamin D**

- Recommended daily intake (RDA): 800 IU per day (oral + sunlight combined).
- Dietary sources:
  - Fatty fish: Highest source (3.5 oz of salmon = ~500 IU+).
  - Eggs: Only ~44 IU per egg.
  - Fortified milk: ~100 IU per cup.
  - Most people struggle to meet RDA through diet alone.

***What Constitutes Vitamin D Deficiency?***

- Clear agreement on deficiency thresholds:
  - Children:
    - Deficiency → Below 15 ng/mL (leads to rickets).
  - Adults:
    - Deficiency → Below 20 ng/mL (linked to poor bone health).
    - Some experts consider anything below 12 ng/mL alarming.
- *Why Does* [*Rickets*](https://en.wikipedia.org/wiki/Rickets) *Occur in Sun-Exposed Regions*?
  - Surprisingly common in Africa & Middle East despite sunlight.
  - Causes:
    - Breastfeeding infants kept in shade.
    - Cultural clothing practices that cover the skin.
    - Middle East has the highest incidence of rickets worldwide.

**The Debate on Insufficiency & Optimal Levels**

- 20-30 ng/mL: Generally considered “insufficient.”
- 30-50 ng/mL: Some argue this is still not “fully replete.”
- 50+ ng/mL: Some experts claim this is the true “optimal range.”

**Vitamin D Toxicity: What Levels Are Too High?**

- Vitamin D [toxicity](https://pmc.ncbi.nlm.nih.gov/articles/PMC6158375/) occurs at levels above 150 ng/mL → Leads to:
  - Hypercalciuria (excess calcium in urine).
  - Hypercalcemia (high blood calcium).
  - Potential bone loss from excessive calcium release.
  - Associated symptoms:
    - Neuropsychiatric issues.
    - Gastrointestinal distress.
    - Cardiovascular complications.
    - Kidney dysfunction.
- Practical clinical guideline:
  - Anything above 80 ng/mL is considered excessive.
  - Ideal range is debated (30-80 ng/mL, 50-80 ng/mL, or 30-60 ng/mL).
  - No clear consensus, even after deep analysis.

## Vitamin D: role in bone health, immune function, potential longevity impact, and biomarker limitations [51:15]

**Vitamin D for Lifespan vs. Healthspan**

- Lifespan:
  - Bone health is a major factor.
  - Vitamin D follows an “inverted U” relationship: Too much or too little is problematic.
  - Ideal range is unclear, but possibly around 50 ng/mL.
  - Indirectly supports longevity by reducing fractures and falls, which are major risks in aging.
- Healthspan:
  - Associations [exist](https://www.tandfonline.com/doi/full/10.1080/10408398.2022.2096560) between low Vitamin D and depression.
  - Peter is skeptical about this correlation due to confounding variables.
  - People with higher Vitamin D levels tend to be more active and spend more time outdoors.
  - Hard to separate whether Vitamin D itself plays a role in mental health or if it’s a proxy for other healthy behaviors.

**Biomarker for Tracking Vitamin D Levels**

- The standard test for Vitamin D levels: [25-hydroxy vitamin D (25(OH)D)](https://www.mountsinai.org/health-library/tests/25-hydroxy-vitamin-d-test).
  - Most commonly measured marker.
  - However, it is not the active form of Vitamin D.
- Active form: 1,25-dihydroxy vitamin D (1,25(OH)₂D).
  - Produced from 25(OH)D via hydroxylation in the kidney.
  - Highly regulated and may not always correlate directly with 25(OH)D levels.
- Issues with relying solely on 25(OH)D as a biomarker:
  - In some cases, 1,25(OH)₂D levels may not be optimal even if 25(OH)D appears normal.
  - Kidney dysfunction can interfere with the conversion process.

**Mechanism of Action**

- [Bone health](https://pmc.ncbi.nlm.nih.gov/articles/PMC3257679/):
  - Enhances calcium absorption in the small intestine.
  - Stimulates osteoblasts (bone-forming cells) and promotes bone mineralization.
  - Regulates parathyroid hormone (PTH), which maintains calcium balance.
  - In the VITAL [trial](https://academic.oup.com/jbmr/article/35/5/883/7516653?login=false), among participants with baseline levels below the median, there was a slight increase in spine areal BMD
- [Immune function](https://pmc.ncbi.nlm.nih.gov/articles/PMC3166406/):
  - Vitamin D receptors (VDRs) are found in nearly all immune cells.
  - Regulates genes involved in immune response.
  - Expressed in bone marrow, brain, and epithelial tissues (colon, breast, etc.), suggesting widespread physiological roles.
- Vitamin D as a hormone:
  - Although classified as a vitamin, Vitamin D functions as a hormone.
  - Influences multiple bodily systems beyond just calcium metabolism.

**Issues with Vitamin D Supplementation Studies**

- Major flaw: Most studies use fixed-dose supplementation instead of targeting an optimal blood level.
  - Studies typically assign participants a set dose (e.g., [2,000 IU/day](https://pubmed.ncbi.nlm.nih.gov/38337676/)) and don’t track whether it actually raises their levels sufficiently.
  - No follow-up to adjust the dose based on individual response.
- This study design issue leads to unreliable results.
  - Some participants remain deficient even while taking Vitamin D.
  - Others may not take the supplement consistently, further confounding results.
  - Ultimately, unclear whether outcomes are due to Vitamin D or poor study design.
- Proposed solution:
  - Instead of giving everyone the same dose, researchers should aim to get participants to a standardized blood level (e.g., 50 ng/mL) and study outcomes from there.
  - This would cost more but provide far more useful data.

**Vitamin D and Immune Function**

- Historically used as a treatment for infections (unknowingly).
  - Before antibiotics, doctors used sun exposure and cod liver oil to [treat](https://pmc.ncbi.nlm.nih.gov/articles/PMC3166406/) tuberculosis.
- Many Vitamin D supplementation trials for immune function and autoimmune diseases have failed.
  - However, failures may be due to poor study design (fixed-dose issue).
- Interesting theory:
  - Vitamin D levels fluctuate with the seasons, as does susceptibility to infections.
  - Possible that lower winter Vitamin D levels contribute to higher rates of colds, flu, and other infections.
  - Not proven, but an intriguing hypothesis.

## Vitamin D: efficacy, safety, and balancing risk vs. reward [58:15]

**Safety of Vitamin D Supplementation**

- Most studies use a fixed dose of 2,000 IU per day.
  - This dose ensures nearly everyone (~99%) reaches at least 20 ng/mL.
  - 90% of the population will be above 30 ng/mL at this dose.
  - At 2,000 IU/day, there are no safety concerns.
- What happens at higher doses?
  - People should not take a fixed dose year-round without adjusting for sun exposure.
  - Example:
    - A person taking 5,000 IU in winter might reach 55 ng/mL.
    - That same dose in summer with more sun exposure could push levels much higher.
  - Recommendation: Monitor and adjust dosage seasonally.
- Target Vitamin D Levels for Safety and Effectiveness
  - Below 80 ng/mL: Very low risk of harm.
  - Below 70 ng/mL: More conservative threshold for safety.
  - Ideal range in Peter’s practice: 40-60 ng/mL.
  - Self-adjustment based on sun exposure is necessary to avoid excess.

**Risks of Excess Vitamin D (Hypercalcemia & Other Symptoms)**

- Hypercalcemia is the primary concern with excessive Vitamin D intake.
  - Leads to excessive calcium in the blood, which can cause:
    - Kidney stones.
    - Nausea, vomiting, and gastrointestinal distress.
    - Weakness, fatigue, and frequent urination.
  - Peter has not personally seen these issues in his patients, but excessive supplementation (e.g., >10,000-15,000 IU/day) poses risks.
- Vitamin D is a fat-soluble vitamin, meaning it accumulates in the body.
  - Unlike water-soluble vitamins (e.g., B vitamins), excess Vitamin D is harder to eliminate.
  - Fat-soluble vitamins can build up to toxic levels over time.

**Balancing Risk-Reward for Vitamin D Supplementation**

- Low risk, high reward if Vitamin D is below 20 ng/mL.
- Moderate reward if Vitamin D is below 30 ng/mL.
- Modest benefit for those already at 30 ng/mL but wanting slightly higher levels.
- Factors influencing supplementation needs:
  - Geography/climate (less sun = greater need).
  - Personal sun exposure habits.
  - Diet (e.g., fish intake).
- Key caution:
  - Since Vitamin D is fat-soluble, excess intake leads to accumulation, making overdosing a real concern.
  - Unlike water-soluble vitamins that are excreted, excess Vitamin D is harder to regulate.
  - People supplementing with high doses (e.g., 10,000 IU+) should regularly check their levels.

## Evaluating B vitamins: function, consequences of deficiency, and key biomarkers to assess whether supplementation is necessary [1:02:15]

**Purpose of B Vitamin Supplementation**

- Primary purpose: Correcting deficiencies rather than achieving supermaximal levels.
- B vitamins are water-soluble, meaning excess amounts are excreted in urine.
  - This makes toxicity much less likely compared to fat-soluble vitamins (like vitamin D).

**Deficiency and Key B Vitamins**

- B vitamin deficiencies can occur, but focus is on three key vitamins:
  - B6 (Pyridoxine)
  - B9 (Folate)
  - B12 (Cobalamin)
- Functions of B9 & B12:
  - Both play key roles in DNA methylation and synthesis.
  - They are involved in gene expression and overall cellular function.
  - B9 and B12 are essential for proper homocysteine metabolism.
- Role of the MTHFR Gene in B Vitamin Metabolism:
  - MTHFR gene affects folate metabolism and homocysteine conversion.
  - People with certain genetic polymorphisms in MTHFR have lower enzyme activity, leading to increased homocysteine levels.
  - However, genetic testing for MTHFR is unnecessary.
    - Management should be based on homocysteine levels rather than genetic testing.
    - Peter stopped testing MTHFR because it did not change treatment decisions.
- B6’s Role in Homocysteine Metabolism:
  - B6 deficiency also contributes to high homocysteine levels.
  - B6 serves as a cofactor in enzymes that break down homocysteine into cysteine.
- Common Deficiency Symptoms & Conditions:
  - Symptoms of B vitamin deficiency are often non-specific.
  - Classic B12/B9 deficiency symptom: Megaloblastic anemia.
    - Characterized by low hemoglobin and enlarged red blood cells.
    - Opposite of iron-deficiency anemia, which causes small red blood cells.
  - Deficiencies are more common in people who consume no animal products.

![](https://peterattiamd.com/wp-content/uploads/2025/03/B-vitamin-figure-1024x722.png)

**Figure 3. Overview of the human folic acid metabolic pathway and the role of MTHFR, S-adenosylmethionine (SAM), S-adenosylhomocysteine (SAH), dihydrotetrafolic acid (DHF), and tetrahydrofolic acid (THF).**

**B Vitamins for Lifespan vs. Healthspan**

- More relevant for lifespan benefits than healthspan.
  - Prevention of anemia and neurodegenerative conditions.
  - Reducing inflammatory markers like homocysteine, which is linked to cardiovascular disease (CVD) and dementia.
- Who needs B vitamin supplementation?
  - Strict vegetarians/vegans are at the highest risk of B12 deficiency.
  - Most omnivores get sufficient amounts from their diet.
  - B vitamin supplementation is commonly used to lower homocysteine levels, which may reduce CVD and neurodegenerative disease risk.

**Biomarkers for B Vitamin Status**

- Several biomarkers help assess B vitamin levels and their effects:
  - Serum B12 levels – Used to assess B12 status but can be misleading.
  - Red blood cell folate (B9 levels) – Best marker for long-term folate status.
  - Methylmalonic acid (MMA) levels:
    - MMA builds up when B12 is deficient.
    - Peter prefers MMA over serum B12 testing because it’s a more reliable indicator of deficiency.
  - Homocysteine levels:
    - Elevated homocysteine suggests issues with B6, B9, or B12 metabolism.
    - If B9 and B12 are sufficient but homocysteine is still high, a small dose of B6 might be added.
  - Plasma B6 levels:
    - Less commonly tested.
    - Usually assessed only if homocysteine remains high despite normal B9 and B12 levels.

> “I would just call out that there’s quite a bit of variability here and that’s why I really prefer to look at things like homocysteine MMA, if I have any doubt.” —Peter Attia
>
> ![](https://peterattiamd.com/wp-content/uploads/2025/03/B-vit-test-table.png)

**Figure 4.**

## B vitamins: risks for CVD and dementia associated with deficiency, and limited evidence for general population supplementation [1:07:15]

**Mechanism of Action of B Vitamins**

- Role in Methylation and DNA Synthesis:
  - Methylated B vitamins bypass the rate-limiting step in the methylation cycle, reducing homocysteine levels.
  - B12 and B9 are crucial for DNA synthesis and repair, particularly in rapidly dividing cells.
- Impact on the Nervous System:
  - B6 and B9 (folate) are essential for neurotransmitter synthesis (serotonin and dopamine).
  - B12 is necessary for myelin synthesis, which supports nerve function and prevents neurodegenerative decline.
- Megaloblastic Anemia:
  - B vitamin deficiencies cause enlarged red blood cells (megaloblastic anemia).
  - Extreme B vitamin deficiency can impair DNA synthesis, leading to anemia and neurological symptoms.
- Severe Homocysteine Elevation:
  - Rare genetic cases with MTHFR mutations can lead to extremely high homocysteine levels (above 20).
  - These cases often require targeted intervention.

**B Vitamins and Cardiovascular Disease (CVD)**

- Association vs. Direct Effect:
  - Deficiencies in B6, B9, and B12 are associated with increased CVD risk.
  - However, intervention trials have failed to show a strong effect of B vitamin supplementation in reducing CVD risk.
- Homocysteine and Vascular Health:
  - Theoretically, reducing homocysteine should improve vascular function.
  - Homocysteine plays a role in nitric oxide synthesis, which affects blood vessel dilation.
- Limitations of Studies on B Vitamins & CVD:
  - Many trials included broad populations rather than targeting people with high homocysteine.
  - A [5,000-patient study](https://jamanetwork.com/journals/jama/fullarticle/181854) on women over seven years showed no reduction in heart disease risk.
  - Studies that did [show a benefit](https://pmc.ncbi.nlm.nih.gov/articles/PMC5015297/) found that only people with large homocysteine reductions (5+ micromol/L) saw improvements.
    - A [meta-analysis](https://pmc.ncbi.nlm.nih.gov/articles/PMC5015297/) of five RCTs found that reducing homocysteine by at least 5 micromol/L led to an 18% reduction in major cardiovascular events (MACE).

**B Vitamins and Cognitive Decline/Alzheimer’s Disease**

- Limited Evidence for Cognitive Protection:
  - B vitamin supplementation has not been shown to enhance cognition in healthy individuals.
  - Some evidence suggests potential benefits in those with early cognitive decline.
- Key Studies on B Vitamins & Brain Health:
  - [VITACOG trial](https://pmc.ncbi.nlm.nih.gov/articles/PMC2935890/):
    - Found that B vitamins slowed brain atrophy in patients with mild cognitive impairment (MCI).
    - The effect was strongest in those with high homocysteine levels.
  - [Meta-analysis](https://bmcgeriatr.biomedcentral.com/articles/10.1186/s12877-021-02253-3) of 21 RCTs (~7,000 patients):
    - Found a small but significant effect on overall cognitive function.
    - No meaningful impact on executive function, memory, or processing speed.
  - No evidence B vitamins enhance cognition in those with normal cognitive function.

**Risks & Side Effects of B Vitamin Supplementation**

- B6 Toxicity:
  - Easiest B vitamin to overdose on.
  - Peripheral neuropathy (nerve damage) can occur with doses as low as 50-100 mg/day.
  - Patients taking >50 mg/day who developed neuropathy saw symptoms resolve after lowering doses to 25 mg/day.
- Potential Risks of B9 (Folate) and B12:
  - Extremely high levels of B9 may cause GI issues, irritability, and confusion.
  - High-dose B12 injections have been linked to skin irritation and tingling in extremities.
- Lung Cancer Concerns in High-Dose B Vitamin Use:
  - Some observational studies suggested a link between high B vitamin intake and increased lung cancer risk in men.
  - Follow-up research found no consistent evidence to support this association.
  - If there was an effect, it seemed to be limited to smokers.

**Risk-Reward Balance of B Vitamin Supplementation**

- Very Low Risk in Normal Supplementation:
  - Standard doses (e.g., 400 mcg folate, 1,000–4,000 mcg B12, ≤50 mg B6) are safe.
  - Excess B vitamins are water-soluble and excreted in urine, reducing toxicity risk (except B6).
- Minimal Benefit in Those Without Deficiency:
  - If someone is already B vitamin replete and has normal homocysteine, supplementation offers little benefit.
  - May be useful for those with high homocysteine or B vitamin deficiencies.
  - Limited evidence for cardiovascular or cognitive benefits unless there is an underlying deficiency.

## Evaluating ashwagandha: background, uses, and mechanism of action [1:15:30]

**Overview of Ashwagandha**

*What is Ashwagandha?*

- Ashwagandha is an evergreen shrub used in traditional Indian medicine (Ayurveda).
- Historically taken for a variety of purposes, including sleep, stress reduction, and immune health.
- Considered an adaptogen, meaning it helps the body adapt to stress and maintain balance.

*Is it for Correcting Deficiency or Achieving Supermaximal Levels?*

- Supermaximal levels – Ashwagandha is not naturally found in the body.
- It is taken with the belief that introducing it exogenously provides beneficial effects.

**Purpose of Ashwagandha Supplementation**

- Lifespan vs. Healthspan
  - Primarily taken for healthspan – aimed at improving sleep quality and reducing stress and anxiety.
  - Potential indirect lifespan benefits – chronic stress and poor sleep negatively affect longevity.
- Are There Biomarkers to Track Effectiveness?
  - No direct biomarker exists for ashwagandha’s effects.
  - Indirect ways to measure impact:
    - Sleep tracking devices (Oura Ring, WHOOP, Apple Watch, etc.) to monitor sleep quality.
    - Self-reported stress and anxiety levels.
    - Saliva or urinary cortisol tests – can measure cortisol reduction.

**Mechanism of Action**

- More Unknowns Than Knowns
  - Exact mechanisms are unclear, but [research](https://pmc.ncbi.nlm.nih.gov/articles/PMC10281725/) suggests effects on:
    - GABAergic pathways – influences GABA, the brain’s main inhibitory (calming) neurotransmitter.
    - HPA axis regulation – affects cortisol levels, potentially reducing stress.
- Findings from Animal Studies:
  - Increases GABA activity in the central nervous system (CNS).
  - Promotes deep sleep (delta waves) and extends non-REM sleep duration.
  - Enhances gamma levels in the brain.
  - But… Major caveats:
    - Studies are mostly in rodents, so human applicability is unclear.
    - Sleep effects were induced using barbiturates rather than occurring naturally.
- Findings from Human Studies:
  - Potential Cortisol-Lowering Effects:
    - A randomized controlled [trial](https://journals.lww.com/md-journal/fulltext/2019/09130/an_investigation_into_the_stress_relieving_and.67.aspx) (RCT) found a 40% reduction in morning cortisol after 60 days of use.
    - If validated in larger studies, this could be a key benefit for stress management.
- Challenges in Evaluating Ashwagandha’s Effects:
  - Withanolides are the primary bioactive compounds in ashwagandha.
  - Many studies do not standardize dosages based on withanolide content.
  - Different brands contain different withanolide levels, making comparisons difficult.

## Ashwagandha: current evidence for its effects on sleep, stress, and anxiety [1:19:15]

**Safety and Tolerability of Ashwagandha**

- General Safety
  - Well-tolerated for most individuals.
  - Some patients swear by it as one of the most effective over-the-counter sleep aids they’ve used.
  - Others report no noticeable effects and discontinue use.
  - Minimal side effects reported in clinical practice.
  - Some [studies](https://www.psychiatrist.com/jcp/withania-somnifera-extract-for-schizophrenia-symptoms/) have found minor gastrointestinal (GI) issues in a small subset of users.
- Cost Consideration
  - Expensive depending on brand and concentration.
  - Since effectiveness varies, it’s not a “set it and forget it” supplement.
  - Recommendation: If no noticeable benefit, discontinue use.

**Ashwagandha and Sleep**

- Quality of Data on Sleep Benefits
  - Low to moderate evidence for ashwagandha’s role in sleep.
  - Compared to other OTC sleep aids (e.g., melatonin), the data is weaker.
  - Not considered a first-line intervention for sleep.
  - First-line interventions should focus on:
    - Sleep hygiene (light exposure, circadian rhythm, evening routines).
    - Temperature control.
    - Food/alcohol intake before bed.
- [Meta-Analysis](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0257843) on Sleep Benefits
  - Analyzed five RCTs (double-blinded, placebo-controlled).
  - Results: Moderate to favorable effects on overall sleep duration.
  - Limitations:
    - High heterogeneity (variation in study designs, dosages, populations).
    - Moderate-quality evidence, not conclusive.
  - Conclusion: Worth trying if sleep hygiene is already optimized, but not a primary sleep solution.

**Ashwagandha and Stress/Anxiety**

- Quality of Data on Stress & Anxiety Reduction
  - Less clear than sleep benefits.
  - Significant variability between RCTs.
  - Studies differ in design, population, and dosages, making conclusions difficult.
- Largest [Meta-Analysis](https://www.researchgate.net/publication/362948981_Does_Ashwagandha_supplementation_have_a_beneficial_effect_on_the_management_of_anxiety_and_stress_A_systematic_review_and_meta-analysis_of_randomized_controlled_trials?enrichId=rgreq-3ba3705a085943cb60e61865a3a2f67b-XXX&enrichSource=Y292ZXJQYWdlOzM2Mjk0ODk4MTtBUzoxMTQzMTI4MTIzODAxOTM3NUAxNzEzODA2MTU1MjI5&el=1_x_3&_esc=publicationCoverPdf) on Stress & Anxiety
  - Reviewed 12 RCTs.
  - Found favorable effects on stress and anxiety.
  - Doses used: 250 to 1,000 mg/day of ashwagandha extract.
  - Limitations:
    - Studies were not high quality.
    - Differences in trial design reduce confidence in conclusions.
  - Conclusion: Evidence suggests potential benefits, but not strong enough to be definitive.

## Ashwagandha: evaluating supplement quality, safety profile, and the risk-reward balance [1:22:15]

**Evaluating the Quality and Purity of Ashwagandha**

- Variation in Supplement Quality
  - Ashwagandha supplements vary widely in quality and effectiveness.
  - Key factor: Withanolide concentration (bioactive compounds believed to provide benefits).
  - Many supplements do not contain the levels of withanolides they claim.
- Third-Party Testing
  - Third-party labs verify withanolide content and safety.
  - However, they only test for a limited number of withanolides (typically 8), whereas ashwagandha extracts contain over 40 different withanolides.
  - [Consumer Lab Testing Report](https://www.consumerlab.com/reviews/ashwagandha-supplements/ashwagandha/):
    - Analyzed 13 ashwagandha supplements for accuracy.
    - Found that only 5 of 13 met the reported withanolide concentrations.
- Different Types of Ashwagandha Extracts
  - KSM-66
    - Marketed as a “full-spectrum” extract, maintaining the same ratio of compounds as the raw root.
    - No scientific evidence that it is superior to other extracts.
  - Shoden
    - 35% withanolide content (highest concentration).
    - Made from both roots and leaves.
  - Sensoril
    - 10% withanolide content.
    - Also extracted from roots and leaves.
  - **Key takeaway**: It’s not just about how much ashwagandha you take, but how much withanolide content you’re getting.
- Dosage Considerations
  - Clinical studies suggest a “sweet spot” of 10–30 mg of withanolides per day.
  - Supplement labels should specify withanolide content per dose, not just the total amount of ashwagandha.

**Practical Strategy for Choosing a High-Quality Supplement**

- Use third-party testing reports to verify accurate withanolide content.
- Compare brands based on cost per gram of withanolides.
- Optimization Tip: If you’re detail-oriented, create a spreadsheet to track price vs. withanolide content for the best value.

**Personal Experience and Practical Considerations**

*Peter’s Perspective on Ashwagandha*

- Initially skeptical but has been taking it for 1–2 years.
- Hesitant to remove it from his routine since his sleep has improved significantly.
- Acknowledges that other lifestyle changes (e.g., meal timing) could also contribute to better sleep.
- Self-experimentation would be ideal, but he prioritizes other things over removing ashwagandha to test its individual impact.

*Who Should Consider Ashwagandha?*

- Best for someone looking for a slight edge in stress reduction and sleep.
- Not helpful for someone with poor sleep hygiene (e.g., staying up all night on Twitter, only sleeping 4 hours).
- Should only be used after addressing foundational sleep habits.

## The importance of using a structured evaluation framework to assess any supplement [1:26:30]

**Final Thoughts on Supplements and the Evaluation Framework**

- Supplements Are Highly Individualized
  - No one-size-fits-all approach to supplementation.
  - Each person’s needs, health goals, and deficiencies dictate what’s appropriate for them.
  - This discussion covered the most frequently asked-about supplements, but the framework applies to any supplement or molecule.
- The Importance of a Structured Evaluation Framework
  - Supplements vary widely in quality, efficacy, and safety.
  - Applying a consistent framework ensures better decision-making.
  - Framework can be applied to all supplements and medications, helping individuals critically assess their choices.
- Over-the-Counter Supplements Require More Scrutiny
  - Unregulated supplements are harder to evaluate than pharmaceutical drugs because:
    - Lack of standardized clinical trials and regulatory oversight.
    - Variability in ingredient purity and dosage accuracy.
    - No FDA-mandated efficacy testing like pharmaceuticals undergo.
  - Pharmaceuticals are easier to assess using this framework because:
    - They must clear strict regulatory hurdles before approval.
    - Clinical trial data is typically available to answer key efficacy and safety questions.

**The Goal of This AMA Episode**

- Purpose:
  - Demonstrate how to systematically evaluate supplements.
  - Provide real-world examples using common supplements (Creatine, Fish Oil, Vitamin D, B Vitamins, Ashwagandha).
  - Help listeners think critically rather than rely on anecdotal advice.
- Encouragement for Listeners
  - Apply this framework to their own supplement lists.
  - Use critical thinking rather than blindly following trends or marketing claims.
  - Recognize the complexity of supplementation and avoid oversimplified, one-size-fits-all approaches.

---

## Selected Links / Related Material

**Episode of The Drive with Katherine Eban where they discussed quality or pharmaceuticals**: [#71 – Katherine Eban: Widespread fraud in the generic drug industry](https://peterattiamd.com/katherineeban/) | Peter Attia (peterattiamd.com) [8:45]

**Creatine supplementation: Consistent evidence supports improvements in muscle performance**: [Effects of Creatine Supplementation and Resistance Training on Muscle Strength Gains in Adults <50 Years of Age: A Systematic Review and Meta-Analysis](https://www.mdpi.com/2072-6643/16/21/3665) (Wang et al., 2024) [15:15]

**A meta-analysis found no significant improvements in endurance athletes with creatine supplementation**: [Effects of Creatine Monohydrate on Endurance Performance in a Trained Population: A Systematic Review and Meta-analysis](https://link.springer.com/article/10.1007/s40279-023-01823-2) (Fernandez-Landa et al., 2023) [15:15]

**A 2017 review suggested that creatine may aid in injury prevention and muscle recovery**: [International Society of Sports Nutrition position stand: safety and efficacy of creatine supplementation in exercise, sport, and medicine](https://jissn.biomedcentral.com/articles/10.1186/s12970-017-0173-z) (Kreider et al., 2017) [15:15]

**A 2024 meta-analysis of 16 RCTs (randomized controlled trials) found positive effects on memory with creatine**: [The effects of creatine supplementation on cognitive function in adults: a systematic review and meta-analysis](https://pmc.ncbi.nlm.nih.gov/articles/PMC11275561/) (Xu et al., 2024) [15:15]

**Women have lower baseline creatine stores**: [Creatine Supplementation in Women’s Health: A Lifespan Perspective](https://www.mdpi.com/2072-6643/13/3/877) (Smith-Ryan et al., 2021) [15:15]

**Some weak evidence suggests creatine may reduce depression symptoms**: [Creatine for the Treatment of Depression](https://pmc.ncbi.nlm.nih.gov/articles/PMC6769464/) (Kious et al., 2019) [15:15]

**Creatine may help offset negative effects of hormonal fluctuations**: [Creatine Supplementation in Women’s Health: A Lifespan Perspective](https://www.mdpi.com/2072-6643/13/3/877) (Kious et al., 2019) [15:15]

**The best biomarker for measuring fish oil levels:** [Omega-3 Index](https://www.amazon.com/Omega-3-Index-Basic-Original-Blood/dp/B07B5HX8Z4) by OmegaQuant | (amazon.com) [20:45]

**A study examined Omega-3 index levels in individuals with varying fish intake and supplementation habits**: [Association of reported fish intake and supplementation status with the omega-3 index](https://www.sciencedirect.com/science/article/abs/pii/S0952327818302254?dgcid=coauthor) (Jackson et al., 2019) [26:30]

**APOE4 carriers may benefit from higher DHA levels**: [Baseline Findings of PreventE4: A Double-Blind Placebo Controlled Clinical Trial Testing High Dose DHA in APOE4 Carriers before the Onset of Dementia](https://link.springer.com/article/10.14283/jpad.2023.77) (Yassine et al., 2023) [26:30]

**A key mechanism of how omega-3s work in disease prevention—inhibits NF-κB pathway (reduces inflammation)**: [Omega-3 Fatty Acids and Inflammatory Processes](https://pmc.ncbi.nlm.nih.gov/articles/PMC3257651/) (Calder, 2010) [26:30]

**Per a 2021 analysis, EPA monotherapy showed an 18% reduction in mortality (but based on only three trials)**: [Effect of omega-3 fatty acids on cardiovascular outcomes: A systematic review and meta-analysis](https://www.thelancet.com/journals/eclinm/article/PIIS2589-5370(21)00277-7/fulltext) (Khan et al., 2021) [30:15]

**Evidence supports secondary prevention of CVD by taking fish oil**: [Cardiovascular Risk Reduction with Icosapent Ethyl for Hypertriglyceridemia](https://www.nejm.org/doi/full/10.1056/NEJMoa1812792) (Bhatt et al., 2018) [30:15]

**Fish oil primary prevention trials (people without known CVD)**: [30:15]

- The VITAL trial found no clear benefit: [Marine n−3 Fatty Acids and Prevention of Cardiovascular Disease and Cancer](https://www.nejm.org/doi/full/10.1056/NEJMoa1811403) (Manson et al., 2018) [30:15]
- The ASCEND trial found no clear benefit: [Effects of n−3 Fatty Acid Supplements in Diabetes Mellitus](https://www.nejm.org/doi/full/10.1056/NEJMoa1804989) (The ASCEND Study Collaborative Group, 2018) [30:15]

**Fish oil for cognitive decline and Alzheimer’s disease**: [31:15]

- Mixed results in the OmegAD Study (200 participants, 6 months): [Omega-3 fatty acid treatment in 174 patients with mild to moderate Alzheimer disease: OmegAD study: a randomized double-blind trial](https://pubmed.ncbi.nlm.nih.gov/17030655/) (Freund-Levi et al., 2006) [31:15]
- Mixed results in the PUFA Trial (100 participants, 3 years): [ω-3 PUFA for Secondary Prevention of White Matter Lesions and Neuronal Integrity Breakdown in Older Adults: A Randomized Clinical Trial](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2821809) (Shinto et al., 2024) [31:15]

**Observational studies (with confounders) show a 20% reduction in dementia risk with higher Omega-3 intake**: [The Relationship of Omega-3 Fatty Acids with Dementia and Cognitive Decline: Evidence from Prospective Cohort Studies of Supplementation, Dietary Intake, and Blood Markers](https://www.sciencedirect.com/science/article/pii/S0002916523463204) (Wei et al., 2023) [30:15]

**DHA Brain Delivery Pilot Trial looking at APOE4 carriers taking DHA**: [Protection against mycobacterial infection: A case-control study of mycobacterial immune responses in pairs of Gambian children with discordant infection status despite matched TB exposure](https://www.thelancet.com/journals/ebiom/article/PIIS2352-3964(20)30266-8/fulltext) (Roy et al., 2020) [30:15]

**Ongoing study (PreventE4 by Hussein Yassine) testing 2 g/day of DHA in APOE4 carriers**: [Baseline Findings of PreventE4: A Double-Blind Placebo Controlled Clinical Trial Testing High Dose DHA in APOE4 Carriers before the Onset of Dementia](https://link.springer.com/article/10.14283/jpad.2023.77) (Yassine et al., 2023) [30:15]

**Episode of The Drive with Hussein Yassine where they discussed the APOE gene**: [#147 – Hussein Yassine, M.D.: Deep dive into the “Alzheimer’s gene” (APOE), brain health, and omega-3s](https://peterattiamd.com/husseinyassine/) | Peter Attia (peterattiamd.com) [37:00]

**2021 meta-analysis of 7 RCTs found a small increased risk of AFib with fish oil**: [Effect of long-term marine Omega-3 fatty acids supplementation on the risk of atrial fibrillation in randomized controlled trials of cardiovascular outcomes: a systematic review and meta-analysis](https://pmc.ncbi.nlm.nih.gov/articles/PMC9109217/) (Gencer et al., 2022) [37:30]

**Top Recommended Brands of Fish Oil due to third-party testing & transparency**: [38:00]

- [Nordic Naturals](https://www.nordic.com/)
- [Thorne](https://www.thorne.com/)
- [Carlson Labs](https://carlsonlabs.com/)

**Associations exist between low Vitamin D and depression**: [The effect of vitamin D supplementation on depressive symptoms in adults: A systematic review and meta‐analysis of randomized controlled trials](https://www.tandfonline.com/doi/full/10.1080/10408398.2022.2096560) (Mikola et al., 2022) [51:15]

**Issues with Vitamin D Supplementation Studies—Studies typically assign participants a set dose (e.g., 2,000 IU/day) and don’t track whether it actually raises their levels sufficiently—leading to unreliable results**: [Vitamin D Supplementation: A Review of the Evidence Arguing for a Daily Dose of 2000 International Units (50 µg) of Vitamin D for Adults in the General Population](https://pubmed.ncbi.nlm.nih.gov/38337676/) (Pludowski et al., 2024) [51:15]

**Potential mechanism of vitamin D on bone health**: [Vitamin D and Bone Health; Potential Mechanisms](https://pmc.ncbi.nlm.nih.gov/articles/PMC3257679/) (Laird et al., 2010) [53:00]

**Before antibiotics, doctors used sun exposure and cod liver oil to treat tuberculosis**: [Vitamin D and the Immune System](https://pmc.ncbi.nlm.nih.gov/articles/PMC3166406/) (Cynthia Aranow, 2021) [55:00]

**B vitamins and CVD: A 5,000-patient study on women over seven years showed no reduction in heart disease risk**: [Effect of Folic Acid and B Vitamins on Risk of Cardiovascular Events and Total Mortality Among Women at High Risk for Cardiovascular Disease A Randomized Trial](https://jamanetwork.com/journals/jama/fullarticle/181854) (Albert et al., 2008) [1:07:15]

**Study that showed a cardiovascular benefit of B vitamins in people with large homocysteine reductions (5+ micromol/L)**: [Folic Acid Supplementation and the Risk of Cardiovascular Diseases: A Meta‐Analysis of Randomized Controlled Trials](https://pmc.ncbi.nlm.nih.gov/articles/PMC5015297/) (Li et al., 2016) [1:07:15]

**A meta-analysis of five RCTs found that reducing homocysteine by at least 5 micromol/L led to an 18% reduction in major cardiovascular events (MACE)**: [Folic Acid Supplementation and the Risk of Cardiovascular Diseases: A Meta‐Analysis of Randomized Controlled Trials](https://pmc.ncbi.nlm.nih.gov/articles/PMC5015297/) (Li et al., 2016) [1:07:15]

**The VITACOG trial found that B vitamins slowed brain atrophy in patients with mild cognitive impairment (MCI) and the effect was strongest in those with high homocysteine levels**: [Homocysteine-Lowering by B Vitamins Slows the Rate of Accelerated Brain Atrophy in Mild Cognitive Impairment: A Randomized Controlled Trial](https://pmc.ncbi.nlm.nih.gov/articles/PMC2935890/) (Smith et al., 2010) [1:07:15]

**A meta-analysis****of 21 RCTs (~7,000 patients) found a small but significant effect of B vitamins on overall cognitive function**: [The preventive efficacy of vitamin B supplements on the cognitive decline of elderly adults: a systematic review and meta-analysis](https://bmcgeriatr.biomedcentral.com/articles/10.1186/s12877-021-02253-3) (Li et al., 2021) [1:07:15]

**Exact mechanisms of ashwagandha are unclear, but research suggests effects on GABAergic pathways – influences GABA, the brain’s main inhibitory (calming) neurotransmitter and HPA axis regulation – affects cortisol levels, potentially reducing stress**: [Sleep-promoting activity of amylase-treated Ashwagandha (Withania somnifera L. Dunal) root extract via GABA receptors](https://pmc.ncbi.nlm.nih.gov/articles/PMC10281725/) (Park et al., 2023) [1:15:30]

**Potential Cortisol-Lowering Effects of ashwagandha—an RCT found a 40% reduction in morning cortisol after 60 days of use**: [An investigation into the stress-relieving and pharmacological actions of an ashwagandha (Withania somnifera) extract: A randomized, double-blind, placebo-controlled study](https://journals.lww.com/md-journal/fulltext/2019/09130/an_investigation_into_the_stress_relieving_and.67.aspx) (Lopresti et al., 2019) [1:15:30]

**Some studies have found minor gastrointestinal (GI) issues in a small subset of users taking ashwagandha**: [Adjunctive Use of a Standardized Extract of Withania somnifera (Ashwagandha) to Treat Symptom Exacerbation in Schizophrenia: A Randomized, Double-Blind, Placebo-Controlled Study](https://www.psychiatrist.com/jcp/withania-somnifera-extract-for-schizophrenia-symptoms/) (Chengappa et al., 2018) [1:19:15]

**A meta-Analysis of people taking ashwagandha found moderate to favorable effects on overall sleep duration**: [Effect of Ashwagandha (Withania somnifera) extract on sleep: A systematic review and meta-analysis](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0257843) (Cheah et al., 2021) [1:19:15]

**Largest meta-Analysis on the effect of ashwagandha on stress & anxiety**: [Does Ashwagandha supplementation have a beneficial effect on the management of anxiety and stress? A systematic review and meta‐analysis of randomized controlled trials](https://www.researchgate.net/publication/362948981_Does_Ashwagandha_supplementation_have_a_beneficial_effect_on_the_management_of_anxiety_and_stress_A_systematic_review_and_meta-analysis_of_randomized_controlled_trials?enrichId=rgreq-3ba3705a085943cb60e61865a3a2f67b-XXX&enrichSource=Y292ZXJQYWdlOzM2Mjk0ODk4MTtBUzoxMTQzMTI4MTIzODAxOTM3NUAxNzEzODA2MTU1MjI5&el=1_x_3&_esc=publicationCoverPdf) (Akhgarjand et al., 2022) [1:19:15]

**A Consumer Lab Testing Report analyzed 13 ashwagandha supplements for accuracy and found that only 5 of 13 met the reported withanolide concentrations**: [Ashwagandha Supplements Review](https://www.consumerlab.com/reviews/ashwagandha-supplements/ashwagandha/) | Tod Cooperman, M.D. (consumerlab.com) [1:22:15]

---

## People Mentioned

- [Katherine Eban](https://www.katherineeban.com/about) [8:45]
- [Hussein Yassine](https://peterattiamd.com/husseinyassine/) [37:00]