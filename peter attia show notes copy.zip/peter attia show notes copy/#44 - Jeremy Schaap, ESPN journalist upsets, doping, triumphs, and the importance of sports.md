# #44 – Jeremy Schaap, ESPN journalist: upsets, doping, triumphs, and the importance of sports

**Source:** [https://peterattiamd.com/jeremyschaap/](https://peterattiamd.com/jeremyschaap/)

---

In this episode, Jeremy Schaap, preeminent journalist at ESPN, discusses two of the most incredible upsets in boxing history, both of which Jeremy has expertly covered during his illustrious career, most recently culminating in the 30 for 30 special, 42 to 1. We also discuss his infamous Bobby Knight interview, his coverage of the doping scandals in baseball and cycling, as well as the pressures of following in his father’s enormous footsteps who taught him the importance of fairness in journalism. Additionally, we also try to extract the deeper meaning of sports, what it teaches us, and how Jeremy uses sports reporting as a platform to bring light to greater societal issues.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/jeremyschaap/the_Drive_public.png)

Play

#44 - Jeremy Schaap, ESPN journalist: upsets, doping, triumphs, and the importance of sports

#44 - Jeremy Schaap, ESPN journalist: upsets, doping, triumphs, and the importance of sports

1x15s30s

0:001:41:38

## We discuss:

- Jeremy and Peter’s shared obsession with boxing history [5:15];
- Cinderella Man: The incredible upset of Max Baer by James Braddock, and the rise of the great Joe Louis [9:00];
- 42 to 1: Buster Douglas beats Mike Tyson for one of the most unlikely upsets in the history of sports [23:30];
- Contrasting fighting styles from “destroyers” to “artists”, and comparing the auras of the all-time greats [36:30];
- Mike Tyson’s take on the Douglas fight, what went wrong for Buster Douglas following his victory, and other incredible upsets in sports history [45:30];
- Ranking the greatest boxers since the 1960s [54:00];
- Jeremy’s famous Bobby Knight interview: A career defining moment [57:00];
- The pressures of following his father’s career path, and what it means to be a fair journalist [1:01:30];
- The meaning of sports: how it brings us together and gives us a platform for bigger discussions [1:11:00];
- Jeremy’s biggest regret in reporting, the 1998 home run chase, and the doping scandals of baseball and cycling [1:17:30];
- The biggest and most underreported stories in sports [1:26:45];
- Best 30 for 30 episodes: Jeremy and Peter pick their favorites [1:31:30];
- Baseball: Steroids and the hall of fame [1:34:30];
- Final thoughts on what makes sports so special [1:37:45]; and
- More.

§

## Show Notes

## Jeremy and Peter’s shared obsession with boxing history [5:15]

- Peter and Jeremy are both obsessed with the history of boxing
- However, Jeremy admits that boxing has “lost a lot of its luster over the last several decades”

Jeremy’s history of covering boxing

- Jeremy was a ringside reporter for some time
- Assigned to cover [Mike Tyson](https://en.wikipedia.org/wiki/Mike_Tyson) for about 10 years (1995-2005)
- Mike Tyson final fight was against [Kevin McBride](https://en.wikipedia.org/wiki/Kevin_McBride)

Peter’s obsession

- “I had an almost ridiculous obsession going back to about [Jack Johnson](https://en.wikipedia.org/wiki/Jack_Johnson_(boxer)) to [Jack Dempsey](https://en.wikipedia.org/wiki/Jack_Dempsey) to [Joe Louis](https://louis) to [Rocky Marciano](https://en.wikipedia.org/wiki/Rocky_Marciano) to [Muhammad Ali](https://en.wikipedia.org/wiki/Muhammad_Ali).”
  - All heavyweights
- [Robinson](https://en.wikipedia.org/wiki/Sugar_Ray_Robinson)
- [Amstrong](https://en.wikipedia.org/wiki/Henry_Armstrong)

Jeremy grew up watching his father, [Dick Schaap](https://en.wikipedia.org/wiki/Dick_Schaap), covering boxing

> “These guys were such big stars and so many of them were outsize personalities and there was nothing else in sports that even approached the significance of the heavyweight championship of the world. That was it.”

## Cinderella Man: The incredible upset of Max Baer by James Braddock, and the rise of the great Joe Louis [9:00]

![](https://peterattiamd.com/wp-content/uploads/2019/03/Cinderella-Man-cover-665x1024.png)

**Figure 1. Cover of Cinderella Man.**Image credit: [amazon.com](https://www.amazon.com/Cinderella-Man-Braddock-Greatest-History/dp/0618711902/ref=sr_1_1?keywords=cinderella+man+book&qid=1552072940&s=gateway&sr=8-1)

**Jeremy’s book**: [Cinderella Man: James J. Braddock, Max Baer, and the Greatest Upset in Boxing History](https://www.amazon.com/Cinderella-Man-Braddock-Greatest-History/dp/0618711902)

“I decided to make it kind of a dual biography as they are on this collision course towards this heavyweight showdown in 1935.”

[Max Baer](https://en.wikipedia.org/wiki/Max_Baer_(boxer))

- Fighting [Frankie Campbell](https://en.wikipedia.org/wiki/Frankie_Campbell) in 1930, Baer delivered a [punch that ultimately killed Campbell](https://www.boxing.com/baer_vs._campbell_the_fight_that_turned_into_a_nightmare.html)
- Baer was devastated and never quite the same after this
- He was blamed later-on for another death, [Ernie Schaaf](https://en.wikipedia.org/wiki/Ernie_Schaaf)
- Max Baer handily beats [Primo Carnera](https://en.wikipedia.org/wiki/Primo_Carnera) in 1934 becoming the World Heavyweight Champion
- Baer is looking invincible leading up to Braddock fight

[James Braddock](https://en.wikipedia.org/wiki/James_J._Braddock)

- Previously a light heavyweight contender in the 1920s
- Been out of the fight game for awhile
- He’s hurt, broken hand so he can’t make money fighting
- He is working on the docks, living in poverty and humiliated to be taking government assistance
- He’s finished, he’s done, people thought
- But working on the dock built up his strength in a unique way
- “It sounds like some kind of fairytale or something, make, prepare him in a way he hadn’t been prepared to seize the moment.”
- Upsets an up-and-comer, John Corn Griffin
- Beats a couple more impressive fighters, and sets up a showdown with Max Baer

Lopsided odds

- Braddock was a huge underdog, ~10 to 1 odds
- “The most lopsided odds ever in a heavyweight championship fight”
- Braddock weighs in around ~193 lb
- Baer was 250 lbs and “he is ripped in a way that athletes were not ripped like that in that era.”

[Braddock pulls off the upset](https://en.wikipedia.org/wiki/James_J._Braddock#Max_Baer_fight)

- Braddock was desperate in a way that you don’t usually see
- Baer on the other hand seemed unmotivated in a way
- Braddock was saying, “I’m not losing this fight. . .there is no way”
- He was fighting for his life, his honor, his family, he was fighting for something much more beyond him
- Braddock was a guy who had been broken and it was unthinkable that he would be fighting for the heavyweight championship
- He inspired so many people. There were so many people pulling for him but nobody really thought that he had a chance against Max Baer who was five years younger.

> “What I think Jim Braddock embodies is this idea, whether or not you buy into it, is that there is something noble about that sport and about the commitment required and about the dedication and about its code. The code of personal courage, of total commitment, of believing there’s something honorable about fighting until you’ve got nothing left. None of that stuff mattered to Max Baer.”

Braddock’s title defense and retirement

⇒ Title defense

- [He loses to Joe Louis](https://en.wikipedia.org/wiki/James_Braddock_vs._Joe_Louis) ⇒ here’s the [fight on YouTube](https://www.youtube.com/watch?v=deMl1Hh_NGs)
- But it was a good fight, Braddock knocks Lewis down in the first round
- Braddock went down with a fight… saying things like [paraphrase], “If he’s going to take my title, he’s going to damn near almost take my life.”

⇒ Retirement

- He won a final fight against [Tommy Farr](https://en.wikipedia.org/wiki/Tommy_Farr) in 1937
- Retired afterward

**The rise of** [**Joe Louis**](https://en.wikipedia.org/wiki/Joe_Louis) **[21:00]**

- [Joe Louis beat Braddock](https://en.wikipedia.org/wiki/James_Braddock_vs._Joe_Louis) at age 23
- Remained champion for 12 years with 25 title defenses
- “the most dominant heavyweight in the history of the sport”

⇒ [Rematch with Max Schmeling in 1938](https://en.wikipedia.org/wiki/Joe_Louis_vs._Max_Schmeling)

- “One of the most remarkable fights ever”
- Louis breaks a bone in Schemling’s vertebrae in the first round

⇒ [Louis vs. Max Baer in 1935](https://boxrec.com/media/index.php/Joe_Louis_vs._Max_Baer) ([video](https://www.youtube.com/watch?v=VeHSseSpTvY))

CORRECTION: Peter remembered Louis fighting Max Baer *after* Louis had become champion, but this fight actually occurred in 1935 before Louis beat Braddock for the title in 1937

- Louis beats Baer with a big left hook which brought Baer to his knees
- When asked about not getting up, Max replied, “I could have struggled up once more, but when I get executed, people are going to have to pay more than twenty-five dollars a seat to watch it.” [credit: [boxrec.com](https://boxrec.com/media/index.php/Joe_Louis_vs._Max_Baer)]

![](https://peterattiamd.com/wp-content/uploads/2019/03/max-baer-on-knee--1024x635.png)

**Figure 2. Max Baer kneeling down getting counted out against Joe Louis.** Image credit: [YouTube: Levi Johansen](https://www.youtube.com/watch?v=VeHSseSpTvY)

Death of Max Baer

- [Died at 50 from a heart attack](https://en.wikipedia.org/wiki/Max_Baer_(boxer)#Death)
- Always a jokester, Max’s famously said [“Oh God, here I go.”](https://web.archive.org/web/20070821202334/https://www.maxbaer.org/theman.html) during his heart attack

## 42 to 1: Buster Douglas beats Mike Tyson for one of the most unlikely upsets in the history of sports [23:30]

[**42 to 1 – ESPN Films: 30 for 30**](https://www.espn.com/30for30/film?page=42to1) **by Jeremy Schaap**

- The story of [Buster Douglas](https://en.wikipedia.org/wiki/Buster_Douglas) beating Mike Tyson in 1990
- Amazing parallels between underdog stories of Braddock and Buster Douglas
  - “They’re the two greatest underdogs in heavyweight championship history”
- 42 to 1 were the odds against Douglas
- Fight was to occur just weeks after his mother passed away
- Jeremy’s reaction to hearing that Douglas had won: *“No, it can’t be. It can’t possibly be. Could not have possibly occurred.”*

**The famous 9th round**

Other famous rounds that compare:

- [Round 10 of Riddick Bowe versus Evander Holyfield](https://www.youtube.com/watch?v=6GngvYoqQj4)
- [Round 1 of Marvin Hagler vs. Thomas Hearns](https://www.youtube.com/watch?v=5s--I8BsgDU) ⇒ “That’s what got me into boxing”, says Peter, “April 1985 was when I decided I wanted to be the middleweight champion of the world”

The most impressive beating taken by Tyson

- [Teddy Atlas made a really interesting point on the Joe Rogan Podcast](https://www.youtube.com/watch?v=3wCZY_vW860)… [paraphrased]… “You know Tyson’s never won a fight in his life because every fight he won, technically, the opponent was beat before they got in the ring. Every fight he lost is because the guy came in and wasn’t afraid.”
- Douglas was in many ways the most impressive of those because he was the first one to beat him, says Peter

Tyson’s losses

- [Buster Douglas](https://en.wikipedia.org/wiki/Buster_Douglas) in 1990
- [Holyfield](https://en.wikipedia.org/wiki/Evander_Holyfield) in 1996
- Holyfield in 1997 (the famous [ear biting incident](https://www.youtube.com/watch?v=zKPMVex-UKk))
- [Lennox Lewis](https://en.wikipedia.org/wiki/Lennox_Lewis) in 2002
- [Danny Williams](https://en.wikipedia.org/wiki/Danny_Williams_(boxer)) in 2004
- [Kevin McBride](https://en.wikipedia.org/wiki/Kevin_McBride) in 2005

*But the Douglas victory was on a different level…*

- Because it’s the first . . . *“He gave us the blueprint.”*
- And it was Mike Tyson at 23, not Mike Tyson after prison
- It was the Mike Tyson who had [annihilated Michael Spinks](https://www.youtube.com/watch?v=HuaFIRD7_5Y) and [humiliated Larry Holmes](https://www.youtube.com/watch?v=W8RQyP_BdOE)
- He was 37-0 with 34 knockouts

> “The thing about the Buster Douglas story. . .it was such a transcendent sports moment. . .and people don’t get it. They don’t want to give Buster credit. They want to say it was a one-hit wonder or he got lucky with a punch. Or that he didn’t deserve to even be in the same ring with Mike Tyson. He doesn’t get lucky. . .it is a butt kicking.”

Boxing is a cruel sport

- “If you’re the third best middleweight in the world, but you’re not the best. . .nobody knows you.”
- Approaching his fight with Tyson, Douglas was given no shot despite impressive victories against [Greg Page](https://en.wikipedia.org/wiki/Greg_Page_(boxer)) and [Oliver McCall](https://en.wikipedia.org/wiki/Oliver_McCall)
- Douglas had even been called a quitter for a loss he took to [Tony Tucker](https://en.wikipedia.org/wiki/Tony_Tucker) in which he was winning on points but ran out of gas in the 10th round

Buster’s disposition and relationship with his mother

- Buster was really close to his mother, and when she passed away, there was thought that the fight might be postponed or cancelled
- I remember thinking, oh man, they’re going to have to postpone the fight and he’s never going to get his shot. I remember just feeling kind of sorry for Douglas. I at least wanted him to get paid. You know what I mean? Like at this point it’s like at least you deserve a couple million bucks because you’ve been through all of this stuff.
- Bruce Trampler, the former manager of Buster’s father said, “I thought he should pull out. I didn’t see how he could possibly have enough focus after his mother’s death to get in the ring.”
- Peter points out a beautiful part of the 42 to 1 film where a reporter, [Al Bernstein](https://en.wikipedia.org/wiki/Al_Bernstein), asks Buster’s mother is she is proud her son… “It was this beautiful look on Douglas’ face as he looks at his mom saying how proud she is of him.”
- His disposition was more like his mother, Lula Pearl
- “He was not the stone cold killer that his father, Bill Douglas, was in the ring.”
- “Bill Douglas fought with the same style [as Tyson], the same commitment and the same determination to not just win but to destroy. And that wasn’t Buster.”

## Contrasting fighting styles from “destroyers” to “artists”, and comparing the auras of the all-time greats [36:30]

Peter recalls reading a [Sports Illustrated article in 1988](https://www.si.com/vault/2016/06/13/tyson-timid-tyson-terrible) where the author boldly claimed that Tyson wasn’t going to have a long career… [paraphrased]…*“The flames that burn this bright burn out really quick. . .this is not a guy who’s going to have a long career. He is going to implode.”*

- Here’s the [issue with Larry Bird on the cover](https://www.si.com/vault/issue/702648/0) (last article of the issue)
- Here’s a direct link to the article: [TYSON THE TIMID, TYSON THE TERRIBLE](https://www.si.com/vault/2016/06/13/tyson-timid-tyson-terrible)
- At the time, 13-year old Peter thought the author was an idiot, but of course the author was right

Contrasting styles: The destroyers vs. the artists

Examples of destroyers…

- [Sonny Liston](https://en.wikipedia.org/wiki/Sonny_Liston)
- [Jack Dempsey](https://en.wikipedia.org/wiki/Jack_Dempsey)
- [George Foreman](https://en.wikipedia.org/wiki/George_Foreman)
- [Mike Tyson](https://en.wikipedia.org/wiki/Mike_Tyson)

Examples of artists…

- [Joe Louis](https://en.wikipedia.org/wiki/Joe_Louis)
- [Muhammad Ali](https://en.wikipedia.org/wiki/Muhammad_Ali)

Peter’s take:

“The ones that have had the really, really long careers, there’s something different about it. There is something different about their ethos. They’re a different type of person. They’re not killers. And it’s not to say they’re gentlemen versus killers but it’s just they’re artists in a way that I think some of the most destructive and feared fighters were not.”

Jeremy’s take:

“If you fall in love with your right hand and the knockout in particular, you’re going to get lazy and you’re going to get one dimensional and you’re going to get exposed eventually. There are enough good fighters out there who can box who bring other skills to bear. If you’ve got some kind of deficiency, they’re going to locate it. They’re going to find it. They’re going to wear you down…

…and if you are being hailed as the destroyer, as the guy who can do everything and can get it done with one punch, you’re not going to be listening the same way to your trainer, to Kevin Rooney or Teddy Atlas or Aaron Stowell, in the same way if you’ve had some challenges.”

**Comparing auras of the all-time greats [40:15]**

Tyson’s aura

Do you believe that Tyson’s aura was greater than that of [George Foreman](https://en.wikipedia.org/wiki/George_Foreman)‘s and [Sonny Liston](https://en.wikipedia.org/wiki/Sonny_Liston)‘s at their respective times?

- “I think so because…the fashion which he did it to so many different guys, I think it was bigger. I think it was more impressive with Tyson at that time. And it was also his own way of speaking about things. His story, where he came from.”

Joe Louis’s aura

- His story, while impressive and probably one of the top 3 boxers of all time, he *did not* have the same aura as Tyson
- Unlike Tyson, Louis had a blemish on his record since he had been [knocked out by an aging Schmeling](https://en.wikipedia.org/wiki/Joe_Louis_vs._Max_Schmeling) before he went on to beat Braddock for the heavyweight title

Jack Dempsey’s aura

- Dempsey has a similar aura to Tyson, says Jeremy
- “Dempsey’s a destroyer and there was this cloak of menace.”
- He fought hundreds of fights as basically a semi-pro in mining camps in Colorado and the toughest possible atmosphere you can imagine. A lot of it was barefisted and no holds barred.
- “Dempsey fights are some of the most amazing things you can watch.”

The 2 biggest sports events of all time, per Jeremy

1. [Dempsey vs. Gene Tunney II at Soldier Field ⇒ “The Long Count”](https://en.wikipedia.org/wiki/Gene_Tunney) ([video](https://www.youtube.com/watch?v=-OeeCfbahwQ))
2. [Ali vs. Frazier 1 in 1971 ⇒ “Fight of the Century”](https://en.wikipedia.org/wiki/Fight_of_the_Century) ([video](https://www.youtube.com/watch?v=Jt-vjZTVLV0))

![](https://peterattiamd.com/wp-content/uploads/2019/03/Ali-walking-through-Central-Park-1971.jpg)

**Figure 3. Ali walking through Central Park in 1971 prior to the “Fight of the Century”.** Image credit: [nytimes.com](https://www.nytimes.com/2016/06/04/sports/as-butterfly-or-as-a-bee-muhammad-ali-always-made-an-impression.html)

Peter’s brings up another huge fight:

- [Tyson vs. Spinks in 1988 in Atlantic City](https://en.wikipedia.org/wiki/Mike_Tyson_vs._Michael_Spinks) ([video](https://www.youtube.com/watch?v=HuaFIRD7_5Y)) ⇒ “The most anticipated fight in the heavyweight division since 1971.”

## Mike Tyson’s take on the Douglas fight, what went wrong for Buster Douglas following his victory, and other incredible upsets in sports history [45:30]

Peter asks why Tyson wasn’t interviewed for the 42 to 1 documentary:

- Ultimately, Jeremy wanted the focus to be on Buster’s story
- “At one point we had a cut of the film where we had a lot of it and … we made an artistic decision essentially at that point that we wanted to see Mike only in context from the time of the fight.”
- Probably the best bite we had from that [E:60 interview](https://vimeo.com/226342185) is something where he said, “Look, was Buster Douglas a better fighter that morning, that afternoon? Yes. Does that mean that he’s a better fighter than me? No.”
- “I think he feels if he’d approached that fight with full commitment he would have won it. But, of course he’s going to think that.”

Has there ever been a bigger upset than Douglas over Tyson?

- Possibly, people might say…
  - [Miracle on Ice](https://en.wikipedia.org/wiki/Miracle_on_Ice) ⇒ “not even within a country mile” in terms of underdog victories at the Douglas upset
  - [Leicester City winning the Premier League](https://sportsworld.nbcsports.com/leicester-city-premier-league-champions/) at 5000 to 1 odds ⇒ “But to me that’s totally different. There wasn’t a single game that season”

> “I think his feelings have been hurt because people for so long have tried to diminish his victory. And there are so many avid Mike Tyson fans who always want to make excuses for him, who always want to discredit Buster for whatever reason. I felt like he had not been fully appreciated for the magnitude of this.”

**What went wrong for Buster after Tyson?**

*Why do you think he didn’t show up in shape for his next fight against Holyfield?*

- Buster was a very skilled boxer and he was a very good athlete
- He was schooled in the sport and when he was fully dedicated and committed which we saw only on a few occasions, he was very tough to beat.
- I don’t think anybody, I don’t care if it’s Jack Dempsey or [Gene Tunney](https://en.wikipedia.org/wiki/Gene_Tunney) or [John L. Sullivan](https://en.wikipedia.org/wiki/John_L._Sullivan) himself would have beaten him in Tokyo that day. I really don’t think so.
- But, after he defeats Tyson everything is just so chaotic
- Too much, too fast, too many people pulling at him
- Distracted by [court cases with Don King](https://law.justia.com/cases/federal/district-courts/FSupp/742/741/1689300/) protesting the referee’s knockdown count in the eighth round
- He signs at the time for $24 million to fight Holyfield. ⇒ Largest purse in the history of sports
- “I think his motivation was gone. I think the reality of his mother’s death sunk in. When she died he had the fight to focus on. Now he’s got this complicated, weird relationship at times with his father.”
- “There’s all kinds of crazy stuff going on. He doesn’t … I think Buster would be the first to admit he doesn’t show up for that fight. Physically. Mentally. Motivationally.”

**The lonely and scary ring**

Peter:

*“There’s something about boxing that I guess this is part of what attracted me to it as a participant and then eventually always just as a fan. And maybe I have a slightly different insight into it because I’ve done it, but the ring is a really lonely place. It’s hard to put in words what the fear is like when you get in the ring. Again, maybe it’s just that that was just who I was and maybe there are some people who get in the ring and they’re not afraid.”*

*“Even Tyson once said [paraphrase], ‘Anybody who gets in a boxing ring and who is not scared senseless is lying or crazy.’”*

*“There are no words to describe that anxiety. There’s nothing I’ve ever experienced since. No professional thing I’ve ever done that has put that much adrenaline into my body that borders on the point of being like you’re on the verge of it being unproductive.”*

## Ranking the greatest boxers since the 1960s [54:00]

**From the 1960s up until today, who have been the top fighters?**

- [Muhammad Ali](https://en.wikipedia.org/wiki/Muhammad_Ali) ⇒ obviously
- [Larry Holmes](https://en.wikipedia.org/wiki/Larry_Holmes) ⇒ “He’s got to be in there”
- [Lennox Lewis](https://en.wikipedia.org/wiki/Lennox_Lewis) ⇒ “Got to be in there”
- [Klitschko brothers](https://en.wikipedia.org/wiki/Klitschko_brothers) ⇒ “They were very tough guys, the Klitschko brothers.”

Current fighters mentioned:

- [Deontay Wilder](https://en.wikipedia.org/wiki/Deontay_Wilder) ⇒ undefeated, current heavyweight champion, “It was so amazing to me to see a guy like Deontay Wilder. . .this is a guy who’s [only] 212 pounds who’s arguably the best heavyweight in the world.”
- [Tyson Fury](https://en.wikipedia.org/wiki/Tyson_Fury) ⇒ recent challenger of Wilder which ended in a draw

## Jeremy’s famous Bobby Knight interview: A career defining moment [57:00]

Jeremy’s famous [interview with Bobby Knight](https://www.youtube.com/watch?v=ZNxKeCLfJqs) after he was fired by Indiana in 2000

Peter on Bob Knight:

- Peter is not fond of Bob Knight: “he just strikes me as just a deplorable human being”
- This [30 for 30 on Bob Knight](https://www.espn.com/30for30/film?page=lastdaysofknight) only solidified Peter’s opinion

Jeremy on Bob Knight:

- Bob Knight was a friend of Jeremy’s father
- Jeremy had always appreciated Knight’s “genius”

**The interview:**

*How many days after he was fired was the interview?*

- 72 hours later

*Why did he give you that interview?*

- “I think he gave me that interview because he thought he could steamroll me.”

*What do you think is the moment memorable exchange of that interview?*

- “That’s indisputable” ⇒ (starting around [24:10](https://www.youtube.com/watch?v=ZNxKeCLfJqs&feature=youtu.be&t=1450))
- They were having a talk about the zero tolerance policy which is what ultimately lead to his termination
- He’s explaining tell me how he doesn’t know what zero tolerance meant and nobody ever defined it for him.
- He was put in a lose/lose situation.
- He says the real victim here is Pat, his son, who was one of the assistant coaches and is going to lose his job
- I feel it’s my obligation at this point to point out and say, “Bob, but Pat wouldn’t be losing his job if you had behaved yourself.”
- And that’s when he got very angry
- He glared at me and he said, [“Be careful here. You’ve got a long way to go until you’re as good as your dad.”](https://youtu.be/ZNxKeCLfJqs?t=1450)

Jeremy didn’t back down

- I had just turned 31 and this is the biggest thing that’s going on. Not just in sports but in America period at this moment in time. It really was. I knew I had to get it right. I knew the stakes were high.
- “They said, ‘Schaap stood up to Knight. He didn’t let the bully, bully him.’ I asked the right questions. I got to the important points.”

> “But at the time for me it was like kind of a career-defining moment. All of a sudden it was like welcome to the big leagues.”

## The pressures of following his father’s career path, and what it means to be a fair journalist [1:01:30]

![](https://peterattiamd.com/wp-content/uploads/2019/03/jeremy-and-dick-schaap.jpg)

**Figure 4. Jeremy with his father, Dick Schaap.** Image credit: [adweek.com](https://www.adweek.com/tv-video/jeremy-dick-schaap-journalism-advice/)

**Decision to follow his father’s (**[**Dick Schaap**](https://en.wikipedia.org/wiki/Dick_Schaap)**) career path**

- Jeremy grew up around his father’s work
- On the weekends he went to the office with my father while he prepared sports stories and sports reports for NBC
- “It was almost like my entire life had been an apprenticeship in the business.”

Peter asks: *You weren’t worried about the shadow?*

- “Maybe I should have been but I don’t think I ever gave it a second thought. I know that sounds ridiculous.”

Peter’s compares himself to his father:

- Peter says he compares his own work ethic to his father’s
- “I don’t think I can work as hard as my dad and deep down it makes me feel a little bit ashamed.”
- “My father’s never been in a bad mood. He’s the most upbeat, positive, optimistic, immigrant that ever lived.”
- “ I really can only compare myself to my father in terms of work ethic, sacrifice and just general disposition. But now you have all those things to compare yourself to plus being the son of one of the most legendary sportscasters of all time.”

Jeremy:

- “I got to say though it really is a testament I guess to my naiveté or just stupidity that I got into this business without really thinking about that. I just knew that I wanted to be in the media. I wanted to work in TV. I wanted to be a writer.”
- “I grew up around a guy who I really think was the best at what he did. He was a great writer. He was a great journalist. He was a great TV storyteller. I figure well if he could do it, I could do it.”

**What is means to be a fair and honest reporter**

⇒ Peter recently read [an article where Jeremy discusses fairness in reporting](https://www.sportsonearth.com/article/230229096/jeremy-schaap-interview-e60-espn-sports-media) being a lesson he learned from his father

Paraphrasing Jeremy’s answer in the interview, Peter says:

*“Fairness means you do have to ask hard questions and you do have to probe in areas that are uncomfortable. But, you’ve got to have a bit of empathy. You have to be able to put yourself in the shoes of the person you’re speaking with. . .. I feel like that doesn’t exist all that much in journalism anymore, does it? . . . The way you described it was very beautiful and you really attributed it all to your father.”*

Jeremy:

*“Yeah, and I think he did operate in that manner. It wasn’t just idle talk. It was what informed his body of work. I work in a business where there are people who all about access. They never ask the tough questions. Then . . . there are people in the business [who are] tough for the sake of being tough.”*

> “I think I’ve built a reputation 30 years in the business of being the guy who does ask the tough questions and doesn’t shy away and is willing to sacrifice relationships for the truth. That’s important, but fairness is the underpinning of everything, right? It’s not just about being fair to the subject. It’s about being fair to the audience. It’s about being fair to the story and fair to the truth.”

[**Dick Schaap**](https://en.wikipedia.org/wiki/Dick_Schaap)

- Passed away unexpectedly during an elective hip operation
- Jeremy was 32 years old
- “It was devastating. I was extremely close with my father.”

9/11 attack on NYC

- Dick Schaap died shortly after the 9/11 attack on NYC
- Schaap’s final regular television appearance was on the September 16, 2001 broadcast of The Sports Reporters on the Sunday after the September 11, 2001 terrorist attacks on New York City
- “There is that surreal grief-stricken moment as well in the history of the city and the country so it all feels like a bad dream. “

His father’s death was difficult on many levels

- Dick’s condition was playing out in public
- The 9/11 attack just a few miles away from the hospital where Dick was in the ICU
- Dick was coming in and out of a coma and at times it looked like he was going to make it

## The meaning of sports: how it brings us together and gives us a platform for bigger discussions [1:11:00]

*Following the collective experience of the loss of your father, which is literally superimposed on 9/11, did that cause Jeremy to revisit his connection to and feelings toward sports?*

- Jeremy remembers a discussion he had with [Keith Olbermann](https://en.wikipedia.org/wiki/Keith_Olbermann) after 9/11 where they were wondering if sports was ever going to be meaningful anymore
- He was telling me, “We can’t be in sports anymore. Everything is over. Everything we’ve known is changed. Nothing will ever be the same. The country’s going to be under constant attack.”
- Jeremy felt unable to process much at that moment: “Everything was discombobulated. We didn’t know where we stood anymore in some regards.”
- “But no, I don’t remember reassessing my relationship with sports in that moment except I did have an immediate reaction to the whole idea that sports was going to make everything better and if the Yankees won the World Series, which they ended up losing, I thought it would be a few minutes of catharsis.”

*Peter describing what he loves about sports and what Jeremy does:*

- “People like you provide a narrative that gives us who don’t know as much a nuanced understanding.”
- “You won’t find a bigger ESPN 30 for 30 fan than me…I love that type of deep exploration. The story behind the story behind the story.”

*What do you think that does for people (outside of the obvious which is that it teaches you about a sporting event)?*

- “It brings us all together.”
- “You can have discussions with sports with people anywhere.”
- “It’s gotten harder to have discussions about other things as we know.”

Using sports as a platform for bigger discussions:

- “I’ve used sports as a platform to tell stories about other things going on in the world that transcend sports. About societal issues. About cultural issues. About crisis of sexual abuse, homophobia, whatever they are.”
- “Sports does that in a way that other things don’t because so much of us are interested in sports.”

⇒ Jeremy did a [story about Al Campanis](https://www.espn.com/espn/otl/story/_/id/7751398/how-al-campanis-controversial-racial-remarks-cost-career-highlighted-mlb-hiring-practices)

- It was on the 25th anniversary of the time of his [infamous Nightline interview](https://www.youtube.com/watch?v=O4XUbENGaiY) where he made racist remarks while being interview by [Ted Koppel](https://en.wikipedia.org/wiki/Ted_Koppel)
- Referring to Ted Koppel, Jeremy says: “He was so great in that moment and he was so fair but persistent and tough … but my point is that that moment, it sparked a discussion about a lot more than sports.”

## Jeremy’s biggest regret in reporting, the 1998 home run chase, and the doping scandals of baseball and cycling [1:17:30]

Jeremy was the guy covering the [1998 home run chase with Mark McGwire and Sammy Sosa](https://en.wikipedia.org/wiki/1998_Major_League_Baseball_home_run_record_chase)

> “Looking back now. . .I wish I had approached that story with more skepticism.”

- [Mark McGwire](https://en.wikipedia.org/wiki/Mark_McGwire) and [Sammy Sosa](https://en.wikipedia.org/wiki/Sammy_Sosa) were chasing [Roger Maris](https://en.wikipedia.org/wiki/Roger_Maris)’s record of 61 home runs in a single season
- [McGwire ended up breaking Roger Maris’s record](https://www.youtube.com/watch?v=M7dvnl9AtP8)
- Many years later [admitted he was using steroids](https://www.cbsnews.com/news/mark-mcgwire-admits-using-steroids/)

*Do you think you were just so caught up in the moment like you couldn’t believe this was happening?*

- People had been wondering if McGwire was using steroids for years
- The subject was kind of taboo
- Then the “[andro story](https://www.nytimes.com/1998/08/22/sports/baseball-mcgwire-admits-taking-controversial-substance.html)” seemed to put everything to rest
  - A substance called androstenedione (at the time a legal supplement) was found in McGwire’s locker
  - So people thought, “he’s not using steroids”, he’s using this legal substance
- “So, in the absence of evidence that he was cheating we just kind of bought the story. . .I wish I had been more skeptical.”

Covering cycling and [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong)

- Jeremy says that after the homerun chase, he was more skeptical of Lance Armstrong when covering the Tour de France
- He asked the tough question about EPO, even after Lance had denied it

The home run scandal vs. the cycling scandal

- “I’m probably biased, but I find the cycling “scandal” to be less upsetting because it really was a uniform playing field.” says Peter
- Baseball is more sad because people tend to forget about the amazing feat of Roger Maris in breaking Babe Ruth’s record
- “This was Roger Maris’ legacy, that record, the 61 and it was stolen from him.” says Jeremy

**When did doping start in cycling?**

*Peter’s take:*

- Looking at watts per kilo, Peter says you can see that he must’ve started doping after 1993
- [Tyler Hamilton](https://en.wikipedia.org/wiki/Tyler_Hamilton) came out in 2011 and admitted to doping and said that everyone else was as well⇒ “But to me, Tyler was the most credible cyclist to come forward.”
- And Peter was then convinced that they were all doing it

*But there was no proof says Jeremy:*

- “[WADA](https://en.wikipedia.org/wiki/World_Anti-Doping_Agency) couldn’t bust them. The [Cycling Federation](https://en.wikipedia.org/wiki/Swedish_Cycling_Federation) couldn’t bust them. The French couldn’t bust them. The Spanish couldn’t bust them. They had a very sophisticated … and almost clownishly brazen in some ways. They were so good at concealing it and they were so aggressive about going after anybody who questioned them.”

*Given the ubiquity of doping in cycling, Peter believes there was an even playing field and championships shouldn’t be stripped away from people:*

- “This will be the single most unpopular thing I will ever say I’m sure. I absolutely believe Lance Armstrong deserves his yellow jerseys back because if you’re going to take his away, you’d better take away [Pantani](https://en.wikipedia.org/wiki/Marco_Pantani)‘s. You’d better take away [Ullrich](https://en.wikipedia.org/wiki/Jan_Ullrich)’s and you’d better take away [Bjarne Riis](https://en.wikipedia.org/wiki/Bjarne_Riis)’s and probably [Miguel Indurain](https://en.wikipedia.org/wiki/Miguel_Indur%C3%A1in)’s.”

*Still doping in cycling?*

- Peter says, “I think it’s interesting today to look at cycling because to be honest with you, I’m too far away from the sport and the numbers and they’re still very concealed in what they do. But, I still think there’s something going on I just don’t know what it is.”

## The biggest and most underreported stories in sports [1:26:45]

**Biggest story**⇒ The [head trauma in the football](https://time.com/4871597/degenerative-brain-disease-cte-football/)

- “I think the biggest story in the last 20 years in sports.”

⇒ What has been the impact?

- It’s had a big impact
- Youth participation in tackle football in certain parts of the country are plummeting
- If that continues, it’s a time question until college football starts to decline

⇒ What does the NFL look like in 20 years?

- That’s the million-dollar question
  - Does football have an existential problem?
  - Or will the game change in order to alleviate concerns about the long-term effects of head trauma?
- What we do know is that everything changes, but in the moment it seems like nothing will change
- People may think that the NFL will always be number one
  - That’s probably how it felt to fans of baseball 60 years ago
  - Or fans of boxing in the 1930s

**Underreported story** ⇒ The use of [human growth hormone (HGH) in sports](https://en.wikipedia.org/wiki/Growth_hormone_in_sports)

- HGH is undetectable in drug testing
- So it’s hard to know who is actually “clean”

⇒ Peter’s intuition:

- He thinks swimming is mostly clean but that track and field is “always going to be full of growth hormone”
- “I don’t have a lot of experience with it even clinically to know how effective it is, but I think it’s used pretty rampantly. My intuition is that in most sports, it’s got to be the drug of choice right now. And I think from my standpoint the interest is, do we have any sense of what the long-term harm is? Which I don’t pretend to know.”

## Best 30 for 30 episodes: Jeremy and Peter pick their favorites [1:31:30]

[The Two Escobars](https://www.espn.com/30for30/film?page=the-two-escobars)

- “That was so heartbreaking” says Peter
- 1994
- Jeremy attended the match in person

[The Last Days of Knight](https://www.espn.com/30for30/film?page=lastdaysofknight)

- The story of Bobby Knight

[The Two Bills](https://www.espn.com/30for30/film?page=TheTwoBills)

- About Bill Parcells and Bill Belichick

[You Don’t Know Bo](https://www.espn.com/30for30/film?page=you-dont-know-bo)

- “I almost forgot how athletic that guy was. You could make the case he’s the greatest athlete ever.” says Peter
- Dick Schaap voted for him as the [greatest athlete in the 20th century in the SportsCentury polling](https://www.baseball-reference.com/bullpen/SportsCentury)

## Baseball: Steroids and the hall of fame [1:34:30]

*When is* [*Barry Bonds*](https://en.wikipedia.org/wiki/Barry_Bonds) *going to admit he did steroids?*

Peter says, “Can’t we just have an open and honest discussion about it and close the chapter?”

Jeremy says,

- “From Barry’s perspective, what does he have to gain?
- “I don’t think he cares. I don’t think he has any interest in creating closure for us.”
- ⇒ Watch [Sammy Sosa continue to deny using PEDs](https://youtu.be/qvABmOzp5Jc?t=18)

*Peter’s take on steroids in baseball and the hall of fame:*

- “I’m going to create a lot of enemies by saying this, but I wish that Barry Bonds could just acknowledge what he did and get into the Hall of Fame and be done with it and we could acknowledge that that was the era that we were in. A lot of people would find that a very controversial view.”

⇒ The argument for it:

- [Roger Clemens](https://en.wikipedia.org/wiki/Roger_Clemens) and Barry Bonds, for example, are different because they were Hall of Fame players *before* they started taking steroids (although of course we don’t know when they started taking steroids)

⇒ The argument against it:

- “But they’re being kept out because they desecrated the record book in the minds of the voters by cheating. They broke faith with the history of the game and the record book and all that. They made a mockery of these hallowed numbers which mean so much in baseball not other sports.”
- [Joe Jackson](https://en.wikipedia.org/wiki/Shoeless_Joe_Jackson), for example…
  - One of the greatest hitters of all time, but he tried to “fix” the [1919 World Series](https://en.wikipedia.org/wiki/1919_World_Series)
  - Nobody is disputing that he was a hall of fame player, but “**it’s what you did at that moment that disqualifies you.”**

*Peter’s quick take on the cycling record books:*

- “I think you can’t do grand tours without drugs, and we’ve had a 20-year period from call it 1991 to 2011 when the drug use was simply comical and what do we do with those years?”

## Final thoughts on what makes sports so special [1:37:45]

Peter:

*“I just think that I have a complicated relationship with sports. Sometimes I feel guilty for caring. Sometimes I feel like why do I care so much about this? Why am I not caring more about something else that ‘matters more’? But in the end I think why I care about sports is they are basically the substrate for some of the greatest metaphors we have in life.*

*When I think about why I want my kids to play sports, it’s not because I think any one of them will ever be a professional athlete. It’s because of what they learn about themselves in this quest.”*

Jeremy:

*“[Some people will say] sports is one thing but the fine arts, or ballet, or opera, or theater are on some plain that’s above sports. Look, I’ll say this. There is nothing else. I’m a Giants fan. I was at the* [*Super Bowl XXV*](https://en.wikipedia.org/wiki/Super_Bowl_XXV) *when they won that game against the Bills in the last second when* [*Scott Norwood missed that kick*](https://www.youtube.com/watch?v=QkCC-crdXXE)*. That kind of joy you feel.”*

*“You don’t go to a concert or you don’t go to a Broadway show and at the end of it go completely nuts the way that say for instance in Super Bowl XXV I was going nuts.”*

https://www.youtube.com/watch?v=QkCC-crdXXE

> “There’s nothing else that gives us that kind of moment. And that’s universal. That’s around the whole world. There’s something special about sports that we’ve got to acknowledge.”

§

## Selected Links / Related Material

**Jeremy’s book about James Braddock**: [Cinderella Man: James J. Braddock, Max Baer, and the Greatest Upset in Boxing History](https://www.amazon.com/Cinderella-Man-Braddock-Greatest-History/dp/0618711902) by Jeremy Schaap | (amazon.com) [4:15, 9:00]

**ESPN 30 for 30 film about Buster Douglas vs. Mike Tyson, directed by Jeremy**: [42 to 1](https://www.espn.com/30for30/film?page=42to1) | (espn.com) [4:30, 23:30, 45:30]

**Movie about Braddock upset of Max Baer (not based on Jeremy’s book)**: [Cinderella Man](https://en.wikipedia.org/wiki/Cinderella_Man) | (wikipedia.org) [9:00]

**Jim Braddock upsets Max Baer in 1934**: [James J. Braddock: Max Baer fight](https://en.wikipedia.org/wiki/James_J._Braddock#Max_Baer_fight) | (wikipedia.org) [9:00]

- **Video**: [James Braddock vs Max Baer – Highlights (Classic FIGHT & UPSET)](https://www.youtube.com/watch?v=ZV2z7kmanAM) | Jeff Jackson (youtube.com)

**Buster Douglas upsets Mike Tyson in his prime despite 42 to 1 odds**: [Mike Tyson vs. Buster Douglas](https://en.wikipedia.org/wiki/Mike_Tyson_vs._Buster_Douglas) | (wikipedia.org) [23:30]

- **Video**: [Tyson vs Douglas FULL FIGHT](https://www.youtube.com/watch?v=R8z0xoMze8U) | Mike Noris (youtube.com)

**Max Baer kills Frankie Campbell in the ring**: [Baer vs. Campbell: The Fight that Turned into a Nightmare](https://www.boxing.com/baer_vs._campbell_the_fight_that_turned_into_a_nightmare.html) | Norman Marcus (boxing.com) [10:15]

**Primo Carnera kills Ernie Schaaf**: [Primo Carnera vs. Ernie Schaaf](https://boxrec.com/media/index.php/Primo_Carnera_vs._Ernie_Schaaf) | (boxrec.com) [12:00]

- **Video**: [Primo Carnera vs Ernie Schaaf](https://www.youtube.com/watch?v=gSrtLbTeukM) | rsmorodinov (youtube.com)

**Max Baer beats Primo Carnera with 10+ knockdowns**: [Primo Carnera vs. Max Baer](https://boxrec.com/media/index.php/Primo_Carnera_vs._Max_Baer) [12:15]

- **Video**: [Max Baer vs Primo Carnera](https://www.youtube.com/watch?v=cf67JevtNcc) | rsmorodinov (youtube.com)

**Max Schmeling beats Joe Louis**: [The First Fight](https://en.wikipedia.org/wiki/Joe_Louis_vs._Max_Schmeling#The_First_Fight) | (wikipedia.org) [12:45, 18:30, 41:45]

- **Video**: [Max Schmeling vs Joe Louis, I (All Rounds)](https://www.youtube.com/watch?v=igoidtPyy6g) | rsmorodinov (youtube.com)

**Tommy Loughran beats Jim Braddock**: [Tommy Loughran vs. Jim Braddock](https://boxrec.com/media/index.php/Tommy_Loughran_vs._Jim_Braddock) | (boxrec.com) [13:00]

- **Video**: [Tommy Loughran vs James Braddock (1929) – Classic Boxing Match](https://www.youtube.com/watch?v=_zkWggCAnR8) | All Classic Video (youtube.com)

**Braddock beats John Corn Griffin**: [Jim Braddock vs. Corn Griffin](https://boxrec.com/media/index.php/Jim_Braddock_vs._Corn_Griffin) | (boxrec.com) [14:30]

**Deontay Wilder draw against Tyson Fury**: [Deontay Wilder vs. Tyson Fury](https://en.wikipedia.org/wiki/Deontay_Wilder_vs._Tyson_Fury) | (wikipedia.org) [16:15, 56:15]

**Joe Louis beats Braddock and sets off an unprecedented 12 year reign by Louis**: [James Braddock vs. Joe Louis](https://en.wikipedia.org/wiki/James_Braddock_vs._Joe_Louis) | (wikipedia.org) [19:00]

- **Video**: [Joe Louis vs James Braddock Highlights HD](https://www.youtube.com/watch?v=IaOr3G8UKnA) | Eli Louis (youtube.com)

**Joe Louis TKO of Max Schmeling in round 1 of their rematch**: [The Second Fight](https://en.wikipedia.org/wiki/Joe_Louis_vs._Max_Schmeling#The_second_fight) | (wikipedia.org) [21:00]

- **Video**: [Joe Louis vs Max Schmeling – 1st Round Knockout](https://www.youtube.com/watch?v=2LNzWHuygpw) | boxingsgreatest (youtube.com)

**Joe Louis beats Max Baer who gets counted out while kneeling down seemingly able to get up**: [Joe Louis vs. Max Baer](https://boxrec.com/media/index.php/Joe_Louis_vs._Max_Baer) | (boxrec.com) [21:30]

- **Video**: [Joe Louis vs Max Baer – September 24, 1935](https://www.youtube.com/watch?v=VeHSseSpTvY) | Levi Johansen (youtube.com)

**Death of Max Baer where he’s says “Oh God, here I go.”**: [The Man, A Glimpse Behind the Clown Mask](https://web.archive.org/web/20070821202334/https://www.maxbaer.org/theman.html) | (web.archive.org) [23:00]

**Round 10 of Riddick Bowe vs. Evander Holyfield-One of the most famous rounds in boxing**: [One of Boxing’s Greatest Rounds: Holyfield vs. Bowe I, Round 10](https://www.youtube.com/watch?v=6GngvYoqQj4) | Wollsche (youtube.com) [26:00]

**Round 1 of Hagler vs. Hearns, the fight that got Peter into boxing**: [Hagler vs Hearns Round 1](https://www.youtube.com/watch?v=5s--I8BsgDU) | 3rdyebar (youtube.com) [26:00]

**Teddy Atlas discussing Mike Tyson was on the Joe Rogan podcast**: [Joe Rogan – Teddy Atlas on Mike Tyson](https://www.youtube.com/watch?v=3wCZY_vW860) | JRE Clips (youtube.com) [26:15]

**Tyson disqualified during Holyfield rematch for biting**: [Mike Tyson Bites Holyfields Ear Clean Off](https://www.youtube.com/watch?v=zKPMVex-UKk) | BoxingNews (youtube.com) [26:45]

**Mike Tyson annihilates Michael Spinks in 1988**: [Mike Tyson vs. Michael Spinks](https://en.wikipedia.org/wiki/Mike_Tyson_vs._Michael_Spinks) | (wikipedia.org) [27:00]

- **Video**: [Tyson vs Spinks – 1st Round Knockout](https://www.youtube.com/watch?v=HuaFIRD7_5Y) | boxingsgreatest (youtube.com) [27:00]

**Mike Tyson humiliates Larry Holmes in 1988**: [Mike Tyson vs. Larry Holmes](https://en.wikipedia.org/wiki/Mike_Tyson_vs._Larry_Holmes) | (wikipedia.org)  [27:00, 45:15]

- **Video**: [Tyson vs. Holmes KO](https://www.youtube.com/watch?v=W8RQyP_BdOE) | Mogh (youtube.com)

**Hasim Rahman upsets Lennox Lewis in 2001**: [Lennox Lewis vs. Hasim Rahman](https://en.wikipedia.org/wiki/Lennox_Lewis_vs._Hasim_Rahman) | (wikipedia.org) [29:00]

- **Video**: [Lennox Lewis vs Hasim Rahman – BRUTAL KO!!!!](https://www.youtube.com/watch?v=inehc0s0rDs) | HatmanTV (youtube.com)

**The famous 9th round of the Douglas vs. Tyson fight**: [Mike Tyson v James ‘Buster’ Douglas RD 8-10](https://www.youtube.com/watch?v=fp9VEi-YLtg) | Dan Hayles (youtube.com) [29:45]

**Tony Tucker beats Buster Douglas**: [Tony Tucker vs. James Douglas](https://boxrec.com/media/index.php/Tony_Tucker_vs._James_Douglas) | (boxrec.com) [31:30]

- **Video**: [Tony Tucker vs Buster Douglas (Highlights)](https://www.youtube.com/watch?v=whjSwx-yyIw) | Jeff Jackson (youtube.com)

**Buster Douglas beats Greg Page**: [Downward Spiral](https://en.wikipedia.org/wiki/Greg_Page_(boxer)#Downward_spiral) | (wikipedia.org) [32:00]

**Buster Douglas beats Oliver McCall**: [Buster Douglas vs. Oliver McCall, 07/21/1989](https://www.forgottenfights.com/buster-douglas-vs-oliver-mccall-07-21-1989/) | Matt (forgottenfights.com) [32:00]

**Al Bernstein asking Buster Douglas’s mom if she is proud of her son**: Schaap, Jeremy ([@jeremyschaap](https://twitter.com/jeremyschaap?lang=en)). “[Lula Pearl Douglas was Buster’s rock. Here she is with a very young @AlBernstein.](https://twitter.com/jeremyschaap/status/1067109126348697600)” November 26, 2018, 11:33 AM. Tweet. [34:45]

**Sports Illustrated with Larry Bird on the cover from March 21, 1988**: [Vault: March 21, 1988](https://www.si.com/vault/issue/702648/0) | ([si.com](https://www.si.com/)) [36:30]

**1988 Sports Illustrated article that predicted Tyson’s aggressive fighting style would lead to long term success**: [TYSON THE TIMID, TYSON THE TERRIBLE](https://www.si.com/vault/2016/06/13/tyson-timid-tyson-terrible) | Gary Smith ([si.com](https://www.si.com/)) [36:30]

**Very first issue of Sports Illustrated with Eddie Matthews on the cover which Jeremy has as a keepsake**: [Vault: August 15, 1954](https://www.si.com/vault/issue/45795/0) | ([si.com](https://www.si.com/))  [37:00]

**Jack Dempsey loses to Gene Tunney in 1926**: [Jack Dempsey vs. Gene Tunney (1st meeting)](https://boxrec.com/media/index.php/Jack_Dempsey_vs._Gene_Tunney_(1st_meeting)) | (boxrec.com) [44:00]

**Jack Dempsey loses to Gene Tunney AGAIN but not without controversy**: [The Long Count Fight](https://en.wikipedia.org/wiki/The_Long_Count_Fight) | (wikipedia.org) [44:15]

- **Video**: [Jack Dempsey vs Gene Tunney – The Long Count (1927)](https://www.youtube.com/watch?v=-OeeCfbahwQ) | Hao1981 (youtube.com)

**Muhammad Ali loses to Joe Frazier in the “Fight of the Century”**: [Fight of the Century](https://en.wikipedia.org/wiki/Fight_of_the_Century) | (wikipedia.org) [44:30]

- **Video**: [Muhammad Ali vs Joe Frazier: Fight of the Century](https://www.youtube.com/watch?v=Jt-vjZTVLV0) | goto11tv (youtube.com)

**Clip from Jeremy’s 2017 conversation with Mike Tyson**: [E:60 Mike Tyson SC Excerpt](https://vimeo.com/226342185) | E60 (vimeo.com) [47:00]

**Huge upset in sports**: [Miracle on Ice](https://en.wikipedia.org/wiki/Miracle_on_Ice) | (wikipedia.org) [48:00]

**Huge upset in sports**: [IN A LEAGUE OF THEIR OWN The unpredictable, unrepeatable, unbelievable run of Leicester City](https://sportsworld.nbcsports.com/leicester-city-premier-league-champions/) | Joe Pasnanski (sportsworld.nbcsports.com) [48:45]

**Overcoming 300-1 odds at the beginning of the year, the 1999 St. Louis Rams won the Superbowl**: [1999 St. Louis Rams season](https://en.wikipedia.org/wiki/1999_St._Louis_Rams_season) | (wikipedia.org) [49:15]

**Holyfield beats Buster Douglas**: [Buster Douglas vs. Evander Holyfield](https://en.wikipedia.org/wiki/Buster_Douglas_vs._Evander_Holyfield) | (wikipedia.org) [50:45]

- **Video**: [Douglas vs. Holyfield: Round 3 KO | SHOWTIME CHAMPIONSHIP BOXING 30th Anniversary](https://www.youtube.com/watch?v=ei3QWwKw47o) | SHOWTIME Sports (youtube.com)

**Lennox Lewis beats Mike Tyson in 2002 when they are both “over the hill”**: [Lennox Lewis vs. Mike Tyson](https://en.wikipedia.org/wiki/Lennox_Lewis_vs._Mike_Tyson) | (wikipedia.org) [54:00]

- **Video**: [Mike Tyson vs Lennox Lewis [Full Fight]](https://www.youtube.com/watch?v=iQeZzlV8X2A) | World Boxing (youtube.com)

**Lennox Lewis loses to Oliver McCall in their rematch**: [Lennox Lewis vs. Oliver McCall II](https://en.wikipedia.org/wiki/Lennox_Lewis_vs._Oliver_McCall_II) | (wikipedia.org) [54:45]

- **Video**: [Lennox Lewis Loses to Oliver McCall By KO This Day September 24, 1994](https://www.youtube.com/watch?v=Y6A31e1pkew) | Boxing Hall of Fame Las Vegas (youtube.com)

**Lennox Lewis loses to Hasim Rahman**: [Lennox Lewis vs. Hasim Rahman](https://en.wikipedia.org/wiki/Lennox_Lewis_vs._Hasim_Rahman) | (wikipedia.org) [54:45]

- **Video**: [Hasim Rahman knocks out Lennox Lewis](https://www.youtube.com/watch?v=inehc0s0rDs) | FuckTheUG (youtube.com)

**Lennox Lewis beats Vitali in 2003**: [Lennox Lewis vs. Vitali Klitschko](https://en.wikipedia.org/wiki/Lennox_Lewis_vs._Vitali_Klitschko) | (wikipedia.org) [55:15]

- **Video**: [Lennox Lewis vs. Vitali Klitschko (Highlights)](https://www.youtube.com/watch?v=FCaohPudiu4) | Erraticsboxing (youtube.com)

**Jeremy’s famous interview with Bobby Knight in 2000**: [Bob Knight and Jeremy Schaap – 9/12/2000](https://www.youtube.com/watch?v=ZNxKeCLfJqs) | Galen Clavio (youtube.com) [57:00]

- **Clip:** [Most memorable moment of the Bobby Knight interview](https://youtu.be/ZNxKeCLfJqs?t=1450)

**30 for 30 episode on Bobby Knight**: [The Last Days of Knight](https://www.espn.com/30for30/film?page=lastdaysofknight) | Robert Abbott (espn.com) [57:30, 1:31:45]

**Article where Jeremy explains what being a fair reporter means to him and what he learned about it from his father**: [Q&A: JEREMY SCHAAP ON SPORTS MEDIA | Alex Wong](https://www.sportsonearth.com/article/230229096/jeremy-schaap-interview-e60-espn-sports-media) (sportsonearth.com) [1:05:15]

**Jeremy’s story on Al CAmpanis on the 25th anniversary of the time of his infamous Nightline interview where he made racist remarks**: [The legacy of Al Campanis](https://www.espn.com/espn/otl/story/_/id/7751398/how-al-campanis-controversial-racial-remarks-cost-career-highlighted-mlb-hiring-practices) | William Weinbaum (espn.com) [1:16:45]

**Infamous episode of Nightline, where Ted Koppel confronts Al Campanis after he makes racist remarks**: [Al Campanis Racist Remarks on Nightline (April 6, 1987)](https://www.youtube.com/watch?v=O4XUbENGaiY) | ZcrAyZ (youtube.com) [1:16:45]

**Jeremy was the ESPN reporter covering the 1998 home run chase**: [1998 Major League Baseball home run record chase](https://en.wikipedia.org/wiki/1998_Major_League_Baseball_home_run_record_chase) | (wikipedia.org) [1:17:45]

**Mark McGwire breaks Roger Maris’s home run record**: [Mark McGwire’s 62nd Home Run](https://www.youtube.com/watch?v=M7dvnl9AtP8) | TheAcsMan (youtube.com) [1:18:15]

**The story about Mark McGwire taking andro during the 1998 season**: [BASEBALL; McGwire Admits Taking Controversial Substance](https://www.nytimes.com/1998/08/22/sports/baseball-mcgwire-admits-taking-controversial-substance.html) | Joe Drape (nytimes.com) [1:18:15]

**Article by David Walsh which got him sued by Lance Armstrong**: [New drugs allegations mean Lance Armstrong again faces the question: champ or cheat?](https://www.thetimes.co.uk/article/new-drugs-allegations-mean-lance-armstrong-again-faces-the-question-champ-or-cheat-vt036g2wjr6) |  David Walsh (thetimes.co.uk) [1:20:45]

**Head trauma in football is the biggest story in sports, per Jeremy**: [Degenerative Brain Disease Found In 87% of Former Football Players: Study](https://time.com/4871597/degenerative-brain-disease-cte-football/) | ALEXANDRA SIFFERLIN (time.com) [1:26:45]

**The undetected use of HGH in sports is the most underreported story in sports, per Jeremy**: [Growth hormone in sports](https://en.wikipedia.org/wiki/Growth_hormone_in_sports) | (wikipedia.org) [1:29:15]

**One of Peter and Jeremy’s favorite ESPN 30 for 30 episodes**: [The Two Escobars](https://www.espn.com/30for30/film?page=the-two-escobars) | Jeff Zimbalist and Michael Zimbalist (espn.com) [1:31:45]

**Show Peter watched that about Pablo Escobar**: [Narcos](https://en.wikipedia.org/wiki/Narcos) | (wikipedia.org) [1:32:15]

**One of Peter and Jeremy’s favorite ESPN 30 for 30 episodes**: [The Two Escobars](https://www.espn.com/30for30/film?page=the-two-escobars) | Jeff Zimbalist and Michael Zimbalist (espn.com) [1:32:30]

**One of Peter and Jeremy’s favorite ESPN 30 for 30 episodes**: [The Two Bills](https://www.espn.com/30for30/film?page=TheTwoBills) | Ken Rodgers (espn.com) [1:32:30]

**Jeremy Schaap’s interview of Matt Millen**: [Matt Millen is still all heart: Emotional episode of ESPN’s “E:60” documents transplant](https://www.youtube.com/watch?v=7bA7v0U1SRg) | ZiZi TV (youtube.com)  [1:33:30]

**Jeremy’s interview with Sammy Sosa where he denies using PEDs**: [Sosa continues to deny PED use | Jun 28, 2018](https://youtu.be/qvABmOzp5Jc?t=18) | Sports TUBE (youtube.com) [1:35:00]

**Joe Jackson tried to fix the 1919 World Series and has been subsequently barred from the Hall of Fame despite his amazing career**: [1919 World Series](https://en.wikipedia.org/wiki/1919_World_Series) (wikipedia.org) [1:36:30]

**Babe Ruth called Shoeless Joe Jackson the greatest hitter he’d ever seen**: [Shoeless Joe Jackson Quotes](https://www.baseball-almanac.com/quotes/quojcks.shtml) | (baseball-almanac.com) [1:37:00]

**Super Bowl XXV when the Giants beat the Bill after Scott Norwood missed the final field goal attempt**: [Super Bowl XXV: Bills vs. Giants (#8) | Top 10 Upsets | NFL](https://www.youtube.com/watch?v=QkCC-crdXXE) | NFL (youtube.com) [1:38:30]

**30 for 30 about the Bills four lost super bowls**: [Four Falls of Buffalo](https://www.espn.com/30for30/film?page=fourfalls) | Ken Rodgers (espn.com) [1:38:45]

**Jeremy attended the match when France won its first World Cup and did so in France in front of 100,000 people**: [1998 FIFA World Cup Final](https://en.wikipedia.org/wiki/1998_FIFA_World_Cup_Final) | (wikipedia.org) [1:39:00]

§

## People Mentioned

- [James J. Braddock](https://en.wikipedia.org/wiki/James_J._Braddock) (famous upset over Max Baer, subject of Jeremy’s book, [Cinderella Man](https://www.amazon.com/Cinderella-Man-Braddock-Greatest-History/dp/0618711902)) [4:15, 7:45, 9:00, 23:30, 42:15]
- [Buster Douglas](https://en.wikipedia.org/wiki/Buster_Douglas) (famously upset Mike Tyson in his prime, subject of [42 to 1](https://www.espn.com/30for30/film?page=42to1)) [4:15, 23:30, 47:45, 49:15]
- [Mike Tyson](https://en.wikipedia.org/wiki/Mike_Tyson) (one of the fiercest boxers ever, famously upset by Buster Douglas, 42 to 1) [4:15, 6:45, 23:30, 36:30, 40:15, 45:15, 53:15]
- [Kevin McBride](https://en.wikipedia.org/wiki/Kevin_McBride) (Tyson’s final fight in 2005) [7:00]
- [Jack Johnson](https://en.wikipedia.org/wiki/Jack_Johnson_(boxer)) (where Peter’s obsession started) [7:15]
- [Jack Dempsey](https://en.wikipedia.org/wiki/Jack_Dempsey) (where Peter’s obsession started, “destroyer-style” boxer, Dempsey-Tunney II at Soldier Field was “the biggest sports event in its moment of all time”) [7:15, 36:30, 41:15, 51:15]
- [Joe Louis](https://en.wikipedia.org/wiki/Joe_Louis) (where Peter’s obsession started, fought with an “artists” attitude, arguably best boxer of all time) [7:15, 12:45, 18:30, 21:00, 36:30, 38:45, 41:15]
- [Rocky Marciano](https://en.wikipedia.org/wiki/Rocky_Marciano) (where Peter’s obsession started) [7:15]
- [Muhammad Ali](https://en.wikipedia.org/wiki/Muhammad_Ali) (where Peter’s obsession started, fought with an “artist” attitude, arguably best boxer of all time) [7:15, 36:30, 38:45, 55:00, 1:15:45]
- [Sugar Ray Robinson](https://en.wikipedia.org/wiki/Sugar_Ray_Robinson) (where Peter’s obsession started) [7:15]
- [Henry Armstrong](https://en.wikipedia.org/wiki/Henry_Armstrong) (where Peter’s obsession started) [7:15]
- [Max Baer](https://en.wikipedia.org/wiki/Max_Baer_(boxer)) (famously upset by Braddock, Jeremy’s book Cinderella man) [7:45, 9:30, 21:30]
- [Dick Schaap](https://en.wikipedia.org/wiki/Dick_Schaap) (Jeremy’s father, iconic sports reporter) [8:30, 43:00, 1:05:15]
- [Stanley Ketchel](https://en.wikipedia.org/wiki/Stanley_Ketchel) (great middleweight) [8:30]
- [Russell Crowe](https://en.wikipedia.org/wiki/Russell_Crowe) (plays James Braddock in Cinderella Man) [9:00]
- [John L. Sullivan](https://en.wikipedia.org/wiki/John_L._Sullivan) (great heavyweight) [9:45, 51:00]
- [Frankie Campbell](https://en.wikipedia.org/wiki/Frankie_Campbell) (killed in the ring by Max Baer) [10:15, 17:00]
- [Dolph Camilli](https://en.wikipedia.org/wiki/Dolph_Camilli) (brother of Frankie Campbell, first baseman in MLB and MVP in 1941) [10:15]
- [Ernie Schaaf](https://en.wikipedia.org/wiki/Ernie_Schaaf) (died while boxing Primo Carnera but Max Baer was blamed) [11:30, 17:00]
- [Primo Carnera](https://en.wikipedia.org/wiki/Primo_Carnera) (killed Ernie Schaaf in the ring, was later beaten by Max Baer) [12:15, 56:30]
- [Max Schmeling](https://en.wikipedia.org/wiki/Max_Schmeling) (German heavyweight with iconic fights against Joe Louis, Max Baer and others) [12:30, 18:30, 21:15, 41:45]
- [Tommy Loughran](https://en.wikipedia.org/wiki/Tommy_Loughran) (beat Braddock in the light heavyweight title) [13:00]
- [John “Corn” Griffin](https://en.wikipedia.org/wiki/Corn_Griffin) (up and comer fighter beaten by Braddock on his way to fight Max Baer) [14:30]
- [Wally Pipp](https://en.wikipedia.org/wiki/Wally_Pipp) (best remembered as the man who lost his starting role to Lou Gehrig) [15:15]
- [Deontay Wilder](https://en.wikipedia.org/wiki/Deontay_Wilder) (current heavyweight champion) [16:15, 56:15]
- [Tyson Fury](https://en.wikipedia.org/wiki/Tyson_Fury) (just had a draw with Deontay Wilder in a heavyweight title match) [16:15, 56:15]
- [Joe Gould](https://en.wikipedia.org/wiki/Joe_Gould_(boxing)) (Jim Braddock’s manager) [20:30]
- [Riddick Bowe](https://en.wikipedia.org/wiki/Riddick_Bowe) (famous 10th round against Holyfield) [26:00, 50:45]
- [Evander Holyfield](https://en.wikipedia.org/wiki/Evander_Holyfield) (famous 10th round against Riddick Bowe) [26:00, 50:45]
- [Marvin Hagler](https://en.wikipedia.org/wiki/Marvelous_Marvin_Hagler) (famous 1st round against Hearns) [26:00]
- [Thomas Hearns](https://en.wikipedia.org/wiki/Thomas_Hearns) (famous 1st round against Hagler) [26:00]
- [Teddy Atlas](https://en.wikipedia.org/wiki/Teddy_Atlas) (boxing manager, interesting discussion about Tyson on the Joe Rogan podcast) [26:15, 40:00]
- [Joe Rogan](https://en.wikipedia.org/wiki/Joe_Rogan) (has Teddy Atlas on his podcast talking about Mike Tyson) [26:15]
- [Lennox Lewis](https://en.wikipedia.org/wiki/Lennox_Lewis) (beat Tyson in 2002) [26:45, 29:00, 54:00]
- [Danny Williams](https://en.wikipedia.org/wiki/Danny_Williams_(boxer)) (beat Tyson in 2004) [26:45]
- [Michael Spinks](https://en.wikipedia.org/wiki/Michael_Spinks) (beaten badly by Tyson leading up the the Douglas upset) [27:00, 45:15]
- [Larry Holmes](https://en.wikipedia.org/wiki/Larry_Holmes) (beaten badly by Tyson leading up the the Douglas upset, top 3 boxer since the 60s) [27:00, 55:00]
- [Carl Williams](https://en.wikipedia.org/wiki/Carl_Williams_(boxer)) (last fight Tyson had before Douglas) [27:15]
- [Frank Bruno](https://en.wikipedia.org/wiki/Frank_Bruno) (second to last fight Tyson had before Douglas) [27:15]
- [Tony Tucker](https://en.wikipedia.org/wiki/Tony_Tucker) (one of 3 fighters who had taken Tyson the distance before Douglas fight) [27:45, 49:15]
- [James “Bonecrusher” Smith](https://en.wikipedia.org/wiki/James_Smith_(boxer)) (one of 3 fighters who had taken Tyson the distance before Douglas fight) [27:45]
- [James “Quick” Tillis](https://en.wikipedia.org/wiki/James_Tillis) (one of 3 fighters who had taken Tyson the distance before Douglas fight) [27:45]
- [Hasim Rahman](https://en.wikipedia.org/wiki/Hasim_Rahman) (famously upset Lennox Lewis with one “lucky” punch) [29:00]
- [Tony Tucker](https://en.wikipedia.org/wiki/Tony_Tucker) (Douglas had been called a quitter for a loss he took to Tony Tucker) [31:30]
- [Greg Page](https://en.wikipedia.org/wiki/Greg_Page_(boxer)) (impressive victory for Buster Douglas before Tyson) [32:00]
- [Oliver McCall](https://en.wikipedia.org/wiki/Oliver_McCall) (impressive victory for Buster Douglas before Tyson) [32:00]
- [Don King](https://en.wikipedia.org/wiki/Don_King_(boxing_promoter)) (Tyson’s manager and promoter, lawsuit with Buster Douglas) [32:15, 51:30]
- [Mills Lane](https://en.wikipedia.org/wiki/Mills_Lane) (referee who called the TKO in the Douglas loss to Tony Tucker) [33:30]
- [Bruce Trampler](https://en.wikipedia.org/wiki/Bruce_Trampler) (Hall of Fame promoter and matchmaker who knew Buster from the time he was a little kid because he was his father’s manager) [34:15]
- [Lula Pearl Douglas](https://twitter.com/busterdouglasko/status/1057053079407755264) (Buster’s mom who he was very close with) [34:45]
- [Al Bernstein](https://en.wikipedia.org/wiki/Al_Bernstein) (reporter who asks Buster’s mom is she is proud of her son) [34:45]
- [Bill Douglas](https://en.wikipedia.org/wiki/William_Douglas_(boxer)) (Buster’s father, boxer, “stone cold killer”, fought with the “destroyer” attitude) [36:00, 52:30]
- [Sonny Liston](https://en.wikipedia.org/wiki/Sonny_Liston) (fought with the “destroyer” attitude) [36:30, 38:00, 40:30]
- [George Foreman](https://en.wikipedia.org/wiki/George_Foreman) (fought with the “destroyer” attitude) [36:30, 38:00, 40:30]
- [Larry Bird](https://en.wikipedia.org/wiki/Larry_Bird) (on cover of SI that Peter read) [36:45]
- [Eddie Mathews](https://en.wikipedia.org/wiki/Eddie_Mathews) (on cover of the [first ever issue of Sports Illustrated](https://www.sicovers.com/content/images/thumbs/0003509_eddie-mathews-of-the-braves.jpeg)) [37:00]
- [Tony Tubbs](https://en.wikipedia.org/wiki/Tony_Tubbs) (got knocked out in the 2nd round vs. Tyson) [37:45]
- [Joe Frazier](https://en.wikipedia.org/wiki/Joe_Frazier) (destroyer-style boxer, famous fights against Ali) [38:00, 44:00]
- [Kevin Rooney](https://en.wikipedia.org/wiki/Kevin_Rooney) (boxing trainer) [40:00]
- [Aaron Snowell](https://boxrec.com/media/index.php/Aaron_Snowell) (boxing trainer, Tyson’s corner man) [40:00]
- [Gene Tunney](https://en.wikipedia.org/wiki/Gene_Tunney) (great heavyweight, famously beat Jack Dempsey in 1926, and the rematch a year later is “arguably the biggest event in the history of the world”) [44:00, 51:00]
- [Vitali Klitschko](https://en.wikipedia.org/wiki/Vitali_Klitschko) ([Klitschko brothers](https://en.wikipedia.org/wiki/Klitschko_brothers), dominated heavyweight divisions 2004-2015) [55:00]
- [Wladimir Klitschko](https://en.wikipedia.org/wiki/Wladimir_Klitschko) ([Klitschko brothers](https://en.wikipedia.org/wiki/Klitschko_brothers), dominated heavyweight divisions 2004-2015) [55:00]
- [Bobby Knight](https://en.wikipedia.org/wiki/Bob_Knight) (Jeremy’s famous interview after Knight was fired) [57:00]
- [Robert Abbott](https://twitter.com/robertheyabbott?lang=en) (directed the Bobby Knight 30 for 30 episode) [57:30]
- [Willie Weinbaum](https://www.espnfrontrow.com/tag/willie-weinbaum/) (producer for ESPN) [1:01:00]
- [Scotty Reston](https://en.wikipedia.org/wiki/James_Reston) (famous American journalist) [1:07:00]
- [Keith Olbermann](https://en.wikipedia.org/wiki/Keith_Olbermann) (ESPN, fried of Jeremy’s whom they discussed the meaning of sports after the 9/11 tragedy) [1:11:15]
- [Jackie Robinson](https://en.wikipedia.org/wiki/Jackie_Robinson) (first African American in Major League Baseball) [1:15:30]
- [Al Campanis](https://en.wikipedia.org/wiki/Al_Campanis) (racist remarks about blacks in baseball in an interview with Ted Koppel) [1:16:45]
- [Ted Koppel](https://en.wikipedia.org/wiki/Ted_Koppel) (famous anchor of Nightline, called out Al Campanis on his racist remarks) 1:16:45]
- [Mark McGwire](https://en.wikipedia.org/wiki/Mark_McGwire) (home run chase in 1998, steroids in baseball) [1:17:45, 1:35:30]
- [Roger Maris](https://en.wikipedia.org/wiki/Roger_Maris) (held home run record of 61 before it was broken by McGwire and Sosa in 1998) [1:18:15]
- [Sammy Sosa](https://en.wikipedia.org/wiki/Sammy_Sosa) [1:19:30, 1:35:00]
- [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) [1:20:15]
- [David Walsh](https://en.wikipedia.org/wiki/David_Walsh_(journalist)) [1:20:45]
- [Mickey Mantle](https://en.wikipedia.org/wiki/Mickey_Mantle) (Roger Maris’s beloved teammate on the Yankees during Maris’s record breaking 61 home run season) [1:21:45]
- [Babe Ruth](https://en.wikipedia.org/wiki/Babe_Ruth) (held the home run record of 60 for decades before it was broken by Roger Maris) [1:21:45, 1:37:00]
- [Tyler Hamilton](https://en.wikipedia.org/wiki/Tyler_Hamilton) (cyclist who revealed the doping scandal)[1:23:15]
- [Frankie Andreu](https://en.wikipedia.org/wiki/Frankie_Andreu) (caught doping by his wife, testified in court about Lance Armstrong’s doping) [1:23:45]
- [Betsy Andreu](https://en.wikipedia.org/wiki/Frankie_Andreu#Armstrong_testimony) (wife of Frankie Andreu who discovered he was taking EPO and then testified against Lance Armstrong in 2005) [1:24:30]
- [Marco Pantani](https://en.wikipedia.org/wiki/Marco_Pantani) (doping in cycling) [1:25:30]
- [Jan Ullrich](https://en.wikipedia.org/wiki/Jan_Ullrich) (doping in cycling) [1:25:30]
- [Bjarne Riis](https://en.wikipedia.org/wiki/Bjarne_Riis) (doping in cycling) [1:25:30]
- [Miguel Induráin](https://en.wikipedia.org/wiki/Miguel_Indur%C3%A1in) (doping in cycling) [1:25:30]
- [Floyd Landis](https://en.wikipedia.org/wiki/Floyd_Landis) (doping in cycling) [1:25:45]
- [Pablo Escobar](https://en.wikipedia.org/wiki/Pablo_Escobar) (the Two Escobars 30 for 30) [1:32:00]
- [Bo Jackson](https://en.wikipedia.org/wiki/Bo_Jackson) (one of the greatest athletes ever) [1:32:45]
- [Matt Millen](https://en.wikipedia.org/wiki/Matt_Millen) (teammate of Bo Jackson) [1:33:30]
- [Barry Bonds](https://en.wikipedia.org/wiki/Barry_Bonds) (steroids in baseball, holds the single season home run record and the career home run record) [1:34:45]
- [Roger Clemens](https://en.wikipedia.org/wiki/Roger_Clemens) (steroids in baseball) [1:34:45]
- [Joe Jackson](https://en.wikipedia.org/wiki/Shoeless_Joe_Jackson) (famously tried to fix the 1919 World Series) [1:36:30]
- [Scott Norwood](https://en.wikipedia.org/wiki/Scott_Norwood) (famously missed the field goal kick to lose Super Bowl XXV) [1:38:30]

§

![](https://peterattiamd.com/wp-content/uploads/2019/03/bio-image-1.jpg)

##### Jeremy Schaap

Jeremy Albert Schaap is an American sportswriter, television reporter, and author. Schaap is an eleven-time Emmy Award winner for his work on ESPN’s E:60, SportsCenter, and Outside the Lines. He is a regular contributor to Nightline and ABC World News Tonight and has been published in Sports Illustrated, ESPN The Magazine, Time, Parade, The Wall Street Journal, and The New York Times. A native and resident of New York City, Schaap is the author of [Cinderella Man: James J. Braddock, Max Baer, and the Greatest Upset in Boxing History](https://www.amazon.com/Cinderella-Man-Braddock-Greatest-History/dp/0618711902), a New York Times best-seller, and [Triumph: The Untold Story of Jesse Owens and Hitler’s Olympics](https://www.amazon.com/Triumph-Untold-Story-Hitlers-Olympics/dp/0618919104). Schaap is the son of the late journalist and broadcaster [Dick Schaap](https://en.wikipedia.org/wiki/Dick_Schaap). Like his father, Schaap is an alumnus of Cornell University and a former editor at The Cornell Daily Sun. Schaap was also a member of the Quill and Dagger society. He won the Dick Schaap Award for Outstanding Writing at the 2005 Emmys, an award named after his father, for an Outside the Lines feature titled “Finding Bobby Fischer.” Schaap and his wife have three children, two girls and a boy. [[wikipedia.org](https://en.wikipedia.org/wiki/Jeremy_Schaap)]