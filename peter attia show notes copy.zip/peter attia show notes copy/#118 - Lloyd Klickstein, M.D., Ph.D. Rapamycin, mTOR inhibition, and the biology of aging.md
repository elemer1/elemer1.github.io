# #118 – Lloyd Klickstein, M.D., Ph.D.: Rapamycin, mTOR inhibition, and the biology of aging

**Source:** [https://peterattiamd.com/lloydklickstein/](https://peterattiamd.com/lloydklickstein/)

---

Lloyd Klickstein is the Chief Science Officer at resTORbio, a biopharmaceutical company that develops medications to target the biology of aging. In this episode, Lloyd discusses his company’s clinical application of rapamycin and its derivatives. He also elucidates details of his 2014 paper—a paper that greatly influenced Peter’s perspective of rapamycin in the context of longevity. Peter and Lloyd go on to discuss the dose-dependent effect of rapamycin on immune function and compare rapamycin, fasting, and caloric restriction.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/lloydklickstein/the_Drive_public.png)

Play

#118 - Lloyd Klickstein, M.D., Ph.D.: Rapamycin, mTOR inhibition, and the biology of aging

#118 - Lloyd Klickstein, M.D., Ph.D.: Rapamycin, mTOR inhibition, and the biology of aging

1x15s30s

0:002:14:55

## We discuss:

- His background and decision to leave academia for translational medicine [6:15];
- Translational medicine—bridging the gap between basic science and clinical medicine [10:30];
- What prompted Lloyd to focus on mTOR inhibition? [18:00];
- Defining mTOR, TORC1, and TORC2, and the consequences of inhibiting them with rapamycin [21:30];
- Dose-dependent impact of rapamycin on immune function, mTOR inhibition, and toxicity [42:15];
- Lloyd’s 2014 experiment—mTOR inhibition improves immune function in the elderly [53:00];
- Insights into autophagy, antigen presentation, and the pleiotropic benefits of a rapalog, and how it compares to fasting [1:13:00];
- Lloyd’s 2018 experiment—TORC1 inhibition enhances immune function and reduces infections in the elderly [1:18:45];
- Creation of resTORbio, subsequent studies, and takeaways about dosing, TORC2 inhibition, and tissue selectivity [1:29:00];
- Comparing the longevity effect of rapamycin, fasting, and caloric restriction [1:40:00];
- Excitement around RTB101—resTORbio’s mTOR inhibiting molecule [1:47:00];
- Identifying rapalogs selective for TORC1 [1:56:15];
- Treating depression with ketamine, an activator of mTOR [2:00:00];
- Epigenetic clocks, rapalogs, and metformin [2:03:30]; and
- More.

§

## Show Notes

## His background and decision to leave academia for translational medicine [6:15]

- Science and medicine is the family business
- He did the combined MD, PhD track at Harvard

*When did you decide you wanted to focus on immunology, rheumatology?*

- “*Like many things in life it was about the people, not the science that led me into immunology, rheumatology and where I am.*”
- He credits his time in a laboratory at Brigham and Women’s Hospital and meeting such wonderful people that ultimately his decision was to stay there and work and learn with them

- He earned his M.D., Ph.D, in 1989
- He then completed postgraduate clinical training in Internal Medicine, Rheumatology & Immunology at Brigham & Women’s Hospital (BWH) in Boston stayed there until 2006
- In 2006, he left academia to join [Tim Wright](https://healthpolicy.usc.edu/author/timothy-wright-md/)‘s department at [Novartis Institutes](https://en.wikipedia.org/wiki/Novartis_Institutes_for_BioMedical_Research)

*Basis for leaving academia?*

> “*For me it’s important to do both science and medicine, and it’s harder and harder and harder to do that now in an academic environment*.”

- Within the academic environment, you have many obligations to research, finding grants, and teaching student — “It’s sort of amazing to me that some folks can actually straddle that.”
- Translational medicine, which was a new concept at the turn of the millenia, “was perfect for somebody like me”

## Translational medicine—bridging the gap between basic science and clinical medicine [10:30]

**Basic science**

-One example of basic science that [led to a Nobel Prize](https://www.nobelprize.org/prizes/medicine/1978/summary/) is the study of [restriction enzymes](https://en.wikipedia.org/wiki/Restriction_enzyme)

- This came from studying obscure bacteria and how they limit their infection by viruses which got to the concept of restriction enzymes—which was required for the development of modern molecular biology

-Another example is [CRISPR](https://en.wikipedia.org/wiki/CRISPR) technology

- It is another critical element of the bacterial immune system—It’s simple, elegant, and powerful
- It came from studying bacterial biology and it became exciting when somebody translated the biochemistry in the bacteria to see if it would it work in humans (which it did)
- See work from [Jennifer Doudna](https://en.wikipedia.org/wiki/Jennifer_Doudna)

–*The takeaway*: Basic science isn’t necessarily in pursuit of anything beyond knowledge, and it doesn’t come with this  need to have a clinical application with respect to the species of interest

**Clinical medicine**

- Medicine is the science and practice of establishing the diagnosis, prognosis, treatment, and prevention of disease [wikipedia.org]
- Investigating things like: Does taking this medication lower your risk of a stroke? Does taking this vaccine lower your risk of getting the flu?

**Translational medicine**

- There’s a **big gap** between basic science and clinical medicine—and translational medicine bridges that gap
- Said another way—*How do you take a basic science observation and make something useful for human health out of it and prove it?*
- Bridging this gap was done previously for a long time but not in an organized and “conceptually holistic way”
- Everyone has now bought into the concept of translational medicine
  - All big pharma companies and many small ones do it
  - Many academic institutions have organizations to do translational medicine
- Basic science is mostly funded by the tax-paying people — and the reason they fund it is to **make their live better** — so we need to be better at translating basic science into clinical applications

> “It’s in part our responsibility, it’s in part a way to do it more efficiently by providing appropriate training and experience to younger scientists. We always have to think back to who’s funding our basic science, especially in academia, ultimately it’s the people.”

*What was the first translational problem that you began to work on when you joined Novartis?*

- Early 2000s, Novartis was working on a regenerative medicine concept in musculoskeletal biology to increase bone density and to increase muscle strength
- He put together some programs that would translate some basic biology observations from human genetics
- A few projects occurred and the one that has been successful is a drug called [zoledronic acid](https://en.wikipedia.org/wiki/Zoledronic_acid) to increase bone density

*How was Novartis organized at the time in terms of their teams of scientists?*

- At that time Novartis worked very much like most other pharmaceutical companies did
- There was a basic science department led by PhD scientists
- There was a clinical development organization led by clinical developers, including MDs
- And then there was a “throw it over the wall” mentality were the scientists make something that they like and then they hand it to the clinical scientists to figure out what to do with it
- The goal of this new concept of translational medicine is to provide clinical input right at the very beginning of the process so that ultimately the drug that’s made is the drug that’s needed
- So it changes from “let’s make something and figure out what we can do with it” to “Let’s figure out what we need and then make it.”

## What prompted Lloyd to focus on mTOR inhibition? [18:00]

- [Mark Fishman](https://en.wikipedia.org/wiki/Mark_Fishman), the founder of the [Novartis Institutes](https://en.wikipedia.org/wiki/Novartis_Institutes_for_BioMedical_Research), asked Lloyd in 2008 to be part of a new group called the **New Indication Discovery Unit**
- The challenge was to figure out, “*What aren’t we doing that we should be doin*g*?*” —then start some projects around that
- The idea was to apply the basic principles—a real medical need, a problem that’s scientifically tractable, and something that Novartis (or anybody) wasn’t working on
- [Joan Mannick](https://www.restorbio.com/team_post_type/joan-mannick-m-d/) brought forth the innovative idea that the biology of aging is tractable—and she figured out a way to test a medicine that could alter the biology of aging in humans and find an endpoint that’s measurable and modifiable in a reasonable timeframe
- Their approach became addressing serious aging-associated diseases, and if successful, the side effect would be longevity
- Today, there’s [substantial scientific data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4906330/) that mTOR inhibition will extend health span in many preclinical species
- But in 2008, it was NOT as clear as it is today
- But in 2009, an [exciting paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) was published that served as a catalyst to pursue molecules that could inhibit mTOR
- In 2010, Joan and Lloyd began the project based on the idea of mTOR inhibition

> “Our approach is to address serious aging-associated diseases, and if we’re successful, the side effect will be longevity.”

## Defining mTOR, TORC1, and TORC2, and the consequences of inhibiting them with rapamycin [21:30]

⇒ See The Drive episodes with [David Sabatini](https://peterattiamd.com/davidsabatini/) and [Matt Kaeberlein](https://peterattiamd.com/mattkaeberlein/) for more on mTOR

**What is mTOR?**

- In a nutshell, mTOR is the master integrator of external availability of nutrients and growth factors
- It decides whether to
  - **A) Grow**—meaning cells are going to make proteins, lipids, nucleic acid, etc.; Or
  - **B) Conserve resources**, recycle, and wait during times of little sustenance
- **Peter’s recap**: “*It takes a bunch of signals which are external to the cell, ultimately become internal to the cell, because mTOR is in the cell, not out of the cell. It assimilates and integrates across that signal and makes decisions that lead to, as you said, at the risk of oversimplifying, grow or don’t grow.*”

*The signals it takes are to determine whether or not there are sufficient resources for the cell grow:*

- amino acids
- glucose
- cellular energy
- growth factors from other parts of the organism

*History lesson:*

- In 1991, [Michael Hall](https://en.wikipedia.org/wiki/Michael_N._Hall) first [identified](https://pubmed.ncbi.nlm.nih.gov/1715094/) what would go on to become TOR in yeast
- In 1994, [David Sabatini](https://biology.mit.edu/profile/david-sabatini/) [identified](https://pubmed.ncbi.nlm.nih.gov/7518356/) TOR in mammals

*Conserved across billions of years*

- This is a really ubiquitous thing that has been preserved across about a billion years of evolution with very little change (something you don’t often in biology)
- Why is that relevant?
- Things that have been conserved from single cell organisms to us are probably important.

*Comparative zoology that’s relevant to mTOR*—

- mTOR lives on something called a [lysosome](https://en.wikipedia.org/wiki/Lysosome)—a structure in the cells that’s responsible for breaking down either cellular material (or material that’s been acquired from outside the cell) into its component elements that then could be recycled… e.g., amino acids and sugars
- Very early in evolutionary biology, when there were single-celled organisms, the way that the organism “ate” was by creating a vacuole from whatever was on the outside and then creating a lysosome
- In the early multicellular organisms, there were specialized cells for doing this and they were called [phagocytes](https://en.wikipedia.org/wiki/Phagocyte) for eating cells
  - It was later discovered by [Élie Metchnikoff](https://en.wikipedia.org/wiki/%C3%89lie_Metchnikoff) that they also serve an immunologic role—they could eat pathogens as well as nutrients
  - Élie Metchnikoff shared the 1908 Nobel Prize with [Paul Ehrlich](https://en.wikipedia.org/wiki/Paul_Ehrlich), who pioneered work on the [humoral immunity](https://en.wikipedia.org/wiki/Humoral_immunity#:~:text=Humoral%20immunity%20or%20humoural%20immunity,the%20humors%2C%20or%20body%20fluids.)
- This is why mTOR is probably on a lysosomal vacuole because, in the context of evolutionary development, it was on these vacuoles that very simplest organisms used to ingest food and nutrients
  - Said another way, because mTOR is there to sense those things, you want to have it very close to where they enter the cell

**mTOR complex 1 and complex 2**

- The mTOR protein can be assembled into two different complexes:
  - TORC1—regulates protein synthesis, lipid biosynthesis, protein translation
    - [RPTOR](https://en.wikipedia.org/wiki/RPTOR) is unique to TORC1 complex
  - TORC2—regulates cytoskeletal, the skeleton of the cell’s organization and growth decisions
    - [RICTOR](https://en.wikipedia.org/wiki/RICTOR) is unique to the TORC2 complex

![](https://peterattiamd.com/wp-content/uploads/2020/07/sabatini-torc1-and-torc2-1024x356.png)

**Figure 1. Established components of mTORC1 (A) and mTORC2 (B). (C) Schematic showing the signals sensed by mTORC1 and mTORC2 and the processes they regulate to control growth.** Image credit: ([Sabatini, 2017](https://pubmed.ncbi.nlm.nih.gov/29078414/))

*How does rapamycin interact with* ***TORC1****?*

-We think about TOR being the target of rapamycin, but that’s not exactly correct…

- The target of rapamycin is an [immunophilin](https://en.wikipedia.org/wiki/Immunophilins) called [FK506 binding proteins](https://en.wikipedia.org/wiki/FKBP) (FKBP)
- Rapamycin binds to FKBP then binds to the TORC1 complex and inhibits it in different ways for different downstream targets
  - It’s very efficient at inhibiting phosphorylation of [S6 kinase](https://en.wikipedia.org/wiki/Ribosomal_s6_kinase)—S6 is a critical protein in the ribosome required for protein translation
  - A little less efficient at inhibiting a protein called [4EBP1](https://en.wikipedia.org/wiki/EIF4EBP1), an inhibitor of protein translation (So you inhibit the inhibitor and you activate protein translation)
  - And even less efficient at phosphorylating [ULK1](https://en.wikipedia.org/wiki/ULK1), which is an early step in the activation of the cell recycling machinery called [autophagy](https://en.wikipedia.org/wiki/Autophagy)
- In layman’s terms—**Rapamycin is i) a strong inhibitor of making new protein, and ii) a modest activator of autophagy**

*What about* ***TORC2****? How does rapa and FKBP bind to mTOR complex 2?*

- There’s no **immediate** effect of the FKBP plus rapamycin on TORC2 activity in the short term
- However, there’s a **longer-term** feedback inhibition of TORC2 because there’s a feedback signaling pathway that down-regulates TORC2

*How much exposure to rapamycin before you start to see this dual-prong of inhibition of TORC1 and TORC2?*

- In humans, after a week to a month, you can start to see consequences of TORC2 inhibition with a rapalog alone and it’s reflected in **hyperglycemia** and **hypertriglyceridemia**
- This happens in “normal” people as well—i.e., non-diabetic, non-immunocompromised
- In one [experiment](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3587783/)—
  - Patients with polycystic kidney disease that were otherwise healthy, took the [rapalog](https://en.wikipedia.org/wiki/MTOR_inhibitors#Rapamycin_and_rapalogs) (RAD001) and a substantial fraction saw these biochemical changes in their blood
  - The dose was 5 to 10 mg a day (equivalent to 2-8 mg of rapamycin)
  - BUT… *not everyone* has these effects and that it unclear why that’s the case

**In summary**:

- Inhibition of TORC1 seems favorable (after the development stage)
- Inhibition of TORC2 is generally not a good thing

⇒ David Sabatini’s has [studied](https://www.nature.com/articles/s41580-019-0199-y) what happens when several components of the TORC1 complex are knocked out:

- Inhibition of TORC1 extends lifespan and health span in rodents
- But if you do that to TORC2, it accelerates death

> “…with the tool that we currently have to block TOR, which is like rapamycin or rapalog, giving intermittent dosing may be beneficial, giving constant dosing may cancel out the benefit.” —Peter Attia

**Mouse study that was the catalyst for mTOR inhibition**

-In 2009, an [exciting mouse study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) showed rapamycin could increase lifespan in rodents

- It was the first of what would become a series of very interesting experiments across multiple labs showing the same result, that rapamycin could increase lifespan
- This was very confusing because before 2009, rapamycin was used solely as an **immune suppressor** for people getting organ transplants so they didn’t reject the foreign organ
- So it seemed counterintuitive that you could suppress the immune system, and somehow reduce death

*How did the people inside Novartis start thinking about this?*

- [Joan Mannick](https://www.restorbio.com/team_post_type/joan-mannick-m-d/) had the innovative thought of being able to recognize that “age” of the immune system is something that’s **measurable and potentially modifiable** in a reasonable time frame
- [Evidence](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5573661/) that a short course of a rapalog could alter the biology of lymphocytes in favorable way
- Earliest [observations of Suren Sehgal](https://pubmed.ncbi.nlm.nih.gov/8363215/) were lymphocytes being highly proliferative were heavily targeted by rapamycin
- TAKEAWAY: “***It’s all about the dose***”

## Dose-dependent impact of rapamycin on immune function, mTOR inhibition, and toxicity [42:15]

**Dose-dependent impact of rapamycin**

- Different dosing regimens of drugs result in different exposures
- “**Exposures**” means how much of the drug is actually in your body over time
- Different doses and exposures results in different levels of efficacy as well as side effects
- Example using [Cialis](https://en.wikipedia.org/wiki/Tadalafil)
  - Typically dosed with 5 mg or 20 mg
  - **20 mgs** of Cialis before you go on a weekend getaway with your spouse, and erectile dysfunction is ameliorated Friday through Sunday
  - Conversely, another way to take Cialis is to take **5 mgs** every single day whether or not you’re going to be sexually active
  - Patients will tolerate 5 mgs daily of Cialis more so than 20 mgs because the **PEAK** levels of the drug result in side effect
- Rapamycin example,
  - It’s more important to pay attention to the **TROUGH** levels, because the side effects are driven by the trough levels, as well as the efficacy
    - Same goes for [gentamicin](https://en.wikipedia.org/wiki/Gentamicin) (common antibiotic) which have the toxicities on the trough

*Why do some drugs produce toxicity by its* ***nadir*** *and others by its* ***peak?***

- Every drug is different and it depends on the specific mechanism.
- For gentamicin, sustained inhibition can cause toxicity, particularly in the kidney and the tubular epithelial cells, also in inner ear hair cells and some other places.
- So having some drug-free time seems to allow the organelles to recover

*A useful conceptual framework*:

- Drugs that have *trough toxicity* are drugs where you must have a break from the drug
- Peak drugs aren’t about time away—rather it’s just that too much of it eventually hits a “trigger”

**Realization that rapamycin could boost immune function at lower doses**

*Before doing their experiments, Lloyd and team had some evidence that lower doses of rapamycin could not only provide less side effects, but might actually change the profile of inhibition for the better:*

  1 | [Looking at transplant patients](https://pubmed.ncbi.nlm.nih.gov/27564469/)—those who were on a calcineurin inhibitor versus those who were on a rapalog, and there was a significant trend that those on rapalogs had fewer [Cytomegalovirus infections](https://en.wikipedia.org/wiki/Cytomegalovirus) than those on [calcineurin inhibitors](https://en.wikipedia.org/wiki/Immunosuppressive_drug#Drugs_acting_on_immunophilins) (all things being equal)

  2 | They had done exposure response experiments in cellular systems looking at how much drug is required to inhibit the downstream targets of TORC1, and it was much, much lower than the exposures that are observed in the usual dosing framework of rapamycin for transplant and immunosuppression purposes

**-The goal** was to determine the doses and frequency which would…

- i) keep the trough levels actually less than assay, which would be as safe as we could get it, and
- ii) also achieve adequate exposures to at least partially, or temporarily fully, inhibit TORC1

**Rapamycin vs. rapalog**

- [Rapamycin](https://en.wikipedia.org/wiki/Sirolimus) is the name given by [Suren Seghal](https://www.sehgal.net/surenshistory.htm) to the compound identified on Easter Island
  - Another name for rapamycin is sirolimus
  - Pfizer gave it the trade name Rapamune and that was FDA approved in 1999 for the purposes of depressing the immune system so as to not reject an organ transplantation

–*What was the first* ***rapalog*** *(synthetic drugs that are analogues of rapamycin) to come along?*

- The generic name is [everolimus](https://en.wikipedia.org/wiki/Everolimus)
- In Lloyd’s [2014 paper](https://www.researchgate.net/publication/270002631_mTOR_inhibition_improves_immune_function_in_the_elderly), they referred to as RAD001
- [Temsirolimus](https://en.wikipedia.org/wiki/Temsirolimus) is another rapalog

*-How does it differ from rapamycin/sirolimus/Rapamune?*

- There are small structural changes modified to improve the properties of the compound
- There haven’t been any comparative studies, but in vitro, potency seems to be a little greater

## Lloyd’s 2014 experiment—mTOR inhibition improves immune function in the elderly [53:00]

**2014 paper**: [mTOR inhibition improves immune function in the elderly](https://www.researchgate.net/publication/270002631_mTOR_inhibition_improves_immune_function_in_the_elderly)

- Peter read this paper on Christmas Eve and “*couldn’t believe*” what he was reading
- Lloyd, [Joan Mannick](https://www.restorbio.com/team_post_type/joan-mannick-m-d/), and team began the project back in 2010

*Pre-work leading up the 2014 experiment*:

- The had pre-work to do before getting to the actual project:
  - 1 | They reviewed the existing literature
  - 2 | They then looked at some other work that had looked at drug levels in cellular systems necessary to partially, or fully, inhibit the target
  - 3 | They had to look at a lot of different cells because the sensitivity of the TORC1 complex to the drug is different in different cells
  - 4 | They then did modeling to understand whether low doses and certain dosing schedules could yield exposures in people that would partially or fully inhibit TORC1, yet give less than assay trough levels to help ensure safety in the healthy volunteers
- This prep work was necessary because before Joan Mannick brought the program to the decision board of the company to request millions of dollars, they needed answers to questions like…
  - What dose do we use?
  - How frequently do we give it?
  - How long do we treat people?
  - What do we measure?
  - How do we answer the question clearly?

**Study design**

-Peter starts by giving high praise for the study design:

- They did a great job of identifying
  - The right patient population
  - The right primary outcome
  - A correct power analysis so you wouldn’t miss the signal
  - Knowing how long to pulse
  - How to dose
- Lloyd says it was helpful that Novartis had a vaccines group, and they had commercialized a flu vaccine, so, they knew a lot about vaccination responses required for making a clinical difference

*-The drug*: RAD001 (aka everolimus–which was already FDA approved for [renal cell carcinoma](https://en.wikipedia.org/wiki/Renal_cell_carcinoma))

*-Subjects*: 218 patients over 65 with no unstable medical conditions

*-Primary endpoint*: To determine whether the study worked or did not work, they were looking at the response to a flu vaccination for the seasonal flu

*-Site*: Australia because the timing needed to be right before a population was going to get their flu vaccines

*-Four arms in the study*:

- 1) Placebo arm
- 2) Group that gets 0.5 mgs of RAD001 *daily*
- 3) Group that gets 5 mgs once a *week*
- 4) Group that’s gets 20 mgs once a *week*
  - *A “clever design” because…a)* the weekly doses 5 mg vs. 20 mg answers both efficacy and toxicity questions as they pertain to that dose, and b) the 0.5 mg daily versus the 5 mg weekly is your closest aggregate dose where you get to see if there is a difference in trough

*-Treatment period*: Patients were dosed for 6 weeks and then given a 2 week “washout” period before getting the flu vaccinations (they wanted to see if there was a residual improvement to the immune system not just a direct one due to the presence of the drug)

**The question being asked (at a high level)**: *Can we see an improved vaccine response at an acceptable level of toxicity that would have this drug make sense?*

- - Each of the doses did a different thing to TORC1 inhibition…
    - The .5 mg dose partially inhibited in a sustained fashion.
    - The 5 mg once a week fully inhibited TORC1 for a couple days out of the week
    - The 20 mgs would fully inhibit TORC1 over the dosing interval (i.e., nonstop inhibition of MTORC1 until your next dose)

- *Did any of these have TORC2 inhibition?*

- - Nobody had to discontinue the drug for that reason

![](https://peterattiamd.com/wp-content/uploads/2020/07/table-1-mannick-et-al-2014-1024x745.png)

**Figure 2. Table 1 from 2014 study by Novartis.** Image credit:  [Mannick et al., 2012](https://www.researchgate.net/publication/270002631_mTOR_inhibition_improves_immune_function_in_the_elderly)

*Interesting observations*:

- Number of adverse events—
  - The placebo group had 21 adverse events (baseline level of adverse effects that have no bearing on the drug whatsoever)
  - The group that got .5 daily had 35 adverse effects
  - 5 mg weekly had 46 adverse events
  - 20 mg weekly had 109 adverse events
- But more importantly is **how many people** actually had adverse effects which was surprisingly constant—
  - Placebo group=12
  - .5 mg daily=22
  - 5 mg weekly=20
  - 20 mg weekly=27
- Mouth ulceration—the most common side effect of rapamycin/rapalogs
  - 11.5% of the 0.5 mg daily
  - 4%, of the 5 mg weekly
  - 17% of the 20 mg weekly
    - “*That tells a very interesting story about the kinetics of this drug.*”
    - We don’t know why this can cause ulcers

![](https://peterattiamd.com/wp-content/uploads/2020/07/table-2-mannick-et-al-2014.png)

**Figure 3. Table 2 – results from the 2014 study by Novartis.** Image credit: [Mannick et al., 2014](https://www.researchgate.net/publication/270002631_mTOR_inhibition_improves_immune_function_in_the_elderly)

- They were looking for at least a 1.2x improvement over placebo
  - They observed improvements for the 0.5 mg daily group and the 5 mg weekly group for all 3 strains of flu vaccine
  - The 20 mg weekly only improved for one strain
    - *Why did the highest dose NOT work?* ⇒ The dose of 20 mgs once a week is sufficiently high to **fully suppress TORC1**, and Lloyd expects that they probably interfered with lymphocyte proliferation

*Any changes in the counts of* [*lymphocytes*](https://en.wikipedia.org/wiki/Lymphocyte)*?*

- They saw improvement in checkpoint protein levels on both CD8 and CD4 lymphocytes
- Checkpoint proteins are very popular in oncology (e.g., PD1 is the drug target of Keytruda or Opdivo)
- Checkpoint proteins inhibit lymphocyte function and they increase in number as the lymphocytes get exhausted
- In this study, the level of PD1 went down on the lymphocytes in the drug treatment group compared to the placebo by about 10-20% — which is basically a mirror of the increase in antibody recognition

⇒ see episode of [The Drive with Keith Flaherty](https://peterattiamd.com/keithflaherty/) for more on checkpoint inhibition

**Has anyone looked to see what rapamycin/rapalog does to inhibitory T cells when using intermittent dosing?**

–*There’ve been a lot of studies of T cell subset functions with rapalogs, both in mice and in humans, looking at…*

- Effector memory transition
- [Tregs](https://en.wikipedia.org/wiki/Regulatory_T_cell) ([Araki et al., 2012](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3241972/))
- B cell function—with high exposures there’s substantial inhibitory effect on B cell function

*-Could rapalogs be used to suppress* [*Tregs*](https://en.wikipedia.org/wiki/Regulatory_T_cell)*?*

- Some evidence for that—an interesting idea would be to start layering in rapalogs with immunotherapy in oncology

## Insights into autophagy, antigen presentation, and the pleiotropic benefits of a rapalog, and how it compares to fasting [1:13:00]

**Autophagy and antigen presentation**

- Within the [2014 experiment](https://www.researchgate.net/publication/270002631_mTOR_inhibition_improves_immune_function_in_the_elderly), they also investigated the effect of rapalog in tandem with **another type of vaccine**—a 23-valent [pneumococcal vaccine](https://en.wikipedia.org/wiki/Pneumococcal_vaccine#:~:text=Pneumococcal%20vaccines%20are%20vaccines%20against,or%20just%20under%20the%20skin.) which is a pure polysaccharide vaccine and therefore T-independent response (so it uses [B cells](https://en.wikipedia.org/wiki/B_cell))
  - (This is in contrast to the flu vaccine which is a T-dependent antibody response)
- They were wondering if the ability to phagocytose the lipopolysaccharide could directly stimulate B cells
- Said another way—*Could enhanced autophagy from a dose of rapalog could improve antigen presentation?*
- In the seven specific antigen responses they measured, six of them increased by a small amount—“*It was an encouraging trend, but we didn’t further follow it up.*”

*Any other markers you could have here for autophagy?*

- No, says Lloyd, autophagy is a really difficult clinical investigation paradigm
- Although [Mitch Weiss’s paper on unpaired hemoglobins in thalassemia patients](https://pubmed.ncbi.nlm.nih.gov/31434755/) was exciting because “here’s now a clinical paradigm where we can test drugs that augment autophagy and see something easily measurable in a not-that-rare patient population.”

**Is there anything about RAD001 administration that mimics fasting?**

*How much of the benefit here is through direct inhibition of mTOR and are there any pleiotropic benefits that aren’t quantified through this?*

- Take statins, for example—
  - They have a direct effect—inhibit cholesterol synthesis
  - An indirect effect—the liver upregulates [LDL-R](https://en.wikipedia.org/wiki/LDL_receptor)
  - And a really indirect effect—immune suppression or other benefits around endothelial health

*Do you think there’s a possible “third leg” to this stool that we haven’t thought about?*

- The fasting story’s kind of complex, says Lloyd, but he DOES believe there is some other persistent benefits of a rapalog
- In mouse studies, for example, a relatively short course of a rapalog is sufficient to extend a mouse’s life span—”*And we do not understand that.*”
- Caveat is that it’s very hard to extrapolate what short versus long means in a mouse
- James Mitchell’s [study in mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4320991/), for example, shows that a 24-hour fast prior to an otherwise uniformly fatal femoral artery ligation in a non-fasted mouse would allow for the mice to survive
  - Peter comments that it’s not really about the duration of the fast, but rather it’s the metabolic consequence of the fast
  - We don’t understand why that 24-hour fast for rats is protective but you could hypothesize—
    - Is there a change in the DNA structure based on histone methylation or DNA methylation?
    - In other words, you could literally be resetting methylation…you could turn back a [methylation clock](https://en.wikipedia.org/wiki/Epigenetic_clock) to its template, potentially.
    - However, studies have looked at the potential to reset methylation with rapalogs and it doesn’t seem to happen—these are generally *negative studies* that may never get published

## Lloyd’s 2018 experiment—TORC1 inhibition enhances immune function and reduces infections in the elderly [1:18:45]

**Following the 2014 experiment…**

- Novartis didn’t yet have enough safety data on RAD001 in order to get it FDA approved for a new indication (such as boosting immune response to flu vaccine)
- The 2014 study was way too small to constitute sufficient safety data to, for example, give every person over the age of 65 who’s getting a flu vaccine this type of a medication

*What did Novartis think when they got the results from the 2014 experiment?*

- Everybody was very excited
- The next step was — Go back and try to do it in a more **TORC1 selective way**
- The plan was to not only fine-tune dosing, but also to use a different combination of molecules
- [Research from Nyfeler and Murphy at Novartis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3498278/) found that a combination of an allosteric and catalytic TORC inhibitors could be more *TORC1 selective* and more potent
- *Catalytic inhibition*—an inhibitor that’s binding at the catalytic site of TORC1 and blocking phosphorylation of targets
- *Allosteric inhibitor*— fancy way of saying an inhibitor that binds someplace else on the molecule and nonetheless inhibits it
- In this case, the allosteric inhibitor is the **combination of** [**FKBP12**](https://en.wikipedia.org/wiki/FKBP1A) **plus rapamycin** binding to TORC1
- The combination of those two synergistically inhibits TORC1 and it’s a little more TORC1 selective
- With that understanding, they could then put a finer point on the dosing *as well as* explore the biology of that catalytic inhibitor *with and without* RAD001

**The next Novartis study in 2018:** [**TORC1 Inhibition Enhances Immune Function and Reduces Infections in the Elderly**](https://www.researchgate.net/publication/326339577_TORC1_inhibition_enhances_immune_function_and_reduces_infections_in_the_elderly#:~:text=TORC1%20inhibition%20enhances%20immune%20function%20and%20reduces%20infections%20in%20the%20elderly,-Article%20(PDF%20Available&text=Inhibition%20of%20the%20mechanistic%20target,immune%20function%20in%20model%20organisms.)

- In this study, there was a new focus on [respiratory tract infections](https://en.wikipedia.org/wiki/Respiratory_tract_infection)
- The reason was because in the 2014 study…
  - They saw immune function improvement measure by the flu vaccine response
  - But also, in the adverse event listings, they saw fewer infections of **ALL types of infections** in the drug treated people compared to the placebo patients *over the course of one year*
  - They saw a decrease in respiratory tract infections (most of them being rhinovirus or  metapneumovirus)
  - They also saw a decrease in UTI’s
  - The biggest effect was over the course of drug treatment and some time thereafter, but one year later there was a decrease (although the effect waned over time)
  - They also brought patients back a year later and revaccinated them to see if the improvement in immunologic function persisted…
  - *Result?* ⇒ it did not, so by one year they had lost the improved immune response from the drug exposure

–*Design of the 2018 study*

- Overall a very similar study design as the 2014 study
- 264 patients
- Treated for 6 weeks with a 2 week washout
  - Reason for the 6 weeks was because “*we know the timing of lymphocyte production from committed precursors in human bone marrow and we were thinking that the drug could be acting at that level. And six weeks of treatment is sufficient to, by the time you vaccinate at eight weeks, have some new lymphocytes from those committed precursors.*”
- Drug used was a catalytic inhibitor called BEZ235

*-Results of 2018 study*

- The immune system function with flu vaccination showed fundamentally similar results
- And again, the drugs decreased the incidents of respiratory tract infections
  - The biggest effect on respiratory tract infections was observed with just the catalytic inhibitor alone—a new molecule called **BEZ235** (which was eventually licensed to resTORbio)
- The combination of RAD001 plus BEZ235 also decreased respiratory tract infections (but not as much) but it was BETTER at improving the flu response

## Creation of resTORbio, subsequent studies, and takeaways about dosing, TORC2 inhibition, and tissue selectivity [1:29:00]

**How resTORbio came to be**

- The [2018 Novartis study](https://www.researchgate.net/publication/326339577_TORC1_inhibition_enhances_immune_function_and_reduces_infections_in_the_elderly#:~:text=TORC1%20inhibition%20enhances%20immune%20function%20and%20reduces%20infections%20in%20the%20elderly,-Article%20(PDF%20Available&text=Inhibition%20of%20the%20mechanistic%20target,immune%20function%20in%20model%20organisms.) produced exciting results for prevention of respiratory tract infections and enhancing immune function with TORC1 inhibition
- However, Novartis already had many things in the pipeline and so this project fell below the funcing line
- This prompted [Joan Mannick](https://www.restorbio.com/team_post_type/joan-mannick-m-d/) to start a company, [resTORbio](https://www.restorbio.com/)
- Novartis then out-licensed to resTORbio the drug, BEZ235, which is now named [RTB101](https://www.restorbio.com/pipeline/), for **all uses** so the project could continue
  - In addition, there was a limited license to use **RAD001** but only *in combination with RTB101* for their indication
- resTORbio quickly went public and raised tens of millions to fund the next round of phase 2 & 3 studies

**resTORbio phase 2b study –** [**Mannick et al., 2019**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6810249/)

- resTORbio then did a [phase 2b study](https://ir.restorbio.com/news-releases/news-release-details/restorbio-announces-positive-topline-results-phase-2b-trial) ([PubMed](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6810249/)) and found RTB101 to be successful—showing significant reduction in respiratory tract infections (RTI)
- (the 2014 and 2018 studies were *phase 2a* studies)

–*In the* [*2014 Novartis study*](https://www.researchgate.net/publication/270002631_mTOR_inhibition_improves_immune_function_in_the_elderly)…

- respiratory tract infections were observed to be decreased in the drug treated group, compared to the placebo

–*In the* [*2018 Novartis study*](https://www.researchgate.net/publication/326339577_TORC1_inhibition_enhances_immune_function_and_reduces_infections_in_the_elderly#:~:text=TORC1%20inhibition%20enhances%20immune%20function%20and%20reduces%20infections%20in%20the%20elderly,-Article%20(PDF%20Available&text=Inhibition%20of%20the%20mechanistic%20target,immune%20function%20in%20model%20organisms.)*…*

- They explored the use of:
  - A catalytic inhibitor, BEZ235 (now RTB101)
  - RAD001
  - As well as the combination of the two
- They looked closer at RTIs and infections in general and again saw decreased RTIs
- The **best drug** for decreasing respiratory tract infections was **BEZ235 (now called RTB101)**
- The combination also worked
- For improving the *flu vaccine response*, the combination of RTB101 plus RAD001 worked best, the RAD001 alone also worked, but interestingly the B*EZ235 (aka RTB101) did not work*

*-How is RTB101 binding to TOR?*

- It’s catalytically inhibiting
- In a cellular assay context, they don’t look specifically for the binding, but they look for inhibition of phosphorylation of sites—S6 kinase and  phospho-AKT for TORC1, and for TORC2 they look specifically at the phosphorylation site that TORC2 does (not the one that any other enzyme does)
- They’re able to see that a catalytic inhibitor **at high concentrations will inhibit both**
- RTB101, however, has some preference for TORC1 and it’s a little different depending upon which cell you look in

*-Question about designing drugs for tissue selectivity*

- When talking about muscle versus liver versus adipose tissue, for example, you could argue you might want very different behaviors there
- Is it easier to target tissues or is it easier to target enzymes, proteins, etc. when designing a drug?
- It’s far easier to design a drug to hit a enzyme than a particular tissue
- Targeting a particular tissue is doable, it’s just how much time and effort you’re going to put into it
- During the [2014 experiment](https://www.researchgate.net/publication/270002631_mTOR_inhibition_improves_immune_function_in_the_elderly), did Lloyd have a sense of where this was acting tissue wise?—Acting on bone marrow? Thymus? Some other cell line that directly or indirectly was playing a role?
- They thought it would be bone marrow and perhaps secondary lymphoid tissue (lymph nodes or glands) but they did not explore it exactly—They knew from toxicology studies with the compound that it distributed to their target tissues so they felt they had enough information to move ahead

**Back to the** [**phase 2b study**](https://ir.restorbio.com/news-releases/news-release-details/restorbio-announces-positive-topline-results-phase-2b-trial)…

- RTB101 was the basis upon which resTORbio was formed
- RTB101 licensed it from Novartis for *all uses*
- In addition, there was a limited license to use *RAD001 only in combination with RTB101* for their indication
- The [phase 2b study](https://ir.restorbio.com/news-releases/news-release-details/restorbio-announces-positive-topline-results-phase-2b-trial) ([PubMed](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6810249/)) showed that the most effective drug, or drug combination, for preventing respiratory tract infections was just **RTB101 alone at 10 milligrams** (a similar finding to the [2018 Novartis study](https://www.researchgate.net/publication/326339577_TORC1_inhibition_enhances_immune_function_and_reduces_infections_in_the_elderly#:~:text=TORC1%20inhibition%20enhances%20immune%20function%20and%20reduces%20infections%20in%20the%20elderly,-Article%20(PDF%20Available&text=Inhibition%20of%20the%20mechanistic%20target,immune%20function%20in%20model%20organisms.))
- *The likely mechanism*? ⇒ It prevents RTIs via the upregulation of an interferon-stimulated antiviral gene response
  - Interferon is a substance in the blood that upregulates many different proteins, most of which are involved in preventing viral infections.
  - You need protein synthesis to make all of these proteins so Lloyd’s fear is that if you inhibit mTOR for a long time, you might upregulate the genes, but they won’t be expressed adequately (some data suggests that you need mTOR in order to express the proteins induced by interferon)

\*Peter recaps the important findings:

- These experiments taken together “***reinforces this idea of intermittent dosing****—not just intermittent within the week, but even applying a secondary cycle over the course of a year, for example*.”
- But the reason you don’t just want to go all the time taking it, presumably, is you might actually start to impair protein synthesis that’s necessary to basically empower your new superpowers of immunity through enhanced protein synthesis.
- That’s correct, says Lloyd, and in part from [Mitch Weiss’s recent paper](https://pubmed.ncbi.nlm.nih.gov/31434755/), Lloyd suspects that there are some proteins that are sensitive to translational inhibition by rapalogs and perhaps some that are less sensitive to rapalog

## Comparing the longevity effect of rapamycin, fasting, and caloric restriction [1:40:00]

**Extending lifespan with rapamycin**

- There has been much excitement around rapamycin for how it can [extend lifespan across species](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5394987/)—
  - [Rapamycin: An InhibiTOR of Aging Emerges From the Soil of Easter Island](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4906330/) (Apelo and Lamming, 2016)
  - [Sirolimus: Effects on Longevity](https://en.wikipedia.org/wiki/Sirolimus#Effects_on_longevity) | (wikipedia.org)
  - Matt Kaeberlein is doing [exciting work](https://en.wikipedia.org/wiki/Dog_Aging_Project) with dogs
- Clearly some of those longevity benefits are being mediated through what resTORbio is testing …
  - The enhancement of immunity in a positive way leading to reduced infections and likely a reduction of cancer through increased surveillance
- But rapamycin/rapalogs is clearly causing other thing such as:
  - Increased autophagy
  - Targeting and/or destruction of [senescent cells](https://en.wikipedia.org/wiki/Cellular_senescence)
  - Reduction of inflammation
  - Enhanced mitophagy

–*What other mechanisms does Lloyd think could be involved in the longevity benefits?*

- Experiments clearly show that every single one of those mechanisms can extend health span in preclinical models
- But we don’t have the data in humans
- Also, what tissues you have to inhibit mTOR in in order to get a clinical benefit…we don’t really know the answer to that either
- Although, we have some data on this such as an [experiment](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5348310/) where inhibition of mTOR in the fat body was sufficient to extend a fly lifespan

**How much overlap might there be between the benefits of fasting and caloric restriction and the benefits of rapamycin?**

- Experiments in rats—such as this [Nature paper](https://www.nature.com/articles/nature09584)—have looked at the consequences of fasting on mTOR activity
- In **young** rats (and people), fasting leads to suppression of mTOR activity, activation of autophagy, suppression of protein synthesis, and DNA and lipid synthesis, etc.
- In **old** rats, that is *impaired* when looking at the liver—even with fasting, their mTOR was still active in the liver (but in a young rat mTOR is suppressed)
- This observation suggests that… **the older animal lost the ability to respond to the environmental reduction in nutrient**
- Peter calls that finding “upsetting”, however, he says it does explain a very interesting finding:
  - Going back to the [2009 paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/)—
    - Those mice were 600 days old
    - They had passed that stage where caloric restriction would extend their life.
    - Yet their lives were extended 15-25% by rapamycin

**Does Lloyd think that intermittent periods of caloric restriction are NOT beneficial to people in their 60s or 70s?**

- We can’t answer the question without liver samples under fasting conditions
- It is an interesting open question—is mTOR suppressed in elderly people with fasting and in which tissues?

**Do we know if autophagy is impaired in older folks with fasting?**

- Autophagy and mTOR inhibition overlap, but they are not synonymous
- It’s unknown whether autophagy is impaired in older people, but it would be an “interesting set of experiments to do with a young group of patients and an old group of patients”

*Other factors making this complicated*:

- This is very multifaceted to study these things, says Peter
- There’s a priming effect to this
- Infinite combinations you can have
- Infinite frequency and dosing schedules

> “You can’t really go on fishing expeditions with these questions. You have to be more thoughtful in your hypothesis generation. There’s just too many variables.” —Peter Attia

## Excitement around RTB101—resTORbio’s mTOR inhibiting molecule [1:47:00]

**The excitement around RTB101 comes from**:

- The [phase 2a study](https://www.researchgate.net/publication/326339577_TORC1_inhibition_enhances_immune_function_and_reduces_infections_in_the_elderly#:~:text=TORC1%20inhibition%20enhances%20immune%20function%20and%20reduces%20infections%20in%20the%20elderly,-Article%20(PDF%20Available&text=Inhibition%20of%20the%20mechanistic%20target,immune%20function%20in%20model%20organisms.) in 2018 by Novartis showed decreased respiratory tract infections in elderly people treated with it
- The [phase 2b study](https://ir.restorbio.com/news-releases/news-release-details/restorbio-announces-positive-topline-results-phase-2b-trial) by resTORbio showing 10 mg once a day provided a decrease in respiratory tract infections

*-Takeaways from the 2018* [p*hase 2a study*](https://www.researchgate.net/publication/326339577_TORC1_inhibition_enhances_immune_function_and_reduces_infections_in_the_elderly#:~:text=TORC1%20inhibition%20enhances%20immune%20function%20and%20reduces%20infections%20in%20the%20elderly,-Article%20(PDF%20Available&text=Inhibition%20of%20the%20mechanistic%20target,immune%20function%20in%20model%20organisms.)*…*

- They saw a decrease in respiratory tract infections, but we did not see an increase in vaccine response—that suggests the *mechanism for the decrease in respiratory tract infections had to be something different*
- They identified a candidate mechanism—there was an **upregulation of antiviral gene expression** in peripheral blood leukocytes—a set of interferon stimulated genes responsible for antiviral activities was upregulated
- In layman’s terms: The [innate immune system](https://en.wikipedia.org/wiki/Innate_immune_system) can be activated by mTOR inhibition

***2019*** [***phase 2b study***](https://ir.restorbio.com/news-releases/news-release-details/restorbio-announces-positive-topline-results-phase-2b-trial)

*-Population*: 652 enrolled patients with pre-specified comorbidities and pre-specified an analysis of them independently

*-Doses and schedule*:

- 5 milligrams and 10 milligrams
- Also 10 mg twice a day
- Did a combination of RTB101 with a rapalog (RAD001)

*-Primary endpoint*: Decreased respiratory tract infections

*-Extended dosing period*: Extended the dosing period to 16 weeks to cover winter cold and flu season

*-Noteworthy change*: With the once a day 10 mg dosing (which is where they saw efficacy in previous studies) they are now only inhibiting mTOR *partially* for part of the day

*-Location of study population*: Ran it in two different cold and flu seasons, one in the **Southern hemisphere**, one in the **Northern hemisphere**

–*RESULTS*:

- Some patient populations have responded well—
  - People over 85 years old
  - Patients with asthma
  - Patients with diabetes
  - Patients who were smokers or had COPD did NOT respond well
- Overall, they saw a 30% decrease in respiratory tract infections
- \*Important finding: They saw the same degree of efficacy for patients in the Southern hemisphere and the Northern hemisphere
- At this point, they have seen 10 mgs of RTB101 decrease respiratory tract infections in the phase 2a and the phase 2b study

**PROTECTOR program — Upcoming phase 3 study by resTORbio**

*-Primary indication*: Respiratory tract infections (RTIs)

*-Patient population*:

- 65+ years old
- Total of 1,024 patients

*-Treatment phase*:

- 16 weeks of drug treatment
- 10 mg of RTB101 will be given during the cold and flu season.

**⇒ NOTE**: As Peter mentioned in the intro, since the recording of this podcast, resTORbio has announced that this phase 3 study [did not meet its primary endpoint](https://ir.restorbio.com/news-releases/news-release-details/restorbio-announces-phase-3-protector-1-trial-rtb101-clinically).

- They are still excited about RTB101 but they shifting their focus to other age-associated diseases such as Parkinson’s
- From resTORbio’s press release: “*We remain committed to exploring the potential benefits of TORC1 inhibition in patients, and we look forward to the data from our* [***Parkinson’s disease trial***](https://www.restorbio.com/clinical-trials/)*, which we expect in mid-2020.*”
- Currently recruiting for a COVID-19 study: [Phase 3 Study to Determine if RTB101 Reduces the Severity of COVID-19 in Older Adults Residing in Nursing Homes](https://clinicaltrials.gov/ct2/show/NCT04409327?term=restorbio&draw=2&rank=1)

## Identifying rapalogs selective for TORC1 [1:56:15]

[Lamming 2019 paper](https://www.nature.com/articles/s41467-019-11174-0)

- They looked at 90 different rapalogs and assessed their ability to be selective for TORC1
- They identified DL001, a FKBP12-dependent rapamycin analog 40x more selective for mTORC1 than rapamycin
- They found possibly the reason the compound was selective was that it bound to one of the immunophilins, but not another
  - It bound to FKBP12, but not FKBP51

-Peter asks, *why doesn’t doesn’t inhibit TORC2?*

- Peter’s logic is that if you bind to FKBP12 and then the rapalog plus FKBP12 binds to mTOR, after a long enough period of time, you would not have enough TOR to make complex 2. *Is that not correct?*
  - “*I don’t think that’s why complex two is inhibited*”, replied Lloyd
  - Instead, Lloyd suspects it’s a downstream and indirect counterregulatory signaling mechanism
  - In other words… it has to do more with sort of the serine kinase or the 4E-BP1 or something else downstream of a direct phosphorylation

NOTE:

- Peter always thought that rapamycin only binds to FKBP12
- But Lloyd says it also binds to [FKBP51](https://en.wikipedia.org/wiki/FKBP5) and also [FKBP12.6](https://en.wikipedia.org/wiki/FKBP1B) (something in cardiac myocytes)
- Therefore, if you only bind a rapalog to FKBP12, perhaps you don’t hit that TORC2 target?

## Treating depression with ketamine, an activator of mTOR [2:00:00]

*Are there any times when you want to be activating mTOR?*

**Ketamine for depression**

- [Ketamine](https://en.wikipedia.org/wiki/Ketamine) may be [activating mTOR](https://pubmed.ncbi.nlm.nih.gov/29532791/)
- For patients with major depression, intravenous ketamine is almost a miracle drug
- Typical antidepressant drugs require weeks and weeks to work and have modest effects at best
- Yet, ketamine works in minutes to hours
- It has a huge effect size
- We don’t yet know what the specific cellular mechanism is

*Other noteworthy info*:

1. There’s a [study](https://pubmed.ncbi.nlm.nih.gov/27004790/) showing that rapamycin, which inhibits mTOR, blocks the antidepressant effect of ketamine
2. And there’s a biotech company called [Navitor](https://www.navitorpharma.com/pipeline/nav-5138-for-trd/) using an mTOR activator to treat depression

**More on FK506 binding proteins and rapamycin**

- It’s a relatively recent understanding how much rapamycin is binding to the [FK506 binding proteins](https://en.wikipedia.org/wiki/FKBP) (FKBP)
- Not only that, but the amount you can change properties by which ones are being binded
- There are several FKBPs—FKBP12 is the one mostly discussed
- But rapamycin binds to all of them
- There are also roles for FKBPs that aren’t at all part of TORC1 biology
- For example, they all have an enzymatic activity involved in protein folding
- But when those are eliminated, there was no clear cellular phenotype—it could mean that others can all substitute because it’s such a critical function, OR… they have no function that’s important
- However, FKBPs are highly conserved across species so they likely play an important role

## Epigenetic clocks, rapalogs, and metformin [2:03:30]

**Recent paper**: [Reversal of epigenetic aging and immunosenescent trends in humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6826138/)

- This paper suggested that growth hormone, DHEA, and metformin set the epigenetic clock back
- Caveat: small study, poorly controlled, and no placebo group
- But this paper got a lot of press because it used an “[epigenetic clock](https://en.wikipedia.org/wiki/Epigenetic_clock)”

*What is the epigenetic clock?*

- [Steve Horvath](https://en.wikipedia.org/wiki/Steve_Horvath) is known for his [work on epigenetic clocks](https://en.wikipedia.org/wiki/Steve_Horvath#Work_on_the_epigenetic_clock)
- By looking at the methylation pattern on peripheral blood leukocyte DNA, we can tell how old you are within about six months to a year
- For people between about 20 and 80, there’s a stereotypical change in methylation patterns on DNA—a chemical change to DNA that happens over time that correlates with your chronologic age
- [David Sinclair refers](https://peterattiamd.com/davidsinclair2/) to this as the “scratching of the CD”… the CD being the master copy of your genome

*Lloyd’s interpretation*:

- Aging is fundamentally a biologic process controlled by pathways
- Presumably it’s a consequence of changes in gene expression—and [methylation](https://en.wikipedia.org/wiki/Methylation) changes gene expression
- If you take a differentiated cell and treat it with a set of transcription factors called the [Yamanaka factors](https://en.wikipedia.org/wiki/Shinya_Yamanaka), you can **reset the cell back to a** [**pluripotent stem cell**](https://en.wikipedia.org/wiki/Induced_pluripotent_stem_cell) and the methylation goes away too
- So DNA methylation *could be* causally related to the gene expression changes, that not only are associated with aging, but may cause aging

*Has anybody looked at the effect on the epigenetic clock and/or DNA methylation in response to rapalogs?*

- Lloyd says one unpublished experiment looked and the answer was negative

**Peter’s take on the** [**recent experiment**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6826138/)**:**

- The initial hypothesis of the experiment mentioned above was that GH, DHEA, and metformin was going to improve thymic function—which was going to improve immune function
- And if that truly is the case…
- You could perhaps say that a rapalog, which is also acting on immunity, could do something similar

*-Lloyd’s response:*

- **First**, DHEA does go down substantially with age, but replacing it seems to have no clinical benefit
  - Peter point’s out that DHEA was used for the effect of *reducing the hyperinsulinemia that follows the administration of growth hormon*e
  - But again, that’s not something that’s well-documented in the literature.
- **Secondly**, the biologic activity of GH is mostly driven by IGF-1
  - We know that [lymphoid tissue](https://en.wikipedia.org/wiki/Lymphatic_system) (e.g., [spleen](https://en.wikipedia.org/wiki/Spleen) and [thymus](https://en.wikipedia.org/wiki/Thymus)) is probably the most sensitive target organ for IGF-1 and it causes hypertrophy
  - So it’s not surprising that he found an enlarged [thymus](https://en.wikipedia.org/wiki/Thymus) in his patients
- *Is there any reason to believe that an enlarged thymus would enhance immune function?*
- - “I don’t know” says Lloyd

**Metformin**

- We have excellent data that in diabetics, metformin is a wonderful drug for diabetics
- In his [TAME studies](https://www.afar.org/tame-trial), [Nir Barzilai](https://peterattiamd.com/nirbarzilai/) is trying to answer more questions about the longevity impact of metformin

Peter says the open question is… *What is the benefit of metformin in a perfectly healthy person? Or even in a fully optimized person with respect to other variables?*

- Peter and Lloyd agree that there may not be any
- In fact, it has some adverse effects on mitochondrial function potentially
- The question of mitochondrial function is what plagues Peter the most on this topic

§

## Selected Links / Related Material

**Biopharmaceutical company that Lloyd works for**: [resTORbio](https://www.restorbio.com/) | (restorbio.com) [54:30, 1:29:00]

**Company that Lloyd worked for and published exciting human studies with rapalogs**: [Novartis](https://www.novartis.com/) | (novartis.com) [8:30]

**Lloyd’s 2014 paper that greatly influenced Peter’s thinking on rapamycin**: [mTOR inhibition improves immune function in the elderly](https://www.researchgate.net/publication/270002631_mTOR_inhibition_improves_immune_function_in_the_elderly) (Mannick et al., 2014) [1:45, 13:30, 17:30, 51:30, 1:23:45, 1:45:45]

**D.A. Wallach on The Drive podcast**: [#06 – D.A. Wallach: music, medicine, longevity, and disruptive technologies](https://peterattiamd.com/dawallach/) | Peter Attia (peterattiamd.com) [3:45]

**David Sabatini on The Drive podcast**: [#09 – David Sabatini, M.D., Ph.D.: rapamycin and the discovery of mTOR — the nexus of aging and longevity?](https://peterattiamd.com/davidsabatini/) | Peter Attia (peterattiamd.com) [4:30, 20:15]

**Matt Kaeberlein on The Drive podcast**: [#10 – Matt Kaeberlein, Ph.D.: rapamycin and dogs — man’s best friends? — living longer, healthier lives and turning back the clock on aging and age-related diseases](https://peterattiamd.com/mattkaeberlein/) | Peter Attia (peterattiamd.com) [4:30, 20:15]

**Nobel Prizes for the study of restriction enzymes came from basic science**: [The Nobel Prize in Physiology or Medicine 1978](https://www.nobelprize.org/prizes/medicine/1978/summary/) | (nobelprize.org) [9:15]

**Another important discovery from basic science**: [CRISPR](https://en.wikipedia.org/wiki/CRISPR) | (wikipedia.org)  [9:30]

**Rapamycin will extend lifespan across many species**: [19:15]

- [Rapamycin: An InhibiTOR of Aging Emerges From the Soil of Easter Island](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4906330/) (Apelo and Lamming, 2016)
- [Sirolimus: Effects on Longevity](https://en.wikipedia.org/wiki/Sirolimus#Effects_on_longevity) | (wikipedia.org)

**Major 2009 publication showing rapamycin extended the lives of rats**: [Rapamycin fed late in life extends lifespan in genetically heterogeneous mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) (Harrison et al., 2009) [19:45, 38:15, 1:42:15]

**Hall first identified in 1991 what would go on to become TOR in yeast**: [Targets for Cell Cycle Arrest by the Immunosuppressant Rapamycin in Yeast](https://pubmed.ncbi.nlm.nih.gov/1715094/) (Heitman et al., 1991) [21:45]

**Sabatini identified TOR in  mammals in 1994**: [RAFT1: A Mammalian Protein That Binds to FKBP12 in a Rapamycin-Dependent Fashion and Is Homologous to Yeast TORs](https://pubmed.ncbi.nlm.nih.gov/7518356/) (Sabatini et al., 1994) [21:45]

**The Nobel Prize in 1908 shared by Élie Metchnikoff and Paul Ehrlich**: [The Nobel Prize in Physiology or Medicine 1908 was awarded jointly to Ilya Ilyich Mechnikov and Paul Ehrlich “in recognition of their work on immunity.”](https://www.nobelprize.org/prizes/medicine/1908/summary/#:~:text=The%20Nobel%20Prize%20in%20Physiology%20or%20Medicine%201908%20was%20awarded,of%20their%20work%20on%20immunity.%22) | (nobelprize.org) [24:45]

**David Sabatini helped elucidate the two complexes of mTOR (RPTOR and RICTOR)**: [26:15]

- [mTOR Interacts With Raptor to Form a Nutrient-Sensitive Complex That Signals to the Cell Growth Machinery](https://pubmed.ncbi.nlm.nih.gov/12150925/) (Kim et al., 2002)
- [Rictor, a Novel Binding Partner of mTOR, Defines a Rapamycin-Insensitive and Raptor-Independent Pathway That Regulates the Cytoskeleton](https://pubmed.ncbi.nlm.nih.gov/15268862/) (Sarbassov et al., 2004)

**David Sinclair’s appearances on The Drive**: [32:45]

- [#27 – David Sinclair, Ph.D.: Slowing aging – sirtuins, NAD, and the epigenetics of aging](https://peterattiamd.com/davidsinclair/) | Peter Attia (peterattiamd.com)
- [#70 – David Sinclair, Ph.D.: How cellular reprogramming could slow our aging clock (and the latest research on NAD)](https://peterattiamd.com/davidsinclair2/) | Peter Attia (peterattiamd.com)

**TORC2 inhibition with a rapalog in humans can results in hyperglycemia and hypertriglyceridemia**: [Everolimus in Patients with Autosomal Dominant Polycystic Kidney Disease](https://www.nejm.org/doi/full/10.1056/nejmoa1003491) (Walz et al., 2010) [33:00]

**David Sabatini has shown inhibition of TORC1 extends lifespan and health span but if you do that to TORC2, it accelerates death**: [mTOR at the nexus of nutrition, growth, ageing and disease](https://www.nature.com/articles/s41580-019-0199-y) (Liu and Sabatini, 2020) [37:15]

**2018 Novartis paper by Lloyd and Joan Mannick**: [TORC1 Inhibition Enhances Immune Function and Reduces Infections in the Elderly](https://www.researchgate.net/publication/326339577_TORC1_inhibition_enhances_immune_function_and_reduces_infections_in_the_elderly#:~:text=TORC1%20inhibition%20enhances%20immune%20function%20and%20reduces%20infections%20in%20the%20elderly,-Article%20(PDF%20Available&text=Inhibition%20of%20the%20mechanistic%20target,immune%20function%20in%20model%20organisms.) (Mannick et al., 2018) [38:00, 1:18:45, 1:29:00, 1:46:30]

**A short course of a rapalog could alter the biology of lymphocytes in a favorable way**: [Low-dose controlled release of mTOR inhibitors maintains T cell plasticity and promotes central memory T cells](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5573661/) (Gammon et al., 2018) [40:00, 52:45] #help1

**Earliest observations from Suren Sehgal were that lymphocytes being highly proliferative were heavily targeted by rapamycin**: [Rapamycin Inhibits Lymphocyte Proliferation in a Popliteal Lymph Node Model via an IL-2-independent Mechanism](https://pubmed.ncbi.nlm.nih.gov/8363215/) (Warner et al., 1993) [40:30]

**A clue that rapalogs could be favorable for immune function came from the observation that transplant patients on rapalogs had fewer Cytomegalovirus infections than those on calcineurin inhibitors**: [Effect of Mammalian Target of Rapamycin Inhibitors on Cytomegalovirus Infection in Kidney Transplant Recipients Receiving Polyclonal Antilymphocyte Globulins: A Propensity Score-Matching Analysis](https://pubmed.ncbi.nlm.nih.gov/27564469/) (Cervera et al., 206) [47:30]

**Keith Flaherty on recently and we had a beautiful discussion about checkpoint inhibition**: [#62 – Keith Flaherty, M.D.: Deep dive into cancer— History of oncology, novel approaches to treatment, and the exciting and hopeful future](https://peterattiamd.com/keithflaherty/) | Peter Attia (peterattiamd.com) [1:09:45]

**Evidence that rapalogs could be used to suppress regulatory T cells (Tregs)**: [TOR in the immune system](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3241972/) (Araki et al., 2012) [1:10:45]

**Mitch Weiss’s paper on unpaired hemoglobins in thalassemia patients**: [The Autophagy-Activating Kinase ULK1 Mediates Clearance of Free α-globin in β-thalassemia](https://pubmed.ncbi.nlm.nih.gov/31434755/) (Lechauve et al., 2019) [1:13:45, 1:38:00]

**A 24 hour fast seemed to help rats survive a normally femoral artery ligation and a reperfusion**: [Pre-Operative Dietary Restriction Reduces Intimal Hyperplasia and Protects from Ischemia Reperfusion Injury](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4320991/) (Mauro et al., 2016) [1:15:45]

**Study finding that a combination of an allosteric and catalytic TORC inhibitor could be more TORC1 selective and more potent**: [RAD001 Enhances the Potency of BEZ235 to Inhibit mTOR Signaling and Tumor Growth](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3498278/) (Nyfeler et al., 2012) [1:20:45]

**resTORbio’s phase 2b study using the rapalog RTB101**: [LB2. TORC1 Inhibition with RTB101 as a Potential Pan-Antiviral Immunotherapy to Decrease the Incidence of Respiratory Tract Infections Due to Multiple Respiratory Viruses in Older Adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6810249/) (Mannick et al., 2019)[1:29:45, 1:45:45, 1:49:15, 1:51:15]

**Matt Kaeberlein is seeing benefits of rapamycin in dogs**: [Dog Aging Project](https://en.wikipedia.org/wiki/Dog_Aging_Project) | (wikipedia.org) [1:38:30]

**Inhibition of mTOR in the fat body of a Drosophila fly was sufficient to extend lifespan**: [Rapamycin enhances survival in a Drosophila model of mitochondrial disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5348310/) (Wang et al., 2018) [1:40:00]

**Nature paper looking at the consequences of fasting on mTOR activity**: [mTORC1 controls fasting-induced ketogenesis and its modulation by ageing](https://www.nature.com/articles/nature09584) (Sengupta et al., 2010) [1:40:30]

**Old rats have less ability to suppress mTOR even when fasting**: [Short-term Low-Dose mTORC1 Inhibition in Aged Rats Counter-Regulates Age-Related Gene Changes and Blocks Age-Related Kidney Pathology](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6001891/) (Shavlakadze et al., 2018) [1:40:30]

**Nobel Prize won by Dr. Murray**: [Joseph E. Murray](https://www.nobelprize.org/prizes/medicine/1990/murray/biographical/) | (nobelprize.org) [1:48:45]

**Announcement from resTORbio that the PROTECTOR 1 failed to meet its endpoint**: [resTORbio Announces That the Phase 3 PROTECTOR 1 Trial of RTB101 in Clinically Symptomatic Respiratory Illness Did Not Meet the Primary Endpoint](https://ir.restorbio.com/news-releases/news-release-details/restorbio-announces-phase-3-protector-1-trial-rtb101-clinically) | (restorbio.com) [1:49:15, 2:10:00]

**Lamming paper that identified DL001, a FKBP12-dependent rapamycin analog 40x more selective for mTORC1 than rapamycin**: [A novel rapamycin analog is highly selective for mTORC1 in vivo](https://www.nature.com/articles/s41467-019-11174-0) (Schreiber et al., 2019) [1:54:45]

**Ketamine may be activating mTOR**: [Mechanisms of Ketamine Action as an Antidepressant](https://pubmed.ncbi.nlm.nih.gov/29532791/) (Zanos and Gould, 2018) [1:58:30]

**Study that showed rapamycin blocked the effect of ketamine**: [Rapamycin Blocks the Antidepressant Effect of Ketamine in Task-Dependent Manner](https://pubmed.ncbi.nlm.nih.gov/27004790/) (Holubova et al., 2016) [1:59:30]

**Biotech company using an mTOR activator to treat depression**: [Navitor Pharmaceuticals](https://www.navitorpharma.com/) | (navitor.com) [1:59:30]

- [NV-5138 for Treatment-Resistant Depression](https://www.navitorpharma.com/pipeline/nav-5138-for-trd/)

**Paper suggesting that growth hormone, DHEA, and metformin may set the epigenetic clock back**: [Reversal of epigenetic aging and immunosenescent trends in humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6826138/) (Fahy et al., 2019) [2:02:00]

**David Sinclair analogizes the aging of the genome to the scratching of a CD**: [#70 – David Sinclair, Ph.D.: How cellular reprogramming could slow our aging clock (and the latest research on NAD)](https://peterattiamd.com/davidsinclair2/) | Peter Attia (peterattiamd.com) [2:03:45]

**Nir Barzilai’s big project to study metformin’s impact on aging**: [The TAME Trial](https://www.afar.org/tame-trial) | (afar.org) [2:07:45]

§

## People Mentioned

- [Mark Twain](https://en.wikipedia.org/wiki/Mark_Twain) [3:00]
- [Tim Wright](https://healthpolicy.usc.edu/author/timothy-wright-md/) [3:15, 2:09:30]
- [D.A. Wallach](https://en.wikipedia.org/wiki/D._A._Wallach) [3:45]
- [Joan Mannick](https://www.restorbio.com/team_post_type/joan-mannick-m-d/) [3:45, 17:30, 18:45, 38:00, 40:00, 49:00, 1:28:45, 2:09:30]
- [David Sabatini](https://biology.mit.edu/profile/david-sabatini/) [4:30, 20:15, 21:45, 25:45, 29:30, 37:15, 1:54:45, 2:01:45]
- [Matt Kaeberlein](https://peterattiamd.com/mattkaeberlein/) [4:30, 20:15, 1:38:30]
- [Mark Fishman](https://en.wikipedia.org/wiki/Mark_Fishman) [8:30, 16:45]
- [Jennifer Doudna](https://en.wikipedia.org/wiki/Jennifer_Doudna) [9:30]
- [Michael Hall](https://en.wikipedia.org/wiki/Michael_N._Hall) [21:45]
- [Élie Metchnikoff](https://en.wikipedia.org/wiki/%C3%89lie_Metchnikoff) [23:45]
- [Paul Ehrlich](https://en.wikipedia.org/wiki/Paul_Ehrlich) [24:45]
- [David Sinclair](https://genetics.med.harvard.edu/sinclair/people/sinclair.php) [32:45, 2:03:45]
- [Chen Schor](https://www.restorbio.com/team_post_type/chen-schor/) [40:00, 52:45, 1:29:00]
- [Suren Sehgal](https://www.sehgal.net/surenshistory.htm) [40:30, 49:30]
- [Keith Flaherty](https://www.dfhcc.harvard.edu/insider/member-detail/member/keith-t-flaherty-md/) [1:09:45]
- [Mitch Weiss](https://en.wikipedia.org/wiki/Mitch_Weiss) [1:13:45, 1:38:00]
- [James Mitchell](https://www.hsph.harvard.edu/james-mitchell/) [1:15:45]
- [Beat Nyfeler](https://www.novartis.com/our-science/postdoc-program/research-themes/pathways-biology/beat-nyfeler-phd) [1:20:45]
- [Leon Murphy](https://www.linkedin.com/in/leon-murphy-286229114/) [1:20:45]
- [Shomit Sengupta](https://www.linkedin.com/in/shomit-sengupta-5871288/) [1:40:30]
- [Joseph Murray](https://en.wikipedia.org/wiki/Joseph_Murray) [1:49:00]
- [Dudley Lamming](https://www.medicine.wisc.edu/people-search/people/staff/4646) [1:54:45]
- [George Vlasuk](https://www.linkedin.com/in/georgevlasuk400h/) (former CEO of Navitor) [1:59:30]
- [Steve Horvath](https://en.wikipedia.org/wiki/Steve_Horvath) [2:02:45]
- [Shinya Yamanaka](https://en.wikipedia.org/wiki/Shinya_Yamanaka) [2:04:00]
- [Nir Barzilai](https://peterattiamd.com/nirbarzilai/) [2:08:00]

§

![](https://peterattiamd.com/wp-content/uploads/2020/07/1x1-lloydklickstein-500x500.jpeg)

##### Lloyd Klickstein M.D., Ph.D.

Dr. Klickstein is Chief Scientific Officer of resTORbio. Prior to joining resTORbio, Dr. Klickstein was Head of Translational Medicine for the New Indication Discovery Unit (NIDU) and the Exploratory Disease Area (DAx) at Novartis Institutes for Biomedical Research.  Under his decade of leadership, NIDU & DAx teams carried multiple projects forward from target identification through clinical proof-of-concept in novel areas of drug development including liver disease, hearing loss and aging, among others.  Prior to his 13 years at Novartis, Dr. Klickstein was an academic physician-scientist at Brigham & Women’s Hospital (BWH) in Boston, where he directed an NIH-funded basic research laboratory and maintained an active clinical practice in the Arthritis Center.  Dr. Klickstein received his B.S. degree from Tufts University, his M.D. and Ph.D. degrees from Harvard University, completed post-graduate clinical training in Internal Medicine, Rheumatology & Immunology at BWH and a post-doctoral research fellowship at the Center for Blood Research in Boston.