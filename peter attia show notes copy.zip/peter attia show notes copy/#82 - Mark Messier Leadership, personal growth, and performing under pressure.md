# #82 – Mark Messier: Leadership, personal growth, and performing under pressure

**Source:** [https://peterattiamd.com/markmessier/](https://peterattiamd.com/markmessier/)

---

In this episode, Mark Messier, six-time Stanley Cup champion, shares the most valuable lessons he picked up over 25+ years of professional hockey resulting in one of the longest and most decorated careers in hockey history. Mark shares what lead to his unique brand of humble leadership, how he was able to get talented individuals to effectively work as a team, the importance of maturing and evolving as a person, and how he was able to stay calm and perform at his best under enormous amounts of pressure. Additionally, we go through his favorite moments as a player, what it was like playing with and learning from The Great One, Wayne Gretzky, and much more.

*Want more content like this? Check out our interviews with [Kristin Neff on the power of self-compassion](/kristin-neff-the-power-of-self-compassion/) and [Esther Perel on the effects of trauma](/estherperel/).*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/markmessier/the_Drive_public.png)

Play

#82 - Mark Messier: Leadership, personal growth, and performing under pressure

#82 - Mark Messier: Leadership, personal growth, and performing under pressure

1x15s30s

0:002:10:00

We discuss:

- Overview of Mark’s extraordinary 25+ year professional hockey career [7:15];
- The trend towards kids focusing on one sport earlier and earlier—A good or bad thing? [12:00];
- Mark’s early passion for hockey, and when he realized it could be his “job” [14:15];
- Going pro at age 17 [19:30];
- Mark’s favorite experience playing professional hockey [25:45];
- Playing with (and learning from) the great Wayne Gretzky [26:40];
- A hard lesson learned in his first year as a pro [32:00];
- Lessons learned from losing his first Stanley Cup Finals [35:45];
- Redemption—Winning his first Stanley Cup and the beginning of a dynasty in Edmonton [41:15];
- Importance of team character [54:00];
- The shocking trade of Wayne Gretzky, and Mark stepping up as the new leader and team captain [59:30];
- Playing for the New York Rangers—the lure of the city and the pressure to perform [1:07:00];
- Ending the 54-year championship drought for the New York Rangers [1:13:30];
- Becoming a great leader [1:16:30];
- How to win the mental war against your opponent [1:20:30];
- Opposing players for which Mark had great respect [1:22:00];
- Retiring after an unbelievably long and lustrous career [1:27:00];
- How to leverage stress and nervousness into a positive force [1:32:45];
- The most important quality—A willingness to learn, improve, and evolve [1:36:00];
- What does Mark do today for exercise to stay in great shape? [1:44:30];
- Why playing sports is such a great thing for kids [1:49:30];
- The Mark Messier Foundation [1:53:00];
- How has Mark avoided the “loss of identity” feeling which plagues many retired athletes? [1:56:15];
- Does Mark think it’s possible to reproduce a team as good as his Oilers teams of the 80s? [1:59:30];
- Would Mark ever want to coach in the NHL? [2:03:00];
- Will the Toronto Maple Leafs ever win the Stanley cup? [2:04:00]; and
- More.

§

## Show Notes

## Overview of Mark’s extraordinary 25+ year professional hockey career [7:15]

- Mark retired from hockey ~14 years go
- Played in the NHL for 25+ years
- Started professionally at age 17 (in the [WHA](https://en.wikipedia.org/wiki/World_Hockey_Association))

**Amazing Oilers teams of the 1980s**

- Playing for the great [Edmonton Oilers](https://en.wikipedia.org/wiki/Edmonton_Oilers) team in the 1980s
- [Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky), [Kurri](https://en.wikipedia.org/wiki/Jari_Kurri), [Coffey](https://en.wikipedia.org/wiki/Paul_Coffey), [Lowe](https://en.wikipedia.org/wiki/Kevin_Lowe), [Fuhr](https://en.wikipedia.org/wiki/Grant_Fuhr), [Anderson](https://en.wikipedia.org/wiki/Glenn_Anderson), and [Messier](https://en.wikipedia.org/wiki/Mark_Messier)
- Hard to imagine that modern free agency rules would ever allow a combo like this to exist on one team
- That team “put Edmonton on the map”

![](https://peterattiamd.com/wp-content/uploads/2019/12/1980-Oilers.jpg)

**Figure 1. 1980 Oilers – Gretzky, Messier, Kurri, Anderson.** Image credit: [thehockeywriters.com](https://thehockeywriters.com/mark-messier-nhl-legend/)

> “Once I started really going abroad, and that really hit it home with that we were doing something special, and actually, we had a really special team with some amazing players, that was being recognized around the world.”

## The trend towards kids focusing on one sport earlier and earlier—A good or bad thing? [12:00]

**Mark grew up in near Edmonton**

- His father played for the Portland Buckaroos and then in 1968 they moved back to Edmonton
- Starting playing hockey at 6 years old
- Mark played other sports like baseball in the springtime

**The trend towards earlier and earlier specialization**

- Some would dispute is not the most healthy thing for kids to specialize so early
- A better approach actually, which is a broader sampling of sports and developing a broader set of athletic abilities, before ultimately narrowing your focus.
- But it’s not what’s typically happening today
- It puts a lot of pressure on the parents, both on a time issue for parents and the pressure it puts on the rest of the family, but also on the financial, by having to travel consistently to different places to play tournament hockey and whatnot.
- But until you get to the age of 14, is really the age where kids start separating themselves into what they really want to do and they’re more focusing on what they want to do.
- But up until then, I’ve always believed that it’s great to try a lot of different sports and become a better athlete total, a total better athlete in all regards.

> “You got to be blessed with a God-given talent in order to make it. Then, at the right time you have to hone those skills and you have to have the desire and the passion to put the work in. But there’s a lot of kids that go through that whole process that never do make it. So, where is that fine line and that balance that’s really healthy for the family structure, healthy for the kid, and give him the best opportunity to fulfill his own dreams.”

## Mark’s early passion for hockey, and when he realized it could be his “job” [14:15]

- Mark always “played up” with his older brother
- So it wasn’t obvious to him at a young age he was anything special
- He really just enjoyed playing and watching the game
- Even though he wasn’t “standing out”, he was having a blast playing

**Started to come together at age 15**

- Around age 14 he really started to focus
- He would practice with 15-20 year olds
- Around 15 he had a growth spurt getting him to 5’9” and 150 lbs
- He ended up making a “junior team” that fall
- Began weight training at age 15 as well
  - M-W-F for 3 hours
  - Lift heavy ⇒ “*It was one of those real beefy, big-weight, heavy-weight, weight lifting programs. That really cemented it for me. I loved the workout. I could see the changes happening.*”
- Grew to 6’1” and 200 lbs by age 17

## Going pro at age 17 [19:30]

- At 17, he signed with a team in the [WHA](https://en.wikipedia.org/wiki/World_Hockey_Association)
- WHA at the time was a competitor of the NHL
- When Mark did that, he lost his eligibility to play in college (a tough decision for him and his parents)
- But the WHA soon folded
- When that happened, the NHL absorbed 5 teams
- So the NHL was now a 21-team league

**Signing with the NHL**

- Mark was drafted 48th overall in 1978 by the Edmonton Oilers
- He first met Gretzky (his now teammate on the Oilers) at training camp in 1979

## Mark’s favorite experience playing professional hockey [25:45]

- In Mark’s second season with the Oilers in 1981, they snuck into the playoffs as the final seed
- They then went on to upset the Montreal Canadians in the first round thanks to a [hat-trick](https://en.wikipedia.org/wiki/Hat-trick) by Wayne Gretzky

![](https://peterattiamd.com/wp-content/uploads/2019/11/mark-messier-fig-1.jpg)

**Figure 2. Headline in the Edmonton Journal in 1981 following the upset over the Canadians.** Image credit: [edmontonjournal.com](https://edmontonjournal.com/sports/hockey/nhl/edmonton-oilers/edmonton-oilers-history-wayne-gretzky-leads-nhl-upstarts-shock-montreal-canadiens-in-three-game-playoff-sweep-april-11-1981)

- Before the Oilers came out to the ice at their home stadium, a [video montage](https://edmontonjournal.com/sports/hockey/nhl/edmonton-oilers/edmonton-oilers-history-wayne-gretzky-leads-nhl-upstarts-shock-montreal-canadiens-in-three-game-playoff-sweep-april-11-1981) played of all the highlights from the first 2 games of the series set to the song [Impossible Dream by Tom Jones](https://www.youtube.com/watch?v=yehGtegknq0)

> “…to this day, one of my best experiences playing hockey. . .to this day, it makes the hair on the back of my neck stand up of how energized that city was.”

## Playing with (and learning from) the great Wayne Gretzky [26:40]

![](https://peterattiamd.com/wp-content/uploads/2019/12/messier-with-gretzky.png)

**Figure 3. Mark Messier (left) celebrates with Wayne Gretzky (right).** Image credit: [amazon.com](https://www.amazon.com/Oilers-Gretzky-Messier-Hockey-Photo/dp/B07NXWNGMP)

> “The chances of Wayne to win a Stanley Cup were going to be pretty good. If we all played our cards right, and we’re able to grab an oar and start rowing, and fill the need on the team, our chances increased significantly if we could follow Wayne.”

- Everyone recognized that Wayne Gretzky was on a different level, says Mark
- Gretzky still [holds the record](https://www.quanthockey.com/nhl/records/most-points-in-one-season-by-nhl-players.html) for most [points](https://en.wikipedia.org/wiki/Point_(ice_hockey)) in a single season with 215
- Gretzky is also the only player to score [50 goals in under 40 games](https://www.sportsnet.ca/hockey/nhl/day-nhl-history-wayne-gretzky-scores-50-39/) (only 2 players had done it in under 50 games)
- And he got to 50 in game number 39 by [scoring 5 goals in a single game](https://www.youtube.com/watch?v=eGBoSKPVm5g)

Mark credits Gretzky for teaching him valuable lessons in leadership

- Mark is the only player to captain two Stanley Cup teams:
  - Edmonton [won a Stanley Cup without Gretzky in 1990](https://en.wikipedia.org/wiki/1990_Stanley_Cup_Finals)
  - Mark captained the [NY Rangers to a Stanley Cup in 1994](https://en.wikipedia.org/wiki/1994_Stanley_Cup_Finals)

**The unprecedented offensive stats by Wayne Gretsky**

- No player other than Gretzky has scored more than 200 points in a season
- Yet Gretzy **averaged** more than 200 over 7 seasons (1981-1988)

## A hard lesson learned in his first year as a pro [32:00]

- In his first year as a pro with Edmonton, Mark missed a team plane flight
- At the time he was living at home with his parents
- His mom drove him to the wrong airport
- Mark rushed to the correct airport and when he got there he found a ticket was waiting for him
- But the ticket wasn’t going to Detroit with the team, it was going to Houston…where the minor league team played
- Mark had to play on the minor league team for 2 weeks to teach him a lesson

> “What you realize is that when you’re playing on a team, and you’re in a team format, nothing is about you as an individual. It’s all about what’s best for the team and your time is not your own. It’s the team’s time and you have to be respectful of that. So, there was a lot of lessons for me growing up as a young adult in a professional environment, that doesn’t always happen. But when you turn professional at 18 years old, you grow up quickly.”

## Lessons learned from losing his first Stanley Cup Finals [35:45]

Mark’s first appearance in the [Stanley Cup Finals came in 1983 against the New York Islanders](https://en.wikipedia.org/wiki/1983_Stanley_Cup_Finals)

- The Islanders were a powerhouse and had won the last 3 championships
- The Oilers were actually favored to win the series
- Mark said they felt really good going into that series
- But they were soon to realize that there was a “huge disparity” between the team cohesion of the Islanders compared to the young Oilers
- The Islands swept the series 4 games to none

> “There was a huge disparity about where they were as a team and how they played as a team compared to where we were. It was not even in the same league, and they pretty much dismantled us. . .We realized we were playing checkers and they were playing chess.”

*Do you remember leaving the arena on the night that they won the Cup?*

- We walked by their dressing room expecting a big celebratory champagne fest, and most of them were just sitting around quietly around their stalls by this time with ice packs on their bodies
- That told us that we weren’t paying the price that we needed to in order to win a Stanley Cup
- A lot of lessons leaving that rink that night

*Exposing their weaknesses*

- It wasn’t like they surprised us from a player standpoint
- They’re able to take our strengths away and expose our weaknesses and pretty much completely take us off our game
- And to everybody’s credit, the Oiler’s players came back the next season with even more vigor and determination to get it to the next level

## Redemption—Winning his first Stanley Cup and the beginning of a dynasty in Edmonton [41:15]

- The Oilers were able to return to the Finals in 1984 and [win the championship](https://en.wikipedia.org/wiki/1984_Stanley_Cup_Finals) in a rematch with the Islanders
- Additionally, Mark was awarded the [Conn Smythe Trophy](https://en.wikipedia.org/wiki/Conn_Smythe_Trophy#Winners) as the MVP of the 1984 playoffs
- The Oilers won the series in 5 games but it was a very hard fought series says Mark

> “To this day it was so amazing to see that team hang onto that championship banner and how hard they fought to relinquish it. You would think at some point we could’ve just willed it away from them, but we couldn’t. They would not relent their grasp on it and it was all we could do in that third game to win that third game. Once we won that third game, I think it kind of was the start of the wear and tear of them starting to show. . .then we were able to win the next games. Not easily, but pretty handily.”

A great lesson in humility:

- “*It was a great lesson in humility and sportsmanship. And what a real pride a champion has to watch those guys go through that whole fifth year of trying to win the Stanley Cup for five times in a row.*”

*Where does that first Stanley Cup rank in terms of the emotion you felt when that final buzzer went off?*

- Every championship has a unique feeling
- Obviously the first stanley cup is special… especially growing up watching hockey and seeing the Stanley Cup awarded every year

**Repeating as champions in 1985**

- The following year had a similar feeling as 1984
- New set of challenges, hardships, etc.
- They faced the [Philadelphia Flyers](https://en.wikipedia.org/wiki/Philadelphia_Flyers) in the Finals who had the great goalie, [Pelle Lindbergh](https://en.wikipedia.org/wiki/Pelle_Lindbergh)
- The Oilers managed to [win the series 4 games to 1](https://en.wikipedia.org/wiki/1985_Stanley_Cup_Finals)

**Going for a third consecutive title**

- As this point, the Oilers with Gretzky in his prime are looking unstoppable
- They had [Grant Fuhr](https://en.wikipedia.org/wiki/Grant_Fuhr) at goalie (Peter thinks he’s the best of all time)
- In round 2 of the playoffs, the Oilers find themselves matched up against the [Calgary Flames](https://en.wikipedia.org/wiki/Calgary_Flames)
- The Oilers are the favorite but the Flames managed to get the series to Game 7
- With the game tied, Oilers player [Steve Smith](https://en.wikipedia.org/wiki/Steve_Smith_(ice_hockey,_born_in_Scotland)) makes an unimaginable mistake by scoring on his own goal giving the Flames the lead

> “Here we are in game seven, and that’s sports. Stuff happens. When you’re in the middle of it, when something like that happens, you got to shrug it off pretty quickly. We weren’t able to rebound from it and score a tying goal and end up winning the game. They beat us in that seventh game. But that’s sports, things happen.”

- Mark says he would never blame any one single incident for losing a 7 game series
- Furthermore, he felt (as his teammates) felt compassion for Steve and said it even “*drove our team closer together in some crazy ways*”

**Bouncing back the next year to win Stanley cup and redeeming Steve Smith**

- The Oilers bounced back the following season and beat the Philadelphia Flyers in 7 games in the [1987 Stanley Cup Finals](https://en.wikipedia.org/wiki/1987_Stanley_Cup_Finals) for their 3rd championship in 4 years
- Wayne Gretzky famously accepted the trophy and handed over to Steve Smith in a moment of redemption for Steve after the devastating “own goal” the previous year

![](https://peterattiamd.com/wp-content/uploads/2019/11/steve-smith-stanley-cup.jpg)

**Figure 4. Wayne Gretzky handing the Stanley Cup Trophy to Steve Smith in a moment of leadership and redemption.** Image credit: [gamewornauctions.net](https://www.gamewornauctions.net/)

> “That’s why sports is so important in everybody’s lives, because it transcends sports. It goes much deeper than sports, especially when you’re playing on a team and doing the things that we were doing there. It wasn’t just about hockey, it wasn’t just about shooting goals and scoring pucks and all the things you would think about. It became much more about life, and life lessons, in order to sustain that kind of remarkable level of play.”

## Importance of team character [54:00]

**Regarding Steven Smith**:

“That’s what defines you, not him shooting the puck in our own goal. What would define him is absorbing that, and having the strength to absorb it, and the infrastructure around him to help him absorb it. And I think that’s what good organizations, good teams do. They help people grow not only as athletes and hockey players, but as people.

**Why character is important**:

“You need good character people in order to win. So, if you’re just talking about developing athletes and hockey players and trying to win a Stanley Cup, it’s just not going to happen.”

**The team character of the Oilers**

- There was incredible talent on the Oilers at the time
- It will probably never happen again given the new rules around free agency
- But when you have the kind of talent it’s easy to understand egos bumping heads creating friction
- So it’s vitally important you have good leadership and high character guys on the roster

*Gretzky’s leadership*

- In the Oilers case, Gretzky was so good that everybody was happy to acknowledge that this is our leader and this is the best player on our team
- It was also the way he included everybody, and as crazy as in the stats that he was having, he had a way of making someone link [Dave Semenko](https://en.wikipedia.org/wiki/Dave_Semenko) feel like he was the most important guy on the team

*Playing as a team and Balancing egos and talent with team character and accountability*

- And let’s hold everybody accountable for the job that they have, and let’s help them understand that even though on another team they may be able to play a different role, but in this team, this is a role we need you to play and we need you to do the best to your ability.
- And anything less than 100% isn’t going to cut it.
- And together we were able to help convince everybody that that was the path to success.
- We never felt jealous of Wayne. We never felt that he shouldn’t be on the ice at the end of the game when he already had four goals and four assists.
- We wanted him on the ice. We felt a part of his success. We felt that we enabled him and put him in position to have the success that he did.
- So, in a crazy way, we felt part of the reason why he was able to smash all those records.
- It was really a team philosophy that we had that we’re all in it together.

*Does Mark think his Oilers teams of the 1980s could compete in the NHL nowadays?*

- Oh yeah, says mark
- Coach Glen Sather recognized the type of talented skaters they had could wreak havoc by weaving up and down in high tempo fashion
- “*Our style with Edmonton would have fit perfectly with the way the game is being played now.*”

## The shocking trade of Wayne Gretzky, and Mark stepping up as the new leader and team captain [59:30]

“*It was devastating for everybody. It was certainly devastating for the players. We felt that we were only just beginning of what we could accomplish.*” -Mark on the Gretzky trade

- In a shocking development, the Oilers traded Wayne Gretzky in July of 1988 just after winning their 3rd Finals in 4 years
- As hard as it was to accept, Mark said the players had no choice but to collect themselves as be ready to represent the city
- In the first year after Gretzky was traded, they Oilers did not make it deep in the playoffs

Year 2 after Gretzky trade:

- But in the 2nd year after Gretzky was gone, the Oilers made it to the [1990 Stanley Cup Finals](https://en.wikipedia.org/wiki/1990_Stanley_Cup_Finals) against the Boston Bruins
- The Oilers won the series in 5 games
- It was Mark’s first championship as the team captain
- Peter and Mark viewed the meaning of that championship differently:
  - At the time, Peter’s view was that this was validation of how good the team was and that they didn’t even need Gretzky to do it
  - Mark said from the team perspective, they felt a feeling of sadness that Wayne was part of the championship
  - Instead they felt proud they were able to elevate the play of the younger guys to win it all

> “*There was never any validation from us that we’re able to do without Wayne.*”

**Final year in Edmonton and knowing it was time to move on**

- The 1990-91 season would end up being Mark’s last year in Edmonton
- Mark battled a knee injury most of the year
- They lost to Minnesota in the semi-finals

“You could just tell that chapter in all our lives was over, and that was time to go do something different in a different place, different town, and you just know it, you can just feel it. You can’t explain it. . .It was just so evident to me that it was just time to go.” qkt

## Playing for the New York Rangers—the lure of the city and the pressure to perform [1:07:00]

What mattered to Mark when deciding where to go play after Edmonton?

- Wanted a completely different challenge
- And a new venue
- And loved the lure of New York

The pressure cooker of New York

- A whole lot of pressure
- Felt like the pressure in Edmonton was high
- But NY was on a different level in terms of pressure
- But it didn’t bother Mark
- He was excited to try to end the 50+ year championship drought in NY
- He was able to perform well by making hockey his #1 focus

*A lesson learned from Wayne Gretzky*:

> “[Wayne] mentioned that everything he has is because of hockey. And he never jeopardized his performance with something that had to do with off the ice. So everything off the ice took a back seat for Wayne. Hockey was his primary focus, and so when I came to New York, I realized that I had to take that same philosophy in order to be successful here because of the distractions that are obviously abundant in a city like this. And so my focus was purely on hockey and everything else that came along with it would take a secondary role.”

*First 3 years on the New York Rangers*:

- Year 1 (91-92): Won the [President’s Trophy](https://en.wikipedia.org/wiki/Presidents%27_Trophy) but lost in the playoffs
- Year 2 (92-93): Bad season and missed the playoffs
- Year 3 (93-94): Won the [Stanley Cup in 1994](https://en.wikipedia.org/wiki/1994_Stanley_Cup_Finals)

**Missing the playoffs in 92-93**

- What was that like compared to other painful moments or seasons?
- By this time Mark was very aware of how impactful the Rangers were to the citizens of the community
- So that second year was very disappointing
- And he got to see the increased pressure and of being a losing athlete in the city

> “I got to see the other side of the city, and the pressures that can go against an athlete that’s expected to bring a championship. Luckily, I had enough experience to absorb it and articulate it in my own mind and take in the responsibility, and then have enough support around me to help get through it.”

## Ending the 54-year championship drought for the New York Rangers [1:13:30]

Before getting to the Stanley Cup they had a tough series against the [New Jersey Devils](https://en.wikipedia.org/wiki/New_Jersey_Devils)

- They were down 3 games to 2 in the series and facing elimination
- As captain, Mark was gauging his teams emotional state, and he wanted to instill some confidence in them
- Mark decided to make a bold prediction to the media and [guaranteed a victory in game 6](https://www.youtube.com/watch?v=viIVXg0AhOI)

Watch Mark get a [hat-trick](https://en.wikipedia.org/wiki/Hat-trick) in a comeback victory for the ages:

So the Rangers win game 6 and get to come back to NY for game 7

**The 1994 Stanley Cup Finals**

- Rangers win game 7 by a score of 2-1 in double overtime to head to the [1994 Stanley Cup Finals](https://en.wikipedia.org/wiki/1994_Stanley_Cup_Finals)
- The Rangers went on to win the Stanley Cup in 7 games
- Mark Messier became the **first (and to this date, the only) player to captain two teams to the Stanley Cup**

![](https://peterattiamd.com/wp-content/uploads/2019/12/mark-rangers-stanley-cup-1024x576.jpg)

**Figure 5. Mark holds up the Stanley Cup trophy in 1994.** Image credit: [nhl.com](https://www.nhl.com/news/mark-messier-100-greatest-nhl-hockey-players/c-285047996)

## Becoming a great leader [1:16:30]

***What shaped Mark into one of the great all-time leaders?***

“It really stems back to all of the lessons that I had from a father who was a hockey player, who was a team player, who was a tough defenseman who protected his teammates, and knew the value of a team in every sense for protection, for success, for individual accomplishments. He really understood what it meant to be a team player. . .

. . .[You could] just see the power of what a team can do when they are completely synced and linked together without ego and without all the things that can undermine any team in any sport.

**As a professional, Mark explains his evolution as a leader**:

“As a young guy just trying to get my own footing as a professional, but still seeing and understanding all the things that I’ve learned all along the way. And then seeing it play out in different formats and sometimes positively and sometimes very negatively.

And so you start to realize that the things that you know are actually really good and smart and healthy, and productive and that [certain things] are very toxic and detrimental and not good for anybody. . .

. . .you just start building the confidence of what you’re doing, not only as an individual, but what you’re trying to do as a team, and how you’re carrying yourself on the team. . .

. . .then you start to see other players and other great leaders and and it just starts to accumulate over time until you’re finally put in a position to have to pull the lever on some of the things that you’ve learned at critical times and having the confidence that it’s the right thing to do.”

**Leaders can make mistakes**:

> “Any great leader will tell you there that no great leader is mistake-free. Every leader makes mistakes, but it’s the equity that you’ve built up into the people that you are around that will forgive you for making an honest mistake. . . [and they] aren’t going to abandon you because of that mistake. They trust you. It was a bad decision, didn’t work out, but they still trust your vision and how you can get there.”

## How to win the mental war against your opponent [1:20:30]

- We would watch other teams and good teams be fighting with each other on the bench and yelling at each other on the ice.
- As a leader on the opposing team, I’m using that as a galvanizing force for our players to say, “*Look at these guys. They don’t even like each other.*”
- I’m using any tool I can to convince our guys that we can win no matter what it is.
- And so if I see a weak link like that, we’re going to expose that.
- When two teams are so evenly matched, the smallest things matter and you’re always looking for that little bit of evidence, that little bit of self doubt on the other team or any kind of pressure cracks at it starting to happen.
- And to use that for your own team to expose that,
- there’s so many things that go along and so you’re really start
- As you get older and you’re in a different position of leadership, you’re looking to play the game within the game, and that’s often where series and Stanley Cups are won and lost… If you can win the mental war that goes on against another team.

## Opposing players for which Mark had great respect [1:22:00]

[Bobby Orr](https://en.wikipedia.org/wiki/Bobby_Orr)

- Peter has a funny Bobby Orr story:
  - Peter had Bobby’s autograph on a hockey stick as a young kid in Toronto
  - Peter was playing hockey with friends and broke his stick so he needed another one
  - Like an idiot, he used the Bobby Orr stick and sawed off the top (which was signed) and used the bottom half to keep playing hockey with his friends
  - “*It’s like the worst thing I’ve ever done in my life.*”

[Guy Lafleur](https://en.wikipedia.org/wiki/Guy_Lafleur)

- Mark remembers a great series where Guy was on the Montreal team and they were playing the Boston Bruins
- After getting beat by Guys great offensive skills in the first 2 games, the Bruin made a claim that Guy would be “lucky to get out of Boston alive”
- “*Guy Lafleur was at the Boston Garden at two in the afternoon in full equipment smoking cigarettes and went out scored a hat trick. When I heard that story I said, wow, because I know what it was like going into the Boston Garden, so I can really appreciate performing under that kind of pressure back then.*”

## Retiring after an unbelievably long and lustrous career [1:27:00]

*How did Mark manage to have such a long career?*

- I got so lucky, Mark says

He sustained many injuries but nothing he couldn’t overcome:

- I had my both knees, ligaments stretched, MCLs probably four times in each knee
- I had arthroscopic surgery on my shoulder towards my second to last year

How many concussions did you have?

- Hard to count
- multiple concussions
- But didn’t really keep track, and back then you made sure you woke your roommate up a couple times if he did get a bump in the head
- It was completely different back then.

**What was the hardest part about retiring?**

- I didn’t really have a hard time retiring, if you can believe it.
- He knew it was his time
- He actually asked his trainer, “If I train every day, am I going to be able to, at age 44…compete with the younger guys on that kind of level?”
- His response: “No, because you’re going to need more work to rest.”

Peter has always thought there should be a way to keep a veteran player on the roster but have him limit his playing time significantly but still be there for the intangibles and leadership qualities and at the same time keep him fresh through the long grueling season

–Mark says,

- “*personally probably wouldn’t have liked that. I love playing every day. I love being in the pit. I love being in the trenches that have would have worked for me. . .*
- *. . .I just don’t think you have the equity with the players. I think you can do that and be a great resource and you can actually play, and it would be for some people, but I think to be in a big leadership role, I think one of the parts of being in a leadership role as being is actually setting an example. And being in those tough skates and being those tough times.*”

**Career stats and records**

- Mark [retired at age 44 and was just 11 games shy of Gordie Howe’s record](https://www.latimes.com/archives/la-xpm-2005-sep-13-sp-nhlretire13-story.html) for [most NHL games played all time](https://en.wikipedia.org/wiki/List_of_NHL_players_with_1,000_games_played)
- Additionally, Mark retired as the [second leading scorer of all time](https://www.quanthockey.com/nhl/records/nhl-players-all-time-points-leaders.html) behind Wayne Gretzky
- Mark clarifies, “*No, I retired as a leading score of mere mortals.*”
- [Jaromír Jágr](https://en.wikipedia.org/wiki/Jarom%C3%ADr_J%C3%A1gr) has now passed Mark pushing Mark down to 3rd all time

> “Never played for stat, never played for any kind of goal record, any kind of assist record. Any kind of a game record. I never played for any of that wasn’t even on my radar when I first came on the league, I was just trying to make the NHL. I never thought I’d even be in a position to hold any record. And so it wasn’t even in my DNA as a player to even consider something like that.”

## How to leverage stress and nervousness into a positive force [1:32:45]

Peter points out the high pressure nature of the sport and asks how Mark managed to turn the stress, anxiety, and nervousness … which can be such a destructive force …  into a constructive force for good

**Mark says the keys are**:

- The level of your preparation
- Trusting your preparation
- Practice and repetition
- Trusting your teammates to do their job
- Unwavering self-belief in who you are and what you’re trying to achieve
- Do not let doubt creep in because it will lead to mistakes
- Keeping your emotions steady (and not getting too amped up)

*⇒ A time when Mark let his emotions get the best of him*:

- Before his first Stanley Cup Finals, Mark was so amped up before the game that he had to come off the ice just 20 seconds into the game
- He was so amped his vision got blurry
- He has to go to the training room and lay on the table until he could relax a bit
- “*That was a great lesson.*”
- It’s about “*how you marry that with too much and not enough and that perfect sublime state.*”

## The most important quality—A willingness to learn, improve, and evolve [1:36:00]

- Early on, Mark became fascinated with the question of WHY Wayne Gretzky was the best player in the world
- Started to watch his practice habits and what he did in practice
- He watched his unique moves on the ice (e.g., how he was able to sauce or the puck on his forehand and backhand and where he would go in certain situations)
- “If you’re curious enough, there’s a lot of answers out there of how to become a better player, both physically and emotionally and tactically.” says Mark

Mark emphasizes the importance of having the quality of being willing to learn and grow and evolve because that it what results in being great:

- “I think that yes, you are given God-given talent, but it has to be nurtured, and honed and then you have to be willing to absorb a lot of information in order to become a good pro and a good teammate.”

**What Mark doesn’t believe in being “in the zone”**

- Mark didn’t believe in this idea that a guy would have a good game “by chance”
- Mark says it’s actually something that happened along the way in order for that to manifest itself at that particular time

–Mark says the “zone” is actually a mixture of:

- Deep level of concentration (that you’re not even aware of)
- Preparation
- Belief
- Repetition of the skill
- All of that comes together at a certain time

This “zone” can be disrupted by things outside of the sport:

- There’s a lot of external things that go on outside the game that can be conflicting and be distracting, and take away energies from you, not only physically, but also emotionally.

**The greats evolve and mature as a player AND as a person**

Mark says there are a lot of questions that need to be answered along the way of anyone’s career:

- Why am I here?
- What am I here for?
- What am I intentions?
- What is the end game?
- How am I being perceived by my teammates?
- How does the sporting hockey world perceive me?
- What am I doing off the ice to be a good citizen?
- What am I doing to contribute to the community?

–That doesn’t happen when you’re 18 years old. That doesn’t happen when you’re 20 years old. That happens over a duration of a period as you evolve as a person.

–Mark says the players maturity has to evolve as they age within their sport

–It that goes in parallel, it can lead to players like Tom Brady who are redefining their sport

**An obsession with honing your craft**

- About Tom Brady, Peter speculates…
- I don’t get the impression he’s playing for another Superbowl ring.
- Of course he wants to win another Superbowl ring, but that’s not the reason he’s playing.
- I get the sense he’s playing because **he believes he can continue to perfect his craft**
- And I suspect that that’s what the greatest players do
- The winning is just the end result of that perpetual honing

## What does Mark do today for exercise to stay in great shape? [1:44:30]

*What does Mark do today for exercise to stay in great shape?*

- “A little bit of everything”
- Weight lifting
- Cardio

*Is Mark deliberate about his training?*

- Mark used to give himself 3 hours for training
- And it would take 15 minutes for him to get mentally prepared to go through it
- After retiring he “kept waiting for that three hour window to come along, and it never came along”
- Kids, life, etc. took priority
- So today he is pretty loose about it

**Working out makes him feel better**

- I feel better when I work out.
- I physically feel more awake, more alive, more energized, fresher, sharper
- It might just be 20 minutes of cardio or a yoga session
- He tries to get workouts in 3 or 4 times per week
- But he will try anything, just wants to keep the body moving

*Does Mark still skate?*

- Occasionally
- what you realize is that you have such massive leg power when you’re playing, and when you stop that atrophies pretty quickly
- Mark estimates he skating ability is **only 10%** of what it was at his peak

> “It’s amazing how much power it takes to play hockey, from a legs standpoint, and a cardiovascular standpoint. It’s incredible.”

## Why playing sports is such a great thing for kids [1:49:30]

Mark’s 16-year-old son has aspirations to play professional hockey

*How does Mark feel about his own involvement in that process?*

- “I think he completely needs to go on that journey of self exploration, to see what he can extract from himself.”
- It’s a tough thing to grapple with
- Mark knows the work and sacrifice that goes into playing pro
- And at the same time he just wants his son to be happy
- And to be playing hockey for the right reasons
- there’s no question, being the son of any professional player in any sport is going to come with some baggage for the kids, whether they feel it as they’re expected to be a great player because their dad was, and all the things that go along with it.

> “Ultimately the reason why sports, in my opinion, are such a great thing for all kids, is that it does take you on that self journey of self awareness, and what you want to do, and are you able to do, and are you able to put the discipline in, and the time in, that’s required to be the best you can be? It doesn’t matter how good everybody else is. What do you have? And are you willing to extract every ounce of talent, and work out of your own body? That ultimately, no matter how far you take it, will serve you well in wherever you land, whether it’s in a sport, or in business, or whatever. That journey can only be beneficial for all kids, and certainly for my kids as well.”

Peter adds the following…

- Sports teaches so much about leadership and team play
- Peter loved the movie [Miracle](https://en.wikipedia.org/wiki/Miracle_(2004_film)) for showing how teams can beat individuals

## The Mark Messier Foundation [1:53:00]

What does the [Mark Messier Foundation](https://markmessierfoundation.org/) do?

- It’s about creating access and opportunity in different areas of kids’ lives there, that they would never have had the opportunity otherwise. And for different circumstances, whether it was financial, or infrastructure not available, or scholastics, or whatever.
- it spun out of the [Kingsbridge National Ice Project](https://www.cityandstateny.com/articles/policy/policy/kingsbridge-national-ice-center-nears-deal.html) that we’re trying to build here in the city, that that would provide a lot more access and opportunities to kids to play hockey in the metropolitan area

## How has Mark avoided the “loss of identity” feeling which plagues many retired athletes? [1:56:15]

**Peter brings up this idea that there are two types of retired athletes**:

  1)  Those who retire, who can never get over the fact that they’re not still 28 years old, and that their glory is no longer going to be wed to that (their identity it tied to being an athlete)

  2)  And then there are another group of athletes who retire and move on, and continue to live life to the fullest with respect to whatever the next chapters of their lives fit.

- Mark fits into category #2

*Do you have a sense of why you’re able to make that transition? And your identity doesn’t have to be wrapped up in that?*

> “I think the thing is I didn’t identify myself only as a hockey player. I think that for me to be able to do that, I needed a good family around me, and good people around you, to remind you that there’s a lot more to life than hockey. Although it’s a huge part of my life from the time I was very young, to the time I turned pro. and is one of the things that I had to really focus in on when I was 18, because it requires all your attention to perform at your highest level. But it wasn’t who I was as a person, big difference.”

**On the contrary. . .**

“*If I was 25 years old and forced to retire because of injury or something, that would have been tough to retire, no question, no question. So I’m only speaking for myself, that I fulfilled everything at 26 years pro, 44, a young family. In my own mind, was there anything left to prove from a hockey standpoint? No. Is there a lot more to prove from a philanthropic standpoint? There’s a lot more.*”

## Does Mark think it’s possible to reproduce a team as good as his Oilers teams of the 80s? [1:59:30]

The [1984-85 Oilers](https://www.nhl.com/oilers/roster/1984) were voted the [top team in the last 100 years](https://www.nhl.com/news/1985-edmonton-oilers-greatest-nhl-teams/c-289776318)

- The team has periodic reunions including one recently
- “*The connection is so strong, because you have such a deep respect for what you did together, and the commitment that each individual put forwards towards the common goal. I think that’s where the gratitude comes in.*”

**Has money and free agency changed the sport enough to never allow such a talented team to be assembled?**

Mark says that there might just be a shorter window of opportunity

“In order to win, you got to get there. Somehow or another, the team has a shorter window to do it, to bring it all together, but they have to get there on an emotional level in order to win. St Louis did it this year. When you looked at them just before Christmas, they weren’t even in the playoffs.Amazing turnaround, but somehow or another they were able to emotionally connect on a much deeper level than they had ever in the past.”

## Would Mark ever want to coach in the NHL? [2:03:00]

“*It’s hard to say. I obviously feel like I have a lot to offer any organization, any team, because of my experiences that would lend itself well to any part of the organization. Coaching is something that I enjoy, and I don’t think there’s a big difference, philosophically speaking, of coaching a 16 year old team and coaching an NHL team. Because you do have to communicate the bench awareness, the things that have to come naturally to some of the coaches. And it doesn’t come naturally to everybody. It just doesn’t. I recognize that I do have a unique ability to coach. And I think I get it from my father…So it’ll be interesting to see if that ever happens one day.*”

## Will the Toronto Maple Leafs *ever* win the Stanley cup? [2:04:00]

- Mark thinks the [Toronto Maple Leafs](https://en.wikipedia.org/wiki/Toronto_Maple_Leafs) will happen eventually (and maybe soon)
- It just takes a team (like St. Louis recently) to bring all the pieces together in a short time and pull it off
- So even a team that has been nowhere close to a championship just the year before can put in together and win
- The league is structured now that every team has weaknesses.
- There’s no perfect team out there right now.
- Every team has to decide where they’re going to put their strengths, and absorb the weaknesses, because of the salary cap era.
- And what it does is it lends itself to a very competitive environment and it also gives teams a lot of hope that it can win
- So even though Toronto is in the midst of a 50+ season drought, Mark thinks they have a good nucleus and will get it done soon

§

## Selected Links / Related Material

**Team that Mark won 5 Stanley Cup Finals with**: [Edmonton Oilers](https://en.wikipedia.org/wiki/Edmonton_Oilers) | (wikipedia.org) [4:15]

**Team that Mark won his last Stanley Cup Final**: [New York Rangers](https://en.wikipedia.org/wiki/New_York_Rangers) | (wikipedia.org) [4:15]

**Competing hockey league with the NHL:** [World Hockey Association](https://en.wikipedia.org/wiki/World_Hockey_Association) | (wikipedia.org) [8:00]

**WHA team that Mark played with for only 5 games before the team folded**: [Indianapolis Racers](https://en.wikipedia.org/wiki/Indianapolis_Racers) [8:15]

**The other WHA teams that Mark played for before the WHA folded**: [Cincinnati Stingers](https://en.wikipedia.org/wiki/Cincinnati_Stingers) [8:15]

**First team Mark played for in the NHL and won Stanley Cups with**: [Edmonton Oilers](https://en.wikipedia.org/wiki/Edmonton_Oilers) [8:40]

**NHL team in Toronto (where Peter grew up):** [Toronto Maple Leafs](https://en.wikipedia.org/wiki/Toronto_Maple_Leafs)  | (wikipedia.org) [8:45]

**Minor league hockey team that Mark’s dad played for:** [Portland Buckaroos](https://en.wikipedia.org/wiki/Portland_Buckaroos) | (wikipedia.org) [10:15]

**WHA folded in 1978:** [World\_Hockey\_Association: Decline and merger](https://en.wikipedia.org/wiki/World_Hockey_Association#Decline_and_merger) | (wikipedia.org) [19:30]

**Where Mark had planned to go and play hockey in college:** [Denver University](https://www.du.edu/) | (du.edu) [20:20]

**Bobby Hull got hockey’s first million dollar contract and it was in the WHA**: [Who Was Hockey’s First Million-Dollar Man?](https://www.liveabout.com/hockeys-first-million-dollar-man-2778723) | Jamie Fitzpatrick (liveabout.com) [22:30]

**WHA team that Gordie Howe played for:** [Hartford Whalers](https://en.wikipedia.org/wiki/Hartford_Whalers)  [22:40]

**Mark’s first year (1979-80 season) they lost in the first round of the playoffs to Philadelphia**: [1979–80 Edmonton Oilers season](https://en.wikipedia.org/wiki/1979%E2%80%9380_Edmonton_Oilers_season#Playoffs) | (wikipedia.org) [25:30]

**Team that the Oilers upset in 1981:** [Montreal Canadiens](https://en.wikipedia.org/wiki/Montreal_Canadiens) | (wikipedia.org) [25:30]

**Story about Edmonton beating heavily favored Montreal Canadians in the 1981 NHL playoffs which Mark calls his favorite moment of his career**: [Wayne Gretzky leads Edmonton Oilers to shocking three-game playoff sweep over Montreal Canadiens](https://edmontonjournal.com/sports/hockey/nhl/edmonton-oilers/edmonton-oilers-history-wayne-gretzky-leads-nhl-upstarts-shock-montreal-canadiens-in-three-game-playoff-sweep-april-11-1981) | JIM MATHESON (edmontonjournal.com) [25:30]

**Song that got the crowd energized before the close out game in Edmonton against Montreal in 1981 round 1 of the playoffs**: [Tom Jones, Impossible Dream, with lyrics](https://www.youtube.com/watch?v=yehGtegknq0) | AipOyot (youtube.com) [25:30]

**Peter’s favorite season of NHL hockey**: [1981–82 NHL season](https://en.wikipedia.org/wiki/1981%E2%80%9382_NHL_season) | (wikipedia.org) [27:30]

**Gretzky still holds the record for most points in a single season with 215**: [Most Points in One Season by NHL Players](https://www.quanthockey.com/nhl/records/most-points-in-one-season-by-nhl-players.html) | (quanthockey.com) [28:00]

**Gretzky scores 50 goals in 39 games**: [On this day in NHL history: Wayne Gretzky scores 50 in 39](https://www.sportsnet.ca/hockey/nhl/day-nhl-history-wayne-gretzky-scores-50-39/) | (sportsnet.ca) [28:15]

**Video of Wayne Gretzki scoring five goals on Pete Peters:** [Gretzky’s 5 Goals to make it 50 in 39 Games](https://www.youtube.com/watch?v=eGBoSKPVm5g) | SPORTSNET (youtube.com) [28:15]

**Mark’s first Stanley Cup Finals appearance with the Oilers when they lost to the Islanders**: [1983 Stanley Cup Finals](https://en.wikipedia.org/wiki/1983_Stanley_Cup_Finals) | (wikipedia.org) [35:50]

**Team that beat the Oilers in the Finals in 1983 … and who the Oilers beat in 1984**: [New York Islanders](https://en.wikipedia.org/wiki/New_York_Islanders) | (wikipedia.org) [35:50]

**Mark’s first Stanley Cup Final victory with the Oilers**: [1984 Stanley Cup Finals](https://en.wikipedia.org/wiki/1984_Stanley_Cup_Finals) | (wikipedia.org) [41:20]

**Mark’s second Stanley Cup Final victory with the Oilers**: [1985 Stanley Cup Finals](https://en.wikipedia.org/wiki/1985_Stanley_Cup_Finals) | (wikipedia.org) [45:30]

**Team the Oilers beat to repeat as champions in 1985**: [Philadelphia Flyers](https://en.wikipedia.org/wiki/Philadelphia_Flyers) | (wikipedia.org) [45:30]

**Steve Smith own goal in 1986 playoffs**: [Steve Smith’s horrible own goal from 1986 Smythe final](https://www.youtube.com/watch?v=q24w0OaXfa0) | SPORTSNET (youtube.com) [48:00]

**Super Bowl XXV when the Giants beat the Bill after Scott Norwood missed the final field goal attempt**: [Super Bowl XXV: Bills vs. Giants (#8) | Top 10 Upsets | NFL](https://www.youtube.com/watch?v=QkCC-crdXXE) | NFL (youtube.com) [49:30]

**In the 1994 the World Cup, Andrés Escobar scores on his own goal and he ends up getting killed**: [The goal that killed Colombia hero Escobar](https://www.youtube.com/watch?v=zMd_hi-ZOoU) | Oh My Goal (youtube.com) [53:00]

**1988-89 Stanley Cup won by Calgary:** [1989\_Stanley\_Cup\_Finals](https://en.wikipedia.org/wiki/1989_Stanley_Cup_Finals) | (wikipedia.org) [1:02:15]

**1992-93 Stanley Cup won by Montreal**: [1993 Stanley Cup](https://en.wikipedia.org/wiki/1993_Stanley_Cup_Finals) | (wikipedia.org) [1:02:15]

**Mark’s first Stanley Cup victory as a team captain after Wayne Gretzky was traded**: [1990 Stanley Cup Finals](https://en.wikipedia.org/wiki/1990_Stanley_Cup_Finals) | (wikipedia.org) [1:02:30]

**Team that Edmonton beat in the 1990 Stanley Cup Finals**: [Boston Bruins](https://en.wikipedia.org/wiki/Boston_Bruins) | (wikipedia.org) [1:02:30]

**Team with the most points wins the President’s Trophy which the Rangers did the first year that Mark Messier played there:** [President’s Trophy](https://en.wikipedia.org/wiki/Presidents%27_Trophy) | (wikipedia.org) [1:11:00]

**The NY Rangers finally win a Stanley Cup in 1994 and Mark gets his 2nd championship as a captain**: [Stanley Cup in 1994](https://en.wikipedia.org/wiki/1994_Stanley_Cup_Finals) | (wikipedia.org) [1:13:30]

**Team the Rangers beat in the first round of the playoffs in 1994**: [New York Islanders](https://en.wikipedia.org/wiki/New_York_Islanders) | (wikipedia.org) [1:13:30]

**Team the Rangers beat in the third round of the playoffs in 1994 when Mark made the “guarantee” the Rangers would win in game 6**: [New Jersey Devils](https://en.wikipedia.org/wiki/New_Jersey_Devils) | (wikipedia.org) [1:13:30]

**Mark’s game 6 “guarantee” against the New Jersey Devils**: [Messier guarantees Game 6 victory](https://www.youtube.com/watch?v=viIVXg0AhOI) | NHL (youtube.com) [1:13:45]

**Mark elects to retire just 11 games short of the games played record held by Gordie Howe**: [Messier Opts to End NHL Career Quietly](https://www.latimes.com/archives/la-xpm-2005-sep-13-sp-nhlretire13-story.html) | Helene Elliot (latimes.com) [1:30:00]

**Kid’s hockey team coached by Mark’s son, Lyon Messier**: [Washington Little Capitals](https://www.washingtonlittlecapitals.com/) | (washingtonlittlecapitals.com) [1:49:30]

**Movie about the US Olympic hockey team beating the heavily favored Russians**: [Miracle](https://en.wikipedia.org/wiki/Miracle_(2004_film)) | (wikipedia.org) [1:52:00]

**Mark’s foundation helping kids play hockey who may not have means to do so on their own**: [Mark Messier Foundation](https://markmessierfoundation.org/mark-messier/) | (markmessierfoundation.org) [1:53:00]

**Charity that Mark was involved with in Edmonton:** [Alberta Lung Association](https://www.ab.lung.ca/) | (ab.lung.ca) [1:53:00]

**The first charity that Mark got involved with when he came to New York to play for the Rangers**: [Tomorrow’s Children Fund at the Hackensack Medical University](https://www.tcfkid.org/) | (tcfkid.org) [1:53:45]

**The Kingsbridge National Ice Project is a complex which will provide more access and opportunities to kids to play hockey in the metropolitan area of New York City**: [Long-awaited Kingsbridge National Ice Center nears deal](https://www.cityandstateny.com/articles/policy/policy/kingsbridge-national-ice-center-nears-deal.html) | ANNIE MCDONOUGH (cityandstateny.com) [1:54:45]

**The 1985 Oilers were voted the top team in the last 100 years**: [1984-85 Oilers voted No. 1 Greatest NHL Team](https://www.nhl.com/news/1985-edmonton-oilers-greatest-nhl-teams/c-289776318) | Stu Hackel (nhl.com) [2:00:15]

**The most recent Stanley Cup champion (2019) and an example of a team that put it all together at just the right time to win it all**: [St. Louis Blues](https://en.wikipedia.org/wiki/St._Louis_Blues) [2:02:15]

**Toronto NHL team that is in the midst of a long championship drought**: [Toronto Maple Leafs](https://en.wikipedia.org/wiki/Toronto_Maple_Leafs) | (wikipedia.org) [2:05:15]

§

## People Mentioned

- [Gordie Howe](https://en.wikipedia.org/wiki/Gordie_Howe) [4:00]
- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) [4:15]
- [Craig Hartsburg](https://en.wikipedia.org/wiki/Craig_Hartsburg) [8:00]
- [Mark Messier](https://en.wikipedia.org/wiki/Mark_Messier) [8:45]
- [Jari Kurri](https://en.wikipedia.org/wiki/Jari_Kurri) [8:50]
- [Paul Coffey](https://en.wikipedia.org/wiki/Paul_Coffey) [8:50]
- [Kevin Lowe](https://en.wikipedia.org/wiki/Kevin_Lowe) [8:50]
- [Grant Fuhr](https://en.wikipedia.org/wiki/Grant_Fuhr) [8:50]
- [Glenn Anderson](https://en.wikipedia.org/wiki/Glenn_Anderson) [8:50]
- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) [11:25]
- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) [11:45]
- [Doug Messier](https://en.wikipedia.org/wiki/Doug_Messier) [14:20]
- [Paul Messier](https://en.wikipedia.org/wiki/Paul_Messier_(ice_hockey)) [15:30]
- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) [20:00]
- [Marshall Johnson](https://en.wikipedia.org/wiki/Marshall_Johnston) [20:15]
- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) [22:20]
- [Bobby Hull](https://en.wikipedia.org/wiki/Bobby_Hull) [22:30]
- [Gordie Howe](https://en.wikipedia.org/wiki/Gordie_Howe) [22:40]
- [Dave Keon](https://en.wikipedia.org/wiki/Dave_Keon) [22:50]
- [Johnny Mackenzie](https://en.wikipedia.org/wiki/John_McKenzie_(ice_hockey)) [22:50]
- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) [23:10]
- [Peter Driscoll](https://en.wikipedia.org/wiki/Peter_Driscoll) [23:10]
- [Grant Fuhr](https://en.wikipedia.org/wiki/Grant_Fuhr) [24:00]
- [Josh Currie](https://en.wikipedia.org/wiki/Josh_Currie) [24:10]
- [Kevin Lowe](https://en.wikipedia.org/wiki/Kevin_Lowe) [24:15]
- [Andy Moog](https://en.wikipedia.org/wiki/Andy_Moog) [24:40]
- [Glen Sather](https://en.wikipedia.org/wiki/Glen_Sather) [25:00]
- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) [26:55]
- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) [29:30]
- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) [31:00]
- [Mario Lemieux](https://en.wikipedia.org/wiki/Mario_Lemieux) [31:40]
- [Mike Bossy](https://en.wikipedia.org/wiki/Mike_Bossy) [35:55]
- [Bryan Trottier](https://en.wikipedia.org/wiki/Bryan_Trottier) [35:55]
- [Billy Smith](https://en.wikipedia.org/wiki/Billy_Smith_(ice_hockey)) [35:55]
- [Glen Sather](https://en.wikipedia.org/wiki/Glen_Sather) [40:45]
- [Pelle Lindbergh](https://en.wikipedia.org/wiki/Pelle_Lindbergh) [45:30]
- [Grant Fuhr](https://en.wikipedia.org/wiki/Grant_Fuhr) [45:15]
- [Steve Smith](https://en.wikipedia.org/wiki/Steve_Smith_(ice_hockey,_born_in_Scotland)) (own goal) [48:00]
- [Ron Hextall](https://en.wikipedia.org/wiki/Ron_Hextall) [51:50]
- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) [51:55]
- [Andrés Escobar](https://en.wikipedia.org/wiki/Andr%C3%A9s_Escobar) [53:00]
- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) [55:30]
- [Dave Semenko](https://en.wikipedia.org/wiki/Dave_Semenko) [55:45]
- [Glenn Anderson](https://en.wikipedia.org/wiki/Glenn_Anderson) [56:50]
- [Paul Coffey](https://en.wikipedia.org/wiki/Paul_Coffey) [57:25]
- [Kevin Lowe](https://en.wikipedia.org/wiki/Kevin_Lowe) [57:35]
- [Glen Sather](https://en.wikipedia.org/wiki/Glen_Sather) [58:15]
- [Anders Hedberg](https://en.wikipedia.org/wiki/Anders_Hedberg) [58:20]
- [Ulf Nilsson](https://en.wikipedia.org/wiki/Ulf_Nilsson_(ice_hockey)) [58:20]
- [Bobby Hull](https://en.wikipedia.org/wiki/Bobby_Hull) [58:20]
- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) [59:45]
- [Peter Pocklington](https://en.wikipedia.org/wiki/Peter_Pocklington) [1:01:35]
- [Glen Sather](https://en.wikipedia.org/wiki/Glen_Sather) [1:07:00]
- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) [1:09:15]
- [Babe Ruth](https://en.wikipedia.org/wiki/Babe_Ruth) [1:13:50]
- [Joe Namath](https://en.wikipedia.org/wiki/Joe_Namath) [1:13:50]
- [Bobby Orr](https://en.wikipedia.org/wiki/Bobby_Orr) [1:22:40], [1:23:15]
- [Guy Lafleur](https://en.wikipedia.org/wiki/Guy_Lafleur) [1:24:25]
- [Eric Lindros](https://en.wikipedia.org/wiki/Eric_Lindros) [1:25:20]
- [Gordie Howe](https://en.wikipedia.org/wiki/Gordie_Howe) [1:30:00]
- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) [1:36:45]
- [Tom Brady](https://en.wikipedia.org/wiki/Tom_Brady) [1:42:30]
- [Lyon Messier](https://www.washingtonlittlecapitals.com/news_article/show/781929-lyon-messier-to-lead-15u-and-2004-teams-) [1:49:30]
- [Douglas Messier](https://www.eliteprospects.com/player/420020/douglas-messier) [1:49:30]
- [Herb Brooks](https://en.wikipedia.org/wiki/Herb_Brooks) [1:51:60]
- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) [1:52:45]
- [Jerry Rice](https://en.wikipedia.org/wiki/Jerry_Rice) [2:01:05]
- [Joe Montana](https://en.wikipedia.org/wiki/Joe_Montana) [2:01:05]
- [Harold Ballard](https://en.wikipedia.org/wiki/Harold_Ballard) [2:05:55]

§

![](https://peterattiamd.com/wp-content/uploads/2019/11/mark-messier-bio-435x500.jpg)

##### Mark Messier

Mark Messier is one of the greatest players in the history of the National Hockey League. He is known for his prodigious accomplishments, unparalleled leadership skills, and unwavering dedication and loyalty to his team. Mark’s achievements over the entirety of his 26-year NHL career are astounding: Six Stanley Cup championships, 1887 points scored, placing him third on the all-time NHL list (behind only Wayne Gretzky and Jaromir Jagr), two Hart Memorial trophies as the league’s Most Valuable Player, and his standing as the only professional athlete ever to captain two different franchises – the Edmonton Oilers and the New York Rangers – to championships. He will always be cherished by New Yorkers for his success with the Rangers, especially for his legendary heroics in 1994 when he led the Blueshirts to their first Stanley Cup championship in fifty-four years.

Mark Messier’s post-career honors are numerous and ongoing. In 2007, Mark was a first-ballot selection to the Hockey Hall of Fame, and in 2009, he received the Lester Patrick Award for his outstanding contributions to hockey in the United States. In February of 2017, as the National Hockey League launched its 100th anniversary celebration, Mark was named to the list of the NHL’s 100 Greatest Players of All-Time. In June of 2017 Mark was named an Officer of the Order of Canada, a highly prestigious award which recognizes outstanding achievement, dedication to the community, and service to the nation of Canada.

Since retiring as a player in 2004, Mark has taken on executive roles with the New York Rangers and Hockey Canada and was a founder of the Messier Project that developed the M-11 hockey helmet to maximize protection, particularly in regard to concussions. Mark currently serves on the board of Answer the Call, the NY Police & Fire Widows’s and Children’s Fund, and is an active supporter of the Tomorrow’s Children’s Fund.

In 2007, the NHL instituted the annual Mark Messier Leadership Award, given annually to the player who combines excellent on-ice performance with extraordinary dedication to community and charity involvement. It is in service of those ideals of social responsibility, that Mark has created the Mark Messier Foundation. In the world of sports, the name Mark Messier has become synonymous with leadership, compassion, and success. Now, in behalf of the Mark Messier Foundation, he harnesses those same attributes to meaningfully improve the lives of those in need. [markmessierfoundation.org]