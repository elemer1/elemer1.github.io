# #137 – Paul Offit, M.D.: An expert perspective on COVID-19 vaccines

**Source:** [https://peterattiamd.com/pauloffit/](https://peterattiamd.com/pauloffit/)

---

Paul Offit is a pediatrician specializing in infectious diseases and an expert in virology and vaccine development. He currently serves on the FDA committee overseeing and evaluating COVID-19 vaccines. In this episode, Paul discusses the strategies and major companies pursuing a vaccine against the SARS-CoV-2 virus. He gets into the nuances of the vaccine approval process and its implications for COVID-19 vaccine outlook. Paul also explains potential risks, reveals his own confidence level in safety, and gives insight into protection against reinfection with vaccination. Please note that this episode was recorded 11/05/2020, prior to the 11/09/2020 news release of the Pfizer vaccine update.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/pauloffit/the_Drive_public.png)

Play

#137 - Paul Offit, M.D.: An expert perspective on COVID-19 vaccines

#137 - Paul Offit, M.D.: An expert perspective on COVID-19 vaccines

1x15s30s

0:001:35:57

## We discuss:

- How Paul’s experience as a child in a chronic care hospital as child informed his path in pediatrics and vaccine development (3:30);
- Addressing the anti-vaccination sentiment and explaining the fraudulent origins of the anti-vaccination movement (8:00);
- Lessons and insights from 26 years studying rotavirus and creating a successful rotavirus vaccine (17:00);
- Developing a new vaccine: the different phases of clinical trials, overall timeline, and financial costs (27:15);
- Operation Warp Speed: the expedited process of creating a coronavirus vaccine (32:30);
- Various vaccine strategies—RNA, DNA, virus vector—and the challenges associated (35:00);
- The Moderna and Pfizer mRNA vaccines: strategy, timeline, and Emergency Use Authorization (41:15);
- Paul’s confidence level in the safety of the first coronavirus vaccines (48:30);
- The risks associated with different types of vaccines, and updates on the Johnson & Johnson and Astrazeneca coronavirus vaccines (52:15);
- What we know about the coronavirus vaccines approved in Russia and China (55:45);
- The latest on the Merck coronavirus vaccine (57:15);
- The recombinant/purified protein vaccine approach for coronavirus—big players, risks, and the best vaccine for the elderly (57:45);
- Attenuated and inactivated vaccine strategies for coronavirus (1:02:00);
- The genetic drift of SARS-CoV-2: Impacts for protection and vaccine development (1:02:30);
- Paul’s take on the hypothesis that a previous coronavirus infection offers protection against the novel COVID-19 (1:06:45);
- Addressing the concern that antibodies fade over time (1:09:15);
- Blood type and protective against coronavirus (1:13:00);
- Distribution: the challenge of prioritizing the limited doses of vaccines after approval (1:13:15);
- Paul’s perspective on COVID-19 vaccine safety (1:16:15);
- Considerations regarding vaccinating children for coronavirus and the role of a fever immune response (1:21:45);
- Why vaccine development can be challenging and risks of current COVID-19 strategies (1:29:45); and
- More.

§

## Show Notes

## How Paul’s experience as a child in a chronic care hospital as child informed his path in pediatrics and vaccine development [3:30]

**A traumatic experience as a young boy that shaped his future**

- Paul was born with [clubbed feet](https://en.wikipedia.org/wiki/Clubfoot) (feet turned inward and down)
- He wore a brace and cast for months as an infant, but his father was not satisfied with the result
- Around age 5, his father found a surgeon to do an unproven procedure to correct this feet and it went very badly
- He ended up in a chronic care facility called Kernan’s Children’s Hospital for 6 weeks
- This was a time when polio was rampant and there was many children suffering with polio in the same hospital
- Due to polio, Paul’s parents were almost never able to come see him, and so he was mostly alone the whole time laying in bed staring out a window with nothing to do— “*I kept waiting for my parents to come rescue me, to walk through that front door of the hospital. Never happened*.”

**How that traumatic experience shaped his future career**

- As a med student at Maryland Medical School, he visited that same hospital and cried when he saw that same window he stared at every day
- “***I think that we are motivated by the scars of our youth.***”
- Paul says his decision to go into pediatrics, to go into pediatric infectious diseases, to write a book about polio specifically about a tragic event associated with the making of the polio vaccine, his choice to make vaccines…*was all motivated by the scars of his youth*.
- Almost every [book he’s written](https://www.paul-offit.com/recent-books) has, at its heart, child advocacy— standing up for children who are vulnerable, who can’t stand up for themselves.

## Addressing the anti-vaccination sentiment and explaining the fraudulent origins of the anti-vaccination movement [8:00]

**How the movement started**

- The anti-vaccination movement was catapulted by a [Lancet paper](https://briandeer.com/mmr/lancet-paper.htm) (now retracted) by [Andrew Wakefield](https://en.wikipedia.org/wiki/Andrew_Wakefield)
- The paper was comprised of 12 completely fabricated case studies that is a big part of the anti- vaccine rhetoric that the vaccines, like the [MMR vaccine](https://en.wikipedia.org/wiki/MMR_vaccine), cause gastrointestinal disease, which causes [autism](https://en.wikipedia.org/wiki/Autism)
- Unfortunately, a solid number of people continue to believe this, despite the efforts of people like [Brian Deer](https://en.wikipedia.org/wiki/Brian_Deer), [Peter Hotez](https://en.wikipedia.org/wiki/Peter_Hotez), and Paul who have so thoroughly debunked it
- Paul says Wakefield was a fraud
- Just one example, at least a couple of the children had developed signs and symptoms of autism before ever having received that vaccine—something Wakefield knew
- Brian Deer’s book, [The Doctor Who Fooled the World](https://www.amazon.com/Doctor-Who-Fooled-World-Deception/dp/1421438003), goes through the whole story

⇒ See also by Paul Offit et al. —

- [Addressing Parents’ Concerns: Do Multiple Vaccines Overwhelm or Weaken the Infant’s Immune System?](https://pediatrics.aappublications.org/content/109/1/124.short)
- [Don’t Hesitate – Vaccinate!](https://link.springer.com/article/10.1007/s40653-020-00324-y)

**Why Wakefield was good for science in a way**

- He became a darling of the anti-vaccine movement, and the anti-vaccine folks attached themselves to his star
- But once it was discovered that he not only had misrepresented clinical and biological data, but in fact had basically laundered money under legal claims through a medical journal—his star fell
- He no longer appeared on mainstream media outlets
- So at some level he helped us marginalize the anti-vaccine voices
- His popularity spurred scientists to scrutinize his claims
- Nowadays, about 85% of parents of children with autism no longer believe that vaccines were the cause according to the [Autism Science Foundation](https://autismsciencefoundation.org/)

> “There aren’t many things in medicine we can say with a higher degree of certainty actually than the MMR vaccine does not cause autism.” —Peter Attia

**The phenomenon of ‘misremembering facts’**

- The other thing that this anti-vax movement has exposed is the all-too-common phenomenon of ‘misremembering facts’
- Any of us are capable of misremembering facts, says Peter
- So much of what gave Wakefield the ability to carry on for so long was effectively parents misremembering things
- Even faced with unambiguous data about what had happened, people still sometimes struggle when we go back to remember things, especially things that are painful
- “I think we look for reasons for why things happen. That gives us some level of control, even though the reason may not be the correct one.” says Paul
- Paul calls Wakefield a “charlatan of the first order” because he took advantage of parents’ desperate desire to do something for their children

“The difference between a good scientist and a bad scientist and a charlatan is that a good scientist can look at the data when they disagree with hypothesis and modify hypothesis.” —Peter Attia

In 2000, Paul created the [Vaccine Education Center at Children’s Hospital of Philadelphia](https://www.chop.edu/centers-programs/vaccine-education-center) to address the anti-vaccine sentiment that people may have — they create and distribute educational materials to educate the press, the public, and the doctors about vaccines

## Lessons and insights from 26 years studying rotavirus and creating a successful rotavirus vaccine [17:00]

**Rotavirus**

- Paul spent about 26 years creating the strands of a virus that became the [rotavirus vaccine](https://en.wikipedia.org/wiki/Rotavirus_vaccine) (brand: RotaTeq)
- [Rotavirus](https://en.wikipedia.org/wiki/Rotavirus) is a virus that affects the small intestine and it causes fever, vomiting, and diarrhea, primarily in children between 6 and 24 months of age
- In the United States, before there was a vaccine, everybody would be infected by age 5
- It would cause about 75,000 children to be hospitalized every year with severe dehydration and about 60 children would die every year
- In the developing world, it was really the biggest killer of infants and young children, killing about 500,000 babies a year (Typically children less than two years of age)
  - The difference between this country and other countries where children die is the not severity of disease. . .It’s just that we have the resources here to keep children from dying.

**Rotavirus vaccine**

- The virus is a double stranded, segmented, RNA virus
- In the 70s, virologist [Ruth Bishop](https://en.wikipedia.org/wiki/Ruth_Bishop) was able to show clear evidence that natural infection can induce protection against the moderate to severe disease from a reinfection
- Then you know that you should just need to mimic that part of the immune response that’s associated with protection to create an effective vaccine

*How long was the protection from reinfection last after an initial infection?*

- Like many mucosal viruses, rotavirus, influenza virus, parainflu, respiratory syncytial virus, natural infection and immunization induces a protection that is short-lived and incomplete—meaning years (not decades) and meaning protection against moderate to severe disease, but not mild disease
- \***Paul thinks we will see something similar with SARS-CoV-2**

*Did Ruth Bishop’s work in the 1970s offer any insight into whether the immunity was provided more by the B-cells or the T-cells?*

- It did not—The thinking was that it was going to be an antibody response at the intestine mucosal surface meaning they had to induce an antibody response that was active in the intestinal mucosal surface (oral vaccine as opposed to injection which would simulate systemic immunity)

*What was the approach Paul took in developing the rotavirus vaccine?*

- The rotavirus is ubiquitous—every mammal has its own unique strand of a rotavirus
- However, a rotavirus in a cow, for example, would not cause the same severity of disease if introduced to a human (though it may induce immunity)
- So the initial approach was just to take a cow virus, a calf virus, that had caused diarrhea, and adapt it to growth in cell culture and then use that as the human—”**And it did work, but it was inconsistent**.”
- From there they modified the calf virus—they made a combination virus, aka reassortant viruses, between calf and animal strains that became the vaccine (way oversimplified explanation)

*What were the risks associated with the vaccine?*

- You don’t know if they will behave differently in people
- For example, a previous rotavirus vaccine caused [intussusception](https://en.wikipedia.org/wiki/Intussusception_(medical_disorder)) (intestinal blockage) in some people
  - It was a vaccine that was introduced in the late 1990s—made by the National Institutes of Health in collaboration with Wyeth—called [RotaShield](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3460207/) (a simian rotavirus)
  - It was off the market within 10 months

**\*Here’s the scary thing**: Rotavirus had been studied for 50 years by that time, nonetheless, it caused this side effect that would have *never been predicted* by all those studies

**Peter adds the following as it relates to coronavirus**: “*It speaks to aftermarket surveillance and the absolute imperative of it. And it also speaks to the fact that as we start to talk about Coronavirus, which we’re going to get to very shortly, one has to be thoughtful about risk versus reward trade- off.*”

**The COVID analogy**: “*Here’s a virus, COVID-19, which was for which we had at least the gene structure in early January of this year. . .It has already had a number of clinical and pathological surprises, which we are now about to counter with a series of vaccine strategies with which we have no commercial experience. I think it’s fair to say there’s going to be a learning curve here. So there has to be real humility I think, as we move forward*.”

## Developing a new vaccine: the different phases of clinical trials, overall timeline, and financial costs [27:15]

Preclinical studies

- **Goal**: Proof of concept
- These studies are done on animals
- Give animal the vaccine then challenge it with the virus
- If the animal were to get sick from the vaccine or the virus, you have a way to study the infection
- You can frankly literally dissect out there that part of the immune response disassociated with protection against challenge.
- Once preclinical is done, you will have settled on your way of making a vaccine
- \*NOTE: It typically takes **10 to 15 years** to get a vaccine from preclinical to phase 1

Phase 1 studies

- **Goal**: Trying to establish a dose and maybe a frequency of dose
- Usually about 20 to 100 people involved
- You give a variety of different doses to people to see whether or not you can safely induce an immune response that you think is going to be protective based on your animal model work
- You SLOWLY increase the dosage after each group of people show no bad side effects starting from the smallest dose
- In phase 1, we’re not actually able to assess whether or not people have legitimate immunity
- In other words, we’re not actually testing their ability to resist an infection, we’re measuring an antibody and you have a prediction, based on your animal model studies, that one aspect of the immune response is going to be associated with prediction to get a protection against challenges (You won’t know that until you get to phase 3)

Phase 2 studies

- **Goal**: Trying to consistently inducing an immune response that you think is protective and that it’s at least safe, i.e., doesn’t cause common serious side effects
- Usually involves hundreds of people—relatively small
- Still using surrogate markers so we don’t truly know efficacy or effectiveness in the real world
- We also don’t have a way of knowing about possible infrequent negative consequences because we’re still dealing with a very small sample size

Phase 3 studies

- **Goal**: The definitive trial you’re going to use to submit information to the FDA for licensure
- Tens of thousands of people
- \*Rotavirus example:
  - Phase 3 trial had 70,000 babies, 35,000 got the vaccine 35,000 got placebo
  - Then you just see whether or not children who got the vaccine were less likely to get rotavirus, or if they got it that they were less likely to get it severely
- This phase typically costs hundreds of millions of dollars

**\*Overall timeline and cost (typically)**: To go from preclinical trials in animals all the way to FDA approved vaccines, it usually take **15-20 years** and over **$1 billion**

## Operation Warp Speed: the expedited process of creating a coronavirus vaccine [32:30]

**Context**

- In January 2020, the sequence of the RNA identified a novel pathogen, a [coronavirus](https://en.wikipedia.org/wiki/Coronavirus) named [SARS-CoV-2](https://en.wikipedia.org/wiki/Severe_acute_respiratory_syndrome_coronavirus_2)
- By March, it becomes pretty clear this is not going to be contained meaning a vaccine was important
- But if the timeline is 15-20 years typically, that would not be helpful
- Back in Feb/March, Paul imagined a vaccine would have been **years away**

[Operation Warp Speed](https://en.wikipedia.org/wiki/Operation_Warp_Speed)

- This program initiated by the Trump administration basically took the risk away of pharmaceutical companies
- The government told the pharma companies that the govt would pay for phase 3 trials, pay for mass production without knowing whether the vaccine works, without knowing whether it’s safe, and showing a willingness to throw out those tens of millions of doses if they didn’t work out (No pharmaceutical company would ever do that)
- Paul says we’re on pace to have vaccines rolling off the assembly line into the arms of Americans by early 2021—just a *year and a quarter* in time with only having the virus in hand in January
- “*That’s remarkably fast, it’s unimaginably fast, but it’s the government that did that. So give credit to them*.”
- \*Resources on Operation Warp Speed:
  - Vaccine timeline shorted from 15-20 years to 1-1.5 years ([cited source](https://dx.doi.org/10.1126/science.abb8923))
  - [Fact Sheet: Explaining Operation Warp Speed](https://www.hhs.gov/coronavirus/explaining-operation-warp-speed/index.html)

⇒ From the NY Times: [Coronavirus Vaccine Tracker](https://www.nytimes.com/interactive/2020/science/coronavirus-vaccine-tracker.html)

## Various vaccine strategies—RNA, DNA, virus vector—and the challenges associated [35:00]

**mRNA vaccines**:

- The idea is you deliver the RNA of the coronavirus in a vehicle that then gets taken up by our DNA which then triggers an immune response to it

*The good news about SARS-CoV-2*:

- 1) We know a lot about the spike protein in the virus that attaches the virus to cells which means, in theory, you should be able to prevent the virus from infecting cells
- 2) We also know the gene that codes for that protein—It’s a single-stranded messenger RNA (mRNA) virus like rubella or German measles
- So the initial coronavirus vaccine strategies are all based on that knowledge
- The **mRNA strategy** would work like this:
  - You take the messenger RNA, which codes for that spike protein, you inject it into people
  - It’s taken up by the cell cytoplasm, the outside of the nucleus, it enters the ribosomal system, and is translated to a protein
  - Put simply, **your body** makes the coronavirus spike protein and then **your body** makes antibodies to the spike protein

![](https://peterattiamd.com/wp-content/uploads/2020/11/mRNA-offit-1024x765.png)

**Figure 1. mRNA vaccines have never been used in people before in a vaccination program. It is a genetic vaccine.** [[source](https://geneticliteracyproject.org/2020/10/05/video-vaccine-expert-paul-offit-talks-with-medscapes-eric-topol-on-the-pitfalls-and-promise-of-covid-operation-warp-speed/)]

**Similar strategies**: “genetic plug and play vaccines” — the below have a similar strategy to mRNA vaccines which is to introduce the gene that codes for the coronavirus spike protein, induce your body to make that spike protein and then your body will make antibodies.

- 1) So called “[DNA vaccines](https://en.wikipedia.org/wiki/DNA_vaccination#:~:text=DNA%20vaccination%20is%20a%20technique,causing%20a%20protective%20immunological%20response.)”
- 2) **Virus vector vaccines** such as:
  - Replication-defective simian, or human, adenovirus vaccines
  - Replication-competent vectored vaccines
  - These plus the mRNA vaccines are likely to be the first ones to come out because they’re the easiest to construct and the easiest to mass-produce (but doesn’t mean they’ll work the best)

**Back to mRNA:**

*Given the unstable nature of RNA, how is it able to work as a vaccine strategy?*

- messenger RNA (mRNA) must be stored at minus 70 degrees centigrade (or in liquid nitrogen) b/c it breaks down within moments
- To get around that problem, the messenger RNA vaccines have to be encapsulated in a complex lipid delivering system which stabilizes them to some extent.
- [Moderna](https://www.modernatx.com/modernas-work-potential-vaccine-against-covid-19) has been able to figure out a way to ship and store at minus 20 degrees, which is just freezer temperature
- But [Pfizer](https://www.nytimes.com/live/2020/pfizer-covid-19-vaccine) is going to ship and store at minus 70 minus 80 which will be a big challenge.
- Once you thaw it out and put it in the refrigerator, it can’t be there for more than a day before you give it.

**\*Interesting fact about coronavirus…**

- When you’re infected with this virus, you’ll shed infectious virus for about a week, but you’ll be PCR positive for up to three months
- But what you’re detecting in the back of the throat is not infectious virus, it’s just messenger RNA
- This is odd because RNA generally degrades to quickly, so why would it be around so much longer in the throat?
- The answer is that the virus is continuing to make messenger RNA, but not making whole virus particles.
- But it’s still unclear WHY it does this, “*I don’t know of any virus that does that*.”

## The Moderna and Pfizer mRNA vaccines: strategy, timeline, and Emergency Use Authorization [41:15]

- [Moderna](https://www.modernatx.com/modernas-work-potential-vaccine-against-covid-19) and [Pfizer](https://www.pfizer.com/health/coronavirus) are the frontrunners for a COVID-19 vaccine
- They are both using an mRNA strategy

Moderna:

- They are partnered with NIH (who holds the patent)—the nucleoside analogs that are used in that vaccine was all developed by a couple of researchers at the NIH
- Spent about $1 billion so far
- They entered phase 3 in July and are fully enrolled

The difference between Moderna and Pfizer:

- Moderna gives a hundred micrograms per dose in a two dose series
- Pfizer gives 30 micrograms, so it’s not the same nucleoside analogs
- It’s not clear how or why, but Pfizer is having to keep the vaccines at minus 70 degrees celsius whereas Moderna is able to keep them at freezer temperature
- They both sort of did a phase 2/phase 3 combined study (almost just skipped phase 2 altogether)

Challenge of keeping vaccines are proper temperature

- Paul is concern about the ability to keep the vaccines (especially Pfizer’s) at the cold temperature
- While the study researchers are on top of it, he’s worried about the pharmacies and such that will have to manage the dry ice constantly
- If the vaccines are not kept at the exact correct temperature, they could lose their effectiveness

**When might we see the data from these trials?**

- Note: Days after this podcast was recorded, Pfizer announced some early data suggesting their vaccine was [more than 90% effective](https://www.nytimes.com/2020/11/09/health/covid-vaccine-pfizer.html)
- Paul points about the executives at Moderna and Pfizer actually don’t know anything about the data because all of the research is being done by a [CRO](https://en.wikipedia.org/wiki/Contract_research_organization)—a group of academics and researchers who are not affiliated with the company

**How the trials are, presumably, set up**:

- There’s a power analysis that says, for example, we’re going to enroll 30,000 people—half get placebo, half get an active agent
- They are also likely stratified on some level by age and and current level of health
- They then have some prediction as to what percentage of people will be exposed to the virus
- Paul’s hope is that these companies do [what was recommended by Francis Collins of the NIH](https://www.nih.gov/research-training/medical-research-initiatives/activ)
  - You need at least around between 147 and 160 people to get sick in the trial in order to be able to
    - 1) reject the null hypothesis (that the vaccine does NOT work) and say ‘we have statistically significant, robust evidence that says it does’, and
    - 2) To get to a 90% confidence interval
  - Safety is being looked at in real time

Vaccine approve through Emergency Use Authorization (EUA)

- Once that information is gathered, these vaccines will be permitted under [Emergency Use Authorization](https://en.wikipedia.org/wiki/Emergency_use_authorization) (EUA) as opposed to the typical process of submitting for licensure with a biologic license application
- An EUA is a permission to use something even though there may not be clear data showing that something is safe or effective
- This can be scary for the public considering other things have recently been pushed out via EUA even though they turned out to not be effective (e.g., hydroxychloroquine and convalescent plasma—antibodies taken from people who have survived the infection)

## Paul’s confidence level in the safety of the first coronavirus vaccines [48:30]

⇒ Paul’s op-ed for the Philadelphia Inquirer: [COVID-19 vaccine, soon to be released, will likely be safe and effective](https://www.inquirer.com/opinion/commentary/covid-vaccine-safety-trials-us-2020-20201106.html)

- In Paul’s piece, is trying to answer the question of ‘**How big of a risk are we taking?’**

*In terms of effectiveness…*

- He believes they will almost assuredly be effective for at least a few months
- It less clear if it will be effective for a year or more, but he thinks it’s **likely to be effective at least for a year or two or three**
- He doesn’t think it’s going to be effective for decades
- And in the worst-case scenario, you could give a booster dose to extend the immunity period

*In terms of safety…*

- Many people are understandably worried about safety given the short period of time this has been studied before being mass-produced
- However, Paul is confident that the **2 months of follow up data** after the last dose is given in these trials will give us a clear picture of safety

*Is 2 months really enough time?*

- “*Personally, I think* ***the answer is yes***.” says Paul
- If you look historically at the serious side effects that vaccines occasionally cause:
  - Polio caused by the oral Polio vaccine, which occurred in one in 2.4 million doses.
  - Narcolepsy was caused by the squalene adjuvant in the flu vaccine occurred in roughly one in 55,000 doses.
  - Thrombocytopenia, lowering of the platelet count that occurs with measles containing vaccine occurs in one in 25,000 doses
  - Viscerotropic disease, which is basically a sort of multi-system disease caused by the yellow fever vaccine occurs in about one in a million doses
  - Guillain-Barre Syndrome, which is this ascending paralysis which can affect your ability to breathe occurs in about one in a million doses of the influenza vaccine
- In all these cases, they knew of these problems **within 2 months**

## The risks associated with different types of vaccines, and updates on the Johnson & Johnson and Astrazeneca coronavirus vaccines [52:15]

Another COVID-19 vaccine strategy is the use of **viral vectors**

- Both Johnson & Johnson and Astrazeneca are both using the same class of vaccine—replicative-defective adenovirus
  - Johnson & Johnson is using a replication-defective human adenovirus (type 26) which was genetically engineered so it contains the gene that codes for the coronavirus spike proteins
  - Astrazeneca is using a replication-defective simian (chimpanzee) adenovirus

**Paul has concern for the safety of these strategies based on three clinical holds so far**:

*With Johnson & Johnson’s product…*

- This was as a replication-defective adenovirus 26 which was genetically engineered so it contains the gene that codes for the coronavirus spike proteins
- Adenovirus is a human virus that causes a variety of clinical diseases, and type 26 is just one of the many types of adenovirus
- Replication-defective means that the virus has been genetically engineered so it **can’t reproduce itself**
- The good news with replication-defective is that it can’t cause disease because the virus isn’t reproducing itself
- The bad news is that the potential for serious side effects is greater because you have to give a lot of virus to get enough of those virus particles into the cell, to make the protein you’re interested in (About 10 billion virus particles per dose)
- The [Jesse Gelsinger story](https://en.wikipedia.org/wiki/Jesse_Gelsinger) of gene therapy was one cautionary tale to remember
  - Note that the amount of replication-defective adenovirus that Jesse got was logarithmically greater than the amount that we’re currently giving in coronavirus vaccine

*With the Astrazeneca product…*

- There were two clinical holds for the replication-defective simian adenovirus both because of neurological issues
- The first was so-called undiagnosed multiple sclerosis
- The second was transverse myelitis — an inflammation of the segment of the spinal cord.
- The mechanism by which both of those diseases happen is the same, which is that you make an immune response really to the sheathing of your nerves, particularly one protein or the sheathing of your neurons, myelin basic protein.
- Multiple sclerosis is relatively common, but transverse myelitis isn’t (maybe one in 200,000 in the general population)
- That trial was about 18,000 people which is to say 9,000 people got vaccine and they saw that case of transverse myelitis
- It was adjudicated to be likely to be coincidental and not causal, but it does worry you a little bit that, because it certainly was a statistical bizarity
- And you’d like to know what the problem was with Johnson and Johnson’s vaccine, which you don’t,
- But the point is that both the Johnson and Johnson vaccine and the Astrazeneca vaccine both in the same class of vaccine—replicative-defective adenovirus

## What we know about the coronavirus vaccines approved in Russia and China [55:45]

China has a replication-defective adenovirus type 5—they actually had approved for use in the military

- But it appears they have pivoted strategies as they are now focusing on inactivated viral vaccine
- Do we have any data on this vaccine?
- Paul has heard they have given it to tens of thousands of people, but he hasn’t seen any date from a phase 3 trial (so we don’t know if it even works)

The [Russian vaccine](https://en.wikipedia.org/wiki/Gamaleya_Research_Institute_of_Epidemiology_and_Microbiology#COVID-19_vaccine_candidate), from the [Gamaleya Research Institute](https://en.wikipedia.org/wiki/Gamaleya_Research_Institute_of_Epidemiology_and_Microbiology) in Moscow, is actually a two dose vaccine

- The first dose is a replication-defective adenovirus vaccine
- The second dose is replication-defective Ad26
- While Putin has said they have checked all the boxes and are ready to give it to the public, Paul has seen no phase 3 data that would suggest it’s ready for that
- A Venezuelan reporter told Paul that the Russian vaccine had been shipped to Venezuela for use

## The latest on the Merck coronavirus vaccine [57:15]

**Two candidate vaccines from** [**Merck**](https://www.merck.com/stories/how-we-are-responding-to-the-global-pandemic-covid-19/)

- One is the replication-competent vesicular stomatitis virus which although reproduces itself in your body doesn’t really cause disease (that’s what they use for their Ebola vaccine)
- They are also using their measles vaccine virus as a vector for this as well
- Paul has not seen any data yet from these vaccines out of Merck

**⇒ From reuters.com**: [Merck says early data from COVID-19 vaccines expected this year](https://www.reuters.com/article/merck-co-results/merck-says-early-data-from-covid-19-vaccines-expected-this-year-idUSKBN27C2BG)

Summary of vaccine pipeline Peter and Paul have discussed so far:

- Moderna and Pfizer as the big players on the mRNA front
- Johnson & Johnson and AstraZeneca as the big players on the adenovirus/viral vector front

## The recombinant/purified protein vaccine approach for coronavirus—big players, risks, and the best vaccine for the elderly [57:45]

**Simplified concept of a recombinant DNA/purified protein approach**

- You take off spike protein from the virus and give a whole bunch of them to the person
- Your body won’t be threatened by them because it has no genetic material with which to take over your cells
- But it will be able to make an immune response to them

Non-coronavirus applications of a recombinant DNA vaccine include:

- [Hepatitis B vaccine](https://en.wikipedia.org/wiki/Hepatitis_B_vaccine) and the [human papillomavirus vaccine](https://en.wikipedia.org/wiki/HPV_vaccine)
  - You take a yeast plasmid, which is just a small circular piece of DNA, you clone it into that the gene you’re interested in (so the spike protein in the case of coronavirus), and then you sort of transfect that into yeast cell, and as this Baker’s yeast reproduces itself, it also makes that protein, which you purify.
- It’s a strategy used to make one of the influenza vaccines ([Flublok](https://en.wikipedia.org/wiki/Seasonal_influenza_vaccine_brands#Flublok/Flublok_Quadrivalent))
  - Flublok is close to the strategy that’s being used by Sanofi-GSK for a coronavirus vaccine
  - You take basically an insect virus, so-called baculovirus, you clone into it the gene that you’re interested in (e.g., coronavirus spike protein gene) and then that protein actually forms rosettes
  - That’s how you make flublok
  - It’s quadrivalent

**Companies using the recombinant/purified protein approach for coronavirus**:

- [Sanofi and GSK](https://www.sanofi.com/en/media-room/press-releases/2020/2020-09-03-07-00-00) are partnering and they are getting close to a phase 3 (December 2020)
- [Novavax](https://novavax.com/our-pipeline) which is in [phase 3](https://ir.novavax.com/news-releases/news-release-details/novavax-provides-phase-3-covid-19-vaccine-clinical-development) as of November 2020

*Is there anything about this approach that tends to go really wrong?*

- It’s probably the most “benign” vaccine strategy
- It’s just a purified protein
- We have decades worth of history doing that approach successfully
- Example, [Shingrix](https://en.wikipedia.org/wiki/Zoster_vaccine#Shingrix_2):
  - A purified protein, it’s just one of the proteins from varicella zoster virus—That vaccine actually works better than the live-attenuated viral vaccines Zostavax
  - Historically, live-attenuated viral vaccines always work better than a single protein
  - But the difference was the **adjuvant**—Shingrix has two powerful adjuvants:
    - One is monophosphoryl lipid A
    - The other is the so-called QS-21…That’s all part of the varicella zoster virus glycoprotein E, has these two adjuncts that are all part of the vaccine.

**Regarding Novavax — best for the older population?**:

- The adjuvant that’s being used in a Novavax product is actually similar to the adjuvant and the Shingrix product
- If you had to take a guess, maybe this would be the vaccine that would be **best for older people** because that Shingrix vaccine works remarkably well in older people

## Attenuated and inactivated vaccine strategies for coronavirus [1:02:00]

- All the inactivated vaccines are coming out of China, says Paul
- This could have the first data from a phase 3 trial and potentially then be the first vaccine that is commercially available

## The genetic drift of SARS-CoV-2: Impacts for protection and vaccine development [1:02:30]

**Genetic drift**

*What do we know about how much the genome of SARS-CoV-2 is moving?*

- It’s a single-stranded RNA virus which means it probably mutates to some extent every time it reproduces itself

**The critical questions are**:

D*oes it mutate in a manner that makes it more or less contagious, or more or less virulent?*

*Or from the standpoint of a vaccine, does it mutate away from the vaccine enough to where* natural *infection or vaccine no longer protect you the following year?*

- Influenza is also a single-stranded RNA virus which mutates so much that we must vaccinate every year
- But measles and mumps is also a single-stranded RNA virus but you only need one vaccination for that in your lifetime
  - In other words, for measles you have different genotypes, meaning that there is enough “drift” to cause there to be different strains, but never enough for measles to have a change in its [serotype](https://en.wikipedia.org/wiki/Serotype)
  - This is why the measles virus vaccine that worked in 1963 still works today.

And so the question is: *Is this novel coronavirus going to be influenza like? Or is it going to be measles like?*

- Paul predicts that it will be **more like measles**
- If Paul is right, this is great news because it means that there won’t be enough genetic drive to alter the serotype and theoretically a vaccine could provide immunity for a long time
- In other words, **a coronavirus vaccine that works now could well work next year and the year after that**

*Peter adds some more good news*: We’re getting to about a year of COVID-19 and the viruses we’re seeing today do not look meaningfully different from what we saw in January

## Paul’s take on the hypothesis that a previous coronavirus infection offers protection against the novel COVID-19 [1:06:45]

There’s also been a lot of talk about T-cells and how some people might be getting a less aggressive version of COVID-19 because perhaps they had some T cells that recognized a separate coronavirus that they may have had, for instance, six months earlier

*What’s the latest thinking on those hypotheses and ideas?*

- SARS-CoV-2 is essentially a bat coronavirus that just reared its head in Wuhan in the middle of November of last year, and now has swept across the world and made its debut in the human population.
- That said, we are infected with [human coronaviruses](https://en.wikipedia.org/wiki/Coronavirus#Infection_in_humans) all the time (about 4 strands) and these cause respiratory infections—congestion, cough, runny nose, & occasionally more severe disease pneumonia

So the question is: *Does your previous experience with human coronavirus, which we pretty much all had, mean something to us in terms of protecting us against this virus?*

- “**I don’t think so**” says Paul

**Paul leans on his experience with rotavirus to pontificate on what “works”**:

- The trick is keeping the virus from binding to cells such as the way the measles vaccine or the varicella chickenpox vaccine works
- If you can prevent the virus from binding to cells, you can prevent the virus from entering cells
- When you make antibodies, you don’t want to just bind to the virus, you want them to **neutralize** the virus (which not all types of antibodies do)

## Addressing the concern that antibodies fade over time [1:09;15]

*So what does that mean for a vaccine if antibodies fade over time?*

- When you’re naturally infected with a virus, it’s not just that you make antibodies, you also induce immunological memory ([memory B cells](https://en.wikipedia.org/wiki/Memory_B_cell)),
  - The kind of cells that actually make antibodies are [memory T cells](https://en.wikipedia.org/wiki/Memory_T_cell)
- *Do the memory B cells matter? …* They do matter, especially for **longer incubation period diseases**
- Really short incubation period diseases—meaning the time from when you’re infected to when you get sick—they are less impacted by memory B cells
- Coronavirus is sort of a **medium length incubation** (6-7 days) whereas measles is much longer (10 to 14 days)
- *For longer incubation period diseases*, there’s enough time then for activation and differentiation of memory cells to become, in the case of B cells, antibody screening cells—So it still would work

> “When people talk to me about how nervous they are that antibodies are fading, I’m not sure you should be nervous about it yet. Let’s wait to see what happens as we move forward with these vaccines.” —Paul Offit

**Peter highlighting the points Paul just made**:

- *First*, it’s not antibodies that probably matter, it’s neutralizing antibodies
  - Frankly, we don’t have commercial tests for that.
  - So I don’t know how much it matters that your serology test that’s measuring IgG and IgM levels over time is changing, when that’s not actually, or certainly not necessarily the thing that we care about—neutralizing antibodies, not antibodies
- *Secondly*, if there’s one upside to having the long incubation period, which has allowed this silly virus to replicate like crazy and spread around the world, at least it’s that the immune system gets some chance to rev up against it
  - If this thing had no time between when you were infected and when you got sick, you’d probably get sicker because you wouldn’t have any of that memory response, but at least it would have been contained

**Paul adds another hopeful point**:

- A [recent paper from Science](https://science.sciencemag.org/content/370/6515/eabd4585) showed that when you’re infected with SARS CoV-2 you can actually make antibodies directed **against** interferons—a protein made by the immune system that interferes with the ability of virus to infect cells
- Since interferons fight viruses, you do NOT want antibodies doing that
- This fact offers hope that a vaccine may be better than natural infection, because it’s unlikely that the vaccine produce antibodies directed against interferons

## Blood type and protective against coronavirus [1:13:00]

Some [research](https://www.advisory.com/daily-briefing/2020/10/20/covid-blood-type) suggests that having Type O blood would be somewhat protective because you can make antibodies A or B types

“*I think I would still put that in the hypothesis unproven category.*” says Paul

## Distribution: the challenge of prioritizing the limited doses of vaccines after approval [1:13:15]

When a vaccine gets approved, there’s going to be some kind of rationing…

- It’s not like a we will have 300 million doses the day after approval
- So what do we know about how people are responding to a vaccine, who’s most vulnerable, and who should be getting it?

Both the National Academy of Medicine and the Advisory Committee for Immunization Practices at the CDC have come up with their first tier group—it’s a very large group, some of which include:

- Healthcare workers
- Essential personnel like people who work in mass transportation, grocery stores, pharmacies
- People working in law enforcement
- People in water purification
- People over 65
- People with certain high risk medical conditions like obesity, diabetes and chronic obstructive pulmonary disease, etc. — which is probably like 30% of the American population,
- If you add that all up, it adds up to about 150 million adults—which is half the adult population in the United States—who are going to require a two-dose vaccine (so 300 million doses)
- That is simply not going to happen immediately
- So, **how do you partition that?** … Paul doesn’t have a good answer to that, it’s going to be a real learning curve when trying to roll this out

*Who will this rationing responsibility fall to?*

- It’s the Department of Defense that’s going to take the lead at Operation Warp Speed for determining where these vaccines get distributed, but they’ll be distributed to the states.
- Then the states, I think, will decide
- The CDC initially had sort of four states and one city, which was Philadelphia actually, to try and do kind of this test program for how it would be distributed.
- Now, Pfizer is not an Operation Warp Speed vaccine, so they may have a different distribution strategy.

> “It’s a two-dose vaccine which means you have to get people back for their second dose, and some of these vaccines are going to be stored at minus 70. It’s going to be really a challenge to see how we get it out there.” —Paul Offit

**Should we mandate the vaccine for hospital workers?**

- No, says Paul, here’s why:
  - One, for the practical reason that we probably won’t have a lot of vaccines
  - Two, I think that with the novel vaccine strategy like mRNA, or these replication-defective viruses, I don’t think you really can fairly mandate that, you might need to wait and see
- “*There’s going to be plenty of people who are going to be perfectly willing to take these vaccines, and then we’ll have a few million doses out there, and we’ll have a sense of things*.”
- [Maurice Hilleman](https://en.wikipedia.org/wiki/Maurice_Hilleman), who Paul considers the father of modern vaccines, said, “*I never breathe a sigh of relief until the first 3 million doses are out there.*”

## Paul’s perspective on COVID-19 vaccine safety [1:16:15]

**Will Paul personally take the vaccine?**

- Paul says he will take it eventually, but “Not till I see the data.”
- The good news is that Paul is on the [FDA vaccine advisory board](https://www.fda.gov/advisory-committees/vaccines-and-related-biological-products-advisory-committee/2020-meeting-materials-vaccines-and-related-biological-products-advisory-committee), so he *will* see the data
- He wants to feel confident that the safety issues look good, that the immunogenicity issues look good for people his age (over 65) — “*I want to feel I’m adequately represented in these trials*.”

**Hypothetical from Peter**: At a sample size of 30,000 with a third of them are over 65, would 10,000 people over 65 having no adverse effects in three months make you feel comfortable enough to take it?

- “I think it would, yes.”
- “I feel between taking a vaccine and wearing a mask and social distancing, I dramatically decrease having to suffer this virus.”

**What scared Paul the most about COVID-19**:

- What [scares Paul the most about COVID-19](https://www.medscape.com/viewarticle/936937) is the possibility that it can cause [vasculitis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7373848/) or cardiomyopathy
- “It can cause heart attacks, it can cause strokes, it can cause liver or kidney disease because it causes vasculitis.”

*Why might it be causing vasculitis?*

- It induces your immune response to damage endothelial cells that line blood vessels, and because every organ in your body has a blood supply, every organ can be affected.
- People that experience “[long COVID](https://reference.medscape.com/viewarticle/935387)”, at least in part, are probably determined by a vasculitis, maybe even at a low level.

> “That’s what scares me about this. This is not a virus that just gets in, kills you and gets out, or gets in, makes you sick and gets out. There are longer-term effects with this virus, and it should be taken seriously.” —Paul Offit

**Peter’s personal take, and some good news about a long lasting vaccine**

- On a personal level, Peter is looking to strike a balance
- “The probability that I’m going to die from this staggeringly low, but there’s some risk that I can’t quantify of cardiomyopathy or some lingering respiratory thing that never fully resolves that impairs quality of life.”
- The real question is just the trade-off between how effective is a coronavirus vaccine relative to what other risk?
- Peter’s interpretation of Paul’s message is one he finds heartening, that within a few months of this vaccine coming out and entering the real world we will have post-market surveillance (i.e., phase four) and we’re going to have a pretty good sense of safety and efficacy

## Considerations regarding vaccinating children for coronavirus and the role of a fever immune response [1:21:45]

Paul believes vaccine testing will begin to include trials in children: [Time to include children in COVID-19 vaccine trials, experts say](https://www.healio.com/news/infectious-disease/20201004/time-to-include-children-in-covid19-vaccine-trials-experts-say)

\*\*\*

- Children are less likely to be infected, and they are usually less severely infected (only accounting for about 0.08% of the deaths)
- That said, it can cause long-term problems in children with the so-called [Multisystem inflammatory syndrome in children](https://en.wikipedia.org/wiki/Multisystem_inflammatory_syndrome_in_children) so there is a compelling desire to make a vaccine for children
- And some of the trials are lowering the age of their participants to 16 and even 12

The question is *what happens if a vaccine is approved through the EUA?*

- To get to the children, this could be done in one or two ways:
- First, it could be done as placebo- controlled trials, the same way we do adults; Or
- Secondly, it could be done as immuno-bridging studies, meaning that you actually find out there is an immunological correlate of protection in adults, that it is a certain level of neutralizing antibodies that’s invoked, and if you give to children a certain dose that you find that you get that level of neutralizing antibodies and so then you just move forward.
- Then you look retrospectively because not all children will be inoculated at the moment that you start inoculating children

**The important role of fever in fighting infections**

- Paul wrote an interesting paper this summer about the role of fever in fighting infection in children: [Could fever improve COVID-19 outcomes?](https://www.contemporarypediatrics.com/view/could-fever-improve-covid-19-outcomes)
- Peter said his article is changing the way he thinks about his use of Tylenol with his kids
- Paul also wrote a book called [Overkill: When Modern Medicine Goes Too Far](https://www.amazon.com/Overkill-When-Modern-Medicine-Goes/dp/0062947494) in which the first chapter is “in defense of fever” and discusses how treating fever can prolong, or worsen, illnesses

**Why fevers are important**:

- Pretty much everything that walks, crawls, flies or swims on the planet can make fever
- Why do we do that? We make fever not because viruses or bacteria die more quickly at a higher temperature, but because our immune system actually works better at a higher temperature:
  - B cells make antibodies more efficiently
  - Neutrophils, or white blood cells that form pus, can travel to areas where bacteria are and kill bacteria more efficiently.
- Studies repeatedly show that the people who are giving anti-fever medicines like Tylenol or ibuprofen do worse [sources found in [Paul’s article](https://www.contemporarypediatrics.com/view/could-fever-improve-covid-19-outcomes)]
- And in the world of vaccines, when people choose to treat fever with anti-fever medicines when they’ve gotten the vaccine, you have a lesser immune response  [sources found in [Paul’s article](https://www.contemporarypediatrics.com/view/could-fever-improve-covid-19-outcomes)]

> “Over and over again this has been shown, yet we just can’t help ourselves because we want people to feel better, or we want ourselves to feel better. But know this, you are hurting one part of your immune system when you do that.” —Paul Offit

**Is there a danger at some point of kids having fevers when their temperatures get too high?**

- So-called febrile seizures are benign, they’re generally short-lived, and they don’t have long-lasting sequela
- It’s not the height of the temperature that’s an issue, it’s the rapid rise in temperature that causes seizure
- Physiological fevers don’t cause harm, but environmental fevers can (e.g., heatstroke)
- Paul urges that we need to give the immune system a chance to work as good as it can: *Why cripple his neutrophils’ ability to ingest and kill bacteria by giving anti-fever medicines?*

**Is there any scenario under which you would recommend taking something like Tylenol?**

- Only if somebody cannot handle the metabolic strain of increased temperature
- For example, someone with chronic lung disease, chronic heart disease, or metabolic disease that makes you unable to handle that rise in temperature
- But otherwise, no.

## Why vaccine development can be challenging and risks of current COVID-19 strategies [1:29:45]

**Are there viruses besides the obvious, like HIV and even Hep C, where just vaccinating them is either impossible or outright dangerous?**

For example, in the case of [RSV](https://en.wikipedia.org/wiki/Respiratory_syncytial_virus)

- There’s no vaccine for it — Is that just that it’s not cost-effective, or was there sort of a more technical issue with it?
- More a technical issue of creating a vaccine, says Paul
- Bob Chanock, head of the Laboratory of Infectious Diseases at NIH, wanted to make an RSV vaccine because it causes pneumonia and can be fatal in young children, especially babies
- He took the virus, grew it up and activated it with formaldehyde (the same way the polio vaccine was made), and then gave it to babies
- What he found was that children who got that vaccine **did worse**
  - After being vaccinated and THEN getting exposed to the natural virus, they were more likely to develop pneumonia and more likely to be hospitalized than if they got the virus without first having a vaccine

*How that’s relevant to SARS-CoV-2*:

- The reason that may be relevant to SARS-CoV-2 is that both of those viruses, respiratory syncytial virus and measles, have a fusion protein just like SARS-CoV-2.
- So people are always a little nervous about an inactivated vaccine because you sort of change the confirmation of that protein, that SARS-CoV-2 protein, so it didn’t really look like it looked on the natural virus
- “You asked me earlier what sort of safety things I’m worried about. That actually is one of the safety things.”

*Would that be more of a concern with the live attenuated virus as opposed to mRNA and the viral vector viruses?*

- “I worry about it with all of them because you worry that the confirmation has made under these conditions, mRNA or DNA or replication-defective virus or a whole-kill virus, or recombinant DNA-generated proteins that it’s different, it’s critically different than the way it sits on the virus surface.”

§

## Selected Links / Related Material

**NOTE: Days after this podcast was recorded, Pfizer announced some early data suggesting their vaccine was more than 90% effective**: [Pfizer’s Early Data Shows Vaccine Is More Than 90% Effective](https://www.nytimes.com/2020/11/09/health/covid-vaccine-pfizer.html) | By Katie Thomas, David Gelles and Carl Zimmer (nytimes.com)

**Retracted Lancet paper that was the basis for the anti-vaccine movement**: [RETRACTED: Ileal-lymphoid-nodular hyperplasia, non-specific colitis, and pervasive developmental disorder in children](https://briandeer.com/mmr/lancet-paper.htm) (Wakefield et al., 1998) [8:15]

**Brian Deer’s book debunking the anti-vaccine literature**: [The Doctor Who Fooled the World: Science, Deception, and the War on Vaccines](https://www.amazon.com/Doctor-Who-Fooled-World-Deception/dp/1421438003) by Brian Deer | (amazon.com) [10:30]

**The education center Paul helped create which distributes educational materials to the press, public, and doctors about vaccines**: [Vaccine Education Center at Children’s Hospital of Philadelphia](https://www.chop.edu/centers-programs/vaccine-education-center) | (chop.edu) [18:00]

**Rotavirus vaccine that Paul developed**: [RotaShield](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3460207/) | (wikipedia.org) [25:00]

**Government program to expedite COVID-19 vaccine development**: [Operation Warp Speed](https://en.wikipedia.org/wiki/Operation_Warp_Speed) | (wikipedia.org) [34:00]

**Frontrunners in the COVID-19 vaccine candidates—both using the mRNA strategy**: [43:15]

- [Moderna](https://www.modernatx.com/modernas-work-potential-vaccine-against-covid-19)
- [Pfizer](https://www.pfizer.com/health/coronavirus)

**The framework for a vaccine study designed by Francis Collins**: [ACCELERATING COVID-19 THERAPEUTIC INTERVENTIONS AND VACCINES (ACTIV)](https://www.nih.gov/research-training/medical-research-initiatives/activ) | (nih.gov) [48:45]

**Paul’s op-ed in the Philadelphia Enquirer regarding the safety of a potential COVID-19 vaccine**: [COVID-19 vaccine, soon to be released, will likely be safe and effective](https://www.inquirer.com/opinion/commentary/covid-vaccine-safety-trials-us-2020-20201106.html) | Paul Offit (inquirer.com) [51:00]

**Info about the two COVID-19 candidate vaccines from Merck**: [Your questions answered: How Merck is responding to the COVID-19 pandemic](https://www.merck.com/stories/how-we-are-responding-to-the-global-pandemic-covid-19/) | (merck.com) [1:00:00]

**Companies using the recombinant DNA/purified protein approach strategy for a COVID-19 vaccine**: [1:00:45]

- [Sanofi and GSK](https://www.sanofi.com/en/media-room/press-releases/2020/2020-09-03-07-00-00) (moving to phase 3 in December 2020)
- [Novavax](https://novavax.com/our-pipeline) (in [phase 3](https://ir.novavax.com/news-releases/news-release-details/novavax-provides-phase-3-covid-19-vaccine-clinical-development) as of November 2020)

**A recent paper from Science showing that a SARS CoV-2 infection can produce antibodies directed against interferons—a protein made by the immune system that interferes with the ability of virus to infect cells**: [Autoantibodies against type I IFNs in patients with life-threatening COVID-19](https://science.sciencemag.org/content/370/6515/eabd4585) (Bastard et al., 2020) [1:15:10]

**Research suggesting that having Type O blood would be somewhat protective against COVID-19**: [Does your blood type affect your Covid-19 risk? Here’s the latest evidence](https://www.advisory.com/daily-briefing/2020/10/20/covid-blood-type) | (advisory.com) [1:16:30]

**Paul’s article about the role of fever in fighting infection in children**: [Could fever improve COVID-19 outcomes?](https://www.contemporarypediatrics.com/view/could-fever-improve-covid-19-outcomes) | Paul Offit (contemporarypediatrics.com) [1:29:45]

**Paul’s book that mentions the overuse of Tylenol and other fever reducing medicines**: [Overkill: When Modern Medicine Goes Too Far](https://www.amazon.com/Overkill-When-Modern-Medicine-Goes/dp/0062947494) by Paul Offit | (amazon.com) [1:29:45]

§

## People Mentioned

- [Andrew Wakefield](https://en.wikipedia.org/wiki/Andrew_Wakefield) [8:15]
- [Brian Deer](https://en.wikipedia.org/wiki/Brian_Deer) [9:00]
- [Peter Hotez](https://en.wikipedia.org/wiki/Peter_Hotez) [9:00]
- [Ruth Bishop](https://en.wikipedia.org/wiki/Ruth_Bishop) [21:45]
- [Francis Collins](https://en.wikipedia.org/wiki/Francis_Collins#:~:text=Francis%20Sellers%20Collins%20(born%20April,Bethesda%2C%20Maryland%2C%20United%20States.) [48:45]
- [Jesse Gelsinger](https://en.wikipedia.org/wiki/Jesse_Gelsinger) [56:00]
- [Murphy Brown](https://en.wikipedia.org/wiki/Murphy_Brown) [1:16:00]
- [Maurice Hilleman](https://en.wikipedia.org/wiki/Maurice_Hilleman) [1:20:50]

§

![](https://peterattiamd.com/wp-content/uploads/2020/11/bio-image-offit-500x500.png)

##### Paul Offit, M.D.

Paul Offit is a pediatrician specializing in infectious diseases and an expert on vaccines, immunology, and virology. He is the co-inventor of a rotavirus vaccine that has been credited with saving hundreds of lives every day. Offit is the Maurice R. Hilleman professor of vaccinology, professor of pediatrics at the Perelman School of Medicine at the University of Pennsylvania and director of The Vaccine Education Center at  Children’s Hospital of Philadelphia (CHOP). Offit is currently a member of National Institutes of Health (NIH) working group on vaccines, a subgroup of the “Accelerating COVID-19 Therapeutic Interventions and Vaccines” (ACTIV) comprised of experts to combat COVID-19. He is also a member of the FDA’s Vaccines and Related Biological Products Advisory Committee (VRBPAC). Previously, he was a member of the Centers for Disease Control and Prevention’s (CDC) Advisory Committee on Immunization Practices. Offit is a board member of Vaccinate Your Family and Autism Science Foundation.  “Overkill” is his 11th book. [[paul-offit.com](https://www.paul-offit.com/about-paul-offit-md)]