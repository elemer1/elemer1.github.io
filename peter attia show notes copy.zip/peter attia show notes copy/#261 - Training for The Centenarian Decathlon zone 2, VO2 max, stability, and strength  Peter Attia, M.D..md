# #261 ‒ Training for The Centenarian Decathlon: zone 2, VO2 max, stability, and strength | Peter Attia, M.D.

**Source:** [https://peterattiamd.com/training-for-the-centenarian-decathlon/](https://peterattiamd.com/training-for-the-centenarian-decathlon/)

---

In this special episode filmed live in front of readers of Outlive, Peter answers questions revolving around his concept of the centenarian decathlon. He starts by defining the “marginal decade” and how that shapes his training for the events and activities that make up his personal centenarian decathlon. Peter explains how he coaches patients through the challenges of customizing their own list and building out a training plan, including how to set fitness goals early in life in preparation for the marginal decade. From there, he dives into training within the four pillars (zone 2, VO2 max, stability, and strength), including the minimum effective dose, how to split your time, his personal protocols, and other considerations. Additionally, he touches on bone mineral density, female-specific considerations, working through injuries, and the profound impact training can have on the overall quality of life.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/training-for-the-centenarian-decathlon/the_Drive_public.png)

Play

#261 ‒ Training for The Centenarian Decathlon: zone 2, VO2 max, stability, and strength | Peter Attia, M.D.

#261 ‒ Training for The Centenarian Decathlon: zone 2, VO2 max, stability, and strength | Peter Attia, M.D.

1x15s30s

0:001:04:51

## We discuss:

- The best interventions for longevity [2:15];
- The marginal decade and the centenarian decathlon [4:45];
- Peter’s personal list of events for his “centenarian decathlon” and how he helps patients create their own list [8:00];
- Determining your fitness goals early in life in preparation for the marginal decade, metrics to track, and more [15:00];
- How does playing sports like tennis, basketball, or golf fit into training for the centenarian decathlon? [24:15];
- Training within the four pillars: minimum effect dose, how to split your time, and other considerations [27:45];
- Advice for the older person and why it’s never too late to start [33:45];
- Bone mineral density and other female-specific concerns and considerations [36:15];
- Training advice for those with minimal access to a gym or equipment [39:30];
- Injuries: prevention and working through existing conditions [41:00];
- Cardiorespiratory training: how to split time between zone 2 and VO2 max training, and different modalities for a true zone 2 workout [44:15];
- VO2 max training: modalities, Peter’s protocol, and how to monitor progress [54:45];
- The profound impact training can have on the overall quality of life [58:15]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- This is a special episode where we recorded this AMA live in April 2023, celebrating the release of [*Outlive*](https://peterattiamd.com/outlive/)
- We received a good bit of feedback from those who attended this episode live, so we decided to make it more widely available
- Our AMAs are typically reserved only for subscribers, so if you’re not a subscriber, this might give you a bit of an idea of what our AMAs are like
  - Although, this is not the typical format
  - Usually our AMAs go a little bit deeper into content than this one
- In this episode, we focus the entire conversation around the centenarian decathlon
  - Events in Peter’s centenarian decathlon and how he decided on them
  - How he works with patients to create their own list
- We then talk about how people can know if they’re on track for their centenarian decathlon across a variety of ages and the various fitness tests that can help determine that
- We focus the rest of the discussion around training for the centenarian decathlon
  - What that training should look like, whether you’re older, younger, new to exercise, or a veteran
  - We talk about some questions that came up around zone 2 and VO2 max training

## The best interventions for longevity [2:15]

- Everyone who pre-ordered the book could sign up for this live event
  - They submitted a bunch of questions
  - The team went through thousands of questions and tried to group them and organize them to get through as many as possible
  - We apologize if we don’t answer your question

**What’s the best thing you can do for longevity?**

*If you have five tactics in a tool kit, but if there’s just one thing people should focus on, what would that be?*

- This is an impossible question to answer because if you have a person who is sleeping four hours a night and you don’t fix that, nothing else will matter
- Likewise, if you have a person who is malnourished, you have to address these issues
- Generally speaking, if everything in your life is a 6 or 7 out of 10, **taking your exercise to a 10 out of 10** is going to have a “*greater impact on both the length and quality of your life than any of the other domains that I can think of*” says Peter
- An exception would be emotional health; that’s one that can be such a binary thing
  - If you take a person who, for example, like Peter, where that house is not in order until that’s addressed, all the exercise in the world wouldn’t fix that either

## The marginal decade and the centenarian decathlon [4:45]

**Quickly define two terms we use quite a bit:** ***centenarian decathlon*** **and** ***marginal decade***

*The marginal decade is the last decade of your life*

- So everyone will have a marginal decade
- Most people certainly don’t know the day they enter it
  - Sometimes, when you’re in it, especially if you’re nearing the end of it, a person probably has a sense of that appreciation
- The marginal decade is an important model because for most people this is really a period of poor life quality
  - Physical health has usually declined significantly
  - Cognitive health potentially has declined as well
- Peter has observed many people in their marginal decades (including people he’s been close to), and he noticed that there can be a great sense of withdrawal because of these things
  - They’re not participating in life

***If you plan to have a remarkable marginal decade, by definition it means that all the decades that came before it also had to be pretty remarkable***

*In the* [*book*](https://peterattiamd.com/outlive/)*, Peter uses the analogy of an archer:*

- If you really want to be proficient at 50 yards with a bow and arrow, practice at 100
  - And you’ll be amazed at how simple 50 becomes and 60, and 70, and 80
  - It’s a very non-linear relationship in terms of accuracy with a bow and arrow
- The centenarian decathlon becomes the scaffolding upon which Peter actually thinks of this

*This came from an observation Peter had in his own life, which was from age 13 to about 42*

- He was constantly involved in something very specific that he was training for
- He never exercised, he trained
  - Trained for boxing, cycling, swimming
  - He had competitions/meets
  - Everything he did vis-a-vis exercise was in service of a goal, and that made it very easy
  - There was real specificity to what he did
- When he hung up his bike, he was still exercising, but it didn’t feel like it had a purpose
  - He realized, “*Oh, my God, I don’t know what I’m doing*.”
  - He realized that’s how most people exercise
    - And when compared to the alternative (not exercising), that’s okay
- As Peter thought more about the marginal decade, he needed to be very specific in his training to make sure he didn’t arrive there and leave it to chance if he would be strong enough, healthy enough, have enough balance
- To borrow a phrase from [Annie Duke](https://www.annieduke.com/about/) ([episode #60](https://peterattiamd.com/annieduke/)), he realized he had to “backcast” from that marginal decade around a set of very specific events
  - And that set of events he would call the **centenarian decathlon**
    - Everybody’s going to pick different events
    - These can be activities of daily living
    - These could be very specific recreational activities
    - It’s a good idea to have both in there

***The more specifically you train for those, the more directed your training is***

## Peter’s personal list of events for his “centenarian decathlon” and how he helps patients create their own list [8:00]

**Peter’s centenarian decathlon list**

- Peter explains that it’s organized in a way that is a bit confusing because in his mind he is constantly thinking: mobility and strength matter, aerobic capacity and efficiency matter, peak aerobic performance matters
  - He wants to be sure he can do all of those things well
  - Some of the items on his list are like exercises, or metrics, or feats, and others are activities

**The four pillars of exercise, in no particular order**

- 1 – Aerobic efficiency refers to [zone 2 exercise](https://peterattiamd.com/category/exercise/aerobic-zone-2-training/)
- 2 – Peak aerobic output refers to [VO2 max](https://peterattiamd.com/category/exercise/high-intensity-zone-5-training/)
- 3 – Within [stability](https://peterattiamd.com/category/exercise/stability/) is mobility, balance, and things like that
- 4 – [Strength](https://peterattiamd.com/category/exercise/strength-muscle-mass/)
- Peter explains this further on the [website](https://peterattiamd.com/framework-for-exercise/)

**Peter’s list, in no particular order**

- Pick up a 30-pound child from a squatted position or from a crib
  - Those are two very difficult positions
  - That requires strength, stability, mobility
- Get up off the floor with one point of support
  - That’s stability and strength
- Place a 30 pound suitcase overhead
  - Strength, also mobility
- Dead hang for 30 seconds
  - Strength, and stability
- Farmer walk for one minute with 25% of body weight in each hand
  - That’s something that today Peter could do for a day
  - That’s really pushing the bounds of what he would want to be able to do in his 80s
  - Strength and anaerobic
- Pull or push a weighted sled 100 feet with a metric of resistance
  - This is one of those things if you’re in a dangerous situation, a spouse has fallen, you have to pull somebody out of the way, or something like that
- Walk up and down stairs with feet pointed perfectly forward
  - If your feet are pointed perfectly forward as you’re walking up and down flight, so stairs, it means you still have the ankle mobility to do that
  - You can get an angle between your foot and your tibia, your shin, into an acute angle as opposed to having to turn your feet outward
- Single-leg stand with eyes open for 30 seconds, with eyes closed for 15 seconds
- Single-leg get up without support
  - So getting up off a seat, for example
- Hex bar deadlift his body weight for five reps
  - Again, pretty aggressive for age 80, but easy now
- A dumbbell lunge in perfect form with 15% of his body weight in each hand for 10 reps
- Cover three miles in one hour by foot
  - A 20-minute mile is pretty slow, but think about being able to do that in the last decade of your life
- Carry 20 pounds up four flights of stairs
- Produce a [VO2 max](https://en.wikipedia.org/wiki/VO2_max) above 30 mL/min/kg
  - If you can do that, that basically buys you a whole bunch of activities
  - That means you could walk up a 6% grade at three miles an hour for a period of time, not necessarily for an hour, but perhaps for 20-15 minutes
- Tread water for 10 minutes
  - Not that he has a plan to, but again, you think about what’s implied, that’s a very functionally anaerobic thing to do
- Scale a ledge at shoulder height or pull himself out of a pool onto a deck, 12 inches above the water surface
- Single-leg glute bridge, 15 reps without loading his lumbar spine
- Do a plank in perfect form with scapular retracted, no hip sag for one minute
- Peter has several of these lists
- There are things that he would add to this that he has on a different list that get more into recreational activities
- He wants to be able to pull a 50-pound bow back (a compound bow that’s 50 pounds; and a compound bow of course lets off as you get further, but you still have to be able to pull 50 pounds at the outset)
- Nick adds, “*I think it’s helpful for people because, if you think about the list you made, they’re very specific things, but you hinted at there’s a reason behind everything.*”
  - The dumbbell is being able to lift grandkids/ great grandkids that you want to be able to play with
  - Being able to get off the ground means you want to be able to live by yourself or with a spouse and be able to full move and not worry about falling
  - Wanting to live in a city area where you can walk to get groceries and bring them back

**Is it purposeful that emotional health is not on your centenarian decathlon list?**

- Emotional health is the only piece of healthspan that can actually go up with age
- Yeah, the centenarian decathlon is focusing purely on that physical piece that is invariably going to decline
- It doesn’t really get into the cognitive or as you said, the emotional part, which, if we’re really doing that right, should be getting better as we age

**When you talk to patients about the centenarian decathlon, what encouragement do you give them as they are starting to think about creating this list?**

- Peter has gone through several iterations on this
- Initially, they asked patients to do what he did ‒ sit down and come up with the list
  - But that didn’t produce as much fruit perhaps because people weren’t putting as much thought into it as he did
- What he does now is give patients a list of about 50 items, and ask them to pick 10
  - About half of them are activities of daily living
  - About half of them are sort of feats of fitness or strength
  - He used to say, “*Pick as many as you want,*” but you have to prioritize what are the 10 most important things on this list
- Then he asks, “*To do those things, do you know what is required?*”
  - To pick up a 30-lb child off the ground
  - What type of stability is required? What type of strength is required?
  - How much will that require you to be able to do today based on the extrapolation of how much each of those parameters declines?

## Determining your fitness goals early in life in preparation for the marginal decade, metrics to track, and more [15:00]

**Are these the things you want to do at 100?**

- Peter doesn’t expect to live to 100
- In his 80s is where he hopes his marginal decade is

**How do you help patients backcast and figure out what their goal should be at age 40 to do X or Y at age 80?**

*On Peter’s list are the things he wants to be able to do in his marginal decade. How much should you be able to do in your 30s, 40s, or 50s?*

- We have a pretty good sense of how major parameters like strength and [VO2 max](https://en.wikipedia.org/wiki/VO2_max) decline with age
- Even though Peter can do everything on that list blindfolded, it’s going to take a lot of work to make sure that his VO2 max is 30-32 mL/min/kg in 30 to 40 years, especially if it’s closer to 40 years
  - Truthfully, right now his VO2 max is not what he’d like it to be
  - It’s probably in the mid-50s, which is again fine for somebody his age, but he really would like a bigger margin of error and maybe want it to be mid to high 50s as opposed to low to mid-50s
- So if you’re 30 (20 years younger than Peter), the bar is even higher
- Paradoxically, the youngest people aren’t necessarily in the best shape here on a relative basis
  - They might be in absolute terms, but they have longer to maintain that and therefore they need to be starting from a higher place

**Metrics and tests to determine your VO****2** **max**

- Peter doesn’t know if VO2 max is necessarily the single best metric of cardiorespiratory fitness, but it’s the one that’s been studied the most
- It’s a $100-150 test you can find in most cities
  - There are also free versions
  - You can estimate it
  - You could run a [Cooper’s test](https://en.wikipedia.org/wiki/Cooper_test) or various versions of these tests
  - Discussed in many previous episodes including: [#144](https://peterattiamd.com/philmaffetone/), [AMA #39](https://peterattiamd.com/ama39/), [#217](https://peterattiamd.com/mikejoyner/), [#201](https://peterattiamd.com/inigosanmillan2/)
  - You could [go to a track and run a mile](https://www.livestrong.com/article/343028-how-to-calculate-vo2-max-from-running/)
  - You can look up the VO2 max [protocol](https://en.wikipedia.org/wiki/VO2_max#Measurement_and_calculation)

**The question then becomes, what are some other metrics that go with it?**

*Metrics for strength*

- A great metric for both upper body strength and grip strength is a [farmer carry](https://www.youtube.com/watch?v=z7E_YU9P1jU)
  - A farmer carry is literally carrying weight in each hand and walking
  - For men, a guy in his 40s should be able to carry his body weight for a minute (half of his body weight in each hand)
    - If he weight s180 lbs, he should be able to carry 90 lbs in each hand and walk for a minute
  - For a woman who is 40, she should be able to carry 75% of her weight
- The [dead hang](https://youtu.be/3CEmHJXbNpc) is another great one for grip strength
  - A man in his 40s should be able to do this for two minutes
    - And that gets discounted roughly 10-15 seconds per decade as you go from 40 to 50, etc.
  - A woman in her 40s should be able to dead hang for a minute and a half
- Another great example of strength is a [wall sit](https://youtu.be/PYva1ogC49s)
  - If you can do a wall sit for two minutes
  - Sitting with your back against the wall, your thighs parallel to the ground, and not using your hands
  - This is one way to test leg strength
- Peter will typically test leg strength in a more free form; he has people do an [air squat](https://youtu.be/C_VtOYc6j5c) where they’re basically hovering but not using their back for support
  - That’s a little more stressful because you’re not just using your legs, you have to stabilize
  - On the wall sit, you get all the stabilization for free because you’re pushing back into the wall

*Metrics for zone 2*

- Zone 2 is technically defined based on lactate production
- The simplest way for most people to define it is the RPE way ([rating of perceived exertion](https://en.wikipedia.org/wiki/Rating_of_perceived_exertion))
  - Zone 2 is that threshold where you go from being able to speak while you’re exercising, but being uncomfortable, to not being able to speak
    - You can speak, but only a few words, you don’t want to carry on a conversation
    - Zone 1 would be talking normally, and for Peter, this is going for a walk or rucking on flat ground
  - Where most people cross that threshold is where you will now start to net accumulate lactate with your activity
- And so figuring out and demonstrating that you can generate more and more work at that level, whether it be wattage or speed (or whatever your metric you’re using), that becomes an enormous way to track your progress

**Muscle mass and other metrics to target [21:15]**

*Percentiles of muscle mass to aim for*

- You can look at metrics of muscle mass from a [DEXA scan](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry)
  - Discussed in AMA [#44](https://peterattiamd.com/ama44/), [#40](https://peterattiamd.com/ama40/), [#17](https://peterattiamd.com/ama17/)

> “*I think everybody should have a DEXA scan. You just have to know this data.*”‒ Peter Attia

- A DEXA scan will tell you your bone mineral density, how much visceral fat you have, how much muscle mass you have
  - It will calculate (or give you the data so you can calculate) the ALMI (appendicular lean mass index) and FFM (free fat mass)
  - The report will show lean mass for left leg, right leg, left arm, right arm; and you can add those up in kilograms and divide by your height in meters squared
  - You’ll get a number, and it can be 8, 9, or 10 for a man, or 5, 6, 7, or 8 for a woman
- Once you have the ALMI, there are nomograms that will tell you, for your age and sex, what percentile you are in (discussed in detail in [AMA #40](https://peterattiamd.com/ama40/))

***Peter wants all of his patients to be at or above the 75th percentile for ALMI***

- This is associative data, but it’s very strong associative data
- Muscle mass is a great integrator of exercise and strength
- In comparison, [hemoglobin A1C](https://en.wikipedia.org/wiki/Glycated_hemoglobin) is a metric that is effectively an integral function for glucose
  - If your number is 6.5, it tells you directionally over the last three months, your average blood glucose has been 140 mg/dL
  - The hemoglobin A1C integrated the area under the curve
- Similarly, that’s effectively what VO2 max, muscle mass, and strength are doing
  - They are integrators of the work that it takes to have a high VO2 max, to have high muscle mass, to have high strength

> “*And the work that goes into that is the secret sauce*”‒ Peter Attia

- In other words, it’s not so much the muscle mass, that is the most important thing; it’s what you had to do to get said muscle mass
  - And what that muscle mass will then do vis-a-vis metabolic function
  - And the implication with respect to the functional side of things
- Muscle mass and strength are not equivalent, and when put head-to-head, strength beats muscle mass as a predictor of lifespan
- But all of these things are important metrics to be tracking

## How does playing sports like tennis, basketball, or golf fit into training for the centenarian decathlon? [24:15]

- The bulk of questions were around:
  - How much should I be training?
  - How much should I train in the different pillars?
  - What is the best zone 2 training?
  - How many times a week?
  - How does playing basketball, tennis, golf fit into this?
  - How important is it to specifically strain and hit all of those pillars?
- The answer depends on your objective, and **everything has to be compared to the alternative**
- If a person asks, “*I’m playing tennis twice a week. I’m playing basketball twice a week and I’m lifting weights once a week, am I doing great?*”
  - The answer is yeah, you’re doing great relative to most people
  - But that’s not a recipe for success if you want to be in the best shape possible in your last decade
  - Any sport (basketball, tennis, swimming) has so much repetitive stress in it that you’re going to develop movement issues
    - You’re going to have asymmetries in joints, in muscles, and you want to balance those things out as much as possible
- If you know want to be able to play golf every week and you’re going to walk five miles, that’s great, but you have to acknowledge every time you’re swinging that club, it’s asymmetric
  - You have to think about, “*What am I doing to counteract that?*”
  - The same with tennis and basketball
- It depends on how much time a person is willing to put into this
- Peter adds, “*I don’t want to suggest that everybody needs to do this because I acknowledge it’s really difficult. If it wasn’t difficult, everybody would be doing it already. By definition, this is really a complicated idea.*”

**Peter had the privilege to experience his marginal decade in his 20s**

- He had a back injury when he was 28 that left him unable to walk for three months and in so much pain, he didn’t know his name for a year
- During that period, he would’ve given his life to have had everything back
- When he got it back, the feeling of what it was like to be so immobile, so debilitated, and in so much pain was seared into his brain
- It changed his mindset, and he wanted to do everything in his power to make sure that never happened again

> *“The reality of it is you really do need to be training very specifically, and that means a lot of really silly looking unsexy things that I do every day, sometimes as little as 10 minutes a day, sometimes as much as an hour a day just on the stability stuff, just on the movement piece. But I wouldn’t trade it for anything because the way my body feels, I’m thanked for it.”*‒ Peter Attia

## Training within the four pillars: minimum effect dose, how to split your time, and other considerations [27:45]

**What’s the minimum effective dose for the person willing to put in the work on the four pillars?**

- This depends on where you’re starting
- If you doing nothing, you’re going to get huge benefits from probably just three hours a week
  - But this may not be the right way to think about it

**How would you spend three hours a week?**

- One hour of steady-state aerobic training (zone 2)
- One hour of strength training
- 20-30 minutes of one or two sessions of high-intensity aerobic training
  - Not [HIIT](https://en.wikipedia.org/wiki/High-intensity_interval_training) intervals, but a longer interval that is more VO2 max appropriate
- 30-40 minutes of stability training, spread out at 10 minutes a day
  - It’s important to understand that blasting out a single one-hour stability session is not better than doing 10 minutes of stability a day, six days a week
  - There is something to the neurologic pattern that comes from practicing your IAP (intra-abdominal pressure), practicing your breathing, your scapular CARs, your cat cow exercises
- On the stability side, [Beth recorded videos of Peter doing these exercises](https://peterattiamd.com/outlive/videos/) in the gym

**So if you start with three hours a week, how often do you ratchet that up?**

- This depends on what the limiting factor is
- Usually when a person starts at three hours per week, it’s because that’s the only time they’re willing to put into it
- Conversely, if a person’s never lifted a finger and they say, “O*h, my God, I’m willing to do whatever it takes*,” and they only start at three hours a week because you don’t want to injure them, then you’re in that situation where how much can you ratchet it up?
  - In that case, Peter would probably ratchet a person up every six weeks
- But the far more typical scenario is to be restricted on time and only willing to do three hours a week
- Usually, a person sort of starts to habituate to that stress

**Progressive overload**

- And one of the important principles of training is a principle that most people have heard of called [progressive overload](https://en.wikipedia.org/wiki/Progressive_overload)
  - In one way or another, the training (the load, the ask) needs to get more complicated, it needs to get more difficult
- In strength training, that could mean using a heavier weight, more reps, more sets, or less rest between sets
  - Other things can also make it more complicated, such as [BFR (blood flow restriction](https://en.wikipedia.org/wiki/Blood_flow_restriction_training), discussed in [episode #179](https://peterattiamd.com/jeremyloenneke/))
- Take Peter for example, he’s not adding time anymore (he’s at the limit of how much he is willing to spend on this)
  - He spends about six hours a week on the strength side, so he has to find other ways to add demand
- If you have a person exercising three hours per week and their ALMI is already at the 70th percentile and they’re reasonably strong but their aerobic training is an atrocity
  - For them, Peter recommends adding aerobic training as opposed to adding equally to all four pillars
- Another example is a guy who has been a lifelong runner, his VO2 max is above 60 and he’s age 60, but he’s never touched a weight in his life
  - He has very little muscle mass
  - He needs to run less and introduce some strength training

***People need to take an inventory of what they’re doing and where their strengths are***

## Advice for the older person and why it’s never too late to start [33:45]

**What about the person who is older, is it too late to start training for the centenarian decathlon?**

- They may not be coming into this with much strength
- Everybody is different, and age is definitely one of the factors that calls for nuance around programming
- On a previous podcast ([episode #235](https://peterattiamd.com/laynenorton3/)), Peter mentioned a [study](https://asbmr.onlinelibrary.wiley.com/doi/10.1002/jbmr.3284) done in Australia where an investigator took a group of women with osteopenia or osteoporosis
  - These women had very low bone density, and they’d never exercised in their life
  - These women were put on a pumping iron regimen, “old school” weights
  - Peter recalls that no one was younger than mid-60s [the publication states participants were older than 58 and at least 5 years post-menopause]
    - One of the women got to the point where she was able to [dead-lift her own body weight](https://youtu.be/9EZw_wrFnmI)
    - Imagine a 120 lb woman picking up 120 lbs off the ground
  - Peter adds, “*While that was a great example because it was documented in a clinical trial, there are so many stories of these things that you just see that I just have to believe that people are far more resilient than they can imagine*.”

- Peter writes about one example in the stability chapter; the case of Barry
  - He’s a guy who traded his health for wealth and then retired, had all the money in the world, and realized he couldn’t do anything because his body hurt so much
  - If you look at Bary today, he’s functioning better than he was 20 years ago

***It comes down to being consistent, having a real sense of purpose around this stuff, being smart so you don’t injure yourself in the process, and having someone who knows how to guide you***

> “*I would never want anybody to come away from this thinking, I’m too old to do anything about it. I think as long as you’re breathing, you have a chance to do something about it.*”‒ Peter Attia

## Bone mineral density and other female-specific concerns and considerations [36:15]

**You mentioned osteopenia/ osteoporosis, talk about BMD (bone mineral density) and why that’s something females specifically should be paying attention to, and how they should be training**

- Bone mineral density is very important for both sexes, but women are at a greater risk
  - The reason for that is the way bones work
- To oversimplify a bit, bones effectively have strain gauges in them, and they respond to tensile stress
  - So when a muscle is contracting, the muscle via the tendon is attached to the bone, and as the muscle contracts, the bone is compressing
  - Imagine a strain gauge inside the bone that senses that
  - That’s a mechanical signal that gets converted into a chemical signal via [estrogen](https://en.wikipedia.org/wiki/Estrogen)
    - Estrogen is the hormone that does the signal transduction and that tells [osteoblast](https://en.wikipedia.org/wiki/Osteoblast) and [osteoclast](https://en.wikipedia.org/wiki/Osteoclast) (which are the bone building and bone reabsorbing cells) to make the bone stronger, not weaker
  - In other words, the “use it or lose it” philosophy is at play here, and estrogen is the key link
- Both men and women have estrogen, and it’s very important for both sexes

***The difference is women lose estrogen precipitously in midlife, and therefore, women are more at risk for osteopenia and osteoporosis***

- Now for men and women alike, it’s very difficult to add bone density after you reach the critical period of maturation, typically in the early 20s
  - Unfortunately, most of our audience is past that point

***The answer is load-bearing, load-bearing, load-bearing, to reach your genetic potential while you have a chance***

**For those of us who are past that point, the key is: how much can you slow the rate of decline?**

***Nothing is more important for that than heavy load-bearing activity***

- Walking does not count as load-bearing activity
- Running is certainly better than swimming or cycling
- None of that compares to strength training

> “*Strength training is really the most important piece of maintaining bone mineral density, and it must be supported from an endocrine perspective with the appropriate amount of estrogen and potentially testosterone and certainly with the correct nutrition and supplementation (such as vitamin D and the right amount of protein and things like that)*.”‒ Peter Attia

## Training advice for those with minimal access to a gym or equipment [39:30]

**What if you can’t afford a trainer or don’t have a gym to go to? How much of this can you do without fancy equipment, maybe with body weight?**

- You can definitely do quite a bit of stuff with body weight, but Peter would encourage people to at least get some dumbbells and kettlebells
  - They make dumbbells where one dumbbell has multiple links in it so it could be 50, 60, 70 lbs, etc. depending on where you click it
- If you are going to think about the most efficient way to do this, splurge on a few pieces of equipment
  - Certainly heavy enough dumbbells that you can get into carrying would be important
  - [Resistance bands](https://en.wikipedia.org/wiki/Resistance_band) are also really important
- Peter has had a couple periods in his life where he didn’t have access to a gym for three or four weeks, and during those periods of time, traveling with heavy resistance bands was essential
  - If he could have added some dumbbells, that would have made a big difference
- It’s definitely easier if you have access to a gym
- A [TRX](https://www.amazon.com/TRX-Suspension-Training-System-Travel/dp/B01LXL27XI/ref=sr_1_5?crid=1KHCLTICF6P93&keywords=trx&qid=1685459361&sprefix=trx%2Caps%2C175&sr=8-5) is another great device you can do a lot of exercises with
  - It’s this strap device that you either hang around a rack or can put behind a door
    - Just make sure you’re on the right side of the door, so the door can’t open

## Injuries: prevention and working through existing conditions [41:00]

**How should people think about this if they’re coming into it with previous injuries, if they’re worried about injury (especially in the older population)?**

*If you haven’t lifted much weight, is that where stability work can be much more effective?*

- You have to be careful, and it’s not reasonable for Peter to offer an answer that would cover that in a broad way
- The podcast with [Alton Barron](https://altonbarronmd.com/) ([episode #232](https://peterattiamd.com/altonbarron/)) looked at injuries of the shoulder, neck, elbow, and hand
  - That was a six-hour episode, one of the longest three podcasts, up there with Tom Dayspring [on cholesterol] and Matt Walker [on sleep]
  - And that didn’t even really get into rehabilitation
  - It just talked about what’s at the root of the injury
- Peter has done a number of videos with [Kyler Brown](https://directory.firstprinciplesofmovement.com/providers/united-states/texas/austin/kyler-brown-dc/) going over some of his [rehab post-shoulder surgery](https://peterattiamd.com/exercises-after-shoulder-surgery/)

***You’ve got to be able to align with people who understand how to not “paint by numbers” in their approach to rehabilitation***

**Tips for finding a practitioner**

- When you meet a practitioner, spend some time talking to them about their philosophy around your particular injury
- Before Peter had his shoulder surgery, he wanted to understand all the details of early versus late mobilization
  - The trade-off between range of motion and stability
  - These are trade-offs when you’re repairing a joint as flexible as the shoulder
  - You can make it really stable again, if you’re willing to give up all range motion and vice versa

> “*I hate to say it, but I think you just have to become a more involved consumer of your care in that regard. But, unfortunately, I just can’t offer some blanket piece of advice around injury.*”‒ Peter Attia

**For the most part, if someone is dealing with an injury, would you encourage them to not give up on working out because of that injury?**

- Exactly, if anything, that should be motivation to get better
- It depends on where you are in your lifecycle
- For most people listening, if you have a nagging injury and you take the approach of ignoring it, and it’s not necessarily getting better, you’re on a very slippery slope
- Peter knows someone who had a shoulder injury for the last six months, and it’s not getting better
  - More importantly, she’s beginning to [atrophy](https://en.wikipedia.org/wiki/Muscle_atrophy) around it
  - She is becoming so weak, and her pain so significant around it that she’s altered all of her movement patterns in response to this
  - She’s younger than Peter
  - He recently had a “heart-to-heart” with her, “*Do you just think this is magically going to get better when you’re 70? No chance. You need to do X, Y, and Z right now.*”
  - That means at least three hours of week doing rehab to see if she can get better without surgery

## Cardiorespiratory training: how to split time between zone 2 and VO2 max training, and different modalities for a true zone 2 workout [44:15]

**How should I train for VO****2** **max?**

*If you take away having only three hours a week to do everything, and someone has good muscle mass but their VO**2* *max sucks. What program should they get on?*

- First, you must be committed to developing your cardiorespiratory fitness
  - Peter talked about this on [Tim’s podcast](https://tim.blog/2023/03/14/peter-attia-outlive/)
- You’re trying to maximize the area of a triangle; the triangle has a base and a peak
  - You don’t want one that’s this wide and this tall or this tall and this wide
  - You want to maximum area
  - The base is your zone 2
  - The peak is your VO2 max
- The rule-of-thumb for normal people and the best athletes in the world is roughly 80/20 (elite athletes are closer to 90/10)
  - 80% of your training volume is down here, at zone 2
  - 20% of your training volume is up here (VO2 max)
  - So it’s the same for an ordinary athlete or the best of the best
- [Tadej Pogačar](https://en.wikipedia.org/wiki/Tadej_Poga%C4%8Dar), who’s the greatest cyclist on this planet, two-time winner of the Tour de France, he’ doing 80 to 90% of his training in zone 2
- Peter wishes he could put 10 hours a week into cardio
  - Historically (up until 10 years ago), he put in 14-20 hours a week
  - He misses those days of being insanely fit, misses the joy of that much training, but it’s simply not possible today with all of his obligations
- Peter starts with the question, “*What’s the most amount of time I can put into dedicated cardio?*”
  - Four to five hours a week, not including rucking (he keeps that in its own bucket)

***The calculation of how to spend his time is simple ‒ 80% in zone 2 and 20% in VO******2*** ***max***

**Peter’s zone 2 workouts**

- He divides it into four workouts a week: Tuesday, Thursday, Saturday, Sunday

*Do you always recommend doing it over four days instead of four hours in one day?*

- You want at least 30-45 minute workouts spread out over the week
- If you’re only able to commit one hour to it, it might be one hour once or 30 minutes twice a week
- Peter does 45-60 minutes, four times a week

**Are you doing zone 2 and VO****2** **max on the same day?**

- He does this one day a week [we’ll come back to this]

**Peter’s weekly workout schedule**

- Monday is 90 min – 2 hr of strength training, including stability training
  - That includes movement prep, stability training, and strength training
  - That’s all lower body
- Tuesday is zone 2, followed by a dedicated hour of stability
- Wednesday is upper body strength and stability for 90 min – 2 hr
- Thursday is a repeat of Tuesday
- Friday is a repeat of Monday
- Saturday is zone 2 in the morning, and upper body strength (repeat of Wednesday) in the afternoon
- Sunday is zone 2, followed by VO2 max

**Will you ever do VO****2** **max before you do zone 2?**

- Generally he doesn’t because he likes to have a lot of reps beforehand
- Even when he was a cyclist and doing two VO2 max workouts a week, super hard sets were always preceded by at least 1,000 kilojoules of work (1,000 calories of work)
  - The metric he would use on a bike was kilojoules

**What is your advice for the person who could do four days a week of zone 2, but only 15 minutes a day?**

- Compress it into two 30-minute sessions

***Your zone 2 training should be at least 30 minutes long***

- Peter usually does his on the bike using a [Wahoo Kickr](https://www.wahoofitness.com/devices/indoor-cycling/bike-trainers/kickr-buy#feature_sec) (sometimes on the treadmill), and it takes him 10 minutes to ramp up

**What modalities can people do zone 2 training on, the treadmill, the bike?**

- Anything that is steady state
- Swimming is great because you can really swim in a pool at a steady state
- Running is also great
- Cycling outdoors is generally hard unless you have a specific place to train
  - Peter used to train at Fiesta Island (in [Mission Bay](https://en.wikipedia.org/wiki/Mission_Bay_(San_Diego)), San Diego); it’s a 7 km loop where all the time trial bike races were held
    - There are no lights or traffic to get in your way
  - He wouldn’t be able to do zone 2 in Austin, TX, because it’s too hilly, and there’s too much traffic
    - It’s fits and starts
- Peter can do his VO2 max in Austin on a very hard hill that is about a mile long
  - He goes hard up the hill and easy down
- You can do zone 2 on a treadmill, walking on an incline
- If you’re a really good rower, you can do zone 2 on a rowing machine
  - Most people aren’t efficient enough, they don’t have the strength or stability to row really well for 45 minutes
- A stair climber is also good for zone 2 training
- If you’re just starting out, brisk walking is probably good enough for zone 2 training
- We won’t get into all the benefits of zone 2 because there are many other podcasts with [Iñigo San-Millán](https://som.cuanschutz.edu/Profiles/Faculty/Profile/19887) that people can listen to (Episodes [#85](https://peterattiamd.com/inigosanmillan/) and [#201](https://peterattiamd.com/inigosanmillan2/))

**We got a lot of questions asking, “*****If I did a 90-minute workout, and I was in zone 2 for 45 minutes of it, am I good?*****”**

- You can go and do a three-hour bike ride, and when you get back, your computer tells you you did 44 minutes of zone 2
- There are two issues here
  - 1 – When a computer tells you that you are in zone 2, that is based on heart rate, and that’s generally the worst approximation of zone 2
    - Zone 2 is really based on [lactate](https://en.wikipedia.org/wiki/Anaerobic_glycolysis) or at a minimum [RPE (rating of perceived exertion)](https://en.wikipedia.org/wiki/Rating_of_perceived_exertion)
  - 2 – Even if you posit that this 45 minutes of zone 2 from your heart rate is roughly accurate, it’s not the same physiologically because usually you’re passing in and out of zone 2 in that situation
    - You’re not getting that constant steady state churn, which you’re looking for

***With zone 2, what we’re really looking for is the harnessing of mitochondrial efficiency with consistent effort***

- To do that, you have to be able to push [oxidative phosphorylation](https://en.wikipedia.org/wiki/Oxidative_phosphorylation) right to its limit before you trip into [glycolysis](https://en.wikipedia.org/wiki/Anaerobic_glycolysis), and you’re just at the limit of that [glycolysis](https://en.wikipedia.org/wiki/Glycolysis) being the dominant energy source
- When your riding your bike outside, you’re going into and out of glycolysis constantly, and it’s not so much that you were in zone 2 for 45 minutes, it’s that you passed through zone 2 for a sum total of 45 minutes (which is not what we’re talking about)

## VO2 max training: modalities, Peter’s protocol, and how to monitor progress [54:45]

**What modalities can you do VO****2** **max training on?**

- This is easier in a way, because it’s pretty much anything that gets your heart rate up and gets you very tired
- It could be: an air bike, a regular bike, a stationary bike, stair climber, treadmill, running outside
  - The sky is almost the limit
- Something like [burpees](https://en.wikipedia.org/wiki/Burpee_(exercise)) is pretty tough once you get into something that intense like jumping because the “sweet spot” for VO2 max is 3-8 minute intervals

***You don’t want to be doing things that are so intense that you can’t do them for at least three minutes***

- Peter can’t jump for three minutes anymore, so he has to rely on easier things

**What is your current VO****2** **max workout?**

- Typically Peter spends his time doing **four minutes repeats** (four minutes on, four minutes off)
- Sometimes three on, three off on a rowing machine
- If he’s in a rush, he will do one minute on, two minutes off at a much higher intensity on the stair climber
  - He has one of those industrial-grade stair climbers
  - He will sprint for a minute, and it will take two minutes to get his heart rate back down to about 100, and then repeat that for 20-30 minutes

**For the four minutes on, are you going 100% for the full time?**

- You have to play with this, and it takes years and years of practice to know what that feels like
- Peter does this on a bike, so he’s looking at wattage
  - His wattage is much lower than it used to be, but he has a sense of what his average wattage needs to be over those four minutes
  - He might go out at 105% of wattage, and it feels pretty easy for the first minute
    - If it doesn’t, he’s gone to hard
  - By three minutes, he’s very uncomfortable
  - In that last minute, he doesn’t have much left
- If you go all out in that first minute, you’re not going to make four minutes
  - You’re going to crash, and your not in that zone
- Peter does more work in the first half than the second, but he doesn’t want it to be more than about 10%

**When will people see an increase in their VO****2** **max? How should people think about monitoring their progress and staying motivated?**

- You don’t need to test your VO2 max more than once a year
- Monitoring progress depends on the modality
- If you use a stationary bike with a power meter, when you start out, you might only be able to put out 150 watts for the four minutes
  - But if in six months if you’re putting out 175 watts for those four minutes, your VO2 max has gone up (assuming that your weight hasn’t increased significantly)
- Riding outdoors, you’d probably want to have a power meter; speed can be misleading because of wind and stuff like that
  - You want to know how much wattage you can do
- The other thing to keep in mind with VO2 max is weight plays an important role in it
  - Because it is VO2 max in liters per minute divided by your weight in kilograms
  - So if the name of the game for you is, “*How do I maximize my VO**2* *max in total absolute terms?*” you can really game the system
  - Peter’s VO2 max when he was cycling was high because he was very light and he was disproportionately light in his upper body
    - Upper body is contributing nothing to the VO2 max for most tests because it’s tested on a bike or on a treadmill
    - So you get punished for any upper body mass, and you’re only rewarded for lower body mass
    - The lighter your upper body is, the better you are

**It comes down to how much time you’re willing to put into VO****2** **max training**

- The literature on this suggests you can only improve your VO2 max by 50%, but the literature is typically looking at eight-week studies
- What we’re interested in is a lifetime of training, and in a lifetime of training, you can increase your VO2 max by 50%
- There is a strong genetic component to it
  - When you see these people who have freakishly high VO2 maxes (in the 80s), there’s unquestionably a strong genetic component to that, but they’re also training like crazy

## The profound impact training can have on the overall quality of life [58:15]

***The goal for people who are wanting to start training for the centenarian decathlon is to think about it based on their lifetime horizon***

- You want to create a program you can keep up with for years and decades
- You also want to keep that timeline perspective of not needing to increase an insane amount because you don’t want to get injured, you want to do something you get enjoyment out of and find value in

**Any last incentive you would want to give people as they think about the centenarian decathlon, as they think about their longevity journey?**

- We talk so much about the benefits of exercise in terms of how much it reduces the risk of chronic disease, how much it reduces all-cause mortality
- You’ve probably heard Peter say this before, but it’s worth repeating, “*If I knew that all this training I was doing, everything I’m doing, if I knew that it was going to shorten my life by a year, I would still do it purely for the improvement in quality of life between now and the end of my life.*”
  - The fact that it’s not shortening my life by a year

> “*The fact that it’s probably adding five to seven years to my life and improving the quality of my life, means day in and day out, I just think it’s about the most important thing that I can do vis-a-vis my physical health.*”‒ Peter Attia

- There are other elements of health that we didn’t get into
- Peter’s parting comment is a thanks to everyone who’s listening to this because, by definition, if you’re listening to this, you were an early purchaser of *Outlive*, “*So I really want to thank you for that, it means a lot to me… I never thought that a book would mean as much as it has in terms of how personal it feels and how attached to the thing that I feel as it’s out there.*”
- Nick adds, “*One thing I forgot to mention earlier is for anyone who has a physical copy of the book, if you haven’t popped the jacket cover off yet and seen the actual cover, there is something on the actual cover too itself that was a special design.*”

Shout out to [Rodrigo Corral](https://rodrigocorral.com/about) and that whole crew who designed the jacket cover and the hardcover of the book

§

## Selected Links / Related Material

**Peter’s book**: [Outlive](https://peterattiamd.com/outlive/) by Peter Attia and Bill Gifford (March 2023) | [0:45, 35:30]

**Videos of stability exercises**: [Outlive Videos](https://peterattiamd.com/outlive/videos/) | [30:00]

**Strength training in women with osteoporosis**:

- [High-Intensity Resistance and Impact Training Improves Bone Mineral Density and Physical Function in Postmenopausal Women With Osteopenia and Osteoporosis: The LIFTMOR Randomized Controlled Trial](https://asbmr.onlinelibrary.wiley.com/doi/10.1002/jbmr.3284) | *Journal of bone and Mineral Research* (SL Watson et al. 2017) | [34:30]
- [Ask the Expert Osteoporosis Australia](https://youtu.be/rZ5rrxzZ3LI) | Professor Belinda Beck, The Bone Clinic (August 22, 2017) | [34:30]
- [Queensland research helping osteoporosis sufferers](https://youtu.be/9EZw_wrFnmI) | The Bone Clinic (April 12, 2016) |

**Previous episode of** ***The Drive*** **with Alton Barron on injuries**: [#232 ‒ Shoulder, elbow, wrist, and hand: diagnosis, treatment, and surgery of the upper extremities | Alton Barron, M.D.](https://peterattiamd.com/altonbarron/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (November 8, 2022) | [41:45]

**Rehab videos with Kyler Brown**: [Exercises After Shoulder Surgery (Post-Op Week 9)](https://peterattiamd.com/exercises-after-shoulder-surgery/) | Peter Attia, PeterAttiaMD.com (June 17, 2022) | [42:00]

**Peter discussed cardiorespiratory fitness and VO****2** **max with Tim Ferriss**: [Dr. Peter Attia — The Science and Art of Longevity, Optimizing Protein, Alcohol Rules, Lessons from Glucose Monitoring with CGMs, Boosting Your VO2 Max, Preventing Alzheimer’s Disease, Early Cancer Detection, How to Use DEXA Scans, Nature’s Longevity Drug, and More (#661)](https://tim.blog/2023/03/14/peter-attia-outlive/) | Host Tim Ferris, [The Tim Ferriss Show](https://tim.blog/podcast/) (March 14, 2023) | [44:45]

**Previous episodes of** ***The Drive*** **with Iñigo San-Millán on zone 2**:

- [#85 – Iñigo San Millán, Ph.D.: Zone 2 Training and Metabolic Health](https://peterattiamd.com/inigosanmillan/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (December 23, 2019) | [51:15]
- [#201 – Deep dive back into Zone 2](https://peterattiamd.com/inigosanmillan2/) | Iñigo San-Millán, Ph.D. (Pt. 2) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (March 28, 2022) | [51:15]

**Previous episode of** ***The Drive*** **summarizing exercising for longevity**: [#206 – Exercising for longevity: strength, stability, zone 2, zone 5, and more](https://peterattiamd.com/exercising-for-longevity/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (May 9, 2022)

§

## People Mentioned

- [Annie Duke](https://www.annieduke.com/about/) (author, speaker, and consultant on the behavior of decision making) [7:30]
- [Alton Barron](https://altonbarronmd.com/) (orthopedic surgeon who specializes in the shoulder, elbow, and hand) [41:45]
- [Kyler Brown](https://directory.firstprinciplesofmovement.com/providers/united-states/texas/austin/kyler-brown-dc/) (Chiropractor) [42:00]
- [Iñigo San-Millán](https://som.cuanschutz.edu/Profiles/Faculty/Profile/19887) (Assistant Professor of Medicine at the University of Colorado – Colorado Springs, expert in exercise-related metabolism) [51:15]
- [Rodrigo Corral](https://rodrigocorral.com/about) (leading creator in conceptual design and art for books, brands, and more) [1:01:30]

§