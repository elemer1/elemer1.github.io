# #333 ‒ Longevity roundtable — the science of aging, geroprotective molecules, lifestyle interventions, challenges in research, and more | Steven Austad, Ph.D., Matt Kaeberlein, Ph.D., Richard Miller, M.D., Ph.D.

**Source:** [https://peterattiamd.com/longevityroundtable/](https://peterattiamd.com/longevityroundtable/)

---

In this special episode of The Drive, Peter introduces a brand-new roundtable format. Joined by three renowned experts in longevity science—Steven Austad, Richard Miller, and Matt Kaeberlein—the group explores the rapidly evolving field of geroscience. Together, they dive deep into topics like the relationship between healthspan and lifespan, evaluating interventions like rapamycin and senolytics, the role of epigenetic changes in aging, and whether GLP-1 receptor agonists hold geroprotective potential. They also tackle major challenges in funding and public acceptance of longevity research including how geroprotective interventions might be tested in humans. Packed with nuanced debate, humor, and groundbreaking insights, this episode is a must-listen for anyone fascinated by the science of aging.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/longevityroundtable/the_Drive_public.png)

Play

#333 ‒ Longevity roundtable — the science of aging, geroprotective molecules, lifestyle interventions, challenges in research, and more | Steven Austad, Matt Kaeberlein, Richard Miller

#333 ‒ Longevity roundtable — the science of aging, geroprotective molecules, lifestyle interventions, challenges in research, and more | Steven Austad, Matt Kaeberlein, Richard Miller

1x15s30s

0:002:41:39

## We discuss:

- The recent rise in public interest in longevity, misconceptions, and the link between healthspan and lifespan [3:45];
- Redefining healthspan, the US healthcare paradox, and separating longevity science from commercial hype [12:30];
- The need to redirect medical research from disease-specific models to aging-focused approaches [21:30];
- Proactive healthcare: rethinking health, disease, and the role of aging [30:00];
- Biologic age versus chronologic age, and the limitations and potential of epigenetic clocks [35:00];
- The utility and drawbacks of the “hallmarks of aging” as a framework for research and funding [49:30];
- The role of epigenetic changes in aging and the challenges of proving causality [56:45];
- The translational challenges of moving aging research from preclinical studies to human applications [1:03:45];
- Distinguishing between a biomarker of aging and aging rate indicators [1:17:15];
- The difficulties of translating longevity research in mice to humans, and the difficulties of testing interventions in humans [1:21:15];
- Exercise, aging, and healthspan: does exercise slow aging? [1:35:45];
- Are GLP-1 receptor agonists geroprotective beyond caloric restriction effects? [1:41:00];
- The role of senescent cells in aging, challenges with reproducibility in studies, and differing views on the value of current research approaches [1:46:15];
- How funding challenges and leadership in NIH and other institutes impact the advancement of aging-related research [2:00:15];
- Metformin: geroprotective potential, mechanisms, and unanswered questions [2:02:30];
- Canagliflozin and rapamycin as geroprotective molecules: mechanisms, dosing strategies, and longevity potential [2:10:45];
- Resveratrol and NAD precursors—a lack of evidence for anti-aging effects [2:22:45];
- The potential of parabiosis and plasmapheresis to slow aging, the challenges in translating mouse studies to humans, and possible design for human studies [2:29:45]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Welcome to a special episode of *The Drive*, today we’re introducing a new format to the podcast: our inaugural roundtable conversation
- For this one, we have gathered 3 brilliant minds to sit down and have a nuanced, funny, sometimes a little heated discussion about one of the most fascinating and rapidly evolving areas of medicine today: geroscience (aka longevity science)
  - All former guests of the podcast
- Dr. Steve Austad is an expert in aging biology and author of groundbreaking research on extending healthspan
- Dr. Richard Miller is a pioneer of the study of anti-aging interventions through the [Interventions Testing Program (ITP)](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp)
- Matt Kaeberlein’s expertise explores the intersection of genetics, aging, and translational research
  - He’s famous for his work in the [Dog Aging Project](https://dogagingproject.org/)
- In today’s roundtable, we discuss a number of things
  - The relationship between healthspan and lifespan
  - What does healthspan actually mean, and is it something we should try to define
  - Can you improve one without improving the other?
  - What has caused a surge in the public interest in longevity science
  - What major barriers are preventing longevity research from reaching its full potential
  - How do we evaluate the effectiveness of interventions like rapamycin, senolytics, or calorie restriction in humans where it’s very difficult to study them (for obvious reasons)
    - This was one of Peter’s favorite parts of the discussion
  - Are there reliable biomarkers or aging rate indicators that can measure biologic aging (a very hot topic)
  - What role do epigenetic changes play in aging? Specifically, are they causal?
  - Are senescent cells a valid target for longevity interventions, or has their role in aging been overstated
  - Are [GLP-1 receptor agonists](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist) (drugs like tirzepatide and semaglutide) potentially geroprotective beyond their weight loss effects
  - How do we overcome the funding and political challenges that prioritize disease-specific research over foundational aging science?
  - What would it take to make longevity research more mainstream and gain broader support from the public and policy makers?
- This idea of doing a roundtable is a new format, and we really want to hear from you
  - Is this something that you like?
  - If so, what are other topics you would like to see for roundtables?
- Please enjoy this roundtable discussion with Steve Austad, Rich Miller, and Matt Kaeberlein

## The recent rise in public interest in longevity, misconceptions, and the link between healthspan and lifespan [3:45]

The rising interest in longevity, misconceptions, and the link between healthspan and lifespan

- The term longevity is clearly at a peak in terms of public interest
  - The number of times “longevity” is searched on Google is similar to “Bitcoin”
- All of today’s guests have devoted decades to studying longevity

**Why are people so interested in longevity? Is there a bubble going on?**

Steve Austad

- It’s a surprise that longevity has become so big, because for a long time we tried to move away from that in the aging field because we were worried that people were thinking of longevity as we’re going to keep frail, feeble old people alive longer
- When really what we were trying to do is extend health
- He thinks it’s because there are certain people of a certain age who’ve started to think about their own longevity
- There’s also a whole new generation of tech entrepreneurs that really feel like this is a problem that will allow them to live healthily for several decades (at least) longer than they are now
- He hasn’t seen this level of interest before
- 30 years ago, he would’ve said, “*Let’s not even say the word longevity, let’s say healthspan*.”
- That has changed as more and more people have been peeking in at the field from the outside

***The field hasn’t changed they way they talk, it’s the people eaves dropping on the field that have changed***

Rich Miller

- People have always been fascinated for millennia on things they could do to stay alive and healthy as long as possible
- But there were actually scientific discoveries in the ’90s that showed that it could be done
- Then in the last 20 years there’s evidence (in mice) that it can be done with pills

***So that naturally should lead to speculation that there could be pills you could give to people that would postpone poor health for a substantial amount of time***

**⇒** 20-30% [extension of healthspan] is what we’re seeing in mice, and 20-30% would be very important for people

- That is one part of it
- The other part is that there are now people who are making a lot of money by selling stuff that is untested (or useless) to gullible customers

***People who want to make a lot of money have finally found that there’s an impetus that will allow them to sell stuff, even if there’s no evidence that it works***

- And they control an enormous amount of advertising dollars, both formal and informal
- That’s a big part of the difference

*With regard to something Steve said about the balance between healthspan and lifespan*

- It’s become fashionable, for the last 20 or 30 years, to imagine that you get one or the other, that you have to make a choice
- That it’s a decision, and that if you give up on lifespan that allows you to extend healthspan
- Rich thinks that’s ridiculous and controverted by all the available evidence

**⇒** All of the drugs at least that extend lifespan in mice (and could potentially do so in people) do so by postponing diseases

- Both the diseases that will kill you (that’s why they extend lifespan) and the diseases that won’t kill you, but which will annoy you and make you very unhappy to be old
- Peter points out ‒ that’s also true of exercise and not being insulin resistant

***Healthspan and lifespan are linked together, they go up and down together***

**⇒** Getting people disabused of that false seesaw metaphor [that for healthspan to go up, lifespan goes down, and visa versa] is an important goal for the public interface between longevity scientists, aging scientists

**15 years ago the first ITP was published showing the overwhelmingly surprising and positive results of rapamycin**

- After a decade-long lag, those results were repeated
- [Cynthia Kenyon’s](https://profiles.ucsf.edu/cynthia.kenyon) work was [published in ‘93](https://pubmed.ncbi.nlm.nih.gov/8247153/), and this may have been the thin edge of the wedge into the idea that lifespan was malleable
  - Albeit through a genetic manipulation in a less relevant model

*Thinking about this lag, do you buy Steve’s argument that it’s a confluence of technology, tech entrepreneurs?*

Rich answers the first question: why the lag?

- There’s a whole batch of important reasons
- 1 – The prevailing attitude about aging is there’s nothing you can do about it
  - I’m not going to outwit aging, though maybe I can be healthier in my older years

> “*The notion that aging is not malleable, though wrong and provably wrong, is still the overwhelming opinion even of reasonably educated scientists and certainly of the lay public*.” ‒ Richard Miller

- 2 – Commercially, there are companies that make a ton of money selling stuff that doesn’t work by pretending, with a wink and a nod and a lawyer, that it might slow the aging process down
  - And since they can make a lot of money, they don’t actually have to spend valuable marketing dollars on doing research and stuff to prove that it works

*The long road to developing a longevity drug*

- In the hands of the [ITP (Interventions Testing Program)](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp), for some of the drugs, the patent is owned by another company
  - Or they’re out of patent
  - Or it’s a natural product
- None of that says take me to whoever owns a big pharmaceutical firm
- Even if you want to do it right and you’ve got a very large budget, it’s not an overnight kind of thing
- For the half a dozen drugs that have been shown to work in the ITP (in mice), finding something in the same family that works really well for people (and is safe) is not trivial
  - Of which [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) is the leading agent

***That takes a long time and it takes a commitment of money and time and effort and intellectual resources, and so far it has not been enormously successful (unfortunately)***

Steve Austad, “*Can I push back a little on what Rich said about healthspan versus lifespan?*”

- Several papers have come out recently showing that the gap between healthspan and lifespan in people is actually increasing
  - It’s increasing the fastest in the United States
  - It’s increasing faster among women than men
- In humans this is a very real gap and it’s a growing gap
- In the area of geroscience (the stuff that we do), Rich is right
  - We don’t see this in our experimental systems

***To Steve, this emphasizes the fact that we need to change the focus***

- One of the reasons that the gap exists is we’re getting better and better and better at treating heart disease and cancer and all these things
  - Keeping people alive when they wouldn’t have been alive 10 years ago
- This is a really important factor when thinking of public health globally

Matt Kaeberlein

- Thinks both Rich and Steve are right, but looking at it from different angles
- Steve pointed out that you can make people live longer when they’re sick
- What Rich is saying (and Matt agrees with) is that if we target the biology of aging, he hasn’t seen anything to make him believe that you can separate healthspan and lifespan
  - Meaning he hasn’t seen things that slow aging/increase lifespan that don’t also increase healthspan

Steve Austad

***That’s an important point: if we target aging, we’re doing something different than the way medicine is operating now, which is targeting individual diseases after they occur***

## Redefining healthspan, the US healthcare paradox, and separating longevity science from commercial hype [12:30]

**Peter makes the connection to healthcare spending**

- This came up in a recent podcast with Saum Sutaria [[episode #327](https://peterattiamd.com/saumsutaria/)] talking about healthcare costs
- One thing that emerged is the sad statistic that among the [OECD nations](https://en.wikipedia.org/wiki/OECD#Member_countries), the US has the lowest life expectancy
- Which is ironic given that we are spending, on average, about 80% more, and in some cases double what most other developed nations spend on healthcare

So how do you reconcile this?

- Saum made a very interesting point: that’s aggregate life expectancy and that’s the case because the United States has by far the greatest rate of death in middle age
- Mortality in the US [of people younger than 60] is horrible due to:
  - Maternal and infant mortality
  - Gun violence, suicide, and homicide
  - Overdoses
- When you kill a whole bunch of people in their 40s and 50s, you cannot have a very high life expectancy
- What Saum pointed out was once an American reaches the age of about 65, all of a sudden [life expectancy] jumped to the top of the list
  - That was very interesting to me

***In other words, if you look at the blended life expectancy, we’re not doing very well; but if you look at life expectancy just in measured as years alive, once you escape those big causes of death in middle age, we actually do quite well***

*This comes down to what was just discussed: we get very good at delaying death in chronic disease*

- This is what Peter calls medicine 2.0 at its absolute finest
  - We are going to keep you along an extra 6 months once you have cancer
  - We are going to get you through that third revascularization procedure.
- Peter’s intuition is where Steve’s is: he doesn’t think we’re getting any healthier, even if we’re incrementally figuring out ways to extend life in the face of chronic disease
  - He doesn’t see it being a quality of life

**Part of this might be how do we define healthspan?**

Matt Kaeberlein

- Matt agrees with Peter and thinks it’s even worse than the way he laid it out
- If you look at the statistics: 60% of Americans have at least 1 chronic disease and the median age in the US is around 38
- Then think about how long people are living on average
- This is what Peter is getting at with the definition of healthspan

*Matt would not define healthspan as ending once you have your first chronic disease, but that’s the definition most people would use*

- If you use that definition, most people are spending 3 decades or more in the absence of healthspan (or in sickspan)

**⇒** The situation is even in the US where life expectancy is relatively short compared to other nations, a big chunk of that life expectancy is not spent in good health; and it’s exactly for this reason

Rich Miller

*There are 2 different issues that are being confused here*

- 1 – The issue of whether you can help middle-aged people live longer
  - And everybody agrees that we’re getting better at that, and we’re pretty good at it
- 2 – That is quite different from a concoction that slows aging by extending healthspan
- Both of these have the word “healthspan” in them, but they are different and shouldn’t be confused

*To the question: What is healthspan?*

***Rich’s answer is: that’s a useless term, because no one can define it***

- The term itself is vacuous and nebulous
- If you have somebody that gets a certain chronic disease here and then another one and then they fall down and bump their head, and by the way they go to the hospital and with COVID, etc, etc.

***Defining when in that 20 to 30 year period they flick the switch, now they have gotten to the end of the healthspan, is impossible and of no interest***

> “*The general notion that people are interested in is whether you can do stuff to keep people healthy for a long time, either without changing their life expectancy or with changing their life expectancy.*” ‒ Rich Miller

- Those are interesting, but you don’t have to assign a number, a healthspan digit

Peter Attia

- Peter doesn’t like the **medical definition of healthspan**: the period of time in which an individual is free of disability and disease
- Part of the reason it’s unhelpful and awful is it’s binary
- If we made it analog instead of digital, it’s still very challenging, but now it allows us to start talking about things

Matt Kaeberlein

- Except healthspan is a qualitative concept
- We to try to  make it to where we can actually come up with a way to measure it

***It’s a useful term as a concept and a way to communicate to a broader audience what one of the goals is: to increase the healthy period of life***

- Rich likes the term health for that
- Matt thinks they can all agree there’s a period of life where you’re in relatively good health, and there’s a period of life when you aren’t
  - The idea is we’re trying to increase that [first] component of life

Steve Austad

*There’s an individualization of this that we’re missing*

***Health is a state of your physical being that you can do the things you like to do***

- If you like to climb mountains, your healthspan is going to be different than if you like to play golf, for instance
- If you can’t run a marathon anymore, some people would say, “*My health is poor.*”
- Matt points out that biologists don’t pay attention to the mental health piece, which is super important

**Peter does an exercise with patients called the “marginal decade exercise”**

- He wrote a lot about this in the [*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=3VCCZOEO62GJ4&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZdGttk3nhLTMuCT6AR1kYNaeU4g3JqQyyTVOqy9epPTjwxzLrbybh5p6kVKfHMZy4G4NUX4XwQ_Fvd2bRJfjc3NqunA3CjgjmNWU6w6qHqNUY5Y1RkETd3cnhnjPemK9EBQ4WQsTCy6uvU46Zc6DZEy_A9qmcO0XyB8Og8HonHYpTzgyGfP3_he-su_f70MmIGwObAaEWfmMqFpP5pOTYWc._dK-pxT4rJbIVnlKwB3ZsOGe-SwqzBE1uMvMArcK370&dib_tag=se&keywords=outlive+peter+attia&qid=1737043421&sprefix=outlive%2Caps%2C96&sr=8-1)
- Peter defines this as the last decade of your life
  - By definition, everyone has a marginal decade
- Most people don’t realize the day they enter it, but most people have a pretty good sense when they are in it

***The exercise is to list the things that are most important for you to be able to do in your marginal decade***

- These generally fall into the buckets: physical, cognitive, emotional, social
  - You can divide the physical bucket into activities of daily living and recreational activities
- That’s where most people obviously intuit that, “*Boy, I would really not be happy if I couldn’t take care of myself. If I couldn’t get out of bed, get dressed, shave, cook, that would be disappointing to me*.”
- But then of course you have different levels of ambition within the recreational side
  - Some patients will say, “*When the day comes that I can’t heli-ski, I’m going to be devastated.*”
  - Other people are like, “*I just want to be able to garden*.”

*That’s going to create a very different standard*

- On the cognitive side, you have people who say, “*I want to be able to run my hedge fund and still make money and make really important investment decisions.*”
- And other people are like, “*I want to be able to do crossword puzzles and read the newspaper.*”

***Peter agrees, you can’t define it, but it doesn’t mean we shouldn’t try to personalize it***

**Why has longevity gone mainstream?**

Matt Kaeberlein

- The points raised by both Stevve and Rich are part of the equation
- It’s the convergence of all these factors and maybe a few others

> “*I do think the science has matured to the point where more people are believing that we can actually modulate the biology of aging*.”‒ Matt Kaeberlein

- The concept of biological aging has become popularized through a variety of mechanisms, including some influencers, individuals who Matt thinks often err on the side of being a little bit less scientific than they should be, but they’ve helped popularize the concept

*Why has it taken so long?*

***That’s the pace that science moves and the rate at which these concepts can sort of permeate the public sphere***

- It’s frustrating in a sense that it’s moved so slowly

Regarding the question, “*Are we in a longevity bubble?*”

- Matt doesn’t know
- Maybe we’re still kind of in the early days of this “hockey stick” moment where you’re getting this exponential increase in attention

***Matt’s hope is, as we go forward, it will become more scientific and less snake-oily***

- It’s a spectrum, there’s this huge gray area in the field right now of what’s real and what’s not real, and none of us at this table actually can really define exactly where in that gray area that line is, or is there a line?

## The need to redirect medical research from disease-specific models to aging-focused approaches [21:30]

**What is the collective wisdom of the group on the funding appetite of the** [**NIA**](https://www.nia.nih.gov/)**?**

- Peter agrees, if we could channel this exuberance away from the highly commercial speculative grifting towards the budget increasing legitimate investigative, that would be awesome

Matt Kaeberlein

- It’s hard to say ‒ the NIH is a moving target
- There’s going to be a lot of change coming in the near future

***Matt’s cautiously optimistic***

**⇒** If you look historically, about 0.5% of the NIH budget goes to the biology of aging (pretty terrible)

- There are 17 groups in the NIH with the NIA being one of them, and the NIA gets roughly 3% of the NIH budget
- Within the NIA about $350 million goes to research on the biology of aging (that was the # a few years ago)
  - It might be higher now, such that it reaches about 0.5%

Rich Miller

***Rich’s optimism that the NIH will wake up and start to pay attention to aging research the way they should is near zero (it’s been near zero for 30 years now)***

- It’s gone up with this outside attention
- The NIH funded the [ITP (the Interventions Testing Program)](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp) 20 years ago
- And they liked it and they doubled the budget about 15 years ago
- He’s very grateful to them for that, but there’s still an enormous untapped potential for making progress in the basic biology of aging
- The reason is, it’s a matter of defending turf
  - If you are a cardiologist researcher or an oncologist researcher or an AIDS researcher or an Alzheimer’s researcher, anytime somebody says, “*The smart play is to reduce your budget by 10% or your institute’s budget by 10%, we’re going to go there faster if we spend money on aging and its relationship to the disease you care about,*” you get the porcupine defense
  - No one wants to take money away from research on Alzheimer’s, little kids with leukemia, breast cancer
- Most of the people making [funding decisions] were not trained in aging research
- They view it as something interesting

> “*They don’t understand that to actually conquer or slow down or effect or protect against the disease they care about, the smart play is to do aging research*.” Rich Miller

***And so they view the suggestion to increase funding of aging research as an imposition, an invasion to be repelled at any cost***

- No one in a position of power has had whatever it takes to reverse that
- And if he or she tried to do that, Congress would smack them down
  - The Alzheimer’s group has a hundred lobbyists
  - The cancer group has a hundred lobbyists
  - The AIDS group has a hundred lobbyists
  - The aging group has two lobbyists: one who’s a lawyer and one who takes the calls, and it’s not enough to do it

Matt Kaeberlein

*Matt agrees and thinks that the reputation of the field has hindered that transition as well*

- Historically the field was viewed as not very mechanistic, kind of phenomenological
- It became much more mechanistic starting around the time of Cynthia Kenyon’s [work](https://pubmed.ncbi.nlm.nih.gov/8247153/) and since then
- But it has continued to have a reputation problem as not being as rigorous as other areas of research

***It is absolutely a turf war, and there’s this overcoming the reputational problem, which makes it harder for serious people in funding and policy circles to give it the attention it deserves, in my opinion***

Steve Austad

***Steve actually thinks this is a very good time for aging research funding, and that’s not because of what’s going on at the NIA, but it’s what’s going on in the private sector (there’s more and more $)***

- There’s even interest now in big pharma (that was very spotty in the past)
- If we focused entirely on the NIA, we would get a false impression of what the funding climate is in the field now

**⇒** We need to take advantage of that; we’ve got to make sure that it doesn’t get captured by the people who are doing the flashy, but bad science

**Peter’s takeaway**

- [Calico](https://www.calicolabs.com/), [Altos](https://www.altoslabs.com/), other private companies within biotech and pharma that are looking at your protective molecules building on the work of the ITP
- It’s safe to say the amount of money that’s being spent privately, probably outdoes public spending 2:1 (easily in a given year)

Matt Kaeberlein

- We could question how much of that is actually going toward research on the biology of aging
- Matt agrees with Steve and doesn’t think what he and Rich were communicate is opposite to what Steve is communicating
- There are a lot of opportunities right now
- Maybe we at the beginning of this hockey stick moment
- There are real opportunities for more resources to be focused on the scientific side and hopefully less focused on the non-scientific aspects of what are going on

*You asked the question of can we shift resources from the more consumer facing, maybe not as rigorous stuff and into the more rigorous stuff*

- Matt’s not a fan of that stuff at all, but maybe you need that stuff to move the needle and get people’s attention

**What is the mission statement of the NIH?**

- Peter is embarrassed that he doesn’t know the answer, because he spent more than 2 years working there

Steve Austad

***It’s to preserve and enhance human health***

- It’s basically the same thing that we’re supposed to be doing

Matt Kaeberlein

- What Matt started to say about the NIA budget is if you look at the major causes of death and disability, **it’s hard to define healthspan**

**⇒** If you look at the top 10 causes of death in the US, 9 of them have biological aging as their greatest risk factor; yet half of 1% of the research budget goes to studying that factor

- It’s extremely frustrating that this hasn’t changed, but there’s a reason to be optimistic that maybe it will change in the near future

**Peter restates that because it is so profound** **⇒*The top 10 causes of death in the United States are well enumerated and incredibly predictable, and they increase by category, by decade, 3-8% monotonically with no exception***

![](https://peterattiamd.com/wp-content/uploads/2025/01/f1-longevityroundtable.png)

**Figure 1. Top 10 causes of death in 2022**. Source: [CDC](https://www.cdc.gov/nchs/fastats/leading-causes-of-death.htm) ([NCHA Data Brief 2023](https://www.cdc.gov/nchs/data/databriefs/db492-tables.pdf#4))

> “*More than 90% on an adjusted basis of what causes death goes up with age. And yet a few basis points of federal R&D goes to addressing that*.”‒ Peter Attia
>
> Rich Miller
>
> - About once every 5 years, Rich is invited to talk at the University of Michigan Cancer Center
> - He points out that we now have **anti-aging drugs in mice** that extend mouse lifespan, and they do it mostly by postponing cancer
>
> - Most mice die of cancer
> - And if you look at age adjusted cancer incidence rates, drugs tested by the ITP reduce these by a factor of 10
> - Rich asks the audience, “*Wouldn’t they like to know why, as cancer scientists? We now have a batch of drugs that postpone cancer. Wouldn’t they like to study them?*”
> - Invariable, somebody calls and says that’s interesting, but then it dies
> - 5 years later, he’s asked to give the same talk (or a related talk)
> - They are cancer scientists, and they know how to do cancer research
>   - And you certainly don’t do it by diverting your lab’s attention to aging
>
> ***That’s insane, but that insanity is how medical research is organized; and breaking that addiction to the kinds of models you grew up on because they’re a better idea is not an easy thing***
>
> ## Proactive healthcare: rethinking health, disease, and the role of aging [30:00]
>
> Steve Austad thinks this is because we think about health all wrong
>
> - We think, let’s wait until you get cancer and see what we can do about it
>   - That’s what cancer biologists do
>   - You have cancer? Okay, how can we better treat that?
>   - Or could we have diagnosed it earlier?
>
> **⇒** What Rich is saying and what we can know how to do in lots of model organisms is delay you from getting cancer for a considerable amount of time
>
> - That’s a little bit harder to study if you’re a cancer biologist, because you want to see the cancer before you can study it
>
> ***That’s why we need aging biologists rather than people focused on certain diseases that come and try to use what we do***
>
> - If we prevented the cancers, they’d be out of a job
>
> Rich Miller
>
> - Rich guarantees these people or mice will get cancer, they’ll just have 10 extra years of life (if they’re a person)
> - They’ll get cancer; they’ll need specialists
>
> Matt Kaeberlein
>
> - That’s an important point: the reactive disease care component is still going to be there even if we’re insanely successful at slowing aging
> - People are still going to get sick
>
> ***He thinks Steve’s point is really important and Peter is a leader in helping people recognize the  need to shift the medical approach from reactive to proactive***
>
> - What a lot of people don’t realize is that mentality goes all the way back to pharmaceutical research, biomedical research, basic science that is ingrained all the way through
> - One of the challenges with getting funding for aging research is that mentality on the basic science world and how deeply ingrained it is
>
> Peter Attia
>
> - This is very interesting
> - Because you don’t know which is the tail and which is the dog
> - Peter has always assumed that the one leading the charge is the clinical side of things
> - The machine of medicine 2.0 is built around delivery of care
>
> ***The delivery of care is built around, I’m going to wait, and when you get disease, we’re ready ‒ then all the research flows from that mindset***
>
> - But it might be that it’s flipped
> - It might be that the clinical engine behaves in that way because that’s how the base of the pyramid has been built
> - Not that it necessarily matters, but if you could be health czar and fix one of them, you might actually start with the research side of things
>
> Matt Kaeberlein
>
> - Matt would start with the research side of things
> - The reality is the research flows from where the dollars are going
> - This has been seen over and over at the NIH: you shift resource allocation to a certain area and the scientists will follow
>   - They will submit grants to get grants in the place where the funding line is the highest
>   - So if somebody came along and shifted funding of biology of aging research from 0.5% to 50% of NIH budget, you’d have no shortage of people applying for grants and becoming experts in the biology of aging
>     - It’d be kind of messy at first
>
> Peter Attia
>
> - And the system would work ‒ you’d get the best and the brightest that would go into that
>
> **Is aging a disease? (is that even a relevant question?)**
>
> Rich Miller
>
> - It’s important to use words optimally and to distinguish causes from effects
>
> **⇒** One of the bad things about aging is it’s a risk factor for many diseases
>
> - And so saying that aging is a disease confuses that discussion, it makes it impossible to see that relationship
>
> > “*Calling aging a disease is a fundamental error*.”‒ Rich Miller
>
> ***The question itself is incorrect***
>
> - Matt agrees; it’s the wrong question
>
> Steve Austad
>
> - Steve agrees, but we have **that idea for marketing purposes**, not for scientific purposes
> - The idea is that money goes to diseases ‒ let’s call aging a disease
>   - Maybe congress will pay attention to it
> - What we’re trying to do is treat aging as if it were a disease
> - Even though he would agree that it’s not a disease
>   - That destroys the word disease if we include aging in it
>
> Rich Miller
>
> - Rich agrees, it’s a marketing ploy
> - You think you can convince people of the importance of aging research by saying it’s kind of a disease
> - It’s probably good for that; he just doesn’t like lying to people
>
> Matt Kaeberlein
>
> - It also creates a negative feeling about the field in some people as well (that should be considered)
> - The other point that people often raise is: we have to call aging a disease in order for FDA to approve a drug for aging
>   - Matt thinks this is a fundamental misunderstanding of how the FDA operates
>
> ## Biologic age versus chronologic age, and the limitations and potential of epigenetic clocks [35:00]
>
> **How do you think about biologic age versus chronologic age in concept and in practice?**
>
> Steve Austad
>
> - Steve doesn’t believe there is one thing as biological age
> - There is potentially an age of your heart, an age of your liver, an age of your lungs, an age of your brain
> - But he doesn’t see why we wouldn’t simply call it health
> - Steve got one of these epigenetic age clocks done on himself a while ago, and he thought, “*Is this just flattery or did it really tell me something?*”
>
> ***He’s dubious about some number***
>
> - He’s knows he’s in good health for his age
> - Now he has a number for it, and he doesn’t put much credence in that
>
> Rich Miller
>
> - Rich agrees with Steve and adds slightly different terminology
>
> ***It’s a matter of taking a very rich, complex data set and trying to collapse it to a number***
>
> *If someone wants to know how healthy I am, he or she would need information*
>
> - How good is my eyesight?
> - How good is my hearing?
> - How good are various kinds of cognitive activities?
> - My aerobic endurance?
> - My joints?
> - All of that is pertinent to how my health is and also about projected future health
>
> ***Once you’ve got that information, there’s no single number that can condense that in any useful way***
>
> *40, 50 years ago, the notion that biological age was not the same as chronological age was useful for a little*
>
> - It emphasized that there might well be 60-year-old people who were unusually like youthful people, and 60-year-old people who were unusually like 70-year-old people
> - Would my drug or my genetic mutant or whatever help to discriminate those people or change them in some way?
> - I can slow your biological aging process ‒ that’s a discussion that was maybe of interest 40 years ago
>
> *It’s now time to drop the notion*
>
> - Too many people still think biological has a value
> - That you can figure out what it is by measuring something: transcriptions or epigenetic markers or something
>
> Rich explains, “*I can do it and give you personally your personal biological age. That’s a waste of everyone’s time, and it also distracts attention from things that actually are important and need to be thought about*.”
>
> Matt Kaberlein
>
> - Matt fundamentally disagrees (and is surprised)
> - He agrees with the idea of a kit you can buy to measure biological age
>   - The stuff that’s out there doesn’t work
> - He also agrees with the idea that reducing it to one number
>   - Conceptually he thinks it’s possible
>   - In reality, he thinks it’s going to be very, very difficult to do
>
> ***He absolutely believes that there is a biological aging process that is different from chronological aging***
>
> Rich Miller
>
> - Rich agrees with this (absolutely)
>
> ***You can agree with that and not like the idea of a number that constitutes your biological age***
>
> Matt Kaeberlein
>
> *2 things make him feel pretty confident in this idea*
>
> - 1 – Compare dogs to people
>   - This is an example he uses a lot among the general public
>
> Everybody’s familiar with the idea that 1 human year is about 7 dog years, but what does that mean?
>
> - It means that dogs age about 7x faster than people do
> - Of course, chronological time is the same between dogs and people
> - It’s the biological aging process
> - You can look across the animal kingdom and see this
> - And dogs get almost all of the same diseases and functional declines that we do at the tissue and organ level but also the whole body level
>
> We also know now there are single genes that significantly modulate what Matt would call the **rate of aging**
>
> - Rich agrees entirely
> - 2 – Genes that modulate the rate of aging
>   - Cynthia’s [work](https://pubmed.ncbi.nlm.nih.gov/8247153/) with [*DAF-2*](https://en.wikipedia.org/wiki/Daf-2) was mentioned earlier
>   - [*TOR*](https://en.wikipedia.org/wiki/MTOR)
> - We can turn these things up or turn them down
>
> - Animals across the evolutionary spectrum seem to age at different rates by modulating single genes
> - Matt doesn’t know of any other explanation other than that there is this process which we call biological aging that can be changed
> - Can biological aging be reversed? That’s an interesting question
>
> ***The process of biological aging is real; it’s just really complicated, and we probably only understand 5% at this point***
>
> Peter Attia
>
> - Peter lands where Rich is, which is if a patient asks about doing a biologic clock, he’s going to point to other metrics
>   - VO2 max, Zone 2, muscle mass, visceral fat, a very complicated movement assessment, balance, lipids, insulin
>   - He knows these 57 things about you and can tell you individually on each of them how you’re doing
>
> ***That number [biologic age] doesn’t tell him a single new piece of information***
>
> Matt Kaeberlein
>
> **What if you were to come up with some sort of composite picture of health based on all of those things?**
>
> - That’s a different biological aging clock
> - Sometimes we conflate the epigenetic tests with biological aging clocks
> - In part this is because of the way that irresponsible people in the field and marketers have done this
>
> ***There are all sorts of flavors of biological aging clocks, including things like frailty indices or metrics of a whole bunch of functional markers ‒ those probably are pretty good readouts of biological age***
>
> - To combine them all to get to one number that’s meaningful for every person is much harder to do
>
> **Matt tested 4 different direct-to-consumer biological age kits**
>
> - They were all epigenetic biological age tests, 4 different companies, and he did duplicates of each kit
> - It was from the same samples collected on the same day
> - He really tried to put his scientist hat on
>   - He only had 2 replicates (not 3 replicates) ‒ it was about the best he could afford
>
> *The results were very informative and they changed his views on these epigenetic tests*
>
> - The standard deviation was either 7 or 9
>   - He’s not a statistician but he knows enough to say that’s completely useless
> - They converged on his chronological age but with a huge variation between the tests
>   - 3 of the 4 tests were reasonably close to each other
>   - The duplicates were reasonably close to each other, but the individual tests were far apart
>   - One of the companies, the individual replicates were 20 years apart
> - Some people will say, “*But the* [*TruDiagnostic test*](https://shop.trudiagnostic.com/products/truage-complete-epigenetic-collection) *is great and the* [*Elysium test*](https://www.elysiumhealth.com/products/index) *is terrible, or the* [*Tally Health*](https://tallyhealth.com/products/test-kit) *test is terrible, and the other one is great.*”
> - Maybe, but how do we know?
>
> ***My take home is that the direct-to-consumer biological age testing industry is a complete mess, and Matt has no idea who to believe or if any of them are actually giving accurate data***
>
> - Matt knows some of the people at some of the companies, and he has personal feelings about who is trying to do it right and who’s a charlatan
> - But across the industry, it’s really hard to know
>
> > “*I think these are really good research tools. I think the direct-to-consumer component has gotten way ahead of itself*.”‒ Matt Kaeberlein
>
> *Matt doesn’t think there’s a lot of clinical value in these biologic age tests*
>
> - We don’t know the precision or accuracy
> - He doesn’t think you can make actionable recommendations based on these tests
>
> **Peter’s takeaway**
>
> - These tests fail in one thing they’re attempting to do
> - If he has a 40-year-old patient who wants to do one of these tests, Peter asks, “*If the answer comes back and says you’re 20, is your expectation that you will live another 70 years?*”
> - “*Conversely, if the answer comes back and says 60, is it your expectation that you will live another 30 years?*”
>
> ***Is the number this test gives predictive of future years of life?***
>
> - Because right now we have this thing called chronologic age that is the single best predictor of future years of life
> - Do we think biologic age as determined by these tests is better as a predictor of future years of life?
>
> *Peter proposes a way to test this*
>
> - How many people have contacted you to get ITP sample data to say, “*Can we predict how much longer these mice were going to live?*”
>
> Rich Miller
>
> - Rich agrees
> - There are tons of things you can measure on individuals, but you only need to ask 4 or 5 of them of a 70-year-old
>   - It’s not hard to figure out a very small set of tests that tell you how long a 70-year-old is likely to live, and it has nothing to do with methylation clocks or things like that
>   - Peter adds that MetLife does this really, really well
>   - And when life insurance companies start using biologic clocks as the cornerstone of their algorithms, he’ll start to think…
>
> Matt Kaeberlein
>
> - Matt doesn’t think we’re far away from that
>
> **⇒** He points out that they keep saying biological age when what they mean is epigenetic age or epigenetic tests
>
> **Peter explains more about these tests**
>
> - Some of these clocks use solely epigenetic measurements, not all
> - Most of the direct-to-consumer ones are epigenetic
> - But some of these tests use a litany of biomarkers inclusive of epigenetics
>   - Methylation pattern, vitamin D level, glucose level, cholesterol level, and a whole bunch of other things
> - Then they compress all of that into a number as well
>
> Matt Kaeberlein
>
> ***Matt thinks we will get to a point where the technology is developed far enough and the quality control is good enough on the consumer side that these tests will be better than chronological age***
>
> - Unless you think that all of the research that’s been done on these epigenetic aging clocks is somehow flawed
> - It’s clear that you can create algorithms that can predict specific methylation patterns that are more highly correlated with life expectancy than chronological age
>
> Steve Austad
>
> - The big “but” here is even if that is the case, they would not be as good as what Peter would predict after all the tests
>   - Which is biological age
>
> Matt Kaeberlein
>
> - This is what Matt was getting at (biological age versus epigenetic age)
> - He thinks what you are actually doing is looking at other biomarkers that have a long-term clinical history that you’re using to come up with a surrogate, but really is reflecting largely biological age
>
> **Matt doesn’t think biological age and health are equal**
>
> - He thinks they’re strongly overlapping
> - Certainly you can identify many ways to reduce health without accelerating biological aging (that’s easy)
>
> *For example*
>
> - If he shows you a sample of nephrons, based on nothing but the methylation pattern could you identify the 20-year-old versus the 50-year-old versus the 70-year-old?
> - Matt agrees, it’s very easy to predict based on the methylation pattern which nephron came from which person
>
> Rich Miller
>
> - There are a lot of things that change with age
> - The literature has 25,000 things that change with age
> - Average amount of methylation at these 10 spots is number 11,407 of those ‒ great, you’ve got another thing that changes with age
> - But that’s not enough
>
> **Do you believe that all of the research we’re seeing on the epigenetic clocks is going to be the 78th variable that we would include in our gestalt?**
>
> Matt Kaeberlein
>
> - Matt is hopeful that epigenetic algorithms can get to the point where they can replace many (certainly not all but many) of the other biomarkers that are being measured
> - The thing that gives him hope is we know that epigenetic changes are part of biological aging
> - This again is a different question, but if we look at the hallmarks of aging [shown in the figure below], epigenetic dysregulation [epigenetic alterations] is 1 of the 12
>   - Some people will argue it’s the most important one
>   - That gives Matt hope that we are measuring something that plays a causal role in the aging process
>
> ![](https://peterattiamd.com/wp-content/uploads/2025/01/f2-longevityroundtable.png)
>
> **Figure 2. Twelve hallmarks of aging**. Image credit: [*Cell* 2023](https://pubmed.ncbi.nlm.nih.gov/36599349/)
>
> - What is missing, what would give all of us a lot more confidence, is if we had a mechanistic connection to the specific methylation changes and some cause of aging or age-related disease
>   - In other words, this change in methylation changes this particular gene’s expression level, which changes the rate of biological aging
>   - If we had that, we’d feel a lot more confident
> - Peter points out that he and Matt spoke about this briefly at the end of their last podcast [[episode #272](https://peterattiamd.com/davidsabatini-mattkaeberlein/#:~:text=infections%20at%20all-,Might%20rapamycin%20induce%20changes%20in%20T%20cell%20methylation%20patterns%2C%20potentially%20reversing%20biological%20aging%3F%20%5B1%3A34%3A15%5D,-Do%20you%20believe) starting at 1:34:15]
>
> ## The utility and drawbacks of the “hallmarks of aging” as a framework for research and funding [49:30]
>
> Topics Peter wants to address
>
> - 1 – Do we believe that it is possible that of the hallmarks of aging epigenetic change is the most important?
> - 2 – Do we believe that the epigenetic changes that we observe over time, which are undeniable, are causal in the arrival of other states?
>   - Everything from the arrival of senescent cells, the increase in inflammation, the reduced function of the organs (which really is the hallmark of aging)
> - 3 – If so, does that mean that reversing the epigenetic phenotype will undo the phenotype of interest?
> - 4 – What about the [proteome](https://en.wikipedia.org/wiki/Proteome)? What about the [metabolome](https://en.wikipedia.org/wiki/Metabolome)?
>   - This is where Peter and Rich’s conversation left off last time [[episode #281](https://peterattiamd.com/richardmiller2/#:~:text=the%20GPLD1%20protein-,Why%20proteomics%20are%20essential%20to%20understand%20changes%20in%20the%20cell%20%5B1%3A12%3A15%5D,-Is%20this%20an) after 1:12:15]
>
> Rich Miller
>
> - These are 3 broad, general statements and each deserves careful amendments
>
> **1 – The hallmarks of aging**
>
> - Rich thinks this set the field back dramatically
>   - When you are officially branded a hallmark of aging by two people sitting alone at their computers and writing a review article
> - You can’t tell if something is a hallmark of aging
>   - Does that mean it goes up with age? It goes down with age?
> - Can you change it in a way that will extend lifespan?
>   - You can kill a mouse or a worm by removing it?
> - It basically it’s something that somebody once thought might be of interest to aging
> - The downside of that is once you’re officially branded as a hallmark of aging, anyone who wants to write a grant on that doesn’t have to prove that their a fundamental cause and effect model has any merit because it’s a hallmark of aging
>   - I don’t have to prove it anymore
>   - Someone I don’t know who or on what grounds has decided it’s important
>   - My reviewers know it’s important because they’ve read the hallmark of aging paper, so I don’t have to think about whether it’s important
> - The negative side of that coin is that there are lots of things that didn’t make it into the hallmark list
>   - Rich thinks it’s premature to close off thought on some of those
> - It’s easy to come up with a dozen things that ought to be investigated, but if you want to investigate it and it’s not on the hallmarks list, what are you wasting?
>
> ***Deciding which of the hallmarks is the “big daddy hallmark” or whatever strikes Rich as not the correct thing to talk about in the hallmarks arena***
>
> Steve Austad
>
> - Steve thinks the hallmarks are kind of an arbitrary list
> - He doesn’t think any of them would say that those 12 things are not involved in aging
>
> ***Steve would certainly not consider epigenetics as the key hallmark***
>
> > “*I consider it to be an interesting list. It became biblically sacrosanct almost immediately. I’ve never understood why*.”‒ Steve Austad
>
> Matt Kaeberlein
>
> *The flip side is the hallmarks have been immensely useful to the field*
>
> - They are a very easy way to communicate this idea of biological aging, and it helps convince some of the scientific community who thought it was all just hocus pocus and snake oil that there is some mechanistic research happening
> - We can point to specific things that are aging (really valuable)
> - The hallmarks of aging has contributed to the popularization of longevity
>
> *And it has been extremely detrimental to the field*
>
> - It caused the field to narrow prematurely
>
> **⇒** Matt doesn’t know if we understand 80% of biological aging or 0.005% of biological aging (his guess is it’s closer to 0.005%)
>
> ***By and large, the funding to look outside of the hallmarks dried up once the hallmarks became the dominant paradigm (people stopped looking)***
>
> - Matt thinks we need to go back to more discovery science and thinking outside the box
>
> Peter asks, “*Would that happen automatically if we could wave that magic wand and increase funding?*”
>
> - It would help, but Matt doesn’t know if it would be enough
> - You also have to change the mindset about what people call “fishing expeditions”
>   - That’s a bad word in grant review panels
>   - “Fishing expedition” meaning you don’t really know what you’re going to find, but you got to go look before you can figure out what’s important
>   - We have to change that mindset as well
>
> Rich Miller
>
> **Thinking about chronic inflammation as 1 of the 12 hallmarks of aging**
>
> *What could be happening*
>
> - This particular set of cytokines might be overexpressed by some glial cells, and that leads to loss of cognitive function
> - Whereas this other overlapping set of cytokines produced by the macrophages in your fat may make you more prone to diabetes or metabolic syndrome
> - Whereas this particular set of lymphocytes are necessary to repel COVID and that’s why you are more susceptible to COVID
> - Learning what changes within the extremely broad generic idea of inflammation what changes in what cell types in what people under what pharmacological or genetic changes, how they are interacting with other aspects of pathology, that’s marvelous to do
>
> ***But simply saying, “Inflammation, that gets bad when you’re old,” is a way of avoiding the labor of thinking and that’s why Rich is against it***
>
> Steve Austad
>
> - Matt brought up a really good point about the way research gets reviewed
>   - And we scientists are to blame
> - For lazy reviewers, having these 12 hallmarks is really helpful
>   - Oh, this has got one of the hallmarks in it; this must be good stuff
>
> ***Reviewers need to be more open to new ideas and new approaches***
>
> - Everybody knows that NIH grants are approved if they’re incremental
>   - If they’re really breakthrough, they don’t get approved
> - The very famous biologist [E. O. Wilson](https://en.wikipedia.org/wiki/E._O._Wilson) told Steve years ago, “*Don’t ever include your best ideas in a grant. They won’t get funded. Do standard stuff. Save your best ideas for projects that you do on the side*.”
>
> Matt Kaeberlein
>
> - This is one of the reasons Matt left academia
> - It is almost impossible to get the important stuff funded (drove him nuts)
>
> ## The role of epigenetic changes in aging and the challenges of proving causality [56:45]
>
> **The second part of Peter’s question: are epigenetic changes causal, and if you could reverse it, would that be a good thing?**
>
> Rich Miller
>
> *Is it causal?*
>
> - The problem is what it means
> - There are some changes that occur in this particular set of 40 cells in the pineal
> - And there are other changes that occur in these cells in the bone marrow
> - And there are other cells that change in the gut and villus lining cells and the crypt cells
> - They are all epigenetic in some
> - They are caused by some things, and we don’t really know which, if any of these, count for aging
> - For the person who says, “*I’m going to prove that an epigenetic change is responsible for aging,*” they haven’t begun to come to grips with the nitty-gritty
> - People always ask, “*Does your drug change epigenetic things?*” ‒ unfortunately, that’s where they stop thinking
> - Rich is always willing to give people tissues from his drug-treated mice
>   - They can study epigenetic changes that affect neuron regeneration
>   - This is important
>
> ***But the general notion that that’s aging vaguely thought of is due to epigenetic change, more vaguely thought of, doesn’t really get you anywhere***
>
> Peter asks, “*Is part of the issue that you’re saying, well, what’s causing the cause?*”
>
> **⇒** No, it’s just that the concept of epigenetic change encompasses thousands of changes in hundreds of cell types under hundreds of influences
>
> - Of course, some of that causes other stuff
>
> ***Everyone can agree that epigenetic change is causal for all sorts of age-related pathologies, but it’s meaningless because what counts is to say this specific epigenetic change is really important in this disease***
>
> - Or this specific broad-spectrum change in multiple tissues causes something good or bad ‒ you have to define what it is before you can test it
>
> **Let’s use a specific example: when you look at a patient with type 1 diabetes and you look at their ꞵ-cell in their pancreas**
>
> - They look different epigenetically than the [ꞵ-cell](https://en.wikipedia.org/wiki/Beta_cell) of an age-matched person without [type 1 diabetes](https://en.wikipedia.org/wiki/Type_1_diabetes)
> - We also know that their ꞵ-cells don’t function
>
> *What confidence would you assign to the notion that the epigenetic change on the ꞵ-cells of the type 1 diabetic are indeed causal to the loss of function of the ꞵ-cells?*
>
> Rich Miller
>
> - Rich’s last exposure to the causes of type 1 diabetes was when he was in medical school
> - He vaguely remembers it was an autoimmune disease
> - If you’re poor little helpless ꞵ-cells are being attacked by antibodies and macrophages and things, those stressors’ are going to cause epigenetic change
>
> ***Whether those epigenetic changes contribute to some extent to the ill fate of the ꞵ-cells ‒ it’s possible***
>
> - If Rich were an expert on diabetes pathogenesis, he’d really want to know that
>
> **⇒** It doesn’t have anything to do with aging, but it’s an interesting question about causality
>
> Steve Austad
>
> - You might equally say, no, no, it’s the mitochondria that have changed
> - They’re a hallmark of diabetes
> - Or it’s the glycated proteins
>
> ***There’s a ton of things, and there’s no reason at this stage to give epigenetics primacy over any thing else***
>
> Matt Kaeberelin
>
> - But it’s a nice hypothesis
>
> Rich Miller
>
> - You can formulate these questions because a lot is known about type 1 diabetes, and I understand 0.05% of the biology of aging
>   - Matt says we know 0.005% (Rich is off by an order of magnitude)
>
> *Formulating the questions in exactly the way Steve did makes it clear how difficult it is to evaluate the concept that epigenetic change contributes to pathogenesis and type 1 diabetes*
>
> - We know more or less what is going on in type 1 diabetes; we don’t know what’s going on in aging
> - We don’t even know what part of the body is going on, or parts more likely, of the body
>
> Matt Kaeberlein
>
> *Matt internally reframes it a bit to ask*
>
> - What would the experiment be?
> - What would you need to do to convince yourself that either broadly speaking epigenetic dysregulation causes aging (whatever that means), or this specific epigenetic change that is associated with chronological age causes aging?
>
> **⇒** We’re never going to get to the answer until somebody actually does the experiment
>
> Rich Miller
>
> - Or decides that it can’t be formulated because it’s too complicated and gives up
>
> Matt Kaeberlein
>
> - Matt agrees
> - But people are trying to do both of those things
>
> **People are using partial or transient epigenetic reprogramming and asking can they have effects on biological aging?**
>
> - Matt is actually cautiously optimistic it
>
> ***He doesn’t think it’s going to be a game changer, but he does think you can modulate aspects of biological aging***
>
> - The technologies are being developed for targeted epigenetic modifications
> - If we think this particular epigenetic mark at this particular location in the genome controls aging, you could go in and modify that and then see
>   - Matt doesn’t think it’s going to be that simple but let’s say it is
>   - Do you reduce disease?
>   - Do you increase lifespan?
>   - Do you improve healthspan?
> - Those are the kinds of experiments that would get us to where we can have a lot of confidence
>
> ***If somebody publishes a paper 3 years from now showing they have made a mouse live 6 years by multiple rounds of transient epigenetic reprogramming, that will convince Matt that this [epigenetic] strategy modulates biological aging***
>
> - Nobody has done that yet
>
> **What about something far less impressive but still worthwhile?**
>
> Peter Attia
>
> - Consider if we could get to the point where we could locally deliver vectors that would epigenetically change chondrocytes so that you could take osteoarthritis in the knee and just regenerate cartilage by changing the epigenome
>
> Matt Kaeberlein
>
> - Clinically useful, but is that biological aging?
>
> ***Matt would not be convinced that’s modulating the biological aging process***
>
> - He would be convinced that’s a clinically useful strategy for people who benefit from that therapy
>
> Peter Attia
>
> - It depends on why we think an individual would be experiencing osteoarthritis
>   - How much of that is senescence?
>   - How much of that is inflammation?
>
> Rich Miller
>
> - If you think osteoarthritis of the knee requires a knee joint replacement and that’s going to help your patient, you are not rejuvenating [chondrocytes]
> - It’s perfectly possible to do great things with technology, including chondrocyte regeneration, without having to decide that that’s related to aging
> - People don’t age because they fail to have titanium knee joints or something
>
> ## The translational challenges of moving aging research from preclinical studies to human applications [1:03:45]
>
> > “*I think about age-related disease as the downstream effect of biological aging. For most diseases, there becomes a point where the pathology of that disease mechanistically is no longer the same as biological aging*.”‒ Matt Kaeberlein
>
> Matt Kaeberlein
>
> - One of the implications of that is the interventions that slow biological aging may not work once you get past that point, but things that do work for that disease may have nothing to do with biological aging
>
> **Think about cancer as an example of an age-related disease**
>
> - We know in many cancers, the process is you have one or more mutations, which then often lead to additional mutations
>   - You get genome instability
> - Eventually you get an oncogene that gets activated, and that leads to uncontrolled cell division
>   - Or a tumor suppressor gene that gets deactivated
> - If we accept that immune surveillance is one important anti-cancer mechanism, we know that immune surveillance declines with age
> - Early on we’re clearing a lot of our cancers
> - As our immune system declines, these cancers are going to escape immune surveillance
> - They’re going to accumulate all these mutations
> - They’re eventually going to go into uncontrolled cell division
>
> ***At that point you can treat the cancer, but uncontrolled cell division is not a part of the normative aging process***
>
> - The mechanism now is fundamentally different from normative aging
>
> ***And the treatment (let’s just say the treatment in this case is chemotherapy) might benefit the cancer but it’s not going to retard aging***
>
> **Rapamycin is a good example here**
>
> Matt Kaeberlein
>
> - We all believe that [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) and inhibiting [mTOR](https://en.wikipedia.org/wiki/MTOR) slows biological aging
>   - At least in mice, hopefully in dogs
>   - [discussed in episodes [#148](https://peterattiamd.com/richardmiller/), [#175](https://peterattiamd.com/mattkaeberlein2/), [#272](https://peterattiamd.com/davidsabatini-mattkaeberlein/)]
>   - Hopefully in people
>
> > “*[mTOR] It’s a fundamental node in the network. That’s the way I think about the hallmarks of aging.*”‒ Matt Kaeberlein
>
> - It’s a node in the network that underlies the hallmarks of aging
>
> **⇒** We can manipulate mTOR with rapamycin, slow aging
>
> - Rapamycin is a pretty good anti-cancer drug until the cancers have evolved to ignore the mTOR break, and then rapamycin doesn’t work anymore
>
> *We know rapamycin doesn’t work for most cancers (that’s been tested)*
>
> - It’s because the cancers evolve to bypass the mTOR break or to bypass the ability of rapamycin to inhibit mTOR
>
> Peter adds, “*That’s a really good point that we all take for granted that I think is worth noting. Rapamycin can be unsuccessful as a chemotherapeutic agent and can yet be very successful as a cancer preventive agent.*”
>
> Steve Austad
>
> - This also illustrates why traditional disease-based medicine is not about the biology of aging
>
> ***Something of the biology of aging is distinct and it needs to be investigated in a different way***
>
> - We know that in the aging field, but the people in the cancer field and the cardiology field and the neurology field, they understand that
>
> **Why is this a zero-sum game?**
>
> - Why can’t we study cardiology, oncology, and neurology and aging without everybody feeling like they’re taking?
> - Peter’s way of saying that is, “*We need to have Medicine 2.0 and Medicine 3.0 in parallel.*”
> - Because the tools of the medicine 2.0 scientist and physician, which we see on display today are:
>   - Putting the stent in
>   - Giving the chemotherapy
>   - Lowering the cholesterol, all of these things
> - The medicine 3.0 toolkit looks different; different science
>   - You’re going to use rapamycin here, and you’re not going to use it over here because it’s too late
> - Instead of saying one or the other, why isn’t it both?
>   - Why wouldn’t we want both of these running in parallel?
>
> Rich Miller
>
> - We would
>
> ***The zero-sum game is a pretty good analogy for what’s actually going on***
>
> - The amount of research dollars (at least available to NIH) is not infinitely expansible
>   - It’s set by complex political process
>   - And then there’s a separate downstream process that allocates it amongst institutions
> - So saying that it would be a good idea to have more funds (Rich agrees), but it’s not easy to do
>
> Peter Attia
>
> - Peter misspoke ‒ it would be a portfolio of reallocation
> - But it will be worthwhile because the burden of this disease will be lower
>
> *Peter’s analogy*
>
> - It’s like saying, right now I spend $100,000 a year on the barrier to my house to prevent anybody from breaking in
>   - And I spend $100 a year patrolling the neighborhood to make sure there aren’t too many bad guys in the neighborhood
> - There’s a scenario where if your total budget is $100,100, maybe you could spend $80,000 in total by spending more money patrolling the neighborhood (less money overall)
>
> Rich Miller
>
> ***I think we generally agree with you that having a greater proportion of available research dollars, (both private and public) going into the biology of aging and its impact on late life health would be a good thing***
>
> Steve Austad
>
> - But you’re you’re going to get a huge argument from anybody in the cardiology field, the neurology field, the Alzheimer’s field
> - It’s their money
>
> Peter asks, “*But wouldn’t some of those people as the funding dollars move towards the aging side also want to move and say, ‘Look, I’m going to study this through the aging lens.’”*
>
> Rich Miller
>
> - Rich was on the council for the National Aging Institute for 3 years, and if at any point somebody would say something like, “*I wonder if maybe a few percent of the Alzheimer’s budget might instead go to studying how slow aging models would have an impact on late life neurodegenerative disease*.”
> - The next day, the director of the Aging Institute would get a call from 2 or 3 congresspeople who were on the Appropriations Committee stating that this will not be happening because there was an Alzheimer’s Association person who got the call from the NIA staff member in charge of Alzheimer’s
> - They’re tied in to the political process
>
> Peter Attia
>
> - Well, we just need to go maybe one step further because those congresspeople have a boss
> - Maybe it’s because the public doesn’t understand: those people answer to the public
> - These are our dollars
>
> Matt Kaeberlein
>
> - But Alzheimer’s Association is a patient advocacy group; that is the public
>
> Peter asks, “*What have they done for those patients lately?*”
>
> - That’s a different question
> - Matt agrees with Peter and thinks part of this is educating people
>
> **An aside on Alzheimer’s disease**
>
> Peter Attia
>
> - If you know somebody who’s suffering from Alzheimer’s disease, you know very well that the only thing we’ve got going for us right now is prevention
> - We don’t have too many silver bullets in the treatment gun
>
> Steve Austad
>
> - Despite massive spending, massive spending on it
> - Steve was once in Congress trying to lobby with about 6 people from the Alzheimer’s Association in the same room, and he was totally ignored by staffers that were in there
>
> Matt Kaeberlein
>
> - Matt agrees with all of this
> - He points out: we should be careful not to demonize people for wanting to cure Alzheimer’s
>   - It’s a good goal
>
> ***The communication piece is about the fact that it’s going to be much more efficient and effective to keep people from getting it in the first place***
>
> **⇒** This goes back to the idea that once you’ve outpaced the biology of aging with the pathology of the disease, it gets a lot harder to do anything about it
>
> **Getting the message out there about the biology of aging**
>
> - Matt doesn’t know why we’ve been so unsuccessful with the communication part
> - A lot of us have been out there trying to communicate this message for a long time, but it’s starting to permeate
>
> > “*We’re at that moment I think where people are starting to get it, that biological aging is a thing. It’s malleable.*”‒ Matt Kaeberlein
>
> - We don’t really know for sure what works in people and what doesn’t work yet, but we’re getting there
> - It’s going to take a little while, but there’s reason to be optimistic
>
> Steve Austad
>
> - The private sector is another reason to be optimistic
>
> ***Steve thinks when we defeat Alzheimer’s disease, it’s going to be because of the biology of aging; it’s not going to be because of the drugs that get rid of it***
>
> Matt Kaeberlein
>
> - Matt agrees and thinks this will be probably be true for cancer and heart disease
>   - Although Peter is more optimistic that we can prevent heart disease
>
> Peter Attia
>
> - If you took the tools of medicine 2.0 and just applied them 30 years earlier, we wouldn’t have ASCVD
> - That’s the one place where it’s worked
> - But that’s because the mechanism of action is so well understood with ASCVD compared to Alzheimer’s and cancer
>
> Matt Kaeberlein adds, “*A lot of infectious disease, a lot of liver disease, a lot of kidney disease, all of those things can be improved dramatically by targeting the biology of agin*g.”
>
> - If Peter were to write his [book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_1?crid=3VCCZOEO62GJ4&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZdGttk3nhLTMuCT6AR1kYNaeU4g3JqQyyTVOqy9epPTjwxzLrbybh5p6kVKfHMZy4G4NUX4XwQ_Fvd2bRJfjc3NqunA3CjgjmNWU6w6qHqNUY5Y1RkETd3cnhnjPemK9EBQ4WQsTCy6uvU46Zc6DZEy_A9qmcO0XyB8Og8HonHYpTzgyGfP3_he-su_f70MmIGwObAaEWfmMqFpP5pOTYWc._dK-pxT4rJbIVnlKwB3ZsOGe-SwqzBE1uMvMArcK370&dib_tag=se&keywords=outlive+peter+attia&qid=1737043421&sprefix=outlive%2Caps%2C96&sr=8-1) again, he would add a **5th horseman: immune dysfunction**
>   - He talked about the **4 horsemen**: ASCVD, cancer, neurodegenerative and dementing disease, and metabolic disease
>   - Immune dysfunction is not really a hallmark of disease, but it’s the 5th thing that brings life to a bad close
>   - He didn’t give it enough attention in the book
> - Immune dysfunction factors very heavily into oncogenesis
> - And COVID showed us what a risk factor it was to be old
> - Peter is reminded of this when  he seeps people his age get brutal pneumonia (it takes them 2 months to recover)
> - 2 of his patients in the past 6 months have had really bad pneumonias where you’re looking at the CT of their chest and you cannot believe they’re alive
> - 3 months later, 4 courses of antibiotics later, they’re fine
>
> ***You realize if you do that to a 75-year-old, it’s over; it simply comes down to how their B cells and T cells work***
>
> **⇒** That is an area where Peter would love to see more attention: what would it take to rejuvenate the immune system as a proactive statement
>
> Steve Austad
>
> - That’s part of the [XPRIZE Healthspan challenge](https://www.xprize.org/prizes/healthspan)
> - This is a perfect example
> - Influenza pneumonia has never fallen out of the top 10 causes of death in the US
>   - It used to be #2, but still now it’s #8 or 9, but it’s always there because you can’t really do anything about the late life immune dysfunction
>
> **If magically you’re able to double the amount of research being done on the biology of aging fundamentally [what experiments would you do?]**
>
> Rich Miller
>
> - Let’s give some mice a batch of anti-aging drugs and see if it makes them more resistant to infectious illnesses
>   - Including pneumonias, but viral infections as well and many others
> - No one has actually really looked in a serious way
> - The [ITP](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp) has enough money to just measure lifespan
> - They are hoping that everybody else is now going to look at the brain and the lungs and the infection, the sensory systems
>
> ***That really ought to be done and is not being done because of a lack of money***
>
> **Rich said something a while ago that Peter thinks is timely now: with each generation of these drugs, they get more efficacious and less toxic**
>
> - Rich responds, “*Not yet, but that’s the hope.*”
>
> *GLP-1’s are the best example of this*
>
> Peter Attia
>
> - Go back to the very first generation of [GLP-1 agonists](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist), barely lost any weight, horrible side effects
> - Generation 2 about 10 years ago, a little bit better weight loss, side effects are so-so
> - Fast-forward to [semaglutide](https://en.wikipedia.org/wiki/Semaglutide), quite a bit better efficacy, still really bad side effects
> - Next generation, [tirzepatide](https://en.wikipedia.org/wiki/Tirzepatide), better efficacy, side effects are almost gone
>
> **Now why haven’t we been able to do that with these geroprotective drugs?**
>
> - We have this one study using [Everolimus](https://en.wikipedia.org/wiki/Everolimus) that gives us a hint that says, hey, this might actually enhance immune function in people in their mid-60s
>   - [discussed in [episode #272](https://peterattiamd.com/davidsabatini-mattkaeberlein/#:~:text=research%20is%20needed-,Rapamycin%20may%20act%20as%20an%20immune%20modulator%20in%20addition%20to%20immunosuppressive%20effects%20%5B1%3A21%3A30%5D,-Pharmaceutical%20interest%20in) after 1:21:30]
> - We need the follow-up study, the follow-up drug
>
> ***Imagine what the 4th generation of that drug can do where it’s tuned to get better and better and have fewer side effects***
>
> Rich Miller
>
> - There’s commercial motivations
> - You know you’re going to sell a lot of the obesity drugs
> - They’re very strong commercial motivations to do those studies over and over and over again until you find one that works better and they’re good preclinical models that you can use that you’re not wasting too much of your time on clinical trials
> - That could be done for anti-aging drugs as well
> - Although testing anti-aging drugs in people is a whole separate set of tangle of difficulties (he doesn’t want to talk about that right now)
>
> ***It won’t be quite as easy for anti-aging drugs as it was for anti-obesity medications***
>
> - But no one’s doing even the first level of research to find the optimal compounds for efficacy without side effects or even to begin to see if they have desirable effects on aging rate indicators in people
>   - That’s kind of a cheap and easy study and no one has really tackled that yet
>
> **⇒** Steve just heard that there are over 80 senolytics studies in early clinical trials
>
> **Are any of these studies powered for anything other than safety?**
>
> Steve Austad
>
> - No, it’s all phase I
> - Peter thinks they’re almost useless then
>
> Matt Kaeberlein asks
>
> **How many years have we been having phase I senolytic trials now?**
>
> - Peter thinks it’s been at least a decade
> - Matt thinks there’s lots of complicated issues here
> - Endpoints for clinical trials are really challenging but solvable
>
> ## Distinguishing between a biomarker of aging and aging rate indicators [1:17:15]
>
> Peter Attia
>
> - There are 2 places Peter wanted to go next and he’s going to let Rich decide because he’s going to have the strongest point of view
>   - 1 – Can we talk about senescence
>   - 2 – Or can we talk about what biomarkers would be necessary to help us study aging in humans as we translate from Rich’s work and Matt’s work?
>
> Rich Miller
>
> - Rich wants to talk about the second one
> - He doesn’t want to spend the next 3-4 hours explaining why [senescence](https://en.wikipedia.org/wiki/Senescence) is silly and anti-senolytics are untested at best
>
> **The most important thing is to make a clear distinction between biomarkers and aging rate indicators**
>
> Rich Miller
>
> - A **biomarker** is something that changes with age
> - If you have some drug that slows aging, the biomarkers, many of them in the different cell types and in the blood will change more slowly
> - For example: long-lived dogs and short-lived dogs will have differences in the rate of change of biomarkers
> - It’s a very established part of the literature and valuable, but you have to wait until somebody’s old (whether it’s a dog or a mouse or a person)
>
> **⇒** Only when they’re old has the biomarker of aging (the surrogate marker for biological aging) changed very much
>
> ***In a human clinical trial, no one wants to wait 20 years to see whether the biomarkers have changed, and 1 year is such a tiny fraction of a human lifespan***
>
> - In 1 year, you don’t really anticipate detectable change with an appropriately powered study
> - **Aging rate indicators** are things you can measure that tell you whether you’re in a slow aging state or a normal state
>   - They are much less well studied and much less well established in principle
>
> Peter Attia
>
> **An example to help the listener understand the challenge of biomarkers**
>
> - When we study blood pressure drugs or cholesterol drugs, the biomarkers change so rapidly and we know the relationship between the biomarker and the disease state
> - So if your blood pressure is 145/90 on average before I give you this ACE inhibitor and 3 months later, 6 months later, 9 months later, 1 year later, your blood pressure is averaging 119/74; I know I’ve done something well
> - In phase III trials, I have to make sure that I also reduce some events in you
> - But generally by the phase II, I know that this drug is not toxic and that it’s predictably lowering your blood pressure ‒ that’s really, really valuable
>
> Rich Miller
>
> - A **biomarker** generically is something that’s easy to measure, that is informative about something that’s hard to measure
>
> *A classical example, famous example*
>
> - You want to know how many cigarettes’ somebody smokes a day, they’ll lie to you
> - But if you measure [cotinine](https://en.wikipedia.org/wiki/Cotinine) in their blood (that’s a byproduct of nicotine), you don’t have to ask them
> - You can find out how many cigarettes they had in the last couple of days by measuring blood cotinine ‒ that’s a biomarker of cigarette consumption
>
> ***In principle, a biomarker of aging (there are many of them) is measuring biological aging processes (and they’re useful in that regard), but they don’t tell you how fast you’re aging***
>
> *Analogy: an odometer is like a biomarker of aging of your car*
>
> - It tells you how many miles your car has gone, but it doesn’t tell you how fast the car is going
> - The speedometer tells you how fast your car is going
> - What we need and what we’re just beginning now to document is things like the speedometer: ***we need aging rate indicators that reliably discriminate slow aging mice or people from regular old mice or people***
> - We have now a dozen or so things that change in the fat, in the blood, in the liver, in the brain, and in the muscle that are always changed in any slow aging mouse
>   - Whether it’s drug A, drug B, drug C, caloric restriction diet, or single gene mutations
>
> ## The difficulties of translating longevity research in mice to humans, and the difficulties of testing interventions in humans [1:21:15]
>
> **Findings in mice about aging rate indicators**
>
> Rich Miller
>
> ***We’ve looked now at 5 different single gene mutations, and this whole set of roughly 12 aging rate indicators always changes in every slow aging mouse;*** **a*****nd it does so in youth, which is the key point***
>
> **⇒** If it does so quickly after an anti-aging drug is administered, that’s the transition ‒ that’s the bridge you need for clinical studies in people
>
> - If you want to know whether [metformin](https://en.wikipedia.org/wiki/Metformin) or [canagliflozin](https://en.wikipedia.org/wiki/Canagliflozin) or something slows aging in people and you don’t want to wait 20 years, but you’ve got things that tell you whether they’re in a slow aging state, how fast they’re aging versus normal (and that’s a big if)
>
> **⇒** We don’t yet have evidence we can do that; we just have hope we can do that
>
> - Then that allows you quickly, quickly being within 6 months to a year, to know whether your anti-aging manipulation, alleged anti-aging manipulation has moved them to a physiological status, which is associated with slower aging
> - A lot of that can be done in mice with drugs, with mutants
>
> Peter asks, “*Are these all Proteins, Rich?*”
>
> - No
> - Some of them are changes in the fat
> - Different classes of macrophages, the pro-inflammatory macrophages (the bad ones) go away
>   - The anti-inflammatory macrophages (the good ones) go up
>
> **⇒** [UCP-1](https://en.wikipedia.org/wiki/Uncoupling_protein#) goes up in every one of our 11 different kinds of [slow-aging mice](https://www.richmillerlab.com/long-lived-mutants)
>
> Peter asks, “*Does it go up in any of the mice that did not receive a successful drug?*”
>
> - They were compared to controls
> - This is an important question, and Rich is working on that in the next 5 years
>   - He just got a grant to do that
>   - He’s going to take mice and give them either a good drug or a different drug that doesn’t work and then make those comparisons
>   - A really important thing to prove
> - So far, the only control has been untreated mice
>
> Steve Austad
>
> - Let’s imagine that Rich is incredibly successful at finding these
>
> **⇒** That is a very long way from assuming that it’s going to be the same in people ‒ most things that clinically work in mice do not work in people
>
> - It might work, but ultimately we’re going to have to find this for people and Steve’s thought is the kind of evaluation that Peter does routinely of his patients
> - If we took a group of 65 year olds and we gave them a drug that we thought was an anti-aging drug and follow them the next 5-6 years doing these evaluations
> - You could probably safely say this is slowing aging or not slowing aging
>
> ***Steve doesn’t think that it’s going to be that easy to jump from mice to people in this***
>
> **How to test if lifestyle changes reduce the rate of aging**
>
> Peter Attia
>
> - Peter has always wondered if in people the easiest way to do it would be to take the most obvious thing that we know is going to reduce the rate of aging
>
> *An interesting experiment*
>
> - Find someone who is overweight, diabetic and smokes and has hypertension – get hundreds of these folks
> - 1 – Put half of them (to be ethical) in a plan where you try to get them to stop and presumably many don’t
> - 2 – In the other group, you pull out all the stops ‒ you’re interested in getting them to lose weight, not have diabetes, stop smoking, exercise like crazy
>   - Does this thing help you?
> - The greatest division between the 2 groups of individuals where we would be able to agree that group #2 is now aging slower
>   - The group that we’ve reconciled their diabetes, quit the smoking, etc.
> - Then Peter would love to see Rich’s 12 [aging rate indicators] line up in that population
>
> Steve Austad
>
> - That would be great
> - Steve thinks that people that study animals (himself included) always underestimate how well we can evaluate health in people with a very, very thorough evaluation because we don’t do that in our experimental animals
>
> Peter asks, “*Why do you think that is?* [*Parabiosis*](https://en.wikipedia.org/wiki/Parabiosis) *seems to actually work in certain mouse models. Do we have any reason to believe it’s going to work in humans? And if not, why not? Why are mice so different from people?*”
>
> Matt Kaeberlein
>
> - Matt wouldn’t say that just because we don’t have evidence that it works in humans means mice are different from people
> - First of all, when it comes to parabiosis, that’s a different discussion
> - Matt agrees that if you look at the attempts to cure cancer or other diseases in mice and translation to people, most have failed
> - That’s because those are artificial mouse models where they tried to give young mice an age-related disease
> - Peter points out that this is not true of Rich’s mice
>
> ***Matt is more optimistic that biological aging or normative aging is going to be much more likely to translate [from mice] to people both interventions and biomarkers than the specific disease interventions***
>
> *Matt doesn’t think we should rule-out mice as a useful model*
>
> - There’s reason to be optimistic that it [will translate to humans]
> - He’s kind of bullish on parabiosis and thinks it will work to some extent in people
> - It’s not a pragmatic approach for population gerotherapeutics
>
> **Peter wonders why parabiosis wouldn’t be as efficacious**
>
> Steve Austad
>
> - Aren’t there 6 or 8 clinical trials going on right now?
>
> Peter hasn’t seen them but recalls a plasmapheresis study for Alzheimer’s (a little bit different)
>
> - There’s also studies going on of young blood
>
> Matt Kaeberlein
>
> - If you think of parabiosis as both taking away the bad stuff that accumulates with age and adding in the good stuff that’s in young, some sort of plasma exchange hits at least half that equation
>
> Peter asks, “*You’re saying, Matt, the difference is probably amplified in disease-specific cases like heart disease, cancer and Alzheimer’s disease. Probably less relevant when you’re talking about aging because even a flawed mouse model still ages. In fact, it’s designed to age in a certain way.*”
>
> - Matt thinks normative aging looks very similar
> - If we look from mice to dogs to people, just broadly speaking, the process looks pretty similar
> - He’s cautiously optimistic that these things are going to translate
>
> Rich Miller
>
> - Not to pay too much attention to Steve’s pessimism on this point, although he’s completely right
>
> **Most things that do have an important effect in mice fail in human clinical trials, and it’s for a variety of reasons**
>
> - Sometimes humans are different from mice
> - Sometimes the drug has side effects that are tolerable in mice, not tolerable in people
> - Rich always likes to look at the other side of the coin
> - That is if your goal is to develop a drug that blunts pain in people and you screen 40 or 50 drugs and you find a couple that inhibit pain in mice, that’s a really good start
> - It doesn’t guarantee they’re going to work in people, but ***it gives you this category*** of snail-based neurotoxins [for example]
>   - Let’s make 40 of those from 40 different snails
>   - We’ll find one that actually works and can be made by a scalable process and doesn’t produce serious side effects
>
> ***It’s not a one-to-one mapping from mice to humans, but it’s an important critical first step***
>
> - It’s usually succeeds in finding a set of drugs of related families (or with related targets at least) that are efficacious in people
> - Most drugs that are used in people had useful rodent-based research somewhere in their pedigree
>
> Steve Austad absolutely agrees
>
> - Nobody’s saying that 100% of things that work in mice do not work, but I think there’s a critical difference for aging research, which it takes four years to do one of these in mice, and so if we have to do 40 to find 1 or 2 that work
>
> Rich Miller
>
> - That’s why Rich likes **aging rate indicators**, speed things up
>
> Matt Kaeberlein
>
> - Matt agrees, we need these aging rate indicators
>
> *The questions Matt always comes back to:* How do we get to the point where we’re confident that they actually work in people and maybe more importantly, how do we get to the point that FDA is confident that they work?
>
> - That’s the only way you’re going to be able to use them in a clinical trial
> - He doesn’t see a path in the short term
>
> Steve Austad
>
> - Steve doesn’t know that we need that
> - He went to the FDA to try to get them to approve a trial of metformin, and we didn’t couch it in aging
> - Because you’re right, as soon as you mention aging, their eyes glaze over and they’re not interested anymore
> - But we did it in terms of multi-morbidity, and they were fine with that
>
> Peter points out, “*But that’s a different end point. That’s not a biomarker.*”
>
> Rich Miller
>
> - Rich’s reply to this question: you’ve merged 2 different difficult problems
> - 1 – Problem A: can we find drugs that slow aging in people?
> - 2 – Problem B: can we surmount the legal and political barriers to getting them…
>
> Peter Attia
>
> - That’s not what I was aksing
> - I was asking how do we get to the point…
>
> Rich Miller
>
> - Peter is focused on something that Rich doesn’t have the answers to: how do we get the FDA to develop and approve clinical trials?
> - Rich is more interested in a step before that: it’d be nice to have some drugs that actually do work to slow aging in people
>
> Matt Kaeberlein
>
> ***But you have to trust the biomarker of aging rate before you can be confident that the drug that moves the biomarker of aging rate works in people***
>
> - Let’s just take FDA out of the equation
>
> Matt asks, “*How do we get to the point… where the 4 of us would sit and look at the data and all be like, ‘Yep. That works.’*”
>
> **Peter’s thought experiment**
>
> - Peter would take an example in humans that is so egregious that nobody with a straight face could say one group isn’t now aging slower than the others
> - It would make him worry because it would only show you the positive signal
>   - It would show the specificity and *not* the sensitivity of the test
>   - [specificity and sensitivity are defined and differentiated in [AMA #25](https://peterattiamd.com/ama25/)]
> - If you found a multimodal signal that detected a difference in rate of aging between those 2 very extreme sets, you might miss it with a geroprotective drug
>   - Which wouldn’t be as dramatic as that change
>
> Matt Kaeberlein
>
> - What if Matt told you that there are people who claim there are epigenetic signatures that do that, that correlate quite well
> - They claim with health outcomes, 10-year mortality, 5-year mortality, 3-year mortality in people, and are measuring the rate of biological aging because it’s out there in the literature
>
> Peter Attia
>
> - This is not perfect, but one thing Peter would immediately think of: take a really good biobank that would have enough samples that you could sample a bunch of human stuff and use an unbiased sample and a biased sample
> - He would determine an algorithm based on one and see how well it predicted on another, based on enough samples
>
> Matt Kaeberlein
>
> - That would have to be true at a minimum (he thinks it is)
> - It depends on how much faith you put in these research studies
>
> **⇒** People have published epigenetic algorithms: [DunedinPACE](https://pmc.ncbi.nlm.nih.gov/articles/PMC8853656/) is the one that most people are going to talk about that correlate seemingly pretty well, at least with mortality and with metrics of health span
>
> Peter asks, “*And DunedinPACE is using something besides epigenetic or is it only epigenetic?*”
>
> - It was trained off of other biomarkers and then they found epigenetic marks that correlate with those other biomarkers
> - So it’s a correlation to a correlation, but there’s still a correlation
>
> **Going back to the example you gave where you took a lot of people and gave them intense exercises and dietary changes to improve their likely health outcomes**
>
> Rich Miller
>
> - That’s a good place to start a discussion because you said every sensible person would see the treated group as aging more slowly
> - Rich would want to ask before he agreed to that: Do they also have improved cognition?
>   - How are they doing in cataracts?
>   - How are they doing in hearing?
>   - What happens when you give them a flu shot?
>   - Do they have a great flu shot?
> - The things Peter pointed out are really important for both overall health and for cardiovascular risk and the things linked to that (it’s nice to know)
>
> ***To convince Rich that you now have a slow aging group of people, you need to go beyond the risk factors for specific common human diseases***
>
> - If you could show that, then for the first time, he would be convinced you had an effective anti-aging manipulation in people
>
> **⇒** Currently, he doesn’t know that there is any effective anti-aging manipulation in people
>
> - If Peter’s approach got there, that would be a terrific research model
>
> Peter points out this gets into the definition of aging and asks, “*Would you agree that the approach I’m describing would produce a longer life?*”
>
> - It’s easy to produce a longer life
> - If you happen to have a clinical condition where you’re tied to a railroad track and there’s a train coming, you can extend that woman’s life enormously by simply giving her a knife and cutting the bonds and letting her walk away from the track
>
> Peter Attia
>
> - If 80% of people died as a result of trains on train tracks, that might be a worthwhile example
> - But given that 80% of people die from these 4 chronic diseases [4 horsemen mentioned earlier]
>
> Rich Miller
>
> - Rich is in favor of protecting people against chronic diseases
>
> **Talking about the biology of aging, there are all sorts of things that also happen when you get older that are not part of those chronic diseases**
>
> - To make a case that you’ve got an anti-aging manipulation, you need to show that those are changed too
>
> Matt asks, “*Do all of them have to change or just most of them?*”
>
> Peter Attia
>
> - Don’t enough of them have to change that you increase the length and quality of your life?
> - And if you still get a cataract at the same rate, Peter’s not sure that should be disqualifying
>
> Steve Austad
>
> - The important thing is all the stuff that Rich pointed out could easily be done in humans
>   - It wouldn’t be hard to measure hearing
>
> Rich Miller
>
> - There are dog examples where you’ve got well-known long and slow-aging breeds
>   - It’s true for horses and mice too
>   - More or less everything slows down together
> - The tiny dogs that are very long-lived, it’s not just that they have a delay of cancer, they have a delay in neurodegenerative disease, a delay in digestive diseases, in joint diseases
> - Aging has been slowed in those dogs, and if the dogs did your thing..
>
> Peter Attia
>
> - We might not have an intervention that does that (nonpharmacological method)
>
> **⇒** Even though exercise clearly extends lifespan, it’s not clear that it’s doing so by slowing aging
>
> - Those 2 things are different
>
> Rich Miller agrees
>
> ## Exercise, aging, and healthspan: does exercise slow aging? [1:35:45]
>
> Matt asks, “*Do you believe exercise slows aging? Exercise, healthy diet, sleep?*”
>
> Rich Miller
>
> - I have no idea
>
> Peter Attia
>
> - I think so (intuition), but I can’t point to any evidence that tells me so
>
> Matt Kaeberlein
>
> - There’s evidence to support it
> - The question is, does it rise to the level of evidence that would convince Rich?
> - Matt believes it probably does too, but he’s not going to say it with a 100% certainty
>
> Steve Austad
>
> - Here’s where we get back into healthspan versus lifespan
> - The effect of exercise on longevity is pretty small
> - Its effect on quality of life is enormous
>
> Peter Attia
>
> - It somewhat depends on where you start
> - This is a little problematic because defining it by the input is as valuable as defining it by the output
> - In other words, to say you exercise this many minutes a week versus that many minutes a week is a little dirty
>   - Because intensity matters
>   - What you do matters
> - Sometimes the output is what matters more
>   - How strong you are
>   - How high your VO2 max is
>   - Those tend to be more predictive because that’s the integral of the work that’s been done
> - But Steve’s point is well taken: the impact on healthspan is what Peter tells his patients
>
> > “*If this amount of exercise didn’t make you live one day longer, the quality in which your life would improve would justify it.*”‒ Peter Attia
>
> Rich Miller
>
> **We can move past the semantic discussions because there’s now molecular ways of checking this**
>
> - Exercises increases an enzyme called [GPLD-1](https://pubmed.ncbi.nlm.nih.gov/32646997/#:~:text=glycosylphosphatidylinositol%20(GPI)%2Dspecific%20phospholipase%20D1%20(Gpld1)) in the blood of exercise people and in mice
> - [Saul Villeda’s](https://villedalab.ucsf.edu/team) lab has shown that if you elevate GPLD-1, it does great things to your brain
>   - More neurogenesis and more brain-derived protective factors, brain-derived neurotrophic factors
> - [Irisin](https://pubmed.ncbi.nlm.nih.gov/22237023/) also goes up in humans and in mice after exercise; it does great things for your fat
>
> Peter Attia
>
> - As does [klotho](https://en.wikipedia.org/wiki/Klotho_(biology)) [the focus of [episode #303](https://peterattiamd.com/denadubal/)]
>
> Rich Miller
>
> - Let’s leave that out for a moment
> - You may be quite right
> - Rich wanted to stick with the [GPLD-1](https://en.wikipedia.org/wiki/GPLD1) and [irisin](https://en.wikipedia.org/wiki/FNDC5) to make the point that they also go up in all of the slow-aging mice
>
> **⇒** That is all the anti-aging drugs, the calorie-restricted diet, the isoleucine-restricted diet, and 5 different single-gene mutants that extend lifespan in mice ‒ they all elevate GLPD-1
>
> Peter asks, “[*17* ⍺*-estradiol*](https://en.wikipedia.org/wiki/17%CE%B1-Estradiol)*?*” [discussed in [episode #281](https://peterattiamd.com/richardmiller2/#:~:text=of%20aging%20together-,The%20ITP%20study%20of%2017%E2%8D%BA%2Destradiol%3A%20mechanisms%20of%20life%20extension%20and%20surprising%20sex%20differences%20%5B1%3A43%3A30%5D,-One%20of%20the) after 1:43:30]
>
> - Yes
>
> [Canagliflozin](https://pmc.ncbi.nlm.nih.gov/articles/PMC7710304/)? Both sexes?
>
> - Rich explains, “*This is the key question*.”
> - Irisin is sex-specific, GLPD-1 is in both sexes
> - If you are interested in the idea that exercise regimes have a benefit beyond the obvious exercise, linked physiological declines of age, do they improve cognition?
>   - And if so, how?
>
> ***These molecular changes are the things you need to begin to investigate***
>
> **⇒** The anti-aging studies in mice show that the anti-aging drugs (at least the ones we’ve looked at so far) increase the same things that exercise does
>
> Peter asks, “*Rich, have you done this experiment with an ITP cohort where you run in addition to a drug parallel?*”
>
> - Nope
> - You are going to ask if we exercised our mice, right?
> - We’ve never done that
>   - Never tested sedentary versus exercise
>   - Never tested obesogenic versus fasted
> - Rich never uses obesogenic diets
>   - It’s worth doing
>   - The ITP doesn’t do it; they don’t have the resources
>     - They have enough resources to test about 5 drugs a year
>
> Peter replies, “*We got to get you a budget increase because that will now get to this question, because now we could look at the soluble*… in mice”
>
> - It’s a good question
>
> Steve Austad
>
> - Maybe it would, maybe it wouldn’t
> - Steve is very agnostic about what we can learn from exercising mice because mice are basically kept in a jail cell their entire life
> - If you took a bunch of people and put an exercise wheel in a jail cell that would use it, would that be the same
>   - Will that substitute for people that walk around to go inside, they go outside, they go to the gym, that do this
>
> Peter agrees, it wouldn’t substitute for all of it (no question)
>
> - Steve thinks it’s a very low level of exercise
> - And if you didn’t see anything from it, then you wouldn’t rule it out
>
> Rich Miller
>
> **A testable molecular hypothesis**
>
> - A hypothesis that links the biology of aging to anti-aging drugs and to exercise and teasing out how those are interrelated
>   - And which of your exercise regimes increase irisin and increase GPLD1
>   - And increases neurogenesis
> - That’s a research agenda that could be very valuable
> - And then if you want to screen drugs in people to see which ones deserve expensive long-term testing
>   - The ones that raise GPLD1, irisin, and some aspect of neurological function in addition to the good stuff they’re doing for the muscles
> - That’s an approach
>
> Matt Kaeberlein
>
> - Matt agrees completely
> - This gets back to what we were talking about before with the **epigenetic changes**
>
> ***If you had a mechanistic connection (which is what Rich is drawing there), not only this is correlated with this outcome, but here’s why we all feel a lot more confident that this is real, that it’s important, and especially if that mechanistic connection is preserved in people***
>
> ## Are GLP-1 receptor agonists geroprotective beyond caloric restriction effects? [1:41:00]
>
> **Do any of you believe that GLP-1 agonists are geroprotective?**
>
> Matt Kaeberlein
>
> - Matt is super interested in that question; he doesn’t know
>
> Steve Austad
>
> - Steve thinks it is; they look good
> - We need to find out
>
> Matt Kaeberlein
>
> *There are 2 parts to this*
>
> - 1 – Are they geroprotective from a caloric restriction effect?
> - 2 – Or are there caloric-independent effects that could potentially be geroprotective?
>
> Peter is asking the 2nd question (and taking the 1st as a given)
>
> - That question: Is chronic caloric restriction beneficial in normal weight people?
> - But most people taking GLP-1 agonists aren’t normal
>
> Peter Attia
>
> - Yes
> - It’s impossible at this point because the studies are all done in obese and patients with type 2 diabetes, that we can’t disentangle them
>
> ***So we will just say that for that patient population, the caloric restriction appears to be geroprotective***
>
> - But yes, you’re right
>
> *Peter is technically asking the 2nd question*
>
> - In an individual who is metabolically healthy but overweight where there’s actually no evidence that weight loss per se is necessary outside of maybe some edge cases in orthopedic stuff, is there a geroprotective nature to this?
> - Where it’s most talked about is in **dementia prevention** right now
>   - That’s where it’s most complicated to tease that out
>
> **What about using GLP-1 receptor agonists for dementia prevention?**
>
> Steve Austad
>
> - It clearly has neurological effects, effects on addiction
> - The dementia connection is not inconceivable
>
> Peter adds that it crosses the blood-brain barrier
>
> Matt asks, “*Why hasn’t the ITP tested this yet, Rich?*”
>
> Peter asks, “*Is it because the oral ones are just not strong enough and we want to…*”
>
> Rich Miller
>
> - Yes
>
> Peter asks, “*Can you break your protocol and do an ITP with an injection?*”
>
> - No
> - Because it’s enormously laborious to do weekly injections
> - And also you need a separate control group
>
> Peter responds, “*That sounds like an ‘I need more money’ problem.*”
>
> - Because it’s the control group that you get sham injections and our…
> - Yes, if you increase our budget dramatically, Rich thinks it’s a worthwhile experiment
> - But what we’re waiting for is oral drugs that work that you don’t have to do injections of drugs
>
> Peter explains, “*There is an* [*oral semaglutide formulation*](https://pmc.ncbi.nlm.nih.gov/articles/PMC6969659/) *that’s taken daily*.”
>
> - It was submitted to the ITP this year
> - The detailed protocol, however, is again technically very laborious
>   - Each mouse has to be food deprived for 6 hours, then the material is administered, and then they have to have a change in their water balance for the next 2 hours
> - It is technically not an injection, but it is not any less laborious
> - And in addition, you have to have your own separate control group that gets all of those different manipulations with a sham [control] injection
>
> Peter asks, “*Could you do 3 instead of 5 next year and make that 1 of them, reallocate some funding?*”
>
> Rich Miller replies, “*Well, I’m not in charge.*”
>
> Matt Kaeberlein
>
> - It’s a heavy lift
>
> Rich Miller
>
> - Rich would vote against it
> - He would vote for waiting about a year until somebody comes up with a pill that you can just mix into mouse food or water and give it to the mice and it’ll work
>
> Steve Austad
>
> - These are going to be mice that are an incredible amount of stress from all the handling the injection
>
> Rich Miller
>
> - Yeah; that’s why the control group is necessary
> - But the companies are putting so much money into this
> - They understand why people don’t like to inject themselves
> - Rich knows nothing about it, but he’s reasonably sure that in a year or two, there’ll be some agent that works when you put it in the food of a mouse (or pop it as a pill as a person)
>
> ***Those would be enormously important to test***
>
> **Effects of GLP-1 receptor agonists on people with a normal body weight**
>
> Steve asks, “*Do we know if tirzepatide, for instance, if were given to people of normal body weight, do they also lose 15% of their body weight?*”
>
> Peter Attia
>
> - Peter has not seen the data on that
> - He can tell you anecdotally, having seen patients, it’s going to be **dose dependent**
> - As you know, that drug is dosed for as low as 2.5 mg weekly to as much as 15 mg weekly
> - Usually people who don’t need to lose much weight (this last 10 pounds), they take a very low dose
> - Now to your point, if they took the 15 mg, would they become sarcopenic? Peter doesn’t know
>
> > “*I think this conversation points out again how constraining lack of resources are*.”‒ Matt Kaeberlein
>
> - We can sit here and talk about 50 amazing questions
>
> Matt Kaeberlein
>
> - Every time Matt hears Rich talk about this stuff, it just pisses him off because there’s a bunch of stuff that should be tested, should have been tested by now that hasn’t been tested
> - Not because it’s not a good idea, but because there just isn’t any resources to do it
>
> Peter Attia
>
> - What’s really frustrating as well is that these are the types of experiments that would allow us to actually start to economically model the impact of these drugs outside of just a disease state
> - For example, if drugs like these are indeed neuroprotective and people can work 3 years longer, 5 years longer because they’re healthier, think of the impact on that over at [OMB](https://www.whitehouse.gov/omb/)
>   - What does that mean to tax take?
>   - What does that mean to delaying Medicare?
>   - What does that mean to reduce healthcare spending at the time when it is most expensive?
>
> Matt Kaeberlein
>
> - Last estimate Matt saw was $38 trillion a year for every year of healthspan
>
> That was a [McKinsey Report](https://www.mckinsey.com/mhi/focus-areas/healthy-longevity)
>
> ![](https://peterattiamd.com/wp-content/uploads/2025/01/f3-longevityroundtable.png)
>
> **Figure 3. McKinsey Report on the value of increasing healthy life expectancy by 1 year in the US**. Image credit: [McKinsey.com](http://mckinsey.com)
>
> Steve Austad
>
> - But that’s analysis by [Andrew Scott](https://en.wikipedia.org/wiki/Andrew_Scott_(economist)), British economist
>
> Peter Attia
>
> - That’s bigger than I would’ve guessed
>
> ## The role of senescent cells in aging, challenges with reproducibility in studies, and differing views on the value of current research approaches [1:46:15]
>
> Steve Austad
>
> - [Senescent cells](https://en.wikipedia.org/wiki/Cellular_senescence), the things that drive aging
>
> Rich Miller
>
> - It’s a terrible historical accident: [Leonard Hayflick](https://en.wikipedia.org/wiki/Leonard_Hayflick) way back found that human cells would only divide 50 times and stop
> - One of his colleagues, a guy named Vittorio Defendi made a joke at lunch and said to him, “*Hey, Len, maybe they’re getting old. Ha ha ha*.”
> - And Len did not understand it was a joke; he thought it was a serious scientific hypothesis
>
> ***It’s clearly nuts because we don’t get old in a way that is modeled by having embryonic lung fibroblasts stop growing***
>
> - But at the time, the hottest technique in modern medicine was you could grow cells in culture
> - So all the cell biologists who really wanted to use the coolest new toys, wanted to have a way of studying aging without all these messy mice and rats and having to wait and stuff
> - They could do it[*in vitro*](https://en.wikipedia.org/wiki/In_vitro) because this was *in vitro* aging
>
> ***This is in vitro senescence and skip ahead 30 or 40 years, the field went ahead with this metaphor without ever questioning it***
>
> - It’s now such an industry that the people who review these grants in papers and advise billionaires and advise startup companies, they all were trained in labs to just do senescence for a living
> - They never stopped to question
>
> **Rich’s collaboration with Judith Capisi to study “senescence”**
>
> - One of the most famous and best scientists in this area is a woman named [Judith Campisi](https://en.wikipedia.org/wiki/Judith_Campisi)
>   - Who just died last year
> - Rich and Judith were assistant professors together at Boston University
> - Together, they were going to send in a program project with a third person (Barbara Gilchrist)
>   - Rich was going to study immunity and aging
>   - Barbara was going to study skin cells
>   - When they asked Judy if she wanted to study self senescence, she read the literature and said, “*It has nothing to do with aging. It’s good cell biology. It’s good about cancer biology, but of course it has nothing to do with aging*.”
>   - They told Judy, “*Of course it has nothing to do with aging. We understand that, but the reviewers think it is aging. So if you can just keep a straight face for the three hours of the site visit, pretend you think it has to do with aging, you’ll get a great score.*”
>   - And that’s what happened
> - They got the program project
> - When she moved to Berkeley, she took her grant with her, and after a year or 2, she had apparently convinced herself that it was it was close enough to aging
>
> **The notion that aging is due to senescent cell accumulation is bad for 2 reasons**
>
> - 1 – It’s a grotesque oversimplification
> - The evidence for this is awful
> - 2 – But even worse, it again cuts off productive thinking
> - There almost certainly are changes that occur in some glial cells in the brain so that as you get older, they start making bad cytokines that’s bad for your brain
> - There probably are changes in some bone marrow cells or some cells in the lineage that leads to the ꞵ-cells in the pancreas that lose the ability to divide and that’s bad for you
>
> ***And finding out how it happens is really important***
>
> - But once you’ve convinced yourself, that it’s all the same thing
>   - This cytokine, this source of proliferation, this change in ability to make specific fibrous connective tissue, let’s call that senescence (it’s the same thing)
>
> ***You’ve lost what you need to think of for good, careful, well-defined experiments with well-defined endpoints***
>
> - If you say there is a thing called a senescent cell, the thing that’s happening in this glia and in this marrow cell and this pancreas, it’s due to the senescent cell accumulating, you’ve blocked off productive generation of research hypotheses
>
> **Rich makes a point about senolytic drugs**
>
> - The ITP was asked to test an allegedly senolytic drug called [fisetin](https://en.wikipedia.org/wiki/Fisetin)
> - It was given to us by someone who is using this now for clinical trials and who has a company that’s interested in senolytic drugs
>
> **⇒** We gave fisetin to mice, and it had no beneficial effect whatsoever
>
> Peter asks, “*What’s the mechanism of this drug’s action?*”
>
> - It has not action
> - It had no effect
> - It’s supposed to kill senescent cells or something
> - When Rich told this guy, “*Sorry, it had no effect*,” he said, “*Well, let’s prove whether it had any change in senescent cells*.”
>
> **⇒** Rich gave him blind tissues from each of the treated and untreated mice, and he tried a test and there were no changes in senescent cells by his marker (he tried 6 different markers)
>
> - They sent him brain, liver, and muscle samples and there were no changes in senescent cells by any of the markers that these folks looked at.
> - Rich is sure this drug is now being marketed in clinical trials, and you can buy it
>   - It’s a natural product, a supplement
>
> Rich explains, “*There’s no evidence as far as I know that it either has an anti-aging effect or removes senescent cells.*”
>
> ***But once you’ve got a commercial company pushing this stuff and your whole brand, your whole lab, your whole program project, and all the people who are reviewing, you are convinced senescent cells exist, they’re bad and drugs can kill them, it’s a snowball rolling downhill and a rant of the sort Rich just delivered has no impact on the field***
>
> **A counter example**
>
> Steve Austad
>
> - There’s good experimental data that these things [senescent cells] can be at least partially eliminated, and when you do that, there’s an improvement in health
> - This has been done both in a genetic treatment which genetically, which they prime these cells to be genetically killed
> - And it’s also been done with drugs (not with fisetin)
>
> ***There’s strong evidence that getting rid of these*** [***p16***](https://en.wikipedia.org/wiki/P16#) ***positive*** [***cells***](https://en.wikipedia.org/wiki/P16#Role_in_cellular_senescence) ***(which is really what it’s all based on) can have an improvement in health and in longevity***
>
> **A treatment that allegedly removes senescent cells in mice**
>
> Rich asks, “*Is the van Deursen* [*paper*](https://pubmed.ncbi.nlm.nih.gov/22048312/) *you’re talking about in which they were allegedly depleted?*”
>
> *Insights from Rich on this who was on the program project*
>
> - There’s a famous [paper](https://pubmed.ncbi.nlm.nih.gov/26840489/) by [van Deursen](https://www.janvandeursen.net/), [Kirkland](https://researchers.cedars-sinai.edu/James.Kirkland/about), [Darren Baker](https://www.mayo.edu/research/faculty/baker-darren-j-ph-d-m-s/bio-00027985) ‒ these guys are at the Mayo Clinic (2 of them have left)
> - They alleged that they could remove senescent cells by taking genetically modified mice and giving them a drug
>   - All the senescent cells would go away and the mice lived longer according to the paper
> - Rich was a part of the program project (along with Judith Campisi)
> - His my job was to do the lifespan experiment
> - We got the mice from Kirkland and van Deursen
> - We got Campisi’s mice
> - We got the drugs from them, and we gave the drugs to the mice at 18 months
>
> **⇒** And they had no effect on senescent cells, not one
>
> - We tried 7 times to show depletion of senescent cells in their mice using their drug and Rich went zero for 7
> - We then took the tissues blinded and sent them to [Judith Campisi’s](https://en.wikipedia.org/wiki/Judith_Campisi) lab, so she could measure p16 cells, but she didn’t know which ones were from treated and which ones were untreated
>
> **Rich explains, “*****When we undid the code, there was no effect on senescent cells whatsoever. So I remained somewhat skeptical.*****”**
>
> - When Rich asked van Deursen if he measured the number of senescent cells in his treated mice? [his reply was] “*No, we’re planning to do that.*”
>
> Peter asks, “*What was the phenotypic change in the mice when you did this experiment?*”
>
> - Rich didn’t want to do an expensive lifespan experiment with an alleged anti-senolytic drug until I knew that it was depleting senescence
>
> Peter asks, “*How long did you treat for?*”
>
> - Rich used their protocol and he asked Darren Baker, “*What is the dose? How long do you treat the mice and how long after you add the drug should you wait before you detect the removal of senescent cells?*”
> - And his answer astonishingly was, “*We don’t know. We’ve never looked at that.*”
>
> Peter asks, “*But the Nature mice were treated for how long?*”
>
> Steve Austad
>
> - A long time
>
> Matt Kaeberlein
>
> - They started treatment in middle age. Right?
>
> Steve Austad
>
> - In the published papers, they do show a reduction in p16 positive cell
> - And you’re saying you couldn’t replicate that in your lab?
>
> Matt Kaeberlein
>
> **We’re conflating a bunch of different issues here**
>
> - We’re conflating the genetic model with the drugs and do senescent cells even exist?
> - Matt thinks Rich’s skepticism is valid in many ways, and there’s actually a large body of evidence that whether we agree on the definition of senescence
>
> **⇒** What people are calling senescent cells do accumulate in multiple tissues with age in mice and people, and if you get rid of them, you can see some health benefits
>
> ***Matt is not convinced they have big effects on lifespan***
>
> - Because the data is mixed and even that genetic model, other people haven’t been able to reproduce (it’s messy)
>
> **Maybe start with what is the definition of a senescent cell? Because that’s where a lot of this confusion comes from**
>
> Rich Miller
>
> - This is what Rich was saying, there is no satisfactory definition
>
> Peter asks, “*Is your issue, Rich, that we talk about it like it’s one cell, but in reality…*”
>
> - Yeah, that’s a big part of it
> - You can’t think about it clearly if you imagine that these many, many different kinds of cell intrinsic changes with potential pathological impacts are all aspects of the same phenomenon
>
> Matt Kaeberlein
>
> - But we do that with other things
> - We do mitochondrial dysfunction
> - There’s lots of different ways to get to mitochondrial dysfunction
>
> Steve Austad
>
> - The NIH has just put about 600 million dollars into a network of researchers to study self senescence, and Steve is on the advisory group for that
> - And to the extent that Rich is saying these are many, many different things, all pretending to be the same thing ‒ that’s clearly true, but they’re coming up with bigger and bigger and broader definitions of what a senescent cell is
>
> *They’re also coming up with more and more interesting things that those senescent cells do*
>
> - Either in tissue culture (which I don’t put much faith in), or in mice
> - The NIH wouldn’t put that kind of money into something if they didn’t feel there was a valid basis
>
> ***Part of this is we’re calling it senescence, and that’s stolen a really good word out of the vocabulary because senescence just means aging***
>
> - It used to be you could talk about calendar aging, you could talk about senescence, which is what we now think of as aging
> - Now you can’t use this anymore because anytime you do, they think you’re talking about these cells
>
> Peter asks, “*Is this what they call the zombie cell?*”
>
> - Yes
>
> Matt Kaeberlein
>
> - The most common definition is just an irreversibly arrested cell that doesn’t die and typically gives off a pattern of inflammatory cytokines and other factors
>   - Which a catch-all for a lot of different ways to get there and a lot of different states that these irreversibly arrested cells can exist in
>
> Steve Austad
>
> - But even neurons, they’re not considering senescent neurons and neurons are postmitotic
>
> Matt Kaeberlein
>
> - Sure, but they don’t always give off this patterned signals, right?
>
> Steve Austad
>
> - No (that’s right)
>
> Matt Kaeberlein
>
> - Again, this is part of the problem you mentioned p16
>
> ***Even at the molecular level, the catalog of markers that people are using to define a senescent cell is changing (broadening)***
>
> - Matt agrees with much of what they’re saying, he just doesn’t think we should throw the baby out with the bathwater here and say there’s nothing to this
> - He thinks there is something to it, there’s lots of evidence
>
> Matt asks, “*Are there enough similarities between all the different classes of senescent cells that people are studying now that they should be categorized as one thing? I think that’s a valid conversation to have… I don’t think we know the answer yet*.”
>
> Steve Austad
>
> - They discuss this a lot in the [SenNet](https://sennetconsortium.org/) because even the [SASP](https://en.wikipedia.org/wiki/Senescence-associated_secretory_phenotype), even these things that are oozing out of the cells varies quite a bit depending on the nature of the cell
>
> Rich Miller
>
> - That’s the problem
> - Steve referred to it as almost anyone would as the SASP (the set of senescence associated secretory proteins), and once you think of it as the SASP, you’ve lost because the key point is not to do that
>
> **⇒** The key point is here’s a set of cytokines that this cell has begun to make (that’s really interesting)
>
> - Here’s another set overlapping probably
> - They make it when you’ve made them stop dividing for a separate reason
>   - That’s interesting
>   - We should study that
> - But to think, you’ve proven something about this cell type when you’ve actually been looking at this cell type because the SASP has been changed
>
> Peter asks, “*Do you think it’s possible that a drug such as rapamycin has part of its effect on aging through a broad inhibition of a subset of the SASPs?*”
>
> - Rich thinks it’s very likely that [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) changes cytokine production by many different cell types and that some of those changes probably have health benefits
> - He would like to know what it does to the cytokine production from the macrophages in the fat and the glial cells in the brain and cells that are in charge of protecting you from viral infections
> - But the mistake is to say yes, it’s affecting the SASP
>
> *Rich’s analogy*
>
> - If I said, “*Here’s a drug and it helps you because it affects neurons*”
> - You’d laugh at me because what you really want to know is: is it motor neurons, sympathetic neurons, parasympathetic neurons, neurons in your hypothalamus, what part of the hypothalamus (the ones that control appetite?)
> - And I said, “*No, no, no. It affects neurons. I’ve got a drug that affects neurons.*”
>
> Steve Austad
>
> - But people are aware of these complications and are studying these complications now
>
> Rich replies, “*I wish.*”
>
> - Steve thinks it’s the terminology that Rich objects to (and he can appreciate that)
>
> Rich Miller
>
> - The thinking that he objects to the terminology is problematic because it makes people stop thinking about the important details and start imagining that they’ve had a thought when they say, “*I have a drug that removes senescent cells.*”
>
> ***The problem is that the words trap you into patterns of thought that are, in this case, non-productive and misleading***
>
> ## How funding challenges and leadership in NIH and other institutes impact the advancement of aging-related research [2:00:15]
>
> Matt Kaeberlein
>
> **It may be inefficient, but the field is making quite a bit of progress**
>
> - The way you learn about the complexities, you start with a simple model, you study it, and then your model gets more complicated
> - Matt totally gets the frustration, but this is also part of the natural process here
> - What Steve said is really important: ***the fraction of the NIH budget that goes to study the biology of aging through NIA has remained tiny, but senescent cells are actually a really good example of how a bunch of people in other institutes are studying aging and they don’t even know it***
>   - They’re studying senescence in cancer or senescence in Alzheimer’s or senescence in kidney disease
> - So it actually has had an impact in broadening the appeal and scope of the field outside of NIA in ways that Matt certainly didn’t anticipate
>
> **A better way to allocate funding?**
>
> Peter asks, “*Going back to the meta problem at the beginning of our discussion, do you think that’s maybe a better way to think about allocating funds?*”
>
> - For example, the NCI receives the most funding within the NIH
> - Maybe some of the NCI funding goes to the NCI to study cancer prevention through geroprotection
>
> Rich and Matt thinks this is a good idea
>
> Steve Austad
>
> - No, no, no
>
> *Steve is part of a group lobbying Congress*
>
> - They asked the NIH to tell them: **How much work in geroscience is going on in all these other institutes?**
>   - Of course, they’re going to have some motivation to minimize that or maximize it or something
>   - But at least it will give us an idea
> - Right now we have no idea how much of the NCI budget is going to this or NIDDK or anything else
> - They already have produced a report that told us how much they were spending in the NIA, but we already knew that
>
> Matt Kaeberlein
>
> - That could alleviate some of the **turf war issues**, but ***what you really need is the change in leadership and leaders who actually recognize why this is important***, and that’s where it starts
> - We can have a conversation about how much power does the NIH director have, how much power does the director of HHS have?
>   - But that’s a place to start
>   - If you can get people in those positions who get, it’s going to have an impact
>
> ## Metformin: geroprotective potential, mechanisms, and unanswered questions [2:02:30]
>
> **Rich, do you think metformin is geroprotective in humans? I know it doesn’t appear to be in your mice**
>
> Rich Miller
>
> - The evidence is uncertain
> - There’s a famous [paper](https://pubmed.ncbi.nlm.nih.gov/25041462/) from [Bannister](https://www.linkedin.com/in/bannisterca/?originalSubdomain=uk) that alleged that diabetics on metformin had lower mortality risks than age specific
> - Peter jokes, “*You don’t listen to my podcast, do you?*” [discussed in [episode #270](https://peterattiamd.com/andrewhuberman2/)]
>   - He did a lengthy treaty in a journal club comparing the Bannister paper to the [Keys paper](https://pubmed.ncbi.nlm.nih.gov/36287641/) and came to the conclusion that the Bannister paper had too many methodologic flaws to be valid
> - That’s exactly what Rich was going to say
> - Rich has just written a review article (under review) about this [study](https://pubmed.ncbi.nlm.nih.gov/36287641/) from Keys and [Christensen](https://www.sdu.dk/en/forskning/dias/researchers/chairs/kaare-christensen) which says exactly that
>
> ***The question of whether metformin would be geroprotective in a non-diabetic (in humans) is interesting and unanswered***
>
> - It’s not the drug Rich would have looked at himself
> - If he had a big set of dogs, for instance, and he wanted to give them a drug that modified their glucose homeostasis, he would probably start with something like [canagliflozin](https://en.wikipedia.org/wiki/Canagliflozin)
> - Canaflozin actually does work in mice, and is known to be safe over the long-term in people
> - Metformin is safe over the long-term in people, but there’s not much evidence that it’s anti-aging (leaving aside how great it is for diabetics and pre-diabetics)
>
> Steve Austad
>
> - Steve thinks it’s very promising
> - He’s skeptical because he’s always skeptical in the absence of evidence
> - But the consistency of the observational evidence (ignoring the Bannister paper) that it reduces dementia, cancer, cardiovascular disease, suggests to Steve that there’s enough smoke there to look to see if there’s fire or not
>
> Peter asks, “*Steve, you’re saying it does all of those things in diabetics?*”
>
> - Most of the studies have been done in diabetics
> - Absolutely
>
> Steve points out, “*How much of that is just because you’re curing the diabetes, is an open question*.”
>
> Peter Attia
>
> - And how much of that is a selection for people in diabetes that are progressing much less slowly?
> - Because they’re the ones that stay on a single agent as opposed to the ones that progress into [additional treatment]
>
> Steve Austad
>
> - Right
> - Which is why you have to do the study
>
> **Where is** [**TAME**](https://www.afar.org/tame-trial) **in the world of…**
>
> [The TAME trial is discussed in [episode #204](https://peterattiamd.com/tame-metformin-anti-aging-trial-nir-barzilai/)]
>
> Steve Austad
>
> - TAME is in a very preliminary state: there’s now enough money to get it started
> - It’s enrolling right now
> - Previously, they didn’t want to start it until they had enough money to do the whole thing
> - It’s been impossible to get that
> - There’s now a small amount of money enough to get it started at a small scale with the hope that that will start the pot rolling
> - Yeah, it’s been around for 8 years now
> - Steve was in on the original discussion about:
>   - Do we do rapamycin?
>   - Do we do metformin?
>   - And it was all about cost and safety
> - Steve went in strongly advocating for rapamycin
> - He came out  acknowledging these cost issues
> - It was important because when we went to the FDA, we didn’t want them to think that we were trying to make a bunch of money with this trial and nobody’s going to get rich from metformin
>
> Peter asks, “*Why is* [*generic sirolimus*](https://en.wikipedia.org/wiki/Sirolimus) *so expensive still?*”
>
> Matt Kaeberlein
>
> - It’s supply and demand
>
> *Back to metformin*
>
> - First of all, we don’t know the answer
> - So what are our opinions?
>
> ***Matt’s opinion is diabetes probably accelerates biological aging, and metformin is effective at reducing diabetic symptoms and probably reduces biological aging in that context; it probably doesn’t in people who are not diabetic***
>
> **Peter pushes back on that**
>
> Peter Attia
>
> - Diabetes is an artificial diagnosis in that we just make a cutoff:we say if your [HbA1c](https://en.wikipedia.org/wiki/Glycated_hemoglobin) is 6.5, you have type 2 diabetes
>   - If your HbA1c is 5.9, you don’t
> - But there are data that we’ve looked at that suggest a monotonic improvement in all-cause mortality as average blood glucose goes down measured by HbA1c in the non-diabetic range
>   - Meaning people with an A1C of 5 live longer than people with an A1C of 5.5, live longer than people with an A1C of 6, all of whom are non-diabetic
>
> ***Point being, if metformin’s geroprotection comes through the regulation of glucose in the patient with diabetes, does it stand to reason that even in patients without diabetes further attenuation of hepatic glucose output is going to improve all-cause mortality?***
>
> Matt Kaeberlein
>
> - Maybe
> - The question is: What is the biomarker A1C actually reflecting?
>   - Is that presumably reflecting some aspect of metabolic homeostasis?
>   - First of all, does metformin in the non-diabetic have the desired effect or the effect we would associate with reduced mortality in nondiabetics consistently
>   - Matt doesn’t know the answer to that
>
> Peter Attia
>
> - It’s been a while since Peter has spoken to [Nir](https://www.einsteinmed.edu/faculty/484/nir-barzilai/), and the last time he had him on the podcast [[episode #204](https://peterattiamd.com/nirbarzilai2/)]
>
> *Nir’s rationale for why metformin was geroprotective had nothing to do with glucose homeostasis in a nondiabetic*
>
> - There was a figure of the hallmarks of aging and how metformin acted on each of them
>
> ![](https://peterattiamd.com/wp-content/uploads/2025/01/f4-longevityroundtable.png)
>
> **Figure 4. Mechanisms by which Metformin may combat aging**. Image Credit: *C*[*ell Metabolism* 2020](https://pubmed.ncbi.nlm.nih.gov/32333835/)
>
> - Not to say that that’s incorrect, correct or anything, it’s that there was something much more primal about metformin’s actions
>
> *Here’s Peter’s pushback on that*
>
> - Metformin requires an [organic cation transporter](https://en.wikipedia.org/wiki/Organic_cation_transport_protein) to get into cells that muscles don’t have
>   - Peter learned this recently [in the upcoming episode with Ralph DeFronzo]
> - If you look at the tracer studies, metformin does not get into muscles
>   - It gets into enterocytes and the liver, it’s very concentrated in the liver, gets in the gut
> - It’s unclear from these tracer studies if it’s getting into immune cells
> - [Nav Chandel](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=11123) tells Peter that he believes they are getting into immune cells as well
>
> **Peter’s question: if it’s working, which cells is it working on and how?**
>
> - In the liver, everybody gets big concentration of metformin shows up here
>
> **⇒** We understand that [metformin] reduces hepatic glucose output
>
> - After that, Peter don’t know how it works
>
> Steve Austad
>
> - We know it has a target in the [mitochondria complex I](https://en.wikipedia.org/wiki/Respiratory_complex_I#:~:text=Complex%20I%20is%20the%20first%20enzyme%20of%20the%20mitochondrial%20electron%20transport%20chain)
>
> Peter asks, “*But in which cells? (it’s not the muscle)*”
>
> - Steve agrees, that’s the question
> - We also know that it activates [AMPK](https://en.wikipedia.org/wiki/AMP-activated_protein_kinase)
>   - (Peter thinks those mechanisms are probably related)
>   - This is why [Nir](https://www.einsteinmed.edu/faculty/484/nir-barzilai/) points at to two of the hallmarks
> - Steve’s good friend, [George Martin](https://academic.oup.com/biomedgerontology/article/78/4/619/6968479) (who died a couple years ago) once went through and cataloged all the human diseases he could and tried to look at the similarities of their phenotypic changes relative to what happens with normal aging
>
> **⇒** He came up with diabetes as having the most similarities to accelerated aging of any of the groups that he looked at
>
> Peter Attia
>
> - That makes sense: they glycosylation, the hyper growth factors like insulin, IGF-1, all these things (there’s logic to that
>
> Rich Miller
>
> **Rich agrees with the emphasis on organ-specific and tissue-specific changes**
>
> > “*I think it’s about time to get away from what does metformin do to the body or any of these drugs for that matter? And start to think what does it do to each of the interesting players and how they talk to one another?*” ‒ Rich Miller
>
> - Someone in Rich’s lab has been looking at the enzymes related to de novo lipogenesis
> - She’s been looking at a couple of different kinds of slow aging mice
> - And it has major effects in the **liver** and it has major effects on **white and brown adipose tissue**
> - And they go in different directions
> - Which is primary, which is reactive, whether any of these are related to the effects of the mutations on the muscle or the brain is now an open question
>
> ***Having a diagram of hallmarks which are changed by a drug is much less useful than asking what specific changes in what cell types of which organs that talk to each other are being changed by this drug as a primary or as a secondary or as a compensatory effect***
>
> - That’s how you’ll start to get into first mechanisms, but also start to be able to think clearly about ways of targeting therapy so that it has a benefit with fewer and fewer side effects
>
> ## Canagliflozin and rapamycin as geroprotective molecules: mechanisms, dosing strategies, and longevity potential [2:10:45]
>
> Peter Attia
>
> - [Canagliflozin](https://en.wikipedia.org/wiki/Canagliflozin) reduces all-cause mortality in your mice in males, and we know exactly what canagliflozin does in the kidney and we know that those mice live longer
>
> **Do you believe that the longevity benefit came through glycemic control?**
>
> - Because there was no difference in weight, Peter recalls
>
> Rich Miller
>
> - Males and females lost weight on canagliflozin
>
> Peter asked, “*Was the difference in weight statistically significant between the long-lived males and the normal males?*”
>
> - The mice treated with the drug were lighter in weight than controls
>   - And that’s true of both sexes
>
> Peter asks, “*So the weight loss wasn’t necessarily explained.*”
>
> - They actually lost more weight in females than in males
>
> ***The question is very valid and we do not know the answer***
>
> - [SGLT2](https://en.wikipedia.org/wiki/Sodium/glucose_cotransporter_2) is on many other cell types and it’s quite possible, very plausible that canagliflozin had an effect principally through controlling **peak daily blood glucose**, not average but peak
> - And it’s also possible that it had effects on cells of unknown origin in the **brain**
>
> Rich explains, “*All of these are very valid and I don’t think anyone knows the answer. It’s well worth evaluating.*”
>
> - There are other inhibitors of [SGLT2](https://en.wikipedia.org/wiki/Sodium/glucose_cotransporter_2) and [SGLT1](https://en.wikipedia.org/wiki/Sodium/glucose_cotransporter_1) that have differential cell specificities and differential effects on different cell types
> - And looking at those would help give you glimpses into this question
> - We guessed it had to do with glucose, but we might be wrong
>
> **Metformin**
>
> Peter asks, “*What is your intuition, Steve? Going back to metformin?*”
>
> Steve Austad
>
> - Steve’s intuition is that it might work
> - He doesn’t have a strong opinion
> - There’s enough suggestive evidence that
> - He thinks it’s worth a trial
>
> > “*If we wait until we figure out exactly what each drug does in each cell type, it will take us forever to get any therapies.*”‒ Steve Austad
>
> - In medicine there have been many, many advances that came about before we understood the mechanistic underpinning
> - And if there’s enough suggestive evidence and there’s not a lot of side effects that suggest to me that it’s worth digging into now because the benefits are so enormous
> - As was mentioned earlier, one year healthy aging is worth $38 trillion ‒ that should talk to Congress if nothing else does
>
> Matt adds, “*I would also say TAME could be successful independent of whether metformin is effective at slowing biological aging necessarily.*”
>
> Steve asks, “*By getting others into the field you mean?*”
>
> Matt Kaeberlein
>
> - Even just hitting the end points
>
> **⇒** The end point is multimorbidity or comorbidity
>
> - It’s quite possible that the trial will be successful even if metformin is not an effective gerotherapeutic
> - It may not succeed for a variety of reasons that clinical trials don’t succeed
> - Matt sort of agrees with Steve: ***he’s supportive of doing the trial***
> - He also agrees with probably both Steve and Rich: ***it’s not the drug he would pick if we could only do one trial, but we have to start somewhere***
>
> **Why do you think that the ITP studies for rapamycin always worked regardless of start young, start old, give it with metformin, do it by itself (always worked); and the mice are taking rapamycin every day?**
>
> Matt Kaeberlein
>
> ***Because inhibiting*** [***mTOR***](https://en.wikipedia.org/wiki/MTOR) ***increases lifespan and slows aging***
>
> - You’re asking because most people who are using rapamycin off-label have moved to once weekly or some cycling like that
>
> *Current questions about rapamycin dosing*
>
> - 1 – Would that [dosing schedule] increase lifespan in mice as much or more than daily?
>   - We don’t effectively know the answer to that question
> - 2 – Intermittent dosing can increase lifespan, but it’s never been dose-optimized (this is the question)
>
> Peter asks, “*Is the metabolic rate of the mouse so fast that giving the mouse daily rapa is not the same as giving the human daily rapa?*”
>
> - Yes, and in the ITP study, rapa is given in the food, so it’s not a single dose
>   - They’re just chowing on it all day (at least during the period where they have access to food)
>
> Peter asks, “*Why did you guys decide, I guess in 2008 or 2007 when you did the first study, maybe it wasn’t clear, this idea of mTORC1 versus mTORC2 and the constitutive dosing.*”
>
> Matt Kaeberlein
>
> - Maybe we should ask how many people at this table actually believe that model?
>
> **Who believes that the bad side effects come from** [**mTORC2**](https://en.wikipedia.org/wiki/MTORC2) **off-target effects of rapamycin and all the good stuff comes from inhibiting** [**mTORC1**](https://en.wikipedia.org/wiki/MTORC1)**?**
>
> Rich Miller
>
> - Rich doesn’t know enough to say
> - Many of our slow aging mice actually mTOR complex 1 function is down in all of them
> - But mTOR complex 2 is often up and it’s up in an interesting way
> - Mice eat mostly at night and they more or less fast during the day
> - In our slow aging mice, mTOR complex 2 is elevated but it no longer responds in the fasting period, but it doesn’t respond to food in the same way
> - So there are complex changes in both its baseline state and its response to food
>
> ***Whether these would happen in people, would happen in people taking it every other day or every 5th day, whether they’re beneficial or harmful or a mixture, Rich really dosen’t know***
>
> *More unknowns*
>
> - The mTOR complex 2 story is trickier
> - The other Rich thinks is important but not really appreciated is that it not only do mTOR complex 1 drugs like rapamycin lower the overall effect, but it also changes the substrate specificity
>   - So that the [kinase](https://en.wikipedia.org/wiki/Ribosomal_s6_kinase) that is susceptible to TORC inhibition that looks at a ribosomal protein S6, that goes down, it doesn’t work nearly as well
>   - The kinase is inhibited for some unknown period of time
> - The other aspect of TOR downstream is on a protein called [4E-BP1](https://en.wikipedia.org/wiki/EIF4EBP1) that’s involved in translation
>   - It does not change that kinase
>   - What it does is it changes the total amount of the protein
>   - So the proportion of the protein that’s phosphorylated drops down, but the actual kinase that adds the phosphate to that substrate is unchanged
>   - So whether that’s important, that is having at least 2 different pathways that are being influenced in one case by changing the substrate and in the other case, by changing the kinase, no one’s really looked at that
> - They say it’s a drug that blocks mTORC kinase one function and downstream is where a lot of the action is
>
> Peter asks, “*Everything you just said, Rich, occurs in what cell?*”
>
> - Mouse liver
>
> Peter asks, “*What about muscle?*”
>
> - The overall decline in the ratio of phosphorylated versus substrate
> - Rich also [published](https://pmc.ncbi.nlm.nih.gov/articles/PMC8135077/) that (he thinks) in muscle and kidney
>   - He would have to go back to the papers and see whether they also found the elevation of the substrate 4E-BP1 in both of those tissues
>   - He vaguely recalls that it was the substrate that changed, not the kinase in those tissues as well (but he’d rather look it up)
>
> Matt Kaeberlein
>
> - What Rich is saying is really important and informative
>   - And only a tiny piece of all the downstream things that mTOR effects
>
> ***The point is we just really don’t have a good understanding of how rapamycin or fasting or other drugs that hit mTOR are affecting all of the things that are downstream of it***
>
> Rich Miller
>
> - Rich agrees completely
>
> *For example*
>
> - [Linda Partridge](https://profiles.ucl.ac.uk/9759-linda-partridge) just [published](https://www.biorxiv.org/content/10.1101/2024.07.25.605097v1) in BioArchive a nice paper: rapamycin increased lifespan of her mice if she added an inhibitor [[trametinib](https://en.wikipedia.org/wiki/Trametinib)] of a different kinase called [ERK](https://en.wikipedia.org/wiki/Extracellular_signal-regulated_kinases)
>   - It did better
>
> ***The inhibition by ERK worked by itself, but it actually improved on rapamycin***
>
> - Two people in Rich’s lab are looking at that, and it turns out that the ERK kinase inhibitor is working in an entirely different pathway
>
> **⇒** It’s affecting the proteome by increasing the degradation through a chaperon-mediate autophagy mechanism, which is not affected by rapamycin
>
> - At least at the dose they used
> - This was in mice [[C3B6F1 hybrid](https://www.jax.org/strain/100010)]
>   - Rich never uses [black 6 mice](https://www.jax.org/strain/000664)
>   - This was a [F1 hybrid](https://en.wikipedia.org/wiki/F1_hybrid), so it’s agreeing with and amplifying the question
>
> Rich explains, “*There may well be multiple cell-intrinsic pathways, some of which are TOR-dependent, some of which are map kinase, ERK-dependent, which can synergize as in the Partridge case for lifespan, but also potentially synergize for health impact*.”
>
> Matt Kaeberlein
>
> **An important limitation to what’s been done**
>
> - There are drugs out there that hit both types of kinases
> - There are drugs out there that are ATP-competitive inhibitors that have different affinities for different types of kinases
>   - Haven’t been tested for longevity, these dual kinase inhibitors
> - In [the resTORbio trial](https://pmc.ncbi.nlm.nih.gov/articles/PMC8102040/), the last one (the phase III, which did not get to completion), they substituted, they took the rapalog out and used an ATP-competitive drug
>
> **What is your belief (Matt) around dosing rapa in humans or even in your dogs?**
>
> Matt Kaeberlein
>
> - We’ve moved to dosing once a week
>
> *How that dosing evolved*
>
> - Most people using rapamycin off-label for potential health span effects and most doctors prescribing it are recommending once weekly dosing in the 3-6 mg, sometimes 8, 10 mg range
> - The first place Matt’s aware of in the literature where this was shown to have a potential benefit for anything related to aging was [Joan Mannick’s](https://www.tornado-tx.com/team) work when she was first at Novartis and then at rest resTORbio looking at flu vaccine response in elderly people
>   - [discussed in [episode #272](https://peterattiamd.com/davidsabatini-mattkaeberlein/)]
>   - They were using [everolimus](https://en.wikipedia.org/wiki/Everolimus) (a derivative of rapamycin) and they found that for vaccine response it was most effective and had the least side effects at once weekly dosing at 5 g
>   - They [tested](https://pubmed.ncbi.nlm.nih.gov/25540326/) daily 1, 2, or 5 mg once a week; or 20 mg weekly
> - Peter has had both [Lloyd Klickstein](https://www.linkedin.com/in/lloyd-klickstein-69b26870/) [[episode #118](https://peterattiamd.com/lloydklickstein/)] and [Joan Mannick](https://www.tornado-tx.com/team) [[episode #123](https://peterattiamd.com/joanmannick-nirbarzilai/)] on the podcast
>   - It’s been so long that he doesn’t recall if he asked them why they designed the trial with those 4 arms
> - It’s Matt’s understanding that Novartis had internal data at that point on side effects and had an internal hypothesis that if you let the trough levels bottom out, that reduced side effects
> - The side effects in organ transplant patients were largely driven by high troughs
> - Then after that they developed based off of [David Sabatini’s](https://www.davidsabatinilab.com/) work and then [Dudley Lamming](https://lamminglab.medicine.wisc.edu/dudley-lamming/) (after he left David’s lab), a hypothesis that chronic treatment with rapamycin, which maybe would be equivalent to daily dosing in people
>   - This was all done in cells
>   - Led to off-target effects on [mTOR complex 2](https://en.wikipedia.org/wiki/MTORC2) and it was mTOR complex 2 effects that were driving the side effects
> - That got sort of dogmatized as the truth
>
> ***Matt doesn’t think there’s a ton of evidence beyond those initial papers to support the idea that the side effects are all through mTOR complex 2***
>
> **⇒** The idea is if you dose once a week, you let the trough levels bottom out, you don’t get the off-target effects on mTOR complex 2, you avoid the side effects (again, we don’t have definitive data)
>
> - The data Matt has seen seemed consistent with that idea
> - People dosing daily seem to be more likely to have side effects
>   - Mostly things like bacterial infections or the really severe mouth sores, but anecdotal
> - Matt doesn’t know for sure how strong that data is in people
> - It did hold up in all of the resTORbio clinical trials that he’s aware of, that once weekly dosing really didn’t show any side effects different from placebo
>
> Steve asks, “*In the dog study, you’re using a slow release formulation?*”
>
> Matt Kaeberlein
>
> - It’s an enteric coated ‒ a different formulation that what the ITP uses
>   - But all of the human [sirolimus](https://en.wikipedia.org/wiki/Sirolimus) formulations have some way to get to the small intestine
>   - It’s not substantially different than Rapamune or the generic sirolimus you would get
>
> ## Resveratrol and NAD precursors—a lack of evidence for anti-aging effects [2:22:45]
>
> **Can we say anything positive about resveratrol?**
>
> Steve Austad and Rich Miller agree, “*No*.”
>
> Peter Attia
>
> - Why does this thing not die?
> - Why is there still a hundred different resveratrols being sold on Amazon?
> - Why do I still get people asking me, “*Do you take resveratrol? Should I be taking resveratrol?*”
>
> Matt Kaeberlein
>
> - I think it’s really hard to prove something doesn’t work
> - So once it gets in the consciousness as improving health, even in the longevity field
>
> > “*Jesus Christ, I was saying the resveratrol stuff was garbage for 10 years before people believed it. Now everybody believes it, but it takes a really long time*.”‒ Matt Kaeberlein
>
> - You never see people studying resveratrol in the aging field anymore
>   - If you went to a conference and asked scientists, “*What do you think about resveratrol?*” You’d get the same answer here with maybe one exception
> - It takes a really long time to change
>
> Peter adds, “*Bad ideas don’t die hard*.”
>
> - Matt agrees, and that’s true in the scientific literature
>   - Especially when there’s a profit motive to continue selling this stuff
> - Matt is not 100% convinced that there are no health benefits from resveratrol
>
> ***Matt is pretty convinced there’s no reason to believe it affects the biology of aging or is a longevity drug, but I can’t say for sure that nobody would ever benefit from any dose of resveratrol***
>
> - But we couldn’t say that about anything
>
> Peter asks, “*If you were force-fed the highest fat diet in the world such that your liver encroached on your lungs through your diaphragm, isn’t there a chance, Rich, that under that situation resveratrol might help?*”
>
> Rich Miller
>
> - Rich has no idea
> - The [famous experiment](https://pmc.ncbi.nlm.nih.gov/articles/PMC4990206/): resveratrol was the first drug ever found to extend mouse lifespan
>   - [discussed in [episode #281](https://peterattiamd.com/richardmiller2/#:~:text=2%20%E2%80%93%20Resveratrol%20was%20hyped%20for%20many%20years)]
>
> **⇒** It turns out that the mice die because they were on a 60% coconut oil diet
>
> - That diet is poisonous to the extent that it causes the liver to fill with fat and compresses the thorax so that they cannot inhale
> - Three or four papers later they published as an obscure paragraph and a discussion section on a paper
>   - [Pearson](https://medicine.uky.edu/users/kjpe222) was the first author of the second paper that, oh by the way, all these mice on the coconut oil diet, finally we’ve looked at them, they’re all dying because of lung compaction due to expansion of the liver
>
> ***The notion that their drug had slowed aging because on the 60% coconut oil diet, it temporarily extended lifespan was due to the prevention of this extremely bizarre phenomenon***
>
> **Let’s have a word on NAD, NR, NMN**
>
> *Steve, what is your point of view on this?*
>
> Steve Austad
>
> - Based on the current state of evidence, he’s skeptical
> - It’s one of those things that makes a great deal of conceptual sense, but the evidence at this point is not very compelling
> - We have the ITP evidence that is Steve thinks is the strongest and there was something there
>
> Rich Miller clarifies, “*Strongest negative evidence*.”
>
> - Steve agrees
>
> *Is it your view, Steve, that this stuff probably does not extend lifespan, but maybe there is some other healthspan benefit out there that has just not been studied?*
>
> ***Steve thinks*** [***NAD***](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide) ***is a very interesting molecule and manipulating NAD is something that could be important for aging – the evidence just isn’t there at this point***
>
> *Do you think if you’re going to manipulate it, you would have to do it with really, really high intravenous doses or do you think you could achieve those levels using oral precursors?*
>
> - Steve doesn’t know
>
> Matt Kaeberlein
>
> - The way Peter framed that question to Steve is indicative of why it’s so hard to disprove something
>   - Especially when there are people out there who have money to make, who really want to make the case that you should buy this stuff because it’s always possible that there’s some way that this could be beneficial
>
> **⇒** Having said that, NAD is a central molecule in thousands of chemical reactions (really important)
>
> - There is some reason to believe that NAD homeostasis declines with age like lots of many other things
> - So it’s plausible that if you fix that you can get benefits from it
>
> ***The data is decidedly mixed both in the literature, preclinical literature, and in people as to whether or not boosting NAD increases lifespan, improves healthspan***
>
> - There’s lots of issues
>
> *What is the most positive data you would point to?*
>
> - For lifespan: the original study by [Johan Auwerx’s](https://people.epfl.ch/johan.auwerx?lang=en) lab where they started treating at 20 months of age was published in *Science*
>   - Matt believes it showed an effect that was reasonably good-sized
>   - Except the controls were short-lived, which is a different issue
> - There’s a number of cases where something was reported to increase lifespan when the controls were short-lived, and then when the study was repeated and longer-lived controls, you didn’t see an effect
> - Matt doesn’t know why there was a difference between that study and the ITP, but that’s probably the best case you can point to
> - There’s studies in *C. elegan*s as well where NAD precursors increased lifespan
> - So there’s evidence out there, and again the biology’s plausible
>
> Matt explains, “*When you talk about the precursors, it’s even more complicated than maybe boosting NAD could slow aging because can you get the right doses in people?*”
>
> *Bioavailability*
>
> - Is there any difference between NMN, NR, niacin, and nicotinamide?
>
> **⇒** Data suggests when you take it orally it all gets broken down to niacin in the gut
>
> Matt asks, “*Why are people taking $70 NMN or NR?*”
>
> Matt Kaeberlein
>
> - Why are people selling it?
>   - Scientists selling it dodge that question
> - It’s complicated
>
> ***Personally, Matt doesn’t believe there is enough evidence to think that NAD precursors as they’re being marketed today are likely to benefit most people***
>
> - Some people, probably people who have conditions of dysregulated NAD could get a benefit
> - He doesn’t think there’s any difference between the various molecules that are being marketed right now
> - There’s at least one study in mice that giving NMN to aged mice causes kidney inflammation and potentially kidney pathology
>
> *Current questions*
>
> - Matt is not saying NMN is dangerous, but when you try to weigh the risk-reward, if it causes kidney pathology in aged mice at least at high doses, could it do the same thing in dogs or people?
>
> ***It bothers Matt particularly in the companion animal space that people are marketing NMN for people’s pets when they know that it might cause kidney disease in people’s dogs and cats***
>
> ## The potential of parabiosis and plasmapheresis to slow aging, the challenges in translating mouse studies to humans, and possible design for human studies [2:29:45]
>
> **Steve, is there going to be a day when the substance found in the blood of someone much younger than you when infused into you whilst some of your old blood is removed, is going to, assuming we figure out at what frequency that has to be done impact your life?**
>
> Steve Austad
>
> - Steve thinks this is an incredibly interesting question and it really deserves to be investigated in detail because if it’s true, it’s a real game changer
>   - Because we do transfusions; this is not exotic medicine
> - We very much need to know whether this works the same way in people
> - The evidence from mice is very, very compelling
>
> *Current question*
>
> - It would be nice to know how much of it is due to the young blood versus versus how much of it is getting rid of the old blood
>
> *If we could design the perfect experiments that would try to ask these questions*
>
> Peter Attia
>
> - Let’s start with an experiment of the full [parabiosis](https://en.wikipedia.org/wiki/Parabiosis) (both putting in and taking out)
> - If there was no benefit in humans
>
> *What would your best hypothesis be as to why it would’ve failed?*
>
> - Assuming it was statistically powered correctly and there was no methodologic error
> - If this was a biologic result, given how favorable this has been in mice, why would it not occur in humans?
>
> Steve Austad
>
> - The products that ended up in the circulation of humans are a very different nature than in mice
> - The number of things that differ between humans and mice and blood would be enormous
>   - So pinning it down would be [difficult]
>
> *There is reason to suspect that it may work*
>
> - It may not work in young people, but it may work in older people
> - There’s a lot of drugs that could affect aging that because young people haven’t aged as much, might not have minimal effect, but you give it to somebody that 50 years later might have a big effect
>
> Rich Miller
>
> - Rich finds himself frustrated by that question rather than by the answer
> - The reason people like parabiosis is that they’ve seen it in a sci-fi movie
>   - It sounds exactly like what you do in sci-fi, and their flashing lights and it’s so sexy and it’s just so great and you can take the blood of young virgins and give it to old people and they stand up and they can get on the road
> - But none of that is pertinent
>
> **What are the pertinent questions?**
>
> - 1 – Is there something that is in the blood of old people that it would be good to remove and if so, what is it?
> - 2 – Is there something (a cell, a molecule, a set of 3 molecules) that’s in the blood of young people (or mice) that would be good for you?
> - The only virtue of this parabiosis circus is to suggest that the answer might be yes, there might be something you could remove from old blood, a cell or some plasma molecule and there might be something good in the blood of young individuals
> - The challenge now is to find out what those things are and then you can do real-life science
> - Real-life science is not done by taking blood from young people and putting it into old people
>   - That’s medieval science where it’s a complex mixture of dozens of hundreds of potential…
>
> Peter Attia
>
> - But that could be the proof of principle
> - In other words, you might start with that: do that experiment where you literally take blood out of an old person and discard it and take blood out of a young person and put it in and you get a favorable result
>   - Nobody thinks that that’s what’s going to the FDA
>   - That is the proof of concept
>
> Rich Miller
>
> - The issue is what experiments would be worth
> - You have a limited amount of volunteers, doctors and money
>
> ***What experiments are most informative and in Rich’s view by far the most informative experiments are what is in the blood of young mice that is so good and what is in the blood of old mice?***
>
> Peter asks, “*Would you want to go on that fishing expedition until you at least saw a signal?*”
>
> - Yes
>
> Matt Kaeberlein
>
> - People are doing it: companies and basic research
>
> Rich Miller
>
> - That’s the only way you can turn your idea into science
>
> Steve Austad
>
> - Steve doesn’t know
> - On the other hand, if it has a positive effect, he doesn’t think it really matters
>   - That’s something to be investigated later
> - His thought is: it’s not simple
>   - It’s not one thing
>   - It’s not [GDF11](https://en.wikipedia.org/wiki/GDF11) for sure
>   - If it were simple, there’s enough people looking at it, they would’ve figured it out
> - Steve’s guess is it’s some combination
>
> Matt asks, “*Why can’t you do both?*”
>
> Matt Kaeberlein
>
> - Matt and Peter are saying the same: we would love to understand the mechanism, but we don’t have to understand the mechanism to figure out if it works in people
> - If it works, that’s  a win
> - Rich’s point is: we only have so much money, let’s spend it on figuring out the mechanism
>   - That’s a fundraising issue
>
> Rich Miller
>
> - It’s a scientific question
> - If you have a choice, the ITP loves to test individual chemical compounds, even sometimes ones where the mechanism of action is not known, and that’s very sensible
> - We are very dubious about: let’s take a little of this and a little of that, a little of that
> - We’re really dubious about: let’s grind up the asparagus
>   - Who knows what’s in it?
>   - Let’s see if it works
>
> Matt Kaeberlein
>
> - Matt agrees, but he bets the ITP has tested natural products where we have no clue what the mechanism is
> - Or even metformin: you pointed to [complex I inhibition](https://en.wikipedia.org/wiki/Respiratory_complex_I)
>   - Yeah, that’s one thing metformin does and it might activate AMP kinase mechanism, but we have no clue
>
> Rich Miller
>
> - Rich is not saying that we have to know them mechanism exactly of each drug
> - What he’s saying is that if you have a very complex mixture of hundreds of molecules and something happens, you don’t know what to do next because it could be any 1 or 2 or 8 or 10 of those and you haven’t really decided
> - You have trouble then with standardization, with mechanistic tests, and with transferring to a key species like some humans
>
> Steve Austad
>
> - We still wouldn’t be using anesthesia if we had to wait until we figured out how it worked
>
> Matt Kaeberlein
>
> - It doesn’t have to be parabiosis, it doesn’t have to be taking blood from young people and putting it into old people
> - There are other variants of this that can be done clinically and there’s some evidence to support things like therapeutic plasma exchange or things like that
>
> ***Matt thinks we should test it, and his gut feeling is, yeah, it probably will have some benefits in people***
>
> Peter asks, “*If you could only do one experiment, would you do a* [*plasmapheresis*](https://en.wikipedia.org/wiki/Plasmapheresis) *experiment? And if so, would you test? The simplest one is you literally just exchange old plasma for albumin. (That’s what they’re typically doing in these studies)*”
>
> Matt Kaeberlein
>
> - Yeah
> - First of all, Matt doresn’t know enough about this area to be confident in his answer
> - But yeah, that’s probably where he would look to start simply because it’s going to be logistically easier to do from a clinical trial perspective
>
> **So scientifically, the hypothesis is it’s the presence of something bad**
>
> - Matt thinks it’s both
>
> Peter Attia
>
> - That is worse than the absence of something good
> - The albumin is not going to give the young person whatever
>
> Steve Austad
>
> - That’s the problem with that experiment: we don’t know
> - If it’s young blood is good, old blood is bad or some combination
> - If we only did the plasmapheresis, we would only be testing part of that
>
> Matt Kaeberlein
>
> - Matt pushes back on that
> - He thinks we do have reason to believe it’s a combination of both
>   - There’s data in both directions
>   - There’s at least evidence to support that idea
>
> **You asked why might it fail in humans**
>
> - Matt thinks Steve’s answer is valid
> - It’s also worth mentioning, the parabiosis experiment itself shortens lifespan in rodents
>   - Just the fact that you’re surgically connecting these animals together
> - It may be that the benefit from true parabiosis in that context is somehow related to the shortening of lifespan due to the procedure
> - Matt doesn’t think that’s the case because there’s other lines of evidence that argue against that
>
> ***But there may be something about the procedure itself that is impacting the outcome ‒ that may be an alternative explanation for something that’s limiting in those mouse experiments***
>
> Steve Austad
>
> - That increases muscle repair and improves cardiac function
>
> Peter Attia
>
> - It seems like there’s not enough time and not enough money to do the work
> - Hopefully some of that’s changing
> - If we were to do another longevity round table next year, which is problematic because at this table, you guys are going to have to get awfully cozy
>
> **Any nominations for folks you’d want to invite to a longevity round table next time?**
>
> Steve Austad
>
> - It would be good to invite [Vadim Gladyshev](https://dms.hms.harvard.edu/people/vadim-gladyshev), he always has something interesting to say.
>   - Even though Steve disagrees with some of what he says
>
> Matt Kaeberlein
>
> - We would all agree, there are tons of great people in the field
> - Brian Kennedy is somebody who also thinks broadly and deeply about the science and is fantastic
> - It would be great to have some differing opinions
>   - We are more or less are aligned
>   - It’d be interesting to have some differing voices as well
> - [Morgan Levine](https://www.altoslabs.com/team/morgan-levine), she’d be really interesting to have because while she is an expert in epigenetics and biomarkers
>   - She takes a pretty clear eyed view of that space
>   - She’s at Altos Labs
>
> > “*I think in a year from now, I think there’s going to be a lot of new stuff*.”‒ Steve Austad

---

## Selected Links / Related Material

**Episode of** ***The Drive*** **with Steven Austad**: [#171 – Steve Austad, Ph.D.: The landscape of longevity science: making sense of caloric restriction, biomarkers of aging, and possible geroprotective molecules](https://peterattiamd.com/steveaustad/) (August 9, 2021)

**Episodes of** ***The Drive*** **with Matt Kaeberlein**:

- [#10 – Matt Kaeberlein, Ph.D.: rapamycin and dogs — man’s best friends? — living longer, healthier lives and turning back the clock on aging and age-related diseases](https://peterattiamd.com/mattkaeberlein/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (August 10, 2018) | [0:45]
- [#175 – Matt Kaeberlein, Ph.D.: The biology of aging, rapamycin, and other interventions that target the aging process](https://peterattiamd.com/mattkaeberlein2/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (August 10, 2020) | [0:45]
- [#207 – AMA #35: “Anti-Aging” Drugs — NAD+, metformin, & rapamycin](https://peterattiamd.com/ama35/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (August 10, 2020) [0:45]
- [#222 ‒ How nutrition impacts longevity | Matt Kaeberlein, Ph.D.](https://peterattiamd.com/preview-222-how-nutrition-impacts-longevity-matt-kaeberlein-ph-d/) (September 12, 2022)
- [#272 ‒ Rapamycin: potential longevity benefits, surge in popularity, unanswered questions, and more | David Sabatini, M.D., Ph.D. and Matt Kaeberlein, Ph.D.](https://peterattiamd.com/davidsabatini-mattkaeberlein/) (September 25, 2023)

**Episodes of** ***The Drive*** **with Richard Miller**:

- [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) (February 8, 2021)
- [#281 ‒ Longevity drugs, aging biomarkers, and updated findings from the Interventions Testing Program (ITP) | Rich Miller, M.D., Ph.D.](https://peterattiamd.com/richardmiller2/) (December 4, 2023)

\*\*\*

**Dog Aging Project**: [Dog Aging Project: Discovering the keys to a healthy lifespan](https://dogagingproject.org/) (2025) | [5:45]

**Cynthia Kenyon’s work on life extension in worms**: [A *C. elegans* mutant that lives twice as long as wild type](https://pubmed.ncbi.nlm.nih.gov/8247153/) | *Nature* (C Kenyon et al. 1993) | [8:45, 25:15, 39:30]

**Episode of** ***The Drive*** **with Saum Sutaria**: [#327 – Choices, costs, and challenges in US healthcare: insurance intricacies, drug pricing, economic impacts, and potential reforms | Saum Sutaria, M.D.](https://peterattiamd.com/saumsutaria/) (December 2, 2024) | [12:30]

**Epigenetic age tests Matt Kaeberlein compared**: [43:00]

- [TruDiagnostic TruAge Test](https://shop.trudiagnostic.com/products/truage-complete-epigenetic-collection) (2025)
- [Elysium Index Biological Age Test](https://www.elysiumhealth.com/products/index) (2025)
- [Tally Health TallyAge Test](https://tallyhealth.com/products/test-kit) (2025)

**12 hallmarks of aging**: [Hallmarks of aging: An expanding universe](https://pubmed.ncbi.nlm.nih.gov/36599349/) | *Cell* (C Lopez-Otin et al 2023) [49:00]

**Epigenetic algorithm DunedinPACE**: [DunedinPACE, a DNA methylation biomarker of the pace of aging](https://pmc.ncbi.nlm.nih.gov/articles/PMC8853656/) | *eLife* (D Belsky et al 2022) | [1:32:15]

**McKinsey Report on the yearly value of a healthy life expectancy in the US**: [Healthy Longevity](https://www.mckinsey.com/mhi/focus-areas/healthy-longevity) | McKinsey Health Institute (2025) [1:46:15]

**Depletion of p16 cells in mice**: [1:52:30]

- [Clearance of p16Ink4a-positive senescent cells delays ageing-associated disorders](https://pubmed.ncbi.nlm.nih.gov/22048312/) | *Nature* (D Baker et al 2011)
- [Naturally occurring p16(Ink4a)-positive cells shorten healthy lifespan](https://pubmed.ncbi.nlm.nih.gov/26840489/) | *Nature* (D Baker, et al. 2016)

**Episode of** ***The Drive*** **that did a journal club on the Banister paper**: [#270 ‒ Journal club with Andrew Huberman: metformin as a geroprotective drug, the power of belief, and how to read scientific papers](https://peterattiamd.com/andrewhuberman2/) (September 11, 2023) | [2:03:00]

**Banister paper on metformin**: [Can people with type 2 diabetes live longer than those without? A comparison of mortality in people initiated with metformin or sulphonylurea monotherapy and matched, non-diabetic controls](https://pubmed.ncbi.nlm.nih.gov/25041462/) | *Diabetes, Obesity & Metabolism* (C Bannister et al. 2014) | [2:03:00]

**Keys paper on metformin**: [Reassessing the evidence of a survival advantage in Type 2 diabetes treated with metformin compared with controls without diabetes: a retrospective cohort study](https://pubmed.ncbi.nlm.nih.gov/36287641/) | *International Journal of Epidemiology* (M Keys et al. 2022) | [2:03:15]

**Episode of** ***The Drive*** **with Nir Barzilai**: [#204 – Centenarians, metformin, and longevity | Nir Barzilai, M.D.](https://peterattiamd.com/nirbarzilai2/) (April 25, 2022) | [2:07:45]

**Rapamycin increased lifespan of mice when given with ERK inhibitor**: [A combination of the geroprotectors trametinib and rapamycin is more effective than either drug alone](https://www.biorxiv.org/content/10.1101/2024.07.25.605097v1) | bioRχiv preprint (L Gkioni et al 2024) | [2:18:30]

**resTORbio of Aging RCT**: [Targeting the biology of ageing with mTOR inhibitors to improve immune function in older adults: phase 2b and phase 3 randomised trials](https://pmc.ncbi.nlm.nih.gov/articles/PMC8102040/) | *Lancet Healthy Longevity* (J Mannick et al 20231) | [2:19:45]

**Joan Mannick’s blocked mTOR and looked at flu vaccine response in elderly**: [mTOR inhibition improves immune function in the elderly](https://pubmed.ncbi.nlm.nih.gov/25540326/) | *Science Translational Medicine*(J Mannick et al. 2014) | [2:20:45]

**Episode of** ***The Drive*** **with Lloyd Klickstein**: [#118 – Lloyd Klickstein, M.D., Ph.D.: Rapamycin, mTOR inhibition, and the biology of aging](https://peterattiamd.com/lloydklickstein/) (July 6, 2020) [2:21:15]

**Episode of *The Drive* with Joan**: [#123 – Joan Mannick, M.D. & Nir Barzilai, M.D.: Rapamycin and metformin—longevity, immune enhancement, and COVID-19](https://peterattiamd.com/joanmannick-nirbarzilai/) (August 10, 2020) [2:21:15]

**Famous mouse experiment with resveratrol**: [Resveratrol improves health and survival of mice on a high-calorie diet](https://pmc.ncbi.nlm.nih.gov/articles/PMC4990206/) | *Nature* (J Baur et al. 2016) | [2:25:00]

---

## People Mentioned

- [Cynthia Kenyon](https://profiles.ucsf.edu/cynthia.kenyon) (Professor Emeritus of Biochemistry and Biophysics at UCSF, characterized a [mutation](https://pubmed.ncbi.nlm.nih.gov/8247153/) in *C. elegans* that allowed them to double their lifespan) [8:45, 25:15]

- [Saum Sutaria](https://investor.tenethealth.com/governance/person-details/) (M.D. Chairman of the Board and Chief Executive Officer, Tenet Healthcare) [12:30]
- [Saul Villeda](https://villedalab.ucsf.edu/team) (Associate Professor of Anatomy, Endowed Chair in Biomedical Science, and associate Director of the Bakar Aging Research Institute at UCSF) [1:37:45]
- [Judith Campisi](https://en.wikipedia.org/wiki/Judith_Campisi) (1948-2024, Professor of Biogerontology at the Buck Institute for Research on Aging, expert in how senescent cells influence aging and cancer) [1:48:00]
- [Jan van Deursen](https://www.janvandeursen.net/) (Expert in age-related diseases, formerly at the Mayo Clinic) [1:52:45]
- [James Kirkland](https://researchers.cedars-sinai.edu/James.Kirkland/about) (Director, Center for Advanced Gerotherapeutics at Cedars Sinai) [1:52:45]
- [Darren Baker](https://www.mayo.edu/research/faculty/baker-darren-j-ph-d-m-s/bio-00027985) (Faculty at the Mayo Clinic, expert in the role of senescent cells in aging and cancer) [1:52:45]
- [Christian Bannister](https://www.linkedin.com/in/bannisterca/?originalSubdomain=uk) (Director of Computational Statistics at Cardiff University) [2:03:00]
- [Matthew Thomas Keys](https://portal.findresearcher.sdu.dk/en/persons/matthew-thomas-keys) (Research Assistant, Epidemiology, Biostatistics and Biodemography in the Department of Public Health at Syddansk Universitet, Denmark) [2:03:15]
- [Kaare Christensen](https://www.sdu.dk/en/forskning/dias/researchers/chairs/kaare-christensen) (Head of Research at the unit for Epidemiology, Biostatistics and Biodemography (EBB) in the Department of Public Health at Syddansk Universitet, Denmark) [2:03:45]
- [Nir Barzilai](https://www.einsteinmed.edu/faculty/484/nir-barzilai/) (Professor of Medicine, Genetics and Director, Institute for Aging Research at Albert Einstein College of Medicine) [2:07:45]
- [Navdeep Chandel](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=11123) (Professor of Medicine, Biochemistry and Molecular Genetics at Northwestern University) [2:08:45]
- [George Martin](https://academic.oup.com/biomedgerontology/article/78/4/619/6968479) (1927-2022, Professor of Laboratory Medicine & Pathology at the University of Washington, pioneer in aging research) [2:09:30]
- [Linda Partridge](https://profiles.ucl.ac.uk/9759-linda-partridge) (Professiorial Research Fellow of Genetics, Evolution & Environment and Director of the Institute of Healthy Aging at the University College of London) [2:18:30]
- [Lloyd Klickstein](https://www.linkedin.com/in/lloyd-klickstein-69b26870/) (President & CEO at Koslapp Therapeutics) [2:21:15]
- [Joan Mannick](https://www.tornado-tx.com/team) (Co-founder & CEO of Tornado Therapsutics, expert in mTOR and geosciences) [2:21:15]
- [David Sabatini](https://www.davidsabatinilab.com/) (expert in mTOR) [2:21:45]
- [Dudley Lamming](https://lamminglab.medicine.wisc.edu/dudley-lamming/) (Associate Professor in the Department of Medicine Division of Endocrinology, Diabetes and Metabolism in the School of Medicine and Public Health at the University of Wisconsin-Madison) [2:21:45]
- [Johan Auwers](https://people.epfl.ch/johan.auwerx?lang=en) (Full Professor, Laboratory of Integrative Systems Physiology, expert in mitochondrial health and aging) [2:28:00]
- [Vadim Gladyshev](https://dms.hms.harvard.edu/people/vadim-gladyshev) (Professor of Medicine at Harvard Medical School, expert in aging) [2:39:00]
- [Morgan Levine](https://www.altoslabs.com/team/morgan-levine) (VP of Computation at Altos Labs, former PI at the San Diego Institute of Science and Professor at Yale; expert in aging) [2:40:00]

---

#####

## **Steven Austad, Ph.D.**

Dr. Austad is a Distinguished Professor and Protective Life Endowed Chair in Healthy Aging Research of the Department of Biology, University of Alabama at Birmingham and Scientific Director of the American Federation for Aging Research. In addition, he directs the NIH-supported UAB Nathan Shock Center of Excellence in the Basic Biology of Aging, one of only six such Centers in the United States. He is also the Co-director of the Nathan Shock Centers Coordinating Center and serves on the Executive Committee of the National Institute on Aging’s Research Centers Collaborative Network.

Dr. Austad’s current research seeks to understand the underlying causes of aging with a long-term goal of developing medical interventions that slow the age-related decay in human health. Dr. Austad is the author of more than 200 scientific peer-reviewed publications covering nearly every aspect of aging from cells to societies. Dr. Austad is a fellow of the American Association for the Advancement of Science, and of the Gerontological Society of America. He has received multiple prestigious awards for his research work. [[UAB](https://www.uab.edu/icar/about/icar-leadership/steven-austad)]

Website: [Let’s Talk Science by Steven Austad](https://www.stevenaustad.com/)

X: [@StevenAustad](https://x.com/stevenaustad)

### **Matt Kaeberlein, Ph.D.**

Dr. Matt Kaeberlein is the Chief Executive Officer at Optispan, Inc., Affiliate Professor of Oral Health Sciences at the University of Washington, and Co-Director of the Dog Aging Project. Dr. Kaeberlein’s research interests are focused on understanding biological mechanisms of aging in order to facilitate translational interventions that promote healthspan and improve quality of life for people and companion animals. He is a Fellow of the American Association for the Advancement of Science (AAAS), the American Aging Association (AGE), and the Gerontological Society of America (GSA). Dr. Kaeberlein has published more than 250 scientific papers in the field of aging biology and has received several prestigious awards including young investigator awards from the Ellison Medical Foundation and the Alzheimer’s Association, the Vincent Cristofalo Rising Star in Aging Research Award, the Murdock Trust Award, the NIA Nathan W. Shock Award, and the Robert W. Kleemeier Award for outstanding research in the field of gerontology. Dr. Kaeberlein is the founding Director of the University of Washington Healthy Aging and Longevity Research Institute, former Director of the NIH Nathan Shock Center of Excellence in the Basic Biology of Aging and the Biological Mechanisms of Healthy Aging Training Program at the University of Washington, and former CEO and Chair of the American Aging Association.

X: [@mkaeberlein](https://x.com/mkaeberlein?lang=en)

### **Richard Miller, M.D., Ph.D.**

Richard A. Miller, M.D., Ph.D., is a Professor of Pathology, Associate Director of Research for the Geriatrics Center, and Director of the Paul F. Glenn Center for Biology of Aging Research at the University of Michigan.  He received the BA degree in 1971 from Haverford College, and MD and PhD degrees from Yale University in 1976-1977. After postdoctoral studies at Harvard and Sloan-Kettering, he began his faculty career at Boston University in 1982 and then moved to his current position at Michigan in 1990.

Dr. Miller has served in a variety of editorial and advisory positions on behalf of the American Federation for Aging Research and the National Institute on Aging, and served as one of the Editors-in-Chief of Aging Cell. He is the recipient of the Nathan Shock Award, the AlliedSignal Award, the Irving Wright Award, an award from the Glenn Foundation, and the Kleemeier Award for aging research. He has been a Senior Scholar of the Ellison Medical Foundation, and is a Fellow of the American Association for the Advancement of Science and a member of the American Association of Physicians. At Michigan, he directs the Paul Glenn Center for Aging Research.

His research program includes ongoing studies of the mechanisms that link stress, nutrients, and hormones to delay aging in mice, development of new approaches to slow aging and disease through drugs and targeted mutations, and studies of the ways in which cells from long-lived birds, rodents, and primates differ from those of short-lived species. [[RichMillerLab.com](http://richmillerlab.com)]Website: [RichMillerLab.com](https://www.richmillerlab.com/)