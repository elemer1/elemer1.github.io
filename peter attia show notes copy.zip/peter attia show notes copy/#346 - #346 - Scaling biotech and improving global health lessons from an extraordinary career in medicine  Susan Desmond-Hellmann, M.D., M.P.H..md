# #346 ‒ Scaling biotech and improving global health: lessons from an extraordinary career in medicine | Susan Desmond-Hellmann, M.D., M.P.H.

**Source:** [https://peterattiamd.com/susandesmondhellmann/](https://peterattiamd.com/susandesmondhellmann/)

---

Susan Desmond-Hellmann is a physician and scientist whose remarkable career has spanned clinical medicine, oncology, biotech innovation, and global health leadership. In this episode, Susan shares insights from her journey training in internal medicine during the early AIDS crisis, treating HIV-related cancers in Uganda, and developing groundbreaking cancer therapies like Herceptin and Avastin. She reflects on her leadership roles at UCSF and the Bill and Melinda Gates Foundation, offering lessons on guiding large-scale health initiatives, navigating uncertainty, and fostering scientific innovation. The conversation explores the promise of precision medicine, the integration of patient care and policy, and the evolving role of artificial intelligence in transforming diagnostics, drug development, and global access to care.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/susandesmondhellmann/the_Drive_public.png)

Play

#346 - Scaling biotech and improving global health: lessons from an extraordinary career in medicine | Susan Desmond-Hellmann, M.D., M.P.H.

#346 - Scaling biotech and improving global health: lessons from an extraordinary career in medicine | Susan Desmond-Hellmann, M.D., M.P.H.

1x15s30s

0:002:05:50

## We discuss:

- Susan’s medical training, the start of the AIDS epidemic, and the transformative experiences that shaped her career [3:00];
- Susan’s experience working on the frontlines of the HIV/AIDS crisis in Uganda [12:30];
- Susan’s time working in general oncology and her transition to biotech where she helped develop taxol—a top-selling cancer drug [26:30];
- Genentech’s origins, and its groundbreaking use of recombinant DNA to develop biologic drugs [33:45];
- Susan’s move to Genentech, and her pivotal role in the development and success of Herceptin as a groundbreaking therapy in targeted oncology [44:00];
- The rise of antibody-based cancer therapies: the development of Rituxan and Avastin [52:15];
- The step-by-step drug development process and the scientific and strategic challenges involved [1:01:30];
- The ethical and economic controversy surrounding Avastin’s high cost and limited survival benefit [1:12:30];
- Susan’s tenure as chancellor at UCSF: leading during a financially strained period, and her strategic approach to fundraising and institutional development [1:14:45];
- What Susan learned as CEO of the Bill and Melinda Gates Foundation: strategic processes and decision-making frameworks [1:26:00];
- Susan’s philosophy of leadership and how she sought to build an empowering, values-driven culture at the Gates Foundation [1:35:15];
- The erosion of public trust in science during COVID, the communication failures around controversial treatments like ivermectin, and the need for better public health engagement and transparency [1:39:30];
- The role of AI in transforming medicine: from drug development to cancer detection and beyond [1:53:00]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dr. Susan Desmond-Hellmann is a physician who is board certified in internal medicine and medical oncology
- Her impressive career has spanned multiple fields
  - She has been a leader in the pharmaceutical industry, where she helped develop several groundbreaking drugs
  - Worked as the chancellor of the health science campus of UCSF
  - Served as the CEO of the Bill and Melinda Gates Foundation
  - She also served on numerous boards of corporations and non-profit organizations
  - She co-chaired the National Academy of Science committee that pioneered precision medicine
  - She currently sits on the board of OpenAI
- Peter wanted to have Susan on this podcast to speak about her extraordinary career, spanning medicine, oncology, biotech, and global health leadership
  - To explore her knowledge on how scientific innovation and leadership can drive better healthcare outcomes
- In this episode, we discuss her early day in medicine
  - Training at UCSF during the start of the AIDS crisis (before people even knew what it was)
  - The lessons she learned on handling uncertainty, balancing health messaging, and accelerating treatment breakthroughs
  - The decision that she made to specialize in oncology and how her time treating HIV-related cancer in Uganda reinforced the need for integrating epidemiology patient care and policy to combat global health crises
- We speak about her transition into biotech, helping to develop cancer drugs like Taxol, Herceptin, and Avastin
  - And the role of precision medicine in improving outcomes
- Susan talks about her leadership roles at UCSF and at The Gates Foundation driving innovation in healthcare and global health
  - The lessons learned from leading health research institutions and global health initiatives
    - Balancing financial constraints with scientific progress
    - Building culture
- We end this discussion with a perspective on the future of medicine
  - Including AI’s role in healthcare ‒ the opportunities and challenges for leveraging AI for drug development, diagnostics, and expanding access to high quality care

## Susan’s medical training, the start of the AIDS epidemic, and the transformative experiences that shaped her career [3:00]

- Susan grew up in Reno, NV
  - Went to Catholic school for 12 years
  - Attended the University of Nevada, both to undergrad and and to medical school
- Her dream residency was internal medicine at UCSF and she got her first pick (that was in 1982)

**Remind me where we were in the AIDS epidemic in San Francisco in ’82. What was known?**

- The first indication of AIDS was in [MMWR in 1981](https://www.cdc.gov/mmwr/preview/mmwrhtml/mm5021a1.htm)
- In 1982, we knew something was happening, especially to gay men
  - There was a sense it was homosexuals, hemophiliacs, and Haitians (the 3 H’s)
- There was so much mystery still involved that Susan and her colleagues were in a study to look at drawing their blood to see if they had been infected as a result of treating patients

*What were they presenting with at the time?*

- It’s hard for anyone of Peter’s generation to imagine, having never seen a drug-naive patient
- These men would present with [*Pneumocystis carinii*](https://en.wikipedia.org/wiki/Pneumocystis_jirovecii)[pneumonia](https://en.wikipedia.org/wiki/Pneumocystis_pneumonia)
  - This was unusual because it was a disease that immunosuppressed patients could get very rarely
  - Most clinicians had never seen it before
- What was also clear is that there were many other infections that were not as obvious or life-threatening as pneumocystis was when we saw it right away

What was interesting from an outpatient perspective was [Kaposi’s sarcoma](https://en.wikipedia.org/wiki/Kaposi%27s_sarcoma)

- Kaposi’s sarcoma is a really unusual purple-colored tumor, very visible externally
- It caused nodules
- In patients with HIV infection, it also caused internal organ involvement
- Patients would cough up blood or they would vomit blood
- What was really sad and difficult is the combination of [cachexia](https://en.wikipedia.org/wiki/Cachexia) and Kaposi’s sarcoma meant that everybody knew you had AIDS (you sort of wore it)
- What was interesting for Susan was that this old-fashioned Kaposi’s sarcoma was fundamentally different than what we were seeing
- Kaposi’s sarcoma was a very big problem in San Francisco
  - It was very common in gay men, and it was common in the population we saw
- We also saw a non-Hodgkin’s lymphoma in numbers much smaller

*Was there ever a sense of fear among the medical staff that we don’t know what this is, we don’t know how it’s transmitted, and therefore we don’t know how to protect each other or ourselves or other patients for that matter?*

- It’s hard for Peter to imagine given how much we take for granted today
- Susan thinks it’s probably a reflection of her personality and wish to be a physician that her memories of those days are much more about sadness about her patients
  - About people her age dying

A story that brings it to life

- Many patients started selling their life insurance because they were sure they wouldn’t live long enough and they wanted the money now
- Then when the antiretroviral therapy came along, they wished they hadn’t
- Susan was just really sad

Fears about contagion

- There were fears about the residents and about contagion
- But in San Francisco there was such a wish to help the patients, and such a good spirit about playing a role in helping, that we all persevered
- For the first patients Susan took care of in the hospital (in 1982), she was gowned, gloved, masked, and had a cap on
  - It was like going into an operating room

**You finished your residency in internal medicine. Did you go directly into your fellowship?**

- Susan did a chief residency at the university hospital for 1 year
- That was the first time she knew she really liked managing
  - She liked interacting with people and helping people succeed
- After that year, she went to an oncology fellowship

Susan adds, “*To this day I love oncology. If you love medicine, and I do, and you love patients, and I do, it’s the combination of you get to call on your compassion gene and your nerdy science gene*.”

- When she was at the VA in Reno as a third year medical student, she had an attending (Stephen Hall), and he was the oncologist who was teaching her about medicine
  - She loved everything about how he showed up
  - She loved his compassion, his intellect
  - After that, she had this bug in her mind, she wanted to be like him
- Peter can relate, when he was in his third year of medical school, he went to NCI for 3 months with [Steve Rosenberg](https://ccr.cancer.gov/staff-directory/steven-a-rosenberg)
  - It was the exact same experience
  - He remembers learning many lessons from Steve
  - One of them was about cancer diagnosis
    - Of course at the NCI, nobody’s showing up with [stage I, II, or III cancer](https://en.wikipedia.org/wiki/Cancer_staging#Overall_stage_grouping)
  - By definition, every patient there is showing up with metastatic cancer, and they’ve progressed through all standard treatments
    - These are people that have 6 months to live
    - Maybe you can achieve a durable remission for 10% of them
  - He said, “*Look, cancer will do one of two things to a family. It will take a strong family and bring them much closer together, it will take a fractured family and blow them wide apart. As a doctor, as a nurse, as an anybody in the field of oncology, your ability to kind of be there for that family is as important, potentially more important, than it is in any other specialty of medicine.*”
  - [Steve was the guest in [episode #177](https://peterattiamd.com/stevenrosenberg/)]

**Tell me a little bit about the state of oncology in the mid-eighties when you’re embarking on your medical oncology fellowship**

*Help people understand what the world of cancer looked like roughly 40 years ago*

Breast cancer is a good example

- The common therapy that was used were very old, decades old: [Cytoxan](https://en.wikipedia.org/wiki/Cyclophosphamide), [Methotrexate](https://en.wikipedia.org/wiki/Methotrexate), [5-FU](https://en.wikipedia.org/wiki/Fluorouracil)
- There were no new chemotherapy drugs, and hadn’t been in a while
- The field was stifled; there wasn’t a lot going on
- Susan was really interested in cancer epidemiology
  - Asking the question: Why did people get cancer and couldn’t we do something about it?
- In the second year of her fellowship, she wanted to study the relationship between [Hepatitis B](https://en.wikipedia.org/wiki/Hepatitis_B) and [hepatocellular carcinoma](https://en.wikipedia.org/wiki/Hepatocellular_carcinoma)
  - To understand the viral link with cancer
- The mentor she was supposed to work with ended up not coming to San Francisco, so she decided to go to Berkeley and get a Master’s in Public Health
  - She really scrambled because she didn’t want to waste a year

**What was the nature of the program? It was a 3-year fellowship with a research track on the side**

- UCSF was a very academic place
- You could do 2 or 3 years, and many people went into the lab
- Susan didn’t want to go into the lab, she wanted to learn more about statistics and epidemiology
- She thought she wanted to be a cancer epidemiologist
  - To this day, she still thinks that is one of the great opportunities to make a big impact,

> “*I’m a pragmatist. The good news was that all that learning at Berkeley and at UCSF in epi and biostat I brought to drug development. Clinical trials have a lot in common with doing epidemiology*.”‒ Susan Desmond-Hellmann

**You brought up Hep B and hepatocellular carcinoma, was it understood at the time what we know now?**

- It was, yeah
- [Palmer Beasley](https://en.wikipedia.org/wiki/R._Palmer_Beasley), one of the fathers of that relationship, was the guy who was supposed to come [to UCSF]
- There were preliminary papers, and something relatively early, but it was emerging science

*Do you recall what the incidence of Hep B was and Hep C back then?*

- She doesn’t
- If you weren’t in Asia, she thinks it was relatively low
  - But increasing, which is partly why the vaccines are so important

## Susan’s experience working on the frontlines of the HIV/AIDS crisis in Uganda [12:30]

**Tell me how you wound up in Uganda**

- After she got her Master’s in Public Health, she became the oncologist at UCSF in the university hospital (Moffett) for the AIDS clinic
  - San Francisco General had a very well-known program run by oncologists for AIDS patients who were in the safety net hospital
- In the university hospital, if you were very sick and you had Kaposi’s sarcoma, you saw Susan
- Susan had just gotten married, and her [husband](https://people.equilar.com/bio/nicholas-hellmann-monogram-biosciences/197658) was also an intern
  - He was in the lab, in ID, doing immunology work
- Two of the chiefs of medicine at UCSF were approached by The Rockefeller Foundation who had started to become worried about heterosexual transmission of HIV
  - Remember Susan talked about the Haitians and the hemophiliacs and homosexuals?
  - One H wasn’t heterosexual
- There was a lot of disbelief about African HIV
  - Some people thought it must be gay sex, but people are too embarrassed to admit it
  - There were other theories, but people just did not understand what was going on in Africa
- The Rockefeller Foundation gave UCSF a grant to study heterosexual transmission of HIV

Peter asks, “*This was through an epidemiologic contact tracing lens, not necessarily going into the lab and trying to figure this out?*”

- Not going to the lab, but really looking at epi
- Particularly, there was a hypothesis that if it was heterosexually transmitted, there was something to do with sexually transmitted diseases, and that there was something about increasing your risk if you had untreated STDs (sexually transmitted diseases)
- UCSF had no global health
- Susan and her husband were asked to go to Uganda
  - They sublet their flat, sold their cars, gave her dad power of attorney, and moved
- Susan is laughing in part because she had never been east of Chicago ‒ this was a pretty dramatic thing to do
- On the positive side, there was some infrastructure there
  - The NCI had set up a collaboration with the [Uganda Cancer Institute](https://uci.or.ug/), where they did some really great things in lymphoma and Burkitt’s lymphoma
  - One of the physicians at UCSF ([John Ziegler](https://globalcancer.ucsf.edu/people/john-ziegler)) had associated with that
  - There was a connection to the Uganda Cancer Institute, and there also was (and is) the [Entebbe Viral Institute](https://www.uvri.go.ug/)
- Unfortunately, most of that infrastructure had been ruined by the [Idi Amin](https://en.wikipedia.org/wiki/Idi_Amin) regime not long before they went to Uganda
- When they went there, it was pretty lawless
  - There were roadblocks you had to stop there
  - It was really difficult to live there
  - It was probably not smart the way they lived there, but they weren’t reckless
  - It seemed dangerous when you were in the car to have a carjacking or your money go missing or things like that

Peter asks, “*Was Idi Amin still ruler?*”

- No, he was gone when they were there
- He made that attempt to come back from Saudi Arabia and go back to Uganda, but it was thwarted
- Susan’s husband Nick reestablished the sexually transmitted disease clinic and attended in the internal medicine ward

> “*I like to say I doubled the population of oncologists in Uganda when I was there*.”‒ Susan Desmond-Hellmann

- Her colleague [Edward Mbidde](https://en.wikipedia.org/wiki/Edward_Katongole-Mbidde) (who’s Ugandan) put all his focus on the pediatric unit, and she put all her focus on the adult unit
  - Which was so many cases of Kaposi’s sarcoma
- This is ‘89, ‘90, ‘91
- [AZT](https://en.wikipedia.org/wiki/Zidovudine) is not out yet (just on the brink) [there’s no treatment for AIDS yet]

**What is the approximate conversion? For a patient who develops AIDS, what fraction of those will go on to develop KS?**

- It’s hard to give those numbers, but about a third of patients who sought medical attention probably had [KS](https://en.wikipedia.org/wiki/Kaposi%27s_sarcoma)

**What was the prevalence of HIV AIDS in the population in Uganda?**

- Depending on the population you treated, it was double digits in the country as a whole
- If you were a 16-year-old girl and you went to the STD clinic, you had a 50% chance of being HIV positive
  - Most of those girls, it was their first and only sexual partner
  - It was Russian roulette to have sex in Uganda then
    - Worse, Russian roulette is 1 in 6; this is brutal
- The best business in town was the coffin maker
- The feeling of being scared and sad in San Francisco in 1982, multiply that by 1,000 in 1989
  - It was terrifying
- If we hadn’t gotten [ARVs](https://en.wikipedia.org/wiki/HIV/AIDS#Antiviral_therapy), this was killing people
- The first time they went back to San Francisco from Uganda was 6 months after they had left
- Susan went back to the Kaposi’s sarcoma clinic she had led she remembers telling a nurse there about all the great patients she cared for
  - They were all dead in 6 months

Susan explains, “*The sense of how bad HIV was before antiretrovirals, it’s impossible to overstate it. Just impossible. When we were in Uganda, it was really clear that you could see someone’s immune status with a good physical exam if they had Kaposi’s sarcoma.*”

- Susan wrote a [paper](https://pubmed.ncbi.nlm.nih.gov/2051304/), a good paper if you do global health and have limited resources
  - It had one observation: if you had Kaposi’s sarcoma on your soft palate (on the roof of your mouth), you had HIV
  - 100% predictive
- For Kaposi’s sarcoma, there’s a Mediterranean form and an African form
  - It happens on your skin, it can cause elephantiasis
  - But it doesn’t go in the mouth
    - It’s just a surrogate for your GI tract
    - It doesn’t happen unless you’re immunosuppressed with HIV

Peter asks, “*These patients weren’t necessarily dying from the KS directly. That’s a proxy for how weak their immune system was. I assume they were ultimately dying from a pneumonia?*”

- Many would die from pneumonia
- There was severe cachexia, and then they were prone to pneumonia and other problems
- Kaposi’s sarcoma in the lungs or the stomach can also cause bleeding, and you can die from that

**What did you know at this point in time about HIV?**

*Because the virus had been identified by this point. What was known and what was unknown?*

- We knew most of the clinical syndromes associated with HIV
- [Bob Gallo](https://en.wikipedia.org/wiki/Robert_Gallo) and [Luc Montagnier](https://en.wikipedia.org/wiki/Luc_Montagnier) had a fight over who deserved credit [for identification of HIV as the cause of AIDS]
- We knew about HIV then, and we knew the biology, and we knew as soon as we got to Uganda and examined patients that this was heterosexual transmission of HIV
  - We knew that untreated STDs were a big reason, and that was a very important thing

**Going back to these 16-year-old girls, is the reason that the heterosexual transmission was so high because the viral loads were through the roof?**

- Peter reasons that today, if a male with HIV had unprotected sex with a female, it would not be that high
- It wouldn’t be that high; no
- One of the really important aspects of STDs is the high frequency of [herpes](https://en.wikipedia.org/wiki/Genital_herpes) and [chancroid](https://en.wikipedia.org/wiki/Chancroid), really open lesions that if not treated
  - It’s a one, two punch: high viral load and transmissible open lesions
- We also knew that some of these were treatable, that both medication, also [Museveni](https://en.wikipedia.org/wiki/Yoweri_Museveni) (the still leader of Uganda) had this very funny campaign called “Zero Grazing”
  - It meant: 1 wife, 1 partner, no grazing
  - It was very important in Uganda to have a herd of cows, it means you’re an important man
  - There was a pretty good public campaign
  - We did a lot of condom distribution
- The government was receptive to this and understood the epidemiology
- They also knew that this was going to be a geopolitical problem for them if people were dying in the prime of their lives at the rates they were

Peter asks, “*What other countries in Africa were afflicted to this extent?*”

- East Africa, Kenya, Tanzania
- There were others where it was more unknown, not talked about
- The program Susan knows about most is the program her husband has been working with for 15 years: [Elizabeth Glaser Pediatric AIDS Foundation](https://pedaids.org/)
  - They work in 12 countries in Sub-Saharan Africa
- Many of the southernmost countries are heavily affected by HIV still

**Can you estimate in a year how many people died from AIDS in Uganda when you were there?**

- No
- It’s a staggering number

Susan estimates, “*If there’s 16 million people, it wouldn’t have surprised me if there were a million people who died.*”

- The sense of feeling overwhelmed is really important
- If you’ve interacted with people in the military, if they were on the battlefield, they triaged
- Susan triaged in San Francisco
  - If you didn’t need chemotherapy, but you had Kaposi’s sarcoma, she didn’t see you

**What was the chemo used to treat Kaposi’s sarcoma?**

- The simple one was [vincristine](https://en.wikipedia.org/wiki/Vincristine), and it worked reasonably good against KS
  - She used it in Uganda a lot
  - It does cause some neuropathy
- [Bleomycin](https://en.wikipedia.org/wiki/Bleomycin), again you have to be careful because of the pulmonary toxicity
- [Taxol](https://en.wikipedia.org/wiki/Paclitaxel) was approved for KS after Susan left Uganda
  - It wasn’t a drug before then
- When Susan would see the patient she would literally ask, “*Can you walk?*”
  - If yes, they were too healthy and she would delay
- There was triage because she only had on the shelf a certain amount of chemotherapy

**How did you manage the personal toll of the grief and the death of seeing this?**

- Peter imagines every doctor goes through this to some extent
  - Where you try to compartmentalize what you’re seeing
  - But the truth of the matter is virtually no doctor can really comprehend what you are describing there

> “*I have this philosophy (which I don’t recommend it for others)… I love getting to know the patients who I care for. It makes me happy to think I’m helping.*”‒ Susan Desmond-Hellmann

- Helping might be helping them get better
- Helping might be helping with their pain, or they can talk about dying with me because it doesn’t make me scared
- Susan gets a lot of joy in trying to contribute, even if she feels overwhelmed

***Her coping is leaning in***

**Does your husband share that? Was there a yin and a yang to the relationship where you supported each other in a way that was helpful in that?**

- Peter understands that there is a joy that comes from helping people
- But there are moments (at least for him personally) when it breaks down and you feel so overwhelmed by sadness
- Susan’s husband is more introverted and probably gets more sad
- They are a good team because they are there for each other
  - It’s a special thing done in small amounts, to be able to come home and say, “*Boy, that was tough. Here’s what I dealt with today,*”
- The other thing which is important is even though Susan derives a lot of joy in trying to help, she’s not a martyr
  - She doesn’t believe in: you worked hard, I worked harder
    - Or you suffered, I suffered more
  - She hates that
- Susan and her husband went to Greece ‒ they still laugh about eating their way through Greece for a week
- They had a couple other good trips
- They went on a hilarious safari and saw hippos and elephants (a grand adventure)
- They played tennis and enjoyed friends
- They did as much to keep their spirits up as one can

## Susan’s time working in general oncology and her transition to biotech where she helped develop taxol—a top-selling cancer drug [26:30]

**You came back to the US after about three years. Did you go back to UCSF?**

- They wanted to go back to UCSF but had not kept their academic careers going as much as they should have
  - They didn’t publish enough
- UCSF didn’t have a global health program or money for them

Peter asks, “*Taking care of a million people with HIV wasn’t enough to justify coming back to UCSF?*”

- It wasn’t
- When the chief of medicine outlined for them the plan to stay, a large part of it was taking care of patients to pay their way
- They went into private practice in Kentucky where Nick is from
- Susan was in a 2-person oncology practice with a former classmate of Nick’s in Lexington, KY
  - She was doing old-fashioned American oncology
  - Not necessarily focusing on HIV/AIDS related cancer
- She didn’t take her oncology boards when they went to Uganda because they were in Uganda
- She laughs about reading the big [DeVita, Hellman, Rosenberg oncology book](https://shop.lww.com/DeVita--Hellman--and-Rosenberg-s-Cancer/p/9781975184742?srsltid=AfmBOoqFDOB312F0CSO_wyqXQFIpVqaVp2NIUd_r14CBZyypnO73ZZmR) twice
- She took the boards and did fine

**What was it like to practice garden variety oncology in Kentucky?**

- It was so, so different
- Nick was in a practice where he was more like a hospitalist
  - Somebody’d get a fever in the ICU and they’d call that ID group
- Susan’s practice was a 2-person practice ‒ it was very classy
- She saw a lot of lung cancer
  - There’s a lot of smoking, a lot of people from Appalachia
- She likes taking care of patients, so that part she liked
- She really missed intellectual research, collegial stuff she was used to at UCSF
  - She had been at UCSF for 9 years by that time ‒ they were still UCSF faculty when they were in Uganda
- Nick was called about a [Bristol-Myers Squibb](https://www.bms.com/) search for an expert on HIV, because they were trying to follow AZT with the next antiretroviral
  - [DDI](https://en.wikipedia.org/wiki/Didanosine) and [d4T](https://en.wikipedia.org/wiki/Stavudine) were both in development then
  - They recruited Nick to come and work at Bristol Myers Squibb out of private practice
- He told them he wouldn’t come unless they had a job for his wife
  - They said, “*No, we have a nepotism clause. We don’t allow couples to work at Bristol Myers Squibb.*”
  - He declined the job, and it’s one of their favorite stories because it’s a true story
  - They called him back and asked if his wife could be a consultant and not a full-time employee
  - Then he agreed
- They moved to Connecticut
- Bristol Myers Squibb put her on drug safety for [Taxol](https://en.wikipedia.org/wiki/Paclitaxel)

Peter asks, “*But did they not understand what you had spent the last couple of years doing prior to being in Kentucky? Did they not know what you had done in Uganda?*”

- Susan doesn’t think that registered because there were so many people there who were traditionally trained in oncology at NCI or Yale or wherever
- Her experience in Kampala in Uganda didn’t make an impact

What’s funny about their experience in Uganda

- They didn’t have a statistician, just the 2 of them went
- They brought this little compact computer and all the SAS manuals
  - They  didn’t have a TV, didn’t have newspapers, didn’t have anything
  - They taught themselves how to do SAS programming
- When Susan got to Bristol Myers Squibb, one of the really interesting things about Taxol is it causes severe [neutropenia](https://en.wikipedia.org/wiki/Neutropenia), but it’s short
- Susan wanted to study that because she thought it was really important in why people weren’t really getting infections

**Tell people what Taxol is, how it works**

*What is neutropenia? Why would we care?*

- Taxol was one of the first new chemotherapy drugs
- [Taxol](https://en.wikipedia.org/wiki/Paclitaxel) is a product of the [yew tree](https://en.wikipedia.org/wiki/Taxus_brevifolia), and it’s a [microtubule poison](https://en.wikipedia.org/wiki/Paclitaxel#Mechanism_of_action)
- If you think about it coming from the yew tree and you think about sap, think about trying to dissolve sap in water and give that to a patient ‒ that’s hard
  - The dissolving agents are like soap
- The reason you would give somebody with cancer a microtubule inhibitor is because that prevents cells from dividing

***Taxol was a good way to block cellular division, and it’s really important because it’s very different than some of the old chemotherapy drugs ‒ if you’re resistant to those old drugs, here you have a brand new mechanism of action***

- Back to the dissolving agents used for Taxol, when the National Cancer Institute tried to use it, some patients got severe allergic reactions from that
- They got scared and put it on the shelf
- Bristol Myers Squibb went to the National Cancer Institute and wanted to take the drug back into the clinic and test it and give people agents to counterbalance the allergic reactions
- They did that and they got an approval in ovarian cancer, a brand new agent

***Taxol was really exciting because it was used to treat first ovarian and then breast cancer, and these were indications where we had not had new drugs (or really any drugs that were active in the case of ovarian cancer) for a long time***

- As the safety person, Susan was trying to understand and put into context all these safety issues so it was possible to safely treat patients with these drugs
- It had already been approved for ovarian cancer when she showed up
- She was doing post-market surveillance on ovarian and putting together a US submission and a European submission for breast cancer
- She started talking to the statisticians there about how she wanted them to program to get the data we needed for the safety label
  - She’ll never forget the guy looking at me and saying, “*Do you know how to do this?*”
  - She said, “*Well, I had to learn in Uganda. I didn’t have somebody like you*.”
- She was very happy to prove herself; it didn’t bug her
  - It made her fore feisty, like, I’ll show you
- She loved every minute of being at Bristol Myers Squibb ‒ they were pros at cancer drug development, at monitoring safety
  - She thought it was so much fun because you got to make drugs

**What was the pharma landscape like in the early ’90s?**

- You had Bristol Myers, Pfizer, Merk, Novartis
  - Novartis was much smaller
- In cancer was Briston Myers Squibb ‒ they had made [cisplatin](https://en.wikipedia.org/wiki/Cisplatin) and [carboplatin](https://en.wikipedia.org/wiki/Carboplatin)
  - They had a lot of those drugs, and people who had made those drugs were still there
  - Susan was really happy to learn from them
- They got Taxol approved in the U.S. and in Europe for breast cancer, and it became Bristol Myers Squibb’s #1 drug
- Susan became the project team leader for Taxol

Peter asks, “*How long did it take them to thank your husband for forcing them to bring you along?*”

- Too long
- Nick really enjoys that story because, like all good family stories, it gets embellished over the years
  - He tells this story like, “*You should actually want her. You don’t know this, but you should.*”

**When you pause in this story to think of everything that would come from this moment forward, and to realize there’s a scenario under which nobody knows everything that’s about to happen**

- She’s an oncologist in Kentucky
- She would be better at tennis ‒ she would have more free time
- The thing is, she loves to mentor
  - It’s really underrated to listen to students and hear what’s on their minds

> “*I remind students about the role of serendipity, and I think I’m a poster child for the role of serendipity*.”‒ Susan Desmond-Hellmann

## Genentech’s origins, and its groundbreaking use of recombinant DNA to develop biologic drugs [33:45]

- Susan left Bristol Myers Squibb in ‘95 and went to Genentech

**Where was Genentech in its life cycle then?**

- [Genentech](https://www.gene.com/) was founded in 1976
- It’s a really interesting company because it claims to be the first biotech company
  - It was based on genetic technology, and that’s where the Genentech name came from
- What [Herb](https://en.wikipedia.org/wiki/Herbert_Boyer) and [Bob](https://en.wikipedia.org/wiki/Robert_A._Swanson) (the co-founders of Genentech) wanted to do is kind of do a proof of concept that you could use genetic technology and make big medicines
  - Make proteins, antibodies, medicines that would almost certainly have to be injected rather than swallowed because they’re large and they’re proteins, so you break them down if you swallow them
- Their initial goals were focused on [insulin](https://en.wikipedia.org/wiki/Insulin#Structural_analysis_and_synthesis:~:text=The%20first%20genetically%20engineered%20(recombinant)%2C%20synthetic%20human%5Ba%5D%20insulin) (which they out-licensed to Lilly and Pfizer) and human growth hormone
- Before Genentech, when you were a parent and your child was short, you needed to give that child growth hormone that came from cadavers
  - That had a risk of this slow virus disease
  - And that was not a good trade-off for parents
- The concept of having recombinant, of having human-like growth hormone was a really wonderful thing
- Genentech’s first drug was [human growth hormone](https://en.wikipedia.org/wiki/Somatrem), and it was a tour de force
  - It was really amazing that in the late ’70s they were able to do this fermentation and purification because they had to prove to FDA it was pure human growth hormone with no contaminants
  - They became famous for that

**Tell people briefly how this worked. What was recombinant DNA technology? What were they putting the gene into? How did they get the gene to make the protein?**

- What you see if you go to a company like Genentech is these tanks
- The tanks are like an ICU for a cell
- What you’re doing is you are teaching the cell to make at very high amounts growth hormone, way higher than your cells or my cells would
- And then you’re teaching the cell through this genetic engineering to secrete it into a medium, this soup [that the cell is growing in]
  - That medium will then contain a lot of growth hormone
- Then you take away the cells after they secrete it, and you purify that growth hormone, and you put it in little vials
- That’s the process of biotechnology

***You can trick a cell into making almost anything you want and make it very much like a human***

- So you don’t have to go to a human to donate it, because growth hormone would be too small
- They used to get insulin from pigs, and porcine insulin caused allergies, and it was expensive

***Human insulin really changed how you thought about treating people who have diabetes***

**More about growth hormone produced by Genentech**

*How do you know that by giving kids extra growth hormone, it won’t cause leukemia or a fourth arm to sprout out or weird things to happen?*

- Genentech decided to follow every child ‒ they set up a patient registry
  - One of the first patient registries ever
  - They followed every child until their reached their final adult height (an amazing amount of information)
  - It was hundreds of kids, thousands by now
  - Genentech got really good at that
- When Susan went to Genentech in 1995, the chief medical officer of Genentech was a pediatric endocrinologist, an expert on short stature and growth hormone
  - But it’s a pretty small market
  - This is uncommon
- By this point, human growth hormone was being used rampantly in sports and the FDA was not happy about they
  - The FDA pushed hard on Genentech to control that use

Peter asks, “*Was it being used by this point also pretty heavily in HIV?*”

- People were using it in HIV, they were using it in sports
  - Anything where you wanted to have more muscle mass
- Genentech had done some studies to look at whether that was a good idea, and none of the studies came out successful

***The benefits did not outweigh risks of having increased blood sugar and some other things that would happen***

**In the early years of Genentech (before Susan got there), they learned how to make enzymes**

- It used the same genetic technology to tell the cell to make these enzymes
- Some of the enzymes got out-licensed to make commercial enzymes
  - Like enzymes you use when you wash clothes and things like that
  - That wasn’t core to Genentech

*They had an* [*enzyme activase*](https://en.wikipedia.org/wiki/Tenecteplase)*, a* [*tPa (tissue plasminogen activator)*](https://en.wikipedia.org/wiki/Tissue-type_plasminogen_activator) *that could break down blood clots*

Peter asks, “*Did they go after that knowing what they were doing or was this a bit of a fishing expedition?*”

- It was intentional
- There’s a clinician researcher ([Dave Stump](https://ir.macrogenics.com/board-directors/david-stump-md)) who is a clotting expert
  - He’s the monk on the heme side, and he was there and really pushed them to do this

**⇒** The concept was that if you could break down the blood clot, you could cure the heart attack, you could save lives

- The interesting thing if you are interested in doing trials is they started the concept of a large, simple trial
- This was early on, and people in cardiovascular, [Eugene Braunwald](https://www.heart.org/en/news/2024/11/15/how-dr-eugene-braunwald-changed-cardiology) and his followers had started these large simple trials
- Genentech bet the farm on this tPa
  - And the farm was that they could change the outcomes in 30 days
  - There’d be more people alive than dead if they were treated with activase
- 2 of the people involved in the studies were [Rob Califf](https://en.wikipedia.org/wiki/Robert_Califf) and [Eric Topol](https://www.scripps.edu/faculty/topol/)

Peter asks, “*Was Eric at Scripps at that time or where was he?*”

- He was at the Cleveland Clinic
- They ran a group called the TIMI Group, and they did all these studies named [TIMI](https://timi.org/)
- They did this big trial and it worked: if you treated with activase, you could break down the blood clots

***So Genentech started this franchise in cardiovascular, and again, did this really interesting patient registry to look at 30-day outcomes for post-marketing***

- But [stents](https://en.wikipedia.org/wiki/Stent) came along, and so the franchise of Genentech and people who were treated with tPa really went down
- The stroke indication was tricky: you had to make sure it wasn’t hemorrhagic or you could make things so much worse
  - On paper, the stroke indication was really cool, but pragmatically it was really tough for hospitals to execute

**Genentech also made another enzyme-like molecule, DNase:** [**Pulmozyme**](https://en.wikipedia.org/wiki/Dornase_alfa) **for cystic fibrosis**

- It decreases how thick your secretions are
- But with Vertex’s CF drugs, it’s also been scooped
- When Susan came in ‘95, Genentech was really struggling
  - They had those three drugs: growth hormone, tPa, and Pulmozyme

Peter asks, “*Why did they out-license insulin?*”

- Susan thinks they needed the money
- She doesn’t think they had the scope to even make it

## Susan’s move to Genentech, and her pivotal role in the development and success of Herceptin as a groundbreaking therapy in targeted oncology [44:00]

**Why did you decide to leave Bristol Myers Squibb?**

- It was the opportunity
- Further down the list of pros and cons was the West Coast was home for her
- She loved the people at Bristol Myers Squibb, she loved the job, but heading back to San Francisco was a big deal
- In 1995 when she sat down with [Art Levinson](https://en.wikipedia.org/wiki/Arthur_D._Levinson) (head of research then) he was talking about the future and oncology, and she believed him when he said Genentech was going to be a cancer company

**What was the first thing you worked on?**

They hired her to work on [thrombopoietin](https://en.wikipedia.org/wiki/Thrombopoietin)

- It was going to be the third leg of the stool
  - 1 – [EPO](https://en.wikipedia.org/wiki/Erythropoietin), so make your red cells go up
  - 2 – [Neupogen](https://en.wikipedia.org/wiki/Filgrastim) for your white cells
  - 3 – [TPO](https://en.wikipedia.org/wiki/Thrombopoietin#Therapeutic_use) for your platelets
- And it was a big race; [Amgen](https://www.amgen.com/) was in the race

Peter asks, “*Who developed EPO?*”

- Amgen
- Amgen and Genentech had always been kind of rivals
- When they cloned thrombopoietin at Genentech, Susan read the paper and then they called her [and asked] did she want to come work on it?
  - It was that kind of thing
- When you clone it, if you publish it, that doesn’t give you the right, it’s a race for everybody

Peter asks, “*Let me ask you a silly question. Why do you publish the results of the cloning before you’ve gone and made the recombinant protein yourself?*”

- You patent it, then you publish, then you make the recombinant
- Genentech, one of their great assets started by [Herb Boyer](https://en.wikipedia.org/wiki/Herbert_Boyer) is they publish
  - They don’t stop the scientists from publishing
  - They get the lawyers in there quick and they make sure that they protect the IP of the company, but they want people to publish (it’s very academic)
- EPO and Neupogen are as if you design them to make recombinant forms and give them to cancer patients or other patients who need them
- Thrombopoietin, not so much
  - To make it simple, if you said your platelets are going way down from chemotherapy and I’m going to give you thrombopoietin to make them go up
  - They come back up really late and they go too high
  - Now this is making you at risk for a blood clot by giving you a million platelets
  - But later than you need to, and you’re recovering on your own already

Peter asks, “*Was that known only once you started developing and you understood the kinetics of it?*”

- Once we looked at how it worked in patients, we knew better than we had before
- Not all chemotherapy as you know causes your platelets to go low
- So you can’t give it prophylactically because you don’t know who’s going to get thrombocytopenia
- This tricky thing about going too high: if you’re wrong, it’s a problem

*What do you do for patients whose platelets go too high?* *Do you* [*plateletpheresis*](https://en.wikipedia.org/wiki/Plateletpheresis) *them?*

- You could; there are remedies, but you don’t want to do that

**Thrombopoietin proved to be very, very difficult drug, and Susan learned the product development equivalent of tulip mania**

- When everybody’s so excited, you get excited too
- What also happened is the labs at Genentech had been working on [Herceptin (trastuzumab)](https://en.wikipedia.org/wiki/Trastuzumab) for a while
- [Art Levinson](https://en.wikipedia.org/wiki/Arthur_D._Levinson) became the CEO in ’95, and he wanted to push on getting Herceptin into the clinic

**How Herceptin worked and what it was for**

- Herceptin is an antibody
- You and I have antibodies that fight disease in our bodies, and it’s an antibody that targets this protein called HER2
- [HER2](https://en.wikipedia.org/wiki/HER2) matters because about 1 in 4 women with breast cancer have too much of it
  - And if you’ve got too much HER2, from the time you’re diagnosed, your median average survival is 3 years
  - If you don’t have too much of it, it’s 7 years
- The concept with this antibody is: turn that off, whatever bad thing that drives survival down to 3 years (pretty simple concept)

Peter asks, “*Mechanistically, do you think that the overexpression of HER2 was impeding immune clearance? What was the thesis at the time for why overexpression of HER2 was cutting life expectancy down?*”

- The thesis was that it was telling the cell to grow

***It was giving a growth signal to the nucleus to say, “Grow more;” and if you could shut that off, you’d grow less***

- Later, we armed Herceptin, we put a payload on it

**⇒** So then you could say both change the grow more signal and you’ve got a little bomb on there to kill [the cancer cell] (you’d get a twofer)

- Another company ([AstraZeneca](https://www.astrazeneca.com/)) has one that’s so powerful with the bystander effect
  - You don’t even have to have overexpression

> “*What I really enjoy about this type of discussion though, Susan, is one, it’s the story of your career, but it’s also the story of oncology.*”‒ Peter Attia

**Because it seemed impossible, a lot of people at Genentech were negative about Herceptin and did not think we should invest**

- The dogma was that antibodies were all hype, overpromised smart bombs that had flopped

Peter asks, “*What was the biggest failure at that point commercially?*”

- Things hadn’t even been commercialized
  - They hadn’t gotten out of the clinic
- People just weren’t seeing benefit
- Susan has a very good friend who’s an oncologist, and he said, “*You just can’t treat a solid tumor, A solid tumor versus leukemia or lymphoma with an antibody. You need something more powerful*.”
- At this same time, it was amazing to hear at ASCO (the American Society of Clinical Oncology) in 2 different rooms
  - In one room we hear that Herceptin is going to change forever how we think about antibodies in breast cancer ‒ way better than we thought, improved survival
  - In the other room we hear about doing bone marrow transplant for breast cancer and having the South African group who published a paper saying it worked, retract the paper and go through and talk about how much of it was fraudulent
  - So at the same time, this nearly toxic, nearly lethal bone marrow transplant for breast cancer was debunked
  - At the same time as we said you give Herceptin (a naked antibody, no payload, no chemo) and you’re going to help that patient with breast cancer
    - Welcome to modern oncology; it could not have been more clear
- Peter almost forgot the [BMT](https://en.wikipedia.org/wiki/High-dose_chemotherapy_and_bone_marrow_transplant) stuff ‒ it’s so archaic
- It was a distraction because people felt they just needed to hit the cancer hard

> “*You just needed to hit the cancer smart. Hard wasn’t the point*.”‒ Susan Desmond-Hellmann

## The rise of antibody-based cancer therapies: the development of Rituxan and Avastin [52:15]

**Rituxan**

- People didn’t believe you could treat a solid tumor, they thought you could treat lymphoma because Genentech did
- People did not believe in antibodies in ‘95, ‘96
- IDEC was going to run out of money so they made an antibody to [CD20](https://en.wikipedia.org/wiki/CD20) [[Rituxan](https://en.wikipedia.org/wiki/Rituximab)]
  - A very important marker on all lymphomas

**⇒** It is impossible to overstate how important Rituxan is in lymphoma

- When in product development, Susan often thinks of patients she’s cared for
  - She had this great 83-year-old pharmacist, and he had a lymphoma that was low grade, a little tired
  - He was fine, so we did watch and wait (not Susan’s favorite strategy of oncology)
  - He’d be a perfect candidate for Rituxan: 4 doses
  - You can repeat it; it works so well

*When Susan changed her mind on antibodies*

- Somebody on Rituzan had [tumor lysis syndrome](https://en.wikipedia.org/wiki/Tumor_lysis_syndrome)
  - They had a lot of lymphoma, and the cells are breaking down so fast that their kidneys can’t keep up (they have to be dialyzed)
  - That was from an antibody, no chemo, no payload, nothing ‒ that’s when you’ve got a good drug

Peter asks, “*How many types of cells in the body express CD20?*”

- It’s mainly [B cells](https://en.wikipedia.org/wiki/B_cell)

Peter asks, “*But it’s not as specific as CD19, is it?*

- [CD19](https://en.wikipedia.org/wiki/CD19#Expression) and [CD20](https://en.wikipedia.org/wiki/CD20#Expression) are both on B cells

**This is a chimeric, tell folks what that implies**

- There are so many dogmas that we believe until data proves otherwise
- Rituxan was a chimera and people worried that it had too many mouse parts to human parts, and that it would cause [human anti-chimeric antibody (HACA)](https://en.wikipedia.org/wiki/Human_anti-chimeric_antibody)
  - The FDA was very concerned about this
- So we measured and measured and measured, and it turned out probably because the patients had lymphoma that they didn’t get HACA
  - Very tiny numbers, not clinically relevant
  - And you treat patients over and over again
- Herceptin is 93% human, so not a chimera, but not fully humanized

***None of the patients treated with antibodies that Susan has seen, not with Genentech or IDEC antibodies have really had problems***

- They’ve had other problems based on target-related problems, not based on the antibody

**⇒** The CD20 antibody was just a straight naked antibody ‒ it’s targeted to destroy the CD20 positive cells

- But it turns out that if you have lymphoma, you’ve got a reserve in your marrow of other CD20 cells of more immature that grow up and replace
- So it’s not like you’re really at a huge risk for untoward reactions from your CD20

Peter asks, “*Why do those patients with marrow that’s still producing CD20 positive cells not go on in a constant state of lymphoma requiring? In other words, why is it that you can treat this and create a durable remission?*”

- Susan doesn’t know if anyone has done a formal study
- She thinks at some point in oncology treatment, if you have a tiny amount of disease left (especially something like lymphoma), you may take care of it yourself

***It’s just getting rid of enough of the diseased B cells to get the load down low enough that the immune system can wipe out the clone***

**The dogma with antibodies is different from the dogma with chemotherapy**

- The dogma with chemotherapy, if you are on Taxol and your tumor comes back, the oncologist wouldn’t give you Taxol again
- If you’re on Herceptin or Rituxan and your tumor comes back, in a heartbeat the oncologist would give it to you again

**What was the price of these drugs at the time they came out?**

*Were these the first chemotherapeutic agents, or you kind of want to distinguish them from traditional chemo, but were these the first oncology drugs that came with big price tags?*

- Probably they were
- Taxol kind of went to that next level, and then they went the further level
- Compared to today’s prices, the price was low
- But Rituxan, more than Herceptin because people started using it more like you’d use 4x or 8x and recurring
  - Rituxan sales went very high, very fast

**Targeting VEGF to stop vascularization of tumors**

*About this time we get the whole anti-VEGF story*

- That was [Judah Folkman](https://en.wikipedia.org/wiki/Judah_Folkman) over at Boston Children’s
- Peter never had a chance to meet Judah; he wrote a fantastic [book](https://www.amazon.com/Dr-Folkmans-War-Angiogenesis-Struggle/dp/0375502440/ref=sr_1_1?crid=15OWODG6IC7NU&dib=eyJ2IjoiMSJ9.XK2Xfb_qlb53e3axZd9jZaiuQP2y0HYzS0D3iAFAcVNcGkWkCg_Gwr6j4eOXXcfkD8_DXYagwmNP3Baf0izzyxoJ7l2yACEG8NdXzwuNpjdkaJzQkJv7QjSPllYRAYB1MUJ4EzNCp5xJj_AWjiZf2Dg-SbkxujjOhCbF37ffoik.JEiNqNH-cCtRo-k45Xr3PVh07BA2CftLPHMmLzLvVuQ&dib_tag=se&keywords=judah+folkman&qid=1741009972&sprefix=judah+folkman%2Caps%2C80&sr=8-1) that Peter poured over in medical school
- Susan is smiling because she had a word for Judah Folkman talks (which she heard many of): phenomenologist
  - He would say, “*This patient had this, so it must mean that.*”
  - Some of it made no sense to Susan, but some of it was like, “*Wow, I wish I had thought of that*.”
  - He was a really fun person to listen to

**⇒** Judah’s thing was: the cancer can’t grow larger than a BB if it doesn’t have new blood vessels (it was stuck at a certain size)

[***VEGF (vascular endothelial growth factor)***](https://en.wikipedia.org/wiki/Vascular_endothelial_growth_factor) ***is the primary way you grow new blood vessels if you’re a tumor***

- People went crazy about this hypothesis
- It was more than the TPO that Susan was describing because it was due to Folkman
  - And he’s very compelling and very charismatic
  - It’s logical, it resonates

A saying Peter loves, “*It’s the description of science as a beautiful, compelling hypothesis slayed by an ugly fact.*”

- [Napoleone Ferrara](https://profiles.ucsd.edu/napoleone.ferrara), also a great character, Italian Ob/Gyn, who came to Genentech and worked in one of the labs, made an antibody to VEGF
  - Same backbone as Herceptin
  - 93, 94% human
- We decided we should go after an antibody for VEGF as our next big oncology program
- Susan remembers one of the things that [Gwen Fyfe](https://www.linkedin.com/in/gwen-fyfe-md-505b71a/) said before the first phase I patient was treated
  - A great clinical oncology trials expert, who was in charge of the program
  - Gwen said after they put that in someone’s body, “*My nightmare is that all the blood vessels fall apart*.”
  - Susan replied that they did all the tox studies and don’t think it’s going to be that bad, but they have no idea
- This was phase I using a very low dose

***This was the first human dosing of anti-VEGF, and they knew how important VEGF was, so they were scared***

- This was the mid ‘90s when Susan had just arrived at Genentech ‒ it was wild
- We’re into the clinic and we make progress and it’s really good news and lots of studies, and we’re ambitious
- We want to target a lot of different cancers: lung cancer and breast cancer

**How are you picking the cancer to study something like this? Herceptin’s obvious because you’re targeting a receptor.**

- Herceptin and Rituxan were easy
- There is one tumor where VEGF plays a seminal role, and that is [renal cell carcinoma](https://en.wikipedia.org/wiki/Renal_cell_carcinoma)
  - Yet renal cell is really tough to study
  - It’s not set-up clinical trials-wise

Peter asks, “*Why is that? You’ve got the IL-2 stuff going on where 10% will respond to it, but 90% won’t.*”

- It should be easier
- It may be the sites and where the clinicians are who care for it (it may just be that pragmatic)
- We kept struggling to figure out how to do a good renal cell study
- We thought we could do a breast cancer study because we had a lot of networks of breast cancer patients, and particularly patients who weren’t eligible for Herceptin (because many of them weren’t)

***We wanted to do a late stage breast cancer study because if we could help these patients, we would find out right away***

- These were patients with metastatic breast cancer who had already progressed through everything
- It was a really tough, high bar
- The standard in phase II was we wanted to have at least 50% shrinkage
  - We wanted to change time progression

## The step-by-step drug development process and the scientific and strategic challenges involved [1:01:30]

**Peter wants people to understand the difference between a phase I, phase II, and phase III study; and also understand what’s preclinical**

- It’s not intuitive to people why it costs a billion dollars to get a drug to market and why it can take a decade

![](https://peterattiamd.com/wp-content/uploads/2025/04/f1-susandesmondhellmann.png)

**Figure 1. Phases of a clinical trial**. Image credit: [Rare Disease CTN](https://rarediseaseresearch.ie/clinical-trials-explained/)

- It’s important to understand how many times a drug failed because of the experimental design, the wrong patient selection, the wrong disease selection
  - You have got to line up four pieces of Swiss cheese just right to get the pen through to hit it

**Back to Judah Folkman talking about VEFG, and that turns into we made an antibody to VEGF (the idea). Now start the clock and start the dollars.**

- Often in oncology today, we’ll start with a target and what’s the best way to turn down (or turn off) that target?
  - Is it a small molecule?
  - Is it an antibody?

**The difference between a small molecule and an antibody**

- **Small molecule** is chemistry, it can be a pill (but not always), and you are often impacting pathways or enzymes or things that happen in the cell
- A large molecule is an **antibody’s biology**
  - With an antibody, you are trying to do something that may be immune in nature
  - Or you use the antibody as a delivery device to get something to the cell
- Many modern companies really like antibodies because when something happens, it’s on target
  - It doesn’t tend to be off-target
  - The chemistry of small molecules tends to have surprises in negative ways: off-target effects, liver toxicity, or kidney toxicity

*Peter explains this through cardiovascular medicine to help people understand the difference between a* [*statin*](https://en.wikipedia.org/wiki/Statin) *and a* [*PCSK9 inhibitor*](https://en.wikipedia.org/wiki/PCSK9#As_a_drug_target)

- These are 2 common drugs used to lower cholesterol
- A statin is a **small molecule**, it’s dirty: it blocks an enzyme but it’s got all these off-target things
  - Your liver function gets whacked, you get insulin resistance, some people get horrible muscle soreness
  - 5-10% of people taking this drug are going to have a side effect that prevents them from taking the drug
- Peter has never seen a person yet who couldn’t tolerate a PCSK9 inhibitor where you inject an **antibody** into them that binds to a protein and shuts it off

***The choice of molecule [small molecule or antibody] is driven by those differences***

- When Susan was first in product development the thought was: you need a pill for chronic indications, for compliance
- Look at obesity drugs, turns out a lot of people would take an injection if they want to

**Once you have made this selection, you need to make sure you can make it ‒ a critical thing for a biotech company is the small scale production of it**

- They call it a mini firm

*The mini firm has to resemble what is actually going to be used, because the next thing you start doing is a bunch of models*

- Judah Folkman giving a great talk doesn’t mean you believe that blocking VEGF will help cancer
- We do models in mice
- We may do larger animals
- We do fewer animal models than we used to because they’re really limited
- Susan would rather have a great target with good biology than an animal model, but it’s still helpful

**The critical thing is the preclinical work that you do**

- The FDA is going to ask you about toxicology
- What’s your safety plan?
- Based on the biology of VEGF, what are you most worried about?
  - I’m most worried about bleeding
  - It’s an antibody and I’m most worried about an allergy to the antibody
    - Did any of the tox studies show allergy to the antibody?
- What are you going to look for and how are you going to look?
- How often are you going to measure the patient?

***The preclinical safety plan is really important and based on what you find in toxicology***

**If you have a targeted therapy you must have a diagnostic**

- This is essential, especially in modern oncology
- And that is wicked hard because you’ve got [to develop] the therapeutic and the diagnostic at the same time
- Things like CD20 and VEGF are very ubiquitous ‒ so it’s not really targeted in the sense of [HER2](https://en.wikipedia.org/wiki/HER2), where we needed a diagnostic
- But if you need to have that, we had what we called a **clinical trials assay** for Herceptin that wasn’t to be marketed

Peter asks, “*Did you guys have to have somebody in parallel developing a* [*CLIA*](https://en.wikipedia.org/wiki/Clinical_Laboratory_Improvement_Amendments) *certified assay that a pathologist was going to use? Or did you do that in-house?*”

- We had an in-house clinical trials assay that we used all the way through phase III
- There was nothing wrong with it, except it wasn’t approved
- When we went to the FDA, they wouldn’t approve Herceptin until we had an approved diagnostic

Peter asks, “*Whose responsibility is that? How do you encourage the world to make that happen?*”

- We went to several diagnostic companies
- [Dako](https://www.agilent.com/en/dako-products) agreed to make an immunohistochemistry test for HER2
  - And [HercepTest](https://www.agilent.com/en/product/pharmdx/herceptest-kits) is made by Dako
- But we had to go back and correlate that with the clinical trials to make sure that it was the same as the clinical trials assay

Peter asks, “*Why didn’t you guys do that in parallel? Was the cost too great? And did you want to de-risk the drug before you sunk the cost into that?*”

- We were too inexperienced to realize we should have
- Nowadays we’re doing that in parallel

**Go back to helping people think through the arc of time. From the moment you guys hit a go decision on we want to do this (we want to pursue this path), how long until you file the** [**IND**](https://en.wikipedia.org/wiki/Investigational_New_Drug)**?**

- It could be 2-3 years, because you’re doing animal models

*Tell folks what the IND is so they understand why that’s an important milestone*

- The [investigational new drug (IND)](https://en.wikipedia.org/wiki/Investigational_New_Drug) is asking the Food and Drug Administration permission to ship an unapproved drug across state lines
  - If you and I wanted to do something in Austin, we could actually do it
  - Which is sort of weird when you think about it, but most people don’t really want to do that
  - You want to run a clinical trial, and ship it, and get it out of the state
- You have to have the IND
- The investigational new drug is the request
- What happens is that you take all this information Susan’s been talking about
  - You have a molecule, you trust the way you’re producing the molecule, you understand the biology enough
  - You have a safety plan and you have a phase I protocol

**The purpose of phase I is for safety**

- Is it safe to give humans this molecule?
  - Is it safe to give it once?
  - Is it safe to give it multiple times?
- There’s an art to knowing where to start the dose; because it’s an escalating dose trial
  - You’re extrapolating from what you learned about toxicity in a totally different organism that never translates one-to-one to the organism of choice
- You see people all the time backing up on the dose, thinking the dose was more than we wanted

**⇒** Phase I with a good pre-clinical package, a good IND, should be uneventful

- And because we are greedy in oncology, we always look to see if anybody responds
- To be fair, phase I has some really tough patients, who are trying something and have tried a lot of other things
  - The patient population can be tough to find any efficacy in

***Phase I might be a year if you’re doing really good job, and it would cost in the tens of millions of dollars***

**Phase II**

- You get into the $20s, $30s, $40s of millions depending on how big your phase II is
- This is where people can use their intellect in many ways

*Phase II looks at*

- What’s the right dose and schedule?
  - It’s very important to get the right dose and schedule
- What’s the right outcome?
- What’s the right patient? Who do you want to treat?

***Phase II is supposed to get you read for phase III: you’ve got a dose, a schedule, a patient selection criteria, and a hypothesis of where this is going to be a drug***

- The exception in oncology is sometimes you want to get an approval off phase II

**When we tested anti-VEGF in breast cancer in phase II, we wanted to use that as an approvable study**

- Because we would go in and say, “*Look, it can be a contingent approval, but these patients have nothing else to do*.”
- That can happen especially with a targeted therapy, where you’ve got the perfect target and FDA’s feeling good about it t
- But most of the time, you’re getting ready for phase III

**Where were you guys with anti-VEGF in phase II? You tested it with breast cancer, and did you do colon?**

- We did colon but not in the kind of study that Susan just mentioned for approval
- We did a traditional phase II in colon

*What happened is the breast cancer study failed, and Susan was so disappointed*

- She was so hoping that that would work
- She still remembers that day
  - She knew they needed more, better drugs for breast cancer
  - She often heard from people, when they’re the 3 out of 4 patients who Herceptin wasn’t for them
  - If you looked at your stock that day, it also looked really bad because all the hype about [Avastin](https://en.wikipedia.org/wiki/Bevacizumab) was there

*But in colon cancer, we had a phase II*

- We got ready on the dose and schedule, and then we went to a phase III study in colon cancer
  - Much more traditional (5-FU and the usual suspects) ± Avastin
  - Treating [stage IV cancer](https://en.wikipedia.org/wiki/Cancer_staging#Overall_stage_grouping)
  - That was a median survival study
- It was the first new thing in colon cancer for a while too, so people were pretty excited

## The ethical and economic controversy surrounding Avastin’s high cost and limited survival benefit [1:12:30]

At this point, Peter is in his first year of medical school

- He’s just down the street at Stanford
- He remembers a discussion in class about [Avastin](https://en.wikipedia.org/wiki/Bevacizumab)
  - $100,000 for the treatment, extend median survival (by maybe 8 months)
  - The UK (NHS) said, “*No, we are not paying for this*.”
    - The NHS had this $100,000 quality-adjusted life year hurdle, and this was only giving you 8 months
    - That’s how  you throttle supply-side economics
  - People in the UK could pay out of pocket, but not through the National Health Service
  - People in Canada could not, because you couldn’t have private insurance in Canada
    - Though you could come to the US for treatment

**What was your thought at the time ‒ have we moved the needle enough? How do we think about the economics of this?**

- Susan had a lot of different reactions
- With Avastin, she remembers reading one of those curtain-raiser things in the Wall Street Journal for the breast cancer study
  - The headline was, “*Avastin might help breast cancer patients, but can they afford to take it?*”
  - She was shocked that it was the first time she had read, in as long as she had been at Genentech, that somebody couldn’t afford one of their drugs
  - That felt really important and really not good

Susan explains, “*We had, as a company, a philosophy that no patient should go without any of our drugs because of an inability to pay*.”

- We had a bunch of patient support programs
- But that doesn’t help patients in the UK, and it doesn’t help the overall cost
- The cost is still really high

***We started to have a lot more discussion at the executive committee about the price and how we would think about it and how we would price the drugs, because that was not good***

## Susan’s tenure as chancellor at UCSF: leading during a financially strained period, and her strategic approach to fundraising and institutional development [1:14:45]

**Did you go straight from Genentech to being a chancellor at UCSF?**

- Yes
- Peter wants to continue the arc of her career, we’re in the early days (in the 90s)
- Given Susan was on the cusp of what is happening in oncology and biotechnology , now the same institution who said she couldn’t come back to a clinical appointment after saving the people of Uganda is offering her the highest post
  - That’s remarkable

**Does that speak to what they saw as the vision of that institution?**

*Which was, few people have learned what Susan has learned in the last 10 years, and we want that type of leadership here?*

First, on the Genentech side of things, [Roche](https://www.roche.com/) bought Genentech in 2009

- It was a hostile takeover
  - In the business world, they call it a squeeze out
- Susan knew she was going to leave, going to do something different
- At UCSF she had been really close with the chief of medicine, [Holly Smith](https://pmc.ncbi.nlm.nih.gov/articles/PMC6118641/)
  - He was Susan’s chief of medicine when she was an intern
  - He was a South Carolinian, Harvard trained, amazing person
- Between him and [Bill Rutter](https://en.wikipedia.org/wiki/William_J._Rutter) (who founded [Chiron](https://en.wikipedia.org/wiki/Chiron_Corporation), who’s a biochemist), they decided a long time ago that UCSF should not be a backwater medical school, and should be a serious medical school
- So Holly on the clinical front and Bill on the scientific front just decided they would start recruiting people to have a great institution
  - In the ‘70s, ‘80s
- Susan was still friends with Holly and he called her when [Mike Bishop](https://en.wikipedia.org/wiki/J._Michael_Bishop) was stepping down
- He said, “*And you should be chancellor*.”
- Of course Susan was not a professor, but she said if they were interested, she would be open to talking to them
- Susan went through the interview process

**Do you remember the vision that you presented to them?**

- 2009 was just a horrible recession and California was particularly in a bad place
- She talked to them about how she thinks about managing people
  - How to make sure you use your assets maximally
  - She admitted that she had never done fundraising
  - But she had done a lot of work with Wall Street and she could talk

Peter asks, “*What was your title at Genentech before you went [to UCSF]?*”

- President
- And she did a massive amount of investor relations because Art didn’t like traveling or talking
- Susan thinks they wanted somebody who could work on the business aspects of campus (to finish Mission Bay)
- She was really the CEO of this system
  - Manage the hospital
  - It’s a big hospital system
  - There’s no undergrads at UCSF

**Were you nervous that you had bit off more than you can chew? This is a huge responsibility.**

- Susan was really concerned
- She also realized that some of the faculty were pretty negative when she first started
  - She was an alum but wasn’t coming up through the ranks
  - They were nervous about money, and weren’t convinced that she knew how to get them money

> “*If you’re running a program, you need money. It’s the mother’s milk of doing science.*”‒ Susan Desmond-Hellmann

**Tell me about the budget of UCSF**

- It’s a state school but almost nothing comes from the state of California
- In a sense, UCSF and Stanford aren’t that different
- You’ve got clinical income, NIH income, other grant income, philanthropy
- Probably ⅓ of the revenue for general operations is coming out of NIH overhead
- Clinical revenue is a lot but a lot of it goes back to the hospital
  - It’s a not-for-profit
- A lot comes from philanthropy: some is direct, some into the endowment
  - They were living off the interest
- Tuition is tiny
  - There’s no undergrads and the number of students is really low
- Peter didn’t apply to UCSF, as a non-Californian he didn’t think there was any way he would get in

**How Susan got into UCSF for her residency**

- During her first year at the University of Nevada, her youngest sister was born
- So she lived at home and helped her mom
  - She was 1 of 7 kids
- When she went to medical school [at the University of Nevada], she had a sign on the stairs, “*Be quiet, I’m studying down here.*”
- Her dad was born and raised in San Francisco, so she wanted to go there
- UCSF had never taken a University of Nevada student
- The University of Nevada was a pretty new medical school
  - Susan was in the second four-year class

Susan explains how much she wanted to go to UCSF, “*I was excited like my head would blow off.*”

**Back to her time as Chancellor of UCSF**

- What saved her as chancellor was philanthropy
- We needed people to care about the mission and the projects at UCSF right at the same time as the [Mark Zuckerbergs](https://en.wikipedia.org/wiki/Mark_Zuckerberg) of the world and the venture capitalists of the world and a lot of people had come into a lot of money
- Even though the overall economy was bad, it was coming back, and we had some spectacular successes
- Susan’s successor, [Sam Hawgood](https://profiles.ucsf.edu/sam.hawgood), continues to have that kind of success
- People are just really generous
- One thing always on Susan’s list of New Year’s resolutions is to be more generous

**What was the approach you took towards philanthropy?**

*And how did you reach donors that maybe previously hadn’t been involved in UCSF?*

- Stanford has a big advantage over UCSF because they have undergraduates
  - They have a lot of people coming through, doing engineering degrees, doing CS degrees, who are going on to create enormous enterprises
- Anyone who’s an alum of UCSF went to graduate school there
  - There’s no business school, there’s no law school, so they’re missing out on a lot of this
- The hospital is the most important donor base
  - Grateful patients or people who love science, technology
- Susan hired [John Ford](https://www.case.org/john-b-ford) to be head of development
  - He had retired as the head of Stanford’s fundraising, moved up to the Northeast
- She asked him to teach her how to be a good fundraiser
  - He talked about, “*Tell people your hopes and dreams. Tell people what you’re excited about and ask them what they’re excited about, and see if there’s a match*.” (that was really important)
- Because Susan had been at Genentech and was gregarious and knew a lot of people
- People knew she had decent business savvy and that she wasn’t going to waste their money

> “*We were very committed to use the money wisely, especially in the hard times, and do special things at UCSF*.”‒ Susan Desmond-Hellmann

- She was worried she would be sad if people said no
  - That it would be weird, especially if she knew them well
- So she would get herself psyched up for the beginning of it, and then by the end she’d be like, “*Oh, that’s fine. Next time, if you’re in town, let’s talk again, and maybe it’ll change*.”
- It was actually fun
- She got to talk to and meet a lot of great people

**What percentage of your time was spent externally versus internally?**

- Probably 40% externally (a lot)

*What was the internal focus then?*

- Working with the team
- Her direct reports were the provost, CEO of the hospital, Lawyer, all the deans
- Monthly she met with all the chancellors, with the University of California President
  - It was [Mark Yudof](https://www.law.berkeley.edu/our-faculty/faculty-profiles/mark-yudof/#tab_profile) at the time, and then he stepped down after a while
- The chancellors meetings were funny because they all had undergrads, so Susan always felt like she was squirming (are we done yet?)
- Her favorite thing was every Friday at lunch in Mission Bay they had a science talk
  - They would have food, and you’d look around the room and see [Bruce Alberts](https://brucealberts.ucsf.edu/), [Liz Blackburn](https://blackburnlab.ucsf.edu/)
    - There’d be four Nobel Prize winners in this little cramped room listening to science
  - This was something she did as a scientist, not as the chancellor

## What Susan learned as CEO of the Bill and Melinda Gates Foundation: strategic processes and decision-making frameworks [1:26:00]

**What in 2013, 2014 leads to the next transition ‒ to being the CEO of the Bill and Melinda Gates Foundation?**

- She got an email from [Melinda](https://en.wikipedia.org/wiki/Melinda_French_Gates) asking if she had time to talk (a surprise)
- UCSF throws a big event every year that’s friend-making, fundraising, everything; and we give out awards, recognition to people whose work we respect a lot
  - Susan had invited Melinda the year before, and thought, “*She’ll never come.*”
  - And she accepted and came with her mom and dad
- Melinda and [Bill](https://en.wikipedia.org/wiki/Bill_Gates) wanted Susan to look at being the next CEO of the [Gates Foundation](https://www.gatesfoundation.org/)
  - Susan had not expected that
- She went up to their house in Seattle to meet with them
- Her husband had worked at the Gates Foundation
  - He led the HIV and TB programs about 5 years before
- Susan had only been at UCSF for 5 years and it was going well
- Bill made this big pitch that a lot of people could do the UCSF job, but Susan was the only person who both Bill and Melinda both wanted for this job
  - She was perfect for it and it’s a really important job for the world (with their focus on global health)

Peter notices, “*You have the background in the clinical side, the research side, the epidemiologic side, the management side. Those are four legs of a chair.*”

**Were there other things that Peter is missing that they felt were essential pillars?**

- It was less obvious then, but Bill and Melinda started to have disparate views of how the foundation should operate
  - Melinda was focused on women’s issues
  - Bill would do another run at polio
- The goal broadly was that all lives have equal value, but they came at it from different ways
- The thing that resonated for Susan was that she could see both those points of view

Peter reacts, “*But those points of view don’t strike me as mutually exclusive for an organization with enormous resources.*”

- Yes and no
- It’s one thing to have enormous resources
- It’s another to know one of the most important assets they have is the time and energy of Bill and Melinda
  - They actually show up; things happen

**How did you weigh this decision?**

- Susan thought she could add value
- She thought she would learn a lot
- She did think UCSF would be fine without her ‒ they were back on their feet financially
- She thought [Sam Hawgood](https://profiles.ucsf.edu/sam.hawgood) (who was the dean of the School of Medicine, who she had a ton of respect for) was the obvious person to take her place

*Was UCSF surprised? Did they try to talk you out of this?*

- She doesn’t think they did
- They had a lot of respect for the Gates Foundation

**You head up to Seattle and when you show up to the foundation, how many employees are there?**

*It’s a not-for-profit, but does it run like Microsoft? How does it operate?*

- It’s a couple thousand ‒ big building, big foundation with people all over the world now
- There was a lot Susan wasn’t surprised by
  - The global health stuff, she knew what they were doing and thought it was interesting and great
- The challenge for her was Bill’s endless appetite for things, like learning things, driving things, funding things
  - Susan feeling like she could get her hands around a strategic plan
  - The staff would be like, “*Bill’s going to love this. Let’s present it.*”
  - She kept trying to get her hands around what they should do so it’s more orderly and they get a great return on their investment
    - She feels good about that focus
- She found it funny when she sent the finance team to Genentech
  - There was a really great portfolio management process put in place when she was there, and they were still using it
  - She recommended it to Bill
  - The process was pretty simple, everybody knows how you make decisions, what money’s up ‒ it doesn’t need to be bureaucratic
- To this idea, Bill replies, “*We don’t need it. It’s all in my head.*”
- Susan thought, “*If it wasn’t you, I would think that was a smart-ass thing to say, but I actually think you’re just being honest.*”
- Susan encouraged him to understand that just because it was in his head, didn’t mean that the rest of the team was there
  - We had a little more ability to make things orderly

> “*It was six years of a wild ride.*”‒ Susan Desmond-Hellmann

**What was the most difficult thing for you to impact that you wanted to change?**

*Was there a global initiative that you wanted to get your hands around that you just couldn’t do organizationally or technically? What were the challenges?*

- For Susan, it was far the opposite
- The things she knew about, felt really good about was the TB stuff, the HIV cure program
- Probably the hardest thing for her was the people side of things
  - She has a very strong sense of how people should treat each other and the competencies that managers should have
    - And she’s not willing to move on that because you’re a technical expert
    - She found that if you do move on that, it just changes the culture, and she struggled with that

**Say a little bit more on that. Is that because in the not-for-profit space, you have a different talent pool than you do at Genentech?**

- No, Susan thinks it’s because Bill really likes technical experts
  - And if he likes them, he doesn’t want the CEO to come and say anything but, “*Yes, they are very smart.*”

**What did the org chart look like? So I assume Bill and Melinda are co-chairs.**

- They were

*As the CEO, who are your direct reports? Is it organized by a bunch of GMs in different programs?*

- There’s a global health person, there’s a global development person, there’s an ag person
- Under global health you have the subs
  - Global health is a very big job, it’s the biggest
- US education is a pretty big job too
- The one that has been ag is now ag financial services for the poor
  - It’s a pretty broad group

**What’s the annual budget?**

- $8 billion
- So much money, it’s amazing

**What are things that you could not have done there in that role had you not had the leadership roles at Genentech and UCSF?**

- Susan thinks more on the people side of things
- She remembers there was an employee whose performance was really struggling at Genentech
  - And her boss (who answered to Susan) kept talking to Susan about how she was struggling
    - Could we do this?
    - Did we need to give her fewer reports, more reports?
    - Make her job harder, make her job…
  - We couldn’t figure it out
  - This person was not acting like she had been
  - One day she said, “*Oh, I’m getting a divorce,*” and after a little while, things got better
- Susan thought, “*Not everything’s work.*”

***As a manager, Susan really cares about people thriving at work***

**⇒** When she went to the Gates Foundation, she understood better (given her experience at Genentech and UCSF) a very important principle: work never fills in for home, ever

- It never makes up for a bad home
- If somebody needs a timeout, she always thinks, “*How can I improve work?*” And sometimes it’s good to understand that’s not always the case
- Especially if you’re working in global health or global development, you might be in South Africa, you might be in China (it’s rough)
- So just thinking a little bit about how people can show up in ways…

***Thinking: How do they maximize the benefit of that $8 billion? And what can I do to enable that?***

## Susan’s philosophy of leadership and how she sought to build an empowering, values-driven culture at the Gates Foundation [1:35:15]

**Are you basically only able to affect that through your interaction with your direct reports, and just hope that that’s the infusion of culture that then trickles down?**

- Peter notices it’s hard to go two levels below your management, and yet the people who probably need this compassion the most are people you’re not even going to meet
- Yes and no
- One thing about traveling a lot, you have big events or things like that, is you meet people on trips, and that’s different people throughout the organization
  - There are opportunities
- Susan also set up meetings
  - When people would have a grant that needed to be signed, the business process was it would show up on my computer
  - Susan changed the business process so she got the group that could fit around the table in her office, and we would talk about the grant
  - This allowed her to interact with more people that weren’t her reports (which she really liked)

***It’s mostly through your reports, but there are ways at the senior level you can interact with people, culture-wise***

**When you think about the culture that you wanted to bring to The Gates Foundation, I’d like to understand what that was and how successful you think you were able to be**

- Peter thinks culture is a very misunderstood word
- He asks this because Susan was in an organization where she also had very powerful other people present whose culture was a part of the organization

Susan explains, “*I define culture in a really specific way, that when you come to work, you feel like the atmosphere, the surround sound, brings out the best in you and that you have some ownership of tweaking it if it doesn’t.*”

- That’s something you feel like you can control
- Because if you’re in thousands of people or hundreds, thousands, tens of thousands of people and you’re the CEO, you’re not going to do that
- But that you set up that culture

**One of Susan’s favorite stories from Genentech is an example of culture**

- Being at a product development meeting, that her successor as Medical Officer [Hal Barron](https://en.wikipedia.org/wiki/Hal_V._Barron) was running, and [Art](https://en.wikipedia.org/wiki/Arthur_D._Levinson) and Susan both attended just because they loved it and wanted to be there
  - They weren’t decision makers, they were just attendees
- The discussion was about Herceptin and how the HER2 test performed
- And if you’ve got more patients, you would get more commercial, but you would have patients who wouldn’t benefit
- And someone said, “*But if we have a test that does this, we can get more money.*”
- In unison, Susan and Art both stood up and said, “*We never do that, we don’t do that here, done*.”

***Culture is right where decisions are being made***

**Susan had practice in so many meetings at the Gates Foundation**

- She would sit there, Bill or Melinda would be there
- A person is presenting and Bill is peppering them with questions, some in a very tough way
- Susan would look at them and nod like, “*You go this*.” (smile and coach)
- She would also stall in a nice way (not confrontational), “*Hold on a minute, Bill. I think he’s just getting ready to answer that question. You’re talking over him right now.*”

> “*I want you to succeed. I want you to know I want you to succeed.*”‒ Susan Desmond-Hellmann

***Susan believes in bringing out the best in people***

- Giving people the agency to do that on their own means that if somebody sees Art Levinson say, “*That’s not the way we do it here,*” they’ll go down the hall in a different meeting and say, “*I heard Art say …*”
  - That’s really powerful

## The erosion of public trust in science during COVID, the communication failures around controversial treatments like ivermectin, and the need for better public health engagement and transparency [1:39:30]

**In 2020, were you at the foundation when COVID hit?**

- Susan had announced that she was leaving and was literally packing as COVID hit
- The first case was a few miles away in a Washington state nursing home

**The difference between science and advocacy**

- Peter has talked about this difference before, and hasn’t wrapped his mind fully around it other than having a sense of lost opportunity with COVID
  - On the one level, there were so many pretty incredible things that happened with respect to the speed with which a vaccine could be developed that really made a difference in terms of mortality for a subset of the population
  - But a lot of that’s overshadowed today by the lingering doubts, the lingering suspicions, and frankly the mistakes that were made
- Peter is not convinced we’re better off today in terms of preparedness for a pandemic than we were in 2019
  - Which seems like an unimaginable statement given what we’ve been through

**Do you think I’m too pessimistic? How do you feel?**

- Susan doesn’t think he’s too pessimistic
- She is absolutely horrified

> “*It’s shocking to me that the narrative is in the place it is today, and I’m honestly still processing how we got here from there*.”‒ Susan Desmond-Hellmann

- It’s a really bad place, and she thinks Peter is right ‒ if a pandemic happened again to day, it would be the way it was with the worst of COVID
- But even worse because trust and the need to have sides and winning and losing

***Susan has been in this business for 40 years, and she doesn’t remember health and medicine being winning and losing and sides (it’s just weird)***

**Peter wonders what it will take to restore confidence**

- It might be that the medical community and the scientific community need to be more vocal about acknowledging mistakes
- He believes it was an enormous mistake having Dr. Fauci being both the head of science and the head of advocacy
  - No human can do that; it’s not about him
- A **scientist** has to be an impartial observer of fact who is happy to change his or her mind in the presence of new information with no attachment to what has been said in the past
- An **advocate** has to be driving policy and action, and sometimes they have to settle for the best you can do, any port in a storm
- When you put those two hats on the same people, Peter worries that you lose all trust

Peter adds, “*I do wish the medical community could have an open and honest discussion about that*.”

- He thinks it’s not an “if” but a “when” we will have another pandemic
  - There’s zero doubt in his mind
  - He hopes it’s decades from now
- Bird flu is working hard on it right now

Peter hopes somebody will remember that lesson and say, “*We want our chief communicator of the state of the science to be completely uninvolved in telling the public what to do, simply there to report what we know today.*”

- Report that today we think masks work
  - Then, we just did a study and realize they don’t work worth a lick
- Today we believe vaccines prevent transmission
  - We just did a follow-up survey: they don’t prevent transmission
- That’s a very forgivable position that Peter thinks the public would welcome

*Susan takes this into the world of oncology*

- She just talked about bone marrow transplants for breast cancer
- If you tell people, look, here’s what we thought
  - We thought harder treatment was better for people
  - It’s now proven that it’s not
- Science changes; people know that

***She agrees that being honest and open when it changes and how it changes matters a lot***

**The difficulty with keeping up with the fast pace of communication**

- She would add to Peter’s recommendation, the pace of communication, the social media and misinformation or just stuff gets out there really fast and having something slow doesn’t keep up
- For example, in May of 2020, if you suggested that this came out of the Wuhan lab, you were kicked off social media
  - You were in the dog house; that was misinformation
  - Today, almost any observer would agree that was actually information

***Peter doesn’t have any insight as to where you draw the line***

- Susan doesn’t think it’s a matter of kicking people off because that would enhance that and you may be wrong
- Instead, be part of the dialogue

**An example Susan has been reading about in the last couple of weeks:** [**ivermectin**](https://en.wikipedia.org/wiki/Ivermectin) **for cancer**

- Her point is a simple one: nature abhors a vacuum
- If you say, I’m not going to kick off people, but I’m not going to remain silent
- Take the lab leak theory for example
  - Here’s the facts, here’s the publication
- Susan thinks that the absence seeds that space to people
- She feels like the anti-vax (specifically things like autism), many people have seeded that space on social media because you are kicked in the butt if you don’t
- You can’t leave a vacuum

*A couple of Peter’s patients have sent him clips of various people claiming that ivermectin is curing people with stage IV cancer*

- For the most part, his patients are educated and affluent
- They’re sending these to him as texts, and because he’s really busy, he’s responding in a rather glib way, “*This is effing bullshit*.”
- But he usually follows it up a few minutes later with a text that says, “*Happy to discuss.*”
- They usually say, “*No Peter, I just needed to know that this was nonsense*.”
- Peter also agrees that people people shouldn’t be taking this thing on faith

Peter wants people to understand why this is such an idiotic statement

**⇒** To believe that Ivermectin cures cancer and to listen to the stories of multiple people with all sorts of different metastatic cancers that are cured, you’re almost explaining that cancer is a single disease

*Explain why at face value, the idea that anything could cure multiple forms of cancer is an impossibility*

- No doubt about it, it is an impossibility

***Every cancer has very specific biologies that allow it to grow and spread and cause humans problems***

- And that’s why you don’t go to the cancer doctor
  - You go for prostate cancer, you go for gastric cancer
- You go because the biology of each of the cancers is different

Peter goes one step further: it’s not just that colon cancer and breast cancer are as different as kidney disease and heart disease

- It’s that breast cancer with an [estrogen receptor](https://en.wikipedia.org/wiki/Estrogen_receptor#Cancer) that lights up versus a [HER2/neu](https://en.wikipedia.org/wiki/HER2#Cancer) receptor that lights up versus no receptors that lights up
  - Those pretty much have nothing in common

Susan explains, “*We use anatomy to describe where the tumors are, but it is not irrational to use different doses of medicines in combination with other doses.*”

- Earlier she talked about the preclinical, phase I, phase II, phase III
- For example, prostate cancer has been talked about a lot
  - All the information on both safety and efficacy
  - Does it work? Does it shrink the tumor?
  - Does it help them live longer?

***Susan hasn’t read anything about ivermectin doing that in patients and what the side effects are and how it could harm patients. She thinks patients deserve that kind of information.***

The other rhetoric that Peter takes issue with is, “*The pharma companies all know this works and the reason they’re keeping it from you is so that they can make more money giving ineffective drugs*.”

- Peter’s view is that pharma would be happy to have a drug like ivermectin that cured all cancer
  - Because the first thing they would do is put a slightly different modification to it to make it more efficacious, basically less side effects
  - And they would patent it and they would make all the money in the world
  - Susan being a veteran of some of the biggest pharma companies agrees

Peter adds, “*If they’re able to make $100,000 on a drug that extends your life by eight months, I promise you they will be making millions per drug if it’s curative*.”

- Such illogical arguments are put forth and it drives him bananas
- There may be human conditions for which ivermectin helps beyond what we know
- There’s an opportunity for somebody to study it

- It’s something about the elitist nature in which that was handled that has now created this terminal effect of ivermectin as a cause celeb
  - Soon someone’s going to say it cures Alzheimer’s disease
- It’s a drug that’s an anti-smarty pants drug

To Peter, that’s heartbreaking because the answer should have been

- Peter talked about this with [Joe](https://open.spotify.com/episode/5DuxGhOJSa7X0AKvJGwwta) very openly on his podcast and said, “*Look, I’ve looked at all the RCTs of ivermectin and COVID. There’s no signal, except my memory could be off on this, but there’s a little signal in this Brazilian trial. But the methodology of that trial was horrible. So I have to believe this is not working. It’s a good try, all about trying.*”
- It was a great idea to take off-the-shelf drugs and see if they worked
- When they don’t, we have to move on

***By demonizing it and by demonizing the people that felt it might work, we find ourselves in a situation right now where it’s very irrational***

**Susan worked in the President’s Council of Advisors on Science and Technology**

*They produced a* [*report*](https://bidenwhitehouse.archives.gov/wp-content/uploads/2023/04/PCAST_Public-Health-Report_May2023.pdf) *on the future of public health*

- One of the remedies for the isSusan just discussed is having a broader set of people who we think of as the public health workforce
  - People who are interested in ivermectin
  - Farmers, people who are up close and personal to some of the things with this bird flu
  - There are a number of different folks who would be really interesting to involve in public health efforts and we typically don’t

***One of the ways that we can go forward in public health is to think about: how do we define public health and what does it look like?***

**Public health has really struggled in some ways**

- You have these incredible success stories and then some awful failures
- On the surface, it’s such a great thing
  - That’s why “Make America Healthy Again” resonates with people
  - People universally want to be healthy, want to keep their families healthy

## The role of AI in transforming medicine: from drug development to cancer detection and beyond [1:53:00]

- Susan is the only person in medicine on the [board of OpenAI](https://openai.com/our-structure/#:~:text=results%20with%20everyone.-,Our%20board,-OpenAI%20is%20governed)

**Tell me how you came to serve on the board of OpenAI, what you are excited about and what you are afraid of**

- Susan joined the board almost a year ago ‒ in November 2023 they had what they call a “blip”
  - The CEO was fired and the board changed over

> “*I have been so impressed by the intellect, the commitment, the sense of responsibility of folks at OpenAI.*”‒ Susan Desmond-Hellmann

*Susan’s top 2 hopes for AI*

1 – Product development

- Susan loves product development ‒ it’s the best job on earth
  - You get to make new medicines for people who are sick
  - You go home and tell your mom and dad ‒ that they’re happy

What if we could take the tool of AI and make easy the things we can make easy

- You don’t use AI to change a clinical trial
  - You still want to know: does your tumor shrink?
    - Do you feel better?
    - Do you have side effects?
- But there’s a lot of study reports
  - There’s toxicology reports
  - There are a lot of things that are labor and paperwork that are actually very important to establishing the safety especially
  - There is also the efficacy of a drug

Susan explains, “*I think using AI more and more on pieces of the clinical trials process so that if something takes time, it’s because it’s benefiting a human, not because we just couldn’t do it fast enough*.”

- In clinical trials, there are some opportunities for that

Peter asks, “*Give me a time and money sense in terms of savings. (this is a very important question)*”

***Hypothetically, if you said the entire clinical trials program for a drug is 6 years (IND to approval), she would want to cut it down by 2 years***

- Susan thinks we could be on a path to that
- The challenge is going to be
  - If you’re changing 5-year survival, you’ve got to wait 5 years
  - You can estimate things and work with the FDA to make sure if people can benefit

Peter thinks you could argue with a **regulatory change in the FDA**

- If we said greater emphasis on safety to approval, greater emphasis on post-market surveillance for efficacy, we shift this thing a little bit
- Now, you could say at 3 years we’re trending, you get a provisional approval and now we’re going to follow you
- There’s an example like [Paxlovid](https://en.wikipedia.org/wiki/Nirmatrelvir/ritonavir) where you could argue maybe it should have been pulled
  - Maybe it wasn’t as effective as it looked in the trials
- And that doesn’t mean they were wrong to approve it, because it was any port in a storm
- But after the fact, we could have been, “*Oh, you know what? No harm, no foul. It was safe*.”

***Maybe we could do that for oncology***

Susan adds, “*The other thing is you and I both know if you have 500 patients in a trial and you look at safety, that’s so limited. If you have a much more AI driven, why don’t we follow safety in every patient on the ongoing*.”

***The opportunities in clinical trials are massive***

2 – Susan would love to see a change in the things that cause burnout of nurses and physicians and others in the hospital

**⇒** Healthcare should have tools where it’s easier to decrease the load, the burden on both caregivers and families (that should be doable)

*On the nursing front, there’s a huge demand. How much of this do you think of absent robotics?*

- Susan is not close enough to the robotics piece of it
- She thinks the greatest opportunity is trying to connect all the dots

***What AI does so brilliantly is it just takes a lot of data and it comes out with observations***

- If there are ways that that can assist at the bedside, that’s a massive improvement
- Especially when people are changing
  - Susan relates to this: moving from the University of Washington to UCSF ‒  it’s so hard to change caregivers, to change health systems
- Those kinds of things can decrease workloads
- She also thinks it’s the kinds of things where clinical observations could be AI driven

**The** [**Nobel Prize last year**](https://www.nobelprize.org/prizes/chemistry/2024/press-release/) **was awarded for protein folding, AI driven analysis. Explain to people what that is significant.**

*How much do you think that particular achievement is going to advance biotechnology and what remains ahead of it as far as even greater molecule selection?*

- This is pre-preclinical
- This is figuring out what you’re going to do
  - If you can make figuring out that much faster (which they did), you are going to have the opportunity
- It’s a start, and it’s great that they were recognized

*Do you think this is the most important thing from a promise perspective that AI has brought to medicine since?*

- Yeah, so far

**What do you think would be the next mega unlock?**

*Would it be on the data front? Would it be a predictive model? How could we shorten a clinical trial by 60%?*

- Anything where AI can help us with outcome measures
- Susan’s husband is an HIV doc, and when they were both at Bristol Myers Squibb, she was doing 2-by-2 measurements of tumors on x-rays for Taxol and he was looking at viral load
  - Viral load allowed them to have 20 HIV drugs in 5 years
  - It was crazy how good it was
  - Susan explains, “*I want a viral load for everything*.”

***We need a good biomarker for more things***

Peter mentioned earlier all the different types of breast cancer: ER-positive, ER-negative, HER2-positive, triple negative

- What if there’s actually 15?
  - There probably are
- Then you’re in 15 trials, but you only need 10 patients in each trial because it’s so obvious you have the perfect remedy for each of those patients
- Susan thinks of it as the switch is on, turn it off and you see clinical benefit
- Anything we do that sets up like that, especially if we can not just measure switch on, but switch off
  - That’s why viral load is so powerful

**What is your level of optimism or pessimism around liquid biopsies and do you think that AI can help us with these?**

- She has been pretty negative based on the data
  - She has not seen the data that suggest that we’re helping on the sensitivity front
- Can AI help us? Possibly
- The problem is just really hard

Peter asks, “*Do you think the problem is [that] tumors don’t shed enough DNA?*”

- That appears to be the problem because if they did, Susan thinks it would work
- That’s the most important problem

**Susan doesn’t think it’s easy to do early detection**

- The other problem is something that I think we all tend to underestimate: preventative therapy
  - She loves the concept of prevention
  - Part of “Make America Healthy Again” is we’ll go to preventive therapy and stop all these
- She understands that in oncology we’ve often celebrated tiny successes, but you can’t have big successes before you have tiny successes

*3 things that work in early detection*

- 1 – The [colonoscopy](https://en.wikipedia.org/wiki/Colonoscopy) works
- 2 – For cervical cancer, a [pap smear](https://en.wikipedia.org/wiki/Pap_test) works even better
  - [HPV vaccine](https://en.wikipedia.org/wiki/HPV_vaccine)
- 3 – And now you can do a [spiral CT](https://en.wikipedia.org/wiki/Operation_of_computed_tomography#Spiral) for lung cancer

***She’s not even using one handful of fingers, and we’ve been trying to do early detection as long as she’s been an oncologist***

- Peter would add [PSA](https://en.wikipedia.org/wiki/Prostate-specific_antigen) in the hands of somebody who understands what to do with it
  - PSA by itself is pretty bad
  - PSA density, when you know prostate volume and PSA velocity when you have serial measurements starts to become very predictive
    - [discussed in [episode #273](https://peterattiamd.com/tedschaeffer2/#:~:text=grapes%2C%20broccoli%2C%20tomato-,Deep%20dive%20into%20PSA%20as%20a%20screening%20tool%3A%20what%20is%20PSA%2C%20definition%20of%20terms%2C%20and%20how%20to%20interpret%20results%20%5B1%3A56%3A30%5D,-Explain%20what%20PSA) after 1:56:30]
  - You take a man who has not had a prostate biopsy and you stratify his PSA according to PSA density, the ability to predict if he has a Gleason 3+3 or 3+4 or 4+3 is really quite high
  - And at least you can then stratify those patients more quickly into a [phi](https://www.beckmancoulter.com/products/immunoassay/phi) or a [4K](https://4kscore.com/), and ultimately decide: do they need a multi-parametric MRI and you go down that path
    - So it’s not turnkey
  - Peter completely understands why they’ve said, “*We’re going to make no recommendation.*”
  - Peter takes comfort in knowing
  - Too many men are dying of prostate cancer ‒ it should not be the third leading cause of cancer death
  - Yet he understands that it’s a big ask to get every doctor fully up to speed on the algorithm

Susan recognizes, “*You know what you just said? That’s something that if someone wanted to start a company, they could simplify that and make something more turnkey for patients and physicians.*”

- Yes

**⇒** When you go through the 4 leading causes of cancer death, 2 of them don’t need to be on the list: colon cancer and prostate cancer don’t need to be on the list

- **Lung cancer**: Peter thinks we can reduce it a lot, but it’s going to be awfully tough
- **Breast cancer** is still really tough because it’s not [Halstedian](https://pmc.ncbi.nlm.nih.gov/articles/PMC8183350/#:~:text=Halsted's%20%E2%80%9Cradical%20mastectomy%E2%80%9D%2C%20as,desmoplastic%20reaction%20are%20mistaken%20for)
  - It doesn’t have that straightforward progression from polyp to cancer
- The beauty of colonoscopy is you can just take out the polyp

**Let’s talk about breast cancer. What would be the earliest signature in the blood of different breast cancers?**

*Think about how that would change breast cancer treatment*

- It would be interesting to look at protein

Peter says the following deliberately not acknowledging her gender because he’s sure she hears all the time, “*Sue, you are the most remarkable example of a woman in medicine*.”

> “*Gender aside, you are just a remarkable inspiration, period. As a physician, as a business leader, as a public health official, I have been a fan of yours for so long*.”‒ Peter Attia

- When he walked into that room last year and saw her sitting there, he was giddy

Peter ends with, “*Thank you for humoring me and making the trip.*”

---

## Selected Links / Related Material

**AIDS foundation in Africa**: [Elizabeth Glaser Pediatric AIDS Foundation](https://pedaids.org/) (2025) | [21:30]

**President’s Council of Advisors on Science and Technology report on public health**: [Supporting the U.S. Public Health Workforce](https://bidenwhitehouse.archives.gov/wp-content/uploads/2023/04/PCAST_Public-Health-Report_May2023.pdf) | Executive Office of the President: President’s Council of Advisors on Science and Technology (2023) | [1:51:45]

---

## People Mentioned

- [Steven Rosenberg](https://ccr.cancer.gov/staff-directory/steven-a-rosenberg) (Senior Investigator, Chief of Surgery Branch, and Head of Tumor Immunology Section at NCI) [9:00]
- [Palmer Beasley](https://en.wikipedia.org/wiki/R._Palmer_Beasley) (1936-2012, physician, public health educator, and epidemiologist who established that hepatitis B virus caused liver cancer) [12:00]
- [Nick Hellmann](https://people.equilar.com/bio/nicholas-hellmann-monogram-biosciences/197658) (Former Vice President, Clinical Research at Monogram Bioscience, Susan’s husband) [13:00, 16:00]
- [John Ziegler](https://globalcancer.ucsf.edu/people/john-ziegler) (Professor Emeritus of Medicine at UCSF, discovered viral causes of Burkitt’s lymphoma and Kaposi sarcoma, known for his work in Uganda) [15:00]
- [Edward Katongole-Mbidde](https://en.wikipedia.org/wiki/Edward_Katongole-Mbidde) (Ugandan physician, academic, and medical oncologist; former director of the Uganda Virus Research Institute) [16:15]
- [Bob Gallo](https://en.wikipedia.org/wiki/Robert_Gallo) (biomedical researcher best known for his role in establishing HIV as the cause of AIDS; co-founder of the Institute of Human Virology at the University of Maryland School of Medicine, co-founder of Profectus Biosciences, and co-founder and scientific director of the Global Virus Network) [20:00]
- [Luc Montagnier](https://en.wikipedia.org/wiki/Luc_Montagnier) (1932-2022, French virologist best known for his role in establishing HIV as the cause of AIDS; researcher at the Pasteur Institute in Paris and Professor at Shanghai Jio Tong University in China)  [20:00]
- [Herbert Boyer](https://en.wikipedia.org/wiki/Herbert_Boyer) (Biotechnology researcher, former Professor at UCSF, and Co-founder of Genentech) [36:30, 46:00]
- [Robert Swanson](https://en.wikipedia.org/wiki/Robert_A._Swanson) (1947-1999, venture capitalist and Co-founder of Genentech) [36:30]
- [David (Dave) Stump](https://ir.macrogenics.com/board-directors/david-stump-md) (clinician researcher, clotting expert, on the board of directors for Macrogenics) [42:00]
- [Eugene Braunwald](https://www.heart.org/en/news/2024/11/15/how-dr-eugene-braunwald-changed-cardiology) (distinguished Hersey professor of medicine at Harvard Medical School and cardiologist at Brigham and Women’s Hospital) [42:30]
- [Robert Califf](https://en.wikipedia.org/wiki/Robert_Califf) (cardiologist and former head of the FDA) [42:45]
- [Eric Topol](https://www.scripps.edu/faculty/topol/) (Cardiologist, scientist, author, and founder and director of the Scripps Research Translational institute where he is a professor and chair of the Department of Translational Medicine) [42:45]
- [Arthur Levinson](https://en.wikipedia.org/wiki/Arthur_D._Levinson) (Businessman and chairman of Apple, former chairman of Genentech) [44:30]
- [Judah Folkman](https://en.wikipedia.org/wiki/Judah_Folkman) (1933-2008, surgeon-in-chief of Children’s Hospital Boston and Professor of Cell Biology and Pediatric Surgery at Harvard; he founded the field of angiogenesis research) [57:00]
- [Napoleone Ferrara](https://profiles.ucsd.edu/napoleone.ferrara) (Distinguished Professor of Pathology and Adjunct Professor of Ophthalmology and Pharmacology at UCSD, expert in angiogenesis) [58:30]
- [Lloyd Hollingsworth (Holly) Smith](https://pmc.ncbi.nlm.nih.gov/articles/PMC6118641/) (Served as the chair of the Department of Medicine and associate dean in the UCSF School of Medicine for 35 years) [1:16:15]
- [William (Bill) Rutter](https://synergenics.net/management) (Professor of Biochemistry and Biophysics at UCSF who founded Chiron Corporation, currently Chairman & CEO of Synergenics) [1:16:30]
- [Michael Bishop](https://profiles.ucsf.edu/j.michael.bishop) (Chancellor Emeritus and Professor Emeritus of microbiology and Immunology, Director of the GW Hooper Foundation, shared the Nobel Prize in Medicine with Harold Varmus in 1989 for cancer research) [17:00]
- [Sam Hawgood](https://profiles.ucsf.edu/sam.hawgood) (Chancellor and Arthur and Toni Rembe Rock Distinguished Professor at UCSF) [1:22:30, 1:29:30]
- [John Ford](https://www.case.org/john-b-ford) (Vice Chancellor Emeritus of University Development and Alumni Relations at UCSF) [1:23:30]
- [Mark Yudof](https://www.law.berkeley.edu/our-faculty/faculty-profiles/mark-yudof/#tab_profile) (UC President Emeritus, Professor of Law Emeritus at UC Berkeley) [1:25:00]
- [Melinda Gates](https://en.wikipedia.org/wiki/Melinda_French_Gates) (Philanthropist and co-founder of the Bill & Melinda Gates Foundation) [1:26:15]
- [Bill Gates](https://en.wikipedia.org/wiki/Bill_Gates) (Businessman and philanthropist best known for co-founding Microsoft and the Bill & Melinda Gates Foundation) [1:26:15]
- [Hal Barron](https://en.wikipedia.org/wiki/Hal_V._Barron) (Former VP of medical affairs at Genentech, President of R&D at GlaxoSmithKline and other biotech, founder and CEO of Altos Labs) [1:37:30]

---

![](https://peterattiamd.com/wp-content/uploads/2025/04/Sue_Desmond-Hellman.jpeg)

##### Susan Desmond-Hellmann, M.D., M.P.H.

Susan Desmond-Hellmann earned a Bachelor of Science degree and medical degree at the University of Nevada. She completed her clinical training in internal medicine and oncology at UCSF, and earned a Master’s in Public Health from UC Berkeley. Dr. Desmond-Hellmann joined the faculty at UCSF as Associate Adjunct Professor of Epidemiology and Biostatistics. Soon thereafter, she worked for two years as a visiting faculty at the Uganda Cancer Institute where she studied HIV/AIDS and Cancer. When she returned to the US, she worked for two years as a medical oncologist in private practice before returning to clinical research.

Dr. Desmond-Hellman has spent her career working as a physician-scientist, she is a member of the National Academy of Medicine, and has held a number of high-profile leadership roles. She worked for Genentech from 1995-2009 first as a clinical scientist, then chief medical officer, and executive vice president (and later president) of development and product operations. She led the development of Herceptin®. In 2009, she became UCSF’s ninth chancellor and first woman to hold the position. During this time she championed the new field of precision medicine. She served as a member of the National Institutes of Health’s advisory committee on the National Center for Advancing Translational Science and co-chaired a National Academy of Sciences committee that produced the report, “[Toward Precision Medicine: Building a Knowledge Network for Biomedical Research and a New Taxonomy of Disease](https://nap.nationalacademies.org/catalog/13284/toward-precision-medicine-building-a-knowledge-network-for-biomedical-research).” Dr. Desmond-Hellmann stepped down from chancellor of UCSF in 2014 to become the CEO of the Bill & Melinda Gates Foundation, a position she held for six years. She has served as a board member at Pfizer since 2020. In 2021, she was appointed to the President’s Council of Advisors on Science and Technology. In 2024, she became a member of the Board of Directors at OpenAI. Dr. Desmond-Hellmann also serves in leadership roles for a number of non-profit organizations including the Global He@lth 2030 Innovation Task Force, California Academy of Sciences, and Howard Hughes Medical Institute. [[UCSF Library](https://history.library.ucsf.edu/desmond_hellman.html)]