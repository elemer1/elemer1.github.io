# #12 – Corey McCarthy: Overcoming trauma, dealing with shame, finding meaning, changing the self-narrative, redemption, and the importance of gratitude

**Source:** [https://peterattiamd.com/coreymccarthy/](https://peterattiamd.com/coreymccarthy/)

---

Corey and Peter met when they visited North Kern State Prison in California together as volunteers for Defy Ventures. Peter was moved by Corey’s remarkable story, who is a former inmate himself, and realized he had to have him on the podcast to share his experiences with a wider audience. You’ll almost assuredly take away something very important from listening to this episode. Understanding how your experiences can define you, what forgiveness means of both yourself and others, and how good people can do bad things, are just a few of the takeaways.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/coreymccarthy/the_Drive_public.png)

Play

#12 - Corey McCarthy: Overcoming trauma, dealing with shame, finding meaning, changing the self-narrative, redemption, and the importance of gratitude

#12 - Corey McCarthy: Overcoming trauma, dealing with shame, finding meaning, changing the self-narrative, redemption, and the importance of gratitude

1x15s30s

0:002:27:00

## We discuss:

- How Corey and Peter met through Defy Ventures [4:00];
- How Corey’s prison experience has shaped his life story [13:30];
- Corey’s early life, and the traumatic event that changed everything [16:00];
- Early adolescence years, beginnings of addiction, and overwhelming shame [23:00];
- The 5 ways to classify wounds, and the relationship between trauma and addiction [39:00];
- Turbulent high school years, the struggle of parenting a troubled child, and more trauma further shaping the self-narrative [46:00];
- Post-high school years, spiraling out of control, and giving up on himself [1:02:00];
- Navigating prison life, and why a desire to change often isn’t enough to make it happen [1:19:00];
- The turning point and eventual road to recovery [1:48:00];
- 12-step programs: Pros and Cons [1:54:00];
- Final days in prison, getting released, and routines Corey has kept [1:54:00]
- Corey’s new perspective on life, takeaways from the visit to Kern prison [2:12:30]; and
- More.

§

## Show Notes

## How Corey and Peter met through Defy Ventures [4:00]

- Introduced through mutual friend, Devin, and met for the first time in the 6-hour car ride to [North Kern State Prison](https://www.cdcr.ca.gov/Facilities_Locator/NKSP.html) to visit with inmates through the [Defy Ventures](https://defyventures.org/) program
- [Catherine Hoke](https://twitter.com/catherine_hoke) founded Defy Ventures and Peter became interested in her work after hearing her on the [podcast episode](https://tim.blog/2018/01/21/catherine-hoke/) with [Tim Ferriss](https://twitter.com/tferriss)
- Peter and Corey were part of the small group (lead by Tim Ferriss) to [visit Kern Prison](https://tim.blog/2018/06/25/tim-ferriss-goes-to-maximum-security-prison/)
- Corey’s initial skepticism of Defy and what made him come around to its validity
- “One of the most important things I’ve done in my life” —Peter on visiting Kern
- “Pain is how we’re all tethered together” —Corey

## How Corey’s prison experience has shaped his life story [13:30]

- 7 years, 3 months, 10 days in prison
- Corey sees his value as someone who has “made it” on the outside, but also someone who is willing and able to “come back” to tell his story and provide hope to others
- Writing a book based on his journaling in prison and using those funds to support people like Cat Hoke
- “Endure and overcome” is a saying that got Corey through prison

## Corey’s early life, and the traumatic event that changed everything [16:00]

- Grew up in Buffalo NY in a good home, older brother and sister, both parents were successful attorneys
- Normal kid, athletic, happy
- When he was 7, he was attacked in a public bathroom
  - Stole his innocence, as well as his trust in adults
  - Corey would come to find out that a lot of damage was done that day
- Blamed himself, as if he deserved it, and began telling himself the narrative that he wasn’t a “good” kid and that’s why he was attacked.
- This event likely transformed Corey from: innocent child => wounded child => adaptive child with stunted growth in maturity
- Parents recognized something was wrong (many parents don’t), but we’re unsure what to do, tried therapy (among other things), but nothing seemed to help
- “I didn’t feel valuable…I felt like something was wrong with me” —Corey on how therapy might have made it worse because it made him feel different

## Early adolescence years, beginnings of addiction, and overwhelming shame [23:00]

- Corey, a tad mischievous but typical kid, had 2 traumatic events in this time period further shaping his negative self-narrative that he was “bad”
  - Arrested at age 12 for a minor offense but an aggressive cop punched him in the face dropping him to the pavement
  - He lost his virginity at 13 and was got in the act by a group of peers and teachers at a school dance.
- Corey’s transgressions progressed to drinking and marijuana
- Overwhelming shame (*Why me? What’s wrong with me? Why am I always in trouble?*) lead Corey to attempt suicide by overdosing Tylenol
- Corey on the danger of drugs: “You don’t solve your problems with drugs use…but they take you out of yourself”
- *“Which list are you looking at?” —*A phrase Corey now uses the express the idea that you have the ability to shift your perspective from a negative view to a positive view

## The 5 ways to classify wounds, and the relationship between trauma and addiction [39:00]

- Peter is fascinated by the strong relationship between trauma and addiction.
- When we think addiction, we think about substance addictions, but commonly people have [process and behavioral addictions](https://americanaddictioncenters.org/behavioral-addictions/) like workaholics, perfectionism, control, etc

The Trauma Tree (5 ways to classify wounds):

1. Abuse (physical, sexual, emotional, spiritual)
2. Abandonment
3. Neglect
4. [Enmeshment](https://en.wikipedia.org/wiki/Enmeshment)
5. Witnessing a tragic event

These create shame, and then if not dealt with appropriately as an adult can result in:

- Addiction
- Codependency
- Attachment disorders
- Habituated survival strategies
- Embedded in that is dysregulated emotion (anger, emotional volatility)

As a child, abuse, neglect, and abandonment always go hand-in-hand… and your parents should be the ones protecting you, and if they don’t, you can be affected

People tend to minimize their own personal trauma, a therapist once told Peter, “Picture your children at the age you were at when you had the experiences you had … and contrast your reaction to that to how you treated it when it was yourself”

## Turbulent high school years, the struggle of parenting a troubled child, and more trauma further shaping the self-narrative [46:00]

- Bounced around high schools after being kicked out of private school
- Parents were at a loss, couldn’t figure out the root of this bad behavior and self-destruction
- Corey was sent to a child psychiatric unit, parents had good intentions but this experience furthered Corey’s self-narrative that he was different, and a bad person
- Admitted to juvenile rehab, but Corey was eventually kicked out of that for bad behavior, first thing he did was go buy alcohol, first *self*-realization that he might have a substance addiction
- Parents split up leaving Corey with a feeling of abandonment
- Corey dropped out of high school and landed in the hands of a predator disguised as a “cool dad” of one of his friends
- This person exploited Corey’s vulnerability, abused him in many ways, pushed him to use and sell drugs
- Corey considers himself a believer in tolerance and second chances but he admittedly has no patience for child abusers
- At this point, Corey’s self-narrative has fully set in sending him down a dark path (part of why he believes in the work of Cat Hoke is that she emphasizes “changing the narrative”)

## Post-high school years, spiraling out of control, and giving up on himself [1:02:00]

- At 19 years old, while trying to protect his friend Corey was physically beaten so badly by a group of hockey players that he required 2 emergency brain surgeries
- Corey credits the brain surgeon for his saving his life with his swift and professional work (crazy chance story: on his flight to NY to talk with Peter, he sat next to the cousin of this doctor)
- His life to him feels like an on-going crazy story
- After the hockey game experience, Corey transitioned to being more violent
- He started to be more offensive, “If I think you are going to hurt me I’m going to hurt you first”
- Arrested 7 times in one year at age 20, meanwhile, his girlfriend was pregnant with his daughter
- By age 22, his life was “way out of control”: selling drugs, robbing other drug dealers, owned many guns
- There were a lot of periods of getting clean and trying to stay sober, but each time the self-narrative would play in his head, *“What are you doing? You’re a bad person, you’re a failure, don’t bother trying to be good”*
- “I’m tired of trying to be good and failing at it” —Corey’s response when asked, *why are you doing these things? This isn’t who you are*
- Ultimately, the life caught up with him, and after shooting someone, he was sentenced to 8.5 years in prison

## Navigating prison life, and why a desire to change often isn’t enough to make it happen [1:19:00]

- Relieved when sent to prison because it meant he’d be taken away from the life he was living
- Prison was safer, had more structure, fewer choices to make
- “If it doesn’t make sense, instead of getting mad, something is wrong” —Corey’s advice to someone observing self-destructive behavior
- Going to prison is “like a new high school…but with knives and heroin”
- Corey continued downward before things eventually turned around for him
- Spent a lot of time in solitary
- Avoided gang affiliation, “gang leaders are ‘pimps’ who just hurt kids”
- Used journaling, reading, and weekly phone calls with his daughter to get through hard times
- Are many criminals just traumatized children whose growth was stunted?
- Why do so many prisoners never make it out? “Fear of failure and lack of hope”
- Prisoners are in desperate need of a playbook (such as Defy) because they lack the strategy and tactics to lead a good life
- “I felt like I was born bad…I had owned it at that point” —Corey

## The turning point and eventual road to recovery [1:48:00]

A culmination of things lead to a turning point for Corey:

- Love of his daughter and not wanting to let her down
- Friends and family who believed in him even when he didn’t
- Reading and studying a lot of books (mentioned The Four Agreements)

For the changes to stick, Corey admitted he first needed:

1. A shift in attitude from complaining to being grateful for circumstances
2. To stop caring about what other people thought

He eventually started to believe that it was okay to treat himself good and try to be better himself

But it was a continuous struggle to change the inner narrative that had been developed through his entire life that he was a bad person and fighting through the shame and regret

## 12-Step programs: Pros and Cons [1:54:00]

While not perfect, Peter believes a 12-step program can be a “powerful process” for some people, but treating these programs like a religion is where it can become problematic.

Corey has mixed emotions about these programs but he does like the synthesized steps:

1. Admit fault
2. Clean house
3. Help others

Pulling from the [Tim Ferriss podcast with Cat Hoke](https://tim.blog/2018/01/21/catherine-hoke/), Corey describes the evolution of individuals making a recovery as follows:

1. I can’t handle this
2. I need some help
3. I believe I can receive the help and change this
4. What’s my fault?
5. Here’s the things I’ve done, am I really that bad?
6. How can I fix those things?
7. Take an inventory
8. How can I help others?

Peter tends towards taking a [Bruce Lee](https://en.wikipedia.org/wiki/Bruce_Lee) approach (Bruce Lee created [Jeet Kune Do](https://en.wikipedia.org/wiki/Jeet_Kune_Do) by taking useful pieces and discarding unuseful pieces from various forms of martial arts) and pulling out the various pieces of various 12 step programs that you find useful and discarding the rest.

Corey says Alcoholics Anonymous (AA) gave him a kind of curriculum/playbook to develop morals

“Some really important things for me in life are gratitude and humility” —Corey

## Final days in prison, getting released, and routines Corey has kept [1:54:00]

- Corey says he was ultimately given a bit more than 7 years after improving his behavior dramatically over the last few years
- Was he scared to leave prison? “Terrified”
- The day of his release, Corey had a profound chance meeting with someone from his past who said, “As long as you stay clean, this shit will be a breeze”
- Corey has developed a knack for detecting the inner feelings of people who’ve been through trauma and has a unique ability to connect with them.
- “You are your biggest enemy” —Corey referencing a common roadblock to recovery
- Corey and Peter both fantasize about catching predators who steal the innocence of children.

What habits or routines that got Corey through prison has he kept or continued?

- Exercise: pull-ups, dips, push-ups, running
- Yoga, meditation, stretching
- Reading
- Helping others

## Corey’s new perspective on life, takeaways from the visit to Kern prison [2:12:30]

- Corey has a developing sense of self-worth but still has to fight back feelings of “I don’t deserve this”
- Corey says his day at Kern made him realize that his suffering was for a reason so that he could give back to the guys in there
- Corey no longer believes in accidents
- Peter believes the world would be a better place if everyone on the outside went and spent one day in the prison with Defy ventures
- Peter says he got way more out of the experience than he gave to the inmates
- “Somehow, someway, we’ve got a find a way to connect as humans or else we’re kind of fucked…” – Corey McCarthy

§

§

## Selected Links / Related Material

- **Prison that Peter, Corey, Tim Ferriss, and others visited through Defy Ventures**: [North Kern State Prison](https://www.cdcr.ca.gov/Facilities_Locator/NKSP.html) | ([cdcr.ca.gov](https://www.cdcr.ca.gov/)) [00:45, 4:00, 2:12:45]
- **Program started by [Cat Hoke](https://twitter.com/catherine_hoke) that works with inmates to give them hope and a playbook for future success**: [Defy Ventures](https://defyventures.org/) | ([defyventures.org](https://defyventures.org/)) [1:00, 4:45, 1:46:00, 2:12:45]
- **Podcast episode that spurred Peter’s interest in Cat Hoke’s work**:[The Tim Ferriss Show: Catherine Hoke — The Master of Second Chances (#293)](https://tim.blog/2018/01/21/catherine-hoke/) | Tim Ferriss ([tim.blog](https://tim.blog/)) [1:00, 7:30, 1:55:45]
- **Powerful commencement speech that Peter shared with the group during their road trip to Kern**: [This Is Water – Full version-David Foster Wallace Commencement Speech](https://www.youtube.com/watch?v=8CrOL-ydFMI) | Jamie Sullivan (youtube.com) [13:00]
- **Dark chocolate eaten on the road trip to Kern**: [Hu Chocolate](https://hukitchen.com/collections/chocolate) | ([hukitchen.com](https://hukitchen.com/)) [13:30]
- **The wounded and** adaptive **child**: [The Wounded Child, Adaptive Child & Functioning Adult](https://recoveryhelpnow.com/2010/12/25/591/) | (recoveryhelpnow.com) [19:45]
- **Book recommendation about addiction**: [In the Realm of Hungry Ghosts](https://www.amazon.com/Realm-Hungry-Ghosts-Encounters-Addiction/dp/155643880X/ref=sr_1_1?ie=UTF8&qid=1534536310&sr=8-1&keywords=in+realm+of+hungry+ghosts) by [Gabor Maté](https://en.wikipedia.org/wiki/Gabor_Mat%C3%A9_(physician)) | ([amazon.com](https://www.amazon.com/)) [40:40]
- **Form of abuse when parents “treat kids like little adults”**: [Enmeshment](https://en.wikipedia.org/wiki/Enmeshment) | (wikipedia.org) [43:30]
- **Catholic Church abuse scandal**: [Catholic Church sex abuse cases in the United States](https://en.wikipedia.org/wiki/Catholic_Church_sex_abuse_cases_in_the_United_States) | ([wikipedia.org](https://www.wikipedia.org/)) [58:00]
- **Movie about how one small change to your past can dramatically change the future**: [The Butterfly Effect](https://en.wikipedia.org/wiki/The_Butterfly_Effect) | ([wikipedia.org](https://www.wikipedia.org/)) [1:15:15]
- **Prison where Corey spent some time and compared it to [Shawshank Redemption](https://en.wikipedia.org/wiki/The_Shawshank_Redemption)**: [Elmira Correctional Facility](https://en.wikipedia.org/wiki/Elmira_Correctional_Facility) | (wikipedia.org) [1:33:15]
- **Book that Corey read in prison that was helpful in his recovery process**: [The Four Agreements: A Practical Guide to Personal Freedom (A Toltec Wisdom Book)](https://www.amazon.com/Four-Agreements-Practical-Personal-Freedom/dp/1878424319/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=) by [Don Miguel Ruiz](https://en.wikipedia.org/wiki/Don_Miguel_Ruiz) | ([amazon.com](https://www.amazon.com/)) [1:50:00]
- **Commonly used program that helps people with trauma and addiction**: [Twelve-step program](https://en.wikipedia.org/wiki/Twelve-step_program) | ([wikipedia.org](https://www.wikipedia.org/)) [1:54:00]
- **The Scarborough Rapist**: [Paul Bernardo](https://en.wikipedia.org/wiki/Paul_Bernardo) | (wikipedia.org) [2:02:00]

§

§

## People Mentioned

- [Tim Ferriss](https://twitter.com/tferriss) (took Peter and Corey to Kern Prison) [00:45, 4:00, 1:54:00]
- [Catherine Hoke](https://twitter.com/catherine_hoke) [1:00, 7:00, 1:01:30]
- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) (This is Water [commencement speech](https://www.youtube.com/watch?v=8CrOL-ydFMI)) [13:00]
- [Dennis the Menace](https://en.wikipedia.org/wiki/Dennis_the_Menace_(film)) (fictional character, mischievous child Corey compared himself to) [23:00]
- [Gabor Maté](https://en.wikipedia.org/wiki/Gabor_Mat%C3%A9_(physician)) (author of [In the Realm of Hungry Ghosts](https://www.amazon.com/Realm-Hungry-Ghosts-Encounters-Addiction/dp/155643880X/ref=sr_1_1?ie=UTF8&qid=1534536310&sr=8-1&keywords=in+realm+of+hungry+ghosts)) [40:40]
- [Samuel Amoia](https://samuelamoia.com/about.html) (interior designer in NY, friend of Corey) [54:45]
- [Carlos Castaneda](https://en.wikipedia.org/wiki/Carlos_Castaneda) (author that Corey read a lot in prison) [1:50:00]
- [Bruce Lee](https://en.wikipedia.org/wiki/Bruce_Lee) (created [Jeet Kune Do](https://en.wikipedia.org/wiki/Jeet_Kune_Do) by taking the most useful pieces from various forms of martial arts) [1:56:30]
- [Goo Goo Dolls](https://en.wikipedia.org/wiki/Goo_Goo_Dolls) (first music listened to when Corey got out of prison) [2:07:00]
- [Paul Conti](https://www.pacificpremiergroup.com/meet-our-team/) (Peter’s friend that’s a psychiatrist who is an upcoming podcast guest) [2:24:00]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/08/1Y8A0296_preview-e1535305317580-445x500.jpeg)

##### Corey McCarthy

Corey McCarthy lives in Buffalo, New York with his girlfriend and three children. He is the founder and owner of McCarthy I.E., a company that specializes in the restoration of historic churches and architectural homes. At age seven Corey was attacked by a stranger in a public place which altered his life significantly. One traumatic event led to the next, the result being years of addiction, visits in rehab facilities, jails, mental inpatient services, homelessness and eventually an extended stay of seven-plus years in N.Y.S correctional system. Defying the odds, Corey has endured and overcome. He embraced a new narrative of gratitude and hope. Because of the changes he’s made he has built a strong business with a family of employees. He has built a loving home. His life’s work is most certainly the time he spends on a daily basis doing whatever he can to help others change their narrative, anyone who feels damaged, dirty, alone or just plain not good enough. This is where he derives true meaning and purpose.

Twitter: [@coreymccarthyie](https://twitter.com/coreymccarthyie)