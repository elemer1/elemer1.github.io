# #260 ‒ Men’s Sexual Health: why it matters, what can go wrong, and how to fix it | Mohit Khera, M.D., M.B.A., M.P.H.

**Source:** [https://peterattiamd.com/mohitkhera/](https://peterattiamd.com/mohitkhera/)

---

Mohit Khera is a world-renowned urologist with expertise in sexual medicine and testosterone therapy. In this episode, Mohit provides a comprehensive overview of male sexual health. He begins with an in-depth exploration of erectile dysfunction, shedding light on its prevalence across different age groups, diagnostic methods, and its intriguing connection to cardiovascular disease. He then ventures into Peyronie’s disease, penile fractures, penile enlargement treatments, prolonged erections, premature ejaculation, and anorgasmia. Shifting gears, Mohit delves into the intricate workings of testosterone, DHT, and estrogen, emphasizing their physiological significance and interplay. He explains blood tests for diagnosing low testosterone, the correlation between symptoms and blood levels in cases of low testosterone, and the pros and cons of different methodologies for increasing testosterone. He concludes with a thought-provoking conversation about the role of testosterone in patients with prostate cancer and addresses concerns surrounding DHT, finasteride, and post-finasteride syndrome.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/mohitkhera/the_Drive_public.png)

Play

#260 ‒ Men's Sexual Health: why it matters, what can go wrong, and how to fix it | Mohit Khera, M.D., M.B.A., M.P.H.

#260 ‒ Men's Sexual Health: why it matters, what can go wrong, and how to fix it | Mohit Khera, M.D., M.B.A., M.P.H.

1x15s30s

0:002:33:12

## We discuss:

- Mohit’s career path and interest in sexual medicine and infertility [3:00];
- The anatomy of the male genitalia [5:45];
- The prevalence of sexual dysfunction, its impact on quality of life, and the importance of seeking help [7:15];
- Erectile dysfunction (ED): definition, diagnosis, pathophysiology, and more [11:00];
- The history of medications to treat ED and the mechanisms of how they work [15:30];
- Relationship between aging and erectile dysfunction and Mohit’s approach to treating patients and prescribing medications [20:00];
- The impact of lifestyle on sexual health and the association between ED and cardiovascular disease [29:30];
- Causes and treatments for Peyronie’s Disease, penile fracture, and more [37:30];
- The value of ultrasound for ED diagnosis and management strategies [47:45];
- Various treatment options for ED: injections, penile prosthesis, and more [50:15];
- Priapism (prolonged erection): what is happening and when to seek treatment [57:15];
- Shockwave therapy as a treatment for ED [1:02:45];
- Stem cell therapy for ED [1:08:15];
- Platelet-rich plasma (PRP) injections as a treatment for ED [1:12:00];
- Premature ejaculation (PE): prevalence, pathophysiology, and treatment [1:14:45];
- Anorgasmia: causes and treatment [1:22:00];
- The interplay of sex hormones, the impact of aging, symptoms of low testosterone, and considerations for testosterone replacement therapy (TRT) [1:26:45];
- Methods for increasing endogenous testosterone [1:38:45];
- Testosterone replacement therapy: various forms of exogenous testosterone, weighing risk vs. reward, and more [1:52:30];
- The physiology and purpose of testosterone and DHT, why some men feel fine even with “low” testosterone, personalized approaches to treating low testosterone, and more [2:02:30];
- Post-finasteride syndrome [2:09:00];
- The role of testosterone in prostate cancer and addressing the notion that TRT could increase risk [2:16:15];
- The effects of testosterone as an adjunct to therapy for estrogen-sensitive breast cancer in women [2:27:15];
- Resources for those looking for healthcare providers [2:28:45]; and
- More.

[fusebox\_full\_player social\_twitter=”true” social\_facebook=”true” social\_linkedin=”true” social\_pinterest=”true” social\_email=”true” ]

§

## Show Notes

\***Notes from intro**:

- Mohit Khera is a Professor of Urology at Baylor College of Medicine
- He is also a renowned expert in male and female sexual dysfunction, declining testosterone levels in aging men, and male infertility
- This episode is a follow-up to last week’s episode with Dr. Sharon Parish, which focused on sexual health in females
- This episode focuses on the other side of that conversation ‒ all things related to male sexual health
- We start by talking about erectile dysfunction
  - We speak about the percentage of men who deal with this issue at various ages
  - The way it is diagnoses
  - What we know about erectile dysfunction and cardiovascular disease
  - Treatment with drugs, shockwave therapy, stem cells, PRP, and lifestyle modification
- We then talk about Peyronie’s disease (which is a curvature of the penis), causes and treatments
  - Discussions around penile fractures and what is known about penile enlargement treatments
- We speak about what happens when a person has an erection for over four hours
- We discuss causes and treatments of premature ejaculation and anorgasmia (delayed orgasms)
- We then shift the conversation to talk about testosterone including the physiology of how testosterone, DHT, and estrogen work
  - How we should think about them, and why they all matter
- We talk about which blood panels you should use to measure your testosterone, and the difference between the blood levels and the symptoms you might see in the case of low testosterone
- We talk about testosterone replacement therapy and the various ways to increase testosterone
  - The use of pellets, topical formulations, injectable formulations, oral formulations, and intranasal formulations
- We discuss the role of testosterone in patients with prostate cancer
- We end the conversation talking about DHT, finasteride, and some of the concerns around post-finasteride syndrome
- This conversation is really a tour de force as it relates to various topics around sexual health in males

## Mohit’s career path and interest in sexual medicine and infertility [3:00]

**Can you tell us about your background and what you did after medical school as it relates to your current work?**

- Mohit went to Vanderbilt for college, after which he attended Boston University where he got his Master’s of Business Administration (M.B.A.) and Public Health (M.P.H.)
- After working as a healthcare analyst for two years and not quite enjoying it, he decided to change the course of his career path
- Mohit then went to the University of Texas, San Antonio for medical school, after which he did a one-year internship in general surgery at Baylor College of Medicine and spent five years in urology
- He then did a one-year fellowship in male reproductive medicine surgery, where he developed a keen interest in sexual health and infertility
- Mohit has been a faculty member at Baylor since 2007

**What are the different aspects of urology, and could you share some insights on what the fellowship experience in urology is like, particularly related to reproductive and sexual health?**

- Peter notes that from his experience, urology places a significant emphasis on urologic cancers such as prostate cancer, bladder cancer, and kidney cancer
  - However, since his exposure to urology was limited, he wasn’t able to see much of the other aspects of the field, particularly those related to reproductive and sexual health
- Mohit explaines that urology is a diverse field with multiple subspecialties and areas of expertise in urology include stones, cancer, and female urology, among others
  - However, sexual medicine and infertility are important subspecialties in urology as well
  - Reproductive medicine involves procedures such as vasectomy reversals, varicocele repair, and sperm retrieval
  - Sexual medicine focuses on addressing issues such as erectile dysfunction, premature ejaculation, Peyronie’s disease, and hypogonadism
- Mohit has dedicated his career and research efforts to sexual medicine

## The anatomy of the male genitalia [5:45]

**Can you briefly go over the anatomy relevant to the male sexual health?**

- The penis is not a single organ, but rather a combination of three distinct organ systems: the urinary system, reproductive system, and sexual system
- The urinary system includes the bladder and urethra
- The reproductive system includes the [prostate](https://en.wikipedia.org/wiki/Prostate)
  - The [ejaculatory ducts](https://en.wikipedia.org/wiki/Ejaculatory_duct) within the prostate receive sperm from the testicles and mix with seminal fluid from the [seminal vesicles](https://en.wikipedia.org/wiki/Seminal_vesicles) to form ejaculate
- The [corpora cavernosa](https://en.wikipedia.org/wiki/Corpus_cavernosum_penis) are smooth muscle bodies responsible for erections and are located above the urethra
- The [urethra](https://en.wikipedia.org/wiki/Urethra#Male) is responsible for urinary function

![](https://peterattiamd.com/wp-content/uploads/2023/06/f1-mohit.png)

**Figure 1. Anatomy of the male reproductive system, sagittal and frontal view**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Male_reproductive_system)

- This system is holistic, and each component has the potential to affect the others
  - For instance, infertility and hypogonadism can impact each other
  - Patients taking medication for [benign prostatic hyperplasia (BPH)](https://en.wikipedia.org/wiki/Benign_prostatic_hyperplasia) may experience [retrograde ejaculation](https://en.wikipedia.org/wiki/Retrograde_ejaculation), which can, in turn, negatively impact both fertility and sexual function

## The prevalence of sexual dysfunction, its impact on quality of life, and the importance of seeking help [7:15]

**Prevalence of erectile dysfunction**

- Over 52% of men over the age of 40 experience some level of [erectile dysfunction (ED)](https://en.wikipedia.org/wiki/Erectile_dysfunction)
  - This means that even with conservative estimates, around 30 million men in the United States alone suffer from this condition
- To determine the extent of the disorder, a validated questionnaire is used, called the [International Index of Erectile Function (IIEF)](https://www.drmohitkhera.com/static/img/iief.pdf), which also has a [shorter version](https://reference.medscape.com/calculator/377/international-index-of-erectile-function-iief-5#) consisting of six questions
  - Based on the answers provided, one can determine whether a person has mild, moderate, or severe ED
- When the original [study](https://pubmed.ncbi.nlm.nih.gov/8254833/) came out in 1994, it showed that 52% of men over the age of 40 had some degree of erectile dysfunction (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2023/06/f2-mohit.png)

**Figure 2. Probability of erectile dysfunction by age imputed by analysis of 1,290 respondents**. Image credit: [*The Journal of Urology* 1994](https://pubmed.ncbi.nlm.nih.gov/8254833/)

- The percentage of men with ED increases with age ‒ 40% of men at age 40 had some degree of ED, 50% at 50, 60% at 60, and 70% at 70 (age is an easy way to remember what percentage of men suffer from ED)
  - It’s not necessarily aging that causes ED
  - It’s more the acquisition of comorbid conditions as we get older

***ED is a prevalent condition***

- Mohit also treats a lot of **women** for sexual dysfunction
- [Studies](https://pubmed.ncbi.nlm.nih.gov/10022110/) have shown that 43% of women in the United States suffer from some degree of sexual dysfunction
- 30% of men have some degree of premature or ejaculatory dysfunction
- 7% to 9% of men have [Peyronie’s disease](https://en.wikipedia.org/wiki/Peyronie%27s_disease)

***The problem is that individuals with these conditions often suffer in silence, they don’t seek care, and it has a significant impact on their quality of life***

- For instance, a third of men with ED have suffered from depression, while 37% have experienced anxiety as a result of the disorder
- Additionally, ED can negatively impact the quality of a couple’s relationship
- [Quality of life scores](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7901407/) are significantly impaired in men who suffer from sexual dysfunction
- A [survey](https://www.multivu.com/players/English/9033951-healthy-now-mens-health-coalition-survey/) came out last year, 1500 men surveyed between the ages of 18 and 80 were asked about their mental, physical, and sexual health (this triad is all related), and it found:
  - Roughly 40% of men had some degree of sexual dysfunction
  - 50% of those men said, “*I would love to get treatment, but I don’t know where to go.*”
  - But only 51% of those men told their doctor about it
  - Only 44% of those men told their partner or their wife about it
    - The main reason was they were embarrassed
- Moreover, clinicians frequently do not ask patients about ED due to time constraints
  - Family practitioners are often obligated to manage an array of medical conditions within a limited timeframe, leading to ED often being at the bottom of their list

> “*Clinicians don’t ask about it. Patients are embarrassed to ask about it, and that’s the suffering in silence.*”‒ Mohit Khera

- Peter responds, “*One of the desired outcomes of this podcast, is to empower people of both sexes plus their physicians to hopefully take a more active role in this*”

## Erectile dysfunction (ED): definition, diagnosis, pathophysiology, and more [11:00]

**What are the criteria for ED?**

- One of the easiest ways is to use questions 2 & 3 on the [SHIM questionnaire](https://www.drmohitkhera.com/static/img/shim.pdf), **ask the patient**:
  - Are you able to get an erection sufficient for penetration? (yes/no)
  - Are you able to maintain that erection until orgasm (yes/no)
  - If they answer *no* to either question, they have ED

**If this happens under any condition, even if it happens just once out of nine times?**

- In that case, they had one episode of ED
- It’s graded
- The first sign of ED is they can get an erection but can’t maintain it
  - This is due to a venous leak
- ED is different from the problem of not being able to ejaculate in men who can get and maintain an erection
  - Which is a complaint that Peter hears a lot and we’ll talk about soon

**Pathophysiology of ED**

*How much of this is physiologic neurovascular?*

*How much of this is psychological?*

- The mnemonic taught to medical students is **VENT**, which stands for Vascular, Endocrine, Neurologic, and Trauma
  - Peyronie’s Disease can also be caused by trauma (we’ll come back to this)
- In addition to these factors, medications such as [beta blockers](https://en.wikipedia.org/wiki/Beta_blocker) and [antiandrogens](https://en.wikipedia.org/wiki/Antiandrogen) like [finasteride](https://en.wikipedia.org/wiki/Finasteride) can also contribute to or worsen ED

**Psychogenic ED** is more common in younger patients, and it is treated differently than organic ED

- Ask the patient, “*Are you able to get erection with masturbation?*” and if they say yes, they are telling you they have psychogenic ED
- Similarly, if they get morning erections but have difficulty having sex, they have psychogenic ED
- Psychogenic ED is treated with sex therapy, and in these cases, Mohit prescribes daily [Cialis](https://en.wikipedia.org/wiki/Tadalafil)

*Do you refer patients out to sex therapy? What are sex therapists doing in these situations? How are they helping people?*

- Sex therapists are very effective
- The problem is many men don’t want to see a sex therapist, they want a pill
  - It’s getting easier to see a sex therapist because of telehealth
- Daily [Cialis](https://www.rxlist.com/cialis-drug.htm) (generic tadalafil) has been very effective for young patients (5 mg per day)
  - Their erections get better

*Problems with psychogenic ED often lead to a vicious cycle*

- If someone experiences ED once, the next time they engage in sexual activity, they start worrying about losing their erection, which often causes them to lose it again
- This becomes a self-fulfilling prophecy; fixating on the issue only makes it worse, and the cycle continues
  - Peter uses a driving analogy, “*If you’re trying to not drive off the track as you’re exiting a corner, looking where you don’t want to go is exactly where you’re going to go… The car follows the eyes.*”
- This is a challenging situation to break free from and can cause anxiety
- When individuals experience anxiety and subconscious aversion towards sex, they often start avoiding sexual activity altogether, which can be mistaken for a low libido by their partner
  - However, it may actually be due to their fear of experiencing ED
- Cialis can alleviate anxiety and reassure them that everything is working fine
- At Mohit’s office, [penile ultrasound](https://en.wikipedia.org/wiki/Penile_ultrasonography) is frequently used to examine the peak systolic velocity and diastolic velocity
  - This can be therapeutic for patients when they see that everything is functioning properly
- There are different types of ultrasounds used for different purposes
  - For diagnostic purposes, ultrasound is used when the penis is injected to induce an erection
  - For ED treatment purposes, shockwave therapy is used

## The history of medications to treat ED and the mechanisms of how they work [15:30]

- Erections are caused by the [parasympathetic](https://en.wikipedia.org/wiki/Parasympathetic_nervous_system) nerves, which can be induced by various types of sensory stimuli (vision, hearing, tactile)
  - When stimulated, these nerves secrete [nitric oxide (NO)](https://en.wikipedia.org/wiki/Biological_functions_of_nitric_oxide#Vasodilation_and_smooth_muscles), which is the key on/ off switch
- Nitric oxide goes to the endothelium and triggers them to secrete nitric oxide which triggers the endothelium to secrete more nitric oxide
- This increase in nitric oxide leads to an increase in [cyclic guanosine monophosphate (cGMP)](https://en.wikipedia.org/wiki/Cyclic_guanosine_monophosphate), which causes intracellular calcium to decrease
- This leads to the dilation of the [sinusoids](https://en.wikipedia.org/wiki/Capillary#Sinusoidal) and an increases blood vessel diameter, allowing blood to come in
- However, there is an enzyme called [phosphodiesterase](https://en.wikipedia.org/wiki/Phosphodiesterase) that breaks down cGMP, causing the loss of an erection
- Medications such as [Viagra](https://en.wikipedia.org/wiki/Sildenafil), [Cialis](https://en.wikipedia.org/wiki/Tadalafil), and [Levitra](https://en.wikipedia.org/wiki/Vardenafil) work by inhibiting phosphodiesterase, allowing for more cGMP to be present and maintaining an erection
- There are 11 different types of phosphodiesterase (PDE) in the body, with [type five (PDE5)](https://en.wikipedia.org/wiki/CGMP-specific_phosphodiesterase_type_5) being located in the penis
  - Some medications have cross-reactivity with other types of phosphodiesterase, leading to side effects such as back pain or changes in vision (affecting PDE11 in the back or PDE6 in the eye)
- The newest medication ([Avanafil](https://en.wikipedia.org/wiki/Avanafil)) has the least cross-reactivity with other types of phosphodiesterase and therefore fewer side effects
  - It is not yet available in a generic form and is currently more expensive than other options such as Cialis
- Generic versions of Cialis can be obtained at a low cost from various retailers

**How was Viagra developed?** [17:30]

- [Viagra](https://www.rxlist.com/viagra-drug.htm) was initially developed as a medication for controlling blood pressure, but during clinical trials, researchers noticed an unexpected side effect ‒ participants were experiencing erections
  - This effect was observed only in those who received Viagra, not the placebo
- Similarly, the drug [Addyi](https://en.wikipedia.org/wiki/Flibanserin), which is used to treat female sexual dysfunction, was originally designed as a medication for depression by Boehringer Ingelheim in Germany
  - However, during clinical trials, it was noted that the women taking the drug experienced an increased desire for sex, which led to its development as a treatment for female sexual dysfunction
- Despite initial hopes that Viagra could be a systemic reducer of blood pressure, this trial failed, and Pfizer was left with significant losses
  - But, researchers noticed that patients on Viagra were disproportionately keeping their samples, leading to follow-up questions and ultimately the discovery of its unintended consequence as an ED medication

***Viagra was a game changer in the field of sexual medicine, particularly in the way men are treated for ED***

**In comparison, drugs for women’s sexual health have not had the same impact as Viagra**

- The first drug for female sexual dysfunction, [Addyi](https://en.wikipedia.org/wiki/Flibanserin), was introduced in 2015, but it has not had the same level of success as Viagra in treating men’s sexual dysfunction.
- Another drug for female sexual dysfunction, [Vyleesi](https://en.wikipedia.org/wiki/Bremelanotide), has also been introduced, but its impact has been limited
- These medications are primarily focused on **desire**, although they may have additional off-label benefits, such as improving orgasmic function
- Peter notes that hormone replacement therapy (HRT) may be the most powerful agent for women’s sexual health, particularly as women age
  - Estrogen, in particular, has a significant impact
  - Mohit points out that there is a synergistic effect between these medications and HRT because of the different mechanisms of action

## Relationship between aging and erectile dysfunction and Mohit’s approach to treating patients and prescribing medications [20:00]

**The phosphodiesterase inhibitors essentially solve the physiologic problem, but what is it about the aging process and/or its comorbidities that lead to the venous leak in the first place?**

- The main issue at hand is referred to as venous leak or [veno-occlusive dysfunction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7884342/#:~:text=Veno%2Docclusive%20dysfunction%20may%20result,repair%20(6%2C%207).)
- In order to better understand this issue, it is important to consider the **anatomy** of the system (shown in the figure below)
  - The two tubes mentioned earlier contain muscle and sinusoids, with an artery running down the center of the tube
  - The wall of the tube is comprised of a thick casing called the [tunica albuginea](https://en.wikipedia.org/wiki/Tunica_albuginea_(penis)), beneath which lie the subtunical veins

![](https://peterattiamd.com/wp-content/uploads/2023/06/f3-mohit.png)

**Figure 3. Anatomy of the penis, transverse section**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Corpus_spongiosum_(penis))

- It’s a clever system, as blood flows into the penis, it presses against the wall, preventing blood from exiting the penile tissue
  - The more blood that flows in, the more the muscle presses against the wall, maintaining pressure and preventing blood from escaping
- However, as we age, the muscle can become atrophied and fibrotic, making it difficult to maintain pressure on the venous wall and resulting in a venous leak
  - The blood comes in but isn’t kept in
  - Aging causes a venous leak
- Fortunately, there are several ways to overcome this issue
  - It’s an outflow/ inflow game, if the inflow is 10 and the outflow is 15, you’re not going to get an erection
    - Similarly, if the inflow is 10 and the outflow is 15, you’re not going to get an erection
  - One way is to **increase blood flow** into the penis, such as with the use of Viagra
    - If you make the inflow 25, you can overcome the venous leak
  - Another option is to use a **penile band**, which works like a tourniquet by compressing the veins and allowing blood to flow in while preventing it from escaping
    - You haven’t fixed the inflow problem, but you’ve increased the back pressure on the outflow
  - Another option is to **manually apply pressure to the penis** at the five and seven o’clock positions, which blocks the outflow and improves the erection
    - This position gives circumferential, almost 180 protection all the way around

> “*We know that lower testosterone levels have been implicated in causing venous leak because it’s atrophy of the penile muscle*.”‒ Mohit Khera

- Mohit does a procedure called a penile prosthesis where they take penile tissue and look at it in the lab, look for a high density of [androgen receptors](https://en.wikipedia.org/wiki/Androgen_receptor)
  - As [androgens](https://en.wikipedia.org/wiki/Androgen) go down, you start getting atrophy of the penile muscle

**How can an aging person prevent atrophy of the muscle in the penis?**

- The most obvious thing that comes to Peter’s mind is “*Use it or lose it*”
  - Similar to if you were to put your arm in a cast, lack of use of the penile muscles can lead to muscle loss
- In order to keep the penile tissue healthy, regular erections, nocturnal erections, and sexual activity are essential for providing oxygen to the tissue
- [Studies](https://pubmed.ncbi.nlm.nih.gov/11672575/) have shown that daily use of [PDE5 inhibitors](https://en.wikipedia.org/wiki/PDE5_inhibitor) (such as Cialis and Viagra) can help with hypertrophy of the cavernosal smooth muscle
  - This is why Mohit particularly like to give patients daily Cialis
- Taking Viagra only covers the problem temporarily and does not cure it
- Daily Cialis, on the other hand, has been shown to prevent muscle atrophy and keep the tissue healthy

***Begin taking daily Cialis when you start noticing a mild degree of ED; this not only helps with the issue but is also a preventative measure***

**Two dosing strategies for Cialis**

- If you take a daily dose of 5 mg, the level of medication in your system can reach almost 8 mg due to a conversion rate of 1.6.
  - It’s worth noting that this dose has been approved by the FDA for treating [benign prostatic hyperplasia (BPH)](https://en.wikipedia.org/wiki/Benign_prostatic_hyperplasia), although the mechanism for this is unknown
    - [Flomax](https://en.wikipedia.org/wiki/Tamsulosin) can also be taken for this purpose, although retrograde ejaculation is a notable side effect
- Daily PDE5 inhibitors can also improve urinary symptoms in men, which are measured by the [International Prostate Symptom (IPSS) scores](https://en.wikipedia.org/wiki/International_Prostate_Symptom_Score) ([survey](https://www.drmohitkhera.com/static/img/ipss.pdf) posted on Mohit’s website)
  - However, it’s important to be cautious if taking Cialis and Flomax together, as they should not be taken too close in time to avoid experiencing [hypotension](https://en.wikipedia.org/wiki/Hypotension)
  - Daily PDE5 inhibitors are also FDA approved for [pulmonary hypertension](https://en.wikipedia.org/wiki/Pulmonary_hypertension)
- Wonderful [studies](https://pubmed.ncbi.nlm.nih.gov/16943794/) looking at daily Cialis versus on-demand Cialis showing that the patients who took it for four weeks daily significant improvement in endothelial dysfunction (we’ll come back to this)
  - This looked at endothelial dysfunction *outside of* the penis
  - They looked at blood markers such as [IL-6](https://en.wikipedia.org/wiki/Interleukin_6) and [C-reactive protein](https://en.wikipedia.org/wiki/C-reactive_protein), as well as flow-mediated vasodilation in the brachial artery
  - In fact, even if the patient stopped taking daily Cialis, the improvements persisted

**What would you say is the biggest downside of Cialis?**

- Mohit used to say cost, it was unbelievably expensive
  - Each pill would cost almost $15 to $20, and a 30-day supply of five milligrams would cost almost $400, which was exorbitant
- However, compounding pharmacies can make it for just a dollar per pill, and that’s great
- With the emergence of generics, the prices have significantly decreased
  - For example, you can get 90 pills (5 mg Cialis) for just $17 with no insurance
  - Mohit has not seen a significant difference in effectiveness between them and the brand name phosphodiesterase-five inhibitors.

**Do you have preferred brands of generics that you fancy?**

- Peter has become very concerned with the quality of generics
  - Not all companies are the same
  - [Sandoz](https://www.us.sandoz.com/our-work/quality-generics) is a good company
- Mohit doesn’t have a preferred brand
- He hasn’t seen generics significantly less effective than brand-name PDE5 inhibitors

**Is a longer refractory period between erections an indicator of ED?**

- Peter notes that any guy listening to this can think back to being in his twenties where you seem to be able to have an erection, ejaculate, and seven minutes later have another erection
  - Then something happens when you get older; those days are done; you might get two a day
- There’s no question that the refractory period goes up as we age
  - One of the factors that contribute to it is [prolactin](https://en.wikipedia.org/wiki/Prolactin) – after ejaculation, prolactin levels increase, and that’s been implicated as the reason for the refractory time
  - Mohit hasn’t seen a study on this but intuitively he thinks prolactin may be around for a longer period of time [as men age]
- It is more difficult to get an erection as men get older and therefore that contributes to refractory time

## The impact of lifestyle on sexual health and the association between ED and cardiovascular disease [29:30]

**From an evolutionary perspective**

- Peter notes that evolution didn’t care about women’s sexual health as they got older and underwent a change in reproductive state

*Is this true for men, that the older you get, the more genetic mutations are present in sperm?*

*Is evolution saying, “I don’t want you reproducing as much when you’re 50 as when you’re 20?”*

- Mohit doesn’t know

***He thinks it’s based on the quality of your health, and doesn’t know if age is the main driver***

- Some patients are older and have great semen parameters
- Some men in their 80s are in great shape; they’re having unassisted sex with no issues
- Older patients (60, 70) that come to Mohit are also trying to conceive (they’ve married someone younger)
- You will see patients with sperm pathogenesis, even at older ages
- He has younger patients (in their 30s) who are in terrible shape, poor quality erections, terrible semen parameters
- Peter talked with [Sharon](https://weillcornell.org/sjparish) on the [podcast](https://peterattiamd.com/sharonparish) about this, and he wonders if the greatest motivation for a male patient with respect to insulin resistance is erectile function
  - He has had patients who go from having a higher [hemoglobin A1C](https://en.wikipedia.org/wiki/Glycated_hemoglobin) to a lower hemoglobin A1C (from 5.9 to 5) and they often notice an improvement in erections
    - This is a person who says, “*I used to need Cialis for every erection… to I’m totally fine.*”

**Improving one’s lifestyle has a significant impact on the quality of a man’s erections**

- Mohit always stresses the importance of the **four pillars for sexual health**: diet, exercise, sleep, and stress reduction
  - Even choosing to focus on just one of these areas can improve the quality of erections and overall quality of life
  - Other examples: when you improve insulin resistance, when you improve obesity, stop smoking

**There is a strong link between ED and cardiovascular disease**

- Many risk factors for ED and cardiovascular disease are almost identical (summarized in the figure below)
  - This correlation is pertaining to organic ED, not psychogenic ED
- Many [studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5675247/) say that if you get ED today, within seven years, 15% of those men will have a heart attack or a stroke

![](https://peterattiamd.com/wp-content/uploads/2023/06/f4-mohit.png)

**Figure 4. Endothelial injury is a common link between erectile dysfunction and cardiovascular disease**. Image credit: [*BMJ* 2016](https://pmj.bmj.com/content/93/1105/679.long)

***Organic ED is often the first sign of cardiovascular disease and should be considered a warning sign of microvascular health***

- For instance, in 2004, [Dr. Ian Thompson](https://www.texasurologygroup.com/ian-m-thompson-jr-md) conducted the prostate cancer prevention trial on around 4,000 healthy men without ED
  - He [reported](https://jamanetwork.com/journals/jama/fullarticle/202047) that 15% of men who developed ED experienced a cardiovascular event within seven years
- [Montorsi](https://www.unimi.it/en/ugov/person/piero-montorsi) [reported](https://pubmed.ncbi.nlm.nih.gov/16901623/) 50% of men who had a cardiovascular event reported ED 39 months prior that that event
- Numerous [studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5675247/) have shown a correlation between ED and cardiovascular disease

> “*So [ED] it’s a real canary in the coal mine when it comes to microvascular health*”‒ Peter Attia

- ED could be considered a warning sign of microvascular health
  - Particularly if it’s [arterial insufficiency](https://en.wikipedia.org/wiki/Peripheral_artery_disease)

**The arterial diameter theory**

- Penile arteries are 1-2 millimeters, while coronaries are 3-4 mm and peripheral arteries are 6-7 mm
- If you get 50% occlusion of an artery, you will get end organ damage
- The theory is, you are more likely to occlude the penile artery before you occlude the coronary, and the coronary before the peripheral artery
- This theory doesn’t work very well because most of ED is due to [veno-occlusive disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7884342/#:~:text=Venogenic%20erectile%20dysfunction%20is%20due,occlusion%20of%20venous%20outflow%20tracts.)
  - And really it’s the [pudendal artery](https://en.wikipedia.org/wiki/Pudendal_arteries), not [cavernosal artery](https://en.wikipedia.org/wiki/Deep_artery_of_the_penis)

**Endothelial dysfunction theory**

- Endothelial dysfunction is the common link between ED and cardiovascular disease
- Cardiologists have shown that by improving endothelial dysfunction, cardiovascular disease can be reversed
  - This approach is also applicable to urologists treating ED
- Peter notes that three of the biggest risk factors for cardiovascular disease take aim at the endothelium
  - The big three risk factors are: smoking, high blood pressure, and [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B)
    - The first two are a chemical and the last is mechanical disruption of the endothelium

***Treating high blood pressure, obesity, diabetes and smoking elimination can reverse ED***

- The best study Mohit ever saw on this was by [Katherine Esposito](https://www.researchgate.net/scientific-contributions/Katherine-Esposito-39255040) published in 2004 in [*JAMA*](https://jamanetwork.com/journals/jama/fullarticle/198993)
  - This was a [RCT](https://en.wikipedia.org/wiki/Randomized_controlled_trial) of 110 obese men, 55 went on a diet and exercise program and 55 went on nothing
  - She followed them for two years, and men in the intervention lost weight and had a 3 point increase on the IIEF score
    - This is a six-question survey
    - A significant fraction improved their ED with diet and exercise only, no Viagra

**Does a three point increase translate to a clinically meaningful improvement?**

- Close, usually it’s four
- For clinically meaningful, think of it as two, five, and seven
  - If you have mild ED, you want to see an improvement of at least two
  - Moderate ED, improvement of five
  - Severe ED, improvement of seven
  - Typically with an intervention, you want to see an improvement of four on the IIEF score
- Even on just diet and exercise alone, they saw improvements in endothelial function, improvements to IL-6, they lost weight

***Lifestyle modification is very important when we talk about sexual dysfunction***

**Explain the use of diagnostic ultrasound**

- Let’s say a guy comes to in and Mohit rules out psychogenic ED, he realizes it’s something physiologic
- He does an ultrasound of the penis, and begins by injecting [Trimix](https://en.wikipedia.org/wiki/Trimix_(drug)) (a compounded medication) to cause vasodilation
  - [Alprostadil](https://en.wikipedia.org/wiki/Prostaglandin_E1) can also be used; for example, [Edex](https://www.rxlist.com/edex-drug.htm) is commercially available
  - It’s injected into the base of the penis at the 2 or 10 o’clock position, and within 5-10 minutes it induces a very good erection
  - This allows Mohit to look at the **peak systolic velocity**
    - If it is <30 (particularly <25 mm/s), then the patient has arterial insufficiency, and that means not enough blood flow is coming into the penis
  - If the end diastolic velocity is >5 mm/s, then he has a venous leak
- Peter explains, “*Systole is what’s happening when the heart is contracting. So you think about that as the flow out. Diastole is when the heart is relaxing itself, it’s filling, and you’re measuring backflow through the venous system.*”

***This is important because a venous leak is the #1 cause of ED (that’s half the problem)***

- In most cases the venous leak happens before you see arterial insufficiency

## Causes and treatments for Peyronie’s Disease, penile fracture, and more [37:30]

- With diagnostic ultrasound, you can also look at the [corpora cavernosa](https://en.wikipedia.org/wiki/Corpus_cavernosum_penis), look at plaque in the wall (the [tunica albuginea](https://en.wikipedia.org/wiki/Tunica_albuginea_(penis))); see the figure below
  - Where two tunica albuginea come together, they form a V, and that is where you see the plaque predominantly
  - 80% of the curvature in the penis is dorsal; it actually goes upwards
  - That plaque is what causes abnormal curvature, and when the curvature is >60 degrees, it’s prohibitive for intercourse
    - Patients can have 90-degrees, almost 180-degrees; it can be a very significant disease

![](https://peterattiamd.com/wp-content/uploads/2023/06/fig-5-mohit.png)

**Figure 5. Transverse section of the penis showing the corpus cavernosum and tunica albuginea shown**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Tunica_albuginea_(penis))

- Patients who have Peyronie’s disease really suffer from depression
  - They feel like there’s a disfigurement

**Treatment**

- In 2015 the FDA approved the first treatment for Pyeronie’s ‒  [Xiaflex](https://en.wikipedia.org/wiki/Collagenase_clostridium_histolyticum) (or collagenase)
- It can be injected into the plaque to break it down and improve curvature of the penis
- Before this all treatments were off-label; people used to give vitamin E or [colchicine](https://en.wikipedia.org/wiki/Colchicine)
  - But the American Urological Association Peyronie’s Guidelines first guidelines said these don’t work, the only medication indicated are systemic anti-inflammatories

**The way Peyronie’s disease works**

- The theory is that [Peyronie’s disease](https://en.wikipedia.org/wiki/Peyronie%27s_disease) is born of **trauma** (buckling sex trauma)
  - When a patient engages in sexual activity with a 100% rigid penis, he is less likely to injure
  - If he penetrates at 70, 80, 90% rigid, he’s going to injure
    - So ED often precedes PD (Peyronie’s disease)
- Mohit uses a balloon as an analogy ‒ if you put a piece of duct tape on a balloon and blow it up, what’s going to happen?
  - Everything is going to expand except the duct tape, and your going to curve in the direction of the duct tape
  - The greater the duct tape, the greater the curve
  - The treatment is to use medications to remove the duct tape (or the plaque)
- There’s an active phase and there’s a quiescent phase
- During the **active phase**, everytime a patient has an erection they have pain
- For about 12 months after you have an injury,  it’s constantly changing
- There’s a rule called the **15/40/45 rule**
  - 15% of patients will get better within the first year
  - 40% experience no change
  - 45% get worse
- Mohit doesn’t operate until the condition has stabilized because 45% of patients get worse
- You need to wait until the healing/ remodeling is finished and the patient is in the quiescent phase (about a year out from injury)
  - When the patient no longer has pain with erections, they are in the **quiescent phase** and can consider surgery

**Surgical therapy**

- In addition to medical therapy (injecting collagenase), there is surgical therapy
- You can put stitches on the opposite side and plicate it to make it straight
- Or, you can cut out the plaque and put in a patch, a graft to a plaster human pericardium
- Or if they have some erectile dysfunction with it, then you put in a penile prosthesis
  - Because what’s the point of making the penis straight if you can’t get an erection?

**Does the patient know when trauma has occurred?**

- Sometimes, but usually not

**If one acts quickly, do they have a better chance of salvaging this?**

- This is only true when someone has something called a [penile fracture](https://en.wikipedia.org/wiki/Penile_fracture)
- A penile fracture is when they’re engaging in sexual activity and there’s a sudden pop, a sudden injury that occurs, and significant swelling occurs in the penile shaft
  - In this case, one should seek immediate medical therapy, and usually it’s surgery to sew up the fracture
  - This occurs when there is a break in the tunica albuginea, in the casing discussed earlier
  - Swelling occurs because blood is leaking out (it’s a hematoma)

***For  Peyronie’s disease, 90% of men do not remember any trauma, but 7-9% of men have this; it’s very prevalent and very, very concerning for these men***

**What is the impact of age?**

- It’s more prevalent as men get older
- In 2009 Mohit wrote a [paper](https://www.auajournals.org/doi/10.1016/S0022-5347%2809%2960793-X) looking at testosterone and found that 74% of men with Peyronie’s disease have low testosterone
  - That’s interesting because when you have low testosterone, you have decreased rigidity of the penis and are more likely to injure
  - Testosterone has been implicated for wound healing in the dermatology literature as well
    - So low testosterone is a double hit ‒ you’re more likely to be less rigid and injure, and you’re less likely to heal
- Many people have trauma but they don’t have a plaque, so there has to be something going on with the healing process
- These patients will have an injury, but during the healing process a plaque forms

**Treatment with traction devices**

- Any part of the body is pliable
- Constant traction can make the penis longer, wider, but straighter
- There is a portion of the device that goes around the glans (the head of the penis) and basically clamps the glans
  - It goes at the base of the penis as well (this is on a flacid penis)
  - You can extend it as far as comfortable
- The one that has gotten the most interest is the one out of the Mayo Clinic called [RestoreX](https://www.restorex.com/restorex/?gad=1&gclid=CjwKCAjw9J2iBhBPEiwAErwpeetUHRIiAVUWOiOKw4UGRIEctk83oqoiu6XXZ92FFgKXNfE8VzeCoBoCxuAQAvD_BwE)
  - This actually bends it in the opposite direction
  - If you’re curving up, you can bend it down
  - If your curving left, you can bend it right
  - They’re about $500, but they are effective
- These devices actually came from porn sites
  - Before they were used medically (in 2010), porn sites were using them to increase length and girth (which they do)

**What % change can you get with these devices?**

- Anywhere from 1-1.5 inches; 2 cm at the maximum

**Is that a permanent change, or does it only last as long as you continue to use the device?**

- There has to be some continued therapy, once a week or twice a week
- Mohit gets patients all the time who say, “*Can you do penis enlargement surgery?*”
  - He doesn’t do that surgery
  - The stretcher is a safe way without doing surgery to gain some length

**How long is this used?**

- Every day for at least 30 minutes, twice a day for up to three months
- The old stretching devices were 2-6 hours a day, but they were not bent in the opposite direction (they were just straight)

**For Peyronie’s disease, is there a critical window in which that works?**

- Although there is no set time window for the device’s effectiveness, it is recommended to use it during the active phase of Peyronie’s disease to prevent further progression
- Success can be defined as reducing curvature or preventing it from worsening
  - If a guy comes in during the active phase with a 30-degree curvature and he gets that down to 0
  - Or if he prevents that 30 from going to 70
    - Remember that >60-degree curvature is prohibited for intercourse
- Mohit would like the least stretching device
- While the American Urological Association guidelines recommend waiting until the quiescent phase to start treatment, the stretching device can still be used off-label
- In cases where arterial inflow is the problem, [phosphodiesterase inhibitors](https://en.wikipedia.org/wiki/PDE5_inhibitor) can be used to compensate

## The value of ultrasound for ED diagnosis and management strategies [47:45]

**How do the ultrasound results impact the management strategy?**

- Ultrasound lets you know where the problem is and how bad it is
  - If it’s a venous leak, a **band** could be a solution
  - You wouldn’t want to offer a band if there’s *not* a venous leak because then it’s arterial insufficiency
- A venous leak that is end diastolic of 10, 15 tells you the severity of ED
- Normal is 5 mm/s on the end diastolic, and you want >25 or 30 mm/s on the peak systolic
  - A 20–year-old with no issues would have a peak systolic of 40 mm/s and a diastolic of ,1 mm/s
- It’s worth noting that each corpora cavernosa may have a different number, so it’s essential to check both sides of the penis
  - While asymmetry usually not that significant, this provides another diagnostic
    - The penis is fenestrated, so whatever you have on one side compensates on the other
    - If you inject a medication on the right, it also gets to the left
- A low peak systolic velocity in a young man can be concerning as it may be an indication of cardiovascular risk
- During Mohit’s fellowship, a machine called the [EndoPAT 2000](https://www.itamar-medical.com/professionals/endopat/) was used to check endothelial function
  - A blood pressure cuff would be placed on one arm and probes on a finger of both arms to measure the dilation of blood vessels
  - By applying supra-physiological pressures and releasing them, the machine could measure the ratio of dilation between the two fingers, which is a marker of endothelial function
  - If this found poor endothelial function in the finger, it was a marker for potentially occult blockage
- Mohit would take these results into the ultrasound room and do a penile ultrasound, and if the patient had poor endothelial function on the EndoPAT, you would see a poor inflow of blood in on the peak systolic artery
- There is a correlation between this endothelial function and cardiovascular disease, but it’s not common
- Mohit sees much more end diastolic dysfunction than systolic dysfunction

## Various treatment options for ED: injections, penile prosthesis, and more [50:15]

**When is a man a candidate for an injection and how long does it last?**

- [Trimix](https://en.wikipedia.org/wiki/Trimix_(drug)) can be injected into the penile tissue to dilate the arteries
  - This is a mix of [papaverine](https://en.wikipedia.org/wiki/Papaverine), [phentolamine](https://en.wikipedia.org/wiki/Phentolamine), and [prostaglandin](https://en.wikipedia.org/wiki/Prostaglandin_E1)
  - Inject at the base of the penis at the 2 and 10 o’clock position
- This is dose dependent, so you’ve got to be very careful because if you inject too much, the patient has a [priapism](https://en.wikipedia.org/wiki/Priapism)
  - They have to go to the ER and may need surgery to bring down the erection
- The first injection should always be in the office and the patient should be taught how to inject
  - Mohit asks patients to bring their partner because 50% of partners inject
  - They slowly titrate up the dose to get to 80% rigidity; they get the other 20% rigidity with foreplay
  - Once you find your number, you use that number (whether it be 0.2 mL, 0.25 mL)
- They inject every time they want to have sex

**The problem is ED is a progressive disease**

- So many men will start having to use higher and higher doses
- Then they’ll have to go to a higher strength solution
- Finally, the third level intervention is a **penile implant**

***In today’s new paradigm, Mohit offers patients all the options using shared decision-making***

- They don’t use urethral suppositories anymore
  - In the past, they used them quite a bit
  - It’s a prostaglandin suppository that is placed into the urethra and it causes  vasodilation in the penis
  - In Mohit’s opinion, they didn’t work very well, and they can cause significant urethral burning, even bleeding
    - It can cause a little bit of hypotension

**Penile prosthesis [52:45]**

- The [penile prosthesis](https://en.wikipedia.org/wiki/Penile_implant) has been around for 50 years now and is a phenomenal treatment option for ED
  - It was invented at Baylor in 1973
- [Boston Scientific Coloplast](https://www.bostonscientific.com/en-US/products/penile-prosthesis.html) is one of two main suppliers (see the figure below)
- The procedure places two cylinders (balloons) inside the corpora cavernosum, a small pump in the scrotum, and a small reservoir behind the pubic bone or underneath the rectus muscle that holds saline
- When you want to engage in sexual activity, you reach down and press the pump; tis bring saline into those cylinders and induces an erection
  - When you finish engaging in sexual activity, you release it and all the fluid goes back
  - The erection does not go away until you turn it off (deflate it)
- The man would still ejaculate normally, still have pleasure

> “*Some men find that very favorable. Essentially you have the erection whenever you want, as long as you want*.”‒ Mohit Khera

![](https://peterattiamd.com/wp-content/uploads/2023/06/f6-mohit.png)

**Figure 6. Inflatable penile implant**. Image credit: [Boston Scientific](https://www.bostonscientific.com/en-US/products/penile-prosthesis/ams-700-inflatable-penile-prosthesis.html)

- With the injection, the erection goes away when the drug wears off; this is not so with the prosthesis
  - Even if you ejaculate, you are not going to [detumesce](https://www.merriam-webster.com/dictionary/detumescence)

**How risky is the surgery for a penile prosthesis?**

- Not very risky at all
- It takes about 45 minutes under general anesthesia
- Let’s be clear, every surgery has some risks associated with it
  - There’s a small percent of risk for infection, there’s malfunction

***This is a relatively very safe procedure, but it has to be with someone who has done a lot of these procedures***

- Mohit does about 60 of these procedures a year
- You would want a provider who does 50-60 of these surgeries a year, just to make sure there are no issues

**When you do this for a first time patient, what’s the re-operation rate, or what’s the rate of complication where you have to do something else?**

- Typically the infection rate’s less than 2%, but now it’s closer to 1% (not very common)
- For [prophylactic antibiotics](https://en.wikipedia.org/wiki/Antibiotic_prophylaxis) he uses vanc-gent (a combination of [vancomycin](https://en.wikipedia.org/wiki/Vancomycin) and [gentamicin](https://en.wikipedia.org/wiki/Gentamicin)) and an antifungal
  - Peter asks, “*Vanc and gent, why such big, big guns?*”
  - Because a prosthetic infection is a disaster
  - Vancomycin has to go in an hour before the procedure; if he can’t get in in a hour before, he sometimes uses [Ancef](https://en.wikipedia.org/wiki/Cefazolin) and gent
- Intraoperative he uses [Irrisept](https://www.irrisept.com/)
  - A lot of orthopedic surgeons use this
  - Irrisept is essentially [chlorhexidine](https://en.wikipedia.org/wiki/Chlorhexidine) ‒ it’s a very effective medication for fungal, anaerobes, aerobes [bacteria], and it’s cheap
- Some of these prosthetics are antibiotic coded
  - The Boston Scientific was antibiotic coded minocycline rifampin
  - The Cold-Plus device is hydrophilic and you can dip it into the antibiotic and it takes it in

***The key is a short operative time, and there are many things in the operating room that we do to mitigate the risk of infection***

**Do you wear the space suit like the orthopods do for joints**?

- No, but they limit the movement in the room
- They tape the gloves
- They make sure there’s no movement in the light handles above
- Mohit doesn’t have more than one person at the table across from him
- Because if the patient has an infection, the prosthesis has to come out
  - If he catches the infection early, he can do a salvage ‒ take it out and put in a new one
    - The success rate is about 86%
  - If the patient is septic or has any kind of [purulence](https://en.wikipedia.org/wiki/Pus), you can’t salvage it

**Worse-case scenario, if a guy is septic, you pull the whole thing out. Do you get another chance to put one in when he’s recovered?**

- You wait three months to make sure everything is okay
- But it’s much more challenging to get another one in, and typically it’s going to be shorter, maybe even thinner
  - Some call this a penile cripple

***You have to be very careful, and really want to mitigate the risk of infection***

- The same thing goes with someone who has [priapism](https://en.wikipedia.org/wiki/Priapism)
  - After 36 hours, the [AUA guidelines](https://www.auanet.org/guidelines-and-quality/guidelines/diagnosis-and-management-of-priapism-aua/smsna-guideline-(2022)) will suggest that you can put a penile implant in

## Priapism (prolonged erection): what is happening and when to seek treatment [57:15]

- A priapism is a prolonged erection that lasts greater than six hours
- Mohit tells patients if it’s longer than four hours, you should start seeking medical attention

**An example to illustrate what’s happening to the penis**

- Take a rubber band and put it around your finger numerous times, this cutts off the blood supply
- How long does it take for that finger to start having necrosis and damage?

***In the penis At 36 hours, the chance of recovery is extremely low***

- If someone shows up at Mohit’s office on Monday with an erection he’s had since Friday, Mohit is very worried
  - The chances of recovery are low, and you have three months to get a penile prosthesis in
    - If you try later, there’s no telling how much fibrosis and scarring will be in that tissue
  - This would be very painful, but the patient may not seek care because he’s ashamed or he thing’s it’s going to go down

***The majority of patients are astute, they’ve been taught that if you have an erection for >4 hours you need medical treatment***

**Can you do an implant on the day of admission?**

- Let’s say a guy comes whose had an erection for 72 hours

*Would they have a better outcome if you put the implant in right away before there’s fibrosis?*

- You can’t, but you’ll have almost a similar outcome if you do it within at least the first three months

**Treatment**

- The first thing the patient gets is a shunt
  - Someone will stick a needle or a knife down the glans or in the corpora and try to [detumesce](https://www.merriam-webster.com/dictionary/detumescence) them
  - Then you get arterial to venous connection
- You don’t want to put an implant in right away, because you have a risk of erosion
  - There is a slight risk of infection possibly because someone’s manipulating the tissue
- Instead, let the tissue calm down, and come back in three weeks
  - This gives more time to get the implant done

**Do you do an ultrasound to make sure there’s no shunt?**

- Yes
- Interestingly, if you do a shunt, most of the time the patient will have an erection the next day
  - And the resident will call and say, “*Doc, it failed*”
  - It didn’t fail
  - Now, the patient has a [reactive hyperemia](https://en.wikipedia.org/wiki/Hyperaemia#Reactive_hyperaemia) ‒ they have high flow
    - He presented with low flow, venous outflow obstruction, and now you’ve converted him
    - They look with ultrasound and measure his flow
  - High flow is typical for someone whose had trauma

**What is the etiology of priapism?**

- There are many causes
- It’s extremely rare that [phosphodiesterase inhibitors](https://en.wikipedia.org/wiki/PDE5_inhibitor) cause priapism
- Most commonly it occurs with someone injects Trimix (or a similar agent) and injects too much
- There are a lot of medications that can induce an erection that won’t go down ‒ [Trazodone](https://en.wikipedia.org/wiki/Trazodone), cocaine
  - Peter notes that Trazodone is ubiquitous now as a sleep agent
  - Mohit doesn’t know if it’s dose-dependent, typically most patients take 50 mg when they go to bed

> “*So the moral of the story here is, if you have erection for four hours, go to the ER.*”‒ Peter Attia

**When the patient comes to the ER**

- If they’ve had the erection for less than 4 hours, Mohit will inject the **antidote** ([phenylephrine](https://en.wikipedia.org/wiki/Phenylephrine)), and this usually works
- If it has been longer, he’ll do some aspiration irrigation off the base of the penis to try to get the old blood out, and use phenylephrine
  - He will put in an 18-gauge butterfly needle and inject with normal saline (to aspirate)
  - Many times he’ll use cool saline
  - He wants to get out the venous clot and all the sluggish blood
- Mohit doesn’t run [heparin](https://en.wikipedia.org/wiki/Heparin) in with the shunt
  - People have advocated we start them on heparin or [Plavix](https://en.wikipedia.org/wiki/Clopidogrel) to keep the shunt open
  - He typically uses a low-dose aspirin

***The treatment is to aspirate, irrigate, then put the phenylephrine***

- If it doesn’t work, then Mohit’s favorite is a [T-shunt](https://www.nature.com/articles/nrurol.2009.86)
  - The patient is in the OR and he counsels the patient, “*If I do this Hegar and disrupt the muscle, there is a high chance you’re going to have erectile dysfunction and we’ll have to deal with it*”
  - For this, he takes an 11 blade through the glans into the corpora, and then sometimes has to use a [Hegar dilator](https://en.wikipedia.org/wiki/Hegar_dilators) and put it down…

**How often do you induce Peyronie’s in treating priapism? After treating the priapism, is there going to be a scar that results in asymmetry?**

- Using Trimix regularly is a risk factor for Peyronie’s
- Any repetitive trauma to the corpora cavernosa is going to actually injure the tissue

**When a man is injecting for ED, do you tell him to vary the site as much as possible to avoid that trauma?**

- Yes, Mohit tells him to inject opposite sides every other day
- You can’t inject every day

## Shockwave therapy as a treatment for ED [1:02:45]

**Last on the topic of ED, a few of Peter’s patients have talked about a device called GAINSWave. What is it?**

- [GAINSWave](https://gainswave.com/gainswave/) is just a company that uses devices for shockwave therapy
- In a European [study](https://pubmed.ncbi.nlm.nih.gov/20451317/) in 2010, [Dr. Vardi](https://www.researchgate.net/profile/Yoram-Vardi) was the first to use shockwaves to treat ED
- Shockwaves are not new to urologists, they use high intensity shockwaves for kidney stones
- Lithotripsy is high intensity shockwave therapy, this is low intensity shockwave therapy (or LiSWT)
- At first, this didn’t make a lot of sense to Mohit, but the science is quite clever
  - The science says you’re inducing trauma, and when you induce trauma, you bring in [neoangiogenesis](https://en.wikipedia.org/wiki/Angiogenesis)
    - You recruit stem cells and you help with [nitric oxide synthase](https://en.wikipedia.org/wiki/Nitric_oxide_synthase)
  - This helps improve the condition
- Cardiologists have been doing it for years, shocking the heart, and it was reperfusing the heart
- Orthopedics do it for joints and they use it for plantar fasciitis
- Think of the device like a probe, and you have to have someone perform the procedure
  - The penis is divided into 6 zones: shaft, hilum, and crus, and two sides, so six zones
    - The shaft of the penis
    - The hilum is  at the base of the penis
    - The [crus](https://en.wikipedia.org/wiki/Crus_of_penis) is underneath the scrotum
- The procedure delivers 2,500 shocks in these 6 areas, and it takes 25-30 minutes
- Patients come in 1-2x a week for 3-6 weeks
  - They may have a booster
- It’s not painful; it’s well tolerated; no anesthetic is necessary
- When Vardi did it, he showed that there was improvement in penile blood flow, and men were having better erections
- There are two types of machines, those with a focal shock and those with a radial shock
  - The **radial shock** is a hundred times less in terms of pressure, it’s over a thousand times over in terms of time, so it’s a longer shock, and it’s less penetration
    - This is like a pneumatic machine
    - They do nothing, but they’re not dangerous
    - The FDA has called this a type I medical device
    - Anybody can buy it
    - The going rate for these is $500-1000 per treatment

> “*The problem is that the ED population is very vulnerable… They’re almost desperate. They want treatment.*”‒ Mohit Khera

- The other problem is that the ED population has a very high placebo response rate
  - Give a hundred men a sugar pill and tell them that this sugar pill would give them the best erections of their life, 30% of men will get the best erections of their life off the sugar pill
- So there have been an explosion of shockwave clinics throughout the country
- The shockwaves machines that are effective are called **electrohydraulic, electromagnetic machines**
  - They are a class III machine
  - They are very effective, but they don’t work in all patients
  - [GAINSWave](https://gainswave.com/gainswave/) is a company that makes these
- The electrohydraulic is the shockwave used for treating a kidney stone, but it’s a low intensity

***This device has taken off greater than the science; the science is coming up and it may be beneficial for patients who have mild to moderate ED, but the ads about shockwave therapy are unbelievable***

- Mohit is part of the **Sexual Medicine Society of North America** and they put out a [position statement](https://www.smsna.org/news/smsna/review-of-smsna-position-statement-on-restorative-therapies) in 2018 stating that shockwave therapy should be used investigationally at this time
- The [American Urology Association guidelines](https://www.auanet.org/guidelines-and-quality/guidelines/erectile-dysfunction-(ed)-guideline) for ED also list it as investigational
- It has been five years, and there’s been more data, but Mohit advises to use it with caution
  - It has potential, but more studies need to be done

## Stem cell therapy for ED [1:08:15]

- The problem with stem cell therapies is that there is no FDA approval for using them for ED, so many patients have to travel outside of the country to receive this treatment
  - Mohit published a [commentary](https://pubmed.ncbi.nlm.nih.gov/25974235/) on this in 2015
  - People used to do this procedure in the U.S. off-label, but you are not supposed to because the FDA has said you cannot use stem cells
- Mohit uses a machine that has an [IDE (investigational device exemption)](https://en.wikipedia.org/wiki/Investigational_device_exemption) by the FDA
  - The exemption was specifically for ED for stem cells
- He conducted a [trial](https://pubmed.ncbi.nlm.nih.gov/31196678/) with 30 patients using adipose-derived stem cells
  - They take fresh fat and put it in the machine
  - He had a plastic surgeon do the liposuction under mild sedation, take 120 cc of fat and put it into a machine for making stem cells
  - After two hours, he would get anywhere from 37-50 million stem cells
  - He would then inject those stem cells into the penile tissue, at the base of the penis with a tourniquet for two minutes
    - You have to inject slow or you’ll damage the stem cells
  - Let the patient sit there for 30 minutes, then take the tourniquet off
  - There was no placebo control

> “*This is important, because up to today, there’s not a single placebo controlled trial with stem cells for ED, not one*.”‒ Mohit Khera

- These patients had an increase of maybe four on the IEF, but it was only durable for 6-9 months before it started tapering off
- It wasn’t a lasting effect, but some effect was going on
- He’s going to start a placebo controlled trial because people swear by stem cells
- Some companies will say they’ll give you 15,000 stem cells for ED, but there is not placebo-controlled trial; you have to be careful
- Mohit thinks stem cells have potential for ED but we need more studies to show the efficacy
  - Also using liposuction to do this every six months is not very practical; it takes a lot of time
- [Exosomes](https://en.wikipedia.org/wiki/Exosome_(vesicle)) may be the next way ([review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9978599/))

**What are exosomes?**

- They are basically the secretome ‒ what’s coming out of the stem cells
- You can harvest them from the placenta, from the patient’s own tissue (fat or bone marrow)
- Some people will take the stem cells and they’ll multiply them and they’ll get billions, enough to treat several patients
  - But remember that every time you multiply them, the efficacy starts going down when you get past four cell divisions

## Platelet-rich plasma (PRP) injections as a treatment for ED [1:12:00]

- The first randomized placebo-controlled trial was [published](https://pubmed.ncbi.nlm.nih.gov/33906807/) in 2021
- Before then, there was one case report with five patients out of Wake Forest showing some benefit
- They call it the “P-shot”, which is the Priapus shot, “*This was sold like it was the best thing since sliced bread. They call it the P-Shot, which is the Priapus shot.*”
- To make it, you take blood, spin it, take the supernatant, spin it again, add some calcium chloride and you have PRP to inject
- When you take stem cells, it costs $1,500-3,000; PRP costs $50 to make

***This is the one that lacks the most science***

- There is an excellent [study ongoing](https://umiamihealth.org/en/clinical-trials/shockwave-therapy-and-platelet-rich-plasma-for-the-treatment-of-erectile-dysfunction-20210887) at the University of Miami looking at PRP in combination with shockwave therapy, with placebo arms
  - [Preliminary results](https://www.auajournals.org/doi/10.1097/JU.0000000000003360.12) are expected at the AUA this year; that’s going to be very interesting]

**Peter’s takeaway on ED**

- An easy way to remember the prevalence is it’s matched by age
  - It’s amazing to think that for someone as young as 40, 40% of men are impacted
  - 50% of men at age 50, 60% at age 60, etc.
- For men who are listening (or their partners) ‒ go and get help; don’t suffer in silence
- The daily phosphodiesterase inhibitor is a very viable solution, and there shouldn’t be a stigma attached to that or a fear of becoming dependent on it
  - These drugs can sometimes break the vicious cycle, if there is a psychogenic component
- There is the diagnostic side on the arterial venous
- For PRP, stem cells, exosomes, and shockwave therapy, it’s still a little bit too soon to know how helpful these are
  - Of these four Mohit likes shockwave therapy the most because it recruits stem cells to the area of damage and it promotes neoangiogenesis; it’s not invasive; it’s quick
  - He’s least optimistic on PRP, but maybe a combination of PRP and shockwave or shockwave and stem cells

## Premature ejaculation (PE): prevalence, pathophysiology, and treatment [1:14:45]

**How does the prevalence of this differ by age?**

- 30% of men are likely to have some degree of ejaculatory dysfunction
- Premature ejaculation is prominent, but only 9% will seek therapy
  - And that’s really because many men are embarrassed to seek therapy about this
  - So basically 30% of men have this, but only 3% of men in total are doing anything about it
- Two years ago new [guidelines](https://www.auanet.org/guidelines-and-quality/guidelines/disorders-of-ejaculation) came out about premature ejaculation

**What is premature ejaculation?**

- There are two ways to think about this ‒ it’s either lifelong or acquired
- In either case, there are **three variables**:
  - 1 – There is a decreased ejaculatory time
    - When it’s lifelong, it’s typically less than two minutes
  - 2 – There is a sense of loss of control
  - 3 – They are bothered by it
  - If a guy comes in and says, “I *ejaculate in 30 seconds and I’m happy*” ‒ great, he doesn’t have the problem
    - If he’s bothered that his partner is bothered, then this is a problem
- Acquired could be things were great until the man hit 40, and all of the sudden he developed premature ejaculation
  - These same three variables/ principles apply
- How you define the time is a little tricky ‒ anywhere between 2-3 minutes *or* it’s 50% of your typical time
  - If a man used to ejaculate in 10 minutes and now it’s 5, that qualifies, and *this is important for determining treatment*

**Pathophysiology of premature ejaculation**

- For acquired premature ejaculation, Mohit starts looking at hormones
  - [Prolactin](https://en.wikipedia.org/wiki/Prolactin), [thyroid hormone](https://en.wikipedia.org/wiki/Thyroid_hormones), [testosterone](https://en.wikipedia.org/wiki/Testosterone)
- For lifelong premature ejaculation, there is *not* a lot of diagnostic workup
- There are four reasons to differentiate between
- 1 – Biological, an increased sensitivity of the glands
  - Some are born with increased sensitivity and that’s why one therapy is to use [lidocaine](https://en.wikipedia.org/wiki/Lidocaine) or an over-the-counter (OTC) numbing agent on the glands
  - For example use a lidocaine spray on the penis 10 minutes prior to engaging in sexual activity, then wipe it off before engaging to prevent spread of lidocaine to the partner
  - Be careful with lidocaine spray because if you spray too much, it causes ED
- 2 – Neurobiological/ neurotransmitters, there is too little serotonin
  - Neurotransmitters are causing an impairment for the ejaculation
- 3 – There is some belief that it is genetic
  - Currently there is not an assay
  - Polymorphisms in the four neurosteroid receptor genes have been implicated in lifelong premature ejaculation
  - More studies need to be done
- 4 – Psychological, any stress that causes some psychological impairment (a new relationship) can cause premature ejaculation

**Do you have a sense of why stress can have opposite effects? Why is it that in one man stress might result in ED and in another man it might result in no difficulty with an erection, but premature ejaculation?**

- Mohit doesn’t know, but stress has a significant impact for all sexual dysfunction
  - This is described by the acronym SAD (stress, anxiety, and depression)

**Treatment**

- First line therapy is a lidocaine spray, Mohit uses [Promescent](https://www.promescent.com/?utm_campaign=search-promescent-brand-usa&utm_source=google&utm_medium=cpc&utm_content=563671868310&utm_term=e_promescent&adgroupid=130468575496&gad=1&gclid=CjwKCAjwl6OiBhA2EiwAuUwWZWyNRszkqTAhg-fQ8ehT0Sf-4lv29MQd-ZdhAcnuMvEgFZxF2LN7FRoCx3QQAvD_BwE) (it’s easy to get, OTC)
- Second, you can use a [SSRI](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor) antidepressant
  - Some men don’t want to take an antidepressant
  - Although it works best if you take it everyday, you can take it on demand but it has to be 6-8 hours ahead of time
  - Peter notes this is counterintuitive, because one of the side effects of an SSRI is reduction in libido (and ED)
- This is one area where sex therapy is very effective

**What is the formality of training to be a sex therapist?**

- They are certified
- Typically psychologists, not psychiatrists, but psychiatrists can be certified in sex therapy
- There are **two techniques to prolong the ejaculate**, and if they work, they are a cure:
  - 1 – The start stop technique
  - 2 – The squeeze technique
- Some patients just want a pill

**Second line therapies**

- [Tramadol](https://en.wikipedia.org/wiki/Tramadol), a narcotic has been shown to prolong a ejaculatory time of <1 minute to 7 minutes
  - The problem is it is a narcotic and has a very high risk of addiction
  - Mohit had a patient that began using 5 a month, then he started asking for 10 a month, and when he called asking for 30 a month Mohit could tell he was getting addicted
- [Alpha blockers](https://en.wikipedia.org/wiki/Alpha_blocker) like [Flomax](https://www.rxlist.com/flomax-drug.htm)
  - One of the risk factors is it can convert premature ejaculation into [retrograde ejaculation](https://en.wikipedia.org/wiki/Retrograde_ejaculation)
  - It does prolong the ejaculatory time

**Explain what a retrograde ejaculation is**

- In the prostate, there’s something called [ejaculatory ducts](https://en.wikipedia.org/wiki/Ejaculatory_duct), think of it like a T (see the figure below)
- The ejaculatory ducts are coming up, moving forward is the urethra (and it’s coming out the urethra), moving backward is the bladder
- So when the sperm comes up and the seminal fluid comes up, the tendency is for the fluid to go back into the bladder
- But as the man has an ejaculate, he closes off the bladder neck, so the fluid cannot get into the bladder, and it’s forced to go out
- But when you take a medication like an alpha blocker or certain other medications, it can actually open the bladder neck
- So what happens is the sperm comes up, seminal fluid then goes into the bladder, and so nothing comes out of the urethra

![](https://peterattiamd.com/wp-content/uploads/2023/06/f7-mohit.png)

**Figure 7. Anatomy related to retrograde ejaculation**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Retrograde_ejaculation)

- The seminal fluid will come out when the man urinates or voids
- There is no harm in retrograde ejaculation, just some patients find it annoying
- It would impair reproduction

## Anorgasmia: causes and treatment [1:22:00]

**Anorgasmisa is at the other end of the spectrum. What is your workup for that?**

- Anorgasmia is delayed ejaculation
- The principles are the same ‒ is it acquired or lifelong?
  - Are you bothered by it?
  - Is there an inability to control it
- Timing is important, the average amount of time it takes a man to ejaculate in the U.S. is 6-7 minutes
  - This has been reported in numerous studies
  - It is determined by look at something called the [intravaginal ejaculatory latency time, (IELT)](https://en.wikipedia.org/wiki/Intravaginal_ejaculation_latency_time)
  - It is also self-reported, but that is often inaccurate
    - If you ask a man who has premature ejaculation, he underestimates the time; if he ejaculated in 2 minutes he reports 30 seconds
    - If you ask a guy who doesn’t have premature ejaculation, he overestimates the time; if he ejaculates in 8 minutes, he reports 15 minutes
  - They give the partner a stopwatch for her to click when he orgasms; that’s the best way to get the IELT
- In the U.S. the gold standard time is 6-7 minutes, and different countries have different numbers
  - Asian countries have lower numbers
  - European countries have higher numbers (longer ejaculatory latency)
- Medications like SSRIs are very effective in prolonging the IELT
  - There was a [study](https://pubmed.ncbi.nlm.nih.gov/14961051/) in 2004 by Waldinger looking at different SSRIs and [Paxil](https://www.rxlist.com/paxil-drug.htm) was #1 by far, [Zoloft](https://www.rxlist.com/zoloft-drug.htm) was #2
  - It is also dose-dependent ‒ the higher the dose, the greater the ejaculatory time
  - It was 25x with Paxil
  - Typically, you’ll see about a 10x delay

**However, a lot of patients on an SSRI have delayed orgasmia**

- The drug is why they have that, and if they’re on 40 mg of Paxil, they’ll try to go to 30 mg
  - They want the benefits for depression, but this can improve the ejaculatory latency time because it’s very sensitive to the dose
- There’s no set number on delayed orgasmia, but >15-20 minutes could be considered delayed orgasmia
- There are no FDA-approved treatments for this condition, everything used is off-label

**What about the role of 5𝛼-reductase inhibitors here?**

- Mohit would not use [5𝛼-reductase](https://en.wikipedia.org/wiki/5%CE%B1-Reductase); he doesn’t like to use them at all
- It’s possible that they could be implicated in anorgasmia; some patients taking these have impaired orgasm
- 5𝛼-reductase inhibitors block [DHT](https://en.wikipedia.org/wiki/Dihydrotestosterone)
  - DHT is 4-5x more potent than testosterone when it comes to function for the receptor
- One treatment for delayed orgasmia is testosterone
  - So using 5𝛼-reductase is going in the opposite direction

**What about the phosphodiesterase inhibitors used to treat ED, how often do they induce delayed orgasm?**

- They don’t induce delayed orgasm, they simply expose it

***If a patient presents with ED and premature ejaculation (PE), you always treat the ED first***

- This is a patient who either can’t get an erection or when he does, he has premature ejaculation
  - Those are his only two states
  - It’s not that common, but it does occur
- Whether it’s conscious or subconscious, it’s a belief that the body’s saying, “*If I don’t ejaculate quickly, I’m going to lose this erection. I’m going to lose the erection before I ejaculate.*”
- So if they are able to maintain an erection and not worry about it, it may prolong the ejaculatory time
- Often by treating the ED first you can treat the PE at the same time

## The interplay of sex hormones, the impact of aging, symptoms of low testosterone, and considerations for testosterone replacement therapy (TRT) [1:26:45]

**The physiology**

- The [pulsatile secretion](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5812824/#:~:text=The%20pulsatile%20secretion%20of%20hypothalamic,(LH)%20by%20pituitary%20gonadotropes.) of GnRH from the hypothalamus goes to the pituitary
  - That pulse goes down as we age (we’ll come back to that)
- The pituitary secretes two hormones: [LH](https://en.wikipedia.org/wiki/Luteinizing_hormone) and [FSH](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone)
- LH and FSH go to the testicles where the [Leydig cells](https://en.wikipedia.org/wiki/Leydig_cell) produce testosterone and the [Sertoli cells](https://en.wikipedia.org/wiki/Sertoli_cell) produce sperm
  - Mohit tells residents, “*Remember that that LH has an L, goes to the Leydig cells. FHS, a S, goes to the Sertoli cells.*”
  - Remember that the majority of a man’s testicles are comprised of Sertoli cells, and that’s important because ***the exam is more of an indicator of his fertility status than his hormonal status***
- The exam looks at the size of his testicles
  - They should be 4 cm in diameter (20 cc)
  - During an infertility workup, if the patient has has small testicles, elevated FSH and LH, then there’s a production problem
    - If he has normal FSH and LH and normal testicles and no sperm, there’s an obstruction problem
- The testicles are making [testosterone](https://en.wikipedia.org/wiki/Testosterone), but there’s a [negative feedback](https://en.wikipedia.org/wiki/Negative_feedback)
  - Testosterone goes back to the pituitary and hypothalamus to provide negative feedback
    - Estrogen also provides negative feedback, and it’s hard to say which is the stronger signal
  - Testosterone can be broken down to [estrogen](https://en.wikipedia.org/wiki/Estrogen) (0.3%) and [dihydrotestosterone](https://en.wikipedia.org/wiki/Dihydrotestosterone) (or DHT, 6-8%)
    - With higher testosterone, you should get greater estrogen and DHT
    - Many clinics try to block these conversions using [aromatase inhibitors](https://en.wikipedia.org/wiki/Aromatase_inhibitor) ([5𝛼-reductase](https://en.wikipedia.org/wiki/5%CE%B1-Reductase)); Mohit is not a fan of this

**When you go to the doctor, they will measure**

- It’s pretty common that the doctor will measure FSH, LH, and testosterone
- They don’t measure [GnRH](https://en.wikipedia.org/wiki/Gonadotropin-releasing_hormone) because it’s pulsatile, and measuring it would be useless
- [SHBG](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin) is often measured
- [Free testosterone](https://en.wikipedia.org/wiki/Testosterone#Free_testosterone)/ bioavailable testosterone/ free androgen index ‒ all of these *estimated*, not measured
- Most testosterone is bound (50% by [albumin](https://en.wikipedia.org/wiki/Albumin), 44% by [SHPG](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin), and 4% by [corticotropin-binding globulin](https://en.wikipedia.org/wiki/Transcortin)

***The body only care about free testosterone; free testosterone is the best correlate with symptoms***

- For example, if a guy walks in and his testosterone is 450, 500 but he feels lousy, checking his SHBG allows you to get a calculated free testosterone
  - If his SHBG is elevated, then the free T is going to be low [and this is why he feels lousy]

**How accurate do you think the calculated free testosterone is?**

- Mohit calculates free testosterone from the albumin, SHBG, and testosterone
  - There are simple calculators [online](https://www.mdapp.co/free-and-bioavailable-testosterone-calculator-544/)
  - It’s more accurate to calculate it this way than to use the assay
- The gold standard is [LC-MS](https://en.wikipedia.org/wiki/Liquid_chromatography%E2%80%93mass_spectrometry), but it’s expensive and hard to get
  - There is an LC-MS assay for total testosterone ([LabCorp](https://www.labcorp.com/tests/070195/testosterone-free-direct-with-total-testosterone-lc-ms-ms)), he doesn’t know about free testosterone
- Peter notes that there is good data for the distribution of total testosterone over a man’s life, but we don’t seem to have that for free T
  - All he can find is free T for a man over 18
  - So when a 50-year-old asks, “*How do I stack up?*” it’s hard to say
- Mohit always thought the concept of **andropause** was real, meaning as men get older, the level of testosterone gets lower and lower due to age alone
  - That is *not* true
  - We now know that total testosterone levels don’t decline very much in healthy males, and what makes it go down is the acquisition of comorbid conditions

***What changes is SHBG goes up as we get older, the total testosterone should stay relatively flat (if you’re healthy), and the free T will start to go down***

**Genetics seem to play a very big role in SHBG**

- Peter is someone who has very low SHBG (in the 30s), but he also has a very low testosterone (400, maybe 500)
  - So his free T is about 2.5% of his total T
- He has lots of patients who have a very high T, but their SHBG is 80s, 90s
  - Mohit explains, that is the body compensating
  - If the patients T starts going down, the body starts lowering the SHBG to maintain homeostasis
    - It’s almost like our reserves
    - The body knows when we have too much and binds it

**What do you think is driving the age thing?**

- Peter knows there is an amazing response to insulin, as insulin comes down, SHBG goes up
- As T4 goes up, SHBG goes up
- As estradiol goes up, SHBG goes up

*Are any of those things driving the age change?*

- Mohit doesn’t know, but SHBG goes up with age
- Genetics may be a big part of this
- Obesity has an effect (it increases SHBG), and there are comorbid conditions that affect SHBG levels
  - Peter thought the hyperinsulinemia that comes with obesity would cause SHBG to go down

**How much of the free testosterone gets into a cell? Then how much gets into the nucleus? How many androgen receptors do they have?**

- One of the things Peter has struggled with is the leap between the estimated free testosterone level and what is physiologically important

*How saturated are the androgen receptors? How sensitive are they? How do they lead to gene transcription?*

- Peter has talked with [Ted Schaeffer](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=34261) about this, but clinically he can’t answer any of these things
  - All he has is a crude estimate of free testosterone
- For example, a 55-year-old in good health had a free T of 7 ng/dL, and all Peter can say is “*It’s low. You’re about the 20th percentile for men over the age of 18.*”
  - Peter can’t tell him how he compares to other 55-year-olds because that data isn’t published
  - When faced with the questions, “*Should we do anything about it?*”, he doesn’t know if his [androgen receptors](https://en.wikipedia.org/wiki/Androgen_receptor) are saturated (whereby adding more T isn’t going to do anything)
  - Instead, he focuses on the man’s symptoms
- Mohit agrees with this approach (symptom focused)

***It’s not about testosterone numbers, it’s about how he feels***

**Symptoms of low testosterone**

- Low energy, low libido, erectile dysfunction
- Increased fat deposition, decreased muscle mass, depression, poor sleep
- Peter also asks about recovery from workouts
  - Mohit agrees and adds that bone fractures are important too
- Metabolic syndrome
- In Peter’s example, this guy lost 25 lbs last year, he’s exercising more, his bone mineral density is fine
  - His appendicular lean mass index is only at about the 55th 60th percentile (Peter want’s patients >75th percentile)
  - He doesn’t think he needs testosterone to get there, just a little more training and protein
- For this 55-year-old, Mohit would say, “*You don’t need testosterone today. I don’t know about five or 10 years from now, but today I’m not going to put you on it. Because the reality is if I do put you on it will suppress your endogenous access and you may need to be on it for life and you don’t need it today. You have no symptoms.*”
  - Peter is a firm believer in the benefits of testosterone, and he’s spent more time in the literature than most, and he completely buys the efficacy and safety of it, but he knows that once he starts taking it, he will be on it indefinitely
    - So he’s going to hold out as long as possible until he needs it (this is what Mohit wishes most people would do)
- The problem is that a lot of young men go to the T clinic at age 30, then they come to see Mohit and say, “*I didn’t know I could be be infertile*” (as a result of testosterone therapy)
  - Then he has to reverse them

## Methods for increasing endogenous testosterone [1:38:45]

**Different ways you can replace testosterone**

- Historically, in Peter’s practice there are four ways they replace testosterone
- 1 – [Clomifene](https://en.wikipedia.org/wiki/Clomifene) (they don’t use this anymore) is a pill taken 3x a week, and it preserved both testicular volume and spermatic function
  - The drawback is, if the man didn’t have testicular reserve, he wasn’t going to get much of a bump
  - This was a great treatment for [central hypogonadism](https://en.wikipedia.org/wiki/Hypogonadotropic_hypogonadism) as opposed to peripheral
- 2 – [hCG](https://en.wikipedia.org/wiki/Human_chorionic_gonadotropin#Anabolic_steroid_adjunct) is a mimetic for [LH](https://en.wikipedia.org/wiki/Luteinizing_hormone) which is the direct stimulant of the Leydig cell (which makes testosterone)
  - There are lots of disadvantages, it’s a very delicate injectable, it has to be refrigerated, it’s expensive
  - But it seems to preserve testicular volume
  - It’s not clear if it’s as good as Clomid at preserving fertility
  - It feels less problematic to men in the sense that it’s less permanent
- 3 – Injectable [testosterone cypionate](https://en.wikipedia.org/wiki/Testosterone_cypionate) (or its derivatives)
- 4 – Testosterone pellets, though these are not used anymore since his practice is remote
  - Putting the pellets in is *not* trivial, men notice it
- Mohit notes that Peter mentioned two ways to **raise endogenous testosterone** ‒ Clomid and hCG
  - Some people use [anastrozole](https://en.wikipedia.org/wiki/Anastrozole), but he doesn’t recommend it

**Clomid (aka Clomifene)**

- [Clomid](https://en.wikipedia.org/wiki/Clomifene) is a serum, it provides negative feedback to the [estrogen receptor](https://en.wikipedia.org/wiki/Estrogen_receptor)
  - The problem is you get a discrepancy effect
  - Patients get a nice bump in the testosterone level, but 40% will say, “*I have no desire for sex. I have no erections. I don’t feel any desire.*”
    - This is because Clomid blocks the estrogen receptor centrally
    - Estrogen is critical for libido and sexual function
  - You put that same patient on exogenous testosterone at 800 and he says, “*It’s working*”
  - Clomid is backordered and hard to get so now Mohit is using [Enclomid](https://en.wikipedia.org/wiki/Enclomifene) more (it’s compounded)

**Why is there such a run on Clomid?**

- For many years hCG was compounded, but recently the FDA put a stop to this (due to a patent infringement)
- So everyone dropped the hCG and went to Clomid, and now there’s a mad rush to get the Clomid
- You can still get hCG commercially, but the price is through the roof

***There was a national shortage of hCG and that’s why people started going to Clomid***

- 60% of men who take Clomid see their testosterone go up
  - 7% get [tachyphylaxis](https://en.wikipedia.org/wiki/Tachyphylaxis) when they take it daily
    - Mohit tells patients to load a pill box so they only take it on Mon, Wed, Fri
    - He prescribes 50 for Clomid every other day, or if they forget 25 Clomid daily
- Mohit prescribes 25 Enclomid daily
- Both are used for fertility
- hCG can also be used but it’s expensive ($1500-2000 3x a week)
  - It’s nice for patients who have pituitary pathology because this bypasses the pituitary and goes straight to the testicle and they can start making testosterone
- Patients who have an elevated LH and FSH initially (or [Klinefelter syndrome](https://en.wikipedia.org/wiki/Klinefelter_syndrome)) can’t really use hCG or Clomid because they’re already maxed out
  - For them you have to use anastrozole because he’s using this medication to increase T and improve spermatogenesis so he can do a biopsy or a [TESE](https://en.wikipedia.org/wiki/Testicular_sperm_extraction) to achieve sperm
  - Peter asks, “*When a man presents with Klinefelter, what are his typical T, DHT and E levels?*”

- E levels are typically high, 40, 30
- The prevalence of Klinefelters is 1 in 500, it’s quite common

**Tell people what Klinefelter it is**

- It’s a genetic abnormality where you have an extra X chromosome ([XXY](https://rarediseases.info.nih.gov/diseases/5677/48xxyy-syndrome))
- People with Klinefelter syndrome are phenotypically male, but there are fertility issues
  - They can have [gynecomastia](https://en.wikipedia.org/wiki/Gynecomastia)
  - They have no issues with ED, but T is low and that may affect the ED
    - Mohit treats them with medications to raise the T
    - He could give them testosterone, but what if they want to have a child
- They are typically long in stature
- Many of these patients are first diagnosed at age 14 or 15 when there is a delay in development
  - Often they come in because there is no facial hair development
  - Klinefelter syndrome is suspected if they have a long stature and small testicles; the pediatrician will check their [karyotype](https://en.wikipedia.org/wiki/Karyotype)
- Peter’s take away ‒ at 1 in 500, that means a lot of people listening to this podcast might have Klinefelter syndrome and they may be wondering if testosterone is an option
  - This is not necessarily the first line treatment unless you can block estrogen as well, and it depends on fertility status
- Mohit adds, some of these patients will start testosterone and when they’re ready to have children they will stop the testosterone and have a procedure called a [MicroTESE](https://www.mayoclinic.org/medical-professionals/urology/news/microsurgical-testicular-sperm-extraction-microtese-more-accessible-for-couples-who-are-infertile/mac-20532220#:~:text=MicroTESE%20is%20a%20surgical%20procedure,seminiferous%20tubules%20of%20the%20testis.)
  - To stop testosterone, Mohit uses a reversal dose of 3000 units of hCG 3x a week, then he’ll give them [Gonal-F](https://en.wikipedia.org/wiki/Gonadotropin_preparations#Recombinant_preparations) or Clomid with it
- Patients who’ve taken testosterone and are abusers will come in when they want to have children
  - They stop testosterone and take 3000 units of hCG 3x a week plus recombinant FSH or 75 units of Gonal-F 3x a week, and in 3-7 months you can see recovery of [spermatogenesis](https://en.wikipedia.org/wiki/Spermatogenesis) in these patients who are [azoospermic](https://en.wikipedia.org/wiki/Azoospermia)
- Many times guys gets testosterone from a gym and they weren’t getting monitored and they’re at a super physiologic level for years
- Both Peter and Mohit use **physiologic doses**, typically 50 mg of [cypionate](https://en.wikipedia.org/wiki/Testosterone_cypionate) twice a week
- For younger patients (in their 40s), Peter tells them they don’t want to be on this for more than a year unless they’re willing to be on it
- When a patient is in their 40s, Mohit tries hCG alone at 1,500 units 3x a week (not 3000 units)
- Mohit did a study at Baylor with a patient who wants to take T, and they have them take hCG with it to protect the access (500 units of hCG 3x a week)
- The best [study](https://pubmed.ncbi.nlm.nih.gov/15713727/) of this is by [Coviello](https://medicine.duke.edu/profile/andrea-diprincipe-coviello) in 2005; patients were given 200 mg of testosterone IM (intramuscularly) every week (a big dose)
  - They measured intratesticular testosterone levels
  - In 94% of patients the intratesticular level of testosterone went down to zero in three weeks
  - Then they gave these patients different doses of hCG (250, 500, all the way to 1000)
  - They  found that between 250-500, there was no significant decline in intratesticular testosterone
- Mohit’s partner ([Larry Lipshultz](https://www.larrylipshultz.com/about/dr-larry-lipshultz)) asked, “*What is it doing for fertility?*”
  - They [gave](https://www.auajournals.org/doi/10.1016/j.juro.2012.09.043) patients testosterone plus 500 units of hCG every other day
  - They saw a decline in intratesticular testosterone but it’s wan’t significant

***So hCG can help protect the decrease in spermatogenesis caused by taking testosterone***

**Why is that the case given that hCG is acting on the Leydig cell?**

- Peter would think recombinant FSH is needed to protect spermiogenesis
- hCG has some FSH properties, and giving a man hCG for fertility results in improvements in spermatogenesis
- Some of the testosterone is being used by the Sertoli cells for sperm production

**Has someone done the study of giving** [**Clomifene**](https://en.wikipedia.org/wiki/Clomifene) **or** [**Enclomifene**](https://en.wikipedia.org/wiki/Enclomifene) **with testosterone to maintain sperm production?**

- Mohit has not seen that study, but people use this off-label
- This issue with that is this causes estrogen to go up, and now you have two things working in opposite directions
- You also know when you give testosterone, you suppress LSH and FSH; Clomid is trying to raise the FSH
- Giving recombinant FSH would be better by it’s extremely expensive ($500 per month) and only used for infertility in women (on-label use)
- hCG is about $300 a month
- Peter can understand why men are just getting testosterone because it’s very cheap, especially if they get in an illicit fashion
  - But they’re out of the doctor’s office where they can’t be monitored

**More on preservation of fertility**

- Besides anastrozole, Clomifene, and hCG, there is some [data](https://pubmed.ncbi.nlm.nih.gov/35791295/) that just came out suggesting that the **intranasal testosterone** (3x daily) does not significantly suppress spermatogenesis
  - It’s called [Natesto](https://www.natesto.com/), and it’s commercially available at Walgreens, etc.
  - It’s 11 mg applied 3x a day for 33 mg daily
  - It has the fastest rapid onset and then it declines; it’s in and out quickly
  - When Mohit looked into this and talked to endocrinologists, he learned that it doesn’t have to be in the serum all the time; if it’s bound to the receptor, then it’s doing its job
  - Patients taking this feel better
    - Some take it before sex or before a workout
  - Peter asks, “*How is this not the drug of choice?*”
  - More studies need to be done, but this is interesting
  - It’s been out for 6-7 years
  - Insurance covers it

## Testosterone replacement therapy: various forms of exogenous testosterone, weighing risk vs. reward, and more [1:52:30]

**How do you decide between the different forms of exogenous testosterone (pellets, topical, injectable, intranasal, and oral forms)?**

- Mohit goes through all the options with patients because a lot of times it could be cost prohibitive

**Injectable Testosterone**

- Cash price for injectable from a compounding pharmacy is $25 a month
- They are injected [sub-Q](https://en.wikipedia.org/wiki/Subcutaneous_administration) with a 25 gauge, ⅝-inch, 1 cc syringe
- Mohit tells patients to pinch the fat in the belly and inject on Sunday and Thursday
  - These drugs peak in 24 hours, so if you do it on Sunday you’re ready for Monday, and if you do it on Thursday, you’re ready for Friday
  - Pinching decreases the pain of the injection
  - Patients can inject wherever they want, in the upper outer gluteal fold, in the muscle, etc.
  - About 20% of patients say it’s less painful to inject in the muscle
  - But you get a higher blood level of testosterone if you inject in the fat
- He uses [cypionate](https://en.wikipedia.org/wiki/Testosterone_cypionate) for younger patients and [enanthate](https://en.wikipedia.org/wiki/Testosterone_enanthate) for older patients (he teaches residents, “*cypionate has a C for child and enanthate has E for elderly*”
  - Cypionates are more anabolic and have more sodium retention, and he tries to stay away from swelling/ edema in older patients
  - He makes the age cut-off around 50-60, but looks at the patient
- [XYOSTED](https://www.xyosted.com/) is a great option; this is enanthate
  - It comes as a preloaded needle, a tiny 27 gauge needle, spring-loaded device
  - There’s no user error associated with how much you’re drawing
  - It gets in with less pain and the patients through the needle away
  - 4 a month for $150 cash price

**Why haven’t they come out with a cypionate equivalent?**

- Enathlate is what they used to get through the FDA, but this is a good point

**Oral testosterone**

- [Undecanoate](https://en.wikipedia.org/wiki/Testosterone_undecanoate) has been approved all over the world since 1970 (China, Australia, Europe), it’s called [Andriol](https://www.drugs.com/cons/andriol.html)
- It wasn’t approved in the U.S. until 2019 because historically, orals cause [hepatotoxicity](https://en.wikipedia.org/wiki/Hepatotoxicity), but these go through the lymphatic system so they don’t cause hepatotoxicity
- You take these with a fatty meal, however the newer ones don’t have to be taken with a fatty meal (just any meal)
  - If you take it while fasting there is zero absorption
  - If you’re intermittent fasting, it makes this tricky because you’re supposed to take it at breakfast *and* dinner
    - Off-label Mohit gives it to patients at breakfast and lunch; he likes it better this way
  - What happens is you superimpose the first [absorption] curve on the next so you maintain a nice level; it mimics the [diurnal](https://en.wikipedia.org/wiki/Diurnality) variation

**What’s the dose?**

- It depends
- [JATENZO](https://www.jatenzo.com/) came out first in 2019, 237 mg are taken [BID](https://www.rxlist.com/bid_on_prescription/definition.htm) (two times a day)
- [TLANDO](https://www.tlando.com/) came out in 2022, 225 mg taken BID
  - This one has no titration, while the other two can be titrated if your testosterone level isn’t high enough
  - 225 mg is enough for 80% of patients to be in the normal range
- Peter comments about the dosages, “*which tells you how inefficient the oral conversion is relative to the injection*”
- A 3rd one just got approved, [Kyzatrex](https://www.kyzatrex.com/?gclid=CjwKCAjwuqiiBhBtEiwATgvixJusUWJNl2PdZqlq72X1-bDqQvDZBBMEb7QUzFNykfVpKVPprqBAchoCZ54QAvD_BwE) by Marius Pharmaceuticals

**Pellets**

- Mohit does a lot of pellets in men and in women
- They are very effective
- Pellets peak in 72 hours
- The only issue with pellets is by the 3rd-4th month there is a sharp decline (shown in Mohit’s [paper](https://www.sciencedirect.com/science/article/pii/S2050116115300696?via%3Dihub))
  - So you can shorten the interval to 3 months
  - Mohit describes this as, “*Putting the balloon in the air. We want to put the balloon in the air and catch it before it gets too low and put it in the air again.*”
    - There can be some logistical problems
    - A lot of patients like the injectables because they don’t have to deal with this; they’re autopilot
- Peter points out, “*How large a tract you’re making for a male to put testosterone in him. It’s not a trivial size.*”
- Mohit was taught initially to make a W (go 1, 2, 3) or a V
- He has since invented a technique called stacking ‒ he puts the pellets in like a column
  - They put them up and down together because you want to keep the distance far away from the incision or you’ll get expulsion, and every time you do a V, it’s a whole new track for blood or trauma
  - The pellets are stacked on top of each other, literally like a column, and it works very well
- After the pellets are implanted, you can’t exercise for 72 hours, and a bandage stays on for 48 hours
  - You can shower
- Patients return every 3-4 months

**If a man is committed to being on testosterone therapy, and you’re no longer worried about preserving endogenous function, do you favor the injectable over all others right now?**

- Mohit does
- He worries also about [erythrocytosis](https://en.wikipedia.org/wiki/Polycythemia)
- He did a [study](https://pubmed.ncbi.nlm.nih.gov/34257404/) showing the worst thing you can do is give 200 mg [IM](https://en.wikipedia.org/wiki/Intramuscular_injection) every 2 weeks
  - That doesn’t make a lot of since since the drug lasts about 10 days, so there’s no medication on board for about 4 days
  - But the spiking level of testosterone results in a higher rate of erythrocytosis
  - If you drop the dose down to 50 mg twice a week, the rate of erythrocytosis goes down
    - It’s a more physiologic dose

***50 mg injected twice a week is Mohit’s favorite dose; it works the best and it’s the cheapest***

**Topical testosterone**

- Peter has never been a fan of topical for men
- He thinks it’s acceptable for women because options are limited
- Mohit doesn’t favor topicals for several reasons
- His [paper](https://pubmed.ncbi.nlm.nih.gov/17898800/) in 2009 showed that testosterone wasn’t absorbed in 20% of men because the formula is mg x % penetrance and that’s variable
  - It’s even variable day by day on the same person
  - Peter notes the same problem occurs in women
  - It’s affected by how clean the skin is, what part of the skin it’s applied to, if the skin has been exfoliated

> “*If I give him a thousand milligrams of testosterone, he has 0% penetrance, he gets nothing*”‒ Mohit Khera

- Mohit tells patients not to get fixated on how many milligrams he’s giving, rather look at the end result, “*What’s your level?*”
- Gels are convenient but their attrition rate is high
  - If a man starts on a gel today, only 20% are on that gel at the end of one year
  - The problem is having to do it every day (once a day)
  - And often you can’t get a man to the levels he wants on a gel
- There is also the problem with transference
  - This is a big problem because they’re covering so much of their body surface
  - If you have a pregnant woman at home or a child, you want to be careful
- If you travel with it, there are issues with TSA

**For women**

- Injectables and pellets work
- Mohit uses 50 mg/mL and injects 0.1 cc a week
  - Peter usually goes 20 mg/mL

## The physiology and purpose of testosterone and DHT, why some men feel fine even with “low” testosterone, personalized approaches to treating low testosterone, and more [2:02:30]

The physiology and significance of testosterone and DHT, understanding individual variations in symptoms , Tailored Treatments, and Beyond

**How should we think about testosterone, DHT and estrogen, and why do they all matter?**

- The breakdown of testosterone to estradiol and DHT was discussed earlier
- Testosterone has numerous effects on different body parts at different levels
  - Erectile function is typically around 200 ng/dL total testosterone
  - When you start falling below 200 ng, you start losing nocturnal erections
  - Muscle tends to be higher
  - Bone tends to be higher

***Different body parts turn on at different levels of testosterone and the way to cover yourself is just being in the upper quartile***

- 300 ng/dL is the definition for [hypogonadism](https://en.wikipedia.org/wiki/Hypogonadism), and Mohit has never understood why we use that number because everyone is different
  - At 290, we don’t all feel bad
  - Similarly, at 310, we don’t all feel good

***The reality is there are many patients that feel good at lower levels, and it’s based on the sensitivity of the androgen recepto***r

- When Mohit was a fellow in the lab, they would take blood and count the [CAG repeats](https://en.wikipedia.org/wiki/Androgen_receptor#CAG_repeats) [in the [androgen receptor](https://en.wikipedia.org/wiki/Androgen_receptor#)], and patients who had longer CAG repeats had more insensitive receptors

***So the sensitivity of everyone’s androgen receptors is different genetically and this is why many people will respond differently to different doses***

- [Dr. Zitzmann](https://www.researchgate.net/profile/Michael-Zitzmann) in Germany [showed](https://onlinelibrary.wiley.com/doi/10.1111/andr.12867) that **depression** and **sexual function** can be associated with androgen receptor sensitivity
- Mohit thinks it’s a misconception when people say you’re in the normal range at 400 and something else may be going on because ***invariably, if you can raise them to the upper quartile of normal, you may see symptomatic improvement***

**Do you think we’re ever going to get to the point where TRT (testosterone replacement therapy) can be customizable based on a more broad view where a patient comes to see you and you do an androgen receptor assay on them and you couple that with what their free T is and make decisions based on that as opposed to just flying a little bit blind and having to guess?**

- That would be amazing
- Mohit looked at this in the lab, but his lab is not [CLIA](https://www.cdc.gov/clia/about.html)-certified so he can’t analyze the sensitivity of androgen receptors for patients
  - He can’t give advice, but he can look at different assays

**How complicated is the assay?**

- It’s easy to run, but it does take a bit of manual labor
- It’s like an ELISA test that you simply have to count CAG and circle it, CAG and circle it, until you determine the number of CAG repeats
- Peter asks, “*Do you not get the impression like LabCorp or somebody like this could generate that, or even just a proprietary lab could get CLIA certification*…”
- Mohit explains, “*What’s the ROI (return on investment)?”*
- The TRT market is wildly unsophisticated, and the answer is just give more testosterone, not titrate based on sensitivity

**What is the purpose of DHT?**

- Mohit mentioned earlier that 6-8% of testosterone gets converted to [DHT](https://en.wikipedia.org/wiki/Dihydrotestosterone)
- Peter presumes there is quite a bit of genetic variability in [5𝛼-reductase](https://en.wikipedia.org/wiki/5%CE%B1-Reductase)

***DHT is the most potent androgen we have on our body; it is extremely important for sexual function***

- When you remove the DHT, it can have a significant impact on someone’s sexual function
- DHT is implicated for **prostate cancer**, in terms of prostate growth
- It’s implicated for **hair** as well
  - These are medications that are used to take away the DHT because they can cause [alopecia](https://en.wikipedia.org/wiki/Hair_loss)
- **5𝛼-reductase** is located all over the body, they comes in two forms/ two isozymes (type 1 and type 2), and they have multiple functions throughout the body
  - This enzyme converts testosterone to DHT
  - 5𝛼-reductase type 1 can be in the scalp, brain, prostate, adrenals, kidney (all over the body)
  - [Finasteride](https://en.wikipedia.org/wiki/Finasteride) predominantly acts on type 2, [dutasteride](https://en.wikipedia.org/wiki/Dutasteride) type 1 and type 2 (we’ll come back to this)
  - Finasteride was the first drug used to treat [BPH (benign prostatic hyperplasia)](https://en.wikipedia.org/wiki/Benign_prostatic_hyperplasia)
    - It came out in 1992 as Proscar, 5 mg to treat BPH
  - Propecia came out in 1997, a 1 mg dose
  - In 2002 dutasteride (Avodart) came out to treat BPH
- The two isoforms of 5𝛼-reductase are expressed all over the body
  - Type 1 and 2 5𝛼-reductase are in the scalp
  - Type 2 is more in the prostate
  - Type one is in the adrenal glands, brain, epididymis

***When you’re take away DHT, your affecting numerous body parts, and that can have detrimental effects and this is why Mohit doesn’t like to use 5𝛼-reductase in his practice at all***

**What would you use as the first line of medical treatment (not surgical) for a guy with BPH?**

- [Alpha blocker](https://en.wikipedia.org/wiki/Alpha_blocker) or daily [Cialis](https://en.wikipedia.org/wiki/Tadalafil)
- He sees a better response with daily Cialis than with an alpha blocker
- For alpha blockers, he uses [alfuzosin](https://en.wikipedia.org/wiki/Alfuzosin) (brand name [Uroxatral](https://www.rxlist.com/uroxatral-drug.htm)) only because it has the least rate of retrograde ejaculation
  - You an use [tamsulosin](https://en.wikipedia.org/wiki/Tamsulosin) or [silodosin](https://en.wikipedia.org/wiki/Silodosin) (young men prefer the latter)

> “ *I think finasteride is a very bad drug, and I think it has very detrimental effects.*”‒ Mohit Khera

- Peter adds, “*You are the second very prominent urologist to raise this to me, the first being* [*Ted Schaffer*](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=34261)*, which has got me and my team trying to wrap our minds around this thing called post-finasteride syndrome”*

## Post-finasteride syndrome [2:09:00]

**What is post-finasteride syndrome?**

- There are patients who have taken finasteride who develop *irreversible* sexual neurologic symptoms
- For example, permanent ED, low libido and psychologic problems, depression, suicidal ideations
- Mohit believes it’s a real syndrome, but *not* everyone who takes finasteride gets post-finasteride syndrome
  - There’s a subset of patients who take finasteride who develop this condition
  - Most physicians do not believe this condition results from finasteride, Mohit is in the minority on this
- The American Urologic Association (AUA) does not have an official statement on post-finasteride
- The package states there are patients who have prolonged side effects with the drug

**A plausible mechanism to explain adverse effects with finasteride**

- You’re taught in medical school that finasteride blocks the conversion from dihydrotestosterone, and that’s it, but that’s only one fraction of the story
- Each one of these steroids goes into something called a [neurosteroid](https://en.wikipedia.org/wiki/Neurosteroid)
  - DHT goes into the androgen diol, that’s the neurosteroid, and then you multiply that by six
    - So six steroids are blocked, and those six steroids then have a decreased conversion into their neurosteroid
    - 5𝛼-reductase acts on [more than one steroid](https://en.wikipedia.org/wiki/5%CE%B1-Reductase#Substrates): testosterone, progesterone, aldosterone
- The biggest problem is when you block progesterone getting into its neurosteroid called [allopregnanolone](https://en.wikipedia.org/wiki/Allopregnanolone)
  - That’s important because allopregnanolone has been implicated for depression, anxiety, cognition
- There has been an increase in **suicide** rates in men who’ve had this post-finasteride syndrome

**If you had to guess what percentage of men who take finasteride experience negative side effects that persist upon the cessation of the drug?**

- Mohit doesn’t have a denominator, but the package insert says less than 5%
- He thinks it’s more than 5%
- Many men get these symptoms, but they’re taking the drug when their 60 or 65, and they think it’s a normal part of aging (getting ED)
  - But a 30-year-old knows this is not normal

***What you cannot deny is that there’s an increased risk of suicides in this population of men, irrespective whether you believe it’s true or not***

- Mohit did a [study](https://pubmed.ncbi.nlm.nih.gov/34247957/) of 25 men who had post-finasteride syndrome and 25 controls who had never taken finasteride, and he looked at variation in gene expression between the two populations
  - Two of his patients out of 25 committed suicide during the trial
    - 8% suicide is an alarming rate
  - They were taking finasteride predominantly for alopecia
  - Peter would like to see the results of 50 men who were all taking finasteride for the same indication, but you isolate the 25 who are experience negative symptoms (Mohit agrees)
  - Peter asks if they had a history of depression before taking the drug; there was none

***Mohit’s point is that any drug associated with a higher rate of suicide is something to take a look at***

- There have been reports of patients who have taken [dutasteride](https://en.wikipedia.org/wiki/Dutasteride) who had similar symptoms, but it’s not as prominent

**When guys come to you for this product for hair loss, what do you tell them?**

- Whether they come to him for BPH or alopecia, he tells them there is a condition that’s been associated with men taking this medication that can cause an impairment in sexual function and actual depression and anxiety
  - Many countries, Canada, France, UK, have put on their package insert; not a [black box warning](https://en.wikipedia.org/wiki/Boxed_warning) but a warning of increased risk of suicidal ideation
    - Peter points out that SSRIs have that warning as well
- Peter’s question is, “*Why does it linger after the drug stops? That’s the part that is undoubtedly most disconcerting. If this is real, how is it that a guy can take this drug for a year, stop it, and two years later he is still suffering the sexual side effects associated with it? That strikes me as epigenetic. I can’t come up with another explanation.*”
- Mohit agrees, epigenetic silencing of the *5ARI* gene (encoding 5𝛼-reductase) through [DNA methylation](https://en.wikipedia.org/wiki/DNA_methylation) is one of the most common thoughts

## The role of testosterone in prostate cancer and addressing the notion that TRT could increase risk [2:16:15]

- When Peter brings up testosterone replacement therapy (TRT) for men, the question he is asked the most about is prostate cancer
- He had done several podcasts on this subject including a [dedicated AMA](https://peterattiamd.com/ama28/) on the risk and benefits of testosterone (see more links in the selected links section at the end)
- He came away from this analysis with the belief that there was no evidence that exogenous testosterone application was increasing the risk of prostate cancer
  - There was actually some evidence that hypogonadism may not be increasing the incidence of prostate cancer, but may have increased the incidence of high-grade prostate cancer
  - He saw virtually no evidence that exogenous testosterone therapy was leading to an increase in atherosclerotic cardiovascular disease
    - There was one study that suggested within 1 year, highly susceptible mend might see an increase in the risk of ASCVD, but that risk decreased 2-3 years post treatment
    - Results of [TRAVERSE study](https://www.nejm.org/doi/full/10.1056/NEJMoa2215025) just published show no increased risk of cardiovascular disease with testosterone therapy

**Can you fill in the gaps?**

- The thought that testosterone causes prostate cancer started in 1941, [Huggins and Hodges Nobel Prize](https://www.nobelprize.org/prizes/medicine/1966/summary/), based on one patient
  - In 1941 when they gave this patient exogenous testosterone, the prostate cancer got worse
- If you look at the different paradigms, the American Urologic Association in 2018 came out with the [testosterone guidelines](https://www.auanet.org/guidelines-and-quality/guidelines/testosterone-deficiency-guideline) stating that patients should be informed, “*There’s no association between testosterone and prostate cancer*.” (strong recommendation)
- Now when patients say, “*I Googled it. I heard I can get prostate*….” Mohit says, “*No, the guidelines are very clear. Based on the evidence… no data to support it.*”

**Contrast that with the guidelines on estrogen therapy and breast cancer in women. Talk about how men and women are treated differently with respect to hormone therapy**

- Mohit thinks a lot of this started with the [WHI](https://jamanetwork.com/journals/jama/fullarticle/195120) (see [episode # 253](https://peterattiamd.com/joannmanson/))
  - This got big news and everyone’s off hormones
  - Later on there was a reevaluation of the WHI and people said, “*Hey, maybe we made some mistakes*”
- Mohit was involved in the [TRAVERSE trial](https://www.sciencedirect.com/science/article/pii/S0002870321004671?via%3Dihub) (results coming out in June 2023), and the impetus was to have a large trial in men like is available in women
  - It’s a RCT of 6,000 men, the largest of its kind

**There’s been a paradigm shift on prostate cancer**

- The thinking now is that testosterone may not only be safe, but it may be protective against the development of prostate cancer
- In 2015, a Hopkins group published interesting [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4507510/) on a concept called **bipolar androgen therapy** (they call it BAT)
  - The lead author was [Schweizer](https://oncology.uw.edu/people/michael-schweizer) and the senior author was [Denmeade](https://www.hopkinsmedicine.org/profiles/details/samuel-denmeade)
  - They did something very unconventional, they treated patients with metastatic prostate cancer with high doses of testosterone
    - Peter notes, “*Which is mind-boggling because the standard care for that patient is the exact opposite. It’s to give you androgen deprivation (chemical castration)*”
  - They gave the patients [LUPRON](https://en.wikipedia.org/wiki/Leuprorelin) first (to shut down testosterone), and then they gave high doses (400 mg a month) of testosterone
    - Testerone levels would go up and down, and it would basically convert the castrate-resistant prostate cancer to castrate-sensitive
    - SA went down by 50%
    - Metastatic disease went down by 50%
- The same group published numerous, impressive studies; Mohit’s favorite one was the [TRANSFORMER trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8274807/) that came out in 2021
  - They took about 200 patients who had castrate resistant metastatic prostate cancer
  - If they became resistant to amiodarone, the treatment of care is [enzalutamide](https://en.wikipedia.org/wiki/Enzalutamide) (an androgen receptor blocker)
  - Instead of giving this, they gave half of the men high doses of testosterone
    - So half got enzalutamide and half got testosterone
  - The overall survival between the two groups was the same, but the patients who got  testosterone had a significantly better quality of life
- Further, if you took bipolar antigen therapy, you were allowed to switch over to enzalutamide if became resistant, and vice versa
  - The patients who did bipolar antigen therapy and then did enzalutamide had significantly greater survival ‒ 37 months versus 28 months than enzalutamide
  - The cost of enzalutamide is $8,000 a month
  - The cost of 400 mg of testosterone is about $100 a month, and they had significantly greater survival

**So we’re two years after that. How many men with metastatic prostate cancer are receiving that care now?**

- Mohit thinks it’s minuscule
- He doesn’t know why more attention was not given to this study
- There have been some recent [studies](https://bjui-journals.onlinelibrary.wiley.com/doi/10.1111/bju.15042) by Tom Ahlering’s group suggesting that giving testosterone to men after radical prostatectomy may be potentially protective against biochemical occurrence
- In Mohit’s lab they do a lot of basic science work with testosterone and prostate cancer
- In one study, they put prostate cancer cells in Petri dishes and gave each Petri dish a different amount of testosterone
  - Initially you see prostate cancer cell growth
  - But with higher doses of testosterone, you see greater and greater suppression of prostate cancer cell growth
    - They call that the inverted U, where castrate maybe protective (eugonadal protective), but hypogonadal is dangerous
- They repeated the [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5588749/) in animals (200 mice, groups of 50), the groups were:
  - Controls
  - Castration (orchiectomy)
  - Castration + low dose testosterone (2 mg pellets)
  - Castration + high dose testosterone (5 mg pellets)
- Results shown in the figure below
  - They found that if you castrate the mouse, you get decreased prostate cancer growth
  - With low doses of testosterone, you start getting increased prostate cancer growth
  - With high doses of testosterone, you get decreased

![](https://peterattiamd.com/wp-content/uploads/2023/06/f8-mohit.png)

**Figure 8. Tumor incidence rate in mice**. Image credit: [*BMC Cancer* 2017](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5588749/)

***The key is this, if I have prostate cancer, either castrate me or put me in the normal range of testosterone; the hypogonadal range is the danger zone***

- Peter has watched men get castrated chemically and it’s awful
  - He advises men to undergo surgery whenever possible
  - There are a lot of downsides to surgery but it pales in comparison to chemical castration and the metabolic derangement that follows
  - Not to mention the complications of bleeding that follow with the radiation
  - The quality of life is so poor after chemical castration

**What dose of testosterone are you using?**

- Mohit typically uses a gel first because he wants something short acting so he can stop it if he needs to
- Then he moves on to injectable and treats prostate cancer patients just like any other patient
  - He treats them in the normal therapeutic range, to the top quartile

**What kind of consent form do these men sign to undergo something that is erratic? And do you need an** [**IRB**](https://en.wikipedia.org/wiki/Institutional_review_board) **for this?**

- A recent survey of urologists show 96% treat men with testosterone after radical prostatectomy and 86% after radiation therapy
- There has to be consent and informed decision making
- The AUA has made it clear that the risk:benefit ratio after prostate cancer surgery or radiation is unknown
  - Mohit tells patients, “*Look, we don’t have a randomized placebo control trial. These are the risks, these are the benefits, and we have a shared decision making model.*”

**The prostate saturation model**

- This model is really important
- They were taught in medical school the higher the testosterone, the greater the PSA
  - They were taught it was a linear relationship, but this is not true because at some point it saturates
- Mohit did a [study](https://pubmed.ncbi.nlm.nih.gov/21788049/) in 2011 and found the saturation was around 250 ng/dL, which is pretty low
- If you have a man who starts out with a testosterone level of 190 and you put him on testosterone, his PSA should go up, and if he’s at 290 and you put him on testosterone, it should *not* go up
  - If you take the guy from 290 to 3000, it should not go up because it’s saturated (it plateaus)
  - The inflection point is around 250 ng/ml testosterone where patients with levels below this will have an increase in PSA after TRT but patients with levels above this will not have an increase in PSA after TRT
- That’s why if he gives someone [LUPRON](https://en.wikipedia.org/wiki/Leuprorelin), testosterone goes down, but PSA goes down
  - It’s *not* the more you raise testosterone, the more PSA goes up
- The tricky part is when patients come to him after radiation therapy because they’ve been given androgen deprivation therapy, their oncologist spent all this time taking away testosterone, and their T level is 50
  - When you get their T level from 50 to past 250, you’re going to see PSA rise until you hit saturation

***An understanding of the prostate saturation model to set the expectations (of the oncologist and patient) for what will happen to PSA levels with testosterone therapy***

## The effects of testosterone as an adjunct to therapy for estrogen-sensitive breast cancer in women [2:27:15]

**From a research perspective, what can you tell us about the effects of testosterone as an adjunct to therapy for estrogen-sensitive breast cancer?**

- Mohit treats women who have a history of breast cancer in conjunction with an oncologist
  - He may treat them with testosterone
  - Many times, he will use drugs that are not hormone based like [Addyi](https://en.wikipedia.org/wiki/Flibanserin), because that will give the same benefit of libido (sexual function) using dopamine
    - This drug was discussed in the [podcast with Sharon Parish](https://peterattiamd.com/sharonparish)
- Peter has read a lot of case reports that have suggested that testosterone replacement therapy with aromatase blockade in women with breast cancer is a therapeutic option
  - In other words, testosterone is protective against breast cancer
  - He doesn’t know if the [aromatase inhibitors](https://en.wikipedia.org/wiki/Aromatase_inhibitor) are necessary, but the thinking there is to prevent testosterone from becoming estradiol
- Mohit has seen studies giving testosterone without the aromatase inhibitors and it’s still protective, but he doesn’t have a lot of experience treating women with breast cancer

## Resources for those looking for healthcare providers [2:28:45]

**Do you have a sense of how many urologists in the country would have your degree of certification/ subspecialization?**

- Mohit is part of an organization called the [Sexual Medicine Society of North America (SMSNA)](https://www.smsna.org/), “*and this is exactly what we do*”
  - Their [healthcare provider directory](https://app.v1.statusplus.net/membership/provider/index?society=smsna) can be used to locate one of 1200 clinicians (doctors, APPs, Nurse Practitioners)
  - Of this 1200 400-450 are urologists, most of which are at academic institutions
- Mohit works via telemedicine in the state of Texas through [Baylor](https://www.bcm.edu/people-search/mohit-khera-24469)

Mohit’s [website](https://www.drmohitkhera.com/)

§

## Selected Links / Related Material

**Incidence of erectile dysfunction**: [Impotence and its medical and psychosocial correlates: results of the Massachusetts Male Aging Study](https://pubmed.ncbi.nlm.nih.gov/8254833/) | *J Urol.* (H A Feldman et al. 1994) | [8:15]

**Prevalence of sexual dysfunction in men and women in the U.S.**: [Sexual dysfunction in the United States: prevalence and predictors](https://pubmed.ncbi.nlm.nih.gov/10022110/) | *JAMA* (E O Laumann et al. 1999) | [8:45]

**Quality of life is less in men with sexual dysfunction**: [The Quality of Life and Economic Burden of Erectile Dysfunction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7901407/) | *Res Rep Urol.* (D S Elterman et al. 2021) | [9:30]

**2022 survey of 1,500 men**: [Healthy Now: A Men’s Health Coalition](https://www.multivu.com/players/English/9033951-healthy-now-mens-health-coalition-survey/) | [9:45]

**PDE5 inhibitors help with hypertrophy of the cavernosal smooth muscle**: [The effect of sildenafil on corpus cavernosal smooth muscle relaxation and cyclic GMP formation in the diabetic rabbit](https://pubmed.ncbi.nlm.nih.gov/11672575/) | *Eur J Pharmacol* (C S Thompson et al. 2001) | [23:45]

**Daily Cialis (not on-demand dosing) improves endothelial function**: [Relationship between chronic tadalafil administration and improvement of endothelial function in men with erectile dysfunction: a pilot study](https://pubmed.ncbi.nlm.nih.gov/16943794/) | *Nature* (A Aversa et al. 2007) | [26:15]

**Association of ED and cardiovascular disease**: [The Association of Erectile Dysfunction and Cardiovascular Disease: A Systematic Critical Review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5675247/) | *American Journal of Men’s Health* (O Raheem et al. 2017) | [32:30]

**Ian Thompson’s observation that ED precedes a cardiovascular event**: [Erectile Dysfunction and Subsequent Cardiovascular Disease](https://jamanetwork.com/journals/jama/fullarticle/202047) | *JAMA* (I Thompson et al. 2005) | [32:45]

**Montorsi’s observation that ED preceded cardiovascular events**: [Association between erectile dysfunction and coronary artery disease: Matching the right target with the right test in the right patient](https://pubmed.ncbi.nlm.nih.gov/16901623/) | *European Urology* (P Montorsi et al. 2006) | 33:00]

**Improved diet and exercise can reverse ED**: [Effect of Lifestyle Changes on Erectile Dysfunction in Obese Men: A Randomized Controlled Trial](https://jamanetwork.com/journals/jama/fullarticle/198993) | *JAMA* (K Esposito et al. 2004) | [34:30]

**Men with Peyronie’s have low testosterone**: [Increased incidence of hypogonadism in patients with a novel diagnosis of Peyronie’s disease as compared to organic erectile dysfunction](https://www.auajournals.org/doi/10.1016/S0022-5347%2809%2960793-X) | *The Journal of Urology* (R Sturm et al. 2009) | [42:00]

**Peyronie’s disease guidelines**: [Peyronie’s Disease (2015)](https://www.auanet.org/guidelines-and-quality/guidelines/peyronies-disease-guideline) | [AUA](https://www.auanet.org/) | [47:00]

**Priapism guidelines**: [Diagnosis and Management of Priapism: AUA/SMSNA Guideline (2022)](https://www.auanet.org/guidelines-and-quality/guidelines/diagnosis-and-management-of-priapism-aua/smsna-guideline-(2022)) | [AUA](https://www.auanet.org/) | [57:15]

**Using shockwaves to treat ED**: [Can low-intensity extracorporeal shockwave therapy improve erectile function? A 6-month follow-up pilot study in patients with organic erectile dysfunction](https://pubmed.ncbi.nlm.nih.gov/20451317/) | *European Urology* (Y Vardi et al. 2010) | [1:03:00]

**Sexual Medicine Society of North America position statement on shockwave therapy**: [Review of SMSNA Position Statement on Restorative Therapies](https://www.smsna.org/news/smsna/review-of-smsna-position-statement-on-restorative-therapies) | [SMSNA](https://www.smsna.org/) [1:08:00]

**ED guidelines**: [Erectile Dysfunction: AUA Guideline (2018)](https://www.auanet.org/guidelines-and-quality/guidelines/erectile-dysfunction-(ed)-guideline) | [AUA](https://www.auanet.org/) | [1:08:00]

**Mohit’s commentary on using stem cell therapy to treat ED**: [Mesenchymal stem cell therapy for the treatment of erectile dysfunction](https://sci-hub.ru/10.1111/jsm.12871) | *The Journal of Sexual Medicine* (M Khera, M Alberson, & J Mulhall 2015) | [1:08:30]

**Stem cell treatment for ED**: [An Update on Regenerative Medicine Clinical Trials in Erectile Dysfunction: Have We Made Any Progress?](https://pubmed.ncbi.nlm.nih.gov/31196678/) | *European Urology Focus* (M Khera et al. 2019) | [1:09:00]

**PRP for ED**: [Platelet-Rich Plasma (PRP) Improves Erectile Function: A Double-Blind, Randomized, Placebo-Controlled Clinical Trial](https://pubmed.ncbi.nlm.nih.gov/33906807/) | *The Journal of Sexual Medicine* (E Poulios et al. 2021) | [1:12:15]

**PRP treatment of ED, preliminary results**: [LBA01-12 Platelet rich plasma for the treatment of erectile dysfunction: a prospective, randomized, double blind, placebo controlled clinical trial](https://www.auajournals.org/doi/10.1097/JU.0000000000003360.12) | *Journal of Urology* (B Ledesma et al. 2023) | [1:13:00]

**Ejaculatory disorders guidelines**: [Disorders of Ejaculation: An AUA/SMSNA Guideline (2020)](https://www.auanet.org/guidelines-and-quality/guidelines/disorders-of-ejaculation) | [AUA](https://www.auanet.org/) | [1:15:15]

**Effect of different SSRIs on ejaculation time**: [Relevance of methodological design for the interpretation of efficacy of drug treatment of premature ejaculation: a systematic review and meta-analysis](https://pubmed.ncbi.nlm.nih.gov/14961051/) | *International Journal of Impotence Research* (M Waldinger et al. 2004) | [1:23:30]

**hCG prevents decrease in intratesticular testosterone**: [Low-dose human chorionic gonadotropin maintains intratesticular testosterone in normal men with testosterone-induced gonadotropin suppression](https://pubmed.ncbi.nlm.nih.gov/15713727/) | *Journal of Clinical Endocrinology and Metabolism* (A Coviello et al. 2005) | [1:48:00]

**Lipshultz’s study giving testosterone with hCG**:

- [The Use of HCG-Based Combination Therapy for Recovery of Spermatogenesis after Testosterone Use](https://pubmed.ncbi.nlm.nih.gov/25904023/) | *The Journal of Sexual Medicine* (E Wenker 2015) | [1:48:45]
- [Concomitant Intramuscular Human Chorionic Gonadotropin Preserves Spermatogenesis in Men Undergoing Testosterone Replacement Therapy](https://www.auajournals.org/doi/10.1016/j.juro.2012.09.043) | *Journal of Urology* (T Hsieh et al 2016) | [1:48:45]

**Review of therapeutics to preserve spermatogenesis during testosterone treatment**: [The treatment of hypogonadism in men of reproductive age](https://www.fertstert.org/article/S0015-0282(12)02430-2/fulltext#secd79422632e553) | *Fertility and Sterility* (E Kim et al. 2012)

**Intranasal administration of testosterone may no inhibit spermatogenesis**: [Comparison of Intratesticular Testosterone between Men Receiving Nasal, Intramuscular, and Subcutaneous Pellet Testosterone Therapy: Evaluation of Data from Two Single-Center Randomized Clinical Trials](https://pubmed.ncbi.nlm.nih.gov/35791295/) | *The World Journal of Men’s Health* (P Diaz et al. 2023) | [1:51:00]

**Testosterone levels induced by gels, injections, and pellets**: [Comparison of the Effects of Testosterone Gels, Injections, and Pellets on Serum Hormones, Erythrocytosis, Lipids, and Prostate‐Specific Antigen](https://www.sciencedirect.com/science/article/pii/S2050116115300696?via%3Dihub) | *Sexual Medicine* (A Pastuszak et al. 2015) | [1:58:00]

**Risk of erythrocytosis with high doses of testosterone given IM**: [Comparative assessment of outcomes and adverse effects using two different intramuscular testosterone therapy regimens: 100 mg IM weekly or 200 mg IM biweekly](https://pubmed.ncbi.nlm.nih.gov/34257404/) | *International Journal of Impotence Research* (F El-Khatib et al. 2022) | [2:00:00]

**Testosterone gels are often not absorbed**: [Efficacy of changing testosterone gel preparations (Androgel or Testim) among suboptimally responsive hypogonadal men](https://pubmed.ncbi.nlm.nih.gov/17898800/) | *International Journal of Impotence Research* (E Grober et al. 2008) | [2:00:45]

**Depression and sexual function associated with androgen receptor sensitivity**: [Testosterone, mood, behaviour and quality of life](https://onlinelibrary.wiley.com/doi/10.1111/andr.12867) | *Andrology* (M Zitzmann 2020) | [2:04:00]

**Mohit’s study of post-finasteride syndrome**: [Differential Gene Expression in Post-Finasteride Syndrome Patients](https://pubmed.ncbi.nlm.nih.gov/34247957/) | *The Journal of Sexual Medicine* (S Howell et al. 2021) | [2:12:15]

**TRAVERSE study shows no increase of cardiovascular risk with testosterone replacement**: [Cardiovascular Safety of Testosterone Replacement Therapy](https://www.nejm.org/doi/full/10.1056/NEJMoa2215025) | A Lincoff et al. 2023) | [2:14:00]

**Previous episodes of** ***The Drive*** **on testosterone and testosterone replacement therapy**:

- [#180 – AMA #28: All things testosterone and testosterone replacement therapy](https://peterattiamd.com/ama28/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (October 19, 2021) | [2:16:30]
- [#196 – AMA #32: Exercise, squats, deadlifts, BFR, and TRT](https://peterattiamd.com/ama32/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (February 21, 2022) | [2:16:30]
- [#84 – AMA #10: Low testosterone, hypothyroidism, building muscle (and preserving it while fasting)](https://peterattiamd.com/ama10/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (December 16, 2019) | [2:16:30]

**Testosterone guidelines**: [Evaluation and Management of Testosterone Deficiency (2018)](https://www.auanet.org/guidelines-and-quality/guidelines/testosterone-deficiency-guideline) | [AUA](https://www.auanet.org/) | [2:18:00]

**TRAVERSE trial**: [Effects of long-term testosterone treatment on cardiovascular outcomes in men with hypogonadism: Rationale and design of the TRAVERSE study](https://www.sciencedirect.com/science/article/pii/S0002870321004671?via%3Dihub) | *American Heart Journal* (S Bhasin et al. 2022) | [2:18:45]

**Treating metastatic prostate cancer with testosterone**: [Effect of bipolar androgen therapy for asymptomatic men with castration-resistant prostate cancer: results from a pilot clinical study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4507510/) | *Sci Transl Med.* (M T Schweizer et al. 2015) | [2:19:30]

**TRANSFORMER trial**: [TRANSFORMER: A Randomized Phase II Study Comparing Bipolar Androgen Therapy Versus Enzalutamide in Asymptomatic Men With Castration-Resistant Metastatic Prostate Cancer](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8274807/) | *Journal of Clinical Oncology* (S Denmede et al. 2021) | [2:21:30]

**Testosterone therapy after radical prostatectomy may be protective**: [Testosterone replacement therapy reduces biochemical recurrence after radical prostatectomy](https://bjui-journals.onlinelibrary.wiley.com/doi/10.1111/bju.15042) | *BJUI* (T Ahlering et al. 2020) | [2:22:00]

**Mohit’s mouse study of treating prostate cancer with high doses of testosterone**: [Testosterone inhibits the growth of prostate cancer xenografts in nude mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5588749/) | *BMC Cancer* (W Song et al. 2017) | [2:22:45]

**Prostate saturation model**: [Changes in prostate specific antigen in hypogonadal men after 12 months of testosterone replacement therapy: support for the prostate saturation theory](https://pubmed.ncbi.nlm.nih.gov/21788049/) | *The Journal of Urology* (M Khera et al. 2011) | [2:26:15]

**Perspective on testosterone therapy in patients with prostate cancer**: [The safety of testosterone supplementation therapy in prostate cancer](https://pubmed.ncbi.nlm.nih.gov/25069737/) | *Nature Reviews Urology* (J Dupree et al. 2014)

**Mohit’s website:** [Dr. Mohit Khera: Men’s Health Urology](https://www.drmohitkhera.com/)

**Mohit’s educational videos**: [Patient Resources](https://www.drmohitkhera.com/patient-resources/) | [Dr. Mohit Khera: Men’s Health Urology](https://www.drmohitkhera.com/)

§

## People Mentioned

- [Sharon Parish](https://weillcornell.org/sjparish) (Professor of Medicine in Clinical Psychiatry at Weill Cornell Medicine, expert in sexual medicine) [31:00, 2:29:30]
- [Ian Thompson](https://www.texasurologygroup.com/ian-m-thompson-jr-md) (Professor and Chairman of the Urology Division at the University of Texas Health Sciences Center at San Antonio, Texas) [32:45]
- [Piero Montorsi](https://www.unimi.it/en/ugov/person/piero-montorsi) (Professor of Clinical Science and Community Health at the University of Milan Centro Cardiologico Monzino, expert in cardiovascular disease) [33:00]
- [Katherine Esposito](https://www.researchgate.net/scientific-contributions/Katherine-Esposito-39255040) (Professor of Endocrinology and Metabolic Diseases at University of Campania “Luigi Vanvitelli”) [34:45]
- [Yoram Vardi](https://www.researchgate.net/profile/Yoram-Vardi) (Urologist at the Ministry of Health, Israel, expert in ED) [1:03:00, 1:05:00]
- [Edward (Ted) Schaeffer](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=34261) (Urologist and Chair of the Department of Urology at Feinberg School of Medicine and Program Director of the Genitourinary Oncology Program at the Robert H. Lurie Comprehensive Cancer Center of Northwestern University) [4:30, 2:09:00]
- [Andrea DiPrincipe Coviello](https://medicine.duke.edu/profile/andrea-diprincipe-coviello) (Professor of Medicine at Duke University in the division of Endocrinology, Metabolism, and Nutrition) [1:48:15]
- [Larry Lipshultz](https://www.larrylipshultz.com/about/dr-larry-lipshultz) (Professor of Urology and Chief of the Division of Male Reproductive Medicine and Surgery at the Baylor College of Medicine [1:49:00]
- [Michael Zitzmann](https://www.researchgate.net/profile/Michael-Zitzmann) (androgen receptor expert, MD, PhD at the Center of Reproductive Medicine and Andrology, University of Münster) [2:04:00]
- [Michael Schweitzer](https://oncology.uw.edu/people/michael-schweizer) (Associate Professor, Division of Medical Oncology, University of Washington and Associate Professor, Clinical Research Division, Fred Hutchinson Cancer Center) [2:19:30]
- [Samuel Denmeade](https://www.hopkinsmedicine.org/profiles/details/samuel-denmeade) (Professor of Oncology and Co-Director of the Prostate Cancer Program at Johns Hopkins University) [2:19:30]

§

![](https://peterattiamd.com/wp-content/uploads/2023/06/bio-image-mohit-500x500.jpeg)

##### Mohit Khera, M.D., M.B.A., M.P.H.

Mohit Khera received his Bachelor of Science from Vanderbilt University, and went on to earn his Master’s degree from Boston University School of Medicine. Dr. Khera then earned both a M.B.A. and a M.P.H. from Boston University. He then earned his M.D. at the University of Texas Health Science Center. Dr. Kera completed his internship in general surgery,  residency in urology, and fellowship in male reproductive medicine and surgery, all at Baylor College of Medicine.

Dr. Khera is a Professor of Urology and the F. Brantley Scott Chair in Urology at [Baylor College of Medicine](https://www.bcm.edu/people-search/mohit-khera-24469), the Director of the Laboratory for Andrology Research at the McNair Medical Institute and serves as the Medical Director of the Executive Health Program at Baylor. He also serves as the President-Elect of the Sexual Medicine Society of North America.

Dr. Khera has dedicated his clinical and research efforts to three main areas: men’s health, sexual medicine, and hormone replacement therapy. Dr. Khera has conducted extensive research on various topics related to his specialty, including the effectiveness of botulinum toxin type A in treating Peyronie’s disease, genetic and epigenetic studies on post-finasteride syndrome patients, and testosterone replacement therapy. In addition to basic science research, he has initiated numerous clinical trials. His basic science and clinic experiences have allowed him to thus far give over 250 lectures at scientific meetings throughout the world, publish over 120 articles in peer reviewed journals, complete 15 book chapters, and edit and write two books in the field of sexual medicine and men’s health. In 2007 he was awarded the American Urologic Association (AUA) Research Scholars Award to study the correlation between ED and BPH. In 2013 he was elected to serve a 4 year term on the American Urologic Society Examination Committee. Dr. Khera has also served on the AUA Peyronie’s Disease and Erectile Dysfunction Guidelines Panel. For the past several years he has taught numerous courses in testosterone therapy and sexual dysfunction throughout the world. [[Dr. Mohit Khera](https://www.drmohitkhera.com/about/)]

Instagram: [@drmohitkhera](https://www.instagram.com/drmohitkhera/?hl=en)

Twitter: [@DrMohitKhera](https://twitter.com/drmohitkhera?lang=en)