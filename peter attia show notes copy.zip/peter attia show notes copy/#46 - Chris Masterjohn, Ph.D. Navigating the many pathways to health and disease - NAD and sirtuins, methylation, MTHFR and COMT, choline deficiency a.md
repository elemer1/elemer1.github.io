# #46 – Chris Masterjohn, Ph.D.: Navigating the many pathways to health and disease – NAD and sirtuins, methylation, MTHFR and COMT, choline deficiency and NAFLD, TMAO, creatine and more

**Source:** [https://peterattiamd.com/chrismasterjohn/](https://peterattiamd.com/chrismasterjohn/)

---

In this episode, Chris Masterjohn, entrepreneur, independent researcher and doctorate in nutrition, elucidates the latest research on the risk and benefits of NAD supplements, and shares his personal intuition on the topic. We also dive deep into choline deficiency and its role in the rising prevalence of nonalcoholic fatty liver disease. From there, Chris enlightens us on the importance of methylation, a simple yet profoundly important biochemical process affecting our physical and mental health. He also describes the variations of the genes MTHFR and COMT, enzymes which play important roles in methylation and which have profound impacts on our well-being.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/chrismasterjohn/the_Drive_public.png)

Play

#46 - Chris Masterjohn, Ph.D.: Navigating the many pathways to health and disease - NAD and sirtuins, methylation, MTHFR and COMT, choline deficiency and NAFLD, TMAO, creatine, and more

#46 - Chris Masterjohn, Ph.D.: Navigating the many pathways to health and disease - NAD and sirtuins, methylation, MTHFR and COMT, choline deficiency and NAFLD, TMAO, creatine, and more

1x15s30s

0:002:51:59

## We discuss:

- Chris’s background, falling in love with biochemistry, and decision to pursue research over medicine [7:45];
- Choline: what it is, why it is important, and how a deficiency can cause non-alcoholic fatty liver disease [11:45];
- NAFLD: increasing prevalence and potential causes [25:00];
- TMAO: Should we be worried about the TMAO content in choline and our foods? [39:15];
- Types of fatty acids: How they may predispose us to different types of illnesses [53:30];
- Why don’t we see low VLDL in patients with NAFLD? [59:45];
- Understanding flux, and how machine learning may affect medicine in the near future [1:03:15];
- NAD: How it works, supplements, sirtuins, and the central role of the liver [1:09:30];
- Intravenous NAD [1:33:00];
- Oral NR: Is it the optimal way to get more NAD? [1:38:30];
- What is the possible harm of taking an NAD precursor? [1:47:15];
- The MTHFR gene [1:49:45];
- The methylation pathway [1:58:15];
- The COMT gene [2:04:30];
- Creatine: The uses and benefits and it’s important role in methylation [2:10:15];
- Dietary strategies for MTHFR: choline, creatine, folate and glycine [2:16:45];
- How to mitigate the negative effects of NAD supplements [2:23:45];
- A case study of a person with high homocysteine [2:28:00];
- What is the level of evidence that you need to take an action? [2:32:15];
- Does Chris supplement with NAD precursors? And can it improve symptoms of rosacea? [2:35:45];
- Decision making in the face of inconclusive data, and trying to disentangle the placebo effect [2:39:00];
- What does Chris believe to be true that very few people would agree with him about? [2:43:15];
- How to follow Chris’s work [2:48:45]; and
- More.

§

## Show Notes

## Chris’s background, falling in love with biochemistry, and decision to pursue research over medicine [7:45]

- Born in Queens
- Grew up in a small town in Massachusetts

College

- Undergrad in history
- Looking for the most efficient way to get an undergrad that would be relevant to being a social studies teacher
- But profound experiences with his personal health made him decide he wanted to go to medical school (which he didn’t end up doing)

While taking required course to be able to apply to medical school…

- Began falling in love with biochemistry and molecular biology and “all the little invisible things that we couldn’t see”
- Decide to go into research instead of medicine
- Got his Ph.D. in Nutritional Sciences from the University of Connecticut

> “I really wanted to do is take my own experiences and pay them forward in some way. And I think the best way that I can do that is by using the creative part of my brain to really immerse myself in the research and come up with new ideas.”

Peter’s take on what to major in during undergrad

- “I always think the worst thing you can do is do an undergrad in what you’re necessarily going to do in graduate school. . .it’s better to do something completely different.”
- Recently gave his take on this topic in [AMA #4](https://peterattiamd.com/ama04/)

Chris on the benefit of looking back at history:

> “I think one of the things that we often neglect in science is we get so caught up in the latest research that we forget to study the foundations of where things came from. My instinct is always to say, well, ‘where did this idea come from? What was the origin of this?’ And that inevitably leads to finding a fresh way to look at something because you realize the path that led you there, and that there were details that got left behind because no one knew what to do with those details at that time.”

## Choline: what it is, why it is important, and how a deficiency can cause non-alcoholic fatty liver disease [11:45]

**Paper that said TMAO would lead to atherosclerosis**: [Gut Microbe-Generated Trimethylamine N-Oxide From Dietary Choline Is Prothrombotic in Subjects](https://www.ahajournals.org/doi/10.1161/CIRCULATIONAHA.116.025338)

- And since choline contains TMAO, choline was now starting to be considered dangerous
- Peter and Chris both had some problems with the science around this thesis

*What is* [*choline*](https://en.wikipedia.org/wiki/Choline) *(chemically speaking)?*

- Choline is a methyl donor
- Choline is an essential part of [acetylcholine](https://en.wikipedia.org/wiki/Acetylcholine) (a neurotransmitter)
- Choline is an essential part of [phosphatidylcholine](https://en.wikipedia.org/wiki/Phosphatidylcholine) (a phospholipid that is in our cell membranes)

*What is a methyl group? And what is methylation?*

- We are biological organisms
- All biological organisms are made of hydrocarbons
- And if you look at any molecule in our body, it’s mostly a string of carbons
- If you want to change one of those molecules, you’re going to have to put together carbons, or take them apart
- You can either put together carbons in two carbon units ([acetyl groups](https://en.wikipedia.org/wiki/Acetyl_group))
- Or you can put together carbons in one carbon units ([methyl groups](https://en.wikipedia.org/wiki/Methyl_group))
- To methylate = “to put on a methyl group”

*What foods contain choline?*

- A lot can be found in…
  - Liver
  - Egg yolks
- Moderate amounts found in…
  - Meat
  - Nuts
  - Low carb veggies (cruciferous)

*Choline deficiency and fatty liver*

- Patients were being fed via [total parenteral nutrition](https://en.wikipedia.org/wiki/Parenteral_nutrition#Total_parenteral_nutrition) (TPN)
- They were not given choline (a.k.a. They were choline deficient)
- These people developed fatty livers

⇒ Why?

- Choline is an essential part of the phospholipid called phosphatidylcholine
- And because that phospholipid is not just in our cell membranes, but it’s also in the membranes of the lipoproteins that carry fat out of the liver
- If you don’t have enough choline, you can’t make the LDL particle to get triglycerides out of the liver

Historical animal data:

⇒ “In the beginning of the 20th century, what we have is rodents developing fatty liver on the diets until they were able to either put choline in or reduce the sugar content. But in those animal experiments, what ultimately was shown was that it doesn’t really matter what the cause of the fatty liver is. As long as you have enough choline in the diet or you have some precursor to make choline, whether it’s sugar, alcohol, fat, as long as you have enough choline in the diet, you can clear those triglycerides out of the liver.”

Peter asks a question to clarify… *With enough choline, does one necessarily have to restrict any of the substrates that are predisposing them to more fat accumulating in the liver than exiting the liver?*

- “That’s what I would believe based on all of the animal experiments that were done.”
- “It baffles me that we don’t have human studies addressing exactly that.”
- There are human studies that put people in a controlled lab environment and when you [take the choline out of their diet they will develop fatty liver disease](https://www.ncbi.nlm.nih.gov/pubmed/11531217/)

**The two-hit hypothesis of fatty liver**

- First, short term development of [steatosis](https://en.wikipedia.org/wiki/Steatosis) (the simple fat accumulation)
- Putting a bunch of fat in the liver is kind of like building the kindling for a fire
- That person might not ever light that fire
- But all it takes is some hit of inflammation or oxidative stress that suddenly lights the fire
- Steatosis does not necessarily lead to [steatohepatitis](https://en.wikipedia.org/wiki/Steatohepatitis) ( fatty liver disease characterized by inflammation)
- But that you can’t develop steatohepatitis without steatosis, but there’s a fairly high probability that that will happen

*Can sufficient choline prevent fatty liver?*

- “The average person walking around out there who doesn’t have fatty liver, they don’t have fatty liver because of the choline in t their diet.” says Chris
- Peter asks, “Not because they’re consuming a paucity of the things that are uniquely fattening to the liver? The two most obvious being fructose, ethanol or highly abundant polyunsaturated fatty acids, things like that?”
- “It’s both”, says Chris

**Total parenteral nutrition studies in humans**

- [This experiment](https://www.ncbi.nlm.nih.gov/pubmed/2010061) took people that didn’t have any fat in their liver and then they put them on this experimental diet where they took the choline out of what they were already eating
- They probably were eating some sugar
- They were probably drinking some alcohol
- Those people didn’t have fatty liver ⇒ then they went on the TPN ⇒ they got fatty liver
- “But you don’t have to put them on TPN. You can just put them on a low choline diet.”

**Animal experiments**

- You can cause fatty liver with sucrose, or alcohol, or excess fat
- But no matter how you cause it, you just put in choline (or precursors to choline) at a high enough ratio and it will get rid of the fatty liver

> “So if we know in humans that you get fatty liver when you take the choline down, and we know in animals that you get rid of fatty liver if you put the choline up, then I would think that if you took the humans with the fatty liver and you put the choline up, you’d get rid of it. But for some reason that hasn’t been tested the way you’d think it would be.”

*How much choline is required in that situation?*

Hypothetical situation…

- Not someone who was avoiding eggs or anything like that. . .but presumably they weren’t having enough
- How much choline would you guess you’d have to put in the diet?
- And would you be able to achieve that through eating more foods rich in choline or would you actually need to supplement it?

⇒ Chris’s response:

- “I can only give you a wild guess and my wild guess would be about 1200 milligrams of choline. And you could get that by eating food, but it would be very difficult.”
- There are human [studies](https://www.ncbi.nlm.nih.gov/pubmed/17490963) where it has been shown that some people require 1,200 milligrams of choline a day
- In labeling [studies](https://www.ncbi.nlm.nih.gov/pubmed/11915037/)
  - If you take a random sample of people with [NASH](https://en.wikipedia.org/wiki/Non-alcoholic_fatty_liver_disease) (both a fatty liver and liver inflammation)
  - Look at their triglyceride export, it’s reduced by 75%
- “I think the average choline intake is probably somewhere around 300 milligrams.”

[*What is the RDA for choline?*](https://www.ncbi.nlm.nih.gov/books/NBK114308/)

- Women = 425
- Men = 550

## NAFLD: increasing prevalence and potential causes [25:00]

*Is NAFLD is more prevalent now than 20 or 30 years ago?*

- “Yeah. I think even though you can’t track the prevalence over time, you can assume that the prevalence has increased over time.”
- “Matched to obesity because that’s the overwhelmingly predisposing risk factor.”

*Is it more driven by a fat accumulation in the liver or choline being less prevalent in our diets (i.e. a clearance problem)?*

- “It’s hard to make an either or question about it, because It comes down to fat-in versus fat-out.”
- Choline is such an overwhelming factor in the “fat out” part of the equation
- Unlikely that we can show that there’s been a linear decrease in choline intake over those years
- More likely that we could show that there was a fairly linear increase in NAFLD over those years that **tracked with obesity**

Obesity and fatty liver disease

- Chris says 67% of people who have obesity have fatty liver, and 76% of people who have fatty liver have obesity
- Why? . . .
- The overwhelming reason (but not the only reason) for that is that the more obese you are, the more likely you are to have [visceral adiposity](https://en.wikipedia.org/wiki/Adipose_tissue#Visceral_fat)
- And the visceral fat pad directly empties into the [portal vein](https://en.wikipedia.org/wiki/Portal_vein) (a blood vessel that carries blood from the gastrointestinal tract, gallbladder, pancreas and spleen to the liver)
- And so it’s a huge factor in fat-in (compared to the [subcutaneous fat](https://en.wikipedia.org/wiki/Subcutaneous_tissue#Subcutaneous_fat) pad)
- “That’s probably a huge factor in why the metabolic health of someone who has relatively more visceral fat is so much worse than the person who has relatively more subcutaneous fat. It’s because you’re basically pounding the liver with fat all the time.”
- You don’t even have to eat anything, it’s just you’re always engaging in [lipolysis](https://en.wikipedia.org/wiki/Lipolysis) (freeing some free fatty acids)
- “And if you have this gigantic tube going right into the liver, just feeding fatty acids in all the time, then I think that’s the major thing.”

**The challenges of studying NAFLD**

Peter take…

- - The biggest challenge is removing the confounder of the reduction of NAFLD, which is weight loss
  - Fructose is one of the greatest drivers of NAFLD
  - And when you take fructose out of the diet, very often a person is going to lose weight
  - And so when ridding yourself of NAFLD after dramatically reducing fructose, the question becomes . . .

- *How much of that was due to the fructose reduction, and how much of that was due to the weight loss?*

Chris’s response…

- “This is a huge point that you’re making that applies so much broader than this discussion.”
- Whenever people make one change in their diet. . .they’re actually changing like 30 or 40 things in their diet.
- So, taking the fructose out of the diet in most cases means they are removing a bunch of junk food.
- What did they eat instead?
- They probably ate something different and better
- So the average person who takes fructose out (or goes on a low carb diet), they actually you probably increased protein, choline, riboflavin, zinc, etc.

> “And I think that the only way to make sense out of the human data is to take all of the animal data that does have precise controls on it . . . and not assume that the animal data always matches the human data. . . but if you can take all the animal data and you can say, ‘wow, everything that is in the human data makes perfect sense according to what the theory we get out of the animal data’ . . . then that’s what you do.”

**Fatty liver, fructose, and choline**

⇒ A rodent experiment from grad school

- In grad school, Chris fed rats a 60% fructose diet (an enormous amount)
- He was trying to give them fatty liver
- The rats **did not** get fatty liver
- *Why?* ⇒ Turns out the rat diet included amino acids that has 6 times more [methionine](https://en.wikipedia.org/wiki/Methionine) (a precursor for choline)

⇒ Looking at methionine/choline-deficient mouse models

- It used to take an 80% sucrose diet (if the nutrients came from whole foods) to give rats fatty liver
- Once they started producing chemically defined diets, it was only 50% sucrose to cause fatty liver
- Further reducing the sucrose content could reduce the fatty liver
- Additionally, the people took those same high sucrose diets and showed that you could add choline and/or methionine, or you could just up the protein, … and it just gets rid of the fatty liver

**In summary:**

*“When I look at the human data, I’m gonna say, ‘I do believe that reducing the fructose is going to reduce the amount of fat that the liver is producing from sugar,’ but I also believe that if you did that and you replaced it with protein, then that was part of the results. Or if you replaced it with vegetables, or you replaced it with egg yolks, those were part of the results.” —Chris*

⇒ Peter: *“It’s very difficult.”*

**⇒ JAMA paper:** [Effect of a Low Free Sugar Diet vs Usual Diet on Nonalcoholic Fatty Liver Disease in Adolescent Boys: A Randomized Clinical Trial.](https://www.ncbi.nlm.nih.gov/pubmed/30667502)

- Took 40 hispanic boys with biopsy-proven NASH
- Eight weeks put them on a virtually zero fructose diet with no instruction to reduce carbohydrate
- In fact, the idea was replace fructose with glucose (glucose is not going to produce fatty liver in almost any quantity)
- They saw a 50% reduction on MRI in liver fat
- But they also lost three pounds on average
- “Now, I don’t know that the three pounds matters that much, but I think your broader point is they almost assuredly cleaned up the quality of their diet in ways that’s difficult to measure, even just looking at the macros.”
- Peter suggests to Chris that he reach out to Miriam Vos to see if she can provide more information about the food supplied for the study so that he could determine potential levels of choline
- “This was a very well controlled study in that the food was provided not just to the children but to their entire families. The idea was make it so easy for the child to be compliant for the eight weeks that they were on this diet that the entire family is gonna get fed the same food.”
- “I was really hoping that the results would come out independent, like there would be no change in weight, that the kids could maintain their body weight and then you could ask the question, ‘Could this nutritional intervention alter NAFLD independent of adiposity.’”

## TMAO: Should we be worried about the TMAO content in choline and our foods? [39:15]

[Trimethylamine N-oxide](https://en.wikipedia.org/wiki/Trimethylamine_N-oxide) (TMAO)

Prior to 2011 studies, it was mostly known for:

- Being found naturally in fish
- And being produced in the gut in very rare cases in people with genetic disorders who were consuming massive amounts of choline
  - This would produce a fish odor syndrome ⇒ These people are smelling like fish
  - So it was known that in cases of enormous choline loading, some of that choline would be converted to [trimethylamine](https://en.wikipedia.org/wiki/Trimethylamine) by gut bacteria

2011 Cleveland Clinic experiments

- [First in mice](https://www.nature.com/articles/nature09922)
  - Genetically engineered to have defects in their lipoprotein metabolism
  - They showed that TMAO was directly atherogenic
- In humans, two different papers. . .
  - The first one [looked at choline](https://www.ncbi.nlm.nih.gov/pubmed/23614584)
  - The second one [looked at meat](https://www.ncbi.nlm.nih.gov/pubmed/23563705)
  - They were showing that TMAO levels in humans correlate with heart disease risk
  - And when humans eat either choline or [carnitine](https://en.wikipedia.org/wiki/Carnitine), they will metabolize both of those to [trimethylamine](https://en.wikipedia.org/wiki/Trimethylamine) in the gut, and the liver will convert it to TMAO

⇒ After that, The argument was made that **TMAO in those humans will cause heart disease** the way that it causes heart disease in the genetically engineered mice

*And how do humans get too much TMAO (according to the study authors)?*

- Too much eggs and red meat (high in choline)
- But, the did NOT mention [fish](https://www.ncbi.nlm.nih.gov/pubmed/10456680) ⇒ Fish has ~100x more choline than eggs and red meat
  - How could they have not brought fish into this discussion??

⇒ Chris strongly disagrees with the hypothesis that TMAO causes heart disease

**Chris wrote a piece on this**: [Does Carnitine From Red Meat Contribute to Heart Disease Through Intestinal Bacterial Metabolism to TMAO?](https://www.westonaprice.org/carnitine-and-heart-disease/)

- “On a scale of one to ten, I wouldn’t say that my opinion that TMAO has negative properties in humans is zero. I think it’s maybe one or two or something like that.”

> “But…my view of the overall story that eating eggs and meat are bad for you because they alter the microbiome in a way that makes you take the choline and the carnitine in those foods and convert it into TMAO and make you uniquely vulnerable to heart disease, I’m very close to zero on the probability of that story being true.”

**Choline supplements and foods**

- Even though Chris doesn’t buy into the TMAO-heart disease hypothesis, he still takes precautions when it comes to choline supplements
- “When I’m looking at choline supplements, I overwhelmingly prefer that someone would get phosphatidylcholine, which is the overwhelming form of choline that’s found in food.”
- Why?
  - 1) Phosphatidylcholine is the form found in real food
  - 2) Phosphatidylcholine least likely to generate TMAO in the gut (because it’s absorption is better)

*How to dose a choline supplement?*

- Chris uses [lecithin](https://en.wikipedia.org/wiki/Lecithin), which is a phosphatidylcholine
- About 15% of phosphatidylcholine turns into choline
- Example, if someone needs 1200 milligrams of choline…
  - When taking a [lecithin](https://en.wikipedia.org/wiki/Lecithin) supplement (a phosphatidylcholine), you would need to take ~8 or 10 grams in order to get between 1000-1500 milligrams of choline
- Better to get choline from food, says Chris, but *“if you had to supplement, I would do it with lecithin.”*

**Eggs and choline/TMAO**

*Choline and blood clotting*

*⇒* [Recently published study](https://www.ahajournals.org/doi/full/10.1161/CIRCULATIONAHA.116.025338) where they fed people 500 mg of choline bitartrate over the course of two months and they did an in vitro assay on their blood and showed that it was more sensitive to clotting

- This may be an indication that having that level of TMAO in your blood is bad, “**but you cannot get that level of TMAO in your blood by eating four eggs, which supplies the same amount of choline**.”

*How does Chris know this?*

⇒ Steven Zeisel’s group [did a study](https://academic.oup.com/ajcn/article/100/3/778/4576437)

- Looked at plasma TMAO response to eggs
- If you eat enough eggs you get a plasma TMAO response, **but it’s three or four times lower than when you eat the same amount of choline as choline bitartrate**.

*Peter tells an anecdote from his ketogenic days*

- When eating keto for several years, Peter would often consume something like four egg whites, eight yolks
- He had done nine blood draws on nine consecutive days under various conditions and so they already had the serum
- They went back and looked at his TMAO level and *“Interestingly, I had virtually none.”*
- Peter’s intuition is that something in his gut prevented it from becoming problematic

*Enormous variability in the* [*Cleveland Clinic study looking at egg consumption and TMAO*](https://academic.oup.com/ajcn/article/100/3/778/4576437)

- In looking at the plasma TMAO response to eggs…
  - There was enormous variability
  - Everyone got some response to six eggs, but there was a lot of variation around the four egg mark
  - So half the subjects didn’t get any response at all until they ate four eggs
  - But some of the people got a very significant response to the four eggs (which is what you’d expect based on what the Cleveland Clinic group is arguing which is that the **gut microbiome is a big determinate**)
  - Peter: “*That was sort of my conclusion. . .my intuition was* ***something in my gut was really preventing this from becoming problematic****. I didn’t know what it was. I didn’t know if it could be replicated, but the story seemed a lot deeper than it was being presented.*”

**The absorption of choline**

*IMPORTANT POINT:* It’s not about how many eggs you eat in a day, it’s about **how many eggs you eat at a sitting**

- The only reason eggs generate TMAO is because there’s some poorly characterized absorption cap to phosphatidylcholine and even though it’s better absorbed than the other choline that’s sold on the market, there’s some cap to how much choline you can absorb
- But no one really knows where the cap is

*Where is it absorbed? What transporter? Is it an enterocyte transporter?*

⇒ It’s gotta be in the small intestine.

*Does it come as a single phospholipid or is it esterified in some way? . . . If you’re eating a food that’s high in phosphatidylcholine, does it actually show up like the analogous free fatty acid, or does it show up more as the analogous triglyceride where you get say two or three of these bound to a glycerol, bound to other fatty acids? Do these things actually show up as free phosphatidyl molecules?*

⇒ I believe that most of the phosphatidylcholine in most of the foods is going to be as phosphatidylcholine that are in cell membranes

*Does it come in through a chylomicron?*

⇒ I assume so. . . my guess is that you’re gonna have partial hydrolysis of some of the fatty acids and then the phosphatidylcholine is going to become probably part of the membrane of a chylomicron

Peter: *I’m wondering…if the bottleneck is at the enterocyte transporter and that’s why you’re limited in how many of these things you can get into the enterocyte, which then on the backside go into the chylomicron?*

- “That makes sense” says Chris
- Chris asked [Steven Zeisel](https://en.wikipedia.org/wiki/Steven_Zeisel) (expert on choline absorption) and his response was, *“I really don’t know. I assume that there’s some absorption cap in the small intestine. I have no idea what it is.”*

***Choline: Good guy or bad guy?***

- Peter: “The choline story is interesting and I think if you look at it over simplistically you could say, “Well, it’s a good guy and a bad guy,” but it seems to be **more of a good guy than a bad guy**.”
- Chris: “Certainly from the perspective of fatty liver that’s clear [that it is a good guy].”

**Choline and adiposity**

*Peter offers a hypothetical…*

- Someone is on a vegan diet (so no liver, no eggs)
- And say they are not eating many veggies and nuts (the “college” vegan diet)
- Would they get more fatty liver?

⇒ Chris: *“My guess is you probably wouldn’t because probably those vegans aren’t too fat, but I don’t know.”*

Visceral fat

- Peter: “There’s just something about **adiposity if it’s accompanied by visceral fat** that is really stoking the fire.”
- Chris: “Yeah. If you take out all the fat in parts of the equation, the choline is not gonna matter that much. It’s just that it becomes the bottleneck to getting **fat out** when you have a buildup of **fat in**.”

## Types of fatty acids: How they may predispose us to different types of illnesses [53:30]

Defining the types of fats: 1) Saturated 2) monounsaturated and 3) polyunsaturated (We can further divide the polyunsaturated into a number of constituents)

- A saturated fatty acid:
  - Specified by the number of [hydrocarbons](https://en.wikipedia.org/wiki/Hydrocarbon)
  - C8 has 8 carbons, versus a C12 would 12 carbons
  - Being saturated just means there are *no double bonds* ⇒ Every carbon is fully saturated with a hydrogen
- Monounsaturated fat has *one double bond*
- Polyunsaturated fat has *two or more double bonds*

That introduces a couple things…

⇒ First

- One thing is that whenever you introduce a double bond, you create a *kink in the molecule*
- So saturated fats ⇒ you can imagine them as just being straight and linear and you can pack them together very well, so *saturated fats tend to be solid*
- Less saturated fats (fats that are higher in monounsaturated and polyunsaturated fat) tend to be more liquid
  - I.e. Olive oil is more liquid than butter because it’s mostly monounsaturated fat

⇒ Secondly

- The other thing is that in a fatty acid with two or more double bonds (polyunsaturated fat), the carbon that’s between two of those double bonds is **very unstable and it is uniquely vulnerable to being damaged**.
  - We call that damage [lipid peroxidation](https://en.wikipedia.org/wiki/Lipid_peroxidation)
- So that fatty acid is *not harmful in and of itself* (and in fact there are polyunsaturated fatty acids that are absolutely essential for us) ⇒ Omega-6 and omega-3 (both polyunsaturated) that are both essential to human physiology
- But it’s also the case that *the more of these that you have in your cell membranes the more of a liability it becomes*
- Because if you have oxidative stress and inflammation, those fats are more vulnerable to damage

*How does this affect fatty liver?* ⇒ “It’s very, very tricky.”

In the short term (looking at only a couple weeks), human studies…

- Showed that over the course of a couple weeks, polyunsaturated fats compared to saturated fats lead to less liver fat
- If you take that at face value, *you would think that PUFAs are better to eat to avoid fatty liver*

⇒ There is a problem with that

- If you already have fatty liver (and it’s mostly PUFAs), you are **way more vulnerable to progressing from steatosis to steatohepatitis**
- Why? ⇒ Because you have more oxidative targets
- Generally you get more steatosis with longer chain length and more saturation, and you get less steatosis the shorter chain length or with less saturation
- However, if you have the steatosis, you have a **dramatic increase in the risk of progressing to steatohepatitis**

In the alcoholic model

- Studies show that you get *less steatosis with saturated fats than with polyunsaturated fats* (opposite of the non-alcoholics)
- Why?
  - I think the reason for this is that oxidative stress does not just cause you to go from NAFLD to NASH.”
  - It also can cause steatosis because you get oxidative destruction of the [ApoB particle](https://en.wikipedia.org/wiki/Apolipoprotein_B)

ApoB particle

- It’s not just choline that allows you to export triglycerides from the liver
- You also need sufficient antioxidant protection in the liver because if you damage that particle before it ever exports to triglycerides, then you prevent it from doing so.

How to reconcile these different animal models

- “Well, in the alcoholic model there’s so much oxidative stress already that’s provided by the alcohol, because the alcohol isn’t just a way to get fat in the liver, the alcohol’s metabolism generates oxidative stress.”
- “You’re taking a liver that doesn’t yet have fat accumulation, you’re putting a bunch of fat into it, and you’re adding on top of that an oxidative flame.”
- “You actually wind up causing steatosis by causing oxidative damage to the ApoB particle so that they can’t leave the liver in that model.”

**PUFAs are very complicated to think about**

- In the short term, in someone who doesn’t have a lot of stuff going on in their liver, they’re probably gonna be better eating PUFA
- In the long-term, if you’re talking about the progression from steatosis to NASH, **they’re a clear disadvantage**

## Why don’t we see low VLDL in patients with NAFLD? [59:45]

ApoB is used in two ways in the liver

- First is VLDL export (which is our main way to get triglycerides out of the liver)
- Second is for making de novo LDL in the liver

*Shouldn’t that mean we see a reduction in VLDL in patients with NAFLD?* ⇒ Peter has seen many patients with NAFLD but has not noticed an association with an alteration in VLDL

⇒ *Why?* Here is Peter’s possible explanation..

- If you have NAFLD, you are very likely insulin resistant
- If you are insulin resistant, you are upregulating [APOC3](https://en.wikipedia.org/wiki/Apolipoprotein_C3)
- If you are upregulating APOC3, your VLDL are going to stick around longer than if you do not
- That’s why we see these pathologic remnant VLDL particles that become atherogenic
- In an insulin sensitive person, the VLDL really don’t pose much of an atherogenic risk because they stick around for such a short period of time (APOC3 is quite down regulated in that scenario)
- If APOC3 is upregulated, you have VLDL starting to act like LDL ⇒ They stick around long enough in the plasma that they become atherogenic
- So maybe the less VLDL that’s being exported in that patient is offset by a longer residence time due to more APOC3.
- Chris points out: “Wouldn’t you also expect that from a lower rate of uptake of triglycerides from peripheral tissues?
- Peter: “That’s a great point. You have a lower peripheral disposal of triglycerides so the whole thing can be confounded.”

It’s also confounded by different ethnicities…

- African American patients even with type 2 diabetes will still have very low VLDL and triglycerides
- A Hispanic patient with diabetes will generally have a high triglyceride and a high VLDL
- Hispanics are actually far more susceptible to NAFLD than African American
- Caucasians are in the middle

## Understanding flux, and how machine learning may affect medicine in the near future [1:03:15]

Flux

- People struggle to understand flux, because you can’t understand flux with a snapshot.
- “You have to have the goddamn video” ⇒ you take a picture of something, you don’t know the flux, meaning what’s in, what’s out, where it’s being disposed of
- [Check out this post for more on the term “flux”](https://peterattiamd.com/how-to-make-a-fat-cell-less-not-thin-the-lessons-of-fat-flux/)

Analogy from Chris

- Imagine that you have a picture of a car accident
- If you zoom into the tire, you might not have any idea what happened
- The more you zoom out, and the more different angles that you have, you can start to build a story of what probably happened based on that snapshot
- But if you’re looking at one element in the snapshot, you can never even so much as build a story about what probably happened

> “Mistaking a concentration for flux is one of the overwhelming interpretive problems in science.”

Peter’s example,

- [Every quarter he does a 7 day fast](https://peterattiamd.com/ama02/)
- Snapshots of blood sample reveal things that, if looked at in isolation, look horrible
- For example, your free fatty acids get into the diabetic range.
- However…
- insulin is unmeasurable
- Glucose is 60 mg/dL
- Yes my FFA is 2 millimolar, but my BHB is 5 millimolar
- “Isn’t it possible that what you’re seeing is an incredible turnover of lipolysis?”
- So yeah, there’s a lot of free fatty acid there, but it’s in motion
- A diabetic person with high FFAs has a much more stagnant form of elevated FFA
- For example, a muscle that’s full of fat that’s going nowhere (diabetic) versus the fasted person where that fat is being turned over very quickly

*How can science overcome this problem?*

⇒ Use our understanding of biochemical pathways

- We have mapped out many biochemical pathways, says Chris
- “If you know all the possible sequences and you can measure all the metabolites, you can often reconstruct what a video would have shown with fairly good precision.”

⇒ Measure an abundance of things to see a fuller picture

- “If you measure 20 things in someone’s blood, you can have a much better idea of what’s going on, what probably happened than if you measure one thing in that blood.”

⇒ Serial measurements (even if it’s just a few markers)

- Example, oral glucose tolerance test…
  - Looking at fasting glucose and fasting insulin, you have some idea of what’s going on, *especially in extremes*
  - A person with a **fasting glucose is 70 mg/dL and their fasting insulin is one**, the probability that they’re going to have postprandial hyperinsulinemia is low
  - Similarly, you look at somebody whose **fasting glucose is 130 and their fasting insulin is 30**, the that person is likely headed towards a train wreck
- So by sampling at 30, 60, 90, and 120 minutes after a glucose challenge, you can develop a very interesting kinetic pathway using just two or three measurements

*Where will machine learning be most likely to displace human ability in medicine?*

- 1) **Radiology**: My intuition is most likely radiology, says Peter
- 2) **In the ICU**: I’ve often thought the ICU would be the second most valuable place just based on the reams of data that are coming out
- 3) **Flux**
  - Peter’s new epiphany during this conversation is that there may be a very interesting opportunity here for machine learning to also start to differentiate this question of flux
  - Peter often asks himself when looking at a blood test, “Can I infer the movement, the velocity or the derivative, the time derivative of this molecule or that molecule?”
  - “Maybe that is an interesting place for machine learning to start to play a role, because I do suspect it will do a better job than me.”

## NAD: How it works, supplements, sirtuins, and the central role of the liver [1:09:30]

NAD precursors are “*the most sought after, discussed, asked about supplement on the market today*”

- Many have heard of the precursor called [nicotinamide riboside](https://en.wikipedia.org/wiki/Nicotinamide_riboside) (NR)
- Many think NAD is the “fountain of youth” because NAD is a substrate to [sirtuins](https://en.wikipedia.org/wiki/Sirtuin)

For more on sirtuins and NAD see a previous episode of [The Drive with David Sinclair](https://peterattiamd.com/davidsinclair/)

Very popular NAD supplements

- [Basis by Elysium](https://www.elysiumhealth.com/en-us/basis?gclid=Cj0KCQjwpsLkBRDpARIsAKoYI8yW0EH5_LB84j4Q2yQxWVXPWXNlDnF8U3oDnCR_XyQShopjSZon9bQaAjUPEALw_wcB) (includes [pterostilbene](https://en.wikipedia.org/wiki/Pterostilbene), which is a sirtuin activator)
- [Tru Niagen by ChromaDEX](https://www.truniagen.com/product_page.html) (no sirtuin activator)

**How NAD works**

- In our cells we have [mitochondria](https://en.wikipedia.org/wiki/Mitochondrion)
- Mitochondria have a ton of complexes which are basically used to generate reducing agents that move electrons to one side of a double membrane
- This process builds up a gradient and then that gradient allows us to make a bunch of [ATP](https://en.wikipedia.org/wiki/Adenosine_triphosphate)
- That whole process is called [oxidative phosphorylation](https://en.wikipedia.org/wiki/Oxidative_phosphorylation)

[![](https://peterattiamd.com/wp-content/uploads/2019/03/oxdative-phosphorylation-1024x927.png)](https://en.wikipedia.org/wiki/Oxidative_phosphorylation)**Figure 1. Oxidative phosphorylation.** Image credit: [wikipedia.org](https://en.wikipedia.org/wiki/Oxidative_phosphorylation)

- The first of these complexes turns NADH to NAD
- It has been postulated that as we age our ratio of NAD to NADH goes down
- That ratio is an indication that we have less NAD
- And NAD is an important substrate for sirtuins (which do many things but primarily repair DNA damage)
- So it would seem that **we would want more NAD**

Another reason for NAD depletion

- Sirtuins and the [PARP](https://en.wikipedia.org/wiki/Poly_(ADP-ribose)_polymerase)s are consuming a lot of NAD
- These two enzymes that are using NAD for the purpose of protecting DNA, [telomeres](https://en.wikipedia.org/wiki/Telomere), and all the things that are postulated to be important to aging and longevity
- Peter agrees: “It’s hard to know why NAD levels might be low. Is it low because of high consumption and high demand? Or is it low because of low production?”

Chris summarizes:

- Well also if you’re looking at the *ratio of NAD to NADH*, then I think that being in the overfed state is the thing that’s the problem
- If you’re talking about *NAD amount levels dropping*, then you’re looking at consumption by the PARPs and sirtuins that are consuming it for the purpose of repairing damage

**Why can’t we just eat more NAD?**

Niacin

- Collectively, we call all this stuff, [Niacin](https://en.wikipedia.org/wiki/Niacin)
- Niacin in the diet, it’s a vitamin B3

In foods

- In plant foods it comes in the form of [nicotinic acid](https://en.wikipedia.org/wiki/Niacin)
- In animal foods, it comes in the form of [nicotinamide](https://en.wikipedia.org/wiki/Nicotinamide)

If we eat a steak…

- Much of the niacin that’s in the steak is going to be in the form of NAD or NADPH
- But **NAD and NADH can’t be digested in the intestines**
- What we’re absorbing in the intestines is either nicotinic acid or nicotinamide

When using supplements…

- If you take a nicotinamide riboside (NR) supplement, you are absorbing the NR intact
- If you take a [nicotinamide mononucleotide (NMN) supplement](/does-nmn-improve-metabolic-health-in-humans/), you are probably digesting that down to NR or nicotinamide and then absorbing them
- “But we are definitely not absorbing NADH or NAD in the intestines.”

So when we’re eating food,

- Once we go into the [enterocyte](https://en.wikipedia.org/wiki/Enterocyte), we have nicotinic acid primarily being converted over to nicotinamide, and the intestinal cell tries to turn that into NAD
- But whatever the intestinal cell doesn’t turn into NAD itself, it passes on to the liver
- So now you have maybe some nicotinic acid
- You might also have some nicotinamide
- *In theory*, if you took a nicotinamide riboside (NR) supplement, you got some nicotinamide riboside
- What it doesn’t convert to NAD, it sends into the liver and the liver is the main site that’s really metabolizing all these forms for the entire body

In the liver…

- It’s going to try to convert as much of those many forms into NAD as possible
- Not even just for itself, but because it’s **going to hold a reserve of NAD for the rest of the body**
- And then almost everything that comes out of the liver and goes into the circulation is *nicotinamide* (the transport form of NAD)

Going to the tissues and becoming NAD

- And then those tissues will convert the nicotinamide into NAD
- So what we definitely don’t see is NAD and NADH being transported in the blood
- If you take an NR supplement, you will get some nicotinamide riboside into the blood but they are a *physiologically meaningless amount of the NAD* that wound up in that muscle cell from taking that supplement

**NR**

- When taking an NR supplement, it becomes NMN which then becomes NAD
- The liver is basically taking all of that NR and making NAD

- All of the NAD that is in any of your cells that are not the liver (aside from 5% in the kidney made from protein) is ultimately derived from circulating nicotinamide that the liver put out

*Is nicotinamide charged?* ⇒ No

*Does nicotinamide makes its way into a cell through an active or passive transporter?* ⇒ Active

**How does nicotinamide get converted into NAD once it gets to the cell?**

Two steps that our ATP dependent

- 1) It gets converted to [nicotinamide mononucleotide](https://en.wikipedia.org/wiki/Nicotinamide_mononucleotide) (NMN)
- 2) Then it gets converted into NAD
  - *NOTE: A portion to the NMN becomes NR, and then comes back to NMN* (Why? ⇒ If you’re trying to hold on to the nicotinamide and get it to NAD more than the rate at which you can make the NAD, you might convert some to NR to hold onto it)
- In summary:
  - Nicotinamide (NAM) ⇒ NMN ⇒ NAD

**What happens when sirtuins and PARPs consume NAD?**

- Enzymes like sirtuins and PARPs are using NAD for DNA repair
- What they do when they consume the NAD is they *release nicotinamide*

⇒ Example: Imagine you are a muscle cell…

- To get every molecule of NAD you have, *originally* you took some nicotinamide from the blood
- But then you did things with it
  - [oxidative phosphorylation](https://en.wikipedia.org/wiki/Oxidative_phosphorylation) ⇒ you don’t “consume” NAD in that process, you just cycle it back and forth (You use it over and over and over and over and over again)
  - Sirtuins and PARPs ⇒ They are engaging in protection and those enzymes will consume the NAD to generate nicotinamide
- The big problem here is that nicotinamide is an inhibitor of all those enzymes through negative feedback loop so you *MUST do something with the nicotinamide immediately, or you need to methylate it and pee it out*
- So you either **use the nicotinamide to make NAD, or you get rid of it**

**What happens when you take a gram of NR?**

Josh Rabinowitz 2018 papers:

1 [Nicotinamide adenine dinucleotide is transported into mammalian mitochondria.](https://www.ncbi.nlm.nih.gov/pubmed/29893687) (Davila et al., 2018)

2 [Quantitative Analysis of NAD Synthesis-Breakdown Fluxes](https://www.cell.com/cell-metabolism/pdfExtended/S1550-4131(18)30196-7) (Liu et al., 2018)

- Showed that there is a little bit of NR that gets into the blood
- And some of the NR gets into **some** of the cells, and not others (it can’t get to the brain, for example)
- The NR could get into the muscle cells ⇒ The problem is that there’s not a lot there: *“It’s basically practically meaningless.”*
- Really well designed study in that they can differentiate the pool of NAD that a muscle made from NR from the pool that it made from nicotinamide

2016 paper: [Loss of NAD Homeostasis Leads to Progressive and Reversible Degeneration of Skeletal Muscle](https://www.sciencedirect.com/science/article/pii/S1550413116303503)

- Showed that you do increase NAD in the muscle a lot when you supplement with the NR
- But it all comes from **nicotinamide that the liver had made in circulated in the blood**
- **They showed that they got a much less NAD response in the muscle with oral nicotinamide than they did with NR *even though* they also showed with very elegant tracers that it all got there as nicotinamide**

Hypothetical…

- You take one mol of NR orally
- The amount of NR that escapes the blood is so tiny
- Peter asks, *how much of the NR is “lost” in terms of it never gets to the cells in the form of nicotinamide?*
- The physiology suggests that a lot of the NR that doesn’t get into any particular cell isn’t actually “lost”

**A thought experiment**

- Chris asks Peter: *What is your thought on the following, would taking NR be more effective than nicotinamide?*
- Peter: “I think based on what you’re saying, I would now say nicotinamide would be a better substrate.”
- Chris: “That is what I would think, too.” … “**But it’s not.**”

*Why might it be more effective to take NR instead of NMN?*

- Imagine that the NR, the nicotinamide, nicotinic acid, whatever it was you ate, gets into the liver…
- We go from nicotinamide to NMN to NAD
- If we consume the NAD with sirtuins and PARPs, we come back to nicotinamide
- And having that nicotinamide around is a liability, because it’s going to inhibit all of the repair enzymes (sirtuins and PARPs)
- So we either want to make NAD out of it, or we want to get rid of it

⇒ So if you take oral nicotinamide…

- The oral nicotinamide is immediately a liability before it ever becomes NAD *because it can inhibit the sirtuins and the PARPs*
- So the liver has 2 things it can do
  - 1) It can methylate it to get rid of it and pee it into the urine
  - 2) it can make NAD

⇒ If you take oral NR…

- It then converts to NMN and then you *have to make NAD before you ever generate nicotinamide* and expose it to the detoxification process
- *Why is this happening?* ⇒ NR is a superior way to increase hepatic NAD because when it gets to the liver…
  - It can’t be immediately detoxified
  - It’s not immediately a threat to the sirtuins and PARPs
  - and it can only make NAD before it does anything else
- “If you’re presenting [the liver] with a thing that’s a threat (nicotinamide) and it has to make that decision, and it can only make so much NAD at once at one time, then you’re going to have much more waste in the detoxification pathway [as compared to] if you put the thing in (NR) that has to make NAD, that is not a threat when it makes NAD, and that has to actually generate NAD to ever be exposed to the detoxification pathway.”

**The central role of the liver**

- It’s controlling the flux throughout the entire body
- The liver is not just making NAD for itself,  it’s making NAD because it carries all of the reserves for the rest of the body as NAD
- Itt has a reserve pool of NAD that it holds onto for the specific purpose of a slow release of nicotinamide to the rest of the tissues that they will take up
- And then the *cells will have the immediate decision* to either detoxify it or make NAD.

⇒ Peter’s glucose analogy:

- It sort of parallels glucose ⇒ we have to maintain about 5 grams of glucose in our bloodstream at all times (10 g you have diabetes, 2 g means you die)
- “It’s an amazing problem where the liver is constantly titrating”
- So in this analogy, **NAD is to glycogen what glucose is to nicotinamide**

## Intravenous NAD [1:33:00]

- Some believe NAD given intravenously is the superior way to get it’s benefits
- Peter does not believe that to be the case, but he’s not sure *why*

*What is happening when you inject NAD into someone?*

- You’ve bypassed the liver, and it’s sitting there in the plasma
- Per anecdotal reports of the immediate response to that, is that they’re are causing an inflammatory response
- What is not clear is the kinetics of where that NAD is going
- *However*, some experiments have been able to show that there are varieties of mammalian cell types that do have the ability to take that NAD into the cells

*But what is the normal physiology?* *For people who are not injecting it, how does NAD get out of this cell in the first place?*

- It appears to be that extracellular NAD is from dead cells, dying cells, and maybe from cells that are undergoing some sort of stress response and are secreting it to some degree to reflect their energy status
- In other words, NAD is a *signaling molecule*

**NAD as a signaling molecule**

> “I think it’s very clear that if there is any role for extracellular NAD, it is as a signaling molecule.”

- There’s a whole class of extracellular NAD consuming enzymes
- So if NAD is not ever supposed to be outside of the cell, why would it be there? And what do those enzymes do?
- They break it down to use it as a signaling molecule
- So it has to be the case, that extracellular NAD is primarily a signaling function
- It’s definitely not a normal way of transporting NAD from tissue to tissue
- “What the signal means I think we’ll probably be debated if enough people care for a long time to come.”

**IV NAD**

- So when we inject NAD we’re thinking about transporting it to cells
- But the body thinks that it’s a signal so we’re amplifying a potentially negative signal

⇒ *But why do some people report benefits?*

- Maybe that has good consequences because maybe it’s some kind of rescue signal?
- If I’m trying to explain why are people reporting benefits from it, either it’s placebo or it’s doing something, says Chris
- “And if it’s not just placebo, my guess is that it’s probably having some signaling effect that is by virtue of luck doing something that the person is reporting is beneficial.”

## Oral NR: Is it the optimal way to get more NAD? [1:38:30]

**Oral NMN**

- Example is [riboflavin 5′-phosphate](https://en.wikipedia.org/wiki/Flavin_mononucleotide)
- “I would bet money that it’s not absorbed intact.”
- And that’s because NMN has a charged phosphate group on it
- And generally charged phosphates cannot cross cells, and so their hydrolyzed.
- “And even if it were to be true that there were transporters in the intestines that could take NMN up intact, it probably still would not be absorbed intact because the phosphatase is in the small intestine that cleave the phosphates off of all the molecules in the food you eat do so nonspecifically to all of the molecules in the food you eat.”
- I believe the NR gets intact because
  - The Rabinowitz group’s paper showed that it was [getting into the liver as NR](https://www.sciencedirect.com/science/article/pii/S1550413118301967?via%3Dihub=)
  - And because NR doesn’t have a charged phosphate on it

**Oral NR**

- So we’re taking super physiologic doses of NR (500 to a 1000 milligrams daily which are found in common NR supplements)…
- Using our glycogen analogy, we’re now increasing our *hepatic reservoir* of nicotinamide that we can slow drip out when it’s demanded
- “There’s promise based on the animal experiments, although in the human trials that they’d done, they haven’t shown any benefit of doing this at all.”

*The Brenner/ChromaDex studies in humans*

- In the [first study](https://www.ncbi.nlm.nih.gov/pubmed/27721479), they just took one person and they extensively characterized all the metabolites that were produced in three different compartments
- In [another study](https://www.ncbi.nlm.nih.gov/pubmed/29992272), they were measuring things that you would relate to health like glucose and triglycerides and **it didn’t look like it was doing anything good**

⇒ *Caveats. . .*

- Pretty short studies
- They’re not even measuring what we really care about
- And they’re not measuring what you would necessarily expect to see (which is harder to measure)

**The possible short-term and long-term benefits of NAD precursors**

- [Rabinowitz papers](https://www.sciencedirect.com/science/article/pii/S1550413118301967?via%3Dihub=) showed that the **turnover of NAD in the small intestine is 40 times what it is in muscle**

*How is this possible?*

- Consider the disease called [pellagra](https://en.wikipedia.org/wiki/Pellagra) (niacin deficiency), where do you see pellagra happening?
  - If you’re an optimist, you say the three D’s of dermatitis, diarrhea and dementia
  - If you’re a pessimist, you say the four D’s and you include death

⇒ In the brain…

- what’s going on is NAD is actually generating molecules that are directly involved in immediate neurotransmitter production ⇒ *“I think that’s why you see brain effects in pellagra.”*
- If you exclude the brain, the two tissues where you are seeing the most dramatic effect are the two tissues that are outside of the body

⇒ What about pellagra and skin issues?

- Well, when you’re out in the sun, you’re always experiencing DNA damage from that sunlight and you’re always repairing it
- So in the skin you have this very incredibly high NAD turnover, because even things that you normally think are benign (like just going outdoors) is actually causing damage that you are repairing always
- And so when you have the skin having a very high need to constantly repair itself, and then you take away its ability to do that, then suddenly you see this manifestation in the skin

⇒ In the gut. . .

- I think part of it is that it’s so energy intensive to maintain the cell turnover in the gut
- But also the gut is exposed to so many insults of just total lack of quality control over the things that come inside it

*What might be the* ***short-term*** *benefit of NAD?*

- In those tissues with the highest turnover (the skin and the small intestine)
- The challenge: It’s hard to design the ideal study to measure those things (as compared to measuring glucose and insulin and triglycerides and lipoproteins which they’ve already done)

*What might be the* ***long-term*** *benefit of NAD?*

- Increased genomic stability
- Decreased accumulation of DNA damage
- Increased telomere length
- “*None of which have been measured*.”

*The need for longer studies*

- To understand what it’s doing inside all of the other cells in the body, you’re going to need a much longer time horizon

> “We basically don’t have much data because we have these several-week-long studies in humans. If we’re going to look at things going on inside the body besides those tissues with super high turnover, I think we’re going to have to look at longer studies that have more relevant endpoints.”

## What is the possible harm of taking an NAD precursor? [1:47:15]

*If you’re cost-insensitive, what’s the downside in spending $100 a month to take these compounds?*

> “The potential risk is that you’re sapping your [methyl group](https://en.wikipedia.org/wiki/Methyl_group) supply.”

- Part of this cycle is when you do generate nicotinamide, you face the possibility that you have to [methylate](https://en.wikipedia.org/wiki/Methylation) it and you have to pee out the methylated metabolite
- If you’re taking 1,000 milligrams or 2,000 milligrams of NR a day (the RDA for niacin is around 15 milligrams), you are losing a lot of methyl groups

## The MTHFR gene [1:49:45]

Methyl groups

- A [methyl group](https://en.wikipedia.org/wiki/Methyl_group) is a one carbon unit
- The [methylation cycle](https://en.wikipedia.org/wiki/Methylation) uses the amino acid [methionine](https://en.wikipedia.org/wiki/Methionine) to donate that one carbon to dozens of different things

![](https://peterattiamd.com/wp-content/uploads/2019/03/methyl-group-1024x624.png)

**Figure 2. Methyl groups are used in the synthesis and regulation of many compounds.** Image credit: Chris Masterjohn

What we do there is…

- Using ATP, we activate methionine to [S-Adenosyl methionine](https://en.wikipedia.org/wiki/S-Adenosyl_methionine) (the universal methyl donor)
  - So no matter what we’re synthesizing or regulating, it is always S-Adenosyl-methionine that donates that one carbon, that methyl group
- Through two steps it becomes [homocysteine](https://en.wikipedia.org/wiki/Homocysteine) (the inevitable byproduct of using it)

![](https://peterattiamd.com/wp-content/uploads/2019/03/methylation-system-produces-S-adenosylmethionine-as-the-universal-methyl-donor-1024x678.png)

**Figure 3.** **The methylation system produces S-adenosylmethionine as the universal methyl donor.** Image credit: Chris Masterjohn

- Once we have homocysteine, we have two choices
  - 1) We can either get rid of the homocysteine (if we have an abundance of methyl groups) or…
  - 2) We recycle the homocysteine back to methionine (if we don’t have enough methyl groups)
- How to get from **homocysteine back to methionine**? 2 ways…
  - 1) [**Folate**](https://en.wikipedia.org/wiki/Folate) (vitamin B9) can take a methyl group from amino acid metabolism and can pass it on to [B12](https://en.wikipedia.org/wiki/Vitamin_B12) ⇒ B12 then passes it onto homocysteine ⇒ Homocysteine regenerates methionine. Or…
  - 2) **Choline** can be oxidized to [betaine](https://en.wikipedia.org/wiki/Betaine) ⇒ which can be then the methyl donor to recycle homocysteine to methionine
  - These two pathways are equivalent meaning in the avg. person they’re probably 50/50, *but it’s going to depend on their dietary intake*

![](https://peterattiamd.com/wp-content/uploads/2019/03/Half-of-methylation-is-supported-by-folate-and-B12-half-by-choline-or-betaine-1024x492.png)

**Figure 4.** **Half of methylation is supported by folate and B12, half by choline or betaine.** Image credit: Chris Masterjohn

What is the MTHFR enzyme?

- One of the enzymes that is involved in **constructing the methyl group** that came from the amino acid metabolism that became the folate molecule
- That’s how folate passed the methyl group on to B12 and then on to homocysteine to recycle methionine

**Everyone has MTHFR**

- We all have MTHFR, but there are variants of the gene
- The two common polymorphisms (gene variants in the MTHFR gene) are so spread out in the population that what you actually see as a gradient of MTHFR activity that’s fairly even spread across the population
- You could basically divide the population into quintiles of MTHFR activity
- Not exactly 20, 20, 20, 20, 20, but it would be fairly close to that

![](https://peterattiamd.com/wp-content/uploads/2019/03/MTHFR-polymorphisms-cause-an-almost-continuous-gradient-of-activity-equally-distributed-across-the-population.-1024x332.png)

**Figure 5. MTHFR polymorphisms cause an almost continuous gradient of activity equally distributed across the population.** Image credit: Chris Masterjohn

⇒ If you have limited ability to use folate for methylation, there are several things that happen…

- The first is that you use up more choline
  - You do that because you suck at using folate and you have no problem using choline.
  - You basically say, “I’m not that good at using this pathway. I’m going to use the alternative.”
  - Nutritionally, that makes the choline requirement go up
  - These people with the worst MTHFR activity are the ones who require 1,200 milligrams of choline

*Which SNPs would be the “worst” to have?*

- The worst case for MTHFR C677T = *homozygous for TT*
  - [rs1801133](https://www.snpedia.com/index.php/Rs1801133) is a SNP that is relatively common and has been studied for (relatively) a long time. Also known as C677T.
  - Homozygous for T = rs1801133(T;T)
- For the A1298C, “that one is less significant than the C677T”
  - [rs1801131](https://www.snpedia.com/index.php/Rs1801131) is a SNP in the MTHFR gene, representing an A>C mutation at mRNA position 1298, resulting in a glu429-to-ala (E429A) substitution (hence this SNP is also known as A1298C or E429A).
  - Homozygous for C = rs1801131(C;C)
- But you can have both of these

*What is the best case?*

- You have neither of C677T or A1298C (10 or 15% of the population)

*But if you’re not in the “best case”…*

- You are probably a CA, or a CT, and “you’re functionally pretty close to normal.”
  - For C677T, heterozygous for T = rs1801133(C;T)
  - For A1298C, heterozygous for C = rs1801131(A;C)

*“Wild type” in both (probably ~10% of the population):*

- For C677T, homozygous for C = rs1801133(C;C); and
- For A1298C, homozygous for A = rs1801131(A;A)

*It’s more like a spectrum*

- “It’s not exactly quintiles.”
- Varies by population
- There’s not a category that even has a large minority of the people in it
- It’s misleading to call it wild type and to say you have the mutation.
- It’s more like a spectrum

**Comparing the two extreme ends of methylation:** The people with the “best” and the “worst” “methyl folate status”

- The people who have bad methyl folate status **are the people who are doubling up the amount of choline that they’re blowing through for the cycle.**
- Peter points out that there’s an undeniable correlation when looking at your MTHFR status, **the lower you are in your capacity to efficiently do so, the higher your homocysteine is, all things equal**.

⇒ Therefore, *wouldn’t we expect that if they’re truly as efficient at methylation even using choline, shouldn’t they be able to compensate for that?*

- Chris:
  - “What you see in the literature is that studies that can show a statistically significant rise in homocysteine, **it is generally limited to the people who are in the worst-case scenario**.”
  - “What’s interesting is that if you subdivide those people by their **riboflavin status**, all the people who have the MTHFR genotype that look bad, that have high homocysteine, have bad riboflavin status.”
  - “The thing that lowers MTHFR activity with those polymorphisms is that MTHFR is a riboflavin-dependent enzyme (vitamin B2).”
  - “It has a lower affinity for the riboflavin as a cofactor, so you need better riboflavin status to optimize your MTHFR.”

*What about using vitamin B6?*

- Peter: “This is so counterintuitive because the thing that we find, clinically, that has the best hammer is B6.”
- Chris: “Because you’re not thinking about optimizing MTHFR activity, you’re thinking about getting the homocysteine.”
- Peter: “Do you think that’s the wrong way to think about it, clinically?”
- Chris: “Yeah, I think it’s the wrong way to think about it. I think it’s too simplistic . . . But if someone has high homocysteine that goes away with B6 supplementation, that person probably needed high B6.”

## The methylation pathway [1:58:15]

**Great resource from Chris**: [Start Here for MTHFR and Methylation](https://chrismasterjohnphd.com/2019/03/01/start-here-for-mthfr-and-methylation/)

Example, you eat a steak…

- Good thing: There’s a bunch of methionine in there and you can use that methionine for methylation
- The bad thing:
  - If you had this boatload of methionine that comes in, you’re going to generate a boatload of homocysteine
  - You also don’t have the problem of needing to recycle that homocysteine because you got a boatload of methionine coming in (it’s probably dripping into the liver and you can probably predict that if you have a lot right now, you’re going to have even more coming in 10 minutes)

*⇒ What do you do?*

- You totally shut down MTHFR which is the enzyme that uses choline
- And then you flip on this other enzyme that’s not usually active that gets rid of the homocysteine
- On top of that, you want to get rid of the extra methyl groups
- You turn on this other enzyme that is going to use the amino acid glycine as a buffer
- That glycine is going to, if it can, hold on to the methyl group for later use, but if you methylate too much of that glycine, you end up peeing it out

![](https://peterattiamd.com/wp-content/uploads/2019/03/When-SAMe-is-present-in-excess-homocysteine-is-broken-down-instead-of-recycled-and-glycine-soaks-up-the-extra-methyl-groups.-803x1024.png)

**Figure 6. When SAMe is present in excess, homocysteine is broken down instead of recycled and glycine soaks up the extra methyl groups.** Image credit: Chris Masterjohn

*⇒ So what is the B6 doing (which Peter uses clinically to reduce homocysteine)?*

- It’s activating the enzyme that kicked on when you ate the steak that helped you break down the homocysteine

*⇒ In the fed state*: Your MTHFR shuts down in the fed state if you ate protein

*⇒ In the fasted state*: The amino acid that falls most quickly when you fast is methionine

*⇒ So three days into a fast, you should have very high MTHFR activity?*  ⇒ “Yes.”

![](https://peterattiamd.com/wp-content/uploads/2019/03/When-SAMe-is-present-in-excess-the-lack-of-methylfolate-turns-on-the-glycine-buffer-system.-1024x600.png)

**Figure 7. When SAMe is present in excess, the lack of methylfolate turns on the glycine buffer system.** Image credit: Chris Masterjohn

*⇒ Tying it back to the patient taking B6 for high homocysteine*

- This is proof of concept that the B6 worked
- But the problem you addressed was not MTHFR
- “That means that part of their high homocysteine, it was a result of fed state homocysteine that should’ve been broken down using the vitamin B6 that wasn’t broken down because they didn’t have enough B6.”
- The B6 is working because those people need more B6.

**Is homocysteine a good indicator of whether you’re messing up your methylation?**

- Some data says that maybe the homocysteine is a problem in it of itself because:
  - it caused oxidative stress and
  - might contribute to cardiovascular disease,
- But it’s also just a marker that things aren’t working right in that cycle.

⇒ Not the only thing that goes wrong in the cycle. For example,

- Some people need 900 to 1,200 milligrams of choline because people who have low MTHFR activity are doubling the amount of choline that they blow through
- This issue has nothing to do with the homocysteine
- “The data indicate that those people have a higher choline requirement and the way that you address that is by consuming enough choline.”

**MTHFR and fatty liver**

*Given that a subset of patients are going to be burning through choline quicker and therefore have less choline to do its job in the liver?*

- “I would expect that that could be the case, but I don’t know of data on that.”
- Hopefully, there’s a graduate student listening to this because that would be a really interesting and elegant experiment to demonstrate that!

*For those in the worst case scenario of MTHFR*

- 900 or 1,200 milligrams of choline will do two things:
  - 1) it will minimize markers of oxidative DNA damage
  - 2) it brings choline utilization markers back down to what you would find in someone who didn’t have the MTHFR or polymorphism.
- If someone is using up more of their choline, I wouldn’t necessarily expect them to have fatty liver, **but I would expect them to have a higher probability of developing it if you put the other conditions in**.

*Recommendation for a choline supplement?*

- Chris would prefer food, first
- But if you’re going to do a supplement, Chris would prefer phosphatidylcholine over a choline salt

## The COMT gene [2:04:30]

**Video**: [What to Do ABout Your COMT Genes](https://www.youtube.com/watch?v=ZgrqePFMKEU&t=13s)

*What is getting synthesized in the methylation process?*

- 90% of the methylation process is done to synthesize **creatine** and to synthesize **phosphatidylcholine**
- Of the remaining 10%, the next most sensitive to methylation is [dopamine](https://en.wikipedia.org/wiki/Dopamine)

![](https://peterattiamd.com/wp-content/uploads/2019/03/synthesis-of-creatine-and-phosphatidylcholine-and-others-1024x369.png)

**Figure 8. Most of methylation is used for the synthesis of creatine and phosphatidylcholine, with other uses including**
**the catabolism of neurotransmitters.** Image credit: Chris Masterjohn

[COMT](https://en.wikipedia.org/wiki/Catechol-O-methyltransferase)

- COMT is the enzyme that methylates dopamine
- If you methylate more dopamine, *you are mentally more flexible*
- If you methylate less dopamine, *you are mentally more stable*
- If you’re in the middle of that, *it could just be a variation of your personality*
- But at the extreme ends of that spectrum, you start to get into the possibility of psychiatric disorders

[**The warrior vs. worrier phenotype**](https://www.ncbi.nlm.nih.gov/pubmed/17008817)

- This can apply to the people in the middle of that spectrum (i.e. not in the extremes)
- **The warrior** = the person who has a higher rate of methylating dopamine, is more mentally flexible, and that’s the person that picks the battle, faces it, picks the battle, faces it, defeats, and just moves from one thing to the next
- **The worrier** = low rate of methylation, gets stuck on things they’re worrying about
- There aren’t as many different types ⇒ It’s basically 50% of people are in the middle, 25% are in one end, 25% are on the other end

*The trade-off:*

**⇒ Worriers** (**low rate of methylation**)

- The good:
  - Better at things that require sustained focus, such as academics, striving for long-term goals, etc.
  - They may also do better in competition ⇒ There was a [recent study](https://www.tandfonline.com/doi/abs/10.1080/02640414.2017.1309058?scroll=top&needAccess=true&journalCode=rjsp20) that came out that showed that competitive swimmers who are the low methylation phenotype get better results, they appear to do better competitively.
- The bad:
  - You are predisposed to worry more because if you get an anxiety producing thought or a depression inducing thought in your mind to get stuck there more
  - More susceptible to OCD

**⇒ Warriors (high rate of methylation)**

- The good:
  - More mentally flexible
  - Less likely to overthink or dwell on things, can face a challenge and move to the next
- The bad:
  - More susceptible to substance abuse
  - ADHD is also associated with the high methylation phenotype

**Meta-analysis Chris said he would provide**: [Association between COMT Val158Met and psychiatric disorders: A comprehensive meta-analysis.](https://www.ncbi.nlm.nih.gov/pubmed/28608575)

*Does this Warrior/Worrier thing have diagnostic utility?*

- “I don’t think it has much diagnostic utility.”
- “I find it interesting from creating a theoretical model of how the stuff works.”

*Is the COMT going to determine your mental state?*

- No, “COMT is **not** a gene for a mental state.”
- “It’s a gene that has a **partial** influence on the ‘stickiness’ of your mind.”

**Nutrition and COMT**

- COMT methylates dopamine is with methyl donors
- So, *nutrition* is going to have an impact

> “Your COMT genotype is not going to tell you *the rate at which you’re methylating dopamine*, it’s going to tell you the **rate at which you** ***could*** **methylate dopamine given a certain supply of methyl donors**.”

## Creatine: The uses and benefits and it’s important role in methylation [2:10:15]

**MTHFR**

- You want to get between 900 and 1,200 milligrams of choline a day
- Get choline from food first (eggs, meat, protein)
- If you need to supplement, use a [phosphatidylcholine](https://en.wikipedia.org/wiki/Phosphatidylcholine)
- Take 5 grams of creatine monohydrate ⇒ *“supplementation with creatine makes a lot of sense because 45% of your methyl demand is to synthesize creatine”*

**Creatine**

- Creatine monohydrate is something that most people take for exercise
- Years ago people thought to load 20 grams a day for five days than five grams (cycle on and off)
- Now the literature suggests [5 g/day is plenty](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5469049/), says Peter

*Peter*: We think of that as creatine as a phosphate donor (i.e. weight training, the burst is really a phosphate donation from creatine, it’s not an ATP driven process)

**Choline’s role in synthesizing creatine**

- Whether you’re taking methyl groups from choline or you’re taking methyl groups from folate…
- What you do when you synthesize creatine is you start with [*guanidinoacetate*](https://en.wikipedia.org/wiki/Guanidinoacetate_methyltransferase_deficiency) *which you make from the protein in your diet and then you methylate it and that makes creatine*

*Creatine’s sensitivity to methyl group supply*

> “Creatine is the **only thing that is super sensitive to the methyl group supply”**

![](https://peterattiamd.com/wp-content/uploads/2019/03/creatine-sensitivity-1024x282.png)

**Figure 9. Creatine synthesis is most sensitive to the supply of methyl groups, while phosphatidylcholine and gene expression are least sensitive and neurotransmitters are intermediate.** Image credit: Chris Masterjohn

- You eat a steak
- You synthesize creatine right then
- But five hours later, you’re synthesizing nowhere near as much creatine

*Why is this the case?*

- Some things never change with the supply of methyl groups in your body
  - i.e. DNA methylation for gene expression ⇒ you don’t want to regulate thousands of genes because you ate a steak and you had a bunch extra methyl groups
- Others are “fairly acutely stable
  - i.e. dopamine and other neurotransmitters you don’t want that to go up “log fold” because you ate a steak
- Creatine is very sensitive to the amount of methyl group supply

*Creatine in the average person*

- Avg. person has 120 grams of creatine in their body and they will lose 2 grams of creatine everyday that they pee out in their urine
- “The whole point of creatine synthesis is to keep the accounts balanced.”
- If you synthesized no creatine in an entire day, your creatine drops from 120 grams to 118 grams ⇒ “It’s like barely a dent.”
- You just have to make sure that in 60 days from now, your creatine isn’t zero, it’s still 120 grams in your body

*Like AMPK is a great surrogate for ATP, do we have similar enzymes that give us a sense of CP versus C, creatine phosphate versus creatine?*

- “I don’t think there’s an analogous enzyme, but there’s a completely analogous energy state.”
- When you’re exercising, for example,
  - ATP levels go down and AMP levels go up ⇒ meanwhile your creatine phosphate levels go down and your creatine levels go up
  - When you recover, everything reverses.

**Creatine’s impact on performance**

- Many athletes like to use creatine is for increasing that maximal performance, or the duration of short maximal performance
- *But would creatine affect your ability to run a marathon? ⇒* “Yes. I think it *will* have an impact on your ability to run a marathon.” say Chris

- Because creatine does things in muscle that are independent of phosphate donation
- It hydrates the muscle which…
  - Makes your muscles look bigger
  - And also directly increases your muscular strength

## Dietary strategies for MTHFR: choline, creatine, folate and glycine [2:16:45]

**Videos by Chris on this topic:**

- [How to Know If You Need to Care About Your MTHFR | Chris Masterjohn Lite #32](https://www.youtube.com/watch?v=290QXvTVp_c&t=86s)
- [What to Do About MTHFR | Chris Masterjohn Lite #33](https://www.youtube.com/watch?v=290QXvTVp_c&t=86s)

**Who should consider modifying their diet for MTHFR reasons?**

⇒ It depends on…

1. what problems are you facing ?
2. what goals do you have ?
3. And to what degree do you want to be anal about doing things that have *theoretical* payoff?

***Strategy for the low methylators:***

- Such as someone who has either high homocysteine or they have psychiatric difficulties
- Or they are overly ruminating on things or feeling like mental health is an uphill battle

What to do:

- Most data backed thing is increasing your choline
- Should also increase creatine intake
- Methyl folate is also important (but overlooked in many cases)
- Glycine is also important

![](https://peterattiamd.com/wp-content/uploads/2019/03/ways-to-get-choline-1024x805.png)

**Figure 10. Ways to get choline from foods.** Image credit: Chris Masterjohn

Methyl folate and glycine

- Methyl folate is the thing that controls whether you pee out glycine as a methyl buffer
- “When your methyl folate level is low, your body thinks that you are in a state of methyl abundance and that you need to methylate glycine and pee out the methyl groups and the glycine into the urine.”
- So you probably need more glycine

Glycine

- We can synthesize glycine but the average person probably falls short of their ability to synthesize glycine by 10 to 60 grams a day (in terms of optimizing collagen turnover in the skin, etc.)
- Studies also show:
  - Better sleep with 3-6 grams before bed
    - [The sleep-promoting and hypothermic effects of glycine](https://www.ncbi.nlm.nih.gov/pubmed/25533534)
    - [Glycine ingestion improves subjective sleep quality in human volunteers](https://onlinelibrary.wiley.com/doi/full/10.1111/j.1479-8425.2007.00262.x)
  - [Better blood sugar](https://www.ncbi.nlm.nih.gov/pubmed/12450897) if they take 3 to 5 grams glycine with a meal
- “It’s entirely reasonable that the average person could use more glycine. “

![](https://peterattiamd.com/wp-content/uploads/2019/03/Glycine-is-calming-and-has-anti-psychotic-and-sleep-promoting-effects.-1024x714.png)

**Figure 11. Glycine is calming and has** **antipsychotic** **and sleep-promoting effects.** Image credit: Chris Masterjohn

Peter isn’t impressed with the data that taking collagen or glycine will help collagen synthesis

- “For the benefit of replacing their own collagen. I’ve always been like I just don’t see how that works.”
- Chris can’t argue: “There is no good data showing that you will have less wrinkles if you take collagen. I’ve never heard of any data on bone health.”

Peter think that glycine is more likely to be beneficial for:

- Blood sugar
- Sleep

**Can collagen improve the health of tendons?**

A study by Keith Baar: [Vitamin C–enriched gelatin supplementation before intermittent activity augments collagen synthesis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5183725/)

- Showed that before you exercise…  if you take 15 grams of gelatin (but not 5 grams) with a little vitamin C, **you will increase collagen synthesis in the tendons**
- The rationale for the study:
  - your muscles are very metabolically active and very good at taking things up when it wants to,
  - but the connective tissues in your joints are very dependent on you just pushing more blood supply there.
  - So, when you exercise, you have the amino acids coming in before you exercise, and then when you’re exercising, there’s increased blood flow that gets the collagen peptides into those tissues.

What foods would be high enough in glycine?

- Bones are the highest, and skin is intermediate.
- For bones…
  - It’s not the marrow, It’s the broth
  - It’s dependent on the protein content ⇒ “If you’re making it homemade, you don’t know exactly what the protein content is, I would use the metric of whether it’s well gelled.”
  - Several bone broth products on the market ⇒ Label says 10 grams of protein per cup which equal 3 grams of glycine
  - Ideally, you should take 3 to 5 grams
- *You’re gonna drink that before bed every night, and it might help you sleep?* ⇒ *“*In theory.”

![](https://peterattiamd.com/wp-content/uploads/2019/03/Nourishing-the-low-MTHFR-phenotype.-1024x761.png)

**Figure 12. Nourishing the low-MTHFR phenotype.** Image credit: Chris Masterjohn

## How to mitigate the negative effects of NAD supplements [2:23:45]

**Losing your methyl group supply**

From the [Brenner study](https://www.ncbi.nlm.nih.gov/pubmed/27721479), we learned…

- That an enormous amount of this NR is getting methylated as nicotinamide
- Not possible to extract the data to say exactly how much because they’re in concentrations, and we don’t know what the up and down flux is over time

Roughly speaking…

- But as a rough calculation to get a sense of how much impact you could have if the impact were maximal…
  - For every 1,000 milligrams of nicotinamide that you detoxify you are in theory **decreasing your synthesis of creatine by 500 milligrams**
  - You’re synthesizing two grams of creatine in a day
  - So if you’re taking 2,000 milligrams of NR and all of it were detoxified, you’d be cutting your creatine synthesis in half
  - And you don’t need your creatine to go to zero before you have problems

**Benefits of creatine**

*Why do bodybuilders take creatine?*

- Because they’re hoping to maybe increase their body stores by about 30%.
- Just leveraging a little bit marginal increased creatine makes big results in your strength

*Depression* ⇒ it’s also been shown that [five grams of creatine a day improves depression in women with major depressive disorder](https://www.ncbi.nlm.nih.gov/pubmed/22864465)

![](https://peterattiamd.com/wp-content/uploads/2019/03/creatine-improves-depression-1024x1000.png)

**Figure 13. Creatine supplementation improves depression.** Image credit: Chris Masterjohn

*Just looking at the physiology of creatine…*

- you use it to make your sperm swim
- And you’re using it to pump acid into your stomach

> “Creatine is important in all kinds of areas that you would not expect to think about it in.”

*Should someone take creatine daily even when not exercising?*

- On the whole, if you take 5 grams a day, and you just always do that, you’re eventually going to get to “hit that steady state”
- Although you could argue that it might be better if…
  - You take it after exercise with a carbohydrate bolus
  - And if you split it up into two doses in a day

**So are NR supplement dangerous?**

“My position is not that this stuff is really dangerous.”

*However…*

- Anecdotally, Chris sees people who are taking this stuff who experience
  - seesawing in their energy levels
  - seesawing in their mental and emotional states
- These are things that could be explained by 1,000 other things
- BUT…this is *“exactly what I would expect to happen in someone whose methyl group supply was being sapped.”*

**How to minimize the potential downside of taking NAD precursors**

- First step is to try taking a lower dose of NR
- Then match the NR it with a methyl donor
- “In theory, you could do creatine.” ⇒ But [Chris’s recommendation](https://www.youtube.com/watch?v=P5UMfCW_23w) is to match it mg to mg with [trimethylglycine (TMG)](https://www.amazon.com/Jarrow-Formulas-TMG-500-Tablets/dp/B00SJK52JC/ref=as_li_ss_tl?ie=UTF8&qid=1530627885&sr=8-1&keywords=jarrow+tmg+500&linkCode=sl1&tag=masterjohn-20&linkId=880d6cab452b270cf6954e4684b9eefa)

## A case study of a person with high homocysteine [2:28:00]

**Case study: A patient of Peter’s with high homocysteine (13-15 range)**

*Could NOT get his levels to go down, Peter tried…*

- Standard dose of methyl B12
- Double dose of B12
- Adding 50 milligrams of B6 three times a week
- Then tried 50 milligrams of B6 daily
- Finally tried [**TMG**](https://en.wikipedia.org/wiki/Trimethylglycine) **and his homocysteine falls by 50%**

*What was going on with this guy?*

- B6 doing nothing indicates one of two things
- 1 Either that guy’s enzyme for getting rid of the homocysteine didn’t work that well
- 2 This was not a fed-state homocysteine issue
- “My guess is that unlike the guy whose homocysteine went down with the B6, this guy had a recycling issue. He did not have a problem of disposing of the homocysteine in the fed state. He had a problem of recycling in the fasted state.”
- When you use choline for methylation, what you do is you convert it into trimethylglycine (TMG), and that becomes the methyl donor.

*Could Peter have just upped his choline intake?*

- Yes probably that would have worked
- The only possibility that would prevent that would be *if he had a problem with the enzyme that oxidizes choline to trimethylglycine*

**Does it really matter what your homocysteine levels are?**

- “I don’t think the argument is super strong that by fixing the homocysteine is reducing cardiovascular risk.”
- “I look at homocysteine, and I say, ‘Well, look. Young, healthy people have a homocysteine on average between seven and nine, that’s probably a sweet spot.’”
- “If I were looking at that from the perspective of what is *the least stuff I can do, unless I am very compelled by the data to do it,* then I would throw out at least everything that I just said, except the choline.”

## What is the level of evidence that you need to take an action? [2:32:15]

*The following is a transcript of their discussion…*

**Chris**: This comes down to a philosophic question of what is the level of evidence that you need to take an action?

**Peter**: Versus the level of evidence to not take an action, which people always forget that they have to ask that question just as well.

**Chris**:

Well, also versus the level of evidence to state that you have a certain degree of certainty or confidence in something.

We can be fairly rational and within a fairly narrow window on what do we believe are the principles that we need to secure to say we have a certain degree of confidence that something is true.

But we can never create that window for saying what is the level of evidence that I need in order to take an action, because that comes back to your subjective values.

A lot of this is assumption as well. Even if you’re coming to the question of what is the probability that we should assess that something is true? For me, I would take as a background assumption that things that have a proven track record in human history over a long period of time should be assumed as a default.

Someone else may take the assumption that nothing is the default or that the status quo is the default.

If you’re basically saying that we have to have meta-analyses of large, randomized, controlled trials on clinical endpoints in order to have something, you are assuming that in the absence of that evidence we will follow the status quo.

Even in the case of us debating how confident we are that something is true, we have reasons like that to have a spectrum of agreement or disagreement.

But when it comes down to should I take this supplement, that comes to subjective value over what kind of risks do you wanna take. Right?

There are some people that want to optimize their metabolism to make their body run like a well oiled machine, the best way that they know how, and they’re willing to spend some money or design their diet around doing so. And I think most of what I said mostly applies to those people.

I think for people who are looking for hard clinical endpoints, in fact, this is why there’s Twitter wars over MTHFR sometime.

**Peter**: Oh, thank God I missed those.

**Chris**:

I’ve gotten into some tussles on the internet with some people who looked at this from the perspective of, “look, there’s no hard clinical endpoints for which MTHFR is diagnostic. There’s no hard clinical endpoints for which people with MTHFR, for whom that population has some specific dietary or supplemental regimen that alters that clinical endpoint.”

And I think that’s true.

Where I come from if I were in that situation, I would wanna bring my homocysteine down to what by all probability appears to be the healthy level.

If I were that person, I would want a reason, well, I feel like my mind is too sticky, and I wanna loosen it up a little bit. If I were that person, I would wanna have good energy, and I would wanna use a rational assessment of why my energy might be low and what I can do to bring it up to normal.

And I’m probably never gonna convince anyone that if I feel better, that there’s a hard, testable clinical end point to that.

## Does Chris supplement with NAD precursors? And can it improve symptoms of rosacea? [2:35:45]

He takes [Tru Niagen](https://www.truniagen.com/product_page.html)

- He takes 75 milligrams with breakfast and 75 micrograms with lunch
- Breaks the 150 mg pill in half
- “I might go up. I’m just playing around with it. It’s just a tinkering thing.”

Do NR supplements help with rosacea?

- In Peter’s patients who take NR, the one thing that seems to across the board improve is [rosacea](https://www.mayoclinic.org/diseases-conditions/rosacea/symptoms-causes/syc-20353815)
- Perhaps, rosacea as an endpoint in a clinical study would have good results to it, suggests Chris

Summarizing Chris’s thoughts

- IV NAD is not a great idea
- It’s much better to build up a hepatic reservoir of nicotinamide that’s converted through the NR that you can then slow trickle into circulation as needed

## Decision making in the face of inconclusive data, and trying to disentangle the placebo effect [2:39:00]

Chris references a [video he made about NR](https://www.youtube.com/watch?v=P5UMfCW_23w)

- Lady was taking Tru Niagen
- She felt great for a couple weeks, but then she started feeling the energy sapping off and then dropping.
- Then she felt like going through a mental rollercoaster
- Chris used this anecdote that obviously could have other explanations and clearly has no clinical measurable endpoint, and I got people just came out of the woodwork trolling and screaming that Tru Niagen is wonderful
- “So here there are people often pointing out that there’s no hard data in that story who are saying all kinds of great things about the way they feel when they take a lot of this stuff (despite lack of evidence).”

> “People are gonna make a decision to take this or not, and there is no clear data on what it does. So, you either take the position that you’re gonna wait 10 or 20 years until we know something better, or you take the position that you’re gonna tinker. And if you’re gonna tinker, you’re gonna tinker a lot more successfully if you have a working model of what’s going on than if you don’t.”

Peter agrees

- He uses the example of how he decided to start taking rapamycin
- Peter made this public on his [appearance on Kevin Rose’s podcast](https://www.kevinrose.com/single-post/Peter-Attia)
- “Rapa would probably be the single most ‘out there’ thing that I do, but my model’s robust. Now, I also think I have much more data to point to. So, even though people can say, “Oh my god, rapamycin is so scary,” I get to point to what happens in the yeast, the flies, the worms, the mice, the rats, the dogs, the kangaroos, so I feel like I’m standing on the shoulder of much more evidence, even though I’m interfering with a much more important sensor.”

Trying to disentangle the placebo effect

- “If you’re taking nicotinamide riboside for a way you feel, it’s very confusing, because I don’t see how one can disentangle the placebo effect.”
- The New York Times [wrote a piece about the power of the placebo effect](https://www.nytimes.com/2018/11/07/magazine/placebo-effect-medicine.html)
- “I’ve even spoken with PIs who have run studies using psychoactive agents, and you’d think, how could you placebo your way out of that? Yet they’ve told me that the placebo effect, in terms of the post depression you would get with certain psychoactives, is actually **greater in the placebo group than the treatment group**. So, I just don’t know that that I trust myself to discriminate between something that works or doesn’t work based on how I feel.” says Peter

For more on placebo effects see Peter’s [non-lame weekly email on the topic](https://us15.campaign-archive.com/?u=21bc5f75235505c27ce465f90&id=1ce39b914d)

## What does Chris believe to be true that very few people would agree with him about? [2:43:15]

**Political views**: Very libertarian ⇒ *“I’m twice the libertarian of your libertarian uncle.”*

**In the medical and nutritional world**:

⇒ The usefulness of RDAs

- Many people believe [RDAs](https://en.wikipedia.org/wiki/Dietary_Reference_Intake) are “trash science”
- “I think that RDAs are actually super good science”

> “I think that wherever you are in controversy that you have to know the core of what constitutes the conventional belief.”

⇒ The carbohydrate hypothesis of obesity

- Used to believe the chain of causality was from metabolic problems to obesity
- “I’ve come to really believe that the conventional view of obesity being a cause of metabolic dysfunction is true.”
- Peter’s response: *“My view is that obesity is actually largely a compensatory response for something metabolic, so that’s the opposite view of you, I think, if I’m understanding you correctly. But it’s also hard to neatly fit these views into a box, because you’re always gonna fond patient that’s an exception to your rule.”*

## How to follow Chris’s work [2:48:45]

- Website: [chrismasterjohnphd.com](https://chrismasterjohnphd.com/)
- Twitter: [@chrismasterjohn](https://twitter.com/chrismasterjohn?lang=en)
- YouTube: [Chris Masterjohn, PhD](https://www.youtube.com/channel/UCSJJM-c27d_DiuaqcZAOMUg)
- Instagram: [@chrismasterjohn](https://www.instagram.com/chrismasterjohn/?hl=en)
- Facebook: [Chris Masterjohn, PhD](https://www.facebook.com/chrismasterjohn/)

§

## Selected Links / Related Material

## Great resources from Chris:

**Chris’s article criticizing the TMAO studies**: [Does Carnitine From Red Meat Contribute to Heart Disease Through Intestinal Bacterial Metabolism to TMAO?](https://www.westonaprice.org/carnitine-and-heart-disease/) | Chris Masterjohn (westonaprice.org) [42:30]

**Video where Chris talks about matching your NR dose mg for mg with a methyl donor**: [Why You Should Be Careful With Niacin and Nicotinamide Riboside | Chris Masterjohn Lite #54](https://www.youtube.com/watch?v=P5UMfCW_23w) | Chris Masterjohn PhD (youtube.com)

**What you need to know about your methylation system**: [Start Here for MTHFR and Methylation](https://chrismasterjohnphd.com/2019/03/01/start-here-for-mthfr-and-methylation/)

**MTHFR videos**:

- [How to Know If You Need to Care About Your MTHFR | Chris Masterjohn Lite #32](https://www.youtube.com/watch?v=290QXvTVp_c&t=86s)
- [What to Do About MTHFR | Chris Masterjohn Lite #33](https://www.youtube.com/watch?v=290QXvTVp_c&t=86s)

**COMT**: [What to Do ABout Your COMT Genes](https://www.youtube.com/watch?v=ZgrqePFMKEU&list=WL&index=48&t=0s)

**Nutrition in Neuroscience** ([Part 1](https://chrismasterjohnphd.com/2019/01/11/nutrition-neuroscience-part-1/) | [Part 2](https://chrismasterjohnphd.com/2019/01/18/nutrition-neuroscience-part-2/) | [Part 3](https://chrismasterjohnphd.com/2019/01/25/nutrition-in-neuroscience-part-3/) | [Part 4](https://chrismasterjohnphd.com/2019/02/01/nutrition-in-neuroscience-part-4/))

**Niacin series** ([Part 1](https://chrismasterjohnphd.com/2019/03/01/niacin-part-1-need/) | [Part 2](https://chrismasterjohnphd.com/2019/03/16/niacin-part-2-blood-tests-foods-supplements/))

## Other Related Links:

**Episode of The Drive discussion NAD and sirtuins**: [#27 – David Sinclair, Ph.D.: Slowing aging – sirtuins, NAD, and the epigenetics of aging](https://peterattiamd.com/davidsinclair/) | Peter Attia (peterattiamd.com) [6:15, 1:10:00]

**The two most commercially known NAD precursor supplements**: [6:30, 1:10:30]

- [Basis by Elysium](https://www.elysiumhealth.com/en-us/basis?gclid=Cj0KCQjwpsLkBRDpARIsAKoYI8yW0EH5_LB84j4Q2yQxWVXPWXNlDnF8U3oDnCR_XyQShopjSZon9bQaAjUPEALw_wcB) (elysiumhealth.com)
- [Tru Niagen by Chromadex](https://www.truniagen.com/product_page.html) (turniagen.com)

**Paper that said TMAO would lead to atherosclerosis**: [Gut Microbe-Generated Trimethylamine N-Oxide From Dietary Choline Is Prothrombotic in Subjects](https://www.ahajournals.org/doi/10.1161/CIRCULATIONAHA.116.025338) (Zhu et al., 2017) [12:30]

**First case of NAFLD**: [Non-alcoholic fatty liver disease: History](https://en.wikipedia.org/wiki/Non-alcoholic_fatty_liver_disease#History) | (wikipedia.org) [18:45]

**Humans on TPN developed fatty liver**:

- [Choline deficiency causes reversible hepatic abnormalities in patients receiving parenteral nutrition: proof of a human choline requirement: a placebo-controlled trial.](https://www.ncbi.nlm.nih.gov/pubmed/11531217/) (Buchman et al., 2001) [19:45]
- [Complications of long-term home total parenteral nutrition: their identification, prevention and treatment.](https://www.ncbi.nlm.nih.gov/pubmed/11270772/) (Buchman AL, 2001) [19:45]
- [Choline, an essential nutrient for humans.](https://www.ncbi.nlm.nih.gov/pubmed/2010061) (Zeisel et al., 1991) [21:45]

**Different dietary requirements for choline**: [Sex and menopausal status influence human dietary requirements for the nutrient choline](https://www.ncbi.nlm.nih.gov/pubmed/17490963) (Fischer et al., 2007) [24:00]

**Studies of seven patients with biopsy proven NASH showed decreased apoB production rate (by 50%) as compared with obese or lean controls without NAFLD**: [Apolipoprotein synthesis in nonalcoholic steatohepatitis](https://www.ncbi.nlm.nih.gov/pubmed/11915037/) (Charlton et al., 2002) [24:15]

**In 1980, the Mayo Clinic published a paper in which they coined the term NASH**: [Nonalcoholic steatohepatitis: Mayo Clinic experiences with a hitherto unnamed disease.](https://www.ncbi.nlm.nih.gov/pubmed/7382552) (Ludwig et al., 1980) [26:00]

**JAMA paper by Miriam Vos, low sugar dietary intervention in young boys with NAFLD:** [Effect of a Low Free Sugar Diet vs Usual Diet on Nonalcoholic Fatty Liver Disease in Adolescent Boys: A Randomized Clinical Trial.](https://www.ncbi.nlm.nih.gov/pubmed/30667502) (Schwimmer et al., 2019) [37:00]

**2011 Cleveland Clinic mouse study showed that TMAO was directly atherogenic**: [Gut flora metabolism of phosphatidylcholine promotes cardiovascular disease](https://www.nature.com/articles/nature09922) (Wang et al., 2011) [39:45]

**Human studies suggesting TMAO was contributing to heart disease**:

- **Looking at choline**: [Intestinal microbial metabolism of phosphatidylcholine and cardiovascular risk.](https://www.ncbi.nlm.nih.gov/pubmed/23614584) (Weifei et al., 2017) [39:45]
- **Looking at meat consumption**: [Intestinal microbiota metabolism of L-carnitine, a nutrient in red meat, promotes atherosclerosis.](https://www.ncbi.nlm.nih.gov/pubmed/23563705) (Koeth et al., 2013) [39:45]

**Chris’s article criticizing the TMAO studies**: [Does Carnitine From Red Meat Contribute to Heart Disease Through Intestinal Bacterial Metabolism to TMAO?](https://www.westonaprice.org/carnitine-and-heart-disease/) | Chris Masterjohn (westonaprice.org) [42:30]

**Observational data showing that people who eat more fish have more TMAO in their blood**: [Trimethylamine N-Oxide: The Good, the Bad and the Unknown](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5127123/) (Velasquez et al., 2016) [43:15]

**Study that fed people 500 mg of choline bitartrate and showed blood clotting**: [Gut Microbe-Generated Trimethylamine N-Oxide From Dietary Choline Is Prothrombotic in Subjects](https://www.ahajournals.org/doi/full/10.1161/CIRCULATIONAHA.116.025338) (Weifei et al, 2017) [46:30]

**Steven Zeisel’s group did a study looking at plasma TMAO response to eggs**: [Effect of egg ingestion on trimethylamine-N-oxide production in humans: a randomized, controlled, dose-response study](https://academic.oup.com/ajcn/article/100/3/778/4576437) (Miller et al., 2014) [46:45]

**Compared with SFA intake, n-6 PUFAs reduce liver fat and modestly improve metabolic status, without weight loss**: [Effects of n-6 PUFAs compared with SFAs on liver fat, lipoproteins, and inflammation in abdominal obesity: a randomized controlled trial](https://www.ncbi.nlm.nih.gov/pubmed/22492369/) (Bjermo et al., 2012) [56:00]

**In the alcoholic model there are studies showing that you get less steatosis with saturated fats than with polyunsaturated fats**: [Alcoholic Liver Disease: Update on the Role of Dietary Fat](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4808795/) (Kirpich et al., 2016) [57:30]

**Peter’s quarterly fasts**: [#11 – AMA #2: the Nothingburger — results from Peter’s week-long fast between two weeks of nutritional ketosis — and answering questions on all things fasting](https://peterattiamd.com/ama02/) | Peter Attia (peterattiamd.org) [1:04:30]

**Studies of seven patients with biopsy proven NASH showed decreased apoB production rate (by 50%) as compared with obese or lean controls without NAFLD**: [Apolipoprotein synthesis in nonalcoholic steatohepatitis](https://www.ncbi.nlm.nih.gov/pubmed/11915037/) (Charlton et al., 2002) [24:15]

**Josh Rabinowitz 2018 papers**: [1:22:15]

- [Nicotinamide adenine dinucleotide is transported into mammalian mitochondria.](https://www.ncbi.nlm.nih.gov/pubmed/29893687) (Davila et al., 2018)
- [Quantitative Analysis of NAD Synthesis-Breakdown Fluxes](https://www.cell.com/cell-metabolism/pdfExtended/S1550-4131(18)30196-7) (Liu et al., 2018)

**Rabinowitz 2016 paper**: [Loss of NAD Homeostasis Leads to Progressive and Reversible Degeneration of Skeletal Muscle](https://www.sciencedirect.com/science/article/pii/S1550413116303503) (Frederick et al., 2016) [1:23:45]

**Chris’s podcast where he discusses the 2018 Rabinowitz paper**: [Niacin Part 1: What It Is and Why You Need It](https://chrismasterjohnphd.com/2019/03/01/niacin-part-1-need/) | Chris Masterjohn (chrismasterjohnphd.com) [1:27:45]

**Paper showing some mammalian cell types have the ability to take that NAD into the cells**: [Nicotinamide adenine dinucleotide is transported into mammalian mitochondria.](https://www.ncbi.nlm.nih.gov/pubmed/29893687) (Davila et al., 2018) [1:35:15]

**ChromaDex/Brenner studies**: [1:41:00]

- **Human study measuring metabolites that are produced when you take oral NR**: [Nicotinamide riboside is uniquely and orally bioavailable in mice and humans.](https://www.ncbi.nlm.nih.gov/pubmed/27721479) (Trammell et al., 2016)
- **Human studies showing no benefits on glucose metabolism or lipid metabolism**: [A randomized placebo-controlled clinical trial of nicotinamide riboside in obese men: safety, insulin-sensitivity, and lipid-mobilizing effects.](https://www.ncbi.nlm.nih.gov/pubmed/29992272) (Dollerup et al., 2018) [1:41:00]

**Nicotinamide riboside studies showing massive urinary methylated metabolites on 2000 mg/d NR**: [A randomized placebo-controlled clinical trial of nicotinamide riboside in obese men: safety, insulin-sensitivity, and lipid-mobilizing effects](https://academic.oup.com/ajcn/article-abstract/108/2/343/5051210?redirectedFrom=fulltext) (Dollerup et al., 2018) [1:48:00]

**Nicotinamide riboside study showing in a single subject massive increases in methylated metabolites on 1000 mg/d NR in plasma, PBMCs, and urine**: [Nicotinamide riboside is uniquely and orally bioavailable in mice and humans](https://www.ncbi.nlm.nih.gov/pubmed/27721479) (Trammell et al., 2016) [1:48:00]

**The warrior/worrier phenotype**: [Warriors versus worriers: the role of COMT gene variants.](https://www.ncbi.nlm.nih.gov/pubmed/17008817) (Stein et al., 2006) [2:05:45]

**Study suggesting competitive swimmers who are the low methylation phenotype get better results**: [Association between COMT Val158Met polymorphism and competition results of competitive swimmers](https://www.tandfonline.com/doi/abs/10.1080/02640414.2017.1309058?scroll=top&needAccess=true&journalCode=rjsp20) (Abe et al., 2018) [2:06:45]

**People with the low COMT phenotype are more likely to do more exercise because you told them to**: [Dopamine-Related Genotypes and Physical Activity Change During an Intervention: The Lifestyle Interventions and Independence for Elders Study](https://www.ncbi.nlm.nih.gov/pubmed/29637543) (Rosso et al., 2018) [2:06:45]

**The associations of the COMT genotypes with different psychiatric diseases**: [Association between COMT Val158Met and psychiatric disorders: A comprehensive meta-analysis.](https://www.ncbi.nlm.nih.gov/pubmed/28608575) (Taylor S., 2017) [2:07:45]

**Report suggesting 5 grams per day of creatine is plenty**: [International Society of Sports Nutrition position stand: safety and efficacy of creatine supplementation in exercise, sport, and medicine](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5469049/) (Keider et al., 2017) [2:11:30]

**Studies showing that people get better sleep if they take 3-6 grams of glycine before bed**: [2:19:30]

- [The sleep-promoting and hypothermic effects of glycine are mediated by NMDA receptors in the suprachiasmatic nucleus.](https://www.ncbi.nlm.nih.gov/pubmed/25533534) (Kawai et al., 2015)
- [Glycine ingestion improves subjective sleep quality in human volunteers, correlating with polysomnographic changes](https://onlinelibrary.wiley.com/doi/full/10.1111/j.1479-8425.2007.00262.x) (Wataru et al., 2007)

**Study showing better blood sugar if they take 3 to 5 grams glycine with a meal**: [The metabolic response to ingested glycine.](https://www.ncbi.nlm.nih.gov/pubmed/12450897) (Gannon et al., 2002)

**Study showing 15 grams of glycine gelatin with vitamin C will increase collagen synthesis in the tendons**: [Vitamin C-enriched gelatin supplementation before intermittent activity augments collagen synthesis.](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5183725/) (Shaw et al., 2017) [2:21:15]

**Five grams of creatine a day improves depression in women with major depressive disorder**: [A randomized, double-blind placebo-controlled trial of oral creatine monohydrate augmentation for enhanced response to a selective serotonin reuptake inhibitor in women with major depressive disorder.](https://www.ncbi.nlm.nih.gov/pubmed/22864465) (Lyoo et al., 2012) [2:25:15]

**Chris’s video about NR and the lady who was feeling bad when taking Tru Niagen**: [Why You Should Be Careful With Niacin and Nicotinamide Riboside | Chris Masterjohn Lite #54](https://www.youtube.com/watch?v=P5UMfCW_23w) | Chris Masterjohn, PhD (youtube.com) [2:27:45, 2:39:00]

**The supplement that Chris recommends to match mg to mg with your NR supplement to minimize the potential downside**: [Jarrow Formulas TMG 500, 120 Tablets](https://www.amazon.com/Jarrow-Formulas-TMG-500-Tablets/dp/B00SJK52JC/ref=as_li_ss_tl?ie=UTF8&qid=1530627885&sr=8-1&keywords=jarrow+tmg+500&linkCode=sl1&tag=masterjohn-20&linkId=880d6cab452b270cf6954e4684b9eefa) | (amazon.com) [2:27:45, 2:39:00]

1. **pylori, an example of self-experimentation**: [Helicobacter pylori: History](https://en.wikipedia.org/wiki/Helicobacter_pylori#History) | (wikipedia.org) [2:36:45]

**Peter announces he’s taking rapamycin on the Kevin Rose podcast**: [#31 – Peter Attia](https://www.kevinrose.com/single-post/Peter-Attia) | The Kevin Rose Show (kevinrose.com) [2:40:45]

**NY Times piece on the placebo effect**: [What if the Placebo Effect Isn’t A Trick?](https://www.nytimes.com/2018/11/07/magazine/placebo-effect-medicine.html) | Gary Greenberg (nytimes.com) [2:41:45]

**Book by Peter Thiel**: [Zero to One: Notes on Startups, or How to Build the Future](https://www.amazon.com/Zero-One-Notes-Startups-Future/dp/0804139296) by Peter Thiel | (amazon.com) [2:43:15]

**Dietary Reference report for niacin**: [Dietary Reference Intakes for Thiamin, Riboflavin, Niacin, Vitamin B6, Folate, Vitamin B12, Pantothenic Acid, Biotin, and Choline](https://www.ncbi.nlm.nih.gov/books/NBK114310/) (Institute of Medicine (US) Standing Committee on the Scientific Evaluation of Dietary Reference Intakes and its Panel on Folate, Other B Vitamins, and Choline., 1998) [2:46:15]

**Chris’s website**: [chrismasterjohnphd.com](https://chrismasterjohnphd.com/) | [2:49:00]

**Chris enjoyed Peter’s favorite beverage**: [Topo Chico](https://www.topochicousa.net/) | (topochicousa.net) [2:50:00]

§

## People Mentioned

- [David Sinclair](https://en.wikipedia.org/wiki/David_Andrew_Sinclair) (previous guest on The Drive, NAD and sirtuins) [6:15, 1:10:00]
- [Stephan Guyenet](https://twitter.com/whsource) (TMAO email discussion with Peter and Chris) [12:45]
- [Chris Kresser](https://twitter.com/chriskresser/) (TMAO email discussion with Peter and Chris) [12:45, 43:45]
- [Steven Zeisel](https://en.wikipedia.org/wiki/Steven_Zeisel) (choline studies) [21:45, 46:45, 51:45]
- [Ron Busuttil](https://www.uclahealth.org/ronald-busuttil) (liver transplant expert) [26:45]
- [Miriam Vos](https://news.emory.edu/tags/expert/miriam_vos/index.html) (lead JAMA study on NAFLD in young boys) [37:00]
- [Bob Kaplan](https://twitter.com/bobkaplan?lang=en) (lead analyst for Attia Medical) [46:30, 1:58:15]
- [Sam Tsimikas](https://twitter.com/Lpa_Doc) (developing an APOC3 assay) [1:02:30]
- [Josh Rabinowitz](https://lsi.princeton.edu/faculty/joshua-d.-rabinowitz) (NAD experiments) [1:22:15, 1:27:45]
- [Charles Brenner](https://en.wikipedia.org/wiki/Charles_Brenner) (ChromaDEX studies) [1:41:00, 1:48:45, 2:23:45]
- [Keith Baar](https://health.ucdavis.edu/physiology/faculty/baar.html) (glycine) [2:21:15]
- [Peter Thiel](https://en.wikipedia.org/wiki/Peter_Thiel) (wrote book [Zero to One](https://www.amazon.com/Zero-One-Notes-Startups-Future/dp/0804139296)) [2:43:15]

§

![](https://peterattiamd.com/wp-content/uploads/2019/03/chris-masterjohn-fb-image-500x500.jpg)

##### Chris Masterjohn, Ph.D.

[From [chrismasterjohnphd.com](https://chrismasterjohnphd.com/2016/06/21/who-i-am/)]

Here’s my academic background:

- I earned my PhD in Nutritional Sciences from the University of Connecticut in the summer of 2012.
- From September 2012 to August 2014, I served as a postdoctoral research associate in the Comparative Biosciences department of the College of Veterinary Medicine at the University of Illinois at Urbana-Champaign.
- From August 2014 to December 2016, I served as Assistant Professor of Health and Nutrition Sciences at Brooklyn College, part of the City University of New York.

In the fall of 2016, I made the decision to leave academia and pursue entrepreneurship a transition I completed on January 1, 2017. If you would like the full story of how I came to this decision, you can join my email newsletter, and the first welcome email tells the story and provides you with my vision going forward.

As of January 2017, I’m on my own. I am currently conducting independent research, consulting, working on information products, collaborating on information and technology products, and producing tons of free content to help people gain better health.

I have deep and personal experiences with the power of food, movement, and mindfulness to support health and well being. I want to take what I’ve learned and pay it forward.

But I’m not done learning. I’m constantly learning from my own challenges, failures, and successes, and I’m constantly learning by scouring the scientific literature, whether I’m uncovering long-forgotten and neglected evidence from yesteryear or following and deciphering the latest findings.

What I try to do here is grapple with complex science and translate it into practical principles that each of us can use to better support our health.

- Website: [chrismasterjohnphd.com](https://chrismasterjohnphd.com/)
- Twitter: [@chrismasterjohn](https://twitter.com/chrismasterjohn?lang=en)
- YouTube: [Chris Masterjohn, PhD](https://www.youtube.com/channel/UCSJJM-c27d_DiuaqcZAOMUg)
- Instagram: [@chrismasterjohn](https://www.instagram.com/chrismasterjohn/?hl=en)
- Facebook: [Chris Masterjohn, PhD](https://www.facebook.com/chrismasterjohn/)