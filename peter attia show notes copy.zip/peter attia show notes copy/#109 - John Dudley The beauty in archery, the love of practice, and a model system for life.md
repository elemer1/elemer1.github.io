# #109 – John Dudley: The beauty in archery, the love of practice, and a model system for life

**Source:** [https://peterattiamd.com/johndudley/](https://peterattiamd.com/johndudley/)

---

In this episode, professional archer, John Dudley, shares the many insights he’s gleaned through the process of not only becoming an elite competitor of archery but also an exceptional teacher. John describes how his desire for improvement has cultivated a sheer love of practice, and how pursuing mastery helped put into context how archery is an amazing model system for life. Additionally, John discusses the often misunderstood nature of hunting, but also makes the case as to why one should consider trying archery even if there is no desire to hunt.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/johndudley/the_Drive_public.png)

Play

#109 - John Dudley: The beauty in archery, the love of practice, and a model system for life

#109 - John Dudley: The beauty in archery, the love of practice, and a model system for life

1x15s30s

0:002:16:34

## We discuss:

- Why John loves archery, and what it means to be a professional archer [4:50];
- How John’s love of practice and training led to archery [10:45];
- How an intense desire to improve drove John to quit football and pursue archery [22:00];
- A traumatic childhood event that changed John’s course from troublemaker to committed athlete [34:15];
- The nuts and bolts of archery—competitive events, types of bows, hunting, etc. [45:30];
- The blissful nature of archery, and the uselessness of anger [57:15];
- Hyper-focus and flow states—Did John’s ADD and task-driven personality give him an advantage? [1:07:15];
- The common traits found in the most successful people [1:12:45];
- The keys to maintaining credibility as a salesman—integrity, honesty, and straightforwardness [1:18:45];
- The coaching technique that makes John a great teacher [1:28:30];
- Why you should consider trying archery (even if you never want to hunt) [1:36:15];
- Hunting discussion—the morality argument, hunting vs. commercial farming, managing overpopulation, and the unique emotional connection [1:45:00];
- Resources for those interested in taking up archery [2:12:00]; and
- More.

§

## Show Notes

## Why John loves archery, and what it means to be a professional archer [4:50]

- John grew up in Mississippi and then the Illinois near the [Fox River](https://en.wikipedia.org/wiki/Fox_River_(Illinois_River_tributary)) and learned archery as a child
- First bow hunt was at 10 years old

**Why does John like archery so much?**

“*Because it’s hard*”

- That insight came from [Andy Stumpf](https://www.andystumpf.com/about-1),  he goes, “That is why you do it. Because there’s days where you’re good at and there’s days when you’re not.”
- There’s always been a new challenge in archery where John can start from a place of being bad and work his way up to being good
- Every time he would get bored, he would jump to a new aspect of archery and start the learning/growing process over again
- With archery, there are days where everything is clicking but then the very next day you can’t replicate it (kind of like how golfers feel)
- In other words, you can’t just be perfect all the time

> “I just have made a career out of being poor at a certain aspect of it and making it a mission to become good at that. And then over the course of 33 years, I’ve got to the point where now I feel like I have a very good understanding of the game and I’ve learned a lot from a lot of mistakes.”

## How John’s love of practice and training led to archery [10:45]

- John was an All-American athlete growing up
- In fact, John earned a division 1 scholarship to play quarterback at [Western Carolina](https://www.wcu.edu/)

**A great story…**

- John was attending a football camp at U of Illinois being led by [Greg Landry](https://en.wikipedia.org/wiki/Greg_Landry)
- Landry was giving a speech to the kids at the camp explaining to them how they have to be ready for their moment to shine at this camp
- Just like a big game, there will come a moment where you have a shot to stand out and you need to be ready
- At that moment, Landry tossed a football to John and said, “What are you going to do with your moment?”
- John stood up and just chunked the football the full length of the field and John said, “I throw footballs.”
- The coach said, “*That was perfect. Sit down*.”
- Later, that coach came up to him and asked, “how do you throw like that?”
- John explained to him that he just **loves training**

**The love of training**

- John loved the **process** and **practice** of training
- Growing up he played all sports … in fact, the sport didn’t really mattered, because he just love to play and to practice

*-What about archery?*

- John said archery would eventually “blindside” him
- Growing up he was pretty good at it
- He would actually make gas money by betting people at parties in high school about things he could shoot with a bow and arrow
- But he was all about the sports he was playing, especially football
- Archery was not much more than a hobby
- But eventually the ability to endlessly practice and improve at archery hooked him in for good

## How an intense desire to improve drove John to quit football and pursue archery [22:00]

**Change of plans with football**

- In the summer after his senior year of high school, he injured his knee
- Since he wouldn’t be playing during his Freshman year now at Western Carolina, the decision was made for John to redshirt at a junior college that ran the same playbook
- John would rehab his knee and learn the offense during his redshirt year

**Falling in love with archery**

- However, before he even reported to football, he happened to drive by an archery store in where they were holding a tournament where competitors shot at 3D targets with scoring rings (something John had never seen before)
- John entered himself into the tournament and did absolutely terrible and lost all his arrows
- But at the end, he saw that the winners of the tournament were wearing shirts that said “GAT GUN, Dundee, Illinois”
- The next day, John drove to [GAT GUNS](https://www.gatguns.com/) and hung out there all day and watched people shoot arrows and just asked them every question he could think of
- He did this for several days in a row until one day the manager, Mike Donovan, grabbed John and said “I need your help”
- Mike pulled John into the back room and said, “*Hey, I forgot to do these guy’s arrows. Do you know how to fletch arrows?” And I said, “No, I don’t know how to do any of this stuff.” And he said, “Okay, I’m going to show you how.*“
- He ended up doing this for several hours that day
- For the next few weeks, John continued helping at GAT GUNS for free
- Eventually… John was able to get a job earning $4.10 per hour
- He worked there every day from 12pm-8pm
- Meanwhile, John is getting to learn everything he wants from these talented people
- Everything the different bows, bow strings, arrows, shooting techniques, etc.
- Finally, one day John tells his father that he has decided to pursue this instead of playing football
- His father said, “*I think that’s a terrible decision.*”

***How much of this desire to commit to archery was because John was so bad at it in the beginning that it seemed like something that he could really improve at?***

- John says he’s not sure how much of that played a role, however, he admits that he rarely just accepts that he sucks at something
- There’s a competitive drive in him that always propels him to try to get better at whatever that thing is
- Archery just seemed like a perfect opportunity to continually get better and better
- He admits he had a natural talent for it, and combined that with how much he loves doing it… it become a passion for him

> “I’m not exceptional. I’ve just made it a lifetime passion to give everything I have to master it. . . I feel like this is what I’m meant to do.”

## A traumatic childhood event that changed John’s course from troublemaker to committed athlete [34:15]

- Something happened to John when he was 9 years old that still haunts him to this day
- But it’s one of things where he’s “happy it happened” because it shaped who he is to this day
- John says he was “Beavis and Butthead” growing up
- He was a skate-boarder, BMX biker, he loved playing with fire, and would steal money from his mom’s wallet to go buy fireworks, etc.
- One day he pretended to be sick from school when his parents were out of town on work
- He was playing with matches at home
- He ended up starting a fire in the bedroom
- He called his father to tell him what was happening and he told John to try to get the smoke out of the house
- John ran around frantically crying trying to open the doors and windows
- But the fire got worse and worse and eventually the whole place burned down
- The family lost every possession they owned

> “The only thing that we had was what was in my mom’s car at O’Hare Airport and what was in my dad’s car that was at work. That was it.”

- John was having a really hard time with the aftermath of this
- He said his parents never really “rubbed it in” to him… in other words, they never guilted him about what happened
- In fact, they could tell that it was taking a toll on him
- After John got into a fight at school about it, his parents made the decision to move to another town to sort of get away from it all

**Moving and taking up sports**

- Once in the new town, John told himself, “*I’ve got to make my dad proud.*”
- His dad was an athlete so John decided he needed to take up basketball, football, or golf
- “*That was totally my passion, I was jumping in there and becoming as good as I can.*”
- So this passion started as a way to pay back his parents
- But then it morphed into a **love of practice** and being fully committed to something and getting better
- In football especially, John dove deep into the details…

> “[I was] fully committed to training because I never had raw talent; I just had size to start with. So then I realized like if I knew every person’s positions, every single person, if I knew what they needed to do every play, I would be a leader.”

**Peter commends the wisdom of John’s parents in how they handled the situation**

- John said he’s never really spoken to his father about his approach to how he reacted to the situation when John burned down the house
- Peter is blown away by John’s father’s wisdom to see that John was taking it hard and how he knew that there was no need to make John feel any worse about what had happened
- Peter says 99 out of 100 parents would not have handled that situation as well
- Even though his parents lost every single possession, John’s parents never said “*Oh man, all my XYZ is gone.*”
- **In summary**, John’s parents had the understanding that he was going to beat himself up in eternity over that, and that they never needed to vent their frustration to John

> “And it’s another one of those perfect examples of when negative things happen, it’s an opportunity to really change full direction or make something out of it. If something blows up, there’s new pieces there. You can build it in a new way. Because the pieces wouldn’t be there if that wouldn’t have happened. It would still be kind of a solid object that wouldn’t have anything.”

**How does all this translate to archery?**

- John says this committed to bettering himself to make his parent proud lead him to realizing the joy in taking something he wasn’t good at and committing himself to getting better
- Archery was the perfect framework for applying his love of training, dedication, and competition
- The difference was that **he was doing archery for himself,** not for his parents or anyone else

## The nuts and bolts of archery—competitive events, types of bows, hunting, etc. [45:30]

**How does the competition work? What does an actual event look like?**

- Every pro tour has a different set of rules (This is very different to football where every field and game is the exact same)
- Each event has a certain number of arrows that you shoot
- Some events shoot a big round and then the top 3 to 5 people shoot down to a winner
- Other events are more like an Olympic-style round where you shoot a ranking round
  - They rank 1 to 64.
  - And then number 1 will shoot against number 64, number 2 shoots against 63, and so on.
  - And you’ll have brackets and you shoot all the way down into a gold medal match.
- Some events are fixed distances ⇒ The maximum is up to 90 meters
- Up until a recent change, a full FITA (now called World Archery) round was 30 meters, 50 meters, 70 meters, 90 meters (they’ve since gotten rid of the 90 meter shoot)
  - Then once the qualifying round was done, the head-to-heads would all be shot at 70 meters, which is 77 yards.

**John’s favorite event**: Field archery formats

- This is multiple size bull’s-eyes (proportion depending on the distance that you’re shooting
- Distance is anywhere from 20 meters out to about 80.
- you would shoot one round that had **marked** distance and one round that was **unmarked** distance
- And then you’d go into qualifications that were half and half (marked and unmarked)

*It’s amazing how accurate the pros really are…*

- For perspective, a football field is ~90 meters long
- From that distance, most pro archers are going to hit inside a 4 inch ring 8 out of 10 times.

**Different types of bows: Recurve vs. compound bow**

-In the Olympics, they shoot a recurve bow

- It’s very long, a handle with wooden limbs, which are the parts that bend, and there’s a string.

-John and Peter shoot a compound bow

- This type of bow has round wheels (cam) on it that essentially store energy
- As you pull back, the “cam” rolls over into a different position to where it gets easier as you get closer to your fully extended position
- So  it’s a little bit easier to hold it at full draw (compared to the recurve bow) … and because of that you’re also able to shoot much more poundage at the beginning of that pull cycle

![](https://peterattiamd.com/wp-content/uploads/2020/04/Recurve-Bow-vs-Compound-Bow-johndudley.jpg)

**Figure 1. Example of a recurve bow compared to a compound bow.** Image credit: [goodgamehunting.com](https://www.goodgamehunting.com/recurve-vs-compound-bow/)

**Summary of differences in those 2 bows**:

- Recurve bow getting harder and harder to pull back the further you go
- Compound bow is tougher to pull back at the start but gets easier as you get to full draw
- Compound bow is more accurate
- Compound bow can shoot longer distances because it has more stored energy
- T*ypical speed of the arrow*:
  - Peter’s bow is 292 feet per second (the muzzle velocity)
    - This is roughly 100 miles per hour
  - The recurve bow in the Olympics is way less in terms of arrow speed

⇒ [**Brady Ellison sets new world record set with the recurve bow**](https://worldarchery.org/news/173159/brady-ellison-breaks-world-record-702-point-qualification-pan-american-games)

- John has known Brady since Brady was a young kid… John actually gave Brady his first recurve bow
- He shot a 701 out of 720 possible points
- 72 shots at a small target 70 meters away

![](https://peterattiamd.com/wp-content/uploads/2020/04/brady_ellison-score-card-dudley-1024x768.jpg)

**Figure 2. Brady Ellison’s world record score card.** Image credit: [worldarchery.org](https://worldarchery.org/news/173159/brady-ellison-breaks-world-record-702-point-qualification-pan-american-games)

**Why didn’t John ever pursue the Olympics?**

- “That was never a pursuit of mine because these guys train for four years for one event.”
- Also, the money in compound bow shooting is much higher than recurve shooting
- Winning a weekend pro event with the compound bow could payout anywhere from $10,000 to $50,000
- Winnings for the recurve bow is just a fraction of that amount

**The hunting component of archery:** *Know your limitations*

- Peter once told John the following: “*I’m a target archer in order to be a better bowhunter; and I’m a better bowhunter because I’m a target archer*.”
- I feel like there’s a very important puzzle piece to being ethical that involves you giving everything you have to being the absolutely best archer you can be
- If you don’t **know your limitations**, you may not hit an animal in the right spot in order to take it down swiftly and humanely

-John says:

“*I’ve always felt ethically I need to know my limitations because when that moment happens, I’m going to be able to make a perfect shot. . .*

*. . .And the more I’ve done it in practice and in weird conditions, the more you realize, ‘This might not be a shot I should even take, even though I know I can technically shoot this far.’*”

## The blissful nature of archery, and the uselessness of anger [57:15]

\*Peter appeared on John Dudley’s podcast [found here](https://nockon.podbean.com/e/pc-244-dr-peter-attia-icon-series/)

- In that discussion, Peter attempted to answer why archery and why John’s teachings so resonated with him
- “*I just think there are some people for whom that degree of perfection is so blissful. There’s such an amazing state.*”

**Why archery is different than the many other obsessions Peter has had in the past**:

- Peter obsesses over many things
- Perfecting surgery, driving, swimming, cycling, etc.
- However, archery is the ONLY one of those things that he doesn’t get pissed off about when he doesn’t do well (other than a few occasions)

> “It’s almost like there’s a benefit to archery for my psyche that goes beyond the performance. There’s something about the act of doing it that is in and of itself beautiful even if I don’t meet the objective. So, the journey seems to matter as much as the destination in archery as anything I’ve ever done.” —Peter Attia

**Does John ever get angry with archery?**

- Yes, there have been times where John has gotten very angry
- However, he quickly realized, “when I do that in archery, it makes it worse really fast.”

> “Archery is really a sport of zen and clarity. You shoot better when you’re trying less. So, when you get mad, you only get worse at it.”

- But it took John a while to learn this
- He used to get very frustrated at times and he struggled with the fact that there was no way to release that anger (in football he could just go hit someone, for example)
- So in archery he’d end up snapping an arrow in half or slamming his bow on the ground
- Keep in mind, John as less than 20 years old when he started becoming a pro

*-Did John ever question his decision to quit football during these moments of anger and frustration?*

- “No”, says John
- Instead, his self-talk was more like: “Something defeated me that day, and it wasn’t going to do it tomorrow. I wasn’t looking back. . .what’s happening now is what I’m focused on.”

**Game changing moment for John**

-One day a coach saw John come unglued after a bad shot

- The coach said, “*Do you know anyone that can pull that arrow back to the shooting line from that target?”*
- And I just said*, “No.”*
- And he goes*, “And you never will. . The only thing you have control on is what you haven’t shot yet. You’ve got to let that go. It’s the past.*”

**Why john loved archery and tried many different forms of it**

- John really loved the **training aspect** of archery
- So many different forms and technique to work on
- He also says he just love the “prep” part (probably why he loves to cook)

## Hyper-focus and flow states—Did John’s ADD and task-driven personality give him an advantage? [1:07:15]

Book John read ⇒ [Mind Gym](https://www.amazon.com/Mind-Gym-Athletes-Guide-Excellence/dp/0809296748/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)

**Could having ADD be an advantage?**

- John has a pretty severe case of ADD and a learning disability
- He barely got by in high school and it was largely because he was a such a good athlete
- With ADD usually comes the inability to focus
- However, a lesser known symptom for some people with ADD is “**hyperfocus**” where with certain activities you can reach *total immersion*
- With archery, John noticed that he could get into an extreme trance where he was so focused to the point where he was oblivious to anything going on around him
- John says he could reach a [flow state](https://en.wikipedia.org/wiki/Flow_(psychology)) that “*most people don’t believe*”
- John thinks this attribute of his personality gives him an advantage

**Task-driven vs. ego-driven mentality**

- Psychology has something called *ego-driven and task-driven personality types*
- John says he is very clearly a **task-driven** personality type

> “Task driven personality type athletes are normally the ones that kind of [stay] at their peak levels for the longest period of time. They might not peak as high as the ego-driven, but as fast as the ego-driven can peak, they can also decel. So when people are looking at ‘Do you want the superstar?’, the ego-driven is like your route. . .[But] the task driven is what you build a team off of.”

## The common traits found in the most successful people [1:12:45]

**1—The love of practice**: “I have yet to meet a world class exceptional performer who didn’t love to practice.”

- Lance Armstrong ⇒ Lance would want to keep going after 6 hours of grueling cycling
- [Apolo Ohno](https://peterattiamd.com/apoloohno/) ⇒ “his appetite for training was just unbelievable”

**2—The ability to practice deliberately**: The best athletes understand the difference between good and bad practice and appreciate what it means to practice deliberately

- Ayrton Senna ⇒ “*his attention to detail was second to none*.”

*\*Peter points out how much he LOVES to practice archery*

- Only two reasons I’ve ever stopped shooting:
  - 1) Time constraint
  - 2) Physical exhaustion
- “*That’s so cool that there is something you can love that much, because I can’t say that about a lot of things*.”

**The love of practice is good for life and business (not just sport)**:

In business, for example, people fail bc they lack the “in between” – i.e., no love for the process

- John says this love of the process, the drive to get better, and the love of preparation is important outside of sports, and especially in business
- John does some consulting for brands and businesses
- And he says many people have good ideas and have a vision for how they want that idea of end up
- But they really lack the “in between”

> “The amount of people that I know that fail because they are really good about the start and they’re really good about wanting to know how they want to finish, but they kind of lack the in between. It’s just a destructive path. And it’s unfortunate because I’ve seen good business concepts, I’ve seen good people and I’ve seen good investors fail.”

## The keys to maintaining credibility as a salesman—integrity, honesty, and straightforwardness [1:18:45]

- Peter commends John for much credibility he has maintained
- In many cases, it’s hard to trust someone when they recommend a product because you just don’t know if they are getting kickbacks
- But Peter holds John’s opinion very highly because he can tell how honest John really is

*How deliberately has John been in developing that amount of credibility in his word?*

- It’s super important says John

*Where did he learn to sell?*

- When he was 19 he sort of fell into it when a company called [Mathews Archery](https://www.mathewsinc.com/?gclid=CjwKCAjwvtX0BRAFEiwAGWJyZCyn0q0NnyAbXsLtU-Ajk7qBEHtbyGvhNr8SmISRvvxVzrqI1FkWrxoCX6YQAvD_BwE&gclsrc=aw.ds) noticed how well John was able to talk to people and communicate about products
- They offered him a job as a sales rep
- At that time the company only had a handful of employees
- 10 years later, it was a massive business on the Inc 500 Business list
- John learned pretty quick that being honest and truthful (even when people didn’t like it) was the most important thing
- He never spoke badly about other company products… he only highlighted the good about the products he was selling
- This worked out bc the moment he left Mathews, he was called up by Hoyt, their biggest competitor, and was offered a job

> “And that was very clear to me that being **straightforward and truthful** all the time, especially owning up to when I make mistakes and publicly telling everybody about when I make mistakes. . .I think it’s just critical and I don’t work with products I don’t like 100%.”

*How did John handle having to sell a product that he didn’t fully like?*

- For example, what if the company came out with a product that John didn’t like, but the company was saying “*hey man, do your job*”?
- 2 things to that:
  - First, if he really didn’t like it… he would just shoot what he shot the previous year
  - Secondly, “The bottom line is you don’t talk about what other people do bad. You don’t talk about what you do bad, you talk about what you do right or you talk about what you do better”

> “I always feel like if you focus on either what you’re doing right, what your company’s doing right, or what you want to do right, you’re just going down a super shady road to pick on the things that people might not be doing right at that time, and if it’s a product that I feel isn’t right, you’re just not going to see me do a review about it. I’m not going to do a review to say it’s poor. All I’m going to do is find another product to distract your attention to something that is a better option for you.”

## The coaching technique that makes John a great teacher [1:28:30]

Peter says that John has a knack for teaching… **When did John notice this about himself?**

- Partly just his personality – he’s always been good at communicating with people
- Also been fortunate to be around great teachers who lead by example
- John’s always strived to do better and learning to teach was no different
- John credits a friend of his, bodybuilder [Frank Zane](https://en.wikipedia.org/wiki/Frank_Zane), who gave John pointers about teaching – delivery, relating the curriculum to things that people are familiar with, etc.)

*Teaching technique:* **Relating the material to the student’s interests**

- One thing John took from [Frank Zane](https://en.wikipedia.org/wiki/Frank_Zane) relating the subject matter to something the person is already familiar with
- So when teaching Peter to shoot a bow he tried to relate it to swimming and driving, for example
- With Jocko Willink he related it to shooting a rifle

**Meticulous**

- John is very detailed
- Peter points out how he gave him tips about his elbow position being just a few degrees out of place
- But that slight difference was putting the stress of holding the bow on the biceps, lats, and deltoids
- But when making the slight move of the elbow, it put the tension all on the rhomboids
- And then you are going to release the arrow just contracting the rhomboids
- It all came together in Peter’s mind when John related it to driving a racecar: “*Think about how if you are driving a car, you can easily use your quads, glutes, and hamstrings to move between the throttle and the brake, but wouldn’t it be more effective if you could just sort of use the heel and the toe going back and forth in the intrinsic muscles of the foot and maybe a little bit of the calf and the anterior compartment of the leg?*”

## Why you should consider trying archery (even if you never want to hunt) [1:36:15]

**Archery can be practiced for a long time:** Sort of like tennis, and the opposite of football, archery is a skill/hobby that one can work at for a long time

**The beauty of archery**:

- “The flow state… all of these things are beautiful” says Peter
- Even if you have no intention of ever hunting an animal

> “It teaches you a lot about yourself and it is a beautiful metaphor for life in so many ways. This ability to understand that the only arrow you have control over is the one that’s still in your quiver. You can’t turn back time.”

**It’s much easier to learn today than in the past**:

- So many resources out there now
- Just with John’s [nockonarchery YouTube videos](https://www.youtube.com/user/nockonarchery), Peter says you could probably learn **60-70% of the total theoretical benefit** that one could get having a great coach standing over their shoulder

**Importance of learning the fundamentals**:

> “It’s a necessity, not only to archery, but to any sport, for people to recognize the fact that the fundamentals are what makes people good at things.”

⇒ Beginners should check out John’s [12 Week School of Nock](https://www.youtube.com/playlist?list=PLlFlZLYiJ88OTQmFXhh34VNC1y9LCd6kG)

**The key to getting kids to stick with something**:

- “when people are good at things, they stay involved” says John
- His take is that you need to set a kid up for success from the very beginning so that they don’t quit too early on
- “As parents… what you need to do is you need to make this fun and you need to make sure that they’re doing well at it a lot so that they stay involved with it.”
- John says this is especially important for pre-teens
- “What I would say is get the biggest bulls-eye possible, put one target that’s 10 yards away”

**The type of feedback to give your kids when starting out in archery:**

- John says to give them feedback on their technique and not the result
- It can’t ONLY be about whether or not they hit the target
- Instead, tell them when they’re shooting good or tell them when they might need to make technique changes if maybe they’re not executing properly

## Hunting discussion—the morality argument, hunting vs. commercial farming, managing overpopulation, and the unique emotional connection [1:45:00]

- Peter had no intention of ever hunting when he picked up archery as a hobby
- But he ultimately decided to go on a hunt
- It has changed his thinking in terms of how important it is to be good
- If you miss a shot you could injury and animal and cause unnecessary suffering

***How does hunting fit into conservation?***

***And who decides what animals get to be hunted and when and in what quantity?***

- Each state has a department of natural resources and/or department of game and fish
- They perform studies on the different species and population numbers
- They decide how many need to be taken to keep that herd in proper management
- With that information, they sell tags to people to be able to take an animal
- And that money typically goes back into conservation programs and to maintaining the natural areas, etc.

**Traffic accidents with deer**

- According to this [study](https://www.ncbi.nlm.nih.gov/pubmed/15823876), deer–vehicle collisions lead to about 200 human deaths and $1.1 billion in property damage every year
- Peter recalls reading that there are ~1,200,000 collisions a year
- And $5 billion spent on damages and protecting against it

**Hunting means NOT supporting commercial farming**

- Hunting a wild animal means not supporting commercial farming… “which I feel pretty good about.”
- “I know exactly where it came from. I know who touched it, start to finish.”

**Hard work paying off**:

- John is passionate about hunting and cooking because it’s something he puts a lot of work into from:
- The training necessary with archery and lifting weights to be in shape
- To the hunt itself putting in over 250 miles on the ground to find the perfect shot
- Taking out the animal swiftly
- Carrying over 500 lbs of meat out of there
- And finally getting it all the way home and cooking and eating it

> “Every freaking mile that we packed that sucker out of there, it was totally worth it.”

[**Hunting axis deer in Hawaii**](https://www.instagram.com/p/BvcVlrLA3go/)

⇒ See Peter’s [appearance on John’s podcast](https://nockon.podbean.com/e/pc-244-dr-peter-attia-icon-series/) for more detail about their axis deer hunt in Hawaii

![](https://peterattiamd.com/wp-content/uploads/2020/04/axis-deer-dudley-1024x688.png)

**Figure 3. Axis deer.** Image credit: [wikipedia.org](https://en.wikipedia.org/wiki/Chital)

About the axis deer, Peter says: “*They’re simply gorgeous actually. I’ve never seen a prettier animal in nature.*”

- They are not native to the US
- They were brought to Hawaii from India 100+ years ago
- But they were equipped to evade tigers so they are very fast and agile and hard to hunt
- They have since multiplied quickly without a natural predator in Hawaii
- They have become a major pest to the land and have destroyed much of the land needed for livestock
- So rather than a wholesale slaughter, Hawaii allows for the ethical hunting of them to reduce their population

**An emotional feeling like no other**:

- During their hunt, they were able to kill a couple deer
- They took it to a local restaurant where the chef cooked it for them
- The animal was so large they were able to feed the whole restaurant staff

> “This is a circle of life here. This a beautiful animal, but it’s now out of balance with our environment and this is a little part that we can do to bring it back into balance. And in the process, those amino acids, that carbon, that nitrogen is going to come back into the people who live here, who have lived here, and who are now working here.” —Peter Attia

**Peter says this is a unique feeling**

- It’s a feeling that maybe can be explained logically to someone
- “*But I don’t think I could have viscerally or emotionally understood it.*”

**Why hunting is more humane than even the most humane commercial farming**:

- Peter says that he’s visited what’s considered the most human version of commercial cattle farming
  - Eating grass
  - Roaming free
  - However, the animal isn’t truly “wild” and also, it’s hard not be struck by the stress the animal goes through when it’s time to be slaughtered

**Hunting strikes Peter as the most ethical way to consume meat**:

> “Actually seeing what a wild animal looks like and watching how if you can be an exceptional archer or hunter, if you’re using a gun, if you can end that animal’s life without its suffering and its basically lived for four years in perfect nature, eating exactly what it’s supposed to be eating, behaving and moving exactly how it was supposed to move, and then in a moment it’s life ended, it just strikes me as the single most ethical and healthy way you can consume that.”

**What hunting has shown John:**

- It has given him an appreciated for the beauty of outdoors that we take for granted
- Secondly, he loves seeing the moment when a person goes on their first hunt
- And when they finally get the meat back and eat their first piece off the grill…
- *“You can see in their face, ‘wow, this is the most meaningful meal that I’ve ever done.’*”

**One lesson that a hunting guide taught to Peter’s daughter Olivia…**

- The guide said to her, “*You know this is in your blood, right? … You are a hunter. You wouldn’t be here, Olivia, if this wasn’t a part of who you are.*”
- The point it… none of us would exist without our ancestors being successful hunters
- It’s only recently that we can walk into a grocery store for our meat
- And so there is a feeling of pride of being able to subside on nothing but what you can hunt and fish (and grow)

***Has John ever been confronted aggressively opposing hunting?***

- A few times, says John
- “All I can do is just say, ‘*I see your point. You’re somewhere where it just isn’t going to be clear to you*’, and I think that’s the best way really to address it.”
- John points out that is easy to understand someone who is an animal lover, how they can see shooting an animal as cruel
- But reality is that it can be done humanely
- And many deer are overpopulated and causing problems to land and causing car accidents in many places
- It’s best to not talk negatively about those who oppose hunting but instead to just speak positively about hunting
- Hunting can be ethical and sustainable
- It’s also healthier and has helped John eat better

> “It’s honestly made me eat less junk and it makes me more focused on supporting what our environment puts in front of us more so than what some type of refinery does or a chemical does.”

## Resources for those interested in taking up archery [2:12:00]

*YouTube Channel*: [nockonarchery](https://www.youtube.com/channel/UCZ0_SNBxvCZyEqURjK8dTPQ)

*Instagram*: [@nockontv](https://www.instagram.com/nockontv/?hl=en)

*Podcast: [Nock On Podcast](https://podcasts.apple.com/us/podcast/nock-on/id827919428)*

**12 Week School of Nock**:

- Can be found on [YouTube](https://www.youtube.com/playlist?list=PLlFlZLYiJ88OTQmFXhh34VNC1y9LCd6kG)
- Or on [instagram IGTV](https://www.instagram.com/nockontv/channel/?hl=en)

“*It will pave the way for you to have really good fundamentals and basics.*”

§

## Selected Links / Related Material

**John’s amazing content on archery**: [1:30, 1:04:30, 2:12:00]

- Y*ouTube Channel*: [nockonarchery](https://www.youtube.com/channel/UCZ0_SNBxvCZyEqURjK8dTPQ)
- I*nstagram*: [@nockontv](https://www.instagram.com/nockontv/?hl=en)
- *Podcast: [Nock On Podcast](https://podcasts.apple.com/us/podcast/nock-on/id827919428)*
- S*chool of Nock*:
  - [YouTube](https://www.youtube.com/playlist?list=PLlFlZLYiJ88OTQmFXhh34VNC1y9LCd6kG)
  - [IGTV](https://www.instagram.com/nockontv/channel/?hl=en)

**Peter’s appearance on John’s podcast**: [PC 244 – Dr Peter Attia – Icon Series](https://nockon.podbean.com/e/pc-244-dr-peter-attia-icon-series/) | (nockon.podbean.com) [3:00, 57:15, 1:33:30, 1:55:40, 2:04:45]

**Jocko’s MÖLK protein that Peter and John are enjoying**: [JOCKO MÖLK](https://originmaine.com/search.php?search_query=molk) | (originmaine.com)  [10:30]

**Wine that Peter and John are drinking**: [Clio wine](https://www.instagram.com/p/Bh2j-VUhG-P/?hl=en) | @peterattiamd (instagram.com)  [10:30]

**Where John’s mom worked when John was a kid**: [Baxter Healthcare](https://www.baxterhealthcare.co.uk/)  [16:15]

**John grew up near here**: [Fox River (Illinois River tributary)](https://en.wikipedia.org/wiki/Fox_River_(Illinois_River_tributary)) | (wikipedia.org) [23:0]

**The bow and arrow shop where John first worked at age 19**: [Gat Guns](https://www.gatguns.com/) | (gatguns.com) [26:00]

**John on the Joe Rogan Podcast**: [34:15, 1:46:00]

- [Joe Rogan Experience #783](https://www.youtube.com/watch?v=JRli5x_pHWk) | PowerfulJRE (youtube.com)
- [Joe Rogan Experience #1181](https://www.youtube.com/watch?v=4FX71oBDVvY) | PowerfulJRE (youtube.com)

**Jocko coffee cup**: [Get After It mug](https://originmaine.com/origin-usa/nutrition/jocko/jocko-white-tea-mug-get-after-it/) | (originmaine.com) [49:00]

**Book John read when trying to understand if his ADD was giving him some kind of focusing advantage**: [Mind Gym : An Athlete’s Guide to Inner Excellence](https://www.amazon.com/Mind-Gym-Athletes-Guide-Excellence/dp/0809296748/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Gary Mack | (amazon.com) [1:08:00]

**Apolo Ohno on The Drive**: [#29 – Apolo Anton Ohno: 8-time Olympic medalist – extreme training, discipline, pursuing perfection, and responding to adversity](https://peterattiamd.com/apoloohno/) | Peter Attia (peterattiamd.com) [1:13:45]

**Archery companies that John has worked for and sold for**:

- [Mathews Archery](https://www.mathewsinc.com/?gclid=CjwKCAjwvtX0BRAFEiwAGWJyZCyn0q0NnyAbXsLtU-Ajk7qBEHtbyGvhNr8SmISRvvxVzrqI1FkWrxoCX6YQAvD_BwE&gclsrc=aw.ds) [1:21:30]
- [Hoyt](https://hoyt.com/) [1:25:00]

**Big Sky archery competition**: <https://totalarcherychallenge.com/events/big-sky/> [1:37:45, 1:55:00]

**Deer collision stats**: [Characteristics of vehicle-animal crashes in which vehicle occupants are killed.](https://www.ncbi.nlm.nih.gov/pubmed/15823876) (Williams and Wells, 2005) [1:49:45]

**Resources for those interested in taking up archery**: [2:12:00]

- *YouTube Channel*: [nockonarchery](https://www.youtube.com/channel/UCZ0_SNBxvCZyEqURjK8dTPQ)
- *Instagram*: [@nockontv](https://www.instagram.com/nockontv/?hl=en)

**12 Week School of Nock**: [2:12:00]

- Can be found on [YouTube](https://www.youtube.com/playlist?list=PLlFlZLYiJ88OTQmFXhh34VNC1y9LCd6kG)
- Or on [instagram IGTV](https://www.instagram.com/nockontv/channel/?hl=en)

§

## People Mentioned

- [Joe Rogan](https://twitter.com/joerogan?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [2:30, 34:15]
- [Andy Stumpf](https://twitter.com/AndyStumpf77?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [7:30]
- [Jocko Willink](https://twitter.com/jockowillink?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [10:30, 1:31:30, 1:35:30]
- [Greg Landry](https://en.wikipedia.org/wiki/Greg_Landry) [11:15]
- Mike Douglas [18:30]
- Mike Donovan (manager at Gat Guns) [26:45]
- [Lance Armstrong](https://twitter.com/lancearmstrong?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [1:13:00]
- [Apolo Ohno](https://twitter.com/ApoloOhno?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [1:13:45]
- [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) [1:14:00]
- JR [1:15:15, 1:28:30]
- Josh [1:15:15]
- [Frank Zane](https://en.wikipedia.org/wiki/Frank_Zane) [1:30:00, 2:07:30]
- [Arnold Schwarzenegger](https://twitter.com/Schwarzenegger?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) {1:30:00]
- Trevor (SEAL friend) [1:38:30]
- Sharon (John’s wife) [1:38:30]
- Andy (mutual friend) [1:39:30]
- Harry (John’s son) [1:40:45]

§