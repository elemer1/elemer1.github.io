# #224 ‒ Dietary protein: amount needed, ideal timing, quality, and more | Don Layman, Ph.D.

**Source:** [https://peterattiamd.com/donlayman/](https://peterattiamd.com/donlayman/)

---

Don Layman is a Professor of Food Science and Human Nutrition at the University of Illinois Urbana-Champaign. He has spent the past 40 years investigating the role of dietary protein in muscle protein synthesis. In this episode, Don describes how his decades of research have shaped his thinking around protein, muscle, anabolic factors, metabolism, and more. He explains the recommended dietary allowance (RDA) for protein: what it is, how it came about, and how it should serve only as a guide for the minimum protein necessary for survival rather than as an optimal level of protein intake. He provides an overview of the essential amino acids, explains the nuances of animal versus plant protein, and provides insights for determining protein quality, absorption rates, and how to best track your intake. He discusses the ideal timing of protein intake in relation to resistance exercise, how protein should be distributed among meals, and how limitations in protein utilization per sitting can impact those practicing time-restricted eating. Additionally, Don shares results from his clinical trials, including how a high-protein diet fared in terms of fat loss, and explains the differences in protein utilization between adolescents and adults and how the problem of reduced efficiency of protein utilization in older adults can be overcome.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/donlayman/the_Drive_public.png)

Play

#224 ‒ Dietary protein: amount needed, ideal timing, quality, and more | Don Layman, Ph.D.

#224 ‒ Dietary protein: amount needed, ideal timing, quality, and more | Don Layman, Ph.D.

1x15s30s

0:002:02:32

## We discuss:

- Don’s background: from growing up on a farm to studying nutritional biochemistry [2:30];
- Don’s philosophy on nutrition, muscle, and metabolism [6:30];
- The controversial relationship between saturated fat and atherosclerosis [18:15];
- The basics of protein and amino acids [25:45];
- Origin and limitations of the current recommended dietary allowance (RDA) for protein intake [32:15];
- Protein sources: determining quality, absorption rates, and how to track intake [41:15];
- Leucine, lysine, and methionine: three important essential amino acids [48:00];
- The vital role of ruminant animals in the production of quality protein [53:15];
- The differing needs and impacts of dietary protein for a 16-year old compared to a 65-year old [59:30];
- Consequences of protein deficiency in childhood [1:06:30];
- Muscle protein synthesis: ideal timing, small meals vs. big meals, and more [1:12:45];
- Protein needs of children [1:19:45];
- How important is timing protein intake around training? [1:24:15];
- The role of leucine in fatty acid oxidation by muscle [1:28:15];
- High protein diets for fat loss: Results from Don’s clinical trials [1:31:30];
- Influence of industry funding on nutrition studies [1:43:45];
- Don’s thoughts on plant-based and synthetic “meats” [1:48:45];
- Problems with epidemiological studies of dietary protein [1:56:30];
- More.

§

## Show Notes

**\*Notes from intro**:

- Don Layman is a Professor Emeritus of Food Science and Human Nutrition at the University of Illinois Urbana-Champaign, where he served as a member of the faculty, as well as the chair of Foods and Nutrition, the Director of Human Ecology and the Associate Dean of Agriculture
- He earned his bachelor’s and master’s degrees in Chemistry at Illinois State University and his doctorate in Human Nutrition and Biochemistry at the University of Minnesota
- His research has focused on muscle development, protein and amino acid metabolism, and nutrition in the context of athletic performance, obesity, diabetes, and cardiometabolic health
- Don currently consults for many food industry companies, including Kraft, Nestle, Hershey, the dairy council, the egg board, and the beef board
- In this episode, we talk about Don’s background, his interest in protein, muscle, insulin, and  anabolic factors in general
- We explain what the RDA (recommended dietary allowance) for protein is
  - How it came about
  - How it’s clearly being misunderstood by people as a recommended amount of protein versus a barely minimum protein amount for survival
- We talk about the nuances of animal versus plant protein
- We talk about the difference in protein requirements between children and adults, even normalized to mass
- And we talk about what happens to children who are protein deficient early in life
- Then we look specifically at protein needs under various circumstances
  - For example, what’s the maximum amount of protein that can be consumed and used in one sitting which will still contribute to muscle protein synthesis
- We talk about the ideal timing of consuming protein throughout the day and around exercise
- We talk about the importance of protein quality when looking at how much or how little a person consumes
- Then we talk about how these things change as you age

## Don’s background: from growing up on a farm to studying nutritional biochemistry [2:30]

- Peter has heard a lot about Don over the past couple of years from their mutual friend [Layne Norton](https://biolayne.com/coaching/coach/layne-norton/), who suggested they get together and go deeper down this nutritional pathway
- Nutrition is Peter’s least favorite subject only because he’s so tired of the religious aspect of nutrition
  - He enjoys talking about nutrition through the lens of biochemistry
- Don was interested in biochemistry first
  - Studying organic chemistry just seemed so boring and esoteric
- With nutrition, he could actually apply biochemistry to things people were interested in

**What was it like growing up on a farm in Illinois?**

- His dad lived to 97 and his mom to 102
- It was great, he was born in the ‘50s
- This was a time when agriculture was very poor in the US
- He learned about animal growth and reproduction
- He leaned about growing corn and soybeans
- He was very interested in food, he always had an interest in science, and this evolved to be a natural marriage
- He grew up in a small town; his school had about 400 people in it

**In college Don first studied biochemistry and organic chemistry**

- This was the serendipity of how he got into nutrition; he didn’t know anything about it
- He first went to Illinois State University to study chemistry
- He realized quickly he had no aptitude for inorganic chemistry, but he understood biochemistry pretty well
- This was during the Vietnam War and he was scheduled to go into the military
  - He was totally unemployable
- So when the university offered him a graduate assistantship, he took it and got a master’s in biochemistry
- His mentor at the time said, “Y*ou really have a knack for this nutrition part of it. Why don’t you do a PhD?*”
- He ended up at University of Minnesota doing a Ph.D. in nutritional biochemistry and fell in love with all of it
- There was no grand plan, but it fit his background of agriculture, foods, sports nutrition
- He fell into a group that was doing muscle metabolism and it just all fell together for him

**Was** [**Ancel Keys**](https://en.wikipedia.org/wiki/Ancel_Keys) **at the University of Minnesota at that time?**

- No, he had left, but his legacy was there with [Henry Blackburn](https://directory.sph.umn.edu/bio/sph-a-z/henry-blackburn), [Ivan Frantz](https://www.bmj.com/content/bmj/suppl/2016/04/12/bmj.i1246.DC1/ramc027623.ww1.pdf), and some of those individuals
- Don got that background while he was there and it certainly invested a lot of his early thinking of nutrition
- [Layne Norton](https://biolayne.com/coaching/coach/layne-norton/), who you’ve [talked](https://peterattiamd.com/laynenorton2/) with before, has talked about how our thinking of nutrition evolves; “*mine certainly has evolved*”

## Don’s philosophy on nutrition, muscle, and metabolism [6:30]

**What was your underlying philosophy of nutrition circa 1975, when you were doing your Ph.D?**

- His earliest thinking about nutrition involves his interest in animal growth and sports nutrition
- Very early he developed  the philosophy that nutrition was really about two tissues, the brain and skeletal muscle
- If those two tissues were healthy, you were going to live a pretty good life
- Everything else is regulatory‒ the liver, the heart, the kidney, the gut
- Everything else adapts to your environment, but you have to focus on those first two
- Don says that “*if you tailor your nutritional requirements around that thinking you end up with a much more sensible approach*”
- He coined the concept that his colleague, [Dr. Gabrielle Lyon](https://drgabriellelyon.com/about/) and he always use‒ **muscle centric nutrition**
  - If you keep muscle healthy, you’ve got a good shot at avoiding obesity, avoiding diabetes, avoiding cancer, etc.

> “If you keep muscle healthy, you’ve got a good shot at avoiding obesity, avoiding diabetes, avoiding cancer, etc.” —Don Layman

**Details about muscle**

- Peter notes that muscle is our largest sink for glucose
  - 75-80% of our glucose storage capacity exists within skeletal muscle
- Muscle is also an early depot for excess adipose tissue
- Once we start to let little droplets of fat accumulate within muscle cells, it leads to this process of **insulin resistance**
  - This creates a problem in that it makes it  harder for muscle to accept carbohydrates
  - This leads to hyperglycemia and ultimately diabetes

**How Don formulated his thinking about muscle**

- What Peter said is correct but he thinks about it differently

*Muscle serves 2 functions*

- 1 – ***Mobility***, functional mobility is critical
  - Most people live to age 65; beyond that most people actually die from some form of immobility
    - This can be falls, breaking something, hospitalization
- 2 – ***Metabolism***, muscle is a primary site for insulin activity
  - Peter mentioned glucose storage but he looks at it more in terms of glucose utilization and fat utilization
- Blood glucose and blood lipids are heavily dependent on muscle metabolism
  - Obviously the amount you eat makes a difference
  - But the actual level is heavily dependent on your muscle metabolism
- Don notes, “*You commented about insulin resistance being associated with fat, actually insulin causes insulin resistance*”
- If you chronically elevate insulin for too long, that is the definition of [type 2 diabetes](https://en.wikipedia.org/wiki/Type_2_diabetes)

**Causality of type 2 diabetes**

- Peter spoke with [Jerry Schulman](https://medicine.yale.edu/profile/gerald_shulman/#:~:text=Shulman%20is%20the%20George%20R,the%20Yale%20Diabetes%20Research%20Center.&text=Shulman%20is%20the%20recipient%20of%20the%20Stanley%20J.) on the [podcast](https://peterattiamd.com/geraldshulman/) about 2 years ago
  - His paradigm was the accumulation of diglycerides within actual [myocytes](https://en.wikipedia.org/wiki/Muscle_cell), not interstitial or in between
  - The actual accumulation of lipid within muscle cells impairs insulin signaling resulting in decreased [PI3K](https://en.wikipedia.org/wiki/Phosphoinositide_3-kinase) activation
    - This removes the signal needed to move the glucose transporter [GLUT4](https://en.wikipedia.org/wiki/GLUT4) to the cell membrane (and glucose is not taken into the muscle cell)
  - Hyperinsulinemia is effectively the first way you can externally measure insulin resistance

*Is this in line whe what you’re saying?*

- Yes and no.  Don agrees Jerry Shulman is great and he follows his research a lot
- In biochemistry you can create models that give negative feedback
- Schulman is correct that [diacylglycerol](https://en.wikipedia.org/wiki/Diglyceride) or [ceramides](https://en.wikipedia.org/wiki/Ceramide) (lipids/ fats) will feed back to the insulin receptor, GLUT4 transport, and cause insulin resistance
  - That is a fat centric philosophy, that fat causes all the problem
- You can do the exact same thing with glucose
  - Too much glucose will also inhibit the insulin receptor and cause that same exact feedback
  - It doesn’t cause accumulation of ceramides or diacylglycerides
- The question becomes‒ *Which one is more likely to be physiological?*
- Is insulin resistance due to people eating 350 grams of carbs per day?
  - Or people eating 90 grams of fat per day?
- The [Randle hypothesis](https://en.wikipedia.org/wiki/Randle_cycle) claims that fatty acids (diacylglycerol) cause all the problems
- [Bob Wolfe](https://aging.uams.edu/dr-robert-r-wolfe/) did this [experiment](https://journals.physiology.org/doi/abs/10.1152/ajpendo.1996.270.4.e733) with stable isotopes and showed it’s the reverse
  - Fatty acids are not inherently toxic but glucose is
- Glucose has its own disease, diabetes
  - When you eat excess carbs, you must get rid of them
  - Carbs absolutely have to be disposed of in the next 2 hours
- Fat can hang around for much longer, it’s not that toxic to the body
  - The body always wants to have a certain level of free fatty acids in the blood because that’s fuel for the heart

**What about the ability to turn excess glucose into fatty acid via** ***de novo*** **lipogenesis? Doesn’t that happen quickly enough to alleviate some of the toxicity of acute hyperglycemia?**

- It doesn’t happen super quick
- A lot of people argue how much *de novo* [lipogenesis](https://en.wikipedia.org/wiki/Lipogenesis) (fat synthesis) actually occurs
- But when you get into requiring high amounts of de novo lipogenesis, now we start talking about fatty liver
  - This is when you start seeing [triglyceride](https://en.wikipedia.org/wiki/Triglyceride) problems
  - People who are actually doing a lot of *de novo* lipogenesis typically have elevated triglycerides; that’s one of the first signs that you’re disrupting that flow
- Triglycerides in general are there to recycle free fatty acids
- Adipose tissue is always dumping free fatty acids out for the heart and other tissues

> “*The problem comes in when you start blending that with too many carbs and too many fats*”‒ Don Layman

- First and foremost, calories are always the problem
- You get in trouble when you have excess calories *and* you start rebalancing these macronutrients
- Peter adds, “*There’s a very* [*famous paper*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC408572/) *by* [*Marc Hellerstein*](https://nst.berkeley.edu/users/marc-hellerstein) *circa mid 90s, that demonstrates really a very small amount of de novo lipogenesis taking place with carbohydrate feeding.  I absolutely believe the results of the paper, but I also think it’s a very narrow context and it’s not necessarily the context of an overfed individual.*”
  - He thinks our capacity for *de novo* lipogenesis (DNL) depends heavily on total energy content or total energy balance
  - He thinks there is a scenario where in the Hellerstein paper you can feed a high carbohydrate diet, but within the overall composition of a low energy diet (or a balanced energy diet) and DNL is actually quite low
  - Conversely, you can feed a high carbohydrate diet in the context of a high energy diet and we would probably see a much greater amount of DNL
- Don agrees
- Peter thinks the context matters
  - If were were describing this as a polynomial, the first order term is energy‒ how many calories are coming in
    - That probably matters more than the ratio of carb to fat

**Back to the Randle Hypothesis**

- Don always thinks of excess glucose (carbohydrates) as toxic
- If the blood glucose level is high, it will damage every tissue from your eyes to your toes
- You have to dispose of the glucose
- Hellerstein’s study looked at an American diet (50% carb, 35% fat)
  - If you take in a 1,000 calorie meal or an 800 calorie meal, which one will result in more fat synthesis?
  - The carbohydrate will get burned and the fat will go to fat

***The body simply selects the easiest pathway***

- But if you switch that to a diet of 80% carb and 10% fat then you’ll see *de novo* lipogenesis
  - [Jules Hirsch](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(15)00112-9/fulltext) [showed this](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC507283/) and [Jeff Volek](https://www.virtahealth.com/people/jeff-volek) also [showed this](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4240601/)
- One of the interesting things is that when the body makes fat, the only type it can make is saturated fat

***Having a lot of saturated fat in the blood doesn’t actually come from eating fat, it comes from eating carbs***

**Think of this in context of how much you’re eating**

- We burn around 100 calories per hour; that would be 2,400 calories per day
- So in 2 hours you’re burning 200 calories
  - Everything else has to be stored
- An average American meal is 400 to 1,000 calories; that means you have to store all of that

**Is this an argument for spreading out calories more over the course of a day?**

- Absolutely not; there are 2 angles on that
- 1 – A theory in the mid 80s by [Gil Leveille](https://academic.oup.com/jn/article/150/5/973/5804832) was that lots of small meals was good for less fat deposition
- This turned out to be an artifact of how he did the [study](https://pubmed.ncbi.nlm.nih.gov/241078/)
  - He showed that when animals made the adaptation to small meals, the animals didn’t gain as much as if you adapted them to eating 2 meals per day
  - The artifact was, when an animal adapts to 2 meals per day, they go through a starvation period and when they come out of a starvation period, they make more fat
- Don redid the study with a longer adaptation period and [found](https://www.sciencedirect.com/science/article/abs/pii/S0271531784801074) that reducing the number of meals per day is actually thermogenically advantageous
  - You actually waste more calories
- 2 – The other aspect to consider is protein
  - Protein needs to be distributed at specific meals, and the distribution needs to be high

> “*Eating lots of small meals is a really bad choice for a lot of reasons*”‒ Don Layman

## The controversial relationship between saturated fat and atherosclerosis [18:15]

**At the University of Minnesota,** [**Ancel Keys**](https://en.wikipedia.org/wiki/Ancel_Keys) **is really famous for 2 things in the mid 70s**

- 1 – His seven countries study
  - Published as a book in 1980, [*Seven countries : a multivariate analysis of death and coronary heart disease*](https://www.google.com/books/edition/_/hOxrAAAAMAAJ?sa=X&ved=2ahUKEwjTxKGnxez5AhXiD1kFHcm2AQ4Q7_IDegQIFBAC)
  - [Summary](https://www.epi.umn.edu/cvdepi/study-synopsis/seven-countries-study/) from the University of Minnesota
- The hypothesis now is a very fat centric view of the negative consequences of dietary fat
  - Specifically dietary saturated fat in the American diet
  - Especially as it pertains to ASCVD
- 2 – Starvation experiments
  - These were done on conscientious objectors, in the 40s
  - The results were published in a 2-volume book in 1950, [*Biology of Human Starvation*](https://www.google.com/books/edition/The_Biology_of_Human_Starvation/3jqCzgEACAAJ?hl=en)
- We learned a lot about starvation from these studies

**How Don’s thinking evolved about saturated fat**

- When he got to Minnesota, he bought into the paradigm about the dangers of cholesterol, saturated fat, and total fat
  - This is what was being taught
- As he slowly started doing experiments, his thinking began to change
- Early in his career he did a lot of fasting experiments with animals to look at composition changes
- He did malnutrition work in Northern Africa
- He will always remember a seminar at Minnesota by [Fred Kummerow](https://en.wikipedia.org/wiki/Fred_Kummerow) about the dangers of cooking oils and trans fats
  - [Blackburn](https://directory.sph.umn.edu/bio/sph-a-z/henry-blackburn) and [Frantz](https://www.bmj.com/content/bmj/suppl/2016/04/12/bmj.i1246.DC1/ramc027623.ww1.pdf) just ridiculed him
    - They basically said, “*This is the craziest thing we’ve ever heard. All these plant oils are great*.”
  - 20 years later, we have banned trans fats from foods literally as the most dangerous fat that you can encounter
  - Don remembers thinking, “*Wow, people who have bought into this dogma aren’t necessarily right, and we need to keep questioning it*.”

**The Minnesota Coronary Experiment**

- In 1973 Frantz completes the Minnesota Coronary Experiment
  - This is one of the most difficult studies for Peter to interpret
  - Chris Ramsden [republished](https://www.bmj.com/content/353/bmj.i1246) it a couple of years ago, based on all of the data from Frantz’s study, plus data he never published
  - He also published one 16 years later in 1989, [*Test of effect of lipid lowering by diet on cardiovascular risk. The Minnesota Coronary Survey*](https://pubmed.ncbi.nlm.nih.gov/2643423/)
- Don remarks, “*I have posed this question to every friend of mine who is more steeped in nutrition than I am. And I still don’t have a great sense of how to explain these results.*”
- The experiment was done in basically institutionalized patients
  - This might not be easy to do today for ethical reasons
  - It had the advantage of being well controlled
- Patients were randomized into 2 groups; their total energy was identical as was the split of macronutrients
- 1 – One group ate a diet high in **saturated fat**
- 2 – The other group at a diet high in **polyunsaturated fat**
- The hypothesis being tested was‒ *Is saturated fat intake leading to increased major adverse cardiac events, heart attacks, and strokes?*
- The experiment ran for 5 years (1968-1973) and showed no difference

***There was no difference in cardiac events, despite the fact that the group that was on the higher polyunsaturated fat group did indeed have much lower cholesterol levels***

- This predated measuring LDL and HDL (subfractionation of cholesterol); they simply measured total cholesterol
- At the time there was some correlation between cardiovascular disease and total cholesterol levels
  - At the extremes, that was certainly true
- The results showed a significant reduction in cholesterol levels for those with a diet high in polyunsaturated fat
  - The change in serum cholesterol for this group was -13.8% [decreased]
  - The dietary change in saturated fat for this diet was -51% [decreased] and for [linoleic acid](https://en.wikipedia.org/wiki/Linoleic_acid) (a polyunsaturated fat) was 288% [increased]
- Peter notes, “*Based on everything we know today, we would assume that much of that was in LDL cholesterol, indeed being lower and non-HDL cholesterol.  Yet there was no difference in events.*”

> “*It’s become a very famous and unfortunate story in nutrition research and that Frantz chose not to publish it because he didn’t like the results*”‒ Peter Attia

***The results didn’t match his hypothesis, which was that the group on lower saturated fat would have fewer events***

- Peter’s initial view of the Minnesota Coronary Experiment was that the intervention did not go long enough
  - Maybe 5 years is not long enough to appreciate a difference
  - It was underpowered to see a benefit, if there was a benefit
- In [Ramsden’s analysis](https://www.bmj.com/content/353/bmj.i1246#T2), you saw the opposite
  - He looked at some subgroups
  - Now you actually saw a higher incidence of coronary events in some of the people that were consuming the high polyunsaturated fat diet
  - Peter can’t remember what the dominant oil was in polyunsaturated fat diet, canola or safflower [it was corn oil]

**Don’s interpretation of the Minnesota Coronary Experiment**

- Don points out that he is not a lipid expert
- He did some research with Ivan Frantz when he was at Minnesota
- Looking at the literature on saturated fat, it’s a **very mixed bag**
- The people who believe the hypothesis have either delayed publishing it or said it could have been wrong
  - They tried to find all kinds of excuses as opposed to believing the results

> “*There’s an old theory in science that if a theory is correct, it’ll get stronger over time.  And if it’s not, it gets weaker*”‒ Don Layman

***The total cholesterol theory has definitely gotten weaker and the saturated fat theory hasn’t held up very well***

**Don’s Takeaway on saturated fat**

- First and foremost is **calories**
- If you put excess saturated fat on top of too many calories, that’s probably a problem

- But if you’re at or below your calorie needs, he doesn’t see any data to suggest that saturated fat is a problem
- If you’re committed to being obese, you probably ought to pay attention to the quality of your fats
- If your goal is to be lean and healthy, calories is what you should paying attention to
- The macro distribution is your personal preference

## The basics of protein and amino acids [25:45]

- This is the macronutrient that Peter pays the most attention to
- Many days he comes up short in protein intake, but he never goes overboard
- Peter’s goals are to maximize muscle protein synthesis to preserve lean tissue for as long as possible

**How did Don become interested in protein?**

- This began during his master’s degree research
- He was  working with [Arlan Richardson](https://medicine.ouhsc.edu/directory/details/arlan-richardson-phd-1) who was an expert in aging and was studying age-related changes in protein synthesis and protein turnover
- They discovered changes in mRNA over time, that the poly-A-tails on mRNA were getting shorter
  - This lessens the ability of ribosomes to bid the mRNA and results in lower protein synthesis
- This *theme of efficiency (or change) of protein synthesis over time* is a theme that runs through all of his research
- When he went to Minnesota, he became focused on muscle protein
- One of the first things he learned in graduate school is we don’t really have a protein requirement
  - We have a requirement for [9 essential amino acids](https://en.wikipedia.org/wiki/Essential_amino_acid) and organic nitrogen
    - This translates into the fact that we can make 11 amino acids and 9 we have get from our diet

**Don says to think of protein as a “vitamin pill**”

- We don’t have a daily requirement for a vitamin pill
- We have a requirement for 12 vitamins inside the pill
- We don’t actually have a daily requirement for protein, we have a requirement for nine or 20 amino acids inside of it
- In terms of protein requirement, we have a requirement for the 9 essential amino acids
  - These amino acids are essential building blocks for new protein
  - But every one of them has a metabolic role like
    - Leucine and mTOR or
    - Arginine and nitric oxide or
    - Lysine and carnitine or
    - Cysteine and glutathione
  - And all of those roles are vastly above the minimum that is detected for nitrogen balance for the RDA (recommended dietary allowance)
- When we think about vitamin C, we know there’s a minimum RDA to prevent [scurvy](https://en.wikipedia.org/wiki/Scurvy), but people will take 5 or 10 times that during COVID for immune response

***But we resist thinking that way about amino acids, and it’s exactly the same***

**Amino acids 101—Structures common in metabolism**

- Most people understand what [glucose](https://en.wikipedia.org/wiki/Glucose) looks like (see the figure below)
  - It’s a 6 carbon ring and each one has an oxygen and hydrogen on it

![](https://peterattiamd.com/wp-content/uploads/2022/09/f1-donlayman.png)

**Figure 1.  Structure of glucose.**

- Most people who have listened to this podcast have a decent sense of what a fatty acid looks like (see the figure below)
  - It’s a long stretch of carbons
  - If it’s saturated, there are no double bonds
  - So it’s just littered with either 2 or 3 hydrogens depending on where it sits in the chain
  - You store them by putting 3 fatty acids onto a little 3-carbon glycerol backbone to make a triacylglycerol (shown in the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/09/f2-donlayman-840x1024.png)

**Figure 2.  Fatty acids are stored in the form of triacylglycerol.**  Image credit: [OpenStax Biology 2e](https://openstax.org/books/biology-2e/pages/3-3-lipids)

**Amino acids**

- Most people understandably have less clarity around what an amino acid is
  - The figure below shows the generalized structure
- We’ve already alluded to the fact that there were 20 of them
  - They differ in their side chain (R-group)
  - 9 of them we can’t even make, and if we were deprived of these things we’d be dead
- An amino acid looks a little bit like a fatty acid, it has a carboxyl end connected with a carbon and it has a nitrogen end

![](https://peterattiamd.com/wp-content/uploads/2022/09/f3-donlayman-1024x585.png)

**Figure 3.  Generalized structure of an amino acid and 2 examples, glycine and tryptophan.**  Image credit: [OpenStax Biology 2e](https://openstax.org/books/biology-2e/pages/3-4-proteins)

- When we eat protein, we get these amino acids in a string, but we totally digest them down to individual amino acids or maybe di- or tripeptides that we can absorb
  - They get to the blood as single amino acids for the most part
  - Then the body begins to reconnect them based on the [messenger RNAs](https://en.wikipedia.org/wiki/Messenger_RNA)
  - Our DNA tells us how to reconnect them
  - And so we connect a carbon [carboxyl end] to a nitrogen [amino end] and we string them together
- Of these 20 amino acids though, they all have that acid [carboxyl] and nitrogen part, but they also have a side chain, ranging from very simple one like glycine (with just a hydrogen), to ones like tryptophan that have a big aromatic part to them
  - Shown in the figure above
- All of the 20 amino acids are different, they go into proteins and form different structures
- The DNA tells us how we put them together
- Proteins can be simple like [insulin](https://en.wikipedia.org/wiki/Insulin) with 51 amino acids
  - Or they could be like [myosin](https://en.wikipedia.org/wiki/Myosin) with thousands of amino acids
- And then every protein in the body has a different **turnover rate**
  - Some of them, like insulin, might last 15 minutes
  - Some of them like myosin or [collagen](https://en.wikipedia.org/wiki/Collagen) might last 250 days
- But beyond that building block structure, every amino acid has other kinds of structures
- It might be like lysine where part of it becomes the molecule known as [carnitine](https://en.wikipedia.org/wiki/Carnitine) (see the figure below), which is needed for fatty acid metabolism

![](https://peterattiamd.com/wp-content/uploads/2022/09/f4-donlayman.png)

**Figure 4.  Lysine and carnitine.**  Image credit: [OpenStax Biology 2e](https://openstax.org/books/biology-2e/pages/3-4-proteins) and the [Linus Pauling Institute](https://lpi.oregonstate.edu/mic/dietary-factors/L-carnitine)

- Or it might be the nitrogen off arginine that goes to [nitric oxide](https://en.wikipedia.org/wiki/Biological_functions_of_nitric_oxide) for vessel restriction (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/09/f5-donlayman.png)

**Figure 5.  Arginine and nitric oxide.**  Image credit: [OpenStax Biology 2e](https://openstax.org/books/biology-2e/pages/3-4-proteins) and [Wikipedia](https://en.wikipedia.org/wiki/Nitric_oxide)

- Or it might be cysteine, which goes to part of [glutathione](https://en.wikipedia.org/wiki/Glutathione) (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/09/f6-donlayman.png)

**Figure 6.  Cysteine and glutathione.**  Image credit: [OpenStax Biology 2e](https://openstax.org/books/biology-2e/pages/3-4-proteins) and [Wikipedia](https://en.wikipedia.org/wiki/Glutathione)

- Don’s favorite is leucine, this is the signal that really got him interested in protein (see the figure below)

***In metabolism, leucine is a signal for muscle protein synthesis***

![](https://peterattiamd.com/wp-content/uploads/2022/09/f7-donlayman.png)

**Figure 7.  The amino acid leucine.**  Image credit: [OpenStax Biology 2e](https://openstax.org/books/biology-2e/pages/3-4-proteins)

***So all the amino acids have this building block function for making proteins where they get strung together, but they also have other metabolic functions***

## Origin and limitations of the current recommended dietary allowance (RDA) for protein intake [32:15]

- When Peter looks at his patients and evaluates their nutrition, almost without exception, he comes to the conclusion that they are not getting enough amino acids based on how much protein they are consuming

**How the recommended dietary allowance (RDA) came to be**

- The RDA is a recommended dietary allowance
- The argument is that for all RDAs we test a population and come up with an average number and then for a safety factor, which on average 50% would be deficient
  - We add a safety factor of 2 standard deviations, which supposedly would be adequate for 97.5% of the people to prevent any signs of inadequacy
  - But that also means 2.5% of the people are actually deficient at that level

*Where does the RDA come from?*

- Consider the history of how we begin to evaluate protein needs
- It all came out of animal sciences back in the early 1900s, before we even knew all the essential amino acids
- Farmers wanted to know how to get animals to grow best
- They developed protein quality scores and things like that to track much growth they saw for what they fed the animals
  - How much nitrogen was deposited for how much was fed?
  - So these were all rapidly growing animals
- From this developed a concept of nitrogen retention
  - That we’ve now translated into what’s called **nitrogen balance**
  - And that’s how we determine the protein requirement
  - All of the concepts were developed for growth where nitrogen balance was positive
- You could measure a change over time
- Now that we have tried to start applying that to non-growing adults, it gets a lot more vague

***So it’s important to recognize that what we think about protein requirements is developed from nitrogen balance, where you measure all of the nitrogen you’re eating (which you can do pretty well), but then you have to measure all of the nitrogen you’re losing (which we’re really bad at), and we call that nitrogen balance***

**How nitrogen balance is calculated in a human**

- Start with the **front end**, how much nitrogen is eaten in food
- You take a bunch of food and do a chemical analysis to measure the nitrogen and then multiply by a factor of 6.25
  - This is an assumption that any protein contains 16% nitrogen (which isn’t always true)
- You’re measuring nitrogen not really protein
  - Nitrogen is also in nucleic acids
- You’re measuring nitrogen in anything and calling it protein
- So there is some error on the front end
- On the **back end**, we are going to try and measure losses
- The primary loss of nitrogen in the body is into urine as urea
  - So that’s pretty easy to measure, you can collect that
- Second would be the stool
- There are also things like sweat, skin loss, hair loss, and respiratory nitrogen ammonia in the breath
  - And those are all incredibly vague

> “*Everyone who knows nitrogen balance says that nitrogen balance underestimates requirement*”‒ Don Layman

- The RDA comes from short-term studies and what you find for most people
  - These studies were done with college-age students, right at the end of their growth
  - They are short, 7-day studies
- Don points out, “*Those of us who study protein have gone beyond that and said, well, nitrogen balance is one outcome, but like the vitamin C argument, there are other outcomes based on amino acid metabolism that may be more important than minimum nitrogen balance*”

**Don’s summary**: “*We now know that protein handling (the efficiency) goes down as we get older.* ***So now we have much higher requirements that most of us talk about for adults****.*”

**Peter’s takeaway**: The reason we all agree that standard nitrogen balance underestimates the requirement is, it’s easier to measure the sum of the ins than the sum of the outs

- Don adds, “*Chances are you’re significantly underestimating the outs*”
- Peter recalls as a surgical resident, times where they did a nitrogen balance on patients who were on long term [TPN (total parenteral nutrition)](https://en.wikipedia.org/wiki/Parenteral_nutrition) in the ICU
  - They had to be fed all of their nutrition through a central line, a very complicated feeding
  - The nutrition team would come in for a consult and do a nitrogen balance
  - They literally put a tent over the patient to create a laboratory environment to calculate nitrogen balance
  - This is very important for a critically ill patient that is in a hyper-catabolic state
  - If you’re trying to create an [anabolic](https://en.wikipedia.org/wiki/Anabolism) state in that person to keep them alive, it’s imperative that you understand how much nitrogen they have or how much nitrogen that they require
  - So the simple idea of “*I’m just going to tell you how much protein you’re eating and I’m going to measure the nitrogen that’s coming out in your urea*,” that’s just not going to cut it
- Don agrees, that’s just too simple
- Currently, a lot of those studies are simply done with a factor
  - They don’t put them in a tent or whatever, they just measure urea in urine and everything else is just sort of 1.3

***So obviously we’re perpetuating an error based on ignorance***

**How do you use isotopes to determine what’s happening with the nitrogen?**

- For the  listener who might be lost as to why we’re talking about nitrogen, proteins/ amino acids have nitrogen while carbs and fats don’t
  - So this is where we can really speak to the source of the nitrogen
  - Additionally, as we mentioned, anything with a nucleic acid is going to have nitrogen as well
  - But the majority of nitrogen comes from proteins in food
- Carbs and fats are energy sources, they have carbon-carbon bonds that provide energy whereas amino acids have a very different purpose and structure
  - That nitrogen is part of what makes amino acids different

**Peter’s takeaway**:

- We consume carbohydrates virtually exclusively for their energy content
- Fat, mostly for its energy content
  - There is some structural importance that comes with fat and cholesterol
- In contrast, you don’t want to be consuming protein for energy
- Don adds a caveat, “*There might be reasons that people are hypersensitive to carbohydrates where taking in more protein (beyond what you might actually need for protein metabolism) might be a substitution for carb calories*”

## Protein sources: determining quality, absorption rates, and how to track intake [41:15]

**How many of the 20 amino acids are in steak?**

- If you’re looking at animal source proteins, whether it’s meat or eggs or milk, basically all of the amino acids that a human would need are in those
- In meat, all the amino acids are in the right balance
  - We have basically the same amino acids, the same protein
- But every protein has a little different balance of essential amino acids

**Dairy proteins**

- Dairy proteins are something we can fractionate because they’re all water soluble
- So we know a lot about [alpha-lactalbumin](https://en.wikipedia.org/wiki/Alpha-lactalbumin) versus [lactoferrin](https://en.wikipedia.org/wiki/Lactoferrin) and [lactoglobulin](https://en.wikipedia.org/wiki/Beta-lactoglobulin) etc.
  - We know that a lot of differences about amino acid compositions of individual proteins

**Animal protein**

- We typically think of meat as
  - 1 – Mammals, beef, pig, stuff like that
  - 2 – Bird protein, mostly chicken
  - 3 – Fish protein
- And then you have eggs and dairy
- The first 3 are exactly the same for a protein, “*So whether it comes from a cow or a pig or a chicken or a fish muscle, protein is still muscle protein*”

**How do we think objectively about the quality of a protein?**

*Isn’t there an efficiency of that protein versus tofu versus soybean versus price all the way down to lower and lower protein density foods?*

- Protein quality is something Don thinks about a lot
- He’s working with a group now to reinvent how we think about that
- What he thinks Peter is referring to is protein quality in a sense of [PDCAAS or DIAAS](https://en.wikipedia.org/wiki/Digestible_Indispensable_Amino_Acid_Score) (protein digestibility corrected amino acid score or digestible indispensable amino acid score)
- We realize that when you look at a protein, there are **2 factors that go into a protein quality score**
  - 1 – What’s the composition of those 9 essential amino acids?
  - 2 – What’s its bioavailability?  (how well do we digest it and absorb it)

***With animal proteins and most isolated proteins, even soy protein isolates, the digestion and absorption is pretty close to 100%***

- Digestion and absorption is usually 95% or higher for all **animal proteins**
- For **plant proteins** it is less, maybe only 60-70% available because we can’t digest the fiber proteins are attached to
  - You need to realize that in a plant, the protein is there for the purpose of the plant, and it is attached to fibers
  - Fibers are structures, plants have proteins attached to the leaves and the stems and the roots and the flowers and the seeds
  - When you eat plants in a raw form, only 60-70% of the protein is available because we can’t digest the fiber
- We can determine that a [whey protein](https://en.wikipedia.org/wiki/Whey_protein) isolate is 20% better than a [soy protein](https://en.wikipedia.org/wiki/Soy_protein) isolate on the basis of its essential amino acids
- Or we can compare a wheat protein (wheat bran) and realize that it’s only 40% available
  - Don points out, “*If you look at wheat bran on a cereal box and say it was a wheat flour; and it says there’s 4 grams per serving, there’s actually less than 2 that you can actually absorb*”
- This makes it hard to compare different types of foods and hard to build a meal that way
- We can say whey is better than soy
  - That’s okay if you’re only eating those 2 foods
  - What happens when you start putting them together?

***This is why Don is working with a*** [***group***](https://www.wisecode.ai/) ***trying to build a pretty quality score that is based on 3 amino acids (lysine, methionine, and leucine), which in his opinion are the key markers for adult health***

**Peter’s takeaway**: “*You could brute force your way through life by looking at every single thing you eat and trying to figure out the DIAAS score for its protein. Okay. I’m about to have a rib eye; that’s going to be about a 96% DIAAS. I’m going to have my soybeans over here; that’s about an 80% DIAAS. I’m going to have my whey isolate; that’s 100% DIAAS. I’m going to have my shredded wheat; that’s a 40% DIAAS. That’s a tough way to go through life because you can’t just add up the protein*.”

- Don agrees, they’re not truly additive
- You can’t really figure that out
- The average person doesn’t even have that data
- If you go into the USDA database with 7,000 foods, there are 4,000 that actually have amino acid scores
  - And of those, there’s probably less than 300 that have DIAAS scores
  - And so you can’t put it together

**Moving forward to allow better tracking of protein**

- This is why Don is working to develop a system that allows people to get better at tracking protein
- If you look on a label on a package and you see again, a wheat cereal that says it has 4 grams of protein
  - That’s a nitrogen analysis times 6.25, remember all the problems discussed
  - And then if you look over at another column, it’ll say daily values, almost no label has daily values for protein, because that would require a [PDCAAS or DIAAS score](https://en.wikipedia.org/wiki/Digestible_Indispensable_Amino_Acid_Score), and nobody has them

***So that 4 grams [of protein in wheat cereal}really would translate into less than 2, but nobody’s being told that***

**DIAAS is the digestible indispensable amino acid score**

- A lot of people are focused on digestibility
- Don has a big problem with the amino acid scores because they’re incredibly low
  - They’re established by the [World Health Organization and FAO](https://apps.who.int/iris/handle/10665/43411)
  - They are really designed to prevent malnutrition in Africa where we know from our Institute of Medicine, that the essential amino acid scores should be much higher than that
- We mentioned stable isotopes a little bit ago
- We know from stable isotope studies show that all those FAO amino acid scores are too low
- And so that’s part of the equation that we’re not telling people

## Leucine, lysine, and methionine: three important essential amino acids [48:00]

**Peter’s takeaway**: “*What you’re offering is an alternative to people living in spreadsheets to calculate how much actionable indispensable amino acid they’re getting is.  What if we make this easier? And you focus on the actual content of three amino acids. So we’re going to take a subset of essential amino acids.*” **Leucine, lysine, and methionine (3 of 9 essential amino acids)**

![](https://peterattiamd.com/wp-content/uploads/2022/09/f8-donlayman.png)

**Figure 8.  Leucine, lysine, and methionine.**  Image credit: [OpenStax Biology 2e](https://openstax.org/books/biology-2e/pages/3-4-proteins)

***If you make sure you get enough of those (leucine, lysine, and methionine) with each meal, the rest will take care of itself***

![](https://peterattiamd.com/wp-content/uploads/2022/09/f9-donlayman.png)

**Figure 9.  Essential amino acids for humans that must be obtained in the diet.**

- The current amino acid scores (DIAAS) are too low
- Secondly, they’re not scoring apples to apples; they’re scoring apples and oranges
- For example, if you look at the soy deficiency, all legumes like soy or pea are deficient in methionine
- If you score that against whey, the limited amino acid in whey is histidine
  - No one has ever shown histidine to be a limiting amino acid in an adult, it is a limiting amino acid in children and babies
  - So this is like comparing apples to oranges; it’s not fair
- If you compare methionine to methionine, it’s not 20% higher, it’s 250% better when comparing soy to whey

***Comparing across these 3 essential amino acids allows for an apples-to-apples comparison***

- These 3 essential amino acids (**leucine, lysine, and methionine**) are actually likely to be limiting where no one has ever shown histidine or phenylalanine to be limiting in an adult
  - So why do we consider them limiting?

**Leucine turns on mTOR**

- Listeners of this podcast are no stranger to leucine because we’ve had [David Sabatini](https://peterattiamd.com/davidsabatini/) and [Matt Kaeberlein](https://peterattiamd.com/mattkaeberlein3/) on and they have gone deep into the weeds on [mTOR](https://en.wikipedia.org/wiki/MTOR)
  - One of David’s postdocs [discovered](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4698017/) the leucine sensor on mTOR
  - Now we know unambiguously that leucine is an amazing trigger for mTOR
- People listening may be confused‒ if rapamycin is good and rapamycin inhibits mTOR, how can leucine be good if leucine turns it on?
  - The difference is chronic activation
  - Sometimes you want mTOR on, sometimes you want it off
  - *When we’re talking about eating, you want to be able to turn on mTOR for muscle protein synthesis*

**How this relates to how often you eat**

- There is the issue of mTOR and whether it needs to cycle on and off
  - Not only does leucine turn it on, but so does insulin (probably the worst-case scenario)
- ***People who eat a lot of small carbohydrate meals continuously activate mTOR***
  - A lot of animal studies back this up
- ***What you want is to use specific meals with the right amount of insulin to active muscle-centric mTOR***
- mTOR is in every tissue
- You don’t want to continuously activate mTOR in the liver or some other tissue
  - This is where confusion arises
  - ***People ignore the fact that insulin is the biggest trigger in other tissues where leucine a very unique trigger in muscle***

**Practical applications of tracking leucine, lysine, and methionine**

- We know why leucine matters

*Why would raising the level of methionine and lysine to the level of leucine become a great proxy for overall protein load?*

- If you look at limiting amino acids in food, **lysine** is always limiting in grains
  - That’s a major consideration in determining the minimum amount to feed animals
- Lysine is probably limiting for protein synthesis
- Lysine is in carnitine and some other things, but it’s mostly needed for protein synthesis

***We need 3.4 grams of lysine per day***

***We probably need a little less than 1 gram of methionine per day***

- **Methionine** is part of what we call the [one-carbon pool](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5353360/#:~:text=One%2Dcarbon%20(1C)%20metabolism,epigenetic%20maintenance%2C%20and%20redox%20defense.)
- We need methionine to:
  - Make and repair DNA
  - Make and repair RNA,
  - Make [taurine](https://en.wikipedia.org/wiki/Taurine) (downstream)
  - Make the non-essential amino acid cysteine
  - Make the oxidant [glutathione](https://en.wikipedia.org/wiki/Glutathione)
- Methionine is one of the most limiting amino acids and it’s limiting in all legumes
  - Think of soy, peas, and lentils
  - We think of these as higher quality protein (they are), but they’re still limiting in methionine

**Natural sources of food high in methionine**

- Eggs are quite high in the sulfur amino acids (which are methionine and cystine, see the figure below)
- But all animal products are adequate in them
- And basically all plant products are pretty low in them

![](https://peterattiamd.com/wp-content/uploads/2022/09/f10-donlayman.png)

**Figure 10.  Sulfur amino acids.**  Image credit: [OpenStax Biology 2e](https://openstax.org/books/biology-2e/pages/3-4-proteins)

## The vital role of ruminant animals in the production of quality protein [53:15]

- - Peter asks about animals like cows that are quite muscular but eat basically just hay and grass‒

- *Does this speak to the incredible volume of plants they have to chew to make sure they’re getting enough methionine, lysine, and leucine to be as anabolic as they are and produce so much muscle?*

- - *What volume of total protein in the form of grass and hay do they need to get a sufficient amount of those muscle building amino acids?*
- Don replies that this brings us into a **sustainability** argument
- Cattle ruminant animals are a very important part of the food chain
- Their stomach is full of bacteria, and ***the only place essential amino acids come from in life is bacteria***
- Our primary source of essential amino acids in nature is bacteria on the roots of plants
  - So bacteria on the roots will take in nitrogen and make all amino acids
  - This is why we fertilize our garden with nitrogen
  - Bacteria will take that inorganic nitrogen and form organic means that can be made into proteins in the plants
- The problem with plants is that they don’t have the same balance as we need
- Don points out, “*The beauty of a ruminant is they can take a plant and they can digest it, and the bacteria will then rebalance all of the amino acids, they’ll capture inorganic nitrogen, and they make the essential amino acids that mammals need and they concentrate it for us*”

**Teleological perspective**

- One argument is humans evolved by being able to use more concentrated protein
  - If we just ate plants, it’s hard to get enough essential amino acids
  - But if the ruminant an animal can actually digest all of that and form it into appropriate amino acids….
  - So basically for every 60 grams of plant-based protein the animal eats, they’ll make 100 grams of essential amino acid balanced protein
    - This is why ruminants are called **upcyclers**

***Whether it’s in dairy or meat (cow, goat, sheep, deer), all ruminant animals upcycle by eating grasses and produce great quality protein***

- And no other animal can do this
- Peter asks, “*The bacteria are obviously the engine of that upcycle, but you can’t make nitrogen out of nothing. So you’re saying…?*”
- They’re making protein out of nitrogen; they’re getting inorganic nitrogen from plants
  - Ruminants are able to increase the value of non-amino acid nitrogen, plus they capture the nitrogen in protein form
- Peter has never heard of this phenomenon and asks, “*Are they also disproportionately creating amino acids that weren’t necessarily there in the plant?*”
- That is exactly what is happening
- Bacteria/ flora in the cow will produce methionine or lysine
  - They can basically take glycine (a non-essential amino acid) and make it into any amino acid
- One supplement you actually feed cows is **urea** and they can make it into methionine or leucine or lysine
- Humans excrete nitrogen waste as urea in the urine
- Peter finds this fascinating and notes, “*Now we’re venturing from nutrition into religion, because there’s certainly a group of people who would argue that we should not be eating any animal protein whatsoever…  A counterargument to that would be, it’s awfully difficult without these animals to get adequate amino acids.*”
- Don thinks of it as a biochemist and someone who grew up on a farm where they raised cattle, pigs, corn, and soybeans
  - He sees it as a life cycle type of thing
- There’s no question that ruminant animals play a very important role in our food system, and one, we can’t really replace
- Don adds, “*We can’t just idle millions of acres of grassland and pretend that we can grow avocados on them or broccoli. Cattle basically spend a year of their life on basically nothing but grass. Sheep, and goats are the same, but those are amazing contributions to our food system.*”
- Peter was completely unaware of this capacity to concentrate and almost up-produce both in quantity and quality of amino acid
  - That’s a very interesting finding
  - He didn’t appreciate the role of bacteria

## The differing needs and impacts of dietary protein for a 16-year old compared to a 65-year old [59:30]

**What do we know about the assimilation of amino acids into new muscle tissue across people of different ages?**

- Don mentioned differences in the efficiency of muscle protein synthesis between 20-year olds and 60-year olds
- Peter asks, “*What do we know about a 20 year old versus a 60 year old who puts their muscle under a progressive overload? They’re doing resistance training. They’re being provided with adequate amino acids, and let’s assume they’re being provided with not just the right quantity but the right quality of amino acids.*”
- Don begins with the need for **protein turnover**, “*It’s important to recognize that whether you’re 16 or 65, your body needs to make nearly 300 grams of new protein per day*”
  - Every tissue in the body is turning over
  - Some as fast as liver enzymes, where you replace every hour
  - For muscle proteins the half-lives is around 15 to 16 days
  - Every 30 days collagen turns over at about half-life of a hundred days
    - Which is why if you hurt your knee, it takes so long to repair it
  - But basically the body replaces literally every protein in it, about 4 times a year, that’s a pretty remarkable number
- We have to make 300 grams of new protein per day, but the average American intake is around 80 grams or less (for women it’s 70 and for men it’s 90)
- This means **recycling** is going on
- For every new protein that’s getting made in the body about 6 out of 7 amino acids are getting recycled
- This feeds into the process of protein synthesis and protein turnover
- In Don’s master’s degree he was studying age-related changes in protein synthesis

***We now know that as you get older, the efficiency of protein turnover goes down***

- If you give a 16-year old a certain amount of protein they will have a very good response
- A 65-year old may have 10% of that response or no response at all

**Don’s summary**:

- We have learned, with the study of leucine and initiation factors and all of that, that ***if you leucinegive an enriched source of essential amino acids, you can actually make the adult look just like the 16 year old***
- So what we know is that the efficiency goes down, but the capacity to respond doesn’t
- Current thought in the field is that if you have a dietary protein requirement that’s about twice the minimum RDA (2 x 0.8 = ***1.6 gram per kg***), you can get the 65-year old to respond the same as the 20-year old in terms of muscle protein synthesis
- Peter recalls the earlier discussion of how it’s a slippery slope if you just focus on total protein

**If a person says, “*****I’m 65 years old and I’m on a plant-based diet*****,” does their protein intake need to be higher?**

- Don says this point is exactly right
- We know is that most people who go to a plant-based diet, a vegetarian diet, decrease both the quantity and the quality

***If you’re on a plant-based diet you’ll need more protein, and that means you’ll have to have more calories***

- What is the threshold?
- If you have 100, 120 grams of protein per day, the distribution between animal and plant  probably doesn’t matter, because you probably have enough to cover it
- But, if you’re only eating 50 grams of protein per day then it makes a big difference, you’ll never catch up to your essential amino acid needs

***A good target is somewhere between 50 and 120 grams of protein, it depends on what you choose***

- If you’re going to be plant-based, have 125 grams of protein per day and you’re probably fine
- But you’re going to get in trouble if you’re going to be vegetarian and you think you’re going to get along with 56 grams per day

**Differences in muscle protein synthesis in a 16-year old compared to a 65-year old**

*What can explain differences in* [*anabolic*](https://en.wikipedia.org/wiki/Anabolism) *resistance as we age?*

- Thinking about the difference between the 65-year old and the 16-year old, there’s a huge difference in androgen level between those 2
- Peter finds it very interesting you can overcome anabolic resistance by eating a higher amount of protein

*What else explains anabolic resistance?*

- 1st and foremost are **hormones**
- When you’re growing, hormones are your friend; they are driving it
- If you look at malnutrition in Africa, children will grow on really lousy diets
  - They may not grow as healthy, they may not live as long, but there’s a survival/ reproduction nature to that
- Now consider healthy aging and the criteria are different
  - Don wants to live as long as his parents (near the century mark)

Let’s think about **mTOR** in that framework

- There are 4 different signals that regulate mTOR
  - 1 – We’ve mentioned leucine
  - 2 – We’ve mentioned insulin
  - 3 – An enzyme factor known as [AMP kinase](https://en.wikipedia.org/wiki/AMP-activated_protein_kinase), which is energy sensitive
  - 4 – Another molecule known as [REDD1](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1168803/), which is stress sensitive, particularly to resistance exercise
  - So these are 4 different things the individual balances
- Hormones that are dominant to drive growth when you’re young are [insulin](https://en.wikipedia.org/wiki/Insulin) and [IGF-1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1)
- Insulin is a growth hormone
  - When you stop growing at 25, it ceases to have an effect on protein synthesis and muscle
  - So now the whole thing shifts to protein quality
- Protein quality is not nearly as important when the system’s dominated by hormones
- As we get older, we can buffer that loss of the hormones by higher quality protein, mostly **leucine**, and **resistance exercise**
  - That’s the way you have to think about the change in efficiency that occurs with aging

## Consequences of protein deficiency in childhood [1:06:30]

- When Don got interested in studying protein, he learned from the godfathers in the field‒  [John Waterlow](https://en.wikipedia.org/wiki/John_Waterlow), [Joe Millward](https://www.nutritionsociety.org/people/professor-d-joe-millward), [Peter Garlick](https://www.researchgate.net/scientific-contributions/P-J-Garlick-38602216), and [Vernon Young](https://en.wikipedia.org/wiki/Vernon_R._Young)
- He got involved with some international malnutrition with a US International Agency for International Development (USAID) project in Morocco
  - The led to animal studies to look at malnutrition and recovery
- He found that malnutrition/ starvation insults early in life would stunt muscle development
  - It limited DNA development and cellular development
  - It stunted lean mass in children and in animals

***When this happened, the individual as an adult was always predestined to have low lean body mass and high body fat (obesity)***

> “*That was really the origins of how we started thinking about muscle-centric health*”‒ Don Layman

- If the muscle didn’t develop right, if it wasn’t metabolically correct, you were predestined to develop other things
- Don and [Dr. Gabrielle Lyon](https://drgabriellelyon.com/about/) put this concept together in **muscle-centric health**

**What is the mechanism behind this phenomenon?**

- When you look at children in places like Africa, who are really malnourished, at first glance you think, “*Why are their bellies so big if they’re malnourished?*”
- This is due to extreme [kwashiorkor](https://en.wikipedia.org/wiki/Kwashiorkor)‒ edema and enlarged liver caused by severe protein malnutrition
- Childhood malnutrition causes 2 things
- 1 – [Marasmus](https://en.wikipedia.org/wiki/Marasmus), which affects the skin and bones
- 2 – [Kwashiorkor](https://en.wikipedia.org/wiki/Kwashiorkor), which causes an inflated belly
- Kwashiorkor is disproportionately caused by poor protein in the diet
  - That leads to changes in water balance and edema
  - It appears to be due to an imbalance in the protein to energy relationship
  - The quality of protein is lacking; they eat these starchy porridges that are probably totally deficient in lysine and methionine
- Marasmus is caused by a deficiency in total calories (protein and everything)

**What is it about this critical window of development, where this protein deficiency makes it very difficult for them to put on lean mass later in life and creates a propensity for adiposity?**

- Don did some [research](https://pubmed.ncbi.nlm.nih.gov/?term=Layman+DK&sort=pubdate&sort_order=asc) on this back in the late 70s, early 80s
- Muscle is a very unique cell structure
  - Muscle fibers are multinucleated, unlike a liver cell which has a DNA/ one nucleus in each cell
  - Muscle cells have what are called satellite cells around them
  - So as the original fiber begins to develop, the satellite cells will put DNA (these nuclei) into it
- They [determined](https://pubmed.ncbi.nlm.nih.gov/6199262/) that each DNA has a certain amount of protein it can handle
  - The DNA ultimately determines how big your muscle can get

***They determined if the insult occurs late in pregnancy, early in lactation, you stunt these satellite cells and you don’t develop enough DNA, so the muscle is always limited in its potential size***

- Peter was aware of the propensity for adiposity later but was not aware of the limitation in lean growth
  - This is really a double whammy

**Does this cause lifetime** [**sarcobesity**](https://pubmed.ncbi.nlm.nih.gov/23201324/) **(loss of muscle mass and obesity)?**

- Yes

***This decreases lean mass and decreases metabolically active tissue such that minimal calories will deposit fat***

**Do you think some of this problem is going to happen (to a lesser extent) in developed nations like the US?**

- In the US it would be hard to imagine a child developing kwashiorkor
- But clearly there are kids in the United States that are disadvantaged enough that they’re not going to be exposed to high enough protein in either quality or quantity
- Don thinks it’s possible and worries about the advocacy of plant-based diets
- New York City is taking animal proteins out of school lunch

> “*We’re conducting a public health experiment without actually having any knowledge of that. I think that’s frightening.*”‒ Don Layman

- The issue is public school lunches, nursing homes, daycares
  - These are all under these federal guidelines
- We’re diluting out the quantity and quality of protein at the same time with no knowledge of what that’s really going to mean

## Muscle protein synthesis: ideal timing, small meals vs. big meals, and more [1:12:45]

- One of the challenges Peter has with patients is when they get into a very heavy regimen of **time restricted feeding**
  - The idea is they limit the amount of time they eat but don’t place any limits on what they eat, how much, or what they’re eating from
  - It certainly is an effective way to reduce calories
- Peter has seen in people who adopt a very narrow feeding window (1 meal a day) for 6 months, they disproportionately lose lean tissue
- The diagnosis here is pretty straightforward‒ they clearly reduced energy intake but they probably reduced protein intake too much
- So body composition actually got worse, despite the fact that weight went down

**Can you eat all of your protein in one meal?**

- Hypothetical person‒ is very active, they are going to eat 3000 calories in 1 sitting
- Peter asks, “*Even if I was able to eat 150 grams of protein in one sitting, is it clear that my body will get the benefit from that, that it would if I ate 50 grams three times a day?*”
- Don replies, “*It’s quite clear that you won’t get a benefit, that there is a limit*”

> “*Think about the body as muscle versus everything else*”‒ Don Layman

- There is a lot of data now that muscle can handle protein meals for an optimum anabolic response between 25- maybe 60 grams before you start getting into distribution
- One of Don’s pet peeves in nutrition is when people refer to protein as a % of calories
  - Protein is not a % of calories
  - Protein’s an absolute number
- You need to decide on what you’re going to build your diet around
- Back to the hypothetical person‒ 150 grams of protein

***Protein requirements are an absolute number so if your calories go down, your protein intake should remain the same***

- For example, if 75-year old woman’s calories go down to 1200 calories/day, she still has a 100 gram per day protein requirement
  - So now her protein needs are 35-40% of  her calories
- When people are doing weight loss, it’s important to remember that protein requirements are an absolute number and not a % of their daily calories
- It’s common for people to say the diet should be 30% fat, 50% carbohydrates, and that leaves 15% for proteins
  - *You have to think about protein first*
- As far as distribution of protein, his research shows that “*the most critical meal of the day is the first meal of the day*”

***When you have had an overnight fast your protein synthesis is down and that mTOR signal molecule is down regulated (it’s inhibited), and until you have enough leucine (around 3 g, which translates to about 30 g of protein for most people), your muscle stays*** [***catabolic***](https://en.wikipedia.org/wiki/Catabolism)

- So you’re continually breaking down protein
- Don thinks that’s a significant aspect of aging, that people have lower and lower protein, they don’t eat protein at breakfast
  - And we know the efficiency is going down in the first place

**Don’s recommendations**

- We want to front load protein in the day
- We want at least two meals that are well above 30 g of protein
- He always has people shooting for 40/45 g at the first meal, and another 45 at their last meal
- And then in-between, if we’re talking with people who are…
  - An elderly woman trying to maintain minimal muscle, I’ll concentrate on those 2 meals
  - Somebody who’s trying to lose weight‒ concentrate on 3 meals because he doesn’t want them getting hungry
  - Someone who’s trying to build hypertrophy (be a muscle builder)‒ concentrate on 4 meals
- For the question of, “*How many meals per day do I make anabolic and muscle? And by anabolic, I’m thinking 35 grams or more.*”
  - The data show for absolute certain that the first and last meal are absolutely important
  - Don would be hard-pressed to find a study where anybody’s ever looked at lunch

**The reason an anabolic person needs 4 meals**

- 1 – The leucine effects on mTOR signaling for muscle protein synthesis
- 2 – To get enough total protein per day
- So if you need more protein and max out at 50 g, you need another meal

**What about the timing of protein intake in relation to exercise/ strength training?**

- There is debate about this
- You will find people and trainers who want to eat protein before a workout
- Don did some animal studies on this looking at different timing

***He found that that exhaustive exercise is catabolic no matter what***

- *He finds the benefit is after the exercise, not before*
  - When the system is not finely tuned
  - REDD1 is inhibited
  - mTOR is ready to go
- Peter asks, “*Just to be clear, what you’re saying is, look, you can take all those amino acids before but it’s not going to prevent you from becoming catabolic during exercise?*”
  - Yes
  - Because exhaustive exercise is a [catabolic](https://en.wikipedia.org/wiki/Catabolism) activity, so you are going to be breaking down muscle no matter how many amino acids are on board while lifting

***It’s more important after the lift, that you have a good meal***

- Don notes that you’ll find disagreement with that in the literature
- But he strongly believes this and his research supports this

## Protein needs of children [1:19:45]

- Funny story, when Don’s youngest son was 3, for whatever reason he was fixated on protein
  - Probably because they kept telling him to eat this and that because there was protein in it, “*Hey, eat your salmon. It’s got protein*.”
  - He became the protein police of the preschool
  - He would walk around and look at kids’ snacks and say, “*That doesn’t have protein. That granola bar does not have protein…. That has protein*.”
  - The people who worked at the preschool asked  his wife if she was a nutritionist
  - So now they joke about how he’s going to be one of these bro protein guys who’s obsessed with protein

- Don doesn’t want everybody to walk away thinking they need to get 50 g of protein into their kid

***Children will be very efficient at maintaining growth with small snacks of eight to 10 grams of protein, where that will have virtually no impact for an older adult***

- So a protein bar that had 10 g of protein is a perfectly legitimate snack for a child
  - Where essentially the only thing it would do is probably increase liver enzymes in a 70 year old
  - Don doesn’t want all the mothers think they’re doing a bad thing by giving their child a 10 g protein snack

**Differences in protein requirements for children and adults and when that protein is consumed**

- In the adult, say they eat 100 g of protein in a day but take it in very small meals
  - 15 g trickled in all day long
  - This will never stimulate muscle protein synthesis
  - But their liver will be perfectly fine
  - Your gut, liver, heart, kidneys, will all respond to the net protein per day, no matter *when* you ate it
- Muscle is different, it is specific

***Muscle isn’t triggered unless the diet is exactly right***

- The muscle senses energy, insulin, and protein before it triggers
  - And if all of those aren’t balanced it won’t trigger, but your liver will
- Peter notes, “*Teleologically you might make the case that the liver has more concern for the brain than the skeletal muscle, and maybe it gets priority over being happy because it has to maintain glucose homeostasis.  And without glucose homeostasis the brain would literally die within 20 minutes*.”
- Don agrees, “*Your liver, your heart, those have to function. In the middle of the night, your liver still has to be making protein, but your muscle doesn’t.*”
  - While you’re laying there in bed, your muscle is catabolic and it’s supplying amino acids so all those other organs work
- So while Don will argue about muscle-centric health, the reality is, moment to moment, it’s organ-based

***But long-term, your overall health is determined on keeping the muscle healthy because it keeps everything else healthy***

**Is the reason that it’s okay for kids to be eating much smaller amounts of protein, is it simply just the mass?**

- Peter’s youngest weighs 25 kg
  - He probably doesn’t need more than 40 g of protein a day
  - For him to have a 10 g serving, this is 25% of his protein
  - For Peter 25% of his daily protein is 40 g
- Don points out that for children, their protein synthesis is driven by hormones
  - This is not true for adults

***Growth in children is highly efficient, it’s driven by hormones, and children will accommodate protein in small doses***

## How important is timing protein intake around training? [1:24:15]

**What is the window in time, post workout, in which you want to make sure you’re getting that first big meal of protein?**

- Don first did this experiment in rats
- [Josh Anthony](https://www.nutritioncapital.com/principals-and-selection-committee/joshua-anthony/) and [Tracy Anthony](https://nutrition.rutgers.edu/faculty/tracy-anthony.html) were in his lab just before [Layne Norton](https://biolayne.com/coaching/coach/layne-norton/) came in
- They were looking at exhaustive exercise in rodents and catabolic state
  - They wanted to know how the muscle regulated recovery
  - They were looking at what we called [initiation factors](https://en.wikipedia.org/wiki/Eukaryotic_initiation_factor) (for initiation of protein synthesis, aka [translation](https://en.wikipedia.org/wiki/Translation_(biology)))
  - They [discovered](https://pubmed.ncbi.nlm.nih.gov/10720160/) a link between leucine and initiation factor eIF4
  - That is a downstream effect of mTOR
    - mTOR is the regulator and it stimulates eIF4, S6, and other initiation factors
- They found that when you come out of an exhaustive exercise, muscle is catabolic until you take in enough leucine to reverse it.
- They started looking at feeding right after exercise
  - A lot of people picked up on that‒ [Stu Phillips](https://www.science.mcmaster.ca/kinesiology/component/comprofiler/userprofile/phillis.html), [Doug Paddon-Jones](https://www.linkedin.com/in/douglas-paddon-jones-099492a6), and others

**What are the caveats?**

- There is a **2 hour window right after exercise** where you can see the biggest effect of feeding, but this is in **untrained individuals**
- If you look longer, you can have a bout of resistance exercise and you’ll detect a difference
  - You’ll start regulating that [REDD1](https://en.wikipedia.org/wiki/DDIT4) protein factor
  - You’ll see an anabolic effect the next day (24 hours, 36 hours later)

***The more trained you get, the less you’re going to see a post-exercise effect***

**Don’s summary**:

- If you’re **beginning training** and you’re in the first 4 weeks, post-exercise protein probably makes sense
- If you’re **well trained**, you’re basically training the same way and you’ve been doing it for 6 months, Don doesn’t see any effect difference between having protein within 2 hours after exercise versus just having your 3-4 four meals per day
  - You won’t see any difference in either mass or strength
- Peter remembers having this discussion with Layne and being pleasantly surprised to learn‒ once you get to a point where you’re well trained enough, you don’t have to be so maniacal about meal timing
  - You can just focus on the **big picture**, which is: total protein, protein quality, and spreading it out such that you don’t exceed the metabolizable fraction of it at any one sitting
  - Don agrees

**How much protein can muscle use at any one sitting?**

- Don hears trainers take that last statement about metabolizable energy and say “*Well, you can’t use more than 30 grams at a meal. You won’t digest it.*”
  - That’s not true

***You’ll digest and absorb 100 grams of protein at a meal. But muscle in particular only has a window of around 25 to 60 grams (depending on protein quality) that it can use. The liver will use all of it.***

- We have what is known as **first pass metabolism of protein** (which confuses the issue even more)
  - When you eat a meal of protein, approximately 50% of the protein is degraded to nitrogen and carbon before it ever gets to the blood
  - The exception to that are the [branch chain amino acids](https://en.wikipedia.org/wiki/Branched-chain_amino_acid): leucine, isoleucine, valine, where almost 75 to 80% of those get into the blood
- Now we’re back to the teleological argument, “*Why did muscle learn to sense that?*”
  - Because that basically shows up in the blood in direct proportion to the meal and the muscle learned to sense that as a **meal quality**
  - This is a signal that a meal has adequate quality for muscle to trigger the very expensive process of protein synthesis, protein turnover
    - And until muscle sees that signal, it won’t do it

## The role of leucine in fatty acid oxidation by muscle [1:28:15]

- The other thing Peter has learned recently that surprised him is the importance of leucine in fatty acid oxidation by the muscle
- One of the pillars of his practice is low-end aerobic training ([zone 2](https://peterattiamd.com/?s=zone+2))
  - This is important for mitochondrial efficiency
  - This is basically pushing your muscles to their maximum point at which you can keep lactate below 2 mmol
  - A very fit individual can generate a lot of power while still keeping lactate below 2 mmol
  - The best in the world can produce more than 4 watts per kilo while still keeping lactate below 2 mmol, and they’re doing so virtually exclusively with fatty acid
- Peter will pair this type of analysis with [CPET (cardiopulmonary exercise test)](https://en.wikipedia.org/wiki/Cardiac_stress_test) testing, and will look at fat oxidation rates
  - Again, you will see the fittest of the fit have insanely high fat oxidation rates, they’re roughly 1 gram per minute
- The point being, a really good muscle doesn’t just rely on glucose
- A really good muscle can oxidize fats very effectively

*What role does leucine play in that?*

- That’s a great question, one that Don doesn’t think has been researched enough
- Every amino acid has a different side chain, and leucine is one referred to as a [branch chain amino acid](https://en.wikipedia.org/wiki/Branched-chain_amino_acid)
  - The side chain of leucine is purely carbons, it looks a lot like a fatty acid (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/09/f11-donlayman.png)

**Figure 11.  Leucine and a fatty acid.**  Image credit: [OpenStax Biology 2e](https://openstax.org/books/biology-2e/pages/3-4-proteins)

- Leucine is one of 2 amino acids that are **ketogenic**, it’s metabolized as a fatty acid
- Leucine will also activate the [CPT1 enzyme (carnitine palmitoyltransferase enzyme)](https://en.wikipedia.org/wiki/Carnitine_palmitoyltransferase_I), which is the link for bringing fatty acids into the mitochondria for oxidation
  - So there’s a benefit there
- It gets even more complicated, in that when you have higher leucine‒  it begins to inhibit pyruvate from going into the mitochondria
- So when you oxidize a leucine, the nitrogen that comes off of it is put onto pyruvate, generating alanine, and so the body begins to recycle glucose
  - It becomes steady state on glucose and emphasizes fat oxidation
- If you overload all of that, you can make leucine inhibit carbohydrate oxidation
  - So if you have huge amounts of carbs coming in, and then you overload the system with leucine, and you’ll inhibit pyruvate oxidation
  - So that could look like insulin resistance
- But if you look at the physiology of how it’s supposed to work, under conditions where you’d be burning fat, leucine actually stimulates fat oxidation and spares glucose for the brain and other tissues
- So again, you really have to think about how the experiment’s set up, what’s getting inhibited and what’s getting pushed?

## High protein diets for fat loss: Results from Don’s clinical trials [1:31:30]

**Peter thinks of 3 strategies to approach weight loss**

- 1 – Reduce calories, pay attention to the total energy content of food without thinking about the timing of food or macro distribution of food
- 2 – Focus on macronutrients, spend less time thinking about the total number of calories and avoid certain foods
  - Create a boogeyman in the diet
  - The restriction of certain things becomes a roundabout way to restrict total energy
- 3 – Time restricted feeding ([intermittent fasting](https://en.wikipedia.org/wiki/Intermittent_fasting))

**How does Don think about manipulating #2, changing macros to achieve energy deficit?**

- Don agrees, weight management is a calorie issue
- It’s not the same for every individual, everybody’s got a little different efficiency
- So you can’t be an accountant and expect to just count calories all the time
- A bit of history starting in the late ’90s…
  - [Atkins](https://en.wikipedia.org/wiki/Atkins_diet) and the [keto diet](https://en.wikipedia.org/wiki/Ketogenic_diet) were out there
  - [Barry Sears](https://en.wikipedia.org/wiki/Barry_Sears) and the [Zone diet](https://en.wikipedia.org/wiki/Zone_diet)
  - [Michael Eades](https://denversdietdoctor.com/about-mike-eades-md/) and the [Protein Power](https://en.wikipedia.org/wiki/Protein_Power)
  - Don was looking at all of these things and doing leucine experiments
- Don discovered this effect of leucine on muscle protein turnover and some of these metabolic things with fat metabolism
- He basically took the leap of faith and said, “*I think the underpinning of all of these diets is really the* ***protein carb ratio*** *and how can we manipulate that?*”
- He started thinking about creating a diet from a satiety standpoint
  - Protein is probably the most satiating
  - Fat would be next
  - Carbohydrate the least
    - They were concerned about big insulin swings
    - They wanted to balance out our carbs per meal
    - They know that if people are overweight, they tend to have big post meal carbohydrate and insulin swings where 2 hours later, they’ll have carbohydrate lows
- He began to think that the first meal after an overnight fast is critical
- He asked, “*How much protein do you need?*”
  - 30, 40 grams of protein to get both satiety, protein synthesis effects
  - They knew that protein had a higher thermogenic effect (burns more calories) than either carb or fat and they wanted to front-load that effect
- People argue that because of the nitrogen, protein is harder to digest and absorb, but he didn’t think that was true
- They thought the thermogenic effect is stimulating muscle protein synthesis, that is a massive ATP expenditure
  - They wanted to maximize that at every meal

***For the 1st meal they wanted 40 grams of protein, and they wanted to have a carb level that would not overstimulate insulin***

- So they kept the carbohydrates under 30 grams
  - This created a **carbohydrate threshold concept**
  - They could use fat to round out the calories

**Human clinical trials**

- They increased protein intake to about 1.6 g/kg and ran a study comparing it to the food guide pyramid recommendation of 0.8 g/kg
- They did 3 studies
  - 1 – A total feeding study where they fed everyone in the lab
    - 2 arms of the study were (1) high carb/ low protein and (2) low carb/ higher protein
    - Published in 2 papers, one about [body composition and lipid profiles](https://pubmed.ncbi.nlm.nih.gov/12566476/) and the second about [glucose and insulin homeostasis](https://pubmed.ncbi.nlm.nih.gov/12566475/)
  - 2 – A [study](https://pubmed.ncbi.nlm.nih.gov/16046715/) with diet and exercise for 4 months
    - They provided participants meals for the 1st 2 weeks
    - A 2×2 design of diet treatment and resistance exercise treatment
  - 3 – A [multi-centered study](https://pubmed.ncbi.nlm.nih.gov/19158228/) with 120 subjects for 16 months
    - Free living studies where participants provided their own food following diets and manuals provided
    - Diet with a generic recommendation for exercise comparing high carbohydrate:protein ratio diet to a low carbohydrate:protein ratio diet
- **Results from study #1**
  - With exactly the same calorie intake, the people on the higher protein, low carb diet lost more total weight, more total fat and less lean, and that stabilized their insulin and glycemic regulations and lowered their triglycerides across the board

*What was the difference in weight and fat mass?  Was it all explained by the thermodynamics of the difference in protein?*

- It was close
- They found that the people on the higher protein diet were getting a benefit of around 170 calories a day eating the same calories
  - So that could be about the thermodynamic effect
- Both groups lost weight, they were both on weight loss diets
- But the protein people lost lost around 8 lbs. more and something like 6.5 lbs. of it was fat

*Did the people on the high protein diet complain less of hunger?*

- They did a satiety check using an analog scale to asked them to rate how they felt
- One of the things that the dieticians who were running the study always came back is they said that the protein people were never talking about food and snacks, but the people on the high carb diet were always talking about being hungry and snacking

> “*There’s definitely a different satiety and compliance issue to it*”‒ Don Layman

**Did the results of all 3 studies point in the same direction?**

- Yes, greater weight loss was observed in people on a higher protein diet

**Peter’s takeaway**:

- Stop thinking about protein as a percent of total calories, protein should always be absolute
- Then as you reduce calories, protein should increase the total fraction of calories
- This is going to preserve lean tissue better, maintain satiety better, and plus there’s potentially this bonus of the thermogenic effect of protein
- Don adds that this definitely partitions the weight loss toward fat, protects muscle/ lean tissue, and definitely has higher satiety

**Weight loss in people over 60**

- For a long time there was a lot of debate over whether people over 60 should ever practice weight loss because they would lose too much lean mass (muscle) and they can’t gain it back
  - [Doug Paddon Jones](https://www.linkedin.com/in/douglas-paddon-jones-099492a6) had the theory that sarcopenic aging isn’t a gradual decline
  - Instead it’s a series of acute effects that you injure yourself (you’re in bed; you have a surgery, whatever), you acutely lose lean mass, and you can never gain it back

> “*We want weight loss, but we don’t want people to lose any lean mass, especially if they’re adults*.”‒ Don Layman

- If you are a 20-year old, it probably doesn’t matter so much
- But if you’re older, if you’re beyond 40, it does matter
- Peter reacts, “*It’s a scary thought, Don, if you think about it, right? 40 is not that old.*”
- Peter just had shoulder surgery 5 months ago and he still has not gained back all of the muscle mass
  - Gaining it back has been difficult in comparison to how acutely he lost it
  - In 3 weeks, he was 10 lbs lighter
  - It’s not just from the shoulder, it’s all the things you can’t do when you don’t have an arm
    - You can’t squat, you can’t deadlift, etc.
  - Some of that 10 lbs. was water weight, but 7 lbs. was lean tissue that he lost in 3 weeks
- There is a [bed rest study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3276215/) by [Doug Paddon Jones](https://www.linkedin.com/in/douglas-paddon-jones-099492a6) (who unfortunately passed away this last year) looking at older adults versus younger adults
  - In the same period of time, an older adult in bedrest will lose 4x as much muscle as a younger adult
- It’s frightening how fast you can lose it
  - If you’re diligent and do weight training, you can begin to gain it back
  - But it’s hard to get back to where you were

**How does leucine come into play?**

- It’s not as important for a 20 year old as it is for a 60
- Don thinks it’s a little like bone health‒ once you’re 40, you’re sort of on the back end of that, and you need to be much more careful
- Don did a [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4018950/) with Doug Paddon Jones where they took 90 grams of protein and looked at it distributed as 3 meals per day, 30, 30, 30 versus 10 20 60.
- They found that with the same amount of protein, the same overall diet, you would have higher net protein synthesis with the distribution to **breakfast**
- This was a study of 37 year olds (mean age)
- So they think that by mid thirties, you can detect the distribution effects
- Peter asks, “*Just to be clear, Don, do you think that the reason 30, 30, 30 was better than 10, 20, 60, was because you started the day at 30, or because you had 3 meals where you cleared the hepatic threshold?*”
- That’s a great question, Don thinks they would have been better off studying a protein split of 40, 10, 40

> “*I think the first and last meals are the key*”‒ Don Layman

- They’ve done a number of studies in animals
  - Other people (Mike Rennie and Phil Atherton) have done it in humans
- When you **trigger mTOR at that first meal** (we know that it’s still stimulated five hours later), why do you need leucine for mTOR at lunch if it’s still simulated?
  - You don’t
  - Nobody has actually studied that at this point
- The key here is, “*Now you’re talking total protein per day, not a leucine effect. It’s not a leucine- mTOR effect, there’s not this threshold to it*.”
  - It’s total substrate
- Layne needs 250 grams of protein per day, he’d be better off putting that in 4-5 meals than putting it in 2
- People need to understand that distributing across all the meals is *not* an mTOR effect
  - Distributing it this way is great for weight loss and appetite

## Influence of industry funding on nutrition studies [1:43:45]

**So much of this research that Don has done has been funded by industry**

- A lot of people are going to say, well, we’re going to discount everything

*Who has funded his work over the last 4 decades?*

- In the early 80’s Don had the concept that leucine was going to be key to protein synthesis in muscle
- They ran studies and realized it had initiation effect
- They started looking for the initiation factors and found [eIF4](https://en.wikipedia.org/wiki/Eukaryotic_initiation_factor_4F)
- They submitted proposals to the NIH for 10 years and were continuously turned down
  - The NIH said, “*We only study disease and we don’t know of any deficiencies of protein, so it’s not a priority to us*”
- Don was left with what turned out to be a revolutionary idea of reinventing protein, that NIH wouldn’t fund
- He finally went to Kraft Foods, the National Cattlemen’s Beef Association, the National Dairy Association, American Egg Board, and some of the other groups who were inherently interested in protein
- They got some money from the USBA
- Don was at a land grant university and those were the funding sources that unlocked all of this knowledge about protein for adults, leucine, mTOR, muscle-centric health
  - All of that was unlocked simply because he could get funding from Kraft and Beef
- Is Don biased? Everybody who eats is biased in some way
- If you look at research, he never believes research until he sees it from 3 more labs
- So he doesn’t mind if people look at his research and say, “*I don’t believe it,*” but his research has been out there, very clear theories for 20 years now
  - And every test makes it stronger
  - Everybody who’s ever run the study after me shows the exactly same thing
  - The fact that Kraft or Beef funded, it’s irrelevant
- Don is semi-retired now, retired from the grant cycle

**Does Don see any evidence that the NIH has taken a broader purview of health?**

- Don thinks they have
- [Chris Lynch](https://dpcpsi.nih.gov/onr/staff/christopher-lynch), is the director of nutrition at NIH now
  - That position didn’t exist back in the late 80s to early 90s
  - It sits across multiple institutes, maybe NIDDK and the Cancer Institute
- There was a general philosophy (and still is) at the NIH, that they do not fund applied food research
  - They believe industry should fund it
  - So that becomes a catch 22
- If you’re going to study the difference between whey and soy protein, unless you can say that’s going to cure heart disease, they’re not going to fund it
- So then you  have to go to the dairy council (or whatever) and say, I want to do this study

> “*The alternative is we put our head in the sand, and we don’t do the research*”‒ Don Layman

- When Don looks at people in nutrition right now, he literally doesn’t know anybody in nutrition who doesn’t get industry funding
  - It’s just simply how you have to get funded
- One of the things he would also point out in this whole issue of bias, it’s important to recognize that the animal commodities are all under the USDA supervision and they have checkoff boards
  - So that means everything they say in advertising has to be screened
- Where as the grain industry has big companies like Kelloggs and Pillsbury and Coke and Pepsi,  they can literally go out and say anything they want
- And so you’ll see a product out there that pretends to be an egg and they’ll claim that they’re better than eggs, but egg can’t come back and refute it
- So you’ve got two different playing fields, one that’s highly restricted and supervised and the other, which is fair game, first amendment, I can say anything I want

## Don’s thoughts on plant-based and synthetic “meats” [1:48:45]

**Thoughts on the nutritional/ amino acid composition of plant-based meats**

- There are a whole host of companies trying to make synthetic meat
- From the little Peter has read about it, he has the impression that it will not be technically feasible from the standpoint of energetics, cost mass balance, sanitation, and GMP
- Don thinks as the world continues to expand in population, we’re going to need additional protein sources
- We may be near our capacity for animal-based protein
  - He doesn’t think we can double it again
- He agrees with Peter’s comments about synthetic proteins, “*I don’t think that will ever be economically or environmentally feasible*”
- Popular versions of plant-based Beyond Burgers, etc look like a flash in the pan
- Burger King’s [Impossible Whopper](https://www.bk.com/menu/picker-95eb0a67-9e69-4849-9bc6-6715b3790e9a) had good sales for a few months, but if you track it, it was all people who don’t normally go to Burger King
  - Once people tried it, the never came back
  - The stock has fallen through the bottom now, nobody’s using it
- [Beyond Burger](https://www.beyondmeat.com/en-US/products/the-beyond-burger) is basically a pea protein produced in Canada
  - It’s then shipped to China, processed, and shipped back to the US
  - We know transportation is a #1 cause of greenhouse gas
  - Now it’s been shipped all over and comes back to the US with around 25 ingredients, probably 5-6 are not FDA approved
- They have multiple products containing multiple synthetic components that have never really been studied and are not FDA approved
  - They’re basically relying on safety without ever proving it
- Don thinks plant-based proteins have been around for a long time

**Don’s takeaway**: “*I think that plant-based proteins have been around a long time. I think trying to pretend that it’s meat, calling soy drink milk or almond drink milk. I think those are travesties. I think those are standards of identity. Almond milk has, what, one gram protein per eight ounces where cows milk has eight? Calling that milk is pure deception.*”

- He’s not against using them, but he thinks the consumer should be aware
- For example, if you look at any **wheat cereal** it has 4 grams of protein per serving
  - He always said that’s probably only 2 grams
  - On the label it says, mix it with ¾ of a cup of milk, and now we have 10 grams of protein
  - If you look at the lysine balance of that, it’s exactly balanced
  - But if you go to soy milk, this has only 6 grams of protein per 8-ounce coup instead of 8
    - And it’s deficient in lysine
    - So it takes almost a quart of soy milk to balance that cereal
- If you’re a mother feeding this to your child and thinking, well, I’m doing a plant-based thing and I’m feeding them a totally deficient diet with 6 ounces of soy milk for breakfast
  - How many mothers know that?
- Those are the kinds of things that we think need to come out about protein quality
- We want a system where we can show people an additive value and that at the end of it when they put that meal together
- There’s a company called [WISEcode](https://www.wisecode.ai/) that Don is working with
- They think that they can use QR codes and your phone to  simply add up the quality protein content and can tell what your total meal looks like

**Getting enough protein and enough quality protein in the diet is hard**

- Peter is not sure he hits the total grams of protein he wants each day
- And there’s no attention to how much methionine, leucine, or lysine he’s getting
- Don replies, “*If you’ve got 125 grams of protein in your diet per day, chances are you’ll hit those numbers.  Where leucine is a meal to meal number, lysine is a daily number (it doesn’t matter meal to meal, it’s a total).*”
- Peter notes for many of his female patients, it’s hard to get them up to 120 grams of protein per day
- Don agrees, with his studies he struggles to keep adult females at 100 grams of protein per day
  - Then quality becomes an issue
- This is Don’s concern with the plant-based movement‒ ***do people have the resources to make it healthy?***
  - You can, but you need a lot of knowledge and food skills
  - You’re going to have to eat synthetic products because you can’t get it from eating lentils and rice
    - You just can’t eat enough of them
  - So you’re going to have to have shakes or supplements to get to that level
- The track record says vegetarians end up somewhere in the 60s for their protein per day, and quality does make a difference at that level

## Problems with epidemiological studies of dietary protein [1:56:30]

**What does high protein mean?**

- When you look at the epidemiology, Don thinks the science is bad

***The definition of high protein is about 1.2 g/kg and low protein is actually below 0.8***

- Many will express it as % of calories and they’ll say less than 10%
- When you look at the epidemiology, you need to realize they’re talking about very narrow ranges of protein intake and it really isn’t the protein that’s making a difference, it’s the calories and the other things that are going with it

**Don’s experience as director of research for the American Egg Board**

- For 4 years Don was director of research for the American Egg Board
- He funded all of the research that basically got the cholesterol direction eliminated from our guidelines
- One of the things funded was a lot of research suggesting that eggs had a high correlation with obesity and diabetes and heart disease
- They funded some research with [Theresa Nicklas](https://www.bcm.edu/people-search/theresa-nicklas-27676) and [Vic Fulgoni](https://www.longdom.org/author-profile/victor-l-fulgoni-iii-348826) who were experts in the NHANES data, and they looked at the epidemiology
  - They looked at the difference between the first quartile and the last quartile for egg consumption
  - It was 3-3.5

***So they were basically saying that a half an egg per week was the difference in causing obesity, heart disease and diabetes***

- And so what they did was they went into the NHANES data and they factored out all of the eggs that were eaten at fast food versus the eggs that were just eaten at home in a “good nutrition setting”, and what they found is in every case, eggs now became a positive
  - They reduced obesity
  - So basically it’s not the egg, it’s the egg in the company it keeps
  - You can make anything a bad diet
- Peter adds, “*Anybody who’s tried to actually consume high protein, realizes it ain’t high protein, it’s high calorie that’s the problem*”
  - The protein is along for the ride
  - Because 1.2 g/kg is actually kind of low protein in the context of a high calorie diet
- Don notes that the surveys for protein used in epidemiology are pretty good
  - People can tell you how many eggs they ate yesterday, or ounces of milk, or grams of meat
    - Because we sell those by ounces and weight
- In contrast, most people misreport the number of carbs they ate by 200 grams

> “*The problem with epidemiology is that the errors are not homogeneous*”‒ Don Layman

§

## Selected Links / Related Material

**Episode of** ***The Drive*** **with Layne Norton**: [#205 – Energy balance, nutrition, & building muscle | Layne Norton, Ph.D. (Pt.2)](https://peterattiamd.com/laynenorton2/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (May 2, 2022) | [6:15]

**Episode of** ***The Drive*** **with Gerald (Jerry) Shulman**: [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (December 7, 2020) | [9:45]

**Bob Wolfe’s experiment with stable isotopes examining fatty acid oxidation**: [Glucose and insulin-induced inhibition of fatty acid oxidation: the glucose-fatty acid cycle reversed](https://journals.physiology.org/doi/abs/10.1152/ajpendo.1996.270.4.e733) | *American Journal of Physiology: Endocrinology and Metabolism* (LS Sidossis and RR Wolfe 1996) | [12:15]

**Hellerstein paper showing low level of** ***de novo*** **lipogenesis after carbohydrate feeding**: [Effects of a low-fat, high-carbohydrate diet on VLDL-triglyceride assembly, production, and clearance](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC408572/) | *The Journal of Clinical Investigation* (EJ Parks *et al*. 1999) | [14:00]

**Hirsch study of high carbohydrate diet showed increased fatty acid synthesis**: [Human fatty acid synthesis is stimulated by a eucaloric low fat, high carbohydrate diet](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC507283/) | *The Journal of Clinical Investigation* (LC Hudgins *et al.* 1996) | [15:45]

**Volek study of high carbohydrate diet showed increased fatty acid synthesis**: [Effects of Step-Wise Increases in Dietary Carbohydrate on Circulating Saturated Fatty Acids and Palmitoleic Acid in Adults with Metabolic Syndrome](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4240601/) | *PLoS One* (BM Volk *et al.* 2014) | [16:00]

**Don finds reducing the number of meals per day is thermogenically advantageous (in rats)**: [Effects of prolonged meal-feeding on the body composition of adult rats](https://www.sciencedirect.com/science/article/abs/pii/S0271531784801074) | *Nutrition Research* (BJ Bittman *et al.* 1984) | [17:45]

**Summary of Ancel Key’s seven countries study**: [Seven Countries Study](https://www.epi.umn.edu/cvdepi/study-synopsis/seven-countries-study/) | University of Minnesota: Heart Attack Prevention: A History of Cardiovascular Disease Epidemiology | [18:30]

**Minnesota Coronary Experiment republished by Chris Ramsden**: [Re-evaluation of the traditional diet-heart hypothesis: analysis of recovered data from Minnesota Coronary Experiment](https://www.bmj.com/content/353/bmj.i1246) (1968-73) | *BMJ* (CE Ramsden *et al.* 2016) | [20:45]

**Episode of** ***The Drive*** **with David Sabatini**: [#09 – David Sabatini, M.D., Ph.D.: rapamycin and the discovery of mTOR — the nexus of aging and longevity?](https://peterattiamd.com/davidsabatini/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (August 13, 2018) | [50:00]

**Episode of** ***The Drive*** **where Matt Kaeberlein discusses mTOR**: [#222 ‒ How nutrition impacts longevity](https://peterattiamd.com/mattkaeberlein3/) | Matt Kaeberlein, Ph.D. | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (September 12, 2022) | [50:00]

**Leucine sensor on mTOR**: [Sestrin2 is a leucine sensor for the mTORC1 pathway](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4698017/) | *Science* (RL Wolfson *et al* 2016) | [50:00]

**Link between amount of DNA and muscle development in rat weanlings**: [Cellular growth of skeletal muscle in weanling rats during dietary restrictions](https://pubmed.ncbi.nlm.nih.gov/6199262/) | *Growth* (SR Glore and DK Layman 1983) | [1:10:45]

**Link between leucine and initiation factor eIF4**: [Orally administered leucine stimulates protein synthesis in skeletal muscle of postabsorptive rats in association with increased eIF4F formation](https://pubmed.ncbi.nlm.nih.gov/10720160/) | *Journal of Nutrition* (JC Anthony *et al.* 2000) | [1:25:00]

**Feeding study comparing high carb/ low protein and low carb/ higher protein diets**:

- [A Reduced Ratio of Dietary Carbohydrate to Protein Improves Body Composition and Blood Lipid Profiles during Weight Loss in Adult Women](https://pubmed.ncbi.nlm.nih.gov/12566476/) | *The Journal of Nutrition* (DK Layman *et al.* 2003) | [1:35:15]
- [Increased Dietary Protein Modifies Glucose and Insulin Homeostasis in Adult Women during Weight Loss](https://pubmed.ncbi.nlm.nih.gov/12566475/) | *The Journal of Nutrition* (DK Layman *et al.* 2003) | [1:35:15]

**2×2 study evaluating dietary protein and exercise on weight loss**: [Dietary protein and exercise have additive effects on body composition during weight loss in adult women](https://pubmed.ncbi.nlm.nih.gov/16046715/) | *The Journal of Nutrition* (DK Layman *et al.* 2005) | [1:35:15]

**Multi-center study of low carbohydrate: protein ratio diet to high carbohydrate:protein diet with exercise**: [A moderate-protein diet produces sustained weight loss and long-term changes in body composition and blood lipids in obese adults](https://pubmed.ncbi.nlm.nih.gov/19158228/) | *The Journal of Nutrition* (DK Layman *et al.* 2009) | [1:35:15]

**Bed rest study by Doug Paddon-Jones**: [Protecting muscle mass and function in older adults during bed rest](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3276215/) | *Current Opinion in Clinical Nutrition and Metabolic Care* (KL English and D Paddon-Jones 2010) | [1:40:45]

**Study of protein distribution over 3 meals shows the importance of dietary protein at breakfast for muscle synthesis**: [Dietary Protein Distribution Positively Influences 24-h Muscle Protein Synthesis in Healthy Adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4018950/) | *The Journal of Nutrition* (MM Mamerow *et al.* 2014) | [1:41:30]

**Dietary recommendations for protein and leucine intake (review)**: [Optimizing Adult Protein Intake During Catabolic Health Conditions](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7360447/) | *Advances in Nutrition* (SM Phillips, D Paddon-Jones, and DK Layman 2020)

§

## People Mentioned

- [Layne Norton](https://biolayne.com/coaching/coach/layne-norton/) (professional bodybuilder and physique coach) [2:45, 6:15, 1:24:30, 1:43:15, 1:45:30]
- [Ancel Keys](https://en.wikipedia.org/wiki/Ancel_Keys) (American physiologist who promoted replacing saturated fat with unsaturated fat to reduce cardiovascular disease) [6:00, 18:30]
- [Henry Blackburn](https://directory.sph.umn.edu/bio/sph-a-z/henry-blackburn) (Professor Emeritus, Division of Epidemiology and Community Health at the University of Minnesota School of Public Health) [6:00, 20:00]
- [Ivan Frantz](https://www.bmj.com/content/bmj/suppl/2016/04/12/bmj.i1246.DC1/ramc027623.ww1.pdf) (Expert in nutrition and cardiovascular risk, led the Minnesota Coronary Experiment) [6:15, 20:00, 24:15]
- [Gabrielle Lyon](https://drgabriellelyon.com/about/) (doctor specializing in muscle-centric medicine) [7:31]
- [Gerald (Jerry) Shulman](https://medicine.yale.edu/profile/gerald_shulman/#:~:text=Shulman%20is%20the%20George%20R,the%20Yale%20Diabetes%20Research%20Center.&text=Shulman%20is%20the%20recipient%20of%20the%20Stanley%20J.) (George R. Cowgill Professor of Medicine (Endocrinology) and Professor of Cellular And Molecular Physiology at Yale University and Co-Director of the Yale Diabetes Research Center) [9:45]
- [Robert (Bob) Wolfe](https://aging.uams.edu/dr-robert-r-wolfe/) (Professor at University of Arkansas for Medical Sciences and Director of the Center for Translational Research in Aging and Longevity at the Reynolds Institute on Aging) [12:00]
- [Marc Hellerstein](https://nst.berkeley.edu/users/marc-hellerstein) (Professor of Metabolic Nutrition at UC Berkeley) [14:00]
- [Jules Hirsch](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(15)00112-9/fulltext) (physician-scientist, obesity expert) [16:00]
- [Jeff Volek](https://www.virtahealth.com/people/jeff-volek) (Chief Science Officer and Co-Founder of Verta Health) [16:00]
- [Gil Leveille](https://academic.oup.com/jn/article/150/5/973/5804832) (Biochemist and expert in metabolism) [17:00]
- [Fred Kummerow](https://en.wikipedia.org/wiki/Fred_Kummerow) (biochemist and lipid expert who pioneered the connection between trans fats and heart disease) [20:00]
- [Arlan Richardson](https://medicine.ouhsc.edu/directory/details/arlan-richardson-phd-1) (Don’s Master’s advisor, now Professor of Geriatric Medicine at the University of Oklahoma) [26:30]
- [David Sabatini](https://www.davidmsabatini.com/research) (American scientist, expert in growth, metabolite profiling, and aging) [50:00]
- [Matt Kaeberlein](https://kaeberlein.org/) (Professor at the University of Washington, expert in aging) [50:00]
- [John Waterlow](https://en.wikipedia.org/wiki/John_Waterlow) (British physiologist, expert in childhood malnutrition) [1:07:00]
- [Joe Millward](https://www.nutritionsociety.org/people/professor-d-joe-millward) (British physiologist, expert in nutrition and metabolism) [1:07:00]
- [Peter Garlick](https://www.researchgate.net/scientific-contributions/P-J-Garlick-38602216) (former Professor at the University of Illinois, Urbana-Champaign, expert in metabolism) [1:07:00]
- [Vernon Young](https://en.wikipedia.org/wiki/Vernon_R._Young) (National Academy of Sciences member, expert in protein requirements) [1:07:00]
- [Joshua Anthony](https://www.nutritioncapital.com/principals-and-selection-committee/joshua-anthony/) (Did his Master’s with Don, nutrition expert, Founder and CEO at Nlumn LLC) [1:24:30]
- [Tracy Anthony](https://nutrition.rutgers.edu/faculty/tracy-anthony.html) (Did her Master’s and Doctorate with Don, Professor of Nutritional Sciences at Rutgers University) [1:24:30]
- [Stuart (Stu) Phillips](https://www.science.mcmaster.ca/kinesiology/component/comprofiler/userprofile/phillis.html) (Professor of Kinesiology at McMaster University) [1:25:30]
- [Douglas Paddon-Jones](https://www.linkedin.com/in/douglas-paddon-jones-099492a6) (Expert in nutrition and aging, was a professor at the University of Texas Medical Branch)  [1:25:30]
- [Robert Atkins](https://en.wikipedia.org/wiki/Robert_Atkins_(physician)) (Cardiologist and creator of the [Atkins diet](https://en.wikipedia.org/wiki/Atkins_diet)) [1:32:45]
- [Barry Sears](https://en.wikipedia.org/wiki/Barry_Sears) (Biochemist and creator of the [Zone diet](https://en.wikipedia.org/wiki/Zone_diet)) [1:32:45]
- [Michael Eades](https://denversdietdoctor.com/about-mike-eades-md/) (Physician and creator of the diet [Protein Power](https://en.wikipedia.org/wiki/Protein_Power)) [1:32:45]
- [Christopher Lynch](https://dpcpsi.nih.gov/onr/staff/christopher-lynch) (Acting Director of the NIH Office of Nutrition Research) [1:46:30]
- [Theresa Nicklas](https://www.bcm.edu/people-search/theresa-nicklas-27676) (Professor of Pediatrics-Nutrition at Baylor College of Medicine, expert in children’s nutrition) [1:57:30];
- [Victor Fulgoni](https://www.longdom.org/author-profile/victor-l-fulgoni-iii-348826) (Vice Chairman of Nutrition Impact at Battle Creek, MI) [1:57:30]

§

![](https://peterattiamd.com/wp-content/uploads/2022/09/bio-pic-donlayman-500x500.jpeg)

##### Don Layman, Ph.D.

Donald Layman is a Professor Emeritus at the University of Illinois Urbana-Champaign College of Agricultural, Consumer and Environmental Sciences in the department of Food Science & Human Nutrition.  Don earned his B.S. in Chemistry and M.S. in Biochemistry at Illinois State University and his Ph.D. in Human  Nutrition and Biochemistry at the University of Minnesota, St. Paul.  His research focuses on understanding the protein and amino acid requirements and interrelationship between dietary protein and carbohydrates needed for adult health.  In particular, his research seeks to understand the impact of diet and exercise on obesity, type 2 diabetes, and metabolic syndrome in adults.  His work has helped to define the role of branched chain amino acids (BCAA) in skeletal muscle metabolism.  BCAA provide an important energy source for muscle during exercise and also serve as a critical regulator of muscle protein synthesis during recovery. During exercise, oxidation of BCAA increases, resulting in production of the amino acid alanine and a rapid decline in plasma levels of BCAA. Amino acid supplements prevent this decline in plasma amino acids, enhance recovery of muscle protein synthesis and interact with insulin to help stabilize blood glucose. His research continues to define mechanisms for control of muscle protein synthesis and differences in dietary protein needs for men versus women and for adults with sedentary versus active lifestyles.  Don currently consults for many food industry companies including Kraft, Nestle, Hershey, the Dairy Council, the Egg Board, and the Beef Board.   [[University of Illinois Urbana-Champaign](https://fshn.illinois.edu/directory/dlayman)]

Twitter: [@donlayman](https://twitter.com/donlayman)