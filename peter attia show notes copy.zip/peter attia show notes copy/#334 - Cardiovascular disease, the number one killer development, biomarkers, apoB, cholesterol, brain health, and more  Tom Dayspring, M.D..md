# #334 – Cardiovascular disease, the number one killer: development, biomarkers, apoB, cholesterol, brain health, and more | Tom Dayspring, M.D.

**Source:** [https://peterattiamd.com/tomdayspring7/](https://peterattiamd.com/tomdayspring7/)

---

Tom Dayspring is a world-renowned expert in clinical lipidology and a previous guest on The Drive. In this episode, Tom explores the foundations of atherosclerosis and why atherosclerotic cardiovascular disease (ASCVD) is the leading cause of death worldwide for both men and women. He examines how the disease develops from a pathological perspective and discusses key risk factors, including often-overlooked contributors such as insulin resistance and chronic kidney disease. He breaks down the complexities of cholesterol and lipoproteins—including LDL, VLDL, IDL, and HDL—with an in-depth discussion on the critical role of apolipoprotein B (apoB) in the development of atherosclerosis. Additionally, he covers the importance of testing various biomarkers, the impact of nutrition on lipid levels, and the vital role of cholesterol in brain health, including how cholesterol is synthesized and managed in the brain, how it differs from cholesterol regulation in the rest of the body, and how pharmacological interventions can influence brain cholesterol metabolism.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/tomdayspring7/the_Drive_public.png)

Play

#334 - Cardiovascular disease, the number one killer: development, biomarkers, apoB, cholesterol, brain health, and more | Tom Dayspring, M.D.

#334 - Cardiovascular disease, the number one killer: development, biomarkers, apoB, cholesterol, brain health, and more | Tom Dayspring, M.D.

1x15s30s

0:002:17:37

## We discuss:

- Defining atherosclerotic cardiovascular disease (ASCVD): development, risks, and physiological impact [2:45];
- The pathogenesis of ASCVD: the silent development over decades, and the importance of early detection for prevention of adverse outcomes [10:45];
- Risk factors versus risk markers for ASCVD, and how insulin resistance and chronic kidney disease contribute to atherosclerosis [17:30];
- How hyperinsulinemia elevates cardiovascular risk [24:00];
- How apoB-containing lipoproteins contribute to atherosclerosis, and why measuring apoB is a superior indicator of cardiovascular risk compared to LDL cholesterol [29:45];
- The challenges of detecting early-stage atherosclerosis before calcification appears [46:15];
- Lp(a): structure, genetic basis, and significant risks associated with elevated Lp(a) [55:30];
- How aging and lifestyle factors contribute to rising apoB and LDL cholesterol levels, and the lifestyle changes that can lower it [59:45];
- How elevated triglycerides, driven by insulin resistance, increase apoB particle concentration and promote atherosclerosis [1:08:00];
- How LDL particle size, remnant lipoproteins, Lp(a), and non-HDL cholesterol contribute to cardiovascular risk beyond apoB levels [1:21:45];
- The limitations of using HDL cholesterol as a marker for heart health [1:29:00];
- The critical role of cholesterol in brain function and how the brain manages its cholesterol supply [1:36:30];
- The impact of the ApoE genotype on brain health and Alzheimer’s disease risk [1:46:00];
- How the brain manages cholesterol through specialized pathways, and biomarkers to track cholesterol health of the brain [1:50:30];
- How statins might affect brain cholesterol synthesis and cognitive function, and alternative lipid-lowering strategies for high-risk individuals [1:57:30];
- Exciting advancements in therapeutics, diagnostics, and biomarkers coming in the next few years [2:09:30];
- Recent consensus statements on apoB and Lp(a) from the National Lipid Association (NLA) [2:12:30]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Tom Dayspring may be a familiar name as Tom has been a guest on the podcast several times

- Tom is a fellow of both the American College of Physicians and the National Lipid Association
- He is certified in internal medicine and clinical lipidology
- He is the recipient of the 2011 National Lipid Association’s President’s Award for services to clinical lipidology and the 2023 Foundation of NLA Clinician/Educator Award
- Peter met Tom back in 2011 ‒ at the time, Peter had a budding interest in cardiovascular disease and lipids
  - Tom took Peter under his wing and has been one of the more important mentors Peter has had in the field of clinical lipidology
- In this episode, we talk about:
  - The foundations of atherosclerosis
  - Why it is the #1 killer in the US and abroad (both for males and females)
  - How the disease works from a pathologic perspective
  - The various risk factors for cardiovascular disease (CVD)
  - The role of insulin resistance and chronic kidney disease (2 things that don’t get talked about quite as much as high blood pressure, smoking, and lipids)
- We dive into cholesterol and lipoproteins
  - Discussing the role of apoB in the development of atherosclerosis
  - Talking about other particles that make up apoB (including LDL, VLDL, IDL, HDL), and their associations on CVD risk
- We talk about testing various biomarkers
- We talk about the impact of nutrition, particularly saturated fat and fat consumption on lipid levels
- We talk about the impact of cholesterol in the brain
  - Where cholesterol in the brain comes from
  - How it’s synthesized there
  - How that differs from the periphery
  - The role of pharmacology in that

## Defining atherosclerotic cardiovascular disease (ASCVD): development, risks, and physiological impact [2:45]

- We’re here to talk about ASCVD, cardiovascular disease
- There aren’t many people who heard our first podcast series together
  - [the 5-part series is listed in the see the “selected links” section at the end of these notes]
  - Peter still gets many notes from people who are just discovering that or who listened to it way back
  - That discussion is a little bit intimidating for someone who’s trying to understand this topic
- Today, Peter wants to bring a little bit of brevity to what they discussed then and also update people on all the things that have changed in the past 6 years

**Define what is meant by atherosclerotic cardiovascular disease (ASCVD)**

**⇒** That’s a very specific type of a vascular disease, and that means arteries throughout your body acquire a pathology: deposition of cholesterol in the artery wall

- If you don’t have cholesterol in your artery wall, you don’t have atherosclerotic heart disease
- We have many arteries in our body and some are much more afflicted than others

*The arteries of most concern are the smaller ones supplying our heart and brain*

- Because those are essential organs that need a profuse blood flow with all the nutrients and oxygen in the blood
- The lumen of the **cerebral arteries** is so small: it’s like the dot of a pencil, so it doesn’t take much to affect the blood flow that’s going through it

*Over time, with this deposition of cholesterol, 2 things that can happen*

- 1 – It can build up, and the artery lumen starts to narrow-narrow, which would interrupt the blood flow
- 2 – Probably more often is the deposition of cholesterol in the artery wall, and those collections are called **plaque**
  - That plaque can become very inflamed and rupture or erode, and that sets off the [coagulation system](https://en.wikipedia.org/wiki/Coagulation) in the arteries, which rapidly cause narrowing or obstruction of that coronary artery

***Atherosclerosis is the deposition of cholesterol in the artery wall***

**How did this happen?**

- The artery is not over-synthesizing cholesterol
- Tom’s joke is, “*It’s a dump job*,” somebody brought cholesterol into that artery wall

**Peter’s summary**

- Arteries come in all shapes and sizes
  - The largest is the aorta coming off the heart, running up in an arch to supply the vessels of the head and then down into the abdomen where every artery of the body arises
- It’s not that the arteries of the heart are uniquely susceptible to this process you just described as atherosclerosis, it’s 2 things that are conspiring against us
- 1 – Very small arteries: it doesn’t take a significant amount of obstruction to create ischemia (a technical term for when oxygen is no longer able to perfuse the tissue)
- 2 – It happens to afflict an artery that is specifically sensitive to the demands of oxygen

*Peter remembers explaining this to his daughter’s 7th-grade class*

- He came in to do a dissection, and explained part of the reason we don’t have “butt attacks” and we have heart attacks is that the glute muscles are not quite as sensitive to oxygen, and there were many forms of collateralization
  - Of course, what everyone remembered was “butt attacks”

***Brain and heart have this issue where tiny blood vessels are very susceptible to collateralization***

**And catastrophic things happen**

- 1 – The gradual occlusion of the arteries is probably what more often leads people to complain of chest pain when under demand
  - Such as climbing the stairs or when at the gym
  - Under normal circumstances, they don’t feel it
  - If they take a [nitroglycerine](https://en.wikipedia.org/wiki/Nitroglycerin#Medical_use), everything goes away
  - (we’ll talk about why all of that’s happening in a moment)
- 2 – A plaque ruptures causing complete occlusion of a coronary artery
  - That’s really a frightening scenario
  - The clotting system of the body responds in the way that it should respond when damage occurs
    - For example, if you cut your skin
    - But this turns out to be the worst thing the body could have done
  - This clotting response is what creates a sudden occlusion, and in an ironic way, the body kills itself
  - If that occurs in the wrong part of the anatomy of the heart, that person will be dead within a matter of minutes if an intervention is not performed
- The brain and heart can’t go very long without nutrients
- The bigger arteries that are bringing in blood to the brain are pretty asymptomatic until they are 75, 80% occluded
  - At which point those organs are deprived of the nutrients they need
  - This can build up for a long time without you knowing it
    - At least if you report chest pain, you will get diagnosed in time to do something about it

**⇒** This is different from a plaque rupture where you’ve got 4 minutes for somebody to dial 911 and hopefully somebody can give you CPR until you can get and take a [clot buster](https://en.wikipedia.org/wiki/Thrombolysis)

## The pathogenesis of ASCVD: the silent development over decades, and the importance of early detection for prevention of adverse outcomes [10:45]

**The timeline of events**

- Atherosclerosis is the leading cause of death in the US and globally, of both men and women
- This is largely viewed as a disease of the elderly

*Does that give us any insight into the time horizon of this disease or the pathophysiology?*

- It clearly does
- If the deposition of cholesterol is the problem, and you got your cholesterol checked and it’s very high, you don’t have to rush out to see a cardiologist to check your arteries that day, because ***it takes a long, long time for this cholesterol deposition to occur***
  - These are very small molecules
  - The way it’s being deposited in your artery wall: they’re very, very tiny dump trucks carrying cholesterol

> “*It takes decades for this plaque to finally get to a point where it’s noticeable on some diagnostic image. Certainly, it would take even longer for symptoms to occur, and everything. So, it’s a slow-slow process.*”‒ Tom Dayspring

- But we know this is occurring, basically, from childhood on
- There are pediatric studies ([PDAY](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1853040/), [Bogalusa Heart Study](https://bogalusaheartstudy.org/impact/)) where young children have died of this or that, and they get autopsied and they have fatty streaks in their aorta at ages 4, 5, 7, and 8
- We know from autopsy studies of military personnel who, unfortunately, get killed in their job, that these young men, many of them robust, in great shape, have subclinical atherosclerosis
  - But none of them are dropping dead of heart attacks while they are serving in the military, with rare exception
- The point is, it takes a long, long time
- Most of the heart attacks occur after age 40 (in men and women)

Tom explains, “*We are recognizing now, the real opportunity is to diagnose who might be having cholesterol deposition at a much younger age when we can just arrest it with various modalities.*”

**Peter’s story from medical school (almost 30 years ago)**

- In the 1st year of medical school, the pathology professor asked, “*What’s the most common presenting sign of myocardial infarction?*”
- Of course, every medical student put up their hand and went through the litany of symptoms that you might have; chest pain, shortness of breath, left shoulder pain, nausea, etc.
- He said, “*No, it’s actually sudden death*.”
  - That was true at the time
  - It’s not still true today, but it’s close

**⇒** The last thing Peter read suggested <50% of people’s first [MI](https://en.wikipedia.org/wiki/Myocardial_infarction) will be a fatal one

*Do you happen to know the most recent stats on that?*

- No, but it’s still quite high
- The majority do survive, but it’s got to be close to 40% that just don’t have that opportunity
- To think that only 25, 30 years ago, that number was north of 50%

**The other statistic Peter has shared before, but it always bears repeating**

**⇒** If you take all of the men who are going to suffer a [major adverse cardiac event [MACE]](https://en.wikipedia.org/wiki/Major_adverse_cardiovascular_events), 50% of them will experience their first event before the age of 65

- MACE includes heart attack, stroke, cardiac death, etc.
- That’s a pretty big number
- And 33% of women in the same boat will experience their first event before the age of 65
- Peter adds, “*The older I get, the younger 65 feels… I don’t think of 65-year-olds as old people anymore.*”

***50% of men and a third of women who are ultimately suffer a cardiac event will suffer their first one (potentially fatal) before age 65***

- This puts in perspective the temporality of this condition

**Peter’s summary**

- This is a disease that begins at birth
  - This is largely established through autopsy studies where children, teenagers, people in their 20s die for other reasons; car accidents, homicides, war; and in the process of doing an autopsy, we see the early stages of atherosclerosis
- The evidence is quite conclusive that this is a disease process that might be inevitable to our species, if we live long enough
- What might separate the people who never get it (or the people who die from something else at old age versus the people who do), simply has to do with the rate of the accelerator and the rate of the brake application, vis-à-vis, these modifiable and non-modifiable risks

**Tom’s addendum on how early this can start** There are [fetal autopsy studies](https://pubmed.ncbi.nlm.nih.gov/9389731/) in mothers who have familial hypercholesterolemia, and when they look at the little fetus’ heart, they actually see the beginning of plaque development

![](https://peterattiamd.com/wp-content/uploads/2025/02/f1-td7.png)

**Figure 1. Lipid accumulation in fetal aortas**.

- It occurs early, and this is why pediatric guidelines have now at least encouraged lipid testing in the pediatric age group, probably age 8 or 9
- You don’t wait until you are 40 or 50
  - Even though we can still help that patient
- We are moving into what’s called “**primordial prevention**” ‒ discover the risk factors early, and whatever ones you can modify earlier rather than later is the time to do it

## Risk factors versus risk markers for ASCVD, and how insulin resistance and chronic kidney disease contribute to atherosclerosis [17:30]

**There is a difference between risk factors and risk markers**

- **Risk factors** have been shown to be causal of the disease through the ways you do that Mendelian trials, a ton of randomized trials, and even observational trials
- **Risk markers** are not causal per se (they’re associative)
  - That’s not to say they’re not important

**⇒** We should attempt to modify them all

*Risk factors*

- Age (we can’t modify that)
- Smoking (modified with the patient’s cooperation)
- Lipid disorders
- High blood pressure
- You can include things like diabetes, but they basically bring hypertension and the lipid disorders to the table

*Risk markers*

- Some are biomarkers, others are not
- Coronary calcium and CTA: if you see that, you have atherosclerosis
  - [discussed further in [episode #247](https://peterattiamd.com/ethanweiss2/)]
- Other risk markers include homocysteine, omega-3 issues, vitamin D, there are a lot of bio-inflammatory markers we can look at
- If you have risk factors and you have these risk markers on top of them, the worst gets worse
  - It’s like a Chinese menu, the more things on there, it’s going to be more expensive at the end of the day

**The most important non-modifiable risk factors**

- Age
- Lp(a) ‒ caused by a gene that we don’t yet have the ability to fully modify it phenotype
- Other strong lines of family history that are necessarily transmitted through lipids the way the [FH](https://en.wikipedia.org/wiki/Familial_hypercholesterolemia#Genetics) sets of genes are
- Peter would argue that he has some of these genes
  - His family history is riddled with cardiovascular disease, and yet it doesn’t come in the flavor of profound dyslipidemia
  - He has normal [Lp(a)](https://en.wikipedia.org/wiki/Lipoprotein(a)) and has never had a very elevated [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B)
- When Peter had his first calcium score at age 35, it showed the presence of calcium, and this was in the context of an LDL cholesterol at about the 50th percentile
  - He was an average Joe, yet there was clearly something going on
  - He wasn’t insulin-resistant or a smoker
  - (we’ll talk in a moment about why he’s had zero evolution of that disease over the past 16 years, which speaks to the nature of interrupting causal pathways)

**Causal risk factors**

- No reasonable person would dispute the causality of apoB and hypertension

*What about insulin resistance and chronic renal failure? Do we have strong enough evidence on the causality of these, which are clearly highly associated with ASCVD?*

- [Chronic kidney disease (CKD)](https://en.wikipedia.org/wiki/Chronic_kidney_disease) is a super major risk factor, but probably, primarily through, virtually everybody with chronic renal failure has lipid disturbances (high apoB) and they have a high degree of serious hypertension
  - You’ve got 2 causal things that are present in everybody with CKD
- The question is, “*Is that the only reason CKD is doing it [a major risk factor]?*”
  - Tom suspects when your kidney is not getting rid of a lot of things, there are other things floating around that are irritating your arteries
- Peter adds that when we see people with compromised kidney function, we generally see [homocysteine](https://en.wikipedia.org/wiki/Homocysteine) go through the roof
- They used to look at the markers of [asymmetric](https://en.wikipedia.org/wiki/Asymmetric_dimethylarginine) and symmetric dimethylarginine, and would see these things skyrocket in people with high homocysteine because homocysteine impaired their clearance
- There’s reasonable mechanistic data to suggest that high amounts of symmetric and asymmetric dimethylarginine impaired the enzyme [nitric oxide synthase](https://en.wikipedia.org/wiki/Nitric_oxide_synthase), which produces [nitric oxide](https://en.wikipedia.org/wiki/Nitric_oxide) (which leads to vasodilatation)

***The path: there’s a very clear link between kidneys that don’t work fully, high homocysteine, and then the buildup of amino acids that prevent the body from making a vasodilator***

- Peter doesn’t know that the causality of that has been clearly established in humans
- But it would serve as one additional plausible mechanism for why [renal insufficiency](https://en.wikipedia.org/wiki/Chronic_kidney_disease) could be leading to an increase in vascular disease
- Tom agrees that there are other things floating around when you have CKD: homocysteine, [uric acid](https://en.wikipedia.org/wiki/Uric_acid), other metabolites, [ceramides](https://en.wikipedia.org/wiki/Ceramide), and things beyond what they want to discuss today

## How hyperinsulinemia elevates cardiovascular risk [24:00]

**⇒** Hyperinsulinemia and insulin resistance tend to traffic hand-in-hand with hyperlipidemia and hypertension (which are clearly and independently established as causal)

Peter asks, “*What do you make specifically of hyperinsulinemia and hyperglycemia as independent risk factors beyond the lipid and hypertensive components?*”

- Tom doesn’t accept that
- It goes back to an incredible [study](https://pubmed.ncbi.nlm.nih.gov/12540621/) from the ‘90s by Steve Garvey [Tom misspoke, it’s W. Timothy Garvey] using nuclear magnetic resonance analysis of lipoproteins
  - There are distinct lipoprotein signatures associated with insulin resistance [shown in the figure below]

[discussed in [episode #24](https://peterattiamd.com/tomdayspring5/)]

![](https://peterattiamd.com/wp-content/uploads/2025/02/f2-td7.png)

**Figure 2. Lipoprotein “signatures” associated with insulin resistance**.

*If you look at certain characteristics of the low-density lipoprotein (LDL), the very low-density lipoprotein (VLDL), and the high-density lipoprotein (HDL), you will see distinct patterns that appear in insulin-resistant people*

- You would have bigger VLDLs because they’re triglyceride carriers
- You would have smaller LDLs because the triglycerides convert big LDLs into small
- Likewise, you would not have big HDLs because triglycerides enhance HDL catabolism, making the HDL small
- These patterns are easily measured by NMR, and this was corroborated doing [insulin clamp studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4175429/)
  - So if we saw these type of lipoprotein signatures and we looked at the insulin clamp studies, they’re all insulin resistant
- The interesting thing was, these signals occur before postprandial insulin goes up
  - Certainly before fasting insulin goes up
  - And decades before glucose goes up
  - [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/02/f3-td7.png)

**Figure 3. Lipoprotein abnormalities occur before changes in fasting glucose and insulin**.

***Tom thinks it’s impossible to separate insulin resistance and lipoprotein abnormalities***

Tom explains, “*Those type of lipoproteins that I just discussed are the ones that are delivering cholesterol to your artery wall*.”

- Not everybody who has atherosclerosis has insulin resistance
- There are people out there who believe that if you don’t have insulin resistance, you cannot get atherosclerosis: that’s silly
- We know that before insulin levels go up, there are other cellular mechanisms that are going on in insulin-resistant people
  - Tom doesn’t know what purpose it served

***Whether you call insulin resistance causal or non-causal, it’s a very serious abnormality to be taken incredibly seriously***

- Peter tends to lean towards some independent causality there
- He points to some of the diabetic research where they look at studies where you take 2 different approaches to maintaining euglycemia
  - There are obviously pharmacologic aids that can do that without the use of exogenous insulin and with the use of exogenous insulin (2 different ways to bring glucose down)
- 1 – By increasing insulin sensitization
- 2 – By giving more insulin

***When you parse apart the results of these studies, you see something interesting: there appears to be some vascular damage that is mediated by just the hyperinsulinemia alone, even in the presence of normal glycemia***

- We would understand why hyperglycemia is problematic for microscopic vessels, but it’s these larger vessels that seem to have a negative response to hyperinsulinemia

*It almost comes back to this idea of, what’s going on with uric acid and homocysteine?*

- Are these things somehow inflammatory to the endothelium, and therefore, render the endothelium even more susceptible to a given concentration of lipoprotein?
- It might be a moot point, because when it comes to ASCVD, the goal is probably to address everything, and therefore, we might be having more of an academic debate on this

**Distinguishing between necessary and sufficient**

Peter points out, “*The other point that is probably worth mentioning to people when we talk about causality and biology is distinguishing between things that are necessary and things that are sufficient.*”

- Once in a while you find something in biology that is both necessary and sufficient, but many times it’s neither, and it can still be causal

*For example, consider smoking*

- There’s no doubt that smoking causes lung cancer
- Smoking is causally related to lung cancer, but is it **necessary** for lung cancer?
  - No
  - Only about 85% of people with lung cancer are smokers
  - 15% have never smoked.
- Is it **sufficient** for generating lung cancer?
  - No
  - There are many smokers who don’t go on to develop lung cancer

***In that sense, you can have something that is very causal (it’s increasing the risk of lung cancer by about 1000x), but it’s neither necessary nor sufficient***

## How ApoB-containing lipoproteins contribute to atherosclerosis, and why measuring ApoB is a superior indicator of cardiovascular risk compared to LDL cholesterol [29:45]

Tom explains, “*ApoB is the ballgame nowadays. It’s not widely tested like it should be, but anyway, cholesterol has got to get in your artery wall to cause this disease, atherosclerosis*.”

- [Cholesterol](https://en.wikipedia.org/wiki/Cholesterol) is an organic molecule that is one member of a very large “lipid family” of molecules
- By definition, a [lipid](https://en.wikipedia.org/wiki/Lipid) is a molecule that is not soluble in water
- The dilemma is, our delivery system of everything in the human body is a water solution called [plasma](https://en.wikipedia.org/wiki/Blood_plasma)
- Trafficking lipids in plasma is chemically impossible
- Evolution had to develop a lipid transport vehicle so these [hydrophobic lipids](https://en.wikipedia.org/wiki/Lipid#:~:text=Lipids%20may%20be%20broadly%20defined%20as%20hydrophobic) could be trafficked in aqueous plasma
- The solution was very simple, because proteins are soluble in water
- If one just combines a collection of lipids to a protein carrier, lipids can go wherever the human body wants them to go in plasma
- The things that traffic lipids in our body are protein-enwrapped lipids, and the proteins are called **apoproteins**
  - Once they bind to lipids, they’re called [apolipoproteins](https://en.wikipedia.org/wiki/Apolipoprotein)
  - And the whole macromolecule, once it’s fully developed, is called the [lipoprotein](https://en.wikipedia.org/wiki/Lipoprotein)
  - [illustrated in the slide below]

![](https://peterattiamd.com/wp-content/uploads/2025/02/f4-td7.png)

**Figure 4. Terminology around how lipids are transported in the body**.

Tom explains, “*Lipids go nowhere in the human body unless they’re a passenger inside of a lipoprotein.*”

**Many proteins can associate with these lipid collections, but we’ll focus on apoB for now**

- Structural apoproteins provide structure, stability, and water solubility to the lipids
- There are 2 categories of lipoprotein families in our body, of which the apoB family is the largest
- Only the liver and intestines can produce apoB; it’s a very high molecular weight protein

*The apo B family*

- Classified using the centrifuge
- Everybody has probably heard of [low-density lipoproteins (the LDL)](https://en.wikipedia.org/wiki/Low-density_lipoprotein)
- [VLDLs](https://en.wikipedia.org/wiki/Very_low-density_lipoprotein) are our triglyceride-carrying particles
- [IDLs](https://en.wikipedia.org/wiki/Intermediate-density_lipoprotein) are the intermediate lipoproteins (mentioned only for completeness), they’re very transient characters in between VLDLs and LDLs
  - Of no consequence except in some rare lipid disorder

**⇒** What makes apoB so valuable is there is 1 molecule of apB per apoB-containing lipoprotein, and this makes it easy for labs to assay

***Knowing the number of apoB-containing lipoproteins is critical because the particle that can leave the plasma and enter the artery wall to start this atherogenic process are the apoB family***

**High density lipoprotein (HDL)**

- [HDLs](https://en.wikipedia.org/wiki/High-density_lipoprotein) are the other family of lipoproteins, and their structural protein is [apoprotein AI (ApoA-I)](https://en.wikipedia.org/wiki/Apolipoprotein_AI)
- Each HDL particle contains between 1 to 5 copies of the apoprotein A-I
  - So that doesn’t become a useful biomarker to determine the HDL particle concentration
- HDL are not atherogenic, not until you get into the sub-discussion of them per se
  - Don’t worry about them too much

**What makes an apoB particle decide to leave the plasma and crash the artery wall?**

- Rather than go back to a receptor in the liver that can bind it and pull it out of plasma in a process called clearance
  - [Tom explained by email that it is the number of hepatocyte expressed LDL receptors that clear LDLs from plasma that determine apoB particle clearance]
- There are threshold concentrations above which the odds are good that apoB particles are crashing into your artery wall

*Unless you have horrific risk factors, atherosclerosis takes decadence develop because it takes a long time for these tiny apoB particles to keep crashing into the artery wall*

- Step #1 is crashing the artery wall, traversing the endothelial barrier (the one-cell lining that’s in every artery in our body) and going in

***It’s particle number***

- The best and easiest way (and the most tested way) to get an accurate atherogenic particle number is to measure apoB
- You’ll hear statements saying [apoB is causal](https://pubmed.ncbi.nlm.nih.gov/32203549/) and LDL-cholesterol is causal because of its very long plasma residence time, compared to the short plasma residence time of VLDLs
- About 95% of our apoB particles are LDL, hence another way of checking particle number (LDL-P)
- Not that VLDLs are not important (they can be), but it’s the LDLs that are doing most of the cholesterol dumping in the artery wall

***apoB gives us a good handle on LDL particle concentration, and it’s bringing sterols into the artery wall that’s causal, but it’s really the sterols that do the dirty work***

**⇒** You can’t separate apoB from cholesterol in physiologic circumstances

- Tom doesn’t care that some people will say cholesterol is causal or apoB is cholesterol

**Understand this process further – let’s assume that the most common apoB-bearing particle is a LDL carrying its load of cholesterol (and maybe a little bit of triglyceride)**

- It makes its way from the lumen of the artery through the endothelial barrier between a couple of cells into a potential space called the **subendothelial space**

Peter asks, “*What set of factors increase or decrease the probability that it is there long enough for its cholesterol package to begin the process of oxidation? Do we have any sense of this idea of retention?*”

- Yes; and it’s always subject to new data coming in because this is under a long time and continuing investigation

*One minor correction: LDL is not a molecule, it’s a macromolecule*

- Once the apoB particle traverses that endothelium
  - That can happen even if you have a normal endothelium
  - It certainly can happen easily if you have a diseased endothelium
    - This is where things like smoking and high blood pressure make your odds worse
    - Those things damage the endothelium, making that barrier more permeable

*This is all probabilistic: what increases the odds of an apoB getting in?*

- 1 – More particles, that’s higher apoB
- 2 – A more porous endothelium
- Peter thinks things like high homocysteine, high insulin, renal insufficiency, high uric acid all contribute to #2
- Peter mentioned [ADMA](https://en.wikipedia.org/wiki/Asymmetric_dimethylarginine) earlier: that’s a regulator of nitric oxide and probably the most crucial moleculethat the endothelium produces to defend the integrity of the artery
  - Once that’s out of whack, the endothelium is not functioning like it should

*When the apoB particle is in the wall of the artery (the intimal layer)*

- It’s like a fly hitting flypaper ‒ it’s stuck
- apoB has a high affinity to bind to tissue molecules called [proteoglycans](https://en.wikipedia.org/wiki/Proteoglycan), [syndecans](https://en.wikipedia.org/wiki/Syndecan) (there’s a sub-family of them)
- You can count the number of LDL particles floating around in our plasma (apoB) quadrillions and quintillions of these particles are crashing into your artery wall
- There’s a lot of them in there, and they’re all right next to each other, bound to these proteoglycans
- On the surface of these apoB-containing particles are phospholipids
  - The cholesterol and triglycerides are inside these particles
- Phospholipids are very susceptible to 2 things, of which **oxidation** plays a big, big role in atherogenesis
- There are enzymes called mutases that realign these phospholipids on the surface of these particles, and when distinct phospholipids are put next to each other, these particles have a high affinity to stick to one another (that’s called LDL or apoB particle aggregation)

***The first step is aggregation of LDL or apoB particles in the artery wall***

![](https://peterattiamd.com/wp-content/uploads/2025/02/f5-td7.png)

**Figure 5. LDL aggregation**.

- Ultimately, you have zillions of these apoB particles in a big mass of cholesterol and all the other lipids that are inside that particle

*That’s where the oxidation starts to occur because sterols get exposed*

- Phospholipids, many of which have double bonds, are highly susceptible to oxidation
- Now you have this clump of gooky cholesterol and phospholipids which are oxidized

*Oxidation is a major signal to the immune system*

- The immune system is going all over the body and when things get oxidized, that means it’s on fire
  - It’s often an infection or some other pathology
  - And here come the white blood cells to “put out the fire”
- So once you get this aggregated mass of oxidized whatever you want to call it (it’s way beyond cholesterol), white blood cells start traversing that endothelium, the monocytes, and they come in and they transform into macrophages, which express receptors that can start ingesting all these aggregated apoB particles
  - [The figure below shows LDL in the plasma at the top and ensuing pathophysiology that occurs after it transverses the endothelium of the artery, in the arterial intima]

![](https://peterattiamd.com/wp-content/uploads/2025/02/f6-td7.png)

**Figure 6. Influx and retention of LDL in the arterial intima drives the pathogenesis of atherosclerosis**.

*In the next step, masses of foam cells form plaque*

- This was first seen [described] by the great Russian [Anitschkov](https://en.wikipedia.org/wiki/Nikolay_Anichkov) in 1913: he overfed rabbits pure cholesterol and they developed atherosclerosis
  - Something rabbits normally don’t get
- Under the microscope, he saw cells full of cholesterol

![](https://peterattiamd.com/wp-content/uploads/2025/02/f7-td7.png)

**Figure 7. Nikolai Anitschokov was the first to describe foam cells**.

- This is what we now call the [foam cells](https://en.wikipedia.org/wiki/Foam_cell), which is a lt of cholesterol in the interior of a [macrophage](https://en.wikipedia.org/wiki/Macrophage)
  - Under the microscope they look very foamy, and that’s how they got their name

***As masses of foam cells accumulate over decades, it becomes plaque***

*As this plaque is being formed, the immune system is trying to “put out the fire”*

- Macrophages have eaten particles containing cholesterol and organized it into a pool, and now smooth muscle cells migrate and start covering this gook (this mass of cholesterol and other lipids)
  - [shown in the figure below]
- That becomes distinct **plaque** where you have a cap on it
  - That cap is smooth muscle cells that will transform into more complex cells that can start secreting calcium, and that gives this cap plaque a fibrous integrity

***The purpose of the cap is to prevent the plaque from rupturing***

![](https://peterattiamd.com/wp-content/uploads/2025/02/f8-td7.png)

**Figure 8. Development of calcified plaque**.

- Analogy: it’s like putting a heavy mound of dirt on a volcano ‒ it’s less likely to rupture if you can cover it
- Some of the cytokines and chemokines that are being produced by these white blood cells have bone forming ability

**⇒** And that’s why much later in the disease **calcium starts to get deposited** in this cap plaque

- That’s maybe somewhat fortunate because being radiopaque, that enables the type of imaging studies we have now to say, “*Oh my goodness, there’s calcium in your artery wall.*”
  - There’s only one cause and that’s atherosclerosis

> “*None of this happens like you overeat a lot of cholesterol tonight and boy, next week you’re going to have a heart attack. It takes decades.*”‒ Tom Dayspring

**Peter’s summary**

- We get into this process where you have the apoB carrying lipoprotein
  - It could also be Lp(a)
  - Let’s simplify it and call it LDL
- It enters that subendothelial space and its presence alone makes it susceptible to having its contents oxidized
  - Cholesterol (and more so the particle phospholipids) are rich targets for oxidation
- The immune system (monocytes) is constantly surveying and looking for things that are bad, and they’re seeing a chemical signal for that oxidation
- As monocytes enter that subendothelial space, they metamorphose into something called a macrophage
- The job of a macrophage is to literally consume (phagocytose, to eat) that thing it is concerned with
- The macrophage begins to eat oxidized cholesterol, and that produces the foam cell

*Way down the line we ultimately have calcification that is visible*

- A [calcium scan](https://en.wikipedia.org/wiki/Coronary_CT_calcium_scan) is looking for that

Peter is often asked, “*Is there anything I can do today to know if there is any damage to my endothelium? Are there any foam cells in me? Are there any fatty streaks?*’

- The next thing we talk about is a [CT angiogram (CTA)](https://en.wikipedia.org/wiki/Computed_tomography_angiography)
- In its first phase when it’s run without contrast, you have the opportunity to potentially see calcifications
- Once the contrast is injected, you get a higher resolution image that shows more anatomic detail of the lumen

## The challenges of detecting early-stage atherosclerosis before calcification appears [46:15]

- In Peter’s experience, you have a reasonable amount of non-calcified soft plaque suggesting that there’s probably still quite a bit of damage that could occur before you would see anything on a CTA
- Newer tests use a fat attenuation index to look at the changes in the character of the fatty tissue in and around the [adventitia](https://en.wikipedia.org/wiki/Adventitia) to see if that is in and if itself predictive of damage

**Outside of research-based tools (such as intravascular ultrasound), do we have tools to really understand these early stages of disease?**

*For the person who doesn’t want to get treatment now, but doesn’t want to wait until they actually have calcium (is there a middle ground?)*

- Not definitively, but there are 2 things
- 1 – There are **advanced imaging techniques** where they are analyzing certain characteristics of the artery wall
  - That’s still not ready for prime time play yet
- Because of its course, it’s nothing the average person is going to go and get tomorrow
- So we go back to the signals these macrophages are sending out to recruit more and more white cells to get in there and help
  - It’s like a fire department calling for a second, third, fourth alarm
  - We need more immune operators on the system
- 2 – Are there **immune markers** we can perhaps measure in the blood? And that’s basically what we’re doing right now

*These would be different types of inflammatory markers, and they’re looking at other types of biomarkers that might signal this type of pathology going on*

- This is the ones that are readily available to most people, and these are risk markers because by themselves they’re not causal and they have other etiologies (or other causes that might explain then why they’re high)
- The first and the one with the most evidence is the [C-reactive protein](https://en.wikipedia.org/wiki/C-reactive_protein) test
  - That was used for years to help diagnose [rheumatic fever](https://en.wikipedia.org/wiki/Rheumatic_fever) (characterized by a lot of inflammation)
- [Paul Ridker](https://prevmed.bwh.harvard.edu/paul-m-ridker-md-mph/) was the guy who did this, he discovered that the type of inflammation that goes on in the artery wall is incredibly subtle at first so you’re not going to see a C-reactive protein of sedimentation rate of 22 or 55 in the blood test (the old-time markers of inflammation)
- He started looking at extremely low C-reactive protein levels and he’s showed beyond debate now that yes, you can detect this
- It’s the same [high sensitivity CRP [hs-CRP]](https://en.wikipedia.org/wiki/C-reactive_protein#:~:text=high%20sensitivity%20CRP%20(hs%2DCRP)%20detects%20CRP%20in%20the%20range%20of%200.5%C2%A0to%C2%A010%C2%A0mg/L) assay that checks for CRP if you have [rheumatoid arthritis](https://en.wikipedia.org/wiki/Rheumatoid_arthritis)
- The high sensitivity has a different reference range that they relate to atherosclerosis (much lower concentrations than if you have some rheumatic disease)

***There are subtle elevations of C-reactive protein: the rule is that at 2 you worry, and >4 you’ve got some serious inflammation going on in your body***

- It’s not necessarily cardiovascular disease, but it could be an early stage of some other inflammatory disease
- That’s why it’s not a specific test
- Even levels less than 2 are a signal to start worrying ‒ that’s the 1st inflammatory marker

*Peter hasn’t been impressed with the specificity of hs-CRP*

- He’s seen too many people who have a normal hs-CRP (<1) and a calcium score of 10
  - This is not a person who’s going to die anytime soon, but they’ve already progressed to a calcium score of 10
  - That person might be in their 40’s
  - This is a person who’s on the path towards premature atherosclerosis

***Peter thinks that inflammatory markers are not specific enough or even sensitive enough at low levels, in particular because this disease has multiple paths***

**Analogy to paths to dementia**

- There are different paths that patients will take to get to [Alzheimer’s disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease)
- Some come at it through almost a genetically pre-programmed path
- Others come at it from much more of a vascular disease path, and yet others come at it from a more metabolic and an inflammatory path

***There are all these different paths and Peter wonders if there are similar paths towards atherosclerosis***

- Some people arrive at it almost genetically programmed in them
- Others are showing up through this lipid-based path
- For other inflammation is the dominant path, and maybe those are the people where hs-CRP shows up very early in the process

***Peter finds himself unconvinced that we have great tools to measure the phenotype of early atherosclerosis***

- Tom agrees and could name 2 or 3 other inflammatory markers that would have the same weakness
  - You could have a fatty liver and they’re elevated; or a subtle infectious disease somewhere
  - They’re not specific
- [Ridker](https://prevmed.bwh.harvard.edu/paul-m-ridker-md-mph/) would tell you in the scenario where coronary calcium is there but CRP is perfect, maybe that’s a stable plaque that’s not going to rupture herself
- Maybe they had a CRP blip 5 years earlier when that plaque was still being oxidized

**Tom explains the weakness of those types of markers**

- These markers are useful with apoB and Lp(a) are high (2 major risk factors)
  - Then if inflammatory markers coexist with them there is cause to worry
- That doesn’t mean if apoB is high (or Lp(a) is high) and inflammatory markers are perfect that we dismiss the chance of atherosclerosis
  - Because that’s not a game you want to play
- There are 10 other subtle rarely tested inflammatory cytokines and chemokines that can be measured
  - Saying that if you apoB is whatever and your homocysteine is high, we worry a little bit more about you
    - That’s modifiable
- Tom doesn’t have any other inflammatory markers to check

**The lipid world is going toward** [**respecting apoB as a biomarker**](https://www.lipidjournal.com/article/S1933-2874(24)00240-X/fulltext)**, and that’s where this new concept of primordial prevention has come into play**

- In the old days, it used to be primary or secondary prevention: you’ve had a heart attack and survived (thank God), let’s try to prevent another one
- Once imaging came along, then we can say your [CAC is positive](https://en.wikipedia.org/wiki/Coronary_CT_calcium_scan#:~:text=coronary%20artery%20calcium%20(CAC)%20score.)

*Tom wouldn’t call that primary prevention, that’s secondary*

**What is primary prevention?**

- You have high apoB, you have blood pressure
- People with physiologic parameters in the lipid and lipoprotein sphere
  - We still check them because we think at a certain age (or depending on what else goes on in their life), they will enter that primary prevention

***Primary prevention is defined as an escalation of apoB***

- Then you get into the decision of what therapeutics to offer this person whose apoB is just slightly high
- We don’t wait until the apoB is 80th or 90th percentile
- If there’s a way of pre-imaging atherosclerosis, we might find it
- But in some we would not
  - Just as not every smoker gets lung cancer, there are people with high apoB who live long and healthy lives
  - But we don’t know what else is going on in their artery wall, and we have no way of measuring that to assure them that they are the exception to the apoB rule

## Lp(a): structure, genetic basis, and significant risks associated with elevated Lp(a) [55:30]

**What would be the 3-minute explanation for the person who either needs a refresher or maybe who is new to this and hasn’t heard of what Lp(a) is yet and why should they care about it?**

- We’ve defined an LDL particle as a collection of cholesterol and a little bit of triglycerides wrapped by 1 peptide called [apolipoprotein B](https://en.wikipedia.org/wiki/Apolipoprotein_B)
- In some people who have the genetic machinery, their liver makes another protein called [apoprotein(a) [apo(a)]](https://en.wikipedia.org/wiki/Lipoprotein(a)#:~:text=a%20protein%20called-,apolipoprotein(a),-.%20Genetic%20and%20epidemiological)
- The guy who discovered it thought he discovered a new antigen
- “a” was the signal for antigen, and that’s where the little “a” came about

- Again, capital A is the [apoprotein A [apoA-I]](https://en.wikipedia.org/wiki/Apolipoprotein_AI) that is on an HDL particle
- There are MEGA-distinctions between small apo(a), and capital A

![](https://peterattiamd.com/wp-content/uploads/2025/02/f9-td7.png)

**Figure 9. HDL particles contain apA-I or apoA-II while Lp(a) particles contain apo(a)**.

Tom explains, “*If your genes tell your liver protein-matching apparatus to produce this apo(a), within the liver it binds to the apoB that’s on a primordial LDL particle that’s being produced in the liver. So now some of your LDLs, apo(a) binds to it and the liver just secretes them into your plasma. So that’s what an Lp(a) particle is.*”

***Lp(a) is a low-density lipoprotein that is carrying another protein that should never be on an LDL particle [apo(a)]***

> “*That apoprotein(a) has some characteristics that make it extremely atherogenic. Much of it ties into the oxidation that we mentioned before.*”‒ Tom Dayspring

- If that particle enters your artery wall, whatever oxidative forces are at play are going to get much worse, which is not good as far as atherogenesis is concerned

**⇒** If you have these Lp(a) particles, that’s sort of an inflamed particle carrying some oxidized phospholipases that can be pulled in by receptors (that are still not defined), but it can easily get into your artery wall

- It’s not a concentration gradient that drives them into your artery wall
- *Analogy*: it’s like we got a little fire in somebody’s backyard and somebody brings a can of gasoline and throws it on the existing fire

***With Lp(a), the atherosclerotic process occurs much more rapidly earlier in life (it’s bad news)***

**The good news perhaps is 80% of people don’t inherit the gene that makes you produce this apoprotein (a), but 20% do**

- But 20% of the world’s population adds up to billions of people who have what’s now recognized to be **the #1 lipid lipoprotein disorder associated with atherosclerosis**
- This is why there’s now a call to get everybody checked once in your life early on, because either you have it or you don’t

*If you do have it, we can start looking at ways to modify some of the bad news risks that’s going to occur with that process*

- Right now, we can’t get rid of the apo(a) particle
- There are drugs under investigation to do that

***All we can do if we discover this Lp(a) is look with a magnifying glass at every other risk factor or risk marker you have and do what we can to control those***

**Tom’s summary**

- Lp(a) is a “bad news” LDL type particle
- It’s not atherogenic because of the amount of cholesterol it’s carrying
- It’s what Tom calls a “minor LDL particle”
- [Tom explained further by email: because although Lp(a) particles are very atherogenic there are way more LDLs without apo(a) attached than there are Lp(a) particles]

***But particle for particle, Lp(a) is 7-8x more atherogenic than an LDL particle***

- An average person might have an LDL-P of 1,200 nanomoles
- So you might have an Lp(a) of 100 nanomoles and you would say, “*Oh, that’s a minor particle*.”
- Yes. But if it’s 8x more atherogenic than an LDL, it’s a bad news particle
  - *Analogy:* not everybody’s a criminal in our country, but it doesn’t take a lot of criminals to cause a lot of havoc
- It’s a terribly dangerous inherited type of lipoprotein

**Peter’s takeaway:** ***you don’t need a lot of something that has high virulence and potency to cause a lot of difficulty***

## How aging and lifestyle factors contribute to rising ApoB and LDL cholesterol levels, and the lifestyle changes that can lower it [59:45]

**The physiologic level of apoB (or LDL-C), the level we have when we’re young**

- The concentration of LDL cholesterol in a child is low
- The concentration of apoB is low
  - We don’t see this very often because we’re not used to checking these things in kids
  - Occasionally you’ll notice it as a parent, if your kid gets a comprehensive blood test: their total cholesterol might be 60 mg/dL with an LDL cholesterol of 30 mg/dL and an HDL cholesterol of 25 mg/dL (very, very low levels)

**Why does this change as we age?**

*Why is it that aging seems to be associated with a monotonic increase in lipoproteins?*

- And this is absent something that we could even get to later if we have time, which is what happens during menopause for women, which is more abrupt
- Just talking about ages 10 to 50, why does everybody seem to go the wrong way?
- A lot of this is the multitude of things we subject our bodies to: environment and lifestyle

***It’s almost all related to your liver losing the ability to clear the apoB particles out of the plasma***

- It’s not that you’re over producing 10 tons of them
  - That can happen, but it’s rarely a contributor to high apoB levels

**Scientifically, we have to zero-in on what regulates clearance of apoB particles**

- The only way these apoB particles get cleared is our liver produces something called an [LDL receptor](https://en.wikipedia.org/wiki/LDL_receptor) that migrates to the surface of the liver cell and interacts with the blood flow, and these LDL receptors are engineered to recognize any apoB peptide that floats by
  - [the figure below shows these LDL receptors in the liver (on the left) and the endothelial lining of arteries (on the right)]

![](https://peterattiamd.com/wp-content/uploads/2025/02/f10-td7.png)

**Figure 10. How atherogenesis relates to apoB particle clearance**.

- If an LDL particle containing apoB floats by an LDL receptor, it will get grabbed and then it gets internalized into the LDL receptor and it gets catabolized
- Then the liver can take whatever cholesterol, triglycerides, fatty acids that are in that molecule and use it for other purposes, or somehow get rid of it in the biliary system if the liver doesn’t need it

Tom explains, “*It’s going to come down to what are these factors that I called environmental or lifestyle that affects what we call LDL receptor expression.*”

- It’s a lot of things
- Insulin resistance would affect that
- Numerous components of the diet regulate whether you express LDL receptors or not
- How much cholesterol your liver is being told it needs to put in the next VLDL particle
- Or more importantly, the HDL particle going out

*Lipid balance in the liver is regulated by a bunch of things called nuclear transcription factors*

- They sense if the liver needs lipids or the liver’s got too much lipids (and needs to get rid of it)
- Those **nuclear transcription factors** migrate into the nucleus and the nucleolus of our cells and they bind to specific parts of the DNA and tell our genes, produce this protein, produce that protein, this enzyme, that enzyme, this receptor, that receptor, that can go out and help restore sterol homeostasis to this human body

***Probably every adversarial thing you’ve been told in your life not to do (gain weight, don’t eat this, don’t eat that) are all affecting these nuclear transcription factors that are going to regulate clearance of these apoB particles, and it’s a long list***

**What about modifying diet to lower apoB?**

*One of the questions Peter gets asked all the time*

- A patient will say, “*Hey doc, I buy your thesis that apoB is bad. I buy your thesis that mine is too high. And I buy your thesis that I should probably lower it. I’d really like to start with my diet before I turn to pharmacology.*”

***Peter tells patients that their 2 best levers nutritionally to reduce apoB are lowering triglycerides and lowering saturated fat intake***

- This assumes that you have high enough triglycerides that lowering them will lower apoB
- And it assumes that you’re eating a high enough amount of saturated fat that reducing it significantly will lower apoB

*Let’s assume that those things are true, and we’re talking to a patient whose apoB is 100 mg/dL*

- You’d be a heck of a lot better if your apoB were at 60 mg/dL
- His triglycerides are about 162 mg/dL
- When asked about his diet, it’s pretty high in saturated fat
  - 40-50% of his calories are from fat
  - He’s probably getting 50, 60 g of saturated fat per day
- He’s an ideal candidate to switch more of his fat calories to monounsaturated and polyunsaturated or even just reducing fat altogether (we’re not going to get into how to do that)

Peter asks, “*Can you explain why lowering triglycerides and lowering saturated fat intake, those 2 things, could bring this guy from 100 down to 60?*”

*Saturated fat is a little easier to explain*

- There are plenty of studies that show excess saturated fat [affect] those nuclear transcription factors that regulate lipid balance in the liver
- The liver is the master controller of lipid homeostasis in the body, it works hand-in-hand with the intestine, but the liver is sort of the brains of the operation
- In many, many people exposure to saturated fat causes the nuclear transcription factors to realize, “*Oh my god, fatty acid toxicity is going to occur to this liver. We have to take our defensive mechanisms on that*.”
- #1 – They don’t want more lipids being pulled into the liver by these LDL receptors
  - So the nuclear transcription factors go into your DNA and say, “*Stop making these LDL receptors.*”

***If you eat saturated fat and your liver stops expressing LDL receptors, your apoB is going to go through the roof***

*What is the apoB particle carrying?*

- Cholesterol
- And above the threshold concentration, it’s going in the artery wall

***Typically, if that person restricts saturated fat, they will bo back to an increase in LDL receptor expression***

- #2 – In some people, saturated fat also turns on the enzymes that induces cholesterol synthesis

***If the liver starts overproducing cholesterol, then the lipid pool is out of whack***

- Now, the same nuclear transcription factors go in and say, “*Stop making LDL receptors. We don’t want to pull in more cholesterol into this liver that’s over synthesizing cholesterol.*”

**⇒** We don’t necessarily tell people to restrict cholesterol in the diet because the absorption of sterols in your gut has nothing to do with the absorption of fatty acids in your gut

- Totally different mechanisms pull each of them in

## How elevated triglycerides, driven by insulin resistance, increase ApoB particle concentration and promote atherosclerosis [1:08:00]

**The triglyceride story gets much more interesting**

- It’s maybe more important because it’s epidemic in the world now

> “*We know triglycerides is a poor man’s biomarker of insulin resistance.*”‒ Tom Dayspring

- If you’re measuring triglycerides in the blood, Tom suggests that you only need to measure apoB and triglycerides
- There are 2 categories of hypertriglyceridemia
- 1 – At or above 500, 1000: due to some crazy genetic disorder
  - Most of those are *not* associated with atherosclerosis
  - Nonetheless, they are associated with pancreatitis and other pathologies so you’d want to lower what’s called a very high triglyceride level
- 2 – 130-180: this is what the average doc measuring lipid levels will see
  - The etiology of that is almost always insulin resistance, through many factors
- Those triglycerides are being made in your liver
  - Other cells don’t produce triglycerides other than an adipocyte
- If your liver is overproducing triglycerides, it’s saying, “*Oh my God, I got to get these out of here.*”
  - If the liver retains triglycerides, it’s going to get fatty liver
- So it packages them into the triglyceride containing lipoprotein (VLDL)

**What VLDLs do**

- [VLDLs](https://en.wikipedia.org/wiki/Very_low-density_lipoprotein) are very similar to the big [chylomicron](https://en.wikipedia.org/wiki/Chylomicron) particles that come out of your intestine
  - These are the triglyceride carrying vehicles that are bringing fatty acids in the form of triglycerides to the tissues (muscles) that need to grab the triglycerides, convert them to fatty acids, and oxidize those fatty acids to make ATP
- The heart is a big consumer of triglycerides
- The big chylomicrons, the big VLDLs coming out of the liver, they go into beds that express the triglyceride-dissolving enzymes (or lipoprotein lipase)
  - In muscular beds or adipocyte beds
- The triglycerides are hydrolyzed to fatty acids, they enter those muscular beds, and then they can be oxidized for ATP
- In adipocytes, the fatty acids are pulled in and reconverted to triglycerides and stored for future energy needs

***If you have way more triglycerides in your liver because you’re insulin-resistant and your liver is overproducing them, the liver makes very big VLDL particles***

**⇒** The big VLDL is a NMR signature of insulin resistance

- A normal person with physiologic triglyceride never makes big VLDL particles
  - There’s no need for them
  - That person makes smaller VLDL particles that carry just enough triglycerides to be sufficient for energy needs of the muscle

**In addition to high triglycerides, an insulin-resistant person makes another apoprotein in excess called apolipoprotein C-III**

- The VLDLs coming out of the liver are now carrying something they shouldn’t carry very much of: [apoC-III](https://en.wikipedia.org/wiki/Apolipoprotein_C-III)

***To make a long story short, it retards the catabolism of these triglyceride-rich VLDL’s, so it blocks their attachment to lipoprotein lipase***

- Now, the plasma residence time of a VLDL or chylomicron (which should be extremely short) is prolonged

**What is the consequence of letting these triglyceride-rich VLDLs float around longer than they should?**

- 1 – If you measure triglycerides in the blood, it’s going to be higher than it ordinarily would be
  - That’s why if you look at a certain triglyceride level, you might suspect this is happening
- 2 – When these triglyceride-rich VLDLs are floating around in plasma, they bump into the much, much, much more numerous LDL and HDL particles
  - What happens?
  - We carry a lipid transfer protein that actually locks LDLs and HDLs into VLDLs, or LDLs into HDLs: it’s called [cholesteryl ester transfer protein (CETP)](https://en.wikipedia.org/wiki/Cholesteryl_ester_transfer_protein)
    - It really should be called CETTP, cholesterol ester triglyceride transfer protein
  - When these 2 particles bump into each other, Tom jokes, “*They’re mating,*” because they’re now connected with this little canal
  - They exchange 1 molecule of triglyceride for 1 molecule of cholesterol
  - In essence, the VLDLs and chylomicrons become triglyceride-poorer, but more cholesterol-rich
  - Whereas the LDL and the HDL become cholesterol-poorer and triglyceride-rich
- Any doctor who does a lot of lipid profiles knows that every time triglycerides go up, LDL-cholesterol doesn’t necessarily go up, but almost assuredly HDL-cholesterol goes down
- That’s because HDLs, which should really carry almost no triglyceride molecules have now sucked in a lot of trigs, but they’ve given up cholesterol
  - If we were measuring HDL triglyceride levels, we would see it’s very high
  - But we just see the HDL cholesterol is low

**The last step of what happens to any triglyceride-rich particle** There are lipases ready to dissolve it: [endothelial lipase](https://en.wikipedia.org/wiki/Endothelial_lipase) and [hepatic lipase](https://en.wikipedia.org/wiki/Hepatic_lipase) attack triglyceride-rich HDLs by extracting and hydrolyzing the trigs

![](https://peterattiamd.com/wp-content/uploads/2025/02/f11-td7.png)

**Figure 11. Triglyceride-rich HDLs get catabolized by hepatic and endothelial lipase**.

- The HDL particles become so small they break apart, and apoA-I goes down to the kidney where it can be catabolized into amino acids and excreted

***This explains why diabetics, people with high trigs have such low HDL particle counts and low HDL cholesterol***

**Here’s what happens to LDL now**

- The LDL is sending cholesterol in exchange for triglycerides to the VLDL or the chylomicron
- The little LDL particle (much smaller than those monsters) becomes triglyceride-rich and cholesterol-poor

*What is the fate of that type of LDL?*

- [Tom clarified by email: that their fate is decreased clearance by LDL receptors due to their altered size changing the shape of apoB thereby decreasing its affinity for LDL receptors]

**⇒** If we could only measure LDL triglycerides, it would be by far the best lipid metric we could ever measure

**Peter’s take on why apoB is going up in a high triglyceride environment**

- This happens because you need more LDLs to carry the same amount of cholesterol ester
- So much of the carrying capacity of the LDLs is going towards managing the transport of triglycerides
- Therefore, while LDL-cholesterol might remain constant, it’s being spread out over more particles

***apoB (which is the marker of particle concentration) is going up, and that is the metric that matters***

- This is the classic example of where we see discordance between LDL-cholesterol and apoB particle concentration
  - [Shown in the figure below where each dot represents 1 patient, notice all of the dots (representing discordance) outside of the red lines]

![](https://peterattiamd.com/wp-content/uploads/2025/02/f12-td7.png)

**Figure 12. Relationship between LDL-cholesterol and LDL particle number**.

*[Tom clarifies, adding this next section by email]*

- As triglyceride molecules (TG) enter the LDL particle core there is less room to hold cholesteryl ester (CE)
  - LDL particles are now TG-rich but CE-poor
  - Shown in the figure below

![](https://peterattiamd.com/wp-content/uploads/2025/02/f13-td7.png)

**Figure 13. Cholesteryl ester capacity of LDL particles decreases as triglyceride content increases and/or as particle size decreases**.

- It takes many more CE-depleted LDLs to traffic a given mass of cholesterol so particle number is increased
- The TG-enrichment also alters the shape and size of the LDL which by altering the conformation of surface apoB, reduces its clearance at hepatic LDL receptors

**⇒** risk increases as the number of LDL particles increases

- As either the size of the LDL shrinks or the content of TG increases, CE is depleted
- It takes more CE-depleted particles to traffic a given mass of cholesterol
- The next 2 figures show the effect of this on number of LDL particles and ASCVD risk

![](https://peterattiamd.com/wp-content/uploads/2025/02/f14-td7.png)

**Figure 14. Impact of triglyceride-rich LDLs on ASCVD risk. Comparing two patients with the same LDL-C and LDL particles of the same size**.

![](https://peterattiamd.com/wp-content/uploads/2025/02/f15-td7.png)

**Figure 15. Smaller LDL particles carry less cholesterol and more particles are needed to accommodate the same amount of cholesterol as larger (normal-size) LDL particles**.

**Triglyceride-rich LDL particles**

- What happens is lipases (mostly hepatic lipase) take the trigs out and then the LDL particle becomes very small [shown in the figure below]
- Now you have a small LDL particle, which per particle can’t carry many cholesterol molecules

![](https://peterattiamd.com/wp-content/uploads/2025/02/f16-td7.png)

**Figure 16. Increased triglyceride leads to smaller LDL particles and an increase in total LDL-P and VLDL remnants**

*The major reason apoB goes up*

- In an LDL that is small, the apoB assumes a different conformation on the surface of the LDL and it is no longer recognized by the LDL receptor

***You have markedly delayed clearance of the small LDL***

- Whether your LDL cholesterol goes up or not, the cholesterol is spread among more LDL particles because they can’t be cleared anymore

> “*That is why lifestyle can work very good. Anything that lowers trigs can interrupt this pathologic lipolysis or catabolism of these apoB.*”‒ Tom Dayspring

- If we could make those small LDLs disappear and they would assume their more circular shape, they conform to the LDL receptor more

**In diabetics**

- This explains why the apoB (or LDL particle) count is through the roof
  - Or in people with high triglycerides
- It’s due mostly to decreased clearance, so the LDL-P goes up
- And small LDL-P is driving that
- When triglycerides go above a certain threshold, the predominant species of LDL is the cholesterol-poor, small LDL
  - These are the ones that have decreased clearance
- So apoB goes up
  - [Tom clarified by email: apoB = total LDL-P = large LDLs + small LDLs]

***When apoB goes up, it crashes the artery wall with relative ease***

**At what level of triglycerides can this occur?**

- The guidelines have put high risk at >150
  - But that’s the 75th percentile of a population triglyceride distribution
    - We don’t wait for any other lipid metric to hit the 75th percentile
  - Tom’s not sure why they still do that other than perhaps they didn’t have enough to tell people what to do about it

***This transformation occurs somewhere at 100 or more***

Tom explains, “*We’re a little nervous when trigs start to go much above 80, nevermind 100-120.*”

**Tom uses himself as an example**

- He’s been a lifelong very insulin-resistant guy
- He always had a decent LDL-cholesterol
- His trig was always in the 102, 105 range (which he dismissed as being normal)
- Once NMR came around and he saw his LDL particle concentration and the number of small LDLs [he became concerned]

**Tom’s summary**

- The real pathology of high trigs is creating too many cholesterol-carrying particles that can invade the artery wall
- It’s not triglycerides in the artery wall that are generating atherosclerosis; it’s the delivery of cholesterol
- As triglycerides go up, you have a lot more apoB cholesterol-carrying particles
  - Even though each particle is carrying lesser numbers of cholesterol than before, there’s just many more of those LDL particles that are crashing your artery wall
- When we do come up with a way to lower triglycerides nutritionally, or even if we wanted to use a drug, virtually every single one of our lipid-modulating drugs is FDA-approved to lower triglycerides

**⇒** You can’t simply aim for lowering triglycerides, you have to lower apoB to see event reduction with trigs

- Most of the time when you lower trigs with proper therapies (lifestyle or drugs), you will see a drop in apoB
- There have been several trials that dramatically lowered triglycerides with the [fibrates](https://en.wikipedia.org/wiki/Fibrate) that did not reduce [MACE](https://en.wikipedia.org/wiki/Major_adverse_cardiovascular_events)
  - Although they dramatically lower triglycerides, they’re not the greatest apoB-lowering drugs in the world
- Respect triglycerides at much lower levels than you’ve ever been taught

***The goal of your therapy is to normalize apoB***

**Nutritional changes**

- Peter thinks it’s always worth taking a shot at modifying your nutrition to fix apoB, but don’t forget the goal is lowering apoB
- If triglycerides are high, caloric reduction is the key to doing that (in most people)
  - If you have a person who’s eating a lot of saturated fat, a lot of carbohydrates, low-quality carbohydrates, sugars, hypercaloric ‒ that person can actually do a lot of apoB reduction with nutrition
- Conversely, when you see a person whose trigs are 50 mg/dL, who’s not mainlining saturated fat and eating in relatively normal amounts, Peter typically advises those people against draconian fat reduction
  - Which admittedly will indeed lower cholesterol, but often comes at the consequence of something else nutritionally

## How LDL particle size, remnant lipoproteins, Lp(a), and non-HDL cholesterol contribute to cardiovascular risk beyond ApoB levels [1:21:45]

**Mechanism behind small LDL particle size**

Peter emphasizes, “*I think this point, by the way, about the conformational change in the relationship between the LDL receptor on the liver and the LDL particle is a very interesting one.*”

- Peter wonders if LDL particle size should be of concern given that these smaller cholesterol depleted LDL may linger longer
- Or can we ignore that if we have a good handle on apoB?

**Is risk completely captured in the apoB marker?**

- Yes
- If you were doing everything nutritionally or pharmacologically, you would see a transformation of those small LDLs
  - You wouldn’t find them anymore, and you’d have a normally sized apoB particle

**Nonsense out there about big LDLs being cardioprotective, often called fluffy-buffy**

- On a big LDL, the apoB gets distorted [just like on a small LDL particle], and those particles are far less compliant to the LDL receptor [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/02/f17-td7.png)

**Figure 17. ApoB on both small and large LDL particles have a distorted shape that impairs LDL-receptor mediated clearance in the liver**.

- People with [FH](https://en.wikipedia.org/wiki/Familial_hypercholesterolemia) have very big particles and their high apoB level is due to defective LDL receptor and defective attachment to LDL receptors

***With big LDL particles, there is also defective attachment to LDL receptors because the apoB is no longer in the proper conformation***

**Chylomicrons and VLDLs are the big triglyceride-carrying particles, and they affect HDL and LDLs**

**⇒** They screw-up the HDLs and LDLs by sending triglycerides over there

- Normally chylomicrons and VLDLs deliver trigs to the muscle cells where they lose trigs and get smaller
- Smaller chylos and VLDLs are called remnant VLDLs or chylos
- The main reason they get cleared from the body is they carry multiple copies of the [apolipoprotein E (apoE)](https://en.wikipedia.org/wiki/Apolipoprotein_E)

ApoE is the apolipoprotein on VLDLs and chylos that binds to a very specific hepatic receptor in the LDL receptor family called [LRP (LDL receptor-related protein)](https://en.wikipedia.org/wiki/LRP1) [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/02/f18-td7.png)

**Figure 18. Hepatic clearance of apoE particles, apoB particles, and HDL**.

- But when apoE is on big VLDLs and chylomicrons, it’s [shape is] contorted and it doesn’t bind to the LRP
  - [Tom misspoke here saying apoB but confirmed that he meant apoE]
- Once the chylos and VLDL shrink down, the apoE assumes a [receptor favorable] conformation [that can bind LRP]  and that’s why their plasma residence time is so short
- Those particles carry several copies of apoE

*But during insulin resistance where the VLDLs and chylos can’t get rid of their trigs, these people have what is called increased* [*remnants*](https://en.wikipedia.org/wiki/Remnant_cholesterol)

- The particle number of remnants doesn’t even come close to an LDL particle number, but it’s up way more than it should be

**⇒** Particle for particle, remnants carry 5-7x more cholesterol per particle than an apoB LDL particle

- If you let these remnants float around, they get pulled into the endothelium
- They’re a very inflammatory particle in part because of the [apoC-III](https://en.wikipedia.org/wiki/Apolipoprotein_C-III) on them

***Remnants get internalized easily into the artery wall, which is another reason people with high trigs have so much atherosclerosis ‒ they have too many LDL particles and too many remnants***

- They may also be losing [HDLs](https://en.wikipedia.org/wiki/High-density_lipoprotein)

**⇒** HDL performs a cardioprotective function by extracting cholesterol

- [Tom clarified by email: efflux is but one of dozens of things HDLs do to fight atherosclerosis]
- And now they may not have enough HDLs to do that
- This is why Tom gets very nervous when we start to see trigs exceeding 100 because he assumes some of these pathological pathways are at play

**Peter’s summary**

- Remnants just like Lp(a) are captured in the apoB concentration
- It’s almost like you have 4 populations buried within apoB
  - 1 – The majority of them are LDLs
  - 2 – Garden-variety VLDLs
  - 3 – Remnant VLDL
  - 4 – Lp(a) ‒ and if you have too many of those you might have too many remnant VLDLs
- Of these 4, it’s that remnant VLDL and the Lp( a) that pack more of a punch

*This is where Peter thinks apoB by itself can be a bit misleading*

- You could have 2 people that have an identical apoB concentration, but if 1 of them has it as all LDL and some VLDL, they’re okay [if LDL-P is normal]
  - The other person might have a disproportionately high Lp(a) and/or remnant concentration
  - You won’t know which it is unless you’re doing additional analysis
  - [Tom added by email: new [data](https://www.lipidjournal.com/article/S1933-2874(24)00256-3/fulltext) shows increased remnants do not change the VLDL-P/LDL-P ratio and thus as remnants are produced, more LDLs are produced]

**Is that a fair rationale for why we want to look at everything?**

- Yes
- Measuring Lp(a) is easy
- Lp(a) is not a major contributor to apoB, but it’s a terribly atherogenic particle, so we get nervous with it
- With VLDL particles, measuring apoB tells you nothing about the number of VLDLs
  - Particle for particle, they can be more atherogenic, but there’s not very many of them

> “*Here’s my little pearl. There’s another metric people should look at. It’s called non-HDL cholesterol.*”‒ Tom Dayspring

**⇒** **Non-HDL cholesterol** is the cholesterol that’s not in your HDL particles; in essence, it’s your apoB cholesterol

***If your apoB is looking good, but the non-HDL cholesterol is still a little high, Tom suspects you’ve got remnant VLDL particles floating around***

Tom’s advice, “*There are no accurate remnant tests that are available to the run-of-the mill doctor. Look at non-HDL cholesterol … that’s a freebie on the lipid profile. It’s basically total cholesterol minus HDL cholesterol.*”

- Non-HDL cholesterol is the cholesterol that is in your VLDLs and LDL
- If your LDL-cholesterol, apoB is looking good, but your VLDL cholesterol is still high, that would drive non-HDL cholesterol to be higher than it should be
- That’s why Tom and Peter have very aggressive goals for non-HDL cholesterol

## The limitations of using HDL cholesterol as a marker for heart health [1:29:00]

- We’ve already done dedicated podcasts on this topic [most recently, [episode #240](https://peterattiamd.com/danrader/)], so we’re not going to cover this in too much detail here
- Tom has alluded to the fact that HDLs can be protective, and this has led many people to refer to HDL as the so-called “good cholesterol”
  - And if your “good cholesterol” is high, you don’t need to worry about anything
- Peter’s not going to ask Tom to debunk that because it’s nonsensical

**A brief discussion on how HDLs work and why they can be protective (when they’re functioning)**

*But also why we can’t figure this out from blood tests*

- This is so important and so unknown out in the real world
- In the layman’s world, it’s probably not known at all because newspapers give the idiotic message to check your “good cholesterol,” and even if it’s high, you don’t have to worry about your “bad cholesterol” (LDL)
  - It’s even sadder that some providers still believe this and tell their patients that
- When Tom is teaching any patient about lipoproteins, what they do, and what they carry, he gets to a point where he says, “*We’re not going to talk about HDLs anymore*.”
- HDL particles are incredibly important to both your cardiovascular system and probably many other tissues in your body
  - HDLs perform a lot of functions that especially with the heart, may be very cardioprotective
- We also know that some people have the type of HDLs that don’t perform those cardioprotective functions
  - They actually perform bad functions to the artery wall and plaque in the heart

*The important point is to understand what HDLs do; let’s call that HDL functionality* **⇒** What your HDLs are doing has zero relationship to their cholesterol cargo (meaning your HDL-cholesterol level in the blood)

![](https://peterattiamd.com/wp-content/uploads/2025/02/f19-td7.png)

**Figure 19. HDL-C doesn’t provide information about HDL function**.

- There are people with low HDL-cholesterol, often a signal for the high cardiovascular risk (but not everybody)
- There are people with very high HDL-cholesterol have been told they’re protected, and we know they are not
  - A group of them gets atherosclerotic disease
  - A group of them have been described with breast cancer, dementia

***You can’t look at an HDL-cholesterol in an individual patient and make extrapolations on what the HDLs are doing in that person***

**The reason HDLs have these either miraculous or disastrous properties comes down not to their lipid content, but 2 things**

*1 – Their protein content*

- Over 150 proteins have been found to be associated with various HDL particles, and they perform an immense number of likely very necessary actions that need to go on in certain tissues where things may be going wrong

*2 – The exact phospholipid concentration of an HDL surface has a tremendous impact on whether the HDL can do wonderful things or bad things*

- We know that the coat of an HDL (apart from its proteins) is virtually all phospholipids
- Those phospholipids really determine what an HDL can bind to in various tissues

**⇒** We can’t measure the HDL phospholipid content

- There are hundreds of phospholipids, and you would get a lipidome coming back that you couldn’t even pronounce half of the phospholipids or at least the fatty acids that are in those phospholipids
- Same with the protein: if there’s 150 of them, your doctor might be familiar with about 10

> “*I don’t know how to determine the patient’s HDL functionality*.”‒ Tom Dayspring

***The people having adverse effects with high HDL-cholesterol have dysfunctional HDLs probably related to that proteome or their phospholipid content and vice versa***

- What we tell a person right now is in the year 2024, we didn’t always believe this
- This bad cholesterol had an origin that everybody believed way back when ([Framingham](https://en.wikipedia.org/wiki/Framingham_Heart_Study), the earlier observational trials), and nobody ever adjusted for apoB in those trials
  - ApoB numbers weren’t available then

**We now know that the people with low HDL-cholesterol who do get atherosclerosis, always have high apoB**

- Why do those people have low HDL-cholesterol?
- It’s the trigs that knock the HDL (discussed earlier)
- The trigs may not be 400, they may only be 130 which are being ignored
- What is high in them? apoB

***The proper treatment of low HDL-cholesterol in the person you believe has cardiovascular risk is just like trigs: lower apoB, lower non-HDL cholesterol if you can’t get an apoB***

- If somebody has a high HDL-cholesterol, always check their apoB
  - Tom does this in 100% of people

***If apoB is high, treat it regardless of the HDL-cholesterol level***

Tom explains, “*I can’t look at a man or a woman and say, oh my god, you are the one with high HDL-C who might wind up with dementia or some cancer or something. I don’t know. We’ll track those other diseases with other modalities*.”

***High HDL-C is not a declaration of cardiac immortality; what’s important is HDL functionality***

**A friend of Peter’s always had very high HDL-C and very low LDL-C**

- His HDL-C was routinely >100 mg/dL, and his LDL-C has always been <100 mg/dL
- By anybody’s metric, this guy looks like he’s in tip-top shape
- Peter suggested to him that it would be reasonable to do a [calcium score](https://en.wikipedia.org/wiki/Coronary_CT_calcium_scan)
- Peter has seen case studies of individuals with high HDL-C, low LDL-C, who still end up having atherosclerosis, and it can be quite aggressive
- He ended up have quite a high calcium score
- Now he’s on very aggressive treatment to take any residual risk out of that apoB
  - He’s on double therapy and now  has an apoB in the 20-30 range
  - Hopefully that’s going to be sufficient to retard this
- Tom remembers Peter sharing this story with him and he thought at the time, “*Why the heck did you do a CAC? Because you’ve heard me spout enough, you learned your lesson. I don’t use HDL-C to make any decision.*”
- Peter remembers reading a case study 10 years ago about a woman who looked just like that and ended up having very advanced atherosclerosis

## The critical role of cholesterol in brain function and how the brain manages its cholesterol supply [1:36:30]

- Cholesterol plays an important role in the brain (to put it mildly), and this is an area where Tom’s knowledge has grown rapidly
- People have many questions about the role of cholesterol lowering therapy and brain health

**What role does cholesterol play in the brain, and what do we know about the different pools of cholesterol?**

- More questions
  - We have cholesterol outside of the central nervous system, cholesterol inside the central nervous system ‒ can they move back and forth?
  - Can lipoproteins go back and forth?
  - Is LDL taking cholesterol into the brain and back?
- This is complex
- Peter got Tom interested in lipids in the brain 15 years ago when he introduced him to [Richard Isaacson](https://ind.org/about#team) at the [Cornell Dementia Clinic](https://weillcornell.org/services/neurology/alzheimers-disease-memory-disorders-program/our-services/alzheimers-prevention-clinic), and he’s been trying to learn about the brain and lipids ever since

Tom adds, “*You did that great podcast with Dan Rader on HDLs, and it’s a podcast everybody should listen to.*” [[episode #240](https://peterattiamd.com/danrader/)]

- At the end Dan said, “*Lipids in the brain is the next frontier*.”
- That hasn’t been studied very much until now because you have to get cerebral spinal fluid to analyze what’s going on in the brain
  - Most people are amenable to a venipuncture in their elbow, not a spinal tap

> “*Cholesterol is almost certainly the most important molecule in the brain.*”‒ Tom Dayspring

- The brain is by far the most cholesterol carrying organ in the body
- The brain actually makes more cholesterol than any other organ per se, way more than the liver even

Tom explains, “*If I gave you a dumb question: I got this body here and I want to find out where all the cholesterol is, where should I go? Open the skull and take out the brain. That’s where you’re going to find the most cholesterol*.”

![](https://peterattiamd.com/wp-content/uploads/2025/02/f20-td7.png)

**Figure 20. Cholesterol in the brain**.

- Wow, obviously cholesterol is crucial to the brain
- The brain is made up of a lot of cells (all of which have important functions)
- What’s on the surface of a neuron? Free cholesterol and phospholipids
- Evolution figured out a long time ago that the brain needs cholesterol
- We’re not going to make the brain dependent on cholesterol that’s floating around the plasma or what’s in your liver or your intestine
- We’re going to let the brain make all the cholesterol it needs

***To make a long story short, every cholesterol molecule that’s in the brain got there by de novo synthesis in the brain***

- Not a single molecule of cholesterol was delivered to the brain from the periphery, meaning none of that floating around our plasma leaves the plasma and enters the brain
- Where is all the cholesterol in our plasma?
- It’s inside of a lipoprotein floating in the plasma (explained earlier)
- We measure lipids in the plasma, but there is no cholesterol carrying particle in the plasma that crosses the blood-brain barrier for delivery to the brain
- There is a rapid turnover of cholesterol in the periphery
  - Cells make it
  - They get rid of what they don’t need
  - It’s brought back to the liver for the liver to decide what to do with it
  - The turnover time for cholesterol in the plasma is 2-3 days
- If a cholesterol molecule is synthesized in the brain, what is its half-life? 5 years
- If a half-life is a given number, the total brain resonance time of that cholesterol molecules: you multiply that by 7
  - Some cholesterol molecules last up to 30 years once they’re synthesized in the brain
- That’s why cholesterol synthesis in the brain starts in utero
- Early on, mom’s supplying the little fetal brain with a lot of cholesterol, but very rapidly (2nd, 3rd trimester) those brain cells start making their own cholesterol
- Once a child is born, there’s a lot of cholesterol synthesis going on by virtually every cell that exists in the brain

**Somewhere between the ages of 5-10, the brain has made all the cholesterol it needs, and then only 2 cell types continue to make cholesterol: oligodendrocytes and astrocytes**

- In utero and in childhood, neurons produce a lot of cholesterol, but at a certain age the neurons have more work to do
- Cholesterol synthesis is a super energy-driven process
  - Every cholesterol molecule requires 27 molecules of ATP to produce
  - Neurons need ATP for a lot of other functions

*1 –* [*Oligodendrocytes*](https://en.wikipedia.org/wiki/Oligodendrocyte) *make the most cholesterol*

- What does the cholesterol they make become?
- [Myelin](https://en.wikipedia.org/wiki/Myelin), which coats every nerve ending, every axon and dendrite in your body
- Those oligodendrocytes are big-time cholesterol producers, but they make all their cholesterol go to myelin
  - They don’t send any cholesterol to neurons

*2 –* [*Astrocytes*](https://en.wikipedia.org/wiki/Astrocyte) *are the sole maker of cholesterol that supplies the neurons, once the neuron stops making it*

- How would an astrocyte send cholesterol over to the neurons?

**The brain has to have a lipoprotein system just like the periphery does** Between astrocytes and neurons it’s basically brain interstitial fluid, a sort of loose connective tissue called the **matrisome** [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/02/f21-td7.png)

**Figure 21. Location of the matrisome in the central nervous system**.

- If astrocytes synthesize cholesterol, they have to package it inside of a brain lipoprotein, secrete that lipoprotein, which swims through the matrisome and goes over to the neuron
- Guess what the neuron expresses? LDL receptors, LDL receptor-related protein, or something called the scavenger receptor
  - All of which can bind to the type of lipoprotein that an astrocyte produces

*The main difference in the brain’s lipoprotein delivery system is the structural protein*

- In the periphery, it’s apoB or apoA-I
- In the brain, it’s apoE

![](https://peterattiamd.com/wp-content/uploads/2025/02/f22-td7.png)

**Figure 22. Lipid and lipoprotein pathways in the brain**.

***When an astrocyte makes an lipoprotein, it’s an apoE containing lipoprotein, and they’re much smaller than the particles we find in the periphery***

- If we put them in a centrifuge, they have the density of a high-density lipoprotein that floats around the periphery

**⇒** ApoE lipoproteins in the brain are often called brain HDLs

- But don’t confuse brain HDLs with peripheral HDLs because most of the brain HDLs have apoE as their structural protein
  - In the periphery, they have apoA-I

**Here’s where the story gets a little more complicated**

- What is the smallest apolipoprotein the body can make?
- It’s actually apolipoprotein A-I, which is why an HDL needs 4 or 5 of them
- If apoA-I can dissociate from an HDL (and we do have free HDL in the plasma that’s measurable), it is small enough that it can cross the blood-brain barrier
- And once it joins the blood-brain barrier, what is the small apoA-I looking for?
- An HDL buoyancy particle
- So it joins with the apoE particles

***The brain lipoproteins are all apoE, or they’re all apoE plus apoA-I; and you can have multiple copies of each of those [proteins] on those particles***

**⇒** ApoA-I can bind to an LDL receptor or the scavenger receptor (same with the apoE), and the neuron can grab them and either internalize them or delipidate them

- The neuron gets its cholesterol and the neuron’s happy
- Then the delipidated particles can go right back and fill up at the astrocyte again
- So that’s brain cholesterol transformation

## The impact of the ApoE genotype on brain health and Alzheimer’s disease risk [1:46:00]

**Worry about patients who carry the** ***APOE4*** **allele**

- We know that’s associated with [AD](https://en.wikipedia.org/wiki/Alzheimer%27s_disease)

***The brain HDLs carrying apoE4 are dysfunctional (just like we discussed with dysfunctional HDLs in the plasma)***

- So if your brain makes [apoE4 instead of apoE3 or apoE2](https://en.wikipedia.org/wiki/Apolipoprotein_E#Polymorphisms), you’re not going to have the best brain HDL particles
- Not only do brain HDL particles carry cholesterol back and forth, if [amyloid](https://en.wikipedia.org/wiki/Amyloid) or [tau](https://en.wikipedia.org/wiki/Tau_protein) is being produced in a neuron, they can grab it and transfer it over to microglia
  - [Microglia](https://en.wikipedia.org/wiki/Microglia) are brain immune cells, which can get it and take it down and get rid of it in the brain lymphatics
- So your *APOE* genotype certainly affects our VLDLs and chylos in the plasma
  - That’s a lecture for another day, because that’s not that common

**⇒** But in the brain you only have apoE containing lipoproteins so you don’t want to have apoE4

**Peter’s summary**

- People listening are familiar with the *APOE4* gene, but just to reiterate, you have 2 copies of these genes (just as you do for every gene)
- This is a gene that exists in [3 isoforms](https://en.wikipedia.org/wiki/Apolipoprotein_E#Polymorphisms): E2, E3, and E4
  - None of these are considered mutations
  - These are the 3 types that occur in nature
- There are 6 possible combinations and 3 of these include at least 1 copy of E4: E2-E4, E3-E4, and E4-E4

***We know epidemiologically that there’s a clear increase in the risk of Alzheimer’s disease as you move from 2-4 to 3-4 to 4-4***

- We are going back and forth between discussion of the gene and the protein
- If you have an *E4* gene or an *E3* gene or an *E2*, whichever combinations you have, you still make an apoE protein
  - What’s different is how that protein looks

If Peter’s memory is correct, it’s only a [single amino acid substitution](https://pmc.ncbi.nlm.nih.gov/articles/PMC7104324/#:~:text=Only%20a%20single%20amino%20acid%20difference%20exists%20between%20APOE3%20(Cys112)%20and%20APOE4%20(Arg112)%20resulting%20in%20a%20conformational%20change%20which%20affects%20binding%20to%20APOE%20receptors%2C%20lipids%2C%20and%20amyloid%20%5B9%5D) between each of these [highlighted in the figure below in the yellow oval and black arrows]

![](https://peterattiamd.com/wp-content/uploads/2025/02/f23-td7.png)

**Figure 23. ApoE protein structure and the amino acid differences in the E2, E3, and E4 variants**.

***This amino acid difference in the apoE4 protein gives it less affinity for doing this job of transferring cholesterol from astrocytes to neurons, and this is a very important explanation of why people with an APOE4 gene are at increased risk***

- This is not to say it is a causative gene, it’s not a deterministic gene
- It’s not a gene that if you have 1 copy or 2 copies of the *APOE4* gene, you’re going to get Alzheimer’s disease

Peter explains, “*This just explains why there’s a greater susceptibility and why an individual who has 1 or 2 APOE4 genes needs to work that much harder on all of the other variables that factor into AD*.”

To Tom’s point, “*Why does this not really play as much of a role in the periphery?*”

- We could save that for another day, but it sort of does in the edge cases, and that’s why we see a higher incidence of ASCVD in *APOE4* carriers
- Tom alluded to it, but only the astute listener will remember it when he talked about the apoE and the conformational change of lipoprotein
- Peter just wanted to interject that point so people knew the relationship between the genotype and the phenotype of the structural [apoE] protein

**Tom continues to explain the pathophysiology of of apoE4**

- That single amino acid change just affects the shape of the protein
- So it no longer binds where it should and it screws up its so-called functionality of the particle

## How the brain manages cholesterol through specialized pathways, and biomarkers to track cholesterol health of the brain [1:50:30]

**Recent developments regarding cholesterol homeostasis in the brain**

- This story is in its infancy, and this is how we understand it in September of 2024
- We know if the brain can’t get rid of cholesterol, that is associated with one of the characteristics of people with dementia or Alzheimer’s disease
- There comes a point where too much cholesterol in the brain can be bad news, but because cholesterol synthesis is so crucial to the brain (he’ll come back to this), you would never want to restrict cholesterol synthesis to a severe degree
- The neuron is interesting because in adulthood it gets its cholesterol from these apoE-containing particles

**⇒** But if the neuron wound up with too much cholesterol, that by itself would kill the cell

- Just like too much cholesterol in any peripheral cell (the liver) is lipotoxic

*The neuron is the one cell in the brain that was given an enzyme that it can transform cholesterol molecule into a metabolite that’s called an* [*oxysterol*](https://en.wikipedia.org/wiki/Oxysterol) [such as [24S-OH cholesterol](https://en.wikipedia.org/wiki/24S-Hydroxycholesterol), shown exiting the brain in the previous figure]

- Oxysterols are also called [bile acids](https://en.wikipedia.org/wiki/Bile_acid)
- The liver can change cholesterol to an oxysterol, which sends it right down the bile acid synthesis pathway and the liver dumps it in the bile and we excrete it fecally

Tom asks, “*So if the neuron can change cholesterol to an oxysterol, is it possible for that oxysterol to leave the neuron and enter the plasma?*”

- That would be a way of the central nervous system to get rid of cholesterol
- Now, wait a minute, that’s a lipid, and lipids can’t pass through that blood-brain barrier
- The neuron makes these oxysterols that’s basically a sterol with extra oxygen molecules attached, something called [24S-hydroxycholesterol](https://en.wikipedia.org/wiki/24S-Hydroxycholesterol)
- For those of you who’ve listened to our first podcast, you know cholesterol at one end has a hydroxy group, and that’s what makes it somewhat water-soluble, but the other end of the cholesterol molecule has no hydroxy, it’s all lipids
- If we could stick another hydroxy group on the tail of the cholesterol molecule that has a hydroxy group at both ends, it actually becomes a **rare hydrophilic lipid**
  - It’s a lipid that’s soluble in water and it has no trouble passing through the blood-brain barrier
- Once it enters the blood-brain barrier, it’s in plasma and it either rapidly binds to albumin or to any lipoprotein that’s passing by, and both the albumin or the lipoprotein brings that oxysterol to the liver, which converts it to a bile acid and excretes it

***The brain can actually get rid of sterols in a fortuitous way by sending it down to the liver, which makes a bile salt from it*** Only neurons have this enzyme, [24S-hydroxylase](https://en.wikipedia.org/wiki/Cholesterol_24-hydroxylase)

![](https://peterattiamd.com/wp-content/uploads/2025/02/f24-td7.png)

**Figure 24. How neurons create 24S-OH cholesterol so it can pass the blood brain barrier for disposal by the liver**.

**⇒** People think if we measure 24S-hydroxycholesterol in the bloodstream and it’s high, we know the brain’s trying to get rid of cholesterol and it’s a **biomarker of brain cholesterol health** because you really should have trivial amounts of that in the bloodstream, and it is easily measurable with mass spectrometry

**Back to the astrocyte and the neuron**

- When our [cells make cholesterol](https://en.wikipedia.org/wiki/Cholesterol#Biosynthesis_and_regulation), there’s a bunch of original steps that go to a linear molecule, and then it starts to form a cyclic molecule later called sterols, and the ultimate sterol is cholesterol
- But there’s many steps of the sterol ‒ one sterol becomes another one, becomes another one, becomes another one
- The penultimate (next to last sterols) that ultimately will transform into cholesterol are either lathosterol or desmosterol
- As it turns out (and it’s lucky for us), [lathosterol](https://en.wikipedia.org/wiki/Lathosterol) is the major pathway of peripheral cell cholesterol synthesis
  - When your liver makes cholesterol, it goes through the lathosterol pathway
  - Same with most of the cells in your body

*Who uses the desmosterol pathway? Why did evolution give us two cholesterol synthesis pathways?*

- Because cholesterol is essential for human life
- God forbid you had some genetic defect where you knocked out one synthesis pathway, you’ve still got another, so you’re still survivable

**⇒** The [desmosterol pathway](https://pmc.ncbi.nlm.nih.gov/articles/PMC4501332/#:~:text=The%20Bloch%20pathway%2C%20indicated%20by%20solid%20black%20arrows%2C%20is%20shown%20on%20the%20left.), although it could be used by any cell, is primarily used by the brain astrocytes, also in the periphery by the steroidogenic tissue

- In your brain, can we measure serum desmosterol?
- Would it reflect what’s going on in the brain?
- Actually, we know it does because people have done the studies where they’ve done spinal taps, analyzed CSF desmosterol, and it correlates incredibly well with serum desmosterol

***Serum desmosterol is a biomarker reflective of the desmosterol synthesis pathway*** **⇒** The desmosterol synthesis pathway is called the **Bloch pathway** and the lathosterol pathway is called the **Kandutsch-Russell pathway** [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/02/f25-td7.png)

**Figure 25. Two pathways can be used for cholesterol synthesis in the body, the Kandutsch-Russell pathway or Bloch pathway**. Image credit: Tom Dayspring

***Astrocytes primarily use the Bloch pathway (the desmosterol pathway) and in adults, astrocytes are the supplier of cholesterol to the neurons***

- If for some reason the astrocyte fails, a neuron can make cholesterol in an emergency, and the neuron uses the Kandutsch-Russell pathway
  - But in adults, this pathway is inactive (for the most part)
- That’s why we don’t measure lathosterol ‒ lathosterol is all coming from peripheral cells

*Why is Tom telling you all of this?*

- Peter speculates that the reason that the place we see desmosterol in the periphery (in the steroidal tissue) is that that’s the tissue that has the highest demand for cholesterol production
  - Maybe suggesting that the desmosterol pathway is more suited to a high demand pathway vis-a-vis the astrocytes and the steroidal tissue
- Tom thinks he’s right

## How statins might affect brain cholesterol synthesis and cognitive function, and alternative lipid-lowering strategies for high-risk individuals [1:57:30]

**A word on** [**statins**](https://en.wikipedia.org/wiki/Statin) **and “brain fog”**

- Anybody who’s ever prescribed a statin to people knows there’s an extreme minority of people who develop “brain fog”
  - It’s even in the package insert
  - People will come back and say, “*Doc, since you started this, I’m not right. I’m not thinking right. I’m not calculating right. My brain is in a fog*.”
- We had no clue what caused that
- Invariably would stop the statin, and try another one
- It usually occurred [again] (or if it didn’t, fine), then we’d have to figure out other ways to lower LDL-cholesterol
  - Which was not easy years ago

*Tom’s hypothesis on these people who get “brain fog” on statins*

- He wishes he had desmosterol levels on them
- Could some people be very sensitive to the effects of a statin
- We know in the periphery, over-synthesizers respond incredibly well with a statin, hypo-synthesizers do not
- There was an [epidemiologic study](https://pmc.ncbi.nlm.nih.gov/articles/PMC4876914/) where they correlated low serum desmosterol with a higher incidence of cognitive impairment in [Alzheimer’s disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease)

> “*People who had low serum desmosterol had a much higher incidence of cognitive impairment in Alzheimer’s disease, which would lead simply to the hypothesis that serum desmosterol is a usable biomarker to say: is somebody at risk for Alzheimer’s disease?*”‒ Tom Dayspring

- And this goes back to when Tom met [Richard Isaacson](https://ind.org/team) with Peter: they started throwing these hypotheses around
- Until recently, statins were our only game in town
- So if we write a statin (especially a higher dose) and if desmosterol was dropping low, we thought, “*Maybe you don’t want to inhibit cholesterol synthesis in the brain to that degree*.”
  - We’d use an arbitrary cutoff point, the 20th percentile
  - Could we attack apoB another way?

***In people that we know are likely prone to dementia and cognitive impairment, we would watch desmosterol incredibly closely in that population***

- The E4 carriers
- People maybe with strong family histories
- People that have other identifiable traits that make us think they’re prone to AD

**If the astrocyte is not making cholesterol because it’s being over-suppressed by a statin, the neuron would be getting less cholesterol**

- The neuron would convert none of that cholesterol to 24S-hydroxycholesterol because it’s trying to conserve every cholesterol molecule it can
- Tom thinks if you were somebody who could measure 24S-hydroxycholesterol in the serum, you would not see it in somebody who had cholesterol synthesis suppression in the brain
- This all has to be worked out in future clinical trials, and there are some looking at this right now
  - So one day we’ll be a lot smarter on this

**Right now, you could measure desmosterol and perhaps use that as a cautionary marker**

- 1 – If they’re not on a drug and it’s low, if you haven’t done an apoE4 genotype, you might look at it
- 2 – If it is somebody who has a propensity of desmosterol and you have to use a statin, maybe you want to watch that

**The good news about drugs used to treat high cholesterol**

- If we have to use a statin, we start with low dose statins
- We have very little use for the high dose statin in the year 2024 because none of the other apoB lowering drugs (be it [bempedoic acid](https://en.wikipedia.org/wiki/Bempedoic_acid), [ezetimibe](https://en.wikipedia.org/wiki/Ezetimibe), certainly [PCSK9 inhibitors](https://en.wikipedia.org/wiki/PCSK9#Inhibitors)) get into the brain and suppress cholesterol synthesis
- We have many ways of lowering apoB if we were a little fearful of low desmosterol in a patient prone to AD or so

**Final thoughts on brain lipids**

- ApoE is a big player in the brain and there are different types of the apoE protein [discussed earlier with variants E2, E3, E4]
- Cholesterol homeostasis has a lot to do with what is in the peripheral cells
  - We can look at markers of synthesis and markers of cholesterol absorption
  - These are not at play in the brain

**⇒** The brain is not absorbing cholesterol from your gut

**What is our hypothesis around the hydrophobicity of various statins and do we think that certain statins are more likely to cross the blood-brain barrier?**

*Are there certain statins that should be ignored in patients with marginal desmosterol?*

- Thoughts on this have changed, early on (maybe even in the podcast with Tom in 2018) we were talking about hydrophilic and lipophilic statins
  - The lipophilic ones can pass right through the barrier a little easier than the hydrophilic one (which need receptors to pull them in)
- Subsequent analysis has shown all statins get into the brain ultimately, once you have a steady state statin level in the blood,and they all have the ability to suppress cholesterol synthesis in the brain
- Before everybody says, “*Oh my God, I’m stopping my statin tomorrow. I can’t get a desmosterol level.*”
  - They’re available if you look for them
- In general, if you analyze all of the statin data (the many trials be they observational or randomized control), there is no signal whatsoever that in a population that statins worsen or cause cognitive impairment or Alzheimer’s disease
  - There’s a few studies that even suggest that statins perhaps lower [the risk], maybe that’s through atherosclerotic cerebrovascular disease (who knows?)

***In the overwhelming vast majority of people, statins are not hurting the brain***

**⇒** Desmosterol is a biomarker that you might follow in patients subject to dementia who are on a statin [concern about it dropping low]

- Peter covered this at length in a previous AMA [[AMA #60](https://peterattiamd.com/ama60/) and [AMA #46](https://peterattiamd.com/ama46/#:~:text=When%20we%20go%20and%20do%20this%20on%20Alzheimer%E2%80%99s%20dementia%20specifically%2C)], and he went through every meta-analysis on this topic
- [In a [newsletter](https://peterattiamd.com/does-low-cholesterol-cause-cognitive-impairment-part-ii/), Peter discusses his concern with low desmosterol levels in patients with cognitive symptoms]

**It’s important for people to understand that there has not been any statin trial where the primary outcome was dementi**a

- It has always been cardiovascular disease
- But there have been dozens of trails where the secondary outcomes are dementia
- These studies were almost all done in the setting of trying to determine if lipophilic versus hydrophilic statins were more or less or better
- The answer that always emerged: it didn’t seem to matter
  - Which of course makes sense if you understand now that they probably all cross the blood-brain barrier
- The question remains: will there ever be a study done that tests this question specifically as the primary outcome?
  - In other words, where the study is powered to ask the question: does the use of a statin increase, decrease or have no effect on the risk of Alzheimer’s disease and dementia?
- Or will we instead be forced to rely on these secondary outcomes which are always subject to some potential misinterpretation?
- Peter takes much more comfort in knowing that they are all either neutral or favorable, but again, that remains a bit of an unknown
- It might be that on average it’s having no effect on the brain, or it’s having a beneficial effect through the vascular system
- But there might be edge cases that are not being captured in large clinical trials based on hundreds of thousands of people, and it might be those patients in whom a little extra knowledge goes a long way vis-a-vis cholesterol synthesis in the brain

Peter’s final point, “*What a privilege it is to be practicing medicine in 2024 when we don’t have only statins, but we have ezetimibe, we have bempedoic acid, we have short-acting PCSK9 inhibitors. We now have long-acting PCSK9 inhibitors. We have ASOs around the corner. There really is no need for a patient to ever endure a side effect of lipid-lowering medication today.*”

> “*We can lower everybody’s lipids without side effects, and that’s only going to become more and more true in the next decade*.”‒ Peter Attia

**Tom reiterates this is not a reason to not use statins**

- We’re not evaluating populations
- We treat people one at a time
- So in somebody where we’re worried about dementia, we have a biomarker that’s probably usable
- If you can’t take the statin, we can get to your apoB goal pretty easily with the other things that we know are not affecting the brain
- Wouldn’t it be nice to have a randomized blinded trial to answer this question?
  - All statins are generic
  - What pharma company that’s going to spend a billion dollars to prove or disprove what statins do to cognitive functions of the brain? (it’s not going to happen)

***We can use these oddball biomarkers in individual patients, and that is part of medicine 3.0 where we use a little smarter knowledge to try and do a better job***

**We don’t use high-dose statins**

- We’re not treating acute coronary syndrome patients where maybe you want to be on a high-dose statin for X amount of time
- You can get most of the apoB lowering with statin with the baby dose
  - This has been proven in trial after trial
  - Most of the LDL receptor upregulation occurs with the lowest dose that inhibits cholesterol synthesis
  - You start doubling, tripling, quadrupling, you might get another 6, 7%, not the original 30% lowering or so
- In today’s world, why do you ever have to double, triple, or quadruple the dose of a statin when we have all these other additive drugs?

***You take a baby statin (Tom’s acronym for a low-dose statin), and you combine it with a*** [***ezetimibe***](https://en.wikipedia.org/wiki/Ezetimibe)***,*** [***bempedoic acid***](https://en.wikipedia.org/wiki/Bempedoic_acid)***, or*** [***PCSK9 inhibitor***](https://en.wikipedia.org/wiki/PCSK9#Inhibitors)***, and you’ve got a military machine that can destroy apoB***

Tom explains, “*Nowadays, we have so many options, which we didn’t have in the heyday.*”

**Where did all this hydrophilic, lipophilic stuff come from?**

- The 1st 2 competitive statins on the market were [Simvastatin [brand name Zocor]](https://en.wikipedia.org/wiki/Simvastatin)
  - Which was Merck’s most potent statin, more potent than their [Lovastatin](https://en.wikipedia.org/wiki/Lovastatin) (brand name Mevacor)
  - So everybody jumped on Simvastatin
- Bristol Myers Squibb made [Pravastatin](https://en.wikipedia.org/wiki/Pravastatin): hydrophilic
- There was a lot of thought looking at other biomarkers, even catabolism
  - Thoughts that the hydrophilic statins were safer than the others

*Was there a little more brain fog with Mevacor or Zocor than there was with Pravachol?*

- Anecdotally, people said that
- Tom never saw a trial that looked at that

***Hydrophilic versus a lipophilic statins all came from pharma competitiveness***

## Exciting advancements in therapeutics, diagnostics, and biomarkers coming in the next few years [2:09:30]

**What are you most looking forward to in the next 3-5 years?**

Tom’s initial response, “*I hope I’m still here in 5 years, and I hope I’m still capable of having these discussions with you.*”

- He thinks we’ve got the apoB solved
- Other types of **PCSK9 [inhibitors]** are coming down the pipe that are a little more potent on LDL-C than the current ones
  - They’re working on an oral PCSK9 [inhibitor]
  - He’s more excited about that for people with rare genetic disorders that are driving their lipids and lipoproteins out of whack (but that’s a minority of patients)

**Diagnostically, Tom can’t ever see it coming**

- He would hope that there might be some usable **HDL functionality tests**, which would make us a little smarter perhaps on giving a patient some insight to their HDL markers
- Would there be other types of earlier markers?
  - He doesn’t know that we’re going to get an earlier imaging marker than a [CTA](https://en.wikipedia.org/wiki/Computed_tomography_angiography) right now without being invasive or maybe optimal tomography and stuff is showing us stuff within the vessel wall

Tom explains, “*Who knows what imaging is going to bring to the table? But that probably won’t be in widespread use when it first comes out*.”

- The inflammatory markers we have now: you can use them, but does everybody understand that whatever inflammatory marker you’re looking at, that is not the goal of therapy?
- apoB is the goal of therapy

> “*If you make apoB low enough, the atherosclerotic process in the artery wall would dry up (scar up) and there’d be no more inflammation in the artery wall.*”‒ Tom Dayspring

**Other biomarkers**

- There are other biomarkers coming including certain amino acid biomarkers are being looked at that might give us insight in arterial wall pathology
- Tom would love to see some of these synthesis and cholesterol markers, perhaps even LDL and HDL-triglyceride levels
  - The latter two are simple assays be made available to the general public,
- He would like to see more widespread availability of the sterol biomarkers, and you need some education on how to use them

## Recent consensus statements on apoB and Lp(a) from the National Lipid Association (NLA) [2:12:30]

**Recently, the NLA published their first** [**statement**](https://www.lipidjournal.com/article/S1933-2874(24)00240-X/fulltext) **on apoB**

- Tom has discussed a lot of info on why we use it, but if you want to get down into the weeds, that’s a statement to read
- The overwhelming majority of practitioners don’t know what apoB is (including those in the cardiology community)

Tom explains, “*You can’t get a guideline declaring everybody stop doing lipid profiles, just get apoB because nobody would know what you’re talking about*.”

**The NLA put out an updated expert** [**statement**](https://www.lipidjournal.com/article/S1933-2874(24)00033-3/fulltext) **on Lp(a)** **⇒** Everybody should get Lp(a) measured once in their life

![](https://peterattiamd.com/wp-content/uploads/2025/02/f26-td7.png)

**Figure 26. NLA statement on Lp(a) risk**. Image credit: [*Journal of Clinical Lipidology* 2024](https://www.lipidjournal.com/article/S1933-2874(24)00033-3/fulltext)

- In 2024, there are several drugs coming to lower Lp(a), but we have no idea whether they’re going to reduce [MACE](https://en.wikipedia.org/wiki/Major_adverse_cardiovascular_events) or not
  - We’ll get the readout next year
- If lowering Lp(a) fails to reduce MACE, then it just becomes a risk marker like CRP or something

*A lot of labs are not doing the right type of Lp(a) testing*

- It’s a cheap test, but apparently there are third-party payers giving doctors grief for ordering it
  - The majority of PCPs
- A lot of cardiologists have no idea what Lp(a) is
  - What good does it tell you to go and get it tested if you show up in your doctor’s office and he goes, “*It’s nothing. Don’t worry about it.*”

> “*I’m hoping for better education among doctors in the lipid world*.”‒ Tom Dayspring

**Peter has done his part to educate doctors**

- Last year, Peter was made an honorary lifetime member of the NLA
- Tom suggests you go to their [website](https://www.lipid.org/awards/past_winners#:~:text=Honorary%20Lifetime%20Membership%20Award) and see who else has ever achieved that title
  - It’s the giants of the field who invented the centrifuge or that type of serious analyses
- Why did Peter get it?
  - Peter has probably brought more lipid education to more people than any of those gigantic thought leaders ever did
- It was a huge honor to receive that award from the NLA last year, and Peter explains, “*That’s obviously due to your mentorship and the mentorship of others. So thank you very much and thank you obviously for your continued education… You’re an absolutely tireless educator. Your zeal for teaching, your generosity of knowledge is really unparalleled.*”
- They both joke about he first time they met way back in Reno ‒ a total chance coincidence and certainly one of the more fortuitous things that’s happened to them both

**Back to Tom’s predictions**

Tom explains, “*Like always, Peter, we’re going to know a lot more. Some of the stuff we said today is probably going to sound like idiocy in 5 or 10 years, but I think a lot of it’s going to be right*.”

- When Tom looks back at his life he’s been a lot more right than wrong
  - And he’s prognosticated about a lot of stuff

---

## Selected Links / Related Material

**5-part series of** ***The Drive*** **with Tom Dayspring**: [1:00, 3:30]

- [#20 – Tom Dayspring, M.D., FACP, FNLA – Part I of V: an introduction to lipidology](https://peterattiamd.com/tomdayspring1/) (October 15, 2018)
- [#21 – Tom Dayspring, M.D., FACP, FNLA – Part II of V: Lipid metrics, lipid measurements, and cholesterol regulation](https://peterattiamd.com/tomdayspring2/) (October 16, 2018)
- [#22 – Tom Dayspring, M.D., FACP, FNLA – Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins](https://peterattiamd.com/tomdayspring3/) (October 17, 2018)
- [#23 – Tom Dayspring, M.D., FACP, FNLA – Part IV of V: statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain](https://peterattiamd.com/tomdayspring4/) (October 18, 2022)
- [#24 – Tom Dayspring, M.D., FACP, FNLA – Part V of V: Lp(a), inflammation, oxLDL, remnants, and more](https://peterattiamd.com/tomdayspring5/) (October 19, 2022)

**Another episode of** ***The Drive*** **with Tom Dayspring**: [#129 – Tom Dayspring, M.D.: The latest insights into cardiovascular disease and lipidology](https://peterattiamd.com/tomdayspring6/) (September 21, 2020)

**Pediatric studies showing fatty streaks in the aorta of young children**: [13:00]

- PDAY: [Risk Factors and Progression of Atherosclerosis in Youth](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1853040/) | *The American Journal of Pathology* (R Wissler et al. 1998)
- The Bogalusa Heart Study: [Tulane University: The Bogalusa Heart Study](https://bogalusaheartstudy.org/impact/) (2024)

**Fetal autopsy studies find the beginning of plague development**: [Fatty streak formation occurs in human fetal aortas and is greatly enhanced by maternal hypercholesterolemia. Intimal accumulation of low density lipoprotein and its oxidation precede monocyte recruitment into early atherosclerotic lesions](https://pubmed.ncbi.nlm.nih.gov/9389731/) | *Journal of Clinical Investigation*(C Napoli et al 1997) | [16:30]

**Nuclear magnetic resonance analysis of lipoproteins and signatures associated with insulin resistance**: [Effects of insulin resistance and type 2 diabetes on lipoprotein subclass particle size and concentration determined by nuclear magnetic resonance](https://pubmed.ncbi.nlm.nih.gov/12540621/) | *Diabetes* (W Garvey et al. 2003) | [24:30]

**Insulin clamp studies confirm lipoprotein patterns associated with insulin resistance**: [Lipoprotein Insulin Resistance Index: A Lipoprotein Particle–Derived Measure of Insulin Resistance](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4175429/) | *Metabolic Syndrome and Related Disorders* (I Shalaurova et al. 2014) | [25:30]

**Mendelian randomization supports causal role for apoB in ASCVD**: [Evaluating the relationship between circulating lipoprotein lipids and apolipoproteins with risk of coronary heart disease: A multivariable Mendelian randomisation analysis](https://pubmed.ncbi.nlm.nih.gov/32203549/) | *PLOS* (T Richardson et al 2020) | [35:30]

**Episodes of** ***The Drive*** **about HDL**: [1:29:00]

- [#22 – Tom Dayspring, M.D., FACP, FNLA – Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins](https://peterattiamd.com/tomdayspring3/) (October 17, 2018)
- [#240 ‒ The confusion around HDL and its link to cardiovascular disease | Dan Rader, M.D.](https://peterattiamd.com/danrader/) (January 30, 2023)

**New data remnants**: [Variance in the Composition and Number of VLDL and LDL Particles with Increasing Triglyceride or Increasing ApoB Concentrations](https://www.lipidjournal.com/article/S1933-2874(24)00256-3/fulltext) | *Journal of Clinical Lipidology* (J Cole et al. 2024) | [1:26:30]

**Episode of** ***The Drive*** **with Dan Rader**: [#240 ‒ The confusion around HDL and its link to cardiovascular disease | Dan Rader, M.D.](https://peterattiamd.com/danrader/) (January 30, 2023) | [1:38:00]

**Cholesterol synthesis in the brain**: [Cholesterol metabolism in neurons and astrocytes](https://pubmed.ncbi.nlm.nih.gov/21741992/) | *Progress in Lipid Research* (F Pfrieger, N Ungerer 2011) | [1:56:00]

**Epidemiology study of serum desmosterol and cognitive impairment in Alzheimer’s patients**: [Reduced plasma desmosterol-to-cholesterol ratio and longitudinal cognitive decline in Alzheimer’s disease](https://pmc.ncbi.nlm.nih.gov/articles/PMC4876914/) | *Alzheimer’s & Dementia* (Y Sato et al. 2015) | [1:58:30]

**AMA on data regarding statin use and cognitive decline**: [2:04:00]

- [#306 – AMA #60: preventing cognitive decline, nutrition myths, lowering blood glucose, apoB, and blood pressure, and more](https://peterattiamd.com/ama60/) (June 17, 2024)
- [#251 – AMA #46: Optimizing brain health: Alzheimer’s disease risk factors, APOE, prevention strategies, and more](https://peterattiamd.com/ama46/) (April 17, 2023)

**Newsletter on tracking desmosterol in patients at risk for dementia**: [Does low cholesterol cause cognitive impairment? Part II](https://peterattiamd.com/does-low-cholesterol-cause-cognitive-impairment-part-ii/) (September 26, 2021) | [2:04:00]

**NLA statement on apoB**: [Role of apolipoprotein B in the clinical management of cardiovascular risk in adults: An expert clinical consensus from the national lipid association](https://www.lipidjournal.com/article/S1933-2874(24)00240-X/fulltext) | *Journal of Clinical Lipidology* (D Soffer et al. 2024) | [2:12:30]

**NLA statement on Lp(a)**: [A focused update to the 2019 NLA scientific statement on use of lipoprotein(a) in clinical practice](https://www.lipidjournal.com/article/S1933-2874(24)00033-3/fulltext) | *Journal of Clinical Lipidology* (M Koschinsky et al. 2024) | [2:13:00]**NLA honorary lifetime membership award**: [NLA: Pawt Award Winners](https://www.lipid.org/awards/past_winners#:~:text=Honorary%20Lifetime%20Membership%20Award) (2024) | [2:14:30]

---

## People Mentioned

- [Paul Ridker](https://prevmed.bwh.harvard.edu/paul-m-ridker-md-mph/) (Eugene Braunwald Professor of Medicine, Harvard Medical School and Director of the Center for Cardiovascular Disease Prevention at Physician, Brigham and Women’s Hospital; expert in C-reactive protein) [48:30]
- [Richard Isaacson](https://ind.org/about#team) (Preventive Neurologist at the Institute for Neurodegenerative Diseases. He is a Harvard-trained neurologist who founded and directed the first Alzheimer’s Prevention Clinic in the U.S. in 2013 at Weill Cornell Medicine/NewYork-Presbyterian) [1:37:30]

---

![](https://peterattiamd.com/wp-content/uploads/2018/10/tom-dayspring.jpg)

##### Tom Dayspring, M.D.

Thomas Dayspring MD is a Fellow of both the American College of Physicians and the National Lipid Association and is certified in internal medicine, and clinical lipidology. After practicing in New Jersey for 37 years, in 2012 he moved to Virginia and served as an educational director for a nonprofit cardiovascular foundation and until mid-2019 as a Chief Academic Advisor for two major CV laboratories. Since then, he has served as a virtual cardiovascular / lipidology educator. Career-wise he has given over 4000 domestic (in all 50 states) and several international lectures, including over 600 CME programs on atherothrombosis, lipids/lipoproteins (and their treatment), vascular biology, biomarker testing, and women’s cardiovascular issues. He has authored several manuscripts and lipid textbook chapters and performed several podcasts. For several years he was an Associate Editor of the *Journal of Clinical Lipidology*. He was the recipient of the 2011 National Lipid Association’s President’s Award for services to clinical lipidology and the 2023 Foundation of NLA Clinician/Educator Award. He has over 38K followers on his educational Twitter (X) feed ([@Drlipid](https://x.com/drlipid)). He has Gold Heart Member status as a professional member of the American Heart Association and serves as a Social Media Ambassador for the European Atherosclerosis Society and for the National Lipid Association.