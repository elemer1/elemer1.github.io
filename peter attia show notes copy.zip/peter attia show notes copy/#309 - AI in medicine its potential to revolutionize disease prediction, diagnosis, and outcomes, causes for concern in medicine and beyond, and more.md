# #309 ‒ AI in medicine: its potential to revolutionize disease prediction, diagnosis, and outcomes, causes for concern in medicine and beyond, and more | Isaac Kohane, M.D., Ph.D.

**Source:** [https://peterattiamd.com/isaackohane/](https://peterattiamd.com/isaackohane/)

---

Isaac “Zak” Kohane, a pioneering physician-scientist and chair of the Department of Biomedical Informatics at Harvard Medical School, has authored numerous papers and influential books on artificial intelligence (AI), including The AI Revolution in Medicine: GPT-4 and Beyond. In this episode, Zak explores the evolution of AI, from its early iterations to the current third generation, illuminating how it is transforming medicine today and unlocking astonishing possibilities for the future. He shares insights from his unconventional journey and early interactions with GPT-4, highlighting significant AI advancements in image-based medical specialties, early disease diagnosis, and the potential for autonomous robotic surgery. He also delves into the ethical concerns and regulatory challenges of AI, its potential to augment clinicians, and the broader implications of AI achieving human-like creativity and expertise.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/isaackohane/the_Drive_public.png)

Play

#309 ‒ AI in medicine: its potential to revolutionize disease prediction, diagnosis, and outcomes, causes for concern in medicine and beyond, and more | Isaac Kohane, M.D., Ph.D.

#309 ‒ AI in medicine: its potential to revolutionize disease prediction, diagnosis, and outcomes, causes for concern in medicine and beyond, and more | Isaac Kohane, M.D., Ph.D.

1x15s30s

0:001:55:15

## We discuss:

- Zak’s unconventional journey to becoming a pioneering physician-scientist, and his early interactions with GPT-4 [2:15];
- The evolution of AI from the earliest versions to today’s neural networks, and the shifting definitions of intelligence over time [8:00];
- How vast data sets, advanced neural networks, and powerful GPU technology have driven AI from its early limitations to achieving remarkable successes in medicine and other fields [19:00];
- An AI breakthrough in medicine: the ability to accurately recognize retinopathy [29:00];
- Third generation AI: how improvements in natural language processing significantly advanced AI capabilities [32:00];
- AI concerns and regulation: misuse by individuals, military applications, displacement of jobs, and potential existential concerns [37:30];
- How AI is enhancing image-based medical specialties like radiology [49:15];
- The use of AI by patients and doctors [55:45];
- The potential for AI to augment clinicians and address physician shortages [1:02:45];
- The potential for AI to revolutionize early diagnosis and prediction of diseases: Alzheimer’s disease, CVD, autism, and more [1:08:00];
- The future of AI in healthcare: integration of patient data, improved diagnostics, and the challenges of data accessibility and regulatory compliance [1:17:00];
- The future of autonomous robotic surgery [1:25:00];
- AI and the future of mental health care [1:31:30];
- How AI may transform and disrupt the medical industry: new business models and the potential resistance from established medical institutions [1:34:45];
- Potential positive and negative impacts of AI outside of medicine over the next decade [1:38:30];
- The implications of AI achieving a level of creativity and expertise comparable to exceptional human talents [1:42:00];
- Digital immortality and legacy: the potential to emulate an individual’s personality and responses and the ethical questions surrounding it [1:45:45];
- Parting thoughts [1:50:15]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Isaac Kohane goes by Zak and is a physician scientist and chair of the department of Biomedical Informatics at Harvard Medical School
  - He’s an Associate Professor of Medicine at Brigham and Women’s Hospital
- Zak has published several hundred papers in the medical literature and authored the widely-used books [*Microarrays for Integrative Genomics*](https://www.amazon.com/Microarrays-Integrative-Genomics-Computational-Molecular/dp/026211271X/ref=sr_1_1?crid=1M99CDBB56KKR&dib=eyJ2IjoiMSJ9.bctrHwKKYhUXuAjdyGrVOJcu37FhtcTKvtLR9BAMA70.6jVbwk7KhbpJCMM0jEdJxu0c6_VUgNyqnw5LEVMqwvE&dib_tag=se&keywords=Microarrays+for+Integrative+Genomics&qid=1715792407&sprefix=microarrays+for+integrative+genomics%2Caps%2C135&sr=8-1) and [*The AI Revolution in Medicine: GPT-4 and Beyond*](https://www.amazon.com/AI-Revolution-Medicine-GPT-4-Beyond/dp/0138200130/ref=sr_1_1?crid=18XKW0M8TFBAM&dib=eyJ2IjoiMSJ9.uCwzKQlwaOhpfGx03Yu7DQHjUMSi1ForqHMK6pZsyzPv-sjQyt6Cwx5xgDkcktBiXwcrIeKDG2sbzgJsCg5uJf5p25wWa4OW0WnPZ3F0vJc20WakUKu52ku6qNX3VN9x8l3S9oja6nfNj0fm1fYTux7PMWGvcJ9I_105ZUrEnLs.OX6Gf3d_b-ia87DIKhAJ6Xc9norp6EOGkJ-sOtz-gT0&dib_tag=se&keywords=The+AI+Revolution+in+Medicine%3A+GPT-4+and+Beyond&qid=1715792531&sprefix=the+ai+revolution+in+medicine+gpt-4+and+beyond%2Caps%2C147&sr=8-1)
- He is the Editor-in-Chief of the newly launched [*New England Journal of Medicine AI*](https://ai.nejm.org/)
- In this episode we talk about the evolution of AI
  - It wasn’t clear to Peter until this interview that we’re really in the 3rd generation of AI
  - Zak has been part of both the 2nd and current generation
- We talk about AI’s ability to impact medicine today (where is it having an impact), and where will it have an impact in the near term?
  - What seems likely
- We talk about what the future can hold
  - The difference between science fiction and the potential for where we hope it could go
- This is a very interesting podcast for Peter, and a topic that he knows so little about

## Zak’s unconventional journey to becoming a pioneering physician-scientist, and his early interactions with GPT-4 [2:15]

**Give folks a sense of your background. Your path through medical school and training was not very typical**

- Zak grew up in Switzerland
- Nobody in his family was a doctor
- He came to the US, decided to major in biology, and then got nerd sniped by computing in the late 70s, so he minored in computer science
- He goes to medical school, and in the middle of the first year he realized it was not what he expected
  - It’s a noble profession, but it’s not a science (it’s an art)
  - He thought he was going into science
- He bails out for a while to do a PhD in computer science
  - This is in the early 80s, and it’s a heyday of AI (actually a 2nd heyday)
    - We’re currently in the 3rd heyday
  - It was a time of great promise
  - With retrospective scope, it’s very clear that it was not going to be successful
    - But unlike today, we had not released it to the public
    - It was not actually working in the way that we thought it was going to work, and it certainly didn’t scale
- His thesis advisor at MIT ([Peter Szolovits](https://www.csail.mit.edu/person/peter-szolovits)) said, “*Zak, you should finish your clinical training because I’m not getting a lot of respect from clinicians. And so, to bring rational decision making to the clinic, you really want to finish your clinical training.*”
- Zak finished medical school, did a residency in pediatrics and then pediatric endocrinology, which was actually extremely enjoyable
- When he was done, he restarted his research in computing
- He started a [lab](https://zaklab.org/) at Children’s Hospital in Boston and then a center of biomedical informatics at the medical school
- Zak was getting a lot of grants, and like almost every other endeavor, getting money gets attention from the powers that be
- They asked him to start a center and then eventually a new [department of biomedical informatics](https://dbmi.hms.harvard.edu/about-dbmi) that he’s the chair of
  - They now have 16 professors or assistant professors of biomedical informatics
- Zak has been involved in a lot of machine learning projects

**Like everybody else, Zak was taken by surprise by large language models**

- He got an email from [Peter Lee](https://www.microsoft.com/en-us/research/people/petelee/) in October ‘22 (it was right out of a [Michael Crichton](https://en.wikipedia.org/wiki/Michael_Crichton) novel), that said, “*Zak, if you’ll answer the phone, I can’t tell you what it’s about, but it’ll be well worth your while*.”
  - Peter was a Professor of Computer Science at CMU and also department chair there
  - Then, he went to DARPA and then he went to Microsoft
  - He told Zak about GPT-4, and this was before any of us had heard about [ChatGPT](https://en.wikipedia.org/wiki/ChatGPT) (which is initially GPT-3.5)
  - He gets Zak early access to it when no one else knows that it exists, and Zak starts trying it against hard cases
- Zak remembers from his training, being called down to the nursery
  - There’s a child with a small phallus and a hole at the base of the phallus, and they can’t palpate testicles
  - They want to know what to do because Zak is a pediatric endocrinologist

So Zak asked GPT-4 about this case, “*What would you do? What are you thinking about?*”

- It runs him through the whole workup of these very rare cases of ambiguous genitalia
- In this case, it was [congenital adrenal hyperplasia](https://en.wikipedia.org/wiki/Congenital_adrenal_hyperplasia) where the making of excess androgens during pregnancy and then subsequently birth causes the clitoris to swell, form the glans of the penis, of the phallus, and the labia minora to fuse to form the shaft of what looks like a penis
  - But there’s no testicles, there’s ovaries
- There’s a whole endocrine workup with genetic tests, hormonal tests, ultrasound, and it does it all
- Zak explains, “*It really blows my mind, because very few of us in computer science really thought that these large language models would scale up the way they do. It was just not expected*.”
- Talking to [Bill Gates](https://en.wikipedia.org/wiki/Bill_Gates) about this, he told me that his line engineers in Microsoft Research, a lot of his fanciest computer scientists did not expect this
  - But the line engineers at Microsoft were just watching the scale-up, GPT-0, 1, 2, and they just saw it was going to keep on scaling up with the size of the data and with the size of the model
  - And they said, “*Yeah, of course this is going to achieve this kind of expertise*.”

> “*But the rest of us, I think because we value our own intellects so much, we couldn’t imagine how we would get that kind of conversational expertise just by scaling up the model and the data set*.”‒ Zak Kohane

## The evolution of AI from the earliest versions to today’s neural networks, and the shifting definitions of intelligence over time [8:00]

- Zak alluded to the fact that when he was doing his PhD in the early ‘80s, he was in the 2nd generation of AI
- This leads Peter to assume that the 1st generation was shortly following World War II
  - [Alan Turing](https://en.wikipedia.org/wiki/Alan_Turing) and the [Turing test](https://en.wikipedia.org/wiki/Turing_test)

**Talk us through what Alan Turing posited, what the Turing test was and proposed to be, and really what the 1st generation of AI was**

- After World War II, we had computing machines, and anybody who was a serious computer scientist could see that you could have these processes that could generate other processes
  - You could see how these processes could take inputs and become more sophisticated
- As a result, shortly after World War II, we actually had artificial neural networks
  - The [perceptron](https://en.wikipedia.org/wiki/Perceptron), which was modeled on the ideas of a neuron that could take inputs from the environment and then have certain expectations, and if you updated the neuron as to what was going on, it would update the weights going into that artificial neuron
- Going back to Turing, he came up with a test that said essentially if a computational entity could maintain essentially its side of the conversation without revealing that it was a computer and that others would mistake it for a human
  - Then for all intents and purposes that would be intelligent behavior

*There’s been all sorts of additional constraints put on it, and one of the hallmarks of AI is that it keeps on moving the goalposts of what we consider to be intelligent behavior*

- If you had told someone in the ’60s that the world chess masters were going to be beaten by a computer program they’d say, “*Well, that’s AI.*”
  - And then, when [Kasparov](https://en.wikipedia.org/wiki/Garry_Kasparov) was beaten by the [Deep Blue](https://en.wikipedia.org/wiki/Deep_Blue_(chess_computer)) (by the IBM machine), people said, “*Well, it’s just doing search very well. It’s searching through all the possible moves in the future. It also knows all the grandmaster moves. It has a huge encyclopedic store of all the different grandmaster moves. This is not really intelligent behavior*.”
- If you had told people it could recognize human faces and find your grandmother in a picture, on any picture in the internet, they’d say, “*Well, that’s intelligence*.”
  - And of course, when we did it, “*No, that was not intelligent.*”
- And then, when we said it could write a rap poem about Peter Attia based on your web page, and it did that, well, that would be intelligent
  - That would be creative
- But then, if you said it’s doing it based on having created a computational model based on all the text ever generated by human beings, as much as we can gather, which is 1-6 terabytes of data, and this computational model basically is predicting what is the next word that’s going to be said, not just the next word, but of the millions of words that could be, what are the probabilities of that next word, that is what’s generating that rap, there’s people who are arguing that’s not intelligence

***So, the goalposts around the Turing test keep getting moved***

- Zak no longer finds that an interesting topic, because what it’s actually doing and whether you want to call it intelligent or not, that’s up to you
  - It’s like discussing whether a dog is intelligent
  - Is a baby intelligent before it can recognize the consistency of objects?
    - Initially, babies, if you hide something from it, it’s gone; and it comes back, it’s a surprise

*There’s this spectrum of intelligent behavior*

- There’s a very simple computational model of predicting the next word called a [Markov model](https://en.wikipedia.org/wiki/Markov_model)
- Several years ago, people were studying songbirds, and they were able to predict the full song, the next note, and the next note of a song just using a very simple Markov model
- So from that perspective, we think that we’re all very smart, but Zak explains, “*The fact that you and I without thinking too hard about it can come up with fluid speech…*”

*The model now*

- The model is now a trillion parameters
- It’s not a simple Markov model but still a model
- Unfortunately, the late [Kahneman’s](https://en.wikipedia.org/wiki/Daniel_Kahneman) notions of [*Thinking Fast and Slow*](https://www.amazon.com/Thinking-Fast-Slow-Daniel-Kahneman/dp/0374275637/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.KP7SbRzcre9DpN2LWPIgYeuUQQSnHrRQrcy8gnDT93DaBHkr0bqjqHA3Ehi2nCUCmppO57ukRcszaa8FDNmdtlO1niBFO5hb_XhryFMUCiEacXsm0frhrsBmMWiZqeCXBluRId77Px1iosIAZ3DhVor3hK_YY1g1BCrsKBFq93ZP69q9kssm3Ddx8mQNy40uoykuU11LAJzIDUahxf3CpylAFfuRSO7_pl42gEbW038.wgYg0qc_RJhc1UNvAwoeqduge-VJ0oxOZKlkHWid_9Q&qid=1715880183&sr=8-1), and this notion of system 1, which is this pattern in recognition, which is very much similar to what we’re seeing here, and system 2, which is the more deliberate and much more conscious kind of thinking that we pride ourselves on
- But a lot of what we do is this reflexive, very fast pattern recognition

**Advances seem to be happening at a nonlinear pace**

- Peter thinks back to World War II, where we saw rule-based computing come of age
  - Anybody who’s gone back and watched movies about the Manhattan Project or the decoding of all the sorts of things that took place, Enigma, for example, that’s straight rules-based computational power, and we’re obviously at the limits
  - That can only go so far
- It seems that there was a long hiatus before we went from there to maybe what some have called **context-based computation**
  - What your Siri does or Alexa, which is a step quite beyond that
- Then, from there we go to what Zak has already talked about: [Blue](https://en.wikipedia.org/wiki/Deep_Blue_(chess_computer)) or [Watson](https://en.wikipedia.org/wiki/IBM_Watson)
  - Where you have computers that are probably going even 1 step further
- Then, where we are now is [GPT-4](https://en.wikipedia.org/wiki/GPT-4)
- When you look at the output, it’s staggeringly different

Peter asks, “*What was it that was taking place during the period of your PhD? What you’re calling wave 2 of AI, what was the objective, and where was the failure?*”

- The objective in the 1st era was, you wrote computer programs in assembler language (or in languages like [Fortran](https://en.wikipedia.org/wiki/Fortran)) and there was a limit of what you could do
  - You had to be a real computational programmer to do something in that mode
- In **wave 2** in the 1970s, we came up with these rule-based systems where we set rules in what looked like English
  - If there is a patient who has a fever and you get an isolate from the lab, and that bacteria in the isolate is gram positive, then you might have a streptococcal infection with a probability of so-and- so

**The problem with these rule-based systems was several fold**

- With rule-based systems, you’re now programming in the level of human knowledge, not in computer code
- A – You’re going to generate tens of thousands of these rules, and these rules would interact in ways that you could not anticipate
- B – And we did not know enough and we could not pull out of human beings the right probabilities
  - What is the right probability of: you have a fever and you don’t see anything on the blood test? What else is going on?
- There’s a large set of possibilities, and getting all those rules out of human beings ended up being extremely expensive, and the results were not stable
- For that reason, because we didn’t have much data online, we could not go to the next step, which is to have data to actually drive these models

**What were the data sources then?**

- Books, textbooks, and journals as interpreted by human experts
- That’s why some of these were called **expert systems**, because they were derived from introspection by experts who would then come up with the rules, with the probabilities
- For example, there was a program called [MYCIN](https://en.wikipedia.org/wiki/Mycin) run by [Ted Shortliffe](https://en.wikipedia.org/wiki/Edward_H._Shortliffe) out of Stanford, who developed an antibiotic advisor that was a set of rules based on what he and his colleagues sussed out from the different infectious disease textbooks and infectious disease experts
  - It stayed only up to date as long as they kept on looking at the literature, adding rules, fine-tuning it as an interaction between two rules that was not desirable, then you had to adjust that
    - Very labor-intensive: if there’s a new thing, you’d have to add some new rules
    - There’s no way you could keep it up to date
  - It was very hard to keep up, and people didn’t
  - The language it was programmed in was called e-MYCIN (these looked like English)
  - There were no electronic medical records, so it was not informed by what was going on in the clinic

***3 revolutions had to happen in order for us to have what we have today, and that’s why Zak thinks we’ve had such a quantum jump recently***

## How vast data sets, advanced neural networks, and powerful GPU technology have driven AI from its early limitations to achieving remarkable successes in medicine and other fields [19:00]

**In generation 2, were there other industries that were having more success than medicine?**

*Were their applications in the military? Elsewhere in government?*

- Back in the 1970s, there were a whole bunch of computer companies around what we called 128 in Boston
  - These were companies that were famous back then, like [Wang computer](https://en.wikipedia.org/wiki/Wang_Laboratories), like [Digital Equipment Corporation](https://en.wikipedia.org/wiki/Digital_Equipment_Corporation)
  - It’s a very sad story for Boston because that was before Silicon Valley got its pearl of computer companies around it
- Digital Equipment Corporation, built a program called R1, and R1 was an expert in configuring the mini computers that you ordered
  - If you wanted some capabilities, it would actually configure all the industrial components, the processors, the disk, and it would know about all the exceptions and what you needed to know
    - What cabling, what memory, configuration, all that was done
  - It basically replaced several individuals who had that very, very rare knowledge to configure their systems
- It was also used in several government logistics effort
- Although they were successful and used commercially, those efforts were limited
- Because it turns out human beings, once you got to about 3, 4, 5, 6-thousand rules, no single human being could keep track of all the ways these rules couldn’t work
- We used to call this the **complexity barrier**, that these rules would interact in unexpected ways, and you’d get incorrect answers, things that were not commonsensical because you had actually not captured everything about the real world
- And so, it was very narrowly focused
- If the expertise was a little bit outside the area of focus, if let’s say it was an infectious disease program and there was a little bit of influence from the cardiac status of the patient and you had not accurately modeled that, its performance would degrade rapidly
- Similarly, if there was in Digital Equipment a new model that had a completely different part not included and that there were some dependencies that were not modeled, it would degrade in performance

***These systems were very brittle, did not show common sense. They had expert behavior, but it was very narrowly done.***

*There were applications in medicine back then that survived till today*

- For example, already back then we’ve had the systems doing interpretation of [ECGs](https://en.wikipedia.org/wiki/Electrocardiography) pretty competently, at least a first pass until they would be reviewed by an expert cardiologist
- There’s also a program that interpreted what’s called [serum protein electrophoresis](https://en.wikipedia.org/wiki/Serum_protein_electrophoresis), where you look at a protein separated out by an electric gradient to make a diagnosis, let’s say, of myeloma or other protein disorders
- Those also were deployed clinically, but they only worked very much in narrow areas
- They were by no stretch of an imagination general purpose reasoning machines

**Walk us through the 3 things that have taken the relative failures of the 1st and 2nd attempts at AI to get us where we are today**

- 1 – Lots of data
  - We needed to have a lot of online data to be able to develop models of interesting performance and quality
- [ImageNet](https://en.wikipedia.org/wiki/ImageNet) was one of the first such data sets, collections of millions of images, with annotations (importantly: this has a cat in it, this has a dog in it, this is a blueberry muffin, this has a human in it)
  - Annotations were absolutely essential to allow us to train the first very successful neural network models
- We did not have a lot of textual information about medicine until [PubMed](https://pubmed.ncbi.nlm.nih.gov/) went online
  - All the medical literature, at least an abstract of it is online in PubMed
    - A subset of that is open-access, which has the full text) ([PubMed Central](https://www.ncbi.nlm.nih.gov/pmc/))
    - All of the sudden, that has opened up over the last 10 years
- After Obama signed the [HITECH Act](https://en.wikipedia.org/wiki/Health_Information_Technology_for_Economic_and_Clinical_Health_Act) (electronic health records), this generated a lot of text for the use in these systems
  - Which also ruined the lives of many doctors
- 2 – The neural network models themselves
- The [perceptron](https://en.wikipedia.org/wiki/Perceptron) (mentioned earlier) was developed not too long after World War II, and was shown by one of the pioneers of AI ([Marvin Minsky](https://en.wikipedia.org/wiki/Marvin_Minsky)) to have fundamental limitations in that it could not do certain mathematical functions like what’s called an exclusive-or gate
  - Because of that, people said these neural networks are not going to scale
- But there were a few true believers who kept on pushing and making more and more advanced architectures and those multi-level, deep neural networks
- So, instead of having one neural network, we layer on top of one neural network another one and another one and another one, so that the output of the first layer gets propagated up to the second layer of neurons to the third layer and fourth layer, and so on

Peter asks, “*Was this a theoretical mathematical breakthrough or a technological breakthrough?*”

- It was both, because having insight that we could actually come up with all the mathematical functions that we needed to, we could simulate them with these multi-level networks
- Whereas, it was a theoretical insight, but we’d have never made anything out of it, if not for the fact of mostly teenage boys playing video games
  - In order to have first-person shooters capable of running high-resolution pictures of aliens or monsters in high-resolution 24-bit color, 60 frames per second, we needed to have very parallel processors that would allow you to do the linear algebra that allowed you to calculate what was going to be the intensity of color on every dot of the screen at 60 frames per second
  - You need huge matrices, and it turns out that’s something that can be run in parallel
    - You want to have multiple parallel processors capable of rendering those images, again, at 60 frames per second, so basically millions of bits on your screen being rendered at 24 or 32-bit color
    - In order to do that, you need to have that linear algebra that you just referred to being run in parallel
- And so, these parallel processors called [graphical processing units (GPUs)](https://en.wikipedia.org/wiki/Graphics_processing_unit) were developed
  - They were developed by several companies, and some of them stayed in business
  - They were absolutely essential to the success of video game
- It then occurred to many smart mathematicians and computer scientists that the same linear algebra that was used to drive that computation for images could also be used to calculate the weights of the edges between the neurons in a neural network
- So, the mathematics of updating the weights in response to stimuli, let’s say, of a neural network, updating of those weights can be done all in linear algebra
- A typical computer has a central processing unit (that’s one processing unit)
- A GPU has tens of thousands of processors that do this one very simple thing, linear algebra
- And so, by having this parallelism that only supercomputers would have typically on your simple PC (because you needed to show the graphics at 60 frames per second), gave us all of a sudden these commodity chips that allowed us to calculate the performance of these multi-level neural networks

***That theoretical breakthrough was a 2nd part but would not have happened without the actual implementation capability that we had with the GPUs***

- [Nvidia](https://en.wikipedia.org/wiki/Nvidia) was the most successful example, and it  created an ecosystem of implementers who built their neural network, deep learning systems on top of the Nvidia architecture

## An AI breakthrough in medicine: the ability to accurately recognize retinopathy [29:00]

**Would you go back and look at the calendar and say this was the year or quarter when there was escape velocity achieved there?**

- Yeah
- It was probably around 2012 when there was an ongoing contest every year saying who has the best **image recognition software**
- These deep neural networks running off GPUs were able to outperform significantly all their other competitors in image recognition in 2012
- That’s very clearly when everybody just woke up and said, “*Whoa, we knew about neural networks. We didn’t realize that these convolutional neural networks were going to be this effective. And seems that the only thing that’s going to stop us is computational speed and the size of our data sets.*”
- That moved things very fast along in the imaging space with, very soon, consequences in medicine

**AI recognizes retinopathy**

- It was only 6 years later that we saw journal articles about recognition of retinopathy (diseases affecting the retina, the back of your eye in diabetes), and a [paper](https://pubmed.ncbi.nlm.nih.gov/27898976/) coming out, of all places, from Google saying, “*We can recognize different stages of retinopathy based on the images of the back of the eye*.”
- That also was a wake-up call because yes, part of the goal-post moving is great that we could recognize cats and dogs in web pages
  - But now all of a sudden, this thing that we thought was a specialized human expertise could be done by that same stack of software
    - Just if you gave it enough cases of these retinopathy’s, it would actually work well
- Furthermore, what was wild was that there’s something called [transfer learning](https://en.wikipedia.org/wiki/Transfer_learning), where you tune up these networks, get them to recognize cats and dogs, and in the process of recognizing cats and dogs, it learns how to recognize the little circles and lines and fuzziness and so on
  - You did a lot better in training up the neural network first on the entire set of images and then on the retinas
  - And if you just went straight to: I’m just going to train on the retinas
    - That transfer alerting was impressive
- Zak was asked to write an [editorial](https://pubmed.ncbi.nlm.nih.gov/29532063/) for the *Journal of the American Medical Association* in 2018 when that Google article was written
  - What was impressive to doctors was that what was the main role of doctors in that publication was just twofold
  - 1 – To just label the images that were used for training: this retinopathy is not retinopathy
  - 2 -To serve as judges of its performance
  - The rest of it was computer scientists working with GPUs and images tuning it

> “*It didn’t look anything like medical school and you were having expert level recognition of retinopathy. That was a wake-up call*.”‒ Zak Kohane

## Third generation AI: how improvements in natural language processing significantly advanced AI capabilities [32:00]

Peter brings up the 2017 paper by Google, [*Attention is All You Need*](https://arxiv.org/html/1706.03762v7)

- This is a great paper that was about the invention of the [transformer](https://en.wikipedia.org/wiki/Transformer_(deep_learning_architecture)), which is a specific type of neural network architecture
- Zak was talking about these were fairly vanilla convolutional, neural networks, the same one that can detect dogs and cats
- Retinopathy was a big medical application
- Except for computer scientists, no one noticed the *Attention Is All You Need* paper
- And Google had this wonderful paper that said, “*If we recognize not just text that colocates together*”
- So we’re going to get back away from images for a second
- Because previously there was this notion that I can recognize a lot of similarities in text
  - If I see which words occur together, I can implicate the meaning of a word by the company it keeps
  - And so if I see this word and it has around it kingdom, crown, throne, it’s about a king and similarly for queen and so on
- That kind of association in which we created what was called [embedding vectors](https://en.wikipedia.org/wiki/Word_embedding), which in plain English: it’s a string of numbers that says for any given word, what’s the probability?
  - How often do these other words co- occur with it?
- Just using those embeddings, those vectors, those lists of numbers that describe the co-occurrence of other words, we were able to do a lot of what’s called natural language processing, which is looking at text and saying, “*This is what it means. This is what’s going on*.”
- But then in the 2017 paper, they actually took a next step, which was the insight that where exactly the thing that we were focusing on was in a sentence, what was before and after the actual ordering of it mattered, not just the simple co-occurrence: that knowing what position that word was in the sentence actually made a difference

***That paper showed the performance went way up in terms of recognition, and that transformer architecture came from that paper, made it clear for number of researchers that if you scaled that transformer architecture up to a larger model so that the position dependence and this vector was learned across many, many more texts, the whole internet, you could train it to do various tasks***

- This transformer model, which is called the [pre-trained model](https://en.wikipedia.org/wiki/Generative_pre-trained_transformer): think of it as equivalent of an equation with multiple variables
- In the case of [GPT-4](https://en.wikipedia.org/wiki/GPT-4), we think it’s about a trillion variables
  - It’s like an equation where you have a number in front of each variable, a coefficient that’s about a trillion long

**This model can be used for various purposes**

- One is the [chatbot](https://en.wikipedia.org/wiki/Chatbot) purpose, which is given this sequence of words, what is the next word that’s going to be said?
- Now, that’s not the only thing you could use this model for, but that turns out to have been the breakthrough application of the transformer model for text

Peter asks, “*Would you say that is the third thing that enabled this third wave of AI, the transformer?*”

- That’s not what Zak was thinking about
- The real breakthrough in data-driven AI was around the 2012 era
  - If you talked to him in 2018, he would’ve already told you we’re in a new heyday and everybody would agree with you, there was a lot of excitement about AI just because of the image recognition capabilities
- This was an additional capability that’s beyond what many of us were expecting just from the scale up of the neural network

**Zak’s summary**: “*The 3, just to make sure I’m consistent, was: large data sets, multi-level neural networks (aka deep neural networks), and the GPU infrastructure. That brought us well through the 2012 to 2018.*”

- The 2017 blip that became what we now know to be this whole [large language model transformer architecture](https://en.wikipedia.org/wiki/Large_language_model), that development was unanticipated for many of us
  - That was already on the heels of an ascendant AI era
  - There was already billions of dollars of frothy investment in frothy companies, some of which did well and many of which did not do so well
- The transformer architecture has revolutionized many parts of the human condition, but it was already part of the third wave

## AI concerns and regulation: misuse by individuals, military applications, displacement of jobs, and potential existential concerns [37:30]

**By the time GPT-3.5 came out, it was now becoming a much a verb as Google was in the early 2000s**

- There were clearly people who knew what Google was in ‘96 and ‘97, but by 2000 everybody knew what Google was
- Something about GPT-3.504 was the tipping point where you cannot know what it is at this point

*Does this speak to the trajectory we’re on?*

**On the topic of regulation: is there a chance for this thing to be harmful to us in some way that we do not yet perceive?**

- There was no public discussion of this in the 80s, maybe because AI just wasn’t powerful enough to pose a threat
- Peter assumes that one side says:
  - pedal to the metal, let’s go forth on development and don’t regulate this
  - The other side is: no, we need to have some brakes and barriers
- Zak thinks this is not quite right
- He agrees that chatbots have now become a commonly used noun
  - That probably happened with the emergence of GPT 3.5, and that appeared around December of 2022
- The out the box, that pre-trained model Zac mentioned earlier could tell you things like: how do I kill myself? How do I manufacture a toxin?
  - It could allow you to do a lot of harmful things
  - So there was that level of concern
  - We can talk about what’s been done about those 1st order efforts
- Then there’s been a group of scientists who interestingly went from saying, “*We’ll never actually get general intelligence from this particular architecture*,” to saying, “*Oh my gosh, this technology is able to inference in a way that I had not anticipated. And now I’m so worried that either because it’s malevolent or just because it’s trying to do something that has bad side effects for humanity, it presents an existential threat*.”
- On the other side, Zak doesn’t believe anybody is saying, “*Let’s just go heads down and let’s see how fast we can get to artificial general intelligence*.”
  - Or if they do think that they’re not saying it openly

*Define AGI*

- Zak explains, “*That was an unfortunate slip because* ***a****rtificial* ***g****eneral* ***i****ntelligence means a lot of things to a lot of people… it’s a moving target, and it’s very much in the beholder*.”
- There’s a guy called [Eliezer Yudkowsky](https://en.wikipedia.org/wiki/Eliezer_Yudkowsky), one of the so-called doomers, and he comes up with great scenarios of how a sufficiently intelligent system could figure out how to persuade human beings to do bad things
  - Or control of our infrastructure to bring down our communications infrastructure or airplanes out of the sky
  - And we can talk about whether that’s relevant or not
- On the other side, we have [OpenAI](https://openai.com/) and Google
- What was fascinating to Zak is that OpenAI (which working with Microsoft) generated GPT-4, and they were not saying publicly at all, “*Let’s not regulate it.*”
  - In fact, they were saying, “*Please regulate me.*”
  - [Sam Altman](https://en.wikipedia.org/wiki/Sam_Altman) went on a world tour where he said, “*We should be very concerned about this. We should regulate AI.*”
    - Said this before Congress
- Sam was kind enough to write foreword to the [book](https://www.amazon.com/AI-Revolution-Medicine-GPT-4-Beyond/dp/0138200130/ref=sr_1_1?crid=18XKW0M8TFBAM&dib=eyJ2IjoiMSJ9.uCwzKQlwaOhpfGx03Yu7DQHjUMSi1ForqHMK6pZsyzPv-sjQyt6Cwx5xgDkcktBiXwcrIeKDG2sbzgJsCg5uJf5p25wWa4OW0WnPZ3F0vJc20WakUKu52ku6qNX3VN9x8l3S9oja6nfNj0fm1fYTux7PMWGvcJ9I_105ZUrEnLs.OX6Gf3d_b-ia87DIKhAJ6Xc9norp6EOGkJ-sOtz-gT0&dib_tag=se&keywords=The+AI+Revolution+in+Medicine%3A+GPT-4+and+Beyond&qid=1715792531&sprefix=the+ai+revolution+in+medicine+gpt-4+and+beyond%2Caps%2C147&sr=8-1) Zak wrote with Peter Lee and [Carey Goldberg](https://www.linkedin.com/in/cagoldberg/) on GPT-4 and the revolution in medicine, and Zak feels a bit churlish in wondering why they were insisting so much on regulation

*There’s 2 interpretations to why they were insisting on regulation*

- 1 – A sincere wish that it’d be regulated
  - So we check these machines, these programs, to make sure they don’t actually do anything harmful
- 2 – Something called **regulatory lock-in** which means: I’m a very well-funded company, and I’m going to create regulations with Congress about what is required, which boxes do you have to check in order to be allowed to run
  - If you’re a small company, you’re not going to have a bevy of lawyers with big checks to comply with all the regulatory requirements
- Zak doesn’t know Sam personally, but he imagines he’s a very well-motivated individual

**There is someone just as potentially evil that we have to worry about, another intelligence, and that’s human beings**

- How do human beings use these great tools?
- We know for a fact that one of the earliest users of GPT-4 were high schoolers trying to do their homework and solve hard puzzles given to them
- We also know that various parties have been using the amazing text generation and interactive capabilities of these programs to spread misinformation to chatbots
- And there’s a variety of maligned things that could be done by third parties using these engines

***For Zak, the clear and present danger today is the question: how do individuals decide to use these general purpose programs?***

- If you look at what’s going on in the Ukraine-Russian War, Zak sees more and more autonomous vehicles flying and carrying weaponry and dropping bombs
- And we see in our own military a lot more autonomous drones with greater and greater autonomous capabilities

***Those are purpose-built to actually do dangerous things***

- And a lot of science fiction fans will refer to Skynet from the Terminator series, but we’re literally building it right now

Peter recalls in [*The Terminator*](https://en.wikipedia.org/wiki/The_Terminator), they refer to a moment, a year (1997 or something) when the Skynet became “self-aware”

- And some who when it became self-aware, it decided to destroy humans

**Is “self-aware” movie-speak for AGI? Or is it super intelligence? What do you think self-aware means in more technical terms?**

- Self-awareness means a process by which the intelligent entity can look back, look inwardly at its own processes and recognize itself
- Now, that’s very hand-wavy, but [Douglas Hofstadter](https://en.wikipedia.org/wiki/Douglas_Hofstadter) has probably done the most thoughtful and clear writing about what self-awareness means
  - If you really want to read a one full book that spends a whole book trying to explain it, it’s called [*I Am a Strange Loop*](https://www.amazon.com/Am-Strange-Loop-Douglas-Hofstadter/dp/0465030785/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.teG_3-IN7cH0XHblUk9GWu0r_1wy8Bt9Opl9VZ8pTiLGjHj071QN20LucGBJIEps.xKlbaCLQvIrJmNWHxlfAypnCjtzXPtUagJ8AJkG7--0&qid=1715964480&sr=1-1)
  - In that book, he explains how if you have enough processing power and you can represent the processes that you have, essentially models of the processes that constitute you
    - In other words, if you’re able to look at what you’re thinking, you may have some sense of self-awareness
    - There’s a bit of an act of faith on that ‒ many AI researchers don’t buy that definition
- There’s a difference between self-awareness and actual war intelligence
- You can imagine a super-powerful computer that would predict everything that was going to happen around you and was not aware of itself as an entity
- The fact remains, you do need to have a minimal level of intelligence, be able to be self-aware
  - A fly may not be self-aware; it just goes and finds good smelling poop and does whatever it’s programmed to do on that
  - But dogs have some self-awareness and awareness of their surroundings
    - They don’t have perfect self-awareness; they don’t recognize themselves in the mirror, and they’ll bark at that
  - Birds will recognize themselves in mirrors
  - We recognize ourselves in many, many ways

***There is some correlation between intelligence and self-awareness, but these are not necessarily dependent functions***

**Peter’s takeaway**: there are clear and present dangers associated with current best AI tools in that humans can use them for nefarious purposes

**Is the most scalable example of that still relatively small in that it’s not an existential threat to our species at large?**

- Yes and no
- If one were trying to do gain-of-function research with a virus, you could use these tools very effectively
- There’s this disconnect: there’s those real existential threats, and then there’s this more fuzzy thing that we’re worried about (correctly): about bias, incorrect decisions, hallucinations
- And there’s concerns about mistakes that might be made
- There’s concerns about displacement of workers that just as automation displaced a whole other series of workers, now that we have something that works in the knowledge industry automatically, just as we’re placing a lot of copy editors and illustrators with AI
  - Where’s that going to stop?
  - It’s now much more in the white collar space
- There is concern around the harm that could be generated there
- In the medical domain, are we getting good advice?
  - Are we getting bad advice?
  - Whose interests are being optimized in these various decision procedures?
    - That’s another level that doesn’t quite rise at all to the level of extinction events, but a lot of policymakers and the public seem to be concerned about it

## How AI is enhancing image-based medical specialties like radiology [49:15]

- The example Zak gave earlier is almost one we take for granted: you go and get an [EKG](https://en.wikipedia.org/wiki/Electrocardiography) at the doctor’s office and you get a pretty darn good readout
  - This was true 30 years ago, just as it is today
  - It’s going to tell you if you have an [AV block](https://en.wikipedia.org/wiki/First-degree_atrioventricular_block), it’s going to tell you if you have a [bundle branch block](https://en.wikipedia.org/wiki/Left_bundle_branch_block)
  - They read EKGs better than Peter does

**What is the next area where we could see this? Radiology?**

- It seems to Peter that radiology, image pixel-based medicine would be the most logical next place to see AI do good work

> “*In all the visual based medical specialties, it looks like AI can do as well as many experts.*”‒ Zak Kohane

*What are the image appreciation subspecialties?*

- **Pathology**, when you’re looking at slices of tissue under the microscope
- **Radiology** where you’re looking at X-rays or MRIs
- **Dermatology** where you’re looking at pictures of the skin
- In all those visual-based specialties, the computer programs are doing by themselves as well as many experts, but they’re not replacing the doctors because ***that image recognition process is only part of their job***
- Now, to be fair to your point in radiology, we already today before AI, many hospitals would send X-rays by satellite to Australia or India where they would be read overnight by a doctor or a specially trained person who had never seen the patient, and then the reports filed back to us because they’re 12 hours away from us, overnight we’d have the results of those reads
  - And that same function can be done automatically by AI
  - So that’s replacing a certain kind of doctor

Peter asks, “*Will they know why this patient presented? Do they have a previous X-ray to compare it to?… Are we not at the point now where all of that information could be given to the AI to enhance the pre-test probability of whatever diagnosis it comes to?*”

- Zak is delighted when Peter says pre-test probability ([Bayes’ theorem](https://en.wikipedia.org/wiki/Bayes%27_theorem))
- Zak explains, “*You just said a lot because what you just said actually went beyond what the straight convolutional neural networks would do ’cause they actually could not replace radiologists because they could not do a good job of taking into account the previous history of the patient*.”
  - It’s required the emergence of [transformers](https://en.wikipedia.org/wiki/Transformer_(deep_learning_architecture)) where you can have multimodality
    - You have both the image and the text
    - Now, they’re going to do better than many, many radiologists today

***Zak doesn’t think there is any threat yet to radiologists as a job***

- One of the most irritating predictions (to doctors) was made by [Geoffrey Hinton](https://en.wikipedia.org/wiki/Geoffrey_Hinton), one of the intellectuals leaders of neural network architecture
  - He said (in approximately 2016), “*But in six years we wouldn’t have no need for radiologists.*” And that was just clearly wrong
    - The reason it was wrong is A – They did not have the capabilities that we just talked about, understanding about the clinical context
    - B – It’s also the fact that we don’t have enough radiologists to do the work
- If you look at residency programs in American medicine, we’re not getting enough radiologists out
  - We have an overabundance of applicants for interventional radiology
    - They’re making a lot of money
    - It’s high prestige
  - But straight up radiology readers, there’s not enough of them
- The same is true for primary care doctors
  - Go around medical schools and ask, “*Who’s becoming a primary care doctor?*” Almost nobody
  - Primary care is disappearing in the United States
    - In fact, Mass General and Brigham announced officially they’re not seeing primary care patients
- In Zak’s speciality (**pediatric endocrinology**), half of the slots nationally are not being filled
  - Pediatric developmental disorders like autism, only half of those slots are filled
  - [PDID](https://en.wikipedia.org/wiki/Dissociative_disorders), there’s a huge gap emerging in the available expertise
- It’s not what we thought it was going to be that we had a surplus of doctors that had to be replaced
- It’s just we have a surplus and a few focused areas, which are very popular
- And then for all the work of primary care and primary prevention, you have almost no doctors available

**Isn’t radiology a gap that should be fillable by AI?**

Peter asks, “*If you’re saying we have a dearth of imaging radiologists who are able to work the emergency rooms, urgent care clinics and hospitals, wouldn’t that be the first place we would want to apply our best of imaging recognition with our super powerful GPUs and now plug them into our transformers with our language models so that I can get clinical history, medical past history, previous images, current images, and they don’t have to send it to a radiologist in Australia to read it, who then has to send it back to a radiologist here to check if we’re just trying to fill a gap, that gap should be fillable, shouldn’t it?*”

- That’s exactly where it is being filled

## The use of AI by patients and doctors [55:45]

- What keep distracting Zak in this conversation is that there’s a whole other group of users of these AIs that we’re not talking about: **the patients**
- Previously, none of these tools were available to patients
- With the release of [GPT-3.5](https://en.wikipedia.org/wiki/GPT-3#GPT-3.5) and [4](https://en.wikipedia.org/wiki/GPT-4), and now [Gemini](https://en.wikipedia.org/wiki/Gemini_(chatbot)) and [Claude 3](https://en.wikipedia.org/wiki/Claude_(language_model)#Claude_3), they’re being used by patients all the time in ways that we had not anticipated

**An example of how a patient used GPT-4**

- There was a child who was having trouble walking, having trouble chewing, and then started having intractable headaches
  - Mom brought him to multiple doctors
  - They did multiple imaging studies, no diagnosis; kept on being in intractable pain
  - She just typed into GPT-4 all the reports, and asked GPT-4, what’s the diagnosis?
  - And GPT-4 said [tethered cord syndrome](https://en.wikipedia.org/wiki/Tethered_spinal_cord_syndrome)
  - She then went with all the imaging studies to a neurosurgeon, said, “*What is this?*”
  - He looked at it, he said, “*Tethered cord syndrome.*”

**We have an epidemic of misdiagnosis and undiagnosed patients**

- Part of Zak’s background: he’s the principal investigator of the coordinating center of something called the [Undiagnosed Network](https://undiagnosed.hms.harvard.edu/)
  - It’s a network with 12 academic hospitals down the west coast from University of Washington, Stanford UCLA to Baylor up the East Coast, Harvard Hospitals, NIH. And we see a few thousand patients every year
    - These are patients who have been undiagnosed and they’re in pain
    - That’s just a small fraction of those who are undiagnosed

> “*We bring to bear a whole bunch of computational techniques and genomic sequencing to actually be able to help these individuals, but it’s very clear that there’s a much larger burden out there of misdiagnosed individuals*.”‒ Zak Kohane

Peter asks, “*Does it surprise you that in that example, the mother was the one that went to GPT-4 and inputted that. I mean, she had presumably been to many physicians along the way. Were you surprised that one of the physicians along the way hadn’t been the one to say, “Gee, I don’t know, but let’s see what this GPT-4 thing can do?*”

- Most clinicians Zak knows do not have what he used to call the “Google reflex”
  - Zak remembers when he was on the wards and they had a child with dysmorphology (they look different), and he asked one of the fellows, “*What’s the diagnosis?*”
  - He didn’t know
  - Zak asked, “*How would you find out?*”
  - They had no idea
  - Zak said, “*He has this and this and this finding… Let’s take what I just said and type it into Google*.”
  - One of the top 3 responses was the diagnosis
- Clinicians use Google in their civilian life, but not in the clinic
- Doctors being driven very, very hard and they’re being told to use certain technological tools
  - They’re being turned into data entry clerks
  - Who has the time to look up a journal article?

***They don’t do the Google reflex even less do they have the: let’s look at the patient’s history and see what GPT-4 would come up with***

- Early on, Zak was gratified to see doctors saying, “*Wow, I just took the patient history, plugged into GPT-4 and said, write me a letter of prior authorization*.”
  - Because it was saving them 5 minutes to write that letter
- He was not pleased because if you use [ChatGPT](https://en.wikipedia.org/wiki/ChatGPT), you’re using a program that is covered by [OpenAI](https://openai.com/) as opposed to a [version of GPT-4](https://azure.microsoft.com/en-us/) that is being run on protected Azure cloud by Microsoft, which is [HIPAA](https://en.wikipedia.org/wiki/Health_Insurance_Portability_and_Accountability_Act) covered
  - HIPAA is the legal framework under which we protect patient privacy and if you violate it, you can be fined and even go to prison

***In other words, if a physician wants to put any information into GPT-4, they better not identify it***

- If they just plugged in a patient note into ChatGPT, that’s a HIPAA violation
- If there’s a Microsoft version of it, which is HIPAA-compliant, it’s not

***The doctors were using it for improving the administrative part of healthcare, but by and large, only a few doctors use it for diagnostic acumen***

**What about more involved radiology?**

*Once we start to look at three-dimensional images such as cross-sectional images, CT scans, MRIs, or even more complicated images like ultrasound and things of that nature, what is the current state of the art with respect to AI in the assistance of reading these types of images?*

- That’s the very exciting news, 1 of the 3 ingredients for a breakthrough (remember how Zak said it was important to have lots of data?)
  - Having a lot of data around, for example, [echocardiogram](https://en.wikipedia.org/wiki/Echocardiography), the ultrasounds of your heart ‒ normally it takes a lot of training to interpret those images correctly
  - There is a [recent study](https://www.nature.com/articles/s41591-024-02959-y) from the EchoCLIP group, and they took a million echocardiograms and a million textual reports and essentially trained the model both to create those embeddings (Zak talked about of the images and of the text)
    - This is very complicated video: you’re putting a multidimensional video because you have timescale, you have Doppler effects
    - It views it from different angles
    - It’s dependent on the radiology tech (they can be good or bad)

***We’re going to get rid of the cardiologist before we get rid of the technician***

## The potential for AI to augment clinicians and address physician shortages [1:02:45]

**The potential for AI to replace clinicians**

- Zak’s target in this conversation is nurse practitioners and physician assistants with these [AI] tools can replace a lot of expert clinicians and there is a big open question: what is the real job for doctors in 10 years from now?
  - Zak doesn’t think we know the answer to that
- Peter points out, “*We still haven’t come to proceduralists, so we still have to talk about the interventional radiologist, the interventional cardiologist, and the surgeon.*”
- What we’re doing is identifying the pecking order of physicians, and let’s not even think about it through the lens of replacement
- Let’s start with the lens of **augmentation**, which is the radiologist can be the most easily augmented, the pathologist, the dermatologist, the cardiologist who’s looking at Echoes and EKGs and stress tests, ***people who are interpreting visual data and using visual data will be the most easily augmented***

*The second tranche of that will be people who are interpreting language data plus visual data*

- Now we’re talking about your internist, your pediatrician, where you have to interpret symptoms and combine them with laboratory values and combine it with a story and an image

**In a place where we don’t have primary care physicians**

- The American Association of Medical Colleges estimates that by 2035 (that’s only 11 years from now), we’ll be missing on the order 50,000 primary care doctors
- As Zak mentioned, he can’t get primary care at the Brigham or at MGH today
- And in the absence of that, you have to ask yourself: ***how can we replace these absent primary care practitioners with nurse practitioners, with physician assistants augmented by these AIs because there’s literally no doctor to replace***

Peter asks, “*Where are we technologically on that augmentation?*”

- If [NVIDIA](https://en.wikipedia.org/wiki/Nvidia) never came out with another chip and this is as good as it’s going to get, do we have good enough GPUs, good enough multilayer neural networks that all you need is more data and training sets that we could now do the augmentation that has been described by us in the last five minutes?
- The short answer is yes

*Zak gives a concrete example*

- Most concierge services cost in Boston, somewhere between $5-$20,000 a year
- You can get this very low cost of concierge service called [One Medical](https://www.onemedical.com/membership/)
  - One Medical was acquired by Amazon and they have a lot of nurse practitioners in there and you can make an appointment and you can text with them
  - Zak believes that those individuals could be helped in ordering the right imaging studies, the right EKGs, the right medications, and assess your continuing heart failure and only decide in the very few cases that you need to see a specialist cardiologist or a specialist endocrinologist today
- It would just be a matter of just making the current models bette

*A big question for us (this is a regulatory question): which ones do a better job? (and they’re not all equal)*

***Zak doesn’t think we need technological breakthroughs to just make the current set of paraprofessionals work at a level of entry-level doctors***

- He adds the old very bad joke: What do you call the medical student who graduates at the bottom of his class? Doctor
- And so if you could just merely get the bottom 50% of doctors to be as good as a top 50%, that’ll be transformative for healthcare

*There are other superhuman capabilities that we can go towards that require the next generation of algorithms, NVIDIA architectures and datasets*

> “*If we stop now, we could already transform medicine*”‒ Zak Kohane

- It’s just a matter of the sweat equity to create the models, figure out how to include them in the workflow, how to pay for them, how to create a reimbursement system and a business model that works for our society
- There’s no technological barrier

**Peter’s takeaway**: everything we’ve talked about is take the best case example of medicine today and you can augment it with AI such that you can raise everyone’s level of care to that of the best, no gaps and it’s scaled out

## The potential for AI to revolutionize early diagnosis and prediction of diseases: Alzheimer’s disease, CVD, autism, and more [1:08:00]

**Where do you see the potential for AI in solving problems that we can’t even solve on the best day at the best hospitals with the best doctors?**

- For example, we can’t really diagnose Alzheimer’s disease until it appears to be at a point that for all intents and purposes is irreversible
  - Maybe on a good day we can halt progression really, really early in a patient with just a whiff of MCI, mild cognitive impairment, maybe with an early amyloid detection and an anti-amyloid drug
- Peter asks, “*Is it science fiction to imagine that there will be a day when an AI could listen to a person’s voice, watch the movements of their eyes, study the movements of their gait and predict 20 years in advance when a person is tearing down the barrel of a neurodegenerative disease and act at a time when maybe we could actually reverse it?*”
- Zak doesn’t believe it’s science fiction at all
  - Looking at images of retinas today can tell you not just whether you have retinal disease, but if you have hypertension, if you’re a male, if you’re female, how old you are, and some estimate of your longevity
    - This uses straightforward convolutional neural network, not even ones that involve transformers
    - And that’s just looking at the back of your eye and seeing enough data
- Zak was a small player in a [study](https://pubmed.ncbi.nlm.nih.gov/15190254/) that appeared in *Nature* in 2005 with [Bruce Yankner](https://yankner.hms.harvard.edu/people/bruce-yankner)
  - They were looking at frontal lobes of individuals who had died from a variety of reasons, often in accidents of various ages
  - They saw bad news: after age 40, your transcriptome (the genes that are switched on) falls off a cliff
    - 30% of your transcriptome went down
    - That seemed to be a big difference in the expression of genes around age 40
  - But there was one 90-year-old who looked like the young guy
    - So maybe there’s hope for some of us
- Zak thought about it afterwards and there were other things that actually have much smoother functions, like our skin
- All our organs age and they age at different rates
- Having the right data sets and the ability to see nuances that we don’t notice makes it very clear to Zak that the **early detection** part can be very straightforward (no problem)
- The **treatment** part, we can talk about it
- For example we had early on from the very famous [Framingham Heart Study](https://en.wikipedia.org/wiki/Framingham_Heart_Study), a predictor of when you were going to have heart disease based on just a handful of variables

***Now we have these artificial intelligence models that based on hundreds of variables, can predict various other diseases and Zak believes it will do Alzheimer’s very soon***

- He thinks you’ll be able to see a combination of gait, speech patterns, picture of your body, picture of skin, and eye movements ‒ that will be a very accurate predictor
- Speaking about eyes, Zak just [published](https://pubmed.ncbi.nlm.nih.gov/38645024/) a very nice study where in a car just by looking at the driver, they can figure out what your blood sugar is because diabetics previously have not been able to get driver licenses sometimes because of the worry about them passing out because of hypoglycemia
  - So there was a very nice [study](https://ai.nejm.org/doi/full/10.1056/AIoa2300013) that showed that you could just by looking (have cameras pointed at the eyes) could actually figure out exactly what the blood sugar is
  - That kind of detection is fairly straightforward
  - It’s a different question about what you can do about it

**Could a retinal exam be useful in predicting adverse cardiac events?**

- The 2 most popular models for looking at major adverse cardiac event risk prediction are the [Framingham model](https://en.wikipedia.org/wiki/Framingham_Heart_Study) and the [Multi-Ethnic Study on Atherosclerosis (MESA model)](https://en.wikipedia.org/wiki/Multi-Ethnic_Study_of_Atherosclerosis)
- But you needed something else to build those models, which was enough time to see the outcome
- In the Framingham cohort, which was the late 70s and early 80s, you then had the Framingham offspring cohort and then you had to be able to follow these people with their LDL-C and HDL-C and triglycerides and later eventually they incorporated calcium scores
- If today we said, look, we want to be able to predict 30-year mortality, which is something no model can do today
- This is a big pet peeve of Peter’s: we generally talk about cardiovascular disease through the lens of 10-year risk (which he thinks is ridiculous)
  - We should talk about lifetime risk
  - He would settle for 30-year risk
- If we had a 30-year model where we could take many more inputs, Peter would love to be looking at the retina

***Peter believes a retinal examination should be a part of medicine today for everybody***

- Peter would take a [retinal exam](https://en.wikipedia.org/wiki/Eye_examination#Retinal_examination) over a [hemoglobin A1c](https://en.wikipedia.org/wiki/Glycated_hemoglobin) all day every day
- The point is, we could define the data set, and we want to see these 50 things in everybody to predict every disease
  - Let’s overdo it and we can prune things later

Peter asks, “*Is there any way to get around the fact that we’re going to need 30 years to see this come to fruition in terms of watching how the story plays out? Or are we basically going to say, no, we’re going to do this over five years. It won’t be that useful because a five-year predictor basically means you’re already catching people in the throes of the disease.*”

> “*I’ll say three words, electronic health records. So that turns out not to be the answer in the United States.*”‒ Zak Kohane

- In the US we move around and don’t stay in any given healthcare system that long
- Very rarely will Zak have all the measurements on a patient (glycohemoglobin, all your blood pressures, all your clinic visits, all the imaging studies that you’ve had)
- That’s not the case in Israel for example
  - In Israel, they have these HMOs (health maintenance organizations) and one of them ([Clalit](https://en.wikipedia.org/wiki/Clalit_Health_Services)), Zak has a good relationship with because they published all the big Covid studies looking at the efficacy of the vaccine and why could they do that?
  - Because they had the whole population available and they have about 20, 25 years worth of data on all their patients in detail and family relationships
- [Kaiser Permanente](https://en.wikipedia.org/wiki/Kaiser_Permanente) also has that kind of data, and with that data Zak thinks you can actually come close
- Now these are noisier measurements, and so those of us who are data junkies (like Zak) always keep mumbling to ourselves, “perfect is the enemy of good”
  - Waiting 30 years to have the perfect data set is not the right answer to help patients now

**There are things that we could know now that are knowable today that we just don’t know because we haven’t bothered to look**

*A quick example*

- Zak did a [study](https://pubmed.ncbi.nlm.nih.gov/22511918/) of [autism](https://en.wikipedia.org/wiki/Autism_spectrum) using electronic health records maybe 15 years ago, and he saw there was a lot of GI problems
- When he talked to a pediatric expert, they were a little bit dismissive
  - They said, “*Brain bad, tummy hurt.*”
  - They’ve seen a lot of inflammatory bowel disease, and it doesn’t make sense to that this is somehow an effect of brain function
- To make a long story short, Zak did a massive study looking forward to tens of thousands of individuals, and sure enough, he found subgroups of patients who had immunological problems associated with their autism
  - They had type 1 diabetes, inflammatory bowel disease, lots of infections

***Those were knowable, but they were not known***

- Zak had parents coming to him more thankful that for anything else he had ever done for them clinically because he was telling these parents they weren’t hallucinating, that these kids had these problems
  - They just weren’t being recognized by medicine because no one had the big wide angle to see these trends
- So without knowing the field of Alzheimer’s the way Zak does other fields, he bets you there are trends in Alzheimer’s that you can pick up today by looking at enough patients that you’ll find some that have more frontotemporal components, some that have more effective components, some that have more of an infectious and immunological component
  - Those are knowable today

## The future of AI in healthcare: integration of patient data, improved diagnostics, and the challenges of data accessibility and regulatory compliance [1:17:00]

- If the physician is the customer (who is not necessarily the most tech forward customer), and truthfully, like many customers of AI runs the risk of being marginalized by the technology if the technology gets good enough
- Yet you need the customer to access the patient to make the data system better, to make the training set better

**How do you see the interplay over the next decade of that dynamic?**

- Zak agrees, that’s the right question
- In order for these AI models to work, you need a lot of data, a lot of patients

*Where is that data going to come from?*

- There are some healthcare systems (like the Mayo Institute) who think they can get enough data in that fashion
- There are some data companies that are trying to get relationships with healthcare systems where they can get de-identified data

*Zak is betting on something else*

- There is a trend where consumers are going to have increased access to their own data
- The [21st Century Cures Act](https://en.wikipedia.org/wiki/21st_Century_Cures_Act) was passed by Congress and it said that patients should be given access to their own data programmatically
- Now, they’re not expecting your grandmother to write a program to access the data programmatically, but by having a right to it, it enables others to do so
- For example, Apple has something called [Apple Health](https://www.apple.com/ios/health/)
  - It has this big heart icon on it
  - If you’re one of the 800 hospitals that they’ve already hooked up with Mass General or Brigham Women’s and you’re a patient there, if you authenticate yourself to it, if you give it your username and password, it’ll download into your iPhone your labs, your meds, your diagnoses, your procedures, as well as all the wearable stuff, your blood pressure that you get as an outpatient and various other forms of data
    - That’s already happening now
- There’s not a lot of companies that are taking advantage of that, but right now that data is available on tens of millions of Americans

**Isn’t it interesting how unfriendly that data is in its current form?**

*An example from Peter’s practice*

- If we send a patient to Labcorp or Boston Heart (or pick your favorite lab), and we want to generate our own internal reports based on those where we want to do some analysis on that, lay out trend sheets, we have to use our own internal software
- It’s almost impossible to scrape those data out of the labs because they’re sending you PDF reports
- Their APIs are garbage
- Nothing about this is user-friendly

***Even if you have the My Health thing come on your phone, it’s not navigable, it’s not searchable, it doesn’t show you trends over time***

Peter asks, “*Is there a more user hostile industry from a data perspective than the health industry right now?*”

- No
- There’s a good reason why: because they’re keeping you captive
- The good news is you’re speaking to a real nerd
- Zak know 2 ways where we could solve this problem
- 1 – If it’s in the Apple Health thing, someone can actually write a program, an app on the iPhone, which will take those data as numbers (and not have to scrape it) and it can run it through your own trending programs
  - You could actually use it directly
- 2 – With Gemini and GPT-4, you can actually give it those PDFs and with the right prompting, it will actually take those data and turn them into tabular spreadsheets

Peter asks, “*We can’t do that because of HIPAA, correct?*”

- If the patient gets it from the patient portal, and the patient gives it to you, you absolutely can do that
  - It doesn’t matter that it’s not de-identified
  - It’s not doable through ChatGPT because your lawyers would say, Peter, you’re going to get a million dollars in fines from HIPAA
  - But if you do [GPT on the Azure cloud](https://azure.microsoft.com/en-us/), that’s HIPAA protected and you absolutely can use it with patient consent (100% you can do it)
    - Zak is not a shill for Microsoft (he doesn’t own any stock)
- GPT is being used with patient data out of Stanford right now
- [Epic’s using GPT-4](https://www.epic.com/epic/post/cool-stuff-now-epic-and-generative-ai/), and it’s absolutely legitimately usable by you
  - People don’t understand that
- Peter’s practice has now totally bypassed [OCRs (optical character recognition)](https://en.wikipedia.org/wiki/Optical_character_recognition), which is what they were using 15 years ago to scrape together this data

**An example where Zak used GPT-4 for diagnosis**

- 3 months ago, the NEJM [published](https://www.nejm.org/image-challenge?ci=20231005) a picture of the week [shown below]: the back of a 72-year-old that looks like someone scratched themselves

![](https://peterattiamd.com/wp-content/uploads/2024/07/f1-isaackohane.png)

**Figure 1. NEJM Image challenge from October 5, 2023**. Image credit: [*NEJM*](https://www.nejm.org/image-challenge?ci=20231005)

- Zak put this image into GPT-4 and the text (minus 1 fact) and it came up with 2 things it could be: bleomycin toxicity or shiitake mushroom toxicity
  - What Zak removed is that they guy had eaten mushrooms the day before
- Peter doesn’t think most doctors know this
- Further, when Peter tried to send a picture of his kid’s rash to the pediatrician and they don’t know what it is
  - It’s it’s like we’re rubbing 2 sticks together and Zak telling him about the Zippo lighter

***This is Zak’s message to patients without a primary care doctor: AI is better than no doctor, maybe better***

**Zak pulls down the adverse events reporting files from the FDA and uses GTP-4 to analyze it**

- He doesn’t know squat about the FDA
- It’s a big zip file (compressed file), and he went and said to GPT-4: please analyze this data
  - It says: unzipping, based on this table, I think this is about the adverse events and this is the locations, what do you want to know?
  - Zak says, “*Tell me what adverse events for disease modifying drugs for arthritis.*”
  - It says: to do that, I’ll have to join these 2 tables
    - And it just does it; it creates its own Python code, and it gives me a report

Peter asks, “*Is this a part of medical education now? You’re at Harvard, right? (…one of the 3 best medical schools in the US)*”

- Peter wonders if they spend as much time on this as they do histology, where  he spent 1000 hours looking at slides under a microscope that he never once tried to understand
  - He doesn’t want to say there wasn’t a value in doing that, but he wants to understand the relative balance of education
- Zak explains that it’s like the stethoscope
  - Arguably, we should be using things other than the stethoscope
  - “*Let me make sure I don’t get fired, or at least beaten severely by telling you that* [*George Daley*](https://hms.harvard.edu/faculty-staff/george-q-daley)*, our dean of the medical school, has said explicitly he wants to change all of medical education so these learnings are infused throughout the 4 years, but it’s going to take some doin*g.”

## The future of autonomous robotic surgery [1:25:00]

- We’ve gone from purely the recognition/ image-based to how do I combine image with voice, story, text?
- Zak has made a very compelling case that we don’t need any more technological breakthroughs to augment those
  - It’s purely a data set problem at this point and a willingness
- Let’s now move to the procedural

**Today, the surgeon needs to move the robot. Are we getting to the point where that could change?**

*For example, consider the radical prostatectomy*

- Currently, this is never done open
- This is a procedure that the [Da Vinci (a robot)](https://www.intuitive.com/en-us/products-and-services/da-vinci) has revolutionized
  - There’s no blood loss anymore
- When Peter was a resident, this was one of the bloodiest operations they did
  - It was the only operation by the way, for which they had the patients donate their own blood 2 months ahead of time (that’s how guaranteed it was that they were going to need blood transfusions)
- Today, it’s insane how successful this operation is, on a large part of the robot, but the surgeon needs to move the robot
- Zak explains, “*That’s already happening. Based on what we’re seeing with robotics in the general world, I think the Da Vinci controlled by a robot, 10 years is a very safe bet.*”

***Surgery is a data problem because you can turn it into a pixel and movement problem***

**Comparing autonomous vehicles to robotic surgery**

- Remember, there’s a lot of degrees of freedom in moving a car around traffic
- Medicine is not the only job where lives are at stake
- Driving a ton of metal at 60 miles per hour in traffic is also putting lives at stake
- Last time Zak looked, there’s several manufacturers who are saying that some appreciable fraction of that effort, they’re controlling multiple degrees of freedom with a robot
- Peter also spoke with somebody recently (one of the companies that’s deep in the space of autonomous vehicles), and they very boldly made a compelling case for autonomous vehicles, saying, “*If every vehicle on the road was at their level of technology and autonomous driving, you wouldn’t have fatalities anymore.*”
  - But the key was that every vehicle had to be at that level

Peter asks, “*Does that sense check to you?*”

- Zak begins by explaining that he is a terrible driver, but he’s a better driver now in a Tesla
- There is a good message for medicine in this
- When Zak is driving his [Tesla](https://www.tesla.com/), he knows he needs to jiggle the steering when because otherwise it will assume he’s zoning out
- What he didn’t realize was is that he will pick up his phone and look at it (very bad), and the car was looking at him telling  him to put down the phone
  - 3 minutes later, he picks up his phone again and switches off the autopilot
  - When he gets home, it says, “*All right, that was bad. You do that 4 more times, I’m switching off autopilot until the next software update.*”
    - Zak mentions this because it takes a certain amount of confidence to do that to your customer base

Zak asks, “*In medicine, how likely is it that we’re going to fall asleep at the wheel if we have an AI thinking for us?*”

- It’s a real issue
- For example, we know for a fact back in the ‘90s that doses for a drug like [Ondansetron](https://en.wikipedia.org/wiki/Ondansetron) where people would talk endlessly about how frequently should be given it, with what dose
  - The moment you put it in the order entry system, 95% of doctors would just use the default there

**How in medicine are we going to keep doctors awake at the wheel and will we dare to do the kind of challenges that Zak just described the car doing?**

- Zak believes because of what he’s seen with autonomy and robots that controlling a dementia robot will probably have less bad outcomes
  - Every once in a while, someone nicks something and you have to go into full surgery or they go home and they die on the way home ’cause they exsanguinate

***Zak thinks robotic surgery is going to be safer***

- It’s unbelievable for Peter to wrap his head around that, but he reserves the right to be startled
- Peter thinks certain things seem much easier than others
- He has an easier time believing we’re going to be able to replace interventional cardiologists where the number of degrees of freedom, the complexity and the relationship between what the image shows, what the cath shows and what the input is, the stent, that gap is much narrower
- But when you talk about doing a [Whipple procedure](https://en.wikipedia.org/wiki/Pancreaticoduodenectomy), when you talk about what it means to cell by cell, take a tumor off the superior mesenteric vessels, he’s thinking, “*Oh my God.*”

***Zak predicts that in 10 years there will be prostatectomy by robot***

## AI and the future of mental health care [1:31:30]

- This is a field of medicine today that is grossly underserved
- Everything Zak has said resonates with Peter from his own experiences  in pediatrics and primary care
- Zak points out that at Harvard, 60% of undergraduates are getting some sort of mental health support and it’s completely outdoing all the resources available to the university health services
  - They have to outsource some of their mental health, and this is a very richly endowed university (yet they don’t have the resources)
- We live in a world where when a person is depressed, when a person is anxious, when a person has any sort of mental or emotional illness, pharmacotherapy plays a role, but it can’t displace psychotherapy
  - You have to be able to put these 2 things together and the data would suggest that the knowledge of your psychotherapist is important, but it’s less important than the rapport you can generate with that individual

Peter asks, “*Based on that, do you believe that the most sacred, protected (if you want to use that term) profession within all of medicine, will then be psychiatry?*”

- Zak would like to think that
- If he had a psychiatric GPT speaking to him, he wouldn’t think that it understood him
- On the other hand, back in the 1960s or ‘70s, there was a program called [ELIZA](https://en.wikipedia.org/wiki/ELIZA), and it was a simple pattern matching program
  - It would just emulate what’s called a [Rogerian therapist](https://en.wikipedia.org/wiki/Person-centered_therapy)
    - “*Where I really hate my mother*.”
    - “*Why do you say you hate your mother?*”
    - “*Oh, it’s because I don’t like the way she fed me.*”
    - “*What is it about the way she fed you?*”
  - This very, very simple pattern matching and this ELIZA program, which was developed by [Joe Weitzbaum](https://news.mit.edu/2008/obit-weizenbaum-0310) at MIT
    - His own secretary would lock herself in her office to have sessions with this thing because it’s not judgmental
- It turns out that there’s a large group of patients who actually would rather have a non-human, non-judgmental person who remembers what they’ve said from last time and shows empathy verbally
- Zak wrote this [book](https://www.amazon.com/AI-Revolution-Medicine-GPT-4-Beyond/dp/0138200130/ref=sr_1_1?crid=18XKW0M8TFBAM&dib=eyJ2IjoiMSJ9.uCwzKQlwaOhpfGx03Yu7DQHjUMSi1ForqHMK6pZsyzPv-sjQyt6Cwx5xgDkcktBiXwcrIeKDG2sbzgJsCg5uJf5p25wWa4OW0WnPZ3F0vJc20WakUKu52ku6qNX3VN9x8l3S9oja6nfNj0fm1fYTux7PMWGvcJ9I_105ZUrEnLs.OX6Gf3d_b-ia87DIKhAJ6Xc9norp6EOGkJ-sOtz-gT0&dib_tag=se&keywords=The+AI+Revolution+in+Medicine%3A+GPT-4+and+Beyond&qid=1715792531&sprefix=the+ai+revolution+in+medicine+gpt-4+and+beyond%2Caps%2C147&sr=8-1) with Peter Lee and Peter made a big deal in the book about how GPT-4 was showing empathy
  - In the book, Zak argued with him that this is not that big a deal, and said, “I *remember from medical school being told that some of the most popular doctors are popular, because they’re very deep empaths, not necessarily the best doctors.*”
- For Zak, cognitive behavioral therapy with AI would not be acceptable to him
- But if it’s giving you insight into yourself and it’s based on the wisdom culled from millions of patients, who’s to say that it’s worse?
  - And it’s certainly not judgmental and maybe it’ll bill less

## How AI may transform and disrupt the medical industry: new business models and the potential resistance from established medical institutions [1:34:45]

**As you look out over the next decade, and we’ll start with medicine, what are you most excited about and what are you most afraid of with respect to AI?**

- With regard to medicine, Zak is most concerned about how AI could be used by the medical establishment to keep things the way they are, to pour concrete over practices
- What he’s most excited about is alternative business models: young doctors who create businesses outside the mold of hospitals
- Hospitals are these very, very complex entities
  - Some of the bigger ones make billions of dollars, but with very small margins, 1-2%

***When you have huge revenue but very small margins, you’re going to be very risk averse and you’re not going to want to change, and so what Zak is excited about is the opportunity for new businesses and new ways of delivering to patients insights that are data-driven***

- What he’s worried about is hospitals doing a bunch of **information blocking and regulations** that will make it harder for these new businesses to get created
  - Understandably, they don’t want to be disrupted
  - That’s the danger

Peter asks, “*In that latter case or that case that you’re afraid of, Zak, can patients themselves work around the hospitals with these new companies, these disruptive companies and say, ‘Look, we have the legal framework that says, I own my data. As a patient, I own my data.*’”

- He knows from his practice that just because patients own the data, doesn’t make it easy to get
  - There is no aspect of his practice that is more miserable and more inefficient than data acquisition from hospitals
  - It’s actually comical
- Zak agrees, and he pays hundreds of dollars to get his data from his patients with rare and unknown diseases in this network extracted from the hospitals because it’s worth it to pay someone to do that extraction, and it’s doable

**Do you think that patients who have their data coupled with AI and companies will be a sufficient hedge against your biggest fear?**

- Unlike his 10-year prostatectomy by robot prediction, he’s not as certain
- But he would give better than 50% odds that in the next 10 years there’ll be at least one company that figures out how to use that patient’s right to access through dirty [APIs](https://en.wikipedia.org/wiki/API)
  - Using AI to clean it up, and provide decision support with human doctors or health professionals to create alternative businesses
- Zak is convinced because the demand is there, and he thinks you’ll see companies that are even willing to put themselves at risk
  - To take the medical risk on that
  - If they do better than a certain level of performance, they get paid more, and if they do worse, they don’t get paid

***Zak believes companies are going to want to be in that space, but he doesn’t want to underestimate the medical establishment’s ability to squish threats***

## Potential positive and negative impacts of AI outside of medicine over the next decade [1:38:30]

**Let’s pivot to AI outside of medicine. What are you most afraid of over the next decade, and what are you most excited about?**

Zak is most concerned about…

- What Zak is most afraid of is a lot of the ills of social networks being magnified by use of these AI’s to further accelerate cognitive chaos and vitriol that fills our social experiences on the net
  - It could be used to accelerate them
- Peter saw an article 2 weeks ago where an individual (maybe currently or formerly part of the FBI) stated they believed that somewhere between 75-90% of individuals on social media were not in fact individuals
- Zak believes that *“It’s going to be harder to actually distinguish reality from human beings, harder and harder and that’s the real problem*”

- We are fundamentally social animals and if we cannot understand our social context in most of our interactions, it’s going to make us crazier

Zak’s most positive aspect would be…

- He thinks that these tools can be used to expand the creative expression of all people
- If you’re a poor driver like he is, he’s going to be a better driver
- If you’re a lousy musician, but have a great ear, you’re going to be able to express yourself musically in ways that you could not do before
- You’re going to see filmmakers who were never meant to be filmmakers before express themselves

> “*I think human expression is going to be expanded because just like [the] printing press…  allowed also expression of all literature in the ways that would’ve not been possible without the printing press. I’m looking forward to human expression and creativity.*”‒ Zak Kohane

- Zak strongly recommends playing with some of the picture generation or music generation capabilities of AI
- Peter is ashamed to admit that his interactions with AI are limited to problem solving with ChatGPT-4
  - He hasn’t done anything creatively with it

## The implications of AI achieving a level of creativity and expertise comparable to exceptional human talents [1:42:00]

- One of Peter’s favorites writers when it comes to science and medicine is [Sid Mukhergee](https://siddharthamukherjee.com/)
  - [Sid was the guest in episodes [#32](https://peterattiamd.com/sidmukherjee/) and [#244](https://peterattiamd.com/sidmukherjee2/)]

- When Peter reads something Sid has written he thinks, “*[Sid] has a special gift that I can appreciate.*”
  - Peter has written a book, but he’ll never write like Sid

**Just as we can appreciate watching an exceptional athlete, artist, or musician, does it mean anything if that line becomes blurred?**

- Zak agrees, that’s the right question
- He has heard an answer many times that he doesn’t like, “[*Deep blue*](https://en.wikipedia.org/wiki/Deep_Blue_(chess_computer)) *beat* [*Kasparov*](https://en.wikipedia.org/wiki/Garry_Kasparov) *in chess, but chess is more popular than it ever was, even though we know that the best chess players in the world are computers.*”
- Zak doesn’t like that answer because if we create Sid GPT and it wrote *Alzheimer’s, the Second Greatest Malady*, and it wrote it in full Sid style, but it was not Sid
  - But it was just as emphatic (i.e., family references, etc.)
  - And it was just a computer
  - ***How would you feel about it? This is the jugular question***
- Peter thinks he would enjoy it, probably just as much
  - But he doesn’t know who he would praise
- Peter is not a religious person, but he loves to see greatness
  - He loves to look at someone who wrote something amazing and say, “*That amazes me*”
  - He loves to be able to look at the best driver in the history of Formula One and study everything about what they did to make them so great
- He’s not sure what it means in terms of that
  - He doesn’t know how it would change that
- Zak grew up in Switzerland, in Geneva, both of his parents were from Poland
- The reason he has an American accent is he went to an international school with a lot of Americans
- All he read was whatever his dad would get him from England and science fiction
  - He’s a big science fiction fan

*Zak goes to science fiction to answer this question*

- It’s not going to be in 10 years, but it could be in 50 years
- You’ll have idols, and the idols will be, “*Yes, Greg Orovich wrote a great novel, but AI-521, their understanding of the human condition is wonderful. I cry when I read their novels*.”
- [AI] They’ll be a part of the ecosystem
- They’ll be entities within us
- Whether they are self-aware or not will become a philosophical question
- Let’s not go that narrow path, that disgusting rabbit hole where I wonder, “*Does Peter actually have consciousness or not? Does he have the same processes as I do?*”
- We won’t know that about these or maybe we will, but will it matter?
- They’re just among us and they’ll have brands, they’ll have companies around them
- They (AI brands) will be superstars:
  - For example, they’ll be Dr. Fubar from Kansas trained on [Ayurvedic medicine](https://en.wikipedia.org/wiki/Ayurveda), the key person for our alternative medicine
  - Not a human, but we love what they do

## Digital immortality and legacy: the potential to emulate an individual’s personality and responses and the ethical questions surrounding it [1:45:45]

***How long until, from at least an intellectual perspective, we are immortal?***

- Peter points out, “*If I died today, my children will not have access to my thoughts and musings any longer*.”
- He wonders if there will be a point during his lifetime when an AI can be trained to be identical to him (at least from a goalpost perspective) to the point where after his death, his children could say, “*Dad, what should I do about this situation?*” And it can answer them in a way that he would have?
- Zak explains that was an early business plan that was generated shortly after GPT-4 came out
- He talked briefly to [Mark Cuban](https://en.wikipedia.org/wiki/Mark_Cuban) because he saw GPT-4 and he got trademarks or copyrights on his voice, all his work and likeness so that someone could not create a Mark who responded in all the ways he does
- It sounds crazy, but there’s a company called [rewind.ai](http://rewind.ai), and Zak has it running right now
  - It’s recording everything that appears on his screen, every sound that it hears, and if characters appear on the screen, it’ll [OCR](https://en.wikipedia.org/wiki/Optical_character_recognition) them
- Then if Zak has a question, he says, “*When did I speak with Peter Attia?*”
  - It’ll find it for him
  - If he asks, “*Who was I talking about AI and Alzheimer’s with?*”
  - It’ll find this video on a timeline

Peter asks, “*How many terabytes of data is this Zak?*”

- Amazingly small; it’s just gigabytes
- It’s possible because compresses it down in real time using Apple Silicon
  - Secondly, you’re old and you don’t realize that gigabytes are not big on a standard Mac that has a terabyte (that’s a thousand gigabytes)
  - Also you can compress audio immensely
  - It’s actually not taking video, it’s just taking multiple snapshots every time the screen changes by a certain amount
- It creates a timeline that has enough data, with enough conversations, that someone could create a pretty good approximation of “public Zak”

*Peter asks if Zak is willing to have rewind.ai on his phone with him 24/7 to record the entire range of experiences (from the good, the bad, the ugly) that are necessary if we want to formulate the essence of ourselves*

- Such as intimate moments, when he is arguing with his wife, when he’s upset at his kids, when he is having the most amazing experience with his postdoc
- Is he willing to take those risks in order to have this data set to be turned into a legacy?
- Zak thinks it’s pretty creepy to come back from the dead to talk to your children
  - He thinks it’s messing with your kid’s head to have you come back from the dead and give advice, even though they might be tempted
  - Technically, he thinks it won’t be that difficult
- He has other goals

**We are being monitored all the time**

- We have iPhones, we have Alexa devices
- Zak doesn’t know what is actually being stored by whom and what
- People are going to use this data in ways that we do or don’t know

***Zak feels that if the little guy, if we have our own copy then we can say, “Well, actually look, this is what I said then… That was taken out of context.” And that’s good***

- Zak has no stake in [rewind.ai](http://rewind.ai)
- He may have paid them for a license to run on his computer, the microphone is always on
  - So when he’s talking to students in his office, it’s taking that down
- Zak adds, “*There are some moments in my life where I don’t want to be on record. There are big chunks of my life that are actually being stored this way.*”

## Parting thoughts [1:50:15]

- Peter has learned a lot in this conversation
- Nothing surprises him more than the timescale that Zak has painted for the evolution of AI within medicine
  - He had no clue we were getting this close to that level of intelligence
- Zak advises Peter to take advantage of AI in his clinic now
  - He would get those videos and sounds and get consent from all his his patients to follow their progress
    - Not just the way they report it, but by their gait and how they look

> “*You can be pushing the envelope using these technologies as just another very smart, comprehensive assistant.*”‒ Zak Kohane

§

## Selected Links / Related Material

**Books by Zak**: [1:15]

- [Microarrays for Integrative Genomics](https://www.amazon.com/Microarrays-Integrative-Genomics-Computational-Molecular/dp/026211271X/ref=sr_1_1?crid=1M99CDBB56KKR&dib=eyJ2IjoiMSJ9.bctrHwKKYhUXuAjdyGrVOJcu37FhtcTKvtLR9BAMA70.6jVbwk7KhbpJCMM0jEdJxu0c6_VUgNyqnw5LEVMqwvE&dib_tag=se&keywords=Microarrays+for+Integrative+Genomics&qid=1715792407&sprefix=microarrays+for+integrative+genomics%2Caps%2C135&sr=8-1) by I Kohane, A Kho, & A Butte (2002)
- [The AI Revolution in Medicine: GPT-4 and Beyond](https://www.amazon.com/AI-Revolution-Medicine-GPT-4-Beyond/dp/0138200130/ref=sr_1_1?crid=18XKW0M8TFBAM&dib=eyJ2IjoiMSJ9.uCwzKQlwaOhpfGx03Yu7DQHjUMSi1ForqHMK6pZsyzPv-sjQyt6Cwx5xgDkcktBiXwcrIeKDG2sbzgJsCg5uJf5p25wWa4OW0WnPZ3F0vJc20WakUKu52ku6qNX3VN9x8l3S9oja6nfNj0fm1fYTux7PMWGvcJ9I_105ZUrEnLs.OX6Gf3d_b-ia87DIKhAJ6Xc9norp6EOGkJ-sOtz-gT0&dib_tag=se&keywords=The+AI+Revolution+in+Medicine%3A+GPT-4+and+Beyond&qid=1715792531&sprefix=the+ai+revolution+in+medicine+gpt-4+and+beyond%2Caps%2C147&sr=8-1) by P Lee, C Goldberg, & I Kohane (2023) | [1:15, 40:02, 1:30:41]

**New journal on AI in medicine**: [NEJM AI](https://ai.nejm.org/) | [1:15]

**Zak’s lab website**: [ZAK LAB](https://zaklab.org/) | [4:30]

**Center for biomedical informatics at Harvard Medical School**: [About DBMI](https://dbmi.hms.harvard.edu/about-dbmi) | Harvard Medical School: Blavatnik Institute Biomedical Informatics (2024) | [4:30]

**With AI Google can recognize different stages of retinopathy**: [Development and Validation of a Deep Learning Algorithm for Detection of Diabetic Retinopathy in Retinal Fundus Photographs](https://pubmed.ncbi.nlm.nih.gov/27898976/) | *JAMA* (V Gulshan et al. 2016) | [30:00]

**Zak’s editorial for** ***JAMA*** **on AI in health care**: [Big Data and Machine Learning in Health Care](https://pubmed.ncbi.nlm.nih.gov/29532063/) | *JAMA* (A Beam, I Kohane 2018) | [31:15]

**Google research paper on transformer**: [Attention is All You Need](https://arxiv.org/abs/1706.03762) | *arXiv* (A Vaswani et al 2017) | [32:00]

**Book about what self-awareness means**: [I Am a Strange Loop](https://www.amazon.com/Am-Strange-Loop-Douglas-Hofstadter/dp/0465030785/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.teG_3-IN7cH0XHblUk9GWu0r_1wy8Bt9Opl9VZ8pTiLGjHj071QN20LucGBJIEps.xKlbaCLQvIrJmNWHxlfAypnCjtzXPtUagJ8AJkG7--0&qid=1715964480&sr=1-1) by Douglas Hofstadter (2007) [46:00]

**Microsoft GPT on the Azure cloud (HIPAA covered)**: [Azure. Limitless Innovation](https://azure.microsoft.com/en-us/) | Microsoft.com (2024) | [59:30, 1:21:30]

**Using AI to interpret echocardiograms**: [Vision–language foundation model for echocardiogram interpretation](https://pubmed.ncbi.nlm.nih.gov/38689062/) | *Nature Medicine*(M Christensen et al 2024) | [1:01:15]

**After age 40, 30% of your transcriptome goes down**: [Gene regulation and DNA damage in the ageing human brain](https://pubmed.ncbi.nlm.nih.gov/15190254/) | *Nature* (T Lu et al 2004) | [1:09:30]

**Detecting hypoglycemia in drivers using cameras focused on their eyes**: [1:11:30]

- [Leveraging Large Language Models to Analyze Continuous Glucose Monitoring Data: A Case Study](https://pubmed.ncbi.nlm.nih.gov/38645024/) | *medRxiv* (E Healey et al 2024)
- [Machine Learning to Infer a Health State Using Biomedical Signals — Detection of Hypoglycemia in People with Diabetes while Driving Real Cars](https://ai.nejm.org/doi/full/10.1056/AIoa2300013) | *NEJM AI* (V Lehmann et al 2024)

**Study of electronic health records of autism patients**: [The co-morbidity burden of children and young adults with autism spectrum disorders](https://pubmed.ncbi.nlm.nih.gov/22511918/) | *PLOS ONE* (I Kohane et al 2012) | [1:15:45]

**NEJM picture of the week**: [Image Challenge October 5, 2023](https://www.nejm.org/image-challenge?ci=20231005) | [1:22:15]

**App that records everything on your screen**: [Your AI assistant that has all the context](https://www.rewind.ai/) | rewind.ai (2024) | [1:46:45]

**More about GPT-4 and AI in medicine**: [Resources for introduction to ASI, post 2022](https://www.zaklab.org/blog/resources-for-introduction-to-ai-post-2022/) | zaklab.org (Z Kohane 2024)

§

## People Mentioned

- [Peter Szolovits](https://www.csail.mit.edu/person/peter-szolovits) (Professor of Computer Science and Engineering and head of the Clinical Decision-Making Group within CSAIL at MIT) [4:00]
- [Peter Lee](https://www.microsoft.com/en-us/research/people/petelee/) (President of Microsoft Research, expert in machine learning and data science) [5:15, 42:15]
- [Bill Gates](https://en.wikipedia.org/wiki/Bill_Gates) (Founder of microsoft) [7:15]
- [Alan Turing](https://en.wikipedia.org/wiki/Alan_Turing) (1912-1954, English mathematician and computer scientist, considered to be the father of AI) [8:30]
- [Garry Kasparov](https://en.wikipedia.org/wiki/Garry_Kasparov) (Russian chess grandmaster and former World Chess Champion) [10:45, 1:43:00]
- [Edward Shortliffe](https://en.wikipedia.org/wiki/Edward_H._Shortliffe) (Chair Emeritus & Adjunct Professor of Biomedical Informatics at Columbia University, pioneer of AI use in medicine) [17:30]
- [Marvin Minsky](https://en.wikipedia.org/wiki/Marvin_Minsky) (1927-2016, Pioneer of AI who co-founded MIT’s AI laboratory) [24:30]
- [Eliezer Yudkowsky](https://en.wikipedia.org/wiki/Eliezer_Yudkowsky) (AI researcher who has written about decision theory and ethics) [41:15]
- [Sam Altman](https://en.wikipedia.org/wiki/Sam_Altman) (CEO of OpenAI) [42:00]
- [Carey Goldberg](https://www.linkedin.com/in/cagoldberg/) (Science/health/medicine reporter) [42:15]
- [Douglas Hofstadter](https://en.wikipedia.org/wiki/Douglas_Hofstadter) (cognitive and computer scientist) [45:45]
- [Geoffrey Hinton](https://en.wikipedia.org/wiki/Geoffrey_Hinton) (one of the intellectuals leaders of neural network architecture) [53:00]
- [Bruce Yankner](https://yankner.hms.harvard.edu/people/bruce-yankner) (Co-Director of the Paul F Glenn Center for the tBiology of Aging and Professor of Genetics and Neurology at Harvard Medical School) [1:09:30]
- [George Daley](https://hms.harvard.edu/faculty-staff/george-q-daley) (Dean of Harvard Medical School) [1:24:45]
- [Joe Weitzbaum](https://news.mit.edu/2008/obit-weizenbaum-0310) (1923-2008, professor emeritus of computer science who created an empathic psychologist program) [1:33:30]
- [Sid Mukhergee](https://siddharthamukherjee.com/) (Assistant Professor of Medicine at Columbia University and Pulitzer Prize-winning author) [1:42:15]
- [Mark Cuban](https://en.wikipedia.org/wiki/Mark_Cuban) (businessman, film producer, investor, and television personality) [1:46:30]

§

![](https://peterattiamd.com/wp-content/uploads/2024/07/bio-isaackohane-500x500.jpeg)

##### Isaac (Zak) Kohane M.D., Ph.D

Isaac (Zak) Kohane earned his MD/PhD from Boston University. He completed his postdoctoral work at Boston Children’s Hospital, where he has since worked as a pediatric endocrinologist. He joined the faculty at Harvard Medical School in 1992, serving as Director of Countway Library from 2005 to 2015 and as Co-Director of the Center for Biomedical Informatics during the same period, before it became the Department of Biomedical Informatics in July 2015. Dr. Kohane is the inaugural Chair of the [Department of Biomedical Informatics](https://dbmi.hms.harvard.edu/) and the Marion V. Nelson Professor of Biomedical Informatics at Harvard Medical School.

Dr. Kohane is a member of the Institute of Medicine and the American Society for Clinical Investigation. Kohane has published several hundred papers in the medical literature and authored the widely-used books [*Microarrays for an Integrative Genomics*](https://www.amazon.com/Microarrays-Integrative-Genomics-Computational-Molecular/dp/026211271X/ref=sr_1_1?crid=1M99CDBB56KKR&dib=eyJ2IjoiMSJ9.bctrHwKKYhUXuAjdyGrVOJcu37FhtcTKvtLR9BAMA70.6jVbwk7KhbpJCMM0jEdJxu0c6_VUgNyqnw5LEVMqwvE&dib_tag=se&keywords=Microarrays+for+Integrative+Genomics&qid=1715792407&sprefix=microarrays+for+integrative+genomics%2Caps%2C135&sr=8-1) (2003) and [*The AI Revolution in Medicine: GPT-4 and Beyond*](https://www.amazon.com/AI-Revolution-Medicine-GPT-4-Beyond/dp/0138200130/ref=sr_1_1?crid=18XKW0M8TFBAM&dib=eyJ2IjoiMSJ9.uCwzKQlwaOhpfGx03Yu7DQHjUMSi1ForqHMK6pZsyzPv-sjQyt6Cwx5xgDkcktBiXwcrIeKDG2sbzgJsCg5uJf5p25wWa4OW0WnPZ3F0vJc20WakUKu52ku6qNX3VN9x8l3S9oja6nfNj0fm1fYTux7PMWGvcJ9I_105ZUrEnLs.OX6Gf3d_b-ia87DIKhAJ6Xc9norp6EOGkJ-sOtz-gT0&dib_tag=se&keywords=The+AI+Revolution+in+Medicine%3A+GPT-4+and+Beyond&qid=1715792531&sprefix=the+ai+revolution+in+medicine+gpt-4+and+beyond%2Caps%2C147&sr=8-1) (2023). He is also Editor-in-Chief of [*NEJM AI*](https://ai.nejm.org/). He served as co-author of the Institute of Medicine Report on Precision Medicine that has been the template for national efforts. He develops and applies computational techniques to address disease at multiple scales: from whole healthcare systems as “living laboratories” to the functional genomics of neurodevelopment with a focus on autism. [[Harvard](https://dbmi.hms.harvard.edu/people/isaac-kohane)]

X: [@zakkohane](https://twitter.com/zakkohane?lang=en)

Zak’s lab website: [ZAKLAB](https://zaklab.org/)