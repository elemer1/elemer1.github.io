# #220 ‒ Ketamine: Benefits, risks, and promising therapeutic potential | Celia Morgan, Ph.D.

**Source:** [https://peterattiamd.com/celiamorgan/](https://peterattiamd.com/celiamorgan/)

---

Celia Morgan is a Professor of Psychopharmacology at the University of Exeter who has authored numerous publications on the potential therapeutic uses of ketamine in mental healthcare.  In this episode, Celia dives deep into the neurobiology of ketamine, how it affects users, and how it differs from other, more classical psychedelics (LSD, MDMA, PCP, and psilocybin). She explains the potential promise of ketamine as a treatment for recalcitrant depression and addiction, and she details the results from her clinical trials in these areas. She discusses the importance of using ketamine in combination with psychotherapy to maximize its benefits, the potential risks associated with ketamine use, and advice for those interested in the therapeutic use of ketamine.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/celiamorgan/the_Drive_public.png)

Play

#220 ‒ Ketamine: Benefits, risks, and promising therapeutic potential | Celia Morgan, Ph.D.

#220 ‒ Ketamine: Benefits, risks, and promising therapeutic potential | Celia Morgan, Ph.D.

1x15s30s

0:001:27:36

## We discuss:

- Celia’s training and interest in ketamine [2:15];
- The history of ketamine, medical uses, and use as a party drug [3:30];
- Neurobiology and pharmacology of ketamine [8:15];
- Ketamine regulation and abuse, and how it compares with psychedelics and other molecules [18:15];
- Ketamine as a therapeutic for depression [30:45];
- The brain under the influence of ketamine and theoretical mechanisms for its anti-depressive effects [48:00];
- Risks and concerns with overusing ketamine, and what an intermittent or maintenance dose might look for a patient [57:15];
- Treating addiction with ketamine: Celia’s studies of alcohol dependance [1:04:00];
- Advice for people considering the therapeutic use of ketamine [1:19:45]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Celia Morgan is a Professor of Psychopharmacology at the University of Exeter in the United Kingdom
- Celia’s research focuses on the benefits and side effects of recreational drugs and alcohol on cognition, behavior, and neurobiology
- She has authored numerous publications on the potential uses of ketamine and other drugs as therapies in mental health
- She completed her undergraduate degree and PhD at University College London, followed by a scholarship program at Yale University
- Celia conducted research at the University of Melbourne prior to returning to University College London
- She eventually moved on to the University of Exeter, where she became the Chair of Psychopharmacology in 2015
- In this episode, we dig deep into ketamine
  - We talk about the neurobiology and the chemistry of ketamine
  - How it affects individuals
  - How it affects specific parts of the brains
  - How it differs from other things that we might think of as psychedelics
    - Although Peter doesn’t really consider ketamine to be a psychedelic
    - We contrast it with things like psilocybin and LSD
- We then talk about the potential promise of ketamine for treating drug-resistant (or recalcitrant) depression and alcoholism
- We talk about the importance of therapy being offered concurrently with ketamine treatment, as many people listening to this might wonder if ketamine therapy is indeed for them

## Celia’s training and interest in ketamine [2:15]

**Celia’s training**

- Celia did her undergraduate in psychology with pharmacology and astrophysics
- She did a PhD program at University College London
  - As part of that, she spent time at Yale on a scholarship to do some research in the US
- Her PhD was largely focused on the effects of ketamine
  - She looked at the acute effects of ketamine as a model of psychosis
    - At the time people were using ketamine with the idea that would help us understand the neuro-biological underpinnings of psychosis, because actually, from the outside, ketamine looks a little bit similar to people who are psychotic
    - They were using that to map the kind of cognitive processes altered by ketamine
  - Simultaneously, she was also looking at people who take ketamine recreationally
    - At the time that was quite a big problem in the UK
- When she went to the US, it was to work on neuro-imaging studies looking at ketamine as a model for psychosis
  - This was before it really became established as an antidepressant

## The history of ketamine, medical uses, and use as a party drug [3:30]

![](https://peterattiamd.com/wp-content/uploads/2022/08/f1-celiamorgan.png)

**Figure 1.  The chemical structure of ketamine.**  Image credit: [c&en 2020](https://cen.acs.org/biological-chemistry/neuroscience/Ketamine-revolutionizing-antidepressant-research-still/98/i3)

- [Ketamine](https://en.wikipedia.org/wiki/Ketamine) was synthesized in the ‘60s as an anesthetic to replace [PCP (phencyclidine)](https://en.wikipedia.org/wiki/Phencyclidine)
- People know PCP as angel dust
  - There is a kind of folklore around it, of people running at the police and being shot down yet kept running.
  - The problems with PCP is it had this protracted psychosis-like effects that lasted for a really long time following anesthesia
  - It was still a good analgesic anesthetic
- Ketamine was synthesized as a similar molecule, so it still worked on the same receptor in the brain, the [NMDA receptor](https://en.wikipedia.org/wiki/NMDA_receptor), but it was 10 times less potent
- The drug company that synthesized it was initially really impressed by its analgesic and anesthetic effects, but then with increasing clinical experience, it was noticed that people were coming around from ketamine anesthesia reporting a variety of weird effects
  - Things like hallucinations and out-of-body experiences
  - And that’s what’s really limited its routine clinical use
- But it’s still one of the most widely used anesthetics in the world today
- It’s on the [World Health Organization list of essential medicines](https://www.who.int/groups/expert-committee-on-selection-and-use-of-essential-medicines/essential-medicines-lists)
- One of the things Peter remembers from his clinical training is ketamine doesn’t produce respiratory depression
  - This was a perk
  - Most things used as anesthetic agents have this problem where if you overshoot them you can cause respiratory depression
    - This is not an issue if you’re doing general anesthesia because you have an endotracheal tube in the main stem bronchus, so you’re breathing for the patient
    - Otherwise though, respiratory depression is a frightening consequence that must be managed closely
    - You don’t have to do this with ketamine

**Is it true that kids are less susceptible to the hallucinogenic effects of ketamine?**

- It is used more with children
- Celia tried to do a study on this, but it never really came off
- She doesn’t know if people have asked kids on ketamine if they have hallucinations
- Ketamine is widely used in pediatrics, geriatrics, and battlefield medicine
  - It was the most widely used anesthetic in the Vietnam War
- It’s a really good question about kids
- Some people are trialing ketamine for antidepressant use in adolescents

**The benefits of ketamine as an anesthetic**

- It’s really safe, physiologically as an anesthetic, because it doesn’t slow your breathing or your heart rate
  - So when you’ve lost a lot of blood, it’s good as well because it actually even vaguely increases your blood pressures
  - That’s why it’s a widely used aesthetic
- Peter can understand why it became a turning point in the field medicine of Vietnam
  - It’s the perfect anesthetic in trauma and shock where patients are hypovolemic, their blood pressure is going down
  - Ketamine is an agent that acts slightly like a vasopressor, it raises blood pressure without the respiratory depression
  - Celia adds, “*The acute experience must be really unusual when you’re in that setting*”
- The benefit of not having to intubate people made it really popular in developing countries where there is limited ability to intubate patients
- Ketamine is a really important medicine in anesthesia still, and Celia thinks that’s something people forget with all the new uses of ketamine
- It’s ridiculous to think that anesthesia is something we’ve only had vor about 140 years
- The concept of losing consciousness and how you measure it is fascinating
- We can measure on an [EEG](https://en.wikipedia.org/wiki/Electroencephalography) how your consciousness drops, but Celia doesn’t think we really know what turns it on and off

**Is ketamine an analog of PCP?**

- They’re all under the class of [arylcyclohexylamines](https://en.wikipedia.org/wiki/Arylcyclohexylamine)
- [Edward Domino](https://www.nature.com/articles/s41386-022-01280-x) coined the term, **dissociative anesthetics** to describe PCP and ketamine
  - People include [nitrous oxide](https://en.wikipedia.org/wiki/Nitrous_oxide) in that category
  - This is based on the fact that they kind of disassociate you from your body and are characterized by these out-of-body experiences
    - This can be quite helpful in anesthetic use
  - They are related compounds; their main action is on the NMDA receptor

## Neurobiology and pharmacology of ketamine [8:15]

**A primer on how neurotransmitters work, how neurons can amplify or attenuate the response to them, and the action of ketamine on the NMDA receptor**

- [Glutamate](https://en.wikipedia.org/wiki/Glutamate_(neurotransmitter)) is the major **excitatory neurotransmitter** in the brain and it’s prevalent all across the brain
- One of the receptors that glutamate works on is the [NMDA receptor (N-methyl-D-aspartate receptor)](https://en.wikipedia.org/wiki/NMDA_receptor)
- The NMDA receptor is really important in a lot of our higher cognitive functions
- It plays a fundamental role in learning and memory
  - Particularly in a process in learning called **long term potentiation**
  - This is where brain cells that activate at the same time‒ if they both activate, then they’re more likely to activate in future
  - This is characterized by this saying, “*Neurons that fire together, wire together*”
  - Glutamate is really important in that and other excitatory functions in the brain
- [GABA](https://en.wikipedia.org/wiki/%CE%93-Aminobutyric_acid) is an **inhibitory neurotransmitter**
  - It shuts down the flow of electrical impulses across the brain

***Peter’s summary: glutamate is excitatory and GABA is inhibitory***

- We will talk about GABA analogs that mimic alcohol later on

**Are there examples of drugs that work to amplify glutamate?**

- [Lamotrigine](https://en.wikipedia.org/wiki/Lamotrigine) is a drug used in seizures tend to reduce the flow of glutamate in the brain, particularly in the prefrontal context
- Celia can’t think of examples that amplify glutamate

**What are GABA analogs doing? Why do people feel relaxed when they drink?**

- Things like [benzodiazepines](https://en.wikipedia.org/wiki/Benzodiazepine) are working on GABA

***Drugs like alcohol and benzos, they all increase GABA activation***

- These slow down, kind of dampens down the brain
- They reduce things like anxiety
- They slow your motor function
- They generally work by inhibiting the flow of electrical impulses across your brain
  - This is part of the reason why we get symptoms you get, when you stop drinking
  - Your brain is a bit like a seesaw‒  the alcohol’s being pushing down on that side and keeping it dampened down, and then you release that and you go into a more excitatory state
- Celia works a lot with alcoholics.
- From alcohol **withdrawal**, you can get seizures and the shakes, and that’s all due to this increase in excitation

***That’s why withdrawal from strong GABA promoters like benzos and ethanol can be fatal if not managed correctly***

- People intuitively know that you can stop opioids immediately, and it might be the most painful thing in the world, but it won’t be fatal
- Whereas if you take a person who’s on a high dose of benzodiazepines or a person who drinks a lot of alcohol and you stop that abruptly, it actually can be fatal
- Withdrawal can be lethal when you stop taking certain drugs
  - Because of this huge increase in excitation
- With repeated alcohol use, your brain gets used to having all this GABA on board and then you get adaptation and your brain kind of up-regulates to counteract that
  - And then when you remove it… you can die from withdrawal
- Celia works with severe alcoholics, it’s unsafe for them to stop straight away
  - They have to cut down and use things like benzodiazepines in withdrawal
- People do think about opiate withdrawal as a really difficult thing, but you wouldn’t die from that
- It’s only from **withdrawal from these inhibitory substances** like alcohol and benzodiazepines

**Theory of how ketamine works**

- It’s not 100% clear how ketamine works
- The theory is that ketamine blocks directly the NMDA receptors on inhibitory (GABAergic) neurons, triggering a downstream cascade involving increased excitatory (glutamatergic) signaling
  - The blue cells in the figure below is a glutamatergic neuron (excitatory neuron)
  - The green cell in the figure below is an GABAergic interneuron (inhibitory neuron)  containing NMDA receptors that can be blocked by ketamine
  - Inhibitory neurons release neurotransmitters that limit release of glutamate
    - Glutamate is an excitatory neurotransmitter
  - Ketamine is thought to block NMDA receptors which reduces neurotransmitter release from inhibitory neurons, shown as an X in the figure below
    - This results in increased release of glutamate

![](https://peterattiamd.com/wp-content/uploads/2022/08/f2-celiamorgan-1024x550.png)

**Figure 2.  Proposed mechanism of ketamine’s action on NMDA receptors in the neocortex.**  Image credit: [c&en 2020](https://cen.acs.org/biological-chemistry/neuroscience/Ketamine-revolutionizing-antidepressant-research-still/98/i3)

- And maybe it’s a combination of the two, that the ketamine blocks NMDA receptors on GABAergic neurons
  - So GABA neurons synapse to your glutamate neurons
    - The blue cell in the figure above is a presynaptic glutamatergic neuron
    - The red cell is a postsynaptic neuron
    - Ketamine blocks release from the GABA neuron thereby affecting glutamate neurons
  - GABA neurons put the brakes on excitation

***If you block an NMDA receptor on a GABAergic neuron, then you’re going to have a net effect of increasing glutamate flow in presynaptic cells***

- People have become interested in the downstream mechanisms for potential therapeutic uses of ketamine

**Does ketamine have different effects on a person based on the dose they receive?**

- Peter notes, “*Ketamine is one of these drugs where the dose makes the poison. I mean, I think that’s true of most drugs*.”
- Yes, it can cause anything from mild hypnosis to some dissociation, to complete anesthesia
- Celia works a lot with  people who take ketamine non-medically or recreationally
  - At  lower doses they get stimulant properties
  - As the dose increases, they get perceptual distortions and illusions…  people talk about floating
  - Higher doses produce a more profound effect; maybe not hallucinations, but changes in perception of reality
  - At the highest dose, people experience catatonic effects and really, really profound hallucinations
    - It’s these really high doses that are very dangerous
    - A couple of people have died from taking ketamine and then having a bath because they’re completely disassociated from reality and they drowned

> “*Ketamine users are very vulnerable to accidents at these higher doses because you are completely dissociated from reality*”‒ Celia Morgan

- Peter compares this to [LSD](https://en.wikipedia.org/wiki/Lysergic_acid_diethylamide) in the sense where it really has no [LD50](https://en.wikipedia.org/wiki/Median_lethal_dose), meaning there’s no amount of LSD that is going to create a lethal physiologic process
  - But this is not to say that LSD is completely safe because it can alter your behavior and perception of reality such that you put yourself in harms way
  - [Tylenol (acetaminophen)](https://en.wikipedia.org/wiki/Paracetamol) would poison your liver at a certain dose
- There’s no LD50 for ketamine from a purely pharmacological standpoint because it doesn’t cause respiratory depression and other things that we worry about
- Celia doesn’t know of anyone getting a large enough dose of ketamine to be toxic

**There are physiological problems with repeatedly taking high doses of ketamine**

- Ketamine has direct toxicity on the epithelial cells
  - It can damage the lining of your bladder
    - This is something that only emerges with people who use really high doses
- With LSD, more of your top down higher cognitive functions are preserved as compared to ketamine
- People taking high doses of ketamine will become completely catatonic and are much more vulnerable to accidents
  - The example of drowning in a bathtub seems tragic
  - It’s hard to imagine how dissociated you would have to be to go into a bathtub, inhale water, and not respond
  - You are completely dissociated
  - Various accidents can happen

**How ketamine can be administered**

- Most studies of ketamine used as an anesthesia or to treat depression give it intravenously
  - This is the most characterized route of administration
  - It provides the best bioavailability
- There are other ways to administer it
  - Intramuscular injection provides good availability in the blood
  - People are starting to use sublingual administration‒ putting it under the tongue
  - Drug users first re-popularized intranasal administration
  - Now intranasal administration is patented by the pharmaceutical company for treating depression
  - Oral dosing in another option, but the bioavailability is not as good

**With oral administration, what happens in the liver with the first-pass effect?  Is there any liver toxicity?**

- Celia assumes people are currently doing toxicity studies
- Pharmaceutical companies are looking at overall dosing as a potential
- The bulk of the research has been done on intravenous, intramuscular, and more recently, intranasal administration

## Ketamine regulation and abuse, and how it compares with psychedelics and other molecules [18:15]

**Ketamine is currently a schedule III drug**

- In the 1970s it was used liberally as an anesthetic and was unscheduled
- Now it’s a much more regulated compound
- In the late 90s it was classified as a schedule III drug
  - The figure below summarizes drug scheduling

![](https://peterattiamd.com/wp-content/uploads/2022/08/f3-celiamorgan-1024x966.png)

**Figure 3. Scheduling of controlled substances.**  Image credit: [Congressional Research Service 2021](https://sgp.fas.org/crs/misc/R45948.pdf)

- [Putin](https://en.wikipedia.org/wiki/Vladimir_Putin) banned ketamine in Russia, it’s an interesting story
  - The very attractive French actress [Brigitte Bardot](https://en.wikipedia.org/wiki/Brigitte_Bardot) petitioned Putin to use ketamine in animals
    - Its widely used in veterinary anesthesia
  - So he removed the ban for animals but kept the ban in place for humans
    - This is horrendous considering what an amazing anesthetic it is
- In the UK in 2006 it became a Class B drug scheduled under the [Misuse of Drugs Scheduling Act](https://en.wikipedia.org/wiki/Drugs_controlled_by_the_UK_Misuse_of_Drugs_Act)
  - It still has medical use
- In the United States, the other psychedelics, LSD, psilocybin, and even MDMA (which is not a psychedelic) are schedule I, which means they have no medical use at all
  - See the previous figure
- Celia finds this drug policy interesting because of all these compounds, ketamine is the most likely to be abused
- Ketamine is still legal for medical use; it has an amazing number of medical uses

**Do you consider MDMA a psychedelic?**

- Peter is not an expert but he does not personally consider MDMA a psychedelic
- He would put it in the category of an empathogen because it doesn’t really cause any dissociation
  - It’s not altering perception in the way that LSD or psilocybin would

**Schedule I drugs**

- Schedule I implies no medical use and a high potential for addiction
- There is certainly medical use for psilocybin and MDMA
  - They have a low potential for abuse
- Interestingly, ketamine clearly has a high medical use

**What is the potential for abuse of ketamine?**

*How addictive is ketamine as compared to benzodiazepines and opioids?*

- Celia doesn’t have good data on this but in terms of physical withdrawal symptoms…. It depends on how you assess addictive properties
  - People become addicted to things that are also multifunctional tools, such as coffee
- Celia did a [study](https://pubmed.ncbi.nlm.nih.gov/18355990/) of people that use ketamine
  - People who use ketamine non-medically are probably at a higher potential for abuse
  - About 9% of them had symptoms of some sort of dependence or craving
  - It’s hard to benchmark ketamine against opioids and benzos
- Peter’s memory is that about 20% of users of prescription opioid painkillers become addicted
  - This is staggering, 1 in 5 people who get an opioid prescription could go on to abuse them later
    - It seems absurdly high
  - This doesn’t include heroin, where the number may be higher
  - Heroin users would be a different subgroup of the population so it’s not really an apples-to-apples comparison
- Celia notes that so far the data seem to suggest that a very low number of people prescribed ketamine (for recalcitrant depression or something else) experience dependency
- This depends on how you **define addiction**
  - Is it physical withdrawal?
  - Is it impacting everyday functioning?
  - Is it seeking drug beyond your prescription (dose escalation)?

***Celia has worked with people who take ketamine and a small proportion do become addicted***

**Ketamine can have serious physical consequences, bladder toxicity**

- Celia has worked with 16-year old girls who abuse ketamine that had their bladder removed (cystectomy)
  - Now they have to wear a colostomy bag
  - This is a really dire consequence but it’s quite rare
  - These are girls who were not using ketamine for any medical indication but became addicted to it recreationally
- There was a ketamine epidemic in the UK in the early 90s-2000s
  - Celia was researching it then
  - People didn’t really know anything about ketamine
- Peter was in medical school in the 90s and learned about it as Special K
- In the UK some people called it kiddie smack
  - They compared it to heroin for kids
- Recreational users were taking grams and grams of it every day
  - This can produce the serious side effects discussed
  - [Tachyphylaxis](https://en.wikipedia.org/wiki/Tachyphylaxis) occurs; this is like a rapidly developing tolerance

***If you do administer ketamine repeatedly in a short time window, you do need to give higher and higher doses***

- These people would take doses that would floor an elephant, but they would still be walking around and functioning
  - They weren’t passing out in their apartments for hours

**What is the drive for people to abuse ketamine?**

- Celia spoke to about 120 ketamine users about this
  - Some of them said very pragmatic things, “*It’s cheap.  It gets me really off my head*”
- Escapism is one reason people take it
- There are some slight opioid actions of ketamine
- [Psychonauts](https://en.wikipedia.org/wiki/Psychonautics) were almost addicted to chasing the consciousness and the insights they felt they were getting
  - They would take more and more to try and get more insights
  - A high-profile example is [John Lilly](https://en.wikipedia.org/wiki/John_C._Lilly), a neuroscientist in California; the film [*Altered States*](https://en.wikipedia.org/wiki/Altered_States) is about him
    - He did a lot of unusual research
    - He gave LSD to dolphins
    - He writes in his book, [*The Scientist*](https://www.amazon.com/Scientist-Metaphysical-Autobiography-John-Lilly/dp/0914171720/ref=sr_1_1?crid=2HVXSZ7RHWIZP&keywords=the+scientist+john+lilly&qid=1656516022&sprefix=the+scientist+john+%2Caps%2C96&sr=8-1), that he invented flotation tanks
    - His book is a great account of ketamine addiction
    - He became completely addicted to ketamine to the extent that he had an intravenous drip of ketamine pretty much 24 hours a day
    - He became a psychotic where he had these revelations and went to tell the president of the USA, about the world being taken over by computers
    - Celia can’t remember the end of the book, how he managed to get off ketamine
- Another book is [*Journeys to the Brighty World*](https://www.amazon.com/Journeys-bright-world-Marcia-Moore/dp/0914918125/ref=sr_1_fkmr0_1?crid=JGAPT2VYJHTU&keywords=journeys+to+the+bright+world+by+marcia+moore&qid=1656516338&sprefix=journeys+to+the+brighty+world+by+marcia+moore%2Caps%2C121&sr=8-1-fkmr0) by [Marcia Moore](https://en.wikipedia.org/wiki/Marcia_Moore)
  - Her husband was an anesthetist and she experimented with ketamine
  - She had a very different subjective experience
  - John Lilly had hallucinations related to being in a computer in a machine state
  - Her hallucinations were very soft and round and going back to the earth
  - Sadly, she took some ketamine outside and froze to death
    - Again, this is the thing where you completely dissociate from your body
- When people take really high intravenous doses of ketamine they rapidly develop [tolerance](https://en.wikipedia.org/wiki/Drug_tolerance)

**How does ketamine compare to PCP?**

- Peter hasn’t taken care of any patients strung out on PCP
- He remembers the lore of the drug, it was a much more aggressive drug
  - People on PCP seemed almost bulletproof
  - They’d punch their hand through a glass window, be unfazed by the fact that they just broke every bone in their hand
- Celia thinks PCP produces a protracted psychotic state
- She thinks police were given nets to catch people on PCP
  - There was a lot of police brutality associated with people taking PCP
- She has looked in the literature for examples of this kind of bulletproof phenomena and can’t find any
- There are definitely examples of people having protracted psychotic-like symptoms with hallucinations and needing to be hospitalized when on PCP
- She find the violent aspect of people on PCP running at police hard to imagine
- PCP was never really a street drug in the UK
  - She’s not aware of many reports in the US either

> “*Nobody’s really thinking about using PCP, but maybe that would be something to investigate*”‒ Celia Morgan

**Contrast ketamine with psilocybin and LSD**

- Psilocybin and LSD are much more similar to each other
- Psilocybin and LSD have a completely different action, they work on the [5-HT2A receptor](https://en.wikipedia.org/wiki/5-HT2A_receptor)
- Ketamine works on these kind of glutamatergic receptors
- There are some similarities in the acute experience
  - People talk about **EO dissolution** and ketamine causes that quite profoundly‒ so you lose your sense of self
  - You can **think more clearly** on LSD and psilocybin
  - Ketamine impairs some of your **higher cognitive functions** and causes that kind of [analgesia](https://en.wikipedia.org/wiki/Pain_management), which is associated with ketamine’s [anxiolytic](https://en.wikipedia.org/wiki/Anxiolytic) effect
    - Even at higher doses, people don’t report **anxiety**, whereas some patients describe things that sound scary, but they don’t feel the kind of physiological anxiety
  - In contrast, people on drugs like LSD and psilocybin report being absolutely terrified by the experience
  - Maybe that’s the **dissociation** that happens more on drugs like ketamine where you have the sense of being separate and everything’s kind of emotionally numb
- Peter comments that perhaps ketamine has a greater inhibitory effect
  - It has less of a negative feedback loop
  - Anybody who’s tried other psychedelics will say, “*Look, if you go back to the well too many times, you can get stung*.”
- Celia adds that ketamine is unpredictable in that sense
- If you’re looking for escapism, you don’t want to escape into absolute terror

## Ketamine as a therapeutic for depression [30:45]

**Early research on using ketamine to treat depression**

- 7-9 years ago a physician friend of Peter’s told him about prescribing intranasal ketamine for patients with depression
  - They used it once a week
- At the time Peter couldn’t find a lot of literature on it, only some interesting case reports
- One study in India was interesting but he forgot about it until recently with the advent of ketamine clinics, which have become almost as ubiquitous as Starbucks
- Celia mentions an early study in Iran, it may even date back to dodgy work by [Salvador Roquet](https://chacruna.net/salvador-roquet-remembered/)
  - He was a psychotherapist
  - He was working for the Mexican government interrogating people
  - He was giving ketamine with other psychedelics to try to produce changes in people’s brain state
    - This is probably the first documented cases of people using ketamine as a psychiatric therapy, in the 60s
    - A summary of his work using psychedelic psychotherapy was [published](https://journals.sagepub.com/doi/abs/10.1177/002216787701700406?journalCode=jhpa) in 1977
- In the 70s a study came out of Iran that caused an explosion in ketamine depression research
- [Robert Berman’s](https://www.crunchbase.com/person/rob-berman) group at Yale did an early study in 2000 giving a single ketamine infusion to patients with treatment-resistant depression
  - They [showed groundbreaking results](https://pubmed.ncbi.nlm.nih.gov/10686270/), you could get rapid reduction in depressive symptoms
  - Traditional [SSRIs](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor) ([Prozac](https://en.wikipedia.org/wiki/Fluoxetine) and traditional antidepressant drugs) have a delayed onset of action
    - It was accepted that they would take 2 weeks to work
  - Why ketamine works immediately in people with treatment-resistant depression was unknown

**What dose of ketamine is used?**

- Early studies administered ketamine intravenously using **0.5 mg/kg**
  - So an 80 kg person would get 40 mg intravenously over 40 minutes
- A recreational user whos not habituated but simply bought ketamine from a drug dealer would take 100-200 mg
  - They would typically take in intranasally which has slightly less bioavailability
    - But it’s still a good way to administer it

**What is the experience of the patient getting 40 mg of ketamine?**

- It’s highly variable
- Celia must have given hundreds of people ketamine in research studies and the response is really variable and not necessarily predictable
  - They weight-adjust all of their doses
- At 0.5 mg/kg patients might feel slightly drunk and disoriented, slightly dissociated
- At the other end of the spectrum (at higher doses) Celia remarks, “*People have gone down a canoe in their mother’s eardrum… doing really weird stuff, having frank hallucinations*”
- Peter is curious‒ for any agent he has ever ingested, from alcohol to acetaminophen to a psychedelic agent, he needs 3x what anybody else needs to feel it
  - He’s always been curious why that is
- In her research, Celia has found that people with a family history of alcohol problems, their acute response to ketamine is less
- A higher BMI is predictive of a higher acute effect
  - Maybe this has something to do with the ratio of lean muscle to fat
- Therapeutically with depression, they have found that the more suicide attempts people have made, the better their response

***More severe patients are more likely to have a response***

**Is the acute response predictive of abatement of depression?**

- The acute response is what happens in the 2-3 hours the person is under the influence of the drug
  - It’s a 40 minute infusion and presumably they are under the influence of the drug for another couple hours
- This is a good question and the field is divided
- Acute effects have typically been measured with a scale called the **Clinician-Administered Dissociative States Scale**
  - It was designed to look at dissociation from people having flashbacks from traumatic experiences
  - They ask some questions relevant for ketamine, but some that are not
  - For example, “*Are things moving in slow motion? Have colors changed? Do you have a sense of forgetting chunks of what has happened?*”
- In studies of dissociative effect, about 25% find this predicts the therapeutic effects
- Celia has done a [systematic review](https://pubmed.ncbi.nlm.nih.gov/32485203/) of this
- In general psychiatry, there’s a feeling that these acute effects are a nuisance and there’s a whole research effort devoted to finding drugs that don’t have these acute effects, with limited success
- When you look at the data and people who use a more nuanced way of looking at the acute effects, mystical experiences do seem to predict the success of ketamine treatment

**Peter’s summary: it’s not clear if the person who’s feeling slightly drunk is going to have a lesser outcome or a greater outcome than the person who’s on the canoe in their mom’s eustachian tube**

*Is it a fair assessment to say we don’t know what questions to ask patients during the acute phase window or we’re not doing analysis on a fine enough gradient of symptoms?*

- Yes, we need more nuanced understanding of the effects
- Celia is studying this now, recording what people say and getting them to describe it, then using artificial intelligence/ machine learning algorithms to find patterns in that
  - To see if something from the acute experience can predict the therapeutic benefits of ketamine for treating depression
- It seems like a no-brainer, but they have quite a long way to go with it, using natural language to predict outcomes

**Does ketamine produce amnesia?**

- Yes, some people get amnesia but other can remember the experience
- You might forget aspects of what’s happened, it only impairs episodic memory

**When the patient returns to their baseline state 3 hours later, do they immediately feel alleviation of depression?**

- People can feel considerably better
- Celia’s colleague, [Rupert McShane](https://www.psych.ox.ac.uk/team/rupert-mcshane) set up the first NHS treatment-resistant depression clinic in the UK
- He likened it to the film [*Awakenings*](https://en.wikipedia.org/wiki/Awakenings) (which is actually about Parkinson’s)
- These patients are severely depressed, often they can’t get off the bed, and suddenly after treatment the come alive
- Not everyone responds to it, but that is pretty rapid
- People say they feel a sense of clarity, ab it more interest in the world
  - Like they are able to detect novelty that they couldn’t before
  - It’s a great thing to see
- The response is variable, 50-60% of people don’t respond at all
  - Peter had no clue this was so high
- Early [studies](https://pubmed.ncbi.nlm.nih.gov/16894061/), [Carlos Zarate](https://www.nimh.nih.gov/research/research-conducted-at-nimh/principal-investigators/carlos-zarate) study showed 75% of patients responded, but as more studies came out, the response rate went down
  - This is typical for any new treatment as additional studies are performed
- The duration of these effects last 2 days to a week, longer for some people
- This is where Celia’s research comes in, she’s been looking at how the response might be extended

***If you give it alongside psychological therapy of some kind, you can really extend the response to ketamine and the antidepressant effects***

- Celia ran a [trial](https://pubmed.ncbi.nlm.nih.gov/35012326/) looking at using ketamine in the treatment of alcoholics
  - They found reductions in drinking 6 months after just 3 infusions
  - These infusions were spaced apart 1-2 weeks and given along with 7 sessions of psychological therapy
    - This is really a limited treatment program

***How does ketamine help people with treatment-resistant depression? [43:30]***

**Define** [**treatment-resistant depression**](https://en.wikipedia.org/wiki/Treatment-resistant_depression)

- This is tricky because different trials define it differently
- Often people define it as not responding to conventional antidepressants in the current depressive episode or having had multiple different treatments
- Some people take a more conservative definition‒ 3 failed responses

**Is depression classified as at least 2 weeks of the set of symptoms typically associated with depression?**

**Would it be classified as depression if there is an obvious externality such as loss of a child?**

*If your child dies and a month later you can’t get out of bed, is that depression?*

- No, that’s natural sadness
- If this continued for a really prolonged period of time it may be classified as depression but even then it would be contentious

***There is a clear boundary between what we would anticipate from grief and natural sadness compared to depression***

**Peter asks about this scenario‒ a person is depressed for months**

- There is not something clearly associated to trigger it, such as grief
- They have gone through one [SSRI](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor) at a therapeutic dose with no benefit
- They moved to a different SSRI or different class of drug and similarly received no benefit

*Do we assess how much psychotherapy they have been doing at the same time?*

- Celia reflects on clinical trials or reasons they give for prescribing off-label ketamine in the UK
  - Typically, it’s because the patient is not responding to antidepressants
  - It could be due to a failed response to [CBT (cognitive behavioral therapy)](https://en.wikipedia.org/wiki/Cognitive_behavioral_therapy)
  - A lot of trials use non-responders to CBT, especially for [psilocybin](https://en.wikipedia.org/wiki/Psilocybin) studies
- Peter recalls their earlier discussion, “*We’ve just said 50% of those people are not going to respond. That’s pretty sad. So what are we saying to those 50% of people?*”
- There is some evidence that depression might not respond to 3 ketamine doses, but the 4th dose or having extra doses beyond 3 may increase the response
- On-label ketamine is indicated for repeated dosing
  - This is [Spravato](https://en.wikipedia.org/wiki/Esketamine#Depression), the [Janssen](https://en.wikipedia.org/wiki/Janssen_Pharmaceuticals) version of ketamine, given intranasally
  - Doses begin twice weekly for a month then move to weekly
  - Long term studies are finding that people stay on the dose
    - There was an idea that people might progress off the drug or drop down in the dosing
    - They may have dropped down to fortnightly (2 weeks), but patients are staying on it for a number of years now as a maintenance

**Is there a plan to wean off ketamine?**

*Hypothetical patient*

- The patient has profound depression for which none of the treatments have worked
- They feel remarkably better after their first ketamine infusion
- This lasts 4 days then all of the sudden the depression sets back in
- Peter asks, “*Is the thinking that we’re going to repeat this treatment and get longer and longer periods of benefit during which time we can work more on psychotherapy to try to wean off the need for ketamine?*”

- Yes, and some people think targeting therapy during that time is really important if you don’t want to keep someone on ketamine as a maintenance dose

**Do patients need to stop their traditional antidepressants when they come to a ketamine trial?**

- In Celia’s trial in the UK, yes
  - Their funding body didn’t want them to include people on an SSRI

***But in most of the depressions studies, people are still on them and there are no interactions***

## The brain under the influence of ketamine and theoretical mechanisms for its anti-depressive effects [48:00]

**Why does ketamine help with depression? What is the proposed mechanism of action?** [48:00]

- People have talked about ketamine and the other psychedelics/ [psychoplastogens](https://en.wikipedia.org/wiki/Psychoplastogen), as provoking a kind of cascade
- There is a study showing they increase [synaptic plasticity](https://en.wikipedia.org/wiki/Synaptic_plasticity) in the [prefrontal cortex](https://en.wikipedia.org/wiki/Prefrontal_cortex)
  - Ketamine certainly does

***This increases the growth of new synapses and dendrites and basically the ability of the brain to form new connections***

- This is correlated with the antidepressant effect

- Celia is doing some work at the moment to chart the time cause of that in humans, by looking at EEG
  - This looks at electrical signals from the brain
  - She’s trying to target the window of this synaptic plasticity
  - We know from animal studies, this might start 4  hours following the ketamine dose and peak at about 24 hours
  - So they are tracking the antidepressant effects, which is quite interesting
- Celia’s view as a psychologist is, this is the time your brain is most plastic, most able to learn new things, and could be the best time for psychological therapy

**Plasticity is impaired across a whole range of psychiatric disorders**

- Not just for depression but also in alcohol, and addiction, and trauma

***So being able to stimulate the brain to learn new things while it’s really plastic and giving psychological therapy that uses that process is thought to be a key part of successful treatment***

- During psychological therapy we are asking people to think about things differently
  - To learn new ways of thinking about old problems
- This seems like an intuitively appealing mechanism
- Some may argue, “*Is this specific enough as a process? Are the drugs producing neuroplasticity that we wouldn’t say were necessarily potential treatments for mental health problems in psychiatry disorders?*”
- There are some problems with this mechanism in that neuroplasticity happens from all sorts of things
  - Such as cocaine
  - People say the neuroplasticity produced from cocaine is why it becomes addictive
  - An acute dose of cocaine stimulates that
- This is something we need to find out more about
- Maybe it’s down to something really specific and neurological
  - This is a question for the preclinical researchers
- Peter asks, “*When you about things like MDMA and psilocybin, a lot of the therapy takes place while under the influence of the drug, whether it be for PTSD or depression, is that happening also with ketamine when that patient is in the aftermath of the infusion or are they basically just left alone during that period of time and the psychotherapy takes place immediately following the next day and the next day and the next day trying to take advantage of them being less dysthymic?*”
- Celia doesn’t try to do any therapy under the influence of ketamine
  - People are too dissociated, the memory is impaired
- Some ketamine therapists do use a **psycholytic approach**
  - They use mild doses to be able to do some therapeutic process
- There is an interesting [study](https://pubmed.ncbi.nlm.nih.gov/32248200/) from a guy in Texas looking at complex PTSD and really severe multiple traumas
  - He’s treating complex regional pain syndrome on top of that
  - These are really traumatized people who have got really severe pain
  - He was giving drug continuously at quite a low dose, over 96 hours
  - And he was doing very basic psychological therapy during that time
  - He found massive reductions in CAPS score, which is a measure of PTSD symptoms
  - It was a really small study, but Celia thought that was an interesting approach

***Celia does therapy outside of the acute ketamine experience; this is true for most people and true for work with psilocybin***

- They simply support patients during the acute experience
- There is very little research on what the integration is or even then key fundamentals of integration

**What do we know about the brain under the influence of ketamine?**

*Have people done* [*fMRI*](https://en.wikipedia.org/wiki/Functional_magnetic_resonance_imaging) *or* [*FDG-PET*](https://en.wikipedia.org/wiki/Positron_emission_tomography) *and looked at either the metabolic state of the brain or the activity of the brain?*

- There’s a lot of interesting work on the [**default mode network**](https://en.wikipedia.org/wiki/Default_mode_network)
  - This is what happens in your brain when you’re not doing anything active
  - Subjects are in a scanner, they’re not doing anything‒ this is a **resting state**
- The brain is imaged in a resting state to see how networks connect
  - People say it’s the background activity of the brain and have likened it to things like rumination
  - Rumination is important in depression, repetitive thoughts about something
  - You can have positive rumination as well
  - Repetitive thinking about something bad or mind wondering occurs in depression

***The default mode network has been shown to be disrupted following psychedelics***

- This background, normal chatter of the brain

- Similar things have been shown with [mindfulness](https://en.wikipedia.org/wiki/Mindfulness)
- There are some interesting studies looking at **prediction error signalings**
  - The idea that your brain is making predictions all the time about the world and that’s how we understand everything perceptually
  - For example, if she puts her laptop screen down she expects to see the world behind it
    - But if she put her laptop screen down and found a gap in reality, she’s have a massive shock of surprise because that would be a signal to her brain to learn something new
  - So every time a prediction you make based on our learning is violated, there is a subsequent increase in learning and attention and activity in your brain
    - Ketamine disrupts this

***The lateral prefrontal cortex is associated with this prediction error processing and that is disrupted with ketamine***

> “*So things that aren’t surprising become surprising (the things that shouldn’t be surprising and are completely predictable), and things that aren’t predictable are no longer surprising*”‒ Celia Morgan

- An interesting way to think about the subjective experience is ***maybe a lot of these drugs turn off some of that forward prediction from the brain*** and make a noisier signal

**Is the brain hyper metabolic under the influence of ketamine?**

- The idea is the brain is hypo in some ways
- There is an increase in prefrontal glutamate
- Neuroimaging as it’s been done in the past is not Celia’s area of expertise

**How many patients do you think when relieved of their depression during these ketamine trips will need to stay on ketamine as a long term treatment?**

- Celia comments that one of the frustrating things about all of the ketamine clinics that have sprung up across the US is the lack of data
  - There is better data in the UK because they have a state healthcare system, the [NHS](https://en.wikipedia.org/wiki/National_Health_Service)
  - In the UK, most patients receiving ketamine for depression get it through the NHS
    - There are a couple of private clinics now giving ketamine
    - Celia is involved with one
    - There are 5 centers prescribing on the NHS, but this is all off-label because the state healthcare regulator has not recommended Spravato yet (intranasal ketamine)
    - It’s all prescribed for treatment-resistant depression
- In the UK there’s a lot of data out there they could be looking at, but they don’t have a good registry of all the patients

***As to the question, a lot of people probably respond to treatment in these clinics, but Celia’s sense is that not everyone has treatment-resistant depression***

- Particularly in the US, ketamine is given for a wide range of indications
- Celia thinks it would be amazing if we could have an international registry of data on patients using ketamine
  - This would provide information about how long people are on ketamine
  - It would potentially add a level of safety for the patients and clinicians

## Risks and concerns with overusing ketamine, and what an intermittent or maintenance dose might look for a patient [57:15]

**Concerns about use of prescription ketamine**

- Celia has seen some slightly worrying trends recently
- She helped organize a ketamine conference
  - This included colleagues from the US and some pharmaceutical companies
- They are developing ketamine for daily dosing‒ this is worrying
- She has worked with ketamine users for 10 years and even if you are using a very low dose, daily dosing will lead to an escalation of the dose

> “*So where’s the end point? If you aren’t giving it in a supportive therapy is the idea that people are just on ketamine all the time… To me, it seems a bit worrying*.” ‒ Celia Morgan

- Peter takes the skeptics point of view‒ it’s a land grab for a greater profit motive without enormous consideration for the downside
- Peter doesn’t know what it is about ketamine that makes him cautious
- Maybe it’s the anecdotes and that’s a bad frame
- He asks, “*Have you ever seen people with these sort of ketamine eyes*‒ *sunken, distant? This person has taken too much ketamine in their life and their brain doesn’t work as well anymore. I’m sure there are lots of different drugs that can produce that phenotype*.”
  - Somebody who’s taken far too much cocaine can experience something
  - He would think this is more commonly seen with ketamine than LSD or psilocybin because the frequency of use with those other drugs is much harder
  - It’s less likely that a person is going to take heroic doses of LSD or psilocybin over and over again
  - Whereas you can get down that path with ketamine
- There are areas of concern with ketamine beyond its toxicity to the bladder
  - Cystitis is a very obvious and tangible objective side effect that can be devastating
- There can be more subtle changes in a person’s brain that are not for the better
- Peter asks, “*Am I just sort of making this up and it’s possible I am and that I’m just over extrapolating from something else, but you’ve been around this more than almost anyone. Do you have a concern around that?*”
- Celia has done a lot of studies on this
- She hasn’t studied the sunken eyes, but she has looked at the brain
  - Peter has not noticed physically sunken eyes, like you would for hypothyroidism, it’s more of a vacancy
  - Celia adds, “*A kind of dullness*”
- Like any addiction, one thing she has noticed anecdotally with addiction is people lose their sense of humor

> “*The spark has gone out of life*”‒ Celia Morgan

- This is an odd vibe considering ketamine is given to treat depression, to put the spark back
- But then it makes sense, you do it too much and maybe that spark is gone
- She has found **cognitive changes**
  - cognitive impairments and with planning
  - Actual reductions in the hippocampus, which is involved in processing novelty and encoding memories
  - That function is reduced in some of their brain imaging studies with people who take daily heavy doses of ketamine
- She’s not saying your non-medical recreational user would show this kind of symptoms, people who take it occasionally
- But she thinks it’s possible for people who take really, really heavy doses

**Ketamine prescribing practices for treating depression**

- Ketamine is administered in clinics as a rapid acting antidepressant
- The promise of it was it’s not a maintenance medication
  - It would be empowering for patients to not be on a daily medication
- This is why Celia feels a little sad that there’s not more research effort aimed at understanding the potential of ketamine to enhance therapy for depression
  - Do we have to give people hundreds of doses?
  - Maybe just some people need that
- Maybe that’s a cost-benefit analysis made when prescribing any drug to patients who are heavily suicidal
  - This depression is life threatening, right?

**Has anyone done a** [**quality-adjusted life year**](https://en.wikipedia.org/wiki/Quality-adjusted_life_year) **analysis of patients with the most treatment-resistant depression?  Have differences in suicide rate been reported?**

- People have worked with suicidal patients and you get reduced mortality with ketamine
  - These are tough studies

**What does your intuition say is probably the sweet spot for what the intermittent/ transient but fixed use of ketamine is, as a bridge to go from completely treatment resistant depression to treatable depression?**

- Celia’s [clinical trial on alcohol dependence](https://pubmed.ncbi.nlm.nih.gov/35012326/) used 3 doses of ketamine and 7 sessions of psychotherapy
  - 0.8 mg/kg ketamine was given over 40 minutes
  - This is a slightly higher dose than used for depression because you get a sort of cross-tolerance with alcohol
    - Because alcohol works on the same receptor as ketamine at higher doses
    - When people get really intoxicated and feel like they’re spinning out, that’s the alcohol working on their NMDA receptors
  - Doses were separated by 7 days to 2 weeks
- People with alcohol problems tend to have depression as well and it can be quite severely treatment-resistant
- *Her study found a reduction in rumination‒*  repetitive, negative thinking
- *Reduction in* [*anhedonia*](https://en.wikipedia.org/wiki/Anhedonia) which is a hallmark of depression and many disorders
  - That’s the inability to experience pleasure in the world
  - She saw reductions in anhedonia at 3 months but they were back to baseline at 6 months
- Subjects were still showing *reduced drinking at 6 months*

***This might suggest in depression that weekly or fortnightly (bi-weekly) dosing might be needed***

**Pros and cons of different maintenance doses of ketamine**

- Peter thinks this model of treating once a quarter (every 3 months) makes more sense
- What worries him is he is seeing people taking ketamine twice weekly for life
  - He worries about the toxicity of the drug
  - It would need to show enormous efficacy to justify this dosing schedule
- When he looks at short-term studies comparing ketamine to [Versed](https://en.wikipedia.org/wiki/Midazolam), ketamine is not that much better
  - Versed is a good option
  - Using Versed as a control shows there is a pretty big placebo effect
- Celia agrees

## Treating addiction with ketamine: Celia’s studies of alcohol dependance [1:04:00]

**Why is ketamine working to treat addiction?**

- Celia is studying alcohol dependence but wants to look at opioid addiction as well
- There is work in the US looking at opioid addiction
- This dates back to the Russian Psychiatrist Jenny Kopitski
  - She worked with heroin addicts and found a similar dosing regime of 3 infusions combined with psychological therapy
    - They used higher doses of ketamine (1-2 mg/kg) administered intramuscularly
  - This produced significant reduction in heroin use at 12 months

**How much of a reduction is seen?**

- For alcohol there was a 40% reduction in relapse rate at 12 months
- These studies were done in the 80s in Russia
  - They were on inpatient alcoholics in locked wards, they couldn’t drop out
  - It wasn’t the normal consent and ethics processes we have now, but still a really important study
  - Both groups had a hundred people in them but it wasn’t a randomized control trial
    - They simply asked people if they wanted to be in the group receiving ketamine and psychotherapy or in the group with standard therapy
    - Celia comments, “*This is dodgy*”
  - They don’t have any access to alcohol
  - They detok, get ketamine treatment, and are then discharged
    - Follow-up occurs 12 months later

**Has a head-to-head study of ketamine + behavioral therapy versus pharmacologic + behavioral therapy for alcohol been done?**

- No

**Celia’s latest** [**clinical trial**](https://pubmed.ncbi.nlm.nih.gov/35012326/) **was a 4-arm trial**

- 1 – Ketamine + psychological therapy
- 2 – Saline placebo + psychological therapy
- 3 – Ketamine + alcohol education
- 4 – Saline placebo + alcohol education

> “*It was great because that’s what we hypothesized (and that’s quite rare), but I wasn’t expecting to get what we hoped for*”‒ Celia Morgan

***They saw the greatest reductions in drinking and greatest abstinence in group #1 (ketamine + therapy) where at 6 months the abstinent rate was 86%***

- The figure below shows the most recent published data from this randomized clinical trial

![](https://peterattiamd.com/wp-content/uploads/2022/08/f4-celiamorgan-1024x766.png)

**Figure 4.  Percentage of days of alcohol abstinence across the four treatment conditions.**  Image credit: [*The American Journal of Psychiatry* 2022](https://pubmed.ncbi.nlm.nih.gov/35012326/)

- The second best effect was in group #3 (ketamine + education control, shown in green in the figure above)
  - They wanted to look at the effects of ketamine without therapy, but there are really nonspecific effects of spending hours with a therapist who’s quite nice
- Peter notes, “*That’s a very elegant trial design because you get away from what’s called the* ***performance bias of the therapy****, the therapy itself. You have to make sure you’re controlling for just the fact that an hour, three times a week, they have to go talk to somebody*.”

**What was done in the education arm of the trial?**

- People learned how alcohol affects the body
- They did some relaxation, just as a bare minimum of what they wanted to do with people going into a ketamine session
  - Maybe the relaxation helped with the blinding
- The placebo was just saline
  - There were no dissociative effects, which is a bit of a shame in retrospect
  - Celia notes, “*We should have used something like* [*midazolam*” (brand name Versed)](https://en.wikipedia.org/wiki/Midazolam)
- The response in the other groups was good as well
- There were 96 patients
  - 24 patients per arm
  - They weren’t powered for the full interaction
- They are moving forward now with a phase II trial of 280 patients funded by the UK state
  - This is run in a NHS setting
  - Celia hopes to see ketamine as a medicine in those contexts
- Celia comments, “*I don’t know what you think of the psychedelics world and I think some of the therapies are amazing, but for our state healthcare system, those things are not ever going to happen. You’re never going to have 2 therapists for 40 hours*.”
- She wanted to come up with a therapy that was deliverable in her state healthcare system
- They have a lot of slightly lower-level trained therapists in the NHS
- So they designed their therapy to be quite manualized so they could deliver it in a short amount of time

**How much therapy were they getting in the active therapy group?**

- A total of about 11 hours in 6 months
- So they have a therapy session immediately before their infusion
- If they’re in a therapy group they would be doing a mindfulness practice
- In the education group: there’s some relaxation, then they have the ketamine session, then they recover as you would from an anesthetic, and then they go home
- They come back the next day and have another longer therapy session of 1.5 hours
  - This where we think the peak of the synaptic plasticity effects occur

***So it’s a ketamine infusion sandwich between 2 therapy sessions, and they repeat that three times***

**What is the therapist talking about?**

- Some of it’s very pragmatic things
  - What are your most risky situations for drinking, trying to preempt situations where they might relapse
  - But some of it’s more about how you want to live your life and the values you want to embody
  - Trying to think about your life without alcohol, how would you structure that
  - Things about thinking about your thinking around drinking, which is more cognitive behavioral therapy based
    - What are your thinking biases? Let’s identify those
    - And then planning
- So they have quite a lot of activities to do in the week or weeks in between the sessions, like standard homework
  - Planning their days, journaling, keeping track of those things
- They teach mindfulness techniques to enable people to deal with cravings
  - To get a bit more of a space between them and their addictive impulses
- There’s a whole range of stuff really

> “*We threw the book of the evidence-based therapies at them*”‒ Celia Morgan

**Explain the inclusion criteria**

- Subjects go through a number of screenings to get into the clinical trial
- One problem with clinical trials is they end up with quite pure populations
- They needed people to be abstinent when they started
  - A lot of people who are drinking can’t stop straight away
  - They needed to go through a medical detox and most of those are in the community now
- They worked with people’s healthcare providers to support them as they went through detox
  - And they kept checking in with them until they were ready to start, maybe 2 weeks after they’ve done a full detox
- They didn’t include people with
  - Psychosis
  - Psychosis in a first degree relative
  - Uncontrolled blood pressure because ketamine is associated with increased blood pressure
  - A variety of other things excluded people from the study
- They had access to the medical notes for subjects of the study
- It’s quite a process, but the main bit is getting people abstinent

***The therapy is all around supporting people with their new life and using the ketamine experience really to get that perspective***

- This is a perspective they might not have had for a while
  - A new perspective to think about their life in a new way and try and focus on how they want to go forward
- It’s really using the **ketamine as a catalyst for their therapy** rather than purely focusing on the pharmacological properties of it

**How much does blood pressure go up when administering 0.8 mg/kg ketamine?**

- It varies
- On the order of 10
- Celia is a psychologist, they had an anesthesiologist there for the whole thing
- They had to stop the infusion for 1 patient because it went over 180

**What the response rate was in the double negative group (#4)?**

- It was still high, about 68%

*What does she attribute this to?  There’s a 20% difference between the 2 extremes (groups #1 and #4)*

- She thinks it was pretty extraordinary for any clinical trial
- You often see people do better in clinical trials
  - They’ve going through this whole process with a really strong intention to stop
  - They’ve been through quite a lot of hurdles
  - The trial was pretty demanding if you stuck with it
- Some things she didn’t mention, subjects wore a [SACM (sweat alcohol content monitor)](https://en.wikipedia.org/wiki/Electronic_tagging#Sweat_alcohol_content_monitor)‒  a tag that you put around your ankle that measures your alcohol transdermally
  - Because you’re excrete about 1% of alcohol in sweat
  - This measurement may have actually acted as an intervention on its own
  - Now they use a much more discreet wearable, but then it was a clunky thing
- Many of these people don’t have a lot of social connections
  - Some of them did
  - But the fact of having people looking after them, checking in on them all the time, people just showing you general human kindness, can have a really positive effect in a group that might be quite isolated

**What can we learn from this about the big picture?**

- Alcohol services here in the UK are just so dysfunctional at the moment
- By the time people get any sort of treatment they have multiple complex health problems
  - Or they’ve been through multiple treatments that haven’t worked
  - It’s really hard toa access therapists

> “*It’s really sad. It doesn’t actually take that much to shift something that’s pretty entrenched*”‒ Celia Morgan

- Peter wonders about the response rate of less motivated cohorts down the line
  - Some individuals are less interested in not drinking
  - Someone who maybe hasn’t fully hit rock bottom but acknowledges they drink too much may say “*I’m going to keep drinking… I haven’t destroyed my life yet*”
- Peter comments, “*I just sort of wonder if you have these places for earlier intervention, as someone is on the path towards really destructive alcoholism*”

**Further study of ketamine [1:17:30]**

*Celia’s phase III trial (in progress)*

- It’s funded by the NHS Department for Health
- They are taking the 2 most extreme arms
  - In an ideal world of infinite resources she would have continued to study the 4 arms because she really likes that design
  - She also thinks that is something that is missing from the psychedelics world, teasing apart the impact of the therapy and the drug
- They have a patient advocacy group involved at the start that provides some of the risks of ketamine
  - They wouldn’t want to give it without a therapeutic container
- Having found these promising effects for the efficacy study (which was more of a definitive study), they decided to just take the most extreme arms
- They are looking just with the therapy and then the various other more discrete variables compared to our placebo that we’re using
  - They’re using the same education protocol
  - The high dose will be 0.8 mg/kg
  - The low dose will be 0.05 mg/kg, they’re still working out the dose with pilot trials
- Studies with morphine and childhood trauma, looking at how childhood trauma seems to synthesize the brain to respond to opiates found that using a very low dose of morphine was a better control than another drug

***Celia thinks a very low dose is helpful in expectancy, you get to tell people they will receive the drug no matter what***

- Patients will receive either the high or low dose of ketamine

## Advice for people considering the therapeutic use of ketamine [1:19:45]

**What cautions would Celia tell people here in the US where ketamine clinics are ubiquitous?**

- Peter thinks anyone can get treatment, they don’t need a referral
- He suspects there’s a really good conduit of therapists sending patients appropriately to good ketamine clinics

*Hypothetically, let’s say anybody can walk into a ketamine clinic, explain their issue, and get treatment*

- Peter asks, “*How would you caution people around ketamine use, liberally in that context?*”

***The evidence Celia has gathered suggests trying ketamine embedded within therapy***

- [Sam Wilkinson](https://medicine.yale.edu/profile/samuel_wilkinson/?tab=bio) at Yale has also looked at therapy + ketamine in a small [RCT](https://pubmed.ncbi.nlm.nih.gov/34186531/)
- She doesn’t think you need all those doses
- People should think about what they are trying to get out of the experience
- It’s great to hear therapists are referring people to ketamine clinics
- Using ketamine in combination with therapy is a much more appealing model
- She doesn’t think people want to be stuck on a drug
  - Even if you’re not addicted, but you’re going in twice a week or even once a week
  - That’s so disempowering for patients
- Celia’s patients say one of the things about her treatment approach that is great is not being on daily meds
  - They feel liberated and they know they’re doing the healing themselves
    - Which Celia thinks is an important part of the process

> “*Get a therapist to think about using a really minimal number of doses*”‒ Celia Morgan

**Celia recommends caution**

- One worrying practice she has heard about is mail order ketamine clinics
  - She’s not worried from the abuse side
  - It’s just so expensive

***It’s unsafe to take ketamine at home unsupervised***

- The drug makes you completely dissociated from your environment
- If something happens (a fire), you can’t take it unsupervised

- The lack of clinical care and supervision in some of these models is really worrying

**Advice for people using ketamine recreationally**

- Start with really small doses
- Take it in a safe place with someone who’s not under the influence of any substances
- Be careful of getting ketamine cut with other things
  - Such as ketamine analogs
  - The drug [methoxetamine](https://en.wikipedia.org/wiki/Methoxetamine) is a research chemical that has come out of labs in China and Israel
    - It’s an analog of ketamine but much more toxic to the bladder
    - It may have a higher abuse potential

***Celia doesn’t think ketamine is normally cut with things, but it’s something to be mindful of and why it’s really important to take a small dose***

- This discussion has been really useful for Peter since ketamine has been a bit of a black box, yet he’s seen the most people use it because it’s legal

§

## Selected Links / Related Material

**Addiction to ketamine and other phenomenology**: [Journey through the K-hole: phenomenological aspects of ketamine use](https://pubmed.ncbi.nlm.nih.gov/18355990/) | *Drug and Alcohol Dependance* (L Muetzelfeldt *et al.* 2008) | [20:45]

**Autobiography of John Lilly, a great account of ketamine addiction**: [The Scientist: A Metaphysical Autobiography](https://www.amazon.com/Scientist-Metaphysical-Autobiography-John-Lilly/dp/0914171720/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1656516022&sr=8-1) by John Lilly (1978) | [25:45]

**Another account of experiences using ketamine** : [Journeys to the Brighty World](https://www.amazon.com/Journeys-bright-world-Marcia-Moore/dp/0914918125/ref=sr_1_fkmr0_1?crid=JGAPT2VYJHTU&keywords=journeys+to+the+bright+world+by+marcia+moore&qid=1656516338&sprefix=journeys+to+the+brighty+world+by+marcia+moore%2Caps%2C121&sr=8-1-fkmr0) by Marcia Moore and Howard Alltounian (1978) | [26:30]

**Celia’s systematic review of the predictive value of acute psychoactive effects of ketamine for treating depression**: [Ketamine as a mental health treatment: Are acute psychoactive effects associated with outcomes? A systematic review](https://pubmed.ncbi.nlm.nih.gov/32485203/) | *Behavioral Brain Research* (M Grabski *et al.* 2020) | [39:00]

**Celia’s clinical trials combining ketamine with psychotherapy to treat alcohol dependance**:

- [A proof-of-concept investigation into ketamine as a pharmacological treatment for alcohol dependence: study protocol for a randomised controlled trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5379743/) | *Trials* (A McAndrew *et al.* 2017) | [43:15, 1:02:00]
- [Adjunctive Ketamine With Relapse Prevention-Based Psychological Therapy in the Treatment of Alcohol Use Disorder](https://pubmed.ncbi.nlm.nih.gov/35012326/) | *The American Journal of Psychiatry* (M Grabski *et al.* 2022) | [43:15, 1:02:00]

**Small study treating pain plus PTSD with Ketamine**: [Continuous Ketamine Infusion for Pain as an Opportunity for Psychotherapy for PTSD: A Case Series of Ketamine-Enhanced Psychotherapy for PTSD and Pain (KEP-P2)](https://pubmed.ncbi.nlm.nih.gov/32248200/) | *Psychotherapy and Psychosomatics* (BM Keizer *et al.* 2020) | [51:15]

**Sam Wilkinson’s study study of the effects  ketamine plus therapy for patients with treatment-resistant depression**: [Cognitive Behavioral Therapy to Sustain the Antidepressant Effects of Ketamine in Treatment-Resistant Depression: A Randomized Clinical Trial](https://pubmed.ncbi.nlm.nih.gov/34186531/) | *Psychotherapy and Psychosomatics* (ST Wilkinson 2021) | [1:20:45]

**Celia’s review of the mechanism of action of ketamine**: [Ketamine for the treatment of addiction: Evidence and potential mechanisms](https://pubmed.ncbi.nlm.nih.gov/29339294/) | *Neuropharmacology* (I Ezquerra-Romano *et al.* 2018)

**Antidepressant mechanism of action by ketamine**: [Mechanisms of Ketamine Action as an Antidepressant](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5999402/) | *Molecular Psychiatry* (P Zanos and TD Gould 2018)

**Cognitive and psychological characterization of frequent ketamine use**: [Ketamine use, cognition and psychological wellbeing: a comparison of frequent, infrequent and ex-users with polydrug and non-using controls](https://pubmed.ncbi.nlm.nih.gov/19133891/) | *Addiction* (CJ Morgan *et al.* 2009)

§

## People Mentioned

- [Edward Domino](https://www.nature.com/articles/s41386-022-01280-x) (Neuropharmacologist who coined  the term dissociative anesthesia) [7:45]
- [Vladimir Putin](https://en.wikipedia.org/wiki/Vladimir_Putin) (President of Russia) [18:30]
- [Brigitte Bardot](https://en.wikipedia.org/wiki/Brigitte_Bardot) (French actress, singer, and model) [18:30]
- [John Lilly](https://en.wikipedia.org/wiki/John_C._Lilly) (Neuroscientist and psychonaut who inspired the film [*Altered States*](https://en.wikipedia.org/wiki/Altered_States)) [25:30]
- [Marcia Moore](https://en.wikipedia.org/wiki/Marcia_Moore) (experimented with ketamine, author of [*Journeys to the Brighty World*](https://www.amazon.com/Journeys-bright-world-Marcia-Moore/dp/0914918125/ref=sr_1_fkmr0_1?crid=JGAPT2VYJHTU&keywords=journeys+to+the+bright+world+by+marcia+moore&qid=1656516338&sprefix=journeys+to+the+brighty+world+by+marcia+moore%2Caps%2C121&sr=8-1-fkmr0) ) [26:30]
- [Salvador Roquet](https://chacruna.net/salvador-roquet-remembered/) (Mexican pioneer in psychedelic psychotherapy) [32:15]
- [Robert Berman](https://www.crunchbase.com/person/rob-berman) (former Professor of Psychiatry at Yale University, now working in biotech) [33;15]
- [Rupert McShane](https://www.psych.ox.ac.uk/team/rupert-mcshane) (Professor of Psychiatry and Neuroscience at the University of Oxford) [41:30]
- [Carlos Zarate](https://www.nimh.nih.gov/research/research-conducted-at-nimh/principal-investigators/carlos-zarate) (Section Chief of Neurobiology and Treatment of Mood Disorders and Chief of Experimental Therapeutics and Pathophysiology Branch (ETPB) at NIMH, and Clinical Professor of Psychiatry and Behavioral Sciences, at The George Washington University) [42:30]
- Jenny Kopitski (Russian Psychiatrist worked with heroin addicts) [1:04:30]
- [Samuel (Sam) Wilkinson](https://medicine.yale.edu/profile/samuel_wilkinson/?tab=bio) (Assistant Professor of Psychiatry and Associate Director, Yale Depression Research Program) [1:20:45]

§

![](https://peterattiamd.com/wp-content/uploads/2022/08/Celia_Morgan.jpeg)

##### Celia Morgan, Ph.D.

Celia Morgan completed her undergraduate degree and Ph.D at the University College London (UCL).  She then spent time at Yale University on a scholarship program before returning to UCL for postdoctoral research.  Following this she worked at University of Melbourne as a visiting research fellow; then she returned to UCL for a fellowship and then Lectureship.  She joined University of Exeter as a Senior Lecturer in May 2013 and was given a Chair in Psychopharmacology in 2015.  She co-directs the [Beckley/Exeter Cannabis Centre](https://www.beckleyfoundation.org/science/collaborations/dr-celia-morgan-exeter-university-uk/) at the University of Exeter.  She is also the Head of Ketamine Assisted Psychotherapy for Addiction at [Awakn Life Sciences Corp](https://awaknlifesciences.com/celia-morgan).  Additionally, she currently holds an Honorary Readership at UCL.

Dr. Morgan is interested in the effects of drugs and alcohol on the brain and behavior.  Her research examines both the benefits and side effects of recreational drugs on cognition, mental health, and neurobiology.  Through behavioral, neuroimaging studies, and clinical trials, she has investigated potential therapeutic uses of controlled substances.  She uses a range of techniques from experience sampling and qualitative interviews to cognitive testing and functional and structural neuroimaging of the DTI and VBM.  In particular, she has investigated treatment of addiction with a combination of psychological therapy and drugs such as ketamine and MDMA.  [[University of Exeter](https://psychology.exeter.ac.uk/staff/profile/index.php?web_id=Celia_Morgan)]