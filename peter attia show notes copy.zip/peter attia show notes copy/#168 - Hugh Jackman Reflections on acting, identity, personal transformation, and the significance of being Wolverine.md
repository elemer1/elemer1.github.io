# #168 – Hugh Jackman: Reflections on acting, identity, personal transformation, and the significance of being Wolverine

**Source:** [https://peterattiamd.com/hughjackman/](https://peterattiamd.com/hughjackman/)

---

Hugh Jackman is an award-winning actor and an overall fascinating and introspective individual. In this episode, Hugh reflects upon his acting career, including how he navigated many tough decisions that led to important professional turning points for him. Peter and Hugh have an intimate discussion related to handling professional criticism, self-identity, spirituality, raising kids, and the role that past trauma often plays in extremely driven individuals. Hugh gives the inside scoop on some of his most well-known character roles and explains how he finds the energy to consistently perform. Finally, they tie the conversation together with a discussion on the importance of physical and mental health and wellbeing.

\*[WATCH PODCAST ON YOUTUBE](https://youtu.be/Go4PYU3hJrc)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/hughjackman/the_Drive_public.png)

Play

#168 - Hugh Jackman: Reflections on acting, identity, personal transformation, and the significance of being Wolverine

#168 - Hugh Jackman: Reflections on acting, identity, personal transformation, and the significance of being Wolverine

1x15s30s

0:002:09:56

## We discuss:

- Hugh’s voracious curiosity and early years of his acting career [2:15];
- Self-identity, overworking, and the importance of living well [9:15];
- Handling criticism and letting go of the desire to please everyone [18:30];
- Dismissing vitriol on social media, and the challenge of communicating science [28:15];
- Going with your gut and the value in finding the right partner [31:30];
- A hard decision that lead to a turning point a turning point in Hugh’s life [40:15];
- How driven personalities often develop from a place of trauma, and how to avoid going from productive to destructive [47:00];
- The effect of fame on Hugh’s family [58:45];
- How Hugh finds the energy to consistently perform, and the spiritual connection he feels when acting [1:07:15];
- Hugh’s experiences on the set of The Fountain and the meaning behind the film [1:26:30];
- The potential of imagination, the idea of a higher power, and thoughts on science vs. religion [1:33:45];
- The deep connection Hugh felt to Logan (his character in Wolverine) [1:41:45];
- Reflections on physical aging, emotional wellbeing, and longevity [1:55:15]; and
- More

§

## Show Notes

## Hugh’s voracious curiosity and early years of his acting career [2:15]

- Hugh is sorry they couldn’t meet in person because they enjoy meals at each other’s houses (2:17)
- In a slightly different format, Peter and Hugh will have a discussion, not an interview, because Hugh is the “most curious person” he knows because he is “just immediately obsessed with and interested in every detail of what another person knows and how they’ve come to know it”
- Hugh says he always asks question in interviews because he gets bored talking about himself (3:57)

> “If you think about my job, my job is human nature. If you’re an actor and you’re not curious about people, it’s going to be a real struggle” —Hugh Jackman

Peter’s daughter Olivia asked him to ask Hugh when he knew he was good enough to make it in his chosen profession

- Hugh says it was when he was 28 and got a job at the [Royal National Theater](https://en.wikipedia.org/wiki/Royal_National_Theatre) in London
- The stats at Hugh’s school in Australia were that about 5% can make a living from acting
- [Sir Trevor Nunn](https://en.wikipedia.org/wiki/Trevor_Nunn) is one of the great theater directors of all time, and Hugh admired his work with the [Royal Shakespeare Company](https://en.wikipedia.org/wiki/Royal_Shakespeare_Company) and in [*Les Misérables*](https://en.wikipedia.org/wiki/Les_Mis%C3%A9rables_(musical)), [*Nicholas Nickleby*](https://en.wikipedia.org/wiki/The_Life_and_Adventures_of_Nicholas_Nickleby_(play)), and other shows
  - When Nunn came to Australia doing [*Sunset Boulevard*](https://en.wikipedia.org/wiki/Sunset_Boulevard_(musical)), Hugh asked to audition with Nunn even though he didn’t want to be in a musical “because I was getting pigeonholed into that world”
  - Ended up deciding to do whatever would allow him to work with Nunn, and Nunn took him to London to be in [*Oklahoma!*](https://en.wikipedia.org/wiki/Oklahoma!)
  - Hugh is grateful that Nunn gave him the confidence to know he could work internationally
- Peter says it’s similar to athletes who “show these glimmers of greatness early on, but you’re still constantly evolving in the craft” (6:54)
  - Early on, no one could have predicted what [Tom Brady](https://en.wikipedia.org/wiki/Tom_Brady) could do
  - Brady got his chance when [Drew Bledsoe](https://en.wikipedia.org/wiki/Drew_Bledsoe) was injured in the 2001 season, and he was able to perform due to all his preparation
- Hugh did not feel that he just needed an opportunity to unleash his potential
  - it felt more incremental to him
  - He lacked the brazen confidence of an athlete who asks the coach for the ball, but he had the courage to try (7:46)
  - It wasn’t really courage or confidence, but rather wanting to make sure that he didn’t “miss an opportunity to try and to grow”
- Even though he was amazed that he was working with Nunn, who had worked with the greats like [Judy Dench](https://en.wikipedia.org/wiki/Judi_Dench), [Patrick Stewart](https://en.wikipedia.org/wiki/Patrick_Stewart), and [Ian McKellen](https://en.wikipedia.org/wiki/Ian_McKellen), his repartee with Nunn made him feel like he was in the right place

## Self-identity, overworking, and the importance of living well [9:15]

- Hugh says that Peter is “obviously one of the most successful doctors in the world” and wonders when he realized the he could take care of “some of the most demanding high achieving people on the planet”
  - Peter says he hasn’t reached a point where he feels like he can do everything (9:46)

> “I think there’s a constant sense of, am I doing enough? Am I learning enough? What am I missing? What am I forgetting? What could I be doing better? How can we make this process better?” – Peter Attia

- But about a year ago he finally stopped feeling like an impostor who was nowhere near as good as others thought
- Therapy helped Peter recognizing how much of his identity was tied to what he did rather than who he was (10:44)
- Kids are a good reminder of Peter’s mission statement in life to make his eulogy better than his resume (11:13)

- Hugh asks himself what he wants to achieve and how he can achieve it with less because he tends to overwork himself (12:25)

> “We probably did work harder than other people. We never stopped. But it’s clearly not actually not a disciplined recipe for wellness or happiness or being a good husband or a good father” – Hugh Jackman

- Peter discussed this extensively with [Ester Perel](https://www.estherperel.com/) for a podcast that will be released later this summer (13:16)
  - About a year ago he wrote a “recovery contract”

> “If you start to prioritize your eulogy over your resume, you will make deliberate trade offs that may sacrifice your performance in the short run and you have to be able to accept that” – Peter Attia

- it is okay to say goodbye to an opportunity today in exchange for something that you value more in the long run
- Peter thinks journaling helps his mental health (14:40)
- [Dialectical behavioral therapy](https://en.wikipedia.org/wiki/Dialectical_behavior_therapy) can also help change behaviors

- One of the chapters in Peter’s upcoming book was extracted from his journals
  - He thinks keeping a journal is a good, private way to process info
  - Hugh was very moved when he read that chapter and could tell it was the result of “years of synthesizing everything” (16:15)
    - Hugh thought it should be the first chapter instead of chapter 15 (16:39)
    - Was useful to hear where Peter had failed and what he’s learned
  - Hugh thinks reading that chapter will help readers be enthusiastic about the rest and that they’ll get a lot out of reading that chapter if it’s the only they read
  - Peter says his editor needs him to cut a third of the book but he won’t take that chapter out (17:38)
  - In some ways he is afraid to put it out there because it’s about all his mistakes

> “Living long without living well, in terms of mental health, it’s a form of torture in a way” – Peter Attia

## Handling criticism and letting go of the desire to please everyone [18:30]

- Hugh says in acting, he is open to criticism every time he performs
  - But his fellow actors aren’t publicly doing it, whereas for doctors and academics, there’s a lot of internal pressure from your colleagues
  - Peter thinks Hugh has it worse because he’s on a much bigger stage
- The performances Hugh is most proud of are elements of [*The Fountain*](https://en.wikipedia.org/wiki/The_Fountain); [*Les Miz*](https://en.wikipedia.org/wiki/Les_Mis%C3%A9rables_(2012_film)); [*Logan*](https://en.wikipedia.org/wiki/Logan_(film)); [*The Greatest Showman*](https://en.wikipedia.org/wiki/The_Greatest_Showman); moments in [*The Prisoners*](https://en.wikipedia.org/wiki/The_Prisoners_(play)) and [*The Prestige*](https://en.wikipedia.org/wiki/The_Prestige_(film)); his first movie, [*Erskineville Kings*](https://en.wikipedia.org/wiki/Erskineville_Kings); and a lot of  [*The Front Runner*](https://en.wikipedia.org/wiki/The_Front_Runner_(film)) (19:35)
  - It’s usually moments that he’s proud of
  - he always comes away from a movie feeling some personal criticism
- Peter thinks about professions where criticism is part of the job: actors, athletes, politicians
  - “If you’re a politician, a 60% approval rating means you’re exceptional. And that means 40% of people can’t stand you” (20:26)
  - Peter mentions the [Q score](https://en.wikipedia.org/wiki/Q_Score), a measure of popularity and likeability
  - Hugh’s is 99%, while the next highest in Australia is something like 67%
  - A friend of Hugh’s who runs [Foxtel](https://en.wikipedia.org/wiki/Foxtel), a cable network in Australia, told Hugh he knew he would focus on the 1% who don’t like him
- Despite playing a politician ([Gary Hart](https://en.wikipedia.org/wiki/Gary_Hart)) in *The Front Runner*, Hugh has no desire to go into politics
- When Hugh chose acting, his father said he had talent was too thin-skinned for that profession (22:31)

> “Once I start reading [reviews], particularly when you’re doing stage, it gets into your head and actually a compliment is sometimes worse than a negative. A negative can fire you up. … But a positive, it can kill you” – Hugh Jackman

- There’s a difference between reviews for films and for the stage where he’s still performing
  - He does not look at stage reviews
  - When he did [*The Boy from Oz*](https://en.wikipedia.org/wiki/The_Boy_from_Oz) back in 2003, he really felt they were connecting with the audiences, but they did not get a *New York Times* review
  - The show ended up being a hit
  - He says the actors know more than anyone else when it’s landing
- Film is different because you do not know how the audience will react
  - He will sometimes read good film reviews to see what they liked
  - but he’s always been scared that someone will think he’s no good and ask why he’s allowed to act
- Hugh and his wife, the actress [Deborra-Lee Furness](https://en.wikipedia.org/wiki/Deborra-Lee_Furness), will sometimes read each other’s reviews and let each other know if there’s something they should read (26:01)
- But Deb once told him to read a [NYT review](https://www.nytimes.com/2011/11/11/theater/reviews/hugh-jackman-back-on-broadway-at-broadhurst-review.html) for [*Hugh Jackman: Back on Broadway*](https://en.wikipedia.org/wiki/Hugh_Jackman:_Back_on_Broadway), and Hugh was fixated on the line “all he asks is that you love him loving you loving him”
  - It made him really evaluate himself and ask how much he was manipulating the audience to show them the version of himself he wanted them to see
- He thinks he’s more authentic now than 10 years ago
- Deb is “like a lioness” about critics who give Hugh bad reviews

## Dismissing vitriol on social media, and the challenge of communicating science [28:15]

- Peter gets attacked primarily on social media, most recently about podcasts on the COVID vaccines (28:16)
  - Instead of questioning his take on the science, people accuse him of being owned by Big Pharma, call him an idiot, and even compare him to [Hitler](https://en.wikipedia.org/wiki/Adolf_Hitler)
    - Peter’s wife Jill wonders why he would be on social media when it gives people an opportunity to attack him like this
    - Peter rarely reads and even more rarely responds to social media criticism
    - On the rare occasions when he responds, “I’m 0 for 20 on ever changing anybody’s mind who’s in that stage” (29:30)
  - [Joe Rogan](https://en.wikipedia.org/wiki/Joe_Rogan) told Peter to “post and ghost” – put up the information and then never read the comments
  - Peter is not phased by ridiculous comments
  - But he is bothered by how people end up suffering because of their warped views about science

> “Science is a hard topic and I think scientists have not always done a good job explaining it. And I think that people do sometimes pay a price for this” – Peter Attia

- Peter feels bad for parents of kids with autism who think vaccines harmed their child even though “there’s not a shred of evidence” to support that idea
  - He thinks it could offer some hope for them to understand that they did not do this to their child
- Hugh thinks people seek confidence in a doctor and it helps to humanize them, as Peter’s book chapter does (31:32)

## Going with your gut and the value in finding the right partner [31:30]

- Hugh wonders if Peter has ever gone with his gut instead of the data
  - Peter says when he was dating Jill during his residency, he was “so maniacally driven” that he has no idea how she put up with it (33:00)
    - After working up to 120 hours a week, he would also prioritize exercise, reading a certain number of pages a day in surgical textbooks, and practicing sewing [anastomoses](https://en.wikipedia.org/wiki/Anastomosis) every night on models he had built
    - Jill was afraid he would always put his work before her
  - They had both second thoughts the week before their wedding about whether Peter was the kind of man who would ever want to be married (34:52)
    - Peter initiated the conversation; he knew surgeons had high divorce rates
    - But Peter had a gut feeling that overrode his concerns
    - “And by the end of that day, I decided that no, there’s something here that I don’t yet understand”
    - It turned out to be the most important decision Peter ever made, because he wouldn’t be doing what he is doing without having Jill as the base of his support
  - No amount of am data would have shown Peter how much Jill was the right person for him

**How Hugh met his wife Deb**

- Hugh met his wife [Deb](https://en.wikipedia.org/wiki/Deborra-Lee_Furness) on a TV series (36:31)
  - She was the star and it was Hugh’s first job
  - It was considered a bad idea to date your co-star, especially when the series was about sexual tension between their characters
- At a restaurant dinner with lots of people, Hugh saw that Deb and the person she was talking to were the only ones not listening to a story or joke he was telling
  - Deb had determined not to date any more actors, especially ones under 30 as Hugh was at the time
  - He told her he knew she was scared but he was confident they’d be together the rest of their lives
  - It was a rare moment of clarity and relief for Hugh, who tends to be very indecisive
- They have now been together for 25 years and their relationship is “one of the greatest blessings in my life”

## A hard decision that lead to a turning point a turning point in Hugh’s life [40:15]

- When Peter was growing up, a Canadian channel called [The Sports Network (TSN)](https://en.wikipedia.org/wiki/The_Sports_Network) had a feature called the “[TSN turning point](https://www.urbandictionary.com/define.php?term=The%20TSN%20Turning%20Point)” showing a play that completely changed a game (40:20)
- Hugh’s father was converted by Billy Graham and he grew up in a religious household (41:06)
  - He wanted God to show him the right life path
- He’d already done a degree in journalism, but he realized how much he loved acting so he auditioned for a drama school and got in
  - But higher ed is usually free in Australia and this school cost $3500
  - He threw away the acceptance letter because he knew he couldn’t afford it
  - His grandmother had died a few months before, and the day after he got the letter he got a check for $3500 from her estate
  - He sees that as a TSN turning point
- At the end of that year, he landed a role on [*Neighbours*](https://en.wikipedia.org/wiki/Neighbours), a popular soap opera similar to [*Beverly Hills 90210*](https://en.wikipedia.org/wiki/Beverly_Hills,_90210) and [*Melrose Place*](https://en.wikipedia.org/wiki/Melrose_Place) that launched the careers of many famous actors
  - He was offered a 2-year contract that paid $2000 a week
  - Had to choose between going off to drama school or taking the role
  - He was torn because he wanted to work at Royal Shakespeare Company or the National Theater
  - He decided to turn down the job and go to drama school
  - Like Peter’s goal to be a great surgeon, Hugh wanted “the opportunity to do everything”
- His dad declined to give him advice but was thrilled with his decision
  - His dad knew he couldn’t advise him because it would have denied Hugh a moment of maturing and growing and left him forever thinking “Dad told me”
  - This was another TSN turning point for Hugh

## How driven personalities often develop from a place of trauma, and how to avoid going from productive to destructive [47:00]

- When Hugh was 8, his mom left (47:03)
  - She had severe postnatal depression and was hospitalized
  - Hugh lived with his godparents until he was about 18 months old
  - Hugh was the youngest of 5 kids and his mom would periodically go away
  - When Hugh was 8 and his oldest sister was about 16, his mom went to take care of her sick mother in England and did not return
- His dad raised them all and did not have a minute to himself for about 10 years
  - Hugh got his work ethic from him
- His mother’s leaving probably subconsciously shaped his perfectionism and strong desire to please people (“You’ve got to work really hard to make sure people don’t leave”)
  - People though that, at 8, Hugh could not understand, but we underestimate children; he did understand
  - Hugh was not really angry with his mother; he understood that she loved him and had done her best
- He just watched the documentary series [*College Behind Bars*](https://www.pbs.org/kenburns/college-behind-bars/) by [Ken Burns](https://en.wikipedia.org/wiki/Ken_Burns) and [Lynn Novick](https://en.wikipedia.org/wiki/Lynn_Novick) about the [Bard Prison Initiative](https://bpi.bard.edu/) and highly recommends it (50:52)
  - He thinks his situation was the opposite of someone who becomes rebellious, as one of his brothers did
  - “When you have some kind of abandonment or a hole, my way of coping with that was I’m going to make sure … that no one’s going to want to leave me behind, ever”
- Peter says their mutual friend [Paul Conti](https://www.pacificpremiergroup.com/meet-our-team/) really understands trauma
  - Conti notes that two people even from the same household can adapt very differently to the same trauma as Hugh and his brother did (51:55)
  - but at some point those kinds of adaptations become counterproductive and maladaptive
  - It’s a form of [dialectical synthesis](https://en.wikipedia.org/wiki/Dialectic#Principles) to recognize this and try to change and improve things

**The need to go to the extreme**

- Hugh points out that Peter always had to do things in the extreme: be the best surgeon, swim 50 miles, and push himself through crazy physical, mental, spiritual, and emotional limits (53:19)
  - Hugh recently read [*As a Man Thinketh*](https://www.amazon.com/As-man-Thinketh-Original-Wisdom/dp/B08W7DWHSS/ref=pd_lpo_14_t_0/139-2451850-0250862?_encoding=UTF8&pd_rd_i=B08W7DWHSS&pd_rd_r=29d3038e-78e8-437e-af14-36304d241936&pd_rd_w=txaUd&pd_rd_wg=NMQdJ&pf_rd_p=fb1e266d-b690-4b4f-b71c-bd35e5395976&pf_rd_r=A2RW2RG7PF7JHEJHW762&psc=1&refRID=A2RW2RG7PF7JHEJHW762), written by [James Allen](https://en.wikipedia.org/wiki/James_Allen_(author)) in 1902, about how growth is a natural state that is part of nature
  - But Hugh and especially Peter have gone beyond the natural state through unusual amounts of pain or sacrifice
- What would Peter tell his kids about how to tell where the line is when it becomes destructive and not productive?
  - Peter feels conflicted between knowing adverse childhood experiences helped him become resilient and not wanting his kids to experience those things (54:44)
  - Wonders how to create resilience from a positive place when most of his drive came from a negative place
  - But it needs to come from self-love and not self-flogging
  - “One of the things I’m really interested in exploring as a parent, is how do you encourage your kids to achieve the best that they can do, but not from this place of beating themselves up to do it?”
- Hugh pressed his father to tell him what he was doing wrong as a parent and his dad said he praised the kids too much (56:26)
  - Hugh thinks it’s a balance of praise and expectations
  - He likes [Seth Godin](https://en.wikipedia.org/wiki/Seth_Godin)’s idea of owning your fear and every person taking responsibility for being a part of a community
- When Hugh’s daughter was taking a standardized test, he told her, “No test is a reflection of you, who you really are. Just be curious and open. Love you”
  - He tells his kids not to just be good like he was because the world does not need more people like that

> “The world will always need people who are going to do what they love. Know when enough is enough. More is not always better in terms of consuming or just achievement. Be disciplined about doing less.” – Hugh Jackman

## The effect of fame on Hugh’s family [58:45]

- Hugh’s son was upset when he found out [John Lennon](https://en.wikipedia.org/wiki/John_Lennon) had been killed (58:49)
  - He worried that Hugh would be killed too and Hugh considered stepping away from acting for a while
  - He hated the paparazzi and the attention
  - He would yell when people came up to say he was cute and use him as a way to meet Hugh
  - If he asked his son to clean his room, he would ask why he should do what Hugh wanted when Hugh wouldn’t stop acting
- His son wondered whether Hugh would have made different choices if he had understood that he would become famous and how the fame would impact his son
  - Hugh said he would not it for the fame or money but because he gets to work with incredible people and it’s what he loves to do
  - For a while he did think he should give us his work because it was so hard on his son
- His daughter’s reaction was much different and balanced
  - The kids are especially famous in Australia, where Deb is famous too
  - As photographers were snapping photos in an airport, Hugh asked her if she wished he had a different job
  - His daughter said, “Dad, we just got off a first-class flight from New York to Sydney. I can put up with this for like 40 seconds”
  - She understands the trade off
- Hugh told the Australian paparazzi it bothered his son and he didn’t want to be hounded for a year (1:05:25)
  - He gave them the pictures they wanted of him shirtless at the beach (“the most uncomfortable 20 minutes of my life”) so they would leave him alone
  - They left his family alone after that

## How Hugh finds the energy to consistently perform, and the spiritual connection he feels when acting [1:07:15]

- Hugh and [Irv Milgrom](https://www.imdb.com/name/nm2916400/?ref_=ttfc_fc_cr1109) [Hugh’s executive assistant] stayed with Peter’s family when he was doing the stage version of *The Greatest Showman*
  - Peter wanted Hugh to relax, but the kids thought he was actually the greatest showman
  - He played with the kids instead of taking time for himself and Peter wondered where he got his energy
- Actors need to get out of their zone a bit
  - his drama teacher who told him a real actor will always accept a ticket to the ballet because “you don’t know where the inspiration is going to come from”
- Peter and Hugh reminisce about the visit
  - They remember that Hugh brought a bottle of [Penfolds Grange](https://en.wikipedia.org/wiki/Penfolds_Grange), which he says is “probably one of the finest wines Australia has produced”
  - Irv has been friends with Deb since they were about 11 and he has become a close friend
  - Hugh told him how much the time with Peter’s family was energizing for him
- Peter was amazed by the stage version of *The Greatest Showman* (1:12:39)
  - Hadn’t realized how personal it was
  - Peter thought it was moving and amazing how gracious you are with an audience and how much energy Hugh gave
  - Hugh did the show 92 times
    - Peter points out that for each person in the audience, it’s the only time they see it, and Hugh is “the type of person who goes out there and every night, you’re making sure that they see the best version possible”
    - It reminds Peter of [Muhammad Ali](https://en.wikipedia.org/wiki/Muhammad_Ali) saying that he wanted every person who came to watch him to see the best version of him
- Hugh says a movie set never feels like a sacred space but the stage sometimes does (1:14:52)
  - He rarely wears aftershave in real life but does when he’s on stage so it feels like a special night
  - Waiting in the wings before a show is a visceral thing to Hugh
  - Hugh likes the audience to feel like each performance is special
  - He feels calm and like himself when he’s on stage

**Hugh’s spirituality and feeling grounded [1:18:15]**

- Peter thinks it’s counterintuitive that Hugh says he’s an introvert but becomes so energized by his experience onstage (1:18:17)
- Hugh thinks there is a spiritual element to life and a higher purpose in everything you do
  - He wanted to get into acting because of the [Socratic](https://en.wikipedia.org/wiki/Socrates) ideal of knowing oneself
  - He no longer believes in a literal heaven and hell
  - Like the [Delphic Oracle](https://press.rebus.community/mythologyunbound/chapter/the-delphic-oracle/), he thinks the key is to “know thyself” – understand who you are and why you are here

> “The most spiritual moments I’ve had in my life have all been on stage where it’s like the moment in a movie when everything stops and things are floating and that feeling of timelessness, where things can be happening” – Hugh Jackman

- He’s only had that out-of-body experience on stage
  - Feel a connection with thousands of strangers
  - When his family is in the audience, he tries to find their eyes
- One night when he was doing *Sunset Boulevard*, Deb had a feeling Hugh had become a star
  - he sought her out backstage and told her that no matter what happened, she would always be the most important thing to him
  - That thought calms him down
  - He always puts his hand over his heart as a signal to Deb that she is the most important thing to him
  - At the Oscars, when he’s facing [Meryl Streep](https://en.wikipedia.org/wiki/Meryl_Streep), [Brad Pitt](https://en.wikipedia.org/wiki/Brad_Pitt), [Angelina Jolie](https://en.wikipedia.org/wiki/Angelina_Jolie) and other stars, seeing Deb calms him down makes him feel like it’s going to be ok
- Hugh asks Peter if, having seen death as a doctor, he is scared of it (1:23:29)
  - Peter says he answers the question in the epilogue of his book
  - His greatest fear, especially after he had kids, was of not being there
  - Feels a constant tension between what he’s doing and what he should be doing
  - He suspects his 10-year interest in longevity came out of a fear of dying without having done what he was supposed to do
  - He felt like he was not a good enough dad, husband, or anything else you can fill in
  - Now that he feels more confident in what he is doing, he is not afraid of death the way he used to be
- Hugh thinks that feeling that we’ve done enough takes a huge weight off

## Hugh’s experiences on the set of The Fountain and the meaning behind the film [1:26:30]

- Peter thinks Hugh’s movie [*The Fountain*](https://en.wikipedia.org/wiki/The_Fountain) is amazing (1:26:34)
  - They are both fans of the writer/ director, [Darren Aronofsky](https://en.wikipedia.org/wiki/Darren_Aronofsky) [01:26:43]
  - There are many possible interpretations of the movie, which is about mortality
- Darren came to see Hugh in the musical *The Boy from Oz* and offered him the role in *The Fountain*
- He had to do Tai Chi and yoga to prepare
  - It took him a year to get his hips flexible enough to be able to do the lotus position for a scene where he’s floating in space
  - Also tried to understand the history and mentality of it and talked to doctors
- The wife of Hugh’s character in the movie is sick and dying and he’s racing to heal her
  - It was the most lost Hugh ever got into a character
  - Darren became a great friend of Hugh’s and the filming was the closest Hugh has ever come to a spiritual experience doing a movie
  - “Particularly when I was in the spaceship, … there were moments where I touched on emotions for me, where an hour later I was still crying”
- Hugh says that Darren is a pure artist who believes in the sacredness of a creative space
  - Darren is interested in the broader sense of consciousness and immortality
  - It was the only time he came from filming a movie where it took him a while to get grounded again
  - Hugh and Darren formed a creative bond during their time in the spaceship set
- Darren wouldn’t tell him what he intended the movie’s message to be
  - He said it was whatever it was for Hugh and the audience
  - But what Darren said at press conferences was not what Hugh expected
  - Peter thought the present was the present while the past and future were metaphors for a kind of emotional travel (1:32:26)
    - The character’s wife was dying and he was struggling with mortality and his loss of control and inability to save her
    - Hugh’s interpretation was the same
  - Darren’s was different, he said something like the future is the present
- Hugh thinks Darren is a genius filmmaker
  - He is funny and interesting and they have stayed in touch
  - “I sort of love the mystery of that movie. It’s sort of the mystery of life. It is whatever we want to believe it to be, it is”

## The potential of imagination, the idea of a higher power, and thoughts on science vs. religion [1:33:45]

**Manifestation**

- Peter thinks he’s too grounded in science to buy into [manifestation](https://en.wikipedia.org/wiki/Manifestation_(popular_psychology)), but Hugh says he’s a recent convert to it
  - Deb always felt it (1:34:23)
  - Hugh thought it sounded nice and thought the placebo effect made sense: if you believe something, it’s probably going to come true
- He used to tell people that if he had manifested when he was 23, he would not have thought up half the stuff he’s done or experienced
  - “I would have had far less sort of scope to imagine what could be” and would have limited his life
- Hugh and Deb play backgammon 15-20 times a day, 400-500 times a month
  - It’s a short game that doesn’t demand a lot of time commitment like chess
  - Hugh decided to test out the idea he was hearing from a life coach on backgammon
  - “I’m going to practice and close my eyes, believe it, feel it, imagine it. Okay, imagine your senses around it. That feeling when the dice is rolling into double six”
  - It worked and he won
- He thinks if Peter said he was into it, he would be professionally destroyed

**The power of imagination combined with practice**

- [CBS This Morning](https://www.cbsnews.com/cbs-this-morning/) has a feature called [Note to Self](https://www.cbsnews.com/cbs-this-morning/note-to-self/) in which people would write a letter to their younger selves
  - Hugh recommends reading the [letter](https://www.cbsnews.com/news/coach-k-duke-basketball-mike-krzyzewski-note-to-self/) by [Mike Krzyzewski](https://en.wikipedia.org/wiki/Mike_Krzyzewski) (“Coach K”), which was about the power of imagination
  - Coach K told the child version of himself that he hours he spent imagining hitting the game time buzzer and winning the championship “are preparing you for the future in ways you do not yet understand” (1:37:33)
  - Peter finds this plausible because it is “rehearsing a set of skills and literally myelinating a set of channels in the body that do come into play” (1:38:02)
- But he doesn’t see how it could work for something random that’s out of your control, “which of course is exactly the great conundrum of how one reconciles religion and science”
  - Peter says it makes sense to him that religion exists “because we had no tool to explain the natural universe until 400 years ago”
  - We couldn’t explain why it was light or dark out, why we saw stars, etc., without understanding gravitational forces and planetary rotation (1:39:00)
  - We had to come up with something plausible, the stories that become the basis for religions

**Religion vs. science**

- Science is difficult for people to understand because it’s not innate
  - the scientific method is only ~400 years old, less than 1/1,000th of 1% of evolutionary history
  - Learning to think critically is a craft you have to practice – it’s difficult and unnatural
  - We’re wired to recognize patterns and come up with stories
- Peter loves to explain science to his kids
  - If they ask if God is real, Jill will say something like “that’s a mystery” while Peter will say there is no evidence and it’s an unanswerable question (1:40:54)
  - He’ll ask his kids to think how they would go about answering the question and how they would test the claims

## The deep connection Hugh felt to Logan (his character in Wolverine) [1:41:45]

**Logan**

- Peter feels a great deal of affection for [Logan](https://en.wikipedia.org/wiki/Logan_(film_series_character)) ([Wolverine](https://en.wikipedia.org/wiki/Wolverine_(character)) from the [X-Men](https://en.wikipedia.org/wiki/X-Men)) even though he is a fictional character (1:41:45)
  - Hugh says Logan is an archetypal character
  - the outsider and reluctant hero who marches to the beat of his own drum
  - and he’s imperfect so we can relate to him
- “When you’re acting, you have to fall in love with the character” (1:42:54)
  - Shakespeare was brilliant, because even if it’s Macbeth, you get inside his head, understand his ambition, failings, and desires, and you can see it coming
  - Hugh and Wolverine are opposites in many ways: unlike Hugh, Wolverine is an outsider and not a people-pleaser

> “Playing someone who was the opposite was so great for me, so kind of relieving and fun. And it was difficult at the front, too.” —Hugh Jackman

- At the beginning Wolverine was teaching him

- For the first movie, he didn’t feel supported and it took a long time to feel comfortable on set
  - [Dougray Scott](https://en.wikipedia.org/wiki/Dougray_Scott) was supposed to be Wolverine, but he got injured while doing another movie and its filming was delayed (1:44:17)
    - Hugh came in a few days after filming had begun in 1999
    - Hugh had auditioned on set and come from the theater
  - He felt isolated and thought he was going to get fired
    - When he complained about the experience, Deb told him that he had to put in the work
    - It was another TSN turning point for him
  - Instead of trying to make scenes work, he ad-libbed and took over “because I felt like I was fighting for my life” (1:45:33)
  - He could tell things were starting to turn around because he was getting calls from the studio

**Hugh’s experiences as Wolverine and making the movie** ***Logan*** **[1:46:45]**

- He thinks it was a shock to everyone how well the film did
- But his affection got deeper and deeper as it went on
  - People asked him if it got boring to do another Wolverine movie but it never did
  - It’s like taking a long break from going to the gym and then learning how to do it again
  - He had no say over the first story but by the last one he was really adamant about what they were going to do
  - He felt he’d let the character down because there was more to him, but he was one of 12 characters
- [*X-Men Origins:Wolverine*](https://en.wikipedia.org/wiki/X-Men_Origins:_Wolverine) (2009) was the first film to primarily feature Hugh until [*The Wolverine*](https://en.wikipedia.org/wiki/The_Wolverine_(film)) (2013) and *Logan* (2017) (1:48:13)
  - Peter has seen *Origins* many times and says it was unbelievable
  - But Hugh felt that it hadn’t gotten to the core of the character and there was a deeper story to tell
- Hugh wanted to call the last movie *Logan* because it was more about the human part of the character
  - but the studio wanted Wolverine because they’d built the brand with that name
  - Eventually it was called Logan and Hugh was “super proud of it because I knew it was going to be my last one”
- He played the character in 9 different movies and didn’t want to lose himself or have any regrets about it (1:49:34)
  - “I just still pinch myself that I got to play such a great role, that I feel at peace with it”
  - Getting the role was a TSN turning point moment for him
- Peter found the scene where [Professor X / Charles Xavier](https://en.wikipedia.org/wiki/Charles_Xavier_(film_series_character)) dies heartbreaking because when X-24 (Logan’s clone) stabs him, Charles thinks that Logan killed him
  - Hugh loved what [Jim Mangold](https://en.wikipedia.org/wiki/James_Mangold) (a friend he has done 3 movies with) and the writers did with that scene (1:50:36)
  - Thinks Patrick Stewart did an incredible job with his monologue about admitting his failures and regrets and telling Logan it was not too late for him
- Knew it was going to be a real film not a superhero movie
  - The scene where [Laura](https://en.wikipedia.org/wiki/X-23) tips the cross on the grave into an X is very emotional
  - When they started the movie, they weren’t sure if they were going to have Wolverine die (“unless we earn that moment, then it’s a stunt”) (1:52:41)
- He, James and Patrick had a chance to build relationships over 17 years in a business where that’s rare and it was a gift
- The first time Peter watched the last scene, when Logan says “this is what it feels like,” Peter thought he was talking about death  (1:53:19)
  - Jim wrote the line and when he read it Hugh thought it was showing that the person who’s effectively immortal was unhappy with life because he was in so much pain
  - Jim Mangold said, “In a movie, don’t tell me one plus one equals two. … Tell me one plus one equals three, and then spend the movie proving it to me”
  - The end line was a great example of that and Darren Aronofsky knows that fully

## Reflections on physical aging, emotional wellbeing, and longevity [1:55:15]

- When Hugh was training for Wolverine, he worked with a professional bodybuilder named Scott (1:55:26)
  - From him he learned to start light and then by the time you’re on the 3rd or 4th set your body has gotten used to it and you want to do more – it doesn’t feel like a chore
  - The trainer got asked the same question about what the primary thing to do to get in shape was all the time
    - A common answer he would give would be: “*Don’t eat carbs after 3pm. You’ll lose three to five kilos in the first month*.”
- Hugh wonders what Peter’s main thing for longevity would be
  - Peter says the universal answer might be not to underestimate exercise, which is a very potent tool to slowing down aging (1:57:45)
    - Just look what happens when someone around 50 years old is hospitalized for a week–it might take 6 months to recover physically
  - His other advice would be not to underestimate the power of relationships
    - They affect quality of life more than length, but that is key
- Hugh’s friend [Gus](https://www.gotcha4life.org/team) started a charity called [Gotcha 4 Life](https://www.gotcha4life.org/) after doing a documentary on male suicide with the idea of not worrying alone (1:59:33)
  - everyone needs to unload and have someone they can say anything to
  - Hugh and Peter have that in their marriages, but not everyone does
  - Peter used to disregard the emotional side and now he is the opposite (2:00:27)
- Once you realize something, it’s hard to imagine how you didn’t know
  - [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) spoke eloquently about it in his commencement address “[This is Water](https://www.youtube.com/watch?v=PhhC_N6Bm_s)”
  - It’s important to recognize the many small ways we can sacrifice for other people, as we see in parenting and marriage

> “But I think somehow finding the beauty in those difficult moments. …There is value in that and I think there is joy in that” – Peter Attia

- When Hugh’s first child was born, Hugh’s oldest brother Ian told him there would bad moments along with the joyful ones and he could always call him (2:02:06)

> “The mirror gets shown up to you about who you are so quickly as a parent, very nakedly” – Hugh Jackman

- How does Hugh handle aging in his field, which while harder for women, affects all actors? (2:03:03)
  - Someone like [Clint Eastwood](https://en.wikipedia.org/wiki/Clint_Eastwood) has been able to transition into each age
  - Hugh has resisted minor cosmetic procedures suggested by the doctor who removed his skin cancer
  - Hugh embraces and enjoys aging
  - It seems exhausting to constantly be striving to look a certain way to stay a star
  - Hugh says it’s as hard to get an appointment with his singing teacher, [Liz Kaplan](https://lizcaplan.com/), as it is to get a doctor’s appointment
- [Paul Newman](https://en.wikipedia.org/wiki/Paul_Newman) is Hugh’s “north star”
  - Peter has pictures of Paul Newman, [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman), and [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) on his office wall
  - Hugh admires the way Newman kept his passions going with acting, [Newman’s Own](https://newmansown.com/), the actors’ union, and nuclear disarmament
  - He met him once
- Peter thanks Hugh for being so open: “It’s a hard thing for an actor to do because you have this contract with us that says, as long as we don’t know you, we can believe you”
- Hugh thinks Peter’s work has helped him and others

§

## Selected Links / Related Material

**NYT review of** ***Hugh Jackman: Back on Broadway*** **that Deb told Hugh to read that he became fixated on**: [A Master of Mass Flirtation](https://www.nytimes.com/2011/11/11/theater/reviews/hugh-jackman-back-on-broadway-at-broadhurst-review.html) | Ben Brantley, *New York Times* (Nov. 10, 2011) | [26:30, 1:20:15]

**Documentary series Hugh recommends**: [College Behind Bars](https://www.pbs.org/kenburns/college-behind-bars/) | pbs.org (2019) | [50:45]

**Book Hugh recently read about how growth is part of nature**: [As a Man Thinketh](https://www.amazon.com/As-man-Thinketh-Original-Wisdom/dp/B08W7DWHSS/ref=pd_lpo_14_t_0/139-2451850-0250862?_encoding=UTF8&pd_rd_i=B08W7DWHSS&pd_rd_r=29d3038e-78e8-437e-af14-36304d241936&pd_rd_w=txaUd&pd_rd_wg=NMQdJ&pf_rd_p=fb1e266d-b690-4b4f-b71c-bd35e5395976&pf_rd_r=A2RW2RG7PF7JHEJHW762&psc=1&refRID=A2RW2RG7PF7JHEJHW762) by James Allen (1902) | [53:45]

**Coach K’s letter to his younger self**: [Duke’s Coach K on his historic path: “Never underestimate the immense power of your imagination”](https://www.cbsnews.com/news/coach-k-duke-basketball-mike-krzyzewski-note-to-self/) | Mike Krzyzewski, *CBS News* (March 14, 2018) | [1:37:00]

**Commencement speech by David Foster Wallace**: [This Is Water by David Foster Wallace Full Speech](https://www.youtube.com/watch?v=PhhC_N6Bm_s) | Joe Mita (youtube.com) [2:01:00]

§

## People Mentioned

- [Sir Trevor Nunn](https://en.wikipedia.org/wiki/Trevor_Nunn) [5:15, 6:30, 8:30]
- [Tom Brady](https://en.wikipedia.org/wiki/Tom_Brady) [7:00]
- [Drew Bledsoe](https://en.wikipedia.org/wiki/Drew_Bledsoe) [7:15]
- [Judy Dench](https://en.wikipedia.org/wiki/Judi_Dench) [8:45]
- [Patrick Stewart](https://en.wikipedia.org/wiki/Patrick_Stewart) [8:45,1:50:00, 1:50:45, 1:51:15, 1:53:00]
- [Ian McKellen](https://en.wikipedia.org/wiki/Ian_McKellen) [9:00]
- [Ester Perel](https://www.estherperel.com/) [13:15]
- [Gary Hart](https://en.wikipedia.org/wiki/Gary_Hart) [22:15]
- [Deborra-Lee Furness](https://en.wikipedia.org/wiki/Deborra-Lee_Furness) [26:00 and then throughout]
- [Adolf Hitler](https://en.wikipedia.org/wiki/Adolf_Hitler) [28:45, 30:30]
- [Joe Rogan](https://en.wikipedia.org/wiki/Joe_Rogan) [29:45]
- [Ken Burns](https://en.wikipedia.org/wiki/Ken_Burns) [50:45]
- [Lynn Novick](https://en.wikipedia.org/wiki/Lynn_Novick) [50:45]
- [Paul Conti](https://www.pacificpremiergroup.com/meet-our-team/) [51:45]
- [James Allen](https://en.wikipedia.org/wiki/James_Allen_(author)) [53:45]
- [Seth Godin](https://en.wikipedia.org/wiki/Seth_Godin) [57:15]
- [John Lennon](https://en.wikipedia.org/wiki/John_Lennon) [59:45]
- [Irving Milgrom](https://www.imdb.com/name/nm2916400/?ref_=ttfc_fc_cr1109) [1:07:30, 1:12:00]
- [Muhammad Ali](https://en.wikipedia.org/wiki/Muhammad_Ali) [1:14:45]
- [Meryl Streep](https://en.wikipedia.org/wiki/Meryl_Streep) [1:23:00]
- [Brad Pitt](https://en.wikipedia.org/wiki/Brad_Pitt) [1:23:00]
- [Angelina Jolie](https://en.wikipedia.org/wiki/Angelina_Jolie) [1:23:00]
- [Darren Aronofsky](https://en.wikipedia.org/wiki/Darren_Aronofsky) [1:26:30, 1:27:15, 1:29:30, 1:30:45, 1:33:15, 1:53:15]
- [Mike Krzyzewski](https://en.wikipedia.org/wiki/Mike_Krzyzewski) (“Coach K”) [1:37:00]
- [Dougray Scott](https://en.wikipedia.org/wiki/Dougray_Scott) [1:44:15]
- [Jim Mangold](https://en.wikipedia.org/wiki/James_Mangold) [1:50:30, 1:51:15, 1:54:45]
- [Gus Worland](https://www.gotcha4life.org/team) [1:59:30]
- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) [2:01:00]
- [Clint Eastwood](https://en.wikipedia.org/wiki/Clint_Eastwood) [2:03:30, 2:05:30]
- [Liz Kaplan](https://lizcaplan.com/) [2:05:15]
- [Paul Newman](https://en.wikipedia.org/wiki/Paul_Newman) [2:05:30, 2:05:45]
- [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) [2:05:45]
- [Ayrton Senna de Silva](https://en.wikipedia.org/wiki/Ayrton_Senna) [2:05:45]

§

![](https://peterattiamd.com/wp-content/uploads/2021/07/1x1-hughjackman-500x500.jpeg)

##### Hugh Jackman

Hugh Jackman is an actor, singer, and producer who has worked on the stage, in musical theater, and in film. Best known for his role as Wolverine/Logan in the *X-Men* movies, he has also played the lead role in *Kate & Leopold* (2001), *Van Helsing* (2004), *The Prestige* (2006), *The Fountain* (2006), *Australia* (2008), *Les Misérables* (2012), *Prisoners* (2013), and *The Greatest Showman* (2017).  He was nominated for the Academy Award for Best Actor and won the Golden Globe Award for Best Actor – Motion Picture Musical or Comedy for his role as Jean Valjean in the movie version of *Les Misérables*.  He won the 2004 Tony Award for Best Actor in a Musical for his role in *The Boy from Oz*. He has hosted both the Tony Awards and the Academy Awards and was appointed a Companion of the Order of Australia. He is married to the actress Deborra-Lee Furness and has two children, Oscar and Ava.