# #278 ‒ Breast cancer: how to catch, treat, and survive breast cancer | Harold Burstein, M.D., Ph.D.

**Source:** [https://peterattiamd.com/haroldburstein/](https://peterattiamd.com/haroldburstein/)

---

Harold (Hal) Burstein is an internationally renowned breast cancer expert. In this episode, Hal discusses a broad range of topics related to breast cancer, starting with the intricacies of breast anatomy and the endocrinological factors at play. He covers the spectrum of breast cancer, from precancerous lesions to invasive breast cancer, classifying these conditions into a helpful framework. He delves into various screening methods, including self-exams, mammograms, ultrasounds, and MRIs, and addresses the ongoing debate surrounding early screening and detection. Hal provides insights into the latest advancements in cancer treatment, offering valuable guidance for individuals to understand their unique circumstances within the three primary categories of breast cancer. Finally, Hal delves into the role of genetics in breast cancer and brings attention to the less commonly addressed issue of male breast cancer.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/haroldburstein/the_Drive_public.png)

Play

#278 ‒ Breast cancer: how to catch, treat, and survive breast cancer | Harold Burstein, M.D., Ph.D.

#278 ‒ Breast cancer: how to catch, treat, and survive breast cancer | Harold Burstein, M.D., Ph.D.

1x15s30s

0:002:10:23

## We discuss:

- The prevalence and mortality rate of breast cancer in women [4:15];
- The anatomy of the breast and the complex factors behind breast cancer development [6:30];
- The three main categories of breast cancer [16:45];
- Breast cancer risk: the impact of menopause, estrogen, breast density, obesity, and more [21:15];
- Finding and evaluating lumps in the breast [25:30];
- Identifying and treating precancerous lesions like ductal carcinoma in situ (DCIS) [31:00];
- Post-lumpectomy for DCIS: standard of care, future risk of cancer, and pros and cons of radiation and other preventative options [41:15];
- Lobular carcinoma in situ (LCIS): how it differs from DCIS in terms of treatment and future risk of invasive cancer [55:00];
- Breast cancer screening: mammography, ultrasound, MRI, and more [1:03:45];
- Invasive breast cancer: pathology report, surgery, and survival [1:11:00];
- The argument for aggressive screening for breast cancer [1:22:15];
- Advances in the treatment of breast cancer, adjuvant therapy, and neoadjuvant therapy [1:27:00];
- The use of hormone replacement therapy in women who are in remission from breast cancer [1:41:15];
- The role of genetics in breast cancer [1:44:45];
- The importance of multidisciplinary care delivered by cancer centers [1:53:15];
- Breast cancer in men [2:03:30];
- Parting thoughts and takeaways [2:05:45]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Harold Burstein goes by Hal, and he is a Professor of Medicine at Harvard Medical School
- He earned his M.D. and Ph.D. in cellular immunology from Harvard Medical School as well as a masters degree in the history of science
- Hal trained in internal medicine at the Massachusetts General Hospital before his medical oncology fellowship at Dana-Farber Cancer Institute
- He joined the staff of Dana-Farber and is also on staff at Brigham and Women’s Hospital where he is a clinician and clinical investigator in the breast oncology center
- Hal’s research interests include therapy for early stage and advanced stage breast cancer, healthcare for breast cancer survivors, and quality of life and psychological issues among women with a history of breast cancer
- This is an episode Peter has wanted to do for a very long time
  - He’s already done an episode or two on [prostate cancer](https://peterattiamd.com/tedschaeffer2/), and prostate cancer is the second leading cause of cancer deaths for men
- Breast cancer is the second leading cause of cancer deaths for women

**In this episode we talk about all things related to breast cancer**

- Beginning with the anatomy and endocrinology of the breast
- The increasing rate of breast cancer over the past decade
- The changes to a woman’s breast throughout her life, and how that relates to understanding the pathology of breast cancer
- The different kinds of breast cancer including:
  - The precancerous lesions of ductal carcinoma in situ (DCIS) and lobular carcinoma in situ (LCIS)
  - Invasive breast cancer and the various stages
- Different ways you would classify these things
  - Hal does a masterful job of taking it into the 3 categories of breast cancer, a helpful framework
- Types of breast cancer screening available
  - The utility of self exams, mammograms, ultrasound, MRI, and more
- The importance of early screening and detection
  - This is still a very controversial topic
- Treatments for the different types of breast cancer
- How someone listening to this with breast cancer can understand which bucket they’re in (of the three) and what the implications are
- We end the discussion by speaking about the role of genetics in breast cancer
  - Many people have heard of the BRCA mutations, but they’re not the only genes involved
- We touch on male breast cancer
  - This is something that many people are surprised to learn exists
  - Peter has a close friend who was diagnosed with breast cancer
    - Fortunately, it was caught at an early stage and he is doing fine

## The prevalence and mortality rate of breast cancer in women [4:15]

**Give listeners a sense of your background, the post you sit in, and the work you do**

- Hal is a professor of medicine at Harvard Medical School and a medical oncologist here at Dana-Farber Cancer Institute where he specializes in breast cancer
- He trained in medical school as an M.D. Ph.D. student and got a Ph.D. in immunology
- Following that, he was a house officer studying internal medicine at Mass General and came over to Dana-Farber to do medical oncology where he’s  been for the reminder of his career
- In his day-to-day work, he sees a lot of patients who
  - He runs a very active and busy clinic at Dana-Farber
- He’s involved in a lot of teaching at the medical school
- He does a lot of both clinical research and clinical education
  - Including guidelines work with ASACO, the NCCN, the St Gallen Pathways, and other international and national groups interested in breast cancer care

**Give people a sense of the magnitude of breast cancer. What is a woman’s lifetime incidence of breast cancer?**

> “*The famous statistic is that American women have about a one in eight lifetime risk or 12% lifetime risk of developing breast cancer*.”‒ Harold Burstein

- The good news is that only a small fraction of those will be fatal
- The mortality associated with breast cancer depends on the stage at which it is caught
  - It also depends on the subtype of breast cancer because we have different treatment programs for each of the different subtypes of breast cancer
- If you look very broadly across the board, there are roughly 275,000 cases of breast cancer in the United States every year, and there are roughly 38,000 deaths
  - If you assume a steady state, we are curing 80-85% of women with breast cancer, but roughly 15-18% are still at jeopardy for recurrence and death from the disease

## The anatomy of the breast and the complex factors behind breast cancer development [6:30]

- One of the challenges of diagnosing breast cancer is that you don’t get to look directly at the place where the tumor arises, the way you do, for example, with colon cancer or skin cancer or cervical cancer
- It probably behooves us to spend some time explaining everything from the embryology to the prepubescent anatomy to the maturation process of the breast, and then perhaps even what happens during menopause

**How would you describe the development and changes of a breast during a woman’s life with a specific nod to how this will factor into helping us understand the pathology of breast cancer development during some of those stages?**

- The breast is a gland
  - It is fundamentally a sweat gland
- If you look at the pure embryology of it, it is the defining feature of what it is to be a mammal
- The breast goes through different stages of maturation and development in the life of a woman
  - It begins as a quiescent area of tissue and then during puberty, because of the hormonal changes, develops enlargement and maturation of the glands such that they become able to eventually secrete milk if the woman becomes pregnant
- The breast is largely composed of two types of tissue
  - 1 – The majority of the volume is actually just fat and non-specific stromal elements and the thing that determines the size of the breast in a woman is just really how much non glandular tissue there is
  - 2 – Glandular tissue
    - All women more or less have the same amount of glandular tissue in the breast (the milk generating component of the breast), and those ducks radiate from the various breast tissues into the nipple
  - The nipple has multiple orifices, and the God-given purpose here is to nurse the child

***Breast cancers largely arise from the ductal or the glandular tissue, and in this respect, breast cancer shares its origins with almost all common cancers, prostate cancer, colon cancer, lung cancer, where it is the glandular part of the organ from which arises the malignant cell***

- One of the interesting things about breast cancer and normal breast development is that there has been over the past decades, a **rise in the incidence of breast cancer** (the rate of breast cancer), and one of the likely contributors relates to the *early puberty* that we are now seeing in women
  - Girls are starting to menstruate at a far younger age in the 2020s than they were 100 years ago or certainly 150 years ago, owing probably to better nutrition and better general health
  - That means that the breast development and the exposure of the breast to estrogens starts earlier
- And women are also *menstruating for longer*, again, largely owing to better health
- Women are having, at the population level in the developed countries at least, fewer children, and they tend to nurse those children for a shorter duration of time
  - Again, this rarely describes an individual patient, but at the population level

***The rates of breast cancer are highest in the most developed societies, and many people think it relates to these issues of childhood nutrition, pubescent nutrition, number of pregnancies, duration of nursing, and that accounts for a lot of the difference in the incidence rates that we see between the United States and other parts of the world***

- As other societies become more developed, their rates of breast cancer tend to go up to mirror those of the US or Western European populations

**Peter remembers from medical school**

- A study of Japanese women (nearly 30 years ago) who moved to the United States and within a generation went from very, very low rates of breast cancer to assuming the same high rate of breast cancer as American women
- For Peter, the takeaway of that was we could never know what the causative driver was, given that there are so many things that are happening
  - But clearly there’s an *environmental component* to this, whether it’s some combination of food, exercise, hormones, stress levels, pollution
  - You would have a very long list of things that could change, that could amount for such a dramatic shift as opposed to saying, for example, there’s genetic differences that are accounting for this
- We’re obviously going to talk at length about the genetic drivers of this, but that wouldn’t explain the one generation shift

**Hal points out historical epidemiology on two cancers you can see**

- Back to the 19th century, one of the first cancer epidemiological findings was that nuns who never became pregnant were at greater risk for developing **breast cancer**
  - Peter asks how high the hazard ratios were for nuns versus non-nuns, but Hal isn’t sure they even articulated hazard ratios at that time
  - This predates radiology
  - Nowadays we would say their risk is higher because they were never pregnant or nursing
- Along with the discovery of **scrotal cancers** in chimney sweeps, it was one of the first real steps forward in the epidemiology of cancer biology to help people begin to get a sense of what was causing cancer
  - The hazard ratios were alarmingly high, around 4, 5, or 6
  - It was very easy to make the causal link
- Hal agrees that the environment in which a person grows up is going to have an impact on their breast cancer risk
  - By which he doesn’t specifically mean the atmosphere or the pollutants or all those kinds of things
- The dilemma here is that for any given individual, we almost never have a good sense of what their intrinsic risk of breast cancer is aside from the family history in genetic cancers
  - Why they get breast cancer now
  - Why they got it in one breast and not the other breast
  - All those things remain very mysterious
  - For someone who takes care of breast cancer patients, it’s a source of real frustration
- There are some tumors where we really think we understand why they’re at greater risk
  - The smoking and lung cancer, at least you can imagine how this arose
  - Whereas breast cancer is often a disease of very healthy women, women who have gone to great lengths to care for themselves, and despite that, they are encountering breast cancer diagnosis (which is often frustrating)

**Things that drive risk of developing breast cancer**

*The interaction between pregnancy and breast cancer risk is both very interesting and complicated*

- Multiple pregnancies lower the risk of breast cancer
- 1 – Pregnancy transiently increases the risk, and then it comes down as time goes by and no pregnancies are associated with a slightly higher risk of developing breast cancer
  - And that’s not related to the in vitro fertilization or other hormonal supplements
- They’ve looked at that with a lot of rigor, particularly the Scandinavian databases where they have outstanding public health registries of all the patients in the Scandinavian countries
- Infertility, for instance, is a slight risk for breast cancer, but the treatments for infertility per se are not

**When we talk about increased risk, there’s a huge difference between a population increased risk and the risk for a given patient**

- At the outset, we said 1 in 8 lifetime risk in the United States (that’s 12-13%)
- A woman who has early onset of menstruation or hormone replacement therapy such that they have **longer estrogen exposure** or shorter period of nursing or fewer pregnancies, they might have a 25 or 30% greater risk of breast cancer
  - But that only moves the needle from around 12% to around 15%
  - Hal points out, “*The risk at the population level is big, the risk for an individual is still pretty small for these kinds of factors.*”

**Do we have a sense of the difference between things that drive the increase in risk versus things that drive an increase in mortality?** [15:15]

- Peter points out, “*In prostate cancer, it’s generally well understood that the prevalence of prostate cancer approximates the decade of life of the male.*”
  - Basically half of men in their 50s have some prostate cancer (Gleason 3+3)
    - This is not a prostate cancer you would take out, but on autopsy you would find it
  - By the time a guy is in his 70s, you might expect there’s a 70% chance he has prostate cancer
    - Of course the challenge then of the urologist is understanding which man is going to die *from* versus *with* prostate cancer
- Peter has covered the topic of hormone replacement therapy (HRT) in such detail that it needs no further rehashing, but the punchline is while the [Women’s Health Initiative](https://jamanetwork.com/journals/jama/fullarticle/195120) demonstrated that women taking conjugated equine estrogen plus MPA had a 25% increase in the risk of breast cancer, *it never translated to an increase in mortality*
  - Similarly, the women who took conjugated equine estrogen alone saw a 24% decrease in breast cancer
  - [HRT was the topic of episodes [#253](https://peterattiamd.com/joannmanson/) and [#42](https://peterattiamd.com/caroltavris-avrumbluming/)]

*Do we have a sense of which risk factors are driving mortality versus just incidence?*

- No and yes
- At the population level, this gets us into the subsets of the different cancers that we speak about

## The three main categories of breast cancer [16:45]

**There are really three major flavors of breast cancer**

Most common:

- 1 – There is **estrogen receptor-positive, HER2-negative breast cancers** [[receptor status of breast cancer](https://en.wikipedia.org/wiki/Breast_cancer_classification#Receptor_status)]
  - Those are the most prevalent kinds of breast cancer, and they account for 70-75% of all breast cancers (if not more)
  - They are the tumors most likely to be found on screening mammography as opposed to presenting with a lump in the breast
  - They tend to have ounce for ounce, size for size, the most favorable prognosis in most instances (but not all)
  - They peak in incidences at around age 65 in the United States
  - Those are the sort of public health face of a lot of breast cancer

Other types of breast cancer presumably have different epidemiologic risk factors:

- 2 – **Triple-negative breast cancer**, which is lacking estrogen receptor, progesterone receptor, and HER2 (hence triple negative)
  - Those tumors have an earlier onset
  - They are more common in younger women, more common at the population level in African-American women
  - They are less likely to be the kind detected on a screening mammogram as opposed to a clinical finding
  - They are a riskier flavor of breast cancer
- 3 – **HER2-positive breast cancer** are tumors that have an amplification of the [HER2/neu](https://en.wikipedia.org/wiki/HER2) [oncogene](https://en.wikipedia.org/wiki/Oncogene)
  - They account for about 10-15% of all breast cancers
  - Like triple-negative breast cancer, these tumors were classically described in younger women.
- The epidemiology of HER2-positive breast cancer as opposed to ER-positive breast cancer is not really well described
- In general, older women are more likely to have better prognosis breast cancers at diagnosis because of the subset that arises in them, and younger women tend to have more aggressive flavors of breast cancer
  - Again, these are broad strokes
- Peter reacts, “*That’s just a fantastic overview of basically the three subtypes. I also want to point out that you did not talk about progesterone receptor except in the negative when you talked about the triple-negative case.*”

 **Case #1 is ER-positive, PR agnostic, HER2-negative**

- Although the vast, vast majority of those tumors also express progesterone receptor
- These are the ones more likely to show up on mammography
- They are seen across the whole age spectrum but the peak is about age 65

 **Case #2 (triple-negative) is about 10-15% of breast cancers**

- You can see them at any age, but they tend to skew younger
- Hal has seen 80-year-olds who have triple-negative breast cancer
- There is an interesting relationship between race and triple-negative breast cancer, and there’s been a lot of really excellent studies to suggest that there may be some real demographic genetic differences that predispose
  - We tend to see triple-negative breast cancers also in [*BRCA1* mutation](https://en.wikipedia.org/wiki/BRCA_mutation) carriers
  - There’s a clear link between specific genetic syndromes and BRCA, such as BRCA and triple-negative disease
- Triple-negative breast cancers also tend to be more virulent
- They’re more likely to present as a lump in the breast or a physical exam finding as opposed to readily being identified on a screening mammogram

**You mentioned a higher prevalence in African-American women. Where do Asian women fit into this?**

- They don’t have any enrichment in general over the US distribution

**Case #3 is HER2/neu-positive**

- This includes triple positives
- It is agnostic of [ER](https://en.wikipedia.org/wiki/Estrogen_receptor) and [PR](https://en.wikipedia.org/wiki/Progesterone_receptor) but is [HER2/neu](https://en.wikipedia.org/wiki/HER2)-positive
- They comprise about 15% of all breast cancer
  - Split half between ER-positive HER2-positive and ER-negative HER2-positive

**Case #3 includes all of your triple positives and is the distinction biological or is it made more because of Herceptin?**

- [Trastuzumab (or Herceptin)](https://en.wikipedia.org/wiki/Trastuzumab) is the targeted therapy that has been the revolutionary treatment in the management of HER2-positive tumors
- There *is* a biological difference
  - There is a specific region of the chromosome 17 that is amplified giving over-expression of the HER2/neu oncogene that’s presumably a driver for a fraction of these breast cancers
  - But it’s also very important because it allows us to bring a specific targeted therapy to play [Herceptin]

## Breast cancer risk: the impact of menopause, estrogen, breast density, obesity, and more [21:15]

**What happens to the breast during or post-menopause**

- During menopause estrogen and progesterone levels are falling dramatically
- Presumably there are anatomical changes occurring in the breast as the breast no longer needs to maintain the infrastructure for lactation.

**Is there anything worth talking about there specifically as it pertains to increasing risk?**

- Only indirectly ‒ estrogenization of the breast does account for breast density, which is something that is often seen on a mammogram
  - There is a relationship between more breast density and a slightly greater risk of developing breast cancer
  - Presumably that relates somehow to the woman’s lifetime exposure to estrogen
  - Postmenopausal women who have **more dense breast tissue** on mammogram are at *slightly greater risk* of developing breast cancer
    - And it’s not simply that the density makes it harder to see the breast cancer

**Is estrogen controlling ductal density?**

- It’s more about the soft tissue component of the breast
- In a *premenopausal* woman, with the monthly cyclical variation, the breast will have changes in both the ductal tissue and the other tissues
  - If anybody listening to this as an embryologist or a breast surgeon, they’re rolling their eyes here because Hal is not going to get all the details correct
  - But in broad terms, there is monthly change in the breast architecture and tissue
- But for *postmenopausal* women on the screening mammogram, that density reflects the fibrous tissue: the fatty tissue in the breast, not specifically the glandular tissue
- Peter recalls Hal mentioned at the outset that regardless of the size of a woman’s breast (so if you compare a woman with an A cup to a D cup), the glandular tissue is still relatively consistent
  - Peter took that to mean the risk of breast cancer by breast size was also relatively similar given that they’re dealing with the same amount of glandular tissue

*Is that an incorrect assumption?*

- That’s a correct assumption
- Breast size at the extremes tends to correlate with obesity
- There is a weak but detectable link between obesity and breast cancer risk
  - Perhaps a slight, slight increased risk

***We don’t fundamentally think that breast size affects risk***

**Breast density and risk**

- Density is a marker that is associated with a slightly increased risk
  - And not just from a detection standpoint
- A lifetime risk of 1 in 8 to 1 in 6 or 7 is the kind of thing that is very important from a public health point of view
- But for any woman, this is rarely a huge driver
  - Hal points this out to draw a distinction between a genetic syndrome and specific behaviors (like smoking) that we know are clearly a dominant risk factor for many different kinds of tumors

**Modifiable risk factors**

- Peter points out, “*The WHO would say that the top two environmental triggers for cancer are, in order, smoking and obesity.*”
- He always thought that obesity is just a proxy for insulin resistance and it’s really the the hyperinsulinemia, the excess growth factors and the inflammation that track with obesity rather than the adiposity per se, that is driving that risk

**How much do those two factors (smoking and obesity right up to type II diabetes) move the needle at the individual level for risk?**

- Smoking is not a major risk factor for breast cancer
  - Smoke affects the aerodigestive tract and some of the internal organs like the kidneys that end up filtering out some of the carcinogens and stuff, but it’s really not part of the breast story
- Obesity is a relatively weak risk factor relative to many others
  - It’s certainly not one that has allowed us to stratify patients for high risk screening versus not, or offer reassurance to a woman that she is not at jeopardy for breast cancer because of lean body mass or things like that

## Finding and evaluating lumps in the breast [25:30]

**What is the probability that a woman doing a correct self-exam will feel a lump in her lifetime?**

- Most women have variations in the texture of the breast, and so almost all women have breast tissue or other things that one can feel and they can appreciate that vary
- In younger women, these may change with the monthly cycle, and in postmenopausal women, they may represent just residual breast tissue
- With weight loss, you might feel some of that architectural tissue more readily than other times
- So there’s a lot of normal lumpiness, if you will, to the breast
- Hal’s **advice to patients** is that they have an awareness of their body and a general sense of what feels normal to them and what feels different from normal to them

***It’s been pretty hard to show that a regular monthly breast self self-exam or a rigid approach to self palpation adds that much***

- There have been some studies in China where they literally had tens of thousands of patients who were taught how to do a breast exam versus not, and it really didn’t change the mortality from breast cancer

***What changes the mortality is a real awareness of the body and the breast***

> “*Our message to women is if you feel something different, suspicious, concerning, seek evaluation.*”‒ Harold Burstein

**Get a breast lump of change in the breast evaluated**

- Nowadays we can usually get people imaging studies (whether it’s mammography or ultrasound combined with an exam by a breast surgeon or a breast expert), and usually do a quick evaluation that most of the time reassures the patient that this is a *benign* finding in the breast itself
  - Some patients may need further evaluation either with follow-up imaging or even with some kind of a needle biopsy
  - But the majority of these findings are not going to be breast cancer

**If a woman ends up having a lump that is suspicious on a mammogram, what is the next step?**

*When does it go down the path of more imaging versus a needle biopsy versus an excisional biopsy?*

- Hal reiterates, “***The key takeaway is if people feel a lump, they should seek medical evaluation***.”
- The quality of radiology has become really terrific at most places around the country
  - And they can often look at findings and say, “*Yeah, this looks like a benign change*,” or, “*Yeah, this same thing was seen a year ago and five years ago when the patient had a mammogram and it hasn’t evolved in any way, so it’s reassuring*.”
  - Or they can say, “*I’d like to get more imaging*”
- Sometimes patients are referred for additional ultrasound or MRI imaging to be sure
- Sometimes it’s necessary to get a tissue biopsy to really understand what exactly is going on
  - Nowadays that usually begins with an **image guided needle biopsy** or core needle biopsy where using an ultrasound or other imaging device
  - The radiology team knows exactly where to pinpoint the lesion within the breast
  - They use a very fine gauge needle to extract a tissue biopsy that’s around the width of a pencil lead
    - With that, they can look under the microscope and usually make a clean diagnosis about what’s going on within the breast itself

**What fraction of biopsies turn out to be a benign lesion such as a** [**fibroadenoma**](https://en.wikipedia.org/wiki/Fibroadenoma)**?**

- Hal would have to look that up
- For most women, it turns out to be very reassuring that either it is a benign lesion (like a fibroadenoma) or even a pre-pre-cancerous change in the breast that might warrant additional follow-up or surveillance, but is not truly breast cancer
- Peter clarifies, “*Which would be the analog of finding a polyp in the colon, which gets removed, which puts you on alert for more screening, but of course is not cancer itself.*”
  - Correct
- Hal adds that we will talk about [ductal carcinoma in situ (or DCIS)](https://en.wikipedia.org/wiki/Ductal_carcinoma_in_situ) which is a precancerous lesion where the cells are beginning to accumulate within the duct but have not penetrated into the rest of the breast tissue
  - The analogy he gives to patients all the time is this is like a colon polyp
  - It is a precancerous growth
  - We treat it so that it doesn’t blossom into a full-blown cancer, but in and of itself, it is not a cancer lesion

## Identifying and treating precancerous lesions like ductal carcinoma in situ (DCIS) [31:00]

**Explain the difference between ducts and lobules, and then how does that factor into ductal carcinoma in situ (DCIS) versus lobular carcinoma in situ (LCIS)?**

- The **ductile tissue** of the breast includes sort of a highway where the milk would come out of the breast, and then at the end of it, a parking lot where the sort of **terminal lobule**, where the gland terminates and the milk would be generated
  - Again, Hal’s breast cancer surgeon friends are rolling their eyes, but that gives you a flavor of what we’re talking about
  - [the ducts and lobes are shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2023/11/f1-haroldburstein.png)

**Figure 1. Anatomy of the breast and changes that occur with DCIS**. Image credit: [National Cancer Institute](https://www.cancer.gov/types/breast/breast-changes)

- The relationship between lobular carcinoma (or lobular carcinoma in situ) and ductal carcinoma (or ductal carcinoma in situ) really don’t exactly correlate to the architecture of the normal gland itself
  - It’s really how the cells look under the microscope
  - You can see changes in these cells that are staged along the way towards cancer
- One of the things that is **associated with an increased risk of breast cancer** is if there are prior changes in the breast that suggest abnormal amounts of proliferation or atypical-appearing cells, which are sort of the pre-pre-cancerous stages
- Oftentimes a woman might have a biopsy that shows what’s called [atypical hyperplasia](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/atypical-hyperplasia): there are too many cells present, that’s the hyperplasia, and those cells don’t look exactly normal
  - The nucleus begins to look a little more aggressive in things and if you’re familiar with talking about [Gleason scores](https://en.wikipedia.org/wiki/Gleason_grading_system), the Gleason score is beginning to drift up there
    - [Gleason scores discussed in [episode #273](https://peterattiamd.com/tedschaeffer2/) in regards to prostate cancer]

[***ADH (atypical ductal hyperplasia)***](https://en.wikipedia.org/wiki/Atypical_ductal_hyperplasia) ***or*** [***ALH (atypical lobular hyperplasia)***](https://www.mskcc.org/cancer-care/patient-education/atypical-hyperplasia) ***are lesions that put a woman at slightly greater risk for developing breast cancer in the decades to follow***

- The numeric risk is still pretty small, probably only about a 0.5-1% per year risk of developing breast cancer at follow-up, but it’s one of those precursor lesions that begins to flag a patient as being at greater risk for developing breast cancer

**Then the next step along the way would be** [**in situ carcinoma**](https://en.wikipedia.org/wiki/Carcinoma_in_situ)

- These are cells that have taken one more step towards looking like cancer
- If you were to look under the microscope, the cell itself looks like it’s almost a cancer cell, but it is respecting some of the normal membranes of the breast gland
  - It’s not penetrating into the breast tissue
  - It hasn’t gone through whatever the final steps of full-blown carcinogenesis are such that that cell can now persist, thrive outside of that gland and begin to develop its own blood supply or even metastasize somewhere else in the body (which is how we think of breast cancer)
- You will encounter those lesions along the way

**Many women have been diagnosed with these precursor lesions, particularly ALH, ADH**

- They can show up as architectural changes in a mammogram, they can show up as calcifications in a mammogram
- It’s rare to find that you actually can feel these things, though sometimes it’s an incidental finding if you’re evaluating a lump in the breast
  - And those are things that warrant regular surveillance
- In some instances, we can actually now use antiestrogen medicines like [Tamoxifen](https://en.wikipedia.org/wiki/Tamoxifen) to help slow the development of any malignant cells in a patient with those problems

**Do we have a sense of how often those things exist?**

- For example, Peter points out that we know from autopsy studies the prevalence of low grade prostate cancer that is not affecting any other issue

*Do we have similar autopsy studies in women where we’re looking at women who have died from some other cause and examining breast tissue and looking for the prevalence of all of these associated changes up into DCIS and LCIS?*

- Hal doesn’t have a good answer
- It’s certainly a common enough problem that it wouldn’t surprise him if someone has done a study of this and reported on it
- The distinction he would draw is those classic autopsy studies of men and prostate cancer is that we’re still talking about something a little different in the breasts (these are precancerous changes)
  - He believes the prostate studies were from automobile accidents

***Precancerous changes in breasts are not uncommon, and many of them will never move forward***

- These precancerous changes in the breast are different from breast cancer, where the tumor can be indolent, it can grow slowly
  - But we’re not so sanguine that these are tumors that would sort of never require treatment or never be a clinical problem for a patient

**Does every breast cancer start as a ductal carcinoma or lobular carcinoma in situ?**

- Many do, particularly hormone receptor-positive breast cancer
- Triple-negative breast cancers probably have something of a different cell of origin within the duct channel, a little less of the glandular component and a little more of the sort of architectural stromal element of the gland
- You will often encounter triple-negative tumors that *do not* have DCIS associated with it

***Probably the vast majority of hormone receptor-positive, ER-positive breast cancers emerge from these multi-stage evolution of these precancerous lesions***

**Is the majority of** [**DCIS**](https://en.wikipedia.org/wiki/Ductal_carcinoma_in_situ) **identified through screening mammography and/or other forms of screening in higher risk women where you’re using more than mammography, such as ultrasound or MRI?**

- That’s right
- 70 years ago, DCIS would present as a lump in the breast, because the cells would just kind of keep accumulating within the duct
  - Or [Paget’s disease of the breast](https://en.wikipedia.org/wiki/Paget%27s_disease_of_the_breast), where the cells would literally creep out of the nipple and sort of form what looked like a crust on the surface of the nipple or the breast
    - Which was again, the growth of these precancerous cells
- In modern practice, those still exist, but they’re really rare
- The vast majority of the time, DCIS is identified following a mammogram, because of calcifications or other subtle changes that appear on the mammogram

**How is DCIS staged?**

- DCIS by definition lacks an invasive component
- So DCIS is stage 0 breast cancer

![](https://peterattiamd.com/wp-content/uploads/2023/11/f2-haroldburstein.png)

**Figure 2. Cancer staging**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Cancer_staging#Overall_stage_grouping)

*Comparing DCIS to colon cancer*

- Hal calls it, “*A colon polyp of breast cancer*.”
- It really is a benign growth that we want to treat so that it does not become an invasive cancer
- The difference between the colon polyp, if people can sort of picture the little mushroom growing in the lumen of the colon, and the DCIS is that the DCIS cells are not as mushroom-forming, if you will
  - They can creep and crawl through the ductal space
  - So you can end up with a more diffuse distribution of the DCIS cells in the breast than you might encounter from an isolated colon polyp

**Once DCIS is identified, and assuming it’s done through a core biopsy, what are the next steps?**

- This is actually a really interesting area of research
- Hal will start by just saying what we typically do for most cases, and then we can talk about some of the areas of controversy
- For most women who have DCIS diagnosed on a core biopsy (because there were calcifications or other changes in the breast), the first step is to do an excisional biopsy
  - This is a surgical biopsy where the area of tissue is surgically removed
- A surgical biopsy is done for two reasons:
  - 1 – We want to remove the area of the breast that has DCIS.
  - 2 – There is some upstaging that happens
- About 15 to 20% of the time when a woman has a surgical excision of an area of DCIS, there will actually be a small component of invasive breast cancer adjacent to that space or nearby that’s removed as well, which upstages the diagnosis from stage 0 (or DCIS), to an early stage breast cancer
  - And it’s important to know that and to remove that affected portion of the breast

***A surgical biopsy is almost always the first step in treatment***

**If you discover that [a small component of invasive breast cancer adjacent to that space], do you also do a sentinel node biopsy?**

- A [sentinel node biopsy](https://en.wikipedia.org/wiki/Sentinel_lymph_node) is routinely done in invasive breast cancers because we want to find out if the cancer is spread to the axillary, the armpit lymph nodes [shown in the figure below]
  - Again, Hal’s surgeon friends who are still rolling their eyes as we’re talking here

![](https://peterattiamd.com/wp-content/uploads/2023/11/f3-haroldburstein.png)

**Figure 3. Anatomy of the breast and nearby lymph nodes**. Image credit: [Mayo Clinic](https://www.mayoclinic.org/diseases-conditions/atypical-hyperplasia/symptoms-causes/syc-20369773)

- In a sentinel lymph node biopsy, they can inject a radioactive tracer and blue dye into the breast tumor
  - They track that into the armpit
  - It allows them to identify the so-called sentinel lymph node or lymph nodes, which are hot from the radioactivity, and blue from the contrast dye
  - And you can find out by removing a couple of those nodes, whether the cancer has spread to the armpit
    - Which is really important staging information
- Peter asks, “*That’s going to be done in those 15-20% of women who are getting upstaged. You’re going to get a wet read in the operating room*.”
- You might, but usually not
- If you’re just having that lumpectomy where the portion of the breast is being removed and it’s not known to have invasive cancer ahead of time, if there is a finding of invasive cancer, then the patient would need to go back for a second operation to do the sentinel lymph nodes
- The exception to this is sometimes there’s a lot of DCIS in the breast
  - Or for whatever reason, the patient has chosen to have a mastectomy for DCIS
  - So this is necessitated sometimes by the extent of the affected area relative to the size of the breast
  - Some women will have diffuse changes in the breast that require a mastectomy, while others might have a personal preference for it
- If the whole breast is being removed for DCIS, then they will also do sentinel lymph node mapping of the lymph nodes in the armpit
  - Because once you remove the breast, you can’t go back post hoc and do the sentinel node mapping, if there is an occult area of cancer found within that area of DCIS
- Peter reasons, “*After they’ve had the excisional biopsy of the DCIS, you get the pathology back a week later, and it says in fact there is some invasive component here. You still have a compromised sentinel node biopsy at that time, I assume, because you’ve actually taken the tumor out, right?*”
- Harold explains, “*Presumably, the sentinel node’s doing its thing, and it’s still very feasible to do sentinel node mapping after an initial lumpectomy biopsy*.”
  - They know where the tumor bed was
  - You don’t have to inject the tumor itself
  - You’re tracking the lymphatic channels in that portion of the breast
  - So you can use the bed or the area

## Post-lumpectomy for DCIS: standard of care, future risk of cancer, and pros and cons of radiation and other preventative options [41:15]

**For the other 80-85% of women where no invasive cancer was found from surgery, what is the standard of care today?**

- Following DCIS removal, if you’ve had a [mastectomy](https://en.wikipedia.org/wiki/Mastectomy), usually that’s all you need
  - And there is no further treatment for DCIS
- For women who have had a [lumpectomy](https://en.wikipedia.org/wiki/Lumpectomy), then there are a couple of options that they can think about
- 1 – Radiation therapy
- One of the interesting things about DCIS as we noted earlier, is the cells tend to creep along the ductal channels
  - And these all arborize out throughout the breast space, and the cells can sneak around in there
- Radiation therapy has been shown in many, many studies to lower the risk of in breast recurrence, including both more DCIS, and including the development of invasive breast cancer
- For younger healthy women, 65, 70 and younger who have DCIS, it’s pretty standard to give a course of radiation therapy to the breast to lower the risk of recurrence of DCIS within the breast itself
- 2 – Antiestrogen therapy
  - Medicines like [tamoxifen](https://en.wikipedia.org/wiki/Tamoxifen) or [aromatase inhibitors](https://en.wikipedia.org/wiki/Aromatase_inhibitor), both of which work by depriving the tumor area of estrogen
  - It can also lower the risk of developing invasive cancer after DCIS
- The downside to those treatments is we usually recommend many years of therapy., and they have a lot of side effects (that are manageable for most women)
- Hal points out, “*But when you’re talking about a DCIS lesion, which isn’t a full-blown cancer, a lot of women wouldn’t be sufficiently interested in the couple of percentage points reduction in the risk of recurrence… for having to take a medicine for many, many years that has side effects related to its antiestrogen effects*.”

***The typical treatment would be a lumpectomy, a strong consideration of radiation therapy, and a discussion of antiestrogen treatments; and with that, most women do very, very well***

**When you get the pathology back, are you also getting the receptor status back on the DCIS?**

- They will test it for estrogen receptor
- And as with invasive cancer, the vast majority of DCIS lesions are estrogen receptor-positive, because it’s the precursor lesion for most breast cancers
- HER2/neu can be tested, but we usually don’t because it’s not clinically actionable (we won’t offer treatment)

**If you took all women who had DCIS who underwent a lumpectomy, and were found to only have DCIS (had no invasive cancer), and you did nothing, how many of those women will go on to get invasive breast cancer?**

- With breast cancer, the thing you want to know is, “*What does the DCIS look like under the microscope?*”
- Because one of the really important prognostic markers for both DCIS and for invasive breast cancer, is what we call a **grade**
- Higher grade, grade three DCIS lesions are often associated with what’s called necrosis
  - Which just means the cells are kind of dying in the ductal space because they’re outstripping the oxygen supply
    - There’s no blood vessels that feed DCIS
  - Those lesions have a slightly greater risk of in breast recurrence than would lower grade, typically more estrogen receptor-positive, less [comedonecrosis](https://en.wikipedia.org/wiki/Comedocarcinoma)-type lesions

***The span ranges from 5-10% at the low risk end, to 20-25% at the higher risk end without further treatment***

- With treatment, **with radiation therapy**, you bring way down the risk of recurrence of DCIS or of new breast cancer for both those kinds of lesions, such that it’s usually into the ***low single digits*** nowadays

**Does that reduce mortality also or just recurrence?**

- No; the interesting thing about DCIS is treating DCIS has actually never been shown to affect mortality
- Because you’re so far ahead of the diagnosis, that there probably isn’t a survival benefit
  - And this is what’s led to some really interesting trials looking at if we can do less for DCIS
- [Shelley Hwang](https://surgery.duke.edu/profile/eun-sil-shelley-hwang) (who’s a very distinguished breast surgeon at Duke) has really been a force in the development of these trials, where they are doing more or less what you proposed, which is what if you just took it out and followed it, and see what happens?
  - In some instances, they’re not even doing that excisional biopsy
  - They’re doing a core biopsy and saying, “*It’s just DCIS, we’re just going to follow you*.”
- Peter responds, “*Then they’re willing to miss the 10-15% of women that have invasive cancer*”
  - Correct
- Hal explains that’s an ongoing study in the NCI led cooperative groups
  - One of the things that can be really interesting is to see, is that really adequate?
- The other thing that comes into play here is one’s perception of risk
  - Because for some women, having a 10-15% risk over the next decade of having a recurrence or a breast cancer in the breast is a very low risk (85, 90% chance they would be fine), and they’re not eager to have more surgery or to have radiation therapy, and so they’re comfortable with that
  - Other women will look at the same number and are not comfortable with that
    - If you tell them that 3-4 weeks of radiation will lower their risk down to 1-2% chance of having a problem, they are willing to sign up and do the radiation treatment

***These become very nuanced discussions that have to reflect both the magnitude of the risk as we’ve been discussing and the possible benefit; the patient preferences become real important here***

**How well are radiation oncologists able to shield the heart, for example?**

*Do you find women making a different decision if this is left side versus right side DCIS? Or is the amount of radiation that’s delivered in this for DCIS, so low compared to say, invasive breast cancer, that it’s a non-issue?*

- The radiation treatments are fundamentally the same for invasive cancer and for DCIS
- In fact, one of the things that’s been persistently a confounding part of the discussion about DCIS, is that the treatments for DCIS look almost identical to the treatments for invasive breast cancer
  - If it’s a lumpectomy, it’s the same kind of surgery
    - You’re looking for negative margins, you’re talking about radiation therapy afterwards
- The issue of left and right, what you’re alluding to is the historic experience, which is that radiation therapy to left-sided breast cancers in the past (important point) was associated with a greater risk of coronary artery disease
  - And that is because in the early days of breast radiation, they would radiate the breast straight on, as though someone was standing in front of you shooting an arrow right at your heart (that’s where the beam of radiation was going)
    - For the past 30 years, we haven’t done that
  - What they do now for most things is what’s called [tangential field radiation](https://ro-journal.biomedcentral.com/articles/10.1186/s13014-015-0392-x#:~:text=Tangential%20field%20techniques%20usually%20consist,result%20in%20higher%20dose%20inhomogeneities.), where they very carefully map out the anatomy of the chest and the breast, and they use the radiation coming in from the sides in with tangent lines to the circle, to irradiate the breast tissue while sparing the underlying chest wall, lung, and particularly the heart

***So while any patient who gets breast radiation will be counseled as part of their decision-making process that there is a risk of accelerated coronary disease, in modern contemporary practice, that risk is incredibly low***

- It’s not just that they set up the fields differently, but now there are a lot of other tricks including specific blocks that radiation doctors can use
  - And what’s called a breath holding technique, where they synchronize the radiation treatment to holding the breath
    - So if you exhale, the heart moves closer to the breast, if you will
    - If you take a big breath in, the chest expands, the heart falls back, and you have more space between the breast and the heart
    - Nowadays they synchronize the radiation beam, which is a zap that moves at the speed of light, to your breath holding
    - So they say, “*Take a big breath in*,” and so the risk to the heart is extraordinarily low

**What are the other risks from radiation (skin damage, sickness)?**

- It depends a little bit on how much radiation is done, and where they have to go
- So if you have particularly a large breast cancer with extensive regional lymph nodes, then that’s where you start talking about doing more extensive radiation to the chest wall, the regional lymph nodes, sometimes even the internal mammary nodes
  - And there, while they can still spare the vast majority of the heart, it becomes a little trickier to fully avoid the heart
- There is a risk of so-called [pneumonitis](https://en.wikipedia.org/wiki/Pneumonitis), inflammation of the lung from some of the radiation scatter
- There is a risk of **secondary skin cancers**, which you can *rarely* see after the radiation

*There’s a lot of short-term side effects*

- Getting the radiation treatment is like having a bad sunburn
  - Or as we say in Boston, “*A wicked bad sunburn on the breast tissue itself, where the breast gets red, sore, swollen*.”
  - It accumulates during the course of the radiation, just as a sunburn accumulates during your day at the beach
  - That can be very physically uncomfortable, but over time, the skin heals
    - The tissue fades from a lobster red, to a pink, and then to a tan color, and eventually back to normal skin tone

**What percentage of DCIS are estrogen receptor-positive?**

- Something like 80%, the vast majority

**What is the natural history of ER-positive DCIS, with and without estrogen blockade in terms of recurrence?**

- Estrogen blockade helps lower the risk further beyond what radiation does
- One of the cleanest studies we have of this is a study called [NSABP B-24](https://pubmed.ncbi.nlm.nih.gov/10376613/), which is an old study [published in 1999]
  - And in that study, it built on a previous study called [B-17](https://pubmed.ncbi.nlm.nih.gov/9469327/)
  - B-17 randomized patients to surgery alone for DCIS, lumpectomy alone, versus lumpectomy plus radiation
    - And in that study at 10 years, about 25-30% of the women who had surgery alone had had a recurrence or second cancer of DCIS or invasive cancer in the breast
    - Radiation cut that in half to about 12-15%.
  - Then in the follow-on study B-24, they did lumpectomy plus radiation with or without tamoxifen
    - And again, it lowered the risk further by about half again
- The dilemma there is that that study is old enough that we’ve gotten much more sophisticated in terms of the imaging we offer to the breast: looking at the margins very carefully, making sure there’s no extraneous calcifications
- So most people think that the baseline risk after surgery alone nowhere approximates that 25-30% number anymore
  - It’s much lower for most patients who have mammographically detected DCIS

***The rules apply: radiation drops the risk of recurrence by half and then tamoxifen drops the risk by another half; but the absolute benefit is a lot smaller because the baseline risk is no longer way up here***

- Hal explains, “*For that reason, the marginal benefits of the antiestrogen* *approaches are something on the order of 3-5% in terms of preventing a recurrence*.”
  - And some of that benefit actually relates to the prevention of a second problem in the opposite breast, because the drug therapy obviously affects both breasts
    - And so you can help prevent a new cancer in the opposite breast, which adds a percentage point or two of the benefit

***It’s a relatively small gain to be using antiestrogens after DCIS***

- For some patients, it clearly makes sense because of the extent or other features of the tumor
- Some will pursue it because they like the idea of the secondary benefit in the opposite breast
- Many women will pass on the antiestrogen therapies, even as they receive other treatments for DCIS
- Hal points out, “*One of the academic questions is, can you use the antiestrogens instead of the radiation?*”
  - That’s part of other studies that are going on, where women might get surgery for the DCIS, then be put on antiestrogens without the radiation, and we’re going to see in the modern era if that’s an acceptably beneficial approach
- Peter thinks a lot about hormone replacement therapy and what tamoxifen does to women, especially premenopausal
- He’s amazed that that’s the more interesting academic question, when the radiation is getting safer and safer, and more and more efficacious
- It seems to Peter that the real jugular question is, “*How long can we justify giving tamoxifen to women with DCIS, given the really devastating consequences?*”
  - It’s basically putting women into menopause at a young age, depriving them of estrogen
  - We think about the long-term consequences on their bones, the vasomotor symptoms, the sexual side effects
- We’re talking about a 3-5% reduction of recurrence over a decade with no change in mortality
- It’s interesting to hear that the majority of women do *not* elect for that
- It sounds like the majority of women say, “*I’ll take my lumpectomy, I’ll do a little bit of radiation, but I’m not going to take tamoxifen for five years.*”
- Hal agrees, it’s part of a comprehensive discussion, and many women don’t elect to take tamoxifen
- Nowadays, in addition to the safer features of the radiation therapy, we’re now offering shorter durations of radiation treatment
  - Historically, the standard was 25 fractions
  - We’re now down to 16 fractions for most women
  - And in Europe and increasingly in the US, there’s interest in looking to at yet shorter courses of radiation down to about 5 days of treatment
    - For many women, that would be great news

## Lobular carcinoma in situ (LCIS): how it differs from DCIS in terms of treatment and future risk of invasive cancer [55:00]

**Lobular carcinoma in situ (LCIS)**

- Peter remembers when he was in medical school, [LCIS](https://en.wikipedia.org/wiki/Lobular_carcinoma_in_situ) was much less frequent than [DCIS](https://en.wikipedia.org/wiki/Ductal_carcinoma_in_situ)
  - It was more of a systemic concern, that your risk of contralateral breast cancer was high
  - At one point they were recommending bilateral mastectomies for LCIS
  - He knows this can’t be right anymore
- Hal agrees, that’s not an approach we would endorse today

***LCIS is probably best thought of as a field risk marker***

- It’s one of those things that you might’ve talked about in other contexts like [leukoplakia](https://en.wikipedia.org/wiki/Leukoplakia) in the throat, which increases the risk of developing head neck cancers or other field defects
- Clearly the diagnosis is saying this patient is at greater risk for developing cancer
- Historically, the teaching was that actually the risk was the same in each breast
- With very large studies, there’s probably a slightly greater risk in the affected breast itself
  - There’s probably something specific and a little bit clone going on there, but it can increase the risk of a second breast cancer as well

***What we usually offer patients like that [with LCIS] is very close monitoring, and many of those women will consider antiestrogen therapy to lower their risk of developing breast cancer***

**Treatment for LCIS differs from DCIS**

- LCIS is not a lesion that is readily thought of as one you treat with surgery alone or surgery plus radiation
  - So that’s an area where LCIS management diverges from DCIS management

**For all radiographically suspicious lesions that go down this pathway, what’s the distribution of LCIS versus DCIS?**

- LCIS is about 20% of the diagnoses compared to DCIS (that’s a ballpark figure)
  - Roughly 4 to 1, DCIS to LCIS

**Are there any differences demographically?**

*Are we seeing more LCIS in older women, younger women?*

*Different changes in estrogen receptor status, anything like that?*

- No
- LCIS is almost universally a hormone receptor-positive, estrogen receptor-positive lesion
- There’s a rare entity called **pleomorphic LCIS**, which is a pathologic diagnosis
  - That’s a more virulent flavor of perhaps LCIS, and certainly of a lobular breast cancer, polymorphic lobular breast cancer
  - But otherwise, it’s the same kinds of demographic trends that we’ve been alluding to

**Do we know the natural history of the progression of LCIS to invasive cancer and how it differs?**

*Peter realizes it’s more of a global marker of risk within the breast (as opposed to a local marker), but is it also a higher risk that breast cancer will occur?*

- Yeah, so LCIS along with those things we alluded to earlier (like atypical ductal hyperplasia, atypical labial hyperplasia) is sort of a **pre-precancerous lesion**, and it does increase the risk of eventually developing breast cancer
- We have some very good data from the [NSABP](https://www.nsabp.org/about-us/the-foundation/)
  - Disclosure: Hal worked with the NSABP as a chair of one of their data safety and monitoring board, so he knows their data pretty well
    - He doesn’t have any other commercial conflicts of interest
- They did a study called the [P-1 study](https://pubmed.ncbi.nlm.nih.gov/9747868/), which was a prevention study [published in 1998]
  - The goal of this study was to see if tamoxifen could lower the risk of breast cancer diagnosis in women who were at intermediate to moderate risk of developing breast cancer
  - They included a lot of women who had lobular carcinoma in situ, and those women were at greater risk of developing breast cancer
  - To be quantitative about that risk, there was a rate of 13 per 1,000 women per year
  - And tamoxifen cut that in half down to about 5-6 per 1,000 women per year
    - So it makes a few percentage points difference as a preventative agent

***The key point here is the absolute risk for developing breast cancer in any given span of time is still pretty low following a diagnosis of LCIS, but those patients do warrant monitoring (obviously mammography) and they can consider antiestrogens to help lower that risk***

**More about the** [**P-1 study**](https://pubmed.ncbi.nlm.nih.gov/9747868/)

- This study took women who were at high risk because they had a family history of breast cancer or because of atypical hyperplasia (there was a whole algorithm that went into the risk assessment) but not yet diagnosed with breast cancer
- Women took tamoxifen for 5 years versus a placebo

*Did it reduce the absolute risk of occurrence of breast cancer by less than 1%?*

- The overall diagnosis of breast cancer in that study was about 4% through 5 years of follow-up, and tamoxifen cut that in half to about 2%
  - So the drug “works”
- For women who are at higher risk or who are very motivated, tamoxifen and subsequently other antiestrogens have been shown to lower that risk of diagnosis
- But for most ordinary women, that risk is sufficiently low that the relative reduction only amounts to 1-2%, so it’s not an approach that has been enthusiastically embraced by most general population patients

*Did that reduction in risk translate to a survival benefit or just an incidence?*

- It did not, for a couple of reasons
- 1 – The risk is really low (obviously)
- 2 – We have good treatments for those women who do develop breast cancer
- 3 – If you’re using tamoxifen as a preventative, arguably you’re preventing the most treatable types of breast cancer from arising
  - So you’re pulling out the better actors, if you will, and what’s left are tumors that remain somewhat resistant to the antiestrogens, and therefore more worrisome
- Peter’s reaction, “*The thought that 98 out of 100 women are unnecessarily exposed to tamoxifen for 5 years, to save two cases of breast cancer that doesn’t translate into any survival benefit.*”

> “*One of the frustrations for people who are really interested in cancer prevention has been that for most people in any given span of time, the risk of developing a cancer is pretty low.*”‒ Harold Burstein

- Even in the P-1 study, which sought to enrich for a group of women who are at slightly greater than average risk of breast cancer, the absolute benefit turns out to be modest
- And it’s been a drug [tamoxifen] that only the most motivated patients would be inclined to pursue
- Peter worries that some of the women in this study might not know what they’re signing up for
  - It really places the onus of really capturing a great consent with the physician
- Peter knows a number of women who have taken tamoxifen for DCIS, and a year in, they’re calling him asking, “*What the hell is going on? Is this really necessary?*”
  - He walks them through the math and tells them to talk to their oncologist because no doctor can predict how badly you will have side effects
    - Some women probably take tamoxifen, and it goes off without a hitch
- Peter thinks it’s worth revisiting that discussion with your physician saying, “*Look, I’m 1 year into a 5-year course, I’m premenopausal, and this drug has ruined my life.*”
  - He doesn’t think any doctor would advise that woman to keep taking the drug
- Hal agrees, this is a great point, and he adds:
- 1 – This is a very nuanced conversation, and we’re living at a time where it’s often hard for clinicians to find the time to have these kinds of very detailed conversations with patients ‒ it’s important that they talk to people who will invest the time to speak about that

- 2 – There will be patients for whom taking this medicine is really important, and they feel very reassured by it
  - And for many, it will be a different decision
- 3 – Hal doesn’t want us to demonize antiestrogen medicines too much
  - They clearly have side effects

***But in terms of global health, tamoxifen and other antiestrogens have cured more people of cancer than anything else we do in oncology, aside from surgery itself***

- These are really important medicines from the global battle against breast cancer
- We spend a lot of time in the clinic addressing the side effects, and talking about them, and alerting patients to them, and managing them, but these remain really important medicines for **invasive breast cancer**
  - For **pre-invasive cancers (like DCIS) and for precancerous lesions**, it’s been a more complicated area to discuss, because *the benefits look pretty small* to most people

## Breast cancer screening: mammography, ultrasound, MRI, and more [1:03:45]

**Anything else you want to say about DCIS or LCIS before we start to talk about invasive breast cancer?**

- The reason we make diagnoses of DCIS and LCIS is often because of [mammography](https://en.wikipedia.org/wiki/Mammography)
- One of the critiques of mammography (which is important to acknowledge) is that when you have a national screening mammography program, you’re going to see an *upsurge in the cases* of DCIS and LCIS
  - And this has led some to question whether we’re over diagnosing cancer on mammography ‒ it’s part and parcel of the same thing
- For the cancers where we have **successful screening programs**, one way they work is because they allow you to diagnose pre-cancerous conditions
  - So fundamentally, that’s what a Pap smear does
    - A Pap smear is looking for obviously cervical cancer, but it’s also looking for the pre-cancerous changes that you can identify on the Pap smear
  - A colonoscopy is a very effective screening tool for colon cancer, because it allows you to both treat the lesion, the polyp, which is the precancerous one, and identify those who are at risk for more of them, so they get more frequent screening
  - You do diagnoses of skin lesions at your dermatologist’s office, and some of them will be benign and others will be skin cancer
    - But you’re going to have an uptick in these pre-cancerous findings as well

***That is the nature of a successful screening program: you are finding precancerous lesions***

- The debate as it relates to breast cancer is, how much treatment should we offer in these precancerous instances?
- That’s why there’s more DCIS and LCIS, and it is a natural consequence of a successful screening tool for the tumor

**Add in a word on ultrasound and MRI**

- Peter brings it back to our prostate analogy: the workhorse of prostate cancer screening is the PSA
  - It’s not an apples to apples comparison, because that’s not an imaging test
  - PSA by itself, really lacks the specificity to be a high yield tool, and in many cases is being abandoned
    - This is unfortunate because it can be used when you look at the density and velocity of PSA
  - Instead, high risk patients are being more quickly sent for MRI (a multiparametric MRI)
- Peter assumes a very similar phase of MRI is being used in breast cancer to provide a high quality image, T1 and T2 weighted image, along with diffusion weighted imaging and the use of contrast as well
- In the case of prostate, this is scored with a RADS score that ranges from 1 to 5, and that’s where the radiology can sort of assign a probability of suspicion

*Can you talk a little bit about how ultrasound and MRI work for breast cancer and how they sharpen the resolution in the screening stage?*

***The screening tool that’s most important is the mammogram, and that is supplemented by sort of an awareness of one’s own body***

- Interestingly, just teaching women to find a lump and go see a doctor has in many developing countries has actually lowered the fatality rate of breast cancer because it allows early detection ‒ so awareness of the body matters
- When we’re talking about **screening mammography**, what they’re looking for are architectural changes, irregularities, calcifications that might be a sign of an invasive cancer and that’s the gold standard for most folks
- The mammogram is not a perfect tool
  - It’s hard to exactly position the breast correctly
  - It depends a lot on a radiology technician to do a good image and the mammography radiologist to interpret it correctly
    - A correct comparison back and forth from the older images to the newer ones
  - And sometimes the breast itself can be difficult to view because of breast density or other features in the breast
  - And that’s where other imaging can be helpful
- Occasionally people may need an [ultrasound](https://en.wikipedia.org/wiki/Ultrasound) to support a mammogram finding
  - It’s not a reflex per se and it’s not universally recommended
  - In fact, studies have not really shown that ultrasonography dramatically improves the outcomes if you are found to have breast cancer
  - But in some women who have denser breast tissue or other suspicious findings, it’s a pretty routine thing
- [MRI](https://en.wikipedia.org/wiki/Magnetic_resonance_imaging) is a very sensitive tool for finding abnormalities in the breast
  - It does not replace the need for a mammogram
  - But for women who are at very high risk of getting breast cancer, classically, these are women who have strong family histories or who have a known hereditary predisposition like a [*BRCA1/ BRCA2* mutation](https://en.wikipedia.org/wiki/BRCA_mutation)
    - MRI is very important for early detection of cancers and is routine for those women, but not for the general population

**Does the mammogram have a similar score to radiographic scoring where you have a RADS score of 1, 2, 3, 4, or 5?**

- Correct
- These are definitions put forward by the academic radiology community and they’re widely used in clinical practice; they call it a [BI-RADS score](https://en.wikipedia.org/wiki/BI-RADS)
  - They range from zero (which is there’s nothing of concern) to 5 (which is oh my gosh, that looks like a cancer), and in between is a gradation and there are very well done standards of what those gradations mean
- The breast imaging has become very sophisticated and at large centers they focus a lot on the quality of the imaging and the review and all of them are required to maintain their data
  - And they know if you had a BI-RADS 3 how many of them eventually became a breast cancer within a couple of years versus not
    - There are accepted standards for what all this should mean
    - It’s sort of like the aviation industry: they’ve gotten really good at quality control and safety measures and it’s really a very refined and sophisticated field of clinical care

**Back to the comparison with prostate cancer**

- MRI has changed prostate cancer diagnoses
- The data exist where if you know the PSA, PSA density, and PI-RADS score, you have a complete distribution wf whether or not there’s no cancer present
  - A Gleason 3+3, you’ll watch and wait
  - A Gleason 3+4, it needs to come out
  - A Gleason 4+4, it should have come out last year
  - You know this a priori before you biopsy

**Does that level of resolution exist with the combination of Bi-RADS and any other factor (the mammographic insight or parameters of family history)?**

- The short answer is no

***The guiding force of breast cancer management is really what the tissue biopsy defines***

- The finding on the mammogram screening, the imaging itself, doesn’t tell you as much as you would like to know
  - There are a few overarching pearls, you can say, slowly evolving lesions tend to be hormone receptor-positive and those tend to have a better prognosis
  - Things that pop up quickly tend to be more virulent or proliferative lesions, which have a less good prognosis
  - But those are not standard markers of risk that you would use to judge what therapy a patient needed

## Invasive breast cancer: pathology report, surgery, and survival [1:11:00]

**What fraction of women that show up with something suspicious (from mammography and/or follow-up imaging) and have a needle biopsy turn out to have invasive cancer?**

- It depends a lot on what the abnormality is
- If you have a BI-RADS 4 lesion, the radiology team is signaling that’s a very suspicious lesion that should have a high chance of being DCIS or invasive breast cancer
- BI-RADS 3, it’s probably (Hal forgot the exact number) less than 5% chance that that’s a malignant lesion
  - There’s that gradation within there
  - And different groups have different thresholds internally and about what gets biopsie

> “*The message to share with patients or people in the general audience would be that a lot of the time, even if there’s a so-called callback for a mammogram finding and the mammogram team wants to do additional imaging or there’s even a recommendation for a biopsy, a lot of the time these will still be for precancerous or even benign lesions and it doesn’t automatically mean that the patient has breast cancer*.”‒ Harold Burstein

**What is the number of breast cancer cases in the US per year?**

- 250-300,000

*Is that just invasive? That doesn’t include any of the DCIS or LCIS cases, correct?*

- Correct
- There’s a ballpark of another 50-60,000 cases of DCIS

**Walk us through the diagnostic and staging procedure for a woman who on that core biopsy, the pathologist identifies invasive cancer**

- The core biopsy is very helpful for both defining (1) what the diagnosis is:
  - Is it precancerous? Is it DCIS? Is it invasive breast cancer?
- And then (2) they would also comment on the [grade](https://en.wikipedia.org/wiki/Breast_cancer_classification#Grade)
  - So the grade is judged as grade 1, grade 2 or grade 3
  - Grade 3: the cells are kind of growing wildly and sort of all over the place
  - Grade 1: the cells tend to still form structures that are recognizable as glandular structures
  - The analogy here would be to a Gleason score, it’s not quite a one-to-one analogy, but the higher the number, the more sort of abnormal the cells are
- (3) They would also do biomarker testing for those three markers we alluded to at the beginning: estrogen receptor, progesterone receptor, and HER2

*Is there anything else that they look at there or is it just those?*

- There are a lot of things they can look at
- They also sometimes comment on the proliferation rate by using a test called the [Ki-67](https://en.wikipedia.org/wiki/Ki-67_(protein)), which is a proliferation measure
- They can also comment on whether or not [tumor-infiltrating lymphocytes (TILs)](https://en.wikipedia.org/wiki/Tumor-infiltrating_lymphocytes) are present
  - That is a *favorable* prognostic marker in triple-negative breast cancers in particular
- They will comment on whether or not lymphovascular invasion is present
  - Sometimes they can see the cancer cells sort of burrowing into a blood vessel or a lymphatic channel, and that is a marker of somewhat *greater risk* of the breast cancer
- Those are things you can all see on the core biopsy, and then those same tests are typically redone at the time of the definitive surgery (especially if you’re at a different institution)

**Is the definitive surgery here always going to be a modified radical mastectomy or is there any situation where the lump is small enough that you will just do a lumpectomy with sentinel node?**

- The good news here is that for women who have early detection of breast cancer, the majority are going to be candidates for so-called breast conserving surgery, also known as a [lumpectomy](https://en.wikipedia.org/wiki/Lumpectomy)
  - Only the affected portion of the breast is removed, the rest of the volume of the breast is left intact
- The next definitive surgery for most women would be a lumpectomy where the affected portion of the breast is surgically removed, and at the same time, the surgeon would typically do a sentinel lymph node biopsy
  - So they would look into the armpit, remove a couple of lymph nodes, one, two, three, and see if there’s cancer in those lymph nodes
  - And then you’ll have the full stage information
- For some women, there is still discussion about a [mastectomy](https://en.wikipedia.org/wiki/Mastectomy)
  - That may be because of family history or genetics
  - It might be because of personal preference
  - It might be because of the size of the tumor relative to the size of the breast is such that a lumpectomy isn’t adequate for achieving a cosmetic result that people would think is acceptable or maybe that there’s sort of diffuse changes throughout the breast that require it
  - So it’s very individualized at that point

**Walk through the TNM staging just so people get a sense of what are the three big things that are driving prognosis because now we’re going to put people into four stages (I, II, III, and IV) with some As and Bs thrown in there**

- As with all cancer staging, **stage IV** is metastatic, or cancer that is spread beyond the tissue of origin
  - In breast cancer that means there’s a breast cancer, but it is spread to the bone, the lung, the liver, those kinds of organs (metastatic disease)
- **Stage I**, at the other end of the spectrum, is a tumor that is 2 centimeters or smaller
  - That’s about the size of a nickel or smaller and the lymph nodes are negative
- **Stage II** includes slightly bigger tumors (bigger than 2 cm) and/or involvement of some of the axillary, the armpit, lymph nodes
- **Stage III** is a progressively larger cancer and similarly affecting more lymph nodes

> “*Lymph node involvement is the biggest single prognostic marker for early stage breast cancer, by which we mean not involving some other organ elsewhere in the body*”‒ Harold Burstein

- There’s a relatively sharp cut between node-negative tumors and node-positive cancers
  - All of it’s really a spectrum
- Breast cancer is really interesting, if you have a big enough study, a 1 cm cancer is less risky than a 1.5 cm, which is less risky than a 2 cm, which is less risky than a 2.5 cm and so forth
- There’s another axis that goes by nodal status
  - Node negative is less risky than 1, 2, 3, 4 ‒ it’s all very linear
- And then finally, there’s a third dimensional access about the biology of the tumor where **triple-negative cancers** (again): ounce for ounce, size for size, will have a more aggressive natural history
- **HER2-positive tumors** historically were also a very aggressive tumor
  - Now, we have some of our most successful outcomes with treatment of HER2-positive cancers
- Within the large group of **ER-positive, HER2-negative cancers**, the risk depends on some of these biomarkers (like grade, so low grade, intermediate grade, higher grade), how robust the expression of the estrogen receptor is
- Nowadays, we also use so-called **genomic tests** like the [Oncotype DX recurrence score](https://precisiononcology.exactsciences.com/healthcare-providers/treatment-determination/breast-cancer/oncotype-dx-breast-recurrence-score) to understand for that large group of cancers how risky they are and whether they warrant chemotherapy

***It’s sort of a three-dimensional axis of the tumor size, the nodal status and then these biological features, all of which are likely to affect risk of recurrence***

- Peter clarifies for the listener, “*It’s important that they understand that all of that is in the M0 case, the non-metastatic case. So all bets are off when we have metastatic disease, the prognosis is awful.*”
- Hal explains that the prognosis is different, but not awful
- There are women who are living a long time nowadays with **metastatic disease**
- We even occasionally think we might cure some people with metastatic disease, though that’s not usually the goal going into it, it’s only in the fullness of time

**What fraction of women today would live 10 years?**

- A very small percentage and largely in this group of **HER2-positive breast cancers** where we think we have very effective therapies these days
- Hal explains the big difference, “*Is the tumor still confined to the breast and the lymph nodes?*”
  - So that with a combination of surgery and radiation therapy to the chest and then drug therapy to prevent recurrence either in the chest or anywhere else in the body, we can cure the cancer or at least aim to achieve a cure for the cancer
  - As opposed to that stage IV distinction where it has spread to other important organs
    - Where usually we don’t actually speak of curing the cancer, we speak of managing it, treating it, keeping it at bay for a long time
    - And there’ll be women who will live for years and years and years with advanced or metastatic breast cancer: that’s the separation between functionally stage III and 4

**What is the median survival today for stage IV breast cancer?**

- About 5 years
- It depends again on the subtype of the breast cancer
- For **triple-negative breast cancers**, it’s more modest
- For **HER2-positive breast cancers**, it’s actually moving further and further out beyond that

**Explain the distinction between stage II and stage III. Is it more separated by the number of lymph nodes or the size of the primary?**

- It’s both
- If you have a large tumor bigger than 5 cm, that becomes a so-called T3 cancer
  - And if you have T3 cancer with any degree of nodal involvement, that becomes a stage III breast cancer
- If you have 4 or more positive nodes, regardless of the extent of the size of the tumor, that’s stage III
- If you have involvement of the [supraclavicular nodes](https://en.wikipedia.org/wiki/Supraclavicular_lymph_nodes), that’s stage III
- And so you got to sort of get the grid out and look up all the criteria

**Can you give me full survival? So not 5-year, not median, but 10-year actual cure rate for stage I, II, and III?**

- The [American Cancer Society](https://cancerstatisticscenter.cancer.org/#!/cancer-site/Breast) updates these statistics every year (shown below)

![](https://peterattiamd.com/wp-content/uploads/2023/11/f4-haroldburstein.png)

**Figure 4. Breast cancer statistics for 2023**. Image credit: [American Cancer Society](https://cancerstatisticscenter.cancer.org/#!/cancer-site/Breast)

- In ballpark terms, for **10-year cancer-free survival**:
  - Stage I: often on the order of 90% or more
  - Stage II: 75-80%
  - Stage III: 65-75%
  - And again, it depends a lot on not just the stage, but on the biology of the tumor and the kinds of treatments that people get

**The grade (1, 2, 3 grade) on pathology, that doesn’t factor into any of the staging. Is it more of a subtle issue that comes in where you are thinking about different chemo regimens?**

- There is a staging criteria that factors in things like grade and that can be used in some of the more up-to-date [American Joint Commission on Cancer’s staging criteria](https://www.facs.org/quality-programs/cancer-programs/american-joint-committee-on-cancer/)
  - They do look at some of the things like grade
  - Usually though, it’s less discussed because it mostly relates to the outcomes in **ER-positive breast cancer**
  - So **triple-negative breast cancers** are almost always grade 3
  - Most **HER2-positive breast cancers** are grade 2 or 3, and they all get treated with the [trastuzumab drug](https://en.wikipedia.org/wiki/Trastuzumab)
- It’s really in that gradation of the **vast majority of cancers** (the ER-positive ones) where low grade clearly does a lot better than higher grade cancers and needs different treatment approaches

## The argument for aggressive screening for breast cancer [1:22:15]

**Aggressive screening**

- Peter has had many disagreements with people over the years when it comes to arguments around aggressive screening
- To him, one of the most compelling arguments for aggressive screening of breast cancer (let’s just limit it to breast cancer) really is explained by what you just said coupled with another observation
  - Which is if you catch a breast cancer that is 2 cm or smaller without lymph node involvement, the chances that you will be cured (which we use as 10-year remission) is 90-95%
  - And without exception, the larger the tumor is at presentation and the greater the lymph node involvement, the lower your survival
  - And of course, if it spreads beyond the breast, let’s not mince words, there is no long-term survival
  - We also know that when we give women chemotherapy in the *adjuvant* setting (Hal will explain what that is in a moment), and we give virtually the identical chemotherapy for women in the metastatic setting, the survival difference is profound
    - It’s a huge difference, suggesting that tumor burden must matter
  - ***All of this is a long-winded way of saying the better we are able to identify breast cancer early on, the better we are at curing cancers, which acknowledges you will catch more cancers***
    - In other words, you will increase the size of the pool of women who have cancers, there will be lead time bias, all of those things will be true, but ultimately it seems mathematically by definition, ***you are also going to cure more women of cancer because you will shift the risk pool towards stage I tumors***

*Do you agree with that?*

- Hal does, and most people who take care of breast cancer patients would very much agree with that
- There is still debate as to how valuable screening could be
- It’s a complicated subject in the sense that most of the studies that were done showing screening was valuable were concluded by the late 1980s
  - They showed that screening did contribute to improvements in mortality
- Since then, the therapy for breast cancer has gotten a lot better, which arguably cuts both ways
  - On the one hand, it means that it minimizes some of the benefits of early detection because you’re not just cutting it out and you are able to treat metastatic or systemic disease, which is ultimately the life-threatening part of breast cancer and prevent recurrence
    - Which on some level diminishes the value of early detection
  - On the other hand, early detection is clearly still associated with better long-term prognosis
    - The drugs are more effective, or you can use the same drugs or fewer drugs when the tumor is smaller to get better results
- All of us who are in the cancer community feel strongly that mammography is a very important tool
- Not to take us away from thinking about how we treat in the United States, but as you may know, breast cancer is now the most common diagnosis of cancer (aside from non-melanoma skin cancer)
  - It’s the most common cancer diagnosis in the world for almost all countries on earth
  - It’s more commonly diagnosed than lung cancer
    - The outcomes for breast cancer are better
    - There are still more fatalities from lung cancer
  - There are still some places in sub-Saharan Africa where there cervical or other gynecologic tumors outpace breast cancer, but almost everywhere else, it’s the number one diagnosis of cancer in women, and in total, it’s the largest cancer diagnosis
- From a global health point of view, breast cancer is becoming a huge issue for countries that historically we’ve not thought of cancer as a big driver of mortality in
  - And this relates to the welfare advances in many countries around the world as they’ve been becoming more affluent, better nourished, and becoming more western in that sense that they now have cancer problems that are looking more and more like the kinds of cancer issues that we see in the United States and Western Europe and other developed countries

> “*The importance of mammography globally is growing, not shrinking. And one of the challenges is there are simply insufficient medical manpower/ womanpower to adopt widespread screening programs in many parts of the world right now.*”‒ Harold Burstein

- There’s been a lot of really cool artificial intelligence research to suggest that you can look at breast imaging perhaps even in the future without a radiologist to begin to identify women who warrant either more detailed evaluation or other diagnostic workup
- But this is going to be a huge problem in the coming decades as breast cancer spreads to really become a global disease

## Advances in the treatment of breast cancer, adjuvant therapy, and neoadjuvant therapy [1:27:00]

- A woman comes out of the definitive procedures (a lumpectomy with a sentinel node biopsy), and the sentinel is negative
  - She will not undergo a formal lymph node dissection
- She is told she had stage I breast cancer

**Is she receiving effectively the same treatment as the DCIS woman where she’s going to get radiation for local control and then, depending on the receptor status, she’ll either get tamoxifen (if it’s ER-positive), Herceptin (if it’s HER2/neu-positive), is there any treatment beyond that?**

- Hal points out, “*That’s a very common problem.*”
- In the United States, the most common presentation of breast cancer is of a stage I breast cancer found on a mammogram, which has a very good prognosis after surgery
- Almost all patients will be candidates for some type of what we call **adjuvant therapy**
- [Adjuvant therapy](https://en.wikipedia.org/wiki/Adjuvant_therapy) are treatments that are designed to help prevent a recurrence after surgery
  - It’s not unique to breast cancer
  - We use adjuvant therapy in colon cancer and in some sarcomas and in certain prostate cancers and in other kinds of cancers as well
- Sometimes patients ask, “*Well, why do I need extra therapy? After all, the surgeon got rid of the tumor*.”
  - It’s a good question when you think about it
  - The answer is that we worry about the possibility of **microscopic disease** that might be somewhere either in the breast or chest area or might have snuck away somewhere else in the body itself
  - So we use additional therapies to mop up those microscopic bits of cancer
- One of those is the **radiation therapy** (discussed earlier)
  - The majority of women who are 70 and younger and who are vigorous and healthy, who have early stage breast cancer are going to be advised to get radiation therapy
  - Many women in their 70s and even older will have to think about radiation treatment, depending on the type of cancer they have, their overall health status, and fundamentally as a ballpark term you might say, whether they have a 10-year life expectancy or not such that radiation is likely to be of some value to them in preventing recurrence over the next decade
- The vast majority of patients are going to be candidates for some form of **drug therapy**

*What has really changed breast cancer mortality (beyond the surgery itself)*

- 1 – Early detection through mammography
  - That’s reduced the mortality from breast cancer over the past 30, 40 years by about half
- 2 – Effective systemic therapy
  - That has given us the other half of improvements in mortality that we’re seeing in the United States over the past 30 years
- For cancers of almost any size that are **estrogen receptor-positive**, we think about antiestrogen medicines like [Tamoxifen](https://en.wikipedia.org/wiki/Tamoxifen) or [aromatase inhibitors](https://en.wikipedia.org/wiki/Aromatase_inhibitor)
  - We go through a process where we decide whether or not the patient needs chemotherapy
    - That usually involves an [Oncotype DX recurrence score](https://precisiononcology.exactsciences.com/healthcare-providers/treatment-determination/breast-cancer/oncotype-dx-breast-recurrence-score), the [MammaPrint Assay from Agendia](https://agendia.com/mammaprint/) or a similar **genomic test** done on the tumor itself where they look at the patterns of gene expression in the tumor
    - Those studies have shown us that scores on this genomic test are very powerful at figuring out who does and more importantly, who does not need chemotherapy
- For tumors that are as small as a 0.5 cm or more in size, we think about drugs like [trastuzumab](https://en.wikipedia.org/wiki/Trastuzumab) that target HER2
  - Most women with **HER2-positive cancers** also get chemotherapy with that trastuzumab
  - As the tumor gets bigger and riskier, we amp up with more anti HER2 drugs and more chemotherapy
- Similarly for very small **triple-negative breast cancers**, we often think about chemotherapy
- There’s been a huge shift in how we use chemotherapy in **ER-positive breast cancers** over the past 25 years
  - From the time in 1999, when the NCI said every woman who had a 1 cm cancer needed chemotherapy, to a time nowadays when we frequently can avoid chemotherapy for most ER-positive breast cancers
    - But certainly those that are node-negative and many of the ones that are node-positive as well because we understand that based on this genomic test, the chemotherapy is just not going to help them do better in the long run

**Hal’s summary of breast cancer treatment**

- To circle back, surgery is the [sine qua non](https://en.wikipedia.org/wiki/Sine_qua_non)
- Following the surgery, we use radiation therapy to sterilize the breast and chest area
- And then the majority of women will need to think about some kind of drug treatment
  - Which could be chemotherapy, antiestrogen therapy, targeted drugs, sometimes immunotherapy to help prevent a recurrence anywhere else in the body

**Explain the distinction between chemotherapy and some of these other therapies**

- Peter points out, “*A lot of people sort of hear any systemic therapy is “chemotherapy,” but you’ve made a great point to distinguish between the antiestrogen therapy (tamoxifen, anastrozole, things like that), Herceptin (which is a targeted therapy) versus “chemotherapy*.”
- We’ve talked about the several different kinds of breast cancer, and nowadays, we have a different treatment paradigm really when it comes to the drug therapy for each of these different types of tumors
- For **ER-positive, HER2-negative breast cancer** (the most common kind) the most important drug therapy relates to antiestrogen medicines
  - There are two basic flavors in the early stage: [tamoxifen](https://en.wikipedia.org/wiki/Tamoxifen) and the other is called an [aromatase inhibitor](https://en.wikipedia.org/wiki/Aromatase_inhibitor)
  - These are each pills, they work by different mechanisms
- Tamoxifen sort of blocks estrogen’s ability to reach the estrogen receptor in the cancer cell
- Aromatase inhibitors only work in *postmenopausal women* and they block the production of estrogen by non-ovarian tissue.
  - A postmenopausal woman still makes a little bit of estrogen in tissues like the liver or the adrenal gland, the fat (a normal body stores of fat)
  - The aromatase inhibitors block that production of estrogen
- The consequences of **estrogen deprivation**: this starves on the vine these cancer cells [grow on]
  - We think breast cancer cells depend on estrogen for their growth and development
- So that’s a very important medicine (globally, hugely important); it has saved more lives than bone marrow transplant or Gleevec or immunotherapy or whatever of the sexy new approaches in cancer
  - The statistics are all in favor of these hormone manipulations as being globally of huge importance
- In addition to that, we also have a whole closet full of different types of drugs that we use
- Some of them are **traditional chemotherapy drugs**, and patients may sort of have a cultural sense of what these drugs are
  - They tend to be rather nasty IV medicines, they make you sick to your stomach, they can make your hair fall out, they lower your blood counts, they make you tired
- On the one hand, our supportive care in oncology has gotten vastly better in recent decades
  - We have very powerful anti-nausea medicines
  - We have medicines to goose the white blood cells to come back faster, so you’re not at risk for infections
  - We have cold caps these days that allow women to often not experience hair loss during chemotherapy
- So on the one hand, the supportive care has really transformed our ability to give chemotherapy drugs
- Drugs such as [doxorubicin (brand name Adriamycin)](https://en.wikipedia.org/wiki/Doxorubicin), the red devil, taxane type drugs called [Paclitaxel (brand name Taxol)](https://en.wikipedia.org/wiki/Paclitaxel), alkylator drugs like [cyclophosphamide](https://en.wikipedia.org/wiki/Cyclophosphamide) or [carboplatin](https://en.wikipedia.org/wiki/Carboplatin), very widely used chemotherapy drugs
  - Peter points out that these all have something in common, “*They’re’ basically antiproliferative drugs*.”
    - They’re old school, dirty drugs that have been around for many decades
    - They target dividing cells, and that’s why these side effects exist
    - Hair falls out because hair is dividing
    - You get sores in your mouth because the epithelial cells in your mouth are dividing
    - These drugs are very nonspecific
    - But on balance, they are going after cancer cells in the sense that cancer cells are going to be dividing more frequently than non-cancer cells
  - Harold agrees, “*They’re rather blunt instruments, but sometimes it’s really helpful to have a wrecking ball*.”

**Developments in the past two decades**

- We’ve really transformed how we think about this because of some newer drugs that have come along
- In the different subtypes of breast cancer, we have different approaches
- **Triple-negative breast cancer** had historically been one of the most difficult to treat types of breast cancer, where we didn’t really have a targeted therapy
  - And so we used a lot of chemotherapy and there were dozens of trials optimizing chemotherapy in triple-negative disease
  - But the biggest new thing has been immunotherapy, the so-called [checkpoint inhibitors](https://en.wikipedia.org/wiki/Checkpoint_inhibitor), drugs like [pembrolizumab](https://en.wikipedia.org/wiki/Pembrolizumab) and others that have proven very active in a lot of different tumor types
    - [Checkpoint inhibitors are discussed in episode [#177](https://peterattiamd.com/stevenrosenberg/)]
- **Checkpoint inhibitors** reduce the risk of cancer recurrence, and the data for these drugs is most compelling inn triple-negative breast cancer
  - Interestingly, we use them before the surgery in what we call a [neoadjuvant approach](https://en.wikipedia.org/wiki/Neoadjuvant_therapy)
    - Which is the same idea as adjuvant therapy: drug therapy is used to mop up cancer everywhere in the body
    - But it’s actually given before the surgery to shrink the tumor and to allow the patient to get the effective treatment that goes everywhere in the body
- For **HER2-positive breast cancer**, the transformative event was the development of [trastuzumab (or Herceptin)](https://en.wikipedia.org/wiki/Trastuzumab)
  - The data came forward in 2005 for early stage breast cancer that adding trastuzumab dramatically improved the chances of never hearing from the cancer again
  - And that became totally standard for HER2 driven breast cancers
  - Nowadays, for higher risk ones, we add a second anti-HER2 drug called [pertuzumab (or Perjeta)](https://en.wikipedia.org/wiki/Pertuzumab)
- Interestingly, we’re still giving chemotherapy with those anti-HER2 drugs

> “*We’ve completely flipped the outcomes for HER2-positive breast cancer, where it has gone from one of the most feared types of breast cancer to one of the most successfully treated types of breast cancer*.”‒ Harold Burstein

- With **estrogen receptor-positive breast cancer**, there have been two narratives
- 1 – A narrative about using *less* chemotherapy
  - The good news is we are able to figure out a lot of women don’t actually need chemotherapy for ER-positive, HER2-negative
  - Men don’t actually need chemotherapy for ER-positive, HER2-negative breast cancers
  - There’s this genomic test we get to help us decide whether a chemotherapy is going to be valuable, and with that, about 2/3 of the women who were previously offered chemotherapy can now avoid chemotherapy
- 2 – At the same time, we’re amping up some of the hormonal axis manipulation
  - We are using ovarian suppression, which means for younger women going into premature menopause to help prevent the cancer from coming back
  - We’re using longer durations of antiestrogens for higher risk tumors
- And there’s a very exciting *new class of drugs* called [CDK4/6 inhibitors](https://en.wikipedia.org/wiki/CDK_inhibitor), which are oral medicines given for a couple of years
  - They are targeted drugs that again, slow down the proliferation of tumors and for very high risk cancers
  - We’re now looking at using them in addition to all the other kinds of medicines that we’re talking about

***Each type of breast cancer has its own paradigm of treatment, and each group is doing incrementally better and better because of those innovations***

**What are the indications for neoadjuvant therapy?**

*Which tumors, based on imaging and biopsy, are deemed cancers where they’re going to get all that systemic therapy before surgery?*

- Peter’s recollection is the pathological response that you see to the neoadjuvant therapy is also a great prognostic indicator
  - Hal confirms, “*That’s exactly right.*”
- For larger tumors, we have been moving more and more towards a paradigm of what we call neoadjuvant treatment
- The usual sequence is: diagnosis of cancer, surgery, chemotherapy (if you’re going to get it), radiation therapy (if you’re going to get it), hormonal therapy
- Now, we’re moving it all around
- Hal describes this as a freight train

***It’s a cassette of treatment and we’re just giving the same therapy, but we’re switching the order and we’re switching the order for very specific reasons***

- 1 – One of those reasons is that by giving the drug therapy first, we usually can shrink the tumor either in the breast or particularly in the lymph nodes as well
- That means we can offer the same good outcomes, but with less surgery
- Women who might’ve needed a mastectomy might now be able to have a lumpectomy if the tumor shrinks
- Or women who might’ve been obliged to undergo a so-called axillary lymph node dissection where all the lymph nodes in the armpit are removed (that carries a greater risk of limited range of motion in the arm or lymphedema in the arm), now might be a candidate for a sentinel node biopsy by shrinking those tumors ahead of time
  - That’s one big advantage of neoadjuvant therapy

***Neoadjuvant therapy gives the same treatment, but it makes the surgeon able to do a lesser operation, so there’s less morbidity from the operation and a better cosmetic result***

- 2 – The second big reason is that we learn while giving this neoadjuvant treatment how well the tumor responds
- If the cancer totally disappears, that’s a really favorable prognostic finding, and we call that a pathologic complete response
  - It just means the pathologist looks under the microscope at the end of that treatment course at the time of the surgery and says there’s no cancer left
  - That’s a really good finding and puts the patient into a much lower risk category, a much better prognostic group

**Do those patients get adjuvant therapy or is therapy done?**

- They often get something
- It depends again on the specific flavor of where you’re at, but the prognosis goes way up
- Conversely, if there’s some residual cancer, it’s a less favorable prognostic finding, but in many instances, we actually have *drugs that we’re now using to overcome that residual disease*
  - For instance, in HER2-positive breast cancer, we give chemotherapy and [trastuzumab](https://en.wikipedia.org/wiki/Trastuzumab) upfront
  - If there’s residual disease out back, we can use a derivative of trastuzumab called [trastuzumab emtansine](https://en.wikipedia.org/wiki/Trastuzumab_emtansine), which improves the prognosis for those patients who have residual cancer
  - And there are many instances of this throughout the spectrum of breast cancer treatment

***So we use neoadjuvant therapy for larger tumors to shrink the tumor in the breast, shrink the tumor burden in the lymph nodes, and to individualize or tailor treatment on the backside based on how much response there is***

## The use of hormone replacement therapy in women who are in remission from breast cancer [1:41:15]

**Back to the analogy of prostate cancer**

- We know that in the case of prostate cancer, testosterone is not causing prostate cancer, but it’s a growth factor for the cancer
- So once a man has prostate cancer, if he has metastatic disease, androgen therapy is the standard of care (removing the androgen)
- If he has surgical disease, you remove the tumor, but men are able to go back on testosterone replacement therapy (if they need it), provided the PSA stays low
- The analogy here in breast cancer where if a woman has ER-positive breast cancer and it’s metastatic, unfortunately you’re going to be dealing with antiestrogen therapy indefinitely
- But if you’re talking about a stage I cancer, or a stage II cancer, or even a stage III where you have neoadjuvant treatment, you have a pathologic CR, as far as you’re concerned, there’s no evidence of disease

**Are those women still told to forego estrogen replacement therapy in post-menopause? And if so, why the difference from the biology of prostate cancer?**

- Antiestrogen medicines are very common
- Remember 80+ percent of tumors are estrogen receptor-positive, and nearly all those patients would be advised to have antiestrogen medications
- The side effects all relate to the estrogen deprivation: hot flashes, night sweats, bone and joint stiffness and achiness, hair thinning (not hair loss, but thinning finer hair, somewhat of a receding hairline), vaginal dryness and sexual health issues or frequent urinary tract infections related to changes in the epithelium of the genital tract, osteoporosis
  - All these things are related to the loss of estrogen
- Now, the upside of the treatment is sufficiently important that we encourage patients to strongly consider those treatments nonetheless, but managing those side effects is a part of the work of what oncology teams do
- For women who’ve had a complete pathologic response, one asks, “*Do I really need all the therapy out back?*”
  - It’s a great question at the moment

***We don’t usually omit the antiestrogens if the tumor is ER-positive***

- Parenthetically, it’s rather rare for ER-positive tumors to have that complete pathologic response because there’s an inverse relationship between the effectiveness of hormone treatment and the effectiveness of chemotherapy
  - The more hormone sensitive the tumor is, the less role there is for chemo and vice versa in the space of ER-positive disease
- For women who have **triple-negative breast cancers**, in theory you could say it would be okay to take antiestrogens, but we don’t stylistically endorse that too often

***What we really focus on is what’s the symptom that we’re trying to address with the hormone replacement therapy?***

- And in those instances, we have important conversations with patients.
- For instance, if a patient has osteoporosis, we have very good non-hormonal options to treat osteoporosis
- If a patient has hot flashes and night sweats, there are non-hormonal options to address those
  - The FDA just [approved](https://www.fda.gov/news-events/press-announcements/fda-approves-novel-drug-treat-moderate-severe-hot-flashes-caused-menopause#:~:text=Veozah%20is%20not%20a%20hormone,the%20same%20time%20each%20day.) a [drug](https://en.wikipedia.org/wiki/Fezolinetant) a few months ago to try and treat hot flashes
- For genital symptoms, genitourinary symptoms, sexual health issues we are rather liberal about using genital preparations of estrogen
  - Vaginal estrogen creams and things like that that can alleviate some of the discomfort or other symptomatology without giving significant systemic absorption

***For most breast cancer patients, we stay away from oral hormone replacement therapy looking whenever possible to use non-hormonal or tapered or tailored hormonal manipulations that don’t offer systemic exposure***

- Now, having said all that, everyone who sees a lot of breast cancer patients knows there’s a few women who are really just so uncomfortable without the hormones that they really need that to have a valuable quality of life
  - And then you have a unique conversation with the patient about those issues

## The role of genetics in breast cancer [1:44:45]

- Everyone has heard of the [*BRCA* genes](https://en.wikipedia.org/wiki/BRCA_mutation), but those are not the only genes responsible
- And when we talk about cancer, everybody understands cancer is a genetic disease in the sense that there are mutations that are the [sine qua non](https://en.wikipedia.org/wiki/Sine_qua_non) of the cancer
  - Most of those mutations are somatic: they’re mutations that occur during our life
  - But a handful of them are germline and clearly the *BRCA* mutations are the most noteworthy

**What can we say about inherited risk of breast cancer through either single genes or polygenic?**

*How much do we know? What’s the prevalence?*

- Family history is obviously a powerful marker for greater risk of breast cancer recurrence
- If you look at large populations, roughly 8-10% of all breast cancer diagnoses are related to a specific hereditary gene mutation
  - *BRCA-1/ BRCA-2* account for about half (or 5 of that 10%) of all hereditary breast cancer
    - These often are families that have particular histories of ovarian cancer and breast cancer
    - *BRCA-1* and *BRCA-2* are very highly [penetrant](https://en.wikipedia.org/wiki/Penetrance) genes ‒ that means there’s a pretty high lifetime risk of developing breast cancer or ovarian cancer if you have a *BRCA-1* or *BRCA-2* mutation

***Think of the average chance of developing breast cancer, that number is 1 in 8 (discussed earlier); instead, we’re talking about a 1 in 2 or 2 in 3 lifetime chance of developing breast cancer for women who harbor those gene mutation***

- Genetic testing for *BRCA-1/BRCA-2* mutations has now become very standard

**Increasingly what we’re seeing is that when one member of a family is identified as having a** ***BRCA-1*** **or** ***BRCA-2*** **mutation, we can help that patient in several ways**

- 1 – They might consider **mastectomy** because of the risk of a second breast cancer
- Some women who’ve not been diagnosed with cancer will consider prophylactic mastectomy
- 2 – Second, we think about **prophylactic ectomy removing the ovaries** once that patient is done with childbearing because we don’t really have a good screening tool for ovarian cancer
  - Ovarian cancer also traffics with a *BRCA-1* and *BRCA-2* mutation
- 3 – For women who choose to retain “the brass”, we offer more **intensive screening**
  - Usually it’s an annual MRI staggered every six months with an annual mammogram

**Cancer risk in men**

- We also talk to extended family members because as you know, *BRCA-1* and *2* increase the risk of prostate cancer in men
  - They also increased the risk of male breast cancer and they also increased the risk of pancreatic cancer
  - Though the numerical issues there are all smaller than the risk of breast or ovarian cancer

**We’ve learned a lot about those particular mutations**

- This is an evolving space in our management of cancers
- We have a whole team of genetic counselors and genetic specialists who both do the genetic testing and then advise patients very carefully on what the particular findings mean for their own care and how they should think about that in their breast cancer or other cancer management

**Can you say a little bit more about those as far as** ***BRCA*** **being gain a function/ loss of function? How is it transmitted? Is it autosomal dominant? Does it matter if a male knows that he has it with respect to his female offspring, et cetera?**

- These are transmitted as autosomal dominant
  - That is to say a man can transmit it to his offspring just as easily as a woman can
- They are [loss of function mutations](https://en.wikipedia.org/wiki/Mutation#By_effect_on_function)
- The normal biological role of these proteins that are encoded by the *BRCA-1* and 2 gene seems to be to help **repair the DNA** in a normal cell
  - Every time a cell divides, there’s all this “fine print editing” of the genome
  - And they’re constantly replacing base pairs to correct the genome so that it stays perfect through the thousands of divisions that a cell might undergo in the lifespan of a person
  - When you have a deficiency in *BRCA-1* or *BRCA-2* or other genes in this space, that repair mechanism is much less precise
    - Mutations begin to accumulate, and if you have further loss of DNA repair that can then predispose to giving rise to cancers

> “*Breast, ovarian, prostate, pancreatic are the most common ones that we see associated with BRCA-1 and 2*”‒ Harold Burstein

**What makes up the other half?**

- The other half includes other proteins in the same pathway of the BRCA-1 and 2, so in particular [PALB2](https://en.wikipedia.org/wiki/PALB2), which is a partner of the BRCA-2 protein.
- About 1% of all breast cancers will have a *PALB2* mutation, which is a mutation that also substantially increases the risk of developing lifetime breast cancer, but a little bit less than *BRCA-1* or *2*
- About 1-2% will be related to a gene called [*CHEK2*](https://en.wikipedia.org/wiki/CHEK2), which also increases the risk of colon cancer
- And about 1-2% will be related to mutations in the [ataxia-telangiectasia gene (ATM)](https://en.wikipedia.org/wiki/ATM_serine/threonine_kinase), which can give rise to several different kinds of cancers, though they’re less common

> “*Here’s the key takeaway for many, many women now, we are recommending that following a breast cancer diagnosis, they do have genetic testing so that we can understand if we need to think about their tumor differently or if we need to think about their surveillance or prevention approaches differently.*”‒ Harold Burstein

- We’re doing a lot more genetic testing than we used to do, and with that, we’re finding these other mutations

***Most women still don’t have a mutation; most women who have first degree relatives, mom or sisters who have breast cancer don’t have a hereditary mutation***

- Because of this, many women can be reassured that they have not transmitted an undue risk to their offspring
  - Which is a real concern amongst many patients diagnosed with breast cancer
- So a negative genetic test result can also actually be very reassuring for a family, even as a positive finding can allow us to act differently in their management

**Peter’s takeaway** ‒ mutations in *BRCA-1* and *2*, *PALB2*, *CHEK2*, *ATM* account for 10% of breast cancer cases

- These are the exception and not the rule, but they are germline mutations
- They’re single gene mutations and they’re worth screening for

**Is there any reason a woman with one first degree relative should be checking this?**

*Or if a woman has a sufficient enough family tree, mom does not have it, no grandparents have it, no parents have it ‒ would that be dispositive to say, “I don’t need genetic testing?”*

- These different genes have different familial patterns, and because many of them are so-called “less [penetrant](https://en.wikipedia.org/wiki/Penetrance),” you can be fooled by a relative not having it
- Hal adds, “*I think we’re getting closer to the time when there will be universal genetic testing following a breast cancer diagnosis, and that will have a cascading effect into the families of affected individuals.*”
- For women who have a strong family history of cancers, it’s certainly very appropriate to meet with genetic counselors, talk about the testing options, and in many instances, pursue that testing both because they want to know if they should be more aggressive about their screening and surveillance
  - But they are also looking for reassurance that this isn’t something they have to be unduly concerned about

**Are there any commercial tests that you can point people to where they can ask their doctor or go directly over-the-counter and get a test done that looks specifically for those five genes?**

- There are many commercial assays from many different companies that typically look nowadays at larger panels of genes, often up to about a hundred genes on a rather regular basis
  - These are usually done with a specific purpose of looking for hereditary cancer risk
- While that over-the-counter things like the [23andMe](https://www.23andme.com/) things, can in theory pick these up, we don’t usually lean on them as clinically actionable tests

***If there’s a real concern about family history, it’s probably better to seek out a genetic counselor or a cancer center in the community where you can talk more about this and get specific tests from different companies***

## The importance of multidisciplinary care delivered by cancer centers [1:53:15]

- Hal is at Dana-Farber, which is probably one of the top three cancer centers globally (certainly in the United States), which would be the epicenter of multidisciplinary care

**Tell folks what multidisciplinary care means, what the benefits are, but given that most people are not going to go to Dana-Farber or Memorial Sloan Kettering for their breast cancer care, how important is it and what should they be looking for in their local hospital when they are diagnosed?**

- It’s a really great point about helping patients get excellent breast cancer care
- And it’s not unique to breast cancer, but many, many cancers require multidisciplinary care
- Multidisciplinary care is a fancy way of saying you’re going to need to think about surgery, radiation therapy, medical oncology management with drug therapy
- You want to have outstanding pathology, you want to have genetic counselors, you want to have great imaging teams
- What cancer centers do is they bring all those people together under one roof (these days it’s sometimes with satellites); they all collaborate together and work together

***That is really why care in a major cancer center can be so effective because you have a team of people who are working together every day to make sure that things get done the right way***

- Hal draws an **analogy about the airline industry**
  - As a passenger, you want an invisible experience with the airline, but what makes it all work?
  - You’ve got to have a great maintenance team
  - You’ve got to have an air traffic controller that knows what they’re doing
  - You’ve got to have pilots who understand how things work
  - You need the food delivery trucks to arrive at the right time at the right moment
  - You need gate agents to keep people moving through the whole thing
  - And you get that at airports that are good because they all work together constantly and they know exactly what they’re doing
  - They communicate with each other regularly
  - That’s what makes for a very uneventful flying experience (we hope)
- And for cancer care, you want the same thing

**The way you figure this out, if you’re a patient**

- ***Are the providers talking to each other?***
- You don’t have to see them all the same day
  - Though of course it’s nice if you can do that, and we try to do that
- They don’t have to all be under the same roof because it’s not essential (but we try to do that)
- What’s essential is that ***they function as a team*** because almost every patient with breast cancer is going to need to think about surgery, radiation therapy, medical oncology care
  - Many will also need to think about plastic or reconstructive surgery
  - Many will need to think about quality of the imaging they get down the road
  - They might need genetic testing
- You want folks who are working together all the time communicating with each other and handing the baton back and forth as necessary
- One of the conversations we frequently have when we meet a new patient is **which modality of therapy is going to come first?**
  - Is it going to be surgery and then medical oncology and radiation afterwards, or do we actually want to flip the sequence as we talked about in neoadjuvant treatment and give medical oncology treatment first?
  - That’s where you want a group that works together, talks effectively and regularly so that they’re all on the same page
  - And we all say things like, “*Okay. You’re going to have surgery first. I’m going to let my surgical team take you through that next lap on this relay race. Then we’re going to have the radiation team grab the baton. They’re going to take you on a lap, and then I’m going to pick it up and take you through another lap as we talk about medical oncology therapy*.”
- That collaboration and teamwork is really important for women who’ve been diagnosed with breast cancer

**How important do you think it is for a woman to undergo her therapy at home versus going somewhere else?**

*How do you help patients navigate that and what fraction of the patients who come to Dana-Farber don’t live in Boston?*

- We’re very fortunate to have a terrific reputation such that we see patients from all across the country and really all across the world
  - They will come to a cancer center like Dana-Farber for exactly that multidisciplinary care
  - And in the management of metastatic disease, they might also come for clinical trials, both in the early and in the advanced stage disease where the next wave or the future of innovative treatment is going to emerge
- Having said that, breast cancer is a very common problem

> “*It is the most common cancer diagnosis in the country, as we’ve mentioned, and you can get great breast cancer care in many, many parts of the country.*”‒ Harold Burstein

- There are very few parts of the United States where people really don’t live within a reasonable distance of access to really good breast cancer care
- Having said that, it is important to make sure that you’re dealing with people who **specialize in cancer care**, and that you have that team presence
  - There’s been a big push to professionalize the issues of radiation oncology and surgery to subspecialize those areas just as we subspecialize medical oncology
  - Those are things to very much seek out as part of your treatment program
- And most people, again, will live within distance of getting a **second opinion**
  - That’s always a good idea if there’s any ambiguity
  - By making the effort to go to a place where you can get external validation of the plan, it offers a lot of reassurance and comfort

**Where would you say is the greatest variability of care across the medical oncology, surgical oncology, radiation oncology, when you compare the top 20 institutions in the United States and compare them to the median institutions of the country?**

*Where will you see the most disparity?*

*Will it be in the radiation side, the  surgical side, the postoperative side?*

*Where’s the greatest variability?*

- There’s not one specific area that jumps out
- The value added of some of the cancer centers that we’ve been discussing: really thoughtful review of the pathology and radiology
  - These are things that are not often visible to patients
- But the experience of the radiology team working with the surgeons: are they really satisfied that that little ditzel doesn’t need to be biopsied
- Is the pathology first rate?
  - Did they really make sure that the grade was called correctly, that the estrogen receptor studies were correctly done?
- Those are incredibly important things, and while most places do it very well, those are things that can really alter longer term outcomes
- Another area is judicious use of treatment: there are a lot of drugs that we can use in early stage breast cancer and dialing in the right amount is a bit of an art form
- Again, it’s a common disease, and most places do it very well
- But there are sometimes nuanced questions about is this a case where we want to add more or is this a case where we’re comfortable doing a little bit less?
  - That’s an important part of the discussion
- Other areas that matter a lot are not always so obvious to patients: **plastic and reconstructive surgery**
  - Tremendous variation in approaches and in the teamwork and collaboration between the breast surgeon and the plastic and reconstructive surgery teams
  - Those things can also have a big impact on how people look and feel years after the breast cancer diagnosis

***Making sure that you have high quality access to plastic and reconstructive surgeons (if that’s part of the treatment plan) is really critical***

**Hal’s takeaway**

- The good news is that you can get excellent breast cancer care at many, many places around the country
- The “test” for most patients is are these folks used to working together?
  - Are they talking to each other, collaborating with one another, coming up with a unified plan that makes sense
    - That’s really what you want to see happen
- Peter adds, “*If they don’t have a monthly tumor board, those would be signs…*”
  - This is a meeting where all these people, the pathologists, the medical oncologists, surgical oncologists, radiation oncologists get together
  - Signs that you might want to travel a little bit further for treatment

**Peter’s public service announcement**

- If you’re going to seek that **second opinion**, sending a block of pathology slide to the “A+ center” is really valuable
- Make sure when you have your tissue specimen taken that you understand you have a right to request a section of that tissue be sent to another pathologist of your choosing
  - That can be a very important determinant of outcome
  - That’s an easy place to make a mistake or overlook something if a less experienced center is viewing a tumor that happens to be not a “run of the mill” tumor
- Hal agrees, “*The quality of pathology is the foundation for all of cancer care*.”
- And again, breast cancer usually begins in the breast
- It’s usually not so mysterious, but oftentimes a **pathology review** is of vital importance
  - Are the margins adequate?
  - Is this DCIS or invasive cancer?
  - It can sometimes be hard to know
  - Is this a favorable prognosis tumor under the microscope or not?
- And then if you take a bigger step back, we occasionally see things that aren’t even breast cancer
  - There are other tumors that can be there, they can be reclassified
  - And then when you start to imagine other kinds of cancer sarcomas and lymphomas and leukemias where there’s a real art to the pathology

***That’s an unappreciated vital part of the cancer care process that everyone has access to with consultations on pathology and is part of what great cancer centers really deliver***

## Breast cancer in men [2:03:30]

**What is the incidence of breast cancer in men, and what do we know about the risk factors?**

- It’s an absolute truism that men can get breast cancer
- Fortunately, the incidence is pretty low ***for every 200 cases of female breast cancer, there’s one case of male breast cancer***
- The **risk factors** are not particularly well known, but they do include genetic predisposition as part of it
  - They include certain hormonal conditions that men can rarely get

***What’s interesting is men are often unaware that they can get breast cancer***

- So it is not uncommon that men’s diagnoses are actually at a higher stage than women’s because they weren’t really paying a lot of attention to the chest or the breast, or they noticed some nodularity and didn’t really think much of it
- If men are found on exam to have any changes around the breast tissue, that should be evaluated as well
- Hal has had the experience over the years of a woman who was diagnosed with breast cancer, and then her husband was poking around his chest like, “*Wait a second*”
  - A husband and wife both had breast cancer
  - It happens once in a while
- The **treatment** principles for male breast cancer are fundamentally the same as for female breast cancer, though nearly all breast cancers in men are estrogen receptor-positive
  - It’s very rare to get a triple-negative breast cancer in a man
  - HER2 receptor- [positive breast cancer] is uncommon but not unheard of
- At the Dana-Farber Cancer Institute they have a [program for men with breast cancer](https://www.dana-farber.org/program-for-breast-cancer-in-men/) headed by [Pablo Leone](https://www.dana-farber.org/find-a-doctor/jose-pablo-leone/)
  - And several other cancer centers around the country also have this

**There are issues that arise historically**

- Men have been offered mastectomy because the aesthetic virtues of breast preservation have not been thought to be so important in men, and that’s changing nowadays for some men
- Most men will be candidates for antiestrogen medicine as their tumors are estrogen receptor-positive
- The genetic piece is very important

## Parting thoughts and takeaways [2:05:45]

- Women are doing better and better following a diagnosis of breast cancer
- Early detection is really important
- Multimodality therapies are really important
- The drugs are getting better and better for both early and for advanced (or stage IV) breast cancer
- So there’s a lot of tremendous optimism in the care of breast cancer patients right now, even as it remains a public health challenge and obviously a personal challenge for hundreds of thousands of women around the country

§

## Selected Links / Related Material

**Previous episodes of** ***The Drive*** **about prostate cancer**: [2:00]

- [#39 – Ted Schaeffer, M.D., Ph.D.: How to catch, treat, and survive prostate cancer](https://peterattiamd.com/tedschaeffer/) (February 4, 2019)
- [#273 ‒ Prostate health: common problems, cancer prevention, screening, treatment, and more | Ted Schaeffer, M.D., Ph.D.](https://peterattiamd.com/tedschaeffer2/) (October 2, 2023)

**Previous episodes of** ***The Drive*** **on hormone replacement therapy (HRT)**: | [16:00]

- [#42 – Avrum Bluming, M.D. and Carol Tavris, Ph.D.: Controversial topic affecting all women—the role of hormone replacement therapy through menopause and beyond—the compelling case for long-term HRT and dispelling the myth that it causes breast cancer](https://peterattiamd.com/caroltavris-avrumbluming/) (February 25, 2019)
- [#253 ‒ Hormone replacement therapy and the Women’s Health Initiative: re-examining the results, the link to breast cancer, and weighing the risk vs reward of HRT | JoAnn Manson, M.D.](https://peterattiamd.com/joannmanson/) (May 8, 2023)

**Treatment of ER-positive DCIS with and without estrogen blockade**: [51:00]

- [Tamoxifen in treatment of intraductal breast cancer: National Surgical Adjuvant Breast and Bowel Project B-24 randomised controlled trial](https://pubmed.ncbi.nlm.nih.gov/10376613/) | *Lancet* (B Fisher et al 1999)
- [Lumpectomy and radiation therapy for the treatment of intraductal breast cancer: findings from National Surgical Adjuvant Breast and Bowel Project B-17](https://pubmed.ncbi.nlm.nih.gov/9469327/) | *Journal of Clinical Oncology* (B Fisher et al 1998)

**NSABP**: [58:00]

- [NSABP Foundation, Inc.](https://www.nsabp.org/about-us/the-foundation/)
- [NSABP: National Surgical Adjuvant Breast and Bowel Project](http://www.nsabp.pitt.edu/) |  NRG Oncology

**NSABP P-1 study**: [Tamoxifen for prevention of breast cancer: report of the National Surgical Adjuvant Breast and Bowel Project P-1 Study](https://pubmed.ncbi.nlm.nih.gov/9747868/) | *Journal of the National Cancer Institute* (B Fisher et al 1998) | [58:15]

**Genetic test to predict recurrence of breast cancer**: [1:17:15, 1:30:45]

- Oncotype DX Breast Recurrence Score: [Precision Oncology: Turn what if into what is](https://precisiononcology.exactsciences.com/healthcare-providers/treatment-determination/breast-cancer/oncotype-dx-breast-recurrence-score) | Exact Sciences (2023)
- MammaPrint Assay: [The molecular profile to define and defeat her unique cancer](https://agendia.com/mammaprint/) | Agendia (2023)

**American Cancer Society current statistics on breast cancer**: [1:20:45]

- [Breast: At a Glance](https://cancerstatisticscenter.cancer.org/#!/cancer-site/Breast) | American Cancer Society: Cancer Statistics Center (2023)
- [Breast Cancer Facts & Figures 2022-2024](https://www.cancer.org/content/dam/cancer-org/research/cancer-facts-and-statistics/breast-cancer-facts-and-figures/2022-2024-breast-cancer-fact-figures-acs.pdf) | American Cancer Society (2023)

**Program for men with breast cancer at Dana-Farber**: [Program for Breast Cancer in Men](https://www.dana-farber.org/program-for-breast-cancer-in-men/) | Dana-Farber Cancer Institute (2023) | [2:05:15]

§

## People Mentioned

- [Eun-Sil Shelley Hwang](https://surgery.duke.edu/profile/eun-sil-shelley-hwang) (Professor of Surgery and Vice-Chair of Research in the Department of Surgery at Duke University) [45:30]
- [Pablo Leone](https://www.dana-farber.org/find-a-doctor/jose-pablo-leone/) (Director of the Program for Breast Cancer in Men and Senior Physician at Dana-Farber Cancer Institute, and Assistant Professor of Medicine at Harvard Medical School) [2:05:15]

§

![](https://peterattiamd.com/wp-content/uploads/2023/11/bio-haroldburstein-500x487.jpeg)

##### Harold Burstein, M.D., Ph.D.

Harold Burstein earned his M.D. at Harvard Medical School. He also earned his Ph.D. in cellular immunology and a master’s degree in the history of science from Harvard. He completed his residency in internal medicine at Massachusetts General Hospital and a hematology/oncology fellowship at Dana-Farber Cancer Institute. Dr. Burstein is a clinician and clinical investigator in the Breast Oncology Center at Dana-Farber Cancer Institute, a Professor of Medicine at Harvard Medical School, and a staff physician at Brigham and Women’s Hospital. He has led and participated in multiple clinical trials, and developed national and international breast cancer treatment guidelines.  Recognized as one of the leading breast oncologists, he is a perennial “Top Doctor” in the US for breast cancer care.  He teaches students, residents and fellows at Harvard Medical School and Dana-Farber. [[Dana-Farber Cancer Institute]](https://www.dana-farber.org/find-a-doctor/harold-j-burstein/)