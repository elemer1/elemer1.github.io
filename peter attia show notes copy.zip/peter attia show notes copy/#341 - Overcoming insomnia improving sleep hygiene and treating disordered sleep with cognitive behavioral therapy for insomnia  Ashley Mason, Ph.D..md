# #341 – Overcoming insomnia: improving sleep hygiene and treating disordered sleep with cognitive behavioral therapy for insomnia | Ashley Mason, Ph.D.

**Source:** [https://peterattiamd.com/ashleymason/](https://peterattiamd.com/ashleymason/)

---

Ashley Mason is a clinical psychologist and an associate professor at UCSF, where she leads the Sleep, Eating, and Affect (SEA) Laboratory. In this episode, Ashley provides a masterclass on cognitive behavioral therapy for insomnia (CBT-I), detailing techniques like time in bed restriction, stimulus control, and cognitive restructuring to improve sleep. She explains how to manage racing thoughts and anxiety, optimize sleep environments, and use practical tools like sleep diaries to track progress. She also offers detailed guidance on sleep hygiene; explores the impact of temperature regulation, blue light exposure, and bedtime routines; and offers guidance on finding a CBT-I therapist, along with sharing practical steps you can take on your own before seeking professional help.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/ashleymason/the_Drive_public.png)

Play

#341 - Overcoming insomnia: improving sleep hygiene and treating disordered sleep with cognitive behavioral therapy for insomnia | Ashley Mason, Ph.D.

#341 - Overcoming insomnia: improving sleep hygiene and treating disordered sleep with cognitive behavioral therapy for insomnia | Ashley Mason, Ph.D.

1x15s30s

0:002:05:16

## We discuss:

- Defining insomnia: diagnosis, prevalence, and misconceptions [3:00];
- How insomnia develops, and breaking the cycle with cognitive behavioral therapy for insomnia (CBT-I) [7:45];
- The different types of insomnia, and the impact of anxiety, hydration, temperature, and more on sleep [11:45];
- The core principles of cognitive behavioral therapy (CBT) and how CBT-I is used to treat insomnia [20:00];
- Implementing CBT-I: time in bed restriction, sleep scheduling, and the effect of napping [29:45];
- Navigating family and partner sleep schedules, falling asleep on the couch, sleep chronotypes, and more [39:45];
- Key aspects of sleep hygiene: temperature, light exposure, and circadian rhythm disruptions [44:45];
- Blue light and mental stimulation before bed, and the utility of A-B testing sleep habits [52:45];
- Other simple interventions that may improve sleep [57:30];
- Ashley’s view on relaxation techniques and mindfulness-based practices [1:02:30];
- The effectiveness of CBT-I, the role of sleep trackers, and best practices for managing nighttime awakenings [1:04:15];
- Guidance on intake of food and alcohol for good sleep [1:16:30];
- Reframing thoughts and nighttime anxiety to reduce sleep disruptions [1:18:45];
- Ashley’s take on sleep supplements like melatonin [1:21:45];
- How to safely taper off sleep medications like benzodiazepines and Ambien [1:26:00];
- Sleep problems that need to be addressed before CBT-I can be implemented [1:38:30];
- The importance of prioritizing a consistent wake-up time over a fixed bedtime for better sleep regulation [1:40:15];
- Process S and Process C: the science of sleep pressure and circadian rhythms [1:45:15];
- How exercise too close to bedtime may impact sleep [1:47:45];
- The structure and variability of CBT-I, Ashley’s approach, and tips for finding a therapist [1:50:30];
- The effect of sauna and cold plunge before bed on sleep quality [1:56:00];
- Key takeaways on CBT-I, and why no one should have to suffer from insomnia [1:58:15]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Ashley Mason is an Associate Professor at UCSF where she leads the [Sleep, Eating, and Affect (SEA) Lab](https://www.sealab.ucsf.edu/)
- Her research focuses on non-pharmacologic interventions for mental health
  - Particularly exploring how treatments like whole-body hyperthermia, mindfulness-based approaches can improve mood disorders, sleep, and eating behaviors
- She’s also the director for [UCSF Center for Obesity Assessment, Study, and Treatment (COAST)](https://chc.ucsf.edu/coast)
- Her work integrates clinical psychology with integrative medicine, aiming to develop accessible treatments that address the biological and behavioral aspects of health
- In this episode, we focus almost entirely around one of her areas of expertise: cognitive behavioral therapy for insomnia (CBT-I)
- Ashely gives us a master class exploration of CBT-I
  - Including various methods
  - Including time in bed-restriction stimulus control and cognitive restructuring to combat insomnia
- We speak about how to manage racing thoughts and anxiety
- She shares techniques like scheduled worry time to address stress during the day and prevent sleep disruption at night
- We talk about the impact of temperature regulation and the role of warming extremities and optimizing sleep environment for effective sleep onset
- We discuss behavioral and cognitive interventions and the impact of leveraging small, actionable changes in thoughts, feelings, and behaviors to overcome patterns of insomnia and other mental health challenges
- Ashley shares some sleep hygiene fundamentals
  - Addressing blue light exposure, food and alcohol intake
  - Creating bedtime routines for better sleep
- She provides practical tools for tracking progress
  - Using sleep diaries and A-B testing to identify and refine effective interventions
- We explore the potential for AI and digital tools to democratize access to CBT-I and address the growing demand for sleep therapy

## Defining insomnia: diagnosis, prevalence, and misconceptions [3:00]

**Where did your interest in insomnia arise?**

- Ashley has been interested in sleep for a long time
- She went to the University of Arizona for her doctoral work and studied with the late [Dick Bootzin](https://en.wikipedia.org/wiki/Richard_Bootzin)
  - He’s one of the co-inventors of cognitive behavioral therapy for insomnia (CBT-I)

*Ashley found CBT-I particularly interesting because it works so well*

- We have so many different psychological treatments and they all have varying degrees of efficacy and effectiveness
- The thing about CBT-I is that it’s kind of like a recipe: if you do it, it works
- This was always just so interesting because it was so different than so many other psychotherapies out there that had so much more unpredictable outcomes

*Ashley became much more interested in CBT-I after her postdoctoral work*

- When she was a post-doc at UCSF and started her assistant professorship, there was this gaping hole in treatment available for people with insomnia
- She thought this might be a good way for her to get back into some clinical work (she was just doing research at the time)

> “*I fell back in love with it because there’s almost nothing as rewarding as being able to see a patient seven times and that seventh time have them say something along the lines of, ‘I have my life back.’*”‒ Ashley Mason

- Patients say something along the line of, “*I have my life back*.”
  - I’m going to get my drivers license back
  - I’m not afraid to drive with my kids in the car anymore
  - I’m going to go back to work

**Ashley grew the clinic that she does CBT-I in**

- She loves it so much that she does it on top of her job
- She meets with patients after hours, at night because it’s the most rewarding thing, and you can have such a big impact on people
  - And people need it

**Help folks understand a little bit about insomnia and maybe go through some of the definitions around the different types of insomnia and maybe some of the different causes for it**

*And also what some of the other treatments for insomnia are*

**⇒** 90% of adults at some point are going to struggle with insomnia, and at any given moment that might be between 5-10%

- The interesting thing about insomnia is that it’s a very clinical diagnosis
  - There’s no blood test for insomnia
  - We can’t put you in a sleep lab overnight and do a test to see if you have insomnia
- We don’t diagnose insomnia based on one night of bad sleep
  - If someone says, “*I didn’t sleep at all last night, or I haven’t slept even for just the last week,*” that’s not going to get a diagnosis of insomnia
- There’s a whole suite of different “somnias” that we could talk about

***The point that is the most salient [for defining insomnia] is just that when you have a problem sleeping and when it’s been going on for at least 3 months (a long time)***

**When you really feel it’s a problem, that’s when it’s time to get help**

**⇒** There’s plenty of people who don’t sleep a whole lot, but it’s not distressing to them, it’s not causing any problems in their life; they’re not going to meet a definition of insomnia per se

- The folks who will tell you, “*I can’t sleep, haven’t been sleeping for months. It’s interfering with my life. It’s really upsetting.*”
  - And they’ve probably already started trying a whole bunch of things to try and help themselves to fix it (and this is where things get interesting)

**Peter clarifies the point estimates [of prevalence] of insomnia**

- 5-10% of the population would have insomnia at any point in time
  - Where it’s been going on for months, and it’s causing distress and impacting life
- At the low end, that’s 1 in 20
- At the high end, that’s 1 in 10 adults
- That’s a higher estimate than Peter would have guessed, given her definition

⇒ Everything Ashley is talking about today is adults (she doesn’t do pediatrics)

*Insomnia is for most people, probably quite episodic*

- It’s not necessarily a permanent state
- People go in and out of it
- The question is how quickly do people go out of it when they go in it?

***And that’s what CBTI is so beautiful for ‒ it’s helping people get out of it quickly***

- There’s going to be things in your life that are going to just happen and they’re going to put you over the threshold for insomnia

## How insomnia develops, and breaking the cycle with cognitive behavioral therapy for insomnia (CBT-I) [7:45]

**How insomnia begins and then how it’s perpetuated**

*These things are actually quite different*

- Everybody has a certain level of **predisposing factors** that are going to put us at risk for having sleeping problems, in particular, insomnia
- Then we may experience what’s called a **precipitating factor**
  - That could be a major life event like losing your job, getting a divorce, getting in a car accident
  - Some major unexpected unhappy life event that might throw you into a bout of insomnia
- That event will end, and you will move on
- But in the meantime, when you’re dealing with that event, **you develop behaviors to cope** with it
  - For example, pop a [Benadryl](https://en.wikipedia.org/wiki/Benadryl) to help you sleep or an [Ambien](https://en.wikipedia.org/wiki/Zolpidem) (something stronger)
  - You might start taking naps the next day after a bad night of sleep to try and cope with it
  - You might start reading in bed a lot or flipping through your smartphone in bed
  - Doing all these different types of behaviors to try and help yourself calm down and actually get to sleep, which in the short term make a lot of sense
- You’re trying to help yourself in the acute moment
- But in the long term, these kinds of behaviors aren’t actually doing you any favors
- And over time that precipitating factor is going to go away

***But all of these behaviors that you’ve started doing to respond to the precipitating event, they’re what stick around; and those are what are going to perpetuate insomnia symptoms and problems***

**Can you say more about the predisposing factors? Are those genetic?**

*Genetic predisposing factors*

- 1 – Patients will say they are a light sleeper
  - That’s tough to fix
  - Ashley will recommend something like earplugs and eye mask, a white noise machine
- 2 – If you are higher on the general psychological reactivity, you’re going to probably get pushed over the threshold more easily than someone else
  - Some people might get in a car accident, a fender bender, and they’re over it by the next day
  - Other people might feel more anxious as a result of that event
- And that’s going to differ from person to person
- You can argue that that’s genetic
- You can argue that that’s based on early childhood or other experiences

***Nature and nurture probably both contribute to that predisposition and there’s not a whole lot that we can do about that***

**The beauty of CBT-I**

- When people come in for treatment, they’re often pretty focused on what caused their insomnia
- Ashley doesn’t ask people what caused their insomnia until the end of her first session with them
- She’s asking them all these other kinds of questions about their behaviors now
- And at the end she asks, “*Okay, so when did this start? What do you think might have caused this?*”
  - And get their attribution for what’s going on

***Because at the end of the day, the intervention’s the same***

*That might differ a lot from the practice of medicine*

- She’s not an MD, she’s a PhD
- In a lot of disease states, we often look at what caused what’s going on
- She’s not really concerned

***She’s more concerned about what you’re doing now that’s perpetuating the problem, and that’s where she intervenes***

> “*That’s why this particular treatment is so effective for so many different presentations of insomnia and causes of insomnia.*”‒ Ashley Mason

- Whether people have difficulty falling asleep in the beginning of the night, waking up in the middle of the night, waking up too early in the morning
- You might think these people all need wildly different treatment, but that’s not actually the case

**Peter’s takeaway ‒** the focus is much more on the coping strategy and the behavior that came out of the predisposing factor or the precipitating event

## The different types of insomnia, and the impact of anxiety, hydration, temperature, and more on sleep [11:45]

**The difference between the person who can’t fall asleep versus the person who wakes up in the middle of the night**

- For Peter, it’s not hard to fall asleep, but he will jolt up at 1 in the morning with some thought or anxiety
  - His mind starts running and he can’t go back to sleep
  - Or he gets up to pee and when he comes back, he starts thinking about the day’s problem or whatever

*Do you think of those as different sides of the same coin?*

***Those people need the same stuff***

- The people who can’t fall asleep at the beginning of the night, their mind’s just racing earlier than Peter’s
- Peter’s is just waking him up
- There’s a whole suite of interventions that are part of CBT-I
  - There are a lot of ways that Ashley could approach an answer to this question

*The racing mind issue*

Ashley always tells patients, “*If you don’t deal with what’s causing you stress or anxiety during the day, it’s going to demand to be dealt with in the middle of the night*.”

- For other people, that happens right when their head hits the pillow at the beginning of the night
  - Oh, you’re relaxing now; okay, here’s your 10 things to worry about

**One of Ashley’s favorite interventions is actually born of anxiety treatment**

- She co-opted it and moved it into CBT-I because it fits with the theoretical framework
- It’s something called “**scheduled worry time**”
- This sounds a little bit panantic and silly, but hear her out
- If a patient came to me and said they worry all day, their life is a constant ball of worry, she would tell them the solution is to just stop it
  - That doesn’t work
- She takes the opposite approach
  - Okay, this is really important to you
  - This is something you’re doing all the time, all day
  - Guess what we do with things that are really important to us? We schedule them

***Ashley has people get out their phone or whatever and schedule “worry time” and it’s going to be an hour a day for the next 7 days***

- It is non-negotiable
- She may or may not schedule an email to go out to you at the end of that time, and you have to go and reply to it and tell her what you did

*Ashley explains what we find when people work with this during the day*

- It does 2 things
- 1 – The first is let’s say it’s 9 A.M. and you are trying to do something in your life, and instead a worry pops up
  - You can actually think, “*Oh, okay, I don’t have to deal with this now. I’m going to write this down because at 4 o’clock I’ve got scheduled time to deal with this.*”
  - So that way you’re uncluttering the rest of your day by moving all of the worry into that scheduled time

Peter reacts, “*This could be a valuable technique even absent insomnia.*”

- Between ⅓ to ½ of Ashley’s patients who come in with insomnia, it a primary **anxiety** disorder and sleep is suffering
- For other folks, it’s primary insomnia and that’s driving them anxious

**To rewind back to the earlier question about trouble sleeping in the middle of the night versus the beginning of the night**

- 2- The other thing that scheduling worry time does is it helps you get it done during the day so that when your head hits the pillow, it’s not there
  - You’ve already worked on this
  - There’s also the knowledge that you have time set aside tomorrow to work on this or to think about this so you don’t have to do that now
  - Ashley mentioned earlier that it unclutters your whole day by shifting worries to this designated time

Ashley cautions, “*Cognitively, this all makes sense and you would maybe think you can think your way out of this, but you can’t. You actually have to try it.*”

- People from all walks of life can really find this valuable

**Other “low-hanging fruit” when it comes to falling asleep at the beginning of the night versus the middle of the night**

- 1 – Not drinking very much fluid with dinner and after dinner is huge
  - Especially for men 45 and over (who still have a prostate)
- 2 – Throwing an electrolyte tab in your drink can really help
  - Granted, it’s got to be the right osmolarity and everything else, but there are ways to find this
  - Don’t slam Gatorade at night; that’s not what she’s suggesting
  - Just throw a [Nuun tab](https://nuunlife.com/products/nuun-zero) or whatever [LMNT](https://drinklmnt.com/), whatever electrolyte replacement
- Ashley has had some male patients go from waking up 3x in the night to pee to 1x
- And the fewer times you wake up in the night, the fewer times you risk not falling back asleep
- 3 -If Ashley had 5 cents for every time she took away a down comforter from someone and their sleep got better, she’d have $8

> “*Everybody’s heard of circadian rhythm, but it’s missing a word, circadian ‘temperature’ rhythm.*”‒ Ashley Mason

**⇒** Your body is supposed to be its coolest at night and its warmest during the day

- Ashley’s favorite people to talk with about this are actually anesthesiologists
  - They know more about body temperature than anyone (it’s remarkable)
- She’s had the great good fortune of learning that your body temperature is supposed to be the warmest during the day and the coolest during the night
- When we do things like trap heat with down comforters
  - Quilted nonsense, even cotton replacement [comforters]
  - If the word duvet or comforter is in it ‒ it’s a “no”
- Ashley gives people a handout of the definition of a cotton blanket
  - If you are cold, use 2 or 3
- It’s made a huge difference for a lot of people
  - In particular, women with night sweats

**Cotton blankets that Ashley recommends** (Ashley has no affiliation with these brands, nor does Peter):

- [Utopia](https://smile.amazon.com/gp/product/B00J82V60E/ref=ppx_yo_dt_b_search_asin_title?ie=UTF8&psc=1): Ashley has these; She layers several of them; They look flimsy but they are terrific
- [Sweet Home](https://smile.amazon.com/gp/product/B01DPSP98G/ref=ppx_yo_dt_b_search_asin_title?ie=UTF8&psc=1)
- [Waffle](https://www.amazon.com/dp/B08L7FWC2L?psc=1&ref=ppx_pop_dt_b_product_details)
- [American Blanket Company](https://www.americanblanketcompany.com/collections/best-cotton-blankets-made-in-usa/products/100-cotton-blankets-american-blanket-company)
- [Eddie Bauer](https://www.amazon.com/Eddie-Bauer-Herringbone-Blanket-Mushroom/dp/B00KDBJK4I?source=ps-sl-shoppingads-lpcontext&ref_=fplfs&smid=ATVPDKIKX0DER&th=1)
- [Coyuchi](https://www.coyuchi.com/products/cascade-organic-blanket)

***And people wake up less sometimes because they’re not giving their body this message that it’s time to wake up because they’re not as warm***

- 4 – It’s pretty hard to fall asleep when you have cold hands and feet
- People complain about their feet and their hands
- She tells them it’s fine to put your down comforter over the foot of your bed
  - You can wear some socks.

***She takes body temperature regulation very seriously, and sometimes it’s a quick fix and we don’t need a whole lot of muss and fuss***

Ashley asks, “*Have you ever tried to fall asleep when your hands and your feet are cold?*”

- We have data on from some interesting research in a totally different realm on people with extremity circulation disorders who have really cold hands and feet ([Raynaud’s](https://en.wikipedia.org/wiki/Raynaud_syndrome))
  - They will have early insomnia (which is difficulty falling asleep at the beginning of the night)
  - When they get successful treatment or when you warm their hands and their feet, it’s much easier to fall asleep
- The whole **warm foot bath** before bed thing, that’s an actual thing

**⇒** Your extremities help you dump heat

- So when you actually warm your hands and your feet, you can actually help dump heat from your core because your veins are dilating
- And when you fall asleep, you want to be dumping heat from your core
- That’s hard to do that when your veins are constricted in your hands and your feet

***For folks who have trouble falling asleep at the start of the night, we want to make sure that their hands and your feet are warm enough and that they’ve dealt with the thoughts and the worries during the day, and that they’re not trying to go to sleep at nine o’clock when their body doesn’t want to go to sleep until 11***

- 5 – Go to bed at the right time for your body
- A lot of people think they need to have this much time in bed each night
- And they get into bed and they struggle for 2 hours before their body actually wants to go to sleep

***A major part of CBT-I is aligning when your body can produce sleep with when you’re in your bed***

## The core principles of cognitive behavioral therapy (CBT) and how CBT-I is used to treat insomnia [20:00]

- We had a podcast on dialectical behavioral therapy (DBT) [[episode #219](https://peterattiamd.com/shireenrizvi/)], but we haven’t covered CBT

**Can you give us a little bit of the tapestry of what defines it and why it, of course then, has this additional subset of treatment for insomnia?**

*Ashley’s favorite way to think about this is a triangle*

**⇒** We have thoughts, we have feelings, and we have behaviors ‒  these are the 3 pieces that are all connected

- Cognitive behavioral therapies generally focus on intervening on the process between thoughts, feelings, and behavior ‒ on one of the sides of the triangle

![](https://peterattiamd.com/wp-content/uploads/2025/03/f1-ashleymason.png)

**Figure 1. CBT can intervene in any one of these connected processes**.

Example

- A patient with type 2 diabetes has the thought, “*I’m never going to be able to get my blood sugar under control*.”
- When a person has those thoughts, how do they feel? They feel bad about themselves
- When people feel bad about themselves, what do they do? Eat some chocolate cake
- What does that do? That reinforces the thought, “*I’m never going to be able to do this.*”

> “*We’ve got this pattern of thoughts, feelings, behavior on repeat.*”‒ Ashley Mason

***Cognitive behavioral therapies will choose where to intervene on a process in that triangle***

- CBT-I is really focused on the area between thoughts and feelings in many ways because people will have a lot of thoughts
  - I can’t sleep
  - I’m never going to be a good sleeper
  - If I don’t sleep 8 hours tonight, I’m going to lose my job, whatever
- And then the big emotions that follow from that

***We work on questioning a lot of those thoughts to then recalibrate the feelings that follow***

- Like, oh, if I don’t sleep 8 hours tonight, I won’t feel great tomorrow; but I’ll probably be okay at work
- The feeling is much smaller than if I don’t sleep 8 hours tonight, I’m going to lose my job tomorrow (they’re noticeably different)

Example

- In terms of depression, an example might be someone saying, “*Oh, I’m really depressed now, but when I feel better, I’m going to take my grandkids to the movies… I am going to take them to the zoo. I’m going to do all these things.*”

As a therapist, what Ashley might do

- Have the patient write all of this huge long list of stuff they’re going to do when they feel better
- Then she gets out their calendar with them and says, “*All right, I don’t care how you feel. We are scheduling all of these things*.”

***That’s an example of intervening on that behavior to the “thoughts line”***

**⇒** A major feature of cognitive behavioral therapies is intervening on behavior to change thoughts. But also intervening on thoughts to change feelings. And there’s many applications for this.

- Cognitive behavioral therapy has been adapted for a whole host of disorders, for eating disorders, for insomnia, specifically for anxiety
  - That’s going to be more in the thoughts and feelings realm too

Peter asks, “*Is that running the triangle in the other direction? So you change behavior to change thought and you change thought to change feeling?*”

- Yeah, so you can change thought to change feeling
- You can work on behavior to change thought
- You can operate on any way of those with different techniques that have been just repackaged into different therapies

**Tell me a little bit about the history of CBT-I specifically. When did the idea come to existence in a way that’s been packaged more or less the way it is today?**

- Cognitive behavioral therapy for insomnia is actually old news (1970s)

When Ashley was learning cognitive behavioral therapy for insomnia, one of the most fun studies to read about was this study of, college aged men who were not doing well academically

- And the **intervention** that they did with them was one of the two pillars of cognitive behavioral therapy for insomnia, which is called **stimulus control**
- They told these young men, “*You’re going to be assigned a carrel in the library and in this carrel is the only place you can study. You can’t study in your dorm, you can’t study outside, can’t study anywhere else. Just this carrel. And only this amount of time can you study each day.*”
  - They had to stick to the set amount of time
  - If they were on a roll, it didn’t change the study time
  - If they were miserable, it didn’t change the study time
- They trained these young men to just study in that one place, and it succeeded in helping these men
  - These were young men who were struggling academically

***This is an example of stimulus control, where we learn to associate a place with a behavior***

- Fast-forward, it was called the **Bootzin method** at one point for [Dick Bootzin](https://en.wikipedia.org/wiki/Richard_Bootzin)

**⇒** One of the hallmarks of cognitive behavioral therapy for insomnia is your bed is only for sleep and sex, but we really want to just associate the bed with sleep

*Going back to this study, were some of these guys studying in bed?*

- They were studying in their dorms, in their beds, and everywhere else
- This study wasn’t focusing on sleep per se
- It was just focused on this associative pattern that became the bedrock of this treatment
- We can go back even further and we can look at [Pavlovian conditioning](https://en.wikipedia.org/wiki/Classical_conditioning)
  - The dog and the bell and the food
  - The point just is that the dog came to associate the bell with getting food

**Back to people struggling with sleep**

- Many times when people are struggling with sleep, you know what they’re doing in their bed?
  - They’re reading
  - They’re scrolling
  - They’re watching TV
  - They’re listening to podcasts
- A lot of people, by the time they get to Ashley, they’re camping out in their bed just in case they’re able to sleep
  - Oh, I’m going to go have a snack in bed because if I’m sleepy enough, I’ll roll over and take a nap and I’ll get some extra z’s
  - People have moved so much of their lives into their beds that their bed is completely dissociated from sleep

⇒  Having the bed just be for sleep is one of the bedrocks of CBT-I

- [Ashley explained earlier that this is stimulus control]

**Another bedrock is what we call “time in bed restriction”**

- This used to be called sleep restriction, but in the last number of years it went from being called sleep restriction to time in bed restriction

**⇒** The other key component of CBT-I is that we restrict the amount of time that a patient is in bed to match how much time their body can actually produce sleep

- A lot of times people with insomnia will say, “*I need to be in bed for at least 12 hours if I want to get 7 hours of sleep*.”
- Ashley just obliterates that notion
- This is a very old part of CBT-I that dates back to the 1970s, 1980s

**Take those 2 parts and add in some of the cognitive components that have been also around for decades**

*The cognitive therapies part*

- The [Aaron Beck](https://en.wikipedia.org/wiki/Aaron_Beck) stuff with cognitive restructuring

Have you ever heard that phrase “*Don’t believe everything you think?*”

- 1 – Have patients write down the thought, write down how they feel, rate their feelings from say zero to 90%
- 2 – Then have them write down what’s the evidence for this thought?
  - If you had to go to court right now and there was a judge and a jury and what have you, and you had to present evidence for your thought, what would you be able to present
  - Example: last time I slept 6 hours, I got a worse grade on a test
  - We look at all the evidence for a thought
- 3 – We look at all the evidence against the thought
  - Example: the last time you didn’t sleep well, you didn’t get fired, you still did fine in school
- 4 – Then we create a balanced thought
  - Example: even though I’m not going to be as well rested, I’ll still get through this day
- 5 – Then we have people re-rate their emotions, re-rate how much they believe this new thought (this whole song and dance)

***This is the cognitive component that is the bedrock of so much of cognitive therapy***

- Of course, people have so many negative thoughts about sleep and dysfunctional thoughts about sleep that aren’t true or that are catastrophizing and whatnot
- That is also blended in to the treatment

*Relaxation techniques*

- These are things like [progressive muscle relaxation](https://en.wikipedia.org/wiki/Progressive_muscle_relaxation)
  - Where you squeeze your hands and let it go
  - And then squeeze your arms and let them go
  - You move through your whole body to get out of your head and into your body

**Core components of CBT-I**

- Ashley doesn’t know what order those were packaged into CBT-I, but the first 2 (the stimulus control and the time in bed restriction) were among the earliest parts of CBT-I

**⇒** What we know from dismantling studies is when you take either stimulus control or time in bed restriction out of the treatment, no dice [it doesn’t work]

## Implementing CBT-I: time in bed restriction, sleep scheduling, and the effect of napping [29:45]

**Time in bed restriction**

- Peter thinks time in bed restriction is pretty interesting
- In talking with sleep physicians who also implement this, it seems quite draconian at the outset
- It can be remarkably difficult
- They’re giving people 5 hours in bed, max
  - They’re really trying to force sleep pressure

**How do you navigate that, and how do you decide how hard to squeeze the tube of toothpaste?**

*Ashley draws a line in the sand between what CBT-I says broadly as a treatment and how she’s actually implemented it in her clinic*

- What CBT-I will have you do is complete something called a **sleep diary** that is a paper diary that covers 7 days
  - Because if Ashley asked you how well you slept 4 nights ago, you’d be like…
  - Peter compares this to a food frequency questionnaire in epidemiology (total waste of time)
- You have to complete the sleep diary every morning
- Ashley is not obsessed with it being exact
- She’s more interested in the picture pattern of it
- If you asked someone to fill it out for just 1 day and then worked with that, you’d have a totally distorted picture
  - You wouldn’t know what you’re working with
- What classic CBT-I does is they’ll take that 7-day sleep diary and then they will actually use it
  - The time you got in bed
  - Time you fell asleep
  - How many times you woke up
  - How long you were awake
  - What time you woke up
  - It has all of these different questions in it
  - [The book Ashley recommends later ([*Quiet Your Mind and Get to Sleep*](https://www.amazon.com/Quiet-Your-Mind-Get-Sleep/dp/1572246278/ref=sr_1_1?crid=1VKBUPLLZL8L2&dib=eyJ2IjoiMSJ9.H6FW_dhbQVNKuosnk4aotVjdtXnBtKjiGKoBLpqTAcTF_6RmBghgT1tZhrStFplrIDwYXetTvvojlv6-F8gQJH9tTAzK_Nmnlw4HhTgvJuKj0yv4d9vkjjkoslnONWCWBBhBFIQOrpA65wLhmRYR7qT9YRSWY94g-La4RnAcIZSqpq6OEt9abRcbx2olRnu9hZG79avjLSMryTPbKJLJxiMkTavlt9c9auPR1er_bbg.80fwYsa98Uk4X4OUjh76HxeXKvZjUnkv_adzDuvQQ1Q&dib_tag=se&keywords=Quiet+Your+Mind+and+Get+to+Sleep&qid=1738342261&sprefix=quiet+your+mind+and+get+to+sleep%2Caps%2C81&sr=8-1)) provides a diary template]

***You can use the sleep diary to calculate how much time a person was sleeping on average over the course of the week***

**How to pick a wake up time**

- CBT-I asks the patient, “*Why don’t you pick what time you want to get up every day?*”
- Let’s say your sleep blog said you were naturally sleeping 6 hours a night

**⇒** The clinician would add 30 minutes to that and make it 6.5 hours, and then work backwards from your chosen wake time

Example

- You chose a wake time of 7 A.M.
- Work back 6.5 hours to get to a bedtime of 12:30 A.M. ‒ that’s what classic CBT-I would do
  - That’s the bedtime of your childhood dreams (adults think this is torture, because it is)

**⇒** As far as Ashley knows, almost nobody is restricting less than 5.5 hours

- There are a subset of people who are genetically short sleepers
  - They have always been like this
  - It’s not upsetting, distressing, or causing them grief
  - We’re not talking about those people

**Clarifying the time of in bed restriction**

- If your body is naturally producing 6 hours of sleep, add 30 minutes (to get 6.5 hours in bed)
- If your body is only producing 5.5 hours of sleep, you get 6 hours in bed
- This computation is done for each person

Peter’s hypothetical sleep log

- For the past week, he’s spending 10-12 hours in bed but is only getting 6.5 hours of sleep each night
  - His recollection from looking at the clock when he’s not sleeping
- 6.5 hours is the sleep time, add 30 minutes to get to 7 hours of scheduled time in bed

**What Ashley does slightly differently for choosing a wake-up time**

- This whole theoretical underpinning is not disturbed by the way she does this

For the patient who says, I want to wake up at 5 A.M. to get my exercise in (or meal prep or whatever)

- She asks, “*What time do you get up now?*” 11 A.M.

Ashley explains, “*This whole part in CBT-I where people choose their wake time, that’s not a thing for me*.”

- Instead, she plays a **game called “Democracy within a Dictatorship”**
- Instead of just letting patients carte blanche choose their wake time, she looks at their sleep diary and lets them think they’re choosing their wake time
  - And if I agree with it, they will have chosen
  - If she doesn’t agree, the dictator comes in
- If their diary shows they’re getting up at 7:00 AM, 6:00 AM, 7:00 AM, 7:00 AM, 6:00 AM, 6:00 AM, 6:00 AM, and they say they want to wake up at 8:30
- She’ll say, “*Well, we have no evidence that you can sleep until 8:30. That’s not realistic, but we have evidence that you can sleep until 6:00 because 4 of the last 7 days, you made it until 6:00. So six o’clock is your wake time*.”
  - And this is not anywhere in CBT-I

**⇒** Ashley has spoken to a lot of her colleagues who do CBT-I and there is no standardized method to choose a wake time

- If she lets that patient choose 8:30 A.M. as their wake time, and they were only producing 6 hours of sleep, they would go to bed at 2:00 in the morning
- But really, they’re going to wake up at 6:00 or 7:00 and they’re not going to cash in on the full 6.5 hours of sleep that they should be getting in bed

***Ashely has added in this component of setting a reasonable wake time***

- She sees how much sleep their body is producing with this new wake time before giving them a bedtime

**A hypothetical sleep log with 5 hours of sleep at night**

- Let’s say the patient’s log shows 8 hours in bed, 5 hours of sleep at night and a 1 hour nap during the day
- Peter reasons: they’re removing all their sleep pressure during the day by taking that nap, but they need that nap
  - They’re in this viscous cycle

*Do you add the hour of nap time back to sleep to say they are getting 6 hours of sleep a day, so schedule for 6.5 hours in bed at night?*

- No
- We want to extinguish that sleeping during the day thing

**⇒** There’s a difference between a person without insomnia, healthily using naps, and then there’s a person with insomnia who’s napping to compensate for what’s not happening at night

**Ashley finishes the wake time example (because this directly ties into Peter’s question)**

- If she’s setting their wake time and then she sees how much time they’re actually producing sleep

**⇒** That first week when she gives them the wake time, she doesn’t give them a bedtime; she doesn’t even do time in bed restriction that first week because for some people, setting a wake time solves the issue (which is nuts)

- But 1-2 of every 8 patients who Ashley sees will have a huge improvement from just having a consistent wake time
  - Because their body actually recalibrates and they start getting sleepy at a more consistent time each night because they’re not doing that
  - She sees patients in groups of 8

**⇒** In that first week, she takes away the naps

- She doesn’t care how they slept at night, the need to stay awake until they are ready to go to sleep (no naps)
- With older patients (>80), she’s ok with a 25-minute nap
  - Set an alarm for 25 minutes
  - You set the alarm, get in bed, and get up when it goes off (she doesn’t care how long you slept)

***She doesn’t want you going into phase 3 or phase 4 (slow-wave deep sleep) during the day, because that’s going to really mess you up at night***

- A stage-2 nap is not really an issue during the day as much (it’s not as bad)
- At this stage of treatment for a person with insomnia, she doesn’t want them taking a 1-hour nap in the day

*After 1 week of trying the wake time*

- She recomputes how much time in bed they’re spending
- She keeps the same wake time and then calculated their bedtime

***True time in bed restriction begins in week 2***

Peter asks, “*Just to be clear, if you have someone who is using a nap to compensate for their insomnia, step one is just kill the nap?*”

- Yes, kill the nap
- Let the cards settle where they may for 1 week and recalculate sleep time

**Peter’s question about his sleep schedule during a bow hunting trip**

- He’s going to be insanely late and waking up insanely early
  - It’s just the nature of when you get back to camp and eat, and then you got to be up super early
- He’s never been on one of these trips where he could actually be in bed for more than 5-6 hours in a night
- So the strategy is to get that sleep, but then he always try to get a 90-minute nap at around 1:00 in the afternoon
  - The reason he picked 90 minutes is to get a full sleep cycle
- He tends to function incredibly well under those circumstances because he’s also very physically active

Peter asks, “*Would I be better off not doing that nap midday?*”

- That is a bow hunting trip and you don’t have insomnia; that’s not a problem
  - Totally different monster

**Ashley tells people who have had a serious illness**

- They’ve had COVID, they’ve had whatever

**⇒** When you’re sick, all bets are off; if you need a nap when you’re sick, you need, but we maintain stimulus control

*How to maintain stimulus control when you’re sick*

- You don’t nap on the couch
- We’re only napping in bed
- And if you’re awake and feeling sick, then you can be on the couch, not in bed

## Navigating family and partner sleep schedules, falling asleep on the couch, sleep chronotypes, and more [39:45]

**What do you say to the legions of people watching who fall asleep watching TV on the couch?**

- That’s the worst
- A lot of people fall asleep on the couch because they’re just so overtired that the ship has sailed
  - Their body’s ready to go to bed and they’re just letting it and they’re not getting up and doing the thing

If you want to prioritize your sleep, pay attention to your body

- When you’re watching TV, do you notice that you’re starting to nod off?
- Do you notice your eyelids feeling heavier, your hand’s feeling warmer?
- Are you starting to sag a little bit?

***These are indicators that it’s probably time to get off the couch and go to bed***

- For people who can’t figure that out: sit in a stool while you watch TV
  - You’re going to figure it out real fast

*What about just the social dynamic of it?*

- When you have a couple, and one part of that couple wants to watch TV together, but one member falls asleep immediately while the other does not
- Ashley sees a lot of these couple-level issues in the sleep clinic
- This is not uncommon because what’s more intimate than being completely unconscious next to another person, if you think about it?
  - Evolutionarily, that’s probably the riskiest thing you can do
- There is this desire for closeness in lots of couples, and it becomes a challenge when one of the members of the couple has a sleep problem

The first step is remembering this is not necessarily permanent

- We need to go about fixing this now and then we can find a new winning solution
- Assuming you’ve already tried maybe watching something different on TV that might be more exciting to the second partner
  - It’s not about the boringness of the show per se
- In the interim, if this is a priority, schedule it
  - Schedule time to be on the couch together at a time where both can be awake and spend meaningful time together
- The problem is sometimes other members of the family who tend to be smaller also tend to be occupying all of the bandwidth during those earlier hours when the member of the family in question is able to be awake
- This is a hard problem

***If you’re actually ready to go to bed and your body is saying that you need to sleep, you should probably do that***

- It’s more likely that then you’ll be awake the next day and be a more pleasant, exciting partner to be around and be able to have more meaningful experiences with your partner that way

***If it’s really an issue, get a babysitter (figure it out)***

*Peter’s situation*

- If Peter’s wife falls asleep every single time on the couch, but then when said Netflix is over and we go up to bed, she falls right back asleep and it doesn’t seem to keep her awake
- Is it pathologic?
- Ashley explains, “*This isn’t necessarily a problem, but what I would say is we sleep more deeply at the beginning of the night.*”
  - We experience more [slow wave sleep](https://en.wikipedia.org/wiki/Sleep#Non-REM_and_REM_sleep) in the first half of the night and more REM sleep in the second half of the night
  - Other podcast guests on *The Drive* can definitely go into the neurobiology of this much more deeply [[episode #47](https://peterattiamd.com/matthewwalker1/#:~:text=sleep%20at%20night.%E2%80%9D-,Stages%20of%20sleep%2C%20sleep%20cycles%2C%20and%20brainwaves%20%5B40%3A15%5D,-Humans%20(Mammals)%20have) after 40:15]

**The way Ashley likes to explain this this has to do with evolution**

- If you think about it, when we’re deeply, deeply asleep, we’re tuned out
  - And on the prairie when we figured it’s safe to go to sleep right now.
  - Our bodies prioritized getting that really deep sleep when we knew it was safe
- And then as the night goes on, we sleep more and more lightly
  - Which makes sense because hey, there could be lions and tigers around or whatever that are going to come and eat us

***So evolutionarily speaking, it was adaptive to sleep more deeply in the first half of the night***

The drawback of the situation Peter just described

- If your wife is falling asleep on the couch and getting some of that [deep] sleep at that stage of the night and maybe getting more interrupted aspects of that because there’s noise from the TV or whatnot, it could be disturbing the quality of her sleep

**Night owls and early morning larks**

- It also makes sense that evolutionarily that there is diversity in people who were night owls and early morning larks
- We needed that diversity in order to keep the tribe safe from the threats on the prairie
  - Some people were staying up late; okay, no lions
  - Some people were up early; okay, no lions

⇒ There’s nothing pathologic about being a person who’s going to be more likely to fall asleep earlier (or being a person who’s more of a night owl)

- It’s very hard to change that ‒ a lot of patients want to change it
- Peter recalls that there are 2-3 archetypes of that
  - There’s a circadian rhythm test you can take online that gives you a sense of it
    - [[MEQ test](https://qxmd.com/calculate/calculator_829/morningness-eveningness-questionnaire-meq) discussed in [episode #126](https://peterattiamd.com/matthewwalker4/#:~:text=from%20a%20physician.-,Understanding%20sleep%20chronotypes%20and%20how%20knowing%20yours%20could%20help%20you%20%5B1%3A06%3A00%5D,-Determining%20and%20understanding) after 1:06:00]
  - It’s self-evident if you pay attention to your patterns
- Ashley is not so concerned about these tests

***She’s more concerned about what’s the problem that’s messing up your life right now and how can we work around that?***

## Key aspects of sleep hygiene: temperature, light exposure, and circadian rhythm disruptions [44:45]

**The impact of temperature on sleep**

- They discussed temperature earlier
- Nowadays, we have these incredible devices that can cool our mattresses and things of that nature
  - Clearly, not everybody needs to buy a mattress cooling device if they can’t afford it, that shouldn’t be an impediment to sleep
- Obviously, we have air conditioning that can cool the room

*Do you have a preference for one or the other?*

*Do you have a room temp set?*

- Peter typically talks about the mid-60s as an ideal room temp
- Mid-60s is terrific
- People will often say, “*My feet*”
  - We have wonderful solutions for that: socks
  - Put a tiny heating pad at the foot of your bed, it’s got an auto-shutoff

***A cool room is definitely key, and insert Ashley’s refrain about down comforters, duvets, etc. Get cotton blankets; get cotton sheets***

**The impact of light on sleep**

*Do we need to have it so pitch black, you can’t see your hand in front of your face? Do we need to block the moonlight? How dark do we need it to be?*

- If you closed your eyes right now, you’d be able to tell that it’s light in this room
- We can sense light through our closed eyelids
  - And many women would tell you that their eyelids seem to get thinner as they age

**⇒** An eye mask is a great addition, and this is for a lot of people with early morning awakenings

- An eye mask can be a game-changer because people don’t realize that what’s causing their early morning awakenings is a little bit of light getting into the wrong part of their eye, indicating it’s time to be awake right now
- Ashley doesn’t know the details on what wavelength of light that is or what necessarily the light is coming from, whether it’s a light outside from the sun or the moon, whatever it might be
- The point just is a lot of folks with early morning awakening can really benefit from having something covering their eyes, whether it’s a sleep mask or a hat that goes down

***Ashley is a big fan of making your room dark***

- She’s one of those people who travels with a roll of black electrical tape because you go to a hotel room and there’s like 50,000 lights everywhere
- She uses an eye mask but is one of those people who rips my eye mask off in the middle of the night

**⇒** If there’s egregious lights in a room, cover them with electrical tape; unplug alarm clocks

- Microwaves are the worst, the blinking time

**The cooling mattress**

- Ashley is intrigued by this but also concerned about it
- It seems that a lot of these mattresses have settings where you can make it cooler, but also, you could make it warmer

She worries about 2 things

- 1 – She worries about messing with our circadian temperature biology
- Remember in the 1980s for a hot minute when **electric blankets** were really popular, and all of a sudden, they’re not
- They starting to see associations between electric blanket use and some cancers
- At the time, there was a lot of speculation that this was related to EMF, but the great thing that time does is it gives us more perspective, and there are some indications that actually, that might’ve been **messing with circadian temperature** and that might’ve been part of the issue
- We know that night shift work is carcinogenic
- Peter knows there’s an association between night shift work and cancer, but he questions if it’s really causal
- Ashley thinks if we go [Bradford Hill](https://en.wikipedia.org/wiki/Bradford_Hill_criteria) on this and we look at temporality, she thinks there are age-matched case control studies where they can control for history effects to see are people getting more and less cancers?
- It is tricky because if, for example, you look at firefighters, they’re way more likely to get cancer
  - They have way more chemical exposures and other things in the mix
- Some of the classic studies have been done with hospital workers, also confounding effects

Peter asks, “*How do we get around the confounding effects of the obvious dietary shifts that occur in people when they’re working under those conditions? If I think back to how I ate in residency or how I eat after a night of poor sleep, to me, that would be more the cause. I’d put more of that on the metabolic ill-health that might result, but carry on.*”

**It’s often hard for people to sleep during the day**

- Making that change from going to sleep at night to being a person who sleeps during the day, for some people, it’s not even possible
- Some night shift workers sleep very little because they just can’t sleep during the day
  - They’re not able to flip their circadian biology

***There’s a whole history looking at disruptions in circadian temperature as one of the most common circadian disruptions in mental health disorders***

**Going back to the cancer thing, what would be the believed mechanism of action?**

- Ashley would talk to an oncologist and talk to a circadian biology person about that

***Her understanding that electric blankets are no longer here with us and very common because there were these observed ill-health effects, whether they’re due to EMF or whether they’re due to messing with your body temperature at night***

**Ashley’s concern about interventions like temperature-regulating mattresses**

- What concerns her about some of the exogenous interventions like mattresses that might heat up is there’s supposed to be a normal circadian temperature rhythm that we do during the day and during the night
- And when we start imposing things on that, some of these mattresses can actually be set to cycle at different temperatures during the night and all of these things

Full disclosure: Peter is an advisor to the company [[Eight Sleep](https://www.eightsleep.com/)] that makes cooling mattresses [A full list of disclosures can be found on his [website](https://peterattiamd.com/disclosures/)]

- The mattress that Peter uses allows you to change how cold it is throughout the night
  - The settings go from 0 to -10
  - With -10 being the coldest; zero is no change in temperature
  - It’s a point scale (not degrees)
- When he gets in bed, he has it at -5, and then he runs it down to -10, and brings it up to -5 in the morning
  - So he’s taking it from cold, to really cold, then back up to cold

*Ashley’s concern is that people would heat themselves with these things*

- That gets to the point which we know we don’t want to be warm
  - We don’t want the duvet
- A lot of people get in bed and they don’t like feeling cold because it is easier to fall asleep when your hands and your feet and your skin is warmer
- So people will maybe mistakenly do this for more of the night than they should

***Ashley is concerned that our circadian temperature rhythm is an exquisitely controlled system and a 10-point scale on a device pales in comparison to the complexity of what our bodies need to do in terms of temperature during the night***

Peter adds, “*The good news is if you can keep your room at 65, none of this matters.*”

**Hotels are the worst**

- Some mattresses are just hot ‒ don’t get those

**⇒** You want to be really careful to make sure that you can be cool in your bed

- The easiest way to do that would be keeping your room cool

## Blue light and mental stimulation before bed, and the utility of A-B testing sleep habits [52:45]

**What about blue light before bed?**

- Peter has looked at these data quite a bit, and 6 years ago, he was in the camp of every light had to be red
  - He had his phone shifted into a red light phase, his computer
  - He had all these apps that managed this, so as soon as the sun went down, blue light was removed from his electronics
- Today, Peter sleeps subjectively and objectively better (if you can believe what a sleep tractor tells you) by paying attention to what he’s consuming, not taking blue light out of his devices

**Peter’s new hypothesis** has become it’s not the blue light that is the problem, it’s the stimulus that often comes with the blue light

- In other words, not looking at social media (regardless of light color) has a far greater positive impact on his sleep

*Ashley completely agrees*

- We didn’t evolve for the neural experience of Instagram (we’re not ready for that)
- Regardless of what color light you’re getting your Instagram on, that’s probably not helpful before you go to bed.

***The larger problem is not necessarily the blue light, but is the thing that we’re interacting with, whether it’s an iPad or a phone or a computer***

- Because typically, those things are going to involve social media, work, email, all of these other things that are much more potent disruptors of sleep than the blue light itself

**Caveat**

- Ashley has had a few patients who they were not using Instagram before bed, nothing stressful or stimulating
- She recently finished with a patient who found that using **orange-colored glasses** (not those beautiful blue-light blocking glasses that have clear lenses) **2 hours before bed** completely ameliorates their sleep onset insomnia
  - Such that they were able to almost immediately quit [Ambien](https://en.wikipedia.org/wiki/Zolpidem)

> “*The beauty of these interventions is if you can isolate them to one change at a time, you can be empirical about it.*”‒ Peter Attia

**Peter’s takeaway on these interventions**

- Something like wearing glasses is benign ‒ you’re only out the money you spend on them; and if it works, great
- If you really want to test it, take them off and see if your symptoms return
- And if they don’t, maybe it fixed you
- Maybe it wasn’t that
- Peter tries not to be terribly dogmatic about this stuff
- He also thinks that when people go to great lengths to remove blue light without removing stimulus, they’re missing the boat a little bit
- For Peter, social media is not much of a stimulus actually, because he doesn’t pay that much attention to it
- But work is [a stimulus]
  - The single worst thing he can do right before bed is look at email
- Whereas watching something mindless on Netflix for an hour is a totally beautiful way for him to be distracted
  - A big bright screen of Netflix doesn’t seem to impact him

*Comparing work and TV*

- Ashley points out that one is much more interactive and stressful, and one is very passive
  - Watching a movie has no bearing on your life

**Ashley’s advice on testing one of these interventions**

- When you want to test one of these “low-hanging fruit” interventions (she calls it A-B testing), you want to collect your own data on a paper sleep diary for 2 weeks

**⇒** You must make the change for 2 weeks and keep a sleep diary to track any effect

![](https://peterattiamd.com/wp-content/uploads/2025/03/f2-ashleymason.png)

**Figure 2. Sleep diary Peter uses with patients to track the effect of interventions on sleep**.

- Track the effect with a simple worksheet
- The one Peter gives patients is shown above
  - Record a “C” when you had caffeine
  - Record “A” when you had alcohol
  - Record “E” for exercise
  - Record when you were in bed and when you were sleeping by shading
- Ashley’s worksheet [shown below] is just enough to get the information that she will act on and nothing else
  - [sleep [diary](https://www.sealab.ucsf.edu/sites/g/files/tkssra9166/f/wysiwyg/Sleep%20Diary%20-%20Fill%20In%20Days_0.pdf) she uses with patients and [instructions](https://www.sealab.ucsf.edu/sites/g/files/tkssra9166/f/wysiwyg/Sleep%20Diary%20Instructions.pdf)]

![](https://peterattiamd.com/wp-content/uploads/2025/03/f3-ashleymason.png)

**Figure 3. Sleep diary Ashley uses with patients**. Image credit: [UCSF](https://www.sealab.ucsf.edu/sites/g/files/tkssra9166/f/wysiwyg/Sleep%20Diary%20-%20Fill%20In%20Days_0.pdf)

## Other simple interventions that may improve sleep [57:30]

**1 – Back to the glasses**

- If you have difficulty falling asleep at the beginning of the night (what she calls “early insomnia”)
- And you’re already not looking at your email, not doing Instagram
- It’s worth trying these glasses for 2 hours a night, for 2 weeks, and see what happens
- Ashley has no affiliations with any of these things
- You can get some nice, ugly glasses from [lowbluelights.com](http://lowbluelights.com)
  - They look like motorcycle goggles
- Ashley thinks the wraparound feature is important because if we’re going for it, let’s go for it

**2 – Talk to your physician about your medications**

- Ashley is not a physician but she works with a ton of them and learned this from an anesthesiologist

**⇒** All medications have circadian effects (all of them)

- Make sure you are taking your medications at the same time every day, and at the right time of day

For example

- Ashley had a patient coming in saying that they were taking 450 milligrams of [bupropion](https://en.wikipedia.org/wiki/Bupropion) for depression before bed
  - That’s going to be a pretty stimulating dose of something to take before bed

***Make sure that you go over your medications with your doctor, and that you’re taking them at the optimal times of day and be really consistent with your medications***

**Amount of caffeine in decaffeinated coffee and regular Starbucks coffee**

- There are speculations that decaf coffee can have as much as 15-30% of the caffeine that regular coffee has
  - There are some [data](https://pubmed.ncbi.nlm.nih.gov/17132260/) from 2006 that were published saying that 15-ish percent

More recent [data](https://pmc.ncbi.nlm.nih.gov/articles/PMC11314177/) have shown that Starbucks, I think says that their 12 ounce has 155 mg of caffeine, but outside laboratory testing [found](https://pubmed.ncbi.nlm.nih.gov/14607010/) something like 310 mg

![](https://peterattiamd.com/wp-content/uploads/2025/03/f4-ashleymason.png)

**Figure 4. Caffeine content of Starbucks Breakfast Blend tested on different days**. Image credit: [*Journal of Analytical Toxicology* 2003](https://pubmed.ncbi.nlm.nih.gov/14607010/)

**3 – Ashley tells patients to be done with caffeine at 11 A.M.**

- Unless there’s an extreme phase delay or phase advance

Defining a phase advance and a phase delay

- A **phase delay** is when you go to bed really late and you wake up really late
  - Someone going to bed at 3:00 AM and I’m waking up at 10:00 AM
- A **phase advance** is when you wake up really early and you go to bed really early
  - Someone who’s waking up at 3:30 in the morning and going to bed at 8:00 PM, that would be a phase advance
- In those cases, Ashley might do something different with caffeine
- But most people are neither of those cases, so the caffeine cut-off is 11:00
- Caffeine withdrawal can cause a lot of damage, and she doesn’t think it’s necessary

***Don’t change how much coffee you’re drinking, just drink it all before 11:00***

*What fraction of people are such rapid caffeine metabolizers that they seem immune to caffeine and sleep?*

- Ashley thinks that person doesn’t exist
- The normal caffeine half-life is 4-6 hours
- Even if you take someone who’s 4 hours, you still have half a cup of coffee after 8 hours
- And if you have a tall coffee from Starbucks at 2:00 P.M., and it actually had 310 mg of caffeine in it (a lot of contingencies)…
  - [Half of that caffeine is around at 6 P.M., one quarter of that is around at 10 P.M.]

**⇒** Stop drinking decaf coffee after dinner makes a world of difference for sleep quality

- People will say that they fall asleep just fine, but it’s affecting the electrical quality of sleep throughout the whole night
  - A sleep neurologist could tell you more about that

***For a person who’s trying to fix insomnia, having 2 decaf coffees after dinner every night could add up to make their sleep less restful***

**Other obvious things to “A-B test” for 2 weeks?**

4 – Don’t fall asleep with podcasts on

## Ashley’s view on relaxation techniques and mindfulness-based practices [1:02:30]

**Relaxation techniques**

*Where does mindfulness-based practice come into it?*

Peter points out

- Anyone who’s done mindfulness-based meditation probably appreciates how difficult it is
- It’s not like transcendental meditation where you’re focusing on a mantra
- You’re instead focusing on a sensation (typically breathing), on body awareness

*Is that counterproductive or is it productive as you’re laying there awake?*

- Ashley’s unsatisfying answer is: it depends (because there’s moderator variables)

When it comes to CBT-I, what’s been tested is [progressive muscle relaxation](https://en.wikipedia.org/wiki/Progressive_muscle_relaxation)

- Which you could argue is a form of a body scan
- Which is part of many mindfulness practices where you scan your whole body, you think about your hands, you notice how they’re feeling, are they warm? Are they soft? (whatnot); and you move through your whole body
- With progressive muscle relaxation, you squeeze your hands and you let them go (repeat)
- It’s more of an active process that you’re paying attention to throughout your body

***Doing progressive muscle relaxation in bed right before you fall asleep for a few minutes is fine***

- That’s the one exception to the sleep and sex rule
- It’s also fine to practice this in other parts of your house (you don’t have to just be in bed)
- The body scan and mindfulness in general has been studied in combination with CBT-I and what the data have shown is somewhat fascinating

⇒ There’s no actual differential improvement on sleep duration or metrics of sleep

- But people like the mindfulness stuff; they report they’re more happy with it
  - They like doing that

***In terms of improvements in sleep outcomes, Ashley doesn’t think it adds too much to CBT-I***

*Ashley’s summary about mindfulness techniques*

- There’s a lot of practical uses for it, for helping yourself when you’re in psychological states you don’t want to be in
- It’s a great way to be in life

***When it comes to sleep, you do not need to start a mindfulness practice to improve your sleep***

## The effectiveness of CBT-I, the role of sleep trackers, and best practices for managing nighttime awakenings [1:04:15]

**The effects of CBT-I**

- When it’s done well, 50-60% of people can get remission
- And 70% can get clinically meaningful improvement in their sleep
- In the world of psychological treatments, that’s really good

*Of the 30% that do not see a clinically meaningful improvement in sleep with CBT-I, why does the treatment fail?*

- The treatment fails when people don’t do it

Peter asks, “*So in other words, we’re really saying 30% of people are not able to adhere to the treatment?*”

- Ashley wouldn’t go that far
- There are some people who are genetically short sleepers, and at some point this may become distressing for them

Example

- Ashley had a patient who was in her 70s complaining that her sleep was not good
- The lady had a volunteer job, was really active, did a full workout plan
- Ashley replied, “*You’re really rushing it lady. What’s the problem exactly?*”
- The lady joined a study and had to wear a device that tracked her sleep, and every morning it said she was not sleeping well and was at risk for different things

**⇒** Get rid of the sleep tracker

**When do you tell people to take the sleep tracker off?**

- Peter will have patients take a 6-month tracker holiday

*Is that mainstay part of the treatment to get all that anxiety out of there?*

- For people with insomnia, Ashley tells them to take off the tracker
- People wait a year and half to get into her clinic, and she tells them to take off the tracker

**Back to the 30% of people who are genetically short sleepers**

- When they become stressed about their sleep, they’re not going to be helped by CBT-I
- There’s nothing to fix
- But they’re presenting, so Ashley puts them in the group

**There’s a huge body of data on CBT-I**

- [see the “selected links” section at the end]
- We know that when people don’t do the treatment, it doesn’t work
- Adherence is a major, major component
- Duration of treatment also matters
  - It seems that if you do 4 or more sessions with a therapist doing the CBT-I, your outcomes are going to be way better than if you try and cut it way short with 1 or 2
- Ashley’s treatment is 5 sessions
  - Intake
  - 5 treatment sessions, spaced 1 week apart
    - If you’re going to miss a week, you have to wait for the next cycle
  - Then a follow-up where we just tidy things up

**Given that people are waiting a year and a half to see Ashley, that tells Peter that there’s a mismatch on the supply-demand curve. Why is that the case?**

**⇒** There’s a great [directory](https://www.behavioralsleep.org/index.php/directory/all) at The Society of Behavioral Sleep Medicine

- That is how you would find a provider who definitely knows how to do CBT-I
- One of the major problems comes down to psychologists and providers taking **insurance**

**⇒** A lot of the best folks there in private practice, they don’t take insurance, and you could be paying hundreds of dollars a session to see them

- They’re pretty backed up as it is
- Ashley is fortunate to work at UCSF at the [Osher Center for Integrative Health](https://www.sealab.ucsf.edu/oshercentersleep), and they take Medicare and all kinds of insurance
  - So people can pay minimal or nonexistent copays to see her
- There are other CBT-I providers at UCSF, and their wait lists are long too
- In order to see patients now with any volume, Ashley doesn’t see individual patients, she sees 8 patients at a time in group medical visits
  - All 8 patients get together for 90 minutes every week to get it done

**What will it take for AI to replicate what you are doing to scale this much more?**

- A lot of the work Peter does can be done by AI

*How much of the art and science of this is teachable to* [*LLMs*](https://en.wikipedia.org/wiki/Large_language_model)*, at least as another offering?*

- Peter is not saying it should ever displace what a therapist is doing
- But with this backlog of people, shouldn’t we have an alternative
  - An online course that could give you 70% of the value of what you might get sitting in the group with Ashley

Ashley explains the issue

- There are some CBT-I smartphone app interventions out there, and Ashley has had patients try these while their waiting
- They report that it might have helped a little bit

> “*I think the major issue is that many, many people with sleep problems think that their sleep problem is unique. It’s special. This can’t be treated by just a generic app*.”‒ Ashley Mason

- The joy of having a group is that people can hear that everybody’s problems are different, and Ashley going to treat them all the same way
  - They are going to do the same things
  - They might do it at different times, but they’re all going to do the same things

***There is a world where AI can help with the personalization aspect***

**Ashley is helping a company that’s making an app called** [**Rest**](https://getrest.app/)

- They’re using AI to calculate someone’s wake time, the way Ashley does (which is not standard in CBT-I)
- They’re able to do more tailoring

Ashley explains, “*The ‘biggest fly in the ointment’ for this is getting patients to look at the fact that they’ve been assigned to wake up at the same time every day for the next 7 days.*”

**⇒** Getting patients to wake up at the same time every day is going to be really hard

*Ashley has patients watch a 10-minute video before they enroll in her clinic*

- It’s a scary video
- Ashley tells them this is going to be hard and they are going to hate her
- She explains, “*You are going to suffer in the beginning of this treatment, but guess what? You have been suffering for months or years. Now you’re going to suffer for five weeks. You’re going to do it my way. If you don’t like it, you can go back to your way. This is five weeks of your life. How bad can it be? How much worse can it get?*”
- She does a pep-talk video
  - This is the biggest problem in your life at that moment
  - Sleep is a 24-hour a day problem
  - This is not just a problem at night; it’s affecting you all day

***It’s a lot to trust an algorithm or app to know how you should really do these things (that’s a big ask)***

Peter asks, “*When you’re giving them that boot camp speech, is the time in bed restriction typically the thing that causes the most distress?*”

- Patient don’t know about that at that stage
- She just tells them, “*It’s going to be really hard. You’re going to get worse before you get better.*”
- Because everybody sleeps less the first couple of weeks while we’re getting all these things lined up
- For some people, what ends up being the hardest is the wake time because they’re used to just sleeping in whenever they can
  - Or catching up on those hours when they can
- For other people, the super late bedtime that Ashley gives them, that’s what crushes them
- The great news is that we dial it back over time

**There’s a benchmark for sleep efficiency**

**⇒** We define sleep efficiency as the amount of time that you’re in bed sleeping divided by the entire time that you’re spending in bed

***The benchmark is 85%***

- Each week, Ashley calculates sleep efficiency from people’s paper sleep diaries

**⇒** Once we do time in bed restriction, if they are above 85%, Ashley moves their bedtime back 15 minutes

- Then if that’s the same for another week, you move back another 15 minutes
- People say, “*15 minutes, what? Who cares?*”
  - After 4 weeks, that’s an extra hour every night (that’s huge)

**Are people able to, with a high enough fidelity, report awake time in bed?**

- For example, if Peter were doing this, he’s got a clock next to his bed he can look at
- If his time in bed tonight is 11 and his wake-up time is 5:30

Peter asks, “*How do I know what time I fell asleep?*”

- Ashley is looking for the difference between 5 minutes and 50 minutes (for the time it takes to fall asleep)
- When you’re waking in the middle of the night, you’re getting out of bed and can look at the clock

**When you get out of bed in the middle of the night you can do a very fun and potentially embarrassing activity**

- Embarrassing meaning if your boss caught you doing this activity during the work day, you should feel embarrassed
- For example, reading People Magazine or reading some trashy magazine, you wouldn’t want to be caught at your desk doing that at work
- That’s exactly what you should be doing in the middle of the night

- When you wake up at 2:00 in the morning and can’t go back to sleep, go and do something that is not productive (not rewarding in that way, so you’re not building a pattern around it)
- Peter wouldn’t be able to get up and do the online chess thing he loves
- Ashley tells people they can play solitaire
  - Adult coloring books
- No checking email or work-related activities
- No scrolling social media
  - Although that meets the criteria of you wouldn’t want your boss catching you doing it
- It’s fine to read for pleasure
- Don’t read about global warming, current events, politics, pandemics (or anything stressful)

***There’s a narrow subset of activities that you are going to get out of bed to do: stuff that is kind of boring but entertaining enough***

- We don’t want you to get a habit of looking forward to doing something in the middle of the night
  - This happens with parents who might be busy all day with their kids and their family’s needs and everything else; then in the middle of the night, they wake up and it’s like, “*Oh, this is me time. This is when I’m going to do all these really fun things that I don’t get to do during the day*.”
  - We don’t want to make a habit of “you time” being between 3:00 and 4:00 AM
    - That’s really when you want you to be sleeping
    - Sometimes you have to schedule that stuff during the day
- We want the stuff in the middle of the night to be mildly boring
- It’s okay to watch a 20 minute episode of a sitcom

After this, check-in with your body and ask, “*Am I ready to go back to sleep?*”

- Then you can go back to sleep

***When you get out of bed in the middle of the night, you do a different activity, you’re resetting, and then you’re going back to sleep (instead of just having stewed in bed that whole time)***

- It’s much easier to fall back to sleep when you have that reset

## Guidance on intake of food and alcohol for good sleep [1:16:30]

**What’s the checklist you run through with clients?**

⇒ Try not to eat within 3 hours of going to bed

- Since we’re dealing with so much life, Ashely doesn’t mess with their food
- Rarely she’ll have a nighttime binge-eating disorder to deal with at the same time, or a blood glucose issue and diabetes that’s poorly controlled ‒ she’s going to put those cases aside for just a moment

⇒ During the 5 weeks of the clinic, nobody’s drinking

- The reason for this is that in order for Ashley to actually see what’s going on with your sleep, she needs to see this with the least perturbation possible

⇒ Alcohol and marijuana are things that perturb sleep

- Now, if people are using a lot of marijuana or a lot of alcohol, she’s not here to put people into withdrawal
  - Before people come to their first group (during intake), she’ll ask about their alcohol intake
- For example, she just finished with a person who was drinking 16-20 ounces of wine at night
  - She had them drink just 2 ounces of wine at night
  - Then using that same glass, drink something else (juice, bubbly water, something special but non-alcoholic)
  - She makes sure they can do that before they start treatment (generally they can)
- She wants people to be consistent
  - If they were drinking every night, then it’s drink 2 ounces of wine a night
  - If they were having 3 drinks a week, then it’s stop drinking

## Reframing thoughts and nighttime anxiety to reduce sleep disruptions [1:18:45]

**Are there any specific cognitive techniques that people are instructed to be working on when they first wake up?**

- No
- It’s all behavior
- As a CBT-I purist, Ashley doesn’t involve the cognitive techniques until week 3 (of 5)
  - That’s when she gets into scheduled worry time and working with the thought records

**When patients wakes up worrying about something**

- Ashley had a patient that would wake up every night at 1:00 A.M. worried about “thing A”
- She had him track how worried he was about “thing A” all day, every couple hours
- This is called **“tracking degree of belief in a thought”**

Example

- A patient with multiple sclerosis, in their early 30s
  - That’s a debilitating disease to have when you’re that young, working a full-time job
- They would jolt awake every morning at 7:00 A.M. thinking, “*I’m never going to make it through this day. My whole body hurts. This is a mess. I’m never going to be able to do this.*”
- She would lay in bed for 2 hours until 9:00 A.M. thinking these thoughts
- By 9:00, she’d get out of bed, she’d shower, she’d get to work by 10:00
  - Because in the Bay Area, all these startups don’t start till like 10:00
- She’d get her coffee, work with her assistants, do her meetings
- And if Ashley asked  her, “*How much do you believe that thought ‘I’m never going to make it through this day?’ at noon,*” she’d probably say, “*Oh, like 60%. This afternoon’s going to be rough. I don’t know if I’m going to make it through.*”
- But if you ask her at 5:30 when she’s done working, she’ll be like, “*Oh, I made it. 0%.*”

***Day after day, she started realizing that she didn’t believe the thought she was having at 7 A.M.***

- She didn’t believe this thought because it’s true, she believed it because it was 7:00 A.M.
- Once she made that connection, she was able to recapture her mornings
- At 7:00 A.M. she went and sat on her couch and started doing something she loved until 9:00 A.M.
  - Which for her was learning Italian with an app
- That used to be her most hated time of the day, but by the end of treatment, it was her most beloved part of the day
  - Because no one was bothering her, and she could learn Italian and whatnot

***One of the cognitive tools Ashley has built into CBT-I is tracking how much you believe a thought over a given day ‒ if you believe a thought in different levels throughout the day, how true can it really be?***

- It’s really enlightening
- Notice what you’re thinking about at 1:00 A.M. and then see how worried you are or how much you believe this the next day at 3:00 P.M.
  - How come this deserves airtime at 1:00 A.M. but not 3:00 P.M.?

## Ashley’s take on sleep supplements like melatonin [1:21:45]

**Do you ask patients to do a purge of supplements?**

*When they come to you and say they’ve been taking melatonin every night or are on ashwagandha drip*

**⇒** A [study](https://pubmed.ncbi.nlm.nih.gov/37097362/) of melatonin supplements found they either had none of what they said in it or more

- Peter did a [newsletter](https://peterattiamd.com/melatonin-content-in-sleep-supplements/) on this
- Let’s assume the patient is taking melatonin from a company that submits to third-party testing, so they know the dose
- Let’s further posit that they’re not taking a dose that is deemed too high
- Peter points out, if you look at some of the sleep literature, there seems to be most people would agree anything north of 1 mg is probably too much
- Whereas there might be some benefit in the 300-600 microgram range (and more importantly, safety)
  - You’re not down-regulating melatonin receptors
  - You’re offsetting the natural decline in melatonin levels over time
    - Peter can tell from Ashley’s face that she doesn’t agree with any of this

It’s hard to know where to go with this question

- In some countries you need a prescription for melatonin (it’s regulated), you’re not going to find it at Walgreens
- But in the US, taking too much can’t kill you, so here you go

***By the time patients get to Ashley, they have a huge list of supplements and they still have their sleep problem***

- She tells patients, “*Clearly these aren’t doing what you want*.”
- She doesn’t know what’s in all of those things because none of that’s regulated

**⇒** The data for things like [ashwagandha](https://en.wikipedia.org/wiki/Withania_somnifera) and melatonin are pretty weak

- There are a few exceptions for melatonin

***To Peter’s question, yes, Ashley takes people off this stuff***

- If they want to take it after treatment, great
- She wants to get rid of it and see what their body is actually doing
- Chances are, you’ve been adding a supplement of 2 over time for years, and we don’t even know what your body wants to do now
- You could actually be shooting yourself in the foot with some of these things

Exceptions

- On the contrary, a patient could be taking a [beta blocker](https://en.wikipedia.org/wiki/Beta_blocker) for blood pressure
  - This is 4th or 5th-line treatment for blood pressure

**⇒** Beta blockers inhibit melatonin secretion, and yet most prescribing doctors who are giving out beta blockers don’t realize that there’s a significant risk of insomnia when you prescribe these to patients

- Ashley has had some patients who only needed a 0.5 mg melatonin pill every night, and that’s it (no CBT-I)
  - Those are some of the most angry and satisfied patients
  - One visit with Ashely and they’re done
  - They’re furious that they’ve been suffering for 5, 10 years
  - One patient suffered for 30 years on [metoprolol](https://en.wikipedia.org/wiki/Metoprolol)
    - He couldn’t change his supplement because of something having to do with the vocal cords (he was a singer and some of the other blood pressure meds affect that)

***The average, healthy adult should not be taking melatonin***

- There are probably some excellent data about how our melatonin secretion, inhibition processes, whatnot, change as we age
- There may be some patients who benefit from taking melatonin (which is a hormone) to induce sleep

**Analogy to understand melatonin**

- But remember, melatonin is like the guy at the start of the race
- He’s the guy that fires the gun
- He doesn’t have a car in the race
- He’s not helping you stay asleep
- He’s telling you when to start the thing

***For a lot of adults, taking melatonin is really messing them up because they’re trying to go to sleep when their body isn’t ready to go to sleep***

- They’re forcing it to go to sleep, then they wake up in the middle of the night and they wonder why
  - It’s because you went to sleep at the wrong time and your body’s all kinds of confused

***Ashley tries to take patients off these things so she can see what’s really going on; and if there’s something that looks like it might necessitate melatonin, she brings in a physician to talk about it***

## How to safely taper off sleep medications like benzodiazepines and Ambien [1:26:00]

**How many of the patients who come to see you are regularly taking a prescription-based drug for sleep?**

*We can talk about benzos, trazodone, Ambien, the orexin-based drugs*

- A lot of people take over-the-counter drugs and prescription drugs for sleep
- Ashley noticed a huge shift when COVID started, and there was a ban on flying to different countries, Mexico and Europe
  - A lot of people were flying to Mexico to get their [Ambien](https://en.wikipedia.org/wiki/Zolpidem)
  - Or flying to Europe to get various sleep drugs that you can’t necessarily get here
  - All of a sudden Ashley saw a wave of patients dealing with withdrawal in the early months of the pandemic because they couldn’t go get more of their drugs
- Ambien is prescription only, and they were taking so much that they were well beyond what they could convince someone here to prescribe them
- A lot of Ashley’s patients are physicians, and a lot of physicians are pretty reticent to go above FDA-recommended doses when it comes to Ambien
  - And Ambien is still the only drug that is differentially prescribed to men and women
  - According to the FDA, the starting dose for women should be 5 mg, starting dose for men is 5-10 mg (for instant release)
  - For extended release, the starting dose for women it’s 6.25, and then for men it’s 6.25 all the way to 12.5
    - Because women metabolize it less efficiently
  - Ashley has seen people taking 30 mg of Ambien (big doses)
- A lot of patients will come to her and ask about something they saw in the news about a medication they’re taking for sleep is bad for their brain
  - They want to quit right away
  - But they’ve been taking it for 20 years, so that never works
- Ashley wouldn’t say she has any extreme expertise in the different classes of sleep meds, but the drugs people most commonly come to her with help to quit are: [benzos](https://en.wikipedia.org/wiki/Benzodiazepine), [Ambien](https://en.wikipedia.org/wiki/Zolpidem) (Sanofi-Aventis stuff), and then over-the-counter stuff like [Benadryl](https://en.wikipedia.org/wiki/Benadryl), maybe your occasional [doxepin](https://en.wikipedia.org/wiki/Doxepin)
  - People are often prescribed [Remeron](https://en.wikipedia.org/wiki/Mirtazapine) for sleep, and they run into metabolic issues and they need to get off of it
  - She hasn’t seen people wanting to quit some of the newer drugs ([Quviviq](https://en.wikipedia.org/wiki/Daridorexant)), but she’s sure it’s coming
- [Trazodone](https://en.wikipedia.org/wiki/Trazodone) is the one that Ashley is the least concerned about for a couple of reasons
  - She’s not seen compelling data that it negatively impacts the electrical quality of your sleep
  - Peter has seen data that it does the opposite, that it’s slightly positive [discussed in [AMA #42](http://trazodone) after 20:30] ‒ there was an improvement in sleep duration
    - Ashley doesn’t think the study was powered for that but they did find an improvement
  - Ashely is not the most worried about trazodone because it’s an antidepressant, and if someone is taking it and it is helping with their depression, then she takes them off of it, she has created a different problem
- Peter points out that the dose of trazodone most people are taking is 25, 50, no more than 100
  - Ashley often sees people taking 100 for sleep, and then she thinks it might be doing more than just helping with sleep
  - Even for patients taking 50 plus another antidepressant, she thinks these could be working together

**If folks are showing up on 20 milligrams of Valium or Xanax (or pick your favorite benzo), do you have them go and do a taper detox with their physician before they come into the CBT-I program?**

- No, she has them do it with her
- First, Ashley always works with the prescribing physician
- Every time Ashley has worked to help a patient stop taking a drug, the physician has been in support of getting their patient off benzos (except for 1 time)
- Most of the time these physicians have already tried to get their patients to quit and to reduce, but they’ve tried to do it way too quickly

***There are physiological dependencies on these drugs and psychological dependencies on these drugs, and we have to attend to both of them while we’re doing this taper process, or it’s going to be a botch and the patient’s going to relapse and we’re going to be back at square one (or square negative one)***

**Ashley’s approach to weaning a patient off benzos (or your favorite med), for example 10 mg** [**Valium**](https://en.wikipedia.org/wiki/Diazepam)

- The patient has occasionally abused; they’ve split a pill in half and gone up to 15 mg sometimes

A better sleep example is Ambien

- Let’s say the patient is taking 10 of Ambien every night, at the beginning of the night
- Then sometimes they’re taking another 5 in the middle of the night when they wake up
  - So some nights it 15 and some nights it 10
- The first thing Ashley does is eliminate the middle of the night dosing ‒ the patient is limited to taking 10 at night before bed
  - They have to take it at the same time every night
- If they’re taking 15, 5 nights a week and 10, 2 nights a week, she’s going to have the take 12.5 before bed
  - The prescriber and Ashley will agree on a dose
- Ashley wants the patient to be taking a stable dose before reducing the amount

**⇒** You cannot quit from a point of instability; it will not work

- After 1 week, she asks them how it sounds to cut down from taking 12.5 to 5
  - That often sounds scary
- She has them rate it on a scale from 1 to 10, with 10 being the most anxiety-provoking and 1 is not upsetting at all (this is called a [subjective units of distress scale, SUDS](https://en.wikipedia.org/wiki/Subjective_units_of_distress_scale))
- If the patient is terrified of reducing from 12.5 to 5, she asks about going down to 10
  - That might still be a 6 on their SUDS scale
- She will do this process until she gets them to a 1
- The next week they may go down from 12.5 to 12 every night before bed

Peter asks, “*How are you even making that increment?*”

- Online you can buy a gem scale [for measuring weight]
- Ashley has patients use a gem scale and cut and weigh pills
  - The pill actually weighs more than 12.5 because it has binders and fillers
  - They end up having to put the crumbly pill into a shot glass with some water and shoot the whole thing
- They go from 12.5 to 12, and they do that for 3 weeks
  - If they’ve been on it for years, we’re looking at 3 weeks
- The first couple nights are a little rough (there’s a little stress)

**⇒** This is a taper program, and it will last a long time; it’s a separate issue from Ashely’s CBT-I program

- Patients do this after they finish CBT-I
- During CBT-I treatment, she stabilizes them on their meds
  - Just get it so they’re not erratically taking 5 different cocktails of things
- Often when people come to see her they’re taking Ambien on Mondays, trazodone on Tuesdays, Benadryl on Wednesdays
  - They have it in their head that they don’t want to get dependent on on and think that by doing a rotating merry-go-round of these things it’s working great
  - Peter’s analogy: it’s vodka on Monday, tequila on Tuesday, red wine on Wednesday, Chardonnay on Thursday ‒  this way they’ll never become an alcoholic
- Ashley will work with the doctor and decide the one drug and dose they are going to do, and she has them take it consistently
- People are really stabilized during CBT-I
- Sometimes during week 3 or 4, they are ready to start the program to taper-down their dose
- Then they can do that on their own, and they’ll be keeping sleep diaries
  - They go from 12.5 to 12 for 3 weeks
  - They’ll get some confidence and will email her
  - Then they can go down to 11.5; if that’s too scary, they can go down to 11.75

Peter confirms, “*Just  to be clear, this is psychological. There can’t possibly be a physiologic difference between 4.75 and 5 milligrams of Ambien… In fact, the medicine isn’t even homogeneously enough compounded within the capsule.*”

- Correct
- The generic has to be 85% similar to the real deal
- So there’s all kinds of mess-ups here
- Remember, Ashley said there’s a psychological part and the physiological part
  - The psychological part gets left out a lot when you say, “*Oh, just cut it in half*.”

Peter asks, “*Do you think that this methodology of the incredibly slow taper with incredibly high precision, do you think it works for opioids?*”

- Ashley has never had to deal with that in her clinic
- That’s far outside of her area, she can’t speak to it

***Using this method with sleep drugs, slowly over time, people get more confidence, and they can make larger reductions at a time***

- Importantly, when someone is tapering and something crazy happens in their life (like a child gets diagnosed with cancer or something terrible happens), we stop the taper and stay where we’re at

**⇒** There’s not a huge rush to get off this thing they’ve been on for 20 years, better to stably get off it

> “*When it comes to quitting these meds, slow and steady wins the race*.”‒ Ashley Mason

***Having people gain the confidence that they can do it is such a big part of it***

- One of the critiques people will say is, “*Some of these pills have coatings.*”
- But a lot of it is psychological
- This works really well for a medication taper, and people can do it themselves

## Sleep problems that need to be addressed before CBT-I can be implemented [1:38:30]

**We haven’t talked about sleep apnea or restless leg syndrome**

*What are the other things you want to confirm that aren’t present?*

- Peter is assuming Ashley is not doing polysomnography on everybody on the way in
- Ashley looks in people’s charts and sees who referred them to her and why they were referred

***Everybody needs a referral of some kind to see Ashley***

- A lot of the referrals come from sleep disorder centers because they’ve already done all that workout, and they conclude it’s not an easy thing
- Ashley will always ask a patient, “*Has your partner or anybody you’ve slept with ever told you that you snore or that you sound like you’re gasping for air in the middle of the night?*”

***She has a bunch of those types of screening questions, and she aggressively refers to colleagues with expertise in those areas before treating patients***

- Often patients with a [CPAP](https://en.wikipedia.org/wiki/Continuous_positive_airway_pressure) will say they don’t use it or it doesn’t fit
- Ashley will make a call to get it to fit ‒ there’s all these different issues that we can tackle
- She wants them to use it every single night
- A lot of patients don’t have great follow-through for their CPAP, and Ashley will help them make that extra connection

## The importance of prioritizing a consistent wake-up time over a fixed bedtime for better sleep regulation [1:40:15]

> “*The one thing I think I want to make sure that we put a bow on also is this obsession with bedtime*.”‒ Ashley Mason

- Ashley can make you wake up at any time by setting a very loud alarm
- She can anchor you into your day with a wake-up time, and that can be consistent every single day

***She cannot wave a magic wand and make you fall asleep at the same time every day***

- So when people think, “*All right, I’m going to get a handle on my sleep, I’m going to go to bed at the same time every night*.”
- No, no, no, no.

⇒ Wake up at the same time every day. That’s a much more important first step.

- And if you’re waking up at different times throughout the week, that is the first thing to fix

**What degree of social jet lag do you tolerate?**

- Social jet lag, meaning the experience of changing your sleep time during weekends, which could be akin to jet lag if it differs by hours
- In an ideal world, it would be zero; you would wake up at 7:00 in the morning every single day of the week

*Can you give yourself a 30-minute grace, and that would still be considered perfectly healthy?*

- Ashley tells patients during treatment they need to wake up at the same time every day that ends in “D-A-Y”

**⇒** There is no room for negotiation during treatment (we’re in a dictatorship)

At the end of treatment, Ashley teaches people how to cope with the fact that life is going to happen when treatment ends

- It happens during treatment, but there’s a lot that pauses during treatment
- Let’s say that you’ve got a major event on a Friday night, you’re going to a concert and you’re out way later than usual

*You need to pick which day of that weekend you want to suffer and which day you want to feel good*

**⇒** You can sleep-in 1 day, you cannot sleep-in 2 days in a row (that’s going to take you off the wagon)

- Let’s say you’re out late on Friday night and you want to feel good on Saturday
  - Sleep-in on Saturday by an hour
  - Go to be Saturday night when you get tired
  - *Spoiler alert*: you’re probably going to get tired past your usual bedtime because you slept in
  - Sunday, you have to wake up at your wake time and you’re going to suffer
- Let’s say you want to feel good Sunday
  - That means on Saturday, you’re going to wake up at your usual time
  - Saturday’s going to be a struggle bus, but you’ll make it to your bedtime, and you’ll go to bed at your bedtime
  - Then, you’ll feel better Sunday

***You have to choose when you’re going to do the suffering: the immediate day after or the next day***

**⇒** Don’t sleep-in more than 1 day in a row, it’s going to mess you up; you’re not getting quality sleep when you sleep-in past your wake time (when it’s been a pattern for a long time)

- When you sleep-in, you’re probably getting some extra [stage 2 sleep](https://en.wikipedia.org/wiki/Non-rapid_eye_movement_sleep#Stages)
  - You’re not going to get more deep sleep, that’s for sure

**Peter’s example**

- This recording was made on Tuesday
- Sunday (2 days ago), Peter flew back to Austin from LA and the flight got delayed over and over and over, and he didn’t get home until 2:00 in the morning (long past his bedtime)

*What would your strategy be, getting home at 2:00 in the morning prior to Monday (a workday), where you do have some leeway (he doesn’t have to get up at 6:00, his normal wake-up time)?*

- Ashley wants to know which day is it more important to feel good on? Monday or Tuesday?
  - Tuesday

***Try not to sleep in too much so that you can go to bed at your regular wake time on Monday***

- If you sleep in horribly on Monday morning, you’re going to stay up later Monday night
- Then, you’ll get up at your wake time on Tuesday, and you will have had shorter sleep, and [the suffering] will have rolled all the way over
- Peter did the second option: his wife tried to get him out of bed at 7:00 and he didn’t get up until 8:00
  - And Monday night, he had a hard time going to bed (he was still up at 11:00)

***You have to carefully decide which day you want to prioritize, and that’s how you make your decision***

- What’s beautiful about that is you have more control than you think

> “*I just remind people, you can never really make up for lost sleep that easily, because sleep architecture really matters.*”‒ Ashley Mason

- When you’re sleeping in, you’re not getting more deep sleep
  - You’re getting some more maybe light sleep
  - And at worst, that’s robbing you of maybe some of the deep sleep you would’ve gotten the following night because you’re on a circadian plan

## Process S and Process C: the science of sleep pressure and circadian rhythms [1:45:15]

**Process S is sleep homeostasis, and that’s this sleep pressure idea that we are working on**

- Every day, we build up sleep pressure until its bedtime
- And then, we capitulate; we fall asleep
- Then, our sleep pressure drains throughout the night while we sleep
- In the morning, we build it up again the next day

Peter asks, “*This is just* [*adenosine*](https://en.wikipedia.org/wiki/Adenosine#Sleep) *building up?*”

***Yeah, and that’s why caffeine is problematic***

- Caffeine blocks adenosine receptors
- The caffeine crash (when it wears off) occurs and then all the adenosine floods the receptors, and we experience sleepiness

**Why taking a nap is so difficult**

- What napping does is it basically kind of deflates your balloon a little bit of your sleep pressure

***It robs you of some of that sleep pressure***

- By the time you get around to your normal bedtime, if you’ve taken a long nap, you’ve reduced how much sleep pressure you would ordinarily have at that time, and that’s why napping could be dangerous

**Then, we have Process C, which is the circadian process**

- And process C just marches on, it doesn’t really care about your sleep pressure or how much you’ve slept
- When people pull **all-nighters**, what they often will notice is you’re sleepy during the night, but in the morning, you kind of have a burst of energy
  - That’s the circadian part speaking up
  - And when we look at the sine curve of it, that’s because your temperature is coming back up
  - Your adrenal glands still make cortisol

**⇒** So your circadian process doesn’t really care much about the sleep pressure

- It looks like these 2 things talk to each other, but they don’t

***Process S and process C really determine a lot about your sleep, and there are things we can do to support each of them, but CBT-I really focuses on the sleep pressure aspect by regularizing people’s schedules***

- CBT-I supports the circadian spect some by standardizing what time people are taking their medications, not eating right before bed
  - You can’t really call this standard CBT-I
- In a perfect world, all of these different time keepers would be consistent day to day
  - Eat breakfast at the same time
  - Eat lunch at the same time
  - All of these things would support your circadian biology and probably improve your sleep

## How exercise too close to bedtime may impact sleep [1:47:45]

**Do you have any rules about exercising?**

*Is exercising in the evening counterproductive? If it is, how do you adjust?*

- This is a really nuanced issue

***For some people, exercise at night is fine; for other people, it’s super stimulating***

- It also really depends on what kind of exercise we’re talking about

*One moderating variable here is level of fitness*

- If you take a person who’s extraordinarily cardiovascularly unfit, and you put them in a spin class in the evening
- Do you know it could take their heart rate quite a while to recover?

**⇒** We know that in order to fall asleep, your heart rate should be lowering

- If your heart rate is still elevated from a whole bunch of exercise you just did, that’s not going to help you
- But if you’re super fit, and your heart rate recovers really quickly, it might affect you less
  - So this matters

***For a long time, the general suggestion was to not exercise close to bedtime (for the most part, it applies)***

*It’s also important to think about what kind of exercise you’re doing*

- If someone is doing yoga that is really relaxing and calming (a form of stretching for me) ‒ that’s fine
  - This is the only time of day you can do it because you got a job, you got kids, whatever
- But if you want to go to a HIIT class, it would really be great if you could move it earlier

**Getting up before your normal wake-up time to exercise**

- Ashley has some patients who’ve come in and said, “*Oh, my body wants to wake up every day at 7:00, but I really want to go to this 5:00 A.M. spin class every day*.”
- Ashley understands exercise is very important
- Also, your circadian biology has you going to bed at 11:00 and getting up at 7:00
- Even if you’re getting up at 4:45 to get on your home spin bike to do this thing with this group, your body doesn’t want to go to bed until 11:00, and we’re not going to be able to change that

***You’re going to have to make that cost-benefit analysis with, do you want to lose that much sleep to do that thing?***

**Peter’s brother-in-law plays in a men’s hockey league on Sunday at 11:00 P.M.**

- It’s the only time they can get ice time
- He’s always fried Monday because it’s pretty hard to play a game of ice hockey, and then fall asleep after that

## The structure and variability of CBT-I, Ashley’s approach, and tips for finding a therapist [1:50:30]

- Ashley has created a system where you’ve got the intake, then you’re going to do these 5 group sessions, then theres the exit
- Everything she does sounds formulaic (not in a bad way)
  - That’s probably a big party of its efficacy

**Is that something people should expect when they are going to a CBT-I therapist? Is it always done this way?**

- Peter wonders if there are CBT-I therapists out there who function like psychotherapists, and they say, *“Yeah, we’re just going to engage with each other until your problem is fixed, and we’ll see each other once a week or maybe once every other week.”*?

***It’s something people should ask for***

- Before people start treatment, they fill out the [Pittsburgh Sleep Quality Index](https://www.sleep.pitt.edu/psqi) [[pdf](https://www.med.upenn.edu/cbti/assets/user-content/documents/Pittsburgh%20Sleep%20Quality%20Index%20(PSQI).pdf)] and they fill out the [Insomnia Severity Index](https://pmc.ncbi.nlm.nih.gov/articles/PMC3079939/) [[pdf](https://www.med.upenn.edu/cbti/assets/user-content/documents/Insomnia%20Severity%20Index%20(ISI).pdf)]
- People also fill these out when they’re done with treatment
  - We’re going to see how this worked for you
  - We’re going to actually take measurements

**What type of scores are you getting on the** [**PSQI**](https://www.med.upenn.edu/cbti/assets/user-content/documents/Pittsburgh%20Sleep%20Quality%20Index%20(PSQI).pdf)**?**

- It ranges from 0 all the way to 21 [the maximum score]
- Below 5 is considered no clinically significant sleep problems
  - Ashley relaxes that to 6 or 7, because if you have a prostate or if you’re going through menopause and have hot flashes, you’re going to be elevated on that scale by no fault of your own (or your sleep’s fault)
- For the Insomnia Severity Index, she sees all the way up to 22, 23

***She commonly sees all the way up to the most severe levels in both of these scales, and the average point drops are huge in clinic***

- She doesn’t know if it was 10 points in the Insomnia Severity Index
  - It’s very high, very responsive to this treatment

> “*Back to your original question, I wish everybody did it by the book*.”‒ Ashley Mason

- There’s a lot of practitioners out there who want to do this by the book
- Ashley has the luxury to do it by the book because she’s able to enlist help from her team to help her process sleep diaries every week
  - And do probably 2 hours of work outside of the clinic of prep for her
  - So they feed her stuff that’s been built into her systems
- Ashley is prepping half an hour before clinic
- She sees everybody for an hour and a half
- She’s got her notes, her templates, and things

***It is very difficult to do CBT-I when you’re not seeing patients weekly***

- Ashley looks at weekly sleep diaries and makes changes based on that

**⇒** Ashley recommends, “*When you find a CBTI therapist, I would say, ask if you can set up a time in the future with that therapist, and see them weekly for a set of whatever, 5 to 8 weeks. And put it on the calendar that way with them.*”

- If they don’t have the bandwidth to do that for another month, wait
  - Then get on every week
- A lot of practitioners also aren’t going to necessarily score your sleep diaries for you
- You can score them yourself, if you want to
  - It’s not that difficult
  - Just Google online, you can find a [sleep diary calculator](https://mysleepwell.ca/cbti/sleep-efficiency-calculator/), and it’s very easy to do the math yourself

**Book Ashley recommends**

[*Quiet Your Mind and Get to Sleep*](https://www.amazon.com/Quiet-Your-Mind-Get-Sleep/dp/1572246278/ref=sr_1_1?crid=1VKBUPLLZL8L2&dib=eyJ2IjoiMSJ9.H6FW_dhbQVNKuosnk4aotVjdtXnBtKjiGKoBLpqTAcTF_6RmBghgT1tZhrStFplrIDwYXetTvvojlv6-F8gQJH9tTAzK_Nmnlw4HhTgvJuKj0yv4d9vkjjkoslnONWCWBBhBFIQOrpA65wLhmRYR7qT9YRSWY94g-La4RnAcIZSqpq6OEt9abRcbx2olRnu9hZG79avjLSMryTPbKJLJxiMkTavlt9c9auPR1er_bbg.80fwYsa98Uk4X4OUjh76HxeXKvZjUnkv_adzDuvQQ1Q&dib_tag=se&keywords=Quiet+Your+Mind+and+Get+to+Sleep&qid=1738342261&sprefix=quiet+your+mind+and+get+to+sleep%2Caps%2C81&sr=8-1)

- Written by Rachel Manber and Colleen Carney
  - Dick Bootzin wrote the foreword
- It’s kind of a guided way through the treatment
  - [it has a great sleep diary worksheet]

***And you can use that workbook yourself to do it***

- You could also use that workbook when you’re working with the provider

**There are a lot of CBT-I providers out there who can see you weekly and can do this**

- You’ll probably just have to do your back end work with your calculations because they don’t have the billable time for that
- They’ll be busy during the sessions trying to teach you things

**Ashley gives her patients other homework**

- Between her sessions with patients, Ashley makes them watch very annoying videos that she’s made of herself giving a lecture about all of the science

***She has found that if you explain the science to patients, you’ll get the adherence***

- They explain why we’re going to do this
- People think, “*Wait, I have problems sleeping. Now, you’re going to make me not go to bed. This is not what I’m going for.*”
- Ashley explains to them, “*Okay, here’s why we do this, because this will ultimately get you where you want to go.*”

**Ashley’s approach to CBT-I**

- The principles of what she’s doing are not at all bespoke

> “*I’m doing the time and bed restrictions, stimulus control, the cognitive techniques, the relaxation techniques, and the sleep hygiene. Those are the five major components.*”‒ Ashley Mason

- What is bespoke is:
  - The way that Ashley sets the wake time because that’s not been standardized in literature
  - The way she deals with standardizing medications
  - The way she deals with medication tapers
  - Some of the anxiety tools that she brings in: like scheduled worry time, tracking degree of belief during the day
    - That is actually pretty well incorporated into CBT-I
    - But some of those are a little bit more tilted toward her audience, which tends to be higher in anxiety

**Ashley’s advice for finding a CBT-I therapist**

- Find someone on the [website](https://www.behavioralsleep.org/index.php/directory/all) that knows how to do CBT-I, and Ashley has a feeling you’ll go far

**⇒** The treatment works when you do it, and it doesn’t work when you don’t do it

**Recommendations for starting on your own**

- The book Ashley mentioned ([*Quiet Your Mind and Get to Sleep*](https://www.amazon.com/Quiet-Your-Mind-Get-Sleep/dp/1572246278/ref=sr_1_1?crid=1VKBUPLLZL8L2&dib=eyJ2IjoiMSJ9.H6FW_dhbQVNKuosnk4aotVjdtXnBtKjiGKoBLpqTAcTF_6RmBghgT1tZhrStFplrIDwYXetTvvojlv6-F8gQJH9tTAzK_Nmnlw4HhTgvJuKj0yv4d9vkjjkoslnONWCWBBhBFIQOrpA65wLhmRYR7qT9YRSWY94g-La4RnAcIZSqpq6OEt9abRcbx2olRnu9hZG79avjLSMryTPbKJLJxiMkTavlt9c9auPR1er_bbg.80fwYsa98Uk4X4OUjh76HxeXKvZjUnkv_adzDuvQQ1Q&dib_tag=se&keywords=Quiet+Your+Mind+and+Get+to+Sleep&qid=1738342261&sprefix=quiet+your+mind+and+get+to+sleep%2Caps%2C81&sr=8-1))
  - This is something people could do on their own or in therapy
- Ashley had a patient this summer who was on the wait list, when he got to the intake he explained “*Look, I’m fixed. I did the book. It was awesome. But I still want to be in this group because I want to see what it’s all about. I’m not giving up my spot*.”
  - It was great to have him in the group because he cheerleaded everyone else and said, “*This works when you do it.*”
- If every practitioner is booking 9 months out, or you can’t afford CBT-I, get this book
- You can also try some of the apps out there
  - They’re still in the early stages

## The effect of sauna and cold plunge before bed on sleep quality [1:56:00]

**Any concerns with extreme temperature changes before bed?**

*This could be using sauna, cold plunge, taking hot showers, hot baths?*

- Subjectively from Peter’s experience, a sauna before bed really seems to help
  - Maybe it creates a bigger gradient in temperature drop as he goes from high body temp to low when he gets into that super cold bed

***First, Ashley takes cold plunge off the table before bed ‒ that’s not a good idea***

- We know that when you get in the cold plunge, it’s immediately cold on your skin
- But then once you get out, your body is busy warming itself back up, and that’s not what we want to be doing right before bed

For sauna, it depends

- The outline that Peter just gave of the temperature gradient is beautiful; it makes a lot of sense
- For people who are naive to sauna who get in a sauna, it increases their heart rate; and increasing your heart before bed might be the same problem as exercise [at night]
  - If they don’t have a rapid recovery [it’s a problem]
  - That’s something you have to learn about yourself
- Peter explains that he doesn’t go straight from the sauna to bed
  - It’s usually sauna to 30 minutes of Netflix to bed

***The effects of sauna are going to vary from person to person***

- Another thing to keep in mind is that some people who use the sauna at night, they then drink a whole bunch of water afterwards
  - And that ends up causing them to wake up more in the middle of the night (so it defeats the purpose)
- Some people find that sauna is really helpful
- For Ashley, it works best to do it a few hours before bed, as opposed to right before bed

***For sauna, it’s going to be a do-what-works situation because we don’t have enough data***

**Ashley just started a** [**NIH-funded trial**](https://clinicaltrials.ucsf.edu/trial/NCT06626048)

- Looking at people who have difficulty with falling asleep
- Giving them whole body heating at home before bed and giving them CBT-I through an app

***We’re going to have them do this whole home-based treatment that’s going to combine a body-based heat treatment for before bed with the CBT-I treatment***

- The idea here is what Peter explained about by heating you up right before bed
  - If we’re heating up your hands and your feet, we’re helping you actually open the vasculature and dump some heat, it’s going to create that gradient
- We think that gradient might be important for people with the early kind of insomnia with [difficulty] falling asleep at the start of the night
- We’re going to see if that helps people using a sauna blanket type thing

## Key takeaways on CBT-I, and why no one should have to suffer from insomnia [1:58:15]

**We’ve only scratched the surface of Ashley’s expertise**

- There are other clinical areas she has expertise in that are of interest
- She’s delivered a master class on CBT-I
- This was a bit of a black box to Peter and he sends a number of patients to CBT-I therapy
  - And based on their ability to comply, the efficacy has been unparalleled

**Peter’s takeaway** ‒ there’s nobody who should be suffering from insomnia; it’s not a necessary thing to suffer

- We are going to have to do a part 2 of this podcast to talk about eating behaviors, thermal regulation and its impact on depression or other things

**Final things Ashley wants to mention about CBT-I**

- It’s important for people just to remember with this one that, even if you don’t know what caused your insomnia, you can do this treatment
  - You don’t have to figure out where this started (or the root of it)
  - You can start this treatment without that knowledge
- This treatment is going to address what you’re doing now that’s actually perpetuating the problem
- Don’t wait: now is the best time to do this
  - There’s never going to feel like a good time to do it
  - Your life is always going to be crazy
  - You’re always going to have 50 more things on the schedule than you wish you did
  - It’s always going to be too busy
  - You’re always going to have events
- Do it now, because it’s so difficult to live with insomnia and all of the problems that it causes
- Ashley had this patient who was 87 (she finished treatment with her last year), and she just said, “*My, I wish I had done this 40 years ago*.”

> “*Don’t wait. Just do it. You won’t regret it.*”‒ Ashley Mason

**Do you have a sense of how large the CBTI community is and how long a person should expect to wait?**

- People are waiting a long time to see Ashley, and Peter thinks that probably speaks to how good you are and the resources that UCSF provides (maybe in combination)
- It’s easier than ever now because of telemedicine
- Ashley sees patients from all over California
  - They don’t all physically come to San Francisco (nobody does)
  - She only sees patients on Zoom now
    - This is a whole lot safer because patients used to drive in from Fresno and stay overnight in a hotel in San Francisco (it was nuts)
- There’s a lot of versions of Ashley who see patients by Zoom
- By going to that [website](https://www.behavioralsleep.org/index.php/directory/all), you’ll be able to find a CBT-I provider
  - And chances are, they do telemedicine
- One of the great pieces of news about that is that if you live somewhere more rural now, it is instantly more accessible to you
- You want to make sure the provider is licensed in your state
- There are ways you can start this on your own: – get the [book](https://www.amazon.com/Quiet-Your-Mind-Get-Sleep/dp/1572246278/ref=sr_1_1?crid=1VKBUPLLZL8L2&dib=eyJ2IjoiMSJ9.H6FW_dhbQVNKuosnk4aotVjdtXnBtKjiGKoBLpqTAcTF_6RmBghgT1tZhrStFplrIDwYXetTvvojlv6-F8gQJH9tTAzK_Nmnlw4HhTgvJuKj0yv4d9vkjjkoslnONWCWBBhBFIQOrpA65wLhmRYR7qT9YRSWY94g-La4RnAcIZSqpq6OEt9abRcbx2olRnu9hZG79avjLSMryTPbKJLJxiMkTavlt9c9auPR1er_bbg.80fwYsa98Uk4X4OUjh76HxeXKvZjUnkv_adzDuvQQ1Q&dib_tag=se&keywords=Quiet+Your+Mind+and+Get+to+Sleep&qid=1738342261&sprefix=quiet+your+mind+and+get+to+sleep%2Caps%2C81&sr=8-1) she discussed

***You just have to remember that as special as each human is, you need to try and not feel like a delicate flower with your insomnia. Just assume that you need to do this.***

---

## Selected Links / Related Material

**UCSF SEA Lab**: [Sleep, Eating, and Affect (SEA) Lab](https://www.sealab.ucsf.edu/) | [1:00]

**Cotton blankets that Ashley recommends** (Ashley has no affiliation with these brands, nor does Peter): [11:45]

- [Utopia](https://smile.amazon.com/gp/product/B00J82V60E/ref=ppx_yo_dt_b_search_asin_title?ie=UTF8&psc=1): Ashley has these; She layers several of them; They look flimsy but they are terrific
- [Sweet Home](https://smile.amazon.com/gp/product/B01DPSP98G/ref=ppx_yo_dt_b_search_asin_title?ie=UTF8&psc=1)
- [Waffle](https://www.amazon.com/dp/B08L7FWC2L?psc=1&ref=ppx_pop_dt_b_product_details)
- [American Blanket Company](https://www.americanblanketcompany.com/collections/best-cotton-blankets-made-in-usa/products/100-cotton-blankets-american-blanket-company)
- [Eddie Bauer](https://www.amazon.com/Eddie-Bauer-Herringbone-Blanket-Mushroom/dp/B00KDBJK4I?source=ps-sl-shoppingads-lpcontext&ref_=fplfs&smid=ATVPDKIKX0DER&th=1)
- [Coyuchi](https://www.coyuchi.com/products/cascade-organic-blanket)

**Episode of** ***The Drive*** **about DBT**: [#219 ‒ Dialectical behavior therapy (DBT): skills for overcoming depression, emotional dysregulation, and more | Shireen Rizvi, Ph.D., ABPP](https://peterattiamd.com/shireenrizvi/) (August 22, 2022) | [20:15]

**Episode of** ***The Drive*** **explaining stages of sleep**: [#47 – Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, memory consolidation, and more](https://peterattiamd.com/matthewwalker1/) (April 1, 2019) | [43:15]

**Episode of** ***The Drive*** **explaining sleep chronotypes**: [#126 – Matthew Walker, Ph.D.: Sleep and immune function, chronotypes, hygiene tips, and addressing questions about his book](https://peterattiamd.com/matthewwalker4/) (August 31, 2020) | [44:30]

**Sleep diary**: [57:00]

- [Pdf](https://us-west-2.protection.sophos.com/?d=ucsf.edu&u=aHR0cHM6Ly93d3cuc2VhbGFiLnVjc2YuZWR1L3NpdGVzL2cvZmlsZXMvdGtzc3JhOTE2Ni9mL3d5c2l3eWcvU2xlZXAlMjBEaWFyeSUyMC0lMjBGaWxsJTIwSW4lMjBEYXlzXzAucGRm&p=m&i=NjM5MjEzOGNjNDEyOGMxMjM1MGU4MzY2&t=MWNRU0d3WjFZNk9WV3BQQ2VBclp1MndKdS9FSElWR2tkR01URnM3L0FwVT0=&h=4927bb2c9b30456f9f243154ec36a957&s=AVNPUEhUT0NFTkNSWVBUSVZQxWuOsPwqVcF5V6xUSHiuApUDdVXhUk-pjUl4Rl1ijA) | UCSF (2025)
- [Instructions](https://us-west-2.protection.sophos.com/?d=ucsf.edu&u=aHR0cHM6Ly93d3cuc2VhbGFiLnVjc2YuZWR1L3NpdGVzL2cvZmlsZXMvdGtzc3JhOTE2Ni9mL3d5c2l3eWcvU2xlZXAlMjBEaWFyeSUyMEluc3RydWN0aW9ucy5wZGY=&p=m&i=NjM5MjEzOGNjNDEyOGMxMjM1MGU4MzY2&t=c3FyYk1tbUFwR3RLZ014VTNZdFhOeFJ3SGJSQUhwejIycEpTMGttcDJLOD0=&h=4927bb2c9b30456f9f243154ec36a957&s=AVNPUEhUT0NFTkNSWVBUSVZQxWuOsPwqVcF5V6xUSHiuApUDdVXhUk-pjUl4Rl1ijA) | UCSF (2025)

**Where to get orange glasses**: [Bluelight Blocking Products – LowBlueLights](https://lowbluelights.com/) (2025) | [58:00]

**Amount of caffeine in decaffeinated coffee**: [Caffeine content of decaffeinated coffee](https://pubmed.ncbi.nlm.nih.gov/17132260/) | *Journal of Analytical Toxicology* (R McCusker et al. 2006) | [59:00]

**Amount of caffeine in a Starbucks coffee**: [59:30]

- [Caffeine content of specialty coffees](https://pubmed.ncbi.nlm.nih.gov/14607010/) | *Journal of Analytical Toxicology* (R McCusker, B Goldberger, E Cone 2003)
- [Evaluation of the Caffeine Content in Servings of Popular Coffees in Terms of Its Safe Intake—Can We Drink 3–5 Cups of Coffee per Day, as Experts Advise?](https://pmc.ncbi.nlm.nih.gov/articles/PMC11314177/) | *Nutrients* (R Wierzejska, I Gielecinska 2024)

**Meta-analyses demonstrate effectiveness of CBT-I**: [1:07:00]

- [Cognitive Behavioral Therapy for Chronic Insomnia: A Systematic Review and Meta-analysis](https://pubmed.ncbi.nlm.nih.gov/26054060/) | *Annals of Internal Medicine* (J Trauer et al 2015)
- [A meta-analysis of group cognitive behavioral therapy for insomnia](https://pubmed.ncbi.nlm.nih.gov/24931811/) | *Sleep Medicine Reviews*(E Koffel, J Koffel, P Gehrman 2015)

**Directory of CBT-I providers**: [Society of Behavioral Sleep Medicine Directory](https://www.behavioralsleep.org/index.php/directory/all) (2025) | [1:07:45]

**UCSF Osher Sleep Center**: [Osher Sleep Clinic | SEA Lab](https://www.sealab.ucsf.edu/oshercentersleep) (2025) | [1:08:15]

**Ashley is working with a company making the app Rest**: [Rest](https://getrest.app/) (2025) | [1:10:00]

**Amount of melatonin in supplements inaccurate**: [1:22:00]

- [Quantity of Melatonin and CBD in Melatonin Gummies Sold in the US](https://pubmed.ncbi.nlm.nih.gov/37097362/) | *JAMA* (P Cohen et al. 2023)
- [Melatonin Natural Health Products and Supplements: Presence of Serotonin and Significant Variability of Melatonin Content](https://pmc.ncbi.nlm.nih.gov/articles/PMC5263083/) | *Journal of Clinical Sleep Medicine* (L Erland, P Saxena 2017)

**Newsletter on melatonin supplements**: [Concerning findings on melatonin content in over-the-counter supplements](https://peterattiamd.com/melatonin-content-in-sleep-supplements/) | PeterAttiaMD.com (A Misic, K Birkenbach, P Attia 2023) | [1:22:00]

**Peter discusses increased sleep duration with trazodone**: [#233 – AMA #42: Optimizing sleep – bedtime routine, molecule regimen, sleep trackers, sauna, & more](https://peterattiamd.com/ama42/) (December 5, 2022) | [1:29:15]

**Sleep index surveys**: [1:51:15]

- [The Pittsburgh Sleep Quality Index (PSQI)](https://www.sleep.pitt.edu/psqi) | University of Pittsburgh (2025)
- [PSQI pdf](https://www.sleep.pitt.edu/sites/default/files/assets/Instrument%20Materials/PSQI-Instrument.pdf) | University of Pittsburgh (2025)
- [Insomnia Severity Index pdf](https://www.med.upenn.edu/cbti/assets/user-content/documents/Insomnia%20Severity%20Index%20(ISI).pdf) | University of Pittsburgh (2025)

**Book Ashley recommends**: [Quiet Your Mind and Get to Sleep: Solutions to Insomnia for Those with Depression, Anxiety, or Chronic Pain](https://www.amazon.com/Quiet-Your-Mind-Get-Sleep/dp/1572246278/ref=sr_1_1?crid=1VKBUPLLZL8L2&dib=eyJ2IjoiMSJ9.H6FW_dhbQVNKuosnk4aotVjdtXnBtKjiGKoBLpqTAcTF_6RmBghgT1tZhrStFplrIDwYXetTvvojlv6-F8gQJH9tTAzK_Nmnlw4HhTgvJuKj0yv4d9vkjjkoslnONWCWBBhBFIQOrpA65wLhmRYR7qT9YRSWY94g-La4RnAcIZSqpq6OEt9abRcbx2olRnu9hZG79avjLSMryTPbKJLJxiMkTavlt9c9auPR1er_bbg.80fwYsa98Uk4X4OUjh76HxeXKvZjUnkv_adzDuvQQ1Q&dib_tag=se&keywords=Quiet+Your+Mind+and+Get+to+Sleep&qid=1738342261&sprefix=quiet+your+mind+and+get+to+sleep%2Caps%2C81&sr=8-1) by C Carney, R Manber, R Bootzin (2009) | [1:53:30]

**Ashley’s clinical trial to test effectiveness of a sauna blanket in combination with a CBT-I app for treating insomnia**: [Optimizing an Integrated Mind and Body Treatment for Insomnia](https://clinicaltrials.ucsf.edu/trial/NCT06626048): The SLEEPS Study | *UCSF Clinical Trials* 2025 | [1:57:45]

---

## People Mentioned

- [Richard (Dick) Bootzin](https://en.wikipedia.org/wiki/Richard_Bootzin) (1940-2014, Professor of Psychology and Psychiatry at the University of Arizona who developed CBT-I) [3:15, 25:15, 1:53:30]
- [Aaron Beck](https://en.wikipedia.org/wiki/Aaron_Beck) (1920-2021, was a Professor of Psychiatry at the University of Pennsylvania, regarded as the father of cognitive therapy and CBT) [27:45]

---

![](https://peterattiamd.com/wp-content/uploads/2025/03/bio-ashleymason.png)

##### Ashley Mason, Ph.D.

Ashley Mason, PhD, is an [Associate Professor of Psychiatry](https://osher.ucsf.edu/patient-care/patient-care-team/ashley-mason) in Residence at the Weill Institute of Neurosciences, Department of Psychiatry and Behavioral Sciences, and the Osher Center for Integrative Health at the University of California, San Francisco (UCSF). Dr. Mason received her PhD from the University of Arizona, completed her resident training in behavioral medicine at the VA Palo Alto Health Care System, and completed a National Institutes of Health (NIH) fellowship training at the UCSF Osher Center for Integrative Health.

Dr. Mason has an active federally and philanthropically funded research program. She directs the [Sleep, Eating, and Affect (SEA) Laboratory](https://www.sealab.ucsf.edu/), which focuses on the development of novel mind and body treatments that address long-neglected targets in (1) mood disorders, principally clinical depression and anxiety, (2) insomnia and sleep-related anxiety, and (3) reward-related behaviors, in particular, craving-related and compulsive overeating. She focuses on “mind” treatments that employ cognitive-behavioral processes and reward-based learning, and “body” treatments that include thermal therapies. Clinically, Dr. Mason directs insomnia treatment at the UCSF Osher Center, where she provides cognitive behavioral therapy for insomnia (CBT-I) to patients with insomnia and patients who want to quit using substances for sleep. She has published more than 70 peer-reviewed manuscripts, and her work has been featured in many news outlets, including *[NPR](https://www.marketplace.org/2021/02/22/wearable-tech-shows-promise-early-covid-19-detection/)*, *[AXIOS](https://www.axios.com/2020/12/14/oura-smart-ring-covid-infections)*, and *[WIRED](https://www.wired.com/story/sauna-heat-therapy-depression-cbt-mental-health-trial/)* magazine.

**Conflict of Interest and Funding Disclosures**: Dr. Mason reports funding for her research from the National Institutes of Health (NIH), including the National Center for Complementary and Integrative Health (NCCIH), the National Institute of Diabetes and Digestive and Kidney Diseases (NIDDK), and the National Heart, Lung, and Blood Institute (NHLBI), as well as the US Department of Defense (DOD), the Medical Technology Enterprise Consortium (MTEC), The Donner Foundation, The Tiny Foundation, The Aoki Foundation, and SCICOMM Media / Huberman Lab. Dr. Mason has consulted for Oura Health and Evolve Global.

Instagram: [ashleymasonphd](https://www.instagram.com/ashleymasonphd/)

X: [@DrAshleyMason](https://x.com/DrAshleyMason)