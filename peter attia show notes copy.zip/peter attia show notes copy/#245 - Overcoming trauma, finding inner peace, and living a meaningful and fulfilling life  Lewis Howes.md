# #245 ‒ Overcoming trauma, finding inner peace, and living a meaningful and fulfilling life | Lewis Howes

**Source:** [https://peterattiamd.com/lewishowes/](https://peterattiamd.com/lewishowes/)

---

Lewis Howes is a New York Times best-selling author, entrepreneur, speaker, and host of the popular podcast, The School of Greatness. In this episode, Lewis opens up about the various hardships and traumatic events he experienced starting at a very young age and reveals the valuable lessons he learned as he worked through those traumas to improve his emotional health. He talks about how his past hardships likely contributed to his success in business and athletics, only to leave him feeling unsatisfied and unfulfilled. Next, he discusses how many aspects of his life were suffering, the inflection point that drove Lewis to seek help, and the long but beautiful healing journey that followed. Lewis makes the case that adversity, and even trauma, can be beneficial if one finds meaning in tribulations and has the courage to face one’s fears and insecurities. Finally, Lewis shares the many modalities of therapy that helped him along the way and gives advice for those wanting to find inner peace and live a fulfilling, rich, abundant, joyful life.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/lewishowes/the_Drive_public.png)

Play

#245 ‒ Overcoming trauma, finding inner peace, and living a meaningful and fulfilling life | Lewis Howes

#245 ‒ Overcoming trauma, finding inner peace, and living a meaningful and fulfilling life | Lewis Howes

1x15s30s

0:001:34:22

## We discuss:

- Lewis’s upbringing and the impact of his older brother going to prison [2:45];
- Finding lessons in tragedy and adversity [10:45];
- Lasting trauma from being sexually abused at age 5 [13:15];
- Inflection point that drove Lewis to seek help, and a beautiful experience at a therapeutic workshop [16:45];
- A powerful workshop on emotional intelligence jump started Lewis’s healing journey [27:30];
- How being authentic can strengthen bonds with family and bring inner peace [39:30];
- Comparing adversity with trauma and finding meaning in struggle [45:15];
- Association between adverse childhood events and diseases in adulthood [56:15];
- How addressing his issues with intimate relationships helped Lewis overcome physical pain related to his past trauma [59:15];
- Healing is a journey that takes time and requires courage to face your fears and insecurities [1:08:45];
- How Lewis thinks about mortality and uses it as motivation to pursue his dreams [1:13:00];
- How anyone can benefit from therapy or coaching, and Lewis’s advice for finding inner peace [1:22:45];
- Lewis’s newest book, *The Greatness Mindset* [1:29:15]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Lewis Howes is a New York Times bestselling author and entrepreneur, and a former professional athlete
- He’s best known for his work as a motivational speaker and host of the podcast, [The School of Greatness](https://lewishowes.com/podcast/#)
- Lewis is the author of several books, including [*The School of Greatness*](https://www.amazon.com/School-Greatness-Real-World-Living-Leaving/dp/1623365961/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) and [*The Mask of Masculinity*](https://www.amazon.com/Mask-Masculinity-Embrace-Vulnerability-Relationships/dp/1623368626/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)
  - His new book titled [*The Greatness Mindset*](https://info.lewishowes.com/the-greatness-mindset?source=guest-podcast) comes out on March 7th this year
- In this conversation with Lewis, we talk about Lewis’s story
  - The traumas he went through as a child
  - And ultimately the lessons he learned throughout his life as he worked through those traumas to improve his emotional health
- Lewis’ story is one that a lot of people will relate to, and while the details are obviously unique to Lewis (just like the details are unique to all of our stories), some of the takeaways are very common
- Lewis endured a lot of hardship as a child, and in some cases many more hardships than a lot of people would endure, and he channeled that into a lot of success driven by inferiority and things like that
- But what he figured out (and luckily figured out early in life) was that ultimately these accolades and these pursuits of success left him feeling unfulfilled
- This podcast really talks about that journey
- As many of you listening to this podcast probably understand, Peter places just as much of an emphasis on emotional health as he does physical health
  - And even though more of our podcasts talk about the physical side of health, cognition, different diseases, physical robustness, etc., it doesn’t mean that emotional health is any less important
- Lewis’s story is such an important one, and Peter is very grateful for how he’s able to open up in this episode
- Hopefully, for any of you listening who have some unresolved issues, this episode might provide the encouragement that you need to address those, to reap some of the benefits of improved emotional health

## Lewis’s upbringing and the impact of his older brother going to prison [2:45]

- Peter feels lucky to be one of the first people to talk to him on the heels of Lewis’s book coming out
  - This was recorded in January and his [book](https://info.lewishowes.com/the-greatness-mindset?source=guest-podcast) comes out at the beginning of March
- Peter wants to talk about this book and things that precede this book
- Lewis’s personal story was the substrate for three of his four books

**Where did you grow up?**

- Lewis grew up in small town in Ohio, near Columbus, but then he bounced around
- He went to a private boarding school in St. Louis, Missouri at age 13
- He begged his parents to send him away for two months in the summer because there was a lot of turmoil ‒  inner turmoil, environment turmoil
  - For most kids it’s the opposite, they beg to stay home
  - His parents didn’t want to send him away
- Peter adds that his daughter (who is in 8th grade), says she wants to go to boarding school for high school (half joking)
  - Peter doesn’t want to because they have the rest of their lives to be away from her
  - He thinks she might want to go because they’ll have less stringent rules about phone time or something

**Boarding school transformed Lewis’ life**

- He benefited from the structure, organization, discipline, strict rules, and guidelines
  - Though it wasn’t a military school, you had to wake up at 6:00 AM
  - That organizational feel gave him structure when he felt like he didn’t have any

**Do you have siblings?**

- Lewis has three older siblings; a brother who is 11.5 years older, and two sisters with 3-4 years gap in between each
  - He’s the youngest of four

*So you probably didn’t play with your brother much growing up*

- No, when Lewis was eight, his oldest brother went to prison for 4.5 years (he was sentenced 6-25 years)
  - He sold a sheet of LSD to an undercover cop when he was 18 years old and in college
  - It was the early ‘90s and with the “war on drugs,” they were cracking down on anything and giving extreme cases in jail time to make an example for others
- He has fond memories from about five years old until eight of his brother being his hero
  - A bigger, older teenager who was very gifted and talented in a lot of different ways, extremely intelligent

**Having his brother go to jail was devastating and very confusing**

- Lewis lived in a small town and didn’t grow up knowing anyone that went to jail or prison
- It was very traumatic for his parents and siblings
- They had the opportunity to visit once a week; it took a couple hours drive to the prison
  - The visiting room was interesting, not many eight-year-olds go to a prison every single weekend for three to four hours and sit in a room with 40 convicts and their families for essentially four years
  - It was a wake up call on different cultures, different ethnicities, different backgrounds, different experiences
- It was a  wake up call for Lewis because he had a lot of judgments about convicts from movies and TV
  - When he actually met a lot of them, they were extremely friendly; they were kind, and a lot of them were with their families reading the Bible
    - They’d been in there for a long time and they’d transformed in a lot of ways
    - For the ones that Lewis was meeting (not all inmates), it felt like they were actually good guys
- This was a dark time because his whole family was overwhelmed by the trauma, shame, and guilt of his brother going to prison
  - Lewis couldn’t really have friends during that time
  - Living in a small town, everyone knew and none of the parents on his block wanted their kids to hang out with him

“*It was a confusing time for me because I felt lonely and insecure and never really accepted myself*”‒ Lewis Howes

- Peter finds it remarkably insightful that Lewis, at age eight, had judgements about what prison was or wasn’t
  - When you’re eight you don’t understand the difference between doing something wrong and breaking the law
  - There are a lot of people who do things that are wrong and awful, but they’re not breaking the law, and as a result of that, there’s no legal consequence
  - Similarly, there are a lot of things that are against the law that are really not morally particularly wrong, and yet there’s an enormous consequence
- Lewis knew his brother committed a crime but didn’t feel like he was a bad guy
  - He didn’t do horrible things
  - He was just trying to make money as a college kid
  - The undercover scheme was to send a bunch of guys to jail
  - He was sentenced for 6-25 years on his first offense

**Do you remember the impact of that on your parents?**

- It was devastating
- His dad was well respected in the community; he was a life insurance salesman
  - He was trying to give back to the community with [Rotary](https://www.rotary.org/en/get-involved)
  - Imagine the impact it had on his dad and his business and his reputation
- They had exchange students living with them since Lewis was five
  - They had seven different exchange students from around the world live with them for six months at a time
- Lewis can imagine the guilt and shame that his parents had from asking themselves, “*Where did we go wrong?*”
- His older brother was extremely gifted and talented in some ways
  - He was one of the top violinists in the country under 17 in national competitions as a classical violinist
    - He was a savant/ prodigy; he did things with the violin classically that people couldn’t do
    - He was second chair/ first chair at 16 in the Columbus Symphony as a 16 year old

## Finding lessons in tragedy and adversity [10:45]

- One of the lessons that came from his brother’s incarceration was a new view of tragedies, challenges, and adversity

> “*Hindsight is always 20/20, and sometimes it’s hard to have future hindsight now*”‒ Lewis Howes

***Now that Lewis has had so many different challenges in life and he sees the meaning of them later, anytime he is in an adversity now, he tries to think of how meaningful this is going to be in his future ‒ It’s going to give him more power and wisdom to serve others***

**The prison band**

- Because his brother was so gifted in the violin, he went to a special prison facility that had a a prison band
- It was like a Hollywood movie in Lewis’s mind ‒ his brother goes to jail and joins the prison band
  - He’s a classical violinist white kid from Ohio, and he joins the band where he’s the only white kid
  - They’re all playing hip hop and funk and blues and rap and R&B and jazz, and they teach him the culture of a different style of music for four years
  - He gets a masterclass from other inmates who are talented and play and sing with their heart and their souls with so much musicality and passion from pain and trauma, and they poured their hearts out in this band
- Lewis and his family got to watch the prison band a few times
  - It was so inspiring to watch prisoners, inmates perform like they were free men
- His brother got out of prison early on good behavior, after 4.5 years instead of the full 25

**In the last 20+ years, his brother has completely transformed his life**

- He goes all over the country and all over the world to perform and teach at schools
- He was a Professor at Berklee School of Music, one of the most prestigious colleges in the world of music
- He played with Les Paul for 10 years in Times Square
  - He played at Les Paul’s funeral, one of the icons of jazz and invented the electric guitar

***He transformed his life to be of service and find meaning from that experience, and he would’ve never been the greatest jazz violinist in the world had he not gone through that four years of challenging education of being an inmate in prison***

## Lasting trauma from being sexually abused at age 5 [13:15]

**Lewis had a really traumatic event occur when he was five, and it was something he kept a secret for 25 years**

- This was unrelated to anyone who came to their house as an exchange student
- Both of his parents worked until 5, 6, or 7; they sent the kids to babysitters after school
  - They didn’t really have financial abundance until he was about 16
- When he was five, he was sexually abused by a babysitter’s son, who was 16 or 17
- That event left Lewis feeling a lot of pain, a lot of insecurity, a lot of shame
- He didn’t think this ever happened to any other boy
  - Growing up in the ‘80s and ‘90s, he had never heard a man on TV or an athlete talk about sexual abuse
  - He heard about it from women, in some cases; but he never heard about it from a male perspective
- Essentially, for about 25 years, he thought he was the only one who’d been sexually abused in the world
  - He was uneducated and unaware
- This left him with a lot of shame and self-doubt that caused him to project a personality that he wasn’t — “*An inauthenticity for me to protect myself*.”
  - He wore many different masks to try and fit in, to feel accepted, to feel belonging to his peer group

***He was always feeling angry, triggered, reactive, defensive ‒ like he was being taken advantage of or abused (whether it was actually happening or not), and in some ways that drove him to accomplish goals and generate success in sports and then eventually in business***

**He would have these big goals in athletics**

- He  wanted to be an all-American athlete
  - He was a two-sport all-American athlete
- He wanted to be a professional athlete
- He made arena football league and was a pro athlete
- He wanted to go to the Olympics and was on the USA handball team for almost nine years
  - They never qualified, but he played against a lot of Olympic teams

***He remembers accomplishing all these sports goals and still not feeling fulfilled and joyful and happy inside***

- He succeeded, but he never felt like it was enough; so he needed to go bigger
- He did the same thing in business for many years
  - He would accomplish goals, make money, get the accolades and things like that, and it still didn’t feel like it was enough

**It wasn’t until he was 30 years old (a decade ago) when he started to have multiple breakdowns**

- He was driven and fueled to prove people wrong, to look good, to win, and to get acknowledged and to be the one standing on top
  - He thought that would bring joy, peace, and fulfillment

***As he got more successful, it just left him feeling more and more angry and upset***

## Inflection point that drove Lewis to seek help, and a beautiful experience at a therapeutic workshop [16:45]

**He had multiple breakdowns in life ‒ with his best friend, in an intimate relationship, in a business partnership**

- He was just kind of reactive in life and had a big wake-up call
- When he’d play sports, one time, he got into a bad fight on a basketball court
- All these things came together at once when his best friend said, “*I don’t want to hang out with you anymore if you’re going to keep reacting like this.*”
  - This is a guy that he played college football with and knew for a decade at that time
  - He was like, “*I don’t like the way you’re reacting. It’s not fun anymore. What are you doing? Why are you getting so triggered?*”
- That was a big wake-up call where he thought he didn’t need additional coaching or support
  - He thought he had all the answers at the time
  - He had a massive ego thinking, “*What else can I learn?*” [I know it all]
    - He was in the personal development space
    - He had made money in business
    - He felt like he had all the answers, and people just need to understand and accept him

**He started to take the advice from this and other friends, and he went to therapy**

- He went to a lot of different emotional intelligence workshops

> “*I’ve been in the journey of trying and testing lots of different healing modalities over the last decade that have been extremely powerful and inspiring”*‒ Lewis Howes

**Opening-up about being sexually abused**

- In a workshop about 10 years ago, Lewis opened up for the first time about being sexually abused
- That was the catalyst for starting the journey of reflecting back on just all the little and big traumas that he had faced
  - Whether he thought they were a big deal or not

***Just allowing himself to reflect back on the different psychological stages of his life that wounded him, that created a scar, it was extremely healing***

- It was terrifying at the same time, but extremely healing when he started to open up about this in this workshop
- Then went through a process of telling his family one by one, and then close friends one by one, and then eventually about a year later, opening up about it publicly on his podcast (see the links at the end of these notes under selected links)
- Before he did this episode about sexual abuse as a man, he remembered thinking that his life would be over, his career and business would be over
  - That no one would ever buy anything from him again
  - That everyone would make fun of him publicly, and he would be shamed

> “*I just felt like it needed to come out of me; and if it could help a few men who had been through something similar, then it was worth losing my credibility in my business and everything*.”‒ Lewis Howes

**What happened afterwards was an extremely beautiful experience**

- For weeks, he got essays from men opening up for the first time about the traumas that they went through, through sexual abuse
- Reading these essays from men was an emotional hangover because he didn’t realize how much trauma men go through in their childhoods

**Stats on sexual abuse**

- [1 in 6 men](https://1in6.org/statistic/) have been sexually abused
- [1 in 4 women](https://www.cdc.gov/violenceprevention/childsexualabuse/fastfact.html)

**The challenge for men**

- There has never really been a safe space until the last few years for men to be able to open up and talk about it
- This is traumatic no matter if you’re a man or a woman
- But there’s been more of an availability to talk about it for women over the last decades
- More men are opening up and talking about it
- More people are talking about mental health in general and healing trauma
- It’s been a beautiful journey over the last 10 years to continue to heal, to continue to grow and reconnect
- To re-parent that five-year-old version of himself, the 10-year-old version of himself, the 18-year-old version of himself
  - To talk to himself in a meditative psychological state of how proud he is of that five-year-old for overcoming this
  - How proud he is of the 8-12-year-old who didn’t have friends for 4.5 years because he was facing challenges with his brother in prison
- *For all the different stages of life that he felt like he was unsure, uncertain, unclear, and being able to go back and have those conversations has been extremely healing experience*

***What do you think created that crescendo when you were 30? Why did it take 25 years for that volcano to erupt?***

- Peter notes that it is not unusual where traumatic events events occur early in life trigger positive and negative maladaptations
  - The positive adaptations were things that gave you discipline and drive, and probably enabled you to reach your potential
  - Unfortunately it came with negative adaptations that increased your temper, created emotional distance between you and others, and impaired your ability to connect with people
- Lewis loves this conversation because most people don’t ask him this stuff
- He became really good at putting on a mask of the athlete mask, the know-it-all mask, the success mask (using success as a mask to protect himself)

> “*I think it’s really hard to transform when things are good*”‒ Lewis Howes

**It’s really hard to transform unless some type of event occurs**

- Maybe it’s someone close to you who has a near-death experience
- Maybe you go through a divorce or breakup or your business bankruptcy or you lose your job
- Maybe you get really sick
- Maybe you lose a grandparent that you’re close with and you start asking yourself:
  - Why am I doing the things I’m doing?
  - There’s not enough time left
  - You start looking at life differently

**A perfect storm of events occurred**

- A business partnership broke up
- He almost got in a fight with his business partner at one point in the middle of Times Square
  - He felt like he was going to punch him because they were just not able to communicate
- It was months and months of frustration and resentment and all these things
- And Lewis was immature and had a big ego

*Peter recalls from Lewis’s book that it was a 50/50 partnership and Lewis was doing 80% of the work*

- That was Lewis’s perspective
  - He was bringing in the revenue
  - He was the one doing the sales
- Peter notes that he had a legitimate concern but was not able to say to his partner, “*Hey, listen, this doesn’t feel equitable to me. How does it feel to you? Should we reconsider things?*”
- Exactly, Lewis didn’t have the **emotional tools to communicate maturely**
  - He didn’t have the tools to communicate his frustrations peacefully and with gratitude
- After he went through this transformational workshop and started learning these tools and practicing them, integrating the healing, he later went back to this business partner (that he didn’t speak to for months) and had a meeting with him
  - He just thanked him; he said, “*Hey, I’m so grateful for you. I appreciate you*.”
  - He was able to sit with him for a couple hours and find peace and actually then sell the business to him in a peaceful way
  - But he didn’t have the emotional tools on how to communicate effectively before then
  - Afterwards, his business partner asked, “*What happened to you? How did you communicate like this?*”
  - Lewis was so relieved because he thought it was going to be an argument

**Sports was an outlet for his frustration**

- In this perfect storm of events, he was in an emotional, up and down intimate relationship
- Along with an emotional, up and down business partnership
- He used basketball and sports as an outlet for his frustration
  - He would take all that aggression out on others in sports
  - That’s what he knew
  - That’s what he did in football, you take all your anger out on someone else and you inflict as much pain on them as possible, but in a legal activity
- Playing pickup basketball in Beverly Hills, he kept getting in more and more tiffs and shoving matches, and eventually into a fist fight with a guy
- For whatever reason, when someone would give him a little elbow to the side or they’d say something he felt like they were abusing him
  - It felt like he was five years old
- Lewis reflects, “*The psychological child in me felt like this is an act of abuse that could take it farther and farther, and I could do everything in my power to protect myself physically, emotionally, psychologically, because I never want that feeling of being powerless again. I never want the feeling of being taken advantage of again.*”
  - This was a pattern that would repeat in different scenarios
- That fuel of needing to look good, wanting to be right, proving people wrong, building himself up to protect himself
  - It allowed him to be so consistent, so driven, willing to work unlimited hours to get results
  - But it left him feeling extremely empty, lonely, insecure, and not free inside

> “*I still felt like a prisoner internally*”‒ Lewis Howes

- All these events came to a head around the same few months, and that was the wake-up call

***He doesn’t think he would’ve woken up if just one thing happened, but all of them at the same time was a wake-up call***

- It was three big things:
  - 1 – His best friend saying, “*You shouldn’t be playing basketball with us anymore*”
  - 2 – His business partnership situation
  - 3 – The blow-up with his girlfriend

## A powerful workshop on emotional intelligence jump started Lewis’s healing journey [27:30]

- A few people had recommended the workshop ([Mastery in Transformational Training](https://www.mittraining.com/)) to him before and he was like, “*Nah, I’m good*”

**Mastery in Transformational Training**

- This was an emotional intelligence workshop in Los Angeles
- There’s a bunch of these workshops out there
- They’re five-day workshops that essentially use a bunch of different scenarios, games, and exercises to show you how you react in life
- They’re designed to see how you are
  - They create a mirror of real-world scenarios in a small group setting, with games, activities, one-to-one dyads, meditations, and all these different things
- You go back into the different events that caused pain, stress, overwhelm
  - The things that keep you from being your most joyful, authentic self now
- You get to discover
  - What is holding you back from giving your fullest self, from being the most loving human being you can be, from enjoying childlike joy as an adult?
  - What robbed you of your joy?
  - Who hurt you?
- Everyone goes through their own journey and their own experience, but for Lewis, it was extremely powerful

**Did this workshop put everyone through the framework of, anything that is not happening for you today is probably tied to “contamination” of your true self as a child?**

- Everyone goes through the same exercises
- Some exercises did not resonate with Lewis, but for other people, it was the biggest eye-opening experience
- While other exercises were a big breakthrough for him

***The exercises are all designed to show you how you show up in life currently, to understand what’s working for you, what’s not working for you?***

- They also introduced tools that you can use moving forward to be a better version of yourself
  - Through leadership training, through emotional intelligence, language, things like that
- Lewis got a lot out of it because he had so much pain he was holding onto for 25 years

**Did you talk about it there for the first time?**

- Yes
- No girlfriend in the past knew
- His family didn’t know
- He didn’t tell any friends because he thought if people knew about this, no one would love him
  - He thought no one would accept him; no one would be his friend

***One of his biggest fears was people not accepting him, but really, what happened was he never fully accepted himself***

- He wasn’t able to forgive, find meaning in that experience, and lots of different experiences that occurred in his childhood
- He was just filled with so much shame about these things, and he thought, “I*f any of my buddies knew these things about me, and my college football teammates or high school basketball team knew this, they wouldn’t want me on the team*.”

***All he wanted to do was learn how to fit in and belong, but he never learned how to belong to himself***

- A lot of people don’t know how to fully love and accept themselves, with all the mess and all the stress and all the things they’ve been through
- He’s not saying you need to be proud of the things you’ve done
- There’s many things in his past that he’s not proud of, but he can **find meaning and accept and have compassion** for the 11-year-old that would steal candy bars almost every day for a year and a half
  - He can have compassion for the tools that he had, the stress he was going through, and that he stopped it and he transformed in a certain way
  - He loves that person and heals that person inside of him so that he is not in shame of all these different stages of his life

> “*I don’t think shame supports us in service. It doesn’t help us serve and give to the people we care about closest to us, to our communities, to our platforms, whatever we’re creating in the world. It holds us back.*”‒ Lewis Howes

**Healing journey**

- For many years Lewis couldn’t **sleep** at night
  - He would just sit up at night for about an hour, hour and a half, just ruminating
- It wasn’t until after he started the healing journey where he was able to fall asleep within minutes
- It hasn’t been a perfect journey over the last 10 years, but it’s been a powerful journey of constantly healing

**Was it a little easier to talk about this (something that seemed so taboo) because you were with strangers?**

- Yeah, it was part of it
- This workshop was two weekend workshops
- He did a four-day workshop that gave you some basic tools and understanding so that we were all on the same page of understanding the language and tools and leadership distinctions of accountability, responsibility, ownership of your life, things like that
- It wasn’t until the second weekend (which was a week and a half later), where it got extremely intense
  - People were opening up, extremely vulnerable and crying, and really sharing different things that had occurred
- Once other people started to share how messed up their life was, it gave him permission to be realize that other people go through stuff too and way worse scenarios than I’ve gone through in certain areas
- In the first couple days of it, the facilitator of the workshop said, “*Okay. We’ve gone back and addressed a lot of the different things that have caused you to guard your heart, that have caused you to be more analytical in your mind and be less peaceful, and not own your peace, and own your love, and give your love generously to others*.”
  - He said, “*Now we’ve addressed these different scenarios. We’ve addressed your mom, your dad, different scenarios from childhood. We’ve done these different exercises and games. Then we have reflection and journaling, time to start integrating these things.*”
  - And he said, “*Now we’re not going to go back into the past anymore. We’ve done enough. We’re going to start creating a vision of the future you want to create. The “who” you want to be, how you want to show up in the world, what you want to create, the type of relationship you want to have, the type of dreams you want to manifest. And we’re going to start building tools into developing how to create that, and getting clear on the vision you want for your life.*”
  - And he said, “*But before we do,* ***if there’s anyone who has yet to be clear of their past and talk about or address something they need to talk about ‒ now is the time****, or forever hold your peace because we’re moving forward. We’re not going back anymore. Let’s go on with our lives and start creating a powerful vision we can live into.*”
    - The room was silent
- Lewis remembers thinking on how he had been going all-in on this workshop
  - He talked about challenges with his parents, his brother going to prison, about being dyslexic his entire childhood and being in special-needs classes until he finished college, being picked-on, being picked last in sports (all these painful memories)
- He remembers asking himself, “*Why have I still not talked about this one thing? Why have I yet to talk about it?*”
- It hit him, “*If I don’t talk about this now, I’ll probably never speak about it in my life. I’ll probably keep it in my grave.*”
- The environment and setting helped; other people were opening up, and it gave him courage in that moment
  - Without it, he doesn’t think he would have ever had the courage to speak to his future wife, his parents
  - He doesn’t think he would’ve told anyone because he didn’t have the courage emotionally
- He remembers standing up, there were probably 40 people in the room
  - He walked to the front of the room; he didn’t even raise his hand
  - He remembers looking down at the carpet, and walking through this story for the first time, reliving it like he was in the bathroom being sexually abused by this man

> “*Almost like I could go to the scene 25 years prior. I could see the room, the mirror, the bathroom I could smell, I went back there*.”‒ Lewis Howes

- He was so **ashamed** that he couldn’t look up at anyone’s eyes; he just stared down at the carpet and walked through this story step-by-step
- He remembers walking back to his seat, sitting down, and just erupting with tears, bawling
  - And he didn’t really cry that much
  - He was conditioned not to cry as an athlete and as a man, and he just bawled
  - It was so beautiful because there were two women on the sides of him, and they were crying and both hugging him
  - The whole room is starting to cry and he thought, “*My life is over*”
- He got scared and ran out of the room and left the event
  - He went out of the hotel conference room, outside to the back alley of the hotel
  - He had his head in his hands sobbing, on the wall in this back alley
  - He thought, “I*‘m never going back in there. I’m done, I’m going home. My life is over.*”
- Then one of the most beautiful things happened as he’s crying on this wall, he felt this tap on his shoulder
  - He turns around to see a 55/ 60-year-old man, big guy
  - He’s looking at me in my eyes, staring at me crying,  and he said, “*You’re my hero, I will follow you anywhere, and I had everything wrong about you*.”
    - Lewis reminds us that he showed up with an ego, he thought he knew it all
  - This man continues, “*Let me tell you something. I’m in my late 50s, I’ve got four kids. I’ve been married for 25 years and my wife doesn’t know, my kids don’t know. No one knows. This happened to me when I was 11. For many years, it’s still the deepest secret that I have. You’re the first person that knows. Thank you for having the courage to open up and give me permission to start talking about it. I’m going to go tell my wife tonight. I’m going to start the healing journey. Thank you*.”
- Lewis was in shock; the man hugs him, and they cry together
- Then one by one, probably 12 or 13 men come out of the room, and they all come and give him a hug
- Not everyone had been sexually abused, but a few other guys had been
  - A few other guys said, “*I’ve never told anyone. Thank you for opening it up… This happened to me when I was 8. This happened to me when I was 13. This happened to me when I was 7*.”
- It was very therapeutic and very healing to hear that other men have experienced this and to talk about it
- Lewis finished the workshop over the next few days and had a powerful experience of catharsis and healing

## How being authentic can strengthen bonds with family and bring inner peace [39:30]

**He remembers thinking, “*****I can’t tell my family*****”**

- It was one thing to tell strangers, but what are his family and friends going to say?
  - He wondered if they would be emotionally available and courageous to be able to receive this information
- Lewis reached out to a therapist friend afterward and started to open up about it
  - He shared that he was terrified to tell his friends and family; he was worried that they would not accept him
  - He asked him, “*What’s a process I can use to connect with them to see if they’re available to hear it?*”
  - His friend/therapist recommended, “***Ask them all a question before you share with them*** *‒ “Is there anything I could ever say or do that would make you not love me?’ And based on their response, if you feel like they’re receiving of it, then you can open up and talk about it.*”
- As he shared, one-by-one with his family and then friends, it brought him closer to all of them
- In turn, they started to open up about things that he didn’t know about them
  - Things that they went through that he had no clue about
  - It created a stronger bond of intimacy and connection
  - And that was really the journey where Lewis was like, “***Wow. I’ve been missing out my entire life (25 years) of true intimacy and real authentic connection, because I’ve been hiding myself from so many people.***”
- Lewis is *not* saying that you’ve got to reveal all your darkest secrets to everyone right now, and publicly, but we’re missing out on something beautiful

***We will never be peaceful and fully free (internally or externally) until we can accept the things of our past that we are most ashamed of, afraid of, insecure about. We will always be a prisoner in our heart and mind until we can face it, and accept it, and embrace it.***

**Prior to this moment, what was your relationship like with your parents and siblings?**

- He loved his parents but had a challenging relationship with them
- He grew up in a stressful environment; his parents were explosive with each other
  - They got married when they were 18, and they didn’t have the emotional tools until later in life
  - They stayed together because of the kids and kept having more kids
  - They probably shouldn’t have stayed married
- He begged them to send him away
  - He grew up with a lot of uncertainty and fear
  - He doesn’t blame his parents; they were doing their best; but it’s one of the reasons that made him want to leave
  - He was the youngest, and at age 13, all his other siblings were out of the house
  - He wanted to be in a peaceful environment, not at home
- Lewis was also doing bad things as an 11/12-year-old
  - Stealing
  - Hanging out with people that influenced him to do bad things
- He wasn’t accepted by other people in school, so he would cling to anyone that would accept him
- He realized, “*I don’t want to be in this environment. I don’t want to live this life anymore. I want to be around good kids, good people*.”
- His parents were great, they would show up to all his sports games, they were extremely supportive
- They encouraged him to follow his dreams
- They taught him a lot of great lessons
- But, their modeling of a relationship was not a good model for him; it caused underlying stress
- He was away from them for five years
  - He only went home for a couple weeks at Christmas, and breaks, and here and there
  - They would come out and visit and watch games, but it would be for a few hours and then they were gone
- Lewis really lived alone with roommates from age 13 to 18
- During that time, his siblings were all off in college doing their life
  - He had a good relationship with them, but he didn’t see them that often

***Lewis remembers at age 30, wanting to reconnect with his family more, and build stronger bonds and stronger relationships, and sharing this trauma allowed him to start that process***

**When you think about your siblings, and your parents, and your friends, who were you most concerned with about having that discussion?**

- Probably his friends because he still wanted to belong in society beyond his family
- Your family’s got to love you and accept you no matter what
  - At the end of the day, they’re stuck with you, essentially
- He told his family first
  - He thought that after what his brother went through, they would accept him
- He wondered if his friends would accept him
  - That was probably the scarier thing to talk to them about
  - But, all them were extremely supportive and and open and loving

**Sharing with his family and friends brought him a lot of inner peace, which he never had**

- He didn’t have this inner peace because he was being inauthentic to who he was
  - He wasn’t accepting himself or fully loving himself
- He was always putting on a mask; he wasn’t able to reveal who he was
  - Therefore others didn’t know who he was and weren’t able to fully accept him
- He was a happy fun-loving guy (the same as now), but he wasn’t as vulnerable

***He felt like he wasn’t revealing something inside and it was constantly eating him up***

## Comparing adversity with trauma and finding meaning in struggle [45:15]

**Where do you draw the line between trauma and adversity?**

- One of Peter’s best friends ([Paul Conti](https://www.pacificpremiergroup.com/coaches-consultants/)) has been on [Lewis’s podcast](https://lewishowes.com/podcast/trauma-the-invisible-epidemic-how-to-heal-from-it-with-dr-paul-conti/) (see the links at the end, under selected links)
  - Paul is an expert on trauma
- Paul was one of the first people Peter met in med school, and they’ve been largely inseparable since
- Peter notes that the effects of **trauma** are probably a *net negative*
- **Adversity** has some positive and negative impacts, but it is probably a *net positive*

***Lewis tries to find meaning in both adversity and trauma; he looks for useful tools that could come from them***

- Previously, he was just afraid of trauma and more embraced adversity
- Examples of adversity for him:
  - The challenges of overcoming being down in a sports game or getting a minor injury and fighting through it
  - Playing with a broken wrist for 14 games as an athlete
  - Playing with three broken ribs was like that’s the adversity, and you just have to tough it out and overcome adversity
  - Those are also traumatic events too, breaking bones and living with physical wound trauma
- He looks at physical trauma differently than the emotional trauma/the psychological trauma, which really shaped his personality and identity
- As [Dr. Joe Dispenza](https://drjoedispenza.com/pages/about-us) says, “*Your personality becomes your personal reality*”
- These emotional and psychological traumatic wounds became part of Lewis’s personal reality
  - It became his inner world
  - This reflected in his outerworld through his reactions

> “*Both of these events, adversity and trauma, can be extremely beneficial if we find meaning*”‒ Lewis Howes

- It’s harder to find the meaning from traumatic experiences and things that no one wants to go through; things you don’t want your enemies to go through:
  - Loss of people close to you, sexual abuse, psychological abuse
  - Horrible things that happen in the world ‒  mass shootings
- Lewis recalls the book [*Man’s Search for Meaning*](https://www.amazon.com/Search-Meaning-Classic-Tribute-Holocaust/dp/1846042844/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Viktor Frankl
- He has had the Holocaust survivor Edith Eger on his podcast a couple times (in [2020](https://lewishowes.com/podcast/healing-forgiveness-and-finding-freedom-with-holocaust-survivor-dr-edith-eger/) and [2022](https://lewishowes.com/podcast/holocaust-survivor-reveals-how-to-heal-trauma-destroy-negative-thoughts/))
  - She talked about watching her parents go into the gas chamber in Auschwitz, and the trauma that she faced for so many decades
  - It wasn’t until she went back there herself and was able to face it and **forgive herself** because she essentially told the truth to the officer
    - When the officer asked her, “*Is this your sister or your mom?*” And she said, “*My mom.*”
    - And so she watched her mom go and be executed
    - If she just would’ve lied and said her sister, maybe her mom would’ve stayed alive
  - She had to relive that, face it, and find forgiveness in herself for the teenager that was fearful, insecure, who didn’t have the tools, who wasn’t to be able to navigate such a traumatic moment
  - She was able to find peace and meaning from that and use the meaning to be of service to others
- I don’t think any one of us are going to get out of this life without experiencing some type of “Little T/ Big T” trauma, and the feelings can all be extremely overwhelming

***Lewis thinks it’s our mission and our goal to figure out what is the meaning from it, how could you benefit from it and serve others in this meaning as well***

**There is a good type of adversity that builds character and life skills [49:00]**

*Does Lewis have kids?*

- No, not yet, but he would like to one day
- Peter notes, “*When you think about having kids… there’s a very protective nature that comes up*”

- Every parent looks at their kid and thinks, “*I want to shield them from the bad things that happened to me, and I want them to have wonderful experiences*”

- Yet there’s always a fear that if we take that to an extreme, we deprive them of something

**There is a type of adversity that is character building and valuable**

- Not getting picked for a sports team hurst in the moment, but it also produces a lot of good
- Versus sexual abuse when you’re five; no parent under any circumstance would be okay with that
- Lewis replies, “*Those experiences could have ruined me had I not had supportive people around me 25 years later to encourage me to talk about it, to go get support, get coaching, go to therapy, try workshops*”
- He has tried so many different therapeutic experiences in the last decade, and he always approaches it with a beginner’s mind (and an open mind)

***Before, he thought he knew it all, and that didn’t give him a sense of peace. Now he goes into stuff with the attitude ‒ how can I learn?***

- He would never want any kid to experience what he experienced
  - There’s no good that comes from it

***He had to find meaning from the traumatic experience so he could have peace in his heart***

> “*I realized if I didn’t create peace in my heart and find meaning, then it would’ve ruined me*”‒ Lewis Howes

**Without this, he would have been more reactive**

- He probably would have gotten into more fights
- He would have blown up his lift
- That’s what was starting to happen
- He was accomplishing more and more, so he was becoming more well known and he had more to lose

***If he didn’t learn the tools of emotional regulation, of healing, of effective communication, then he probably would’ve done a lot more damage to himself and the people around him***

- Finding meaning behind it all supported him and helped him have more compassion and empathy
- Lewis doesn’t wish trauma on anyone
- As [Jordan Peterson](https://www.jordanbpeterson.com/about/) says, you don’t want to protect your kids, you want to create a safe environment where they feel loved by you and accepted
  - You want to allow them to be vulnerable because that’s how they get stronger; that’s how they can develop courage when challenging things happen, when us parents are not around and they can have the tools to take on the adversities of life

***It’s a balance between wanting to give them so much love and acceptance, but also putting them through the most adversity you can in safe containers, to give them tools of overcoming and learning how to do it on their own***

- Peter and his wife talk about this; they have 3 kids, ages: 5, 8, & 14

**Peter uses the mental model of the immune system to think about adversity**

- It’s well known now, but one it was speculated that if you took a child when they were born and put them in an environment where their immune system is never challenged, they will never get sick
- But something worse is going to happen ‒ their immune system will turn on the body and they will develop ravaging autoimmunity
- The immune system undergoes [negative](https://en.wikipedia.org/wiki/T_cell#Negative_selection) and [positive selection](https://en.wikipedia.org/wiki/T_cell#Positive_selection) so it becomes good at recognizing self from non-self
  - [Thymic selection](https://en.wikipedia.org/wiki/T_cell#Thymic_output) of T cells occurs when you’re an infant
- The immune system is a very potent system; it has remarkable killing capacity
  - That’s what keeps us safe from viruses
  - We don’t have good drugs to combat viruses the way we do bacteria
- When children are put in a position where they do not have enough exposure to pathogens, problems arise
  - For example, food allergies
  - It’s not a coincidence that we are seeing nut allergies go through their roof as kids are having less and less exposure to nuts when they grow up
- So at the one end of the spectrum, you put your kids in a bubble and they don’t get sick, but their immune system attacks themselves, so they end up with ravening autoimmunity
- Prior to the advent of antibiotics and things like that, and when we had no sterilization, our life expectancy was literally half what it is today
  - Largely due to infectious diseases

***So there’s this happy medium where your immune system has to be honed to be strong enough to know what is “Lewis” and what is “not-Lewis”, so that it always attacks “not-Lewis.” This is how Peter thinks about adversity with kids.***

- It’s pretty good when they finish last in a race and they’re embarrassed about it because they didn’t train that hard
- Or it’s pretty good when they blow a test
- But at the other end of the spectrum (and this really comes from discussions between Peter and Paul Conti and a few others; and Lewis’s story resonated this), ***the thing that we really want to avoid is children having a feeling of complete helplessness***
- Peter suspects that perhaps the most traumatic thing about Lewis’s experience as a child was the total helplessness

***Peter thinks helplessness and shame compound each other***

## Association between adverse childhood events and diseases in adulthood [56:15]

**Did you ever take the** [**adverse childhood event (ACE) test**](https://en.wikipedia.org/wiki/Adverse_Childhood_Experiences_International_Questionnaire)**?**

- No, Lewis has never heard of it, but he should
- Peter has many of his patients take a [10-question ACE test](https://www.aceresponse.org/img/uploads/file/ace_score_questionnaire.pdf), when it’s relevant and potentially germane to their care
  - They are simply yes/ no questions
  - For example:
    - Have you been sexually abused?
    - Did you grow up in a household where your parents were divorced?
    - Did you grow up in a household where one of your parents physically assaulted the other?
  - Lewis answers yes, yes, yes
  - Though Lewis did not grow up in a household where a parent went to prison
    - Peter thinks this would be true for Lewis because a sibling 11-years older is effectively a parent

![](https://peterattiamd.com/wp-content/uploads/2023/03/f1-lewishowes.png)

**Figure 1. Many people report ACEs**. Image source: [CDC 2021](https://vetoviolence.cdc.gov/apps/aces-infographic/home)

- If you fill out the Adverse Childhood Event Score, data show the predictive value of the score on both physical health and emotional health
  - The figure below shows the adjusted odds ratio (AOR) for health conditions stratified by ACE score; numbers in bold reached statistical significance
    - Many diseases show a dose response ‒ the odds of developing a disease increases as the ACE score increases
    - The % affected is also shown

![](https://peterattiamd.com/wp-content/uploads/2023/03/f2-lewishowes.png)

**Figure 2. Adjusted odds ratio (AOR) for adult health conditions by ACE score**. Image credit: [*American Journal of Preventive Medicine* 2015](https://pubmed.ncbi.nlm.nih.gov/25300735/)

![](https://peterattiamd.com/wp-content/uploads/2023/03/f3-lewishowes.png)

**Figure 3. Lasting impacts of adverse childhood experiences (ACE)**. Image credit: [CDC](https://www.cdc.gov/violenceprevention/aces/about.html)

![](https://peterattiamd.com/wp-content/uploads/2023/03/f4-lewishowes.png)

**Figure 4. Reducing ACEs has the potential to reduce many problems in adulthood**. Image credit: [CDC](https://www.cdc.gov/vitalsigns/aces/pdf/vs-1105-aces-H.pdf)

- It’s probably not surprising that the higher your ACE score, the worse your emotional health
  - The greater the likelihood of anxiety, depression, suicidality and these things
- Peter notes the surprising effects on physical health ‒ the higher your ACE, the worse your physical health as you age
  - In his experience, people aren’t able to take care of themselves if they have a lot of unresolved trauma
- He suspects this is probably confounded by socioeconomic factors
  - You often see higher ACE scores in lower socioeconomic status
- Lewis agrees, if you live with a higher score and you haven’t learned how to heal and navigate them in a healthy coping mechanism way, processing the trauma, healing and being on the journey of consistent healing, you are constantly reliving past traumatic events for which you have not yet healed
  - Your immune system is under attack as if it’s fight or flight
  - If it feels like it’s still a your child-self in these moments, and you’re stacking all of them on your body and your immune system at once and connecting the thoughts to your immune system, your body can probably never fully recover
  - Your body probably can’t build the strength to get rid of the bad cells the way it needs to with that much trauma.
  - [Paul Conti](https://www.pacificpremiergroup.com/coaches-consultants/) talks a lot about this connection the immune system

> “*When we learn to create the environment of peace and harmony and alignment in our heart, connect it to our mind, then the body will start to follow*.” —Lewis Howes

## How addressing his issues with intimate relationships helped Lewis overcome physical pain related to his past trauma [59:15]

- Lewis feels like there’s a lot less pressure on his heart now
- He used to feel a lot of pain in his chest, physical, sharp chest pain would come and go
  - It wasn’t related to working out
- Two years ago, Lewis did a five-month intensive therapy coaching experience
  - He practiced that for a few years, and he really felt peace and free from his trauma
- He’s done a lot of different modalities over the last 10 years to help him process the sexual abuse, but he was still having chest pain and a sensation of throat clenching
  - He processed other stuff with his parents
  - He did a lot of good work, but these feelings occurred when something triggered an emotional response
    - He felt like someone was strangling him or pressing a weight on his heart; he couldn’t breathe fully
  - This pain still happened off and on because he had not yet healed a lot of things in intimate relationships
    - He was still afraid in intimacy with romantic partners
- It was only the last relationship he was in where he had that perfect storm of events happening over and over where he started to recognize that **he was abandoning himself**
  - This took a lot of courage
  - He was repeating this pattern of abandoning who he was, his values, his vision, his identity, his beliefs to please one person that he thought he loved and was in an intimate relationship with
  - ***In order to make them happy and keep the peace externally, he would change who he was to make them happy***

**He realized he was the common denominator of why his previous relationships did not work out**

- He was choosing based on a wound, staying based on a wound, and abandoning who he truly was based on wounds
- Two years ago he said “*Enough is enough*”
  - He realized that he didn’t feel stress/ pain around the sexual abuse, being picked on as a kid in school anymore; he was able to process that
  - He still didn’t have the courage to be 100% who he was in intimacy
- He is so glad he found this therapist/ coach, and for the last two years he has done a session with her every two weeks
  - For the first five months he was going every week, doing 6-7-hour sessions on Saturdays; doing individual and joint sessions
- But after five months, there wasn’t any improvement
  - He realized he and his partner weren’t aligned on their values
  - He felt he couldn’t be in a relationship with someone and change all my values and beliefs to make them happy
  - He realized he was repeating a pattern ‒ he was attracting people that didn’t have the same shared values, vision and lifestyle

> “*For whatever reason, there was a wound that I was doing this from*”‒ Lewis Howes

**Do you think that you were finding somebody that had a hole that you felt you could fill?**

- Yes, 100%; he felt like they needed him
- He felt like there was something he could do to support them
- This was something unconscious that he was repeating

***He was following the model of his parents’ relationship; he was trying to fix his parents through the relationships he was in***

**During this five-month period, were you growing as a response to this therapy?**

- Lewis has met so many interesting people to interview on his show: [Paul Conti](https://www.pacificpremiergroup.com/coaches-consultants/) (on trauma), [Dr. Ramani](https://doctor-ramani.com/about/) (on narcissism) [links to these podcasts are at the end of the show notes in selected links]
- He’s interviewing all these different therapists and experts on neuroscience, and he’s starting
- Interviewing people about trauma, relationships, healing, and all these things are starting to connect the dots after about five months
- There was a moment where he went away for a weekend to go to a kind of business mastermind event in Florida with some people that you’d know in the industry (like [Tony Robbins](https://www.tonyrobbins.com/))
  - The person he was dating at the time was supposed to come, but the day before she got mad about something and decided not to go
  - Lewis remembers going to this event and feeling so much love from people
    - Feeling accepted, feeling loved, feeling celebrated for the person that he was showing up as
  - And yet, he wasn’t able to experience that at home and in this relationship
    - He was forcing it and trying to make it work and changing who he was to belong and fit in, in the relationship
  - He remembers texting the therapist at that time, “*I can’t do this anymore*”
    - She replied, “*You’re starting to lift the veil. You’re starting to realize and see the things that aren’t working.*”

***Lewis realized he was abandoning himself to please one person, trying to make the relationship work. He wasn’t pleasing himself, and he was letting go of his authentic highest self.***

- Over the next month he went deeper and deeper into therapy, both individually and together
  - At one moment, talking about his parents he realized, “*I don’t want to feel trapped. I want to feel free.*”
  - It was kind of like connecting the dots from 38 years of life, his brother in prison, watching his parents trapped in a marriage being unhappy
- After five months of doing this, she said to him, “*Lewis, you’re free. You can walk away at any time. You don’t need to keep forcing things. You are free.*”
  - For whatever reason, this connected in his heart where he actually understood the concept
  - ***And in that moment, all the pain that was in his heart/chest this whole time somehow disintegrated***

**He didn’t believe he could be free internally even if things weren’t working out externally**

- He thought he had to do whatever it took to make it work, go in harder and sacrifice who he was to please one person
- He lacked the emotional courage to walk away when they weren’t aligned on their values and vision, when they weren’t a right match

**Since this time (the last 1.5 years) he hasn’t felt this pain in his chest**

- He felt the pain disintegrating throughout his whole body
- He felt like he could breathe and had peace internally for the first time, and he believed it and he owned it

**The end of that relationship**

- The fascinating thing that happened after this is he started showing up for himself and he didn’t abandon myself again over the next few weeks of the relationship
  - He created his value, his boundary
- She didn’t like that; she didn’t like him not giving in and not giving her what she wanted all the time
- He was responded, “*That doesn’t work for me and here’s my boundary and here’s what I’m willing to do and I’m not willing to do this*”
- It became clear to him that it was time to walk away, and even in the chaos of her not liking him and the relationship, he had so much peace
- He was never okay with hurting someone he cared about before this
  - He would give in and mold to try too make it work (abandon himself)

**It was a beautiful thing to interview Paul Conti and so many other experts**

- As he was living this moment, as he was experiencing this physically, emotionally, and connecting the dots mentally and tying it all back to the childhood stuff
- It was amazing for the actual first time to feel pain free in his body
  - And it wasn’t because of something he was doing physical
  - ***It was psychological and emotional trauma and wounds that were still hurting me that I hadn’t faced and fully addressed***

## Healing is a journey that takes time and requires courage to face your fears and insecurities [1:08:45]

- There was a moment when the pain went away, but it didn’t mean there weren’t tremors, some [PTSD](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder) feelings that he had to keep breathing through and practicing and integrating these lessons
- In other moments, he wondered if he was going to go back into fear and how he used to be, or was he going to lean into courage, lean into owning who he is and not abandoning himself?

***Every time he kept stepping into the emotional courage and speaking his truths, it gave him so much more confidence, peace, courage, energy, freedom that he’d never fully experienced in intimate relationships***

- Being real to himself and to the people that were upset with him, and just saying, “*Well, I’m sorry you feel this way, but this is my vision and we’re just not a good match*”
- And it has been a complete game changer in every area of his life since integrating these lessons and being consistent with it when he feels a sense of  maybe he could go back into that old way of being
- Knowing that he’s going to be okay/ safe with conflict
  - It may be a little disturbance, but he’s going to be able to manage it

> “*It’s been a beautiful journey, but it has taken a lot of emotional training and consistency*”‒ Lewis Howes

- He did an eight-hour therapy session one day on a Saturday to just say, “*I’m all in. I’m committed to peace and freedom.*”

***And what he’s realized is that it is truly hard to live a fulfilling, rich, abundant, joyful life, peaceful life unless we are willing to face the wounds, the fears, the insecurities, the shames, the guilt, all that stuff that has held us back***

- The more Lewis interviews experts who study this, and the more he experiences it firsthand and sees actual results personally, he’s convinced that ***when we face the emotional trauma, psychological traumas of our past and we own it and we process it, we will be free***

**Peter’s takeaway‒**

- These are not digital switches; these are not either zero or one
- It’s not like in 2013 when your life was about to implode and you went to this workshop and it was all good
  - Sure, he had a very powerful experience, and he revealed perhaps the greatest “tea” in his “bag of teas”
- It’s actually more analog; it dials up and dials down

***This is an important distinction because it can be very discouraging when you make progress and then you take a step backwards***

- Lewis agrees; he thought he did a lot of work but then realized he was still repeating this pattern in intimacy in relationships
  - He thought he healed it and wondered why it was still coming up
- When Lewis has kids he’s going to need to face things courageously that are from childhood
- He’s going to have to show up and have the **courage** and be able to sit in discomfort when his kids are crying, or when his kids are sick, or when they’re afraid
- He’s going to have to learn how to become a better emotional leader and lean into these things that held him back in the past and have that emotional courage
- He’s going to have to do things he’s never done before, and step into that emotional courage in relationship and children, all that stuff
- As we age, everything is going to have to have more and more courage

## How Lewis thinks about mortality and uses it as motivation to pursue his dreams [1:13:00]

**How much do you think about mortality?**

- Every day, multiple times a day
- His father just passed away a year ago

**When Lewis was 20/ 21, his father got into a car accident that caused traumatic brain injury**

- A car crashed into his father’s car and the bumper came through the windshield and hit him in the forehead, splitting his head open
- His father was on a trip in New Zealand with his then-girlfriend at the time (his parents had been divorced for years)
- He was cut out of the car, and had to be airlifted to a hospital in New Zealand where he was in a coma for three months, asleep

***This was another traumatic event that happened to someone close to me, someone I cared about deeply, a mentor of mine, someone that was there for me in a lot of ways***

- For four to five years after the car accident, Lewis was really angry and upset and afraid
  - Because his father was in a lot of ways a big mentor and a teacher of; he supported Lewis to chase his dreams
- His father gave him a lot of lessons as a kid
  - Some things Lewis didn’t understand until later
- His father never celebrated his birthday, and when he was a kid, this upset him
  - When Lewis was 9 (or 10 or 11) he asked, “*Dad why don’t we ever have a birthday for me? There’s all these other kids that have birthday parties, but I never have a birthday party.*”
  - His dad said, “*I never want you to be limited by your age. Most people I see make an excuse that they’re too young to try something, or they’re too old and it’s too late, and I never want you to have that excuse.*”
- When his dad went through his coma, it was extremely traumatizing for the entire family
  - It was kind of like his brother going to prison
  - It was an experience of uncertainty, fear, and loss
- His dad got out of the coma three months later, came back to the USA, but he couldn’t speak for almost a year
  - He could barely walk
- It was so hard to see another hero of Lewis’s who didn’t have the ability to live his full personality and his life
- For many years his dad did different therapies, physically and psychologically
- He eventually was able to talk again, to write some and function minimally, but he could never work again
  - He stayed home 24/7
  - Sometimes he could get out and walk a little bit, but he had so many different broken bones, and ammonia, and collapsed lungs, and the brain trauma was so intense that essentially he was physically alive, but mentally and emotionally he had died
  - That was another hard thing to witness
- Lewis was unable to have a real conversation with him
  - Every time he’d see him, it was, “*Hey, son, where’d you go to school again? What sport did you used to play? Oh, that’s right, you played football.*”
  - Sometimes he got Lewis confused with his other brother and call him Chris
  - It was the same conversation on repeat for 17 years until he just passed a year ago
- Lewis doesn’t wish this on anyone
  - To have a loved one go through a traumatic brain injury; to have them physically alive but have to take care of them like a five-year old
    - Change his diapers
    - Make sure he’s not burning himself on the stove
  - His dad couldn’t drive

***It was such an emotional sadness to have that loss and see him physically unable to live the life that he once had***

**The experience with his father motivated Lewis**

- He got so clear that he was going to do whatever it took to pursue the dreams inside of him
- There was no fear of failure; it was just, “*I’m doing it and if I fail, I’m fine with it because I don’t want to die regretting that I didn’t at least go for it*.”

**Pursuing his athletic dreams**

- Shortly after that, Lewis tried out for professional football teams and made a pro football team
  - Then he got injured
- Two years later, he had this dream of playing in the Olympics
- He figured out how to make money and moved to New York City to play with the handball team and learn the sport of handball and try to make the USA team
- He made the USA team a year after that
  - He traveled the world with the USA team while he was building a business
    - He did it digitally and virtually, running webinars and things like that all over the world to pursue a dream that he was not getting paid to do just because he knew this is something that he wanted to do, at least give it a shot
  - He played in Spain and Israel and Luxembourg and Canada and Mexico and Uruguay and Argentina and Brazil
  - He traveled over the world, paying for my own travel to wear the USA across his chest, be able to sing the national anthem and play against Olympic teams
  - They never qualified for the Olympics

> “*Just because the dream didn’t come true, doesn’t mean it wasn’t a dream come true*”‒ Lewis Howes

***The experiences, the lessons, the growth, the adversity he faced, the injuries he overcame, all these things… and his dad never was able to watch. He was alive, but he never came to a game. He didn’t really understand what life was anymore.***

- Lewis has gone after everything for these past 17 years because he knew this could happen to him at any moment

***Life is not guaranteed today, tomorrow, and it gave him a lot of courage to say yes***

- He wrote a book before he was 25, even though he almost flunked out of English in high school
  - He didn’t care if he was embarrassed; he’d rather be embarrassed and give it a shot than be regretting that he never tried and let the dream die inside him

> “*I really believe self-doubt is the killer of dreams and people hold onto their insecurities and self-doubt so much that they really never launch the dream or even try for it”*‒ Lewis Howes

***For Lewis, the results are irrelevant because it’s about the things he learns about himself, the people he meets, the connections, the moments that are meaningful along the way***

- It became so real when his father had this accident
- He had to learn how to accept it after four or five years, when it was just kind of a suffering depression around his father‒ hoping he’d recover, hoping he’d get back to who he was
  - He had to learn to accept that his father sometimes isn’t going to remember who he is, that he’s going to have the same conversation on repeat, that he’s going to forget, that they would never have a meaningful relationship
- Lewis had some great moments with his father, some great conversations in the last few years before he passed, but it was essentially a really sad time for 17 years

**It was almost like he didn’t get to grieve emotionally until last year**

- His father, even though physically he was alive, he was kind of mentally and emotionally gone
- Lewis feels like these last two years, therapy, the process of death, and my father going through this accident 17 years ago, gave him so much clarity

***I’ve got to take care of my body. I’ve got to take care of my mind. I’ve got to take care of my emotions. It could all be gone at any moment.***

- He wants to be proud of the actions he’s taking
  - He wants to be proud knowing that he went after the dreams

**Lewis thinks about death daily, he reflects on it, and he appreciates his life every day**

- Peter comments that just this morning he ordered of of those calendars that is a [week calendar for your life](https://4kweeks.com/products/poster)
  - [Bill Perkins](https://www.diewithzerobook.com/welcome) talked about it on the [podcast](https://peterattiamd.com/billperkins/)
  - Peter felt like there is no substitute for the reminder every single day
- Lewis’s friend [Nas Daily](https://www.instagram.com/p/ChKA6QIpwOq/) has worn one shirt for the last seven years (see the image below)
  - It’s a shirt that has a battery and it says,”35% life,” and that’s how much life he’s lived
  - ***He wears the same shirt as a reminder to live his full life today***
  - He changes the shirt every year and reduces the percent; he gets about 20 of them for the year
  - He wears them in every video

![](https://peterattiamd.com/wp-content/uploads/2023/03/f5-lewishowes.png)

**Figure 5. Nas Daily**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Nas_Daily)

## How anyone can benefit from therapy or coaching, and Lewis’s advice for finding inner peace [1:22:45]

**What do you say to the person listening/ watching who say, “*****I can see how in Lewis’s case, all this therapy was necessary, but I don’t think it’s necessary for me*****”?**

- Lewis has made a very compelling case for how different modalities of therapy have changed his life
- Many people will think that they don’t need therapy
  - They never went through horrific things
  - Their relationships aren’t perfect
  - They can be a little reactive, but they say “*There can’t be any upside in talking about this because there’s nothing to really talk about*”
- Lewis has tried a lot of stuff, and he’s sure he could try a lot more
  - He did emotional intelligence workshops for years
  - He went to India  and studied meditation to become a meditation instructor for many weeks
  - He took a bunch of guys to [Wim Hof](https://www.wimhofmethod.com/) in Poland and did a private thing with him jumping in frozen rivers, and doing the whole breathing, and meditation, and ice training, and mindset training
  - He’s done seven day meditation retreats with [Joe Dispenza](https://drjoedispenza.com/pages/about-us).
  - He’s done coaching; he’s had therapy, I’ve done all these different things

**Lewis uses the analogy of an athlete and their coaches to explain the usefulness of therapy**

- Lewis tries to think of it in a practical sense as an athlete, and studying the great athletes and interviewing a lot of world champions from [Kobe Bryant](https://en.wikipedia.org/wiki/Kobe_Bryant) to [Novak Djokovic](https://en.wikipedia.org/wiki/Novak_Djokovic) to Olympic gold medalists
  - All the great athletes who get to the top have coaches in their field of expertise to support them in winning their sport and becoming the best
  - When they win, they don’t say, “*I’ve got it all figured out. I’m at the top. I’ve got it all figured out. I don’t need coaches anymore.*”
  - They actually go and hire more coaches that are specialized in different modalities to improve the nutrition and mobility and strength training and whatever it might be
  - ***They hire more elite coaches when they’re at the top to continue to sustain that and get better***
- As a kid growing up, **Lewis doesn’t remember being taught how to navigate** emotions, love, relationships, understanding our own emotions and how we interact with triggering events in the world
- As an athlete in a coaching environment, he was taught how to overcome stressful situations and set goals and work with a team
- But when it came to love, when it came to intimacy, when it came to running a business, these aren’t things that he learned in school
  - Some of the things transferred over, but it wasn’t really there

***Coaches and therapy and workshops have supported Lewis in developing more tools that help him overcome his fears and insecurities and become a better, more authentic version of himself, that allow him to have more peace and more abundance***

- There’s a lot of people that live a really good life, even if they have stresses and they’re not perfect
  - But that holds people back from living an abundant, joyful, peaceful life, and being willing to just try new stuff
- It doesn’t mean everything Lewis has tried works for him, and it doesn’t have to work for you either
- There’s a lot of people that talk about **psychedelics** and mushrooms and all these things, and that doesn’t speak to Lewis
  - It’s not something that calls to him in his life at this point, maybe in the future it will

**Lewis’s advice**

- Be willing to try stuff
- Listen to your friends and family
- When you’re listening to Peter on his podcast, he’s got a lot of great recommendations for these things
- Learn from the experts (like [Paul Conti](https://www.pacificpremiergroup.com/coaches-consultants/))
- Just try stuff;  maybe some of it works, maybe some of it doesn’t
- Do *not* wait until things get to the perfect storm in your life
  - Unfortunately, that’s what it takes for a lot of people to start doing the work on themselves
- Do your best to just be a constant learner, growing and developing in your emotional journey

**You’ve used the word, peaceful, many times today (peaceful life, peaceful transformation). What does that mean for you?**

- Lewis doesn’t know if transformation is peaceful; it can be very stressful and overwhelming

> “*I think inner peace is the greatest currency*”‒ Lewis Howes

- The world that we’ve been going through the last couple years, with the stress, overwhelm, COVID, isolation, economic crisis that’s happening now, war, **mental health** is being talked about more than ever

***He believes inner peace is the highest currency that human beings can cultivate and can manifest and develop***

- There’s a lot of financially rich people who have very little inner peace and they suffer emotionally
  - Their relationships are at risk
  - Their health is at risk
  - There’s a lot of wealthy people that die young because of the stresses and the traumas that they have *yet to* heal
- Inner peace is the thing that a lot of us want
  - It’s the thing we seek, we desire
  - But a lot of us just haven’t been taught the tools
- Lewis wants to have inner peace so that he can take on the problems, and the pain, and the stresses that are outside of him with more poise, with more grace, with more mature leadership qualities
  - As opposed to reactive, frustrated, stressed, anxious, overwhelmed qualities
- The greatest coaches he’s had were able to face adversity, challenges, stress, multiple personalities of teammates *with* poise, with calm, because they had inner calm
  - And those are the people that he respected the most because they were able to navigate situations in life that were chaotic with grace
- Inner peace will support you in anything ‒ in your marriage, your relationship, your family, your friends, your community, your business online, your platform, your career, and really just navigating your own life
- For Lewis inner peace is the greatest currency, and we should all be seeking to develop it

## Lewis’s newest book, *The Greatness Mindset* [1:29:15]

**We didn’t talk much about your book**

- The title is [*The Greatness Mindset*](https://info.lewishowes.com/the-greatness-mindset?source=guest-podcast)
- It’s 10 years in the making
- It is a culmination of research from experts like Peter, Paul Conti, different experts from neuroscientists to doctors to world-class athletes
- They tie the same things together, but say it in different ways about:
  - How to get clear on your meaningful mission so that your life has a lot of **purpose**, and a richness, and an excitement to it
  - How to **heal** the different things of the past that have held you back
    - Even though some of these things have actually helped you get to where you are
    - But it’s not helping you get to where you want to be
  - Figuring out how to live in an abundant, renewable energy way
  - How to set clear, what Lewis calls “**greatness goals**,” to help you make a bigger impact on the people around you
- Lewis has always wanted to be successful, but he realized that success was very selfish and me-centric
- When he hit 30, he said, “*How can I make everyone else win around me?”*
- And greatness became the thing he wanted to achieve more because greatness is about him pursuing his dreams and impacting those around him in that pursuit as well
- It wasn’t about competition, it was about collaboration
  - That’s why he made a [show](https://lewishowes.com/podcast/#) that was about lifting others up and shining the light on others
- This book has been 10 years of research of helping people get clear on what’s holding them back
  - On the main cause of their **self-doubt**
  - And the supporting on the frameworks on overcoming that and living a more **abundant life**

§

## Selected Links / Related Material

**Lewis’s podcasts**:

- [The School of Greatness](https://lewishowes.com/podcast/#) | [1:00]
- [The Daily Motivation](https://greatness.com/daily-motivation/)

**Lewis’s books**:

- [LinkedWorking: Generating Success on LinkedIn … the World’s Largest Professional Networking Website by Frank Agin and Lewis Howes](https://www.amazon.com/LinkedWorking-Generating-LinkedIn-Professional-Networking/dp/098233320X/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=) (February 2009)
- [The School of Greatness: A Real-World Guide to Living Bigger, Loving Deeper, and Leaving a Legacy](https://www.amazon.com/School-Greatness-Real-World-Living-Leaving/dp/1623365961/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Lewis Howes (October 2015) | [1:00]
- [The Mask of Masculinity: How Men Can Embrace Vulnerability, Create Strong Relationships, and Live Their Fullest Lives](https://www.amazon.com/Mask-Masculinity-Embrace-Vulnerability-Relationships/dp/1623368626/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Lewis Howes (October 2017) | [1:00]
- [The Greatness Mindset: Unlock the Power of Your Mind and Live Your Best Life Today](https://info.lewishowes.com/the-greatness-mindset?source=guest-podcast) by Lewis Howes (March 2023) | [1:00, 3:00, 1:29:15]

**Lewis’s podcast episodes about his sexual abuse**:

- [What sharing my childhood rape taught me about being a loving, vulnerable, free man EP61](https://lewishowes.com/podcast/what-rape-taught-me/) | Host Lewis Howes, [The School of Greatness](https://lewishowes.com/podcast/#) (4/15/2014) | [18:45]
- [I was sexually abused (how to heal from trauma) EP776](https://lewishowes.com/podcast/i-was-sexually-abused-how-to-heal-from-trauma/) | Host Lewis Howes, [The School of Greatness](https://lewishowes.com/podcast/#) (3/27/2019) | [18:45]
- [How I’ve overcome trauma to find peace EP1177](https://lewishowes.com/podcast/how-ive-overcome-trauma-to-find-peace/) | Host Lewis Howes, [The School of Greatness](https://lewishowes.com/podcast/#) (10/18/2021) | [18:45]

**Emotional intelligence workshop**: [Mastery in Transformational Training](https://www.mittraining.com/) | [27:30]

**Lewis’s podcast with Paul Conti**: [Trauma: The invisible Epidemic & How to Heal From it w/Dr. Paul Conti EP 1202](https://lewishowes.com/podcast/trauma-the-invisible-epidemic-how-to-heal-from-it-with-dr-paul-conti/) | Host Lewis Howes, [The School of Greatness](https://lewishowes.com/podcast/#) (12/15/2021) | [45:15]

**Book on finding meaning in trauma**: [Man’s Search for Meaning](https://www.amazon.com/Search-Meaning-Classic-Tribute-Holocaust/dp/1846042844/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Viktor Frankl (January 2011) | [47:45]

**Lewis’s podcasts with Edith Eger (Holocaust survivor)**:

- [Healing, forgiveness & finding freedom w/holocaust survivor Dr. Edith Eger EP 1010](https://lewishowes.com/podcast/healing-forgiveness-and-finding-freedom-with-holocaust-survivor-dr-edith-eger/) | Host Lewis Howes, [The School of Greatness](https://lewishowes.com/podcast/#) (9/23/2020) | [49:45]
- [Holocaust survivor on forgiveness, healing your past & living a happy life EP 1354](https://lewishowes.com/podcast/holocaust-survivor-reveals-how-to-heal-trauma-destroy-negative-thoughts/) | Host Lewis Howes, [The School of Greatness](https://lewishowes.com/podcast/#) (11/28/2022) | [49:45]

**ACE questionnaire**: [What’s my ACE score](https://www.aceresponse.org/img/uploads/file/ace_score_questionnaire.pdf) | [56:45]

**ACE score and risk of disease in adulthood**: [Childhood adversity and adult chronic disease: an update from ten states and the District of Columbia, 2010](https://pubmed.ncbi.nlm.nih.gov/25300735/) | *American Journal of Preventive Medicine* (L Gilbert et al. 2015) | [57:00]

**Lewis’s podcast with Dr. Ramani**:

- [Signs you’re dating a narcissist & how to know if you are one w/ Dr Ramani Durvasula (Part 1) EP1194](https://lewishowes.com/podcast/narcissists-vs-psychopaths-how-to-avoid-dating-one-with-dr-ramani-durvasula-part-1/) | Host Lewis Howes, [The School of Greatness](https://lewishowes.com/podcast/#) (11/29/2021) | [1:04:15]
- [How to create boundaries with a narcissist with Dr. Ramani Durvasula (part 2) EP1196](https://lewishowes.com/podcast/how-to-create-boundaries-with-a-narcissist/) | Host Lewis Howes, [The School of Greatness](https://lewishowes.com/podcast/#) (12/1/2021) | [1:04:15]
- [How to heal & move on from narcissistic relationships](https://lewishowes.com/podcast/how-to-heal-move-on-from-narcissistic-relationships/) | Host Lewis Howes, [The School of Greatness](https://lewishowes.com/podcast/#) (11/7/2022) | [1:04:15]

**Episode of** ***The Drive*** **with Bill Perkins**: [#237 ‒ Optimizing life for maximum fulfillment | Bill Perkins](https://peterattiamd.com/billperkins/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (January 9, 2023) | [1:21:30]

§

## People Mentioned

- [Paul Conti](https://www.pacificpremiergroup.com/coaches-consultants/) (Psychiatrist, President of Pacific Premier Group, author, expert on trauma) [45:15, 49:45, 55:30, 58:45, 1:04:15, 1:08:45, 1:26:30, 1:29:30]
- [Joe Dispenza](https://drjoedispenza.com/pages/about-us) (Chiropractor and author) [46:45, 1:24:00]
- [Jordan Peterson](https://www.jordanbpeterson.com/about/) (Clinical psychologist, professor emeritus at the University of Toronto, and author) [52:15]
- [Ramani Durvasula](https://doctor-ramani.com/about/) (psychologist, author, expert on narcissism) [1:04:15]
- [Tony Robbins](https://www.tonyrobbins.com/) (author, coach, speaker) [1:04:45]
- [Bill Perkins](https://www.diewithzerobook.com/welcome) (hedge fund manager, entrepreneur, and author) [1:21:15]
- [Nas Daily](https://www.instagram.com/p/ChKA6QIpwOq/) (Nuseir Yassin is an Arab-Israeli vlogger creates 1-minute videos under the name Nas Daily) [1:22:00]

§

![](https://peterattiamd.com/wp-content/uploads/2023/03/bio-lewishowes-500x500.jpeg)

##### Lewis Howes

Lewis Howes is a *New York Times* best-selling author, keynote speaker, and industry-leading show host. Howes is a two-sport All-American athlete, former professional football player, and member of the U.S.A. Men’s National Handball Team. His show [*The School of Greatness*](https://lewishowes.com/podcast/#) is one of the top podcasts in the world with over 500 million downloads. He was recognized by the White House and President Obama as one of the top 100 entrepreneurs in the country under 30.

Facebook: [Lewis Howes](https://www.facebook.com/lewishowes/)

Instagram: [lewishowes](https://www.instagram.com/lewishowes/?hl=en)

Linkedin: [Lewis Howes](https://www.linkedin.com/in/lewishowes)

TikTok: [@lewis](https://www.tiktok.com/@lewis)

Twitter: [@LewisHowes](https://twitter.com/LewisHowes?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

Website: [lewishowes.com](https://lewishowes.com/)

YouTube channel: [@lewishowes](https://www.youtube.com/user/lewishowes)