# #277 ‒ Food allergies: causes, prevention, and treatment with immunotherapy | Kari Nadeau, M.D., Ph.D.

**Source:** [https://peterattiamd.com/karinadeau/](https://peterattiamd.com/karinadeau/)

---

Kari Nadeau is a physician scientist with expertise in treating food allergies. In this episode, Kari first explains the fascinating workings of the immune system, exploring how it adeptly defends against bacteria and viruses but how the same system can lead to food allergies. She proceeds to explore the complexities of food allergies, detailing their typical developmental patterns, underscoring the significance of preventative approaches like early exposure, and highlighting the potentially life-threatening nature of severe food allergies. Kari illuminates the latest advancements in immunotherapies that not only mitigate allergy severity but also hold the potential to completely cure the patient. Additionally, Kari shares her concerns about the increasing levels of air pollution, elucidating its adverse effects on health while providing valuable suggestions for reducing exposure.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/karinadeau/the_Drive_public.png)

Play

#277 ‒ Food allergies: causes, prevention, and treatment with immunotherapy | Kari Nadeau, M.D., Ph.D.

#277 ‒ Food allergies: causes, prevention, and treatment with immunotherapy | Kari Nadeau, M.D., Ph.D.

1x15s30s

0:001:45:40

## We discuss:

- Kari’s motivation to study food allergies [4:00];
- Overview of the immune system and the family of immunoglobulins [9:00];
- How our immune system fights a virus, bacteria, or fungi, and some exceptions to the rule [13:00];
- Why our immune system is generally better at fighting viruses than bacterial infections [18:45];
- Differentiating a food sensitivity from a food allergy, and a discussion about celiac disease [25:30];
- How food allergies develop, why they can be lethal, and factors contributing to the uptrend in food allergies [35:45];
- The role of environmental factors in the onset of food allergies and strategies for prevention [50:15];
- How immunotherapy helps to overcome, and even cure, food allergies [1:04:15];
- Can immunotherapy work for environmental allergens like pollen? [1:24:00];
- Air pollution: impact on health and tips for reducing your risk [1:25:30];
- What happened to Kari’s early patient who died despite using an epinephrine device? [1:37:15];
- Resources for those wanting to learn more or find clinical trials related to food allergies [1:40:45]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Dr. Kari Nadeau is the chair of the [Department of Environmental Health](https://www.hsph.harvard.edu/environmental-health/) at Harvard School of Public Health, a professor of climate and population studies, and the interim director of [The Center for Climate, Health, and the Global Environment](https://www.hsph.harvard.edu/c-change/?utm_source=os&utm_campaign=redirect_analysis)
- Kari’s research focus on the study of immunologic mechanisms involved in the causes, diagnoses, and therapy, for allergies and asthma
- Kari earned her M.D. and Ph.D. from Harvard Medical School in 1995, completing her doctoral work in biochemistry and immunology
- She’s a member of the National Academy of Medicine and has co-authored the book [*The End of Food Allergy: The First Program to Prevent and Reverse a 21st Century Epidemic*](https://www.amazon.com/End-Food-Allergy-Program-Epidemic/dp/0593189515/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1696938156&sr=8-1)
- In this episode we talk about how the immune system works when it comes to fighting bacteria and viruses
  - The same immune system that correctly helps us fight off bacteria and viruses *incorrectly* gets wound-up when it comes to food allergies
  - You need to understand how the immune system works in the correct way in order to understand how it can go rogue
- We deep dive into food allergies, and we distinguish them from food sensitivities
- Many people listening to this will have some sort of food sensitivity (and that’s also potentially mediated by parts of the immune system), but what we focus on are true food allergies
- Food allergies can range from mildly inconvenient to outright life threatening and debilitating
  - It’s that latter area that we want to focus on
- We talk about early exposure, we talk about immunotherapies that are available
- If you have a peanut allergy and you don’t carry an Epi pen you can end up losing your life
  - Peter wanted to understand why that’s happening
  - He wants to understand what parents can do to reduce the risk of that developing in their kids
  - And for those who already suffer from those things, he wants to understand: what are the immune-based therapies that can effectively make people who would otherwise suffer a lethal anaphylaxis reaction safe
    - This is the kind of work Kari has been doing
- We also talk a little about air pollution
  - This was a real bonus for Peter because when he reached out to Kari initially, he thought they would only talk about food allergy
  - Peter has a real interest in getting deeper down the rabbit hole of air pollution, specifically PM2.5 and we go into all of that in this episode

## Kari’s motivation to study food allergies [4:00]

- It’s been 8 years since Peter and Kari were together in person
- He always appreciated the amount of time she used to make for him when he would wander into her lab at Stanford, just to pick her brain
- He always thought her work was exciting and knows that it ties into so much about what people are interested in around food allergies, even to some extent food sensitivities
- It’s also very interesting to discuss air pollution
  - This is probably something that isn’t getting enough attention with respect to health
  - Peter feels woefully deficient in his understanding though he tries to pay attention to his PM2.5 but he’s not sure what to do with that information sometimes
- Kari has now left Stanford and is at Harvard

**What Kari’s Ph.D. dissertation focused on**

- She was really excited to do her Ph.D. in biochemistry
- She learned a lot about toxicology and biochemistry
- She did her Ph.D. in parasitology working on an enzyme in a parasite called the [trypanosome](https://en.wikipedia.org/wiki/Trypanosoma), which causes [African sleeping sickness](https://en.wikipedia.org/wiki/African_trypanosomiasis) and another disease called [Chagas disease](https://en.wikipedia.org/wiki/Chagas_disease)

> “*I loved my work there because we were able to go to the very minute levels of understanding of a chemical entity to be able to create a drug to target that entity to help people with that disease*.”‒ Kari Nadeau

- She did her Ph.D. at Harvard under [Chris Walsh](https://hms.harvard.edu/news/christopher-t-walsh-dies); it was a great Ph.D., she loved it
- Then she did other work in immunology and animal models
- She is also a pediatrician by training

**What led you to study the field of food allergies?**

- She did her M.D. training at Harvard and then trained in pediatrics at Children’s Boston as well as Stanford
- With that, she had the opportunity to become a fellow in a feel that she loved: allergy, asthma, and immunology
- She had done a lot of immunology work when she did her Ph.D. in parasites because parasites are killed by immune cells
  - Especially this little molecule called [IgE](https://en.wikipedia.org/wiki/Immunoglobulin_E): it tends to kill parasites but it’s not so great for allergies
- This yin and yang of this molecule [IgE] in biology as an immunologist was really interesting
- Fast-forward, she was a fellow on the wards about to see a patient that she was being asked to consult on for a milk allergy
  - He was in the ICU after having drunk a glass of milk and having a bad reaction
  - By the time she arrived, he had died, and his parents were being asked to give consent for him to be a liver donor
  - She took care of the person that received the liver who also had a milk allergy
    - That gave her pause and really initiated her efforts in food allergy to understand the role of IgE (the role of the immune system) and how food allergies get started in the first place

***Kari wanted to know: “How in the world did a child with food allergy who died then give his same food allergy to the recipient of his liver?”***

- All of these things started to catalyze her curiosity, and she felt very blessed and lucky at the time to be able to be in a lab
- She feels that we’re obligated to be able to use that training to best help mankind and to best help those questions that parents ask us
- At the bedside of this particular young child that died, unfortunately due to a milk allergy, she’ll never forget his father trembling, asking why the [EpiPen](https://en.wikipedia.org/wiki/Epinephrine_autoinjector) didn’t work?
  - “*What can we do to help children in the future never have to die again?*”
  - Kari promised that father that she would do the absolute best to prevent further deaths in children and adults with food allergy as well as help really make sure that we educate about the use of injectable epinephrine devices and how to best use them to prevent deaths to food allergy
  - That’s her why, and ever since then she’s always wanted to really help out in this field

## Overview of the immune system and the family of immunoglobulins [9:00]

**You mentioned one of the immunoglobulins (IgE), talk about the family of immunoglobulins: what are they there for? How do we acquire them? How do they normally function?**

- We have certain proteins in our blood that help protect us and that’s what they’re meant to do and that’s great
- And they exist in different concentrations
  - Just like in a milkshake, you have different proteins that exist in different concentrations and they’re all there for nourishment purposes, sometimes for taste too
- The proteins in our blood that constitute [immunoglobulins](https://en.wikipedia.org/wiki/Antibody) are really helpful
  - For example, we learned a lot about how important immunoglobulins were to protect against COVID
    - Everyone wanted to know their “[titers](https://en.wikipedia.org/wiki/Titer#Antibody_titer)” and what that means is immunoglobulin
- IgG is the main class of immunoglobulin, and those are very protective
  - They are proteins found in high amounts in our plasma
  - [the figure below summarizes the different classes of immunoglobulins, aka antibodies]
- The minute someone is under a drug like a [steroid](https://en.wikipedia.org/wiki/Glucocorticoid#Effects) (or other drugs that affect your immune system), the amount of immunoglobulin in the blood decreases
- It’s important to have good concentrations (not too high), and immunoglobulins in general help protect us against infections and they also help protect us against allergies
- There’s another complimentary suite of immunoglobulins that don’t just stay in our blood, they get into our organs
  - Because you want to protect all of the surfaces around your organs (in addition to your blood)
  - For example [IgA](https://en.wikipedia.org/wiki/Immunoglobulin_A) class (we call that the secretory class)
    - That’s helpful in our saliva, in our gut
    - In women who are pregnant, they secrete it after pregnancy in their breast milk
    - When people are missing IgA, they have [allergies](https://en.wikipedia.org/wiki/Allergy)

![](https://peterattiamd.com/wp-content/uploads/2023/10/f1-karinadeau.png)

**Figure 1. Classes of immunoglobulins (aka antibodies)**. Image credit: [*OpenStax Microbiology*](https://openstax.org/books/microbiology/pages/18-1-overview-of-specific-adaptive-immunity)

- The other immunoglobulin class that Kari will talk about is [IgM](https://en.wikipedia.org/wiki/Immunoglobulin_M) (the “Marines” of the immunoglobulins)
  - IgM goes out on the first call
  - They’re there to fight infections
  - IgG comes in after IgM and they stay for much longer
    - IgM doesn’t stay for very long
- The final class is IgE
  - In the past, IgE was very helpful for fighting parasites
  - Now, unfortunately IgE still exists in our blood ‒ it represents 0.005% of all the immunoglobulins in our blood
    - IgE has the lowest concentration of all immunoglobulins in the blood

> “*It [IgE] is unfortunately the most potent and I call it the match that lights the fire behind allergies*”‒ Kari Nadeau

- You may think: why do we have such a skewed response?
  - Why do we still have this prehistoric molecule floating around in our blood that truly all of us consider a bad actor?
- We think it’s because of that prehistoric need to fight parasites, but importantly now fast-forward thousands and millions of years, it’s still there and it unfortunately has a ***skewed response in allergies***

## How our immune system fights a virus, bacteria, or fungi, and some exceptions to the rule [13:00]

*Explain* [*cellular*](https://en.wikipedia.org/wiki/Cell-mediated_immunity) *versus* [*humoral immunity*](https://en.wikipedia.org/wiki/Humoral_immunity)

- Kari will explain how our immune system fights a virus or bacteria or fungi, but there’s always some exceptions to the rule
- She’ll explain the general pathway to help people conceptualize what happens
- She’s always amazed with the immune system, and there’s a lot we still don’t know
- What we do know is that when something attacks us like a virus (or bacteria or fungi), that enters into our lungs (or gut or nose)
- On the other side waiting for them is a whole panoply of immune cells ready to attack
- If a virus gets in through the body
  - Typically it doesn’t, we try to fight it right away
  - But sometimes it does

Let’s say a virus gets through our skin barrier…

- Right away we have these cells called [macrophages](https://en.wikipedia.org/wiki/Macrophage) and they literally just [eat up things](https://en.wikipedia.org/wiki/Phagocytosis)
  - So they bind on to the virus (or the bacteria or the fungi), and then eat it up into small little bits
  - Then they expose those small little bits on their surface, and those small little bits on the surface, they actually then become the [educator pieces](https://en.wikipedia.org/wiki/Antigen_presentation) for another group of cells called the [T cell](https://en.wikipedia.org/wiki/T_cell)
- T cells are what we call the [cellular system](https://en.wikipedia.org/wiki/Cell-mediated_immunity)
- Macrophages are what we call [antigen-presenting cells](https://en.wikipedia.org/wiki/Antigen-presenting_cell)
- These little bits [of virus (or bacteria/ fungi) that the macrophage chewed up] are called [antigens](https://en.wikipedia.org/wiki/Antigen)
- The T cell comes along and says, “*Huh, that’s interesting. I’m going to teach myself how to operate within these little androgens. What are these things? How do I train the immune system to get rid of this thing?*”
  - The T cell will start to understand what this new organism is that just attacked the body and will fend against that
- The T cell becomes what we call a [memory cell](https://en.wikipedia.org/wiki/Memory_T_cell)
- A memory T cell then [teaches](https://en.wikipedia.org/wiki/B_cell#T_cell-dependent_activation) another cell called the [B cell](https://en.wikipedia.org/wiki/B_cell)
  - The T cell interacts with the B cell and trains it to make immunoglobulins for the exact little antigen [the T cell responded to], the antigen from the virus/ bacteria/ fungi
- Then B cell then starts to make immunoglobulins
- These immunoglobulins then bind to the antigen
- And now you have specificity in your cellular and your humoral immune system

***The*** [***humoral immune system***](https://en.wikipedia.org/wiki/Humoral_immunity) ***refers to these antibodies that float in the blood***

- These antibodies [aka immunoglobulins] are not attached to a cell, but they were made by a cell [a B cell]
- When these antibodies attach to the antigen, now a macrophage can recognize it
  - There is this whole system we call **antibody-dependent cell killing**
- Now that the antibody recognizes this virus as foreign, then these other cells (the macrophage) come back again and they [chew the whole virus up](https://en.wikipedia.org/wiki/Phagocytosis) and eliminate it from your body

That’s a long system—Kari just talked about things that take days to respond to, months to respond to

- And it took many years of science to figure that whole pathway out
- This is a lot of science and that science has allowed us to understand the immune system and provide vaccines to people
- Because of this system our bodies know how to make immunoglobulins
- Because of vaccines, we know how long they can last for
- These memory T cells, for example, can last up to 100 years
- The cellular humoral part of the immune system is very instructive to fight microbes
- Unfortunately it doesn’t fight all microbes
  - Some microbes need a little help with antibiotics, with antivirals
  - So this story isn’t perfect, and that’s why you need to see the doctor
    - You need to have other medicines for example to try to help your immune system fight infections
    - Because there’s holes in the immune system and we need to help it

## Why our immune system is generally better at fighting viruses than bacterial infections [18:45]

**Why do you think our immune system is, on balance, so much better at fighting viruses than bacteria, at least in terms of the clinically relevant ones?**

- Peter notes that very few people will take an antiviral drug in their life, outside of a handful of unusual circumstances
- Most people will go through life with their immune system doing a very good job of lopping off the head of two to three viruses a year that actually reached the threshold of clinical significance
- And yet most people don’t go more than two or three years without actually requiring an antibiotic to aid in the destruction of a bacteria
- This is an excellent question teleologically as well as from an evolutionary point of view as well as really understanding how did viruses start in the first place?
  - How did the bacteria start in the first place?
  - What do they need to grow?
  - From the perspective of the virus, why do they need us?
  - From the perspective of bacteria, why do they need us?
  - Same thing for fungi
- When you think about a virus, they kind of flip from one organism to the other
  - They sometimes can exist out in the wild, they don’t necessarily need us, but sometimes like HIV, it needs some of our cells to be able to live inside to be able to keep proliferating
- There are some viruses that are of course very severe and they can cause fatal disease
- Typically though, viruses aren’t as bad as bacteria

***We don’t typically need an antiviral because we can fight viruses***

- It’s a great question though because viruses can mutate in our body like we saw with COVID and then all of a sudden we can’t fight them as well
- But our body can much more easily to destroy a virus
  - Because we make things like mucus, we have fevers
  - We have these immune cells that are really programmed to attack quickly, and they can chew up the viral proteins much better
- Because a virus is really relatively simple compared to a bacteria
- So it doesn’t take a lot for the immune system to wipe that out because that virus is made out of simple things
  - It’s basically made of really simple Lego blocks
- But then you have the bacteria that’s made of an enormous amount of Lego blocks and it is much harder to destroy that
- Same thing with fungi, they are much more complex organisms, they’re made of many different materials
  - So that it’s harder for our immune system to kill every piece of the part and get rid of it
- There are certain viruses though that we still get infected with but that they don’t cause fatalities
  - They’ve learned to kind of use us and then move on because they want to just keep proliferating
  - But they don’t necessarily stick around for our immune system to kill it
  - They just keep being contagious
- Viruses are much easier at hopping from one person to the other, whereas bacteria, that’s not so easy because they’re heavier, it’s harder to take a bacteria and give it to another human
- With bacteria, we have this bimodal relationship:
  - Kari wants to make sure all the viewers know that there are some bacteria that are actually really good
  - We don’t know any viruses in particular that are actually good and beneficial for us
  - But our body lives with bacteria

***Perhaps our immune system has a little tougher time knowing if this is a good bacteria or a bad bacteria***

- We’ve learned to be tolerant to certain bacteria but not others
- Some of them escape our immune system if they are bad bacteria because they know that we have this tolerance to other bacteria that are in the same class
- But it depends on where that bacteria is
  - It’s totally fine if this bacteria is in your gut
  - But the minute it gets into your blood, if it’s the same bacteria, it’s actually really dangerous
  - That’s where our immune system has to figure out is this a bacteria in the gut?
    - I’m okay with that
  - Or is this bacteria in the blood?
    - I’m not okay with that
- And bacteria tend to divide so fast (just like viruses) and that makes it difficult
- When we talk about **vaccines**, luckily we have used science to enable the immune system to get boosted for both types of infections (bacterial and viral)
- It’s always hard to predict mutants, to predict different infections that one would have

**Peter’s analogy with cancer**

- What makes cancer so challenging for the immune system is that it’s basically self, and it’s very good at masking its non-self entities
- So even though it’s genetically distinct from a non-cancer cell, it’s very good at hiding its neoantigens
  - Sometimes they’re not even coding proteins
  - In other words, sometimes the mutation in the cancer cell doesn’t lead to the generation of an antigen and therefore it can go completely undetected, masquerading itself
- Kari adds that our [memory T cells](https://en.wikipedia.org/wiki/Memory_T_cell) are supposed to be there to protect us, to monitor, and to make sure that any cancer cells are killed right away
- Sometimes they’re faked out and that’s where [CAR T cell therapy](https://en.wikipedia.org/wiki/CAR_T_cell) and a lot of the T cell mediated therapies (immune-mediated therapies) can enable and better instruct our immune system
  - But that’s not perfect either
- In COVID, we found that people that slept better, ate a healthy diet, and exercised, their immune system was healthier in general
  - We learned a lot about what it takes to have a healthy immune system to better fight viruses and microbes
- Peter adds, “*It’s hard to understate the harm that hypercortisolemia and a ramped-up sympathetic system have on the immune system*.”

## Differentiating a food sensitivity from a food allergy, and a discussion about celiac disease [25:30]

**Differentiate between a food sensitivity and an allergy**

- This comes up all the time with Kari’s patients, and she’s inspired by how much knowledge they have
  - They come to the table with knowledge they received from the internet, podcasts, or just reading in general
  - They ask questions ‒ this is so important

***If you don’t know something, feel free to ask your doctor these questions. This is critical.***

- **Food sensitivity** means that you can bite a food and you’re typically going to react to a chemical in that food, perhaps a protein
  - But it’s mostly a small molecule, maybe a sugar, maybe a fat, maybe a spice
  - And with that, people can get headaches, people can get bloating
- A typical food sensitivity is [lactose intolerance](https://en.wikipedia.org/wiki/Lactose_intolerance)
  - When you drink milk, for example, one of the sugars in the milk is called lactose
  - And if you don’t have an enzyme in your gut and in your body called lactase, you can’t break down that sugar
  - So that’s why people take lactate milk, for example
  - There are some ethnicities that don’t have that enzyme, and they can’t drink cow’s milk because of that lactose sugar
- With a food sensitivity, people get bloating, people get headaches, but they’re not going to have a fatal reaction
- Peter clarifies, “*The immune system is not reacting at all in that state of a food sensitivity?*”
  - Kari explains that it can react, but it reacts with a different pathway than an allergic pathway
  - If you have enough lactose and you keep drinking lactose, your body can send some immune cells to try to break it down, and that causes inflammation
- For some people, certain preservatives, emulsifiers, their immune system doesn’t like these chemicals
  - They’re seen as foreign, and for some people, the immune system reacts
  - But it reacts with a different pathway than an allergic pathway

***A food sensitivity can cause bloating or headaches or even rashes… importantly, we don’t have cures or therapy for food sensitivities***

- If that’s happening to you, it is important to get tested because we want to make sure it’s *not* a  food allergy
- For food sensitivity, we often tell people to avoid that food
- Kari knows someone who has terrible bloating with mushrooms because a certain chemical in them mushroom bothers her immune system
  - The minute she even smells the mushroom, she gets an immediate reaction in her gut that causes her to vomit
  - We don’t know why
  - But it’s *not* a food allergy
  - It’s an intense reaction of the nervous system to that food chemical
- Sometimes Peter sees people who have a low-grade elevation of their [C-reactive protein (CRP)](https://en.wikipedia.org/wiki/C-reactive_protein) (somewhere between 2-3, about 2-3x higher than it should be), and it lingers in this state for a very long period of time
  - There’s clearly no infection
  - In talking to them you realize it might be attributed to food
- In Peter’s experience, **the two foods that far and away account for the majority of this** (as determined by simple elimination and watching this go away) are (1) wheat-related products and (2) dairy
  - By wheat, he doesn’t mean celiac disease (which he’d like Kari to explain as a contrast but rather some sort of low grade sensitivity)
- Peter asks for clarification about food sensitivities, “*There’s nothing going on in the IgE pathway, but there is something going on in the IgG pathway.”*
  - Again, C-reactive protein is made by the liver as basically a calling sign to the immune system
  - For lack of a better word, you’re seeing the sirens going constantly, which is CRP
- Kari agrees, CRP is a really good beacon to tell us that something is going on chronically in the immune system
- When she tests CRP in patients with food sensitivities, and they’re not able to eliminate that specific chemical, then she sees CRP in that range where she calls it “*simmering immune inflammation*”
  - It’s not a fire, but it’s simmering

> *“The problem with food sensitivities is I don’t have a great way to diagnose them. I don’t have a skin test. I don’t have an IgE test, I have to do elimination and then I follow that CRP level until it can try to get to zero.”*‒ Kari Nadeau

- That’s not easy because some of these chemicals are so systematically in our food supply that it’s hard to get rid of
- She also agrees that milk and wheat are some of the most associated culprits in food sensitivities in the US
- That might be due to a lot of different reasons in terms of how we process
  - How we have detergents in our milk
  - The same thing with our wheat products
  - It isn’t necessarily the same wheat that we ate when our ancestors ate it originally

**More about wheat and this triangulation of food sensitivities/ celiac versus food allergy**

- [Celiac](https://en.wikipedia.org/wiki/Coeliac_disease) is a very specific type of food sensitivity, and it has a very marched out pathway of immune reaction to wheat
  - To wheat protein, specifically [gliadin](https://en.wikipedia.org/wiki/Gliadin)
  - That reaction is to a very specific part of the protein of the wheat
  - But not everyone with a food sensitivity to wheat has celiac
  - And not everyone with celiac will have the same reaction to wheat as the food sensitivity people do
- We take celiac extremely seriously because it can result in long-term problems with your gut
  - It has its own special category

***You shouldn’t call yourself celiac just because you have a food sensitivity to wheat; there’s a specific diagnosis that needs to occur with a professional that specializes in gastroenterology or in celiac***

- If you have celiac, then it’s important to test family members and to really get under the care of a good doctor

**Are we seeing any increase in the prevalence of celiac disease or food sensitivities?**

- On one side, people are becoming more knowledgeable about this, and they also feel they have agency (as they should) when they come to the doctor to be able to say, “*I think I have a sensitivity of this food*”
  - And people take them seriously and that’s good because these symptoms are serious, they’re affecting someone’s quality of life, and we need to help
- In the past maybe they were poo-pooed and [doctor’s] said, “*Oh, I can’t help you, so I can’t do anything about that*.”
- But now, doctors can say, “*Let’s test that CRP. Let’s see if we can be better detectives and really try to help you*,” because in the end, we want to help quality of life
- People are feeling more and more like they can talk about it as well as celiac disease, but importantly, we have better **diagnostics**
  - As a community, we have gotten better at diagnosing celiac, and that’s another good reason why there might be more people with it
- People also are seeing an increase in food sensitivities and celiac because of the different ways that wheat is **processed**
  - Because of the different detergents now and unfortunate chemicals that are put into our foods
  - Hopefully the food industry and agriculture will think carefully about those chemicals before they put them in

***When Kari tells people not to eat foods with those chemicals in them, they tend to not have food sensitivities***

## How food allergies develop, why they can be lethal, and factors contributing to the uptrend in food allergies [35:45]

**Do you have a sense of how many people in the United States die in a year as a result of a food allergy like the tragic story you told?**

- Thankfully, that’s extremely rare
- Kari hedges this a bit because sometimes it’s a little blurry if someone died from a food allergy, with the codes in the emergency rooms/ intensive care units
- Epidemiologists say it’s very rare (Kari is not an epidemiologist)
- People have claimed one of the reasons why people can have a fatal attack is because they don’t have access to an [Epi device](https://en.wikipedia.org/wiki/Epinephrine_autoinjector) or they don’t have anticipatory guidance for what to do during a reaction

> “*Any fatal reaction could have be avoided*”‒ Kari Nadeau

***Kari hears about approximately 1 fatal reaction per month in the US***

- Every one of those stories comes with a tragedy that’s heart-wrenching
- It compels Kari to keep training her patients
  - To make sure they have two injectable epinephrine devices at all times
  - To make sure they know how to use it within a minute
  - To make sure that if it doesn’t help their symptoms within a minute that they use another right away
  - To know it’s okay to use an injectable epinephrine device because that’s the only thing that can actually prevent the unfortunate death
- The numbers right of death rates are getting lower, which is good, because people are understanding more about this disease and communities understand why we don’t want to expose people unnecessarily to foods that could kill them
- There are increasing incidents and prevalence of food allergies in general in the U.S

[***Ruchi Gupta***](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=17229) ***out of Chicago,*** [***published data***](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6317772/) ***that 1 in every 12 children in the classroom in the U.S. has a doctor’s diagnosis of food allergy***

- [figures from this study are shown below]

![](https://peterattiamd.com/wp-content/uploads/2023/10/f2-karinadeau-1024x546.png)

**Figure 2. Percent of children in the US with food allergies (FA)**. Image credit: [*Pediatrics* 2018](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6317772/)

![](https://peterattiamd.com/wp-content/uploads/2023/10/f3-karinadeau-1024x613.png)

**Figure 3. Symptoms of an allergic reaction with stringent symptoms indicative of a convincing food allergy highlighted**. Image credit: [*Pediatrics* 2018](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6317772/)

- When Kari was training, it was thought that children would lose their food allergy
  - Especially those with milk and egg
  - If they were under the age of five, there was an 80% chance that they would lose these allergies by the time they were teenagers
  - But if it was peanut or any kind of tree nut or shrimp or fish, they had an 80% chance of keeping it
- Now unfortunately, if you have a milk or an egg allergy and you’re under the age of five, you have a 50% chance of losing it
- So now we see more and more adults having food allergies
- The other unfortunate thing is that more adults when they get to adulthood are getting food allergies

***Presumably about 1 in 30 adults will have some type of food allergy when they’re an adult***

- Whether or not that’s because they had it when they were children or because they gain it newly when they’re an adult

***The numbers of food allergies are rising, but luckily the death numbers are not*** (someone needs to do more research on that)

- This compels Kari as a food allergist to really make sure that both children and adults understand this disease and how to manage it
- The rising incidence and prevalence of food allergies is occurring throughout the world
  - It’s not just a problem in the US

**How a food allergy occurs**

- Peanut allergies are a problem in the US, the UK, and Australia
  - But not in Italy ‒ where allergies to hazelnuts are #1
- In Japan, it’s allergies to fish
- In China, it’s allergies to milk

***A peanut allergy is an example of how our immune system reacts to something, and a very similar immune reaction occurs in other types of food allergies***

- Kari has seen a spectrum of allergies
  - Allergies to cinnamon
  - Allergies to orange pit seeds

***All of these have proteins in them so people can actually become allergic to these proteins***

- People can have allergies to the tannin proteins from grapes in wine

> “*I’ll tell about the story of the peanut, but I want people to know that it’s not just about peanuts, and many people that have allergies to one food have allergies to other foods.*”‒ Kari Nadeau

***If you have a child with a food allergy, it is highly likely they will develop another food allergy as well***

- It is important to be super careful and vigilant about taking your child (or yourself) to the doctor to manage food allergies and get diagnosed
- When a person starts to have a food allergy, about ***70-80% of the time it’s NOT genetic but environmentally related***

*How a food allergy begins*

- When a baby is born, perhaps their skin is a little rough and a little dry and there might be microscopic holes in that skin
  - That happens a lot now a lot of children have **dry skin**
  - With that little dry skin, the epithelial cells that are typically connected and form a nice beautiful barrier, they separate, and our body doesn’t know how to deal with this separation too well
    - It thinks it’s a mosquito bite, and it’s like, “*Wait, what the heck is happening? I have a little hole in there.*”
    - It reacts to these types of holes as if it was a mosquito bite
  - And all of a sudden in the air you have dust that might contain hazelnut protein or in this case, peanut protein, and that comes settling in and it goes through this hole [in the skin]
- Our body has a very prehistoric way of dealing with this, which gets back to parasites
- Allergens come in by passive aeration, it drops down on the skin
- The body tries to pick it up, and the immune system tries to sense, “*What the heck is this? Is this good or bad?*”
- Then it says, “*Wait, this is bad. I’m not supposed to have food through my skin. I’m supposed to have food through my gut*.”
- So the cell [the [macrophage](https://en.wikipedia.org/wiki/Macrophage)] takes it up and activates the allergic pathway because it thinks it’s a parasite, it thinks it’s a mosquito bite
- [The macrophage] takes up the food, processes it, teaches a [T cell](https://en.wikipedia.org/wiki/T_cell#Activation) to interact with that food antigen and then a [B cell](https://en.wikipedia.org/wiki/B_cell#T_cell-dependent_activation) starts to make IgE against that very same food antigen
- Now, the next time that baby eats a peanut, even if it eats it through the gut, that little IgE molecule will have been made by the B cell and it’s sitting around in the blood
  - IgE will bind to the peanut protein that the baby eats
  - Remember, the IgE is a very small percentage of the concentration of proteins in the blood, but it is a potent molecule
    - It’s what Kari calls, “*The match that lights the fire behind allergies*”
- In a person with an allergic reaction to peanut, that IgE binds to the peanut [circled in the figure below] and then this part of the IgE molecule [the Fc portion, at the bottom of the molecule] is recognized by a receptor on another cell

![](https://peterattiamd.com/wp-content/uploads/2023/10/f4-karinadeau.png)

**Figure 4. Structure of an antibody with the antigen-binding site circled and the Fc region at the bottom**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Antibody#Structure)

- The IgE bound to the peanut allergen now docks via the antibody’s Fc region into a receptor on a cell and activates [histamine](https://en.wikipedia.org/wiki/Histamine) release by that cell [shown in the figure below]
  - That occurs within minutes

![](https://peterattiamd.com/wp-content/uploads/2023/10/f5-karinadeau.png)

**Figure 5. IgE-mediated allergic response**. Image credit: [*The Biologist*](https://www.rsb.org.uk/biologist-features/focus-on-allergies)

- Within 6 minutes, histamine goes through the body and causes swelling and mucus release (in your lungs, eyes, or nose), itching on your skin
  - The itching is very similar to what would happen if you got a mosquito bite
  - In the same way that your body wants to get rid of that mosquito, it wants to get rid of that food
- The body’s trying to do something that it was meant to do prehistorically, but it doesn’t help the person at all
- Histamine levels become so high that it can sometimes cause death
  - Within minutes if you already have asthma or lung issues
    - That mucus can become so strong that it clogs up your lungs
- What often can lead to those rare fatal reactions is there’s another chemical released by these cells when the IgE docks into the receptor, called [bradykinin](https://en.wikipedia.org/wiki/Bradykinin)
- Bradykinin can affect our **blood pressure** system
  - That can lead to dizziness and heart issues
  - That’s the second reason why people have fatal reactions
- You can imagine when you take epinephrine through an injectable epinephrine device, that helps both the lung to clear the mucus, and it helps the heart and the blood pressure stay strong so that you don’t have one of these near-fatal or fatal reactions
  - But it all is linked to the immune system and how it reacts, and it’s a very fast reaction

**Is my memory correct that the cell that’s releasing the histamine a** [**mast cell**](https://en.wikipedia.org/wiki/Mast_cell)**?**

- You’re seeing both sides of the story for the immune system
- The **humoral response**, which is IgE
- And the **cellular response** ‒  mast cells, eosinophils, and basophils all have a receptor on them to bind an IgE (shown in the previous figure)
  - There’s another type of disorder called eosinophilic disorders, which is a different type of food allergy but also related
  - Mast cells exist in tissues, but they’re not in the blood
  - Eosinophils and basophils are in the blood
- This is a potent system because it’s got these cells ready to go in the tissues,
- Mast cells are in the skin, they’re in the gut, they’re in the lung, in the eyes, in the nose
  - Mast cells can live a very long time in tissues, and that’s why someone’s reactions can build up over time, because every time they eat that food (or have that allergen exposure), their mast cells are going to remember because of the immunoglobulins that bind to them
- These other cells are floating around the blood and are also secreting histamine and bradykinin
  - They’re like the messengers across the whole system

***The implication is that each successive exposure gets worse***

**How often is a person’s first brush with a food allergy a fatal one?**

- We’re only as good as our data, as our epidemiological studies
- There are always exceptions, but typically, if you learn about your allergies before the age of two, those food allergic reactions are typically vomiting and hives
  - They’re not typically related to lung and heart
- Typically babies and toddlers do not have fatal reactions to their first ingestion of food
  - Although there are rare exceptions

***If you dissect out who dies from a food allergy, it’s typically people that already have a heart problem, already have a lung problem or didn’t get to the EpiPen fast enough***

- It would seem logical that with every dose that you take, your reaction could get worse and worse with the same dose, but it depends on:
  - If your at elevation
  - If you already have a cold
  - If you have [aero-allergies](https://en.wikipedia.org/wiki/Aeroallergen) and you’re allergic to a dog and a dog came by you that week and you also ate a peanut
- But yes, in general, if all things being equal each time you ate it, your immune system would remember more and more and will boost up that response

**Luckily with therapy, there’s a way to retrain your immune system, but that takes regular interaction with the food every day, not every week**

- If you take it **every week**, it actually boosts your immune system to become more allergic
- If you ou take it **every day**, there’s something to the circadian rhythm and the diurnal cycle, (which we haven’t talked about yet)
  - You can train it away from becoming allergic and train it into becoming more protective

> “*What I love about the immune system is it can be trained, and you just need to know how to train it*.”‒ Kari Nadeau

## The role of environmental factors in the onset of food allergies and strategies for prevention [50:15]

**What are other environmental factors that predispose children and adults to food allergies?**

- Earlier Kari mentioned dry skin
- The *lack of certain factors* also predisposes people
- People have talked about having a good [microbiome](https://en.wikipedia.org/wiki/Microbiome) and how “good dirt” helps decrease the likelihood of food allergies
  - For example, children who grow up on farms and have good exposure to animals tend to not have as many food allergies
  - This is called the “dirt hypothesis”
  - Also growing up with animals like dogs helps reduce the likelihood of food allergy, and that’s probably due to the microbiome
- Vitamin D also seems to play a role ‒ having enough vitamin D decreases the risk of food allergies
- Being around too much detergent is a risk, this is what Kari calls the “dry skin hypothesis”
  - Detergents for washing clothes and our dishwashers are really potent, and it’s not getting rinsed away enough
  - A babies skin (though it heals so well) is somewhat more sensitive than adult skin
- Babies tend to have dry skin do to other issues let alone detergents
- Anytime in life, pollution or tobacco smoke causes dry skin and itchiness
- Any part of the body that touches the air can be affected: our lungs, our gut

***One hypothesis is that allergies begin through the skin***

***We also think that it’s really important to diversify your overall diet really early and often***

- Feed certain proteins to your children when they’re young, and that diversity in diet can prevent the advent of food allergies later on in life

**The 5 D’s to preventing food allergies**: dirt, dogs, detergents, vitamin D, and diversity in diet

- Dry skin does seem to be a conduit by which food allergies start
- People will say that their parents gave them this food allergy or it’s in their genes

***There are certain allergies that can be passed on from one generation to the next, but even with those diseases, if you change your behavior, that can decrease the likelihood of having food allergies***

**Kari’s advice**

- Improve your skin barrier
- Try to stay away from emollients that are petroleum-based or paraffin-based products (like Vaseline)
- Science has shown us these are not natural to the skin
- Our skin doesn’t really like wax or petroleum products

***Vaseline is a petroleum product that tends to increase the bacteria on our skin, and that can make skin inflammation worse***

- Try to choose products that have natural lipids that give the skin back what they’re missing

**How does one look for that on the label?**

- [Ceramide](https://en.wikipedia.org/wiki/Ceramide) is a natural lipid, and you want to look for those emollients that actually replete the skin with natural lipids
- [CeraVe](https://www.cerave.com/) is a brand that has ceramide in their products
- Kari doesn’t work for any of these companies
- Choose ecologically-friendly detergents because those tend to be better for our own bodies
- Also try to rinse things

**Is there any relationship with breastfeeding?**

*Do we see any difference in the incidence of food allergies in a child who’s breastfed or not breastfed?*

- Many of Kari’s colleagues in Europe have tested this
- Now breastfeeding is so much that standard that it’s hard to do these studies
- The World Health Organization has recommended breastfeeding
- It’s really important to start feeding infants other types of foods between 4-6 months of age
- In general, breastfed infants do do better in terms of their overall gut health, in terms of their overall health in general

***But it has not been shown definitively that by breastfeeding you can prevent food allergies***

- Breastfeeding is very helpful towards creating an overall healthy immune system
- Kari tells all her families, “*If you can breastfeed, please do*.”
- But the ulterior, unfortunately, is that some children can have an allergy to a protein in the mom’s breast milk (it’s very, very rare)
  - So if your child does start to have issues with your breastfeeding, go see a doctor and make sure that they don’t have an allergy to your own milk

**What is the case for and against early exposure to nuts as a vehicle to prevent the onset of one of these allergies?**

- This has been confusing, and there’s been a lot of flip-flopping
- Unfortunately, well-meaning people made guidelines 20 years ago that weren’t based on a lot of data
  - They saw the increase in food allergies throughout the world and reacted, “*Oh, we don’t have enough science, but we’re really worried. So let’s just tell people to avoid those foods. And hopefully that can prevent this epidemic from increasing.*”
  - And the minute those guidelines came forward, you started seeing a hockey stick in the epidemic (food allergies started to increase)
  - While in those countries that did not follow these guidelines, it stayed flat
- Peter reacts, “*That’s a very telling case, even though it’s not a randomized intervention, that says when you avoid foods at a young age, you paradoxically predispose to the allergy.*”

**The importance of guidelines**

- We’re only as good as our data
- Fast-forward 20 years and now the world has different data
  - We now think that allergies begin through the skin, and through the diet allergies can stay quiet
  - We now know that the gut is really important for tolerizing to those antigens.

> “*The immune system in the gut is meant to tolerize. The immune system in the skin, in our lungs and in our skin is actually meant to be activated and react*.”‒ Kari Nadeau

- When you think about that dry skin hypothesis, of course it’s going to promote allergic pathways
- But when you think about taking things through the gut, it’s going to promote tolerogenic pathways
- The same people who wrote the guidelines 20 years ago, came together again to say, “*We need to diversify the diet. We need to tell our country’s population to start having children eat foods in small amounts like tree nuts, like fish, like milk, like egg, like peanut, and to be able to have that early and often and regularly so that we can try to prevent food allergies.*”
  - That’s the general mantra
  - The guidelines have now switched
- The same thing for people who are pregnant
  - It used to be thought based on a very small study of only 20 individuals, that women who are pregnant should avoid peanuts and tree nuts
  - 20 years later after a much bigger study was done, it showed it’s definitely okay to have peanuts and tree nuts when you’re pregnant
    - It’s healthier with [omega-3’s](https://en.wikipedia.org/wiki/Omega-3_fatty_acid)
- Of course, people who already have food allergies shouldn’t be eating these foods when you’re pregnant or if you’re a child

**Regular exposure to foods helps prevent the development of food allergies**

- But it does seem to be important, and it goes back to those instrumental recipes of the immune system
- If the immune system can probe the antigen, know that it’s safe, know that it’s not going to harm the immune system or the body, it then becomes tolerant
- But in order to give it that instruction sheet, you need to feed and you need to get exposed regularly

***“Regularly” means every day to every-other-day***

- You may say, “*My grandmother didn’t have to feed me these foods regularly. What all of a sudden changed?*”

**We think the environment around us is changing**

- The environment is changing with different detergents, different emulsifiers, different chemicals in our food, different pollutants, different viruses

**Do you think the genie ever gets back in the bottle? Do we ever get back to the levels we had 30 years ago?**

- When Peter was a kid, he did not know another child that had a food allergy
  - All the way through grade school, middle school, high school
- Today, his kids can’t take nuts to school
- You can’t have nuts on an airplane today
- Peter can’t tell how much of this is overreaction
- There’s clearly a log-fold change, but he can’t tell how much of this is also just a “disease of the brain”
- Lots of epidemiologists have asked this question and tested it, and it’s real
- There were people who rarely had a milk allergy or peanut allergy, and the allergist focused on aero-allergens
- Now their offices have shifted to food allergy

***This is a real diagnosed food allergy, and Kari doesn’t think we’re ever going to get back to 30 years prior because we had different practices, different ways of processing food, different environmental exposures***

> “*This is mostly environment, if I have identical twins born to the same mom and dad, I can have one twin develop a food allergy and the other one doesn’t (and typically, that’s in adulthood).*”‒ Kari Nadeau

- The one twin that develops a food allergy, they’re the one who’s been out in pollution more, they’ve eaten not such a healthy diet, they have a lot of preservatives
  - Or they smoke or they eat a lot of fast food
  - Or they are under a lot of stress and they don’t get a lot of sleep

***So genetics being equal, exposures in early life being equal, there are certain behaviors that we’re seeing that are more associated with food allergy (like air pollution)***

- Luckily, science has helped us so that we know what to do now and how to change our behavior so that we can try to prevent food allergies from worsening

## How immunotherapy helps to overcome, and even cure, food allergies [1:04:15]

- Peter met Kari about a decade ago through a mutual patient who at the time was being treated by her
- Peter was blown away at the fact that a person who once had an [anaphylactic reaction](https://en.wikipedia.org/wiki/Anaphylaxis) to nuts was going through an immunotherapy-based sensitization program with Kari at Stanford, and then all of a sudden didn’t have an anaphylactic reaction to nuts

**Give us a sense of what this revolution in immunotherapy-based sensitization is about?**

- Peter adds, “*It’s sort of hard to wrap our head around when you consider the lethality of these conditions”*
- Kari’s colleague, [Kim Yates](https://latitudefoodallergycare.com/about-us/team/corporate/kimberley-yates/) has don a lot of work in this area to educate
- Organizations like [FARE](https://www.foodallergy.org/) and others have really moved the needle forward
- When you think about food allergies, it’s something a child (or an adult) has to live with, and it’s not fun
  - It can affect their social lives or quality of life
- So they often come to the table wanting to know what is the best therapy now
- We now have a lot more therapeutic options
  - Any of these decisions are really personal
  - They’re something that the doctor, the healthcare provider, should talk to the patient about and see what’s the best for them

***Getting back to the immune system, regular eating of foods will retrain the immune system to be tolerant to those foods, to see them as natural (not unnatural)***

- This has been going on for about 100 years, even though it is new to many of us
  - Work Kari did at Stanford built upon evidence and other clinical trials
  - Kari worked closely with the FDA because you don’t want to do anything that’s not safe, anything you wouldn’t want to do with your own children

**What you do in immunotherapy at the very basic level is give the person back the very same thing that they’re allergic to**

- This was done 100 years ago with dog allergies, cat allergies, grass allergies, mold allergies
- People would start to inject these things
- A lot of patients may have had allergy shots when they were little
- These are ways immunologists learned to retrain the immune system
- You can train a body so that they are no longer allergic to cats, for example
- But you need to keep taking those allergy shots in general
- The same thing is true for food, but you don’t want to give a food allergy shot because the food in and of itself is very potent

***Food allergies are an IgE-mediated disease, and injecting allergic foods can be extremely dangerous, so we don’t give it via injections***

- Peter asks…
- “*Just to be clear, the allergy example, let’s say it’s cat dander or whatever, is the shot giving you a little bit of that dander? Is it sensitizing to you a little bit?*”
- A*nd how frequently does the patient need allergy shots to achieve a symptom-free existence*?

- Initially, you need to take it almost daily, daily to weekly
- Once your body starts to build up that immune muscle, you only need to take it about once a month
- Some people do it for life, and some people do it for 5 years

*For an aeroallergen (not a food allergen)*

- If you stop after 5 years, you have a 25% chance of regaining your allergy, a 25% chance of having the allergy to a lesser degree, and a 50% chance of having the allergy be resolved for the rest of your life
  - These are for environmental allergies, and 5 years depends on the [aeroallergen](https://en.wikipedia.org/wiki/Aeroallergen)
- The reason you can get away with that is because these allergens do not induce [anaphylaxis](https://en.wikipedia.org/wiki/Anaphylaxis) the way food does
- It’s the severity of the IgE mast cell reaction to food allergens that is different, and we’re still trying to understand why that is
  - E.g., *Why is grass allergy not as bad as peanut allergy*?

***Immunotherapy is giving small amounts of that specific allergen back to the patient, and this can be a shot for environmental allergies or orally for a food allergy***

*For a food allergy*

- You start with a small spec that you can hardly see and then you increase that dose by 25% every 2 weeks, but you’re giving it every day
- You increase it step-by-step: every 2 weeks you increase the dose, but you’re giving it daily
- And you want to do that in a doctor’s office, you want to be really careful about that
- Over time, this readjusts the immune system, but it takes a while

**What happens in the immune system**

- What happens in the immune system is the T cells start to be taught that this antigen seems to be okay
- When they get it every day they realize, “*I need to reframe my mindset.*”

***You start creating another whole layer of memory T cells that become tolerant to that antigen***

- The new memory T cells teach the B cell to forget making that IgE
  - Instead, they want the B cell to make more IgG because that’s protective
- This happens over time during the first year of immunotherapy
  - You’re slowly going up, slowly readjusting

**The patient’s immune muscle switches from an IgE-mediated bad reaction to an IgG reaction that is protective against the allergy**

- The IgE can still be there but you have this huge amount of IgG that is protective
  - The IgG acts like a blanket of immunoglobulins that covers the allergen so that none of the allergen binds to the IgE
  - [Illustrated in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2023/10/f6-karinadeau-1024x686.jpeg)

**Figure 6. Tolerance to food antigens is mediated through IgG immunoglobulins**. Image Credit: [*Frontiers in Allergy* 2021](https://www.frontiersin.org/articles/10.3389/falgy.2021.810067/full)

**In the case of the person with the anaphylactic reaction to peanuts, do they ever go above the 0.005% IgE concentration [in the blood]?**

- In order to have that reaction, IgE is specific to a specific food
- People with peanut allergies (or other allergies) will have a higher concentration of IgE
- A virus can also increase IgE non-specifically (probably against the virus)
- It’s a very prehistoric type of reaction
- But importantly, for every IgE molecule, we can make 100 IgG molecules that protect against that IgE molecule circulating and becoming potent, and that’s what is happening during immunotherapy [shown in the previous figure]
  - You’re making huge amounts of IgG molecules to bind against that IgE becoming pathological
  - It’s a ratio thing

**Give me a sense of scale. So on the very first cycle, that first two-week cycle, what fraction of a peanut is being given in the capsule? How small is it?**

- It’s about 1/200th of a peanut
- You start very low and you go very slow, because in the end you want to retrain that immune system, but you don’t want to activate it too much
- Now, during that retraining, sometimes your “muscles” get sore
  - Sometimes you will see some hives, sometimes you will get a little itchy throat
  - Your body will have these little reactions, Kari calls them simmering reactions
- But you do need to take it every day
- And then you start to see this switch from IgE to IgG
  - The T cells are responsible for that; many other cells are too
- But in general, if you stop the therapy, this beautiful pathway of tolerance then starts to go back to the original pathway
- So it’s really protection and it’s very rare that a person completely flips and becomes non-allergic

***What you’re doing in the immunotherapy is changing your threshold and creating more protection molecules around you and creating more protective cells around you***

**When does that switch flip?**

- In a typical immunotherapy regimen, it flips around 9 months to 1 year
- Peter thinks about the doses they’re talking about, “*Someone comes in with an allergic reaction to peanuts, for two weeks they’re going to take a capsule that contains one 200th of a peanut. That goes according to plan, they will increase that by 25% for another couple of weeks. A month into this thing, they’re still basically taking one 200th of a peanut, but you will continue to do that. They will not hit the threshold of a full peanut by the end of the year. They’re really, really microdosing this in the true sense of the word.*”
- Kari clarifies: after a couple of weeks, you’ll be up to 40-60 mg
  - There are certain steps of this where you don’t have to increase by 25%, where you can go higher/ steeper
  - So by the end of the year, the dose is about 1-2 peanuts
- Also remember that a lot of people have **more than one allergy**, and they had to work this out scientifically to go low and slow, but within reasons so that they could get the immune system to flip within a year
  - That way if the patient didn’t want to continue with therapy, they would be safe for an accidental ingestion of that food

**How do you evaluate the therapy?**

*Are you looking at the IgE, IgG level? Are you simply doing this based on the absence of symptoms in the presence of the administration?*

- Blood biomarkers
  - Thanks to a lot of pioneers and patients in those trials
  - They were taking blood every 2-3 months and looking to see when the humoral immune system started to switch [from making IgE to IgG antibodies]
- They used those biomarkers to readjust and recreate the regimen so that you could go low and slow in the beginning
- By about 3 months, they knew the “muscles” were starting to change, so they could hike up the dose a little more
  - By six months, even more
  - By a year, the immune system had switched
- It took a lot of time and effort and blood draws from those original pioneer patients to give us the science by which we could perfect this regimen
  - It’s not perfect yet, but it’s much better than it was 10 years ago

**By the end of a year**

- Patients may not want to continue with frequent immunotherapy injections

*Is it safe to assume they may never be able to eat nuts, but if they accidentally ingest a nut here and there, that they’re going to be fine?*

- Yes

***They try to get patients up to 600 mg by the end of a year, and that’s what the FDA thinks is the threshold for accidental ingestion***

- Oftentimes, people say, “*I’m done. I really don’t want to have to do this every day. Can you please tell me if I could take my dose weekly or if I can take it every other day? And what dose is safe enough?*”
- For **maintenance**, they try to get them up to 2 peanuts a day
  - They don’t want to have to take a nut every day, but they kind of have to because we don’t know what will happen if you stop
- With long-term follow-up, we are learning who can stop therapy and who might not be able to stop therapy

***In general, it’s much better to take 1-2 nuts every day after you finish your therapy with a doctor***

**Do they ever transition to the point where they can do this as outpatients on their own or do they always have to do this in a doctor’s office?**

- After 6 months to 1 year, if people get up to 1-2 peanuts a day (or hazelnuts or glasses of milk), then they can do this at home and just let the doctor know how they are doing

**Are people undergoing this therapy outside of clinical trials yet?**

- Yes, and that’s been going on for a while
- We were very careful to say that if you do decide to do it in an outside clinic, try to get your health insurance to approve
- We want to democratize this
  - We don’t want it to be only available to certain populations because everyone gets food allergy and sees no boundaries in terms of ethnicities or socioeconomic status
- People of color have a much higher rate of anaphylaxis unfortunately because of access to healthcare
- There are clinics that are offering this
  - For example, [Latitude](https://latitudefoodallergycare.com/) in New York City and San Francisco now offer specific regimens that are based on science and evidence to be able to offer therapy
  - There are unique clinics out there that are specializing in food allergy care to be able to help patients based on scientific methods

**What fraction of patients who continue this protocol get to the point where they completely shed the allergy altogether and at some point will go on to eat as many peanuts as they want?**

- Kari always starts any conversation with a patient by saying this is possible
- Some patients just want to be able to eat 1-2 peanuts for the rest of their life and know they’re not going to have an accidental ingestion
  - They’re willing to do that
  - They believe that is the “cure”
- As a doctor, Kari pushes her standards a little higher: ***a cure should be eating ad-lib and not having to worry at all***
- In that category, if you take the dose for at least 2 years, you have a 20% chance of being in the cure category
  - ***20% chance of being “cured” after stopping treatment after 2 years***
  - ***60% chance of being “cured” after stopping treatment after 5 years***
- Time on dose matters; it’s all recalibrating/ reeducating the immune system
- Many people ask Kari, “*Are there some people that are refractory?*”
  - You’ll now that term because of people that are refractory to cancer therapy
  - ***But in allergy, there’s no refractoriness per se***
- If sometimes people have too much abdominal pain or they have too many hives or their asthma gets worse every time they have the dose that’s where she’ll say, “*Hey it might not be worth it. There’s too many side effects here, this bothers you too much*.”
  - We try to decrease the dose so that we personalize it for them
  - But some people just say, “*This is too much now I really don’t want to go through it*.”
- But in general, if you stay with it, you’ll get the benefit from it

**What percentage, if any, of people going through the clinical trials required epinephrine during the administration of the immunotherapy?**

- Nowadays it’s very rare, about 1 in 100,000

**Is there any allergen that is not amenable to this type of therapy?**

- This goes back to the elemental nature of the immune system, and this work with **any protein**
- It’s very rare that the allergen is not a protein
  - One example is the sugar [alpha-gal](https://en.wikipedia.org/wiki/Galactose-alpha-1,3-galactose)
    - This is rare, occurring in the southeastern part of the US, associated with a tick bite [[alpha-gal allergy](https://en.wikipedia.org/wiki/Alpha-gal_syndrome#)]
    - Kari doesn’t think this regimen will work with alpha-gal allergies because that’s a sugar

***Right now, there’s nothing they have not been able to desensitize a patient to with food allergies***

## Can immunotherapy work for environmental allergens like pollen? [1:24:00]

**Environmental allergens**

- In Austin there is a thing called “cedar fever”
- The cedar trees give off a ton of pollen sometime between November to January
- People affected can’t function without [Benadryl](https://en.wikipedia.org/wiki/Benadryl) and [Zyrtec](https://en.wikipedia.org/wiki/Cetirizine)
- Peter has asked around on behalf of friends to see if there are immunologists and allergists that have an immunotherapy regimen, and he can’t find any

**Would “cedar fever” be an easy thing to address?**

- Cedar allergies are interesting, because the cedar protein itself is something called a protease
  - You can start to grade proteins; it’s a little weird
  - But cedar allergies are very serious
- Yes, there are people that have developed immunotherapy for cedar
  - It’s the same rubric to desensitize to it, although it takes a lot of care [and maybe that’s why providers are hard to find]
- Cedar allergies are something just like other tree allergies, they can give you lots of mucus and asthma

**Kari breaks immunotherapy down to proactive therapy and reactive therapy**

- Reactive therapies are all those antihistamines people need to take
- Proactive therapy is the immunotherapy to readjust your immune system

***But you need both***

## Air pollution: impact on health and tips for reducing your risk [1:25:30]

**Air pollution: tell folks what a PM2.5 is and why somebody should care**

- 10 years ago, Kari didn’t understand all of the PM2.5 jargon either

> “*This is something that we all need to learn now, every single one of us, even if we’re in a research station in Antarctica, because air pollution unfortunately is rising*”‒ Kari Nadeau

- There are no boundaries, when wildfire smoke happens in Australia, it can circumnavigate the world within 4 days

[***PM2.5***](https://en.wikipedia.org/wiki/Particulates#Size,_shape,_and_solubility_matter) ***is a way that we measure to air pollution, but it’s not everything in air pollution, it’s the particles in air pollution that are 2.5 microns in size***

- Now you think, well what in heaven’s name is that? 2.5 microns?
  - Think of a little red blood cell, that’s 1 micron (1 𝜇m)
  - So, you think about particles that are basically about twice the size of a red blood cell and those are floating around in the air
- They come from partially combusted fuel/ combusted fuel from our cars (if you don’t have an electric car)
  - Combusted fuel from industry when it breaks up petroleum (when it breaks up any kind of product, wood fire as well), little particles escape into the air and those particles are *not* what you see as soot on your car
    - They’re *not* what you see as brown dust on your house
- These are particles that are so small, they continue to be aerated and they can float in the air around the whole world
  - And they’re so small that they can penetrate into our lungs

**Why do we care about that size, 2.5 microns?**

- Because it can get through our lungs and into our blood
- It’s dangerous also because PM2.5 as a defined measure of air pollution has about 200 different chemicals in it
- And of those 200, some of those are what we call [volatile organic compounds](https://en.wikipedia.org/wiki/Volatile_organic_compound)
  - These are compounds that you smell when you smell markers like xylene or in the old days, mothballs, naphthalene
  - These are chemicals that are not good for the body
  - They are from combusting fuel
  - If any one of your listeners is a chemist, these are what we typically call six-membered rings
    - They’re organic chemists’ nightmares because they smell horrible (Kari didn’t like them when she was doing organic chemistry when she was a student)
    - She doesn’t like them now because now she knows what they can do to your body
- **Volatile organic compounds can:** cause cancer, increase asthma, increase cardiovascular disease, stroke
- **Wildfire smoke** is even more potent as an air pollutant than PM2.5
- We also measure PM2.5 for wildfire smoke because wildfire smoke basically is biomass burning
  - Unfortunately wildfires aren’t burning just trees anymore; they’re also burning commercial buildings
- Comparing what goes up in wildfire smoke to let’s say just diesel from the car (which is bad enough)
  - With wildfires, you’re burning up your upholstery, paint thinners, detergents underneath your sink, shampoos ‒ that’s all going up in the air
    - And that’s also measured as PM2.5 because all those particles are so small they’re also going into your lungs
- With wildfire smoke we also have to be super careful
- You can look on websites such as [AirNow](https://www.airnow.gov/) or the [NOAA website](https://digital.mdl.nws.noaa.gov/airquality/?element=ozone01_bc&mapcenter=-96.00%2C40.00&mapzoom=5&subregion=CONUS&region=CONUS) and know what the air quality index in your region is for the day
  - If it’s in the green zone, great
  - If it’s in the yellow zone, please start wearing a mask
- A mask like the one you used to wear in COVID are very important to reduce the risk of those exposures to your lungs
  - Especially for children and elderly patients
- PM2.5 is measurable, it’s biologically and medically important
- In California they use something called [PurpleAir monitors](https://www2.purpleair.com/products/list?campaignid=19775547351&adgroupid=148141901713&network=g&device=c&gclid=Cj0KCQjw7JOpBhCfARIsAL3bobdIVQEblxzDLlJaE3KfzgFOeCsWTuuuPm6LIL4ZigLQM9712h-9AogaAtKyEALw_wcB) and you can look on the [web](https://map.purpleair.com/) and it will tell you what the PM2.5 measures in the air
  - We are lucky in the US that our agencies measure PM2.5 on a regular basis so we can map that to our zip codes

**Is it necessary to buy a PM2.5 monitor for your home or is looking at one of these databases enough?**

- Peter points out that there are a lot of PM2.5 monitors you can buy for your home and asks:
  - Do you need to make sure that you don’t have particulate matter in your home due to a leaking stove (that would probably turn up as carbon monoxide)
  - Do you  need to know what the level is outdoors because that might be the day you choose *not* to do your 10-mile run if it’s a red day?
- Kari replies that all of these things are important
- If you know you have to be outdoors for work, for 8 hours no matter what, and the air quality index is 100, then you should wear a [N95 mask](https://en.wikipedia.org/wiki/N95_respirator)

**Will a N95 sufficiently prevent PM2.5 from getting in?**

- Not perfectly, but at least it reduces the risk
- No mask completely reduces those small organic molecules (those six membered rings from getting through the mask), but at least it’s better than nothing
- Kari tells her patients, “*Please don’t exercise during any air quality index that’s greater than let’s say 50.*”
  - Because even though they might not feel it during the hour that they exercise outside, it definitely affects their immune system
- There were studies done in London for example, where people would exercise out in the streets that had a certain air quality index
  - And in London you can actually do this because there’s micro PM2.5 measurements in Hyde Park versus in Broad Street

***They did this research and they knew that even if people exercise out for one hour in polluted air (versus clean air), their immune system changed for a whole day based on that one hour of exercise***

- Indoor air is also very important
  - More than 90% of our lives are spent indoors (for the typical US citizen)
- So having a [Purple Air monitor](https://www2.purpleair.com/products/list?campaignid=19775547351&adgroupid=148141901713&network=g&device=c&gclid=CjwKCAjw4P6oBhBsEiwAKYVkqzBG_50ZySahvIsAvjQDsB1NeiwS5DrIBYrwjpeH6ous_qluqi3qxxoCcfYQAvD_BwE) indoors is helpful, especially if you live in a place with lots of wildfire smoke or air pollution
  - Because you can’t assume that your air pollution is being filtered appropriately and you can’t assume that you’re being protected because oftentimes you can’t smell this and you can’t see it
  - It is so small that you need a special detection monitor to know if it’s there
- Now if you do have bad indoor air, you can buy a [MERV filter](https://www.epa.gov/indoor-air-quality-iaq/what-merv-rating) (13 or higher, don’t buy a MERV 7 or 8)
  - You can buy a filter in your air conditioning or central air or you buy a standup filter to reduce the exposure
- All these things are available to people, and in certain states they are available freely for families that can’t afford them

**Let’s say you buy the Purple air monitor or figure out that you liver in an area where there’s enough pollution outdoors that it can easily get indoors**

- Option #1 is to get a [HEPA](https://en.wikipedia.org/wiki/HEPA) filter for the house
- Option #2 is to get a MERV 13 (or higher) filter for your [HVAC](https://en.wikipedia.org/wiki/Heating,_ventilation,_and_air_conditioning)
  - Don’t buy a MERV 7 or 8
  - See the figure below

![](https://peterattiamd.com/wp-content/uploads/2023/10/f7-karinadeau.png)

**Figure 7. MERV scale of effectiveness of air filters**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Minimum_efficiency_reporting_value)

- MERV 13 reduces all of the major PM2.5 as well as pollens as well as other chemicals’
- But you need to change them often, because they’re getting clogged up
- Kari doesn’t work for PurpleAir, but you can buy any of these monitors that can monitor external outside air and indoor air
  - You can buy them and get to know the difference

**General advice**

- It’s good to ventilate your home
- You don’t want your home to be collecting its own toxins, and that can happen if you have a gas stove or a wood stove
- In general, knowing and measuring your PM2.5 is going to be helpful to your health because you can manage accordingly

**Do you have a sense of the magnitude of the effect of air pollution on our health?**

- Peter wanted to include a section in his book on air pollution, but didn’t for a couple of reasons
- The biggest reason was he couldn’t get a clear sense of the mortality impact
  - He couldn’t quantify it in the way you can for smoking or obesity
- Quantifying the exposure is difficult
  - It’s not like pack years of cigarettes where we can say 40 pack year history versus zero pack year history translates to this much difference in outcome
- Kari explains that the WHO just put a report out, the [AQLI just put a report out from University of Chicago](https://aqli.epic.uchicago.edu/wp-content/uploads/2023/08/AQLI_2023_Report-Global.pdf)
  - Kari adds, “P*eter, I feel like you are in this incredible position to make this impact with others. You are a trusted voice and because of that comes the privilege of being a trusted voice, but also that accountability and responsibility of knowing all the science. And so what I’ll do is send you this report because it has now been put into exactly those terms and it’s more dangerous than tobacco smoke, because it is so prolific.*”
  - ***In the first page of this report, it shares with you the context of how pollution has killed about 8-10 million people a year now***
    - And that’s attributed directly to air pollution

**What is the final common pathway? Where do we think the actual mortality comes from?**

*Is the majority through cardiovascular disease, cancer?*

- Exactly, especially in low to middle income countries, it’s cardiovascular disease and lung disease
- In more westernized countries, it’s more associated with stroke, long-term cardiovascular disease, and cancer
- Now, thanks to a lot of science, you can disaggregate what deaths are due to air pollution versus what deaths are due to tobacco smoke
- There’s a multiplicity of effect here, but now the epidemiologists really have the data, and you can sink your teeth into this data and know that it’s accurate

## What happened to Kari’s early patient who died despite using an epinephrine device? [1:37:15]

**When you go back to the child who died in the ICU, the child who was your patient zero (mentioned earlier), why did the EpiPen not work?**

- It had expired; they hadn’t renewed the EpiPen
- They hadn’t gone to the doctor for at least 5 years and they assumed that their child had grown-out of the milk allergy
  - Because that’s what people told them would happen
- They never got their [child’s] IgE retested
- They never went back to their allergist
- They still had the EpiPen that had been given to them 5 years prior and it had expired
- In addition, it was for a different weight child
  - It was for EPI JR, and he had grown
  - Even if the Epi was not expired, he should have gotten a different dose

***It interlaid all these aspects about the fact that you cannot know that what typically happens to a patient is what will happen to you. You need to actually go to a doctor and get your own set of data to figure out how to best manage your disease.***

- It also taught the lesson: you’ve got to keep updating your EpiPen and make sure it’s renewed and the correct dose

**Was there a big controversy a couple of years ago when a company that was selling EpiPens decided egregiously for no apparent reason other than just malicious greed to jack the prices up. Has that resolved and are EpiPens now relatively inexpensive again?**

- That’s right
- That company was Mylan and they were making EpiPens
- And that’s why Kari called it an “injectable epinephrine device” because now there’s a lot of them
- Thank goodness the FDA other agencies got involved and said this is not right

> “*No one should be charged that amount of money for a lifesaving drug*”‒ Kari Nadeau

- That’s when generic epinephrine devices started to be made
  - Other companies started to hit the road
  - There’s other devices now that can be used called the [AUVI-Q](https://en.wikipedia.org/wiki/Epinephrine_autoinjector#Design)
  - There is also potentially a [nasal epi](https://www.nbcnews.com/health/health-news/fda-nasal-spray-epinephrine-neffy-rcna105078) that can be used [FDA rejected it after the recording of this podcast]

**What were they charging for EpiPens?**

- $400-600 for some of Kari’s patients
- Luckily that is now being covered by insurance
- Third party payers also need to make sure that they can reimburse for these lifesaving medications

## Resources for those wanting to learn more or find clinical trials related to food allergies [1:40:45]

**What would you suggest for those people, someone listening or hearing this, who is being blown away by what you’re telling them? Where can they either find a clinical trial or find a nonclinical trial provider, who’s able to walk them down this pathway?**

- Do a search on [clinicaltrials.gov](https://clinicaltrials.gov/), look under the category of [food allergy](https://clinicaltrials.gov/search?cond=food%20allergy), and you can find out what clinical trial nearby you is actually ongoing for food allergy therapy
- There’s a lot more than there were just five years ago
- There’s like 17 companies in this space now, and Kari is really excited about the future

> “*There is a lot of hope and promise*”‒ Kari Nadeau

- There are more clinics around the country that are specializing in food allergy
- One example mentioned earlier is [Latitude](https://latitudefoodallergycare.com/), but there are others as well
- With that in mind, go to your healthcare provider, ask them questions
  - If you feel like they don’t have time or they haven’t really answered the questions in the way that you learned about today, go online and find out about those clinics that specialize in food allergy therapy
- Not everyone fits with everyone; so, give it a test
  - See if you like that structure and then you can try
- That possibility is there, that reality is there, and Kari hopes everyone tries to undergo therapy

§

## Selected Links / Related Material

**Kari’s book**: [The End of Food Allergy: The First Program To Prevent and Reverse a 21st Century Epidemic](https://www.amazon.com/End-Food-Allergy-Program-Epidemic/dp/0593189515/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1696938156&sr=8-1) by Kari Nadeau and Sloan Barnett (September 2020) | [1:45]

**Incidence of food allergies in children**: [The Public Health Impact of Parent-Reported Childhood Food Allergies in the United States](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6317772/) | *Pediatrics* (R Gupta et al 2018) | [38:00]

**FARE ‒ food allergy advocate and education organization**: [FARE: Food Allergy Research & Education](https://www.foodallergy.org/) (2023) | [1:05:15]

**Food allergy clinic**: [Take Control of Your Food Allergies](https://latitudefoodallergycare.com/) | Latitude: Food Allergy Care (2023) | [1:20:30]

**Websites to check air quality in your region**: [1:29:15]

- [AirNow](https://www.airnow.gov/)
- [NOAA website](https://digital.mdl.nws.noaa.gov/airquality/?element=ozone01_bc&mapcenter=-96.00%2C40.00&mapzoom=5&subregion=CONUS&region=CONUS)
- [PurpleAir](https://map.purpleair.com/)

**2023 AQLI report**: [AQLI: Air Quality Life Index Annual Update](https://aqli.epic.uchicago.edu/wp-content/uploads/2023/08/AQLI_2023_Report-Global.pdf) | University of Chicago (M Greenstone and C Hasenkopf 2023) | [1:35:30]

**Role of the skin in development of food allergy**: [Epicutaneous sensitization in the development of food allergy: what is the evidence and how can this be prevented?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7494573/) | *Allergy* (H Brough et al 2020)

**Characteristics and etiology of food allergy**: [Food Allergy from Infancy through Adulthood](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7899184/) | *The Journal of Allergy and Clinical Immunology* (S Sicherer et al 2020)

§

## People Mentioned

- [Christopher Walsh](https://hms.harvard.edu/news/christopher-t-walsh-dies) (was the Hamilton Kuhn Professor of Biological Chemistry and Molecular Pharmacology, Emeritus, at Harvard Medical School and Kari’s Ph.D. advisor) [5:30]
- [Richi Gupta](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=17229) (Director, Institute for Public Health and Medicine (IPHAM) – Center for Food Allergy & Asthma; Professor of Pediatrics (Advanced General Pediatrics and Primary Care), Medicine (Allergy and Immunology) and Preventive Medicine at Northwestern University) [38:00]
- [Kimberley (Kim) Yates](https://latitudefoodallergycare.com/about-us/team/corporate/kimberley-yates/) (Founder and CEO of Latitude Food Allergy Care) [1:05:15]

§

![](https://peterattiamd.com/wp-content/uploads/2023/10/bio-image-karinadeau.png)

##### Kari Nadeau, M.D., Ph.D.

Kari Nadeau earned her B.S. in Biology from Haverford College and her M.D./Ph.D. from Harvard Medical School. She completed a pediatric internship and residency at Boston Children’s Hospital and a residency and fellowship in allergy, asthma, and immunology at Stanford-UCSF. After this, she joined the faculty at Stanford Medical School. Currently, Dr. Nadeau is the Chair of the Department of Environmental Health at Harvard School of Public Health and John Rock Professor of Climate and Population Studies. She practices Allergy, Asthma, Immunology in children and adults.

For more than 30 years, Dr. Nadeau has devoted herself to understanding how environmental and genetic factors affect the risk of developing allergies and asthma, especially wildfire-induced air pollution. She has published over 400+ papers, many in the field of climate change and health. Her laboratory has been studying air pollution and wildfire effects on children and adults, including wildland firefighters. She oversees a team working on air pollution and wildfire research along with a multidisciplinary group of community leaders, firefighters, engineers, scientists, lawyers, and policy makers. Dr. Nadeau was appointed as a member of the U.S. Federal Wildfire Commission in 2022. She is also a member of the National Academy of Medicine and the U.S. EPA Children’s Health Protection Committee.

Dr. Nadeau co-founded Before Brands, IgGenix, alladapt immunotherapeutics, and COUR Pharmaceuticals. At Stanford, she started the Sustainability Health Seed Grant initiative as well as the [Climate Change and Health Equity Task Force](https://climatehealthequity.stanford.edu/) and Fellowship program. [[Harvard](https://www.hsph.harvard.edu/profile/kari-c-nadeau/)]