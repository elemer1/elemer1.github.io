# #316 – AMA #63: A guide for hair loss: causes, treatments, transplants, and sex-specific considerations

**Source:** [https://peterattiamd.com/ama63/](https://peterattiamd.com/ama63/)

---

In this “Ask Me Anything” (AMA) episode, Peter dives deep into the topic of hair loss, exploring its relationship with aging and its impact on quality of life. The conversation focuses on androgenic alopecia, the most common form of hair loss in both men and women, and covers the differences in patterns and causes between the sexes. Peter delves into the right timing for treatment, breaking down various options such as minoxidil and finasteride, low-level laser therapy, platelet-rich plasma injections, and more. Additionally, Peter outlines the pros and cons of the two primary hair transplantation methods and concludes with practical advice on selecting the right specialist or treatment team for those facing hair loss.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #63 show notes page](https://peterattiamd.com/ama63). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- The impact of hair loss on emotional health [2:15];
- The prevalence, patterns, and causes of hair loss in men and women [5:15];
- The genetic and hormonal causes of hair loss, and the role of dihydrotestosterone (DHT) in androgenic alopecia [8:45];
- The visual differences in hair loss patterns between men and women, and the importance of consulting a specialist to rule out non-genetic causes of hair loss [13:30];
- How genetic predisposition influences the risk of androgenic alopecia, and how early detection through diagnostic tools and blood tests can help manage the risk more effectively [16:45];
- Ideal timing for starting treatment: why early treatment is crucial for effectively managing hair loss [19:30];
- The various FDA-approved treatments for androgenic alopecia, their mechanisms, and additional off-label treatments commonly used to manage hair loss [24:30];
- Topical minoxidil—the most commonly recommended starting treatment for hair loss [30:15];
- Oral vs. topical minoxidil: efficacy, ease of use, and potential side effects that must be considered [33:45];
- Finasteride for treating hair loss: efficacy, potential side effects on libido, and the need for careful PSA monitoring in men to avoid missing early signs of prostate cancer [37:15];
- Other effective hair loss treatments for women: boosting hair density with spironolactone gel and ketoconazole shampoo as part of a comprehensive strategy [41:30];
- Low-level laser therapy: effectiveness, costs, practicality, and a comparison of in-office treatments with at-home devices [49:00];
- Platelet-rich plasma (PRP) as an off-label treatment for hair loss: potential effectiveness, varying protocols, and significant costs [53:45];
- Hair transplant for advanced hair loss: criteria and considerations [58:00];
- Types of hair transplants: follicular unit transplantation (FUT) vs. follicular unit extraction (FUE) [1:02:00];
- The financial cost of hair transplant surgery, and what to consider when seeking affordable options [1:06:15];
- The potential risks and downsides of the various hair transplant procedures [1:09:30];
- Post-procedure care for hair transplants and whether the procedure must be repeated periodically [1:16:30];
- Combining different hair loss treatments: benefits, risks, and considerations [1:18:30];
- Emerging hair loss treatments with limited data [1:21:00];
- Key considerations for selecting the right treatment plan for hair loss [1:22:00];
- A summary of the different considerations for men and women facing hair loss [1:24:30];
- Practical advice on selecting the right specialist or treatment team [1:26:15]; and
- More.

§

The Peter Attia Drive

A guide for hair loss: causes, treatments, transplants, and sex-specific considerations

§

## Show Notes

## The impact of hair loss on emotional health [2:15]

General Podcast Focus:

- Most podcast episodes and AMA sessions focus on lifespan and healthspan topics.
- Today’s topic is hair loss, which doesn’t directly relate to lifespan or healthspan but is a common question from both podcast listeners and patients.

The conversation will address:

- Causes of hair loss.
- Options to slow down hair loss or treat it once it has occurred.
- Summary of available treatments and guidance on choosing the right approach.
- How hair loss affects both men and women differently.
- How to find a good specialist if treatment is necessary.

For most people, hair loss is noticed in different ways:

- Visually, through the thinning of hair density.
- Noticing fallen hairs on pillows or in drains.

Relationship Between Hair Loss and Healthspan

- Although hair loss may not directly affect lifespan or traditional healthspan factors (physical or cognitive performance), it can still impact quality of life.
- But it can cause emotional distress, which ties it to emotional health and, indirectly, to healthspan.

## The prevalence, patterns, and causes of hair loss in men and women [5:15]

Prevalence of Hair Loss Across Genders:

- Hair loss is common for both men and women, but many people are surprised by how frequently women experience it.
- The focus of this discussion is [androgenic alopecia](https://en.wikipedia.org/wiki/Pattern_hair_loss) (AGA), which accounts for about 95% of male hair loss and at least half of female hair loss cases.

Male vs. Female Hair Loss:

- Androgenic alopecia is the primary cause of hair loss in men and often in women, but women have other common causes of hair thinning that must be ruled out.
- Men: Androgenic alopecia is responsible for almost all cases of hair loss in men.
- Women: While androgenic alopecia can cause thinning, other factors, such as pregnancy, menopause, autoimmune conditions, stress, vitamin deficiencies, and medications, play a larger role in women.
  - Temporary hair loss during and after pregnancy is common, but its inclusion in statistics depends on the context.

Causes of Hair Loss (other than AGA)

- Autoimmune conditions.
- Psychological stress.
- Hormonal changes (e.g., pregnancy, menopause).
- Vitamin/mineral deficiencies: Iron, Vitamin D, B12.
- Medications: Rare cases linked to statins, antidepressants, antihypertensives.

\*NOTE: For most of this episode of the podcast, we’re going to be referring to androgenic alopecia

Prevalence and Age-Related Hair Loss

- Prevalence in Men:
  - Male pattern hair loss (AGA) affects 30-50% of men by age 50.
  - Virtually all cases are manifest by age 40, though some men can begin experiencing hair loss as early as their late teens or early 20s.
- Prevalence in Women:
  - Female pattern hair loss is surprisingly common, affecting 20-50% of women across their lifespan.
  - It can begin as early as age 40, but in some cases, it may not start until age 60.

## The genetic and hormonal causes of hair loss, and the role of dihydrotestosterone (DHT) in androgenic alopecia [8:45]

Genetic and Hormonal Factors:

- Androgenic alopecia (AGA) is driven by a genetic susceptibility to hair follicle sensitivity and a hormonal component, primarily dihydrotestosterone (DHT).
- DHT, a derivative of testosterone, plays a central role in hair loss by binding to the androgen receptor in hair follicles, leading to miniaturization and thinning of the hair shaft.

Role of DHT in Hair Loss

- Testosterone and DHT:
  - Both men and women produce testosterone, but men produce significantly more (10-12 times more).
  - Testosterone is converted into DHT, a more potent hormone with a higher affinity for androgen receptors, contributing to hair follicle miniaturization.
- Sensitivity vs. DHT Levels:
  - AGA is more likely due to sensitivity of the hair follicle to DHT rather than the absolute levels of DHT.
  - Genetic factors determine the sensitivity of hair follicles to DHT, rather than an overproduction of DHT itself.

DHT and Hair Loss Threshold

- Variation in DHT Levels:
  - There is no clear minimum threshold of DHT that must be reached to cause hair loss, meaning even low levels of DHT can lead to hair loss if follicles are genetically sensitive.
  - Lowering DHT levels can help prevent or slow hair loss, though exact thresholds for complete prevention are not established in research.

Implications for Treatment

- Supplements and Medications:
  - Taking supplemental testosterone can increase DHT levels, accelerating hair loss in genetically predisposed individuals.
  - That said, medications that block the conversion of testosterone to DHT can help slow down or prevent hair loss.

Peter’s quick recap:

- So DHT levels per se are not a marker for androgenic alopecia, and it’s not clear if elevated DHT is necessary for AGA, androgenic alopecia, or whether it’s even sufficient.
- In other words, what I have not been able to find in the literature is a minimum threshold of DHT that if beneath that level is impossible for a hair follicle to come out.
- So presumably that would be zero, but can hair loss be stopped completely if DHT is below nine nanograms per deciliter versus 15 nanograms per deciliter versus five nanograms per deciliter? — “I haven’t seen those data.”

> “*Genetic sensitivity to DHT appears far more important than absolute DHT level. But. . .lowering DHT is a very important strategy to either preventing or halting hair loss*.” —Peter Attia

## The visual differences in hair loss patterns between men and women, and the importance of consulting a specialist to rule out non-genetic causes of hair loss [13:30]

**Visual Differences in Hair Loss Patterns**:

Men:

- Hair loss typically occurs in the temporal region and on the top of the head.
- Stages of male pattern baldness are well-documented and can be visually tracked

![](https://peterattiamd.com/wp-content/uploads/2024/09/f1-ama63-1024x400.png)

**Figure 1.** [[source](https://www.healthline.com/health/norwood-scale)]

Women:

- Hair loss is more nuanced and diffuse.
- Begins with widening of the part at the middle of the head and thinning on the scalp, possibly with frontal hairline recession.
- Women are less likely than men to experience significant balding.

![](https://peterattiamd.com/wp-content/uploads/2024/09/f2-ama63-1024x897.png)

**Figure 2.** [[source](https://www.treatmentroomslondon.com/hair/hair-loss-stages-in-females-ludwig-scale/)]

Cause of Hair Loss:

- Both men and women’s hair loss is related to the sensitivity of hair follicles to DHT.
- Peter mentions a curiosity regarding the evolutionary explanation for hair loss and the conservation of polygenic traits.
- No definitive evolutionary reason is known, but curiosity remains around why these genes have been conserved.

Diagnosing Hair Loss:

- Peter recommends using multidisciplinary hair centers for evaluation.
- These centers are beneficial for **ruling out non-genetic causes of hair loss**.
- Stress-related, medication-induced hair loss, or iron deficiency anemia can sometimes mimic androgenic alopecia (AGA).
- It’s important not to self-diagnose based solely on visual patterns. Consulting a specialist is key to eliminating other potential causes.

## How genetic predisposition influences the risk of androgenic alopecia, and how early detection through diagnostic tools and blood tests can help manage the risk more effectively [16:45]

***Let’s say a young person is trying to understand what their susceptibility to hair loss is as they grow older, do we know anything about how someone might know if they’re at risk for AGA?***

Genetic Risk of Androgenic Alopecia (AGA):

- Males:
  - If a male’s father experienced hair loss, he has about [twice the risk](https://karger.com/drm/article-abstract/209/1/33/112112/Family-History-and-Risk-of-Hair-Loss) of experiencing hair loss compared to males whose fathers did not have hair loss.
- Females:
  - The genetic relationship is even more pronounced in women, with an [85% increased risk](https://journals.lww.com/ijot/fulltext/2016/08020/female_pattern_hair_loss__a_retrospective_study_in.1.aspx) if either their mother or father had hair loss.
  - The absolute risk for women is still relatively low, and the severity tends to be much lower than in men.

Family History and Hair Loss:

- Family history is the most common predictor of androgenic hair loss for both men and women.
- This is a polygenic trait (multiple genes involved), not linked to a single gene.

Genetic Testing:

- Genetic services like 23andMe or tools like Prometheus can screen for genetic markers associated with AGA.
- These tests look at SNPs (Single Nucleotide Polymorphisms) to predict the likelihood of experiencing hair loss.
- “*Again, this is polygenic, so it’s not like there is a gene for this, but there are clearly genes that are associated with this, and therefore that’s probably the best predictor*.” says Peter

Early Detection Tools:

- In terms of understanding what is happening at the earliest instant, the gold standard would be the [trichoscopy](https://dermnetnz.org/topics/trichoscopy) test
- It’s a video scope test performed by a physician to examine hair follicles and detect early signs of hair loss.
- Can help determine whether the hair loss is autoimmune, nutritional, or another cause.

Blood tests can be used to rule out other conditions like:

- Iron deficiency anemia
- Thyroid dysfunction
- Endocrine disruptions
- These tests should be done early on, especially for individuals with a genetic predisposition.

## Ideal timing for starting treatment: why early treatment is crucial for effectively managing hair loss [19:30]

***Do we know anything about when the ideal time to start to look at treatment for hair loss would be?***

Timing of Hair Loss Treatment:

- **Prevention** is key and should be started early before significant hair loss occurs.
- Hair follicles don’t die completely in AGA (androgenic alopecia), so early intervention can slow or reverse hair thinning.
- Once hair loss reaches an advanced stage, the growth phase shortens significantly, producing only small, thin hairs.
- Intervening early gives the best chance of preventing irreversible damage to hair follicles.

Follicle “Breakpoint”:

- There is a breakpoint where follicles can no longer return to producing thick, long hair shafts, and only produce peach fuzz-like hair.
- The exact timing and cause of this transition is not well understood.
- Early intervention can prevent reaching this breakpoint
- Note that different parts of the scalp may reach this stage at different times due to sensitivity to DHT.
  - Each hair follicle has a different sensitivity to DHT, which dictates how quickly hair thinning progresses.
  - Some parts of the scalp may still be reversible, while others may have passed the point of no return.

Surprising Hair Loss Findings:

- A person can lose up to 50% of their hair density before it becomes visually noticeable.
- Hair density is typically measured in follicular units per centimeter squared.
- Normal density is 80-100 follicular units per cm², with each unit containing 1 to 4 hair shafts.

Hair Thinning Progression:

- Early thinning reduces density to around 25 to 50 follicular units per cm² and becomes visually apparent when 50 units or fewer are left.
- Later thinning occurs at 10 to 25 follicular units per cm², making the hair look thin all the time.
- When density falls below 10 follicular units per cm², the area appears visibly bald in all scenarios.

## The various FDA-approved treatments for androgenic alopecia, their mechanisms, and additional off-label treatments commonly used to manage hair loss [24:30]

**FDA-Approved Treatments for AGA**:

Topical Minoxidil:

- Minoxidil is historically used to treat recalcitrant hypertension.
- Mechanism: a vasodilator and an anti-inflammatory medication that also possibly has some anti androgenic effects
- Topical minoxidil is available in 2% and 5% solutions (5% is more potent but may cause more scalp irritation).
- **Oral** minoxidil (off label) is commonly dosed at 0.625-1 mg/day for women, 1-2.5 mg/day for men.
  - Biggest thing to be aware of with oral minoxidil is that this is going to interact with certain blood pressure medications potentially
    - If a person has labile blood pressure, they’re taking other blood pressure medications, this has to be a consideration, especially if they’re using minoxidil orally
  - Another thing of note is you’re likely to grow hair or increase hair growth in other parts of the body that are already growing hair

Oral Finasteride:

- Finasteride, depending on the dose you take it, comes in two names—
  - Available as Proscar (5 mg for treatment of enlarged prostate) and Propecia (1 mg for treatment of hair loss).
- 5-alpha reductase inhibitor, reducing DHT levels.
- Its “cousin” drug dutasteride is more potent and used at a lower dose.
- These drugs predictably and reproducibly lower DHT levels
- WARNING: pregnant women cannot take finasteride due to risks to fetal development.

Low-Level Laser Therapy (LLLT):

- FDA-approved non-invasive treatment for both men and women.
- Light therapy using wavelengths between 630-690 nm.
- Typical sessions: 15-20 minutes, 3 times a week for six months, followed by maintenance.
- Believed to increase ATP production and enhance blood flow to promote hair growth.

Spironolactone (oral/topical):

- Androgen receptor inhibitor.
- Often used by women for acne but not recommended for men due to anti-androgenic effects.

Ketoconazole Shampoo:

- 5-alpha reductase inhibitor and anti-inflammatory.
- Typically used in 1-2% solutions, 2-3 times a week.

Platelet-Rich Plasma (PRP):

- *Not FDA-approved* for hair loss but used off-label.
- PRP involves injections of concentrated platelets to stimulate hair follicles and reduce apoptosis.
- Typical treatment: 3-4 sessions every 2-4 weeks, followed by maintenance therapy.

## Topical minoxidil—the most commonly recommended starting treatment for hair loss [30:15]

***Is there any single approach that you think would be “the best place to start” for anyone experiencing AGA?***

- Overall, Peter says it’s not as simple as a “one-size-fits-all” approach for treating androgenic alopecia (AGA).
- Peter’s recommendation is to consult a hair specialist for individualized treatment plans.
- Reason being that hair specialists have more expertise, and it’s not something to approach lightly or without professional guidance.

Topical Minoxidil as a Starting Point:

- Topical minoxidil (e.g., Rogaine) is often the first-line treatment for most people.
- Mechanism: Vasodilator that enhances blood flow to hair follicles with anti-inflammatory properties.
- Available in 2% and 5% solutions.
- 5% solution is generally recommended unless not tolerated.
- Typical usage: applied 1-2 times daily, massaged into the scalp.

[Meta-analysis](https://pubmed.ncbi.nlm.nih.gov/34159872/) findings:

- Compared 24-week treatments of 5% solution, 2% solution, and 5% foam.
- All options outperformed placebo and showed similar efficacy.
- Even the 2% minoxidil increased hair count by almost 13 hairs per cm² (~4 follicular units).

Effectiveness of Minoxidil:

- While minoxidil increases hair count, the effect is modest unless treatment starts in the very early stages of hair loss.
- For example, if someone starts with 80-100 follicular units per cm², they can lose up to 50 units before noticing visible thinning.
- Minoxidil adding 4-5 follicular units alone may not be significant unless used early on.
- For people who are genetically susceptible to hair loss, early intervention with minoxidil and coupled with DHT reduction is recommended.
- Minoxidil’s pros: well-tolerated, inexpensive compared to other treatments.

**In summary**:

Minoxidil—because it’s very well tolerated topically, it’s very inexpensive relative to some of the other treatments—would probably still be first line, despite the fact that the actual results of minoxidil as monotherapy are modest.

## Oral vs. topical minoxidil: efficacy, ease of use, and potential side effects that must be considered [33:45]

***Are there specific circumstances when other treatment options may be preferable to the topical minoxidil?***

- Yes, says Peter
- Some patients find it difficult to adhere to the once or twice daily topical treatments required for effective results.
- This has led to increased interest in oral minoxidil, which is easier to manage but used off-label for hair restoration.

**Oral Minoxidil Use and Dosage**:

- Though FDA-approved for other conditions (such as hypertension), oral minoxidil is often prescribed off-label for hair loss (therefore, not covered by insurance)
- Doses range from 0.5 to 10 milligrams per day for hair restoration, with lower doses for women (0.625-1 mg) and higher doses for men (1-2.5 mg).
- High doses of oral minoxidil (5-10 mg/day) are in the lower range of doses used to treat hypertension (10-40 mg/day).
- Interactions with other medications (especially antihypertensive drugs) must be considered when using oral minoxidil.

**Efficacy of Oral vs. Topical Minoxidil**—Oral minoxidil is generally higher than that of topical forms.

In a [24-week randomized controlled trial](https://www.jaad.org/article/S0190-9622(19)32666-0/fulltext) (RCT) with 50 women:

- Oral minoxidil (1 mg/day) increased hair count by 20 hairs per cm².
- Topical minoxidil (5% solution twice daily) increased hair count by 13 hairs per cm².
- Both of these increases were statistically significant over placebo, however, the difference between the two groups wasn’t statistically significant likely due to the small sample size.

[Meta-analysis](https://pubmed.ncbi.nlm.nih.gov/34159872/) results: Oral minoxidil (5 mg) was more effective than any topical formula.

> “*Oral minoxidil is more efficacious than topical minoxidil, but it also comes with far more side effects*.” —Peter Attia

**Side Effects of Oral Minoxidil**:

- Oral minoxidil can cause excessive hair growth (hypertrichosis) across all parts of the body with existing hair.
- This side effect may be more concerning for women than men.

## Finasteride for treating hair loss: efficacy, potential side effects on libido, and the need for careful PSA monitoring in men to avoid missing early signs of prostate cancer [37:15]

**How Finasteride Works**:

- Finasteride blocks the enzyme responsible for converting testosterone to dihydrotestosterone (DHT).
- DHT is a key hormone driving androgenic alopecia (hair loss).
- In the US, finasteride is FDA-approved only for men, though it’s used off-label for women.

Finasteride Dosage and Efficacy:

- Typical doses range from 1 mg to 5 mg per day, though the efficacy of 1 mg/day is generally sufficient to reduce DHT levels.
- A [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/34291720/) showed that 1 mg of finasteride daily increased hair count by 12 hairs per cm² after 24 weeks and 16 hairs per cm² after 48 weeks, comparable to minoxidil’s results.

Adverse Effects of Finasteride:

- Potential side effects include decreased libido, erectile dysfunction, and ejaculatory dysfunction, though these are relatively uncommon.
- Post-Finasteride Syndrome: a rare condition where these symptoms persist even after stopping the drug.
  - [Discussion of post-finasteride syndrome with Ted Schaeffer](https://peterattiamd.com/tedschaeffer2/)
- Pregnancy risks: Finasteride should not be taken by women who are pregnant due to the risk of birth defects caused by DHT interference in fetal development.

Dutasteride:

- Dutasteride, a cousin of finasteride, is more potent and typically dosed between 0.1 to 0.5 mg/day.
- Some men take 0.5 mg as little as 2-3 times per week.
- A 24-week [study](https://pubmed.ncbi.nlm.nih.gov/24411083/) of nearly 1000 men showed that 0.5 mg/day increased hair density by 14 hairs per cm² compared to 10 hairs/cm² for 0.1 mg/day.

**Impact on PSA Levels**:

- Both finasteride and dutasteride can mask elevated PSA (prostate-specific antigen) levels, which is important for detecting prostate cancer.
- Patients using 5-alpha reductase inhibitors (like finasteride and dutasteride) must have PSA levels monitored closely to detect changes that might otherwise be missed.

## Other effective hair loss treatments for women: boosting hair density with spironolactone gel and ketoconazole shampoo as part of a comprehensive strategy [41:30]

**Spironolactone**:

- Primarily used for high blood pressure, fluid retention, and acne (linked to PCOS or excess androgens).
- Occasionally used off-label for female hair loss by inhibiting androgen receptors in hair follicles, preventing DHT signaling.
- Available as a 1% topical gel or 5% topical solution, and oral tablets ranging from 25 to 200 mg.
- [2023 Systematic Review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10010138/):
  - Out of 200 female participants, 81% showed improvement in hair growth.
  - A key limitation of the study was that it did not include numerical data regarding the density of hair growth or follicular unit density.
  - This means that while the photographic results suggested progress, the study did not quantify exactly how much the hair density increased per centimeter squared.
  - Instead, the results were based on the subjective evaluations of photos, where blinded assessors (those who did not know whether a participant received the drug or placebo) reviewed the images to determine the extent of hair improvement.
- Side effects: dizziness, headaches, nausea, increased urination, and the risk of hyperkalemia (high potassium).
  - Important to consult with a doctor as it can interact with other medications, especially blood pressure and heart failure drugs.
- Very affordable; shouldn’t cost more than $25 for a 30-day supply.

**Ketoconazole Shampoo**:

- Originally used as an antifungal for treating dandruff and scalp infections.
- Off-label use for hair loss due to local 5-alpha reductase inhibition and anti-inflammatory properties.
- Available in 1% and 2% concentrations by prescription; typically used 2-3 times a week as part of regular haircare.
- Side effects include scalp irritation and changes in hair dryness/oiliness.
- A [6-month trial](https://pubmed.ncbi.nlm.nih.gov/9669136/) showed significant increases in hair shaft density:
  - The trial compared ketoconazole shampoo to a minoxidil treatment coupled with an unmedicated shampoo
  - Ketoconazole group saw a 46 hairs/cm² improvement.
  - The minoxidil + unmedicated shampoo group saw a 30 hairs/cm² improvement.
  - Peter says it’s possible that the ketoconazole group were earlier in their process of hair loss and that’s why they had a better response compared to minoxidil.

Conclusion:

- The results from ketoconazole and spironolactone suggest these treatments can be effective in addressing hair loss, especially when used in a multimodal approach.
- Combining these methods can yield better results than relying on a single treatment.

## Low-level laser therapy: effectiveness, costs, practicality, and a comparison of in-office treatments with at-home devices [49:00]

**Low Level Laser Therapy (LLLT) Overview**:

- Treatment Description:
  - LLLT is a non-invasive treatment used to treat hair loss in both men and women.
  - It involves using a helmet-like device that emits red light in the 630-690 nm range directly to the scalp.
    - The red light range fluorescence of about 1 to 10 joules per centimeter squared with a power density of somewhere between as low as 3 to as high as 90 milliwatts per centimeter squared
    - 15 to 20 minutes three times a week for six months.
  - The treatment stimulates hair follicles to transition from a resting phase to a growth phase, potentially enhancing ATP production, improving blood flow, and reducing inflammation and oxidative stress.
- In-Office vs. At-Home Devices:
  - In-office devices are generally more potent than at-home versions, making them more effective. A combination of both in-office treatments for intensive therapy and at-home devices for maintenance is often recommended.
- FDA Approval: There are at least 30 FDA-approved devices for at-home use, but the efficacy may be limited compared to in-office treatments.
- Efficacy:
  - Clinical trials have supported LLLT’s effectiveness.
  - For instance, a [16-week RCT](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7373546/) involving 60 participants showed an improvement of 42 hairs per centimeter squared in the LLLT group compared to baseline, with a 7.5 micrometer increase in hair thickness.
  - The study used 655 nm light at 25-minute sessions every other day.

Costs and Time Commitment:

- Cost: Treatments in-office range from $100 to $500 per session. With three sessions a week, you’ll pay a minimum of $300 per week.
- Time: Patients may spend about three hours per week on treatments.
- In-office sessions offer advantages such as higher power and professional application, allowing for better monitoring of progress.
- At-home devices vary in cost from $200 to $2,000 but can be more practical for long-term maintenance.

Recommendations:

- If opting for at-home devices, it’s best to invest in the most powerful and effective device available, as results correlate with the power output.

## Platelet-rich plasma (PRP) as an off-label treatment for hair loss: potential effectiveness, varying protocols, and significant costs [53:45]

**Overview**:

- PRP therapy is not FDA-approved for hair loss but is used off-label due to its approval for other medical indications.
- The process involves drawing a small sample of blood, concentrating the platelets, and injecting the resulting platelet-rich plasma into the scalp where hair loss is occurring.

Protocol Variability:

- One challenge with PRP therapy is the lack of standardized protocols across practitioners.
- Different doctors use varied approaches for spinning blood, reconstituting plasma, and determining injection sites, making it difficult to assess overall effectiveness.

The general recommendation:

- 3-4 initial treatments spaced 2-4 weeks apart
- Followed by a maintenance schedule
- However, no consensus exists on how frequently these maintenance sessions should occur, with recommendations ranging from one month to six months intervals.

Efficacy:

- Longitudinal data is sparse, making it challenging to assess PRP’s long-term effectiveness.
- [A 2017 systematic review](https://pubmed.ncbi.nlm.nih.gov/28296142/):
  - Looked at five studies and reported an increase of 18 hairs per centimeter squared compared to controls, which equates to approximately 5-6 follicular units per centimeter squared.
  - This is somewhat less effective than red light therapy and on par with finasteride, dutasteride, and oral minoxidil.
- Some studies show better outcomes: a [24-month RCT](https://pubmed.ncbi.nlm.nih.gov/26400925/) revealed an increase of 46 hairs per centimeter squared in the PRP group, suggesting near-complete hair restoration in some cases.
  - But note that these better outcomes might result from earlier intervention before significant hair loss occurs.

Cost:

- PRP therapy can be expensive, with sessions costing between $500 and $1,000 each.
- Patients typically require between 2 to 12 sessions per year, leading to escalating costs as treatments shift from topical and oral options to more procedural approaches.

## Hair transplant for advanced hair loss: criteria and considerations [58:00]

***Let’s say someone’s out there and they’ve already lost a lot of their hair, what are the options available to them to “potentially get it back”?***

*A note about advanced hair loss*:

- Cannot be reversed with current technology once hair follicles reach a point of no return.
- Hair follicles may still be alive but are no longer capable of producing substantial hair.
- Hair transplantation is the only option to add back hair density for individuals with advanced hair loss.

Hair Transplant Effectiveness:

- Patient selection is crucial for success, similar to other surgeries (e.g., LASIK, complex surgeries).
- Unstable hair loss, patchy hair loss, or insufficient hair loss makes someone a poor candidate.
- Hair transplant candidates must have stable and predictable hair loss patterns.

Best Candidates for Hair Transplant:

- Should have lost at least 50% of their native hair which is regarded as the threshold at which hair transplantation can be performed without risk of damage to the remaining hair in the recipient area.
- Should have significant scalp visibility
- Surgeons need to clearly identify donor sites (where hair will be harvested) and target sites for transplantation.
- Ideal patients will ideally have hair density below 10 and certainly less than 25 follicular units per cm²

Surgery Considerations:

- Transplantation is possible if the hair loss is stable and the recipient area doesn’t show high levels of miniaturization.
- If miniaturization is over 15%, the risk of shock loss (further hair loss after surgery) increases.
- Patients must exhaust medical options and stabilize hair loss before surgery.

Shock Loss Risk:

- Shock loss can occur if hair is transplanted prematurely or into areas with high miniaturization potentially resulting in further hair loss post-op
- It’s important to ensure stabilization of hair loss with medical therapies before considering surgery.

## Types of hair transplants: follicular unit transplantation (FUT) vs. follicular unit extraction (FUE) [1:02:00]

**Overview of Hair Transplant Procedures**:

- Hair transplants are complex and tedious procedures requiring significant skill.
- There are two primary methods: Follicular Unit Transplant (FUT) and Follicular Unit Extraction (FUE).
- FUT (aka strip harvesting) is the older method, but FUE is increasingly preferred, though some experts still favor FUT for certain cases.

**Follicular Unit Transplant (FUT)**:

- Method: A strip of scalp is removed from the back or sides of the head, where hair growth is abundant and resistant to DHT (the hormone responsible for hair loss).

![](https://peterattiamd.com/wp-content/uploads/2024/09/f3-ama63.png)

**Figure 3. Preparation of minigrafts and micrografts from the dissection of the strip graft.** (1) Separation in vertical “filets,” (2) micrograft with one hair follicle, (3) micrograft with more than two hair follicles, often containing parts of >2 FUs, and (4) minigrafts include multiple FUs or multiple, partial FUs. [[Source](https://www.thieme-connect.com/products/ejournals/html/10.1055/s-0043-1777311)]

- Procedure:
  - Strip size: Typically 18 cm long and 1-1.5 cm wide.
  - The strip is dissected into 1,000 to 2,000 micro follicle units.
  - These units can be single hair follicles or groups of follicles.
- Post-procedure: The scalp is sutured after the strip is removed. The dissected follicles are implanted into the recipient areas.
- Pros: Ability to harvest a large number of follicles at once.
- Cons: Requires a larger wound to be closed, and may leave a visible scar.

**Follicular Unit Extraction (FUE)**:

- Method: A punch tool is used to remove individual hair follicles from the donor site (typically the sides or back of the head).
- Procedure:
  - The surgeon extracts each follicle individually using a small punch tool.
  - The follicles are then sorted, prepared, and transplanted into the recipient areas.
- Advantages:
  - Less invasive than FUT.
  - No large scar, only small punch marks that heal faster.
  - Additional donor sites: Can be harvested from areas like the beard, providing more options.
- Cons:
  - A much more time-consuming procedure since each follicle is extracted individually.

## The financial cost of hair transplant surgery, and what to consider when seeking affordable options [1:06:15]

Cost factors:

- The cost of a hair transplant varies significantly based on:
- Reputation of the surgeon: High-profile or specialized centers often charge more.
- Amount of hair transplanting needed: The more grafts required, the higher the cost due to both fixed and variable expenses (time and effort involved).

Grafts and cost estimates:

- On average, patients need 1,200 to 2,000 grafts per sitting.
- The cost per follicular unit extraction graft in the U.S. is typically around $5 to $10.
- This leads to a total cost range of $5,000 to $15,000 per treatment.

Medical tourism:

- Patients often explore medical tourism for cheaper procedures abroad, similar to going overseas for hip replacements or other surgeries.
- International locations offer lower prices, sometimes only a few thousand dollars for the full procedure.

Considerations for choosing medical tourism:

- Quality: Questions to ask include:
  - Are the facilities up to standard?
  - Are grafts being over-harvested?
  - What do scars look like from previous patients?
  - What kind of pain management or follow-up care is provided?
- Post-procedure care:
  - After surgery, patients should avoid long flights for at least two weeks to prevent complications, such as blood clotting.
  - Consider the benefit of staying near the clinic for post-op care and monitoring.

Recommendation:

- Thoroughly research the facility, surgeon, and quality of care before deciding to save money through medical tourism.
- The quality of the procedure should be a top priority over cost savings.

## The potential risks and downsides of the various hair transplant procedures [1:09:30]

**Follicular Unit Transplant (FUT)**:

- Advantages:
  - Produces a more robust graft.
  - Less risk of injuring the follicle during harvesting.
  - More efficient at gathering multiple grafts in one sitting.
- Disadvantages:
  - Produces a visible scar on the donor site, which may be more apparent in individuals with short hair.
  - Results in a larger initial appearance of transplanted follicles, making it more obvious initially that a hair transplant has been done.
  - More invasive, requiring sutures to close the wound and leaving a linear scar.
  - Healing time: Approximately two weeks to heal.
  - Not ideal for individuals who want to maintain short hair over the donor site.
- Preferred method for women, as shaving the head is not required for harvesting.

**Follicular Unit Extraction (FUE)**:

- Advantages:
  - Less invasive: No sutures needed, and it doesn’t leave a single large scar like FUT.
  - Scars are more distributed and smaller, but the total scarring area is larger due to multiple small incisions.
  - Can be harvested from donor areas beyond the head, such as the beard.
  - Shorter healing time, typically a day (though multiple harvesting can extend this).
  - Ability to perform the extraction without shaving the head using advanced facilities and techniques.
- Disadvantages:
  - More time-consuming as each graft is individually pulled and placed.
  - Fewer grafts can be harvested per session, limiting the total number over a lifetime.
  - Transection rate: In the hands of a skilled surgeon, the transection rate is about 5-10% (slightly higher than FUT’s 1-2%).
  - Requires frequent return visits for additional treatment within six months, while FUT patients may need to wait up to 10-12 months before further treatment.

Post-operative Recovery:

- FUT involves more debilitating pain in the donor area, with about two weeks required for healing.
  - If additional treatment is needed, FUT patient have to wait 10-12 months
- FUE patients are typically fine the next day
  - FUE patients can return for treatment on different areas as early as the next day, and can return within six months to work on the same area.

Graft damage/transection

- 1-2% with FUT
- 5-10% with FUE with experienced surgeons (a lot higher with inexperienced hands)

Long-term Considerations:

- Lifetime grafts: FUT allows for a higher number of grafts over time compared to FUE, which caps at about 3,000 grafts in total.
- Surgeon experience: It’s crucial to ask about the surgeon’s transection rate and expertise, as inexperienced surgeons can damage a large percentage of follicles.

![](https://peterattiamd.com/wp-content/uploads/2024/09/f4-ama63.png)

**Figure 4.**

## Post-procedure care for hair transplants and whether the procedure must be repeated periodically [1:16:30]

***Do hair transplants need to be repeated and combined with other therapies?***

- Hair transplants are generally permanent when done correctly.
  - Surgeons identify donor sites with hairs that are insensitive to DHT, ensuring that transplanted hair is not affected by androgenic alopecia.
  - It’s not the presence of DHT that causes hair loss, but the sensitivity of follicles to DHT. Transplanted hair remains unaffected even in DHT-sensitive areas.
- Post-transplant medical management:
  - After a hair transplant, patients should continue medical management to maintain the results.
  - This includes using treatments to preserve existing hair that wasn’t transplanted and may still be susceptible to DHT.
- Ongoing therapies may include:
  - Oral finasteride to lower DHT levels.
  - Minoxidil to stimulate hair growth.
  - Ketoconazole shampoo as an anti-inflammatory and DHT-blocking agent.
- Combination approach:
  - While the transplant itself is permanent, maintaining non-transplanted hair is key.
  - Patients should expect to continue using pharmacological treatments like finasteride and minoxidil for long-term maintenance.

## Combining different hair loss treatments: benefits, risks, and considerations [1:18:30]

**Combination therapy** is more effective than using a single treatment (monotherapy).

- Key caution: Avoid combining treatments that have overlapping effects, such as:
  - You wouldn’t combine finasteride with dutasteride because it’s the same thing
  - Don’t combine topical minoxidil with oral minoxidil, or topical finasteride with oral finasteride

An example of a combo approach:

- A combination of topical minoxidil, oral dutasteride/finasteride, and topical ketoconazole is recommended for different angles of treatment.

Supporting evidence:

- A [clinical trial](https://pubmed.ncbi.nlm.nih.gov/29972712/) (RCT of 40 men) compared 3% topical minoxidil + 0.25% topical finasteride to a minoxidil only group:
  - Minoxidil alone increased hair count by 35 hairs/cm² after 24 weeks.
  - Combination therapy boosted the count to 62 hairs/cm²—equivalent to approximately 20 follicular units.
  - Hair diameter also increased more significantly in the combination group (17 micrometers vs. 13 micrometers for minoxidil alone).

## Emerging hair loss treatments with limited data [1:21:00]

- Exosome vesicle therapy and trans-epidermal delivery of growth factors are newer concepts being discussed in the hair restoration community.
- Exosomes are not yet approved for any medical use in the U.S.
- There is skepticism around their applications due to the lack of data.
- Potential:
  - Despite skepticism, exosomes might show promise for hair restoration, given the success of platelet-rich plasma (PRP) in hair loss treatments.
  - The scalp is an easier area to study than other areas of the body (e.g., back pain), providing an opportunity for further research.
- Key point: While exosomes could be an area of innovation, caution is advised when considering treatments that lack strong supporting data.

## Key considerations for selecting the right treatment plan for hair loss [1:22:00]

***If someone is concerned about hair loss and they’re trying to figure out what to do, can you summarize the various variables that they should consider when determining what options are best for them?***

Stage of hair loss:

- Early-stage hair loss can often be managed with monotherapy (e.g., topical minoxidil).
- More advanced stages may require more aggressive treatments.
- Hair transplantation becomes the main option for late-stage hair loss.

Medication contraindications:

- Patients on certain medications (e.g., antihypertensives) need to be cautious, especially with treatments like oral minoxidil.

Risk tolerance:

- Personal comfort with side effects plays a major role, such as the rare but concerning post-finasteride syndrome for those considering finasteride.
- Some may prefer topical options over oral to mitigate risks (even though it might not be quite as efficacious, although in some studies it was)

Time Commitment and Financial Cost:

- Hair loss treatments can be expensive, with some patients even spending up to $100,000 annually on transplants and related treatments.
- Long-term commitment is required as hair loss treatment is typically lifelong.
- Maintenance costs are lower after a successful transplant, but upfront costs are high.

## A summary of the different considerations for men and women facing hair loss [1:24:30]

Men:

- Need to be cautious of treatments with anti-androgenic effects, such as spironolactone, which is generally not an option.
- Finasteride and dutasteride are effective but come with a small risk of impacting sexual function (libido, erectile, and ejaculatory function).

Women:

- Five alpha reductase inhibitors (e.g., finasteride) are potentially safe when not pregnant, but they are typically less effective in women compared to men.
- Women must consider non-genetic causes of hair loss, such as:
  - Iron deficiency, mineral deficiencies, nutritional depletion, or stress.
  - Hormonal changes, especially during perimenopause.
- Progesterone deficiency may contribute to thinning hair, and in some cases, progesterone supplementation has been shown to restore hair thickness.

General Considerations for Women:

- Women should work with hair specialists who can evaluate broader health issues, such as nutritional and hormonal factors, beyond genetic predisposition.

## Practical advice on selecting the right specialist or treatment team [1:26:15]

Multidisciplinary Approach:

- Hair loss treatment requires addressing genetic, nutritional, and hormonal factors.
- It’s essential to consult with a certified hair restoration physician who works closely with primary care physicians, dermatologists, and pharmacists to provide a comprehensive treatment plan.

Consider going to a Board-Certified Hair Restoration Physician:

- If considering a hair transplant, ensure the surgeon is board certified by the American Board of Hair Restoration Surgery.
- Key questions to ask include:
  - How many years of experience do you have?
  - What is your experience with FUE (Follicular Unit Extraction) vs. FUT (Follicular Unit Transplant)?
  - Can you show examples of scars from previous procedures?
  - Why do you recommend this approach for me?
- Be wary of doctors who are unwilling to answer questions or make time for you during consultations. This could indicate a lack of transparency.
- Hair transplant surgery is a significant decision, and mistakes can lead to physical and emotional scarring. Make sure to carefully evaluate your surgeon and their proposed treatment approach before proceeding.

Balancing Treatment with Time and Cost:

- Consider the sustainability of the treatments, including time commitment and cost.
- The good news is for those individuals starting early enough, you’re really talking about oral or topical minoxidil and finasteride, which are both inexpensive (topical ketoconazole, potentially spironolactone, also very inexpensive)
- It’s only once you go into laser light therapy, PRP, and transplants that the costs go way up
- But even the laser light at home, if you can get a high enough power unit is a big one-time cost, but otherwise is relatively low cost

> “Starting earlier is the name of the game here.” —Peter Attia

§

## Selected Links / Related Material

**Men with fathers who had hair loss have twice the risk of hair loss**: [Family History and Risk of Hair Loss](https://karger.com/drm/article-abstract/209/1/33/112112/Family-History-and-Risk-of-Hair-Loss) (Chumlea et al., 2004) [17:00]

**If women have a family member with hair loss—either mother or father—their risk is increased by 85%**: [Female Pattern Hair Loss A Retrospective Study in a Tertiary Referral Center](https://journals.lww.com/ijot/fulltext/2016/08020/female_pattern_hair_loss__a_retrospective_study_in.1.aspx) (Siah et al., 2016) [17:00]

**Meta analysis that compared a minoxidil treatments with a 5% solution, a 2% solution, or a 5% foam, and interestingly, it all showed roughly equivalent efficacy**: [Minoxidil: a comprehensive review](https://pubmed.ncbi.nlm.nih.gov/34159872/) (Gupta et al., 2022) [32:00]

**RCT of minoxidil for women comparing oral vs topical**: [Minoxidil 1 mg oral versus minoxidil 5% topical solution for the treatment of female-pattern hair loss: A randomized clinical trial](https://www.jaad.org/article/S0190-9622(19)32666-0/fulltext) (Ramos et al., 2020) [35:15]

**Another minoxidil study comparing oral vs topical showed oral to be more efficacious**: [Minoxidil: a comprehensive review](https://pubmed.ncbi.nlm.nih.gov/34159872/) (Gupta et al., 2022) [36:00]

**Episode of The Drive with a discussion of post-finasteride syndrome**: [#273 ‒ Prostate health: common problems, cancer prevention, screening, treatment, and more](https://peterattiamd.com/tedschaeffer2/) | Ted Schaeffer, M.D., Ph.D. (October 2, 2023) [37:45]

**A meta-analysis in males found that one milligram of Finasteride daily resulted in increased total hair count compared to placebo**: [Finasteride for hair loss: a review](https://pubmed.ncbi.nlm.nih.gov/34291720/) (Gupta et al., 2022) [37:45]

**Studying showing effectiveness of dutasteride for hair loss**: [A randomized, active- and placebo-controlled study of the efficacy and safety of different doses of dutasteride versus placebo and finasteride in the treatment of male subjects with androgenetic alopecia](https://pubmed.ncbi.nlm.nih.gov/24411083/) (Harcha et al., 2014) [40:00]

**A systematic review that looked at oral spironolactone in about 200 female participants with hair loss**: [The Efficacy and Safety of Oral and Topical Spironolactone in Androgenetic Alopecia Treatment: A Systematic Review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10010138/) (Wang et al., 2023) [42:45]

**Ketoconazole shampoo study**: [Ketoconazole shampoo: effect of long-term use in androgenic alopecia](https://pubmed.ncbi.nlm.nih.gov/9669136/) (Piérard-Franchimont et al., 1998) [45:30]

**Low-Level Laser Therapy RCT of 60 men and women assigned to either an LLT group or a sham protocol**: [Low-level light therapy using a helmet-type device for the treatment of androgenetic alopecia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7373546/) (Yoon et al., 2020) [51:30]

**A 2017 systematic review of platelet-rich plasma therapy for hair loss**: [Platelet-rich plasma for androgenetic alopecia: Does it work? Evidence from meta analysis](https://pubmed.ncbi.nlm.nih.gov/28296142/) (Giordano et al., 2017) [55:15]

**A 24 month RCT that showed a difference of 46 hairs per centimeter squared in a group using PRP**: [The Effect of Platelet-Rich Plasma in Hair Regrowth: A Randomized Placebo-Controlled Trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4622412/) (Gentile et al., 2015) [56:30]

**Trial that looked at a combination therapy approach compared to minoxidil only**: [A randomized, double-blind controlled study of the efficacy and safety of topical solution of 0.25% finasteride admixed with 3% minoxidil vs. 3% minoxidil solution in the treatment of male androgenetic alopecia](https://pubmed.ncbi.nlm.nih.gov/29972712/) (Suchonwanit et al., 2018) [1:19:45]

§

## People Mentioned

- [Ted Schaeffer](https://dr-schaeffer.com/about-dr-schaeffer/) [37:45]

§