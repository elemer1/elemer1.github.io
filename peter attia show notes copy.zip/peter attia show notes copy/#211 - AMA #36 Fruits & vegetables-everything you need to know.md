# #211 – AMA #36: Fruits & vegetables—everything you need to know

**Source:** [https://peterattiamd.com/ama36/](https://peterattiamd.com/ama36/)

---

In this “Ask Me Anything” (AMA) episode, Peter discusses the nutritional profiles of various fruits and vegetables as a means of assessing their relative value. He explains the difference between eating them vs. drinking them, how processing fruits and vegetables can change their properties, and how one’s current state of health affects nutrition strategy when it comes to fruits and vegetable consumption. Additionally, Peter explains the potential benefits and negative effects of certain phytochemicals found in produce and concludes with a discussion of supplementing with green powders, multivitamins, and more.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #36 show notes pag](https://peterattiamd.com/ama36)e. If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- The limitations of nutritional data and challenges of making broad recommendations [2:00];
- How one’s current state of health impacts their “optimal” diet [11:30];
- Defining “metabolic health” [14:45];
- The wide-ranging nutrition profiles of various fruits and vegetables [16:30];
- The benefits of fiber [20:45];
- Eating whole fruits vs. drinking fruit juice or smoothies [22:30];
- Drinking alcohol: metabolic effects, calories in alcohol, and more [28:30];
- Can excess fruit consumption lead to insulin resistance? [30:30];
- Glycemic impact of different fruits, using CGM data to assist decision making, and how fruit is fundamentally different from what we evolved to eat [31:30];
- Dietary approaches for people with a carbohydrate tolerance disorder (TD2, NAFLD, etc.), and when it makes sense to restrict fruit consumption [34:30];
- Nutrition profile of select vegetables: sugar content, micronutrients, and more [40:00];
- Phytochemicals in produce: potential positive health impacts on inflammation, cardiovascular (CV) risk, and cancer [44:30];
- Phytochemicals with potential negative health impacts [50:45];
- Nightshades and inflammation [53:15];
- How important is it to eat organic foods? [56:00];
- How necessary is it to wash fruits and vegetables? [1:00:45];
- How does food preparation change the nutritional composition? [1:03:45];
- Considerations when eating canned and frozen food, and paying attention to processed food additives [1:04:45];
- Supplementing vitamins and nutrients as an alternative to eating whole fruits and vegetables [1:06:15];
- Green powder supplements [1:11:15];
- Important takeaways [1:16:00]; and
- More.

§

The Peter Attia Drive

Fruits & vegetables—everything you need to know

§

## Show Notes

## The limitations of nutritional data and challenges of making broad recommendations [2:00]

**What we really know and don’t know**:

- The following is true on average: People who eat more fruits and vegetables are healthier than people who don’t
- But if you really get into the details of this stuff, there’s far less that’s known than is represented as true
  - That’s a broader concept that applies to nutrition in general
  - And it speaks to why the nutrition chapter of Peter’s book has been “hands down posing the greatest difficulty”
  - And it’s not because Peter has nothing to say, it’s because there’s less to say *definitively* than he would’ve said 5 or 10 years ago
  - There are the obvious things:
    - Too much food is bad
    - Too little food is bad
    - Too little protein is bad
    - Certain micronutrients are essential
    - Certain things are toxic
    - After that, it starts to go from really clear, absolute knowledge to probable knowledge very quickly (And it does so quicker than it does with sleep, with exercise, and even with pharmaceuticals)

“And yet it’s the one area where I think people speak about things in more absolute terms than they do in anything else”

***Why do people speak in absolute terms about nutrition despite the nuanced and complex reality?***

- One explanation is that everyone on the planet has some “expertise” with nutrition because we eat food every single day
  - By contrast, not everybody exercises every day
  - But we’re conscious and we make deliberate choices when we eat every single day

> “I think there’s also a very significant cultural and social component to this thing as well. So I think that’s where the tribalism comes from around nutrition.” —Peter Attia

*On the flip side…*

- It’s very difficult to acquire reliable knowledge in this space
- However, there are some really good scientists working on the mechanistic side of nutrition
  - Such as people who are really under very tightly controlled conditions, elucidating some of the most interesting knowledge with respect to energy balance, with respect to appetite, with respect to fuel partitioning, food reward
  - The problem is that it is nearly impossible to do this type of work in large sample sizes over long durations
  - And you need large sample sizes and long durations to infer hard outcomes that we care about, which are prevalence of disease or incidence of disease and ultimately mortality
  - So therefore to get insights on those topics, you have to rely almost without exception on epidemiology
- There are some reasonably well done, large clinical trials, but they require thousands of people and many, many years…And that means your interventions had better be very, very simple if you’re going to achieve compliance over that period of time.

*All of this is to say…*

- Nutrition is very hard and when we rely on epidemiology and we’re struggling to necessarily get it right in areas where the hazard ratios end up being quite small
  - when you get hazard ratios like 1.19, it’s very difficult to know that you’ve captured and removed all of the biases that fed into that

**People doing good work**

- [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin) is really doing some super interesting work
- Peter says Kevin is one of the most thoughtful people on the subject of energy balance
  - This is an area where you can get answers to questions in months
  - And you don’t need thousands of people, you can actually do these in tens of people provided you’re using very precise instrumentation

**Questions that can’t really be answer quickly**

Example: *Are omega 6 polyunsaturated fats inherently healthy or harmful?* (a very vexing question)

- Peter has seen pretty compelling evidence that omega 6 polyunsaturated fats as substituted for saturated fats could actually be viewed as harmful
- For example, looking at the initially unpublished data from the Minnesota Coronary Experiment that completed in 1973, but didn’t get published in its first rendition until 1989 and then wasn’t [reexamined](https://www.bmj.com/content/353/bmj.i1246) and republished much later
  - If you look at those data, you could make a very compelling case that omega 6 polyunsaturated fats as substituted for saturated fats could actually be viewed as harmful
- But then you look at a whole bunch of other data and you might conclude that actually any harm associated with those fats is purely due to the confounders of what they track with, the seed oils that show up in low quality foods and junk foods
  - In other words, it’s not the seed oil that’s the problem, it’s the junk food that’s the problem
- This example just speaks to the type of questions that have profound importance but it’s unclear as to the answer

## How one’s current state of health impacts their “optimal” diet [11:30]

- The goal of the podcast today isn’t for listeners to be told what they can and can’t eat
  - It is variable depending on your metabolic health diet, what you’re already eating
- The hope is for the listener to have a better understanding of the subject and to be able to apply that knowledge to their unique situation

**Important point from Peter**:

- Don’t confuse the optimal diet for you in a **state of health** versus the optimal diet for you in a **state of sickness** that’s trying to restore your health
- For example: When Peter works with patients who are metabolically healthy, he’s never once restricted the amount of fruit they consume
  - But when working with a patient who has type 2 diabetes and non-alcoholic fatty liver disease, he will actually restrict how much fruit they consume
  - Peter says that “we’re going to have a better chance of improving your metabolic health if we at least temporarily reduce the volume of that significantly. Reduce the burden of fructose on your liver.”
  - This is because both fructose and ethanol are pretty uniquely poised to make a sick liver sicker
  - *Does that mean that that person’s going to always be restricting fruit?* ⇒ No, not necessarily, but empirically, it seems easier in those people to reduce fructose intake and to do so through fruits
- Even for Peter personally, he says that how he eats today to preserve his health is “*unquestionably different from how I was eating 15 years ago when I was in the process of trying to improve my health from a place that was actually below where it is today*”

## Defining “metabolic health” [14:45]

There’s a lot of different ways you can define it

- It’s sort of like BMI is the easiest way to to define overweight and obesity but body composition would be a better way to do it
- Similarly, the quickest and easiest way to define metabolic health is probably to use the criteria for metabolic syndrome
  - metabolic syndrome is basically defined in a binary fashion where if you have three or more of the the following five criteria you are considered to have MetSyn:
    - Increased blood glucose
    - Abdominal (truncal) obesity
    - High fasting triglycerides
    - Low HDL cholesterol
    - High blood pressure
- That said, Peter doesn’t use this with his patients since he’s not trying to make assessments at a population base level
- He’s looking at many more factors beyond those things, such as:
  - oral glucose tolerance tests
  - uric acid levels
  - homocysteine levels
  - the entire lipid profile
  - Functional testing
    - how the mitochondria perform in a zone two test
    - how much lactate is a person producing at rest and then how much lactate did they produce under increasing amounts of workload

## The wide-ranging nutrition profiles of various fruits and vegetables [16:30]

An easy way to do this is to do it on equal servings per weight:

![](https://peterattiamd.com/wp-content/uploads/2022/06/f1-ama36-1024x746.png)

**Figure 1.** Nutrition profiles of select fruits.

They took the fruit and nutrition profile of a 300 gram serving of a number of fruit

- So a 300 gram serving would be two avocado, four lemons, one and a half oranges, 20 to 25 strawberries, three bananas, and so on
- The things that we looked at to make this table was how much sugar is in it, how much water is in it, how much fiber, calcium, potassium, vitamin C and vitamin A
- Presumably more calcium, more potassium, more vitamin C, more vitamin A would be better
- But by normalizing it to this 300 gram serving, you get a sense of the trade offs between the content in them

Highlighting a couple of examples

- Consider oranges — Eating whole oranges.
  - So 300 grams serving would be one and a half oranges.
  - So that’s got 28 grams of sugar in it which isn’t that much, especially if you compare it to dates
- Dates
  - 300 gram serving of dates is only 12 dates
  - 190 grams of sugar in just 12 dates
  - Those 12 dates have 60 plus grams of water versus 260 grams of water in the orange
- In summary of oranges vs. dates
  - Again, 300 gram serving of orange, 260 of that is water, only 28 of that is sugar
  - In the dates, 300 gram serving, 60 is water, 190 is sugar
  - interestingly, the dates have more fiber (surprising to Peter) — the dates actually have 24 grams of fiber versus only seven grams in the oranges
  - In terms of Calcium, they’re about the same. 120 in the orange, 117 in the dates
  - Potassium, no comparison
    - The dates are so rich in potassium, almost two grams of potassium in the dates versus about 500 milligrams in the orange
  - Vitamin C — No comparison in the other direction — The orange is about 160 milligrams of vitamin C to only one milligram of vitamin C in the dates
  - Then vitamin A — 33 milligrams in the orange and nothing in the dates
- Looking at Figure 1, you will get a sense of the following: To describe fruits or vegetables as a homogeneous construct is silly
  - This is a very heterogeneous class of food that on some levels have very little in common
  - For instance, avocados and dates pretty much have not a single thing in common when looking at their nutritional profiles

## The benefits of fiber [20:45]

***What is it about fiber that’s beneficial when you eat sugar?***

- Fiber is beneficial probably first and foremost, because if it’s effect on the microbiome
- We have to kind of distinguish between soluble and insoluble fiber
  - soluble fiber is that which we can digest
  - Insoluble fiber is that which we cannot digest
- Fiber probably plays a role in slowing down the absorption of the macronutrients—the amount of glucose and fructose and things like that
- Also plays an important role in feeding the bacteria in our gut
  - we’re now more aware of the role the intestine play in fructose metabolism than previously known
  - Before, we thought that most of the metabolism or fructose was actually done in the liver
- In the recent [podcast with Rick Johnson](https://peterattiamd.com/rickjohnson2/), he talked about how actually the enterocytes can do some of that digestion in the gut provided it’s happening slowly
  - So as long as they’re not being saturated, they can metabolize that fructose reasonably well
- Peter forgets the exact rate, but when that rate is exceeded, all of a sudden you have to then rely on this systemic approach where you go from the gut to the liver and that’s probably where you start to get into more the metabolic difficulties in an individual who’s challenged
- In short, that’s probably part of why there’s some benefit to fiber from a sugar absorption and digestion standpoint

## Eating whole fruits vs. drinking fruit juice or smoothies [22:30]

***How do you think about everything we just talked about with fruit terms of eating it (i.e., orange slices) versus drinking it (i.e., orange juice or smoothie)?***

***Is there a difference in how people should think about the health benefits and all the metrics that you saw there with the fruit?***

*Using the example of apple sauce*:

- Peter’s kids love apple sauce – which usually has two ingredients: apples and citric acid (to prevent oxidation)
- So if it’s just apples grinded up, and you do a comparative analysis with a similar volume of who applies, *why does it seem to have a higher glycemic impact?*
- It seems to me that any type of processing, which can include just grinding it up, mashing it, cooking it, raises the glycemic index of the fruit by making it more easily digestible
- All things equal, anytime you eat a fruit or a vegetable closest to its natural form, you’re going to have a lower, basically, glycemic index to it.
- For instance, apple sauce may have a glycemic index of 53 while a whole apple may have a glycemic index of 38

Another note: It’s nearly impossible to eat something like 5 oranges back to back, but you could easily drink the juice from 5 oranges in one sitting

**Policy with Peter’s patients**: Don’t drink calories

- As a general rule, I think drinking calories is not a good idea
- E*xtreme example*:
  - patients who have had gastric bypasses who have regained a lot of weight after the surgery
  - one of the most common reasons for that is drinking things with calories in it
  - That’s definitely a way to hijack the circuit
  - once you start drinking calories, you basically go outside of the normal regulatory pathways that might be more conscious of regulating intake
  - You lose a ton of the volume regulation. So volume is a piece of how we regulate what we consume. So gastric distention is what I mean by volume
- Imagine what your stomach looks like after eating eight big oranges versus drinking 12 to 14 ounces of orange juice
- “*The fewer calories you drink, I think the better off you are*.”
- One exception to that rule would be shakes that are meal replacements
  - Peter probably drinks a reasonable amount of protein, mostly out of convenience
  - It may be hard to eat 180 grams of protein a day for some people without those 40 grams that come in a shake

## Drinking alcohol: metabolic effects, calories in alcohol, and more [28:30]

> “Alcohol is literally the worst food you can drink.” —Peter Attia

**Alcohol**

- Compared to say, a fruit smoothie, you’re getting more caloric density with alcohol
  - Alcohol is 7 calories per gram
  - Carbohydrates (e.g., fruit) is 4 calories per gram
- Then you also get the metabolic effects of alcohol which are pretty harmful
  - So you have the straight up toxicity of alcohol
  - And then you have the effect of alcohol on fat oxidation, fuel partitioning, and how it basically sets you back every time you have a drink
  - The body then goes into prioritizing ethanol, oxidation and metabolism and it basically puts a halt to anything else

> “If weight loss and fat loss is an objective, then I would really make sure you’re not drinking those two glasses of wine a night.” —Peter Attia

## Can excess fruit consumption lead to insulin resistance? [30:30]

One could argue that limiting fruit consumption in someone with type 2 diabetes makes sense

However, *does Peter worry that excess fruit consumption could lead to insulin resistance in someone who is metabolically healthy*?

- Short answer is “no”
- Peter says: “*In a metabolically healthy individual, I just don’t see any compelling reason to restrict fruit.*”

## Glycemic impact of different fruits, using CGM data to assist decision making, and how fruit is fundamentally different from what we evolved to eat [31:30]

Question(s):

*How would that metabolically healthy person weigh CGM information?*

Let’s say they wear a CGM and they notice that it spikes after they have maybe fruits and vegetables…

*Do you tell them not to worry about those spikes? Is it because of what they’re eating? How do you work through that concept of, do you worry about every spike that comes through a CGM?*

**Peter notes**: These are good questions because it speaks to the fact that not all fruits are created equal

- Personal example, grapes tend to have a HUGE impact on Peter’s blood sugar
- How does Peter interpret his CGM info from grapes?
  - I interpret that information as that’s unnecessary
  - If I really feel like I need to eat grapes
  - Maybe I just eat fewer of them or maybe I pair them to a time of day when my glucose disposal is going to be far better (such as right after a workout)
  - And don’t eat them before bed

**How fruit has changed**:

- And it’s worth noting that the big juicy green grapes you find at a grocery store is nothing like what our ancestors ate
- A lot of the fruit today probably bears no resemblance to fruits of 100 years ago, let alone 1000 years ago.
- When you sort of take into account what crop domestication has done, the real change in fruits and vegetables has been through the domestication of selective breeding
- That coupled with the huge advances in understanding how much nitrogen to use, how much phosphorus to use, how to basically go through soil rotations and things like that, that’s what’s fundamentally changed and leapfrogged the ability of food scientists and farmers to dramatically create these different breeds of fruit
- A lot of them are really wonderful, but we just have to accept the fact that they’re pretty foreign to our DNA and they’re not necessarily what we evolve to eat

## Dietary approaches for people with a carbohydrate tolerance disorder (TD2, NAFLD, etc.), and when it makes sense to restrict fruit consumption [34:30]

**NAFLD and Type 2 Diabetes**

- Type 2 diabetes is a carbohydrate tolerance disorder—if you have type 2 diabetes, you do not process glucose correctly
- ⇒ [Gerald Shulman](https://medicine.yale.edu/profile/gerald_shulman/#:~:text=Shulman%20is%20the%20George%20R,the%20Yale%20Diabetes%20Research%20Center.&text=Shulman%20is%20the%20recipient%20of%20the%20Stanley%20J.) provides a remarkable explanation as to why that’s the case in [episode #140](https://peterattiamd.com/geraldshulman/)
  - What is the etiology?
  - How is it that intramuscular fat becomes the canary in the coal mine that leads to this dysregulated insulin signaling that ultimately results in the dysregulation of blood glucose?
  - It does seem that to a first order effect—this is predicated by energy and balance
    - Excess energy seems to be the root cause of this energy spillover from the adipocyte into the muscle or into the liver or into the perinephric space or into the pancreas

*So how do you go about treating T2D?*

- One way to do it is just completely calorically restrict people
- And the quickest way to treat diabetes would be to fast
  - An exception to that rule might be gastric bypass

**More on gastric bypass and what it’s telling us about T2D**

- GB can ameliorate the consequences of type 2 diabetes from a glycemic standpoint within weeks, even before the patients lose significant amount of weight
- This tells us that significant weight loss is not responsible to reverse the physiologic changes in type 2 diabetes
- Weight loss is an important avenue, but the GB tells us something else is going on

**Fasting**

- Fasting may be hard for a diabetic to tolerate
- However, if you take somebody with type 2 diabetes and they do a seven day only water fast, which is going to require a lot of supervision, they’re going to be in a much different physiologic place at the end of seven days than they were at the beginning

**Carbohydrate restriction and keto diets**

- This can be thought of as a less extreme way to get the benefits of fasting
- Ketogenic diets are a very effective way to treat type 2 diabetes
  - The advantage that they have is the patients don’t have to feel starving all the time
  - it’s generally easier for patients to eat less on a ketogenic diet than it is on a balanced diet (meaning balanced in carbohydrates and fat)
  - That’s just an empirical fact. That’s not saying anything special about a ketogenic diet. It’s simply an empirical fact and anybody who’s tried a ketogenic diet, anybody who has treated patients with ketogenic diets will attest to that.
- One of the other things that’s missing in a ketogenic diet is sugar
  - Sugar, even in modest amounts, will boot you out of ketosis and it’s something probably about the elevation of beta-hydroxybutyrate and acetoacetate that makes the ketogenic diet work a little bit better
    - It augments some of the glucose demand of the brain
    - It’s probably about a 10- to 20% energy offset, obviously in very, very deep ketosis, which can really only be achieved through fasting

**Takeaways as it pertains to fruit**:

> “I absolutely feel like the easiest way to get people to start to close the gap when they’re starting out with a place of type 2 diabetes and NAFLD, is to restrict fructose in the form of fruit.” —Peter Attia

Question is, *how much fruit?*

- Peter will sometimes go pretty draconian and limit people to 15 grams a day of fructose
- For context, that’s a small bowl of berries or half an apple

## Nutrition profile of select vegetables: sugar content, micronutrients, and more [40:00]

![](https://peterattiamd.com/wp-content/uploads/2022/06/f2-ama36-1024x611.png)

**Figure 2.** Nutrition profiles of select vegetables.

*A few interesting items*:

1 – The first thing that just jumps out at you is that there is way, way less sugar in veggies than in fruit

- If you rank veggies in sweetness (starting from least sweet) first would be spinach the sweetest being sweet corn
- Peter is surprised at how little sugar is in sweet corn—a 200 gram serving (of which 150 grams is water) has only 12 and a half grams of sugar

2 – Generally speaking, fiber in veggies is as high as Peter would’ve guessed

- Kale came in at 7 grams of fiber per 200 gram serving

3 – What’s interesting is when you start to look at the micronutrients

- 3a) Carrots—not surprisingly because we were all told this as kids good for the eyes—has staggering amounts of vitamin A
  - Kale, 1000
  - Spinach, almost 1000

⇒ See episode [#198 with Steven Dell](https://peterattiamd.com/stevendell/) for more on eye health

- 3b) When you look at vitamin C
  - Kale again wins at 240
  - Broccoli’s a little under 200
  - Spinach around 50
- 3c) Potassium and calcium
  - kale and spinach are the big winners

4 – Overall: There really is something to be said for the micronutrient value of things like kale and spinach

**About figure 3 below**:

- It tells you what the estimated average requirements are
- But as a general rule, this really, really represents a bare minimum
- Obviously it doesn’t tell you anything about you, but it gives you a sense of where people are generally falling short and therefore you get a sense of maybe where you need to go in and fill the gaps

![](https://peterattiamd.com/wp-content/uploads/2022/06/f3-ama36-1024x677.png)

**Figure 3.** Common micronutrient deficiencies among US adults. [[source](https://lpi.oregonstate.edu/mic/micronutrient-inadequacies/overview)]

## Phytochemicals in produce: potential positive health impacts on inflammation, cardiovascular (CV) risk, and cancer [44:30]

**What is a phytochemical?**

- “Phyto” refers to plants
- So phytochemicals are chemicals that are produced by plants
- And we kind of distinguish them from essential nutrients such as essential vitamins, minerals and micronutrients, which plants are capable of producing
- Sometimes phytochemicals actually play a role in helping plants defend themselves
  - Animals can run, animals can attack, but plants are sometimes armed with phytochemicals that can themselves be competitive against other plants or pathogens or predators
- Phytochemicals are then further subdivided into different classifications
  - Glycosides
  - Alkaloids
  - Polyphenols (which probably get the majority of the attention)
  - Polysaccharides
  - Lectins
  - Etc.

**Polyphenols**

- Polyphenols then get subdivided into flavonoids and non-flavonoids.

*Flavonoids*

- There’s some interesting data on the effect of cocoa flavonoids as a supplement with respect to cardiovascular disease
- There’s a nutritional supplement made from cocoa extract called [CocoaVia](https://www.cocoavia.com/)
  - Note that you can’t get enough cocoa flavonoids from eating chocolate (so don’t go nuts!)
  - But the pure cocoa flavonoid seems to offer pretty significant improvements in endothelial health
- An [interesting study](https://pubmed.ncbi.nlm.nih.gov/35294962/) that just came out in 2022 that looked at using about 500 milligrams a day of cocoa flavonoids
  - Study last 3.5 years
  - Groups: 400 subjects taking supplement and 450 in the placebo group
  - Results: It did not find a significant reduction in total cardiovascular events though it did find a reduction in CVD deaths specifically
  - Peter says that he wouldn’t be surprised if this study was just underpowered so that the effect size that was significant was smaller than what they set out to test
  - But it at least seems interesting to me that there might be something to these cocoa flavonoids when supplemented as a way to improve endothelial function
    - And that can be done through presumably promotion of nitric oxide synthase and things like that

*Quercetin [48:25]*

- Quercetin can be found in the skin of apples (and other places)
- Some [data](https://www.nature.com/articles/s41598-021-02544-0) about how quercetin plays a role in tamping down senescent cells
- But one of the challenges of studying these things is that most of them are nutraceutical products and therefore they’re generally not things that have the same motivation to be studied rigorously the way drugs would have

⇒ See [AMA #35](https://peterattiamd.com/ama35/) for more about why certain molecules don’t get studied as rigorously as others

**Phytochemicals for Cancer [48:45]**

- There’s some weak evidence, but there may be some benefits
- Certain phytochemical classes, again, the polyphenols probably being the most well studied, but also tannins and glycosides, they do show some evidence of reducing inflammation, both in vitro and also in vivo for rodent models, not in vivo for humans ([1](https://www.mdpi.com/2072-6643/10/11/1618/htm), [2](https://www.mdpi.com/1422-0067/21/6/2187/htm), [3](https://www.hindawi.com/journals/omcl/2016/7432797/))
- The clinical evidence of this in humans is still lacking…“*but that doesn’t stop people from being all over social media telling you that the secret elixir to life is more polyphenols*.”
- The data is probably stronger on cardiovascular disease than it is on cancer, says Peter

> “The data is overwhelmingly stronger for exercise than it is for all of the above on any given day, no matter how strong the tailwind. . .Major in the major and minor in the minor, the stuff’s in the minor.” —Peter Attia

⇒ See [episode #163 with Layne Norton](https://peterattiamd.com/laynenorton/) all about exercise

## Phytochemicals with potential negative health impacts [50:45]

***Is there anything negative or “bad” in terms of phytochemicals?***

- This speaks to the nature that not everything in plants is good and there’s a subset of these phytochemicals that are actually referred to as anti-nutrients
- So these are phytochemicals that interfere with the body’s ability to absorb nutrients
- They can actually inhibit binding of vitamins and minerals and things like that

Some to highlight include:

- Oxalates
- Lectins
- Phylates
- Tannins

Oxalates

- Oxalates are found in turmeric and spinach
- If you eat too much spinach, you actually run the risk of getting high oxalate levels and this can result in kidney stones
- Anytime one of Peter’s patients has a kidney stone, they do an analysis of their urine or of stone itself (if they can get it)
- They look to see if it’s more calcium based, oxalate based, etc.
- Again, one has to be a bit careful about how much of those things you’re consuming

Lectins

- Lectins are found in legumes and grains
- if they’re undercooked, they can be problematic
- They can cause diarrhea and vomiting

Phylates

- Phylates are found in the holes of whole grains and seeds and they bind two essential minerals like calcium, magnesium, iron, etc.
- if you have too many of these things, they can actually interfere with the binding of calcium, magnesium, etc.

Tannins

- Typically found in red wine
- Tannins can inhibit the absorption of minerals such as calcium, magnesium and vitamins such as A and B12.
- Some people will say that red wine makes them feel terrible and this might be due to the effect of the tannins
- This could cause gut discomfort, skin discomfort, or things just feel generally “off”

## Nightshades and inflammation [53:15]

***Is there any validity to concerns about nightshades and inflammation?***

- This is a bit of a gray area
- Peter wouldn’t be surprised if there are some people that are very sensitive to nightshade vegetables, but there’s far less to this than is given in pop nutrition culture
- There are a few [animal studies](https://link.springer.com/article/10.1007/s10620-010-1158-9) that look at nightshades and talk about how they might induce intestinal inflammation due to their glycoalkaloid content
- So if you look at human studies, gut inflammation from glycoalkaloid consumption, it’s probably only in those with very high sensitivities or in people who are ingesting completely unripe tomatoes or green potatoes and things like that

List of nightshade veggies:

- Tomatoes
- Potatoes
- Peppers
- Eggplant
- Tomatillos
- Goji Berries
- Okra
- Tobacco
- Cayenne pepper
- Paprika
- The ones that most people are avoiding are tomatoes, eggplants, peppers and potatoes.
  - “*Those are the things that people are generally going out of their way to avoid. And I think it has less to do with the fact that they’re not growing in direct sunlight. It has more to do with these alkaloids that they seem to be high in*.”

> “It’s something that I think is certainly reasonable to try empirically. But understand that the human data for the removal of nightshades is virtually nonexistent.” —Peter Attia

## How important is it to eat organic foods? [56:00]

**Organic versus nonorganic**

*-Is it worth it if you can afford it?*

*-And is it also worth it if it might be a stretch?*

*-What’s the potential harm of eating non-organic and what’s the potential benefit of eating organic?*

**The real distinction is between organic and non-organic**

- This generally comes down to the exposure to pesticides
- Using the extreme example that we talked about at the outset, which is GMO, so genetically modified organisms
  - So genetically modified crops usually have genes inserted in them that make them really resistant to pesticides
  - And that allows the farmers to use greater amounts of pesticides because they’re not going to harm their crop
- Analogy: Pesticides are kind of like chemotherapy
  - Ultimately it’ll kill everything in sight.
  - So what would be amazing one day is if we’re giving patients chemotherapy, but we could first give them a gene therapy that puts in some resistance to the chemotherapy, and then you could just carpet bomb them with chemo and really kill the cancer, but not harm any of them
  - That’s kind of the way to think about this

***Are pesticides harmful?***

- Organic still often uses some pesticide residuals
- So one just has to be mindful of, *are you going with zero pesticide or next to zero pesticide?*
- This is an area where Peter hasn’t found a satisfactory answer so he can only tell you what he’s observed
- Peter says it’s pretty hard to make the case, based on the availability of data that glyphosate (the most common pesticide) is harmful
- Peter knows this is a VERY controversial statement, “but if you really just look at the data, it’s pretty hard to make that case”
- That doesn’t mean that pesticides aren’t toxic
- It means at the doses that they are used and in the doses at which they get to us, I just don’t see the toxicity data

Then the question becomes, *what’s the cautionary principle say?*

- The cautionary principle would say that you are better off without a toxin then with one (if you can afford it)

How Peter approaches this in his household:

- Given organic is more expensive, you could stratify the foods into ones worth the money and ones not worth the money
- For Peter, he buys organic berries
- But he does not buy organic bananas (b/c who really cares if there’s residual pesticide on the peeling?)

> “But if you can’t afford to buy organic, I don’t think I would let that discourage you from buying fruits and vegetables.” —Peter Attia

## How necessary is it to wash fruits and vegetables? [1:00:45]

***How important is it to wash fruits and veggies?***

- The first order thing you want to be mindful of when you’re washing food is to free it of the contaminants that may have come along the way
- E. coli, for example, is a real (though not huge) consideration
- At least a couple times a year there’s an outbreak of E. coli in spinach or lettuce or something
- So there is real value in washing your food

Being honest, Peter has no idea if what most people consider washing their fruits and vegetables is actually going to get rid of E. coli

- E.g., *Would rinsing an apple and wiping it with a towel really rid it of E. coli?*

In summary…

- It’s kind of a numbers game
- It’s a super, super low probability negative outcome.
- And most of us are going to go our entire lives without exposure to a deadly pathogen in our food.
- But if you can make the time to really wash the hell out of it, that would be great

## How does food preparation change the nutritional composition? [1:03:45]

**Food prep**

- The most obvious thing we do to food that might change the nutritional profile is cooking it (i.e., adding heat)
- it seems that **water soluble vitamins** (e.g., vitamin c) tend to actually degrade with heat
- If you are going to cook something that has vitamins C in it, you’re probably going to reduce the amount of vitamin C that reaches you
  - For example, eating apple pie probably won’t give you as much Vit C as eating apples

Conversely, there are four lipid soluble vitamins

- 1) Vitamin A
- 2) Vitamin D
- 3) Vitamin E
- 4) Vitamin K
- It turns out that heat can actually increase the bioavailability of these
- So you might actually see an increase absorption in some of those vitamins with some light cooking

## Considerations when eating canned and frozen food, and paying attention to processed food additives [1:04:45]

**Canned foods**

- Most foods that are canned are cooked first, then flash vacuumed and sealed for an almost infinite shelf life
- The cooking of those foods prior to canning is going to alter the nutritional profile in the same way that cooking foods yourself would (like mentioned above)
- What’s more important about canned foods is what gets added to it if it’s processed

**Processed foods**

Using the applesauce example:

- The apple sauce versus the whole apple — the issue is probably more that it’s being broken down and it’s easier for you to digest.
- And if your kid doesn’t want to eat apples, but eats applesauce, “I’d say take it as a win and have them eat the apple sauce, because that’s still 10 times better than drinking apple juice.”
- “And I think that’s still better than eating cookies or something like that. So I think it’s absolutely better to have something that is canned than to not have fruits and vegetables at all.”

## Supplementing vitamins and nutrients as an alternative to eating whole fruits and vegetables [1:06:15]

***Is it possible to get all the vitamins and nutrients you need without eating whole fruits and vegetables?***

- A bit dependent on other things
  - For instance, how do you reconcile the fact that the Inuit consumed no fruits and vegetables and yet had no scurvy, whereas the Limeys crossing the Atlantic Ocean, if they weren’t eating their limes, were going to get scurvy
    - Comes down to the role of glucose
    - in the absence of glucose, the amount of vitamin C that you need is very little to act as a co-factor, I think, that’s for Proline, the amino acid that’s necessary to maintain the integrity of the fibrous tissue that would prevent you from having scurvy
    - the Inuit we’re going to get that small amount of trace vitamin C from the blubber that they were actually eating or probably within the meat of the animal since it’s a water soluble vitamin
  - if you’re on a standard American diet, you actually do need vitamin C because you’ve got enough carbohydrate in your diet that you’re probably going to need a higher dose
  - we do need to make sure that we are somehow getting vitamin A, biotin, folate, vitamin C, vitamin D, E, calcium, magnesium potassium, etc.

The question becomes, *how do you get it? Do you get that all from your food? Or do you need a supplement along the way?*

- Peter has an issue with multivitamins knowing how unregulated the supplement industry is
- Supplement brands Peter likes:
  - [Pure Encapsulations](https://www.pureencapsulations.com/)
  - [Jarrow](https://jarrow.com/)
  - [Nature’s Way](https://www.naturesway.com/)
  - [Thorne](https://www.thorne.com/)
- If you look at those companies above, they’re less likely to make a multivitamin than to make specific products
- This gets to the second issue with multivitamins…
  - they generally provide not enough of the things that you probably need
  - They tend to provide too many things that I don’t think you really need
- Peter prefers a more targeted approach when using supplements to try to target these things

*How is Peter thinking about that in terms of knowing which ones you want to target, which you need more of, which you probably don’t need to supplement?*

- For example, people who don’t eat any meat products are generally going to be very deficient in B vitamins
  - It shows up in your blood work
  - you’ll have B vitamin levels that are very low and you’ll probably have homocysteine that’s very high as a result of that
- Magnesium is something that is generally deficient in people
  - once it gets to the point where you’re frequently cramping, I mean, you’re so deficient in magnesium
  - Peter will typically load people up with two grams of magnesium a day for a couple of weeks to get them over that hump
  - Then he’ll put them on to a maintenance dose of one gram of supplemental or 1000 milligram supplemental magnesium to follow
  - Peter also personally takes magnesium — “I find it’s just better for me to supplement it and have that be an addition to what I’m getting in my nutrition than just making sure I’m eating enough magnesium each day.”

## Green powder supplements [1:11:15]

**Peter’s thoughts on green powder supplements**

- Peter can really only speak to one called [Athletic Greens](https://athleticgreens.com/en) (disclosure: he’s an investor in the company)
- He can see exactly how “the sausage is made)
- He can speak to the quality of that product and the ingredients that go into it
- He can’t actually speak positively or negatively to the others

Peter’s approach with Athletic Greens

- He takes a scoop of Athletic Greens every day, regardless of what else he’s eating
- He knows that if he’s taking that AG, he’s getting exactly what he needs (probably a little bit more)
- “*There’s a lot of companies out there. I have to believe that not all of them are doing the work that Chris and his team are doing*.” says Peter

More about AG:

- AG is an expensive product, but it’s expensive because it costs an unbelievable amount to make
- And that’s part of the reason you have to refrigerate it after you open a packet
- If you’re consuming a product that doesn’t need to be refrigerated once it’s been exposed to air, it’s probably not a very high quality
  - If you don’t refrigerate AG, you’re increasing the risk of oxidation and you’re increasing the risk of spoilage

*Does Peter ever take more than one scoop if he hasn’t had fruits and vegetables in multiple days?*

- I have no basis to say that there’s any rationale for what I’m about to say other than it’s just what I do
- He will do a scoop in the morning and a scoop in the evening if I’m on a hunting trip or something where there’s super high demands on my output
- So wake up first thing in the morning, a scoop and water. And then after dinner, a scoop in water
  - in part it’s because you’re not eating as many vegetables on hunting trips
  - then, frankly, there’s just, I want to be at my absolute best, I suppose. So it’s worth the extra headache of trying to remember to take that second dose

*Get energy from AG?*

- There are some people who feel quite activated by AG — it gives them a little bit of an energy kick and that could be because of the B vitamins
- If you’re very sensitive to the B vitamins in there, then you might not be able to go to sleep if you take too much

## Important takeaways [1:16:00]

**Takeaways**

First, don’t confuse a nutritional intervention that might be more directed towards improving your health, getting you out of a valley with something that might be ideal for helping you maintain altitude

- Analogy: Airplane flight
  - When an airplane is taking off trying to go from ground to 28,000 feet, it has totally different flight characteristics than what it’s doing in flight
  - That’s totally different from the flight characteristics of when it’s landing
  - There are three totally different phases and each of them is essential and quite different.
- It’s similar to say that it might be very different what you need to do to go from being in the valley of death nutritionally and health wise, to being in an optimal state versus what you might want to do to stay in that state

Secondly, understand that we don’t have really great data when it comes to nutrition on these macro questions that everybody understandably wants to have insights to

- Therefore on some level you have to be somewhat empirical
- You want to combine empiricism with the best of the available information that we have and try to not be terribly dogmatic about it
- Otherwise you end up spending too much time thinking about this at the expense of thinking about things that are, in my opinion, more important

§

## Selected Links / Related Material

**Formula 1 show on Netflix**: [​​Formula 1: Drive to Survive](https://www.netflix.com/title/80204890) **|** (netflix.com) [2:15]

**Episode of The Drive with David Allison**: [#197 – The science of obesity & how to improve nutritional epidemiology | David Allison, Ph.D.](https://peterattiamd.com/davidallison/) | Peter Attia (peterattiamd.com) [5:30]

**Reexamination of the data from the Minnesota Coronary Experiment that completed in 1973 makes a “*****very compelling case that omega 6 polyunsaturated fats as substituted for saturated fats could actually be viewed as harmful*****”**: [Re-evaluation of the traditional diet-heart hypothesis: analysis of recovered data from Minnesota Coronary Experiment (1968-73)](https://www.bmj.com/content/353/bmj.i1246) (Ramsden et al., 2016) [10:30]

**Episode of The Drive with Rick Johnson**: [link](https://peterattiamd.com/rickjohnson2/) | Peter Attia (peterattiamd.com) [21:45]

**Meal replacement called Soylent**: [Soylent](https://soylent.com/) [28:00]

**Episode of The Drive with Gerald Shulman**: [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) | Peter Attia (peterattiamd.com) [35:00]

**Episode of The Drive with Steven Dell**: [link](https://peterattiamd.com/stevendell/) [42:45]

**Recent study with some interesting data on the effect of cocoa flavanoids as a supplement with respect to cardiovascular disease**: [Effect of cocoa flavanol supplementation for the prevention of cardiovascular disease events: the COcoa Supplement and Multivitamin Outcomes Study (COSMOS) randomized clinical trial](https://pubmed.ncbi.nlm.nih.gov/35294962/) (Sesso et al., 2022) [46:00]

**A nutritional supplement using cocoa flavonoids**: [CocoaVia](https://www.cocoavia.com/) [46:15]

**Some data about how quercetin plays a role in tamping down senescent cells**: [Senolytic effects of quercetin in an in vitro model of pre-adipocytes and adipocytes induced senescence](https://www.nature.com/articles/s41598-021-02544-0) (Zoico et al., 2021) [48:25]

**AMA episode of The Drive looking at NR, NMN versus Metformin or Rapamycin**: [#207 – AMA #35: “Anti-Aging” Drugs — NAD+, metformin, & rapamycin](https://peterattiamd.com/ama35/) | Peter Attia (peterattiamd.com) [49:00]

**There’s some “weak” evidence that certain phytochemicals have some benefits**: [49:30]

- [The Immunomodulatory and Anti-Inflammatory Role of Polyphenols](https://www.mdpi.com/2072-6643/10/11/1618/htm) (Yahfoufi et al., 2018)
- [Therapeutic Potential of Volatile Terpenes and Terpenoids from Forests for Inflammatory Diseases](https://www.mdpi.com/1422-0067/21/6/2187/htm) (Kim et al., 2020)
- [Oxidative Stress and Inflammation: What Polyphenols Can Do for Us?](https://www.hindawi.com/journals/omcl/2016/7432797/) (Hussain et al., 2016)

**Episode of The Drive with Layne Norton**: [#163 – Layne Norton, Ph.D.: Building muscle, losing fat, and the importance of resistance training](https://peterattiamd.com/laynenorton/) | Peter Attia (peterattiamd.com) [50:45]

**Supplement Brands Peter likes**: [1:09:00]

- [Pure Encapsulations](https://www.pureencapsulations.com/)
- [Jarrow](https://jarrow.com/)
- [Nature’s Way](https://www.naturesway.com/)
- [Thorne](https://www.thorne.com/)

**Green powder discussed (disclosure: Peter is an investor)**: [Athletic Greens](https://athleticgreens.com/en) [1:11:30]

§

## People Mentioned

- [David Allison](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=allison) [5:30]
- [Kevin Hall](https://twitter.com/KevinH_PhD) [9:15]
- [Rudy Leibel](https://www.ihn.cuimc.columbia.edu/profile/rudolph-l-leibel-md) [10:00]
- Eric Robinson [10:00]
- [Rick Johnson](https://som.ucdenver.edu/Profiles/Faculty/Profile/9426) [21:45]
- [Gerald Shulman](https://medicine.yale.edu/profile/gerald_shulman/) [35:00]
- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) [38:15]
- [Steven Dell](https://www.dellvision.com/eye-doctor-austin/steven-j-dell-md/) [42:45]
- [Layne Norton](https://twitter.com/BioLayne) [50:45]
- [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) [55:30]
- [Chris Ashenden](https://www.linkedin.com/in/chris-ashenden-35652013/) [1:11:30]

§