# #192 – COVID Part 2: Masks, long COVID, boosters, mandates, treatments, and more

**Source:** [https://peterattiamd.com/covid-part2/](https://peterattiamd.com/covid-part2/)

---

##### Check out more of my recent content on COVID:

- *(January 3, 2022)* [COVID Part 1: Current state of affairs, Omicron, and a search for the end game](/covid-19-current-state-omicron/)
- *(January 23, 2022)* [Why I’m for COVID vaccines, but against vaccine mandates.](/why-im-for-covid-vaccines-but-against-vaccine-mandates/)
- *(January 24, 2022)* [COVID Part 2: Masks, long COVID, boosters, mandates, treatments, and more](/covid-part2/)
- *(January 29, 2022)* [A follow-up to my article on vaccine mandates](/a-follow-up-to-my-article-on-vaccine-mandates/)

This episode is a follow-up to our [recent COVID-19 podcast](/covid-19-current-state-omicron/) with Drs. Marty Makary and Zubin Damania (aka ZDoggMD). Here, we address many of the listener questions we received about our original discussion. In addition to Marty and ZDoggMD, we are also joined by Dr. Monica Gandhi, an infectious disease specialist and Professor of Medicine at the University of California, San Francisco. In this episode, we talk about new data on Omicron, long COVID, masks, kids and schools, vaccine mandates, policy questions, and treatments. We also discuss some of the most prevalent misinformation and spend time talking about claims made by Robert Malone. We end with a conversation about our exit strategy.

*\*Please note: we recorded this episode on January 17, 2022, and in an effort to get it out as soon as possible, this won’t have full show notes or a video. Additionally, Monica was only able to join us for the first section of the podcast, so you’ll hear her drop off partway through.*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/covid-part2/the_Drive_public.png)

Play

#192 - COVID Part 2: Masks, long COVID, boosters, mandates, treatments, and more

#192 - COVID Part 2: Masks, long COVID, boosters, mandates, treatments, and more

1x15s30s

0:002:52:48

## We discuss:

- Severity of infection from Omicron—reviewing the data [5:15];
- Factors contributing to the relative mildness of Omicron infections [8:30];
- Is SARS-CoV-2 evolving to cause less severe disease? [13:00];
- Potential of Covaxin—an inactivated virus-based COVID-19 vaccine [17:45];
- How B cells and T cells work together to defend against viruses [22:00];
- Comparing the COVID-19 vaccines, and the rationale for the time between doses  [25:30];
- Reviewing the purpose and effectiveness of boosters for reducing severity and transmission [32:30];
- Debating vaccine mandates, and putting COVID’s mortality risk in perspective [41:00];
- Why the topic of COVID has become so polarized [1:03:15];
- Reviewing the data on masks for protecting oneself and protecting others [1:06:30];
- The inconsistent logic used for mask mandates [1:16:00];
- Long COVID and the potential for vaccines to reduce risk [1:21:45];
- Risks for children and policies for schools [1:27:30];
- Reviewing the outcomes from Sweden, where the government didn’t impose lockdowns [1:31:00];
- Draconian measures implemented in Canada [1:38:15];
- Antiviral treatments for COVID and a common-sense approach [1:42:15];
- Importance of ending tribalism and having rational discussions with humility [1:47:30];
- Treating infection with monoclonal antibodies and convalescent sera [2:01:45];
- Reviewing claims made by the controversial Dr. Robert Malone [2:11:15];
- A potential exit strategy from the current situation [2:30:30];
- Change needed at the NIH [2:40:00];
- More.

§

## Show Notes

**Pre-show notes:**

- A couple of weeks ago Peter, Dr. Marty Makary, and Dr. Zubin Damania (aka ZDoggMD) sat down and had a relatively informal discussion of the COVID-19
  - [Podcast #189 – COVID-19: Current state of affairs, Omicron, and a search for the end game](https://peterattiamd.com/covid-19-current-state-omicron/) (January 3, 2022)
  - Different from our usual podcasts, this is a discussion among a group of us
  - We have tried to call out what is fact and what is opinion
    - We have a healthy mix of both
  - The format seemed to resonate a lot with people, and the follow- up was surprising
  - Peter thought it would be a one-and-done episode as they put to rest as many of the misconceptions as they could
  - It may be helpful to go back and listen to the earlier episode linked above if you didn’t hear it
- We are back with Marty and ZDoggMD, and this time Dr. Monica Gandhi joins us
- We will get into the newest data on Omicron
- We’ll talk about how viruses evolve over time
- Monica gives a great explanation of what B cells and T cells do, and how antibodies work
  - She explains the implications for different types of immunity: vaccine-induced and natural immunity
- We’ll talk about the ideal timing for vaccines and number of doses
  - We’ll talk about how natural immunity plays into this and if a booster is needed
- We’ll discuss some side effects of current vaccines
- We’ll get into the controversial topics of: vaccine mandates, masking, the lock-down in Canada, kids in school, Sweden’s approach to COVID, Joe Rogan’s podcast with Robert Malone
  - Podcast, December 2021 – [#1757 – Dr. Robert Malone, MD](https://open.spotify.com/episode/3SCsueX2bZdbEzRtKOCEyT)
  - ZDoggMD does a pretty good point-by-point analysis of where he thinks Malone is off the mark and where he is saying something valid
- We spend a lot of time discussing the fact versus fear approach to COVID
  - We’re still very much in a fear approach and it’s not clear why this is
- We end this conversation again talking about the future and what the exit strategy is
  - We are in an endemic; this is no longer a pandemic
  - We should have strategies geared toward an endemic now

## Severity of infection from Omicron—reviewing the data [5:15]

- Preprint in *medRxiv* Jan. 11, 2022 – [Clinical outcomes among patients infected with Omicron (B.1.1.529) SARS-CoV-2 variant in southern California](https://www.medrxiv.org/content/10.1101/2022.01.11.22269045v1)
- They found 52,000 cases of Omicron, none required mechanical ventilation
  - And remember, 52,000 documented means there are 4-5 cases out there in the community for every 1 that is picked-up with testing
  - Roughly half of infections are asymptomatic and a lot of people have a tough time getting access to testing
  - So we’re really looking at a population of, say, a quarter million people with Omicron and nobody required a ventilator
- There was 1 death in this group (not in the ICU or intubated)
- Infection with the Omicron variant was determined using PCR diagnosis where S gene dropout was observed
- There was a net total of 154 people who were hospitalized out of, say, a quarter million infected with Omicron
- Of those hospitalized, 83% were there in the hospital for less than 48 hours
  - Remember way back about 2 months ago, this is exactly what the South African doctors observed early on
  - They noticed people were in the hospital about two days instead of eight days, and they proclaimed to the world this is a mild infection
- According to the most recent CDC numbers, 98.3% of new cases of COVID in the United States are Omicron
  - On December 10th, it hit 73%
  - Now, we’re at 98.3%
  - So we’re dealing with a different virus
- People who are still in the hospital are those who came in with Delta
  - Unvaccinated people who got Delta
  - And remember, people stay in the hospital a long time especially right now and it’s very difficult to discharge a COVID positive patient to a skilled facility or rehab so that’s inflating the numbers a little bit
  - Hospitals are truly strained, but it’s really those who had Delta
- If we look at the future, Omicron promises to be a mild virus based on all of this data

## Factors contributing to the relative mildness of Omicron infections [8:30]

**Current numbers of people in the hospital with Omicron**

- Marty just looked this up, NYU, for example, reported 53% are not there for COVID, but they are COVID positive
  - These are incidental COVID admissions
- In Jackson Memorial in Florida, 65% are incidental COVID positive cases
- Perhaps 50% to 60% of the COVID hospitalizations are incidental
- This depends on how highly vaccinated the region is
- The numbers are even higher out in California for people with COVID in their noses because so many people are tested
  - So LA County reported 67%
  - This was closest to what we saw in South Africa during the Omicron surge which was 63%.
  - And it wasn’t that South Africa was a highly vaccinated region; it was about a 25% vaccinated region
    - Instead, a seroprevalence study in SARS-CoV-2 in South Africa that showed 79% of adults had SARS-CoV-2 antibody
    - So think of South Africa, between natural immunity and vaccines, as likely having the same degree of immunity as California
  - So the higher the vaccinated region, the higher the incidental rate is

**Study in South Africa just released aims to dissect the contribution of immunity to outcomes with Omicron versus the contribution a milder variant**

- Adding to this, a couple Omicron studies came out yesterday verifying this
- One from South Africa was really well-documented
  - It tried to tease out the reason for better outcomes with Omicron, looking at the contribution of immunity versus the more milder aspect of Omicron
  - This focused on the 4th wave in South Africa
  - Preprint published on *medRxiv* January 12, 2022, [Outcomes of laboratory-confirmed SARS-CoV-2 infection in the Omicron-driven fourth wave compared with previous waves in the Western Cape Province, South Africa](https://www.medrxiv.org/content/10.1101/2022.01.12.22269148v1.full-text)
  - This compared outcomes in the 4th wave to the prior 3 waves
  - Essentially what this study showed was that absolutely immunity is contributing to why in December 2021, January 2022, we’re having a better outcome with the latest variant

“*The contribution of immunity, both natural immunity and vaccine induced, estimated vaccination probably led to a 0.24 hazards ratio of a severe outcome*” – Monica Gandhi

- A [hazard ratio](https://en.wikipedia.org/wiki/Hazard_ratio) compares the risk in 2 groups
  - A [hazard ratio of 1](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/hazard-ratio) means there is not difference between the 2 groups
  - A hazard ratio of more than 1 or less than 1 means outcomes were better in 1 of the groups
- Here this study is looking at the risk of severe outcomes from COVID infection in people who have some form of immunity (from vaccination or recovery from infection) compared to people without immunity
  - They conclude that immunity provided protection from severe COVID outcomes with a hazard ratio of 0.24
  - The hazard ratio here divides the occurrence of severe COVID outcomes in people with immunity by the occurrence of severe COVID outcomes in people without immunity
- As doctors in South Africa kept saying the Omicron variant is more mild, the fundamental question became, “*Okay, is Omicron more mild because we have so much immunity in the population at this point, January 2022 now, that our T cells and B cells are attacking that SARS-CoV-2 variant?*”
- It takes a while for the B cells to make antibodies; one may not have antibodies right away
- Maybe if one just got boosted, they may have antibodies right away if they’re older
- But say someone has been vaccinated or has natural infection
  - They now have T cells; and their B cells produce antibodies
  - This attacks that virus; it brings down the viral load quickly
  - This will make it less infectious and it helps the person do well with the virus
- And so, immunity, of course, will help one do well
- This is what probably what happened in 1918 when the world was transitioning from pandemic to endemic
  - There was a lot of immunity to influenza in the world
- The next question is also, is Omicron less virulent inherently than the other strains that we’ve had so far, the other variants we’ve had so far?
  - Yes, it seems to be not just based on the 6 laboratory studies, including 2 in [*ex vivo*](https://en.wikipedia.org/wiki/Ex_vivo) lung transplants
    - So this is human lung tissue
  - And then also animal studies that show it can’t infect lung cells very well
  - 6  studies now
- What the South Africa study showed us was very good analysis distinguishing between immunity making it more mild and also having fewer less virulent,

> “*They estimated it’s 25% less virulent than Delta above and beyond immunity*” – Monica Gandhi

- So it’s not just our increasing immunity in the population that’s making Omicron more mild, but it’s something to do with the virus itself likely, that it can’t infect lung cells well

## Is SARS-CoV-2 evolving to cause less severe disease? [13:00]

- Less severe outcomes observed in children under 5 infected with Omicron versus Delta
  - Preprint available on *medRxiv* and PMC January 2, 2022, [Comparison of outcomes from COVID infection in pediatric and adult patients before and after the emergence of Omicron](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8750707/)

**Do viruses cause milder disease as they become endemic?**

- Evolution of virus is accompanied with lessening of disease severity
- Will SARS-CoV-2 become a virus that causes disease with severity somewhere between common-cold-coronaviruses and influenza (that causes the flu)?
- Monica notes this makes sense evolutionarily and that’s been the pattern in history
- She also notes that if a more virulent strain arises, we have the protection of immunity across the entire virus from B cells, T cells, antibodies
- A lot of people have seen Omicron
  - Probably 50% of people in Europe
  - It’s estimated that 25% of Americans (probably more) have seen Omicron
- Infection with Omicron results in T cells and B cells that will fight that new variant in the future, even if it’s more virulent

> “*Both the FDA chief and the NIH chief have said we’re all going to see Omicron”* – Monica Gandhi

**Break-through infections with Omicron provide broad immunity to other variants**

- Preprint available at *medRxiv* January 13, 2022, [Immunity in Omicron SARS-CoV-2 breakthrough COVID-19 in vaccinated adults](https://www.medrxiv.org/content/10.1101/2022.01.13.22269213v1.full-text)
- This study shows that when someone gets a natural Omicron infection on top of their vaccines, they form broadly neutralizing antibodies against all the variants (Alpha, Beta, Gamma, Delta)
- Importantly, one forms T cells and B cells that work across all the variants
- Remember, the vaccines we have in this country only expose us to the spike protein of the virus, so just one piece of the virus as opposed to the whole virus

## Potential of Covaxin—an inactivated virus-based COVID-19 vaccine [17:45]

**Advantages of a whole-agent vaccine**

- Something Monica has been thinking about lately is why we don’t have [Covaxin](https://en.wikipedia.org/wiki/Covaxin) in this country
- Covaxin filed for an EUA 73 days ago with the FDA

> “*If you don’t see Omicron, I wish the booster could be Covaxin*” – Monica Gandhi

- ZDoggMD asks if there is a difference in mucosal antibody immunity between the mRNA vaccines (specific only to the spike protein) and Covaxin (an inactivated, whole virus)
- Monica explains that when someone is exposed to the virus, they develop [IgA antibodies](https://en.wikipedia.org/wiki/Antibody#Classes) in their nose
  - These go down with time
- There’s a great interest in mucosal, nasal vaccines to help decrease transmission
- But it is true that if one gets Covaxin or gets exposure to the actual virus, they develop IgA against multiple parts of the virus
- With the mRNA vaccines, one is developing IgA against only the spike protein

**Comparing the vaccines**

- Thinking back to the early days of the vaccine, Pfizer was approved with an EUA on November 9th and then Moderna was November 16th
- And then J&J and AstraZeneca followed shortly thereafter, single dose
- Peter asks if the absolute risk reduction was greater with J&J than both Pfizer and Moderna
- Both Johnson & Johnson and AstraZeneca are adenovirus DNA vector vaccines
  - They show a different part of the spike protein, which is why mixing them exposes one to more of the spike protein antigen
- But what Monica thinks happens with the DNA antiviral vectors is they produced a more robust T cell response than the mRNA vaccines, and T cells are the long-lasting friends
  - Remember, those who’ve survived SARS-CoV the first one
    - SARS from 2003, late 2002 to early 2003
  - There are people 17 years later that they have strong T cell immunity against SARS-CoV-1
- T cells are the long-lasting arm in the immune system
- Antibodies always come down
  - If someone had antibodies for every cold they’ve ever had in their body, they couldn’t move because the blood would be so thick with antibodies
- AstraZeneca seems to produce and Johnson & Johnson stronger T cells response

## How B cells and T cells work together to defend against viruses [22:00]

- Peter asks why is that the wrong metric to exclusively focus on antibody levels as opposed to understanding how the T cells work?
- What’s the difference between these B cells and T cells and how they actually kill viruses?
- Monica explains that [T cells](https://en.wikipedia.org/wiki/T_cell) are actually the main arm of the immune system that fight viruses
  - So for example, she’s an HIV doctor
  - So as T cells go down, people are susceptible to very severe viral infections
  - T cells are cells that last for a long time; they’re called [cellular memory](https://en.wikipedia.org/wiki/Immunological_memory)
- And then what [B cells](https://en.wikipedia.org/wiki/B_cell) do is they become the recipe book or the template to produce more antibodies, but they have to be aided by T cells to do so
- [Antibodies](https://en.wikipedia.org/wiki/Antibody), which are pieces of protein, they will come down with time
  - They will come down even after a booster, say, 10 weeks or so
- B cells are known to develop after vaccination
  - In studies they’ve biopsied bone marrows from people who’ve had natural infection, lymph nodes from people who had the RNA vaccines
  - It has been observed that people produce strong B cells in what are called [germinal centers](https://en.wikipedia.org/wiki/Germinal_center)
  - The B cells will, if they see the virus again, aided by T cells will produce antibodies directed against that SARS-CoV-2 when they see it in the future
  - And not only will they produce antibodies, but they will actually adapt those antibodies to the variant they see
  - If they see Delta, they’ll make Delta-specific antibodies, Omicron, Omicron-specific antibodies, Zeta, Zeta-specific antibodies because that’s what adaptive immunity is
  - They vary the recipe based on the conditions; that’s what [adaptive immunity means](https://en.wikipedia.org/wiki/Clonal_selection)
  - So B cells will produce antibodies against the variant they see aided by T cells
- And then T cells line the whole virus and directly kill the virus itself

> “*T cells and B cells, which are formed by the vaccines and natural immunity, will last a long time and will enable us to have ongoing immunity to the virus in the future, even different variants*” – Monica Gandhi

- B cells could last 90 years
  - People who have gotten influenza in 1918 and then they found these 90-year-old, 100-year-old people, they looked at their B cells and they said, “*Oh, you actually can produce antibodies directed against the influenza strain from 1918, 90 years later.*”

## Comparing the COVID-19 vaccines, and the rationale for the time between doses  [25:30]

- In the US, only Pfizer is off EUA (emergency use authorization); it’s the only vaccine to have full approval
- [Covaxin](https://en.wikipedia.org/wiki/Covaxin) is the inactivated, whole-virus vaccine developed by Bharat Biotech in India
- [Covovax](https://en.wikipedia.org/wiki/Novavax_COVID-19_vaccine) is a protein subunit COVID-19 vaccine developed by Novavax Inc
- ZDoggMD notes that the CDC has indicated a preference for the mRNA vaccines to J&J
- Paul Offit and others have speculated that J&J really always should have been a 2-dose vaccine
  - As a single dose, it had a lot of promise initially, but it’s looking more like it should have been a double dose vaccine
  - And then, there is the vaccine-induced thrombotic thrombocytopenia issue which seems to be a class effect with the adenovirus vector vaccines because AstraZeneca has it as well
    - Monica adds that Sputnik V isanother adenovirus DNA vector vaccine; they all have this rare side effect

![](https://peterattiamd.com/wp-content/uploads/2022/01/f1-covid2.png)

**Figure 1. 9 COVID vaccines compared.**  Image credit: [*BBC*](https://www.bbc.com/news/world-asia-india-55748124)

**Why use of the J&J vaccine paused while use of Moderna was not?** [26:30]

- ZDoggMD thinks this comes down to severity
- The outcomes of people who get vaccine-induced thrombotic thrombocytopenia can be very bad to fatal
  - It’s very rare, but it is catastrophic if it happens
- Whereas with myocarditis, at least from the early series that we have, is generally reversible
  - Although it requires hospitalization and is still terrifying for parents and children, this is less of a catastrophic issue
- The interesting question is what is worse for generating myocarditis— natural coronavirus infection or the vaccine?
  - This is where data sets seem to disagree and how one interprets them
- Marty notes, those studies did a head-to-head comparison and found that the rates of myocarditis after vaccination were higher, particularly with Moderna
  - In parts of Europe they’ve restricted Moderna in anyone under age 30
  - This hasn’t been discussed in the US
- There’s also this interesting idea— the myocarditis from vaccination may be different than the myocarditis from the infection itself
  - There may be more delayed contrast uptake in the heart that they’re noticing in the studies of the myocarditis from vaccination
  - So there’s a feeling among cardiologists that it’s not the exact same apples to apples myocarditis
- Monica also notes the difference in the amount of RNA the vaccines contain
  - Moderna has 100 micrograms, Pfizer’s 30 micrograms
  - So that dose difference probably explains why myocarditis could be more seen with the Moderna vaccine
    - It’s literally a higher dose
- She thinks the best study on this is from Canada
  - That showed that the risk of myocarditis after the second dose is more with higher dose Moderna vaccine
  - And also more if there is a shorter period between the 2 doses
    - This is why spacing the doses has been such a strategy in Canada of 8 weeks or even longer between doses

**What is the rationale behind the time between vaccine doses?**

- Peter asks about the immunologic rationale for why the mRNA vaccines were dosed at four weeks apart
- Monica thinks it was simply expediency because the trials were conducted in a hurry
  - We were in the middle of a pandemic
  - So they tested Pfizer 3 weeks apart
  - And Moderna 4 weeks apart

**What time between vaccine doses would provide the most durable immune response?**

- Dr. Stanley Plotkin wrote a *Clinical Infectious Disease* article in January
- He was saying we need to space them out longer for 2 reasons
  - 1) One was to save more lives because if there is a limited supply, we want to save more lives by giving people just 1 dose (and then give them the second dose later)
    - 1 dose will provide some T cell immunity
  - 2) And then the second was he said that in any field of vaccinology (and now this has been shown in a *Cell* paper) if you give longer time between doses, you get a better response
    - Published October 15, 2021, [Immunogenicity of standard and extended dosing intervals of BNT162b2 mRNA vaccine](https://www.cell.com/cell/fulltext/S0092-8674(21)01221-6)
    - Not just increased antibody responses, but fundamentally what we were talking about is we want to develop cellular memory
    - There’s better T cell responses if you space them out, the doses, by 8 weeks or so
- Peter asks what would be the ideal time to give a booster to somebody who has 2 shots of Moderna or Pfizer
  - Nobody would be 1 year out from their second show now because these things just became available
  - Is giving a booster in less than a year the optimal way to boost long-term immunity?
  - Would we be better off boosting less frequently?
- Monica explains, to extrapolate on the 3-dose vaccines from the hepatitis B vaccine and the human papilloma virus vaccine— the longer the time between the 2nd and 3rd doses, the better
- Dr. Plotkin talks about this in the *CID* article; what happened here with the booster is that we had a lot of high transmission with Omicron, and then the idea was, “*Oh, if we give the booster, maybe we can bring transmission down*”
  - That’s all Monica can see as to why there were widespread booster recommendations as opposed to more selected booster recommendations for those who were more at risk for severe disease
  - She thinks it was an attempt to increase antibodies to bring transmission down

## Reviewing the purpose and effectiveness of boosters for reducing severity and transmission [32:30]

- Peter asks if there is data on how the vaccine reduces transmission
- Monica explains that vaccines will increase antibodies and this could reduce transmission
- There was an Omicron paper studying transmission within households, and given a boost did decrease transmission
  - Preprint on *medRxiv* December 27, 2021, [SARS-CoV-2 Omicron VOC Transmission in Danish Households](https://www.medrxiv.org/content/10.1101/2021.12.27.21268278v1.full-text)
- Monica notes, if the patient benefits from a booster to reduce severe disease, then that’s when we would give a booster in how we usually do infectious disease
  - Not for this purpose of reducing transmission
  - Later if we get a different variant and virus goes up in the community she doesn’t think we will give a booster to try and decrease transmission
- Peter asks how long this effect lasts
- The UK study suggests 10 weeks
  - Published in *Nature Medicine* January 14, 2022, [Effectiveness of COVID-19 booster vaccines against covid-19 related symptoms, hospitalization and death in England](https://www.nature.com/articles/s41591-022-01699-1)
  - The booster makes the antibodies go up and then come right back down after 10 weeks
- It’s just never been done that we give boosters to decrease transmission
- We usually give boosters in a risk versus benefit analysis for the patients
- We want to make sure it’s safe for the patient and then also we want to make sure that it does something beneficial for the patient
  - Which in this case would be keeping them out of the hospital
  - This is important for older people, immunocompromised people, people who have medical conditions, maybe everyone over 40

***Why are universities requiring students to get a 3rd dose?***

- Peter comments, “*if we were to speculate based on the policies that are in place of providing boosters to healthy college kids in an effort to prevent transmission, the only logically consistent thing to do would be to make sure college kids get boosters every 10 weeks for the rest of their lives*”
- Monica replies that it is  profoundly not recognized is how well the vaccines work for the older adult who is teaching the student
  - Even 2 doses, certainly 3 doses if they’re older
  - She asks Marty and ZDoggMD if they think the healthcare worker study in the *New England Journal of Medicine* from Israel showed anyone over 50 really benefits from a third dose, even in reducing severe disease
    - Published in *Lancet* December 4, 2021, [Effectiveness of a third dose of the BNT162b2 mRNA COVID-19 vaccine for preventing severe outcomes in Israel: an observational study](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(21)02249-2/fulltext)
- The CDC showed us just in a study two weeks ago that even with the 2-dose vaccines, the chance of dying from COVID (across the entire swath of the population) was 0. 00003
  - There were specific risk groups that were at risk for severe outcomes; they were older people over 75 with multiple comorbidities, 4 comorbidities
    - These patients should be boosted, maybe even get a 4th booster; and they should be masking themselves for protection
- Monica notes, putting all this together means that we have underestimated those college students, if they’re around vaccinated staff members and teachers, those vaccinated staff members and teachers are doing great
- The vaccines are working well
- What we were so scared of was severe disease from COVID

**Are there any bad outcomes from a vaccine booster (3rd dose))?**

- What is the rationale for not boosting with the same antigen again and again?
- Monica replies, the term is [original antigenic sin](https://en.wikipedia.org/wiki/Original_antigenic_sin)
  - When the immune system keeps seeing the same piece of protein
  - The adaptive immunity allows one to produce trained immunity to whatever virus is seen in front of them
  - We don’t want to train the immune system to respond to the ancestral strain
- Marty notes that even the European CDC basically said specifically that repeated boosters could cause “*problems with the immune system*”

**Anecdotes of autoimmunity**

- Marty and his colleagues have seen cases that raise questions about the onset of autoimmune disease, either immediately after the second dose or after a very mild infection in somebody fully vaccinated
- Maybe the immune system was revved up and caused juvenile diabetes in an adult
  - How often do you see that on day two of a very mild infection?
- Now, the risk benefit still favors vaccination
- This is not an argument to say, “*Hold off on vaccines because there’s concern*”
- This is an argument to say, “*Only give boosters if there’s a clinical benefit*”

> “*The frustrating thing is, as you alluded to, Peter, if we would’ve spaced out these doses, we might not even be talking about boosters”* – Marty Makary

**Infection with Omicron is the best booster** [39:45]

- ZDoggMD notes that the best booster of all is infection with Omicron; this would be true of any natural infection
  - Infection elicits profound T and B cell responses; broad neutralizing antibodies across the whole virus

> “That is the best booster of all, unless you got a Covaxin booster” – ZDoggMD

- When these B-cells are retriggered, you get another process of what they call [somatic hypermutation](https://en.wikipedia.org/wiki/Somatic_hypermutation)
  - The B-cells are constantly undergoing mutational process to diversify

> “*The worded adaptive truly means you adapt your own immune system to what you see*” – Monica Gandhi

## Debating vaccine mandates, and putting COVID’s mortality risk in perspective [41:00]

- Peter asks what everyone thinks about vaccine mandates; he’s looking for a diversity of opinion
- Monica replies that when she and ZDoggMD had this discussion previously, she favored mandates and he did not
  - One argument is that the vaccines reduce transmission
    - This argument has become weaker
  - Then each successive variant evades antibodies more (even though the T cells and B cells are intact)
- Monica supports mandates because she works in a hospital and there is no doubt that the people in the ICU and the people who are sick are unvaccinated adults
  - If our entire purpose of a lot of what we did throughout this pandemic was to save hospitals, then not having hospitals have unvaccinated people when they could have gotten the vaccine, allows us to work on other aspects of hospitalization

> “*I think the vaccinated are more concerned about thinking that their vaccines don’t work than the unvaccinated*” – Monica Gandhi

- Those who are  vaccinated are more concerned about COVID than those who are unvaccinated
- People are fearful
- People don’t trust vaccines— this is a failure of public health messaging

**People have difficulty estimating risk** [43:00]

- Peter is reminded of an interesting anecdote; he recently had to mediate a family conflict about a son who didn’t want to get vaccinated
- He listened and asked a simple question of the father, “*What do you believe is the risk that your son will be hospitalized or die if he contracts COVID in an unvaccinated state?*”
  - His son was 38 and is very healthy
  - He said 50%
  - Now Peter understood why the father was so distraught over this, he literally thought his child was making a decision that put them at a 50% risk of death
- He showed him the data
  - There was a 10-fold difference in the actual risk of hospitalization of death without the vaccine, a 1-log difference

**What are the facts on risk?**

- Monica notes COVID is a very interesting and different virus in the sense that young children are very low risk for severe disease
  - This isn’t true of, for example, influenza, which affects young children and the extremes of age (elderly)
- Somehow people are not aware of the epidemiology of COVID
- Monica blames public health officials also for not clearly laying it out, how much more at risk one is when they’re older
- She also blames public health officials for not even putting out this data of how vaccines really make one almost immune to the severe outcomes
  - Unless someone is in specific risk groups in which case they are vulnerable and must be protected

**Emotional resistance to mandates**

- ZDoggMD notes the emotional response to mandates
- If he could wave a magic wand and have everyone eligible to be vaccinated at a minimal level that prevents severe disease, he would do it in an instant because he knows this would reduce suffering
- He sees the emotional reaction to mandates and the psychological reactance to a government that nobody trusts and a public health apparatus that people don’t trust
- People don’t want to be told what to do
- This is why he is nervous about the public health policy tool of mandates
  - He’s worried it will backfire in a longer emotional way in a segment of the population that could be reached otherwise with education
  - The Swedes don’t mandate anything; they trust their government
  - Now the questions is how to wield policy to make that happen

**Putting risk in context** [48:45]

- Consider deaths from any of the top causes of death as a fraction of COVID deaths
  - Divide the number of deaths from any cause by the number of deaths from COVID

![](https://peterattiamd.com/wp-content/uploads/2022/01/f2-covid2.png)

**Figure 2. Specific death rates as a multiple of COVID deaths.**  Data from: [NSC](https://injuryfacts.nsc.org/motor-vehicle/historical-fatality-trends/deaths-by-age-group/) & [CDC](https://www.cdc.gov/nchs/nvss/vsrr/mortality-dashboard.htm#)

- Marty finds this comparison so compelling
  - What this graph shows is that deaths from each of these independently— motor vehicle accidents, suicide, homicide, drug overdoses, just blow COVID out of the water
  - These are the major public health threats facing young people
  - It just shows how we have had massive blind spots during this entire pandemic
- People don’t just die of COVID; they die of depression and poverty and hopelessness and alcohol and stress and deferred cancer care and drug abuse
  - That is the broader perspective
  - That’s the context Marty thinks we’ve lost

- Remember when Joe Rogan had Sanjay Gupta on his podcast
  - [#1718 – Dr. Sanjay Gupta](https://open.spotify.com/episode/6rAgS1KiUvLRNP4HfUePpA) (October 2021)
  - Rogan points out the data on young unvaccinated children and the hospitalizations are significantly clustered in kids with comorbid conditions
  - Those are the ones that should be a priority for vaccination
  - The risk stratification for a healthy child is different

- Marty notes the numbers of unvaccinated people in the US getting hospitalized for COVID is 65.9 per 100,000 per week
  - That was roughly at the peak of Delta that ended up being about 1 in 1,500 people in the population
  - And these people were generally older, not a young, healthy 30-year-old
- Risk can be stratified  by comorbid condition
- Marty thinks immunity requirements make sense in healthcare for those who are patient facing
  - He doesn’t think the same calculus applied to the accountant working at home for the hospital
- We’ve been sitting stagnant at 85 to 86% of the adult population in the United States vaccinated for a long time
- He thinks all these discussions of the mandates hardened a lot of people
- And a lot of these immunity requirements do not account for natural immunity

**Crazy anecdote of illogical outcomes from vaccine mandates**

- Hospitals who have laid off staff for not being vaccinated are left working with a skeleton crew
  - There’s a hospital system in Washington State, in Tacoma and Olympus; it’s called MultiCare
  - MultiCare laid off 55 staff for not being vaccinated
  - That’s on top of the people who left before the vaccine requirement took effect
- The hospital asked people who called in sick with COVID to come in back and work in the hospital
  - This is a memo, reported from Jason Rantz, that Marty tweeted the other day
  - It says, basically, even if you have symptoms, if you’ve tested positive, come back, unless the symptom is fever
  - Then, they told the managers, “*Hey, when you assign these workers, try not to assign them to people. immunosuppressed. If anything, try to assign them to patients who have COVID. Let COVID staff take care of COVID patients*.”
- This is the insanity of blanket policies hardening people requirements that do not account for immunity
- Washington State had this harsh few exception, no exception vaccine mandate
- Consider snow plow workers in Washington State
  - They work alone driving a snow truck
  - One of the main highways in Washington State then got snowed in; it was undriveable
  - The county, Kittitas County offers to then plow this road for the state
    - The state should be plowing it, but they don’t have enough snow plowers
  - The state says, “*No, you’re not allowed to because your snow plow workers do not have the vaccine mandate. They’re not under the vaccine mandate*.”

**Natural immunity should be factored into vaccine mandates**

- Monica thinks that recovery or having natural immunity should always be taken into account
- There is a study soon to be published about reinfection in healthcare workers
  - Published in *PLoS One* January 4, 2022, [Incidence of COVID-19 reinfection among Midwestern healthcare employees](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0262164)
  - This reported that healthcare workers were equally as likely to be reinfected if they had been vaccinated versus had natural immunity
  - And severe disease was equally as protected
- Recovery immunity always has to be taken into account for any mandate

> “*I think that our country is unable to have nuanced conversation about COVID*” – Monica Gandhi

- We will have a lot to do after this to figure out why we allowed healthcare workers to not drive the conversation about COVID
  - And we allowed people who don’t have a lot of expertise in a way to drive the conversation

**Antidote from a previous podcast guest who will remain anonymous** [60:45]

- This person is a professor at an Ivy League University
- They do really remarkable work
- They were fired in November 2021 for not getting vaccinated
- The point here is that the University has its own mandate program absent the federal government

**Mandates continue**

- Peter has read that 50 of the fortune 500 companies in the US are going to continue with mandates even in the context of the recent Supreme Court decision
- He doesn’t think this issue of vaccine mandates is going away
- Certainly states like California and New York may be still deciding to create their own mandate
- Almost every single country in Europe takes natural immunity into account, why isn’t this considered in the US?

## Why the topic of COVID has become so polarized [1:03:15]

- ZDoggMD speculates that we’ve created a God-shaped hole in our society over multiple years of secularization,
- What’s happened now is a situation that polarizes people almost the way a religion would
- Look at the natural immunity versus vaccine immunity camps
- It is a sanctity versus degradation issue for people with purity issue
  - If you’re a Covidian and you’re in the thesis camp and you’re like, “*No. Vaccines are the answer. We get through this through vaccine related immunity*,” you are unclean, unpure, undesirable and unwelcome if you are not vaccinated
  - If someone got the disease previously, they already have a strike against them because they didn’t mask up, they didn’t distance, and they are unclean
- On the other side, there’s an equal religious fervor and that is this holy sacraments of Hydroxychloroquine and Ivermectin
  - And the conspiracy end times revelation aspect of these guys are trying to hide something from us, poisoning us by injecting our holy temples, our bodies with vaccines
- Both sides on this that are polarized; they have a religious aspect to it,
  - That’s why it’s been so hard to understand why this is going on
- Monica notes that Omicron is actually destigmatizing; that’s good, in a way
  - It’s a very highly transmissible respiratory variant
  - It can’t be eradicated like we thought this disease could be at the beginning
- Omicron won’t be eliminated because—
  - It is a highly transmissible respiratory variant
  - It has animal reservoirs
  - It has a presymptomatic period where one is infectious
  - It has a long infectious period
  - And vaccines elicit non-sterilizing immunity

> “*All of that means it cannot be eradicated, but it can be made endemic. It can be controlled.*” – Monica Gandhi

- It is the time where the shame of getting a pathogen is being destigmatized

## Reviewing the data on masks for protecting oneself and protecting others [1:06:30]

**What do we know today about the efficacy both at protecting one’s self and protecting others?**

- Monica’s first podcast with ZDoggMD was that cloth masks seem to reduce the severity of illness. Then, there were some NIH studies that showed that actually, it’s probably the humidification of air when you’re wearing a cloth mask that reduces the severity of symptoms.
  - **Monica’s podcast with ZDoggMD about cloth masks**: [Masks may do more than we think (w/Dr. Monica Gandhi)](https://zdoggmd.com/monica-gandhi/) | Host Dr. Zubin Damania  ([ZDoggMD](https://zdoggmd.com/), September 13, 2020) | [1:07:15]

> “*The best way to reduce the severity of symptoms is to get vaccinated, right?*” – Monica Gandhi

- There are certain masks that seem to work best for the individual
- We cannot be mandating mask mandates for the whole population anymore because transmission doesn’t seem to be reduced by cloth masks, doesn’t seem to be reduced by even surgical masks, unless you really tuck them in and double loop them and so forth
- The Bangladesh randomized controlled study of mask was reanalyzed by a group at Berkeley and cloth masks and surgical masks did little for the population level, but what a mask does is it one way protects you
- Monica thinks the CDC should tell people worried about exposure to wear the right kind of mask
  - Protective masks are N95, SKN95, SKF94, FFP2s, double masks, or even tucked in surgical masks
- It’s important to give people information and let them decide instead of creating a mandate for the whole population
  - There are some people who want no exposure to Omicron
  - There are some people who really feel protected by their vaccine
    - Even if they have mild symptoms, they feel okay about that.
  - There are some people who have no risk tolerance
  - There are some people who have high risk tolerance
  - Monica wants her father to wear an N95 because he happens to be getting chemotherapy right now, and he’s 87
  - She wants her child who’s low risk and fully vaccinated to be able to not wear a mask
- Monica’s interest in cloth masks and my interest in masking were for the individual for reducing severe disease
  - Data now from the NIH with humidification of air supports this
- However, [the Bangladesh RCT Mask Study, which was published in *Science*](https://www.science.org/doi/10.1126/science.abi9069) has now been corrected because the raw data got put out
  - 3 groups looked at the raw data and it didn’t look like cloth reduced transmission
  - And even surgical masks actually was much less than originally said in the interpretation of the Bangladesh RCT in villages
  - Maybe if one tucked in their surgical mask and double looped it and really sucked it to their face, this could make surgical masks work better because they are polypropylene material
- Peter asks if Monica will wear a mask when she visits her father
- She will see him in a couple weeks and will either test and make sure that she’s negative before she hugs him or she’ll wear a good mask while she’s waiting for the test
  - She can’t risk exposing him
  - He is in that category where he can have a severe breakthrough
- The implication is that he wears a mask to protect him and she will wear a mask to protect him
- Back to mask mandates— now that vaccines are available, masks should be a choice
  - That’s different from a mandate
- Peter is vocal about his personal choice, he doesn’t wear a mask [1:12:00]
- Monica was really into masks early on,before the vaccines were available
- But now that 2 years of data are available, their utility is clear
- She advises people to look at [Joseph Allen’s work](https://www.hsph.harvard.edu/joseph-allen/op-eds/) and Shera Donna’s work

**Masks that offer the best protection**

- N95s, KN95s, FFP2s, KF94s, a double mask with cloth and surgical, or the final option is actually a cloth mask with a surgical filter inside, a filter inside that’s polypropylene material
  - That last option is probably the most comfortable; a cloth mask with a filter inside
  - All of these have been studied very well
  - All of these protect the individual
  - For someone who wants no exposure, wear one of those masks

**Mask mandates on airplanes and in federal buildings** [1:14:30]

- - The Biden administration task force advisors wrote a piece in JAMA just two weeks ago; it was similar to a piece I’d written in Time that said you have to accept that we have to live with COVID

- *JAMA* January 6, 2022, [A National Strategy for the “New Normal” of Life With COVID](https://jamanetwork.com/journals/jama/fullarticle/2787944)

- *Time* December 22, 2021 updated January 19, 2022, [We Can’t Just Impose Restrictions Whenever COVID-19 Surges. Here’s a Better Plan for 2022](https://time.com/6131104/rethinking-covid-19-restrictions-2022/)

- Monica thinks there’s going to be 4 things that happen that are different now than before what used to happen in the world
  - 1) We have to protect ourselves from respiratory pathogens as a whole
  - We’re probably going to always vaccinate
  - 2) We need better treatments and we need more of those treatments
  - 3)  More attention should be paid to ventilation for all respiratory pathogens
  - 4) There will be people who want to mask
    - Wear those 6 types of masks
    - Monica doesn’t think wearing a mask can be mandated
    - She doesn’t think it’ll be mandated in California after February 15th, nor for travel after March or whatever date Biden has said

> “*One way masking works. It’s like your vaccine protects yourself. Your mask protects yourself, too.*” – Monica Gandhi

## The inconsistent logic used for mask mandates [1:16:00]

**Should kids be required to wear masks in school?**

- This is up to local school districts in many states, but Marty would say the majority of schools require masks
- Unfortunately, a lot of kids are wearing the cloth masks
- So they’re getting all the downside of hiding their faces, not learning how to read facial expressions, all those other things
  - And none of the supposed upside of protection
- There was a Brown University study that talked about significant cognitive and motor delays in children that can only be ascribed to the loss of the human connection
  - Preprint available in *medRxiv*, August 11, 2021, [Impact of the COVID-19 Pandemic on Early Child Cognitive Development: Initial Findings in a Longitudinal Observational Study of Child Health](https://www.medrxiv.org/content/10.1101/2021.08.10.21261846v1.full-text)
- Looking at the risk stratification in kids, it’s just a whole different ballpark as we’ve talked about
- Honestly, we are now using policies designed around Beta and Delta in an era of Omicron, which is behaving very differently

> “*What happens when Omicron is essentially gone and now we’ve got wave a year from now, but it’s parainfluenza? Or we have a rhinovirus wave, which we have every year? Then what?*” – Marty Makary

- There was a study we discussed last time in PNAS looking at N95 masks with and without a nose piece and surgical masks
  - Cloth masks weren’t studied, maybe because they recognized there is no value in them
  - Published December 7, 2021, [An upper bound on one-to-one exposure to infectious human respiratory particles](https://www.pnas.org/content/118/49/e2110117118)
  - They found that if an infected person is in direct contact with somebody else for 20 minutes, the risk of transmission with surgical masks was 10.4%
    - With an N95 without a nose piece it was 4.2%
    - And an N95 with a nose piece, in other words, a good seal, 0.14%
  - So that tells us a lot; it tells us that one can significantly reduce the risk of transmitting
  - But it also tells us that the quality of the mask matters
- Why are we learning this 2 years into the pandemic?
- The NIH and CDC are not fulfilling their role of providing data to the public
  - For two years, with their gigantic budgets, they couldn’t do this basic study on masks

## Long COVID and the potential for vaccines to reduce risk [1:21:45]

- UCSF has a great study on post-acute SARS COVID 2 sequela
  - [Understanding the Long-term Impact of COVID-19 in Adult](https://clinicaltrials.ucsf.edu/trial/NCT05172024)
  - Study started October 29, 2021
- This type of disease can occur with any severe viral infection, including influenza
- It is characterized by lingering symptoms
- The pathophysiology seems to be twofold
  - 1) In the absence of immunity to the virus, it can go multiple places
    - It won’t stay in your body long term like HIV, but it can go multiple places
  - 2) In the absence of immunity, the innate immune response can lead to inflammation that lingers
- With immunity to the virus (as a result of vaccination or recovery from infection) 2 things happen
  - 1) One develops an adaptive immune response
    - The adaptive response responds quickly to a breakthrough infection
    - T cell islands in the nose begin to control infection and limit spread of the virus
    - This is why breakthrough infections are mild and up in the upper respiratory tract; immunity limits spread of the virus
    - This is a benefit of being vaccinated or immune
  - 2) It’s not the innate immune system that reacts to infection but the adaptive immune response
    - This doesn’t’ produce that kind of massive inflammation that can occur before immunity
- Just this morning Monica saw a study out of Israel showing that those who are vaccinated don’t get long COVID symptoms after having a mild breakthrough
  - Preprint available at *medRxiv*, [Association between vaccination status and reported incidence of post-acute COVID-19 symptoms in Israel: a cross-sectional study of patients tested between March 2020 and November 2021](https://www.medrxiv.org/content/10.1101/2022.01.05.22268800v2.full-text)
  - In fact, they have long COVID symptoms at the same rate as people who’ve never had COVID at all
    - There’s people who have had a lot of anxiety and depression during this time, understandably, and that can be mistaken for long COVID symptoms
    - There are some studies that what’s going on in the world right now and how miserable everyone is, is making people have less cognitive function because it’s just a miserable time
  - This was a study of people who had 2 vaccine doses; they had fewer long COVID symptoms than people who never had COVID
  - So basically vaccination both brings your long COVID symptoms in check
  - So getting vaccinated for long COVID is one way to treat long COVID
  - And then also those who have mild symptomatic breakthroughs who have been vaccinated don’t seem to get long COVID symptoms
    - Now there are 3 studies showing this, including this one
    - And we have had a lot of breakthrough infections through Delta and now out through Omicron

“*These are very good studies that shows our adaptive immunity prevents us from getting these longer symptoms*” – Monica Gandhi qkt

**What is the incidence of long COVID in presumably the unvaccinated**

- It depended on if someone had severe disease or mild disease
- So those who had severe disease, there is a very good *Nature* study, they are more likely to get longer symptoms after that
  - The incidence was about 30%
  - Published November 2021, [Burdens of post-acute sequelae of COVID-19 by severity of acute infection, demographics and health status](https://www.nature.com/articles/s41467-021-26513-3)
- For those who had mild disease, the incidence was very low
- However, at this point there are so many people who’ve been vaccinated and there is so much natural immunity that the long COVID population is going down
- From the clinic she knows we’re still treating people who had an initial severe infection before the vaccines were available

**What portion of the young population is not vaccinated and therefore at risk for long COVID?**

- 15% of Americans over 18 are unvaccinated
- 20% of Americans over age 12 are unvaccinated

> “*Really to me that might be one of the more potentially compelling reasons to be vaccinated if you are otherwise young and healthy is to mitigate the risk and the downside of long COVID*” – Peter Attia

- Not only does vaccination help someone not get long COVID if they get COVID, but also it seems to be able to treat long COVID
  - because with vaccination, the more dysregulated immunity becomes a more adaptive and organized immunity

> “*I think it’s profoundly important to say vaccination helps long COVID, either after the fact or before the fact* “ – Monica Gandhi

- So adaptive immunity seems to be the way all roads lead to where we need to get to with this virus, which is having a lot of immunity to the virus
- Now in this stage of the pandemic, we have so much more immunity to the virus

## Risks for children and policies for schools [1:27:30]

- Monica notes that Peter went over how much lower the risk of severe COVID is for children
- There is a clear mechanism by which children are less likely to get severe COVID— with these two receptors and their native immune response
  - And that’s true of long COVID as well
- Schools should not be a place of fear
- There will always be respiratory disease; think of parainfluenza, rhinovirus, influenza
- Few people will deny the ill effects of school closures 2 years into the pandemic
  - The ill effects include mental illness, anxiety, depression, eating disorders, and learning loss
- Children are the most precious resource
- We need to now move towards normality for children in schools

**Colleges move toward management of COVID as an endemic not pandemic**

- Harvard just said, they’re not going to do asymptomatic testing or contact tracing starting in the spring semester, they’re going to have normal college
- John’s Hopkins is still not having normal college
- Monica notes that Marty wrote a really poignant piece on the restrictions being placed on college students
  - Published January 4, 2022 in *Common Sense*, [Universities’ Covid Policies Defy Science and Reason](https://bariweiss.substack.com/p/universities-covid-policies-defy?r=abaxo&utm_campaign=post&utm_medium=web)

> “*Harvard of all places saying they’re going to have normal school in the spring semester and accepting that we can’t eradicate a virus, for me, was very hopeful this weekend*” – Monica Gandhi

**Monica had to leave but Marty, ZDoggMD, and Peter continue the discussion**

## Reviewing the outcomes from Sweden, where the government didn’t impose lockdowns [1:31:00]

- - Remember in spring, summer of 2020, when Sweden didn’t lock down and everybody looked at Sweden as though it was crazy
  - Peter has not gone back and looked at Swedish outcomes but wonders what happened
  - Anecdotally, ZDoggMD has gotten lots of messages from Swedes
  - People fail to see the context of the society in Sweden
    - This is a Nordic country that over the years has developed a relationship between its population and its government that is trusting
    - One has to consider their healthcare system, their public welfare system, aspects of their population
  - Sweden took the tact of less regulation
    - There were rules early on about large events and large gatherings
  - But their public health officials didn’t know when a vaccine was coming  and took a long-game approach, thinking years
  - So they said we cannot shut down schools

- Early on what they found was they did have a higher mortality per capita rate than their neighbors

- Largely because the one big mistake that was made early on is failing to protect nursing home patients who are the highest risk of mortality in the early days

- - - This was 2020

- In 2021, it seemed the data shifted to where there was no excess mortality; it was not higher than their neighbors

- And they actually did quite well

- Overall, they stayed mostly open
- They had some businesses that suffered that the government directly stepped in and paid salaries and things like that
  - So there was more of a social support network
- But they really were playing the long game
  - And it seems like so far, they’ve done quite well
- Marty agrees, this is a fascinating case study because Sweden took a radically different approach
- There was criticism of their strategy early on, but nobody has talked about them since

**Data from Sweden**

- It turns out that their data are very impressive
- The mortality per capita in Sweden, all in all cumulative, this entire pandemic has been 1 in 663
- Compare this to the United States, it’s 1 in 387
  - This is a radically different confirmed deaths per capita rate
  - This is according to [Statistica](https://www.statista.com/)
- The mortality rate for Sweden falls around the middle
  - But remember most of the countries in the bottom half are not reporting reliably

## Draconian measures implemented in Canada [1:38:15]

**Anecdotes**

- Peter has a friend who had COVID and didn’t get vaccinated
  - Their kids didn’t get vaccinated
- Without vaccination, the kids can’t play sports
- Quebec is now trying to tax the unvaccinated
  - This is a sin tax
  - To be logically consistent, a lot of people should be taxed
    - A tax for having a high BMI
    - A tax for being clumsy and doing high risk sports because of the increased risk of ending up in the hospital
- An unvaccinated person in Canada cannot travel in Canada
  - They can only drive themselves
  - They can’t get on a bus or airplane
  - They can’t cross the border
- Marty asks what happens to people infected with influenza or parainfluenza
  - Is this okay even though the case fatality rate is high?
- ZDoggMD agrees, influenza kills so many people per year

## Antiviral treatments for COVID and a common-sense approach [1:42:15]

- Tamiflu doesn’t do much for the flu
- Peter has had the flu twice in his life; it sucks
- The bad thing is that we can’t really do much about it
- Peter remarks that influenza is about as bad as Omicron
  - Marty says influenza is worse
  - In a study of 52,000 people infected with Omicron, only 1 died
- For COVID there is now [Fluvoxamine](https://www.nature.com/articles/s41380-021-01432-3) and the more recently [Pfizer’s Paxlovid](https://www.pfizer.com/news/press-release/press-release-detail/pfizers-novel-covid-19-oral-antiviral-treatment-candidate) and [Merck’s molnupiravir](https://www.nature.com/articles/d41586-021-03667-0)

**Ways to protect one’s self**

- 1) Get vaccinated
- 2) Have access to therapeutics
- 3) Have access to a healthcare system that knows how to treat this disease

**Policies are based on previous variants**

- Peter notes that we are operating under assumptions that are 2 years old
- Marty adds that we are thinking of the infection fatality rate of the prior virus

> “*Omicron needs a PR firm because as long as it’s COVID people think they’re using all the COVID historical data”* – Marty Makary

- When you add population immunity and a more mild virus, it does change the calculus
  - It doesn’t mean people don’t get sick
  - It doesn’t mean that any of us would ever wish anyone to become infected and deal with this virus
- Everybody is so upset at the CDC over so-called messaging
  - Over the time to quarantine
  - Is it 1 or 2 tests?
  - Is it an antigen or PCR test?
- Let’s ask the bigger question— why are we even quarantining immune people who are low risk from other immune people?
  - Would we ever do this for parainfluenza or rhinovirus?
- We need to get back to common sense

**What does common sense look like?**

- Marty’s pan viral strategy for general public health hygiene
  - This will get us away from these crazy deliberations that we’re having right now
  - 1) Which means if you’ve been exposed, then wear a mask; it doesn’t matter what virus
  - 2) If you are around someone vulnerable, be careful, maybe stay your distance
  - 3) And if you’re sick, stay home
- ZDoggMD notes this requires a culture shift
- Because people have to understand that going into work sick without a mask say is really a taboo

## Importance of ending tribalism and having rational discussions with humility [1:47:30]

- Since the last COVID podcast Peter has been more attentive to all things related to COVID
  - It hasn’t been good for him
  - His blood pressure has been running 10 mmHg higher
  - Most of that is social media
  - He has this “*anaphylactic reaction to things that are logically inconsistent, but it serves no purpose other than to hurt me*”
- He started trying to understand his agenda
  - He’s not a contrarian
- He’s worried about the integrity of the medical profession and the broader discipline of science
  - He has many friends and some patients who have completely lost faith in this profession
  - This is the ax he’s grinding
  - He’s very upset about what the implications of this are down the line
- For ZDoggMD, thinking about COVID since the last podcast has been nothing but suffering
- From the early days, his agenda is trying to find a synthesis of what is the best policy versus science thing for the most people and trying to bridge across this divide of misunderstanding and division
  - He wants to understand all these positions
  - He calls his agenda the alt middle

> “*How do we build those fibers that connect these things together and help us think rationally*” – ZDoggMD

- It’s important to understand where our agendas are and where our biases are, whose hive mind has captured us
  - Otherwise you’ll never be able to bridge these different gaps and have some sanity
- Marty says his agenda is to end tribalism, because that is the most offensive thing
  - It’s not a different opinion
  - He’ll hear somebody articulate a different perspective and they’ll come out entirely differently on what we should be doing or should be recommending
  - That is okay in the context of civility in my mind.
  - And his thought is, “*Let’s show the data on both sides to the best of our ability and let people make a decision*”
  - One of the few things that  is morally offensive is the automatic tribalism, the dismissal of people because of something that they thought early on
- He sees universities, who ironically are supposed to be champions of data and scientific reason, revert to these primitive practices that are almost barbaric
  - They’re definitely cruel on students
- Peter got a lot of hate mail after the last podcast [1:53:00]
- ZDoggMD has been talking about this in the [Sensemaking](https://en.wikipedia.org/wiki/Sensemaking) community online, people who are focused on trying to figure out “how do we make sense of the world in a fractured information economy and so on”
  - So, David Fuller, Rebel Wisdom, BJ Campbell and other people like that
- There’s an idea that individual humans actually do instantiate these higher elements of thinking
- We call them different things— groupthink, hive mind; he actually calls them [egregores](https://en.wikipedia.org/wiki/Egregore), which is a demon that emerges from groups of people and their thinking
- It used to be in the old days, you would share information in very slow and uniform ways
  - Whether it was mass media, just a few channels
  - Or whether it’s money as a way to exchange information because they’re economic incentives, like you build a city on a river because it’s easy access to ports and so on
- But now with social media, it has effectively have turned every human with a smartphone into an addicted machine that behaves like a neuron
  - And its neurotransmitters are likes, dislikes, comments, shares
  - So, each of us is part of a network of people that acts, again, we’re neurons
  - And we instantiate, through these instant connections, these hive mind groupthink tribes
  - Instantly one can be a part of this and then be controlled by it without even knowing it
    - And it’s lubricated by social media
- And the people who are acting as the neuron in that network don’t even know they’re doing it
  - They actually believe this until they really introspect or they talk to you in person or something happens that breaks the spell
- So, the Malones of the world are captured by the antithesis groupthink hive mind
- The Fauci’s, Eric Topol’s of the world are more captured by the thesis hive mind
- And who are we in this middle corpus callosum hive mind?
  - We’re hated by everyone
- The letters that meant the most to Peter were the ones that said, “*I have been morally opposed and opposed in every manner to getting vaccinated until I heard this podcast. I actually think I might get vaccinated now*”
  - That’s worth all the hate mail in the world
- And Peter doesn’t think the purpose of these podcasts is to get everyone vaccinated
  - It’s how about to give people the information so they can make the best decision in their best interest
- But when someone says, a buddy of mine who’s the most anti-vax human being in the history of civilization, just got vaccinated because of that podcast, Peter thinks, “*Wow, that’s fantastic*”

> “*There is hope that information can trump fear*” – Peter Attia

- Marty thinks the honesty of the conversation is what was appealing

> “*I think people are starving out there for honesty on this topic that’s not tribal*” – Marty Makary

- It’s not an allegiance to a party line on what we have handed down to us as an edict
- Marty thinks it’s this very genuine humility around the data and a virus that changes and evolves
  - And we have to change our thinking in real time
  - People are starving for honesty and data
- It’s important to spend time just explaining things with a non judgemental approach
  - By the way, physicians have been doing this our whole careers

## Treating infection with monoclonal antibodies and convalescent sera [2:01:45]

**What monoclonal antibodies are effective against Omicron?**

- Only 2 out of the 3 work on the Delta variant
- Over the last few weeks, the people who have been showing up in the hospital in deep trouble medically tend to be heavily skewed towards the remaining Delta variant
- Now, if the CDC estimates are correct, Delta is 1.7% of new cases as of January 14th or so
- That tells us that the influx, that the ongoing damage that this is causing in terms of severe illness, is really letting up right now just by the dominance of Omicron
- There is only 1 monoclonal that works well, the [GSK monoclonal, sotrovimab](https://www.gsk.com/en-gb/media/press-releases/preclinical-data-demonstrate-sotrovimab-retains-activity-against-key-omicron-mutations-new-sars-cov-2-variant/)
  - This is the only one that works well on Omicron
- But if Omicron is as mild as we’re seeing, that tells us we should be using it selectively in high risk individuals
  - We don’t do a good job of that in healthcare
  - Instead what happens is these industrial strength big guns like [PAXLOVID](https://www.pfizer.com/news/press-release/press-release-detail/pfizers-novel-covid-19-oral-antiviral-treatment-candidate) and sotiromab are being used in very low risk people, sometimes people with wealth and power and access tend to get it

**Fluvoxamine**

- Peter asks if there is any emerging data on the efficacy of fluvoxamine against Omicron specifically?
  - Because obviously the Lancet trial, the JAMA trial were all in Delta
- Marty replied that someone at the NIH wrote a summary of [fluvoxamine](https://www.covid19treatmentguidelines.nih.gov/therapies/immunomodulators/fluvoxamine/) where they described its benefit and impact on reducing hospitalizations and survival and concluded, at the end of it, that there was insufficient data to recommend it
  - This was a conclusion that should not have been derived from that summary
- Unfortunately now there is this militaristic mentality where everyone just falls in line in medicine
- Many physicians are creative and smart enough and they’re like, “*Hey, I read the studies. The reduction is dramatic. Just because there’s not an official authorization around it at the FDA, I’m going to use it for my patients*.”
- And then there’s some that just say, “*Well, the CDC doesn’t say for me to use it,*” or they say, “*The NIH is not officially endorsing it*.”
  - So, they’re up against that
- The people who did that study have told ZDoggMD and I that they’re close to what they believe might be some good news at the FDA around an authorization
- But unfortunately this is a drug that has reduced mortality among people compliant by 91% in high risk COVID patients, and we still have very little awareness around it
- In fact, a preprint was just released; it was a survey of doctors asking what they recommend for patients just diagnosed with COVID
  - They said Vitamin D, Vitamin C, Zinc, and something else with no evidence really behind it
  - There was no discussion of convalescent plasma, which in concentrated form reduces hospitalizations by 50%
    - That’s been around, by the way, for 2 years
  - There was no mention of fluvoxamine

**Convalescent plasma**

- Convalescent plasma was talked about immensely in March and April of 2020 when we truly had nothing on the horizon and then it went away

- Peter doesn’t know if it went away because it didn’t have efficacy or because we finally got  monoclonal antibodies

- Marty talked to the authors of a study on convalescent plasma that was the subject of a recent article in *MEDPAGE TODAY*
  - [FDA Allows COVID Convalescent Plasma for Some Outpatients— Updated EUA limits scope of treatment to immunocompromised individuals](https://www.medpagetoday.com/infectiousdisease/covid19/96430) (December 29, 2021)
- Convalescent plasma is the plasma from someone who recovered from COVID illness
  - Convalescent means recovered from illness
  - This is the plasma, not the red cells
  - The plasma contains antibodies
  - This is an infusion of a partially intact immune system, real antibodies
- Essentially, monoclonal antibodies that pharma companies make is the same thing
  - They’re just antibodies made in a laboratory and they tend to be all one type, hence the name monoclonal as opposed to polyclonal antibodies
- So, in the convalescent plasmas, there is a more diverse antibody profile
  - Arguably this is better
- Marty thinks the backlash against convalescent plasma is politically driven
  - The trump administration had a lot of enthusiasm for it
- There was confusion about it
- The head of the NIH, Francis Collins, was asked to weigh in on convalescent plasma; and he said, “*We need a randomized controlled trial*”
  - Marty thinks this was a cop out
  - They had strong data in a non-randomized fashion
- We should do a randomized control trial, but what he did is he threw water on any sort of interest in using it clinically
  - The news media distorted it
  - Pharma companies were saying, “Hey, we’re making antibodies. Why use convalescent antibodies?”
  - Convalescent plasma fell to the wayside
- Marty reached out to the study authors of the first trial that showed a benefit, the *New England Journal of Medicine*, and they said, “*That study was flawed. The design was flawed. We need more research and trust us, it’s coming*.”
  - And they were very frustrated
  - They eventually published a study that came out very recently that looked at concentrated convalescent plasma
    - Concentrated convalescent plasma provides more antibodies
    - It was a well done study
    - It showed a dramatic reduction in hospitalization, a reduction by 50%
    - But nobody talks about it
- There are shortages of monoclonal antibodies but nobody is talking about concentrated convalescent plasma
- But we don’t yet know how effective convalescent plasma will be against Omicron
- In general, when someone is exposed to a virus, they get a more diverse antibody response or profile than with just a monoclonal infusion

**Why natural immunity is thought to be stronger than vaccinated immunity**

- There’s two reasons why people think natural immunity is stronger and more effective than vaccinated immunity
  - 1) Natural immunity produces a more diverse antibody portfolio
  - 2) Natural immunity is a more mucosal-based immunity; so it’s more on the front lines of defense

## Reviewing claims made by the controversial Dr. Robert Malone [2:11:15]

- ZDoggMD thinks of our division around this, into these two churches of Covidian and Covidiot, and Robert Malone is an interesting epiphenomenon
- He’s a scientist who was involved early on in some of the work on the mRNA technology
  - In particular wrapping that mRNA molecule in a lipid particle, in a fat particle, that allows it to be taken up by cells
  - He was working on a HIV vaccine that didn’t generate an immune response, but the technology was there
- He was one contributor in a vast chain of contribution that actually led ultimately to where we are now
  - His contributions and patents expired a while ago
- He bills himself as the inventor of mRNA technology
- He uses that credibility and also the credibility of working as a consultant in different government entities to make a series of claims about vaccine safety
  - That ultimately got him banned from Twitter
  - This got Joe Rogan’s attention, and Rogan then gave him a platform
- He has made multiple claims
  - ZDoggMD thinks some are correct, such as giving infinite boosters is not a good idea
  - He questions the financial incentives of pharma and different entities within healthcare to focus on vaccines; this is not unreasonable
  - He downplays the point that there’s lots of money in therapeutics, too
  - Those are the main things that I think establish his credentials as a heterodox thinker

**Where Malone is wrong**

- But then every major point that he makes is fundamentally flawed, if not a parroting of an extreme anti-vaccine position on these things
  - So, one of the things he says is that PCR is overestimating the number of COVID cases, and that it’s not accurate
    - The truth is, it is quite accurate; it’s very sensitive and it’s quite specific
  - For example, he says, “*If we had just provided early treatments in the form of hydroxychloroquine, ivermectin, monoclonals, et cetera, it is a fact that we would’ve saved 500,000 US lives*.”
    - And he provides no data to actually support this
    - There’s no evidence that hydroxychloroquine and ivermectin actually do anything that’s compelling
    - That’s still being studied with ivermectin
    - But with hydroxychloroquine it was quite clear
  - He said that hydroxychloroquine was shown to be active against the original SARS
    - But this is a bit misleading because chloroquine inhibited the virus [*in vitro*](https://en.wikipedia.org/wiki/In_vitro)
    - There are millions of compounds that work *in vitro*; it was never shown to be anything beyond that
  - He then discusses that the spike protein that is used in current vaccines by Pfizer, Moderna, et cetera, was never tested for safety
    - He then either is deliberately misleading or misunderstands the scientific process with this because that’s what the clinical trials with tens of thousands of people were doing, was showing (that it is safe and effective)
  - The other thing he says that’s abjectly untrue is that there were no pre- clinical or animal studies on these particular vaccines or mRNA constructs
    - These studies are findable
    - This is simply a lie
- He made the claim that hospitals in particular are mis-characterizing COVID cases
  - Now, this is a claim that actually has some validity in a sense
  - Hospitals are paid more for COVID patients; so, there is some incentive to up code in a medical billing situation
  - In the early days, they’ve looked at this and it’s not clear that that was happening
  - Because to some degree there’s a fraudulent component there
  - He specifically said there are gunshot victims being coded as COVID patients
    - And by the way, that could be true if a gunshot wound patient has COVID
    - It would be unethical to code it as a COVID patient

**The number of COVID deaths** [2:17:15]

- Marty has the numbers
- There were 477,000 excess deaths from March 1st to December 21st, 2020
  - 74% of match up with the COVID mortality
  - 385,000 were due to COVID; there was 477,000 total
- Peter notes that half a million excess deaths can’t be explained with coding
- ZDoggMD notes that some of it may be ancillary effects of lockdowns and so on
  - But some of it may be even under-counting of COVID cases, people just dying at home and not being diagnosed
  - There are lots of different potential explanations
- Peter notes, this begs a question which is, were the people who disproportionately died people who were going to die within the next 2 to 3 years
  - Does that imply that there may be a reduction of death in 2022 or 2023
- ZDoggMD replies that this has been discussed quite a bit in online circles
  - It’s this dry tinder theory, where people who had a short life expectancy died from COVID
  - We see this every winter in the hospital with the flu
  - That’s why they say pneumonia is the old man’s friend, right? It’s the final thing in a very medically frail person
- ZDoggMD thinks it has this ramification in the sense that how much of the overall suffering under the curve was just expedited by a year
  - Versus how much it is cutting off five years, 10 years of quality adjusted life years
  - That’s quite high
- That then would justify or de-justify certain social policies that have been put in place

**Vaccine monitoring and vaccine injuries** [2:19:45]

- Related to this, Malone asserts that we don’t have good vaccine monitoring at all and asserts that there are lots of vaccine injuries and damage that we are not counting
- He talks about [VAERS](https://en.wikipedia.org/wiki/Vaccine_Adverse_Event_Reporting_System), which is really a hypothesis generating system where anybody can report and so on, but he does not talk about PRISM or V-safe or the Vaccine Safety Datalink ([read more about them](https://www.hhs.gov/immunization/basics/safety/index.html))
  - These are very robust vaccine monitoring systems that actually help to catch things like very rare events like the vaccine induced thrombotic thrombocytopenia of the Johnson & Johnson, AstraZeneca vaccine
- ZDoggMD thinks that’s quite misleading to say that
- It’s good that he’s asking these questions
- Malone is directly misleading when he states that the lipid nanoparticles from the mRNA vaccines concentrate in tissues such as ovaries
  - To  explaining things like infertility and menstrual cycle abnormalities in women
  - And the truth is, the data he’s citing is a rat study where they pounded these rats with super normal levels of this lipid nanoparticle mRNA, and they saw accumulations in various tissues, but no tissue damage, actually
  - This has not been seen in humans
- There are menstrual cycle abnormalities, so that’s where he is correct
  - And NIH has actually funded studies on this
  - The speculation on why this may be has been rampant
  - Some of it is just with any infection with an immune response, there can be abnormalities in menstrual cycles
  - And it’s that whole hypothalamic ovarian axis thing that ZDoggMD wishes he understood better
- He mentions other things about ivermectin that are incorrect
  - Like Japan recommending ivermectin for treatment of COVID; they did not
- He says that the Chinese were using hydroxychloroquine to great effect early on
  - And he uses that as an example of a reason of why we should be using it
    - Simply not true
- Peter remarks, “*those are the types of claims that are difficult because you can’t counter a negative…you can’t search the anti-truth*”
- This is why ZDoggMD thinks many people will not research it
  - They constantly want to debate

> “*When you actually have days to look at the data, you realize, wow, that’s total bullshit, but I could never have responded that in real time*” – ZDoggMD

- What is needed is an honest debate, a conversation
  - Where everyone is familiar with the data
- The fact that Malone was deplatformed on these other platforms is why he’s on Rogan
- ZDoggMD has no idea what his motivations are
- The interesting thing to do when judging the veracity of somebody or the credibility of somebody, is to see who they cite

**Who Malone cites as reputable sources**

- At one point Malone cites [Peter Duesberg](https://en.wikipedia.org/wiki/Peter_Duesberg)
  - He’s a legendary guy in science because he was an esteemed virologist based out of UC Berkeley
  - He was known for denying that HIV (the virus) caused AIDS
  - He would say things in his German accent like, “*AZT is AIDS by prescription*”
  - He got famous for this because he went to South Africa and actually convinced the president of South Africa that this might be true
    - And it may well have cost lots of people their lives because they were slow to uptake protease inhibitors, et cetera
- So, Malone actually cites Duesberg as the esteemed virologist who was canceled by Fauci in the early days
  - This is not true, actually
  - Duesberg continued to teach at Berkeley where ZDoggMD took his class; where he presented his ideas and the class got to debate them.
  - Duesberg was since proved remarkably wrong on HIV
- In the same breath, Malone actually associates with [Robert F. Kennedy Jr.](https://en.wikipedia.org/wiki/Robert_F._Kennedy_Jr.) who is a known anti-vaccine activist, not a physician
- And right after Rogan, he went on [InfoWars](https://www.infowars.com/) with [Alex Jones](https://en.wikipedia.org/wiki/Alex_Jones) and started talking about the great reset, various conspiracies along those lines

**Mass formation psychosis**

- Peter asks about a term he keeps hearing from that, mass formation psychosis
  - What is this?
- ZDoggMD links this back to the earlier discussion of groupthink and neuronal networks
- Any human now can create information and put it out in the world and form a hive mind around it
- Mass formation psychosis is a term based on the work of a European psychologist; ZDoggMD forgets his name
  - He parallels it to what happened with Nazi, Germany
    - Which again, if he’s resorting to the Nazis, he’s already lost the discussion
- Malone wrapped what he said in reason, and in a sense he is correct
  - Malone said, “*The rules for having a mass formation psychosis were the population is hypnotized into believing something to the detriment of actual truth is the following— You need an isolated population where there’s been isolation and dissatisfaction.*”
  - ZDoggMD forgets all the things he listed but he said, “*You need a sense of economic destabilization and crisis. You need to silo people off*.”
  - One other thing needed is an entity in authority to say, “*We have the solution, and it is one solution and that’s it*”
  - Then Malone’s argument is that “*the good German people, who are hyper educated, go and do crazy things*”
- Malone claims, “*Now we’re in a situation where the mainstream has created this mass formation psychosis where the only way out, we’re in this dangerous situation, you have to lock down, you have to close schools, you have to shut down your way of life and wear masks. And the solution is just this, vaccines. Forget about therapeutics, forget about ivermectin, forget about monoclonals. It’s just this, and this is the only way out. And people start to believe it because they’re so destabilized from all the other stuff happening. And so, they go along with the mass formation*.”

> “*Where I think he’s correct is that we are all victims of groupthink. What he ignores is that so is he*.” – ZDoggMD

- Malone is part of the reactionary tribe mind that says, “*No, I’m not comfortable with this, and here are all the crazy things we believe*”
- ZDogg breaks down Malone’s claims in more detail in this recent podcast, [Ep. 10: Dr. Robert Malone’s Joe Rogan Interview, Decoded – ZDoggMD](https://zdoggmd.locals.com/upost/1574469/malone-rogan-and-making-sense-of-it-all-the-vpzd-show)

## A potential exit strategy from the current situation [2:30:30]

- Peter takes some comfort in what Monica presented, which was that, in the spring, colleges might say, “*You don’t have to wear masks to sit in class anymore*”
  - That would be fantastic for young people, for every person
  - If airplanes, if the TSA and airlines say you no longer have to wear masks
- Marty thinks in a matter of a month or two, there are going to be very low levels of Omicron around
  - Almost nobody left who’s not already had it or strong immunity
  - And he thinks people are going to be so giddy to move on that the fatigue is just going to hit all time highs and people are going to turn the page

> “*And I think you’re going to see a sentiment really flip in most of the country*” – Marty Makary

- Remember when the opioid epidemic was nightly news every night, and we all were in touch with it
  - And then overnight, in one day, the media shifted their attention
  - And it was almost as if within 24 hours people forgot we even had an opioid epidemic
- Marty thinks there’s going to be an even bigger flip pretty soon

**Will new variants become the norm every winter?**

- Peter asks, “*we’re going to either have Omicron come back next winter, or we’re going to have Epsilon show up next winter. And presumably case rates will be high again, and mortality and hospitalizations will be relatively low. But what will prevent us from backsliding into a state of panic?*”
- Marty thinks the reaction will depend on geography
  - The reaction to the current pandemic was vastly different in Florida versus New York City
- 10% to 25% of the public is going to get some respiratory infection almost every year in perpetuity
  - That’s the way respiratory pathogens work

> “*But we’re definitely going to see more variants*” – Marty Makary

- Are we going to realize what Monica was describing— that is the beautiful, amazing, gorgeous immune system of the human body (adaptive immunity) will increase our protection against future variants regardless of what they are
  - Marty thinks there may be some anxiety, but at some point people are going to believe in adaptive immunity

**Implications for vaccine mandates**

- So, there’s not going to be a federal mandate, but states and employers, universities, where is that going to go?
- ZDoggMD thinks this is an issue where we need discussions
- What is the incremental value now of mandating vaccines?
- [Vinay Prasad](https://en.wikipedia.org/wiki/Vinay_Prasad) talks about this, he says, “*How many people are actually at risk of high complications? And of those, how many are unvaccinated? And of those, how many will mandates actually reach them?*”
  - ZDoggMD thinks the answer is probably much less than one might think
- These shotgun mandates that affect a lot of people and are polarizing society more along these like peri-religious lines
- ZDogg agrees with what Monica was saying, now at this point in the pandemic it’s an individual choice
  - One can vaccinate, one can wear a mask or not, and one can take the precautions that they need to

> “*Omicron will be the great equalizer that immunizes a lot of people, and we’ll then be on the other side of this where we don’t need mandates and policy stuff*” –  ZDoggMD

- ZDogg sees the need for these conversations but notes, “*even opening your mouth about it is taboo within certain hive mind states. I think it also requires a degree of thick skin*.”
- Since the last podcast Peter doesn’t know why, but he finds himself having much more empathy for people who don’t see eye to eye with him on vaccines, who are anti-vax
  - Even though he doesn’t agree with them scientifically, and he don’t agree with the facts that they cite in some circumstances
- Peter reserves the right to say, “*maybe one day a pathogen will come along that is so deadly for which there is no treatment for which transmission is eliminated by a vaccine, and for which the vaccine is so incredibly safe, where I might change my mind….and say we’re going to have to mandate this shit*.”
  - But he can’t say this with the current set of facts
- ZDoggMD notes that explaining what would convince him to do something shows nuanced thinking that is different from a hardcore anti-vax person who’s just that conditioned,or even a pro-vax person
- The difference is talking about a real belief based thing instead of strong convictions loosely held
  - What would dislodge convictions of belief?
- Marty adds that when one sees how the decision making is made at a government level
  - At the absurdity of how they’ve brushed over the data
  - How there’s this bandwagon effect, how the leadership has been dismissive of some of the data and cherry picking other data
  - He sees this attitude of “You’re stupid. Don’t ask questions. Just do it.” and that’s not how people are wired
- Marty worries about our response to another pandemic
  - One that has a case fatality rate not of two-tenths of 1% (which is probably retrospectively what it’s panning out to be with COVID)
  - An infection with a case fatality rate of 5%
    - Spanish Flu had a case fatality rate of 2%
    - Ebola has a case fatality rate of 50%
- What happens when we get a virus with a case fatality rate of truly 10%,  and we are acting like this sort of dysfunctional tribal, big tech censored…
  - This is what we were worried about from the early reports of China
  - We might be hosed

> “*We’ve got to have an NIH that responds in seven days with bedside clinical trials to tell us what’s happening, what works, what’s effective*” – Marty Makary

## Changes needed at the NIH [2:40:00]

- Peter asks, “*What are the ethics of having the people at the top of the NIH be both in charge of funding any academic in this country, and yet also being the arbitraries of what is appropriate to be said and not to be sa*id?”
  - Think of careers being ruined
  - Think about people who are now being silenced and not permitted to say anything that is at odds with the narrative of their funder

> “*Science has a currency of objectivity*” – Peter Attia

- Scientific freedom is a key component of actually being able to do science because science isn’t a dogma; it’s a process
- Peter relates it to the movie [*Don’t Look Up*](https://en.wikipedia.org/wiki/Don%27t_Look_Up) on Netflix; it was depressing because it was so accurate

**Fear and undue focus on how questions and commentary is perceived**

- Marty agrees, he’s had so many doctors tell him exactly what Peter just described
  - They’ve  been threatened
  - They’ve  been bullied by the media relations department at their hospital
  - Their department chair directly told them, “*Don’t put this out. Don’t write this op-ed*.”
- Many people have told him they believe natural immunity confers a lot of protection
- Many people believe in spacing out the second doses to save more lives and give better durability to the immunity
- People believe in open schools, that cloth masks don’t work
- But many people feel they can’t say anything
  - They encourage Marty to “*keep going, keep being out there and saying things*”
- When he looks at this national dialogue, he recognizes the one common theme people say is that their local institutions are concerned how it could be perceived
- Marty notes that “*Twitter is now the ultimate arbitrator of whether or not institutions are willing to put things out*”
- The other thing he hears is people are worried about their NIH funding
  - And if there is one currency of academic medicine, it is NIH funding
  - It is a direct requirement for every step of the promotions process
- He thinks people are afraid to go against Dr. Fauci, Dr. Collins
  - That is a tremendous amount of power concentrated in one human being, Dr. Fauci, and it’s even magnified because he’s such a nice gentleman
  - He has too much influence; it’s too concentrated
  - It’s not that he is bad or diabolical
  - Marty actually thinks he’s very well intended, he just disagrees with him on almost every aspect of the strategy
  - It’s just too much concentration of power, especially with when he controls the NIH funding dollars

**Anecdote about NIH not funding studies that go against the grain**

- Marty just heard from a doctor who has been funded by the NIH for 30 years
- He tells Marty that he submitted a very elegant and extensive grant to study natural immunity
- The grant got a near perfect score, and it’s not been funded
- That’s the kind of thing that should deserve funding and to get an answer
- The NIH has $42 billion at their disposal; that’s one question that deserves an answer rather than saying “*we don’t know*”

**What studies have been funded?**

- Peter asks, “H*ow many studies have been funded by the NIH that look at disparities in COVID rates*”
- Marty’s team just put out a Preprint analyzing 254 studies looking at COVID research on health disparities and social disparities
  - Available on *medRxiv* December 11, 2021, [NIH Funding of COVID-19 Research in 2020: a Cross Sectional Study](https://www.medrxiv.org/content/10.1101/2021.12.08.21267482v1.full-text)
- There has been 1 prevalence study; the results aren’t available yet, and it’s outdated anyway
- The other question is how does the virus spread?
  - The NIH funded 4 studies on that
- The question of the effectiveness of masks— 1 study has been funded
- Of the 254 grants the NIH put out there on social and health disparities in COVID, 4 are on how it spreads and 1 is on masks
- Marty notes, “*If you agree with me, you should be offended that Princeton is testing people three times a week even though they’re asymptomatic and triple vaxed. You talk about a disparity. High risk people in the community or can’t get a test when they’re sick and vulnerable, and yet we’re testing the hell out of these young, healthy, triple vax people*.”

> “*But how about knowing how it spreads?*” – Marty Makary

- Because we were propagating surface transmission for way too long
- Peter adds that we need to understand the natural history of the disease is vis a vis the immune system in the people who were infected without a vaccine

**Final comments**

- ZDogg defends Fauci from a piece that ran in *The New York Post* where his finances were disclosed
  - ZDogg took personal offense to this
  - The guy is 80 and so what if he saved his money and happened to believe in the power of compounding and very generic mutual funds
  - It’s not like he owns Pfizer directly or something

§

## Selected Links / Related Material

**Previous podcast with Marty and Zdogg on COVID-19**: [Podcast #189 – COVID-19: Current state of affairs, Omicron, and a search for the end game](https://peterattiamd.com/covid-19-current-state-omicron/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (January 3, 2022) | [1:30]

**Joe Rogan’s podcast with Dr. Robert Malone**: [#1757 – Dr. Robert Malone, MD](https://open.spotify.com/episode/3SCsueX2bZdbEzRtKOCEyT) | Host Joe Rogan, [The Joe Rogan Experience](https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk) (December 2021) | [2:45]

**Omicron cases in Kaiser hospitals in southern California suggests less severe disease**: [Clinical outcomes among patients infected with Omicron (B.1.1.529) SARS-CoV-2 variant in southern California](https://www.medrxiv.org/content/10.1101/2022.01.11.22269045v1) | *medRxiv* (JA Lewnard *et al.* Preprint 2022) | [5:15]

**Risk of severe disease from Omicron may be reduced by 25% as compared to the Delta strain**: [Outcomes of laboratory-confirmed SARS-CoV-2 infection in the Omicron-driven fourth wave compared with previous waves in the Western Cape Province, South Africa](https://www.medrxiv.org/content/10.1101/2022.01.12.22269148v1) | *medRxiv* (MA Davies *et al.* Preprint 2022) | [10:00]

**Omicron is less virulent in children under 5**: [Comparison of outcomes from COVID infection in pediatric and adult patients before and after the emergence of Omicron](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8750707/) | *medRxiv* (L Wang *et al.* Preprint 2022) | [13:00]

**Break-through-infections with Omicron result in broad immunity to other variants**: [Immunity in Omicron SARS-CoV-2 breakthrough COVID-19 in vaccinated adults](https://www.medrxiv.org/content/10.1101/2022.01.13.22269213v1.full-text) | *medRxiv* (H Kared *et al.* Preprint 2022) | [16:45]

**India’s new inactivated COVID vaccine, Covaxin**:

- [Covovax and Corbevax: What we know about India’s new Covid vaccines](https://www.bbc.com/news/world-asia-india-55748124) | *BBC* (December 28, 2021) | [17:45]
- [Efficacy, safety, and lot-to-lot immunogenicity of an inactivated SARS-CoV-2 vaccine (BBV152): interim results of a randomised, double-blind, controlled, phase 3 trial](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(21)02000-6/fulltext) | *The Lancet* (R Ella *et al.* 2021) | [17:45]

**Cell paper showing longer time between vaccine doses results in more durable immunity**:  [Immunogenicity of standard and extended dosing intervals of BNT162b2 mRNA vaccine](https://www.cell.com/cell/fulltext/S0092-8674(21)01221-6) | *Cell* (RP Payne *et al.* 2021) | [30:15]

**UK study showing boosters benefit continues after 10 weeks**”  [Effectiveness of COVID-19 booster vaccines against covid-19 related symptoms, hospitalization and death in England](https://www.nature.com/articles/s41591-022-01699-1) | *Nature Medicine* (N Andrews *et al.* 2022) | [33:30]

**Danish study shows transmission within households reduced in boosted individuals**: [SARS-CoV-2 Omicron VOC Transmission in Danish Households](https://www.medrxiv.org/content/10.1101/2021.12.27.21268278v1.full-text) | *medRxiv* Preprint (FP Lyngse *et al.* 2021) | [32:45]

**Boosters reduce risk of severe disease in people over 50**: [Effectiveness of a third dose of the BNT162b2 mRNA COVID-19 vaccine for preventing severe outcomes in Israel: an observational study](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(21)02249-2/fulltext) | *The Lancet* (N Barda *et al.* 2021) | [35:45]

**Joe Rogan’s podcast with Sanjay Gupta**: [#1718 – Dr. Sanjay Gupta](https://open.spotify.com/episode/6rAgS1KiUvLRNP4HfUePpA) (October 2021) | Host Joe Rogan ([The Joe Rogan Experience](https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk)) | [53:45]

**Reinfection in healthcare workers**: [Incidence of COVID-19 reinfection among Midwestern healthcare employees](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0262164) | *PLoS One* (A Rivelli *et al.* 2022) | [59:00]

**Monica’s podcast with Zdogg about cloth masks**: [Masks may do more than we think (w/Dr. Monica Gandhi)](https://zdoggmd.com/monica-gandhi/) | Host Dr. Zubin Damania  ([ZdoggMD](https://zdoggmd.com/), September 13, 2020) | [1:07:15]

**Bangladesh mask study**: [Impact of community masking on COVID-19: A cluster-randomized trial in Bangladesh](https://www.science.org/doi/10.1126/science.abi9069) | *Science* (J Abaluck *et al.* 2021) |

**Articles about the “New Normal” of living with COVID**:

- [A National Strategy for the “New Normal” of Life With COVID](https://jamanetwork.com/journals/jama/fullarticle/2787944) | *JAMA* (EJ Emanuel, M Osterholm, & CR Gounder 2022) | [1:14:45]

- [We Can’t Just Impose Restrictions Whenever COVID-19 Surges. Here’s a Better Plan for 2022](https://time.com/6131104/rethinking-covid-19-restrictions-2022/) | by Monica Gandhi and Jeanne Noble, *TIME* (December 22, 2021 updated January 19, 2022) | [1:15:00]

**Brown University study, loss of human interaction during the pandemic is linked to cognitive and motor delays in children**: [Impact of the COVID-19 Pandemic on Early Child Cognitive Development: Initial Findings in a Longitudinal Observational Study of Child Health](https://www.medrxiv.org/content/10.1101/2021.08.10.21261846v1.full-text) |  *medRxiv* Preprint (S Deloni *et al.* 2021) | [1:18:30]

**Study of N95 masks with and without a nose piece**: [An upper bound on one-to-one exposure to infectious human respiratory particles](https://www.pnas.org/content/118/49/e2110117118) | *PNAS* (G Bagheri *et al.* 2021) | [1:19:30]

**UCSF clinical trial underway on Long COVID**: [Understanding the Long-term Impact of COVID-19 in Adult](https://clinicaltrials.ucsf.edu/trial/NCT05172024) | Steven Deeks, MD, UCSF Clinical Trials (December 27, 2021) | [1:22:15]

**Study in Israe showing Long COVID does not occur in mild breakthrough infections**: [Association between vaccination status and reported incidence of post-acute COVID-19 symptoms in Israel: a cross-sectional study of patients tested between March 2020 and November 2021](https://www.medrxiv.org/content/10.1101/2022.01.05.22268800v2.full-text) | *medRxiv* Preprint (P Kuodi *et al.* 2022) |  [1:23:34]

**Nature study linking long COVID to severe acute disease**: [Burdens of post-acute sequelae of COVID-19 by severity of acute infection, demographics and health status](https://www.nature.com/articles/s41467-021-26513-3) | *Nature Communications* (Y Xie, B Bowe, and Z Al-Aly 2021) | [1:25:45]

**Marty’s editorial on the restrictions being placed on college students**: [Universities’ Covid Policies Defy Science and Reason](https://bariweiss.substack.com/p/universities-covid-policies-defy?r=abaxo&utm_campaign=post&utm_medium=web) | by Marty Makary MD, MPH, *Common Sense* (January 4, 2022) | [1:30:00]

**Recent article on convalescent plasma in MedPage Today**: [FDA Allows COVID Convalescent Plasma for Some Outpatients— Updated EUA limits scope of treatment to immunocompromised individuals](https://www.medpagetoday.com/infectiousdisease/covid19/96430) | by Ian Ingram, *MEDPAGE TODAY* (December 29, 2021) |  [2:06:15]

**Preprint by Marty’s team analyzing 254 studies on COVID health disparities**: [NIH Funding of COVID-19 Research in 2020: a Cross Sectional Study](https://www.medrxiv.org/content/10.1101/2021.12.08.21267482v1.full-text) | *medRxiv* Preprint (L Balaguru *et al.* 2021) | [2:46:15]

**2 vaccine doses in adolescents prevents almost all severe disease**: [Effectiveness of BNT162b2 Vaccine against Critical Covid-19 in Adolescents](https://www.nejm.org/doi/full/10.1056/NEJMoa2117995#.YeRx2QrtXuQ.twitter) | *The New England Journal of Medicine* (SM Olson *et al. 2022)*

**CDC director thinks most deaths are still due to the Delta strain**: [As Covid deaths rise, many still caused by delta variant, CDC says](https://www.nbcnews.com/health/health-news/omicron-covid-deaths-rise-many-are-still-delta-cdc-says-rcna11924) | by Berkeley Lovelace Jr., *NBC NEWS* (January 12, 2022)

**The** ***Financial Times*** **comment on the COVID vaccine**:

- *“One of the effects of vaccination is that fully vaccinated people have a much lower risk of death from Covid, even if they are not completely immune*” ([Twitter](https://twitter.com/financialtimes/status/1419978085106126848) @FinancialTimes, July 27, 2021)
- [Why are fully vaccinated people testing positive for Covid?](https://www.ft.com/content/0f11b219-0f1b-420e-8188-6651d1e749ff) | by Oliver Barnes and John Burn-Murdoch, *Financial Times* (July 23, 2021)

**Zubin talks Malone in his recent podcast**: [Ep. 10: Dr. Robert Malone’s Joe Rogan Interview, Decoded – ZDoggMD](https://zdoggmd.locals.com/upost/1574469/malone-rogan-and-making-sense-of-it-all-the-vpzd-show) | Host ZDoggMD, The VPZD Show (January 20, 2022)

§

##### Marty Makary M.D., M.P.H. - Zubin Damania, M.D. - Monica Gandhi, M.D., M.P.H.

**Marty Makary M.D., M.P.H.**

Dr. Marty Makary is a Johns Hopkins professor and public health researcher. He is a member of the National Academy of Medicine, serves as Editor-in-Chief of the 2nd largest trade publication in medicine, called Medpage Today, and he writes for The Washington Post, The New York Times, and The Wall Street Journal. He is the recipient of the Business Book of the Year Award for his New York Times bestselling book [*The Price We Pay*](https://nam11.safelinks.protection.outlook.com/?url=https%3A%2F%2Fsmarturl.it%2Fthepricewepay&data=04%7C01%7Cp%40attiamedical.com%7C941394cd72c64b161e8808d9c266f76e%7C818179767cb4449aa341c29596a5fcc4%7C1%7C0%7C637754569798684779%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000&sdata=se5f85eHDb0ebTzUESYZgY%2Fm8A2Lu4WHqaQA1e85gCY%3D&reserved=0). He is a graduate of the Harvard School of Public Health, has served on the faculty of the Johns Hopkins School of Public Health for the past 16 years, and served in leadership at the World Health Organization.

**Zubin Damania, M.D.**

Zubin Damania, aka Zdogg MD, is a UCSF/Stanford trained internal medicine physician and founder of Turntable Health, an innovative primary care clinic and model for Health 3.0 that was part of an ambitious urban revitalization movement in Las Vegas spearheaded by Zappos CEO Tony Hsieh. During a decade-long career as a hospitalist at Stanford, Zubin led a shadow life performing stand-up comedy for medical audiences worldwide as a way to address his own burnout. His videos and live shows have since gone epidemically viral with nearly a half a billion views on Facebook and YouTube, educating patients and providers while mercilessly satirizing our dysfunctional healthcare system. The goal of his movement is to rapidly catalyze transformation by leveraging the awesome power of passionate and engaged healthcare professionals. [[zdoggmd.com](https://zdoggmd.com/about-z/)]

Facebook: [ZDoggMD](https://www.facebook.com/ZDoggMD)

Twitter: [@zdoggmd](https://twitter.com/zdoggmd)

Instagram: [@zdoggmd](https://www.instagram.com/zdoggmd/)

**Monica Gandhi, M.D., M.P.H.**

Monica Gandhi earned her M.D. from Harvard Medical School and did her internal medicine residency and ID fellowship at UCSF. After her residency, Dr. Gandhi completed a fellowship in Infectious Diseases and a postdoctoral fellowship at the Center for AIDS Prevention Studies, both at UCSF. She also obtained a Masters in Public Health from Berkeley in 2001 with a focus on Epidemiology and Biostatistics.

Dr. Gandhi’s current research program is on identifying low-cost solutions to measuring antiretroviral levels in resource-poor settings, such as determining drug levels in hair samples. Dr. Gandhi also works on pre-exposure prophylaxis and treatment strategies for HIV infection in women. .

Dr. Gandhi also has an interest at UCSF in HIV education and mentorship. Dr. Gandhi co-directed the “Communicable Diseases of Global Health Importance” course in the Global Health Sciences Masters program from 2008-2015, and serves as the overall Education Director of the HIV, ID and Global Medicine Division. She also served as the principal investigator of an R24 mentoring grant from the NIH focused on nurturing early career investigators of diversity in HIV research, is the co-Director for the Center for AIDS Research (CFAR) Mentoring Program, and is the Chair of the Advisory Board for the UCSF Building Interdisciplinary Research Careers in Women’s Health (BIRCWH). She directs the HIV/ID Consult Service at San Francisco General Hospital (SFGH) and attends on the inpatient Infectious Diseases consult service. [[UCSF Department of Medicine](https://medicine.ucsf.edu/people/monica-gandhi)]

Twitter: [@MonicaGandhi9](https://twitter.com/MonicaGandhi9?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)