# #240 ‒ The confusion around HDL and its link to cardiovascular disease | Dan Rader, M.D.

**Source:** [https://peterattiamd.com/danrader/](https://peterattiamd.com/danrader/)

---

Dan Rader is a Professor at the Perelman School of Medicine at the University of Pennsylvania, where he conducts translational research on lipoprotein metabolism and atherosclerosis with a particular focus on the function of high-density lipoproteins (HDLs). In this episode, Dan goes in-depth on HDL biology, including the genesis of HDL, its metabolism, function, and how this relates to atherosclerotic cardiovascular disease (ASCVD). He explains why having high HDL-C levels does not directly translate to a low risk of cardiovascular disease and reveals research pointing to a better way to measure the functionality of HDL and predict disease risk. He also goes into detail on the role of HDL in reverse cholesterol transport and the benefits this has for reducing ASCVD. Additionally, Dan discusses the latest thinking around the association between HDL cholesterol and neurodegenerative diseases and ends the conversation with a discussion of how the latest research on HDL provides a promising outlook for ongoing trials and future therapeutic interventions.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/danrader/the_Drive_public.png)

Play

#240 ‒ The confusion around HDL and its link to cardiovascular disease | Dan Rader, M.D.

#240 ‒ The confusion around HDL and its link to cardiovascular disease | Dan Rader, M.D.

1x15s30s

0:001:54:10

## We discuss:

- The lipidology of apoB and apoA [4:00];
- A primer on the high-density lipoprotein (HDL): genesis, structure, and more [9:30];
- How the lipoprotein system differs in humans compared to other mammals [20:00];
- Clarifying the terminology around HDL and apoA [25:30];
- HDL metabolism [31:45];
- CETP inhibitors for raising HDL-C: does it reduce CVD risk? [34:45];
- Why it’s so important to have hard outcome trials in the field of cardiovascular medicine [42:30];
- SR-B1: an HDL receptor important for cholesterol efflux [48:00];
- The association between HDL levels and atherosclerosis: are they causally linked? [53:15];
- How insulin resistance is impacting HDL, and how HDL-C provides insights into triglyceride metabolism [58:00];
- Disappointing results from the studies of niacin—a drug that raises HDL-C and lowers apoB [1:08:15];
- HDL lipidation, dilapidation, and reverse cholesterol transport [1:12:00];
- Measuring the cholesterol efflux capacity of HDL:  a better predictor of ASCVD risk than HDL-C? [1:22:00];
- A promising new intervention that may promote cholesterol efflux and reverse cholesterol transport [1:32:45];
- The association between HDL cholesterol and neurodegenerative diseases [1:34:00];
- Challenges ahead, a promising outlook, and the next frontier in lipidology [1:44:45]; and
- More

§

## Show Notes

**\*Notes from intro**:

- Dan Rader is a Professor of Molecular Medicine at the Perelman School of Medicine at the University of Pennsylvania, where he conducts translational research on lipoprotein metabolism and atherosclerosis
- His focus is on the metabolism and function of high density lipoproteins (HDLs)
- Dan has received numerous awards and has been elected to the American Society of Clinical Investigation, the Association of American Physicians, and the National Academy of Medicine
- He currently serves on the board of directors of the International Society of Atherosclerosis, the Board of External Experts at the National Heart Lung and Blood Institute, and the advisory board for the clinical research of the NIH
- This episode is the first time we focus our entire conversation around [HDLs](https://en.wikipedia.org/wiki/High-density_lipoprotein)
- Now, as any listener of this podcast will know, we have no shortage of content around lipids, and we focus a lot of that energy on the apoB side of the family
  - That is LDLs and  Lp(a), a subset of LDL
- HDL biology is much more complex than LDL biology, and we know so much less
- People generally think of HDL as the “good cholesterol”, but you have no doubt heard Peter rail on the stupidity of such a designation
  - But there is clearly something good about HDLs (as in the lipoproteins, not the cholesterol)
- In this discussion we really talk about everything from the biology of the HDL, its genesis, its origin, its metabolism, its life cycle, to its function
- We also talk about why it has been so complicated to use pharmacologic interventions on the HDL side of the equation to impact atherosclerosis
- Perhaps the greatest success of modern medicine, especially as it comes to cardiovascular disease, has been our ability to manipulate the apoB side of the equation as opposed to the apoA side of the equation
- In this episode we will get into terminology such as [apoA](https://en.wikipedia.org/wiki/Apolipoprotein_AI) in the context of HDLs
  - Which has no bearing whatsoever to apo- little a [apolipoprotein(a), the thing that of course defines a [Lp(a)](https://en.wikipedia.org/wiki/Lipoprotein(a))]
- We talk about the genesis of the HDL, its structure, its metabolism
- We talk about the differences between HDLs, [LDLs](https://en.wikipedia.org/wiki/Low-density_lipoprotein), the difference between the HDL measurements
- We explain the difference between HDL cholesterol versus apoA concentration versus HDL particle number
- We talk about the idea that having a high HDL means you don’t need to worry about cardiovascular disease and how that’s obviously going to be bunk
- We speak about [CETP inhibitors](https://en.wikipedia.org/wiki/CETP_inhibitor), which are a class of drug that have been repeatedly used to try to increase HDL cholesterol with the hopes that that would reduce cardiovascular disease
- We end the conversation around some of the new thinking around HDL and neurodegenerative disease (something Peter learned a lot about)
- [Tom Dayspring](https://www.linkedin.com/in/thomas-dayspring-md-facp-fnla-3aaa876) recommended Dan highly, and anytime Tom Dayspring says, “You should have so and so on the podcast to talk about anything that has to do with lipids,” Peter immediately pays attention

## The lipidology of apoB and apoA [4:00]

- Broadly speaking, there are two families of lipids‒ the [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B) family and the [apoA](https://en.wikipedia.org/wiki/Apolipoprotein_AI) family
  - We have spent much more time talking about the apoB family, and our understanding of its causal relationship to pathology is more clear

**Where do these two families fit into the border architecture of our existence?**

- Lipoproteins are these big complexes that evolved to transport lipids within the blood
- Lipids are like oil: they don’t mix well with water
  - Oil droplets float to the top of a puddle
  - We wouldn’t be able to transport lipids in the blood if we hadn’t evolved a mechanism to do that; and lipoproteins are that mechanism
- As their names suggest, lipoproteins have lipid in their core, and then they have proteins that dot the surface
  - The proteins allow them to be transported in very complex and sophisticated ways within the bloodstream
    - In terms of how they’re metabolized in terms of the receptors they bind to
    - In terms of the specific proteins and lipids that they carry
- Peter has talked a lot about apoB lipoproteins in previous podcasts; they’re really fabulous
- ApoB lipoproteins evolved to transport [triglycerides](https://en.wikipedia.org/wiki/Triglyceride) as a source of energy, from the gut to adipose and muscle and heart, as well as from the liver (during times when we’re fasting)
  - They’re very important in terms of causal relationship to atherosclerotic cardiovascular disease (ASCVD)
- [HDL](https://en.wikipedia.org/wiki/High-density_lipoprotein) is a very complex lipoprotein
- HDL doesn’t have this key protein apoB
  - This is why we often refer to the apoB-containing lipoproteins and HDL (the other half)
- HDL is characterized by a different protein called [apoA-I](https://en.wikipedia.org/wiki/Apolipoprotein_AI)
- HDL also transports cholesterol and other complex lipids

***Lipoproteins are lipid transport vehicles within the blood; that is the function they evolved to do***

- Peter adds, “*Unlike glucose, electrolytes (things that we take for granted that are water soluble), we use our circulatory system as the freeway to move these things around. Unfortunately, because of the insolubility of both cholesterol, triglyceride, lipids, etc., we have to come up with this more complicated system.*”

**The nomenclature gets confusing; clarify the difference between apoA and Lp(a)**

- When you talk about [apoA](https://en.wikipedia.org/wiki/Apolipoprotein_AI), it’s important to realize we are not talking about [Lp(a)](https://en.wikipedia.org/wiki/Lipoprotein(a))
- Lp(a) is not the topic of today’s discussion; this is totally different
- ApoA has a capital A after it, and the most important one is **ApoA-I**

**Technically there are two lineages of apoBs**

- [ApoB-100](https://en.wikipedia.org/wiki/Apolipoprotein_B#Molecular_biology) is what we refer to virtually all the time we say apoB
- This is in contrast to [apoB-48](https://en.wikipedia.org/wiki/Chylomicron#Nascent_chylomicrons), which is on chylomicrons used to transport lipids/ energy from the gut

## A primer on the high-density lipoprotein (HDL): genesis, structure, and more [9:30]

**The genesis of the high density lipoprotein (HDL)**

- HDL metabolism is perhaps an order of magnitude even more complex than LDL
- Peter agrees, “*It is hands down the most confusing stuff in the lipid space*”
- ApoA-I as the key protein with HDL
- The analogy is to apoB [on LDL] as Peter alluded to
  - Although one big difference is apoB stays with the LDL particle throughout its lifetime
  - ApoB gets made by the intestine as B48 or the liver as B100, and it stays with that particle
  - Each LDL has one molecule of this huge apoB protein, and then it ultimately gets taken up mostly by the liver after its time in the blood
- ApoA-I is also made by the intestine and the liver
- It is a core protein of HDL, but unlike apoB, there are several molecules of apoA-I on any given HDL particle (anywhere from 1-4, maybe more)
- ApoA-I doesn’t stay with the particle, it can exchange onto other types of HDL particles, but even sometimes onto apoB lipoproteins
- In the last decade we have learned that apoA-I is a secreted protein put into the blood by either the intestinal enterocyte or the hepatocyte in the liver as a free protein (more or less)
- One of the first steps that has to happen for HDL to be formed is that once HDL comes out of the cell, it engages with a key transport protein called [ABCA1](https://en.wikipedia.org/wiki/ABCA1)
  - ABCA1 takes lipid, cholesterol, [phospholipids](https://en.wikipedia.org/wiki/Phospholipid) from the cell and exports them to newly secreted apoA-I

***ApoA-I has to acquire lipid soon after it has been secreted in order for nascent or early HDL to start forming; this is the first step in HDL biogenesis***

- We’ll come back to this when we talk about genetics because humans who lack ABCA1 have virtually undetectable HDL
  - They can make plenty of ApoA-I but cannot protect it with lipid once it’s secreted, and so it “*goes like a rocket from the blood*”

**What other phenotype do people without ABCA1 have?**

- This disorder is called [Tangier disease](https://www.ncbi.nlm.nih.gov/books/NBK549920/); studying rare human genetic disorders tells us a lot about what specific proteins/ genes are doing
  - It’s named for a small, flat, bizarre island in the middle of the Chesapeake Bay where the first patient was discovered
- This disorder is primarily associated with accumulation of cholesterol in macrophages throughout the body (tonsils and spleen)
  - Cholesterol accumulates in places where there are a lot of macrophages
- People with this disease will have orange colored tonsils
- They have big spleens that sometimes rupture, they have big livers (because there are a lot of macrophages and macrophages-like cells in the liver)
- They also have some neurologic type issues, especially neuropathy (which we’ll leave to later when we start talking about HDL and its relationship to the nervous system)
- They may or may not have some increased risk of atherosclerotic cardiovascular disease, but the relationship between HDL and atherosclerosis is quite complex

**If you were to compare a mature, garden-variety HDL particle to an LDL particle, what is the difference and size and why is one called high density versus low density?**

- The name is a historical artifact of how lipoproteins were discovered and named
- HDLs are much smaller, in the neighborhood of 1/5th to 1/10th the size of an LDL, and are much smaller than triglyceride-rich lipoproteins
- Lipoproteins contain lipid, and lipid floats, it creates buoyancy within particles
- The way lipoproteins were discovered is that when you spin plasma, the lipoproteins spin to spin to the top at different rates under different forces
  - The low density lipoproteins have more lipid (they are bigger), and they spin to the top more easily
  - The high density lipoproteins also have lipid, but they don’t spin to the top as quickly or easily; their density is higher than LDL
- As an artifact of history, after LDL was discovered, something even lighter (that spun up more easily) was discovered; this was called [VLDL](https://en.wikipedia.org/wiki/Very_low-density_lipoprotein)
- Lastly, [chylomicrons](https://en.wikipedia.org/wiki/Chylomicron) are the huge lipoproteins that come from the intestine
  - They are so light and buoyant that instead of calling them very low, they were simply given the name chylomicrons

**What happens after the nascent HDL particle gets formed**

- The nascent HDL has apoA-I, phospholipids, and free cholesterol
- Cholesterol itself can have a fatty acid attached to it (attached to the hydroxyl moiety), and this is what we call a [cholesterol ester](https://en.wikipedia.org/wiki/Cholesteryl_ester)
  - A cholesterol ester is even more [hydrophobic](https://en.wikipedia.org/wiki/Hydrophobe) (or oily) than free cholesterol
- A critical part of the HDL maturation process is to have a fatty acid attached to the cholesterol after the nascent HDL has been formed
  - The key enzyme responsible for that is the [lecithin-cholesterol acyltransferase (LCAT)](https://en.wikipedia.org/wiki/Lecithin%E2%80%93cholesterol_acyltransferase), and it rides on that nascent HDL particle
  - LCAT takes a fatty acid from one of the phospholipids on the particle and transfers it to to cholesterol, creating the cholesterol ester
- The cholesterol ester moves to the center of the HDL particle because it wants to be by itself, and not interacting with water
  - This starts to form the core of the mature HDL particle

**People who lack LCAT due to a rare genetic condition**

- People with [LCAT deficiency](https://en.wikipedia.org/wiki/Lecithin_cholesterol_acyltransferase_deficiency) have extremely low levels of HDL (around 10), though not quite as low as Tangier disease (around 1)
- They simply can’t form mature HDL particles
- They have very low HDL cholesterol (but also have low apoA-1 because it’s more rapidly removed from the blood)

**The mature HDL particle is what we measure as HDL cholesterol in people**

- Most of the cholesterol we’re measuring is the cholesterol ester in the core of the particle
- When you don’t make cholesterol ester, then apoA-I is rapidly removed from the blood
  - The kidneys filter and degrade it
- The biggest issue with LCAT-deficient patients is they get renal disease, a serious, progressive, chronic kidney disease
  - This usually leads to a kidney transplant

## How the lipoprotein system differs in humans compared to other mammals [20:00]

**Are there any insights we have into this (or parallel systems) in other mammals (dogs, mice, etc)? A lot of these animals have a very different apoB side of the equation, and Peter is curious about apoA-I?**

- ApoA-I is highly conserved among mammals
- In mice, more than 90% of the cholesterol in the blood is in HDL
  - This is true for all mammals
- Once you start getting below mammals, things change in terms of lipoprotein metabolism
- There are thoughts that HDL is the primordial lipoprotein that evolved early as a transport system for lipids within circulatory systems in lower species
  - And that the apoB system evolved subsequently
- Peter has never heard a convincing argument for why humans have apoB, when it seems that every other species gets away without it
- Many animals (mice, dogs, pics, rabbits) make apoB in both the gut and liver
  - So it’s not that these species don’t have apoB
  - The difference is in their steady state plasma levels
  - Their apoB system is revved up so apoB-containing particles are cleared out of circulation much more quickly
  - The apoB particles still serve a similar role of transporting triglycerides as a source of energy to tissues in the body
  - Humans are not nearly as efficient at clearing the apoB-containing particles, and they hang around especially as LDL and ultimately lead to [ASCVD](https://en.wikipedia.org/wiki/Coronary_artery_disease)
- Mammals evolved apoB to efficiently capture fats in the diet for energy purposes
  - That’s what chylomicrons allow us to do
  - And during fasting, we have to be very parsimonious about parceling out the available fat we have in our adipose stores back out to heart and muscle to be able to have as a source of energy
    - The liver and apoB does this

> “*Now unfortunately, in the modern times, the apoB system is mostly a problem, not something we need*”‒ Dan Rader

**Peter’s takeaway**‒ It’s not that we don’t need apoB, but if we could clear it more efficiently (like primates and other mammals) and walk around with 20 mg/dL (instead of 100 mg/dL), that would be the difference between getting atherosclerosis in our lifetime and never getting it

- Absent lifestyle things that raise apoB, it simply increases with aging
  - Peter Libby has written eloquently about this‒ children and neonates have apoB concentrations similar to that of other animals
  - As we age, the apoB concentration goes up; we are less efficient in clearing apoB from circulation

## Clarifying the terminology around HDL and apoA [25:30]

**ApoA nomenclature clarification**

- In addition to [apoA-I](https://en.wikipedia.org/wiki/Apolipoprotein_AI), there are two other apoAs that we know about‒ [apoA-IV](https://en.wikipedia.org/wiki/APOA4) and [apoA-V](https://en.wikipedia.org/wiki/APOA5) (Dan doesn’t know what happened to apoA-III)
- We don’t know what apoA-IV does
- ApoA-V has an important role in stimulating [lipoprotein lipase](https://en.wikipedia.org/wiki/Lipoprotein_lipase) in the metabolism of triglyceride rich lipoproteins
  - It rides on HDL and also on triglyceride-rich lipoproteins
  - People who lack apoA-V have really high triglycerides and are at major risk for ASCVD
- ApoA-V was named apoA because it was discovered on HDL, but it’s primary role is in triglyceride-rich lipoprotein metabolism
- ApoA-V is stored within the blood on HDL, but when we eat a fatty meal, it transfers off to the triglyceride-rich lipoproteins
  - Where it serves a role of promoting the hydrolysis of triglycerides

**Think of the HDL molecule as a lipoprotein and a platform for transport in the blood of all sorts of proteins and lipids**

- HDL also gets transferred off to other things, such as the apoB-containing lipoprotein
- Dan points out, “*A general concept for HDL that we’ll keep coming back to is this platform for all sorts of things that are doing different things that involve not only lipid metabolism but host defense and other things it evolved to do as a platform for transporting things within the blood.*”
  - This explains part of the complexity of the system
  - It is much more dynamic than what we see on the apoB side
- With apoB, it is produced in the liver and it’s with our for life, while HDL is swapping and carrying things around that it doesn’t really use (but it loans them out)

**The numbering of the HDL particles is also confusing**

- Peter uses Boston Heart Labs with his patients and results might say things like HDL1, HDL2, HDL3, “*What is the relationship between that nomenclature and the apoA-I, apoA-II, apoA-IV, etc.?*”
- Dan responds, “*This is ridiculously complex… the short answer is there’s no relationship*”

***The numbering of the apoA lipoproteins is totally independent of the numbering of the HDL particles***

- The two main “subclasses” of HDL are HDL-2 and HDL-3
  - These are different sizes and different densities of HDL that were originally isolated/characterized by centrifugation and their float properties
  - HDL-2 is a little bigger, and HDL-3 is a little smaller
  - HDL-2 has mostly four molecules of apoA-I, while HDL-3 has mostly three molecules of apoA-I
- To make this more complicated, there are other ways of subfractionating lipoproteins
  - [NMR](https://en.wikipedia.org/wiki/Nuclear_magnetic_resonance)-type methodology doesn’t use HDL-2 and HDL-3 (which is a little outmoded now)
  - Instead NMR uses things like very large HDL, large HDL, medium, HDL, small HDL, and very small HDL

***HDL certainly comes in a whole series of sizes and densities that can be isolated by these different methodologies***

- Dan notes, “*That there has been a cottage industry of trying to relate these different fractions of HDL to cardiovascular risk in a way that might vie us some advantages in terms of trying to predict risk*”

> “*I’m not very compelled that fractionating HDLs gives much clinically valuable information that allows us to predict risk*”‒ Dan Rader

- This is in contrast to the apoB-containing lipoproteins where the smaller, denser LDL particles do have a relationship to increased risk
- HDL fractionation is fascinating for understanding the HDL biology and metabolism, but it is relatively unimportant from a clinical relevance standpoint
  - Peter is relieved to hear this because in 2016 he stopped paying attention to any of the HDL fractionation metrics, and he was wondering if this was right or if he needed to change their clinical practice

## HDL metabolism [31:45]

**Lipases**

- Once HDLs are formed and have cholesterol ester they are mature HDLs and have a complex metabolism in the blood
  - There is a whole set of different size and density HDL
  - Complex metabolism occurs on mature HDLs once they are in the blood
- HDLs are acted upon by lipases
  - Lipoprotein lipase is an example, and it’s critically important for triglyceride metabolism and energy metabolism
- Two close cousins to lipoprotein lipase are (1) hepatic lipase and (2) endothelial lipase
- As their names suggest, they are each made in different places, but they both chew on phospholipids on the HDL
  - This results in modification of the phospholipid composition of the HDL particle, and each has different effects
  - These change the protein composition of the HDLs in ways we don’t fully understand
  - They also have other important biological effects that we don’t fully understand
- These lipases evolved for some reason ( Dan will come back to when we talk about the CNS at the end)

***The one thing Dan knows is that lipases are really critical for HDL metabolism***

**CETP**

- Another protein that is very relevant to HDL is [cholesteryl ester transfer protein (CETP)](https://en.wikipedia.org/wiki/Cholesteryl_ester_transfer_protein)
- CETP transfers cholesteryl esters between apoB-containing lipoproteins and HDL
- CETP is a major modifier of the HDL particle in terms of its size and composition
- People who lack CETP have hugely elevated HDL cholesterol levels (way over 100)
  - That told us that CETP siphons cholesterol out of HDL, and when you don’t have CETP, you have a lot more cholesterol in HDL
- Mice don’t have CETP; this is one difference between mice and humans
  - They have a lot more HDL cholesterol relative to apoB because they lack CETP

## CETP inhibitors for raising HDL-C: does it reduce CVD risk? [34:45]

**How does this relate to the standard lipid panel?**

- Peter notes that the listener is going to be saying, “*The only thing I know is when I go to the doctor, the doctor says, ‘My good cholesterol is high. I’m in good shape*.’”
- The standard lipid panel spits out a bunch of numbers
  - Total cholesterol
  - LDL cholesterol
  - HDL cholesterol
  - VLDL cholesterol
  - Non-HDL cholesterol
  - Triglycerides
- If the lab is competent and they’re using direct measurements then your HDL-C, LDL-C, and VLDL-C should add up to your total cholesterol
  - Your non-HDL-C should be the same number as your total cholesterol less your HDL-C
- Peter points out that HDL is not a laboratory metric, it is a lipoprotein
  - The laboratory metric is HDL-C (HDL cholesterol)
  - Or if the lab is using [NMR](https://en.wikipedia.org/wiki/High-density_lipoprotein#NMR_measurements), HDL-P (the HDL particle number)
  - ApoA-I is an analogy to measuring apoB (for enumerating HDL and LDL particles respectively)

**Units of HDL cholesterol**

- Dan mentioned earlier that people deficient in CETP have HDLs over 100; that’s 100 mg/dL
- That observation goes back to the late ‘70s- early ‘80s; some of the earliest [Framingham cohorts](https://en.wikipedia.org/wiki/Framingham_Heart_Study) which observed the risk of ASCVD in five cities
- What came out of the [first Framingham cohort](https://www.amjmed.com/article/0002-9343(77)90874-9/pdf) was that higher HDL cholesterol (HDL-C) was better than lower HDL-C
  - Low HDL-C was 4x greater as a predictor of ASCVD than high LDL-C
  - This is a big part of why HDL cholesterol became known as the “good cholesterol” and LDL became known as the “bad cholesterol”
- It wasn’t long before companies said, “*We know that if CETP is inhibited (this enzyme is inhibited) HDL cholesterol goes up. That must be a good thing, right?*”
- And that came from the observation that people who genetically lack CETP have hugely elevated levels of HDL
- But if you pharmacologically inhibit CETP, it does raise HDL but the story is not simple from there

**CETP inhibitors**

- The first [CETP inhibitor](https://en.wikipedia.org/wiki/CETP_inhibitor) was [torcetrapib](https://en.wikipedia.org/wiki/Torcetrapib) (made by Pfizer)
- Peter notes, “*You could take a skeptical view of the trial, which was LIPITOR was about to go off patent and so they came up with a trial that was LIPITOR by itself versus LIPITOR combined with the CETP inhibitor… This was probably early 2000’s*”
  - Peter was in his surgical residency, so he was only tangentially interested, but his family history for ASCVD was high
  - He remembers thinking this would be super
- But this combination treatment did *not* make ASCVD risk better, it made it slightly worse; it was a bombshell
- Dan points out that genetics did predict what happened
  - Pharmacologic inhibition of CETP is extraordinarily effective at raising HDL a lot; it put people over 100 mg/dL for HDL cholesterol

***Several trials of different CETP inhibitors, not only didn’t show benefit, but showed a n actual adverse effect***

- Literally more people died, but that adverse effect was due to off-target effects of the drug, not due to CETP inhibition itself
  - It was a bad drug, but it didn’t kill the field
  - People wanted to get a clean CETP inhibitor and see what it really does
- But 16 years since that trial was halted, we still don’t have a CETP inhibitor on the market
  - It’s still in development
- Three additional CETP inhibitors were then taken into late stage clinical development, including large cardiovascular outcome trials
  - For one drug, the effect was flat (it didn’t hurt, but it didn’t help either)
  - The second one was stopped early because it didn’t look like it was helping
  - The third one was followed through but showed a disappointing 9% reduction in cardiovascular events
- Dan points out that it lowered LDL and apoB by 9%, but this was not exciting, and the drug was not taken further in terms of seeking approval
- A fascinating side note‒ one of these drugs that failed in clinical trials ([dalcetrapib](https://en.wikipedia.org/wiki/Dalcetrapib)), a detailed genetic study was done post hoc, and it found that there were individuals with a particular genetic variant that benefited from the drug
  - That led to a subsequent attempt to do another trial focused on people with that genotype
  - The [results](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9565632/) were reported last year as a negative trial

***Dan summarizes:***

- “*This has been a long saga of using CETP inhibition to raise HDL as a way to reduce risk*”

-However, Dan says that the most important thing that came from this research is the following:

- “*The HDL cholesterol itself is not directly and causally protective against atherosclerotic cardiovascular disease*.”
- There are a lot of nuances there, but Dan feels pretty confident making that statement

> “The HDL cholesterol itself is not directly and causally protective against atherosclerotic cardiovascular disease.” —Dan Rader

## Why it’s so important to have hard outcome trials in the field of cardiovascular medicine [42:30]

**The first lipid-lowering drug**

- Peter recalls that the first lipid-lowering drug was introduced in the US around 1959
  - [Triparanol](https://en.wikipedia.org/wiki/Triparanol) inhibits the enzyme needed for the last step in cholesterol biosynthesis ([24-dehydrocholesterol reductase](https://en.wikipedia.org/wiki/24-Dehydrocholesterol_reductase)) that converts desmosterol to cholesterol
  - This drug lowered cholesterol, but bear in mind this was before we knew anything about the subfractions of cholesterol
- Some of the early work of [Ancel Keys](https://en.wikipedia.org/wiki/Ancel_Keys) shows that if you compared people who had very, very high levels of total cholesterol to people with very, very low levels, there was a difference in cardiovascular outcomes
  - But there was no intervention to test that
- This drug (triparanol) lowered total cholesterol; it would have likely lowered LDL-C and apoB
  - It got approved on the basis of that without outcome trial results
  - But 8-10 years later there was enough post-surveillance to see that even though it lowered cholesterol, it was increasing cardiovascular mortality
  - So the drug was pulled off the market
- Peter and [Tom Dayspring](https://www.linkedin.com/in/thomas-dayspring-md-facp-fnla-3aaa876) have speculated that the spike in desmosterol was the problem; that you might be trading one problem for a worse problem
- Dan is only peripherally familiar with that story, but there has been a ton of research on desmosterol over the last several years
  - He agrees that increasing desmosterol might explain the increased cardiovascular mortality

**Tangent‒ it has become in vogue to use clomiphene (brand clomid) for testosterone replacement in men**

- It’s quite effective
  - If you give [clomiphene](https://en.wikipedia.org/wiki/Clomifene), you are telling the pituitary to make a lot of LH and FSH which is telling the testes to make a lot of testosterone
  - This has the advantage in the short-term of preserving testicular function (unlike giving exogenous testosterone, which suppresses testicular function)
  - For the short-term, Peter thinks this probably isn’t a bad thing
    - If a guy was still considering reproduction
    - Or this was a bridge treatment between testosterone
  - It’s an [off-label](https://en.wikipedia.org/wiki/Off-label_use) use
- In patients taking clomiphene, Peter always measures desmosterol, lathosterol, campesterol, and sitosterol when he measures the patient’s cholesterol levels and he noticed how high the desmosterol levels were getting in those patients
  - He quickly figured out that clomid (generic clomiphene) was doing this
  - After taking patients off the drug, it could take a year for their desmosterol levels to return to normal
- About four years ago, Peter stopped using clomid
- But now the use of that hormone has gone through the roof with lots of clomid clinics opening up, and Peter doesn’t understand why someone hasn’t studied this
- Peter doesn’t think using clomid for a couple years is going to be problematic; nor would it be problematic for women using it for [IVF](https://en.wikipedia.org/wiki/In_vitro_fertilisation)
- But if a guy is on it for 10 years and his desmosterol levels are going up by 20-fold, that would be concerning
  - He doesn’t know how high the desmosterol levels were in the triparanol trial
  - But the assumption is that triparanol and clomiphene both interfere with the same enzyme

> “*The point of that long-winded story is things can make a lot of sense until they don’t, right?*”‒ Peter Attia

**Back to CETP inhibitors**

- Dan points out that there is still one CETP inhibitor in clinical development, [obicetrapib](https://www.nature.com/articles/s41591-022-01936-7)
  - It’s much more effective at lowering LDL and apoB
- Dan notes, “*We now no longer think that raising HDL cholesterol with CETP inhibition is going to help you. We don’t think it hurts you, but we don’t think it’s going to help you. But we do think that there’s still merit.*”
- We know there’s merit to lowering LDL-C and apoB, and perhaps the CETP inhibitor could be part of the armamentarium to do that

## SR-B1: an HDL receptor important for cholesterol efflux [48:00]

- Peter notes that after the third failure of a CETP inhibitor, it seems that making it harder for the HDL particle to efflux it’s cholesterol might actually be problematic
  - Even though on the surface a higher level of HDL cholesterol looks good
- Peter compared HDL to a room
  - You know something awesome is going on in that room
  - But if you can’t measure all the ins and outs, could it be that the people in that room are stuck because the door is locked
  - He asks, “*Is there any merit to that sort of thinking around the different ways in which one might boost HDL cholesterol and how some of those could actually be deleterious if they prevent function?*”
- Dan thinks there is, but it’s probably not relevant to CETP

**SR-B1**

- [SR-B1](https://en.wikipedia.org/wiki/SCARB1) is another key protein; it’s the major HDL receptor
  - The equivalent of the [LDL-receptor](https://en.wikipedia.org/wiki/LDL_receptor) for LDL
- SR-B1 is a receptor that is on a lot of cells, but the liver is the most important with regard to HDL
  - The liver binds the HDL particle and basically sucks the cholesterol ester out of the HDL particle, and then it releases the cholesterol-depleted HDL back into the circulation

**Dan uses the analogy of a garbage truck (it’s a very simplistic view of HDL)**

- To a certain extent, HDLs functions like garbage trucks that are picking up things
  - Trash in places where you don’t want it and returning it to the liver
  - Dumping it off via SR-B1, and then going back, now empty, to do more of its role
- It’s more complicated than that, but that’s an analogy

**Humans that lack SR-B1**

- Humans that lack SR-B1 have very high HDLs because they can’t unload the garbage trucks
- They have increased risk of heart disease because they are not efficiently unloading HDLs
  - Very similar to Peter’s analogy of a locked room
  - You’re not clearing the HDL and doing that normal process of recycling the trucks back to the periphery to do what they need to do
- This is the best example of the constipation of this system leading to high HDL and paradoxically increased risk

***The interpretation would be that you never want to develop a SR-B1 inhibitor***

- It would raise HDL quite a lot, but it wouldn’t protect against heart disease and would probably hurt people
- Peter remembers the first time Tom shared a case study of a patient with defective (but not completely absent) SR-B1
  - Her LDL cholesterol was 100 mg/dL, but her HDL cholesterol was 150 mg/dL
  - She had high cholesterol, but initially people assumed it was not of concern because the fraction that was HDL cholesterol was so high
  - On further examination, she had very, very advanced atherosclerosis for a woman of her age
  - He doesn’t see this often
- In Peter’s practice they look for this when they see people with HDL cholesterol higher than 90 mg/dL

**When would you recommend that somebody go and get checked out for a genetic deficiency there?**

- AR-B1 deficiency is not common
- Dan has had a huge project for a long time, collecting consenting people with extreme high HDL with the goal of trying to determine the underlying genetic cause
- They found a few of the SR-B1 folks, but most of them don’t have any identifiable gene you can point to and explain their high HDL level
- HDL is very heritable, meaning that there’s a lot of genetic determinants of HDL
- But it’s more about so-called [polygenic inheritance](https://en.wikipedia.org/wiki/Quantitative_trait_locus#Quantitative_traits) where multiple different genes (including SR-B1) contribute to HDL levels
  - But not major genetic defects
  - More common variants
- Some of the things we’ve been talking about (including CETP and ABCA1) contribute to the heritability of the HDL cholesterol

## The association between HDL levels and atherosclerosis: are they causally linked? [53:15]

**Clinical implications**

- It’s clear to Dan that high HDL is not uniformly associated with protection
- There was a [recent paper](https://pubmed.ncbi.nlm.nih.gov/33961844/) showed in people of African ancestry who tend to have higher HDL, the high HDLs are not protective and may even be associated with risk

**Dan’s advice**‒

- If you have high HDL don’t get yourself sequenced to see if you’re deficient in SR-B1, this is very rare
- Never use high HDL as a reason for not using a statin or some other LDL-lowering therapy

**Peter touches on this in his book**

- He cites two [Mendelian randomization](https://en.wikipedia.org/wiki/Mendelian_randomization) studies that look at this in some detail [see the selected links section at the end]
  - This is a technique where you look for genes that impact traits that you are interested in
- In this case, HDL is very genetic
  - There are sets of genes that predispose people to having very high HDL versus very low HDL cholesterol
- Because these genes are randomly occurring, you can look at that as a natural experiment
  - You can look at the spreading (or skatering) of those genes and how ASCVD outcomes are affected

***It turns out that low HDL cholesterol is not causally linked to atherosclerosis and genetically high HDL cholesterol is not causally linked to protection from ASCVD***

- Peter thinks these are very important findings and speaks to why you can’t use high HDL cholesterol as a reason not to treat other risk factors
- The idea of protective high HDL-C persists, and this is one of the top three most vexing discussions Peter has with other physicians
  - They will say, “*I know his LDL-C is 140 mg/dL but his HDL is 80… his ratio of LDL to HDL is such and such and therefore, I don’t need to treat him*”
- Dan agrees, high HDL is never a reason not to treat someone who would’ve otherwise merited treatment
- He wants to make it clear that there are lots of people who are on the fence about whether to start a statin who have borderline LDL, and he looks at the whole patient
  - He looks at their calculated risk and other risk factors
- A *low* HDL in the setting of someone who you’re on the fence about treating could contribute toward, “*Yes, I’m going to treat this person*”
- In people of African ancestry we have to be a little bit more careful about using HDL as a predictor (see below)
- Peter recalls that the relationship between low cholesterol is the HDL2 fraction and association with insulin resistance (we’ll come back to this phenotype)
- Peter notes, “*In non-African American patients, the ratio of triglyceride to HDL cholesterol (when both are in milligrams per deciliter) is reasonably associated with insulin resistance… the higher the ratio, the more insulin resistant they are*”
  - This is not helpful for people of African ancestry
  - This ratio is driven up by an increase in triglycerides and a reduction in HDL-C

## How insulin resistance is impacting HDL, and how HDL-C provides insights into triglyceride metabolism [58:00]

- We’ve spent hours on the podcast talking about why insulin resistance would be associated with high triglycerides, but we haven’t done the reverse

***What is it about insulin resistance that drives down HDL2?***

- The analogy Dan likes to make is that HDL cholesterol is for cardiovascular risk factors (while not causally related to disease) as [HbA1C](https://en.wikipedia.org/wiki/Glycated_hemoglobin) is for insulin resistance
- Dan describes HDL as “*An integrator of information related to insulin resistance*”
  - Related to triglycerides, related to inflammation (when it’s low), it’s telling you something about cardiovascular risk
  - Even though HDL itself it isn’t directly impacting on risk
- Dan thinks one of the big issues with HDL cholesterol is that it’s an inverse barometer of triglyceride efficiency of triglyceride metabolism
- You can only learn so much from measuring a fasting triglyceride after a 12-hour overnight fast
  - It’s useful, it’s the way we do it in terms of lipid panels
  - But a lot happens after a fatty meal, and a lot of that action is basically over in most people by 12 hours
- Some people are extraordinarily effective at clearing their dietary fat, and others are not
  - But their fasting triglycerides may not necessarily reflect that
  - HDL cholesterol does reflect that
- There is a complex, frequent interaction and exchange between triglyceride-rich lipoproteins and HDL with the net effect being the higher the triglycerides at any given time, the lower the HDL is (as a result of the complex interactions)

**Dan does a lot of experiments where he brings people in and gives them a high-fat milkshake**

- They draw blood at multiple timepoints after that milkshake and measures triglycerides and all sorts of other things

> “*People differ a lot in their response to that high fat milkshake challenge*”‒ Dan Rader

- The higher that triglyceride goes (the area under the curve), the lower the HDLs are
  - The relationship is extraordinarily strong
- So just like HbA1c, HDL cholesterol is a much better read out of the 24-hour triglyceride metabolism than the overnight fasting triglyceride measurement is
  - To complete the analogy, that’s sort of why HbA1c is better than fasting glucose levels [as a metric of insulin resistance]

> “*I’ve never heard that before, and if I learn nothing else on this podcast, Dan, that is hands down the most amazing thing I have learned, not just today, but… potentially this month. That is super fascinating*.”‒ Peter Attia

- People on this podcast have heard Peter gripe over the lack of integral functions in biology
  - Coming from a background in math and engineering, he loves integrals
- As imperfect as the A1C is, it is an integrator, and it’s so hard to find integrators
- Ferritin does it a little bit for iron, but not nearly as well
- The holy grail would be to find an integral of something like [mTOR](https://en.wikipedia.org/wiki/MTOR) activity

**Questions about this milkshake tolerance test**

- You bring someone into the lab in the morning and they’re fasted
- You measure their HDL-C and it’s 50 mg/DL
- You measure their triglycerides and it’s 100 mg/dL
- Most people would say, “*Oh that’s great. This person looks super healthy*.”
- You give them a high fat shake and after 30 minutes start measuring from their blood every couple minutes
  - Most people would not be surprised to learn that the triglycerides will go through the roof (400-500 mg/dL)
  - But this is highly variable from person to person
  - And highly dependent on the meal
- In this experiment, you’re giving them something to elicit the biggest triglyceride response
  - Let’s say their triglycerides go all the way to 400 before they start to come down, and that generates an area under the curve
- You could integrate that on the curve

**Can you give realistic values for what the HDL cholesterol would do during that period of time?**

- The HDL cholesterol definitely dips during that time in a way that’s roughly proportional to the triglyceride levels, but not anywhere near the same degree of magnitude
- It’s starting lower, but also the dynamics of its turnover are very different
- The key point here is HDL is not just an integrator acutely over that meal, but chronically
- In this example, the HDL cholesterol might go from 40 to 38 or 37, which doesn’t sound like a lot after that one meal
- But the repeated meals that the individual is eating that are high fat and that repeated triglyceride excursion has a more chronic effect
  - A little like glucose and HbA1c that keeps taking the HDL down over time until you get to a new steady state
- So, the acute effect on the HDL is real, it’s modest
- The chronic effect on the HDL of that abnormal postprandial triglyceride metabolism is quite substantial, and that’s why HDL is a good integrator of this effect
- Peter thinks this probably captures some of what’s happening outside of the meal
  - Just as hemoglobin A1C doesn’t only reflect what would be captured in an oral glucose tolerance test, it captures what’s happening over 90 straight days when you’re eating, when you’re not eating
- Dan adds, “*And that’s also why there’s a very strong statistical relationship between fasting triglycerides and the HDL. So, the fasting triglycerides themselves are still affecting HDL metabolism. It’s just that the* [*postprandial*](https://en.wikipedia.org/wiki/Prandial) *part is also a key component.*”

**Reiterate the lagging nature of HDL cholesterol through HDL biology to what’s happening with the efficiency of lipid partitioning by considering a hypothetical experiment**

- Lagging nature refers to the integrating over time
- Say you have two people who are exercising, and they are very similar except one is very insulin *resistant* and one is insulin *sensitive*
- The **insulin resistant person** is going to have a higher level of insulin
  - They’re going to have a more difficult time oxidizing free fatty acids
  - As energy demand goes up from the muscle, they are more likely to utilize glycogen as opposed to utilizing triglycerides
  - You might notice more fat in their liver, even when they’re not eating
- Peter asks, “*What is the HDL doing in those two scenarios?*”
- The simplest most direct model is that the HDL is reflecting the 24-hour excursions and triglycerides
- There are almost certainly other components of metabolism that the HDL is integrating and reflecting, particularly in the complex insulin resistance world
- We know insulin resistance has a lot of effects other than affecting triglycerides, and insulin resistance
  - Insulin resistance has effects that are affecting and are reflected by the lowering of HDL, though Dan can’t tell you is exactly what those are
  - That is still a topic of investigation
- One hypothesis involves [adiponectin](https://en.wikipedia.org/wiki/Adiponectin) (an adipokine secreted by fat that has an inverse relationship to insulin resistance)
  - People who are insulin resistant have lower levels of adiponectin than people who are more insulin sensitive
  - And adiponectin itself appears to have some direct effect on HDL metabolism in the right direction
  - We could talk about it possibly by tweaking the liver in ways that then the liver affects HDL

***The data still are not completely solid, but another way that insulin resistance is impacting HDL through adiponectin secretion, affecting HDL metabolism in a way that’s completely different than the triglyceride hypothesis that Dan just put forth***

- Peter remarks that he used to measure adiponectin and leptin levels, but it’s one of those things that he stopped measuring

**Do you think adiponectin is a helpful biomarker, independently?**

- It’s fascinating to try to put together these metabolic pathways
- In terms of its utility as a clinical marker, Dan is a little bit skeptical
  - He’s not sure how he would use it to guide clinical care
- This was where Peter ended up too; he gets more actionable insight out of other metrics

## Disappointing results from the studies of niacin—a drug that raises HDL-C and lowers apoB [1:08:15]

**Niacin raises HDL cholesterol and lowers apoB**

- It modestly lowers triglycerides, apoB, LDL, and Lp(a) by 15-20%
- Dan remarks, “*Peter, I just chuckled because niacin is one of these areas where we as lipidologists and me personally have to really eat a bit of crow*.”
- There was a time when Dan prescribed niacin to a lot of patients, primarily with the idea that the only thing he had to do was raise HDL
  - He thought it was a nice broad spectrum, lipid-lowering drug
  - Not to be used in place of but on top of a statin for people with certain lipid profiles (mostly high triglycerides and low HDL)
- As Peter pointed out, clinical trials really are a cornerstone of cardiovascular medicine
- The [AIM-HIGH trial](https://www.nejm.org/doi/full/10.1056/NEJMoa1107579) (which was very well done) didn’t show much benefit of niacin
- Another [trial run by Merck](https://www.nejm.org/doi/full/10.1056/NEJMoa1300955) with a drug helped to potentially address some of the issues with niacin was performed
  - This was a large, very well powered trial
  - It also had really minimal or very disappointing effects on reducing cardiovascular events

> “*Essentially those two trials killed niacin*”‒ Dan Rader

- Over the next year as patients would come back, Dan would have a discussion with patients explaining why they didn’t have to take niacin anymore
  - It was a humbling experience to have to tell patients “*I don’t think in retrospect this is helping you much*” for a drug he prescribed a lot
  - He does have a subset of patients who are so wedded to niacin that despite this conversation, they haven’t wanted to stop
  - The vast majority of his patients have stopped taking niacin

**What’s the mechanism by which niacin raises HDL cholesterol?**

- Triglyceride lowering
- But it’s not just this; the increase in HDL were somewhat disproportionate to what you’d predict from the triglyceride lowering
- There is probably some other mechanism, and to this day we don’t really understand it
- Niacin is a very complex drug
- We’re talking about pharmacologic dosing of niacin, not vitamin dosing

***We don’t really know how niacin raises HDL beyond its triglyceride lowering effect***

- Peter did not use niacin that much, but when he did, he was surprised at how much it raised HDL-C
  - It was not uncommon to go from 50 mg/dL to 90 mg/dL on a strong dose

## HDL lipidation, dilapidation, and reverse cholesterol transport [1:12:00]

**Explain what HDL lipidation, dilapidation, and reverse cholesterol transport are**

*Begin with the goal post of a foam cell stuck in an artery wall*

- A core concept in atherosclerotic vascular disease is the macrophage that’s taken up lipids and is now a so-called [foam cell](https://en.wikipedia.org/wiki/Foam_cell)
  - This cell looks foamy under a microscope, because it has all this lipid, and when you stain tissues, the lipids become like bubbles within the cells and they look foamy
- The foam cell (the lipid loaded macrophage) is a core pathologic feature of atherosclerotic vascular disease, and it’s also the first thing you see
- Careful studies that have really looked at vascular tissues in children and teenagers and young adults have seen lipid loaded macrophages accumulating in the subintimal space and intimal space in the large vessels (see the anatomical diagram below), before you start seeing some of the more complex features of infiltration of other leukocytes and extracellular matrix and all the stuff that ultimately becomes the complex atherosclerotic plaque

![](https://peterattiamd.com/wp-content/uploads/2023/01/f1-danrader.png)

**Figure 1. Cross-section through a human coronary artery**. Image credit: [*Interventional Cardiology*](https://www.openaccessjournals.com/articles/the-use-of-subintimal-pathways-to-facilitate-chronic-total-occlusion-procedural-success.html#:~:text=Subintimal%20space%20in%20CTO%20PCI,of%20a%20stenosis%20or%20occlusion.) 2013

- There has been a strong belief for a long time that foam cells are one of the core initiators of this process
- An analogy would be with [Alzheimer’s](https://en.wikipedia.org/wiki/Alzheimer%27s_disease), the [Aꞵ](https://en.wikipedia.org/wiki/Amyloid_beta?wprov=srpw1_0) being the core initiator of the process, leading to much more complex pathology
- Macrophages have very well-established mechanisms for ridding themselves of cholesterol
- Keep in mind, no cell (except the liver cell) has the ability to metabolize cholesterol to other sterol species
- Cells can make plenty of cholesterol, but the only way cells can deal with their cholesterol is to efflux the cholesterol‒ to push the cholesterol out of the cell and get rid of it
- All of the body is making cholesterol, but that cholesterol ultimately has to come out of those cells into something
- This is where HDL comes in
- HDL ultimately gets cholesterol back to the liver where the liver can metabolize it or directly excrete it into the bile
  - Where it goes out the intestines and into the feces
- All cells have the ability to push cholesterol out of the cell, but [macrophages](https://en.wikipedia.org/wiki/Macrophage) really have to do it
  - Because macrophages are like the dump truck of the body
  - They’re picking up not only LDLs and lipoproteins with cholesterol, they’re scavenging cells/ dead cells/ [apoptotic cells](https://en.wikipedia.org/wiki/Apoptosis) that have lots of cholesterol
- Macrophages have very effective way to rid themselves of cholesterol
- When those pathways get overcome (or less efficient), the macrophage then builds up cholesterol and becomes the foam cell we’re talking about
- Macrophages have transporters, they have a very abundant amount of [ABCA1](https://en.wikipedia.org/wiki/ABCA1)
  - We talked about it earlier in the gut and liver
  - ABCA1 is one (but not the only) way that macrophages rid themselves of cholesterol
- The main acceptor of cholesterol via ABCA1 transport out of a cell is [apoA-I](https://en.wikipedia.org/wiki/Apolipoprotein_AI)
- This led to the paradigm (long ago) that macrophage foam cells are building up cholesterol because they’re not getting rid of it effectively, and one of the best ways to get rid of it would be to promote these efflux pathways via ABCA1 and other transporters that are being driven by apoA-I to HDL
- Back to Dan’s garbage truck analogy, HDL is the garbage truck picking up cholesterol in the periphery (in the blood vessel) and dumping it off in the liver, and then going back and doing its job again

***It has long been thought that a key process to help protect against the early initiation and progression of atherosclerotic plaque is cholesterol efflux from macrophages and other cells in the blood vessel wall***

**Peter’s takeaway**‒

- The positive valence of HDL as a particle is because of this function
- Part of the problem is that we can only measure crude metrics like the amount of cholesterol in an HDL, the number of HDL particles, or the size of an HDL particle
  - This is so far removed from quantifying the process Dan just described

**Cholesterol efflux**

- The first step in this broader physiologic process is what we call [reverse cholesterol transport (RCT)](https://en.wikipedia.org/wiki/Reverse_cholesterol_transport)
- Forward cholesterol transport describes cholesterol coming out of the liver into VLDL and LDL, and then depositing in tissues like the artery
- Reverse transport is the picking up of cholesterol (punitively via apoA-I and HDL) and returning it back to the liver
- Data from some animal models support the idea that reverse cholesterol transport is related to protection against atherosclerosis

***According to this theory, the more effective you are at picking up cholesterol (efflux) and returning it to the liver for secretion, the more you protect against atherosclerosis***

- Dan reminds us that [SR-B1](https://en.wikipedia.org/wiki/SCARB1) is one of the terminal steps where HDL is dumping off the cholesterol
- If you interrupt that process, HDL goes up, but the process of reverse cholesterol transport is being constipated, and therefore, there’s increased risk of atherosclerotic cardiovascular disease

**One of the great goals of the field has been‒ can we promote that first step of this process?**

- Can we figure out a way to promote the process of cholesterol efflux from the macrophages (and maybe other cells in the atherosclerotic plaque) to acceptors like HDL in order to protect or even regress atherosclerotic plaque, as a way of trying to reduce risk?
- Dan thinks what’s pretty clear is it’s not the mature HDL particle
  - When we measure HDL cholesterol, we’re measuring cholesterol in the mature particle

***HDL is almost certainly not the particle that is driving this first step of the efflux of cholesterol from the foam cell and the macrophage***

- That is maybe why simplistically raising HDL cholesterol (like with CTP inhibition) doesn’t actually reduce atherosclerotic cardiovascular disease events

**Questions remain about cholesterol efflux and how to target this clinically**

- But are there other ways more creatively that we might be able to drive that process?
- Might it be that different people (even with identical HDL cholesterol levels) have different function of their HDL?
  - One person with an HDL cholesterol of 50 might have something about their HDL pathway that is super functional at driving efflux, whereas, another person with the same HDL cholesterol doesn’t do nearly as well
- If we could measure function efficiently, might we have a better way of assessing risk and maybe even targeting interesting therapies more so than just measuring this fairly not so dynamic measure of HDL cholesterol itself?
- Peter agrees that we have very few dynamic biomarkers
  - An [oral glucose tolerance test (OCTT)](https://en.wikipedia.org/wiki/Glucose_tolerance_test) is a dynamic biomarker, but most things are very static and allow us to mix flux

## Measuring the cholesterol efflux capacity of HDL:  a better predictor of ASCVD risk than HDL-C? [1:22:00]

**Back to reverse cholesterol transport (RCT), how often is it happening that an apoB-bearing lipoprotein (an LDL for example), is floating around, not yet in an artery wall, and a HDL comes along, collides in the artery itself, dilapidation takes place, and the HDL takes some of the cholesterol back to the liver?**

- BTW, the LDL is also carrying cholesterol back to the liver
  - But not as a reverse cholesterol transport process
- Dan doesn’t think this scenario occurs that often
- As discussed with CETP, the directional flux of cholesterol in the blood is more from HDL to apoB-containing lipoproteins rather than the other way around

***It’s more likely that there is something about HDL/ apoA-I interacting with cells to promote efflux of cholesterol rather than interacting with other lipoproteins (like apoB lipoproteins)***

**What do you think the future could look like here in terms of commercial assays to measure HDL function?**

- Several years ago, Dan developed an assay in mice that followed cholesterol loaded macrophages in mice; he called it the **integrated reverse cholesterol transport**
  - Macrophages were loaded with labeled cholesterol, then injected into mice
  - These macrophages were followed all the way through HDL, to the liver, to the gut, and to the feces
- With this assay he was able to tweak reverse cholesterol transport using a variety of different genetic and pharmacologic approaches
  - He was able to increase or decrease this process, and it mirrored the effect of that process on atherosclerosis
  - Something that promoted reverse cholesterol transport reduced atherosclerosis
  - Something that constipated reverse cholesterol transport increased atherosclerosis

***This gave him a lot of confidence that the integrated measure of reverse cholesterol transport is actually relevant to atherosclerotic cardiovascular disease, at least in mice***

- But you can’t do this type of experiment in humans
- Dan then [developed](https://www.jlr.org/article/S0022-2275(20)33852-9/fulltext) what he calls an ***ex vivo*** **cholesterol efflux assay**
  - You start with a blood sample, and isolate HDL (get rid of the apoB-containing lipoproteins)
  - Next, put this HDL on cells that were labeled with cholesterol
  - Then, measure the effectiveness by which that HDL removes cholesterol from these cells

***Dan was struck with the differences in the ability of HDLs for extracting cholesterol from cells when comparing HDLs from different individuals, even between individuals that had the same HDL cholesterol level***

> “*It affirmed this concept that HDL cholesterol is not really informing us on the efficiency of the function of HDL, the function defined as the ability to extract cholesterol from cells*”‒ Dan Rader

- Dan went on to use that assay on larger numbers of individuals and [showed](https://www.nejm.org/doi/full/10.1056/NEJMoa1409065) that is was more predictive of risk of coronary heart disease than just measuring HDL-C, even when you controlled for HDL-C
  - Many others have shown the same thing

***It is now well established that the cholesterol efflux capacity of HDL is a better predictor of ASCVD risk than simply measuring HDL cholesterol***

- Where *increased* cholesterol efflux is associated with *reduced risk* of ASCVD, and *decreased* cholesterol efflux is associated with *increased risk* of ASCVD
- Consistent with the idea that function is important, perhaps if we could increase function we may have a mechanism for reducing risk
- Dan is asked all the time by patients and referring doctors, “*Can you measure my patient’s HDL function?*”

**Full disclosure**‒ Dan was part of starting a little company several years ago called [Vascular Strategies](https://vascularstrategy.com/research-services/), and they do this measurement in a very reproducible way

- There is a lot if interest in trying to bring this to the clinic
- There are also other assays being developed
- Dan thinks there’s a chance we could have a clinical assay available within the next 2-3 years
  - Right now, it’s still under development

**What type of cell are you using to measure the efflux capacity?**

- They pioneered the work using a mouse macrophage cell line called J774
- They have done it with human macrophages (and so have others)
- Dan thinks the macrophage is the most relevant cell type for reasons discussed earlier

**If you take 100 people that have roughly the same HDL-C level, do this assay, and rank them in order of effectiveness (which correlates directly with disease risk), is this directly related to risk by proxy (i.e. other measurements like insulin resistance, apoB) or is it actual outcomes?**

- The [first study](https://www.nejm.org/doi/full/10.1056/NEJMoa1409065) Dan published on this was cross-sectional and correlated with clinical coronary disease
- He then wanted to know if this is predictive of incident disease, and went to colleagues who did the [EPIC-Norfolk study](https://www.epic-norfolk.org.uk/) (a very large prospective study in the UK
  - In these many thousands of samples they measured cholesterol efflux for people who had been followed for 10+ years
  - They [showed](https://www.thelancet.com/journals/landia/article/PIIS2213-8587(15)00126-6/fulltext) in this setting that cholesterol efflux capacity was predictive of incident cardiovascular events
  - These are **hard events**, not just proxies, like measurement of coronary calcium

**How well does that prediction hold up if you corrected for other things that could be measured in the blood, such as insulin resistance, triglyceride or apoB?**

- They did the statistical analyses correcting for clinical risk factors, including HDL
- They corrected for things like BMI and the presence of diabetes
- They did not correct for a sophisticated marker of insulin resistance (like [HOMA](https://en.wikipedia.org/wiki/Homeostatic_model_assessment))
- At some point, is this causal, or is it still associative?
- But just even better associative because it correlates with things even better than HDL cholesterol
- This is why we need interventional studies that actually test the hypothesis
- Peter thinks it is causal

**Because it’s so difficult and complex to initiate [cholesterol efflux testing] at scale, could we use AI to figure out its equivalent to a new metric or a composite metric of things we can measure as biomarkers?**

- In Dan’s [paper](https://www.thelancet.com/journals/landia/article/PIIS2213-8587(15)00126-6/fulltext) with the EPIC-Norfolk data, they did correlations of efflux capacity with lots of different things (shown in the figure below)

![](https://peterattiamd.com/wp-content/uploads/2023/01/f2-danrader.png)

**Figure 2. Correlation of cholesterol efflux capacity with risk factors for ASCVD (n=1749)** Image credit: [*The Lancet* 2015](https://www.thelancet.com/journals/landia/article/PIIS2213-8587(15)00126-6/fulltext)

- Dan would have to go back and look at this
- If he could find markers that would predict efflux capacity, this could be used as a biomarker instead of measuring the efflux capacity itself
  - He’s not convinced this is possible, but it’s a good thought
- The analogy that comes to Peter’s mind is that certain labs use a series of NMR metrics to predict insulin resistance
- So the idea here is to look at the NMR spectra of all the lipoproteins, and impute a composite metric
  - It would be amazing if there was an HDL function score build out of X, Y, and Z

**Lots of labs use NMR to count the number of HDL particles and provide an HDLP**

- Dan points out, “T*he overall number of particles is obviously correlated with HDL cholesterol, but it’s a different measure, because HDL cholesterol is just that amount of cholesterol carried in the HDL, whereas the particles are more analogous to measuring apoB (meaning total particle number)*”
- Data suggests that HDL particle number is a little better than HDL-C at predicting risk
- They haven’t formally compared HDL particle number to cholesterol efflux capacity (the functional measurement)
  - Fundamentally, it’s another static measure though
  - It may have some limited predictive value, but it doesn’t take us that much further in being able to predict risk better

## A promising new intervention that may promote cholesterol efflux and reverse cholesterol transport [1:32:45]

 **Promoting efflux and reverse cholesterol transport**

- The concept of promoting the **efflux and reverse cholesterol transport pathway** is being tested with another intervention called [CSL112](https://www.ahajournals.org/doi/10.1161/JAHA.121.024754)
  - It’s a form of apoA-I that has been complexed with lipids (a so-called recombinant HDL particle)
  - It is being tested for impact on cardiovascular outcomes in the setting of acute coronary syndromes
  - So, people have come in, been randomized to four weekly injections of this apoA-I containing recombinant particles (which is very effective at promoting cholesterol efflux), with the idea being that this may directly impact the plaque and have an impact on cardiovascular events
- This is the closest thing we have to a formal test of the cholesterol efflux hypothesis as an intervention, in terms of whether it will reduce risk

> “*Those of us in the field are on the edges of our seats*”‒ Dan Rader

- It’ll be a little while to really see what this trial shows, and Dan thinks it’s going to be interesting either way.

## The association between HDL cholesterol and neurodegenerative diseases [1:34:00]

- This is a fascinating new area of HDL biology that has a number of components that are still being investigated

**APOE isotypes and risk of disease**

- ApoE clearly has a role in apoB-containing lipoprotein metabolism, in mediating the uptake of those remnant particles into the liver
- Most people hearing this are going to think about the gene for *APOE* and it’s three isoforms‒  apoE2, apoE3, apoE4
  - Each encoded by a different allele‒ *APOE-*ε*2*, *APOE-*ε*3*, and *APOE-*ε*4*
  - Everyone has two copies of this gene, so there are six possible combinations of these isoforms
  - Depending on the genotype, you’re going to have different amounts of apoE protein and potentially different functionality

> “*ApoE is possibly one of the most fascinating genes and proteins in human biology, in terms of its roles, and the isoform issue, and its relationship to disease*”‒ Dan Rader

- Of the three common isoforms, apoE3 is the most common and so-called “wildtype”
- In lipidology, they’ve focused a lot on **apoE2**‒ this is the form of apoE that is defective in binding to the LDL receptor (and the other receptors that mediate uptake of remnant lipoproteins, both chylomicron and VLDL)
  - This is important if you inherit two copies of *APOE-*ε*2* because you are at risk for [type III hyperlipidemia](https://en.wikipedia.org/wiki/Hyperlipidemia#Type_III) (a remnant clearance disorder)
    - These individuals get high triglycerides and cholesterol and are at risk for ASCVD
- Peter asks, “*Do these patients require* [*fenofibrates*](https://en.wikipedia.org/wiki/Fenofibrate) *to bring down the VLDL and triglyceride?*”

- They respond to a lot of the standard LDL lowering therapies like [statin](https://en.wikipedia.org/wiki/Statin) and [ezetimibe](https://en.wikipedia.org/wiki/Ezetimibe)
- They even respond to [PCSK9 inhibition](https://en.wikipedia.org/wiki/PCSK9#As_a_drug_target)
- Sometimes you have to add on fibrates, depending on how severe they are

- This is the only genotype (*APOE-*ε*2/ APOE-*ε*2*) that Peter has never seen
  - It is more rare than *APOE-*ε*4/ APOE-*ε*4*
- But *APOE-*ε*2/ APOE-*ε*2* comes with about a 20% relative risk reduction for Alzheimer’s disease, but paradoxically these people have a higher risk of ASCVD
- A lot of people listening will think of **apoE4** and the risk associated with Alzheimer’s disease
- The apoE4 form is present in about 25% of people, it’s common
- In the homozygous form (*APOE-*ε*4/ APOE-*ε*4*), it acts in a dose-dependent way and is the major genetic risk factor for Alzheimer’s disease
  - We don’t fully understand the reasons for this risk
- As a lipidologist, Dan thinks the risk has something to do with lipid transport in the brain, and this brings him to HDL
- ApoE is made locally in the brain and [CSF](https://en.wikipedia.org/wiki/Cerebrospinal_fluid)
- Newer developments show that apoA-I is present in the brain and CSF, but apoA-I is not made in the brain
  - So apoA-I somehow gets to the brain through the blood (we’ll come back to this)
- There is a lot of observational data that strongly suggest that apoA-I is protective against neurodegenerative disease
  - Realize this is associative data, and it doesn’t prove causality
- Dan thinks this is plausible because two of the major genetic risk factors for Alzheimer’s that are expressed in the brain are [ABCA1](https://en.wikipedia.org/wiki/ABCA1) and [ABCA7](https://en.wikipedia.org/wiki/ABCA7)
  - ABCA1 is that lipid transporter that rids cells of cholesterol, and apoA-I  interacts with it and promotes it
  - ABCA7 is a very close relative of ABCA1 that structurally looks very similar, but we don’t know exactly what it does
    - Dan thinks it’s a safe bet that ABCA7 is transporting some sort of lipid to something in the extracellular space (whether that’s apoA-I or apoE or something else)

***So the plausibility of apoA-I being protective against neurodegenerative disease, particularly Alzheimer’s, is quite high***

- A lot of work needs to be done to figure that out
- Levels of apoA-I in the blood and CSF are not well correlated
  - There have been a relatively small number of studies that have measured both in the same people
  - So it’s not simply a matter of, if you have a high level of APOA1 in the blood, that’s going to generate a high level of APOA1 in the CSF
- What that probably means is the processes that are happening that get apoA-I across the [blood-brain barrier](https://en.wikipedia.org/wiki/Blood%E2%80%93brain_barrier) are highly regulated (a little like the cholesterol efflux story) and probably differ from person to person
  - They aren’t directly being driven by the level of apoA-I in the blood

***If we could figure out how apoA-I gets across the blood-brain barrier, and if we could somehow promote more apoA-I*** ***going into the brain and CSF, we might be able to reduce the risk of Alzheimer’s disease***

**Do we know if this relationship is stronger or weaker as a function of** ***APOE*** **genotype?**

- That’s a super question, and we don’t have big enough data sets yet to be able to parse it out in terms of *APOE* genotype

**Do you have any idea why a commercial assay for apoE concentration has not been developed?**

- Peter knows there is some data to suggest that apoE concentration might be more relevant than *APOE*  genotype
- Dan knows of automated assays for apoE (he runs one routinely in the lab), but it’s not a clinical assay
- Peter has never seen a [CLIA](https://www.cms.gov/regulations-and-guidance/legislation/clia)-based assay for apoE
- Dan thinks this is because measuring apoE (in total plasma) isn’t that helpful in the limited clinical studies that have been done
  - Helpful in terms of predicting cardiovascular risk

**Has apoE measurement been evaluated for predicting risk of neurodegenerative disease?**

- You would need to take a CSF sample because the levels of apoE in the CSF and blood do not correlate much at all (in the few studies that have measured it in both blood and CSF)

***Dan thinks measuring apoE in the CSF might be a useful clinical tool***

**Peter’s takeaway**‒ HDL is potentially protective in the brain, presumably via apoA-I, potentially offsetting some of the apoE problem

- A previous guest on the podcast referred to apoE as the “*general contractor of cholesterol in the brain*”

**Does HDL have anything to do with nitric oxide?**

- There have been a variety of other “functions” HDL has been reported to do, but their relevance to human disease and pathophysiology are less clear
- A couple of investigators (most notably [Phil Shaul](https://profiles.utsouthwestern.edu/profile/16558/philip-shaul.html) in Dallas) have shown very clearly in mice that HDL can promote nitric oxide production in a way that would be expected to be beneficial
  - Both in terms of blood pressure lowering, and it may be protection against atherosclerosis
- And that [SR-B1](https://en.wikipedia.org/wiki/SCARB1) (the receptor we’ve been talking about) is also present on endothelial cells, and it mediates (at least part of) that effect of HDL
- Translating that observation to relevance in humans is challenging but plausible

**Another thing HDL has been shown to do that would be putatively beneficial is promote insulin sensitivity**

- There is data that suggests that HDL can interact directly with skeletal muscle in a way that promotes insulin sensitivity
- Its relevance to human disease and physiology is still a little unclear
- Peter adds, “*Even if we knew mechanistically that this were sound, we’re still back in the same area we are with ASCVD… we’re standing here with our hands in front of us saying, well, what can we do about it clinically?*”

## Challenges ahead, a promising outlook, and the next frontier in lipidology [1:44:45]

**What do we do about this knowledge that HDLs are helpful particles, when I can’t measure the manner in which they do their job?**

- Peter notes the protective action of HDL in the muscle and brain and notes, “*This is such a complicated area of biology that I would guess it has to be considered the next frontier of the lipid space*”
- If we step back and put ASCVD in the context of cancer and neurodegenerative diseases (the big three killers in the modern world)
  - We know so much more about **ASCVD**, and we have so many more tools to effectively treat it
  - We know a bit about these other diseases
  - In the case of **Alzheimer’s disease**, we don’t have a single tool to do anything about it
  - In the case of **cancer**, 90% of the tools do nothing (i.e. they barely extend median survival, but don’t cure people)
- In ASCVD, we can really move the needle, and yet you could argue half of the field we still know nothing about

**Is there going to be a renaissance, or are we up against some technical limitation on this inability to measure function?**

- Dan separates this into two topics
  - 1 – Measurement of function for risk prediction
  - 2 – Implications for intervening therapeutically

In regards to measuring function…

- Dan thinks measuring cholesterol efflux (HDL function) has the ability to allow us to more specifically assign risk better than just measuring HDL cholesterol
  - What we need is a good, reproducible, easy to run, automated assay that is tested in large number of people and shown to predict risk better than HDL-C
  - We are on the path to developing such an assay
  - But proving that this measurement actually enhances risk prediction enough to make it worth doing in clinical practice has about a 50% chance of success
  - Even then, it will only be physicians like Peter and Tom Dayspring who pick up that assay and start using it in their patients to get a sense of whether its useful in the context of a sophisticated preventative clinical practice

In regards to intervention (#2), the [study](https://www.sciencedirect.com/science/article/pii/S0002870320303355?via%3Dihub) Dan discussed is huge for moving this forward

- Let’s assume that study is positive, that four weekly infusions of CSL112 (a recombinant HDL) significantly reduces cardiovascular events in patients with [ACS](https://en.wikipedia.org/wiki/Acute_coronary_syndrome) after 90 days
  - That will rejuvenate the field of cholesterol efflux and reverse cholesterol transport as a therapeutic target for intervention
- If that trial is not positive, then the concept of intervening around HDL and reverse cholesterol transport for purposes of ASCVD is probably past recovery
- Even the CETP inhibitor that Dan mentioned is still in development

***It’s really more about reducing apoB than it is about raising HDL***

**What is this trial and when do we expect the data to come out?**

- Dan notes, “*I should have refreshed my memory on that. I just can’t remember.*”
- The [trial](https://www.sciencedirect.com/science/article/pii/S0002870320303355?via%3Dihub)‒ is ApoA-I Event Reducing in Ischemic Syndromes II (AEGIS-II), and it follows patients for 1 year
- It’s a global study with centers in the US, Australia, and Europe

**The next frontier in lipidology**

> “*I don’t think HDL per se is the next frontier, but I do think lipid metabolism in the brain is one of the next frontiers”*‒ Dan Rader

- Dan thinks **lipid metabolism** in the brain is one of the next frontiers in understanding **neurodegenerative disease** and other **brain function**
  - He thinks this as a long-term lipidologist who has focused primarily on the blood
  - He is always looking for things he can apply his expertise as a lipidologist to
- The brain is the most lipid rich organ of any organ in the body, and understanding lipid metabolism in the brain and its relationship to disease has been under studied
  - He thinks investigations in this area will uncover some very interesting things, that with luck with have implications for therapeutic intervention to prevent neurodegenerative disease

§

## Selected Links / Related Material

**Previous episodes of** ***The Drive*** **on apoB**:

- [#238 – AMA #43: Understanding apoB, LDL-C, Lp(a), and insulin as risk factors for cardiovascular disease](https://peterattiamd.com/ama43/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (Jan 16, 2023) | [6:00]
- [#229 ‒ Understanding cardiovascular disease risk, cholesterol, and apoB](https://peterattiamd.com/understanding-cardiovascular-disease/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (October 31, 2022) | [6:00]
- [#185 – Allan Sniderman, M.D.: Cardiovascular disease and why we should change the way we assess risk](https://peterattiamd.com/allansniderman/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (November 29, 2021) | [6:00]

**Clinical trial of dalcetrapib in people with a specific genotype**: [Pharmacogenetics-guided dalcetrapib therapy after an acute coronary syndrome: the dal-GenE trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9565632/) | *European Heart Journal* (JC Tardif et al. 2022) | [41:45]

**People of African ancestry tend to have higher HDL and this may not be protective**: [Sex and Racial Differences in High-Density Lipoprotein Levels in Acute Coronary Syndromes](https://pubmed.ncbi.nlm.nih.gov/33961844/) | *The American Journal of the Medical Sciences* (A Ozaki et al. 2021) | [53:45]

**Mendelian randomization studies evaluating the causal relationship between HDL and ASCVD**:

- [Plasma HDL cholesterol and risk of myocardial infarction: a mendelian randomisation study](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(12)60312-2/fulltext) | *The Lancet* (B Voight et al. 2012) | [54:30]
- [Evaluating the relationship between circulating lipoprotein lipids and apolipoproteins with risk of coronary heart disease: A multivariable Mendelian randomisation analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7089422/) | *PLOS Medicine* (T Richardson et al. 2020) | [54:30]

**The AIM-HIGH trial did not show benefit of niacin**: [Niacin in Patients with Low HDL Cholesterol Levels Receiving Intensive Statin Therapy](https://www.nejm.org/doi/full/10.1056/NEJMoa1107579) | *NEJM* (W Boden et al. 2011) | [1:09:30]

**Merck trial of niacin**: [Effects of Extended-Release Niacin with Laropiprant in High-Risk Patients](https://www.nejm.org/doi/full/10.1056/NEJMoa1300955) | *NEJM* (M Landray et al. 2014) | [1:09:45]

***Ex vivo*** **cholesterol efflux assay**: [A novel approach to measuring macrophage-specific reverse cholesterol transport in vivo in humans](https://www.jlr.org/article/S0022-2275(20)33852-9/fulltext) | *Journal of Lipid Research* (M Cuchel et al. 2017) | [1:24:45]

**Cholesterol efflux is inversely associated with risk of ASCVD**: [HDL Cholesterol Efflux Capacity and Incident Cardiovascular Events](https://www.nejm.org/doi/full/10.1056/NEJMoa1409065) | *NEJM* (A Rohatgi et al. 2014) | [1:25:15, 1:28:15]

**Company Dan founded to develop assays of HDL function**: [Vascular Strategies LLC](https://vascularstrategy.com/research-services/) | [1:26:30]

**Cholesterol efflux capacity measured in participants of the EPIC-Norfolk study**: [Association of HDL cholesterol efflux capacity with incident coronary heart disease events: a prospective case-control study](https://www.thelancet.com/journals/landia/article/PIIS2213-8587(15)00126-6/fulltext) | *The Lancet* (D Saleheen et al. 2015) | [1:28:45, 1:30:15]

**Review of CSL112 (a human apoA-I) in clinical trials for reducing risk of ASCVD**: [Antiatherosclerotic Effects of CSL112 Mediated by Enhanced Cholesterol Efflux Capacity](https://www.ahajournals.org/doi/10.1161/JAHA.121.024754) | *Journal of the American Heart Association* (B Kingwell et al. 2022) | [1:33:00]

**Clinical trial of CSL112 (recombinant apoA-I) for reducing major adverse cardiovascular events**: [Rationale and design of ApoA-I Event Reducing in Ischemic Syndromes II (AEGIS-II): A phase 3, multicenter, double-blind, randomized, placebo-controlled, parallel-group study to investigate the efficacy and safety of CSL112 in subjects after acute myocardial infarction](https://www.sciencedirect.com/science/article/pii/S0002870320303355?via%3Dihub) | *American Heart Journal* (CM Gibson et al. 2021) | [1:33:00, 1:48:00]

§

## People Mentioned

- [Tom Dayspring](https://www.linkedin.com/in/thomas-dayspring-md-facp-fnla-3aaa876) (MD, lipidologist for Early Medical) [4:00; 44:15, 1:47:45]
- [Ancel Keys](https://en.wikipedia.org/wiki/Ancel_Keys) (American physiologist who studied the role of saturated fat in cardiovascular disease) [43:30]
- [Philip Shaul](https://profiles.utsouthwestern.edu/profile/16558/philip-shaul.html) (Professor of Pediatrics, Vice Chair for Pediatric Research; Director, Center for Pulmonary and Vascular at UT Southwestern Medical Center) [1:43:30]

§

![](https://peterattiamd.com/wp-content/uploads/2023/01/bio-image-danrader.jpeg)

##### Dan Rader, M.D.

Daniel Radar earned his BA at Lehigh University and MD from the Medical College of Pennsylvania. He then trained in internal medicine at Yale-New Haven Hospital. He further trained in human genetics and the physiology of lipoprotein metabolism at the National Institutes of Health.

Dr. Rader is the Seymour Gray Professor of Molecular Medicine at the Perelman School of Medicine at the University of Pennsylvania. There he serves as the Chair of the Department of Genetics as well as the Chief of the Division of Translational Medicine and Human Genetics in the Department of Medicine.  He is also the Director of Preventive Cardiovascular Medicine and Lipid Clinic, the Associate Director of the Institute for Translational Medicine and Therapeutics, and the Director of the Cardiovascular Metabolism Unit, Institute for Diabetes, Obesity and Metabolism.

Dr. Rader’s research focuses on the human genetics and functional genomics of lipoprotein metabolism and atherosclerosis, as well as the translational implications for novel therapeutic approaches. He has had a long interest in novel therapeutic approaches to unmet medical needs in the treatment of severe dyslipidemia. He led the scientific and clinical development of a first-in-class inhibitor of microsomal transfer protein for the treatment of homozygous familial hypercholesterolemia. He also has a particular interest in HDL metabolism and function, and novel approaches to targeting HDL metabolism and reverse cholesterol transport in the treatment, prevention, and regression of atherosclerosis.

Dr Rader is a recipient of several national awards, including the Clinical Research Award from the American Heart Association. He is currently the deputy editor of the journal Arteriosclerosis, Thrombosis and Vascular Biology, the Chief Scientific Advisor to the Familial Hypercholesterolemia Foundation, and serves on the Board of Directors of the International Society for Atherosclerosis, the Board of External Experts of the National Heart Lung and Blood Institute, and the Advisory Board for Clinical Research for the NIH. Dr. Rader has been elected to the American Society of Clinical Investigation, the Association of American Physicians, and the Institute of Medicine of the National Academy of Sciences (now the National Academy of Medicine). [[Penn Center for Precision Medicine](https://www.med.upenn.edu/pcpm/daniel-j-rader-md.html)]