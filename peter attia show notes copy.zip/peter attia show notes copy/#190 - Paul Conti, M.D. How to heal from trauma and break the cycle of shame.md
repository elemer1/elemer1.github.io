# #190 – Paul Conti, M.D.: How to heal from trauma and break the cycle of shame

**Source:** [https://peterattiamd.com/paulconti3/](https://peterattiamd.com/paulconti3/)

---

##### Check out more content with psychiatrist, Paul Conti, M.D.:

- *(September 17, 2018)* [Paul Conti, M.D.: trauma, suicide, community, and self-compassion](/paulconti/)
- *(April 10, 2020)* [Paul Conti, M.D.: The psychological toll of a pandemic, and the societal problems it has highlighted](/paulconti2/)
- *(January 10, 2022)* [Paul Conti, M.D.: How to heal from trauma and break the cycle of shame](/paulconti3/)

Paul Conti, a returning guest on The Drive, is a practicing psychiatrist and recent author of [*Trauma: The Invisible Epidemic: How Trauma Works and How We Can Heal From It*](https://www.amazon.com/Trauma-Invisible-Epidemic-Works-Heal/dp/1683647351), in which he offers valuable insights on healing from trauma. In this episode, Paul explains how his personal experience with trauma and his many years seeing patients have shaped his understanding of trauma’s impact on the brain, its common patterns and manifestations, and how often people don’t recognize the implications of trauma in their own life. He discusses major challenges in recognizing trauma, including the lack of biomarkers in psychiatry and psychology, as well as the misguidance of the mental health system in targeting symptoms as opposed to root problems. He talks about shame as the biggest impediment to healing from trauma and offers solutions to how, as a society, we can start to change the stigma of mental health and allow more people to receive help. Finally, he concludes with a discussion about the potential role of psychedelics like psilocybin and MDMA in treating trauma.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/paulconti3/the_Drive_public.png)

Play

#190 - Paul Conti, M.D.: How to heal from trauma and break the cycle of shame

#190 - Paul Conti, M.D.: How to heal from trauma and break the cycle of shame

1x15s30s

0:002:20:58

## We discuss:

- Paul’s background and unique path to psychiatry [2:30];
- A personal tragedy that shaped Paul’s understanding of trauma and resulting feelings of shame and guilt [5:30];
- The current state of psychiatry training and need for improvement [20:15];
- The over-reliance on outdated metrics and lack of attention to past trauma as an impediment to patient care [28:30];
- Defining trauma: various types, heterogeneity, and effects on the brain [34:30];
- Importance of finding the roots of trauma and understanding the “why” [47:00];
- The major challenge of recognizing trauma in patients [55:15];
- How shame and guilt are barriers to treatment and healing [1:06:00];
- How treating trauma compares to treating an abscess—a powerful analogy [1:11:30];
- How evolutionary survival instincts create problems in modern society [1:15:15];
- First step toward healing: overcoming the fear of talking about past trauma [1:19:00];
- Shame: the biggest impediment to healing [1:25:15];
- The antidote to shame and the need for discourse and understanding [1:34:15];
- The emotional health component of healthspan [1:41:15];
- How to reframe the conversation about mental health for a better future [1:52:00];
- The growing impact of trauma on our society and the need for compassion [1:58:45];
- Society’s antiquated way of treating manifestations of trauma rather than root issues [2:04:15];
- Potential role of psychedelics like psilocybin and MDMA in treating trauma [2:11:15];
- Parting thoughts and resources for getting help [2:16:30];
- More.

§

## Show Notes

**Notes from intro:**

- Paul was one of our initial guests back in September 2018 in [episode 15](https://peterattiamd.com/paulconti/)
- Paul is a practicing psychiatrist and recent author of [Trauma: The Invisible Epidemic: How Trauma Works and How We Can Heal From It](https://www.amazon.com/Trauma-Invisible-Epidemic-Works-Heal/dp/1683647351/ref=sr_1_3?crid=2Y4RURJAIXYUQ&keywords=paul+conti+trauma&qid=1638386640&sprefix=paul+conti+%2Caps%2C181&sr=8-3)
  - A book that brings his valuable insights about how we can collectively heal from trauma’s effects to a larger audience
- Paul is a graduate of Stanford University Med School, which is where Peter met him
- He completed his psychiatry training at Stanford and Harvard, where he was appointed chief resident
- He then served on a medical faculty before moving to Portland and [founding a clinic](https://www.pacificpremiergroup.com/)
- This episode is focused primarily around trauma
- We talk about Paul’s upbringing and his experience and how that got him interested in studying medicine and ultimately psychiatry and trauma
- We look at the impact of trauma on the brain, patterns around trauma, and how often people don’t recognize the implications of trauma in their life
- We talk about the lack of biomarkers in psychiatry and psychology, and the misguidance around trauma and the mental health system
- We talk about how trauma is treated as a symptom instead of going after the problem
- We talk about the importance of lowering the barrier around trauma so that people can begin to receive help
- We look at the shame that comes with trauma
  - How shame is often the thing that prevents people from getting help
  - How we can start to change the stigma around that shame that comes with past trauma
- We end the discussion with the conversation around suicide and the potential to use MDMA

## Paul’s background and unique path to psychiatry [2:30]

- Paul trained as a psychiatrist
- A big part of his day job is being a clinical psychiatrist
- He also does some consulting work along the lines of understanding brain function and how brain function can impact us in personal or professional settings
- But by and large his work is really grounded in the clinical
  - He has a clinic of about 15 really great people he works side by side with in trying to meet the needs of people who bring whatever mental health questions there may be, which sometimes is clinical care

*When he became interested in mental health*:

- He became interested in mental health around the clinical rotation part of medical school, probably into the last year
- This is when he realized that he could really be a doctor and understand medical things
  - He wanted to understand how they impact people and be grounded in that aspect of practicing medicine
- But he also wanted to understand people’s experiences of life
  - What people think and feel as they’re going through their day
  - He wanted to combine these 2 things and be grounded to all the things one learns about life as they through it and help people in that way

*Paul’s unique path to medicine*:

- Peter remembers that Paul did not come to medical school in a typical way; he was not a pre-med
- Paul worked for a consulting firm in New York and really enjoyed many aspects of the work, the business and financial aspects of it, but there was something more that he wanted
- He wanted to know more and learn more and be more directly involved with people.
- This led him to medical school to try and learn more and explore what he might be able to bring to others

## A personal tragedy that shaped Paul’s understanding of trauma and resulting feelings of shame and guilt [5:30]

- Peter asked about the events in his adolescence that shaped how he thinks about trauma
- In the first half of his life, there wasn’t any major trauma
  - He was fortunate to have a stable family system around him and to develop a pretty stable sense of self
    - This is much easier to do if there aren’t big traumas
- It was in the second half of his life that he started to have some very major traumas

> “To experience the traumas after having developed an orientation to myself and to the world that had been free of them was very, very striking” – Paul Conti

- He thinks it put him in a place to see what was going on in him and what was changing in him
  - Even though he didn’t completely understand them
  - To see what the impacts of the trauma were was distressing and surprising
  - This is part of what led him towards mental health, the surprise at seeing what was happening to him
- His sense of self was really thrown off by the traumas that happened even though he had gotten through his formative stages without any trauma
  - He wondered what happens to someone who experiences these traumas who doesn’t have a stable family system
- He was 24 when his brother committed suicide
- He felt shock and disbelief, which is common for families
- Looking at the events from the outside, his brother had a huge trauma a few years before
  - He had a very significant medical issue that came out of the blue and was life threatening
  - It really shook his sense of self
  - And he was very different after that in ways that Paul could see in some sense but not fully understand
- From the outside, seeing these changes in his brother one might think his suicide may not be that shocking
- This is not how it was on the inside
  - Everyone has mechanisms of denial or rationalization that tell us think are okay when they aren’t
  - Then the shock of it happening and realizing, “*Oh, what could I have seen? Would I have seen?*” contributes to the guilt and shame that people feel
- It’s a bad combination; an immense amount of shock and then immediately thereafter a sense of guilt and responsibility
- People get into a mindset that if this big trauma had not happened…
  - It offers some sort of psychological protection
  - But it can make the shock of a trauma more difficult because one starts to feel cursed or unworthy
  - There’s some mark of stigma that is very frightening
- Peter asked how his other brother and parents coped

> “I think my other brother and I are sort of built in somewhat the same way of continuing to persevere and trying to find something new that can make life feel better, which often means working toward achievements, applying ourselves, which can be quite a good defense against trauma” – Paul Conti

- His parents were different
  - His father was more of an outgoing, gregarious person and was able to fall into a social network that was really supportive of him
  - His mother, who has since passed away, was more of a private person, less socially connected
    - Ultimately she suffered from a lot of depression without her or us really understanding it
- This is part of what pushed his interest in trauma so strongly
- The realization of all the things he and his family didn’t understand
  - Or understood enough to know that they weren’t good, but they didn’t have the words or the understanding to really talk about all the changes and what it meant
  - They didn’t have a ready lexicon or environment to be able to talk about things
- People at times sort of retreat into themselves, and then the trauma stays very immediate even though that immediacy can play out over years and years
- So he thinks they were very ill-equipped, like most people
  - Ill-equipped to handle a massive trauma and its impact upon all of us individually, let alone the greater complexity of all of us as a family
- Is it more common that in a situation like this, where a child commits suicide and the parents and siblings are left picking up the pieces, that very little is spoken explicitly?

**Common responses to suicide of a friend or family member**

- Peter reflects of the people he knew growing up who dealt with suicide
  - He had a girlfriend in college whose mom committed suicide
  - He had another girlfriend in high school whose dad committed suicide. And one of these had a very tragic outcome
  - He had a very close friend in high school whose dad committed suicide
    - This friend later committed suicide too
    - Peter felt very guilty about this friend because when he was in college, his mom called and told him he wasn’t doing well
    - It was April during finals and Peter told himself he would reconnect in 3 weeks when he was home but by then it was too late

**Why is it hard to reach out for help?**

- Peter asks if Paul and his family ever talked about seeing a therapist to process the loss of his brother
- There was some discussion about it, but partly because of his generation, he hadn’t been to medical school yet so he had no knowledge of anything; but he was a little more inclined to want to talk about things
  - He could tell that all of them were not doing well but didn’t know the words to put to it

> “We don’t, in a sense, give ourselves permission to have words of immensity… Of impact… Of oh, my whole existence feels different.” – Paul Conti

- Often the reflexive nature of shame causes us to go inside

> “A primary point that I wish to make about trauma, is that there is a reflexive shame that comes of being traumatized” – Paul Conti

- This is the same shame he sees if someone is assaulted and then presents talking about the assault through the lens of their shame that it happened
- These powerful stories that reinforce the reflexive nature of a sense of shame that drives us inwards
  - One doesn’t have the words for it
  - Then they feel very, very bad about it

**Impact of trauma and shame**

- Even the trauma that Peter felt as a result of not going home for his friend; it’s so obvious
  - But it’s obvious only in retrospect
  - At the time it was not obvious, because those words of desperation and of immensity were not being used
- We sit within a social context around us that, in a sense, normalizes not really talking about it
  - Not saying that “*everything has changed and I don’t know what to do about that or what that means*”
  - And then we move forward as best we can
  - But we’re limping forward without really talking about the things that matter, which really starts with how differently we feel about ourselves
- We all felt a sense of shame and a sense of responsibility— what should I have seen? What should I have done?
  - Paul was living at home at the time of his brother’s suicide
  - His parents thoughts of how they could have, would have, should have, seen something, known something; that sense of shame drives everyone inside
  - Then they’re trying to communicate but don’t have the words; it’s like they’re muffled
- One can see cascade of trauma where one suicide follows upon the initial suicide; or the people around the person feel so guilty and ashamed that their lives head in different directions
  - His  mother became depressed and more isolative
  - It really changed the course of her subsequent life in a way that was very negative without any of them really knowing how to understand it or what to do about it
- That’s among the biggest aspects he’s fighting against
- He’s saying “*Look, we need to be able to talk about these things. What’s more important and what’s more worth the time and effort to put the right words of understanding to than what happens inside of us after trauma*.”
- Peter asks, “*What other thoughts did you have as you went through medicine as it pertained to your brother, or were there other factors that shaped that as well?*”
- In retrospect, in himself what he often has seen in his clinical work over these past 20 years is there’s a sort of bifurcation often after big trauma
- He had wanted other things in his life before his brother’s death
  - He wasn’t completely happy with his career and thought maybe he needed more education
  - The idea of doing those things was really based on some sense of faith and confidence in myself, thinking “*I could take a different path and figure it out.*”
- But after his brother’s death, there was a bifurcation where he start to feel very differently about himself, he felt incompetent, incapable
- He thought, “*how could I even hope to take care of myself if I couldn’t be a brother to my own brother?*”
- As he has thought about it, talked about it, and written this book, he realized he had forgotten that sense of confidence in himself
  - He was going in a negative direction of becoming less healthy and drinking too much and just wallowing in his own unhappiness through a sense of guilt and shame over what had happened
- He came to a point of realizing that it was not going well
  - He realized he was forgetting who he’d always thought he was
- He got a little bit of therapy, which was a very wild thing to do— like no one went to therapy
  - There was a sense of stigma even around needing mental health help after his brother’s suicide
  - But even that little bit of therapy helped him ground again to realize, “*No, I don’t actually feel differently about myself.*”
  - Then if anything, he felt more of a drive— like he wanted to go do this good thing
    - It was a drive to help people
    - But it was really a drive of self that, “*Am I going to take care of myself in a way that says, if you’re not happy and you want more of your life in the way that you see it, are you going to go do that?*”

> “And that’s where I think helping ourselves and helping others comes together.” – Paul Conti

- If he had no confidence in himself that he could guide his own life or be worth having in anyone else’s life, how would he go off and do something to help other people?

- He thinks that’s often what happens after tragedy, in a very seductive and evil way, the consequences of trauma beckon us to limit our horizons, to see ourselves in a different and very negative way, which leads to bad things
  - It leads to depression
  - It leads to panic attacks
  - It leads to substance abuse
  - It leads to not being who we want to be
- Often juxtaposed to that is seeing the trauma through a lens that makes us redoubled in wanting to be who we can be
- Understanding the different effects of trauma
  - Whether it gets the best of us and the guilt and shame wins the day, and changes one’s memories of who one thinks they are
  - It can go this way or one can be lodged into life in a way that lets them move forward
  - He was very fortunate to have gone the good path instead of where it could have led him
  - Going to medical school was about him and his sense of confidence in himself that ultimately wasn’t taken away by his brother’s suicide, but man, it really could have been

## The current state of psychiatry training and need for improvement [20:15]

- Peter asks, “*When you think back to your residency, you stayed at Stanford after med school for the first part of your residency before going to Harvard, when you think back to those first couple of years, what stands out in terms of what you learned and how one teaches psychiatry?*”
  - This discipline seems to be more difficult to teach than say, surgery
  - Teaching somebody how to make a psychiatric diagnosis might be less challenging than teaching somebody how to talk to someone and elicit information that would allow them to make that diagnosis
    - Or more importantly, communicate with a person in a way to help them
  - In other words, using words seems harder than using a needle and suture
- There’s lots of learning of facts around neurobiology and medicines and different modalities of therapy
- But then there are the less tangible aspects that are the most important
  - Like how does one establish rapport?
  - How does one really be present with someone?

**The need for better education on the mental health front**

“I think that’s where the training in the field, I think across the board, often fails us. And I think part of that is the world, the society we live in and the world of modern medicine.” – Paul Conti

- At the time he was very struck, and continues to be over these past 20 years, of how so much of what he learned as a second year psychiatry resident, he thinks we should be teaching people in elementary school
  - About how one responds to the world around us
  - The idea that bullying comes from a sense of shame in the person doing the bullying and then creates a sense of shame and inadequacy in the person on the receiving end
    - And how does this all work in our brains?
    - How does logic and emotion clash in our brains?
    - And emotion wins over logic yet we’re taught that we’re logical creatures?
  - He was in some sense quite incensed at a whole education process that doesn’t prepare us to live life by telling us the basics of what goes on in our brains

**The medical establishment can do better**

- He was also struck that as he was learning it, it wasn’t necessarily being directly applied in the field
  - As mental health has tried to fit itself in with the rest of medicine, it wants to have a very clear diagnostic paradigm
  - This is a trend away from describing someone in a narrative
    - Now the focus is on the diagnosis of the patient; years ago it was on the narrative of the patient
    - One would talk about who that person was, and in at least a couple of paragraphs
    - That’s by and large gotten reduced to a number
    - And in trying to regiment itself in a way that is overly rigid and serves the field’s desire to integrate with the rest of medicine, psychiatrists start losing the truth of really sitting with people and being present with people
- A lot of what he learned about how to be a psychiatrist was about boundaries with other people
  - Which makes sense in many cases; but the boundaries were put forth in a way that was often about eliminating the realness of presence with someone
  - And he thinks maybe that’s the part that is intangible or the harder aspect of the field
    - It doesn’t have to be that way
    - Psychiatrists are going to help people through understanding, through really being with someone and trying to understand their experience
    - And of course, having it be about the other person, but being a real person with them
    - He found that in his training process but didn’t find it in the field
- The field is largely moving towards these brief appointments and just giving people medicines, instead of trying to understand what’s going on with them
  - This is what he describes as polishing the hood, when it’s very clear there’s something going on in the engine
- And while he learned a great deal and he learned from some wonderful people who role modeled for him how to be with people one was trying to help, it was also a great deal of disappointment with a field that often in its training and its interaction with patients ignored the crucial point of realness of the experience of the other person

**Paul’s training in psychiatry**

- Peter asks him to “*Think about the differences between the two programs you trained in… Because you did half of your training at Stanford and half at Harvard, which are generally regarded as two of the finest psychiatry training programs in the country, but they have a very different method of training.*”
  - Harvard’s approach to psychiatry is more clinical, more Freudian
  - Stanford seems to be focused more on neurobiology
  - It seems there would be huge benefits to integrate these 2 perspectives
- Paul didn’t understand this at the beginning
- The medical and neurobiological approach to psychiatry at Stanford is among the finest points of its program
  - He was lucky to learn a lot of neurobiology, neurochemistry function of medicines
  - He learned aspects of the different parts of the brain and how they communicate with one another to generate one’s perception of reality and problems that can afflict them
- He didn’t realize how little he was learning of the psychology of being a psychiatrist, of the unconscious motivations in us of this rich history of understanding human beings that is so tremendously important to being able to help people
- When he got to Harvard, [Dr. Mary Anne Badaracco](https://connects.catalyst.harvard.edu/Profiles/display/Person/29824) (to whom he is eternally grateful) was impressed with the amount of biology knowledge he had, but was kind of horrified with the lack of psychology knowledge
  - She really helped him to get that knowledge
  - She helped him learn to put the rubber to the road by being a real person with the patient that you’re trying to help
    - This is now how he approaches psychiatry
- He realized when he’s being more rigid in a certain way, he’s less helpful; and if he uses a more existential therapy approach to realness with a person, then he can use all the neurobiological and the psychological training to really make a difference to someone
- He’s figured this out through practice; learning what really helps someone
  - Just like he found his way to trauma
- He didn’t decide “*Oh I’m going to be a trauma person. I’m going to write a trauma book*.”
  - Instead, he saw that trauma was undergirding a very high percentage of everything he was trying to treat
- He think one learns by trying to apply what they know
  - He was  very fortunate to have had the brain biology knowledge and the psychological knowledge

## The over-reliance on outdated metrics and lack of attention to past trauma as an impediment to patient care [28:30]

- When was the first edition of the [diagnostic and statistical manual (DSM)](https://en.wikipedia.org/wiki/Diagnostic_and_Statistical_Manual_of_Mental_Disorders) published and how does this fits in the evolution and history of psychiatry
- The first DSM was published somewhere in late 1940s, around 1948
  - The initial versions of the DSM described the phenomenology of what a particular diagnosis is like
    - What are the aspects of it
    - What’s felt or experienced by the person, and what’s seen from the outside
    - And then there were clusters of symptoms that would then lead one to think that that diagnosis fits, which acknowledges the unique aspects of human beings
      - And if psychiatrists get too rigid about that, they start serving the manual, instead of the person
  - This evolved as a way to catalog and create crisp diagnoses around psychiatric illness
  - In many ways, the DSM evolved as a way of allowing for research criteria to say, “*Okay, we want to be calling a diagnosis the same thing if we’re going to communicate among clinicians and do research*”
  - Paul feels it is now so overly rigid and is this very thick book that could give everyone multiple diagnosis and justify a 15-minute appointment in which the person has no hope of actually being understood in any way, because this can’t be done in 15 minutes
- The most recent edition is the DSM-5; it seems to get updated every 15-20 years
  - There are technical revisions in between
- Paul thinks it is so rigid that it in many ways works against the clinical care that psychiatrists are trying to achieve
- It’s gotten to the point where it is often called a Bible which is unfortunate because it implies that there’s something in that book that actually tells what mental health problems are and what they are not
- And some of the criteria really make no sense
  - For example, someone who is experiencing vicarious trauma (but not in an occupational framework) doesn’t meet criteria for a [PTSD](https://en.wikipedia.org/wiki/Post-traumatic_stress_disorder) diagnosis
    - PTSD has come to mean everything trauma
    - So if one has trauma that’s real or legitimate, they have PTSD, and if not, they don’t, right?
    - This clearly makes no sense, but the field often views it that way and then applies criteria that are not the be-all and end-all of the human experience, and then becomes very, very rigid in a way that he thinks trivializes often what’s going on with someone
- This trends towards that symbolism of capturing everything in a number as opposed to in a human experience
- And psychiatry has gone so far away from the realness of human experience and how to sit with a person and be helpful that the field has in many ways, led itself very far astray
- He thinks that the evolution of the DSM is both a driving cause of that and also a resultant symptom of that too

**Trauma is a common thread underlying many mental disorders**

- Outside of post traumatic stress disorder, PTSD, how often does the word trauma appear in the DSM–5?
  - It appears in other places, but it doesn’t appear in a foundational way
- Because if the book is descriptive, then the book is looking to take an inventory of signs and symptoms; it’s not looking at causality
  - And that is a problem, because so much of the depression that he sees, so much of the anxiety spectrum disorders, obsessive compulsive disorder, abuse of substances and addiction, or alcoholism, is undergirded by trauma
  - And trauma changes that person’s experience of life to a place of fear and vulnerability, and then that drives the subsequent problems
- But if we’re not looking at what’s at the root of the things that we’re describing, then we’re just taking a descriptive inventory, and “*that’s how we end up polishing the hood*”
  - He can’t tell you how many people he’s seen with very severe substance disorders that haven’t been helped by three, four, five, six courses of treatment, and they’re then often labeled as “failing the treatment”
  - And very often prior treatment never took a trauma inventory; and it’s trauma that is driving the substance use
  - It’s trauma that’s changed that person’s internal dialogue towards something that’s extremely negative that tells them that they’re not worthwhile and they’ll never get anywhere in life, and why try for a new job or a new relationship, because nothing ever works out for them
  - And this wasn’t that person’s belief in themself before trauma
- Trauma is undergirding everything, and then it’s spinning off these symptoms, and then we take inventory of the symptoms as if they are the be-all and end-all, and then somehow we’re surprised when the treatments don’t work
- So the fact that we’re not looking to etiology is a huge problem and it fits with not actually paying attention to people
- He would get handoffs that would describe a person in a number, “*That’s a 296.44 with a 309.81.*”
  - But we’re talking about human beings here and we’ve somehow reduced that to numbers that indicate a set of symptoms
  - It’s hard for him to see how one could argue the field hasn’t been led astray if that’s become the standard

## Defining trauma: various types, heterogeneity, and effects on the brain [34:30]

- Peter asks him to define trauma as broadly as he can; for somebody who’s really hearing about this for the first time, what does trauma mean

> “Trauma is anything that pushes our coping skills to and beyond their limits and then results in a set of feelings inside” – Paul Conti

- That could be acute terror, or it could be, for example, a sense of denigration
- But it creates these feelings inside that then changes the functioning of one’s brain, the communication within the brain among the various parts in a way that shifts the lens through which one sees themselves and the world around them
- So it pushes one’s coping skills beyond the limits, and then it changes the way one’s brain functions
- This is identifiable in modern science; there is the ability to see the changes in space-aged neuroimaging that shows how the connectivity in the brain shifts
  - Or even the fact that trauma changes the expression of genetically determined characteristics in us
  - Because genes are either on or not on, and that changes as a result of trauma and can be passed down to children even years after the trauma occurs
    - So someone can have trauma occur, change the brain, and then have a child years later and the child is impacted by the trauma that occurred years before

> “These are real changes inside of us, identifiable by modern science, that happen when our coping skills are pushed beyond the limits” – Paul Conti

- Our view of trauma comes through this history of seeing trauma through the lens of combat, because it’s the most obvious way to see it
  - A person went off to war and they experienced terrible things in war, and they came back and it’s so clear that they are different, right?
  - So that’s how we look at acute trauma because it’s the most obvious
- And if there’s a suicide and gosh, the family members are traumatized; we can see that

**The heterogeneity of trauma**

- But what we pay less attention to are 2 different factors
- 1) The variables inside of us that determine what pushes our coping skills over the limits differ
  - It differs by genetic characteristics
  - It differs by early life experience
  - It differs by, for example, how finely tuned one’s emotional compass is
  - It differs by the chronicity of trauma
  - The multiple-hit hypothesis— if there are multiple traumas, it might be the 5th trauma that now pushes that person into a post-trauma syndrome where the brain is different
    - Even though the 5th trauma might seem less traumatic than the first 4, but the weight of the first 4 are there
  - So we tend, then, to paint with this broad brush that ignores the richness of human diversity and how we are impacted differently by different things
- 2)  It also ignores that not all trauma is acute; there are traumas that are chronic
  - Think of the trauma of neglect— neglect of a child is not defined by an acute incident; it’s defined by the impact upon that child of the neglect over time
  - The same thing occurs with systemic racism; a person gets messages over time that they’re less than, that they look different, they dress different, they worship different
    - Whatever is going on in them is less than
  - And that’s inculcated into the person over time; and that can have exactly the same effects on the brain
- The same is true with vicarious trauma
  - We are fortunate as a species that we can be empathic with one another; we can experience the emotions of another person in a way that’s connected as if they’re our own
  - But the other side of that coin is we can be traumatized by what happens to other people, and sometimes that might be someone we’re very close to, or it might be a person who develops such a strong interest because they’re horrified by things they see going on around the world and then are paying very, very close attention in a way that overwhelms their brain’s ability to cope with that
  - For example, a person who was so deeply impacted by the crisis in Syria that then develops post-trauma symptoms
    - That person never left their home in the United States, but was so appalled and distraught by what was going on, and didn’t know to divert their attention
    - Even though this attention was coming from a good place in their heart
    - Ultimately that person manifests the same post-trauma signs and symptoms as people who suffer from an acute assault
- Whether the DSM likes that or not, it is true, and it’s identifiable in human experience

> “So the truth of human experience reflects the diversity of how we can be traumatized in acute, chronic and vicarious ways, and that how traumatic things impact us and whether they push our coping skills over the limits is also so unique to each human being, which doesn’t mean we don’t follow patterns.” – Paul Conti

- Of course the discipline of psychiatry involves following patterns and identifying patterns, is very, very important, but needs to acknowledge that people are different and one can’t understand what’s going on inside of a person without paying attention to that actual person
- Peter summarizes, there are at least 2 variables at play
  - 1) The individual’s susceptibility
  - 2) The circumstances of the event (which may be an acute, chronic, or experienced by others they witness)

**Shortcomings of the DSM**

- The DSM excludes people who witness events in the now and then are pushed beyond their manner of coping to begin to internalize shame and think of themselves differently
  - In the DSM, they don’t meet the criteria for what validates trauma
  - Paul doesn’t think this makes sense, that a book has to validate the trauma
  - Instead, psychiatrists should be looking at people and saying, “*Do you present with the signs and symptoms of trauma that has pushed your coping skills over the limits? Is your mood chronically lower? Is your anxiety chronically higher? Are you having panic attacks you didn’t have before? Is your sleep disturbed? Are you more hypervigilant? Do you feel less safe in the world about maybe yourself or people that you love?*”
    - These are clearly identifiable things
- At the same time, he wouldn’t say well, “*Oh, wait a second, that happened to you, but you were vicariously traumatized in the course of something occupational, so I’m going to put the stamp of approval on you. That happened to you, but you were just so horrified by what was going on, say, in Syria that you couldn’t take your attention away from it, and it woke you up in the middle of the night and you went on the computer for two more hours, and now all of a sudden you really can’t sleep well and you’re fearful about your children in ways you weren’t before… Wait a second. That wasn’t occupational. Now you don’t get the stamp of approval.*”

> “The idea is we have to anchor to the truth of human experience, because it’s not that extreme that people are traumatized by vicarious things” – Paul Conti

- He has seen this  and has written this prescription more times than he can count. “*No more news*”
- He prescribes this because he sees that this person’s health has deteriorated over a couple months of paying attention to something so intensely distressing

- And in recent years we’ve had more one could pay attention to the the point of utter despair

> “We’re not doing justice to that if we’re making a set of criteria that try and treat us like robots or machines instead of… human beings” – Paul Conti

- We have to know what’s come before in a person’s life
  - Where were they at when they experienced an acute or chronic or vicarious trauma?
- And if psychiatrists look at the manifestations of what’s going on in a person and how they help them understand it, then they can help people

**[44:15]**

- Part of the message of the [book](https://www.amazon.com/Trauma-Invisible-Epidemic-Works-Heal/dp/1683647351/ref=sr_1_3?crid=2Y4RURJAIXYUQ&keywords=paul+conti+trauma&qid=1638386640&sprefix=paul+conti+%2Caps%2C181&sr=8-3) is pay attention to what’s going on in people and help them understand it
  - This is not rocket science
  - There’s a lot about this that’s very simple and very grounded to common sense
- And if psychiatry has an entire paradigm of helping that’s around symptom inventory and putting a label or not putting a label and then schlepping some medicines at someone without really trying to understand, then even the first step we take down helping pathways are misguided
  - So then is it really a surprise that the mental-health treatment system is not doing a good job serving the majority of people?
- He doesn’t think this is an overly strong or exaggerated statement that accessing mental health help often leaves someone feeling worse
  - And he’s not trying to be over-critical of the people working in the system
  - There’s so many good people that are trying to help others, but the system often doesn’t let them do it
- There are more patients than one can count in 15-minute appointments
  - How then is one supposed to understand and help someone?
- He thinks the entire system is misguided towards this notion of “*How little money can we spend in the short term? How can we get human beings out of the equation, because human beings cost more money to deploy than medicines?*”
  - We are misguiding ourselves in a way that’s away from common sense, and we do often leave people worse than when we found them
- Consider a classic example of a patient going to a hospital and trying to get help
  - 15 or 20 years ago, when he took care of a person who might be in crisis, he would think, “*If I don’t send that person to an emergency room, that would be malpractice. They’re in crisis. They need help.*”
  - Now the vast majority of times he does not do that, because if the patient shows up at a hospital, they’re going to wait 36 hours, 40-something hours, before they see someone
    - They’re going to be put in a place that’s going to feel very shameful and very stigmatizing— there’s a locked room, people are watching them in a way that makes them feel like they’re crazy when they’re in distress, and when they finally get help, it’s only some short-term stabilization
    - They get a little medicine; they fall asleep; they wake up; they feel a little better because they slept, then they are sent home
  - This doesn’t serve people well in the short-term
  - There are not enough beds in emergency rooms, in mental-health units
  - There’s not enough time with practitioners
  - To say the system is broken is as obvious as 1+1 = 2
    - He sees it every day

## Importance of finding the roots of trauma and understanding the “why” [47:00]

**What clinical work as a psychiatrist has taught him over the past 20 years**

- Peter asks, “*When in the last 20 years did the matrix come together for you with respect to trauma? I mean, the first time you and I ever spoke about this was four years ago, 2017*”
  - Peter didn’t understand it at the time, he thought about trauma only in the most literal sense, which is something that is so obviously physically harmful that that could be traumatic
- Paul sent patients to residential facilities for trauma since very early on in my career, but he didn’t having the understanding
- He relates, “*When you do anything for a long time, you internalize aspects of doing it that become reflexive, and then it frees up parts of your brain to learn more. I think I just learned more and I got more experience and more ability to spend more time with people*”
- Eventually he realizes that he was treating the same things all the time
  - If a patient presented with panic attacks or obsessive compulsive disorder, or depression, or addiction…
  - His treatment was ultimately the same; **try to help the patient understand why**, because that’s what’s going to make the difference
  - Maybe along the way he can treat symptoms
    - Maybe he can prescribe a couple antidepressants
    - Or if someone has psychosis, he can try to decrease it with medication

> “Ultimately, how to really help that person is to try and understand what their experience is of it and their sense of vulnerability is of it.” – Paul Conti

- He realized what he was doing was trying to help people understand where the problems are coming from, because that’s how they get better
- This is the same as what he saw in himself: anger, frustration, resentment, underlying depression
  - All of these problems were in him, and a very negative and oppressive internal dialogue
  - And in his own psychotherapy exploring this, he wasn’t trying to treat whatever symptom that was spinning off now
    - He was trying to understand, what’s going on inside of him, that he’s doing this
- He saw in the process of his own psychotherapy, and what he was doing with others, that it was all about the same thing, which were the roots of what ails us

> “Those roots are the seeds of trauma falling into a soil that lets those seeds grow; and trying to understand what is that soil inside of you? How is it unique to you? How does it follow patterns that impact all of us? What was that seed? How has it grown?” – Paul Conti

- At some point he realized, this is what he’s doing and stopped thinking about how many depression cases he has or other cases and instead realized they were all trauma cases
  - This was such a revelation
- Then, in the practicality of starting to work more intentionally that way, he could see that it was more effective
- Then he  started working with really great like-minded people, and their knowledge and experience with what he was learning really came together in a way that this lens of trauma seemed not so esoteric of a discovery, but rooted back to the obvious, the older literature, in describing human behavior
  - This just wasn’t at the forefront of psychiatry in terms of education and training

**A residential trauma facility is a great tool for healing**

- Peter asks what his guess is of mental-health providers that have never referred a patient to a residential trauma facility
- It’s probably a pretty high percentage, because trauma gets defined as— does that person have PTSD
  - And people are not going to even say all the things that would lead them to be diagnosed; because they’re ashamed of the symptoms
- Peter recalls that the word PTSD almost never comes up at these facilities; and he’s been to 2 of them
  - Instead there is a label of this addiction, or this maladaptive coping strategy— you’re angry, you’re depressed… Let’s find out why
  - These facilities don’t position themselves as PTSD treatment centers, although there are people there with PTSD
- It’s interesting that practitioners aren’t more aware of this tool
  - Take something like an eating disorder; what fraction of those patients have an underlying trauma as a significant contributory factor in their illness
  - Paul says this approaches 100%

**The characteristics and outcomes of trauma beyond PTSD**

- Even when one looks at trauma through that appropriately broad lens
- Because we’re looking at what causes the outcome
- The chronic trauma of immensely high expectations of self, often placed upon self by self, but often that process being aided and abetted by external forces
  - This could be the expectations of the people around a person
  - Or just the expectations of society, of how one is supposed to look and act, how one is supposed to present themself to the world, what someone is supposed to achieve…
  - This can create and immense sense of insecurity and of vulnerability
- And people laboring under that for long periods of time often find an outlet for control
- This is often what the signs and symptoms of so many mental health issues are, an attempt to find control
  - Maybe somebody finds control by [tapping](https://en.wikipedia.org/wiki/Emotional_Freedom_Techniques) five times when they think they have a negative thought
  - Someone else finds control by restricting what they eat and they can control what goes into their bodies
  - The roots of this are always trauma
  - Paul can’t think of a person suffering from an eating disorder who did not have trauma as a root of that eating disorder
    - And the trauma was discovered and talked about and addressed, at least to some degree, during the treatment
- These residential trauma facilities understand this; they want to understand and treat the patient’s trauma
  - They’re not concerned with the magic card of entry of PTSD
  - But doctors are busy with the computer, the chart, the paperwork, establishing a diagnosis so the insurance company will pay for the 15-minute appointment or medicine that’s going to treat a symptom but not the problem that they become a gating mechanism
  - And PTSD is some magic gating mechanism that doesn’t get talked about when one is actually treating trauma because it makes no sense as a gating mechanism
- He thinks Peter makes a powerful point, “*that the world we live in says you have to have PTSD and meet these criteria or you don’t have trauma*”
  - But when one talks to someone who treats trauma, they never talk about PTSD
  - They talk about the reality and truth of what the patient has lived, and what that has done to them in ways that are then counterproductive to their life

## The major challenge of recognizing trauma in patients [55:15]

- Peter notes the problem recognizing this; this is a macro problem
  - 1) Medicine works in this sphere of biomarkers and objective measures of illness or disease
    - So doctor’s can look at a person’s ApoB, or LDL cholesterol, or hormone level; and it’s subjective; they can understand what that implies
    - Or they can look at a CT scan that shows an injury here or there
    - But psychiatry has none of these things; doing an MRI of a person’s brain offers one no more insight into their plight or their suffering than rubbing a towel on their head
    - There are exceptions such as a nutritional deficiency that can show up in a biomarker and explain a psychiatric illness
      - Such as a B12 deficiency
  - 2) The heterogeneity of the individual and their history another problem
    - One could expose 100 individuals simultaneously to the same traumatic event, but without knowing their antecedent history it’s impossible to predict how those 100 people are going to react to an identical stimulus
      - What else has the person experienced?
      - What else has been dropped in the soil?
    - This is very uncomfortable for medicine; it’s uncomfortable for science
    - Think of [Koch’s postulates](https://en.wikipedia.org/wiki/Koch%27s_postulates) [4 steps to identify the cause of an infectious disease]
    - We really love it when we can say, “*Add this microbe, get this disease. Subtract this microbe, subtract this disease.*”
    - Medicine is good at that type of thinking
- Paul agrees and sees the need to acknowledge that complexity and also that lack of specificity
- On the other hand, there are aspects of this that simplify it in ways that are very compelling
- In the book he interviews [Stephanie von Guttenberg](https://en.wikipedia.org/wiki/Stephanie_zu_Guttenberg) (who’s an expert on understanding and prevention of child abuse) and [Daryn Reicherter](https://profiles.stanford.edu/daryn-reicherter) (who’s a professor at Stanford who’s done a lot of trauma work and trauma research around the impact of trauma on identifiable markers and what that means)
  - Daryn’s work draws at times from the field of [epigenetics](https://en.wikipedia.org/wiki/Epigenetics), which shows that gene expression changes after trauma
  - His work suggests that trauma is not limited to 1 event; it carries on throughout that person’s life; it impacts the society in which that person lives, and it gets passed on to the next generation
  - His testimony was instrumental in jurisprudence on an international level, recognizing that, for example, rape as a tool of war is not a one-event criminal act, which was how it was being viewed
  - Now we have this powerful science that can show that woman who was raped and then has a child,  the genetics that are expressed in that child 3 years later are impacted by the trauma that happened years before conception
- Go back to those 100 people, who have different soil and will be affected in different ways
  - A percentage of people are likely to respond in certain ways if the trauma is dramatic
  - If the trauma is acute and dramatic, the soil might not matter so much as the majority of people people are going to be very deeply affected
  - Or there might be other kinds of trauma where the psychiatrist can only understand it by really understanding that person

**Checklists to identify should be used carefully**

- So we do fit patterns and we can understand how those patterns unfold, just like we can understand the aspects of basic science that show this is very complicated and that’s why it can’t be deployed in some checkbox kind of manner
  - But we can understand it well enough to say, “*okay, it’s actually not that complicated to try and understand, what has your experience been or what’s going on inside of you*”
  - If the patient is depressed, what is their history? What are they saying to themself inside? Has that shifted over time
  - Then the psychiatrist can understand if their brain has changed because of trauma
  - The next step is to try and understand the trauma so the patient can get better
  - This is the aspect of this problem that is simple but it’s not deployed because psychiatry is lost in the complexity of all those other things
    - All the box checking
    - All that they don’t know or understand

“And that complexity very often prevents a person from being understood, feeling understood, feeling helped, getting any help at all.” – Paul Conti

- Peter asks if there are checklists that can help with this, such as the [adverse childhood event (ACE) questions](https://en.wikipedia.org/wiki/Adverse_childhood_experiences#ACEs_score)
  - Sometimes these tests have a high positive predictive value
  - But they can also have a low negative predictive value; there are lots of people who don’t score highly on the adverse childhood event score but had significant trauma in their lives and it was instrumental in how their identity was formed
- For example, a person grew up in a family where they simply weren’t paid attention to; they would check the box of neglect
  - But not of the other boxes would get checked
  - Maybe they were part of a large family of 5 kids and the parents worked long hours
  - Those 5 kids could internalize this in different ways
  - Some of those kids could go on to become the most successful people in the world because of a drive that gets instilled in them to prove their worth
  - One of their siblings could easily go in the exact opposite direction and turn to a life of substance abuse and addiction
    - Paul notes that he sees this all the time
- There are 2 things Peter wants to explore
  - 1) Something as innocuous as neglect can produce such vastly different phenotypes
  - 2) The heterogeneity among people; the soil problem again, which is how 2 siblings in the same family, exposed to the same environmental factor (neglect), can have vastly different responses
    - One of these responses society is impressed with and the other one, society frowns upon
    - None of the siblings have an ACE score that rises to the level of concern
- Paul points out that genes are different among siblings and their manifestations can be very different based upon aspects of early childhood experience that may have nothing to do with trauma
- Overall he thinks that inventories of signs and symptoms can be useful, but they’re just one element of data
  - One aspect of this is the accuracy of reporting
  - People will often under report because trauma creates shame in us
  - Paul often sees patients who check the boxes for depression and panic attacks but not trauma
  - It’s rare for him to see a patient with purely biological depression that comes out of the blue and he can’t find trauma associated with it
    - It happens, but it’s rare
- Often when he starts talking to a person, sometimes he will have 3 sessions worth of trauma history that’s intrinsic to all aspects of that person’s life and they check no on the trauma box
  - This is because they didn’t really think this was trauma
  - They often think it was too long ago to be trauma,
  - And  that it’s not as bad as what other people have to deal with so that can’t be trauma
  - This happens all the time; it’s the norm

> “This is really a crux of the messaging of the book because trauma changes the instrument that we use to understand our trauma. It’s changing our brain.” – Paul Conti

## How shame and guilt are barriers to treatment and healing [1:06:00]

- Combine the changes in the brain with how much shame is evoked by trauma and how hard it can be to discuss that
  - Because if one is ashamed of something, they don’t want to reveal it to somebody else
  - They often don’t know if another person going to feel okay about them, even if it’s a professional psychiatrist
  - They worry that the other person is going to look at them differently because they see that shameful thing in them?

“We feel this, and absolutely I felt this after my brother’s death” – Paul Conti

- Paul went to see a therapist after his brother’s death and he worried what they were going to think of him; they didn’t know him
- He worried that he didn’t do enough to help his brother
  - He worried that he wasn’t around enough
  - He only lived 2 hours away and wasn’t home to see this
  - He worried the therapist would say, “*shame on you for what happened*”
  - He thinks this response is the norm

> “Which is why we can’t replace humans; we kind of understand this, that we can’t replace humans in our helping endeavors with something that’s computerized or mechanized in some way.” – Paul Conti

- Sure, we want to take inventories, if it makes sense,  but realize that you have no idea what that data means until you sit with the person
- Why should it be strange to say that human beings are a necessary part of this helping process?
  - He often looks at all the data he has from someone, and a lot of times he even has data from other providers or other facilities
  - There may be a lot of data and he thinks it tells him something but he really doesn’t know anything about that person until they sit in front of him
  - Once a person sits in front of him he can anchor that data to something
- What he started seeing as he got more experience in the field was when he talked more with a person about what’s going on in them, it is indeed linked to trauma, whether they’ve checked that box or not
- And it’s all those barriers (it was too long ago, they feel ashamed of it) that lead them not to recognize that the trauma is driving all of the problems

**A true story from his book illustrates the powerful changes that take place after trauma**

- The last story in the book is a true story about a woman (he got her permission before writing) who 10 years after a trauma didn’t understand how her life had changed

- She had had a tragedy in her life; her daughter had died years before
- For him, just standing from the outside and hearing this story there was such a disjunction of how she felt about herself and felt about her life and was living her life that changed after the trauma in a way that was so stark
- She didn’t realize that she was living a life so changed
- The lens through which her thoughts about herself arose was so unfair
- Despite her being intelligent and personable and all these wonderful qualities, she couldn’t see it.
  - And this is not the exception;  it’s the norm
  - Those rationalizations inside of herself that— no, it was too long ago
  - Or feeling so badly about it, and being unable to let it to the surface enough to see all of the change it had driven in her
  - So despite her attesting to not having trauma, it was 100% trauma
- She came into his care for symptoms that had spun off
  - This is often the case
  - Maybe the person is depressed

> “Where the money was at, was in the trauma, and it’s that leaf at the end of the tree that caught the person’s attention.” – Paul Conti

- He wants the leaf to be a little healthier and that’s what brought her in so he can actually look at what’s going on in the roots, that’s affecting all of the leaves
  - This gives them a chance of actually getting at it and developing an understanding of trauma and:
    - Of the reflexive shame and what that does to her
    - The change in her internal dialogue from feeling a sense of pride in herself, as someone who works hard and does good things for other people and in the world around her, to someone who couldn’t see her own worth anymore
    - There is an absolute disjunction of one’s self before and after a trauma
  - And by understanding it, she could get better
  - Does it take away the grief? No
    - In fact, it let her begin to process the grief
    - Because if we’re blaming ourselves, we can’t grieve

“That’s why it can be 50 years later and be just as immediate as when it happened, because if the grief gets walled off under this layer of shame, like an abscess medically would be in the body, then it can spin off symptoms for years and years and years without anything ever getting any better. And in fact, with things getting worse, because the trauma then brings new trauma.” – Paul Conti

- This reaction to trauma makes one feel worse about themselves
- This woman’s story is an example of something Paul sees all the time
- It’s why he wants to get to the truth of what’s going on in the person, and help them understand it so things get better
  - It’s not that hard and complicated, but it requires an approach that actually wants to understand what’s going on

## How treating trauma compares to treating an abscess—a powerful analogy [1:11:30]

- Peter found the analogy of an [abscess](https://en.wikipedia.org/wiki/Abscess) helpful; for those who aren’t familiar with it—
  - An abscess is a walled off infection
  - A great example of how one might get an abscess is if they had a ruptured [appendicitis](https://en.wikipedia.org/wiki/Appendicitis)
  - And a ruptured appendicitis carries with it a very high mortality, but there are some ways to survive it without antibiotics, without anything
  - Hundreds of years ago when people were making long haul journeys across the ocean, they discovered if one laid a person down on their right side down and tilted their head slightly up, then all of the puss that was coming out of the ruptured appendix would wall off in the lower part of the right abdomen
    - As opposed to spread throughout the entire abdomen
    - And this would increase the odds that a fibrous capsule would form around it and wall it off
    - This would contain all the pus and nastiness inside there
    - And if this happened just right, the person might survive
    - Now, they weren’t going to be perfectly healthy, but they’d survive
  - Today people show up with abscesses from a ruptured [diverticulum](https://en.wikipedia.org/wiki/Diverticulum) or something like that, and they’re not well; they’re not dead either
    - The first thing that has to happen is for them to come into the medical system for treatment
    - The analog here would be, they have to at least present for help in some way
    - The second thing is they have to be willing to get help, to acknowledge they have an abscess
- Treatment is a lot easier with an abscess because it can be readily identified with a [CT scan](https://en.wikipedia.org/wiki/CT_scan)
- But nevertheless, there’s got to be some component of convincing the person that they have this abscess
- What’s interesting is the treatment, the patient often gets a little worse before they get better
  - Because when the doctor opens that abscess it releases all of the bacteria
  - And even though they’re doing it in a manner to clean it up, the patient will initially have an inflammatory response, and that is probably worse than the condition that brought them in
- Of course there is the luxury of doing this in the hospital, the patient is getting antibiotics and IV fluids; they are monitored so this is rarely a fatal event
  - Nevertheless it is uncomfortable
- And in many ways, this is a great analogy for what need to happen here, except it’s harder in the case of trauma, because:
  - 1) The patient might be less likely to come in and seek help
  - 2) There is a really big hurdle to actually convincing the person that they have this ‘abscess’
  - 3) The treatment is much harder
  - In many ways, the treatment of the abscess is really quite simple; the patient is under anesthesia for a couple of hours, a procedure is performed, and then they take a bunch of antibiotics
  - It’s a lot harder to do what Paul did with that woman than what Peter would do with an abscess patient
- Paul notes, as he listens to this analogy of an abscess, “*what it makes me want to focus on is the really big hurdle*”
  - Peter replies, “*That saved you. Your response to the trauma saved your life.*”
  - Right

## How evolutionary survival instincts create problems in modern society [1:15:15]

**Viewing the maladaptive response to trauma through an evolutionary lens**

- Humans are built to recoil and protect ourselves from dangerous things
- This is why trauma leads to avoidance and hyper vigilance
  - People become more afraid of the world, and less likely to engage, and less likely to take chances
  - Even if it’s the chance of a job that seems better, or the chance of dating someone who seems like they could be a great partner
  - That person becomes much less likely to take chances in good ways
- If one thinks about how these systems grew in us:
  - That trauma raises a lot of negative emotion in us
  - Then one recoils to protect themselves
  - And it may be that a depressed mood, or a lot of panic attacks and disturbed sleep may all go hand in hand with:
    - Hypervigilance
    - Avoidance
    - Rationale that this is better than death
- Human development occurred in small groups
  - This is where these systems grew in humans, when a lot of the trauma that happened told us to stay close to home
  - Similar to if one ate something that made them sick, the take-away was to never, never eat that again
  - Or if one goes over that hill and someone from another tribe attacks, don’t go there again; stay closer to home
  - These systems, these responses are part of the evolution of human beings psychologically over time in order to stay alive

**Problems with the innate response to trauma**

- But now in the modern world, those things don’t always make sense
- The rationale that to wall-off a psychological abscess is better than death; this is spinning off symptom after symptom
  - It’s making that tendency towards a little too much alcohol to soothe a person
  - Then they want to do it a little more because there’s a desperation in them to not feel so terrified or have panic attacks when they’re falling asleep
  - So now they’re drinking 3, 4, 5, 6, 7 days a week
  - Or that tendency towards avoidance makes it so they can’t get out of bed or leave the house
- These are things Paul sees all the time; and often what brings a person to care is a symptom
  - Just like the person with the abscess might come to care because they don’t feel well; they don’t know they have an abscess

“The parallel is so strong there, and I think the difference is in the hurdle” – Paul Conti

- Understanding and treating an abscess is easier in many ways than for trauma
  - The patient sees the bright spot of the abscess on the CT scan
  - They understand the need for the doctor to take it out for them to get better
  - They understand that they will feel a little worse before they feel better
  - After seeing the CT scan, they understand the problem is not just the thing that brought them to the doctor, but 50 more things they didn’t  know about
  - The patient is much more likely to say yes to treatment

**The hurdle to recognize the role of trauma in mental health disorders** [1:17:45]

- Paul thinks the problem is 2-fold
- 1) It’s not as easy to recognize trauma as it is to recognize an abscess
- He thinks mental health methods should improve to help look for this
- In this analogy, Peter compares the technology available in psychiatry to the pre-CT scan era where the doctor could only palpate the patient’s belly to surmise that they had an abscess
  - The difference in the technology “*is effectively the difference between a catapult and a cannon*”
  - Paul replies that in this example, psychiatry is choosing to palpate the abdomen instead of using the CT scan
  - “*Because the human brain has more sophistication than even that finest CT scan. Right?*”

## First step toward healing: overcoming the fear of talking about past trauma [1:19:00]

- Paul suggests that psychiatry apply the trained human brain to want to try and understand what’s actually going on in the patient instead of saying, “*oh, you’re depressed*”
  - And check all the depression boxes
  - And prescribe an antidepressant
  - And conduct a follow-up appointment in two months where the psychiatrist won’t make eye contact
    - This is not helping, it’s not understanding

“But if we apply the human brain like we apply the CT scanner, then we will identify way more trauma and… tell a person here’s the great news is you do not have five problems” – Paul Conti

- Paul cannot count how many times this has been the case for him
- People present saying, “*you can’t help me, there’s no way you’re going to help me, right? It’s been going on with me for years and I have four different problems… How are you going to help me?*”
  - He replies that the problem has been going on for years because the trauma has never been looked at
  - Further the patient doesn’t have 4 problems (depression, sleep disturbance, panic attacks, and alcohol abuse), they have 1 problem— trauma
    - All these problems are arising from the trauma
    - Why would Paul say this?
    - Because he’s had a couple of conversations where the person told him how none of those things were present before the trauma and all of those things are present after the trauma.
    - It’s not rocket science
- Psychiatrists can use the human brain and identify what’s going on
- They can also decrease the hurdle

**The internal dialog that occurs after trauma makes it hard to get help**

- Consider why it is so daunting to get help for trauma
  - In many ways it is scary because if a person has been keeping it inside then they feel they can’t talk about it
  - Because if they talk about it, they then realize that they knew all along
    - Not always, but often they knew all along what was going on because they can tell the whole world inside of them is different now
- When Paul can get someone to understand this… often it’s right there waiting, because the person has disclosed that there’s been some trauma
  - They put words to something that maybe they never put words to before and guess what? The world didn’t end
  - The psychiatrist didn’t lean across the table and say “*Get out of my office*”
    - These are the things people are afraid of
    - These are the things he was afraid after his brother’s death

**Identifying the trauma is the first step to recovery [1:21:15]**

- It happens all the time after people talk about it for say 40 minutes, they say, “*I feel better now, I already feel better*”
  - They realize that they have felt different since that car accident or since that thing happened to their friend’s child,
  - But because of the shame and the idea of what is one going to do with that
  - They don’t know that there are helping resources
- He thinks more needs to be done to let people know these helping resources are available
- Instead, people have way too many experiences of going to get help and then they come out with a prescription for an antidepressant, from somebody who didn’t really talk to them
  - And they know that’s not going to help
  - Or they’ve already done it 4 times and it hasn’t helped
  - These are the barriers
- There needs to be a return to common sense to use the right helping mechanism
  - Use the equivalent of the CT scan to find the abscess
  - Make the barrier lower so the person doesn’t have to feel that it’s utterly terrifying to go through this helping process
  - Once people start doing this, even though it’s difficult, people feel good about it
    - People feel good about doing something that’s hard
    - Like working out is really hard, but one knows they are getting healthier so they don’t mind doing it
    - This is how the experience is; it’s not miserable, and it often surprises people that his clinic is not a miserable place to come
- Peter asks if he finds in the short term this can be quite distressing for the patient to go back and revisit trauma
  - This was his experience
  - It really did feel like an abscess where he felt worse before he felt better
- Yes, this is true, but now the patient knows why and they know it’s helping so it’s much more tolerable
  - This happened in Paul’s therapy
  - He knew it was going to be painful to  talk about but he wasn’t afraid of it because he knew it would help
  - Similarly, people perceive pain differently in medical settings if they know why

**Perception of pain [1:24:00]**

- Paul saw a study about gunshot wounds and how people’s pain was different if they saw the reason
  - If they knew they were going to survive, even if it’s terrifying, their pain went down
  - So yes, it was painful; but the perception of pain is important
- Is this a pain that threatens them, menaces them with destruction or is it a pain in the service of doing right by themself
  - This is an important anchor for the discussion he has with patients
  - He will tell a patient, “I *don’t see a reason for you to have a dialogue running in your head where 500 times a day you tell yourself that you’re worthless. Really that doesn’t seem fair or right to me.*”
  - Or maybe he tells them, “*there’s nothing to be ashamed about here because something just happened in life*”

> “And it’s that change inside the person that gives us all the bravery to go and do difficult things, because we see that it’s aligned with truth.” – Paul Conti

- Often people see psychotherapy as trying to shift them towards something that feels better
  - That’s not the purpose
  - The purpose is to shift towards something that’s true
  - “*Oh, and by the way, that true thing feels better.*”

## Shame: the biggest impediment to healing [1:25:15]

- Peter asks, “*What do you think are the impediments to a person once they’re presented with a plausible explanation for their symptoms in the roots of trauma?*”
  - Here’s the second huge difference from the abscess; with the abscess the patient gets an IV in the arm, takes some [propofol](https://en.wikipedia.org/wiki/Propofol), and wakes up to it all being over
  - When someone is confronted with events from their childhood, though seemingly completely disconnected from the problems they’re having today as an adult, they are probably causally linked, and the doctor needs to get them to go back and talk about them, and process them, and disconnect their shame from them
    - There’s a lot of resistance to that
    - There is the fear that the patient may not accept treatment

**Patient needs that are not adequately addressed by the current medical establishment**

- Paul thinks the biggest problem is a system that is looking for high throughput and minimal short term cost as the primary metric of success
  - The problem with this is it brings the patient frustration of not finding what’s needed
- What’s needed are skills that are learned through education and training
  - Neuro biological knowledge
  - Pharmacological knowledge
  - Psychotherapeutic modality knowledge
  - But most importantly is presenting a setting where there can be what’s called a holding environment
  - The reason one can do these things that are very, very frightening is because the patient establishes rapport with someone who they feel and believe wants to help them
    - Who they feel is capable of helping them
    - Who isn’t going to look down on them and instead, can help them hold the distress of it
- If one looks at primary predictors of success, it lies in the rapport, because of the rapport, the trust, the mutuality that’s generated is what creates that thing that’s called the holding environment
  - This is a safe environment with a safe person who wants to help them
  - And even though the patient feels scared and intimidated, they come to for help
  - They don’t feel bad when sitting across from the psychiatrist
  - This is why Paul and most of the people he works with acknowledge their own trauma
    - Trauma has been deeply ingrained in his life
  - And that sense of mutuality leads a person to feel the trust and to be able to tolerate the distress, because they’re not tolerating it alone
  - The patient now feels that the person they go to for therapy makes them feel helped and understood
    - They know the psychiatrist wants to help them
    - They feel a sense of respectful camaraderie in the work they’re doing
    - And then they can bear the distress of it
    - They can take it home with them, even if it causes them some symptoms thereafter
    - They know that they’re going to come back next week and they’re going to make more progress
  - But our helping systems have to be set up to do that for people

**The innate response to trauma makes it hard to get help**

- Working under the assumption that these helping systems are in place, Peter asks what are the things that stand in the way for people accepting this type of information to move forward?
  - These are people who had early life trauma that is producing very maladaptive responses in their lives
    - This could be a problem with self-care, care of others, or any of the other manifestations of trauma

> “So the first three answers are shame, shame, and more shame. Trauma makes a reflexive shame in us. And that’s what tells us to make the abscess.” – Paul Conti

- What’s interesting is in the appendix example, the abscess happens and now the appendix bursts
  - Then maybe the body can figure out a way, especially if the person’s leaning on the right side, it can figure out a way to wall off the abscess
- But the difference here are the defense mechanisms that say, “*I’ve got to wall this off. I can’t think about this. I can’t talk about this. I don’t want to go to therapy after my brother’s death, because I was ashamed to go to therapy on top of the shame I felt about his death.*”
  - So we do it to ourselves, because that’s what seems like the safest course of action
  - And then, because things aren’t going well, we wall off that abscess more and more, because other shameful things happen
- Paul recounts that after his brother’s death, when he wasn’t functioning well and didn’t feel like he was taking good care of himself— he felt ashamed of that too
  - This made it harder to get help

> “So shame… is the primary henchman of trauma… comes along with all these other accomplices; shame loves alcohol excess, shame loves an internal dialogue that tells you that you’re not worth anything, you’re not going to get anywhere.  There are all these things that shame loves, that we then cultivate in ourselves and we apply to further walling off, further pushing that problem down.” – Paul Conti

**Changes to improve the recognition and treatment of trauma**

- When someone goes to see someone about their symptom, it’s important for the medical provider to be actually thinking of them
- Paul strongly believes there is a need to change the sociological aspects of this
  - A  need to acknowledge that many of us have had significant trauma that has overwhelmed our coping skills, changed how we view ourselves, and changed the safety of the world around it
  - There is a need to look at this
  - There is no shame about this
- He remembers telling a group of 300 physicians from mixed backgrounds this many years ago
  - He said he had a really significant trauma in his life and psychiatric care and psychiatric medicines really helped him
  - And he could see out in the audience, probably about a third or so of people looked shocked that he had said something that was so shameful
    - It was as if the next thing that was going to happen was someone was going to fly through the air and tackle him and pull his medical license out of his pocket then put him someplace where people go, who need those things
  - He hadn’t planned on this and said, “*Look, it’s a problem, because I see a lot of you really recoiling from this, right? And I’m saying something that I don’t think takes away from my ability to be a competent physician or a competent person in the world. And I think in fact, being able to say it is what helps me navigate the world.*”
  - Those in the audience who recoil from the thought of needing help or needing medicine, how likely are they to get help themselves when they need it
    - How likely are their patients going to feel comfortable broaching the subject of something traumatic?
- It’s known that over 50% of complaints to general medical providers come from mental health conditions
  - This figure is a bottom, and the ceiling is significantly higher than that
  - So non-mental health providers have to be aware and not respond in this way
- He sees this response even in mental health professionals, some of those people who were coiled were almost certainly in mental health and this needs to change
- Paul asks, “*Why should we be ashamed of this? Don’t we have to acknowledge this?*”

**The impact on society of untreated trauma**

- Otherwise, the negatives inside of us, including the anger and frustration that for example, promotes all the dysfunction in our political discourse, all of this comes to the fore in sociological ways
- If we don’t look at this, how likely are we to help people get help?
- And then if we don’t do that, do we make everything worse in our inability to come to a decision about what’s factual and what’s not factual
- This is important for how we as a society try and navigate things like racial issues, or discrimination based upon gender sexuality, or the climate crisis
- How are we going to look at these issues if we don’t look at what’s going on inside of us
- This often involves the anger and frustration that make people just need to be right
  - And he’s not saying this is always where it goes
- A lot of the dysfunction and the misery gets turned inward in people, but some of it does get turned outward
  - And he thinks we see the manifestations of that in the real degeneration of our discourse as a society

## The antidote to shame and the need for discourse and understanding [1:34:15]

Peter asks, **“*****What is the antidote to shame?*****”**

- The answer = “Understanding”
- Paul views the lancing of the abscess as the equivalent of shining a light on shame
- Shame is so powerful
  - The thoughts that one should have done things differently
  - The things shame tells someone is like a devil on their shoulder telling them to hide
  - And it gets scarier and scarier

> “You can’t share that even with yourself, let alone with someone you love, let alone someone professional. It’s your fault that that happened to you, right?” – Paul Conti

- Paul hasn’t worked with a person where shedding light on shame wasn’t extremely helpful
  - It brings a sense of levity
  - Even though it has moments of fear and misery
  - It also has moments of bringing good memories to the fore
- But the impacts of shame make it hard to bring it to the light
  - Health systems go along with this by shuttling people through the system with a prescription for [Prozac](https://en.wikipedia.org/wiki/Fluoxetine)

> “So society colludes with shame in preventing way too many of us from ever getting a handle on our trauma, when it’s actually not rocket science to do so” – Paul Conti

**Healing take time** [1:36:15]

- Peter asks, once a light is shined on the shame and the person realizes why they feel a certain way, how can they change this feeling?
  - Is step 1 to understand why?
  - Is then step 2 to change the feeling?
- Yes and this work takes time

> “We live in a society that so wants rapid results. And that’s why we throw medicines at so, so many things” – Paul Conti

- For example, pick out a word and say it over 500 times, what’s the chance of thinking of that word tomorrow?
  - What if someone said the word 5,000 times
  - It will be in their head next week
- What someone says to themselves and how they conceptualize theirselves won’t go away overnight
  - Especially when it’s overly reinforced
  - There are several milestones to overcome
- One milestone is the realization of the shame
  - For example, a patient may realize, “*Oh my God, the shame isn’t mine. I was six years old. The shame is that person who hurt me.*”
  - Paul points out that all those thoughts and the feelings attached to those thoughts [of shame] are not going away but they will attenuate over time
- Another victory is to disempower these thoughts when they come
  - For example, a patient may think, “*Oh, you’re worth nothing and that was your fault. And if you’d been better, that wouldn’t have happened to you.*”
  - They can disempower this by realizing, “*Wait a second. I don’t actually believe that. I can’t keep it out of my head, but I’m going to put you back thought, I’m going to direct my thoughts away from you more quickly.*”
  - And there are more strategies around that
- Often practitioners think their patient has failed the treatment, and everyone looks at this negatively, because 2, 3, 4 weeks later, they’re not better
  - “*There’s no way on God’s earth they were going to be better after 2, 3, 4 weeks; something that’s developed over years; it doesn’t go away that quickly*”
- Instead, engage in this process and take away the fear
  - The patient needs to be prepared with what is realistic— they can get better, but it’s going to take place over time
  - The patient doesn’t need to be afraid when bad thoughts are in their mind
- Paul has worked with people who started treatment before he met them, and they had among the most severe repeated negative thoughts and feelings inside them
  - They may have been doing really well for 10, 20 years, but if they’re put under enough stress and enough triggering, these thoughts will still come back to their mind— “*Oh, you’re nothing and you should kill yourself*.”
  - But now they know well enough to realize, “*Wow, that stuff dies hard.*“
  - And to not be afraid of it one little bit, because that person understands that he said that to himself 100,000 times
    - It’s still going to come back every now and then
    - This doesn’t have to mean anything
    - That person doesn’t have to believe it

**The need for psycho-education**

- Paul believes psychiatrists have to educate people
- The mental health field doesn’t put very much value in psycho-education, “*let’s help you understand yourself”*
- A lot of what he does is psycho-education through the lens of understanding trauma
  - If he could only choose 1 thing to do for patients, maybe he can’t prescribe medicine anymore or cant do depth psychotherapy or can’t use multiple modalities
  - If he could only do 1 thing, he would choose psycho-education about trauma
    - Because then he can arm people with knowledge they didn’t have before, and they can go help themselves
    - With this knowledge they can get help from people who are close to them
- This is a point of his book, he wants anyone who picks it up to be able to read their way through it, and at the end of it have knowledge and education they didn’t have before
  - Then they’ll be equipped to do something good with it
  - Even if they are limited by time, circumstances, resources, etc.

## The emotional health component of healthspan [1:41:15]

**What is the healthspan?**

- Peter reflects on his practice and all the dimensions of healthspan
- Longevity refers to 2 things: 1) how long one lives and 2) the health span or how well they live
- Within health span, there are 3 dimensions— the cognitive, physical/exoskeleton, and emotional
  - 1) The cognitive dimension— how sharp is one’s brain
    - Dementia is the extreme loss of this
  - 2) The physical or structural dimension— the ability to be free of pain and carry out one’s daily activities and everything they enjoy doing physically
  - 3) The emotional dimension— some people call this the mind or the spirit
    - Peter thinks this emotional dimension is the hardest one for his practice to help patients with because they don’t have a great set of screening tools
    - On the lifespan side there are lots of great screening tools— biomarkers and MRI scanners and liquid biopsy and colonoscopies

> “I mean, we’re very good at trying to identify the things that will end your life in a binary fashion from a cardio respiratory standpoint. We’re not very good at identifying the things that are going to end your life emotionally.” – Peter Attia

- In the book Peter is working on he writes about 4 types of deaths
  - 1) The death certificate— cardio, respiratory, pulmonary death
  - 2) Cognitive death— the decline of the ability of the brain with respect to processing speed, short term memory, long term memory, and executive function
  - 3) The physical/ exoskeleton death— this leaves a person in pain and unable to carry out the activities of daily living
  - 4) Emotional death
- Peter notes, “*In some ways the perfect life would be a long life that just goes straight to type 1 death without detouring through type 2, type 3 and type 4. But tragically, that’s almost never the case.*”
- He thinks so much about how to identify and treat type 2, 3, & 4
- Type 4 is by far the one in which they are the most limited in how to identify
  - Part of this is shame
  - Part is inadequacy of tools
  - Compare it to the physical dimension, of which there are many ways to access: movement, strength, balance, stability, stamina, etc.
    - And usually once people are confronted with how bad they are, they will take the steps to train and get better

**How to improve emotional health screening in patients**

- For years Peter has wondered how to do the same sort of screening with emotional health
  - How would it be received?
  - Then how would they implement therapy?
- Because if someone is doing very well on type 1, 2, & 3 [of the types of death], meaning they have no chronic diseases, no acute diseases; their mind is sharp, their body is great, but they’re a slave to some shame that’s rooted in trauma, they can often have the most miserable life
  - Then how long they live becomes completely irrelevant; in fact, it become a curse, more time to suffer
  - A lot of these people of course, are not obviously suffering
- Paul notes, there are enough external markers that one can make that conclusion with a high degree of certainty
  - Peter agrees and notes the patient is probably self-aware enough
- But what about someone who is quite successful by all the metrics of the external world—  they’re successful financially, they have a wonderful family, all these other things; it usually takes a bit of prodding for them to acknowledge a
  - And one has to be astute enough to prod and realize that actually all is not well
- Peter notes, “*I’m not a psychiatrist. How do I bring our evaluation of what I call type four death or demise up to the level of our ability to evaluate the other three?*”
- Paul thanks Peter for being kind enough to share some excerpts from his book, and he thinks these aspects of life that he’s talking about are so important
  - They ask the question, “*Am I taking care of myself in the way I want to? Am I paying attention to my life in the way that I want to?*”
  - He agrees that the emotional aspect is the hardest to identify; there aren’t serological  markers for it
  - Often the truth of what may be going on is under the surface
- He thinks Peter is already doing the right thing; he sometimes refers patients to him
- Peter thinks his practice does a better job than most but he wonders why they can’t do better
  - Why is it that there are some patients whom he suspects there’s an issue, but as he broaches it there’s complete denial?
  - Or there’s other patients who on the surface will accept it, but then he can’t get them to engage in it?
- Paul notes that Peter’s patients are a little different than those generally going in for healthcare
  - Peter’s patients come to him wanting to be the healthiest they can be
  - Normally, people present to healthcare because they have a problem
- Paul thinks good mental health is always consistent with simplicity
  - If someone wants to be healthy and they come to a health assisting resource, one would presume they are going to act in ways that assist the resource that’s helping them
  - If they’re not acting in that way, this indicates there’s something going on that’s not consistent with that simple, common sense understanding of how to make their lives better
    - This will point towards something in the mental health spectrum, which the vast majority of times has its roots in trauma
- The red flags for emotional health problems are if Peter sees people running countercurrent to their stated goals, or if the person is sharing something about their inner world that is not consistent with what he sees on the outside
  - This dissonance leads to the realization, “*Ah, there’s something going on here that it’s affecting them emotionally, even if they are still trying to be healthy*”
  - There is a recognition that something under the surface is taking a toll and the doctor wants to understand it better and guide the patient in the right direction
- For example, a person really wants to stay alive because they love their grandkids but they have diabetes and this is their 3rd hospital admission in 2 years
  - Clearly this person doesn’t want this to happen
  - They like their life and they’re grounded to these reasons of being healthy and staying alive, but they can’t act that way
  - Maybe there are non-trauma related barriers to them getting to care or taking medicines
  - If the realization is there’s something that’s preventing that person from taking care of themselves, then there might be something in their mental health that can be helped
- So looking for vectors that run countercurrent to the person’s stated and healthy intentions and trying to get some assessment of what’s going on in the person’s inner world
  - Because even if things are going well in the outer world, these problems in the inner world represent risks for the future
- This is not that hard to do; Paul think’s Peter is reflexively doing this because he’s applying common sense to his practice
  - If he sees something outside of the norm that seems to indicate mental health, he refers the patient to a psychiatrist

> “But the health systems in our society as a whole can be doing this to help people, because it’s not that hard to take stock of someone’s inner state. If you sit down and talk with them and you establish the right rapport or to call out when they’re acting countercurrent with their stated intentions.” – Paul Conti

- A lot of times the general medical systems push this under the rug, because they don’t know what to do about it
  - They keep trying to treat the diabetes as best they can, with some knowledge in their head that this lovely person who wants to be healthy, isn’t really on board with this

## How to reframe the conversation about mental health for a better future [1:52:00]

- Peter asks if he thinks there will be a day when shame is out in the open
  - “*What does a world look like in which the light switch gets turned on and shame has to retreat to the corner and cower, as opposed to letting its cape sit over that which needs to be exposed?*”

**Begin by improving emotional education**

- Paul thinks a big part of that is in the education process in our society
  - It’s not hard to cast a broad net and start in early education
  - Talk about what goes on in people when they feel bad and when something makes them feel good; what do they do with that feeling?
  - Help the bully, understand why he or she is bullying when they’re in first or second grade
- It begins with educating the professionals— the teachers, the doctors, the police, the legal system
  - He’s not saying, “*Well, let’s bolt on some process that tries to turn everyone into a therapist*”
- Consider how many checklists, how much paperwork there is in medicine
  - This is utterly and completely noncontributory and everybody knows it
- Why not an approach that’s not paperwork intensive or time intensive that just looks at trying to understand somebody and thinking about them through this framing
  - And structuring the mental health resources so that there is a place to send someone
  - So  there’s a place where the patient can have basic conversations about what’s going on inside of them; then that gates the care
- There are mental health courts now, they’re not nearly as widespread as they should be, but psychiatrists are trying to educate doctors in the legal process and the education process, but they’re not prioritizing it with a sense of urgency

**Red flags of untreated mental health problems**

- This can be different, it needs to be said, “*This is worth paying attention to. Is this a large part of what’s driving the over 100,000 drug deaths in this country every year?*”
  - Why is there not a sense of urgency and want to look at the way that help is provided?
- Does the current method drive doctors to burnout? (this is a term Paul can’t stand)
  - When Paul grew up, burnout wa a negative term to say somebody couldn’t handle it; it was an insult
- Now there are doctors who are often traumatized by the health systems that they work in and the unreasonable expectations in that they’re treating charts and computers all the time and don’t have enough time with their patients
  - This needs to be looked at

> “We spend more money than any developed country on healthcare? Yet we have the worst outcomes” – Paul Conti

- Has the system gone mad?

- Why is our healthcare the worst at things that involve direct patient contact, preventative healthcare, and treatment over time?
- There needs to be a sense of urgency and a realization that this isn’t working

**The benefit of public figures who talk about their own trauma**

- When people that others look to, and have a sense of respect for, talk about their own trauma it helps
  - Such as [Tim Ferriss](https://en.wikipedia.org/wiki/Tim_Ferriss) and [Stefanie Germanotta](https://en.wikipedia.org/wiki/Lady_Gaga)
    - And Lady Gaga, who was kind enough to write the forward for his book
    - She talks about her humanness and that all of us, no matter who we are, are susceptible to this
  - This includes in some small way what Paul and Peter are trying to do
- When Paul gives a talk to a bunch of doctors, he’s not going to pretend that he doesn’t have any trauma
- There is a responsibility to be open and honest about the things that have impacted us

**How to reframe the conversation about mental health**

- The other and most important aspect is on this grassroots level of changing how we frame mental health in the world around us
  - Starting with curiosity about it at very early stages of life— “*when that bully tells you that you’re lousy because of what you look like or where you come from, what does that make you feel? And let’s start looking at that reflexive sense of shame*.”
    - There is a need to stop and think about that
    - Does one feel bad when that happens and what happens next?
    - If one feels bad about themself, then let’s put a full stop to it there
    - The bully is hurting someone because they feel bad about themself
    - One needs to put a barrier between the reflexive shame and feeling bad about themselves
    - Many people don’t actually logically feel bad about themselves, but this is something they feel
    - And the feeling matters, not the fact, not the logic
- This is a plain and obvious truth that pervades the society around us— feelings matter (even if illogical) and need to be addressed
  - As individuals we are doing a very poor job of developing understanding in us at any stage of life and as a society
- These are big, all encompassing aspects of our society
  - We can see that things are not going well
  - And if one looks at the roots of it, it’s clear that what can be done
- Paul feels his book is uplifting because it points out the problems and simple, well-grounded solutions
  - He thinks the common sense of it will resonate with people

## The growing impact of trauma on our society and the need for compassion [1:58:45]

**Is there a link between the new highs in drug overdose and trauma?**

- Peter returns to a statistic that Paul mentioned earlier, that the US has for the first time ever surpassed a 100,000 person mortality for a 12 month period due to overdose
  - He thinks for many people, this is almost impossible to fathom
  - 1) Is this an epidemic of trauma and shame?
  - 2) Or is the availability of cheap and highly potent opioids just a new escape valve?
- Paul think’s it a combination of these 2

**Drugs— an escape valve**

- The more and more people are feeling desperate and disenfranchised and are feeling like, look, I can’t make my way in the world, the more likely they are to look for an escape
  - Whatever a person’s endeavor is, if they can’t get ahead, they don’t feel good about themselves
    - If they can’t make a living, they can’t support their family
  - He sees this even in  people who have good jobs who feel like, “*okay, I finally got my way, if I work hard, if I have a good job…*” but often that job is running them ragged in a way that they can’t take care of themselves and they can’t take care of their families
    - Now they feel the same desperation as a person who doesn’t have a job
- This desperation builds anger and frustration and resentment and all these other symptoms, depression and panic that spin off of it
- And that makes it much more appealing to soothe in the short term
  - That’s a basic psychological fact of human beings
  - The more pain one is in, in the short term, the more one is going to choose a short term solution without any consideration to the long term
  - Consider someone who is absolutely desperately miserable and there is something that can make them feel better right now; they’re not going to ask what that may do to them tomorrow

**There is a need for compassion in society**

> “So we have of developed a society that has become more and more and more hardhearted towards people’s attempts to make their way in the world” – Paul Conti

- Paul sees that with the response to the pandemic
  - People respond in the way they want and they don’t really care about the other person

> “I cringe at times at our inability to even have basic compassion for others” – Paul Conti

- Of course this isn’t everyone, but he thinks it’s present in society in ways that it wasn’t before
- This is reflected in the rhetoric and the dialogue that’s acceptable
  - It was not that long ago that behavior of those who currently have a public presence would have been met with censure by everyone
    - The public would say, “*hey, I don’t even care that you’re advocating for what I want, or even for me directly, I can’t support you if you’re going to behave that way, talk that way, denigrate people that way.*”
    - We’ve moved far away from that and we need to look at what are we doing in the world around us?
    - How are we handling ourselves?
    - Are we indirectly promoting this ethic of not really caring that leads to desperation, that leads people to soothe with drugs
- It’s a tragic atrocity that people will say, “*oh gosh, I have four people who are drug addicted in my practice I’m going to see this afternoon*” (or 10 people)
  - It’s not who it used to be
  - Before the addicts used to be those who had sifted down to the places in society where society turned their backs on them
- Now addiction affects people from all walks of life
  - It’s gone beyond socioeconomic demographic, educational demographic, geographic, demographic, racial, religious, or ethnic concept,
  - Everyone is menaced by this because there’s often a desperation to soothe that wasn’t there before
  - It has shot through every demographic
- And if we continue to turn away from this fact, then we continue to look at statistics like that and say, “*oh my gosh, how horrible*” without doing anything about it then it becomes acceptance

> “If we don’t look at what are we doing to people that drives them to desperation, then we’re not going to make that statistic better” – Paul Conti

- How much is going on behind closed doors in the pandemic?
  - How much violence behind closed doors?
  - Neglect behind closed doors?
  - Drug and alcohol abuse behind closed doors?
- Are we going to look more at this? Or are we going to just pay lip service to looking at it while we don’t actually change anything?
  - Without action this number is going to increase
- People often say Paul’s interest in trauma is a niche
  - He disagrees; with numbers  like this, there is a cascade through the population
  - Without change the burden of trauma is going to just grow and grow
  - We should be appalled enough by the number of overdose deaths to do something

## Society’s antiquated way of treating manifestations of trauma rather than root issues [2:04:15]

**How can treatment be improved?**

- Peter notes that people are often treated and categorized based on the symptom of their trauma
  - Even within the lens of helping people and acknowledging their trauma
  - For example, addiction is a very common manifestation of trauma
    - The most obvious is substance addiction, alcohol or drugs
    - But there’s work addiction, there’s process addiction, here’s gambling addiction, there’s sex addiction
    - There are lots of other types of addictions; there’s co- dependencies, there’s anger, perfectionism, other means of control…eating disorders.
  - It seems that one way to think about this is treating people together who have similar end states
    - Such as a 12-step meeting
    - These often group people according to their specific addiction
- But what if people were bundled together through the common lens of what the trauma was?
  - Would that be more or less efficacious than the current approach?
  - This would mean having a meeting with lots of people who have very different manifestations of their trauma, combining someone who is— addicted to alcohol, a workaholic, a rageaholic, codependent, someone who’s got debilitating anxiety, someone who’s got debilitating depression
  - But what they all have in common is they were completely neglected by their parents
  - Would there be any advantage of grouping people by a common thread?
- Paul thinks there is a huge advantage to this
- At one point when he was the medical director for a clinic, they had programs running for helping groups; by and large it was all centered around substance abuse, but he wouldn’t separate the groups by what the substance was

> “There’s so many ways in which the addictive processes can take hold of our brains in order to provide some short term sense of control or short term relief from the desperation of feeling out of control. And when we parse that out too much, then again, we’re just trying to check boxes.” – Paul Conti

- When health care does this, it tells a person what they have, in a sense that this thing is their burden to carry and it’s about them
  - The language is often stigmatizing, “Well, I’m an alcoholic and I’m a rageaholic”
  - It sends the message— “*this is the thing that is bad about you*”
  - None of us come out of the womb an alcoholic, or a rageaholic, or addicted to unhealthy foods
- It’s important to look at what’s happened to someone along the way that leads them to this place
  - A search for commonality is needed
- Instead, if healthcare sets up a process that parses things out, they’ve overly reductionist
  - Now the alcoholic feels like they have nothing in common with the person who is addicted to cocaine

**Trauma— a common thread running through many mental health problems**

- In contrast, Paul who knows the health histories of these people as the medical director of their clinic sees the common driving force behind each of their behaviors is trauma
  - This is the commonality 80% of the time
- When he steps back, he can see that many of the ways patients get short term relief is at the expense of their long term health

- To be overly reductionist and put things in little buckets may a feeling of satisfaction of doing something but it prevents the healthcare professional from getting into what’s real about the patient’s problem
- There is a need to put those people together and look at trauma
  - Ironically, this is what the helping resources around trauma are doing, such as [Bridge to Recovery](https://www.thebridgetorecovery.com/)
- When he looks at people who are addicted to one thing versus another, he doesn’t find massive differences between them
  - Aspects of science are catching up with this and show that is true
  - The same machinery in the brain is hijacked

**The need to reassess and change how the medical establishment approaches mental health problems**

- But people have these entrenched ways of looking at it through the lens of how medical care is or how society views it
- There’s a lot of data behind the interventions
- In mental health, the practice within individual practitioners and the systems can be antiquated by a half a century or a couple thousand years in some cases
  - No one comes in and looks at that
  - There are programs that are taking care of people for opiate dependence that don’t even talk to them about a medicine that you can get, a shot that prevents them from overdosing
  - This is not okay
- A big part of that is the stigma, the shame that we don’t want to come in and look at all of it and say, there’s something obvious here that we’re just not paying attention to
- Because if the shame is shot through humans, then it is also shot through the humans who are making those decisions around resource allocation and how to approach the helping process

## Potential role of psychedelics like psilocybin and MDMA in treating trauma [2:11:15]

- Peter switches gears to ask about the role of [psilocybin](https://en.wikipedia.org/wiki/Psilocybin) and [MDMA](https://en.wikipedia.org/wiki/MDMA) in treating trauma
  - This has been discussed numerous times on the website (see Selected Links section below)
- MDMA has been tested in clinical trials for treatment of PTSD
  - Published in *Nature Medicine* in 2021, [MDMA-assisted therapy for severe PTSD: a randomized, double-blind, placebo-controlled phase 3 study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8205851/)

> “I see it as among the brightest sort of shining hopes for the future” – Paul Conti

- The data, both from decades ago, and more recent clinical trials, and firsthand reports tell us these drugs provide a great potential for understanding and helping
  - These drugs are so incredibly powerful and fit with a lot of what psychiatrists have understood about brain biology and psychology
  - The process is in place so that they can be understood and deployed safely and effectively
- Paul thinks the hope they provide for better treatment is immense
- There’s a story he likes to tell that captures the potential of these drugs for improving treatment
  - Where he grew up was close to the [Delaware and Raritan Canal](https://en.wikipedia.org/wiki/Delaware_and_Raritan_Canal)
  - In colonial times it ran between New York and Philadelphia; it was part of a network
  - He was always fascinated by the artifacts that were found
    - Somebody would be fishing and find a vase or something
    - Barges went up and down the canal; and people would find things and that was interesting.
  - At some point in time, a whole section of the canal was drained
  - And what was found is a kind of analogy to the helping powers of these substances
- These drugs are so strong that they can get one to places of really seeing what’s going on inside and shift those brain pathways, and cause a change
  - The science tells us this is not esoteric
- There is more science that is similar to what the CAT scan can do for the appendix, to see that these helping modalities allows for understanding and makes it easier for people to change in ways that can let them reorient much faster

> “There’s a potential here for a revolution within the field, but we have to safely and effectively incorporate those arrows into the quiver” —Paul Conti

**Resistance to using psychedelics in therapy**

- What is often seen is that many of the people and organizations wielding the helping resources don’t like this
  - Some aspects of traditional psychiatric care that don’t like this
  - Perhaps that’s through a sense of threat
  - The power of these resources make a lot of the tools that psychiatrists currently wield seem a little bit paltry in comparison
  - Of course, this is not always the case
- Western medicine needs to approach these wonderful, new, powerful tools through a lens of being respectful of wanting to understand the new modalities
  - It’s also important that they know what all the arrows in the quiver are and understand them enough to know who they will help

> “If I’m coming in the door for help, I don’t care what it is. I want the person who’s going to help me to have all the possible arrows in their quiver.” – Paul Conti

- Western medicine can get to a place of incorporating this, but society and helping systems have to bend a little bit to acknowledge the incredible potential of these drugs
- It’s important to work towards integrating instead of splitting
  - And our societal mode in this country that’s very much aimed at splitting, be it sociology, politics, even medical care

## Parting thoughts and resources for getting help [2:16:30]

**Basic themes discussed in his book**

- Paul’s book is [Trauma: The Invisible Epidemic: How Trauma Works and How We Can Heal From It](https://www.amazon.com/Trauma-Invisible-Epidemic-Works-Heal/dp/1683647351/ref=sr_1_3?crid=2Y4RURJAIXYUQ&keywords=paul+conti+trauma&qid=1638386640&sprefix=paul+conti+%2Caps%2C181&sr=8-3)

> “I think it’s trauma that leads us to reject new helping resources, because they may be threatening to our power within the discipline. And that by regrounding to really the first principles of knowledge and of helping, then I think we, again, come back to an urgency to ground ourselves to the basic common sense of understanding everything that could be helpful and having all of those arrows in the quiver of health systems or of to the extent possible, individual practitioners.” – Paul Conti

- The clinic he works at is [Pacific Premier Group](https://www.pacificpremiergroup.com/)
- Another place people can get help is through [NAMI](https://nami.org/Support-Education) (National Alliance on Mental Health)
  - They often have resources on a local level
- There is help one can access in their own home, people who love and care about them
  - Access help by thinking about what’s going on inside oneself and others
- The message Paul wants to deliver is— this help isn’t esoteric
  - Ground to what’s really going on inside
  - Pay attention to it and be brave enough to face it
  - There is hope in facing it and this will allow one to begin a process of helping themselves and others
  - He has seen this unfold many times, including in himself, that he really believes in it

§

## Selected Links / Related Material

**Paul’s latest book**: [Trauma: The Invisible Epidemic: How Trauma Works and How We Can Heal From It](https://www.amazon.com/Trauma-Invisible-Epidemic-Works-Heal/dp/1683647351/ref=sr_1_3?crid=2Y4RURJAIXYUQ&keywords=paul+conti+trauma&qid=1638386640&sprefix=paul+conti+%2Caps%2C181&sr=8-3)  by Paul Conti (Author) and Lady Gaga (Introduction) (2021) | [1:00, 3:00, 5:30, 17:45, 28:00, 44:15, 58:00, 1:05:45, 1:08:00, 1:40:45, 1:56:00, 2:16:30]

**Paul’s clinic in Portland, Oregon**: [Pacific Premier Group](https://www.pacificpremiergroup.com/) | [1:15, 3:30, 1:22:30, 2:06:15,  2:16:45]

**Paul’s first appearance on this podcast**: [#15 – Paul Conti, M.D.: trauma, suicide, community, and self-compassion](https://peterattiamd.com/paulconti/) | The Drive with host Peter Attia,  ([PeterAttiaMD.com](https://peterattiamd.com/)) | [3:00]

**Epigenetic changes occur after trauma**: [Epigenetic Modifications in Stress Response Genes Associated With Childhood Trauma](https://www.frontiersin.org/articles/10.3389/fpsyt.2019.00808/full) | *Frontiers in Psychiatry* (S Jiang *et al.* 2019) | [58:15]

**Previous discussion/ podcasts on PeterAttiaMD.com about the use of psychedelics to treat mental illness**:

- Treatments: [Promise and challenges for psilocybin and MDMA use in treatment: What lies ahead before FDA approval](https://peterattiamd.com/promise-and-challenges-for-psilocybin-and-mdma-use-in-treatment/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (February 28, 2021) | [2:11:15]
- Mental health: [Psilocybin for depression? The psychedelic drug goes head-to-head with Lexapro in a recent trial](https://peterattiamd.com/psilocybin-for-depression/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (May 23, 2021) | [2:11:15]
- Mental health: [MDMA for PTSD? MDMA-assisted therapy gets one step closer to its projected 2023 FDA approval](https://peterattiamd.com/mdma-for-ptsd/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (May 30, 2021) | [2:11:15]
- Mental health: [Alternative perspectives on drug use and addiction: Considerations for drug use and treatment](https://peterattiamd.com/alternative-perspectives-on-drug-use-and-addiction/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (August 15, 2021) | [2:11:15]
- Mental health: [How should we do drugs now? Searching for a Bob Ross painting](https://peterattiamd.com/how-should-we-do-drugs-now-searching-for-a-bob-ross-painting/) | Peter Attia, [peterattiamd.com](https://peterattiamd.com/) (August 22, 2021) | [2:11:15]
- [#01 – Tim Ferriss: depression, psychedelics, and emotional resilience](https://peterattiamd.com/timferriss/) | Host Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) | [2:11:15]
- [#15 – Paul Conti, M.D.: trauma, suicide, community, and self-compassion](https://peterattiamd.com/paulconti/) | Host Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) | [2:11:15]
- [#34 – Sam Harris, Ph.D.: The transformative power of mindfulness](https://peterattiamd.com/samharris/) | Host Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) | [2:11:15]
- [#65 – Rick Doblin, Ph.D.: MDMA — the creation, scheduling, toxicity, therapeutic use, and changing public opinion of what is possibly the single most important synthetic molecule ever created by our species](https://peterattiamd.com/rickdoblin/) | Host Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) | [2:11:15]
- [#76 – Kyle Kingsbury: Finding meaning, depression, and psychedelics](https://peterattiamd.com/kylekingsbury/) | Host Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) | [2:11:15]
- [#135 – BJ Miller, M.D.: How understanding death leads to a better life](https://peterattiamd.com/bjmiller/) | Host Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) | [2:11:15]
- [#139 – Kristin Neff, Ph.D.: The Power of Self-Compassion](https://peterattiamd.com/kristin-neff-the-power-of-self-compassion/) | Host Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) | [2:11:15]
- [#172 – Esther Perel: The effects of trauma, the role of narratives in shaping our worldview, and why we need to accept uncomfortable emotions](https://peterattiamd.com/estherperel/) | Host Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) | [2:11:15]
- [#182 – David Nutt: Psychedelics & Recreational Drugs](https://peterattiamd.com/davidnutt/) | Host Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) | [2:11:15]

**The use of MDMA for treating PTSD, clinical trials**:

- [MDMA-assisted therapy for severe PTSD: a randomized, double-blind, placebo-controlled phase 3 study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8205851/) | *Nature Medicine* (J M Mitchell *et al.* 2021) | [2:11:30]
- [The safety and efficacy of {+/-}3,4-methylenedioxymethamphetamine-assisted psychotherapy in subjects with chronic, treatment-resistant posttraumatic stress disorder: the first randomized controlled pilot study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3122379/) | *Psychopharmacology* (M C Mithoefer *et al.* 2010)
- [MDMA-assisted psychotherapy for treatment of PTSD: study design and rationale for phase 3 trials based on pooled analysis of six phase 2 randomized controlled trials](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6695343/) | *Psychopharmacology* (Michael C. Mithoefer *et al.* 2019)
- [Posttraumatic Growth After MDMA-Assisted Psychotherapy for Posttraumatic Stress Disorder](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7216948/) | *Journal of Traumatic Stress* (I Gorman *et al.* 2020)
- [Long-term follow-up outcomes of MDMA-assisted psychotherapy for treatment of PTSD: a longitudinal pooled analysis of six phase 2 trials](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7351848/) | *Psychopharmacology* (L Jerome *et al*. 2020)

**NAMI (National Alliance on Mental Health)**: [Support & Education](https://nami.org/Support-Education) | [2:16:45]

§

## People Mentioned

- [Dr. Mary Anne Badaracco](https://connects.catalyst.harvard.edu/Profiles/display/Person/29824) (important mentor for Paul at Harvard) [26:30]
- [Stephanie von Guttenberg](https://en.wikipedia.org/wiki/Stephanie_zu_Guttenberg) (expert on prevention of child abuse) [58:00]
- [Daryn Reicherter](https://profiles.stanford.edu/daryn-reicherter) (professor at Stanford who specializes in trauma research) [58:00]
- [Tim Ferriss](https://en.wikipedia.org/wiki/Tim_Ferriss) [1:56:00]
- [Stefanie Germanotta](https://en.wikipedia.org/wiki/Lady_Gaga) (aka Lady Gaga; singer, songwriter, actress) [1:56:00]

§

![](https://peterattiamd.com/wp-content/uploads/2022/01/1x1-conti-500x500.jpeg)

##### Paul Conti, M.D.

Dr. Paul M. Conti is a graduate of Stanford University School of Medicine. He completed his training at Stanford and at Harvard, where he served as Chief Resident. He then worked in private practice while serving on the medical faculty at Harvard. Dr. Conti was named as one of Oregon’s Top Psychiatrists in 2008, his first full year of practice in Oregon. He is a general psychiatrist, treating all aspects of both mental illness and the impact of life stressors. Dr. Conti is adept at helping people untangle complex problems, and he incorporates a holistic view of each client or patient into his work, knowing the far-reaching impacts trauma can have upon the systems and communities in which an individual resides, works, and serves. His practice includes the use of medications and psychotherapy, and he also treats complex cases, co-occurring alcohol and drug issues, and does neuropsychiatric assessments. In addition to clinical treatment, Dr. Conti provides business-related and legal consulting services.  He is the author of *Trauma: The Invisible Epidemic*, a book that brings his valuable insights about how we can collectively heal from trauma’s effects to a larger audience. [[Pacific Premier Group](https://www.pacificpremiergroup.com/coaches-consultants/)]