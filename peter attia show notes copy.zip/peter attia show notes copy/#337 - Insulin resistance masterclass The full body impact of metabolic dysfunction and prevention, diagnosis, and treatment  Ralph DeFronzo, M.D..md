# #337 – Insulin resistance masterclass: The full body impact of metabolic dysfunction and prevention, diagnosis, and treatment | Ralph DeFronzo, M.D.

**Source:** [https://peterattiamd.com/ralphdefronzo/](https://peterattiamd.com/ralphdefronzo/)

---

Ralph DeFronzo is a distinguished diabetes researcher and clinician whose groundbreaking work on insulin resistance has reshaped the understanding and treatment of type 2 diabetes. In this episode, Ralph shares insights from his five decades of research, including his pivotal role in bringing metformin to the U.S. and developing SGLT2 inhibitors. Ralph explores the impacts of insulin resistance on specific organs, the pharmacologic interventions available, and the gold-standard euglycemic clamp method for measuring insulin resistance. This episode is a masterclass in the pathophysiology and treatment of type 2 diabetes, featuring an in-depth discussion of GLP-1 receptor agonists, metformin, and a lesser-known class of drugs that opened Peter’s eyes to new possibilities in diabetes care.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/ralphdefronzo/the_Drive_public.png)

Play

#337 - Insulin resistance masterclass: The full body impact of metabolic dysfunction and prevention, diagnosis, and treatment | Ralph DeFronzo, M.D.

#337 - Insulin resistance masterclass: The full body impact of metabolic dysfunction and prevention, diagnosis, and treatment | Ralph DeFronzo, M.D.

1x15s30s

0:002:26:40

## We discuss:

- Metabolic disease as a foundational driver of chronic illness [4:00];
- Defining insulin resistance: effects on glucose, fat, and protein metabolism, and how it varies between healthy, obese, and diabetic individuals [8:15];
- The historical significance of the development of the euglycemic clamp technique for measuring insulin resistance [11:45];
- How insulin affects different tissues: liver, muscle, and fat cells [15:00];
- The different ways insulin resistance manifests in various tissues: Alzheimer’s disease, cardiovascular disease, and more [25:00];
- The dangers of hyperinsulinemia, and the importance of keeping insulin levels within a physiological range [29:00];
- The challenges of identifying the genetic basis of insulin resistance and type 2 diabetes [37:00];
- The “ominous octet”—a more comprehensive model of type 2 diabetes than the traditional triumvirate [45:45];
- The kidneys’ unexpected role in worsening diabetes, and how SGLT2 inhibitors were developed to treat diabetes [55:45];
- How insulin resistance in the brain and neurocircuitry dysfunction contribute to overeating and metabolic disease [1:04:15];
- Lipotoxicity: how overeating fuels insulin resistance and mitochondrial dysfunction [1:07:30];
- Pioglitazone: an underappreciated and misunderstood treatment for insulin resistance [1:10:15];
- Metformin: debunking the misconception that it is an insulin sensitizer and explaining its true mechanism of action [1:19:15];
- Treating diabetes with triple therapy vs. the ADA approach: a better path for diabetes management [1:24:00];
- GLP-1 agonists, the Qatar study, and rethinking diabetes treatment [1:31:30];
- Using a hyperglycemic clamp to look for genes that cause diabetes [1:45:15];
- The superiority of measuring C-peptide instead of insulin to assess beta-cell function [1:46:45];
- How GLP-1-induced weight loss affects muscle mass, the benefits and risks of myostatin inhibitors, and the need for better methods of evaluating functional outcomes of increased muscle mass [1:51:30];
- The growing crisis of childhood obesity and challenges in treating it [2:02:15];
- The environmental and neurological factors driving the obesity epidemic [2:07:30];
- The role of genetics, insulin signaling defects, and lipotoxicity in insulin resistance and diabetes treatment challenges [2:11:00];
- The oral glucose tolerance test (OGTT): detecting early insulin resistance and beta cell dysfunction [2:18:30]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dr. Ralph DeFronzo is a distinguished diabetes researcher and clinician known for his pivotal work in advancing the understanding and treatment of type 2 diabetes
- He is widely recognized for his ground breaking contribution to the concept of insulin resistance
  - Which has reshaped the understanding of type 2 diabetes and its progression
- He played a very important role in bringing metformin to the US as a standard treatment for this disease 40 years ago, along with the discovery and development of SLGT2 inhibitor (a class of drugs you have no doubt heard Peter discuss many times before)
- With over 5 decades of research in the field, Dr. DeFronzo has received numerous prestigious accolades including the Banting and Claude Bernard Award ‒ the highest honors that can be given to diabetologist
- This episode is really a master class in the organ-specific aspects, the pharmacology, the diagnosis of type 2 diabetes, and it draws from his vast experience
- If you listened to Peter’s conversation with Gerald Shulman a few years ago on insulin resistance [[episode #140](https://peterattiamd.com/geraldshulman/)], what amazed Peter was how little overlap there was
  - Not because the information is not congruent, but because of how much we were able to go into different topics
  - The discussion with Shulman really focused on one of the areas where insulin resistance manifests ‒ in the muscle
  - Peter would encourage everyone to go back and listen to this episode
- What we talk about here is all of the other organs
  - Spoiler alert: there are 7 organs that are impacted by this condition
- We go into much greater detail there in addition to the pharmacologic interventions

Peter adds, “*I learned more in this podcast than I do in most podcasts. It’s one of the few that I had to immediately go back and listen to*.”

- Peter’s notes from this podcast are so voluminous that they even provided substrate for internal meetings with his team in the clinical practice
  - In short, there are many things that he has taken away from this that will directly impact his patients
- Other things discussed: we get into details about how insulin resistance impacts liver
- We do talk about muscle
- We talk more about fat cells
- We talk about Ralph’s development of the euglycemic clamp  ‒ the gold standard for measuring insulin resistance
- We talk about the pharmacology
  - Not just the SGLT2 inhibitors
  - The GLP-1 receptor agonists
  - Metformin
  - And another class of drug that we don’t talk about that often, that for Peter, this was a real eye-opener
- There’s a lot more Peter could say, but at the end of the day, you just got to listen to this one (maybe twice)

## Metabolic disease as a foundational driver of chronic illness [4:00]

- People who listen to Peter are familiar with him talking about these 4 horsemen:
  - Cardiovascular disease and cerebrovascular disease
  - Cancer
  - Neurodegenerative and dementing diseases
  - Metabolic disease
    - This one is the squishiest because it’s not the one that shows up on the most death certificates, but in many ways, it’s the foundational one that is amplifying the risk of all of those other causes of death
    - Spanning the spectrum from hyperinsulinemia to insulin resistance to fatty liver disease, all the way out to type 2 diabetes
- It seems very important that we should have a really thorough discussion of that foundational metabolic disease, and there’s no one better than Ralph to have that discussion

**Briefly tell folks what you’re doing at UT San Antonio and why you’ve spent the last 50 years working on this problem**

- Ralph has been in this field of metabolic disease for a long time
- He may be the longest consecutively funded [NIDDK](https://www.niddk.nih.gov/) investigator (53 years)
- He actually started even long before that when he was a medical student at Harvard
- He had this fantastic teacher, [Professor Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.), who gave the lectures on intermediary metabolism, and Ralph decided this is what he wanted to do
- He worked each summer with Professor Cahill

> “*Sometimes in life you meet the right person, the right opportunity and it changes everything you do*.”‒ Ralph DeFronzo

- What Ralph does now, he attributes directly to George
- When he gave the [Banting Lecture](https://pmc.ncbi.nlm.nih.gov/articles/PMC2661582/) in 2008
  - People usually put a picture of their mother, and father, and children
  - Ralph loves his mother, and father, and children, but he only showed one picture and that was Professor Cahill because he’s really the person who’s ended up directing him to where he is today

**People who are listening, who are particularly astute, might recall that Peter has referenced a number of Cahill’s** [**papers**](https://thehealthsciencesacademy.org/wp-content/uploads/2015/07/Fuel-Metabolism-in-Starvation_ReviewArticleTIMM2008-9Lazar-1.pdf)

- One of the more interesting studies he did, was the 40-day starvation [study](https://pubmed.ncbi.nlm.nih.gov/5720334/) in the mid-60s
- A group of students at Harvard did a water-only fast for 40 days, and he followed all the metabolites

***One of the things that was interesting to Peter was that even under a period of extreme starvation, the brain never gave up its dependency on glucose***

- Even though ketone bodies began to service the brain by about day 7-10 as the majority of the fuel, glucose was still providing about ⅓ of the brain’s energy
- The brain did switch over to ketone metabolism
- Ralph was not one of the people who did the 40-day fast, but he did fast for 5-7 days
  - If you fasted for 3 days you could get paid $50, and Ralph thought he was the richest guy in the world from this study
  - He can assure you that the physical specimens in this study were phenomenal

*The interesting thing you realize is that we have so much energy stored into human body*

- Who would’ve thought that a lean type person can fast for 40 days?

**⇒** The real problem is at some point you start to break down muscle

- And then if you start to break down cardiac muscle, prolonged fasting at that point becomes a problem
- But you have a lot of **energy stored in fat** and you can starve for a long time
- And obese people easily can go for 3, 4 months with all of the reserves that are in the body

## Defining insulin resistance: effects on glucose, fat, and protein metabolism, and how it varies between healthy, obese, and diabetic individuals [8:15]

**Insulin resistance is a term that gets thrown around constantly, explain what it is from a technical standpoint**

- Every time you eat a meal and your blood sugar level goes up, you’re going to release insulin

**⇒** Insulin is a master regulator for all biochemical processes in the body

- 1 – One of the things insulin is going to do, it’s going to talk to your muscles and say, “*Take up glucose and burn that glucose*.”
- What we need to know is, when you infuse insulin, how much of the glucose is taken up by the muscle
- We can compare a normal person, someone who is overweight, and someone who is diabetic

> “*I actually developed the gold standard technique which is the insulin clamp technique to look at this*.”‒ Ralph DeFronzo

- Comparing an overweight person to a lean person ‒ obese people are very insulin resistant **in terms of muscle glucose uptake**
- In a diabetic, they’re even more insulin resistant

*There are many processes that insulin controls*

- 2 – Insulin regulates how much fat is released from your fat cells
- Unfortunately, insulin keeps the fat in your fat cell
- But in obese people insulin doesn’t work so well
  - So instead of keeping the fat in the fat cell, even though your insulin is high, you’re breaking down the fat

***You have to look at each individual process that insulin is controlling ‒ insulin resistance is a general term because insulin controls many things***

- For that process, we know how a normal person should respond and how a diabetic responds
  - And the diabetic is much more insulin resistant
- 3 – Insulin controls protein metabolism ‒ it’s important in helping you build protein
- Ralph did a [study](https://dm5migu4zj3pb.cloudfront.net/manuscripts/113000/113272/JCI87113272.pdf) infusing insulin and carbon-labeled leucine to define how insulin promotes protein metabolism in a normal healthy person
  - He could do the same study in an obese person, and we know they don’t respond to insulin as well in terms of aggregating protein metabolism

Peter asks, “*Does that translate not just to structural proteins such as enzymes or cellular structural proteins but also macrostructural proteins such as muscle?*”

- Absolutely
- You can look at specific enzymes within the cell or muscle in terms of muscle as a bulk

***There are many ways you could define insulin resistance, but whatever the particular process you’re looking at, you’re comparing what would be the normal response in a normal healthy person compared to what might happen in a diabetic person or an obese individual***

**Peter’s takeaway on insulin resistance**

- It’s a vague term and it’s non-specific because the actions of insulin are so many
- It has an action in the liver
- It has an action in the muscles
- It has an action with response to glucose
- It has an action with response to amino acids
- It has an action with response to fat, both in the liberation of fat, lipolysis, and presumably in response to oxidation

## The historical significance of the development of the euglycemic clamp technique for measuring insulin resistance [11:45]

**Explain how the euglycemic clamp test is done**

*What would happen in a healthy individual?*

- When Ralph was a fellow, at that time there was not a good measure of insulin sensitivity
  - You do an oral glucose tolerance test and the insulin level would go up
  - Some people would look at how much insulin comes out compared to the rise in glucose, and that’s a measure of ꞵ-cell function
  - Then someone would just turn it around and look at how much the rise in glucose was per insulin, and that’s a measure of insulin resistance
- It was very clear to Ralph that this was insane
  - You can’t take 2 variables and then, just depending upon how you want to look at them, switch denominator and numerator
- Ralph wanted to develop something more specific
- Unfortunately, clinicians are not able to do [euglycemic clamps](https://en.wikipedia.org/wiki/Glucose_clamp_technique#:~:text=Hyperinsulinemic%2Deuglycemic%20clamp%20technique)
  - They are still looking at [oral glycemic tolerance tests](https://en.wikipedia.org/wiki/Glucose_tolerance_test): giving people oral glucose, and sampling glucose and insulin every 30 minutes, and trying to impute what we can
  - [we will come back to what you can learn from an OGTT at the end of the episode]
- Ralph [developed](https://journals.physiology.org/doi/abs/10.1152/ajpendo.1979.237.3.E214?rfr_dat=cr_pub++0pubmed&url_ver=Z39.88-2003&rfr_id=ori%3Arid%3Acrossref.org) a technique where you could take 100 people and infuse insulin (initially as a priming dose) and then just clamp the insulin level
  - [and infuse enough glucose to keep it at 80; discussed further shortly]

***Give a prime continuous insulin infusion: raise their insulin level by 100 micro units per ml, and do that for 2 hours***

![](https://peterattiamd.com/wp-content/uploads/2025/02/f1-ralphdefronzo.png)

**Figure 1. The euglycemic insulin clamp technique and examples of data obtained**. Image credit: [*Obesity* 2022](https://pmc.ncbi.nlm.nih.gov/articles/PMC9542105)

- Now you know that the insulin stimulus, whether you’re lean, whether you’re obese, or whether you’re diabetic, whatever particular process that you want to look at
  - Maybe you wanted to look at how insulin shut down a part of glucose production
  - Ralph’s group was the first to ever use radioisotopes to trace this, and show that ***in normal people insulin shut down glucose production by the liver very quickly***
  - But obese people and diabetics were very, very resistant to the insulin

**With this technique, everyone now has the same insulin level, [and you can ask the question] how effectively does that insulin stimulate muscle glucose uptake?**

- These were the very first unequivocal demonstration that people with type 2 diabetes were insulin resistant
- Before this there was a lot of controversy
- [Dr. Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) (who is the father of insulin resistance) was one of the very first people to insinuate that diabetics were insulin resistant
  - Ralph likes to think he’s the son of Dr. Reaven
- With the insulin clamp DeFronzo showed this very definitively (when he was at Yale)
  - Using labeled glycerol and free fatty acids and he could show that the ability of insulin to shut down **release of lipid from the fat cell** was markedly impaired [in people with insulin resistance]

**⇒** So 3 of the major organs are affected by insulin resistance [muscle, liver, and fat]

## How insulin affects different tissues: liver, muscle, and fat cells [15:00]

**Peter’s summary of the action of insulin in an insulin-sensitive person**

- 1 – Right out of the gate insulin is going to shut down hepatic glucose output
  - Which makes sense if you think through the pathway
  - Our liver is constantly putting glucose into circulation
  - Because the muscles can’t put glucose into circulation so something has to feed the brain
  - If insulin is high, it suggests glucose is already sufficiently high, so let’s not create more glucose toxicity
- 2 – The second thing it’s going to do is it’s going to take that excess glucose and put it in the place where we have the largest capacity to store it: in the muscle
  - Point two is we increase muscle uptake of glucose
- 3 – It’s going to shut down lipolysis
  - It’s going to shut down the release of triglycerides and/or free fatty acids from the adipose tissue

**Ralph looked at individual tissues while doing a euglycemic insulin clamp**

- When Ralph did these studies they would put a catheter in the hepatic vein and in the femoral artery in the femoral vein, so they could look at the individual tissues

**⇒** They showed when you infuse insulin, say 80 or 90% of the glucose is going to be taken up in muscle, only 10% is going to be taken up in the adipocyte and stored, and basically none was taken up by the liver

- They were the first to show conclusively that there’s no glucose uptake in the liver in response to insulin (under euglycemic conditions)

**Explain what a euglycemic condition means (more about how the euglycemic insulin clamp technique works)**

- Your fasting glucose when you wake up in the morning is 80 ‒ now your euglycemic
- When we do the studies we keep your fasting glucose of 80

***We don’t let the glucose change, all we’re going to do is raise the insulin; and that means you’re giving glucose [to keep it at 80]***

- If you didn’t give glucose then your blood sugar level would drop and then you’d release [cortisol](https://en.wikipedia.org/wiki/Cortisol), you’d release [epinephrine](https://en.wikipedia.org/wiki/Adrenaline)

*The test is very counterintuitive*

- The subject has been fasting, they have a catheter in each arm
  - Their blood sugar is 80-90 mg/dL
- You’re going to infuse both insulin and glucose
- You’re going to steadily increase insulin and take it to a steady-state of 100 mico unit per mL
  - After a meal, insulin may be 60
  - Obese people commonly get to 100; a healthy person would never see an insulin level that high
  - If you were not simultaneously running glucose into them you will kill them with an insulin level that high (they would become profoundly hypoglycemic)

**⇒** If the subject is very sensitive to insulin, then you would have to infuse a lot of glucose

- When Ralph was a young guy at Yale, there was a physician in New York ([Dr. Altshuler](https://en.wikipedia.org/wiki/David_Altshuler_(physician))) who was the first one to use tritiated glucose to trace metabolic pathways
- Ralph learned from him
- They were the first people to use tritiated glucose in humans (in the insulin clamp studies)

**⇒** They showed that the ability of insulin to shut down the release of glucose from the liver was markedly impaired [in type 2 diabetics]

**Peter’s recap of Ralph’s studies with tritiated glucose**

- The reason Ralph wanted to use tritiated glucose was not to quantify the total amount of glucose disposal (you could do that on mass balance), it was to determine the ultimate fate of glucose
- 1  – How much became hepatic glycogen, if any?  (in general, none)
- 2 – How much became muscle glycogen? (about 90%)
- Remember, some of the glucose is going to be oxidized once it gets into the muscle cell (about ⅓) and the other ⅔ would be stored as glycogen
- The person is sedentary during the test so the muscle is that metabolically active at rest
- You’re increasing energy expenditure under these conditions, turning on a number of cycles that generate ATP, but it’s nothing compared to jogging for 5 miles
  - Exercise is really the thing that increases energy expenditure
- 3 – And how much ultimately got converted through de novo lipogenesis into adipocyte or free fatty acid? (about 10% under the euglycemic condition)

Peter asks, “*In somebody my size who’s insulin sensitive, how many actual grams of glucose would you be able to get into the person within the hour whilst keeping insulin clamped?*”

- Ralph will answer first in terms of rates (the way we express it), and then he’ll translate that

***Under basal conditions, you wake up in the morning and your liver is producing and your tissues are taking up about 2 mg/kg body weight per minute (hepatic glucose output)***

- Ralph was the first to show this in humans
- **Mice are totally different**, and that’s why extrapolating from mice to humans can be a problem

> “*The liver never ceases to amaze me*. *It’s an unbelievable organ.*”‒ Peter Attia

**The liver is the only major organ for which we don’t have extracorporeal support**

- If you went into cardiogenic shock, and we felt we could reverse it in time, we could put an intra-aortic balloon pump in you
  - We could put an [IABP](https://en.wikipedia.org/wiki/Intra-aortic_balloon_pump) in you, we could put a left ventricular device in you to stem you over until we get you out of there
- If your kidneys are destroyed we can transiently dialyze you
- Even if your brain is experiencing swelling we can put enough steroids in you or decompress your skull to give you the time to recover and keep you alive otherwise
- Go through all the major organs
- If your spleen is dinged, take it out
- Even if you lost your small bowel we could at least transiently keep you alive with TPN or something like that
- None of this is true with the liver
- In the old days they actually used to use pig liver perfusion, or baboon (not anymore)

***The fact that the liver can titrate 2 mg/kg/min is remarkable***

- You take an individual who weighs 100 kilograms, you’re putting 200 mg/min of glucose into circulation
- Now you can multiply that by however minutes you want to look
  - That’s 1 gram every 5 minutes
  - 12 g of glucose every hour ‒ that’s a lot that the liver is putting out

**When Ralph does an insulin clamp**

- Depending on how much he raises the insulin
- Over the years he’s done a dose-response curve

*Your fat is exquisitely sensitive to insulin*

- If he raises the insulin just by 10 micro units/mL, the fat stops producing free fatty acids and glycerol
  - You inhibit lipolysis completely
- You need to get the insulin up to about 50 micro units/ml to really get the **liver** to shut down [glucose output]
- A healthy person has an insulin level of 5-10 fasting, so this procedure is going to raise them to maybe 15-20, and that in large part will shut down lipolysis
  - At the level of the liver, you really need to get up to 50 micro units/mL to shut off glucose production by the liver
- This is work Ralph did many, many years ago

**Control of blood glucose by the liver**

- When you wake up in the morning, your liver is producing glucose
- If you eat a meal, glucose is coming in from the gastrointestinal tract
- You can’t have glucose coming in from the liver at the same time otherwise you get very [hyperglycemic](https://en.wikipedia.org/wiki/Hyperglycemia)
- So when you eat a meal and that insulin comes out, it really needs to shut down a part of glucose production
- Now what’s replacing the liver is what’s coming from the meal
- But then after you absorbed all of the meal, the liver needs to turn back on [glucose production]

***So understanding how the liver is responding to insulin is really very important***

**If you want to look at what’s going on in the muscle**

- 100 micro units/mL is still within the physiologic range
- And the reason the test goes to this level is because if you really want to stimulate muscle glucose uptake completely, in a normal healthy person, you’d probably have to get the plasma insulin to about 200 micro units/mL

***At 200 micro units/mL, you have maximized muscle glucose uptake (in an insulin-sensitive person)***

- If you took an insulin-sensitive individual at 100 units of insulin to 200, you will drive about 25% more glucose uptake

## The different ways insulin resistance manifests in various tissues: Alzheimer’s disease, cardiovascular disease, and more [25:00]

**When we talk about insulin resistance, you need to know which tissue you’re talking about and which metabolic pathway**

- If you want to talk about enzymes, you need to talk at what specific enzyme because insulin resistance needs to be related to the tissue you’re talking about and the process within the tissue that you’re talking about
- So insulin resistance is a very important concept, but you all have to be a little bit more specific about what aspect you want to address
- You can have insulin resistance in the fat cell
- You can have insulin resistance in the liver
- You can have insulin resistance in the muscle
- You may have insulin resistance in the brain
  - There are many insulin receptors in the brain
  - [Jesse Roth](https://feinstein.northwell.edu/institutes-researchers/our-researchers/jesse-roth-md-facp) was the first person to describe insulin receptors in the brain (50-60 years ago)

**⇒** This is an area that is now starting to unfold ‒ some people say that Alzheimer’s disease is diabetes type 3 (Ralph is not sure that he agrees)

***Insulin resistance is a very important concept***

**The 2 big concepts in diabetes**

- Even though there’s an “[ominous octet](https://pmc.ncbi.nlm.nih.gov/articles/PMC2661582/#:~:text=diabetes%20(227).-,OMINOUS%20OCTET,-(FIG.%2013)” that Ralph developed that’s used everywhere in the world for the pathophysiology of type 2 diabetes
- 1 – Insulin resistance would be here
- 2 – The other one would be impaired [ꞵ-cell](https://en.wikipedia.org/wiki/Beta_cell) function
- So if you are insulin resistant, and your ꞵ-cells work well, they know how to read the insulin resistance, they’ll make enough insulin that you won’t become diabetic

***The hyperinsulinemia can damage you in other ways but you won’t become diabetic***

**What happens if you’re insulin resistant**

- Particularly if you have a genetic predisposition

***If your ꞵ-cell have to continuously pour out insulin they start to exhaust***

- And insulin resistance is a disaster for someone who has a genetic predisposition, it’s going to bring out the diabetes

Ralph explains, “*Insulin resistance, in my opinion, is intimately related to cardiovascular disease.*”

- That is why when you see a diabetic patient, 10-15% of them already have a clinically significant cardiovascular disease
  - And if you look carefully, virtually 100% of them do

Peter asks, “*Do you think that that is a result of the hyperinsulinemia or the untreated or poorly treated hyperglycemia?*”

- All of the above
- Ralph’s group was the first to show this
- Cardiologists are hemodynamically-oriented, they’re looking at vessels (stenosis)

**If you look at the insulin signaling pathway**

- Insulin has got a bind to its receptor
- Then there’s a signaling pathway (we won’t go into this) that results in glucose getting transported in the cell [via GLUT4, shown in the diagram below]

***Ralph’s group was the first to show in humans [with diabetes] that that*** [***pathway***](https://en.wikipedia.org/wiki/Insulin_signal_transduction_pathway) ***doesn’t work normally***

- Insulin will bind to the receptor, it will activate the receptor, but the next molecule ([IRS-1](https://en.wikipedia.org/wiki/Insulin_receptor_substrate_1), [PI3-kinase](https://en.wikipedia.org/wiki/Phosphoinositide_3-kinase)), all those molecules don’t get activated so glucose doesn’t get into the cell → that’s diabetes
  - [the figure below shows normal glucose signaling resulting in translocation of the glucose transporter (GLUT4) to the cell surface]

![](https://peterattiamd.com/wp-content/uploads/2025/02/f2-ralphdefronzo.png)

**Figure 2. Insulin signaling activates the MAPK pathway (on the left) and PI-3-kinase pathway (on the right)**. Image credit: [*Experimental and Molecular Medicine* 2023](https://www.nature.com/articles/s12276-023-01101-1)

- That same pathway activates [nitric oxide synthase [NOS]](https://en.wikipedia.org/wiki/Nitric_oxide_synthase) and that generates nitric oxide [see the next diagram below]
- Nitric oxide is the most potent vasodilator in the human body, it’s the most potent anti-atherogenic molecule in the human body
- This defect in the insulin signaling pathway, it’s in cardiac muscle and it’s in skeletal muscle (this is all human data, not animal data)

![](https://peterattiamd.com/wp-content/uploads/2025/02/f3-ralphdefronzo.png)

**Figure 3. Insulin signal transduction pathway and effects of PI-3-kinase activation**. Image credit: [*Biochemistry Research International* 2010](https://pmc.ncbi.nlm.nih.gov/articles/PMC2860140/)

***When you get a defect in that insulin signaling pathway, that’s going to cause diabetes and it’s going to promote cardiovascular disease. And that is why you can never separate cardiovascular disease from diabetes***

## The dangers of hyperinsulinemia, and the importance of keeping insulin levels within a physiological range [29:00]

**Ralph also believes that high levels of insulin are also atherogenic**

- He doesn’t want people to think that you shouldn’t be giving insulin to people who need it

**⇒** Our ꞵ-cell make 35 units of insulin per day

- If you were to take a type 1 patient, and they were lean, they would only need 35 or 40 units of insulin to get their glucose controlled, assuming you gave the doses at the right time
  - Ralph showed this long ago when he was at Yale
- But we have a lot of people who are taking 100 units of insulin, both type 1 [diabetics] and type 2s
  - That’s 3x the physiologic dose
  - That’s hyperinsulinemia

***There’s evidence to support that 100 units of insulin per day is atherogenic***

*Now we have a problem: can you have the glucose remain high?*

- We have very good drugs
- But if you were only doing this [treating diabetes] with insulin, you’d have a problem
- It’s an **awful trade-off**: you’d die very quickly from hyperglycemia if left untreated, but if we overdo it with insulin to maintain normal glycemia, we’re going to kill you slowly

***You have to treat, but you also know that when you’re giving these big doses of insulin, there may be some side effects***

> “*This is something, Ralph, I don’t think that has been necessarily appreciated by the medical community.*”‒ Peter Attia

- When Peter has talked to patients with type 2 diabetes, what they’ve been told is to use as much insulin as is necessary to maintain glucose levels in this range
  - It means they can eat whatever they want (pasta, bread, sugar) as long as they’re covering it with insulin
- Then you find out they’re taking 150 units of insulin a day in all of its forms (short-acting, long-acting, etc.)

**⇒** Peter didn’t realize we would consider the physiologic dose is 35 units per day that’s a great reference

**Peter summarizes this takeaway**, “If *there’s a person with type 2 diabetes listening to us today, and they’re taking 75 units of insulin, one of the takeaways should be: what do I need to do with my nutrition and other pharmacologic activities, plus exercise, plus everything that’s under my control to maybe get that down to 35 (where I would be at a physiologic level)?*”

**Things you can do to allow you to reduce insulin administration**

- Weight loss
- Exercise
- Add medications in combination with insulin [he’ll explain more later]
  - Insulin sensitizers
  - Some drugs to help you lose weight will also allow you to reduce your dose of insulin
- Ralph and [Dr. Del Prato](https://www.easd.org/media-centre/home.html#!users/3329) (the past president of the European Diabetes Association) [took](https://pubmed.ncbi.nlm.nih.gov/7851681/) normal, healthy, lean kids, 18, 25 years of age, and put them on the clinical research center for 3 days and gave them a very, very low dose of insulin infusion
  - They raised their fasting insulin from 8 (which is what a normal person would be) to 20 (which is really quite low)
  - And within 48 to 72 hours they were as insulin resistant as a type 2 diabetic patient

***Hyperinsulinemia induces insulin resistance***

**Why that is the case**

- Insulin down-regulates the insulin signaling transduction system so that insulin, when it binds to its receptor, and then it activates IRS-I, and PI 3-kinase, and Akt, that system is down regulated by hyperinsulinemia
- These are all published studies done in humans
- This also has been shown in rodent models as well
- So this is another reason why we don’t want people to be hyperinsulinemic
- Peter finds this mind-boggling (he would have never predicted this result)

*Summary of Ralph and Del Prato’s* [*study*](https://pubmed.ncbi.nlm.nih.gov/7851681/)

- They took normal, lean, healthy volunteers who had a fasting insulin of 8 and infused them with insulin and glucose
  - In a clinical research center where we can monitor and keep the glucose perfectly constant, we’re not letting the glucose change
  - They show up with an insulin of 8 and a glucose of 90
- You do a euglycemic clamp where you bring the insulin only up to 20 (1.5x)
  - Which is much less than it would be after you eat a meal
  - Now it’s sitting there at 20, and you’ve obviously had to infuse glucose to maintain euglycemia
- They maintained this for 48 to 72 hours, and now these people are as insulin resistant as type 2 diabetics

*Peter finds this counterintuitive*

- Because if our model is that insulin resistance is driven by lipotoxicity (which we’re going to come to)
  - Remember, insulin resistance in combination with ꞵ-cell fatigue is the hallmark factor contributing to type 2 diabetes
- These people didn’t have any of that
  - They didn’t have any intramyocellular lipids that [Jerry Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) talked about as a predisposing factor

Ralph explains, “*It’s the direct effect of insulin down regulating the insulin signaling system, and probably other distal metabolic within the cell as well*.”

**What would you predict would happen after you turn the clamps off?**

- Probably within 24 to 48 hours, they would return to normal, because we did this acutely
- Now, if we were able to do this for several months, then Ralph would anticipate that the insulin resistance would remain for a long period of time
- Remember, when we treat type 1 diabetics, we’re always giving the insulin into the periphery
- In contrast, when you or I ingest the meal, where does the insulin go? It goes into the portal vein
- So the liver is seeing a high level of insulin
- That’s good: it [tells the liver to] stop making glucose; and now, it removes half of the insulin
- So how much insulin gets into the periphery? Half of what you secreted
- Why? Because we don’t want the insulin in the periphery over insulinizing the periphery
- Because it would make the muscle tissue very insulin resistant

**Ralph explains what normally happens when the pancreas secretes insulin**

- The pancreas secretes insulin into the portal circulation, the liver sees the insulin and stops making glucose (good), but it also takes up half of the insulin
- So less insulin get [into the periphery]
  - It’s enough to nourish the muscle
  - Enough to shut down the fat from producing free fatty acids
  - But not enough to hyper insulinize the system

**One effect of administering insulin to a diabetic**

- In a certain way, if you’re a diabetic and you are insulin resistant, or an obese person and you are insulin resistant, and you’re hyper secreting insulin, it’s kind of working against you
- It’s a reverberating system that’s making the insulin resistance aggravated

*One of the big things that we’ve forgotten is*

- Earlier, Ralph said there are 2 problems in diabetes: (1) is you don’t make enough insulin, (2) is you’re insulin resistant
- You need to attack both problems
- Ralph recently [published](https://pubmed.ncbi.nlm.nih.gov/39098317/) a perspective in *The Lancet Diabetes Endocrinology* to help people remember that we still have a **genetic cause for insulin resistance**

**⇒** You go back to 1950, the incidence of diabetes was 2% (very low)

***But these people were all lean and they’re insulin resistant ‒ so there’s a genetic cause of the insulin resistance***

Peter asks, “*Do you think that the greater genetic effect is on the insulin resistance side, or on the ꞵ-cell fatigue side?*”

- Both

## The challenges of identifying the genetic basis of insulin resistance and type 2 diabetes [37:00]

**What we know about the genetics of insulin resistance**

- That’s easy ‒ nothing (Ralph jokes)
- 20 years ago, Ralph was involved in one of the biggest genetic studies called the [VAGES study](https://pubmed.ncbi.nlm.nih.gov/16644701/) (Veterans Administration Genetic Epidemiologic Study)
  - They were one of the first people to do [GWAS](https://pubmed.ncbi.nlm.nih.gov/18931038/) on this
  - They thought they would define all the genes responsible
  - They were not very successful

Peter asked, “*Even if you took the subset of people with type 2 diabetes who were lean, and you compared them to people who were lean and non-diabetic, versus obese and diabetic, a GWAS was not able to identify a signal in those 3 cohorts?*”

- Ralph identified several in non-coding regions, the [TCF7LT2 gene](https://en.wikipedia.org/wiki/TCF7L2)
- But that had already been [described](https://pubmed.ncbi.nlm.nih.gov/17259383/) by [Dr. Michael Stern](https://www.linkedin.com/in/mike-stern-93a2bbb/) in San Antonio many years before
- So Ralph repeated what Michael showed, and other people have shown that
- Again, if you ask how many genes have we truly established that are really important in terms of causing type 2 diabetes? Very, very few
  - Ralph knows the genetics people out there probably hate this, and they’ll say that we can put together a genetic score
  - But when they talk about a genetic score, it’s not that they causably associated a gene with diabetes ‒ it’s an association
- Then you start to think about rare diseases
  - Maybe in 1 family you have this particular genetic mutation
  - In another family, you have a different genetic mutation
  - In a 3rd family, a different genetic mutation
- Then when you do a [GWAS](https://en.wikipedia.org/wiki/Genome-wide_association_study), you have this mixture of individual genes

**What about the phenotype?**

- That’s the answer
- Peter has taken care of a couple of patients with type 2 diabetes who are very lean
  - Including 1 patient whose body fat by DEXA was about 8% (insanely lean)
- The first thing that comes to Peter’s mind is a [lipodystrophy](https://en.wikipedia.org/wiki/Lipodystrophy) ‒  is this an individual whose adipose tissue is the problem?
  - In other words, they’re not able to assimilate enough excess nutrient (i.e. glucose) into the fat cell, and so they’re undergoing the toxicity associated with an insufficient reservoir

Peter asks, “*Is that what could be the causal? Not that I can tell you what’s causing the lipodystrophy.*”

- The answer is yes, it’s very clear that lipodystrophy can cause diabetes, but that is a very, very rare and unusual cause
  - That’s not what would explain 1% of diabetics
- [Gerald Shulman](https://medicine.yale.edu/profile/gerald-shulman/) has done some beautiful work in this area: it’s unequivocal that lipodystrophic people, because their fat cells can’t take up the fat, it ends up in your myocardium, cause heart disease
  - Fat ends up in the ꞵ-cell
  - Fat ends up in muscle
  - [Gerald Shulman was a guest on the podcast in [episode #140](https://peterattiamd.com/geraldshulman/)]
- But that’s a very, very small percentage [of diabetics]

**About 7 or 8 genes have been associated with the basic genetic etiology of insulin resistance**

- The [PARγ gene](https://en.wikipedia.org/wiki/Peroxisome_proliferator-activated_receptor_gamma) has been associated, and it’s pretty clear that’s causal
- There’s a recent [study](https://www.nature.com/articles/s41586-024-07019-6#:~:text=We%20define%20eight%20non%2Doverlapping%20clusters%20of%20T2D%20signals%20that%20are%20characterized%20by%20distinct%20profiles%20of%20cardiometabolic%20trait%20associations) in *Nature* where they identified 8 genes (associations)

Peter asks, “*Did* [*Mitch Lazar*](https://www.med.upenn.edu/apps/faculty/index.php/g275/p7505) *do some of this work?*”

- He’s worked in this area, but it’s a long list of folks
- The other thing people said, “*Well, maybe there are 20 genes involved each giving a small component, and that’s why it’s so difficult.*”

***All of these hypotheses have been difficult to prove, and the simple fact is, we don’t understand the genetic basis***

- In part, because diabetes, in Ralph’s opinion, is a very poor phenotype

**⇒** Diabetes is a very heterogeneous disease

- So when we talk about diabetes, if that’s your phenotype, it’s not surprising that it’s going to be difficult to define genes that are related to diabetes

**Muscle insulin resistance**

- Ralph doesn’t want to take credit for this
- [Dr. Luke Norton](https://directory.uthscsa.edu/academics/profile/nortonl) in his division, working with [Steve Parker](https://medschool.umich.edu/profile/3640/stephen-c-parker) at Michigan
- Ralph is involved because he’s doing the insulin clamp studies

***They’re looking at the phenotype of muscle insulin resistance***

- This is a very, very specific phenotype
- This is not diabetes
  - Which is the ominous octet (8 problems discussed later)

**Experimental approach**

- Ralph is going to do a muscle biopsy followed by an insulin clamp, and then he is going to do another muscle biopsy at the end of the insulin clamp
- During the insulin clamp, he knows exactly how sensitive or resistant you are to insulin
  - He’s got the most definitive phenotype in the world

*What does he see?*

- An enormous amount of chromatin opens up ‒ this is the epigenetic component
- Genes in the chromatin area that you are never ever going to see in the basal state
- Hypothesis: that [epigenetic change] is why it’s been so difficult with all of these GWAS studies to identify genes that are associated with diabetes

***We’re starting to see some associations which we think now are causal (in diabetic people and non-diabetic people), and we can relate to the insulin resistance with the clamp***

*Peter wants to make sure everyone is following this*

- You’re saying, look, one of the challenges of having a disease that isn’t perfectly, perfectly, clearly defined, where every single member of the class that has the disease looks exactly the same ‒ the word for the challenge in type 2 diabetes is **heterogeneous**
- In contrast, let’s take an example where the disease is very *homogenous* [in terms of its genetic cause]: [sickle cell anemia](https://en.wikipedia.org/wiki/Sickle_cell_disease)
  - [Peter misspoke here and said heterogenous; in understanding the heterogenous genetic causes of type 2 diabetes, it is helpful to compare it to a homogenous disease where the genetic cause is singular]
- Everybody who has sickle cell anemia, there’s a single mutation that defines the disease
  - From a pathophysiology standpoint, it’s identical in everyone with the disease
  - One gene mutated, produces one change in one base pair that changes one amino acid, that changes the property of the hemoglobin molecule, and everybody looks the same
- But Ralph is saying that with type 2 diabetes, we have:
  - Some people that are thin, some people that are fat
  - Some people that have lots of insulin resistance in the muscle, some people that don’t seem to have much but it’s all in the liver

***If that’s the case, why would you ever expect to find a simple genetic answer? By definition it’s going to be a mess***

- Absolutely
- If you don’t have a very definitive phenotype, it’s going to be difficult

**⇒** The implication is, any physician who approaches a patient with type 2 diabetes as a single entity is going to be providing suboptimal care

**Ralph has been fighting for 20 years to convince people, you need to start with combination therapy from the beginning**

- Finally, in 2022, the American Diabetes Association has made a [comment](https://diabetesjournals.org/care/article/45/11/2753/147671/Management-of-Hyperglycemia-in-Type-2-Diabetes#:~:text=weekly%20(185).-,Combination%20Therapy,-The%20underlying%20pathophysiology), and for the first time, suggests that you should consider starting with combination therapy (discussed more later)

**Peter’s takeaway ‒** ***you have to take a precision medicine approach to type 2 diabetes, which begins by trying to identify which phenotype your patient is***

- Before you couldn’t
- This is the brain child of [Luke Norton](https://directory.uthscsa.edu/academics/profile/nortonl) and [Steve Parker](https://medschool.umich.edu/profile/3640/stephen-c-parker)
- Ralph is involved ‒ he understands the disease, he’s doing the insulin clamps, he’s giving them the phenotype
- They’re doing the single cell [analysis]

**⇒** It turns out there are 10, 12 different types of cells within the muscle

- When we think about muscle, we think there’s a [myocyte](https://en.wikipedia.org/wiki/Muscle_cell) problem

***But it’s probably cells also talking to each other, making it even more complex ‒ we’re at an early stage in the development (but we’re enthusiastic)***

- We have not discovered these genes

**⇒** We think epigenetics are important, and this is part of the epigenetic phenomenon

## The “ominous octet”—a more comprehensive model of type 2 diabetes than the traditional triumvirate [45:45]

**The ominous octet of type 2 diabetes**

- In 2008, the title of the [Banting Lecture](https://pmc.ncbi.nlm.nih.gov/articles/PMC2661582/) was “From the Triumvirate to the Ominous Octet.”

*What was the triumvirate?*

- Ralph got the Young Investigator Award, the Lilly Award from the ADA in 1987
- The **triumvirate** was very simple:
  - 1 – The ꞵ-cell, it fails
  - 2 – Insulin resistance in the muscle ‒ when you ingested a meal, the muscle didn’t take up the glucose because you’re insulin resistant
  - 3 – Insulin resistance in the liver ‒ when you ate a meal, insulin didn’t shut down [glucose release from] the liver
- From the triumvirate to the ominous octet, we needed to add 5 more players

*Who were the new 5 players?*

![](https://peterattiamd.com/wp-content/uploads/2025/02/f4-ralphdefronzo.png)

**Figure 4. The ominous octet ‒ players involved in the pathogenesis of type 2 diabetes**. Image credit: [*Diabetes* 2009](https://pmc.ncbi.nlm.nih.gov/articles/PMC2661582/)

**#4 – The fat cell**

- The fat cell is your friend, initially
- You overeat, you take in excess calories, you store them in the fat cell, that can’t hurt you there
- But if you keep expanding those fat cells, the fat cells become very, very resistant to the antilipolytic effects of insulin
- Now you start to pour fat out into the bloodstream (also work of [Gerald Shulman](https://medicine.yale.edu/profile/gerald-shulman/))

Peter finds this one very counterintuitive and asks , “*Not that we should mire ourselves in teleologic things. Do you have a sense of why?*”

- The insulin signaling system and multiple early steps become severely impaired
- When you get insulin resistance in the glucose metabolic pathway, there are changes that alter the cell metabolism
  - You become very resistant to insulin’s antilipolytic effect
- If you look at people who are obese, or people who have type 2 diabetes, their plasma [FFA](https://en.wikipedia.org/wiki/Fatty_acid#Free_fatty_acids) levels are very, very high
  - Those FFA levels, this is lipotoxicity
- We’ve got a long history of studying this
  - High FFA levels impair insulin secretion
  - High FFA levels cause insulin resistance in the muscle
  - High FFA levels cause insulin resistance in the liver
  - High FFA levels impair the insulin signaling transduction system
  - One of Ralph’s previous fellows, who’s now back with him at UT ([Dr. Belfort](https://lsom.uthscsa.edu/physiology/team-member/renata-belfort-de-aguiar-md/)) was the first author on this [paper](https://pubmed.ncbi.nlm.nih.gov/15919784/) showing that just physiologic rises in the plasma FFA literally obliterate the insulin signal transduction system, which is the first step in glucose metabolism

***Peter always thought the reason we saw high free fatty acids in people with type 2 diabetes was not because the fat cells were undergoing more lipolysis, but because the fat cells were themselves becoming resistant to insulin and not able to take up fat***

- So same net effect, but he was drawing the arrow of causality in the other direction

Ralph explains, “*The arrow is more on the other side. The fat is pouring out fat. And you can* [*show*](https://pubmed.ncbi.nlm.nih.gov/14764748/) *that the lipolytic enzymes are all resistant to insulin… These elevated FFA levels are a disaster.*”

- The fat cell initially, he’s your friend; then he becomes a bad guy

**#5 – The gastrointestinal tract**

- When you eat a meal, you release 2 incretin hormones: [GLP-1 (glucagon-like peptide-1)](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1) and [GIP (glucose-dependent insulinotropic polypeptide)](https://en.wikipedia.org/wiki/Gastric_inhibitory_polypeptide)

**⇒** Those 2 incretin hormones account for about 70% of the insulin that’s released in response to the meal

- Is the problem is that you don’t release enough GLP-1 and GIP?
- Or is it that your ꞵ-cell is refractory to the GLP-1 and GIP? (it’s this one)

**Peter’s summary**

- This is important to understand because it’s important to understand why drugs like [semaglutide](https://en.wikipedia.org/wiki/Semaglutide) and [tirzepatide](https://en.wikipedia.org/wiki/Tirzepatide) were developed
  - Semaglutide is already the 3rd generation
- When you eat a meal, GIP and GLP-1 are increased, and they tell the ꞵ-cell to make more insulin
- [In type 2 diabetes] the ꞵ-cell is deaf, it’s not listening, it’s resistant to GLP-1 and GIP

> “*70% of the insulin that’s going to come out is dependent on that GLP-1 and GIP. So you can imagine that that’s a huge problem at the level of the* ꞵ-*cell in terms of the defect in insulin secretion*.”‒ Ralph DeFronzo

Peter asks, “*Tell me, why is it mechanistically that the ꞵ-cell becomes deaf to GLP-1 and GIP?*”

- We don’t know the answer to that
- It’s another horrible piece of this puzzle, where everything starts to work against the patient
- This is an area of intense investigation

***The drugs that are out there (the GLP-1 receptor agonists) gives you a pharmacologic dose of GLP-1, and it’s overcoming the resistance at the level of the ꞵ-cell***

- There’s another component to this that we’ll get to, and that’s **glucotoxicity**
- These were [studies](https://pubmed.ncbi.nlm.nih.gov/24423311/) that were done by [Jens Holst](https://www.harringtondiscovery.org/scholars/jens-j-holst) and the group in Denmark
  - They took people and they infused [GIP](https://en.wikipedia.org/wiki/Gastric_inhibitory_polypeptide)
  - Type 2 diabetics don’t respond to GIP
  - Then they intensively treated them with insulin and lowered their glucose
  - Then when they come back with the GIP, you reach a normal amount of insulin
  - This is a glucotoxic effect

***In terms of mechanism, we know that at least for the GIP, the glucotoxicity is impairing the ability of the ꞵ-cell to respond to the GIP***

- That doesn’t correct the GLP-1 problem ‒ there’s true resistance still
- This incretin axis, the gut is a very important endocrine organ

**#6 – The α-cells**

- [Dr. Roger Unger](https://en.wikipedia.org/wiki/Roger_Unger) in Dallas (the father of hyperglucagonemia) was one of the very first people to show that diabetics had very high [glucagon](https://en.wikipedia.org/wiki/Glucagon) levels and glucagon drives

*What glucagon does*

- Glucagon drives hepatic glucose production
- If your glucose gets too low, your [α-cells](https://en.wikipedia.org/wiki/Alpha_cell) will release glucagon
- The α-cells can sense the glucose
- And so if you’re hypoglycemic, this is an important defense mechanism: you release glucagon, that stimulates your liver, and the glucose production goes up
  - It returns your glucose to normal
- But a diabetic already has a high glucose, and we don’t want high glucagon levels

***Paradoxically, there’s very high glucagon levels in the diabetic, and those high glucagon levels are a very important contributor to the hepatic insulin resistance, because they’re driving the liver to make glucose***

Peter asks, “*Is it driving the liver to make glucose out of, for example, glycerol, amino acids, or other things?*”

- *Acutely*: gluconeogenic pathway in [glycogenolysis](https://en.wikipedia.org/wiki/Glycogenolysis)
  - So if I acutely give you glucagon, the first thing that happens, you break down glycogen
- But very quickly, you get rid of all the glycogen that’s in the liver, and so *chronically* now you’re running on [gluconeogenesis](https://en.wikipedia.org/wiki/Gluconeogenesis)

**⇒** Glucagon stimulates both pathways: the breakdown of glycogen (glycogenolysis) and gluconeogenesis

***It drives hepatic glucose output as well as gluconeogenesis, and that’s an important reason why you have fasting hyperglycemia***

- So when you wake up in the morning and your blood sugar is 110 mg/dL ‒ that’s the liver
- Part of that is because your liver’s intrinsically resistant to insulin
- Part of it is because the liver is now responding to the glucagon, and producing an excess amount of glucose
  - Both through gluconeogenesis and through glycogenolysis
  - Although, the major contributor is the gluconeogenic pathway
- Now, that gluconeogenic pathway is also turned on because fat is coming from the fat cell
  - Remember, Ralph mentioned that the FFA is high
  - Glycerol is coming from the fat cell
- [Shulman’s](https://medicine.yale.edu/profile/gerald-shulman/) work [showed](https://pmc.ncbi.nlm.nih.gov/articles/PMC4498261/) that glycerol coming from the fat cell is an important driver of gluconeogenesis
- And then hepatic fatty acyl CoA levels are up, because you have all this fat pouring in, and that’s activating the enzymes, pyruvate carboxylase that are driving the gluconeogenic pathway

***The metabolic pathways are very well worked out: glucagon, alpha cell → bad guy***

Peter asks, “*Is the α-cell overproducing glucagon in this state?*”

- Yes, absolutely
- [Roger Unger](https://en.wikipedia.org/wiki/Roger_Unger) in Dallas showed this

**Why is the α-cell overproducing glucagon? (something that doesn’t make sense in the context of  what’s happening)**

- In a certain way, this is also insulin resistance
- Because hyperinsulinemia shuts down glucagon
- And we have very high fasting insulin levels in the diabetic
- What’s the sensing mechanism?
- Peter finds this counterintuitive because usually when things go wrong, they get attenuated
  - It makes sense that the ꞵ-cell eventually fatigues, because that’s an attenuation of doing something that it’s getting tired of doing
  - The α-cell ramping up is a little less intuitive

Ralph adds, “*You’re going to see it gets even worse when we talk about the kidney, which is #7 on the list.*”

## The kidneys’ unexpected role in worsening diabetes, and how SGLT2 inhibitors were developed to treat diabetes [55:45]

**#7 ‒ Increased glucose reabsorption by the kidney**

- Ralph is also a board certified in nephrology
- In the old days, he trained as a micropuncturist
  - He used to sit with a microscope and would draw his little pipettes out the night before and put the little micropipette in the tubules and collect tubular fluid
  - This was when he was a renal fellow at University of Pennsylvania
- He was interested in glucose and phosphate transport, and he published a series of elegant papers in the *JCI*, looking at what regulated glucose in phosphate transport
- He knew that there was a molecule called [phlorizin](https://en.wikipedia.org/wiki/Phlorizin) that blocked glucose transport in the kidney
- He took this molecule called phlorizin, and it blocks glucose transporters

*There are 2 [glucose] transporters in the kidney: SGLT2 and SGLT1*

- [SGLT2](https://en.wikipedia.org/wiki/Sodium/glucose_cotransporter_2) takes back 90% of the glucose
- If it does its job, [SGLT1](https://en.wikipedia.org/wiki/Sodium/glucose_cotransporter_1) takes back the other 10%
- In a normal person, even though we filter 180 grams of glucose per day, no glucose appears in the urine
- Ralph showed that phlorizin (it blocked both SGLT2 and SGLT1) blocked glucose transport, and it also blocked phosphate transport

**⇒** He showed that glucose and phosphate transport were coupled

- When Ralph was doing these studies, even though he was a nephrology fellow, he had previously done an endocrine fellowship at the NIH in Baltimore City hospitals
- He had an interest in diabetes and he said, “*This would be a great way to treat diabetes.*”

Ralph shares, “*In the old days, we did things for science, and I published a series of four papers in the JCI. And I never even thought of, to be honest with you, of patenting this*.”

- His significant other said, “*Ralph, you’re one of the smartest guys I ever met… and you’re probably the stupidest guy I ever met*.”
  - He asked why
  - She said, “*You could have patented this drug*.”
  - He actually worked with Bristol Myers Squibb and then AstraZeneca, and that eventually led to phlorizin coming to the market (the first SGLT2 inhibitor, brand name [Farxiga](https://en.wikipedia.org/wiki/Dapagliflozin))
- The next SGLT2 inhibitor to come to market was [empagliflozin](https://en.wikipedia.org/wiki/Empagliflozin), then [canagliflozin](https://en.wikipedia.org/wiki/Canagliflozin), [ertugliflozin](https://en.wikipedia.org/wiki/Ertugliflozin) (there are a bunch of them)
- They’re all very good; they basically do the same thing

***Ralph showed that the SGLT2 transporter was markedly upregulated in the kidney [in diabetics]***

**Peter’s summary**

- This is so counterintuitive
- The kidney is this massive filtration (another remarkable organ)
- Everything that’s floating through our plasma, our kidneys take 25% of our cardiac output (huge)
  - This organ weighs 2% of our weight
- Why? Because we have to take everything that is in our circulation and dump it out, and then the kidney has to selectively bring back in what’s normal
- Peter remembers learning about this in medical school
  - This is a brilliant trick of evolution
  - Evolution was never going to be able to predict every toxic thing we might encounter
  - Therefore, teaching the kidney how to spot toxic things and get rid of them would’ve been a failed mission
  - Rather, it was better to teach the kidney what was absolutely necessary, and to discard all other things (pretty simple way)
  - It’s like taking everything out of your drawer and dumping it out, and only bringing back the socks and underwear that you need
- So glucose, potassium, sodium, you name it, chloride, phosphate, all of these things get dumped along with everything else
- And then it knows, “*I need this much glucose, I need this much sodium. I need this much potassium*.”

**⇒** SGLT2 does the lion’s share of this: it takes back 90% of the glucose

- Peter’s point was that if SGLT2 had a brain it would realize, “*Oh, you have too much glucose… Turn it off. How about we just stop reabsorbing all this glucose?”*
- But what Ralph just explained is the opposite: in a diabetic guy with very high glucose, it ramps up SGLT2

***As a doctor, Ralph wants the kidney to dump the glucose out in the urine, but instead the kidney is doing the opposite (holding on to the glucose)***

**Even as a renal fellow, it became clear to Ralph that this is a simple way to treat diabetes**

- It’s so simple that no one thought about it
- If only he had patented it, he would probably never have to write another NIH grant

**Ralph went on to show the first definitive proof of the glucose toxicity hypothesis**

- All of these studies were initially done in animals and published in the JCI
- [Luciano Rossetti](https://www.flagshippioneering.com/people/luciano-rossetti-2) and [Gerrry Shuman](https://medicine.yale.edu/profile/gerald-shulman/) were fellows on these papers

***They showed in different types of diabetic animal models that they were reabsorbing excessive amounts of glucose, and if you treated them with phlorizin, they simply pee the glucose out in the urine and all of a sudden, their ꞵ-cell started functioning normally and muscle insulin sensitivity improved***

- That’s wonderful if you’re a rat
- Initial studies in humans were done with [dapagliflozin](https://en.wikipedia.org/wiki/Dapagliflozin)

**⇒** In humans, just 14 days of treatment with dapagliflozin markedly lowered the fasting and postprandial glucose, insulin sensitivity improved by 35%, and there was a major improvement in ꞵ-cell function

> “*The beauty of this, SGLT2 inhibitors are only in the kidney. They’re not in your muscle.*”‒ Ralph DeFronzo

- The only thing SGLT2 inhibitors do is make you put glucose out in the urine
- The only change in the plasma was the glucose came down
- And now insulin sensitivity improved in muscle, and ꞵ-cell function improved

***These were the first studies to show an improvement and the reality of glucose toxicity***

*When they started to work on developing this with BMS and AstraZeneca*

- The company wanted to get some nephrologists to see about this story
- They worried that putting glucose in the urine would be a disaster
  - Arguing it will glycosylate proteins and then cause kidney damage
- They actually held up development of SGLT2 inhibitors
- The way Ralph finally convinced them to go ahead is that there’s a disease called [familial renal glucosuria](https://en.wikipedia.org/wiki/Renal_glycosuria)
  - From day one of their life, they’re peeing out tremendous amounts of glucose
  - They have perfectly normal kidney function

Peter asks, “*How many grams of glucose can be differentially or extra secreted basically in the presence of an SGLT2 inhibitor today?*”

- It depends on what level your GFR is, but it could be anywhere from 40-60 grams up to 120 g of glucose
  - The higher would be in somebody with higher glucose

*These drugs are very, very good*

- In developing these drugs, based on the [Barry Brenner hypothesis](https://www.renalfellow.org/2008/10/19/brenner-hypothesis/), Ralph predicted these drugs would save your kidneys, and that’s all turned out to be correct

***These drugs are great for the kidney, what Ralph never envisioned is that they were also going to save your heart***

*The drug* [*Sotagliflozin*](https://en.wikipedia.org/wiki/Sotagliflozin) *inhibits both SGLT2 and SGLT1*

- Peter wants to come back to discuss the broader geroprotective nature of the SGLT2s as documented by the [ITP](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp) in mice and then also in the human studies for cardioprotection

## How insulin resistance in the brain and neurocircuitry dysfunction contribute to overeating and metabolic disease [1:04:15]

Finishing the ominous octet

**#8 ‒ The brain**

- The brain plays a role in a somewhat indirect way
- Every day you have your breakfast, your lunch, and at some time during the meal you’ll stop eating
  - Ralph actually eats only once a day, but at some point you eat a meal
- Do you ever think, why does that happen?
- It’s because there are certain hormones that are released or inhibited that tell you, “*Okay, you’re satiated, stop eating*.”
- One of the very important ones is [GLP-1](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1)
  - That same thing that’s increasing insulin secretion

***[In type 2 diabetes] your brain has become very resistant to GLP-1***

- When you eat a meal, [amylin](https://en.wikipedia.org/wiki/Amylin) comes out in a one-to-one ratio with insulin

**⇒** Your brain has become resistant to amylin. Your brain is resistant to [leptin](https://en.wikipedia.org/wiki/Leptin). There are a lot of these anorectic molecules that your brain has become resistant to

- These molecules are another area of interest of Ralph’s, they work in the hedonic areas in the brain, and they tell you to stop eating
  - In the [putamen](https://en.wikipedia.org/wiki/Putamen#Anatomy), the [prefrontal cortex](https://en.wikipedia.org/wiki/Prefrontal_cortex)
- What’s going on in the brain is still a big unknown (unfortunately)

***The neurocircuitry is clearly distorted***

*Changes observed in the brain*

- One of  the big things [Dr. Peter Fox](https://directory.uthscsa.edu/academics/profile/fox) at UT and Ralph are interested in is if you look at the gray matter in these areas of the brain important in regulating appetite ‒ there’s shrinkage of the gray matter
- If you do an insulin clamp: in a normal person, the brain is insensitive to insulin, but in obese people, there is marked increase in glucose uptake (incredible finding)

Peter asks, “*You’re saying that these are the few areas in my brain and your brain that are actually default insulin insensitive?*”

- Yes
- They don’t take up glucose during an insulin clamp (in response to insulin)
- From the Cahill studies: as long as your glucose is about 50, your brain is happy
- This is in the evolution of the human, because in the old days, you may not eat for days, so your glucose would drop
  - If your normal fasting glucose was 80 and it dropped to 40, you’re okay because your brain is saturated at 40
- If you got below 40, you’re in trouble
- So you have a big buffer here
- But now if you are infused with insulin and your glucose is 80, your brain doesn’t take up more glucose ‒ it’s “insulin insensitive” in a certain way

Peter adds, “*If you take people with mild cognitive impairment, there’ve been some experiments that actually suggest in these people insulin infusion can transiently improve glucose uptake. But presumably that’s because they’re insufficiently getting glucose in the disease state*.”

- This has been postulated
- It also suggests that there’s brain insulin resistance
  - Which Ralph thinks is an interesting concept and may play some role in this neurocognitive dysfunction, Alzheimer’s (whole different story that’s in evolution)

## Lipotoxicity: how overeating fuels insulin resistance and mitochondrial dysfunction [1:07:30]

**Back to the ominous octet: if you overeat, what happens?**

- You gain weight

**⇒** When you gain weight, you become insulin resistant, severely insulin resistant

***That’s lipotoxicity***

- Ralph has done studies in both directions
- Put in an IV and **infuse and emulsion of free fatty acids**, and within 2-4 hours severe insulin resistance is induced in muscle and liver, and there is markedly impaired ꞵ-cell function
- There’s a drug available in Europe (not in the US) that Ralph has an IND to use, called [acipimox](https://en.wikipedia.org/wiki/Acipimox) ‒ it inhibits lipolysis
- It’s like an SGLT2 inhibitor ‒ the only thing to do is block glucose reabsorption in the kidney

**Acipimox, all it does is do block lipolysis ‒ It lowers your FFA level**

*Does it result in any meaningful clinical increase in adiposity? Or is it so subtle that you don’t notice it?*

- Over 12 days, no change in adiposity, huge improvement in insulin sensitivity and muscle

Peter asks, “*Why is it not approved in the US?*”

- Ralph doesn’t know if the company that developed it in Europe ever tried to get it approved in the US

**⇒** It’s modestly effective in lowering triglycerides

- We have [fenofibrate](https://en.wikipedia.org/wiki/Fenofibrate) which are much more effective, and that may be the reason
- Peter adds that triglycerides and FFA (free fatty acids) are not the same thing
- No, but if you lower the FFA (that’s the precursor for triglyceride synthesis), it has an effect to lower the triglycerides

***The key thing is if you lower the FFA, you markedly improve insulin sensitivity in the muscle ‒ Ralph’s group did this for 12 days in both obese people and in diabetics***

- If using MRI, you can measure muscle fat ‒ it goes down dramatically and correlates with the improvement in insulin sensitivity
- They also measured ATP generation because there’s clearly **mitochondrial dysfunction** if you’re a diabetic, that’s unequivocal
- The controversy is is the mitochondrial dysfunction causing the insulin resistance or is the insulin resistance causing the mitochondrial dysfunction?
- In Ralph’s [study](https://pubmed.ncbi.nlm.nih.gov/24353180/), when they lowered the FFA and lowered muscle lipid content, they saw about a 50% improvement mitochondrial ATP generation

***This says that part of the mitochondrial dysfunction is secondary to the lipotoxicity and insulin resistance***

- This remains a controversial topic
- Clearly there’s mitochondrial dysfunction, and if you can improve it, that’s going to improve insulin sensitivity

## Pioglitazone: an underappreciated and misunderstood treatment for insulin resistance [1:10:15]

**Is there anything that improves mitochondrial function more than aerobic exercise training?**

- [Pioglitazone](https://en.wikipedia.org/wiki/Pioglitazone), the drug that Ralph can’t get people to use, which is a phenomenal drug
- By activating [PPARγ](https://en.wikipedia.org/wiki/Peroxisome_proliferator-activated_receptor_gamma), it does a lot of good things
- One of the important things that it does, it has a huge effect to improve mitochondrial dysfunction
- And it has direct effects: it works directly through PPARγ to do this, and it also binds directly to the [mitochondrial pyruvate carrier](https://en.wikipedia.org/wiki/Mitochondrial_pyruvate_carrier), and that influences flux through the mitochondrial chain

Peter asks, “*Why don’t people use this drug today?*”

- Huge misconceptions

> “*As part of my triple therapy regimen, I use a GLP-1 receptor agonist, I use pioglitazone, and I use an SGLT2 inhibitor. There’s a fourth good drug, and that’s metformin.*”‒ Ralph DeFronzo

**Metformin**

- You might ask why is [metformin](https://en.wikipedia.org/wiki/Metformin) #4 on Ralph’s list of good drugs since he single-handedly brought metformin to the United States in 1995
  - No other endocrinologist was involved in this
- Why was metformin a revolutionary drug in 1995 when we had insulin and sulfonylureas?
  - Now we had a drug that really could work
  - It’s still a very good drug, and of course it’s very cheap (it’s $5 a month in the state of Texas)
  - But we have much better drugs

**Pioglitazone causes weight gain**

- The problem (and paradox) is, the more weight gain, the greater the drop in A1C
- The more weight gain, the greater the improvement in insulin sensitivity

Peter asks, “*Is it fat gain specifically?*”

- No (he’ll come back to this)
- It is fat weight gain and Ralph believes it’s also muscle weight gain

*The more weight gain*

- The greater the improvement in ꞵ-cell function
- The greater the drop in blood pressure
- The greater the drop in triglycerides
- The greater the rise in HDL cholesterol
- Sounds like a terrible drug

- We know a few overeat and gain weight, that’s a disaster
- But with pioglitazone, the more weight you gain, everything gets better

***What pioglitazone does is it shifts weight around in the bod***y

Ralph adds, “*In my opinion, it’s the best drug for treating NASH. No drug is going to beat pioglitazone*.”

**⇒** The brand name for pioglitazone is Actos

*The paradox: why do you gain weight?*

- Pioglitazone redistributes fat in the body: it gets it out of the muscle and puts it in subcutaneous tissue
  - Gets it out of the liver and puts it in subcutaneous tissue
  - It gets it out of your ꞵ-cell and puts it in subcutaneous tissue
- That’s not going to make you gain weight
- The richest density of PARγ receptors is in the hypothalamus
- When you activate these PARγ receptors in the hypothalamus you eat
  - It makes you hungry
  - That’s got nothing to do with redistributing the fat in the body, except they parallel each other in association

***When people see weight gain, they think it’s really bad, but it’s really recycling and moving the fat around***

*The other negative thing about pioglitazone is it causes fluid retention*

- People have associated fluid retention with [heart failure](https://en.wikipedia.org/wiki/Heart_failure)
- People do not understand why you get fluid retention

**⇒** The only only drug that is a true insulin sensitizer is pioglitazone

- [Metformin](https://en.wikipedia.org/wiki/Metformin) is not a true insulin sensitizer
  - That’s a total misconception
- That insulin signaling defect that Ralph mentioned earlier, pioglitazone corrects that defect (it’s incredible)

**Changes in insulin signaling that contribute to insulin resistance**

- Insulin binds to the [insulin receptor](https://en.wikipedia.org/wiki/Insulin_receptor) on the cell surface ‒ that’s a [receptor tyrosine kinase](https://en.wikipedia.org/wiki/Receptor_tyrosine_kinase)
- There are 3 tyrosine molecules, and they have to be phosphorylated [depicted in the diagram below as green circles labeled pY)
- These were studies done, [Ron Kahn](https://nutrition.hms.harvard.edu/people/c-ronald-kahn), and other people in Boston

**⇒** You mutate 2 of those tyrosines, you become a little insulin resistant, you mutate 2 of them, you become moderately insulin resistant, you mutate 3 of them, you’re severely insulin resistant

- Insulin binds to the receptor
  - That happens normally in diabetics; there’s no problem there
- Then [IRS-1 (insulin receptor substrate 1)](https://en.wikipedia.org/wiki/Insulin_receptor_substrate_1) inside the cell comes up and it interacts with the insulin receptor, and it phosphorylates the same 3 tyrosine molecules [on the insulin receptor, INSR in the figure below]
- Then you activate [PI3 kinase](https://en.wikipedia.org/wiki/Phosphoinositide_3-kinase), [Akt](https://en.wikipedia.org/wiki/Protein_kinase_B)
- We could add some more molecules in here, but this is the insulin signaling pathway [summarized in the figure below]

***The pathway that the earliest defect that you can show in diabetics is in that pathway***

![](https://peterattiamd.com/wp-content/uploads/2025/02/f5-ralphdefronzo.png)

**Figure 5. Signaling from the insulin receptor (INSR) with tyrosine residues represented as green circles**. Image credit: [*Physiological Reviews* 2018](https://pmc.ncbi.nlm.nih.gov/articles/PMC6170977/)

- Peter recalls that [Shulman](https://medicine.yale.edu/profile/gerald-shulman/) argued [in [episode #140](https://peterattiamd.com/geraldshulman/)] that the accumulation of intramyocellular lipid was creating the defect in that pathway
- Ralph explains that Shulman elegantly showed there are certain lipids, and it’s a specific [DGAT](https://en.wikipedia.org/wiki/Diglyceride_acyltransferase)
  - There are several types of DGAT molecules, which has confused things
  - There’s a specific DGAT that activates atypical PKC molecules which then serine phosphorylates the insulin receptor [not tyrosine phosphorylation as discussed earlier], and it *inactivates* them
  - This happens both in peripheral muscle and liver and plays a very important role in insulin resistance
  - This is part of the lipotoxicity
  - [discussed in this [review](https://pmc.ncbi.nlm.nih.gov/articles/PMC6170977/)]
- Ralph doesn’t believe this is the genetic etiology
- You get fat and you start putting fat everywhere ‒ this is critically important
- That was when Shulman gave his [Banting Lecture](https://youtu.be/mrpQeRY7jXU?si=W4xSXYJxqM95Dj-A)

***Shulman has done phenomenal work in this area, and intramyocellular lipids are a very, very important mechanism of insulin resistance***

- Given that this is both a very important and a very common pathway toward insulin resistance and [PPARγ](https://en.wikipedia.org/wiki/Peroxisome_proliferator-activated_receptor_gamma) is part of the pathway

**How PPARγ fits into the insulin receptor signal transduction pathway**

- It’s part of the IRS1, PI3K, GLUT4 [see the asterisks in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/02/f6-ralphdefronzo.png)

**Figure 6. Insulin receptor (IR) signaling through the IRS-1/PI3K/AKT pathway activates PPARγ and causes translocation of GLUT4 to the cell surface.** Image credit: [*Expert Reviews in Molecular Medicine* 2012](https://pubmed.ncbi.nlm.nih.gov/22233681/)

- GLUT4 brings glucose into the cell
  - If people don’t want to get mired down in this, insulin hits the receptor that kicks off a cascade that ultimately results in a little tube (GLUT4 is like a straw) that goes into the cell surface that allows glucose to freely flow into its gradient
- That same pathway also activates nitric oxide synthase to generate nitric oxide [not shown in the figure above, but shown in a previous figure]

***This is why we see cardiovascular disease is up in patients with insulin resistance, even if glucose is controlled***

**Back to** [**Actos [pioglitazone]**](https://en.wikipedia.org/wiki/Pioglitazone)

- It activates that signaling pathway and you generate nitric oxide
- Now you vasodilate, that’s why the blood pressure drops
- Ralph is a nephrologist and he understands this very clearly: when you vasodilate, anytime you under perfuse the kidney
  - You hold on to salt and water
  - You become edematous
- People associate fluid retention and edema with heart failure

Ralph did the [definitive studies](https://pubmed.ncbi.nlm.nih.gov/28847910/) published in *Diabetes Care* in 2017

- They took people who had diabetes and we treated them with pioglitazone, and then using NMR (very, very sophisticated techniques), they showed that pioglitazone markedly improved myocardial blood flow

**⇒** Myocardial insulin sensitivity with PET and fluorodeoxyglucose improved by 75%

- Ralph showed before that the heart is severely insulin resistant
- This came pretty close to normalizing insulin sensitivity in the heart
- Since they were doing the insulin clamp with tritiated glucose, they would track the improvement in skeletal muscle insulin sensitivity, and it was the same (74% improvement)

**⇒** Ejection fraction went up by 5-10%

- Every measure of [diastolic function](https://en.wikipedia.org/wiki/Diastolic_function) got better
  - E over A, E over E prime, LV Peak Filling Pressures, etc.

**Peter’s takeaway on pioglitazone (Actos) ‒** ***it’s a victim of not so nuanced thinking about the drug***

**Don’t we have better drugs?**

***No drug corrects insulin resistance***

- Metformin is not an insulin sensitizer
- Ralph brought metformin to the US in 1995; he did all the mechanism of action studies

**⇒** Using the insulin clamp, he showed that Metformin absolutely does not improve insulin sensitivity

## Metformin: debunking the misconception that it is an insulin sensitizer and explaining its true mechanism of action [1:19:15]

- Everybody wants to know if metformin is geroprotective

**Remind people,** [**metformin**](https://en.wikipedia.org/wiki/Metformin#Pharmacology) **inhibits** [**complex I**](https://en.wikipedia.org/wiki/Electron_transport_chain#Complex_I) **of the electron transport chain**

- This is still controversial
- In high doses, it does for sure
- In the doses you give metformin, it’s somewhat equivocal

**Is the belief that metformin’s efficacy in diabetes is through reducing hepatic glucose output?**

- That is 100% true

*What’s the mechanism by which it reduces hepatic glucose output?*

- Inhibiting the mitochondrial chain and inhibiting gluconeogenesis
  - For sure it inhibits gluconeogenesis
- Metformin gets in the cells through the [organic cation transporter](https://en.wikipedia.org/wiki/Organic_cation_transport_protein)

**⇒** The organic cation transporter doesn’t exist in muscle, it can’t possibly be an insulin sensitizer in muscle (you’re asking the drug to do something that’s impossible)

Peter asks, “*Does it [metformin] get into muscle mitochondria?*”

- No, it doesn’t get into muscle at all

**Why does lactate go up when people are taking metformin?**

- That’s at the level of the liver ‒ it’s interfering with aerobic metabolism

> “*This is very important. I have erroneously always believed, so I’m really happy to be corrected.*”‒ Peter Attia

- Peter has always believed that the reason we saw an increase in fasting lactate, even in healthy people if they took metformin, was because of the inhibition of the [ECT](https://en.wikipedia.org/wiki/Electron_transport_chain) in skeletal muscle
- That’s not possible because metformin can’t get into skeletal muscle

***It’s all in the liver***

Ralph explains, “*Not a single molecule in the world of metformin has ever gotten into any skeletal muscle anywhere.*”

- Metformin enters cells using the organic cation transporter, and it does not exist in skeletal muscle or cardiac muscle ‒ so metformin cannot get into those tissues
- It’s a huge misconception
- A rare complication that can occur when you have very low [GFR](https://en.wikipedia.org/wiki/Glomerular_filtration_rate) and/or very, very high doses: lactic acidosis
  - Metformin is excreted by the kidney
  - That’s not a reason why you shouldn’t be using the metformin

**⇒** Ralph is not saying that metformin is not a good drug, it is; he doesn’t think it’s as good as the other 3 drugs discussed [a GLP-1 receptor agonist, pioglitazone, and an SGLT2 inhibitor]

***At high doses, metformin increases lactate level due to its effect on the liver***

- 2 g of metformin a day is not a high dose
- The old drug [phenformin](https://en.wikipedia.org/wiki/Phenformin) (a biguanide) caused all the problem [of lactic acidosis], but it had a powerful effect

**What metformin has going for it**

- It’s basically free
- It does a pretty good job at reducing hepatic glucose output
- It has no myotoxicity, or any toxicity
- You can usually overcome GI side effects with a slow ramp up

**The GI side effects is the reason people thought it was an insulin sensitizer**

- 15-20% of people have significant GI side effects and they lose weight
  - On average, there’s about a 3 kg weight loss with metformin
- And when you lose weight, you can improve insulin sensitivity

**Ralph did all the work on developing metformin that went to the FDA**

- In the [1995 *NEJM* article](https://www.nejm.org/doi/full/10.1056/NEJM199508313330902), there were only 2 names on the paper: Ralph and a PhD oncology lady from Lipha Pharmaceuticals
- He did many of the insulin clamps and could never show metformin improved insulin sensitivity using the gold standard with radioisotopes

 Peter asks, “*Do you get the sense that most people are still thinking what I think? (that metformin gets into the muscle, metformin is an insulin sensitizer)*”

- Yes, absolutely
- You can label metformin, give it, and see where it goes using [PET](https://en.wikipedia.org/wiki/Positron_emission_tomography) studies
- You see it all accumulating in the **liver** in the first 3, 4, 5, 10 minutes [Ralph emailed the figure below]
  - Then it starts accumulating in the **kidneys** (because that’s where it’s excreted)

And another 5-10 minutes, you see it in the **bladder**

![](https://peterattiamd.com/wp-content/uploads/2025/02/f7-ralphdefronzo.png)

**Figure 7. PET studies of labeled metformin show its uptake by the liver and kidneys**. Image credit: 2015 ADA meeting [abstract #128-LB](https://app.core-apps.com/tristar_ada15/abstract/1678f29f2a56ce35baedcc25f394afd9)

**⇒** You never see metformin in the muscle, and it’s definitely not an insulin sensitizer

**Is there a downside to using metformin in combination with the other 3 drugs?**

- No

## Treating diabetes with triple therapy vs. the ADA approach: a better path for diabetes management [1:24:00]

**The classic study that should change the entire approach to treating diabetes is called the** [**EDICT study**](https://pubmed.ncbi.nlm.nih.gov/25425451/)

- It used triple therapy right from the beginning [metformin, pioglitazone, and exenatide]

***The point of Ralph’s*** [***Banting lecture***](https://pmc.ncbi.nlm.nih.gov/articles/PMC2661582/)***: if you have 8 problems, why do you think 1 drug is going to correct them? You need to use drugs in combination***

- Ralph is sure that more problems will be found
- They started with the best drugs at the time: [metformin](https://en.wikipedia.org/wiki/Metformin), [exenatide](https://en.wikipedia.org/wiki/Exenatide) (a first generation GLP-1, pre-liraglutide, what was available at the time), and [pioglitazone](https://en.wikipedia.org/wiki/Pioglitazone)
  - This is what Ralph believed is appropriate therapy
- There were 315 people in this study, follow-up for 6 years
- They had insulin clamps, hyperglycemic clamps, muscle biopsy
- They compare it to the ADA approach: start at metformin, and when you fail, the next drug that’s used is [sulfonylureas](https://en.wikipedia.org/wiki/Sulfonylurea), and the 3rd drug that’s added is insulin
  - You titrate basal insulin up to 60 units (60 is the cap, which is 2x the physiologic dose)
  - You have to split the dose of insulin, adding rapid insulin (reasonable)

**⇒** The goal of therapy was a [HbA1c](https://en.wikipedia.org/wiki/Glycated_hemoglobin) of 6.5

*Results of the EDICT study, 6 years later*

- With the ADA approach, 29% of people have failed (their A1C is >6.5)
  - Zero improvement with insulin sensitivity [shown in the figure below]
- With triple therapy, 70% of people have an A1C <6.5 (huge improvement)
  - You have almost a normal β-cell

![](https://peterattiamd.com/wp-content/uploads/2025/02/f8-ralphdefronzo.png)

**Figure 8. Insulin sensitivity (A) and ꞵ-cell function (B) after 3 years of conventional therapy or triple therapy**. Image credit: [*Diabetes Care* 2021](https://pmc.ncbi.nlm.nih.gov/articles/PMC7818318/)

- The 3 year data is [published](https://pubmed.ncbi.nlm.nih.gov/33273042/) and they’re writing up the 6 year data

Peter asks, “*Why the disconnect between what you’re seeing in the EDIC study and what the ADA is promoting?*”

- You have to ask the ADA

*Is this simply a question of the pace at which medicine moves is so glacial?*

- That’s part of it
- Plus remember, if to do 315 people, follow them for 16 years, and do all of the stuff Ralph did, it’s unequivocal

Peter asks, “*Why has there not been political pressure because the cost of insulin is enormous? Your approach is going to be less expensive.*”

***The state finally said in 2022 that the ADA approach is not based on pathophysiology***

- Ralph views himself as a scientist as well as a clinician
- As a good clinician, he’s taken care of hundreds of thousands of patients and had 850 publications
- He does clinical research and when he does an insulin clamp study (hyperglycemic clamp) and sees improvement in insulin sensitivity
  - He sees the β-cell function in 315 people
  - He doesn’t need 5,000 people; no one can do this study in 5,000 people
  - The tools he’s using are so powerful
- With triple therapy he normalizes insulin sensitivity, gives you a normal β-cell, and your A1C is <6.5 (it’s half of the 315 people in the study) ‒  why do you not think that is the best therapy?
- With ADA therapy using metformin, [SU](https://en.wikipedia.org/wiki/Sulfonylurea), insulin: 71% of people have failed, there’s zero improvement in insulin sensitivity, and zero improvement in β-cell function ‒  why do you think that’s such a good regimen?

**Other studies have replicated the findings of the EDICT study**

- [Dr. Robert Turner’s](https://en.wikipedia.org/wiki/Robert_Turner_(endocrinologist)) United Kingdom Prospective Diabetes [Study](https://pubmed.ncbi.nlm.nih.gov/9850487/) showed this in 1990
- [Steven Kahn](https://uwmdi.org/faculty/steven-kahn-mb-chb/) showed this in the [ADOPT study](https://pubmed.ncbi.nlm.nih.gov/17145742/) in year 2005
- The [GRADE study](https://pubmed.ncbi.nlm.nih.gov/36129996/), sponsored by the NIH in 2020

> “*I call this the 15-year revelation.*”‒ Ralph DeFronzo

- We saw what didn’t work 1990
- Steven Kahn did it again (it didn’t work in 2005), and now 2020, the NIH did it

***They all show the same thing***

**The ADA approach**

- This was a sequential approach ‒ you had to have failed on metformin to get into the study
- Then they used a single agent
- They want to know what’s the next best drug to add to metformin
- Add a sulfonylurea and A1C went down in year on, up straight

**Tell folks how a sulfonylurea works**

- [Sulfonylureas](https://en.wikipedia.org/wiki/Sulfonylurea) are old-time drugs, they bind to the [sulfonylurea receptor](https://en.wikipedia.org/wiki/Sulfonylurea_receptor) on the [ꞵ-cell](https://en.wikipedia.org/wiki/Beta_cell)  and they kick out insulin
- They’re very good drugs in the first year, and then they stop working

Peter explains, “*Basically they kick the can down the road without addressing the pathophysiology.*”

**The other drug is a DPP-IV inhibitor**

- A [DPP-IV inhibitor](https://en.wikipedia.org/wiki/Dipeptidyl_peptidase-4_inhibitor) increases your [GLP-1](https://en.wikipedia.org/wiki/Glucagon-like_peptide-1) and your [GIP](https://en.wikipedia.org/wiki/Gastric_inhibitory_polypeptide) level endogenously
- It makes your gastrointestinal cells (the K and the L cells that secrete the GLP-1 and GIP) make more GLP-1 and GIP
- But it doesn’t increase the GLP-1 and GIP enough to really give you a knockout punch
  - An injection of [Mounjaro](https://en.wikipedia.org/wiki/Tirzepatide) or [semaglutide](https://en.wikipedia.org/wiki/Semaglutide), that’s the knockout punch
- So the first year, A1C comes down, A1C goes up

**Liraglutide**

- The 3rd drug ([liraglutide](https://en.wikipedia.org/wiki/Liraglutide)) was very surprising: Ralph thought it was going to work the best but it failed
  - It worked in the first year, then failed
- This is one of the earlier GLP-1 receptor agonists

**Insulin was the 4th drug**

- The docs just didn’t titrate the insulin enough, so A1C went down and then they failed

***So 5 years later, all 4 of those regimens added to metformin failed***

**Advantages of triple therapy**

**⇒** The old version of triple therapy: exenatide (an old-time GLP-1), pioglitazone (which people don’t appreciate, the only true insulin-sensitizer), and metformin

- 6 years later, 70% of the people have an A1C <7

*The cost is very low*

- Metformin and exenatide are basically free now
- Pioglitazone is $5 a month

***We have 3 free drugs that work better***

## GLP-1 agonists, the Qatar study, and rethinking diabetes treatment [1:31:30]

- Today’s triple therapy is way more efficacious
- 2 of those drugs are very expensive: [SGLT2 inhibitors](https://en.wikipedia.org/wiki/SGLT2_inhibitor) and the modern [GLP-1 receptor agonists](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist#Approved) ($1000 a month)

**Do you need to be on those drugs if the old version of triple therapy is effective?**

- The old version is incredibly effective
- The problem is you can’t get people to use pioglitazone
  - Patients gain weight

Peter asks, “*How much weight do they gain typically?*”

- It depends on the dose
- Ralph doesn’t go to the 45 mg dose

***At the end of the year, they may gain 1-2.5 kg [2.2-5.5 lbs.] on the 15 and 30 mg dose, but their A1C is controlled***

*If you give pioglitazone plus a modern-day GLP-1, don’t you offset the weight gain?*

- [Yes] you lose all the weight you lose with the GLP-1 receptor agonist

***Ralphs treatment is to use triple therapy with a modern-day GLP-1 receptor agonist***

- That eliminates the weight gain and edema
- Their A1C is down in the normal range

**Pioglitazone and the PROactive Study**

- The [PROactive Study](https://pubmed.ncbi.nlm.nih.gov/16214598/) was done a long time ago
- You have to show cardiovascular safety (5,238 people) ‒ to get into the study, you had to have an [MI](https://en.wikipedia.org/wiki/Myocardial_infarction), stroke, or something bad
- Half the people are on pioglitazone, half the people are on placebo
- The endpoint is MACE (Major Adverse Cardiovascular Events), which is non-fatal MI, non-fatal stroke, cardiovascular mortality
- You have to show the benefit to get approval by the FDA

***The MACE endpoint was positive***

- When Ralph talks to cardiologists, he likes to say, “*What was the one thing in the pioglitazone that predicted that you would not die?*”
  - They don’t know
  - It was weight gain
  - He jokingly says, “*Look, you can either be a little fat and alive or you could be lean and dead. Which one are you going to pick?*”
  - He goes for being a little bit chubby
  - [Ralph’s [review](https://pubmed.ncbi.nlm.nih.gov/30706731/) of benefits of pioglitazone]
- But now you don’t even need to make that trade-off with a modern GLP-1 receptor agonist

**If Ralph had to pick 2 drugs to treat diabetes**

**⇒** He would pick pioglitazone with one of the newer drugs [GLP-1 receptor agonists]

- If you have any kind of renal cardiac disease, he’s going to pick an SGLT2 inhibitor
- If you’re a newly diagnosed diabetic and you don’t have any cardiac symptoms, why do you think that the SGLT2 inhibitor is not doing all of the beneficial things in that newly diagnosed diabetic that it’s doing in the people who get into these studies who already have cardiac disease?
  - If you have a cardiac problem and you go on the SGLT2 inhibitor, you’re less likely to have MI, stroke, etc.
- Although this study will never be done
  - You’d have to take 20,000 newly diagnosed people and have 10,000 go on SGLT2 and 10,000 on placebo then follow them for 20 years to see who’s going to have a heart attack
  - No one’s going to do that study because they’re going to get on all kinds of drugs
- Peter relates this to PCSK9 inhibitors reducing MACE in people with secondary prevention
  - Of course everybody’s using these for primary prevention now

***We already know that SGLT2 works for secondary prevention, and that may never get approval for primary prevention, but it probably justifies its use***

**Peter’s summary**

- If you only get 1 drug, and you’re price-agnostic, use a GLP-1 agonist
- If you get to add a 2nd drug, add [PO](https://en.wikipedia.org/wiki/Pioglitazone)
- If you get a 3rd drug, add SLGT2 (especially if you care about your heart)

Peter adds, “*What’s amazing is metformin didn’t even make the top three in your list.*”

- But it’s #4

Peter asks, “*Given that metformin is free, should we just be adding it the second we put on the GLP-1?*”

- Yeah
- We have to be cognizant of the fact that these **newer GLP-1s** are so potent but they’re $1000 a month
  - [Semaglutide](https://en.wikipedia.org/wiki/Semaglutide) is gen 3
  - [Tirzepatide](https://en.wikipedia.org/wiki/Tirzepatide) is gen 4
  - [Retatrutide](https://en.wikipedia.org/wiki/Retatrutide) is coming out, assuming the Phase 3 goes according to plan
  - [CagriSema](https://en.wikipedia.org/wiki/Cagrilintide/semaglutide) is the new Novo one

**Retatrutide, GLP-1, GIP, and glucagon**

*Can you explain that in the context of the* [*octet*](https://pmc.ncbi.nlm.nih.gov/articles/PMC2661582/) *where glucagon is going up?*

- It’s not proven
- Earlier Ralph explained that insulin knocks down glucagon

- That glucagon effect to drive hepatic glucose production will be totally blunted by the insulin secretory effect
- When you eat a meal, 70% of the insulin that’s secreted is coming from the GLP-1 and the GIP

*The GLP-1 receptor agonists*

- These are the best drugs in the world for losing weight
- These are the best drugs in the world for saving your ꞵ-cell
- People have stopped talking about this effect on the ꞵ-cell
  - That when you eat a meal, 70% of the insulin that’s secreted is coming from the GLP-1 and the GIP

***The big problem in type 2 diabetes is*** ***ꞵ-cell*** ***failure, insulin resistance and these GLP-1s, they’re saving your*** ***ꞵ-cell******, and we’ve become so enamored with the weight loss that we’ve forgotten about that***

**⇒** When you take a GLP-1 and they work on the ꞵ-cell, they’ll kick out insulin, any negative thing that glucagon’s doing will be totally negated

**Now you may see some good things that glucagon is doing that we couldn’t appreciate before**

- Some people have suggested that it increases thermogenesis energy expenditure, but Ralph doesn’t believe that
  - There are animal data, but he doesn’t believe this is true in humans
- He believes that it’s exerting an anorectic effect in the central nervous system
  - That is yet to be established
  - There are studies going on now at the [Pennington Institute](https://www.pbrc.edu/) and maybe also at [TRI](https://www.adventhealth.com/institute/adventhealth-research-institute/translational-research-metabolism-and-diabetes) in Orlando where they have these chambers where you can get an answer about energy expenditure
- Peter would be surprised if they see a clinically meaningful increase in involuntary energy expenditure
- Ralph agrees and thinks it’s all appetite

**Reduction in cardiovascular events in GLP-1 studies**

- It’s almost uniformly 20% (old drugs and new drugs), even though the weight loss is much greater with the newer drugs
- Ralph suspects there’s a cap in cardiovascular benefits
  - Once you’ve lost a certain amount of weight and you’ve gotten a certain amount of lipotoxicity and all the good things that these drugs are doing, you don’t go beyond that, even though you’re losing more weight
- If you look at the A1C, yes, the Mounjaro does drop the A1C a little bit more than semaglutide, but they’re both pretty powerful
- Retatrutide does a little bit more (as does CagriSema), but they don’t do a lot more
- Ralph thinks there’s going to be somewhat of a cap on how much you drop the A1C
  - You get a 2.5% drop
  - Do you need to drop it to 3?

**If a person shows up with a HbA1c of 9.5%**

- They haven’t come to medical attention soon enough

*Are you happy if they only go from 9.5 to 7% (a 2.5% drop)? You wouldn’t try to get them down to 6%?*

***Ralph would and he’s done the study: this is called the*** [***Qatar Study***](https://pubmed.ncbi.nlm.nih.gov/28096223/)

- What drives Ralph is the science, and if you understand pathophysiology and there’s an abnormality and you correct the abnormality, things get better

**The Qatar study**

- Ralph gives credit to [Dr. Muhammad Abdul-Ghani](https://directory.uthscsa.edu/academics/profile/abdulghani), his co-worker in all of these studies
  - Muhammad’s on the faculty at UT in the diabetes division
- There are 220 or so people, you had to be poorly controlled on metformin and sulfonylurea
- The average A1C was about 10
- About ⅓ of the people were symptomatic: they had [polyuria](https://en.wikipedia.org/wiki/Polyuria), [polydipsia](https://en.wikipedia.org/wiki/Polydipsia), they were losing weight
- The current concept for those people is to put them on a mixed/split insulin regimen
  - You would get rid of the glucotoxicity
  - You would get rid of the lipotoxicity
  - You get their A1C down to 6.5
- Then you could put them back on the oral medications or whatever, and now they respond because you got rid of the glucotoxicity and lipotoxicity
- Ralph thought that may or may not be true
- In this study, half of these people starting with an A1C >10 will go on a mixed/split insulin regimen with a [glargine](https://en.wikipedia.org/wiki/Insulin_glargine) and a [rapid acting insulin](https://en.wikipedia.org/wiki/Insulin_analog#Fast_acting)
- The other half are going to go on that old-dude [exenatide](https://en.wikipedia.org/wiki/Exenatide) and [pioglitazone](https://en.wikipedia.org/wiki/Pioglitazone) (the one that people don’t like to use)

*Results*

- 3 years later, the A1C in the group with the mixed/split insulin regimen is 7.1%, and we are very good at insulin
  - They couldn’t go lower because they got into trouble with hypoglycemia
- The A1C in the group treated with exenatide and pioglitazone is 6.1

**⇒** [Subgroup analysis](https://pubmed.ncbi.nlm.nih.gov/35581905/) of the people who are symptomatic: the starting A1C was 12.2, and 3 years later it is 6.1 (on exenatide and pioglitazone)

- They had failed on metformin and SU to get into the study

***What Ralph is saying is you have drugs that correct the insulin resistance (that’s pioglitazone)…***

> “*This is almost impossible for me to imagine.*”‒ Peter Attia

Peter emphasizes, “*I hope every single family medicine internist, everyone who ever takes care of somebody with diabetes is listening.*”

**Peter’s takeaway ‒** ***you’re basically saying we can take these 2 old, cheap drugs and take someone from the most brittle type 2 diabetes (you’re knocking on death’s door) and in a couple of years, you’re normal***

- These are the people who are going to go blind, have their toes amputated, are never going to have an erection again
- These are the people who are going to die of cardiovascular disease or kidney disease or Alzheimer’s disease quickly

Ralph adds, “*What makes these studies so solid is we have very sophisticated pathophysiologic measurements. No one can do what we do*.”

**Concerns about weight gain**

- The only pushback is those patients are going to gain a couple of kg, but if you’re willing to spend a bit more money and switch from gen-1 to gen-3 or gen-4 GLP-1 receptor agonists and GIP, then all of a sudden, you ameliorate that and you get all the benefits
- Peter wonders if you add metformin, you almost cancel out the weight gain
  - Because you might get a little bit of a GI improvement and you get the 2-3 kg of weight loss there

***These drugs are so powerful when you put them with pioglitazone, I mean, you lose almost the same amount of weight***

- This study was done in Qatar, the country
- Ralph gives credit to [Dr. Muhammad Abdul-Ghani](https://directory.uthscsa.edu/academics/profile/abdulghani) who has been is coworker in all of these studies (he’s on the faculty at UT in the diabetes division)

**Are the Gulf states paying attention to this?**

- They are disproportionately ravaged by type 2 diabetes
- They are and there is a big program going on there as well as in Kuwait
- Ralph has a formal cooperative agreement with the Kuwaiti people
  - At the [Dasman Diabetes Institute](https://www.dasmaninstitute.org/about-us/), Ralph’s group has trained them how to do these insulin clamps and sophisticated metabolic studies, and they take care of the patients

## Using a hyperglycemic clamp to look for genes that cause diabetes [1:45:15]

**What triggers insulin secretion**

- 1 – You eat a meal, your glucose goes up ‒ that secretes insulin
- 2 – There’s amino acids in the meal ‒ that secretes insulin
- 3 – GLP-1 goes up ‒ that secretes insulin

***So when you eat a meal, there are already 3 stimuli, and now you’re looking for a gene or a set of genes that might be associated with ꞵ-cell failure when you have 3 stimuli***

- That’s going to be pretty confusing

**Ralph’s approach: a 3-step hyperglycemic clamp**

- Give a little rise in glucose, another rise in glucose, and another rise in glucose
- See how much [C-peptide](https://en.wikipedia.org/wiki/C-peptide) comes up
- The slope of that curve is the ꞵ-cell sensitivity to glucose

Peter asks, “*And then the M-value is where it hits the axis?*”

- Then you can get glucose
- Ralph is going to focus on the ꞵ-cell because the hyperglycemic clamp is just for ꞵ-cell function
- After that, he’s going to give a GLP-1 infusion and see how much insulin comes up
- After that, he’s going to give a balanced amino acid infusion and see how much insulin comes up

**⇒** You can sequentially measure 3 different stimuli, and now what we see is different genetic loci

- Some loci are associated with the defect in the glucose, some are associated with the defect in amino acid

***The more you can refine the phenotype, the more likely you are to identify defects that are there at the level of the ꞵ-cell***

## The superiority of measuring C-peptide instead of insulin to assess beta-cell function [1:46:45]

**Back to the Qatar study**

- There were about 220 people in that study ‒ a lot when you’re doing insulin clamp studies (these measurements are not easy to do)
- The 1.5 year data was published in [2017](https://pubmed.ncbi.nlm.nih.gov/28096223/) and the 3-year data in [2020](https://pubmed.ncbi.nlm.nih.gov/32729222/)

*If you take an individual with type 2 diabetes (or insulin resistance), presumably collecting urinary C-peptide for 24 hours is the best surrogate for total insulin secretion?*

- No, it’s an index

Peter asks, “*If you could quantify total area under the curve of insulin for a person, and then you gave them a GLP-1 agonist, is total insulin going up or down?*”

- It depends because you have competing factors going on here
- The drug is going to kick out insulin and C-peptide is going to go up, and now the glucose is going to come down
  - And then you need less insulin
- So depending upon the relationship, when you look in absolute terms, the C-peptide and insulin levels actually may be lower
- But now, when you express how much C-peptide comes up for the rise in glucose, a huge increase

**⇒** You always have to have something that you compare it to, and that’s the increment in glucose

- Anytime you look at how much insulin comes out (or C-peptide, which is another confusing factor which he’ll mention in a second), you always have to relate it to the glucose area
  - When you do that, huge increase in ꞵ-cell function

**⇒** The other thing you have to be very careful about is you need to be measuring C-peptide, not insulin

**Tell people what C-peptide is and what its relationship is to insulin**

- When you ingest a meal, there’s a precursor that contains both C-peptide and proinsulin
- And so you split off C-peptide and you split off insulin, and they both come out in a one-to-one molar ratio
- The problem is half of the insulin that comes out is taken up by the liver, so you never see it in the circulating bloodstream
- The C-peptide is *not* taken up by the liver, so everything that comes out you see in the circulation

***So when we want to know how much insulin was secreted, we actually don’t measure the insulin; we measure the C-peptide, and that’s the true measure***

**The other confounding feature here**

- Ralph has shown this and it’s been reproduced by many other people
- When you become insulin-resistant and diabetic, your ꞵ-cells don’t secrete enough insulin (that’s one of the big defects)
- How do you compensate? You don’t destroy the insulin that’s secreted

***The degradation of insulin becomes markedly impaired***

**⇒** You can have a high insulin level, either because you secrete too much insulin or because you don’t destroy the insulin

- So measuring the insulin level is not a good measure of ꞵ-cell function

***If you want to know about insulin secretion, measure the C-peptide and express it per rise in glucose***

- It gets a little bit more clouded because your ꞵ-cell also can recognize how insulin-resistant you are
  - It knows if you’re this insulin-resistant, then it needs to secrete more insulin
  - If you’re very insulin-sensitive (you’re a lean person with normal glucose tolerance), you don’t want to secrete much insulin because you get hypoglycemic
- How does your ꞵ-cell recognize that? Well, that’s somewhat controversial

***In either case, measuring ꞵ-cell function, it’s not just simply measuring insulin (that’s probably bad); measuring C-peptide is better***

- Measuring C-peptide per rise in glucose is better
- And then for somewhere or another, if you can express this all per insulin resistance, this is called the [disposition index](https://en.wikipedia.org/wiki/Disposition_index)
  - Something that [Dr. Stephen Kahn](https://uwmdi.org/faculty/steven-kahn-mb-chb/) developed with Daniel Port many, many years ago

**⇒** So simply looking at insulin or trying to do an [OGTT](https://en.wikipedia.org/wiki/Glucose_tolerance_test#:~:text=oral%20glucose%20tolerance%20test%20(OGTT)%2C) to know how the ꞵ-cell is working, that’s not so good

- That’s why in the [Qatar Study](https://pubmed.ncbi.nlm.nih.gov/28096223/), in the [EDIC Study](https://pubmed.ncbi.nlm.nih.gov/25425451/), we are doing such sophisticated measures of insulin sensitivity and ꞵ-cell function
  - You do 350 people, that’s like doing one of these big cardiovascular studies with 5,000 people in it

> “*The pathophysiology will always tell you the truth in my opinion. If you know what the problem is and you correct the problem, the A1C’s going to get better.*”‒ Ralph DeFronzo

- ADA does not emphasize pathophysiology
- Shulman was on the podcast [[episode # 140](https://peterattiamd.com/geraldshulman/)], and he and Ralph think very similarly: you understand what causes a disease and then you come with the treatment that will make it work

## How GLP-1-induced weight loss affects muscle mass, the benefits and risks of myostatin inhibitors, and the need for better methods of evaluating functional outcomes of increased muscle mass [1:51:30]

**Do you have any concerns with long-term safety or anything other than simply the economics of the GLP-1s in this current generation?**

- It was a huge leap forward between [liraglutide](https://en.wikipedia.org/wiki/Liraglutide) and [semaglutide](https://en.wikipedia.org/wiki/Semaglutide), and Peter has discussed briefly elsewhere on the podcast [[AMA #64](https://peterattiamd.com/ama64/)] what the roadmap looks like for how many of these drugs are in the pipeline
  - There seems to be no end in sight
  - And we’re going to look back at semaglutide and say, “*God, that thing was pedestrian.*”
- At the present time, Ralph considers these drugs to be quite safe

***The major issue is you have to go slow because of the GI toxicity***

*Where is the controversy involved?*

- This is something Ralph is involved in

**⇒** When you lose 20 or 30% of your body weight, you lose muscle mass

- Recently, Ralph gave a talk on this to one of the pharmaceutical companies that are involved in this area
- He started with a discussion of real data from a gastric bypass surgery [study](https://pubmed.ncbi.nlm.nih.gov/30657952/) ([Roux-en-Y bypass](https://en.wikipedia.org/wiki/Gastric_bypass_surgery#:~:text=The%20Roux%2Den%2DY%20laparoscopic%20gastric%20bypass))
- People lost about 33% of their body weight, and their lean body mass came down quite significantly

***One of the problems is people measure lean body mass, and that’s not a real measure of muscle mass***

- In fact, it can be a very bad measure ‒ you should measure muscle mass
- But let’s assume that the lean body mass largely reflects a reasonable assumption of muscle mass; and muscle mass came down. Why is that so bad?

Peter asks, “*How much did it come down? Because if total body mass came down by 33%, but ¾ of that mass was fat and only ¼ of that was lean, we would consider that acceptable.*”

- This is where the controversy is because no one has really measured muscle mass
- Ralph is studying this and will have a definitive answer
  - He’s doing it with MRI (the gold standard)

***In this study it was measured with absolute strength (grip strength or leg strength), and absolute strength went down maybe 25%***

Peter asks, “*Were these patients exercising during the period of new weight loss?*”

- No
- Then they said, “*Let’s express strength per weight loss.*”
- It went up by 50% per appendicular
- They looked at how far they could walk: they went from walking 200 yards to 2 miles
- They looked at how many times they could get up out of a chair in a certain period of time
  - It increased 3 or 4-fold
- They measured VO2 max, and it all got better
- Peter finds that counterintuitive ‒ normally when you lose weight, VO2 max in L/min does not improve because you have less metabolic tissue
- Ralph suggests that maybe all of the fat that’s pushing on your lungs makes it so you can’t oxygenate…
  - Or the epicardial fat is not allowing your heart to contract
  - The fat that’s in the heart, that’s causing myocardial lipotoxicity ‒ these things are all changing in a positive way

**The pharmaceutical companies don’t like this**

- Now the companies are all looking at developing drugs that will preserve the muscle mass or increase the muscle mass
- But this is lean mass and we have to say it’s reflecting muscle mass
  - That everything gets better, the patient feels better, they can walk better, they feel stronger, etc.

***Ralph asks why they are so worried about muscle mass and sees all these gloomy faces because they’re all developing*** [***myostatin inhibitors***](https://en.wikipedia.org/wiki/Myostatin_inhibitor) ***or*** [***activin***](https://en.wikipedia.org/wiki/Activin_type_2_receptors)

- The next slide in his talk is about improvements after gastric bypass surgery, if you lose all of this body weight
  - You improve insulin sensitivity in muscle
  - You improve it in the heart and there are cardiovascular benefits, and you correct the improvement in all of the cardiovascular risk factors
  - There may be an enormous benefit of seeing the improvement in the muscle insulin sensitivity, even though you’ve lost muscle mass
- There are some concerns about these drugs (myostatin inhibitors), that they actually may have some negative effects on the heart
- Ralph suggests: actually, you may find a big improvement in myocardial function

**Where are myostatin inhibitors in their development?**

- Phase 2
- We’ve talked about myostatin before on the podcast [[episode #291](https://peterattiamd.com/derekmpmd2/)]:
  - Cardiac muscle is striated when you inhibit myostatin, you increase expression of striated muscle
- It works through the [activin](https://en.wikipedia.org/wiki/Activin_type_2_receptors) 2A and 2B system

Peter asks, “*Do you think that’s a more promising pathway than the* [*follistatin*](https://en.wikipedia.org/wiki/Follistatin) *pathway where increasing follistatin inhibits myostatin?*”

- Yes, this is a more direct way to do it
- There are antibodies ([bimagrumab](https://en.wikipedia.org/wiki/Bimagrumab)) to myostatin, or you can interfere with the signaling receptor itself

*Do we think this can still be effective in a fully developed and mature adult?*

- We don’t know the answer to that
- A lot of the animal work is knockouts ‒ [myostatin knockouts](https://www.pnas.org/doi/10.1073/pnas.94.23.12457#:~:text=data%20not%20shown).-,Figure%202,-A%20fullblood%20Belgian) look like bodybuilders

*It passed the toxicity studies in Phase I, what about the phase II studies?*

- There doesn’t seem to be any adverse effect of these drugs or they wouldn’t got through Phase II, and there are actually some fairly large Phase II studies
- Ralph doesn’t know what the indication is
- If you have a sarcopenic disease, the FDA has certain criteria you have to meet if you want to develop a drug
  - Ralph is not an expert in this and can’t tell you exactly what these criteria are

**Let’s say you go on a GLP-1 receptor agonist and you lose 25% of your body weight, and you also take a myostatin inhibitor and that prevented muscle loss (didn’t increase it)**

- To Peter this is ridiculous
  - If you took a 200-pound individual who’s 30% body fat
  - They’ve got 60 pounds of adipose tissue on them
  - If you took 25% of their body weight off, you take them down to 150 pounds
  - But you’re telling me potentially we prevent any deterioration of lean mass?
  - That means they’re down to 10 pounds of fat mass on a 150-pound frame (that’s remarkable)
- Let’s say that happened

*What would be the FDA criteria to give approval for this drug?*

- Peter thinks the FDA would ask that you’ve also improved function in some way and the function would have to be determined through absolute strength (not relative strength)
- Ralph doesn’t know the answer to this question
- Peter thinks about these drugs more for the sarcopenic adult than this situation
  - The lean older person
- For the elderly individual whose sarcopenic and whose fall risk is enormous and their risk of fall and morbidity and mortality is very high, Peter doesn’t think the FDA will be satisfied with simply an increase in lean body mass unless it is accompanied by strength
- Some of the tests used here are silly
  - Peter thinks the 6-minute walk test should be put in a wastebasket and never discussed again
- We need a much more rigorous test that is actually more of a submaximal test
- If we’re **testing cardiorespiratory fitness** or some sort of peak aerobic fitness, we have to do more than walking
- For **testing strength**, Peter prefers grip strength, leg extension, bench press
  - These can be done with machines and done very safely
- We really need to test strength
- Ralph agrees these are very important and critical issues

**There are many companies that are going ahead with these drugs that increase muscle mass, but what does that mean?**

- There needs to be some functional translation of that
- Peter suggests **other functional benefits** that exceed strength: for example, glucose disposal
  - Insulin sensitivity ‒ that’s the one Ralph put at the top of the list for them
- Get rid of insulin resistance, the FDA won’t give them credit for that
  - Peter thinks that’s harder to tease out, because there’s more moving pieces
- They might argue there are easier ways to increase insulin sensitivity and glucose disposal

*What if you did it the old-fashioned way? What if you got in the gym and lifted a bunch of weights?*

- That’s been done, and it increases insulin sensitivity (and functional strength)

**The question is, can we replicate that pharmacologically?**

- That is exactly the way Ralph ended his discussion with these people
- He showed them what resistance training did
- If you could show what resistance training did with your muscle mass increase, then you’d have something
- But you need to design the studies appropriately
- And we don’t know what the criteria are going to be that the FDA uses to judge these things
  - They have a sarcopenia set of criteria, but that’s a very different group of people

**What about the lean person who’s 80 years of age? Is this the right drug for that person?**

- It might not
- Let’s say you have a healthy, 80-year-old person and everybody in the family lives to be 105, and they have diabetes
- They’re at risk to the toxic effects of hyperglycemia
- Would it be reasonable to treat that person?
- We know those powerful effects on the ꞵ-cell
- Ralph would say it would be quite reasonable, but you need to monitor what’s happening to their weight and other features

## The growing crisis of childhood obesity and challenges in treating it [2:02:15]

**A bigger issue is childhood obesity**

- You are obese when you’re 4 years of age, you’re going to be obese when you’re an adult
- And your life expectancy is decreased
- Your quality of life will be significantly reduced
- And you get diabetes

**⇒** Adolescents, these young kids with diabetes, they don’t respond to any of the drugs

**What is the prevalence of type 2 diabetes in under 18?**

- It’s increasing; maybe around 4-5%
  - 1 in 20 teenagers in San Antonio has type 2 diabetes (very high)
  - Ralph is biased by San Antonio because they have more people with type 2 diabetes in their clinic
- In the pre-diabetes studies Ralph did (a big NIH-sponsored study), these kids don’t respond to metformin, sulfonylureas
- The first [studies](https://pubmed.ncbi.nlm.nih.gov/38229444/) of the GLP-1 receptor agonists has just come out (using [liraglutide](https://en.wikipedia.org/wiki/Liraglutide)), and they respond better

***Clinically, even using the best drugs available you’re in trouble, you can’t get them controlled ‒ they’re much more insulin resistant than adults***

Peter asks, “*Is this really a selection bias where for someone to develop type 2 diabetes as a 16-year-old, the underlying genetics and pathology are so severe that the current crop of drugs are the problem as opposed to when you take the current crop of drugs and you apply them to people who are young, they don’t work?*”

- All 3
- Ralph adds 1 more: genetic predisposition
  - This is a huge problem in the hispanic population
  - Obesity is a huge problem
- You don’t see the lean diabetic in this age group

**The** [**RISE study**](https://diabetesjournals.org/collection/50/The-RISE-Study-More-Insights-into-T2D-in-Youth-and) **[Restoring Insulin Secretion]**

- These kids are starting to develop kidney disease
- Some even have [MIs](https://en.wikipedia.org/wiki/Myocardial_infarction) in their 20s

> “*They’re incredibly difficult to control.*”‒ Ralph DeFronzo

- Say you’re 16 and you’re on metformin
- Your A1C is 9
- You can put someone on Mounjaro and they’re going to have to take this for the rest of their life
- Because as soon as you stop the drug…
- The **3 big ifs**: if their doctor knows what to do, if the patient will cooperate, and if they can afford the medication

***If you can satisfy those 3 ifs, then their diabetes would be well controlled***

**Does Medicaid cover Mounjaro if their A1C is 9?**

- Yes, if you have diabetes, the Mounjaro coverage I think is pretty good if you have diabetes
- If you have obesity without, that’s a whole different issue

*Should you be treating these young kids?*

- Obesity is a disease; you got all kinds of problems
- Should you put these young kids on these newer drugs knowing that all I did is change them from food addiction to drug addiction?
- It’s almost like alcohol addiction: there are drugs that can be given to help, but they tend to relapse
  - Food addiction, you go on a drug, you lose weight
  - You stop the drug, you regain the weight
- This is a huge public health concern

*Finances are involved*

- Can we afford to treat 42% of the people in the U.S. who are obese?
- Or is there some way amongst the 42%, we can define who are the people who are insulin-resistant, who are the people who have the metabolic syndrome, that we know they’re at risk, that we can treat them?
  - Ralph’s guess is it’s the great majority of that 42% of the people
- Can we treat all of those people? And moreover, are they going to stay on the drug?

**⇒** On average, what the data is saying: within a year, half of the people stop the drug

- It’s probably a combination of cost and side effects
- Ralph’s patients commonly tell him, “*I enjoy eating and I can’t eat anymore.*”
- Some is GI side effects
- Some is cost: $1000 a month is a lot of money

Peter adds, “*This begs the question, will the next generation of weight loss drugs be true uncoupling agents where you can basically eat as much as you want and they’re going to create so much mitochondrial uncoupling and thermogenesis that you’re truly going to see this increase in non-voluntary energy expenditure, and of course not have the GI side effects*.”

## The environmental and neurological factors driving the obesity epidemic [2:07:30]

**The question everybody wants to understand is: what has changed so much in the last 30 years that has created this epidemic?**

- Everybody has their favorite pet theory: sugar, carbs, plastics, video games, the internet, whatever
- Ralph would say all of the above

**⇒** Processed foods, calorically dense foods, and lack of exercise are critical

***These are the stimuli that has done something, that’s changed the neurocircuitry in the brain***

- There’s a stimulus and because now you’ve been oversubscribed to the stimuli, that’s now initiated a process in the brain
  - Which is going to be a self-fulfilling prophecy
- This is something Ralph and [Dr. Peter Fox](https://directory.uthscsa.edu/academics/profile/fox) at the Health Science Center are very interested in
- If you go through the literature in the areas of the brain that control food intake
  - Not the hypothalamus ‒ that kind of regulates your basal energy intake, what you need to keep your BMI of 25, do what you do during the day

*What is it that makes your BMI go to 35?*

- That’s all related to the hedonic areas in the brain, the putamen, the amygdala, the prefrontal cortex, etc.
- When you do [structural MRI](https://pmc.ncbi.nlm.nih.gov/articles/PMC6865471/), those areas in the brain, the gray matter is shrunk down

***If you map the neurocircuitry using functional MRI (which*** [***Peter Fox***](https://directory.uthscsa.edu/academics/profile/fox) ***has been involved with), you can see that there’s clear disruption of the neurocircuitry in the brain***

- Ralph and Peter fox have a particular interest in defining where this dysfunction occurs, and they have some ideas
- And interest in how we might be able to sort of reprogram the brain
- If you do an insulin clamp, Ralph mentioned earlier that in you or I, your brain doesn’t respond by taking up glucose
- But in people who are obese, actually almost in proportion to how obese you are in these areas in the brain, the hedonic areas, there’s a marked increase in, it’s called fluorodeoxyglucose
  - Which is the PET radioisotope tracer we use in these areas
- And that correlates inversely with the muscle insulin resistance

***The more insulin resistant they are in the muscle, the more uptake of glucose there is in the brain***

- This is very interesting because what it’s saying is that somehow or another we believe that the brain is talking to the muscle or the muscle is talking to the brain (there is a connection), and somehow the brain is playing a very important role in the development of insulin resistance
- In large part, this deranged neurocircuitry, which is related to food intake, is now making you overeat
- And as you overeat, then all of the things that we know that we’ve studied, that go with lipotoxicity: you put fat in the muscle, you’re insulin resistant
  - You put fat in the liver, you got NASH and NAFLD

**⇒** What people have totally overlooked, you put fat in the kidney, you get kidney disease

- Fat in the heart ‒ yeah

## The role of genetics, insulin signaling defects, and lipotoxicity in insulin resistance and diabetes treatment challenges [2:11:00]

**You’ve been in San Antonio since the late ’80s. When did you really start to notice this was a problem, at least in your community?**

- Almost instantaneously
- Even in kids
- We can’t blame video games or social media, because that wasn’t going on in the late ‘80s

Ralph adds, “*I never saw fat kids at Yale. I was on the faculty from ’75 to ’88… I don’t remember seeing 12-year-old kids with type 2 diabetes.*”

- People thought that was crazy when he came to San Antonio

*What about in non-Hispanic kids? Because if the Hispanic kids are genetically predisposed to this, then the question becomes when did you begin to see this in African-American kids and Caucasian kids?*

- There is not a large African-American population in San Antonio
- But in Philadelphia, [Silva Arslanian](https://www.pediatrics.pitt.edu/people/silva-arslanian-md) sees the same thing and it’s significant in the African-American population
- In certain ethnic minorities where the genes for diabetes are enriched, those are the populations that are predisposed

**Do you think this is mostly an energy balance issue and therefore it’s mostly a food environment issue?**

- Ralph thinks it’s both
- A long time ago, he did a genetic study with an Italian fellow who was with him, [Giovanni Gulli](https://www.researchgate.net/profile/Giovanni-Gulli-2)

*They wanted to know: what is the earliest defect that you can see in people who are going to develop type 2 diabetes?*

- In the Hispanic community, children whose mom and dad had diabetes have a 70, 80% chance of developing diabetes
- It was easy to find these children
- The problem was, they couldn’t find lean children; they finally found them and did an insulin clamp
- If you’re obese, you got the lipotoxicity
- These lean children were as resistant as their parents
  - They had a normal glucose tolerance because their insulin levels are astronomical (2x normal or higher)
  - This is a [*JCI* paper](https://pubmed.ncbi.nlm.nih.gov/1446799/)
- A muscle biopsy shows the same defect in the insulin signaling pathway

Peter asks, “*How many tyrosine kinase defects do they have?*”

- It starts at IRS-1 [shown in the figure below]
  - You can’t tyrosine phosphorylate it
  - You cannot activate PI3 kinase
- Insulin binding at the receptor is okay (just like their parents)

![](https://peterattiamd.com/wp-content/uploads/2025/02/f9-ralphdefronzo.png)

**Figure 9. Impaired insulin signaling in insulin resistant individuals begins at IRS-1**. Image credit: [*Biochemistry Research International* 2010](https://pmc.ncbi.nlm.nih.gov/articles/PMC2860140/)

- Shulman and Ralph have both done this in somewhat different ways
  - Shulman uses NMR by looking at phosphate derivatives, and his work would suggest that the primary defect is at the level of glucose transport
  - Ralph believes the primary defect is in the signaling pathway
- Ralph developed a novel triple tracer technique using 3 isotopes infused into the brachial artery
- He believes that the primary defect is at the level of [hexokinase](https://en.wikipedia.org/wiki/Hexokinase) in phosphorylating glucose
- They agree to disagree because we can’t do the study
  - They’d have to do the MRI study at the same time they’re doing the triple tracer technique

***In addition to the insulin signaling defect, there’s a severe defect in glucose transport and phosphorylation***

**How glucose enters the cell and what happens next**

- Glucose enters the cell passively through the [GLUT4 transporter](https://en.wikipedia.org/wiki/GLUT4)
- Then to metabolize it, the first step is [hexokinase II](https://en.wikipedia.org/wiki/Hexokinase#Hexokinases_I,_II,_and_III) takes a phosphate off ATP and puts it on the 6th carbon of glucose
  - There’s a [different hexokinase](https://en.wikipedia.org/wiki/Glucokinase) in the liver versus the muscle

***The GLUT4 transporter is severely impaire***d

- Shulman would say this is the primary defect (in the GLUT4 transporter)
- The controversy is if GLUT4 is simply because it’s not getting the signal to work because of IRS-1
- Ralph was the 1st to show this defect in muscle in humans
  - He may be the only people to show this in humans
  - Metabolism in rats and mice is so different

**Mechanisms of insulin resistance**

- 1 – Simply having the IRS-1 problem may be enough (Ralph believes and there is evidence to support that)
- 2 – GLUT4 is not going to the cell surface (even if IRS-1 is functioning reasonably)
- 3 – If hexokinase doesn’t phosphorylate glucose [to keep glucose in the cell], then you backup the whole system
- 4 – Ralph can show that it is a primary defect in [pyruvate dehydrogenase](https://en.wikipedia.org/wiki/Pyruvate_dehydrogenase_complex), in [glycogen synthase](https://en.wikipedia.org/wiki/Glycogen_synthase)

**It comes back to the** [**ominous octet**](https://pmc.ncbi.nlm.nih.gov/articles/PMC2661582/#:~:text=a%20new%20tab-,The%20ominous%20octet.,-See%20text%20for) **for insulin resistance and this is why people don’t understand**

- There are 8 organ sort of things that are a problem
- There are 8 problems within the muscle

*Why do you think 1 drug is going to correct all these problems?*

- We need drugs that work on the ꞵ-cell
- We need insulin sensitizers
  - We probably need different types of insulin sensitizing drugs
- We need drugs that reverse the lipotoxicity

*Will we ever have a single magic bullet that corrects all of these?*

- Probably not until we discover the genetic basis
- Diabetes is a heterogeneous disease
- In *Diabetes Metabolism Reviews*, 30 years ago, Ralph wrote a [review article](https://onlinelibrary.wiley.com/doi/10.1002/dmr.5610010101) that said, “*I can put a defect in the muscle and reproduce diabetes. I can put a defect in the liver and reproduce diabetes. I can put a defect in the fat cell and reproduce diabetes. I can put a defect in the ꞵ-cell and reproduce diabetes.*”
- He went back and read that and added, “*I can put a defect that starts in the brain and reproduce diabetes.*”

***When we see someone with an A1C of 8 or 9, all these defects we’ve been talking about, they’re already there***

Peter asks, “*You put that defect in the fat cell, they can look lean?*”

- There’s a syndrome called [Alstrom Syndrome](https://diabetesjournals.org/diabetes/article/70/2/364/39497/Relative-Adipose-Tissue-Failure-in-Alstrom) where there’s a specific defect in white adipocytes
  - There is a specific defect in the glucose transporter in white adipose tissue [that impairs glucose transport]
  - And you become diabetic
  - You gain weight
  - You get NASH
- [Phil Scherer](https://profiles.utsouthwestern.edu/profile/92752/philipp-scherer.html) is the top guru in adipocyte metabolism up in Dallas, and when the gene causing this defect is knocked-out in mice, it causes diabetes

## The oral glucose tolerance test (OGTT): detecting early insulin resistance and beta cell dysfunction [2:18:30]

**OGTT (oral glucose tolerance test)**

- None of us have the privilege of being able to use a euglycemic clamp, both clinically as physicians or experience it as patients
- So we’re going to have to kind of rely on other things
  - We’re going to have to rely on body fat
  - We’re going to have to rely on triglycerides
  - We’re going to have to rely on HbA1c
    - Although this is unhelpful at the individual level ‒ the correlation between HbA1c and realized glucose levels is pretty weak
    - At the population level, it’s great
- [OGTT](https://en.wikipedia.org/wiki/Glucose_tolerance_test) is not a test that is done frequently but Peter believes it should be

*Walk us through the interpretation of the following couple scenarios*

- All of these people are going to start out normal with a glucose of 90 and an insulin of 6
- They consume 75 g of oral glucose

Case 1

- At 30 minutes after consuming glucose, the glucose rises to 130 and the insulin rises to 90
- At 60 minutes, the glucose is down to 200, the insulin is down to 60
- At 2 hours, the glucose is at 60 and the insulin is 20

***This is a very insulin resistant person, and this is a pre-diabetic state***

- 2 hours later, the hypoglycemia is a reflection of the ꞵ-cell’s early insulin secretion (they over did it)
- Peter sees this all the time
- This person has a perfectly normal HbA1c, and gets passed all the time as normal

**⇒** They’re severely insulin resistant; the ꞵ-cell is doing a good job

- Your A1C is normal and your insulin is 6, even if the doctor is checking insulin

***The thing that trips you off is not their glucose (90 to 130 to 100 is amazing), it’s how high the insulin was at 30 minutes (90)***

- They overshot [insulin secretion] and that is why they became hypoglycemic

Case 2

- This person also starts out with a glucose of 90 and an insulin of 6
- At 30 minutes their glucose goes to 180 and their insulin goes to 30
- At 60 minutes their glucose is 200 and insulin is 40

***They’re diabetic***

- These are almost real cases
- This is a person whose HbA1c is 5.6

**⇒** The best predictor of who’s going to get diabetes is a one-hour glucose greater than 155

- Ralph has [published](https://pubmed.ncbi.nlm.nih.gov/18487478/) this
- This is from prospective data from the [San Antonio Heart Study](https://jamanetwork.com/journals/jamainternalmedicine/article-abstract/622459)
- Also from the [Botnia study](https://www.helsinki.fi/en/researchgroups/genetic-and-metabolic-characterization-of-diabetes)  and Ralph’s [VAGES Study](https://pubmed.ncbi.nlm.nih.gov/16644701/) [Veterans Administration Genetic Epidemiology Study]
- Ralph’s group were the first people to publish this (7, 8, 9, 10 years ago)
- There’ve been at least 15 to 20 studies that have reproduced what they showed 10 years ago

***If the 1-hour glucose is >155, this is a great predictor of type 2 diabetes; and if you also happen to be hypoinsulinemic, that adds more to the predictive value***

Case 3

- This is a person who has a delayed onset of insulin
- They start out normal at 90
- The 30-minute insulin does nothing, glucose rises
- Then at 1 hour and 90 minutes, the pancreas kicks on and starts to dispose of glucose

***That’s a primary ꞵ-cell defect***

**⇒** One of the earliest things you can detect in people who are predisposed to develop diabetes is loss of 1st phase insulin secretion

- Strictly speaking, the 1st phase insulin secretion can only be measured with the hyperglycemic clamp that Ralph developed
- When you acutely raise the glucose from say 90 to 200: in the first 10 minutes, there’s a big spike of insulin that comes out
- That is typically lost in people who are going to develop type 2 diabetes

***Its counterpart, during the OGTT, is the insulin level at 30 minutes, and a low insulin response is a predictor of who’s going to get in trouble***

**Numbers Peter uses in his practice (what he wants to see)**

*Do you think we’re being too aggressive?*

- At time 0, we want to see you less than 90 [for glucose] and less than 6 [for insulin]
- At time 30 minutes, we want to see you less than 140 and less than 40
- At time 60 minutes, we want to see you less than 130
- At 90 minutes, we want to see you less than 110 and less than 20

***That might be overly aggressive, but if you meet those numbers, you’re probably safe***

**Closing thoughts**

- Someone listening to this podcast who heard the [podcast](https://peterattiamd.com/geraldshulman/) with [Gerald Shulman](https://medicine.yale.edu/profile/gerald-shulman/) from probably 3 years ago will be pleased because the overlap is virtually zero
- That’s what’s amazing about a topic as rich as this, as you can talk to 2 of the world’s experts and have 2 completely different conversations
- The conversation with Shulman focused so much on the pathophysiology of insulin resistance
- Here, we focused much more on the actual organ-specific aspect of type 2 diabetes
- We got a master class in the pharmacology of it, and then brought it back to ways to diagnose it if you’re slumming it with those of us in the clinic who don’t have clamps
- Maybe in the future we have an episode with both Gerald and Ralph

---

## Selected Links / Related Material

**Episode of** ***The Drive*** **with Gerald Schulman**: [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) (December 7, 2020) | [2:00, 1:15:00, 1:51:30]

**Ralph’s Banting Lecture and ominous octet of diabetes**: [Banting Lecture. From the Triumvirate to the Ominous Octet: A New Paradigm for the Treatment of Type 2 Diabetes Mellitus](https://pmc.ncbi.nlm.nih.gov/articles/PMC2661582/) | *Diabetes* (R DeFronzo 2009) | [5:45, 26:15, 45:45, 1:16:00]

**Review of Cahill studies of starvation**: [Fuel Metabolism in Starvation](https://pubmed.ncbi.nlm.nih.gov/16848698/) | *Annual Reviews in Nutrition* (G Cahill 2006) | [6:00]

**40 day fast**: [The consumption of fuels during prolonged starvation](https://pubmed.ncbi.nlm.nih.gov/5720334/) | *Advances in Enzyme Regulation* (G Cahill, O Owen, A Morgan 1968) | [6:00]

**Euglycaemic insulin clamp technique**: [Glucose clamp technique: a method for quantifying insulin secretion and resistance](https://journals.physiology.org/doi/abs/10.1152/ajpendo.1979.237.3.E214?rfr_dat=cr_pub++0pubmed&url_ver=Z39.88-2003&rfr_id=ori%3Arid%3Acrossref.org) | *American Journal of Physiology Endocrinology and Metabolism* (R DeFronzo, J Tobin, R Andres 1979) | [13:15]

**Insulin promotes protein metabolism**: [Effect of insulin and plasma amino acid concentrations on leucine metabolism in man. Role of substrate availability on estimates of whole body protein synthesis](https://pubmed.ncbi.nlm.nih.gov/3316280/) | *Journal of Clinical Investigation* (P Castellino et al. 1987) | [14:30]

**Managing insulin resistance**: [Managing insulin resistance: the forgotten pathophysiological component of type 2 diabetes](https://journals.physiology.org/doi/abs/10.1152/ajpendo.1979.237.3.E214) | *The Lancet Diabetes Endocrinology* (M Abdul-Ghani, P Maffei, R DeFronzo 2024) | [36:15]

**VAGES study**: [Insulin secretion and action in subjects with impaired fasting glucose and impaired glucose tolerance: results from the Veterans Administration Genetic Epidemiology Study](https://pubmed.ncbi.nlm.nih.gov/16644701/) | *Diabetes* (M Abdul-Ghani et al. 2006) | [37:15]

**GWAS on insulin resistance**: [Genome-Wide Linkage Scan for Genes Influencing Plasma Triglyceride Levels in the Veterans Administration Genetic Epidemiology Study](https://pubmed.ncbi.nlm.nih.gov/18931038/) | *Diabetes* (D Coletta et al. 2009) | [37:15]

**8 genes associated with insulin resistance**: [Genetic drivers of heterogeneity in type 2 diabetes pathophysiology](https://pubmed.ncbi.nlm.nih.gov/38374256/) | *Nature* (K Suzuki et al. 2024) | [40:45]

**Rise in plasma FFA obliterates insulin signaling**: [Dose-response effect of elevated plasma free fatty acid on insulin signaling](https://pubmed.ncbi.nlm.nih.gov/15919784/) | *Diabetes* (R Belfort et al. 2005) | [48:00]

**GIP infused into patients with type 2 diabetes**: [Glucose-dependent insulinotropic polypeptide: blood glucose stabilizing effects in patients with type 2 diabetes](https://pubmed.ncbi.nlm.nih.gov/24423311/) | *Journal of Clinical Endocrinology & Metabolism* (M Christensen et al 2014)| [51:15]

**Glycerol from the fat cell drives gluconeogenesis**: [Hepatic Acetyl CoA Links Adipose Tissue Inflammation to Hepatic Insulin Resistance and Type 2 Diabetes](https://pubmed.ncbi.nlm.nih.gov/25662011/) | *Cell* (R Perry et al. 2015) | [50:32]

**Lowering FFA improves mitochondrial ATP generation**: [Chronic reduction of plasma free fatty acid improves mitochondrial function and whole-body insulin sensitivity in obese and type 2 diabetic individuals](https://pubmed.ncbi.nlm.nih.gov/24353180/) | *Diabetes* (G Daniele et al 2014) | [1:09:45]

**Review of insulin signaling and insulin resistance**: [Mechanisms of Insulin Action and Insulin Resistance](https://pmc.ncbi.nlm.nih.gov/articles/PMC6170977/) | *Physiological Reviews* (M Petersen, G Shulman 2018) | [1:15:15]

**Shulman’s Banting Lecture**: [2018 Banting Lecture, Gerald Shulman, Mechanisms of Insulin Resistance: Obesity, Lipodystrophy, T2DM](https://youtu.be/mrpQeRY7jXU?si=SXbfvPkERkty_OrF) | The Kevin Bass Show YouTube (2019) | [1:16:00]

**Pioglitazone myocardial blood flow**: [Pioglitazone Improves Left Ventricular Diastolic Function in Subjects With Diabetes](https://pubmed.ncbi.nlm.nih.gov/28847910/) | *Diabetes Care* (G Clarke et al 2017) | [1:17:45]

**NEJM article on metformin**: [Efficacy of metformin in patients with non-insulin-dependent diabetes mellitus. The Multicenter Metformin Study Group](https://pubmed.ncbi.nlm.nih.gov/7623902/) | *NEJM* (R DeFronzo, A Goodman 1995) | [1:23:00]

**EDICT study of triple therapy**:

- [Initial combination therapy with metformin, pioglitazone and exenatide is more effective than sequential add-on therapy in subjects with new-onset diabetes. Results from the Efficacy and Durability of Initial Combination Therapy for Type 2 Diabetes (EDICT): a randomized trial](https://pubmed.ncbi.nlm.nih.gov/25425451/) | *Diabetes, Obesity & Metabolism* (M Abdul-Ghani et al. 2015) | [1:24:15]
- [Durability of Triple Combination Therapy Versus Stepwise Addition Therapy in Patients With New-Onset T2DM: 3-Year Follow-up of EDICT](https://pubmed.ncbi.nlm.nih.gov/33273042/) | *Diabetes Care* (M Abdul-Ghani et al 2021)| [1:26:45]

**PROactive study**: [Secondary prevention of macrovascular events in patients with type 2 diabetes in the PROactive Study (PROspective pioglitAzone Clinical Trial In macroVascular Events): a randomised controlled trial](https://pubmed.ncbi.nlm.nih.gov/16214598/) | *The Lancet*(J Dormandy et al 2005) | [1:32:45]

**Review of benefits of pioglitazone**: [Pioglitazone: The forgotten, cost-effective cardioprotective drug for type 2 diabetes](https://pubmed.ncbi.nlm.nih.gov/30706731/) | *Diabetes & Vascular Disease Research* (R DeFronzo et al 2019) | [1:33:15]

**Qatar study**: [1:40:30]

- [Combination Therapy With Exenatide Plus Pioglitazone Versus Basal/Bolus Insulin in Patients With Poorly Controlled Type 2 Diabetes on Sulfonylurea Plus Metformin: The Qatar Study](https://pubmed.ncbi.nlm.nih.gov/28096223/) | *Diabetes Care* (M Abdul-Ghani et al. 2017)
- [Combination therapy with pioglitazone/exenatide improves beta-cell function and produces superior glycaemic control compared with basal/bolus insulin in poorly controlled type 2 diabetes: A 3-year follow-up of the Qatar study](https://pubmed.ncbi.nlm.nih.gov/32729222/) |  *Diabetes, Obesity & Metabolism* (T Abdul-Ghani et al. 2020)

**Subgroup analysis of the Qatar study**: [Type 2 diabetes subgroups and response to glucose-lowering therapy: Results from the EDICT and Qatar studies](https://pubmed.ncbi.nlm.nih.gov/35581905/) | *Diabetes, Obesity & Metabolism* (T Abdul-Ghani et al. 2022) | [1:42:00]

**Peter’s recent discussion of GLP-1 receptor agonists**: [#320 – AMA 64: New insights on GLP-1 agonists (Ozempic, Wegovy, Mounjaro) – efficacy, benefits, risks, and considerations in the rapidly evolving weight-loss drug landscape](https://peterattiamd.com/ama64/) (October 7, 2024) | [1:52:00]

**Effect of gastric bypass on lean body mass**: [Changes in Lean Mass, Absolute and Relative Muscle Strength, and Physical Performance After Gastric Bypass Surgery](https://pubmed.ncbi.nlm.nih.gov/30657952/) | *The Journal of Clinical Endocrinology & Metabolism* 2019 | [1:52:45]

**Peter discusses gains in muscle mass when myostatin is inhibited**: [#291 ‒ The role of testosterone in males and females, performance-enhancing drugs, sustainable fat loss, supplements, and more | Derek, More Plates More Dates Pt.2](https://peterattiamd.com/derekmpmd2/) (February 26, 2024) | [1:56:15]

**Using GLP-1 receptor agonists to treat youth with type 2 diabetes**: [Real-world use of glucagon-like peptide-1 receptor agonists in youth with type 2 diabetes is associated with short-term improvements in HbA1c](https://pubmed.ncbi.nlm.nih.gov/38229444/) | *Diabetes, Obesity & Metabolism* (S Samuels et al. 2024) | [2:03:15]

**The RISE study of type 2 diabetes in youth**: [The RISE Study-More Insights into T2D in Youth and Adults](https://diabetesjournals.org/collection/50/The-RISE-Study-More-Insights-into-T2D-in-Youth-and) | *American Diabetes Association* (2024) | [2:04:15]

**Children with diabetic parents who are lean but insulin resistant**: [The metabolic profile of NIDDM is fully established in glucose-tolerant offspring of two Mexican-American NIDDM parents](https://pubmed.ncbi.nlm.nih.gov/1446799/) | *Diabetes* (G Gulli et al 1992) | [2:09:22]

**OGTT one-hour glucose identifies diabetes risk**: [One-hour plasma glucose concentration and the metabolic syndrome identify subjects at high risk for future type 2 diabetes](https://pubmed.ncbi.nlm.nih.gov/18487478/) | *Diabetes Care* (M Abdul-Ghani et al. 2008) | [2:21:15]**Ralph’s recent perspective on type 2 diabetes**: [Managing insulin resistance: the forgotten pathophysiological component of type 2 diabetes](https://pubmed.ncbi.nlm.nih.gov/39098317/) | *The Lancet Diabetes and Endocrinology* (M Abdul-Ghani, P Maffei, R DeFronzo 2024)

---

## People Mentioned

- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) (1927-2012, Professor at Harvard Medical School; diabetes expert) [5:15]
- [Gerald (Jerry) Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) (1928-2018, endocrinologist and Professor of Medicine at Stanford; diabetes expert) [14:15, 34:15]
- [David Altshuler](https://en.wikipedia.org/wiki/David_Altshuler_(physician)) (Clinical endocrinologists, geneticist, Chief Scientific Officer at Vertex Pharmaceuticals, former Professor of Genetics at Harvard Medical School and MIT) [18:00]
- [Jesse Roth](https://feinstein.northwell.edu/institutes-researchers/our-researchers/jesse-roth-md-facp) (Professor of Medicine at the Feinstein Institutes for Medical Research, expert in diabetes and metabolic disorders for 50 years) [15:45]
- [Stefano Del Prato](https://www.easd.org/media-centre/home.html#!users/3329) (Professor of Endocrinology and Metabolism and Chief of the Section of Diabetes at the University of Pisa School of Medicine, Italy; past president of the European Diabetes Association) [31:45]
- [Michael Stern](https://www.linkedin.com/in/mike-stern-93a2bbb/) (Professor of Medicine at UT Health Science Center at San Antonio) [38:00]
- [Gerald Shulman](https://medicine.yale.edu/profile/gerald-shulman/) (George R. Cowgill Professor of Medicine (Endocrinology) and Professor of Cellular And Molecular Physiology, Co-Director, Yale Diabetes Research Center, and Director, Internal Medicine at Yale School of Medicine) [40:15, 47:00, 54:30, 1:01:00]
- [Mitchell Lazar](https://www.med.upenn.edu/apps/faculty/index.php/g275/p7505) (Willard and Rhoda Ware Professor in Diabetes and Metabolic Diseases and Founding Director of the Institute for Diabetes, Obesity and Metabolism at the Perelman School of Medicine, University of Pennsylvania) [41:00]
- [Luke Norton](https://directory.uthscsa.edu/academics/profile/nortonl) (Assistant Professor of Medicine at UT Health San Antonio, expert in type 2 diabetes) [41:45]
- [Stephen Parker](https://medschool.umich.edu/profile/3640/stephen-c-parker) (Professor of Computational Medicine and Bioinformatics, Professor of Human Genetics, and Professor of BIostatistics at the University of Michigan Medical School; expert in metabolic diseases) [41:45]
- [Renata Belfort De Aguiar](https://lsom.uthscsa.edu/physiology/team-member/renata-belfort-de-aguiar-md/) (Assistant Professor of Cellular and Integrative Physiology at UT Health San Antonio Long School of Medicine) [48:00]
- [Jens Holst](https://www.harringtondiscovery.org/scholars/jens-j-holst) (Professor and Vice-Chair of Medical Physiology at the University of Copenhagen, expert in regulatory peptides of the pancreas and gut) [51:15]
- [Roger Unger](https://en.wikipedia.org/wiki/Roger_Unger) (1924-2020, was the Touchstone/West Distinguished Chair in Diabetes Research at University of Texas Southwestern Medical Center; expert in the physiology of pancreatic islets) [52:15, 55:00]
- [Luciano Rossetti](https://www.flagshippioneering.com/people/luciano-rossetti-2) (Chief Medical Officer for Flagship Pioneering and Head of R& D for Pioneering Medicines; Prior to this he spent 18 years as a Professor of Medicine and Molecular Pharmacology and leader of the Diabetes Research & Training Center at the Albert Einstein College of Medicine) [1:00:59]
- [Barry Brenner](https://www.kidney-international.org/article/S0085-2538(24)00642-2/fulltext) (1937-2024, his work as a Professor of Medicine at Harvard and leader of the Renal Division of the Peter Bent Brigham Hospital made tremendous advances in kidney basic science and clinical research) [1:03:30]
- [Peter Fox](https://directory.uthscsa.edu/academics/profile/fox) (Professor of Radiology and Director of the Research Imaging Institute at UT Health San Antonio) [1:04:30, 2:08:30]
- [C. Ronald Kahn](https://nutrition.hms.harvard.edu/people/c-ronald-kahn) (Mary K. Iacocca Professor of Medicine at Harvard Medical School and Senior Investigator and Head of Section of Integrative Physiology, Joslin Diabetes Center; expert in insulin signaling) [1:14:15]
- [Robert Turner](https://en.wikipedia.org/wiki/Robert_Turner_(endocrinologist)) (1938–1999, endocrinologist and Professor of Medicine at the Nuffield Department of Medicine, Oxford; he was best known for the UK Prospective Diabetes Study) [1:29:00]
- [Steven Kahn](https://uwmdi.org/faculty/steven-kahn-mb-chb/) (Professor of Medicine, Division of Metabolism, Endocrinology and Nutrition at UW and VA Puget Sound Health Care System and Director of the UW Diabetes Research Center) [1:29:00, 1:50:45]
- [Muhammad Abdul-Ghani](https://directory.uthscsa.edu/academics/profile/abdulghani) (Professor of Medicine at the Diabetes Division, University of Texas Health Science Center at San Antonio; expert in diabetes and Ralph’s collaborator) [1:44:15]
- Daniel Port ( [1:50:45]
- [Silva Arslanian](https://www.pediatrics.pitt.edu/people/silva-arslanian-md) (Professor of Pediatrics and Clinical and Translational Science at the University of Pittsburgh School of Medicine and Scientific Director of the Center for Pediatric Research in Obesity & Metabolism) [2:12:15]
- [Giovanni Gulli](https://www.researchgate.net/profile/Giovanni-Gulli-2) (Clinician and clinical scientist who specializes in diabetes at Division of Internal Medicine, Ospedale Maggiore, Savigliano, Italy) [2:12:45]
- [Philipp Scherer](https://profiles.utsouthwestern.edu/profile/92752/philipp-scherer.html) (Professor and Distinguished Chair in Diabetes Research at UT Southwestern Medical Center) [2:18:00]

---

![](https://peterattiamd.com/wp-content/uploads/2025/02/bio-pic-ralphdefronzo.png)

##### Ralph DeFronzo, M.D.

Ralph DeFronzo earned a B.S. in biology and biochemistry before attending Harvard Medical School. He did his residency in internal medicine at Johns Hopkins followed by a fellowship in endocrinology at the NIH, Baltimore City Hospital and then nephrology at the University of Pennsylvania. Dr. DeFronzo has been faculty at the Long School of Medicine at UT Health San Antonio since 1988, where he is currently the Joe R. & Teresa Lozano Long Distinguished Chair in Diabetes. He is a physician scientist who specializes in endocrinology and nephrology. Dr. DeFronzo is directly responsible for many seminal advances achieved in diabetes over the last 50 years. He was a leader in developing the concept of insulin resistance, the defining characteristic of Type 2 diabetes, resulting in novel ideas about the development and progression of diabetes.Dr. Ralph DeFronzo’s major interests focus on the pathogenesis and treatment of type 2 diabetes mellitus and the central role of insulin resistance in the metabolic-cardiovascular cluster of disorders known collectively as the Insulin Resistance Syndrome. Using the euglycemic insulin clamp technique in combination with radioisotope turnover methodology, limb catheterization, indirect calorimetry and muscle biopsy, he has helped to define the biochemical and molecular disturbances responsible for insulin resistance and impaired glucose metabolism.  Dr. DeFronzo is the longest consecutively funded investigator by the NIDDK/NIH – from 1975 to 2028 (53 years).  He currently is the PI on two five-year NIH grants and the Co-PI on two other five-year NIH grants in type 2 diabetes mellitus. [[UT Health San Antonio](https://directory.uthscsa.edu/academics/profile/defronzo)]