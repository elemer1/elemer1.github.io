# #85 – Iñigo San Millán, Ph.D.: Zone 2 Training and Metabolic Health

**Source:** [https://peterattiamd.com/inigosanmillan/](https://peterattiamd.com/inigosanmillan/)

---

##### Check out more content with expert, Iñigo San Millán, Ph.D.:

- *(December 23, 2019)* [Part I of II: Zone 2 Training and Metabolic Health](/inigosanmillan/)
- *(March 28, 2022)* [Part II of II: Deep dive back into Zone 2 Training](/inigosanmillan2/)

In this episode, Dr. Iñigo San Millán, Assistant Professor at the University of Colorado School of Medicine, explains the crucial role of mitochondrial function in everything from metabolic health to elite exercise performance. Iñigo provides a masterclass into the many different energy system pathways, the various fuel sources (including the misunderstood lactate), the six zones of exercise training, and the parameters he uses to measure metabolic health. Additionally, he highlights the power of zone 2 training in its ability to act as a powerful diagnostic tool, and perhaps more importantly as a treatment for mitochondrial and metabolic dysfunction.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/inigosanmillan/the_Drive_public.png)

Play

#85 - Iñigo San Millán, Ph.D.: Mitochondria, exercise, and metabolic health

#85 - Iñigo San Millán, Ph.D.: Mitochondria, exercise, and metabolic health

1x15s30s

0:002:53:03

## We discuss:

- Iñigo’s background in sports and decision to focus on education [7:15];
- Explaining the various energy systems and fuels used during exercise [14:45];
- Iñigo qualifies energy systems into six training zones [23:00];
- Lactate is an important fuel source [33:00];
- Zone 2 training—physiologic characteristics, fuel sources, lactate, and the transition into zone 3 [40:30];
- Using blood lactate levels (and zone-2 threshold) to assess mitochondrial function [47:00];
- Accessing mitochondrial function by looking at one’s ability to utilize fat as fuel (with an RQ test) [55:00];
- Athletes vs. metabolically ill patients—mitochondria, fat oxidation, muscle glycogen capacity, “fat droplets”, and more [1:00:00];
- Physiologic characteristics of zone 3, zone 4, and the lactate threshold [1:20:00];
- Fueling exercise—dietary implications on glycolytic function [1:30:30];
- Relationship between exercise and insulin sensitivity (and what we can learn from studying patients with type 1 diabetes) [1:46:30];
- Metformin’s impact on mitochondrial function, lactate production, and how this affects the benefits of exercise [2:04:15];
- Raising awareness for risk of “double diabetes” [2:15:00];
- How to dose zone 2 training, and balancing exercise with nutrition [2:18:00];
- Proposed explanation of the Warburg Effect: Role of lactate in carcinogenesis [2:27:00];
- Doping in cycling, and the trend towards altitude training [2:39:15] and;
- More.

§

## Show Notes

## Iñigo’s background in sports and decision to focus on education [7:15]

- He works with elite and recreational athletes in his clinical and research work and he was an athlete himself
- Grew up in spain, played fútbol for Real Madrid Academy for six years
- At 16, he discovered cycling and changed sports – racing professionally for six years
- He became very familiar with everything the sport involves at an elite level
- The distinction between ability of top caliber cyclists is not subtle
  - Decreasing categories represent higher ability levels with [category 1](https://en.wikipedia.org/wiki/USA_Cycling#cite_note-https://www.usacycling.org/forms/USAC_rulebook-1.pdf-2) being the immediate step below professional level
  - even between category one collegiate athletes
  - At a professional level there is a step between a domestic and European pro and moreover, between a European pro and a major team
- Iñigo left racing behind when he decided to focus on his studies – did an internship at a sports medicine clinic in Spain where [Platelet Rich Plasma Therapy](https://www.hss.edu/condition-list_prp-injections.asp) (PRP) was developed
- Has been at the University of Colorado for 11 years
- Works with professional cycling teams and has developed a protocol for [zone 2 training](https://www.trainingpeaks.com/blog/zone-2-training-for-endurance-athletes/) as a way to improve and test mitochondrial function

## Explaining the various energy systems and fuels used during exercise [14:45]

- Defines metabolic training zones by type of [muscle fiber](https://www.ncbi.nlm.nih.gov/pubmed/6462127) recruitment and whether energy demand is aerobic and anaerobic
- Outside of sprinting, we do the majority of activity in an aerobic state
- Fuel type utilized used to produce energy is what changes
- Peter refers to aerobic and anaerobic energy systems in a previous [blog post](https://peterattiamd.com/the-interplay-of-exercise-and-ketosis-part-ii/)

> “The immense majority of activity that we do is aerobic. We tend to believe that any hard effort is anaerobic, and therefore the concept of anaerobic threshold. But actually, even what we call the anaerobic threshold is aerobic activity. The majority of the efforts that we do are in an aerobic environment except for when you do a sprint…or a one minute maximal.” – Iñigo San Millán, Ph.D.

***Muscle Fiber Type***

- Depending on the energy system (training zone) different muscle fibers are recruited
  - “Slow” and “fast” twitch fibers require different force
  - The speed refers to how quickly the fibers fatigue
- Type I muscle fibers are used during low intensity exercises
  - Don’t need to contract as forcefully
  - Have a high oxidative and low glycolytic capacity
- Speed refers to how quickly they fatigue
- type 2 fiber divided into 2A and 2B
  - IIA have high oxidative and  glycolytic capacity and fatigue relatively slowly
  - IIB have low oxidative and high glycolytic capacity and fatigue quickly (recruited for anaerobic sprint – short time duration under stress)
- Fatigue faster because metabolically more stressed

***Cellular Fuels***

- Main fuels: [fatty acids](https://en.wikipedia.org/wiki/Fatty_acid_metabolism) and [glucose](https://en.wikipedia.org/wiki/Glucose)
- Fatty acids are the cellular fuel source for lower intensity activities

> “It’s about ATP generation, that’s exercise intensity. So, at low exercise intensities, those slow twitch muscle fibers, or type 1 muscle fibers, are very well designed to use an energy that is good enough to provide ATP. And yet, you can do this for a very long time. And that’s the diesel gasoline, and that is the fatty acids.” – Iñigo San Millán, Ph.D.

- As energy demand increases at higher intensity, glucose is used as fuel
- Glucose is a faster energy system

> “However, as exercise intensity increases, the necessity to produce ATP at a higher rate increases as well. And it gets to a point where fatty acids alone are not enough to produce ATP. Therefore, you need another energy system. And that energy system is glucose, which is a faster energy system. ” – Iñigo San Millán, Ph.D.

⇒ **Car analogy**: When driving on flat roads, the car will use diesel gas (fatty acids for the muscles) because it’s more efficient and economical because you get more miles per gallon. If you’re driving through the mountains you’ll need more acceleration so you’ll use the regular gasoline (glucose for the muscles)

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-1-inigo-1024x800.png)

**Figure 1****. Mitochondria metabolism. Mitochondria substrate utilization involves both fatty acids and glucose, undergoing either glycolysis or beta-oxidation to produce ATP. In the second stage of aerobic oxidation, pyruvate formed in glycolysis and transported into mitochondria, where it is oxidized by O2 to CO2. These mitochondrial oxidation reactions generate 34 of the 36 ATP molecules produced from the conversion of glucose to CO2.** Image credit: ([San Millán, 2015](https://www.ucdenver.edu/academics/colleges/medicine/sportsmed/cusm_events/2014SportsMedSymp/Documents/2015/Sports%20Performance%20testing%20in%20the%20Cyclist%20-%20San%20Millan.pdf))

- Whether activity demand qualifies as aerobic or anaerobic comes down to the speed with which the muscle is demanding ATP
- [Aerobic](https://www.sciencedirect.com/topics/medicine-and-dentistry/aerobic-metabolism) means ATP demand is slow enough that it can be met through mitochondrial oxidation of fuel sources (fatty acids)
- [Anaerobic](https://www.sciencedirect.com/topics/medicine-and-dentistry/anaerobic-metabolism) energy demands exceed the capacity of mitochondria oxidation
  - Fuel source comes from stored ATP in the muscle itself – not requiring any energy systems

> “when the ATP demands even exceed the cytosolic production of ATP, that’s when you need to use the ATP that is already stored in the muscle. You just don’t have time to synthesize it. You need to use it. And that’s why the body stores very, very minimal amounts of ATP. And that’s what you use in a sprint. But you need to resynthesize it very fast. That’s the pure anaerobic. You don’t need any energy systems.” – Iñigo San Millán, Ph.D.

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-2-inigo-1024x807.png)

**Figure 2****. The three energy systems of muscle ATP regeneration. Muscles cannot obtain ATP from the blood or other tissues, so they must manufacture it. To do this, they need ADP, inorganic phosphate (Pi), and energy from other chemical sources to reconstruct the ATP molecules by rephosphorylation of ADP.** Image credit: ([Baker et al., 2010](https://www.hindawi.com/journals/jnme/2010/905612/))

- The [creatine phosphate system](https://www.sciencedirect.com/topics/neuroscience/creatine-phosphate) (also called the phosphagen system) is the fastest way to resynthesize ATP  in the muscle
  - [Creatine phosphate](https://en.wikipedia.org/wiki/Phosphocreatine) (Crp) found in muscle donates a phosphate to ADP to produce ATP
  - Does not require oxygen; can therefore occur anaerobically

***Even under aerobic conditions, cell metabolism can produce lactate …***

- **[Research](https://www.cell.com/cell-metabolism/pdf/S1550-4131(18)30186-4.pdf) published by Iñigo’s colleague – [George Brooks](https://ib.berkeley.edu/people/faculty/brooksg) – reveals that lactate forms continuously under aerobic conditions in the cytosol**
- - Once thought to be a waste product of anaerobic metabolism is now known to form continuously under aerobic conditions
  - Lactate regarded as a “link” between glycolytic and aerobic pathways (lactate shuttle theory)
- [Aerobic glycolysis (Warburg effect)](https://www.ncbi.nlm.nih.gov/books/NBK470170/) also produces lactate
  - ATP can also be produced in the cytosol of a cell without mitochondrial oxidation

- - Utilization of glucose in the cytosol rather than in the mitochondria
  - Occurs in the presence of oxygen; produces lactate

## Iñigo qualifies energy systems into six training zones [23:00]

***Introducing a key paper that compared study groups with varying metabolic function capabilities….***

- Iñigo and his colleague George Brooks published a [2018 paper](https://www.ncbi.nlm.nih.gov/pubmed/28623613) that looked at Zone 2 efficiency in three populations:
  - 1) world class athletes
  - 2) recreational athletes
  - 3) diabetic individuals
- To understand how to fix defective mitochondria, Iñigo studies “perfect” mitochondria of elite athletes

> “The elite athletes have the perfect metabolism, and mitochondria is at the epicenter of metabolism … There are no other populations on the planet with the mitochondria of elite endurance athletes” – Iñigo  San Millán, Ph.D.

- The comparison of metabolic function across zones (particularly zone 2) provides a means by which Iñigo can study and understand key differences in mitochondrial health between a “normal” person, super athlete, and metabolically ill person

**Iñigo defines training zones by e*****nergy systems***

- Other energy systems are codified into different zones – for example [Dr. Andy Coggan’s](https://legacy.usacycling.org/coggan-bio.htm) [FTP-based (functional power threshold) energy system](https://www.trainingpeaks.com/blog/power-training-levels/)
- Iñigo defines six zones

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-3-inigo-1024x370.png)

**Figure 3.** **Iñigo defines six training zones that corresponds with the muscle fiber recruitment pattern and therefore, the fuel source demanded for exertion.** Image credit: [trainingpeaks.com](https://www.trainingpeaks.com/blog/zone-2-training-for-endurance-athletes/)

- Iñigo explains that zone training aligns with muscle fiber recruitment pattern and  corresponding energy systems
- In the lower training zones, type 1 muscle fibers are recruited
  - Have the highest mitochondrial density and content
  - We know they oxidize fat; fat can only be oxidized in the mitochondria
  - Particularly type 1IA fibers, in comparison, have lower mitochondrial function

> “The zone 1 would represent the minimum stimulation that the muscle fibers receive. It’s just pure contraction. That’s what you do in a recovery day or recovery mode. You have very low exercise intensity and you burn a little bit of fat… That’s what we see also … We [also] look at fat and carbohydrate utilization. Scientifically we call it fat and carbohydrate oxidation rates. How many grams per minute of carbohydrate and fat you burn.” – Iñigo San Millán, Ph.D.

- Zones are defined the same but look different (different output) depending on individual’s metabolic capacity (e.g., [Meb Keflezighi](https://en.wikipedia.org/wiki/Meb_Keflezighi)’s sub-2:10 marathon who would be in zone 1 at a 7min/mile pace)
  - Lactate yield depends on individual’s glycolytic capacity
  - For a metabolically normal person, glycolytic capacity is not as good as that of an elite athlete
  - Elite athlete lactate clearance is also more efficient, even though their yield may be higher
  - Sometimes elite athletes don’t make much lactate at all (e.g., [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong))

## Lactate is an important fuel source [33:00]

***Lactate is not a waste product but a fuel source***

> “…every cell in the body produces lactate and almost every cell in the body utilizes lactate…we believe…that it’s a very important signaling molecule that goes beyond being a byproduct or a metabolite” – Iñigo San Millán, Ph.D.

- Lactate is the most important fuel for the body
- Its a central player in cellular, regional, and whole body metabolism
- Brain prefers to use lactate
- Faster fuel compared to glucose

***Lactate used as a treatment in head trauma patients..***

- Alternative substrate to [beta-hydroxybutyrate](https://en.wikipedia.org/wiki/Beta-Hydroxybutyric_acid) (BHB) in trauma patients
- Comparatively, lactate is a faster fuel
- [Pyruvate dehydrogenase](https://en.wikipedia.org/wiki/Pyruvate_dehydrogenase) becomes resistant to insulin – explaining why glucose becomes ineffective
- George Brooks’ [research](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4530406/) with traumatic brain injury patients at UCLA (TBI) suggests that lactate can be used in rehabilitation
  - Supported giving trauma patients lactate rather than glucose
  - Without added fuel source, the injured body doesn’t have enough energy to repair itself
- In his research on lactate, Brooks has discovered three main uses of lactate in the body

1. It’s a major fuel source
2. It’s the major material to support blood sugar level
3. It’s a powerful signal for metabolic adaptation to stress

***In the context of physical exertion, lactate has been largely misunderstood…***

- Detrimental effects (the experienced pain and fatigue) of lactic acid (HLa) on muscle and exercise performance are due to (hydrogen ion) H+ rather than lactate (La−)
  - It’s not lactate but the H+ associated to lactate that accumulates
  - H+ can decrease both the contraction capacity of the muscle fibers, as well as the force by more than 50%
  - ATP is required for muscle contraction -unlocking the [actin-myosin](https://www.ncbi.nlm.nih.gov/books/NBK9961/) coupling
  - It’s the relaxation phase of the muscle contraction that requires energy
  - H+ are also produced from the hydrolysis (breakdown) of ATP
- When people are fatigued, there is a protective decrease in [adrenaline/epinephrine](https://en.wikipedia.org/wiki/Adrenaline)
  - Adrenalin is involved in the breakdown of glycogen to glucose

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-4-inigo-1024x885.png)

**Figure 4.** **The functional correlates of fatigue. Power output decreases by up to 50% in the presence of H+ buildup.** Image credit: adapted from plots ([Debold et al., 2008](https://www.ncbi.nlm.nih.gov/pubmed/18480297))

*In the context of pushing against fatigue during physical exertion…*

⇒ Peter recommends the book [Endure](https://www.amazon.com/Endure-Curiously-Elastic-Limits-Performance/dp/0062499866) by Alex Hutchinson

## Zone 2 training—physiologic characteristics, fuel sources, lactate, and the transition into zone 3 [40:30]

***Zone 2 is where the mitochondria produce the maximum ATP output under purely aerobic conditions…***

- Slow twitch muscle fibers are stimulated to their fullest expression prior to recruiting type 1Ia muscle fibers
- Coincides with [Fatmax](https://www.brianmac.co.uk/fatburn.htm) (exercise intensity where the highest amount of fat is oxidized by the cell)

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-5-inigo-1024x657.png)

**Figure 5. Metabolic map of fuel sources utilized depending on exercise intensity (marked by heart rate). Fat utilization in cellular metabolism peaks in zone 2. The crossover point (marked), where glucose exceeds fatty acids as a fuel source, occurs in transitional training zone 3.**  Image credit: ([San Millán, 2015](https://www.ucdenver.edu/academics/colleges/medicine/sportsmed/cusm_events/2014SportsMedSymp/Documents/2015/Sports%20Performance%20testing%20in%20the%20Cyclist%20-%20San%20Millan.pdf))

***Lactate as a signalling molecule…***

- Every cell produces lactate and almost every cell in the body utilizes lactate
- There is always some blood lactate (even at rest) produced from glucose utilization (our brains utilize blood glucose)
- Red blood cells produce a lot of lactate because they don’t have mitochondria
- It is not a waste product that merely gets transported back to the liver where the [Cori Cycle](https://en.wikipedia.org/wiki/Cori_cycle) and converted to glucose for transport
  - Lactate used as a fuel source by the mitochondria and type 1 muscle fibers (George Brooks [research conclusion](https://www.cell.com/cell-metabolism/pdf/S1550-4131(18)30186-4.pdf) about lactate)

> “We believe…[lactate] is a very important signalling molecule that goes beyond being a byproduct or a metabolite.” – Iñigo San Millán, Ph.D.

- In his [research,](https://www.frontiersin.org/articles/10.3389/fonc.2019.01536/abstract) Iñigo has observed how lactate stimulates the expression of the major oncogene transcription factors in breast cancer cell cycle genes
  - The work has just been reviewed and will be published shortly
  - demonstrated for the first time that dysregulated lactate (not same lactate from exercise) is a major regulator of all major genes involved in breast cancer

***Transitioning into zone 3…***

- As you progress to higher energy systems, you generate more ATP and consume more oxygen
- Once the ATP demand cannot be supported by fat alone, fuel source is switched and type 1I muscle fibers are recruited
- **[VO2 max](https://en.wikipedia.org/wiki/VO2_max) has not been reached, but efficiency decreases as you move to a less efficient fuel source (glucose)**
- We see a big drop in fat oxidation and an increase  in glucose oxidation

- If the ATP demand exceeds the capacity described in zone 2, pyruvate is converted into lactate (faster fuel source) to generate additional ATP
- Fatty acids and carbohydrates are mixed as fuel sources but the muscle starts using more carbohydrate and more lactate is therefore produced

## Using blood lactate levels (and zone-2 threshold) to assess mitochondrial function [47:00]

> “We start seeing an increase in lactate as well because lactate is […] the mandatory byproduct, not waste product, […] of glucose utilization … Every time you use glucose, you use lactate, and at higher intensity you produce more [lactate]…”  – Iñigo San Millán, Ph.D.

- Fitter individuals, like elite athletes, have a very high zone 2 (high lactate threshold)

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-6-inigo-1024x852.png)

**Figure 6****. Fitness level dictates blood lactate levels in response to increased power output (exertion). More efficient mitochondria function keep blood lactate lower relative to less efficient mitochondria at the same power output.** Image credit: [lactate.com](https://lactate.com/lactate_cycling.html)

- Elite athletes recruit fast twitch muscle fibers, utilizing glucose and producing lactate, but they have a high lactate clearance ability
- Levels remain within 1.5 to 2.0 millimole, which corresponds to fat max
- Blood lactate levels remain slightly above resting so there is no accumulation
- When blood lactate levels begin to increase, it means the muscle’s lactate clearance capacity cannot match lactate production (due to metabolic energy demands)

> “But since they have a very well developed mitochondria in slow twitch muscle fibers, they don’t need to export it [lactate] into the blood and it doesn’t accumulate” – Iñigo San Millán, Ph.D.

- Above 2 millimolar indicates that the muscle’s ability to utilize and recirculate lactate decreases so there is a higher blood lactate
- Elite athletes have a higher power output but not high blood lactate
- The fuel utilized is different: they may not need to use so much glucose
- If lactate is produced, they clear it efficiently by slow twitch muscle fibers that there remains a low blood lactate

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-7-inigo-1024x418.png)

**Figure 7.** **(Elite) Athletes can train to improve their lactate clearance capacity (increasing their zone 2 threshold).** Image credit: ([San Millán, 2015](https://www.ucdenver.edu/academics/colleges/medicine/sportsmed/cusm_events/2014SportsMedSymp/Documents/2015/Sports%20Performance%20testing%20in%20the%20Cyclist%20-%20San%20Millan.pdf))

> “An elite athlete might not need to use so much glucose. And if they do, they produce lactate but they clear out so efficiently in the slow twitch muscle fibers that it doesn’t have to go to the blood. Whereas the person who doesn’t have a very good mitochondrial function, cannot oxidize lactate very efficiently, locally in the skeletal muscle, and they have to export it into circulation”  – Iñigo San Millán, Ph.D.

- In their [2018 paper](https://www.ncbi.nlm.nih.gov/pubmed/28623613), Brooks and San Millán indirectly evaluated mitochondrial function, in the three populations, by measuring metabolic stress (blood lactate at a given effort)
- They found participants’ zone 2 threshold – the point at which their mitochondria are no longer able to meet the energy output requirement at blood lactate increases

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-8-inigo-753x1024.png)

**Figure 8****. Relationships between the average blood lactate concentrations and FATox (fat oxidation) rates as a function of exercise power output in a international-level professional endurance athletes, b. moderately active healthy individuals, and c. individuals with metabolic syndrome.** Image credit: ([Brooks and Millan, 2018](https://link.springer.com/article/10.1007%2Fs40279-017-0751-x))

> “A typical characteristic that we know of people with pre-type 2, or type 2 diabetes, is that they have a poor metabolic flexibility that is also a poor capacity to oxidize fuels. One of them is fat. We know that fat can only be oxidized in the mitochondria. Therefore, by measuring the fat oxidation of these patients, we can indirectly see the mitochondrial function, especially when we put them in context or in comparison with those ones who are healthy individuals.”  – Iñigo San Millán, Ph.D.

- The paper [essentially] proposes a functional definition of FatOx threshold capacity for the different study groups
- Zone 2 threshold becomes a way to assess mitochondrial function, thereby providing opportunity to clinically assess a patient and better understand their health

## Assessing mitochondrial function by looking at one’s ability to utilize fat as fuel (with an RQ test) [55:00]

***Using baseline respiratory quotient (RQ)***

- [RQ](https://en.wikipedia.org/wiki/Respiratory_quotient) is the ratio of produced carbon dioxide to consumed oxygen – measured with blood
- Another measure of the metabolic fuel the body uses is  the [respiratory exchange ratio (RER)](https://en.wikipedia.org/wiki/Respiratory_exchange_ratio) – measured with breath
- At rest, normal metabolism does not produce a lot of CO2 so the ratio remains below ~0.7 (CO2 divided by oxygen)
- Ratio is dependent on FatOx at the time of measure

***FATox rate during exercise provide an indirect method to assess metabolic flexibility and oxidative capacity across individuals of  different metabolic capabilities***

- The recent study assessing metabolic flexibility in the three populations measured RER to determine how much fat was oxidized under a given exertion of effort
- FATox ability was significantly higher in professional athletes compared to patients with metabolic syndrome
- When 100% of the fuel source is glucose (marked by RER of 1.00) the individual is in zone 4
  - Not oxidizing any fatty acid as a fuel source
  - High RER at a low workload (or at rest) is a red flag for mitochondrial dysfunction
- FATox negatively correlates with blood lactate (less lactate produced at lower energy outputs, when fatty acids are predominantly utilized as the cellular fuel source)
- As exercise intensity increases, our ability to oxidize fat efficiently decreases and we rely more on glucose
- People who are not metabolically flexible, rely on glucose earlier on in this process
- Metabolically sick people may have an RQ 0.9+ *while at rest*
  - *RQ of 1.0 means burning 100% glucose (Zone 4)*
- As a cardiologist would use an [electrocardiogram (EKG)](https://en.wikipedia.org/wiki/Electrocardiography) to evaluate cardiac function at rest vs. under stress, the study takes the same approach by measuring FATox

> “We want to see the same thing that is done usually at the EKG level. So when a cardiologist wants to study the heart, if there’s any abnormality, resting EKG has a reliability of about 50%. So you could see some red flags already, but you don’t see everything…And you stress the heart and similar protocol than what we did here, and that’s what do you do when you EKG in stress, right? Situations derail abilities are by 95%, 97%. So you see a lot of things. So I decided to take the same approach and say, okay, now at rest, as you very well said, you see people in the 90s with RQ, and that’s a red flag. Now, okay, let’s trace those mitochondria.” – Iñigo San Millán, Ph.D.

## Athletes vs. metabolically ill patients—mitochondria, fat oxidation, muscle glycogen capacity, “fat droplets”, and more [1:00:00]

> “You can categorize people by looking at the fat and also looking at the lactate. If you burn very little fat, that means that you don’t have a good mitochondrial function. . .If you produce a lot of lactate, that means that you don’t have a good mitochondrial function either, because lactate is metabolized in the mitochondria.” – Iñigo  San Millán, Ph.D.

- People with metabolic syndrome (MtS) – such as type 2 diabetes – often have coupled pre-type 2 cardiovascular disease
- [Cardiometabolic Disease](https://www.acc.org/tools-and-practice-support/quality-programs/cardiometabolic-health-alliance) represents a coupling of different risk markers
- 80% of people with diabetes have cardiovascular disease and vice versa

In Iñigo’s [2018 study](https://www.ncbi.nlm.nih.gov/pubmed/28623613), he found there to be a strong correlation between the lactate curve and the fat burning curve which tells him that it’s a valid indirect test to see the mitochondria function

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-9-inigo-707x1024.png)

**Figure 9.** **In the study, the RER, measuring FATox, and corresponding blood lactate at workload, was found in professional athletes (PA), moderately active individuals (MA), and patients with metabolic syndrome (MtS).** Credit: ([Brooks and Millan, 2018](https://www.ncbi.nlm.nih.gov/pubmed/28623613))

***Iñigo will next repeat the tests with the addition of muscle biopsies***

- [Metabolomics](https://en.wikipedia.org/wiki/Metabolomics) provide insight into:
  - Mitochondrial density
  - Cellular respiration
  - Genomics and proteomics, as well as metabolomics
- Muscle biopsy will reveal the mechanisms of what is going wrong in MtS patient metabolism
- The current study indirectly reveals that something is wrong, but the exact mechanism is yet unknown
- There are no other ways to look at mitochondrial function (aside from non-invasive zone 2 test measuring ATP to lactate via blood lactate level)
- With biopsy, he can expose the (muscle) tissue different fuel sources: glucose, pyruvate, fatty acids to observe metabolism

***Studying mitochondrial function in skeletal muscle …***

- Skeletal muscle is probably the first tissue where diabetes starts
- About 80% of all the glucose or carbohydrates that we oxidize in the body after a meal is in skeletal muscle
- And within the skeletal muscle is the mitochondria ⇒ So that’s why looking at the mitochondrial skeletal muscle gives us a very good ability to describe the metabolic mechanism in a more precise way

⇒ Mitochondria in well-trained athletes:

- Have 3x-4x the amount of mitochondria and each mitochondrion is larger, compared to the normal individual
- A [study](https://diabetes.diabetesjournals.org/content/57/4/987.figures-only) by [Dr. Frederico Toledo](https://profiles.dom.pitt.edu/faculty_info.aspx/Toledo5170) reveals size and density
- Zone 2 stimulates different pathways for mitochondrial biogenesis as well as improves the efficiency of the mitochondria

***Iñigo hypothesizes that the mitochondria function determine performance (and potential improvements)***

- Best treatment is *zone 2 training* to adapt and improve mitochondrial function

> “What I have been seeing for 25 years, working with elite athletes, is that this [zone 2] is the exercise intensity where I see the biggest improvement in fat burning and the biggest improvement in lactic clearance capacity. Therefore, that means that the mitochondria is where you see the biggest improvement. We also see the biggest improvement in performance.” – Iñigo  San Millán, Ph.D.

- Elite athletes exercise at low intensities that would be high for anyone else as their mitochondrial density is so high and efficient (their recruitment of type 1 muscle fibers)
- Additionally, the cell efficiently reuses the lactate and keeps it confined to the muscle as fuel for adjacent fibers
- They generally produce more lactate and utilize it more efficiently as fuel in the cell
- MtS patients utilize more glucose for energy, which may be converted in the cytosol rather than in the mitochondria
- Favoring glucose is a phenotype of [metabolic reprogramming](https://www.ncbi.nlm.nih.gov/pubmed/29487204) seen in MtS patients
- Cannot synthesize fatty acids for energy purposes very efficiently so they rely on glucose at rest
- Normally, glucose at rest is oxidized in the mitochondria, but mitochondria don’t function well so cells rely on cytosolic production of ATP
- The  blood lactate levels in MtS patients at lower intensities implies that they predominantly rely on cytosolic ATP production, with intermediary pyruvate and lactate endpoint

***Energy storage capacity comparison between elite athletes and metabolic syndrome (MtS) patients***

*Fitter individuals can store more glycogen than MtS patients…*

- [John Hill](https://www.uchealth.org/provider/john-hill--do-family-medicine/) and Millán developed a [methodology](https://www.ncbi.nlm.nih.gov/pubmed/25295766) to indirectly and noninvasively look at glycogen content, using high-frequency ultrasound
- [David Nieman](https://www.linkedin.com/in/david-nieman-b661b219) – another researcher – saw correlations in his own [research](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4406335/), validating the system

- The fitter you are, the more glycogen you store
  - Less dependent on glycogen
  - However, it is the energy you need to mobilize quickly when required

*Both populations also have cellular intramuscular triglycerides (IMTGs)*

- As opposed to cellular glucose utilization, both elite athletes and individuals with metabolic disease have fat droplets ([IMTGs](https://en.wikipedia.org/wiki/Intramuscular_fat))
- Biopsy shows that fittest and least fit individuals have muscular fat
- IMTGs are highly related to cardiovascular disease and type 2 diabetes; insulin resistance
- Endurance-trained athletes – who possess a high oxidative capacity and enhanced insulin sensitivity – also have higher intramyocellular lipid (IMCL) content
- [The athletes’ paradox](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3804891/)

- Normal individuals (neither an elite athlete nor a patient with metabolic disease) don’t have IMTG reservoir
  - Iñigo does not yet understand why
  - Hypothesizes that under normal physiologic exertion day-to-day (not elite athlete) the mutation is not necessary
  - Fat droplets build up for MtS patients as a result of mitochondrial dysfunction whereby fatty acids build up outside of the mitochondria

***The difference between IMLDs in elites and MTs patients is flux***

- Under the most metabolically flexible and the least metabolically flexible conditions, there is the same pattern: higher free fatty acids. But it comes down to flux (utilization)
- Iñigo hypothesizes that diabetic individuals retain IMLDs that are not utilized
- Fatty acids cannot be transported into the mitochondria and they build up outside the mitochondria
- In diabetic blood test screening, there is high free fatty acid blood level
- Conversely, about 25%-35% of all the fat oxidation an elite athlete undergoes during exercise comes from the fat droplet reservoir: it is very active (high rate of flux)

> “So, what it was found that in people with type 2 diabetes, that fat is not active. In fact, it can produce ceramides and other pre-inflammatory mediators that are not only involved with insulin resistance, but maybe with cardiovascular disease or atherosclerosis. They cannot be oxidized in the mitochondria, so they build up outside.” – Iñigo  San Millán, Ph.D.

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-10-inigo-1024x596.png)

**Figure 10. Role of intramyocellular lipid (IMCL) during exercise and in obesity. This schematic depicts the fate of the major IMCL lipid species within the context of exercise and obesity. In obesity, because of lower energy demand, most fatty acid (FA) acyl CoA is partitioned to lipid droplet (LDs). FA CoA oversupply to mitochondria during low energetic demand results in incomplete β oxidation and reactive oxygen species (ROS) production. The size of the arrows represents the rate of flux. Ab, albumin.** Credit: ([Coen and Goodpaster, 2012](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4908975/))

## Physiologic characteristics of zone 3, zone 4, and the lactate threshold [1:20:00]

***Zone 3 transition to a glycolytic energy system to zone 4 lactic threshold***

- Energy demands exceed the mitochondria’s capacity to be the sole provider of ATP
- The cell becomes dependent on glycolysis in the cytosol
- Fat oxidation decreases as the primary fuel contributor as glycolysis increases
- Zone 4 is where we see [lactate threshold](https://www.trainingpeaks.com/blog/what-is-lactate-and-lactate-threshold/)
  - blood lactate levels which correspond to the metabolic event when it is not possible to maintain that given exercise intensity
  - RQ of 1.0 and zero fat oxidation
  - There is an inflection (jump) indicating a metabolic transition point where energy is glucose-dependent, converted in the cytosol (aerobic conditions)
  - Many lactate thresholds (e.g., functional threshold power in cycling **(FTP)**)

***Iñigo’s experiment investigates what happens to lactate at threshold power output***

> “The ability of humans to exercise depends on the ability to convert chemical energy or by chemical energy into mechanical energy. The mechanical energy is the end product, watts, but how do you get there?” – Iñigo  San Millán, Ph.D.

- Did a peak power output at the end of the maxima test in a group of elite cyclists
- For the next test, put the first group at 80% of peak power output, a second group at 75% – where they stayed for 20 minutes
- Saw that blood lactate increased as a function of time: watts are watts at a metabolic level
- Recreational athletes had the same pattern at lower power outputs so in this sense, power is not just power but related to heart rate and lactate

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-11-inigo-1024x683.png)

**Figure 11. A plot of lactate and heart rate against power.** Credit: [lactate.com](https://www.lactate.com/triathlon/lactate_curves_various.html)

- Heart rate is a physiologic parameter and responds to physiologic and metabolic stress
- When heart rate increases, lactate increases
- [Heart rate variability (HRV)](https://www.health.harvard.edu/blog/heart-rate-variability-new-way-track-well-2017112212789) indicates a lot

## Fueling exercise—dietary implications on glycolytic function [1:30:30]

**The importance of carbohydrates**

> “… I decided to try to develop a way to look at glycogen, because I would see that in maximal physiological states, many athletes who were fatigued were restricting carbohydrates. They had a very low maximal lactate levels and very low maximal heart rate.” – Iñigo  San Millán, Ph.D.

- Iñigo emphasizes the importance of carbohydrates (CHO) in athletics
- He observes that when an athlete is fatigued, tired, restricting carbohydrates in a maximal physiologic state, they have very low lactate levels and heart rate
- With fatigue (whether due to exhaustion and/or diet) power output decreases along with a decrease in lactate and heart rate
- Even though a normal athletes Fatox increases after one to two weeks of CHO restriction, their power output decreases

> “We see that the power output decreases at least 0.5 watts per kilogram, so about 30 or 40 watts. Also, we see that the maximum one heart rate decreases, and the maximum lactate decreases” – Iñigo  San Millán, Ph.D.

**Ketogenic diets**

- Peter observed in himself that when he was in ketosis, he could perform other than when he needed to sprint; he didn’t have glycolytic capacity
- Iñigo has never had an elite cyclist athlete adapt to be ketosis
  - (That said, he believes it may be possible to adapt given how many anecdotes are out there from people)
- Although ketosis may allow the body to be more metabolically flexible (with carbohydrate consumption) long term, elite athletes cannot afford to wait for adaptation (takes months to years)
- Iñigo sees that athletes that attempt ketogenic diets or carbohydrate restriction while training for an event fail
- Short term, rather than preserve protein under periods of nutrient deprivation (carbohydrate restriction for elite athletes), protein breakdown occurs
- Cyclists (even in endurance races) need a huge amount of carbohydrates because of the catabolic activity

> “…the thing that I haven’t seen that adaptations in elite athletes cannot afford it [waiting for ketogenic adaptations]. You mentioned that it takes months to get there. You don’t have months, because you get trapped in the races. Your performance is very poor. Your contract is going to be trashed. They’re not going to renew you, and you’re going to feel like crap… Every single athlete who has tried to go, whether you call it a ketogenic diet or a carbohydrate restriction while training in competing for an event, they fail.” – Iñigo  San Millán, Ph.D.

## Relationship between exercise and insulin sensitivity (and what we can learn from studying patients with type 1 diabetes) [1:46:30]

> “These athletes have the highest insulin sensitivity of any humans. There’s no insulin resistance, because first, we know very well that exercise increases insulin sensitivity, and they need it to utilize carbohydrates. Eating increases insulin sensitivity, as well, and the transporters” – Iñigo  San Millán, Ph.D.

- Elite athletes are very insulin sensitive
  - Exercise increases insulin sensitivity
  - They need to utilize carbohydrates; eating increases insulin sensitivity
- High mitochondrial efficiency
  - Increases insulin sensitivity
  - Increases [non-insulin dependent glucose uptake](https://www.ncbi.nlm.nih.gov/pubmed/9435517)
- There is no better way to stimulate glucose deposition into the muscle than via zone 2 training – clinically seen in type 1 diabete patients
- Working with [Team Novo Nordisk](https://www.teamnovonordisk.com/)
  - all of the professional cyclists are type 1 diabetics
  - Iñigo can study the metabolic effects of exercise
  - With his insights, he can provide a framework of recommendations for patients who exercise and have MtS

***Challenge of exercising with diabetes:***

- MtS patients are told to exercise but blood glucose alters with exercise
- Patients become hypoglycemic or hyperglycemic and need to correct with insulin but exercise response is variable
- As a result, many decide not to exercise

> “The problem is that they [MtS patients] go to exercise, and they become hypoglycemic or hyperglycemic, and they need to correct it…the hormonal system goes all over the map, and they go back to their doctors and they have no answers. So it’s the number one barrier that they find from exercise, and many decide not to exercise, because they can’t control their doses very well at home.” – Iñigo  San Millán, Ph.D.

***–****Understanding metabolic insulin usage rather than correcting with insulin*

- Exercise increases insulin sensitivity so a patient will not need as much
- Iñigo has observed that type 1 diabetics (via Novo Nordisk athletes) are
  - even more insulin sensitive
  - Have 25% higher glycogen content before the race
  - Have ~3x less carbohydrate requirement than non-diabetics
  - They likely have higher glycogen content because insulin drives glycogen synthesis

***–****Glucose uptake via non-insulin dependent pathways: A case for improving mitochondrial efficiency*

- High intensity exercise increases blood glucose because of hepatic glucose output ([gluconeogenesis](https://en.wikipedia.org/wiki/Gluconeogenesis))
- The professional team had very high levels of non-insulin dependent glucose uptake by the skeletal muscle
- Insulin initiates the cascade of events that translocate the transporters of insulin, called the [GLUT4s](https://en.wikipedia.org/wiki/GLUT4), to the surface of the muscle.
- The implied hope is that the more work on mitochondrial efficiency (via zone 2 training), the more non-insulin dependent pathways will be utilized

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-12-inigo-1024x550.png)

**Figure 12. Exercise-mediated insulin sensitization in muscle.** Image credit: [cell.com](https://www.cell.com/trends/endocrinology-metabolism/comments/S1043-2760(15)00025-9)

*Muscle contraction initiates GLUT4 transport and passive diffusion of glucose into the cell (without insulin)*

- [Erik Richter](https://nexs.ku.dk/english/staff/?pure=en/persons/94866) and [Laurie Goodyear](https://connects.catalyst.harvard.edu/Profiles/display/Person/25240) research how muscle contraction stimulates pathways to translocate GLUT4 transporters
  - Relates exercise, GLUT4, muscle glucose is stimulated by muscle contraction to translocate GLUT4 and other transporters to the surface
  - Research reveals an increase in muscle GLUT4 in trained individuals, which contributes to an increase in the responsiveness of muscle glucose uptake to insulin

*-Cooldown period after exercise to calibrate blood glucose*

- Along with the [Juvenile Diabetes Research Foundation (JDRF)](https://www.jdrf.org/)**,** Iñigo studies hyperglycemia in diabetic athletes and develops management protocols
  - Train clinicians who treat diabetic patients
  - Suggested [cooldown protocol](https://www.typeonerun.org/s/lancetexercise.pdf) which has been successful in *not needing insulin to correct hyperglycemia post exercise*
- Diabetic people might experience hyperglycemia after a jog or a race because they’re not fit enough so they’re in zone 4 already, very glycolytic so they are seeing the post-exercise hyperglycemia

- Whereas zone 2 training decreases blood glucose, higher intensities increase blood glucose leading to hyperglycemia

- The hyperglycemia correction with insulin administration can result in hypoglycemia
- Iñigo recommends his athletes initiate a cooldown period after exercise

> “After [exercise] people would have these high post-exercise hyperglycemia, the muscle contraction stops. And that’s why I believe this is happening. First, you have a very high adrenergic activity, high intensity, a lot of adrenaline, and that’s what causes the breakdown of glycogen into glucose, as well as their glucose export from the liver..when exercise stops the muscle contraction – which initiates glucose reuptake – stops completely, resulting in hyperglycemia” – Iñigo  San Millán, Ph.D.

## Metformin’s impact on mitochondrial function, lactate production, and how this affects the benefits of exercise [2:04:15]

- Peter has long taken Metformin but realized about a year ago that his zone 2 resulted in high lactate levels
  - He refers to his observation in a blog post [here](https://peterattiamd.com/metformin-and-exercise/)
  - [Studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6351883/) have suggested that Metformin blunts the benefits of exercise
  - Supports that Metformin decreases mitochondrial function
- Although the mechanism is not clear, one side effect of Metformin is [lactic acidosis](https://en.wikipedia.org/wiki/Lactic_acidosis)
  - Could be because it increases glucose flux into the cell and saturates [pyruvate dehydrogenase](https://en.wikipedia.org/wiki/Pyruvate_dehydrogenase) such that it has a low [Michaelis Constant](https://en.wikipedia.org/wiki/Michaelis%E2%80%93Menten_kinetics) and more pyruvate is converted to lactate in the pathway
  - Could also be that mitochondrial decrease in overall function via inhibition of [Complex II](https://en.wikipedia.org/wiki/Electron_transport_chain#Complex_II)

> “It could be both. What we know epidemiologically speaking is that Metformin doesn’t cure diabetes. In the immense majority of patients, they end up using insulin down the road. So we know that Metformin is not that magical drug for type 1I diabetics. It just kind of gets them by. Tt buys them time, but eventually, the majority use insulin. If they don’t change their lifestyle, their nutrition, exercise…” – Iñigo  San Millán, Ph.D.

- High lactate levels, has been shown to push cells into [apoptosis](https://en.wikipedia.org/wiki/Apoptosis)
- Peter hypothesizes that the more healthy you are, the less helpful taking Metformin could be and could cease to be healthy

## Raising awareness for risk of “double diabetes” [2:15:00]

- Many people who have type 1 diabetes may also have type 1I
- 50% of U.S. adults have either diabetes or prediabetes (~40% is pre- type 2 diabetic)
- Type 1  and type 2 diabetes are very different metabolic diseases and require different treatment
  - One commonality is high blood glucose as a potential consequence
  - Novo Nordisk told Iñigo that about 75% of inulin sold in the US is for type 2 diabetics but not for type 1 diabetic treatment
  - Exercise for type 1I diabetes will eliminate insulin requirement
- Nutrition and exercise are the best ways to address diabetes risk

*Potential implication of taking statins on metabolic health*

- 5-10% of people experience [muscle symptoms](https://www.health.harvard.edu/heart-health/statin-side-effects-how-common-are-they) on statins
- Administration impacts mitochondrial function
- Increase possibility of becoming diabetic (~4% risk)

## How to dose zone 2 training, and balancing exercise with nutrition [2:18:00]

***What is the right dose of zone 2 exercise?***

- Two days a week of zone 2 exercise in elite athletes for many hours maintain fitness
- For diabetics, Iñigo thinks 3x a week for an hour at a time is enough to be beneficial
- He had a clinical case who *reversed late prediabetes with 90 minutes of exercise 4x a week*

***Inigo’s weight loss***

- After his cycling career, Inigo put on about 65 lbs
- He then dropped all the weight by implementing about 6 hours per week of zone 2 training
- He relied heavily on exercise, and less so on nutrition, to lose the weight
- For Inigo, he was not willing to make too many sacrifices to his diet other than eating a little less (his culture is around food, pasta, bread, chocolate, wine, etc.)
- Peter points out that Inigo’s training was not about calories, it was about “*training your mitochondria to become better at fuel partitioning*”

**It’s about fuel partitioning, not just calories**

- Many people think about burning calories when exercising
- A better way to think about it would be that you’re improving your body’s fuel partitioning
- Burning fat trains the cell to become better at fuel partitioning with positive implications for cellular longevity

***Zone 2 training for metabolic health and exercise adherence…***

- High intensity training burns a lot of calories but doesn’t burn fat to the same degree it is burned during zone 2 training
- In many cases, high intensity is “too hard”
  - Individuals that have not exercised in a long time push too hard
  - May decrease long term adherence/commitment

**Inigo on training above zone 2**:

“*Number one, you don’t burn much fat. You burn fat in the post exercise because you might increase your metabolic rate, but can that override the fat burning from the exercise itself?…*

*…And second, it’s too hard. You haven’t exercised in a long time to start with and you get into this high intensity programs. They may not suit you or they might injure you and many people give up…*

*…We see the rate of people giving up from gyms is about 50% or so within X amount of months. They either give up or their adherence decreases a lot.*”

**Nutrition**

- Exercise is important for MtS patients but nutrition is also critical
- Inigo emphasizes that a metabolically ill individual must do both exercise and nutrition and to find the right balance because you need both
- It’s like the 2 most important levers to pull, and finding your right balance is the key
- Peter adds that this is why he loves fasting, he calls his 7 days fasts once a quarter like his “sprint”

> “And to the point of the nutrition; the nutrition is a must. You need to do something with it or do a lot more exercise, but I think it’s the balance that we all, I think, need to understand better.”  – Iñigo San Millán, Ph.D.

## Proposed explanation of the Warburg Effect: Role of lactate in carcinogenesis [2:27:00]

- In type 2 diabetes, the mitochondria are not well-functioning
- There is an observed higher blood lactate, which is a commonality with cancer patients

***Historical theories of cancer cell metabolic behavior…***

- Cancer cells use glucose for energy  even in the presence of sufficient cellular oxygen
- [Warburg](https://en.wikipedia.org/wiki/Otto_Heinrich_Warburg) concluded that cancer is a metabolic disease caused by an injury of the cellular respiration system (i.e., mitochondria)
- [Meyerhof](https://en.wikipedia.org/wiki/Otto_Fritz_Meyerhof), under Warburg, discovered glycolysis which was measured prior to discovery via lactate produced by the cell
- Observed that cancer cells have a very high lactate production

***Three possible explanations for the role of lactate in cancer metabolism…***

- Dysfunctional mitochondria (Warburg)
- Glycolysis and lactate production is a byproduct of metabolic demand via rate of cell growth (put forth by [Craig Thomson](https://www.mskcc.org/research/ski/labs/craig-thompson)**,** [Lewis Cantley,](https://cantleylab.weill.cornell.edu/LabTeam) and [Mathew Vander Heiden](https://ki.mit.edu/people/faculty/vanderheiden) in their [2009 paper](https://www.ncbi.nlm.nih.gov/pubmed/19460998))
- Cancer relies on lactate as a signalling molecule (Millán and Brooks aforementioned [study](https://www.frontiersin.org/articles/10.3389/fonc.2019.01536/abstract) awaiting publication)

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-13-inigo-741x1024.jpeg)

**Figure 13. A ‘lactagenesis’ hypothesis to explain cancer metabolism. Effort from oncogenes and tumor suppressor mutations for continuous glucose utilization to produce lactate.** Image credit: ([San-Millan and Brooks, 2016](https://academic.oup.com/carcin/article/38/2/119/2709442))

***Summary of Iñigo’s recently approved study for publication …***

- Study looked at [MCF-7 cancer cell line](https://en.wikipedia.org/wiki/MCF-7)
- Exposed cells to four different treatment groups:
  - Medium with nothing (control)
  - Medium with glucose (replicating some original Warburg studies)
  - Medium with glucose + 10mm lactate
  - Medium with glucose + 20mm lactate
- Found that lactate is necessary in each of the major step in [carcinogenesis](https://en.wikipedia.org/wiki/Carcinogenesis)
- Lactate was observed to be a signalling molecule, overexpressing oncogene transcription factors between 2-8x v. control
- Without lacate,  mutated genes could not elicit the necessary growth and proliferation of studied breast cancer cell line
- Currently reproducing this study with the 2 main forms of lung cancer (non-small cell lung cancer and small-cell lung cancer) and we are seeing similar results

*In terms of Metformin administration …*

- Observational data that Metformin could lower cancer may be supported if the acidic environment becomes so toxic that the cell undergoes apoptosis

> “What we believe is that it’s a signaling molecule to really over-express the transcriptional activity of oncogenes, transcription factors and cell cycle genes in a nonhierarchical way because the traditional view of cancer is that you have the oncogenes, they tap on the transcription factors and they start an array of different downstream signaling that eventually transforms a normal cell into a cancer cell.” – Iñigo  San Millán, Ph.D.

## Doping in cycling, and the trend towards altitude training [2:39:15]

> “It’s hard to see any of today’s cyclist being at the top 20 best times now as they did before. So that’s something that shows that, yeah, cycling, thank goodness, is a very clean sport right now.” – Iñigo San-Millan, Ph.D.

- Cyclists now want to do well and they train at altitude, which did not happen in the past
- Altitude training is a way to increase oxygen carrying capacity

***“Live high, train low”…***

- At altitude, glycolytic capacity deteriorates with high exercise intensity
- For cyclists, this is a problem
- Ideal scenario is to find a balance in exercise type and effort output (difficult in high altitude environment)
- Iñigo will construct a hyperoxic environment room, simulating sea level conditions in high altitude environment (Boulder, Colorado training facility)
  - Allowing athletes to do high intensity efforts with a lower perceived effort, at altitude
  - Athletes living at altitude who do high intensity exercise tend to become overtrained
  - They have high oxygen carrying capacity but poor glycolytic capacity

*On the physical prowess of Miguel Indurain…*

- Iñigo did an internship with [Miguel Indurain’s](https://en.wikipedia.org/wiki/Miguel_Indur%C3%A1in) physiologist
  - He notably sweat a lot – had an amazing capacity to dissipate heat
  - Sweating a lot is indicative of a mature, efficient physiology
  - Metabolic flexibility marked by sodium retention even with high sweat output

> “He was calm. He was relaxed, he was super intelligent. He could read the game ahead of things. He would never get nervous about anything and he would never doubt about anything which is rare in athletes. I’ve seen athletes getting to the top of the game and falling apart and start crying. There’s the fear to lose, but also the fear to win because when you win, your life changes for the good or for the bad.” – Iñigo San Millán, Ph.D.

**Book recommendation from Inigo**:

- Iñigo notes the confidence and mental fortitude of [Greg LeMond](https://en.wikipedia.org/wiki/Greg_LeMond) and recommend his [book](https://www.amazon.com/Greg-lemonds-complete-bicycling-Perigee/dp/0399515941)
- He says “*it’s the best cycling book I’ve ever read in my life and it’s about how he trained and how he ate and the way he approached cycling*”

§

## Selected Links / Related Material

**Peter refers to aerobic and anaerobic energy systems in a previous blog post**: [The interplay of exercise and ketosis – Part II](https://peterattiamd.com/the-interplay-of-exercise-and-ketosis-part-ii/) by Peter Attia | (peterattiamd.com) [20:45]

**A book Peter recommends**: [Endure](https://www.amazon.com/Endure-Curiously-Elastic-Limits-Performance/dp/0062499866) by Alex Hutchinson | (amazon.com) [39:45]

**On zone 2 training**: [Zone 2 Training For Endurance Athletes](https://www.trainingpeaks.com/blog/zone-2-training-for-endurance-athletes/) by  Iñigo San Millán | (trainingpeaks.com) [40:00; 1:46:45]

**Iñigo’s presentation on cellular metabolism and application**: [Sports Performance testing in the Cyclist: where are we in 2015 and how does it apply to the recreational athlete?](https://www.ucdenver.edu/academics/colleges/medicine/sportsmed/cusm_events/2014SportsMedSymp/Documents/2015/Sports%20Performance%20testing%20in%20the%20Cyclist%20-%20San%20Millan.pdf) by  Iñigo San Millán | (ucdenver.edu) [41:15]

**Research on lactate**: [28:45; 34:30; 1:01:00; 2:30:00]

- On lactate shuttle theory: [The Science and Translation of Lactate Shuttle Theory](https://www.cell.com/cell-metabolism/pdf/S1550-4131(18)30186-4.pdf) (Brooks, 2018)
- Traumatic brain injury patients at UCLA (TBI) suggests that lactate can be used in rehabilitation: [Lactate: Brain Fuel in Human Traumatic Brain Injury: A Comparison with Normal Healthy Control Subjects](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4530406/) (Glenn et al., 2015)
- Lactate stimulates the expression of the major oncogene transcription factors in breast cancer cell cycle genes: [Is Lactate an Oncometabolite? Evidence Supporting a Role for Lactate in the Regulation of Transcriptional Activity of Cancer-related Genes in MCF7 Breast Cancer Cells](https://www.frontiersin.org/articles/10.3389/fonc.2019.01536/abstract) (San Millán et al., 2019)
- Glycolysis and lactate production is a byproduct of cell growth metabolic demand: [Understanding the Warburg effect: the metabolic requirements of cell proliferation](https://www.ncbi.nlm.nih.gov/pubmed/19460998) (Vander Heiden, Cantley, and Thompson, 2009)

**Energy system approach proposed by Dr. Andrew Coggan**: [FTP-based (functional power threshold) energy system](https://www.trainingpeaks.com/blog/power-training-levels/) by Dr. Andrew Coggan | (trainingpeaks.com)[26:00]

**Metabolic flexibility and mitochondrial function in three study groups**: [Assessment of Metabolic Flexibility by Means of Measuring Blood Lactate, Fat, and Carbohydrate Oxidation Responses to Exercise in Professional Endurance Athletes and Less-Fit Individuals](https://www.ncbi.nlm.nih.gov/pubmed/28623613) (San Millán and Brooks, 2018) | [56:30]

**On mitochondrial size and density**: [Mitochondrial Capacity in Skeletal Muscle Is Not Stimulated by Weight Loss Despite Increases in Insulin Action and Decreases in Intramyocellular Lipid Content](https://diabetes.diabetesjournals.org/content/57/4/987.figures-only) (Toledo et al., 2008) | [1:07:15]

**Assessing muscle glycogen content via ultrasound** [1:10:30]:

- Proposed methodology: [Validation of musculoskeletal ultrasound to assess and quantify muscle glycogen content. A novel approach](https://www.ncbi.nlm.nih.gov/pubmed/25295766) (Hill and Millán, 2014)
- Methodology validation: [Ultrasonic assessment of exercise-induced change in skeletal muscle glycogen content](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4406335/) (Nieman et al., 2015)

**Both MtS patients and elite athlete store intramuscular triglycerides**: [Exercise-induced alterations in intramyocellular lipids and insulin resistance: the athlete’s paradox revisited](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3804891/) (Dubé et a., 2015) | [1:15:00]

**Professional team where all cyclists are type 1 diabetics**: [Team Novo Nordisk](https://www.teamnovonordisk.com/)  | (teamnovonordisk.com)[1:48:00]

**Organization that leads research on type 1 diabetes**: [Juvenile Diabetes Research Foundation (JDRF)](https://www.jdrf.org/) | (jdrf.org) [1:50:30]

**Peter writes how he has observed impact of taking Metformin on his zone 2 lactate levels**: [Metformin and exercise](https://peterattiamd.com/metformin-and-exercise/) by Peter Attia | (peterattiamd.com) [2:06:45]

**Metformin demonstrated to blunt the benefits of exercise**: [Metformin inhibits mitochondrial adaptations to aerobic exercise training in older adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6351883/) (Konopka et al., 2019) | [2:06:45]

**Iñigo recommends Greg LeMond’s book**: [Greg lemond’s complete book of bicycling](https://www.amazon.com/Greg-lemonds-complete-bicycling-Perigee/dp/0399515941) by Greg LeMond | (amazon.com) [2:47:00]

§

## People Mentioned

- [Meb Keflezighi](https://en.wikipedia.org/wiki/Meb_Keflezighi) (elite marathon runner) | (wikipedia.org)[29:30]
- [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) (former professional road racing cyclist) | (wikipedia.org) [32:00]
- [George Brooks](https://ib.berkeley.edu/people/faculty/brooksg) (University of California Berkeley professor; lactate shuttle theory; lactate use in injury treatment)| (ib.berkeley.edu) [21:00; 28:45; 34:30; 44:30]
- [Dr. Andy Coggan](https://legacy.usacycling.org/coggan-bio.htm) (exercise physiologist USA cycling) | (usacycling.org) [26:00]
- [Alex Hutchinson](https://alexhutchinson.net/) (journalist; book author) [39:45]
- [Dr. Frederico Toledo](https://profiles.dom.pitt.edu/faculty_info.aspx/Toledo5170) (professor and director of clinical research, Center for Metabolic and Mitochondrial Medicine) [1:07:15]
- [Joel Friel](https://joefrielsblog.com/) (endurance sport coach) [1:30:00]
- [John Hill](https://www.uchealth.org/provider/john-hill--do-family-medicine/) (doctor in family and sports medicine; colleague of San Millán) [1:10:30]
- [David Nieman](https://www.linkedin.com/in/david-nieman-b661b219) (Professor at Appalachian State University) [1:10:30]
- [Erik Richter](https://nexs.ku.dk/english/staff/?pure=en/persons/94866) (Professor of molecular physiology at the University of Copenhagen) [1:57:15]
- [Laurie Goodyear](https://connects.catalyst.harvard.edu/Profiles/display/Person/25240) (Professor of Medicine, Joslin Diabetes Center) [1:57:15]
- [Otto Heinrich Warburg](https://en.wikipedia.org/wiki/Otto_Heinrich_Warburg) ( German physiologist, medical doctor, and Nobel laureate) [2:27:45]
- [Otto Fritz Meyerhof](https://en.wikipedia.org/wiki/Otto_Fritz_Meyerhof) (German physician and biochemist who won the Nobel Prize in Physiology and Medicine) [2:27:45]
- [Craig Thomson](https://www.mskcc.org/research/ski/labs/craig-thompson) (President and CEO, Memorial Sloan Kettering Cancer Center) [2:30:00]
- [Lewis Cantley](https://cantleylab.weill.cornell.edu/LabTeam)  (Professor of Cancer Biology in Medicine) [2:30:00]
- [Mathew Vander Heiden](https://ki.mit.edu/people/faculty/vanderheiden) (Associate Professor of Biology; oncologist) [2:30:00]
- [Miguel Indurain](https://en.wikipedia.org/wiki/Miguel_Indur%C3%A1in) (retired road racing cyclist) [2:44:00]
- [Greg LeMond](https://en.wikipedia.org/wiki/Greg_LeMond) (former professional road racing cyclist) [2:47:00]

§

![](https://peterattiamd.com/wp-content/uploads/2019/12/bio-image-inigo-500x500.jpg)

##### Iñigo San Millán, Ph.D.

Iñigo San Millán, Ph.D. is an Assistant Professor at the [University of Colorado School of Medicine](https://www.ucdenver.edu/academics/colleges/medicine/sportsmed/cusm_physicians/Pages/sanmillan.aspx), where his areas of research, clinical work, and interests include exercise metabolism, nutrition, sports performance, overtraining, diabetes, cancer, and critical care.  He’s internationally renowned applied physiologist having worked for the past 20 years for many professional teams and elite athletes worldwide across multiple sports like running, football, soccer, basketball, rowing, triathlon, swimming, Olympics and cycling, including eight Pro Cycling Teams. Iñigo has also been a consultant in exercise physiology and sports medicine to international organizations like the US Olympic Committee and the International Cycling Union. He has been a pioneer in developing new methodologies for monitoring athletes at the metabolic and physiological level including a novel method to measure mitochondrial function and metabolic flexibility as well as the invention of the first method to measure skeletal muscle glycogen in a non-invasive way using high frequency ultrasound. Previously, Inigo was a competitive athlete and played soccer for 6 years for Real Madrid soccer academy team as well as raced as a professional cyclist for 2 years. He also returns to Spain every summer to run with the bulls. [[ucdenver.edu](https://www.ucdenver.edu/academics/colleges/medicine/sportsmed/cusm_physicians/Pages/sanmillan.aspx)]

Twitter: [@doctorinigo](https://twitter.com/doctorinigo?lang=en)