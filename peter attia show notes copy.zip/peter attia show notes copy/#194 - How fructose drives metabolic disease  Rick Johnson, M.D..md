# #194 – How fructose drives metabolic disease | Rick Johnson, M.D.

**Source:** [https://peterattiamd.com/rickjohnson2/](https://peterattiamd.com/rickjohnson2/)

---

##### See more content from Rick Johnson, M.D.:

- - *(January 6, 2020)* [Metabolic Effects of Fructose with Rick Johnson, M.D. | Part I](/rickjohnson/)
  - *(February 6, 2022)* [How Fructose Drives Metabolic Disease with Rick Johnson, M.D. | Part II](rickjohnson2/)

Rick Johnson, Professor of Nephrology at the University of Colorado and a [previous guest](https://peterattiamd.com/rickjohnson/) on The Drive, returns for a follow-up about unique features of fructose metabolism, and how this system that aided the survival of human ancestors has become potentially hazardous based on our culture’s dietary norms. In this episode, Rick explains how the body can generate fructose from glucose and how circulating glucose and salt levels can activate this conversion. He discusses the decline in metabolic flexibility associated with aging, as well as how factors such as sugar intake or menopause-associated hormone changes can alter responses to sugar across a lifetime. In addition, Rick lays out strategies for combating the development of metabolic illness using dietary changes and pharmaceutical therapies, and he discusses the impact of fructose metabolism and uric acid on kidney function and blood pressure. He concludes with a discussion of vasopressin, a hormone that facilitates fructose’s effects on weight gain and insulin resistance.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/rickjohnson2/the_Drive_public.png)

Play

#194 - How fructose drives metabolic disease | Rick Johnson, M.D.

#194 - How fructose drives metabolic disease | Rick Johnson, M.D.

1x15s30s

0:002:05:28

## We discuss:

- Unique features of fructose metabolism and why it matters [2:45];
- A primer on fructose metabolism and uric acid [10:30];
- Endogenous fructose production, the polyol pathway, and the effect of non-fructose sugars [22:00];
- Findings from animal studies of glucose and fructose consumption [29:00];
- What calorie-controlled studies say about the claim that a “calorie is a calorie” [42:15];
- Implications for aging and disease [51:15];
- Impact of endogenous fructose production on obesity and metabolic syndrome [1:01:30];
- Why vulnerability to the negative effects of sugar increases with age and menopause [1:04:30];
- Dietary strategies to reduce the negative impact of fructose [1:16:30];
- The role of hypertension in chronic disease and tips for lowering blood pressure [1:30:45];
- The impact of fructose and uric acid on kidney function and blood pressure [1:39:45];
- The potential role of sodium in hypertension, obesity, and metabolic syndrome [1:49:00];
- The role of vasopressin in metabolic disease [1:54:00];
- More.

§

## Show Notes

## Unique features of fructose metabolism and why it matters [2:45]

- We had a lot of follow up questions from our first podcast, which aired 2 years ago
  - [#87 – Rick Johnson, M.D.: Metabolic Effects of Fructose](https://peterattiamd.com/rickjohnson/)
- The #1 question people ask is, “*Hey, can you explain again, why is it that fructose metabolism is kind of unique from a nutrient standpoint in terms of creating this transient intracellular energy deficit*.”
- All nutrients, any kind of food is used to produce energy or [ATP](https://en.wikipedia.org/wiki/Adenosine_triphosphate) but there is a cost to producing energy
  - Some energy is used  to digest foods and some energy is used to metabolize foods
  - The idea follows the old adage, “*you have to spend money to make money*”; here we are thinking about ATP
- Metabolism of **fructose** and **alcohol** can cause rapid ATP depletion
- In terms of nutrient metabolism, fructose is pretty unique
- The very first enzyme in fructose metabolism is called [fructokinase](https://en.wikipedia.org/wiki/Fructokinase) (see the figure below)
  - Fructokinase is also known as ketohexokinase or KHK
  - This is a key enzyme in fructose metabolism
  - It phosphorylates fructose at the 1 position to generate fructose-1-phosphate
  - This enzymes in *not* controlled by [negative feedback](https://en.wikipedia.org/wiki/Negative_feedback) so it will phosphorylate fructose as soon as it sees it
    - It is *not* responsive to ATP levels; so if ATP levels start to drop, fructose metabolism continues
  - This first step in fructose metabolism requires ATP expenditure, so consuming large amounts of fructose causes severe ATP depletion
  - Similarly, if the fructose concentration is very low, there won’t be as much ATP depletion
  - So the degree of ATP depletion varies with the concentration of fructose

![](https://peterattiamd.com/wp-content/uploads/2022/02/f1-rickjohnson2-1024x556.png)

**Figure 1. The first step of fructose metabolism leads to loss of ATP.** Image Credit: [*Nature Reviews Nephrology*](https://www.nature.com/articles/ncpneph0019)

- As ADP is produced by fructokinase, it will be used to make ATP and AMP (shown in the figure below)
  - [Adenylate kinases](https://en.wikipedia.org/wiki/Adenylate_kinase) convert ADP to ATP + AMP (and the reverse reaction)
- Under high energy conditions the cell has a ratio of ATP : ADP of 10:1 and a ratio of ATP : AMP of 100:1
  - The AMP : ATP ratio will rise as ADP is produced due to the action of adenylate kinases
  - During ATP depletion the change in concentration of AMP is much greater than that of ATP or ADP or even the ratio of ATP/ADP
  - See this review, [Keeping the home fires burning: AMP-activated protein kinase](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5805978/)

![](https://peterattiamd.com/wp-content/uploads/2022/02/f2-rickjohnson2-1024x298.png)

**Figure 2. As ADP  levels rise, ATP and AMP are produced**.  Image Credit: [Keeping the home fires burning: AMP-activated protein kinase](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5805978/)

**Why high fructose corn syrup is particularly bad**

- Fructose concentration relates to not just the amount of fructose, but how rapidly it’s absorbed
  - Liquid fructose (like a soft drink) consumed on an empty stomach, can get absorbed very quickly and even more quickly when it is high fructose corn syrup
  - There’s some debate on this, but in [high fructose corn syrup](https://en.wikipedia.org/wiki/High-fructose_corn_syrup), the fructose and glucose are already separated so that it may be absorbed differently than [sucrose](https://en.wikipedia.org/wiki/Sucrose) where it’s glucose and fructose bound together, but they are broken and they have to be degraded to the individual fructose and glucose in the gut before they’re absorbed
  - The figure below shows the relationship between structure of glucose, fructose, and sucrose

![](https://peterattiamd.com/wp-content/uploads/2022/02/f3-rickjohnson2-1024x338.png)

**Figure 3. Sucrose is 1 glucose bound to 1 fructose.**  Image credit: [Wikimedia Commons](https://commons.wikimedia.org/wiki/Category:Sucrose#/media/File:Formation_du_saccharose.PNG)

- Drinking liquid fructose leads to very fast absorption; the concentration will be higher when it reaches the liver
- The liver is one of the key sites of fructose metabolism that drives this whole process
- When fructose gets to the liver, fructokinase phosphorylates it, and the ATP levels acutely fall

**Cellular response to low ATP levels**

- The low ATP state is maintained primarily by a drop in intracellular phosphate that accompanies this and that activates this enzyme system that removes the breakdown of ATP products
  - These 2 reactions occur together (shown in the Figure 1)
    - ATP + H2O → ADP + Pi
    - Fructose → Fructose-1-Phosphate
  - With ADP and Pi removed, ATP cannot be regenerated easily (see Figure 2)
  - Normally AMP and ADP get reformed to make more ATP
    - 2 ADP → ATP + AMP
    - They’re really important to make the ATP
  - The ATP levels fall
  - There’s the accumulation of ADP and AMP ([adenosine monophosphate, AMP](https://en.wikipedia.org/wiki/Adenosine_monophosphate),  is one of the key ones) and then AMP is swept away
  - If the AMP is removed, then it’s hard to replenish the ATP because you’ve removed a key building block for ATP
    - AMP is removed by an enzyme called [AMP deaminase](https://en.wikipedia.org/wiki/AMP_deaminase), which turns out to be a very, very important enzyme in this pathway
- AMP deaminase breaks down the AMP stepwise until it produces **uric acid**, which is the end product of [purine metabolism](https://en.wikipedia.org/wiki/Purine_metabolism)
- The adenine of ATP is a purine, and it eventually gets broken down to [uric acid](https://en.wikipedia.org/wiki/Uric_acid)
- Uric acid inside the cell actually causes oxidative stress to the [mitochondria](https://en.wikipedia.org/wiki/Mitochondrion)
  - The mitochondria are also really important in ATP production
- The oxidative stress affects the mitochondria in several ways
  - 1) It inhibits an enzyme called [aconitase](https://en.wikipedia.org/wiki/Aconitase), which is involved in the [Krebs cycle](https://en.wikipedia.org/wiki/Citric_acid_cycle) and basically leads to citrate accumulation in the stimulation of fat production
  - 2) It also blocks an enzyme called [Enoyl-CoA hydratase](https://en.wikipedia.org/wiki/Enoyl-CoA_hydratase)
    - This enzyme is involved in [beta fatty acid oxidation](https://en.wikipedia.org/wiki/Beta_oxidation) (step #2); blocking this blocks the burning of fatty acids
  - Ultimately what happens is, it reduces the production of ATP
    - By blocking the Krebs cycle (this shunts these components to make fat)
    - And by blocking the burning of fat
    - See the review from 2018, [Fructose and sugar: A major mediator of non-alcoholic fatty liver disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5893377/)
- In all, fructose metabolism stimulates fat storage
- Uric acid also inhibits [AMP kinase (AMPK, AMP-activated protein kinase)](https://en.wikipedia.org/wiki/AMP-activated_protein_kinase); this blocks energy production

> “*It’s a brilliant system to set the energy levels down in a cell, and it mimics the condition of starvation*.” – Rick Johnson

- Reducing the energy in the cell triggers an alarm signal; it’s a survival pathway
  - This leads to a survival response, makes the animal get hungry, thirsty, forage for food, try to store fat, try to store [glycogen](https://en.wikipedia.org/wiki/Glycogen)

## A primer on fructose metabolism and uric acid [10:30]

- Fructose can be metabolized like glucose through some of the glucose enzymes but it prefers to be metabolized by fructokinase
  - Fructose has a higher affinity for fructokinase than glucose enzymes

**Tissues that express fructokinase**

- Normally fructokinase is present in modest amounts in the gut
- Fructokinase is also present in the liver, brain, islets of the pancreas, some in white fat, and a fair amount in the kidney
  - The islet of the pancreas is very important because that’s where [insulin](https://en.wikipedia.org/wiki/Insulin) and [glucagon](https://en.wikipedia.org/wiki/Glucagon) are produced

**Fructokinase expression is upregulated**

- Expression of fructokinase can be turned on whenever there is injury
  - For example, it can be induced in the heart following a heart attack
  - It can be produced in the kidney further or be activated further to have kidney failure, following damage to the kidney from a COVID infection
- Induced expression is probably trying to provide some “survival mechanisms” in these sites
  - But what happens is, it tends to be over activated and end up causing worse injury rather than protection from injury
- The main sites of fructokinase expression are the liver, the brain, the islets, the kidney, and the intestine

**Fructokinase action in the liver causes energy depletion**

- Fructokinase seems to cause energy depletion in all those sites except the intestine
- Work done by [Dr. Joshua Rabinowitz](https://chemistry.princeton.edu/faculty/joshua-rabinowitz) from Princeton has shown that the fructokinase in the gut, when there’s just small amounts of fructose, it actually tends to not cause the energy depletion and to actually convert the fructose to glucose
  - Fructose can be converted to glucose and glucose can be converted to fructose
  - At high concentrations of fructose, energy depletion probably occurs

> “*The intestine tends to be a shield that at low concentrations just helps remove the fructose without it being a problem*” – Rick Johnson

- The action of fructokinase in the intestine is one reason why fruits and vegetables don’t cause energy depletion
  - Fruits have 4 grams of fructose
  - Vegetables have small amounts of fructose, 2-5 grams
  - Intestinal fructokinase seems to inactivate small amounts of fructose
  - Published in *Cell Metabolism* in 2018, [The Small Intestine Converts Dietary Fructose into Glucose and Organic Acids](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6032988/)
- If a large amount of fructose is consumed, it gets through the intestine
  - It probably causes ATP injury to the intestine
  - Rick has done some studies to show it causes gut leak
    - Discussed in this review from 2018, [Fructose and sugar: A major mediator of non-alcoholic fatty liver disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5893377/)
    - It may be responsible for  anaphylaxis to certain foods (food allergies)
- Most fructose is metabolized in the liver and the liver seems to be the primary place that drives the metabolic syndrome and obesity and diabetes
  - Study comparing fructokinase action in the intestine versus liver, published in *Cell Metabolism* in 2020, [Deletion of Fructokinase in the Liver or in the Intestine Reveals Differential Effects on Sugar-Induced Metabolic Dysfunction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7347444/)
  - If he knocks out fructokinase just in the liver, he can protect animals from obesity and diabetes and high blood pressure
- The liver is the king when it comes to metabolic syndrome
- The kidney’s actually important for kidney disease
- The brain is really important for diseases like Alzheimer’s and so forth; he’ll come back to his

> “*Fructose turns out to have been meant to be this wonderful system for survival, but in our culture with the amount of sugar in foods that we are eating (that either provide sugar or can be turned into fructose), this pathway has become hazardous*” – Rick Johnson

- Peter goes back to step #1, fructose is eaten, it goes through the stomach, into the [duodenum](https://en.wikipedia.org/wiki/Duodenum) and into the proximal part of what’s called the [jejunum](https://en.wikipedia.org/wiki/Jejunum)
  - [Epithelial cells](https://en.wikipedia.org/wiki/Epithelium) line the gut
- Low doses of fructose (from eating a piece of fruit or some vegetables) can be absorbed in the gut without creating an ATP deficit
- Higher concentrations of fructose cause a problem; they get through the gut without being metabolized
  - Fructose enters the portal system
  - The reason it preferentially makes its way to the liver is due to the venous system that drains the gut
    - Where the [superior mesenteric vein](https://en.wikipedia.org/wiki/Superior_mesenteric_vein) and [inferior mesenteric vein](https://en.wikipedia.org/wiki/Inferior_mesenteric_vein) join the [splenic vein](https://en.wikipedia.org/wiki/Splenic_vein), these things become the [portal vein](https://en.wikipedia.org/wiki/Portal_vein) and that becomes an inflowing conduit to the liver
- The liver has 2 incoming blood supplies:
  - 1) The arterial supply, which supplies oxygen
  - 2) The venous supply, which supplies nutrients on first pass from the gut
  - This is why the liver plays such an important role in metabolism
- Fructose that gets through the gut, goes to the liver where it is phosphorylated by fructokinase
  - By definition, this is a high fructose state because the gut’s capacity to metabolize fructose has been exceeded
  - Now there is unlimited conversion of fructose to fructose-1-phosphate
    - The reaction catalyzed by fructokinase: fructose + ATP → fructose-1-phosphate + ADP + Pi
    - The cell is generating lots of ADP
    - This reaction requires ATP
- ATP has 3 phosphate groups (see the image below)

![](https://peterattiamd.com/wp-content/uploads/2022/02/f4-rickjohnson2-1024x823.png)

**Figure 4. Related structures of ATP, ADP, and AMP.**  Image Credit: [Wikimedia Commons](https://www.google.com/imgres?imgurl=https%3A%2F%2Fupload.wikimedia.org%2Fwikipedia%2Fcommons%2F7%2F7e%2F230_Structure_of_Adenosine_Triphosphate_%2528ATP%2529-01.jpg&imgrefurl=https%3A%2F%2Fcommons.wikimedia.org%2Fwiki%2FFile%3A230_Structure_of_Adenosine_Triphosphate_(ATP)-01.jpg&tbnid=WKsJawGRsfHgoM&vet=12ahUKEwj-rYONn5b1AhWL11MKHfE6CgUQMygOegUIARDuAQ..i&docid=Gtli6V1BYlFGIM&w=1402&h=1223&q=adenosine%20triphosphate&ved=2ahUKEwj-rYONn5b1AhWL11MKHfE6CgUQMygOegUIARDuAQ)

- When 1 phosphate is removed this leaves [ADP (adenosine diphosphate)](https://en.wikipedia.org/wiki/Adenosine_diphosphate)
- ADP further gives up a phosphate, becoming [AMP (adenosine monophosphate)](https://en.wikipedia.org/wiki/Adenosine_monophosphate)
- The ADP and AMP are being shunted elsewhere in the further degradation of their [adenosine](https://en.wikipedia.org/wiki/Adenosine) component; and that’s being turned into [uric acid](https://en.wikipedia.org/wiki/Uric_acid) (as shown in the figure below)
  - Uric acid being the final breakdown product of adenosine

![](https://peterattiamd.com/wp-content/uploads/2022/02/f5-rickjohnson2-1024x369.png)

**Figure 5.  Metabolism of fructose lowers ATP and produces uric acid.** Image credit: [*Obesity* 2019](https://pubmed.ncbi.nlm.nih.gov/31054268/)

- 2 things occur when adenosine is broken down
  - 1) The base (adenosine) is removed that could be rephosphorylated to repopulate ATP
  - 2) Uric acid goes on to be metabolized into other molecules that both increase the substrate for *de novo* lipogenesis (in the form of citrate) and also create other molecules that inhibit the process of [beta oxidation](https://en.wikipedia.org/wiki/Beta_oxidation) (which is the process by which we break down fatty acids to make ATP)
- Rick clarifies that uric acid doesn’t break down but causes [oxidative stress](https://en.wikipedia.org/wiki/Oxidative_stress) in the mitochondria by stimulating [NADPH oxidase](https://en.wikipedia.org/wiki/NADPH_oxidase) (this enzymes produces [reactive oxygen species](https://en.wikipedia.org/wiki/Reactive_oxygen_species) that cause oxidative stress)
  - NADPH oxidase actually translocates into the mitochondria
  - The oxidative stress NADPH oxidase causes inhibits different enzymes that lead to fat synthesis and block fatty acid oxidation
- Uric acid accumulates in the cell, it can be measured, and it turns on these processes that seem to drive this whole mechanism
- There are 2 pathways for fructose metabolism, shown in the figure above
  - 1) In the caloric pathway, fructose gets metabolized to CO2 and water
    - This is similar to glucose metabolism except ATP degradation is not considered a caloric pathway
  - 2) In the non-caloric pathway, metabolism of fructose activates a side reaction producing uric acid
  - This metabolic process leads to the development of diabetes, obesity, and hypertension
- The calories from glucose are not activating these diseases
  - It’s the fact that fructose lowers the energy (ATP) in the cell and keeps energy levels low
    - This is due to this runaway, renegade enzyme fructokinase that just takes all the ATP again to phosphorylate as much fructose as it can

**Evolutionary purpose for downstream effects of fructokinase**

- Peter puts this in evolutionary perspective— in a food scarce environment, fructokinase is not telling the organism to stop eating; there is no signal that the cell has enough energy
  - The opposite occurs, as more fructose is eaten, more is wanted
  - It turns off the ability to oxidize fat and turns on the ability to store fat and make more fat from fructose metabolism
  - This is an amazing adaptation
- Rick notes this is a fundamental mechanism developed in nature; it’s a process so key for survival that all animals use it
  - Discussed further in [Fructose metabolism as a common evolutionary pathway of survival associated with climate change, food shortage and droughts](https://pubmed.ncbi.nlm.nih.gov/31621967/), published in the *Journal of Internal Medicine* in 2020
  - The figure below summarizes how fructose metabolism provides survival functions but in excess contributes to disease

![](https://peterattiamd.com/wp-content/uploads/2022/02/f6-rickjohnson2-1024x590.png)

**Figure 6.  Role of fructose metabolism in survival and disease.**  Image credit: [*Journal of Internal Medicine* 2020](https://pubmed.ncbi.nlm.nih.gov/31621967/)

## Endogenous fructose production, the polyol pathway, and the effect of non-fructose sugars [22:00]

- One of the breakthroughs was the discovery that it’s not just the fructose we eat, but that the body can make fructose
  - And when the body makes enough fructose, it can activate this pathway
- When he first began studying this he thought the solution would be a low fructose diet
  - And maybe this is how low carb diets work, because they are also low in fructose
  - He wrote the book, [*The Sugar Fix*](https://www.amazon.com/Sugar-Fix-High-Fructose-Fallout-Making/dp/1594866651/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) back in 2008 about this

> “*But the problem is that the body can make fructose. And it turns out that the favorite way it makes fructose is through high glucose levels*.” – Rick Johnson

- Classic diabetes is a high glucose state
- It’s been known for decades that there’s the enzyme that gets turned on in high glucose states called the [polyol pathway](https://en.wikipedia.org/wiki/Polyol_pathway) (shown in the figure below) and that enzyme can convert glucose to sorbitol, and sorbitol then gets converted to fructose
  - BTW, sorbitol is considered an artificial sugar so be aware that it gets turned into fructose in the body (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/02/f7-rickjohnson2-1024x399.png)

**Figure 7. The polyol metabolic pathway.**  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Polyol_pathway)

- In the polyol pathway, glucose is converted to fructose in a 2-step process
- Rick notes that he was always thinking about high plasma glucose conditions but realized the plasma was not as important as the liver
  - It’s what’s going on in the liver that’s so important
- When we eat carbs, we generate glucose
- When someone eats broccoli, they’re going to generate some glucose because this is a vegetable that has carbohydrates in it; but it doesn’t produce a lot of glucose
  - The glucose concentrations in the liver and blood don’t go up with broccoli
- When someone eats bread, rice, potatoes, chips, cereals (or other high glycemic foods), this gets broken down to glucose in the gut
  - Starch gets broken down to glucose in the gut
  - A continuous glucose monitor will show a rise in blood glucose after eating these foods
  - Glucose will also go up in the liver
  - We don’t know what the difference is in the portal vein
    - These studies have not been done, but that would be very helpful
    - There is something called the first-pass effect; for nutrients that go to the liver, some are used by the liver first before it gets into the blood
    - So a lot of the glucose that enters the liver  is quickly sequestered in the liver cells and metabolized, and then some of it passes through to the blood
  - Glucose in the blood is like the tip of the iceberg; the glucose levels in the liver are likely higher
- Bread is going to be much more fattening if the enzyme [aldose reductase](https://en.wikipedia.org/wiki/Aldose_reductase) is elevelated in the liver
  - Rick would love to develop an assay to measure aldose reductase in peripheral blood
    - It’s expressed in the liver but it can be measured in the plasma
    - Sorbitol is a good marker showing activation of this pathway [the polyol pathway, shown in the previous figure]
- Aldose reductase is the rate limiting enzyme that converts glucose to sorbitol
  - It’s normally present in low levels in the liver, but it gets induced
  - It can be induced by high glucose or high uric acid
  - There’s a *positive feedback system* because when fructose is metabolized, uric acid is generated; and uric acid then goes back and tries to turn on the enzymes that can lead to more fructose metabolism
- The action of high glucose levels activating aldose reductase has been shown in humans as well as in animals as well as in cell culture
  - This is the basis for original concerns about the polyol pathway being important in diabetic complication
  - This has been known for 50 years
- Rick has published the observation that uric acid is a stimulus for aldose reductase, observed in animal studies and cell culture
  - Published in the *Journal of Biological Chemistry* in 2019, [Uric acid activates aldose reductase and the polyol pathway for endogenous fructose and fat production causing development of fatty liver in rats](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6422088/)
  - Published in *PLoS One* in 2012, [Uric acid stimulates fructokinase and accelerates fructose metabolism in the development of fatty liver](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0047948)
  - This has not been shown in humans yet, but he believes it is likely true of humans too
- Uric acid becomes clinically relevant and might turn on the polyol pathway at levels over 7 mg/dL in a human
  - This is what is seen in metabolic syndrome

## Findings from animal studies of glucose and fructose consumption [29:00]

**Obesity and insulin resistance**

- Rick thought that giving glucose to animals would not cause obesity because glucose would maintain ATP levels (a deficit of ATP would not occur)
- Fructose is activating this metabolic syndrome through dropping ATP levels
- When he did the experiment, and gave mice glucose, over time they became very very fat and insulin resistant
  - Mice were given glucose in drinking water; their water was 10% glucose
  - Control mice received plain water
  - Both groups had access to the same chow
    - Published in *Nature Communications* in 2013, [Endogenous fructose production and metabolism in the liver contributes to the development of metabolic syndrome](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3833672/)
  - They also used a control where animals received water with [Splenda](https://en.wikipedia.org/wiki/Splenda) in it, this tastes sweet but contains no calories
    - Published in the *American Journal of Physiology Endocrinology and Metabolism* in 2020, [Sugar causes obesity and metabolic syndrome in mice independently of sweet taste](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7473911/)
- When he looked in the liver, he found that maybe **as much as 25% of the glucose was being converted to fructose** in these laboratory mice
- When he gave mice fructose in their water, they get fat
- It takes months to really see the effects of glucose or fructose to cause obesity

**What happens when mice are given glucose or fructose in their drinking water?**

- When mice are given glucose/ fructose in their drinking water, initially thy drink a lot more than they would normally
  - Control mice that had water + Splenda also drank more
- They’re getting a fair amount of caloric intake from the water because it has sugar in it
- When an animal gets calories in their water, they reduce how much food they eat
  - This is a normal process; it’s true for sugar (sucrose), glucose, and fructose
- Over a period of a month or so, the mice drinking sugar calories start eating more, despite still drinking a lot
  - This results in a high caloric state
- Then they start developing [leptin](https://en.wikipedia.org/wiki/Leptin) resistance
  - Leptin is a hormone produced in the fat cells that tells the brain that it’s full
  - It’s what they call a satiety signal; it says, okay, you’ve eaten enough
  - When normal mice are injected with leptin, they will reduce their food intake immediately, within hours, by 30%
  - Injecting leptin doesn’t decrease appetite in humans because, most overweight people are resistant to leptin
    - Overweight people almost always have very high leptin levels
    - In leptin resistance, leptin signaling is not working
- Leptin resistance is how fructose causes animals to eat more
  - This takes a month or so, but giving animals fructose leads to the animals becoming resistant to leptin
- Leptin resistance can be determined experimentally— inject an animal with leptin and if they continue to eat a normal amount they are resistant to leptin
  - He tests all his animals this way
  - Normal animals are sensitive to a leptin injection and will begin to eat less
  - If animals are born with low leptin, they will be hungry and eat more
  - If animals become resistant to leptin, they can have a high leptin level but will not respond to it; so they will eat more
- Evidence of leptin resistance can also be determined by studying the hypothalamus
  - There is a change in the [hypothalamus](https://en.wikipedia.org/wiki/Hypothalamus), phosphorylation of [STAT3](https://en.wikipedia.org/wiki/STAT3)
  - Published in *PNAS* in 2018, [High salt intake causes leptin resistance and obesity in mice by stimulating endogenous fructose production and metabolism](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5866545/)
- The mechanism of leptin resistance is not fully known, but there’s some evidence that it might be due to uric acid
  - A group in China injected uric acid in the brains of animals and showed that caused leptin resistance
  - They also showed that this caused inflammation in the hypothalamus
  - Inflammation in the hypothalamus is thought to be the driver for leptin resistance
  - Published in *PNAS* in 2018, [High salt intake causes leptin resistance and obesity in mice by stimulating endogenous fructose production and metabolism](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5866545/)
- Back to the mouse experiment, when animals get glucose to drink they initially reduce their chow intake; but over time they start increasing their chow intake
  - Then they become very fat and insulin resistant
  - They develop all features of metabolic syndrome
  - When he looks at their livers, they’re making fructose and they’ve turned on this enzyme (aldose reductase), this polyol pathway is high
  - And so they are gaining weight and becoming fat related to fructose production

**Effects of glucose consumption in mice lacking fructokinase**

- Further support of this comes from experiments where glucose was given to animals that lack fructokinase
  - These are genetically manipulated mice where the gene for fructokinase has been removed (knocked out)
  - These animals cannot metabolize fructose through this ATP depletion pathway
- Give animals without fructokinase glucose to drink and they gain some weight and fat
  - This is probably related to the effects of insulin
    - Glucose stimulates insulin and insulin can decrease fat breakdown in the peripheral fat
  - These animals do not develop insulin resistance or fatty liver
  - They’re really protected from the metabolic syndrome and they gain much less weight and have less fat
  - These animals are eating the same calories as control animals that have a functioning fructokinase
  - Published in *Nature Communications* in 2013, [Endogenous fructose production and metabolism in the liver contributes to the development of metabolic syndrome](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3833672/)
- He does lots of pair feeding studies, in this case mice lacking fructokinase are drinking the same amount of glucose as normal controls (that have fructokinase)
  - There may be 3-5% difference, but it’s very similar
  - The difference in body weight and fat is remarkable
- So when he gave just glucose alone, the animals gained a little bit of weight, they drank a lot of glucose
  - They still gained a little bit of weight compared to a mouse that didn’t get glucose, even when the fructokinase was knocked out
  - A mouse that just gets glucose alone really gains weight
  - A mouse that gets glucose in which they cannot metabolize fructose, gains dramatically less weight, but it’s still a little bit more than normal
- - To recap the experimental design—
    - Both animals get glucose in their water + chow
    - One animal has functional fructokinase and the other does not
    - Both animals presumably can make the same amount of fructose
    - The conversion of glucose to sorbitol to fructose is not impaired
    - Only 1 animal cannot convert fructose to fructose-1-phosphate (and therefore cannot metabolize fructose); this is the knockout
    - Fructose levels are still high in the fructokinase knockout, they can’t metabolize it
- Peter wants to understand this from an energy balance perspective, what is the difference between normal and knockout animals?
- When fructokinase is blocked animals regulate their weight, regulate their caloric intake
  - When he gives fructose and glucose to animals, initially they reduce their cow so that they maintain the normal weight
  - But after the leptin resistance kicks in, they start eating more chow than they need and so they go into a positive energy balance where they’re eating a lot more than they normally do; this is associated with weight gain
  - When he gives glucose to an animal that is a fructokinase knockout, what happens is it continues to keep its chow low; so even though it’s drinking a lot of glucose, the chow stays low so that the overall energy intake only very mildly increases
  - Published in *Cell Metabolism* in 2020, [Deletion of Fructokinase in the Liver or in the Intestine Reveals Differential Effects on Sugar-Induced Metabolic Dysfunction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7347444/)
- The fructokinase knockout mice eat less
- Both groups get the exact same amount of glucose but they’re eating different amounts of chow
  - The chow contains everything: fat, protein and glucose
- He did an isocaloric experiment too; this compared mice drinking fructose/glucose and eating chow
  - This compared fructokinase knockouts and [wild type](https://en.wikipedia.org/wiki/Wild_type) mice
  - Published in *Cell Metabolism* in 2020, [Deletion of Fructokinase in the Liver or in the Intestine Reveals Differential Effects on Sugar-Induced Metabolic Dysfunction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7347444/)
  - The hypothesis is that the fructokinase knockouts would be protected from the negative effects of fructose
    - Both the fructose that they’re eating directly and the fructose that they will make from glucose
  - The groups were paired so that animals were eating the same total calories
  - This showed a dramatic difference in fatty liver and insulin resistance
  - To really simplify the findings, he identified that fructose stimulates obesity and metabolic syndrome and it does it through two major ways:
    - 1) By encouraging an animal to eat more; it basically stimulates hunger and stimulates food intake
      - Part of that is through the brain and part of that is through this leptin resistance, which is also kind of a brain effect
      - The animals eat more
    - 2) They also drop their resting energy metabolism
    - So they’re both metabolizing less [metabolism is shifted toward fat synthesis away from energy/ ATP synthesis] and they’re eating more and that causes the weight gain

## What calorie-controlled studies say about the claim that a “calorie is a calorie” [42:15]

**The claim that a calorie is a calorie**

- Peter asks what he would say to those who claim that a calorie is a calorie, they’re all the same
  - Also, does this effect of fructose reduce resting energy expenditure?  Does it reduce the energetic drive and spontaneous energy expenditure?
- Rick says no, this is still the first mechanism
  - Fructose “*makes you gain weight by increasing energy intake and dropping energy metabolism*”

> “*What happens is a lot of weight gain from sugar is because you are eating more and exercising less*” – Rick Johnson

- In this situation resting energy metabolism is less, movement is less

**Problems with claims by the high fructose corn syrup industry [43:30]**

- Most weight gain from sugar is due to eating more
  - Some weight gain is due to a decrease in energy metabolism
  - When Rick used an isocaloric diet (so all the animals, the controls and the sugar-fed animals are eating the exact same amount) there’s minimal difference in weight gain in *the short term*, in a 2 month study
  - There’s a little bit of weight gain because of the decreased energy metabolism in the fructose group, but it can be hard to show and the [high fructose corn syrup (HFCS)](https://en.wikipedia.org/wiki/High-fructose_corn_syrup) industry loves this
    - The HFCS industry says the problem is people are eating too much and sugar is safe
    - Because isocaloric studies looking at the short term show no difference in weight gain
    - This misses the point that the *sugar is actually causing hunger* and by forcing an isocaloric diet, the people are hungry, but they’re not able to eat because they’re not allowed to eat
    - If a *longer term* was studied (a year), these studies would probably  show a difference in weight gain because of the difference in energy metabolism
- Peter puts some numbers to this to compare a high fructose diet to a high glucose diet, “*if the high fructose group was driven to eat an extra 300 calories per day, while simultaneously experiencing a reduction of energy expenditure of 25 calories per day, the increase in the drive to eat 300 calories a day would be readily apparent. Again, this is very back of the envelope math*.”
- Rick agrees, this is correct
- By these numbers, every 12 days would result in a 1-lb gain on the intake side but it would takes months to show a 1 lb gain on the energy expenditure side
- The other problem in the industry is they’ll compare fructose to glucose
  - But we know that some of the glucose is being converted to fructose, so it’s really not a fair comparison
- But there’s another major mechanism, even if animals are pair fed (so that they’re eating the exact same amount), there may not be a difference in weight gain because they’re all eating the exact same number of calories
  - This doesn’t take into account that the animals eating more fructose are leptin resistant
    - They can’t eat what they want to eat
    - They’re presumably less happy; they’re hungry
    - This is due to the non caloric pathway of fructose metabolism shown in the figure below

![](https://peterattiamd.com/wp-content/uploads/2022/02/f8-rickjohnson2-1024x377.png)

**Figure 8.  The noncaloric pathway of fructose metabolism contributes to obesity and disease.** Image credit: [*Obesity* 2019](https://pubmed.ncbi.nlm.nih.gov/31054268/)

- Even when animals are given the exact same diet, all the other metabolic effects of fructose are still going on
- The group getting a high fructose diet still becomes insulin resistant
- They’re still getting fatty liver
- They’re still getting hypertension
- It’s observed in animals and Rick has seen clinical evidence of this in people too

**Studies in mice comparing a 40% sucrose diet to an isocaloric 10% starch diet**

- A great example, he was doing a pair feeding study of 40% sugar versus starch and so the animals were getting the exact same amount of food
  - Published in *Metabolism* in 2011, [Sucrose induces fatty liver and pancreatic inflammation in male breeder rats independent of excess energy intake](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3137694/)
  - A pair feeding means let’s say there are 10 animals in this group and 10 animals in the other group; they have to eat the same amount of food each day
  - This means is that the animal that eats the least amount of food, all the other animals have to eat this same/least amount of food
  - His group was doing this study and didn’t know 1 of the animals had cancer and was hardly eating anything
    - This adjusted the diet for the study
    - Now the animals were on a severe diet
  - 1 group had a diet of 40% sugar and the other 40% starch; everything was equal
  - At the end of the 4 months, the sugar fed animals tended to have a higher weight but it wasn’t significant
    - This was due to changes in resting metabolism, due to the fact that they had a lower energy metabolism
    - And it looked like it would’ve been significant if they’d gone a little bit longer
  - This study went for 4 months; to put this in perspective, mice live for 2.5 years
    - This was like 15 years in a human
- Peter summarizes— this suggests that at least in a calorie controlled state, excess fructose does not alter energy expenditure in any clinically relevant manner
  - Energy expenditure is not a driver of adiposity
  - Rick thinks it is over decades; maybe half a pound a year
    - It depends on the individual
- One can’t completely separate decreased energy expenditure increased food intake that accompanies this in people
- The other thing that happened is these animals that got sugar, every one of them became diabetic
  - Every animal had severe fatty liver; it was a dramatic difference from the starch fed animals
  - The islets of the pancreas were showing changes of type two diabetes as well
  - Peter clarifies that neither group of animals were overweight at the end of this study, but one of them became very skinny fat (metabolically unhealthy)
- Rick’s work has shown multiple times that there are many, many effects from fructose that are independent of calories and it’s due to this energy depletion pathway
  - One of the consequences of this energy depletion is that it stimulates food intake

> “*Part of obesity really is as eating more and exercising or moving less*” – Rick Johnson

- Obesity is not behavioral driven so much as due to activated biologic pathways
- The figure below summarizes metabolism of dietary fructose and endogenously produced fructose; the energy depletion pathway is the non-caloric pathway that contributes to obesity and disease

![](https://peterattiamd.com/wp-content/uploads/2022/02/f9-rickjohnson2-1024x533.png)

**Figure 9. Metabolism of fructose contributes to disease.**  Image credit: *J*[*ournal of Internal Medicine* 2020](https://pubmed.ncbi.nlm.nih.gov/31621967/)

## Implications for aging and disease [51:15]

**Long-term effects of a high sugar diet**

- Rick thinks this whole pathway is very important in aging

> “*I’ve always felt that obesity is a passenger that comes along for the ride, but it’s the metabolic derangement that lies under obesity, that’s highly correlated with obesity, but is quite separate from obesity that’s the root cause of our mortality*” – Peter Attia

- Long studies in Rick’s mice would be one experimental way to demonstrate this; it’s not beyond the realm of doing
- Rick has proposed to do this study
- There has been some interesting studies looking at the effects of sugar on aging done in [fruit flies (*Drosophila*)](https://en.wikipedia.org/wiki/Drosophila)
- The fruit fly actually is eating fruit; that’s what they like
  - They are always on some fructose, but they’re not getting highly concentrated fructose
    - Because the fruit also has lots of other things in it, fiber and other things, flavanols and some of them neutralize some of the effects of sugar
- But if you give a fruit fly *sucrose or table sugar*, which is really fructose and glucose together, they love liquid sucrose and there are studies showing that they will develop obesity
  - These obese, insulin resistant flies will die early
  - When they die, they die from complications related to uric acid production, which is really interesting
  - They develop the equivalent of kidney failure

**Aging-associated renal disease**

- Rick is interested in whether or not mice that lack fructose metabolism (fructokinase knockouts) might live longer than normal mice
- He has some he’s keeping around and they are on a normal mouse chow diet that is very low in fructose
  - He compared the fructokinase knockout mice to wild type mice
  - These animals are eating almost no fructose; it’s less than 3% of their chow
  - They get glucose in the form of starch in the chow; they get a fair amount of carbohydrate
  - This is a standard, low-sugar chow
  - He took these mice out a little over 2 years and found they stayed lean compared to control mice; this was statistically significant
    - Published in the *American Journal of Physiology Renal Physiology* in 2016, [Aging-associated renal disease in mice is fructokinase dependent](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5142232/)
  - These mice tended to have normal blood pressure or lower than control animals
    - To measure blood pressure in mice they use a cuff on their tail; this measures systolic pressure
    - Their blood pressure is similar to ours, 100-120
- Peter asks if they were significantly leaner than wild type control and if he documented how much less they were eating
  - Rick didn’t measure that but in retrospect, it was very important to know
  - 2 years is a lot of laboratory time

**Effects of fructose metabolism on the kidneys**

- Normal mice show aging changes in their kidneys
  - This is true for all mice and rats and humans;
- But the fructokinase knockout had no aging changes in their kidney
  - Their blood pressure was pretty normal, it tended to be a little bit lower
  - They did a study and showed if they were given salt, normal animals had a higher rise in blood pressure than fructokinase knockout animals
    - But the baseline blood pressure in these animals was not really different
  - There is a difference in response to salt; this has been reported in aging
    - People become more sensitive to the effects of salt with aging
- Peter asks, “*what do you hypothesize was the difference between the kidney function in these two animals?*”

> “*The dramatic thing is that the fructokinase knockout were protected from aging associated changes to the kidney and so it suggests that endogenous fructose production is maybe more important than we think and that it could have a role in the aging process*” – Rick Johnson

- Endogenous fructose production can be quantified; a recent study labeled fructose and gave it to people in a soft drink
  - This study found that when people drank the soft drink, they increased the production of fructose by 3-4x
  - Note, we are always making some fructose in our bodies
  - Published in *Clinical Nutrition ESPEN* in 2019, [The extra-splanchnic fructose escape after ingestion of a fructose-glucose drink: An exploratory study in healthy humans using a dual fructose isotope method](https://pubmed.ncbi.nlm.nih.gov/30661675/)

**Fatty liver disease**

- Peter wants to put this in perspective with his patients
  - When he has a patient with fatty liver disease, the first thing he does is restrict fructose and alcohol
  - He stops all alcohol and drops fructose intake dramatically to typically 5 to 10 grams per day, which basically means vegetables and a handful of berries if they must have some fruit
    - It’s a minimal fruit diet and no alcohol
    - This is before calorie restriction or manipulation of other macros, carbohydrates, etc.
    - This usually improves [non-alcoholic fatty liver disease (NAFLD)](https://en.wikipedia.org/wiki/Non-alcoholic_fatty_liver_disease) in most people
    - They may or may not lose weight
  - These conditions reverse NAFLD without a huge amount of weight loss
    - These patients often lose weight because they are also in a state of positive energy balance
    - Studies from David Ludwig’s group, Rob Lustig, Miriam Vos, etc. have looked at this (refer to the selected links section at the end)
    - One of the challenges that all of these investigators have had is maintaining the weight of the fructose restricted group
- Rick’s group was the first to report that fructose could be a cause of fatty liver
  - Published in the *Journal of Hepatology* in 2008, [Fructose Consumption as a Risk Factor for Non-alcoholic Fatty Liver Disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2423467/)
  - This study with Manal Abdelmalek at the University of Florida, and found that patients who were drinking large amounts of soft drinks had high uric acid levels
    - When they looked at liver biopsies, they found an increased expression of fructokinase by 3-4x
- He started putting people on low fructose diets (in addition to low alcohol) for treating fatty liver
  - One of the people in his lab had a son who developed fatty liver but was skinny
    - It turns out he was drinking soft drinks almost every day
    - Simply cutting that out was enough
    - That was one of the precipitants for Rick to write [his first book](https://www.amazon.com/Sugar-Fix-High-Fructose-Fallout-Making/dp/1594866651/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=), the dramatic effects seen in some people with fructose restriction

> “*But now we know that it isn’t just the fructose you drink, it’s the fructose you make*” – Rick Johnson

## Impact of endogenous fructose production on obesity and metabolic syndrome [1:01:30]

**Typical fructose consumption in the American diet**

- About 15-20% of the diet is from sugar (and sugar is half fructose and half glucose)
- So 10-15% of the diet is fructose
  - Fructose comes from added sugars, fruit, and other foods
- Sugar in the diet can vary; some people are eating as much as 25% of their diet as sugar
  - So people can be eating as much as 15, even 20% of their diet as fructose
- Conservatively, it’s not hard to eat 100 grams of fructose a day
  - 400 calories of fructose could represent 15% of the daily caloric intake
- Let’s say the average American is eating 75-100 g of fructose; that’s their exogenous consumption of fructose
  - Let’s assume that person is a little bit insulin resistant and a little bit leptin resistant (but not off the charts); what is their endogenous production of fructose?
  - A guess (based on animal data) would be around 25-50% more fructose comes from endogenous production

**Endogenous fructose production**

- There are 3 major sources for endogenous fructose production
  - 1) High glycemic carbs such as rice, potatoes, bread, and chips [he will come back to the other 2 sources]
    - Maybe a quarter of that can be turned into fructose
    - Rick thinks this is playing a major role in metabolic syndrome
  - When someone is young and the polyol enzyme pathway is not activated, eating things like potatoes and French fries may not cause so much weight gain, you may feel you’re invincible, but as this pathway gets activated and aldose reductase starts being highly expressed in the liver, then potatoes and bread may cause much more weight gain

**Studies in fructokinase knockout mice**

- He did another study where animals were given soft drinks/ high fructose corn syrup
  - They got really fat and insulin resistant
  - But if he blocked fructokinase, this completely blocked development of metabolic syndrome
    - [Sugar causes obesity and metabolic syndrome in mice independently of sweet taste](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7473911/) | *American Journal of Physiology Endocrinology and Metabolism* (A Andres-Hernando *et al.* 2020) | [35:45; 1:04:00]
  - So with soft drinks, it really was all fructose, even though there’s a lot of glucose in there
  - He saw a little bit of weight gain with glucose alone

> “*When we give high fructose corn syrup, it was… the fructose that was causing them to gain weight and to get metabolic syndrome*” –  Rick Johnson

## Why vulnerability to the negative effects of sugar increases with age and menopause [1:04:30]

**The important role of the mitochondria**

- Peter asks what is it about *aging* that alters our sensitivity or vulnerability to glucose?
  - Rick mentioned that when we are young, we can tolerate lot of high glycemic foods
- Rick notes there are 3-4 reasons
  - 1) when we’re young, we tend to have very healthy mitochondria
  - Kids are active, and this keeps the mitochondria healthy
  - Fructose works by causing oxidative stress to the mitochondria. this activates these pathways
  - But if the mitochondria are really powerful, these metabolic effects won’t develop as easily, because the mitochondria are more resistant to the effects of fructose
    - This is seen in super athletes; they have fantastic mitochondria
    - Many of them feel like they can drink a lot of sugar and they’re immune and it’s because they have really, really healthy mitochondria
- Peter asks what it means to have healthy mitochondria; why is mitochondrial dysfunction viewed as one of the hallmarks of aging?
- [Mitochondria](https://en.wikipedia.org/wiki/Mitochondrion) are one of your major places where energy is made
  - In fact, it’s the high output energy producer, so it’s producing the ATP that we need to drive everything we do
- Over many years, the mitochondria get less good at making the energy because of damage, recurrent damage, and it’s thought that oxidative stress to the mitochondria can cause this damage
  - And so when you want to try to store fat, mitochondrial oxidative stress is part of the requirement to store fat and fructose works to store fat by stimulating mitochondrial oxidative stress
  - Initially, this is an easily reversible mechanism
- Oxidative stress inhibits these enzymes and it leads to fat production and so forth; this is a survival pathway
- But when the mitochondria is continually stimulated with oxidative stress, the mitochondria become unhealthy
  - This has been shown with fructose; the mitochondria start to decrease and the mitochondrial change
  - The mitochondria become smaller and less efficient
  - The mitochondrial function starts to reduce; the number of mitochondria becomes less
  - When that happens, less ATP is made
    - This is associated with feeling more fatigue, more tired
    - Lower ATP levels in the muscle is associated with muscle fatigue

> “*Your natural gait will slow down as your mitochondrial function decreases, and it’s all associated with aging*” – Rick Johnson

- Peter asks how this is quantified in animals; are muscle biopsies taken?
- The mitochondria themselves can be measured by looking at them with an [electron microscope](https://en.wikipedia.org/wiki/Electron_microscope)
- It can be measured indirectly with [PCR](https://en.wikipedia.org/wiki/Polymerase_chain_reaction)
  - The number of mitochondria can be determined by measuring the ratio of [mitochondrial DNA](https://en.wikipedia.org/wiki/Mitochondrial_DNA) to nuclear DNA
- ATP levels can be measured in tissues
- There are lots of ways to measure mitochondrial function, but what we know is it tends to decrease with age
- There is good evidence that recurrent chronic oxidative stress to the mitochondria is involved in decreased mitochondrial function
- Rick thinks that fat storage is associated with mitochondrial oxidative stress
  - So if these pathways are continually stimulated with fructose, that may actually wear down the mitochondria
- Rick did a study in humans where people were put on a low fructose diet
  - This showed that mitochondrial biogenesis could be increased in people within 30 days
    - There was a very dramatic increase in mitochondrial production
  - Published in *Experimental and Clinical Endocrinology & Diabetes* in 2013, [Low fructose and low salt diets increase mitochondrial DNA in white blood cells of overweight subjects](https://pubmed.ncbi.nlm.nih.gov/23934680/)

**Fasting and calorie restriction can also increase the number of mitochondria and function**

- Fasting is thought to increase mitochondrial probably the same way, and actually even caloric restriction
- The concept that caloric restriction can be beneficial to reduce aging is probably through this pathway
  - The process of eating and storing fat seems to involve some mitochondrial oxidative stress
  - And so if one eats less food, they’re going to have less oxidative stress to the mitochondria and less fat stores
  - This will allow them to live longer
- Reduce aging by reducing mitochondrial oxidative stress
- Animals always want to have some extra fat on board because they’re living in the wild
  - They need to be prepared for a sudden food shortage
- When he puts animals on a diet, 70% of their normal caloric intake, their fat stores become very minimal
  - They have less oxidative stress to their mitochondria and they’re going to live longer
  - Their mitochondria are going to stay healthier
  - But if these animals are put in the wild, the first food crisis will kill half of them
    - They can’t survive because they don’t have enough energy stores
    - So in the wild, animals want to have a little bit of extra fat

> “*The obesity paradox is hard to ignore, that low levels of obesity actually seem protective*” – Peter Attia

- If someone has cancer or heart failure or any kind of chronic disease, they’ll actually live longer if they have fat stores,
  - Someone who has a [BMI (body mass index)](https://en.wikipedia.org/wiki/Body_mass_index) of 27 is going to do better than someone with a BMI of 20 when they both have a chronic illness
  - Even a person that has a BMI of 28 is going to do better than a person with a BMI of 24 as they age
  - We need to have a little bit of fat stores

**Why is this a problem associated with aging?** [1:11:30]

- Back to the original question, why is it when people are young they can eat bread without a problem?
- This is because their mitochondria are healthier and they have metabolic flexibility; they can metabolize things very easily
- But over time, the more sugar we eat, the better we get at metabolizing it
- Normally, when we eat sugar the transporter for fructose in our gut is expressed at low levels
  - Animals that get fructose when they’re young tend not to absorb it as well
- But the more we get exposed to sugar, the better we get at absorbing it
  - We turn on the enzymes and the transporters that allow us to absorb fructose more readily
- For example, give an animal sugar for a month, they’ll up regulate all these pathways
- Maybe if they stop eating sugar for one day, and then are given a bolus of sugar (a large, single dose), they get a very dramatic activation of this switch and the fallen energy
  - It’s very dramatic compared to a normal animal that’s not been exposed to sugar that gets a single dose
  - And that’s because we turn on these pathways, so we turn on the ability to metabolize sugar

**Studies in children**

- He did a study in children where they gave them a dose of fructose
  - Published in *Pediatric Obesity* in 2015 in [Oral fructose absorption in obese children with non-alcoholic fatty liver disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4948988/)
  - They compared lean, obese children, and obese children with fatty liver (known by liver biopsy)
  - They were given a dose of fructose; this was a liquid bolus, about 1 g per kg of body weight
  - The lean children only absorbed about 70% of the fructose and they metabolized it slowly
  - The kids that were obese, they absorbed much more fructose and they metabolized it a little bit faster, but they still didn’t absorb it all
  - The kids that had fatty liver and obesity and they absorbed a 100% of it and they metabolized it faster
    - He thinks this is because of prior exposure to sugar and so forth
    - There could possibly be genetic differences
    - But in animals, the more sugar they are given, the more they’ll absorb; there’s other data in humans to support this as well

**Mechanisms that make one sensitive to fructose over time**

- 1) Mitochondria tend to be healthier when one is young
- 2) The more sugar one eats, the more they are able to absorb and metabolize
- 3) The polyol pathway also gets turned on over time
- By the time someone has metabolic syndrome, they probably have this enzyme [aldose reductase] turned on
  - They have high uric acid; this can activate the polyol pathway too
  - They convert glucose to fructose
- For someone who is overweight and cuts out sugar and fructose
  - They are still gaining weight probably because their body is making a lot of fructose
    - The body makes fructose from high glycemic carbs; this is the #1 food that is used to generate fructose

**What effect does menopause have on this?**

- Peter asks about menopause
- Estrogen increases uric acid excretion
- Young women tend to have lower uric acid levels compared to men
- When women go through menopause and estrogen levels fall, uric acids increase and suddenly post-menopausally women suddenly develop obesity, diabetes, heart disease
  - The rates of these diseases in post-menopausal women become more like males
- Premenopausal, estrogen is providing some protection
  - This can certainly be overwhelmed by eating a lot of sugar and so forth
- Menopause is related to this change in uric acid
- Fructose metabolism will be up regulated by uric acid
  - When uric acid goes up, not only does it turn on the polyol pathway, but it actually up regulates fructokinase as well
- He’s shown in animals that when uric acid is raised, this raises the fructokinase levels and also amplifies the effects of sugar
  - Published in *PLoS One* in 2012, [Uric acid stimulates fructokinase and accelerates fructose metabolism in the development of fatty liver](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0047948)
- There is also a direct relationship between uric acid and aldose reductase
  - Published in the *Journal of Biological Chemistry* in 2019,  [Uric acid activates aldose reductase and the polyol pathway for endogenous fructose and fat production causing development of fatty liver in rats](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6422088/)
- Peter asks if someone is given allopurinol to knock their uric acid from 7-4 mg/dL, does this reduce the conversion of glucose to sorbitol?
  - Rick hasn’t done this experiment; it’s a great question; it would be a good study

## Dietary strategies to reduce the negative impact of fructose [1:16:30]

- Peter asks “*What do people need to be wary of? I mean, I think the other question that emerges from a discussion like this for many people is, oh my God, do I need to not eat any fructose? This means I can’t have any fruit. Tomatoes have fructose in them… how do we provide some insight to people so that they can figure out how to adjust the dose of something that is something that is completely ubiquitous?*”
  - So if you want to go on a zero fructose diet, you’re going to have a hard time
  - That’s not going to work
- The first thing Rick recommends is try not to drink liquids that have lots of sugar in them— soft drinks and fruit juices
  - Review of risks of liquid sugars, published in *Obesity* in 2019, [Are Liquid Sugars Different from Solid Sugar in Their Ability to Cause Metabolic Syndrome?](https://pubmed.ncbi.nlm.nih.gov/31054268/)
- Sports drinks are interesting because some are really low in fructose
  - Maybe 2-4% fructose and 6% glucose
  - 6% glucose means there are 60 grams of glucose per liter
- Soft drinks are about 11% sugar— 6% fructose and 5% glucose
  - This is on the order of 110 g total sugar per liter

> “*That really is bad stuff; soft drinks should… be banned*” – Rick Johnson

**Sports drinks**

- Sports drinks were developed originally by [Bob Cade](https://en.wikipedia.org/wiki/Robert_Cade) and the invention of [Gatorade](https://en.wikipedia.org/wiki/Gatorade)
  - People who are exercising a lot are losing lots of salt in their sweat; they’re burning up glucose, and some of them were getting hypoglycemic on the field
  - Sports drinks were really meant to help replenish the electrolytes and to fix the glucose problem
    - Glucose is fuel for the muscle during heavy bouts of exercise; we often use a lot of glucose during exercise
  - The original sports drinks were glucose rich and had a lot of salt and water
  - Some studies that showed that oxidation of glucose could be facilitated by having a little bit of fructose in the drink
    - Having a small amount of fructose actually accelerated glucose uptake; this worked primarily in the gut
    - Performance was increased by having small amounts of fructose (2-3%) and the optimal glucose in sports drinks was found to be 5-6%
  - Now, some sports drinks actually have more fructose in it because it tastes better and that’s a problem
    - But for someone out there exercising, using a sports drink for what it’s meant for, then this is fine
    - But drinking sports drinks without exercise, in front of the TV, is probably not a good idea

**Fruit juice**

- The sugar content of freshly squeezed orange juice is probably about two thirds of a soft drink
- Apple juice is sweeter, it’s equivalent to a soft drink
- [The Pediatric Society](https://publications.aap.org/pediatrics/article/139/6/e20170967/38754/Fruit-Juice-in-Infants-Children-and-Adolescents) a long time ago realized that juice has so much fructose that it was being associated with obesity in children
  - They made recommendations to limit fruit juice, to like 6 ounces or less for older children and 4 ounces or so for really small children
  - Rick thinks we should even limit it more

**Whole, fresh fruit**

- Natural fruits are different; they have much less fructose in an individual fruit
  - Fruit juice is made from multiple fruits
  - Eat an orange and it has 6-8 grams of fructose, closer to 6 g of fructose and some glucose
  - Rick thinks natural fruits are fine, even for someone with NAFLD (fatty liver)
- There are certain fruits that are high in sugar— mangoes, figs, dates
  - Figs are very, very enriched in fructose; fFigs are probably something that we should avoid
- Apples and pears, plums, tend to be fairly high, around 9-10 grams
- Bananas are fairly high glycemic; they have a fair amount of fructose, but it’s probably in the range of 6-8 grams
- Most fruits are between 3-9 g, 10 g max, with the average being 4-6 g (see the table below)
- Some fruits have much less sugar— kiwi and berries (strawberries and blueberries)
  - People  should be encouraged to eat these

![](https://peterattiamd.com/wp-content/uploads/2022/02/f10-rickjohnson2-1024x928.png)

**Figure 10. Fructose content per serving of fruit.** Image credit: [*Nature Wants Us to Be Fat*](https://www.amazon.com/Nature-Wants-Fat-Prevent-Reverse/dp/1637740344/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)

- Rick did a study, they gave people a low sugar diet that was low in refined sugar and low in high fructose corn syrup
  - Published in *Metabolism* in 2011, [The effect of two energy-restricted diets, a low-fructose diet versus a moderate natural fructose diet, on weight loss and metabolic syndrome parameters: a randomized controlled trial](https://pubmed.ncbi.nlm.nih.gov/21621801/)
  - One group got natural fruit, but was low sugar and low fructose
    - It was sort of a modest total fructose intake
  - The other group was restricted too
    - It was a low fructose diet that was low fructose in all aspects
  - They found equivalent improvement in metabolic syndrome in both groups

> “*The presence of natural fruit did not block the ability of the low sugar diet to improve metabolic syndrome*” – Rick Johnson

- Peter notes, “*The takeaway here is don’t drink it and don’t consume added sugar, and I think this is a difficult thing for people to differentiate. So added sugar is when a food has sucrose or high fructose corn syrup.  These are typically the most common agents that are added to the food. So if you go and get a jar of pasta sauce, they have added sugar to it*.”
  - This is not the sugar naturally present in the tomatoes; it’s deliberately added to make it taste sweeter
  - Rick agrees
- Remember the intestine acts as a shield for 4-6 grams of fructose
  - Eating 4-5 g of fructose in a fruit is okay because the intestine’s going to provide protection
  - In addition, there is fiber in a natural fruit and that slows the absorption so the concentration of fructose that goes to the liver is lower
    - This results in less ATP depletion

**Dried fruit**

- Peter asks about dried fruits.  How does apple chips compare to a whole apple, when considering equal amounts of calories?

> “*The trouble with dried fruit is that it still has all the fructose, but a lot of the good things are removed… Dried fruit is sort of like candy*.” – Rick Johnson

- It’s not just the loss of water that’s a problem in dried fruit, things like vitamin C tend to be low
  - Peter notes, “*It’s hard to eat more than two apples in one sitting. It’s not hard to eat more than ten apples’ worth of apple chips in one sitting. So I really thought it was more of just a regulation of quantity*.”
  - This may be true, but Rick has read that dried fruits do not contain as much of the good nutrients (see studies listed in the Selected Links section at the end)
- Dried fruits are thought to be primarily devoid of the good components that are in fruit
  - And we know that there are many other good components in fruit besides fiber
  - There’s potassium and [flavonols](https://en.wikipedia.org/wiki/Flavonols)
  - There’s a substance called [epicatechin](https://en.wikipedia.org/wiki/Catechin) that’s in a lot of fruit that actually can block some of the effects of fructose
  - Other things like [luteolin](https://pubs.acs.org/doi/10.1021/acs.jafc.0c08085) and [mangosteen](https://en.wikipedia.org/wiki/Mangosteen) (a fruit from Southeast Asia), and different flavonols also seem to block the effects of fructose

**Effects of blocking fructokinase activity in humans**

- Peter asks, “*how do I knock out my fructokinase? And maybe more interestingly, how much polymorphism exists in the fructokinase gene in humans that might account for differences in fructose tolerance?*”
- There is a condition called essential fructosuria; this is a hereditary condition in which a person does not have fructokinase
  - They pee about 10% of the fructose they eat (it goes out through the urine), and the rest is metabolized by the glucose enzymes because some of the glucose enzymes can metabolize fructose
  - No one with this condition has ever been reported with type II diabetes or obesity
  - It seems that it’s associated with normal lifespan or maybe even prolonged lifespan
  - Rick is  in connection with a small kindred or family that has this condition and interestingly, they can eat all the sugar they want, but they tend to prefer salty foods
- What is the hope for a pharmacologic agent that could block fructokinase as a treatment for obesity, type II diabetes, and NAFLD?
- Disclosure— Rick has a small company that’s trying to develop fructokinase  inhibitors for the treatment of metabolic syndrome and other conditions associated with fructose
- But there are also several large pharma that are actively working on making fructokinase inhibitors
  - Eli Lilly is one that’s actively trying to make fructokinase inhibitors; they’re in phase I clinical trials right now
  - Pfizer actually had a success in a phase two trial where it reduced fatty liver pretty significantly and improved insulin resistance
- It’s a very exciting future, if these inhibitors can be developed, it looks like they hold great promise
  - In animal studies, they can block sugar induced obesity and diabetes and fatty liver
- Sadly, [Pfizer](https://www.fiercebiotech.com/biotech/pfizer-dumps-midphase-nash-prospect-quarterly-pipeline-cull) stopped development of its fructokinase inhibitor, despite a positive phase II result
  - He doesn’t know why they stopped developing their drug
    - No toxicity was reported
    - The drug looked very promising
  - They have another [drug they’re developing for fatty liver](https://www.pfizer.com/disruptive-science/meet-team-homegrown-therapies-get-ready-fight-nash) that also had very positive results

## The role of hypertension in chronic disease and tips for lowering blood pressure [1:30:45]

**High blood pressure contributes to many chronic diseases**

- Blood pressure seems to play a very important role in all the major chronic diseases, except for cancer
- Peter notes, “I*n neurodegenerative disease, cardiovascular disease, cerebrovascular disease, and renal disease (which are really the main pillars of death), hypertension seems to work against you*”
- High blood pressure (aka primary or essential hypertension) is extraordinarily common in our country and throughout the world
  - Maybe 1/3 of adults have high blood pressure
- High blood pressure is usually defined as a blood pressure greater than 140 over 90
  - In the US it was recently redefined as being greater than 130/80
- Rick is a nephrologist, he takes care of the kidneys, the organ that is arguably the most sensitive to blood pressure (this is the first place where damage shows up)
- Rick notes there are 3 main sites where high blood pressure really causes problems
  - 1) [Stroke](https://medlineplus.gov/stroke.html)— high blood pressure is a major cause of stroke
  - 2) [Heart failure](https://medlineplus.gov/heartfailure.html)— it’s a major cause of heart failure
  - 3) [Kidney disease](https://medlineplus.gov/ency/article/000471.htm)— it’s one of the 2 major causes of kidney disease
  - These are all pressure related conditions where the higher the pressure the higher the risk of these diseases
- Studies show that the greatest risk for these diseases occurs when the systolic blood pressure is 160-180 or higher
  - This is kind of a turning point, beyond which there is a dramatic increased risk for these conditions
- There is a linear relationship between blood pressure and the risk of stroke and heart failure going all the way down to 120/80
- Most studies done in around 1900 showed that less than 5% of the population had blood pressures of over 140 over 90
  - Based upon the normal Gaussian curve of the population back then, probably about 140 over 90 was the cutoff for what was thought to be high blood pressure

> “*I’m a believer that 140 over 90 is a good mark for where we should be viewing hypertension as a condition that really should involve active management*” – Rick Johnson

- Rick believes there is  minimal risk with a blood pressure 135 over 85
  - In epidemiology studies over many years, it can be shown that 120/80 is superior to 135/ 85
- Peter comments that he freaks out when it comes to managing the [glomerular filtration rate (GFR)](https://en.wikipedia.org/wiki/Glomerular_filtration_rate) in his patients because he’s not a nephrologist
  - He wants people to live to 100; most people aren’t going to but this is an aspiration
  - A 40-year old patient with a GFR of 85 is normal; but Peter wants her to live to 100 not 80, so he needs to treat her like a 20-year old
    - This is why he wants to understand this
  - If he wants to get people’s kidneys to have a GFR above 40 at the age of 100, do the standards on hypertension need to be revised?
- Rick replies, “*the answer is we would prefer blood pressure of 120 over 80, but if it’s 135 over 85, to put someone on a medication that they’ll have to take for the next 60 years, I’m not sure that that’s the best way to go. I think that doing nutritional and exercise related maneuvers when you’re at 135 over 85 should be the way to go*.”

**Dietary changes can reduce blood pressure**

- Blood pressure can be fixed by diet— reducing salt, picking healthier foods, and exercising
  - But the trouble with when someone gets to 140 over 90, if they can’t lower their blood pressure by dietary means, they should go on an antihypertensive medication because it will provide protection over time
- Rick hasn’t seen any evidence that antihypertensives provide long term benefit to patients with a blood pressure of 135/85
  - Dietary measure makes sense
  - He’s not sure about pharmaceutical interventions

> “*The trouble with defining hypertension at a lower level, is it implies that antihypertensive should be used at those lower levels and I don’t think that the evidence is strong enough to warrant that*” – Rick Johnson

- Peter notes that “*the absence of evidence is not the evidence of absence*”; perhaps this should be studied
  - This is  the same problem that we face when we try to think about this through the lens of cardiovascular disease, which is, is a 30 year old with an [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B#Role_in_lipoproteins_and_atherosclerosis) of a hundred worse off than a 30 year old with an apoB of 70?
    - This episode discussed apoB in great detail: [#185 – Allan Sniderman, M.D.: Cardiovascular disease and why we should change the way we assess risk](https://peterattiamd.com/allansniderman/)
  - There’s no study that can answer that question because if one studies a 30 year old for the next five years, apoB of 70 versus, hell 170, they cannot see a difference over that period of time
    - One would have to study those people over their lifetimes
  - If one compares people with a blood pressure of 135/85 to 120/80 over five years, it’s not going to reveal enough of a difference
  - So it creates a bit of a problem with how the guidelines are created, but it shouldn’t confuse the underlying physiology
- Rick agrees and notes, “*I think if you use these more stringent definitions of hypertension, then suddenly a very large number of adults have hypertension. And if you then say that they need treatment for it in terms of like an antihypertensive, then you’re talking about probably the majority of the population.”*
- Or Peter suggests that maybe the treatment is to reduce insulin resistance; Rick agrees
  - Drugs aren’t great at reducing metabolic syndrome

## The impact of fructose and uric acid on kidney function and blood pressure [1:39:45]

**Mechanisms that drive high blood pressure**

- The first issue was known is that **salt** is important in blood pressure
  - In animals that are sensitive to high blood pressure, one can make blood pressure a lot worse by giving them salt.
  - Studies from 1900 showed that if you took people with high blood pressure and you put them on a salt restriction, this lowered blood pressure
  - This has led to recommendations to restrict salt in people with high blood pressure
- Not everybody is sensitive to salt
  - Lot of people when they’re young can eat all the salt they want and they don’t seem to have so much of a problem
- But as we get older, we become more and more sensitive to the effects of salt on blood pressure
  - Why is this?
  - For years, it was thought the problem is the kidneys in people with high blood pressure can’t excrete salt as easily or as well as normal people
    - And so it was thought that there was some defect in the kidney
  - To make a long story short, over a decade of studying this revealed that people with high blood pressure have **inflammation** in their kidneys
    - This low grade inflammation in the kidneys is due to T-cells and macrophages
    - This inflammation tends to be in the main part of the kidney where the tubules are and around the little blood vessels
  - Studies were able to prove that the inflammation was actually maintaining the kidney in a state where it couldn’t get rid of salt very well
    - Reviewed in *Physiological Reviews* in 2017, [Role of the Immune System in Hypertension](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6151499/)
  - This occurs by creating reduced blood flow to the kidney
- People with high blood pressure, they all have reduced blood flow to their kidneys
  - When the blood flow is reduced, this affects the ability of the kidney to excrete salt, and triggers the retention of salt
- Studies revealed that high blood pressure is an inflammatory disease that is driven by inflammation
  - But then the question is, what is driving the inflammation?
- He found that many things could drive inflammation in the kidneys
  - Some drugs are very vasoconstrictive;  cocaine, for example, and other things that constrict the renal arteries
  - Activation of the renin angiotensin system, for example, can cause ischemia to the kidneys and bring in this inflammation
  - But one thing that seems to drive it is a level of high uric acid
- He did studies in adolescents who were overweight
  - Published in *JAMA* in 2008, [Effect of allopurinol on blood pressure of adolescents with newly diagnosed essential hypertension: a randomized trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2684336/)
  - Many of them had high uric acid levels and were discovered to have high blood pressure
- He did some studies in animals and saw that when they raised uric acid, the animals developed high blood pressure
  - Published in *Nephron, Experimental Nephrology* in 2012, [Uric acid-induced endothelial dysfunction is associated with mitochondrial alterations and decreased intracellular ATP concentrations](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3656428/)
- He thought maybe the uric acid could be playing a role in blood pressure in humans
- He did [a study, done by Dan Feig (published it in JAMA)](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2684336/) where they randomized adolescents with high blood pressure to drugs to lower uric acid or not
  - This is a study of kids with newly discovered hypertension; they’ve never been on any kind of drug at all
  - He put them on [allopurinol](https://www.rxlist.com/zyloprim-drug.htm), a drug that can lower uric acid
  - The results were remarkable, 90% of them normalized their blood pressure when their uric acid levels were lowered
  - There was a 5-8 mm drop in ambulatory blood pressure

**Uric acid produced by fructose metabolism contributes to high blood pressure and metabolic disease**:

- Peter asks about the 2009 study where patients were given 200 g fructose with and without allopurinol
  - Published in the *International Journal of Obesity* in 2010, [Excessive fructose intake induces the features of metabolic syndrome in healthy adult men: role of uric acid in the hypertensive response](https://pubmed.ncbi.nlm.nih.gov/20029377/)
  - With treatment, their blood pressure was reduced 7 mm systolically and 5 diastolically
  - Is this drop clinically significant?
  - Absolutely, when blood pressure goes up that much, it is definitely associated with increased cardiovascular events over time
  - It’s thought to be clinically significant when diastolic pressure can be lowered by more than 3 mm and the systolic pressure by more than 4-5 mm
  - In this study the blood pressure of all the patients went up quite significantly
  - 25% of the patients developed metabolic syndrome [*de novo*](https://en.wikipedia.org/wiki/De_novo), mainly because of a rise in blood pressure
- Peter asks about the mechanism responsible for these changes, is it all due to inflammation in the kidney?
- Rick notes that it’s more complicated than that
  - Chronically elevated blood pressure is caused by inflammation in the kidney
  - Inflammation in the kidney is associated with high uric acid
  - Uric acid is also raising blood pressure directly through effects on blood vessels
    - Uric acid will inhibit [nitric oxide](https://en.wikipedia.org/wiki/Nitric_oxide#Biological_functions); it will stimulate oxidative stress
  - Specifically, uric acid will reduce endothelial nitric oxide through multiple mechanisms
    - 1) It removes nitric oxide directly by binding to it
    - 2) It decreases the uptake of  [L arginine](https://en.wikipedia.org/wiki/Arginine#High_blood_pressure), which is used to make nitric oxide
    - 3) There’s some models where it seems to be blocking the [endothelial nitric oxide synthase](https://en.wikipedia.org/wiki/Endothelial_NOS)
- Peter asks if he has looked at symmetric and [asymmetric dimethylarginine](https://en.wikipedia.org/wiki/Asymmetric_dimethylarginine) levels as well?
  - There’s some association between these elevated levels and decreased renal function
  - And it’s also believed to work through the inhibition of nitric oxide synthase
- Rick notes, “*High blood pressure is a very complicated problem. And we think that it’s initiated by eating foods high in salt and foods high in sugar. And if you give sugar to animals, blood pressure goes up acutely. And if you give sugar or fructose to humans, blood pressure goes up within minutes*.”
  - If someone drinks a 20-ounce Coke, their blood pressure goes up 3-4 mm
- Peter asks about increased blood pressure in response to exercise
  - When exercising, his blood pressure will go up 40 mm, but acutely, that’s not a problem
  - An acute change is not problematic but a chronic increase is
  - Chronically, exercise reduces blood pressure, inflammation, hepatic glucose, etc.
  - He notes, “*I’m always a little bit worried when we talk about,you drink a Coke and this happens acutely without understanding what it’s doing chronically*”
  - Rick agrees, Peter is absolutely right

**The link between sugar and hypertension** [1:48:15]

- Sugar is linked epidemiologically with the development of hypertension
  - Published in the *Journal of the American Society of Nephrology* in 2010, [Increased fructose associates with elevated blood pressure](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3013529/)
- There are studies out there where overweight people have gone on low-sugar diets and their blood pressure comes down
  - There’s evidence that it’s the fructose component that is driving the blood pressure response because acutely, giving fructose increases blood pressure
    - Giving glucose does not increase blood pressure acutely
    - So fructose does something that raises blood pressure

## The potential role of sodium in hypertension, obesity, and metabolic syndrome [1:49:00]

- Rick’s group discovered that when animals are put on a salty diet, they actually start producing fructose in their bodies
  - Published in *PNAS* in 2018, [High salt intake causes leptin resistance and obesity in mice by stimulating endogenous fructose production and metabolism](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5866545/)
  - So salty foods turned out to be another way to stimulate fructose production
  - And when you give salt chronically to animals, they get high blood pressure, they get hypertrophy of their heart, and they also develop metabolic syndrome
    - They actually develop obesity, insulin resistance and everything

> “*That may seem surprising because we don’t think of salt as driving obesity, it’s non caloric. But actually there’s data in humans that high salt diet also increases the risk for obesity and insulin resistance besides hypertension*” – Rick Johnson

**Mechanisms: How salt raises blood pressure and stimulates endogenous production of fructose**

- The mechanism is that as the salt concentration in the blood goes up, it activates the polyol pathway and turns on this enzyme (aldose reductase) to make fructose
  - Aldose reductase converts glucose to fructose
  - When one eats potato chips, the glucose and salt stimulates the enzyme to convert glucose to fructose

> “*French fries are particularly fattening because they have the salt and the carbs that together really turn on this pathway to make fructose*” – Rick Johnson

- There is strong evidence in humans that serum sodium concentration activates aldose reductase; the data is very strong
  - Increased serum [osmolality](https://en.wikipedia.org/wiki/Molality#Osmolality) activates this pathway or increased salt concentration in the blood can activate the aldose reductase pathways
  - This data is very strong in humans; it’s very strong in all organisms.
  - The change in osmolality is key; this is why elevated glucose can also activate this pathway
    - Peter notes that, “s*omeone with type two diabetes and their glucose concentration is 140 milligrams per deciliter, that’s a huge osmolar load. So even if they have normal salt concentration, that could be activating it*.”
- What is it about osmolality that activates this enzyme?
  - The promoter for aldose reductase has an osmol sensitive region that gets activated by a [transcription factor](https://en.wikipedia.org/wiki/Transcription_factor) called TonEBP (aka NFAT5)
    - This is a major mechanism that animals use when they get dehydrated
- Dehydration or increases in the salt concentration of the blood when salty foods are eaten triggers thirst and the body starts making fructose from the glucose that has been eaten
  - Over time, it appears that this fructose (as well as sugar) seems to be enough to drive metabolic syndrome
- So salt and sugar both activate the pathway
  - When animals are given salt, it takes them a longer time to gain weight as compared to sugar
    - Sugar’s pretty quick, but when they are given salt, it takes a few more months for the animals to really get overweight
- Rick has done epidemiologic studies in humans, high salt intake increases the risk for fatty liver and diabetes
- One study in Japanese adults, high salt also increased the risk for blood pressure
  - Published in *Nutrients* in 2020, [Hyperosmolarity and Increased Serum Sodium Concentration Are Risks for Developing Hypertension Regardless of Salt Intake: A Five-Year Cohort Study in Japan](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7284783/)
- It’s the salt concentration that’s the greatest risk factor for high blood pressure, not the amount of salt one eats or how salty the food is
  - It’s how much salt goes up in the blood.
  - For example, if someone drinks a lot of water and so the salt concentration doesn’t go up, then the effect of salt to raise blood pressure is blunted
  - He did a study in humans where they gave salty soup with or without water
    - Published in the *Journal of Clinical Hypertension* in 2018, [Acute effects of salt on blood pressure are mediated by serum osmolality](https://pubmed.ncbi.nlm.nih.gov/30232829/)
  - If enough water was given to prevent the salt concentration from going up, this could prevent the rise in blood pressure
- Salt increases the salt concentration in the blood, and that activates the osmol pathway
- When salt is given to animals that cannot metabolize fructose, he finds that they eat the same amount of salt, they get that salt, concentration goes up in their blood the same, but they don’t gain weight, they don’t become obese, and they don’t become hypertensive

> “S*o this hypertension and that left ventricular hypertrophy and all these things that are happening, are driven a lot by the conversion of glucose to fructose in the body from the salt*” – Rick Johnson

- So the salt and sugar work together, and then it’s what they’re doing to actually drive the blood pressure response and obesity

## The role of vasopressin in metabolic disease [1:54:00]

**Vasopressin signaling through the V1b receptor drives obesity**

- Now interestingly, when salt concentrations go up in the blood, so does [vasopressin](https://en.wikipedia.org/wiki/Vasopressin)
  - And vasopressin is a hormone that’s produced in the brain that helps to conserve water
- When one eats salt, or sugar, vasopressin levels go up in the blood
  - Fructose induces vasopressin gene expression, Published in the *Journal of Neurophysiology* in 2017, [Role of fructose and fructokinase in acute dehydration-induced vasopressin gene expression and secretion in mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5288484/)
  - The ability of salt to raise blood pressure depends on an increase in serum osmolality, Published in the *Journal of Clinical Hypertension* in 2018, [Acute effects of salt on blood pressure are mediated by serum osmolality](https://pubmed.ncbi.nlm.nih.gov/30232829/)
- And the vasopressin released from the brain goes up in the blood and it helps hold onto water to try to help the body conserve water
- But Rick has recently found that the vasopressin is also helping the fructose to drive fat
- When one eats fructose or salt, the fructose that’s produced from the salt stimulates vasopressin, and the vasopressin binds to a specific receptor called the [V1b receptor](https://en.wikipedia.org/wiki/Vasopressin_receptor_1B)
  - It’s the V1b receptor that is actually important in driving obesity
  - If this receptor is blocked, this can block the effects of sugar to cause obesity, metabolic syndrome and so forth
    - Hydration also blocks these effects by limiting an increase in serum osmolality

![](https://peterattiamd.com/wp-content/uploads/2022/02/f11-rickjohnson2-1024x773.png)

**Figure 11.  The action of vasopressin (AVP) on fructokinase (KHK) can be blocked with increased water intake**  Image credit: [*JCI Insight* 2021](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7821599/)

- Rick took animals where they knocked out the different vasopressin receptors
  - Published in *JCI Insight* in 2021, [Vasopressin mediates fructose-induced metabolic syndrome by activating the V1b receptor](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7821599/)
  - One of these receptors is a vasopressin receptor called 1b (V1b receptor), and no one knows what the function of that receptor is
  - When this receptor is blocked, they had a remarkable finding— the animals could eat all the sugar they want, or they could eat salt, but they won’t get obese because the obesity pathway is driven through that receptor
    - Exactly how the receptor works, he don’t fully know
- The V1b receptor stimulates a hormone called [ACTH](https://en.wikipedia.org/wiki/Adrenocorticotropic_hormone) that stimulates [cortisol steroids](https://en.wikipedia.org/wiki/Corticosteroid)
  - It also stimulates the [islets](https://en.wikipedia.org/wiki/Pancreatic_islets) to produce [glucagon](https://en.wikipedia.org/wiki/Glucagon), which counters the effects of [insulin](https://en.wikipedia.org/wiki/Insulin)
  - And it also works to upregulate the fructose pathways in the liver
- The V1b receptor is expressed in the central nervous system and also in the [adrenal gland](https://en.wikipedia.org/wiki/Adrenal_gland)
  - It’s also expressed in the islet cells in the pancreas
  - In obesity, it seems to be expressed in the liver

**Studies in fructokinase knockout mice and V1b receptor knockout mice**

- Peter asks how this effect compares to the fructokinase knockouts, “i*f you took the fructokinase knockout mice and compared it to the mouse that has normal fructokinase, but just has this receptor [V1b] blocked and you give them the same amount of fructose, glucose, salt, etc., which one is more resistant to the obese phenotype?*”
- The fructokinase knockout tends not to want to eat sugar; they tend to not like fructose
  - One has to kind of force them to eat the fructose
  - But even they are forced to eat the fructose, they’ll never get fat

> “*The V1B receptor knockout (like the fructokinase knockout) they’ll eat a lot of sugar, they won’t get fat*” – Rick Johnson

- Peter asks how they are disposing of the fructose they eat
- They’re totally regulating total caloric intake
  - So although they eat more fructose, they eat less chow; so they maintain their energy balance
- How do they not turn into skinny fat mice where their overall energy balance is fine, but because of the fructose they eat, they should get fatty liver disease and diabetes
  - Rick notes, “*They do not get that. They don’t get fatty liver. They don’t get insulin resistant. They stay normal.*”
- Remember that the metabolic syndrome was driven through the energy depletion pathway; the actual caloric pathway is still intact
  - What we know is that it’s down regulating fructokinase; this is probably the key point
  - The V1B receptor knockout have less fructokinase; they’re turning it off; they’re reducing the amount
- Normally when you eat sugar, the fructokinase levels get higher and higher
  - They get turned on by sugar
- And the V1B knockout doesn’t do that; so the fructokinase stays at a low level
- Rick’s guess is that some of the fructose is being metabolized by other enzymes, like glucose, glucokinase and stuff
- What happens is they eat normal amounts and they stay normal weight and they don’t develop metabolic syndrome, but they don’t turn up their fructokinase

**Vasopressin stimulates fat synthesis to store water**

- Rick’s recent book, just released in February 2022, is [*Nature Wants Us To Be Fat*](https://www.amazon.com/Nature-Wants-Fat-Prevent-Reverse/dp/1637740344/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)
  - This goes into a lot of the stuff discussed in this podcast
  - It provides the next level of insight into fructose metabolism, uric acid, vasopressin, and the sequela that develops
- In the vasopressin story, a very important finding is that when he studied the fructose survival pathway, he found that the fat produced was not just being used as a caloric source, but it was being used as a source for water
  - Because when fat is oxidized, it generates a ton of water ([metabolic water)](https://en.wikipedia.org/wiki/Metabolic_water)
- Animals in the wild, when they store fat, they’re actually storing it not just for calories, but for water
- So the hibernating bear will use the fat as a source of water while they’re hibernating
  - While they’re storing fat, vasopressin levels are high
  - But vasopressin levels plummet during hibernation; that seems to allow them to burn the fat
  - During hibernation, they are making some urine, but their bladders stay permeable and so they reabsorb some of their urine
    - Rick doesn’t think they’re making large amounts of urine; it’s probably because of the low metabolism
    - Because they drop their temperature and their body metabolism so they’re generating less urine
  - But their vasopressin levels typically are turned off during hibernation
- And animals in the desert often have fat in their tails or the camel has a hump, because they don’t want the fat on their body because that would increase the insulation and increase the body temperature
  - But they want to use the fat as a source of water
  - They live in these environments; they do have very high vasopressin levels
- The big breakthrough was to realize that vasopressin is not just holding onto water by reducing the excretion (the volume of urine), but it’s also holding onto water by stimulating fat [synthesis]
  - Vasopressin stimulated fat synthesis through the V1b receptor
- The V1b receptor increases [cortisol](https://en.wikipedia.org/wiki/Cortisol)
  - High cortisol levels can lead to [Cushing Syndrome](https://www.niddk.nih.gov/health-information/endocrine-diseases/cushings-syndrome), these individuals develop kind of metabolic syndrome
- The V1b receptor also stimulates glucagon, which raises glucose
  - This counters some of the effects of insulin; it creates an insulin resistant state
- But also because the fructokinase in the liver seems to increase in the setting where the V1B receptor is activated
- And that may help produce more energy depletion by increasing the enzyme [fructokinase], so that it can really metabolize the fructose as fast as it can
  - Rick thinks that is the mechanism
  - And animals that have the V1B receptor knocked out, they like sugar, they like salt, but they cannot metabolize the fructose very well and they seem to be protected from obesity

§

## Selected Links / Related Material

**Rick’s latest book**: [Nature Wants Us to Be Fat: The Surprising Science Behind Why We Gain Weight and How We Can Prevent–and Reverse–It](https://www.amazon.com/Nature-Wants-Fat-Prevent-Reverse/dp/1637740344/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) By Richard J. Johnson (February 2022) | [1:59:00]

**Rick’s previous books**:

- [The Fat Switch](https://www.amazon.com/Fat-Switch-Richard-Johnson-M-D/dp/0615648002/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Richard J. Johnson (January 2012) | [1:59:15]
- [The Sugar Fix: The High-Fructose Fallout That Is Making You Fat and Sick](https://www.amazon.com/Sugar-Fix-High-Fructose-Fallout-Making/dp/1594866651/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Richard Johnson, Timothy Gower, and Elizabeth Gollub (April 2008) | [22:45]

**Increasing ADP leads to the production of AMP**: [Keeping the home fires burning: AMP-activated protein kinase](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5805978/) | *Journal of the Royal Society* (DG Hardie 2018) | [5:30]

**Review of energy depletion and downstream effects of fructose metabolism (including leaky gut)**: [Fructose and sugar: A major mediator of non-alcoholic fatty liver disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5893377/) | *Journal of hepatology* (T Jensen *et al.* 2018) | [8:15, 14:15]

**The intestine shields the liver from the effects of low amounts of fructose**: [The Small Intestine Converts Dietary Fructose into Glucose and Organic Acids](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6032988/) | *Cell Metabolism* (C Jang *et al.* 2018) | [13:15, 1:23:15]

**Most fructose is metabolized in the liver, comparison of intestinal and liver metabolism**: [Deletion of Fructokinase in the Liver or in the Intestine Reveals Differential Effects on Sugar-Induced Metabolic Dysfunction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7347444/) | *Cell Metabolism* (A Andres-Hernando *et al.* 2020) | [14:15, 40:30]

**The evolutionary importance of fructose metabolism for fat storage and survival**: [Fructose metabolism as a common evolutionary pathway of survival associated with climate change, food shortage and droughts](https://pubmed.ncbi.nlm.nih.gov/31621967/) | *Journal of Internal Medicine* (R J Johnson *et al.* 2020) | [23:45]

**Uric acid activates aldose reductase**: [Uric acid activates aldose reductase and the polyol pathway for endogenous fructose and fat production causing development of fatty liver in rats](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6422088/) | *The Journal of Biological Chemistry* (L G Sanchez-Lozada *et al*. 2019) | [28:00]

**Uric acid stimulates fructokinase expression**:  [Uric acid stimulates fructokinase and accelerates fructose metabolism in the development of fatty liver](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0047948) | *PLoS One* (M A Lanaspa *et al.* 2012) | [29:00; 1:16:00]

**Studies of glucose consumption in animals**:

- [Endogenous fructose production and metabolism in the liver contributes to the development of metabolic syndrome](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3833672/) | *Nature Communications* (M A Lanaspa *et al.* 2013) | [29:00, 35:15]
- [Sugar causes obesity and metabolic syndrome in mice independently of sweet taste](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7473911/) | *American Journal of Physiology Endocrinology and Metabolism* (A Andres-Hernando *et al.* 2020) | [29:00, 35:15; 1:04:00]

**Leptin resistance causes a change in the hypothalamus**: [High salt intake causes leptin resistance and obesity in mice by stimulating endogenous fructose production and metabolism](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5866545/) | *PNAS* (M A Lanaspa *et al.* 2018) | [34:15]

**Effects of glucose consumption in mice lacking fructokinase**: [Endogenous fructose production and metabolism in the liver contributes to the development of metabolic syndrome](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3833672/) | *Nature Communications* (M A Lanaspa *et al.* 2013) | [29:00, 35:45]

**Isocaloric experiment with fructokinase knockout mice**: [Deletion of Fructokinase in the Liver or in the Intestine Reveals Differential Effects on Sugar-Induced Metabolic Dysfunction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7347444/) | *Cell Metabolism* (A Andres-Hernando *et al.* 2020) | [14:15, 40:30]

**Pair feeding study comparing sugar and starch in an otherwise isocaloric diet**: [Sucrose induces fatty liver and pancreatic inflammation in male breeder rats independent of excess energy intake](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3137694/) | *Metabolism* (C A Roncal-Jimenez *et al.* 2011) | [47:30]

**Do mice that lack fructose metabolism live longer?**: [Aging-associated renal disease in mice is fructokinase dependent](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5142232/) | *American Journal of Physiology Renal Physiology* (C A Roncal-Jimenez *et al.* 2016) | [54:15]

**Endogenous production of fructose increases dramatically after consuming a soft drink**: [The extra-splanchnic fructose escape after ingestion of a fructose-glucose drink: An exploratory study in healthy humans using a dual fructose isotope method](https://pubmed.ncbi.nlm.nih.gov/30661675/) | *Clinical Nutrition ESPEN* (C Francey *et al.* 2019) | [57:30]

**Treating NAFLD with fructose restriction**:

- [Hepatic steatosis and increased adiposity in mice consuming rapidly vs. slowly absorbed carbohydrate](https://pubmed.ncbi.nlm.nih.gov/17890486/) | *Obesity* (KB Scribner, DB Pawlak, and DS Ludwig 2007) | [59:15]
- [Effects of Dietary Fructose Restriction on Liver Fat, De Novo Lipogenesis, and Insulin Kinetics in Children with Obesity](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5813289/) | *Gastroenterology* (JM Schwarz *et al*. 2017) | [59:15]
- [The role of fructose in the pathogenesis of NAFLD and the metabolic syndrome](https://pubmed.ncbi.nlm.nih.gov/20368739/) | *Nature Reviews Gastroenterology & Hepatology* (JS Lim *et al.* 2010) | [59:15]
- [Effect of a Low Free Sugar Diet vs Usual Diet on Nonalcoholic Fatty Liver Disease in Adolescent Boys: A Randomized Clinical Trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6440226/) | *JAMA* (JB Schwimmer *et al.* 2019) | [59:15]

**First report that fructose could cause fatty liver disease**: [Fructose Consumption as a Risk Factor for Non-alcoholic Fatty Liver Disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2423467/) | *Journal of Hepatology* (X Ouyang *et a l.* 2008) | [1:00:15]

**A low fructose diet increases mitochondrial biogenesis in people**: [Low fructose and low salt diets increase mitochondrial DNA in white blood cells of overweight subjects](https://pubmed.ncbi.nlm.nih.gov/23934680/) | *Experimental and Clinical Endocrinology & Diabetes* (R Hernandez-Rios *et al.* 2013) | [1:09:15]

**Effects of oral fructose in children**: [Oral fructose absorption in obese children with non-alcoholic fatty liver disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4948988/) | *Pediatric Obesity* (L S Sullivan *et al.* 2015) | [1:12:45]

**Uric acid increases expression of aldose reductase**: [Uric acid activates aldose reductase and the polyol pathway for endogenous fructose and fat production causing development of fatty liver in rats](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6422088/) | *The Journal of Biological Chemistry* (L G Sanchez-Lozada *et al.* 2019) | [1:16:15]

**Review of risks from liquid sugars**: [Are Liquid Sugars Different from Solid Sugar in Their Ability to Cause Metabolic Syndrome?](https://pubmed.ncbi.nlm.nih.gov/31054268/) | *Obesity* (G Sundborn *et al.* 2019) | [1:17:30]

**Pediatric society recommendations for fruit juice consumption by children**: [Fruit Juice in Infants, Children, and Adolescents: Current Recommendations](https://publications.aap.org/pediatrics/article/139/6/e20170967/38754/Fruit-Juice-in-Infants-Children-and-Adolescents) | *Pediatrics* (MB Heyman and SA Abrams 2017) | [1:20:30]

**Effects of a low sugar diet with and without fruit**: [The effect of two energy-restricted diets, a low-fructose diet versus a moderate natural fructose diet, on weight loss and metabolic syndrome parameters: a randomized controlled trial](https://pubmed.ncbi.nlm.nih.gov/21621801/) | *Metabolism* (M Madero *et al.* 2011) | [1:23:00]

**Dried fruits contain fewer micronutrients**:

- [From plums to prunes: influence of drying parameters on polyphenols and antioxidant activity](https://pubmed.ncbi.nlm.nih.gov/12769544/) | *Journal of Agriculture and Food Chemistry* (A Piga, AD Caro, and G Corda 2003) | [1:25:00]
- [Alterations in fruit and vegetable β-carotene and vitamin C content caused by open-sun drying, visqueen-covered and polyethylene-covered solar-dryers](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2141613/) | *African Health Sciences* (J Ndawula *et al*.  2004) | [1:25:00]
- [Effect of Passive Drying on Ascorbic Acid, α-Tocopherol, and β-Carotene in Tomato and Mango](https://pubmed.ncbi.nlm.nih.gov/29624695/) | *The Journal of Food Science* (JC Smith *et al.* 2018) | [1:25:00]

**Dried fruits contain a greater antioxidant capacity than fresh fruits**:

- [Dried Fruits: Excellent in Vitro and in Vivo Antioxidants](https://pubmed.ncbi.nlm.nih.gov/15670984/) | *Journal of the American College of Nutrition* (JA Vinson *et al.* 2005) | [1:25:00]
- [Is Eating Raisins Healthy?](https://www-ncbi-nlm-nih-gov.gate.lib.buffalo.edu/pmc/articles/PMC7019280/) | *Nutrients* (A Olmo-Cunillera *et a l.* 2020) | [1:25:00]

**Essential fructosuria, medical condition where fructokinase is not active**:

- [Essential benign fructosuria](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2012767/) | *Archives of Disease in Childhood* (Z Laron 1961) | [1:27:30]
- [Prevalence and cardiometabolic correlates of ketohexokinase gene variants among UK Biobank participants](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7901775/) | *PLoS One* (JA Johnston *et al*. 2021) | [1:27:30]

**News report on Pfizer’s development of a fructokinase inhibitor**: [Pfizer dumps midphase NASH prospect, slew of early efforts in Q2 clear-out](https://www.fiercebiotech.com/biotech/pfizer-dumps-midphase-nash-prospect-quarterly-pipeline-cull) | Nick Paul taylor, Fierce Biotech (July 28, 2021) | [1:29:30]

**Pfizer’s drugs in development to treat fatty liver disease**: [Meet the Team: Homegrown Therapies Get Ready to Fight NASH](https://www.pfizer.com/disruptive-science/meet-team-homegrown-therapies-get-ready-fight-nash) | pfizer.com (2022) | [1:29:45]

**The role of inflammation in hypertension**:

- [Low-fructose diet lowers blood pressure and inflammation in patients with chronic kidney disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3350341/) | *Nephrology Dialysis Transplantation* (A Brymora *et al.* 2011) | [1:41:45]
- [Role of the Immune System in Hypertension](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6151499/) | *Physiological Reviews* (B Rodriguez-Iturbe, H Pons, and R J Johnson 2017) | [1:41:45]

**Effects of reducing uric acid on blood pressure in adolescents**: [Effect of allopurinol on blood pressure of adolescents with newly diagnosed essential hypertension: a randomized trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2684336/) | *JAMA* (D I Feig, B Soletsky, and R J Johnson 2008) | [1:42:45]

**Raising uric acid levels in rats causes high blood pressure**: [Uric acid-induced endothelial dysfunction is associated with mitochondrial alterations and decreased intracellular ATP concentrations](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3656428/) | *Nephron, Experimental Nephrology* (L G Sanchez-Lozada *et al.* 2012) | [1:42:45]

**Uric acid produced by fructose metabolism contributes to high blood pressure and metabolic disease:** [Excessive fructose intake induces the features of metabolic syndrome in healthy adult men: role of uric acid in the hypertensive response](https://pubmed.ncbi.nlm.nih.gov/20029377/) | *International Journal of Obesity* (S E Perez-Pozo *et al*. 2010) | [1:43:00]

**Epidemiological study shows an association between high fructose intake and higher blood pressure**: [Increased fructose associates with elevated blood pressure](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3013529/) | *Journal of the American Society of Nephrology* (D I Jalal *et al.* 2010) | [1:48:15]

**A high salt diet increases endogenous fructose production**: [High salt intake causes leptin resistance and obesity in mice by stimulating endogenous fructose production and metabolism](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5866545/) | *PNAS* (M A Lanaspa *et al.* 2018) | [1:49:00]

**Expression of aldose reductase is increased in response to increased osmolality**: [Characterization of the osmotic response element of the human aldose reductase gene promoter](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC38723/) | *PNAS* (B Ruepp *et al.* 1996) | [1:51:15]

**Epidemiological study of high salt diet in Japanese Men**: [Hyperosmolarity and Increased Serum Sodium Concentration Are Risks for Developing Hypertension Regardless of Salt Intake: A Five-Year Cohort Study in Japan](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7284783/) | *Nutrients* (M Kuwabara *et al.* 2020) | [1:52:30]

**Salt increases blood pressure and vasopressin levels only when serum osmolality increases**: [Acute effects of salt on blood pressure are mediated by serum osmolality](https://www-ncbi-nlm-nih-gov.gate.lib.buffalo.edu/pmc/articles/PMC8030773/) | *Journal of Clinical Hypertension* (M Kanaby *et al.* 2018) | [1:53:00]

**Fructose induces vasopressin gene expression**: [Role of fructose and fructokinase in acute dehydration-induced vasopressin gene expression and secretion in mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5288484/) | *Journal of Neurophysiology* (Z. Song *et al.* 2017) | [1:54:15]

**Vasopressin is a fat hormone and works via the V1b receptor (vasopressin paper)**

[Vasopressin mediates fructose-induced metabolic syndrome by activating the V1b receptor](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7821599/) | *JCI Insight* (A Andres-Hernando *et al.* 2021) | [1:55:00]

**Reducing uric acid can almeroliate disease caused by fructose metabolism:**

- [Effects of allopurinol on endothelial dysfunction: a meta-analysis](https://pubmed.ncbi.nlm.nih.gov/24751886/) | *American Journal of Nephrology* (M Kanbay *et al.* 2014)
- [Renal oxidative stress induced by long-term hyperuricemia alters mitochondrial function and maintains systemic hypertension](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4396880/) | *Oxidative Medicine and Cellular Longevity* (M Cristobal-Garcia *et al.* 2015)

**The role of uric acid in hypertension**:

- [Uric acid-induced endothelial dysfunction is associated with mitochondrial alterations and decreased intracellular ATP concentrations](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3656428/) | *Nephron, Experimental Nephrology* (L G Sanchez-Lozada *et al.* 2012)
- [Uric acid and the origins of hypertension](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7556347/) | *The Journal of Pediatrics* (D I Feig *et al.* 2013)
- [Uric Acid and Hypertension: An Update With Recommendations](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7368167/) | *American Journal of Hypertension* (L G Sanchez-Lozada *et al.* 2020)

**Endogenous fructose production and the contribution of fructose metabolism to disease**: [Endogenous fructose production: what do we know and how relevant is it?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6684314/) | *Current Opinion in Clinical Nutrition and Metabolic Care* (A Andres-Hernando, RJ Johnson, and MA Lanaspa 2019)

[**Nutraceutical**](https://en.wikipedia.org/wiki/Nutraceutical) [**Osthol**](https://en.wikipedia.org/wiki/Osthol) **ameliorates disease induced by a high-fat/high-sugar diet in rats**: [Osthol Ameliorates Kidney Damage and Metabolic Syndrome Induced by a High-Fat/High-Sugar Diet](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7957708/) | *International Journal of Molecular Sciences* (F E Garcia-Arroyo *et al*. 2021)

§

## People Mentioned

- [Joshua Rabinowitz](https://chemistry.princeton.edu/faculty/joshua-rabinowitz) (research on fructokinase in the gut) [15:00]
- [David Ludwig](https://www.drdavidludwig.com/) (MD PhD at [Harvard](https://www.childrenshospital.org/research/researchers/l/david-ludwig) studies obesity) [59:15]
- [Robert Lustig](https://robertlustig.com/) (MD at [UCSF](https://profiles.ucsf.edu/robert.lustig) studies regulation of energy balance) [59:15]
- [Miriam Vos](https://news.emory.edu/tags/expert/miriam_vos/index.html) (MD at [Emery](https://hip.emory.edu/faculty/bios/vos_miriam.html) studies fatty liver disease) [59:15]
- [Robert (Bob) Cade](https://en.wikipedia.org/wiki/Robert_Cade) [developed Gatorade) [1:18:30]

§

![](https://peterattiamd.com/wp-content/uploads/2022/02/bio-image-rickjohnson2-500x500.jpeg)

##### Rick Johnson, M.D.

Richard Johnson is a [professor of medicine in the Department of Nephrology at the University of Colorado](https://som.ucdenver.edu/Profiles/Faculty/Profile/9426) since 2008 and he’s spent the last 19 years being a division chief across three very prestigious medical schools. An unbelievably prolific author, Rick has well over 700 publications in JAMA, New England Journal of Medicine, Science, et Cetera. He’s lectured across 40 countries, authored two books, including The Fat Switch, and has been funded extensively by the National Institute of Health (NIH). His primary focus in research has been on the mechanisms causing kidney disease, but it was in doing this that he became really interested in the connection between fructose (and fructose metabolism) and obesity, diabetes, heart disease, hypertension, and metabolic disease.