# #81 – Debra Kimless, M.D. & Steve Goldner, J.D.: Cannabis – the latest science on CBD & THC

**Source:** [https://peterattiamd.com/debrakimless-stevegoldner/](https://peterattiamd.com/debrakimless-stevegoldner/)

---

In this episode, Dr. Debra Kimless and Steve Goldner share their knowledge on the science, policy, and market evolution of medicinal cannabis. We start with the differences between THC and CBD, how they work in the body, and how they act on the brain. We discuss the many potential benefits of using CBD, THC, hemp in the various forms of administration (smoking, vaping, edibles, oils, etc.) as well as some of the safety issues including the recent uptick in incidents of hospitalization and death linked to vaping. Debra and Steve are both involved with the company, [Pure Green](https://pure.green/)—Debra the Chief Medical Officer and Steve the founder and CEO—whose aim is to create the safest, most efficacious form of delivery of cannabis. Their bigger mission is to shift the perception of the cannabis plant, garner acceptance of its medicinal benefits, and ultimately get it descheduled on a federal level so more people can access cannabis for a range of chronic ailments.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/debrakimless-stevegoldner/the_Drive_public.png)

Play

#81 - Debra Kimless, M.D. & Steve Goldner, J.D.: Cannabis – the latest science on CBD & THC

#81 - Debra Kimless, M.D. & Steve Goldner, J.D.: Cannabis – the latest science on CBD & THC

1x15s30s

0:002:11:35

## We discuss:

- Debra and Steve’s background reason for their interest in medical cannabis [7:00];
- The history of medical use of cannabis [11:15];
- How THC, CBD, and other cannabinoids work [16:00];
- Hemp—What it is, special uses, and the 2018 farm bill [22:45];
- The legal status of CBD, Deb and Steve’s clinical trial, and how CBD differs from THC [30:15];
- The safety profile of THC [35:00];
- Is marijuana as a gateway drug? [45:30];
- Smoking vs. vaping vs. edibles—Benefits, risks, and mechanistic differences [53:30];
- Can you build up a tolerance to the effects of THC? [1:15:00];
- What do people generally want to get from using marijuana? [1:17:15];
- Cannabinoid synthetics [1:22:30];
- Efficacy of CBD oils as a sleep aid [1:25:00];
- Pure Green Cannabis [1:30:30];
- Anecdotal evidence and managing the hype surrounding cannabis in medical treatment [1:38:45];
- Aspirations for the future of medicinal cannabis, and the legal challenges that await them [1:45:15];
- Descheduling cannabis: A human rights issue [2:04:00] and;
- More.

§

## Show Notes

## Debra and Steve’s personal motivation in medical cannabis research [7:00]

- Debra started to consider non-pharmaceutical options as a pain reliever when her mother was dying from a pharmaceutical drug complication
- From 2013, she has investigated cannabis as a medicinal molecule
- She treats patients with cannabinoid medicines free of charge, sharing her findings with colleagues
- Steve began his career formulating [methadone](https://en.wikipedia.org/wiki/Methadone) for Vietnam War veterans, who returned addicted to drugs
- He now develops different cannabis derived formulations to help people with PTSD and pain management
  - Became interested in cannabis as a medicine 45 years ago to address PTSD symptoms
  - Noticed that his friend with [PTSD](https://www.mayoclinic.org/diseases-conditions/post-traumatic-stress-disorder/symptoms-causes/syc-20355967) felt better when he smoked cannabis and realized it could be a medicine but was not (yet) legal
  - Vowed to develop the cannabis medical and research space after his friend died of liver cirrhosis seven years ago

> “… developing methadone at the beginning of my career was a first bookend and now developing all these formulations to help people with cannabis is the second book end on my career” – Steve Goldner

- The two met at  [IACM](https://www.cannabis-med.org/?lng=en)  two years ago and now work together in venture (Pure Green Canna) to create the safest and most effective system to deliver medical cannabis

##

## The history of medical use of cannabis [11:15]

> “..it’s not a new medication. In Asia, the king fancied himself a pharmacist and he was treating people for all sorts of disorders, from gout to absent memory…The ancient Greeks used it topically on their horses, which is why I do know that the acid forms of cannabis medicine actually work because they love their warhorses. They applied the cannabis leaves to the horses bodies to reduce swelling, inflammation, and infection after a war or a battle” – Dr. Debra Kimless, M.D.

- Cannabis has been used as a medicine for over 5,000 years
- Leaves – with small amounts of [trichomes](https://en.wikipedia.org/wiki/Trichome)– were applied to horses in order to relieve pain
- Indian use would mix cannabinoids with heated milk – called [Bhang](https://www.alchimiaweb.com/blogen/bhang-lassi-cannabis-milk-shake/) – which was consumed orally as an anesthetic
- The medicinal plant then became associated with drug policy around the 1930s
  - Political inclination towards controlling people’s behaviors around drinking and recreational drug
  - Marijuana became associated with **THC** intoxication and smoking
  - The case against marijuana: led by the **Nixon administration** and propelled as part of the [United Nations](https://www.un.org/en/) (UN) [War on Drugs](https://news.un.org/en/tags/war-drugs)
  - DEA designated it as a Schedule I (“no accepted medicinal use”) narcotic drug
  - People who utilized marijuana became disenfranchised

##

## How THC, CBD, and other cannabinoids work [16:00]

> “when it grows in nature, it grows as a flower. The leaf does have some cannabinoids in it or some of those medicines in it, but really the most bang for your buck, it comes from the flower where that’s what it is” – Dr. Debra Kimless, M.D.

- Grows as a flower in nature
- The leaf has some **cannabinoids** in it but most medicine is derived from the flower

![](https://peterattiamd.com/wp-content/uploads/2019/11/cannabis1.jpg)

**Figure 1****. The cannabis plant.** Image Credit: [curealeaf.com](https://www.curaleaf.com/botany-of-cannabis/)

> “The interesting thing is that you can eat the cannabis plant all day long. You may get a bellyache from all the fiber, but you won’t get that intoxicating feeling because its chemical constituents are not in a way that can get you intoxicated” – Dr. Debra Kimless, M.D.

- Can eat the plant without intoxication
- The two most significant ingredients in cannabis are:
  - Tetrahydrocannabinol [(THC)](https://en.wikipedia.org/wiki/Tetrahydrocannabinol)
  - **[Cannabidiol (CBD)](https://en.wikipedia.org/wiki/Cannabidiol)**

***THC***

- Binds to both **CB1** and **CB2 receptors** (found peripherally on immune cells and on other tissues and organs)
  - CB1 is predominantly in the brain and other nerves in the peripheral nervous system
  - CB2 is predominantly a peripheral receptor for cannabinoids

> “So our brains have these sort of docking stations called receptors and chemicals act on different docking stations or receptors in order to affect a change. So THC works on these docking stations in our brain and our peripheral nervous system, known as CB1 receptor, cannabinoid one receptor…” – Dr. Debra Kimless, M.D.

![](https://peterattiamd.com/wp-content/uploads/2019/11/cannabis2-1024x837.png)

**Figure 2.** **The endocannabinoid system in the CNS.** Image credit:  [(Friedman et al. 2019)](https://www.download.thelancet.com/journals/laneur/article/PIIS1474-4422(19)30032-8/fulltext)

- THC produces the “high” associated with marijuana
- Effect of THC depends on where receptors are located:
  - may stimulate areas in hippocampus region to extinguish memory (indication for PTSD)
  - may interfere centrally with **periaqueductal gray areas** that conduct pain signaling

> “So depending upon where in those receptors are located, will determine what happens. So for example, if it’s in the hippocampus, it may stimulate areas in that area that will help you extinguish memory. So for people with PTSD who cannot stop thinking about certain things, that area of the brain extinguishes memory and helps somebody with PTSD maybe to get some sleep” – Dr. Debra Kimless, M.D.

- For pain management:
  - Interferes with periaqueductal gray areas and also works peripherally on immune cells to decrease inflammation and reduce **cytokine expression**

*THC works in multimodal ways…*

- Medicine does not work on a single target in a biologic system

> “We’re used to thinking in medicine actually as an allopath of a single molecule single target. But what you really learn is that that’s a great way of understanding how a drug could work. But that’s not how it works in a biological system known as a person or an animal” – Dr. Debra Kimless, M.D.

*Inhaling marijuana elicits an increase in appetite because …*

- Areas in brain (medulla) that control appetite have many CB1 receptors which get stimulated by THC inhalation
- Has therapeutic applications for patients undergoing chemotherapy/has wasting syndrome

**CBD**

- Always been in the plant and available but has previously been overlooked b/c people more interested in THC for it’s intoxication effects
- In the last 2-3 years CBD has come to the forefront because:
  - It *does not* have intoxication effects like THC
  - But it *does* have medicinal applications

> “It’s just really in the last two or three years that CBD, because of its non hallucinogenic effects, has become interesting to people because it appears to have, it does have, so many medicinal applications and at the same time doesn’t get a person stoned” – Steve Goldner

- CBD does not sit directly on CB1/2 receptors
- It either works on the endocannabinoid system indirectly or on different receptors
- It works synergistically with THC and is an effective medicine on its own
- **Neither THC or CBD actually exists in nature**:  It requires the application of time and temperature to remove a carboxyl group from the cannabinoid

![](https://peterattiamd.com/wp-content/uploads/2019/11/cannabis3.jpg)

**Figure 3.** **The cannabinoids THC and CBD originally have an additional carboxyl group attached, beginning as THCA and CBDA. With a carboxyl group attached, neither THCA and CBDA are psychoactive as they cannot effectively bind to our cannabinoid receptors. In order to be bioavailable to our endocannabinoid system, these cannabinoid molecules must undergo decarboxylation.** Image Credit: [**medium.com**](https://medium.com/@consultants/cannabis-decarboxylation-explained-why-its-important-and-how-to-do-it-de09c9f6d670)

- Can grow in varying concentrations depending on plant strain

##

## Hemp—What it is, special uses, and the 2018 farm bill [22:45]

- **The** [**2018 United States farm bill**](https://en.wikipedia.org/wiki/2018_United_States_farm_bill)
- **Read more specifically about how hemp was impacted here:** [**Hemp Farming Act of 2018**](https://en.wikipedia.org/wiki/Hemp_Farming_Act_of_2018)

> “Congress decided, pushed forward by several legislators who had large numbers of farmers, that this would be a really good cash crop for them. When you think of it, these products are selling for thousands of dollars a pound compared to 50 cents or a dollar a pound for lettuce or tomatoes. So if you’re a farmer, you’d much rather grow something that you can get thousands of dollars for” – Steve Goldner

- A number of legislators – particularly [Senator McConnell](https://en.wikipedia.org/wiki/Mitch_McConnell) **–**  had farmers in jurisdiction
- Aimed to develop cannabis as a well-regulated source of product domestically (v. overseas)
- Idea was to bring U.S. Department of Agriculture ([USDA](https://www.usda.gov/)) and other scientific bodies like the Federal Department of Agriculture ([FDA](https://www.fda.gov/home)) together in order to study the products and help the growers to advance their product
- Provided legal cover for farmers to grow hemp and for processors to process it into other products
- **Hemp** is a classification of cannabis: defined as having less than 0.3% THC

*Products that can come from the hemp plant…*

- Vape cartridges
- Lotions
- Creams
- Ointments
- Cannabinoid additives in foods and in drinks
- Hemp seeds are high in [omega-3](https://en.wikipedia.org/wiki/Omega-3_fatty_acid) and [omega-6](https://en.wikipedia.org/wiki/Omega-6_fatty_acid) fatty acids and protein

> “The Farm Bill really provided legal cover for farmers to be able to grow the hemp and then to be able for processors then to be able to process it into oil and be able to turn it into other products. So it started out as something to just aid farmers, but now it is moving through the economic distribution chain and that’s why we can see it now in nearly every drugstore or big box store as finished goods on the shelf” – Steve Goldner

*Other uses of hemp beyond the cannabinoid …*

- Hemp fiber has a tensile strength of steel or greater
  - Plastic goods can be substituted for hemp by displacing the petroleum in plastic
- Hempcrete is can be used instead of concrete
- Can also make clothing with hemp
- In 1930, Henry Ford even developed a [hemp mobile](https://www.verymagazine.org/magazine/216-overview-issue20/877-henry-fords-hemp-car-1941) – a car fueled by hemp oil instead of gasoline
  - Had to stop when the marijuana plant became illegal

Hemp is still mostly for CBD

- Most hemp today is used for CBD because that is where the money is for now
  - The machinery (a [decortication machine](https://en.wikipedia.org/wiki/Decorticator)) is used to break down the plant stock
  - Machinery is very expensive right now
  - It is easier to extract CBD and make derivative products than it is to industrial products from the plant

##

## The legal status of CBD, Deb and Steve’s clinical trial, and how CBD differs from THC [30:15]

*The legal status of CBD*

- The 2018 Farm Bill legalized the industrialization of the hemp plant but it did not legalize CBD products
- CBD is still state regulated
- Federal regulation is continuing to unfold

**Deborah’s clinical trial with CBD**

- Deborah spoke to the FDA to advocate for CBD product legalization
- She spoke about her clinical trial using a water-soluble CBD for mild to moderate pain
- It was a “proof of concept study”
- It was a 16-patient cohort
- 5mg CBD with [terpenes](https://en.wikipedia.org/wiki/Terpene) in a tablet given to 16 patients over a 14-day period
- Demonstrated a statistically significant decrease in pain across all 16 patients
- No placebo control

*How does CBD differ from THC other than the intoxication effect?*

- CBD works in different mechanisms of action for pain relief: does not sit on CB1 receptors but interacts with endogenous endocannabinoids that sit on these receptors
- Interacts with dopamine, norepinephrine, epinephrine-type receptors and enhances them

![](https://peterattiamd.com/wp-content/uploads/2019/11/cannabis4.png)

**Figure 4.** **THC and CBD mechanisms of action on CB1 and CB2 receptors.** Image credit: [(Castle et al., 2018)](https://psychscenehub.com/psychinsights/psychopharmacology-cannabis-and-mental-health/)

- There are over 100 different cannabinoids and over 80 [**terpenes**](https://en.wikipedia.org/wiki/Terpene), flavonoids, and other constituents in the plant

*What do the terpenes do?*

- Give taste and scent to plants
- Natural pesticide for the plant
- Anti-inflammatories
- Antioxidants

##

## The safety profile of THC [35:00]

> “So I think everybody is different. We’re all an N of one, and we all respond differently to the same type of thing” – Dr Debra Kimless, M.D.

*Health risks …*

- May cause severe anxiety of panic
- Rapid heartbeat or rise in blood pressure
- This can be dose-dependent
- The setting is important as well

*Safety…*

- THC has the lowest toxicity potential compared to other drugs
- Do not have any deaths or truly serious events that are attributed to THC or CBD
- W*hat is the* [*LD50*](https://simple.wikipedia.org/wiki/LD50) *of THC*?
  - Never been possible to dose enough to kill animal models so there is a 5g/kg cutoff (which is a huge amount)

> “In my experience, this has the lowest toxicity potential of any pharmaceutical, nearly of almost any product I’ve ever seen. In the course of history, we really do not have any deaths or truly serious events that are attributed to THC or CBD at all. It is so less toxic than what are common over-the-counter drugs, aspirin, Tylenol, etcetera, and certainly far and away compared to alcohol, which is truly toxic.” – Steve Goldner

*To make the point for very low toxicity…*

- In support of rescheduling cannabis the 70’s, an attorney for the DEA cited how cannabis does not have a [LD-50](https://simple.wikipedia.org/wiki/LD50)
  - There are no CB1 receptors in the cardio-respiratory centers of our brain  so breather and heart rate does not stop or slow
  - There is not a known upper limit of toxicity from a cardio-respiratory standpoint
  - The LD-50 of ethanol in rats is [7060 mg/kg](https://cures.lmu.edu/wp-content/uploads/2016/07/M4_L4.1_S_Key_Final-1.pdf)
  - The [Therapeutic index](https://en.wikipedia.org/wiki/Therapeutic_index) for cannabis is about 1 to 20,000 (very safe)
    - Aspirin, for example, is a 1 to 20 index (take 2 aspirin for your headache, take 40 you’ll be rushed to the hospital)
    - Valium is ~1 to 10
    - Alcohol ⇒ “3 drinks won’t kill anyone, but 30 will kill anybody”

*Despite the very low acute risk to health…*

- During prohibition, the sociology of the time supported alcohol being brought back into favor but not marijuana
- Cannabis was not brought back because it may have been too out of reach (not widely used as was alcohol)

##

## Is marijuana as a gateway drug? [45:30]

> “I always say that cannabis is a gateway more towards health than to other drugs.”

- The National Institute of Drug Abuse ([NIDA](https://www.drugabuse.gov/)) no longer considers cannabis a “[Gateway drug](https://en.wikipedia.org/wiki/Gateway_drug_effect)”
- Colorado (the first state to legalize cannabis) has not displayed an enhanced utilization of cannabis from the black market
- States with medical legal programs have seen a reduction in opioid prescriptions in patients who have access to medical dispensaries

*If marijuana precedes harder drugs like heroin, does that mean the use of marijuana “causes” use of hard drugs?*

- Marijuana use preceding “harder” drugs like cocaine and heroin may be true, but it does not mean that marijuana leads to other drug use…
- Marijuana is more readily available but causality for later drug addiction is not supported

> “Marijuana is generally more available than any of these other perhaps hardcore drugs, so it may appear that people are starting with marijuana, but frankly you can get cigarettes on every street corner. So therefore, I think we should blame cigarettes more for beginning this inappropriate behavior that is sometimes addictive. I don’t think that marijuana itself, cannabis in any way causes or leads people on into, let’s call it more hardcore drug addiction” – Steve Goldner

*How addictive is THC?*

- THC addictive capacity is below alcohol
- [Animal studies](https://www.ncbi.nlm.nih.gov/pubmed/24897085) show a 9% addictive percentage of THC

THC and CBD as an “exit drug”

- Medical centers are using CBD and THC in combination as an exit drug for other more highly addictive substances

*What about the danger of using THC in a young person (e.g., 15 years old) whose brain is still developing?*

- There are no robust (double blind, randomized, controlled) trials that have evaluated THC effect on a developing brain
- If utilized as a medicine (rather than recreational inhalation), cannabis could be an appropriate choice for a young person with health ailments (e.g., seizure disorder, depression)

##

## Smoking vs. vaping vs. edibles—Benefits, risks, and mechanistic differences [53:30]

> “So your bioavailability in an inhalational method is fast and furious. You miss the whole GI tract, which is great. So if you’re somebody with MS and has muscle spasm that’s acute, inhalation method could be a godsend for them, for sure. You’re right that the length or duration of action is a lot shorter than other methods of administration. So if you’re somebody with a chronic pain issue, that’s probably not your method of administration that you want to employ. Yes, you get products of combustion, so if you’re smoking plant material, you have a whole bunch of other things, no differently than tobacco, that can cause some issues” – Dr. Debra Kimless, M.D.

**Inhaled administration: (e.g., smoking)**

- Time to effect is fast as GI tract is skipped
  - So for long term chronic pain, inhalation probably not preferred method
- However, [one study](https://www.atsjournals.org/doi/abs/10.1513/AnnalsATS.201212-127FR) reports that smoking cannabis flower does not have an association with lung cancer
  - Reason for why is not clear – [one study](https://harmreductionjournal.biomedcentral.com/articles/10.1186/1477-7517-2-21) suggests that it could be anti-inflammatory effects of cannabinoids – but it is not recommended that patients who utilize for chronic pain inhale
- Debra does NOT recommend the inhalation method for her patients
  - We know heat causes cellular change
  - It is difficult to help titrate the dose via inhalation administration (e.g., a shallower versus a deeper inhalation provides a different dose)

**The dangers of vaping:**

- [Vaping](https://en.wikipedia.org/wiki/Electronic_cigarette) is inhalation method using an electronic cigarette
- But works at a lower temperature compared to a bong (via [pyrolysis](https://en.wikipedia.org/wiki/Pyrolysis))

Recently, vaping has lead to [acute respiratory distress syndrome](https://www.nytimes.com/2019/08/31/health/vaping-marijuana-ecigarettes-sickness.html) outbreaks

- This is like a chemical burn to the lungs
- Puts people into the ICU on incubators
- The oil to put in a cartridge is too thick so substances are used to thin the extracted cannabis in order to be inhaled
- These substances (Propylene Glycol (PG),polyethylene glycol 400 (PEG),α-Tocopheryl acetate (vitamin E acetate)) are GRAS (generally regarded as safe) to ingest
- But we do not know if they are safe to be heated and inhaled (and they may be a big problem)
- Thousands have been hospitalized
- Over 34 deaths directly attributed to vaping

- The epidemiologic loci for the chemical burn cases have not yet been clearly identified by the Center for Disease Control (CDC)

Peter asks: *So we have no idea if the uptick in these acute toxicities is potentially manufacturing related, loci related, diffuse. We don’t know any of those things yet?*

- “That’s exactly correct” answers Steve
- At the moment, there may be thousands in the hospital, and 30+ deaths, but it’s a small percentage of the millions of uses of vaping
- And there seems to be no clear cut cause

*Why isn’t the FDA policing the creation of cannabis cartridges that may be causing the cases of lung issues and death?*

- Because marijuana is still federally illegal therefore the FDA is not involved
- It would be up to the states to police this which they are not set up to do

**Chronic toxicity of vaping?**

*Aside from the recent acute events of toxicity related to vaping cannabis are there any chronic toxicity concerns?*

- Was not until the popularity of vaping through the e-cigarette market that the cannabis market got involved in vaping
- There is limited robust data to answer the chronic toxicity concern

**If someone was arguing in favor of vaping, what would they say?**

- Better than smoking b/c no combustion
- Helps withdrawal from nicotine
- Immediate relief from acute pain issues

**Edibles**

*How come simply eating the raw cannabis flower would get you high?*

- Vaping/combusting the product works quickly because the chemical constituents are heated
- People only get high consuming edibles because the plant chemicals are heated in the baking process

![](https://peterattiamd.com/wp-content/uploads/2019/11/cannabis5-1-1024x770.jpg)

**Figure 5****.  THCA can be transformed in THC after heating (decarboxylation). Taking the combined trendline into account, it would need 3 hours at 100 °C to convert THCA fully into THC and 4 hours at 98 °C.** Image Credit: [thehempchronicle.com](https://thehempchronicle.com/topic/decarboxylation-tetrahydrocannabinolic-acid/)

- When the chemicals are heated, that is when they are able to sit on receptors (CB1/2) that make someone feel high/intoxicated
- For intoxication, heat and time is always required (in order to make THC)
- With edibles, aside from the preparation, there are a lot of variables that can vary from person to person and thus, impact the response to consumption:
  - Body mass
  - Digestion
  - Time of day
  - Individual response to THC or CBD

> “And the variables for the edibles is not just the preparation of the food, but that our digestive process varies from hour to hour, person to person, as well as our body mass and how we feel about things and what the time of day and the circadian rhythm. So it’s almost impossible to expect out of eating any food that contains THC or CBD to expect you will get a reliable, repeatable dosage experience from that, even if the label is completely correct and completely accurate” – Steve Goldner

*Why are edibles more intoxicating that smoking?*

- When the chemical constituents are consumed via the GI track, it is the THC metabolite rather than THC itself
- the metabolite is much more intoxicating

*What are the best use cases for edibles?*

- Best use case for edibles are for someone with chronic pain (i.e., too much pain to sleep at night)
- The bioavailability takes 60-90 minutes
- In the best case scenario, only get about 8% of whatever you ingesting
- But it can have a 8-10 hour duration

##

## Can you build up a tolerance to the effects of THC? [1:15:00]

*Can you increase your tolerance to THC by taking it over time?*

- THC sits on docking stations and these receptors and there are chances of over consuming THC and down regulating these receptors
- It actually can be reset very quickly by just stopping for a couple of days

One study out of the Netherlands reported that patients stabilized at 750 mg of cannabis a day indicating that there is not an occurrence of [tachyphylaxis](https://en.wikipedia.org/wiki/Tachyphylaxis) (diminishing response to successive dosing)

- This is in contrast to opiates:
  - In the case of opiates, the docking stations down-regulate quickly, requiring an increase  to achieve the same effect

- - After a certain amount of opiates, pain gets enhanced: a phenomenon called hyperalgesia
  - Interestingly… THC taken with opiates has been shown to reduce the required amount of opiates for pain relieving efficacy, without tachyphylaxis

##

## What do people generally want to get from using marijuana? [1:17:15]

> “So a little bit of THC won’t cause any intoxication. You need the receptor, you need the drug and you need enough drugs sitting on all of those receptors in order to express those things…I like to use very small amounts of cannabinoids to activate things on a cellular level. So you actually don’t feel the intoxicating effects because most patients don’t want to be sidelined by their pain and they don’t want to be sidelined by their pain medicine” – Dr. Debra Kimless, M.D.

- Rather than intoxication, patients want a sense of relief provided by medicinal cannabis
- Steve did a survey in Michigan from over 400,000 people with medical marijuana cards
  - 75% of people frequenting dispensaries were going for medical reasons (and not to be intoxicated)
  - The use medicinal cannabis to manage severe symptoms
  - People who employ cannabis smoking or vaping for physical and psychological pain relief are able to titrate themselves

*Some (mental) illnesses can be exacerbated by THC…*

- A high dose of THC would have a contraindication for someone with schizophrenia, for example
- But there are over 100 different cannabinoids that could be used without negative effects

##

## Cannabinoid synthetics [1:22:30]

- There is a synthetic THC – [Dronabinol](https://en.wikipedia.org/wiki/Dronabinol) – that has been available in hospitals since the 1980s
  - Used for chemotherapy nausea in some settings but not very successfully
  - THC alone (synthetic) is not easily taken as a result of side effects (in the natural form, it is better modulated with other plant constituents)
- Synthetic CBD molecule from GW pharma called [Epidiolex](https://epidiolex)
  - Plant-derived but isolated and purified to over 90%
  - Requires a large amount to get desired therapeutic response
  - Utilized for two types of seizures
    - for children with rare refractory seizure disorders
    - Drug has [30% reduction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6396837/) in their seizures
  - Brings on GI side effects and liver issues
- Pure Green formulates to capitalize on the synergistic effects of different medications (rather than isolate one molecule to administer)

> “We formulate using isolated cannabinoids, but we joined them together along with other constituents so that we use less and we capitalize on the synergistic effects of a lot of the molecules, no differently than what we do in medicine as an anesthesiologist. We just don’t push one medication. We push a lot of different medications to lower the bad effects of of one particular medicine and capitalize on the good effects of all of them” – Dr. Debra Kimless

##

## Efficacy of CBD oils as a sleep aid [1:25:00]

- “In our experience, it works.” – Steve
- Steve and Debrah believe taking it in a water soluble form is more effective than oil but that oil still works
- Does not seem to produce grogginess that other sleep aids may give

Mechanisms of action are multimodal:

- Anti Inflammatory
- Activates the CNS [GABA receptors](https://en.wikipedia.org/wiki/GABA_receptor)
- Decreases anxiety

*Any effect specific to sleep stages?*

- Although CBD seems to support sleep duration, there is not yet data on sleep architecture (i.e., stages of sleep, duration)
- Because of the illegality of THC medical universities don’t allow research with THC unless someone has a DEA license
- In the last few months, CBD is permitted for research if the THC level is low enough
- Research protocols take a while to be developed, funded, approved

> “…because of the still illegality of THC and the confused legality about all of the others, that pretty much every university, especially medical universities, do not allow research to be done on the facility unless someone has a DEA license. And even then getting the DEA license is a long drawn out process, so that very little work is able to be done. And there are thousands of medical researchers who would love to work on these problems, but they can’t, just like they haven’t been able to for 50 years” – Steve Goldner

##

## Pure Green Cannabis [1:30:30]

Steve is the founder and CEO of [Pure Green Cannabis](https://pure.green/)

- The products that are sold help fund cannabinoid research
- Formulations are put through pilot clinical trials in a small patient population
- With positive response, the products are distributed in state with a license
  - The funds from sales are put into scaling business
  - And to do other studies under FDA regulation

> “We came up with formulations that we felt would work and then we ran pilot clinical trials to see how they would do in a small patient population and once we saw that that was getting a very good response among people, then we were able to distribute the products within the state because we are state licensed to be able to do that and now we are taking the funds from, essentially from that cash flow, and scaling up to be able to do studies under FDA office or spaces, which are frankly much more expensive to do because of all the controls that go along with it” – Steve Goldner

***Pure Green Canna’s water soluble tablet formulation***

- All formulations of CBD and THC are oil soluble
- Pure Green created a water soluble product
- This means that the tablets disintegrate in the mouth and the molecules move into the bloodstream for a very quick acting effect
- Medicinal effect onset takes about 8-10 minutes

*–There are many advantages to sublingual water soluble delivery…*

> “It avoids first pass metabolism. It gets much more of the active drug into the bloodstream and to be distributed throughout the body. So in theory, you could actually lower the levels of drug that are necessary” – Steve Goldner

—**The optimal cocktail for sleep**: The optimal dose is *10mg of CBD and 1 mg THC*

- Pure Green Canna’s tablet formulation follows [the entourage effect](https://en.wikipedia.org/wiki/Entourage_effect) principal…
- Multiple drugs prescribed at the same time or in sequence for treatment

> “We’ve found exactly the same effect and did it by clinical trial of seeing how it would be with patients, getting feedback from them, revising the formulations, re-dosing them and seeing how those effects changed.”

##

## Anecdotal evidence and managing the hype surrounding cannabis in medical treatment [1:38:45]

- There is rationale in support of the “hype”
  - THC and other cannabinoids [have been shown](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3165955/) in the laboratory to have a multimodal effect on cancer
  - THC and other cannabinoids have been demonstrated to reduce apoptosis, migration or metastasis of disease, and neovascularization
- There are no trials to prove the miraculous healing properties of THC and other cannabinoids but there are anecdotal accounts

##

## Aspirations for the future of medicinal cannabis, and the legal challenges that await them [1:45:15]

- Steve wants to see a formulation that will relieve PTSD

> “. I made a vow to do that for people who were heroin addicts and [Methadone](https://en.wikipedia.org/wiki/Methadone) may not be the best of all formulations, but that’s what I did when I was 23 years old and I got a little better as I went along. So that is the driving force for me to be able to do this. And then my goal is to be able to discover as many of these disease conditions, psychological or physical conditions as we can extract value from these stunningly nontoxic molecules” – Steve Goldner

- The company has Investigative New Drug Exemption [INDs](https://www.fda.gov/drugs/types-applications/investigational-new-drug-ind-application) associated with each new derived molecule
- In order to sell a drug in the U.S. a company needs to have an approved new drug application  (NDA) from the FDA
- Prior to selling a drug on the market, it requires an IND

> “In order to sell a drug in the United States, you have to have an approved new drug application that’s called NDA from the food and drug administration. So what do you do before you get that you have to go investigate that drug” – Steve Goldner

- The company is in the IND process with three different therapeutic indications to address:
  - PTSD (anxiety and pain)
  - Pets who suffer from osteosarcoma
  - Human osteoarthritis of the knee
- The company currently has products that are legally sold in Michigan
- The manufactured products work within the medical legal rules in Michigan and can uphold to [GMP manufacturing](https://en.wikipedia.org/wiki/Good_manufacturing_practice)
- To make a new drug from IND to approval is order of magnitude 10 years and $1 billion
  - The company has not yet released a CBD product for sleep due to resource allocation
  - Sleep studies are very expensive and methodologically variable
  - Pain is more easily measurable and scored
- The company has a license in Michigan to process cannabis
- Pure Green Canna takes cannabis that has been grown in state, extract it, turn it into tablets or other consumables, and sell the products to state-authorized dispensaries

> “So it’s quite challenging. We drove at getting a first license and we were successful in getting the first license in Michigan to be a processor. That is we can take in cannabis that’s been grown within the state and turn it into an extractive and then turn that into tablets. That’s what the process of processing is…Historically, people in Michigan needed to have medical marijuana licenses in order to get into those stores, but now like many states, it’s called recreational or adult use” – Steve Goldner

- The company also has subsidiaries to include growing plants and dispensary stores throughout Michigan
- FDA approval is required in order for products to be sold across state lines
- Takes between 2-4 years for products to go through the FDA approval process

> “I was lucky enough to be able to be at the United Nations in 2016 testifying and telling the UN that they should change the war on drug policy from incarceration and retribution to medication and treatment and while things move slowly through the political process, we see that is taking hold in country after country, that this war on drugs policy is changing dramatically” – Steve Goldner

- Products cannot ship from Michigan to Colorado or California – two states with the same legal framework – because it will be in federal land in order to pass into another state (interstate commerce)

*Steve believes that cannabis will gain legal status at a federal level…*

- A possible legal loophole could be to utilize the over-the-counter drug store review used to take products onto drug store shelves for which patients can self-prescribe
  - Many of the products have sufficient safety that make them viable for self-prescribing

> “And this is a remarkable societal experience in allowing nontoxic substances to be used and self prescribed. I think it’s a challenge for the physicians to catch up because you are a learned intermediary to help patients be able to do this” – Steve Goldner

- A few “bad actors” could set the commercial and legal cannabis industry behind

> “…just because you can buy something off the shelf of a big box store or from an online source, that it’s tested and it’s safe because there is no guarantee to that. And so my recommendation in patients is if you live in a legal state, you should buy from a legal dispensary, ask for their certificate of analysis, take a look at it and make sure that there’s no adulterants to the best of our knowledge and the science right now” – Dr. Debra Kimless, M.D.

- Of particular concern is the stigma it could cause for patients and patient safety
- Certificate of analysis inspection by the consumer is important to make sure the quality of what they are buying is good

##

## Descheduling cannabis: A human rights issue  [2:04:00]

- Debra believes that cannabis should be descheduled: it will allow for standardized interstate testing

> “I mean from laboratory to laboratory, there are no standards and the problem is there’s no guidance because it’s been illegal. And so the sources the laboratories would use to go to to say, well where do we get our standards from and what are the methods of extracting from this gummy bear or this brownie? In order to test the potency or test the microbials or to test any of it don’t exist” – Dr. Debra Kimless, M.D.

*Prospective medical users of cannabis should…*

- Go to a legal state
- become certified as a patient
- meet with a physician and receive guidance
- Buy from a legal dispensary

> “I would recommend not buying online. I would recommend not buying off the street. I mean we tell our children don’t take candy from strangers because you don’t know what it is. Why would our medicine be any different?” – Dr. Debra Kimless, M.D.

*Laboratories are now equipped to develop and test cannabinoid products,but interstate guidelines (alignment) are required…*

> “The labs are capable nowadays because I just recently set one up a few years ago of doing remarkably accurate and precise work on all of these cannabinoid products and to be able to do it. But the state rules vary and the states are still learning what should the pesticides be that are allowed or allowable, what are the levels of heavy metals, et cetera. So from state to state, the rules vary and they are getting more learned as the work is done. So this is a great developing field” – Steve Goldner

§

## Selected Links / Related Material

**Steve spent the first part of his career developing and formulating**: [Methadone](https://en.wikipedia.org/wiki/Methadone) | (wikipedia.org)[8:45]

**Steve developed and formulated Methadone to help war veterans**: [PTSD](https://www.mayoclinic.org/diseases-conditions/post-traumatic-stress-disorder/symptoms-causes/syc-20355967) | (mayoclinic.org)

**Steve and Dr. Kimless met at the International Association for Cannabis in Medicine**: [IACM](https://www.cannabis-med.org/?lng=en) | (cannabis-med.org)[10:30]

**Policy promoted by**: The [United Nations](https://www.un.org/en/)  [War on Drugs](https://news.un.org/en/tags/war-drugs) | (un.org)[12:45]

**U.S. Food and Drug Administration**: [FDA](https://www.fda.gov/home)  | (fda.gov) [14:00]

**Drug Enforcement Administration**: [DEA](https://dea)  | (dea.org) [14:00]

**On the outer surface of plant leaves**: [trichomes](https://en.wikipedia.org/wiki/Trichome)  | (wikipedia.org) [15:00]

**Indian cannabis milk drink**: [bhang](https://en.wikipedia.org/wiki/Bhang)  | (wikipedia.org) [15:00]

**American Stoner Comedy Film**: [Dude, Where’s My Car?](https://en.wikipedia.org/wiki/Dude,_Where%27s_My_Car%3F) | (wikipedia.org)[16:00]

**A cannabinoid of the cannabis plant**: [Tetrahydrocannabinol (THC)](https://en.wikipedia.org/wiki/Tetrahydrocannabinol)  | (wikipedia.org)[17:00]

**Primarily in the central nervous system (CNS)**: [CB1 receptors](https://en.wikipedia.org/wiki/Cannabinoid_receptor_type_1) | (wikipedia.org) [17:15]

**Primarily in the peripheral tissues and immune cells**: [CB2 receptors](https://en.wikipedia.org/wiki/Cannabinoid_receptor_type_2)  | (wikipedia.org) [17:15]

**Consists of nerves and ganglia outside of the brain and spinal cord**: [peripheral nervous system (PNS)](https://en.wikipedia.org/wiki/Peripheral_nervous_system) | (wikipedia.org)[18:00]

**Areas of the brain that conduct pain signaling and reduce cytokine expression**: [periaqueductal gray areas](https://en.wikipedia.org/wiki/Periaqueductal_gray)  | (wikipedia.org) [18:45]

**THC reduces inflammation**: [cytokine expression](https://en.wikipedia.org/wiki/Cytokine)  | (wikipedia.org) [18:45]

**A cannabinoid of the cannabis plant**: [cannabidiol (CBD)](https://en.wikipedia.org/wiki/Cannabidiol)  | (wikipedia.org)[21:15]

**The endocannabinoid system**: [ECS](https://en.wikipedia.org/wiki/Endocannabinoid_system) | (wikipedia.org)[22:00]

**Hemp cultivar is to have less than 0.3% by weight of THC or THCA**: [Hemp](https://en.wikipedia.org/wiki/Hemp)  |(wikipedia.org)[22:45]

**Hemp production and the 2018 Farm Bill**:  [The Farm Bill](https://www.fda.gov/news-events/congressional-testimony/hemp-production-and-2018-farm-bill-07252019)  | (fda.gov) [24:15]

- The [2018 United States farm bill](https://en.wikipedia.org/wiki/2018_United_States_farm_bill)
- Read more specifically about how hemp was impacted here: [Hemp Farming Act of 2018](https://en.wikipedia.org/wiki/Hemp_Farming_Act_of_2018)

**Hemp properties**: seeds high in [omega-3](https://en.wikipedia.org/wiki/Omega-3_fatty_acid) and [omega-6](https://en.wikipedia.org/wiki/Omega-6_fatty_acid) fatty acids | (wikipedia.org) [27:45]

**Hemp properties**: fibers have a high [tensile strength](https://www.hindawi.com/journals/amse/2013/325085/)  | (hindawi.com) [27:45]

**Machinery required to break down fibrous hemp cultivar**: [decortication machine](https://en.wikipedia.org/wiki/Decorticator) | (wikipedia.org)[29:00]

**Henry Ford’s hemp-fueled and cellulose plastic prototype car**: [hemp mobile](https://www.verymagazine.org/magazine/216-overview-issue20/877-henry-fords-hemp-car-1941)  | (verymagazine.org) [29:45]

**Used for the plant as a natural pesticide, an antioxidant, and it works that way in our bodies as wel**l: [Terpenes](https://en.wikipedia.org/wiki/Terpene)  | (wikipedia.org) [31:45]

**The lethal dose that it takes in order to kill off 50% of a population of a substance**: [LD-50](https://simple.wikipedia.org/wiki/LD50)  | (wikipedia.org)[37:15]

**Relative safety of a drug**: [Therapeutic index](https://en.wikipedia.org/wiki/Therapeutic_index)  | (wikipedia.org)[42:15]

**Observation that a psychoactive drug may increase the probability of future drug use**: [Gateway drug](https://en.wikipedia.org/wiki/Gateway_drug_effect)  | (wikipedia.org) [45:30]

**Animal studies show a 9% addictive percentage of THC**: [Adverse health effects of marijuana use](https://www.ncbi.nlm.nih.gov/pubmed/24897085) (Volcow et al., 2014)  [45:30]

**The National Institute of Drug Abuse**: [NIDA](https://www.drugabuse.gov/) | (drugabuse.gov) [45:45]

**Alcohol v. Marijuana**: [We took a scientific look at whether weed or alcohol is worse for you — and there appears to be a winner](https://www.businessinsider.com/alcohol-marijuana-which-worse-health-2017-11) Erin Brodwin | (*businessinsider.com)* [50:30]

**There has not been an association between lung cancer and smoking cannabis flowers**: [Effects of marijuana smoking on the lungs](https://www.atsjournals.org/doi/abs/10.1513/AnnalsATS.201212-127FR) (Tashkin,2013) [54:00]

**Anti-inflammatory effects of cannabinoids may prevent lung cancer from smoking the plant**: [Cannabis and tobacco smoke are not equally carcinogenic](https://harmreductionjournal.biomedcentral.com/articles/10.1186/1477-7517-2-21)  (Melamede, 2005) [55:00]

**Thermal decomposition of a material substance at elevated temperatures (bong use v. vaping)**:[pyrolysis](https://en.wikipedia.org/wiki/Pyrolysis)  | (wikipedia.org)[56:45]

**There has been a recent epidemic of acute respiratory distress syndrome**:  [The Mysterious Vaping Illness That’s ‘Becoming an Epidemic’](https://www.nytimes.com/2019/08/31/health/vaping-marijuana-ecigarettes-sickness.html) Sheila Kaplan and Matt Richtel | (*nytimes.com*) [58:00]

**FDA recognized material as safe, for particular uses, either as direct food ingredients, indirect food ingredients, part of packaging**: [Generally Recognized As Safe (GRAS)](https://www.fda.gov/food/food-ingredients-packaging/generally-recognized-safe-gras)  | (fda.org) [58:15]

**Decreased response to a drug after administration (e.g., seen in opiates)**: [Tachyphylaxis](https://en.wikipedia.org/wiki/Tachyphylaxis) | (wikipedia.org) [1:15:00]

**In response to opiates, 20%-30% of people experience an opposite reaction to pain relief**: [hyperalgesia](https://en.wikipedia.org/wiki/Hyperalgesia) | (wikipedia.org) [1:16:00]

**Synthetic THC has been on the market since the 1980s**: [dronabinol](https://en.wikipedia.org/wiki/Dronabinol)  | (wikipedia.org)[1:19:45]

**GW Pharma plant-derived, purified single CBD molecule**: [Epidiolex](https://www.gwpharm.com/healthcare-professionals/epidiolex) | (gwpharm.com)[1:23:30]

**Epidiolex therapeutic administration reported to reduce incidence of target seizures by 30%**: [Epidiolex as adjunct therapy for treatment of refractory epilepsy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6396837/) (Sekar et al., 2019) [1:23:30]

**Receptors responding to inhibitory neurotransmitter of the CNS gamma-aminobutyric acid (GABA)**: [GABA receptors](https://en.wikipedia.org/wiki/GABA_receptor)  | (wikipedia.org)[1:26:30]

**Used to treat anxiety; CNS depressant; GABA receptor pharmaceutical**: [Phenibut](https://en.wikipedia.org/wiki/Phenibut) | (wikipedia.org) [1:26:30]

**The Multidisciplinary Association for Psychedelic Studies**: [MAPS](https://maps.org/)| (maps.org) [1:30:00]

**For more on the MAPS organization business structure check out previous episode of The Drive with Rick Doblin**: [#65 – the creation, scheduling, toxicity, therapeutic use, and changing public opinion of what is possibly the single most important synthetic molecule ever created by our species](https://peterattiamd.com/rickdoblin/)  | Peter Attia (peterattiamd.com) [1:30:00]

**Cannabis compounds act synergistically**: [The Entourage Effect](https://en.wikipedia.org/wiki/Entourage_effect) | (wikipedia.org) [1:35:30]

**The endocannabinoid system and cancer**: [The endocannabinoid system and cancer: therapeutic implication](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3165955/) (Guindon and Hohmann, 2011)[1:35:30]

**Investigational New Drug**: [IND](https://www.fda.gov/drugs/types-applications/investigational-new-drug-ind-application) | (fda.gov) [1:47:00]

**Good Manufacturing Practice**: [GMP](https://en.wikipedia.org/wiki/Good_manufacturing_practice) | (wikipedia.org) [1:47:30]

§

## People Mentioned

- [Richard Nixon](https://en.wikipedia.org/wiki/Presidency_of_Richard_Nixon) (37th president of the U.S. whose administration led the “war on drugs” campaign beginning in 1971) [12:45]
- [Jeff Spicoli](https://en.wikipedia.org/wiki/Fast_Times_at_Ridgemont_High) (fictional character from comedy film “Fast Times At Ridgemont High”) [16:00]
- [Senator Mitch McConnell](https://en.wikipedia.org/wiki/Mitch_McConnell) (U.S. senator, hemp Farm Bill supporter  ) [24:30]
- [Henry Ford](https://en.wikipedia.org/wiki/Henry_Ford) (American industrialist and business magnate)[29:45]
- [Willie Nelson](https://en.wikipedia.org/wiki/Willie_Nelson) (American musician)[38:30]
- [Dr. Donald Tashkin](https://en.wikipedia.org/wiki/Donald_Tashkin) (American pulmonologist and professor who has studied the effects of cannabis) [54:00]
- [Frank sinatra](https://en.wikipedia.org/wiki/Frank_Sinatra) (American Singer) [1:19:45]
- [Rick Doblin](https://maps.org/about/staff) (previous guest on [The Drive](https://peterattiamd.com/rickdoblin/)) [1:30:00]

§

![](https://peterattiamd.com/wp-content/uploads/2019/11/goldner-and-kimless-1x1-500x500.jpg)

##### Debra Kimless, Ph.D. & Steve Goldner, J.D.

**Dr. Debra Kimless** is a board-certified anesthesiologist with a certification in pain medicine who is best known for her strong provider-side advocacy of medical cannabis. She became interested in medical marijuana because her mother suffered from constant pain that did not respond to opiates. She traveled to both Israel and the Netherlands to study their well-regarded medical marijuana practice models. As the CMO of [Pure Green](https://pure.green/), she conducts clinical trials of the company’s sublingual tablets.

Her goal is to de-stigmatize medical cannabis and educate both physicians and the public about its benefits. She is a frequent presenter at conferences and sees individual patients pro bono to develop treatment plans utilizing cannabis. She is also a “holistic” health proponent who combines her advocacy for medical cannabis with recommendations for a whole food, plant-based diet.

His focus is on drug-related investments with cannabis as a special area of interest. In addition to Pure Green, he runs 3 other businesses: Pinnacle Lab, which tests the safety/efficacy of marijuana; C3, a consulting firm for cannabis-based businesses; and Regulatory Affairs Associates, which helps companies with the drug and medical advice approval processes.

He advises NIH Phase 2 grant awardees through the FDA approval process, provides a free service to match patients to clinical trials, and holds several cannabis-related patents. He is also the Chairman of the USA Cannabis Laboratory Standards Setting Committee.

**Steve Goldner** is both a chemist and a lawyer but is probably best described as a medical entrepreneur. He is known as much for his business expertise as for his knowledge of pharmaceuticals or FDA law. In the 1970s, he co-invented both liquid methadone and urine drug screening testing, and early in his career he worked in FDA / regulatory affairs for several pharmaceutical companies. He is known for his expertise in the pharmaceutical industry in general and his knowledge of the FDA approval process in particular.

His focus is on drug-related investments with cannabis as a special area of interest. In addition to [Pure Green](https://pure.green/), he runs 3 other businesses: Pinnacle Lab, which tests the safety/efficacy of marijuana; C3, a consulting firm for cannabis-based businesses; and Regulatory Affairs Associates, which helps companies with the drug and medical advice approval processes.

He advises NIH Phase 2 grant awardees through the FDA approval process, provides a free service to match patients to clinical trials, and holds several cannabis-related patents. He is also the Chairman of the USA Cannabis Laboratory Standards Setting Committee.

Website: [stevegoldner.com](https://www.stevegoldner.com/#intro)