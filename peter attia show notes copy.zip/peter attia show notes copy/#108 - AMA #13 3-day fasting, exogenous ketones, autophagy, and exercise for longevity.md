# #108 – AMA #13: 3-day fasting, exogenous ketones, autophagy, and exercise for longevity

**Source:** [https://peterattiamd.com/ama13/](https://peterattiamd.com/ama13/)

---

In this “Ask Me Anything” (AMA) episode, Peter explains some observations he’s noticed since switching to a 3-day fasting regimen, the various things he’s measuring, and some helpful tips for getting through a prolonged fast. He also discusses the role of [exogenous ketones](/experience-exogenous-ketones-2/) in fasting and ketogenic diets as well as their impact on autophagy, specifically. Finally, Peter provides some practical advice for those looking to fit exercise for longevity into their busy life. Once again, Bob Kaplan, Peter’s head of research, will be asking the questions. If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #13 show notes page](https://peterattiamd.com/ama13/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Peter’s observations since switching from a 7-day to a 3-day fasting regimen [1:25];
- Ketone measuring devices—blood and breath [7:40];
- Can zero-calorie sweeteners affect ketone production? [10:40];
- Will there be a continuous insulin monitor anytime soon? [11:55];
- Exogenous ketones—Role in fasting and ketogenic diets and their effect on insulin, blood glucose, and autophagy [14:10];
- 5 tips to help you get through a multi-day fast [25:55];
- Relationship between BHB levels, glucose levels, and autophagy—Are high levels of ketones enough to produce autophagy? [34:10];
- Why is measuring blood insulin so much harder than blood glucose? [36:55];
- Advice and resources for people wanting to stay up to date on developments related to health and longevity (and how to quickly sift through all the bad science) [40:10];
- Advice for those looking to fit exercise for longevity into their busy life [51:10]; and
- More.

§

The Peter Attia Drive

Fasting, exogenous ketones, autophagy, and exercise for longevity

§

## Show Notes

## Peter’s observations since switching from a 7-day to a 3-day fasting regimen [1:25]

**Switching from 7-day fasting to 3-days fasting**

- Previously, Peter has been doing 7-day fasts once a quarter
- For 2020, he has switch to a 3-day fast once a month
- So he’s still fasting a roughly equal amount of time per year in total
- The rationale for the switch was twofold:
  - 1) 7-day fasts are quite intrusive on life
  - 2) In doing the 7-day fasts, Peter has noticed that on the second day of his fasts, his glucose levels will normalize and his ketone levels really start to rise — so something interesting is happening at that point so at least doing a slightly less extreme version (3 days) will give him some of that benefit that we got from the seven day fast

*-Observations about the 3-day fast compared to 7-day*:

- First observation
  - 3 days fasts are easier, not just because they are shorter, but he never feels like he’s “dragging” like he does a some points during the 7 day fasts
- Second observation:
  - Exercise tolerance is higher since he’s not subjected to the same degree of glycogen depletion
  - The implications to this is that he won’t have to dial back the volume/intensity of his workouts multiple times per year
- Third observation:
  - Note: Peter still needs to do a full blood test after day 3 to be able to compare it to after day 7.
  - However, he HAS done a blood test after a 4 day fast and here’s what he noticed:
  - It looked almost identical to what he’d see at the end of a 7 day fast, meaning…
    - Insulin is basically unmeasurable
    - Glucose is very low
    - Triglycerides, not that low
    - Likely b/c so much flux of triglyceride to free fatty acid going through, that that’s basically your substrate for making all those ketones
    - TGs weren’t “high” though, they were about the same as they are when he’s fed
    - Uric acid, very high
    - Free T3, very low
    - Reverse T3, very high.
    - Testosterone, very low
    - IGF also, very low

## Ketone measuring devices—blood and breath [7:40]

*Peter uses a few different ketone checking devices*:

- Blood testing—
  - [Precision Xtra](https://abbottstore.com/precision-xtra-blood-glucose-ketone-monitoring-system-1-pack-9881465.html) (more accurate at lower levels)
  - [Keto-Mojo](https://keto-mojo.com/?gclid=Cj0KCQjw9ZzzBRCKARIsANwXaeJHjkIt4oEXZ7-cbCytZBOjw9Xh3WITvV4SSeg7GRRa0Ze0Qsk0BGEaAlUuEALw_wcB) (runs “a little high” at lower levels)
- Breath testing—
  - Peter is helping test a new breath device for measuring [acetone](https://en.wikipedia.org/wiki/Acetone) (not commercially available yet)
  - Historically, breathe acetone and blood ketone levels have **not** been very correlated
  - Bob has a [Ketonix](https://www.ketonix.com/) device that simply gives you a red, yellow, and green color based on acetone levels
  - This new device Peter is testing will have more quantitative data as compared to Ketonix

*Potential advantages of having an “accurate”* ***breath*** *test for measuring ketosis*:

- One—Much cheaper
- Two—More practical and accessible for people (especially since they don’t have to draw blood)
- And a device like this is probably MORE helpful when trying to get into ketosis by way of a ketogenic diet vs. when fasting, says Peter

## Can zero-calorie sweeteners affect ketone production? [10:40]

- Peter used to chew gum and occasionally have a diet soda while fasting, but he noticed he felt crappy
- After checking his blood ketones he realized that the **non-nutritive sweeteners were impairing his ability to make ketones**

\*Peter thinks that at some point in the near future, we may see a **continuous** ketone monitor just like we have a continuous glucose monitor

## Will there be a continuous insulin monitor anytime soon? [11:55]

*Will there be a continuous insulin monitor anytime soon?*

- The short answer is “probably not”
- Insulin is a much more complicated thing to measure than glucose, lactate, beta-hydroxybutyrate, hemoglobin, even cholesterol, or triglyceride.
- At least one company has a prototype that’s able to test insulin and C-peptide in real time

Peter says being able to measure C-peptide/insulin levels is interesting to him because…

- The ability to self check urinary C-peptide (and by proxy, insulin) would give people the ability to get great insights into metabolic health on their own

*Peter’s dream assay*: **Insulin AUC** (area under the curve)—“*To know over 24 hours how much insulin you made would be a fantastic metric to juxtapose with the knowledge of what your average glucose or standard deviation of those things would be.*”

## Exogenous ketones—Role in fasting and ketogenic diets and their effect on insulin, blood glucose, and autophagy [14:10]

*Could exogenous ketones help bring up ketones to a desired level if you’re not where you want to be during a fast or while on a ketogenic diet?*

- During a fast, Peter says you wouldn’t really want to ingest exogenous ketones
- Why? Because one thing you are trying to accomplish with a fast is [autophagy](https://en.wikipedia.org/wiki/Autophagy) … and exogenous ketones are a source of energy which would probably impair autophagy from happening

**3 things that signal autophagy to happen**:

1. **Low ATP**—low intracellular ATP is a global [signal for autophagy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3879708/) and that’s mediated through the upregulation of adenosine monophosphate kinase (AMPK)
2. **Low mTOR**—When amino acids are low, mTOR activity goes down and that becomes a signal to autophagy
3. **A reduction in the cytosolic pool of acetyl-CoA**—the way that the cell checks for low levels of acetyl-CoA (a metabolite of glucose and fatty acid) is looking at protein de-acetylation. As protein de-acetylation goes down, intracellular acetyl-CoA levels go down, and that’s a trigger for autophagy.

\*Peter’s concern regarding taking exogenous ketones is that **beta-hydroxybutyrate might would trip up one of those three systems and therefore attenuate, or even shut off, autophagy**

⇒ More on this in a future podcast with [Dr. Eileen White](https://www.cinj.org/research/profile-eileen-white-phd) and/or [Dom D’Agostino](https://twitter.com/DominicDAgosti2?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

*-How long does it take after you ingest these things to see a rise in ketone level?*

- Very quickly, says Peter
- In as short as 30-60 minutes
- How long it would stay elevated would depend on your activity?
  - If you were exercising, probably not long
  - If you were sitting and watching TV, probably for a while

**Could exogenous ketones be used for a performance boost under conditions of extreme concentration?**

- A question Peter has been pondering is related to… *how much energy is expended under conditions of extreme mental concentration?*
- ⇒ *For example*, when Peter drivers in his race car driving simulator, he says the concentration factor is “*unlike anything I’ve ever done*”
- Given that the brain is a “pretty greedy organ energetically” he wonders…
  - i) how much energy it’s using while concentrating and
  - ii) if consuming exogenous ketones prior to driving would increase performance
  - Whereas the body can tap into stored forms of glucose and fatty acid, the brain is more reliant on glucose and ketones most recently ingested

**Exogenous ketones effect on blood glucose levels**

- It appears that ingesting ketones actually drives down blood glucose… *why does this happen*?

*-One potential explanation*:

- Ketones do elicit insulin (That’s how people with a functioning pancreas don’t get diabetic ketoacidosis from nutritional ketosis)
- So if someone were to take a huge amount of exogenous ketones, it would likely then release insulin which then drives blood glucose levels down

–*Another possible factor*:

- The body may sense that with a rise of BHB, you have more energy substrate (ATP) so therefore it down regulates your blood glucose
- If you plotted glucose and BHB (both in millimole) over the course of a day, they tend to sum to about the same amount no matter the % of the total was BHB or glucose
- Now, there’s ways that you can blow that up ⇒ go eat a big Mac and fries and a milkshake your ketones will bottom out at zero but your glucose of course can go up and up and up
- BUT… if we’re talking about not eating crap and not taking exogenous ketones even, but rather you’re in nutritional ketosis and watching BHB and blood glucose wax and wane… the two of them add up to about **6-8 millimole**

*Where are ketone levels and glucose levels when several days into a fast?*

- BHB is about ~4 mmol
- Blood glucose is about 3 to 4 mmol
- The sum being 7-8 mmol

*What is Peter’s fasting glucose in the morning when NOT in the midst of a multiple day fast?*

- Between 90-100 mg/dl (which converts to 4.75-5.25 mmol)

*After about 24 hours of fasting, where is Peter’s BHB levels?*

- For Peter, usually between 0.5-1.0 mmol
- This [paper](https://www.gwern.net/docs/longevity/2019-decabo.pdf) mistakenly stated that people reach 2-5 mmol after 24 hours when they meant to say 0.2-0.5 mmol

## 5 tips to help you get through a multi-day fast [25:55]

Tips:

1 | Start with baby steps, know you can end it whenever you need to

- Peter says there’s nothing wrong with ending a fast early if you’re not feeling well
- In fact, he has ended fasts for his patients on many occasions
- That said, Peter doesn’t have any examples of a patient who “medically” NEEDED to eat
- Needing to eat was more psychological than anything

2 | Fast with others to be able to support each other

- The feeling of support while doing it with another person makes the process easier to get through
- If you don’t have a person to do it with, consider the fasting app called [ZERO](https://www.zerofasting.com/)
  - \*Note, Peter is involved with this company
  - At any time, there’s 500,000+ people fasting simultaneously using the Zero app

> “*There’s a huge strength in numbers that kind of comes from knowing that at any moment you’re miserable. It’s going to pass and you’re not alone.*”

3 | Have a plan for when you know it will be tough

- If you love a certain food or meal, be somewhere else when that temptation will be there
- Go for a walk, occupy yourself elsewhere

4 | Have something to look forward to

- Each day that you’re fasting, put something on the day that you might not otherwise do that’s just pure bliss
- A show, a book, just some kind of “reward”
- And try to do this thing especially when you suspect to have hunger pangs

5 | Start with baby steps

- First, get some experience with time-restricted eating
- Then try to elongate the fasting window to 24 hours
- Then many 36 hours, then 48
- And keep progressing from there

**Insights from a 10 day fast**

- Both Peter and Bob have done a 10 day fast
- They both observed that after about 8 days you lose almost any desire to eat and it become super easy
- Bob even pointed out that he had to “convince” himself to break his fast
- He said it felt wrong to do so
- “But it really felt like it was a religious experience, almost.” says Bob

**One more tip:** *Consider using “negative” motivation*

- Meaning… if you don’t do something, you experience some *negative consequence*
- Bob got this idea from [Ryan Holiday](https://peterattiamd.com/ryanholiday/) who applied it to his [21-Day challenge](https://dailystoic.com/challenge)
- This challenge included an app called [SPAR](https://getspar.com/?gclid=Cj0KCQjw9ZzzBRCKARIsANwXaeKjv8jvL6z7eiE2957fs4TxlZ3vrPTE2Px5kHQz8fl1VIRqznQhKGoaAtFfEALw_wcB)
- In this case, through SPAR,
  - You commit to a certain amount of money financially that if you don’t do whatever the daily task is, then you have to pay into a pool
  - Then at the end of the 21 days, the money is split between all the people who participated in the challenge in a way that benefits those who stuck with it

## Relationship between BHB levels, glucose levels, and autophagy—Are high levels of ketones enough to produce autophagy? [34:10]

**In the famous** [**fasting study**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2194504/pdf/tacca00002-0213.pdf) **by George Cahill…**

- Participants where fasted for 40 days
- It was reported that the participants’ beta-hydroxybutyrate kept climbing until about 15 or so days where it started to level off
- Bob wonders if the same thing is happening with the level of autophagy
- The problem is that we don’t have any way to measure the level of autophagy happening at a given time

-What we do know, however, is that **having high ketones is consistent with being in a state of autophagy**

–*The question is…*

- Does the body realize the difference between when you’re **making the ketones** versus when **you ingested them**?

–*In other words…*

- Is it the actual BHB itself that is a signal for autophagy?
- Or is it the energetic state that produces BHB the signal for autophagy?

-The answers to these questions have implications such as…

- Would it be possible to therefore eat a [SAD diet](https://en.wikipedia.org/wiki/Western_pattern_diet) and still achieve autophagy by ingesting exogenous ketones?
- \*For now, this is just a thought experiment but hopefully one day will be a real experiment

## Why is measuring blood insulin so much harder than blood glucose? [36:55]

*Why is measuring blood insulin so much harder than blood glucose?*

- The issue is how you measure it—i.e., *How simple is the chemical reaction?*

–*With glucose and BHB*:

- You take the drop of whole blood
- You don’t have to spin it
- You don’t have to separate plasma from serum
- You probably just stick an antibody on it and based on the amount of signal you get, you infer what the concentration is.

–*With more complicated assays like insulin*:

- It has to go through multiple iterations of washing the reagent away, putting another antibody on, washing the reagent away, putting another antibody on, and so on
- Plus, there are definitely other layers of complexity on top of that
- It’s certainly not amenable to sort of the simple quick check on a drop of whole blood

\*Peter does believe that these obstacles are possible to overcome at some point in the future

## Advice and resources for people wanting to stay up to date on developments related to health and longevity (and how to quickly sift through all the bad science) [40:10]

**Here’s what Peter looks at regularly**:

*-One of Peter’s favorites*: Weekly email from [Obesity and Energetics](https://www.obesityandenergetics.org/) of which [David Alison](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=allison) (Indiana University) is the Editor-in-Chief

- Peter subscribes to categories of Basic, Drugs, and Caloric and Dietary Restriction)

–[Science Daily](https://www.sciencedaily.com/newsletters.htm) – he will get a daily email on a number of tagged diseases

- ~10 papers show up daily in his email
- But they are just press releases
- 90% of the papers are “total crap”
- It takes Peter about 10 minutes to looks through the emails and decide if anything is worth clicking into

–*Journals*

- Reads [JAMA](https://jamanetwork.com/) weekly
- Skims other journals less regularly

*-Twitter* – Peter gets quite a bit from Twitter by following the right people

- He will get at least one “gem” a week from someone posting on twitter

–*Team of analyst* – his team will also send Peter stuff that looks interesting

**How Peter sifts through the growing mound of crappy science**:

> “A press release is pretty much as useful as a warm bucket of hamster vomit and anything that the university has to say about this study is either wrong or irrelevant.”

–*Peter’s process is to …*

- Skim the abstract, and if it looks interesting…
- He will then look at the figures (the figures “tell the story of the paper”)
- From there Peter will go and look at the methods (which sometimes if hard to acquire)
- Peter also leans on “Journal Club” within his team of analysts

⇒ Check out Peter’s [3/8/20 newsletter email](https://peterattiamd.com/multiple-problems-with-a-study-linking-proximity-to-major-roads-to-dementia-parkinsons-disease-alzheimers-disease-and-ms/) describing his process of sifting through papers

**Another good resource per Bob**: The work of [Vinay Prasad](https://twitter.com/VPrasadMDMPH?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

- [Malignant](https://www.amazon.com/Malignant-Policy-Evidence-People-Cancer/dp/1421437635) ⇒ Book with a whole chapter on how to navigate the literature as a physician or a researcher
- He has a Medscape article where he touches on a lot of this: [21st Century Physician: Triaging the Tsunami of Medical Information](https://www.medscape.com/viewarticle/902209)

*-Important tip that Bob pulled from Prasad’s framework*:

- Always read the literature that interests you and **come to your own conclusions BEFORE going on twitter (or anywhere online) and getting OTHER PEOPLE’s curated takes** on the paper
- Because if you get other people’s takes first then your judgement will be clouded as to what you will find in the paper

*“Very humbling” says Peter*

- Peter says that when you think about how much science is being done…
- And how many branches of medicine there actually is…
- “I literally know nothing” says Peter
- “I’m constantly amazed at my own ignorance.”

**The biggest challenge for researchers and doctors trying to keep up:**

- The is an endless flow of information that comes in that you can’t keep up
- And the nature of science is that there is never a certainty about anything
- As an analyst, you might be able to say “we just don’t know”
- But as a physician, you have a patient that might need an answer
- So the **biggest challenge is guiding patients despite that incomplete information**
- And then it doesn’t help that you’re “*constantly being batted over the head with how little you know*”

**Resource for physicians trying to stay “up to date”**:

- A subscription to [UpToDate](https://www.uptodate.com/home) is a good resource although it’s not exclusively health and longevity

## Advice for those looking to fit exercise for longevity into their busy life [51:10]

**The full question from the subscriber**: “*With my busy career, a family, and frankly a lack of any interest to be an elite athlete, I just want to be able to exercise enough and be doing the right things to help my health journey even if this means I won’t make it to 100. Help those of us committed to living as well as we can to find a realistic approach, please.”*

-Peter first says the good news is that exercise for *longevity* is less time consuming that exercise for *performance*

–*Peter has a framework for exercise*:

1. Stability
2. Strength
3. Aerobic efficiency
4. Anaerobic performance

⇒ see [AMA #12](https://peterattiamd.com/ama12/) for a deep dive into his framework for exercise

*Is there a minimum effective dose for each of those components?*

- It’s very hard to say because “I don’t think we know that”
- Also, it varies by individual
- In other words, what Peter does and how much time he spends in regards to those four components is probably different than what you would need to do

**What Peter does**:

- Overall, he spends about 10 to 12 hours a week exercising (i.e., slightly less than two hours a day)
- Another principle Peter suggests: Try to **exercise every single day**
- Peter now lifts weights five days a week instead of three days a week
- *M,W,F* will be bigger lift days where it’s a 90 minute session.
- *Saturday and Sunday* he will combine 45 to 60 minutes of zone 2 training with 30 minutes of some lifting afterwards
  - *Some example exercises post-zone 2*: Deadlifts, sled work, farmer carries with rows and some tricep serratus activity

**Peter’s advice for how much time to spend exercising**:

*-Stability*

- Stability training is too big a topic to cover here, says Peter
- But he tries to work on it for 10 min per day, but at least a dedicated hour a week

*-Strength*

- You could really efficiently get some good work done in three, one-hour sessions in a week

*-Zone 2 (i.e., aerobic efficiency)*

- The minimum effective dose if you’re starting from nowhere is probably two hours a week
- If you have a reasonable base of fitness, probably three hours per week is better

⇒ see [episode of The Drive with Iñigo San Millán, Ph.D.](https://peterattiamd.com/inigosanmillan/) for more on zone 2

*-Zone 5 (i.e., anaerobic work)*

- You don’t need much of this, says Peter
- And it’s very easy to incorporate into regular activity

⇒ See [AMA #12](https://peterattiamd.com/ama12/) for more on this

> “So, I would say that’s sort of the foundation that I would think of for exercising towards aging well and being able to physically do the things that matter to you as you get older. I think once people enter that seventh and eighth decade, if they haven’t done a lot of consistent preparatory work in the decades prior, it’s alarming how quickly things go south. That’s probably the problem I think most about in my own life, is how to mitigate that risk.”

§

## Selected Links / Related Material

**Cereal that Peter sometimes eats with tons of fiber that does not spike his blood sugar**: [Fiber One](https://www.fiberone.com/) | (fiberone.com) [7:00]

**Ketone measuring devices Peter uses**: [8:00]

- [Precision Xtra](https://abbottstore.com/precision-xtra-blood-glucose-ketone-monitoring-system-1-pack-9881465.html) | (abbotstore.com)
- [Keto-Mojo](https://keto-mojo.com/?gclid=Cj0KCQjw9ZzzBRCKARIsANwXaeJHjkIt4oEXZ7-cbCytZBOjw9Xh3WITvV4SSeg7GRRa0Ze0Qsk0BGEaAlUuEALw_wcB) | (amazon.com)

**Breath testing device for measuring ketones that Bob has used**: [Ketonix](https://www.ketonix.com/) | (ketonix.com) [9:00]

**Dom D’Agostino has said taking an acute bolus of exogenous ketones drives blood glucose down**: [Transcript – Keying in on Ketones with Dominic D’Agostino – #325](https://blog.daveasprey.com/wp-content/uploads/2016/07/Transcript-DomDAgostino.pdf) | (daveasprey.com) [14:45]

**When ATP is low, AMPK is revved up, and that is a signal to autophagy**: [Autophagy regulation by nutrient signaling](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3879708/) (Russell et al., 2014) [15:45]

**This NEJM paper mistakenly stated that people reach 2-5 mmol after 24 hours when they meant to say 0.2-0.5 mmol**: [Effects of Intermittent Fasting on Health, Aging, and Disease](https://www.gwern.net/docs/longevity/2019-decabo.pdf) (Cabo and Mattson, 2019) [25:00]

**Fasting app to help with feeling like you have community support**: [ZERO](https://www.zerofasting.com/) | (zerofasting.com) [28:45]

**Ryan Holiday episode of The Drive where he mentioned the Spar app for accountability**: [#90 – Ryan Holiday: Stillness, stoicism, and suffering less](https://peterattiamd.com/ryanholiday/) | Peter Attia (peterattiamd.com) [33:00]

**Ryan Holiday’s “amazing” newsletter**: [Daily Stoic](https://dailystoic.com/) | (dailystoic.com) [33:00]

**App that allows you to challenge friends and be held accountable for things you want to do**: [Spar app](https://getspar.com/?gclid=Cj0KCQjw09HzBRDrARIsAG60GP-NDF2TZ-rMFh65M4WreBmJt6_R9Uk4VWQY_2xOLQLFMe846w0QUEwaAs_AEALw_wcB) | (getspar.com) [33:15]

**George Cahill’s famous 40-day starvation experiment that showed how BHB levels changed during a prolonged fast**: [KETOACIDS? GOOD MEDICINE?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2194504/pdf/tacca00002-0213.pdf) (Cahill and Veech, 2003) [34:15]

**Rosalyn Yalow won the Nobel Prize for developing a radioimmunoassay to measure insulin**: [Rosalyn Yalow-Facts](https://www.nobelprize.org/prizes/medicine/1977/yalow/facts/) | (nobelprize.org) [37:00]

**Resources Peter uses to stay up to date with publications**: [40:15]

- *One of Peter’s favorites*, a weekly email: [Obesity and Energetics](https://www.obesityandenergetics.org/) | (obesityandenergetics.org)
  - Peter subscribes to categories of Basic, Drugs, and Caloric and Dietary Restriction)
- *One he says is 90% crap but will sift through it quickly*: [ScienceDaily](https://www.sciencedaily.com/newsletters.htm) | (sciencedaily.com)
- *The Journal of the American Medical Association*: [JAMA Network](https://jamanetwork.com/) | (jamanetwork.com)
- *Peter always gets something good from people he follows on*: [Twitter](https://twitter.com)

**Peter’s 3/8/20 newsletter email describing his process of sifting through papers**: [Multiple problems with a study linking proximity to major roads to dementia, Parkinson’s disease, Alzheimer’s disease, and MS](https://peterattiamd.com/multiple-problems-with-a-study-linking-proximity-to-major-roads-to-dementia-parkinsons-disease-alzheimers-disease-and-ms/) | Peter Attia (peterattiamd.com) [44:00]

**Book with a whole chapter on how to navigate the literature as a physician or a researcher or even I think the lay public**: [Malignant: How Bad Policy and Bad Evidence Harm People with Cancer](https://www.amazon.com/Malignant-Policy-Evidence-People-Cancer/dp/1421437635) by Vinayak K. Prasad | (amazon.com) [44:45]

**Medscape article about how to navigate the literature as a physician, researcher, or a layperson**: [21st Century Physician: Triaging the Tsunami of Medical Information](https://www.medscape.com/viewarticle/902209) | Vinay Prasad, MD, MPH (medscape.com) [44:45]

**Site both Peter and Bob recommend as a way to stay up to date on research**: [UpToDate](https://www.uptodate.com/home) | (uptodate.com)  [49:15]

**AMA episode where Peter dove deep into his exercise framework**: [#92 – AMA #12: Strategies for longevity (which don’t require a doctor)](https://peterattiamd.com/ama12/) | Peter Attia (peterattiamd.com) [52:50]

**Episode about Zone 2 exercise with Iñigo San Millán**: [#85 – Iñigo San Millán, Ph.D.: Mitochondria, exercise, and metabolic health](https://peterattiamd.com/inigosanmillan/) | Peter Attia (peterattiamd.com) [55:00]

§

## People Mentioned

- [Dom D’Agostino](https://twitter.com/DominicDAgosti2?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [8:30, 14:00, 20:00]
- [Eileen White](https://www.cinj.org/research/profile-eileen-white-phd) [16:00, 35:45]
- [Richard Veech](https://ketogenic.com/richard-veech/) [20:15]
- [Mark Mattson](https://en.wikipedia.org/wiki/Mark_Mattson) [25:00]
- [Jocko Willink](https://twitter.com/jockowillink?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [30:00]
- [Ryan Holiday](https://twitter.com/RyanHoliday?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [33:00]
- [Rosalyn Yalow](https://www.nobelprize.org/prizes/medicine/1977/yalow/facts/) [37:00]
- [Solomon Berson](https://en.wikipedia.org/wiki/Solomon_Berson) [37:00]
- [David Alison](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=allison) [40:30, 51:15]
- [Vinay Prasad](https://twitter.com/VPrasadMDMPH?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [44:45]
- [Iñigo San Millán](https://twitter.com/doctorinigo?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [55:00]

§