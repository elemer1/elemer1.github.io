# #302 – Confronting a metabolic epidemic: understanding liver health and how to prevent, diagnose, and manage MAFLD and liver disease | Julia Wattacheril, M.D., M.P.H.

**Source:** [https://peterattiamd.com/juliawattacheril/](https://peterattiamd.com/juliawattacheril/)

---

Julia Wattacheril is a physician scientist and director of the Metabolic Dysfunction Associated Steatotic Liver Disease (MASLD) program at Columbia University Irving Medical Center. In this episode, Julia delves deep into the complex world of liver health, beginning with a foundational overview of liver physiology. She provides an in-depth look at how alcohol impacts liver function, breaking down the metabolism of ethanol and its detrimental effects. Julia then shifts the focus to understanding liver function tests and optimal enzyme levels, providing a detailed explanation of AST and ALT and elucidating why fluctuations in these levels may or may not be concerning. She provides a primer on the four major stages of liver disease, discussing risk and emphasizing the importance of early diagnosis. Julia highlights the role of liver disease in increasing the risk of cancer and cardiovascular disease and covers in detail the various strategies for diagnosing, treating, and preventing the progression of liver disease.

*\*Dr. Wattacheril’s views expressed in this conversation reflect her own, not those of her institution.*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/juliawattacheril/the_Drive_public.png)

Play

#302 - Confronting a metabolic epidemic: understanding liver health and how to prevent, diagnose, and manage liver disease | Julia Wattacheril, M.D., M.P.H.

#302 - Confronting a metabolic epidemic: understanding liver health and how to prevent, diagnose, and manage liver disease | Julia Wattacheril, M.D., M.P.H.

1x15s30s

0:002:25:03

## We discuss:

- Julia’s training, the importance of liver health, and the challenges and innovations of hepatology [3:15];
- The complex and crucial functionality of the liver, its four most essential functions, and more [8:45];
- Liver injuries: historical and evolving understanding of causal factors, and the progression to liver diseases and cancer [13:15];
- How the liver metabolizes nutrients, and what happens in the presence of excess calories or alcohol [24:45];
- Methods of diagnosing liver disease, and how insights guide treatment and management strategies [33:30];
- The poisonous nature of ethanol to the liver [40:30];
- Varied responses to alcohol, damaging effects of alcohol beyond the liver, and the process of advising patients on their alcohol consumption [47:15];
- Understanding liver enzymes—AST and ALT—interpreting levels, lifestyle factors that affect them, and diagnostic approaches [58:30];
- Interpreting liver function tests for fatty liver disease, and the challenges of diagnosing liver pathologies, particularly in children versus adults [1:13:15];
- Comprehensive liver health assessments via imaging and various diagnostic tools to prevent overlooking potential liver pathologies [1:18:45];
- Potential impact of recreational drugs, statins, and other medications on liver function test results [1:26:45];
- Shifting nomenclature from NAFLD to MASLD to reflect accuracy in the underlying pathophysiology and understanding of liver diseases [1:30:30];
- Pathophysiology of MASLD, the need for proactive screening, and the significance of liver fat percentage as an indicator of metabolic health [1:36:30];
- The importance of screening for and considering rare conditions alongside common metabolic diseases associated with fatty liver accumulation [1:42:45];
- Practical strategies for managing MAFLD [1:45:30];
- The impact of fructose consumption on liver health and the challenges of disentangling its effects from other factors like obesity and insulin resistance [1:52:45];
- The potential of GLP-1 agonists for the treatment of MASLD [1:57:45];
- How the four stages of liver disease have evolved [2:00:30];
- Increased cancer and heart disease risk associated with early stage MAFLD [2:05:15];
- Emerging drugs and therapies for addressing fat accumulation and fibrosis related to MAFLD [2:12:15];
- Peter’s major takeaways [2:18:45]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Julia Wattacheril specializes in non-alcoholic fatty liver disease as well as all forms of hepatitis, chronic liver disease, and liver cancer
- In addition to being a hepatologist who takes care of patients pre and post liver transplantation, her research interests include hepatic steatosis, insulin resistance, gut hormones, and metabolic liver disease in adults
- Julia is an associate professor of medicine and director of the Metabolic Dysfunction Associated Steatotic Liver Disease (MASLD) program, the Center for Liver Disease and Transplantation program at Columbia University Medical Center
- Julia earned her MD and completed her residency at Baylor College of Medicine followed by a fellowship in gastroenterology at Vanderbilt University where she also earned a Masters in Public Health
- She completed a second fellowship in transplant hepatology at Columbia University before becoming an attending there, where she is today
- In this episode, we start by speaking about the basic physiology and the 4 functions of the liver, the history of liver disease and transplantation, and the details of acute versus chronic liver injury
- We speak about alcohol-related injury, and what it is about the mechanism and metabolism of ethanol that is problematic for the liver
- We look at what the optimal levels for liver function tests and liver enzymes might be in a blood test
- Julia explains in fantastic detail what AST and ALT do in a cell, what they refer to
  - 2 very common measurements that we talk about a lot, and you have undoubtedly seen on your blood test
  - What is it about their elevation that we should or shouldn’t be worried about
- We then discuss how to improve metabolic health in relation to the liver, and why the liver is truly the mothership of all organs
- Lastly, Julia outlines the 4 major stages of liver disease
  - Discussing the risk, treatment options, and the importance of early diagnosis

## Julia’s training, the importance of liver health, and the challenges and innovations of hepatology [3:15]

**Tell folks a little bit about your training, what it means to be a hepatologist and what led you there**

- Julia is a transplant hepatologist
  - Her clinical hat is divided into 50% liver transplant and 50% general liver care
- How she got to that path ‒ she did medical school in Houston at the Baylor College of Medicine and completed residency there as well
  - A GI fellowship at Vanderbilt in Nashville
  - Then a transplant fellowship at Columbia
- When it comes to her faculty time division, she tends to focus on [MASLD](https://en.wikipedia.org/wiki/Metabolic_dysfunction%E2%80%93associated_steatotic_liver_disease) (or NAFLD as it used to be called)
  - Metabolism and a nexus with endocrinology is also a big focus of hers

**Give folks a sense of what the liver does**

- People have heard Peter say this before, but it’s worth repeating, “*The liver is this essential organ for which we don’t have extracorporeal support (that’s just a fancy word that means outside of body support).*”
  - If a person’s lungs don’t work, you have extracorporeal support
    - You have a ventilator that can do the job of the lung for a temporary period of time, hours, weeks, even months
  - Believe it or not, if the heart doesn’t work, we have extracorporeal support in terms of intra aortic balloon pumps or even ventricular assist devices
  - If the kidneys don’t work, we have extracorporeal support in the form of dialysis
- Peter is not suggesting any of these things are a substitute for the real thing, but they’re remarkable bridges that save many lives
- And yet we don’t have anything that even remotely resembles extracorporeal support for the liver
- We have this essential organ and if it is injured, we don’t even have a way to bridge people to transplantation

*Anything you want to say about that? Is that just a staggering feature of this organ?*

- It’s not for lack of trying
- There have been some devices like the [MARS machine](https://en.wikipedia.org/wiki/Liver_support_system#The_MARS_System) that have been developed
- The bulk of liver disease has historically been chronic, and so you have time for intervention
- It’s the acute phases that we really need either a 3D printed liver or an accessory liver that could function either inside the body or outside of the body
  - Those efforts are being undertaken, but it both hearkens to the complexity of what the liver does and how hard it is to mimic when the liver is injured, what it can do
- It also gives you a focus on the panoply of liver diseases, the timeline to development of liver disease, and the functional aspect of what it takes to actually get some of these devices to market

*Peter’s story from his time at Hopkins*

- One of the attendings who had trained at one of the universities in Virginia told a story about when he was in his training: they were using baboons as a bridge to transplantation (not xenotransplantation)
  - They would literally put a baboon in a bed next to the human in acute liver failure
  - They would run conduits between them and obviously they had somehow [ABO](https://en.wikipedia.org/wiki/ABO_blood_group_system) matched the baboon to the human, and they would basically circulate the human’s blood through the baboon using the baboon’s liver to detoxify and carry out [gluconeogenesis](https://en.wikipedia.org/wiki/Gluconeogenesis) (or whatever other features were critical in the acute moment)
  - Apparently, this somewhat worked
  - You could take a person who was completely jaundiced, on the verge of death and buy them another week or so until a liver transplant showed up
- According to the story of this one attending, it worked really well until once a patient emerged from basically a state of unconsciousness due to their liver failure and realized what was going on and freaked out and panicked and pulled the cannulas out
  - It turned into a big bloody mess that ended with the baboon dying and the patient nearly dying, and that put an end to it
- That story always stuck with Peter as the depths to which one had to go to try to basically save people during this period of acute liver failure while you either hoped for a recovery and/or found a transplant

**Any of those stories ever come your way?**

- Not so much the animal portion
- If you’ve read about **accessory livers**, you learn a lot about this from living donation: how much liver is required when people are in acute liver failure
  - It’s not something apart from the pediatric population that a small segment of liver could actually solve
  - For accessory livers, you’re implanting a human liver to basically function as a temporary means of metabolism and recovery of immune function and all the other functions that we’ll get to
    - But it’s much more on the human side than cannulas to a baboon, which is a good mimicker
- We learned a lot about liver disease from alcohol in the baboon
  - This model was one that mimicked human responsiveness more so than other animal models
  - For example, nutrient deprivation that occurs from carbohydrate load from alcohol versus direct injury to the liver

## The complex and crucial functionality of the liver, its four most essential functions, and more [8:45]

- The liver is clearly complex enough that in the year 2024, we still do not have a way to approximate it the way we do most other vital organs
- There’s something about it that’s obviously quite susceptible to injury in the modern environment

**How would you get people to understand and appreciate the absolute beauty of this what Peter considers a very underappreciated organ?**

- The liver is about 3.5 pounds, it sits underneath your right rib cage
  - Sometimes people get it on the wrong side, but in most humans it’s on the right
- It’s the largest internal organ

> “*Basic functions [of the liver], there’s over 300 functions*”‒ Julia Wattacheril

- A big one that hepatologists don’t necessarily get trained in much is metabolism
  - They’ve left a lot of that to the endocrinologists
- Hepatologists think about [parenchymal](https://en.wikipedia.org/wiki/Parenchyma#Liver) liver diseases
  - Common things like MAFLD or NAFLD, alcohol, autoimmune hepatitis
  - Things that affect the whole liver and then [cholestatic](https://en.wikipedia.org/wiki/Cholestasis) liver diseases or bile duct, the plumbing system of the liver

![](https://peterattiamd.com/wp-content/uploads/2024/05/f1-juliawattacheril-1024x844.png)

**Figure 1. Anatomy of the Liver**. Image credit: [Johns Hopkins Medicine](https://www.hopkinsmedicine.org/health/conditions-and-diseases/liver-anatomy-and-functions#:~:text=The%20liver%20holds%20about%20one,form%20the%20common%20hepatic%20duct.)

- A lot of what’s read about the liver is focused on one versus another component; so it’s just really important for any audience member who’s looking at a tiny piece of liver information (whether it’s biochemistry or a picture) to understand it in the context of what the liver does

**Some of the basic functions of the liver**

- 1 – Metabolism: that’s proteins, lipids and fat carbohydrate metabolism
- 2 – It serves an immune function

*We learn a lot about what the liver does from what happens when it doesn’t work well*

- 3 – One of the major proteins that it makes are the synthetic proteins that help you clot blood
  - Bleeding disorders are common in people with liver dysfunction
- 4 – The other one that comes up a lot is detoxification
  - Whether it’s metabolism of pharmacologic agents that people are taking in or any supplement or exogenous compounds or even toxins, environmental toxins, all of those get processed in the liver
- Those are just a few of the many functions
- Also included are the nutritional components: bile acid production, all of those things within the metabolic chamber
  - But that in and of itself could be a whole different category (some of that nutrient load handling)

**Would you agree that one of the big 4 things the liver does is regulate blood glucose?**

- This is part of the liver’s role in metabolism
- Peter points out, that this is something that’s almost impossible to describe how perfectly the liver is able to do
  - Including someone with [type 2 diabetes](https://en.wikipedia.org/wiki/Type_2_diabetes), where you end up being about 2x too much blood sugar
    - But that’s still a relatively narrow band with which blood glucose is regulated compared to the extremes
  - If blood glucose levels ever fall below about 50 mg/dL (or half a teaspoon total glucose circulating), you’re dead
    - If it really ever gets above 400-500 acutely, you are dead
  - That the liver can keep most of us around 100-00 is incredible at the minute-by-minute, second-by-second deviation
- The other 3 big functions: making clotting factors, detoxification, and the generation and clearance lipoproteins

***Peter thinks its a Herculean feat for 1 organ to be involved in these 4 profoundly important things***

## Liver injuries: historical and evolving understanding of causal factors, and the progression to liver diseases and cancer [13:15]

**Is it safe to say that infectious agents were the predominant driver of liver injury 100 years ago, 200 years ago?**

*Or was it toxins in the environment?*

- This question hints at common popular conceptions of, “*Why does someone have liver disease?*”
- Toxins and alcohol being the #1 thing that we’ve studied since the 1700s, 1800s, and then the onset of viruses and the study of non-A, non-B, which eventually became [hepatitis C](https://en.wikipedia.org/wiki/Hepatitis_C)
- All of that to say the liver was this recipient of external harm, and that goes to show why we’ve undervalued some of the natural resilience and endogenous effects of its inherent metabolic function
- Because we’ve focused on derangements, which as doctors, we tend to focus on the problem and try to treat the problem

***Those perturbations in normal liver physiology based on an exogenous agent leads to structural issues (histologic issues), and that sometimes limits us when we talk about the study of metabolic diseas***e

- For instance, if we perseverate on an [ALT](https://en.wikipedia.org/wiki/Alanine_transaminase) or [aminotransferases](https://en.wikipedia.org/wiki/Transaminase), that’s probably not the best marker of understanding fatty liver disease or metabolic dysfunction

> “*The framing around how we think about liver injury from an exogenous compound or as a result of a metabolic derangement plays a role in understanding longitudinal progression of the disease*.”‒ Julia Wattacheril

- Is liver injury an external insult?
- When taking care of humans, no one is in isolation, and behaviors, habits, environments change over time
- All of those serial perturbations and how to monitor and follow those perturbations also inform how we’re going to move forward from our old way of thinking about how to measure liver disease injury
  - How to prevent it, and how much time we have to intervene

**One of Peter’s favorite books he read in residency was the** [**biography of Thomas Starzl**](https://www.amazon.com/Puzzle-People-Memoirs-Transplant-Surgeon/dp/082293714X/ref=sr_1_1?crid=1J4W0MF5G8I3J&dib=eyJ2IjoiMSJ9.ERrILh_WCCN30GowrpYRj6z5y01NpqWejbWo3f0IANLGjHj071QN20LucGBJIEps.hhttwpyuBaXV3bDbc8yKYrQbTGdByAdrmAuiXJTW808&dib_tag=se&keywords=biography+of+Thomas+Starzl&qid=1712683566&sprefix=biography+of+thomas+starzl%2Caps%2C79&sr=8-1) **who pioneered liver transplantation**

- Everyone who pioneered an organ transplant is a giant in the field, whether it’s the pioneers [Murray](https://en.wikipedia.org/wiki/Joseph_Murray) of kidney transplantation or [Shumway](https://en.wikipedia.org/wiki/Norman_Shumway) and cardiac transplantation
  - Peter omitted the guy in South Africa, not just because he forgot his name for the moment, but because he ripped off Shumway
- None of these figures was bigger to Peter than [Starzl](https://en.wikipedia.org/wiki/Thomas_Starzl), in part because Peter thinks the liver was the hardest organ to transplant
  - This is true not just technically, but perhaps metabolically
- At the time when Starzl and his colleagues finally succeeded, it was probably in the late ’60s

**What was the dominant indication for liver transplant?**

*How often was it being done for an acute injury in that first era versus chronic injury that became untenable?*

- Whenever you’re talking about a new intervention and surgeons or any high risk-taker for a new intervention, the indications are going to have to justify some of the risk
- So acute liver failure
- Liver injury without failure would not be an indication
  - There has to be a life-threatening situation for someone to justify the risk that’s associated, not with just the explanation and implantation, but also the post-care
- Indications at that time from a liver disease perspective would be a little bit different than they are now
- Now in the pandemic, alcohol has really, really surpassed a lot of other more chronic indications that we thought were going to eclipse alcohol at this point
  - And that’s behavior and coping mechanisms with stress

***Alcohol-related liver injury and then viral hepatitis are the top 2 chronic adult liver diseases***

- The most common causes of **acute liver failure:** paracetamol or acetaminophen injury are the most common cause of suicide attempts outside of the United States
- [King’s College Criteria](https://en.wikipedia.org/wiki/King%27s_College_Criteria): how we’ve learned a lot about the function and dysfunction of the liver during acute liver failure is all learned from those toxin-related exposures and acute failure

*What percentage of patients who overdose on Tylenol and who cause a fatal or what would be fatal injury of the liver are able to receive a transplant in time?*

- It’s small
- [Will Lee’s](https://profiles.utsouthwestern.edu/profile/14217/william-lee.html) work at UT Southwestern has really encapsulated thi
- There’s lots of variables in terms of accessing liver transplantation
  - Whenever we talk about studies versus real world
  - There’s many logistic variables including payment and social support
  - It’s a complex decision

***Indications for transplantation at Julia’s center, under 10% are due to acute liver failure and a subfraction of those are acetaminophen injuries; it’s on the order of single-digit percentages if you look at most large centers***

- When Peter was in medical school (more than 25 years ago), they were told that [hepatitis C](https://en.wikipedia.org/wiki/Hepatitis_C) was basically going to be the sole indication for liver transplant by 2025

*Maybe a couple of things happened that weren’t anticipated*

- The first was an effective treatment for hep C
- Peter assumes that [hep B](https://en.wikipedia.org/wiki/Hepatitis_B) is potentially a greater problem than hep C, although we have a [vaccine](https://en.wikipedia.org/wiki/Hepatitis_B#Vaccine) for hep B
- Peter is curious about the relationship between hep B and hep C
- He also wants to hear a little bit more about alcohol- related injury, which seems to be on the rise as opposed to the decline

**Start with the hep B versus hep C distinction**

- Julia will zoom out a little because we are limited in what we know
  - We haven’t been able to do large aggregate, well-done population studies where you’re looking at all-comers (that’s happening now)
- It’s important to understand why we look at things the way we do because it can be frustrating to patients to not understand

***Hepatitis C is non-A, non-B hepatitis, and we think of it being chronic and progressive***

- This is during the pre-DAA (direct-acting antiviral) era (before 2014) when hep C was a common indication for liver transplant
- It took time to discover what the virus did, how it functions, how it results in liver injury and how that liver injury is chronic and progressive

***Hepatitis B is a lot less predictable, but we have really good antiviral medications and a very effective vaccine***

- We often see hepatitis B in the East Asian population
- It’s important to emphasize that the variability and the progression of the hep B is reassuring in the sense that we think that fewer people are going to progress to advanced fibrosis, cirrhosis
  - ***Fewer people with hepatitis B will need a liver transplant***
- Hepatitis B is the one liver disease that is an outlier in terms of oncologic potential
  - ***We see liver cancer develop in people with hepatitis B independent of going through the progression to advanced fibrosis or cirrhosis***
  - Our radar has to be up to screen for cancer in people that have chronic untreated hepatitis B, and the effectiveness of antiviral treatment on the cancer potential is still an unknown

**Peter’s takeaway:** ***Both hepatitis B or C also increase your risk for hepatocellular cancer (a very bad cancer)***

- Part of the mortality here results not just from the reduction of synthetic function in the liver, but from actual oncology
- Further, your probability of developing cancer moved in lockstep with the extent to which your disease progressed, but that’s only true with C
  - It is not true with B

**Julia explains, “*****We’re learning and we’re starting to reframe how we think about metabolic dysfunction as well when we think about the milieu within the liver and how injury is handled within the liver*****.**

- The big causes of advanced liver fibrosis (where cancer risk increases): alcohol- related liver disease, chronic hepatitis C, [MASLD](https://en.wikipedia.org/wiki/Metabolic_dysfunction%E2%80%93associated_steatotic_liver_disease)

**When we start screening for cancer risk when someone has cirrhosis of the liver**

***We screen for liver cancer and chronic hepatitis B independent of their degree of scar tissue or injury***

- Since we’re just barely touching on the cancer aspect of things, Julia adds:
- 1 – A relatively rare disease that also has a high oncologic potential is [hereditary hemochromatosis](https://en.wikipedia.org/wiki/Hereditary_haemochromatosis)
  - Julia gets the biased point of view of being referred cases that may not have been diagnosed early on
  - She is seeing things that could have been intervened on earlier had someone known about relative risk
- Peter probably knew this at some point and asks, “*Is that true of every one of these like* [*Wilson’s disease*](https://en.wikipedia.org/wiki/Wilson%27s_disease) *(where you accumulate copper)… [that] the risk of cancer increases with the risk of parenchymal injury?*”
- Yeah, parenchymal injury to a liver doctor, the card-carrying metric that we frame very highly is **fibrosis** (a term for scar tissue)

***Mst of our cancer outcomes are associated with what we call stage 4 scar tissue or cirrhosis***

- Julia is cautious with the use of staging because patients oftentimes relate it to cancer in the sense that a terminal diagnosis and a stage non-reversible gloom and doom, cirrhosis is stage 4 scarring of the liver, but the natural history of cirrhosis is widely variable

***Stage 4 cirrhosis an indication for increased monitoring, it’s not a death sentence nor is it an indication for transplant***

Peter asks, “*To be clear, you can have fibrosis long before you have cirrhosis, which means you don’t need to be all the way at, “a terminal stage of cirrhosis,” to be at increased risk of cancer.*”

- “Correct”, says Julia

## How the liver metabolizes nutrients, and what happens in the presence of excess calories or alcohol [24:45]

**Talk a little about the way a healthy liver metabolizes nutrients in a eucaloric nutrient appropriate manner, then explain what’s happening when excess calories or alcohol is present**

*Explain how the liver normally functions in metabolism and how VLDL works and what happens when you  start to create more fat de novo all of a sudden and have an inability to export it*

- When you have the luxury of time to be able to get somebody’s story, you can look at the liver in the context of the development of various aspects of their lives
  - Why someone drinks excessively is as important as the actual toxin
- The beauty of the liver is its resilience
  - Shy of more dense fibrosis (even in cirrhosis), liver damage is largely reversible and there are decades of potential time to intervene
  - This often gets forgotten
- It’s a general knee-jerk assumption when someone sees [hepatic steatosis](https://en.wikipedia.org/wiki/Fatty_liver_disease) (increased fat in the liver) to assume that it falls within what we used to call [non-alcoholic fatty liver disease](https://en.wikipedia.org/wiki/Metabolic_dysfunction%E2%80%93associated_steatotic_liver_disease) (that we now call metabolic dysfunction-associated steatotic liver disease, MASLD) without doing the detailed work around alcohol
- Why does this matter?

**Because you see dysregulated metabolism, even with alcohol-related injury**

- Alcohol is 7 calories per gram of pure carbohydrate
- When there is an excess nutrient load, there’s some evidence that the mechanisms affecting the liver early on maybe related (not exactly the same [as non-alcoholic fatty liver disease])

**Release of liver enzymes AST and ALT during disease**

- About 80% of the liver is [hepatocytes](https://en.wikipedia.org/wiki/Hepatocyte): those are the primary liver cells where your [AST](https://en.wikipedia.org/wiki/Aspartate_transaminase) and your [ALT](https://en.wikipedia.org/wiki/Alanine_transaminase) live
  - Ordinarily, they live in this cuboidal cell
    - Oftentimes hexagonal is the way that we describe the whole lobule that’s working hard
  - Those enzymes are basically [aminotransferases](https://en.wikipedia.org/wiki/Transaminase) that have a host of different activities

***Until hepatocytes get stressed and releases those enzymes [AST and ALT] in a detectable way in the bloodstream, we think that the liver has some degree of resilience and function***

**What is happening in the liver with both of these diseases**

- Julia explains, “*There’s altered redox potential and there’s free fatty acid handling differences. I think that the glucose aspect of things is incredibly important.*”
- When we think about a normal functioning liver for someone that has eucaloric [diet] and then all of a sudden there’s a relative excess caloric imbalance
  - Where what they’re taking in outpaces what they’re able to expend, and there’s nutrient excess

> “*The liver was never designed to store fat, and so we commonly think of an abnormality*.”‒ Julia Wattacheril

***Speaking specifically to the definition of*** [***MASLD***](https://en.wikipedia.org/wiki/Metabolic_dysfunction%E2%80%93associated_steatotic_liver_disease)***: more than 5% of the hepatocytes containing fat***

- Usually, subcutaneous fat is our component where processing of fat storage but it’s handled in a dynamic way
- Oftentimes when those compartments are overwhelmed, they start to deliver more substrate to the liver
- There are 2 big ways that the liver manufactures [fat], and 1 is **de novo lipogenesis**
  - We think in most people that that’s the secondary mechanism, and it’s the **exogenous input through nutrition** that supplies the majority of the lipid
  - De novo lipogenesis is manifested mostly with the triglyceride component
- Peter mentioned cholesterol ‒ there’s triglycerides and there’s phospholipids
  - He also mentioned lipoproteins, which Julia links to trafficking and metabolism of lipid molecules in terms of function

*The way that we study it is oftentimes through close collaboration with patients where any component is deranged*

- Now, by virtue of technology, we have means of detecting increased hepatic fat independent of insulin resistance or predating insulin resistance
- The relationship between how the liver accumulates triglyceride and starts to dispose of glucose is one that endocrinologists have started to or continue to dig a little bit deeper
  - We know that this relationship exists between insulin resistance and liver storage of fat, but the exact mechanism and timing is still undetermined
  - It’s called bidirectional in a lot of ways
- One of the junior scientists Julia works with describes different thresholds [of disease]
  - 1 – At some point, the insulinization of the liver leads to fat storage
  - 2 – A second threshold is crossed when you start to see decreased hepatic glucose production

**Explain what hepatic glucose production is**

- Peter explains, “*Something miraculous is actually happening given the glucose thirst of our brains, and all of the glucose that is being supplied to our brains right now as we have this discussion for the next hour or so is coming from our liver*.”
  - Our liver knows to not do too little and not do too much
  - It can make glucose, store glucose, and temper the glucose output
  - Anything that gets in the way of that is problematic, especially on the low end
- In type 2 diabetes, there is insulin resistance at the level of the cell, and so you have a harder time disposing of glucose peripherally
  - That leads to an increase in glucose [in the blood]
- In type 2 diabetes, we also probably see an increase in hepatic glucose output, which is where a drug like [metformin](https://en.wikipedia.org/wiki/Metformin) (that suppresses hepatic glucose output) becomes valuable

**What’s happening clinically when we see decreased hepatic glucose output?**

*What’s true in the liver for that to be the case?*

- Start with the clinical observations
- If you look at our guidelines, they’ll have multiple ways of looking at insulin resistance
  - One that Julia likes is the [HOMA-IR](https://en.wikipedia.org/wiki/Homeostatic_model_assessment)
- What is going on in the body at this time is a [hyperinsulinemic](https://en.wikipedia.org/wiki/Hyperinsulinemia) state
- Whether or not you’re seeing increased glucose is this sweet spot that we’re starting to see increased triglyceride deposition within the liver, but not yet a compensatory response with circulating [hyperglycemia](https://en.wikipedia.org/wiki/Hyperglycemia)

***What is going on at the level of the hepatocyte and what’s going on with the lipid droplets that are associated with this precursor are unknowns (yet to be determined)***

- When you look at somebody clinically and they show up with [hepatic steatosis](https://en.wikipedia.org/wiki/Fatty_liver_disease) and you want to know where in the spectrum they are
  - And how to counsel them to avoid the downstream consequences that are potentially avoidable for them
  - You want to look at their **relative insulin resistance**
    - You are looking at circulating isolated insulin values and calculating either a HOMA-IR or some people do [glucose tolerance tests](https://en.wikipedia.org/wiki/Glucose_tolerance_test)

***You want to try to catch people in this window of either early insulin resistance or not yet developed insulin resistance***

**How are you defining steatosis?**

- An aggregate of ≥5% of the hepatocytes contain fat

## Methods of diagnosing liver disease, and how insights guide treatment and management strategies [33:30]

**How do we go about making that diagnosis accurately?**

- For such a prevalent phenomenon like stenosis, we have to be practical
- The vast majority will be diagnosed using an ***imaging-based modality*** rather than a biopsy
- It was originally defined based on histologic evidence
  - The [MRI-PDFF](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6054824/) is costly and not necessarily that readily available
- In Julia’s clinic, they use point-of-care techniques that are based on ultrasound technology
  - A plain old ultrasound that someone gets is generally not detecting steatosis at levels under 30%
  - ***So an important take home is a negative ultrasound does not mean that you don’t have hepatic steatosis***
- If a **regular ultrasound** needs a threshold of basically a third of the liver has fat in it, that’s a big threshold
  - Clearly, someone who’s getting a routine ultrasound for some other reason (their kidney and the tech just goes and puts the probe on the liver)

*What is it about the technique or the imaging software or hardware that allows a dedicated scan to detect with much greater sensitivity at that 5% threshold?*

- For [MRIs](https://en.wikipedia.org/wiki/Magnetic_resonance_imaging), it’s proton related
  - The proton density fat fraction has to do with basic physics and how reverberations occur with different fractions (namely, water versus fat)
- For something that we use called [vibration-controlled transient elastography (VCTE)](https://www.cghjournal.org/article/S1542-3565(14)00818-0/fulltext)
  - It’s point of care
  - It’s something that a lot of liver doctors are fond of (we’ll probably talk about it later when it comes to sequential testing)
  - It applies a calculator called a controlled attenuation parameter to attenuate some of the echoes, some of the light signals that the ultrasound is emitting in order to get to a more granular level of fat, how much, and the measures of it are in the level of sound waves
    - So we’re talking about decibels

**Fat accumulation in the liver as a result of overnutrition**

- You have some combination of exogenous fat making its way into the liver and also endogenous fat production (de novo lipogenesis within the liver)
- The net result is more fat is entering and staying in the liver than is exiting the liver

***In most cases, we also see a remarkable fat exodus from the liver as evidenced by a very high*** [***VLDL***](https://en.wikipedia.org/wiki/Very_low-density_lipoprotein) ***and a very*** [***high triglyceride***](https://en.wikipedia.org/wiki/Hypertriglyceridemia) ***burden***

- In other words, the liver is trying its darnedest to get the fat out
- And we measure this high amount of fat, which might be a clue that there’s a high amount being accumulated
- Given the complexity of metabolism and the liver’s desire to maintain homeostasis, before the liver even sees that you’re overwhelming your subcutaneous [fat] compartment

**Some people are not expressing higher levels of circulating triglycerides and don’t have these metabolic features**

- That’s a tip to the clinician that maybe this isn’t garden variety metabolic dysfunction, fat deposition in the liver, and you might need to be thinking about **something a little bit more rare**
- This is different from the obvious and well-known race-based differences
- For example, even in situations of type 2 diabetes, African Americans will rarely exhibit an elevated triglyceride level the way a Caucasian will
  - You’ll see a triglyceride of 400 versus a triglyceride of 90 in 2 people that are equally insulin resistant
- Julia is speaking to some of the rarer causes that get lumped into hepatic steatosis where there’s a trafficking (an export) problem

**How does this rarer cause of hepatic steatosis come up clinically?**

- Julia will put a probe on someone and see their BMI is 22
- They have very little evidence of insulin resistance and their [CAP score](https://www.mskcc.org/cancer-care/patient-education/understanding-your-fibroscan-results) (something used to grade fat) is very, very high, 400
  - That’s a tip-off that potentially there’s a genomic [familial hyperlipidemia](https://en.wikipedia.org/wiki/Hyperlipidemia#Familial_(primary))
  - There is something that’s going on that may be making their liver store fat in an anomalous way that’s not reading the room in terms of metabolic risk

***Julia points this out because of the prevalence of disease and it’s important to pick out the folks that may not respond to some of the current recommendations***

*Peter had a friend where this was the case*

- He had [elevated transaminases](https://en.wikipedia.org/wiki/Elevated_transaminases)
- But he clearly didn’t fit the bill of anything as he was: lean, athletic, etc.
- It wasn’t until he had an MRI for an unrelated reason that they noticed the amount of iron accumulation in his liver
- He had [hemochromatosis](https://en.wikipedia.org/wiki/Iron_overload) that had somehow been previously undiagnosed
- He had accumulated enough iron in his liver that it was actually beginning to show these signs of injury through the elevation of transaminases
- That’s one of the drawbacks of the ubiquity of all of this liver disease
  - Besides the obvious, which is it sometimes makes it harder to identify the “zebras” when there’s so many “horses” everywhere
- Julia thinks about this a lot, how we pick out the “extreme phenotypes,” and how we can better understand some of the biological targets that are driving disease
- An easier way to do that is to look at some of the extremes
  - The folks that don’t have all the metabolic risk factors but do have pretty aggressive disease
    - For example, lean people that are a normal body habitus and then manifest rip-roaring metabolic dysfunction including steatohepatitis plus or minus fibrosis

**Back to the point of racial differences**

- We talk a lot about ancestry and when you have ancestry distributions, for example, South Asians: same predominance that you’ll see with sort of lean diabetes, some of the [MODY](https://en.wikipedia.org/wiki/Maturity-onset_diabetes_of_the_young) phenomenon that you are aware of
  - You can see very, very aggressive forms of not just altered metabolism within the liver, but aggressive inflammation and scar tissue
    - The latter (injury) is usually what is needed to get the attention of a lot of the liver folks, not just the accumulation of fat
    - The fat is much more important from a metabolic endocrinologic perspective
    - We tend to perseverate on the people with a lot of liver injury

## The poisonous nature of ethanol to the liver [40:30]

- People get bent out of shape about the word poison, so feel free to use whatever word you want
- Peter thinks the dose makes the poison
  - Everything is technically a poison
  - Tylenol is clearly a poison, whereas a low dose of Tylenol is a wonderful thing if you’ve got a splitting headache or a fever, but at some point you exceed the capacity of the liver to metabolize it and it goes from being not harmful to deadly

**What is it about the metabolism of ethanol that is problematic for the liver?**

- Ethanol (or alcohol) gets processed in the [hepatocyte](https://en.wikipedia.org/wiki/Hepatocyte)
- A normal liver cell uses [alcohol dehydrogenase](https://en.wikipedia.org/wiki/Alcohol_dehydrogenase) to convert alcohol to [acetaldehyde](https://en.wikipedia.org/wiki/Acetaldehyde)
- Acetaldehyde is then metabolized further and it eventually becomes carbon dioxide + water

***Where you start to see problems is when the capacity of*** [***redox potential***](https://en.wikipedia.org/wiki/Reduction_potential) ***is overwhelmed***

- Again, these are very variable if you look at populations
  - How alcohol is handled in various populations
  - And even just the dimorphic differences in sex between men and women of how livers metabolize alcohol
- That normal process can be overwhelmed and then all of a sudden you start to have **peroxidation**, and that’s a feature that we see in the non-alcoholic or the metabolic dysfunction that’s not associated with alcohol-related liver disease
- That’s about 80% of the alcohol metabolism

*There’s another pathway that’s also invoked when there’s alterations and injury and toxicity*

- That’s when you have the acetaldehyde behaving badly (kind of like you’re describing as a toxin)
  - It’s attracting free radicals
  - It’s attracting immune cells
  - It is leading to fat deposition, altered metabolism at the level of the cell
- Different enzymes are being used
- But that’s some of the commonalities when we look histologically at somebody who’s not using alcohol versus someone who is, there are some features that you cannot distinguish histologically because the injury pattern is so similar

**Peter’s takeaway**

- When we talk about the metabolism of ethanol, we have this enzyme **alcohol dehydrogenase**
  - We know as some people genetically are lacking in that enzyme or don’t have as effective a version of it
    - These people tend to be incredibly sensitive to alcohol
    - They get beet red when they drink it
    - In some regards, they’re largely protected from the toxicity of alcohol because they simply can’t tolerate it
- For most people you go ahead and you metabolize it and while the downstream stuff is ultimately the same as the normal carbohydrates (basically CO2 and water), you get **acetaldehyde** as an intermediary

**Why is acetaldehyde toxic as an intermediary?**

*Peter asks*

- Does it stick around long enough to cause problems?
- Why isn’t it all just being flushed to CO2 and water quickly?
- It’s sort of like saying when we metabolize glucose, we stock at pyruvate before we go to Acetyl-CoA and CO2 and water
- You wouldn’t think of pyruvate being problematic unless it’s stuck around for a really long time.

*Help us understand why any minor exposure to acetaldehyde is problematic, even if it’s very brief?*

- It would be hard to say where the system is overwhelmed unless you had a system-wide, diverse cohort
- What we can say is that it does attract **inflammatory cells**
- Julia analogizes it to the lipotoxicity model in her favorite disease, [metabolic dysfunction associated disease](https://en.wikipedia.org/wiki/Metabolic_dysfunction%E2%80%93associated_steatotic_liver_disease)

***There’s something about that moiety that makes it pro-inflammatory***

- And how the body, how an individual, and how that liver will handle the inflammation that’s a resultant of the acetaldehyde attracting [free radicals](https://en.wikipedia.org/wiki/Radical_(chemistry)#In_biology)

***And overwhelming the*** [***redox potential***](https://en.wikipedia.org/wiki/Reduction_potential#) ***of that cell is one mechanism by which injury is occurring***

- Know that not every cell is going to behave similarly, and so the relative injury of some cells versus others, the compensatory damage and recruitment of inflammatory handlers, whether it’s monocytes, macrophages or lymphocytes, is also going to play a role
- We’re starting to get at some of the complexities that are extremely hard to tease out unless you’re thinking not just molecularly but as a liver as a whole

**Say a little more about the differences between men and women in their capacity to metabolize ethanol and susceptibility to its toxicity**

*Peter is also curious to hear about how much heterogeneity there is*

- Alcohol has been studied longer than any of the viral hepatitises
- A lot of the sex differences were just attributed to the fact that alcohol is a polar compound and so it’s less soluble in fat
  - And women’s body composition typically has more fat
  - The relative damage that could be done was based on body composition
    - Julia doesn’t know that that’s necessarily true, but it was an easy way to sort of explain some of the early differences at that point
- When it comes to gene expression, you’re going to have to look specifically at premenopausal women versus postmenopausal women
  - And not just androgen components and estrogen components, but also the upstream signaling of all these
  - Julia is not an alcohol expert, but as far as she knows, none of these have been teased apart in terms of sex differences specific to the premenopausal women

***For premenopausal woman, 14 grams is what can be handled in terms of the liver and subcutaneous fat component and hormonal responses to the compound acetaldehyde generation or other potential toxic moieties***

- But these are all variables to be studied

## Varied responses to alcohol, damaging effects of alcohol beyond the liver, and the process of advising patients on their alcohol consumption [47:15]

- Peter [wrote](https://peterattiamd.com/why-do-women-have-lower-alcohol-tolerance-than-men/) about this: it’s historically been chalked up that the differences between men and women are size differences, but he thinks there are differences in gene expression that play a much greater role than size

**Is alcohol less toxic to some people?**

- You’ve got two people who both weigh 85 kilos (so their size is comparable), their body composition is similar enough, let’s even grant that they’re metabolically comparable in health
- They can have two very different responses and susceptibilities to alcohol
- There are probably a lot of people listening who think, well, “*I’m one of those people who can drink a lot and it doesn’t seem to have an effect on me.*”

*Does that mean that alcohol is less toxic to them?*

- Julia’s biases
  - A lot of people think that toxicity is only occurring at the level of the liver
  - She sees (especially in post-transplant patients) post reformed alcohol use, the effects on the brain, the effects on the heart, the effects on the pancreas
    - There’s a panoply of organs that can be affected by what’s considered normal or moderate, less than moderate alcohol intake
  - And so how someone is considering themselves not affected is also really important
  - There’s the psychosocial components as well
- The big one that a lot of people are failing to talk about tis  the **oncogenic potential in DNA disruption**, and how to measure than and how to mitigate some of those risks
  - The World Health Organization came out with a [consensus statement](https://www.who.int/europe/news/item/06-11-2023-joint-statement-by-who-europe-and-iarc-to-the-european-parliament---raising-awareness-of-the-link-between-alcohol-and-cancer) in 2023
- Some people are subjectively saying they don’t feel affected by alcohol from a central nervous system perspective (that their sensorium is altered)
- Sensorium is used to grade [hepatic encephalopathy](https://en.wikipedia.org/wiki/Hepatic_encephalopathy), there are some mood changes that happen in the CNS
  - Either depressant effects or removal of inhibitions, some of those effects are also socially acceptable CNS related effects, but they’re effects

**At what point does the dose of ethanol in grams per day or per week start to become problematic?**

- This is a topic that Peter has [written](https://peterattiamd.com/low-to-moderate-alcohol-consumption-and-longevity/) about at length and he *rejects* the data that says there is a J-curve [for alcohol consumption]
- He has not been convinced by the J-curve data, which is largely epidemiologic and largely suggests that at very low doses, zero alcohol is actually slightly worse than some alcohol
  - Then of course the risk goes up as drinks go up, but there’s some sweet spot which depending on the study, can be actually quite high for alcohol consumption to produce the lowest all-cause mortality

***Peter thinks there are many ways to explain those data that are a better explanation than alcohol is good for you at some dose***

- The [Mendelian randomizations](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8956974/) point to the opposite, which is a monotonic change in risk that increases consistently from zero and upward
- But of course this risk is nonlinear with dose
- It begs the question then for people who want to choose to drink responsibly, at what point do you say the risk is probably too great?

**If we’re not going to be complete abstainers, at what point do you tell somebody, “*****That’s a little too much*****”?**

- This is a loaded question because Julia is thinking more about the liver
- The way doctors think about injury are **markers of necroinflammation**
- AST and ALT are not functional
  - They’re markers of injury
- We think of much more meaningful things in terms of being functional: albumin, synthetic function in terms of coagulation, and also glucose handling
- She has many patients that have a degree of hepatic steatosis and their only risk factor is alcohol intake
- If they’re not having any dysregulated metabolism, they’re not distressed by this abnormality, and we’re able to monitor them
  - If the net gain to them from all sorts of inputs (including social inputs) is that their alcohol level is not causing major life events (including effects on their family or things that maybe are harder to talk about)

***Then there’s a permissive to that, but it’s just like supplement use***

- At some point, contaminated supplements or unknown supplements may cause evidence of liver injury

***Julia discusses this with patients with an openness to can you give this up if it becomes problematic?***

- Problematic either physiologically to the liver, to another organ, to relationships, etc.
- [Julia emphasizes via email that these views are her own not those of her institution]

**There are all sorts of ways of looking at problematic use disorders**

*The big driver for all liver diseases (parenchymal liver diseases) is what is the behavior and the motivation behind engaging some of these things?*

- That’s how the relational component with understanding why someone is doing what they’re doing can really make a big impact
- Because 2 or 5 years down the road, when you ask them to give it up because there’s a new breast cancer diagnosis
- Or the patient brings it up in terms of what disease modifying changes can they make in order to improve their lifespan

> “*The risk of breast cancer is higher than the risk of liver disease for most women who are consuming alcohol*.”‒ Julia Wattacheril

- The origin of the desire in terms of engaging in some of these behaviors is what Julia will go back to when talking about these questions with patients
- Humans are far more likely to give up something they don’t find beneficial

**Julia’s advice on a specific example of social drinking**

- Let’s say an individual comes to Julia and says, “I *consume alcohol socially, and if you go and talk to my friends, family, children, they would all tell you it’s not a problem in my alcohol consumption.*”
  - Meaning there’s no unintended consequence that is negative
- They have a normal liver synthetic function
  - That’s a late finding, if they don’t
- Their [transaminases](https://en.wikipedia.org/wiki/Elevated_transaminases) are normal (we’ll explain what that means later)
- In as much as we can assert, their kidney function is normal, cardiac function is normal
- If all of these factors look okay, would you say, “*I’m alright with you drinking two glasses of wine in evening*”?
- Or are you still saying, “*Look, there are still things I can’t measure and even normal transaminases don’t give me a good enough confidence that you are not causing irreversible harm here*”?
- Julia wouldn’t use aminotransferases as a good marker
  - More often we use a bedside imaging technique (the [vibration controlled transient elastography](https://www.cghjournal.org/article/S1542-3565(14)00818-0/fulltext)) because the sensitivity of picking up on hepatic steatosis is higher
  - It actually takes quite a bit of derangement and problematic drinking to derange your aminotransferases
- An early warning sign is when you start to see fat accumulation in the liver, and there are potential downstream metabolic consequences, potential inflammatory consequences

***This doesn’t mean that they have to give it up, but it really tattoos to the patient in their experience tha***t ***there are measurable effects of even moderate, what’s considered social drinking and it is very, very variable***

**The importance of quantifying use of alcohol with patients**

- Julia explains that it’s good for audience members that are clinicians to quantify the use of alcohol
  - Especially now, post pandemic
- Just like the ALT has been perturbed based on environmental changes in our population, so has the **definitions of moderate** use
- Going through that with patients can sometimes give you a little bit more information about how they’re perceiving their risk

**How do you ask people specifically about that?**

- Peter asks patients, “*On average, how many drinks do you have in a given week and what’s the variance of that?*”
- First, we define what alcohol is
  - Oftentimes one drink might be double the quantity that we’re used to seeing (in terms of concentrations)

***Julia defines a*** [***standard drink***](https://www.niaaa.nih.gov/alcohols-effects-health/overview-alcohol-consumption/what-standard-drink) ***as: 1.5 ounces of hard liquor, 5 ounces of wine, or 12 ounces of beer***

- That will get some raised eyebrows from people because patients don’t know about those quantities
- The CDC **definition of moderate alcohol** intake is 2 drinks per day for men and 1 drink per day for women (standard drinks)
- People will oftentimes say, “*I don’t have a problem with drinking. I don’t drink every day*.”

***Julia asks about the quantity over what period of time for those standard drinks***

- Then she asks, “*What’s going on in these situations that you feel?*”
  - Is that you’re with family gathered over the weekend?
  - Is it at home?
- In the pandemic, it was a lot of isolated drinking at home, and that’s where we started to see some of the chemical changes, some of the imaging based changes, and then more importantly, some of the social changes that happened with problematic drinking
  - Because the slope can vary without an individual being aware
    - This is why Julia thinks it is important to quantify it
- The other **test** liver specialists will also do is measure the longer range metabolite, something called [phosphatidylethanol (or a PEth)](https://en.wikipedia.org/wiki/Phosphatidylethanol#Marker_in_blood)
  - It’s a little bit more like an [A1C](https://en.wikipedia.org/wiki/Glycated_hemoglobin) than a rapid identifier
  - Like an [ethyl glucuronide](https://en.wikipedia.org/wiki/Ethyl_glucuronide)
  - It gives us an idea and it’s graded in terms of moderate versus severe
- Sometimes that gives you an aspect, another angle to interview a patient
- There’s a lot of shame around alcohol use and what’s going on in an individual at times

***When you see really severe heavy alcohol use, but a self-report of something far less severe, it’s an opportunity to figure out what’s going on***

**If the A1C looks back about 90 days, how far back does the phosphatidylethanol or PEth study go?**

- On the order of 1-2 weeks
- It’s not something that lasts 90 days

**Can you order that through Labcorp or is that a super specialty test?**

- Julia thinks it’s a readily available test that you can order from [Labcorp](https://www.labcorp.com/tests/791584/phosphatidylethanol-peth) or [Quest](https://www.questdiagnostics.com/healthcare-professionals/clinical-education-center/faq/faq293)

## Understanding liver enzymes—AST and ALT—interpreting levels, lifestyle factors that affect them, and diagnostic approaches [58:30]

- Peter points out that everybody listing to this podcast knows to look at AST and ALT
- They get called liver function tests, but they’re really not proxies for liver function

**What does AST and ALT do in a cell under normal physiologic circumstances?**

*What happens that leads to their elevation in the serum, in the plasma when things go awry?*

- [AST (aspartate aminotransferase)](https://en.wikipedia.org/wiki/Aspartate_transaminase#Clinical_significance) and [ALT (alanine aminotransferases)](https://en.wikipedia.org/wiki/Alanine_transaminase#Clinical_significance) are enzymes and they are usual working enzymes to help process things that go through your liver
- Normal liver physiology: there are 2 blood supplies to the liver
  - 1 from the portal circulation, and that’s what drains your guts
    - All the nutrients that you take in that are processed in your intestines, they get shown to your liver through that portal system
  - The other one is the hepatic artery
- These 2 blood supplies are one of the many forms of resilience of the liver
- The blood percolates in this very porous milia showing all the hepatocytes what they have by way of nutrients, toxins, etc.
- Then those things are filtered through hepatocytes, and there’s lots of enzymes
- These are enzymes that we typically measure, and they also exist in muscle
  - Whenever we get some rare cases of elevated aminotransferases, we have to make sure that they’re coming from where we think they’re coming from
- The definitions of normal have evolved over time and sometimes different thresholds are set for different diseases
  - In the earlier days we said 19 and 30 were our thresholds
    - In terms of what we expected the aminotransferases to be for men and women, and what we would consider abnormal
  - The labs often flag them when they’re in the upper 40s or 50s
- What is the definition of normal? How much does this matter?
- When it is flagged as abnormal, how much should you get anxious about that?
- Julia explains, “*In general, again, we want to harp on the fact that the liver is extremely resilient*.”
- When you get an isolated abnormality, what that is telling you is that liver cell (hepatocyte) is now under so much stress that it’s now what we call necroinflammatory marker
  - Necro being cell death and inflammation mostly
  - That cell is under stress and is now bursting

***When that liver cell bursts, it releases these enzymes into the bloodstream, and that’s what we’re checking with blood tests***

- The question is why are those enzymes elevated and is it an isolated phenomenon (such as you had mononucleosis, you’re over your virus), or is it chronic?

***Something that’s continuing over a period of 6 months is the definition of chronic liver disease***

**When those elevations have persisted is when we start our workup**

- Julia wants to know: why is this inflammation and cell death happening in this liver?
  - Is it due to our top 3 in adults: alcohol, viral hepatitis, or [MASLD](https://en.wikipedia.org/wiki/Metabolic_dysfunction%E2%80%93associated_steatotic_liver_disease)
    - MASLD being the most common globally and in the country)?
  - And is there something more rare that we are missing?
  - Is there a potential that there is something treatable, that there is something reversible at this earliest stage of laboratory detection?

**Julia has reiterated a point that Peter has tried to make several times over the past several years: we never want to confuse a laboratory’s standard for what is normal**

- Because the laboratory is simply reporting on a **population distribution**
- And if the population’s health is deteriorating over a 50-year period of time, that isn’t necessarily a reason we should hold ourselves to the standards of unhealthy people today
- Peter just had his labs done last week, and he thinks Labcorp has a cutoff is 40 or 44 for the AST and the ALT
- But if you went and looked at what was the cutoff 50 years ago, you’d see a much lower number (probably 25 to 30)
  - And presumably that’s the 80th or 90th percentile of the population

***It’s not likely that the liver has changed from an evolutionary perspective in 50 years; it’s more likely that we’ve seen a drift towards liver injury***

**Where do you think the right place to have those transaminases be as one more piece of the puzzle (not the only piece of the puzzle)?**

- For the vast majority of people, they are doing well when this is under 30

*When does Julia start to get alarmed?*

- In the liver world, we think of fold differences

***When it [AST and ALT values] is consistently 1.5-2X the upper limit of normal (when it’s in the 50s and 60s), it tells us something is potentially going on in the liver***

- Julia will then start to pursue a workup to determine if it’s a result or a cause of other symptoms in their body, other disease processes

**Peter’s recent bloodwork**

- Peter’s AST is always significantly higher than his ALT
- Last Friday when he had his blood drawn, his ALT was 21 but his AST was 34 (and those are typical values for him)

*What are your thoughts on those values?*

- Julia realizes that the audience is capable of reading the guidelines and she wants to make sure everyone knows that the **threshold for workups**, etc. is around 40
- Julia would ask, “*Did you work out within 24 hours of that laboratory assay, and if so, what type of resistance work or muscle work did you do?*”
- Peter went to the doctor in the afternoon and had already done a 2-hour workout in the weight room that morning (from 8-10)
  - The blood draw was at noon
- Follow up question, “*Have we ever drawn blood on you on a non-workout day, on a rest day?*”
- Yes, Peter would still see the same pattern if the blood was drawn first thing in the morning, but it would still be within 24 hours of a workout
  - Because he would’ve lifted on been on the bike or have been rucking the day before
- If the question is, has he done a blood draw with more than 24 hours of no exercise
  - The answer is, probably not
- Julia adds, “*I would be curious if you had ever had a* [*CK*](https://en.wikipedia.org/wiki/Creatine_kinase) *done (a creatine kinase) just to look if there’s any evidence of muscle breakdown*.”
- Anytime Peter gets a CK done, let’s pretend that the threshold of abnormal is 200; he’s typically right about there
- Julia asks these questions based on knowing a little bit about Peter and making some assessments based on body composition and potential risks
  - The line of questioning may be very different with someone else
- Peter adds that he does drink alcohol (Julia was going to ask about this next)
- Julia asks about when Peter’s labs are done and the relationship to alcohol intake
- Peter wishes he could say he is more thoughtful about this, but he’s never one that likes to cram for the test
  - He tries to never change behavior before a blood test
- What he can safely say is any blood test he’s had is probably a reasonable sampling of his typical pattern of alcohol consumption
  - Based on the [standard drink](https://www.niaaa.nih.gov/alcohols-effects-health/overview-alcohol-consumption/what-standard-drink) (defined earlier), he’s in the 6-8 drinks per week category
  - He virtually never has more than 2 drinks in a day
  - That makes him a moderate drinker
- Let’s assume that he had 30 grams of alcohol within 24 hours
- Julia also asks, “*Is there anything that’s bothering you about your blood tests? What is your impression of them?*”
- When Peter looks at the bloodwork of many of his patients who have AST’s and ALT’s in the teens, he wishes his values were in the teens
  - He also realizes that most of these patients are women with a very slight build, so there may be a component that is related to muscle mass
- Peter also points out that his [creatinine](https://en.wikipedia.org/wiki/Creatinine) is always quite high, but his [cystatin C](https://en.wikipedia.org/wiki/Cystatin_C) is very low, and his renal function is great
  - If you look at his [eGFR](https://en.wikipedia.org/wiki/Glomerular_filtration_rate) (by creatinine), it’s about 70
    - Whereas by cystatin C, it’s about 110
  - He sees this in a lot of patients who exercise, so that may be a component
- Julia agrees, “*It’s the injury component to the muscle.*”
  - To be clear, having a big muscular build is not necessarily injurious in terms of detection of aminotransferase elevations
  - The most common one that we talk about are like marathon runners with [rhabdo](https://en.wikipedia.org/wiki/Rhabdomyolysis), etc.
  - It’s not just having the component of muscle, but also just the workout and the injury component and recovery component

*Peter also wonders about supplements and medications*

- He does take one medication that at least in patients we often see an [elevation of transaminases](https://en.wikipedia.org/wiki/Elevated_transaminases), and that’s [ezetimibe](https://en.wikipedia.org/wiki/Ezetimibe)
  - He could do the test of stopping ezetimibe and seeing if that has any effect
- Peter is a little lean on supplements these days, and the ones he takes tend to be pretty straightforward
  - Things like fish oil and magnesium and things like that
  - He’s not taking too many funky supplements that he’s seen in patients where they can really have negative impacts on liver function tests
- Julia explains that drug induced liver injury is where she sees a lot of elevations in aminotransferases
  - This includes supplements
  - So whether or not an individual is taking recreational substances is something she uses in the differential for that sort of laboratory assessment
- She always asks the patient about their assessment of the result because some individuals will perseverate
  - For example, if their fat fraction is 7% and they’re living an optimized life and the number itself is problematic to them, they think something is potentially abnormal or wrong
- In Peter’s instance, rather than withdrawing the ezetimibe, Julia would rather do labs
  - She asks, “*Would you consider doing labs after a series of rest days plus no alcohol intake?*” (you’re doing a controlled experiment)
    - Julia has patients do this all the time: they withdraw from alcohol for 6 weeks to see what is the effect on their fat fraction
    - Most of the time you can’t predict what your reaction will be

> “*But there’s something to be said about a measurable effect and how motivating that is. That’s something I’ve been humbled by a lot with some of our imaging based studies*.”‒ Julia Wattacheril

- Julia also thinks about what has happened in the prior decades of life, and that’s where she would do something like a **fibrosis assessment** to figure out if there’s a degree of stiffness or injury to the liver
  - It could be a quick calculator like a [FIB-4](https://www.hepatitisc.uw.edu/page/clinical-calculators/fib-4)

## Interpreting liver function tests for fatty liver disease, and the challenges of diagnosing liver pathologies, particularly in children versus adults [1:13:15]

- Peter uses Labcorp for much of his labs, and the last one he did the full [Labcorp NASH score](https://www.labcorp.com/tests/550960/nash-fibrosure-plus) was maybe 3 months ago
  - He doesn’t think he has fatty liver disease, but in order to test it on patients, he’s curious what it shows for him
  - It came back negative, no evidence of fatty liver disease
  - The scores were very, very low
- Peter suspects these scores are going to be used more and more frequently now

**Can you explain how the scores are generated?**

- There are so many
- There’s a whole serum based biomarker milieu and imaging based, and some of them were derived based on the hepatitis C population and then subsequently validated in metabolic dysfunction
- If we’re looking at something like a [FIBROSpect](https://prometheuslabs.com/disease-tests/fibrospect-nash/), etc. (something that’s been studied in [NASH](https://en.wikipedia.org/wiki/Steatohepatitis#Metabolic_Dysfunction_Associated_Steatohepatitis_(MASH))), you’re usually looking at something that’s got components of collagen matrix, of metalloproteinases, etc.
  - It’s looking at measurable [CK18 fragments](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10135741/), etc. that are detectable in the blood, that suggest not just fat accumulation in the liver, but also diabetes risk, and then subsequent inflammation, cell death, and eventual scar tissue
    - This takes decades to develop

***Most of the proprietary serum-based tests will give you a steatosis score, a fat score, and then they’ll also give you a fibrosis score***

- We use our bread and butter hepatic function panels
  - Which are not functions necessarily
- We also use a lot of **imaging based tests**, because they are so much more sensitive rather than these biomarkers that leave you with a lot of intermediate risk
  - It’s really hard to counsel patients with that [biomarker] type of information

**Results of one of Peter’s patients**

- One patient has transaminases values that are persistently in the 40s
  - It’s not quite enough to trigger a full million dollar workup, but something is not normal
  - There’s something pathological going on, even if it’s very, very low grade and doesn’t post an immediate threat to them in any way, shape, or form
- But Peter is in the business of medicine 3.0 (not 2.0), and he doesn’t want to wait until there’s a problem

Peter asks, “*If we get one of those NASH scores and it comes back zero, you’re saying, Peter, you’re not out of the woods yet. There’s a lot of nonsense that can be going on there.*”

**Should we mention** [**GGT**](https://en.wikipedia.org/wiki/Gamma-glutamyltransferase)**? Does that factor into your thinking beyond AST and ALT?**

*Fatty liver disease in children presents differently than it does in adults*

- One of the things that we notice is that in **kids**, the development of NASH looks different histologically than in adults
- There’s a lot to be said about what we know and what we don’t know
- The pattern of liver injury, if we were to look at your liver tissue under a microscope, we usually have all these zones when we’re doing detective work to determine why someone’s liver tests are abnormal
  - We’re coming at it from a histologic lens, where the activity is in the liver sometimes gives us a mini differential
- For **kids**, the activity of fatty liver disease typically behaves like other chronic liver diseases ‒ it’s what we call **portal-based**
  - It’s around the [portal triad](https://en.wikipedia.org/wiki/Lobules_of_liver#Portal_triad), which is a functional unit of the liver
    - The liver in many ways is beautiful and worthy of respect, but its architecture is really elegant
    - Portal-based diseases, autoimmune disease, this includes hep C

***We see a lot of the changes in children around that portal area whereas in adults, the changes are more around the central vein***

- In **adults**, we see it much more around the **central vein**
  - This drainage vein around the middle of that hexagon that Julia described before
  - You see fat, you see inflammatory cells
  - There are these things called ballooned hepatocytes, that we in pathologists love to perseverate over, and it’s a precursor to cell death
    - It’s like a hot air balloon
    - It’s shaped as a stressed out cell, its pre-hepatic
  - When we see that type of injury pattern around the central vein, that’s more typical of what we used to call **NASH**, but now call [MASH](https://en.wikipedia.org/wiki/Metabolic_dysfunction%E2%80%93associated_steatotic_liver_disease)
- Around the portal diseases we see much more of the [GGT](https://en.wikipedia.org/wiki/Gamma-glutamyltransferase), [alkaline phosphatase](https://en.wikipedia.org/wiki/Alkaline_phosphatase#Physiology), things that affect the bile ducts
- Oftentimes with **pediatric fatty liver disease**, we’ll see elevations in the GGT alkaline phosphatase, not necessarily to the point of having an elevated [bilirubin](https://en.wikipedia.org/wiki/Bilirubin) or a plumbing problem
- We also see higher degrees of elevation in aminotransferases, AST and ALT in kids and adolescents than would be predicted necessarily from an adult
- Peter did know there was a slight difference in the pattern between children and adults, but he didn’t’ realize that it was anatomically that distinct and that it resulted in a differential pattern of enzyme secretion
  - Yet another reason why it’s so easy to be fooled

***There are so many degrees of variation that we can describe clinical observations to you, but it doesn’t necessarily get at the mechanism or the driver as to what’s causing those differences***

## Comprehensive liver health assessments via imaging and various diagnostic tools to prevent overlooking potential liver pathologies [1:18:45]

**How an ultrasound should be done**

- Peter wants to make sure he is relying on the gold standard and not missing something
- He worries that they are running the risk of missing something by just relying on ASTs, ALTs, and NASH scores
  - Whether the injury, the inflammation, the fibrosis is the result of alcohol or nutrient or something else
- Julia explains, “*The framing around how to deal with the relative risk and the anxiety provoked or alleviated by negative testing and sort of a modicum of humility that a whole bunch of negative testing doesn’t necessarily mean that nothing ever bad will happen*.”
- She does a lot with genomic analyses and depending on how targeted the testing can be, **a negative test** does not mean nothing is ever nor will be wrong with you
  - Sometimes folks get anxious and it’s more sort of an off-ramp
- Julia likes to understand the psychology behind why people are interested and how they’re going to utilize that information

*If she were to see a patient for early-stage disease*

- That’s non-cerotic, non-portal hypertensive, non- transplant
- They are referred because of an imaging abnormality
  - Absolutely no blood test abnormality

**The 2 most common referrals for hepatologist are abnormal aminotransferases or abnormal imaging**

- These are not the super sick people
- The abnormal liver imaging may be a reflection of [hepatic steatosis](https://en.wikipedia.org/wiki/Fatty_liver_disease)
- The error we want to prevent anyone who sees something like that, is just a knee-jerk reaction that that is NAFLD and MASLD, and not to forget about asking about the biggest differential which is **alcohol**, and then also when to invoke some of the more **rare biochemical involvement**
  - ***That’s where just talking to your patient is going to give you a lot of information***
- For patients who do not drink alcohol, who present with an abnormal image or are interested in being proactive about their liver health, it boils down to the conversation
  - What are their risks?
  - Do they have metabolic risks?
  - Do they have habit risks in terms of either recreational drug use or pharmaceutical agents?
    - [Methotrexate](https://en.wikipedia.org/wiki/Methotrexate) being one that needs liver-based monitoring

**How Julia gets a snapshot of the liver and overall patient health**

- We always start with a **basic blood test** (that’s what Peter has described already)
  - Including aminotransferases
  - And then [decide] whether or not a **liver image** is warranted

*Clinical risk factors used to determine if a person needs secondary testing*

- What is their metabolic health?
- BMI
- Metabolic syndrome risk factors
- Cardiometabolic risk factors
- Habits: social habits, exercise, engagement around different forms of nutrition
- Hepatic function panel
- Calculating something like a [FIB-4](https://www.hepatitisc.uw.edu/page/clinical-calculators/fib-4), where those functions have been elevated over a period of time
- A male over 50 ± insulin resistant diabetic
- Julia will hardly ever refer for an ultrasound because most of the time that has already been done
- The **threshold for detection for an ultrasound** is around 30-33% to pick up on hepatic fat (mentioned earlier)
- A lot of it will depend on what is available to you, around you

**Tools that are price performance based**

- [VCTE (vibration-controlled transient elastography](https://www.cghjournal.org/article/S1542-3565(14)00818-0/fulltext)) and then ultrasound [elastography](https://en.wikipedia.org/wiki/Elastography#)
- Julia’s radiology colleagues have picked up on some of the different ways that you can attenuate the ultrasound in order to calculate fat fractions
- For very sophisticated testing: **MRI-PDFF** (proton density fat fraction) is used in research studies and they’re increasingly available clinically
  - MRIs are very good at detecting and quantifying the amount of fat, but also depending on the protocol, the amount of iron
- And when you add what we call an elastography component you typically get 2 scores: a fat score and a scar score
  - Elastography component means you’re not just shining a light or changing the imaging signal intensity to the liver, but you’re also creating vibrations
  - A normal liver is soft like a sponge, and when it’s filled with blood it’s a little bit more dense
  - A cirrhotic liver (full of scar tissue) is much harder like a brick
  - All of these elastography based techniques (whether it’s MRI elastography or vibration controlled elastography) are literally shaking the liver
    - They’re sending vibrations across the liver and saying, “*Is that vibration as it’s coming back and being detected more in a sponge-like fashion or more in a brick-like fashion?*”
  - The **scar score** matters a lot to us in the liver disease world
  - The **fat score** is the one that’s easiest to modify
    - If you give up drinking, if you were to lose a modest amount of weight
    - Depending on how you see lipid related risks from a cardiovascular health perspective, very often a statin or a lipid lowering compound results in a tiny elevation in an amino transferase
    - And when we’re looking at net-net cardiovascular risk, we give blessings in the same way that we give blessings to chemotherapy induced liver injury, because we’re prioritizing what the overall risk to that human is
    - This is a bit of a tangent

***Julia’s framework for viewing an individual coming to her for overall liver health includes***

- Family history of first degree relatives
- And cancer potential

> “*The big thing that we need to talk about that we don’t necessarily talk a lot about, is metabolic risk and cancer*.”‒ Julia Wattacheril

- Oncologic risk in addition to metabolic risk is something that we’re seeing more and more of
  - Not in a causal way but in a disease association, especially in the young

**When you use the term vibration controlled elastography and ultrasound elastography, are they being used interchangeably or are those two different tests?**

- 2 different tests
- The proprietary name of the Echosens machine is called [FibroScan](https://www.echosens.com/en-us/)
  - That is point of care
  - You get an image generated at the time you see the patient and it uses both ultrasound based technology for the fat score and then the elastography vibration technology for the stiffness
  - It’s a measure of liver stiffness
  - There’s errors, but it’s generally widely studied, well validated across different groups including people with a lot of subcutaneous tissue
  - It’s not technically feasible in about 8-10% of Julia’s patients
- [Shockwave elastography, ultrasound elastography](https://radiopaedia.org/articles/ultrasound-elastography-1?lang=us) are typically done by radiologists as are MR elastographies
- Every site is a little bit different
  - Sometimes for Julia’s center, they don’t unbundle an MRI from the elastography
- So from a price performance, availability, when she’s talked to either internists or endocrinologists, becoming familiar with 1 or 2 tests and using them, will help train that 6th sense as to “*Am I missing something? Is this person best served by this test or is this something that I need to refer for expertise on?*”

***The list of tests are huge and the elastography component can be either MRI-based or ultrasound-based***

## Potential impact of recreational drugs, statins, and other medications on liver function test results [1:26:45]

**Can you say a little bit more about which recreational drugs might be the driving feature if you’re seeing otherwise unexplained elevations of** [**LFTs**](https://medlineplus.gov/lab-tests/liver-function-tests/)**?**

- This came up a little bit when they talked about viral hepatitis earlier
- What you may have done in the 70s or 80s is oftentimes a risk factor
  - This can be injection drug use, IV drug use, or intra nasal cocaine that is shared between different individuals
- There’s a ton of people with **undiagnosed hepatitis C** that are picked up on screening exams, and the only thing we find is drug use in the late 80s, etc.
  - Back in the day before we screened blood products as well
- In the 7th, 8th decade of life Julia sees women that may have had a hysterectomy
  - So **contaminated blood products** [could have given them hepatitis C]
- Other questions that Julia asks patients are about **dental work abroad**
  - Contaminated types of things are risk factors for various forms of viral hepatitis

**It’s not that current use of pick your favorite drug, marijuana, is necessarily hepatotoxic**

- No, it’s not in terms of this question

**The use of lipid-lowering agents**

- From Peter’s experience, the most predictable manner in which we see an [elevation of transaminases](https://en.wikipedia.org/wiki/Elevated_transaminases) is with the addition of [statins](https://en.wikipedia.org/wiki/Statin), especially if combined with [Zetia](http://zetia)
- The general consensus is that unless the elevation exceeds 2.5, maybe 2X the upper limit of normal, it’s deemed not clinically relevant
  - Peter is not sure that’s what he heard Julia say
  - What he thinks he heard is, the benefits outweigh the risks
  - Those are two different things
    - In other words, if a person takes [Crestor](https://en.wikipedia.org/wiki/Rosuvastatin) and Zetia, and their transaminases pre-therapy are in the 20s and post-therapy, they’re 50, he hopes there’s a reason they’re taking Crestor and Zetia
    - He hopes that that speaks to a risk reduction that’s significant with respect to ASCVD

*But we shouldn’t conclude from that, that their liver is happy, should we?*

- No, and this is where we get into the full differences
- If you’re looking at a change from 19 to 25, 19 to 30, you’re still within the range of normal
  - Most people would say risk-benefit favors continuing on that lipid-lowering agent
- If you’re persistently elevated, and we’ve gone so far as to look with biopsies, etc.; in very rare circumstances, is there actual liver injury that’s happening with some of these drugs?
  - Julia can count on 1 hand how many times we’ve seen demonstrable liver injury that we think is associated with 1 of these lipid-lowering agents

***The real summary point is that there’s so many alternatives oftentimes, that don’t induce or cause elevations, that are well tolerated and have a either more potent lipid-lowering effect or better tolerated by that person***

- So it depends on the degree of elevation within the bounds of what we expect as sort of the upper limit of normal or is there some evidence of liver injury going on and is there an alternative?
- Peter tends to be very aggressive on this
  - His practice doesn’t tolerate elevations of AST and ALT
  - Today we have far more tools in our toolkit to get people off those drugs if that’s what’s happening

## Shifting nomenclature from NAFLD to MASLD to reflect accuracy in the underlying pathophysiology and understanding of liver diseases [1:30:30]

**Nomenclature change in the last year**

- Many listeners are familiar with the terms [NAFLD (non-alcoholic fatty liver disease)](https://en.wikipedia.org/wiki/Metabolic_dysfunction%E2%80%93associated_steatotic_liver_disease) and NASH (non-alcoholic steatohepatitis)
- Now there’s a different term [MASLD](https://en.wikipedia.org/wiki/Metabolic_dysfunction%E2%80%93associated_steatotic_liver_disease), which Julia has alluded to several times
- [[The Journal of Hepatology](https://www.journal-of-hepatology.eu/article/S0168-8278(23)05075-4/fulltext#:~:text=Three%20years%20later%2C%20the%20term,seven%20parameters%20of%20metabolic%20dysfunction.) distinguishes MASLD and MAFLD while a more [recent article](https://www.oaepublish.com/articles/mtod.2024.06) concludes that patients with fatty liver disease usually meet the criteria for both MASLD and MAFLD]

*First define the term and secondly, explain why people have decided to make this change*

- A big component is we’re listening to patients a lot more and trying to incorporate their thoughts about how we label their disease
- Some of the problems we had with the name NAFLD is that the disease was defined by what it wasn’t, and that left patients confused
  - Not only was non-alcoholic in the alcohol component, but you had to go through a laundry list of things that weren’t well explained by the name
- NAFLD was a compendious name, it was hard to say
  - We didn’t’ get around that with the new naming
- The name NAFLD also didn’t hit at the underlying physiology
  - Which is metabolic dysfunction

**Several things prompted the change**

- The terminology alcoholic was reflected differently in different global populations
  - Some populations really like the term non-alcoholic because it was clearly not alcohol-related, and they felt alcohol was very stigmatizing
  - A lot of the US population felt that having that term in there was stigmatizing
    - A common scenario that we have with people who do not drink alcohol at all and are found to have liver disease, is that they are labeled alcoholic by friends, families, doctors
    - It’s a natural assumption if you have liver disease, that it must be a result of alcohol
- There’s also stigmatizing feelings that were associated with the term fatty
- That’s some of the rationale behind changing the name to steatotic, as opposed to the interim name of metabolic dysfunction associated fatty liver disease
- And now patients are involved in a way that they probably should have been in the past

**Another reason is adherence to what is the actual underlying pathophysiology**

- We now have an umbrella term called **steatotic**
  - Steato is a Greek for fat
- Steatotic liver disease and MASLD is one group underneath that metabolic dysfunction-associated steatotic liver disease
  - We now have a category
- One of the issues with renaming is that we’re actually taking into account what humans do
  - They may have metabolic dysfunction
  - But they also may be drinking moderate amounts of alcohol ‒ so we call that metabolic alcohol liver disease or **METALD**
- We have a category for alcohol related steatosis
- We have a category for [monogenic](https://en.wikipedia.org/wiki/Genetic_disorder#Single_gene_disorder) [causes]
  - More and more we’re discovering abnormal particular [autosomal recessive](https://en.wikipedia.org/wiki/Genetic_disorder#Autosomal_recessive) conditions that are associated with increased fat in the liver
- And then our least favorite term **cryptogenic**, in terms of as yet *unknown* but has fat deposition in the liver

**Some medications are known to be associated with fat deposition in the liver**

- Oftentimes with Julia’s patients, she has to go through a list of all their medications because some medications are known to be associated with fat deposition in the liver
- The mechanisms vary
- This is something that if you are patients, if you’re listeners and if you’re clinicians who are following, that is all widely available in terms of what is known and there’s resources that we can supply

**Peter’s takeaway:** ***while the name sounds incredibly confusing, it is more granular than what we used to have***

- The name we used to have was [AFLD](https://en.wikipedia.org/wiki/Alcoholic_liver_disease) and NAFLD
  - So either you’re getting all this fat in your liver because you drink too much alcohol and that fat accumulation is leading to fibrosis, and if that fibrosis isn’t halted, it’s going to lead to cirrhosis
  - Or you’re getting too much fat in your liver because of over nutrition, and we went through the endogenous and exogenous differences, that fat itself is inflammatory just as all sources of fat that exist outside of the subcutaneous space are, whether they be visceral or peripancreatic or all sorts of things, perinephric
    - All of these things are pretty painful and that kicks off the cascade

***What you’re saying now is, no, this was a gross oversimplification and there are lots of pathways that get us here and they’re not even mutually exclusive***

- Peter asks, “*How many people are consuming alcohol and as a result of that or independent of that, frankly, are also over consuming calories? And so they have excess fat accumulation from a nutritional perspective plus the alcohol toxicity and all of these things are leading to this?*”
- The subset that he wants to focus on at the moment is the one related to nutrition
  - Because in North America we would place the metabolic-associated disease above even hepatitis and alcohol-associated disease

**Is this correct?**

- It depends on what end point you are asking about
- In terms of overall prevalence or risk for transplantation?

***In terms of all-comers prevalence of disease, yes***

- And not just for the US but also globally

**Is this also the one that disproportionately affects children?**

- If you think about the exogenous influences, for sure
- It varies, but most children do not get exposed to medications, alcohol or some of the other hepatotoxins until their teens

## Pathophysiology of MASLD, the need for proactive screening, and the significance of liver fat percentage as an indicator of metabolic health [1:36:30]

- Let’s narrow our scope to just talk about the metabolic association and talk about the pathophysiology

**Hypothetical patient**

- A patient just triggers the diagnostic criteria
- They are not consuming too much alcohol
- We have ruled out hepatitis and pharmacologic toxicity
- They fit the clinical picture of a person with [metabolic syndrome](https://www.nhlbi.nih.gov/health/metabolic-syndrome)
  - But Peter assumes that you don’t have to have metabolic syndrome

Peter clarifies, “If *you’re insulin resistant with or without metabolic syndrome and you hit the 5% threshold on your FibroScan, or whatever test we’ve used that has a high enough degree of sensitivity. That qualifies you as having MASLD, correct?*”

- Yeah, this is going through the diagnostic algorithm that Julia and her colleagues are hoping to do a better job of educating the population about
- It’s not just exclusion of those things, but it’s picking up on our current technology (either a biopsy or imaging that’s suggestive of steatosis)
- A lot of hepatologists downplay the metabolic components of livers because of the history of the nature of liver disease and how we’ve studied it

***But the cardiometabolic risk [of MASLD] does not require metabolic syndrome***

- Metabolic syndrome is important to pay attention to, particularly if we’re looking at quick clinical grab bag things that should make you think that that person has a risk factor for NAF
- Metabolic syndrome increases the risk for having the **inflammatory phenotype**
  - The one that we think progresses un-intervened upon unmitigated

***From a MASLD definitions perspective, how we get at staging of disease and progression is dependent on multiple risk factors***

- The take home point in terms of teasing out cardiometabolic risk: we have all the parameters that are listed and they vary a little bit by ethnicity
  - We’re much more sensitive about definitions of obesity and metabolic risk across different ethnic backgrounds that were not well described in our previous definitions.
- Any one of those cardiometabolic features will start to push you into the category of metabolic dysfunction-associated steatotic liver disease or MASLD

**Peter envisions a world in which we move so far beyond using something like MET Syndrome as the diagnostic criteria**

- He says this with great respect and appreciation for the work of someone like [Jerry Reaven](https://med.stanford.edu/news/all-news/2018/02/gerald-reaven-stanford-scientist-who-coined-syndrome-x-dies-at-89.html), who even brought this to the attention of people 30-40 years ago through [syndrome X](https://en.wikipedia.org/wiki/Metabolic_syndrome)
- When you think about how crass it is to say, “*Well, when your blood pressure finally hits this and your waist circumference finally hits that and your glucose level hits that, that’s when the trouble begins.*”
- Imagine a world in which once your liver fat hits 2% and we’re paying attention
  - Because even though at 5% you now have this disease, that doesn’t mean that 2% of your hepatocytes accumulating fat is necessarily a good thing

***In other words, you could really start to take an organ centric view of metabolic health, and if you could really only look at one organ, Peter thinks you’ve got to start with the liver***

- Peter points out his bias as a hepatophile
- But the liver is really the mothership

> “*[The liver] It’s got to be the canary in the coal mine for when things are going wrong*.”‒ Peter Attia

**Should we be doing scans on people?**

- To Peter, [FibroScan](https://www.echosens.com/en-us/) sounds like a totally reasonable idea
  - It’s relatively low cost
  - If it gives us any insight even before you trigger that threshold, that strikes him as far more useful than looking at something as anodyne as hemoglobin A1C, which is so prone to error

**What fraction of the people listening to us today in this podcast might have MAFLD or AFLD without their knowledge?**

- Assuming they’re representative of the population in the United States

***25-35% are pretty conservative projections***

- One of Julia’s mentors, a surgeon who did a lot in terms of metabolism outside of the liver said, “*I wish we could get all the CT data from airports (granted, it’s not the best imaging data). So that we could really get some estimates of prevalence because that’s a good way to look at everybody that’s coming through a population.*”

***We don’t recommend screening from a fatty liver disease or steatotic liver disease perspective yet***

- But even if your audience is relatively healthy, it really underestimates the capacity of having a test
  - One of the reasons that Julia agreed with Peter’s prior riff on how unsophisticated some of our current ways of thinking about things are, understandably given some of the costs associated with it
  - How much that underserves a lot of very proactive patients who can handle a lot of health information and make and implement meaningful change
- Oftentimes doctors or advisors will check out and say, “*We can’t do anything about this, therefore there’s no relevance in checking*.”
- Julia argues, “*There is a lot of relevance to the majority of our patients in terms of understanding that they’re at risk for something and how to implement longitudinal changes, not just to themselves, but families eat similarly. Families exercise similarly.*”
  - When we counsel an individual, [it can help people in their family]
- Julia has many, many patients who do not fit the standard phenotype
  - This is why she likes to see patients in succession, because it really does change the way that you frame quantitative and qualitative risk across diverse populations

***Even if someone listening doesn’t have it, Julia would say 100% of them know someone in either their family or their close circle who does***

- As soon as she gives a talk like this, everybody starts to identify themselves as having it but not knowing what to do about it

## The importance of screening for and considering rare conditions alongside common metabolic diseases associated with fatty liver accumulation [1:42:45]

**How does one go about doing some of the other dotting of I’s and crossing of T’s?**

- [Tom Dayspring](https://peterattiamd.com/tomdayspring6/), a lipidologist that works in Peter’s practice, mentioned some of these liposomal acid lipase, loss of function, basically sterile accumulation disorders that can masquerade very similarly histologically and biochemically, but of course it’s a totally different disease
- Julia already alluded to several of these conditions

*At what point should one be looking at the “zebras” when they see all the hoof prints on the ground, given the prevalence of up to a third of the population actually just has metabolic disease associated with fatty liver accumulation?*

- If you’re a front-line clinician, anyone, not just a specialist from Julia’s tiny corner
  - Either gastroenterologist or a hepatologist
  - If you are a primary care, an intensivist, endocrinologist, cardiologist, and you’re seeing this
- This is the point of having colleagues, expert referrals, and people to reach out to, when you’re starting to think about rare causes
- The most common reason people reach out is **when do we need a biopsy?**
- It’s very, very obvious that people look at metabolic risk, they do their [viral hepatitis screens](https://www.ncbi.nlm.nih.gov/books/NBK92029/), and we don’t expect them to do [alpha-1 antitrypsin phenotype testing](https://medlineplus.gov/lab-tests/alpha-1-antitrypsin-testing/) initially

*When someone is an outlier*

- They’re lean, they have elevated ALT, they’ve got a stiffness that puts them in moderate range halfway to cirrhosis by the age of 35, we need to involve a specialist
- The reasons is with some of the genetic testing for families, you’re going to want the expertise that comes with a center where they see some of the “zebras”
  - Whether it’s genome sequencing versus genotypes versus targeted genomics versus some of the molecular diagnostics done with histology
- Other people will identify “zebras”, but most often, when this is all you do and your 6th sense is trained on the reasons to think about outliers
  - She is humbled and surprised by people that come with diagnostics, but often they come to it in an indirect way

***All of that is to say, many of the rare “zebras” that she pursues genomic testing on, if you’re identifying through a lipid profile and liver-based screening that they’re already an outlier, that’s the reason to refer***

## Practical strategies for managing MAFLD [1:45:30]

- Peter brings it back to the standard case
  - Which for the hepatologist is very common and not the typical person they see
    - They’re not seeing somebody with MAFLD minus cirrhosis, who doesn’t have any other diagnosis unless it progresses and becomes problematic
- Given that that is an enormous volume of people, Peter wants to spend some time talking about
  - What are the most important things to be doing besides the obvious? (And we’ll discuss the obvious)
  - Are there any treatments on the horizon, even as it progresses to steatohepatitis and before it gets to cirrhosis?
  - Are there any deficiencies in a person’s diet that can play a role in this?
  - Are there any other predisposing factors that people need to be aware of?

**The traditional therapy for this is weightloss**

- Peter explains, “*Weight loss is the most important tool that’s going to improve metabolic health*.”
- Maybe at the population level, that’s true, but we should also talk about exercise, sleep and things like that

***Things that improve metabolic health should improve MAFLD***

*Would you put a finer point on that?*

- Julia agrees that Peter named the building blocks of good health: exercise, sleep, and nutrition
- But these are the ones that are least studied

- Julia explains, “*We’re using histology as a surrogate marker for outcomes that are sometimes 5-50 years down the road.*”
- A lot of the evidence is based on histology where the natural history studies are yet to be born out
  - So with a lot of humility towards the cardiovascular endpoints

> “*The average person you’re seeing with MASLD is much more at risk for cardiovascular-related outcomes and malignancy-related outcomes from their metabolic health than they are for liver-related risks*. ”‒ Julia Wattacheril

**About 30% of Julia’s patients self-refer**

- They read their own report and convince their doctor to refer to her
- They’re not necessarily super high risk
- These are exactly the same types of patients that Peter is talking about, they are proactive

**Julia doesn’t want to dismiss patient-centered lifestyle intervention**

- Micronutrient, macronutrient, those are things that we usually involve in specific certain circumstances
- For example, post-bypass surgery for some individuals, [short gut syndrome](https://en.wikipedia.org/wiki/Short_bowel_syndrome), that’s [choline deficiencies](https://en.wikipedia.org/wiki/Choline#Deficiency)
- When we think about precision exercise, precision nutrition formulation for an individual, again, context of disease, context of life
- If a person already has relatively moderate amounts of low glycemic intake food…

***A lot of patients hear fatty liver disease and assume this is from eating too much fat, when instead, it’s a lot of exogenous carbohydrates***

- Julia advises patients to switch to **slow burn carbohydrates** or complex carbohydrates
- A lot of patients want very, very detailed information (as they should), but a lot of that comes about in meetings with someone who is of the nutrition sciences
- Part of that is we need to know their day-to-day intake and make it culturally appropriate
  - If we tell you to take something in that’s completely outside the bounds of what you normally intake, it’s not really easily implementable for everyone’s life
- Julia spends her time as a doctor talking about **exercise**, doing an exercise/ physical activity assessment
- Julia explains, “*This may sound gendered, but a lot of my female patients, especially with lean NAFLD, are low in the muscle component. Muscles [are] typically quite hard to build after the age of 60 so we spend a lot of time talking about increasing resistance work, combination activity of a lot of single moms who are working very hard and don’t necessarily have that much time to dedicate to exercise. So we talk about combination aerobic and resistance activity.*”
  - This is part of healthy aging
- She sees a lot of people become more [insulin resistant](https://en.wikipedia.org/wiki/Insulin_resistance) with aging as they become more [sarcopenic](https://en.wikipedia.org/wiki/Sarcopenia)
  - Even lean individuals
- She figures out what a patient’s baseline activity is
- For the sedentary person, it’s a walking prescription to increase their aerobic activity and build habits
  - That’s where the behavior motivation aspect of change is very critical
- She outsources the nutrition component to a registered dietician with detailed information

**The impact of coffee**

- Some [studies](https://bmcpublichealth.biomedcentral.com/articles/10.1186/s12889-021-10991-7) have shown coffee to be beneficial for multiple liver diseases: fatty liver disease, hepatitis C, fibrosis, even HCC
  - Black coffee or coffee with limited sugar and milk components added
- Julia is not recommending it as a prescription, but up to 3 cups of coffee has been shown in multiple studies in terms of antifibrotic effects and good metabolic effects
  - It’s now part of the European guidelines and has made it into the [American guidelines](https://journals.lww.com/hep/Fulltext/2023/05000/AASLD_Practice_Guidance_on_the_clinical_assessment.31.aspx)

*Do we have a sense of what component of the coffee it is?*

- Peter points out that if it’s caffeine, that has one set of implications
- But if it’s polyphenols or things like that, then it also has a huge implication as far as the form of the coffee
  - A highly filtered drip coffee versus a French press, you’re going to have totally different amounts of those polyphenols making their way in
- Everybody who loves coffee (Peter included) is asking the question, “*What do we know about the constitutive components responsible for that benefit and how should that impact our coffee drinking choices?*”

***The short answer is not enough***

- In terms of the granularity of nutrition detail, huge opportunity
- In terms of metabolomics, caffeine is a signal, but when given caffeine in and of itself, it does not mimic some of the effects that we observe
  - So that’s not one thing
- Like many things that we talk about with nutrition, extracting a nutrient versus taking it in its natural form are 2 different components
- The methodology of coffee extraction and the caffeine component, the instances of tea (a lot of cultures drink much more tea than coffee, including green tea) ‒ ***these are all areas for further exploration***
- The times Peter has [looked into this](https://peterattiamd.com/coffee-and-neurodegenerative-disease/), he’s come to the conclusion that the more of the coffee bean you are ingesting, the better
- And so, when in doubt, he opts for a French press because it’s the least filtered and you’re getting the most of everything

## The impact of fructose consumption on liver health and the challenges of disentangling its effects from other factors like obesity and insulin resistance [1:52:45]

**Do we believe that fructose is more injurious to the liver than glucose?**

- Peter points out that these are 2 very similar molecules that have very different paths of metabolism
- For patients with what we historically called NAFLD, he has subscribed to the approach of **eliminating all liquid sources of fructose**
  - If he’s trying to get patients to change their diet he counsels them to keep eating berries and fruit, but get rid of the smoothies and any sugar sweetened beverages
    - Not just because of their caloric content, but because that huge bolus of fructose is hitting the gut and heading through the portal circulation to the liver

**Julia explains that most of the mechanism for any type of liver disruption comes through an insulin resistance pathway, so you would have to tease apart the presence/ absence of obesity or insulin resistance as the big driver of what you’re observing in the liver**

- There are only a couple of studies that have done that, and they find no net difference
- There are a couple of studies that have looked at liver exposure to fructose without parsing those out and they report evidence of significant liver injury (inflammation and/or scar tissue)
  - These are population-level data
- Peter agrees that his reading of the literature is that it has been very difficult to disentangle the relationship between the macronutrient and weight loss (for example)
  - In other words, if you look at studies that have removed all fructose from the diet and have actually demonstrated a remarkable amelioration of what was called NAFLD, the patients still lost weight
  - And so even though these were meant to be studies that were eucaloric, just taking fructose out of a person’s diet presumably led to less spontaneous consumption
    - There are lots of great mechanisms for why a high fructose diet leads to overeating
- While weight loss may be a great outcome, we don’t know if that’s sustainable in the long run, and it doesn’t answer the mechanistic question

**Peter’s takeaway:** ***Julia does not counsel people to eliminate fructose from their diet other than that being part of an overall general dietary pattern of advising people to eat less and move to lower glycemic foods***

- This will result in a diet that is lower in all forms of fructose that come from refined sources

***Julia explains that specific recommendations have got to be dialed in for the individual and what they have the capacity for at that time***

- In the range of patient’s that she sees, some people can hire a personal chef and a personal trainer, but he vast majority cannot
- The effort to eliminate a specific component causes so much distress to the average person
  - That’s a lot of mental work
  - It’s much easier and implementable to say, “*Avoid processed foods.*”
- The best way to study this would be in areas where the government or some regulatory body has excluded some of the high fructose corn syrup and processed foods
  - There are communities that do that
- This type of study is completely doable from a mouse model perspective
- But what we know about fatty liver disease ([MASLD, MAFLD](https://en.wikipedia.org/wiki/Metabolic_dysfunction%E2%80%93associated_steatotic_liver_disease)) is that any way that you study it, the translation from preclinical to clinical does not always borne out with the biology, given the beauty of the liver in its homeostasis
  - Let alone from phase I to phase III

## The potential of GLP-1 agonists for the treatment of MASLD [1:57:45]

- The 2 most popular GLP-1 agonists out there today are [semaglutide](https://en.wikipedia.org/wiki/Semaglutide) and [tirzepatide](https://en.wikipedia.org/wiki/Tirzepatide)
- Obviously they have a profound impact on weight loss
- They generally tend to have a very favorable impact on insulin sensitivity as well
- It seems to Peter, “*One could it make the case today that the most effective drug we have for treating MASLD (formerly NAFLD and NASH) are these drugs*.”

**What is your view of that and what have you seen clinically?**

- Julia’s view is based on published evidence, what we have data for, and what we have approvals for
- If you have someone who is a known diabetic, it is low hanging fruit to reach for one of these agents when there is weight to be lost
  - A certain percentage of patients can’t afford to lose weight, especially some of the muscle loss effects that are also associated with these drugs
- When she has an average person whose BMI is 28-40, they have stage 2 estimations from noninvasive tests, they’ve maximized their lifestyle modifications
  - If they’re working with endocrinologists, most of them with diabetes have already had the discussion of bringing in a GLP-1 receptor agonist
    - If not, she strongly moves forward that conversation
- Her conversation about GLP-1 agonists includes the discussion, “*At some point, you will likely have to come off of this medicine. We need to talk about how many people regain the weight afterwards and what’s the longitudinal benefit for a longitudinal disease if two years down the road you regain the weight and the injury pattern resumes.*”
- She has very overt conversations when patients are in the stage 3 range or early cirrhosis about bariatric surgery, metabolic and weight loss surgery, and the involvement of some of these weight loss drugs
  - Also with a clear open discussion about what happens when you come off of the drugs
  - And what’s the longitudinal weight regain post-bariatric surgery from some of the surgical interventions
- She discussed it with patients who are comorbid overweight, comorbid diabetes
- It’s been tested in multiple phase 2 studies and [data](https://pubmed.ncbi.nlm.nih.gov/38253482/) was released recently about its effects on the liver

> “*The effects on the liver are difficult to tease out in terms of how much of it is due to overall weight loss versus a direct liver-related effect*.”‒ Julia Wattacheril

## How the four stages of liver disease have evolved [2:00:30]

**The staging of liver disease has changed**

- Peter points that that when we used to talk about NAFLD and NASH, he assumes those were largely biopsy differentiated terms
  - NAFLD focused on fat accumulation
  - NASH focused on the inflammation that was present
  - Cirrhosis was the end stage of fibrosis
- Today Julia is talking about it in terms of staging

*Does that allow us to move past biopsies and rely on some of the elastography and ways to look at both fat and fibrosis scores? And if so, how do you delineate the staging today?*

- Most hepatologists are using noninvasive tests (discussed earlier), not a biopsy
- A biopsy will be used when there is some indication of an autoimmune component
  - For example a woman with a positive [ANA, smooth muscle antibodies](https://en.wikipedia.org/wiki/Hepatitis#Autoimmune)
  - Treatments are very different
  - About 18-20% of people with MASLD will be positive for one of these biomarkers
- A biopsy is used to exclude other types of diseases, used for clinical trial purposes, and oftentimes used in diagnostic testing prior to an elective procedure where you need to know about cirrhosis before the surgery
  - Such as abdominal surgery or cardiothoracic surgery
- Julia explains, “*Because of the explosion of non-invasive tests being a recipient of all the confounders, we also help use it to delineate when there needs to be a tiebreaker. You get one non-invasive test that suggests very advanced fibrosis. You get an MRI that suggests with elastography that suggests something very different where there’s such discordance that you need something to adjudicate the in-between area.*”

**What are the stages of MASLD?**

- Fibrosis scores makes up those stages
- There are different scoring systems that are based on different types of diseases

*How liver diseases are defined*

- **Steatosis** development in MASLD is >5% fat
- When you start to move into fat plus inflammation, that’s the definition of **NASH**
  - Inflammatory cells infiltrating the liver plus what is called hepatocyte ballooning (that’s a stressed-out hepatocyte)
  - NASH does not necessarily mean there is scar tissue
    - Oftentimes you will see some scar tissue, but the fibrosis component is different
- **Stage 1 scarring** is early stage scarring
  - Seen in an adult around their vein
  - We call it chicken wire because that’s what it looks like under the microscope
- Depending on the distribution and presence of scar tissue, we stage it: stage 1, stage 2, stage 3, stage 4
- **Stage 3** describes the way that the liver architecture looks under the microscope, we start to see connections between that portal based area and some of the central vein areas
  - You’ll hear people say **expansion bridges**
- **Stage 4 scarring** is what we consider **cirrhosis**, and that’s where you have a lot of architectural disruption, nodules forming in the liver
  - It looks lumpy, bumpy: sometimes on an ultrasound, sometimes on an MRI

**The thinking around cirrhosis and reversibility has changed in the field**

- A lot of this was learned after the potent hepatitis C cures
- We used to teach that the fat scar tissue was very fixed and irreversible (any form of cirrhosis)
- Now we’ve subdivided cirrhosis into different stages

> “*Early cirrhosis or stage 4 scarring of the liver, we’ve started to see evidence that even that is reversible*.”‒ Julia Wattacheril

- The **time course** between each of these stages for something like MASLD is 5-7 years
  - That’s largely based on European ancestry information

***That’s why it is such a hopeful disease because there’s tons of time to intervene before there’s progression to the next stage***

**Peter’s takeaway:** those are 2 very uplifting pieces of information

- 1 – You’ve got 5-7 years between each of those stages
- 2 – At least a subset of cirrhosis might be reversible
- That stands in the face of the traditional teaching that we had, which was stages 1, 2, 3, reversible, while stage 4 is not

## Increased cancer and heart disease risk associated with early stage MAFLD [2:05:15]

- If Peter heard correctly, for the early stages of MAFLD, you should care more based on the risk to your heart and risk to cancer than immediate risk to liver disease
  - Because you’re 15-20 years away from liver failure
  - But you could be much closer to cancer or heart disease
- A lot of patients pick up impressions based on how clinicians deliver the news
- There’s been a jadeness in terms of tackling diabetes, obesity, and any type of metabolic diseases ‒ as if the general population will not take that information and act on it
- Julia thinks we have a lot to do in terms of how we counsel patients and whether or not they feel empowered by the information we’re giving them
- A **main outcome in clinical trials** for the average person, and patients that are in stage 1, stage 2, and stage 3 is [major adverse cardiac events (MACE)](https://en.wikipedia.org/wiki/Major_adverse_cardiovascular_events)
  - That’s a longitudinal risk that we need to think about
- When Julia sees a patient, she is trying to figure out what the leading risk factor is for mortality and also quality of life implications
  - Is it something liver-based or is it something outside of the liver

**Risks associated with early stage 1 disease**

- This is not even stage 1 fibrosis
- She talks a lot about the risk of eventual development of diabetes
- To a patient with an elevated cap score on a FibroScan, she will say, “*Here’s your fat score, here’s your scar score. Your scar score is normal. Your fat score is exceedingly high. It’s very modifiable. [In] 6 weeks to 6 months it can be in the normal range. Unchanged, you will most likely develop diabetes in X number of years.*” (depending on what their insulin risk profile will be)
  - That’s not usually received in a scary way
  - Patients realize they can change their diabetes related risk in a meaningful way a nd see an outcome in a year or two on a scan

> “*Empowering patients with information and then also working in partnership with endocrinology and cardiology in terms of what their cardiovascular risk might look like and how to modify it, and how to make it sustainable.*”‒ Julia Wattacheril

***Sustainability is the biggest thing we have to deal with when it comes to liver disease and scar***

- If it is 5-7 years on average to develop stages to progress, that’s a lot of sustainability
- And a lot of the behavior changes that we see are related to circumstances
- In early stage disease, she’s concerned with how to build resilience not just in terms of their metabolism and their metabolic flexibility, but what their coping skills are, what they reach for in different instances

**How would you quantify the increased risk of cancer?**

- The liver related cancer is [hepatocellular carcinoma](https://en.wikipedia.org/wiki/Hepatocellular_carcinoma), and we generally think that that occurs with cirrhosis
  - Origin is in the liver
  - Julia’s not speaking about metastatic disease that lands in the liver.

***For most liver diseases, around 3-5% per year is what we quantify risk***

- The highest risk is [hereditary hemochromatosis](https://en.wikipedia.org/wiki/Hereditary_haemochromatosis)
- Next, combination [hepatitis C](https://en.wikipedia.org/wiki/Hepatitis_C) and alcohol
  - This was mostly quantified before hepatitis C cures existed
- Then hepatitis C, alcohol, and MASLD
- With [hepatitis B](https://en.wikipedia.org/wiki/Hepatitis_B), your escape hatch phenomenon alerts always come on
- We were getting case reports of people with stage 3 scar tissue from fatty liver disease, developing really bad cancers
- When liver cancers are slow growing, they’re quiet, they’re silent, you have to look ahead of time
  - That is a population

***People with cirrhosis are a population that we recommend looking for cancers before anyone is symptomatic: every six months we recommend screening***

- Whether or not that needs to be done at an earlier stage in fatty liver disease world, (the MASLD world) is to be determined
- For MASLD, there’s some early evidence around the metabolic reprogramming that’s going on in the liver, the insulinization of the liver, that the oncologic potential is changing
  - Whether or not that person needs to be screened at an earlier stage of disease is a current area of interest in the field

**Peter’s takeaway:** ***there is a 3-5% per year increase in the risk of hepatocellular carcinoma once you have stage 4 disease***

- Once you’re at **stage 4**, you’ve got a lot of problems
  - Your risk of [HCC](https://en.wikipedia.org/wiki/Hepatocellular_carcinoma) is one of them
  - At this point everything is a “four alarm fire”
- But given the prevalence of MAFLD (NAFLD, NASH, whatever you want to call it), along that progression, it would be really helpful to know, “I*s your risk of hepatocellular carcinoma 2X the normal, 3X the normal, 5X the normal?*”
  - Admittedly, it’s a low baseline even if you’re at stage 1 or stage 2
  - It could be a while to answer those questions because of the sample sizes needed

***Julia points out that at stage 4 disease is an opportunity to have a discussion with a patient about the use of pharmacologic agents (or surgical agents) to massively decrease their risk of fat and scar tissue in the liver as well as decrease their potential cancer risk***

- Julia has a biased point of view because of her specialty
- A lot of patients come to her with a new diagnoses of **cirrhosis** and they’re in their 30s, 40s
  - ***This disease starts so young***
- You can live, you can have relatively good metabolic health for quite some time before your liver falls off the curve from a dysfunction standpoint
- Even with cirrhosis, you need to undergo some appropriate screening, but the timeline for that: you’re not going to need a transplant in 2 years
  - Once you involve portal hypertension, it’s a different story

***A good percentage of listeners might have stage 3 scar and not know it and at the age of 40 might be told that they have pretty early onset stage 4 disease***

- But that’s not like stage 4 cancer
- There are opportunities to do a lot of good in that population

## Emerging drugs and therapies for addressing fat accumulation and fibrosis related to MAFLD [2:12:15]

- Currently used drugs are drugs used to treat other things
  - The diabetes drug [metformin](https://en.wikipedia.org/wiki/Metformin) will very likely improve insulin sensitivity
  - [GLP-1 agonists](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist) target both insulin sensitivity and appetite regulation, which then feeds back

**Are there any other drugs out there today or in what I would call kind of late stage 3 that are specifically targeting fat accumulation in the liver due to metabolic consequence or even due to alcohol?**

- A phase 3 clinical trial with [Resmetirom](https://pubmed.ncbi.nlm.nih.gov/37313239/) was just [published](https://pubmed.ncbi.nlm.nih.gov/38324483/) in the *New England Journal of Medicine*
  - [Resmetirom was approved after this podcast was recorded]
- What we have learned about the liver:
  - There are a lot of biological processes that are being regulated
  - There are a lot of exogenous inputs
  - There is lots of potential for therapeutics, but that also means a lot of potential for error because of the biology of the disease
- Resmetirom is a thyroid hormone receptor agonist that has been studied and shows very good promise in terms of late stage efficacy (phase 3 efficacy) and safety in a population
  - A couple of limitations in terms of the population: it’s 90% European ancestry or self-described as white
    - The disease prevalence in the US and around the world is very diverse
    - How it will play out in a different population is one thing to watch
  - A hormone signal has some biological plausibility that might have an actionable effect in the liver
  - That [study](https://pubmed.ncbi.nlm.nih.gov/38324483/) looked at scar tissue (fibrosis stage of 1, 2 or 3)
- Tons of clinical trials have been done at various stages including what we call decompensated
  - That’s when somebody with cirrhosis falls off the curve, all of a sudden their liver stops working
- When you think about promising agents independent of weight loss, Resmetirom is one
- There are some that act on multiple types of pathways like [FGFs](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10003526/), [FXR](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10109454) (agonists)
- When you look at the pleiotropic of expression of where the injury can occur and keep in mind that the liver talks to subcutaneous adipose and muscle tissue, that’s where some of the [PPAR agonists](https://www.journal-of-hepatology.eu/article/S0168-8278(23)04980-2/fulltext) come from
  - The [PIVENS trial](https://pubmed.ncbi.nlm.nih.gov/20427778/) studied vitamin E
- There are different agents that have been studied depending on the stage of disease
- What’s messy about this work is that oftentimes things that show biological activity from a histology perspective don’t necessarily result in some of our endpoints that we developed with the FDA
  - **Endpoints**: reversal of NASH and no progression of fibrosis
  - Whether or not those histologic endpoints are representative of the disease at large within the liver and then also the cardiovascular and glycemic effects are what makes doing these trials so hard
    - You’re looking at multiple variables, not just liver-related, but also endocrine- and cardiac-related

**If a patient asked you, “*****Should I be taking choline supplements, vitamin E supplements based on the histologic changes that didn’t quite meet clinical endpoints?*****” do you see a downside in doing that?**

- For choline deficiencies specifically, those are sometimes measurable by assays
- Julia sees them a lot in people post bypass surgery, the malnutrition form of steatotic liver disease

***She is not terribly aware of any downsides***

- But she’s cautious when she says this because every day she sees a patient with some sort of new formulation that has a hyper potent level of what they think they’re getting

***When it comes to supplementation, quantifying exactly what’s in it [is important]***

- From a [vitamin E](https://en.wikipedia.org/wiki/Vitamin_E) perspective, there are some downsides
  - All-comers, cardiovascular longitudinal risk, and then prostate cancer
    - These are things to think about in terms of whether or not she would choose to use it or at least have a discussion with a patient
- Vitamin E is a low hanging fruit from a steatotic perspective, but we do have additional discussions with people that have diabetes
  - It’s generally okay now
- Studies have been done on people with cirrhosis

***There have been some studies that indicated increased in all-cause mortality depending on the dose of vitamin E and what it’s being used for***

**What’s in the pipeline as far as any of the mitochondrial uncoupling agents?**

- If we go back to the [de novo lipogenesis pathways](https://en.wikipedia.org/wiki/De_novo_synthesis#Fatty-acid_(de_novo_lipogenesis)) where there’s failures in [beta oxidation](https://en.wikipedia.org/wiki/Beta_oxidation), where there’s overwhelm ‒ there’s a putative mechanism there
- Julia sees the most potential in interventions like siRNA-based agents in combination based therapies
  - That’s because for approval, you’re going to have to get at a component of fibrosis
  - And the most potent aspect to deal with both steatosis and fibrosis right now are some of the blockbuster weight loss drugs
    - In order to have a liver specific directed therapy for something like a mitochondrial-based pediology
- We typically think of microsteatosis and development in that way rather than the macrosteatosis
  - Macrosteatosis being the large flat droplets that we see with metabolic-associated steatotic liver disease

***Julia sees them used potentially, and is not conflicted in terms of speaking about this in forms of combination therapy***

- There are so many different agents being talked about that are not yet public from a preclinical perspective
- She could envision that as a potential putative agent from a steatotic based application, but in combination

## Peter’s major takeaways [2:18:45]

- We need to be very thoughtful in how we make the diagnosis here
- We need to be very thorough in evaluating the clinical history
- The overlap could be much more significant than previously realized between metabolic dysfunction and alcohol use
- It doesn’t take a whole lot of alcohol consumption to impact these steatohepatitic pathways
- Many patients are probably walking around with some combination of what was formerly AFLD and NAFLD
- The near term cardiometabolic risk and the near term oncology risk might even outweigh the near term hepatology risk in the early stages of that disease
  - There’s still a great unknown in terms of quantifying some of those risks
- Peter was actually very taken aback by the statement Julia made, which was in the stage 1, 2 and 3 clinical trials, you’re using [MACE (major adverse cardiac events)](https://en.wikipedia.org/wiki/Major_adverse_cardiovascular_events) as the clinical outcome
  - That speaks to the proximity of cardiovascular disease as a bad thing, as the thing that you ought to care about
  - If clinical trials are looking at MACE as an outcome, that tells you how tightly linked these conditions are with cardiovascular disease
- Julia explains, “*It’s not the primary endpoint. We’re still looking at liver-based endpoints. But when we look at longitudinal clinical outcomes data where post-approval surveillance will be and clinically significant outcomes for the FDA for certain cardiovascular outcomes are a huge one.*”
- Peter knows there are hundreds of thousands of people listening to us right now who are afflicted by this, some of whom know it, but many of whom don’t
- The hope is that they can get the proper diagnosis and that that diagnosis perhaps by itself serves as the motivation to go after this and address it

> “*The other takeaway here, [MAFLD] is imminently treatable, imminently reversible, and therefore there’s no reason to not know that this is something going on inside your body.*”‒ Peter Attia

§

## Selected Links / Related Material

**Biography of Thomas Starzl**: [The Puzzle People: Memoirs Of A Transplant Surgeon by Thomas Starzl](https://www.amazon.com/Puzzle-People-Memoirs-Transplant-Surgeon/dp/082293714X/ref=sr_1_1?crid=1J4W0MF5G8I3J&dib=eyJ2IjoiMSJ9.ERrILh_WCCN30GowrpYRj6z5y01NpqWejbWo3f0IANLGjHj071QN20LucGBJIEps.hhttwpyuBaXV3bDbc8yKYrQbTGdByAdrmAuiXJTW808&dib_tag=se&keywords=biography+of+Thomas+Starzl&qid=1712683566&sprefix=biography+of+thomas+starzl%2Caps%2C79&sr=8-1) (1992) | [15:45]

**Newsletter about the greater effects of alcohol on women**: [Why do women have lower alcohol tolerance than men?](https://peterattiamd.com/why-do-women-have-lower-alcohol-tolerance-than-men/) | PeterAttiaMD.com (P Attia 2022) [47:15]

**World Health Organization statement on carcinogenic effects of alcohol**: [Joint statement by WHO/Europe and IARC to the European Parliament – raising awareness of the link between alcohol and cancer](https://www.who.int/europe/news/item/06-11-2023-joint-statement-by-who-europe-and-iarc-to-the-european-parliament---raising-awareness-of-the-link-between-alcohol-and-cancer) | WHO (H Kluge, E Weiderpass 2023) | [48:30]

**Newsletter addressing possible benefits of low alcohol consumption**: [Is low-to-moderate alcohol consumption beneficial for longevity?](https://peterattiamd.com/low-to-moderate-alcohol-consumption-and-longevity/) | PeterAttiaMD.com (A Misc, K Birkenbach, P Attia 2024) | [49:15]

**Coffee reduces the risk of liver disease**: [All coffee types decrease the risk of adverse clinical outcomes in chronic liver disease: a UK Biobank study](https://bmcpublichealth.biomedcentral.com/articles/10.1186/s12889-021-10991-7) | *BMJ* (O Kennedy et al 2021) | [1:50:30]

**American guidelines for MASLD**: [AASLD Practice Guidance on the clinical assessment and management of nonalcoholic fatty liver disease](https://journals.lww.com/hep/Fulltext/2023/05000/AASLD_Practice_Guidance_on_the_clinical_assessment.31.aspx) | *Hepatology* (M Rinella et al 2023) | [1:50:45]

**Newsletter on the health benefits of coffee**: [Non-caffeine components of coffee and their effects on neurodegenerative diseases](https://peterattiamd.com/coffee-and-neurodegenerative-disease/) | PeterAttiaMD.com (A Misic, K Birkenbach K Niotis, P Attia 2023) [1:52:30]

**Effects of GLP-1 agonists on the liver**: [Glucagon-like peptide-1 receptor agonists and risk of major adverse liver outcomes in patients with chronic liver disease and type 2 diabetes](https://pubmed.ncbi.nlm.nih.gov/38253482/) | *Gut* (A Wester et al 2024) | [2:00:30]

**Phase 3 clinical trial of Resmetirom for NASH**: [A Phase 3, Randomized, Controlled Trial of Resmetirom in NASH with Liver Fibrosis](https://pubmed.ncbi.nlm.nih.gov/38324483/) | *NEJM* (S Harrison et al 2024) | [2:12:00]

**PIVENS trial of vitamin E**: [Pioglitazone, vitamin E, or placebo for nonalcoholic steatohepatitis](https://pubmed.ncbi.nlm.nih.gov/20427778/) | *NEJM* (A Sanyal et al 2010) | [2:15:30]

§

## People Mentioned

- [Thomas Starzl](https://en.wikipedia.org/wiki/Thomas_Starzl) (1926-2017, American physician and researcher who pioneered the first liver transplant) [15:45]
- [William Lee](https://profiles.utsouthwestern.edu/profile/14217/william-lee.html) (Professor of Internal Medicine at UT Southwestern Medical Center and expert in acute liver failure) [18:15]
- [Gerald (Jerry) Reaven](https://med.stanford.edu/news/all-news/2018/02/gerald-reaven-stanford-scientist-who-coined-syndrome-x-dies-at-89.html) (1929-2018, endocrinologist and professor of medicine at Stanford, first to characterize metabolic syndrome) [1:39:00]
- [Thomas Dayspring](https://peterattiamd.com/tomdayspring6/) (Internal medicine physician and clinical lipidologist) [1:43:00]

§

![](https://peterattiamd.com/wp-content/uploads/2024/05/bio-juliawattacheril.png)

##### Julia Wattacheril, M.D., M.P.H.

Julia Wattacheril earned her medical degree and completed her residency at Baylor College of Medicine. She completed a fellowship in gastroenterology at Vanderbilt University, where she also earned a Masters in Public Health. She completed a second fellowship in transplant hepatology at NewYork-Presbyterian Hospital/Columbia University Medical Center.

Dr. Wattacheril is an associate professor of medicine, physician scientist, and director of the Metabolic Dysfunction Associated Steatotic Liver Disease (MASLD) program at Columbia University Irving Medical Center. Her clinical and translational work spans the multidisciplinary care of MASLD patients at all stages of their disease to the investigation of rare genetic variants influencing the development and progression of MASLD before and after liver transplantation. She currently leads an interdisciplinary research group using semi-automated techniques to identify at-risk and protected phenotypes within the electronic health record (EHR) for multi-omic analysis. Of particular interest for clinical outcomes discovered through EHR phenotyping include rapid progression to advanced liver disease, need for transplantation, and hepatocellular carcinoma. Her current projects test hypotheses at scale across populations. She has a particular commitment to develop and translate science and medicine not just across disciplines but to those most affected and often least included in the conversation. [[Columbia](https://www.giving.cuimc.columbia.edu/profile/julia-j-wattacheril-md)] Dr. Wattacheril’s views expressed in this conversation reflect her own, not those of her institution.