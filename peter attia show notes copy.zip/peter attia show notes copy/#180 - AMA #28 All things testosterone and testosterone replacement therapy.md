# #180 – AMA #28: All things testosterone and testosterone replacement therapy

**Source:** [https://peterattiamd.com/ama28/](https://peterattiamd.com/ama28/)

---

In this “Ask Me Anything” (AMA) episode, Peter and Bob discuss all things related to testosterone: what happens when testosterone levels are low, and the potential benefits and risks of testosterone replacement therapy (TRT). They explain the physiology of testosterone, how it works, and how its level changes over the course of a person’s life. They have a detailed discussion about existing literature, which reveals vast potential structural, functional, and metabolic benefits of testosterone replacement therapy. They also take a very close look at potential risks of this therapy, with a focus on the controversial effects on cardiovascular disease and prostate cancer.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #28 show notes page](https://peterattiamd.com/ama28/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- A primer on the hormone testosterone and how it influences gene expression [3:30];
- How the body naturally regulates testosterone levels [11:30];
- The defining threshold for “low testosterone,” how low T impacts men, and why free testosterone is the most important metric [16:15];
- When it makes sense to treat low testosterone [26:00];
- The structural and metabolic benefits of testosterone replacement therapy [29:15];
- Body composition changes with TRT [45:30];
- Changes in bone mineral density with TRT [48:15];
- The metabolic impact of TRT: glucose, insulin, triglycerides, and more [52:30];
- A study investigating testosterone replacement therapy for prevention or reversal of type 2 diabetes [59:30];
- The impact of TRT on metabolic parameters and body composition—A study comparing results from continuous vs. interrupted treatment [1:07:15];
- The controversy over TRT and cardiovascular disease [1:21:45];
- Two flawed studies that shaped perceptions of risks associated with TRT [1:44:15];
- The controversy over TRT and prostate cancer [1:56:45];
- Other potential risks with testosterone replacement therapy [2:02:15]; and
- More

§

The Peter Attia Drive

All things testosterone and testosterone replacement therapy

§

## Show Notes

§

## A primer on the hormone testosterone and how it influences gene expression [3:30]

**Overview**:

- Testosterone is a steroid hormone
- It’s derived from the cholesterol family and it is synthesized in a number of steps
- What’s really important is that it *exerts its effect through binding to an androgen receptor*
- Because it is a hydrophobic molecule, it basically makes its way into the cell easily—meaning it doesn’t require a channel or a receptor on the cell membrane to make its way inside
- Cholesterol can’t make its way through the bloodstream the way glucose can or the way electrolytes can; for example, sodium & potassium (because electrolytes are soluble in water, they’re therefore soluble in the bloodstream (plasma), and they don’t need a chaperone or carrier proteins)
- But cholesterol does need carrier proteins (lipoproteins)
- Similarly, testosterone needs to be bound primarily to carrier proteins

*Two dominant carrier proteins for testosterone*:

- 1) One is called sex hormone-binding globulin or SHBG
- 2) The other is albumin
- SHBG is responsible for about two-thirds of the carrying capacity, whereas albumin is about one-third
- what’s important is knowing that it’s **only the unbound portion of testosterone that is able to actually exert the biological influence**
- “We pay very special attention to how much testosterone is “free,” and free is defined as the testosterone that is neither bound to SHBG or albumin”
- whereas there’s another term that many people who have had a blood test may notice, something called *bioavailable testosterone*
  - that’s the portion that is unbound to SHBG, but remains bound to albumin or is free
- In other words, free testosterone, which is a tiny amount, it’s typically 1% to 3% of total testosterone, is that which is completely unbound
- whereas bioavailable includes that tiny fraction plus the much larger fraction that is bound to albumin
- From a clinical standpoint, symptoms track more with free testosterone than bioavailable
- But honestly, they’re close enough in terms of their prediction of what’s going on that if you’re using a lab that relies on one versus the other, it’s probably okay.
- The lab that Peter uses looks at total testosterone, of course, but **free testosterone**, and it’s really the free number that Peter is paying most attention to

**How testosterone works [9:15]**

- It makes its way into the cell, and then it binds to an androgen receptor (this receptor is outside of the nucleus)
- It undergoes this conformational change, and it causes things called [heat shock proteins](https://en.wikipedia.org/wiki/Heat_shock_protein) to be dislocated
- Heat shock proteins get transported into the cell, and then something called the dimerization takes place
- Dimerization is a fancy way of saying a new molecule is created by the fusion—and it doesn’t have to be covalent, it can be non-covalent—but fusion of two molecules that look very much alike
- This androgen receptor dimer now makes its way into the nucleus and binds with something called a hormone response element, which is what actually turns on and off gene transcription
- Effectively, testosterone is up or downregulating genes that are responsible for a number of things—the most obvious of these are the anabolic or growth characteristics

*Another important hormone worth mentioning is* [*dihydrotestosteron*](https://en.wikipedia.org/wiki/Dihydrotestosterone)*e (DHT)*

- DHT is about three to six times more powerful than testosterone—meaning a greater binding affinity for the androgen receptor
- DHT is something that is converted from testosterone using an enzyme called 5-alpha reductase
- “*We could go a lot deeper into it, but I’m not sure it really adds much value to the clinical questions that we’re going to want to get to*”

## How the body naturally regulates testosterone levels [11:30]

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-1.-ama28-1024x786.png)

**Figure 1. Hypothalamic-pituitary-gonadal axis.** ([Boron and Boulpaep, 2016](https://www.elsevier.com/books/medical-physiology/boron/978-1-4557-4377-3)).

- There is a feedback loop that exists in this process
- You have the central nervous system, but specifically the hypothalamus
- The hypothalamus, in response to low testosterone, will secrete gonadotropin-releasing hormone
- It secretes that to another part–the endocrine system called the pituitary gland, which is divided into two pieces,
  - 1) an anterior and
  - 2) a posterior
- In the anterior pituitary gland in response to gonadotropin-releasing hormone, two other hormones are released (commonly seen on a blood test)
  - 1 – LH or luteinizing hormone
  - 2 – FSH or follicle-stimulating hormone
- LH and FSH are released from the anterior pituitary gland into the blood stream and their targets are two specific types of cells in the testes
  - 1 – The Sertoli cell
  - 2- The Leydig cell
- The Sertoli cell is responsible for secreting growth factors that further stimulate the Leydig cell
- LH directly acts on the Leydig cell
- The net result of this is the production of testosterone
- And as you can see on this figure, it’s actually a little more specific…
  - The androgens that are produced by the Leydig cell, testosterone, can undergo what’s called romatization—which is the process by which they are turned into estrogens using specific enzymes
  - An obvious by-product of testosterone creation is the co-creation of [estradiol](https://en.wikipedia.org/wiki/Estradiol)

**The most important takeaway**:

- When testosterone is low, the feedback cycle to the brain ultimately is to ramp up the secretion of LH and FSH
- Conversely, when testosterone is high, the signal that’s sent back is to inhibit the production of these things

*\*A very important point to understand clinically*:

- If a person is supplementing with testosterone, it is usually very obvious to tell this from their blood work because they have unmeasurable levels of LH and FSH and usually high levels of testosterone
- At some point, this becomes a permanent issue—if a person is taking exogenous testosterone for long enough, their body will lose the ability to make its own
- Another way to look at this clinically is when you see patients who have relatively *high LH and high FSH, but low testosterone*
  - In that situation, the problem is usually in the testes
- Conversely, when you see *low testosterone, but low LH and low FSH*…
  - the problem is usually central, meaning there’s something in the brain that isn’t working—there’s something in that pathway, either at the GnRH level or at the pituitary level.
- *The most common thing* that we see clinically that results in that picture, i.e., low testosterone, but with an inappropriately low LH and FSH, is sleep deprivation and hypercortisolemia, i.e., Lots of stress
  - Those are unfortunately kind of ubiquitous clinical situations—a lot of people that have insufficient sleep or insufficient quality of sleep and/or high levels of cortisol and stress, which, by the way, are difficult to disentangle sometimes from poor sleep
  - And that can result in the brain not sending the right signal to the testes.
- That’s important from a clinical perspective because how we treat low testosterone—and when we do make the decision to treat—*it is highly dependent on being able to differentiate between those two paths*

## The defining threshold for “low testosterone,” how low T impacts men, and why free testosterone is the most important metric [16:15]

**The question:** ***If somebody is looking at a panel, what is low testosterone?***

- Most of the literature focuses on low total testosterone and that’s probably because it’s more commonly measured
- Peter rather would focus on **free testosterone** because that’s actually the testosterone that makes its way into the cell

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-2.-ama28-1024x764.png)

**Figure 2. Total ​​testosterone levels in males and females.** ([Chernecky and Berger, 2012](https://www.elsevier.com/books/laboratory-tests-and-diagnostic-procedures/chernecky/978-1-4557-0694-5))

This table that looks at **total** testosterone levels and you get a sense at how wide the range is across all age groups

- Peter will only look at the *nanogram per deciliter units* simply because that’s the units he’s most familiar with
- In the very first column, there are a few of things worth noting:
  - The testosterone level of a newborn is 75 to 400 nanograms per deciliter — “*I’ve seen men with testosterone levels in that level*”
  - *Then what happens?* … In the first six years of life, it’s virtually unmeasurable
  - In the next couple of years of life, it’s still virtually unmeasurable
  - Then you see by about 10 to 11 years of age, it’s slowly starts to kind of ramp up
  - Then puberty hits, 12 to 14, and now it really kind of takes off
  - Peak testosterone is going to be in about the later part of the teens into your twenties and thirties.
- NOTE: These ranges, because they’re so wide, it’s important to understand what they represent—typically represent the 10th to the 90th percentile
  - For example, if you look at the age range of 20 to 39, it says the range is 400 to 1,080 nanograms per deciliter
  - What that means is 10% of men in that age range will be low 400 nanograms per deciliter and 10% will actually be above 1,800 nanograms per deciliter
- Important to point out that this tends to vary by laboratory, because every lab has kind of a different way that they’re doing this—everyone will typically report on their ranges—and that’s why you may see some variation amongst this
- One of the things Peter appreciates about this table is that it shows the change more or less by decade.
- A note about women: “*I can tell you just from our clinical experience that a woman in that sort of midlife but prior to menopause will typically be about 50 to 100 nanograms per deciliter. That’s about* ***one-10th that of a man***.”
- You will also notes that the range gets narrower as men get older and that’s because peak testosterone levels get lower and lower and lower
- Again, notice the units here, *nanograms per deciliter*

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-3.-ama28-1024x487.png)

**Figure 3. Free ​​testosterone levels in males and females.** ([Chernecky and Berger, 2012](https://www.elsevier.com/books/laboratory-tests-and-diagnostic-procedures/chernecky/978-1-4557-0694-5))

- NOTE: You will notice that the study switches the units to picograms per milliliter–”I’m not sure why that’s done. I’ve always found it counterintuitive, because it would seem to me that if reporting total testosterone in nanograms per deciliter, we would want to be able to talk about free testosterone also in nanograms per deciliter.”
- It turns out it’s a really easy conversion to make—to go from picograms per milliliter to nanograms per deciliter, you’re just moving the decimal place over to the left one point
- For example, when you look at the case of males over the age of 18, it says 44 to 244 picograms per milliliter, but what that really means is 4.4 to 24.4 nanograms per deciliter
- “For me, that’s more intuitive. Because in my mind, I’m always doing the calculation, ‘*What is their free as a function of their total?*’”

***Discussion about the huge range in free testosterone levels***

- Look at that range — 4.4 to 24.4
  - And to say that 80% of men live within that range gives you just a sense of how variable this is
- For context, we would never see a range like that for a normal potassium level, a normal sodium level, a normal bicarb level, a normal hemoglobin
  - Those things are confined to very, very narrow ranges
- Peter says the best explanation for this range is that there are other factors at play—because for example, androgen receptor sensitivity probably varies amongst men as well, nuclear transcription rates, responses to the androgen receptor dimer complex, all of these things probably create some normalization or some buffering of these vast differences.
- On the flip side — let’s consider another hormone like thyroid hormone
  - We might say normal is 0.5 to 4.5 for TSH, which is also kind of an absurdly broad range
  - But that doesn’t necessarily mean that people at all extremes feel wonderful
- In other words, Peter would not suggest that someone at a free testosterone level of 4.4 and someone at 24.4 typically feel the same—they almost certainly do not
  - But it also speaks to how broadly we can see people when they are at least physiologically functioning
- Again, if we were dealing with hemoglobin and we were talking about a range that broad…
  - you wouldn’t see that same level of compensation — Someone with a hemoglobin of 5.0 versus 15, which is just a three- fold difference, is night and day
  - “A person with a hemoglobin of 5 will barely be able to get up off the ground. The person with the hemoglobin of 15 is ready to go ride the Tour de France.”
- So again, I’ll just sort of note that there’s enormous variability there
- “But I haven’t met too many people that walk around with a free testosterone of 4.4 who upon really being scrutinized will tell you that they feel just adequate”

***As men get older, what is the prevalence of low testosterone?***

- It’ll depend how you define it, but you’ve got to figure here that looks at defining low testosterone as under 325 nanograms per deciliter
- “I would argue that that is VERY low.”
- And here they use bioavailable (free plus the albumin bound) instead of free T, but nevertheless, they use bioavailable levels under 70 nanograms per deciliter and that’s a relatively low bioavailable number
- You can see that by decade, the prevalence of low testosterone as defined by these levels rises quite sharply

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-4.-ama28-1024x729.png)

**Figure 4. Prevalence of low levels of total and bioavailable testosterone according to decade of life.** ([Rhoden and Morgentaler, 2004](https://www.nejm.org/doi/10.1056/NEJMra022251?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed))

- If you just look at the total testosterone…
  - when you look at men in their twenties, 5% would meet that criteria
  - men in their thirties, it would probably be 2 or 3%
  - In their forties, you’re up to 10%.
  - In their fifties, 12 to 13%.
  - Then it kind of climbs pretty sharply, such that by the time you’re talking about men in their eighties, half of them would be below that level
  - If you use the bioavailable metric, even by the time they’re in their seventies, you’re talking about 70% of men having low testosterone by those levels and 30% when we’re in our fifties

## When it makes sense to treat low testosterone [26:00]

> “In my opinion, to treat testosterone based on the number alone is unwise.” —Peter Attia

- You want to also understand what’s happening with respect to symptoms and metabolic markers
- As a general rule, when it comes to the endocrine system, it doesn’t make a lot of sense to treat numbers for the sake of numbers
- That’s different elsewhere in biology;
  - For example, lipoproteins, it makes sense to treat the number just for the sake of the number, and you don’t expect the patient to necessarily feel any better when you do so
  - When you take apoB from 100 down to 70, the patient is not going to feel any better, but you will have improved their risk for atherosclerotic disease.
- But when it comes to the endocrine system, whether it be thyroid, adrenal, sex hormones, you have to be getting a symptomatic benefit
- We’ll divide symptoms into two categories:
  - more traditional sense of symptoms such as more muscle mass, increased libido, a greater sense of well-being, improved sleep
  - we’ll also talk about things that are measured such as the metabolic parameters that can improve

*Why drugs that improve symptoms has better adherence*

- With lipid modulating drugs, you don’t feel anything or there’s no alleviation of symptoms
- But just in terms of the adherence to taking a drug like that where you don’t feel any benefit, you might not think it’s actually doing anything.
- But as we’ll probably get into with testosterone therapy, I’m curious as to the adherence when people go on testosterone. If you’re alleviating symptoms like bettering your sleep or your performance or your libido and things like that, I think people might be more inclined to stay on it
- That’s really good point and is absolutely correct: Compliance is much better when it comes to medications that change the way you feel
  - That can be things like testosterone replacement therapy, thyroid replacement therapy, other forms of hormone replacement therapy, medications that help people sleep better
  - All of those things have a much higher compliance than things for which people don’t feel a difference such as blood pressure medication, lipid medication, things like that

## The structural and metabolic benefits of testosterone replacement therapy [29:15]

**Peter puts TRT benefits into two categories**

1 – structural benefits

2 – metabolic benefits

- Structural benefits would include strength, body composition, and bone mineral density
- Metabolic benefits would be glucose disposal, changes in parameters that would lead to increased metabolic health, etc.

**Testosterone/steroids are enough on their own to produce significant muscle mass growth**

- Testosterone replacement therapy in a *trained* individual will almost without exception increase lean mass and often decrease fat mass
- It’s important to point out that that requires usually doing something (i.e., Ronnie Coleman doesn’t look like he does simply from steroids, it’s the extreme training and genetics that make the difference)
- The point here being is testosterone is going to exert its maximum effect on the individual that is doing the maximum amount of training and the one who is actually requiring the most of that DNA machinery, that gene transcription to repair
- Peter says: “What I find interesting about some of the studies is they don’t necessarily prescribe exercise to the participants, and we don’t have a great sense of whether or not these participants are exercising more or less.”

**TRT studies**

[Exogenous Testosterone or Testosterone with Finasteride Increases Bone Mineral Density in Older Men with Low Serum Testosterone (Amory et al., 2004)](https://academic.oup.com/jcem/article/89/2/503/2840744)

- Peter comments that his study is very elegant because it sought to identify if the benefits of testosterone replacement therapy were more mediated by testosterone or dihydrotestosterone (DHT)
- W*hy that matters*:
  - Testosterone gets converted by an enzyme called 5-alpha reductase into another hormone called DHT that is somewhere between three and six times more potent than testosterone.
  - this is a hormone that has become of interest for a totally separate reason, which is in men who are androgen sensitive to hair loss, DHT will drive hair loss
  - It is also a hormone that will disproportionately drive hyperplasia of the prostate gland. So it will increase the size of the prostate gland
  - And as a result of that, there are a number of drugs that exist to block that enzyme, 5-alpha reductase, and thereby reduce the conversion of testosterone to DHT
  - So the two drugs that are very commonly used, one is called [finasteride](https://en.wikipedia.org/wiki/Finasteride), which when given at five milligrams daily, which is a pretty whopping dose, will basically eliminate DHT
  - And that’s a drug that has historically been used for the management of what’s called BPH or benign prostatic hypertrophy
  - So in older men typically, when the prostate gets quite large, it results in a lot of miserable symptoms, probably the most notable of which are urinary symptoms
  - And so by giving these men five milligrams of finasteride, you can block the creation of DHT, and a lot of times the prostate will shrink in size and therefor alleviate these symptoms
  - Now, if given at lower doses, by the way, typically one milligram daily, finasteride will lower DHT typically enough to have an improvement in hair loss
  - More about this in the [podcast with Alan Bauman](https://peterattiamd.com/alanbauman/)

***So what did*** [***this study***](https://academic.oup.com/jcem/article/89/2/503/2840744) ***do?***

*Dosing*: This study gave men 200 milligrams of testosterone intramuscularly every two weeks—so they average about a hundred milligrams a week

*\*Note from Peter about dosing and efficacy*:

- From clinical experience, that’s a very normal physiologic dose of testosterone”
- Probably the lowest dose I’ve ever seen a male patient take is about 50 milligrams weekly”
- But for males, the very lowest dose, I would see having any efficacy would be about 50 milligrams weekly, but typically it’s about a hundred to 120 weekly
- So 200, every two weeks is on that kind of normal, low end dose
- For what it’s worth, I’ve never been a fan of intramuscular dosing and or dosing at every two weeks, because the half-life is three and a half, four days. And therefore you tend to have a very high peak and then a period of having normal doses, and then you kind of fall off
- In our practice, for men who are using testosterone, we would prescribe it twice a week, subcutaneously. So you would take the weekly dose if it’s a hundred and instead you would take 50 every three and a half days, or basically you’d go twice a week.
- We even have some patients who are fine doing this daily. And so they’ll take one seventh of a weekly dose subcutaneously every single day

*Groups in the study*:

- Group one is taking 200 milligrams of testosterone every two weeks with a placebo pill—your “testosterone only” group
- Group two is taking the same amount of testosterone, but they’re also taking five milligrams of finasteride daily—so this is your “testosterone plus finasteride” group, which means this is a group that’s going to have presumably the same level, more or less, of testosterone in the first group, but no dihydrotestosterone
- Group three is taking a placebo of both—placebo injections plus placebo pills

“*I just can’t tell you how interesting I found this study*” says Peter

- This table gets at something that we didn’t talk about yet, which is another important both benefit and side effect of testosterone
- something that is both a benefit and side effect is worth talking about, and that is what’s called [haematopoiesis](https://en.wikipedia.org/wiki/Haematopoiesis)
- Testosterone is a very potent stimulator of creating new red blood cells
- for a person whose hematocrit is low, that’s a really great benefit of testosterone
- For a person whose hematocrit is normal, that is a side effect that needs to be managed
- Meaning if you get too much haematopoiesis, you actually need to donate blood
- You don’t want to have your hematocrit become too high

*Looking at how testosterone plus or minus DHT impacted hemoglobin…*

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-5.-ama28-1024x219.png)

**Figure 5. Hematocrit, hemoglobin, prostate size, and PSA during treatment.** ([Amory et al., 2004](https://academic.oup.com/jcem/article/89/2/503/2840744))

- Note that for the purposes of this discussion, **hematocrit and hemoglobin are the same thing**
- This was a study that was done over three years
- You have your baseline, your midpoint and your three-year mark
- In the placebo group, as you can see, there was no change from baseline all the way out to 18 months and 36 months with respect to hematocrit
- In the testosterone only group, you can see that by 18 months, and it stayed constant until 36 months, there was a significant increase in hemoglobin/ hematocrit
- And the same was true in the group that would have had high testosterone but low DHT
- Remember…
  - T only means your testosterone goes up and your dihydrotestosterone goes up
  - Testosterone plus finasteride, means your testosterone goes up, but your DHT would have been suppressed
- So this suggests that the hematopoietic impact of testosterone replacement therapy is **via testosterone** and not via DHT

*Effects on prostate specific antigen (PSA) and prostate volume*

- Another interesting observation is the effect of testosterone replacement therapy on both PSA, prostate specific antigen, and prostate volume
- *First looking at prostate volume*:
  - A normal prostate is about 30 *grams* in size but note Peter can’t comment if 32 CC is normal or not
  - But what’s interesting here was that in the placebo group, prostate size went up with no treatment
    - So in just a three year period of time, the men went from a prostate size of 32 to 42 CC, and that was statistically significant
  - In the testosterone only group, it went up from 29 to 43, which is about the same, and also statistically significant
  - And in the testosterone plus finasteride group, it went from 33 to 38, and that was significant with respect to their baseline, and also significant with respect to the T only and the placebo
  - In other words, what this means is that **all of them had a statistically significant increase above baseline, but the DHT removal group was significantly lower than the T only in the placebo group**
  - “I’m not sure what to make of this” says Peter
    - Note the avg age of this group is 71 and that’s probably the decade of life when we’re going to see the biggest growth of the prostate
  - Nevertheless, it’s interesting to note that that even in the placebo men, it went up that much
  - What this would demonstrate is that **blocking testosterone to DHT conversion mitigates that response**
  - So you attenuate the effect of PSA increase and prostate size increase with 5-alpha reductase inhibition
- Now looking at PSA change…
  - If you look now at the PSA change in the men who were just on the placebo, the PSA went from 1.4 to 1.7, that was not statistically significant
  - In the men receiving testosterone only it went from one to 1.4, which was statistically significant
  - And in the men receiving testosterone plus finasteride, it went from one to 1.1, which was not statistically significant
  - Again, suggesting that when it comes to managing PSA and managing prostate size, the effects are mitigated by blocking DHT
- We’re going to come back to this topic in more detail, but what matters more than this is the risk of prostate cancer

**Now looking at changes in** ***bone mineral density*** **in this study [43:15]**

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-6.-ama28-1024x479.png)

**Figure 6. Mean BMD (g/cm2) measured by DXA in older men administered in T alone, T + F, or placebo** ([Amory et al., 2004](https://academic.oup.com/jcem/article/89/2/503/2840744))

- This is also something that I don’t think gets enough attention, says Peter, Because as we age, the risk of accidental falling—and therefore accidental fractures—goes up
- Peter being honest:
  - “*I had always been under the impression that testosterone did not impact BMD, that BMD was largely set by the time you’re in your twenties and the only thing that you really had at your control were managing things that reduced BMD*…[things like avoiding long courses of corticosteroids, inability or lack of impact exercise, etc.]”
  - “*But I didn’t really think that we had a tool like testosterone at our disposal to actually increase bone mineral density*”
- Looking here, you see that turned out to be not the case
- It’s basically showing you different bony regions—
  - So the lumbar spine, the total hip, the intertrochlear or trochanteric region. So that’s the area between the upper part of the femur and the ball, the socket, the hip socket joint
  - The femoral neck, and then the actual trochanter itself.
- The trends here are pretty clear
- Baseline to six months to 12 months to 18 and all the way to 36 months—there is almost a monotonic rise in bone mineral density for both the testosterone and the testosterone plus finasteride groups, *but not in the placebo group*
- What that means is across each of these metrics, bone mineral density went up both in the group with increased testosterone and increased testosterone without DHT, suggesting, again, that **testosterone and not DHT is responsible for these BMD benefits**

## Body composition changes with TRT [45:30]

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-7.-ama28-1024x515.png)

**Figure 7. Change in body composition in older men with low T treated with T, T + F, or placebo for 36 months.** ([Page et al., 2005](https://academic.oup.com/jcem/article/90/3/1502/2836784))

- The graph on the left shows the change in body composition—looking at the increase or decrease in lean mass
- The graph on the right is showing you the increase or decrease in fat mass
- The placebos showed no change from baseline, so they didn’t gain or lose any statistically significant amount of lean mass and they didn’t gain or lose any statistically significant amount of fat mass
- Conversely, the other two figures show basically mirrored graphs
- In other words, the testosterone and the testosterone plus finasteride graph are basically the same graph, which suggests that **the effect we’re looking at is due to testosterone and not dihydrotestosterone**
- We saw about a four kilogram increase in lean mass—that’s not a trivial amount in three years, especially for men of that age (~71 years)—that’s about **nine pounds of lean mass** that was added during three years
  - “It’s staggering” says Peter
- In terms of fat mass, they lost close to 10 pounds
- So they would have had a net loss of about one to two pounds of total body weight gaining approximately 8.5 pounds of lean mass and losing about 10 pounds of muscle mass all while gaining bone mineral density
- Here’s an example of where BMI is not a good metric—these guys would have had a negligible change in BMI
- But from a body composition, “*this is enormous*”

## Changes in bone mineral density with TRT [48:15]

[Effect of Testosterone Treatment on Volumetric Bone Density and Strength in Older Men With Low Testosterone](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2604138)

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-8.-ama28-1024x373.png)

**Figure 8. Effects of Testosterone or Placebo Treatment for 12 Months on Volumetric BMD and Estimated Bone Strength, as Assessed by QCT.** ([Snyder et al., 2017](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2604138))

*Study design:*

- 200 men
- 65 and older
- They had low testosterone
- followed them up for over a year
- looked at their bone mineral density and bone strength and muscular strength
- This was using a topical testosterone  — Peter notes he’s “never really been a fan of topical testosterone [because] I find the bioavailability of it to be so variable among men”
- They titrated the dose until they got the men into the normal range —
- these men were starting out at a very low level (~275 nanograms per deciliter)
- So they probably had to give them quite a bit of testosterone to get them back into, I would guess, the 500-700 range

*Results:*

- Pretty unambiguous change in bone mineral density
- But, *why the fixation on spine and hip?*
  - the reason is that we use the spine and the hip to make the diagnosis of osteopenia
  - if you get a DEXA scan, for example, it may show you lots of different BMD readings, and it may even show you your total body BMD reading, but the ones we pay most attention to are lumbar spine and hip, because that’s where we can actually make the diagnosis of osteoporosis or osteopenia
- The results were clearly showing increase in BMD and bone strength
- “*I find interesting because, again, I really did not think that this was the case. This was very much news to me, and it speaks to just a blind spot that I had, which was the belief that there was no way that testosterone replacement therapy was going to have an impact on BMD*.”
- You also see an improvement in bone strength as well
- So this is not just increasing density without a functional change. It’s also increasing it with a **functional benefit**

> “There were countless other studies to look at, but they all basically point in the same direction, which is testosterone replacement therapy improves lean mass, reduces fat mass, improves strength.” —Peter Attia

*Implications of these findings:*

- it’s a life saving therapy
- when you look at the sarcopenia that’s associated less so today with antiretroviral therapy, but in the early days of HIV and AIDS, testosterone replacement therapy was perhaps one of the most important therapies that these patients had to prevent the muscle wasting that was an enormous comorbidity of the disease

## The metabolic impact of TRT: glucose, insulin, triglycerides, and more [52:30]

***What’s the level of evidence to suggest that testosterone replacement therapy has a benefit metabolically?***

- Bob says, “*I think there’s good evidence that metabolically there are good things happening*.”

[**2014 meta-analysis**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3901874/)

**This first figure is looking at fasting glucose:**

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-9.-ama28-1024x573.png)

**Figure 9. Fasting plasma glucose (mM) in testosterone and control groups.** ([Cai et al., 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3901874/))

*Study set up*:

- They looked at fasting glucose, fasting insulin, HBA1C, and triglycerides
- When you aggregate it, all the study was an average followup of about seven months on testosterone replacement therapy
- We’ve got fasting plasma glucose levels, and testosterone and control groups
- Different forms of testosterone:
  - Top group used a testosterone gel
  - Second to the top group used oral testosterone,
  - The third group used intramuscular testosterone
  - Then at the bottom of Figure 9 is the aggregate of the aggregates

*Orienting you to what you’re seeing in Figure 9 above:*

- This is a very common way that meta-analysis will demonstrate in one figure all of the studies
- you have the vertical line that passes through zero and basically anything that is to the left of that means there’s an improvement in the variable of interest, and anything to the right of that would mean that the variable of interest gets worse
- So what these figures show is the mean value and then the error bar for the 95% confidence interval for each variable
- If your interval for the 95 confidence interval crosses the unity line, it is not statistically significant

*Results:*

- In the very first group, the 2009 study using testosterone gel…
  - It found a hazard ratio of minus 0.5, so that means a 50% improvement
  - And the confidence interval is minus 0.94 to minus 0.06, which does not cross one, therefore that is statistically significant, albeit barely
- In the second group,
  - minus 0.17 is the mean difference, but notice that the 95 confidence interval, minus 1.42 to 1.08 crosses the unity line, so that’s not significant.
  - “just as another clinical aside, I am not at all a fan of oral testosterone administration. I think it’s certainly doable, but it’s very hard on the liver and you really want to be able to administer it in a manner that kind of dissolves under the tongue without being swallowed at all, to avoid the first pass effect”
- Looking at the **aggregate benefit to fasting glucose**…
  - a reduction of 1.10 millimole of glucose, which is statistically significant
  - so that translates to about 20 milligrams per deciliter

**This next figure is looking at fasting insulin**:

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-10.-ama28-1024x240.png)

**Figure 10. Fasting serum insulin (mIU) in testosterone and control groups.** ([Cai et al., 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3901874/))

- These results are less clear in their benefit
- Three of the four studies have a trend towards a reduction of fasting insulin, but are not significant
- But one study is pretty significant
- But based on the number of subjects in this significant study, it kind of dominates the others so the net effect is that the entire meta-analysis suggests a reduction in fasting insulin as well

**This next figure is looking at HbA1c**:

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-11.-ama28-1024x226.png)

**Figure 11. HbA1c % in testosterone and control groups.** ([Cai et al., 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3901874/))

- The figure speaks for itself, says Peter
- Two of the three studies here show a reduction in hemoglobin A1C
- Again, it’s worth noting where these patients started
  - This is a study of patients who either have diabetes or will very soon have diabetes
  - To be clear, they’re still diabetic at the end of this study — “In other words, not here to suggest that testosterone replacement therapy cures diabetes. It’s simply looking at a population with type two diabetes and noting how much of a benefit you get from the testosterone itself.”
- In the second study, they’re pre-diabetic and they experience a very, very small change, almost a negligible change
- In the next study, which includes both diabetic and pre-diabetic, you experience a greater change
- And the **net change is almost 1% reduction** in hemoglobin A1C

**This next figure is looking at triglyceride levels**:

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-12.-ama28-1024x243.png)

**Figure 12. Triglyceride levels (mM) in testosterone and control groups.** ([Cai et al., 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3901874/))

- Summary: modest improvement in triglyceride levels

## A study investigating testosterone replacement therapy for prevention or reversal of type 2 diabetes [59:30]

**2021 Study**: [Testosterone treatment to prevent or revert type 2 diabetes in men enrolled in a lifestyle programme (T4DM): a randomised, double-blind, placebo-controlled, 2-year, phase 3b trial](https://pubmed.ncbi.nlm.nih.gov/33338415/)

*Study design:*

- This study is asking, *what’s the efficacy and safety of testosterone treatment?*
- They’re looking at a couple of things to prevent the progression of impaired glucose tolerance to type two diabetes
- also, can it reverse newly diagnosed type two diabetes beyond the effects of what they called lifestyle intervention
- in this case, Weight Watchers was the lifestyle intervention
- randomized double blind placebo controlled trial
- men 50 to 74 years old
- they had impaired glucose tolerance or newly diagnosed type two diabetes
- They were getting TRT intramuscularly

*Issues Peter has with the study*:

- Peter doesn’t think this study was dosing in an optimal way
- They got a thousand milligrams of intramuscular testosterone at baseline and then six weeks later, and then every three months for two years.
- An ideal dose would be a hundred milligrams weekly
- “And when you consider the half-life of testosterone, you understand that every time these guys are getting a thousand milligrams, they are so super physiologic, it’s almost comical. And by the end, when they’re getting ready for their shot at the end of the last month, for example, the testosterone’s basically all gone.”

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-13.-ama28-1024x317.png)

**Figure 13. Primary outcomes at 2 years.** ([Wittert et al., 2021](https://pubmed.ncbi.nlm.nih.gov/33338415/))

*Primary outcomes*:

- They looked at their two hour glucose on an oral glucose tolerance test
- And they looked at where they were at or above 11.1 millimoles per liter (converts to 200 milligrams per deciliter)
- And the reason for it is that’s the diagnosis, that’s the old diagnosis of type two diabetes
- So today the diagnosis of type two diabetes is predicated on the hemoglobin A1C being above 6.5%
- “I actually favor the diagnostic criteria used in this study, which is two hours post glucola ingestion to have a blood glucose that is still above 200 milligrams per deciliter would be diagnostic of type two diabetes.”

*Results at the end of 2 years:*

- 21% in the placebo group were at that level
- 12% in the testosterone group
  - So that’s about a 40% reduction, which was statistically significant.
- Looking at the figure, you can see that 21% and 12% at the top
- And then the bottom, the second row, they’re looking at the mean change from baseline in two hour glucose
  - it wasn’t a huge change truthfully in fasting glucose
  - So 0.75 millimole. So sort of 13 to 14 milligrams per deciliter reduction at the two hour mark
  - the treatment group, their fasting blood glucose at baseline was about 109 milligrams per deciliter
  - And then after two years, if you look at that mean change, it went from 109 to basically 106 or 105.5 milligrams per deciliter
  - So kind of a modest reduction in fasting glucose, on the border of statical significance
- At the two-hour mark of an OGTT, you saw about a 13 and 14 milligram per deciliter reduction
- The more **relevant point**:
  - The top line point, which is there’s a little over a 40% reduction in the number of people that trigger the diagnosis of diabetes.

**Table showing secondary outcomes:**

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-14.-ama28-1024x478.png)

**Figure 14. Secondary outcomes.** ([Wittert et al., 2021](https://pubmed.ncbi.nlm.nih.gov/33338415/))

- The highlighted rows are the significantly significant results
- So waist circumference went down a little less than an inch
- Total muscle mass went up by 1.7 kilos (about four pounds)
- Fat mass went down by about six pounds
- Abdominal fat percent down by two and a half percent
- Arm muscle mass up by a little less than a pound
- muscle strength for non-dominant hand up by about five pounds
- “*this is interesting to me, but it’s also curious that these results, while statistically significant and in the same direction as some of the earlier studies we looked at, not as big*” says Peter

## The impact of TRT on metabolic parameters and body composition—A study comparing results from continuous vs. interrupted treatment [1:07:15]

[**2016 observational study**](https://pubmed.ncbi.nlm.nih.gov/26331709/)

*Study overview:*

- Looked at people who went on testosterone, had that interrupted for a period of time, and then went back on testosterone
- observational study where they looked at 300 middle-aged men received TRT for an average of more than five years
- About half of those people had their TRT temporarily interrupted due to a “cost reimbursement issue”
- Another seven men has to stop treatment because they got prostate cancer
- Those men whose TRT got interrupted were then compared to the men who took it continuously

*Peter’s initial reaction to this study results:*

- “*I got to be honest with you. . .it looks too good.*”
- The data looks “made-up” because it was “so perfect”
- There’s an obvious methodological issue here, which is this is an observational study,
- That said, the study is so consistent in its directionality

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-15.-ama28-1024x720.png)

**Figure 15. Total testosterone (nmol/L) in hypogonadal men with continuous (n = 115) and interrupted (n = 147) testosterone treatment.** ([Yassin et al., 2016](https://pubmed.ncbi.nlm.nih.gov/26331709/))

- In Figure 15, you can see that these men all start out hypogonadal and within a very short period of time, they’re all at normal levels of testosterone and they stay that way through five years of treatment
- When you take the interrupted group off testosterone, they return basically to their baseline level
- Then when you put them back on testosterone, they return to the level they were basically at on treatment

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-16.-ama28-1024x715.png)

**Figure 16. Waist circumference (cm) in hypogonadal men with continuous (n = 115) and interrupted (n = 147) testosterone treatment.** ([Yassin et al., 2016](https://pubmed.ncbi.nlm.nih.gov/26331709/))

- On the X-axis here, we’re looking at waist circumference in centimeters
- When both of these groups go on testosterone, they have a very linear reduction in waist circumference
- The green group just stays basically on that trajectory and keeps marching on through
- The interrupted group, once you take them off testosterone, their waist shoots back up in size and when you put them back on testosterone, it comes right back down at the same rate that it was before and the same rate of the uninterrupted group.

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-17.-ama28-1024x713.png)

**Figure 17. Weight (kg) in hypogonadal men with continuous (n = 115) and interrupted (n = 147) testosterone treatment.** ([Yassin et al., 2016](https://pubmed.ncbi.nlm.nih.gov/26331709/))

- these guys average about 220 pounds at the outset
- we’re going to assume that that puts them at the overweight category
- In both groups, weight comes down to the tune of about 8 to 10 kilograms
- Then the interrupted group,
  - their weight shoots back up, and again, to the tune of five kilos in 17 months
  - And then once they resume testosterone, it comes back down.

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-18.-ama28-1024x731.png)

**Figure 18. BMI (kg/m2) in hypogonadal men with continuous (n = 115) and interrupted (n = 147) testosterone treatment.** ([Yassin et al., 2016](https://pubmed.ncbi.nlm.nih.gov/26331709/))

- At baseline, these men are clinically obese at over 30 BMI
- Results almost mirror the body weight figure

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-19.-ama28-1024x752.png)

**Figure 19. Fasting glucose (mg/dL) in hypogonadal men with continuous (n = 115) and interrupted (n = 147) testosterone treatment.** ([Yassin et al., 2016](https://pubmed.ncbi.nlm.nih.gov/26331709/))

- The results here seem more pronounced than what we saw in the previous study
- people are all starting out with a very elevated fasting glucose, somewhere between 110 and 115 milligrams per deciliter
- the continuous treatment group, they basically monotonically fall from that level down to a normal level — “*that’s astonishing.*”
- the continuous group goes from 113 milligrams per deciliter to 105 over five years
- The interrupted group…
  - They shoot back up to higher than when they started
  - And then you put them back on testosterone and they have this really precipitous fall ending up at 90.

*Quick note on something that bothers Peter about these results:*

- The interrupted group doesn’t do as well as the continuous group prior to the interruption
  - They seem to be starting out worse in some cases
  - And don’t seem to progress as quickly
- That’s a limitation of the fact that this is not a randomization
  - So by definition, if we know that the interrupted group are interrupted because of an insurance issue and a reimbursement issue, there must be a socioeconomic difference between the groups
  - And if there’s a socioeconomic difference between the groups, there are a whole bunch of other differences between these groups that we’re probably unaware of.
- “*[However], that doesn’t in any way diminish the point of this study. But it’s interesting to me how remarkable the improvements are in both groups independent of what I just said.*”

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-20.-ama28-1024x807.png)

**Figure 20. HbA1c (%) in hypogonadal men with continuous (n = 115) and interrupted (n = 147) testosterone treatment.** ([Yassin et al., 2016](https://pubmed.ncbi.nlm.nih.gov/26331709/))

- Looking at the continuous group
  - These guys start out at a hemoglobin A1C of 6.4
  - By the end of the study, they’re at 5.6
- How to reconcile these results with the results from the [T4DM study](https://pubmed.ncbi.nlm.nih.gov/33338415/)?
  - You could argue here that the time course is so much longer
  - This is effectively a nine-year study, and we don’t have the time point of two years
  - We basically go from baseline to the time point of 5.5 years
  - So it does beg the question. Did the most recent study, the T4DM study, did it fail to show these improvements because it was so short and/or because the method of testosterone delivery was so wonky as commented earlier?
- For the interrupted group…
  - they basically start at baseline on average, diabetic, and then before interruption, they’re no longer diabetic according to the Hb1C cutoff of 6.5
  - then they go off treatment, they become diabetic again.
  - They go back on treatment, they’re no longer diabetic
  - “It’s kind of remarkable.”
  - It’s also interesting how much quicker they get back to being diabetic and how quick they get back to being not diabetic once they resume therapy

> “I’m not suggesting there was anything wrong with this study because we couldn’t find anything wrong with it, but it just seems too good to be true.” —Peter Attia

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-21.-ama28-1024x717.png)

**Figure 21. Systolic blood pressure (mmHg) in hypogonadal men with continuous (n = 115) and interrupted (n = 147) testosterone treatment.** ([Yassin et al., 2016](https://pubmed.ncbi.nlm.nih.gov/26331709/))

- A 20-point reduction in systolic blood pressure
- All fully reversible when you come off testosterone and then fully reproducible when you add testosterone back on

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-22.-ama28-1024x723.png)

**Figure 22. Diastolic blood pressure (mmHg) in hypogonadal men with continuous (n = 115) and interrupted (n = 147) testosterone treatment.** ([Yassin et al., 2016](https://pubmed.ncbi.nlm.nih.gov/26331709/))

- A 10-point reduction in diastolic blood pressure
- “*Remarkable.*”

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-23.-ama28-1024x727.png)

**Figure 23. Total cholesterol (mg/dL) in hypogonadal men with continuous (n = 115) and interrupted (n = 147) testosterone treatment.** ([Yassin et al., 2016](https://pubmed.ncbi.nlm.nih.gov/26331709/))

- Same remarkable trend.

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-24.-ama28-1024x750.png)

**Figure 24. HDL cholesterol (mg/dL) in hypogonadal men with continuous (n = 115) and interrupted (n = 147) testosterone treatment.** ([Yassin et al., 2016](https://pubmed.ncbi.nlm.nih.gov/26331709/))

- “This is the one that I just couldn’t make sense of.” says Peter
- He’s never seen a study showing that HDL cholesterol goes up on testosterone replacement therapy
- And it’s not just a little bit — nearly a 50% increase in HDL cholesterol on testosterone replacement therapy.
- In fact, one of the big arguments that people have made against the use of testosterone replacement therapy is dyslipidemia — “But this study didn’t find that. In fact, it found the exact opposite.”
- look at the interrupted group
  - At end of interruption they’re at about 37
  - And then after 14 months, they’re at 57

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-25.-ama28-1024x743.png)

**Figure 25. LDL cholesterol (mg/dL) in hypogonadal men with continuous (n = 115) and interrupted (n = 147) testosterone treatment.** ([Yassin et al., 2016](https://pubmed.ncbi.nlm.nih.gov/26331709/))

- Peter is shocked at results
  - “The only thing I can think of here is these patients may have been also put on lipid-lowering drugs at the same point in time?
  - “I can’t for the life of me explain how these patients started out with an LDL cholesterol of nearly 160 milligrams per deciliter.”
- The continuous group…
  - monotonic fall to a 100 milligrams per deciliter
  - they went from the 90th percentile to the 20th percentile, at least according to the Framingham cohort.
- The interrupted group…
  - starts out at 160, goes down to 130 before discontinuing therapy, at which point they go back to above one 160
  - Then in just over a year, they go from 160 down to 115
- “Again, it just seems too good to be true.”
- *Peter broad comment:* “I think the only point that can really be drawn here safely is when you give testosterone, then things get better. If you remove testosterone, things get worse again. And when you add testosterone, they get better again.”

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-26.-ama28-1024x736.png)

**Figure 26. Triglycerides (mg/dL) in hypogonadal men with continuous (n = 115) and interrupted (n = 147) testosterone treatment.** ([Yassin et al., 2016](https://pubmed.ncbi.nlm.nih.gov/26331709/))

- If any figure really speaks to how metabolically ill these patients were to begin with…the triglycerides make that point
- these are very, very elevated levels of triglycerides
- they certainly come down, but I wouldn’t say they’ve normalized
- Technically, this is the one metric of metabolic syndrome that they would still trigger
- So in aggregate, the improvement in their health was, again, it seemed too good to be true by every metric we have

**Reflecting on the results of this study**

*If TRT treatment really a lifelong thing in order to see continuous benefits?*

- It might be the case
- The only time we see methods of testosterone replacement that can be somewhat transient are in individuals, especially younger individuals, where their sleep has been deprived, they’ve been ill, so they’re recovering from sickness, and you can sort of kickstart them again
- And in that case, Peter prefers to use HCG, which basically kickstarts the Leydig cell and the Sertoli cell, and basically gets the testes making testosterone again
- Sometimes that is an example of where you normalize testosterone, but you don’t need ongoing treatment

*To summarize kind of the metabolic side of this*

- It’s safe to conclude that basically, testosterone replacement therapy is an effective therapy for people with low testosterone and metabolic dysfunction
- So in addition to the improvements in lean mass, fat mass, strength, bone mineral density, we can add to that list basically every parameter of metabolic dysfunction

## The controversy over TRT and cardiovascular disease [1:21:45]

**Concerns about TRT**

- When it comes to testosterone replacement therapy, the big thing people and even smart physicians worry about is prostate cancer and cardiovascular disease
- But is that concern founded in data? Let’s dig into it

***The story behind how TRT became linked to cardiovascular disease:***

- It’s a similar story to how hormone replacement therapy for women became linked to an increased the risk of breast cancer (See [podcast with Avrum Bluming and Carol Tavris](https://peterattiamd.com/caroltavris-avrumbluming/))
- In this case, in late 2013, early 2014, couple of studies came out reporting increased cardiovascular events in men who received testosterone prescriptions
  - [Vigen et al., 2013](https://jamanetwork.com/journals/jama/fullarticle/1764051)
  - [Finkle et al., 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3905977/)
- Subsequently, The Endocrine Society issued a [statement](https://www.endocrine.org/news-and-advocacy/news-room/2014/endocrine-society-calls-for-large-scale-studies-to-evaluate-testosterone-therapy-risks) in February 2014 cautioning against the use of T therapy in older men and in men with a history of CAD.
- The FDA [announced](https://www.fda.gov/media/91048/download) plans to review the CV safety of T products two days after publication of the second article, on January 31, 2014.

**The** [**2013 study**](https://jamanetwork.com/journals/jama/fullarticle/1764051)

- A retrospective analysis of men who had undergone coronary angiography within the Veterans Administration health care system.
- The authors reported that the overall rate of MI, stroke, and death in men with serum T levels less than 300 ng/dL was higher in men who received a T prescription compared with untreated men.
- So they took a bunch of men who had a very low T, less than 300. Some were treated, some were not. And the report was that you had a higher myocardial infarction, stroke, and death in the treated versus untreated men
- Peter’s honest opinion: “*I’m going to just stop the charade and just say, I don’t even understand how this study hasn’t been retracted.*”

*Problems with the study:*

- It turns out that 10% of the people in the study were **actually women**
- “*If you’re so sloppy that you can’t get the gender correct on 10% of the patients in your study, what else are you doing incorrectly*?”

*Looking at the raw data*:

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-27.-ama28-1024x825.png)

**Figure 27. Actual percentage of individuals who experienced an adverse CV event in the testosterone (T)-treated and untreated groups in the study by Vigen et al.** ([Morgentaler et al., 2015](https://www.dropbox.com/s/9xj6sqyc0m4q0oe/%23morgentaler%20%232015%20Testosterone%20Therapy%20and%20Cardiovascular%20Risk-%20Advances%20and%20Controversies.pdf?dl=0))

- Graph that shows the two groups
  - the orange bars are the men with low testosterone who were not treated
  - the blue bar represents the men with low testosterone who were treated
- Y-axis shows the rate of events
- The first event we will concern ourselves with is death
- The second is myocardial infarction
- The third is stroke
- And then in the table or graph rather on the right, we’ll look at the aggregate of all events.

*Results (untreated/treated)*:

- With respect to death: 9%/5.5%
- Myocardial infarction: 5.5%/2%
- Stroke: 6%/2.5%
- Aggregated all event: 21.2%/10.1%
- In summary: This meant that the group that received testosterone replacement therapy had a 52% relative risk reduction in all events or a 10.1% absolute risk reduction.
- In simple terms: you need to treat just 10 people with the therapy to prevent one death stroke or heart attack

*So this is great results, so why is the paper reporting something negative?*

- Well, the study reported a 29% relative risk **increase** in all events in the TRT group compared to the untreated group
- But this is different from the 52% **decrease** we see in the figure above. Why??
- The authors came to an opposite interpretation of the data based on complex statistics that included adjustment for more than 50 variables
- They study did a they did some statistical adjustment that Bob admits is hard to comprehend
- They did a stabilized inverse propensity treatment weighting that they applied to this study
- Also, they tried to control for about 50 variables
- And then they’re also doing this thing called time varying — the time varying covariate of testosterone

*Critization following the publication of the paper:*

- it immediately received a lot of similar responses to Peter and Bob’s response
- And “*it’s not that statistical adjustments are a bad thing. In fact, they’re generally a good thing, I think, as an attempt, when you’re looking at non-randomized data. But a good thing can be taken too far, and that seems to be the case here*.”
- Almost immediately, the authors published a correction to this study, but it was challenged again and again and again
- There were just so many repeated errors in this study, including the statistical correction, the accidental inclusion of 10% women in a study of men, etc.
- In response to these errors, 29 international medical societies and more than 160 physician-scientists from 32 countries petitioned JAMA to retract this article, [citing](https://www.dropbox.com/s/9xj6sqyc0m4q0oe/%23morgentaler%20%232015%20Testosterone%20Therapy%20and%20Cardiovascular%20Risk-%20Advances%20and%20Controversies.pdf?dl=0) “*gross data mismanagement and contamination” that rendered the study “no longer credible*.”
- And yet, as of this recording, **this study has not been retracted**.
- The FDA was forced to look at this, but they ultimately concluded that this study was so limited that they could not attribute the reported findings to testosterone treatment

**The** [**2014 study**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3905977/)

- A retrospective study of a health insurance database that reported rates of nonfatal MI in the period up to 90 days after a T prescription and compared these rates to MI rates in the previous 12 months
- Essentially they looked at the moment someone got a testosterone prescription and looked at, *What was the risk of a non-fatal MI in those 90 days. And how does it compare to the rates of MI in the previous 12 months for the same patient?*
- The authors reported the rate ratio of MI post-prescription to pre-prescription was 1.36, and the rate in men older than 65 years was 2.19
- In short, that would mean that in all men, there was a 36% increase in MI. And in older men, it was a more than doubling in the risk of EMI
- The “elephant in the room” about this study — *how do you even control for the fact that if someone had an MI in the past 12 months, they might not actually get a testosterone prescription?*

*Limitations of the study:*

- That’s such a big limitation to this one, and I think the FDA analysis also pointed out
- The FDA wrote that it’s “difficult to attribute” the increased risk for non-fatal MI seen in the Finkel study to testosterone alone and not consider that the study participants might have remained hypogonadic and thus had higher risk for non-fatal MI
- A subsequent analysis from [Morgentaler et al., 2015](https://www.dropbox.com/s/9xj6sqyc0m4q0oe/%23morgentaler%20%232015%20Testosterone%20Therapy%20and%20Cardiovascular%20Risk-%20Advances%20and%20Controversies.pdf?dl=0) noted that the observed MI rate in the men who received testosterone was about one-third the expected rate
- In other words, this study didn’t have a control group who were untreated so you have no idea if that change in MI rate should be compared to something that is better or worse.
- We don’t actually know if these MIs were higher, lower, or unchanged with respect to testosterone
- In summary:
  - This wasn’t randomized, an obvious limitation
  - The second limitation is you have a very bizarre selection criteria because of the fact that you wouldn’t be giving a testosterone prescription presumably to someone who had an MI in the last 12 months, but then they don’t even have a control group against which to say, “What’s the expected rate of MIs in people longitudinally to follow our treated group?”

**More studies linking TRT to cardiovascular disease [1:36:55]**

**2010 study:** [Basaria et al., 2010](https://www.nejm.org/doi/full/10.1056/nejmoa1000485)

- A prospective randomized trial designed to investigate whether T gel provided greater muscular and functional benefits than placebo in a population of frail elderly men treated for 6 months.
- The study did indeed find a benefit of T treatment over placebo for muscular and functional responses but was terminated early because of the observation of increased adverse events categorized as “cardiovascular” in the treatment arm. [[Morgentaler et al., 2015](https://www.dropbox.com/s/9xj6sqyc0m4q0oe/%23morgentaler%20%232015%20Testosterone%20Therapy%20and%20Cardiovascular%20Risk-%20Advances%20and%20Controversies.pdf?dl=0)]
- This study wasn’t designed to look at cardiovascular events as the primary outcome

*Early termination of the study:*

- But the study was actually **terminated early** because of the observation of increased adverse events, categorized as cardiovascular in the treatment arm
- There were 23 of these events in the T arm and 5 in the placebo arm
- On the surface, terminating the study seems reasonable even though you’re seeing a benefit in the treatment group on your primary outcome, every study still has to consider safety its highest priority
- However…Most of the reported events were incidentally noted, subjective, or of questionable clinical importance, such as palpitations, pedal edema, and premature ventricular contractions.
- None of these adverse events were defined before study enrollment, and there was no attempt to systematically investigate all participants for the presence of any of these events. [Morgentaler et al., 2015]
- More about these types of events:
  - pre-ventricular contraction, so PVCs, are very common. They usually result from magnesium insufficiency. So you can usually just give somebody magnesium and those will go away. It’d be very hard to categorize that as a cardiovascular event
  - pedal edema is edema, so fluid retention, in the feet. Again in elderly frail men, that would not really be considered much of a surprise
- the big issue here is that there were four “real” events in this study
  - So of the 23 events in the testosterone treatment group, there was one death, there were two MIs, and there was one stroke
    - That is not uncommon in a clinical trial that’s so small
- What was the FDA’s response to that?
  - at the outset of this study, that there appeared to be an association between testosterone and cardiovascular risk, but they found it to be non-conclusive because of that small sample size and the small number of events reported in the study, and as well as the limitations, as a respect to confirming those events
  - They also note that the authors themselves note, explicitly indicated that the differences between the groups in cardiovascular adverse events might have been due to chance alone, which I think is true when you’re dealing with such a small sample size in a study like this

[2013 meta-analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3648456/)

- This study is the only one of several meta-analyses and systematic reviews to suggest any increased risk with T therapy.
- This analysis that did not include the 2014 study, but it did include 27 placebo-controlled studies of 12-weeks duration
- Two of these studies accounted for a third of the events, one which being the [2010 study](https://www.nejm.org/doi/full/10.1056/nejmoa1000485) just discussed above and the other being the [Copenhagen study from 1986](https://pubmed.ncbi.nlm.nih.gov/2875927/)
- So the **disproportionate influence of these 2 studies on the outcome of the meta-analysis merits closer scrutiny**.
- Notes about the Copenhagen study from 1986:
  - This was a weird study because they used an oral formulation of micronized testosterone given at a very high dose to men with liver cirrhosis. It resulted in men having testosterone concentrations of 4,000 nanograms per deciliter
  - I’ve never actually seen a level that high clinically, says Peter
  - Basically they them effectively hepatotoxic micronized testosterone to men with cirrhosis of the liver at a dose that took them as high as 21,000 nanograms per deciliter
- So basically two of the main studies that make up with meta-analysis were critically flawed
- Without the contributions of the Copenhagen study and the non-MACE in the study by Basaria et al, **the rates of adverse CV events in the T and placebo groups were similar, with a slightly lower rate in the T group** (78 events in 1599 men [4.88%] vs 60 events in 1174 men [5.1%], respectively). [Morgentaler et al., 2015]

**Subsequent petition for a warning on testosterone**

- Public Citizen, a non-profit, [petitioned](https://www.citizen.org/news/public-citizen-petitions-fda-for-a-black-box-warning-on-testosterone-products/) the FDA for a black box warning on testosterone, and petitioned the FDA to send dear doctor letters to physicians to basically warn them of this risk
- The FDA denied that petition, however, the FDA later on did issue a safety announcement, so that was in March of 2015, requiring a label change on testosterone products, warning of “***possible increased risk of heart attack and stroke with use***.” And they say based on the available evidence from published studies and expert input.

## Two flawed studies that shaped perceptions of risks associated with TRT [1:44:15]

[**2018 meta-analysis of RCTs**](https://pubmed.ncbi.nlm.nih.gov/29803351/)

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-28.-ama28-1024x894.png)

**Figure 28. Panel A. Odds ratio for major adverse cardiovascular events (MACE) in subjects treated with TRT or placebo in RCTs.** ([Corona et al., 2018](https://pubmed.ncbi.nlm.nih.gov/29803351/))

- You can see the unity risk line is the vertical line that sits at the one
- what you’re looking at is all of these studies with their respective hazard ratios
- anything that is to the left of one suggests that it improves the risk of cardiovascular disease
- Anything that is to the right of one suggests it makes things worse
- aggregate is an odds ratio of 0.97, which would imply a 3% reduction in major adverse cardiac events
- But of course, this is not remotely statistically significant. The P value is 0.88, and the confidence interval straddles one perfectly, 0.64 to 1.46
- that would suggest that there is no harm and no benefit to cardiovascular events with respect to testosterone replacement therapy
- But in all honesty, meta-anlyses aren’t always your best producer of truth
- Peter uses the quote, “a thousand sow’s ears makes not a pearl necklace” (attributed to James Yang)
- In this case, most of these studies were not powered to detect anything in terms of cardiovascular events
- Bob says, “You take a bunch of studies that are kind of inadequate and then you lump them all together and then you get a result and it shows no difference, but I would just caution that that’s one of the inherent challenges with all this, is that we’re still waiting for a trial to really be adequately powered to answer these questions much more reliably.”

In summary: you have basically all of the randomized controlled trials that try to examine this question, but it’s a bit odd in that these studies are all small and so underpowered that we can’t draw any conclusion one way or the other

**The meta-analysis paper also looked at some observational studies**:

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-29.-ama28-1024x730.png)

**Figure 29. Odds ratio for mortality, aggregate CV events, AMI, and CE events in TTh vs those not treated or healthy.** ([Corona et al., 2018](https://pubmed.ncbi.nlm.nih.gov/29803351/))

- In the case of observational studies vs RCT, we trade one good thing for one bad thing and one bad thing for one good thing — we give up randomization, but in exchange for that, we get large, large sample size
- hence, the tight error bars and lll but five of these are statistically significant
- the trend here is pretty clear
  - There does not appear to be, in the observational studies, any increase in mortality, in cardiovascular mortality
- This really does beg for a large, well done randomized controlled trial because this is not unlike what we saw with HRT in women, where the epidemiology was all very favorable. And then the large randomized control trial initially was interpreted as not being favorable of course, because it was sort of misunderstood and reported incorrectly
  - Good news is there is a trial in the works: TRAVERSE trial

Trial in the works: [TRAVERSE trial](https://www.clinicaltrials.gov/ct2/show/NCT03518034)

- five-year trial and 6,000 participants
- using AndroGel for this trial (not ideal, but at least the advantage is they’re using daily administration and they’re not going to get ridiculously super physiologic)
- primary endpoint is Major adverse cardiovascular events (MACE)

[**2016 study**](https://pubmed.ncbi.nlm.nih.gov/27165609/) **[1:49:45]**

[Wallis et al., 2016](https://pubmed.ncbi.nlm.nih.gov/27165609/)

- A 2016 observational study (Wallis et al. 2016) [same as study above in the ACM section] followed more than 10,000 men treated with TRT and 28,000+ controls for approximately 5 years, and found that a cardiovascular event had occurred in:
  - 5% of control subjects and
  - 6% of TRT subjects.
- But *what can we say about that over time?*
- What was unique was the way that they parsed these subjects out by time.
- They did them by duration of treatment
  - first tertile is less than four months of exposure
  - middle tertile was four months to 1.4 years
  - third tertile was men treated beyond 1.4 years

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-30.-ama28-1024x345.png)

**Figure 30. Crude events, stratified by treatment group (left); Results of survival model assessing effect of TRT on the primary and secondary outcomes (right).** [[Wallis et al., 2016](https://pubmed.ncbi.nlm.nih.gov/27165609/)]

*Overall mortality:*

- if you’re looking at the figure on the right, keep in mind, the hazard ratio is numbers greater than one mean an increase in risk, number is less than one mean a reduction in risk
- In the first tertile: overall mortality went up 11%. That was statistically significant
- In the second tertile, so men that are exposed for up to 1.4 years: overall mortality went down by 10%, also statistically significant
- In the third tertile, the long exposure group taking it for more than 1.4 years: A risk reduction by 33%, and that was very significant when you look at that confidence interval

*When you look at cardiovascular events (which includes cardiovascular mortality, but includes heart attacks and strokes as well):*

- You saw a statistically significant increase in events by 26% in four months
- Tertile 2 it is an increase of 16%, on the cusp of statistical significance at 1.4 years
- and a reduction of 16% over the long haul

*Prostate cancer:*

- in the first tertile, there was no increase in the risk of prostate cancer
- In the second tertile, there was no change in the risk of prostate cancer
- but in the third tertile, which means the long exposure group, there was a 40% reduction in the risk of prostate cancer

**Peter and Bob’s thoughts:**

- There’s an interesting limitation of this study that makes it really hard to draw much of a conclusion from it, says Peter

*Healthy user bias?*

- Even the authors noted that there is a possibility of a healthy user bias involved here — where the people that are going on testosterone replacement, when they’re going on the testosterone replacement, likely their healthcare provider or their doctor might screen them for prostate cancer.
- And so they may make sure that they they’re not at any increased baseline risk for prostate cancer.
- And so you would have that testosterone group, there’d be a bias there, where this testosterone groups getting screened for prostate cancer and the matched controls, presumably that’s not going on
- That could be an issue here where there may not necessarily be an increased or decreased risk with prostate cancer, but it might be that the testosterone group is healthier compared to there might be some mix of people in the control group, which might put them at a disadvantage at baseline

*Peter’s take:*

- *Is it possible that we’re seeing an accelerated stance on disease in the most vulnerable people, and they’re the people that are basically having their events right away?*

- So yeah, there’s a bias to who gets on treatment
- For example, if you’re right at the edge of having an MI and you go on treatment, you’re going to have it.
- But the longer you go without an event, the healthier you are, and therefore, the more likely you are to not have an event in subsequent time periods.
- The other thing to remember here is that these buckets are not linear for time, they’re linear for people
- That first bucket of under four months — “that’s an astonishingly quick timeframe”
- And if there is some risk, it does require some thought around how you would monitor patients if you are in fact worried about risk
- I.e., What factors would you look at? And are there certain patients that you would say under no circumstance, would you give them testosterone?

> “*At the end of the day, this still all says to me, we need large random controlled trials to answer this question*.” —Peter Attia

## The controversy over TRT and prostate cancer [1:56:45]

took one look at it here in this [retrospective analysis](https://pubmed.ncbi.nlm.nih.gov/27165609/), which was, it did not appear to be the case at any tertile

then in the third tertile, the long exposure group, there was a 40% reduction in risk

[**Study**](https://pubmed.ncbi.nlm.nih.gov/26772440/) **looking at TRT and overall cancer death risk**

- They took 4,000 men on TRT and they looked at was **overall cancer death risk**
- The groups of men were divided up
- There were low T levels, intermediate T, and high T
- 18% of the low T got TRT, and all of the intermediate T and high T were treated with TRT to get to those levels
- They found that it was reduced by 33% in men with intermediate testosterone levels versus lower levels and in this case, that’s 212 to 742 nanograms per deciliter
- the people who were treated and got to a high level had the 67% improvement in risk reduction compared to the lows,
- So 1.8% absolute risk of cancer death in the low testosterone treatment group versus 0.9% in the intermediate and 0.4 in the high

*Peter’s reaction to these results*:

- A lot of reasons why these could have been the results (other than the TRT)
- For example,
- the people seeking testosterone therapy probably have better access to healthcare
- probably have greater motivation to do other things to improve their health
- “*The only conclusion I think you could draw here is the contrapositive, which is it doesn’t appear to be increasing the risk of cancer. . .it’d be hard to make the case that testosterone therapy is reducing the risk of cancer*.” says Peter

**Systematic reviews**

- A [2004 study](https://www.nejm.org/doi/10.1056/NEJMra022251?url_ver=Z39.88-2003&rfr_id=ori%3Arid%3Acrossref.org&rfr_dat=cr_pub++0pubmed) compiled the published prospective studies and discovered five cases of prostate cancer among 461 men (1.1%) on TRT when followed for 6-36 months, a prevalence rate similar to the general population.
- Similarly, a [2009 systematic review](https://www.nature.com/articles/ijir200831?proof=t) in 11 randomized placebo-controlled studies found 7 of 543 (1.3%) men in the treatment group developed prostate cancer, compared to 5 of 333 (1.5%) in the control group
- Does that mean  that testosterone replacement therapy reduces the risk for prostate cancer? — “*I’m not so sure, but we’re looking at seven men in the treatment group and we’re looking at five in the control group*.”
- *“I don’t think you can draw much of a conclusion from this*” says Peter “*this is not a hard study to do. The estimate is you need 6,000 men in a TRT study for five years to get an answer to this question definitively.*”

> “*It seems to be the case that testosterone replacement doesn’t seem to increase the risk of prostate cancer, but the definitive study to demonstrate that is not yet done*.” —Peter Attia

## Other potential risks with testosterone replacement therapy [2:02:15]

[**2004 NEJM paper**](https://www.nejm.org/doi/10.1056/NEJMra022251?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed) **that summarized all the work to date**

![](https://peterattiamd.com/wp-content/uploads/2021/10/fig-31.-ama28-1024x987.png)

**Figure 31. Potential risks associated with TRT.** [[Rhoden and Morgentaler, 2004](https://www.nejm.org/doi/10.1056/NEJMra022251?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed)]

- Cardiovascular disease – existing data suggests either neutral or a possible benefit
- Lipid alterations – most studies show no change with a physiologic replacement dose—meaning taking people to the normal ranges, but not these super normal ranges
- Erythrocytosis – this would be one of the things that we have to pay most attention to in patients who are receiving testosterone replacement therapy
- Fluid retention – “we just don’t see this in our practice because when we are replacing testosterone it’s to what we would call physiologic levels”
- Same as above with BPH and DHT levels
- Prostate cancer (this is from 2004) –
  - “Since that time, most urologists that I’ve spoken with are more optimistic that there is no relationship between prostate cancer and testosterone replacement therapy…which of course is still very counterintuitive when you consider the role of androgen deprivation in the treatment of prostate cancer for men who are not surgical candidates”
  - So there is still an opportunity to sort of observe that in men who are non-surgical candidates for prostate cancer, who undergo chemical castration, we have to wait at least five years before we would consider replacing testosterone in those patients
- Liver toxicity – limited to the oral agents so kind of an irrelevant point
- Sleep apnea – very infrequent
- Gynecomastia – probably more a side effect of the estradiol increase, which is easily treatable with medication that blocks the conversion of testosterone to estradiol, which is called anastrozol
- Skin reactions – seen only with a patch, but otherwise pretty much unheard of
- Acne and oily skin – probably is something that we see only in people who are using super-physiologic doses
- Testicular atrophy and infertility – very common if treatment goes uninterrupted for about two years so if a person is concerned with testicular atrophy and fertility, they really should not be on uninterrupted testosterone replacement therapy for more than two years

§

## Selected Links / Related Material

**Episode of The Drive about the myths around hormone replacement therapy for perimenopausal and post-menopausal women**: [#42 – Avrum Bluming, M.D. and Carol Tavris, Ph.D.: Controversial topic affecting all women—the role of hormone replacement therapy through menopause and beyond—the compelling case for long-term HRT and dispelling the myth that it causes breast cancer](https://peterattiamd.com/caroltavris-avrumbluming/) | Peter Attia (peterattiamd.com) [4:00]

**An elegant which sought to identify if the benefits of testosterone replacement therapy were more mediated by testosterone or DHT**: [Exogenous Testosterone or Testosterone with Finasteride Increases Bone Mineral Density in Older Men with Low Serum Testosterone (Amory et al., 2004)](https://academic.oup.com/jcem/article/89/2/503/2840744) [32:15]

**Episode of The Drive discussing strategies for reversing hair loss**: [#43 – Alan Bauman, M.D.: The science of male and female hair restoration – how to protect, enhance, and restore the appearance and health of the hair and scalp](https://peterattiamd.com/alanbauman/) | Peter Attia (peterattiamd.com) [35:00]

**TRT study looking at changes in body composition in older men with low T who got treatment**: [Exogenous Testosterone (T) Alone or with Finasteride Increases Physical Performance, Grip Strength, and Lean Body Mass in Older Men with Low Serum T](https://academic.oup.com/jcem/article/90/3/1502/2836784) (Page et al., 2005) [45:30]

**TRT study showing the benefits of TRT on bone mineral density**: [Effect of Testosterone Treatment on Volumetric Bone Density and Strength in Older Men With Low Testosterone](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2604138) (Snyder et al., 2017) [48:15]

**AMA episode of The Drive discussing sarcopenia**: [#176 – AMA #27: The importance of muscle mass, strength, and cardiorespiratory fitness for longevity](https://peterattiamd.com/ama27/)  | Peter Attia (peterattiamd.com) [51:30]

**2014 meta-analysis looking at the metabolic effects of TRT**: [Metabolic effects of testosterone replacement therapy on hypogonadal men with type 2 diabetes mellitus: A systematic review and meta-analysis of randomized controlled trials](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3901874/) (Cai et al., 2014) [53:00]

**2021 TRT studying investigating testosterone replacement therapy for prevention or reversal of type 2 diabetes**: [Testosterone treatment to prevent or revert type 2 diabetes in men enrolled in a lifestyle programme (T4DM): a randomised, double-blind, placebo-controlled, 2-year, phase 3b trial](https://pubmed.ncbi.nlm.nih.gov/33338415/)  (Wittert et al., 2021) [59:30]

**The Diabetes Prevention Program**: [National Diabetes Prevention Program](https://www.cdc.gov/diabetes/prevention/index.html) | (cdc.gov) [1:04:45]

**TRT study comparing results from continuous vs. interrupted treatment**: [Effects of intermission and resumption of long-term testosterone replacement therapy on body weight and metabolic parameters in hypogonadal in middle-aged and elderly men](https://pubmed.ncbi.nlm.nih.gov/26331709/) (Yassin et al., 2016) [1:07:15]

**Studies linking TRT to cardiovascular disease—2013 study that was part of the reason TRT became linked with cardiovascular disease**: [Association of Testosterone Therapy With Mortality, Myocardial Infarction, and Stroke in Men With Low Testosterone Levels](https://jamanetwork.com/journals/jama/fullarticle/1764051) (Vigen et al., 2013) [1:23:30]

**Studies linking TRT to cardiovascular disease—2014 study that was part of the reason TRT became linked with cardiovascular disease**: [Increased Risk of Non-Fatal Myocardial Infarction Following Testosterone Therapy Prescription in Men](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3905977/) (Finkle et al., 2014) [1:23:30, 1:32:45]

- Subsequent analysis from that noted that the observed MI rate in the men who received testosterone was about one-third the expected rate: [Testosterone Therapy and Cardiovascular Risk: Advances and Controversies](https://www.dropbox.com/s/9xj6sqyc0m4q0oe/%23morgentaler%20%232015%20Testosterone%20Therapy%20and%20Cardiovascular%20Risk-%20Advances%20and%20Controversies.pdf?dl=0) (Morgentaler et al., 2015)

**The Endocrine Society issued a statement in February 2014 cautioning against the use of T therapy in older men and in men with a history of CAD**: [Endocrine Society Calls for Large-Scale Studies to Evaluate Testosterone Therapy Risks](https://www.endocrine.org/news-and-advocacy/news-room/2014/endocrine-society-calls-for-large-scale-studies-to-evaluate-testosterone-therapy-risks) | (endocrine.org)  [1:23:45]

**FDA announced plans in 2014 to review the cardiovascular safety of testosterone products**: [FDA Drug Safety Communication: FDA cautions about using testosterone products for low testosterone due to aging; requires labeling change to inform of possible increased risk of heart attack and stroke with use](https://www.fda.gov/media/91048/download) | (fda.gov) [1:24:00]

**Another paper linking TRT to cardiovascular disease that was originally designed to investigate whether T gel provided greater muscular and functional benefits than placebo in a population of frail elderly men**: [Adverse Events Associated with Testosterone Administration](https://www.nejm.org/doi/full/10.1056/nejmoa1000485) (Basaria et al., 2010) [1:37:00]

**The meta-analysis that was brought to the FDA linking cardiovascular disease to TRT**: [Testosterone therapy and cardiovascular events among men: a systematic review and meta-analysis of placebo-controlled randomized trials](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3648456/) (Xu et al., 2013) [1:40:45]

**Copenhagen study from 1986**: [Testosterone treatment of men with alcoholic cirrhosis: a double-blind study. The Copenhagen Study Group for Liver Diseases](https://pubmed.ncbi.nlm.nih.gov/2875927/) [1:41:15]

**Public Citizen, a non-profit, petitioned the FDA for a black box warning on testosterone**: [Public Citizen Petitions FDA for a Black Box Warning on Testosterone Products](https://www.citizen.org/news/public-citizen-petitions-fda-for-a-black-box-warning-on-testosterone-products/) | *Feb 25, 2014* (citizen.org) [1:43:00]

**2018 meta-analysis of RCTs that shaped perceptions of risks associated with TRT**: [Testosterone and Cardiovascular Risk: Meta-Analysis of Interventional Studies](https://pubmed.ncbi.nlm.nih.gov/29803351/) (Corona et al., 2018) [1:44:15]

**A trial being put together to better answer the risks of cardiovascular events with TRT**: [A Study to Evaluate the Effect of Testosterone Replacement Therapy (TRT) on the Incidence of Major Adverse Cardiovascular Events (MACE) and Efficacy Measures in Hypogonadal Men (TRAVERSE)](https://www.clinicaltrials.gov/ct2/show/NCT03518034) (clinicaltrials.gov) [1:49:15]

**2016 observational study that contributed to the perceived risks of TRT**: [Survival and cardiovascular events in men treated with testosterone replacement therapy: an intention-to-treat observational cohort study](https://pubmed.ncbi.nlm.nih.gov/27165609/) (Wallis et al., 2016) [1:49:30]

**Study looking at TRT and overall cancer death risk**: [Impact of Testosterone Replacement Therapy on Myocardial Infarction, Stroke, and Death in Men With Low Testosterone Concentrations in an Integrated Health Care System](https://pubmed.ncbi.nlm.nih.gov/26772440/) (Anderson et al., 2016) [1:57:15]

**Systematic review looking at TRT and prostate cancer**: [Testosterone therapy in hypogonadal men and potential prostate cancer risk: a systematic review](https://www.nature.com/articles/ijir200831?proof=t) (Shabsigh et al., 2008) [2:00:00]

**A 2004 NEJM paper that summarized all the work to date regarding risks involved with TRT**: [Risks of Testosterone-Replacement Therapy and Recommendations for Monitoring](https://www.nejm.org/doi/10.1056/NEJMra022251?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed) (Rhoden et al., 2004) [2:02:00]

§

## People Mentioned

- [Arnold Schwarzenegger](https://en.wikipedia.org/wiki/Arnold_Schwarzenegger) [30:15]
- [Frank Zane](https://en.wikipedia.org/wiki/Frank_Zane) [30:15]
- [Dorian Yates](https://en.wikipedia.org/wiki/Dorian_Yates) [30:15]
- [Ronnie Coleman](https://en.wikipedia.org/wiki/Ronnie_Coleman) [30:15]
- [Ralph Nader](https://en.wikipedia.org/wiki/Ralph_Nader) [1:43:00]
- [James Yang](https://ccr.cancer.gov/staff-directory/james-c-yang) [1:46:00]

§