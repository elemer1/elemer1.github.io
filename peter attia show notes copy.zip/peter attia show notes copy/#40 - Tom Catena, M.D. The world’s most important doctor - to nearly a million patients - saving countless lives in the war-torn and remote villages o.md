# #40 – Tom Catena, M.D.: The world’s most important doctor – to nearly a million patients – saving countless lives in the war-torn and remote villages of Sudan

**Source:** [https://peterattiamd.com/tomcatena/](https://peterattiamd.com/tomcatena/)

---

To support Tom’s mission and work, please visit: <https://africanmissionhealthcare.org/donation/catena/>.

In this episode, Tom Catena, a missionary physician who runs Mother of Mercy Hospital in the Nuba Mountains in Sudan, describes some of his extraordinary work as the only doctor in a remote, war-torn region of Africa. In terms of individual lives saved, you could argue that there is no other person on the front lines doing more than Tom. Additionally, we explore the manner in which the Nuba people die, which is in striking contrast to the ubiquity of chronic disease and self-harm in the west, despite the extreme poverty and unimaginable suffering experienced by the Nuba people. Lastly, we discuss the lessons to be gleaned from the Nuba people, who despite their suffering, live so harmoniously, happily, and resiliently.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/tomcatena/the_Drive_public.png)

Play

#40 - Tom Catena, M.D.: The world's most important doctor – to nearly a million patients – saving countless lives in the war-torn and remote villages of Sudan

#40 - Tom Catena, M.D.: The world's most important doctor – to nearly a million patients – saving countless lives in the war-torn and remote villages of Sudan

1x15s30s

0:002:41:46

## We discuss:

- Background, medical training, and early days of missionary work in Africa [5:15];
- Tom arrives at Mother of Mercy Hospital in the Nuba Mountains of Sudan, civil war breaks out, and his staff evacuates [12:30];
- Learning surgery on the job and earning the trust of the community [37:00];
- The amazing people of Nuba, and why Nuba feels like home to Tom [47:45];
- NY Times article about Tom’s work, and Tom’s new venture on the board of the Aurora Prize Foundation, raising awareness and funds for other missionaries [59:45];
- Tom’s mind-blowing ability to deal with chaos while seeing hundreds of patients per day [1:12:00];
- The most afraid Tom has ever been, and how he copes with the emotional trauma of his daily experiences [1:19:45];
- The basic tools, technologies, and medicines that Tom is lacking that could save many lives [1:30:00];
- The logistical challenge of helping Tom’s hospital, and what Tom really needs [1:35:15];
- Diseases in the adult population [1:38:30];
- Living without possessions, finding meaning, and being a missionary [1:55:45];
- Happiness, sense of purpose, and suicide: contrasting the US with Nuba [2:07:15];
- Other than donations, is there a way people can help Tom and other similar causes? [2:15:15];
- The food in Nuba [2:18:30];
- Tom’s annual bout of malaria [2:23:45];
- Patients Tom will never forget [2:26:00];
- Resources for people wanting to get involved in helping Tom’s work [2:31:00];
- Peter tells a story that defines Tom [2:32:00]; and
- More.

§

## How you can directly support Tom’s work and change the lives of his patients:

You can directly support the needs of the Mother of Mercy Hospital by going to: <https://africanmissionhealthcare.org/donation/catena/>. The following are some of the most urgent needs:

### **Operating eye microscope and associated supplies**

- Funds needed = $40,000
- These funds would be enough for ~600 eye operations

### **Housing**

- Funds needed = $100,000
- Mother of Mercy hospital operates at 100% capacity at all times
- These funds would allow the hospital to build 2 additional much-needed units

### **Batteries for solar panels**

- Funds needed = $15,000
- Mother of Mercy hospital runs on 100% solar power and needs battery replacements every so often to keep everything running without interruption

### **Pay for a C-section**

- Each C-section costs roughly $250
- Childbirth mortality is a major problem in Nuba, and your donation could save the life of the mother and/or child

§

## Show Notes

## Background, medical training, and early days of missionary work in Africa [5:15]

- Grew up in Amsterdam, New York
- Majored in mechanical engineering while at Brown University, (also played football at Brown)
- While at Brown, decided he wanted to do missionary it but need to get a degree in medicine
- Med school at Duke on scholarship from the Navy
- 5 years serving Navy
- Residency at family practice in Indiana
- Then left for Kenya

**Kenya**

- Got there January 17, 2000
- Teamed up with [Catholic Medical Mission Board](https://en.wikipedia.org/wiki/CMMB_(Catholic_Medical_Mission_Board))
- Worked at Our Lady of Lourdes Mutomo Hospital in the rural settlement of Mutomo, Kenya
- Was supposed to stay one year and then come back, but fell in love with the place

*What was it like?*

- Had to learn surgery, obstetrics, C-sections to be of more help
- Volume of patients was crazy
  - Was seeing 50-60 patients per day
  - In residency in US it was 5 or 6
- Variety of diseases
  - [Malaria](https://en.wikipedia.org/wiki/Malaria), [tuberculosis](https://en.wikipedia.org/wiki/Tuberculosis), [leishmaniasis](https://www.who.int/news-room/fact-sheets/detail/leishmaniasis)
  - “all this kind of stuff I had no idea about”

**Deciding to go to Sudan**

> “The modus operandi of my life was always looking for. . .the opposite of greener pastures. I’m looking for browner pastures.”

- Stayed in Mutomo, Kenya for 2.5 years
- Then went to Turkana, Kenya and worked at the [Kakuma Mission Hospital](https://www.electives.net/hospital/6916/preview)
- While in Turkana, he learned about the harsh conditions of Sudan, which intrigued him…

*“The conditions there were terrible. . .such a lack of any kind of health services. I thought, “Man, I’d really like to get involved in that struggle, just to go and work with and help the people there’. The health facilities were so limited. I thought, ‘That’s kind of the place I want to go to.’”*

- He then moved to St Mary’s Mission Hospital in Nairobi, Kenya
- There he worked with the Bishop of the El Obeid Diocese, Macram Gassis to plan out the Sudan hospital in the [Nuba Mountains](https://en.wikipedia.org/wiki/Nuba_Mountains) (where Tom is today)
- Planning took 6 years
- It was all funded by Catholic Diocese of El Obeid who raised funds through the church mechanism
- **Tom arrives in the Nuba Mountains on March 10, 2008**

## Tom arrives at Mother of Mercy Hospital in the Nuba Mountains of Sudan, civil war breaks out, and his staff evacuates [12:30]

**Some history of Nuba**

![](https://peterattiamd.com/wp-content/uploads/2019/02/nuba-mountains-map.jpg)

**Figure 1. Map showing location of Nuba Mountains within Sudan.** Image credit: [pbs.org](https://www-tc.pbs.org/prod-media/newshour/photos/2011/11/18/Sudan-SK-BN2_blog_main_horizontal.JPG)

- One of the most remote places in the world
- On the border between North Sudan and South Sudan
- People have a unique culture different than the majority of Sudan

**The religious conflict of Sudan**

- North Sudan is muslim
- South Sudan is christian
- This difference was a big reason for the fighting
- Nuba Mountain region (more or less in the middle) is split Muslim/Christian, yet they live in harmony with each other
- Tom’s wife, Nasima Mohammed Bashir, is Nuba

**The history of war within Sudan**

- Civil war going on for decades between north and south Sudan
- [Omar al-Bashir](https://en.wikipedia.org/wiki/Omar_al-Bashir) took power in 1989
- North issued jihad against Nuba in the early 90s even though many of them are muslim but since they lived in harmony with christians they were not “true” muslim
- This lead to a lot of genocide (led by [Hassan Al-Turabi](https://en.wikipedia.org/wiki/Hassan_Al-Turabi))
- Peace agreement signed in 2005
- Tom arrived in March 2008
- In 2011, the South voted to officially secede from the North
- But Nuba was not included in south
- It was separate but North wanted Nuba under their control
- There was a sham election and al-Bashir’s candidate wins election
- Civil war breaks out in Nuba against the government in June 2011

**Civil war breaks out**

*Before war*

- Tom was there March 2008-June 2011 before the war broke out
- During that time, the hospital staff included:
  - 8 expats from Kenya and Uganda
    - Tom was the only doctor
    - A few nurses
    - Anesthetists
    - Lab person
  - Plus 15 local staff from Nuba who had to be taught literally everything

*Fighting starts*

- Fighting begins in June 2011 after Southern Sudan votes to secede
- The war is between the North Sudan government and the people of Nuba which consisting of local tribes of Nuba plus some leftover South Sudan soldiers who still live in Nuba
- This “new” military fighting against North Sudan was referred to as SPLA North (the South Sudan soldiers are simply “[SPLA](https://en.wikipedia.org/wiki/Sudan_People%27s_Liberation_Army)”)

**The staff evacuates**

- A plane came, last plane for a long time, and staff had to decide whether to leave or stay
- Had to secretly bring in plane bc N sudan would bomb them if saw them
- Tom stayed
- All other expats left
- So now just Tom and local Nuba people

*Did Tom consider leaving?*

- He was encouraged to leave
- But there were no other hospitals with surgical capability… if somebody needed a C-section, or something more serious, they would just die
- “For me, it was a very easy decision. There’s no way I can in good conscience leave this place, and go out. It was a very, very stark reality. And to be honest with you, it was not a difficult decision.”
- “Let’s just stick it out, we’re here as missionaries, let’s do what we’re supposed to do and take care of the people as best we can. And come what may. We have faith in God. We’ll see what happens.”
- That said, he does not hold it against the others that left

*After the staff left:*

- Biggest problem was anesthesiology for surgery
- The morning that the staff left, there was a bombing by the North Sudan’s air force
- You can hear the sounds of the [Antonov planes](https://en.wikipedia.org/wiki/Antonov_An-24) in the film [Heart of Nuba](https://theheartofnuba.com/)
- Mangled bodies start rolling in
- Huge shards of metal tore through people creating massive tissue loss and trauma

**Girl needing arm amputated**

- First case after staff evacuated
- Girl came in needing her arm amputated
- Neither Tom, nor the nurses knew how to do general anesthesia
- They literally read a basic anesthesia book that listed it out step by step
- Tom had to intubate the patient, which can kill them if done wrong, something Tom had never done before
- By the grace of God, got the patient intubated
- Then someone had to manually ventilate the patient throughout the entire surgery
- All they had was an Oxford Miniature Ventilator

*Peter is flabbergasted and goes on a brief rant*

- They were without an anesthetist for 2 months
- Tom can’t measure blood gasses (PaO2, PaCO2)
- He also had no [pulse oximeter](https://en.wikipedia.org/wiki/Pulse_oximetry) which measures the percentage of oxygen saturation
- This means the nurse has to figure out how to ventilate, which means how much oxygen the person needs and how much CO2 you take off… and if you screw either of those two up, you will kill someone
- Peter then says if you were to put him in the same spot and said… “All you have to do is be the guy that manually ventilates them… I wouldn’t be able to do that. I would overdo it or under do it. There’s no way you’d hit that sweet spot.”

[**Intussusception**](https://www.google.com/search?q=intussusception&oq=Intussusception&aqs=chrome.0.0l6.222j0j7&sourceid=chrome&ie=UTF-8) **in a baby**

- Nine month old baby
- intussusception is when the intestine telescopes on itself and basically causes a blockage of the intestine
- The longer you delay, that intestine can die and the person will die from infection
- “We made the diagnosis and I’m just like, ‘Oh God, what are we supposed to do with this kid?’”
- But managed to get baby intubated
- Did a bowel resection
- And now he’s nine years old, “he’s cruising”

*What other kinds of injuries occur when shrapnel is going through people?*

- Liver lacerations, bowel injuries, hemopneumothorax, head trauma, kidney trauma, etc.
- *Why do you have so many extremity traumas?* ⇒ “Because they’re the ones who actually survive”
- One guy has 23 holes in his intestines that “we had to resect here, resect there, stitch this one… just took forever”

![](https://peterattiamd.com/wp-content/uploads/2019/02/amputation-1024x673.png)

**Figure 2. Victim of the cowardly and vicious bombing by the North Sudan dictatorship.** Image credit: [Youtube: The Heart of Nuba – 15 minute supercut](https://www.youtube.com/watch?v=fwDjCNuHiWs&t=827s)

**The Nuba people are tough as nails**

- Hospital is six hours away
- People walk for days with holes in their stomach, mangled limbs, etc.
- But they would make it and pull through

> “These people are just tough as nails”

## Learning surgery on the job and earning the trust of the community [37:00]

[![](https://peterattiamd.com/wp-content/uploads/2019/02/heart-of-nuba-1024x535.jpg)](https://theheartofnuba.com/)

**Figure 3. Heart of Nuba film cover.** Image credit: [@theheartofnuba](https://twitter.com/theheartofnuba)

- Trained for internal medicine in a family practice so he had minimal surgical training
- But when got to Kenya, he saw it as a necessity to learn, “I realized a lot of the disease burden in Africa was surgically related.”
- A ton of wound care, miscarriages, laparotomies, amputations
- Like another residency learning from other doctors in Kenya

Mentors

- American missionary doctor there named [Mike Johnson](https://thosepeculiarjohnsons.org/about/)
- Kenyan surgeon, Dr. Ritu (sp?)

Making a ton of mistakes?

- Peter says… It’s the nature of medicine to make some mistakes even at the best hospitals with the best tools
- But Tom was missing so many of the basic tools that could act as sort of a safety net
- Fortunately, always someone looking over him for first 7+ years in Kenya
- Mostly obstetrics, orthopedics, and urology
- The trade off is the surgery in Africa is much broader, but less depth
- None of the high tech stuff (no CT scanner, for example)
- And of course, Tom follows the axiom, “First do no harm”

Building up trust

- Being a foreigner, there was definitely a trust barrier that needed to be overcome
- In the early days, it was quite scary to think you could have a bad outcome with a patient
- Now he is trusted so it is easier in that sense

Patients that Tom is unable to save

- How does Tom deal with telling families he can’t save someone?
- Nuba people have low expectations, they don’t expect miracles
- “They just want to be treated as a human, they want that human touch”
- As a people, they are very accepting of negative outcomes or bad news
- This makes sense when you consider that they are largely living “at the edge of survival all the time”
- They are also very spiritual

*How primitive was the care when he showed up?*

⇒ Local traditions include:

- Burning ⇒ to try to release fevers, malaria, and other illness, the local tradition is to burn the skin to “release” the illness (All the Nuba people have burn marks)
- Some herbal remedies for malaria (not much evidence it is working)
- Local fruits and veggies for GI problems (works a little bit per Tom)
- [Local shamans](https://www.jstor.org/stable/41716442?seq=1#page_scan_tab_contents)⇒ Known as the “Kujur”, the shamans will visit the family and come up with a reason why a child may be sick (this unfortunately delays the time until they will see a real doctor)

## The amazing people of Nuba, and why Nuba feels like home to Tom [47:45]

*How big is Nuba?* Roughly 750,000 people being served by Tom’s single hospital (physical area around size of Austria)

How much knowledge do the Nuba people have outside of their small world?

- Very little
- Example, Tom’s wife’s mother has lived entire life in her tribe in Nuba Mountains
- She has never heard of the United States, thought Tom was from Kenya
- No concept of an ocean
- She didn’t even know she was in Africa

> “A lot of my wife’s siblings have never been out of this 15 square mile radius. You can’t imagine the worldview.”

**Tom’s wife first time outside Africa**

- Shortly after getting married, they went to Armenia which was her first time outside rural Africa
- Next went to Dubai, airport was crazy, so much electricity
- Never seen flushing toilets, elevators, etc.
- First time to the US…
- Went to New York, Time Square
- Went to Boston (North Shore) ⇒ first time to see ocean
- “My family just went crazy with her. They had so much fun being with her, seeing all these things for the first time through her eyes. She has an infectious joy to her and they really kind of tapped into that.”
- While in the US, [Tom’s wife accepted an award on behalf of Tom giving to him by Medicines for Humanity](https://medicinesforhumanity.org/events/annualdinner/)

**Peter’s moving encounter with the Sudanese people**

- Peter took the whole family to the Sudanese Community Center in San Diego to deliver Christmas gifts
- Basically all refugees there
- Peter’s youngest child (1.5 years) was playing with a similar-aged Sudanese child
- There’s a woman that’s holding the Sudanese girl and she was sort of keeping an eye on Peter’s son as well
- A few hours later they thank the young mother for watching their son, and turns out *she wasn’t even related to the Sudanese child*
- *“We couldn’t stop talking about that… talk about a different sense of community.”* says Peter

> “For as many things as they lack, they have something we don’t have.”

![](https://peterattiamd.com/wp-content/uploads/2019/02/Screen-Shot-2019-02-10-at-8.24.12-AM-1024x635.png)

**Figure 4. Tom with one of the nearly 1 million Nuba people that his hospital serves.** Image credit: [Youtube: The Heart of Nuba – 15 minute supercut](https://www.youtube.com/watch?v=fwDjCNuHiWs&t=827s)

**The amazing community of the Sudanese people**

Tom says: “You always hear about the negative side of a place like Sudan. . .war, poverty, disease, starving kids… but the positive side is not shown.”

“The concept of community, what stuff belongs to you, what does a stranger mean? … Totally different than our outlook here.”

Example,

- Tom has patients travel by foot for days to get to the hospital
- Along the way, they will just knock on the door of a stranger and that person will give them food and a place to stay

**Nuba feels like home to Tom**

Peter asks Tom how he is able to work and thrive and enjoy his environment…

> “I think everybody is kind of geared a bit differently. So, I grew up in a big family and my brothers could never be [in Nuba], but at the same time I could not do what they’re doing. . .So, I think, yeah, I’m very comfortable there, but I couldn’t maybe fit working in New York.”

**Tom says everybody has something to contribute**

“I think everybody has something to offer and if we try to get in this thinking like, ‘Gosh, I’m not doing what he’s doing, I should be doing what he’s doing.’ I think we miss the point. We miss out on our shared abilities.”

“I think it’s good to be aware of what’s going on in the world and everybody should think about their brothers and sisters elsewhere and contribute and do something to help other people. At the same time don’t spend too much time stressing that you’re not doing enough. . . do something, but it shouldn’t be something which is agonizingly painful.”

“It’s a sacrifice. It is. And I miss my family like crazy. . .but I’m pretty comfortable in that weird, remote setting in the Nuba mountains.”

## NY Times article about Tom’s work, and Tom’s new venture on the board of Aurora Prize Foundation bringing awareness and funding to other missionaries doing great work [59:45]

**Here is the NY Times article by Nicholas Kristof**: [‘He’s Jesus Christ’](https://www.nytimes.com/2015/06/28/opinion/sunday/nicholas-kristof-hes-jesus-christ.html)

**Here is the 10-min video from that article**: [The Worst Atrocity You’ve Never Heard Of: Sudan’s Nuba Mountains](https://www.youtube.com/watch?v=kG4xMTlPt6I)

*Peter’s comment on the article*: “But I think the point Kristof makes, and makes it beautifully, is if you want to be critical of all of the religious hypocrisy, by all means do so. But you can’t then fail to acknowledge the times when, in the name of religion, people are doing these incredible things.”

*How did* [*Nick Kristof*](https://en.wikipedia.org/wiki/Nicholas_Kristof) *learn about Tom?*

- Always had an interest in Sudan after seeing what al-Bashir was doing to the people
- He made a couple of trips into the Nuba mountains
- To get there…
- You can fly into [Juba](https://en.wikipedia.org/wiki/Juba)
- Then take a flight up to the refugee camp in Yida
- And then, you can manage to come into Nuba mountains
- You don’t come in with official permission of the Sudan government
- He just has an interest in that part of the world and really wanted to do something that shed light on the situation there, against Bashir
- He had been to Nuba, I think, one previous time and heard about the hospital, wanted to come see us there and see what kind of work we were doing, to see for himself, and was there for a few days. He’s a really intrepid traveler, an incredible journalist.
- “What I respect about him the most is he can disagree with you, whatever, religiously, politically not agree with your beliefs, but he could realize what you’re doing has benefit, and he can look at it objectively and say okay, I don’t believe in this religion, but I see what these guys are doing, and highlight that. Not many people are willing to do that.”
- “Certainly the Nuba Mountains are a better place because of Nicholas’s work.”

**Tom’s work with the Aurora Prize organization**

> “Aurora’s focus is on highlighting what they say is unsung heroes, but people that are kind of operating in the weeds, that nobody knows about. So shine a bit of spotlight on them, not so much for publicity, but to help them both in their work, and by raising their profile you raise the issues that they’re involved with.”

**Tom won the 2017 Aurora Prize for his work in Nuba**: [DR. TOM CATENA – 2017 AURORA PRIZE LAUREATE](https://auroraprize.com/en/aurora/detail/11531/dr-tom-catena-2017-aurora-prize-laureate)

**Here’s the video made for Tom as an Aurora Prize finalist**: [2016 Aurora Prize Finalist, Dr. Tom Catena: Courage You Would Never Expect](https://www.youtube.com/watch?v=1oLEl2sdRP4)

The Aurora Prize gives away 1 million dollars yearly to people doing humanitarian work and allows them to elect which charity that money goes towards (although it’s a finite time period of 8 years so it ends in 2023)

*Tom now* [*works with Aurora as a chairman of the organization*](https://auroraprize.com/en/aurora/detail/13800/surgeon-and-missionary-dr-tom-catena-announced-as-chair-of-aurora-humanitarian-initiative-)

⇒ “But I thought maybe using Aurora as a vehicle, it was time to come out, to kind of see what was out there, and to try to expand the model that we have in the Nuba Mountains. So to find a way to bridge the gap between big donors … and small organizations, people on the ground that are doing a lot of the grassroots work and doing it very efficiently.”

**Money goes a LONG way in Africa**

At Tom’s hospital, for example…

⇒ For 1 million dollars:

- Could see 130,000 outpatients
- do close to 2,000 operations
- 6,000 inpatients
- vaccinate tens of thousands of children
- several thousand maternity patients for that

“If someone gave us a million bucks, we could easily run the hospital for a year and probably expand quite a bit what we’re already doing.”

**Biggest problem is logistics of getting the supplies**

- The #1 challenge is logistics
- Supplies have to come from Nairobi which is 2 countries away
- First goest through Uganda, up to the border with South Sudan where they just harass the heck out of the drivers
- You’ve got to bribe the guards and they’re always changing the rules
- 30-40 checkpoints along the way
- It takes weeks to get to Yida, South Sudan
- Then its 6 hours dirt roads to get from Yida to Nuba

“We try to make it one full year on that supply that gets sent in. The problem comes. . .when it’s not in stock, and you can’t order one-off things. There’s no system to get stuff up to us. So it’s really hard. If you can’t load everything on that truck for this one go, we’re a bit stuck, and we’ve got to be really creative trying to get these other small things up.”

## Tom’s mind-blowing ability to deal with chaos while seeing hundreds of patients per day [1:12:00]

> “It’s the theater of the absurd. It’s crazy.”

**Mortality of childbirth**

- Infant mortality still very high
  - Most neonatal deaths are just from difficult deliveries (baby gets asphyxiated, baby’s born and dies, either is a stillborn, or dies soon after birth)
  - 99% of women there still deliver at home, but many of the infant deaths would have survived with a c-section
  - How many babies born at his hospital? ⇒ 400 per year, very small compared to home deliveries
- Mortality of mothers
  - Unknown
  - It’s so remote, and people are so spread out, there’s not really a system to collect that kind of information
  - It’s likely pretty high because we have a lot of women that we end up doing C-sections on that would have died without that

**Learning surgery on YouTube**

- Partial nephrectomy (removing part of a kidney because of a tumor)
- Had never done one
- Watched a YouTube video
- Then successfully performed the surgery

**Hundreds of patients**

- 435 beds at Tom’s hospital
- It always at 100% occupancy
- At peak of war, it would be 550 people there, just laying all over the ground
- Peter says: “It looks like when you see movies in war zones, and you see the tents that are serving as hospitals, and you just see amputation, nose completely missing, the most gruesome things. That’s what it looks like you’re in.”
- A US hospital, by comparison… Peter says in residency it was grueling to get through 20 patients in a day
- Tom sees about 300 per day nowadays
- However it used to be more in the past

**Challenges of the remote location of Nuba**

- Once had a measles epidemic and he was seeing 225 kids per day on top of everything else
- They couldn’t get vaccines to Nuba because they were in rebel-territory
- “The sovereignty of a government that kills its own people, it needs to be respected?”
- We’d start at 7:30 in the morning, and 2:00 I’d be finishing up.
- But constantly interrupted by emergencies coming in

> “All this stuff was still going on. It was pretty crazy. You really had to just go as fast as you could. There was a lot of just putting out fires. We weren’t able to spend a lot of time with each patient, obviously. It was really, you had to go pretty rapid fire through all those cases. It was exhausting. Psychologically, it was rough.”

## The most afraid Tom has ever been, and how he copes with the emotional trauma of his daily experiences [1:19:45]

**Tom’s Nuba hospital was bombed twice by the North Sudan military**

> “You’re totally at the mercy of these people, and you feel like you’re just like a hunted animal. That’s what I felt like. I felt like I’m a hunted animal.”

![](https://peterattiamd.com/wp-content/uploads/2019/02/hiding-from-bomb-1024x663.png)

**Figure 5. Nuba child hiding in a foxhole watching the North Sudan aircraft, the Antonov, fly overhead.** Image credit: [Youtube: The Heart of Nuba – 15 minute supercut](https://www.youtube.com/watch?v=fwDjCNuHiWs&t=827s)

**First time, they were at church**

“The mass was over. We were standing there. All of a sudden, somebody says, ‘Everybody get down!’. So we just dive on the ground, we’re just lying flat, and I heard the airplane droning overhead, this Antonov sound. Then I heard the pitch change. It was high-pitched like a whirring sound, almost like a jet engine noise. And then boom, this incredibly loud explosion.”

“They bombed six times. You kept hearing this thing. . .And you’re lying there terrified, you feel like you want to burrow yourself into the ground and disappear.”

**The second time, Tom was inside the hospital**

“I was in the hospital and just down on the floor of the hospital. You know, you’re just thinking, this might be it. Because you can’t tell where it’s going to fall. You hear that whirring sound, and when you hear that whirring sound, you don’t know if that’s going to fall on top of you, if it’s going to fall right next to you and shatter your body. You have no idea. So it’s really terrifying.

**Tom wonders why**

“You’re thinking, ‘what are these people doing? How can they bomb us? Don’t they know there are people down here?’. That’s what I felt, like it was some exercise where they made a mistake.”

But I really hope someday I will meet these pilots. I don’t even feel any animosity towards them. . .t’s strange. You don’t feel anger. You don’t feel animosity towards these people, just kind of wonderment like, ‘What are they doing? Why are they doing this?’”

**Physical and mental exhaustion and emotional trauma**

“The emotional trauma…is probably worse than the physical degradation your body takes by just always being on call. Even when you’re not called that night, it’s hard to sleep. There’s a lot of fear and worry about things. . .There’s always that sense of worry about you’ll be in physical danger. But even when you’re out of that, when the risk of physical danger’s not there, it’s just the psychological thought of always being responsible for the patients and not having a psychological rest. I can’t refer these people somewhere. There aren’t other colleagues we can talk to or get advice on or have somebody else see these patients. It is very draining.”

**How does Tom cope with and manage the emotional distress of his environment?**

1. Draws on his faith
2. Gets strength from the amazing Nuba people

> *“You see the strength and resilience of the Nuba people. You say well, okay, if they can put up with this environment and keep functioning, keep going ahead, let me just try to keep taking care of them as best I can.”*

## The basic tools, technologies, and medicines that Tom is lacking that could save many lives [1:30:00]

- Tom has an ultrasound
- He has an x-ray machine

**Biggest challenge is lab work**

- His machines keep breaking down
- Could really use a [Piccolo lab machine](https://www.pointofcare.abbott/us/en/offerings/piccolo-xpress-chemistry-analyzer)
  - Costs roughly $14,000
  - And would need a year supply of discs for the machine

**Acute leukemia in children**

- If a child has acute leukemia, Tom can’t send them to Kenya, too far and costly
- Can’t treat them chemotherapy either
- They basically help them with [palliative care](https://en.wikipedia.org/wiki/Palliative_care) (end of life care)

**Chronic leukemia in adults**

[*Chronic lymphocytic leukemia*](https://en.wikipedia.org/wiki/Chronic_lymphocytic_leukemia) *(CLL)*

- Tom is able to treat them with cyclophosphamide
- Periodic injections
- This is pretty effective

[*Chronic myelocytic leukemia*](https://en.wikipedia.org/wiki/Chronic_myelogenous_leukemia) *(CML)*

- Tom does NOT have a treatment for this
- But CML is very treatable with the drug called [Gleevec](https://en.wikipedia.org/wiki/Imatinib)
- It’s too expensive yet it would cure almost all cases of CML
- It costs $7,000 per month
- He can’t spend $80,000, for example, to treat one patient knowing that $80,000 could save hundreds of lives
- Tom has to make these agonizing decisions constantly…

> “Yeah. It’s agonizing. It’s absolutely agonizing. And that’s just one example of many.”

**Watch Tom explain one of these agonizing decisions:**

**Tom’s current patient (a mother with CML) desperately needs Gleevec**

“It’s absolutely agonizing. I cannot send her anywhere. It’s totally impossible.”

- She’s got a huge spleen that hurts, she’s anemic
- And she’s got a bunch of kids
- She walks for days to each time she visits the hospital despite her condition
- Only a small amount of Gleevec would get her through the year
- She is one of only a few people with CML so they really don’t need much

## The logistical challenge of helping Tom’s hospital, and what Tom really needs [1:35:15]

**How would someone even logistically go about providing specific or project-based funding to your mission?**

First step is to contact the [Catholic Medical Mission Board](https://en.wikipedia.org/wiki/CMMB_(Catholic_Medical_Mission_Board)) (CMMB) ⇒ For example, if someone were to send Gleevec to CMMB, and they could find a way to get it to [Juba](https://en.wikipedia.org/wiki/Juba), then they *might* be able to find a way to get it to Tom in Nuba

**Money is half the battle, the other half is** **logistics**

⇒ The logistics problem can be summed up as follows:

1. There’s a problem with access to the remote area of Nuba
2. Getting through the administrative things you have to do to get some funding and supplies from the big organization that have money to disperse to charity causes

**What Tom really needs is people**

- It’s a daunting task trying to apply to in these big organizations and to just get through that application process to get funds
- Then once you get the funds, you have to account for it and do monitoring and evaluation and follow-up
- Tom needs people who are trained in this area of writing proposals and monitoring and evaluation and all this sort of stuff to really follow through with all this

## Diseases in the adult population [1:38:30]

[Liver disease](https://en.wikipedia.org/wiki/Liver_disease) is high on the list

- Cirrhosis
- Liver cancers (mostly from hepatitis B)

[Hepatitis B](https://www.webmd.com/hepatitis/digestive-diseases-hepatitis-b) is very common

- Tom vaccinates all the kids in his hospital which is helpful
- However, doesn’t have the funds or capability to get vaccines to the villages so it’s still very prevalent

[Diphtheria](https://www.mayoclinic.org/diseases-conditions/diphtheria/symptoms-causes/syc-20351897)

- This hasn’t been seen since the 1940s in the US yet it shows up in Africa due to lack of vaccines

[Leprosy](https://en.wikipedia.org/wiki/Leprosy)

- In the [tuberculosis](https://www.mayoclinic.org/diseases-conditions/tuberculosis/symptoms-causes/syc-20351250) family
- Transmitted by respiratory droplets and prolonged close contact
- Not by touch which is a misunderstanding, which leads to these people being shunned in the community

[Tuberculosis](https://www.mayoclinic.org/diseases-conditions/tuberculosis/symptoms-causes/syc-20351250) ⇒ Very prevalent

[HIV](https://en.wikipedia.org/wiki/HIV) ⇒ actually quite low

- Less than 1%
- Why? Mostly because Nuba is so isolated
- But if peace comes to the whole region and it opens up you will likely see a rise of HIV because it is sexually transmitted

*STDs are common*

- Gonorrhea
- Syphilis

*What about heart disease?*

- Not heart disease, but they do see [congestive heart failure](https://www.webmd.com/heart-disease/guide-heart-failure) for people in their 60s & 70s
- Not atherosclerotic in origin ⇒ Tom’s never seen a single case of [myocardial infarction](https://en.wikipedia.org/wiki/Myocardial_infarction) in over 10 years
- He posits that it is untreated [hypertension](https://www.mayoclinic.org/diseases-conditions/high-blood-pressure/symptoms-causes/syc-20373410) (many people have BP of 250 over 180)

*How prevalent is obesity?*

⇒ Obesity is almost non-existent (maybe someone is slightly overweight but that’s it)

*What about* [*Type 2 Diabetes*](https://en.wikipedia.org/wiki/Diabetes_mellitus_type_2)*?*

⇒ Rare, but it is seen in some people in the 50s

*Fatty liver disease?*

⇒ Never

**Cancers in Nuba versus the US**

- *In the United States…* the top 5 cancers are lung, breast, colon, prostate, pancreas
- None of these are prevalent in Nuba

*Common cancers in Nuba*

⇒ In kids…

- Burkitt’s lymphoma (common in areas with malaria)
- Fortunately, this is a very treatable cancer, even in Nuba

⇒ In adults…

Liver cancer

- Most common of all (hepatocellular carcinoma)
- Probably all related to hepatitis B positivity

[Cervical cancer](https://en.wikipedia.org/wiki/Cervical_cancer) in women

- Can’t do [pap smears](https://www.mayoclinic.org/tests-procedures/pap-smear/about/pac-20394841) to screen for HPV because it’s impractical b/c can’t send results to get tested (so even the equipment to do a pap smear wouldn’t be helpful to have)
- What would be helpful?
  - Vaccines, specifically [Gardasil](https://en.wikipedia.org/wiki/Gardasil), but only if they were made available at a very low cost
  - But then we’re back to the logistics problem
  - It would need to be lumped into their annual supplies
- Preventing cervical cancer through screening
  - There is something called the [See and treat technique](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5454481/)
  - This might be a middle step before Gardasil becomes available
  - You first need the equipment and then you need the staff with the knowledge and it would be pretty labor intensive

Breast cancer

- There are some cases
- But nobody is getting a mammogram, so people are only diagnosed when they come in with a noticeable lump
- Treatment in these women is pretty unsuccessful
- *Would getting a mammography machine help? ⇒ Partially, but like cervical cancer, Tom would need a whole staff of people to read it… so the machine alone wouldn’t help much*

Colon cancer

⇒ Very rare, 2 or 3 cases in 10 years

**What is the average life span?**

- Nobody knows their exact age (no birth certificates)
- They don’t celebrate their birthdays
- Tom guesses they don’t live much longer than 70s

**Movie recommendation**: [The Good Lie](https://en.wikipedia.org/wiki/The_Good_Lie) starring [Reese Witherspoon](https://en.wikipedia.org/wiki/Reese_Witherspoon)

**Do you see cognitive impairment?**

⇒ Really rare, “they probably die of something else before they reach that stage”

## Living without possessions, finding meaning, and being a missionary [1:55:45]

**See this ABC News story for more about Tom’s experience in Nuba and what motivates him to do this work**: [What it is like being the only doctor in war-torn Sudan’s Nuba Mountains](https://abcnews.go.com/International/doctor-war-torn-sudans-nuba-mountains/story?id=54370334)

*How does Tom handle working around the clock and trying to spend time with his wife?*

- When work is over for the day, there are no distractions
- No TV, radio, no electricity, so when you’re together, you are really present with each other
- Peter points out: “In a way you may actually spend more time with your kids than many of us do here because of our distractions and our travel and our this and our that.”

*Does Tom feel out of place when he’s back in the US?*

“A little bit. I like it, but I don’t think I could stay long-term. . .I do feel much more at home in the Nuba mountains where it’s very quiet and kind of sedated and your time is your own when you’re off.”

*What possessions do you value?*

“I think I’m very much a minimalist since I was born. All these clothes you see me wearing, the socks, the trousers, both these shirts I bought when I came out of Nuba last month.”

“I really do believe that the more detached you become, not like in this Buddhist kind of nirvana sense, but the more detached you are from things, the easier life is. It just simplifies your life.”

*Finding meaning*

“I do feel better with less and I think everybody is looking for some meaning in life.”

**Book recommendation**: [Man’s Search for Meaning](https://www.amazon.com/Mans-Search-Meaning-Viktor-Frankl/dp/080701429X) by [Viktor Frankl](https://en.wikipedia.org/wiki/Viktor_Frankl)

*Favorite Bible passage*

[Matthew 19:16-22](https://www.biblegateway.com/passage/?search=Matthew%2019:16%E2%80%9319:22&version=nkjv)

The verse in Tom’s words:

The basic story is there’s a guy, the guy is a very wealthy young man, and he goes to Jesus. It says he tried to justify himself and says, “Look, what do I have to do to get eternal life?” And Jesus says, “Well, follow the prophets. You’ve got all this stuff there. Follow the 10 commandments. Follow the laws of the prophets and you’ll be okay.” And the guy says, “Well, I do all those things. What do we need to do to really become perfect?” And Christ said, “Sell everything you have. Pick up your cross and follow me.” And it says something which I think is very beautiful. It says, “The man went away, very sad because he had many possessions.” He couldn’t do it.

⇒ Tom’s take:

- It’s not saying being rich is bad, or rich people are bad people. I think that is missing the point. It’s just very difficult because it’s very difficult to be detached from things when you have a lot of possessions.
- Is this thing where you put your values? Is your value in the car you drive, and what kind of beer you drink, or whatever? Or is your value more in people and what you’re doing and how you’re helping people?

**What it means to be a missionary**

- Peter says most people picture a missionary as someone who goes into remote areas and “hits people with Bibles”
- You’re not hitting anybody over the head with a Bible. You’re just sort of saying, “Look, I’m, I’m here to serve you.” And your example is what’s actually doing the talking as opposed to your words.

Tom agrees with this sentiment and quotes [St. Francis](https://en.wikipedia.org/wiki/Francis_of_Assisi):

“Preach always, sometimes use words.”

## Sense of purpose, happiness, and suicide: Contrasting the US with Nuba [2:07:15]

*Are there any cases of suicide in Nuba?*

- “Extremely rare”
- Peter surmises, “There must be a different sense of fulfillment, contentment, happiness, sense of purpose there versus here.”

Suicide in the US

- Suicide is among the top 10 causes of death in every age demographic except for 0 to 10
- But that’s just “fast suicide,” when you kill yourself immediately
- When you include the ‘slow suicide’, when people that kill themselves with alcohol and drugs over time, it is actually in the top-five causes of death across the board

*How is it that Nuba has 1/1000th of the privilege of the US, yet suicide is so rare?*

“When you’re really gripped in this struggle to survive, every day, you have that sort of primal instinct of survival, your mind doesn’t drift off to other things. . .Suicide is so inward-looking, so focused on your own misery that you can’t come out of it.”

**Book recommendation**: [Tribe](https://www.amazon.com/Tribe-Homecoming-Belonging-Sebastian-Junger/dp/1455566381/ref=sr_1_1?ie=UTF8&qid=1549561020&sr=8-1&keywords=tribe+by+sebastian+junger) by [Sebastian Junger](https://en.wikipedia.org/wiki/Sebastian_Junger)

- In the book, Tribe, he writes about post-9/11, suicide rates went down in New York
- It speaks to what Tom is saying…
- “When there’s a real struggle, when there’s something that can bring people together in a common goal, or there’s something that unites people, it can presumably distract from some of that pain that can otherwise hurt us.”

*Relating it to PTSD in US Veterans*

- Somebody’s fighting in Iraq or Afghanistan, and they survive all that
- They come back home, they get despondent and they commit suicide
- Tom posits:
- “Maybe what kept them alive during the fighting was a sense of camaraderie, togetherness, fighting for a common goal. . .
- . . .we’ve had this huge rate of suicide amongst veterans that come back. Not so much from the trauma they had during the fighting. . . but the sense of loss of any bonds, that human contact with other people, that sense of purpose is gone.”

> “It would be interesting if there would be a way to pair a void that exists here in this country, a void of purpose, with a part of the world where purpose is not lacking, but resources are lacking.”

## Other than donations, is there a way people can help Tom and other similar causes? [2:15:15]

Peter asks… *So how can people help? Giving is of course the most obvious. . . but is there something else people can do?*

First of all,

⇒ “Never underestimate the value of a donation to someone you trust, or a group you trust, or an organization you trust. The amount the impact that has is tremendous. We can’t do anything in our work without financial resources.”

Secondly,

⇒ Bringing awareness to those in need

- “If you have a knack for advocacy, or work in government, be aware of the political situations there, advocate on behalf of some of these people that are oppressed, or having difficult lives, whether it’s working in issues of poverty, or poor health, poor education. I think people have a voice to offer, and people do have an influence over governments.”
- Government policies and government funding is a reflection of the constituents
- So to fund projects like Mother of Mercy, the politicians will have to know that the people (the constituents) want that

**The ultimate goal of help**

“The goal is to eventually let these people who are beneficiaries stand on their own two feet maybe in the next generation, the next go-around.”

- The cycle of aid and dependency is a bad thing, this is known…
- But you can’t do anything without some help at this point
- But let’s make sure that help is “geared towards getting these people to stand on their own two feet”

## The food in Nuba [2:18:30]

- Very little variety
- So little variety that if you asked them what they had for supper they would respond “I had food”

[Asida](https://en.wikipedia.org/wiki/Asida)

- Very common dish
- A cake made out of sorghum, totally tasteless

Tom’s body weight

- Tom weighed 230 pounds in college
- Played football (nose guard) at Brown
- Now weighs about 150 lbs

![](https://peterattiamd.com/wp-content/uploads/2019/02/doctor-and-football.jpg)

**Figure 6. Tom now vs. his college football days.** Image credit: [ncaa.org](https://www.ncaa.org/student-athletes/former-student-athlete/tom-catena-man-mission)

**What do Tom and the locals eat?**

- Usually rice, kidney beans, some kind of lentils
- Once in a while, chicken

*Where’s the protein?*

- The sorghum actually has a high protein level
- Locals are actually pretty muscular
- “They’ll have maybe some sorghum porridge in the morning. And that’s pretty much it for the day.”
- A few peanuts (not much)

*Fruits and veggies?*

- Seasonal
- Mangoes, lemons, and tomatoes

![](https://peterattiamd.com/wp-content/uploads/2019/02/crops-1024x603.png)

**Figure 7. The land in Nuba is fertile.** Image credit: [Youtube: The Heart of Nuba – 15 minute supercut](https://www.youtube.com/watch?v=fwDjCNuHiWs&t=827s)

*Milk*

- Only available for a couple months b/c the cows will only give birth during the rainy season
- Since there’s no refrigeration the milk is sour, curdled
- They will pour that over the assida, over the sorghum paste

Peter [laughing]: “That just doesn’t sound tasty”

Tom [also, laughing]: “It’s not very good. . .You kind of eat it, and you’re like, ‘Aw man’. You’re still kinda hungry a bit, but there’s no way you’re going back for seconds. It’s like, ‘Great. That was enough. . .I guess I’m finished.’”

## Tom’s annual bout of malaria [2:23:45]

> “It’s pretty bad. I mean, sometimes you’re wishing somebody comes in and just shoots you and puts you out of your misery. You’re pretty sick with it.”

- Symptoms include: real bad headache, nausea, vomiting, you can’t sleep, just high fevers, body aches, terrible body aches
- A lot of times, it’ll drag on for a month
- Tom was even in a coma for a few days one year
- “They thought I was dead. He goes, ‘Hey, doctor’s dead.’ People came running in. Anyway, I didn’t die. . .I was out of it for quite a while, but then I recovered pretty quickly.”

## Patients that Tom will never forget [2:26:00]

**10-year old bombing victim**

- Kid came in with bomb shrapnel in his face
- He had first gone to another place that just stitched it up without proper cleaning
- It was completely infected
- They completely cleaned it and tried their best
- Got tetanus and died a couple days later
- Tom will never forget seeing the boy trembling at the sounds of planes, he was completely traumatized

**Victim of a napalm bomb**

- Another kid with third-degree burns from a napalm bomb
- Burns on 60% of his body
- He somehow lived 2 months
- “The amount of work the nurses did every day just to try to dress him. The agony he went through before he died.”

**Six other burn victims (kids)**

- They lived in a village that should get shelled all day and bombed at night
- At nighttime, they would sleep in the foxholes for protection
- While sleeping in foxholes, a straw structure caught fire and fell in the foxhole
- The 6 kids that survived initially were burned over 80% “full thickness” and eventually all died

**Soldier**

- 23 holes in his abdomen
- Many many hours operating on him
- Post op doing great
- But died suddenly
- He was a Darfuri guy fighting with the Nuba rebels
- “Like, this guy’s got a family, you know? He’s fighting in this place. His family’s somewhere in Darfur. What’s happening? Do they have any idea what’s happening here?”

**A young boy trying to help**

- 16 years old
- Jumped in a truck to go help the Nuba rebels push back the approaching enemy
- No gun or anything
- Just a civilian
- Shot in the head
- Brain pulsating out
- Survived for a few weeks

> “So these are all people I’ll never forget. And there are many, many, many beyond that.”

![](https://peterattiamd.com/wp-content/uploads/2019/02/bomb-victims-1024x660.png)

**Figure 8. Civilian victims who were ruthlessly bombed by the North Sudan government.** Image credit: [Youtube: The Heart of Nuba – 15 minute supercut](https://www.youtube.com/watch?v=fwDjCNuHiWs&t=827s)

## Resources for people wanting to get involved in helping Tom’s work [2:31:00]

- [African Mission Healthcare Foundation](https://africanmissionhealthcare.org/donation/catena/)
- Please also make sure to watch: [Heart of Nuba](https://theheartofnuba.com/) ⇒ Watch on: [YouTube](https://www.youtube.com/watch?v=MR7k-wfuvXY), [Amazon](https://www.amazon.com/Heart-Nuba-Cornelio-Catena/dp/B07DP1MFSR), [Google Play](https://play.google.com/store/movies/details?id=MR7k-wfuvXY)

## Peter tells a story that defines Tom [2:32:00]

Peter closes with a story that he says defines Tom as someone working on the front lines…

**The Starfish Story:**

Two guys are walking down the beach, and it’s after a really high tide and the beach is covered in starfish. And the starfish are going to die pretty soon if they don’t get back in the water, which means they’re pretty much all going to die. The two guys are walking, and every few steps, one of the guys bends down and he picks up a starfish and he throws it back in the water. And five steps later, he does it again, and again, and again. After like the 10th one, the one guy says to him, “What are you doing?” And he says, “Well, if these starfish don’t get back in the water, they’re gonna die.” And he goes, “Have you looked and seen how many of them there are? You can’t possibly make a difference.” And he throws another one in the water, and he says, “Well, it made a difference to that one.”

*Tom’s response to the story:*

In the end, medicine is individual. It’s the beauty of our profession. And it’s a huge privilege to have the opportunity to affect one person. And in the end, you close the door and it’s you and the patient, whether you’re in Nuba mountains, whether you’re here in New York. And that’s an incredible privilege. And I think if we keep that focus, just one person at a time, I think people can kind of relax a bit. You can see that what you’re doing for that one person. . .I think people look at Africa and say, “What you’re doing is a drop in the ocean.” I really like that story because when you’re there, you don’t see a drop in the ocean. You see a person. You see a life. And you see somebody that can laugh, and can cry, and can play, has aspirations, and is a living, breathing human being. You think, “Man, we helped this one person.” That’s a huge thing, you know? But I think that helps to stave off some of the burnout and the cynicism. This is a very individual thing, so one person is really a big deal. It’s everything to that one person, that one person’s family. And I think we really have to keep that in mind, especially with this growing realm of cynicism and sort of negativity that we see now.

*Peter sums it up:*

> “For people on the front lines, I don’t think there’s a human being on this planet who throws more starfish back in the water than you.”

§

## Selected Links / Related Material

## How you can directly support Tom’s work and change the lives of his patients:

You can directly support the needs of the Mother of Mercy Hospital by going to [African Mission Healthcare donation page](https://africanmissionhealthcare.org/donation/catena/). The following are some of the most urgent needs:

**Operating eye microscope and associated supplies**

- Funds needed = $40,000
- These funds would be enough for ~600 eye operations

**Housing**

- Funds needed = $100,000
- Mother of Mercy hospital operates at 100% capacity at all times
- These funds would allow the hospital to build 2 additional much-needed units

**Batteries for solar panels**

- Funds needed = $15,000
- Mother of Mercy hospital runs on 100% solar power and needs battery replacements every so often to keep everything running without interruption

**Pay for a C-section**

- Each C-section costs roughly $250
- Childbirth mortality is a major problem in Nuba, and your donation could save the life of a mother and/or child

## Must watch videos and articles to read

1. **Documentary based on Tom’s work in Nuba**: [Heart of Nuba](https://theheartofnuba.com/)
   - **Or this 15-minute shortened version of Heart of Nuba**: [The Heart of Nuba – 15 minute supercut](https://www.youtube.com/watch?v=fwDjCNuHiWs&t=827s)
2. **NY Times article by Nick Kristof where Peter first heard of Tom**: [‘He’s Jesus Christ’](https://www.nytimes.com/2015/06/28/opinion/sunday/nicholas-kristof-hes-jesus-christ.html)
3. **10-min video from the NY Times article**: [The Worst Atrocity You’ve Never Heard Of: Sudan’s Nuba Mountains](https://www.youtube.com/watch?v=kG4xMTlPt6I)
4. **ABC News story on Tom’s work**: [What it is like being the only doctor in war-torn Sudan’s Nuba Mountains](https://abcnews.go.com/International/doctor-war-torn-sudans-nuba-mountains/story?id=54370334)
5. **See the Heart of Nuba YouTube channel for more**: [The Heart of Nuba](https://www.youtube.com/channel/UC2hFxxzKS7qReKulPXR756A)

## All other related material

**Documentary based on Tom’s work in Nuba**: [Heart of Nuba](https://theheartofnuba.com/) | (heartofnuba.com) [8:45, 32:30, 45:15, 57:00, 1:18:30, 2:00:00, 2:35:15]

**Sponsor of Tom’s hospital in Nuba**: [Catholic Medical Mission Board](https://en.wikipedia.org/wiki/CMMB_(Catholic_Medical_Mission_Board)) | (wikipedia.org) [11:30, 1:39:30, 2:35:30]

**Hospital in Kenya where Tom worked**: [Kakuma Mission Hospital](https://www.electives.net/hospital/6916/preview) | ([electives.net](https://www.electives.net/)) [15:00]

**Another hospital in Kenya where Tom worked just prior to moving to Nuba**: [St Mary’s Mission Hospital](https://www.stmmh.co.ke/) | (stmmh.co.ke) [15:00]

**Sponsor and developer of Mother of Mercy Hospital**: [Catholic Diocese of El Obeid](https://en.wikipedia.org/wiki/Roman_Catholic_Diocese_of_El_Obeid) | (wikipedia.org) [15:45]

**NY Times article by Nick Kristof where Peter first heard of Tom**: [‘He’s Jesus Christ’](https://www.nytimes.com/2015/06/28/opinion/sunday/nicholas-kristof-hes-jesus-christ.html) | Nicholas Kristof ([nytimes.com](https://www.nytimes.com/)) [1:03:30]

**Here is the 10-min video from that article**: [The Worst Atrocity You’ve Never Heard Of: Sudan’s Nuba Mountains](https://www.youtube.com/watch?v=kG4xMTlPt6I) | The New York Times (youtube.com) [1:03:30]

**Tom won the 2017 Aurora Prize for his work in Nuba**: [DR. TOM CATENA – 2017 AURORA PRIZE LAUREATE](https://auroraprize.com/en/aurora/detail/11531/dr-tom-catena-2017-aurora-prize-laureate) | (auroraprize.com) [1:07:00]

**Here’s the video made for Tom as an Aurora Prize finalist**: [2016 Aurora Prize Finalist, Dr. Tom Catena: Courage You Would Never Expect](https://www.youtube.com/watch?v=1oLEl2sdRP4) | Aurora Prize (youtube.com) [1:07:00]

**Tom announced as chairman of the Aurora Prize foundation**: [SURGEON AND MISSIONARY DR. TOM CATENA ANNOUNCED AS CHAIR OF AURORA HUMANITARIAN INITIATIVE](https://auroraprize.com/en/aurora/detail/13800/surgeon-and-missionary-dr-tom-catena-announced-as-chair-of-aurora-humanitarian-initiative-) | (auroraprize.com) [1:07:00]

**Non-governmental humanitarian organization**: [Doctors Without Borders](https://en.wikipedia.org/wiki/M%C3%A9decins_Sans_Fronti%C3%A8res) | (wikipedia.org) [1:11:30]

**Lab chemistry analyzer that Tom needs**: [Piccolo Xpress](https://www.pointofcare.abbott/us/en/offerings/piccolo-xpress-chemistry-analyzer) | ([pointofcare.abbott](https://pointofcare.abbott)) [1:35:00]

**Tom explaining the agonizing choice of deciding which patient to treat and which to let die due to a lack of resources**: [Tom’s Choice](https://www.youtube.com/watch?v=H-cuPm8E-K0) | The Heart of Nuba (youtube.com) [1:38:00]

**Foundation doing great work in Africa but has trouble helping Sudan specifically**: [Bill & Melinda Gates Foundation](https://www.gatesfoundation.org/) | (gatesfoundation.org)[1:40:45]

**Movie starring Reese Witherspoon about the civil war in Sudan**: [The Good Lie](https://en.wikipedia.org/wiki/The_Good_Lie) | (wikipedia.org) [1:58:45]

**Book recommendation about finding meaning in life**: [Man’s Search for Meaning](https://www.amazon.com/Mans-Search-Meaning-Viktor-Frankl/dp/080701429X) by Viktor Frankl | (amazon.com) [2:05:45]

**Tom’s favorite Bible passage**: [Matthew 19:16-22](https://www.biblegateway.com/passage/?search=Matthew%2019:16%E2%80%9319:22&version=nkjv) | ([biblegateway.com](https://www.biblegateway.com/)) [2:06:30]

**Book about the importance of a tribal connection that we’ve lost in the US**: [Tribe](https://www.amazon.com/Tribe-Homecoming-Belonging-Sebastian-Junger/dp/1455566381/ref=sr_1_1?ie=UTF8&qid=1549561020&sr=8-1&keywords=tribe+by+sebastian+junger) by Sebastian Junger | (amazon.com) [2:15:15]

**A reliable way to donate funds to the crisis in Sudan**: [African Mission Healthcare Foundation](https://amhf.kindful.com/?campaign=238209) | ([amhf.us](https://www.amhf.us/)) [2:35:00]

**Foundation set up to take donations in response to the Heart of Nuba film**: [Take Heart Foundation](https://takeheart.nationbuilder.com/donate) | ([nationbuilder.com](https://nationbuilder.com/)) [2:35:15]

§

## People Mentioned

- [Omar al-Bashir](https://en.wikipedia.org/wiki/Omar_al-Bashir) (evil dictator of North Sudan) [14:00, 20:30, 1:06:00]
- [Deirdre Burns](https://www.uwhealth.org/findadoctor/profile/deirdre-a-burns-md/5624) (missionary doctor in Keyna that told Tom about the crisis in Sudan)  [15:00]
- [Bishop Macram Gassis](https://de.wikipedia.org/wiki/Macram_Max_Gassis) (helped get Mother of Mercy hospital built) [15:30]
- [Hassan Al-Turabi](https://en.wikipedia.org/wiki/Hassan_Al-Turabi) (evil genius of the Muslim Brotherhood) [19:30]
- [Osama bin Laden](https://en.wikipedia.org/wiki/Osama_bin_Laden) [21:15]
- [Ahmed Haroun](https://en.wikipedia.org/wiki/Ahmed_Haroun) (Omar al-Bashir’s candidate, National Congress Party) [24:00]
- [Abdou Aziz](https://fr.wikipedia.org/wiki/Abdou_Aziz_Sy) (candidate who lost the sham election in Nuba) [24:00]
- [Mike Johnson](https://thosepeculiarjohnsons.org/about/) (American missionary doctor in Kenya who was a mentor to Tom) [41:30]
- [Nasima Catena](https://cmmb.org/wp-content/uploads/2017/05/Wedding-day.jpg) (nurse at Nuba hospital, now Tom’s wife) [52:15]
- [Dr. Jon Fielder](https://www.hopkinsmedicine.org/news/publications/aequanimitas/aequanimitas_spring_2015/jon_fielder_executive_director_african_mission_healthcare_foundation) (career in missionary medicine, co-founder of African Mission Healthcare) [1:01:15, 1:15:00, 2:39:30]
- Rick Gerson (Peter’s friend who told him about Tom) [1:03:30, 2:39:30]
- [Mark Gerson](https://en.wikipedia.org/wiki/Mark_Gerson) (Peter’s friend who told him about Tom) [1:03:30, 1:10:00, 2:39:30]
- [Nick Kristof](https://en.wikipedia.org/wiki/Nicholas_Kristof) (author of NYT article about Tom’s work) [1:03:30]
- [Dr. Corry Chapman](https://immediatecare.net/meet-the-staff/) (has worked at Mother of Mercy with Tom, he appears in the Heart of Nuba film) [1:19:45]
- [Olivia Attia](https://peterattiamd.com/sneak-peek-peter-attia-drive/) (Peter’s daughter) [1:23:30]
- [Reese Witherspoon](https://en.wikipedia.org/wiki/Reese_Witherspoon) (stars in The Good Lie) [1:58:45]
- [Viktor Frankl](https://en.wikipedia.org/wiki/Viktor_Frankl) (wrote A Man’s Search for Meaning) [2:05:45]
- [St. Francis](https://en.wikipedia.org/wiki/Francis_of_Assisi) (“Preach always, sometimes use words.”) [2:10:00]
- [Sebastian Junger](https://en.wikipedia.org/wiki/Sebastian_Junger) (author of Tribe) [2:15:15]
- [Ken Carlson](https://www.imdb.com/name/nm0007189/) (creator of Heart of Nuba film) [2:35:15]

§

![](https://peterattiamd.com/wp-content/uploads/2019/02/dr-tom-catena-time-100-2015-pioneers-copy-500x500.jpg)

##### Tom Catena, M.D.

Thomas (Tom) Catena is an American physician who has been practising in Gidel in the Nuba Mountains of Sudan since 2008. On May 28, 2017 he was awarded the second annual Aurora Prize for Awakening Humanity, receiving a $100,000 grant and an additional one million dollars for him to distribute to three humanitarian organizations. He has been likened to the 20th-century medical missionary Albert Schweitzer. He has also been called “Jesus Christ” by one muslim man for his amazing ability to treat and save so many patients. Catena graduated with a bachelor’s degree in mechanical engineering from Brown University in 1986. While at Brown, Catena played nose guard on the Brown Bears football team. He later received his medical degree from Duke University on a U.S. Navy scholarship. During his fourth year at Duke Catena went on his first mission to Kenya in 1992. After graduating, he completed a one-year internship in internal medicine at the Naval Medical Center San Diego in 1993 and later joined the U.S. Navy. For the next four years, he served as a flight surgeon. After his discharge from the Navy in 1997, Catena began a postgraduate residency in family medicine at Union Hospital in Terre Haute, Indiana, while also participating in one-month medical mission trips to Guyana (1997) and Honduras (1998). When he finished his residency in 1999, Catena decided to continue volunteering with the Catholic Medical Mission Board (CMMB) and spent two and a half years as a missionary doctor at Our Lady of Lourdes Mutomo Hospital in the rural settlement of Mutomo, Kenya. From 2002 until 2007, he worked as a consultant at the private St Mary’s Mission Hospital in Nairobi. With CMMB, Catena volunteered to help the Roman Catholic Diocese of El Obeid establish the Mother of Mercy Hospital in the Nuba Mountains, which was built in 2007 and first launched its operations in March 2008. Tom has been acting as the director of the hospital and the sole doctor to nearly one million people in the hospital’s catchment area since 2008. In 2018, he was appointed chair of the Aurora Humanitarian Initiative, a position he holds in addition to his activities in Sudan. [[wikipedia.org](https://en.wikipedia.org/wiki/Tom_Catena)]

Twitter: [@CatenaTom](https://twitter.com/CatenaTom?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)