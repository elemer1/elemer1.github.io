# #83 – Bill Harris, Ph.D.: Omega-3 fatty acids

**Source:** [https://peterattiamd.com/billharris/](https://peterattiamd.com/billharris/)

---

In this episode, Bill Harris, Ph.D. in human nutrition and expert on omega-3 fatty acids, sets the table by clearly defining the families of fatty acids (saturated, monounsaturated, polyunsaturated) before diving into the current landscape of polyunsaturated fat (omega-6 and omega-3) with a particular focus on EPA and DHA (the two main elements of fish oil supplements). Bill gives a historical overview, updates us on the latest science related to the health benefits, and provides plenty of insights as to how we should think about increasing our EPA and DHA intake.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/billharris/the_Drive_public.png)

Play

#83 - Bill Harris, Ph.D.: Omega-3 fatty acids

1x15s30s

0:002:02:26

## We discuss:

- Bill’s long history of studying fatty acids [6:30];
- Defining the fatty acids—SFA, MUFA, PUFA, omega-3, omega-6, and more [9:45];
- What is the significance of fatty acids? Why should we care? [19:45];
- History of fat phobia, saturated fat, and does PUFA reduce cholesterol? [23:45];
- Breaking down the conversion process of omega-6 and omega-3 fatty acids including how we get to EPA and DHA [28:00];
- Takeaway from Bill’s 1980 study looking at how salmon oil affected cholesterol and triglyceride levels [36:15];
- History of our understanding of omega-3 and its effect on LDL cholesterol [45:00];
- Prescribed fish oil drugs vs. OTC supplements—Differences and recommended brands [52:00];
- Health benefits of EPA [57:45];
- Potential benefits of ALA and how it compares to taking EPA and DHA directly [1:12:45];
- Health benefits of DHA [1:17:15];
- Cell membrane omega-3 index—What is it, the role of genetics, how to increase it, and a recommended target [1:19:00];
- Is EPA or DHA neuroprotective? Can it help with depression? [1:23:30];
- Recommended fish to eat for EPA and DHA – Any mercury concerns? [1:25:45];
- Can omega-3 mitigate risks associated with smoking? [1:29:15];
- The problem with the omega-6 to omega-3 ratio [1:30:00];
- The problem with labeling any kind of fatty acid as “bad” [1:36:00];
- Why increasing EPA and DHA intake matters more than reducing omega-6 intake [1:38:00];
- Important takeaway from the VITAL study [1:46:30];
- Importance of testing your omega-3 index [1:53:00];
- Exciting study coming out soon, and why you need to take your fish oil with food [1:57:15]; and
- More.

§

## Show Notes

## Bill’s long history of studying fatty acids [6:30]

- Got a PhD in nutrition in 1978
- In post-doc, worked for [Bill Connor](https://www.oregonlive.com/news/2009/11/the_scientist_whose_pioneering.html) in Portland, Oregon
- First assignment was to figure out what the effect is of salmon oil on cholesterol levels
- Did a metabolic ward study in the late 70s
- Fed people huge amounts of salmon steaks plus salmon oil (~25 grams of EPA/DHA per day)
- Lasted 28 days
- Found that the salmon oil did lower cholesterol relative to the saturated fat diet
- It was about the same lowering as we saw with the vegetable oil diet
- The thing that was unique about salmon oil was that it **lowered triglyceride levels**
- [Published these results in 1980](https://www.ncbi.nlm.nih.gov/pubmed/7195627)
- Around that same time, Hans Olaf Bang and Jorn Dyerberg published a series of [Greenland Eskimo studies](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(71)91658-8/fulltext) which were becoming well-known

> “And so we started chasing omega-3 effects on lipids and platelet function and all kinds of other things, and so I’ve just been able to stay with it. I’ve had five grants from the NIH to study omega-3 related questions. It’s been a field that’s continued to be fascinating and ups and downs, but enriching, and as you said, it’s confusing right now. It’s been confusing for most of its history.”

## Defining the fatty acids—SFA, MUFA, PUFA, omega-3, omega-6, and more [9:45]

**Fat is one of the five macronutrients**

1. Fats
2. Proteins
3. Carbohydrates
4. Ketones
5. Alcohol

Fats come in different chemical forms:

- Saturated fat
- Monounsaturated fat
- Polyunsaturated fat
  - PUFA is then divided further
    - Omega-3
    - Omega-6
    - Omega-9
    - And more.

**Saturated fatty acid (SFA)**

- SFA are a long single chain of carbon atoms all hooked together (single bonds)
- In chemistry, you can have single bonds, you can have double bonds, you can have triple bonds
- The vast majority of fatty acids in butter, for example, have long single chain
- Solid at room temperature: The simplest way to detect the saturated fat is at normal room temperature, they’re solid

![](https://peterattiamd.com/wp-content/uploads/2019/12/Fig-1.-SFA-billharris-1024x508.png)

**Figure 1. Saturated fatty acid.**

**Monounsaturated fatty acids (MUFA)**

- These have the same long carbon chain as SFA (It can be 12, 14, 16, 18 carbons long)
- But there’s one double bond in a monounsaturated fatty acid
- When there’s a double bond in a molecule, it now has a point of unsaturation
- The classic oil that is rich in monounsaturated fatty acids would be olive oil (and canola oil now)
- They are liquid at room temperature, but you put them in the refrigerator and they’ll get hard (or very cloudy)

![](https://peterattiamd.com/wp-content/uploads/2019/12/Fig-2.-MUFA-billharris-1024x385.png)

**Figure 2. Monounsaturated fatty acid.**

**Polyunsaturated fatty acid (PUFA)**

- Instead of one double bond, now we have two or more double bonds
- The same long carbon chain with now two or three typically double bonds
- Polyunsaturated oils are liquid at room temperature and they’re typically liquid in the refrigerator
- You have to put them in a freezer to get them to get solid or to get cloudy
- Some fish oils will not even get solid even in a freezer

*The two major families of PUFAs*:

  1 [Omega-6](https://en.wikipedia.org/wiki/Omega-6_fatty_acid)

- If you count back 6 positions from the final carbon you will get to the first double bond in the molecule
- *Examples*: vegetable oils, safflower oil, corn oil, sunflower oil

  2 [Omega-3](https://en.wikipedia.org/wiki/Omega-3_fatty_acid)

- The first double bond is in the third position from counting back from the final carbon
- *Example*: Fish oil

![](https://peterattiamd.com/wp-content/uploads/2019/12/Fig-3.-PUFA-billharris-1024x568.png)

**Figure 3. Polyunsaturated fatty acid.**

**The numerical system**:

–Saturated fat…

- Palmitic acid (palm oil from palm trees) is an SFA that has 16 carbons
- Its designation is 16:0
- 16 means how many carbons are in the molecule
- What follows the colon is the number of double bonds in the molecule
- Since all saturated fats are single bonds, the number is zero

–For monounsaturated fats…

- The most common one is 18 carbon fatty acids
- So it would be written as 18:1 ⇒ the “1” tells you there’s one double bond

–Once you start putting a double bond in a molecule, now you have to tell the reader where it is in the molecule

- In the case of an omega-9 fatty acid it about be n-9
- So something like 18:1, n-9
- So if you see written “n-3 fatty acid” it is the same molecule as omega-3

## What is the significance of fatty acids? Why should we care? [19:45]

- Every membrane of every cell is formulated with fatty acids
- Every membrane of every cell is made up of a unique suite of fatty acids depending on the type of tissue
- Why?
  - Well, each cell has its own role to play in metabolism, the membrane has to have certain physical characteristics being real loose and floppy or being real stiff depending on the need of that cell and the fatty acid composition is unique to afford a certain kind of chemical flexibility

Blood test

- There is a [blood test](https://omegaquant.com/what-is-the-omega-3-index/) that can be done to show the percentage of what percentage is EPA, DHA, total saturates, total monounsaturates, etc. that are in the red blood cell membranes
- The ranges on those are not that big and most people tend to fall within them no matter how much they’re eating
- But… they can be at really different ends of those ranges
- In other words, you don’t have people that differ by two and three fold, but people can definitely differ by 20 or 30%
- There is a much wider variation in the fatty acids we eat than what we see in our blood
- That’s because the body is making the membranes from the raw materials we eat and it picks what it wants and it puts the fatty acids largely where it wants them to be
- You can influence it a little bit by what you eat, but not by 2 or 3 fold

## History of fat phobia, saturated fat, and does PUFA reduce cholesterol? [23:45]

- Bill’s studies in the 70s and 80s were largely spawned from what was going on at the time with dietary guidelines
- [George McGovern](https://en.wikipedia.org/wiki/George_McGovern) was presiding over the Senate committee on health in 1977 and made the decision to tell Americans to [greatly reduce intake of saturated fat](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3910043/) because of its alleged causality of heart disease
- A question that came out of that was:  *If saturated fat is going to do this, does polyunsaturated fat do the reverse?*
- A [number of studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3971029/) showed that polyunsaturated fats, mostly omega-6s, actually showed a *reduction* in total cholesterol
- In the 70s, people were taking tablespoons of vegetable oil to lower their cholesterol

*What is the mechanism by which taking tablespoons and tablespoons of sunflower oil or corn oil would lower a person’s cholesterol?*

- When you’re taking the Omega-6s or the Omega-9s, the monounsaturates, you’re replacing some saturated fatty acids in the membranes
- If you’re reducing your saturated fat intake, you’re reducing the amount of saturated fat to an extent in your membranes and that has an effect on the physical, chemical fluidity of the membrane
- Buried within all of our cell membranes, there are thousands of receptors/proteins that are sitting right in the middle of membranes
- One of these is called the LDL receptor, low density lipoprotein, which is the primary lipid particle that carries cholesterol in our blood
- That receptor is sitting there in the liver membrane
- If you remove saturated fat or lower the amount of saturated fat in that membrane, it changes the properties of the membrane so that that LDL receptor is more efficient at binding to and removing LDL particles from the blood
- That essentially lowers your cholesterol level
- So *the cholesterol lowering comes through lowering of the LDL more so than the HDL*?
  - Correct, it’s the LDL that’s affected primarily by the saturation of fats
  - There’s some effect on HDL cholesterol, but most of it is LDL

Fat phobia

- Bill points out that people became to demonize all fat (rather than just saturated fat)
- In addition, people replaced fat with carbs and sugars

## Breaking down the conversion process of omega-6 and omega-3 fatty acids including how we get to EPA and DHA [28:00]

![](https://peterattiamd.com/wp-content/uploads/2019/12/Fig-4.-billharris-1024x572.png)

**Figure 4. Slide showing linoleic acid down to arachidonic acid (left side) and alpha-linoleic acid down to EPA and then down to DHA (right side).**

**The omega-6 family:**

- Starts with [Linoleic acid](https://en.wikipedia.org/wiki/Linoleic_acid) (LA)
  - Found in corn oil and soybean oil
  - It’s an essential fatty acid (meaning we can’t make it and it’s important for health)
  - 18:2 fatty acid
- Once LA is eaten it goes to the liver
- Liver uses elongase enzymes to elongate the fatty acid chain from 18 to 20
- It also is de-saturazing it by adding 2 more double bonds
- So it went from 18:2 to 20:4
- It is now [arachidonic acid](https://en.wikipedia.org/wiki/Arachidonic_acid) (AA)
  - Extremely important fatty acid in metabolism
  - Substrate for [prostaglandins](https://en.wikipedia.org/wiki/Prostaglandin)
- **In short**: LA⇒ AA

**The omega-3 family**:

- Starts with [alpha-Linolenic acid](https://en.wikipedia.org/wiki/Alpha-Linolenic_acid) (ALA)
  - Found in flaxseed oil and chia seed oil
  - Also an essential fatty acid
  - 18:3, n-3 fatty acid
- Once eaten, goes to liver
- Elongated by 2 more carbons
- More double bonds are added
- Now we are at a 20:5, omega-3 fatty acid called [EPA](https://en.wikipedia.org/wiki/Eicosapentaenoic_acid)
- EPA can get further elongated and get more double bonds added
- You eventually get to [DHA](https://en.wikipedia.org/wiki/Docosahexaenoic_acid) with is 22:6, omega-3 fatty acid
- **In short**: ALA⇒ EPA⇒ DHA

![](https://peterattiamd.com/wp-content/uploads/2019/12/Fig-5.-billharris-1024x561.png)

**Figure 5.**

*What is the main source of ALA (therefore EPA and DHA) for Americans?*

- Well, the high dose products would be flaxseed and chia seed
- However, the principal source actually tends to be soybean oil since americans consume so much of it (7% of the fatty acids in soybean is ALA)

![](https://peterattiamd.com/wp-content/uploads/2019/12/Fig-6.-billharris-1024x651.png)

**Figure 6. While arachidonic acid is the “most important endpoint”, the liver can even take that molecule and make it even longer (22 carbons) and add up to five more double bonds (see green box). But there’s not much of that around, and little is known about what it does.**

## Takeaway from Bill’s 1980 study looking at how salmon oil affected cholesterol and triglyceride levels [36:15]

**In 1978, what did Bill know about EPA and DHA?**

- Did not even know EPA and DHA existed
- He was investigating what it was about salmon oil that apparently lowered cholesterol
  - Was the “liquidness” (as opposed to solid) important?
  - Or was it the fact that it was an animal derived versus plant derived?
- Turns out the “**liquidness**” was the important part

**How much EPA and DHA are in the diet of the average American (who is not supplementing)?**

- Bill says Americans get about 150 milligrams of EPA+DHA per day from their diet
- Considering we eat 80-100 grams of fat per day, it’s “too bad” we get so little of EPA+DHA
- By contrast, fish-eating populations such as the [Okinawan people](https://en.wikipedia.org/wiki/Okinawa_diet) would eat ~2,000 milligrams per day
- The [Greenland Eskimos](https://en.wikipedia.org/wiki/Inuit_cuisine) would get closer to 6-7 grams per day (6,000-7,000 mg)

**What was the magnitude of the reduction in total cholesterol, LDL cholesterol, and triglyceride that Bill saw in his** [**1980 study**](https://www.ncbi.nlm.nih.gov/pubmed/7195627)**?**

- Cholesterol went down from 250-230
- TG went from 100 to 75

*Is EPA a blood thinning fatty acid?*

- One theory was that EPA thinned out blood which could explain why Eskimos didn’t have heart attacks
- But Bill’s study showed it didn’t thin blood any more than an aspirin

**Referring to the Greenland Eskimos diets…**

- 80% of their diets were animal fat
- How much was PUFA vs SFA?
  - Only about 6-7% of their fat intake were PUFA and those were mostly Omega-3 (almost zero Omega-6)
  - And probably 70% of the fat was saturated fat

“*What was so amazing about the Eskimo studies because we had this paradigm that high fat, high saturated fat, high cholesterol, of course eating very high cholesterol diet because everything was from animals. Those are bad diets. And yet the evidence, which has been challenged nowadays, but at the time, the evidence was these Eskimos were virtually free of acute myocardial infarction, of heart attacks. It just didn’t make any sense.*” —Bill Harris

**Bill’s 1989 paper explains this paradigm and talks about the discovery of Omega-3**: [Fish oils and plasma lipid and lipoprotein metabolism in humans: a critical review.](https://www.jlr.org/content/30/6/785.full.pdf)

## History of our understanding of omega-3 and its effect on LDL cholesterol [45:00]

Bill calls 1985 a “turning point year for Omega-3”

The New England Journal of Medicine published three studies on Omega-3 in the same issue in May of 1985:

1. *Bill’s 1985 paper in NEJM giving very high doses of Omega-3 which showed huge drops in triglycerides*: [Reduction of plasma lipids, lipoproteins, and apoproteins by dietary fish oils in patients with hypertriglyceridemia.](https://www.ncbi.nlm.nih.gov/pubmed/3990714) (Phillipson et al., 1985) [46:00]
2. [The Inverse Relation between Fish Consumption and 20-Year Mortality from Coronary Heart Disease](https://www.nejm.org/doi/full/10.1056/NEJM198505093121901) (Kromhout et al., 1985)
3. [Effect of Dietary Enrichment with Eicosapentaenoic and Docosahexaenoic Acids on in Vitro Neutrophil and Monocyte Leukotriene Generation and Neutrophil Function](https://www.nejm.org/doi/full/10.1056/NEJM198505093121903) (Lee et al., 1985)

*⇒ Bill’s* [*1991 study*](https://www.ncbi.nlm.nih.gov/pubmed/1832701)

- Showed patients with lipid disorders could significantly reduce their triglycerides with fish oil
- Gave patients 18-20 grams of salmon oil to make this happen

**The LDL conundrum**—**Bill’s** [**1990 study**](https://www.ncbi.nlm.nih.gov/pubmed/2375788)

- This study showed 6 grams/day of EPA and DHA in capsule form…
  - Made **triglycerides go down** very nicely
  - But **LDL cholesterol started to go up**

This became the “downside” to the Omega-3 story

- Fish oil companies at the time were marking their products as cholesterol lowering so this was a problem for them
- The FDA began sending out “false advertising” notices
- A “gut punch” to the industry

*What was thought of as the reasoning for this rise in LDL cholesterol?*

- Bill says there were more LDL and ApoB particles
- With 6 grams of additional EPA/DHA, they would go from about 120 to 140 or 150
- It was hard to know why at the time
- But more recent papers, like [this one from 2004](https://www.ncbi.nlm.nih.gov/pubmed/15051597), suggests that it turns down the LDL receptors
- So Omega-3’s effect was on **clearance**, not an effect on production

IMPORTANT NOTE:

- This study was giving 6 grams of omega-3 which is far beyond what people would get from a fish oil pill
- And Bill’s study was showing that it would raise LDL cholesterol in people who had high TG and high LDL cholesterol already
- It’s unclear what would happen if giving 6 grams to “healthy” people

## Prescribed fish oil drugs vs. OTC supplements—Differences and recommended brands [52:00]

- The largest pharmacological dose given today is 4 grams
- And it’s for people with VERY high TG (over 500)
- The product is called Lovaza which is a 1,000 mg capsule of which is 85% (850 mg) EPA and DHA ethyl-esters

**The two brands of fish oil that Peter recommends to patients**:

- [Carlson Labs](https://carlsonlabs.com/the-very-finest-fish-oil/)
- [Nordic Naturals](https://www.nordicnaturals.com/consumers/omega-3-in-fish-gelatin)

⇒ \*Here is the [NY Times article by Anahad O’Connor](https://well.blogs.nytimes.com/2014/01/22/whats-in-your-fish-oil-supplements/?mtrref=www.google.com&gwh=A9E9C4FEFAE3E5A3A751BD1D762D06FA&gwt=pay&assetType=REGIWALL) comparing fish oil brands

- When you read the label you might see a 2,000 mg pill of fish oil
- But it’s not uncommon for only 80% of that to be EPA and DHA
- What is the other 20%?
  - A mixture of some monounsaturates and some polyunsaturates just again, a general standard fatty acids you’d find in most foods

*Can you get the same dose of Omega-3 from OTC supplements as you could with prescribed Lovaza?*

- It’s possible
- And Bill doesn’t see any harm in the supplements out there
- But it would be almost impractical because to get 4 grams you’d have to take a TON of pills
- That said…
- There are more supplements being produced that are very very concentrated
- Bill predicts a “fight” coming soon between the drug manufacturers and the supplement producers because the line between drug and supplement is getting fuzzy

## Health benefits of EPA [57:45]

**EPA is considered “heart healthy” … how so?**

1. **Blood platelets become less sticky** – some prostaglandin type molecules make the blood platelets less sticky (It’s kind of like taking Aspirin without some of the side effects of Aspirin)
2. **Anti-inflammatory** – The EPA is also able to produce a whole series of molecules that we call resolvins, because they resolve inflammation
3. **Helps cellular metabolism run more smoothly –** when EPA becomes incorporated into cell membranes, it changes the flexibility/ fluidity of the membrane which changes the way the enzymes that live in the membranes work in such ways that makes cellular metabolism run more smoothly

   ⇒ ([Harris et al., 2018](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6034629/))

**The only study to look at EPA without DHA ⇒** [**REDUCE-IT study**](https://www.ncbi.nlm.nih.gov/pubmed/31707829?dopt=Abstract)

-Patient population

- ~8,000 patients that met the following criteria
  - On statin drugs to control their cholesterol levels
  - Had triglycerides between 150 and 500
  - LDL cholesterol was roughly in the 70s (“healthy” levels of LDL)
  - And they also had to have either a history of heart disease or some other risk factors (like having diabetes for example)

-Intervention:

- Product was Vascepa (generic name icosapent ethyl)
- 4 grams a day of this EPA
- It’s an ethyl ester, so it’s a very purified EPA that has a ethyl ester, which is the typical way that they concentrate Omega-3’s nowadays.
- There was a placebo as well which was 4 grams of a mineral oil placebo

–*What did the study show?*

- 25% reduction in risk for overall cardiovascular events over ~5 years
- “*It was a big hit.*”
- The industry has been searching for a drug to pair with statins that can help improve outcomes over statins
- This worked great because there were no side effects and you can take it with any other medications

-Issues with the study (Peter’s take)

- One of the issues with this study is the inclusion criteria assumes that the patients have very high triglycerides
- I must have received 12 emails in the span of a day from patients of mine saying, “Hey, should I be taking this?” To which my answer was, “Well, your triglycerides are 86, so I’m going to go with no on that, because I can’t infer that the mechanism by which this worked in these patients is going to have a benefit in you.”

*-Does Bill believe EPA and DHA, from a cardiovascular standpoint, have benefit in people with normal triglycerides?*

- “Yes” says Bill … “because I don’t think the cardiovascular benefit comes from lowering triglycerides.”

*-Was there any change in LDL-C or ApoB particles?*

- Virtually no change

**What about EPA is reducing cardiovascular events?**

- Bill suggests that it is likely a combination of …
  - **The reduction of inflammation** – To whatever extent a cardiovascular event is precipitated by an inflammatory event, the omega-3 EPA could participate in that.
  - **Improving (increasing) heart rate variability** – a marker of autonomic nervous system control of the heart

*Are the benefits of taking EPA transmitted through the conversion to DHA?*

- No, it’s probably all the benefits of EPA are transmitted through EPA, not through conversion to DHA
- In fact, when giving EPA, the red blood cell DHA level go down a little bit
- In other words, if EPA is being converted to DHA, it’s just increasing the substrate pool of DHA, but not necessarily the incorporation into cell membranes

## Potential benefits of ALA and how it compares to taking EPA and DHA directly [1:12:45]

*Could you ever get close to 4 grams of Omega-3 by taking* [*ALA*](https://en.wikipedia.org/wiki/Alpha-Linolenic_acid) *(like flaxseed oil or flaxseed tea)?*

- No

*Are we missing something by only looking at the* [*Omega-3 index*](https://omegaquant.com/what-is-the-omega-3-index/) *of red blood cell membranes?*

- Red blood cell membranes are the easiest to look at
- And it also correlates really well with cell membranes in [other parts of the body](https://www.ncbi.nlm.nih.gov/pubmed/27637336) (like the [heart](https://www.ahajournals.org/doi/full/10.1161/01.cir.0000142292.10048.b2) and [intestines](https://www.ncbi.nlm.nih.gov/pubmed/24913088))

*Potential benefits of ALA?*

- You can’t get a meaningful amount of EPA or DHA from ingesting ALA
- But there is some epidemiological studies suggesting higher ALA intake is associated with reduced risk of disease (but not because it’s converted to EPA and DHA)
- So Bill doesn’t have a problem with ALA, but he would have a problem with someone taking it in lieu of taking fish oil

> “I have no problem with ALA. I just have a problem with it being a substitute for fish oils, for omega-3, long chain omega-3s, because it doesn’t. But ALA itself, I don’t think it’s a bad idea to take ALA products, rich oils, as well as take fish oils.”

## Health benefits of DHA [1:17:15]

First, we haven’t had a study that looks at [DHA](https://en.wikipedia.org/wiki/Docosahexaenoic_acid) alone (like REDUCE-IT did with EPA)

*But what is Bill’s best guess as to what DHA is doing?*

- Much the same thing as EPA
- Anti-inflammatory ⇒ DHAs are called protectins (EPA is resolvins)
- DHA will also improve platelet function like EPA does (but with a different mechanism)
- DHA is probably better than EPA at actually *lowering triglycerides* and *raising HDL*
- Although DHA does have an [LDL raising effect](https://www.ncbi.nlm.nih.gov/pubmed/21975919/) (particularly in people who are hypertriglyceridemic taking fairly high doses of DHA)
  - B/c of this some will say that the EPA plus DHA products are not good for you because they have DHA which can raise LDL (“*But I think that’s a big stretch and misses a lot of caveats.*”)

## Cell membrane omega-3 index—What is it, the role of genetics, how to increase it, and a recommended target [1:19:00]

- DHA is more commonly found in our red blood cell membranes
- Typically something like 85/15 ratio DHA to EPA
- Peter, for example, said his recent lab work showed his membranes had ~10.2% EPA plus DHA but 2.2% was EPA and 8% was DHA
- You can find this out by looking at the fatty acid composition of the red blood cell membranes (aka the [Omega-3 index](https://omegaquant.com/what-is-the-omega-3-index/))

**Can your Omega-3 index (EPA plus DHA) of your membranes ever be too high?**

- Peter has a patient who takes ~3 grams of fish oil daily and has an [Omega-3 index](https://omegaquant.com/what-is-the-omega-3-index/) of 16%
- Bill says that he hasn’t seen any adverse effects in even in doses of 5-6 grams of EPA+DHA
- Bill says Peter’s patient is in the 99.9 percentile but that he’s seen patients with 20+% Omega-3 index (without taking supplements)
- In short, Bill doesn’t see any reason to worry about an Omega-3 index getting too high

**Genetics play a role in your membrane makeup**

- Bill points out that eating oily fish and supplementing will increase the likelihood of having a higher omega-3 index
- However, some people have higher than average indexes without eating more than maybe one fish meal a week
- Here’s [Bill’s study](https://www.ncbi.nlm.nih.gov/pubmed/30773210) looking at ~3,500 people suggesting that to give yourself a 50% chance of having an index of 8% or more you need to eat 3 oily fish meals per week AND take a supplement
- But at the same time there were examples of people who did nothing more than eat 1 fish meal per week and still had an index over 8% (rare but they did exist)

**Do you have a recommendation for physicians or patients, who are monitoring EPA and DHA levels in red blood cells, for a target?**

- Bill likes to see an [omega-3 index](https://omegaquant.com/what-is-the-omega-3-index/) (which is EPA plus DHA in red cell membranes) of 8% to 12%
- The average American is around 4% to 5%

## Is EPA or DHA neuroprotective? Can it help with depression? [1:23:30]

Peter says there was/is some hype around neuroprotective benefits of DHA

*What is the latest on this?*

- Bill says it starts with the observation that the brain and the retina are very rich in DHA (virtually no EPA in the brain)
- People jump to the conclusion that therefore if you give more DHA, you’re going to get better brain health and better eye health.
- Well, that’s hasn’t necessarily panned out, says Bill

-For example, in depression studies…

- DHA products don’t seem to help with depressive symptoms
- In fact, products that are richer in [EPA work better for depression](https://www.nature.com/articles/s41398-019-0515-5)
- How might EPA be doing this?
  - EPA is probably providing some unique anti-inflammatory effects in the brain circulation in a way that DHA doesn’t

> “I don’t think we can at this point say [EPA or DHA] is better than the other for any given system. They come together in nature in all fish . . . It’s not 50/50. It’s usually 60/40 or 40/60 in terms of ratio, EPA to DHA. So I think that’s the best thing to do, is to get both of them at this point for any condition, all conditions.”

## Recommended fish to eat for EPA and DHA – Any mercury concerns? [1:25:45]

Fish high in EPA/DHA:

- Salmon
- Herring
- Mackerel
- “Almost all the oily fish are going to have high EPA levels”

Fish that have a lot of mercury:

- Tilefish
- Swordfish
- King mackerel
- Shark

What about tuna?

- Bill thinks it’s mostly safe to eat tuna despite some people’s mercury concerns
- Albacore tuna has twice the EPA+DHA has light chunk tuna
- But it has more mercury than light chunk tuna

In general, Bill thinks people are far too concerned about mercury and will unfortunately forego EPA/DHA benefits because of this:

> “ I think people get that balance way out of wack. They’re far more concerned about miniscule amounts of mercury, and they will forgo the good benefits of EPA and DHA in a food like albacore tuna, white tuna, because they’re afraid of the small amount of a toxin. The benefits of eating fish, even if there’s some mercury in it, far outweigh the downside of the mercury.”

**⇒ Lab test for mercury**: [Quicksilver Scientific](https://www.quicksilverscientific.com/all-products/mercury-test-kit/)

- Peter says that there is a ton of variability in people’s response to mercury
- Peter says that body’s ability to clear mercury is actually more important than the intake
- And this lab test might help people understand their sensitivity to it

## Can omega-3 mitigate risks associated with smoking? [1:29:15]

**Honolulu Heart Program suggesting a reduced amount of lung cancer in smokers who had high omega-3 levels**: [Fish intake may limit the increase in risk of coronary heart disease morbidity and mortality among heavy smokers. The Honolulu Heart Program.](https://www.ncbi.nlm.nih.gov/pubmed/8790031/)

**Papers suggesting omega-3 can mitigate some adverse effects of smoking**:

- [Macular Degeneration](https://www.healio.com/ophthalmology/retina-vitreous/news/print/ocular-surgery-news/%7B250aeab1-702f-42c0-a1f7-d4fd4735d51b%7D/smoking-and-omega-3-fatty-acids-shown-to-affect-amd-in-twin-study)
- [Smoking is reduced when taking omega-3](https://www.sciencedaily.com/releases/2014/11/141106101903.htm)

## The problem with the omega-6 to omega-3 ratio [1:30:00]

-Our main source of [linoleic acid](https://en.wikipedia.org/wiki/Linoleic_acid) (LA) comes in corn oil and soybean oil

-LA is an omega-6 oil

-After eaten, LA gets converted to [arachidonic acid](https://en.wikipedia.org/wiki/Arachidonic_acid) (AA)

-LA and AA (i.e., omega-6 oils) are seen as being bad… *where did that notion come from?*

- It came from the observation that omega-6 fat were pro-inflammatory
- And omega-3 were anti-inflammatory
- And since people like things to be black and white (good and bad) …
- They labeled omega-6 as bad
- And the [omega-6:omega-3 ratio](https://en.wikipedia.org/wiki/Fatty_acid_ratio_in_food) was created

**⇒ Bill does NOT like this ratio**: “*I think it doesn’t make any sense, partly because it presumes that the omega-6s actually are bad, and they really aren’t.*”

**The latest science looking at omega-6**:

- A [meta analysis](https://www.ncbi.nlm.nih.gov/pubmed/30971107) looking at plasma linoleic acid levels (omega-6 levels in the blood) and followed the development of heart disease and diabetes over 5 to 30 years found a “very clear signal” that the more LA eaten, the lower the risk of heart disease
- They also looked at AA levels and found it was neutral… it didn’t make any difference

*What’s the correlation between arachidonic acid level and linoleic acid level?*

- Virtually none, says Bill
- Less than 1% of the linoleic acid we eat gets made into arachidonic acid
- Arachidonic acid is very tightly controlled in the body and it’s not driven by a linoleic acid

**Problems with the omega-3/omega-6 ratio**

- The total omega-6 to omega-3 is it doesn’t define what the fatty acids are (is the omega-3 ALA or is it EPA, for example)
- Secondly, the fact that you can have the same ratio of omega-6 to omega-3 with **very high** levels of omega-6 and omega-3 or **very low** levels of omega-6 and omega-3 **doesn’t make any sense**
- Additionally, it presumes that the omega-6 is bad and the omega-3 is good

-Another commonly cited ratio is the AA to EPA ratio… *How does Bill feel about this metric?*

- It’s a little bit better
- At least defines which fatty acids you’re talking about
- I don’t think it’s any more informative, says Bill
- And it’s a ratio that presumes arachidonic is bad (arachidonic is not only made into pro-inflammatory, it’s made into anti-inflammatory molecules too)

## The problem with labeling any kind of fatty acid as “bad” [1:36:00]

- There are 100 different metabolites that get made from these molecules…
- and it’s virtually impossible to study all of them in-vivo, together.
- You can take one particular metabolite and sprinkle it on a cell in a test tube and see what it does and then write a paper on it…
- but it may have nothing to do with reality because in reality you got 100 different molecules all banging on the door fighting with each other. One balancing the other.
- “It’s an incredible dance that you can’t replicate outside of the body.”
- People draw conclusions about certain fatty acids being bad or good based on really naive views of the complexity of the biology
- What’s most compelling is looking at blood levels of fatty acids and who’s actually having diseases (i.e., *Who’s getting sick?*)

> “At the end of the day if omega-6 levels are high and that’s associated with reduced risk for diabetes and heart disease, that’s a very powerful testimony to me that the omega-6s are good.”

## Why increasing EPA and DHA intake matters more than reducing omega-6 intake [1:38:00]

Does Bill view oils like canola, safflower, sunflower, etc. to be “unhealthy” in any quantity?

- First, Bill points out that canola oil and safflower oil have virtually the same fatty acid composition as olive oil (the “healthy” oil)
- Originally, safflower oil was ~77% linoleic acid (omega-6) and now it’s down to 15%

![](https://peterattiamd.com/wp-content/uploads/2019/12/Fig-7.-comparison-of-dietary-fats-billharris-1024x676.png)

**Figure 7. Comparison of dietary fats.** Image credit: [canolagrowers.com](https://canolagrowers.com/resource/dietary-fat-chart/)

- The refining process has replaced most of the omega-6 with omega-9 (monounsaturated)
- Bill goes as far as saying that reducing our omega-6 intake might lead to an **increased** risk for major diseases
  - That comment was based on looking at the correlation between heart disease and LA that shows as you eat more LA, your heart disease risk goes down

-Peter pushes back on this…

- The problem with that type of data is that we superimpose the use of statins and advanced cardiac life support and defibrillators and smoking
- It seems that we’re on more stable ground saying that EPA and DHA are protective
- “*I’m still at a bit of a loss as to what to say about omega-6.*”

**Bill’s main points are**:

- Omega-6 is not the evil it’s presented to be
- What’s most important is that we increase our EPA+DHA intake
- And we need to stop getting “hung up” on reducing omega-6 or improving our ratio
- Instead, we should pay attention to our [omega-3 index](https://omegaquant.com/what-is-the-omega-3-index/)

> “The problem is the lack of EPA and DHA. If you get those up, your arachidonic levels will go down. If you want to lower arachidonic take fish oil, and so your ratios will change. You can change ratios all day long by just changing the denominator. And what I don’t like about AA/EPA ratio or omega-6 to omega-3 is it distracts people from the real problem which is the lack of EPA and DHA. It lets them run and say, “Okay, I can fix my ratio by eating less omega-6 and not eating more omega-3.” That doesn’t help. Whereas if you just look at the omega-3 index, EPA, DHA, that’s your focus. If it’s too low, fix it, raise it up. Everything else will settle out.”

*Is it better to get our EPA and DHA from eating fish compared to taking supplements?*

- It’s unlikely that we are “missing” some benefit of the fish by just doing supplements
- That said, Bill prefers to increase EPA and DHA with fish consumption if possible
- But… there’s a lot of challenges with that ⇒ personal taste, cost, ecological issues
- So EPA plus DHA supplements are a fine (and easier) way to do it

## Important takeaway from the VITAL study [1:46:30]

**The VITAL study**

- Summary of findings found [here](https://www.vitalstudy.org/findings.html)
- NEJM publication found here ⇒ [Marine n−3 Fatty Acids and Prevention of Cardiovascular Disease and Cancer](https://www.nejm.org/doi/full/10.1056/NEJMoa1811403)

**-The subjects** of the study were ~25,000 “healthy” people who did NOT have high TG

**-The dose** was 850 mg of EPA/DHA in the form of one Lovaza capsule

**-The results**:

- If you read the abstract, or saw what the press reported, you’d say “it didn’t work”

–**The problems…**

- They were looking for an effect of less than one gram a day of EPA and DHA (i.e., low dose)
- And they were looking at a composite endpoint of several different elements (cardiovascular disease, (Stroke, non- fatal stroke, non-fatal heart disease, cancer, etc.)
- Most of the endpoints were not affected
- But one was affected tremendously ⇒  there was a 20% reduction in heart attacks
- Bill’s says, “that’s impressive for 850 milligrams a day”
- There was some really positive stuff in this study, but it was buried in the press headlines that said, “Fish oils don’t work,”

**The important takeaways from the VITAL study**:

- What likely prevented it from reaching the clinical and statistical significance one would want to move forward is a combination of i) the dose, ii) the patient population that was studied, and iii) the composite endpoints chosen
- Together those characteristics can conspire to have a neutral study when there really are some good effects that are overlooked
- Additionally, the extreme safety, accessibility, and affordability of these supplements are completely overlooked

-Bill says there’s not much (if any) differences in a pharma-grade product like Lovaza compared to OTC supplements

- That said, the REDUCE-IT study used pure EPA which you can’t really buy as a dietary supplement
- Peter says the closest you can get is something like Nordic Naturals EPA products that skew heavily in the direction of EPA in their EPA to DHA ratio
  - [EPA](https://www.nordicnaturals.com/consumers/epa)
  - [EPA Xtra](https://www.nordicnaturals.com/consumers/epa-xtra)

## Importance of testing your omega-3 index [1:53:00]

Bill would like to stress the importance of measuring your [omega-3 index](https://omegaquant.com/what-is-the-omega-3-index/)

- The omega-3 index is testing the EPA and DHA content in your red blood cells

“I just think we need to see more doctors measuring omega-3 status because it means a lot. Low omega-3 means something . . . I really want to encourage people to make the assessment of omega-3 status in their patients as important as measuring cholesterol.”

**OmegaQuant**

- [OmegaQuant](https://omegaquant.com/) is Bill’s company that he has run for the last 10 years or so
- They have an [Omega-3 Index test](https://omegaquant.com/shop/) you can order online and take at home
- It’s a finger stick test that you do yourself and mail back the sample
- There are other places to do a comparable test (True Health, for example)
- The target is to be between 8-12%

\*TIP: Don’t do a **plasma** omega-3 test and expect to see numbers that high

- The plasma levels are lower (but they do correlate pretty well with the red blood cells)
- Red cells are much more stable, long term marker of omega-3 status than plasma

*How often should you test this?*

- Bill says maybe once every 4 months
- It takes about **4 months after you make a change in your omega-3 intake to see a new steady state**

## Exciting study coming out soon, and why you need to take your fish oil with food [1:57:15]

**Bill is excited about a study called** [**STRENGTH**](https://clinicaltrials.gov/ct2/show/NCT02104817)

- Currently in progress and expects to report results in late 2020
- The study is similar to the [REDUCE-IT study](https://www.ncbi.nlm.nih.gov/pubmed/31707829?dopt=Abstract) in that it’s looking at a similar patient population (high TG and other risk factors) and looking at outcomes after 5 years
- The dose is 4 grams per day
- But it differs in that the drug is [EPANOVA](https://www.astrazeneca-us.com/media/press-releases/2014/epanova-press-release-20140506.html#) which is EPA+DHA (as opposed to pure EPA in REDUCE-IT)
- Additionally, the pill is NOT ethyl esters, it’s a free fatty acid version
- The free fatty acid version is more readily absorbed and ethyl esters so this might mean a bigger increase in the omega-3 index
- Bill thinks this study will be more successful than REDUCE-IT

***IMPORTANT TIP*** *about taking omega-3 supplements in the* ***ethyl ester*** *form*:

- You need to take it WITH food
- When taking it on an empty stomach, the absorption is almost zero
- The ethyl ester needs to have enzymatic conversion in the gut
- This is in contrast to free fatty acids which doesn’t require any enzymatic conversion to get absorbed
- But a free fatty acid version of fish oil may not be available until after this study concludes

§

## Selected Links / Related Material

**Bill’s metabolic ward study in 1980 looking at salmon oil’s effect on cholesterol and triglycerides: first really metabolic ward study**: [The effects of salmon oil upon plasma lipids, lipoproteins, and triglyceride clearance.](https://www.ncbi.nlm.nih.gov/pubmed/7195627) (Harris and Connor, 1980) [7:45, 36:15]

**Greenland eskimo studies**: [8:30, 38:00, 44:00]

- [PLASMA LIPID AND LIPOPROTEIN PATTERN IN GREENLANDIC WEST-COAST ESKIMOS](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(71)91658-8/fulltext) (Bang et al., 1971)
- [The composition of the Eskimo food in north western Greenland.](https://www.ncbi.nlm.nih.gov/pubmed/7435433) (Bang et al., 1980)
- [MARINE OILS AND THROMBOGENESIS](https://knoesis.org/researchers/delroy/projects/swanson-rfo/full-text/01-6302714-dyerberg.pdf) (Dyerberg and Jørgensen, 1982)

**A number of studies suggest that broadly speaking, polyunsaturated fats, mostly omega-6s, actually showed a reduction in total cholesterol**: [Omega-6 polyunsaturated fatty acids: Is a broad cholesterol-lowering health claim appropriate?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3971029/) (Bazinet and Chu, 2014) [24:45]

**George McGovern’s senate committee recommending a reduction in saturated fat**: [McGovern’s Senate Select Committee on Nutrition and Human Needs Versus the: Meat Industry on the Diet-Heart Question (1976–1977)](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3910043/) (Oppenheimer and Benrubi, 2014) [24:00]

**Study showing EPA goes to DHA but DHA does not go to EPA**: [Compound-specific isotope analysis reveals no retroconversion of DHA to EPA but substantial conversion of EPA to DHA following supplementation: a randomized control trial.](https://www.ncbi.nlm.nih.gov/pubmed/31204771) (Metherel et al., 2019) [35:30]

**1978 Lancet paper proposing that EPA was an anti-platelet (blood thinning fatty acid) and that is why it prevented blood clots, and that is why Eskimos didn’t have heart attacks**: [Eicosapentaenoic acid and prevention of thrombosis and atherosclerosis?](https://www.ncbi.nlm.nih.gov/pubmed/78322) (Dyerberg et al., 1978)  [40:45]

**EPA may slightly decrease mean platelet volume (about the same as Aspirin)**: [EPA, but not DHA, decreases mean platelet volume in normal subjects.](https://www.ncbi.nlm.nih.gov/pubmed/12530552) (Park and Harris, 2002) [41:45]

**Eskimo studies created a paradigm where a high saturated fat diet produced very little heart disease which lead Danish investigators to study them which lead to the discovery of Omega-3 fatty acids**: [Fish oils and plasma lipid and lipoprotein metabolism in humans: a critical review.](https://www.jlr.org/content/30/6/785.full.pdf) (Harris, 1989) [44:00]

**The three Omega-3 studies published in the same NEJM issue in May of 1985**: [46:00]

1. *Bill’s 1985 paper in NEJM giving very high doses of Omega-3 which showed huge drops in triglycerides*: [Reduction of plasma lipids, lipoproteins, and apoproteins by dietary fish oils in patients with hypertriglyceridemia.](https://www.ncbi.nlm.nih.gov/pubmed/3990714) (Phillipson et al., 1985) [46:00]
2. [The Inverse Relation between Fish Consumption and 20-Year Mortality from Coronary Heart Disease](https://www.nejm.org/doi/full/10.1056/NEJM198505093121901) (Kromhout et al., 1985)
3. [Effect of Dietary Enrichment with Eicosapentaenoic and Docosahexaenoic Acids on in Vitro Neutrophil and Monocyte Leukotriene Generation and Neutrophil Function](https://www.nejm.org/doi/full/10.1056/NEJM198505093121903) (Lee et al., 1985)

**Bill’s later studies showed patients with lipid disorders could significantly reduce their triglycerides with fish oil**: [Effects of four doses of n-3 fatty acids given to hyperlipidemic patients for six months.](https://www.ncbi.nlm.nih.gov/pubmed/1832701) (Harris et al., 1991) [46:30]

**Bill’s study showing 6 grams/day of EPA and DHA in capsule form made triglycerides go down very nicely, but LDL cholesterol started to go up**: [Changes in lipoprotein composition in hypertriglyceridemic patients taking cholesterol-free fish oil supplements.](https://www.ncbi.nlm.nih.gov/pubmed/2375788) (Inagaki and Harris, 1990) [47:45]

**DHA may turn down LDL receptor activity which could explain the increase in LDL particles**: [LDL cholesterol-raising effect of low-dose docosahexaenoic acid in middle-aged men and women.](https://www.ncbi.nlm.nih.gov/pubmed/15051597) (Theobald et al., 2004) [49:45]

**Fredrickson classification of familial hyperlipidemias—type IV**: [Familial hypertriglyceridemia](https://en.wikipedia.org/wiki/Familial_hypertriglyceridemia) | (wikipedia.org) [51:15]

**First companies to get FDA approved omega-3 drugs**: [52:30]

- [Lovaza](https://www.drugs.com/pro/lovaza.html) | (drugs.com)
- [Omacor](https://www.drugs.com/omacor.html) | (drugs.com)

**The two brands of fish oil that Peter recommends to patients**: [54:30, 1:51:45]

- [Carlson Labs](https://carlsonlabs.com/the-very-finest-fish-oil/)
- [Nordic Naturals](https://www.nordicnaturals.com/consumers/omega-3-in-fish-gelatin)

**NY Times article by Anahad O’Connor about fish oil brands and****contaminants**: [What’s in Your Fish Oil Supplement?](https://well.blogs.nytimes.com/2014/01/22/whats-in-your-fish-oil-supplements/?mtrref=www.google.com&gwh=A9E9C4FEFAE3E5A3A751BD1D762D06FA&gwt=pay&assetType=REGIWALL) | Anahad O’Connor (nytimes.com) [54:30]

**Cardiovascular benefits of EPA and DHA**: [Erythrocyte long-chain omega-3 fatty acid levels are inversely associated with mortality and with incident cardiovascular disease: The Framingham Heart Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6034629/) (Harris et al., 2018) [57:45]

**The REDUCE-IT study—Big study using EPA only**: [59:15, 1:44:45, 1:57:30]

- *Rational and methods*: [Rationale and design of REDUCE-IT: Reduction of Cardiovascular Events with Icosapent Ethyl-Intervention Trial.](https://www.ncbi.nlm.nih.gov/pubmed/28294373?dopt=Abstract) (Bhatt et al., 2019)
- *Jan 2019*: [Cardiovascular Risk Reduction with Icosapent Ethyl for Hypertriglyceridemia.](https://www.ncbi.nlm.nih.gov/pubmed/30415628?dopt=Abstract) (Bhatt et al., 2019)
- *June 2019*: [Effects of Icosapent Ethyl on Total Ischemic Events: From REDUCE-IT.](https://www.ncbi.nlm.nih.gov/pubmed/30898607?dopt=Abstract) (Bhatt et al., 2019)
- *Nov 2019*: [REDUCE-IT USA: Results from the 3,146 Patients Randomized in the United States.](https://www.ncbi.nlm.nih.gov/pubmed/31707829?dopt=Abstract) (Bhatt et al., 2019)

**Drug used in REDUCE-IT study**: [Vascepa](https://www.vascepa.com/) [59:50]

- *Generic name for Vascepa*: [icosapent ethyl](https://en.wikipedia.org/wiki/Ethyl_eicosapentaenoic_acid) [1:03:00]

**Vascepa is made by this company**: [Amarin](https://amarincorp.com/) [59:50]

**Japanese trial using EPA drug**: [Effects of eicosapentaenoic acid on major coronary events in hypercholesterolaemic patients (JELIS): a randomised open-label, blinded endpoint analysis.](https://www.ncbi.nlm.nih.gov/pubmed/17398308) (Yokoyama et al., 2007) [1:04:30]

**FOURIER trial looking at PCSK9 inhibitors**: [Evolocumab and Clinical Outcomes in Patients with Cardiovascular Disease](https://www.ncbi.nlm.nih.gov/pubmed/28304224) (Sabatine et al., 2017) [1:06:15, 1:48:15]

**ODYSSEY trial looking at PCSK9 inhibitors**: [Efficacy and Safety of Alirocumab in Reducing Lipids and Cardiovascular Events](https://www.ncbi.nlm.nih.gov/pubmed/25773378) (Robinson et al., 2015) [1:06:15, 1:48:15]

**Omega-3 content in red blood cell membranes correlates with other cells in different body parts**: [Red blood cell PUFAs reflect the phospholipid PUFA composition of major organs.](https://www.ncbi.nlm.nih.gov/pubmed/27637336) (Fenton et al., 2016) [1:14:30]

- *Omega-3 content in red cells membranes correlates well with heart cell membranes*: [Omega-3 Fatty Acids in Cardiac Biopsies From Heart Transplantation Patients](https://www.ahajournals.org/doi/full/10.1161/01.cir.0000142292.10048.b2) (Harris et al., 2004) [1:14:30]
- *Intestines*: [Is the omega-3 index a valid marker of intestinal membrane phospholipid EPA+DHA content?](https://www.ncbi.nlm.nih.gov/pubmed/24913088) (Gurzell et al., 2014)

**Some hints in epidemiologic studies that higher ALA intakes is associated with reduced risk for disease**: [Intake of alpha-linolenic acid and risk of coronary heart disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4301411/) (Vedtofte et al., 2014)  [1:16:15]

**DHA does have an LDL raising effect (particularly in people who are hypertriglyceridemic taking fairly high doses of DHA**: [Effects of eicosapentaenoic acid versus docosahexaenoic acid on serum lipids: a systematic review and meta-analysis.](https://www.ncbi.nlm.nih.gov/pubmed/21975919/) (Wei and Jacobson, 2001) [1:18:00]

**Bill’s study that found out that people who eat 3 oily fish meals per week AND take a supplement had a 50% chance of having an 8% omega-3 index and anything less than that would diminish the odds HOWEVER there were still people in the group who at something like one fish meal per week and have 8+% (they were just the outliers)**: [Association of reported fish intake and supplementation status with the omega-3 index.](https://www.ncbi.nlm.nih.gov/pubmed/30773210) (Jackson et al., 2019) [1:21:45]

**Meta analysis suggesting EPA has more benefit on depression than DHA**: [Efficacy of omega-3 PUFAs in depression: A meta-analysis](https://www.nature.com/articles/s41398-019-0515-5) (Liao et al., 2019) [1:24:30]

**The lab that does mercury testing**: [Quicksilver Scientific](https://www.quicksilverscientific.com/all-products/mercury-test-kit/) | (quicksilverscientific.com) [1:28:15]

**Honolulu Heart Program suggesting a reduced amount of lung cancer in smokers who had high omega-3 levels**: [Fish intake may limit the increase in risk of coronary heart disease morbidity and mortality among heavy smokers. The Honolulu Heart Program.](https://www.ncbi.nlm.nih.gov/pubmed/8790031/) (Rodriguez et al., 1996) [1:29:15]

**Papers suggesting omega-3 can mitigate some adverse effects of smoking**: [1:29:45]

- *Macular Degeneration*: [Smoking and omega-3 fatty acids shown to affect AMD in twin study](https://www.healio.com/ophthalmology/retina-vitreous/news/print/ocular-surgery-news/%7B250aeab1-702f-42c0-a1f7-d4fd4735d51b%7D/smoking-and-omega-3-fatty-acids-shown-to-affect-amd-in-twin-study) | (healio.com)
- *Smoking is reduced when taking omega-3*: [Omega-3 reduces smoking, study suggests](https://www.sciencedaily.com/releases/2014/11/141106101903.htm) | (sciencedaily.com)

**Meta analyses found a “very clear signal” that the higher the level of linoleic acid in the blood, the lower the risk of heart disease suggesting omega-6s may not be “bad”**: [Biomarkers of Dietary Omega-6 Fatty Acids and Incident Cardiovascular Disease and Mortality.](https://www.ncbi.nlm.nih.gov/pubmed/30971107) (Marklund et al., 2019) [1:32:00]

**The VITAL study—testing EPA and DHA in relatively healthy people**: [1:46:20]

- *Summary of findings found here*: [Study Findings](https://www.vitalstudy.org/findings.html) | (vitalstudy.org)
- *NEJM publication*: [Marine n−3 Fatty Acids and Prevention of Cardiovascular Disease and Cancer](https://www.nejm.org/doi/full/10.1056/NEJMoa1811403) (Manson et al., 2019)
- *Drug used*: [Lovaza](https://www.drugs.com/pro/lovaza.html) | (drugs.com)

**Nordic Naturals EPA products (which is just a higher percentage of EPA to DHA than fish oil)**: [1:52:45]

- [EPA](https://www.nordicnaturals.com/consumers/epa)
- [EPA Xtra](https://www.nordicnaturals.com/consumers/epa-xtra)

**Bill’s company that does at home testing for omega-3 index (which is EPA plus DHA in red cell membranes)**: [OmegaQuant](https://omegaquant.com/) | (omegaquant.com) [1:53:50]

- *The $50 at home test for Omega-3 index*: <https://omegaquant.com/shop/>

**The big study called STRENGTH currently in progress looking at benefits of EPA/DHA in patients with high TG and other risk factors**: [Outcomes Study to Assess STatin Residual Risk Reduction With EpaNova in HiGh CV Risk PatienTs With Hypertriglyceridemia (STRENGTH)](https://clinicaltrials.gov/ct2/show/NCT02104817) | (clinicaltrials.gov) [1:57:15]

**The drug being used in the STRENGTH study**: [EPANOVA](https://www.astrazeneca-us.com/media/press-releases/2014/epanova-press-release-20140506.html#) | [1:57:30]

**EPANOVA is made by this company**: [AstraZeneca](https://www.astrazeneca-us.com/) | [1:57:30]

§

## People Mentioned

- [Tom Dayspring](https://peterattiamd.com/tomdayspring1/) [6:50]
- [Bill Connor](https://www.oregonlive.com/news/2009/11/the_scientist_whose_pioneering.html) [7:00]
- [J. Dyerberg](https://www.ncbi.nlm.nih.gov/pubmed/?term=Dyerberg%20J%5BAuthor%5D&cauthor=true&cauthor_uid=7435433) (Eskimo studies) [8:45]
- [H.O. Bang](https://www.ncbi.nlm.nih.gov/pubmed/?term=Bang%20HO%5BAuthor%5D&cauthor=true&cauthor_uid=7435433) (Eskimo studies) [8:45]
- [George McGovern](https://en.wikipedia.org/wiki/George_McGovern) [25:45]
- [Anahad O’Connor](https://twitter.com/anahadoconnor?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [54:30]
- [Barry Sears](https://www.amazon.com/gp/product/B005UKHA0S/ref=dbs_a_def_rwt_hsch_vapi_tkin_p1_i5) [1:30:30]
- [Bill Lands](https://en.wikipedia.org/wiki/William_E.M._Lands) [1:30:30]
- [Artemis Simopoulos](https://en.wikipedia.org/wiki/Artemis_Simopoulos) [1:30:30]

§

![](https://peterattiamd.com/wp-content/uploads/2019/12/bill-harris-bio-bill-harris-500x500.jpg)

##### Bill Harris, Ph.D.

Dr. Harris is an internationally recognized expert on omega-3 fatty acids and how they can benefit patients with heart disease. He obtained his Ph.D. in Human Nutrition from the University of Minnesota and did post-doctoral fellowships in Clinical Nutrition and Lipid Metabolism with Dr. Bill Connor at the Oregon Health Sciences University.

His interest in omega-3 fatty acids began with his postdoctoral work when he published his first study on the effects of salmon oil on serum lipids in humans (1980). Since that time he has been the recipient of five NIH grants for studies on the effects of omega-3 fatty acids (EPA and DHA) on human health. He has more than 300 publications relating to fatty acids, including omega-3s, in medical literature and was an author on two American Heart Association scientific statements on fatty acids: “Fish Consumption, Fish Oil, Omega-3 Fatty Acids and Cardiovascular Disease” (2002), and “Omega-6 Fatty Acids and Risk for Cardiovascular Disease” (2009) both published in the journal Circulation.

Dr. Harris is a Professor in the Department of Medicine in the Sanford School of Medicine at the University of South Dakota and the President and CEO of [OmegaQuant](https://omegaquant.com/).

[omegaquant.com]