# #202 – Peter on nutrition, disease prevention, sleep, and more — looking back on the last 100 episodes

**Source:** [https://peterattiamd.com/strong-convictions-loosely-held-2/](https://peterattiamd.com/strong-convictions-loosely-held-2/)

---

In this second edition of the “Strong Convictions, Loosely Held” episode, Peter discusses topics on which his thoughts have evolved as a result of his interviews with podcast guests and other information he’s gained since episode 100. Peter covers topics including cancer therapy and screening, as well as prevention strategies for cardiovascular disease and Alzheimer’s disease. He also describes changes in his perspectives on time-restricted feeding and protein consumption and on the therapeutic use of psychedelics, and he discusses some sleep supplements with remarkable efficacy. He ends with a special discussion on all things Formula 1 racing.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/strong-convictions-loosely-held-2/the_Drive_public.png)

Play

#202 - Peter on nutrition, disease prevention, sleep, and more — looking back on the last 100 episodes

#202 - Peter on nutrition, disease prevention, sleep, and more — looking back on the last 100 episodes

1x15s30s

0:001:57:28

## We discuss:

- The concept of “strong convictions, loosely held” [3:10];
- Update on Peter’s upcoming book [8:30];
- Cancer: the promise of immunotherapy [14:15];
- Cancer: how aggressive screening for gastrointestinal cancers could save lives [24:30];
- Cardiovascular disease: how early and aggressive lowering of apoB could change the course of ASCVD [31:30];
- Alzheimer’s disease: genes that modify risk associated with the APOE4 variant [40:15];
- Time-restricted feeding: where the benefit comes from, and when this practice can be problematic [44:00];
- The common problem of protein underconsumption [51:45];
- The tremendous impact of exercise on lifespan and healthspan [54:45];
- Peter’s shoulder surgery [1:00:15];
- An uninspiring viewpoint on NAD precursors as a longevity tool [1:06:15];
- Psychedelics: a powerful therapeutic tool in the right setting [1:09:30];
- Sleep: updated thoughts on blue light and a remarkable drug for aiding sleep quality [1:13:15];
- Book recommendation from Peter [1:20:45];
- Formula 1: the 5 variables that determine the winner [1:22:00];
- F1: the drivers [1:26:00];
- F1: the tires [1:27:30];
- F1: the engine and chassis [1:32:00];
- F1: rule changes around cars [1:34:15];
- F1: importance of qualifying races [1:41:15];
- F1: racing strategy [1:47:30];
- F1: season outlook and predictions [1:51:00]; and
- More.

§

## Show Notes

## The concept of “strong convictions, loosely held” [3:10]

Previous “strong convictions, loosely held” episode: [#103 – Looking back on the first 99 episodes: Strong Convictions, Loosely Held](https://peterattiamd.com/strong-convictions-loosely-held/)

\*\*\*

**Explaining the phrase “strong convictions loosely held”**

- Peter is unsure where this phrase came from originally
- However, Peter first heard it from his friend, [John Griffin](https://www.investopedia.com/articles/investing/031216/john-griffins-success-story-net-worth-education-top-quotes.asp), who used to run a very successful hedge fund
  - When talking about his investment philosophy, John says that you have to invest based on strong convictions, but they need to be loosely held, and so you have to constantly update your assumptions with new information
  - if you’re more interested in staying with a position as opposed to evolving your position, you’re probably not going to be a very good investor
- This can be related to our understanding of science and medicine
  - Unfortunately, it’s probably our default setting to dig our heels in on a position
- Ironically, in politics especially, it’s viewed as a sign of weakness or being wishy-washy when you change your mind
- For this very reason, Peter has consternation about his upcoming book release which he started writing in 2016 — “*I can promise you that there are things that I’m going to have changed my mind on that will be in print*.”
  - In contrast, this is why he loves podcasts so much because you can do exactly what we are doing right now which is being able to consolidate all the changes in how he thinks about stuff

## Update on Peter’s upcoming book [8:30]

- The draft was insanely long, but it’s in the process of being cut down
- The manuscript was close to 200,000 words, but the hope is to get it down to about 120,000 words
- Peter’s coauthor is [Bill Gifford](https://twitter.com/billgifford?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) and they are relentlessly pushing each other to figure out how this can be said in fewer words
- This is the perfect example of “killing your babies”
  - Peter was giving great advice in medical school when writing his first scientific paper
  - “I put so much work into it, and I had all of these figures and all of these tables”
  - One of the guys he was working with in the lab said, “Look, you got to learn to kill your babies. You’re going to do 20 experiments that are not going to make their way into the paper, and that’s going to feel awkward. It’s going to feel like, ‘No, no, I need to show you, as the reader of this paper, everything I’ve done and every experiment and every iteration.”
- Similarly, with a book, there’s a part of Peter that wants the reader to see how much work has gone into this but, of course, that doesn’t make for a good book
  - “*So, there’s lots of baby killing going on now. I hope that that will make it better*.”
- The last big stress is over the audiobook version — he’s currently looking for a good reader for the book as Peter doesn’t want to be the voice for the book for various reasons

## Cancer: the promise of immunotherapy [14:15]

Peter says there are three disease topics where his thinking today is either more clear or different than it was before:

- i) cancer
- ii) atherosclerotic cardiovascular disease (ASCVD), and
- iii) Alzheimer’s disease

**Cancer: the promise of immunotherapy**

- Peter is excited about the promise of immunotherapy for cancer
- His excitement came out of the research he did to prepare for a [podcast with Steve Rosenberg](https://peterattiamd.com/stevenrosenberg/)
- And one of the things that really blew his mind was the fact that [80% of patients have neoantigens on their cancers that are recognized by their immune system](https://aacrjournals.org/cancerdiscovery/article/9/8/1022/41919/Unique-Neoantigens-Arise-from-Somatic-Mutations-in)

*Why is that so significant?*

- Well, the holy grail of cancer therapy is undoubtedly immunotherapy
- In other words, anytime you can get the immune system to recognize your cancer as nonself, you get to use a cellular systemic system that could eradicate a tumor without the toxicity and failures basically associated with systemic therapies like chemotherapy
- That said, historically speaking, very few people have a cancer where the immune system can automatically recognize it at sufficient force to eradicate it
- There are a couple such patients like that, that Steve Rosenberg saw during his training, that basically formed the impetus for his life’s work
- But there’s another subset of patients typically with cancers like melanoma and renal cell cancer, which have a high mutagenic burden where they might not have enough immune cells to recognize and kill the cancer completely without any prompting, but if you prompt them with a cytokine, like interleukin-2 at a very high dose, that is sufficient for their T cells to go and eradicate the cancer
- To put that number in context, we’re talking about 10 to 20% of people with metastatic melanoma or renal cell cancer will respond to that
  - These are patients who would otherwise be dead in six months, and they would now go on to have durable remissions

**Checkpoint inhibitors**

- The next step would be using something called a checkpoint inhibitor—drugs that block the checkpoints on immune cells.
- By dropping these checkpoint inhibitors on patients—so things that block either CTLA-4 or PD-1 being the two most well studied of these—we have the same effect
- It tends to only work in patients that either have specific mutations or patients that, again, have a very high mutagenic burden
- But when you look at the fact that 80% of patients have neoantigens on their cancers that are recognized by their immune system, yet only about 10% respond really well to immunotherapy and/or checkpoint inhibitors, *what about those other 70% of people?*
- What this finding gives us hope for is that we may, in fact, be able to use some combination of tumor infiltrating lymphocytes, TIL, or adaptive cell therapy where you genetically engineer T cells with that recognition
- So, the reason that those patients aren’t having spontaneous remissions or aren’t responding to interleukin-2 or even checkpoint inhibitors is because they probably **don’t have enough of those T cells yet**
- This now becomes just as much a bioengineering problem as it is an immunology problem
- You have to be able to recognize those cells (turns out it’s pretty easy to do)
- Then you now have to be able to expand them in a manner where they still have the longevity necessary to go in and be infused into patients and basically arrest and eradicate their tumors

> “I really think that in 10 years we’re going to basically be using designer-based immunotherapies to eradicate most solid organ metastatic cancers.” —Peter Attia

*Why does Peter think this is so doable?*

- Because the main impediment to this is cost
- If every single person has to have their own TIL or adaptive cell therapy regimen created, that could be a $200,000+ to generate
- But the reality of it is, when you compare this cost to the cost of cancer therapeutics today, the cost of doing designer-based immunotherapies might actually be less especially when you do it on a quality adjusted life year basis
- For instance, today it’s not uncommon to spend $80,000 on a treatment that extends life by four months
- Well, would you rather spend $80,000 on something that’s going to extend life four months or $300,000 on something that’s going to extend life indefinitely with respect to cancer?

**Follow up questions**:

*What does metastatic mean?*

- Metastatic means the ability of the cancer cells to spread beyond their primary site of origin
- This is one of the two hallmarks of cancer that differentiates it from a normal cell
  - E.g., If you have somebody with colon cancer, what is it about the colon cancer cells that is different from the regular colon cells? ⇒ One of them is this ability to leave the colon and go someplace else
  - Colon cancer cells could now grow in the liver, whereas regular colon cells, if you put them in the liver, wouldn’t grow
- The second hallmark of cancer is the inability to respond to cell cycle signaling
  - For instance, a regular cell from the colon will respond to signals that tell it to stop growing
  - So, if you have an injury to the colon, it will respond appropriately and grow to heal, but then it will stop growing once it’s told
  - Colon cancer cells won’t do that
- Those are the two hallmarks — not responding to growth signal stopping and being able to spread

*What is a solid organ tumor?*

- Solid organ tumors are basically anything that is not a leukemia and lymphoma
- Leukemias and lymphomas probably account for about 20% of cancer deaths
- Solid organs about 80% of cancer deaths
- Almost every time we hear about somebody dying of cancer—colon cancer, breast cancer, prostate cancer, brain cancer—those are what we call epithelial tumors, to be more technically correct.

***Is 10 years the timeline where this becomes a possibility, or is that the timeline where it becomes widely available to the mass public?***

- 10 years might be aggressive for this to be the standard of care, but 10 years would be the time when it’s going to be out of clinical trials and something that’s going to be available at least to some
- it might not be something that is covered by insurance, which would then immediately limit to a fraction of the population the people that could get this
- Best case scenario is it goes straight from very successful clinical trials directly to something that Medicare reimburses for, because unless Medicare and Medicaid reimburse for this type of treatment, it could never be widespread, regardless of how successful it is

## Cancer: how aggressive screening for gastrointestinal cancers could save lives [24:30]

**Screening for gastrointestinal cancers**

- Peter has an increased aggression when it comes to screening for gastrointestinal cancers
- For perspective, in 2020 there were about 600,000 people in the US that died of cancer
- 170,000 of the 600,000 were in the GI system (so mouth to anus)
- Some of those GI cancers are very difficult to screen for.
- Pancreatic cancer, for instance, we don’t really have a great way to screen for it, and that’s why we use things like diffusion-weighted image MRIs, liquid biopsies, as ways to basically pursue those things
  - See [episode #61 with Raj Attariwala](https://peterattiamd.com/rajpaulattariwala/) where they talked about diffusion-weighted imaging MRI for cancer screening

The good news is that there are a lot of cancers for which we can directly take a look at the epithelial surface that is going to become cancerous

- And there is no part of that that is more important than the colon
- The esophagus, the stomach, and the colon probably represent about 40% of those GI cancers
- Liver and intrahepatic, bile duct, and pancreas are probably also about 40%, and those are much harder to screen for
- But when you look at *organ-specific* sites, colon cancer is generally in the top three leading causes of death for both men and women

**Bold and controversial opinion from Peter**: “*Nobody should ever die from colon cancer.*” (same for esophageal and stomach)

- The reason for that is that the progression from non-cancer to cancer is visible to the naked eye, through the transition of nonmalignant polyp to malignant polyp

\*Thought experiment: if you did a colonoscopy on somebody every single day of their life, they would never get colon cancer because, at some point, you would see the polyp, you would remove it while it is non-cancerous, and they would not get cancer

- So… *how do you turn that thought experiment into a real life idea?*
- You have to ask the question: *what is the shortest interval of time for which a person can have a completely normal colonoscopy until they can have a cancer?*
- There’s no clear answer to this question — some case reports that it can happen in as little as six to eight months
- Most people would agree that if you had a colonoscopy every one to two years, the likelihood that you could ever develop a colon cancer, while maybe not zero, is so remote that you could effectively take colon cancer off the list of the top 10 reasons why someone dies of cancer

Peter says: “*It’s for that reason that I’m very aggressive when it comes to this type of screening, which also includes upper endoscopy…you basically get for free the esophagus and stomach when you look at the entire colon, rectum, anus*.”

*What are your costs/downsides to more frequent screening?*

- Financial costs — it’s not cheap
- Risk of the sedation — not zero risk but very small
- Risk of perforation — also incredibly small risk

*Ideal frequency?*

- “I can’t tell you yet what the ideal frequency, but it’s much more frequently than what’s being done today”
- It’s not every 5 to 10 years, it’s probably every **one to three years**

\*Additional Resources:

- [Episode #61 with Raj Attariwala](https://peterattiamd.com/rajpaulattariwala/)
- Weekly email from Peter: [Colorectal cancer screening](https://peterattiamd.com/colorectal-cancer-screening/)

**Age to start colorectal cancer screening**:

- Peter screens patients starting at age 40 if they have *no history of colon cancer*
- This is earlier than most doctors recommend so you may have to push your doctor (and insurance company) to get this done
  - Tip – send them Peter’s [weekly email](https://peterattiamd.com/colorectal-cancer-screening/)

## Cardiovascular disease: how early and aggressive lowering of apoB could change the course of ASCVD [31:30]

**How Peter has changed on ASCVD**: He’s become far more aggressive on the timing and magnitude of ApoB reduction

*What are the leading causes or modifiable causes of ASCVD?*

- Big three:
- i) smoking,
- ii) hypertension, and
- iii) hyperbetalipoproteinemia
  - Fancy word for saying too many lipoproteins that have ApoB on them (LDL, IDL, VLDL, Lp(a))

**Measuring ApoB**

- Peter is such a fan of measuring ApoB as opposed to just measuring LP, LDL, particle number, or LDL cholesterol number because we have one single number that captures the total concentration of ApoB
- While that’s pretty well associated with non HDL cholesterol—which is a far better surrogate than LDL cholesterol—it’s still better and that’s been demonstrated
  - A [previous podcast](https://peterattiamd.com/tomdayspring3/) covered the discordance between non HDL cholesterol and ApoB

The question becomes: “***When should you start ApoB reduction and how much should you lower it?***”

- Some numbers: The 20th percentile of ApoB is about 80 milligrams per deciliter
- Let’s say somebody was at the 50th percentile, they’re 40 years old, their calcium score is zero, and they were ambivalent about lipid lowering therapy and let’s assume that they’re not insulin resistant and you’ve done all of the things that you can do reasonably with nutrition
- In the recent past, Peter wouldn’t push that hard to take action
- Today, he takes a very different stance which is **treat early and treat aggressively**

**Bold statement incoming**: If you pharmacologically lower ApoB to somewhere in the 20 to 30 milligram per deciliter range for everybody in the population while someone is in their 20s, can you eliminate ASCVD?  ⇒ *I think the answer is probably yes*

- In other words, what you’re basically going to do is eliminate death from atherosclerotic causes
- How do you take that thought experiment and turn it into a practical implication?
- Well, it’s not really practical to take every 20 year old and obliterate their ApoB (although this could and should be done with patients with significant genetic abnormalities that result in familial hypercholesterolemia)
- Practically what it means is basically by the time you’re in your late 30s or early 40s, if you have any measure of ApoB that’s even north of the 20th percentile, that should be completely lowered
- Peter views the “ceiling” to be ~60 milligrams per deciliter
- Peter wants everybody to be below the 5th percentile

\*Additional resources:

- Check out [AMA #34](https://peterattiamd.com/ama34) for a deep dive into ASCVD
- [Episode #185 with Allan Sniderman](https://peterattiamd.com/allansniderman/)

Rough percentile numbers:

- 5th percentile = 62 (from the [Framingham Offspring Study](https://framinghamheartstudy.org/participants/participant-cohorts/))
- 10th percentile is about 70
- 20th percentile is about 78
- 50th percentile is about 97
- 80th percentile is 118
- 95th percentile is about 140

> “I just don’t see a reason to have an ApoB ever north of 60 milligrams per deciliter.” —Peter Attia

**How to lower ApoB**:

- When you look at a lot of the Mendelian randomizations plus the clinical trial data, if you have an LDL cholesterol below 30 or an ApoB below 40 milligrams per deciliter for a very long period of time, I think the odds that you’re going to suffer for ASCVD are incredibly low
- The earlier you start and the lower you go the more you can make that number approximate zero

And therefore it then only becomes a question of: W*hat are your therapeutic choices to get there?* And *how do you do this in a way that minimizes the side effects of that?*

- Because for some people to lower ApoB that much is trivial — Peter takes a PCSK9 inhibitor and a statin and he can basically eradicate it
- But for some people, statins are difficult to tolerate
  - About 5% of the population has intractable muscle soreness and that appears to be the case regardless of which statin you use and we tend to rotate through different statins
- Peter likes to start patients with rosuvastatin or pravastatin
- If they have difficulties there, move to pitavastatin (Livalo)
- But if people can’t tolerate any of those things, today we have so many other options
  - If they’re a hyper absorber we would use ezetimibe
  - if they’re a hyper synthesizer, but can’t respond to statins, we use mefenamic acid
- “*We have lots of tools up our sleeve today more than ever before and that’s why I just think we should be more and more aggressive on this now*.”

## Alzheimer’s disease: genes that modify risk associated with the APOE4 variant [40:15]

**Changes in thought related to Alzheimer’s disease**: When it comes to Alzheimer’s disease, Peter’s focus on genes outside of APOE is now pretty significant

- It turns out that there are a lot of genes that seem to modify the risk of APOE
- APOE has three subtypes, e2, e3, and e4
- Everyone has a pair meaning there are six possible combinations
- The fourth isoform (e4) is the high risk one
- If you’re a e2/e4 it seems to, more or less, be a wash with maybe slight increase in risk
- The e3/e4 seems to be associated with about a 2x-3x increase in risk in Alzheimer’s disease
- The e4/e4 probably has about an 8x-12x increase in risk
- But even though everything above is true at the population level, it doesn’t explain what happens at the **individual level**
- There are some individuals who walk around with e4/e4 who don’t seem to get Alzheimer’s disease or if they do, they get it very late in life

**Genes that modify the risk of the e4 variant**

- It turns out that there are a bunch of other genes that we’re now starting to understand, modify the risk of e4 (some genes make it more significant, some genes make it less)
- So there are certain haplotypes of the TOMM40 gene that amplify risk
- There are certain mitochondrial haplotypes that amplify risk
- One of the most exciting genes is the Klotho modifier
  - KL-VS is the modified snip of klotho that actually seems to erase all of the downside of APOE4
  - So APOE4 people who have this klotho subtype have baseline risk

*Prospects of identifying these genes in individuals*

- Unfortunately the ways to measure these other genes, it’s very challenging and we have to do it by brute force today
  - it takes a lot of time and costs a lot of money to take a whole genome sequence and do the search for all of these other subtypes
  - A big step in the right direction here is going to be getting more data and getting those data for less than $20,000 per person.
- W*hen might this be practical to do for people*?
  - Probably sooner than 10 years from now
  - This is a solvable problem technically speaking, it’s just about throwing enough dollars at it

## Time-restricted feeding: where the benefit comes from, and when this practice can be problematic [44:00]

**Things on the nutrition front where Peter has become more pointed in my feelings over the past roughly two years**:

–*Peter now believes more strongly that* ***most of the benefit of time restricted feeding is accrued through caloric restriction***

- He’s always been a little unsure of how much of the time restriction was exerting its benefit through factors that go beyond what is likely a reduced calorie intake in someone with a smaller feeding window
- In other words, *was there something magical about not eating?*
  - “I think the answer is no.”
  - When people talk about how time restricted feeding is helping them lose weight and manage insulin resistance and things like that, it appears that’s all due to reduced caloric intake (It’s just harder to eat more during a narrower window)
- Where this gets problematic:
  - This can be an issue in people who can’t really afford to lose too much muscle
  - Because they’re eating so much less protein, they’re impairing muscle protein synthesis so they’re actually losing lean mass even while putting on fat mass.
  - Hypothetical example: A patient who becomes completely obsessed with only eating in a six hour window or even less and at the end of a year, they’ve lost five pounds
    - They were normal-ish weight to begin with
    - a year later they’re 5 lbs lighter and they’re like, “Ah, this is just amazing. I’ve lost five pounds. I feel like I can eat whatever I want”
    - Then you do a DEXA scan on them and you realize, “Well, you lost 10 pounds of lean tissue and you gained five pounds of fat mass”
    - So yes, you’re down five pounds, but your body fat is actually up.
    - Your body fat’s up 3%. Your visceral fat is up by 500 grams.
    - Nothing has moved in the right direction except this very, very crude measurement of the number on the scale

**Body composition: What we are looking for with a DEXA scan**:

- [DEXA](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry) scans are the most practical and useful way to measure important body composition metrics
- It’s not the single most accurate way to do it—there are more accurate ways to do them—but those would all be done in a research setting
- DEXA is relatively inexpensive, $100 in most places.
- And the information it yields is also segmental, which is really valuable
- When we do a DEXA scan, we’re looking at lots of information (bone mineral density, total body fat, and more)
- But what Peter is really interested in is: what’s your **fat free mass index** (FFMI)– that’s the total lean tissue in kilograms divided by height in meters squared
- Another metric is appendicular lean mass index (ALMI) which is the same as the FFMI, except it’s only using the lean mass of the four limbs, not including the torso
- Also looking at visceral adipose tissue (VAT)

*Rank by age and sex*

- The idea is you’re putting all of these things on a nomogram to see where you rank for your age and sex
- That’s where people need to be really focused
- “I care much more about those metrics than I care about your total body fat percent” says Peter
- “If your body fat percent is at the 40th percentile, but your ALMI, FFMI are at the 90th percentile and your VAT is at the 10th percentile, I think that’s perfectly adequate”
- Total body fat in some ways comes down to a little bit of vanity once the biomarkers are themselves also great

## The common problem of protein underconsumption [51:45]

Taco Bell protein commercial:

\*\*\*

- Most people are not eating enough protein
- The recommended daily allowances (RDA), are “pathetic” says Peter
- The RDA for protein is roughly 0.8 grams per kilogram of body weight
- You take an 80 kilogram person, so someone that weighs like about 175, and that person should only be eating 65 grams of protein a day or “something asinine like that”
- The RDA is likely predicated on how much protein you need to like live versus how much protein you need to thrive
- We probably need closer to two grams per kilogram or about a gram per pound of body weight

**Regarding concerns about the toxicity of excess protein**:

- The concern is that if you consume enough protein you’re going to overtax the kidneys because that’s how we excrete the excess nitrogen.
- And you’re looking at somewhere in the order of three to four grams per kilogram before you get into the places where you’re going to start to challenge your kidney’s abilities to take care of excess nitrogen

**Lack of protein in middle-aged women**:

- It seems to be a really big problem in middle aged women
- Especially in women that show up with no muscle mass, eating no protein, doing very little strength training
- “*To me that is a recipe for a shorter life, but more importantly, a lower quality of life*.”

\*Additional Resource: [Follow-up conversation Layne Norton](https://peterattiamd.com/laynenorton2)

## The tremendous impact of exercise on lifespan and healthspan [54:45]

**How Peter’s feeling about exercise has evolved**: He’s more sold than he’s ever been on the importance of exercise in someone’s longevity

- Peter has really come to appreciate the magnitude of the value that is brought to a person’s lifespan and healthspan by having higher cardiorespiratory fitness and more strength
- And you can’t add strength without strength training

⇒ See Peter’s [post to instagram](https://www.instagram.com/p/CapXi-yOixe/) on the importance and impact of exercise

- When you look at the improvements in all-cause mortality by moving up from below average, to average to above average, and so on…
- …your all cause mortality drops and it drops at levels that aren’t appreciated by any other intervention
  - So comparing someone with end-stage renal disease to someone who doesn’t have it
  - a smoker to a non-smoker
  - someone with type two diabetes to someone who does not
  - those thing above are all big multipliers of risk
  - But they’re dwarfed by the multiplier in risk that you would go from having a very high VO2 max to a low VO2 max
- Note: These associations have lots of interplay with other variables—There’s some genetic component to this, there’s obviously a healthy user bias, etc.
- But the point here is if you can get yourself to exercise versus not, that’s a big driver of mortality reduction
- And the VO2 max becomes one way that we can track the progress you’re making on that metric.
- Similarly with strength, similarly with muscle mass, and things like that

**Strength vs. muscle mass**

- Turns out that strength matters more than muscle mass (See [AMA #27](https://peterattiamd.com/ama27/))
- But muscle mass is a very good proxy for strength

*Grip strength*

- Peter is two days now post-op from his surgery on his right shoulder and it’s really interesting how much he’s noticed his grip is weaker in my right hand
- “*So not being able to recruit the full musculature of my shoulder and scapula on the right means I actually have slightly weaker grip in my right hand*.”
  - (That’s why he thinks grip strength is a great proxy for longevity.)
- It’s always been known to be that way and the question is **why?**
  - There’s lots of reasons
  - Among them it’s just a great proxy for overall body strength and muscle mass, but I think it’s also a very functional form of strength
  - Basically everything in your upper body is mediated through your hands.
  - if your grip is weak, everything downstream of that is weak
  - When you watch someone who’s got a weak grip deadlifting, it’s very difficult for them to deadlift correctly because they don’t create a proper wedge. They don’t create enough tension between the bar and their torso because their grip is weak
    - if they don’t create that tension, they’re going to compromise their lift
- H*ow do you train for grip strength*?
  - First, a lot of carrying things
    - Peter will do a lot of super sets
      - I’m doing a farmer’s carry in between other workouts
      - One of his favorites is [SkiErg machine](https://www.google.com/search?q=skierg&sxsrf=APq-WBuq3Bk7SlyAAtD055o9JvUBIbBGBQ:1648493769383&source=lnms&tbm=isch&sa=X&ved=2ahUKEwjr86bsven2AhVwlmoFHZhIBHMQ_AUoA3oECAIQBQ&biw=739&bih=695&dpr=2) — one minute, all out SkiErg followed by a one minute farmer’s carry with about 70 pounds in each hand
  - Secondly, dead hangs from a pull up bar
    - Peter’s PR is 4 min, 35 sec

## Peter’s shoulder surgery [1:00:15]

Some videos after Peter’s shoulder surgery (warning: graphic content): [1](https://www.instagram.com/p/CbaOfeqj_9P/), [2](https://www.instagram.com/p/Cba0yjjOsRF/), [3](https://www.instagram.com/p/CbcuBijjEnL/), [4](https://www.instagram.com/p/CbgIzqlDUxi/), [5](https://www.instagram.com/p/CblUETMjtgE/)

**About Peter’s shoulder surgery**

- Just had shoulder surgery two days ago and it was to have his labrum repaired in the right shoulder
- Labrum is the fibrous tissue that forms a ring over the sort of flat surface of the scapula called the glenoid fossa
- That ring of labrum is what creates the socket for the ball of the humeral head to stay in that joint
- Because he’s had so many subluxations where that humeral head has popped out of that effective socket, that labrum has become torn
- Over the past 25 years, it’s just been insult after insult after insult so he finally just decided it was time to have this thing fixed

*How this will impact Peter’s workout regimen:*

- Doctors estimate about eight to nine months before he’s back to full strength
- His workouts will change in phases
- For the first four to six weeks, it’s going to be really quite gentle like walking and doing zone 2 rides
- He’ll be switching to the Peloton because it’s easier to sit upright on the Peloton than on his regular bike
- He’ll keep doing his lower body workouts as well as some upper body stuff on his left side
- the reason I was dragging my feet on this surgery was the fear of immobility
- Peter has hypermobile shoulders — “On my left, I was able to have hypermobility without pathology but that’s not the case on the right which ultimately turned into pathology because it was too mobile. (That’s what the frequent subluxations were all about.)

**Mobility recovery**

- When you have labral surgery, you are reducing mobility which is something Peter is very afraid of because of the downstream arthritis and things like that
- He will be moving early and doing so smartly
- He will use blood flow restriction with his KAATSU which is going to be a very important part of that recovery and doing a lot of isometric stuff
  - For example, instead of doing bicep curls with the right, he’ll do isometric pressure with the blood flow restriction so that he’s not putting the stress on the joint but he’s still getting the muscle to work

**A quote from Peter regarding the overall takeaway with exercise**:

> “*The good news is this tool called exercise…has an unbelievable impact on your lifespan and healthspan, probably bigger than anything else, and it’s available to everyone. It has the least barrier to entry. The drawback is it’s the hardest, I think. It takes the most time, that’s for sure, and it’s the most uncomfortable*.” —Peter Attia

## An uninspiring viewpoint on NAD precursors as a longevity tool [1:06:15]

***Anything around molecules (supplements, prescription, drugs, hormones, etc.) you’ve maybe changed your mind about?***

NAD and NAD precursors

- Peter remains quite uninspired by the entire NAD stratosphere
- Two years ago, he was pretty neutral on their ability as a longevity tool
- And today, he’s even less than neutral on them
- There’s evidence that you can take NAD precursors, NR and NMN being the two most common and increase NAD levels
  - “*I think that has been demonstrated. I think two years ago that was not demonstrated as clearly*.”
  - What’s not been demonstrated is that there is a phenotypic benefit from doing that outside of very pathological states
  - In other words, if you take a “normal person,” or a normal aging person and do that, is it bringing any benefit to them in terms of lifespan or health span
- “And I would say the answer right now is, ‘No.’ It’s very difficult for me to get excited about this, even though it generates a tremendous amount of excitement on social media.”
- “I’m not going to be swayed by poorly done studies where outcomes are not pre-selected but are cherry picked and not corrected for.”
- Some of the common problems we see with small exploratory trials that are important to do, but should never be confused with trials that convince us of what’s going on.

## Psychedelics: a powerful therapeutic tool in the right setting [1:09:30]

- Peter worries a little bit about the hyper focus on psychedelics as the catchall cure all to every problem in isolation
- He hears many stories of somebody raving about this shaman in Peru, or this shaman here, or their psychedelic experience being life changing
- But they’re describing something in isolation that he doesn’t think is very durable.
- His intuition is that those types of therapies are incredible tools to create the vulnerability and the environment in which you can do the really deep work
- Therapy should be guided by these types of molecules (e.g., psilocybin and MDMA)
  - “*I think there are a lot of people who are just taking journeys on those things but not really pairing it with the hard work that needs to proceed and follow it to have the lasting benefits*.”
- At the end of the day, Peter thinks psychotherapy is probably the most powerful tool in different forms
  - For example, dialectical behavioral therapy is an amazing type of therapy that’s more tool oriented rather than insight oriented

> “We want to think about ways to use those molecules to prime us to be ready to do that type of therapy, as opposed to just viewing the molecule as the solution.” —Peter Attia

***Update on potential legalization of psilocybin/MDMA for therapeutic purposes?***

- The [phase three data](https://www.nature.com/articles/s41591-021-01336-3) for MDMA have been marching along with a lot of promise, says Peter
- It’s looking at the efficacy of MDMA combined with psychotherapy versus placebo combined with psychotherapy and so far are “demonstrating pretty impressive deltas and improvements in reduction of PTSD symptoms”
- And just as importantly, there’s no toxicity with these molecules
- Peter thinks that using MDMA and, potentially eventually, psilocybin as adjuncts to that type of therapy should be coming to the mainstream soon

**\*Additional resources**:

- [Ep #182 with David Nutt](https://peterattiamd.com/davidnutt/)
- [Ep #65 with Rick Doblin](https://peterattiamd.com/rickdoblin/)

## Sleep: updated thoughts on blue light and a remarkable drug for aiding sleep quality [1:13:15]

**Changing thoughts on the impact of blue light from electronics**

- Peter is less concerned today with the light from electronics before bed — he used to view them as pretty deadly for sleep
- The negative impact on sleep is more likely to do with the stimulation that often accompanies blue light
- So in other words, it might not be your phone per se that is killing your sleep, it might be what you’re doing on your phone (i.e., watching cat videos not so bad, reading stressful emails probably very bad)

**Useful sleep aids and problems with Ambien**

- Phenibut has become impossible to acquire in the US which has lead Peter to look for more appropriate sleep aids
  - Phenibut is a form of GABA and it was over the counter available freely until about two years ago after an incident where kids took too much and ended up in the ER
  - Peter says that Phenibut is an amazing sleep supplement where you could use it frequently without any concern, unlike Melatonin, for example, where you really have to be limited in how much Melatonin you’re using and how often.
- What emerged from his search is [trazodone](https://en.wikipedia.org/wiki/Trazodone)
  - This can be used as a regular maintenance sleep drug
  - Trazodone is an old school antidepressant that inhibits both serotonin transporters and serotonin type two receptors (it’s a serotonin antagonist and reuptake inhibitor)
  - It never really took off as an antidepressant because at the doses that one would use it as an antidepressant (250/300 mg), it created too much drowsiness
  - In the past few years, it has come to be widely accepted that this off-label use for sleep at much lower drugs—typically 25 to 100 milligrams nightly—produces not just remarkable sleep, but more importantly, preserves sleep architecture
- The key with sleep medications is not being “unconscious” because that means you’re not promoting sleep architecture
  - For instance, Ambien might increase total sleep time slightly, but it’s actually reducing slow wave or deep sleep by 5% to 10% so you’re trading good quality sleep for low quality sleep
  - In the one study on Ambien, you see no change in REM sleep, a reduction in non-REM deep sleep with a slight increase in total sleep, suggesting all you did was add more light sleep
  - Ambien can also cause short term memory loss which can be dangerous

**More on trazodone**:

- It actually doesn’t work for everybody (maybe 20% of people)
- For some people it just doesn’t produce any sedation
- There are others for whom we just can’t get the right dose — so even at low doses, it produces so much sedation that the next day they’re still groggy in the morning
- But for most people (80%+), there is a dose between 25 and 100 milligrams before bed that produces remarkable sleep, both in quality, duration and lack of interruption
- It also doesn’t have the dependency issues that other sleep drugs often have, including benzodiazepines, which aren’t horrible for sleep architecture
- Getting trazodone prescribed to you by your doctor shouldn’t be too difficult as it’s getting a pretty reasonable amount of acceptance amongst doctors that are reasonably well read

\***Resources for data on trazodone and sleep**:

- Data on the mechanism of action: [Shin and Saadabadi, 2021](https://www.ncbi.nlm.nih.gov/books/NBK470560/#:~:text=Mechanism%20of%20Action&text=Trazodone%20reduces%20levels%20of%20neurotransmitters,alpha%2D1%2Dadrenergic%20receptors.)
- Data on the efficacy:
  - [Yi et al., 2018](https://pubmed.ncbi.nlm.nih.gov/29680424/)
  - [Fagiolini et al., 2020](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7099841/)
- Data on stage preservation: [Wang et al., 2020](https://www.frontiersin.org/articles/10.3389/fpsyt.2020.00620/full)

## Book recommendation from Peter [1:20:45]

***Is Peter reading any good books lately?***

[The Comfort Crisis](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1648656078&sr=8-1) by [Michael Easter](https://twitter.com/Michael_Easter?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

- Peter liked this book so much he’s already reached out to the author to have him on the podcast
- “I recommend it highly.” says Peter

*About the book*:

- Basically, we are in a comfort crisis, meaning we are way too comfortable now
- We live in a world where we’re never hungry, we’re never cold, we’re never hot, we’re never bored, etc.
- That level of comfort can have really negative outcomes on our mental health and our physical health
- The open questions are: *How can you exploit that information? What can you do in your comfortable world to get appropriate doses of things that are uncomfortable to recoup some of the benefits?*

## Formula 1: the 5 variables that determine the winner [1:22:00]

**Advice for people wanting to get into watching Formula 1**

- A good place to start is with the show [Drive to Survive](https://www.netflix.com/title/80204890) on Netflix
- There are really five variables that determine who’s going to win a race (4 having to do with how fast the car goes plus 1 for strategy)
- You can be perfect on all four of those things, but if you have the wrong strategy you’re going to lose.
- The four things are:
  - 1 – The skill of the driver
  - 2 – The tires – only point of contact between the car and the surface
  - 3 – The engine – generates the power
  - 4 – The chassis – what allows that power to be transmitted to the tires and it confers the aerodynamics that are necessary to go fast on curves (which is really what differentiates F1 from any other class of motor racing—it’s not how fast those cars can go in a straight line, how much down force they can generate)

## F1: Drivers [1:26:00]

- 10 F1 teams and 2 drivers per team (an A and B driver)
- Usually one of the two drivers is the more senior driver
  - [Team Ferrari](https://www.formula1.com/en/teams/Ferrari.html) is an expectation where this year with [Charles Leclerc](https://en.wikipedia.org/wiki/Charles_Leclerc) and [Carlos Sainz](https://en.wikipedia.org/wiki/Carlos_Sainz_Jr.) – both of those guys could win (in that case the team is unlikely to employ what’s called “team orders” which is when the team tells one of them to get out of the way if the other one is behind)
  - That’s one thing you see in the Drive to Survive is those team dynamics…just because they’re on the same team, they’re still competition with each other
- On some teams that competition between the drivers on the same team is the most fierce because technically the cars are close to identical so if that person is constantly beating you, there’s no ambiguity about who’s a better driver

## F1: Tires [1:27:30]

**Does every team have access to the same tires?**

- [Pirelli](https://www.pirelli.com/global/en-ww/homepage) has been the tire manufacturer in F1 about six years now
- Sometimes you’ve had different tire manufacturers in the same year—certain teams would use Bridgestone while others would use Michelin, Goodyear, all sorts of things

**The different types of tires**

- But now, Pirelli has seven tire options – there are seven tires that you have (two for wet weather)
- For each race they designate a soft, medium and a hard
- The five tire compounds are C1, 2, 3, 4, and 5 in increasing hardness
- They might say C1, 2, 3 are the soft, medium and hard for one particular race (Or it could be 2, 3, 4 or 4, 5, 6)
- If you look at the tire rim you’ll know it’s a soft tire because it’s red
- The medium for that race is the yellow
- And the hard is the white
- Then the “intermediate” is a green tire with an intermediate tread
- Then the blue tire is the full weather tire and that has a more aggressive tread
- The **more tread you have, the slower the tire** is between the intermediate and the wet.
- The soft, medium and hard are the slick tires

**The tradeoff with tire types**

- The trade off here is the harder the tire, the longer it lasts and the slower it is because it has less grip
- So one of the rules of F1 is— unless it’s a wet or intermediate tire, those situations are aside—but when you’re using any of the dry tire compounds, you must use at least two tires of two different compounds in a race
- What that means is even if this were a race that were short enough that you could get away with just the hard tire, you can’t do it, you have to make at least one pit stop to switch to a different tire compound
- Certain races like [Bahrain in March 2022](https://www.formula1.com/en/results.html/2022/races/1124/bahrain/race-result.html), you’ll see multiple pit stops from the teams because the tire degradation of that circuit is so high

*Is that where a lot of the strategy comes in on which tires are used at which point of the race?*

- Yes. And also when you switch and how many times you switch
- For example, you could run a race on a hard and a medium and do one switch, whereas someone else might do a soft medium and medium and do two switches.
- Every time you switch tires, you have a guaranteed time hit of roughly 25/26 seconds (slow down to enter the pit, have the actual tire change)
- Tire changes are taking about 3 seconds this year (last year it was closer to 2 seconds)
- Last year was just a little over two seconds. So it doesn’t sound like much but, again, that’s a relatively small price you’re paying relative to how much you have to slow down to drive into and enter the pits.

*So under what scenario would you risk an extra pit stop, which costs you 25 seconds to do two stops when someone else is doing one?*

- The answer is, if you can make up half a second per lap on a 50 lap race with a different tire strategy, then you would stay out
- By the way, there’s always a risk when you do a pit stop that something goes wrong and that three second of actual tire changing becomes 10 seconds (if anything goes wrong and a bolt gets wedged or something strips, it can be the end of the race)

## F1: the engine and chassis [1:32:00]

As far as engines go, there are only a handful of engine manufacturers in F1

Last year, you had four manufacturers:

- 1 – Mercedes
  - The Mercedes engine is used by McLaren, Williams, and Mercedes
- 2 – Ferrari
  - Ferrari engine is used by Ferrari, Alfa Romeo, and Haas
- 3 – Renault (the Alpine team)
  - Renault is only used by Alpine
- 4 – Honda
  - Honda engine is used by Red Bull (Honda’s team) as well at AlphaTauri
  - Honda left the sport last year, but Red Bull preserved the rights to the engine so Red Bull is still using a Honda engine as is AlphaTauri

This is different from IndyCar…

- In IndyCar, everybody’s on the same engine and the same chassis
- In that sense, there’s something that IndyCar has that’s better than Formula One, which is everybody’s basically in the same car which makes the setup and the driver and the strategy play a bigger role
- Keep in mind, even though Mercedes makes the engine, you can’t assume that the same engine is in the Williams car
- William’s is really not getting exactly the same engine — the engine that the Mercedes team is using, that is built by them, everything about their car is tailored to how to use it
- So Ferrari has the best Ferrari engine, Mercedes has the best Mercedes engine
- The chassis is also important
- For instance, Aston Martin has a Mercedes engine, but Aston Martin makes the chassis, so it’s hard to imagine that they could ever do as good a job as Mercedes is doing because Mercedes gets to design their chassis to pair it to a Mercedes engine.
- So you end up with very different equipment in F1.

## F1: rule changes around cars [1:34:15]

**Periodic rule changes**

- Every few years you get a rule change
- This year there was a major rule change after 8 years

**Recent regime changes follow rule changes**

*2011-2013*

- A huge regime change in F1 was in 2013 to 2014
- Prior to 2013, Red Bull was the most dominant team of that era
- In 2011, ’12 and ’13, [Sebastian Vettel](https://www.formula1.com/en/drivers/sebastian-vettel.html) with Red Bull won the F1 title, and he almost won in 2009
- And for all intents and purposes, Red Bull and Vettel dominated F1 for five consecutive years

*What happened in 2014?*

- The hybrid turbo era was introduced
- Then Mercedes became the most dominant team ever in the history of F1 by winning eight out of eight Constructors’ Championships and seven out of eight Drivers’ Championship.

**Two championships every year**

- 1 – Drivers’ Championship, which is awarded to the driver with the most points
- 2 – Constructor’s Championship, which is the constructor with the most points
- Those are two are not always the same, meaning, it’s not always that the team that the driver drives for is going to win
- To do that, you would have to have two relatively strong drivers, which Mercedes has historically had
- Although last year, a Red Bull driver, Max Verstappen won the Drivers’ Championship, but Mercedes was still hands down the best team and won the Constructors’ Championship because Max Verstappen and Sergio Perez had fewer points for Red Bull than Lewis Hamilton and Valtteri Bottas had for Mercedes

**New rule changes**

*Rule changes for making it easier to pass other cars*

- Now, the new rules that were introduced for this year are going to readjust the pecking order
- The rules basically came down to how to make the cars more competitive and how to create more wheel-to-wheel racing that basically reduced the down force of the cars, which means that when a car is following another car, it is less susceptible to the dysregulation of airflow going over it
- Formula One cars are basically like airplanes flying upside down…
  - So an airplane flying right side up, the more speed going in front of the airplane, the higher goes up. That’s what lift is
  - The force of lift is equal to the surface area of the wing times the velocity squared times the coefficient of lift
  - So that’s why when a plane reaches its terminal height and terminal velocity, it turns down the coefficient of lift, so it doesn’t just keep going up
  - Formula One race car is an upside down airplane—the faster it goes, the harder it’s being pushed down
  - To put this in perspective, last year’s cars had so much aerodynamics that once they hit about 50 to 60 miles per hour, they were generating down force that exceeded their weight
  - At less than a hundred kilometers per hour, they could be driving upside down, that’s how much down force they generate
  - So you can imagine, if you have two cars on a straightaway at 300 kilometers per hour, they’re basically stuck to the ground. But if one car is behind another car, which by definition, it needs to be to pass, it’s airflow is being disrupted and it’s losing down force and therefore, it’s slowing down
  - That creates a vicious cycle that makes it difficult to pass. And so, they wanted to make it more competitive and it looks like they’ve succeeded
- Looking at a [recent race](https://www.formula1.com/en/results.html/2022/races/1124/bahrain/race-result.html)
  - The race was basically down to Verstappen and Leclerc until Verstappen’s engine failed.
  - There were five passes between the two of them, something you wouldn’t have seen historically

*Rule change: bigger wheels*

- They’ve also changed the tire size, so the wheels are now bigger wheels which is exciting b/c we’re basically back to square one trying to figure out tires and engines

*Rule change: E10 fuel*

- They also introduced E10 fuel which Peter calls “the dumbest idea ever”
- “*It’s in an effort to be sustainable, which I think is so ironic for F1 to try to be sustainable. It’s like, an easier way to be sustainable might be scheduling races in such a way that you don’t have to fly across the world 27 times as opposed to dropping from proper octane to E10, that has zero bearing on the outcome compared to one cross world flight in the F1 schedule*”

***Results of rule changes so far…***

- But based on those changes, after one race at least, it is looking like this year is going to be not only more competitive in the races themselves in terms of action passing
- But also is it safe to say it’s going to be more competitive in terms of the teams that are competing b/c last year McLaren and Ferrari were battling a little bit for third in the Constructors, but there wasn’t a lot of competition in that

Last year was a pretty good battle between first and second between Mercedes and Red Bull

- But between third and fourth, it wasn’t really much of a battle and that was less on the basis of the cars and probably more on the basis of the performance of a couple of the drivers

This year is just going to be a big reshuffling

- Based on preseason testing, Ferrari and Red Bull looked to be the strongest and McLaren looked to take a step backwards
- By the way, that all looked to be true in that first race—Ferrari looked incredibly strong, going one, two.
- Had [Max Verstappen](https://en.wikipedia.org/wiki/Max_Verstappen) and [Sergio Pérez](https://en.wikipedia.org/wiki/Sergio_P%C3%A9rez) not had a pump failure in their engine in the last three laps, the order would’ve been Ferrari, Red Bull, Ferrari, Red Bull, positions, 1, 2, 3, 4, and Mercedes would’ve been fifth, sixth
- It was clearly Ferrari, Red Bull then Mercedes, and McLaren was way at the back of the pack
- McLaren has two amazing drivers in [Lando Norris](https://en.wikipedia.org/wiki/Lando_Norris) and [Daniel Ricciardo](https://en.wikipedia.org/wiki/Daniel_Ricciardo) so you can’t blame their performance on their drivers
- The other thing we saw was Haas, which for the last couple of years has been the worst team in F1, they had [Kevin Magnussen](https://en.wikipedia.org/wiki/Kevin_Magnussen) finish fifth which is kind of amazing given that they had zero points last year and you get points anytime you’re in the top 10

## F1: importance of qualifying races [1:41:15]

**The schedule for an F1 weekend**

Consists of five sessions, typically

- Always start with Free Practice 1 (FP1) and FP2 on Friday
- Saturday morning is FP3
- Then qualifying (Qualy) is Saturday afternoon
- The race is on Sunday

Free Practice

- The purpose of FP1, FP2, and FP3 is to scrub some tires, to basically get that sheen off them so that you have a nice set of brand new tires to get ready — plus you’re also learning the track
- With FP1 and FP2, it’s very difficult to draw much of a conclusion for how people are going to perform that weekend because they’re really fiddling with the setup of the car
- There are some tracks where you want very little down force such as on a high speed track
  - [Monza](https://en.wikipedia.org/wiki/Monza_Circuit#:~:text='National%20Motor%20Racetrack%20of%20Monza,the%20oldest%20in%20mainland%20Europe.) is the prototypical example—it’s called the Temple of Speed— b/c it’s the fastest track in all of F1 and you have very little down force — meaning you can’t go as fast around the corners, but you can go much faster in the straights
  - Conversely, you have tracks like [Suzuka](https://en.wikipedia.org/wiki/Suzuka_International_Racing_Course) in Japan which is maximum down speed—You have so many high speed corners that you basically say, “*We’re going to put all of our eggs in the down force basket and make sure we can go as fast as possible around these high speed corners, and we’ll give up 15-20 miles per hour of straight line speed*”
- So you have to fiddle with that setup as much as possible during those practice sessions and it’s really only in FP3 on Saturday morning that you get a sense of how fast somebody can go

**Qualys**

- You have what’s called Q1, Q2 Q3
- Q1, everybody goes out for 12-15 minutes and put a lap time down
- At the end of Q1, the top 15 move on and for the bottom 5, their place is determined on the grid by where they finished
- With Q2, you do the same thing again and now it’s the top 10 that go forward to Q3 and places 11 to 14 are set on the grid
- With Q3, the final 10 positions are set on the grid
- That’s virtually how every race works
- Exceptions to this protocol: There are a couple of races last year where they did something called a Sprint qualy where they do an FP1 and then qualy on Saturday and then maybe FP2.
  - They somehow insert an extra race in the schedule on Saturday afternoon
  - That race grid is determined by your position in qualifying, but then how you finish the race determines how you’ll start the race on Sunday
  - It’s a short race, typically 16 laps or something (about a quarter to a third of the length of the total race, no pit stops)
  - How you finish in that race determines your position

*With the qualifying, how many races do you think where it’s more important than others? Meaning, what percentage of the tracks are hard to pass on versus easier to pass on?*

- The track that is almost impossible to pass is [Monaco](https://en.wikipedia.org/wiki/Monaco_Grand_Prix)
- But the analysis you’d do is, *what percentage of races are won by polesitters?*
- in Monaco, that’s going to be the highest b/c it’s such a narrow track making it very difficult to pass
- [Suzuka](https://en.wikipedia.org/wiki/Suzuka_International_Racing_Course) is also a very difficult track to pass on with only a handful of places you can pass
- Historically, [Abu Dhabi](https://en.wikipedia.org/wiki/Abu_Dhabi_Grand_Prix) was one of those tracks where you couldn’t really pass but now they made a lot of changes last year to change the circuit to slow it down a little bit and create more passing opportunities
- All that said, there’s never a scenario where you’re not going to do your best in qualifying because higher grid place is always better
- Note: This is kind of different from the golden era of F1 (80s and 90s) when you could radically change the tuning of a car during qualifying
  - If you look at the McLarens of the mid-80s, they could boost those things to 1,400, 1,600 horsepower during qualifying, and they might race at 800 horsepower
  - There were some drivers like [Niki Lauda](https://en.wikipedia.org/wiki/Niki_Lauda), very famously, would not boost during qualifying — His thinking was, “*It’s freakin’ dangerous. There’s a good chance I’m going to kill myself or blow up the car. . .I’m not going to risk it.*”
  - Conversely, [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) is the best qualifying driver of all time—He took the poll position in something like 63 pole positions out of 161 races
    - Even Lewis Hamilton and [Michael Schumacher](https://en.wikipedia.org/wiki/Michael_Schumacher) are nowhere near that and Hamilton is, statistically speaking, by far the greatest F1 driver of all time
    - But on that one metric, nobody compares to Senna, despite the fact that his [career was cut very short](https://en.wikipedia.org/wiki/Death_of_Ayrton_Senna#:~:text=On%201%20May%201994%2C%20Brazilian,e%20Dino%20Ferrari%20in%20Italy.)

## F1: racing strategy [1:47:30]

***When people are watching on Sundays, what should they be watching for with regards to strategy?***

- It’s understanding how much drivers push the car and when they do it
- A lot of things that determine speed are tires—Softer tires are going to generally be faster, especially new soft tires, but they might only be fast for 10 laps
- And then there is also how you discharge the battery b/c these are turbo hybrid cars so they’re getting probably an extra 160 or 200 horsepower out of a battery
- For context, in qualifying race, there’s a reason there’s so much faster by up to three seconds on a lap—a huge difference
  - The reason is the way the car is tuned for qualifying, the way that they can maximally discharge the battery
- If you listen to the radio communications, you’ll hear them say, “Push, push.” or “Box, box” —Box means pit stop, push means drive faster or push ahead

*Note that drivers can’t go all out all the time*

- They have to protect their tires as well as protect their batteries
- If a driver knows he’s going to go for a big pass, he’s going to have to actually back off a little bit to recharge his battery during a lap, to then be able to make a big mode push
- Then similarly with the tires — for instance, when Verstappen and Leclerc were going back and forth passing each other five times in two laps, they ended up taking quite a bit out of their tires
- When Peter is at a live race, he’s usually timing their splits at a fixed point on the track so he can see what their time degradation looks like per lap

## F1: season outlook and predictions [1:51:00]

***Who is your prediction to win this year, not only the driver, but the team?***

- The smart answer is Ferrari — They looked the most dominant during the two testing weeks and then they finished first and second in the first race
- But it’s a 23-race season and anything can happen
- Red Bull, a strong team, finished with zero points in the first race
  - Peter says if they can figure out what’s wrong with these fuel lines they may come back strong
  - He wonders if there’s an issue with their fuel because they’re using a different fuel from everybody else—they’re using Exxon as opposed to Petronas or Shell—and it might be that Exxon has just shit the bed on this E10 mixture and there’s something not working there
  - On that note, three out of the four Honda engines failed last week so that might be something to keep an eye on
- Ferrari also has two amazing drivers—[Chales Leclerc](https://en.wikipedia.org/wiki/Charles_Leclerc) and [Carlos Sainz Jr](https://en.wikipedia.org/wiki/Carlos_Sainz_Jr.).—Leclerc is probably the better of the two so based on that, Leclerc would be kind of a early favorite
- If Red Bull can figure out what they’re doing, Max Verstappen has a fantastic chance to win
- And finally, how do you bet against Lewis Hamilton and Mercedes?
  - Don’t forget how much they came back last year—Red Bull had almost put that championship away with five races to go and Mercedes and Lewis Hamilton stormed back
  - The difference this year is Mercedes now has two drivers that can really win this thing as opposed to just Hamilton, so you have [George Russell](https://en.wikipedia.org/wiki/George_Russell_(racing_driver))
  - Russell is viewed largely as the heir apparent within the team and that’s why they made the somewhat difficult decision of getting rid of Valtteri Bottas—an amazing wingman to Hamilton—in favor of someone who’s going to be nipping at his heels more, but is also probably the future for Mercedes

*There’s a lot more intriguing storylines and competition based on this first race compared to what we’ve seen in the past…*

- The competition between Lewis Hamilton and George Russell is going to be intense
- The competition between [Charles Leclerc](https://en.wikipedia.org/wiki/Charles_Leclerc) and [Carlos Sainz, Jr.](https://en.wikipedia.org/wiki/Carlos_Sainz_Jr.) could become intense, even though historically they’ve been the most cordial teammates of all time but that could change here
- Those three teams, Ferrari, Red Bull and Mercedes at the top, is going to be intense
- And anybody who’s watched Drive to Survive can appreciate the interpersonal dynamics between [Toto Wolff](https://en.wikipedia.org/wiki/Toto_Wolff) and [Christian Horner](https://en.wikipedia.org/wiki/Christian_Horner), the Mercedes and Red Bull team principles, two guys who can’t stand each other
  - Article: [HORNER BOUGHT HIMSELF A MERCEDES FACTORY TOUR AT A CHARITY AUCTION](https://wtf1.com/post/horner-bought-himself-a-mercedes-factory-tour-at-a-charity-auction/)

§

## Selected Links / Related Material

**Episode of The Drive which was the first edition of the “Strong convictions, loosely held” episodes**: [#103 – Looking back on the first 99 episodes: Strong Convictions, Loosely Held](https://peterattiamd.com/strong-convictions-loosely-held/) | Peter Attia (peterattiamd.com) [3:15]

**Episode of The Drive with Sebastian Junger**: [#195 – Freedom, PTSD, war, and life through an evolutionary lens | Sebastian Junger](https://peterattiamd.com/sebastianjunger/) | Peter Attia (peterattiamd.com) [10:45]

**Episode of The Drive about cancer immunotherapy with Steve Rosenberg**: [#177 – Steven Rosenberg, M.D., Ph.D.: The development of cancer immunotherapy and its promise for treating advanced cancers](https://peterattiamd.com/stevenrosenberg/) [15:00]

**Data showing that 80% of patients have neoantigens on their cancers that are recognized by their immune system**: [80% of patients have neoantigens on their cancers that are recognized by their immune system](https://aacrjournals.org/cancerdiscovery/article/9/8/1022/41919/Unique-Neoantigens-Arise-from-Somatic-Mutations-in) (Parkhurst et al., 2019) [15:45]

**Episode of The Drive discussing diffusion-weighted imaging MRI for cancer screening with Raj Attariwala**: [#61 – Rajpaul Attariwala, M.D., Ph.D.: Cancer screening with full-body MRI scans and a seminar on the field of radiology](https://peterattiamd.com/rajpaulattariwala/) [25:00]

**Peter’s weekly email about colorectal cancer screening**: [Colorectal cancer screening](https://peterattiamd.com/colorectal-cancer-screening/) | Peter Attia (peterattiamd.com) [30:00]

**Episode of The Drive discussing the discordance between non HDL cholesterol and apoB with Tom Dayspring**: [#22 – Tom Dayspring, M.D., FACP, FNLA – Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins](https://peterattiamd.com/tomdayspring3/) [32:45]

**Study providing apoB levels in the population in percentiles**: [Framingham Offspring Study](https://framinghamheartstudy.org/participants/participant-cohorts/) | (framinghamheartstudy.org) [37:15]

**Episode of The Drive about assessing CVD risk with Allan Sniderman podcast**: [#185 – Allan Sniderman, M.D.: Cardiovascular disease and why we should change the way we assess risk](https://peterattiamd.com/allansniderman/) [39:45]

**Taco Bell protein commercial**: [Taco Bell protein commercial](https://www.youtube.com/watch?v=N60utqXf5HQ) | dansan (youtube.com) [51:30]

**Episode of the Drive that is a follow-up conversation that you and Layne Norton**: [link](https://peterattiamd.com/laynenorton2/) | Peter Attia (peterattiamd.com) [54:00]

**Peter’s instagram post showing data about the impact of exercise on longevity**: [@peterattiamd | 3/3/2022](https://www.instagram.com/p/CapXi-yOixe/) | (instagram.com) [55:45]

**AMA episode of The Drive discussion NAD and its precursors (NR, NMN) as well as Metformin, Rapamycin**: [link](https://peterattiamd.com/ama35/) | Peter Attia (peterattiamd.com) [1:08:45]

**Episode of The Drive about psychedelics with David Nutt**: [#182 – David Nutt: Psychedelics & Recreational Drugs](https://peterattiamd.com/davidnutt/) | Peter Attia (peterattiamd.com) [1:09:45]

**Episode of The Drive about psychedelics with Rick Doblin**: [#65 – Rick Doblin, Ph.D.: MDMA — the creation, scheduling, toxicity, therapeutic use, and changing public opinion of what is possibly the single most important synthetic molecule ever created by our species](https://peterattiamd.com/rickdoblin/) | Peter Attia (peterattiamd.com) [1:11:30]

**The phase 3 data for the therapeutic use of MDMA**: [MDMA-assisted therapy for severe PTSD: a randomized, double-blind, placebo-controlled phase 3 study](https://www.nature.com/articles/s41591-021-01336-3) (Mitchell et al., 2021) [1:12:15]

**Episodes of The Drive on sleep with Matt Walker**: [1:13:15]

- *(April 1, 2019)* [Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, and memory](https://peterattiamd.com/matthewwalker1/)
- *(April 8, 2019)* [Part II of III: Heart disease, cancer, sexual function, and sleep disruption](https://peterattiamd.com/matthewwalker2/)
- *(April 15, 2019)* [Part III of III: The penetrating effects of poor sleep from metabolism to genetics](https://peterattiamd.com/matthewwalker3/)
- *(June 17, 2019)* [AMA #1: Strategies for sleeping more and sleeping better](https://peterattiamd.com/matthewwalkerama/)
- *(October 28, 2019)* [AMA #2: short sleep mutants, optimal sleep environment, & sleep apnea](https://peterattiamd.com/matthewwalkerama2/)
- *(August 31, 2020)* [Sleep & Covid-19: Sleep and immune function, chronotypes, and hygiene tips](https://peterattiamd.com/matthewwalker4/)
- *(September 7, 2020)* [AMA #3: Fasting, gut health, blue light, caffeine, REM sleep, and more](https://peterattiamd.com/matthewwalkerama3/)

**Study showing Ambien reduced non-REM deep sleep and increased light sleep**: [Randomised clinical trial of the effects of prolonged-release melatonin, temazepam and zolpidem on slow-wave activity during sleep in healthy people](https://pubmed.ncbi.nlm.nih.gov/25922426/) (Arbon et al., 2015) [1:17:00]

**Trazodone data on sleep**: [1:29:15]

- Data on the mechanism of action: [Shin and Saadabadi, 2021](https://www.ncbi.nlm.nih.gov/books/NBK470560/#:~:text=Mechanism%20of%20Action&text=Trazodone%20reduces%20levels%20of%20neurotransmitters,alpha%2D1%2Dadrenergic%20receptors.)
- Data on the efficacy:
  - [Yi et al., 2018](https://pubmed.ncbi.nlm.nih.gov/29680424/)
  - [Fagiolini et al., 2020](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7099841/)
- Data on stage preservation: [Wang et al., 2020](https://www.frontiersin.org/articles/10.3389/fpsyt.2020.00620/full)

**Book recommendation from Peter**: [The Comfort Crisis: Embrace Discomfort To Reclaim Your Wild, Happy, Healthy Self](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1648656078&sr=8-1) by [Michael Easter](https://twitter.com/Michael_Easter?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (amazon.com) [1:21:00]

**Formula 1 show on Netflix**: [Drive to Survive](https://www.netflix.com/title/80204890) | (netflix.com) [1:22:00]

**Article explaining the feud between Toto Wolff and Christian Horner and how Horner bought a charity ticket to see inside the garage of Wolff**:  [HORNER BOUGHT HIMSELF A MERCEDES FACTORY TOUR AT A CHARITY AUCTION](https://wtf1.com/post/horner-bought-himself-a-mercedes-factory-tour-at-a-charity-auction/) | Hannah Prydderch (wtf1.com) [1:54:00]

§

## People Mentioned

- [Bob Kaplan](https://www.linkedin.com/in/bobckaplan/) [3:15]
- [John Griffin](https://www.investopedia.com/articles/investing/031216/john-griffins-success-story-net-worth-education-top-quotes.asp) [5:25]
- [Bill Gifford](https://twitter.com/billgifford?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [9:15]
- [Sebastian Junger](https://en.wikipedia.org/wiki/Sebastian_Junger) [10:45]
- [Steve Rosenberg](https://ccr.cancer.gov/staff-directory/steven-a-rosenberg) [15:00]
- [Raj Attariwala](https://aimmedicalimaging.com/tag/dr-raj-attariwala/) [25:00]
- [Chadwick Boseman](https://en.wikipedia.org/wiki/Chadwick_Boseman) [29:45]
- [Allan Sniderman](https://www.cardiomuhc.ca/allan-sniderman) [39:45]
- [Richard Isaacson](https://www.fau.edu/newsdesk/articles/isaacson-brain-health.php) [40:30]
- [Layne Norton](https://twitter.com/biolayne) [54:00]
- [Matt Kaeberlein](https://dlmp.uw.edu/faculty/kaeberlein) [1:09:00]
- [David Nutt](https://www.imperial.ac.uk/people/d.nutt) [1:09:45]
- [Rick Doblin](https://en.wikipedia.org/wiki/Rick_Doblin) [1:11:30]
- [Matt Walker](https://en.wikipedia.org/wiki/Matthew_Walker_(scientist)) [1:13:15]
- [Tom Dayspring](https://twitter.com/Drlipid) [1:13:15]
- [Michael Easter](https://twitter.com/Michael_Easter?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [1:21:00]
- [Charles Leclerc](https://en.wikipedia.org/wiki/Charles_Leclerc) [1:26:30]
- [Carlos Sainz, Jr.](https://en.wikipedia.org/wiki/Carlos_Sainz_Jr.) [1:26:30]
- [Lewis Hamilton](https://en.wikipedia.org/wiki/Lewis_Hamilton) [1:31:45]
- [Sebastian Vettel](https://www.formula1.com/en/drivers/sebastian-vettel.html) [1:34:30]
- [Max Verstappen](https://en.wikipedia.org/wiki/Max_Verstappen) [1:35:45]
- [Sergio Perez](https://en.wikipedia.org/wiki/Sergio_P%C3%A9rez) [1:35:45]
- [Valtteri Bottas](https://en.wikipedia.org/wiki/Valtteri_Bottas) [1:35:45]
- [Lando Norris](https://en.wikipedia.org/wiki/Lando_Norris) [1:40:45]
- [Daniel Ricciardo](https://en.wikipedia.org/wiki/Daniel_Ricciardo) [1:40:45]
- [Kevin Magnussen](https://en.wikipedia.org/wiki/Kevin_Magnussen) [1:40:45]
- [Niki Lauda](https://en.wikipedia.org/wiki/Niki_Lauda) [1:46:45]
- [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) [1:47:00]
- [Michael Schumacher](https://en.wikipedia.org/wiki/Michael_Schumacher) [1:47:15]
- [George Russell](https://en.wikipedia.org/wiki/George_Russell_(racing_driver)) [1:52:45]
- [Toto Wolff](https://en.wikipedia.org/wiki/Toto_Wolff) [1:53:45]
- [Christian Horner](https://en.wikipedia.org/wiki/Christian_Horner) [1:53:45]

§