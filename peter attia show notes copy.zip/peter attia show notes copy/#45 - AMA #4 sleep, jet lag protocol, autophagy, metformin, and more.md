# #45 – AMA #4: sleep, jet lag protocol, autophagy, metformin, and more

**Source:** [https://peterattiamd.com/ama04/](https://peterattiamd.com/ama04/)

---

In this “Ask Me Anything” (AMA) episode, the first subscriber-only edition, Peter answers a wide range of questions from readers and podcast listeners. Bob Kaplan, Peter’s head of research, asks the questions. If you’re a subscriber, you can watch or listen to this full episode on our website.

## We discuss:

- Blue light blockers and how they improve sleep [1:30];
- How to minimize jet lag and sleep disruption while traveling [6:45];
- How to treat symptoms of PMS, the female hormone cycle, testosterone in women, and estrogen in men [15:45];
- Autophagy: what it is, why it matters, and how can we enhance it [26:15];
- The two-minute drill (and a bonus Patriots and Tom Brady tangent) [41:15];
- Has Peter thought about having CME accredited content for people in the medical field? [44:15];
- How does one find good doctors that are somewhat up to date on the latest research, primary care, etc.? [45:45];
- What values would Peter be interested in monitoring continuously if the tech existed? [47:15];
- How to annoy Peter [49:15];
- If I’m interested in longevity, should I do a Ph.D. or M.D.? [50:00]; and
- More.

§

The Peter Attia Drive

Sleep, jet lag protocol, autophagy, metformin, and more

§

## Show Notes

## Blue light blockers and how they improve sleep [1:30]

**Blue blocker glasses**

- Brand Peter uses ⇒ [Gunnar](https://gunnar.com/?gclid=CjwKCAiA2fjjBRAjEiwAuewS_eXj-LwVodsKjSdKF-jBYmkfL1xpXZ2Zt9vlZ2lN4GcfbicT9YtqRBoCWwsQAvD_BwE)
- (Peter is neither sponsored by, nor receives any compensation from, Gunnar)
- Approx. $40 per pair
- Look for frequent sales on Gunnar glasses

**Other measures you can take to block light from electronics**

- Phone setting
  - Most smartphones have [light settings that block blue light](https://www.digitaltrends.com/mobile/how-to-use-blue-light-filter-phone/) by rendering the phone completely red or grey
  - “That usually is more than adequate than needing these glasses.”
- App for a Mac laptop
  - [f.lux](https://justgetflux.com/) is a downloadable application for MacOS which will block blue light on your laptop

*So are the blue blocker glasses really necessary?*

- Peter says, “I kind of view the glasses as an insurance policy and I definitely notice a difference in my sleep quality.”

**What are blue blockers actually doing to improve sleep?**

*Sleep is a balancing act between* [*adenosine*](https://en.wikipedia.org/wiki/Adenosine), [*cortisol*](https://en.wikipedia.org/wiki/Cortisol)*, and* [*melatonin*](https://en.wikipedia.org/wiki/Melatonin)

⇒ Adenosine

- Sounds familiar? Probably because you remember from high school biology that ATP, which is the currency of energy, is adenosine triphosphate
- Adenosine builds up with the more energy you expend
- Adenosine levels in the morning will be higher than levels in the evening (if you’ve been doing something)
- Note: Caffeine works to keep you awake by lowering adenosine levels

⇒ Cortisol

- You want cortisol low in the evenings
- The cycle of cortisol

![](https://peterattiamd.com/wp-content/uploads/2019/03/images-cortisol-diurnal.jpg)

**Figure 1. Normal daily cortisol pattern**. Image credit: [ZRT Laboratory](https://www.zrtlab.com/landing-pages/diurnal-cortisol-curves/)

- You want to wake up at a low level
- You want to go to bed at a low level
- In about the first two hours of waking, you should have a huge surge in cortisol
- Then a gradual tapering off leading up to bedtime

⇒ Melatonin

- You want melatonin to rise at night
- Melatonin is secreted by a tiny little gland called the [pineal gland](https://en.wikipedia.org/wiki/Pineal_gland)
- It is secreted in the **absence of light, specifically blue light**

In summary, you want. . .

1. High adenosine
2. Low cortisol
3. High levels of melatonin

## How to minimize jet lag and sleep disruption while traveling [6:45]

*Note: If you have time to acclimate to your new time zone, this protocol is probably unnecessary*

**Strategy** = When you leave the place of origin, you immediately “put yourself” in the destination

- Example, say you are leaving Los Angeles at 2 PM and flying to Dubai which would be 2 AM
  - So to immediately “put yourself” into 2 AM, you have to immediately fall asleep
  - Sleep for 7 hours on the plane, and when you wake up it will be 9 AM in Dubai (but 9 PM in L.A.)
  - You will then stay up until a normal bedtime on Dubai time
  - Make sure to get up early the following day and stay on Dubai time
  - And then when you fly back to L.A., you would do the same tricks in reverse

The days before the trip:

- Start waking up really early and going to bed a little bit earlier
- The day of the trip, get up even earlier (i.e. 3 AM)
- Get quite a bit of exercise in that day
- Don’t have any caffeine that day

At the airport, begin the “chemical coma”:

- Peter takes a supplement called [phosphatidylserine](https://www.webmd.com/vitamins/ai/ingredientmono-992/phosphatidylserine)
  - Used to get cortisol levels down (which is tough in the middle of the day)
  - Somewhere between 100 and 600 milligrams (it’s been tested up to 600 milligrams, it’s completely safe)
  - Take this about 30 minutes before boarding the flight
- Peter then takes a single dose of the [sleep remedy that is made by Kirk Parsley](https://store.docparsley.com/)
  - (Disclosure, Peter is a small investor in that company)
  - Peter takes the capsules for convenience
- He also takes 10 milligrams of [Valium](https://www.webmd.com/drugs/2/drug-11116/valium-oral/details)
  - “I will take either 10 milligrams of Valium or a shorter acting version of that.”
  - Take it far enough before the flight that by the time you get on a flight you are really ready to sleep but not so far before the flight that you have to fight to stay awake to get on the plane
  - “I made that mistake once and almost missed the flight”

On the plane:

- Inform the flight attendant you plan to sleep and not to be bothered
- Set an alarm for 7 hours later

When you wake up:

- Peter then takes 200 mg of [modafinil](https://en.wikipedia.org/wiki/Modafinil)
- Your brain will still sort of think it’s night time (i.e. 9 PM instead of 9 AM)
- But needing to stay awake for 12+ hours, modafinil works for that

⇒ More about modafinil

- 200 milligrams of modafinil which is about 1/3 of the maximum dose
- Modafinil is usually taken as 100, 200, 400 or 600 milligrams
- Modafinil is a non-stimulant that unfortunately, we don’t have a great idea of how it works
- It’s been around since the mid-’90s
- It’s used primarily to treat narcolepsy, but it’s also been used extensively in the military
- Remarkably safe when taken with appropriate dosing
- About 10% of people are stimulated by it
- But for about 90% of people, you don’t really feel anything other than you’re not tired and then you don’t really have any difficulty going to bed the next night

*⇒ What about using blue light to wake you up and suppress melatonin?*

- That is absolutely a technique
- I’m going to blast that computer at myself on the plane when I wake up

## How to treat symptoms of PMS, the female hormone cycle, testosterone in women, and estrogen in men [15:45]

Question: *My wife gets PMS, is that just in her head?*

- “The short answer is yes and no.”
- Is she psychologically “making this up”? **Absolutely not.**
- It’s affecting her head (i.e. emotions), but this is a completely legitimate response to a hormone issue
- “What is likely happening is that in some women that are susceptible, **progesterone withdrawal** during the last part of the luteal phase is the problem.”

**The female hormone cycle**

![](https://peterattiamd.com/wp-content/uploads/2019/03/estrogen-and-progesteron-cycle.jpg)

**Figure 2. Female hormone cycle.** Image credit: [PrimalEye](https://primaleye.uk/how-female-hormones-affect-your-diet/)

Two phases:

- Follicular phase ⇒ Getting ready for the follicle to get secreted
- Luteal phase ⇒ Prepare endometrial lining to prepare for a fertilized egg
  - The period is body getting rid of the luteal lining if there is no pregnancy

Estrogen and progesterone

- “Progesterone is the one that really matters here”
- They both start very low during the period

Estrogen

- Peaks during ovulation
- Then goes down but has a second peak in the mid-follicular phase, then comes back down again

*Note*: In the case of a pregnancy, these hormones would skyrocket as the pregnancy continues

*Fun Fact*: One of Peter’s favorite things to do as soon as he sees a woman’s labs is to look at the FSH, the LH, the progesterone, and the estrogen, and try to guess what day she is at in her cycle . . . “If I can do that, it usually means her cycles pretty normal. If I’m off in my guess, it usually means there’s something off in her cycle.”

Progesterone

- Stays really low throughout follicular phase
- It does not start to rise until after ovulation when it kicks into gear to prepare the endometrium
- it also then comes crashing down at the end but from a much higher peak because it rises much higher during the luteal phase

**So, what is this “PMS”?**

- Due to the very, very rapid withdrawal of progesterone, some women experience symptoms of emotional lability
  - Not being themselves
  - Easier to react, be emotional, cry, get upset
  - Mood swings
- It typically goes away once her period arrives

> “I’ve been surprised with a number of patients when I explain this to female patients, how many of them say, ‘I didn’t really know why I felt so irritable in the week leading up to my period.’ In some ways, as crazy as it sounds, empowering a woman to realize this actually makes her life a lot better because she sort of realizes, ‘oh my God, I’m not crazy. This isn’t something in my head.’”

*What causes symptoms to be more severe in some women than others?*

- People have suspected that there are different degrees of progesterone receptors centrally that may be part of why this is happening

*What are the interventions?*

⇒ First is to try:

- Better sleep, exercise, nutrition, time with friends
- “I actually had one patient for whom my prescription was every day during that week she had to do something that was 100% for her, non-negotiable. . . those things make a difference.”

⇒ Next is pharmacological:

- Elegant way
  - A very low dose of progesterone for women to take orally following ovulation
  - Between 25 and 50 milligrams, which is about 1/8 to 1/4 of the progesterone a woman would take after menopause for uterine protection
  - That usually blunts all of the symptoms out
  - The drawback is that the woman has to closely monitor her cycle and time the dosage accurately for it to work
- The blunt tool
  - Oral contraceptives
  - Takes all of this fluctuation away and normalizes it
  - But comes with its own pros and cons

**What happens to hormones in menopause?**

- Estrogen and progesterone ⇒ A rapid drop off, “they effectively go to zero”
- What about testosterone? ⇒ It also drops to zero

⇒ Testosterone in women

- It’s actually much higher than estrogen and progesterone (counterintuitive)
- Testosterone is the dominant hormone in both **men and women**
- Estradiol levels in women at their peak are ⅕-1/10 the level of testosterone
- Still much less than men, however
  - Men have 14-22 nanograms per deciliter
  - Women have 0.5-0.8 nanograms per deciliter
- [Testosterone also varies throughout a woman’s cycle](https://www.ncbi.nlm.nih.gov/pubmed/23127814) but to a much less degree than other hormones

**Testosterone varies throughout a woman’s cycle**: [Dynamics of serum testosterone during the menstrual cycle evaluated by daily measurements with an ID-LC-MS/MS method and a 2nd generation automated immunoassay](https://www.ncbi.nlm.nih.gov/pubmed/23127814) (Bui et al., 2012)

**Estrogen in men:**

On the flip side, estrogen is very important in men

**The importance of estrogen in men**: [Gonadal Steroids and Body Composition, Strength, and Sexual Function in Men](https://www.nejm.org/doi/full/10.1056/NEJMoa1206168) (Finkelstein et al., 2013)

[New England Journal of Medicine in 2013](https://www.nejm.org/doi/full/10.1056/NEJMoa1206168):

- Basically, they took a number of men and “chemically castrated them” (the investigators gave men ages 20 to 50 goserelin, a hormone that suppresses both estrogen and testosterone production)
- They gave hormones that completely shut off testosterone production
- Then they replaced them with testosterone at five different doses and then did so with and without a drug that blocks the conversion of testosterone into estrogen
- The idea is you’d get basically 10 different pictures of testosterone and estrogen
- *The finding*: **if estrogen is too high or too low, it’s suboptimal regardless of the testosterone level**.

**Estrogen and bone density**

⇒ Important to monitor estrogen levels in men:

- Some men just don’t genetically make much estrogen out of their testosterone and so their estrogen is low
- In these men, you actually worry about reduced bone density

⇒ Low estrogen in women after menopause

- “This is also clearly a problem for women post-menopause and arguably **one of the most important reasons for women to consider hormone replacement therapy.”**

For more on hormone replacement therapy in women, check out the [episode of The Drive with Avrum Bluming and Carol Tavris](https://peterattiamd.com/caroltavris-avrumbluming/)

## Autophagy: what it is, why it matters, and how can we enhance it [26:15]

**What is autophagy?**

- Auto-phagy = self-eating
- When the [lysosome](https://en.wikipedia.org/wiki/Lysosome) of a cell basically auto digests the cell
  - Lysosomes are sacs within cells that contain digestive enzymes that, sort of like the pancreas, contains a bunch of digestive enzymes

*Why does autophagy matter?*

- Like most processes in the body, there must be balance
- When there’s too much of it, or too little of it, really bad things happen
- For example,
  - When you create an “autophagy knockout mouse” that can’t undergo autophagy, it’s lethal
  - When you have a creature that is in hyper ramped up autophagy mode, that is lethal
- “There’s clearly something about this thing being imbalanced.”

*What important role does autophagy play?*

- One of the more important reasons for doing this is to **rid the body of cells that are suboptimal**
- Example of a suboptimal cell is a cell that’s got **DNA damage**

*The challenges of measuring autophagy:*

- In a lab, it’s cumbersome because you’re typically doing muscle biopsies
- What are you looking for?
  - These things called [light chains](https://en.wikipedia.org/wiki/Immunoglobulin_light_chain)
  - Basically, these are spindles that you see that occur during various stages of cell cycle arrest and development
  - And so by looking for these light chains which are spindles, you can infer this (but even that assay is problematic because the act of taking the biopsy and trying to get a snapshot in time renders this quite difficult)
- The reality is we don’t have amazing ways to measure this
- And we really don’t have a way to measure this **in humans**

*Is there a way we can we infer when autophagy is happening?*

- We rely on an imputed understanding that certain things are probably also happening when you’re undergoing autophagy
- For example, during autophagy, you are…
  - Depleting glycogen,
  - Turning over nucleic acids
  - And you can possibly see the “knockoff effects” of those things
- “But we do not have at this time a blood test that could say even in an analog way, let alone digital, are you in sort of one varying degree of autophagy to the next?”

*Could AMPK be promoting autophagy?*

- [AMP-activated protein kinase](https://en.wikipedia.org/wiki/AMP-activated_protein_kinase) (AMPK) is upregulated in stressful situations like exercise and fasting and in animal models [you see autophagy happening](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5780224/)
- Bob read in [Nick Lane](https://en.wikipedia.org/wiki/Nick_Lane)’s book, [Power, Sex, Suicide](https://www.amazon.com/Power-Sex-Suicide-Mitochondria-Meaning/dp/0199205647), that 10 billion cells undergo apoptosis in any given day
- [Apoptosis](https://en.wikipedia.org/wiki/Apoptosis) is fully programmed cell death which is actually the mitochondria “calling the shots”
- “*And so when I thought about that, I kind of think about autophagy as well,*” says Bob

**You see autophagy happening**: [AMPK: guardian of metabolism and mitochondrial homeostasis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5780224/) (Herzig and Shaw, 2017)

> “Every day in the human body, some 10 billion cells die and are replaced by new cells. The cells that die do not meet a violent unpremeditated end, but are removed silently and unnoticed by apoptosis, all evidence of their demise eaten by neighbouring cells. This means that apoptosis balances cell division in the body. It follows that apoptosis is just as important as cell division in normal physiology.”

—NICK LANE,  *Power, Sex, Suicide: Mitochondria and the Meaning of Life*

*Is autophagy either completely on or completely off at all times?*

- Another thing that goes way back to this guy [Ernst Wertheimer](https://en.wikipedia.org/wiki/Haim_Ernst_Wertheimer), he talked about fat metabolism
- In 1948, [he said](https://www.physiology.org/doi/abs/10.1152/physrev.1948.28.4.451), “Mobilization and deposition of fat go on continuously, without regard to the nutritional state of the animal.” So we’re always gaining and losing fat at the same time — it’s the overall balance of mobilization and deposition over time that tells us whether we’re accumulating or diminishing the amount of fat in our fat cells
- It’s like this flux or homeostasis: we tend to think of stuff as on or off, or up or down, but all of these things can be happening in various cells at the same time
- And so these things are **probably not all on, nor all off, at all times**
- Autophagy may be happening in all of us right now at some baseline level (i.e., [basal autophagy](https://www.ncbi.nlm.nih.gov/pubmed/16247501))
- But if you want to really push the needle one way or another, there are specific tactics

**The continuous nature of fat metabolism**: [THE PHYSIOLOGY OF ADIPOSE TISSUE](https://www.physiology.org/doi/abs/10.1152/physrev.1948.28.4.451) (Wertheimer and Shapiro, 1948)

**Baseline or basal level of autophagy**: [The pleiotropic role of autophagy: from protein metabolism to bactericide](https://www.nature.com/articles/4401728) (Mizushima, 2005)

***How do we enhance autophagy?***

⇒ Fasting

- “Clearly the most direct way to enhance autophagy is to fast.”
- The deprivation of nutrients appears to be the most obvious way to induce autophagy.
- Drugs like [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) mimic fasting and enhance autophagy
  - Experts on rapamycin like [David Sabatini](https://twitter.com/dmsabatini?lang=en) or [Matt Kaeberlei](https://en.wikipedia.org/wiki/Matt_Kaeberlein)n both agree that *at least some of the life-extending benefits of rapamycin and are probably attributed to autophagy*
- The question we are still trying to answer is… *Are rapamycin’s benefits mostly driven through autophagy, or is it driven more through the silencing of* [*senescent cells*](https://en.wikipedia.org/wiki/Cellular_senescence)*?*

⇒ Exercise

- What role does it play? ⇒ “I don’t think I know the answer to this question but I think it does come down to probably the type of exercise. “
- Type of exercise
  - The body’s response to [high intensity interval training](https://en.wikipedia.org/wiki/High-intensity_interval_training) versus [strength training](https://en.wikipedia.org/wiki/Strength_training) versus purely [aerobic exercise](https://en.wikipedia.org/wiki/Aerobic_exercise) is very different
  - Peter suspects **sustained aerobic exercise** is most of likely to push us towards more autophagy
  - Why? ⇒ It more closely mimics a nutrient deprived state
  - *High-intensity interval training* has the exact opposite of a low fed state ⇒ It looks more like a high fed state (i.e. your glucose levels ramp up significantly)

⇒ Studying exercise and autophagy in mice

- [NY Times article](https://well.blogs.nytimes.com/2012/02/01/exercise-as-housecleaning-for-the-body/?rref=collection%2Fbyline%2Fgretchen-reynolds)
- [Nature paper](https://www.ncbi.nlm.nih.gov/pubmed/22258505)
  - The study used transgenic mice whose cells produced a glowing green protein whenever autophagy occurred
  - They ran the mice on little treadmills
  - After 30 minutes, autophagy had drastically increased
  - The rate continued increasing until the mice had been running for 80 minutes
  - Beth Levine, the lead author, admitted that after the study she went out and bought a treadmill
- How to extrapolate to humans?
  - Mice have much smaller lifespans and so it’s very hard to equate a 30 minute run for a mouse to a human  (“it’s almost like a three-month run”)
  - “I wouldn’t even know how to interpret those data. 30 minutes to 80 minutes of running for a mouse, what does that mean? That means running a marathon to two marathons, it could mean running less. We can’t even come close to, in my opinion, at least trying to impute from that what the answer is for us.” says Peter
- The same study created a strain of mice whose body wouldn’t allow for an increase in autophagy when exercising
  - And they found that the benefits of exercise were basically gone
  - The benefits of exercise seems to be largely due to the process of autophagy

*Why is autophagy so remarkable?*

- We have some system that can basically pick out the damaged cells and debris
- And not only is it clearing it away, it’s actually taking up some of the stuff that can be reused and recycled

*What is* [*mitochondrial biogenesis*](https://en.wikipedia.org/wiki/Mitochondrial_biogenesis)*?*

- Cells also have a mitochondrial homeostasis…
  - Sometimes they say a cell needs to die
  - Other times they say “just this part” of the cell needs to die, but this part can stay
  - And other times it says that we don’t have the supply to meet the demand so we’re going to make more mitochondrial DNA and make more complexes and increase our ATP capacity (mitochondrial biogenesis)

*Does it matter* ***how*** *the mitochondria die?*

- Yes, it does…
- If the mitochondria can die in a controlled process through [mitophagy](https://en.wikipedia.org/wiki/Mitophagy) or apoptosis, it’s controlled, that’s great.
- If the mitochondria become damaged and lice their contents, namely their DNA into the cytoplasm, that becomes problematic.

*What happens when mitochondrial DNA escape into the cytoplasm?*

- Mitochondrial DNA are bacterial in origin
- So when mitochondrial DNA escape the mitochondria into the cytoplasm, that’s a real trigger to the immune system that something bad is happening
- There is [a paper](https://www.ncbi.nlm.nih.gov/pubmed/30135585):
  - Looked at blocking the mitochondrial DNA sensing apparatus within a cell
  - Demonstrating that the inflammation that’s found in aging muscles can be tied to mitochondrial DNA seeping into the cytoplasm

*Does* [*metformin*](https://en.wikipedia.org/wiki/Metformin) *induce autophagy?*

- [Nir Barzilai](https://en.wikipedia.org/wiki/Nir_Barzilai) believes [metformin can be taken to “tame” aging](https://peterattiamd.com/nirbarzilai/)
- Studies showing t[ype 2 diabetics that were taking metformin live longer than non-diabetic control](https://www.ncbi.nlm.nih.gov/pubmed/25041462)

![](https://peterattiamd.com/wp-content/uploads/2019/03/Screen-Shot-2019-01-02-at-10.08.22-AM.png)

**Figure 3. Metformin associated with reduced mortality in T2DM compared with non-diabetics.** Image credit: [peterattiamd.com](https://peterattiamd.com/nirbarzilai/)

- Metformin increases AMPK ⇒ so maybe part of the beneficial effects of metformin is increased autophagy
- Originally (9 years ago), Peter saw metformin through the lens of reducing hepatic glucose output
- At the time, “I didn’t even understand the relationship between AMPK and mTOR”

*Does sleep have an effect on autophagy?*

- In [Matthew Walker](https://twitter.com/sleepdiplomat?lang=en)‘s book, [Why We Sleep](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316), he wrote about the process of cleaning up cellular debris and how important sleep is for that process
- “I don’t know if it was from his book but they at least in mice and when they look in people and the markers that there might be increased autophagy as well,” where [circadian rhythm is linked to autophagy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3389582/) and [sleep fragmentation appears to disrupt this process in mice](https://www.ncbi.nlm.nih.gov/pubmed/27078501)

*What about ketosis and beta-hydroxybutyrate?* ⇒ These things sort of mimic fasting and that might help in this autophagic state

*Why is diet, sleep, and exercise beneficial for health?* ⇒ autophagy might be one of the mechanisms of benefit

*How do the autophagic results of drugs like rapamycin and metformin compare to the results of natural and behavioral regimens?*

- If you took a 25-year-old and you put them on the absolute best, which is not to say I know what that is, but if you could theoretically know what the best
  - Nutritional regimen
  - Sleep regimen (which I think we have much more of an idea of what that looks like)
  - Exercise regimen
  - Stress regimen

> “It seems to me that the alpha that you could generate exceeds that which you could generate through any drug.”

- Peter [posed a similar question to David Sabatini](https://overcast.fm/+NmiTsdktw/1:03:12) to which he responded that he thinks rapamycin could have a positive impact on the dietary deficiencies more so than the other behavior/lifestyle choices

*How much can metformin benefit “healthy” people?*

- The data is much more clear on the beneficial effect of metformin on people who are metabolically dysregulated.
- “I think we have really good data to suggest that that person’s going to benefit from metformin.”

## The two-minute drill (and a bonus Patriots and Tom Brady tangent) [41:15]

- Patriots have just recently [won their sixth Superbowl](https://en.wikipedia.org/wiki/Super_Bowl_LIII)
- Peter says, “I thought that game was incredible.”

Tom Brady’s first super bowl victory

- Peter went back and watched the [final drive of the 2002 super bowl](https://www.youtube.com/watch?v=0WNBQmcPh24)

- The Patriots are up by quite a bit and it looks like they’re going to win until the Rams really come back and tie the game with about a minute and a half to go.
- The Patriots receive the ball on roughly their 20-yard line with a minute and a half left in the game and the game is tied.
- Now, you got to understand, this is a young team. Brady looks like he’s 13 years old.
- John Madden was the announcer, and he’s like “the only thing that matters here is do not turn over the ball. You just run the clock out until overtime.”
- First play pass ⇒ Madden’s like, “What the hell are they doing? An interception on your own 20-yard line, you lose the Superbowl.”
- With no time outs, they managed to go down and kick a field goal as time expired to win the game

## Has Peter thought about having CME accredited content for people in the medical field? [44:15]

- Yes, he has thought about it a lot
- However, more likely that CME credits will be earned in the future from “conferences that we’ll eventually put on” and “research reports that we’ll put out”

⇒ **A podcast that definitely** ***should*** **be a CME course**: [Tom Dayspring five-part series on a lipidology](https://peterattiamd.com/tomdayspring1/) . . . *“I just don’t see how that couldn’t be CME accredited.”*

- Cost to get content CME accredited is a big number ($50,000 or $100,000)
- “But it might be worth doing at some point. If for no other reason then I think it would be great for physicians when they’re getting their CMEs to have valuable content.”

> “Every two years when I have to do it, I’m constantly blown away at how pathetic the content is.”

## How does one find good doctors that are somewhat up to date on the latest research, primary care, etc? [45:45]

1 Start by questioning your current doctor… such as:

- How much time does your practice permit you to read scientific articles or attend meetings or keep up with X, Y, or Z?
- What are your interests clinically outside of what you’re doing?

2 [Peter Attia Doctor Directory](https://peterattiamd.com/directory-signup/)

- It’s been open for a few months
- So far, about 150 doctors have signed up
- However, more are needed ⇒ the goal is to have enough doctors so that anybody in any city or even outside of the country who wants to find a doc can do it

## What values would Peter be interested in monitoring continuously if the tech existed? [47:15]

**Lactate in real time** ⇒ Currently, a pain in the ass to check with finger pricks

**Real-time beta-hydroxybutyrate** ⇒ really cool for people in ketosis

**Real-time insulin** ⇒ *“The holy grail”*

- Peter thinks we’re a long way from real-time insulin (like a [CGM](https://www.dexcom.com/continuous-glucose-monitoring) but for insulin)
- But there is a company developing a point of care device for insulin, “which is a huge step”
- Currently, it is “staggeringly expensive”
- But a device that you could poke your finger and measure insulin in real time…that’s pretty cool and that would suggest that hey, maybe there’s a day when you could get that information continuously.”
- This same device can measure the total amount of C-peptide collected in your urine which is a proxy for insulin area under the curve (a 24 hour AUC for insulin)

## How to annoy Peter [49:15]

Step 1: Irresponsibly use the font, [Comic Sans](https://en.wikipedia.org/wiki/Comic_Sans)

Step 2: Refuse to use [Avenir](https://en.wikipedia.org/wiki/Avenir_(typeface)), even when it’s an option

## If I’m interested in longevity, should I do a Ph.D. or M.D.? [50:00]

**If Peter could go back in time, would he have gotten a Ph.D.? How might he have changed his path?**

“I’ve found myself at many points in life upset at my trajectory.”

For example, Peter was unsatisfied after 10 years in medicine…

- He left to work in credit risk at [McKinsey](https://en.wikipedia.org/wiki/McKinsey_%26_Company)
- Thought to himself… “why didn’t I just do my Ph.D. in math like I was planning to do?”
- Before going into medicine, he originally planned to do [control theory](https://en.wikipedia.org/wiki/Classical_control_theory) (math and aerospace)

*Unsatisfied again, he moved back to medicine* ⇒ And now that he is back in medicine, he’s very glad he got his M.D. rather than an engineering degree

*Could have he pursued a Ph.D. and done valuable lab research?*  ⇒ Yes, of course, he would have liked that experience, but…

> “It’s hard to answer those questions because then it becomes a question about what cost? You don’t get to wave magic wands and make time out of nothing. You had to have given something up. Would I have given up my clinical experience to have done that? For me no. I mean, I love clinical medicine.”

**What about someone who’s obsessed with the topic of longevity, where should they apply themselves?**

- It depends on whether or not you want to be in contact with patients
- If you do, it’s very difficult to do that without having an M.D.
- *Getting an M.D. and a Ph.D. together* ⇒  A difficult line path because depending on the field you choose, it’s hard to be competitive with your Ph.D. peers when you’re also learning to practice medicine
- “Just remember, life is basically one big do-over so you can sort of do something and realize, hey, that wasn’t a good use of time and negate the sunk cost and sort of move on.”
- ***Don’t study pre-med***: “I don’t think you ought to do a pre-med degree if you want to go to medical school. In fact, I don’t think you ought to repeat in undergrad what you’re planning to do in graduate school.”

> “I think that the greater the breadth that you can bring to what you’re studying, the better you are and I think you’re honestly better off being a philosophy major and then going into medical school than being a premed.”

§

## Selected Links / Related Material

**Brand of blue blockers that Peter prefers**: [Gunnar](https://gunnar.com/) | (gunnar.com) [1:30]

**Many phones have a light setting for nighttime**: [How to use a blue light filter on your phone](https://www.digitaltrends.com/mobile/how-to-use-blue-light-filter-phone/) | Simon Hill (digitaltrends.com) [3:00]

**Light blocking app for a Mac computer**: [f.lux](https://justgetflux.com/) | (justgetflux.com) [3:30]

**Matthew Walker’s book about sleep**: [Why We Sleep: Unlocking the Power of Sleep and Dreams](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316) by Matthew Walker (amazon.com) [4:15, 39:00]

**Where Peter worked as a credit risk modeler**: [McKinsey & Company](https://en.wikipedia.org/wiki/McKinsey_%26_Company) | (wikipedia.org) [8:45, 52:15]

**Supplement Peter uses for getting his cortisol levels down**: [Phosphatidylserine](https://en.wikipedia.org/wiki/Phosphatidylserine) | (wikipedia.org) [10:45]

**Supplement Peter uses to help induce sleep**: [Sleep Remedy by Doc Parsley](https://store.docparsley.com/) | (docparsley.com) [11:00]

**Medication Peter takes to help induce sleep**: [Benzodiazepine](https://en.wikipedia.org/wiki/Benzodiazepine) | (wikipedia.org) [11:30]

**Medication that Peter uses to stay awake and overcome jet lag**: [Modafinil](https://en.wikipedia.org/wiki/Modafinil) | (wikipedia.org) [12:30]

**Testosterone varies throughout a woman’s cycle**: [Dynamics of serum testosterone during the menstrual cycle evaluated by daily measurements with an ID-LC-MS/MS method and a 2nd generation automated immunoassay](https://www.ncbi.nlm.nih.gov/pubmed/23127814) (Bui et al., 2012)

**The importance of estrogen in men**: [Gonadal Steroids and Body Composition, Strength, and Sexual Function in Men](https://www.nejm.org/doi/full/10.1056/NEJMoa1206168) (Finkelstein et al., 2013) [24:30]

**For more on hormone replacement therapy, see this episode of The Drive**: [#42 – Avrum Bluming, M.D. and Carol Tavris, Ph.D.: Controversial topic affecting all women—the role of hormone replacement therapy through menopause and beyond—the compelling case for long-term HRT and dispelling the myth that it causes breast cancer](https://peterattiamd.com/caroltavris-avrumbluming/) | Peter Attia (peterattiamd.com) [26:00]

**Books by Nick Lane that Bob that talked about the 10 billion cells that undergo apoptosis**: [30:30]

- [Power, Sex, Suicide: Mitochondria and the Meaning of Life](https://www.amazon.com/Power-Sex-Suicide-Mitochondria-Meaning/dp/0199205647) by Nick Lane | (amazon.com)
- [The Vital Question: Energy, Evolution, and the Origins of Complex Life](https://www.amazon.com/gp/product/0393352978/ref=dbs_a_def_rwt_bibl_vppi_i0) by Nick Lane | (amazon.com)

**You see autophagy happening**: [AMPK: guardian of metabolism and mitochondrial homeostasis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5780224/) (Herzig and Shaw, 2017) [30:00]

**The continuous nature of fat metabolism**: [THE PHYSIOLOGY OF ADIPOSE TISSUE](https://www.physiology.org/doi/abs/10.1152/physrev.1948.28.4.451) (Wertheimer and Shapiro, 1948) [30:45]

**Baseline or basal level of autophagy**: [The pleiotropic role of autophagy: from protein metabolism to bactericide](https://www.nature.com/articles/4401728) (Mizushima, 2005) [31:00]

**Episodes of The Drive discussing rapamycin**: [31:45]

- [#09 – David Sabatini, M.D., Ph.D.: rapamycin and the discovery of mTOR — the nexus of aging and longevity?](https://peterattiamd.com/davidsabatini/) | Peter Attia (peterattiamd.com)
- [#10 – Matt Kaeberlein, Ph.D.: rapamycin and dogs — man’s best friends? — living longer, healthier lives and turning back the clock on aging and age-related diseases](https://peterattiamd.com/mattkaeberlein/) | Peter Attia (peterattiamd.com)

**Studying autophagy in mice during exercise**: [Exercise-induced BCL2-regulated autophagy is required for muscle glucose homeostasis.](https://www.ncbi.nlm.nih.gov/pubmed/22258505) (He et al., 2012) [33:15]

**New York Times article about the mouse study on exercise and autophagy**: [Exercise as Housecleaning for the Body](https://well.blogs.nytimes.com/2012/02/01/exercise-as-housecleaning-for-the-body/?rref=collection%2Fbyline%2Fgretchen-reynolds) | Gretchen Reynolds (nytimes.com) [33:15]

**Mitochondrial DNA and inflammation**: [Parkin and PINK1 mitigate STING-induced inflammation](https://www.ncbi.nlm.nih.gov/pubmed/30135585) (Sliter et al., 2018) [36:45]

**Episode of The Drive discussing metformin**: [#35 – Nir Barzilai, M.D.: How to tame aging](https://peterattiamd.com/nirbarzilai/) | Peter Attia (peterattiamd.com) [37:15]

**Studies showing type 2 diabetics that were taking metformin live longer than non-diabetic control**: [Can people with type 2 diabetes live longer than those without? A comparison of mortality in people initiated with metformin or sulphonylurea monotherapy and matched, non-diabetic controls.](https://www.ncbi.nlm.nih.gov/pubmed/25041462) (Bannister et al., 2014) [37:45]

**The circadian rhythm and autophagy**: [Circadian autophagy rhythm: a link between clock and metabolism?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3389582/) (Ma et al., 2012) [38:45]

**The circadian rhythm and autophagy**: [Circadian rhythm of autophagy proteins in hippocampus is blunted by sleep fragmentation](https://www.ncbi.nlm.nih.gov/pubmed/27078501) (He et al., 2016) [38:45]

**2019 Super Bowl won by the Patriots**: [Super Bowl LIII](https://en.wikipedia.org/wiki/Super_Bowl_LIII) | (wikipedia.org) [41:45]

**Tom Brady’s game-winning drive in the 2002 super bowl**: [Super Bowl XXXVI – Tom Brady’s Final Drive (2002](https://www.youtube.com/watch?v=0WNBQmcPh24)) | WWECenaManiaTV (youtube.com) [42:15]

**5 part series on lipidology-podcast episodes that definitely should be CME accredited**: [45:00]

1. [#20 – Tom Dayspring, M.D., FACP, FNLA – Part I of V: an introduction to lipidology](https://peterattiamd.com/tomdayspring1/)
2. [#21 – Tom Dayspring, M.D., FACP, FNLA – Part II of V: Lipid metrics, lipid measurements, and cholesterol regulation](https://peterattiamd.com/tomdayspring2/)
3. [#22 – Tom Dayspring, M.D., FACP, FNLA – Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins](https://peterattiamd.com/tomdayspring3/)
4. [#23 – Tom Dayspring, M.D., FACP, FNLA – Part IV of V: statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain](https://peterattiamd.com/tomdayspring4/)
5. [#24 – Tom Dayspring, M.D., FACP, FNLA – Part V of V: Lp(a), inflammation, oxLDL, remnants, and more](https://peterattiamd.com/tomdayspring5/)

**The doctor directory on Peter’s website**: [Peter Attia Doctor Directory](https://peterattiamd.com/directory-signup/) | (peterattiamd.com) [46:30]

**The lab of David Sabatini**: [Sabatini Lab Whitehead Institute](https://sabatinilab.wi.mit.edu/) | (mit.edu) [50:45]

§

## People Mentioned

- [Matthew Walker](https://twitter.com/sleepdiplomat?lang=en) (sleep expert, author of Why We Sleep, future podcast guest on The Drive) [4:15, 39:00]
- [Vik Jain](https://www.nm.org/doctors/1992965156/vikas-jain-md) (sleep doctor Peter works closely with) [15:00]
- [Kirk Parsley](https://twitter.com/docparsley?lang=en) (doctor and sleep expert, testosterone in women) [11:00, 24:30]
- [Nick Lane](https://en.wikipedia.org/wiki/Nick_Lane) (author of the book Power, Sex, Suicide and the book Vital Questions) [30:30]
- [Ernst Wertheimer](https://en.wikipedia.org/wiki/Haim_Ernst_Wertheimer) (fat metabolism goes on continuously regardless of the nutritional state of the animal) [30:45]
- [David Sabatini](https://twitter.com/dmsabatini?lang=en) (rapamycin) [31:45, 40:30, 50:45]
- [Matt Kaeberlein](https://en.wikipedia.org/wiki/Matt_Kaeberlein) (rapamycin) [31:45]
- [Beth Levine](https://en.wikipedia.org/wiki/Beth_Levine_(physician)) (author of the [autophagy study in mice](https://www.ncbi.nlm.nih.gov/pubmed/22258505), she bought a treadmill after seeing the results of the study) [34:30]
- [Nir Barzilai](https://en.wikipedia.org/wiki/Nir_Barzilai) (metformin, uses Comic Sans in his presentations) [37:30, 50:15]
- [Tom Brady](https://en.wikipedia.org/wiki/Tom_Brady) (6-time super bowl champ) [41:30]
- [Drew Bledsoe](https://en.wikipedia.org/wiki/Drew_Bledsoe) (the quarterback who got injured and lost his job to Tom Brady) [42:30]
- [John Madden](https://en.wikipedia.org/wiki/John_Madden) (announcing the 2002 super bowl) [43:00]

§