# #225 ‒ The comfort crisis, doing hard things, rucking, and more | Michael Easter, MA

**Source:** [https://peterattiamd.com/michaeleaster/](https://peterattiamd.com/michaeleaster/)

---

Michael Easter is the author of the bestseller, [*The Comfort Crisis*](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767). He’s also a journalist, Professor of Journalism at UNLV, and a leading voice on how humans can integrate modern science and evolutionary wisdom for improved health, meaning, and performance in life and at work. In this episode, Michael first talks about his upbringing, including his parents’ struggle with alcoholism, his father leaving when he was young, and how these things impacted Michael’s own struggle with alcoholism. He explains what led to his realization that we are in a “crisis of comfort” and how the removal of many of life’s discomforts through advancements in modern society may actually be a leading contributor to many of our most urgent physical and mental health issues. He explains the benefits of challenging oneself and the immense positive carryover which can come from doing things we find difficult. He describes the consequences of technology like smartphones, which have effectively eliminated boredom—a discomfort that comes with many benefits. He tells the story of a profound experience at an elk hunt that changed Michael’s thoughts around life and death, how happiness can thrive in places without all of the modern comforts of the West, and why we’re hardwired for stress and what to do about it. They conclude with a conversation around rucking, an activity with many physical and mental benefits.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/michaeleaster/the_Drive_public.png)

Play

#225 ‒ The comfort crisis, doing hard things, rucking, and more | Michael Easter, MA

#225 ‒ The comfort crisis, doing hard things, rucking, and more | Michael Easter, MA

1x15s30s

0:001:48:49

## We discuss:

- The value in doing something difficult [2:30];
- Michael’s upbringing with a single parent and alcoholism [5:45];
- Michael’s battle with alcoholism and his experience with quitting drinking [10:00];
- Origin of the idea that we are in a crisis of comfort [20:30];
- The death of boredom in modern society [28:45];
- The benefits of boredom [36:00];
- The value of disconnecting and being in nature [39:15];
- Changing the dynamic of how we think about food and the story of Peter’s daughter’s first hunt [43:45];
- How a profound experience at an elk hunt changed Michael’s thoughts about life and death [49:15];
- How happiness can thrive in places without all of the modern comforts of the West [57:15];
- Why we’re hardwired for stress, and the responsibility that comes with our level of comfort [1:05:30];
- How perspective on the timescale of our lives in relation to history can impart positive changes [1:14:00];
- The benefit of challenging oneself and the positive carryover it can have [1:19:45];
- The many benefits of rucking [1:28:45];
- Tips for rucking: ideal load, type of pack, and other considerations [1:38:00];
- Parting thoughts on the downside of comfort and benefits of difficult things [1:43:00]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Michael Easter is an author, speaker, and professor
- His work focuses on how humans can integrate modern science and evolutionary wisdom for improved health, meaning, and performance in their life and work
- When he is not on the ground reporting, Michael is a visiting lecturer in the Journalism and Media Studies Department at the University of Nevada in Las Vegas
- Michael travels the world to speak with different thinkers and people living at extremes, and he shares those insights in his books and his other writing
- He’s the author of the best seller, [*The Comfort Crisis*](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767), which no doubt you have heard Peter speak about, both in other podcasts and probably on social media
- In this episode, we talk about a lot of things‒ Michael’s background, his parents struggle with alcoholism, his father leaving when he was young, and how these things impacted Michael’s own struggle with alcoholism
- From there, we talk about his realization that we are in a crisis of comfort and how this became the thesis for the book we discuss
- We talk about boredom, phones, TV, stress, and dealing with the possibility of failure
- We talk also about hunting and the importance of thinking about death and how other cultures think about and face death differently compared to those of us, especially here in the United States
- We end the conversation around one of Peter’s favorite topics of all, rucking

## The value in doing something difficult [2:30]

**Peter’s obsession with rucking**

- You may have heard Peter talk about [Michael’s book](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767) on previous podcasts or allude to his obsession with rucking
- Peter’s daughter just got back from her first sleepaway camp in Colorado and Wyoming
  - She’s 13
  - The camp was 2 weeks
  - They deliberately sent her to a hard camp
  - They work and take care of animals
  - There are no electronics
- In preparation for her camp Peter asked her to ruck with him but she didn’t really want to
  - The idea of carrying a heavy-weighted backpack for a walk with your dad in the 5 o’clock sweltering Austin heat is not that appealing
- The kids get 1, 10-minute phone call in the middle of their time at camp
  - The first thing she said was, “*Dad, I’m the fastest hiker here. All that rucking totally paid off.*”
  - The camp is at 10-12,000 feet, at altitude
  - He had her walking with 25-30 lbs in her pack
  - They have a lot of hills

**The importance of introducing kids to difficult tasks**

- Michael loves that Peter sent his daughter to a camp where she’s doing hard things outside
  - That is so valuable for kids today
  - It’s a theme that runs through his book
- At UNLV where Michael teaches, he sees a lot of students psychologically embedded in their digital worlds and in their own head
  - For them things that most would consider minor inconveniences can easily be blown up
  - The antidote to that is introducing kids to hard things when they are younger

## Michael’s upbringing with a single parent and alcoholism [5:45]

**Where did Michael grow up?**

- Northern Utah, a little town called Banfield, just outside of Salt Lake city
- Snowboarding got him into college
- He was not a great student in high school
  - He liked to go out and party
  - He was into girls and cars
- But Park City Mountain Resort would sell a season pass for $99 if you got on the honor roll
  - This is the only thing that incentivized him
  - It got him into college

**Michael’s parent’s struggle with sobriety**

- They split when his mother was 5 months pregnant
- His dad was always a heavy drinker and drug user
- When his parents met, his mom was into that lifestyle too
- His parents were married and his dad went into rehab before he was born
- As part of rehab they gave his mom a book to read to explain what her husband was going through
  - As his mom explains it, “*I’m sitting in the tub one night and I’m drinking a gin and tonic. I get to this line in this book and it says, ‘Try to drink and stop. Try it twice.’ And she goes, ‘Oh, yeah, I couldn’t do that.’*”
  - This is when his mom realizes she has a problem too
- She manages to get sober
- His dad stayed sober for a little bit, just long for her to get pregnant
- Once she was pregnant, his drinking buddy was gone and the fun was over
- Maybe he wasn’t ready for that; he took off
- Michael’s always been raised by a single parent
- He doesn’t have a relationship with his dad
  - He hasn’t heard from him since he was about 8 years old

**When you were in high school, did you know the history of your parents drinking?**

- He knew his mom didn’t drink and the reason why
- She was always respectful of his dad and didn’t give any details
- He was left to assume the reason he was not in Michael’s life was because he never stopped drinking

**What was his mom’s advice to him in high school when most kids are experimenting with alcohol?**

- His plan was to never drink because he could have a genetic predisposition to alcoholism
- He read books instead; he was a nerdy kid
- But as you turn into a teenager, your brain starts changing and you look for excitement and risk
- And all of a sudden, the pull of social things become so much more rewarding than it ever was
  - This is when he began to drink
- The town he grew up in was all Mormon
- They weren’t Mormon, and his mom was a single parent
  - They were a bit of an outcast in that sense
- Drinking made this uncomfortable feeling go away and it became a learned thing that he associated with good experiences
  - All of the sudden, he could talk to anyone, girls
  - He could say funnier things
  - He was more clever
- Eventually this stopped working so today he’s sober

## Michael’s battle with alcoholism and his experience with quitting drinking [10:00]

**The realization that drinking wasn’t working**

- Peter asks, “*What was the slow descent into the quick realization? Not everybody just has a one realization where they hit rock bottom and they switch, sometimes you have to bounce a little bit on the bottom*”
- Michael noticed the drank a little more than other people
- There were no real repercussions until he was 23-24
  - He was living alone in New York City, going to grad school
  - The bars closed at 4:00 AM
  - That was a potent combination
  - This is when he started to realize that maybe this wasn’t good
- He consulted “Dr. Google” and “signs you have a drinking problem”
  - He read 10 questions and answered yes to 5 or 6
  - When he got to the bottom of the page it said “*If you have answered yes to 1 or more of these above*…”
  - This was the moment he realized he had a problem
  - This put it on his radar
- He told himself, “*I’ll just quit when it gets bad enough*”
- He probably tried to stop when he was 25
  - He tried different ways but it never worked

**Why do you think willpower alone is not enough to stop drinking?**

- There are lots of reasons
- Some are developmental, about half of people will get sober around age 30
  - The things happening in the brain that draw a teenager towards alcohol and make it this great association, they start to shake out over time
  - You take on responsibility and have other things in your life that make you realize, “*Maybe this isn’t as good for me.*”
- Eventually the balance tips where the short-term relief isn’t as good as what this long-term thing could be
  - Coming to that realization takes a long time and a lot of bouncing
- One morning when he was 28 and living in Pennsylvania and working in a magazine based there, he woke up and his house was a mess, he was a mess
  - This morning he could see very clearly where this path was going
  - If he were to continue this drinking, he was going to die early

**How was his relationship with his mom at this age?**

- She didn’t know about his drinking; he hid it from her
- They’ve always been very close; they were always a team
- When he was in high school he would only drink when she was traveling
  - She was gone about a third of the year
- The morning his drinking problem became clear to him, she was the first person he called
- He had a girlfriend at the time who he really loved and was starting to realize, “*This is a really good person for me*”
  - They’re now married

**What did his girlfriend think of his drinking?  Was she aware of it fully?**

- She wanted him to get it under control
- She basically said, “*You’re a really good, cool dude when you’re sober, but you start drinking and you’re obnoxious*”

**The allure of drinking**

- But he was in a cycle where if 1 is good, 2 is better, 3 is even better, etc.

> “*Once you start drinking, something happens in your brain where, all of a sudden, just your entire thinking and universe shifts*”‒ Michael Easter

- He could see that giving up drinking was going to be hard, uncomfortable
  - He was going to have to relearn everything
- He didn’t know if he could do it, but he was going to try
- He would go through stints for a few weeks where he wouldn’t drink
- His mom suggested he talk to people similar to them
  - This is when he started becoming active and meeting other people who were sober

***A big part of becoming sober for him was realizing he doesn’t have to be comfortable all the time***

- This is one of the reasons why this book came about
- Alcohol was the biggest comfort blanket for him
  - If he had stress from work
- Alcohol became a learned behavior where if he drank, the problem went away
- But ultimately, over time, this was backfiring in a severe way

**How many of your friendships were predicated around alcohol consumption, and once alcohol was gone didn’t make a lot of sense?**

- There’s a few that they stuck around
- Michael got sober on December 15th and had planned to hang out with a friend/ drinking buddy on New Year’s Eve
  - It was a relief that he still wanted to hang out sober
- When he became sober he realized he didn’t have as much in common with his friends
- Peter adds, “*That’s the subtle part of this that’s really complicated*”
- Peter did his residency in Baltimore, and at the time it was the heroin capital of the US
  - It seemed like everyone who came into the ER with an abscess on their warm was addicted to heroin
    - He may have told this story on a [previous podcast](https://peterattiamd.com/patrickraddenkeefe/)
  - The best advice he could offer them (though not particularly helpful) was, “*Listen, you’re going to die from this. It didn’t kill you this time. You had a huge abscess that I cut open and drained and pulled old needles out of, and you’re really lucky to be alive. You’re going to be on IV antibiotics for a few days and then oral antibiotics for a lot longer. You only get a few more of these, and that’s going to be the last one. But I realize you can’t just leave here and go back to the row home you’re living in with all the people that are doing that same thing and expect to stop. If you want to quit heroin, you need a whole new group of people to be with.*”
    - This is a devastating thing to contemplate when your entire life is centered around this block of Baltimore where everybody is using
- Michael agrees; this plays out in the research
  - Research on alcoholics, only 15% of those who stay with their normal friend group remain sober
    - Peter is amazed it’s that high
  - Of those who start hanging out with a different group of people, 60% are sober a year later
- Michael’s wife is not a big drinker; that’s super helpful
  - It’s a lot harder for people whose significant other is a heavy drinker
  - It becomes almost an illogical decision not to drink in the short term
  - It’s only maladaptive in the long term

**What is this adaptation for?**

- It serves him well in the short term but not in the long term
- Peter asks, “*Is it related to his abandonment as a child by his father?… coupled with the genetic predisposition, which is the way things work in life, do you have an environmental and a genetic component to something? Did you at the time think, ‘I should also probably figure out how much of this is driven by that feeling or that vacancy.’?*”

> “*Early on you’re just trying to figure it out day to day*”‒ Michael Easter

- Early on you’re just trying not to drink, you’ve just trying to make the next right decision
- Everyone has their own onion, whatever it is, that needs that unpeeling
- And just like with a real onion, sometimes you cry during it, but it’s the right thing to do

## Origin of the idea that we are in a crisis of comfort [20:30]

**At the magazine you were working at that time, what were you writing about?**

- Michael was running all the fitness coverage for [*Men’s Health*](https://www.menshealth.com/)
  - This is how he originally met Peter, [Bill Gifford](https://www.linkedin.com/in/bill-gifford-125868b) introduced them
  - Michael interviewed Peter for a piece
- He wrote about fitness, nutrition, performance, and some mental health stuff
- He worked there for 6-7 years

**Where did you get this idea that we are in a crisis of comfort?**

- A few things happened
- 1 – Working at the magazine, he noticed in everything he was writing about that ***you have to go through a short-term discomfort in order to improve***
  - To get fit, you’re going to have to exercise harder than you are now
  - To lose weight, you’re going to have to be hungry at some point
  - If you want to improve your mental health, you’re going to have to ask yourself some hard questions about “*Why do I feel this way? What’s happening? What’s the underlying behavior and motivation?*”
- 2 – He got sober December 2014; that was exceedingly hard
  - But things settle after you’re done with the white-knuckling
  - His white-knucking was probably shorter than for some people because he was psychologically done with it
  - You have to relearn all these behaviors and figure out how to deal with things
  - That’s really tough
  - But soon everything in his life got better
    - His performance at work, his writing
    - His finances
    - He lost weight
  - Internally, things had really changed and he wanted to keep that energy going

> “*I got that from being willing to step into the fire, to enter the cave. That was the one that I feared.*”‒ Michael Easter

- This set the stage for the idea that going through discomfort often leads to something really good in the long term
  - It’s a necessary buy-in for change
- He started thinking about this idea of comfort and observed that life is pretty comfortable in a lot of different ways
- What really brought the idea together (that would ultimately become the book) was a backcountry elk hunt he did with [Donnie Vincent](https://www.donnievincent.com/pages/bio)
  - He’s a backcountry bow-hunter, filmmaker who Michael profiled for *Men’s Health* magazine
  - Donnie was on this elk hunt for about 2 weeks, Michael was with him for about 5 days
    - They were in the Nevada mountains
    - It was a backpack hunt

**What led you to want to do the profile on Donnie?**

- Michael came across a YouTube video of his called [*Who We Are*](https://youtu.be/fL3gCr2Jr0U)
- He had always been interested in the outdoors and hunting but had never come across any material around hunting that spoke to him until this
- Donnie’s profession is a hunting and fishing guide
- Michael describes him as being “*part locavore, part naturalist, part environmentalist, part conservationist, part ultra athlete*”
- Michael joined him on an elk hunt in September and they backpacked up to 11,000 feet
  - It was freezing cold
  - They could only pack in some food
  - Getting water required hiking down to a stream and hoofing it up
- Peter points out, “*Most people don’t understand that you really only can shoot the elk at dawn and dusk*”
  - The rest of the day is spent doing recon
- Michael had no idea until he was there; he could have packed better
  - He found himself bored in the afternoon
- During the 5 days Michael was with Donnie on the hunt they didn’t get an elk
  - They got within 40 yards of one but it was too young
  - The elk didn’t see them but Michael was in awe of its large size
  - A coyote came in and spooked the elk
- Donnie got an elk just after Michael left

**The inspiration for his book,** [***The Comfort Crisis***](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767)

- When Michael got back home to Las Vegas he felt great and realized, “*Man, the world I’m in now is so different than the world I was in up there. And it’s different because this is comfortable in every way. And that, it was uncomfortable in almost every way. And yet that…*”
- This got him thinking because it didn’t make sense
  - He was rapidly back in his world of comfort
  - He started looking at all the things that impacted his daily life the most
  - He couldn’t live in Las Vegas if it were not for air conditioning
  - On his drive to work he streams entertainment from XM Radio

> “*I don’t have to be alone with my thoughts*”‒ Michael Easter

- He doesn’t have to work for any of his food
- Food is also exceedingly calorie-dense and available in great abundance
- He can eat anytime

- He started asking, “*How are all these other comforts affecting us?  Have we almost become too comfortable?  What happens if you push back against this?  What are the key types of discomfort that we evolve to face, and do those still help us today?*”
- He realized this was a lot of material
- It didn’t sound like a magazine article, it sounded like a book
- The overarching narrative of the book was a 33 day trip in the Alaskan Arctic
  - He faced discomforts that humans used to face in the past that can still be beneficial to us now that our world is comfortable
  - He wove stories in and out of this narrative leaving book agents to wonder, “*Is this in the adventure section? Is it self-help? What is it?*”

## The death of boredom in modern society [28:45]

**The discomfort of boredom**

- Peter has thought about most of these discomforts before but the one that caught him by surprise was boredom

> “*In some ways, that’s [boredom is] the most insidious comfort we’ve cured*”‒ Peter Attia

- Michael discusses the first time there is an external source of input that you can numb your boredom with
  - The radio in the 1920s, the television in the 1950s
- Before theme there is reading, but it’s not the same type of remedy
- Michael describes June 29th, 2007 as the death of boredom with the advent of the iPhone
  - This was a major shift
  - Look at how much time people spend engaged with digital media today
    - When he wrote the book the average was 11 hours and 6 minutes
    - Now it’s past 12 hours
- Peter questions this time, does it include working at the computer
- Michael  points out that cell phone usage is up to an average of 3 hours a day
- Television is the most dominant digital media capturing our attention
- Peter wonders, how much of the time when TV is on are people not watching (like when he’s cooking)?
  - He feels out of touch because if he watched 6 hours of TV in a week, that would be a big week of TV

**How is the average person watching 4 hours of TV a day (or whatever it is)?**

- Data from Netflix show that when they release a new series, thousands upon thousands of people will binge 12 episodes in a weekend
- When Netflix began streaming, they went all in‒ they financed [*House of Cards*](https://en.wikipedia.org/wiki/House_of_Cards_(American_TV_series)) and as a random thing, they put up all the episodes at once
  - A crazy number of people binged the show
  - This is when binge watching shows began

**Smartphones**

- Peter notices the time he spends paying attention to his phone
  - Early on in the days of his first Blackberry, email is what he cared most about because he was in work mode
  - He thinks about now compared to life before smartphones, he’s old enough to remember sitting on the toilet and not reading the news on his phone
  - Now he’s pretty much always reading the news, it’s weird
  - “*If you think about something as silly as sitting on the toilet, you’re not there for that long, do you really need to be doing anything else?*”

**Downtime on a hunt led Micheal to think about the idea of boredom**

- Michael started thinking about the idea of boredom when he was on the hunt, there’s a lot of sitting on a hill and looking for animals
- Animals are pretty sparse
- Most people can’t fathom what it actually means to scour 20,000 acres for an animal

> “*It is 99.99999% extreme boredom and 1,000001% pure panic*”‒ Peter Attia

- In the Alaskan arctic, Michael was hunting caribou
  - They timed their hunt to the caribou migration and were waiting for the animals to come through
- There was 5 days in a row of not seeing anything
  - He didn’t bring a cell phone, books, or magazines
  - To entertain themselves they read the labels on their food
  - He did bring a write-in rain notebook that he brings on any journalistic assignment
    - He came up with 17 different ideas for the magazines he writes for, and they’re all very good
    - He started writing some of the book
- This led him to a point about boredom‒ **boredom is an evolutionary discomfort that basically, tells us, “*****Whatever you’re doing with your time, the return on your time invested has worn thin*****.”**
- A million years ago you would need to hunt for food or else you’d starve
  - In this context, when no animals are coming through, boredom is going to kick on and tell us, “*Go do something else*.”
    - Then you might pick berries or whatever it might be

> “*Boredom tells us, do something; and in the past that something used to be productive*”‒ Michael Easter

- Boredom used to move our lives forward in a way, but now when we feel this evolutionary discomfort of boredom, we have very easy, very effortless escapes from it
- You just pull out your cell phone
  - We have the ultimate vehicle for stimulation and attention capture on our persons at all time
  - It has put a big dent in boredom and boredom does come with benefits

## The benefits of boredom [36:00]

**Interesting (and totally hilarious)** [**studies**](https://clok.uclan.ac.uk/22263/1/22263%20Does%2520being%2520bored%2520make%2520us%2520more%2520creativeV2.pdf) **around boredom and creativity**

- 1 – Take a group of people and let them do whatever they want, use their cell phones or whatever
- 2 – Take another group, bore the hell out of  them and then give them a creativity test

***The bored group always comes up with more creative answers than the non-bored group***

- Michael thinks being bored allows your brain time to process information in the background, to let things happen
- Think about the cliche of getting your best ideas in the shower‒ it’s a cliche for a reason
- When we’re focused outwardly on the outside world like in a screen, our phone, Netflix, even this conversation, your brain’s working hard to process that information so it’s in **work mode**
- When you have these moments of boredom you tend to go inside for a little while as you figure out what to do
  - You have some weird, funky thoughts and that’s more like a **rest mode** for your brain
  - Michael calls it **unfocused mode** in the book
  - Good things seem to come from this
- Michael notes that *“What we do with boredom now increasingly is something that isn’t moving our lives forward.”*

**What you do with boredom is important**

- He’s not saying burn your cell phone and go back to a flip phone or any of that
- Instead, we need to think about putting more boredom back into our lives
- There’s a lot of talk about reducing phone screen time
  - But what tends to happen is people take an hour off their phone and watch Netflix instead‒ you’re brain doesn’t know the difference

> “*It’s better to have time where you’re just unstimulated*”‒ Michael Easter

- Michael takes a walk every day for at least 20 minutes and just lets his mind do what it needs to do (no phone)
  - This also gets you out into nature which has its own benefits
- Peter relates this to rucking, when he talks about this with friends and tries to get them into it he tells them, “*Don’t bring your phone. You’re not listening to a podcast and you’re not listening to music. The whole key to this thing is going without the phone so that all you’re hearing… is the wind*”
  - You want to get into that zone of not being with the phone
  - For Peter, who is the king of efficiency, there is never a time when he’s not listening to an audio book or a podcast, or on a phone call
    - When he’s moving one of those 3 things are happening
- Michael was the same way but as he started digging into this research it changed how he thought about it

***He finds he gets better ideas and his mind goes to more interesting places when he’s disconnected and doesn’t bring the phone along***

## The value of disconnecting and being in nature [39:15]

**Relating this to hunting and awakening one’s senses**

- Peter finds on a hunt it takes him 2 days to find his senses
- One of the reasons he likes [axis deer](https://en.wikipedia.org/wiki/Chital) so much is you’re doing something very positive for the environment
  - The meat is incredibly healthy, it tastes great
  - The challenge of hunting them is high, they have really good senses
  - “*If you try to go and hunt them in a clumsy way, where your senses aren’t heightened, it’s a joke. It’s like they’re toying with you. They’ll smell you a mile away, they’ll see you a mile away, they’ll hear you a mile away. You’re not going to get within their zip code.*”
- If you can shoot an axis deer with a bow, you have earned that animal
- You can only get up on them if you become attuned to the wind, attuned visually to what’s going on, and to every sound you’re making
- This takes a day or 2
  - You don’t have your phone with you, you’re not listening to anything else as you’re making this move
  - Peter remembers what this transition feels like and getting there is hard
  - It is boring as hell but you have to go through that for your senses to wake up

![](https://peterattiamd.com/wp-content/uploads/2022/09/f1-easter.png)

**Figure 1****. Male axis deer (aka chital)**  Image credit: [*Wikipedia*](https://en.wikipedia.org/wiki/Chital)

- Michael thinks this is a metaphor for the book as a whole‒ ***you have to go through boredom to get that benefit***
- There’s a lot of different things that we’ve removed from our lives that going through can benefit us
- Peter’s experience totally jives with his and it relates to the [Three-Day Effect](https://www.rei.com/blog/camp/the-nature-fix-the-three-day-effect)

**The Three-Day Effect**

- “***After 3 days in nature, a lot of good things tend to happen to people***”
- In the modern world, your brain tends to ride what are called [beta waves](https://en.wikipedia.org/wiki/Beta_wave), frenetic sort of go, go, go associated with stress, burn out and this sort of thing
- After your third day in nature, brain tends to start to ride what are called [alpha waves](https://en.wikipedia.org/wiki/Alpha_wave)
  - These are produced by meditation
  - They are associated with a feeling of calm, focus, and greater awareness
- Researchers think extended time in nature is a way to help veterans with PTSD
  - The benefits don’t seem to wash off immediately
- The idea of the Three-Day Effect is at the top of the nature pyramid he writes about in the [book](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767)
  - He prescribes different amounts of time you should spend in different types of nature
  - 3 days in backcountry nature is at the pinnacle of this and we should try to do this at least once a year

**Hunting in the wilderness**

- Peter relates, “*If you’re going out there to try to kill an elk or a deer, it’s going to take you a week. And my first elk hunt, seven days later I didn’t have an elk. That’s not uncommon.*”
  - You have to be an exceptional hunter to get an elk on public land
- What people often don’t realize about hunting is you’re not hanging on on a trail or trotted ground
  - You’re embedded in the wilderness, bush whacking the entire time
  - You can be completely off the grid and in nature
- This is what makes hunting compelling to Michael, rather than being an observer of nature, you become a participant it it
- He had his reservations about hunting before his first big game hunt; he wasn’t sure how he would feel about it
- But Donnie told him, “*I think you’d understand why we go out there and do this thing if you were to actually hunt*” and Michael trusted him and can see the appeal
- Peter’s daughter brought this up when she got back from her sleepaway camp

## Changing the dynamic of how we think about food and the story of Peter’s daughter’s first hunt [43:45]

**Peter brought his daughter on a hunt**

- Peter brought her on a hunt with him when she was 10 or 11, and in retrospect, he’s really glad he did
  - He doesn’t know what he was thinking at the time because it’s hard to see an animal die
  - Most experienced hunters he knows have a real respect for life and what he describes as the **carbon cycle**, which we’re a part of too
    - We’re going to die and our carbon is going back into the earth and are nitrogen is going to fertilize something around us
- The 1 axis deer she sees him shoot is a disaster because he forgot the front stabilizer for his bow
- They’re booking it at 4 am to be in position to try to see deer by 5:30 and get a shot
- He took the front stabilizer off his bow the night before (something he would never do) and forgot to put it back on
- They’re an hour in and he realizes he doesn’t have it but there’s no choice, if they go back they’re done for the morning
- He’s never shot his bow without the front stabilizer but it’s doable
- To make a long story short, he got a 47 yard shot at this axis deer and doesn’t hit his sweet spot
  - On an axis deer it’s not that big
  - This deer probably weighted 150 lbs, not as big as the monsters in Hawaii that can grow to 200-220 lbs
- Instead, he hit it in the neck (it hits his spinal cord) and it drops immediately, paralyzed
  - So now he has to run up and stick a knife into its heart to kill it
  - On one hand you could say, “*Well, he [the deer] doesn’t feel anything,*” but you could argue psychologically, this is pretty traumatic
  - It wasn’t a clean kill, his daughter sees a very messy kill
- She handled it amazing well, she got a little nauseous
- Peter likes to take the insides apart after he shoots an animal
  - It helps him understand the anatomy
  - Plus he eats the heart and some of the organs
- They took the deer back to the hotel they were staying at in Maui and ate it
- They befriended the chef who prepared it and they shared it with everyone who worked at the hotel
  - It fed 50 people
  - It was really fantastic
- The people local to Hawaii know what axis deer do to their community, they destroy farms
- Many of them had never eaten an axis deer
- When his daughter got back from camp she was talking about this experience
- She said one of the counselors there was a vegan so for a week she went vegan too
  - She thought it was all right but probably not for her
- Peter has talked to his daughter about 3 reasons people would associate with being vegan: animal rights, environmental reasons about climate change, and perceived health reasons
  - For his daughter’s counselor it was about the treatment of animals
  - Peter respects this
  - Part of him thinks you shouldn’t be able to eat meat unless you can kill it
    - That doesn’t mean you have to kill everything you’re eating, because that gets pretty complicated
  - “*But if you can’t actually kill an animal psychologically, maybe you should question whether you should be eating it.  That would be at least a discussion to have*.”
    - This is why he wanted his daughter to see this early in life to understand when you’re eating an animal, it was a thing that was alive
- His daughter shared her experience with this counselor, which is they eat elk and axis deer most days
  - The counselor was super impressed
  - His daughter was able to explain the manner in which these things are killed which Peter thought was cool
- This gets back to Michaels’ point which is, “*It totally changes the dynamic of how you think about food*”
- It also makes you realize how easy is it to be able to use a sophisticated weapon like this and think about what our ancestors had to do

**Traditional bow and arrows used for hunting**

- [Darren Aronofsky](https://en.wikipedia.org/wiki/Darren_Aronofsky) (a good friend of Peter’s) was filming hunters in Papua New Guinea for a documentary and they hunt with bows and arrows
  - He brought back one of their actual bows and arrows, shown in the figure below
  - They kill an animal 10-20 yards away with that

![](https://peterattiamd.com/wp-content/uploads/2022/09/f2-easter.png)

**Figure 2.  Bow and arrow from a tribe in Papua New Guinea**

- Michael was just in the Bolivia Amazon with the [Tsimané Tribe](https://en.wikipedia.org/wiki/Tsiman%C3%A9) and that’s what they hunt with
  - They kill fish, they hunt tapir
- It’s still an enormous step forward to use a compound bow for hunting

## How a profound experience at an elk hunt changed Michael’s thoughts about life and death [49:15]

**Michael’s experience hunting**

- Michael had his hesitations about hunting, about the act of taking a life
- He told himself it’s because he’s a journalist and journalists don’t get involved in the story, they’re just there to cover it
- Michael is glad he trusted Donnie, that book ended up better
- Specifically, there is this section where he talks about death; it’s a lot richer because of that experience of killing a caribou
- He was carrying around the rifle for a couple of weeks and finally got in a position on a hill and there was a herd of caribou on the other side of the valley
- Donnie said, “*They keep eating their way down this hill. They’re probably going to come over this null so if we can get on the other side of the null, we’re going to be in a good position*.”
- They start cranking through the grass on the tundra and get into an army crawl, planning on the herd coming over the hill
- They get into position, and it’s like something out of [*Planet Earth*](https://en.wikipedia.org/wiki/Planet_Earth_(franchise)) where you’re watching this hill and then all of a sudden, the first thing you see are these gigantic  antlers
- There’s 1 and then 2 and eventually 30 of them coming
- “*And we’re looking at them because we’re only wanting to shoot something that’s old*”
- They were pretty far away when they spotted them, maybe a mile
- Eventually they see an old limping bull in the herd
- In that moment Michael thinks, “*I’ve got the rifle, I’m in position. I don’t have to pull the trigger*.”
  - This was weeks into the hunt
- But when he saw the limping bull, it felt right
- It was a tough process to get the shot off because they’re going in and out of the herd and you want a clean shot
- They were maybe 150 yards ahead of them and that was a close as they were going to get
- He couldn’t get them in the scope and Donnie tells him “*If you don’t want to take the shot, don’t take the shot*.”
- He knew he had to do it soon and right after that, the herd parted and he had a perfect shot
- He pulled the trigger, and pulled it again
- The herd ran and his initial reaction was, “*Oh my God, what have you done?*”
  - It was immediate regret and sadness
  - It didn’t help when they came up on the animal
- It was really interesting though, he had a lot of emotions around that

**Where meat comes from**

- To realize, “*Wait a minute, that’s meat*” and that’s why they’re doing this

***You don’t really understand that until you experience it***

- Then it occurred to him, “*Dude, you eat meat all the time*” and never once questioned it or felt one iota of emotion
- Not only that, but this animal he just shot died more humanely and suffered less than anything  he’s eaten
- Peter adds, “*It lived a beautiful traumatic life in nature which is what it is, let’s not romanticize nature. But it wasn’t in a corral, it wasn’t force fed antibiotics*.”
- Until Peter met [Jake Muise](https://mauinuivenison.com/pages/about-us) in Hawaii, he never appreciated the stress an animal is in during the final hours of its life and how that impacts the food quality
  - Jake Muise was on the [podcast in April of 2021](https://peterattiamd.com/jakemuise/)
- It’s totally different when an animal gets a bullet through it and dies quickly
  - There’s no cortisol surging through it, no lactic acid
- What Michael did is about the most humane thing you could have offered that animal relative to anything you’ve eaten
  - But also, given to what it’s natural history is, that’s the other thing people have to understand‒ these old animals don’t go to old animal folks homes
  - Old animals get killed by wolves
  - Or drown crossing rivers when they make this migration
  - Or freeze to death
  - They have a harder time getting food as they age, so he could starve to death
- After this a deep appreciation set in, a sort of gratitude
- He was very thank for for that meat
- He also wished our meat system had some changes to it but he was thankful for all the other meat we have because he realized the buy-in that goes into this

***It was a very intense realization that for one life to go on, another has to die***

**The idea of death**

- This eventually got him thinking about death in general, how he’s going to die, we’re all going to die
  - That is an uncomfortable thought

> “*I start thinking about that and this idea of death is the most uncomfortable thing that we can think about*”‒ Michael Easter

- Michael adds, “*When you do it right, you’ll ball up like a child*”

***But when he started practicing that, he found that it improved his life, because it changed his behavior***

- Thinking about death
  - It improved his behavior
  - He started to make better decisions about work and what he’s going to do with his time
  - It improved his interactions with other people, everyone from his wife to the lady at the 7-11
- If you look at our structures in the US, we don’t think about death, we want to ignore it
- Back to our food system‒ it’s based around meat and the way it’s processed we don’t really know that it has come from an animal
  - We have euphemisms for different cuts of meat, instead of saying muscle
- In our funeral system‒ when someone passes away, we dress them up to look as alive and youthful as possible
  - We have a viewing and then we’re told, “*Take your mind off it. Don’t worry about it. Don’t think about it*.”
- Michael wondered what some of the repercussions of that are
- What other ways do different people do this?
- This led him on a trip to Bhutan, a fascinating place

## How happiness can thrive in places without all of the modern comforts of the West [57:15]

- The country of [Bhutan](https://en.wikipedia.org/wiki/Bhutan) is dirt poor, if you measure it by GDP they are 160-something out of 184
- But in happiness measurements, they rank in the top 20
  - How they approach death factors in
- The Bhutanese are told to think about death 3 times a day
  - It’s kind of a cultural practice
- Death is woven into a lot of the art and the cultural dances and heritage
- There’s even these little clay pyramids all over the country made from mud mixed with the ashes of cremated people
  - You take a turn on a road and there might be 300 of them
  - They’re in the window sills in the city
  - They’re everywhere, a constant reminder
- This flows in with this idea of impermanence and Buddhism
- Michael traveled there to learn more about this after the hunt
- He met different people there, the first was a guy guy named [Dasho Karma Ura](https://en.wikipedia.org/wiki/Karma_Ura)
  - A  Dasho is like secretary in the US
  - We have a secretary of state and they have a secretary of happiness

> “*92% of Bhutanese say that they are happy more or less*”‒ Michael Easter

- In the US our happiness numbers are dropping
  - Michael is not sure what it is, maybe 40% say they are happy
- Peter is familiar with this research and  has talked a lot about it with [Arthur Brooks](https://www.hbs.edu/faculty/Pages/profile.aspx?facId=1134664) who studies happiness, and it’s hard for people to wrap their head around some of this stuff
  - Stay tuned for an episode of *The Drive* with Arthur Brooks
- You have to actually go and experience places away from what we do
  - You don’t necessarily have to go to Bhutan, but you have to see other parts of the world

**Experience of physician Tom Catena practicing medicine in the Nuba mountains of Sudan**

- Several years ago [Peter interviewed](https://peterattiamd.com/tomcatena/) an amazing physician named [Tom Catena](https://en.wikipedia.org/wiki/Tom_Catena), he’s a missionary physician in one of the worst parts of Sudan
  - There are about a million people in the Nuba mountains with no access to healthcare who were being bombed by their government
  - He runs the hospital that takes care of these people
  - One of the things he discussed was the fact that nobody’s depressed
  - He has only seen 1 case of suicide and that was probably related to a brain tumor that altered that person’s brain
  - The circumstances there sound miserable and Peter wondered, “*How are people not just in a state of pure misery?*”
  - It turns out, there is an amazing sense of community there (which we’ll also talk about in Bhutan)

**Michael’s observations in Bhutan**

- Michael adds that economic equality can affect happiness too
- There’s generally more economic equality in Bhutan
- The pace of life feels slower than it does here and they have spend more time in nature
- They also have no debt
- There is universal healthcare, it isn’t perfect but if you have something that needs to be treated beyond what they are capable of, the country will fly you to India or somewhere else
- They are healthier, the obesity rate is 6%
- What they’ve tried to do is prevent the influence of other places from coming in and sort of let Bhutan figure itself out without other places intervening
- It’s a country of about 3 million people and 600,000 live in the capital, Thimphu
  - Most other people live in the countryside and mountsides in small communities of maybe 200 people

**Benefits of living life at a slower pace**

- Peter remarks about the impact of stress
- He just got back from Italy and he spent a lot of time there thinking about why their life expectancy is 4-5 years greater than ours despite the fact that they smoke nonstop
  - Smoking is the single most damaging thing you can do to your health
- What he came to realize is they do everything else so much better
  - They eat a fraction of what we eat
  - Even though they are still eating pasta and gelato, the serving size is tiny
  - They’re much more active
  - “*But the thing that really blows my mind… the pace is just so much lower*”
  - Peter can’t imagine they’re under the stress that we put ourselves under
- The flip side of that is, maybe there’s a reason the US is the world’s biggest economy
- And maybe there’s a reason that most innovations come out of here and not Italy
- You start to appreciate the trade-off

> “*We are paying a price to be the world’s leaders in innovation. We are paying a price to have unlimited access to food and comfort.*”‒ Peter Attia

- When Peter was in Tuscany, in the middle of nowhere, the home they stayed in had no heat and no air conditioning
  - In the winter it’s freezing and in the summer it is basically a sauna
- Michael adds, “*When I started to look at a lot of what kills us now, it’s all things linked to pace and comfort*”
- Peter agrees‒ it’s over-nutrition, under-movement, and too much stress

## Why we’re hardwired for stress, and the responsibility that comes with our level of comfort [1:05:30]

**What is causing our stress?**

- Michael realized a lot of is is manufactured

> “*No one causes your stress. You cause your stress.*”‒ Michael Easter

- In his [book](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767) he talks about the concept of **prevalence induced concept change**
  - This is a nerdy way of saying problem creep

**Studies on how people perceive threats**

- Scientist at Harvard did a fun [study](https://pubmed.ncbi.nlm.nih.gov/29954981/) inspired by their experience waiting in line for TSA on the way to a conference
- They noticed a lot of people who are clearly not threatening get patted-down
  - Grandma’s getting the full body pat down because she had a half-filled bottle of hairspray in her purse
  - They pulled out my banana thinking that it was a Beretta or something
- They wondered if all of a sudden everyone just followed the rules, would they let everyone flow through and go onto your flight?
  - Or would they start looking for successively smaller things?
  - And they thought it would probably be the latter
- Peter thinks the reverse would be true‒ if every 4th person coming through actually had a gun, would the other 3 of us who have never carried a gun or threatening thing to an airport, never get patted down?
- They do 2 studies where they had people look at 800 different faces and the people had to deem whether the face was threatening or nonthreatening to them
- About midway through, they started showing people successively fewer threatening faces
- The other study was similar except they had people read research proposals and rate them as ethical or unethical
- Again, about midway through, they started feeding them fewer unethical proposals
- You would think people would start saying threatening fewer times or start finding fewer things unethical
- A person either threatens you or they don’t,and something either crosses this moral line you have in the sand or it doesn’t
- What ended up happening is they said threatening the same amount of times, same ratio of times
- They found the same amount of studies unethical

***Their takeaway was, as we experienced fewer and fewer problems, we don’t actually perceive this. We simply go out and look for other problems. We don’t become more satisfied*****.**

- The thing is, as the world improves over time, we look for problems where they maybe don’t exist

> “*There’s never been a better time to be a human being with respect to the benefits we have*”‒ Peter Attia

- When you poll people, only about 12% of people think the world is improving — “***It’s because we’re always moving the goalpost”***

**Thinking about the ability to identify problems from an evolutionary perspective**

- Michael thinks this makes evolutionary sense because in the past, when the world was hard, when you did have serious life threatening problems, if you were always identifying the next problem, that would give you a survival advantage
- Peter thinks another issue is at play here, one that he started thinking about 10 years ago when he read [*Guns, Germs, and Steel*](https://www.amazon.com/Guns-Germs-Steel-Fates-Societies/dp/0393038912/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1660062742&sr=8-1) by [Jared Diamond](https://en.wikipedia.org/wiki/Jared_Diamond#Upheaval_(2019)) (a great read)
  - It got him thinking about how awful life was
  - He wouldn’t want to be one of the Hadza right now
  - Even today, the Hadza are one of the last tribes of hunter gatherers, one of our final windows into what people were doing 10,000 years ago, there’s literally not a second of that Peter thinks of as desirable outside of a vacation
    - And by vacation, he means a hard experience you would go through for a couple of weeks to make you more appreciative of what you have when you’re back in plush Austin, Texas
  - He would never want to exist in that world
  - It was so awful he can’t believe we survived it
  - But we are tied to the genetics of people who manage to survive that
- Michael agrees, it’s unbelievable
- Especially after we start to establish cities, because then all of a sudden you have 1 king and everyone else is out in the field for 12 hours a day
  - You’re starving the whole time
  - Conditions are unsanitary, terrible
- Peter asks if Michael saw the movie, [*The Last Duel*](https://en.wikipedia.org/wiki/The_Last_Duel_(2021_film)) with Matt Damon and Adam Driver
  - It’s loosely a true story based on the last time the king of France authorized a duel (in the 14th century)
  - It was about the most privileged people in France‒ Kings and Knights
  - At the time (about 500 years ago), France and England were the most privileged in the world
  - Peter is thinking, he would rather be homeless today than the king of France 500 years ago
  - “*It is unbelievable abject misery they lived in*”
- When Peter read *Guns, Germs, and Steel* he took away how miserable life was for hunter gatherers, not that we need to go back and be hunter gatherers

**Peter’s takeaway**: “*It’s like an Uncle Ben moment with Spider-Man. It’s like* ***with great power comes great responsibility****. We have this great power today. We have processed food… you have all of these things that allow you so much latitude. Do more with it. To me, what it comes down to is* ***we have the ability to help more people****.*”

**With more resources comes responsibility**

- He thinks Michael does a great job of explaining processed food in his book
  - Processed isn’t bad, processed is actually what allows us to not get poisoned every time we eat food
- If you think about what it was like 500 years ago, if a person had mental illness 500 years ago, he doesn’t know how many other people were bending over backwards to try to make their lives better
  - Because you were just too busy trying to survive
  - Whereas today, you can help somebody else

> “*That’s the responsibility that comes with the privilege of having so much*”‒ Peter Attia

- You can afford to try to feed other people that aren’t being fed, and in a world of overnutrition it seems almost absurd that anybody would go without

**Michael’s takeaway**

- Michael makes the argument that we’ve become victims of our own success
- We need times that push back against what we have and reframe how lucky we are in the grand scheme of time and space
- Processed food is great, it keeps us alive, and is why there’s nearly 8 billion people on the planet
- At the same time, if we don’t have to move around we have problems
- If you’re always eating the most comforting food all the time, you’re going to have some problems
- It’s great that you don’t have to exercise or physically work for your food every day, but at the same time, if you never reinsert exercise into your life to make up for that, you’re going to have some problems
- It’s great that if I feel bored, I can go on Instagram and watch the most entertaining 15 seconds of my life and probably laugh my ass off for a week because I’ve found something so funny
  - But if you’re always doing that, it comes with problems

***He argues that we need moments that push back at us and reframe things***

## How perspective on the timescale of our lives in relation to history can impart positive changes [1:14:00]

**If the entire history of this universe were laid out in a calendar year, can you give some milestones?  Where did Michael hear about this idea?**

- He was driving to work and heard about this on a podcast
- He’s a little shaky on the months, but if the big bang happens on January 1st
  - Our galaxy forms in September
  - Earth forms in November
  - Dinosaurs die off on December 25th, after appearing on December 20th
    - They were around for 5 days on this calendar
  - All of human history that we have written down happens New year’s Eve 11:59 starting at 33 seconds
    - “*That is how little time we’ve been here. It’s crazy.*”

***All of recorded human history is the last 27 seconds of a year***

- When Michael started thinking about this he realized, “*You’re not damn that important in the grand scheme of time and space*”

***This sounds like you’re being hard on yourself, but at the same time, once you have that realization, it can change your behavior in a positive way***

- Because we’re all here, we’re all going to die

**Some places impart a perspective on the timescale of our life in relation to history**

- Peter relates this back to Italy because he just got back from Tuscany where he was staying with a friend on a 400 acre farm that has been built up over the years
  - The first thing built on that farm 500 years ago was a church
  - 50 years later, another house was built
  - 100 years later, this other thing was built
  - The newest thing on the farm is 300 years old
  - “*I had this sense that came over me while I was there, which was I felt so good being in a place where I knew so many people had lived and died… it really made me feel appropriately irrelevant.*”
- Peter’s friend is an American, but he lives in Tuscany 3 months out of the year
- Peter asked  him, “*Dude, I’m not being facetious, so you can say no. But if my death is reasonably inevitable, like I have cancer or something like that, would you be cool if I came and died here and was buried here?*”
  - And he’s like, “*Yeah man, that would be fantastic*”
  - Peter would really like to die in a place where he’s just an irrelevant piece of the long, beautiful history of our species
  - He likes the idea of being buried there by the olive trees so that his carbon and nitrogen can become a part of an olive tree that someone will drink olive oil from 25 years later

**Rule 62**

- When Michael was getting sober, he learned the phrase **Rule 62**‒ ***don’t take yourself so damned seriously***
- Peter’s story reminds him of this
- People have a tendency to take themselves and the things in their life so seriously, and you realize things aren’t that big of a deal… you can slow down sometimes
  - This has been freeing for him
  - It’s allowed him to improve, improve his performance at work and in life
  - It allows one to be free to do the things you want to do and let your mind go where it needs to go

***This is especially helpful for creative work***

> “*If I don’t put all this pressure on myself, I’m like, no one’s going to read this book in 200 years, 100 years, 20 years. Who knows? Just make it good. It’s a ride.*”‒ Michael Easter

**In the moment**

- Michael remembers watching this documentary about the [Grateful Dead](https://en.wikipedia.org/wiki/Grateful_Dead) (his favorite band)
  - It was around 1967 when they were coming up; they were living in San Francisco and taking a bunch of acid
  - This would have been 3 years after they played at [Ken Kesey’s Electric Koolaid Acid Test](https://en.wikipedia.org/wiki/Acid_Tests)
  - They’re in LA and [Garcia](https://en.wikipedia.org/wiki/Jerry_Garcia) talks about the big LA tower and the tourists that will come to see it
  - Garcia says, “*You know, I want to just create things that live and explode in the moment and just have fun in this moment*”
    - And that ultimately guided them as a band forever
    - Every song is like its own exploding moment and this is how Michael views what we are as humans

***No one’s going to remember you. You’re not going to have this big monument to you… Ride this thing out, give yourself some space and just enjoy it.***

## The benefit of challenging oneself and the positive carryover it can have [1:19:45]

**What is Misogi?**

- Michael learned about this concept from a guy named [Marcus Elliott](https://www.p3.md/team/marcus-elliott/)
  - He went to Harvard med school but decided he didn’t want to be traditional doctor
  - He wanted to get into sports science and revolutionize the field
  - He’s the first guy to bring AI and movement tracking into pro-sports
  - Using this data he can predict the chance of injury based on other cases documents of men of a similar size
  - He uses numbers  and data to improve performance
  - He also believes there are intangibles that cannot always be measured that can improve performance and potential
  - To get to these intangibles he does this idea called [Misogi](https://depthnotwidth.com/the-misogi-challenge-taking-risks-and-crushing-your-comfort-zone/)
- The background on this is based on the idea that humans had to do hard things all the time, without a safety net throughout our evolution
- We were challenged all the time and if we failed, we would die

***But each time you take on one of these challenges, you would inevitably learn what your potential is***

- You would really have to dig deep, push, and you would come out of that knowing what you were capable of
- But now in modern life, you start to see a shift where you can live a decent life and you’re never really challenged
  - You’ll have your running water, your food, your home, your family
- If you think of human potential like a really big circle, most people are kind of in this little dinner plate-sized thing right here, because we never explore those edges, really what we’re capable of
- Misogi is this idea that once a year, you go out into nature to do a really hard, challenging task
- There are only **2 rules of Misogi**
  - 1 – It has to be really hard, something you have a 50/50 chance of finishing
    - Often people take on physical challenges that they know they will finish, that are within their capabilities
  - 2 – You can’t die, be safe
- There are **2 guidelines** as well
  - 1 – You don’t talk about Misogi publicly
    - You can talk about it with friends, with your wife and close ones
    - But you don’t put it on Instagram, Facebook, or Twitter
    - The idea is if you’re doing something really hard and you want to quit, are you going to keep going for you, knowing that it’s not going to be for a pat on the back with social implications?
  - 2 – The Misogi should be somewhat quirky
    - Make something up
    - If you’re doing a marathon, you’re thinking about your time and all these different things that are socially constructed
    - Instead, if you pick some random task, there is no framework for this
    - And that opens up the door for some interesting experiences

**Examples of a Misogi**

- One year this guy and a few of his friends got an 85 lb boulder and walked it underneath the Santa Barbara channel, maybe 5 miles
  - One guy would dive down, pick up the Boulder walk, 10 yards, drop it, go up
  - The next guy would dive down, rinse and repeat till you’re at point B
- There’s also simpler things like, here’s this mountain that we see every day, let’s see if we can get up there in a single day

**Why do a Misogi?**

- 1 – ***It teaches you that you chronically undersell your potential***
  - You see that you are capable of more
  - As you do a hard task you keep putting one foot in front of the other and get to a point where you look back at what you thought was your edge, but you’re beyond this point
- 2 – ***It can reframe fear because we’re wired to avoid failure at all costs***
  - In the past failure meant death, but not today
  - Today, failure is mistyping in an email, a misspeak when you’re speaking to a group of people, something like that
  - Yet we still fear those kinds of things like they’re deaths

> “*Dancing on the edge of failure, you can realize that it’s not that big of a deal*”‒ Michael Easter

- When Michael first learned about this concept it sounded intriguing, cool, and at the same time kind of quirky
- Then he started researching what was happening here

**Rites of Passage**

- We used to call things like a Misogi a **rite of passage**
- When we have a young person at point A and want to get them to point B (where they are more confident, competent, and a better contributor to the tribe), we send them out into nature to do something really hard
  - Along the way they would struggle, they would battle, they would have moments of doubt
  - Ultimately, they come out on the other side realized that they are are lot more capable
  - They bring this back into society and improve the tribe as a whole
- You see these rites of passage across cultures
- It’s also in mythology
- In the work of [Joseph Campbell](https://en.wikipedia.org/wiki/Joseph_Campbell) on [*The Hero’s Journey*](https://www.amazon.com/Heros-Journey-Joseph-Campbell-Life/dp/006250102X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1660158358&sr=8-1), the hero leaves the comfort of home and is faced with battles
  - They have to go inward
  - They have to physically strive
  - Then they come back into society with the treasure of the talisman
    - This is not a physical object
    - It’s the way that person has changed and what they can bring back into society
- There’s been a falling away of traditional rites of passage like this
- This is why Michael got excited when Peter talked about sending her daughter to that camp, because kids would really benefit from  having times where they get pushed to their edges
  - Adults would benefit too
  - To have those moments of doubt where they’re not sure what they’re capable of, but to cross it and realize they can do more than they ever imagined is powerful
- You look at what people can accomplish when the conditions are survival condition
  - It’s incredible what people can do
  - And it also makes evolutionary sense to undersell yourself; it keeps you safe

**Benefits of challenges**

- Research on challenges in people’s lives show that there are 2 groups of people that have the worst mental health
- 1 – People who have had an overwhelming amount of challenges and traumas
- 2 – And on the opposite end of the spectrum are people who have no challenge in their life and no traumas

**“*****So it’s kind of a U-shaped curve where having enough challenge in your life that you learn that what you’re capable of, that you can persist through things, that you’ve got this, seems to be healthy for people*****”**

## The many benefits of rucking [1:28:45]

**What is rucking?**

- One of Peter’s favorite challenges is a daily practice of rucking
  - Though it would never rise to the level of a Misogi
- Rucking is carrying weight in a backpack for the sake of weight
- This word grew out of the military where rucking is a standard fitness practice going back hundreds and hundreds of years
- This is a feature that is unique to our species
- Michael started thinking about this when he was hunting
  - Once you kill the animal and have the meat, you have to pack it out

**The human body is built to be good at 2 things**

- 1 – Running long distances in the heat
  - The book [*Born to Run*](https://www.amazon.com/Born-Run-Hidden-Superathletes-Greatest/dp/0307266303/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1660227282&sr=8-1) was spawned from a [2004 paper in *Nature*](https://pubmed.ncbi.nlm.nih.gov/15549097/) by [Dan Lieberman](https://heb.fas.harvard.edu/people/daniel-e-lieberman)
  - We have all these adaptations that make us good at running long distances slowly in the heat, and we would use that to hunt on hot days
  - We could also walk further in a day than an animal could go at whatever pace it chose
  - We don’t have to be running; we can simply walk 3 mph and we’ll walk 75 miles in a day
  - On a hot day, 4-legged animals are not efficient at cooling themselves
  - We would chase animals down until they essentially toppled over from heat exhaustion, and we would spear them
- 2 – We have adaptations that make us really good at carrying
  - After we kill an animal we would carry that animal back to camp
  - We are in fact, the only animal that can carry
  - Peter was surprised to learn how lousy primates are at carrying
  - We can hold up to maybe 33% of our body weight and still be more efficient at covering ground than most other primates carrying nothing
  - Peter weighs 180 and could easily carry a 60 pound kettlebell in one hand
- Arguably, we carried a lot more as early humans than we would’ve run, because running is mostly reserved for hunts
- Carrying stuff back to camp is used for gathering
- Michael went to Harvard to meet with Lieberman
  - It was a fun meeting; he’s a fascinating guy

**Fitness benefits of rucking**

- Michael argued in his [book](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767) that running is popular as a form of fitness and activity but carrying is not
- He traveled to [GORUCK](https://www.goruck.com/) headquarters
  - They make backpacks specific for rucking
  - [Jason McCarthy](https://www.linkedin.com/in/jasonmccarthy) (the founder) leaned into rucking as a form of fitness
- Rucking is great because it works both the cardiovascular system and the strength system
  - Where as running and cycling are pure endurance
  - Rucking involves endurance but you also have a load on your body that stimulates muscles to a greater degree
- There are fascinating [studies](https://physoc.onlinelibrary.wiley.com/doi/full/10.14814/phy2.13925) on backcountry hunters who carry loads deep into the mountains
  - It was a small, 10-day study [of 4 men and 3 women]; they tested body fat before and after
  - Participants lost 14% of their body fat and maintained the same amount of muscle
    - Some gained an ounce or 2 of muscle

> “*So it’s really good at melting fat and preserving muscle*”‒ Michael Easter

- Peter loves getting most of his cardio done on a bike, but there’s no load on the bike
- He used to run a lot and is fortunate he had perfectly finke knees and hips despite running many 60 mile weeks growing up
- He would love to go back to running but doesn’t want to hurt himself
  - Your knees experience a force of [about 8x your body weight](https://journals.lww.com/acsm-msse/Fulltext/2014/03000/Why_Don_t_Most_Runners_Get_Knee_Osteoarthritis__A.18.aspx) with every step you run
  - Weight matters so it’s not a surprise that the best runners are feather light
  - With walking the force on your knees is only about 3x your weight
- With rucking, you’re walking and adding more weight
  - If you increase your body weight by a factor of 30%, then the 30% increase at 3 X multiple of force is much less than your body weight at 8x the force (if you were running)
  - All this is to say, “*As hard as rucking is with all that extra weight, it’s still much easier on your knees than running*”
- Peter just got back from vacation and yesterday was the first day he rucked in 2 weeks and it felt much harder after that break
  - Even though he was walking nonstop on vacation
  - Rucking is really a workout
  - His heart rate hit 165 when normally it is between 130-140s beats per minute

**Injury data on soldiers**

- [Studies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6614812/) on soldiers in the military show that people often get injured running
- In comparison, a small number of people get injured by rucking
- You get a higher heart rate than you would from walking and also preserve muscle

**Rucking improves cardiovascular fitness, eccentric strength, and bone density**

- Rucking over hills is great exercise
- Uphill you’re just obliterating your heart and lungs
- Downhill you’re working eccentric strength in your quads
  - Peter discussed the difference between eccentric and concentric strength in the newsletter [*Avoiding Injury Part I: Eccentric Strength*](https://peterattiamd.com/avoiding-injury-part-i-eccentric-strength/)
- Peter loves the downhill and tries to be as deliberate about it as possible, “*Because in life that’s where people fail*”
- When you get older, nevermind running, can you walk downstairs without collapsing?
  - You need to know how to decelerate and there’s no better way to learn than walking downhill with a big load on your back
  - This is not something you get easily in the gym or running
- Rucking is also good at improving bone density
  - So if you’ve been rucking and you do fall, you’re going to be better off
- [Studies](https://newsnetwork.mayoclinic.org/discussion/womens-wellness-bone-density-in-women/) in women show it improves bone density better than weight lifting or cardio alone
- That becomes so important as women age

- Women in hunter gatherer societies are always carrying things
  - They stay strong and vital their entire lives
  - They don’t get hip fractures

> “*We are born to carry*”‒ Michael Easter

- In hunter-gatherer societies, no one runs, but work life is carrying

## Tips for rucking: ideal load, type of pack, and other considerations [1:38:00]

**Metrics of strength Peter uses with patients**

- Peter comments that with a reasonably well-trained person, “*We can get most of our patients to the point where they can carry their body weight*”
  - A reasonably fit person could carry for a minute their body weight in their hands
  - They could carry it longer on their back
- To have the grip strength and limb strength to carry our body weight is fantastic
- One of the metrics he uses with female patients (who have less upper body strength) is the ability to carry 75% of their body weight for a minute

**How Peter began rucking**

- Peter didn’t know what rucking was when he began doing it, training for hunts
- What he does now is better than just using a weight vest
- His backyard is really, really steep
- In the weeks leading up to a hunt, he would put on a 50-lb. weighted vest and just go up and down the hill

**Why is a rucksack better than a weighted vest?**

- It tends to pull your spine into a better position to relieve and prevent back pain
- Working in front of a desk, we tend to slump over all the time
- [Stu McGill](https://uwaterloo.ca/kinesiology-health-sciences/people-profiles/stuart-mcgill) (a back expert in Canada) is a huge fan of rucking and is very careful when it comes to exercise
  - He said rucking is a great way to add some durability to people in a way that’s safe
- Peter comments on his experience with several rucksacks from GORuck, “*The belt really makes a difference when you get that belt on your hips*”
- He had shoulder surgery 4 months ago and one of the things he was super stressed about was not being able to ruck
- Amazingly, he was rucking 3 weeks after surgery even though he couldn’t do much else
  - This was because he had really well placed straps on his shoulders that weren’t putting his joints at risk
  - You can control the load by how you adjust it
  - He put all the load on his hips to cook his legs and spare his shoulder

***A rucksack beats a weighted vest in that you distribute the load posteriorly and can also distribute the load on your hips***

**The importance of a pack that fits well and the ability to adjust the weight distribution**

- It’s important to have a pack fit well on your hips, otherwise you simply can’t carry 100 lbs on your shoulders for very long
- When Michael was in the arctic and was packing out caribou, they carried 100-120 lbs. And it was nice to have the hip belt because he would spend most of the time with the weight on the hips
  - And when that started to burn he could adjust the weight to his shoulders for a while and go back and forth to get a break
- When Peter’s wife started rucking with him she asked, “*Does this ever stop hurting?*”
  - And she’s a super tough chick
  - She has a very high pain tolerance
  - The first time she ever did a dead hang, she went 3 minutes and 8 seconds, which is insane
- Peter answered, “*No, I wouldn’t say it ever really stops hurting. You can lighten the load, but no, it’s uncomfortable.*”

**Rucking loads**

- Peter and his wife carry a third of their body weight and are walking as quickly as they can
- Michael will even take meeting while rucking with a light load (20 lbs. or so)
- Rucking is very easy to flow into life
  - If you’re going to walk the dogs, just toss on a pack and all of the sudden that becomes a lot more effective

**Peter and Michael’s favorite brand of packs**

- Peter doesn’t know anybody at GORUCK or get any kickback
  - But he’s sent so many people there
  - He hopes at some point they will do a subscriber discount with them because he would love to get more people doing this
  - GORUCK has some [great videos and stuff](https://www.goruck.com/pages/what-is-rucking)
- Michael has tried a handful of pack for rucking specifically, and [GORUCK](https://www.goruck.com/pages/new-start-here) is definitely his favorite supplier
  - They’ve thought about it deeply

## Parting thoughts on the downside of comfort and benefits of difficult things [1:43:00]

**Back to Michael’s book**

- Peter comments, “*I think on some level, it’s such an obvious thing. It’s one of those books where you read it and you’re like, yeah, of course.  But if it’s not pointed out to you, it’s really easy to miss how this has happened.*”

> “*Comfort has become so ubiquitous that I don’t think we’re aware of it anymore*”‒ Peter Attia

- Peter thinks of it like the [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) “[*This is Water*](https://youtu.be/PhhC_N6Bm_s)” thing
  - “*The ubiquity of the water of course creates the irony of the fish not knowing what water is. And I kind of feel like that’s what comfort has become for at least those of us in the developed world*.”

**There are different ways things can be difficult**

- Michael adds that even if you’re pressing against comfort in one way, there’s probably a lot of other ways you’re not pressing against it
  - He has friends that can run 25 miles but if he asks them to sit in silence for 10 minutes, they’d have a problem

**Difficult things can provide benefits**

- There are all these things we’ve removed from our lives over time that have a benefit
- And figuring this out is what he’s trying to present in the book
- Then how to intelligently weave them into life
  - Because he’s not suggesting that we go back to live as hunter-gatherers
- We can use some of those things from the past to build a better future

**Relating this to hunger**

- Peter thinks part of it is hunger
- He used to do a lot of fasting, and one of the things he loved about fasting was how much he learned what he could do when he was hungry
  - He remembers going to bed so hungry he thought he’d never be able to sleep, yet he did
- He would do 7-10 day water-only fasts, and keep working out hard throughout the fast
  - The first couple times it almost killed him
- He realized, “*There’s no way our species would be here if we couldn’t figure out how to do these things when we’re hungry, be it sleep or go out and hunt or do something like that*”
- So when you think of all of these forms of discomfort‒ hunger, boredom,a physical challenge

**Peter’s takeaway**: “*We have this incredible privilege and it just comes with a little responsibility, which is just* ***make sure on a daily basis you are inserting brief windows of discomfort****, so that you’re never too far from realizing that you’re in the water*”

> “*If you’re the fish, just make sure you jump out of the water a few times a day so that you never lose sight of the water you’re in*”‒ Peter Attia

§

## Selected Links / Related Material

**Michael’s book**: [The Comfort Crisis: Embrace Discomfort To Reclaim Your Wild, Happy, Healthy Self](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767) by Michael Easter (2021) | [3:30, 5:00, 16:00, 23:15, 28:00, 1:05:30, 1:32:00. 1:27:30]]

**Donnie Vincent video**: [Who We are](https://youtu.be/fL3gCr2Jr0U) | Donnie Vincent’s perspective on hunting (November 2014, YouTube.com) | [23:30]

**Studies indicating that boredom boosts creativity**:

- [Does Being Bored Make Us More Creative?](https://clok.uclan.ac.uk/22263/1/22263%20Does%2520being%2520bored%2520make%2520us%2520more%2520creativeV2.pdf) | *Creativity Research Journal* (Mann *et al.* 2014) | [36:00]
- Interview with [James Danckert](https://www.jamesdanckert.com/) in [The Comfort Crisis: Embrace Discomfort To Reclaim Your Wild, Happy, Healthy Self](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767) by Michael Easter (2021) | [36:00]

**The Three-Day Effect**: [The Nature Fix: The Three-Day Effect](https://www.rei.com/blog/camp/the-nature-fix-the-three-day-effect) | Florence Williams, rei.com blog (May 29, 2017) | [41:00]

**Episode of** ***The Drive*** **with Jake Muise**: [#156 – Jake Muise: Humanely harvesting axis deer while alleviating its impact on Hawaii’s vulnerable ecosystems](https://peterattiamd.com/jakemuise/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (April 5, 2021) | [53:30]

**Episode of** ***The Drive*** **with Tom Catena**: [#40 – Tom Catena, M.D.: The world’s most important doctor – to nearly a million patients – saving countless lives in the war-torn and remote villages of Sudan](https://peterattiamd.com/tomcatena/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (February 11, 2009) | [1:00:00]

**Studies about perceived problems by Harvard scientists inspired by observing the TSA screening in an airport**: [Prevalence-induced concept change in human judgment](https://pubmed.ncbi.nlm.nih.gov/29954981/) | *Science* (DE Levari *et al.* 2018) | [1:06:30]

**Book‒ Guns, Germs, and Steel**: [Guns, Germs and Steel: The Fates of Human Societies](https://www.amazon.com/Guns-Germs-Steel-Fates-Societies/dp/0393038912/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1660062742&sr=8-1) by Jared Diamond (1997) | [1:08:30]

**Misogi**: [The Misogi Challenge – taking risks and crushing your comfort zone](https://depthnotwidth.com/the-misogi-challenge-taking-risks-and-crushing-your-comfort-zone/) | Depth Not Width (March 13, 2021) | [1:20:30]

**Joseph Campbell’s book**: [The Hero’s Journey: Joseph Campbell on His Life and Work](https://www.amazon.com/Heros-Journey-Joseph-Campbell-Life/dp/006250102X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1660158358&sr=8-1) by Joseph Campbell (1990) | [1:26:30]

**Book** ***Born to Run***: [Born to Run: A Hidden Tribe, Superathletes, and the Greatest Race the World Has Never Seen](https://www.amazon.com/Born-Run-Hidden-Superathletes-Greatest/dp/0307266303/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1660227282&sr=8-1) by Christopher McDougall (2009) | [1:29:45]

**Dan Lieberman’s** ***Nature*** **paper on running**: [Endurance running and the evolution of Homo](https://pubmed.ncbi.nlm.nih.gov/15549097/) | *Nature* (DM Bramble and DE Lieberman 2004) [1:29:45]

**Study of backcountry hunters who carry loads, effects on fat and muscle**: [The energy requirements and metabolic benefits of wilderness hunting in Alaska](https://physoc.onlinelibrary.wiley.com/doi/full/10.14814/phy2.13925) | *Physiological Reports* (RH Coker *et al.* 2018) | [1:33:00]

**Force experienced by knees during running**: [Why Don’t Most Runners Get Knee Osteoarthritis? A Case for Per-Unit-Distance Loads](https://journals.lww.com/acsm-msse/Fulltext/2014/03000/Why_Don_t_Most_Runners_Get_Knee_Osteoarthritis__A.18.aspx) | *Medicine & Science in Sports & Exercise* (RH Miller *et al.* 2014) | [1:34:00]

**Injuries of soldiers are due to running more than foot marching**: [Medical Encounters During the United States Army Special Forces Assessment and Selection Course](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6614812/) | *Military Medicine*(JJ Knapik *et al.* 2019) | [1:35:15]

**Studies of bone density in women who go rucking**: [Women’s Wellness: Bone density in women](https://newsnetwork.mayoclinic.org/discussion/womens-wellness-bone-density-in-women/) | Dana Sparks, *Mayo Clinic News Network* (May 18, 2018) | [1:37:15]

**Michael’s website**: [Michael Easter: AUTHOR // SPEAKER // PROFESSOR // EXPLORER](https://eastermichael.com/) | eastermichael.com

**Michael’s newsletter**: [The 2 Percent  Newsletter](https://unique-painter-9003.ck.page/441934d2f0) | (2020)

§

## People Mentioned

- [Bill Gifford](https://www.linkedin.com/in/bill-gifford-125868b) (Editor and author) [20:45]
- [Donnie Vincent](https://www.donnievincent.com/pages/bio) (Filmmaker and backcountry hunter) [23:15, 40:15, 43:30, 49:00, 52:45]
- [Darren Aronofsky](https://en.wikipedia.org/wiki/Darren_Aronofsky) (film director, producer, and screenwriter) [48:30]
- [Jake Muise](https://mauinuivenison.com/pages/about-us) (found of the Axis Deer Institute) [53:30]
- [Dasho Karma Ura](https://en.wikipedia.org/wiki/Karma_Ura) (President of the Center for Bhutan Studies and Gross National Happiness Research) [58:45]
- [Arthur Brooks](https://www.hbs.edu/faculty/Pages/profile.aspx?facId=1134664) (Professor of Management Practice at Harvard University, studies happiness) [59:30]
- [Thomas (Tom) Catena](https://en.wikipedia.org/wiki/Tom_Catena), a missionary physician who runs Mother of Mercy Hospital in the Nuba Mountains in Sudan [1:00:00]
- [Jared Diamond](https://en.wikipedia.org/wiki/Jared_Diamond#Upheaval_(2019)) (Professor of Geology at UCLA) [1:08:30]
- [Marcus Elliott](https://www.p3.md/team/marcus-elliott/) (Harvard trained physician specializing in performance enhancement of elite athletes) [1:19:45]
- [Joseph Campbell](https://en.wikipedia.org/wiki/Joseph_Campbell) (Writer, Professor of Literature at Sarah Lawrence College who worked in comparative mythology) [1:26:30]
- [Daniel (Dan) Lieberman](https://heb.fas.harvard.edu/people/daniel-e-lieberman) (Professor and Chair of Human Evolutionary Biology at Harvard University) [1:32:15]
- [Jason McCarthy](https://www.linkedin.com/in/jasonmccarthy) (founder of [GORUCK](https://www.goruck.com/)) [1:35:15]
- [Stuart (Stu) McGill](https://uwaterloo.ca/kinesiology-health-sciences/people-profiles/stuart-mcgill) (Professor emeritus at the University of Waterloo, expert in mechanisms of back pain) [1:42:00]
- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) (American author and Professor of English) [1:45:59]

§

![](https://peterattiamd.com/wp-content/uploads/2022/10/bio-pic-easter.jpeg)

##### Michael Easter, MA

Michael Easter earned his B.A. at Wheaton College and M.A. in Health Journalism at New York University.

Michael Easter teaches journalism, with a special emphasis on health media at the University of Nevada, Las Vegas.  Michael hosts *Nevada Health*, a weekly health radio show on KUNV, and his writing appears in *Men’s Health*, *Outside*, *Vice*, *Cosmopolitan*, *Scientific American*, *Men’s Journal*, and *FiveThirtyEight*.  Michael authored [*The Comfort Crisis*](https://www.amazon.com/Comfort-Crisis-Embrace-Discomfort-Reclaim/dp/0593138767), a best seller.  His book has been translated into 10 different languages and adopted by Major League Baseball teams, top-ranked NCAA D1 football programs, top-tier universities and law programs, major corporations, and tier-one military units.

Michael’s work and ideas have appeared in over 60 countries. They’ve been endorsed by directors of the CIA and Navy SEALs, gold medal-winning Olympians, leading physicians, Pulitzer Prize-winning authors, Buddhist and environmental leaders, and more. His writing has appeared in *Men’s Health*, where he’s a Contributing Editor, and *Outside*, *Men’s Journal*, *Cosmopolitan*, *Vice*, *Esquire*, *Scientific American*, *FiveThirtyEight*, and *Women’s Health*. He’s also talked about his work and ideas on the world’s largest, most influential podcasts, like *The Joe Rogan Experience*, *Art of Manliness*, *Impact Theory*, *NPR*, *EconTalk*, and more.

When he’s not on the ground reporting, Michael is a professor in the journalism department at UNLV. He co-founded and co-directs the [Public Communications Institute](https://www.unlv.edu/urbanaffairs/pci), a think tank at the University of Nevada Las Vegas (UNLV). [[UNLV](https://www.unlv.edu/news/expert/michael-easter) and [eastermichael.com](https://eastermichael.com/about/)]

Michael’s website: [ME](https://eastermichael.com/)

Michael’s newsletter: [The 2 Percent Newsletter](https://unique-painter-9003.ck.page/441934d2f0)

Instagram: [michael\_easter](https://www.instagram.com/michael_easter/?hl=en)

Twitter: [@Michael\_Easter](https://twitter.com/michael_easter?lang=en)

Facebook: [Michael Easter](https://www.facebook.com/pages/category/Writer/Michael-Easter-225875898170585/)