# #92 – AMA #12: Strategies for longevity (which don’t require a doctor)

**Source:** [https://peterattiamd.com/ama12/](https://peterattiamd.com/ama12/)

---

In this “Ask Me Anything” (AMA) episode, Peter explains the various levers one can pull to affect longevity with a specific focus on the strategies and tactics one can implement that do not require the help of a physician. This episode heavily features insights into nutrition, exercise physiology, and sleep physiology. Once again, Bob Kaplan, Peter’s head of research, will be asking the questions. If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #12 show notes page](https://peterattiamd.com/ama12/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- The five levers you can pull to affect longevity [1:15];
- Nutritional biochemistry: Framework, 3 nutritional interventions, and how to approach your goals, and what you should be tracking [4:30];
- Exercise for brain health, and the 4 components of exercise [20:45];
- Exercise component—Stability [24:30];
- Exercise component—Strength [29:00];
- What is Peter optimizing for with his exercise? [30:30];
- Exercise components—Zone 2 and zone 5 training [33:15];
- More about DNS, and why we need to be careful with rushing kids through neuromuscular development stages [45:00];
- Sleep: How to improve quantity and quality [48:15]; and
- More.

§

The Peter Attia Drive

Strategies for longevity (which don't require a doctor)

§

## Show Notes

## The five levers you can pull to affect longevity [1:15]

1. Nutritional biochemistry
2. Exercise physiology
3. Sleep physiology
4. Distress tolerance
5. Exogenous molecules (drugs, hormones, supplements … and maybe telomeres)

The podcast is going to focus today on **things that one can do that specifically does not require the help of a physician**

> “The good news is you can do more on your own than you require the help of a physician for.”

## Nutritional biochemistry: Framework, 3 nutritional interventions, and how to approach your goals, and what you should be tracking [4:30]

> “Nutrition…might be the most complicated because I think it has the most variable response for a given individual to a given stimulus.”

**Variation in individuals**

- The same dietary program may work for one person and not for another
- This is the source of a lot of frustration for people who are doing everything “right” but aren’t getting the results they expected

“*The* ***overarching principle*** *of nutritional biochemistry is you have to be malleable, you have to be empirical, and you have to assume that if it doesn’t work and you’ve tried it correctly, that that’s okay. And that there’s another approach.*”

**Framework for nutrition**

⇒ See Peter’s [email newsletter](https://peterattiamd.com/my-nutritional-framework/) on this topic

**The 3 nutritional interventions/restrictions**:

-1) *Dietary* restriction

- restricting some type of macromolecule
- Examples: restricting sugar, carbohydrates, restricting animal protein, fats, one type of fat like polyunsaturated fat

-2) *Time* restriction

- This is limiting the window during which you eat
- This gets lumped into the broader terminology of [intermittent fasting](https://peterattiamd.com/intermittent-fasting/) but Peter prefers “time-restricted feeding”
- Example: 16:8 protocol is 16 hours of fasting and 8 hour window in which you can eat

-3) *Caloric* restriction

- This is simply reducing the input but not restricting what or when you eat

⇒ **Note**: These three approaches can be done separately or can be combined

*Peter’s current approach*:

- Dietary restriction alone
- When not doing a multi-day, water-only fast, Peter is engaging only in dietary restriction
- He is pretty much eating however much he wants, whenever he wants, but he is being “manically strict” on what he’s eating
- He’s completely restricting carbohydrates outside of vegetables – no starch whatsoever
- This dietary approach has worked really well for Peter when he wants to lose a few pounds
- As Peter [wrote about previously](https://peterattiamd.com/a-new-year/), one of his goals this year is to lose about seven pounds

**How to approach your nutritional goals**:

- But that same approach that Peter uses for weight loss (dietary restriction) won’t result in weight loss for many of Peter’s patients
- Some people, for example, only lose weight when condensing the eating window (time restriction)
- One particular approach isn’t necessarily better than another, says Peter

—*Instead you should approach the problem in the following way*:

- A) Know what it is you’re trying to address
- B) Figuring out how to measure that when possible (in the case of something as trivial as weight, it’s very easy to measure, but for other things it’s potentially impossible to measure)
- C) Sticking with a plan long enough to assess it
- D) Being ready to abandon it if it doesn’t seem to work

**Why Peter pays attention to blood glucose**:

- The continuous glucose monitor (CGM) is the “single most important wearable that is at this moment in time”
- However… at the moment, you will likely need a doctor to prescribe one to you (at least the one that Peter favors the most ⇒ the [Dexcom G6](https://www.dexcom.com/g6-cgm-system))
- Another way to access blood glucose numbers includes the finger stick ⇒ not continuous and is quite inconvenient relative to the CGM
- Peter is hopeful that the CGM is soon to be available to the public and will be part of the solution for anyone who’s in the “do it yourself” category

-Peter’s current very strict modicum of dietary restriction in the form of carbohydrate restriction results in the following blood glucose characteristics:

- Blood glucose levels very flat
- Levels very low, and
- Very low variability

> “*Those things speak to a metabolically healthy phenotype, which frankly is more important than the amount of weight that I may or may not lose in the process*.”

**Subcutaneous fat vs. visceral fat (**[**see this figure**](https://www.google.com/search?q=Subcutaneous+fat+vs.+visceral+fat&sxsrf=ACYBGNRwQ_PCBtdpEnp61pT3wryLJVPcTw:1580750102998&source=lnms&tbm=isch&sa=X&ved=2ahUKEwj0o_iC8bXnAhVCU98KHSw5BhIQ_AUoAXoECA8QAw&biw=886&bih=695&dpr=2#imgrc=-B5q3GintNBPtM:)**)**

- Much of the weight Peter may lose will come from subcutaneous fat, which actually doesn’t play an enormous role in our health
- It’s the [visceral fat](https://en.wikipedia.org/wiki/Adipose_tissue#Visceral_fat) that is by far the bigger predator
- Unfortunately, it’s very difficult to ascertain visceral fat loss

*Does Peter think there is a role for patients to be able to order their own* ***blood tests*** *without a physician?*

- I think the answer should be yes.
- At the same time, I think it opens up a can of worms and I think there is a benefit to having a physician being a person who can not only order it, but more importantly help you understand and interpret it, especially in the event that something is not optimal.
- Many blood test results come fully editorialized from the lab as “good, bad, or intermediate.”
- Peter has to tell patient that it is many times the “good” or “bad” results are out of context and to ignore it
  - E.g., Uric acid is 6.6 and the test says that is in the “normal” range…and Peter might say that’s not good enough

**Pay attention to how you FEEL**

- How you feel can’t be overstated, says Peter
- Although it’s complicated because it includes the [placebo effect](https://peterattiamd.com/the-placebo-effect/)

–*All things considered, if a nutritional intervention results in things like*:

- More and stable energy
- Less GI distress
- Better sleep
- Less cravings
- More satiation with meals

–These would be signs that the changes you’ve made have been in the right direction even if they aren’t accompanied by some of the more obvious things that we look at (such as a lower number on the scale)

**A lesson Peter learned when he transitioned to ketosis in 2011:**

- When Peter switched to a ketogenic diet in 2011…
- It meant that he would be going from a very glycolytic athlete to someone whose muscles are going to have to learn to burn fatty acids and ketones at a much broader range of ATP requirement up until about VO2 max
- Peter was advised to back off the intensity and the volume of his workouts
- Instead, Peter ignored the advice
- “*The summer of 2011 was hell.*”

–*Eventually, it sort of “clicked” in two phases:*

- First, In August of 2011 he had an aerobic click (i.e., mitochondrial efficiency)
  - All of a sudden everything started to feel really good up until about zone three
- Secondly, he has an anaerobic click in November of 2012 (almost 1.5 years after going keto)
  - So this was above FTP up until VO2 max
  - “All of a sudden I just had sort of this surge of efficiency that kicked in.”
- Peter has big regrets that he wasn’t taking periodic muscle biopsies during the 3+ years he was in ketosis to see how his muscles changed in terms of efficiency and fuel utilization

## Exercise for brain health, and the 4 components of exercise [20:45]

> “Exercise and nutrition are really potent physiologic tools. In fact, I don’t know how you’d quantify it, dose for dose, but certainly exercise [and sleep] might be the most important tool we have with respect to brain health.”

**Exercise and brain health**

- Exercise and sleep are the two most potent nootropics we have available, says Peter
- Everybody seems to be searching for the latest and best supplement like mushroom, or the right dose of Adderall or Modafinil, etc.

–*Here’s a tip from Peter*:

- Until you have your sleep fully optimized and you’re exercising every day and producing bucket loads of [BDNF](https://en.wikipedia.org/wiki/Brain-derived_neurotrophic_factor), lay off the nootropics and get those two things tuned up
- You’re going to do more for your cognitive performance and for your long-term brain health by having these two pillars optimized than any stack of nootropics that has ever been concocted.

**The 4 components of exercise**:

  1 **| Stability** (the foundation)

  2 | **Strength**

  3 | **Zone 2** aerobic training

  4 | **Zone 5** (high intensity, e.g., HIIT)

##

## Exercise component—Stability [24:30]

> “[Stability] is the cornerstone upon which your strength is delivered, your aerobic performance is delivered and your anaerobic performance is delivered. And it’s the way that you do so safely.”

Stability is…

- a way that we **transmit force from the body** to the outside world…
- in the safest manner possible…
- across the muscles which are designed to carry that load…
- as opposed to seeing the dissipation of force across joints that are not fit to do so.

–*For example*, when you pick up 60 pounds off the ground

- [Newton’s Law](https://en.wikipedia.org/wiki/Newton%27s_laws_of_motion) says you have to exert 60 pounds of force on the world around you to move that thing
- The idea is you want all of that 60 pounds to be transmitted from your **muscles to the ground**
- And you DON’T want anything dissipating out your back, knees, or hips

-Humans are born with this ability

- But we lose it over time because of our lack of activity and our abundance of sitting
- But it’s possible to reacquire this ability through deliberate practice of these movements

![](https://peterattiamd.com/wp-content/uploads/2020/02/squatting-clinic-ama12-1024x981.png)

**Figure 1. Ayrton Attia demonstrating a proper squat.** Image credit: [Peter Attia (Instagram)](https://www.instagram.com/p/Bp7Je3YgKYz/)

**Dynamic neuromuscular stabilization (DNS)**

- Peter is a big fan of DNS to train proper stabilization and movements
- Peter has a lot of inefficient movement patterns that results in force leakage around his scapula, elbow, knee, back, hips, etc.
- This “force leakage” is the root cause of a lot of the chronic injuries that people have
- “*Stability is probably what I think of as the foundation upon which everything should be done vis-a-vis exercise.*”

*Other ways to train stabilization*:

- [Postural Restoration Institute](https://www.posturalrestoration.com/) (PRI)
- Pilates – while the vocabulary might be different than DNS or PRI, many of the principles are similar
- The particular teacher matters a lot
- “I think this is somewhat discipline agnostic, but it’s heavily dependent on the practitioner and the student.”
- “Of the four pieces of exercise we’re going to talk about, this is the one that probably will take the most tinkering for people to find the right type of practitioners.”

## Exercise component—Strength [29:00]

- Strength means basically utilizing the muscle to generate force
- So strength training with weights (or body weight) is a very important part of strength
- This is I think the most intimidating of the four types of exercise especially for people who have not done it before

-Peter’s counter to that would be: “*If you are interested in longevity, if you are interested in playing with your great grandkids, you want to prioritize muscle mass. Never in the history of civilization has a 90 year old said, ‘I wish I had less muscle.’*”

- The same is true for bone density (which can be improved with lifting weights)

-\*To reiterate the importance of stability\*: “*To train in the discipline of strength, absent a foundation of stability, can be a recipe for disaster. And so therefore I believe that those two have to go hand in hand.*”

## What is Peter optimizing for with his exercise? [30:30]

- Everything Peter is talking about in terms of exercise is about optimizing for **longevity**
- That is much different that optimizing for **performance**
- For instance, if someone were to want to run the fastest 10k possible…
  - That means training at an energy system that is very demanding of the cardiovascular system.
  - It is pretty much maximum cardiac output just beneath VO2 max above functional threshold which is past the point of optimizing longevity returns and it actually comes at some cost to longevity relative to something more at a slightly lower energy system
- Instead, Peter thinks about training for the [Centenarian Decathlon](https://peterattiamd.com/ama05/)⇒ i.e., being a kickass 90 year old

The main energy systems of life:

- Zone 1
- Zone 2
- Zone 5

> “By training zone 2 and zone 5 . . . we’re really teeing ourselves up metabolically and also structurally to do these things.”

## Exercise components—Zone 2 and zone 5 training [33:15]

**Zone 2 training**

Make sure to check out the [podcast with Iñigo San Millán](https://peterattiamd.com/inigosanmillan/)

- Iñigo explains that zone 2 is basically the highest level of exertion that is effectively pure mitochondrial oxidative phosphorylation before you start to net accumulate lactate

*-How Peter does zone 2 training:*

- Peter does zone 2 about four times per week
- He uses a lactate meter to make sure he is right on that limit of not going too far, not pushing too hard, but pushing hard enough
- Usually he does it on a stationary bike that’s hooked up to a power meter where he’s titrating watts and heart rate to get to a point where his finger stick **lactate level is 1.8 or 1.9 milliMole**
- If done on a treadmill, he’s doing 15% incline at about 3.0 to 3.4 miles per hour to produce the same effect as the bike
- Can also be done on an elliptical

*-What is the right dose of zone 2?*

- For a beginner: ~2 hours a week is a good place to start
- Ideally: 3-4 hours per week
- But you probably can’t do too much zone 2, says Peter, you’re mostly just limited by time and the ability to allocate it towards other forms of exercise

**Zone 5 training**

- Zone 5 is high intensity zone (i.e., [HIIT](https://en.wikipedia.org/wiki/High-intensity_interval_training)) and the fourth and final piece of exercise
- You don’t need to be spending much time in zone 5, but to neglect it completely, you’ll probably pay a bit of a price, says Peter
- Peter describes this zone as a small part of life using the example of an escalator being broken and you have two pieces of luggage and your kid and you’re late for your flight

*-HIIT vs aerobic exercise*:

- Many of the studies on this focus on its comparability to aerobics exercise on a *minute per minute* or unit time basis.
- HIIT is more efficient when looking at it that way
- But Peter does not view it as an *either/or* situation
- Using both of these tools is optimal and especially when zone 5 training doesn’t require that much more time

**Peter summarizes his typical week of exercise**:

- 3-5 bouts of strength training
- 4 bouts of zone 2
- 2 bouts of zone 5
- Stability is sprinkled into pretty much every day with maybe one day of a longer, more dedicated 60-minute session around stability

Book rec: [The Secret Race](https://www.amazon.com/Secret-Race-Inside-Hidden-France/dp/034553042X) by Tyler Hamilton – “*What an unbelievably good book that was. That’s one of about three or four books in my life that I read in one sitting.”*

**How to know if you are actually in zone 2?**

  1 | Gold standard way = **Blood lactate**

- The “gold standard” is measuring blood lactate concentrations
- Being at ~2.0 mM (or probably just below it at 1.8, 1.9) is the gold standard because that is the definition.
- That definition is the **highest generation of ATP that is coming through the mitochondria such that you are not net accumulating lactate**
  - (which is well below lactate threshold)

⇒ Lactate meter that Peter recommends: [Lactate Plus Meter by Nova](https://www.novabio.us/lactate-plus/)

- Heads up, it’s not cheap for the device or the strips
- TIP: You need to use very clean soapy water to wash your hands before doing a blood test. Alcohol is not sufficient because it does not remove lactate.

  2 | Simplest way = **rate of perceived exertion**

- RPE of 3 to 4 on a scale of 1-10 is generally where you should be
- However, Peter finds the idea of rating your exertion on a scale of 1-10 rather difficult
- Instead, Peter prefers to gauge it by your ability to hold a conversation: Once you’re at the point when it becomes **annoying to talk** during that form of exercise, you’ve hit that threshold.
  - (i.e., you can talk, but you don’t want to)

  3 | Maximum heart rate

- 69% to 83% of your heart rate max should be zone 2
- Peter points out however that it varies quite widely from person to person
- You really need to know your [true max HR](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3935487/) (you can’t just use the 220-age formula)
- Once you know your true max HR, Peter suggests starting out at **75% of max HR**

\*Peter recommends that most people use one of the 3 options above for assessing their zone 2, however, there are a couple more ways to do it. Such as…

  4 | Lactate threshold heart rate

- 85% to 89% on a run ([per Joe Friel](https://www.trainingpeaks.com/blog/joe-friel-s-quick-guide-to-setting-zones/))
- 81% to 89% on a bike
- Oftentimes, onset of blood lactate accumulation (OBLA) is confused with the lactate threshold (read the difference [here](https://www.ncbi.nlm.nih.gov/pubmed/19453206))

  5 | [Functional threshold power](https://www.cyclingweekly.com/fitness/ftp-cycling-363865) (FTP)

- FTP is the highest level of power you can hold for an hour
- 56% to 75% of your FTP is zone 2
- *Note about determining your FTP*: Rather than testing for a full 60 minutes, you can determine your FTP by doing 20 minutes of max effort and then take 90% of that max output as your FTP

## More about DNS, and why we need to be careful with rushing kids through neuromuscular development stages [45:00]

- Bob makes the analogy that zone two training is like you’re improving the **stability** of your mitochondria
- You might even be thinking of free radical production from “leakage” as your mitochondria become more efficient organelles in the context of training.
- And with Olympic lifting, which may seem like all about performance, a good coach should watching closely and correcting any efficient movement or “leakage”
- So in a way like that speaks to DNS being the foundation for all forms of exercise

The origins of DNS

- It originated from at Prague school as a tool upon which one could study the developmental delay in children with cerebral palsy
- And it was through that that they realized that kids with CP had missed certain developmental milestones.
- And it was because they missed those developmental milestones very early in life that translated to difficulty with movement later on.
- The initial thrust of DNS was how can we go back and teach these kids early enough in life once they’re diagnosed to learn these movement patterns that they would otherwise miss and to save them some of the challenges later on.

Be care about rushing kids through natural stages of neuromuscular development:

- It’s common for kids to have hip dysplasia being born breached and to then be put in a hip harness for 6+ months
  - This is a really a horrible thing for a kid to be in because it really limits movement during a very critical period of development
- Be careful with [bumbo seats](https://www.google.com/search?q=bumbo+seats&sxsrf=ACYBGNQFoHwLumu_P62giRtzzCJOG7H8yw:1580828121260&source=lnms&tbm=isch&sa=X&ved=2ahUKEwjKk_nUk7jnAhVshq0KHX3ECOkQ_AUoAnoECA8QBA&biw=776&bih=695&dpr=2) that put them up in a seated position prematurely before they have developed the truncal strength to support themselves or the stability
  - You’re rushing through a stage and they tend to then not develop the right connections across their torso.
  - Same goes with those bouncer walker things
  - Or even putting shoes on kids too early

> “There’s a whole bunch of things that we do as parents obviously with the best of intentions that actually kind of work against a child’s correct neuromuscular development.”

## Sleep: How to improve quantity and quality [48:15]

==> Here’s the [blog post](https://peterattiamd.com/irisin-the-magic-exercise-hormone/comment-page-1/) by Peter defining “first-order terms” that resonated with Bob

**Improving your sleep**

*The #1 tip from Peter*: **Consistently getting enough time in bed**

- The goal should be to spend enough time in bed to give yourself an opportunity to sleep ~8 hours
- Given a reasonable sleep efficiency, if you got into bed and then got out of bed 8.5 hours later, for many people that’s going to produce a great sleep cycle.

*Secondly*, it’s ideal to get in bed and get out of bed at the same time every day

- The more consistent your wake up time can be, the better you are because circadian rhythm is not exactly 24 hours and so you like having that morning reset every day
- Keep that wake up time as consistent as possible even on the weekends
- For Peter, there’s probably less than a 60 minute variation from wake up time on any given day ⇒ “*If I could narrow that gap, I would do it even more.*”

**Peter’s routine**:

- He gets in bed before 9pm because his son wakes up at 5am
- In an ideal world, his nighttime routine begins at least an hour before bed
- Preferably, he doesn’t use electronics at night at all, but if he needs to he makes sure to wear blue light blockers (he uses [Felix Gray](https://shopfelixgray.com/))
- NOTE: Not all electronics seemed to be created equal, computer is more stimulating and destructive to sleep than TV or a Kindle

**Sleep trackers**

- Peter uses the [Oura ring](https://ouraring.com/) (full disclosure he’s an investor and advisor to Oura)
- Other trackers include Fitbit and Apple Watch

*What’s most important to track?*

- First and foremost, just pay attention to your time in bed
- Don’t get too worked up about stages like how much deep sleep and REM sleep that your tracker says you are getting
- It still remains to be seen how accurate the staging data are on any of these devices.
- If you’re in bed for 8.5 hours, give or take, and you’re presumably getting 7.5-8 hours of sleep and you **feel and function great**, then there’s no need to stress out about the different stages

**Ways to improve your deep sleep**:

  1 | **Blue light blocking glasses** if you are going to look at electronics at night

- Peter’s first choice is [Felix Gray glasses](https://shopfelixgray.com/)

  2 | A supplement called a **magnesium L-threonate**

- L-threonate is a magnesium transporter
- It is sold under many different brand names, but it has to have something called [Magtein](https://magtein.com/), in the actual ingredients
  - Many companies will license Magtein to be able to put it in their product
- Peter takes the L-threonate (Magtein) with additional slow absorbing form of magnesium

  3 | Keeping the **bed cool**

- Peter uses the [Ooler](https://www.chilitechnology.com/products/ooler-sleep-system?gclid=CjwKCAiAyeTxBRBvEiwAuM8dnT3gl5GO51yBHkd5arWEfLNqd1D05CA3FAn4zDHTON7yDziXuiucshoCW90QAvD_BwE)

**Other measure you can take to improve sleep**:

- Don’t drink alcohol too close to bed (it’s harmful to sleep quality)
- Food intake too close to bed also has a negative impact (try to cut off food 3-4 hours before bed)
- Keep the room as dark as possible
- Keep the room temperature cold
- Going to bed earlier (try setting a “get in bed” alarm on your phone)

**3 sleep surveys you can take to assess your sleep proficiency**:

1. The [Pittsburgh Sleep Quality Index (PSQI)](https://www.opapc.com/uploads/documents/PSQI.pdf)
2. [Epworth Sleepiness Scale](https://epworthsleepinessscale.com/)
3. [Stop-Bang Questionnaire](https://stopbang.ca/osa/screening.php) for assessing risk of sleep apnea

- Peter has his patients take all three of these surveys
- Based on the results of those, he may recommend they go to a sleep lab

> “For many people just getting this sleep hygiene dialed in with respect to electronics, blue light, temperature, a couple of supplements, timing of food, limiting alcohol, the discipline around the time in bed, darkness in the room, et cetera. I’m constantly amazed, Bob, at how many people want a single pill to solve this problem when in reality you have to take a broader approach to this and you’ll get much better results.”

⇒ For more on sleep, check out any of these podcast episodes with sleep expert, Matthew Walker:

1. [Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, memory consolidation, and more](https://peterattiamd.com/matthewwalker1/)
2. [Matthew Walker, Ph.D., on sleep – Part II of III: Heart disease, cancer, sexual function, and the causes of sleep disruption (and tips to correct it)](https://peterattiamd.com/matthewwalker2/)
3. [Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep](https://peterattiamd.com/matthewwalker3/)
4. [AMA with sleep expert, Matthew Walker, Ph.D.: Strategies for sleeping more, sleeping better, and avoiding things that are disrupting sleep](https://peterattiamd.com/matthewwalkerama/)
5. [AMA #2 with sleep expert, Matthew Walker, Ph.D.: short sleep mutants, optimal sleep environment, sleep apnea, & rapid fire questions](https://peterattiamd.com/matthewwalkerama2/)

§

## Selected Links / Related Material

**Peter’s email newsletter about his nutritional framework**: [My nutritional framework](https://peterattiamd.com/my-nutritional-framework/) | Peter Attia (peterattiamd.com) [6:00]

**Peter’s article about intermittent fasting and how it is a confusing term**: [Intermittent fasting](https://peterattiamd.com/intermittent-fasting/) | Peter Attia (peterattiamd.com) [6:45]

**Peter has previously written about how his goal is to lose about 7 pounds**: [A new year](https://peterattiamd.com/a-new-year/) | Peter Attia (peterattiamd.com) [9:00]

**The continuous glucose monitor Peter wears**: [Dexcom G6](https://www.dexcom.com/g6-cgm-system) | (dexcom.com) [11:45]

**The importance of BDNF for brain health**: [Brain-derived neurotrophic factor and its clinical implications](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4697050/) (Bathina and Das, 2015) [24:00]

**The stability program Peter currently follows**: [Dynamic Neuromuscular Stabilization](https://www.rehabps.com/REHABILITATION/Home.html) | (rehabps.com) [26:00]

**Podcast where Peter discusses his idea of the Centenarian Decathlon**: [#50 – AMA #5: calcium scores, Centenarian Decathlon, exercise, muscle glycogen, keto, and more](https://peterattiamd.com/ama05/) | Peter Attia (peterattiamd.com) [32:30]

**Podcast discussing zone 2 training with Iñigo San Millán**: [#85 – Iñigo San Millán, Ph.D.: Mitochondria, exercise, and metabolic health](https://peterattiamd.com/inigosanmillan/) | Peter Attia (peterattiamd.com)  [33:30, 37:45]

**Book rec – “*****What an unbelievably good book that was.”***: [The Secret Race: Inside the Hidden World of the Tour de France](https://www.amazon.com/Secret-Race-Inside-Hidden-France/dp/034553042X) by Tyler Hamilton | (amazon.com) [37:00]

**Article by Joe Friel (Bob accidentally said San Millan) about finding zones**: [Joe Friel’s Quick Guide to Setting Zones](https://www.trainingpeaks.com/blog/joe-friel-s-quick-guide-to-setting-zones/) | Joe Friel ( [39:00]

**Onset of blood lactate accumulation (OBLA) is confused with the lactate threshold—read the difference here**: [Lactate threshold concepts: how valid are they?](https://www.ncbi.nlm.nih.gov/pubmed/19453206) (Faude et al., 2009) [39:00]

**The lactate meter Peter recommends to patients**: [Lactate Plus Meter by Nova](https://www.novabio.us/lactate-plus/) | (novabio.us) [40:30]

**Cycling app that uses a 20 minutes FTP test**: [TrainerRoad](https://www.trainerroad.com/) | (trainerroad.com) [44:30]

**Where Dynamic Neuromuscular Stabilization (DNS) originated**: [The Prague School and Dynamic Neuromuscular Stabilization](https://www.rehabps.com/REHABILITATION/Home.html) | (rehabps.com) [45:50]

**DNS started as a tool upon which one could study the developmental delay in children with cerebral palsy**: [Effects of dynamic neuromuscular stabilization on diaphragm movement, postural control, balance and gait performance in cerebral palsy.](https://www.ncbi.nlm.nih.gov/pubmed/29254112) (Son et al., 2017) [46:00]

**Peter’s blog posts that really resonated with Bob defining “first-order terms”**: [Irisin: The magic exercise hormone?](https://peterattiamd.com/irisin-the-magic-exercise-hormone/comment-page-1/) | Peter Attia (peterattiamd.com) [48:30]

**The Drive episodes with sleep expert Matthew Walker**: [49:45]

1. [Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, memory consolidation, and more](https://peterattiamd.com/matthewwalker1/)
2. [Matthew Walker, Ph.D., on sleep – Part II of III: Heart disease, cancer, sexual function, and the causes of sleep disruption (and tips to correct it)](https://peterattiamd.com/matthewwalker2/)
3. [Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep](https://peterattiamd.com/matthewwalker3/)
4. [AMA with sleep expert, Matthew Walker, Ph.D.: Strategies for sleeping more, sleeping better, and avoiding things that are disrupting sleep](https://peterattiamd.com/matthewwalkerama/)
5. [AMA #2 with sleep expert, Matthew Walker, Ph.D.: short sleep mutants, optimal sleep environment, sleep apnea, & rapid fire questions](https://peterattiamd.com/matthewwalkerama2/)

**Sleep tracker Peter uses (full disclosure: he is an investor and advisor)**: [Oura Ring](https://ouraring.com/) | (ouraring.com) [51:30]

**Blue light blocking glasses Peter prefers when using electronics at night**: [Felix Gray](https://shopfelixgray.com/) | (shopfelixgray.com) [53:30]

**Magnesium L-threonate product Peter prefers**: [Magtein](https://magtein.com/) | (magtein.com) [53:50]

**Bed cooling product Peter uses**: [Ooler Sleep System](https://www.chilitechnology.com/products/ooler-sleep-system?gclid=CjwKCAiAyeTxBRBvEiwAuM8dnT3gl5GO51yBHkd5arWEfLNqd1D05CA3FAn4zDHTON7yDziXuiucshoCW90QAvD_BwE) | (chilitechnology.com) [54:15]

**3 sleep surveys you can take to assess your sleep proficiency**: [55:45]

1. [Pittsburgh Sleep Quality Index (PSQI)](https://www.opapc.com/uploads/documents/PSQI.pdf) | (opapc.com)
2. [Epworth Sleepiness Scale](https://epworthsleepinessscale.com/) | (epworthsleepinessscale.com)
3. *Questionnaire to assess the likelihood that you have sleep apnea*: [Stop-Bang Questionnaire](https://stopbang.ca/osa/screening.php) | (stopbang.ca)

§

## People Mentioned

- [Stephen Phinney](https://www.virtahealth.com/people/stephen-phinney) [17:15]
- [Jeff Volek](https://ehe.osu.edu/directory/?id=volek.1) [17:15]
- [Iñigo San Millán](https://www.ucdenver.edu/academics/colleges/medicine/sportsmed/cusm_physicians/Pages/sanmillan.aspx) [33:30]
- [Tyler Hamilton](https://en.wikipedia.org/wiki/Tyler_Hamilton) [37:00]
- [Jonathan Vaughters](https://en.wikipedia.org/wiki/Jonathan_Vaughters) [37:30]
- [Matthew Walker](https://psychology.berkeley.edu/people/matthew-p-walker) [49:45]
- [Jocko Willink](https://en.wikipedia.org/wiki/Jocko_Willink) [57:15]

§