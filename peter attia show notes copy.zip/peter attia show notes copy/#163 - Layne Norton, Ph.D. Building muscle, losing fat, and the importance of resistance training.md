# #163 – Layne Norton, Ph.D.: Building muscle, losing fat, and the importance of resistance training

**Source:** [https://peterattiamd.com/laynenorton/](https://peterattiamd.com/laynenorton/)

---

##### Check out more content from Layne Norton, Ph.D.:

- - *(May 24, 2021)* [#163 – Building muscle, losing fat, and the importance of resistance training](/laynenorton/)
  - *(May 2, 2022)* [#205 – Energy balance, nutrition, & building muscle](/laynenorton2/)

Layne Norton is a physique coach, a natural professional bodybuilder and powerlifter, and holds a Ph.D. in nutritional sciences. In this episode, Layne explains how he became interested in weightlifting and fitness both professional and academically. He provides insights into preventing and managing injuries while using consistency and determination to boost his professional success in bodybuilding and powerlifting. Peter and Layne also review the science of body composition and what’s really driving muscle growth, including the role of nutrition, supplements, and a number of important and misunderstood hormones important to muscle protein synthesis. Furthermore, Layne stresses the importance of maintaining muscle mass even while losing fat for improving metabolic health and longevity and provides the keys to developing healthy habits.

\*[WATCH PODCAST ON YOUTUBE](https://youtu.be/aRdEZIyyhJA)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/laynenorton/the_Drive_public.png)

Play

#163 - Layne Norton, Ph.D.: Building muscle, losing fat, and the importance of resistance training

#163 - Layne Norton, Ph.D.: Building muscle, losing fat, and the importance of resistance training

1x15s30s

0:002:41:10

## We discuss:

- Layne’s childhood and why he gravitated towards weightlifting and bodybuilding [2:45];
- Layne’s academic path, overcoming ADHD, and kicking Adderall [11:45];
- Paradoxical observations about expertise, and Layne’s career transition to health and fitness [22:00];
- The power of persistence and resilience in the face of setbacks [32:15];
- Battling injuries, managing back pain, and setting lifting records [43:00];
- Bodybuilding vs. powerlifting: comparing and contrasting the training approaches [57:15];
- Cutting weight without losing muscle mass: exercise and dietary protocols, fasting, and a look at the literature [1:06:00];
- Muscle protein synthesis and the importance of leucine [1:25:30];
- Nitrogen balance and muscle protein synthesis, and the regulatory role of hormones for fat flux and muscle growth [1:37:00];
- What’s really driving muscle growth: intrinsic vs. systemic factors, IGF, and hormone signaling [1:46:30];
- The role of protein, carbohydrates and insulin on muscle growth and preservation, and the importance of context when interpreting study results [1:55:30];
- Clarifying the role of cortisol—a misunderstood hormone [2:07:45];
- The problem with studies trying to isolate one nutrient [2:15:00];
- The important role of inflammation from exercise [2:19:25];
- Keys to preserving muscle, and the value of habits, consistency, and resilience [2:23:30]; and
- More.

§

## Show Notes

## Layne’s childhood and why he gravitated towards weight lifting and bodybuilding [2:45]

- [Dom D’Agostino](https://www.ihmc.us/groups/ddagostino/#:~:text=Dominic%20D'Agostino%20is%20a,Florida%20Morsani%20College%20of%20Medicine.) introduced Peter and Layne and Peter has wanted to interview Layne for 2.5 years
- Despite what people might assume, they have similar viewpoints on most things
- Layne grew up in Evansville, IN
  - Played baseball since age 5 and lettered in high school
  - Sports did not come naturally to him and he had to work at it: “That may be apparent for my baseball aficionados out there. I was a five foot 10, right-handed first baseman. So, that’s not your prototypical first baseman”
  - Also ran cross country in high school, “definitely not the sport that you would pick as the precursor to strength sports and bodybuilding”
- Layne was picked on and “borderline emotionally abused” by other kids when he was growing up
  - He was nerdy, talkative, and goofy and had [ADHD](https://en.wikipedia.org/wiki/Attention_deficit_hyperactivity_disorder)
  - “*I started lifting weights just to hopefully have people stop picking on me and get some dates. And lifting weights didn’t do either of those things, but I developed a passion for weight training*.”
- He loved weight training, but it didn’t come naturally to him
- Neither did academics, but “I did find at a young age that through sheer volume of work I could overcome a lot of that stuff”

> “I really appreciated lifting weights … from the perspective of the work investment to the payoff compared to how much talent was needed…For me, it felt more fair…in terms of level of work you get in versus what you see.” —Layne Norton

- It’s also very measurable in a black and white way: can see that you’re lifting 10% more
- Boxing drew Peter into strength and endurance training, and older men who trained in his gym served as mentors to keep him safe, explain the sport, and give him common sense around training
- Layne went to the library for weightlifting books and magazines when started in the late 90s
  - “We have really advanced our understanding of weight training. But the basics, progressive overload, that sort of stuff is still relatively similar. And I remember the book did talk about periodization, which at that time was not a new concept in athletics, but for weightlifting was a new concept”
- If you’re consistent, you will get stronger regardless of what you’re doing
- He entered his first bodybuilding competition at 19

> “I’ve always been drug-free in terms of anabolic steroids, growth hormones, all that kind of stuff. No performance enhancing drugs. I don’t have any problem with anybody who does it as long as they compete in untested organizations.” —Layne Norton

- The only evidence-based natural bodybuilding coach, [Joe Klemczewski](https://www.bodybuilding.com/author/joe-klemczewski), lived in his hometown and helped him prepare
- Layne won the teenage and novice divisions
- “Dr. Joe wasn’t right about everything, obviously. But the crux of his information and being so focused on being evidence-based and not necessarily buying into dogma, that sort of thing, that definitely did help me”

## Layne’s academic path, overcoming ADHD, and kicking adderall [11:45]

- Listening to Joe talk about physiology made Layne want learn more about the human body and do more academically
- Layne was the first person in his extended family to go to college

- ADHD made it hard for him to focus in school, and he found he had to study more than his classmates
  - In an advanced chem course in high school, he studied for 15 hours for a test but a friend who got the same grade only studied a bit the night before
  - Layne’s college roommate could sit and study for 8 hours straight, while he would get in about 30 hours of productive studying if he tried that, so he learned to work in 30-45 minute blocks with breaks in between
- At [Eckerd College](https://www.eckerd.edu/) in St. Petersburg, Florida, he was worried whether he would be able to compete with the other students, so he studied hard and got all As
  - He took [Ritalin](https://en.wikipedia.org/wiki/Methylphenidate) and [Adderall](https://en.wikipedia.org/wiki/Adderall) growing up but weaned off of it in grad school because he had developed the right study habits and hasn’t taken meds in 15 years
  - “I always joke, the only problem with Adderall is whatever I was doing when it kicked in was what I was going to be doing for the next eight hours”
- He thinks struggling when he was young helped because he learned to deal with adversity
- Layne had planned to study marine science – he was and is passionate about sharks and still has a goal of diving with a great white shark
  - Peter mentions a [*National Geographic* special](https://www.natgeotv.com/za/shows/nationalgeographicwild/worlds-biggest-great-white-expedition-hawaii#episodes-t0) that mesmerized him where researchers towed a dead whale out to sea to study tiger sharks they thought would feed on it but ended up getting footage a giant great white shark
  - Layne’s plan was changed by a professor at Florida Institute of Technology who studied great white sharks
    - He said such jobs were very rare, very hard to get, and didn’t pay well
    - Told him to get an undergrad degree in a more general science and then specialize in grad school
- Layne started in biology instead of marine science, but ultimately switched to biochemistry
  - His first year chem professor, [Chris Schnabel](https://www.eckerd.edu/chemistry/faculty/schnabel/), told him to do biochemistry instead because it would lead to more options and better opportunities
  - His second year organic chem professor (“He was firm but fair. If I look back, best mentors were always firm but fair”) asked him to be a summer research assistant even though he got a B in the class because he was passionate and worked hard
- By his junior year he had started writing articles for [bodybuilding.com](https://www.bodybuilding.com/author/joe-klemczewski)

## Paradoxical observations about expertise, and Layne’s career transition to health and fitness [22:00]

**The Dunning-Kruger curve and the limits of knowledge**

- In graduate school, Layne “had crested the [Dunning-Kruger](https://en.wikipedia.org/wiki/Dunning%E2%80%93Kruger_effect) curve and was down in the valley”
- The Dunning-Kruger curve is perceived versus actual knowledge
  - When we start learning about a subject, since we are aware that we know little, our perceived knowledge pretty much aligns with how much knowledge we have (both very low)
  - But our perceived knowledge skyrockets after about 6-12 months after starting to study a particular subject
  - Eventually if you keep learning you realize that you did not know as much as you thought and how much more there is to learn
  - “Even though … your actual knowledge is going up, your perception of your knowledge starts going down. And I would say my third year of graduate school was where it got to the very bottom”
- [Jeremy Loenneke](https://hesrm.olemiss.edu/people/jeremy-paul-loenneke/), a professor at U Mississippi, always says, “Once you drink from the fountain of knowledge, you will thirst for the ignorance you once had”
- Attia’s Head of Research, [Bob Kaplan](https://www.linkedin.com/in/bobckaplan/), often quotes the saying “the further you get from shore, the deeper the water gets”
- Peter says he knows much more about nutrition now that he did 10 years ago, “but in relative terms, … it’s basically to the point where I pretty much think I know nothing”
  - “I think unfortunately social media has created a lot of people who shout really loudly from the top of the … initial peak of the Dunning-Kruger curve”
  - It’s very difficult for people who want to learn because of the signal noise problem
- People gravitate towards a person who speaks like they know everything rather than an expert who recognizes the limits of their knowledge and adds caveats
- Layne’s podcast interviewed [Alan Levinovitz](https://www.jmu.edu/philrel/people/levinovitz-alan.shtml), a professor of religious studies
  - He discusses naturalism, the idea that we assume something natural (which we can’t even really define well) is better
  - Levinovitz said it’s a paradox, but if you want to find the people who know what they’re talking about, look for people who seem unsure
- Layne’s friend [Greg Nuckols](https://breakingmuscle.com/coaches/greg-nuckols) says that people can quickly determine whether someone else knows more about something than they do
  - but if two people have more knowledge on a subject than we do and they’re in disagreement, we have a lot of problem evaluating who has the better argument
  - Layne says that debates favor those who can speak well and are not useful for evaluating arguments

> “At the end of the day, [whether] you’re talking about religion, politics, [or] nutrition, 95% of the people are going to go with whatever their perception was before the debate. …If you don’t have a PhD in something or an advanced degree, if two people are citing studies, who do you go with? It’s very, very difficult.” —Layne Norton

**Layne’s transition to the fitness industry**

- 3 years into his biochem degree, Layne knew he wanted to work in the fitness industry but little else
  - Around then (2003), people who made money in the fitness industry owned a supplement company or a gym, were a personal trainer, or wrote for a publication
  - Went to grad school to learn more and delay his decision so he could figure out what he wanted to do
- Ended up focusing more on nutrition than exercise physiology
  - He hears people say it’s 80% nutrition and 20% training
  - He says, “I have a PhD in nutrition. I will tell you, training is the most powerful thing for your health and body composition that you can possibly do”
- If you don’t train, the changes to body composition from dietary changes will be minimal – you will lose and gain some lean body mass along with fat

> “Resistance training specifically is the most powerful tool you have to change your body composition, and I would actually argue your overall health as well.” —Layne Norton

- In the beginning Layne was focused on building up muscle
- Layne picked up bodybuilding at 15, stopped at 16 when he got his first girlfriend, and then started again when he was almost 18 and never stopped
  - He was just under 5’ 10” and 152 lbs (he remembers because he was weighed at the Bigger Faster Stronger seminar) in 1999
  - He competed at 5’ 10.5” and ~175 lbs
  - His upper body was more muscular than others’ when he graduated high school

## The power of persistence and resilience in the face of setbacks [32:15]

*Peter is curious about if or when Layne ever realized that he had a “gift of strength”*

- On Peter’s [podcast](https://peterattiamd.com/brothersbell/) with [Mark](https://www.markbell.com/who-is-mark-bell) and [Chris](https://en.wikipedia.org/wiki/Chris_Bell_(director)) Bell, he mentioned 4 brothers who trained in his gym
  - They were taking anabolic steroids, but they naturally had very high abilities and physical assets
  - One was an ER resident with limited time to train, but he would still come into the gym between shifts and perform impressively
- Layne’s best total is nearly 1800 pounds
- Layne never had a period of time where his gains were crazy, but he found that **when he was very consistent and steady, he had very steady increases**

**The importance of working through setbacks**:

- “I think if I’d had a lot of success right out of the gate, I might not have pushed as hard or been as consistent because it’s kind of this weird paradox with me.”
- “The harder something is, the more I want to do it.”
- Layne has seen plenty of instances where people have natural success right out of the gate and then when they start to meet resistance in their gains they give up
- Whereas the early resistance helped Layne in the long term as he was ready to overcome the harder obstacles down the road

*In college…*

- When Layne got to college he could start being more consistent with his lifting and eating
- He was wanting to just get bigger in general and didn’t mind a little more body fat

*Bodybuilders in person vs. on stage*:

- Layne says that competitive bodybuilders look much more impressive **in person** than in onstage photos in terms of definition, muscle size, muscularity, etc.
  - The only bodybuilders Peter has paid attention to are [Lee Haney](https://en.wikipedia.org/wiki/Lee_Haney) and [Dorian Yates](https://en.wikipedia.org/wiki/Dorian_Yates) and he has never seen someone of that stature in person

*Work ethic makes a huge difference in bodybuilding compared to other things*:

- Genes likely play as much of a role in [hypertrophy](https://en.wikipedia.org/wiki/Hypertrophy) as they do in hitting a baseball or shooting a basketball, but the idea of success being related to work ethic appealed to him
  - “I think a lot of the gift was I’m just really stubborn and I could tolerate a lot of **training volume**”
  - In 2015 he won a gold medal in the [squat](https://en.wikipedia.org/wiki/Squat_(exercise)) at the [International Powerlifting Federation](https://www.powerlifting.sport/) (IPF) world championships (“essentially the super bowl for power lifting”) and set a world squat record (668 lbs at the time) when he weighed only 201.5 lbs

![](https://peterattiamd.com/wp-content/uploads/2021/05/f1.-squat-laynenorton.png)

**Figure 1. The squat**. Image credit: [startingstrengh.com](https://startingstrength.com/articles/squat_rippetoe.pdf)

- Training volume: The preceding 2 weeks before he won gold, he did 34 sets with over 500 pounds between squat and [deadlift](https://en.wikipedia.org/wiki/Deadlift)

![](https://peterattiamd.com/wp-content/uploads/2021/05/f2.-deadlift-laynenorton-1024x612.png)

**Figure 2. The deadlift**. Image credit: [startingstrength.com](https://startingstrength.com/article/deadlift-mechanics-the-obvious-can-be-obscure)

- Layne says he was gifted with a resilient body & mind:
  - “*I just remember looking back at that thinking like how bad I wanted that and just how much volume of work I did. And I think again, I think I was just able to tolerate some really insane style training*”
  - “I think my body was a little bit more resilient and I think my mind was a little bit more resilient.”
  - His gains were never overnight, it was always just kind of a slow, steady progression
- His training did not come without setbacks:
  - He had multiple injuries: two herniated neck discs, multiple herniated lower back discs, hip injuries, etc., and it helped him to deal with those setbacks early in his career

**Persistence and resilience is key**:

- He doesn’t like people saying “have more confidence in yourself” – confidence has to be based on something
- He suggests starting small: e.g., “this week I’m going to show up every day” to “I’m going to squat 200 pounds”

> “Over time, every little thing that you go through might feel insignificant in terms of what it means to you at that time. But when you look back, you can draw on that. … I always tell people, I don’t think I would’ve had the success I did in business or social media or academia if I hadn’t done weightlifting because that taught me so much about other things in life.” —Layne Norton

- Peter wanted to become a professional boxer and didn’t plan to go to college
  - He was able to tolerate a lot of training and also had a lack of confidence: “it was sort of an insecurity that the other guy’s going to train three hours a day, I’ll train six hours a day”
  - But then college seemed easy “compared to getting up at 4:30 every morning and running 10 miles and going to the gym this many hours and sparring this many rounds every day and doing 400 pushups before bed every night and all of those things”
  - He already had the “habit and discipline infrastructure” he needed to succeed
  - He is encouraged when his own kids take an interest in something because of the discipline they’ll learn
- Most people who don’t lift won’t appreciate the magnitude of the numbers like doing a 700 pound squat when you are 200 lbs and drug-free
- Peter says the way Layne talks about the use of performance enhancing drugs has never come across as haughty or holier-than-thou; his only real pet peeve is people who cheat and basically enter drug-free bodybuilding competitions while using drugs

## Battling injuries, managing back pain, and setting lifting records [43:00]

Layne’s early performance

- Bench press
  - Layne peaked early in [bench pressing](https://en.wikipedia.org/wiki/Bench_press) – hit a 300 pound bench press in high school without a pause, with a pause maybe 280-85

- Squat
  - Layne has a very long femur-to-shin ratio as well as a shorter torso, which means he has to lean forward when he squats
  - In high school be could squat 315 folded over, which is pretty strong for a high schooler
  - but he did not know how to use hinge or his hips correctly, and it was barely to depth if that
  - He did not deadlift until college and hit 405 lbs before he graduated
- Peter notes that these numbers are “very mortal,” which shows there has been a very slow and steady trajectory to where Layne is now and likely reflects muscle and technique maturity

**Injuries & back pain**

- Layne had neck herniations from college rugby and had lost about 40% of strength on the left side
  - A doctor told him he wouldn’t fully recover his strength, but Joe said docs weren’t used to patients like Layne who would actually do the rehab
  - Six months later he did the rehab and was hitting personal records (PRs) again
- He had radiating pain from his lumbar herniations
  - when it flared up, it was 10/10 and he could not get off the floor
  - Saw [Stu McGill](https://www.backfitpro.com/about-us/), one of the more well-known experts on lower back pain, who pointed out that about 60% of all people over 30 have disc herniations
  - Has been on ongoing issue
  - First hit in 2015 a week out from the [Arnold Classic](https://www.arnoldsportsfestival.com/) pro
  - One day he felt tight and by the next he couldn’t move
  - Once the inflammation subsided he was able to compete and actually won
    - Ended up squatting 661 lbs and tying the world record
- But back pain was an issue from that meet in March and world championships were in June
  - Had to take 4 weeks off squatting and deadlifting and started only 4 weeks before world championships
  - He got the gold and set a world record in squat and a silver medal overall
- But issues continued during a stressful period a few years later (“they have shown that like stress, lack of sleep, all that plays into your level of pain sensitivity”)
  - Starting in December 2017, he took about 9 months off from any spine loading, which was probably overkill
  - But, he built back up and In 2019 he hit a 666 lb squat in the 727 lb deadlift at nationals

*Where Layne disagrees with some doctors:*

- Layne says he does not agree with docs who tell athletes they must give up their sport
  - it’s not “a death sentence” for most people, especially with back injuries
  - About half of people over 35 have herniated discs they are unaware of because they’re asymptomatic

**Peter wonders if Layne could pinpoint the cause of his pain (51:39)**

- Peter says some people don’t have segmental control within the spine:
  - can’t generate enough intraabdominal pressure
  - too much lordosis in the spine when they’re under an axial load
  - can’t generate enough articulation between T12 and L1
  - tend to generate disproportionate load at hinge points
- Layne suspects that his lumbar flexion was a trigger for his pain

![](https://peterattiamd.com/wp-content/uploads/2021/05/f3-laynenorton-912x1024.png)

**Figure 3. The end of the thoracic spine (T12) meets the beginning of the lumbar spine (L1)**. Image credit: [BraceAbility](https://www.braceability.com/blogs/articles/t12-l1-spinal-thoracic-burst-fracture)

**Approaches to managing pain**

> “If we look at the bio-psycho-social model of pain, it gets really murky because I mean, they’ve shown that you can have tissue damage and no pain and you can have pain with very little tissue damage. So, I think part of it was just I had that initial injury to the disc, but then I probably didn’t give myself enough time to desensitize myself to that pain and just kept hammering at it.” —Layne Norton

- Research shows that one of the best things you can do for low back pain is resistance training
  - But, if you were doing it with a load that increases that pain, then it’s going to make it worse
  - modify the load, tempo, and range of motion to reduce pain
  - if those don’t work, modify the exercise selection
  - Layne now knowns not to work through the pain, which made things worse, but to modify training to reduce the pain to a 2 or 3 out of 10
- When he had hip pain for 6-7 months, he stopped doing full range of motion squats and did above parallel pin squats instead (pause at the pins and then come up)
  - After about 6 weeks it did not hurt as much
  - Then gradually increased his efforts until he could do a full squat without pain

> “Based on what some of the pain specialists have said, you’re probably better off doing something than nothing if you can, because if you just take time away from training, you end up detraining. So when you come back, you’re not as practiced at the lifts and you might end up hurting yourself again.” —Layne Norton

- Layne modifies variables instead, sees it as a puzzle to work out
  - Peter agrees that the worst thing for an injury is completely stop the activity
  - He tends to move from two legs to one when he’s in pain: typically use not half, but a third, the weight at a single leg

## Bodybuilding vs. powerlifting: comparing and contrasting the training approaches [57:15]

Comparing powerlifting and bodybuilding

- Have a very clear overlap, but also have a pretty different point of optimization
  - bodybuilding is a very subjective sport where it’s about how you look and strength is less important
  - powerlifting requires a lot of strength but nobody really cares how you look
- Layne has excelled at both
  - Consensus seems to be that hypertrophy does matter for strength training, so the more muscle you have, the more weight you’re going to be able to lift
  - Bodybuilding is much more forgiving
    - have a lot of options because it’s simply about creating tension on the muscle to get the requisite volume and progressive overload
    - There are many forms of progressive overload, but volume load is a major one
    - Can be done in many different ways – can pick something you can do without pain or that you really enjoy
  - With power lifting, you can do some accessory movements, but you still have to do and be well-trained on the major lifts

> “I think that bodybuilding in a way is a little bit more demanding mentally, because …you cannot imagine the levels of hunger and low energy that these people go through. … I’m talking about so hungry that you literally think about it from the moment you wake up to the moment you go to sleep and then it wakes you up at night.” —Layne Norton

- Once after training Layne was so low energy that he watched a terrible show because he could not get up to get the TV remote
- Layne’s last show was in 2010
- the amount of calories you start on is not going to be what you end up finishing on
  - his lowest calorie level was ~1900
  - Doesn’t sound low, but he’s probably 185+ lbs of lean body mass
  - Trained at least 2 hours a day
  - His training was all he had energy for
  - once when he did a cardio session at night he couldn’t believe it had only been 3 minutes
  - he would get lightheaded standing up because his BP was so low
- power lifting is hard but you can leave it at the gym, but bodybuilding never leaves you
  - it’s more flexible, though
  - Dorian Yates never squatted but [Ronnie Coleman](https://en.wikipedia.org/wiki/Ronnie_Coleman) squatted tons of weight
- “I think that the appeal for me for bodybuilding was that mental challenge. Basically how much could you suffer?”
- Appeal of powerlifting is the relative lack of subjectivity: “either you pull it or you don’t, and that determines if you win or not” and, unlike bodybuilding, what you’re doing is exactly what you trained to do
- Peter wonders about the timing and order of doing both
  - Layne says it’s individually independent
  - For him he’d do a powerlifting meet and then a bodybuilding show after that
  - Layne would typically want about 6 months after a powerlifting meet to get ready for a bodybuilding competition to really maximize lean body mass

## Cutting weight without losing muscle mass: exercise and dietary protocols, fasting, and a look at the literature [1:06:00]

- How much lean body mass vs. fat gets lost depends on how much body fat you’re starting with
  - someone who is overweight or obese doesn’t need to worry about losing too much lean body mass
  - using estimated numbers:
    - can go from 15% to 7% body fat with very minimal lean body mass loss
    - From 7% to 5%, probably losing 20 to 30% of that weight as lean body mass
    - Below 5%, might be losing just as much lean body mass as fat mass
- Layne implements diet breaks, periods of eating at maintenance
  - Aim for a level of calories where you’re not going to add back fat tissue, but you can eat more than you did previously
  - Layne would aggressively diet for 2-3 weeks to try to lose 1.5-2 lbs a week
  - then 1-3 weeks of eating just a maintenance level of calories (3200-3400 calories for Layne)
  - worked well for him to maintain his strength
- wouldn’t use this strategy if he were getting ready for a bodybuilding show or coming down from a higher body fat
  - use it as approach lower levels of body fat
  - He’d only need to drop 10-15 lbs from where he is now, but he would probably spend more time at maintenance than he did in a deficit
  - Think of it as a wet towel
    - when you start squeezing water comes out very easily, which is like losing weight when you are obese
    - But when towel is almost dry and you’re trying to wring last bit of water out, you have to put in monumental levels of effort compared to what you did at the beginning to get the same amount of water out
  - That’s why he would want to allow so much time to get ready

**Body fat set point**

- Peter is impressed that Layne could go from 15% to 7% body fat without much loss of lean tissue without [exogenous](https://en.wikipedia.org/wiki/Exogeny) testosterone
- body fat set point theory: idea that you have a relatively tight range of homeostatic body fat that your body will try to maintain
  - when you drop below that range, you really start to feel the negative effects of caloric restriction: hunger goes up while BMR, non-exercise activity thermogenesis, and libido drop
- Based on caliper readings, Layne estimates his body fat setpoint range is 7-11%
  - On a dual-energy X-ray absorptiometry ([DEXA) scan](https://hudsonmedical.com/articles/dexa-scan-the-gold-standard/), his range would be 10 to 14%
  - The lowest he’s been by caliper is just over 2% (maybe 5-6% DEXA), but at the end of the day it’s the visual aspect that matters
- Peter says that as recently as 10 years ago he was 7.1 – 7.8% by DEXA and he looked nothing like a bodybuilder, so he guesses that a bodybuilder could be 4% by DEXA
  - A natural bodybuilder named [Alberto Nuñez](https://3dmusclejourney.com/about/alberto-nunez/) had such low body fat that the vascularity in his glutes was visible, and he was 6% by DEXA
  - Peter wonders how much was visceral versus subcutaneous, and Layne points out the margin of error
- It seems that if your body has a higher body fat set point, you may see some lean body mass loss at a similar body fat to what Layne is able to retain more at
- We don’t really have a lot of data on this issue – scientific studies are blunt instruments that cannot control for many factors
- But Layne thinks it’s likely that variation is due to different body fat set points
- Can use resistance training to overcome this

**The relationship among diet, fasting, and muscle mass and limitations of current studies (1:14:45)**

- Diet-induced lean body mass reduction may be because people are not doing resistance training
- Also, “when people are dieting and they’re starting to feel worse because they’re lower energy, their training volume drops, their training intensity drops, and that’s probably part of it”

> “People don’t realize lean body mass is not the same thing as muscle mass. Lean body mass is all non-fat tissues, that’s skin, bone, organ weight, all that stuff, and including your body water. And a lot of, I think, what we see with lean body mass loss is water, gut tissue, liver. Those tissues shrink in response to caloric restriction.” —Layne Norton

- Peter points out that you can lose glycogen, which tracks with water
  - For example, if you lose half your glycogen volume, the total mass lost is 3-4 times the mass of glycogen lost given water, plasma, etc.
  - Layne says the loss of a lot of water with glycogen is seen in ketogenic diet [studies](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin/publications) like [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin)’s
- Peter does periodic fasting for health benefits (increasing autophagy)
  - 5-7 day water-only fast each quarter
  - Rather than alternating between cardio and resistance training, he did only resistance training on fasting days
  - He would deadlift, focusing on the biggest muscles and going more slowly
  - needed much more rest between sets, but could still move the same amount of weight
  - did not appear to lose muscle mass
  - Peter thought that, although there was an [mTOR](https://en.wikipedia.org/wiki/MTOR) reduction via the nutrient pathway, he was at least counterbalancing it
- What it takes to maintain muscle tissue is very minimal compared to what it takes to actually build it
  - probably have not lost contractile tissue in the fasting period
  - maintenance is a reasonable goal in a situation where not trying to maximize hypertrophy or strength
- Layne does not claim you can’t get strong fasting, only that it’s unlikely you can get as big and strong as someone who is consuming nutrients regularly
- In January 2021, Peter weighed the same he did 10 years before but a DEXA showed he had lost muscle mass
  - His body fat increased from about 7% to 16% over a decade
  - Used to train 4.5-5 hours a day, now maybe 90 minutes
  - Different priorities and goals
  - His colleague [Beth Lewis](https://bodyevolvednyc.com/us/) suggested he stop fasting to build more muscle
  - It’s an optimization issue
- Randomized controlled trials don’t show much difference between plant and animal protein
  - But 8 weeks is a short time window to look at muscle mass
  - Layne knows he’s biased because he did work on leucine and has received funding from the egg and dairy councils
  - He fully acknowledges that you can build muscle with plant protein, as shown by plant-based bodybuilders with impressive physiques
  - But requires more detailed planning because of limited [amino acids](https://en.wikipedia.org/wiki/Amino_acid), low [leucine](https://en.wikipedia.org/wiki/Leucine) content, etc.
  - But he thinks animal protein is going to end up being superior for muscle building
- consistent resistance training and progressive overload is by far the most dominant factor in muscle hypertrophy
  - but we can barely pick out differences
  - volume and weekly set number are important, but sometimes we can’t distinguish differences in hypertrophy with different volume protocols
  - Given that, we’re not going to be able to tell the difference in the actual hypertrophy in eight weeks from protein sources where calories and total protein are acquainted
  - Studies are underpowered and not long enough to show any difference between plant and animal protein

**Limitations of current studies**

- Peter points out that studies are limited because it’s difficult to control the variables, and the tighter they are the shorter the study must be
  - Kevin Hall’s [studies](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin/publications) are at the highest level that can be done (use inpatient setting)
  - Peter is friends with Kevin, has seen his lab at the NIH and others
  - has even  personally spent time inside the metabolic chambers, which have the highest level of precision inside a chamber that does indirect calorimetry
  - but you can’t put somebody in this situation for a year
  - “If we think that the difference in a person over six months might be two to three pounds of muscle mass under perfect conditions, it’s going to be very difficult to tease that out in eight weeks” or in real-world conditions

## Muscle protein synthesis and the importance of leucine [1:25:30]

- Leucine
  - Leucine is one of the 3 branched chain amino acids which are good for muscle
  - timing of things like training and meals must matter with respect to leucine
- Body makes muscle proteins from amino acid substrates
- In his studies, Layne looks at mixed muscle protein synthesis
  - He [presented data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3500748/) on an experiment in which he used a stable isotope, [d5-phenylalanine](https://pubchem.ncbi.nlm.nih.gov/compound/Phenylalanine-d5) (on which one of the hydrogens on the phenylalanine is deuterated), to assess
  - was looking at how much of that label gets incorporated into the mixed muscle versus how much is in the precursor pool (the intracellular fluid)
  - that rate of incorporation divided by a time factor gives you the rate of muscle protein synthesis
- protein synthesis starts in your DNA because your DNA codes for the proteins that are going to be synthesized
  - in response to resistance training, you increase muscle protein synthesis
  - resistance training is telling your DNA that we need to adapt to this stressor
  - increases the [transcription](https://en.wikipedia.org/wiki/Transcription_(biology)) of specific DNA sequences
  - it gets transcribed to an mRNA sequence, which is then read by a ribosome, which  brings amino acids in and hooks them together to build new proteins
- When you do resistance training, contractile proteins like myosin and actin will be produced during muscle protein synthesis
- a research review will coming out on Layne’s website soon
- His website has a 50-page [guide](https://www.biolayne.com/articles/research/the-checklist-for-reading-research/) on how to read research
  - A [Venn diagram](https://en.wikipedia.org/wiki/Venn_diagram) in the guide includes the factors highly controlled, high subject number, and long duration, “and what you find is the only way you can get all those to overlap is if you do animal studies”
  - if you want tightly controlled and a high subject number, it’s going to be really short in humans
  - If you want long duration and tightly controlled, you’ll have very few subjects
- Layne used rats because he wanted to study the mechanisms and rats are a good model for human protein metabolism
  - Rats can be fed specific discrete meals
  - Can measure specific useful outcomes once cleared with the IACUC (the IRB for animals)
- Studied the importance of leucine
  - By the mid-2000s, Layne’s advisor [Don Layman](https://fshn.illinois.edu/directory/dlayman), as well as [Leonard Jefferson](https://pennstatehealthnews.org/topics/a-career-filled-with-teaching-mentoring-and-discovery/) and [Scot Kimball](https://pennstate.pure.elsevier.com/en/persons/scot-kimball) from Penn State, [had](https://www.researchgate.net/publication/51643196_Leucine_or_carbohydrate_supplementation_reduces_AMPK_and_eEF2_phosphorylation_and_extends_postprandial_muscle_protein_synthesis_in_rats) [shown](https://diabetes.diabetesjournals.org/content/51/4/928) [that](https://pubmed.ncbi.nlm.nih.gov/16365087/) purified solutions of leucine would increase mTOR activity and muscle protein synthesis
- Layne [looked at the duration](https://academic.oup.com/jn/article/139/6/1103/4670442) of muscle protein synthesis in response to a complete meal
  - even with whey protein, which is thought of as a fast protein, he found an increase in muscle protein synthesis that peaked at 90 minutes post-meal and then by 180 minutes had gone back down to baseline
  - this finding has since been validated in humans [1:31:30]
- Peter wonders how long after the training stimulus ends muscle protein synthesis continues if enough substrate is available
  - Layne says you need a nutritional steady state to measure muscle protein synthesis
  - This is because of assumptions that must be made about things like the isotope that you’re using to assess it, the precursor pool, and the actual protein-bound label
- Two key questions
  - If you gave someone an IV infusion of all amino acids so that the substrate was not limited, what would muscle protein synthesis look like over time?
  - How would things change depending on which amnio acids were provided?
- Mixed muscle protein synthesis (includes all cytoplasmic proteins, mitochondrial proteins, etc.)
  - Layne says there is a 100 – 150% increase in mixed muscle protein synthesis
  - peak is about the same for trained versus untrained people, but the untrained duration lasts much longer
    - in untrained people mixed muscle protein synthesis is about 48 – 72 hours
    - In trained people the initial robust response comes back down about 10 – 12 hours
  - At 24 hours, it’s not much different than baseline
- Myofibrillar protein synthesis (actual contractile muscle proteins)
  - so far has only been assessed up to 16 hours after training
  - neither group (trained or untrained) has returned to baseline in that time
  - but the [area under the curve (AUC)](https://en.wikipedia.org/wiki/Area_under_the_curve_(pharmacokinetics)) is greater for untrained versus trained
- But neither is addressing the other side of protein balance, protein degradation
  - During the first 6 weeks or so of resistance training, you see strength improvements but don’t see much hypertrophy
  - In this initial phase, you have a robust increase in both muscle protein synthesis and protein degradation
  - It’s a big stressor especially if you’ve never trained before
  - Is like cycle remodeling – clearing out damaged proteins and building new ones
  - At the end of the 6-week period, degradation decreases markedly which may coincide with when we see increasing hypertrophy

## Nitrogen balance and muscle protein synthesis, and the regulatory role of hormones for fat flux and muscle growth [1:37:00]

[**Nitrogen balance**](https://en.wikipedia.org/wiki/Nitrogen_balance)

*If a person is consuming roughly the same amount of protein and their training volume and intensity is roughly the same, will they have a negative rather than neutral potential nitrogen balance in the first phase? If you were evaluating them with a nitrogen cart, would that show up as a nitrogen excretion in that first phase? Or are they recycling it?*

- They’re probably going to be nitrogen positive a little bit
- in muscle protein synthesis, about seven out of every eight amino acids used to create a new protein, are recycled from degraded proteins
  - muscle tissue is about 70% water and about 30% protein, so if you add 25 lbs of muscle in a year, it’s about 10 grams of amino acids deposited in muscle per day
  - no matter how much muscle mass you put on, it’s never going to be impressive relative to the amount of amino acids you took in
- Peter says the difference among re-esterification, lipolysis, and fat [oxidation](https://en.wikipedia.org/wiki/Redox) is important
  - If eating a ketogenic diet and a lot of fat, you can very easily gain weight if you’re ingesting so much fat that it exceeds your ability to oxidize it
  - Doesn’t really matter if the fat is [endogenous](https://en.wikipedia.org/wiki/Endogeny_(biology)) or exogenous
  - a ketogenic diet can still produce a ton of fat oxidation without oxidizing the endogenous source that you are targeting
  - And a lot of the [triglyceride](https://en.wikipedia.org/wiki/Triglyceride) contained within the adipose site gets recycled so it can be liberated as free fatty acid and then be re-esterified with glycerol back into it

> “People think of metabolism as like on and off switches. Think about dimmer switches. People think when you’re losing fat, that means that fat burning is ramped up and fat storage is all the way down at zero. No, you are always burning and storing fat simultaneously. Same thing, you are always synthesizing protein and degrading it at the same time.” —Layne Norton

- it’s the relative rates of each that are going to determine if you deposit versus lose fat or protein
- Peter and Bob Kaplan recently did a related [podcast](https://peterattiamd.com/ama22/) on fat flux
- talked about it through the lens of [*de novo*](https://en.wikipedia.org/wiki/De_novo_synthesis) [lipogenesis](https://en.wikipedia.org/wiki/Lipogenesis), [re-esterification](https://en.wikipedia.org/wiki/Ester#Preparation), and [lipolysis](https://en.wikipedia.org/wiki/Lipolysis)

![](https://peterattiamd.com/wp-content/uploads/2021/04/slide-2.-ama22-1024x643.png)

**Figure 4. Neutral fat flux: neither gaining nor losing fat tissue**

![](https://peterattiamd.com/wp-content/uploads/2021/04/slide-4.-ama22-1024x702.png)

**Figure 5. Negative fat flux: losing fat mass**

![](https://peterattiamd.com/wp-content/uploads/2021/04/slide-3.-ama22-1024x684.png)

**Figure 6. Positive fat flux: gaining fat mass**

**The role of hormones in fat flux and muscle mass**

- Fat flux is unrelated to external oxidation that can feed into substrate pools
- Many hormones are actually regulating the different steps
  - Include [insulin](https://en.wikipedia.org/wiki/Insulin), [epinephrine](https://en.wikipedia.org/wiki/Adrenaline), [norepinephrine](https://en.wikipedia.org/wiki/Norepinephrine), [hormone sensitive lipase](https://en.wikipedia.org/wiki/Hormone-sensitive_lipase), [cortisol](https://en.wikipedia.org/wiki/Cortisol), [testosterone](https://en.wikipedia.org/wiki/Testosterone), [lipoprotein lipase](https://en.wikipedia.org/wiki/Lipoprotein_lipase), etc.
  - Some are acting inside the cell (e.g., hormone sensitive lipase, testosterone) and others outside (e.g., insulin, lipoprotein lipase)
- Peter asks for Layne to discuss the hormonal regulation on the same unit of muscle
  - testosterone plays an important role in the transcriptive drive
  - The most obvious difference of course is that testosterone works inside the cell
- Layne points out that when we’re talking about all these hormones, the outcome is the result of the summation of all of those signals
  - you’ll get confused if you focus on just one hormone
  - Example: Kevin Hall’s [study on fat loss](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4962163/) showing that even though insulin was 26% higher, one group lost a greater amount of actual fat mass than the ketogenic diet group
  - People were confused, but they forgot that insulin is only one input
- Recent [study](https://www.frontiersin.org/articles/10.3389/fphys.2018.01373/full) by [Stu Phillips](https://www.science.mcmaster.ca/kinesiology/component/comprofiler/userprofile/phillis.html) on testosterone and [androgen receptor](https://en.wikipedia.org/wiki/Androgen_receptor) density
  - Peter wonders why androgen receptor density would be higher in someone getting exogenous testosterone – shouldn’t the receptors downregulate?
  - when testosterone gets into the cell, it’s converted to a substance that binds with the androgen receptor
  - then it can attach to the DNA, increasing transcription of different proteins
  - ramping up your capacity for increasing muscle proteins
- Different than how leucine acts nutritionally, because although leucine is also intracellular, it’s more of a short-term signal
  - when you have enough testosterone available, the androgen receptors have to meet the demand for metabolizing and regulating the excess testosterone
  - there is a negative feedback loop with luteinizing hormone and the gonads (receptors will downregulate as levels of the hormone go up)
- Layne guesses that if you’re not getting exogenous testosterone, then there’s probably not a negative feedback regulation loop
  - it would make sense that the muscle might increase its androgen receptor density to meet the free testosterone load
  - as long as there’s not so much testosterone that sets up a negative feedback loop to the gonads or reduces luteinizing hormone or increases [aromatization](https://en.wikipedia.org/wiki/Aromatization)
- Layne warns that he is not a testosterone expert, so he’s not sure if this is exactly accurate

## What’s really driving muscle growth: intrinsic vs. systemic factors, IGF, and hormone signaling [1:46:30]

- Much of Stu Phillips’s work indicates that muscle growth appears to be mostly intrinsically regulated
  - In the late 90s and early 2000s, the focus was on systemic regulation of muscle growth (e.g., systemic levels of testosterone or IGF-1, noting that resistance exercise will increase testosterone for 30 – 60 minutes)
  - Work by Stu and others suggest that muscle growth is likely an effect of tension
- If that’s the case, there would need to be a translation of contractile force into a chemical signal (called mechano-transduction)
  - Mechano-[growth factor](https://en.wikipedia.org/wiki/Growth_factor) is probably involved
- People don’t realize that systemic [IGF-1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1) and [growth hormone](https://en.wikipedia.org/wiki/Growth_hormone) are not [anabolic](https://en.wikipedia.org/wiki/Anabolism) to skeletal muscle (meaning that they do not build it up)
  - We know that growth hormone increases in response to certain factors like fasting, resistance training, exercise in general, sleep, etc.
  - growth hormone increases the liver production of IGF-1, the master hormone that increases muscle mass
- Studies how that giving exogenous growth hormone leads to an increase in lean body mass but not skeletal muscle mass
  - increase in lean body mass is completely accounted for by an increase in body water and connective tissue
- even amongst scientists, people don’t understand the concept of a localized response versus a systemic response or an acute response versus a chronic response
- growth hormone is not anabolic to skeletal muscle
  - growth hormone response to exercise appears to be mostly substrate driven
  - growth hormone probably increases as a response to exercise to increase lipolysis and to liberate free fatty acids for use as an energy [substrate](https://en.wikipedia.org/wiki/Substrate_(chemistry))
  - The autocrine IGF-1 that is released by the muscle tissue itself in response to mechanical tension is very anabolic
- Difference among [endocrine](https://en.wikipedia.org/wiki/Endocrine_system), [paracrine](https://en.wikipedia.org/wiki/Paracrine_signaling), and [autocrine](https://en.wikipedia.org/wiki/Autocrine_signaling)
  - Endocrine: a hormone gets released and its effect is all throughout the body (e.g., insulin., which is released by the pancreatic β-cells and then affects many cells throughout the body)
  - Paracrine: a hormone gets released but only impacts the cells right next to it
  - Autocrine: effect is on itself only

![](https://peterattiamd.com/wp-content/uploads/2021/05/f7.-laynenorton.jpeg)

**Figure 7. Comparison of types of hormone signaling.** Image credit: [BioNinja](https://ib.bioninja.com.au/options/option-d-human-physiology/d5-hormones-and-metabolism/types-of-signalling.html)

- If you want to get a sense of growth hormone levels, measure IGF-1
  - find out how much IGF is being produced by the liver, which is systemic and what we think of as an endocrine IGF
  - autocrine or paracrine IGF-1 that gets released by the muscle tissue itself is also called mechano-growth factor
  - is anabolic to muscle tissue and a very localized, intrinsic response

> “Muscle tissue is an energetically expensive tissue to maintain. It takes more energy, more ATP, more calories. To maintain it, you actually have to increase synthesis and breakdown.” —Layne Norton

- If you want to eat more calories, build muscle, because it takes calories to maintain it
- “If you place a stress on a particular muscle tissue like your legs, it does not make sense to me that your arms will grow because you may not need your arms”
  - from an evolutionary perspective, it does not make sense that you would build a different tissue in response to the localized effect of training
  - if you train your legs, your arms don’t get bigger
  - if you train one leg, the other one doesn’t get bigger
  - some of the best resistance training studies use unilateral training
  - the person’s non-trained leg serves as the individual’s own control to account for genetic variations

**Regulation of mechano-transduction**

- [Phosphatidic acid](https://en.wikipedia.org/wiki/Phosphatidic_acid) is a likely component of mechano-transduction
- The contractile unit of a muscle tissue is called a [sarcomere](https://en.wikipedia.org/wiki/Sarcomere)
  - a sarcomere has two ends which are called Z disks, and in between you have [actin](https://en.wikipedia.org/wiki/Actin) and [myosin](https://en.wikipedia.org/wiki/Myosin), which overlap
  - Sarcomeres are separated by Z discs

![](https://peterattiamd.com/wp-content/uploads/2021/05/f8.-laynenorton.jpeg)

**Figure 8. Illustration of a sarcomere**. The sarcomere is the contractile subunit of striated muscle.  A myofibril consists of hundreds of sarcomeres end to end.  The sarcomeres appear striated due to alternating bands of thin actin (light) and thick myosin (dark).  The anatomical landmarks of a sarcomere are: the A band (length of a myosin filament, including actin overlap), the H band (myosin filaments only), the I band (actin filaments only), the M line (region of myosin interlacing / anchoring), and the Z line/disc (region of actin anchoring). Image credit: [University of Miami](https://www.bio.miami.edu/dana/360/360F18_15.html)

- When a muscle contracts, actin and myosin are linked together and pulling
- The Z disc is where phosphatidic acid is stored
  - To transform a mechanical signal into a chemical signal, it makes sense to store the signal in the Z disc where a lot of the mechanical tension is felt
  - Mechanistic studies suggest that mechanical tension causes phosphatidic acid to be released
- Phosphatidic acid is a stimulator of mTOR
  - testosterone doesn’t really regulate mTOR but works on the transcriptional level
  - insulin affects mTOR
    - although it doesn’t seem to be a powerful enough signal to actually impact muscle building
    - so if it has an effect, it’s probably related to protein breakdown

## The role of protein, carbohydrates and insulin on muscle growth and preservation, and the importance of context when interpreting study results [1:55:30]

**Role of insulin**

- Taking pure carbohydrate will cause insulin levels to rise and seems to inhibit protein degradation, but it doesn’t seem to affect muscle protein synthesis
- [Bob Wolfe](https://aging.uams.edu/dr-robert-r-wolfe/)’s lab [developed a way](https://www.researchgate.net/publication/11171167_Measurement_of_muscle_protein_fractional_synthesis_and_breakdown_rates_from_a_pulse_tracer_injection) to measure muscle breakdown
  - arterial venous balance: determine balance by infusing a stable isotope and see how much of that label is going into the muscle and then how much is coming out
  - A biopsy can determine the [fractional rate](https://en.wikipedia.org/wiki/Fractional_synthetic_rate) of protein synthesis
  - Can then subtract to calculate the breakdown
- In people who are resistance trained, a large amount of carbohydrates causes a switch from an increase in muscle protein breakdown to baseline breakdown
  - But synthesis remains the same

**Is there an advantage to combining carbohydrate and protein?**

- Peter wonders if there is an argument for combining carbohydrate and protein after a resistance training to both reduce degradation and increase synthesis
  - Some degradation is probably needed to improve the muscle

*-Layne knows of two relevant studies:*

- [Vargas study](https://jissn.biomedcentral.com/articles/10.1186/s12970-018-0236-9)

- - - - Looked at a protein and low carbohydrate diet (ketogenic) versus a protein and higher carbohydrate diet (both had same number of calories)
      - Over 12 weeks, blood ketones increased and there was less lean body mass accrual in the ketogenic diet group
      - They still increased lean body mass, but the group that was getting more carbohydrates had more lean body mass
      - However, carbohydrates make you store [glycogen](https://en.wikipedia.org/wiki/Glycogen)
      - Was it just water or was it contractile tissue?

- [Mettler study](https://pubmed.ncbi.nlm.nih.gov/19927027/)

- - - Found that diet composition made a difference in maintenance of lean body mass
    - Measured subjects’ performance in exercises like squat and bench press
    - Suggests that perhaps there is something different in terms of actual contractile tissue, but a lot more research is needed
  - you can definitely build muscle on a [ketogenic](https://en.wikipedia.org/wiki/Ketogenesis) diet, but likely can build more if you’re including carbohydrates
  - it may have something to do with carbohydrates’ or insulin’s blunting effect on muscle protein breakdown

**Ketogenic diet**

- Peter’s experience on a ketogenic diet
  - Harder to study because of the length of time it takes to adapt to them
  - Peter started in May 2011 and initially committed for 12 weeks
  - He was miserable 5 weeks in, but he had not reduced his already very high training volume (cycling and swimming)
  - At 12 weeks, he got to the point where he could get his [aerobic](https://en.wikipedia.org/wiki/Aerobic_exercise) base back to where it was 12 weeks earlier
  - but [anaerobically](https://en.wikipedia.org/wiki/Anaerobic_exercise), he was nowhere near where he was 12 weeks earlier – took 18 months with essentially no deviation from the diet, half of the 3 total years he was on the diet
  - hard to say if other variables also had an effect
  - shows how hard it is to study it
- A similar thing can be said about testosterone supplementation:
  - I.e., you do not need to take exogenous testosterone to be a bodybuilder
  - But if your goal is to be the biggest and strongest you can be, you’ll need to take it

**The problem with anecdotal evidence**

- We must be cautious with anecdotes
- everyone knows someone who smoked but lived a long life, but we still know it’s bad for you and does not increase longevity
- We make broad recommendations based on evidence, but there will be outliers
  - We need a hard metric for ketogenic or fat adaptation
  - It’s not blood ketones or lipolysis
  - fat oxidation within six days is already maxed out
- Peter wishes he had taken muscle biopsies when he did the ketogenic diet “if that 18-month transition was something beyond psychological”
- For ultra endurance, low carb is neither better or worse
  - For aerobic exercise, under 60% of [VO2 max](https://en.wikipedia.org/wiki/VO2_max), can still get the most out of exercise after fat adapted
  - But once over 70%, hard to get optimal performance on a ketogenic diet
  - [Shawn Baker](https://shawn-baker.com/about/) is 50 years old and dead lifting 500 pounds for nine reps, so it’s possible to excel, but we don’t know if he is at his own personal optimal level or not

**Context matters**:

- we only need 50 g of protein a day to avoid being in negative nitrogen balance
- but that’s not necessarily optimal for health or lean body mass
- Can definitely get strong on a ketogenic diet
  - Dom D’Agostino can deadlift 700 pounds multiple times with no carbohydrate intake
  - But that doesn’t mean that’s the best approach generally
- In nutrition, it’s important to be clear about what you’re comparing something to
  - Layne has a great [critique](https://www.biolayne.com/articles/research/the-game-changers-review-a-scientific-analysis/) on his website of the documentary [*Game Changers*](https://gamechangersmovie.com/), which Peter calls “a horrible, horrible piece of propaganda”
  - Peter doesn’t oppose a plant-based diet, just bad science

> “If you compare diet X to the standard American diet, almost by definition, diet X is going to look amazing because the standard American diet is such an awful diet.” —Layne Norton

## Clarifying the role of cortisol—a misunderstood hormone [2:07:45]

**Cortisol**

*Extreme scenarios:*

- [Addisonian crisis](https://en.wikipedia.org/wiki/Adrenal_crisis)
  - can’t make cortisol after infection or injury to the adrenal gland
  - Have to give them massive doses of hydrocortisone to keep them alive – shows how medically necessary cortisol is
- [Cushing’s disease](https://en.wikipedia.org/wiki/Cushing%27s_disease)
  - Problem with pituitary or adrenal gland where excess cortisol is made
  - Very serious condition with excessive fat accumulation and metabolic dysregulation

*Role of cortisol*

- cortisol is secreted in response to some kind of stress
- Things like lack of sleep or an overall unhealthy lifestyle will cause high levels of cortisol
- We evolved to react to stressors like getting chased by a predator, and a part of that is a fuel mobilization response, mobilizing glucose and free fatty acids
  - In Cushing’s disease, you’re not really accumulating fat but redistributing it
  - Exercise is a stressor that increases cortisol
- People used to say not to exercise for more than an hour because cortisol levels would spike, which reveals a deep misunderstanding
- Stu Phillips cortisol [study](https://pubmed.ncbi.nlm.nih.gov/22105707/)
  - looked at the post- exercise increases in several systemic hormones: testosterone, IGF-1, growth hormone, and cortisol
  - cortisol was most closely associated with hypertrophy
- But is cortisol producing the hypertrophy, or is cortisol increased in response to the stress that is producing hypertrophy?
  - Not necessarily a cause
- the resistance training session that produces the most amount of stress and adaptation is likely to produce the most cortisol and possibly the most hypertrophy if it’s repeated
  - cortisol will impede muscle protein synthesis
  - acts transcriptionally like testosterone
- it’s a steroid hormone that is sometimes used to reduce inflammation
- the real concern is long-term, low-level elevations in cortisol

> “A lot of the vegan doctors get all up in arms about getting stimulated by leucine and that’s going to give you cancer. You don’t understand tissue specifics and you don’t understand acute versus chronic.” —Layne Norton

- Peter says a very famous vegan doctor chastised him for suggesting that someone ingest five grams of leucine during a workout because of its negative effect on mTOR and its potential negative effects on a person’s health

## The problem with studies trying to isolate one nutrient [2:15:00]

> “People want to isolate out nutrients as being good or bad, and I would really implore people that nutrients are not necessarily good or bad. Context matters. And what really matters is lifestyle and overall eating patterns.” —Layne Norton

- When you isolate out one substance, you can find mechanistic data to support almost anything you want
  - For example, there’s no question that high-fructose corn syrup (HFCS) is not good for you
    - but the data suggest that it provides too much energy rather than being fattening independent of calories ingested
    - people who eat HFCS also tend to eat more calories, more processed foods, and more fats

- A [Canadian study](https://www.researchgate.net/publication/343301272_Co-consumption_of_Vegetables_and_Fruit_Whole_Grains_and_Fiber_Reduces_the_Cancer_Risk_of_Red_and_Processed_Meat_in_a_Large_Prospective_Cohort_of_Adults_from_Alberta's_Tomorrow_Project) looked at cancer incidence in 100K people grouped by quartile of meat intake
  - tend to find that meat intake is associated with cancer
  - but people who eat high amounts of meat tend to have an unhealthy lifestyle in general
    - less likely to exercise
    - more likely to smoke and eat processed foods
- - But this study also compared it with the lowest to highest quartiles of fruit and vegetable intake
  - found that the group with the highest level of both meat and fruit and vegetable intake had the same risk for cancer as the group with the lowest level of meat intake but a high level of fruit and vegetable intake
- Layne says it shows we need to look at eating patterns much more than we look at individual nutrients
  - If take 50 g of starchy carbs or fats and replace it with sugar, unlikely to change much, but people don’t eat like that in the real world
  - He’s not recommending that people eat sugar, just thinking mechanistically

> “It’s really important to understand how limited nutritional studies are. …When you’re talking about trying to pick out these really granular details, you’re talking about a study that’s so restrictive it’s really hard to generalize the results to the average person.” —Layne Norton

## The important role of inflammation from exercise [2:19:25]

- In the [*Game Changers* debate](https://open.spotify.com/episode/110ulFKocbLDsLhZ0bJwwm) on [Joe Rogan](https://en.wikipedia.org/wiki/Joe_Rogan)’s podcast, [James Wilks](https://en.wikipedia.org/wiki/James_Wilks) said that if you have high levels of inflammation from exercise and then eat meat afterwards, you’re compounding the inflammation
  - That shows a lack of understanding between acute vs. chronic inflammation
  - Those two types of inflammation are not the same

**Acute inflammation from exercise**

- Acute inflammation from exercise can be beneficial
- In theory, exercise sounds like a terrible idea
  - it increases your blood pressure, heart rate, [free radical](https://en.wikipedia.org/wiki/Radical_(chemistry)) production, and inflammation
  - But exercise is almost like a vaccine
  - “You give a controlled dose of a stressor and your body adapts to that stressor by getting better at handling it”
  - People who exercise regularly have lower resting heart rate, blood pressure, and inflammation
- There is limited value in measuring IGF-1 or [IGF-6](https://en.wikipedia.org/wiki/Insulin-like_growth_factor) an hour or two hours after a meal

> “Exercise probably is the best drug we have…I don’t believe we will ever be able to develop a drug that is that remarkable. It is simply unbelievable what it can do” —Peter Attia

- You have to lose body fat to see any big improvements: with exercise, you can get massive improvements with no weight loss
- If you don’t do any resistance exercise, “you are missing out on the most powerful tool you have to improve your health and body composition”
- Bob Wolfe [points out](https://academic.oup.com/ajcn/article/84/3/475/4648841) that the amount of lean body mass was a powerful predictor of longevity
  - it doesn’t take nearly as much work to preserve muscle mass once you have it
  - Peter discussed this with [Alex Hutchinson](https://www.outsideonline.com/1745511/alex-hutchinson) on a previous podcast [episode](https://peterattiamd.com/alexhutchinson/)
  - One of the things Peter fears the most for his patients as they age is any sort of injury or illness preventing them from exercising
  - “the deconditioning that occurs when someone doesn’t do anything for a month is devastating”

## Keys to preserving muscle, and the value of habits, consistency, and resilience [2:23:30]

- How does Layne stay consistent and diligent?
- The principles of resistance training are very similar to those for life in general
  - Pyramid schemes are not the way to acquire wealth
    - 80% of millionaires are first-generation self-made based not on luck but by consistent, long-term fiscal discipline
  - Need to modify behavior to get consistency
    - Binging on junk food or blowing money on a shopping spree are due to behaviors that must be modified
    - need to create new positive habits
- [Marie Spreckley](https://www.linkedin.com/in/marie-spreckley-570884a/?originalSubdomain=uk) did a [systematic review](https://pubmed.ncbi.nlm.nih.gov/33455563/) looking at people who lost weight and kept it off
  - Was inspired to get her PhD after reading Layne’s book [*Fat Loss Forever*](https://www.amazon.com/Fat-Loss-Forever-Lose-KEEP/dp/1794510109)
  - Maintenance of weight loss was associated with consistency and the ability to embrace challenges rather than running from them or viewing challenges as part of the process
  - She also found that the people who lost weight and kept it off said that they had to form a new identity
- Peter says [James Clear](https://jamesclear.com/about)’s [book](https://www.amazon.com/Atomic-Habits-Proven-Build-Break/dp/0735211299) first made him understand this
  - The key is not discipline and willpower, which will fade over time
  - Must change mindset from “I have to exercise” to “I am a fit person who exercises”
  - Makes it easier to do day in and day out
  - Peter never struggles with exercise, but he will always struggle with food a bit because he hasn’t had a “full identity switch” with food
- [Ethan Suplee](https://en.wikipedia.org/wiki/Ethan_Suplee) is an actor known for the movie [*Remember the Titans*](https://en.wikipedia.org/wiki/Remember_the_Titans)
  - He lost a tremendous amount of weight and is “jacked” now
  - He says “I killed my clone today,” which means he formed a new identity and killed the person he once was
- “You cannot create a new life … while still dragging those behaviors behind you”
  - It’s like an alcoholic who gives up drinking
  - You can’t just say I’ll stop drinking, you have to change everything about your life
  - The same is true of nutrition and maybe also exercise – you must give some old habits up
- “The great thing about nutrition is you get to pick what you sacrifice”
  - Pick the form of restriction that feels easiest
  - For Layne, it feels easy to control portion size and track calories and macros, so he can otherwise eat what he wants
  - For other people this feels labor intensive and avoiding specific foods may work better
- Layne initially assumed that what worked for him would work for everyone but he realized it wasn’t true

> “At the end of the day, if you’ve ever lost weight and then regained it, why did it happen? It didn’t happen because you didn’t get your macronutrient ratio perfect or your nutrient timing wasn’t down, it happened because you stopped being consistent with the behaviors that you implemented.” —Layne Norton

- People say they wish they were motivated to exercise like Layne is
  - He tells them it’s like marriage – you always love your spouse, but sometimes you fight and are not always happy with them
  - He loves weightlifting but he acquired that love through years
  - It’s fine to take a day off, but you have to be careful that it doesn’t turn into weeks and months and years
  - He sees training like brushing his teeth – he doesn’t need to be motivated and pump himself up to brush his teeth, because if he doesn’t his teeth will go bad
  - Similarly, if you don’t exercise, your body will suffer

> “It is not a question of motivation, it is a question of ‘what do I want and what are the actions that are required to get what I want?’ And if my actions do not line up with what is needed and the amount of work that is needed, it’s very simple: I’m not going to get what I want.” —Layne Norton

- People need to:
  - 1) buy in
  - 2) persist after the honeymoon phase when facing their first challenge or setback
- Participants in the systematic review said it was difficult to see their weight fluctuate; Layne tells them to weigh in every single day and take the average
- “The point of this all is that consistency is the fundamental… You could have any diet. You could have any training system. If you’re consistent, you’re going to see results”
  - If you tried to be the best [3-point shooter](https://en.wikipedia.org/wiki/Three-point_field_goal) you could be, and you practiced every single day for three hours a day for 10 years
    - you probably wouldn’t be in the [NBA](https://www.nba.com/)
    - but even with no instruction, coach, or books, you’d be pretty damn good at shooting three pointers
- Layne says to use other people’s stories for inspiration, but be very careful about comparing yourself
  - Don’t ask yourself if you can be like a specific person but instead if you can get better
  - When he started out, other people told him he wouldn’t be good at weightlifting
  - If he had listened to them, he never would have won a gold medal in the squat

> “I got a lot farther than I ever could have imagined just through sheer consistency. I did a lot of stuff wrong, but sheer mass effect of work and consistency can make up for a lot of shortcomings.” —Layne Norton

**Wrap up and a future conversation**

- Peter says they only got through a third of what he wanted to talk about

He will have Layne back on to discuss, among other topics: [creatine](https://en.wikipedia.org/wiki/Creatine); [KAATSU](https://en.wikipedia.org/wiki/Kaatsu) / [occlusion training](https://en.wikipedia.org/wiki/Blood_flow_restriction_training); the differences among the size of a muscle, the strength of a muscle, and the metabolic function of a muscle; and leucine signaling

§

## Selected Links / Related Material

***National Geographic*** **special about a great white shark**: [World’s Biggest Great White? Expedition Hawaii](https://www.natgeotv.com/za/shows/nationalgeographicwild/worlds-biggest-great-white-expedition-hawaii#episodes-t0) [17:30]

**Layne’s podcast interview with Alan Levinovitz about naturalism and uncertainty**: [Interview with professor of religious studies Dr. Alan Levinovitz](https://beautyandthegeek.podbean.com/e/interview-with-dr-alan-levinovitz/) [25:45]

**Peter’s interview with Mark and Chris Bell**: [#28 – Mark and Chris Bell: steroids, powerlifting, addiction, diet, training, helping others, documentaries, and living your best life](https://peterattiamd.com/brothersbell/) (November 12, 2018) [32:15]

**Layne’s data on mixed muscle protein synthesis using d5-phenylalanine as a marker**: [Protein distribution affects muscle mass based on differences in postprandial muscle protein synthesis and plasma leucine in rats](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3500748/) *Journal of the International Society of Sports Nutrition* (Norton et al. 2012) [1:27:15]

**Layne’s guide to understanding research studies**: [The checklist for reading research](https://www.biolayne.com/articles/research/the-checklist-for-reading-research/) Eric Trexler, biolayne.com (February 28, 2016) [1:29:30]

**Work showing that leucine increases mTOR activity and muscle protein synthesis**: [1:30:45]

- *By Don Layman*: [Leucine or carbohydrate supplementation reduces AMPK and eEF2 phosphorylation and extends postprandial muscle protein synthesis in rats](https://www.researchgate.net/publication/51643196_Leucine_or_carbohydrate_supplementation_reduces_AMPK_and_eEF2_phosphorylation_and_extends_postprandial_muscle_protein_synthesis_in_rats) *AJP Endocrinology and Metabolism* (Wilson, Layman et al. 2011)
- *By Penn State team*:
  - [Orally Administered Leucine Enhances Protein Synthesis in Skeletal Muscle of Diabetic Rats in the Absence of Increases in 4E-BP1 or S6K1 Phosphorylation](https://diabetes.diabetesjournals.org/content/51/4/928) *Diabetes* (Anthony … Kimball, & Jefferson 2002)
  - [Signaling pathways and molecular mechanisms through which branched-chain amino acids mediate translational control of protein synthesis](https://pubmed.ncbi.nlm.nih.gov/16365087/) *Journal of Nutrition* (Kimball & Jefferson 2006)

**Layne’s study on the duration of postprandial muscle protein synthesis**: [The Leucine Content of a Complete Meal Directs Peak Activation but Not Duration of Skeletal Muscle Protein Synthesis and Mammalian Target of Rapamycin Signaling in Rats](https://academic.oup.com/jn/article/139/6/1103/4670442) *The Journal of Nutrition* (Norton et al. 2009) [1:31:30]

**Peter and Bob Kaplan’s podcast on fat flux**: [#157 – AMA #22: Losing fat and gaining fat: the lessons of fat flux](https://peterattiamd.com/ama22/) (April 12, 2021) [1:41:15]

**Kevin Hall’s study on insulin, fat mass, and the ketogenic diet**: [Energy expenditure and body composition changes after an isocaloric ketogenic diet in overweight and obese men](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4962163/) *American Journal of Clinical Nutrition* (Hall et al. 2016) [1:42:45]

**Study by Stu Phillips on androgen receptor density**: [Muscle Androgen Receptor Content but Not Systemic Hormones Is Associated with Resistance Training-Induced Skeletal Muscle Hypertrophy in Healthy, Young Men](https://www.frontiersin.org/articles/10.3389/fphys.2018.01373/full) *Frontiers in Physiology* (Morton … Phillips 2018) [1:44:00]

**Bob Wolfe’s paper on calculating muscle breakdown**: [Measurement of muscle protein fractional synthesis and breakdown rates from a pulse tracer injection](https://www.researchgate.net/publication/11171167_Measurement_of_muscle_protein_fractional_synthesis_and_breakdown_rates_from_a_pulse_tracer_injection) *AJP Endocrinology and Metabolism* (Zhang, Chinkes & Wolfe 2002) [1:55:45]

**Vargas study comparing lean body mass with a ketogenic vs. high carb diet**: [Efficacy of ketogenic diet on body composition during resistance training in trained men: a randomized controlled trial](https://jissn.biomedcentral.com/articles/10.1186/s12970-018-0236-9) *Journal of the International Society of Sports Nutrition* (Vargas et al. 2018) [1:57:30]

**Study finding diet protein composition made a difference in maintenance of lean body mass**: [Increased protein intake reduces lean body mass loss during weight loss in athletes](https://pubmed.ncbi.nlm.nih.gov/19927027/) *Medicine and Science in Sports and Exercise* (Mettler et al. 2010) [1:58:00]

***The Game Changers*** **documentary that Peter calls “a horrible piece of propaganda”**: [The Game Changers](https://gamechangersmovie.com/) (2019) [2:06:30]

**Layne’s critique of** ***The Game Changers***: [*The Game Changers* review – a scientific analysis (updated)](https://www.biolayne.com/articles/research/the-game-changers-review-a-scientific-analysis/) (November 11, 2019) [2:06:30]

**Study finding that cortisol was most closely associated with muscle hypertrophy**: [Associations of exercise-induced hormone profiles and gains in strength and hypertrophy in a large cohort after weight training](https://pubmed.ncbi.nlm.nih.gov/22105707/) *European Journal of Applied Physiology* (West & Phillips 2012) [2:12:15]

**Study of cancer risk that grouped participants by quartile of both meat and fruit/vegetable consumption**: [Co-consumption of Vegetables and Fruit, Whole Grains, and Fiber Reduces the Cancer Risk of Red and Processed Meat in a Large Prospective Cohort of Adults from Alberta’s Tomorrow Project](https://www.researchgate.net/publication/343301272_Co-consumption_of_Vegetables_and_Fruit_Whole_Grains_and_Fiber_Reduces_the_Cancer_Risk_of_Red_and_Processed_Meat_in_a_Large_Prospective_Cohort_of_Adults_from_Alberta's_Tomorrow_Project) *Nutrients* (Maximova et al. 2020) [2:16:45]

**Debate about** ***The Game Changers*** **on Joe Rogan’s podcast**: [#1393 – James Wilks & Chris Kresser – *The* *Game Changers* Debate](https://open.spotify.com/episode/110ulFKocbLDsLhZ0bJwwm) Joe Rogan, The Joe Rogan Experience (December 2019) [2:19:30]

**Bob Wolfe on lean body mass as a predictor of longevity**: [The underappreciated role of muscle in health and disease](https://academic.oup.com/ajcn/article/84/3/475/4648841) *The American Journal of Clinical Nutrition* (Wolfe 2006) [2:22:45]

**Peter’s discussion with Alex Hutchinson about muscle mass**: [#151 – Alex Hutchinson, Ph.D.: Translating the science of endurance and extreme human performance](https://peterattiamd.com/alexhutchinson/) (March 1, 2021) [2:23:15]

**Systematic review of the psychological aspects of weight loss:** [Perspectives into the experience of successful, substantial long-term weight-loss maintenance: a systematic review](https://pubmed.ncbi.nlm.nih.gov/33455563/) *Int J Qual Stud Health Well-being* (Spreckley et al. 2021) [2:27:00]

**Layne’s book that inspired Marie Spreckley**: [Fat Loss Forever: How to Lose Fat and KEEP it Off](https://www.amazon.com/Fat-Loss-Forever-Lose-KEEP/dp/1794510109) by Layne Norton and Peter Baker (2019) [2:27:00]

**Book that helped Peter understand the connection between identity and habits**: [Atomic Habits: An Easy & Proven Way to Build Good Habits & Break Bad Ones](https://www.amazon.com/Atomic-Habits-Proven-Build-Break/dp/0735211299) by James Clear (2018) [2:28:15]

§

## People Mentioned

- [Dominic D’Agostino](https://www.ihmc.us/groups/ddagostino/#:~:text=Dominic%20D'Agostino%20is%20a,Florida%20Morsani%20College%20of%20Medicine.) [2:45, 2:05:45]
- [Joe Klemczewski](https://www.bodybuilding.com/author/joe-klemczewski) [8:45, 45:15]
- [Chris Schnabel](https://www.eckerd.edu/chemistry/faculty/schnabel/) [18:30]
- [Jeremy Loenneke](https://hesrm.olemiss.edu/people/jeremy-paul-loenneke/) [23:00]
- [Bob Kaplan](https://www.linkedin.com/in/bobckaplan/) [23:45, 1:41:15]
- [Alan Levinovitz](https://www.jmu.edu/philrel/people/levinovitz-alan.shtml) [25:45]
- [Greg Nuckols](https://breakingmuscle.com/coaches/greg-nuckols) [26:00]
- [Mark Bell](https://www.markbell.com/who-is-mark-bell) [32:15]
- [Chris Bell](https://en.wikipedia.org/wiki/Chris_Bell_(director)) [32:15]
- [Lee Haney](https://en.wikipedia.org/wiki/Lee_Haney) [36:00]
- [Dorian Yates](https://en.wikipedia.org/wiki/Dorian_Yates) [36:00, 1:02:30]
- [Stuart McGill](https://www.backfitpro.com/about-us/) [46:00]
- [Ronnie Coleman](https://en.wikipedia.org/wiki/Ronnie_Coleman) [1:02:30]
- [Alberto Nuñez](https://3dmusclejourney.com/about/alberto-nunez/) [1:11:45]
- [Kevin Hall](https://www.niddk.nih.gov/about-niddk/staff-directory/biography/hall-kevin) [1:16:00, 1:24:15, 1:42:45]
- [Beth Lewis](https://bodyevolvednyc.com/us/) [1:20:15]
- [Don Layman](https://fshn.illinois.edu/directory/dlayman) [1:30:45]
- [Leonard “Jim” Jefferson](https://pennstatehealthnews.org/topics/a-career-filled-with-teaching-mentoring-and-discovery/) [1:30:45]
- [Scot Kimball](https://pennstate.pure.elsevier.com/en/persons/scot-kimball) [1:30:45]
- [Stuart Phillips](https://www.science.mcmaster.ca/kinesiology/component/comprofiler/userprofile/phillis.html) [1:44:00, 1:46:30, 2:12:15]
- [Robert Wolfe](https://aging.uams.edu/dr-robert-r-wolfe/) [1:55:45, 2:22:45]
- [Shawn Baker](https://shawn-baker.com/about/) [2:04:45]
- [Joe Rogan](https://en.wikipedia.org/wiki/Joe_Rogan) [2:19:30]
- [James Wilks](https://en.wikipedia.org/wiki/James_Wilks) [2:19:30]
- [Alex Hutchinson](https://www.outsideonline.com/1745511/alex-hutchinson) [2:23:15]
- [Marie Spreckley](https://www.linkedin.com/in/marie-spreckley-570884a/?originalSubdomain=uk) [2:27:00]
- [James Clear](https://jamesclear.com/about) [2:28:15]
- [Ethan Suplee](https://en.wikipedia.org/wiki/Ethan_Suplee) [2:29:15]

§

![](https://peterattiamd.com/wp-content/uploads/2021/05/bio-image2-laynenorton-500x500.png)

##### Layne Norton, Ph.D.

Layne Norton is a natural pro bodybuilder, professional powerlifter, and a bodybuilding / figure / physique coach.  He has won numerous bodybuilding and powerlifting competitions and currently holds the world record for the IPF 93 kg class squat.  He is the co-author of several books, including *Fat Loss Forever: How to Lose Fat and KEEP It Off*, as well as several research publications. He has a degree in biochemistry from Eckerd College and earned his PhD in nutritional sciences from the University of Illinois.

Website: [Biolayne](https://www.biolayne.com/)

Podcast: [Physique Science Radio](https://www.biolayne.com/media/podcasts/)

Twitter: [@BioLayne](https://twitter.com/BioLayne?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

Facebook: [Layne Norton](https://www.facebook.com/LayneNorton)

Instagram: [Biolayne](https://www.instagram.com/biolayne/?hl=en)