# #178 – Lance Armstrong: The rise, fall, and growth of a cycling legend

**Source:** [https://peterattiamd.com/lancearmstrong/](https://peterattiamd.com/lancearmstrong/)

---

Lance Armstrong is a legendary figure in professional cycling having won seven consecutive Tour de France titles but also a controversial figure facing scrutiny for the use of performance enhancing drugs. In this episode, Lance takes us through his meteoric rise to one of the most famous athletes in the world and his equally accelerated fall from grace. Lance describes how he persevered through his brutal diagnosis of testicular cancer before rattling off a historic run of seven consecutive Tour de France titles all while facing tremendous scrutiny for his alleged use of performance enhancing drugs such as EPO and cortisone. Lance opens up about his decision to come clean about his use of performance enhancing drugs, the remorse for how he treated other people during that time in his life, and the personal growth that’s helped him emerge on the other end of that. Finally, Lance recounts some of favorite stories from his cycling career, reflects on his legacy, and explains how he stays fit at age 50.

\*[WATCH PODCAST ON YOUTUBE](https://youtu.be/NaGLfau1tRs)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/lancearmstrong/the_Drive_public.png)

Play

#178 - Lance Armstrong: The rise, fall, and growth of a cycling legend

#178 - Lance Armstrong: The rise, fall, and growth of a cycling legend

1x15s30s

0:001:58:16

## We discuss:

- What everyone wants to know—yes and no questions [2:15];
- Lance’s childhood and beginnings of a great athlete [4:15];
- Lance’s realization that he had a knack for racing after his first pro race at age 15 [13:00];
- The move to cycling full time and a desire to compete in the Olympics [16:30];
- Metrics tracked early in Lance’s career and his time with Motorola team [20:00];
- The grueling nature of the Tour de France and the beginnings of serious drug usage in cycling [27:00];
- The impact of EPO on cycling performance [35:15];
- Testicular cancer diagnosis—denial, torturous symptoms, and treatment [38:15]
- Livestrong is born [50:45];
- Return to cycling post-cancer and a crossroad in Lance’s career [53:45]
- Lance’s rise to prominence in the late 90s and the growing use of EPO in the sport [1:00:00];
- Racing in the early 2000’s, blood transfusions, and rivalry with Jan Ulrich [1:12:00];
- Retirement in 2005 and a comeback in 2009 [1:22:45];
- Lance’s decision to come clean and tell the truth [1:27:30];
- Growth through downfall: learning from his mistakes and helping others after their own fall from grace [1:33:00];
- Moving forward: Living his life, reflecting on his legacy, the state of Livestrong [1:42:30];
- Turning back the clock: Advice Lance would give to his 15 year-old self [1:46:45];
- Keeping fit at age 50 [1:51:00];
- More.

§

## Show Notes

**Pre-show notes**

> “I realize that many people listening to this might think that they have their mind made up about Lance, and that’s understandable, but I do suggest that it might be worth spending the time to listen to this episode” – Peter Attia

- There are really a number of issues here
  - The use of performance enhancing drugs during his time in the Tour de France
  - The lessons he learned as an individual; what he learned about himself and how he treated other people during that time in his life; and how he emerged on the other end of that
- It’s a story about redemption, a rise, a fall, and a rise again
- For Lance, being back in Austin, TX is surreal
  - For 30 years he’s seen it change as a cyclist; it’s a great city
  - Peter and his wife love it here too

> “So I think cyclists see more stuff than most people. You’re always covering ground. You’re finding back roads. You get a sense for a town growing.” – Lance Armstrong

## What everyone wants to know—yes and no questions [2:15]

> “I think it’s just sometimes easier if we can get into some hard yes and no questions, just so that there’s no ambiguity about some of the really important stuff.” – Peter Attia

- Is [Dura Ace](https://road.shimano.com/dura-ace/) better than [Campy Super Record](https://www.campagnolo.com/US/en/Groupsets/super_record_groupset)?
  - Yes
- Is the greatest innovation in time trialing the aerodynamic water bottle?
  - No
- Is Edgar Allan Poe the greatest poet of the 19th century?
  - Sure
- Are today’s clinchers as high performing as tubulars?
  - Yes
- Is Alberto Contador the greatest cyclist of all time?
  - Absolutely not
- Can you still ride up [Alpe d’Huez](https://en.wikipedia.org/wiki/Alpe_d%27Huez) in under 45 minutes?
  - Probably not
- Is the 1985 Oakley pilot big ass sunglass the greatest shades of all time?
  - No
- Is [Pinarello](https://en.wikipedia.org/wiki/Pinarello) the best bike on the market?
  - No
- Is [George Hincapie](https://en.wikipedia.org/wiki/George_Hincapie) the best lieutenant you’ve ever had?
  - Absolutely
- Was your grandfather the first man to ride his bike on the moon in 1969?
  - No

## Lance’s childhood and beginnings of a great athlete [4:15]

**Lace grew up in** [**Plano, TX**](https://en.wikipedia.org/wiki/Plano,_Texas)**, a Northeast suburb of Dallas.**

- Pretty much straight north
- It lives up to its name
- Plano is Spanish for flat, plano; very flat, very windy
- It’s another community like Austin that’s drastically changed
- When Lance was a kid growing up in Plano he would leave the house and be out in the fields
- He would head up into Allen; or go around Lake Lavon, or Frisco
  - Frisco is one of the fastest growing communities in America; There was only one building out there, and that was the global headquarters for [EDS](https://en.wikipedia.org/wiki/Electronic_Data_Systems)
  - People thought [Ross Perot](https://en.wikipedia.org/wiki/Ross_Perot) was nuts to build the EDS headquarters there
  - Lance’s Mom is still there, so just going back is crazy
- He takes his bike everywhere
  - He’ll just kind of ride around and go past Dooley Elementary where he went to middle school, and he’ll go to his elementary school
  - He’ll just go by these places and just look at them through a 50 year old’s eyes.
- Peter asks if going home is bittersweet, because he hates seeing where he grew up; the last time he looked at his elementary school it upset him so much
  - No; one is allowed to sort of hate where you grew up
  - I don’t want to live there, but it’s fine to go back and see Mom

**Lance’s father**

- Peter asks about Lance’s birth father, Eddie Gunderson; did he ever see him after he left his mom when Lance was 2
  - Lance never saw him again and he passed away several years ago
  - From what he heard, his biological father died of a spider bite; maybe that led to some other complications
  - He never had a desire to sort of reconnect with him for most of my life
  - He might have a different view of that now
  - His biological father never reached out to him directly
  - After the first Tour (in ’99) the press interviewed him and his stories were just totally inappropriate, he made comments about my mom that far down the road
  - Eddie made disparaging comments about Lance’s mom
  - He wasn’t a road scholar
- Lance was 3 or 4 when his mom met and then married Terry Armstrong
  - That’s where the name comes from; he wasn’t born Lance Armstrong

> “Funny thing is my initials would have been LEG, if I would have stayed Lance Edward Gunderson” – Lance Armstrong

- Peter remembers stories Lance has told in the past about Terry and  how strict he was; he asks if Lance thought of him as a father
  - Oh sure; as a five, six, seven-year-old kid, he didn’t know
  - He had his mother, he knew Terry wasn’t his biological father but they were a family and his mom seemed happy
  - He wasn’t violent, just strict
  - Every little thing could get Lance in trouble
  - If he left his drawer open it would be a big deal to Terry
    - For Lance, he wouldn’t care if his kid left a drawer open

**Sports, swimming, triathlons, then cycling**

- At 12 years old, Lance played every Texas sport every kid does, but didn’t shine in any of those things
  - He wasn’t good at mainstream sports
- His Mom put him in swimming
  - She knew her high energy kid needed something constructive to do; she was right
  - He didn’t know much about it but picked it up fast
  - He had a few friends on the swim team and so was open to try it
  - It was an age group team
- There are different categories; the most serious is age group swimming That’s where Michael Phelps grew up swimming
  - On one end of the spectrum is country club summer leagues
  - One swims some laps, has a few meets, all the parents are there
  - There is high school swimming
  - Then, the most serious training is age group swimming
- At 12 Lance didn’t know how to swim
  - He could have faked freestyle but didn’t know any strokes
  - He showed up and the coach stuck him with the six- and seven-year-olds
  - Thinking back, he never questioned it; he just stayed swimming
  - After a month of that, he moved over a lane and was with the 8-year-olds; then a month later he moved over again
  - He just kind of kept going across the pool until less than a year later, he was a legit swimmer
  - It’s still one of his great loves
- Peter asks if he is swimming for both high school and age group competitions
  - Yes and no
  - He turned pro in triathlons at 15
- His swim coach at the time, a total hardass but an amazing coach (Chris McCurdy)
  - One did not miss a workout
  - There were no excuses: holidays, family, doesn’t matter
- His age group team was COPS (City of Plano Swimmers) which was, at the time, one of the best age group teams in the country
  - That was because McCurdy
- Lance started traveling to triathlons and skipping workouts because he was on a ride or a run; McCurdy wasn’t having it at all
- Peter asked if Lance gravitated to the mile in swimming
  - Lance is an endurance guy; he doesn’t have great fast twitch muscle
- His 100 freestyle swim… the mile is 16 and a half of those; he doesn’t remember his time
  - In state championships one year, he got third
  - He was decent but wasn’t going to the Olympics
- He would have swam in college if he stuck with just swimming
  - If you asked McCurdy, he thinks I could have gone far
- Peter asks “*When did you realize you also had a knack to run and bike*?”
  - Lance was running right around the same time as swimming
  - Running track and cross-country in high school
  - Plano city champ at one point; it wouldn’t have been the mile, maybe the 1200
- Back then, event timing was primitive
  - Timers had stopwatches, one per athlete and when you came across the line they’d ask your name
  - One time, Lance came across the line and the timer says, “What’s your name?”
  - He was going to Armstrong Middle School, so he said, “Armstrong”
  - The timer said, “I didn’t ask you what school you went to. I said what’s your name” Lance finally, after three or four go arounds, explained, “I’m Armstrong from Armstrong”
- He was a decent runner.

**Peter Attia asks if he enjoyed training at that age**

- Lance loved it; he loved the structure
- Coach McCurdy had this board
  - He must have laid awake every night and dreamed up these workouts; it was so detailed
- Lance loved it; it was the most structure he had.
- Running with the cross-country team also had structure
- He had another great coach in track and cross-country named James Maize
  - James Maize was a world class 800-meter runner
  - He was actually the rabbit for the dream mile, and this guy ended up being Lance’s high school track and cross-country coach; he was awesome
  - He’d run with us; he drove a Porsche; kids were like, “Holy shit, our teacher. Who is this dude?”
- At the time, cycling was just go pedal around, no structure, only group rides



## Lance’s realization that he had a knack for racing after his first pro race at age 15 [13:00]

- Peter asks when it became clear that Lance had a knack for triathlons
- Was it the [race](https://www.everymantri.com/everyman_triathlon/2009/08/watch-lance-armstrong-race-ironman-champ-mark-allen-back-in-the-day-at-bermuda-triathlon.html) everybody talks about where Lance (at age 15) was in the front with [Mark Allen](https://en.wikipedia.org/wiki/Mark_Allen_(triathlete))?
  - At the time, Mark Allen must have been one of the top three professional triathletes in the world
  - That was Lance’s first pro race, the President’s Triathlon in Dallas.
  - That would have been ’87
- He did the President’s in ’86, out at Lake Lavon; it was a longer distance, and then they moved it over to Las Colinas, where the old Cowboys facility was in ’87, and they made it an Olympic distance
- Lance was training with some guys, and they said, “Look, you should just turn pro and go try it”
  - He was 15 years old; he was swimming my ass off; he was a great swimmer
  - He came out at 15 and knew he was going to come out of the water with the leaders
  - He’s coming out of the water under 20 minutes easily
  - And then he hops on the bike; the bike section is around 55 minutes
    - This is pre-aero bars
  - Although, that might have been the year that Andrew MacNaughton flew away on the bike
    - He had the original Scott aero bars
  - Lance rode with Allen the whole time on the bike
  - These athletes all raced each other every weekend
- Peter asks if [Dave Scott](https://en.wikipedia.org/wiki/Dave_Scott_(triathlete)) was there too
  - Lance doesn’t remember
- Peter remarks that [Mike Pigg](https://www.triathlon.org/news/article/20_years_of_itu_world_cups_a_q_and_a_with_mike_pigg) would have been there
  - Pigg would have been there
  - I’m sure Pigg was looking at Lance thinking, “Who the fuck is this person, this guy, this kid?”
- A guy like Mark Allen, get off and run 32
- Peter asks if Lance would run a 36 after that
  - No, probably 38 or 39
- Lance thinks he ended up fifth or sixth, and thought “Okay, I can do this”

**Peter asks if the bike is different compared to swimming and running?**

- The experience was certainly different
- People don’t really appreciate how much time swimmers devote to their sport, and how much distance they cover
- At age 13, 14, 15, training involved swimming 10 miles a day
- That’s a 5:30 AM morning practice for an hour, and two hours in the afternoon
- You’re covering some ground; staring at the black line the whole time
- That’s why swimmers are crazy
- If somebody said they run 10 miles a day, Lance would say, “You are a fucking badass”
- The funny thing, most people don’t appreciate that the swim to run ratio is about 4:1
- To swim 10 miles a day is comparable metabolically to running 40 miles a day
- Without the impact; there’s no impact in swimming
- This makes it a great sport as you get to be older

> “The thing I love about swimming is you can swim your whole life. You can’t necessarily ride your whole life. You certainly can’t run your whole life.” – Lance Armstrong

## The move to cycling full time and a desire to compete in the Olympics [16:30]

**Full time cycling and desire to go to the Olympics**

- Lance realized his quickest path there is probably going on the bike
- He started to transition to full time cycling in ’89
- Still competing in triathlons in ’89 and ’90
- Went to the Junior World Championships in Moscow in 1989
- At the time, he assumed triathlon would be an Olympic sport
  - It is the ultimate sport
- The best sports in the Olympics are swimming and cycling and running
  - This is in the late ’80s, early ’90s.
- Triathlons wouldn’t be in the Olympics wouldn’t be until 2000, Sidney

**Beginning of his cycling career and the 1992 Olympics**

- Lance switched over to full time cycling in 1990/1991
  - Pretty amazing considering he won the [1993 UCI Road World Championships](https://en.wikipedia.org/wiki/1993_UCI_Road_World_Championships) in Oslo, Norway

*1992 Olympics*

- Prior to Oslo race, Lance fulfilled his Olympic dream by going to the [Barcelona games in 1992](https://en.wikipedia.org/wiki/1992_Summer_Olympics) [00:17:29]
  - Competed in the [individual road race](https://olympics.com/en/olympic-games/barcelona-1992/results/cycling-road/individual-road-race-men), finished 14th
  - There were maybe 3 or 4 cyclists from the US competing
  - There were no pros; pros were added in ‘96
- Peter asks who the best amateurs were then
  - [Davide Rebellin](https://en.wikipedia.org/wiki/Davide_Rebellin); [1992 olympics cycling results](https://en.wikipedia.org/wiki/Cycling_at_the_1992_Summer_Olympics_%E2%80%93_Men%27s_individual_road_race)
  - The Italians were amazing, [Casartelli](https://en.wikipedia.org/wiki/Fabio_Casartelli) won the men’s road race in the ’92 Olympics
  - [Erik Dekker](https://en.wikipedia.org/wiki/Erik_Dekker) was on the Dutch team
  - [Erik Zabel](https://en.wikipedia.org/wiki/Erik_Zabel) was on the German team
- What was that like competing against the best amateur cyclists in the world?
  - It was great.
  - Tactically, Lance was still trying to figure out cycling
  - He didn’t know how to move through the Peloton and gauge the flow and tactics of the race
  - Now he takes that for granted; he could find his way around any race
  - He couldn’t draft at the time in ’90, ’91
  - You shouldn’t be able to draft in a triathlon

> “I got in a bunch of grief once because I called the part of triathlon a shampoo, a blow dry, and a 10K. But anyways, it’s an individual sport.” – Lance Armstrong

- His cycling career as a cyclist began two years before the Olympics
- But all the training he was doing as a triathlete prepared his cardiovascular system and fitness, but not bike handling skills, tactics, or other things
  - He had rode enough that he was comfortable in the Peloton and had bike handling down
  - Understanding the movements of the race and positioning, that took a few years

## Metrics tracked early in Lance’s career and his time with Motorola team [20:00]

**Metrics cyclists used in 1990**

*Did they track heart rate?*

- Not even, says Lance
- When riding for Motorola (1992-1996), they began tracking heart rate with the earliest tools when they sponsored by [Polar](https://www.polar.com/us-en/products/accessories?gclid=CjwKCAjw7fuJBhBdEiwA2lLMYWQUt6byqR0uxCmoIhdv8pUWW3BrYfThEeBBIgF9aVp6IhXIkv1c_xoCwtsQAvD_BwE#pf6=1)
  - Early heart rate monitors were massive, they looked like bricks
  - No power meters; no testing; just looked at the heart rate
- Peter asks if Lance had any metrics or insights into his physiology being unique at the time
  - No, that was later

> “I don’t remember which time trial it was you were telling me about in one of your tours, that you were able to hold a heart rate of 200 beats per minute for the entire TT.” – Peter Attia

**When Lance realized he had a special “engine”**

- The first time Lance really thought he had an engine, so to speak, was when he was doing a study at the [Cooper Clinic](https://www.cooperaerobics.com/Cooper-Clinic.aspx) in Dallas – he was 15 years old at the time
  - It was a treadmill test
  - It was all about core temp
  - He did a running VO2 test and killed it
  - Doesn’t remember his VO2 max then but the person administering the test was like, “Okay, this kid’s special”
    - They wanted him to come back the next week to do a core temp study using an anal probe
    - Lance is 15 and the idea of using this kind of probe is terrifying; he never went back
    - He knows he runs hot

**The Motorola cycling team – 1992**

- At [Motorola](https://en.wikipedia.org/wiki/7-Eleven_(cycling_team)) he was the only amateur on the team
  - [Steve Bauer](https://en.wikipedia.org/wiki/Steve_Bauer) was on the team as was [Phil Anderson](https://en.wikipedia.org/wiki/Phil_Anderson_(cyclist)) and [Andy Hampsten](https://en.wikipedia.org/wiki/Andrew_Hampsten)
  - Peter recalls Steve Bauer was the reason a kid like him, growing up in Canada, was obsessed with cycling

> “So, I was one of like 12 people in North America that loved cycling, followed it. Because Bauer won a silver in ’84 at the Olympics. So basically, I’m 10 or 11 years old. That puts cycling on the map as something that’s awesome” – Peter Attia

- The [1989 Tour](https://en.wikipedia.org/wiki/1989_Tour_de_France) was unbelievable with [Greg LeMond](https://en.wikipedia.org/wiki/Greg_LeMond)
  - Some would argue the greatest ending to a tour
  - Maybe second greatest after what happened last year

[*1993 UCI Road World Championships*](https://en.wikipedia.org/wiki/1993_UCI_Road_World_Championships)

- The [’93 season](https://en.wikipedia.org/wiki/1993_Tour_de_France) has a guy named [Miguel Indurain](https://en.wikipedia.org/wiki/Miguel_Indur%C3%A1in), who’s come along and dethroned Greg LeMond
  - At this point, Indurain has won three consecutive tours, ’91, ’92, ’93.
  - This is one of the guys Lance was racing against for the World Championship in the road race
- The way the season was structured then, the Worlds was much earlier
  - It was four or five weeks after the tour
  - Was it before the [Vuelta](https://en.wikipedia.org/wiki/Vuelta_a_Espa%C3%B1a)?
  - No, back then, the Vuelta was early in the season
  - The Vuelta was before the [Giro](https://en.wikipedia.org/wiki/Giro_d%27Italia)
  - The Vuelta was minimized, but we had a true World Cup
  - There was all the monuments, all the big spring classics
  - Then, every week after the tour
    - There was [San Sebastian](https://en.wikipedia.org/wiki/Cl%C3%A1sica_de_San_Sebasti%C3%A1n)
    - [Zurich](https://en.wikipedia.org/wiki/Z%C3%BCri-Metzgete)
    - [Leeds](https://en.wikipedia.org/wiki/Wincanton_Classic) in England
    - It was like boom, boom, boom
    - Lance loved the rhythm of that calendar after the [Tour of ’93](https://en.wikipedia.org/wiki/1993_Tour_de_France)
      - He won stage 8 of the ’93 Tour
      - He was pulled out because he was young
  - His form kept improving
  - He was there, at all the prep races; he knew he was going to be in the front group
  - He was riding with greats: [Olaf Ludwig](https://en.wikipedia.org/wiki/Olaf_Ludwig), [Indurain](https://en.wikipedia.org/wiki/Miguel_Indur%C3%A1in), [Chiappucci](https://en.wikipedia.org/wiki/Claudio_Chiappucci), [Tchmil](https://en.wikipedia.org/wiki/Andrei_Tchmil), [Museeuw](https://en.wikipedia.org/wiki/Johan_Museeuw), [Riis](https://en.wikipedia.org/wiki/Bjarne_Riis)
    - People were crashing everywhere
    - Lance crashed twice
    - It was cold, in the ’50s; Northern Europe

*Peter asks Lance to explain what it means to win that race, to be the world champion*

- You get to wear a special jersey that nobody else gets to wear for a year
  - You wear the rainbow jersey for a year
  - Then for the rest of your career, you have some representation on your jerseys or shorts of rainbows on the sleeves, the collar
  - It’s a cool race to win

![](https://peterattiamd.com/wp-content/uploads/2021/10/rainbow-jersey.jpeg)

**Figure 1. UCI rainbow jersey.** [[source](https://www.pinterest.fr/pin/307863324512445069/)]

**State of performance enhancing drugs in 1993**

- Peter asks about the [1993 Tour](https://en.wikipedia.org/wiki/1993_Tour_de_France): “you’ve in the past said that was in the era when you and your team were still in the low octane phase of things, right? The cortisones, things like that. But, it was the pre-EPO era, even though [EPO](https://en.wikipedia.org/wiki/Blood_doping#:~:text=Erythropoietin%20(EPO)%20is%20a%20glycoprotein,for%20erythropoiesis%20in%20bone%20marrow.&text=Because%20of%20its%20physiological%20side,by%20professional%20and%20amateur%20cyclists.) was around.”
  - It was around, but this was before the real shoot out
  - There was buzz o EPO, speculation, scientific articles; but it wasn’t an obsession in ’92-‘93
- Peter asks if it was in ’91 when high octane products became the mainstay
  - Or if it was at the end of Indurian
  - By the time [Bjarne Riis](https://en.wikipedia.org/wiki/Bjarne_Riis) in the [1996 Tour](https://en.wikipedia.org/wiki/1996_Tour_de_France) there was overt use of drugs
- Drugs were in the Peloton in the late ’80s, but that’s really going far back, and nobody from back then is talking for sure
  - There were rumors about [Pedro Delgado](https://en.wikipedia.org/wiki/Pedro_Delgado) – *Didn’t he win the year that LeMond was out, which was* [*’87*](https://en.wikipedia.org/wiki/1987_Tour_de_France#Final_standings)*?*
  - Delgado won the [Tour in 1988](https://en.wikipedia.org/wiki/1988_Tour_de_France#Final_standings)
- About drug use, Greg Lemond could have
  - Indurian was a machine; this guy trained 365 days a year; he could do it all
- It’s not clear when the transition to drug use in cycling was

## The grueling nature of the Tour de France and the beginnings of serious drug usage in cycling [27:00]

**Explain how grueling the Tour de France is**

> “there’s nothing about doing that that is physiologically appropriate or, in any way, shape, or form, promotes a person’s health” – Peter Attia
>
> “A rider at the end of the Tour is probably the least healthy they could ever be. And as a result of that, there’s no era in the history of this bike race where cyclists haven’t turned to substances, and whether they’re banned or not banned is really a semantic point.” – Peter Attia

- In the earliest renditions of this race, riders were using alcohol, traditional painkillers, cocaine, or amphetamines to numb pain
  - Or hopping on trains; grabbing cars; literally being pulled up mountains

**Racing in the early 90’s**

- Lance was tested in [’93](https://en.wikipedia.org/wiki/1993_Tour_de_France) when he won a stage in the [Tour](https://en.wikipedia.org/wiki/Tour_de_France), and also in the [Worlds](https://en.wikipedia.org/wiki/UCI_World_Championships)
- He acknowledges that back then, he was using things like cortisone
  - Was he worried that those things would show up, or were you just making sure that they were out of your system by the time you were racing?
- The way to go about that was just a TUE, a [therapeutic use exemption](https://www.wada-ama.org/en/what-we-do/science-medical/therapeutic-use-exemptions)
- In competition testing, EPO has a half-life of five hour; testing on the day is not going to work
  - This is why out of competition testing began
  - The biggest hammers that have dropped in cycling in and around drugs were not through testing
  - They were through the police
  - Nobody tested positive in the [Festina affair](https://en.wikipedia.org/wiki/Festina_affair)
  - A a dumbass crossing the border, gets pulled over with a car full of stuff; that’s how that happened; the agencies had nothing to do with that
- Peter notes, coming into the ’94 season, Lance has got to be optimistic; he’s the World Champion
- What were the expectations and goals for that season with respect to either single day classics or grand tours?
  - That was an interesting period of time because that is when he basically got his ass kicked that year
  - Lance thought he’d be competitive in every one-day race he started
- Peter Attia asks if he thought: “*I’m going to be on the podium in the Tour in the next three years*“?
  - No; at that time, Lance was fully resigned or committed to the fact that he was a kid
  - He was fully resigned or committed to the fact that he was a kid, classic rider; he was one-day rider
    - His weight was probably 175; he was big
    - He had been a swimmer his whole career
    - A swimmer never loses a swimmer’s body, the back, the chest, the shoulders
    - Was it tough to be a climber at 175?
    - One of the tours he was between 160, 165; still big
    - He was racing [Pantani](https://en.wikipedia.org/wiki/Marco_Pantani) who weighed 125

**The early tours**

- A [one-day race](https://en.wikipedia.org/wiki/Classic_cycle_races) is a race of chance; one has to be fit, but it depends on chance and tactics
  - He made his move in ‘[93](https://en.wikipedia.org/wiki/1993_Tour_de_France) early; he got a gap

> “The big tours were the race of truth, and the time trials are the hardest climbs, those are individual competitions and so there was a tectonic shift from 93 to 94.” – Lance Armstrong

**Performance-enhancing drugs**

- How long did it take to understand exactly what’s happening; this is not about more cortisone; this is not about more testosterone, more growth hormone
- It was all over the press
  - Then the press were friends with the riders; they were all buddies
- People got to [Ferrari](https://en.wikipedia.org/wiki/Michele_Ferrari), his famous quote comparing EPO to orange juice
  - After that it was everywhere in the press, in the peloton
- What happened in the [94 Tour](https://en.wikipedia.org/wiki/1994_Tour_de_France)
  - He got sick halfway through and dropped out

**Fabio’s crash in the ‘95 Tour**

- The [95 Tour](https://en.wikipedia.org/wiki/1995_Tour_de_France)–
  - Lance finished and it’s a tragic tour, [Fabio](https://en.wikipedia.org/wiki/Fabio_Casartelli) is killed

> “Is that a wake-up call to you in any way? Do you realize how dangerous your sport is when you watch your teammates head smashed open on the side of the road?” – Peter Attia

- That was; helmets were not required and very few people wore them
  - Not sure it would’ve helped [Fabio](https://en.wikipedia.org/wiki/Fabio_Casartelli)
    - He really hit his face and basically died right there; it’s just surreal
    - It was a tough mountain day and we were in the group Pareto; we were out there forever
    - We actually got news of his death in the race; it was just so rare; to have it happen to us on our team
    - Fabio was interesting; not your normal Italian; not super serious; he was a jokester
    - He obviously had huge talent and potential; won the [Olympic gold in ‘92](https://en.wikipedia.org/wiki/Cycling_at_the_1992_Summer_Olympics#Men's)
    - He wasn’t adjusting to pro cycling
    - So [Motorola](https://en.wikipedia.org/wiki/List_of_teams_and_cyclists_in_the_1995_Tour_de_France#By_team) picked him up in 95
    - Ironically for the ninth spot, it was down to him and [George](https://en.wikipedia.org/wiki/George_Hincapie) and George was actually there at the start because we would always take 10 guys and then literally the day before the team would decide who the ninth guy was and they decide George was young, but they decided to take Kasser Telly; it was bad
- In the 18th stage that Lance won in Fabio’s honor three days later, when did he realize he was going to win that stage?
  - At the end of the tour, they’re just custom made for breakaways, perfect for the opportunist
  - Lance went away in a group, [Johan Bruyneel](https://en.wikipedia.org/wiki/Johan_Bruyneel) was in that group too, but it was a huge group and that group stays away;. they never get caught
  - Lance just took a huge flyer, with 30, 40K to go; he was flying
  - The director at the time [Hennie Kuiper](https://en.wikipedia.org/wiki/Hennie_Kuiper), who was a legendary Dutch cyclist, he kept coming up and giving him time splits
  - Lance was gaining on the gap
  - He finally asked Hennie to just stay back; he knew he was flying
- Peter asks, “*Did you feel a sense of this was for Fabio, you felt a little extra strength that day.* I mean, I’ve heard so many athletes talk about that when they’re… Damon Hill talking about racing after Senna died later in that season, feeling like he couldn’t just make that car go fast enough. And it’s almost like he looked up to these guys and just asked for somebody to help from him.”

- Lance didn’t really know Fabio
- They were on the team together, but he died in the team colors and that just doesn’t happen
- Lance was just possessed that day

## The impact of EPO on cycling performance [35:15]

- In the ‘96 season, that’s the year started moving into the high octane world
  - No, that was ’95 when Lance joined the Ferrari team
- In ‘95, were you sort of doing freestyle [EPO](https://en.wikipedia.org/wiki/Blood_doping#:~:text=Erythropoietin%20(EPO)%20is%20a%20glycoprotein,for%20erythropoiesis%20in%20bone%20marrow.&text=Because%20of%20its%20physiological%20side,by%20professional%20and%20amateur%20cyclists.), managing it on your own?
  - I think that would be a bad; there was some oversight
  - The doctors would look at the hematocrit level and hemoglobin levels
- Peter asks what is Lance’s normal hemoglobin?
  - It would likely be in the low 40’s
- Lance doesn’t recall exactly where his hematocrit levels got to when using EPO, but suspects it was under 60
  - He said the doctors didn’t seem to have concerns about blood clotting at those levels
  - Lance comments that people on Everest have a hematocrit of 70

> “But enough is enough, right? At some point you’re competitive. You’re at the front of the room. Why do you need to do more?” – Lance Armstrong

- Was there a noticable difference from 1994?
  - Oh yeah; it’s a very effective substance
- Was it being used as often in the one-day races as it was in the grand tour?
  - Yes
  - It would help you on [Paris-Roubaix](https://en.wikipedia.org/wiki/Paris%E2%80%93Roubaix) as much as any race
  - One’s getting 10% more hemoglobin or hematocrit
  - One’s also getting at threshold **10% more power**
- Power meters  – Lance first started using the [SRM](https://en.wikipedia.org/wiki/Schoberer_Rad_Me%C3%9Ftechnik) in ‘98
- Lance’s functional threshold power in 1999
  - Before the [Tour in 99](https://en.wikipedia.org/wiki/1999_Tour_de_France), he tested his FTP on the Madone ([col de la Madone climb](https://www.ultimatefrance.com/road-cycling/south-france/col-de-la-madone))
  - He wasn’t the first to use it; [Tony Rominger](https://en.wikipedia.org/wiki/Tony_Rominger) used it; he had the fastest time
  - How many kilometers is Madone?
    - Was about 30 minutes.
  - What’s the grade?
    - It’s about 7- 8%.
  - What did you average for 30 minutes in 99?
    - 500 Watts when he was about 165 lbs which equals 7 Watts per kilo
      - Peter: “*Are you freaking kidding me? 500 watts for 30 minutes?!*”

## Testicular cancer diagnosis—denial, torturous symptoms, and treatment [38:15]

**Symptoms**

- In the [’96 Tour](https://en.wikipedia.org/wiki/1996_Tour_de_France), you should be in top form and you’re sick as hell, you pull out
- He thought he was just sick
  - He was definitely sick of being there
  - The weather was shit
  - He wasn’t riding that well
  - He was ready to go home.
- When did he notice the testicular pain?
  - Certainly then, but he chalked it up to soreness
  - Sore on every level, to the touch or to sit on a seat
  - He just thought it had to do with sitting on a bike seat all the time
  - Peter remarks this is odd because he’s been sitting on a bike for 10 years at that point
  - Lance admits it’s how he rationalized it
    - He rarely got sick
    - Never thought he would be in this position
    - Even as symptoms became drastically significant, he had an excuse for all of them
- Peter asks if he had any headaches?
  - He had one massive one, right before diagnosis
  - The following day he had blurry vision
- A week later (maybe October 1st) he had an episode where he coughed up blood everywhere
  - He called his buddy, a neighbor who is a doctor, a cosmetic surgeon
  - He looked in Lance’s nose and throat
  - But Lance had rinsed out the sink so the doctor didn’t see the blood or know how much was there
  - They chalked it up to dry sinuses
  - Even still, this scared Lance
- Peter notes that Lance wasn’t putting two and two together – this thing in his testes, the headache, the blood
  - Nope, they weren’t related in his mind
- The next day (October 2nd) he called his doctor friend back
  - The pain at this point was so bad and the testicle was so swollen
  - He said, “listen, there’s this one other thing that just embarrassed or I just haven’t talked about”, his testicle
  - That’s when he drove to see the urologist [Jim Reeves](https://health.usnews.com/doctors/james-reeves-793202)

**Diagnosis**

Peter remarks:

- “*People talk often about when a diagnosis like this has levied on them. They’re not even able to process. What’s being said, like you hear some things, but you don’t hear other things.*”
- Peter remembers experiencing this when delivering this news where you sort of try to talk as slowly as possible. You pause as much as possible. But you realize at the end of that, they probably heard a 10th of what you said.

*What is your recollection of the very first time? Because by this point, they probably had a chest x-ray”*

- A chest x-ray was one of the first things Jim Reeves did
- They also gave him a [TB skin test](https://en.wikipedia.org/wiki/Mantoux_test)
  - He really wondered what that was for
  - He remembers thinking “God, please give me tuberculosis
- He also had an ultrasound performed
  - The lady who did it took forever
  - Then the doctor came in and repeated the ultrasound of his testes and abdomen
- Then they walked in and handed him the file of results and directed him back to Dr. Reeves office
  - It’s late at this point, 6 or 7 PM
  - He knew it wasn’t good
  - He doesn’t remember most of what was said because the doctor didn’t say very much
- Peter asks if at the time it was known if his cancer was [seminomas](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/seminoma); if there was still a window of opportunity for it to be a very curable form of testicular cancer
  - The chest and the chest x-ray was riddled;  there was more white than it was grey
- How long until the [orchiectomy](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/orchiectomy)?
  - The next morning
  - Even though Lance told Dr. Reeves, he feel like I should get a second opinion
    - Reeves said, you have surgery at 7:00 AM tomorrow morning
    - This was in 1996, one couldn’t go home and Google it
- Peter asked when Lance called his mom
  - Right away, when he got home
  - What makes his mom great and strong is she never shows weakness
  - He knew she had moments where she would be sad and upset and worried
  - On the surface she just had this shield like, “Let’s fucking go. We got this. You could do this”
  - She was totally confident
- Peter asks if he understood what the prognosis was at that time?
  - Not really
- Peter notes: “Well, it wasn’t just that it was advanced, right? It was the histology of it. It was not a seminoma tumor, which is at that point is the only testicular cancer that’s curable, right? You had a much more histologically advanced cancer, that [choriocarcinoma](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/choriocarcinoma), which was wildly [metastatic](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/metastatic). What was your [alpha-fetoprotein level](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/alpha-fetoprotein)?”
  - It was elevated
  - [beta-hCG](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/beta-hcg) was the metric monitored most closely
    - It was 100,000.
    - Peter remarks: “So you were pregnant”
    - At 500 there is a problem; anything above 200 is a problem

**Cancer treatment**

- Lance had an [orchiectomy](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/orchiectomy)
  - Didn’t touch the [lymph nodes](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/lymph-node-dissection); didn’t touch the lungs
- Peter asks when Lance knew he had brain metastasis; when was the CT scan?
  - Later, when he went to Indiana
- His first cycle of chemotherapy was in Austin
  - That was traditional [BEP](https://www.cancerresearchuk.org/about-cancer/cancer-in-general/treatment/cancer-drugs/drugs/bep)
  - He did one cycle with [bleomycin](https://www.rxlist.com/blenoxane-drug.htm)
    - A really toxic chemotherapeutic
    - He did 4 cycles in total
  - The first cycle was done in Austin
    - One week on, two weeks off, followed by one week on and two weeks off
    - On that first two weeks he went to Houston to visit MD Anderson
      - MD Anderson had a whole different approach, not bleomycin, not traditional therapy, many different drugs — It didn’t feel right; Lance left
- His oncologist mentioned [Dr. Larry Einhorn](https://medicine.iu.edu/faculty/4942/einhorn-lawrence) in Indianapolis was king when it came to treating testicular cancer
  - A lot of his work really led to platinum based therapies
- Peter asks about his care in Indiana, “did they do the CT scan first? They figured out you’ve got brain metastasis as well. *Is that another, what the hell is going on here? How much worse can this moment get?*”
  - Yes, but it’s a relief because it explains everything
  - He thought this would be the worse part, it wouldn’t get any worse

**Peter asks if he ever thought he might not live**

- Lance said it crossed his mind, but he didn’t dwell on it
- Treatment and testing kept him busy
- He watched his hCG come down
- He kept thinking he was ahead in this game
- Peter asks about the protocol his doctors chose, this other protocol
  - The doctors asked Lance if he wanted to race bikes again and said he couldn’t keep taking bleomycin if he wanted to race
    - Because it’s so pulmonary toxic it’s so cardiotoxic
- People ask Lance “why wouldn’t everybody be treated the way you were treated with a protocol called [VIP](https://www.cancer.gov/about-cancer/treatment/drugs/vip), which doesn’t indicate that you’re a VIP”
  - It’s chemotherapeutics [vincristine](https://www.rxlist.com/vincristine-sulfate-injection-drug.htm), [cisplatin](https://www.rxlist.com/cisplatin-drug.htm), etc
  - The downside to being treated with VIP is you have to stay as an inpatient
    - One of the drugs is so toxic on the body it requires 24/7 hydration
  - With bleomycin, one can go home after 3-4 hours at the chemo clinic

**Brutal nature of chemo**

- Lance still talks to people about this when they about to start chemo
- In cycle one he was like, “Are you sure you did this right? I don’t feel anything.”
- Cycle two he got sick a few times; he felt “Ooh. I think they got it right this time”
- Cycle three, he was sick as shit
- Cycle four he just wanted to sleep
- It just compounds and compounds to get much worse

**Neurosurgery – Peter asks about his recovery like from neurosurgery**

- There were big cuts; tennis ball size

> “Easiest way to describe it for people listening or have never been there, it’s like doing the pumpkin for Halloween. You literally just cut the whole, pull off the thing, dig out the seeds and put the thing back on it. And there were two of them. There was one on the top, one on the back, right on the surface. Dr. Shapiro was my neurosurgeon.” – Lance Armstrong

- When the surgeon pulled that skull off, the tumors there were dead
  - The [blood-brain barrier](https://en.wikipedia.org/wiki/Blood%E2%80%93brain_barrier) should have kept the drugs out; the tumors should not have been dead
- The surgery occurred before half of the chemo was complete
- Lance was kept pretty isolated; he never shared a room; he did chemo alone in his room

## Livestrong is born [50:45]

- Peter remarks: “early on you latched onto an important idea, right… *people need help navigating this system*. You obviously felt moved at a very early point in your disease and recovery to create a foundation that you ultimately would. What do you think was part of the impetus for that in your experience?”
- Lance had a disease that carried with it a huge stigma; he wanted to bring awareness to it
- He thought he would start a bike ride in Austin and get a few people out to donate money

> “We had no plan, but it just felt like the time to do something.” – Lance Armstrong

- Peter asks: “*Was it sort of a pay it forward thing? Like you were just so happy to be alive that you were like, ‘I just have to share some of this’*“
- It began during his treatment
- He wasn’t sure there was going to be a forward
- It’s interesting that the foundation grew to over half a billion dollars
  - That money was very specific, it wasn’t directed towards research
  - Lots of dollars are directed toward research
    - Research is imperative and should be the largest allocation of resources
  - Money is also needed for other things, softer stuff
    - Help for a family that can’t afford the travel for the child with cancer
    - Providing resources for people
- Peter notes that Lance “You inspired a lot of other people like fertility hope and other people to come along and address other problems that just probably didn’t get enough attention”
- [Livestrong](https://www.livestrong.org/) gained a lot of power with the story and the brand
  - In Texas they advocated for a $3 billion bond initiative that created CPRIT, the [Cancer Prevention & Research Institute of Texas](https://www.cprit.state.tx.us/)
  - Livestrong spent about $600,000 on that initiative

## Return to cycling post-cancer and a crossroad in Lance’s career [53:45]

**When did Lance decide to come back?  What was his contract now that** [**Motorola**](https://en.wikipedia.org/wiki/7-Eleven_(cycling_team)) **had folded**

- Lance signed a 2-year contract in ’96 with the French [Cofidis Cycling Team](https://en.wikipedia.org/wiki/Cofidis_(cycling_team))
  - 2 months before he was diagnosed with cancer
  - In the hospital, they sent a representative to see Lance and recommended they part ways
  - This was a million-dollar contract
  - He was with the team for even though he didn’t ride in ‘97
  - His contract wasn’t renewed at the end of ‘97
  - Lance had a disability policy, which typically is for injuries, crashes, anything that makes you disabled enough, you can’t turn the crank
    - Cancer fell under this disability clause; he started to take it
    - He thought this might be his off-ramp for cycling
- In ’98 he went back out to shop teams; there was almost zero interest

**Joining the Postal team**

- [Postal](https://en.wikipedia.org/wiki/U.S._Postal_Service_Pro_Cycling_Team) wasn’t really interested at first
  - Postal was owned by [Thom Weisel](https://en.wikipedia.org/wiki/Thom_Weisel#Professional_sports)
  - Lance was on Weisel’s team before Motorola; he called on that relationship; he had left Subaru Montgomery to go to Motorola and now wanted to go back
- Lance negotiated $200K as a base and performance bonuses, $1000 per [UCI point](https://en.wikipedia.org/wiki/UCI_road_racing_world_ranking#Explanation_of_the_men's_ranking_points_system)
  - A top rider would have thousands of points
  - Potentially millions of dollars; this is what Lance did in ‘98
- He competed in [Paris-Nice](https://en.wikipedia.org/wiki/Paris%E2%80%93Nice#Winners) in [‘98](https://en.wikipedia.org/wiki/1998_Paris%E2%80%93Nice)
  - He quit, came home, and said “Fuck this I’m out of here. I’m not cut out for this.”
  - *What was wrong?*…
    - the weather, the crosswind of the peloton, just didn’t feel strong
  - He pulled over, got in the car, went to a hotel and called Kristin and said “we’re going home”
    - She was supportive, even if she didn’t agree

> “Looking back on it, I was like, ‘Wait, if I was that good then, and I was that sick. All this shit is gone, now I’m going to be like 10 times as strong.’” – Lance Armstrong

**Crossroads in Lance’s career**

- Peter recalls reading [Lance’s book](https://www.amazon.com/Its-Not-about-Bike-Journey/dp/0399146113/ref=sr_1_3?crid=3PW8QGVDVUXHO&dchild=1&keywords=lance+armstrong+book&qid=1631714247&s=books&sprefix=lance+armstron%2Caps%2C184&sr=1-3) and Lance “kind of vacillated back and forth between, I want to ride, I don’t want to ride.
- Part of Lance just wanted to sit around and eat tacos all day and TexMex
  - For about 6 weeks around the April timeframe, Lance did just that
  - Friends had an intervention with him; telling him he can’t go out like this, that he needed to finish the season
  - Lance reluctantly decided to just start riding again — no structure, just riding about 5-6 hours a day
  - Lance’s teammates are racing at that point
  - The team doesn’t care about his performance because they’re not paying anything, basically

*First race after his “time off” and using EPO*

- He competed in the [Tour de Luxembourg](https://en.wikipedia.org/wiki/Tour_de_Luxembourg) and he won (though it was void once it was discovered he was blood doping)
- Went to Germany did another race and won that
  - Note: These are short stage races
- Peter asks if he a has reintroduced EPO at this point
  - “Yes”

*Testosterone needed post orchiectomy?*

- Peter wonders if Lance needed testosterone replacement after his testical was removed:
  - Post orchiectomy, wouldn’t one have had a medical exemption for testosterone?
  - Did he need more testosterone after having a testicle removed?
    - Not necessarily
    - He was producing on the lower end of normal amounts, but it wasn’t a problem
  - Did he ever consider if taking growth hormone or other anabolic agents amplify his cancer?
    - There is no way EPO would have
    - It did cross his mind after his diagnosis but certainly not before
    - He and his trainer [Ferrari](https://en.wikipedia.org/wiki/Michele_Ferrari) never went back to growth hormone or other anabolic agents after the cancer

## Lance’s rise to prominence in the late 90s and the growing use of EPO in the sport [1:00:00]

**Drug use**

- When he came back his mainstay drug was [EPO](https://www.wada-ama.org/en/questions-answers/blood-doping#item-590) and [cortisone](https://cortisone-info.com/en/cortisone-and/sport/)
  - Peter asks about cortisone and is surprised it was that helpful
    - It’s injected intramuscularly
    - It’s helpful to shed weight primarily, and especially as a bulkier guy trying to shed upper body muscle

**1998 season**

- In ’98 Lance finished fourth in “everything”
  - [Vuelta](https://en.wikipedia.org/wiki/Vuelta_a_Espa%C3%B1a)
  - The [World’s TT](https://en.wikipedia.org/wiki/1998_UCI_Road_World_Championships_%E2%80%93_Men%27s_time_trial)
  - The [Worlds Road Race](https://en.wikipedia.org/wiki/UCI_Road_World_Championships_%E2%80%93_Men%27s_road_race)
  - But he got a thousand points UCI points that Tom Wizel had to pay

**Getting ready for the 1999 season**

- He decided to come back in ‘99
  - [He hired Bruyneel](https://en.wikipedia.org/wiki/Johan_Bruyneel)
  - [Johnny Weltz](https://en.wikipedia.org/wiki/Johnny_Weltz) was the director at the time
  - But the team was unorganized, “a shit show”
- Peter remembers ’98; he was in his second year of medical school; he and a group of guys would go riding every Saturday and Sunday morning
  - They were so excited Lance was back
  - They would joke about Go Postal two meanings: cheering for the postal team and then going crazy
- Lance ended up fourth in the Vuelta in 1998
- But Lance said Johnny Weltz was so disorganized and he wouldn’t pay the [soigneurs](https://en.wikipedia.org/wiki/Cycling_team)
  - At breakfast one day the soigneurs were missing — they had walked out because they weren’t getting paid

> “Wait a minute. We are in the middle of a grand tour. We have to have mechanics, soigneurs, what the fuck is going on?” – Lance Armstrong

- *Lance was back in full competition mode, but he wasn’t going to put up with the loss of soigneurs and disorganization*

- - - [Johan Bruyneel](https://en.wikipedia.org/wiki/Johan_Bruyneel) has plans to retire, but Lance got his number
      - Johan Bruyneel wore a yellow jersey in the ‘90’s
      - He and Lance always butted heads racing; he was always at the front of the race
      - Lance called him to see what he would do next; he asked him to come be the director
      - Johan wasn’t interested at first but Lance convinced him

- *People say everyone doped in this era but US Postal took it to an industrial level; it was systemic*

- - [Ferrari](https://en.wikipedia.org/wiki/Michele_Ferrari) was demonized but he is incredibly smart
  - He guided all of Lance’s training
  - [Carmichael](https://en.wikipedia.org/wiki/Chris_Carmichael_(cyclist)) didn’t do anything at this time in Lance’s career; he was just an advisor, friend
    - He was the Olympic coach in ‘92
- Peter recalls Lance saying he had no aspiration of winning the tour
  - That changed when he placed fourth in the Vuelta
  - The first “aha” moment that says, “I could win this thing”
- When Johan finally decided to come and be the team director, he said, “You are going to finish on the podium [in 1999]”
  - Lance said, “You’re crazy; there’s no way” but his confidence said otherwise
  - Getting fourth in the Vuelta equates to maybe top 10
    - Which would have been a great result
    - But Johan was a hundred percent sure of Lance

**1999 season – The Tour de France**

- *Peter asks about the Tour de France: in* [*’98*](https://en.wikipedia.org/wiki/1998_Tour_de_France#Final_standings), [*Pantani*](https://en.wikipedia.org/wiki/Marco_Pantani) *had won; in* [*’97*](https://en.wikipedia.org/wiki/1997_Tour_de_France#Final_standings), [*Ullrich*](https://en.wikipedia.org/wiki/Jan_Ullrich) *won; how much time did he spend riding alongside those two?*

- - - In the grand scheme, not much
    - Did he have a sense of how he’d stack up against them?
      - He had never competed in a grand tour at his peak form when they were in their peak form
    - Neither Pantani or Ullrich rode in the [’99 Tour](https://en.wikipedia.org/wiki/1999_Tour_de_France)
      - [Pantani was expelled](https://en.wikipedia.org/wiki/Marco_Pantani#1999:_Expelled_at_Madonna_di_Campiglio) at the [Giro d’Italia](https://en.wikipedia.org/wiki/1999_Giro_d%27Italia) over a hematocrit test
      - [Jan Ullrich](https://en.wikipedia.org/wiki/Jan_Ullrich#1998_Tour_de_France) had an injury and didn’t ride in the ’99 Tour
  - At the ’99 Tour, the two best tour riders are not there, the two previous winners
  - Lance remembers watching the prologue
    - It’s not a long stage; it’s an eight and a half kilometer time trial
    - They don’t always include it in the tour anymore which Lance disagrees with
    - It’s the best way to start the Tour

- *The prologue allows the rider, especially the GC guys, to really test their condition, not just their own, but against the other guys*

- - One can put 30 seconds in a climber, 30 seconds is 30 seconds
  - This was a tough one; it had a serious climb sort of halfway through, enough to make some separation

> “There are certain things that the Tour de France should always have. It should always have a prologue. It should always have a team time trial.” – Lance Armstrong

- *Lance wins the* [*prologue*](https://en.wikipedia.org/wiki/1999_Tour_de_France,_Prologue_to_Stage_10#Prologue) *in the ’99 Tour, easily*

- - His first [yellow jersey](https://en.wikipedia.org/wiki/Yellow_jersey_statistics)
  - It was a dream

**Performance-enhancing drug use [1:07:00]**

- Peter asks “Now, remind me in that tour, you were not using blood transfusions. It was all EPO. You didn’t microdose. You were just giving straight regular doses. This is before they had a test for EPO.”
- Yes, the only thing they had was the hematocrit test
  - Lance stayed around 46, 47; a hematocrit of 50 would have been too close to a red flag if one were to get tested
  - In the [’96 Tour](https://en.wikipedia.org/wiki/1996_Tour_de_France), [Riis](https://en.wikipedia.org/wiki/Bjarne_Riis) won and his hematocrit was somewhere between 60 and 66
    - He had the nickname Mr. 60
- Peter asks what changed: Was it Festina in 1998 that basically brought the hammer down and said, “We’re done with these guys walking around with hematocrits in the 60’s””
  - Yes
- How much of a difference is a hematocrit of 42 or 44 compared to 46, 47?
- Generally, this is most helpful at the end of the tour when the hematocrit would start to dwindle

- Transfusions came in as a way to get around the hematocrit test
- Peter asks if there way anybody on the Postal Team that year not doing EPO
  - No, not that Lance was aware of
  - Not everyone on the team was seeing Ferrari, but there were other trainers and doctors
- Peter asks if this was the year [Motoman](https://road.cc/content/news/68911-lequipe-names-c%C3%B4te-d%E2%80%99azur-bike-shop-owner-motoman-who-delivered-epo-lance) was going around
  - Yeah, it was ’99
  - Lance doesn’t know if that was a great idea; it was fucking crazy

**1999 Tour de France**

- [1999 was the year](https://en.wikipedia.org/wiki/1999_Tour_de_France) that Lance not only won the Tour de France, but each of the 3 individual time trials as well
  - He won the prologue, stage 8, & stage 9
    - The time trials were long then
    - 55, 60 K
- Peter asks “You win that year, do you think to yourself, Ullrich wasn’t here, Pantani wasn’t here. Can I win this thing when they’re both there?”
  - Lance agrees but says not to minimize the other great riders
  - Not to mention, that big crash early in the race, [Zülle](https://en.wikipedia.org/wiki/Alex_Z%C3%BClle) lost seven minutes;  he was close in the race
    - He was within about a minute
    - It would have been close
  - Even with Pantani and Ullrich out, there was still Zülle, [Escartín](https://en.wikipedia.org/wiki/Fernando_Escart%C3%ADn), [Olano](https://en.wikipedia.org/wiki/Abraham_Olano)

**Scrutiny over drug use**

- Peter notes: “We almost take it for granted now, but at the time, how much scrutiny was there over your performance that year”
  - A lot
  - That was the year of cortisone

> “It was the year after Festina. The Pope could have won the tour and they would have questioned it.” – Lance Armstrong

- Prior to this he wasn’t in the hot seat; nobody really cared because he wasn’t winning
- Peter asks where the posture of his denial came from; in retrospect was there another way to deny without attacking
  - In the press conferences, the questions felt like an attack
- Peter asks “What did your teammates say? Did anybody pull you aside and say, “Lance, you got to back this down, man.””
  - No, but they wouldn’t have
  - Johan was like a brother; he would do the same thing
- Who else knew at the time? Lance’s wife?
  - He didn’t share this information
  - He never had that conversation with his wife, though he couldn’t keep it a secret from her
    - All the wives thought it was part of the job; they knew
  - Not even his mom knew; she never asked

## Racing in the early 2000’s, blood transfusions, and rivalry with Jan Ulrich [1:12:00]

**Cycling legends**

*In 2000, what happened with* [*Ventoux*](https://en.wikipedia.org/wiki/Mont_Ventoux) *and* [*Pantani*](https://en.wikipedia.org/wiki/Marco_Pantani)*?*

- Lance wanted to give him the win
  - This is one of the biggest regrets of his career.
  - [Merckx](https://en.wikipedia.org/wiki/Eddy_Merckx) called him and said, “You don’t ever gift the Ventoux, ever.”
  - Lance knew he was going to win the tour so he was trying to be gracious
  - In hindsight, the Ventoux is not something you just give away
- Peter asks “*Is Merckx the greatest cyclist of all time?*” –
  - Of course, but the sport is so much more specialized now
    - Today he would focus on the grand tours
    - The sport is very different now
  - [Half man, half bike](https://www.amazon.com/Half-Man-Bike-William-Fotheringham/dp/1613747268/ref=sr_1_2?dchild=1&keywords=Half+man%2C+half+bike&qid=1631725839&sr=8-2) is a biography of Merckx, Peter loves this book
    - Lance gave him one of the most amazing gifts ever, this book; it’s on his coffee table now
    - It’s an unbelievable story
    - One can’t really understand what he did; what does it mean to win five Giros, five Tours, every single day classic, the one-hour record; it just doesn’t make any sense

*Jan Ulrich*

- [Jan Ullrich](https://en.wikipedia.org/wiki/Jan_Ullrich) got second in the [2000 Tour](https://en.wikipedia.org/wiki/2000_Tour_de_France)
- Peter asks if his respect and love for Jan begin in the 2000 Tour
  - It was more intense; he viewed him as a enemy and rival
    - He was convinced that Ullrich was the most talented
    - When it was pouring down rain and there was a 5 hour ride scheduled, it was the thought of Ullrich that got him out there
    - No one inspired him like Jan Ullrich

**2001-2003**

Peter asks about his biggest memory from ’01 and ’02?

- Lance says 2001 was physically his best tour
  - ’01, everybody refers to it as, “[The look](https://www.yahoo.com/now/lance-armstrong-jan-ullrich-tour-181624028.html)“; racing Ullrich up Alpe d’Huez
- Peter asks “What was your time or what was your wattage up [Madone](https://www.ultimatefrance.com/road-cycling/south-france/col-de-la-madone)?”
  - 500 Watts
  - Peter: “500 Watts for 30 minutes??”
  - Lance: “Yeah, and loving it”
  - Without EPO it would have been 450
    - EPO adds 10%
    - 450 is still pretty good by the way
    - Yeah. I mean, look, [Bradley Wiggins](https://en.wikipedia.org/wiki/Bradley_Wiggins) probably put out 450, 440-450 during his one hour record – very impressive

*“The Look” in 2001*

- In the climb up [Alpe d’Huez](https://en.wikipedia.org/wiki/Alpe_d%27Huez#Cycle_racing) in ‘01 Lance turns and gives “The Look” — people thought he was staring down Jan Ulrich
  - But… he wasn’t looking at Jan
  - Lance was about to “send it” but he wanted to see if his teammate was near by
  - Lance was looking for a teammate to bail him out if it didn’t work

![](https://peterattiamd.com/wp-content/uploads/2021/10/the-look.png)

**Figure 2.  “The look” on the climb up Alpe d’Huez.** Image credit: [Club Lexus](https://www.clublexus.com/forums/the-clubhouse/171923-lance-armstrong-about-to-finish-on-top-2.html)

**EPO/blood doping and tracking hematocrit levels**

- In ’03 was there a worry that red blood cells are pretty depleted
  - Lance had a huge crash in the Dauphiné, right before
  - One couldn’t take EPO during competition
  - He took EPO out of competition; then Ferrari had them switch to transfusion
  - After ’99 he never did EPO on the tour.
  - His hematocrit at the beginning of ’03 was 38 at pre-race check
- Peter remarks “Oh, I didn’t realize that. I thought that happened in ’02. So you’re saying, from 2000 on it was two bags during the race?”
  - No, the first year was 2000; we did one bag halfway through the Tour
  - So that first day at [Hautacam](https://en.wikipedia.org/wiki/Hautacam), that was with nothing that was before the bag
- How are they not catching the jump in hematocrit that comes with the transfusion?
  - One day hematocrit is 41 and the next day it’s 47
  - Surprising that this wasn’t caught
- Peter asks how close Lance was to understanding the UCI algorithm for testing?
  - Lance says there is a lot of bullshit out there
  - Yes, the pillars are true, but most of it is just total bullshit
  - For instance, a month ago, there was a 30 minute program on French TV, convincing themselves that they had figured out that I had an engine in my bike
    - Saying the switch was in the shorts
    - Fortunately he has gotten himself to a point in life where it’s like, “whatever”

**Glorious competition with Jan Ullrich**

- - The last time trial in [’03](https://en.wikipedia.org/wiki/2003_Tour_de_France), Lance and Jan were really close.
    - Yeah, inside a minute; it might’ve been less
    - The fear or the stress around it was not so much
    - The bigger stressor was in the first time trial
      - He was maybe 2 minutes ahead; in the first stage
      - Now he’s thinking he has 45 seconds
  - That’s when his hematocrit 38.
  - It was pouring rain
    - He put six seconds on me in the first kilometer; unbelievable
      - Johan didn’t tell him that stat
  - The time trial was 50 K, 50-ish?
  - Peter asks if he felt redlined
    - Oh yeah. It was terrible.

- *Peter asks if they were using power meters at that point or mostly heart rate*

- - Didn’t race with power meters
  - Trained a hundred percent of the time with them
  - Just monitoring heart rate during the race
- Peter asks about the [Ulrich’s crash](https://en.wikipedia.org/wiki/Jan_Ullrich#2003_Tour_and_sportsmanship)
  - They told him right away
  - Johan was watching the race on TV in the car, as he’s driving, and then I knew, and it was over

**‘03 Tour de France**

*Avoiding the Beloki crash*

- The other thing about [’03](https://en.wikipedia.org/wiki/2003_Tour_de_France#Race_overview) was [Beloki](https://en.wikipedia.org/wiki/Joseba_Beloki), right?
- How did Lance avoid that [crash](https://www.youtube.com/watch?v=sVAKU2LCygc)?
  - That’s one of the things from the tour that Lance gets asked about the most, riding through a field
  - It was incredibly lucky
  - Very unlucky for Joseba Beloki
    - He’s leading, flying downhill, it’s a hundred degree day, it’s bad patched roads, the tar was literally boiling
    - Tire caught some hot tar and just blind-sided him and ruined his career, ended his career.
  - Lance had a choice, stop or go left
- He was going 40 mph
- He went left, rode through a field, then had to get off the bike and jump down on the road

> “There was a path. What are the chances? There was a path into the field where the farmer would go in and out with his tractor. What are the chances?” – Lance Armstrong

- The field is dry, the crop is sharp; he hopes he doesn’t get a flat
- At the other side, he sees the road is way down and decides to get off the bike

*The other* [*famous crash*](https://www.youtube.com/watch?v=sRxGNttpaZA) *in 2003*

- Peter asks about his other famous crash, when his handlebar got caught on a spectator’s bag
  - It was on the [Col du Tourmalet](https://en.wikipedia.org/wiki/Col_du_Tourmalet); his handlebar got caught in a spectator’s bag waving in the air
  - Rather than taking advantage and racing ahead, Jan Ulrich decided to wait for Lance to catch back up
  - He and Jan had established an amazing respect
  - “He’s a total gentleman” says Lance
  - Lance hit the kid’s bag and went straight down, the bike was broken, didn’t know at the time; the whole chain stay was snapped

## Retirement in 2005 and a comeback in 2009 [1:22:45]

- Fast forward to the end of ’05, Lance has won seven and at the time said, “Look, I want to spend more time in the foundation. I want to spend more time with the family.”
- I assume those were the real reasons you wanted to retire.
  - That’s right.
- Peter asks “When you came back, [LeBlanc](https://en.wikipedia.org/wiki/Jean-Marie_Leblanc) wrote an open letter, basically telling you not to, right? What was that about?”
  - Jean-Marie Leblanc was an icon
  - He was a director general of The Tour and he’ll go down as being viewed as one of the greatest directors ever
  - He’s a very, very tough guy; it was his way, or the highway and you just didn’t cross Jean-Marie
  - Lance retires
  - [Landis](https://en.wikipedia.org/wiki/Floyd_Landis) wins, then tests positive

> “It was a Festina-esque moment in time in cycling. And yet another shift to guys looking around and going, “Wait a minute, we might be extinct here if we don’t fucking clean this up.” So the sport was shifting to a better place.” – Lance Armstrong

- Jean-Marie’s point in his letter was, “Look, you are a bridge to the past, right? So the sport has evolved. You are part of the old culture and it’s not good for this.”
  - He was right
  - Lance remembers when he wrote it and they printed it in two big political papers, [LeMonde](https://www.lemonde.fr/sport/article/2005/07/01/lance-armstrong-un-dernier-tour-et-toujours-des-ennuis_668397_3242.html) and Le Figaro
  - At the time he was [Marfa, TX](https://en.wikipedia.org/wiki/Marfa,_Texas) with Anna; one of his favorite places
  - She wasn’t with him when he raced before
  - He saw the letter and said “This is a mistake”, coming back
- Peter asks if LaBlanc called him to follow up
  - Not that he remembers
- Lance felt a ton of responsibility to the foundation
  - The sponsors and foundation was excited
  - It felt like quitting, and he’s not a quitter
- At this point the sport is clean; no one is using anything; he doesn’t need to use anything

> “The comeback years were clean and ironically Ferrari was the one who was adamant. He’s like, “They are coming for you.” We just didn’t cross the line.” – Lance Armstrong

**2009 season**

- In the [’09 Tour](https://en.wikipedia.org/wiki/2009_Tour_de_France#Final_standings), he finishes third, but it wasn’t “close” says Lance
- Peter remembers reading an article in [ESPN magazine](https://www.espn.com/espn/columns/story?columnist=reilly_rick&id=4312289) comparing the ’09 tour to Jordan’s comeback; then they’re like, “well wait until you see Lance in ’10, because that’s going to be Jordan’s ’96.”
- How did it feel after 2009?  Were there thoughts of retirement?  Staying on meant building a new team.
  - That was a big part of it, says Lance, he wanted to build a good team
- At this point Lance is getting “old” for the sport
  - He’s an old man; he was old in ’05 when he was 34 years old and won
  - But this machine was rolling; he wasn’t going to be the guy to say, “I’m getting off the wave here”

**Reservations about his return to the sport**

- Peter asks how much of this comeback was filling a void that said, “I don’t like sitting around and not being an athlete”
  - That’s not the point, says Lance
  - But he did second guess his decision
  - In his life he’s never going back to that place where he thinks “What the fuck am I doing?”
  - The investigation was heating up at this time, so he had to defend his reputation, livelihood, all the while trying to compete in one of the hardest sports in the world
  - He was like “*get me out of here*”

## Lance’s decision to come clean and tell the truth [1:27:30]

“*When did you realize that you had to tell the truth?*” asks Peter

- Either when [George Hincapie](https://en.wikipedia.org/wiki/George_Hincapie) was interviewed or when he went to the grand jury
  - So fall of ’12; or earlier
  - Peter recalls “naively” believing that the sport was mostly cleaned up following the 1998 season
  - Peter didn’t find [Landis](https://en.wikipedia.org/wiki/Floyd_Landis) very believable
  - But Peter’s thoughts started to chance once he heard [Tyler](https://en.wikipedia.org/wiki/Tyler_Hamilton) speak on it
- Tyler wrote a [book](https://www.amazon.com/Secret-Race-Inside-Cover-ups-Winning/dp/0345530411/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1631797597&sr=1-1) with [Daniel Coyle](https://danielcoyle.com/author/) in 2012
  - Peter remarks, when he read it he was like, “This guy is way too freaking believable.” And if he’s saying this, and he’s saying that this is what they were all doing. I believe it.
- Lance notes Tyler had a different version in his deposition in the Postal case, but… when anybody’s deposed and they’ve written a book, they’re just going to read the book
  - If it was in any way contradictory towards him or somebody cared about, then he would blame Dan, the co-author

**Oprah interview**

- Peter asks “You’ve talked about your reasons for doing the [interview with Oprah](https://www.bbc.com/sport/cycling/21065539), which I think make a lot of sense, right? Which is, if you’re going to give a deposition, you might as well do it on your terms.”
  - Looking back, he was convinced that it was the right thing to do
  - The lawyers hated it
- Did any of the sponsors call you to quietly thank you for what you had done over the past 15 years?
  - No
  - In general, did Trek?
    - No.  But if Mike Sinyard from Specialized was asked, he would say, thank you.
    - “All the ships rose.” says Lance

- How Lance talked about this stuff with his kids:
  - What was the discussion like with them?
    - It was an open door policy
    - If anything came up at school
    - Any questions about my life and the decisions I’ve made, we’ll have as many as wanted
    - It is a totally open door
    - They haven’t asked about much
- The family is close – myself, my kids, Anna and Kristin
  - Imagine the Brady Bunch set up, it’s a very close family

*Re-connecting with people Lance implicated or “attacked” when going through this process*

- After the Oprah interview, in early 2013, who was the first person you reached out to apologize to?
  - Actually, before the interview, Lance reached out to [LeMond](https://en.wikipedia.org/wiki/Greg_LeMond)
  - Kathy and Greg wouldn’t take his call
    - They eventually met up, years ago
    - It went better than expected
    - “*I was sincere. I said what I felt like I needed to say; they accepted the apology.*”
  - He met up with Emma O’Reilly in Florida; she was great; her mission was to fix the sport
    - [Emma](https://www.theguardian.com/sport/2014/jul/02/emma-o-reilly-lance-armstrong-cyclist-doping) was his soigneur 99′ and left the team and was a person that he went after
    - She got mixed up in this because of the [L.A. Confidentiel book](https://en.wikipedia.org/wiki/L.A._Confidentiel)
    - She was quoted in it, but it seemed the reason she agreed to talk with David Walsh was really to make a broader statement about how corrupt the sport was
    - Lance enjoyed reforming that friendship and he wrote the foreword for [her book](https://www.amazon.com/Race-Truth-Blowing-Armstrong-cyclings/dp/0593074068/ref=sr_1_1?dchild=1&keywords=Emma+O%27Reilly&qid=1631799182&s=books&sr=1-1); she’s a cool lady
- What about reconnecting with former teammates, [Tyler](https://en.wikipedia.org/wiki/Tyler_Hamilton) or [Floyd](https://en.wikipedia.org/wiki/Floyd_Landis)
  - Those are the two names that stick out
  - The reality is 95% of that former team (the Blue Train) are like brothers.
  - Floyd and Tyler, they were never our brothers; there won’t be any future dinners

## Growth through downfall: learning from his mistakes and helping others after their own fall from grace [1:33:00]

**“T*****here’s a reason the windshield is bigger than the rear view mirror*****“**

- Lance had this in his Twitter bio for a some time (has since been changed)
- But this quote resonates with Peter

> “I always found that to be very poignant because it’s not saying you should only have a windshield and no rear view mirror. And it’s not saying you should have no windshield and only a rear view mirror. It’s saying you need both, but one’s bigger than the other. But in my own life, I’ve always felt like I have to have a rear view mirror. I never want to lose sight of my sins because they kind of ground me.” – Peter Attia

**Facing his sins on a public stage**

- Peter notes: “You’ve had both the luxury and the inconvenience of living all of your sins on the world’s most public stage. So most of us make all of our mistakes behind closed doors and nobody really gets to see the horrible things we’ve done. I remember when I hit the one year anniversary of doing something so awful, I couldn’t stand my existence for it. And I remember talking to my therapist about it and she said, “I actually don’t want you to ever forget this. I want you to remember what you did. You have to remember that the monster that did that thing, he’s never going to die. He’ll sit in the corner. He’ll be small, but he’s never going to die.””
  - You can keep them in a box

*Peter asks if Lance regrets the way he acted, citing the 2005 SCA deposition*:

- Lance says it is embarrassing to watch those videos
- “*That is a pathetic person*”
- As unfortunate and embarrassing and “as tough as they are to watch, for me, those are good”, says Lance

> “*That guy needed to die and a new guy needed to come around.*” – Lance Armstrong

***Lance on whether he would “change” things from his past if he could…***

- One gets stuck by saying they wouldn’t change a thing; but he loves the spot he’s been able to get to
- These events shape the person sitting here today, but Lance admits that there would have been a better way to go about it

*NBC interview*

- Peter brings up an [interview](https://www.youtube.com/watch?v=ac_x4ucbReo) Lance did for NBC
- In the [interview on NBC](https://sports.nbcsports.com/2019/05/29/watch-lance-armstrong-full-interview-with-mike-tirico-video-tour-de-france-cycling/) Lance tried to offer a nuanced explanation for why you wish you didn’t have to hurt people, but you also wouldn’t have done it different in the sense that you needed to learn the lessons you learned
  - Of course, every commenter on YouTube is ripping him apart
  - But one guy writes something that resonated with Peter: “*I was not a good person. And it took losing everything to realize it. I’m not yet at the point where I would not change a thing, but I do get the I can’t change a thing. So it’s useless to feel as much regret and shame as I do. I really believe him when he says that he values the lessons he learned because I do too.* ***I might not be a good person yet, I’m learning, but I’m no longer a bad one*****.**“
  - Peter remembers feeling like when he went through that transition thinking “Okay, you’re not the worst human in the world. You’re not perfect and you’re never going to be.”

**Why Lance may have been vilified more than others**

- - Once it became clear how widespread EPO use was in the peloton, and blood transfusions, and all that stuff; it became very difficult to say, “Well, Lance is a bad guy because he did these performance enhancing drugs.”

- *Lance did them no more, or no less than anybody else*

- S*o why was Lance vilified so strongly? And why were certain cyclists singled out more than others*?

- Is it that he treated people so badly and that’s why Lance is the worst person?
  - But that doesn’t explain to why [Ivan Basso](https://en.wikipedia.org/wiki/Ivan_Basso) did everything that [Pantani](https://en.wikipedia.org/wiki/Marco_Pantani) did; he was loved and Pantani was completely vilified
    - Pantani effectively killed himself
  - Why is the favorite German rider love and [Ullrich](https://en.wikipedia.org/wiki/Jan_Ullrich) rejected?
  - Why is [Vaughters](https://en.wikipedia.org/wiki/Jonathan_Vaughters) loved and [Tyler](https://en.wikipedia.org/wiki/Tyler_Hamilton) gets rejected?
  - Lance is radioactive, but what is the difference between these other guys?
  - Ivan wasn’t beating anybody up; Pantani wasn’t screaming at anybody
  - It’s the same in Spain with [Jiménez](https://en.wikipedia.org/wiki/Jos%C3%A9_Mar%C3%ADa_Jim%C3%A9nez), they had problems handling a difficult situation
  - Why is Jan Ullrich not welcome at the start of the tour? Meanwhile, [Erik Zabel’s](https://en.wikipedia.org/wiki/Erik_Zabel) up there, shaking hands with the guy in the yellow jersey… “this is fucking stupid”
- Peter asks Lance, “*D​​o you have any idea why that hypocrisy exists?*”
  - Pantani was the biggest athlete in Italy; Jan was the biggest athlete in Germany; Lance was the biggest athlete in the US, etc.

> “Maybe it has to do with those heights and the only place you can end up is the complete opposite, the bottom of the pool.” – Lance Armstrong

- *Lance dealt with things differently*

- But look at all the dead cyclists: Pantani, Jiménez, [Vandenbroucke](https://en.wikipedia.org/wiki/Frank_Vandenbroucke_(cyclist)), [Gaumont](https://en.wikipedia.org/wiki/Philippe_Gaumont)
  - All these guys were at the top of the game and then **couldn’t handle their own fall from grace**
  - Jan Ulrich almost dies as well

***Peter asks when he realized Jan was in trouble?***

- Jan has always liked to have fun, but this didn’t look like having fun
- One of Jan’s closest lieutenants when he was competing with Lance was [Andreas Klöden](https://en.wikipedia.org/wiki/Andreas_Kl%C3%B6den), who ended up being on Astana with us and RadioShack
- Lance got to know and love Kloden
  - He heard a lot of these guys (Klöden, Zabel, Danilo Hondo) had tried to reach out to Jan
- It was in the press, Jan got in a fight with his neighbor
- Jan turned everybody away and not just turn them away, but just flat out erased them from his life because he didn’t want to hear it
- Two guys, German brothers, Frank and Mike Baldinger; normal guys, not professional cyclists, not rich or famous contacted Lance
  - They told him how Jan has turned all his friends away and Lance was their last hope
  - That’s when Lance went to see Jan
  - Jan was a mess, unrecognizable; “*like an alien has entered his body*”
- Now Jan is two years sober; he’s got his kids back in his life; he’s on the bike

> “It’s amazing to me how our society, I can’t understand it, why we sometimes lift people up and then find such joy in watching them crash.” – Peter Attia
>
> “The one thing I said to myself. I said, “Just whatever you do, just do not. I mean, you can go have fun and do some crazy, but don’t you ever lose contact with your health, your wellness, your fitness, your family, don’t ever lose sight of that.”” – Lance Armstrong

## Moving forward: Living his life, reflecting on his legacy, the state of Livestrong [1:42:30]

- - Was there a period in 2013 after the confession of reclusion?
  - When did the podcast start, in 2016, 2017?
    - Lance began the podcast [Forward. Thinking. Dialog.](https://theforwardpodcast.libsyn.com/) in 2016
      - This features conversations with an eclectic range of personalities with intriguing stories to tell
    - Lance began the podcast [THEMOVE](https://stages.libsyn.com/) in 2017
      - This features his perspective on iconic cycling races
  - He had no choice but to be off the radar; the radar didn’t pick him up; there was nothing to do
  - How was it to walk into a restaurant
    - Perfectly fine; indifference
  - Indifference?
  - Yeah; that’s why he doesn’t read comments; not an accurate snapshot of what his life is like at all
  - Peter clarifies “Even in 13′? Because remember, the other thing that was going on at that point in time is the foundation is crumbling, and you’re getting kicked out. You’ve told me before that hurt as much as anything else.”
    - It was surreal
  - What about the people at the foundation who worked there, the people who were doing the actual heavy lifting
    - Lance has a ton of regret about them because they were doing the Lord’s work and they were not privy
      - They were not decision makers
      - They believed the dream, the story
      - In many ways felt complicit in the scheme
      - That’s tough for him to hear, and he’ll spend the rest of my days trying to make that okay for them
    - He doesn’t know what the boardroom discussions were like, or which consultants were hired or how it all went down

- *A timeout was the right thing, to give some space, but not an ending*

> “If I look at where Livestrong has ultimately ended up. If I look at my audience now, well, they’re very different. One of them is not doing very well, and the other one is back so to speak.” – Lance Armstrong

**Peter asks what interaction he has these days with the cancer community?**

- Very little
- Just one-on-one and that’s fine

**Peter asks what Lance thinks his legacy will be**

- Too early to say
- He doesn’t like to brag, but he’s really fucking proud
  - Proud of the fact that he didn’t quit
    - Peter asks “Which time?”
    - That he was able to keep it together without really any support
    - I’m 50 years old, I’ll live another 40 or 50 years; there’s a lot left to be told

> “Thank God we live in 2021, 20, whatever, where you can reinvent yourself on your own. You don’t need network television. You don’t need the New York Times. You don’t need any of that, but we’re doing right here right now, you did this on your own. You brought the cameras, you got the mics. You’re asking the questions. You’re the smart guy, millions of people are listening. You did that on your own. I couldn’t have done that 10 years ago, 20 years ago. I’ve chosen to go that path, and I’m proud of that.” – Lance Armstrong

- *Lance’s top priority is his family; it’s his first checkpoint and that’s amazing*

- He feels beholden and loyal to the audience of his podcast
  - As a by-product of the success of the podcast, the fund, the people who have entrusted him with their hard-earned money; he’s beholden to them

> The guy that the whole world thought could never be trusted again – Lance Armstrong

- Otherwise, he is fine being private; he doesn’t need to be on the cover of Forbes

## Turning back the clock: Advice Lance would give to his 15 year-old self [1:46:45]

**Peter asks “If you could go back in time to 15 year old Lance… You’ve got a week with him. What kind of lessons would you try to impart on him?”**

- There would have been a lot
- He was a pro athlete and it was when his mom kicked out Terry Armstrong (age 15)
- That was the point in time where it was her and I against the world

- - Peter observes “So the chip on your shoulder, which I’m guessing exists, subconsciously now became pretty conscious”
    - Absolutely.
    - It’s been good for him and also bad for him
  - 15 year olds don’t realize that
  - The amount of trauma he had already had in his life, which just got worse and worse and worse
    - Cancer was hugely traumatic
    - The fall was traumatic.
    - There’s a lot to unpack there
    - Never meeting your father and having this man around
    - Never having that figure in your life, and the figure that was there was wildly defective

- *He doesn’t think 15-year old Lance would have listened to anyone coming with advice*

- - He embraces therapy now

> “One of the things I’ve learned about myself over time is that so many of the character traits that were both positive and negative and they tend to cluster like right on top of each other, right? It’s two genes that sit right next to each other in the chromosome. One good, one bad. A lot of those traits come about long before we’re consciously aware of what led to them.” – Peter Attia

- Peter thinks Lance’s traumas are so obvious
  - The dad, the stepdad, the growing up without this; cancer
- Peter asks which he feels he’s gone back and unpacked as an adult, the PTST of all those layers
- Lance doesn’t know if any of us can ever unpack it all
  - In the last year, he’s certainly done more unpacking than in the previous 49
  - He should have started that process a lot earlier
- Going back to the question, even then at 15, he drove a fast car and every green light was a competition
  - He would tell himself “Slow down kid.”
  - Everything was fight, not even a competition,
  - It would have been impossible to get through to that 15-year-old, the 25-year-old, the 35-year-old, even the 45-year-old
- Peter relates “*I think that’s something that very few people can understand. I can relate to Lance, because I’ve had my own total, total destruction. I’ve played the game in my head 100 times. God, I just wish I could take that all back. I wish I could undo all of that stuff. But I realized if I were to undo all of that stuff, I wouldn’t have fallen down. And if I didn’t fall down and lose it all.*”
  - Right, this is when one says “Well, I wouldn’t change a thing.”
  - Because these series of events happened and caused deep work or introspection or realignment
  - Without these events, that wouldn’t have happened

## Keeping fit at age 50 [1:51:00]

**How does Lance keep fit these days?**

- Is swimming the mainstay of training?
- During the summer in Aspen, it’s mountain biking
- He doesn’t get in his car to ride his bike
- He’s happy to just go out and ride
  - No heart rate, no power meter; none of that bullshit
  - No group rides; he just enjoys riding alone
- He hasn’t run much; he’s getting too old to run
  - Maybe if he did yoga 3 days a week or was serious about stretching and playability he could run
  - He likes to just go out and exercise; just put on shoes and go
  - That doesn’t work when you’re 50

- Peter asks “what’s the tightest interval you’d swim 10 hundreds on? What would be your touch and go interval for 10 hundreds?”
  - Could he do 105 touch and go?
  - No, 115 and maybe bring it to 110
  - He’s still fit
- Peter asks “What’s the biggest liability to your fitness. What’s your biggest vice? Food, alcohol, what gets in the way of…? Because what do you weigh right now?”
  - He weighs 180; 15 pounds above his tour weight
  - It’s not a struggle to maintain his weight
  - He exercises for mental health, for sanity

> “I will ride for as long as this body will allow it to ride.” – Lance Armstrong

§

## Selected Links / Related Material

**Lances book**: [It’s Not about the Bike: My Journey Back to Life](https://www.amazon.com/Its-Not-about-Bike-Journey/dp/0399146113/ref=sr_1_3?crid=3PW8QGVDVUXHO&dchild=1&keywords=lance+armstrong+book&qid=1631714247&s=books&sprefix=lance+armstron%2Caps%2C184&sr=1-3) by Lance Armstrong (2000) | [57:30]

**Biography of Eddy Merckx**: [Half Man, Half Bike: The Life of Eddy Merckx, Cycling’s Greatest Champion](https://www.amazon.com/Half-Man-Bike-William-Fotheringham/dp/1613747268/ref=sr_1_2?dchild=1&keywords=Half+man%2C+half+bike&qid=1631725839&sr=8-2) by William Fotheringham (2013) | [1:13:00]

**Tyler Hamilton’s account of doping in cycling**: [The Secret Race: Inside the Hidden World of the Tour de France: Doping, Cover-ups, and Winning at All Costs](https://www.amazon.com/Secret-Race-Inside-Cover-ups-Winning/dp/0345530411/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1631797597&sr=1-1) by Tyler Hamilton (2012) | [1:28:30]

**Lance Armstrong’s interview with Oprah Winfrey in 2013**: [Lance Armstrong & Oprah Winfrey: interview transcript](https://www.bbc.com/sport/cycling/21065539) | *The BBC* (January 18, 2013) | [1:29:15]

**Interview with Lance’s soigneur Emma O’Reilly**: [Interview: Emma O’Reilly: ‘My relationship with Lance Armstrong was and still is a human one’](https://www.theguardian.com/sport/2014/jul/02/emma-o-reilly-lance-armstrong-cyclist-doping) | William Fotheringham, *The Guardian* (July 2, 2014) | [1:31:45]

**Book by** **Lance’s soigneur Emma O’Reilly in which he wrote the forward**: [The Race to Truth: Blowing the whistle on Lance Armstrong and cycling’s doping culture](https://www.amazon.com/Race-Truth-Blowing-Armstrong-cyclings/dp/0593074068/ref=sr_1_1?dchild=1&keywords=Emma+O%27Reilly&qid=1631799182&s=books&sr=1-1) by Emma O’Reilly (2014) | [1:32:30]

**NBC Sports interview with Lance Armstrong**: [Lance Armstrong: Next Stage](https://youtu.be/ac_x4ucbReo)  | *NBC Sports* (May 29, 2019) (youtube.com) | [1:35:30]

**Lance’s podcast features conversations with an eclectic range of personalities with intriguing stories to tell**: [Forward. Thinking. Dialog.](https://theforwardpodcast.libsyn.com/) | [1:42:30]

**Lance’s podcast featuring his perspective on iconic cycling races**: [THEMOVE](https://stages.libsyn.com/) | [1:42:30]

**Recent news about Jan Ullrich and his appearance on Lance’s podcast The Move**: [Jan Ullrich opens up about the toughest comeback of his life](https://cyclingtips.com/2021/09/jan-ullrich-opens-up-about-the-toughest-comeback-of-his-life/) | *Cycling Tips* (September 27, 2021)

§

## People Mentioned

- [George Hincapie](https://en.wikipedia.org/wiki/George_Hincapie) [4:15, 18:45, 33:30, 1:27:45]
- [Mark Allen](https://en.wikipedia.org/wiki/Mark_Allen_(triathlete)) [13:15, 14:15]
- [Dave Scott](https://en.wikipedia.org/wiki/Dave_Scott_(triathlete)) [14:15]
- [Davide Rebellin](https://en.wikipedia.org/wiki/Davide_Rebellin) [18:15]
- [Casartelli](https://en.wikipedia.org/wiki/Fabio_Casartelli) [18:00]
- [Erik Dekker](https://en.wikipedia.org/wiki/Erik_Dekker) [18:15]
- [Erik Zabel](https://en.wikipedia.org/wiki/Erik_Zabel) [1:38:30]
- [Steve Bauer](https://en.wikipedia.org/wiki/Steve_Bauer) [21:45]
- [Phil Anderson](https://en.wikipedia.org/wiki/Phil_Anderson_(cyclist)) [21:45]
- [Andy Hampsten](https://en.wikipedia.org/wiki/Andrew_Hampsten) [22:00]
- [Greg LeMond](https://en.wikipedia.org/wiki/Greg_LeMond) [22:00, 25:45, 1:31:30]
- [Miguel Indurain](https://en.wikipedia.org/wiki/Miguel_Indur%C3%A1in) [22:30, 23:45, 25:45, 26:45, 1:07:30]
- [Olaf Ludwig](https://en.wikipedia.org/wiki/Olaf_Ludwig) [23:45]
- [Claudio Chiappucci](https://en.wikipedia.org/wiki/Claudio_Chiappucci) [23:45]
- [Andrei Tchmil](https://en.wikipedia.org/wiki/Andrei_Tchmil) [23:45]
- [Johan Museeuw](https://en.wikipedia.org/wiki/Johan_Museeuw) [23:45]
- [Bjarne Riis](https://en.wikipedia.org/wiki/Bjarne_Riis) [23:45]
- [Pedro Delgado](https://en.wikipedia.org/wiki/Pedro_Delgado) [26:15]
- [Marco Pantani](https://en.wikipedia.org/wiki/Marco_Pantani) [30:30, 1:05:00, 1:09:30, 1:12:00, 1:37:45, 1:39:00, 1:41:45]
- [Michele Ferrari](https://en.wikipedia.org/wiki/Michele_Ferrari) [31:30, 35:30, 1:00:00, 1:03:30, 1:08:30, 1:16:30, 1:25:15]
- [Fabio Casartelli](https://en.wikipedia.org/wiki/Fabio_Casartelli) [18:06, 32:15, 34:30]
- [Johan Bruyneel](https://en.wikipedia.org/wiki/Johan_Bruyneel) [34:00, 1:01:00, 1:02:00, 1:04:30, 1:11:00, 1:19:45, 1:20:15]
- [Hennie Kuiper](https://en.wikipedia.org/wiki/Hennie_Kuiper) [34:15]
- [Tony Rominger](https://en.wikipedia.org/wiki/Tony_Rominger) [37:45]
- [Dr. James Reeves](https://health.usnews.com/doctors/james-reeves-793202) [41:15, 42:30]
- [Dr. Larry Einhorn](https://medicine.iu.edu/faculty/4942/einhorn-lawrence) [45:45]
- [Thom Weisel](https://en.wikipedia.org/wiki/Thom_Weisel#Professional_sports) [55:30]
- [Johnny Weltz](https://en.wikipedia.org/wiki/Johnny_Weltz) [1:01:00]
- [Chris Carmichael](https://en.wikipedia.org/wiki/Chris_Carmichael_(cyclist)) [1:03:45]
- [Jan Ullrich](https://en.wikipedia.org/wiki/Jan_Ullrich) [1:05:15, 1:09:30, 1:13:45, 1:38:00, 1:41:45]
- [Bjarne Riis](https://en.wikipedia.org/wiki/Bjarne_Riis) [1:07:30]
- [Alex Zülle](https://en.wikipedia.org/wiki/Alex_Z%C3%BClle) [1:09:30]
- [Fernando Escartín](https://en.wikipedia.org/wiki/Fernando_Escart%C3%ADn) [1:09:45]
- [Abraham Olano](https://en.wikipedia.org/wiki/Abraham_Olano) [1:09:45]
- [Eddy Merckx](https://en.wikipedia.org/wiki/Eddy_Merckx) [1:12:15, 1:39:45]
- [Bradley Wiggins](https://en.wikipedia.org/wiki/Bradley_Wiggins) [1:15:30]
- [Joseba Beloki](https://en.wikipedia.org/wiki/Joseba_Beloki) [1:13:45, 1:20:15]
- [Jean-Marie Leblanc](https://en.wikipedia.org/wiki/Jean-Marie_Leblanc) [1:23:00]
- [Floyd Landis](https://en.wikipedia.org/wiki/Floyd_Landis) [1:23:30, 1:28:15, 1:32:45]
- [Tyler Hamilton](https://en.wikipedia.org/wiki/Tyler_Hamilton) [1:28:15, 1:32:30, 1:38:00]
- [Emma O’Reilly](https://www.theguardian.com/sport/2014/jul/02/emma-o-reilly-lance-armstrong-cyclist-doping) [1:31:45]
- [Ivan Basso](https://en.wikipedia.org/wiki/Ivan_Basso) [1:37:30, 1:41:45]
- [Jonathan Vaughters](https://en.wikipedia.org/wiki/Jonathan_Vaughters) [1:38:00]
- [José María Jiménez](https://en.wikipedia.org/wiki/Jos%C3%A9_Mar%C3%ADa_Jim%C3%A9nez) [1:38:15]
- [Erik Zabel](https://en.wikipedia.org/wiki/Erik_Zabel) [1:38:45, 1:40:30, 1:41:45]
- [Vandenbroucke](https://en.wikipedia.org/wiki/Frank_Vandenbroucke_(cyclist)) [1:39:15]
- [Gaumont](https://en.wikipedia.org/wiki/Philippe_Gaumont) [1:39:15]
- [Andreas Klöden](https://en.wikipedia.org/wiki/Andreas_Kl%C3%B6den) [1:40:15]

§