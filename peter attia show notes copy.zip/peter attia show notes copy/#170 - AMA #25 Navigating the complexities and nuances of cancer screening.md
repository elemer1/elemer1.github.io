# #170 – AMA #25: ﻿Navigating the complexities and nuances of cancer screening

**Source:** [https://peterattiamd.com/ama25/](https://peterattiamd.com/ama25/)

---

In this “Ask Me Anything” (AMA) episode, Peter and Bob dive deep into cancer screening, including why it’s important, what you need to know about a test, and Peter’s approach with patients. They specifically discuss various screening methods, explain important terms like sensitivity and specificity, and how layering and stacking different tests in tandem can improve predictive values. They conclude with a discussion on one of the more exciting screening tools, diffusion-weighted MRI, and how it’s changing the cancer screening landscape.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #25 show notes page](https://peterattiamd.com/ama25). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- The importance of cancer screening [1:15];
- Cancer screening terms: sensitivity, specificity, false positives, and false negatives [8:25];
- Cancer screening terms: positive and negative predictive value [17:00];
- Improving predictive value by layering tests, and the predictive values of mammograms [25:45];
- How smoking impacts the predictive value of cancer screening [30:45];
- Liquid biopsies for ruling out cancer and the blind spots of common cancer screening tests [33:00];
- The difference between cancer originating from inside versus outside the body [41:15];
- How diffusion-weighted MRI is changing cancer screening [45:15];
- Summary of Peter’s approach to cancer screening [53:45]; and
- More.

§

The Peter Attia Drive

Navigating the complexities and nuances of cancer screening

§

## Show Notes

§

## The importance of cancer screening [1:15]

**Some subscriber questions covered in this podcast**:

- How do you think about cancer screening?
- Why and or when should I be screened?
- Which tests are worth getting?
- What do you think of liquid biopsies?
- How do you interpret sensitivity and specificity of tests? What do those actually mean?
- What are some screening tools for cancer you use in your practice?
- Can you discuss how you categorize cancers and how you screen for each?
- What’s the difference between cancers outside the body versus cancers inside the body?

**Addressing the first question**: *How do you think about cancer screening?*

Longevity has these two components—they’re not independent—but sometimes, it’s helpful to think about them in isolation:

- Lifespan—How do you live longer?
- Healthspan—How do you live better?
- Major diseases that rob a person of lifespan include cancer, atherosclerotic diseases, and the diseases of dementia and neurocognitive decline
- The latter two go more hand in hand with the reduction in health span
- By definition, when a person has Alzheimer’s disease, their quality of life  i.e. their cognition) is also deteriorating–So they’re experiencing both the slide in quality of life and eventually length of life
- Similarly in people that have advanced atherosclerosis, a lot of times the reduction in the ability to carry out activities of daily living kind of moves more hand in hand with that
- In the case of cancer, health span decline is a little less the case
- Age is the greatest risk factor for cancer just as it is for the other two diseases
- But in some ways it’s a little bit easier to think of cancer in isolation from the health span stuff
- if you’re trying to imagine a world in which you can live longer… that means living in a world where we **delay the onset of chronic disease** and/or have **better tools to live longer with chronic disease**
- Peter much more favors the former option (i.e., delay) because we’ve basically spent most of the history of modern medicine working on the latter option with very, very limited success.

**Screening**

- One of the pillars of longevity is **minimizing mortality from cancer**
- So *where does screening fit into this*?
- Screening is one of three pieces
- First piece would be, *how do you prevent cancer*?
- The second thing would be, *how do you screen for cancer and detect it early*?
- And the third is, *how do you treat it when you have it*?

Focusing on the prevention piece…

- W*hy does Peter believe that screening is an important pillar*?
  - The simplest explanation for why screening matters is the evidence that suggests that a **cancer that is caught earlier is easier to treat** than a cancer that is caught later
  - For instance, if you catch a breast cancer or a colon cancer when there are tens or hundreds of millions of cancer cells, your odds of treating that successfully are better than if you catch the same cancer years later, when there are billions of cells
  - The evidence for that basically comes from examining how patients respond to the exact same drugs in the adjuvant setting versus in the metastatic setting
  - The adjuvant setting is when a drug is given to a patient who has no visible cancer
  - So if you believe that they have microscopic disease that remains, and you give them a drug like Herceptin for a HER2/neu positive breast cancer
  - If you compare the outcomes of those patients to the outcomes of patients who are given the exact same drug for the exact same phenotype and genotype of the cancer, but in the metastatic setting, there’s no comparison in the outcomes
- Possible explanation for the difference in success rates:
  - One explanation for that may be that the cancers that have been around longer have developed more mutations
  - It is therefore Peter’s belief that the more we can do to screen for cancer and catch it earlier, the better we will be

**Screening frequently comes with a price**:

- We pay a financial price for that
- And we pay potentially an emotional price
  - We have to now get into false positives and false negatives

**Looking at five-year survival stats…**

- Take breast cancer—If you catch it early and it’s a local cancer and it hasn’t metastasized, the [five-year survival rates are 99%](https://www.cancer.net/cancer-types/breast-cancer/statistics#:~:text=The%20average%205%2Dyear%20survival,with%20this%20disease%20is%2099%25.)
- But for metastatic breast cancer, [five-year survival is about 28%](https://www.cancer.net/cancer-types/breast-cancer-metastatic/statistics)

## Cancer screening terms: Sensitivity, specificity, false positives, and false negatives [8:25]

**Sensitivity**

![](https://peterattiamd.com/wp-content/uploads/2021/07/f1-ama25-1024x662.png)

**Figure 1**.

- Sensitivity is the probability that the test yields a positive result for someone who has the condition of interest
- A sensitive test is likely to detect a person who has COVID if they’re tested

*A realistic example: Mammography*

![](https://peterattiamd.com/wp-content/uploads/2021/07/f2-ama25-1024x636.png)

**Figure 2.**

- we are now talking about 1,000 women who have breast cancer
- if you were to run a mammogram on them, 840 of them would have a positive mammogram
  - the radiologist would read that and say, “this woman has breast cancer.” So those are true positives.
- In this example, 160 of those women would have their mammogram read as negative
  - And these would be false negatives
- Sensitivity is defined as the true positive rate over the total number of cases
- True positives plus the false negatives, which in this case yields 84%.
- a *very, very, very* sensitive test would always have caught the people who have the condition
- Best case scenario here is a 100% sensitive test that would detect 1,000 of those women, and none of them would be false negatives

With sensitivity, you have to understand that it’s basically backwards looking

- With specificity, by contrast, you truly know who has cancer, who doesn’t have cancer, when we get into specificity
- when you look at sensitivity, you already know what the result is when somebody, after they get screened and you know the results
- But in the case of sensitivity, if the test is negative, you know it’s wrong. You know it’s a false negative, just because we’re looking at a group of people where you already kind of have the answer in hand with sensitivity
- with specificity as you’ll see in a moment, it means that you actually have forward-looking data to know that a negative is truly a negative

**Specificity**

![](https://peterattiamd.com/wp-content/uploads/2021/07/f3-specificity-ama25-1024x707.png)

**Figure 3.**

- contrapositive of sensitivity
- specificity is the probability that a bunch of people who do not have the condition will also end up with a negative test

*An example…*

![](https://peterattiamd.com/wp-content/uploads/2021/07/f4-ama25-1024x641.png)

**Figure 4.**

- So if you took 1,000 women who do not have breast cancer (that means that I know longitudinally that they don’t have breast cancer)
  - For the next five years, you follow them, and none of them go on to develop breast cancer
  - These are truly women who do not have breast cancer
- You run the mammogram on them, 90 of them are going to have a positive finding
  - A radiologist is going to read this and say, “Hey, I think you have breast cancer here. We need to do a biopsy or do something else
  - In other words, those 90 women (or 9%) had a false positive.
- Conversely, 910 women in this case would have a negative read, which is truly negative
  - Specificity is therefore the number of true negatives over the total number of cases, the true negatives plus the false positive
  - 910 over 1,000 is a 91% specificity
- As **specificity** goes up, your **ability to discern negatives** goes up
- As **sensitivity** goes up, your **ability to discern positives** goes up

![](https://peterattiamd.com/wp-content/uploads/2021/07/f5-trade-off-ama25-1024x595.png)

**Figure 5**.

- As sensitivity goes up, your true positives go up and your false negatives go down

*The “metal detector” example for illustrative purposes*:

- You have a metal detector in the airport, and your goal is to figure out if people walking through the metal detector are carrying metal
- you can adjust the gain on that for how much magnetic signal you want to pick up
- if you want it to be very, very sensitive, that means you never want to have a false negative
- You never want anyone to walk through that detector with metal and get missed
- you are dialing up sensitivity
- Your true positives are going to go very high. You’re going to catch everybody. And your false negatives are going to be very low
- What’s happening on the flip side of that, you’re going to get a lot of false positives. Which means you’re going to be dinging a lot of people for metal who don’t have metal
- In the case of a metal detector in an airport, we probably are willing to make that trade off

*Using the “metal detector” analogy, now let’s look on the other side with* ***specificity*****:**

- Let’s say you forgot to plug it in, and everybody walks through
- And imagine the manufacturer says, “One thing in our favor is that our specificity is 100%. If you’re not carrying any metal, we’re going to pick up every single true negative. And we will never pick up any false positives with our machine.”
- An unplugged metal detector has 100% specificity, because there will be no false positives—so it’s useless when it comes to actually accomplishing what you need a metal detector for, which is finding the true positives and minimizing the false negatives

Similarly, a test that is 100% sensitive but 0% specific is equally useless

- For example, say you send a million letters out to women and tell every one of them they have breast cancer
  - Guess what? That’s 100% sensitive
  - In that group of a million women, some are guaranteed to have breast cancer and you have truly told every one of them that they have breast cancer
  - The problem is your false positives are so high, your specificity is effectively zero—It’s a useless test

> “Don’t be lulled into the trap of thinking [a cancer screening test] has to have 100% sensitivity or 100% specificity. It’s more about the interplay between them.” —Peter Attia

## Cancer screening terms: positive and negative predictive value [17:00]

![](https://peterattiamd.com/wp-content/uploads/2021/07/f6-ppv-and-npv-ama25-1024x756.png)

**Figure 6**.

- If you’re going in to get screened, these two metrics (PPV and NPV) are really important
- Peter points out that he has a hard time thinking about them in isolation, because it’s better to think about them in terms of prevalence
- This is what determines clinical decision-making and anxiety—This is not just an academic exercise, we are doing this because we need to make decisions based on the outcomes *and we don’t want to cause undue stress*

**Definitions:**

The **positive predictive value** is defined as the number of *true* positives over the true positives + the false positives (the tested positives versus all the positives)

- So a high positive predictive value means if you get a positive test, here’s how confident you are that your test is truly positive
- For example, a 50% positive predictive value means one out of every two tests is a false positive (a true positive is a test positive that is indeed positive)
- A false positive is a test positive that is not positive for the condition.

Similarly, the **negative predictive value** are the *true* negatives

- So if you had a 50% negative predictive value, it would mean that only half the people for whom a negative test is the outcome are actually negative for the condition

The **single most important concept** is: *How do these numbers change in the context of the* ***prevalence****?*

- Because you have to know what’s called the pretest probability before you can take a given sensitivity and specificity and get a PPV and an NPV

\*[**Interactive spreadsheet**](https://peterattiamd.com/how-to-interpret-screening-tests-video-spreadsheet-and-primer/)\*

- **Four things that you get to input into the spreadsheet** –
  - i) Population,
  - ii) Prevalence,
  - iii) Sensitivity, and
  - iv) Specificity
- For the population — if you want to actually see numerical relevance, it does not change the PPV or the NPV
- For Prevalence – Things to consider when inputting prevalence:
  - Are we talking about the general population? Are we talking about a given individual?
  - If you consider a 60 year old who smokes two pack a day for the last 30 years, the prevalence of cancer in a group of those people is *much higher* than a 30 year old who is a totally healthy nonsmoker without Lynch syndrome or something like that
  - In that latter case, the prevalence is less than 1%. In the former case, that prevalence is probably greater than 10%

![](https://peterattiamd.com/wp-content/uploads/2021/07/f7-ama25-1024x632.png)

**Figure 7.**

![](https://peterattiamd.com/wp-content/uploads/2021/07/f8-ama25-1024x635.png)

**Figure 8.**

**Example using the** [**interactive spreadsheet**](https://peterattiamd.com/how-to-interpret-screening-tests-video-spreadsheet-and-primer/)**:**

*Let’s first use an example of a high-risk person doing a mammography test whose prevalence of cancer is 5% at the time you do this test* [see timestamp 23:20 in the video above]—

![](https://peterattiamd.com/wp-content/uploads/2021/07/f9-ama25-1024x460.png)

**Figure 9. Screenshot from video at 23:20.**

- The numbers for the mammography test — sensitivity is 84% & the specificity is 91%.
- The **green squares** show you when the test is doing its job correctly—the true positives are 84%, which means 4,200 out of 5,000 people (5,000 because 5% of 100,000 have cancer)
- Then when you look at the “don’t have cancer” column, which is the 95,000 people who don’t have cancer, *how many of them were truly diagnosed as negative?* = 86,450
- Your **red squares** show you where the test didn’t work (i.e., the false negatives) = 800 women in this case have breast cancer (i.e, 800 women would get missed)
- For the false positives, we have about ~8,500 (i.e., the people that are going to require follow-up testing or even a biopsy)
- Now, let’s take at **positive predictive value** (PPV)
  - In an environment where prevalence is 5%, sensitivity is 84%, specificity is 91%, the **positive predictive value is only about 33%.**
  - This is very important to understand… it means if you have a mammogram that says you have breast cancer, there’s actually only a 33% chance that you actually do have cancer
- Conversely, the **negative predictive value** is very high at 99% — Meaning if you have a negative mammogram in this setting, you can be very confident that you do not have breast cancer

*Now, let’s* ***change the prevalence value to 1%*** *and see what happens* [see timestamp 25:00 in the video above]—

![](https://peterattiamd.com/wp-content/uploads/2021/07/f10-ama25-1024x458.png)

**Figure 10. Screenshot from video at 25:10.**

- Note that we haven’t changed the sensitivity or the specificity so this is the same exact test
- We’re now just applying it to a person who has a much lower pretest probability of the cancer
- In this case, if this person has a positive test, it means almost nothing because the PPV is really low at 8.6%
- The NPV becomes even stronger at 99.8% — so it’s overwhelmingly the case that this person does not have cancer
- You could argue that that’s not very relevant because the person’s pretest probability was only 1%, and their post-test probability is 0.2%, so you’ve gained 5X in terms of negative predictive value

*Now, let’s* ***change the sensitivity to 50% and specificity to 99%*** *while keeping the prevalence at 1% and see what happen* [see timestamp 26:15 in the video above]—

![](https://peterattiamd.com/wp-content/uploads/2021/07/f11-ama25-1024x452.png)

**Figure 11. Screenshot from video at 26:25.**

- You now have a test that is far less sensitive — meaning it’s not as good at detecting cancer when it’s there, but it’s much better at knowing **when cancer is not there**
- Notice that you’ve paid a little bit of a price on your NPV as it’s come down from 99.8 to 99.5.
- And look what it’s done on your PPV — it’s increased that from basically nothing to at least 33%.

*Now, let’s* ***move the specificity up to 99.5%*** *while keeping everything the same and see what happens* [see timestamp 26:55 in the video above]—

![](https://peterattiamd.com/wp-content/uploads/2021/07/f12-ama25-1024x458.png)

**Figure 12.**

- now you’re talking about a positive predictive value of a coin toss 50%
- in a patient population where the prevalence of cancer is 1% is not that bad.
- And the negative predictive value is basically unchanged

*Just to complete this, let’s* ***change the prevalence 10%*** [see timestamp 27:20 in the video above]—

![](https://peterattiamd.com/wp-content/uploads/2021/07/f13-ama25-1024x454.png)

**Figure 13.**

- now we’re talking about a very high risk population
- prevalence is 10%. Your sensitivity is still 50%. Your specificity is basically 100%. It rounds up to 100
- Your positive and negative predictive value are very high here
- If you have a positive test, you’re more than 90% sure that it’s positive, that you have the condition
- And if you have a negative test, you’re 95% sure that that’s correct.

\*IMPORTANT POINTS: [25:24]

- The first point is that sensitivity and specificity cannot be evaluated in isolation. They have to be evaluated in the context of the prevalence or what we call the *pretest probability.*
- The second point is the nonlinearity with which sensitivity and specificity affect PPV and NPV in the case of prevalence makes it such that we need a worksheet like this to play with. We can’t do this math in our head.

## Improving predictive value by layering tests, and the predictive values of mammograms [25:45]

[To see the spreadsheet results from this section, start the video at timestamp 28:30]

**Looking at mammography…**

- Bob says, “if you’re looking at routine screening in people who are at average risk, the prevalence might be around 1.3%.”
- And then if we go back to those values of was it 84% sensitivity, 91% specificity
- You might say “okay, well mammography has a sensitivity of 84% and specificity of 91%”
- Well, what does that mean?
- If a woman has a mammography in this population and has a positive test…what is the likelihood that she actually has breast cancer?
- When Bob saw a positive predictive value of about 10%, “it just didn’t compute even though I’m literally computing this”
- You look at 84% and 91% and you just think those are good grades
- And then you actually look at, how predictive is this test?
- Well, the prevalence is 1% and the positive predictive value is 10%—That’s actually pretty good as far as a test goes.
- “*But just looking at the absolute numbers, it just took me aback that when you looked at those sensitivity and specificity and you think well, somebody comes back with a positive test. What’s the likelihood that she has breast cancer? And just on average, it’s a 1 in 10 chance*.” says Bob
- Peter points out that today’s mammography is better
- But the reality of it is I think this gets to another question, which is: *Why is screening such a controversial topic?*

***Why is screening such a controversial topic?***

- People tend to revisit literature they are familiar with rather than seek out and become versed in new literature
- A paper published 10 years ago was going to be based on mammography done 25 years ago, following women from, say, the mid ’90s to the early 2000s
- At that time, you had two things going on:
  - One, you had less sensitive, less specific tests.
  - And two, the outcome was, we’re going to go and do a biopsy—therefore the morbidity of the false positives was large—so therein lies the opposition
- Fast forward to today…Today’s mammography is going to have a higher sensitivity and specificity
- Let’s plug in 90 and 95 into the spreadsheet and see how it changes
  - That’s basically going to increase your positive predictive value to 20%
  - That means there’s still an 80% chance when you have a positive mammo that you don’t have breast cancer
  - But if you have a negative mammo, you’re in pretty solid shape
- Peter still believes mammo is essential for all women despite all of the fancy other tests we can do, like diffusion-weighted imaging, and MRI, and ultrasound, mammo is important for an anatomic reason we’ll get to.

**Importance of layering tests [28:53]**

- If you do one particular test, so for mammography for example, maybe it doesn’t mean right away that you get a biopsy
- Instead, maybe you do another test on top of that and you might actually be able to get a better positive predictive value
- That’s effectively how we think about cancer screening, says Peter
- One type of test is a piece of Swiss cheese, there are lots of pencils that can go through it.
- You really want to stack a few pieces of Swiss cheese on top of each other such that the holes are all obstructed except the one which is the true positive

*Using breast cancer as an example for the value in layering tests*:

- Best way to do that with today’s technology is mammography plus MRI with diffusion-weighted imaging
  - Not the most cost-effective way to do it
  - But it minimizes radiation because the mammography is very low radiation
  - Whereas there are other types of imaging for breast that have an enormous amount of radiation that used to be in vogue less so now with MRI and ultrasound.
- As they talk about later in the podcast, the diffusion-weighted imaging with background subtraction can pick up things that no other test can pick up
- However, diffusion-weighted imaging misses something that mammograms pick up— small calcified lesions
  - If you have dense breast tissue, if you have glandular breast tissue, you’re going to get a lot of false positives
  - And that’s why ultrasound or MRI as a backup is a great way to avoid the unnecessary biopsies that plagued many women for decades.

## How smoking impacts the predictive value of cancer screening [30:45]

![](https://peterattiamd.com/wp-content/uploads/2021/07/f14-ama25-1024x213.png)

**Figure 14.**

**Population of smokers**

- If you look at a population of smokers and you’re looking at screening, you’re going to have a higher prevalence.
- One study showed ~70 year old individuals with a two pack a day smoking habit for 50 years would have a pretest probability of the prevalence of about 15%
- That pretest probability of the prevalence is going to change the landscape in terms of the predictive value of a test—if you’ve got a higher prevalence, you’re going to have more predictive value with that

**Looking at row #6 in the figure above…**

Mammography—using the old numbers—at 1.3% prevalence of breast cancer, sensitivity of 84%, specificity of 91%

- Your positive predictive value is 11.6%
- Your negative predictive value is 98.8%
- So a women gets that test and comes back negative can confident in the result
- But if she’s positive…*now what do we do?*
  - You take that woman with a positive mammo, and you do the MRI with diffusion-weighted imaging and background signaling—A test which has a 92% sensitivity, a 99.6% specificity
  - And now, your pre-test probability goes up to that 10.6% based on the positive mammo
  - This is not a woman with a pretest probability of 1.3%, this is a woman with a pretest probability of 11%
  - And all of a sudden now if the MRI comes back positive, she has a 97% chance of breast cancer
  - This is a woman in whom you can justify doing a biopsy
    - And if it comes back negative, you’re 99% sure it’s negative

## Liquid biopsies for ruling out cancer and the blind spots of common cancer screening tests [33:00]

**What is a liquid biopsy?**

- A liquid biopsy is a biopsy of the blood (essentially a blood sample)
- The goal here is to be able to infer through a blood test if a person has a solid organ tumor
- If a person has a blood cancer like a leukemia, that would be the way you would gather that information before ultimately doing a bone marrow biopsy
- But what we’d really like to know—and it turns out it is possible—is to determine that a person has lung cancer, or breast cancer, or pancreatic cancer just by sampling in the blood
- A company called [GRAIL](https://grail.com/) has basically developed a technology of both sequencing and machine learning that takes blood and looks for something called [cell-free DNA](https://en.wikipedia.org/wiki/Circulating_free_DNA) fragments
- DNA resides in cells
- But inside the nucleus of a cell, there’s a reasonable amount of extracellular DNA fragments
- When a cell gets recycled, when it dies, or even when it releases DNA from the spontaneous synthesis of DNA in white blood cells, cell-free DNA occurs as part of normal cell turnover.
- When cancer is present, the methylation profile of cfDNA or cell-free DNA changes
- Methyl groups are those little CH groups that are ubiquitous in all of biochemistry and when they get attached to DNA/get attached to the nucleotides it’s like fingerprints, like knowing that there’s a change in the signature of what’s going on
- It’s that CF or cell-free DNA methylation pattern that is what allows people to in the case of these machine learning algorithms infer that a cancer is present AND what the likely tissue of origin is

Originally, there was another hypothesis was that you could look for tumor DNA

- But it turns out that this cell-free DNA approach is the more robust approach because it’s simply a numbers game
- While there is some DNA from tumors, it’s far less common
- The actual amount of it is about 1/1000th the amount of cell-free DNA
- In other words, you’ve got about 0.1% the amount of tumor DNA that you have cell-free DNA so you’d be better off looking at the cell-free DNA and looking at the methylation patterns of that than trying to find the tumor DNA
- This kind of epigenetic screening is basically what allows you to infer what’s going on at the level of the tissue

**How do liquid biopsies work?**

- You validate using known positive and known negatives
- You look at blood banks in which you have a whole bunch of people who have a known type of cancer
- And then you have blood from people who are known to not have cancer and not develop cancer in the next period of X months or years
- Then the question is, *Can you take that information of something that you calibrate on known positives and negatives, and then apply it to what we call real-world performance?*
  - The answer is yes

**Specificity and sensitivity of liquid biopsies**:

- Preliminarily, what we know is that the test increases in sensitivity as cancer stages goes up
- The specificity on this test is very high – about 99.5%
- But the sensitivity starts low
  - stage one cancers – about 20%
  - stage two cancers – about 45%
  - Stage three cancers – about 81%
  - Stage four cancers – about 93%
  - For all local cancers—stage one, two, and three—it’s a 44% sensitivity
- For all cancers all told, *it’s about a 55% sensitivity, 99.3% specificity*
- Predictive value:
  - If you apply those data to an all-comer prevalence, you’ll see that the positive predictive value for early stage tumors is about 20%
  - And it increases to about 45% for all cancers, and 55-60% for advanced cancers
  - Negative predictive value vacillates between 99.2 and 99.9%.
- “That’s a really long-winded way of saying liquid biopsies are an amazing way to tell somebody that they do not have cancer. They’re not a great way to tell somebody that they do have cancer.”
  - And this why layering tests is important

*The most remarkable thing about liquid biopsies…*

- It’s testing for more or less 50 cancer types and it’s really good at discerning what they call the tissue of origin—96% of the samples can actually detect which location it’s coming from
- So rather than going through the multitude of invasive tests (CT scan, biopsy, colonoscopy) in search of the origin, you can know this from the liquid biopsy

**Blind spots of liquid biopsies (and other tests)**

- With mammography, there are huge blind spots when it comes to very dense glandular breast tissue
- Huge blind spot to MRI, small calcified lesion
- There’s a blind spot to liquid biopsies, ***tissues that are encapsulated***
- Prostate, for example—liquid biopsies are not a great test for prostate cancer

*What is good for prostate screening?*

- Multiplanar MRI is incredible for prostate cancer
- So is PSA despite the fact that most people don’t think it is, but that’s because most people just look at PSA when they should be paying closer attention to PSA density and PSA velocity
- You have other blood tests like the 4K diagnostic test, which doesn’t just look at PSA and free PSA, but looks at two other proteins and has tremendous accuracy at not just determining if prostate cancer is present, but determining if aggressive prostate cancer is present
- Because the important question with prostate cancer is not if a man has it, but if a man is going to die from it
- There’s a saying that goes, “*Every man dies with prostate cancer. Some die of it*.”

⇒ For prostate cancer testing – See [podcast with Ted Schaeffer](https://peterattiamd.com/tedschaeffer/)

The macro point is knowing where your blind spots are

- One other example of blind spots is with MRI in early lesions in the GI tract
- If the lesion is big enough, you’re going to see it, but if not, you’re going to need to look inside

## The difference between cancer originating from inside versus outside the body [41:15]

> “In my mind, it’s unacceptable for a person to die from a cancer that starts outside the body that is visible.” —Peter Attia

**Starting with outside the body**

- Everything from the mouth to the anus is outside the body
- It is part of the same type of tissue lining
- Outside the body would be things like melanoma or even colon cancer
- It’s exposed to the outside world, which means you can look at it directly, you can look at it with your eyes
  - I.e., There is no barrier between you and the lesion

*Colon cancer*

- There’s another thing that makes colon cancer in particular very amenable to early screening
- Unlike other cancers, it has a very predictable path of development
- It always goes from polyp to cancer
- Not all of those polyps are pedunculated, meaning they’re not all the little polyps that stick out that are easy to see
- There are also sessile polyps, which are flat and easy to miss
- A great endoscopist and an exceptional bowel prep should be able to identify all polyps, especially if the endoscopist is able to spend enough time looking and get complete visualization of the entire colon

*Thought experiment*:

- If you were to do a colonoscopy on a person every single day, you would by definition always see the thing that is going to become colon cancer
- That means nobody should ever be dying of colon cancer if we’re smart enough to know how often to do that test
- A common recommendations today says somewhere between every 5 and 10 years, starting between age 40 and 50 depending on your risk factors
- But, at the individual level, those recommendations don’t make any sense
- And the reason they don’t make any sense is there are still people dying of colon cancer, despite following those recommendations

**Inside the body**

- Inside the body cancer is tougher
- Examples: Brain cancers, breast cancers, lung cancers, pancreatic cancers, liver cancer, kidney cancer, prostate cancer, sarcomas, cancers of the connective tissue
- Cancers that you can’t look at with the naked eye
- And liquid biopsies can hopefully give us a great insight into this coupled with all of these other types of screenings
- The MRI is a big part of that
- it’s also knowing when you need other things — *For example, knowing you also need the mammography*

- Other examples of outside the body, cervical cancer, head and neck cancer, you can’t look at—it’s too far away
- Even though some of them can be outside the body, but they’re just too difficult to see. So we tend to rely on the inside the body looks.

**The final category is in the blood**

- There are cancers of the blood – Leukemias
- Unfortunately, those are still things that show up when people are symptomatic — we don’t have routine tests for looking for leukemias
- People usually show up with anemia or some abnormal finding on a blood count that usually tips people off to that
- So it’s a question of, *How do we stack our screening in each of those three categories to go about finding it?*

## How diffusion-weighted MRI is changing cancer screening [45:15]

⇒ Previous [episode of The Drive](https://peterattiamd.com/rajpaulattariwala/) dedicated to discussing diffusion-weighted imaging MRI

**How MRI works**

- MRI is it’s all about proton manipulation
- Protons or hydrogen atoms are ubiquitous in the body, and if you think about it, we’re 70, 75% water and water is H2O
- By the way says nothing of all the hydrocarbons in our body—We are organic matter, we’re made of carbon, hydrogen, nitrogen
- Everything that is happening with an MRI is basically manipulating a hydrogen atom with a very, very strong magnet
- if anybody’s had an MRI, they’re probably very used to seeing the images and they may even notice that sometimes the images look really good (meaning they look anatomically normal)
- Then other times, the images don’t look very good at all, things light up very bright or they sort of look a bit odd
- And that has to do with the sequence, the timing of how the protons are led to be pulsed with a frequency
- The two most common sequences in MRI are called T1 and T2-weighted images
- They basically highlight different elements of the anatomy
- A T1-weighted image is a very anatomically beautiful image – it tends to highlight fat

- A T2-weighted image conversely is not as anatomically nice, but it’s still a very helpful image especially, for example, if you’re looking at the spine
- If someone’s getting a dedicated MRI of their spine and you want to truly understand the nature of the discs, the intervertebral discs, the T2-weighted image is really good

**Explaining** [**diffusion-weighted imaging with background subtraction**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2516183/) **(DWIBS)**

- Easiest way to explain it is that it’s looking at water, but it’s doing so across two points of time
- It’s doing so at two very small points of time, which is about 60 microseconds
- When you consider how ubiquitous water is in our body, even over 60 microseconds, water should be moving
- But if it doesn’t, then it tells us that that water is somehow **trapped**
- For example, if you look at the water in your blood between 60 microseconds, it’s going to have moved, it’s in constant circulation
  - But if there’s water that is not moving at all, we might infer that it’s stuck within a cell that is preventing the water from moving in and of itself
  - Or that it’s stuck in tight membranes
  - If that’s happening, it gives you a sense that there’s a high density of cells within that area
  - This is what makes diffusion-weighted imaging a little bit more of a functional test than an imaging test

In the [podcast with Raj Attariwala](https://peterattiamd.com/rajpaulattariwala/), they talked about the difference between a CT scan and a PET scan

- A CT scan is an image that shows anatomic detail
- Whereas a PET scan is a functional study—it shows glucose uptake by tissue so it’s not really trying to show you a nice picture where you can infer the minutiae of the vascular system of the liver or the pancreas.
  - Instead, it’s just trying to say, “Look, here’s an area where a lot of cells are taking up glucose.”
- The DWI is more akin to the latter (the PET scan)—
  - It’s basically showing you the darker something is on that scan, the firmer that tissue is
  - And that becomes very relevant in the setting of cancer, because cancer feels different than non-cancer
    - For example: women doing a self exam for a lump on their breasts
      - By feeling, palpating over breast tissue, if you feel a lump, that is a concern because cancer is firm
      - When you’re in the operating room and you run your hand across a patient’s liver and look for tumors, the tumors stand out because they are firm
      - “*This is why the DWI, when paired with the other phases of the MRI, is a very powerful tool*.” says Peter

![](https://peterattiamd.com/wp-content/uploads/2021/07/f15-prenuvo-pancreas-ama25-1024x606.png)

**Figure 15. Prenuvo MRI versus conventional MRI—Pancreatic cancer**

- In the figure above, you’ll see the upper right and the lower left are axial views of the patient
- What we’re basically trying to show you is what’s happening with the pancreas
- The point of this is that in all but the bottom right photo, it’s not entirely clear that there is something nefarious going on in the pancreas
- But in the bottom right, it lights up very dark—which is to say that it is a very firm mass in the pancreas, which in this case turned out to be a very early stage pancreatic cancer that was otherwise missed.

![](https://peterattiamd.com/wp-content/uploads/2021/07/f16-prenuvo-breast-cancer-ama25-1024x628.png)

**Figure 16. Prenuvo MRI versus conventional MRI—Breast cancer**

- In the figure above, the upper right and lower left are showing you foot up view of a person cut in an axial manner
- What we’re trying to look at here is the left breast
- In this case, the patient has very dense breast tissue—a woman with very dense breast tissue is going to easily have a mammogram that’s going to make mistakes
- And it can make mistakes in both directions
- interestingly here, the mammogram did not identify a tumor
- But what you do see is the dark tissue on the DWI, which is the bottom right
- Again, the DWI is not an anatomically attractive image
- In other words, you’re doing this just to understand how firm the tissue is, and then to have that correspond with the anatomic information
- In this case, it did ultimately end up corresponding to an eight millimeter high ductal breast cancer
- This is an aggressive cancer that unfortunately would have been missed not just by mammogram, but also would have been missed by traditional MRI

## Summary of Peter’s approach to cancer screening [53:45]

> “We screen often, we screen early, and we screen aggressively.” —Peter Attia

**Important tests**

- Widely utilizing the liquid biopsy
- utilizing the full body MRI with diffusion-weighted imaging
- The following Peter encourages to do frequently:
  - Mammography
  - cervical exam
  - Colonoscopy
  - Endoscopy
  - dermatologic exam
  - ophthalmologic exam for ocular melanoma
  - In men, PSA with PSA velocity, PSA volume — and if suspicion is high, they will do a [Four-kallikrein test (4k score)](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2891337/)

**Tailed to the individual**

- All of this is tailored to a person — they don’t have an algorithm that they would apply to all people
- Some patients are getting a colonoscopy every year because they’re finding polyps every year that are tubular adenomas that are precursors to cancer
- Other patients are going to get colonoscopy every five years
- By most people’s standards, Peter is on the far end of the spectrum with screening
- But this approach comes at a cost — A financial cost, and at the cost of the risk of identifying **false positives**
- But by stacking these things, so far it has not yet led to any unnecessary procedures for his patients
- For example, when his patients have had suspicious findings on one test—like an elevated 4K score— it has not led to a biopsy of the prostate, but it has led to a multiplanar MRI of the prostate that has shown this is a very low concern

> “I can’t say. . .that this is the approach that everyone should take. But I hope that this discussion at least makes it easier for people to understand another way to think about it beyond the standard approach.” —Peter Attia

§

## Selected Links / Related Material

**Five-year survival rates of non-metastatic, local breast cancer are 99%**: [Breast Cancer: Statistics](https://www.cancer.net/cancer-types/breast-cancer/statistics#:~:text=The%20average%205%2Dyear%20survival,with%20this%20disease%20is%2099%25.) | (cancer.net) [8:00]

**Five-year survival rates of metastatic breast cancer is 28%**: [Breast Cancer – Metastatic: Statistics](https://www.cancer.net/cancer-types/breast-cancer-metastatic/statistics) | (cancer.net) [8:00]

**Interactive spreadsheet for determining the predictive value of cancer screening tests**: [How to interpret screening tests: video, spreadsheet, and primer](https://peterattiamd.com/how-to-interpret-screening-tests-video-spreadsheet-and-primer/) | Peter Attia (peterattiamd.com) [19:30]

**Company developing liquid biopsy technology**: [GRAIL](https://grail.com/) | (grail.com) [33:45]

**Podcast discussing prostate cancer with Ted Schaeffer**: [#39 – Ted Schaeffer, M.D., Ph.D.: How to catch, treat, and survive prostate cancer](https://peterattiamd.com/tedschaeffer/) | Peter Attia (peterattiamd.com)[40:15]

**Podcast discussing diffusion-weighted MRIs**: [#61 – Rajpaul Attariwala, M.D., Ph.D.: Cancer screening with full-body MRI scans and a seminar on the field of radiology](https://peterattiamd.com/rajpaulattariwala/) | Peter Attia (peterattiamd.com) [45:45, 49:45]

§

## People Mentioned

- [Ted Schaeffer](https://dr-schaeffer.com/) [40:15]
- [Raj Attariwala](https://peterattiamd.com/rajpaulattariwala/) [49:45]

§