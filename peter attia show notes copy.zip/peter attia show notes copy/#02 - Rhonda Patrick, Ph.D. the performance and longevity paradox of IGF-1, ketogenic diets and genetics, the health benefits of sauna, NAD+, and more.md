# #02 – Rhonda Patrick, Ph.D.: the performance and longevity paradox of IGF-1, ketogenic diets and genetics, the health benefits of sauna, NAD+, and more

**Source:** [https://peterattiamd.com/rhondapatrick/](https://peterattiamd.com/rhondapatrick/)

---

[Rhonda Patrick, Ph.D.](https://twitter.com/foundmyfitness) and I go on a Nerd Safari into the jungle of health, nutrition, fitness, performance, and longevity. We visit IGF-1 and whether there’s a tradeoff between having high or low levels. We discuss the PPARs (receptor proteins) and genetic polymorphisms. Does Rhonda think there’s any benefit in a NAD+ booster for health and longevity? Can saunas lower the risk of heart disease, dementia, and all-cause mortality? We dig into those questions…and a lot more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

Rhonda is a wealth of knowledge and was the perfect companion to explore several interesting topics in this episode. She puts a great deal of thought and effort into her research, and it really shows in this conversation.

![The Peter Attia Drive](images/rhondapatrick/the_Drive_public.png)

Play

#02 - Rhonda Patrick, Ph.D.: the performance and longevity paradox of IGF-1, ketogenic diets and genetics, the health benefits of sauna, NAD+, and more

#02 - Rhonda Patrick, Ph.D.: the performance and longevity paradox of IGF-1, ketogenic diets and genetics, the health benefits of sauna, NAD+, and more

1x15s30s

0:001:49:41

## We discuss:

- What Rhonda believes differently today than she did a few years ago;
- The paradox of GH/IGF-1 in performance and longevity;
- The role of PPAR in fat metabolism and ketogenic diets;
- The possible genetic explanations for why some patients don’t respond well to a ketogenic diet;
- The health benefits of heat and cold exposure;
- NAD+; and
- More.

## Show Notes

What Rhonda believes differently today versus 5 years ago? [5:40]

Calorie restriction and IGF reduction. Is it the best way to boost longevity? [6:30]

Rhonda’s changing opinion on the ketogenic diet. [9:00]

Peter’s experience with the ketogenic diet [10:30]

Exogenous ketones: Rhonda’s personal experience. [13:00]

Diet-induced ketosis, purported benefits and detriments, limitations of current studies, and what Peter would like to see in a future study. [15:30]

The practicality of the ketogenic diet and how to get your nutrients. [16:45]

The IGF-1 paradox, is it “good” or “bad?” [21:00]

Misconceptions about protein levels in the ketogenic diet. [22:00]

Intro to PPAR alpha and PPAR gamma, polymorphisms that impact fatty acid metabolism, ketogenesis, and how we react to saturated fat. [23:00]

Saturated fat and genetic variants that may affect how we respond to consuming it. [25:30]

How certain genes variants may affect certain people’s reaction to saturated fat. [29:00]

Rhonda has developed a [genetic testing tool](https://www.foundmyfitness.com/genetics) available to the public. [30:00]

Why some people have trouble producing ketones and how exercise and fasting may be the crucial piece for getting over the hump. [31:00]

Rhonda’s approach to eating/fasting/exercise and using exogenous ketones by [HVMN](https://hvmn.com/). [34:45]

Can ketone esters be used to reduce blood glucose levels? [41:15]

[Acarbose](https://en.wikipedia.org/wiki/Acarbose) for controlling blood glucose. [41:45]

Peter and Rhonda share their evolving understanding of the IGF-1 literature. [42:15]

Only the germ cells in *C. elegans* divide, which may make cancer in this organism fundamentally different than humans. “Nematodes have a fixed, genetically determined number of cells, a phenomenon known as eutely. The adult hermaphrodite has exactly 959 cells. The male *C. elegans* has 1031 cells. The number of cells does not change after cell division ceases at the end of the larval period, and subsequent growth is due solely to an increase in the size of individual cells.” [[Wikipedia](https://en.wikipedia.org/wiki/Caenorhabditis_elegans)]

Do we want low or high IGF-1? Or is “cycling” the key? [48:00]

![](https://peterattiamd.com/wp-content/uploads/2018/06/null-1.png)

Figure. Predicted HR for the association between IGF-I and all-cause mortality. [Burgers et al., 2011]

Image credit: [Meta-analysis and dose-response metaregression: circulating insulin-like growth factor I (IGF-I) and mortality](https://www.ncbi.nlm.nih.gov/pubmed/21795450) (Burgers et al., 2011)

![](https://peterattiamd.com/wp-content/uploads/2018/06/null-2.png)

Figure. Relationship between serum IGF-1 levels and risk of (A) all-cause mortality (B) cancer mortality and (C) cardiovascular disease (CVD) mortality. [Svensson et al., 2012]

Image credit: [Both Low and High Serum IGF-I Levels Associate with Cancer Mortality in Older Men](https://academic.oup.com/jcem/article/97/12/4623/2536566) (Svensson et al., 2012)

The important role that IGF-1 plays in muscle and brain tissue through exercise. [50:00]

Efficacy of prolonged fasting for cancer, autoimmune diseases, and other afflictions. [51:00]

Prolonged fasting and cancer, how it could maybe be apart of standard of care in the near future. [53:00]

Can chemo patients benefit from fasting and certain dietary protocols? [54:15]

Can fasting help with the response to, and recovery from, invasive operations? [55:00]

Importance of exercise for brain health. [59:30]

VO2 max, cardiorespiratory fitness, strength training, and how it affects our health. [1:03:15]

Can lowering inflammation be a key to extending life? [1:06:30]

Peter shares his hope/vision for the future of personalized health protocols. [1:11:45]

Sauna, and the growing evidence for the benefits of heat therapy. [1:12:30]

Does sauna have an impact on sleep? [1:13:30]

Saunas and the healthy-user bias, a critical look at the literature. [1:14:15]

The overlapping physiological responses of heat therapy and exercise. [1:16:15]

Saunas as an antidepressant? [1:17:15]

Different types of saunas and which one Rhonda likes best. [1:18:15]

Can saunas act as an anti-inflammatory and improve insulin sensitivity? [1:20:15]

Can saunas help prevent neurodegeneration? [1:21:45]

What kind of disease is dementia? And how might ketones and saunas help? [1:22:15]

Cold therapy vs heat therapy, similarities, and differences. [1:24:30]

Can we stack hot and cold therapy to maximize the benefits? [1:28:30]

Cold therapy and mitochondrial biogenesis. [1:29:00]

How cold therapy can blunt hypertrophy from strength training. [1:31:15]

A primer on NAD+/NADH, its effect on lifespan/healthspan, and a review of the supplements. [1:32:45]

PARP, an important enzyme for DNA repair, needs NAD+ for fuel. [1:34:30]

What causes NAD+ to decrease as we age? [1:35:00]

Could metformin negatively affect the NAD+ to NADH ratio? [1:36:15]

Evidence for NAD+ supplements. [1:37:00]

Can we increase NAD+ levels with fasting? [1:38:00]

Peter asks Rhonda, “What is the most interesting question you don’t yet know the answer to but you feel like is knowable?” [1:39:15]

Rapamycin, the most promising life-extension drug? [1:42:30]

The next medical frontier: specificity and selectivity of drugs. [1:45:00]

Where you can find Rhonda and her work. [1:46:45]

§

## Selected Links / Related Material

- [The peroxisome proliferator-activated receptor: A family of nuclear receptors role in various diseases](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3255347/) (Tyagi et al., 2011)
- [Pathway maps — PPAR Pathway](https://pathwaymaps.com/maps/546) | pathwaymaps.com
- [Fasting, circadian rhythms, and time restricted feeding in healthy lifespan](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5388543/) (Longo and Panda, 2016)
- [Peroxisome proliferator–activated receptor α mediates the adaptive response to fasting](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC408372/) (Kersten et al., 1999)
- Nature study on Lemurs: [Caloric restriction increases lifespan but affects brain integrity in grey mouse lemur primates](https://www.nature.com/articles/s42003-018-0024-8) (Pifferi et al., 2018)
- [Ketogenic Diet Reduces Midlife Mortality and Improves Memory in Aging Mice](https://www.ncbi.nlm.nih.gov/pubmed/28877458) (Newman et al., 2017)
- [A Ketogenic Diet Extends Longevity and Healthspan in Adult Mice](https://www.ncbi.nlm.nih.gov/pubmed/28877457) (Roberts et al., 2017)
- Rhonda Patrick’s [genetic testing tool](https://www.foundmyfitness.com/genetics) available to the public that looks at APOE, PPAR, and other polymorphisms | FoundMyFitness.com
- [The first long-lived mutants: discovery of the insulin/IGF-1 pathway for ageing](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3001308/) (Kenyon, 2011)
- [NF-κB signaling in inflammation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5661633/) (Liu et al., 2017)
- [Dr. Jari Laukkanen on Sauna Use for the Prevention of Cardiovascular & Alzheimer’s Disease](https://www.foundmyfitness.com/episodes/jari-laukkanen) | FoundMyFitness podcast
- [Dr. Charles Raison on Depression, the Immune-Brain Interface & Whole-Body Hyperthermia](https://www.foundmyfitness.com/episodes/charles-raison) | FoundMyFitness podcast
- [Heat stress increases insulin sensitivity in pigs](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4562564/) (Sanz Fernandez et al., 2015)
- [Navigating Metabolism](https://www.amazon.com/Navigating-Metabolism-Navdeep-Chandel/dp/1621821293) by Navdeep Chandel
- [A randomized controlled trial to establish effects of short-term rapamycin treatment in 24 middle-aged companion dogs](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5411365/) (Urfer et al., 2017)
- [New agents that target senescent cells: the flavone, fisetin, and the BCL-XL inhibitors, A1331852 and A1155463](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5391241/) (Zhu et al., 2017)
- [A C. elegans mutant that lives twice as long as wild type](https://www.ncbi.nlm.nih.gov/pubmed/8247153) (Kenyon et al., 1993)
- [IGF1 as predictor of all cause mortality and cardiovascular disease in an elderly population](https://www.ncbi.nlm.nih.gov/pubmed/18931092) (Andreassen et al., 2009)
- [Both Low and High Serum IGF-1 Levels Associate With Increased Risk of Cardiovascular Events in Elderly Men](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4258605/) (Carlzon et al., 2014)
- [Both Low and High Serum IGF-I Levels Associate with Cancer Mortality in Older Men](https://www.ncbi.nlm.nih.gov/pubmed/23015658) (Svensson et al., 2012)
- FMD decreased the size of multiple organs/systems: [A periodic diet that mimics fasting promotes multi-system regeneration, enhanced cognitive performance and healthspan](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4509734/) (Brandhorst et al., 2015)
- [Fasting: Molecular Mechanisms and Clinical Applications](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3946160/) (Longo and Mattson, 2014)
- [Comparative signaling pathways of insulin-like growth factor-1 and brain-derived neurotrophic factor in hippocampal neurons and the role of the PI3 kinase pathway in cell survival](https://www.ncbi.nlm.nih.gov/pubmed/15140184) (Zheng and Quirion, 2004)
- [The effect of exercise on IGF-I on muscle fibers and satellite cells](https://www.ncbi.nlm.nih.gov/pubmed/22201867) (Shefer and Benayahu, 2012)
- [Diet mimicking fasting promotes regeneration and reduces autoimmunity and multiple sclerosis symptoms](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4899145/) (Choi et al., 2016)
- [Fasting Cycles Retard Growth of Tumors and Sensitize a Range of Cancer Cell Types to Chemotherapy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3608686/) (Lee et al., 2012)
- [Fasting and cancer treatment in humans: A case series report](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2815756/) (Safdie et al., 2009)
- [Is Overnight Fasting before Surgery Too Much or Not Enough? How Basic Aging Research Can Guide Preoperative Nutritional Recommendations to Improve Surgical Outcomes: A Mini-Review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5722208/) (Longchamp et al., 2017)
- [Mechanisms of Risk Reduction in the Clinical Practice of Alzheimer’s Disease Prevention](https://www.frontiersin.org/articles/10.3389/fnagi.2018.00096/full) (Schelke et al., 2018)
- [Effect of 24 Sessions of High-Intensity Aerobic Interval Training Carried out at Either High or Moderate Frequency, a Randomized Trial](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0088375) (Hatle et al., 2014)
- [Inflammation, But Not Telomere Length, Predicts Successful Ageing at Extreme Old Age: A Longitudinal Study of Semi-supercentenarians](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4634197/) (Arai et al., 2015)
- [Interleukin-6 directly increases glucose metabolism in resting human skeletal muscle](https://www.ncbi.nlm.nih.gov/pubmed/17363741) (Glund et al., 2007)
- [Antiinflammatory Therapy with Canakinumab for Atherosclerotic Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa1707914) (Ridker et al., 2017)
- [CANTOS Validates Role Of Inflammation In Heart Disease](https://www.cardiobrief.org/2017/08/27/cantos-validates-role-of-inflammation-in-heart-disease/) (Cardiobrief, 2017) [1:10:00]
- [Cardiovascular Inflammation Reduction Trial (CIRT)](https://clinicaltrials.gov/ct2/show/NCT01594333) (ClinicalTrials.gov)
- [Methotrexate and Cardiovascular Protection: Current Evidence and Future Directions](https://journals.sagepub.com/doi/full/10.1177/1179559X17741289) (Mangoni et al., 2017)
- [NIH Halts Large Cardiovascular Inflammation Reduction (CIRT) Trial](https://www.cardiobrief.org/2018/05/21/nih-halts-large-cardiovascular-inflammation-reduction-cirt-trial/) (CardioBrief, 2017)
- [Acute effects of sauna bathing on cardiovascular function](https://www.nature.com/articles/s41371-017-0008-z) (Laukkanen et al., 2018)
- [Association between sauna bathing and fatal cardiovascular and all-cause mortality events](https://www.ncbi.nlm.nih.gov/pubmed/25705824) (Laukkanen et al., 2015)
- [Sauna bathing is inversely associated with dementia and Alzheimer’s disease in middle-aged Finnish men](https://academic.oup.com/ageing/article/46/2/245/2654230) (Laukkanen et al., 2016)
- [Sauna bathing and systemic inflammation](https://www.ncbi.nlm.nih.gov/pubmed/29209938) (Laukkanen and Laukkanen, 2018)
- [Whole-Body Hyperthermia for the Treatment of Major Depressive Disorder: A Randomized Clinical Trial](https://www.ncbi.nlm.nih.gov/pubmed/27172277) (Janssen et al., 2015)
- [Malaise, Melancholia and Madness: The Evolutionary Legacy of an Inflammatory Bias](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3678371/) (Raison and Miller, 2013)
- [Heat stress acutely activates insulin-independent glucose transport and 5′-AMP-activated protein kinase prior to an increase in HSP72 protein in rat skeletal muscle](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4632964/) (Goto et al., 2015)
- [Novel ketone diet enhances physical and cognitive performance](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5102124/) (Murray et al., 2016)
- [Can Ketones Help Rescue Brain Fuel Supply in Later Life? Implications for Cognitive Health during Aging and the Treatment of Alzheimer’s Disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4937039/) (Cunnane et al., 2016)
- [Heterologous mu-opioid receptor adaptation by repeated stimulation of kappa-opioid receptor: up-regulation of G-protein activation and antinociception](https://www.ncbi.nlm.nih.gov/pubmed/12753076) (Narita et al., 2013)
- [Chronic cold exposure potentiates CRH-evoked increases in electrophysiologic activity of locus coeruleus neurons](https://www.biologicalpsychiatryjournal.com/article/S0006-3223(00)01057-X/abstract) (Jedema et al., 2001)
- [The effects of exercise and cold exposure on mitochondrial biogenesis in skeletal muscle and white adipose tissue](https://www.ncbi.nlm.nih.gov/pubmed/28715885) (Chung et al., 2017)
- Exercise and mitochondrial biogenesis: [Physiological adaptations to interval training and the role of exercise intensity](https://www.ncbi.nlm.nih.gov/pubmed/27748956)
- [Physiological adaptations to interval training and the role of exercise intensity](https://physoc.onlinelibrary.wiley.com/doi/full/10.1113/JP273196) (MacInnis and Gibala, 2016)
- [Post-exercise cold water immersion attenuates acute anabolic signalling and long-term adaptations in muscle to strength training](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4594298/) (Roberts et al., 2015)
- [Regulation of muscle growth and regeneration by the immune system](https://www.nature.com/articles/nri.2016.150?foxtrotcallback=true) (Tidball, 2017)
- [Why NAD+ Declines during Aging: It’s Destroyed](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(16)30244-3) (Schultz and Sinclair, 2016)
- [NAD+ content and its role in mitochondria](https://www.ncbi.nlm.nih.gov/pubmed/25308486) (Li and Sauve, 2015)
- [ARTD1 (PARP1) activation and NAD+ in DNA repair and cell death](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4252787/) (Fouquerel and Sobol, 2014)
- [Role of Nicotinamide in DNA Damage, Mutagenesis, and DNA Repair](https://www.hindawi.com/journals/jna/2010/157591/) (Surjana et al., 2010)
- [NAD+: The convergence of DNA repair and mitophag](https://www.tandfonline.com/doi/full/10.1080/15548627.2016.1257467)y (Fang and Bohr, 2016)
- [Inhibition of mitochondrial complex I improves glucose metabolism independently of AMPK activation](https://onlinelibrary.wiley.com/doi/full/10.1111/jcmm.13432) (Hou et al., 2017)
- [A need for NAD+ in muscle development, homeostasis, and aging](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5840929/) (Goody and Henry, 2018)
- [NAD+ replenishment improves lifespan and healthspan in Ataxia telangiectasia models via mitophagy and DNA repair](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5777858/) (Fang et al., 2018)
- [Repeat dose NRPT (nicotinamide riboside and pterostilbene) increases NAD+ levels in humans safely and sustainably: a randomized, double-blind, placebo-controlled study](https://www.nature.com/articles/s41514-017-0016-9) (Dellinger et al., 2018)
- [Chronic nicotinamide riboside supplementation is well-tolerated and elevates NAD+ in healthy middle-aged and older adults](https://www.nature.com/articles/s41467-018-03421-7) (Martens et al., 2018)
- [From rapalogs to anti-aging formula](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5482593/) (Blagosklonny, 2017)
- [Transient rapamycin treatment can increase lifespan and healthspan in middle-aged mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4996648/) (Bitto et al., 2016)
- [A randomized controlled trial to establish effects of short-term rapamycin treatment in 24 middle-aged companion dogs](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5411365/) (Urfer et al., 2017)
- 2009 study where there was a greater survival benefit for females than males; Increased mean and maximal lifespan in both males and females when (rapamycin) initiated at 20 months of age: [Rapamycin fed late in life extends lifespan in genetically heterogeneous mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) (Harrison et al., 2009)
- Increased mean and maximal lifespan in both males and females when (rapamycin) initiated at 20 months of age: [Rapamycin, But Not Resveratrol or Simvastatin, Extends Life Span of Genetically Heterogeneous Mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3021372/) (Miller et al., 2011)
- When ~ equal blood levels of rapamycin were achieved, the response was also about equivalent in females and males: [Rapamycin-mediated lifespan increase in mice is dose and sex dependent and metabolically distinct from dietary restriction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4032600/) (Miller et al., 2014)
- [Cellular Senescence: A Translational Perspective](https://www.ncbi.nlm.nih.gov/pubmed/28416161) (Kirkland and Tchkonia, 2017)
- [The Achilles’ heel of senescent cells: from transcriptome to senolytic drugs](https://www.ncbi.nlm.nih.gov/pubmed/25754370) (Zhu et al., 2015)

§

## People Mentioned

- [Eric Verdin](https://www.buckinstitute.org/content/eric-verdin-md-president-and-ceo)
- [Satchin Panda](https://www.salk.edu/scientist/satchidananda-panda/)
- [Dom D’Agostino](https://www.ketonutrition.org/about/)
- [Tom Dayspring](https://truehealthdiag.com/leadership/thomas-dayspring/)
- [Stephen Phinney](https://www.virtahealth.com/team)
- [Kevin Rose](https://www.kevinrose.com)
- [Geoff Woo](https://hvmn.com/team/geoffrey-woo)
- [Cynthia Kenyon](https://www.calicolabs.com/cynthia-kenyon/)
- [Andrew Dillon](https://en.wikipedia.org/wiki/Andrew_Dillon)
- [Valter Longo](https://valterlongo.com)
- [Doug Green](https://www.stjude.org/directory/g/douglas-green.html)
- [Joseph Opferman](https://www.stjude.org/directory/o/joseph-opferman.html)
- [James Mitchell](https://www.hsph.harvard.edu/james-mitchell/)
- [Richard Isaacson](https://weillcornell.org/risaacson)
- [Tim Ferriss](https://tim.blog/about/)
- [Ryan Flaherty](https://ryanjflaherty.com)
- [Jeanne Calment](https://en.wikipedia.org/wiki/Jeanne_Calment)
- [Jari Laukkanen](https://twitter.com/laukkanenjari)
- [Richard Veech](https://irp.nih.gov/pi/richard-veech)
- [Kieran Clark](https://www.dpag.ox.ac.uk/team/kieran-clarke)
- [Nav Chandel](https://www.chandellab.com/people)
- [Ralph Deberardinis](https://profiles.utsouthwestern.edu/profile/99018/ralph-deberardinis.html)
- [David Sabatini](https://sabatinilab.wi.mit.edu/membersDS.html#p7TPMc1_1)
- [Matt Kaeberlein](https://kaeberleinlab.org/people/matt-kaeberlein)

§

![](https://peterattiamd.com/wp-content/uploads/2018/06/rhonda-patrick-drive-image-provided-by-Rhonda-500x500.jpg)

##### Rhonda Patrick, Ph.D.

Rhonda Perciavalle Patrick has a Ph.D. in biomedical science from the University of Tennessee Health Science Center, Memphis TN and St. Jude Children’s Research Hospital, Memphis TN. She also has a Bachelor’s of Science degree in biochemistry/chemistry from the University of California, San Diego. She has done extensive research on aging, cancer, and nutrition. She did her graduate research at St. Jude Children’s Research Hospital where she investigated the link between mitochondrial metabolism, apoptosis, and cancer. Her groundbreaking work discovered that a protein that is critical for cell survival has two distinct mitochondrial localizations with disparate functions, linking its anti-apoptotic role to a previously unrecognized role in mitochondrial respiration and maintenance of mitochondrial structure. Her dissertation findings were published in the 2012 issue of [Nature Cell Biology](https://www.ncbi.nlm.nih.gov/pubmed/22544066).

Dr. Patrick trained as a postdoctoral fellow at Children’s Hospital Oakland Research Institute with [Dr. Bruce Ames](https://www.bruceames.org/). She investigated the effects of micronutrient (vitamins and minerals) inadequacies on metabolism, inflammation, DNA damage, and aging and whether supplementation can reverse the damage. In addition, she also investigated the role of vitamin D in brain function, behavior, and other physiological functions. In February of 2014 she published a paper in [FASEB](https://www.fasebj.org/content/early/2014/02/14/fj.13-246546.abstract?papetoc) on how vitamin D regulates serotonin synthesis and how this relates to autism.

Dr. Patrick has also done research on aging at the Salk Institute for Biological Sciences. At the Salk she investigated what role insulin signaling played in protein misfolding, which is commonly found in neurodegenerative diseases.

She frequently engages the public on topics including the role [micronutrient](https://en.wikipedia.org/wiki/Micronutrient) deficiencies play in [diseases of aging](https://en.wikipedia.org/wiki/Aging-associated_diseases), the role of genetics in determining the effects of nutrients on a person’s health status, benefits of exposing the body to [hormetic](https://en.wikipedia.org/wiki/Hormesis) stressors, such as through exercise, [fasting](https://en.wikipedia.org/wiki/Intermittent_fasting), [sauna](https://en.wikipedia.org/wiki/Sauna) use or heat stress, or various forms of cold exposure, and the importance of [mindfulness](https://en.wikipedia.org/wiki/Mindfulness), stress reduction, and [sleep](https://en.wikipedia.org/wiki/Sleep). It is Dr. Patrick’s goal to challenge the status quo and encourage the wider public to think about health and longevity using a proactive, preventative approach. [ [FoundMyFitness.com](https://www.foundmyfitness.com/about-dr-rhonda-patrick)]

Rhonda on Facebook: [FoundMyFitness](https://www.facebook.com/foundmyfitness/)

Rhonda on Instagram: [@foundmyfitness](https://www.instagram.com/foundmyfitness/?hl=en)

Rhonda on Twitter: [@foundmyfitness](https://twitter.com/foundmyfitness)

Rhonda’s website: [FoundMyFitness.com](https://www.foundmyfitness.com/)

Rhonda’s podcast: [FoundMyFitness](https://itunes.apple.com/us/podcast/foundmyfitness/id818198322?mt=2)