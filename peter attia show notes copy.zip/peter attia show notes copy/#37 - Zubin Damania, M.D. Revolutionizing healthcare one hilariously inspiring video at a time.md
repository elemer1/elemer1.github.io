# #37 – Zubin Damania, M.D.: Revolutionizing healthcare one hilariously inspiring video at a time

**Source:** [https://peterattiamd.com/zubindamania/](https://peterattiamd.com/zubindamania/)

---

##### Check out more content from Zubin Damania, M.D.:

- *(Jan 21, 2019)* [#37 – Revolutionizing healthcare one hilariously inspiring video at a time](/zubindamania/)
- *(Jan 3, 2022)* [#189 – COVID Part 1: Current state of affairs, Omicron, and a search for the end game](/covid-19-current-state-omicron/)
- *(Jan 24, 2022)* [#192 – COVID Part 2: Masks, long COVID, boosters, mandates, treatments, and more](/covid-part2/)

In this episode, Zubin Damania, a.k.a. Zdogg MD, a Stanford trained physician and founder of Turntable Health, discusses his evolution from disillusioned doctor suffering burnout to leading the charge for a radical shift in how we practice medicine. We also go down the rabbit hole on all sorts of juicy topics from meditation to nutrition to the nature of consciousness itself.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/zubindamania/the_Drive_public.png)

Play

#37 - Zubin Damania, M.D.: Revolutionizing healthcare one hilariously inspiring video at a time

#37 - Zubin Damania, M.D.: Revolutionizing healthcare one hilariously inspiring video at a time

1x15s30s

0:002:51:09

## We discuss:

- Med school antics [7:00];
- Hierarchies in healthcare, physician burnout, and a broken system [20:15];
- Why Zubin left medicine, and what lead to the ZdoggMD persona [31:30];
- Peter’s tough decision to leave medicine [44:00];
- Benefits and challenges of meditation [54:15];
- Zdogg’s theory of consciousness [1:11:30];
- Nutrition: Peter’s current strategy with patients [1:31:00];
- The anti-vaccine dispute [1:38:15]
- The common thread of all “diets”, the obesity epidemic, and Peter’s dream experiment [1:44:30];
- Do we have free will? And how do we make better decisions and learn from our mistakes? [1:55:15];
- Peter’s current obsessions: fasting and rapamycin, measuring autophagy, and becoming a kickass 100-year-old [2:03:15];
- Reforming the healthcare payment model [2:14:45];
- How to find doctors like Peter and Zubin in your area [2:28:15];
- Zdogg’s amazing videos [2:31:15]; and
- More.

**Video: Peter and Zubin both recorded this interview.****Here is Zubin’s video of the interview:**

[DR. PETER ATTIA RAPS W/ZDOGGMD](https://zdoggmd.com/incident-report-218/) | ZDoggMD.com

§

## Show Notes

## Med school antics [7:00]

- Peter 1 year behind Zubin
- Zubin went to [UCSF](https://en.wikipedia.org/wiki/University_of_California,_San_Francisco) for med school
- Zubin completed his residency at Stanford, which is where he and Peter met
- They worked together when Zubin was an internist and Peter was a fourth year med student
- Peter reflects fondly: *“I could not imagine how much one could enjoy a rotation of internal medicine.”*

Peter left an impression on Zubin ⇒ *“I’ve taken care of a lot of people, I’ve been through a lot of teams. There are very few people I remember. I remember fucking Peter Attia.”*

- Zubin describes Peter as the cocky guy that was gonna do general surgery so he wasn’t worth spending time to teach him anything
- But then Peter sat down and the entire monologue of [Dr. Evil talking to the therapist from Austin Powers](https://www.youtube.com/watch?v=lTJj4wbmAhk) and the therapist and won Zubin over

Peter tells the back story

- Peter originally thought first thought he was going to be a pediatric oncologist
- But during the fourth day of rotation for pediatrics, Peter tried out his Austin Powers jokes pretending to be [Fat Bastard](https://en.wikipedia.org/wiki/Fat_Bastard) wanting to eat the fat babies
- Not one person smiled… *“They were mortified by my existence.”*
- Zubin: *“we have a very similar disturbed sense of humor.”*

Zubin’s med school antics

- He used comedy to bring levity to stressful situations
- Many times it got him in trouble and he was once told, *“Hey you speak and then think. You should just reverse that, or better yet, just think.”*

Final test to pass med school

- When they were finishing med school, there was a transition from a paper test to a live patient/actor test with made-up scenarios
- It drove Peter insane having to pretend and act out these fake situations
- Towards the end, he had had enough, decided to pretend to be Dr. Evil
- They freaked out and ended the session
- The dean calls Peter and actually tells Peter he thought it was hilarious
- *“That’s like the highlight of my medical school.”* says Peter

Zubin’s graduation speech

- Zubin’s antics can be summed up quite elegantly in his hilarious **UCSF graduation speech from 1999**

## Hierarchies in healthcare, physician burnout, and a broken system [20:15]

The problem with the hierarchies:

- **Zubin**: They either have a tendency to dominate those underneath or to treat them as equals inappropriately. In which case the lower down in the hierarchy don’t have the competence. What they need is actually to be trained and lifted and supported and instead it’s like, why aren’t you at the level that I’m asking you to be. It’s interesting. It becomes tough in the higher echelons of performance and stuff.
- **Peter**: I really loved hierarchy when I could respect the person I was reporting to…but when I encountered somebody I didn’t think that they were good enough, or smart enough, or knew enough, I wouldn’t hesitate to just steamroll them. That gets you into a lot of trouble.
- **Zubin**: It speaks to our medical training in general that it really is about kissing the ring of the authority figure so one day you’ll be the ring that’s kissed. That’s the majority of our training. The first few years are, we’re fed a bunch of information, 50% of which is wrong. . .but when you start  questioning things is when you get told you are out of line.
- **Peter**: The challenge comes when you have to make a decision that is probably not the best decision for the patient, but it’s the one that’s coming down from the person just above you.

Peter tells a revealing story

- During residency, he encountered a patient that needed to be taken to the OR (operating room)
- But when Peter called the chief resident to let him know (which would have required the chief to come in to the hospital), Peter was told to deal with it himself
- So Peter followed orders but in his heart he knew he wasn’t doing the right thing for the patient
- In retrospect, Peter thinks he should have gone over the head of the chief resident
- But at the time Peter knew he would have paid an enormous personal price for that through the duration of his residency
- Peter has felt shame and guilt about this for over 15 years until he finally found out the patient was fine and doing well (the mother of the patient recognized Peter on [his appearance on the Dr. Oz show](https://www.doctoroz.com/episode/government-out-undermine-your-health?video_id=3479158688001))

**Physician burnout or moral injury?**

- Zubin says that Peter’s story is at the center of what we’re now calling “burnout”
- But Zubin thinks it something else called “moral injury”
- ⇒ [Physicians aren’t ‘burning out.’ They’re suffering from moral injury](https://www.statnews.com/2018/07/26/physicians-not-burning-out-they-are-suffering-moral-injury/)
- *Moral injury can be summed up as follows* ⇒ You were in a position where all the system was arrayed to make it very difficult for you to do the right thing for the patient. You knew it was the right thing. You knew the patient needed to have this done and you knew that it would cause serious consequences to you to have it done. Then you had to live with the shame and the guilt of NOT having done something that was self-destructive, that was not in your best interest, to help this other person.

> *“Now, let’s take Peter’s story and how he suffered and scale it by a thousand times every single day when we have to take care of patients, we know full well what needs to be done. We know where the fuck ups are and where things have gone wrong and where our system has failed and we are powerless. Not only powerless, if we do the right thing, we will lose money, we will lose time with our family. We’ll be charting all night and it still may not work for the patient.”*

## Why Zubin left medicine, and what lead to the ZdoggMD persona [31:30]

What happened after residency?

- Wanted to do UGI (GI tract) and hepatology but found it to be miserable and tedious and mind-numbing and it didn’t sit well for him morally
- “I loved the way that digestion works and the mind, body, gut connection I thought was fascinating.”
- But had a terrible mentor who was just scoping, routinely doing colonoscopies and EGDs, it was horrible
- The idea that that could scale for a career was mind-numbing to me
- “I like talking to patients. I like the relationship and I like the physiology of it, talking to people about their issues because a lot of times [their afflictions] are deeply connected to the mindset. That’s what I love.”
- His humor started to get dark, told he was a bad influence on the interns
- It became more of a wall than a coping mechanism

> “I was starting to get disillusioned in general with medicine, because most of what we did seemed like bullshit. Most of what we did either harmed people or it just wasn’t thought out. It’s half baked. That causes a kind of moral distress.”

Left medicine and went into tech in Silicon Valley

- Did that for a year
- But learned that he needed the deep connection of human relationships to feel fulfilled
- This lead Zubin to a hospitalist gig (a dedicated in-patient physician who works exclusively in a hospital) at Stanford which he did for nine years

Working as a hospitalist

- Did it for nine years
- For the first 4 years he felt like he had found his niche, loved it
- What changed?
- “What changed was what’s been changing in medicine across the board which is the creep of medicine as business. . . medicine as assembly line, medicine as processes to be improved, not medicine as deep human relationship, that’s a sacred calling.”

Feeling burnout

- [EHR](https://www.healthit.gov/faq/what-electronic-health-record-ehr) was implemented and the focus became revenue generation
- He began taking his work home with him
- Tipping point is when they had their first daughter *“my burnout is expressing in how I’m treating my daughter.”*

Meeting with Tony Hsieh

- Zubin was making some videos and putting them on YouTube
- It got the attention of [Tony Hsieh](https://en.wikipedia.org/wiki/Tony_Hsieh) the CEO of Zappos (who went to Harvard with Zubin’s wife)
- Tony asked Zubin if he was happy, “Absolutely not. To see you living this life where you’re doing what you love and you’re financially successful and you’re affecting people’s lives.”
- ⇒ Peter and Zubin both recommend Tony’s book: [Delivering Happiness: A Path to Profits, Passion, and Purpose](https://www.amazon.com/Delivering-Happiness-Profits-Passion-Purpose/dp/0446576220)
- After this discussion with Tony, Zubin felt depressed, would cry in the shower
- Tony later asked Zubin what he wanted to do?
- “I did this speech for graduation. I felt so connected to the audience. I felt like I was revealing truth through humor that could help motivate people to change stuff. I would do that for a living.”

ZdoggMD was born

- Created ZdoggMD so Stanford wouldn’t figure out it was him
- Did these videos while working at the hospital full time for 2 years
- First video: [Colon Wars](https://www.youtube.com/watch?v=74oK6RFNmDg), a parody of talking about GI through the lens of Luke Skywalker going down the trench
- Next came **[Manhood in the Mirror,](https://www.youtube.com/watch?v=fypm_aeR5qA) which was the first big music parody of a testicular self-exam**

Going all in

- Tony Hsieh made Zubin a proposition, “Come to Vegas and do something that’s going to transform medicine that’s about you and about the community.”
- Zubin thought the idea was crazy, but wanted to do it
- Zubin’s wife was very encouraging: “She was the one who pushed me. . .I think the biggest decision you can make in your life is who you partner with.”
- So he quit his job, moved to Vegas, and started [Turntable Health](https://en.wikipedia.org/wiki/Turntable_Health)

**For more on Zubin’s story, check out his [TEDMED talk in 2013](https://www.youtube.com/watch?v=WeY_z0c_wMs)**

## Peter’s tough decision to leave medicine [44:00]

*“I loved the operating part. It was just there were too many things about the system I couldn’t stand. Then I came to that really hard decision. . . which was, ‘it would be great to stay if I could fix all of these things, but I can’t so I probably need to go.’”*

Peter left residency with 2 years left

- But he was miserable and wife said, “fix the things that are making you miserable or leave”
- So in 2005, Peter decided to leave medicine
- Where to go? He wasn’t sure: “I didn’t know if I should go into another specialty, leave medicine altogether, go into the lab full-time. I had just come back from NIH where I had spent two years in the lab. All of these options were spinning through my mind.”
- He ended up taking a job as a credit-risk modeler for [McKinsey & Company](https://en.wikipedia.org/wiki/McKinsey_%26_Company)

Did he hate residency at Johns Hopkins?

- Not at all, “I freaking loved that place”
- One of the best chapters in my life
- Peter loved the mentorship and being surrounded by so many amazing people, “the most skilled, gifted, remarkable surgeons, and the residents above me. . .I mean some of them were just gods to me.”

Peter has no narrative, so don’t ask him what it is. . .

- What does Peter say when people ask what he does for a living?
- The first is I’m a shepherd, and the second is I’m a race car driver.
- Peter’s obsessions and evolving interests change his path constantly
- *“The point is, I don’t have a narrative. I struggle with all of that stuff.”*
- ⇒ Zubin: “I always see you as this oscillating electron probability cloud wave, that what you settle on at any minute can be on how you’re observing yourself, or what you’re obsessed about at that moment. It’s always changing.”
- Peter: Truthfully, I think it’s just selfish. . .I don’t learn shit when I’m talking. When the other person’s talking, I get to learn, and I’m kind of selfish when it comes to desiring knowledge. . .and I don’t have to waste any of my time hearing myself say the same stupid thing.

## Benefits and challenges of meditation [54:15]

Book recommendation from Zubin: [The Mind Illuminated](https://www.amazon.com/Mind-Illuminated-Meditation-Integrating-Mindfulness/dp/1501156985)

- Zubin found meditation very challenging until this book and things improved vastly
- *“This is a goddam manual for nerds and for type A’s who want a process.”*

Meditation apps Zubin has used

- [Waking Up with Sam Harris](https://wakingup.com/)
- [Headspace](https://www.headspace.com/headspace-meditation-app)

The sub-mind system (described in The Mind Illuminated)

- Our mind is really like a boardroom where you’re projecting stuff on a screen, and that’s our conscious awareness
- These sub-minds are what’s doing the projecting
- We have an audio sub-mind, a visual sub-mind, and a narrating sub-mind that ties them together
- *“The liberating thing about that is that at any moment your next slice could be something completely different. It’s influenced by the momentum of the previous slices, but it is in itself an unknown and anything is possible.”*

**What got Zubin curious to start exploring mindfulness and meditation?**

- Moving to Vegas in 2012
- Always been a materialistic person
- Suddenly, people asking him, *are you happy?*
- Hippies, thought Zubin

*Transformative experience with marijuana*

- Had an experience with a potent sativa with an acquaintance who was a Bikram yoga instructor
- She basically broke Zubin down and destroyed his ego
- *“Like what a lying fraud, an imposter that I am. She starts noticing these things, and what happened is a protective mechanism to live with this thing I thought was myself was to dissolve that thing, and realize that wasn’t really me at all. The me is the awareness in which all this arises and moment to moment.”*
- *“That experience, combined with living in the desert of Vegas, and being told to basically reinvent yourself or go out of business was a* ***personal awakening for me****.”*

**Challenges of learning awareness and mindfulness meditation:**

Peter: *“When it comes to understanding consciousness, when it comes to understanding the nature of my mind, I feel like a complete moron.”*

⇒ Peter’s breakthroughs

- catching the narrative
- catching the self-talk
- and realizing the transient nature of emotions

*Seeing through the turbulence at the top of the mind*

- Meditation
- Psychedelics can also jumpstart the process
  - [Tim Ferriss](https://twitter.com/tferriss?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) and Peter [discussed psychedelics on The Drive](https://peterattiamd.com/timferriss/)
  - [Sam Harris](https://twitter.com/SamHarrisOrg?lang=en) and Peter also [discussed psychedelics on The Drive](https://peterattiamd.com/samharris/)

*How* [*Tim Ferriss*](https://twitter.com/timferriss?lang=en) *learned to use meditation*

- First, I’m going to use this to help me perform better
- Secondly,  I’m going to use it to quiet the demons
- Ultimately, you use it to actually understand and appreciate your mind and transform it, so that your day-to-day defiling thoughts and little voices, and the emotional reactivity are uprooted permanently

*Why learning meditation is so difficult*

- Peter found The Mind Illuminated very difficult to understand
- He had a little easier time understanding [Waking Up by Sam Harris](https://samharris.org/books/waking-up/) but admits that he still doesn’t understand about ⅓ of the book
- Peter recognizes that he is still in the infancy of his practice
- Uses swimming as an analogy
- He learned to swim as an adult and was frustrated watching other swimmers doing it with such ease compared to him
- Realized that others have been swimming (and meditating) for decades
- Uses the mantra, “You just haven’t earned it yet, baby.” to remind him to keep working
- He tries to remember this lesson when he finds himself getting a little frustrated trying to understand consciousness

*A helpful metaphor that Zdogg continually comes back to throughout the episode*

- From psychologist, [Jon Haidt](https://en.wikipedia.org/wiki/Jonathan_Haidt), he coined the [elephant and rider metaphor](https://en.wikipedia.org/wiki/Jonathan_Haidt#Elephant_and_rider_metaphor) to describe the two different parts of the brain
- The elephant is our limbic system, emotions, and unconscious
- The rider is the cortex on top that’s conscious, and the thinker and the planner
- *“The rider. . . is fucking completely beholden to this totally dumbass elephant”*
- Even when the rider has the information to make a rational decision, he can’t move until the big, strong elephant is on the same page
- To dive deeper into this [watch ZdoggMD explain it here](https://www.youtube.com/watch?v=GLQySJr-_uY)

*Zubin’s personal experience with mindfulness meditation*

- Meditation is something he uses by straight necessity, to alleviate personal suffering
- Practices an hour a day
- When you get lost in thought, you remember the intention and you come back
- You’re floating on the breath, and the body feels like this pulsing wave of energy, and you realize ”this is all just experience happening in the present moment”
- Zubin feels like there is a lot of benefit from spending time in this *state*

**Can meditation alter traits?**

⇒ [Altered Traits](https://www.amazon.com/Altered-Traits-Science-Reveals-Meditation/dp/0399184384) is a great book on the topic of mediation’s *state effects (temporary) vs. trait effects (qualities that persist beyond the session)*

*Like exercise,*

- the purpose of the hour you spent in the gym this morning was not because there’s something particularly insightful about moving a dumbbell from here to there, those are simply tools that we’re using
- There’s maybe a state that we create in that hour of exercise, but the goal is to give you traits that last for the other 23 hours

*With meditation,*

- I would suspect you’re getting a hell of a lot more than 5 minutes, or 20 minutes of benefit during the session
- That kind of a meditative practice is infused into the other 23 hours of the day in how you react

*Peter’s experience with meditation:*

- *“I feel the difference. I feel infinitely less aggressive. I feel infinitely more empathic.”*
- Wants to practice more to try to reach a **threshold effect**

*Is there a threshold effect with meditation?*

- Some claim (such as Peter’s friend, [Kevin Rose](https://twitter.com/kevinrose?lang=en)) that there is a real, therapeutic threshold that you must cross for it to start to affect your day-to-day (i.e. trait effect)
  - ⇒ [Listen to Peter get interviewed by Kevin Rose](https://www.kevinrose.com/single-post/Peter-Attia)
- If you practice meditation without somehow applying it in your daily life it’s like a bucket with no bottom

*What does mindfulness really mean?*

- Mindfulness is simply a lack of reactivity
- Tim Ferriss described it as “You become response – able” … meaning you’re able to actually make a response instead of an autonomic knee jerk to your elephant, says Zubin

**For more on mindfulness meditation, be sure to take a listen to a previous episode of The Drive: [Sam Harris, Ph.D.: The transformative power of mindfulness (EP.34)](https://peterattiamd.com/samharris/)**

## Zdogg’s theory of consciousness [1:11:30]

Zdogg’s theory of consciousness is influenced by the work of [Dr. Donald Hoffman](https://en.wikipedia.org/wiki/Donald_D._Hoffman)

- Dr. Hoffman’s TED Talk: [Do we see reality as it is?](https://www.ted.com/talks/donald_hoffman_do_we_see_reality_as_it_is/up-next?language=en)
- His appearance on Zdogg’s show: [WHAT IF WE’RE WRONG ABOUT REALITY? W/PROFESSOR DONALD HOFFMAN](https://zdoggmd.com/incident-report-179/)
- Here is a complete list of [Dr. Hoffman’s publications](https://cogsci.uci.edu/~ddhoff/publications.pdf)

**Synthesis of Zdogg’s theory of consciousness:**

*Are we seeing a world as it is? Or a fabrication not even close to reality?*

*⇒ Interface theory of perception*: Every species sees reality through a series of evolved hacks that allow them to reproduce

- Organisms that see any aspect of reality as it is, go extinct in just a few generations because it requires energy to actually see reality in all its complexity
- Organisms that see reality as a **fitness icon** designed to help them reproduce will thrive
- As humans, we have evolved a shorthand hack in how we see the world to help us survive… *i.e. I see something wet that I know that if I drink it I will not die*

*So is there a reality?*

⇒ Yes, there is an objective reality, but our visual cortex is simply constructing the world second-to-second in our minds every day

*Based on what?*

⇒ In quantum mechanics, it’s pretty clearly established that there is no such thing as local realism…in other words, something doesn’t exist until it’s interacting with a *conscious observer*

*What is it that we are interfacing with?* (Dr. Hoffman answers this question in his [TED Talk](https://www.ted.com/talks/donald_hoffman_do_we_see_reality_as_it_is/up-next?language=en))

⇒ The world is actually nothing but consciousness subdivided into *conscious agents*, which are little subdivisions of consciousness, the sum of which is equal to all of consciousness

*What does it mean to be conscious?*

⇒ The ability to **perceive, decide, and then act** (per the theory, even something as small as an electron is nothing but consciousness and it has these 3 abilities)

*How do we go from atoms, neurons to experience?*

⇒ At some point there’s a jump that no one has been able to explain

*The concept of “icons”*

⇒ Like movable icons on a computer desktop, all matter and neurons are “icons” that we use and “move around” in a species-specific way to understand this social network of consciousness interacting with itself

*Example*…

…when looking at Peter, Zubin only sees what he needs to see in order to get through the world, survive, and reproduce…because “we don’t have enough processing power to see what I really think is there, which is this incredibly complex series of nested consciousness all interacting”

*What about evolution? Why would that happen if conscious agents just exist and they’re outside of time and space?*

- Time and space is simply a species-specific data compression algorithm that allow us to make sense of this social network and allow us to survive
- Example, a dog or a cat or a fruit fly are all awareness interacting with other awareness, but the way they see the world in space and time is a totally different construct

*Summary of this Zdogg’s theory***:** There is nothing real beyond awareness itself and it creates reality on icons that allow it to evolve. We thought that the [Big Bang](https://en.wikipedia.org/wiki/Big_Bang) happened and then matter organized into complex structures through which consciousness emerged. But, this model says that consciousness was there first, then it subdivided into smaller agents that combined into bigger agents, and then it evolved over time into complex agents like ourselves that interact with other agents and social networks that probably form higher levels of consciousness.

**The follow-up conversation (paraphrased) between Peter and Zubin:**

**Peter:** It’s hard for me to actually internalize that because I mean letting go of subatomic structures as sort of not being real, that would just require a lot more understanding on my part.

**Zubin**: Subatomic structures are absolutely real as icons, so in other words, they mean something. They’re an image of something.

**Peter**: I think trying to imagine that they have their own state of consciousness is hard for me to understand.

**Zubin**: There’s no electron at all. Electron is a conscious agent that we see as an electron through our species-specific interface. It’s how we’ve evolved to see the world.

**Peter**: How would we explain physical experiments that have independently validated the same construct?

**Zubin**: We have our hack, but it’s based on reality and reality is these conscious agents exchanging experience with each other. . .of course it will be validated because it’s actually happening in the sense that these agents are behaving relationally to each other in predictable and precise ways that we can measure and science can quantify.

**Peter**: But why would the electrons behave in a predictable way when you and I can’t behave in a predictable way?

**Zubin**: We are unpredictable due to our complexity. We are made up of multiple conscious agents that emerge out of very high-level consciousness … we have agents, which are unconscious to us, that are making decisions in the background that are feeding it up to our higher instantiations…

…The simplest systems behave predictably because they may only have two perceptions, two actions and so it sums up scientifically, mathematically as absolute predictability.

**Peter**: But if you collapse that to one perception and one action that the simple system can use, then all of these sub-particles actually have no choice so it would become a semantic game.

**Peter sums up his objection**: *You couldn’t have the order that we have in the universe if there was any choice to be made at that low level.*

**Zubin**: Look at quantum mechanics. There is uncertainty.

**Peter**: It’s defined by a probability function, but it collapses to something that’s known once it’s observed.

**Zubin**: Correct, so what is observation but two conscious agents interacting and exchanging experience that then allows this particular conscious agent to settle into a particular choice? …

…So if we all see things differently, how can there be reality? How can there be objective, predictable scientifically valid reality? …

…Example of synesthetes: People that experience the world very differently such as they smell colors, or they hear sights, or see colors when they hear sounds…parts of the brain that light up with touch, light up when they’re simply *thinking* about something specific.

**Peter**: So the cortex has been remapped?

**Zubin**:  I would argue that the cortex is an icon we used to actually, consciousness interacting with itself…now imagine if evolution put pressures on us where the people with these interface mutations are at an advantage?

**Peter**: It becomes the default. But to me, that is totally explainable through [Darwinian Biology](https://en.wikipedia.org/wiki/Darwinism).

**Zubin**: That works just as well with conscious agents as it does with material stuff. Conscious agents can evolve over time to have perceptions that actually allow them to succeed in this social network where they’re competing.

**Peter**: Why is it that if that bottle is an icon you can’t make it lift up off the table by thinking about it

**Zubin**: that is not a perceptual decision

**Peter**: I can’t override it?

**Zubin**: There are rules, it’s not a free for all. It’s not magical thinking.

[*“There are rules, dude. This isn’t fucking ‘Nam.”*](https://www.youtube.com/watch?v=WiQmQhA-OrM) —Walter, from [The Big Lebowski](https://en.wikipedia.org/wiki/The_Big_Lebowski) (paraphrased)

## Nutrition: Peter’s current strategy with patients [1:31:00]

**How would Peter define his current nutritional strategy at his practice?**

- Peter squirms at the question: “I don’t know how to put a label on it”
- “I can define my objective, I can define the strategy, and I can define the tactics but other than that I can’t actually take an existing description and apply it to it”
- **Peter has a great talk about objective/strategy/tactics ⇒ [Reverse engineered approach to human longevity](https://vimeo.com/228845024)**

*Objective:*

⇒ Live longer than I am otherwise on a trajectory to live, which means I have to delay the onset of the things that will kill me

⇒ I want to improve the quality of my life, which I define rather simply as having three legs

1. **Cognition**=Delaying neurodegenerative disease
2. **Exoskeleton**
   - The maintenance of muscle mass
   - the ability to move and maintain mobility and stability
   - freedom from pain
   - sexual function
   - Basically, all the things that people take for granted until they start to lose it in their 80s and 90s
3. **The ability to be happy**
   - Having the highest degree of “distress tolerance” possible
   - Mindfulness and meditation becomes the single most important tool to impact that
   - Also important is social support and sense of purpose

*“For most people, if you took those things away from them, they wouldn’t want to live one more minute”*

⇒ Zubin has a similar approach with patients:

> “This idea that you can optimize a particular regiment to the goals of that unique patient is the foundation of what we call health 3.0. . .which we tried in our clinic, [Turntable Health](https://zdoggmd.com/turntablehealth/).”

**Challenges of this approach**

*The Efficacy Problem:* Figuring out the optimal way for an individual to eat, the good news being there is a finite number of iterations you can make until you start to converge on it

*The Effectiveness Problem:* By far the more challenging problem, which is finding a nutrition problem that actually works for the person, logistically or practically

⇒ Peter is a perfect example of the effectiveness problem, he knows he does best on a ketogenic diet but he simply doesn’t want to eat keto anymore, so this strategy is no longer “effective” for him

**Peter’s nutritional framework:**

There is a spectrum

- One end is the SAD, [The Standard American Diet](https://en.wikipedia.org/wiki/Western_pattern_diet)
- The other end is complete caloric restriction (water only, obviously not sustainable, this should be cycled)
- In between those two ends of the spectrum, Peter says there are 3 other steps

*“It’s one thing to figure out how to optimize a person based on how they cycle between those layers, but the harder part is figuring out how to make that the default, as opposed to something you have to work into.”*

*How do we make it our default?*

⇒ Peter says he’s Influenced by [Nudge by Dick Thaler](https://en.wikipedia.org/wiki/Nudge_(book))

- The easier you can make something for someone, the easier it’s going to be to do
- Figure out a way for them to *opt out* of good behaviors rather than opt *into* good behaviors.

⇒ Zdogg recommends the book [Switch](https://www.amazon.com/Switch-Change-Things-When-Hard/dp/0385528752/ref=sr_1_1?ie=UTF8&qid=1547495951&sr=8-1&keywords=heath+brothers+switch) (based on the elephant/rider motif from Jon Haidt)

## The anti-vaccine dispute [1:38:15]

**Zdogg [interviewed Paul Offit](https://zdoggmd.com/incident-report-192/) on this topic**

**Story of how Peter lost a patient over vaccines**

- Patient asked Peter if he should vaccinate his kids
- Peter said yes, absolutely
- The patient freaked out, “I expected more from you!”
- He didn’t ever want to see me again

*Why was this person so upset?*

⇒ Zubin posits, *“What you triggered was that person’s elephant. Their unconscious was triggered in a way where their entire conception of the world, their ideas of liberty versus justice, versus care, versus harm, this moral pallet that Jon Haidt talks about, which we can talk about more later. This idea that vaccines are a violation of the sanctity of the body so you’re putting toxins in the body. The idea that he probably went to you thinking you were a little bit off the grid, that you’re looking at the unique person and therefore you’re not going to swallow the dogma, right? But the truth is what he didn’t realize is no, you swallow what works. The things that have been shown to work are, in fact, vaccines.”*

The reality of anti-vaccine literature

- There was a [single paper](https://www.ncbi.nlm.nih.gov/pubmed/9500320) which made this an issue
- But this [paper has since been retracted](https://retractionwatch.com/2018/10/16/journal-retracts-16-year-old-paper-based-on-debunked-autism-vaccine-study/) because the calculations were wrong…it was fraud

Peter, upon reflection on his interaction with this patient:

- “*My guess is he was pissed not only in the fact that I was obviously a ‘not-outside-the-box’ thinker, but maybe on some level he was just pissed that I probably talked to him like an idiot. I was dismissive of him.”*
- Zubin: *“You really put your finger on something that we do in medicine a lot, and I’m guilty of it. That is, [we’re] speaking all to the ‘rider’, trying to give them data, when we haven’t motivated the ‘elephant’ or understood the elephant’s unconscious motivation.”*

*How do get through to people who seem unable to objectively look at the data?*

- Zubin admits that it’s hard for him to not get angry
- “I want these children to live and not die of preventable diseases. . .when you see a case of measles, when you see whooping cough in the hospital it will devastate you.”
- The truth is, yelling and ranting is not going to influence those people
- “The truth is nuance, and people hate nuance.”

## The common thread of all “diets”, the obesity epidemic, and Peter’s dream experiment [1:44:30]

People treat nutrition like a religion

- *For example*, when Peter would mention eating one molecule of carbohydrate on his blog, inevitably there would be people in the comments freaking out, “I thought you were about ketones, man. You’re a fraud!”
- Another example is the vegan propaganda documentary called, [What the Health](https://www.youtube.com/watch?v=LL2cLhOqPsE) ⇒ **Zdogg did a hilarious video about this:** **[A Real Doctor Watches “What The Health”](https://www.youtube.com/watch?v=skIGCoopR-g)**

All “diets” are better than the SAD

- Any diet you compare it to the SAD is amazing
- “The Standard American Diet which is this incredibly perfectly engineered ratio of just the right amount of refined carbohydrates, the right amount of sugars, the right amount of fats, it’s like you couldn’t come up with a better way to kill someone than that diet.
- That said, Peter doesn’t believe it is a deliberate conspiracy

People are solely focused: *dietary restriction* (keto, paleo, Mediterranean, vegan, vegetarian, etc.) to the exclusion of other interventions, such as:

- Time-restricted feeding
- Hypocaloric feeding
- Caloric restriction
- *“All of these guys are trying to nuke each other, saying, ‘My diet’s the best.’ ‘No my diet’s the best.’. . .But what they’re forgetting is they’re all comparing it to SAD…All of your diets are better than SAD.”*

Zdogg’s evolving *personal* nutritional strategy:

- Previously, he was doing a ketogenic diet, and in that process made the transition into more of Mediterranean diet combined with intermittent fasting
- Currently, he’s using a feeding window of once a day ⇒ *“I finally found a sweet spot where it’s not only good for me, I feel better and my labs are good, but I can do it, and I enjoy that meal so much. It allows me to be with my family during the meal we eat together, and I cheat on the weekend, because I’m with my family; it worked for me personally.”*

*How to solve the obesity epidemic?*

- Zubin: “It’s going to take a multi-pronged approach. . .and fat shaming”
- Who is at fault for childhood obesity?
- Zdogg made a somewhat controversial video:  [It’s Your Fault Your Kid is Obese](https://www.youtube.com/watch?v=DaqOe2mMURc)
- *“There are social determinants on health. Yeah, food deserts exist. Yeah, it’s hard to afford good food. But if your kid, absent a medical cause, is obese, it is fucking your fault. It is entirely your fault as a parent, because you control what goes in that child’s mouth.”*
- He asks Peter’s opinion⇒ “I guess to me it’s just hard for me to say that that parent is at fault, because they’re not playing with the same template that you or I are playing with. So again, if I were obsessed with this problem, I would solely be interested in changing the environment.”

**Peter’s dream experiment:**

- Take two geographical areas in reasonable proximity and similar in nature
- *The control group*: Give them an amount of money that was going to allow them to buy whatever they want, but you wouldn’t change the food environment or anything like that.
- *Treatment group*: You teach them how to cook, you give them the money, and then you completely reorganize the grocery stores as well as price switch everything (i.e., make Cocoa Puffs $12.99 instead of $2.99 and make them hidden and hard to see on the shelves)
  - In other words, you totally change the food environment
- You would run this over one year in parallel and then you [cross them over](https://en.wikipedia.org/wiki/Crossover_study)

⇒ Zdogg laments,

> *“We’ll never do it because prevention, proactivity, and looking at root cause is not something we do in American medicine.”*

Turntable Health

- Zubin says that, at Turntable Health, he gave people the tools, the education, guidance, and coaching and it worked
- It got to the heart of this issue
  - First of all, patients need to feel like we actually care
  - Then they’re being held accountable to some degree
- *“But humans are humans, and we’re driven by these unconscious urges and processes and until we are able to understand them, we can’t hack them.”*

## Do we have free will? And how do we make better decisions and learn from our mistakes? [1:55:15]

**Does free will exist?**

*Peter:*

- 2 year ago, I would have said 100% yes, there is free will
- Now, it’s a grey area, “I’m starting to begin to understand the counter-argument”
- What I love about the counter-argument is, it’s another great [empathogen](https://en.wikipedia.org/wiki/Empathogen%E2%80%93entactogen) ⇒ Do you know how much easier it is to go through life, when you stop being a pompous piece of shit, who thinks you’re so good because of your own free will?

*Zubin:*

“This idea that these thoughts and impulses bubble up from dark spaces that we cannot nail down…

…so how did he come to that choice? …

…Thoughts and decisions bubble up from an unconscious processes that we don’t understand: states and causes and conditions…

…As a result, when somebody does something dumb in a way they could never have acted otherwise; the same person, molecule for molecule, could not have acted otherwise.”

*Does lack of free will mean there are no consequences for actions?*

- This is a big counter argument from people who are afraid of the implications of there being no such thing as free will: *“The whole criminal justice system falls apart.”*
- But, lack of free will doesn’t mean there are no consequences
- They’re sort of confusing and confounding two issues
- Zubin: “We just need to make sure that others, who also don’t have free will, have their sub-minds conditioned that if you commit murder, you go to jail forever…As a result, that deterrent reconditions the unconscious that then allows different decisions to be made.”

⇒ Zubin summarizing his thoughts on free will: *It’s actually much more nuanced. These sub-minds actually have their own free will, and they feed it up, and it’s conditioned by our downward input. So what comes out is a consensus decision.*

⇒ Zubin recommends the book [Free Will by Sam Harris](https://www.amazon.com/Free-Will-Deckle-Edge-Harris/dp/1451683405)

**A better way to learn from our mistakes:**

⇒ [Morbidity and Mortality conferences](https://en.wikipedia.org/wiki/Morbidity_and_mortality_conference): A beneficial component of med school education

- Peter really enjoyed M&M at believe it to be very beneficial in the learning process
- Everybody would meet in a room and all of the complications, so the morbidities and then all of the deaths, the mortalities would be presented
- Very un-emotionally present the facts of a case where someone died in your care
- Then comes the process ⇒ The audience begins questioning your process and decisions leading up to the death
- “I’ve never been afraid of speaking in public with maybe one exception, that was a very difficult conference to present at. . .but by the time you were senior enough to be the one to stand up there and present, you had seen the beauty of it and the benefit of it”
- Peter then went to work for [McKinsey](https://en.wikipedia.org/wiki/McKinsey_%26_Company) and wondered why they didn’t do M&M?
- The reason M&M works: It’s completely closed off to others not part of the system, and there is no legal recourse.
- Zubin had the same experience with pain, but so much benefit, of going through M&M
- ⇒ “In the hospital, nurses often get fired if they make mistakes, and the truth is it ought to be a no-blame culture.”

## Peter’s current obsessions: fasting and rapamycin, measuring autophagy, and becoming a kickass 100-year-old [2:03:15]

**Obsession #1: Understanding what is the appropriate dose, and frequency, of caloric restriction, and of the molecules that mimic that.**

Molecules that mimic caloric restriction include:

- [Metformin](https://en.wikipedia.org/wiki/Metformin): Metformin has a net effect of activating an enzyme called [AMP kinase](https://en.wikipedia.org/wiki/AMP-activated_protein_kinase), which is a nutrient sensing enzyme. It mimics something that you see when you’re being deprived of calories.
- [Rapamycin](https://en.wikipedia.org/wiki/Sirolimus): inhibits something called the [mechanistic target of rapamycin](https://en.wikipedia.org/wiki/MTOR) (mTOR)…when you inhibit mTOR, you are mimicking deprivation of amino acids.

Fasting: Nothing but water, seems to work really well provided you do it in short enough periods of time

*⇒ The problem: We don’t have a clue what the optimal dose is*

If you think about fasting as a drug:

- How long should you fast for (dose)?
- How often should you fast (frequency)?
- Furthermore, do you need to go all the way? Could you just eat 500 calories a day for a certain period of time?

You pretty quickly realize that it becomes an infinite problem:

1. You have the number of calories you consume ⇒ somewhere from zero to something not too big.
2. The composition of those calories (macros)
3. The duration at which you’re exposed to eating/fasting (i.e. feeding window)
4. If you want to add a *fourth* variable: What should you consume when you’re not doing a specific eating/fasting/drug protocol?

*“That’s an unsolvable problem.”*

**Obsession 1-B: Understanding the readout states that would indicate life extension**

- If caloric restriction and/or rapamycin, and/or metformin extend life, what would be some of the readouts states of that?
- Peter is now obsessed with understanding those readout states
- Assays need to be created to measure the readout states for [autophagy](https://en.wikipedia.org/wiki/Autophagy) ⇒ generally regarded as probably the most important, though not the only mechanistic change, that occurs under caloric restriction and administration of rapamycin

“I have spent years experimenting on myself with this stuff, but the measurement tools that I have are too blunt to actually make any reasonable inference.”

- Need a better study
- Need better tools to measure what we care about

Is Peter using metformin or rapamycin on patients?

- Yes to metformin
- No to rapamycin, not because it’s dangerous (at the right dose and frequency), it just gets a bad rap
- *“But we certainly know enough now based on all of the literature out there, including literature in humans, dogs, etc., that rapamycin given at certain doses at certain frequencies actually enhances the immune system, and improves many metrics of physiology”*
- See [Longevity, aging and rapamycin](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4207939/)

Rapamycin is safer than other drugs that are commonly prescribed

⇒ [Fluoroquinolones](https://fluoroquinolones/) (a common antibiotic)

- Tendon injuries during the course of fluoroquinolones (you have about a six-month window of susceptibility to tendon injury following fluoroquinolones)
- Zdogg gives another example: We saw a higher incidence of [C-diff](https://en.wikipedia.org/wiki/Clostridioides_difficile_infection), a bowel infection, and actually had a patient who died of it
- He has a song about this: [Dawn of the Diff](https://www.youtube.com/watch?v=WNfFQI18ABI)

Zdogg’s rant about how hospitals suck and our medical system is broken:

*“You don’t understand how fucked up and terrible the hospital is, as a place to be safe and taken care of. It is a disastrous zone of chaos, of infection, of errors, of poor system design, of lack of coordination and of expense that doesn’t need to be done…*

*…Until we feel that emotionally in our elephant, we’re going to continue to perpetuate a broken system. We have to wake up and realize, maybe we need AI to help coordinate our care. Maybe we need better technology. Maybe we need better processes, but none of it’s happening because our incentives are still fees-for-service, which is we get paid to do things to people. In a hospital you can do a shit-ton of stuff to people. The hospital gets paid. Nobody’s incentivized to make it safer. Even though we all have a story of someone who we love, we took care of, who died because of a medical error, or got injured because of a medical error.”*

Why rapamycin is so exciting:

- Zubin: I get excited because maybe we can keep people out of the hospital
- Peter: It doesn’t just increase lifespan, it reduces the rate of healthspan decline

**⇒ For more on rapamycin check out [Peter’s interview with Matt Kaeberlein](https://peterattiamd.com/mattkaeberlein/) about his work with pet dogs**

**Peter’s current obsession #2: Figuring out how to be a kickass 100-year-old**

⇒ My intention is to understand what the 20 requirements are to be a kickass 100-year-old. So consider a new Olympic sport is the centenarian decathlon. So you figure out what all those metrics are, and then engineer your way back to what you need to be able to do at 40, 50, 60, 70, 80 to hit that target.

**Summary of his current obsessions:**

1. Developing finer tools to probe the molecular places to be able to see readout states on caloric restriction, rapamycin, metformin, and other agents that are CR mimetics, meaning drugs that mimic caloric restriction.
2. And secondly codifying what does the perfect training routine look like to make us be kickass 100-year-old

## Reforming the healthcare payment model [2:14:45]

**Peter gave a lecture on this topic: [Dr. Peter Attia: Healthcare Cost Containment](https://www.youtube.com/watch?v=LB4wRxRROfA)**

https://www.youtube.com/watch?v=LB4wRxRROfA

**Peter’s take:**

Quick story about a friend living in Saudi Arabia

- His friend leaves Saudi Arabia every summer for 3 months
- But he leaves his AC running *the entire time*
- *Why would he do this?* ⇒ Because otherwise his apartment would be 120 degrees when he returned, and because **the government pays for the electricity**
- *How ridiculous right??* ⇒ But that’s the US Healthcare system

Decision makers must bear the cost

- Peter plotted where the dollars come in, and who makes the decisions on where the dollars get spent, and it turns out that **the people who are driving the cost are not bearing the cost**
- *“Fundamentally if you want to fix the cost issue, you must be able to couple decision making to spend. You can’t have those uncoupled, and they’re currently uncoupled.”*

3 legs of healthcare system

1. Cost
2. Access
3. Quality

- People talk about them like they are independent, but they are not
- Canada for example, has optimized for affordability, but it might take you 6 months to get an MRI

If Peter could wave a magic wand, he would make the following changes:

- 1) Single payer system
  - “As much as I hate to say it, I do believe that if you truly try to individually privatize healthcare”
  - If you do, you cannot get that silly decouple out
- 2) Patients need more skin in the game
  - Under the current pricing regime, that would be impossible
  - So the answer isn’t patients need to spend more, they just need to own a greater share of the cost
  - This means the total cost can’t be a bullshit scam, which is sort of what it is right now

![](https://peterattiamd.com/wp-content/uploads/2019/01/skin-in-the-game-300x204.png)

**Figure 1. Disconnect between financial burden and decision makers in healthcare.** Image credit: [Peter’s Healthcare Cost Containment presentation](https://www.youtube.com/watch?v=LB4wRxRROfA)

**Zubin’s solution:**

Give everyone a personal health account up to about $2500

- It has to be used within healthcare (so there’s no incentive to not spend it)
- Use it for primary care

Preventative healthcare is incentivized

- Flat membership fee for an unlimited, all you can treat access to a relationship-driven, preventative-mind, a team-based healthcare
- You can look at the unique patient, you’re not subject to metrics beyond the patient having outcomes that matter to them
- It’s people competing with each other based on what they’re providing to the patient.

*When the $2,500 is used up…*

⇒ Then it gets into deductible space

- Wealthier people may have a higher deductible ($7500 or so)
- Low-income people: “It might be subsidized by either your employer or by the government to some degree, but your skin is still somewhat in the game, and so you’re paying for that.”

⇒ Once you reach the deductible…

- Catastrophic Medicare kicks in
- That is Medicare for all but not in a single-payer sense…it doesn’t pay for everything.
- It’s given out and administered in the same way that Medicare advantage is… in other words, different entities compete to be the most efficient with that money
- “You have businesses competing, you have the government covering everybody. Nobody falls through the cracks. Hospitals compete, doctors compete. But everybody gets to practice the way they want.”

*In summary:*

- It doesn’t bankrupt the country because you only need maybe another 6% tax and it’s equitable, but not completely unfair.
- At the center of it is *prevention primary care*  ⇒ That also ameliorates burnout for doctors
- Then focus on science and technology that actually improves quality

**Peter and Zubin’s follow up discussion (paraphrased):**

**Peter**: I would love to say this should all be done privately without the government. But the one advantage the government has going for it is that it “owns” the patient life forever, and therefore it is truly incentivized to participate in a capitated way. The challenge of privatizing this is that the median tenure of a patient with a payer, be it an insurance company or their employer is in the neighborhood of what, four or five years? …

…if you are a newly diagnosed type two diabetic today, and I, as the payer, know I only own your life for three or four more years, I have *zero incentive to spend one penny*. Because by the time the macrovascular and microvascular diseases destroy your life in 20 years, I’m going to be so long gone I won’t even remember your name.

**Zubin**: In this country we medicalize our social problems. Diabetes to a large extent is a social problem. It’s poverty, it’s lack of job security, it’s inability to exercise because of danger in the community, these kinds of things. It’s adverse childhood experiences. As a result, if you start shunting money from healthcare into those social services, like every other industrialized country does, you can actually squeeze down the overall cost.

**Peter**: Yes, but the government must be the one who does that.

**Zubin**: I think that’s the role for government. People will disagree, the hardcore libertarians will disagree.

**Peter**: Well, here’s the funny thing, I consider myself libertarian, which is such a broad term that it doesn’t mean much. . .but I actually found Michael Lewis’s book, The Fifth Risk to be quite interesting. . .I think Lewis does a great job explaining things that the government are good at.

**Zubin**: This is why the center probably holds the truth for in most cases. That’s where I am, too. I think government has a role. . .The government is already 50% of healthcare so how can we optimize them? Don’t let them break stuff that they have no business in, but have them do what they do really well. I think social support is something they do well.

## How to find doctors like Peter and Zubin in your area [2:28:15]

One of the most frequent questions Peter gets asked: *How can I find a good doctor where I live?*

⇒ Peter is in the process of creating a doctor database through his website to facilitate patient-doctor introductions

⇒ Doctors can go now to Peter’s website and [apply to be part of the database](https://peterattiamd.com/directory-signup/)

- “We’re making it a pain in the ass for the doctors to fill out because I want them to do some work”
- They must answer a lot of questions,
  - How much time do you spend each month learning about this or that?
  - What is your process of re-education?
  - What is your philosophy on medicine?
  - And so on.
- Goal: Get to the point where a patient can type in their zip code and be able to read about doctors in their area

*“My hope is that, given the hurdle of how much work goes into that, it’s not just someone mindlessly saying, ‘I’m a doc. I want another portal of referral.’ … but if it streamlines the process for patients by 50%, it’s still valuable. And I think it could be more valuable than that.”*

\*Note: Peter can’t completely vet and scrutinize them all, so it is not an endorsement\*

## Zdogg’s amazing videos [2:31:15]

**You can find all of Zubin’s incredible videos at [ZdoggMD.com](https://zdoggmd.com/) as well as on his [YouTube channel](https://www.youtube.com/user/ZDoggMD). Check the ‘Selected Links’ section below to find all the videos that were specifically mentioned throughout this conversation.**

**What is Zdogg’s process in producing videos from start to finish?**

*“Everything we do is try to be mission-driven. . .what’s the message we’re trying to give?”*

**Using the example of his song called [Ain’t The Way To Die](https://www.youtube.com/watch?v=NAlnRHicgWs) (One of Peter’s Top 3 Zdogg videos)**

**Step 1**: Identify a problem or message that needs to be communicated

- Noticed that people suffered and were tortured at the **end of life** because nobody had the balls to have a conversation and say, “What is it you want when this happens?”
- The loved ones would say, “He never talked about it. He said he didn’t want to be a vegetable.”
- It starts from that emotional place of “what do we want to do with this thing?”

**Step 2**: Find the right song

- With the right emotional valence
- The right lyrical structure
- Flip through Spotify
- *“We can motivate the elephant and then later we’ll think about how we can direct the rider”*
- Came across Eminem’s song, [Love The Way You Lie](https://www.youtube.com/watch?v=uelHwf8o7_U) ft. Rihanna
- It’s about domestic abuse ⇒ Isn’t domestic abuse the same as the institutional abuse that happens to our patients when we don’t have this conversation?

*Tangent: Is Zubin musically trained?*

- In high school, awkward kid, *“I picked up guitar as a way to try to impress ladies”*
- Inspired by [Weird Al](https://en.wikipedia.org/wiki/%22Weird_Al%22_Yankovic). . .in love with the concept of parody
- I minored in music at UC Berkeley, and I majored in molecular biology because I was like, pre-med with the hedge that I was going to be a rockstar.
- “There were so many kids that were so much better than me, and I knew it. The thing is, rather than beat myself up about it, I’m like, cool, I’ll be a doctor who plays guitar on the side.”

**Step 3**: Review original lyrics and structure, and pick a title

- On the left, I have the original lyrics to Eminem and their structure, and the right I have a blank space
- Come up with a title

**Step 4**: Create track music

- Reached out to friend, Devon Moore, who’s an audio engineer
- He sends me the track, then I have the feel of it

**Step 5**: Lyrics

- Then I’ll sit there with the original, listen to it, and I’ll just start coming up with lyrics
- In my mind, I may have some notes, I needed to hit this point, this point, this point.
- *Creative process:*
  - I get on a treadmill or a Stairmaster, or go for a run
  - The silence helps get through the monkey mind on top
  - The unconscious, which has been processing the stuff in the background, starts to bubble up these ideas.
- *“The nice thing is. . . there’s a structure in the song already that I can’t violate. That bit of constraint allows me actually to excel at what I do, I need that constraint. If it’s just open, I will fuck it up, because it’s too much possibility and I’ll mentally masturbate for hours and it won’t come out.”*

**Step 5-b**: Rewrite the lyrics

- The rewriting process of lyrics is even more important than the initial writing.
- Tweak it and tweak it and tweak it
- Hone lyrics with the help of [RhymeZone](https://www.rhymezone.com/)

**Step 6**: Record audio in a studio

*How long does this process take?*

- From idea to picking the right song: About 2 days
- From song picked out to lyrics written: One or 2 weeks for Ain’t The Way To Die, sometimes can do it in one day… longest it took a month
- Time to record the song in studio: A couple days, 30+ takes
- Peter is amazed at the ability to do so many takes…
- *“The finished product matters so deeply to me that I cannot put out a stinky piece of shit.”*

*Voice lessons:*

- Zubin took voice lessons which helps to reduce the amount of takes needed
- He also now does live performances multiple times per year
  - [Ain’t The Way To Die](https://www.youtube.com/watch?v=NAlnRHicgWs)
  - [7 Years](https://www.youtube.com/watch?v=jV9RyXQyQ7Q) (Peter says this one is the most touching of them all)

**Step 7**: Cinematography (shooting and editing the music video)

- Shot usually in a single day
- One take in a hospital (have to basically beg a hospital to let them in)
- Real practitioners as extras

COMING SOON: A parody to [Barenaked Ladies: One Week](https://www.youtube.com/watch?v=fC_q9KPczAg) which he will be calling “One Sikh,” a tribute for foreign medical graduates from India and South Asia

§

## Selected Links / Related Material

## You can find all of Zdogg’s videos here:

- Website: [Zdoggmd.com](https://zdoggmd.com/)
- YouTube: [ZdoggMD](https://www.youtube.com/user/ZDoggMD)

**Peter’s favorites:**

1. [Ain’t The Way To Die](https://www.youtube.com/watch?v=NAlnRHicgWs)
2. [Lose Yourself](https://www.youtube.com/watch?v=3lyMvp2GoSY)
3. [7 Years](https://www.youtube.com/watch?v=jV9RyXQyQ7Q)

**Others specifically mentioned during conversation:**

- [Colon Wars](https://www.youtube.com/watch?v=74oK6RFNmDg) [41:45]
- [Manhood in the Mirror](https://www.youtube.com/watch?v=fypm_aeR5qA) [42:00]
- [A Real Doctor Watches “What The Health”](https://www.youtube.com/watch?v=skIGCoopR-g) [1:44:30]
- [It’s Your Fault Your Kid is Obese](https://www.youtube.com/watch?v=DaqOe2mMURc) [1:48:30]
- [Dawn of the Diff](https://www.youtube.com/watch?v=WNfFQI18ABI) [2:10:45]
- [Ain’t The Way To Die](https://www.youtube.com/watch?v=NAlnRHicgWs) [2:32:30]
- [More Than Warts](https://www.youtube.com/watch?v=dpHXm3Y4pFQ) [2:36:30]
- [7 Years](https://www.youtube.com/watch?v=jV9RyXQyQ7Q) [2:45:00]

## Other related material:

**Peter and Zubin both spoke at TEDMED in 2013:** [07:45]

- Zubin’s talk: [ZDoggMD at TEDMED | Zombie Docs 2013](https://www.youtube.com/watch?v=WeY_z0c_wMs) [40:30]
- Peter’s talk: [Is the obesity crisis hiding a bigger problem?](https://www.ted.com/talks/peter_attia_what_if_we_re_wrong_about_diabetes?language=en)

**Peter on Jocko Willink’s podcast**: [56: OVERCOMING STRESS, SLEEP DEPRIVATION, AND THE DARKNESS WITH PETER ATTIA](https://jockopodcast.com/2017/01/04/56-overcoming-stress-sleep-deprivation-and-the-darkness-with-peter-attia/) | Jocko Willink ([jockopodcast.com](https://jockopodcast.com/)) [10:00]

**Peter’s discussion with Tom Seyfried mentioned by Zdogg**: [Thomas Seyfried, Ph.D.: Controversial discussion—cancer as a mitochondrial metabolic disease? (EP.30)](https://peterattiamd.com/tomseyfried/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) [11:30]

**In med school, Zubin remembers Peter doing the entire monologue from Austin Powers where Dr. Evil talks about his childhood**: [Austin Powers Doctor Evil Talks About Himself](https://www.youtube.com/watch?v=lTJj4wbmAhk) | enda wright ([youtube.com](https://www.youtube.com/)) [11:00]

**Zubin’s 1999 med school graduation speech**: [Funny Graduation Speech | UCSF Med School | ZDoggMD.com](https://www.youtube.com/watch?v=mgnHH7Iz37c) | ZdoggMD (youtube.com) [20:00]

**Doctors suffering from moral injury**: [Physicians aren’t ‘burning out.’ They’re suffering from moral injury](https://www.statnews.com/2018/07/26/physicians-not-burning-out-they-are-suffering-moral-injury/) | SIMON G. TALBOT and WENDY DEAN ([statnews.com](https://www.statnews.com/)) [28:00]

**Peter on Dr. Oz**: [The Truth about Saturated Fat, Pt 1](https://www.doctoroz.com/episode/government-out-undermine-your-health?video_id=3479158688001) | ([doctoroz.com](https://www.doctoroz.com/)) [29:30]

**Book which coined the term “gomer”**: [House of God](https://www.amazon.com/House-God-Samuel-Shem/dp/0425238091) by [Samuel Shem](https://en.wikipedia.org/wiki/Samuel_Shem) | ([amazon.com](https://www.amazon.com/)) [34:00]

**Tony Hsieh book both Peter and Zubin recommend**: [Delivering Happiness](https://www.amazon.com/Delivering-Happiness-Profits-Passion-Purpose/dp/0446576220) by Tony Hsieh | (amazon.com) [38:30]

**Zdogg video: Parody looking at the GI tract through the lens of Luke Skywalker**: [Colon Wars | Star Wars Colonoscopy Parody](https://www.youtube.com/watch?v=74oK6RFNmDg) | ZdoggMD (youtube.com) [41:45]

**ZdoggMD video: Parody to raise awareness of testicular cancer**: [“Manhood in the Mirror” | Man in the Mirror Parody: Michael Jackson](https://www.youtube.com/watch?v=fypm_aeR5qA) | ZDoggMD (youtube.com) [32:15]

**Peter’s longest swim**: [Peter Attia crossing Catalina Channel](https://www.youtube.com/watch?v=yMQFd9q07Zo&t=13s) | Peter Attia (youtube.com) [49:00]

**Book that helped Zubin with meditation**: [The Mind Illuminated: A Complete Meditation Guide Integrating Buddhist Wisdom and Brain Science for Greater Mindfulness](https://www.amazon.com/Mind-Illuminated-Meditation-Integrating-Mindfulness/dp/1501156985) by John Yates | (amazon.com) [54:15, 1:04:15]

**80s show that Zubin compared himself to when he’s trying to learn to meditate**: [The Greatest American Hero](https://en.wikipedia.org/wiki/The_Greatest_American_Hero) | (wikipedia.org) [54:45]

**Meditation apps used by Zubin**: [55:30]

- [Waking Up with Sam Harris](https://wakingup.com/)
- [Headspace](https://www.headspace.com/)

**Previous episodes of The Drive discussing MDMA and psychedelics**: [57:15]

- [Tim Ferriss: depression, psychedelics, and emotional resilience (EP.01)](https://peterattiamd.com/timferriss/) [also mentioned at 1:02:45]
- [Sam Harris, Ph.D.: The transformative power of mindfulness (EP.34)](https://peterattiamd.com/samharris/)

**Book by Eckhart Tolle that Zubin read when he was focused on making a mental change**: [The Power of Now: A Guide to Spiritual Enlightenment](https://www.amazon.com/Power-Now-Guide-Spiritual-Enlightenment/dp/1577311523/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Eckhart Tolle | (amazon.com) [1:00:30]

**Sam Harris’s book on mindfulness that helped Peter with meditation**: [Waking Up: A Guide to Spirituality Without Religion](https://www.amazon.com/Waking-Up-Spirituality-Without-Religion/dp/1451636024) by Sam Harris four times. [1:03:45]

**Song with a the line, “You just haven’t earned it yet, baby.” that Peter loves**: [THE SMITHS – You Just Haven’t Earned It Yet, Baby](https://www.youtube.com/watch?v=Dh2bRJcE7I8) | Rod241 (youtube.com) [1:05:15]

**Jon Haidt’s elephant and rider metaphor**: [Jonathan Haidt: Elephant and rider metaphor](https://en.wikipedia.org/wiki/Jonathan_Haidt#Elephant_and_rider_metaphor) | (wikipedia.org) [1:05:45]

**Zdogg explains the elephant and rider metaphor**: [The Elephant and Rider Episode | Incident Report 153](https://www.youtube.com/watch?v=GLQySJr-_uY) | ZdoggMD (youtube.com) [1:05:45]

**Meditation book explaining how the effects of meditation may translate beyond the state of being in meditation**: [Altered Traits: Science Reveals How Meditation Changes Your Mind, Brain, and Body](https://www.amazon.com/Altered-Traits-Science-Reveals-Meditation/dp/0399184384) by Daniel Goleman and Richard J. Davidson | (amazon.com) [1:08:00]

**Peter’s discussion with Kevin Rose on Kevin’s podcast**: [#31 – Dr. Peter Attia – longevity compounds, fasting, supplements and more](https://www.kevinrose.com/single-post/Peter-Attia) | Kevin Rose ([kevinrose.com](https://www.kevinrose.com/))  [1:09:15]

**The basis of Zubin’s theory of consciousness**: [The Interface Theory of Perception.](https://www.ncbi.nlm.nih.gov/pubmed/26384988) (Hoffman et al., 2015) [1:13:45]

**Donald Hoffman’s TED talk**: [Do we see reality as it is?](https://www.ted.com/talks/donald_hoffman_do_we_see_reality_as_it_is/up-next?language=en) | (ted.com) [1:14:30]

**Donald Hoffman’s appearance on Zdogg’s show**: [WHAT IF WE’RE WRONG ABOUT REALITY? W/PROFESSOR DONALD HOFFMAN](https://zdoggmd.com/incident-report-179/) | Zubin Damania (zdoggmd.com) [1:14:30]

**Heisenberg’s formula for electron probability cloud**: [Uncertainty principle](https://en.wikipedia.org/wiki/Uncertainty_principle) | (wikipedia.org) [1:17:15]

**Famous quote about all models being wrong**: [All models are wrong](https://en.wikipedia.org/wiki/All_models_are_wrong) | (wikipedia.org) [1:18:00]

**Darwinian Biology**: [Darwinism](https://en.wikipedia.org/wiki/Darwinism) | (wikipedia.org) [1:28:30]

**Zubin quotes The Big Lebowski and then they talk about the drink made famous in the movie, White Russians**: [The Big Lebowski](https://en.wikipedia.org/wiki/The_Big_Lebowski) | (wikipedia.org) [1:29:45]

**Peter’s talk about objective/strategy/tactics**: [Reverse engineered approach to human longevity](https://vimeo.com/228845024) | A|M (vimeo.com) [1:31:00]

**Health 3.0, Zubin’s idea to transform healthcare and the way primary care physician work**: [THE HEALTH 3.0 MOVEMENT](https://zdoggmd.com/health-3-point-0/) | (zdoggmd.com) [1:35:30]

**Turntable Health, Zubin’s clinic in Las Vegas that used the Health 3.0 model**: [TWO DOCUMENTARIES ABOUT TURNTABLE HEALTH](https://zdoggmd.com/turntable-health-documentary/) | (zdoggmd.com) [1:35:30]

**A book that influences Peter’s thinking on how to make healthy decisions easier**: [Nudge: Improving Decisions about Health, Wealth, and Happiness](https://www.amazon.com/Nudge-Improving-Decisions-Health-Happiness-ebook/dp/B009KERBQI) by Richard Thaler | (amazon.com) [1:37:00]

**A book recommended by Zubin which also discusses ways to influence behavior**: [Switch: How to Change Things When Change Is Hard](https://www.amazon.com/Switch-Change-Things-When-Hard/dp/0385528752) by Chip and Dan Heath | (amazon.com) [1:37:30]

**The Dunning-Kruger effect**: [Dunning-Kruger effect](https://en.wikipedia.org/wiki/Dunning%E2%80%93Kruger_effect) | (wikipedia.org) [1:38:15]

**Paul Offit on Zdogg’s podcast discussing the anti-vaccination world**: [THE DANGER OF CELEBRITY HEALTH ADVICE (W/DR. PAUL OFFIT)](https://zdoggmd.com/incident-report-192/) | (zdoggmd.com) [1:39:15]

**Anti-vaccination paper that eventually got retracted**: [RETRACTED: Ileal-lymphoid-nodular hyperplasia, non-specific colitis, and pervasive developmental disorder in children](https://www.ncbi.nlm.nih.gov/pubmed/9500320) (Wakefield et al., 1998) [1:41:15]

**Article about how the anti-vaccination paper got retracted**: [Journal retracts 16-year-old paper based on debunked autism-vaccine study](https://retractionwatch.com/2018/10/16/journal-retracts-16-year-old-paper-based-on-debunked-autism-vaccine-study/) | (retractionwatch.com) [1:41:15]

**Health documentary that was basically vegan propaganda**: [What the Health – Documentary – 2017 2160p 4K](https://www.youtube.com/watch?v=LL2cLhOqPsE) | DarkMind Inc (youtube.com) [1:44:30]

**Zdogg’s hilarious video about What The Health**: [A Real Doctor Watches “What The Health”](https://www.youtube.com/watch?v=skIGCoopR-g) | ZdoggMD (youtube.com) [1:44:30]

**Zdogg’s somewhat controversial video out childhood obesity**: [It’s Your Fault Your Kid is Obese](https://www.youtube.com/watch?v=DaqOe2mMURc) | ZdoggMD (youtube.com) [1:48:30]

**Sam Harris’s book on Free Will**: [Free Will](https://www.amazon.com/Free-Will-Deckle-Edge-Harris/dp/1451683405) by Sam Harris | (amazon.com) [1:56:00]

**Animal studies showing some form of caloric restriction increases longevity**: [Caloric restriction delays disease onset and mortality in rhesus monkeys](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2812811/) (Colman et al., 2009) [2:05:00]

**Rapamycin literature showing life extension in rats**: [Longevity, aging and rapamycin](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4207939/) (Ehninger et at., 2014)  [2:09:30]

**Peter’s interview with Matt Kaeberlein about his work with pet dogs**: [Matt Kaeberlein, Ph.D.: rapamycin and dogs — man’s best friends? — living longer, healthier lives and turning back the clock on aging and age-related diseases (EP.10)](https://peterattiamd.com/mattkaeberlein/) | Peter Attia (peterattiamd.com) [2:09:30]

**Studies showing you have about a six-month window of susceptibility to tendon injury following fluoroquinolones**: [The Risk of Fluoroquinolone-induced Tendinopathy and Tendon Rupture](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2921747/) (Grace K. Kim, 2010) [2:10:30]

**ZdoggMD video: Parody about the danger of antibiotics**: [Dawn of the Diff](https://www.youtube.com/watch?v=WNfFQI18ABI) | ZDoggMD (youtube.com) [2:11:00]

**Peter’s lecture on the broken healthcare system**: [Dr. Peter Attia: Healthcare Cost Containment](https://www.youtube.com/watch?v=LB4wRxRROfA) | Stern Speakers (youtube.com) [2:14:45]

**Michael Lewis’s book that does a good job explaining what the government is actually good at**: [The Fifth Risk](https://www.amazon.com/Fifth-Risk-Michael-Lewis/dp/1324002646) by Michael Lewis | (amazon.com) [2:26:15]

**ZdoggMD video about how we suck at end-of-life care**: [Ain’t The Way To Die](https://www.youtube.com/watch?v=NAlnRHicgWs) | ZdoggMD (youtube.com) [2:32:45]

**Eminem’s song about domestic abuse which Zdogg used for his parody called Ain’t The Way to Die**: [Eminem – Love The Way You Lie ft. Rihanna](https://www.youtube.com/watch?v=uelHwf8o7_U) | EminemMusic (youtube.com) [2:34:00]

**Zdogg video, an HPV Vaccine Parody PSA**: [More Than Warts](https://www.youtube.com/watch?v=dpHXm3Y4pFQ) | ZdoggMD (youtube.com) [2:36:30]

**The audio editing software Zdogg uses**: [Logic Pro](https://en.wikipedia.org/wiki/Logic_Pro) | (wikipedia.org) [2:43:00]

**My people call it Maize commercial**:: [1976 Mazola Margarine “We Call It Maize” Commercial](https://www.youtube.com/watch?v=cuOlD0JZhM4) | commerce (youtube.com) [2:44:30]

**Zdogg’s video that Peter says is the most touching of them all**: [7 Years (A Life In Medicine)](https://www.youtube.com/watch?v=jV9RyXQyQ7Q) | ZDoggMD (youtube.com) [2:45:00]

§

## People Mentioned

- [Tony Hsieh](https://en.wikipedia.org/wiki/Tony_Hsieh) (CEO of Zappos, recruited Zubin to Vegas with the task of transforming medicine) [5:15, 38:00, 57:00]
- [Jocko Willink](https://twitter.com/jockowillink) (Peter was a guest on Jocko’s podcast) [6:30, 24:30]
- [Tim Ferriss](https://twitter.com/timferriss?lang=en) (meditation, psychedelics) [7:30, 1:02:15, 1:07:00]
- [Sam Harris](https://twitter.com/SamHarrisOrg?lang=en) (meditation, free will) [7:30, 49:15, 1:08:00, 1:56:00]
- [Thomas Seyfried](https://twitter.com/tnseyfried?lang=en) (cancer as a metabolic disease, [guest on The Drive](https://peterattiamd.com/tomseyfried/)) [7:30]
- [Fat Bastard](https://en.wikipedia.org/wiki/Fat_Bastard) (fictional character Peter imitated in med school, from Austin Powers) [12:00]
- [Michael Bishop](https://en.wikipedia.org/wiki/J._Michael_Bishop) (laughed at Zubin’s commencement speech, Nobel Prize winner) [20:15]
- [Simon Talbot](https://physiciandirectory.brighamandwomens.org/details/1847/simon-talbot-lgbt_health-plastic_surgery-restorative_surgery-trauma_burn_and_surgical_critical_care-boston) (moral injury) [28:15]
- [Wendy Dean](https://www.hjf.org/about/leadership/) (moral injury) [28:15]
- [Dr. Oz](https://en.wikipedia.org/wiki/Mehmet_Oz) (Peter was on an episode of Dr. Oz’s TV show, Zubin like Dr. Oz) [29:30]
- [Gary Vaynerchuk](https://twitter.com/garyvaynerchuk?lang=en) (example as you uses YouTube content to make a living) [41:15]
- [Kevin Rose](https://twitter.com/kevinrose?lang=en) (creator of Digg.com, meditation) [41:15, 1:09:15]
- [Michael Jackson](https://en.wikipedia.org/wiki/Michael_Jackson) (Zdogg did a Man in the Mirror parody about testicular cancer) [42:30]
- [Terence McKenna](https://en.wikipedia.org/wiki/Terence_McKenna) (smoking level heroic dose of weed) [57:45]
- [Eckhart Tolle](https://twitter.com/eckharttolle?lang=en) ([Power of Now](https://www.amazon.com/Power-Now-Guide-Spiritual-Enlightenment-ebook/dp/B002361MLA) book) [1:00:30]
- [Jon Haidt](https://en.wikipedia.org/wiki/Jonathan_Haidt) (elephant and rider metaphor) [1:05:45, 1:39:30, 2:41:15]
- [Dr. Donald Hoffman](https://en.wikipedia.org/wiki/Donald_D._Hoffman) (person from whom Zubin formulated his theory of consciousness) [1:11:30, 1:21:00]
- [George E. P. Box](https://en.wikipedia.org/wiki/George_E._P._Box) (“All models are wrong, some are useful.”) [1:18:00]
- [Isaac Newton](https://en.wikipedia.org/wiki/Isaac_Newton) [1:23:30]
- [Indiana Jones](https://en.wikipedia.org/wiki/Indiana_Jones) (Zubin imitates a scene from the movie) [1:28:15]
- [Deepak Chopra](https://en.wikipedia.org/wiki/Deepak_Chopra) (meditation) [1:29:30]
- [Paul Conti](https://www.pacificpremiergroup.com/meet-our-team/) (distress tolerance) [1:34:00]
- [Stephen Hawking](https://en.wikipedia.org/wiki/Stephen_Hawking) (exception of someone who completely lost mobility but was still happy) [1:34:15]
- [Dick Thaler](https://en.wikipedia.org/wiki/Richard_Thaler) ([Nudge](https://www.amazon.com/Nudge-Improving-Decisions-Health-Happiness/dp/014311526X) book Peter is influenced by) [1:37:00]
- [Paul Offit](https://en.wikipedia.org/wiki/Paul_Offit) (enemy of the anti-vaccine people) [1:39:15]
- [Charles Manson](https://en.wikipedia.org/wiki/Charles_Manson) (someone you should decide not to hang out with) [1:58:15]
- [Michael Lewis](https://en.wikipedia.org/wiki/Michael_Lewis) ([The Fifth Risk](https://www.amazon.com/Fifth-Risk-Michael-Lewis/dp/1324002646) book) [2:26:15]
- [Chris Kresser](https://twitter.com/chriskresser/) (has a physician directory similar to what Peter is trying to create) [2:30:30]
- [Eminem](https://www.instagram.com/eminem/?hl=en) (Zdogg did a parody of one of his songs) [2:34:00]
- [Rihanna](https://www.instagram.com/badgalriri/?hl=en) (Zdogg did a parody of her and Eminem’s song) [2:34:00]
- [“Weird Al” Yankovic](https://en.wikipedia.org/wiki/%22Weird_Al%22_Yankovic) (someone Zdogg liked growing up and models some of his stuff after) [2:36:30]
- [Devin Moore](https://zdoggmd.com/tag/devin-moore/) (Zdogg’s audio engineer) [2:38:15]
- [Tom Hinueber](https://www.linkedin.com/in/tom-hinueber-9a735368) (video editor/cinematographer who works with Zdogg) [2:40:30]
- [Logan Stewart](https://www.linkedin.com/in/logan-stewart-341285a3) (video editor/cinematographer who works with Zdogg) [2:40:30]
- [Amy Winehouse](https://en.wikipedia.org/wiki/Amy_Winehouse) (Zdogg almost did a parody of her song Rehab) [2:40:45]
- [Freddie Mercury](https://en.wikipedia.org/wiki/Freddie_Mercury) (Queen, We Are The Champions) [2:44:30]
- [Zubin Mehta](https://en.wikipedia.org/wiki/Zubin_Mehta) (a conductor that Zubin was named after) [2:44:30]
- [Barenaked Ladies](https://en.wikipedia.org/wiki/Barenaked_Ladies) (Zdogg is doing a parody of their song One Week) [2:47:00]
- [Jim Creeggan](https://en.wikipedia.org/wiki/Jim_Creeggan) (current bassist for Barenaked Ladies, Peter went to high school with him) [2:47:00]
- [Andrew Creeggan](https://en.wikipedia.org/wiki/Andy_Creeggan) (former member of Barenaked Ladies, Peter went to high school with him) [2:47:00]

§

![](https://peterattiamd.com/wp-content/uploads/2019/01/bio-image-500x500.png)

##### Zubin Damania, M.D.

Zubin Damania, aka Zdogg MD, is a UCSF/Stanford trained internal medicine physician and founder of Turntable Health, an innovative primary care clinic and model for Health 3.0 that was part of an ambitious urban revitalization movement in Las Vegas spearheaded by Zappos CEO Tony Hsieh. During a decade-long career as a hospitalist at Stanford, Zubin led a shadow life performing stand-up comedy for medical audiences worldwide as a way to address his own burnout. His videos and live shows have since gone epidemically viral with nearly a half a billion views on Facebook and YouTube, educating patients and providers while mercilessly satirizing our dysfunctional healthcare system. The goal of his movement is to rapidly catalyze transformation by leveraging the awesome power of passionate and engaged healthcare professionals. [[zdoggmd.com](https://zdoggmd.com/about-z/)]

Facebook: [ZdoggMD](https://www.facebook.com/ZDoggMD)

Twitter: [@zdoggmd](https://twitter.com/zdoggmd)

Instagram: [@zdoggmd](https://www.instagram.com/zdoggmd/)