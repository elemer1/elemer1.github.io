# #157 – AMA #22: Losing fat and gaining fat: the lessons of fat flux

**Source:** [https://peterattiamd.com/ama22/](https://peterattiamd.com/ama22/)

---

In this “Ask Me Anything” (AMA) episode, Peter and Bob take a deep dive into fat flux. They define the major players that impact the flow of fat entering and exiting a fat cell, which determines how much fat a person carries. They discuss the significant influence that insulin has on the net fat balance and explore common strategies, such as fasting and low-carb diets, that have efficacy in the liberation and oxidation of fat from fat cells. Additionally, Bob explains his research process and how he seeks answers to Peter’s challenging questions.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #22 show notes page](https://peterattiamd.com/ama22/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- The two main ways to reduce fat mass (1:30);
- Explaining fat flux—how fat enters and exits a fat cell (9:15);
- What fat balance looks like (21:15);
- What net fat influx looks like, and the impact of insulin in lipolysis (24:30);
- What net fat efflux looks like, and the benefits of fasting for breaking the hyperinsulinemic cycle (28:30);
- Exploring why most people with excess body fat will lose fat mass when reducing carbohydrates or eating a ketogenic diet (32:45);
- Why being in nutritional ketosis does not automatically translate to negative fat flux (fat loss) (42:40);
- Bob’s approach to scientific research (47:00);
- The importance of curiosity and a desire to learn (58:30);
- Bob’s tips and tricks for answering a scientific question in a time-crunch (1:00:00); and
- More.

§

The Peter Attia Drive

Losing fat and gaining fat: the lessons of fat flux

§

## Show Notes

§

## The two main ways to reduce fat mass [1:30]

**A lot of questions related to fat flux**:

*-Why doesn’t oxidation of fat necessarily mean you’re losing total body fat?*

*-If I eat a low carb diet and become a “fat burning machine,” why don’t I always lose fat on this diet?*

*-If I’m in ketosis, doesn’t it mean I’m burning fat?*

-Peter’s response: “*You can absolutely be in ketosis and gain weight. You can absolutely be a ‘fat burning machine,’ and still accumulate fat.”*

Some shorthand to be used in today’s podcast:

- Using “gaining weight” and “gaining fat” interchangeably
- So when people say, “I want to lose weight,” what they really mean is “I want to lose fat.”
- When people say, “I want to gain weight,” they usually mean “I want to gain muscle.”

-Well, there are two main approaches to losing fat

- 1 – Reduce the total number of fat cells
- 2 – Shrink the fat cells
- The former (reduce the total number of fat cells) is most typically something that is done with [liposuction](https://en.wikipedia.org/wiki/Liposuction)
- Note: An [NEJM study](https://www.nejm.org/doi/full/10.1056/NEJMoa033179) suggests that there is a profound difference between losing fat via liposuction vs. through dietary & lifestyle interventions

> “We should never confuse the metabolic benefits that come from reducing the size of adipose tissue with reducing the amount of it. The former, in the case of liposuction, is really a cosmetic procedure. Whereas the latter of course has cosmetic benefits, but much more importantly as a metabolic improvement.” —Peter Attia

***How do you shrink a fat cell? [6:12]***

Overview:

- An engineer would think about this by drawing a boundary, looking at the boundary conditions, and effectively understanding *what goes in* and *what comes out*
- Mass cannot be created from nothing and mass cannot disintegrate into nothing
- If a fat cell gets larger, there is a net accumulation of fat in that cell relative to how much goes out of it (and the converse is true)

*Quick example*: A room has 100 people in it

- There were people traveling in and out of the room constantly so if you want to understand if that room is increasing or decreasing in the number of people in it, you need to understand what is happening at every point where there’s an entry or exit
- By doing that, you can understand what is the net increase or decrease
- Peter refers to that as flux
- So, today they will be looking at fat gain/loss through the lens of fat flux—i.e., *What is the flux of fatty acids substrate into and out of a fat cell, and can we infer the behavior of that fat cell in response to that?*

*Bob adds*:

- *W*hen we talk about weight loss or weight gain or fat loss or fat gain, a lot of times we’ll hear about calories in, calories out
- Basically, if any more energy is entering the system than leaving it, the system is getting bigger and vice versa.
- If more energy is leaving the system than entering it, it’s more or less getting smaller
- What Peter is talking about is at the level of the adipose tissue—i.e., how much fat is going into the adipose tissue, how much is being released, and also how much is being trapped

*⇒ Check out Peter’s blog post:* [How to make a fat cell less not thin: the lessons of fat flux](https://peterattiamd.com/how-to-make-a-fat-cell-less-not-thin-the-lessons-of-fat-flux/)

## Explaining fat flux—how fat enters and exits a fat cell [9:15]

![](https://peterattiamd.com/wp-content/uploads/2021/04/slide-1.-WAT-ama22-1024x572.png)

**Figure 1. Overview of fatty acid and glucose metabolism in white adipose tissue. The body’s main store of chemical energy is in the form of TAG in WAT. Fat storage is the process of deposition of TAG; fat mobilization (or lipolysis) is the process of hydrolysis of the stored TAG to release NEFA into the plasma (bound to albumin), so that they can be taken up by other tissues. The major pathways and main sites of hormonal regulation are shown: a plus sign indicates stimulation, a minus sign inhibition. Dashed lines show multiple enzymatic steps.** [Source: [Frayn, 2010](https://www.amazon.com/Metabolic-Regulation-Perspective-Keith-Frayn/dp/1405183594)]

**WAT vs BAT**

- White adipose tissue (WAT) is called white adipose tissue to contrast it from brown
- BAT is a form of adipose tissue that is not as prevalent as WAT, but it has really unique metabolic properties, namely, a higher concentration of mitochondria and therefore a much greater metabolic activity
- We’re focusing on WAT, which is what most people think of when they think of fat — a glistening, yellow substance with cellular structure that looks surprisingly simple
- But white adipose tissue is an endocrine organ and is way more complicated than it looks under a microscope

**Looking at the above figure, it has two sides**:

- You have an “in” side
- and you have an “out” side
- On the left hand side of the above figure, there are 2 doors—the upper left door and the lower left door are **two ways that the fat cell gets fatter**
- On the right hand side of this page, you have the exit door—this is how the fat cell gets skinnier

**The first door (upper left of figure)**:

- This is basically how we bring fat into a fat cell
- What you see in this figure are triacylglycerides and in this figure, TAG, which is synonymous with TG
- TAG means three fatty acids onto a glycerol backbone and that’s the way that we very efficiently store fat
- \**IMPORTANT DISTINCTION*: When you get your blood tests done… they’re looking at your triglycerides carried in your lipoprotein, most of which are VLDL cholesterol (they are NOT looking at TAGs in your fat cells)
  - This test is nearly always done in a fasted state —
    - if you get a score of 60, that’s good;
    - if you get a score of 150, they doc will want you to lower that;
    - That test is primarily measuring the amount of triglycerides in your VLDL cholesterol
  - But if we measured your triglycerides as you were eating, we’d get a higher level for one and much of it would be carried in the [chylomicron](https://en.wikipedia.org/wiki/Chylomicron)
    - chylomicrons, which are very short-lived, are what bring fat that you eat in from the gut into the plasma, and then ultimately either get utilized or more commonly, get brought and stored here in the fat cell
    - that’s why this picture is showing both the chylomicron, which is postprandially and the VLDL, which is most other times
- Two things that are highlighted on the upper left side of the figure: i) **LPL**, and ii) **insulin**
  - LPL stands for [lipoprotein lipase](https://en.wikipedia.org/wiki/Lipoprotein_lipase) (anything that ends in -ase is an enzyme)
    - This lipase facilitates the transport of triacylglycerides into the fat cell
  - Insulin:
    - the reason that insulin is sitting there is insulin is the strongest regulator of that
    - insulin activates and upregulates LPL
    - Insulin is a very anabolic hormone—a building hormone—so it’s anabolic to muscle and unfortunately anabolic to a lot of cancer and to a fat cell
    - insulin is pro growth, and it wants to bring more of these fats in

**Second door (lower left side)**:

- Beneath that you will see glucose
- insulin also drives the translocation process of a GLUT4 transporter
- In a [discussion with Gerald Shulman](https://peterattiamd.com/geraldshulman/), focused on the muscle cell because the muscle cell is a far more important source of glucose disposal
  - In a metabolically healthy person, there’s very little glucose that is being brought into the fat cell
  - But as a person becomes more and more insulin resistant at the muscle, we will see more of the glucose entering the fat cell via the GLUT4 transporter and then insulin is promoting lipogenesis
  - what that means is glucose can actually be turned in to fatty acids

-So now you have **two pools of fatty acids**

- You have the fatty acids that have come in via the triacylglyceride pool
  - that means that they’ve been broken down into their glycerol backbone and the fatty acids
- Then you have fatty acids that are made de novo, hence the term de novo lipogenesis or DNL
  - Then they get re-esterified
  - While the glucose molecules are being broken down into fatty acid precursors, they’re also making glycerol
  - you turn glucose into fatty acid and glycerol
  - You bring triacylglyceride into the cell as pre fatty acids, and then you reconstitute them all into TAGs
  - Now you basically bring fat in — You take that from its storage form to its transport form, to its storage form and glucose in, and you basically just increase the density.
- **Summary**: Storing fat in the form of a triacylglyceride or triglyceride is a very efficient way to store it, and our body has an amazing set of tools to do that
- **Takeaway**: *Insulin is driving nearly all of the “fat in” side of the equation*.

**How do you get fat out of a fat cell? [17:10]**

- First and foremost, you have to break down the triacylglycerides or the triglycerides into the fatty acid and the glycerol
- And that is done primarily by another hormone called HSL, [hormone-sensitive lipase](https://en.wikipedia.org/wiki/Hormone-sensitive_lipase) (not shown on this figure)
  - In this figure just says lipases — we refer to these as hormone-sensitive lipases because they’re primarily driven by norepinephrine and epinephrine
  - Worth noting, and this figure points it out, we don’t really know the impact of glucagon on this in humans
  - In animal models, glucagon also seems to promote this
  - But at a minimum adrenaline and noradrenaline also known as epinephrine and norepinephrine, which are acute stress hormones, promote this
- Why is that the case? ⇒ the fight or flight response that will elicit adrenaline, noradrenaline, etc.
  - Basically, if you need energy very quickly (e.g., to run away from a tiger) those hormones are going to go up in response to that stimulus
  - And when those things go up, it’s going to break down those triglycerides into fatty acids, leave the adipose tissue and essentially flood the bloodstream with substrate
  - So it’s worth understanding that this process is regulated very finely by hormones, but it’s also dependent on substrate availability

*Two categories of thinking on the issue of ‘How get fat out of a fat cell’*:

- Camp #1: The amount of fat you have in a fat cell is 100% determined by the amount of calories you eat and the amount of calories you burn
- Camp #2: It has nothing to do with calories that you eat or burn. It has everything to do with insulin levels
  - The problem is, neither of those extreme views is correct, both of these things are somewhat correct
  - All of the amount of hormone in the world won’t change the fat, if you don’t have substrate availability
  - Similarly, the idea that just calorie balance alone makes this work is hard to explain empirically when you observe how easy it is to manipulate these things with endocrine systems

⇒ For example:

- Estrogen, testosterone, thyroid hormone—all of these other hormones play a role and we clearly see clinically
- A woman, for example, when she goes through menopause, tends to gain more fat weight
- A lot of that has to do with the change of estrogen and testosterone and their regulation of these hormones, whether it be the hormones themselves, the enzymes that regulate them, or otherwise.

**Takeaway**: Need to think of this through the lens of—

- First, it absolutely does matter at the macro level what the energy balance looks like, but that’s not entirely the determinant of it
- It also certainly matters *internally at the cellular level* what’s going on as well
- These things are impacted by what you eat, but they’re also impacted by different disease states, and other hormones such as cortisol

## What fat balance looks like [21:15]

![](https://peterattiamd.com/wp-content/uploads/2021/04/slide-2.-ama22-1024x643.png)

**Figure 2. Fat balance: DNL + RE = L (no net fat flux). Tried to size the arrows accordingly to match their relative contributions of each input and output.**

- The figure above shows what net fat balance looks like
- You’ve got **de novo lipogenesis + re-esterification=lipolysis**
- \*Back to the room analogy:
  - A room has 100 people in it
  - An hour from now, the room still has 100 people in it
  - Do you have any idea how many people entered the room in that time period? ⇒ No clue
  - Any idea how many people left the room in that period of time? ⇒ No clue
  - The only thing we know is that the amount of people that entered is the same as the amount of people that left
- Similarly, when we look at this adipose tissue: In fat balance, the only thing we know is the combination of de novo lipogenesis and re-esterification is equal to lipolysis

\*NOTE about de novo lipogenesis:

- When I’m talking about de novo lipogenesis, Peter is talking about the de novo lipogenesis that occurs where glucose is directly entering
- There is another de novo lipogenesis—[discussed in detail with Gerald Shulman](https://peterattiamd.com/geraldshulman/)—that occurs in the liver (and that’s actually a greater pool of DNL)
- And as a person gets more insulin resistant, all pools of DNL go up
- As a person’s carbohydrate tolerance falls/their inability to efficiently metabolize carbohydrates goes up, their liver is going to make more and more fat, and that fat is showing up as triglyceride by the time it gets to the liver
- And that’s really being counted in the re-esterification bucket
- So the VLDL that’s exiting the liver, that person that has a triglyceride level of 250, they’re hammering out triglycerides in the VLDL that are being re-esterified
- but they’re also undoubtedly bringing glucose in that’s going DNL directly

One more comment regarding DNL:

- The literature on how much DNL takes place in the fat cell itself is confusing so you just need to pay very close attention to the subjects
- The [1995 paper](https://pubmed.ncbi.nlm.nih.gov/8675642/) that is often quoted suggested that DNL in *healthy* people was quite low to the tune of less than 5% of total influx
- But that is definitely not the case for *unhealthy* people
- So you have to keep in mind how much of the DNL is also contributing through the re-esterification pathway

## What net fat influx looks like, and the impact of insulin in lipolysis [24:30]

**The case where someone is in net fat influx, i.e., “positive fat flux”**

- This is someone whose DNL + re-esterification > lipolysis

![](https://peterattiamd.com/wp-content/uploads/2021/04/slide-3.-ama22-1024x684.png)

**Figure 3. Fat imbalance: DNL + RE > L (net fat influx or “positive fat flux”).**

- This is a person who is getting fatter—i.e., their fat cells are getting bigger
- Clinically, this is not necessarily a person who is eating non-stop, contrary to popular belief
- These people are people who generally have shut off lipolysis
  - By contract, the person who’s in *fat balance* has reasonable amount of fat coming in, but they’re *very efficient at getting fat out of the fat cell*
- The person whose net accumulating, they are usually slowly gaining weight
- It’s a very frustrating place to be for many people, especially when their inputs don’t seem that big
- But even at the cellular level, their inputs are not that huge
- They probably have more de novo lipogenesis than the person who’s in fat balance
- And really **the issue is that their exit to the room is cut off**

**The impact of insulin in lipolysis**

- A really important thing that insulin does when it’s elevated is it inhibits lipolysis, which plays a role in the positive fat flux scenario
- And it’s a very non linear effect

![](https://peterattiamd.com/wp-content/uploads/2021/04/insulin-and-fat-breakdown-volek-1024x616.jpg)

**Figure 4. The precipitous drop in lipolysis as insulin goes up.** [[source](https://journals.lww.com/nsca-scj/fulltext/2010/02000/low_carbohydrate_diets_promote_a_more_favorable.6.aspx)]

- The figure shows at a very low level of insulin, there’s a high level of lipolysis
- As insulin goes up, lipolysis just crashes
- At some point, if insulin is high enough, **you’re not getting any fat out of the fat cell**

–*How does this manifest itself clinically*?

- Patients that show up and their fasting insulin is 20 and they’re postprandial insulin is 40, 60, 80, 100 and they’re saying, “I can’t lose a pound, no matter what I do.”
- And Peter believes them
- You aren’t going to be losing a pound of fat when your insulin is that high—that cycle has to be broken.

There are lots of ways to break that cycle:

- Carbohydrate restriction
- Fasting
- Fixing hypercortisolemia
- Fixing sleep
- Or, most likely, it’s a combination of all of the above

## What net fat efflux looks like, and the benefits of fasting for breaking the hyperinsulinemic cycle [28:30]

![](https://peterattiamd.com/wp-content/uploads/2021/04/slide-4.-ama22-1024x702.png)

**Figure 5. Fat imbalance: DNL + RE < L (net fat efflux or “negative fat flux”).**

The figure above would represent **a person whose fat cell is getting smaller, meaning they are in net fat efflux, i.e., “negative fat flux”**

*What do we notice?*

- The DNL arrow has almost vanished
- This is a person who is probably quite carbohydrate sensitive and/or eating very few carbohydrates
- Those are basically the two scenarios in which you look like this because **you’re just not turning glucose into fat**
- Probably re-esterifying a bit
- It really depends on the strategy being taken:
  - So you’re either re-esterifying a ton if you’re on a high fat, low carb diet,
  - or you’re probably not re-esterifying a ton if you’re just very insulin sensitive or not eating a lot of fat.
  - The lipolysis spigot is exceeding DNL + re-esterification
  - The magnitude of the difference of it is going to *depend on the re-esterification bucket*, not the DNL bucket
  - This is a person who is in a high state of lipolysis, which by definition, means **they have low insulin**
- “*There’s simply no way this phenotype exists without unmeasurable levels of insulin*.” says Peter

Bob referring to the “hockey stick” figure above:

- “What’s remarkable about it is if you want to look at what a hockey stick looks like, as far as the graph, that’s what it looks like.” says Bob
- You need remarkably low insulin levels in order to really get fat breakdown *maximized*
- As you move up in insulin, it’s going to essentially inhibit that lipolysis
- When talking about fat-in/fat-out…those two things are going on continuously—
  - If mobilization is exceeding deposition, then you’re looking at that negative fat flux or efflux
  - If deposition is exceeding mobilization, you are looking at positive fat flux or influx
  - It’s important to recognize that it’s not like if you eat a meal and your insulin goes up, you don’t necessarily completely shut down lipolysis, but insulin does an exceptional job of really ratcheting that down

**\*Peter on the benefits of fasting for breaking the hyperinsulinemic cycle**:

- There is no faster way to get into this state than fasting
- Nutritional ketosis is probably the fastest way to get into this state if you’re in a [eucaloric](https://en.wiktionary.org/wiki/eucaloric) state
- After that, it’s going to be basically a complete fast and then various forms of caloric restriction

> One of the greatest tools that we use fasting for is you take that person who you cannot break that [hyperinsulinemic cycle]. . .For me, taking that patient and getting them to the point where they can do three days, four days, five days of water only is an amazing way to break that vicious cycle.” —Peter Attia

In short—

- First, you break the cycle with that fast
- Next, you put them onto a different nutritional strategy
- Then, you periodically revisit the fasting

**Additionally**: there’s a whole suite of pharmacologic approaches to this

- Some of them intuitive like metformin
- Some of them counter-intuitive like GLP-1 agonists, which in the short run may actually raise insulin, but in the long run might actually lower postprandial insulin
- Another option is something else like an SGLT2 inhibitor

⇒ Check out the [discussion with Rich Miller](https://peterattiamd.com/richardmiller/) for more on this topic

## Exploring why most people with excess body fat will lose fat mass when reducing carbohydrates or eating a ketogenic diet [32:45]

**The question**: *Why do most people with excess fat to spare, who are on a well-formulated carbohydrate-reduced or ketogenic diet, lose fat?*

**Several reasons**:

- In the real world, many people who reduce carbohydrates end up eating less
- But the more important question is, *do they lose weight because they’re eating less or are they eating less because they are losing weight?*

To explain this, let’s consider the examples provided by [Gary Taubes](https://twitter.com/garytaubes?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) in his book, [Good Calories, Bad Calories](https://www.amazon.com/Good-Calories-Bad-Controversial-Science/dp/1400033462)

- Consider a growing child or a pregnant woman—
  - A growing child would go through growth spurts and they tend to be eating more when they’re going through growth spurts
  - Nobody would argue that they’re growing because they’re eating more
  - we would generally agree that they’re eating more because they are growing
- The same is true for a pregnant woman—
  - she goes through various spurts of growth during the pregnancy and at times her appetite is extremely high which is hormonally driven
  - they seem to be eating in response to a demand for growth

**Tying this back to the person who is gaining weight…**

- It’s possible that the reverse is true
- So as a person is changing the endocrine environment of their fat cell, which is to say they are liberating more free fatty acid & creating more substrate availability to the rest of the body…it could be that the body is saying, “*Oh, come to think of it, I just don’t need to eat as much*.”

-To illustrate this, let’s consider an [extreme example put forth by Mark Friedman and David Ludwig](https://jamanetwork.com/journals/jama/fullarticle/1199154) several years ago—

- They made this case that a person who is obese could, at a cellular level, still feel like they’re “starving” because even though their total quantity of stored energy is enormous, they can’t access them
- “And if they can’t access them, well, they might as well be buried in their backyard.”
- Therefore, if a person reduces carbohydrates resulting in lower insulin levels, that gets their body to start mobilizing fatty acid (their body to basically start eating itself) then it makes sense that a result of this process would not only be weight loss but also reduced intake

-Another subset of people may be increasing their energy expenditure when changing their diet

- Peter fell into this category initially when he first went on a ketogenic diet where it’s unlikely that he was actually eating less calories yet he was still losing weight
- Peter wonders if he was increasing his energy expenditure without realizing it, voluntarily or involuntarily
- For example, some people as their nutritional state changes, they just feel better
  - They just have more energy and they become more active for whatever reason. They’re like, “Oh wow, I don’t feel the need to lay around in the afternoons.”

**Exploring the reason why someone on a low-carb diet would lose fat:**

*Energy expenditure argument***:**

- [Hugo Rony](https://www.nytimes.com/1972/09/10/archives/dr-hugo-rrony-84-i-internist-is-dead.html), an endocrinologist at Northwestern in 1940 wrote [Obesity and Leanness](https://onlinelibrary.wiley.com/doi/pdf/10.1002/j.1550-8528.1995.tb00197.x) in which he referred to something called “the impulse to activity”
- It makes sense in light of what Peter was talking about with the [Friedman and Ludwig’s paper](https://jamanetwork.com/journals/jama/fullarticle/1199154)

*Internal starvation argument*:

- Another endocrinologist, [Edwin Astwood](https://en.wikipedia.org/wiki/Edwin_B._Astwood) talked about “internal starvation”
- Say you see somebody on the street and they’re morbidly obese and you think, “Wow, I’m sure they could afford to miss a few meals. Why don’t they eat a few salads?”
- Actually, it’s the opposite—if you see somebody who’s morbidly obese, it looks like that they probably can’t access that fat and they’re accumulating it
- And if they can’t access it, they’re starving internally which means that they’re going to be hungrier and more lethargic because they literally have less energy to burn if it’s getting sequestered into the fat tissue

Another point related to this question of, *do you eat less* ***carbohydrates*** *or is it just basically that you’re cutting* ***calories****?* …

- It looks like the answer is **both**
- Some people argue that, “Oh, it’s just because you cut 500 calories and you would be in calorie balance if you’re eating 2,000.”
- But if you look at some of these randomized controlled trials—
  - they do them ad libitum — in other words, they tell participant that they can eat all they want
  - Then you look at the results and you say, “Oh, well, it looks like they just ate 500 fewer calories a day. That’s why they lost the weight.”
  - Then you think, “*Well,* ***WHY did they eat 500 less calories****?”*
  - One hypothesis is that they are actually “getting” 2,000 calories a day—
    - They’re taking in 1,500 calories a day exogenously (food)
    - PLUS they are liberating another 500 calories from their fat cells and using those for energy
    - So, weirdly, if you look at both exogenously and endogenously, they’re in calorie balance.
    - So if we’re just looking at calories, that could be 2,000 calories of intake matching 2,000 calories of expenditure… It’s just that they’re endogenously getting more calories from the fat tissue.
  - A limitation of those type of studies—
    - They are really hard to do because to do them right, they have to be done in the free living environment
    - Obviously, researchers will go to great lengths to try to reproduce studies like that on metabolic wards
    - “But as I’ve learned having been involved in such things, even a metabolic ward” says Peter, “though it’s perfect for its precision and control, its use of indirect calorimetry, it does not reproduce the real world in terms of a person’s appetitive behavior.”
    - If we really want to understand this topic, you have to be able to study people with perfect precision, but in a free living environment because the deltas don’t need to be big — We could be talking about a delta of 200-300 calories a day, which is really not that much, but it’s easy to miss if you’re trying to rely on self-reporting questionnaires
    - It really needs to be weighed amounts of food and things like that

*The energy cost of making ketones*

- There are some people who are actually pretty metabolically inefficient at making ketones
- So the cost of making those ketones was so high there may be hundreds of calories per day that were being expended in that manner

\***Important caveat:**

- Peter says, “*There are a lot of people that I’ve come across who cannot lose any amount of weight on carbohydrate-restricted diets and I don’t understand why*.”
- “*There are a subset of people that just fare much better on a diet that restricts fats and is quite liberal with carbohydrates.*”
- “*I have some hypotheses around what that looks like, but I don’t even want to get into it because at this point it’s really quite speculative.*”

## Why being in nutritional ketosis does not automatically translate to negative fat flux (fat loss) [42:40]

**Question**: *Does being in nutritional ketosis ensure negative fat flux?*

- No, it does not
- If you go back to the equation, De novo lipogenesis (DNL) + re-esterification (RE) = lipolysis (L) — That’s what we call *fat balance*
- If we want to be in *negative fat flux*, then L needs to be bigger than DNL + RE
- Nothing about being in ketosis tells us the inputs to that equation
- Ketosis just tells you that you are making a lot of BHB, beta-hydroxybutyrate
- If you’re restricting carbohydrates and you’re not starving yourself, it means you’re eating a lot of fat
- And one cannot tell by looking at this equation if L is bigger than, or less than, RE
- Stated another way, you could force feed a person on ketosis and make them gain weight like crazy

![](https://peterattiamd.com/wp-content/uploads/2021/04/slide-5.-ama22-1024x730.png)

**Figure 6. Interplay of dietary fat, fat in the fat cells, and ketones.**

There’s multiple things that can happen with the fat you are eating

- The dietary fat can directly go into storage in the fat cells—the chylomicrons would pick it up and they’d stick it into the fat cell directly
- The fat can be utilized (muscles love fat cells)
- For someone in ketosis, the fat could go to the liver and the liver can make BHB which can be used by  the muscles, the heart, and the brain
- But again, nothing in this equation is telling you about the relative size of those arrows
- So one has to be very careful — it’s totally understandable why people get frustrated when they start eating a keto diet
  - They may be sticking their finger and the meter is showing them they are producing ketones yet they are not losing weight
  - They would think, *how is that possible?*

**The best way to troubleshoot if you are in ketosis and not losing weight**:

- Lower the fat intake
- If you’ve clearly demonstrated that you’re in ketosis, then you’re working on the lipolysis side of the equation with all you can
- The ketosis side of the equation implies insulin is low (which is great)
- You may just need to lower the re-esterification side by eating less fat

## Bob’s approach to scientific research [47:00]

**Bob’s approach to scientific research**

- Starts very broad
- First, try to triangulate onto, *What’s the question that I’m trying to answer?*

⇒ Example: [Omega-6 PUFAs](https://en.wikipedia.org/wiki/Polyunsaturated_fatty_acid)

- With something like Omega-6, there’s so much information and it seems like there’s a pretty big debate on whether they’re actually helpful or they’re benign or they’re harmful
- And he tries to gather as much information I can from those different camps on that question
- First, he will look for the most recent review papers using Google Scholar and PubMed
- He set parameters like only looking at review studies in the last, say three years, and see if anything pops up
- If it does, I’ll give it a read
- Note, it doesn’t necessarily have to come from JAMA or NEJM (those pop to the top anyway because the relevance I think is tied into the number of citations they have)
- Bob will also look for people that talk about the topic at hand – academics giving lectures or even some person on the internet with a blog or youtube channel

In this first phase of research, Bob is just trying to be gain exposure to all sides —

- “*Trying to be aware of differing opinions*” says Bob, because when reading review papers, “*I’m not sure if I’m getting all sides of the story*”
- He is looking for anybody saying something that is refuting what’s in the review paper, for instance, a blog post
- “*You can kind of see how they’re thinking through a problem and whether it’s worth taking seriously or not, or whether the person really knows what they’re talking about and understands the history*”

He’s also trying to understand, *what’s the conventional wisdom on this topic?*

- For something like Omega-6, the conventional wisdom kind of depends on which lab or research team you’re looking at
- “I take the approach that, ‘okay, how’s this person full of \*bleep?’ And I’ll see if there’s existing evidence to refute what they’re saying.”
- A review paper may have 200 references, and while Bob may not look at all 200, he will dig in to the references if there’s a section of the paper that he’s particularly interested in to make sure the claims that they’re making hold any water

*Peter adds some input*:

- Peter says Bob does really well at taking the “red team approach” which is generally viewing everything as “probably not true”
- Secondly, Bob has the discipline to actually go deep and not trust what someone writes
- For example, it’s surprising how often references in a paper don’t even make sense — There are times when a paper will cite something and say, “Well, this compound did this and these mice,” and you go and look and the paper cited has nothing to do with that
- They either completely misinterpreted it or misrepresented it

**A “short cut” can involve finding people you trust**

- Peter says he gravitates towards focusing on listening to trustworthy people
- Whereas, Bob often takes a deeper route by basically assuming everyone has made a mistake
- That said, Bob says that once you gather a ton of data you start to see which people really know what they are talking about
- And then you’ll start to look at what else that person has published on the topic
- Bob will go as far as to try to learn about that individual person’s background — “*I try to learn more about that person than they know themselves*.”

**Reaching out to people**

- Bob sometimes actually attends lectures of people and tries to talk to them after their lecture
- But you can also finding interesting speeches and lectures online — see [Gerald Shulman’s Banting Memorial lecture](https://www.youtube.com/watch?v=TnvmEUUtoZw) on YouTube
- Then you can actually find their contact info and follow up with them
- “You’ll be surprised that if you reach out to some of these people and you ask them some questions, I think that a lot of times they’re flattered and they’re happy to answer your questions…you can get a lot of insight”
- If you reach out to a lead author on a paper, for example, you can have a conversation with that person and there’s so many nuggets that are actually not in the paper itself
- “*It’s really eyeopening … there’s just human errors that are happening left and right…sometimes you read these papers and you think ‘follow the science and trust the science.’ … science, it’s actually really messy, but it’s terrific just to be able to try to figure things out*.”
- Researching limitations:
  - Bob always tries to look at the limitations of a paper — he gives credit to those that actually are honest about the limitations
- One “tell” for Bob —
  - You may see an extensive list of limitations but then immediately following the list you’ll see a paragraph of how they **totally controlled and adjusted for it — “**that’s another tell to me is that if they’re not being honest in the limitations of it”
- One more thing… “*When you talk to these people, sometimes you get a little bit more of the tonality of how they feel about the topic, which can be important*.”

**Fun fact:** Bob actually got introduced to Peter through [Gary Taubes](https://en.wikipedia.org/wiki/Gary_Taubes)

- Bob read a couple of Gary’s articles that was virtually the opposite of everything he had learned in school
  - [The (Political) Science of Salt](https://garytaubes.com/wp-content/uploads/2011/08/science-political-science-of-salt1.pdf)
  - [The Soft Science of Dietary Fat](https://garytaubes.com/wp-content/uploads/2011/08/Science-The-soft-science-of-dietary-fat.pdf)
- He decided to reach out to Gary and Gary ended up being really generous with his time
- “*I think that it is really important [that] people will see that curiosity.*”
- Ultimately, Bob met Peter through Gary

## The importance of curiosity and a desire to learn [58:30]

- Even Peter and Bob, who have backgrounds in science, are constantly learning new things
- Peter was recently sent a paper by friend and [former podcast guest](https://peterattiamd.com/lloydklickstein/) [Lloyd Klickstein](https://www.linkedin.com/in/lloyd-klickstein-69b26870/)
- It was a very interesting paper about proteomics in a very interesting experimental model and the figures in the paper were so complicated that Peter “. I got through the paper and it was pretty complicated, and then I got to the figures and the figures were really complicated
- Had “no freaking clue” what it meant so he just had to start Googling stuff

> “Part of it is you just have to acknowledge like it’s okay not to understand something and it might take you a little longer to get through it, but having that sort of curiosity is, I think the most important step to going through.” —Peter Attia

## Bob’s tips and tricks for answering a scientific question in a time-crunch [1:00:00]

*What does Bob do when he has a deadline to answer a complicated question from Peter?*

- Oftentimes, the answer can’t just be googled
- Bob’s process will depend of i) the question and topic and ii) what knowledge he’s already accumulated on said topics (in many cases simply a curiosity-inspired [nerd safari](https://peterattiamd.com/articles/))

In many cases, this is where Bob leans on the network of people that he has created —

- *Who’s way better at answering this question than I am*?

- *Has somebody already done that*?

- *Is somebody insightful on that*?

- He recently emailed [Matt Kaeberlein](https://peterattiamd.com/mattkaeberlein/), for example, on an aging-related question — “*He gave me a really insightful answer and also said, ‘Here are the things where I’m not sure about this, and those are things that you may want to look into independently.*’”

**One of my Bob’s “tricks”**

- If you really need an answer fast, you can reach out to somebody that you’ve already established a relationship with because you showed interest in their work
- When Bob does reach out to them, he tries to provide them some info on a topic that interests them that perhaps that haven’t been aware of to sort of repay their generosity
- Peter says, “*you’re selling yourself short because you also organize information very well*”

***Example of how Bob answered recent question from Peter***

There was a [JAMA paper](https://jamanetwork.com/journals/jama/fullarticle/2777172) that was writing about all the COVID vaccines

- The article included a very insightful comment from a reader which pointed out that comparisons amongst vaccines was being reported in terms of relative risk rather than absolute risk reduction:

*The effect of vaccine is measured by comparing the risk reduction in the two groups of participants (vaccinated and placebo groups) in randomized clinical trials. Relative risk reduction (RRR) or commonly known as vaccine efficacy is often used to express the magnitude of this effect which is derived simply by subtracting the relative risk from one. Alternatively, absolute risk reduction (ARR) is rarely used but is a much more meaningful measurement of risk. ARR is difference between the risks of disease in the two populations and defines the absolute magnitude of the risk.*

*RRR is frequently reported in medical literature and news media. When vaccine effect expressed in relative terms, 95%, 94.6% and 66% VE were reported for Pfizer, Moderna and J& J vaccines respectively. In contrast, only Advisory Committee on Immunization Practices (ACIP) reported the ARR i.e 0.9%, 1.3% and 1.7% for Pfizer, Moderna and J& J vaccines respectively.*

*In conclusion, when the magnitude effect was expressed in relative terms, much larger percentages result than when the publicly available clinical data was discussed in absolute terms. Thus, the presentation of RRR certainly created the perception bias of efficacy. Among the three vaccines, J&J vaccine has the highest ARR but lowest RRR.*

(Here are the related reports from the FDA for [Pfizer](https://www.fda.gov/media/144245/download), [Moderna](https://www.fda.gov/media/144434/download), and [Janssen](https://www.fda.gov/media/146217/download) (J&J))

- Peter was surprised he wasn’t aware of this so he put Bob and Rachel on the case, independently, and they both came up with the same answer
- Peter says “It was a great example of basically really organizing the hell out of a bunch of data and knowing that like, if you can’t present this in a single table, you don’t know what you’re talking about”

Peter asks Bob to elaborate on how he pulled this together:

- It starts with Bob’s mentality of “you don’t trust it, but verify it” (a revised take on [Ronald Regan’s “trust, but verify”](https://en.wikipedia.org/wiki/Trust,_but_verify))
- So he sees the comment, he assumes the commenter is wrong, but he is going to verify he is wrong
- But it turned out that the commenter was more or less correct

*How did Bob determine that?*

- First, he thinks… “Is there something within that comment that I could actually identify within this 175 page FDA report on one of these vaccines and see if I can hone it, chisel it down to [find] actually what this person is talking about?”
- In that case, it was the J&J vaccine that it seemed like there was a discrepancy in the absolute risk reduction that this commenter was coming up with
- Bob realized that it was correct, but it was a different table within that FDA briefing document ([Pfizer](https://www.fda.gov/media/144245/download), [Moderna](https://www.fda.gov/media/144434/download), and [Janssen](https://www.fda.gov/media/146217/download) (J&J))
- It came from looking at one of the numbers that the commenter put in there and searching it and finding it, going through on a PDF and hitting a particular number with a decimal point and then honing in on that and finding it

![](https://peterattiamd.com/wp-content/uploads/2021/04/vaccines-1024x450.png)

**Figure 7. The spreadsheet Bob made to compare the JAMA commenter’s values to the data from the FDA, which ended up matching in terms of absolute risk reduction. When Bob was referring to the different table, you can see in the “Janssen” section of the table Bob has “Table 10” and “Table 14” side-by-side and you can see that the commenter’s ARR match the FDA docs for all three vaccines (using Table 14 and not Table 10 for Janssen).**

**Up shot**

- Bob’s curiosity in understanding all this terminology is what helped him in this case—Some people blow off steam but scrolling instagram, but Bob blows off steam by watching lectures on YouTube

\*Recommendations for online resources:

- [Ninja Nerd Lectures](https://www.youtube.com/channel/UC6QYFutt9cluQ3uSM963_KQ) on YouTube
- [John Ioannidis](https://profiles.stanford.edu/john-ioannidis)
- [Vinay Prasad](https://www.vinayakkprasad.com/)
- Check out the [Studying Studies series](https://peterattiamd.com/ns001/)
- [Richard Feyman](https://en.wikipedia.org/wiki/Richard_Feynman)’s old lectures on YouTube

> “You have to have that insatiable curiosity about it in the first place to become smarter. I don’t think there’s a shortcut.” —Bob Kaplan

§

## Selected Links / Related Material

**Paper showing a profound difference between losing fat via liposuction vs. through dietary & lifestyle interventions**: [Absence of an Effect of Liposuction on Insulin Action and Risk Factors for Coronary Heart Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa033179) (Klein et al., 2004) [5:00]

**Peter’s blog post about fat flux**: [How to make a fat cell less not thin: the lessons of fat flux](https://peterattiamd.com/how-to-make-a-fat-cell-less-not-thin-the-lessons-of-fat-flux/) | Peter Attia (peterattiamd.com) [8:30, 30:45]

**Episode of The Drive with Gerald Shulman**: [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) | Peter Attia (peterattiamd.com) [14:45, 22:45]

**A paper that has historically been quoted which examined what happened to DNL during periods of over- and under-feeding CHO and fat**: [Short-term alterations in carbohydrate energy intake in humans. Striking effects on hepatic glucose production, de novo lipogenesis, lipolysis, and whole-body fuel selection](https://pubmed.ncbi.nlm.nih.gov/8675642/) (Schwarz, Hellerstein et al., 1995) [24:00]

**Paper showing the “hockey stick” figure showing the precipitous drop in lipolysis as insulin goes up**: [Low-Carbohydrate Diets Promote a More Favorable Body Composition Than Low-Fat Diets](https://journals.lww.com/nsca-scj/fulltext/2010/02000/low_carbohydrate_diets_promote_a_more_favorable.6.aspx)

**Episode of The Drive with Rich Miller**: [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) | Peter Attia (peterattiamd.com) [32:45]

**Gary Taubes’s book**: [Good Calories, Bad Calories: Fats, Carbs, and the Controversial Science of Diet and Health](https://www.amazon.com/Good-Calories-Bad-Controversial-Science/dp/1400033462) by Gary Taubes | (amazon.com) [33:30]

**Paper suggesting that a person who is obese could still be “starving” at a cellular level**: [Effects of Dietary Composition on Energy Expenditure During Weight-Loss Maintenance](https://jamanetwork.com/journals/jama/fullarticle/1199154) (Ebbeling, et al., 2012) [35:00]

**Obesity and Leanness by Hugo Rony**: [Obesity and Leanness](https://onlinelibrary.wiley.com/doi/pdf/10.1002/j.1550-8528.1995.tb00197.x) (Hugo Rony, 1995) [36:45]

**Ronald Reagan – “*****trust, but verify*****”**: [51:30]

- [Trust but verify](https://www.youtube.com/watch?v=As6y5eI01XE) | theconservativewill (youtube.com)
- [Trust, but verify](https://en.wikipedia.org/wiki/Trust,_but_verify) | (wikipedia.org)

**Gerald Shulman’s 2018 Banting Lecture**: [Critical Viewing on Insulin Resistance – Banting Medal for Scientific Achievement – Gerald Shulman](https://www.youtube.com/watch?v=TnvmEUUtoZw) | Ivor Cummins (youtube.com) [55:15]

**Article by Gary Taubes that opened Bob’s eyes and inspired him to reach out to Gary**: [58:00]

- [The (Political) Science of Salt](https://garytaubes.com/wp-content/uploads/2011/08/science-political-science-of-salt1.pdf) | Gary Taubes (garytaubes.com)
- [The Soft Science of Dietary Fat](https://garytaubes.com/wp-content/uploads/2011/08/Science-The-soft-science-of-dietary-fat.pdf) | Gary Taubes (garytaubes.com)

**Episode of The Drive with Lloyd Klickstein**: [#118 – Lloyd Klickstein, M.D., Ph.D.: Rapamycin, mTOR inhibition, and the biology of aging](https://peterattiamd.com/lloydklickstein/) | Peter Attia (peterattiamd.com) [59:00]

**Episode of The Drive with Lloyd Klickstein**: [#118 – Lloyd Klickstein, M.D., Ph.D.: Rapamycin, mTOR inhibition, and the biology of aging](https://peterattiamd.com/lloydklickstein/) | Peter Attia (peterattiamd.com) [59:00]

**JAMA paper about the COVID vaccines**: [The Johnson & Johnson Vaccine for COVID-19](https://jamanetwork.com/journals/jama/fullarticle/2777172) (Livingston et al., 2021) [1:03:00]

If you look at the briefing document, probably put up in the show notes, I forget how many tables there are, but it’s way in the double digits, more or less. [1:05:00] #askbob

**YouTube channel Bob recommends for research**: [Ninja Nerd Lectures](https://www.youtube.com/channel/UC6QYFutt9cluQ3uSM963_KQ) | (youtube.com) [1:06:00]

**Episode of The Drive with John Ioannidis**: [#143 – John Ioannidis, M.D., D.Sc.: Why most biomedical research is flawed, and how to improve it](https://peterattiamd.com/johnioannidis/) | Peter Attia (peterattiamd.com) [59:00]

**Episode of The Drive with Vinay Prasad**: [#133 – Vinay Prasad, M.D., M.P.H: Hallmarks of successful cancer policy](https://peterattiamd.com/VinayPrasad/) | Peter Attia (peterattiamd.com) [59:00]

**The Studying Studies series**: [1:06:30]

- [Studying Studies: Part I – relative risk vs. absolute risk](https://peterattiamd.com/ns001/)
- [Studying Studies: Part II – observational epidemiology](https://peterattiamd.com/ns002/)
- [Studying Studies: Part III – the motivation for observational studies](https://peterattiamd.com/ns003/)
- [Studying Studies: Part IV – randomization and confounding](https://peterattiamd.com/ns004/)
- [Studying Studies: Part V – power and significance](https://peterattiamd.com/studying-studies-part-v-power-and-significance/)

§

## People Mentioned

- [Sam Klein](https://diabetesresearchcenter.wustl.edu/people/samuel-klein-md/) [5:00]
- [Gerald Shulman](https://medicine.yale.edu/profile/gerald_shulman/) [14:45, 22:45, 55:15]
- [Marc Schwartz](https://gufaculty360.georgetown.edu/s/contact/00336000014Ray3AAC/marc-schwartz) [24:00]
- [Marc Hellerstein](https://vcresearch.berkeley.edu/faculty/marc-hellerstein) [24:00]
- [Ralph DeFronzo](https://www.uthscsa.edu/patient-care/physicians/providers/1851408843/Ralph-DeFronzo) [29:45]
- [Jeff Volek](https://www.virtahealth.com/people/jeff-volek) [29:45]
- [Stephen Phinney](https://www.virtahealth.com/people/stephen-phinney) [29:45]
- [Rich Miller](https://peterattiamd.com/richardmiller/) [32:45]
- [Gary Taubes](https://en.wikipedia.org/wiki/Gary_Taubes) [33:30, 58:00]
- [Mark Friedman](https://monell.org/mark-friedman/) [35:00]
- [David Ludwig](https://www.drdavidludwig.com/) [35:00]
- [Hugo Rony](https://www.nytimes.com/1972/09/10/archives/dr-hugo-rrony-84-i-internist-is-dead.html) [36:45]
- [Edwin Astwood](https://en.wikipedia.org/wiki/Edwin_B._Astwood) [37:00]
- [Jerry Lewis](https://en.wikipedia.org/wiki/Jerry_Lewis) [51:30]
- [Ronald Reagan](https://en.wikipedia.org/wiki/Ronald_Reagan) [51:30]
- [Lloyd Klickstein](https://www.linkedin.com/in/lloyd-klickstein-69b26870/) [59:00]
- [Matt Kaeberlein](https://en.wikipedia.org/wiki/Matt_Kaeberlein) [1:02:00]
- [John Ioannidis](https://profiles.stanford.edu/john-ioannidis) [1:06:30]
- [Vinay Prasad](https://www.vinayakkprasad.com/) [1:06:30]
- [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) [1:06:45]

§