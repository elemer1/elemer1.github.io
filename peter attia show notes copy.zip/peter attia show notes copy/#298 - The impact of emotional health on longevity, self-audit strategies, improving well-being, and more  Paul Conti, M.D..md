# #298 ‒ The impact of emotional health on longevity, self-audit strategies, improving well-being, and more | Paul Conti, M.D.

**Source:** [https://peterattiamd.com/paulconti4/](https://peterattiamd.com/paulconti4/)

---

Paul Conti is an author and practicing psychiatrist who specializes in helping people heal from trauma. In this episode, Paul returns to *The Drive* to delve into the intricate relationship between emotional health, healthspan, and lifespan. He first challenges common assumptions about the inevitable decline of emotional health with age, providing strategies for conducting a comprehensive audit of internal emotional health. He establishes a framework for the foundation of good emotional health: a balance between the generative drive, the assertive drive, and the pleasure drive. Paul also explores the nuanced dynamics of motivation, happiness, and satisfaction as it relates to material possessions, draws connections between physical and emotional well-being, confronts the impact of negative self-talk, and describes how making peace with our mortality can foster a sense of hope, purpose and well-being. Additionally, Paul offers many practical insights into initiating emotional health improvements and navigating the search for a suitable therapist.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/paulconti4/the_Drive_public.png)

Play

#298 ‒ The impact of emotional health on longevity, self-audit strategies, improving well-being, and more | Paul Conti, M.D.

#298 ‒ The impact of emotional health on longevity, self-audit strategies, improving well-being, and more | Paul Conti, M.D.

1x15s30s

0:002:23:51

## We discuss:

- The importance of prioritizing emotional health as we age [2:45];
- The impact of emotional health on healthspan and how to foster a proactive approach to emotional well-being [7:00];
- The discrepancy between outward success and inner fulfillment, and the importance of a healthy “generative drive” for genuine well-being [13:00];
- A deeper dive into generative drive: impact on human behavior, resilience, purpose, and more [23:15];
- Evaluating one’s inner self: introspection, self-awareness, challenging societal norms, and returning to the basics of physical and emotional well-being [29:00];
- Self-auditing tools: introspection, curiosity, and exploring underlying reasons for unwanted behaviors [41:45];
- Breaking free from destructive cycles by understanding the continuum of self-care and addictive behaviors and remaining curious [50:15];
- Critical self talk: the malleability of one’s inner dialogue and the potential for transformative change with perseverance and self-compassion [1:00:15];
- Slowing the anger response and gaining insights into the underlying triggers to achieve lasting change and self-understanding [1:13:45];
- Foster gratitude and humility by achieving balance between the three drives—assertion, pleasure, and generative [1:20:45];
- The conflict between intellectual understanding and emotional feelings, problematic comparison frameworks, and the importance of living in the present with intentionality [1:24:15];
- How making peace with our mortality can foster a sense of hope, purpose and well-being [1:34:45];
- Advice for finding a compatible therapist [1:43:45];
- The key components of therapeutic progress [1:57:00];
- The caricatures of four common patient phenotypes, and how to get through to them [2:05:30];
- How Paul manages his own well-being and the emotional challenges that come with his line of work [2:15:15]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Paul Conti has been on *The Drive* multiple times and was one of our first guests in September 2018 on [episode #15](https://peterattiamd.com/paulconti/)
- Paul is a practicing psychiatrist and author of [*Trauma: The Invisible Epidemic: How Trauma Works and How we can Heal from it*](https://www.amazon.com/Trauma-Invisible-Epidemic-Works-Heal/dp/1683647351/ref=sr_1_1?crid=MS9CFNXCNJOK&dib=eyJ2IjoiMSJ9.7mcVwe9wf7iEpcEgP92jjths4D7vTjAJyozv8RxaCGWkMauclJ8ebT4VasAMTvW8Iz7xLmm-ZFKhqJdYvcG4d092KhCKkCbHql3Bntbcm4mXh9V1q3Jo9OTfjKxrDeTvUp6hh1ojMmOmd09loyakDjU0T2YunlCb3JmBKxVtbLVzZSP8ZD8SBxDzo0Lxff72jiAkNmk72vZbkD_TvgS0DvystEYYKozp15DKJQ6uVQ4.-q5xciOfTGcgMUOc5eE_676RMwgWPop9TTp92fkAyI4&dib_tag=se&keywords=trauma+the+invisible+epidemic+by+paul+conti&qid=1709564787&sprefix=trauma+the+in%2Caps%2C108&sr=8-1)
- He’s a graduate of Stanford University School of Medicine and he completed his psychiatric training at both Stanford and Harvard where he was appointed chief resident
- He then served on the medical faculty before moving to Portland and founding [Pacific Premier Group](https://pacificpremiergroup.com/)
  - A practice focusing on addressing mental health from a trauma-based perspective
- In this episode, we speak about emotional health and its relationship to lifespan and healthspan
- Through this, we try to look at the various ways listeners can take an audit of their internal and emotional health, knowing that this is one compartment of healthspan for which we don’t have biomarkers and for which we don’t expect an inevitable decline as we age
- We cover:
  - How emotional health can also increase with age
  - What drives people and their motivations, happiness and satisfaction as it relates to material possessions
  - The connection between physical and emotional health
  - Negative self-talk
  - Accepting death and more
- We end this conversation speaking about how people can take a first step in improving their emotional health and what people can look for in a therapist if they deem it necessary

## The importance of prioritizing emotional health as we age [2:45]

- As Peter’s thinking on longevity has evolved, he feels more and more drawn to healthspan over lifespan
  - Not that these are ever mutually exclusive (they’re not)
  - And virtually without exception, anything that’s enhancing healthspan is enhancing lifespan.
- It’s just a question of focus, and when you focus more of your energy on healthspan, you’re getting a lot of those lifespan benefits for free
- You can clearly do a lot of the one-off stuff that is purely lifespan related (like managing your [apoB](https://peterattiamd.com/understanding-cardiovascular-disease/) and [cancer screenin](https://peterattiamd.com/ama56/)g and things like that)
- But it’s this focus on cognitive health and physical health that get you so much of that lifespan benefit, and of course you’re enjoying the quality of your life
- Those 2 decline quite predictably, and so really what we’re trying to do is we age is delay the rate of decline
- There’s this 3rd component of healthspan, which is **emotional health**, which is what obviously we’re going to speak about in great detail
- What Peter tells people (and what he tells himself when he’s feeling a little depressed about aging) is that the thing we have going for us is that is **the 1 thing that doesn’t have to get worse with age**
  - Everything else gets worse with age
  - You can do quite a bit to mitigate that and reduce the magnitude of the negative derivative, but you’re not making it a positive derivative
  - But this doesn’t have to be true for emotional health

**In your experience working with people, do you see that people generally become happier and more satisfied as they age?**

*How deliberate does one need to be about emotional health to ensure that you can be on an increasing curve of emotional health as you age?*

- Unfortunately, emotional health often declines as people get older
  - That is sort of the rule, but it doesn’t have to be
- Emotional health can improve throughout the lifespan, but there’s so many things that we have to be aware of
- Does it take intention? Yes
  - We have to really think about how we take care of ourselves
  - How is your emotional health setting the climate for your physical health, your cognitive health, for your happiness?
- Very often we get swept up in this idea that, “*Oh, time is passing and we’re getting older. Isn’t that bad?*”
  - There’s a whole set of societal standards that bias us away from good emotional health as we get older
  - This idea that “It’s sad that we lament getting older and we talk about how fast times is going”, because that’s really a societal construct

> “*It’s a social construct that we can change… if we’re actively taking care of ourselves.*”‒ Paul Conti

- **Taking care of ourselves** means taking care of our bodies so we can remain active
  - Remaining interested in new things ‒ learning
  - Keeping an expansive mindset that if we’re doing this, we’re setting a climate inside of us that is conducive to all these other good things to healthspan, lifespan, cognitive health
- So often we say that we’re trying to do that, but we’re ignoring the climate that we’re living in
  - And we have much more control over that

***Part of the message of healthspan and lifespan is attend to our emotional health and take it seriously because we’re living in it day in, day out***

- We’ve got to step back from our lives often and look at what we are presuming
  - Are we thinking, “*Oh, it’s just bad to get older and the jokes and all the dialogue within us is negative*”
  - Or, can we feel good about getting older that we have achievements under our belt
  - And have learning and wisdom that we didn’t have before
  - And continue to stay curious and active and get happier and healthier across the lifespan
- There’s a demographic of people for whom that’s absolutely true, and it’s wonderful to witness them
  - They’re very, very different than people who are not like that
  - People that are still bright-eyed, engaged in the world as they age
  - And that doesn’t happen by accident

## The impact of emotional health on healthspan and how to foster a proactive approach to emotional well-being [7:00]

- When someone asks Peter to explain what the cognitive component of healthspan is, we can talk about executive function, we can talk about processing speed, we can talk about recall memory
- Of course, you can drill down further and further and further into these things and you can start to paint a pretty comprehensive picture of what cognitive health involves
- You can also do that cognizant of the changes that occur
- [Arthur Brooks](https://arthurbrooks.com/) has written quite eloquently about the transition from **fluid intelligence** to **crystallized intelligence**
  - [In the book [*From Strength to Strength*](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=), and discussed in [episode #226](https://peterattiamd.com/arthurbrooks/)]
  - While our fluid intelligence peaked when Peter and Paul met each other (and in that regard they’ve only become stupider), they’ve gained other intelligence (this crystallized intelligence) that’s more experiential and more about pattern recognition
  - While we might not have the processing speed we once did, we’re intelligent in a different way
- The same is true on the physical side
  - Peter could spend the next 5 hours talking about the nuances of strength, power, explosiveness, cardio respiratory efficiency, maximum cardio, flexibility, balance, all of those things
  - We can measure all of those things effectively and we can track progress
    - Peter does this with his patients

**How would you explain the umbrella of a person’s emotional health?**

- Peter wants to know how we can evaluate it
- Paul evaluates it by looking inside and trying to understand what’s going on in us
  - When we wake up in the morning, how do we feel about ourselves?
  - How do we feel about life?
    - Are we low-grade afraid?
    - Do we feel on the back foot?
- There’s so much of this going on in us and then that impacts our **self-talk**, which is why we may not have biomarkers

***But we can look inside, so to speak, by asking the right question***s

- What do you say to yourself when you are alone?
- What kind of phrases or mantras seem to repeat over and over?
- Do you criticize yourself?
- Do you have a shadow voice within you that is oppressive or that is regretful or that is ashamed?
- What is going on inside of us is often very opaque to us, even though we are living through that when we then interface with the world

> “*If we inquire, if we become curious about ourselves, we learn so much more about what is going on inside of us and it can guide us towards change*.”‒ Paul Conti

- If a person wakes up and doesn’t feel good about waking up or feels afraid or feels ashamed, why is that?
  - What can be done to change that?

**Very often it’s the environments inside of us we’re not taking good care of**

- For example, if we harbor traumas within us that we haven’t talked about or processed
- Or we know that we don’t feel great, we don’t know quite why, and then we’re sort of afraid and confused and we move forward

***This idea that we should be as interested in what is going on inside of our minds, what is going on inside of us emotionally as we are about our bodies, even though we have many more markers, biomarkers, internal and external to look at physically***

- Sometimes Paul will see a person paying a lot of attention to that, but it’s all couched in an emotional climate that’s not good and at times becomes angry and aggressive
  - Like, “*I’m going to fight aging and I’m not going to let this get the best of me.*”
  - That’s not a recipe for happiness and health
  - Acceptance is needed ‒ we need to accept the fact that we’re aging
- Peter is right, they had much greater processing power when they first met
- They could sprint better, but life isn’t a sprint
- Paul hopes and believes that they’re both smarter now even though their processing power has changed for the negative
  - Overall, he hopes they are wiser and happier

**We have a salience bias toward the negative**

- We say, “*Oh, look, I could do so much more before. I could hold so much more in working memory. I was so much faster. Look, I’m getting old.*”

***The trade-off for that is increased intrinsic knowledge (things we know without having to think about it, that reside in our unconscious mind), which is something we don’t value as much***

- Paul thinks if we can get over some of the biases that come from the outside [we would do better]
  - Pay attention to our emotional health
- Ask yourself:
  - What is going on inside of me?
  - How is it affecting me?
  - How are all these things I do from morning till night affecting what’s inside?
  - And how’s what’s inside affecting that or things I want to change or do differently?

***When we become curious and engaged, and we want to learn, this is a characteristic of being younger***

- If we can maintain that curiosity about ourselves and the world around us then we change this really big factor that often is working against us, without us being aware of it
  - By looking at it, we can control it and make it work for us

## The discrepancy between outward success and inner fulfillment, and the importance of a healthy “generative drive” for genuine well-being [13:00]

**How do you integrate into emotional health one’s sense of purpose, the idea of satisfaction, and relationships?**

- Peter points out that there is so much literature on one’s sense of purpose
- For the person who is working hard but feeling down and out, if they **won the Powerball** today and never had to work again
  - You might think their life would be better
  - But the data are pretty clear that the answer is no
- If you don’t have something to do, if you don’t have purpose, then it’s very difficult to have an emotional keel that’s adequate
- Peter describes satisfaction as a feeling of achievement that follows a struggle
  - Achievement with no struggle is not particularly satisfying
  - [Arthur Brooks](https://arthurbrooks.com/) has talked a lot about this idea that satisfaction is sadly fleeting, but nevertheless it temporarily provides a positive feeling that is worth reinforcing
    - [In his book [*Build the Life You Want*](https://www.amazon.com/Build-Life-You-Want-Science/dp/0593545400/ref=sr_1_2?crid=16EXA5NNUUZY4&keywords=arthur+brooks+and+oprah+winfrey+book&qid=1698245918&sprefix=arthur+brooks%2Caps%2C105&sr=8-2), discussed in [episode #280](https://peterattiamd.com/arthurbrooks2/)]

Peter asks, “*What is the nature of our relationship to self and then the quality of our relationships with others? What else would you add to this or would you subtract anything from it?*”

- The first thing Paul would do is take the extremely important things Peter just said and put them under the heading of a **generative drive**
- The field of mental health has long understood that we have drives within us, and it has been focused on an **assertion or an aggression drive** (which makes sense)
  - We have to do things in order to survive, in order to achieve, in order to move ahead ‒ there’s an assertion drive within us
  - Peter thinks natural selection must have been ruthlessly selecting for this
  - The thought is it would be very hard to survive without either one of these
    - Especially in an era of human development when one took a significant amount of responsibility for one’s own survival
    - One had to be assertive
    - You had to want to impose yourself on the world around you
- There is also the **pleasure drive**, which at times has been misunderstood as a drive for hedonism
  - Pleasure comes in all sorts of ways
    - Pleasure comes from being inside out of the rain
    - Pleasure comes from being warm and not cold
    - Pleasure comes from having enough to eat
  - Pleasure drives us not just through sex and satisfaction that make it more attention, but through relief of pain, through a sense of safety, a sense of security
- In the field of mental health, we’re very focused on humans, which has guided our understanding and beliefs about ourselves
- We see assertion and pleasure, but that ignores the humanity inside of us
  - People create for the satisfaction of creating something new
  - Or go somewhere new because we don’t know what’s there

***There’s something else going on in us and that other thing is the generative drive and aspects of philosophy and literature and religious studies and psychological studies point us in this direction, but the field of mental health doesn’t acknowledge that we want to live and create beyond ourselves***

- For example, we have children not just so someone may take care of us later on and we perpetuate our genes, but for the joy of seeing the children learn and develop and be in the world and see them grow?
- There are things inside of us that are about **creation** and are about **growth**

**When we are in touch with that, when there is an active generative drive, then we are on this path to happiness**

- This is the way to take care of everything, emotional health, cognitive health, physical health
- It all naturally comes together if we’re approaching life from a healthy place

**Back to the example of someone who is working and unhappy and feels like, “*****Oh, I’ll be happy if I win the lottery.*****” Why does the data show us that’s not true?**

***Because the presumption there is the generative drive isn’t satisfied by either scenario***

- If the person is working and they’re not happy, then there’s something there that could be, would be, probably should be different
  - Are they enjoying the work that they’re doing?
    - Is this what’s really inside of them, what they value?
    - Are they doing it just because they feel it pays them more money and they have to make more money?
    - Do they feel that they need to make more money than they’re making and now they’re unhappy and disappointed?
  - There’s something in their work that’s not honoring this **greatest human thing**: which is to make more than what we are
  - It’s not honoring the generative drive

***There’s enough money, but there’s nothing coming out of the person that’s creative***

- If someone imagines winning the Powerball and then maybe they’ll go back to school and learn something they really wanted to learn or they’ll go do this thing they really wanted to do or they’ll grow a giant garden
  - If having the money that would come from the lottery win and having the time subserves the generative drive, then that is a good thing
  - But money alone doesn’t provide that

**That’s where inquiry could come in**

- What is going on in this person’s life?
- How are they working?
- What choices are they making and why?
- What’s inside of them?
- Do they feel good about what they’re doing?
- Do they want to do something else?

**Paul often sees examples of this where people are out of accord with themselves and they’re unhappy and then there’s a sense of futility about it**

- Winning the lottery is not the answer
- There are many, many things we can change in our lives
- Think of how many different things both Paul and Peter have done across the lifespan?
  - Some of which they incorporate going forward and some of which they have decided to move away from
- Some of that is honoring the generative drive of, “*If I’m not feeling a certain way when I’m getting up in the morning, what is it that I need to do differently to feel that way?*”

**What is your belief around the innate nature of the strength of the generative drive in an individual?**

*If you look at a thousand children that are born across various cultures, socioeconomic status, different races, look at all factors, what is your view on the innate strength of that drive? Do you believe it’s relatively preserved and that early life experiences shape it as adults?*

- There are nature and nurture aspects
- It’s wide-ranging across humans
- If we step back within a relatively narrowband, we see that the drive varies so much across people
- How we see that is also a factor of what the person has been through
  - Has a person been taught and told that their generative drive was worth something?
  - Did their parents delight in things that were of interest to them?
  - Did they feel nurtured or did they feel denigrated?
  - Did they feel thought of as less than by the society around them for whatever reasons people do, whether it’s race, religion, gender identity, sexual orientation?
- There are things that push people towards feeling less than, feeling less capable, or feeling that the good things in the world aren’t out there for them
- One aspect is genetic, that we probably inherit a whole set of factors that we don’t understand that lead with a predisposition
  - Someone may be relatively satisfied with a level of life that might make someone else bored and needing something very, very different
- We have a whole bunch of factors that feed back to the natural genetics and impact where you are at any point in time
  - Our life experience probably affect that through psychological factors, epigenetic factors, even factors of inflammation running around in us and how that makes us feel physically based upon what’s going on in us emotionally
- This is why we can intervene and we can help people to feel more of a generative drive
- If a person feels disillusioned and disheartened, maybe there’s some desire to do something different or better
  - They may feel, “*But why? It’s not going to happen anyway, or I’ll end up feeling disappointed and worse afterwards.*”

***Can we help people be in the world in a way that better honors what’s inside of them and tells them they can understand and harness and change their lives in ways that bring them greater happiness?***

- We all have a generative drive and it varies a lot among humans, but if we take a step back and look, we’re probably selected to be within a relatively narrow range
  - Though as we look closer, that range seems wider
- What we can do is help ourselves to optimize whatever the range of genetic drive is within us because it’s not set at a certain place
- Through things like giving people opportunity or encouragement when there was none before, helping people with their mental health or their physical health, helping people with basic needs, basic needs of encouragement
  - That often doesn’t happen in our education systems

***If we can help people be at the best place they can be, that’s the leader of all else***

- If we help the generative drive be as best it can be, where we want to be in the world, and we want to see and understand and create
  - Whatever that may be, whether it’s a garden or it’s a company or it’s a cure for cancer

***If we help ourselves to live as best we can [with the best generative drive], then the rest of the aspects of our health will follow***

- Paul doesn’t know anyone with a really strong generative drive who’s engaged in the world who isn’t also interested in taking care of themselves
  - This comes along with feeling that we can be the best we can be in the world around us

## A deeper dive into generative drive: impact on human behavior, resilience, purpose, and more [23:15]

**What about the person who is striving so much, successful by every metric, but they’re not actually taking care of themselves?**

- Peter is thinking about a person running 3 companies, but they’re not actually taking care of themselves
  - They’re working so hard that they’re not taking care of themselves

Peter asks, “*Have I misunderstood generative drive and I’m now talking about a pathologic state or a state that is harmful?*”

***Achievement is not the measure of the generative drive***

- There are people who are phenomenally successful in the eyes of the outside world and running three companies and they feel great about what they’re doing
  - They have great relationships with people around them
  - They’re thinking as they’re doing
  - They’re taking pride in moving forward businesses or ideas in ways that wouldn’t be happening without them
  - There’s an engagement in life and they feel productive
  - They feel worthwhile
  - They wake up with a good feeling
- There are also people who look the same from the outside and are driven by shame or fear or previous deprivation that there can never be enough so that what you have can’t be taken away from you
  - There are people who are laboring under those **fears** (often from early childhood experiences)
  - From the outside they look very, very productive and successful, but on the inside, things are very thread bare or they’re filled with fear
- Whereas you can see a person who from the outside world is not doing very much or coming and going from a routine job, but they’re growing a beautiful garden in their backyard and they are filled with a generative drive and they are happy

***What we see from the outside tells us something, but it’s just data like any other data. Data outside of context is not a value, and in fact becomes misleading.***

**Why some people who are very successful are not happy**

- Paul sees this at times in people who are very successful, who don’t understand why they are not happy because they are very successful
- What really is going on, they may have a very strong assertion or aggression drive because they’re running away from something
  - Their own fears about themselves or shame or prior poverty or whatever it may be
  - That drive is very, very strong

***Their enjoyment, their ability to take pleasure in all of it is very, very low, and then the generative drive inside of them is at a much lower level than it seems to be from the outside***

- Peter responds, “*That’s very helpful. And it actually, I think, probably answers part of my next question.*”

**Do you believe that everyone is (at least from a “nature” perspective) born with the capacity for enough generative drive to be happy later in life?**

- Yes
- We are selected for high levels of generative drive because it is adaptive
  - In hunter-gatherer days a person would say, “*The food is a little bit sparse. There’s a mountain over there. We don’t know what’s on the other side of it. Maybe we should check. Or maybe we should do things differently so that we’re better prepared for what may come next.*”
- The generative drive and the enthusiasm and the joy inside people when that is being realized pulls humanity forward
- [Leon Trotsky](https://en.wikipedia.org/wiki/Leon_Trotsky) said that the locomotive of history is war, and Paul would beg to differ
- Paul thinks war and aggression is driven by human envy and destructive capacity *not* the locomotive of history
  - It pushes history backwards

***What is actually the locomotive of his history is the generative drive within us as human beings and our ability to realize it***

- This is why people learn and create
- Imagine [Mendeleev](https://en.wikipedia.org/wiki/Dmitri_Mendeleev) in front of the periodic table and the joy of seeing a pattern and figuring it all out [putting together the periodic table of elements]
- There is a joy in creation, whether it’s watching a child or they can be watching something grow or discovering something
  - This is the locomotive of history, but we pay so little attention to it inside of us
    - [We focus on] idea of valuing ourselves by what we see from the outside by things that we feel bring us prestige,[even though] we know that that doesn’t make happiness

**We’ve gotten lost and a little bit away from what our core humanity is telling us: we want to be interested in things around us and delighted by new knowledge and new experience**

- When people carry this through the lifespan, these are people who are happy and who are taking care of themselves and who age well and who don’t fear death

*Another part of it is when people are living through the generative drive, they’re taking care of themselves in mind and body and emotion*

- They find they’re not afraid of death
  - It’s not that people want to die, but they want to stay alive because they’re healthy and happy
- There’s a difference between that kind of enthusiasm and fear
- We should look very closely at who are people who are not fearing death (that’s remarkable)
  - We see that they are often in very good balance
  - The generative drive is being honored and the assertion within them and the ability to feel pleasure and satisfaction, these are all well-balanced, and then they’re in places where they can find some peacefulness and some reflective capacity and some ability to feel contentment and delight in the world around them

## Evaluating one’s inner self: introspection, self-awareness, challenging societal norms, and returning to the basics of physical and emotional well-being [29:00]

**How can a person begin an examination of their inner self?**

- You can have an individual who looks like they are doing remarkably well by any metric, and it could come from this generative place or it could be fueled by fear/ anger/ insecurity
  - [The driver] can be indistinguishable

*If an individual listening says, “Hey, how can I take this first diagnostic step and evaluate my own drive?” What would you say to them?*

- The 1st thing to do is look inside yourself
  - How do you feel?
- Paul talks a lot about life narrative

*There are ways of taking stock of what is going on inside of you*

- A person could just start writing
- You can start talking with someone
- You can start introspecting
  - Am I being kind to myself?
  - What’s the voice inside of me saying to me?
  - Do I feel good about any of this?
  - Is any of this what I want?
- Peter responds, “*That’s not an easy question to necessarily answer. I want to dig into this because it can be very difficult to answer that at a deep level because sometimes the superficial answer is so obvious*.”
  - If you have everything (material success), your knee-jerk answer would be, “*Of course this is what I want.*”

**How do you go deeper into that question, looking inside oneself?**

- Use more specific tools
- What do you say to yourself when you’re alone?
- Is there something that you say to yourself over and over?
- If you make a mistake, what do you say to yourself then?
- Is there an urge in you to be helpful to other people when you see them around you?
  - If someone stumbles in front of you, do you feel like you want to move forward to help that person?
- These are the ways in
  - These are the ways to give us answers about how we feel about ourselves

**Paul’s clinical experience with people on the opposite ends of the socioeconomic spectrum as it relates to happiness**

- There was a period of time 7-8 years ago, where he would, for some period (a week or so) see people who had very, very high levels of success
  - Who from the outside looked as if they must be happy
- When he would stop doing that, he came back and he would do clinical work on a unit that takes care of people who don’t have insurance
  - Many of whom are indigent, who have drug and alcohol problems (not all)

***When he compared people on the opposite ends of the socioeconomic spectrum, he could find no difference in overall happiness between the 2 groups***

- Someone who looked to have it all would feel, “*If I don’t have that next achievement, it all goes away*.”
  - The person is owning what they have earned for themselves
  - The person may have made a lot of money and now they don’t have to worry about being in need
  - Or they may have achieved at their chosen art form, but they’re so afraid that if the next thing doesn’t go right, it’ll all be taken away or they’ll feel ashamed of themselves
  - This goes on a lot in people who are high achieving
    - It’s like, “*What have I done for myself lately? If I haven’t done something good enough, I can’t feel good enough about myself*.”
- Whereas people who from the outside literally had nothing would be saying, “*When I get out of here, I’m going to do it differently. I’m going to do it better.*”
  - I’m going to go see this person I really miss who is helpful to me
  - I’m going to get a job
  - I’m going to keep myself away from what got me in here in the first place
  - They might have an enjoyable story or memory
- Paul remembers at one point meeting someone who was living behind a bush under bad conditions, who was far, far happier than the vast majority of people he had seen over the previous several days

***The truth is, we are often running from something or trying to achieve something that makes us feel safe in the world and all of a sudden better about ourselves***

> “*What we really need to do is honor that we are human and what is going on inside of us is so important.*”‒ Paul Conti

**If we are willing to look at that, we’re willing to ask the questions**

- What do I say to myself?
- How do I feel about myself versus other people?
- Do I feel like a fraud?
- Am I afraid everything will be taken away from me?
- Every time I drop something, do I say, “*What an idiot*,” inside of myself?
- What is going on inside of me?
- Do I feel like I have an openness of spirit to new things or people who are different from me?

***We can ask ourselves these questions, but we have to stop feeling that what we adorn ourselves with is what brings us happiness***

- Then we can get to this owning what is ours
- That person who is going to try and put a roof over their head when they leave can own what’s theirs
  - Which is the tenacity to have what survived behind the bush
    - Survived and lived in that way and maintained a good spirit
- Often, these are people who are helpful to other people and are looking out for people around them
- That is something to feel so good about as you strive for what comes next
- Just as someone who has worked and learned and studied could feel good about the achievements they have, or someone who goes to a difficult job that doesn’t provide them with satisfaction, that they feel is backbreaking labor, and underpaid
  - They go and do that, and they take home a salary that supports a family and puts a roof over people’s heads
    - Feel proud of that

**When we don’t feel good about ourselves, often we are out of kilter with the generative drive within us**

- That is absolutely a part of what makes people unhappy
- Coming along with that is not owning what is ours
- Many people who’ve raised families, done things that are so impressive from the outside have told Paul over the years that, “*Oh, they’re not worth anything. They didn’t make enough money. They didn’t do this, they didn’t do that*. *It’s not what matters*.”

***It is being the best that we can be and honoring the drive inside of us to live and to create***

**How would you make the case that it’s not a zero sum game?**

- Somebody listening might understand what Paul is saying but there’s no way he would choose [option 1]
  - 1 – To live behind a bush with nothing but have some sort of happiness
  - 2 – Verses to be incredibly successful in the eyes of society, to have all the comforts that come with success, but to be unhappy
- Someone listening to us might not be able to even wrap their head around what Paul is saying because they might be right somewhere in the middle [of these 2 options]

***If you’re in the middle, Paul advises to get to know people in both categories***

- He knows what option he would choose, “*I would absolutely choose that person who doesn’t have any material possessions… the selfish choice is to choose that person.*”
- He doesn’t want to be the person in option 2 because that’s not happy
  - Paul sees where dissatisfaction leads and he doesn’t want that
  - He’s much rather have the spirit that makes him feel like he can do something, make some change
- We all need the basic minimum in order to have some safety and satisfaction
  - A roof over our head, enough to eat
  - Oftentimes, if you give a person a little bit of help, they can go off and do that
- If Paul were that person [#2] getting some help so that maybe now he can move his life forward, he would feel an enthusiasm about that
  - Feel that he can make things better
  - Feel that he can have the minimum that he needs
- From there he asks, “*What is it that I choose to build?*”

***When we look at measures of satisfaction, societies (even today) who are by and large hunter-gatherer societies or the societies that we from the outside think have nothing are often happier than we are***

- There is your proof
- We have plenty and we can look after people better
- We live in a society that runs ahead so quickly that we’re always trampling people along the way
  - 1 – It’s just not right to do
  - 2 – Any of us can be in that group of people who has something really difficult happen to them and gets to a place where we need a helping hand up
    - Any of us could be that person, or someone we love could be that person
  - Even if that weren’t the case, it’s just not right
  - It’s not even economically efficient

***Help people to be productive members of society. That’s important economically, and beyond economics, it is the human part that matters.***

- We can do more for people to give them an opportunity to make a life for themselves that can feel productive and contain happiness within it
- If we do this, we give all of us an opportunity to have the generative drive within us realized
- Someone who’s very interested in academic learning and success may think, “*I like when I get an accolade. I like when I learn something.*”
  - Then maybe they go off and they start building businesses and they feel great about that
  - That is wonderful if that’s what that person feels good about
- There are also people who live good productive lives, and they’re good neighbors to the people around them, and they take care of children if they’ve chosen to be responsible for children
  - These people shouldn’t feel any less good about themselves

***The irony in the world is that often both groups of people are not feeling good about themselves: they’re not earning what is theirs***

- The person who went off and studied and created and can’t feel good about the wealth they generated that now may be good for people around them
- Or the people who struggled and worked and made good lives for themselves don’t feel that they have enough

> “*I see this is coming along with this idea about aging that we should feel so bad about getting old, and we should feel so bad about whatever we can identify in ourselves that isn’t what we think it should be if we look from the outside*.”‒ Paul Conti

**There is a real simplicity in just sitting with ourselves and introspecting, or sitting with someone that we’re talking to, or writing with a pen, or being in a therapy room of, let me think about me**

- Because the truth is, all of us are so different as to be really and truly unique
- If we take ourselves out of how we try and tether ourselves to all the shoulds around us and instead talk about your life
  - Talk about what your experience of life has been
    - Your experience of being in the world and trying to have some healthy control over a world that’s difficult to control
- It’s those discussions that lead people to interesting decisions
  - Sometimes the decision is to leave a very high paying job for a lower paying job, but then the depression goes away
    - Or the substance use goes away
- It’s a decision to strive for more that leads a person ultimately to achieve external measures of success
  - We don’t know what that is
- If we start thinking about it and talking about it, we also go back to the basics of how are you taking care of your body?
  - It’s going to be very difficult to feel good if one is not taking care of the basics of their physical function
- We get down to the first principles, physical health, the things that contribute to lifespan, health-span, cognitive health and emotional health
- We have to go back to the first principles of who are you and let’s talk about your story

***Because that understanding is what leads to the next decisions and the next decisions are not obvious from where we stand now***

## Self-auditing tools: introspection, curiosity, and exploring underlying reasons for unwanted behaviors [41:45]

- Peter is thinking about this as a self-audit tool
- If a person ostensibly recognizes that they are not taking care of their physical health, they’re drinking too much, smoking, using substances in an unhealthy way, eating too much, not exercising, all of these things
  - That’s a generally pretty easy thing to recognize

**If a person can recognize objectively that those things are true, what is the positive predictive value (PPV) of that sign that says there is something unhealthy going on in themself emotionally?**

*How likely is it to then be predictive of the fact that you’re emotionally unhealthy?*

- Very high
- That has very high predictive value
- Think about the link between the 2
  - It doesn’t feel good to get up every day and *not* feel good
  - It doesn’t feel good to know that one is unhealthy and energy levels are low
  - It doesn’t feel good to look at oneself in the mirror and say, I could, would, should be healthy
  - Or to not be able to keep up with one’s kids
  - Or whatever it is that goes on inside of us that makes us know that
- If that’s going on, something isn’t aligned well within us

**What is the reason for that?**

- I have to work to do this, this and this, so I don’t have time to take care of myself
  - Or I’ve got to be in this job I hate
  - I’m so stressed

***We have all these reasons, but they aren’t good reasons***

> “*Our bodies and our minds are what we have. The idea that we can just push that aside and not pay attention to it can’t be right*.”‒ Paul Conti

**The key is the curiosity to link the 2**

- There’s a high positive predictive value that there is something emotionally out of balance (or something in the mental health realm)
- Whether or not good comes of that is the link of curiosity

**To not pay attention to what’s going on in our mind is such a common phenotype, and Peter includes himself in this category**

- For Peter, it’s overindulging in food
  - Even when he says to himself, “*You don’t need to be eating this extra helping of dessert or whatever*.”
  - Peter talks about emotionally eating with his wife all the time

Peter asks, “*How do I think about that in a way to not overanalyze this or over-interpret it? How do you decide if my overeating is actually a canary in the coal mine that says, hey, there’s something going on inside of you emotionally?*”

- Peter wants to be careful not to demonize everything, but at the same time, he wants to be able to use this as signs
- Peter is coming back to this idea of when it comes to [mental health], we don’t have biomarkers
  - We don’t have scans that give us answers, blood tests, tests that you can do with objective measurements
- Peter is searching for other ways to gain an insight into, “*How do I at least start asking questions to get myself help?*”
- In this scenario where emotional eating is the subject of conversation, then we know something is there
- A lot of times a place to start is are we over-managing ourselves?

***Every now and then, a little bit of indulgence is okay ‒ let’s make sure that it’s not that, that we’re criticizing***

- Let’s make sure that we’re actually recognizing something that we don’t need a biomarker for
  - Which is, when I am very stressed, I am eating in ways I don’t want to be and it soothes me a little bit at the moment, then I feel worse about it and I got to go do something to make up for it
  - That’s not good
  - That is face validity

***What we can do and often do is just simply perpetuate that to recognize that and it goes no further***

- If we continue to do it, as opposed to saying, “*Whoa, this is the place for curiosity*.”
- What is different about the feeling inside of you: if you eat because you’re hungry or you eat because you’re stressed?
  - Can you recognize that difference?
  - Maybe you can, if you’re paying attention to it (A lot of people can)
  - If not, what’s the context around?

- Paul explains, “*You can have an idea of what’s going on inside of you, and then it fits into this human thing that we do, which is short-term gratification at the expense of something that in the long-term, is negative.*”

**Addiction mechanisms**

- This is why when Paul and Peter were back in medical school, people were not very interested in studying addiction
- The thought was that addiction was separate from other mental health things, and it was people who were doing something they shouldn’t and then weren’t able to stop
- Paul though it was a very denigrating and disinterested approach

*What the field has come to recognize is that these addiction mechanisms, it’s going on in all of us all the time*

- The short-term soothing of a little bit of food that isn’t healthy for you at the expense of you feeling badly about yourself in the longer term is part of that same cycle
- It’s the same brain machinery that is getting harnessed so that we over prioritize the short term at the expense of the long term while looking away from the fact that we are doing that
- If we become curious, why is it, what crests inside of you that you, a person who’s very good at looking at the long-term and foregoing immediate gratification and all of that would say, “*I’m going to soothe this right now with food?*”
  - If we look at that, the thought would be we’ve got to be able to do something about that
  - You’ve done much harder things than to realize, oh, there’s an emotion inside of me
    - Like, wait, let me go look. What is that?
    - What is that emotion?
    - Where is it coming from?
- Maybe you can’t stop the emotion in the moment, but it might tell you, “*Hey, this thing in my life should be a little bit different. Or it might say, I crest like this with relative frequency.*”
  - Is this okay?
  - Can I take care of myself?
- Sometimes it’s harder answers: a person should do less
  - The answer isn’t keep doing everything that you’re doing and don’t have these emotions that crest in certain ways
  - The answer might be, why are you doing all the things that you’re doing?
- Paul is not saying this is the case for you, but we need to look at all of this

***What is going on inside of me that something is cresting and all of a sudden, I prioritize the short term and I don’t look at that?***

**This can be the beginning of 30 sessions of weekly therapy with a person, talking about this paradigm within us of**

- How are we doing this for all sorts of things in life?
- What might be rationalizing about our choices, personal and professional?
- How are we taking care of ourselves?
- What’s the climate inside of us?
- Because when a person seems to be taking care of themselves from the outside (and maybe is, you can see from the outside), but they’re so frustrated on the inside
  - Or they’re so afraid
  - Or they’re so overly managing themselves to make up for something
  - Then we don’t necessarily see that, that keeps them healthy
- [Analogy] there may be a higher inflammatory state that increases risk of cardiovascular disease or autoimmune phenomena
  - We know this happens

***We have to be curious about ourselves; it is amazing what we hide from ourselves***

- We go through life hiding so much of what is going on inside of us from ourselves in the service of maintaining some direction we’ve decided was important
  - I’ve got to go do that, or I’ve got to go achieve that
- Then we put these blinders on ourselves and we don’t look
  - Does this make sense for me?
  - Am I being the best person that I can be?
  - What’s the whole set of priorities in my life, personal and professional, self-care about other people that you care about, about achievement?
  - Am I balancing all of this right?

***It’s remarkable how little we inquire of ourselves about our own unhappiness or markers of our own unhappiness***

- Even excessive emotional eating
  - It may not be the determinant of absolute misery for a person, but there’s something going on there that’s not happy that’s not in alignment with oneself

## Breaking free from destructive cycles by understanding the continuum of self-care and addictive behaviors and remaining curious [50:15]

**There’s a continuum of how people take care of themselves and manage addictive mechanisms**

- 1 – There are people, who from the outside, it’s obvious that they’re not taking care of themselves
  - There are many patterns
    - Not sleeping well
    - Not exercising
    - Not eating well
    - Drinking to excess
  - In those situations, it becomes pretty obvious to someone on the outside that there’s something going on here
    - That you’re acting in a manner that is harmful to yourself
    - We should explore why
- 2 – Then you have the intermittent example, and Peter uses himself as an example
  - For the most part, you’re taking reasonable care of yourself
  - Then you really have these breakout moments where you’re soothing something, some stress with a maladaptive behavior
- 3 – There are a lot of people living with over management and the idea that you’re going to be perfect
  - By any objective measure, you’re going to have it perfectly dialed in with respect to your health
    - You’re going to eat like a robot, exercise like a robot, sleep like a robot, etc.
  - This one is probably a harder one to get people to look inside and see

**If you were talking to somebody like that [#3], how would you help them come to realize that while on the surface that looks really good and it looks like they’re doing everything so well (that they clearly must be doing this from a place of health), how would you challenge their thinking on that?**

- One route of approach is the old [Freudian](https://en.wikipedia.org/wiki/Sigmund_Freud) way of seeing this: they thought of this as what they thought of as **living in the ego**
  - Which is no less valid just because it’s old
  - The old Freudians didn’t get everything right, but boy, they really got some things right
  - It wasn’t the modern idea of ego
    - It’s like, that’s a person at their best, at their most self-aware
  - It’s not easy to live in the ego
    - We have to think about ourselves in order to be self-aware, to be aware that we’re not aware of everything
  - It’s this idea that as best I can, I understand myself and what’s going on inside of me and what my hopes and fears are and what I want and what I have achieved and what I’m afraid of
  - Then we can healthily control our lives
- We’re keeping two other aspects of ourselves in balance than what they thought of as the “[Id](https://en.wikipedia.org/wiki/Sigmund_Freud#Id,_ego,_and_super-ego)” was the desire for immediate gratification
  - I feel bad now. Where’s the food?
  - There’s that part of us, “*I want what I want and I want it now*.”
- There’s that part of us on one side and the other side is what they call the [superego](https://en.wikipedia.org/wiki/Id,_ego_and_superego#Superego)
  - The part that manages us that says, “*You want what you want when you want now, but that’s not okay. Keep yourself in check.*”
- There are these parts of us that manage us and that want indulgence

***That it’s us, the whole us in the middle that has to recognize all that and keep it all in balance***

**What we see is that the part they call the superego, (the self-management) often gains supremacy over the others, and that’s not good**

- That’s how we internalize the persecutor
- Parallel to this, this is a true story where someone who Paul hasn’t seen before who is in his office and he’s getting to know them
  - They’re telling him about being persecuted by someone who says, “Y*ou can’t do anything and you’re not worth anything.*”
  - Think about where this person is living, and how can we get them out of there?
  - Then Paul learns that the other person has been dead for 7 years, but the person took into themselves the persecutor, the you’re not good enough
- That can come from outside of us, and that’s very striking when it comes from outside of us
- It can also come inside of us
  - There’s probably some external modeling
  - It can come inside of us where I decide the way I’m going to be good enough is I’m going to berate myself and torment myself until I’m perfect

> “*Perfect isn’t just the enemy of good enough, perfect is really the enemy of everything that’s not misery*.”‒ Paul Conti

- No one is perfect
- Nothing is perfect
- When we’re **over-managing ourselves**, that’s what we’re telling ourselves
- This superego part of us (if we want to call it that) is always looking at us
  - What are you doing wrong?
  - What’s not right?
  - What’s not good enough?
  - That becomes a very harsh, critical voice
  - Often, we don’t know that, that’s inside of us

**Paul tells the story at times of a person who was very underachieving, given this person’s level of intelligence and other things that they had done**

- They were so below in role performance of what one might have expected
- Paul asks questions and is trying to understand
- Then he realized this person loved music, and he asked, “*What music are you listening to?*”
  - He learned the person was taking these long drives to go to some awful job that they didn’t have to have, and they weren’t listening to music in the car
  - Now we have a clue why this person is a music aficionado
    - Because without the music, the person could on all that long drive to the job and all the drive back, tell them what garbage they were (what a loser they were)
- This was going on the whole time, the person was going to a farther away job than they could have gone to have more time to criticize and berate themselves
- It’s an extreme circumstance, but it’s not that uncommon that he sees things like this

***That person needed to stop that search for perfectionism through self-criticism***

- When you explore that, the person wasn’t aware that they were being sadistic to themselves

**Those voices inside of us are very powerful**

- This is how you’re keeping yourself down
- Paul has given a couple of really strong examples, but they’re not outliers
- These are examples to elucidate what very often is going on inside of us where we are trying to manage ourselves, whether we’re being **perfectionist** about it or we are **afraid** or we are **ashamed** in ways that are very, very harmful to us

Paul explains, **“*****That kind of self-talk destroys motivation, destroys confidence, increases levels of inflammatory markers, increases risk of illness. There’s so much bad that comes of that, but that’s inside of a lot of us.*****”**

**If a person stops now and thinks, “*****Is that inside of me?*****”**

- It’s remarkable how many people stop and think
  - [For example,] in the shower in the morning telling yourself all the thing you better not mess up today
    - Or what you did wrong yesterday
- Patients tell Paul so much

Peter asks, “*Did you have to prime this particular individual to get them to recognize consciously what they were doing?*”

- Sure
- They had been talking for a while, and clearly, the person wasn’t aware of it
- Through a process of inquiry, they had to stumble across something that didn’t make sense
  - Paul learned this person loves music
    - They listen to music when they’re home and they have this really long drive
  - Then he learned they’re *not* listening to music, and he became curious about that
    - Was there another reason? Did they like looking out the window?
- Paul pointed out to them that they’re taking a longer drive and not doing something they enjoyed in order to punish themself

**Paul’s struggle with a critical inner voice**

- Through Paul’s own therapy he began realizing that there’s such a negative critical voice all the time, and it wasn’t needed to help him move forward with life
  - Trying to control things around him and feeling afraid of not being successful or not being good enough leads him to start managing himself pretty closely
- But then Paul stopped managing himself when he was in high school
  - He could do 3 sports over the course of the year and still maintain academics
    - That was good to learn how to do that and balance fun and work
- But then it gets to be too much of a good thing, and now he’s going to manage himself by being critical and telling himself all the things [that] could go wrong
  - Making sure that nothing is any less than perfect (which of course it is)
  - And now he feels worse about himself
- That in him (like in many people), was why he could look successful from the outside, but for a long, long time was really not happy and was depressed and ashamed of things
  - And feeling in ways he had to then through his own work get out of himself

**Experiences like this have helped Paul have insights**

- One doesn’t need to go through something to know that others are
- Having been through a lot of that, Paul has learned that ***what you see on the outside doesn’t tell you at all what’s going on on the inside***
  - Like seeing a beautiful home doesn’t tell you what’s going on the inside of it
    - Who are the people?
    - How are they behaving?
    - Are they healthy?
  - It’s not that it’s irrelevant there’s a beautiful home on the outside, but it’s also not irrelevant if let’s say there is a home that doesn’t look so good on the outside
    - There could be so much beauty inside of it and so much happiness inside of it, and we know those things are true
- Paul and Peter have both been around life enough to know that those things are true, so let’s bring that to the forefront

***Let’s look inside of us with the same curiosity and not having to hide from ourselves what we might find there***

## Critical self talk: the malleability of one’s inner dialogue and the potential for transformative change with perseverance and self-compassion [1:00:15]

**Peter wrote in his** [**book**](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.C2hgMckAFDA_vImELekFZXv42gm3e5yZwOVrYDOggEQPnB-0MJD179kN9LgnXOsQ-B4fKurPREA5YpaJiCAfbvjOiFAeeTThG6YgSt5QRI_qlrxDCRap9IIK8zSVcS8WPoj-eBfRgd2BbYWojBJrWHvN2csTmmvh7xnDbQMKdVLeE1zXd6gnCt8N9ir99Rv0bFq965QkmPMVE0cShZFWmOAqcrLdgQOWhKTpKrKUDwU.3Qb0leUEWM92K0xvK3liUnVEYEoM7PQV7dW0RD8zbkc&qid=1710176636&sr=8-1) **a little about the discovery of his inner voice**

- Many of us have an inner monologue
- But it was so startling in terms of how aggressive his “[Bobby Knight](https://en.wikipedia.org/wiki/Bob_Knight)” voice was
- He had a breakthrough one day at [PCS](https://pcsintensive.com/) where all of that came out

***It’s a little sad to realize that 47 years of his life went by (probably 45 of them) with that voice, and yet no recognition of it***

- Peter explains, “*Why that is frightening to me, is it tells me there have to be a lot of other people out there with potentially as awful a voice in their head. They might be listening to us now thinking, yeah, that would be awful. And yet they have it and they don’t recognize it.*”
- Paul agrees and adds that you don’t want to give this a pass
- If your experience of it normalizes it
- I you have an emotional investment on some level that this voice is causing you to behave and achieve in ways that let you feel good enough about yourself
  - Even then you don’t feel good enough about yourself and you’re really afraid of feeling worse, then it gains almost a buy
- We don’t go and look at that, it just gets a pass
  - That happens all the time, it’s so automatic within us
- Just as there are people who around 20 years of age can have schizophrenia that they didn’t have before (they’re hearing voices inside of them), and it’s years later that they realize that’s not normal
  - Even something we would think of that’s so different than what most people are experiencing, but it’s not different from what you are experiencing if you are experiencing it
  - And it has come about in a way that didn’t have a marker that told us that it was not healthy

**There’s a common theme to what we’re talking about, which is introspection**

- Curiosity about things going on inside yourself that are wildly unhelpful to what you are trying to achieve
  - Like better healthspan and lifespan, or better emotional health
- They’re just going on on the surface
  - They’re hiding
  - There they are waving a flag and you’re not paying any attention to it
- It is curiosity about ourselves that makes all the difference
  - How do I work?
  - What is going on inside of me?

***When we start thinking about that, we become aware of it, that’s when we can change***

**Paul remembers that Peter described feeling all this all at once, and that’s how change happens in people**

- There’s a great [Hemingway](https://en.wikipedia.org/wiki/Ernest_Hemingway) quote, which Peter is paraphrasing incorrectly: change happens incredibly slowly, and then very quickly
- Paul agrees
- If you think about [quantal leaps](https://en.wikipedia.org/wiki/Quantum_jump), like an [asymptotic function](https://en.wikipedia.org/wiki/Asymptote) in math
  - What we’re getting at is discontinuity
  - This is true on all levels down from quantum physics through to astrophysics, you see that we are only here because we are in these eddy pools of counter entropy
    - Where instead of everything dividing and dispersing like it does in the vast majority of the universe, there are these places where certain forces go the other way
    - Now there’s not things coming apart, but coming together
- Whether we’re looking at the biggest levels or we’re looking at the smallest levels, the way that things work inside of us is that there are processes of understanding and change that are rare (or infrequent), but we can bring to the surface by looking in the right place
- If you look all over the universe, most of what you see is no life
- But if you look in the right places where those forces of coming together are more than coming apart, then you see there’s something that’s happening there

***The same way inside of us if we’re looking where things are happening, then we can gain understandings that happen very, very quickly***

- Just as in mathematical functions or quantal leaps, these things are discontinuous
- When you have a curiosity about yourself that leads you to now do something where you’re thinking about yourself
  - You’re thinking about yourself with the help of other people outside of you, and you’ve engendered this across time
  - Now you go do something that’s intensive, then all of a sudden something becomes clear to you and you see, “*Oh, I’m now interested in this*.”
  - Now you start to do all the things that you do when you’re interested in things
    - Ask, why is this here?
    - How did this develop?
    - How is this serving me?
    - How might this be working against me?
- And now you can change, where before you couldn’t change it
- Yes, change happens slowly, but then it happens fast

> “*You do a lot of work on yourself to get to that point where the change can happen.*”‒ Paul Conti

- Maybe these are principles of existence
- Same with physical health
  - This person works out and works out, and you don’t immediately notice linear change
  - You have to have faith that the work you’re doing is going to get you there, and lo and behold it does
- That’s how these really big things inside of us happen to us, and it’s amazing that we often don’t know it
  - What am I saying to myself?
  - Is there a running narrative inside of myself?
  - Is someone else’s voice inside of me?
- Once you recognize it, it isn’t more likely that you’re going to choose the **short-term soothing**
  - Whether it’s Pringles or it’s a drug
- We’re more likely to choose short-term soothing because we’re afraid and we’re out of control, and we’re berating ourselves
- Paul suggests, “*Let’s just bring some peace and understanding to this equation and then things will change for the better… make change*.”

**Dropping a glass bottle today reminded Peter how much he has changed his inner voice**

- These things occur on a daily basis, so he gets a daily reminder of this (and it amazes him)
- He was shaving today and went to grab a brand new bottle of aftershave
  - This big glass bottle of Nieva aftershave (same thing he’s been using for 25 years)
- He went to grab the bottle and he opened it, and as he was dumping it in his hand, maybe because it’s so cold today, it was harder to get out
- Somehow the bottle dropped, and it landed on the floor
- It’s a glass bottle and it shattered, so now you’ve got glass and aftershave on the floor
  - This is the first time this has ever happened
- It’s moments like that he’s always paying attention to now, because there’s no one around for him to talk to
  - He’s not going to yell out loud or anything
- And the only thought he had was, “*Oh, let’s make sure you don’t step on the glass. Looks like there’s no glass over there, so let’s just walk over there. Do you have another bottle? Because you’re not going to want to reach down on the floor and mop some of that up because there’s probably glass in it. Okay, found another bottle. Away we go*.”
- Peter remembers thinking a minute later, “*Wow, what a different conversation that would’ve been 5 years ago.*”
  - That would’ve been a 3-minute internal lashing of, “*You incompetent non-attentive piece of shit. What? How could you possibly drop that?*”

***But again, the thing that he gravitates towards is the ability to start paying attention, to just listen to that voic***e

**Peter has talked a lot about the exercise that he used to do that, which was suggested by** [**Katy**](https://pacificpremiergroup.com/katy-powell-pmhnp-bc/)**, and by another therapist at** [**PCS**](https://pcsintensive.com/)**, which was the recording**

- Even if 1 person listening to this has not heard this story, Peter thinks it’s worth repeating
- He was instructed as he was leaving PCS to take his phone out every time he made a mistake or fell short by whatever metric, and to speak out loud audibly and record the way he would speak to his best friend if he had made the same mistake
- So if Peter’s best friend had just dropped the aftershave, he wouldn’t yell at him and call him a piece of shit
  - He would say, “*Are you okay? Those are really small pieces of glass there, let’s not step on them.*”
- And while that now is a very easy thing to do, it took months of recording those [to change his inner voice]
- Peter still has a number of these recordings (believe it or not), which he would then forward to Katy each time
- It’s amusing to note how strained they were at the beginning, as he had to learn a new language
- Now, it’s very natural

***Peter highlights that to say, that was a technique that worked for him, it was incredibly powerful, but most of all, the moral of that story is [your inner voice is] malleable***

- When this exercise was suggested to Peter, he did it because he was at rock bottom
  - And when you’re at rock bottom, you don’t really have a lot of negotiating power
  - You can’t say that’s a dumb idea because it’s like, how’s the current one working out for you?
- He didn’t actually expect it to work
- He thought, if this is ever going to work, it’s going to take 40 more years
  - Because that’s how much we’re overriding
- It took about 3 months to totally change

**How could it have happened so fast?**

- That’s 3 months of work
- It’s that same theory that matter is not evenly distributed, change does not happen in a linear way
- It’s only 3 months, but Peter had to run countercurrent to patterns of neurotransmission that were inside of him for years and years

**This is another big problem with modern mental health: it’s packaged to suit insurance paradigms**

- That’s not serving the people it’s supposed to serve
- The idea that whatever has gone on (there’s 10 sessions of therapy authorized), progress has to be gained in a short period of time
  - Let’s take an inventory of symptoms, and let’s throw a medicine at you so now your symptom is a little bit better without ever knowing what’s undergirding it

***There are things that take time, and when we establish patterns of neurotransmission, it takes time to establish them***

**An example Paul often gives**

- If you and I picked a random word and we said it 1,000 times, we’re going to be saying it later today
- If we say it 5,000 times, we’re each going to be saying it tomorrow and over the weekend
- Why? If we know that it’s just a silly experiment, why would it stay with us?

***Because we said it and the brain’s mechanisms are designed to hold onto it because we said it a lot of times ‒ the same is true with what we’re thinking***

- We’re just thinking what we think we put into words
- It’s the same, it’s thought, it’s neuronal connections that don’t want to go away because this is how we’ve developed

***We’ve developed to remember things and not forget things that are important***

- The brain says, “*You said that word 2,000 times, I’m not just going to forget it, because you said it.*”
  - It’s the evolutionary mechanism that’s been in your for a long, long time
- So when you start trying to say something nice
  - There’s got to be a fear in you that everything is going to fall apart
  - You’re doing this wild reckless thing which is going to take your edge away
    - Because the “Bobby Knight” produced great results
  - Next thing you know, you’re going to be lazy and slovenly and not care about anything
    - You’re not going to care when you make mistakes
- Think about how outrageous that is
  - But it’s *not* outrageous to the emotional part of your brain that didn’t want to stop it
- It takes bravery to stop it
  - You have to take a chance
- That part of you that says you’re going to fall apart, and you think you feel like a piece of shit now, wait until you stop doing this
- You have to say, “*No, I hear it and I’m doing something different.*”
- It’s a leap of faith in myself and in what you’ve thought about and learned about yourself
- Then you can go and do it, and you start running counter to those neuronal connections and then it changes
- But it takes time, it takes effort, it takes bravery, it takes faith in self
- So when Peter said, it only took 3-4 months, realize that he worked really, really hard at that

**We’re talking about 100 days or so of running agonist those patterns and making new patterns, and then it feels different**

- As someone who has known Peter for over a quarter-century and loves him, and is trained as a psychiatrist, and was there when Peter came out with the remains of the bottle
  - It was not lost on Paul that there was no edge in Peter and how that would have been [different] before
  - He thinks Peter is happier [now]

**Paul thinks about healthspan and lifespan as coming from the mental health side of things (psychiatry): it’s active brain function, emotional states within us**

- He knows Peter is healthier inside even without biomarkers a
- He could see and noted that change in Peter (not that long ago), and he knew Peter was happier and this is healthy for him

## Slowing the anger response and gaining insights into the underlying triggers to achieve lasting change and self-understanding [1:13:45]

**This area is still very difficult for Peter**

- He thinks he’s made maybe a 50% improvement
  - The magnitude is huge
- But given where’ he was starting, there’s still a long way to go
- Analogy: it’s like saying if a person loses 50 pounds, are they necessarily healthy?
  - It depends
  - If they went from 220-170, they almost assuredly are
  - If they went from 400-350, they probably still have work to go
- Peter thinks he’s probably the 400-350 guy, in this area
  - Which is just general outburst of anger at a situation that almost assuredly warrants anger
  - It’s something that happens to warrant anger, but the response is disproportionate to it, and it’s counterproductive
- The exercise here was an exercise suggested by [Andy White](https://www.pdbti.org/people/andrew-white/), who of course Paul very graciously introduced Peter to

**More about this exercise**

- This is an exercise Andy does with patients who are trying to quit smoking

***The exercise is about separating, creating a discontinuity between urge and behavior***

- Let’s say a person is smoking 2 packs a day
  - For the next month he’s not necessarily going to reduce the number of cigarettes you smoke, but what he will do is separate the urge from the behavior
- He tells patients, “*Every time you have the urge to smoke, I want you to pull out your phone and set an alarm for 40 minutes. Don’t smoke now, but when the alarm goes off, go smoke*.”
- The goal is to separate that so you’re not just feeding an urge every time it comes up, you’re going to go smoke
  - And sometimes you might not actually even feel it going for a smoke

*What this exercise was for Peter*

- The next time something happens that stimulates a response that is an **outburst of anger**
  - It could be he’s going to fire off a really nasty email to somebody
  - Or he’s going to call somebody and tear them apart
- He would instead **pause and set an alarm for an hour**, and then come back and respond in an hour
- That’s much easier to do over email than it is to do sometimes on an interpersonal level

***Not surprisingly, when he is able to do this (react, stop, come back, respond), it’s always better***

- To be clear, he’s probably only batting 500, meaning there’s a lot of times he’s failing to do this and just reacting to situations in ways that he almost always regrets (as opposed to responding to situations)

Peter asks, **“*****Why does this appear to be a harder exercise? And would you modify the exercise in any way to produce even greater efficacy, or am I just being impatient?*****”**

- He thinks this exercise might takes years as opposed to months
- Paul explains, “*Anger  is very, very powerful, and anger can propel us forward.*”
- [Analogy to think about anger:] sprinters coming out of the blocks
  - If they come out too fast, then they don’t have control and they’re just flying headlong until they fly face first
    - That can happen because they propel themselves out too strongly

***Anger does that inside of us, there’s this cascade from what technically is affect to feeling to emotion***

- It’s worth pointing out the difference that **affect** is aroused in us, meaning it’s created in us without choice
- When we have high levels of **emotional response**, some of it is nature, some of it is nurture
  - It’s cultivated over the years, and then these pathways are very strong
- So something is negative and there’s a high level of aroused, negative affect
  - Anger, in this case, and then that propels forward
- So when it comes in us, we don’t even know
  - The affect is aroused in us, we’re not even aware of it yet
  - It’s just a split second
- But when we’re aware of it, it has a whole head of steam and it runs through feeling when we relate it to self, and emotion when we relate it to others
  - I am angry. I’m an idiot.
  - We went from a lot of aroused anger right through affect to me, and now I’m mad at myself
  - Or if the target is someone else or something else that has happened to us, then we run right through us, there’s a lot of negative affect of anger raised
    - We burst right through us and now we’re like, and it’s your fault or it’s God’s fault, or it’s fate, or nothing ever happens right, or I’m cursed
    - Now we relate it to the world around us
- Paul views this as the equivalent of the sprinter being 25 meters from the start of the blocks sprawled face first on the track
  - It’s not good, and it leads us to unhealthy places

[**Andy White**](https://www.pdbti.org/people/andrew-white/) **and** [**Katy Powell**](https://pacificpremiergroup.com/katy-powell-pmhnp-bc/) **are fabulous therapists, and what they’re doing is they’re saying we’ve got to put a hand between the dominoes**

- Dominoes are going, this is running ahead
- We got to stop, slow that sprinter down coming out of the blocks so that person has healthy control over the movement of their body, they’re not just flying ahead
- What they’re doing there is they’re trying to slow that down and say ***affect does not have to run right to feeling when we relate it to self, and run right to emotion when we relate it to others***

**This is a lot of work when we slow that down**

- We do intensive programs with people, where people come to us and they spend a week with us or 2 weeks with us
  - A lot of the work is around things like this
    - People want to understand themselves better and they want things to change
  - We know these strategies work, and we know why they work
- There’s another aspect of this, which is the understanding of it (Pauls is most interested in this)
  - It then becomes interesting that you become very angry

**For example, I become very angry about a flight being delayed**

- I rush to get to the airport, the flight is delayed, I didn’t get the text I was supposed to get, and I become angry
- I am curious, why am I angry?
  - Oh, all my flights are always delayed ‒ none of this is true actually, right?
  - I see myself as a very fortunate person
  - I don’t feel that I’m cursed or that bad things only happen to me, or that people have it out for me
- But in the moment when something triggers anger, that’s not how I feel

**Strategies help you slow down, but what are you slowing down to?**

- Peter adds, “*The slowing down step is necessary but not sufficient for the real insight.*”
- It could be sufficient if sometimes just slowing down, it dissipates the energy, but we want more than that

***How about combining it with understanding?***

## Foster gratitude and humility by achieving balance between the three drives—assertion, pleasure, and generative [1:20:45]

**This brings Paul to what he believe works for everyone**

- This is a human thing, and it crosses cultures, race, religion, socioeconomic status
- We are humans and we have these drives within us
- There’s an **assertion drive** to be able to have some healthy control in the world, and there’s a **pleasure drive** to feel at least no privation and feel safety, and then also to have good things,  and there is also a **generative drive** in us
  - Are we honoring the generative drive?
  - Are we in balance?
- If we are doing that, what comes is a sense of gratitude and humility

***Paul’s idea of what’s going on inside of you when you’re able to stop is that you are able to take stock of self and be reflective to feel***

- You may or may not see and put words to it, but there’s a knowing inside of you that your assertion drive is like, “*You’re doing well with it. You’re putting yourself out there in the world, and I’ll take stock of myself. I’m not unhappy with how I’m trying to be in the world, and I do take some pleasure and satisfaction in what I do, and I am able to provide for people, and I feel a sense of wholeness and safety. And because of that, I can feel good about myself and I’m learning and curious.*”
- [When you stop,] you realize your life is great, and you feel a sense of gratitude because so much of that is a blessing
- There is also a sense of humility we have when we recognize our own work and effort, and we recognize our own responsibility for where we are, but we also recognize that it’s also a blessing to be able to bring ourselves to bear in that way
  - This is why people say, “*I got an award and it was so humbling*.”
    - They worked hard, did those things, and was acknowledged by people around them
    - They feel fortunate to be in a place where they can own that they worked hard and got something

***This pervades people when those other drives are in balance***

**How do people have a wonderful healthspan?**

- When the drives inside of them are in balance
- And you’ve got to look in yourself in order to get them in balance

***When they’re in balance, you orient yourself to that balance and you live much more in an appropriate and active sense of gratitude and humility, and you feel that when things are difficult***

- The work that you’ve done lets you feel a sense of humility
- You’re not supposed to be perfect despite all that you have achieved
- That’s why when Paul goes to the airport later today, if his flight is delayed and he’s going to sleep in the airport
  - That’s not going to feel great, but he’s *not* going to get down on himself or anything else around him
    - It’s not right, and it’s not good for him either

**Peter said he’s maybe 50% of the way there**

- That’s a huge achievement
- Once you start making progress, the  next 50% can’t be as difficult as the first
  - You’re going to get there

## The conflict between intellectual understanding and emotional feelings, problematic comparison frameworks, and the importance of living in the present with intentionality [1:24:15]

**When intellectual understanding and emotional feelings are at odds with each other**

- Peter and Paul talked a little bit about the following paradox over dinner last night
  - Peter is reading this book ([*The Worst Hard Time*](https://www.amazon.com/Worst-Hard-Time-Survived-American/dp/061834697X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.01gv1t59d_g1a_-V6IowQXYtxmpGbfMrjxGhkHZA5ARJE5Nc4eduTkSogYzzfBFPX34GyzAoqF5WWtylvvkbbr4EmpcLezXCeyJV0qvrDPLuLgWC8VSUvSj6jqDQumXZoLM02Xvek_bsvm6mzwRa072D_vUYgfvLmNOhWM0qtjdtG9Orr48EGb0TZskYWTSFcjXu40PRpiYt1nNRc_o7xYYRQfy58_uhsDr8yBYL8i4.7FN9C_gZEY-RSsUSK9sQPn1PJ1nG9dgVuGiRwBw0QCI&qid=1709752612&sr=1-1)) about the impacts of the [Dust Bowl](https://en.wikipedia.org/wiki/Dust_Bowl) and the depression (90 years ago), and the people living in the middle part of the United States were subjected to conditions that most of us couldn’t survive
    - The abject horror of what it meant to live in the depression in the Dust Bowl
  - The book is amazing
- You think about that and you think, “*God, that was only 90 years ago. What’s the luck that allowed me to be born now instead of then?*”
  - Had you been born 100 years earlier, you’d be dead (an awful death)
  - Intellectually, you recognize how lucky we are

***Then something happens that upsets him and it pales in comparison to what it would’ve been like to have been born 100 years ago***

- That creates tension internally because you think, “*Why can’t you just be grateful?*”
- In the airport example, why can’t you be grateful that you can at least get on a plane?

**How often is a person coming to you where that’s the source of the tension: the difference between the intellectual understanding of what should be gratitude and the emotional feeling that is incongruent with it?**

- A lot
- In this example, there’s a **fallacy** or a problem
  - Something is not real or healthy in the framing
- Paul does not believe that Peter would have died if he was in the Great Dust Bowl
  - He also doesn’t know that he wouldn’t been happier
  - Maybe he would’ve barely eked out enough food, got some shelter, kept his family going
    - Dirt poor, but alive
  - Or maybe not everyone stays alive, but he keeps alive who he can
    - And he has a sense of wholeness and goodness in himself despite the deprivation

***When we set up, “Oh, we should feel grateful, because,” then you set up a scenario where you can’t win, because anything you feel bad about, you should feel ashamed about feeling bad about***

- Because it’s not the Great Depression and the Great Dust Bowl, so what are you complaining about?
- You’ve inadvertently set up a situation where the odds are against you
- Up until a couple of generations ago, probably everyone in Paul’s family (from all sides, extending back generations) was a shepherd
- So you could now say, “*Wow, just look how fortunate I am. Look at the opportunities I have and the places that I’ve gone*.”
  - That can be a way of saying, “*This is so amazing*.”
- But this is not giving yourself room to say, “*Maybe I would’ve been happier being a shepherd. I don’t know.*”

***You are not someone else and you are also you now***

- A lot of people come to Paul with what Peter just said
- What Paul tries to do with all of them is to say, “*This is not a framing that we massage. I think it’s a framing that we just throw out.*”
- He knows nothing about a person by knowing their reflections on what they think it might be like if they are in the Great Depression

***What Paul know about a person, he knows from now, and this is when you live your life (now)***

- He explains, “*You’re entitled to be angry and frustrated about things sometimes*.”
  - Yes. You’re entitled to feel bad about things or annoyed about things at times
- Now, do you want to modulate that and keep it inside and not let it run out of the starting blocks?
- If we live them within ourselves and we are the marker of comparison ‒ that’s between you and you right now
  - How am I taking care of myself now?
  - How am I exercising the drives within me now?
  - How am I serving the generative drive within me?

***When we bring people back to that, that’s when things can really start to shift***

- Because you then maybe stop doing something that is going to do something and immediately you set the odds against yourself by having this comparison
- I’m not in the war, I know that, but that doesn’t mean that you can’t suffer now
  - It’s true and unrelated

***The other aspect, don’t be an isometric exercise, don’t push against yourself***

- And that’s often what we’re doing
- Often we’re doing that exercise within ourselves instead of simplifying

> “*The rule of all good mental health, which I believe undergirds health span, lifespan is simplicity*.”‒ Paul Conti

- It doesn’t mean that good mental health is simple to get to, but it is simplicity

***It’s really complicated to start comparing yourself to the theoretical you 90 years ago***

**Paul explains that he will stop and think about himself**

- He’s here now
- He knows his own history pretty well
- He is capable of introspecting
- Stop and think, “*What’s going on inside of me? Am I making a decision? Am I upset with myself or someone else?*”
  - I’ve got to be able to understand this well enough to simplify it
- If I’m going to beat up on myself and flog myself to get myself somewhere I want to go, that’s not how I’m choosing to do it (it’s not good)
- Paul asks, “*Is that why things seem to maybe take more energy out of me than they should?*”
  - Am I more easily frustrated?
  - Am I not getting enough sleep or not sleeping as well?
    - It’s harder to take care of yourself when you feel fatigued
    - There’s more inflammatory markers
    - Your body doesn’t feel as good
    - Now I’m even more frustrated with myself wondering, what is going on here?

***We can stop and take stock of things and decide a path forward where we are not working against ourselves and we simplify down to what the real truths are***

- Paul’s not saying that’s easy

***It takes work and it takes reflection, and we’ve got to run counter to some of these established neuronal pathways***

- But isn’t that a lot easier and a lot more likely to be effective if you’re living in the here and now with yourself, knowing what you know about yourself as you make decisions
  - Whether it’s what am I going to say to myself inside of my head?
  - What am I going to say to someone else?
  - What am I going to do?
  - Now we are intentional
  - Now, in that Freudian way, we’re living in the ego in that sense of the ego being the whole self at my most self-aware
- I don’t want the superego telling me I should feel bad about any frustration in me because I’m not a shepherd
  - It doesn’t help me
  - It makes things worse
  - It’s the opposite of simple
- We can reject having ourselves be out of balance
- Just like our drives need to be in balance because then the generative drive is what makes you wake up with a glimmer in your eye

**The need for balance**

- We have to be healthy in mind and body and these other drives, the assertion and the pleasure, have to serve it, the same way we have to be balanced inside of us
  - We need some gratification
  - We also need some self-control
- How about we have as clear a lens as we can sitting in the middle of it all?
  - Analogy: I don’t want fun house mirrors around me when I’m trying to see what’s going on
  - I want clarity around me
  - A lot of times what we don’t realize is we create fun house mirrors around us and then we get angry with ourselves that we don’t understand or that we walk in the wrong direction or that we run into something

*In this analogy (the fun house mirror), the mental construct that adds confusion is the example Peter gave [comparing his life now to what it might have been if he lived during the Dust Bowl]*

- Yeah, a fun house mirror comes into the room when you start comparing you now to the theoretical you during the Great Depression
- It’s a fun house mirror when I’m mad at myself because something wasn’t good enough and I realize that the standard I’m using is actually perfect

***If I start speaking to myself through the lens of someone who is so critical to myself, these are all the distractions away from clarity***

- And it is so easy; no one else brings the fun house mirrors in
- No one catapults ourselves out of the blocks so that we fall headlong

> “*It is we who do this to ourselves and we don’t have to do this.*”‒ Paul Conti

**Think about what humans do: we create so much and we destroy so much**

- Look at the destruction in the world around us
- How long it takes even to create one building that gets destroyed, let alone the vast swaths of the earth that we then destroy and the harm that we do to people
- Just as in the universe around us, there’s a lot more force towards entropy than there is to things coming together
  - That’s why these small places where life could be here
  - This is true in our lives here on earth
- It is so much easier to destroy than to create
- If we stop working against ourselves as humanity, we’re trying to move forward and create
- We do this as a species and we do this as individuals where we work against ourselves, and we don’t have to do this

*We don’t have to have needless destruction happen around us*

- We don’t have to have a society of plenty while there are single mothers with children on the streets
- There is more that we can do whether it’s trying to lift up the people who are on the verge of not surviving, who are living in misery
- We can also do it with ourselves

***Paul explains, “I don’t want to cloud my own picture. I don’t want to work against myself. And if I see with clarity and I don’t bring in the fun house mirrors, life goes a lot better and I use a lot less time and energy making it go better.” (it’s true within each one of us)***

## How making peace with our mortality can foster a sense of hope, purpose and well-being [1:34:45]

**How important do you think it is for our emotional health to have peace with non-existence?**

- Peter doesn’t have a great sense of that (many people don’t)
- We all will die at some point, and that knowledge is difficult to process

*Let’s talk about the best case example: you live a long healthy life and in your 90s, you die in your sleep*

- Let’s assume that everything up until that point is moving in the right direction
- You don’t just die in your sleep, you die in your sleep having lived a meaningful life and having had wonderful relationships and having raised children and grandchildren who are wonderful people
  - Let’s make this the best case scenario
- Yet many of us still struggle with the finite nature of our existence

*Do you think that coming to some acceptance of that is essential for our emotional health?*

- Paul does
- He’s not sure if it’s essential for everyone

***It’s very important, and there are many factors that work against us that we can change***

- This societal idea that getting old is just so awful and death is something to be feared
  - It’s not clear that that’s true
- When you see when people are much older and are closer to death, what they fear is loss of control, not death
- Maybe we build up a society that glorifies not being dead as opposed to glorifying living well
  - That would be a nice switch
- Maybe we think about health span and quality of life instead of living in a society where we’re so afraid of death that we just don’t want to die, and we’re not even paying attention to whether we’re happy or not

**We could work against that a lot, and we could work against these cognitive tricks (these things we do inside of us that torment ourselves)**

- I don’t want the voice of someone critical of me living in my head
- I also don’t want to be contemplating my non-existence, because what I do then is contemplate that I’m aware that I don’t exist and I’m upset about it
  - That’s not existing
  - If you don’t exist, you’re not contemplating it
- Peter thinks therein lies the greatest challenge, and he envies **people who believe in an afterlife**
  - If you believe in an afterlife, you have a way to get around that issue
  - If you don’t believe in an afterlife, then you’re stuck with that very bizarre idea that seems impossible to reconcile
- Paul wonders about that and has thoughts about that which are not fully formed
- He thinks a lot of times people ostensibly have faith but aren’t behaving that way because we are in a society where everyone is fearing death and non-existence
- Many of those people are people with professed religious values don’t really know what those things mean
  - Oftentimes we’re taught religious values when we’re young and we identify in a certain way
  - Ask: what do I actually think and feel?
    - When people do have a deep faith, it could be something different
    - But our religious values don’t really work against that very much
- Paul thinks it was [Spinoza](https://en.wikipedia.org/wiki/Baruch_Spinoza) whose **definition of faith** was the belief in something that you don’t know for sure
- When people say, “*This is my religious values. I know that’s true,*” Paul doesn’t think that’s faith
  - He doesn’t think our philosophical and psychological heritage tells us that
  - He thinks that’s a leap of something because we don’t actually know
- If you think you know and you don’t have enough understanding or humility to recognize that there is a leap of faith, then are you doing something that doesn’t actually help you?
  - Paul isn’t being anti-religious
  - He thinks faith is very, very important, but it’s recognized as, “*There is something I believe, but I do not know that thing. I believe it*.”
    - Why does the person believe it? (that’s very interesting)
- How do we see the beyond ourselves as opposed to just pasting something on that doesn’t actually make change?
- Paul worries about when people feel very, very sure of something
  - And also when people feel very, very sure that there’s nothing

**Paul finds it amazing that there are so many things that we know a little bit about that fills him with wonderment about what else might be there**

- It’s interesting to think about things that happen outside of time and space
- There’ve been experiments done where you or I could decide what happened in the past
  - Not figure out what happened, but decide
- So time, space, movement, the impact of consciousness upon the world around us, this is all so interesting
- Even things we learn about that are going on inside of our brains, the cutting edge of neurobiology and neuroimaging and some of the psychedelic studies and what they’ve shown going on inside of us tells me
- Paul explains, “*I don’t know what happens next*.”
  - I may have all sorts of thoughts one way or another
  - Maybe some of it comes from early education and some of it comes from the faith I was raised in, but I don’t know
- Paul find that not knowing to be very, very hopeful
  - I don’t know what comes next, it doesn’t mean that I’m going to rely on anything in particular, but it certainly means I’m not going to despair about nonexistence
  - I think that’s what Spinoza was writing about, and what great religious thinkers are writing within religions
    - Maybe that engenders a respectfulness
- If we knew that there was nothing afterwards, I would hope we could still find a way to be respectful of our lives

***But the fact that we don’t know what comes next is interesting; that’s full of interest and curiosity and hope***

**Things that happen outside of space and time are certainly not absolute**

- Paul explains, “*The generative drive in me gets activated when I think about dying.*”
- Our consciousness may actually change things
  - Be its own entity in the world around us
- We all have different times and do we have different dimensions?
- This is out there in the world around us
  - This isn’t pie in the sky
  - This is academic studies that are telling us these thing
- When Paul thinks about that and scratches the surface a little bit, he realizes that he doesn’t know the answer
  - That’s interesting and it helps him feel a sense of excitement about living the best life that he can live
  - Because if it’s all I have, then I want it to be good
- Paul adds, “*In taking care of myself, I’m better for other people. I feel invigorated by that and not afraid*.”

**You see that in people who don’t fear death**

- They’re happy with their life
- They’re leading life in a way that they can feel a sense of pride and they feel humble
- They feel gratitude; they’re rooted in that
- There’s often a sense of, “*I don’t know, and isn’t that okay?*”
  - Think about how many things we don’t know

*Paul summarizes*

- Can we take care of ourselves and treat every life as precious?
- This idea that there’s nothing special about any of us, but there’s something special about each one of us
- Not knowing what comes next and the idea that if we think there is something or isn’t
  - There’s faith involved and that’s a thought process
  - That’s a deciding on the part of the person
  - That comes through interest
- Then we stop fearing death and we stop living in this pseudo-cult of, “*I must not die,*” which is fed by all these fantasies
- Even in literature, think about [*No Exit*](https://en.wikipedia.org/wiki/No_Exit), a great play by [Sartre](https://en.wikipedia.org/wiki/Jean-Paul_Sartre), where people are dead and they’re watching themselves
  - That’s interesting as a way of learning something through the fantasy of literature
  - There’s a theme that runs through that, that we’re dead and we see ourselves with despair
    - Paul feels pretty sure that’s not happening
    - It would really make no sense that that happens, that there’s some punishment of seeing ourselves with despair
    - Why would it be?

***If we’re open to the idea that we just don’t know***

- And the literature and the philosophy and the world around us have interesting things to say, but no one’s going to tell us
  - Isn’t that awesome? Paul thinks it is

## Advice for finding a compatible therapist [1:43:45]

- Peter explains, “*There are a few facts that people are generally starting to understand, which is, of all branches of medicine, this is one in which the interpersonal relationship between the… therapist and the patient, the interpersonal connection matters more than it matters in any other form of care*.”

**Would you agree?**

- Yes, there have been many studies that show how important **rapport** is between a patient and their provider

*People can come at things from different perspectives*

- Think about anger and how [Andy](https://www.pdbti.org/people/andrew-white/) or [Katy](https://pacificpremiergroup.com/katy-powell-pmhnp-bc/) may come at this from the angle of getting a space between he anger and the response
- Paul may come from the understanding that you go to a place of humility and gratitude
  - But he wants you to pause too

***They’re not doing different things, but what they are doing is from very different perspectives that will feel very different if you’re on the receiving end of it***

- The presumption is the therapist knows what they’re doing
  - They’re coming at the skilled part of it from different perspectives

***But it doesn’t matter that the therapist knows what they’re doing if there isn’t rapport***

- Peter takes rapport as a necessary but not sufficient piece of the equation

**What are other things that a person should be asking themselves?**

*Address both (A) where you are seeking help of a therapist for the first time, and (B) you have been working with a therapist for a long period of time and you want to evaluate if it is productive*

- The impetus for (B) is that Peter can’t tell you how many people he’s met who to his untrained eye seem to be more critical of self than others
  - And he thinks, “*What is your therapist getting paid for? You are having the exact same problems today that you had 5 years ago. If anything, you seem a bit worse*.”
  - He asks this from a place of wanting to see people get better (not judgment)
- Paul would start with an **overarching principle** (because he thinks the principle always applies) and then it can get at a lot of these things underneath the principle
  - He would ask, **“*****Does 1+1 equal more than 2?*****”**
- The way that mental health was thought about before the end of the Second World War, our minds were conceived of as very transactional
  - They would say (even now), I put something out there in words, you take it in, then you put it into your brain, you put something out in words, I take it in
  - Even though they would acknowledge we’re doing something, the thought was it’s very transactional
  - And what we see is that’s *not* really the truth
- [Viktor Frankl’s](https://en.wikipedia.org/wiki/Viktor_Frankl) writings after the Second World War were really an impetus to really see this and led to a whole different type of psychotherapy that was called [existential psychotherapy](https://en.wikipedia.org/wiki/Existential_therapy)
  - It still is existential psychotherapy, and it doesn’t map to the existential philosophers exactly, but they are principles there that are around shared humanness
- Do you feel like 1+1 is more than 2?
  - When you’re with the person, you’re going to have thoughts and feelings and ideas, and that person’s going to have thoughts and feelings and ideas too
  - And does that create something more between the 2 of you?
- The thought is, this is how we find meaning in life, that when we’re with someone we love, for example, it’s not just: it is us and it is them
  - There is an “us”
  - You’re you, the other person is who he or she is, but together there’s something different that each isn’t going to find on their own and that each isn’t going to find with another person

***In this case, the dyad is special: the two people together are more than the sum of each of them***

- Paul thinks that’s true for satisfaction, enjoyment, learning in human relationships because these principles run wide

**The same thing applies here [to your therapist] too: there should be someone whose presence and whose work with you figuring things out feels greater than the 2 people in the room**

- That’s a lot of what rapport is
- There’s a shared humanness
- There is a positive regard of the other
- There are pleasantries and nice ways we can build rapport, but they’re more on the surface
  - They’re important, but that’s not what makes real rapport
- What makes real rapport is the fact that here I am with you and there’s something different with us than there is than just the sum of us
  - There is something new and different that I feel when I come in the room to see you
- There’s an obligation of the therapist
  - To know the technical things
  - To give ourselves in a way that has us truly be present with the person

**To the question of, “*****Should I have this person be my therapist or should I… try something new?*****”**

- Try that on for size and it doesn’t fit, you should probably change something

**How long in the context of looking for a therapist, how many meetings with a person do you think you need to have before you can evaluate that?**

- Paul talks about this a lot
- You can know if things aren’t right, if you’re not going to resonate with someone
  - For example, someone who’s not making eye contact
  - Or you feel an awkward sense
- Be fair and reasonable about it: do you want to be in therapy?
  - If you don’t, then maybe you’re going to find something wrong with everyone

***If you really bring yourself to the process, then you can tell “no” sooner than you can tell “yes”***

- In the first couple sessions you’re trying to build a relationship and people need to get to know one another
  - How they respond and what their mannerisms are
  - If they have a sense of humor
  - How much emotional valence is inside of them
- It takes time so there’s a little bit of a dance like there is in any new human relationship
- If something really rubs you the wrong way and you’re looking at that honestly, you could probably tell if it’s a “no” on the 1st, 2nd, 3rd meeting
- If not, give it a little bit of time (5-7 meetings) just to see, “*Do I feel like I’m resonating with this person? Are we really getting somewhere?*”
  - Progress and the perception of progress is not linear
  - Sometimes 4 sessions in with a the person, you’re not sure
    - Give it a couple more because sometimes by the 6th, the person feels like it’s falling flat and 1+1 is not equaling more than 2
    - Or sometimes the stuff we did early on is clicking a little bit and now it’s only session 6, it’s 2 more than 4, but they start really feeling something

*Paul’s advice: be observant, be patient*

- What’s going on inside of you?
- How are you feeling?
- Are you feeling help?
- Do you feel what gets called a holding environment, that the space when you go in is a safe space?
  - Where you can be open and honest
  - Because so many times people fear criticism or they feel that they’ll say something
  - People fear that they’ll divulge something and then the other person will recoil in horror (this is often true with trauma)
- As a therapist, if you develop enough of a holding environment, enough benign regard, enough real humanness with the person, then that can come out of them [the patient] without them having even decided
  - It just naturally flows out because they know that they’re in a safe place and somewhere inside of them they know that the other person isn’t going to recoil
    - Just like what would you say to your best friend

**Thinking back to Peter’s example**

- Somewhere inside of you, you know that you don’t really want to be saying the things you’re saying to yourself
  - You know that because, why would you say it to yourself and not someone else?
- But that’s different than having an experience of it and having an experience when Peter was making the recordings
  - You’re having an experience of a more **accepting self** (that’s great)
- We can also have that experience with another who represents a more accepting self
  - If the other person doesn’t recoil, that’s right, you’re not really recoiling from that either
- Peter really felt uncomfortable sending those recordings to [Katy](https://pacificpremiergroup.com/katy-powell-pmhnp-bc/)
  - He initially said, “*Well, I’m uncomfortable because I hate that I’m wasting her time. I’m lighting up her phone with text messages of these recordings.*”
    - But that was less of what it was
    - It was more that he was ashamed of the fact that he’s doing this and how difficult this is
    - And what is she thinking when she gets this?
- You have to know that she really wants you to send them, and she really wants to help you
  - She really feels good about you
  - She sees the goodness in you
- Then that lets you do something that exposes the **shame**
  - Paul thinks part of what you feel ashamed of is that you’re doing that to yourself
  - The shame that this is so hard to do

*Now it’s witnessed because there are competing shames*

- The shame of not being perfect leads you to do something shameful to yourself, which is to be berating yourself
  - If you did that to someone else, we would say, “*Hey, that’s a good reason to feel ashamed to talk to somebody like that just because they broke something*.”
    - We say, “*Hey, that’s not okay*.”
  - So why is it that you shouldn’t feel ashamed when you’re saying it to yourself?
- Shame can help us by changing behaviors, but now you have competing shame
  - Should you be ashamed that you’re not perfect and it’s good that you’re beating up on yourself?
  - Should you be ashamed that you’re beating up on yourself because it’s okay that you’re not perfect?
- This is part of what keeps us in stasis
- But then she, as the person, she’s not completely separate from you in that way
  - 1+1 is equaling more than 2
  - Because she becomes a little bit of an arbiter or a metric of what really makes sense here, and her reflecting back to you that, “*Hey, you’re worth treating better than this. This is not okay for anyone including you. It’s not okay. You’re not the only person who gets to be beaten up this way*.”
- The part of her that is seeing that helps make it easier for you to change, because then you put the shame in the right place
  - If I feel ashamed that I’m doing this to myself, I want to stop, and if it’s going to take a long time, I’m going to let it take a long time
  - I’m not going to be so ashamed it’s still here in 3 weeks that I stop
  - I’m going to keep doing it, but part of what lets you do that, it’s the exposure to the outside person who you trust
    - Because then that person becomes a barometer of what’s real and true
- It helps us get our minds into place, to get this
  - It is okay that I’m not perfect
  - I do not want to beat up on anyone like this, including myself
  - Now, you’ve got the resolve inside of you to do it
    - Why? Because you’ve been validated
    - Whereas before you might not have been so sure if the shame is with the lack of perfection or with the self-talk

## The key components of therapeutic progress [1:57:00]

**How often do you see a therapist whose rapport is in the way: they’re getting along but not hitting the 1+1 is more than 2**

- The rapport is such that it’s almost **enabling** the behavior in the patient, there’s no progress being made, and yet the patient feels great about the therapist?
- An objective person would say that things aren’t getting better

*Is there value in just having a person that you pay to listen to what’s wrong, or are you paying this person to help you become better at dealing with whatever it is that’s going wrong?*

- The critical 1st step is to recognize that you need to reevaluate the relationship

*What are the tools to evaluate that?*

- Yes, this happens a lot because not everybody brings their best to their work
- For some therapists, they’ll let the person come and go and they rationalize, well, they’re still clicking along and they’re doing okay
  - They’ll rationalize that what they’re doing is a non-doing (they’re not actually doing anything)
- But the therapist has to know we’re either achieving something now or we’re heading towards achieving something that’s changed in this person
- It’s the job of the therapist to be active about that and not get complacent
  - If they see that person wants to get complacent, it’s their job to talk to them about it

***In this situation it’s good to question, what am I doing here?***

- When you go for an hour of therapy, do you want to understand yourself and make change?
- Are you going to talk about all the things that are making you angry in the last week?
  - And then that person gives you a little bit of sympathy and you’re no less angry?
- **Paul’s advice**: you want to really look inside at what the person is serving, and also how good does it feel, how comfortable does it feel?
  - It shouldn’t always feel good and comfortable
  - There should be times when you’re talking about something that’s not easy to talk about, or you’re crying in therapy, you’re upset in therapy
  - It’s supposed to be work
    - It doesn’t mean it has to be work every moment
    - If it’s easy, that’s not a good sign
- If you feel a threadbare, it’s hard to quantify when 1+1 is more than 2
- But you do know it often in human relationships: you just feel good with someone
  - There’s something where you’re more than the 2 of you
  - That’s why people want to spend time together
  - That’s why people become romantically interested in one another
- Peter finds this fascinating because he’s never contemplated it
- He agrees that 2 people (like Paul and himself) who are very close friends, it’s a clear example of the accretive nature of their interaction
- A therapist and patient shouldn’t necessarily be friends

**What are some other questions a person can ask to try to get at that accretive nature of coexistence?**

- Go back to the framing of it: how do we decide people are friends?
  - You can’t qualify all of that
  - They know something about one another
  - They’re interested in on another’s well-being
  - They have points in the past to tether to
  - When they’re together, they leave feeling different
    - Because they have a real human relationship
- That shouldn’t be different in therapy
  - It doesn’t mean that these people are friends and they’re going out for dinner together
  - It’s a human connectedness and there’s something that’s greater than the sum of the parts

*If we look at friendship as an aspect of human interconnectedness and a human ability to see and feel and be present beyond the self*

- That happens in friendships, that happens in romance, that happens in parent-child relationships, that happens in a therapy room
- If that doesn’t happen, there’s a problem
  - There is supposed to be something greater than the sum of the parts

***That person has to have real regard and interest in the person, have some aspect of the friendliness that friends feel when they’re togethe***r

**The** [**existential therapist**](https://en.wikipedia.org/wiki/Existential_therapy) **understood that the brand of therapy**

- That when it was thought everything is transactional, you could sit behind the person
  - It’s not as if there’s nothing that could ever be gained by that, but that can’t be the baseline of it
- What has happened since then where people like [Harry Stack Sullivan](https://en.wikipedia.org/wiki/Harry_Stack_Sullivan) or the existential therapist that came after [Viktor Frankl’s](https://en.wikipedia.org/wiki/Viktor_Frankl) writing, [Rollo May](https://en.wikipedia.org/wiki/Rollo_May) and [Irvin Yalem](https://en.wikipedia.org/wiki/Irvin_D._Yalom)
  - They were doing something different

***They were like, we’re humans being with other humans (that’s real)***

- When Paul learned that in his therapy training, when that element was added, it was like, “*It’s okay to be human*.”
- Paul had an existential therapist who was taking care of him at the time, and he also had some mentors who [conveyed the idea that [as a therapist] we have to think about the other person
  - The session is about the other person, but we’re both humans and it’s going to help them if they see that in their therapist too
- Paul explains, “*Every now and then it makes sense to disclose something, to talk a little bit about yourself and the service of the other, to let the person know something. Let them know that you are not perfect.*”

***The reason he and Peter are able to help people is because they are suffering through things that other people are suffering through, and there’s a humanness to that which is real and honest***

- People can always hide behind something, whether it’s socio-economic or it’s a power differential or it’s a position in life
  - But that doesn’t make anyone feel better

**The truth of it is, we do share humanness with everyone**

- Anyone can get trampled by the society around us
- Lightning can strike us
- We all suffer
- We all have struggles within us

***So acknowledging that we’re all human and we’re trying to help one another, but we’re coming at it from a place of acknowledging what’s going on inside of us and that we are not perfect***

- That’s why therapists learn from their patients
  - Good therapists learn from their patients
  - Why? Because I’m human too and I don’t have all the answers
    - Hopefully, I have some education and training that can let me help you, but also helping you will help me too

## The caricatures of four common patient phenotypes, and how to get through to them [2:05:30]

- 1 – The **workaholic**, the extreme achiever
  - This person is so successful on the outside and everybody assumes everything is wonderful, but that’s not entirely true
- 2 – The endless **optimizer**
  - This person is incredibly rigid and controlling of everything in order to drive towards perfect (health, as an example)
- 3 – The very **anxious person** who struggles with the fear of the future (this can be short-term and it can be long-term)
- 4 – The **denier**
  - This is a person who by any reasonable metric is suffering, but their barriers to accepting that are so high that you can almost make a cartoon about it
    - Where you see a person who’s missing an arm and you ask them if you can help them because they can’t do something that would require two arms
    - They look at you like, what are you talking about?

**How do you think about trying to get through to any of these phenotypes, to put the thin edge of the wedge in there such that they can make a tangible step towards self-help?**

- The first thing to do is recognize that there’s a problem
- Then you go back down this idea that there are these cupboards in the conscious mind and the unconscious mind, and that if we go and look and scrutinize what is going on inside of us, or we have curiosity about what is going on inside of someone else, that we’re going to find the answer
  - That this is not a mystery, that this is just like a Sherlock Holmes investigative process or a math problem
  - One can look at it and learn things
- #1 **the workaholic**, the word by definition is a problem
  - Oftentimes they’re avoiding something
    - Alcoholics are trying to avoid something by drinking to get away from it, and it’s no less true with workaholics
  - There’s something going on inside that person that they’re afraid of, that they’re suffering from, that they’re ashamed of, something is driving this behavior

***Ask: What are you avoiding? What are you trying to get away from?***

- Workaholic doesn’t mean you work very hard and you achieve at a high level
- Workaholic means you’re working when it makes absolutely no sense to work
  - So what are you escaping from?
- There’s a defense here that is usually avoidance as a defense
- There’s other defenses that come along with it
  - The person can put blinders on themselves, go in one direction, feel that that’s good enough, but boy, aren’t they seeing what’s on the other side of it or feeling what they would feel on the other side of it
  - That becomes a point of curiosity
    - Is there avoidance? What is that avoidance? What’s going on inside that person?
- #2 **the optimizer** they’re always trying to perfect, and there’s something different going on there
  - Probably more rationalizing
- We all know that things get to a place that’s good enough
- The person is still trying to make something that’s really solidly good enough, perfect
  - What’s going on there?
  - What are they serving inside of themselves?
  - They’re going to soothe something
    - Some anxiety then gets soothed because they do something that’s irrelevant
- Let’s go look at why the need to focus on optimizing something that’s already good enough
  - There’s other things to do in life
  - There’s other ways to spend that time and energy
  - Why that focus?
- With #3 **the very anxious person**, that leads us to what’s going on in side of them
- Younger people in Paul’s practice call it “future tripping” (anticipatory anxiety)
  - Is there a way that a person’s fear about the future shuts them down so that they’re not doing anything in the present and they don’t have to be afraid that what they’ll do won’t work in the future?
    - That doesn’t go well, but we get into those places
- What is that anxiety inside?
  - What is it about?
  - Why is it so high?
  - Again, we become curious about that
- #4 **denial** is the hardest one
- We think of maladaptive defenses, because how do you get someone around maladaptive defenses?
  - You’re trying to help them understand
  - If you’re rationalizing, there’s a little bit of a place we can grab onto that.
    - Some of it makes sense, then it doesn’t, but denial can be very, very cut and dry and very frustrating to come up against
- [Peter Grover](https://pacificpremiergroup.com/peter-grover-ph-d-llc/) is a therapist in Paul’s practice who is very, very experienced and good at helping people in denial
  - Peter has a sign on his wall: how’s that working for you? (that’s his mantra)
  - The idea is the person is at odds with a therapist
  - When you ask, “*How’s that working for you?*” Then you can look out at it together
- Paul met [Leston Havens](https://en.wikipedia.org/wiki/Leston_Havens) many years ago, who in an era when most therapists were sitting behind the patient, he would sit next to them and look out at the world together
- You’re trying to do that, “*How’s that working for you?*”
  - It’s like, okay, I hear what you’re saying
  - It’s not saying it’s right or wrong, whether you’re working or you’re doing this or that
  - Let’s just look at how it’s working for you
- Peter thinks that can’t be answered without some introspective capacity
- Peter has interacted with people where maybe he didn’t ask that question point blank, but he can almost imagine that if he did, they would respond, “*Great… can’t you see, everything’s great.*”

**If people around individuals like that [#4 the denier], if they care about them and they want to help, how can they help them probe even further?**

*You heard about an intervention where you get everybody in a room who knows this person. What’s the equivalent of that state here?*

- It’s hard
- Sometimes you can come at it
- The idea here is the person is not letting you see “with them”
  - You’re “across” from them (metaphorically)
- What you can do is say to them how you see it, because it is, “*I can’t impact you. You’re not letting me. Barry, there’s nothing wrong. That’s your story. You’re sticking to it.*”
- Presumably, if one is having that conversation with a person, 1+1 is equaling more than 2
  - That’s why you’re sitting across from them
  - There’s some emotional investment
  - There’s some respect, some love, or consideration
  - There’s something there that when you say, “*Hey, I just understand that and I hear where you’re coming from, and I hear it loud and clear. I just want to say to you that from where I sit, as someone who knows you, cares about you, loves you, whatever it may be, what I see doesn’t seem okay to me, and I just want to say this. I’m not trying to force it on you*.”
    - People sometimes will remember that down the road
    - Maybe you can’t help this person right now, but maybe you can put a seed in there that may come about later
- Paul sees this with someone who’s drinking very heavily and not acknowledging
  - It’s not hard to see from the outside
  - But that person is like, “*I don’t feel any different. There’s nothing wrong.*”
- Try to put the idea of at some point you’re going to start feeling something different
- Also remember that you can’t get through to everybody, and that’s okay
  - If you can’t, don’t keep trying because that person has long turned you off and tuned you out
- Sometimes Paul sees this in his own work with someone who he thinks things ended badly and the person wasn’t helped, and they left
  - He tried to plant the seed, and then they come back in a couple years
    - It’s proof of concept that you’re doing the right thing by planting those seeds
    - But more often than not, we see someone else has planted a seed (another therapist or friend, long ago)

***If we can plant seeds in people who are in denial, those seeds may grow, but we have to understand when we can’t do more than that and stop. Otherwise, we could drive the person away and prevent any help from coming.***

## How Paul manages his own well-being and the emotional challenges that come with his line of work [2:15:15]

**How do you manage internally the challenges of what you do, in the sense that you work with all sorts of people across all sorts of spectrums?**

- Peter points out that Paul is very quick to look for trauma in a person’s life that has probably shaped many of their current adaptations
  - In doing so, sometimes those things are very sad/ tragic

*How do you manage the sadness around that for yourself?*

- Peter thinks about what it was like being a resident
  - Patients would come in and they would die
    - Trauma victims, sometimes from a car accident
  - You take care of them and can’t save them
- We don’t really get taught how to manage that at all
- Peter found that to be hands down, the biggest failure of their training system
  - Perhaps that’s changed, but certainly when he went through there was absolutely no discussion of that
- He remembers being reprimanded for going to the funeral of a patient
  - The idea being that’s a line you never cross and you have to block that stuff out
- Paul agrees, in their era of training, medicine did a lamentable job of that
- Hopefully in medicine, you’re selecting for empathic, compassionate people
  - When a person is built that way, 1+1 is more than 2
  - So you feel part of a we, and if you’re taking care of someone and they die, you feel part of them
- We see that with people we really love close to us: they’re part of who we are
- We see this in settings where we’re helping people too
- Paul remembers very vividly being an intern and having to tell himself, “*I am not this person.*”
  - Because then he could see this person is suffering and it’s easy to lose those **boundaries**
  - So to be able to say, “*I’m standing here. That person is there… I have to know that I’m not that person*,” (but it wasn’t easy)
    - It starts with that because that’s a physical separation
- Then the idea that he can mentalize a lot, meaning think a lot and feel things

***We can all do this, but when you do this when you’re a therapist, you’re feeling what other people are feeling. You’re feeling for them. It’s easy to keep that in your mind too much.***

- Then just like if we picked a word and said it 5,000 times, it’ll be in us tomorrow

> “*If there’s something you don’t want to do and you repeat it 20 times, you’re more likely to do it again. The same is true when we can’t bound ourselves well enough from the suffering in other people*.”‒ Paul Conti

- This is why people have post-trauma syndromes from **vicarious trauma**
  - This absolutely happens
  - The brain is changed
    - There are biological changes, behavioral changes, and all of that trauma is vicarious
- This is why we see the levels of depression and suicidality and substance use is higher in people who are giving care to others

***It is so important that we have these boundaries inside of us and they have to come from this place of balanced drives and gratitude and humility***

**Paul is so grateful he gets to know other people and they share things with him**

- He can help them, and he can learn from them
- That is such a wonderful thing that it helps him to accept the other side of it
  - Which is sometimes things that are very, very hard to hear or very hard to get out of our minds, and he has to have the humility that he is human too
- If he keeps this in his head or if he’s really mad about these things that happen to somebody, he can fester on the anger, the frustration, the misery of this, and he will hurt himself
- Paul’s obligation to himself and to the people around him that he cares about is, “*I want to be healthy. I want to be at my best, and I have to be able to maintain these boundaries inside of me.*”
- He must have the discipline to stop thinking about that
  - Take stock of, “*I’m doing the best I can for that person. I’m still worried he’s not going to have a good outcome. Am I doing what I can do?*”

**Paul finds it is easier to do that as he focuses more on the balance of drives, on being generative**

- He’s asserting himself
- He’s taking pleasure in what he’s doing and he feels gratitude for what he’s doing
- He also has the humility to know that if he doesn’t take care of himself, it’ll kill him too

§

## Selected Links / Related Material

**Previous episodes of** ***The Drive*** **with Paul Conti**: [1:00]

- [#15 – Paul Conti, M.D.: trauma, suicide, community, and self-compassion](https://peterattiamd.com/paulconti/) (September 17, 2018)
- [#105 – Paul Conti, M.D.: The psychological toll of a pandemic, and the societal problems it has highlighted](https://peterattiamd.com/paulconti2/) (April 10, 2020)
- [#190 – Paul Conti, M.D.: How to heal from trauma and break the cycle of shame](https://peterattiamd.com/preview-190-paul-conti-m-d-how-to-heal-from-trauma-and-break-the-cycle-of-shame/) (January 10, 2022)

**Paul’s book**: [Trauma: The Invisible Epidemic: How Trauma Works and How We Can Heal From It](https://www.amazon.com/Trauma-Invisible-Epidemic-Works-Heal/dp/1683647351/ref=sr_1_3?crid=2Y4RURJAIXYUQ&keywords=paul+conti+trauma&qid=1638386640&sprefix=paul+conti+%2Caps%2C181&sr=8-3)  by Paul Conti (Author) and Lady Gaga (Introduction) (2021) | [1:15]

**Paul’s practice**: [Pacific Premier Group: Brain-Based Consulting Clinical Mental Health Care](https://pacificpremiergroup.com/) | [1:30]

**Arthur Brooks book on the transition from fluid intelligence to crystalized intelligence**: [From Strength to Strength: Finding Success, Happiness, and Deep Purpose in the Second Half of Life](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Arthur C. Brooks (2022) | [7:30, 14:15]

**PCS intensive therapy program**: [PCS: Psychological Counseling Services: Healing Hearts & Transforming Lives](https://pcsintensive.com/) | [1:00:30, 1:08:00]

**Book about the difficulties of life in the Dust Bowl**: [The Worst Hard Time: The Untold Story of Those Who Survived the Great American Dust Bowl](https://www.amazon.com/Worst-Hard-Time-Survived-American/dp/061834697X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.01gv1t59d_g1a_-V6IowQXYtxmpGbfMrjxGhkHZA5ARJE5Nc4eduTkSogYzzfBFPX34GyzAoqF5WWtylvvkbbr4EmpcLezXCeyJV0qvrDPLuLgWC8VSUvSj6jqDQumXZoLM02Xvek_bsvm6mzwRa072D_vUYgfvLmNOhWM0qtjdtG9Orr48EGb0TZskYWTSFcjXu40PRpiYt1nNRc_o7xYYRQfy58_uhsDr8yBYL8i4.7FN9C_gZEY-RSsUSK9sQPn1PJ1nG9dgVuGiRwBw0QCI&qid=1709752612&sr=1-1) by Timothy Egan (December 2005) | [1:24:45]

§

## People Mentioned

- Arthur Brooks (Harvard professor, Ph.D. social scientist, and bestselling author) [7:30, 14:15]
- Katy Powell (Psychiatric Mental Health Nurse Practitioner at Pacific Premier Group) [1:08:00, 1:18:30, 1:45:00]
- Andy White (Associate Director and co-owner of the Portland DBT Institute) [1:14:45, 1:18:30, 1:45:00]
- Viktor Frankl (1905-1997, Austrian psychiatrist who founded existential psychotherapy) [1:48:00, 2:03:45]
- Harry Stack Sullivan (1892-1949, American existential psychologist) [2:03:30]
- Rollo May (1909-1994, American existential psychologist [2:03:45]
- Irvin Yalem (American existential psychologist and emeritus professor of psychology at Stanford) [2:03:45]
- Peter Grover (psychologist at Pacific Premier Group) [2:11:00]
- Leston Havens (1924-2011, American psychiatrist and physiotherapist) [2:11:30]

§

![](https://peterattiamd.com/wp-content/uploads/2024/04/bio-paulconti4.png)

##### Paul Conti, M.D.

Paul Conti earned his medical degree at Stanford University. He completed training as a clinical psychiatrist at Stanford and at Harvard, where he served as chief resident. He continued at Harvard Medical, serving on the faculty while he also worked in private practice. In 2008 he moved to Oregon and during his first full year of practice there, was named as one of Oregon’s top psychiatrists. In 2014 he founded the Pacific Premier Group, where he is currently the President and also works as a psychiatrist and consultant.

Dr. Conti is a general psychiatrist, treating all aspects of both mental illness and the impact of life stressors. Dr. Conti is adept at helping people untangle complex problems, and he incorporates a holistic view of each client or patient into his work, knowing the far-reaching impacts trauma can have upon the systems and communities in which an individual resides, works, and serves. His practice includes the use of medications and psychotherapy, and he also treats complex cases, co-occurring alcohol and drug issues, and does neuropsychiatric assessments.

Dr. Conti is the author of [*Trauma: The Invisible Epidemic*](https://www.amazon.com/Trauma-Invisible-Epidemic-Works-Heal/dp/1683647351/ref=sr_1_1?crid=MS9CFNXCNJOK&dib=eyJ2IjoiMSJ9.7mcVwe9wf7iEpcEgP92jjths4D7vTjAJyozv8RxaCGWkMauclJ8ebT4VasAMTvW8Iz7xLmm-ZFKhqJdYvcG4d092KhCKkCbHql3Bntbcm4mXh9V1q3Jo9OTfjKxrDeTvUp6hh1ojMmOmd09loyakDjU0T2YunlCb3JmBKxVtbLVzZSP8ZD8SBxDzo0Lxff72jiAkNmk72vZbkD_TvgS0DvystEYYKozp15DKJQ6uVQ4.-q5xciOfTGcgMUOc5eE_676RMwgWPop9TTp92fkAyI4&dib_tag=se&keywords=trauma+the+invisible+epidemic+by+paul+conti&qid=1709564787&sprefix=trauma+the+in%2Caps%2C108&sr=8-1), a book that brings his valuable insights about how we can collectively heal from trauma’s effects to a larger audience. [[Pacific Premier Group](https://pacificpremiergroup.com/paul-m-conti-md/)]

Website: [DrPaulConti.com](http://drpaulconti.com)