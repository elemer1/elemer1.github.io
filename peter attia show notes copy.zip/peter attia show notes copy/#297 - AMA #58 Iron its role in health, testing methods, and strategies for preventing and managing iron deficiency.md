# #297 – AMA #58: Iron: its role in health, testing methods, and strategies for preventing and managing iron deficiency

**Source:** [https://peterattiamd.com/ama58/](https://peterattiamd.com/ama58/)

---

In this “Ask Me Anything” (AMA) episode, Peter delves into the crucial yet often overlooked topic of iron and iron deficiency. He explores why iron is indispensable for the body, explains the repercussions of iron deficiency, and sheds light on the prevalence of this issue and who is most susceptible. Peter outlines strategies for increasing iron levels, covering dietary iron, supplementation, and infusion options, while also discussing the suitability of each approach for different individuals. Shifting gears, Peter tackles rapid-fire questions on creatine and sodium, as well as inquiries related to his book.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #58 show notes page](https://peterattiamd.com/ama58). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Overview of today’s topics and the importance of understanding iron levels in the body [1:45];
- The importance and ubiquity of iron in the body, and the role of the protein called ferritin [4:30];
- The processes of iron absorption, utilization, and transportation [9:30];
- Options for testing iron levels and how to interpret the results [13:45];
- What does it mean to be iron deficient and how is it different from anemia? [17:15];
- Symptoms of iron deficiency and/or anemia [22:15];
- How prevalent is iron deficiency and who is most susceptible? [24:30];
- The importance of consuming an adequate amount of iron daily to prevent deficiency [30:30];
- The best way to improve iron levels for someone who is deficient [34:45];
- Iron supplementation: various formulations and potential side effects [37:45];
- Intravenous iron infusion as an alternative to oral supplements — plus restless legs syndrome and other topics [42:00];
- Iron supplementation: who should and should not consider it [44:00];
- Peter’s approach to creatine and his pre- and post-workout supplements [50:15];
- Navigating sodium intake: effect on blood pressure, who should use precaution, and other considerations [54:45];
- Peter’s thoughts about the potential of writing another book [57:15]; and
- More.

§

The Peter Attia Drive

Iron: its role in health, testing methods, and strategies for preventing and managing iron deficiency

§

## Show Notes

§

## Overview of today’s topics and the importance of understanding iron levels in the body [1:45]

Today’s focus is on something that we haven’t really covered before, but we see a lot of questions come through, which is related to iron deficiency/ferritin

This is something that people see on blood tests… *so why does it matter?*

- Why is iron necessary in the body?
- What happens if you’re deficient?
- What are those symptoms?
- How prevalent is it?
- Who is most susceptible?
- And then ultimately really lean into what can someone do about this? And is there even any concern if you have too much iron?

Peter says:

- This is a topic that is far more complicated topic than we’re going to cover today, and that’s by design
- “*As we got down the rabbit hole of iron biology, it was like the most overwhelming thing I’ve ever encountered, at least for me. And I realized that we needed to bring it way back to make it more actionable. And I think we’ve struck that balance here today*.”

The goal of this podcast is for listeners to:

- Know what blood tests you should get so you can ask for them
- Know how to look at it and interpret it
- And know what to do about it

Additionally, Peter will answer some rapid-fire questions unrelated to iron, such as the following:

- Do you take creatine?
- Do you worry about the sodium in your venison sticks?
- A few other questions that we’ve seen come through a lot that will also tack on at the end of this

## The importance and ubiquity of iron in the body, and the role of the protein called ferritin [4:30]

*Why is iron so necessary in the body and why is this something that people should think about?*

- Basically 2% of the human genome encodes for iron-related proteins—that a staggering amount
- Of these, nearly half are heme-binding proteins

What is it about iron that’s important in the body?

- Well, a big part of it comes down to all things related to hemoglobin and oxygen binding and oxygen transport
- Another big part is that 6.5% of all enzymes in the human body are iron-dependent.
  - An enzyme is a substance that facilitates a chemical reaction
- So if you think about the trillions of chemical reactions that are going on inside of our body, imagine how many of them are facilitated by enzymes that depend on iron.
- If you forget everything else about iron’s importance, just remember this, **you’re not going to be able to move oxygen around your body without it**
- And when it comes to your mitochondria and other very important places in the body where cellular respiration takes place, some of the most important enzymes depend on iron.

*Do only certain tissues require iron, or is it something that is necessary throughout the whole body?*

- After a bit of searching, Peter had a hard time finding an example of a tissue that didn’t require iron — which tells you just how important it is
- As we get into how do you measure iron levels and stuff, a very important protein is going to come up over and over again—that protein is called [**ferritin**](https://en.wikipedia.org/wiki/Ferritin)
- If you’ve ever had at least a reasonably comprehensive blood test where they’ve checked more than just your iron level, hopefully you’ve noticed that they’ve checked your ferritin level
- **Take home message number one of this podcast is: if your doctors are not checking your ferritin levels, please ask that they do**
- It’s not enough to just know what your iron level is, you have to know what that ferritin level is as well
- This is a very, very ubiquitous protein which is sort of analogous to a lipoprotein
  - it’s a huge spherical protein and its purpose is to store iron
  - And its stores iron to the tune of, about 4,500 iron ions fit within one ferritin sphere
  - Where it differs from lipoproteins is that the purpose of lipoproteins is not really to store cholesterol, but really to transport them, and in the case of ferritin, it’s really more about storage and there’s a little bit of transport
- Most ferritin actually resides within tissues, namely the muscle and the liver
- But a small amount of ferritin is obviously found in the serum and that’s how we sample it.
  - And that’s why when you go and get a blood test, one of the things you look at is ferritin because it’s measuring the concentration of ferritin

\*A very important point\*

- Ferritin is also what is known as an acute phase reactant
- what that means is, anytime inflammation is present in the body, you will see ferritin levels rise and they will rise independent of iron levels
- Ferritin being the total body store of iron, the most dominant protein that speaks to total body iron stores when it is high, all things being equal, iron levels are high, and when it is low, the converse of that is the case
- But when a person has an infection, for example, their ferritin level can be high even if they are deficient in iron
- Similarly, if a person has chronic inflammation, their ferritin level will be elevated as will other acute phase reactants such as C-reactive protein, even while total body stores of iron remain low
- So therefore, you have to be a bit more nuanced in your appreciation for how to measure total body iron stores so that you can not be fooled or misled by high or low levels of ferritin.

## The processes of iron absorption, utilization, and transportation [9:30]

![](https://peterattiamd.com/wp-content/uploads/2024/04/f1-ama58.png)

**Figure 1.** Source: [Abbaspour et al. J Res Med Sci. Feb 2014](https://pubmed.ncbi.nlm.nih.gov/24778671/)

- Anybody who has studied iron will appreciate that this is a profound oversimplification of the system
- But it’s not necessary for the purpose of our discussion to get that much more complicated than this
- We consume about 10 to 20 milligrams of iron per day, and our absorption of that is roughly 10% so we’re going to absorb somewhere between one and two milligrams of iron per day
- The rest of it will be lost out of our GI system
- We’re also going to lose one to two milligrams of iron per day, primarily through desquamation of epithelial cells
- So if you do the math on that, you’re in iron balance if you’re absorbing one to two milligrams net per day relative to the one to two milligrams that you’re losing per day.

So for that person who is in iron balance, where does that iron reside? Where does that iron go that you absorb?

- As you can see in this figure, 3/4 of that goes into hematopoiesis, meaning it goes into the production of red blood cells, it becomes the central piece of the heme molecule that sits within hemoglobin, the protein that holds hemoglobin, that holds heme, and that transports oxygen and carbon dioxide for that matter
- The other 10% to 20% then will be put into a long-term storage depot—that’s the ferritin
  - Again, most of the ferritin is going to be in the liver and in the heart
- Then the remaining call it 5% to 15% goes into these other processes that we’ve spoken about

In summary:

- You’re going to consume 10 to 20 milligrams of iron
- You’ll only absorb 10% of that, which will perfectly offset that which you’re losing
- And of that amount that you absorb…
  - you put 75% of it right into the production of red blood cells
  - 10% to 20% of that you put in the piggy bank, that’s called ferritin
  - And 5% to 15% of that you use for the other enzymatic processes that we discussed.

There’s one other thing to say about this figure:

- Notice at the top of this figure, it says it’s got transferrin and it says transports iron
- So iron is obviously water-soluble meaning you don’t need binding proteins or carrier proteins to move around
  - So glucose and sodium, potassium, all of those things are water-soluble and they transport themselves freely through the plasma
  - Obviously we make a lot of hay about the fact that cholesterol is not water-soluble. Triglycerides are not water-soluble, and that’s why they need to, in the case of triglycerides, be bound to either albumin or inside of lipoproteins
  - And obviously cholesterol needs to be inside of lipoproteins.
- So the question is: If iron is water-soluble, it should just be able to move willy-nilly throughout the plasma
  - Of course it can’t because it is quite *toxic*
  - So based on the fact that free iron is toxic, it does need to be bound to another protein called transferrin
  - And a transferrin molecule is able to hold exactly two iron ions, and that is primarily the means in which iron makes its way through the circulation, and that’s how transport of iron is facilitated to cells
  - So a cell will have a transferrin receptor
  - That transferrin receptor acts as the baseball glove to which the baseball of transferrin with its two iron ions will bind, and that gets basically absorbed into the cell through a vesicle and then it gets incorporated to all the uses that it needs
- So this figure really shows you what’s the purpose of ferritin, transferrin, and obviously how iron moves between them

## Options for testing iron levels and how to interpret the results [13:45]

*What is the best way to get tested to determine if they have sufficient iron and then how can they also interpret those results?*

- It starts with just making sure that when you get your blood test (at least once or twice per year) and you want to make sure that they’re checking everything:
  - Ferritin
  - total iron-binding capacity (TIBC)
  - your actual iron level
  - iron saturation
  - And unbound iron-binding capacity (UIBC)

More detail about those things above:

- Iron is actually measured—when you get a serum blood test, they’re actually measuring the amount of iron that is within the plasma
- UIBC—the unbound iron-binding capacity—is the amount of transferrin that remains unbound
- Remember that earlier Peter said transferrin is a protein… it’s a protein that has the potential to carry exactly two ions of iron
- And basically your iron-binding reserve is the UIBC… it’s how much transferrin doesn’t have something bound to it
- If you then take the serum iron level, which is measured, and the serum UIBC which is measured, you then calculate something called the total iron-binding capacity (TIBC)
- you’ll see these show up as TIBC, iron, and UIBC
- You’ll then see another calculation which is called the TSAT, which stands for Transferrin Saturation
- And the transferrin saturation is obviously the total serum iron, divided by the TIBC

Interpreting results:

- What we want to be able to understand when we look at a patient’s blood levels is:
  - What is their transferrin saturation?
    - Meaning how much iron do they have relative to their total amount or capacity to bind it, in addition to what their total body stores are, which is communicated through ferritin?
  - And then obviously what the iron levels are themselves
  - But of these things, the total iron level for most people is not the big telling thing, it’s usually the ferritin
    - In fact, it’s when we can look at something like the transferrin saturation, it can help us understand, for example, if a patient is iron deficient even if ferritin is artificially elevated due to inflammation
    - Very low levels of transferrin saturation can be diagnostic of iron deficiency even in the presence of normal ferritin, which again, an example of that would be in a patient who’s got inflammation.

## What does it mean to be iron deficient and how is it different from anemia? [17:15]

**Iron deficiency vs. anemia**

- These two go often in hand-in-hand
- Remember, of the iron that you absorb every single day, 75% of it is going into the production and maintenance of red blood cells
- Clearly things that cut at the body’s supply of iron are eventually going to cut into the production of red blood cells—and the clinical term for that is [anemia](https://en.wikipedia.org/wiki/Iron-deficiency_anemia)
- Iron is this super important cofactor for many enzymes and it obviously plays an essential role in the formation of hemoglobin, which is the protein in the red blood cells that’s responsible for carrying oxygen from the lungs to the rest of the body
- So you will eventually find yourself in a place of anemia if you are iron deficient, but it can take a while
- In fact, you can develop other symptoms of iron deficiency long before anemia presents itself—that’s another reason it doesn’t makes sense to just look at a complete blood cell count, a CBC, to make a determination of whether or not a patient has iron deficiency
- In other words, anemia is potentially a later stage depending on the chronicity of iron loss, and you want to get ahead of this long before that occurs
- So iron deficiency can affect lots of tissues
  - For example, long before a patient actually has anemia, you’ll demonstrate benefits (as discussed in a [recent newsletter](https://peterattiamd.com/iron-deficiency-and-exercise/)), where replacing iron in patients who are iron deficient based on ferritin, but not yet anemic, improved athletic performance.

*Let’s look at what happens in iron deficiency anemia*:

- As ferritin levels fall lower and lower and lower, eventually the body is going to struggle to make enough hemoglobin
- Remember, red blood cells turn over about every three months…so while the spleen has the ability to recycle some of that iron, there’s always just kind of a net turnover and therefore a net dependency on an influx of iron
- So once ferritin levels get really low, and that’s typically going to be below about 10 to 12 micrograms per liter, you’re going to really begin to compromise the production of hemoglobin
- Interestingly, the body instead of using iron in its ferrous form (Fe+2), it substitutes zinc into the formation of the heme complex
- The assumption here is that it’s doing that because structurally it needs something of about the size of iron with the charge of ferrous iron and so it sticks that zinc in there and therefore it’s able to build hemoglobin
- But of course, it’s using zinc as the protoporphyrin, which is the thing that is responsible for binding hemoglobin… And guess what? *It can’t*
- So when you have zinc sitting in the middle of your heme, you don’t bind red blood cells, so you’re actually making red blood cells, but you’re using zinc instead of iron, and those don’t count as appropriate red blood cells (they’re not really doing the job)

> “I found that to be just kind of a little interesting piece of trivia as we think about what is it that the body’s actually doing in iron deficiency anemia, and it’s basically run out of iron to make hemoglobin, so it keeps making it, but doing so with zinc. I think that that is hands down the most important side effect, but by no means the only one.” —Peter Attia

**There are many problems of iron deficiency that happen before you get to anemia**

- The problem with iron deficiency outside of anemia truthfully, is that the symptoms such as fatigue are quite vague
- And as is the case with many conditions such as hypothyroidism, it becomes very difficult to really point a finger at it
- the point of this is don’t confuse iron deficiency with anemia
- Anemia as a consequence of iron deficiency is a subset, but iron deficiency is a much broader clinical scenario that can produce many symptoms that don’t include anemia
- Or to be more specific, you can experience symptoms of iron deficiency while you are not anemic

## Symptoms of iron deficiency and/or anemia [22:15]

***What symptoms might someone see if they are iron deficient and/or anemic?***

- Unfortunately they’re very nonspecific and they can be quite vague and attributed to many other things as well
- But they include:
  - shortness of breath
  - brain fog
  - general fatigue
  - Lightheadedness
  - increased sensitivity to cold temperatures
  - heart palpitations
- What’s interesting here is some of those are actually very similar to low thyroid symptoms minus the heart palpitations (typically, heart palpitations is something that we see in high thyroid)
- It takes a very astute clinician to be able to piece together a set of symptoms, but then very quickly mirror them to a set of biomarkers or blood results coupled with a sense of the cause
- The reason that these symptoms are so broad is because the need for iron is so diverse
- The lower efficacy of oxygen transport and storage in the blood, even prior to anemia, is at least in part explanatory for the fatigue, especially during exercise
  - So when we start to see demand-related fatigue, even absent anemia, that’s also a sign
- One really weird thing, which is something called [pica](https://www.mayoclinic.org/diseases-conditions/iron-deficiency-anemia/expert-answers/chewing-ice/faq-20057982#:~:text=The%20term%20%22pica%22%20describes%20craving,although%20the%20reason%20is%20unclear.), which is people who are iron deficient and crave eating ice
  - Peter has seen one case of this, which was a woman who was experiencing iron deficiency anemia while pregnant and had this insatiable craving for eating ice

**Another thing we see**: An exacerbation of restless legs syndrome (RLS) in those who are susceptible

- In fact, people with RLS, we have a much higher threshold for the ferritin level we want to see in them
  - For example, if we want to see a person’s ferritin at least at a level of 30, in someone with restless legs, we want to at least see it at 70 or 75.

## How prevalent is iron deficiency and who is most susceptible? [24:30]

***How prevalent is iron deficiency? And what are the odds that this could affect someone?***

- The answer of prevalency depends on what criteria are used
- A widely accepted criteria might be a ferritin level of less than 12 nanograms per milliliter
- The WHO defines it slightly differently—it defines it as less than 15
- Interestingly, the American Gastroenterological Association recommends that ferritin be north of 45 nanograms per milliliter, and that probably speaks to their profession—these are the types of doctors who most see people for blood loss, GI occult blood loss.
- So the fact that you can see such a wide variety where it could be as low a threshold as 12 as high as 45 clearly speaks to why it’s difficult to give a true prevalence
- Of course, the most susceptible individuals here are *pre and perimenopausal women* for obvious reasons, which have to do with regular blood loss
- And there we see a prevalence of probably on the low end 20% and probably on the high end 60% if we’re using a diagnostic threshold of less than 15 nanograms per milliliter
- With males, the numbers seem to be significantly lower than that, probably 4% to 8%, maybe up to 10% of males
- There was one [study](https://jamanetwork.com/journals/jama/article-abstract/2806540) published this year in JAMA that found that 17% of women and girls up to the age of 21 were iron deficient based on the WHO criteria of 15
  - If they use the higher criteria of 50, 77% of menstruating women were deemed iron deficient

The thing that matters most is: *where are the symptoms showing up?*

- But the literature is not clear enough because obviously based on how subjective many of these symptoms are, outside of anemia of course, this can be much more complicated.

***Who is most susceptible to potentially having iron deficiency?***

- If you’re going to be iron deficient, something in the following pathway isn’t working:
  - 1) Either you’re not taking in enough iron
  - 2) or you are taking in enough iron, but you are failing to absorb it
  - 3) You are losing a disproportionate amount of iron (and that’s almost always in the form of blood)

Let’s go through these

- 1) so not taking in enough iron, people on a vegetarian or vegan diet or any other iron deficient diet. That’s the biggest one we see
- 2) The next one is not absorbing it.
  - there are a number of GI diseases such as celiac disease, H. pylori, atrophic or autoimmune gastritis, and people who have had bariatric surgery where their GI tract is rerouted and they lose proximity to something called intrinsic factor
  - but hands down, the biggest reason is because of a very common class of drug called proton pump inhibitors, PPIs, which are used commonly for reflux
  - the reason for that is iron absorption requires an acidic environment, and so the more acidic the environment in the stomach, the more effective the absorption
  - That’s why vitamin C, which is an acid, when taken with iron, increases absorption
  - And so people on proton pump inhibitors, which are absolutely necessary for many people, especially someone with something like Barrett’s esophagus, they’re going to require much more iron intake to overcome their low absorption efficiency.
- 3) people who are losing blood, and that really fits into two categories
  - The first is women who are menstruating
  - the second is any individual with a gastrointestinal bleed because those are the types of bleeds that are largely going undetected
    - there are lots of people with slow bleeds from ulcers anywhere along their gastrointestinal tract who are shedding blood into their stool but not realizing it because it’s high enough in the GI tract that it’s not red, and these are the people who are at greatest risk.

> “I’ve seen a lot of cases of iron deficiency. I’ve seen a lot of cases of iron deficiency anemia. I can’t tell you I’ve seen one that isn’t attributable to some combination of … low iron in the diet, poor absorption, or blood loss.” —Peter Attia

**Pregnancy and lactation and iron deficiency**

- There’s one other case that’s worth noting, and that is pregnancy and lactation
- in the case of women who are pregnant and lactating, the demand for iron is so high that it can actually produce iron deficiency, potentially even anemia if the intake side isn’t high enough to match the demand

## The importance of consuming an adequate amount of iron daily to prevent deficiency [30:30]

*Does someone need to consume a certain amount of iron each day to ensure that their iron isn’t deficient?*

- Consuming 10 to 20 milligrams per day will lead to a net absorption of about one to two milligrams per day, which would offset that normal loss
- That normal loss is the shedding of the epithelial cells in the body
  - W*hat’s your epithelium?* It’s all of the skin of your body plus every cell from mouth to anus on the quote/unquote “inside” of your body, but that’s also outside your body
- So we just shed those cells daily and we’re losing one to two milligrams per day
- So we’ve got to be able to consume 10x that, and therefore if anything is altering that, so if we’re losing more iron, for example, through blood loss, or we are deficient in absorption, then we’re going to need to consume more

So total body stores of iron again are pretty big

- Two to four grams (2000 to 4,000 milligrams) of iron is the total body store in a typical adult
- So how does that break down?
  - Nearly half of that is in circulating red blood cells
  - About another 1000 milligrams of that would be in the liver
  - 600 of that would be in the immune cells (maybe part of why we also see the rise in ferritin in the presence of inflammation)
  - another 300 of that in muscle
  - 300 of that in bone marrow
  - and then the small amounts that add up in all the rest of the body

**Iron needs for different people**

- For men and postmenopausal women who have no other source of blood loss, who have normal absorption patterns, about 8 to 10 milligrams per day is required
- Conversely, for women who are of reproductive age, they need typically at least 20 milligrams of iron per day
- And pregnant women, of course, need significantly more iron, especially in the second and third trimester
  - And obviously that in part, is at least due to the need to have iron reserves for delivery, but also to accumulate the additional blood volume that’s necessary.

**Recommended daily allowance (RDA)**

![](https://peterattiamd.com/wp-content/uploads/2024/04/f2-ama58.png)

**Figure 2.** Source: [NIH Office of Dietary Supplements](https://ods.od.nih.gov/factsheets/Iron-HealthProfessional/#en2)

- When you’re looking at that table, remember this assumes no additional blood loss beyond what is baked into it, namely menstruation for women and it assumes normal absorption
- These are big caveats because there are a lot of people out there that are experiencing subtle blood loss and/or have other factors that are impairing iron absorption (most notably the use of PPIs)

**One very important point**: It’s very important that low ferritin levels not be ignored

- In fact, if a person is 50 years of age or older and they have low ferritin, they have colon cancer until proven otherwise
- Now most of those people will not have colon cancer, but if they are iron deficient, and especially if it’s impacting hemoglobin (for men the hemoglobin is below 13, and for women the hemoglobin is below 12) in the presence of low ferritin, *we need to assume that they have colon cancer until colon cancer is ruled out*

> “Again, that might be one of the three most important things I’ll say in this podcast, especially for those of you listening who are above the age of 50.” —Peter Attia

## The best way to improve iron levels for someone who is deficient [34:45]

***If someone finds out they are iron deficient, what is the best way to improve their iron levels?***

- First you’ll need to rule out things that are important that need to be treated directly (the most extreme example of that might be colon cancer or a GI bleed)
- From there, if it’s believed that the source of the iron deficiency is on the *input* side, then you want to increase the inputs, and the best way to do that is actually through the diet
- Animal sources tend to be more bioavailable than plant sources
- So meaning when you consume iron from heme, which is really what you’re getting with animal sources, it’s more bioavailable than the non-heme sources
- If you’re going to make it up with plant sources, you’re going to need to consume more than you expect—it’s about a 2X difference
- So the estimated bioavailability of iron from a vegetarian diet with non-heme sources is about 10%, whereas in an omnivore diet it’s about 18% because you’re getting a much higher fraction of that in the form of heme.
- Another thing that you can do is consume vitamin C with the iron
  - vitamin C is an acid and it’s going to transiently reduce the pH, which increases the absorption

![](https://peterattiamd.com/wp-content/uploads/2024/04/f3-ama58.png)

**Figure 3.**

- Outside of clams, there’s no food that in a single serving can provide your daily requirement, and that includes beef liver
- Beef liver, which is probably going to be your richest source of iron because you’re going to get 6.5 milligrams of iron and it’s heme iron, so it’s going to be more bioavailable than say, lentils
- A cup of lentils, by the way, is also very high in iron. It’s 6.6 milligrams, but it’s non-heme, so you’re only going to get half of the absorption that you get from the beef liver
- Again, none of these things by themselves are wholly sufficient
- **The big takeaway:** you need diversity in your diet, you need to be eating a lot of things that are high in iron
- When you look at this, you might jump to the conclusion that you should just be mainlining clams all day
  - That’s probably not a good idea, given that while clams do indeed seem to be very high in iron, they also tend to be kind of high in other metals as well, such as aluminum and cadmium, and that might be due to the grit and filtration that’s used in these bivalve systems
- As a vegetable, you can see broccoli is pretty high on the list, but it’s still only one milligram in a cup of cooked broccoli
- So we do need to be pretty deliberate about our iron consumption to make sure we’re hitting that 8 to 20 milligrams per day depending on where we are in life
- This table also gives you a sense of why so many people can be iron deficient, anemic, especially young women.

## Iron supplementation: various formulations and potential side effects [37:45]

*How do you think about supplements for iron deficiency and are there any side effects of those supplements you think people should be aware of?*

- For many people, they are going to need to rely on supplementation, especially people that show up with iron deficiency
- We’re dealing with two different cases:
  - One person may be iron replete and they’re probably going to be able to increase their iron through diet
  - But when people show up and they’re *iron deficient*, it’s almost always a case where they need to resort to some form of supplementation
- Something to keep in mind: As most multivitamins are now moving towards gummies, that means that they have no iron in them—you can’t formulate a multivitamin with a gummy that has iron in it
- To increase the absorption of iron:
  - Take supplements on an empty stomach
  - Avoid calcium products (calcium may have some inhibitory effects on iron transporters)
  - Take with vitamin C to maximize your absorption

*What do we know about any potential side effects of those supplements?*

Constipation is certainly a big issue

Peter has transitioned to giving patients “smarter” types of supplements

The three brands that Peter has seen reasonable success with:

- 1) [Slow Fe](https://www.slowfe.com/) (slow iron)
  - generally well-tolerated brand
  - provides 45 milligrams of elemental iron as ferrous sulfate (the absorbable form of iron)
  - Very slow release, and very few GI side effects
- 2) [Floradix](https://www.floradixusa.com/products/floradix-iron-herbs-liquid-herbal-supplement)
  - well tolerated, but it’s actually considerably lower in dose (10 milligrams instead of 45 milligrams in Slow Fe)
  - It’s a liquid—you also have to rinse your mouth after you use it, ’cause it could leave kind of a gray tinge on your teeth
- 3) [Vitron-C](https://www.vitronc.com/)
  - It’s 65 milligrams of elemental iron, but it also comes with 125 milligrams of ascorbic acid
  - Peter’s only been using this with patients for the last couple of months so he doesn’t feel that he has enough information to know if it’s going to end up being as good as Slow Fe

“*Those would be our preferred brands as opposed to just bashing people over the head with 80 milligram iron tablets of which they don’t absorb that much and they get profoundly constipated*.”

## Intravenous iron infusion as an alternative to oral supplements — plus restless legs syndrome and other topics [42:00]

- *If people can’t tolerate iron supplements kind of in pill form, do they have other options?*

- Iron can also be given intravenously
- Peter has given patients IV iron, but only in patients with restless legs syndrome
- Restless legs syndrome is a diagnosis based on having a strong, basically irresistible urge to move your legs
- They start to get worse when they’re resting so this really affects people when they’re laying down and especially when they’re sleeping
- Patients say that the best way they can get a good night’s sleep is do as many squats as possible before bed, which of course has its own issues
- The prevalence of this is actually quite high, somewhere between 1.5-2.5% of the population
- Iron really seems to play a significant role in this, not entirely clear why, but it’s certainly believed that reduced CNS iron stores produce restless legs syndrome through the effect on dopaminergic signaling.
- Peter has a much higher ferritin cutoff for these people, and he considers anything below 75 nanograms per milliliter to be low
- In these patients, even if we are able to get their ferritin level there orally, there’s at least anecdotal evidence that maybe suggests that getting it there intravenously produces better outcomes
- Again, those would be the only patients where we’ve used intravenous iron
- You can typically give people obviously significant more, up to 1000 milligrams, and presumably you wouldn’t need to do that very often

## Iron supplementation: who should and should not consider it [44:00]

*If someone that is not iron deficient wanted to take an iron supplement to be safe and prevent iron deficiency, what would Peter say about that?*

- You should not supplementing iron if you’re not deficient
- Too much and too little iron are problematic and they’re problematic in different ways
- You only want to supplement with iron if you’ve established a deficiency based on the metrics that we’ve talked about
- Not just looking at iron and not just considering anemia, but looking at ferritin, TIBC, UIBC, T-saturation, etc.
- But if you are normal by all of those metrics, then supplementation is not necessary

We also don’t want to supplement people without investigation

- Blood loss from colorectal cancer is the number one reason for low ferritin in people over the age of 50
- Earlier when Peter said low ferritin or iron deficiency, especially with hemoglobin below 13 for men and below 12 for women if you’re over 50, is colorectal cancer until proven otherwise.
- What we don’t want to do is have one of those patients say go take iron supplements and potentially to mask that problem instead of immediately getting medical help

**Too much iron is also a problem**

- You can actually overdo this—iron is toxic
- A main reason why kids vitamins are gummies (which don’t have iron) is because it eliminates the chances they would take too many and get iron toxicity
- Serum iron levels above 500 micrograms per deciliter would be associated with pretty significant toxicity
- In the **acute** sense, you would have abdominal pain, vomiting, potentially bloody vomiting and diarrhea, and then potentially even iron-induced coagulopathy, hepatic or liver dysfunction, cardiomyopathy, kidney failure
  - Those things are quite rare and would only be due to massive doses of iron getting into tissue
- What we worry about more are the **chronic** symptoms of elevated iron
  - Here we would see fatigue and weakness, which again, paradoxically is the same sort of symptoms you might see with very low iron
  - You might also see joint pain, abdominal pain typically from the liver, darkening of the skin, heart arrhythmias, and even diabetes from iron deposition within the pancreas

*A genetic condition which can lead to* ***excess iron*** *and downstream problems*

- One of the things Peter looks for in patients is any evidence of iron deposition in the midbrain, the basal ganglia, the cerebellum
- When he sees patients who have altered iron metabolism, especially if they’re at risk for any of the movement disorders such as Parkinson’s disease or Lewy body dementia, it heightens his level of concern and he takes other actions
- There’s a genetically inherited condition that by definition, many people listening to us have called [haemochromatosis](https://en.wikipedia.org/wiki/Hereditary_haemochromatosis) (1 in 300 people approximately)
- There are two pretty common mutations in the HFE gene (haemochromatosis gene), that lead to this phenotype
- The C282Y and the H63D mutations are the most common, and you need to be homozygous to have the condition fully
- So meaning haemochromatosis is when you have both genes that have been disabled, or altered, rather
- And so the C282Y mutation is homozygous in about 0.3% of the population and the H63D, while that mutation is much more common, the penetrance of it is actually quite low
- That said, even though “only” 1 in 300 people have haemochromatosis, the prevalence of heterozygosity is actually surprisingly high
  - 8% to 10% of people in the US have one copy of the C282Y mutation, and about 20% of people in the US are heterozygous for one copy of the H63D mutation
  - And these people also tend to have slightly elevated levels of iron, even if they don’t quite rise to the level of haemochromatosis
- Now in haemochromatosis, these patients absolutely require blood removal
- A friend of Peter’s was diagnosed for this when he had an elective MRI, and the MRI of the liver was completely lit up with iron
- In fact, the technician couldn’t initially understand the technical details of the scan because of how much metal was in the liver that had interfered with the scan, and that’s how he was diagnosed with haemochromatosis
- Fortunately for him, that led to the treatment that ultimately was able to reverse the content of iron that had built up in his liver
- But if that not been done, he ultimately could have gone down the path of ultimately cirrhosis and liver failure
- So if haemochromatosis is untreated, it can lead to diabetes, arrhythmias, heart failure and liver failure

> “*So there are lots of reasons to be taking this seriously. And I think given the prevalence of it, and even though most of what we talked about today was on the iron deficiency side, I think people need to be just as concerned about iron excess*.” —Peter Attia

## Peter’s approach to creatine and his pre- and post-workout supplements [50:15]

***Does Peter take creatine?***

- He does take creatine every day
- His workout drink consists of:
  - 20 ounces of water
  - A pack of [LMNT](https://drinklmnt.com/) (an electrolyte drink that increases the effective absorption of water)
    - Disclosure: Peter is an investor in LMNT
  - Plus 5 grams of creatine monohydrate (power)
  - He consumes that drink mixture during his workout every single day
- W*hy do I consume my creatine in workout*?
  - First of all, you do not need to
  - So creatine can be consumed away from the workout, but from a compliance perspective, it’s a ritual that he has every single day
  - For some people, 5 grams a day might produce GI effects such as diarrhea or bloating
  - And if that’s the case, then clearly you would want to either take less of it, and/or certainly not take it during a workout
  - But to be clear, you don’t need to take it in the workout to get the benefits

***On that, is there anything else you’re taking specifically, pre, during, or post workout?***

- No. Actually his post-pre-in-workout stack, if you will, has become significantly simpler than it used to be
- He used to be taking branched-chain amino acids and all sorts of other things but he doesn’t take any of those things anymore
- The evidence just isn’t there to support the use of branched-chain amino acids in workouts, as an important way to support muscle growth
- If you’re taking sufficient enough total amino acids and getting the right amount of branched-chains from your food, or with your whey protein supplement, Peter doesn’t think you need to be specifically spiking it in your workouts
- He also doesn’t use any of the other substances, so the nitric, the caffeine, any of those things

*Post-workout*

- He is usually just trying to eat protein post workout
- What he eats depends on how much time he has, but his favorite way to get a quick 40 or 50 grams of protein is by eating four or five sticks of venison jerky
- And they’re actually not that caloric because they have very little fat and carbohydrate in them, and you’re mostly just getting the 40 or 50 calories from the protein

## Navigating sodium intake: effect on blood pressure, who should use precaution, and other considerations [54:45]

*Is Peter concerned about the amount of sodium in those venison sticks given how many he’s eating each day?*

- It depends on what kind of jerky you’re consuming
- Peter only consumes two types of jerky:
  - One is the [Maui Nui venison sticks](https://mauinuivenison.com/collections?gad_source=1&gclid=CjwKCAjwwr6wBhBcEiwAfMEQs5L5Bkhr6MHSmBfGfh50aO5pTQN3m7aere1qJAlzGrtgPHTUxMQi1xoC-4oQAvD_BwE#fresh-venison) (Disclosure: Peter is an investor in Maui Nui)
  - Another is [Carnivore Snax](https://carnivoresnax.com/)

*Sodium*

- Maui Nui venison sticks have anywhere from high 200s to high 300 milligrams of sodium per stick
- Peter doesn’t look at the RDA for sodium intake as it is a bit of a misleading number
- It’s all about the individual—there are some individuals who can tolerate much more sodium than others
- As you may recall, we had a [podcast](https://peterattiamd.com/rickjohnson/) with nephrologist, [Rick Johnson](https://som.cuanschutz.edu/Profiles/Faculty/Profile/9426) who pointed out that while sodium absolutely is related to blood pressure, it’s a much more nuanced relationship than just higher sodium equals higher blood pressure
- It has to also do with factors such as uric acid and also the amount of water that’s being consumed with the sodium — i.e., how diluted is the sodium as it comes in?
- “*All of this is kind of a long-winded way of saying that I am personally not worried about the sodium I’m consuming because I’m able to track these other metrics*…
- …*For example, I know that my blood pressure, if anything, runs a little bit low, not a little bit high. And so my kidneys work just fine and they’re obviously taking care of the filtration*.”
- Does that mean that everybody listening should be out there eating jerky willy-nilly? ⇒ The answer is no
- There indeed are people with metabolic syndrome and/or hypertension who are sodium sensitive and they do need to be more careful with their sodium intake
- And if that’s the case, then consuming a protein source like jerky would still probably be a suboptimal strategy versus using a really high quality whey protein isolate

## Peter’s thoughts about the potential of writing another book [57:15]

*Has Peter started to write book #2 yet?*

- It’s been about one year since the release of [Outlive](https://peterattiamd.com/outlive)
- But Peter has put no work put into another book at this time
- Peter says there are two conditions needed to be true for him to write another book:
  - 1) He has to have more time available to work on it than he had for Outlive
    - He says the stress of writing Outlive took years off his life to make it and he doesn’t want to do that again
  - 2) He would need to have something else to say
    - He had a lot to say in Outlive, and that’s why it was worth the pain of doing it
    - And when he has something else to say that he feels strongly about, then he might say it
- So he’s not closing the door on book #2 but he’s not currently writing anything

> “There are three things that I could imagine writing a subsequent book about, but none of which I feel comfortable talking about publicly yet.” —Peter Attia

§

## Selected Links / Related Material

**A newsletter that discussed how replacing iron in patients who are iron deficient based on ferritin, but not yet anemic, improved athletic performance**: [Does low iron intake change exercise capacity?](https://peterattiamd.com/iron-deficiency-and-exercise/) | Peter Attia (peterattiamd.com) [19:00]

**JAMA study that found that 17% of women and girls up to the age of 21 were iron deficient based on the WHO criteria of 15**: [Prevalence of Iron Deficiency and Iron-Deficiency Anemia in US Females Aged 12-21 Years, 2003-2020](https://jamanetwork.com/journals/jama/article-abstract/2806540) (Weyand et al., 2023) [26:00]

**The three brands of iron supplements that Peter has seen reasonable success with**: [40:30]

- [Slow Fe](https://www.slowfe.com/) | (slowfe.com)
- [Floradix](https://www.floradixusa.com/products/floradix-iron-herbs-liquid-herbal-supplement) | (floradixusa.com)
- [Vitron-C](https://www.vitronc.com/) | (vitronc.com)

**The supplement Peter adds to his workout drink that “increases the effective absorption of water”**: [LMNT](https://drinklmnt.com/) | (drinklmnt.com) [51:00] [disclosure: Peter is an investor]

**The brands of jerky Peter prefers**: [55:00]

- [Maui Nui venison sticks](https://mauinuivenison.com/collections?gad_source=1&gclid=CjwKCAjwwr6wBhBcEiwAfMEQs5L5Bkhr6MHSmBfGfh50aO5pTQN3m7aere1qJAlzGrtgPHTUxMQi1xoC-4oQAvD_BwE#fresh-venison) [disclosure: Peter is an investor]
- [Carnivore Snax](https://carnivoresnax.com/)

**Episode of The Drive with Rick Johnson which discussed the nuanced relationship of sodium and blood pressure**: [#87 – Rick Johnson, M.D.: Metabolic Effects of Fructose](https://peterattiamd.com/rickjohnson/) | Peter Attia (peterattiamd.com) [55:30]

**Peter’s book**: [Outlive](https://peterattiamd.com/outlive) by Peter Attia | (peterattiamd.com) [57:15]

§

## People Mentioned

- [Rick Johnson](https://som.cuanschutz.edu/Profiles/Faculty/Profile/9426) [55:30]

§