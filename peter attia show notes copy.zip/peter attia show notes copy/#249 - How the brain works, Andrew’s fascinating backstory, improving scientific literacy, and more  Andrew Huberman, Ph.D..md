# #249 ‒ How the brain works, Andrew’s fascinating backstory, improving scientific literacy, and more | Andrew Huberman, Ph.D.

**Source:** [https://peterattiamd.com/andrewhuberman/](https://peterattiamd.com/andrewhuberman/)

---

Andrew Huberman is a Professor of Neurobiology at Stanford University and host of the [*Huberman Lab* podcast](https://hubermanlab.com/). In this episode, Andrew begins with a fascinating discussion about the brain, including the role of the prefrontal cortex in adjusting your ruleset to match your setting, the neural circuitry underlying the ability of stress to limit creativity and problem-solving, the effect of belief on physiology and performance, and more. He speaks about vision being our “superpower” and compares this to animals that rely more on other senses. Next, Andrew opens up about his personal journey, the struggles and losses he has overcome, the value of therapy, and the many great people who helped him along the way. He speaks to his love of biology and discovery and the importance of staying true to your passion rather than being driven purely by ambition. Lastly, the conversation includes a look to the future of Andrew’s scientific work and podcast as well as his unique approach to communicating science and tackling the issue of scientific illiteracy.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/andrewhuberman/the_Drive_public.png)

Play

#249 ‒ How the brain works, Andrew's fascinating backstory, improving scientific literacy, and more | Andrew Huberman, Ph.D.

#249 ‒ How the brain works, Andrew's fascinating backstory, improving scientific literacy, and more | Andrew Huberman, Ph.D.

1x15s30s

0:002:50:42

## We discuss:

- Exercise under blood flow restriction, lactate utilization, and transient changes in the brain function in response to adrenaline and stress [3:30];
- The role of the prefrontal cortex in governing rulesets [9:15];
- New discoveries about the circuitry between the prefrontal cortex, insula, and amygdala, and the insights gleaned about brain function in different emotional states [15:30];
- Comparing human vision and other senses to animals [26:00];
- A deep dive into vision: evolutionary adaptations, facial recognition, color, and more [39:45];
- Sense of smell, pheromones, and why evolution developed better vision over smell [46:30];
- The relationship between visual input and time perception [55:30];
- Mindset effects: the effect of belief on physiology and performance [1:00:45];
- Accessing higher levels of creativity with broadening rulesets and the limiting nature of stress and fear on creativity [1:05:30];
- Stress and fear increase autonomic arousal, limit access to rulesets, and inhibit performance [1:12:15];
- Andrew’s upbringing, early childhood, and tough adolescent years [1:15:00];
- Andrew’s time in a residential treatment program and how he benefited from therapy [1:20:15];
- The beginning of positive changes in Andrew’s young life [1:28:30];
- Andrew’s decision to turn his life around [1:37:00];
- A new passion for science and exercise helps Andrew [1:42:00];
- The difference between a postdoc and a PhD [1:54:15];
- Staying in touch with the love of biology and not getting pulled into ambition [1:59:15];
- Andrew starts his own lab, and continues work to overcome his demons [2:07:00];
- The loss of three mentors leads to deep soul searching [2:12:00];
- What motivated Andrew to begin his podcast [2:18:00];
- Looking to the future of Andrew’s scientific work, podcast, and more [2:22:45];
- Andrew’s unique approach to communicating science and the issue of scientific illiteracy [2:30:00]; and
- More.

§

## Show Notes

\***Notes from intro**:

- You may recognize Andrew Huberman, not because he is a professor of neurobiology at Stanford University, but rather because he is the host of the very popular [Huberman Lab podcast](https://hubermanlab.com/)
  - It is probably the #1 podcast in the space of health medicine
- Andrew and Peter are also close friends; he is someone who Peter spends a lot of time talking with
- Going into this discussion Peter put something out to social media that said, “*Hey, I’m going to be talking with Andrew. Shoot me a bunch of topics that people are interested in.*”
  - Not surprisingly, the response was overwhelming
  - Peter came into the conversation with 10-12 pages of notes based on topics that people wanted to talk about ‒ unfortunately, we didn’t get to even one of them
- Instead, we talk broadly about three things
- 1 – We talk about neuroanatomy and a greater understanding of how the brain works and what the rulesets are with respect to thinking and how senses work (hearing, seeing, smelling, etc.)
  - We go through some real basics here; this is an important podcast because Peter doesn’t make the assumption that the listener is familiar with all of these processes around the brain
- 2 – We talk about Andrew and his personal journey from childhood, to his education, to his career, and who the most important mentors were in his life
  - Many people are familiar with Andrew the expert
  - There are few podcasts out there that provide any insight into Andrew’s background
- 3 – We end the conversation on a very important topic ‒ the crisis of scientific literacy and the importance of science communication
  - The latter is something Andrew has done an excellent job of
- We are planning a part 2 of this podcast because of all of the content that didn’t get covered and a few questions that came up during this podcast

## Exercise under blood flow restriction, lactate utilization, and transient changes in the brain function in response to adrenaline and stress [3:30]

**Morning workout**

- Andrew always enjoys seeing Peter, he learns from him; and when he trains with him, he always enters a new pained state
- This morning he warmed up on the assault bike, then started doing some intervals, and he was going to go for a run when Peter suggested [blood flow restriction (BFR)](https://en.wikipedia.org/wiki/Blood_flow_restriction_training)
  - Last time he used the blood flow restriction cuffs on his arms, did some curls with light waits, and those were extremely painful
- This time he put the cuffs on his legs and locally it was less painful; it was more of a whole body pain
  - Pedaling for two minutes at 220 watts with the cuffs on his thighs, he didn’t feel like his legs were going to pop, instead his whole body felt a little bit swollen
  - When you come off of that two minutes and you take the cuffs off, he can’t really describe the feeling ‒ it’s somewhere between bliss, relief, and a supercharge
- He took off for a run feeling more energized than he had in a long, long time
- Peter does this sort of BFR 2-3x a week at the end of a leg workout
- Using BFR cuffs on the arms is different; he suspects because there’s less fat and it’s easier to compress the vasculature so you get more distal occlusion
  - Peter agrees, “*Doing bicep curls with those cuffs on, it is really the definition of hell; and it’s much more of a deep, awful pain in the legs”*
- Andrew enjoyed BRF training; this was his third time doing it
- He noticed that when it’s done on the upper body, the pain can be very localized and it starts to migrate around in interesting ways
- He actually learned a thing or two about the distribution of sensory receptors in the upper body
  - For instance, immense pain in the hands, and then the moment you think you can’t tolerate it at all, it migrates to your shoulder and away from the hands
  - With the legs, it’s more evenly distributed
- He thinks it’s incredible training as long as people don’t try and “cowboy it” and just tie tourniquets
  - You need the proper blood flow restriction cuffs

**Benefits of BFR training**

- Growth hormone increase, minimal soreness despite getting quite a lot of metabolic activity
- It provides less trauma with more metabolic benefit
- One reason Peter likes doing the set Andrew did today is he likes exposing his legs to [lactate](https://en.wikipedia.org/wiki/Lactic_acid#Exercise_and_lactate)
  - The more lactate you’re exposed to, the more [MCT](https://en.wikipedia.org/wiki/Monocarboxylate_transporter) the cells will upregulate
  - Basically you want your cells to become more and more efficient at taking lactate and getting it out of the cell
- Ultimately lactate is an amazing fuel
  - Its role in neurons is just starting to become appreciated
    - We typically think of neurons as only accepting glucose and ketones, but there is emerging evidence that lactate is a fuel
  - Of course the liver can turn lactate right back into glucose via the [Cori cycle](https://en.wikipedia.org/wiki/Cori_cycle)
  - The more efficiently our cells can get lactate out and start processing, the better
- Lactate is not a poison
  - We once thought of lactate as kind of a bad thing
  - It’s only bad if you don’t know what to do with it

**Lactate utilization in the brain**

- Andrew’s understanding of neurons that preferentially use lactate as a fuel, they do so under conditions of **high stress or high exertion** (it doesn’t have to be stressful)
- The **hypothalamus and areas of the brainstem** that control breathing and more primitive functions preferentially utilize lactate first
  - This is evident when you get into an ice bath or any kind of adrenaline shock environment
- The little neuroimaging that is out there tells us that the **prefrontal cortex** essentially shuts down because there’s a preferential shuttling of glucose and lactate to other regions of the brain (simply to keep everything online); it’s not shutting down because of a lack of electrical activity
  - The prefrontal cortex is involved in rule-setting and decision making, but really rule and contingency setting

***Translated into plain English ‒ if you get into an ice bath or get a shot of adrenaline, your forebrain quiets for 20-30 seconds and all the other systems ramp up to provide survival function; then the forebrain can come online***

**The autonomic response associated with hypothalamus and brainstem activation**

- A lot of people feel hijacked by the autonomic response associated with [hypothalamus](https://en.wikipedia.org/wiki/Hypothalamus) and [brainstem](https://en.wikipedia.org/wiki/Brainstem) activation
  - Heart rate goes up, breathing goes up, pupils dilate, tunnel vision;  all of that happens immediately
  - Most people aren’t familiar with those states
- The more familiar we can become with those states and the fact that they are transient, the lower the probability we get hijacked by them
- This is **classic stress inoculation,** but it’s nice to see that nowadays a number of people are doing this outside the military and outside of sports training, and just teaching themselves to be comfortable with that pulse of adrenaline and doing it through deliberate cold exposure or blood restriction cuffs
- Once you feel that first shot of pain, “*How am I going to make it through two minutes of this?*” That’s another place where **you just keep going** and then all of a sudden your brain comes online, then the forebrain comes online

**Peter’s takeaway** ***‒ we evolved to sacrifice the most advanced part of the brain temporarily for the parts of the brain that are absolutely essential (the midbrain, the brain stem)***

- Resources are shunted away from a somewhat gratuitous part of the brain that is the most evolved
- Realize though, it’s using a broad brush when to say that the forebrain shuts down

## The role of the prefrontal cortex in governing rulesets [9:15]

**A powerful discovery made by** [**Nolan Williams**](https://profiles.stanford.edu/nolan-williams)

- The [prefrontal cortex](https://en.wikipedia.org/wiki/Prefrontal_cortex) is the brain real estate right behind the forehead; it’s involved in rule-setting by context
- There’s this classic [Stroop task](https://en.wikipedia.org/wiki/Stroop_effect) ‒  give people a bunch of cards with words or numbers written on them in different colors, and then you ask them to read the words or the numbers (see the figure below)
  - Or you ask them to tell you the colors and ignore what the words say
  - It sounds easy, but it’s actually pretty hard to do when going fast
  - And then you start switching back and forth
  - ***That is a very prefrontal cortex-dependent kind of task***

![](https://peterattiamd.com/wp-content/uploads/2023/04/f1-andrewhuberman-1024x632.png)

**Figure 1. The Stroop task reveals a delay in the reaction time of reading words when the color is incongruent (doesn’t match the word).** Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Stroop_effect)

***The Stroop task reflects the ability to adjust your ruleset depending on what’s demanded of you in the context***

- For example, when Andrew walks in here for a podcast, it’s a very different rule-setting context than when he’s alone at home or when he is engaged in public speaking or or even when he’spodcasting
  - There are slightly different rulesets when you’re a guest versus host of a podcast
  - There are completely different sets when you’re spending time with your children, your wife alone

***Rule-setting and context is completely governed by prefrontal cortex***

**The story of Phineas Gage illustrates the function of the prefrontal cortex**

- Hence the famous case of [Phineas Gage](https://en.wikipedia.org/wiki/Phineas_Gage), a tamping iron, destroyed his prefrontal cortex

![](https://peterattiamd.com/wp-content/uploads/2023/04/f2-andrewhuberman.png)

**Figure 2. The path of the iron rod through Phineas Gage’s skull**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Phineas_Gage)

- Andrew begins this story with a qualification ‒ everyone is obsessed with clinical trials (they are wonderful and immensely powerful), but we have to remember that in medicine (neuroscience in particular), most of what we know about memory comes from one single patient (the famous [HM](https://en.wikipedia.org/wiki/Henry_Molaison)) who had bilateral hippocampal damage
  - Doctors deliberately burned out his hippocampi to offset epilepsy, temporal lobe epilepsy

![](https://peterattiamd.com/wp-content/uploads/2023/04/f3-andrewhuberman-1024x542.png)

**Figure 3. Neuroanatomy,** **Patient HM had most of his hippocampus removed**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Henry_Molaison) & [John Hopkins Medicine](https://www.hopkinsmedicine.org/health/conditions-and-diseases/anatomy-of-the-brain)

- The case of Phineas Gage was a result of an accident
  - He was a railroad worker and they would drive these tamps in with explosives, and he caught one coming up through the base of his jaw, went out through the forehead
  - Somehow it missed the critical vasculature, and he survived
- After the accident Phineas Gage became somebody who did not obey rulesets; he had inappropriate behavior
  - He wasn’t necessarily profane, but he didn’t behave correctly for the context
  - Whereas before he was very well mannered, and he adjusted his behavior according to context
    - When he is out with beers for friends or working on the railroads, he might speak and behave one way
    - When he would go home, he would speak and behave another way, etc.
  - ***He completely lost the ability to switch rulesets according to context***

**The Amygdala**

- Related to this is [Klüver-Bucy syndrome](https://rarediseases.org/rare-diseases/kluver-bucy-syndrome/) (Bob Dylan mentions it in a song)
  - This is characterized by bilateral damage to the amygdala
- Many people think the [amygdala](https://en.wikipedia.org/wiki/Amygdala) is involved in fear, but it’s really a defense and alertness system in the brain
- Monkeys or people who have bilateral amygdala damage, they can still experience certain kinds of fear
  - For instance, drive up CO2 (carbon dioxide) in their environment or make them breathe pure CO2 and they will panic, but they become unafraid of things like snakes (if previously they were afraid of snakes)
  - They become kind of sexually and food inappropriate
    - They’ll pick up a pen and start to gnaw on it, maybe taste it.
    - They will try and copulate with various inanimate objects
  - So there’s this kind of bizarre lack of context

**We think of the prefrontal cortex as this very evolved structure**

- It is intimately involved with the [limbic pathway](https://en.wikipedia.org/wiki/Limbic_system); it’s what we call mono-synaptic
- Peter asks, “*So it’s less evolved than the top of the cortex, the neocortex?*”
- The whole dating of cortical areas is a bit of a controversial thing, but beautiful work by [Arnold Kriegstein](https://neurograd.ucsf.edu/people/arnold-kriegstein-md-phd) at UCSF has focused on this using carbon dating as a way to approach this
  - They’ve looked at brains from different species and are starting to establish homology from a macaque to a baboon to a human
  - It’s hard to study homology and evolution of the nervous system because there is no fossil record
    - The skull is preserved, but the brain degenerates and disappears
- The two ways you establish homology come from development
  - 1 – Developmental position ‒ for example, if you look at the hippocampus (an area associated with memory) in a mouse versus a  human
    - In the mouse, the hippocampus is up near the top of the brain
    - In a human, it’s down near the bottom
    - And you say, well, how can those be the same structure?
    - If you look during development, they start off in the exact same place
    - In the human brain, because it has so much neocortex (the outer shell), the whole thing starts moving and moving and moving, and it ends up down there at the bottom
  - 2 – Connectivity ‒ for example, we know that the prefrontal cortex and amygdala are monosynaptically connected (there’s just one synaptic connection; it doesn’t go through a network)
    - If we were to put an anatomical tracer into the amygdala, to the prefrontal cortex, you would see direct connections between those two structures, and you would see connections with intervening structures
    - Ultimately in the brain, everything is connected to everything; just like on Google Maps, everything is connected to everything, even if it’s by way of ocean
  - The presence of a monosynaptic connection (one connection or direct connection), or even a disynaptic connection (where there’s an intervening connection, but only one), is an important criteria for establishing homology because what it really says is that it establishes very fast communication between structures
  - The brain is so metabolically demanding in general that we assume evolution did not introduce a lot of extraneous wiring

## New discoveries about the circuitry between the prefrontal cortex, insula, and amygdala, and the insights gleaned about brain function in different emotional states [15:30]

- So when we think about prefrontal cortex, it’s role in executive function, complex rule-setting, contingencies, we think it must be very evolved
- This is the region of the human brain that’s expanded relative to other primates and other species
- But it’s involved in some primitive stuff as well, not just by way of connectivity, and this brings us back to the [Nolan Williams](https://profiles.stanford.edu/nolan-williams) discovery
- The [prefrontal cortex](https://en.wikipedia.org/wiki/Prefrontal_cortex) is involved in rule-setting and contingencies
- The [amygdala](https://en.wikipedia.org/wiki/Amygdala) and associated structures are involved in threat detection
  - The response is kind of generic ‒ they raise heart rate, they raise awareness, they change the visual system, and they tune your auditory system to localize things as opposed to paying attention to everything in your environment
    - Imagine the cone of attention, the so-called “cocktail party effect” ‒ you’re trying to hear a conversation in particular, not listen to just the buzz and the clinks of the glasses and stuff in the room
- The [insula](https://en.wikipedia.org/wiki/Insular_cortex) is also in that circuitry involving prefrontal cortex and amygdala
  - The insula has a map of the body surface and the internal organs
  - It is essentially controlling [interoception](https://en.wikipedia.org/wiki/Interoception) (at least in one region), which is our perception of everything that’s happening within our body, our perception that our heart rate has increased or decreased, our perception that our blood pressure is dropping, our perception that our gut feels acidic or full or empty, etc.
  - Peter asks, “*What’s the physical size of this region?*”
    - It is fairly expanded in humans, but Andrew would have to check
    - It’s going to be larger than a few millimeters
  - It’s small, but it contains a complete map of the internal body surface, and it’s in a position to integrate information about the outside world and rulesets and internal state ‒ they all converge there
- Under conditions where we are rested, we are feeling rational, we understand the environment, we feel in control of things, **the prefrontal cortex leads activation of the amygdala and the insula**
  - In other words, Andrew can say, “*Okay, my heart rate’s going up a little bit, but I’ve done a podcast before. I can get comfortable here*.”
  - Someone who’s never done public speaking, if they get out on stage and they’re feeling their heart rate going up and they’re thinking, “*Oh my God, I’m going to pass out, or I’m going to say something ridiculous*,” and they’re panicking; Andrew asks, “*What happens here?*”

**Nolan’s lab and others have shown that now the insula activity and the amygdala starts leading the ruleset of the prefrontal cortex**

- In other words, the coach now becomes the player, the trainer becomes the trainee
- It’s literally an inversion, instead of it going prefrontal cortex to insula leads amygdala, it’s insula and amygdala lead prefrontal cortex
- And so the prefrontal cortex doesn’t shut down completely under conditions of say getting into an ice bath or panic
- The prefrontal cortex can only access one or two very specific rulesets

***In times of stress, you lose flexibility of thinking***

- This is kind of a duh when you hear it, but the fact that neuroscientists are finally identifying the underlying neurology is very exciting
- Because what we’re talking about is that neural circuits can run in both directions
- We had always thought it was, this activates that, activates that in a kind of a chain of events
  - But it can run in the other direction too

**Are you saying that the action potential moves in the other direction, and the neurotransmitters are actually released on the other side of the synapse?**

- No
- All these structures are reciprocally connected
- So we haven’t changed anything about the underlying cell biology, about the axon propagating down the axon
  - The action potential propagating down the axon and transmitter release
- It’s just that it’s a **two-way highway**
  - And suddenly, if everything was running *north to south,* when we are in our rational mind, creativity, all of those things under conditions of calm, as soon as a certain level of internal discomfort arises, everything starts running *south to north*

**This is exceedingly interesting because it means**

- 1 – Neural circuits are not just all the classic lesion data
  - You lesion a structure, like you remove some prefrontal cortex (like the Phineas Gage example), and you can start to see why that’s a cool, naturally occurring experiment
  - You’re just getting an impression of what happens when you blow up one city along this map
  - ***It doesn’t tell you anything about the direction of flow of information in and out of that map***
- The more we learn about the prefrontal cortex and these other structures (like the insula), the more we start to understand that the brain has neurons, and we have what are called **receptive fields**
- Receptive fields are basically the way in which specific neurons are activated by specific events in the world, either in our bodies or outside our bodies
- Those receptive fields are very dynamic depending on context
- While the brain has all this diversity of response, it’s not infinite; we have modes that we sort of fall into bins of **autonomic arousal** (levels of alertness) in the context of sexual arousal or hunger (it doesn’t always have to be stress)
  - In one of these contexts, the ruleset becomes very, very narrow ‒ it’s find food, it’s have sex, it’s find a safe place to fall asleep
- In contrast, **when we are rested and we have our basic needs met**, this opens up the opportunity to start thinking in new and novel ways
  - It’s like taking the Stroop task to the extreme
  - It’s 2023, what is the metaverse going to look like? What’s going to happen to Twitter? What’s going to happen to the economy? What’s going to happen to public health?
  - And so you can start thinking, ***what you can start doing is combining different rulesets and evaluating those different rulesets***
- Andrew believes this is one of the reasons why many **people experience their best ideas** from doing a lot of structured thinking, but also from taking a walk and all of a sudden an idea comes to us, or in the shower
  - When we aren’t focusing on the implementation of a specific ruleset it’s very clear that ***the prefrontal cortex has this ability, depending on what else is going on in our body, to start swirling and combining these different rulesets***
- Andrew and Peter are both fascinated by high performance (for example [F1](https://en.wikipedia.org/wiki/Formula_One_racing)), but at the start of any performance there’s the classic laddering up of unskilled, then skilled, then mastery
  - And then this thing that we love to observe, which is virtuosity, is this combining of rulesets in a way that it seems even the performer didn’t even realize was possible

**The work of** [**Nolan Williams**](https://profiles.stanford.edu/nolan-williams) **has taught us about this whole prefrontal cortex, insula, amygdala circuitry**

- When people are in states of calm, and certainly in states of what we consider mental health, *things run north to south, prefrontal cortex downward*
- People who are depressed have deficits in activation of particularly the left dorsal lateral prefrontal cortex, and much of their thinking and their life is *run from the insula and amygdala up to the prefrontal cortex*
  - And this is why people wake up thinking, “*I don’t know how to accomplish anything today. There’s no point in trying.*”
  - ***Their rulesets seem like they don’t work because they are only able to access specific rulesets of thinking***
  - Meanwhile, the rest of us say, “*Well, hey, get some exercise and apply for a job, look for a new relationship,*” but these rulesets are not available to depressed people
  - It’s almost like depressed people can’t see the play board in the same way
- Nolan’s lab has been using [transcranial magnetic stimulation](https://en.wikipedia.org/wiki/Transcranial_magnetic_stimulation) to activate (not inhibit) the left [dorsal lateral prefrontal cortex](https://en.wikipedia.org/wiki/Dorsolateral_prefrontal_cortex) in particular, and he sees that all of a sudden people have **new ideas about rulesets** revealed to them ([published in *The American Journal of Psychiatry*](https://ajp.psychiatryonline.org/doi/10.1176/appi.ajp.2021.20101429))

**Is the idea there that if you stimulate and activate and send the current back north to south, it automatically reduces the south to north or just overwhelms it?**

- Most likely it overwhelms it, and with time, it creates neuroplasticity that reduces it
- This seems to happen by temporarily shutting down people’s interoception
- We think so much about how it is important to be connected to your body
  - For many people, their entire life and experience exists from the neck up and the waist down

**Interoception is a double-edged sword**

- People who have extreme levels of interoception can reliably feel and count their heartbeats without taking their pulse or using a heart rate monitor (you can be trained to do this)
  - These people have very high levels of **insula activity**
- There are subregions of the insula that are particularly sensitive to internal state; other regions of the insula are tuned to other things

**Is bowel pain perceived in the insula?**

- Peter is thinking of the feeling of having a stomach bug or something worse like extreme constipation or a small bowel obstruction
- The innervation of the small bowel is insane; we are able to detect pain at even a modest amount of stretch

***The answer is yes; the insula is going to a primary site for delivery of somatic sensation to the brain***

> “*I’m very, very open to the idea that the body plays an important role in all things health and perception, but there is something particularly important about the real estate in our skulls.*”‒ Andrew Huberman

## Comparing human vision and other senses to animals [26:00]

**Where in the body is the sense of who you are?**

- There is something particularly important about the real estate in our skulls
  - You could amputate all four of my limbs, that would suck for me, but I’d still be Andrew
  - “If you take out one square millimeter of my prefrontal cortex, the chances are I’m going to be a very different person”
  - Now, that is not true if you remove one square millimeter of a different brain area
    - The last place I would ever allow you to take a square millimeter of neural tissue is my neural [retina](https://en.wikipedia.org/wiki/Retina)
    - Peter would have guessed the hippocampus; Andrew replies “*There are a few things I’d like to forget*”

**Vision**

- Andrew doesn’t care to much about [peripheral vision](https://en.wikipedia.org/wiki/Peripheral_vision), although you use that when you’re driving
- A lot of people think you use [foveal vision](https://en.wikipedia.org/wiki/Fovea_centralis) (central vision) for driving, but there are many people driving out there who are legally blind in their central vision
  - They aren’t great drivers, but they are decent enough to pass the driving test
  - There are a lot of legally blind people driving

**You would prioritize vision over any other part of your brain?**

- Absolutely
- Except perhaps the [motor cortex](https://en.wikipedia.org/wiki/Motor_cortex)
- If you look at the allocation of real estate in the human brain, it’s very clear that vision and movement dominate most of the requirements
  - Sensation and the [homunculus](https://en.wikipedia.org/wiki/Homunculus#Philosophy_of_mind) are also enormous

**The** [**occipital cortex**](https://en.wikipedia.org/wiki/Occipital_lobe) **is responsible for vision, on a neuron basis what % is it of total neurons? Would you include glial cells?**

![](https://peterattiamd.com/wp-content/uploads/2023/04/f4-andrewhuberman-1024x721.png)

**Figure 4. Major lobes of the human cerebral cortex**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Occipital_lobe)

- Yes, we should include the glia ‒ Andrew pays homage to the great [Ben Barres](https://en.wikipedia.org/wiki/Ben_Barres), his postdoc advisor and Peter’s former instructor at Stanford

***In terms of strict volume-based real estate, the amount of the human brain allocated for vision and vision only as well as neurons that are responsive to visual stimuli, this is 40-42%***

- Areas of the auditory cortex are also responsible for vision
  - If you hear something over to your left, you tend to look left; there’s integration (what we call multimodal neurons)
- Multimodal neurons have auditory and visual receptive fields; they can be activated by auditory and visual cues
- Peter finds this amazing

**Different senses are heightened in different animals**

- One of the things Peter enjoys about bow hunting is the ability to observe other species and how they have different superpowers from us
- Axis deer and elk have incredible hearing, but their sense of smell is next level (we don’t have a way to comprehend it)
  - Someone described their amazing sense of smell with this analogy
  - If you were to come across an animal that had been killed, and it was mostly still there and rotting, when you are within 10 feet of it, it would smell rancid beyond words
  - This is what we smell like to an elk a mile away
- We always hear that sharks can smell a drop of blood in the water from a mile away, but it’s hard to imagine what that is
- There is a beautiful book about animal behavior and perception called [*An Immense World*](https://www.amazon.com/Immense-World-Animal-Senses-Reveal/dp/0593133234/ref=sr_1_1?crid=2B5DOQDNMTDK8&keywords=an+immense+world&qid=1676658267&sprefix=an+immense+world%2Caps%2C111&sr=8-1) by Ed Young; it’s all about the sensory specializations of other animals
- Peter’s point is that the only sense we have that seems to rival animals is vision

***It’s interesting to think that so much of the real estate of our brain is assigned to vision; the olfactory neural component is minimal in comparison***

- The volume of real estates is not always the best indicator though

**A lot of mistakes were made in the early days of neuroscience because of looking at the # of neurons / # connections**

- A good example would be the [Raphe nucleus](https://en.wikipedia.org/wiki/Raphe_nuclei) of the brainstem manufacturers [serotonin](https://en.wikipedia.org/wiki/Serotonin)
  - It sends an enormous projection to the [circadian clock](https://en.wikipedia.org/wiki/Circadian_clock) of the [hypothalamus](https://en.wikipedia.org/wiki/Hypothalamus)
  - There have been dozens of experiments evaluating the role of serotonin in that pathway and its ability to shift the circadian system, and so far it seems like it has barely any influence
    - We assume it’s doing something, but it’s not doing anything obvious based on the experiments that have been done
- You’ve got to be a little careful in any description about animals and the natural world and vision, because this could end up being a 15 hour podcast
  - Andrew turns into the six-year-old version himself (he was obsessed with learning about animals)

**Putting sensory experiences in perspective**

- To get a sense of how well we see relative to other animals, if you were to hold out your thumb at arms distance, if Andrew were to draw 60 black lines separated from one another on your thumbnail, you would be able to perceive that
  - We call that being able to measure 60 **cycles per degree**, cycles of black, white, per one degree of visual angle
  - You can’t count the 60 lines, but you can recognize that they are discrete lines; this is normal for people with 20/20 vision
- A raptor bird like a red tail hawk sees at 120 cycles per degree
  - That means they can sit up on a light pole and look down at the ground and see a small gopher raise its head in the ground (they’ll perceive it)
    - They might not be able to count the whiskers on that gopher’s face
- We have a [pupil](https://en.wikipedia.org/wiki/Pupil) and a [fovea](https://en.wikipedia.org/wiki/Fovea_centralis) behind that (see the diagram below)
  - A fovea actually means a pit
  - The fovea is a concentration of retinal cells that allows us to see at highest acuity in the central vision
    - How do we know this?
    - You can put your hand out to the side and you know your fingers are waving off in your periphery
    - You can see that they’re moving, but you can’t really count them
    - As you move your hand in front of your face, you can count the fingers

![](https://peterattiamd.com/wp-content/uploads/2023/04/f5-andrewhuberman.png)

**Figure 5. Schematic of the human eye indicating the fovea**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Human_eye)

- We have more pixels in our central vision than in peripheral vision, but only in the center, and it’s circular
- Red tail hawks have a fovea, but other types of raptors have another fovea that views the floor (such as a diving bird)
- Birds that fly along the ocean have a horizontal visual streak that allows them to view the horizon; and what we consider central is their peripheral
  - They also have a fovea because they need to actually dive into a school of fish and capture a fish while adjusting for the [refractory index of the water](https://en.wikipedia.org/wiki/Refraction#Refraction_in_a_water_surface)
    - An example to understand refraction of light in water ‒ if you ever reach for a coin at the bottom of the swimming pool, it’s only when you get very close that you realize you were off by a few centimeters
  - These birds do this incredible feat by distributing the high pixel region of their retina to a visual streak and down below of fovea
- The sloth that hangs upside down has its fovea on the top of the eye so it can view the jungle floor
- Andrew’s favorite example of this is the J-shape, high density, high pixel concentration of the retina of the elephant so that it can view the trunk and the tip of its trunk
  - It has to make very high acuity placement of the trunk in order to eat properly
  - This is not really a fovea

***Nature has evolved all these incredible retinal specializations, and all have differences in acuity and distribution of what they see in the world***

- Sheep need to see the horizon and be aware of predators, but they also need to pay attention to what they’re eating
  - Peter recalls friends who have hunted sheep in North America say that if you break horizon out to five miles, the sheep will see you
  - A guy down in Australia for years named [Jack Pettigrew](https://en.wikipedia.org/wiki/Jack_Pettigrew) did tons of beautiful experiments on animals like sheep and goats, and they have incredibly high acuity vision, but for very select regions of visual space
  - They have a visual streak that is not straight across the eye
  - The sheep doesn’t know that Peter and his friends are creeping up on them on the horizon, they only see a deflection of something in their visual field

***The point being one universal truth of all of this is that the retina and the visual system is most sensitive to motion***

- There’s a very fast pathway that goes from the retina to a brainstem structure called the [superior colliculus](https://en.wikipedia.org/wiki/Superior_colliculus) that immediately engages the orienting reflex
  - It’s not even conscious
  - It’s not a decision-making process
  - If something moves in the periphery, and the signal to noise is great enough that we (or an animal) orient towards it

**Are we more sensitive to the sound or to something moving in our periphery?**

- Visual periphery moving, though there are exceptions
- For instance, watch the [Nature is Metal channel on Instagram](https://www.instagram.com/natureismetal/?hl=en) ‒ there are gruesome examples of lions hunting
  - They move very slowly and they learn that they become invisible to prey when they are *not* moving

- If you were to eliminate all your retinal movements and you’re looking right at Andrew, he would disappear
- You’re making little [microsaccades](https://en.wikipedia.org/wiki/Microsaccade) all the time that prevent the habituation of the neurons that would otherwise erase your visual perception of whoever is in front of you
  - The retina has little microsaccades (basically a little tiny jitter) that prevents the habituation of the neurons in the visual system from essentially losing the perception of what’s in front of you
- Experiments have been done ‒ eliminate these little microsaccades and you would become invisible to me
  - The only way Andrew would see you is if he moved his head or his eyes in a bigger eye movement
  - These experiments were done by [Hubel](https://en.wikipedia.org/wiki/David_H._Hubel) and [Wiesel](https://en.wikipedia.org/wiki/Torsten_Wiesel), [Nobel Prize winners](https://www.nobelprize.org/prizes/medicine/1981/summary/) for a number of different aspects of vision
  - You can do this by giving the toxin [Curare](https://en.wikipedia.org/wiki/Curare) to eliminate the small muscle movements of the eye (temporarily paralyze these muscles)
  - There are some other drugs that you can use that tap into the cholinergic system

**Getting into the realm of sensory perception**

- If your hands are on your thigh, you can habituate to that
  - Some people call it attenuation, habituation, adaptation
  - Smell is another example, if you walk into a dentist’s office, the smell of the dental cement makes you want to vomit, but a couple minutes later you don’t notice it because the olfactory neurons habituate

***Because the nervous system mostly runs on a signal to noise over time algorithm***

## A deep dive into vision: evolutionary adaptations, facial recognition, color, and more [39:45]

**Examples of visual adaptations**

- There is rapid plasticity in terms of adaptation
- If you go into a fun house mirror type environment, that’s more of a visual proprioceptive feedback, where at first you feel kind of wobbly and then you can move
  - You’re like, “*Oh, when I see myself move that way in the mirror, that’s not really how I need to respond.*”
  - At first you feel a little off balance, but there’s very fast adaptation
- Here is a wild experiment ‒ you put glasses on somebody that inverts the visual world
  - That’s got to throw off your day.
  - But within four hours you’re navigating just fine
  - What happens? The receptive fields invert and all of a sudden you see the world right side up (it flips)

**What happens at the cellular level to enable that?**

- This has been studied by [Tomaso Poggio](https://mcgovern.mit.edu/profile/tomaso-poggio/) and others and it’s still somewhat of a mystery
- It appears to be mediated by **bottom-up changes**, meaning it is shifts in the ocular motor and visual motor structures of the brainstem communicating with the higher level perceptual centers of the cortex
  - Remember, if we were to splay out from most primitive to most evolved functions within vision, and we can make up “just so” stories
  - Andrew is joking, he wasn’t consulted  in the design phase, so he don’t know the logic
    - By the way, anytime someone asks you, “*Why is something this way?*” The response should be, “*I wasn’t consulted in the design phase*”
    - Andrew borrowed that phrase from [Russ Van Gelder](https://ophthalmology.washington.edu/faculty/russell-n-van-gelder-md-phd) who’s the chair of ophthalmology at University of Washington (thank you)
    - This simply captures the fact that you can come up with “just so” stories
- What we know for sure is that based on genetics and cellular architecture, that the primary function of the visual system was not to see and perceive things
  - It was to recognize when it’s daytime and when it’s nighttime (we’ll come back to this)
  - The neurons that handle this are the so-called [melanopsin and intrinsically photosensitive ganglion cells](https://en.wikipedia.org/wiki/Intrinsically_photosensitive_retinal_ganglion_cell), they don’t pay attention to shapes, but they tell the brain when it’s daytime and they tell the brain when it’s absence of light
- This relates to [Satchidananda Panda](https://www.salk.edu/scientist/satchidananda-panda/), [Samer Hattar](https://www.nimh.nih.gov/research/research-conducted-at-nimh/principal-investigators/samer-hattar), [Matt Walker](https://www.sleepdiplomat.com/professor) (all the greats of [Circadian biology](https://en.wikipedia.org/wiki/Circadian_rhythm))
  - This relates to sleep and wakefulness

**The next thing is neurons that can sense contrast and motion**

- More important than knowing that your skin has a particular tone is just knowing that you are there and that you are a moving object, as opposed to stationary objects in the room that I just need to navigate around.
- Then comes shape and form
  - For example, is that a fish that I want to move away from or do I want to approach and eat? Is it bigger than I am? Is it smaller than I am? These kinds of things
- Then comes color of the more traditional sort (we’ll come back to this)

**The final category is specific features of shape, such as your face**

- I recognize your face or JFK’s face or Marilyn Monroe’s face
- There’s an area of the brain called the [fusiform face gyrus](https://en.wikipedia.org/wiki/Fusiform_gyrus); it lies way up along the visual pathway (meaning very far from the retina), but neurons there are exquisitely tuned to specific faces
  - If you lesion that area, people become what’s called [Prosopagnosia](https://en.wikipedia.org/wiki/Prosopagnosia), where people know they are looking at a face, but they don’t know whose face it is
  - [Ben Barres](https://en.wikipedia.org/wiki/Ben_Barres) had a mild face recognition deficit; Andrew would sometimes walk into his office and he’d mistake him for Challa (a woman that worked in the lab)
    - Now that kind of question might have been more context-appropriate given that Ben was transgendered, so maybe his notions of gender and faces were a little bit intermixed
    - But we don’t think that people who are transgendered perceive other people as different genders
- This brain area controls recognition of facial identity; it’s a very high-level function
- There are extreme examples ‒ a lesion where you can’t recognize anybody or there are also super recognizers
- We are at the point now where machine learning and AI is getting better than many humans at face recognition
  - 10 years ago, 15 years ago, retinal scans existed, but nothing like the ones they have now
  - For example, face recognition on your phone for getting into your bank account
- Monkeys, macaque monkeys, old world primates also have this fusiform face area
  - This is largely the work of [Nancy Kanwisher](https://mcgovern.mit.edu/profile/nancy-kanwisher/) at MIT
- For years it was debated. “I*s this a face recognition area really? Or is it just recognition of two dots in a line?*”
  - If I draw two dots in a line on a piece of paper, and you say, “*That’s a face*.” If I curl that line upward a little bit, you say, “*It’s smiling*.”
  - If I turn it upside down or I put it at 90 degrees, it does not look like a face
  - So the neurons in this area are amazingly tuned to specific features

**Color vision**

- Your dog sees you in brown/red/orange-ish tones, not the colors we see
- A mantis shrimp sees 60 different variations of red that we can’t even perceive
- All of that suggests that color vision was a late evolution in the visual system
  - And indeed the genetics of the [photopigments](https://en.wikipedia.org/wiki/Photopigment#) in the eye argue that’s true
  - Photopigments absorb either the red, green, or blue, meaning long, medium,  and short wavelength lights (not really red, green, or blue)

## Sense of smell, pheromones, and why evolution developed better vision over smell [46:30]

- Peter asked earlier whether or not our olfaction is diminished
  - Beautiful work by a couple, [Samir Deeb](https://medgen.uw.edu/news/memoriam-samir-deeb) and his partner at the University of Washington, showed that if you look at human genomics, that humans traded out diversity of olfactory receptors (the ability to sense a rich array of scents compared to other animals) for evolution of that long-wavelength red photo pigment

***So trichromacy, this ability to perceive in the color ranges that we perceive, is a late stage evolution, and we traded out olfactory ability for that***

**Why did we trade out olfactory ability for color vision? Is it literally a brain real estate question? Is it a metabolic question?**

- To be fair to the [olfactory system](https://en.wikipedia.org/wiki/Olfactory_system) and the [vomeronasal system](https://en.wikipedia.org/wiki/Vomeronasal_organ), smell is incredibly important for humans
  - Anyone that got COVID and couldn’t smell for a day (like Andrew), that sucked
    - Andrew remembers biting into a handful of blueberries and he couldn’t taste it very due to the lack of smell
    - Taste and smell are intermeshed
    - He thought, “Oh my goodness, my life isn’t over. But this really sucks. This is not pleasant at all. These taste like little bags of water.” And he loves blueberries
- We are sensitive to the smell of vomit, disgust
- We are sensitive to the smell of our romantic partners; we tend to like that smell
- The debate between odors and pheromones, pheromone effects in humans are present

**What is the definition of a pheromone?**

- A [hormone](https://en.wikipedia.org/wiki/Hormone) is a chemical released in one location in the body that can act at that location and many other locations, so-called [endocrine signaling](https://en.wikipedia.org/wiki/Endocrine_system) (or [paracrine signaling](https://en.wikipedia.org/wiki/Paracrine_signaling))
- A [pheromone](https://en.wikipedia.org/wiki/Pheromone) is a chemical released by one organism that can act on the physiology of another organism

**Can we capture the molecular structure of a pheromone? For example, a pheromone released from the nape of your child’s neck (someone you can smell, someone you love)?**

- The presence of true pheromones in humans is still debated because the so-called accessory olfactory system that governs that hormonal response in other animals
  - There’s an organ in the human nose called [Jacobson’s organ](https://en.wikipedia.org/wiki/Vomeronasal_organ) that is thought to be the vestigial pheromonal organ; that’s debated
- But what is absolutely clear is that the scent, the conscious perception of a scent has dramatic effects on our physiology
  - There’s a direct wiring from the olfactory system

***These are odor effects not pheromone effects***

- The idea of a chemical coming off of your child and going through the vomeronasal system and impacting these aspects of self-[oxytocin](https://en.wikipedia.org/wiki/Oxytocin) release, probably [dopamine](https://en.wikipedia.org/wiki/Dopamine) release, all sorts of wonderful things, that’s debated
- What is absolutely clear though is that that specific scent clearly is perceived and registered by you and has an impact on your physiology

**What is the connection?**

- It is a molecule traveling into the nose and impacting the deep [limbic cortex](https://en.wikipedia.org/wiki/Limbic_system)
- You’ve got a [six layered cortex (neocortex);](https://en.wikipedia.org/wiki/Neocortex) it’s thought to be more evolved
- The limbic and [piriform cortex](https://en.wikipedia.org/wiki/Piriform_cortex) have fewer layers
- The [hippocampus](https://en.wikipedia.org/wiki/Hippocampus#Anatomy) (the memory center) is actually three layers
  - It’s cortical; it’s not what we think of as neocortex
- It’s very clear from the work of [Richard Axel](https://zuckermaninstitute.columbia.edu/richard-axel-md) and [Linda Buck](https://www.fredhutch.org/en/faculty-lab-directory/buck-linda.html) and others, that the smell of your child’s head and neck is perceived and impacts specific neurons in these more “primitive” brain areas
- And there are many automatic (innate) as well as learned responses to that, such as the desire to focus on their needs instead of your own is odor-driven

***Whether these responses to your children are pheromone-driven is a little like splitting hairs; it’s debated; olfaction is absolutely powerful for humans***

- But of course, you can lose your olfaction and still function just fine
- Pheromone effects are very powerful in other animals and you see analogs to them in humans

**Unique aspects of the human visual system [50:45]**

- One of the reasons we think that the visual system is so dominant is that it allows us to function based on perception of things at a distance
- The olfactory system requires fairly close-range contact
- We think of binocular vision (using both eyes) as creating a coherent picture
- Elk and many other animals that are olfactory driven can sense odor plumes (cones of odor)
  - This switches between their different nostrils and allows them to distribute odor plumes
  - They can geolocate and track three or four young (or hunters) simultaneously through odor plumes
- It sounds crazy, but we do this all the time; it’s called [covert attention](https://en.wikipedia.org/wiki/Attention#Overt_and_covert_orienting)
  - This is the phenomenon of being at the bar and you’re talking to somebody, but you’re actually checking out somebody else at the bar or somebody walks in who you really dislike or like, and so you’re pretending to have a conversation, but you’re really paying covert attention
- Animals like elk can create and split multiple cones of odor attention
  - They can also perceive depth with their odor plumes
  - The concentration of an odor would fall off with distance
- We do this with our visual system, obviously things on the horizon
  - You watch a plane fly overhead, it looks like it’s slow
  - If you’re right up next to it’s going to go blazing past
  - Or consider F1 racing, Andrew thinks, “*Why are the cars driving so slow? I thought this was car racing*,” but then they come by and it’s incredibly fast
  - That captures the relationship between visual perception and time perception where the same thing at a distance appears to move slowly (we’ll come back to this)

- Andrew’s favorite example of this ‒ go to New York City, get up in a skyscraper, look out the window and people below look like little ants moving around kind of slowly
  - Then all of a sudden, look at something in your room and all of a sudden things are moving really fast because they’re close
- Other animals do this with their odor plumes, which is insane because it’s not our experience
- Also insane ‒ a pit viper sees in the infrared and can sense your heat emissions in the same way as sensing movement is sensing vectors of movement

**What was the limit for us not to have all of these super senses?**

- Presumably there were variants of us that were randomly occurring that had those skills, and they got outcompeted by people who had greater and greater visual acuity
- Is it a problem of running out of real estate inside the cranium?
  - And if so, why not get a bigger cranium? Neanderthals had bigger cranium
- Andrew thinks this is unanswerable, but it’s a fascinating question
- Also fascinating is that we have vestigial pheromonal organs
- Or that we have an olfactory system that can be used to a greater degree than we do rely on it

**Humans can be trained to enhance olfactory perception**

- Andrew is a huge fan of the work of [Noam Sobel](https://www.sfari.org/people/noam-sobel/)
  - He used to be at Berkeley and now he’s in Israel
  - When Andrew was at UC Berkeley, he used to see people doing experiments where they would put gloves and goggles, occluding goggles, and all sorts of stuff to block hearing and touch and vision, and Noam taught people to follow odor trails of chocolate and distinguish between different odor trails
    - People can learn this; you can devote more resources to it

***In terms of the limit for super senses, Andrew thinks the most straightforward answer is likely that we traded out space (less space devoted to olfactory perception and more space devoted to visual perception)***

## The relationship between visual input and time perception [55:30]

- There is something important about that relationship between vision and time perception
  - At some point in human evolution, whether or not it was through the visual system or through the prefrontal cortical mechanisms, something very special happened for old world primates and us in particular
  - Andrew thinks this is what sets us apart from all the other animals, and it is the reason that we are the curators of the earth and not other species
- We have a greater duration of time in our lifespan in which we can engage neuroplasticity (the ability to deliberately change our neural architecture through learning)
- Our perception of time ‒ we developed the ability to divorce from memories of the past and experiences in the present and also anticipate experiences in the future
- Andrew doesn’t know about animals (because he’s not in the elk’s mind or the mind of a turtle), but everything that we know about their sensory life and perception says that they have memories
  - This whole notion of a goldfish not having a memory is the stupidest thing he’s ever heard
    - First of all, the experiment’s never been done
    - Second, the goldfish has to swim in circles. Who decided it forgot?
    - They can remember food is over there
  - Animals cache food for the winter and go back to those cache sites
    - Squirrels have an incredible memory of location and landmarks and all this stuff

> “*We have a memory of past, we have perception of present, but we also can think about how past and present relate to anticipation of future events. And that places us in an incredible arena of interaction with the natural world, where we can make plans in very specific ways*.” —Andew Huberman

**Andrew’s takeaway on our dependance on vision**

- Andrew thinks our ability to be so dependent on vision, and the fact that our visual system has this aperture, we can view broad swaths of our visual environment and we can carve up time in very broad bins
  - Think about the plane flying slowly, or we can narrow our visual aperture
  - We could go outside, find a little ant hill and we could pay attention to all the micro-movements of that and focus on that for a couple of hours
  - We can narrow our visual aperture
  - Stress or excitement will narrow our visual aperture
- Remember the prefrontal cortex has different rulesets associated with different internal states
  - That also relates to different modes of visual perception
- At some point in human evolution, some ancient version of ourselves figured out how to see into the future
  - Obviously, not directly
  - But we anticipate the rulesets of events that are still yet to come
  - Other animals, if they do that, they don’t seem to actualize on that ability
    - Andrew had this bulldog for years and he loved chasing rabbits, but he didn’t wake up on New Year’s Day and say, “*Okay, 50 rabbits this year.*”
    - And if he did, he never actually succeeded in making a good plan to execute that

**How could we test that hypothesis?**

- Andrew doesn’t know
- What he does know is there are certain states (including dreams, the [liminal state](https://www.merriam-webster.com/dictionary/liminal) between waking and sleeping) when we are completely devoid of external visual input
  - This is also true in certain psychedelic states
  - And space and time become not normal
- First thing we learn is objects fall down, not up
  - We learn, these are our caretakers, and when I feel stressed, I don’t know that I need to have my diaper changed, I just scream, my diaper gets changed (hopefully)
  - Those are the rulesets that we come into the world with, early rulesets
- But then at some point our rulesets become very constrained by our immediate experience and by past experience, like, “*Oh gosh, that teacher is not nice, that babysitter is*…”

**This is the whole thesis of the** [***Matrix***](https://en.wikipedia.org/wiki/The_Matrix)**, Neo having to unlearn the constraints of the Matrix**

- Andrew agrees
- And then at some point, the prefrontal cortex, not us consciously, but the prefrontal cortex learns, “*Ah, there’s the possibility, for instance, of birds fly, we don’t fly, but that I can throw a stick. But what if I could throw a stick with…*” and maybe somebody hung some leather ornaments on that stick and figured out they could throw it a little bit further and a little longer
  - The experiments have to be done in the present, of course
  - Andrew thinks it’s these experiences of vision that are outside the realm of normal experience

***The evolution of our species suggests we can do this, and we don’t see that complexity of behavior/ planning in other species, and this relates to neuroplasticity and self-knowledge***

- We’re getting into the abstract and we’re certainly not getting into the realm of laboratory experimentation and having proved any of this

> “*But if I were to put it simply, I think the evolution of the visual system allowed us to think in different time domains*”‒ Andrew Huberman

## Mindset effects: the effect of belief on physiology and performance [1:00:45]

**Experiences in dreams can allow you to access new rulesets**

- Andrew thinks things like dreaming in liminal states give us access to visual experiences that are impossible in regular conscious, perceptual states
- He had a dream the other day where he was in a taxi and then all of a sudden he was someplace else
  - This is not real
  - But the brain can learn things in those states, it can learn about new rulesets, new possibilities of rulesets

**Can that be harnessed? (the potential to learn of new possible rulesets in a dream)**

- For example, nobody has run a four-minute mile
  - If [Roger Bannister](https://en.wikipedia.org/wiki/Roger_Bannister#Sub-4-minute_mile) had dream after dream of breaking the four-minute mile, do we have reason to believe that that would’ve impacted his physiology and belief system in the way that it did when he actually broke the four-minute mile and all of a sudden, breaking the four-minute mile became a standard occurrence?
- In other words, the ruleset got broken in the real world and that clearly demonstrated a path to progress

*Do we have evidence that, had that ruleset been broken in a dream state, it could have had a similar effect for the first individual?*

- The best evidence Andrew has is the incredible work of his colleague at Stanford, [Alia Crum](https://profiles.stanford.edu/alia-crum)
  - She’s worked on these **mindset effects** or **belief effects**
    - These are different than placebo effects
- Short answer is yes; there are a million examples
- Andrew’s three favorite examples:
- 1 – You give somebody a milkshake, you tell them it’s a low-calorie milkshake
  - You measure things like their insulin, their glucose response, levels of satiety, levels of ghrelin, etc.
  - You give another group the same milkshake, but you tell them it’s a high-calorie shake; take all the same measures
  - You see vastly different responses (published in [*Health Psychology*, 2011](https://pubmed.ncbi.nlm.nih.gov/21574706/))
- 2 – You give hotel workers a little tutorial on the fact that cleaning hotel rooms is boring, but it burns calories and can lower blood pressure and help you lose weight
  - They lose on average between 8-11 pounds in the following three or four weeks
  - You don’t say anything to hotel workers about all the benefits of their work and the exercise that it includes
  - You just tell them that it involves a lot of movement and there will be no consequences
  - ***There’s clearly a mindset effect***
- 3 – Andrew’s favorite example is related to stress
  - You tell people all the negative impacts of stress on memory and wellbeing and immune system
  - Or you tell people true data on the performance-enhancing effects of stress, sharpening of memory, capacity, reduction of reaction time
  - And you see exactly what people believe, what they’re told and what they believe

***You can’t lie to yourself, but what you believe about a given practice strongly regulates the physiology***

- This is interesting in terms of the four-minute mile or other things
- For example, if you tell people that the burn of lactate, or maybe even the lack of sleep that they had the night before, reflects a training adaptation as opposed to overreaching and overtraining
  - You’re going to see very different outcomes
- Ali’s been cuing Andrew to the idea that a lot of the sleep tracking stuff, if you tell people you didn’t have a good night’s sleep, they feel like shit the next day
  - If you tell them they had a great night’s sleep (independent of their sleep physiology), it has an immense impact on their physiology
  - And Andrew is as much a proponent of sleep as the core of mental and physical performance as [Matt Walker](https://www.sleepdiplomat.com/professor) or anyone else (Peter included)

***But what you believe about what you’ve been told has an immense impact on your physiology***

- Andrew uses this to explain some of the battles around nutrition where you hear people saying one thing or another
- There’s a distribution where facts rule and physiology rules, the laws of thermodynamics are intact, but then these **belief effects** can account for (according to [Alia Crum](https://profiles.stanford.edu/alia-crum)) anywhere from 8-20% of the effects of anything, like a food or a behavior
- She actually set out in her thesis at Harvard to study the effects of exercise and her advisor said to her, “*I think all the effects of exercise are placebo.*”
  - It was a prompt to go actually look at that
  - Ali’s an former [D-I athlete](https://en.wikipedia.org/wiki/NCAA_Division_I); she’s also a trained clinical psychologist, and runs a lab at Stanford; she’s one of these superhumans
  - She thought this advice was crazy because exercise changes blood pressure by way of a number of different physiological mechanisms
  - But she went and tested the idea that it’s all placebo, and in fact there is a lot that is placebo; so mindset effects are real in terms of physiology

**Do mindset effects allow people to break mental barriers?**

- For certain things, like sending rockets up to Mars, clearly there’s an engineering feat that has to adapt to the physical world
  - You can’t just will it into existence

***But in terms of what the limits are on human performance and what the limits are in terms of creative endeavors, as far as we know, that’s infinite***

## Accessing higher levels of creativity with broadening rulesets and the limiting nature of stress and fear on creativity [1:05:30]

- A good friend [Rick Rubin](https://en.wikipedia.org/wiki/Rick_Rubin) has a [book](https://www.amazon.com/Creative-Act-Way-Being/dp/0593652886) on creativity coming out
  - Andrew doesn’t want to talk about it because there’s no way he could capture Rick’s brilliance there
- But Rick and Andrew have had a lot of discussions about this and it’s clear that creativity involves combining existing rulesets, but also **coming up with completely novel rulesets**
  - This is something that is a fun space for the philosophically oriented or for the neuroscience oriented or psychologically oriented
  - When was the last time any of us took a walk and thought, “*How do I completely fracture my notions of the rules in a given domain and think about truly new ones?*”
    - It’s hard to do, but once you set the intention around that, Andrew believes that ***when you enter sleep states, the brain tries to solve the most important problems that are happening in your daily life***
- Peter notes, “*There’s something really beautiful about singular focus and purpose in life*”
  - He thinks he talked with Matt Walker about this on the podcast a long time ago
  - For him, some of his fondest memories are in college and medical school where life was remarkably simple
    - No responsibilities
    - He doesn’t possess the vocabulary to describe how much he loved mathematics when he was an undergrad
  - He remembers trying to solve a math problem of integrating the volume of a face and he got stuck on the chin because there wa a dimple there, and he went to bed and actually dreamt the solution
    - He dreamt the function needed to be rotated around a Z-axis to come up with the integral
    - He got out of bed and solved the problem
    - ***Peter thinks this probably doesn’t happen anymore because he’s too distracted; there are too many things he’s trying to do and he lacks that real sense of purpose***
- Andrew adds one way to describe it in the context of the neural architectures they’ve been talking about
  - You have all the necessary **rulesets** to complete all the demands of your daily life, from parenting to podcasting, to running your clinical practice and on and on
  - And so you know how to toggle between those, you know not to apply one ruleset in the wrong context and you just go, go, go, go, go
  - And there’s an energetic cost to that
  - ***When we are singularly focused on one context (even if it’s one conceptual context), you still have the same amount of total neural architecture, but now it’s concentrated***
- Andrew still has images burned in his brain of neural tissue he was viewing with a microscope
  - He can close his eyes and see it
  - He doesn’t have photographic memory
- He used to have an audiographic memory where he could turn on a recorder in his head and then listen back to those conversations later in the evening
  - It was very dangerous to get in an argument with him at that time because he could remember what you said
  - He has lost that ability, but not truly lost it; instead he is thinking about other things
  - That was a useless ability

> “*I think ultimately being fairly narrow context and being able to access these broader rulesets and come up with new rulesets is incredibly powerful*”‒ Andrew Huberman

- There are certain states of body and mind that favor this creativity process
- Even though our ability to be gritty and to survive allows us to access a number of important rulesets, we know (based on the relationship between stress and survival and the prefrontal cortex) that **those rulesets are constrained**
  - If you are in a dangerous situation where you need to protect your family, you are going to figure it out
- There is also a state of love that is associated with **access to a much broader ruleset** and creative ruleset
  - This underlies our evolution as a species
- The number of different things that you can do to access survival if you’re taking care of your family is immense, but the number of different adaptations that you can come up with in order to raise your children to be as happy and healthy as they can be, out of love, is absolutely infinite
  - Why? Because it really is, there’s no other option
  - You’re not fearing death
  - What you’re doing is you’re trying to access this landscape of wanting them to be as great as they can be
  - That’s the **infinite ruleset**
  - Not having constraints on what the outcome is, is really the way to access expanded rulesets
- Now this is getting a little bit circular, and there are philosophers out there who going to nitpick this
- But in discussions with Rick about creativity, and in discussions with Peter and other folks, it’s very clear that accessing these brain centers that have full understanding of internal state, and then full understanding of past, present, and future
  - That is absolutely the best state to be in, in order to access expanded rulesets, and ever expanding rulesets
  - Whereas anytime I’m accessing knowledge about internal state, but it’s constrained by outcome (I need this not to happen), you have already shut down a number of rulesets
- This is why Andrew thinks in dreaming, we aren’t constraining our rulesets
  - It could be a nightmare, it could be the best fantasy we’ve ever had, you can fly, all these things
  - The rulesets are infinite but constrained by experience
- We’re not aware yet that we can dream about things in a way that does not reflect what we’ve already experienced
  - We might be able to, we don’t know enough about sleep and dreaming yet
- The idea here is that placing one’s mind and body into states of love
  - He knows he is sounding squishy
  - Or we could also think anything that doesn’t include a, “*But not that,*” is an expanded ruleset
- He’s not going to do this podcast spinning around in his chair on his head, but the moment he decides what’s appropriate and inappropriate behavior, he’s now started to constrain the rulesets
- We can go around this circle as much as we want or as little as we want
- ***Once people start to understand what places their body and mind into the most relaxed and “open” state for accessing new rulesets, the more quickly we can solve problems***

## Stress and fear increase autonomic arousal, limit access to rulesets, and inhibit performance [1:12:15]

*Evidence from the laboratory*

- If Andrew gives you a cognitive task and he ramps up your level of autonomic arousal, you can function up to a point
  - But this is mainly dependent on how well you have performed that thing in the past
- If he gives you something novel, everybody cliffs
  - Even if you’re a SEAL team six guy, or if you’ve run three countries, or if you’ve parented 12 kids on your own
  - Your rulesets are constrained
- If you are asked to do something novel under conditions of even mild stress, you break down
- If you are asked to do something novel under conditions of relaxation, and you can pull from what might seem like ridiculous rulesets; you can start solving problems
  - Humans do this exceptionally well
- The more we can narrow the context, be it medical school or math or parenting or whatever it is
  - The more we can narrow the context even in the moment
  - The more we can be in a relaxed state, a state of *not* wanting to avoid something
  - The more rulesets we can access
  - This is where Andrew thinks creative solutions come from

> “*I think every major advancement in human evolution has largely been from a desire for something as opposed to an avoidance of something else*”‒ Andrew Huberman

- For example, Elon musk wasn’t thinking about going to Mars because he hated Earth
  - He’s thinking about it because he loves the idea of going to Mars

**What about some of the amazing advances in cryptography and nuclear physics in World War II? You could argue that a lot of that was fear based.**

- Andrew agrees, but for the people doing the work, they just loved that they were solving a problem
- We got [Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) all around us here, and he played a prominent role in Andrew’s home and childhood
  - The love of what he did that came through
  - Sure he was working on the bomb, but he was also enjoying picking locks, and laying out all the secrets on the floor of the offices, because he loved the playfulness of it
- It was love (maybe love is too much of a loaded word)
- But delight is what captures this fascination, curiosity, and thrill of something that we see or experience and want more of
  - Delight is probably the better word for it

***You can get a lot done out of fear and the need to adapt, but you get a hell of a lot more done out of a genuine desire because you just want more of that thing***

- Andrew would argue that cryptographers were in bliss
  - Now, they didn’t want to get blown up and they’d love to save people, but there can be multiple purposes behind doing something

## Andrew’s upbringing, early childhood, and tough adolescent years [1:15:00]

**Upbringing**

- Andrew grew up in Northern California; he was born in Palo Alto at Stanford Hospital
- The joke is, he was born at Stanford, hung around skateboarding on the campus in his youth, then was trained at Stanford (in part), then became a faculty member; so he’ll probably die at Stanford
- His dad is from South America
  - He’s Argentine with dark hair, dark eyes
  - He speaks both Spanish and English
  - He came to the US on a naval scholarship
  - He was an experimental physicist at UPenn
- His dad met his mother in New York and they moved to California
- Andrew and his sister were born in the early and mid-70s (she’s 3 years older)
- His dad took a job at Xerox Park (Palo Alto), in the early days of the personal computer, the so-called graphical user interface and things like that.
- His mother was a stay-at-home mom; she was a teacher
- He lived right over the fence from Gunn High School; it’s the high school that’s infamous for having the huge number of youth suicides
  - Fortunately that’s adjusted
  - There are a lot of kids of Stanford professors
  - It’s not the Palo Alto High School on the other end of town; his end of town tends to be a bit more middle and upper middle class
  - At that time, Palo Alto had Midtown, which there were some families that were at or below the poverty line
    - Nowadays Palo Alto’s all pretty upper class
    - East Palo Alto still struggles
- Growing up from birth until about age 12 or 13, it was soccer, swim team, tons of kids on his street hanging out, there were all these boys his age
  - They had all had older sisters his sister’s age

***It was a pretty magical childhood***

- His dad transitioned into theoretical physics, and he was involved in the early days of [chaos theory](https://en.wikipedia.org/wiki/Chaos_theory)
- The family spent a lot of Andrew’s youth in Aspen in the summers because there’s the Aspen Center for Physics
- Andrew grew up running around hearing about [Peter Kaus](https://senate.universityofcalifornia.edu/in-memoriam/files/peter-kaus.html) and [Feineman](https://en.wikipedia.org/wiki/Richard_Feynman) and [Murray Gell-Mann](https://en.wikipedia.org/wiki/Murray_Gell-Mann)
  - Those were regular characters in his life, and he met those folks and they were around
- He was exposed to the academic world
- It was a pretty cool childhood; it was a pretty normal childhood
- The family did a sabbatical in Europe where he became really close with his sister
  - She’s an excellent therapist
- He wasn’t a great athlete or student, but he was always super curious about biology and animals
  - His Mom used to drop him off at Monet’s Pet Shop on California Avenue; he was obsessed with animals
    - It was directly across from Draper’s Music, which is where the Grateful Dead got their start
    - And those guys used to hang out there because they were from Menlo Park
    - There was a club, *The Edge*, you wouldn’t find that in Palo Alto now
- He had a pretty healthy upbringing
  - There weren’t have any issues around alcohol or drugs in his home
  - It was a two parent home, dinner together every night

**Everything took a  hard turn when Andrew was 12-13**

- There were some things looming under the surface, and his parents divorced
  - Unfortunately they didn’t read the rule book, or if they did, they broke every rule
  - It was a very high conflict situation
- His dad moved out and Andrew lived with his mom
  - His sister went off to college

**The skateboarding scene**

- At the time, Andrew had gotten into skateboarding and wasn’t playing soccer or doing other things
  - He fell really deeply into the community of skateboarding, which at that time was really underground
  - Skateboarding is a unique sport, because you have interactions with kids of a lot of different ages
  - He was hanging out with 30 year old guys, 20 year old guys, and kids his own age
- A good friend of his named Paul Zuanich was really good at skateboarding, and he started picking up sponsors and turned pro while they were in high school
- They started going up to San Francisco and hanging out at the the famed Embarcadero or EMB crowd
  - For skateboarding this is a huge deal, it’s kind of the golden era of street skateboarding
  - There he got exposed to drugs, alcohol, fights
  - He got exposed to a lot of kids that just didn’t go to school
  - There was also a lot of amazing skateboarding
    - The young [Danny Way](https://en.wikipedia.org/wiki/Danny_Way) would come through town or [Rob Dyrdek](https://en.wikipedia.org/wiki/Rob_Dyrdek), and these names will be familiar to people with [DC Shoes](https://en.wikipedia.org/wiki/DC_Shoes)
- In full disclosure, Andrew wasn’t a very good skateboarder
  - He was okay, but he kept getting hurt
  - He didn’t have the athleticism
  - He hit puberty late at age 14
    - This is something  someday he wants to understand ‒ the relationship between how long puberty lasts and longevity
    - He didn’t grow beard until college, but by the other marks of puberty were there at 14

**He had all this upset in his home life**

- It was pretty bad; his mom was struggling a lot
- His dad was trying to be in the picture, but there was a lot of conflict between him and Andrew
- Something about his behavior cued the schools system and he got taken away and put into a **residential treatment program** up on the peninsula
  - This was not for drug use, alcohol use, or hurting anyone or himself
  - This was mainly for truancy

## Andrew’s time in a residential treatment program and how he benefited from therapy [1:20:15]

**Did they require the permission of your parents to do that?**

- When he was in the 9th grade, Andrew remembers getting called into the office and asked questions about his home life
  - He caught onto the fact that something was going to happen, and did everything he could to resist getting taken away
  - But they took him away and put him under lock and key
- He was really angry and upset then, but he doesn’t have a ton of emotion around it anymore
- It was a terrible situation; his home life was so bad at that point
  - His sister was off in college
  - No one was there for him
  - His mom was working, and his parents were so focused on their own stuff
- He was basically running his own life, which is terrible for a 14-year-old
  - Boundaries are great; rules are great
  - He had a community of young guys, learning some healthy (and some not healthy) behaviors from older guys
- It felt super unfair when he got put away, but the counselors he met there were amazing
- He was also very lucky that drugs and alcohol were never his thing
  - A lot of kids in the residential treatment program were dealing with drug and alcohol issues; they were mis-wired
  - There were crazy adults in another building
- There was a moment when he thought, “*Is there something genuinely wrong with me?*”
  - He didn’t do anything except not take good care of himself

**Did you leave the facility each day to go to school or was there school there?**

- He was locked in a room
- His roommate turned out to be a really good guy
  - He was huge; he looked like [Richard Ramirez](https://en.wikipedia.org/wiki/Richard_Ramirez)  from the Night Stalker
- Andrew remembers not being able to sleep, and they came in to do bed checks three times a night
  - They frisked them
  - They did cavity searches for weapons and drugs
- He did group therapy with all these people
  - Some of them are talking about terrible molestation experiences, which fortunately he didn’t have, or drug thing
- He remembers thinking, “*Why am I here?*” He had no idea
- At the time he had picked up one skateboard sponsor, the Spitfire Wheels and Thunder Trucks
  - They put him on out of sympathy
  - Andrew is still friends with the team manager, Steve Ruggie
    - He’s not a pot smoker now, but back then he was
- Andrew remembers they literally got one phone call
  - He wasn’t going to call his parents
  - He called Steve and I was like, “*Hey Steve, I’m locked up here. I’m in the peninsula, I’m in Belmont, I don’t know what to do.*”
    - Steve replies, “*Man, you’re the most normal guy I know. I can’t help you.*”
- Andrew thought he was genuinely stuck, “*What am I going to do? I just didn’t know where to go*.”
- What happened was he eventually worked the program they gave him
  - Someone there said, “*Listen, just play the game*.”
- Eventually he realized they were asking questions that he actually want the answers to
  - What’s going on in my head?
  - Why am I just letting my whole life go?
  - What’s going on at home?

**Now in retrospect Andrew can summarize what he was dealing with**

- It was a super traumatic, a daily traumatic environment when he was at home
- Or it was just pure neglect
- Prior to that year, he had gone off to skate camp in [Visalia](https://en.wikipedia.org/wiki/Visalia,_California)
  - All the other kids went there with their bags and their parents, but Andrew just went
  - He just hung out; he would just get in cars and go
  - He went to Reno for a week to skate in the Nationals
    - He sucked, but he went anyway; they were just there, a bunch of parentless kids
  - He was part of this huge group of parentless kids
- At Gunn High School, there was a spotlight on him
  - Whereas had he been in an inner city school or something, he probably would’ve gone under the radar
- This gave him a great sensitivity to the word privileged
  - This word gets thrown around a lot these days in incorrect ways
- But he was very lucky to have that spotlight on him
- He was also getting into a lot of street fights
- He eventually got out of residential treatment, and the agreement was that he would switch high schools and start therapy

**How long were you in the residential treatment program?**

- A month or more, but that was plenty of time
  - You’re not controlling your food, your sleep, it’s all on their plan
  - Good kids were there
  - A couple kids killed themselves while they were there
    - You could get stuff in; there were all sorts of networks
    - It wasn’t jail, but it wasn’t far off

**You went to a great high school. Was the idea to get you a new peer group?**

- They weren’t so concerned with his peer group
- The idea was that he would live with his dad; something Andrew was excited to do at the time and had requested
- He switched to Palo Alto High School, just across from the Stanford campus
- At the time he had a girlfriend that went there
  - He met her when he worked at the local skateboard shop in the back of the Palo Alto Toy and Sport World
- One of the things Andrew had baked into him was an enthusiasm for animals and he liked work
  - He always had a job ‒ a paper route, work in the skate shop
- He moved to Palo Alto High School and was supposed to live with his dad
  - He had to be respectful of certain elements of privacy
- Then it was decided that he wouldn’t live with his dad, and this was like gasoline on fire
  - This was not his decision
  - He couldn’t live with his mom
  - He couldn’t go to the high school
  - He was hitting puberty
  - He  had no interest in biology anymore
  - He was just skateboarding and being a punk
    - But he ended up having a lot of fun and loving his friends and girlfriend at the time
- He ended up going to Palo Alto High for about three weeks before he stopped going
- Everything was getting worse, worse, worse

**The thing that saved him was therapy**

- He had to go once or twice a week
- The therapist was the first person who really paid attention
- His parented loved him, and he loved them
- But it was a crazy thing to have somebody listen and give you the confidence to figure things out
  - It was powerful
  - It wasn’t like everything will be okay, but they were going to figure this out
  - It was an amazing dialogue to be in
- In therapy, they discussed:
  - What he wanted to do
  - What he wanted to create
  - What is important to him

***Andrew has continued to work with this person 1-3x a week until now, and he’s been very lucky to have this mentor for 30 years***

- At times he had to request some budget help to do this
  - It was hard when he was a graduate student
  - Eventually insurance helped

> “*But to just be able to understand my own thinking, to be able to separate what was happening around me from what I wanted for myself*”‒ Andrew Huberman

- He had a number of huge mistakes along the way; therapy did not allow him to avoid mistakes

## The beginning of positive changes in Andrew’s young life [1:28:30]

- He got with a different girlfriend
- He stopped skateboarding when he got hurt really badly
- He started getting involved in fitness
- He went back to Gunn high school
  - There was a football coach at school, Bob Peters
- Andrew changed his look
  - He used to dye his hair black and wear skateboard clothes
  - He let his hair grow out to its natural color and decided to be a little less outrageous
- He started Thai boxing; he was not very good at it but was okay
- He started lifting weights, and his body reacted like crazy to that
  - He wasn’t on hormones, it was just the youth thing
- He started running; he ran cross country
- He still wasn’t very focused on school, but he was doing a little bit better
- His girlfriend at the time was a year older, and she had a really good work ethic
  - Andrew would run to her house on Sundays and wash her car
- He started doing a lot of physical labor, and figured he’d go into the fire service
- He started taking fire science classes at Mission College while he was still in high school; he loved the guys there
- At that young age he made the mistake of dabbling in psychedelics
  - Psychedelics have their place in the therapeutic context when people are older
  - But while the brain is still developing, it’s *not* a good idea
- He had a girlfriend, there was a pregnancy
- There was a number of things where his life still wasn’t bolted down, and that was causing problems
- His girlfriend was loving and great; she went off to college at UC Santa Barbara
  - In his senior year he would go down to visit her
  - Hew would sleep in the parking lot outside her dorm and hang out with people there
  - She was like his family; he mapped everything into her
- He applied to Santa Barbara and somehow got in; he went there to be with her
  - He barely broke a thousand on the SAT (he doesn’t remember studying)
- Two quarters into UC Santa Barbara, he had more fights than he did time in class
  - By the end of the year, he flunked out

> “*I think I just had so much fire and so much anger… inside*”‒ Andrew Huberman

**At the risk of stating the obvious, it sounds like you were very angry at your parents and you had good reason to be**

- Yeah, he was angry with them
- There was no organization in his life except the organization that he wanted to see his high school girlfriend
  - Her parents hated him
  - Her dad thought he was a punk, a disaster (and he was right)
  - She had a tough home life and Andrew moved into a protective role
  - She was a hard worker, and her dad was an extremely hard worker, so Andrew had a lot to prove
- With running, lifting weights, and stuff with the fire service, Andrew was learning there was a direct relationship between input and output
  - Whereas in skateboarding, he always felt like it was 10 units of input and then he would get hurt
    - He wasn’t a natural athlete for it
- He did some therapy work with his parents (a one-on-one things in the therapist’s office), and Andrew expressed his anger or whatever it was
  - He doesn’t remember being furious, as much as just feeling like “*You people don’t know what you’re doing*”

**Everytime Peter has a meal with Andrew, he learns something about him that is so remarkable**

- Peter’s favorite this week is about when Andrew was at some skateboarding thing, and there was no one there to take him home; he ended up getting a ride home with [Tony Hawk’s](https://en.wikipedia.org/wiki/Tony_Hawk) dad
  - They flew him home to San Diego
- Andrew was 14-years-old, he goes to the Linda Vista Boys Club and competes in a skateboarding contest
  - He did terribly
  - Then everyone heads off to their cars, and he’s just there with this kid Billy Waldman, (who people referred to as the demon child) and Frank Hawk (who’s Tony Hawk’s dad)
  - Frank ran the National Skateboard Association; he came up to Andrew and asked, “*Where are you going?*”
    - Andrew replied, “*Well, I’m from northern California. I was going to take the bus to Lancaster. There’s this guy that I know in Lancaster*.”
    - And he replied, “*No, no, no, no, no. You’re coming with me*.”
  - So Tony and his wife (Nancy Hawk) took Andrew to their home
    - Tony had moved out,so Andrew slept in Tony’s room that night
    - To say it was filled with trophies, is an understatement
  - They went to dinner, and they eventually flew him home
  - It was an amazing experience
- Frank eventually talked to Andrew’s mom and was like, “*Hey listen, this kid needs some guardrails*.”
  - Because skateboarding has a lot of truancy and a lot of wildness
- Part of its appeal to many is you don’t need parents around a skateboard
  - You don’t need your pre-workout drink, you need a Slurpee, or beer
  - For the 15-16-year old Andrew, it was a pack of cigarettes and a skateboard (he doesn’t recommend that)
- What ended up happening was the next day Frank took Andrew to Tony’s house in Fallbrook
  - He got to meet [Tony](https://en.wikipedia.org/wiki/Tony_Hawk) and Ray Underhill and a bunch of other guys, and pump around on the ramps a little bit, and then flew home
  - That was an amazing experience
- 10 years later on Instagram, he sent Tony a direct message and said, “*Hey listen, I know you get a ton of messages, but your dad really took me in*.”
  - He sent his condolences for the death of Tony’s mom
  - He added, “*And if you don’t believe that my story is true, how’s this? Your parents used to drink black coffee after dinner.*”
  - Tony wrote back, “*No way. Nobody would know that*.”

**Amazing experiences and struggles**

- A number of people tried to help Andrew along the way
- He had amazing experiences skateboarding in the early to mid ‘90s
  - To be a 14 year old kid at the Reno Nationals, running around the casinos with your friends and seeing these amazing skateboarders
  - He was also seeing rampant amounts of drug use and rampant amounts of odd types dating relationships
- It was fun to be free and wild, but he felt like he was always the guy at the end, because he wasn’t very good at skateboarding
- He didn’t have a home, and he didn’t have any structure
- He was the guy that didn’t know where to go

***And to this day, even if he’s at a scientific meeting, and everyone clears out at the end, he gets totally depressed, “I feel like I’ve got nowhere to go”***

- He’s owned homes, he had a dog
- He was angry with his parents and also just flabbergasted
- Now, having spent time with friends who have kids, 14 is pretty young
- He was involved in all sorts of things at 14 that he would never subject a 14 year old to
  - You want to preserve that innocence of youth as much as possible
  - At the same time, the fighting and hard work forced him to grow up
    - The fact that he thought about making a living really early on

## Andrew’s decision to turn his life around [1:37:00]

**In your first semester at UC Santa Barbara, who were you getting into fights with?**

- Just people
- Andrew was ever somebody who provoked fights or initiated them, but somehow it just found him
- He was not a big drinker, but there wa a lot of alcohol intake in that town
- In the summer between his freshman and sophomore year of college, there was a house that everyone hung out at, and he decided to stay there for the summer
  - He wouldn’t go home, what would he do at home?
- He had split-up with his girlfriend; they were having issues
- He was living in the town of Ala Vista with his pet ferret, and was squatting in a house
  - In skateboarding, you learn how to just kind of squat in places
- He was delivering bagels for the bagel cafe
- He showed up at a friend’s house, and a bunch of guys were stealing some stuff from the house
  - He got into this fight with a bunch of guys
  - And the people he had shown up there with all scrambled, they all just took off
  - This fight started getting ratcheted up into weapons, and people hitting each other with skateboards, and knives coming out; the police show up
  - In the end, he was let go because he was “protecting our property”
    - He remembers the police officers congratulated him
- He remembers feeling like this picture sucks
  - He was 19-years-old
  - He had no future in skateboarding
  - He barely went to class
  - He was getting into fights
  - He’d been thrown out of the dormitory for something stupid related to the fighting
  - He split up with girlfriend
  - He worked at the bagel cafe

***At that point, he didn’t really know what to do. He remembers thinking he was a total screw-up***

- He actually wrote a letter to his mom in the summer of ‘94 saying all these things he felt about the past and what he was going to do going forward
  - He still has the letter

**He made a hard left turn**

- He took a leave of absence from UC Santa Barbara
- He moved home and went to Foothill college
- His sister was home from abroad after college; they lived with their mom and this other girl who rented a room
- He went to Foothill College and just listened to himself
- One thing Andrew knows how to do is memorize information
- He just started focusing on coursework and working out
- And from that point on, except for one course in college, he was a straight-A student
- After a quarter there and a summer, he went back to Santa Barbara and lived in a studio apartment by himself
- He got back together with the girlfriend

**How did you fund this? Did you just take out loans to do all this?**

- He was very blessed, his dad helped with money
- He didn’t want to go back to Santa Barbara, he wanted to go to Whitman College in Walla Walla, Washington
  - He wanted to be a journalist or do something related to writing
  - But his dad said, “*No way. I’m not going to pay for this fluff education, liberal arts school. You’re going to go back there where there was some science*.”

**Andrew went back to school and was just a machine**

- It was like [Henry Rollins](https://en.wikipedia.org/wiki/Henry_Rollins) style, just work out
- He listened to [Rancid](https://en.wikipedia.org/wiki/Rancid_(band)), listened to [Bob Dylan](https://en.wikipedia.org/wiki/Bob_Dylan), listened to classical music on loop, drank coffee, worked out, ran, studied
- His goal was to be on the far end of the curve; they used to publish the curve for every class outside
- He became a straight A student

**Eventually he started working in a laboratory**

- He took a class from a guy named [Harry Carlisle](https://senate.universityofcalifornia.edu/_files/inmemoriam/html/carlislehj.htm) who was teaching about mental health, neuroscience, physiology, brown fat thermogenesis
  - Andrew started working in his laboratory on brown adipose tissues, and [dopamine antagonists](https://en.wikipedia.org/wiki/Dopamine_antagonist), and [clozapine](https://en.wikipedia.org/wiki/Clozapine) neuroleptics, and effects on temperature
    - He was obsessed with physiology and temperature
- Meanwhile, he was getting really interested in fitness and supplementation
- He tried to run cross country for Santa Barbara, but you had to run a sub-10 two mile, and that was way too fast
  - Guys on the team were built like whippets
  - Andrew is 6’1” and was 185-200 lbs then

**How fast do you run two miles today?**

- He doesn’t know, but his fastest mile ever was in high school
  - He ran a 4:57 first mile in a three mile race, and then bonked and had to walk off the race
    - So basically he failed the race
    - But that’s was pure adrenaline; it wasn’t training capacity
- He’s not a fast runner; he runs a two-mile run once a week, and would be happy with a 12 to 13 minute time

## A new passion for science and exercise helps Andrew [1:42:00]

- Andrew started getting really into work in [Harry’s](https://senate.universityofcalifornia.edu/_files/inmemoriam/html/carlislehj.htm) lab; he was great
  - Harry smoked cigarettes in the lab, he’d light them with the bunsen birder and smoke in the fume hood
  - They would drink coffee
  - They were injecting rats with [MDMA](https://en.wikipedia.org/wiki/MDMA)
  - They were studying the temperature regulating effects of MDMA, and we were studying amphetamines
  - Andrew was learning so much neuroscience; he was like a kid in a candy shop; it was amazing
- There was not a neuroscience degree at the time, it was called neurochemistry or neurobiology
- He was also taking psychology courses and bio-psychology courses
- He met a guy named [Ben Reese](https://psych.ucsb.edu/people/emeriti/ben-reese), who is expert in visual system development
- Andrew started learning about all these retinal specializations
- He learned there was a guy on campus named [Gerald Jacobs](https://psych.ucsb.edu/people/emeriti/jerry-jacobs), who discovered the evolution of vision and color vision (and is a member of the [National Academy](https://en.wikipedia.org/wiki/National_Academy_of_Sciences))

**Andrew’s crowd completely changed to a bunch of neuroscience dorks**

- He started hanging out with all these guys who were to him the coolest guys in the world, and in many ways still are
- He learned about all this mental health stuff he saw when he was locked up and how it related to his friendship circle, family, people who have anxiety
  - He learned about schizophrenia, neurotransmitters ‒ dopamine, norepinephrine
  - It’s not just Freudian Theory (even though he respects Freudian Theory)
- He and his girlfriend decided to part ways
  - They managed to make it about two more years
- He was on a mission to go to graduate school
- At this point, it was no drinking, no drugs
  - Once a month, he would go out and really tie one on with friends

**Are you still talking on the phone with your therapist with some regularity?**

- Every week

**Going back to this pivotal moment, the fight where the cops came. It sounds like a very orthogonal moment.**

- 100%

***Andrew realized he was going to end up dead or in jail***

- When the knives came out he realized he didn’t want to hurt anyone
- He had been locked up once before, and that was an experience he did not want again
- He realized at the time that he wasn’t doing anything well
- At the time he was paying the bodybuilder [Mike Mentzer](https://en.wikipedia.org/wiki/Mike_Mentzer) $100 to coach him and give him a program
  - He had read a think about him that his high intensity training was way better than everything else
  - He stopped doing  high-volume work and started doing two sets per muscle group each week and just grew like a week
  - Mike took a liking to him and was sending him [Ayn Rand](https://en.wikipedia.org/wiki/Ayn_Rand) books

**Is Mike Mentzer still alive?**

- No, he and his brother both died of heart attacks
- They were both pretty heavy amphetamine users
- Mike trained clients in a [high-intensity training program for bodybuilding](https://en.wikipedia.org/wiki/Mike_Mentzer#Mentzer's_heavy-duty_training_system)
- [Dorian Yates](https://en.wikipedia.org/wiki/Dorian_Yates) worked under him and used to bark at Andrew over the phone:
  - “*PhD stands for piled high and deep*”
  - “*You seem really interested in ideas. Don’t be a moron. Don’t be a bodybuilder. Don’t touch steroids. You have a mind. Develop your mind.*”
  - This had a huge impact on Andrew
- Him and Bob Peters (a high school football coach) taught him about weight training and running
- Gary Hall was a guy Andrew grew up with skateboarding told him early on (when Andrew was 14), “*Look, your parents are really messed up, and so many of the people we know in skateboarding are super messed up. If you mess up, I’m going to kick your ass.*”
  - Gary moved away to Milpitas, but now he is Andrew’s lab operations manager
  - Andrew remembered him saying, “*It’s not your fault, but if you screw up…*”
    - They laugh about this now

> “*I think in those years I started just realizing discipline is the answer… I needed structure, and the structure had to be self-imposed*.”‒ Andrew Huberman

- He really got into school and by the time he graduated, he graduated with honors and had published a paper
  - It wasn’t magnificent but the data was solid
- He got into Berkeley and Princeton for graduate school and decided to go to UC Berkeley
- He loved his time at UC Berkeley
  - He originally wanted to work with [Carla Shatz](https://profiles.stanford.edu/carla-shatz?releaseVersion=10.5.1), an amazing developmental neurobiologist
    - She developed the phrase, “*fire together, wire together*”
    - But she moved to Harvard
    - She is now back at Stanford
- He decided to move to UC Davis where she suggested working with a younger faculty member, [Barbara Chapman](https://neuroscience.ucdavis.edu/barbara-chapman-neuroscience-award)
  - She was his PhD advisor
- Andrew had met someone when he was in Berkeley (a wonderful person), but he ended that relationship when he joined Barbara’s lab so he could just focus on school

> “*I literally lived in the laboratory. I’d bring my groceries, I’d train at the gym, I’d sometimes shower in the monkey cage washer with the heat turned down, and I was just a machine. I was just work, work, work, work, work, work.*”‒ Andrew Huberman

- They published a bunch of papers
- He wasn’t paying much attention to his emotional and personal development, but in terms of loving science and focusing on science
  - He loved it so much
  - He adored Barbara
- Things started happening along the way
- He met [Ben Barres](https://en.wikipedia.org/wiki/Ben_Barres), the first transgendered member of [The National Academy](https://en.wikipedia.org/wiki/National_Academy_of_Sciences)
  - In 2001 or 2002 he came to UC Davis to give a talk; he came into the lab and started talking to Andrew
  - Andrew was supposed to deliver him to a seminar and they ended up being an hour late because they were just riffing on science
- Andrew thought, “*This guy is the best. He’s got this energy.*”
  - Andrew has always been tuned into people’s enthusiasm and excitement; he can spot bullshit pretty quick
- Andrew has never been drawn to people who are purely ambitious
  - Ambition is an algorithm that works, but when somebody is in love with what they do
    - That was why he loved skateboarding; you don’t survive long in that community unless you love it
    - And the same is true with science
- Andrew was in love with retinal biology, in love with developmental neurobiology, and he saw Ben’s love of [glia](https://en.wikipedia.org/wiki/Glia)
  - Andrew could care less about glia, but they resonated on this passion
- Ben happened to be transgendered, and Andrew didn’t even know he was transgendered, but they became friends
- At some point, Andrew started going down to Palo Alto to teach his lab some techniques, and Ben said to him, “*You should just do a postdoc in my lab*.”

**Were you sure that you wanted to do a postdoc?**

- Yes, he had decided in undergrad that he wanted to run a lab, teach students, and be a researcher; he was going to do it ethically and honestly
- He looked up to [Harry Carlisle](https://senate.universityofcalifornia.edu/_files/inmemoriam/html/carlislehj.htm) so much
  - Harry drove a black truck, smoked cigarettes, and drank coffee
    - Don’t smoke, it’s bad; Andrew doesn’t smoke anymore
  - His wife was a therapist; she ran the psychology center at UC Santa Barbara
  - Andrew adored them and wanted to be that
    - The fact that his dad was a professor added to this
- Over the years, Andrew was in touch with his parents and they were proud of his shift
  - He still has a lot of issues to work out with him, less so with his mom
  - He buried the hatched with his dad in 2007
- Andrew earned his PhD from UC Davis

**Andrew went to Harvard to do a postdoc but realized he didn’t want to work for the guy**

- He was sitting in on lab meetings, and the personality traits of this person were repulsive

- Andrew didn’t like the way he treated a janitor with a stutter
  - Just thinking about this makes his blood boil
- Andrew has never been an aggressor, never started a fight
- Even in nursery school, he has been an advocate and protector of others
- It was an after-work interaction, and the way he communicated, Andrew knew there was no way he could be there
- He remembered thinking, “*Oh no. What am I going to do?*”
  - He had just moved to Boston
  - He broke up with his girlfriend on the West Coast; his girlfriend at the end of graduate school was great
  - This was November of 2005 and he was supposed to start January one
- He told him he was leaving, but at the time didn’t have the skills to be direct about why
- They guy said, “*No. You need to get therapy first.*”
- Andrew replied, “*Well, I’ve got loads of that under my belt, so that’s not going to work.*”
- There were certain things in the interaction around his decision to leave that made it absolutely clear that leaving was the right thing to do
- He called [Ben Barres](https://en.wikipedia.org/wiki/Ben_Barres) because he had turned him down for a postdoc; at the time, he didn’t want to work in Palo Alto
- Ben, in his love of biology, just said, “*Come to my lab. You can work on anything you want… But you have to pay it forward someday.*”
- When Ben was a graduate student in [David Corey’s](https://brain.harvard.edu/?people=david-p-corey)
- at Harvard, David Corey worked on hair cells, hearing stuff, and he allowed one person (Ben) to do something different
  - So Ben was going to pay it forward through Andrew
- Andrew wanted to work on stuff related to what he was going to do at Harvard, but he didn’t want to compete with that lab
  - They were a big monster lab
  - Ben was like, “*No, you have to work on that… You have to*.”
  - Andrew didn’t want to at that point
  - There were three labs trying to figure out genetic markers for retinal cells ‒ this guy at Harvard, a guy in Basel ([Botond Roska](https://iob.ch/people/botond-roska)) who does amazing work, and then Andrew, alone as a postdoc
- At the time the hunt for genetic markers for retinal cells was a big deal
  - Andrew felt there was plenty to go around ‒ there were many retinal cells, 40 ganglion cells (the output cells of the retina that connect to the brain), there was so much territory
  - Andrew ended up getting his slice, the guy at Harvard got a bigger slice (he had a lot more people), and Botond did that and so much more for visual repair
- Botond and [Karl Deisseroth](https://profiles.stanford.edu/karl-deisseroth) have figured out ways to get blind people to see, putting light sensitive options into the eye etc.
- Andrew was just one postdoc, but it worked out well; he got a job at UC SanDiego which has a great neuroscience program

## The difference between a postdoc and a PhD [1:54:15]

**Give folks a bit of a sense of the difference between a PhD and a postdoc**

- During your PhD, you’re working closely under the mentorship of one person
  - That’s also true in the postdoc
- During the PhD, the requirements are to learn the basics of the field and be tested on them in the classroom, learn the basics of experimentation and experimental design, and then become expert in one specific area by doing experiments
- Andrew always says you get your PhD by being an expert in one very specific area
  - You have to know everything about what you did and why, literally down to what specific antibody you used and where it is in the refrigerator
  - You need to be able to do everything that’s on your papers
  - Learn the publication process, learn how to write, learn to take rejection, learn to take challenge in the seminar format, all of that

**What is the expectation for a PhD as far as publications?**

- This varies
- Andrew did very well as a PhD student; he published 4-6 first author papers in great journals
- 1-2 would be sufficient if they’re good quality papers, and some projects go better than others

>  “*The key requirement of the PhD is to become a true expert in one area, and then to be able to frame how that fits into the context of the field as a whole*”‒ Andrew Huberman

- Your PhD thesis is given not for saying, “*I did this, I did this, I did this*,” which any technician could do
- It’s given to you for saying, “*I did this, I did this, I did this, and the implications are blank,*” and to extend that into the discoveries of past and other laboratories
  - Typically, that correlates with having one first author manuscript in a good journal, but not always
- Andrew did his PhD in four years, which was pretty quick

**Was half of that in the classroom and half in the lab?**

- Typically, you’re taking courses only in the first two years
- You also have to consider peer group, this was 2000-2004
  - Andrew was 25 when he started his PhD, and he finished when he was 30
  - He had no children
  - He was dating, but wasn’t in a committed relationship for most of it
  - He literally worked 12-16 hours a day
  - He was not in the best health; he lived on Peet’s black coffee, Diet Mountain Dew, cucumbers, ground beef, oatmeal, oranges, and love of what he was doing
    - He was into vitamins and creatine; he worked out one day a week in the gym and ran one day a week
    - He was young, so his body didn’t fall apart, but it wasn’t good
  - He prioritized everything around work
- In 2012 he started taking better care of himself and began taking [Athletic Greens](https://athleticgreens.com/en)

**What was the title of your dissertation?**

- It was *Neural Activity and Axon Guidant Q-Dependent Development of Eye Specific Segregation in the Lateral Geniculate Nucleus*
  - This is basically saying there are molecules and there are patterns of neural activity that govern brain wiring
- At the time, he was working in ferrets and cats (carnivore species), and he wanted to move away from that
  - He’s always been an animal lover; he had a pet ferret
  - He didn’t want to work on large animals
  - He’s done some non-human primate work; he published a lot on the fetal primate (fetal macaques)

**How big is an adult macaque?**

- An adult male macaque can be a couple feet tall
- They’ll rip a limb off of you if you let them
- They carry [herpes B](https://en.wikipedia.org/wiki/B_virus) which can kill you
  - There’s a [famous case](https://www.nytimes.com/1997/12/14/us/a-drop-of-virus-from-a-monkey-kills-a-researcher-in-6-weeks.html) in Atlanta of one splashing its pee into a woman’s eye
  - She wasn’t wearing the face shield, and she was dead two weeks later
  - You’re better off getting HIV
- Andrew does not like working on macaques for a number of reasons, and he doesn’t work with them any longer
- As a postdoc, you’re not taking courses
  - You’re mainly focused on research
  - You’re developing your own independent research program

**What is the purpose of a postdoc?**

*Would you do a postdoc if you didn’t want to have your own lab?*

*How many people do a postdoc and choose to go into industry rather than form their own lab?*

- Nowadays about 80% go into industry
- But now there are a lot more jobs for neuroscientists in industry, places like [Genentech](https://www.gene.com/), etc.
- At the time, there wasn’t as many industry jobs

**What defines the duration of a postdoc?**

- You know when you’re ready to move on as a postdoc because you generally have one or two papers and a story to take into a seminar
- In both the PhD and the postdoc, the goal is to have a one-hour seminar of your own independent work, and the context it fits into, and you get hired
  - Peter has an honorary PhD in some facet of Formula One where he can spend one hour talking
- Andrew’s postdoc was great; he loved working for Ben

## Staying in touch with the love of biology and not getting pulled into ambition [1:59:15]

**Andrew left Palo Alto for San Francisco**

- In 2005 he moved back to the Bay Area of San Francisco, he didn’t want to live in Palo Alto
  - He commuted down 280, and loved working in Ben’s lab; there were 30 people in the lab
  - He started his postdoc in 2005 and finished in 2010
- Peter was in the Bay Area for med school from ‘97 to ‘01 and lived there again from ‘06 to ‘08
- Andrew was living at Clayton and Parnassus, right near UCSF, the old campus, the hospital
- His sister was in the neighborhood and had just adopted, so he wanted to be to spend time with her
- Peter spent a lot of time out there because his wife ran the [Coumadin Clinic at UCSF](https://www.ucsfhealth.org/clinics/anticoagulation-clinic)
- Andrew was a few blocks from the [Haight Ashbury Clinic](https://www.healthright360.org/agency/haight-ashbury-medical-clinics), a very different clinic, but famous because of the [Manson](https://en.wikipedia.org/wiki/Charles_Manson) thing, and if anyone hasn’t read [*Charles Manson, A Chaos, Charles Manson, the CIA and the Secret History of the Sixties*](https://www.amazon.com/Chaos-Charles-Manson-History-Sixties/dp/0316477559/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1677164495&sr=8-1), a lot of history there

**Andred loved working in Ben’s huge, vibrant lab**

- There were 32 people in the lab, and it was run by a person with a face recognition issue; you can imagine it was hilarious
- The lab meetings were legendary; they were 4 hours or more; people would argue and fight
  - Ben could be very politically incorrect, which was hilarious
  - At the time, it was also important for us to have someone challenge us in these very direct ways
  - We were all politically correct, but Ben said some pretty outrageous things

***Andrew learned so much from Ben about staying in touch with the love of biology and not getting pulled into ambition***

- Ben called it the light, or the flame
- Ben was incredibly ambitious, but he just loved biology

**Something weird happened in 2000**

- Peter had the distinction by just luck by the year he was in med school (‘97), Andrew’s postdoc advisor (Ben Barres) was the head of neuroscience
  - He year began as Barbara Barres and ended as Ben
  - The she to he transition occurred during that year
  - Even though that was more than 25 years ago, it didn’t seem that unusual, but this had much more to do with Ben

**Ben passed away in 2017**

- Andrew wrote [Ben’s obituary](https://www.nature.com/articles/d41586-017-08964-1) for *Nature*
- When Ben moved to the Bay area, Andrew sat with Ben for many hours recording conversations with him that he hopes to someday release
  - Talking about his history and the decision to transition and his thoughts on when and how best for people to transition, what that means, his relationship to sex, the verb and sexuality, academia
  - It’s a great audio file because he tears loose on people in academia
  - He says at the beginning, “*Is this for my obituary?*” Andrew replied, “*Yes*,” and he said, “*Well, it better be for a good journal*.”
    - Andrew said, “*It’s for Nature*,” and he says, “*Okay, well, given that it’s for my obituary, I’m going to say whatever the fuck I want.*”
    - And he really does; he lets people have it
  - But he also really expresses a lot of heart for the things that he thinks are important in science and in life
  - Andrew was sitting there, tears just running down his eyes trying to get these recordings, and he realizes what’s happening
    - He’s going to be dead soon
    - He had pancreatic cancer, and as a non-clinician, that was pretty intense

**Peter reconnected with Ben in 2012**

- Ben had red some of Peter’s blog and reached out and became interested in some of the things Peter was doing
- He asked if Peter would check his bloods, etc.
- Ben was really into data
- One thing that people don’t realize about Ben is that he was always trying **different diets**
  - He struggled with his weight a lot
  - Because he transitioned, he was taking testosterone, but he had always struggled with his weight
  - He had tried keto, he had tried fasting, he had tried vegan diets
  - He was always sampling with different things, and he was always asking me about nutrition and supplementation
- When Andrew was in his lab, he was working a lot, and he noticed that the fewer carbohydrates he ate, the more he could stay awake
  - Andrew is a pure omnivore; he loves starches, but tends to eat oatmeal, rice, and pasta ‒ what he considers “clean” starches
- At the time, Ben caught him drinking the oil off the top of a jar of almond butter, and then slugging back two expressos
  - Ben was like, “*What are you doing? You’re going to die of a heart attack*.”
  - Andrew was like, “*No, you have to understand, certain lipids can be used as fuel if you’re not taking enough carbohydrate.”*
  - Then he would scream, “*That’s ridiculous. That violates all the rules of biology*.”
- Then Ben came back to him six months later and was like, “*I’m doing this low carb thing and I’m losing weight like crazy. How come nobody knows about it?*”
  - He said “*Most doctors are so unhealthy. They don’t know anything.*”
  - Ben was a MD, PhD
- Andrew remembers Ben telling him, “*Don’t believe any dogma, don’t believe any of it.*”

**Ben had this heretical thing ‒ there’s a theme here**

- Andrew liked hanging out with punks and skateboarders when he was younger, not because they were wild, but because they looked at things differently
- He loves stories
  - He loved the [*Steve Jobs*](https://www.amazon.com/Steve-Jobs-Walter-Isaacson/dp/1451648537/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1677166250&sr=8-1) book
  - He remembers seeing [Steve](https://en.wikipedia.org/wiki/Steve_Jobs) walking barefoot through the neighborhood when he was a postdoc, when he would visit my folks in Palo Alto
    - He would also visit his high school girlfriend, that he met at the skateboard shop
    - She was his vegan chef, and her sister worked for Steve
  - Steve was a punk rocker and didn’t even realize it
- Andrew’s heroes are people like [Joe Strummer](https://en.wikipedia.org/wiki/Joe_Strummer), [Oliver Sacks](https://en.wikipedia.org/wiki/Oliver_Sacks), people that really went against the grain of their field out of love, not as an F-U
- When Ben started working on [glia](https://en.wikipedia.org/wiki/Glia), everyone thought glia were stupid
  - Why would you study support cells?
- Ben showed they were important for everything, disease in particular, but normal brain functioning and development
- Ben was the one who really encouraged Andrew to stay in touch with that feeling around doing things and to never let ambition pull you in a direction where you were divorced from that for too long
- Ben was also an extremely hard worker
  - He understood that that’s what [Rick Rubin](https://en.wikipedia.org/wiki/Rick_Rubin) called “the source,” that’s the ability to continue working long hours and not feel like you’re depleting yourself
- Andrew got really close to Ben in those years that he worked for him
  - Ben was healthy then
  - During those years when he was working for Ben, he wasn’t making enough money to survive in the Bay Area; he was really struggling

**What is a postdoc salary?**

- He had a [Helen Hay Whitney Fellowship](https://hhwf.org/research-fellowship/), which is a premier fellowship from a private institution
  - They pay more, and he was making $45k
  - But rents were crazy and gas and food and everything else
  - Living on $45k  in the Bay Area was rough, and he didn’t have kids
- Andrew actually went back to [*Thrasher Magazine*](https://www.thrashermagazine.com/)
  - He had a bunch of friends that worked there
  - They’re located in the only truly dangerous part of San Francisco, Hunter’s Point
  - They gave him a job writing articles for *Thrasher* and *SLAP Magazine*, the sibling magazine
  - He wrote a bunch of articles under a different name (Andy Huberman); people in skateboarding knew him as Andy
  - He was writing articles on musics and bands
  - He was going to hear bands play and then getting back to the lab at 2:00 or 3:00 in the morning
    - Sleeping in Ben’s office, and then working in the day
  - He was making an extra $500-1000 bucks a month
- It was great to go to shows for free, get to know musicians, fall back in with the skateboard set (all the ones who were healthy and how had families and jobs)
  - All the other dysfunction got pushed away
- He was in both worlds again

## Andrew starts his own lab, and continues work to overcome his demons [2:07:00]

**Eventually Andrew got a job at UC San Diego**

- He had a choice between UC San Diego and MIT
- While he loves the academic community in Boston, he realized, “*I’m a California kid, I’m a skateboarder and punk rocker at heart*.”
  - He thought, “*Back there, everything’s focused on lineage and how old you are and how long you’ve been around*”
  - In the Bay Area it’s all about the young tech and youth is really valued
    - You could be 25 years old in the Bay Area, and if you have a great idea, people don’t care
    - The East Coast is different, at least at the time it felt different
- Andrew went to UC San Diego in 2011 and his lab flourished there
- He left in 2015 because he got hired back to Stanford when Ben was still in the department

**The weird thread through all of this is the contrast between life as a graduate student/ posdoc and life as a professor**

- In San Diego, he lived in Normal Heights, out towards El Cajon
- He went from making $42-45,000 dollars a year as a postdoc to $100,000-110,000 as a starting assistant professor
- He went from having essentially no responsibility to buying a little house, getting a bulldog puppy, and getting a laboratory
- He hired a technician that he knew from Davis, and just went ham
- It was all about experiments, experiments, experiments
  - He lived in the lab two or three days a week, brushing his teeth in the sink
  - His students were like, “*What’s wrong with this guy?*”
- He was very fortunate; they published a bunch of papers in great journals
- More importantly, they were having a lot of fun doing research; it was incredible
  - He had all these microscopes
- He couldn’t believe he had his name on the door
  - Actually, he’s always thought that labs should name themselves after the work they do as opposed to the name
- He met a woman and was in a five-year relationship with somebody there that was really wonderful
  - She taught him a lot about how to balance his professional life and his personal life
  - Despite that relationship not working out, he learned a lot of important elements ‒ for example, it’s good to come home for dinner and be with her and the dogs every once in a while
  - It taught him some self-care
  - He got back into boxing, although he tried not to spar too often

**Overcoming demons [2:09:00]**

*Were the demons of your youth still rearing some of the emotional damage?*

- That would show up in various form
- He and his dad finally put to rest their challenges in 2007
  - He wrote Andrew a letter expressing concern and disappointment in the ways they were relating
  - This was when Andrew was a postdoc in Ben’s lab
  - He remembers thinking, “*He’s reaching out. Maybe it’s time to take a look at this*”
  - He wasn’t about to try and solve it in a conversation; he suggested therapy
    - Andrew wanted to have a conversation in front of somebody would could tell him here he was also wrong
    - They did a total of four sessions with a really excellent female therapist
    - He remembered the question of who was going to pay for it
    - Andrew told his dad, “*I don’t have much money, but I’m going to go in 50/50 with you on this one*”
    - After four sessions, they realized it was the first their man-to-man conversation they ever had
- Andrew realized that a lot of the things he struggled with growing up, his dad did too
  - His relationship to his mother
  - His relationship to himself
  - Trying to balance a life in science and ambition
- Science is not throwing punches at your face/ shooting at you
  - But you’re also not winning millions of dollars at the end of a case or cashing out a bit IPO
  - The wins are really wins of the heart and wins of discovery ‒  you get a paper in *Science* or *Nature* (Andrew is blessed to have more than a few of those)
    - At first you’re like, *“Shit, will I ever do that again?*”
    - It’s a lot like a professional athlete, but your world is tiny
    - Once you realize your world is tiny, you have two choices ‒ either leave because it’s too small, or go back to your love of the work
    - But you also have to live in the world and have a family in relationships

***In those conversations, he realized he inherited some real gifts from his dad ‒ curiosity and love of craft***

- His dad is 80, and he’s still firing on eight cylinders
  - He’s excited about cars, he’s excited about science, he’s excited about movies
- Andrew and his dad resonated; they finally hit that point

***They say forgiveness is really the best thing, and Andrew thinks it really is***

- He’s good with his dad; they’re super close

## The loss of three mentors leads to deep soul searching [2:12:00]

**The loss of his undergraduate mentor Harry Carlisle**

- When Andrew was in San Diego, he went back into full forward center of mass **ambition**
- It was only his girlfriend and bulldog that kept him a little calibrated
- When he was a PhD student, the second [paper](https://pubmed.ncbi.nlm.nih.gov/12738869/) he published was in *Science*; he was super proud
- He called and told [Harry Carlisle](https://senate.universityofcalifornia.edu/_files/inmemoriam/html/carlislehj.htm) because he knew Andrew’s story, gave him a lab to work in, saw him graduate with honors
  - He congratulated him and invited him to have pizza with him and his wife (Jane) to catch up the next time he was in Santa Barbara
- Three days later, Harry shot himself in the bathtub, just killed himself
- Andrew was there two or three days later speaking at his funeral and was like, “*Holy shit*,” he knew a bunch of people who had died or gone to jail from the skateboarding world
- It was just crazy because this was the guy that had taught him about mental health issues and about depression and how it’s all neurochemistry
- Andrew and Jane would meet for the next couple of years; he would go to their house and talk to her
  - She recently passed away
  - She told him that they had had a son who had died in a motorcycle accident early on when he was in his teens, and Harry never quite got over that
- Harry should have known better
- Andrew realized, “*Wow, you can have all the knowledge in the world about the underlying biology, and it might not save you.*”

> “*That was a wake up call*”‒ Andrew Huberman

**The loss of his PhD advisor, Barbara Chapman**

- Andrew was very close with his PhD advisor, [Barbara Chapman](https://neuroscience.ucdavis.edu/barbara-chapman-neuroscience-award)
  - She had two kids while he was in the lab, and his niece is friends with them
  - Their families have merged
  - She started falling out of communication with people, she had early-onset breast cancer and died
    - She had the [BRCA1 and BRCA2 mutations](https://en.wikipedia.org/wiki/BRCA_mutation) which made her highly susceptible to cancer
  - Andrew spoke at her memorial at the House of Flowers in San Francisco
  - It was horrible; it was like losing his mother

***Her death destabilized him, but he got through it; he reacted by working twice as hard, which was not a good formula***

- He got hired back to Stanford; he was working next door to Ben
- His first week back he goes out to dinner with Ben Barres, Carla Shatz, Krishna Shanoi, and Karen Hersh
  - They’re at Il Fornaio, downtown Palo Alto; Ben looks at him and says, “*I think I’m having a heart attack*”
    - Ben’s a MD
  - Andrew takes him in his 4Runner to Stanford Hospital and they spend the night talking
  - Ben asks him not to tell anyone in his lab; he doesn’t want them to think he’s dying
- Later that week, Ben has a second heart attack; he’s throwing clots; he was diagnosed with pancreatic cancer

**From the moment Andrew lands at Stanford, he’s watching his third advisor die**

- Ben with his MD morbid sense of humor used to joke, “*Andy, you’re the common denominator.*”
  - The joke is, you don’t want Andy to work for you
- Andrew had a conversation with Barbara before she died, talking about people who work in hospice
  - Saying goodbye to someone is tough
  - Hearing that somebody went suddenly is tough
- Luckily, Barbara’s daughters are both doing really well
  - One graduated from college
  - The other is a neuroscience student at McGill

***Ben’s passing away was the final nail in the coffin for him; he realized he needed to go all the way back and start doing some deep excavation because he was starting to feel really shut off***

- At this point, Andrew hated doing his work
- He thought he might write a book
- He was losing touch with the source, the love for science
  - He had a big lab but wasn’t feeling it
- Andrew started foraging, he started doing cage exit Great White Shark diving
  - Real smart, he might as well box nine rounds with Peter or a real fighter with no headgear
  - He was starting to engage in dangerous behavior again
- Here he is at age 42 with tenure at Stanford, he’s publishing
- He published a [full article](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8442544/) in *Nature* in 2018 after Ben’s death, but he remembers feeling pretty joyless and thinking, “*What the fuck and I going to do? I’m out of touch with all of it.*”

**Therapy**

- Andrew did the [Hoffman process](https://www.hoffmaninstitute.org/the-process/), this is no drugs, no psychedelics, but psychedelic state of self-actualization stuff
  - It was $4-5,000 for the week; they have scholarship programs
  - This was helpful
- One of the things that really helped was he did a week-long trauma immersion in 2017 on the east coast with a brilliant guy named [Ryan Soave](https://www.ryansoave.com/about)
- Andrew was trying to work through many different things:
  - Old stuff he amassed in childhood
  - Major loss as an adult
  - He has mentioned 3-4 girlfriends, and he wasn’t someone who enjoyed skipping from relationship
    - For each of those there was a story of hope for a permanent future and then a cliff
  - He was the common denominator; he’s not going to take all the blame, but there is a consistent variable there

## What motivated Andrew to begin his podcast [2:18:00]

**A turning point after so much loss**

- In 2017 he met a guy named [Pat Dossett](https://www.linkedin.com/in/patdossett) at Hoffman
  - He had done 13 years in the SEAL teams
  - They became friends, and Andrew would go down to LA (where Pat was living), swim with him and hangout out
- In 2019 Pat asked him, “*What are you going to do for the world in 2019?*”
  - That was the seed question
  - He thought about posting one-minute clips on [Instagram](https://www.instagram.com/hubermanlab/?hl=en) about the retina or nerdy stuff that he thinks is cool, and Pat made him shake on it
- Andrew starting posting, and then in 2020 the pandemic hits, and he thought maybe he should write a book
  - He realized that his lab works on stress and he has some **tools for stress and improving sleep**
  - He wasn’t going to talk about vaccines because it seemed like a barbed wire topic; you can’t win that conversation
- He thought he could teach stuff by going on podcasts, and in 2020 he did 30 podcasts that year
  - He went on [Joe Rogan’s](https://www.joerogan.com/) [podcast](https://www.jrepodcast.com/episode/joe-rogan-experience-1513-andrew-huberman/), and [Lex’s podcast](https://lexfridman.com/andrew-huberman/)
- At the end of 2020, [Lex](https://lexfridman.com/) suggested that he start his own podcast, “*But don’t make it just you talking.*”
- Andrew took half of the advice, and in 2021 he hired the guy who was going to do PR for his book stuff, Rob Moore and they started the [*Huberman Lab*](https://hubermanlab.com/) podcast

**In 2019, he was blabbing into Instagram; in** **2020, he was going on podcasts**

- During those years he was so frightened
- He hoped none of his colleagues would see this
  - But if they did, they would know that everything he’s saying is true
- Probably the only reason he is not on TikTok is that Stanford forbid them from being on it early on; it’s a security risk

**In 2020, he was really concerned for the world**

- He knows the director of the [National Institute of Mental Health](https://www.nimh.nih.gov/) ([Josh Gordon](https://www.nimh.nih.gov/about/director)) and told him that he didn’t see any advice on:
  - Getting regular sunlight
  - Staying on a circadian rhythm
  - Learning some stress mitigation techniques
  - He told him, “*The world is falling apart due to stress*”
- Andrew remembers thinking, no one is going to step up, “*I’m going to do this*”
  - He wasn’t selling a book
  - He didn’t have a podcast
  - He was just giving information
- When the podcast started he wanted to honor the incredible place that is Stanford
  - He would love to incorporate some of the brilliant minds at Stanford
  - So he invited a bunch of his colleagues
  - [Karl Deisseroth](https://hubermanlab.com/karl-deisseroth-understanding-and-healing-the-mind/) was one of his first guests
  - He had [Anna Lembke](https://hubermanlab.com/dr-anna-lembke-understanding-and-treating-addiction/) on

**In this last year the fun really started because he could include people to speak to some of his other long-standing interests**

- [Andy Galpin](https://hubermanlab.com/dr-andy-galpin-how-to-assess-improve-all-aspects-of-your-fitness/) on fitness
- [Layne Norton](https://hubermanlab.com/dr-layne-norton-the-science-of-eating-for-health-fat-loss-and-lean-muscle/) on nutrition and other things

**Andrew continues therapy**

- Throughout this whole time, Andrew has kept a weird journal where he has conversations with different people (Peter, Rick Rubin, etc.)
  - He also keeps having conversations in a journal with Barbara (mostly) and Ben where he discusses major decisions, stance around a podcast, stance around research or what to do with his lab
  - He considers the important lessons that he has learned from them
- Andrew still does therapy 1-3x a week, “*because if I didn’t, who knows what would happen*”
- He has done some exploration of the [psychedelic space](https://peterattiamd.com/?s=psychadelics) (not a lot), and always in the company of a physician
- In two of those sessions, [MDMA](https://en.wikipedia.org/wiki/MDMA) was immensely beneficial for:
  - Allowing him to have a conversation like this
  - Put down his dog, who he was super close to
  - Getting clarity on lessons from his life arc ‒ staying in touch with the things that give us energy as opposed to being ambitious for ambition’s sake
  - Getting the order of that dialogue correct and putting love of craft first, and letting ambition stem from that
  - Appreciating friendship and amazing mentors

## Looking to the future of Andrew’s scientific work, podcast, and more [2:22:45]

[***Huberman Lab***](https://hubermanlab.com/) **is one of the top podcasts**

- In the podcast space, Andrew listened to [Tim Ferriss’s podcast](https://tim.blog/podcast/) early on, and read his [books](https://tim.blog/tim-ferriss-books/)
  - He listened to [Joe Rogan](https://www.joerogan.com/), Peter Attia, [Lex Fridman,](https://lexfridman.com/podcast/) [Rich Roll](https://www.richroll.com/all-episodes/)
  - [Rhonda Patrick](https://www.foundmyfitness.com/episodes), he jokes “First Man In” was actually a woman, it was Rhonda
  - Before he knew these people, there was the [Ben Barres’s](https://en.wikipedia.org/wiki/Ben_Barres) and [Richard Axel’s](https://zuckermaninstitute.columbia.edu/richard-axel-md) of the world

***These are the greats of podcasting, so he pays a lot of attention to how he can do things well like them but different***

- There are no rewards for just imitation

**The beauty of podcasting relative to science is that if Peter and Andrew have the same guest on in one week, it raises it in the algorithm**

- Where as in science, if two papers come out simultaneously in a journal, that lends strength to the argument that the data and conclusions are true because of two independent discoveries
  - But there is this notion of scooping ‒ if someone publishes a result in a given arena and then you’re six months late publishing the same finding, you can’t get it into a good journal
  - It’s the opposite in podcasting
- If Joe has [David Goggins](https://www.jrepodcast.com/episode/joe-rogan-experience-1906-david-goggins/) on yesterday, and then he comes on Peter’s or Andrew’s podcast, it’s a rising tide that raises all boats, and the algorithm is the tide
- Andrew is still running a lab but he’s also in a field where goodness grows goodness
  - Sharing and being generous makes everybody succeed more
  - You learn from seeing how someone relates in other conversations
- Whatever deadening was created by the death of Andrew’s advisors in 2020 (and especially in 2021), it was just like rocket fuel
  - It was that conversation with Lex and all the other stuff that led up to it

> “*If you gave me a $100 billion to stop podcasting, I wouldn’t do it*”‒ Andrew Huberman

- Andrew knows that at some point, the lights are going to go out for him and he’ll be dead, and the question is, “*What are you going to have, and what have you done?*”
  - He feels he’s good if he can, “*Touch into the beauty and utility of biology and share that… the rest is just noise*”

**Given the meteoric rise of your amazing work over the past two years, what do you think you’re going to be doing in two years?**

- Podcasting
- In the lab, he has a paper that’s right on the 99.9 yard line
  - There is one more little thing they want us to tweak before it goes in
  - This is a [*Cell* paper](https://www.cell.com/cell-reports-medicine/fulltext/S2666-3791(22)00474-8?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS2666379122004748%3Fshowall%3Dtrue) he’s really proud of on human breathing patterns and anxiety [It was published before this podcast was released]
- There is another paper he is fighting with a journal about right now
- Because of the podcasting, his lab has gotten smaller
- But he has a close collaboration with [David Spiegel](https://profiles.stanford.edu/david-spiegel) (the Associate Chair of Psychiatry), and they are spinning up a number of programs at Stanford around mind-body research
  - He works on clinical applications of hypnosis
  - [Nolan Williams](https://profiles.stanford.edu/nolan-williams?tab=bio) works with psychedelics

- Andrew hasn’t talked too much about this publicly, but all of his podcasts are free
  - They are released on Monday, sometimes also on Wednesdays
- They launched a premium channel
  - Thanks to Andrew Wilkinson and Tiny Capital who are matching of funds for people that subscribe
  - What he is trying to do is raise money to fund the best work

***In two years, he will still be podcasting, he’ll still be a Professor at Stanford, teaching***

- He will be teaching the same course (next quarter) that Ben taught Peter, [Bio 206](https://explorecourses.stanford.edu/search?q=NBIO206) on neuroanatomy, functional anatomy, everything around addiction

**Andrew would like to get more involved in science philanthropy, in particular to fund research on humans**

- He is very frustrated with the lack of progress in translating animal models to human treatments
- He knows it’s necessary, it takes time
- He loves the worm work, fly work, mouse work in particular
- There’s also a place for primate work, although thresholds for that are higher given the animals they are
- But there’s some excellent human work that really needs funding
- Even though he was always well-funded, one of the things he experienced first hand was the frustration of wanting to do the coolest thing and having to take five years to ramp up to do it
- Meanwhile, there is a lot of human suffering
- There is also a lot to be gained from doing these studies right away
- Stanford has great channels for raising funds for doing that high ambition, high output work
- Andrew thinks he’s in a unique position to be able to understand the life of the researcher, and what he is doing is creating a system where someone can literally type out no more than half a page in 11-point font
  - And the last thing a researcher needs to do is spend time writing all the justification
  - He will raise funds for funding work though the podcast

***He has always hoped he could shape science policy at some point, and the things that need shaping to make big differences in discovery, curing disease, and laboratories are very simple***

**Money is necessary but not sufficient to make progress**

- More money simply gives you more opportunity to try things
- There’s never a case of too much money for doing research
- There is sometimes a dearth of excellent people, but that’s not a problem at Stanford and other places; there are many excellent places

> “*The more money that can go into research, the more progress that will be made, period*”‒ Andrew Huberman

**Andrew sees himself podcasting and also being a really strong advocate for directing money into research**

- We’re losing a lot of graduate students and postdocs and potential graduate students and postdocs
  - There’s a big strike right now in the UC system because they are paid garbage and many of them have kids
  - We’re going to lose entire generations of great discovery
- He is also trying to create endowments so that we can pay people a reasonable wage
  - It’s insane, most of the people holding the power to make these decisions wouldn’t live a day with that amount of money in their bank account because it would give them an autonomic shock to just know that they were not necessarily going to make it into the next week
- Andrew feels very strongly about giving people resources that allow them to flourish
  - This is very Ben Barres-ish

> “*Give people resources that allow them to flourish, that allow them to stay in touch with ‘the source’, if you will*”‒ Andrew Huberman

***If he can raise $1 billion for research in the next two years or five years, he thinks he’ll have a greater impact on science and discovery than if he’s writing his next*** [***R01***](https://en.wikipedia.org/wiki/National_Institutes_of_Health#Extramural_research)

## Andrew’s unique approach to communicating science and the issue of scientific illiteracy [2:30:00]

- Peter had six pages of single space type on things to talk about today, and they talked about zero of these
- He asks, “*When are you coming back to Austin so that we can actually do the podcast*”
  - Anytime; this could be part one

**Intro to a philosophical question**

- They discussed earlier how there’s really a **renegade spirit** that exists in some of the great minds
  - [Rick Rubin](https://en.wikipedia.org/wiki/Rick_Rubin) and [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) come to mind
- There’s no question that you need people who are willing to question everything
- It’s no small miracle that the Apple campaign of “think different” was arguably one of the most successful ad campaigns of all time
- But, we also have to reconcile that science requires a lot of fundamental knowledge to even give you the privilege to think differently
  - Before you do the PhD, you’ve done four years of undergraduate coursework, which is mostly learning in existing body of knowledge
  - You then spend two years [usually four to six] doing a PhD where you’re learning an existing body of knowledge in a much narrower area than your undergraduate, but at a much deeper level
  - You take a comprehensive exam (they didn’t even talk about how challenging the comps are, depending on the university especially) before you even earn the right to now go sit in the lab to start to think differently
    - Which by the way is essential
    - If you go into the lab, you can’t by definition have a PhD thesis that’s the same as somebody else’s; it has to be unique work
- This is what is very difficult about **communicating science to the public**
  - That line is difficult to explain
- It’s very easy in **social media** to just assume everybody’s an expert because there’s no real ability to distinguish between signal and noise
  - Or you could assume if somebody got something wrong that they’re wrong about everything else they’re saying (which is certainly not the case)
- Peter was interviewed on a podcast recently and someone posed the question to him around this and he didn’t have a great answer
- Peter thinks about his **purpose** in providing a sense of source
  - He hopes to get people to think about things

***Peter hopes to provide people with enough substrate in terms of both knowledge and mental models/ frameworks to have some critical thinking***

- He hopes people are being armed with a tool that will allow them to look at the world and claims
  - But he has no idea if he is able to do that
  - It’s a very difficult thing to do

**How do you see your role in addressing the crisis of scientific literacy that has led to a crisis of confidence?**

- Andrew thinks Peter is not only getting people to think differently (or more deeply), but he is also giving them very useful information
  - He says this as a consumer of the information Peter’s information, but also as somebody who pays a lot of attention to the landscape of this space
  - Peter’s impact is real and significant
- Andrew has long been interested in the **common themes** between different movements and cultures
  - He watched it happen in **skateboarding**
    - He knew well enough to know that he wasn’t going to play a major role
    - He probably could have run a company or been involved in that; and some of them are worth many hundreds of millions of dollars now
    - These companies run beautifully because they have a family feel
  - In the landscape of **science**, there are people in it just for ambition, and there are others who are in it for real passion (like Ben), and there is everything in between
  - Likewise within the **social media sphere and health education**, you’re seeing people that are just compelled to do it because they love it
    - They are also ambitious
    - Other people are purely ambitious, and you can tell because they’re grabbing onto every recent event as a way to get views and likes and grow their channels
  - The fate of the purely ambitious is obvious ‒ over time, it’s just going to end
    - They’re going to flame out
- The human aspect comes through when you think about these different universes or cultures, and it gives one answer to the question, “*What are we trying to do here?*”

**For Andrew, there are several things that are really like mantras**

- “*I want to communicate the beauty and utility of biology. I want to do that by being a teacher and to some extent a storyteller*”‒ Andrew Huberman
- He wants to be a giver
- Peter raises an important point, a formal rigorous education often involves not doing anything **creative**
  - Especially in biology
  - This is not necessarily the case in mathematics
    - [Ramanujan](https://en.wikipedia.org/wiki/Srinivasa_Ramanujan) didn’t have the formal education, it wasn’t necessary
    - He was able to derive the insights from [Gauss](https://en.wikipedia.org/wiki/Carl_Friedrich_Gauss) to [Newton](https://en.wikipedia.org/wiki/Isaac_Newton) to [Euler](https://en.wikipedia.org/wiki/Leonhard_Euler) all the way through
    - And literally in the dirt he was coming up with creative insights,
  - That is why mathematics and science are fundamentally very different things
    - Especially in biology; the fact set is unbearably large
- Andrew agrees, [Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) pointed out that unfortunately [taxonomy](https://en.wikipedia.org/wiki/Taxonomy) gets you nowhere
- Andrew could tell you the 20 or so different kinds of ganglion cells in the retina, how they code visual space, what they inform the brain likely or not
  - And the only thing that would’ve mattered is for you to understand that some cells sense motion, some cells sense contrast, some encode color information, and that it’s built up in a hierarchy pyramidal model to give you something like face recognition
  - It doesn’t matter if it’s the alpha cell, the beta cell, the theta cell, the schemata cell
- In biology, so much of it is showing some degree of ability in the taxonomy
  - It’s not useless because it sets up a common dialogue

***Taxonomy doesn’t teach you rulesets***

- Andrew doesn’t want to go back to the prefrontal cortex *per se*, but think about the [Stroop task](https://en.wikipedia.org/wiki/Stroop_effect) (illustrated below)

![](images/andrewhuberman/f1-andrewhuberman-1024x632.png)

**Figure 6. The Stroop task shows it is easier to name the color of a printed word when the word matches the color (top) than if it does not (bottom)**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Stroop_effect)

- If you can’t speak the language (that’s red) or recognize that 7+7 = 14 is just true
  - That’s not changing; there’s nothing creative about it

***But you can’t come up with alternate rulesets if you don’t have the basic substrates, the basic building blocks***

- Andrew looks at a high school degree and an undergraduate degree as developing the raw materials from which to then start resampling those raw materials into what is truly novel
  - This is what happens in a PhD
- Most PhDs are truly **novel** but *not* terribly **impactful** for their field
  - And most postdocs are like an attempt to show that you can do it twice
  - Then, you get your own laboratory, and there are some labs that survive very well by just turning a crank and doing the same thing over and over again

***The fundamental discoveries come from people really taking risk***

**In the social media space, there are a couple of different issues**

- Do people need to have a formal rigorous **education** in something?
  - Andrew would say yes, but we need to put air quotes around formal
  - You look at a guy like [Rick Rubin](https://en.wikipedia.org/wiki/Rick_Rubin), he doesn’t know what Rick’s undergraduate education was in, but he doubts it was in music producing
    - His “formal” rigorous education is in the real world of producing music
- Andrew would hope that the young person out there (or even the older person out there) who really wants to get good at science thinking, puts themselves through the hard filter that is a formal rigorous education in that thing

> “*The beauty of looking at things through the lens of biology or through the lens of science and experimentation is that really at its essence, your goal is to falsify your own what you think are best ideas*.”‒ Andrew Huberman

- This gets to the complete other end of the spectrum; Andrew brings it back to Ben’s comment to Peter when he had his epiphany (discussed earlier about weight loss on a keto diet), which is, “*The medical profession doesn’t know that much*”
  - So that the listener doesn’t assume for a moment we’re just sitting here being elitists, saying you shouldn’t be the ones talking about science if you don’t have a background
- It’s very clear that scientific literacy in the general public does not require a formal education in science, if you assume zero knowledge and infinite intelligence
  - Andrew thinks it was [Max Delbruck](https://en.wikipedia.org/wiki/Max_Delbr%C3%BCck) that said that

***Andrew believes that people are curious and that if you give them the raw materials to understand what you’re about to tell them, they can understand pretty much everything***

- There’s the whole [Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) quote of, “*If you can’t explain it to a six-year-old, then you don’t really understand it*.”
- You can take adults or younger people and educate them
  - You give them a minimum of [nomenclature](https://en.wikipedia.org/wiki/Nomenclature), and emphasize that the nomenclature isn’t really the point
- We call it **prefrontal cortex**, but we could have called it green monkey tree, it doesn’t matter
  - It’s a ruleset context appropriate setting machine in your brain, and it’s behind the forehead
  - It doesn’t even matter that it’s behind the forehead, but it helps you remember prefrontal
  - What is important is the algorithm that it uses
- In biology we’re always talking about processes, and one thing that is really important and can be communicated to the general public (regardless of educational background) is that ***most of the time when you’re paying attention to science, forget the nouns, focus on the verbs***
  - If you want to understand how the brain wires up, forget that it’s an axon, just understand an axon is like a wire
    - That helps you visualize it
  - Andrew can put in your head the ideas of a number of different processes that are involved ‒ going from sperm meets egg, to a baby and a brain
  - Why? Because it’s a bunch of **processes**, and when you understand one of them, you can more easily understand the next and the next
    - Taxonomy doesn’t do that
    - Knowing what one area of the brain is called doesn’t give you one shred of a hint of that a different brain area is called (it probably confuses you)

***Teaching the verbs in biology is necessary***

**For example**

- Andrew has talked about the importance of getting **morning sunlight**. Why?
  - Low solar angle sunlight has more yellow/ blue contrast
  - And even though you don’t perceive it through these cells, and you look at it through cloud cover
  - That yellow blue/ contrast is what activates the cells in the retina to say it’s morning
  - When the sun is overhead, there’s no yellow/ blue contrast
- You can take a picture of it with your phone and see, but what do you need people to understand?
  - You don’t need to see the sunrise, you need to see the sun rising (the verb)
  - You don’t need to see it across the horizon, you need to see it when it’s low in the sky
    - If people hear that and they then remember, “*Oh yeah, because that’s when it’s yellow and blue,*” now it doesn’t matter what the ganglion cells are called (melanopsin)
    - What you’ve got them on is a verb

***And when you teach people the verb action of biology, they start to understand the real mechanism and the real utility***

- No one gives a shit about the nouns; it doesn’t matter
  - Especially not to the general public that’s mostly trying to just think about health information

**We saw this during the pandemic**

- The problem with the vaccines is they showed these little movies with this ominous little spiky thing and here’s the spike protein when what people really wanted to know is:
  - How do I know it’s going to be safe?
  - What kind of safety is it going to afford me in terms of my health?
  - What are the probabilities?
    - This is an important point
    - Peter thinks the world would be a much better place if people knew freshman statistics and probability
- And then, even if when you told them that, a lot of people are still standoffish about it
- The way to understand **statistics**, of course you have to understand the mode, the median, etc.
  - But what’s really important is once you understand standard deviation, you want them to know what it represents ‒ it’s the verb in there
  - You don’t care if people know what one or two standard deviations from the mean is
- You also want them to understand what **probability** means
  - What does a 2% chance that something will happen mean?
  - The thing is either going to happen or not happen; it’s a binary outcome
  - Where does priority and value fit into that?
- Peter thinks part of why scientific communication got destroyed during the pandemic is you had people in charge treating everybody like idiots
  - They didn’t take the time to explain probabilistic things
    - Is the vaccine safe ‒ yes, on average
    - Is there a chance of an adverse outcome when you take a Tylenol or a baby aspirin
- The thing that keeps Peter up at night is, “*Why can’t we introduce nuance when it matters and not be fooled by noisy nuance that doesn’t matter, which people like to interject as a way to at the worst, hide their nefarious intentions, and at the best, miss the point?*”
- Andrew agrees, people were treated like idiots during the pandemic and they responded in a very angry way
  - When you treat people like idiots, they act like idiots or they get angry
  - It’s like a teenager who realizes that their parents don’t understand anything when they start seeing a lot of flip flopping in messaging
- When people understand or at least can visualize or experience the verb action of biology, they are forever changed
- If Andrew gives you 50 facts about the brain, it doesn’t change you, but if he explains the process underlying even just five of your daily experiences
  - Or what it means when you get tired and how to ameliorate that
  - What it means when you get stressed and how to deal with that

***If he teaches you the mechanisms that underlie those tools, then the tools are forever embedded in you***

- Now, one has to be very careful because the best cases where you can teach people something, it works the first time and every time
  - Like sunlight viewing, and in two, three days everything’s changed (if you’re doing that consistently at the right times)
  - Or certain patterns of breathing for stress mitigation
  - Or exercise
- But you have to be very careful because if you give people something with the promise that it works the first time and every time and it doesn’t, then you lose **trust**
- You have to build trust over time
- Once people understand mechanisms… and it must be the same way that physicians and sports psychologists start to see an interaction between two different people
  - It’s those Peanuts cartoons, the chatter between the two of them
- We need a better understanding of algorithms
  - You’re not going to teach somebody calculus by showing them a problem set and a solution
  - You’re going to teach them how you arrive at solutions to any problem set using a particular algorithm more or less

***One way Peter thinks about it (and in calculus specifically), is if you can come to understand things from first principles and never go into things where you have to memorize anything, the less you can rely on rote memory, the better***

§

## Selected Links / Related Material

**Andrew’s podcast**: [Huberman Lab](https://hubermanlab.com/) | [1:00]

**Nolan Williams reports transcranial magnetic stimulation is helpful for people with depression**: [Stanford Neuromodulation Therapy (SNT): A Double-Blind Randomized Controlled Trial](https://ajp.psychiatryonline.org/doi/10.1176/appi.ajp.2021.20101429) | *The American Journal of Psychiatry* (E Cole et al. 2021) | [23:30]

**Book about the sensory specializations of animals**: [*An Immense World*](https://www.amazon.com/Immense-World-Animal-Senses-Reveal/dp/0593133234/ref=sr_1_1?crid=2B5DOQDNMTDK8&keywords=an+immense+world&qid=1676658267&sprefix=an+immense+world%2Caps%2C111&sr=8-1) by Ed Young (June 2022) | [30:00]

**Experiment with a milkshake showing the effect of mindset**: [Mind over milkshakes: mindsets, not just nutrients, determine ghrelin response](https://pubmed.ncbi.nlm.nih.gov/21574706/) | *Health Psychology* (A Crum et al. 2011) | [1:02:15]

**Rick Rubin’s book on creativity**: [The Creative Act: A Way of Being](https://www.amazon.com/Creative-Act-Way-Being/dp/0593652886) by Rick Rubin (January 2023) | [1:05:30]

**Book about the history of Charles Manson**: [Charles Manson, A Chaos, Charles Manson, the CIA and the Secret History of the Sixties](https://www.amazon.com/Chaos-Charles-Manson-History-Sixties/dp/0316477559/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1677164495&sr=8-1) by Tom O’Neil (June 2019) | [2:00:15]

**Ben Barres obituary in** ***Nature***: [Ben Barres (1954–2017): neurobiologist who advocated for gender equality in science](https://www.nature.com/articles/d41586-017-08964-1) | *Nature* (A Huberman 2018) | [2:02:00]

**Biography of Steve Jobs**: [Steve Jobs](https://www.amazon.com/Steve-Jobs-Walter-Isaacson/dp/1451648537/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1677166250&sr=8-1) by Walter Isaacson (October 2011) | [2:04:45]

**Joe Rogan’s first podcast with Andrew**: [Joe Rogan Experience #1513 – Andrew Huberman](https://www.jrepodcast.com/episode/joe-rogan-experience-1513-andrew-huberman/) | Host Joe Rogan, [The Joe Rogan Experience](https://www.joerogan.com/) (July 23, 2020) | [2:19:15]

**Lex Fridman’s first podcast with Andrew**: [#139 – Andrew Huberman: Neuroscience of Optimal Performance](https://lexfridman.com/andrew-huberman/) | Host Lex Fridman, [Lex Fridman Podcast](https://lexfridman.com/podcast/) (November 16, 2020) | [2:19:15]

**Episode of the** ***Huberman Lab*** **with Karl Deisseroth**: [Dr. Karl Deisseroth: Understanding & Healing the Mind](https://hubermanlab.com/karl-deisseroth-understanding-and-healing-the-mind/) | Host Andrew Huberman, [Huberman Lab](https://hubermanlab.com/) (June 28, 2021) | [2:21:00]

**Episode of the** ***Huberman Lab*** **with Anna Lembke**: [Dr. Anna Lembke: Understanding & Treating Addiction](https://hubermanlab.com/dr-anna-lembke-understanding-and-treating-addiction/) | Host Andrew Huberman, [Huberman Lab](https://hubermanlab.com/) (August 16, 2021) | [2:21:00]

**Episode of the** ***Huberman Lab*** **with Andy Galpin**: [Dr. Andy Galpin: How to Assess & Improve All Aspects of Your Fitness](https://hubermanlab.com/dr-andy-galpin-how-to-assess-improve-all-aspects-of-your-fitness/) | Host Andrew Huberman, [Huberman Lab](https://hubermanlab.com/) (January 18, 2023) | [2:21:15]

**Episode of the** ***Huberman Lab*** **with Layne Norton**: [Dr. Layne Norton: The Science of Eating for Health, Fat Loss & Lean Muscle](https://hubermanlab.com/dr-layne-norton-the-science-of-eating-for-health-fat-loss-and-lean-muscle/) | Host Andrew Huberman, [Huberman Lab](https://hubermanlab.com/) (November 7, 2022) | [2:21:15]

**Rhonda Patrick’s podcast**: [Found My Fitness](https://www.foundmyfitness.com/episodes) | [2:23:00]

**Episode of** ***Joe Rogan Experience*** **with David Goggins**: [Joe Rogan Experience #1906 – David Goggins](https://www.jrepodcast.com/episode/joe-rogan-experience-1906-david-goggins/) | Host Joe Rogan, [The Joe Rogan Experience](https://www.joerogan.com/) (December 6, 2022) | [2:23:45]

**Andrew’s** ***Cell*** **paper on breathing patterns and anxiety**: [Brief structured respiration practices enhance mood and reduce physiological arousal](https://www.cell.com/cell-reports-medicine/fulltext/S2666-3791(22)00474-8?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS2666379122004748%3Fshowall%3Dtrue) | *Cell Reports Medicine* (M Yilmaz Balban et al. 2023) | [2:25:15]

§

## People Mentioned

- [Nolan Williams](https://profiles.stanford.edu/nolan-williams) (Associate Professor of Psychiatry and Behavioral Sciences at Stanford University and Director of the Stanford Brain Stimulation Lab) [9:30, 16:00, 18:15, 22:45, 2:25:45]
- [Arnold Kriegstein](https://neurograd.ucsf.edu/people/arnold-kriegstein-md-phd) (Professor of Neurology at UCSF and founder of the Eli and Edythe Broad Center of Regeneration Medicine and Stem Cell Research at UCSF) [13:15]
- [Ben Barres](https://en.wikipedia.org/wiki/Ben_Barres) (was a Professor of Neurobiology at Stanford University, characterized the interaction between neurons and glial cells) [27:45, 44:00, 1:48:15, 1:52:15, 1:59:15,
- [Jack Pettigrew](https://en.wikipedia.org/wiki/Jack_Pettigrew) (Australian neuroscientist, expert in vision) [36:00]
- [David Hubel](https://en.wikipedia.org/wiki/David_H._Hubel) (Neurophysiologist, expert in vision, Nobel laureate) [39:00]
- [Torsten Wiesel](https://en.wikipedia.org/wiki/Torsten_Wiesel) (Neurophysiologist, expert in visual information processing, Nobel laureate) [39:00]
- [Tomaso Poggio](https://mcgovern.mit.edu/profile/tomaso-poggio/) (Pioneered computational neuroscience, expert in visual systems) [41:00]
- [Russ Van Gelder](https://ophthalmology.washington.edu/faculty/russell-n-van-gelder-md-phd) (Professor and Chair of Ophthalmology at University of Washington ) [41:30]
- [Satchidananda Panda](https://www.salk.edu/scientist/satchidananda-panda/) (Professor and Chair of Regulatory Biology at the Salk Institute) [42:30]
- [Samer Hattar](https://www.nimh.nih.gov/research/research-conducted-at-nimh/principal-investigators/samer-hattar) (Senior Investigator and Chief of the Section on Light and Circadian Rhythms at the NIMH) [42:30]
- [Matt Walker](https://www.sleepdiplomat.com/professor) (Professor of Neuroscience and Psychology at UC Berkeley, sleep expert) [42:30]
- [Nancy Kanwisher](https://mcgovern.mit.edu/profile/nancy-kanwisher/) (Professor of Cognitive Neuroscience at MIT, expert in functional organization of the human brain) [45:30]
- [Samir Deeb](https://medgen.uw.edu/news/memoriam-samir-deeb) (was a Professor of Genome Sciences and of Medicine at University of Washington School of Medicine) [46:30]
- [Richard Axel](https://zuckermaninstitute.columbia.edu/richard-axel-md) (Professor of Pathology and Biochemistry at Columbia and Nobel laureate) [50:00, 2:23:00]
- [Linda Buck](https://www.fredhutch.org/en/faculty-lab-directory/buck-linda.html) (Professor at the Fred Hutch Cancer Center, Nobel laureate, expert in olfaction) [50:00]
- [Noam Sobel](https://www.sfari.org/people/noam-sobel/) (Head, Department of Neurobiology, Weizmann Institute of Science) [54:45]
- [Alia Crum](https://profiles.stanford.edu/alia-crum) (Professor of Psychology at Stanford, expert in changes in subjective mindsets) [1:02:00]
- [Rick Rubin](https://en.wikipedia.org/wiki/Rick_Rubin) (influential record Producer) [1:05:30, 1:10:30, 2:05:30, 2:21:30, 2:30:30, 2:38:30]
- [Harry Carlisle](https://senate.universityofcalifornia.edu/_files/inmemoriam/html/carlislehj.htm) (was a Professor at UC Santa Barbara, a biopsychologist and expert on the biological basis of motivated behaviors) [1:40:45]
- [Ben Reese](https://psych.ucsb.edu/people/emeriti/ben-reese) (Professor at UC Santa Barbara, an expert in retinal development) [1:42:30]
- [Jerry Jacobs](https://psych.ucsb.edu/people/emeriti/jerry-jacobs) (Professor at UC Santa Barbara, discovered evolution of color vision) [1:42:45]
- [Mike Mentzer](https://en.wikipedia.org/wiki/Mike_Mentzer) (bodybuilder) [1:44:45]
- [Carla Shatz](https://profiles.stanford.edu/carla-shatz?releaseVersion=10.5.1) (Professor of Biology at Stanford University, expert in the development of brain circuits) [1:47:00]
- [Barbara Chapman](https://neuroscience.ucdavis.edu/barbara-chapman-neuroscience-award) (was a Professor of Neurobiology, Physiology and Behavior at UC Davis, expert in brain development) [1:47:15]
- [David Corey](https://brain.harvard.edu/?people=david-p-corey) (Professor of Neurobiology at Harvard) [1:52:45]
- [Botond Roska](https://iob.ch/people/botond-roska) (Professor of Science at the University of Basel, expert in human retina visual circuits) [1:53:30]
- [Karl Deisseroth](https://profiles.stanford.edu/karl-deisseroth) (D.H. Chen Professor of Bioengineering and of Psychiatry and Behavioral Sciences at Stanford) [1:54:00; 2:21:00]
- [Steve Jobs](https://en.wikipedia.org/wiki/Steve_Jobs) (was the co-founder and CEO of Apple) [2:04:45]
- [Ryan Soave](https://www.ryansoave.com/about) (trauma therapist) [2:17:30]
- [Pat Dossett](https://www.linkedin.com/in/patdossett) (Co-founder and CEO of [Madefor](https://getmadefor.com/)) [2:18:00]
- [Joe Rogan](https://www.joerogan.com/) (stand-up comedian and podcaster)
- [Lex Fridman](https://lexfridman.com/) (podcaster and research scientist at MIT)
- [Josh Gordon](https://www.nimh.nih.gov/about/director) (Director of the National Institute of Mental Health) [2:20:15]
- [Tim Ferriss](https://tim.blog/about/) (Podcaster, author, entrepreneur) [2:22:45]
- [David Spiegel](https://profiles.stanford.edu/david-spiegel) (Professor and Associate Chair of Psychiatry & Behavioral Sciences and Director of the Center on Stress and Health, and Medical Director of the Center for Integrative Medicine at Stanford) [2:25:45]
- [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) (theoretical physicist) [2:30:45, 2:36:15, 2:50:30]

§

![](https://peterattiamd.com/wp-content/uploads/2023/04/bio-pic-andrewhuberman-500x500.jpeg)

##### Andrew Huberman, Ph.D.

Andrew Huberman earned his Bachelor’s degree from the University of California, Santa Barbara. He went on to earn a Master’s degree in Neurobiology and Behavior from the University of California, Berkeley, and a PhD in Neuroscience from the University of California, Davis. He completed his postdoctoral training at Stanford University.

Dr. Huberman is currently an Associate Professor of Neurobiology and an Associate Professor (by courtesy) of Psychiatry and Behavioral Sciences at Stanford University. His laboratory studies neural regeneration with the goal of developing treatments to prevent and reverse vision loss. They also study neuroplasticity and circuits for anxiety and visually-driven autonomic arousal.

In 2021 Andrew started the [*Huberman Lab* podcast](https://hubermanlab.com/) where he discusses neuroscience and the connections between the brain, our organs, our perceptions, our behaviors, and our health. This has become one of the top-10 podcasts on Apple Podcasts and Spotify. [[Stanford](https://med.stanford.edu/profiles/andrew-huberman#bio)]

Twitter: [@hubermanlab](https://twitter.com/hubermanlab?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

Instagram: [hubermanlab](https://www.instagram.com/hubermanlab/?hl=en)