# #25 – Scott Harrison: transformation, finding meaning, and taking on the global water crisis

**Source:** [https://peterattiamd.com/scottharrison/](https://peterattiamd.com/scottharrison/)

---

In this episode, Scott Harrison, founder of charity: water, discusses his radical personal transformation from club promoter with substance abuse problems to a humanitarian, successful CEO, and one of the happiest people Peter knows.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/scottharrison/the_Drive_public.png)

Play

#25 - Scott Harrison: transformation, finding meaning, and taking on the global water crisis

#25 - Scott Harrison: transformation, finding meaning, and taking on the global water crisis

1x15s30s

0:002:18:40

## We discuss:

- How Scott and Peter met [3:45];
- Scott’s tragic family story that shaped his life and altered his trajectory [8:00];
- High school years, rebellion, and music [30:30];
- Life as a club promoter, drug use, soul-searching, and a change of heart [41:30];
- Mercy Ships [1:15:00];
- The amazing transformations of Mercy Ships and the parallels to his own transformation [1:28:00];
- Leveraging the art of storytelling to raise money and awareness while fighting temptations to fall into his previous life [1:33:30];
- Discovering the water crisis that led to charity: water [1:46:45];
- How the lack of trust in nonprofits can cripple charities [1:54:00];
- The four pillars of charity: water that helped it overcome the stigma of nonprofits and become successful [2:01:00];
- Where to learn more about Scott’s work and charity: water [2:12:30];
- Scott’s book recommendations [2:14:30]; and
- More great conversation.

§

## Show Notes

## How Scott and Peter met [3:45]

- Met through Peter’s patient at a meeting called Dialogue
- When Scott asked Peter’s opinion on a watch that won’t break the bank, without hesitation, Peter said, “Seiko Cocktail” (Figure 1)

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-175.png)

**Figure 1. Seiko Cocktail**. Image credit: [Hodinkee](https://www.hodinkee.com/articles/the-seiko-presage-cocktail-time-srpb43)

- Peter’s wife surprised Peter with the Seiko Cocktail just a few hours after telling Scott about it
- Peter then gave it to Scott, “He’s meant to have this watch”

## Scott’s tragic family story that shaped his life and altered his trajectory [8:00]

- Born in Philadelphia
- Dad sold power equipment, Mom was a writer for the [Philadelphia Inquirer](https://www.philly.com/) and local newspaper
- Moved to southern New Jersey when Scott was 4 years old
- There was a carbon dioxide leak at their new home and on New Years Day, 1980, his mom collapsed from high levels of [carboxyhemoglobin](https://en.wikipedia.org/wiki/Carboxyhemoglobin) in her blood (25x the normal level)
- Mom’s immune system was irreparably destroyed
- She developed an environmental illness called [Multiple chemical sensitivity](https://en.wikipedia.org/wiki/Multiple_chemical_sensitivity)
- She was allergic to almost anything beyond basic purified air (e.g., perfume, soap, car fumes, new book smell, radio waves)
- The whole family had to wash their clothes in baking soda to avoid odors
- Her diet became so extremely limited to just a handful of items
- His mom had to live in a “safe room” for the rest of her life, which was basically a cot inside a small bathroom
- Scott became a caregiver at a very young age
- His mom’s condition was so rare and extreme that many people started to think it was all in her head ([idiopathic pain](https://www.verywellhealth.com/what-is-idiopathic-pain-2564613))
- Even Scott started to believe his mom was crazy (when he was a teenager)
- Peter theorizes that Scott may have been traumatized by enmeshment

For more on trauma and enmeshment see the episode of The Drive with [Corey McCarthy](https://peterattiamd.com/coreymccarthy/) as well as the episode with [Paul Conti](https://peterattiamd.com/paulconti/)

Coping with the physical and emotional pain

- Scott started to resent his situation by the time he was in his adolescent years
- Missed the period of life with no responsibility
- Forced into the caregiver role
- Couldn’t bring friends into the house
- How did mom cope with the emotional pain?
- The family was deeply spiritual and religious
- Unbelievable faith, read the Bible daily
- “A remarkable extreme version of stoicism,” says Peter
- The belief that challenges make us better, can’t sharpen the knife without these events
- She believed that, like Jesus who suffered, there was a reason for her suffering
- She would literally praise God for things like the fabric softener, which would make her sick, trying to stay positive through the suffering
- But Scott started to hate church and religion
- He would even pretend to not hear his mom calling for him when she needed something (Peter believes it was Scott trying to protect himself, in a way, from the pain and trauma that had been inflicted on him from being forced into a caregiver role at such a young age)

## High school years, rebellion, and music [30:30]

- Now it is the mid-90s and Scott immediately falls in with the wrong crowd in high school
- Joined a band (Sunday River) as the keyboard guy and band manager
- They landed gigs at the famous venues [CBGB](https://en.wikipedia.org/wiki/CBGB) and the [Wetlands](https://en.wikipedia.org/wiki/Wetlands_Preserve)
- Was determined to make a record and this took precedence over school
- Barely graduated high school with no plans to pursue a college degree
- Moved to NYC by himself in 1994, to Greenwich Village to be close to the music scene
- Started working at [Sam Ash](https://www.samash.com/) for pocket money and ultimately decided to take classes part-time at NYU and got a degree in communications with the “bare minimum effort”
- Ironically, he’s now a prized alumnus of NYU and even [made a video](https://video.alumni.nyu.edu/detail/videos/nyu-alumni-changemakers/video/5824430445001/nyu-alumni-changemaker:-scott-harrison-cas-98?autoStart=true) for a recent commencement ceremony
- Not long after moving to NY, his band broke up (a lot of drugs, didn’t really like each other)
- But he was making decent money selling stereo equipment

## Life as a club promoter, drug use, soul-searching and a change of heart [41:30]

Life as a club promoter

- Got a job as a club promoter which involved filling the club with “beautiful” paying customers
- To be successful it was all about networking, you’d have to go out every night and just strike up conversations and promote your club
- Pre-email, it was all about hitting the phones all day long after late nights at the clubs
- Started emailing as soon as it was doable, open rate was 100% (nowadays *maybe* 1-5%)
- Scott finds major success as a promoter for [Nell’s](https://en.wikipedia.org/wiki/Nell%27s), he even had his own event called “Voices at Nell’s” where he was able to book big names like Mick Jagger, Stevie Wonder, Chaka Khan, and Prince
- Eventually transitioned to club promotion in the fashion scene because there was more money
- Scott was one of the pioneers of what is commonly known now as bottle service and coined his events as “Models and bottles”
- It was almost like a matchmaking service between wealthy men and models
- Nightclub promoters would get paid by taking a cut of the total business of the night (15-20%)

Dark habits that come with the territory

- Nearly impossible to avoid drugs and drinking
- Smoking, drinking, sex, gambling, cocaine, weed, ecstasy, and MDMA were all part of the life
- Interestingly, most would avoid heroin as it is so common to overdose
- Unhealthy behaviors such as late dinners at 10 PM, the club at 12 AM and partying all night, take cocaine to stay awake, take Ambien to fall asleep
- While it may sound glamorous to some, Scott says there was a feeling of emptiness

Periodically he would visit his parents

- Every couple of months, for 48 hours, put on pure clothes laid out in the garage, sometimes a gown or hospital scrub
- Parents were concerned as Scott was living out their worst nightmare

Peter asks, were you happy?

- “I thought I was”
- Top model girlfriend, fancy car, Rolex, loft with a grand piano
- It got old over time, he was trashing his body and the bodies of those around him, he smoked about 60 cigarettes a day
- Stumbling home at 11 AM seeing people going about their day
- One day half his body started going numb and doctors had no explanation for him
- This lead to internal conversations about his mortality, *what is he doing with his life?*

For more on true happiness and finding fulfillment, see the episode of [The Drive with Tom Bilyeu](https://peterattiamd.com/tombilyeu/)

Soul-searching

- The culmination of things led to a kind of soul searching
- Scott felt dirty, like a degenerate, a hedonist
- Starting reading *The Pursuit of God*
- Spiritually and morally taking stock of his life
- Had seen firsthand that money was never enough, wealthy men would run off on their wife, kids would not talk to them
- “A lot of brokenness”
- Wanted to find his way back to the moral foundation of the way he grew up
- At 28, he came to see Jesus very differently, as someone who was challenging the establishment, fighting against religiosity and oppression of the religious leaders, preaching purity, absolute love

A change of heart

- Scott starts to dial back the substance abuse and partying
- Goes to church again
- Most importantly, his intentions have changed
- But with no true friends to speak to, he has kept his change of heart to himself
- Wrestling with demons himself

For more information about the dangers of suffering in silence and the importance of community see the episode of [The Drive with psychiatrist Paul Conti](https://peterattiamd.com/paulconti/)

- The numbness just stopped, as quickly as they started
- Needed out of the environment but he had nobody to help him and cry to and talk to except for God
- One day he decided to take some time off
- Packed iPod, a bottle of liquor, and the Bible, rented a blue Ford Mustang, and just drove “north”
- Found himself in a dial-up internet cafe in Greenville, Maine on Moosehead Lake filling out as many applications to volunteer as possible at all the humanitarian organizations
- Probably due to his suspect background as a club promoter, only one organization gave him a chance, Mercy Ships

## Mercy Ships [1:15:00]

Mercy Ships is an organization that outfits massive vessels into state-of-the-art hospital facilities and sails to countries that lack access to first-rate medical care.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-176.png)

**Figure 2. An inside look at the Africa Mercy.** Image credit: [Mercy Ships](https://www.mercyships.org/blog/an-inside-look-at-the-africa-mercy/)

- Scott was hired as the photographer and tasked with documenting all the amazing work being done by the crew on Mercy Ships
- The night before departure, he decided to have one more night of drinking and smoking and then quit for good, “a clean break”
- In 14 years since that moment, he has not once relapsed, he only casually drinks beer and red wine now
- What was the withdrawal like? Peter asks
- “So hard, so hard”
- What allowed him to walk away and stay clean?
- The environment, Christian doctors, the new norm was being healthy, up early, saving people’s lives in the most profoundly and visually evident way possible

Details of Scott’s ship

- Scott’s ship was the [Anastasis](https://www.mercyships.org/who-we-are/our-ships/the-anastasis/) between October 2004 and June 2005
- Tasked with stopping in Benin for several months before moving on to Liberia for a total of 12 months
- Doctors were specialized in [maxillofacial surgery](https://en.wikipedia.org/wiki/Oral_and_maxillofacial_surgery), cleft lips, fixing cataracts, etc.
- 42 beds
- 3 or 4 operating theatres
- Only working CT scan in 4 neighboring countries when they sailed into Liberia
- High-quality medical staff, all volunteers
- Scott believes he had the best job, getting to document all the “life-saving wonder”
- 1,500 surgery slots to fill

A profound moment for Scott

- Scott wondered if they would be able to fill all 1,500 surgery slots
- But there were over 5,000 people waiting in line when they arrived at the initial screening on day 1 and he soon realized they would be *turning away* thousands of people
- Local doctors could be trained, however, there were very few of them and not enough facilities
- In Liberia, for example, there’s only 1 doctor per 50,000 people (the US is 1 for every 300)
- Scott wept for 40% of the first day, he wasn’t prepared for what he was going to see, kids choking on 4 lb benign tumors on their face, burn victims, smells of rotting flesh
- But he did his job, taking photos of everything

## The amazing transformations of Mercy Ships and the parallels to his own life transformation [1:28:00]

Of the thousands of amazing stories and transformations, there are two that really stood out in Scott’s mind

**Alfred**

- On day one of screening, Scott met a little boy name [Alfred](https://www.onamercyship.com/alfred/alfred3.html) with a massive ameloblastoma on his face that was literally choking him
- Scott took photos during the procedure inside the operating theater
- 2 weeks later Scott got to take him home and was documenting the boy’s return to his village
- The villagers surrounded the boy who they thought was cursed for dead
- In total awe, they lined up to see and touch the boy’s face
- Scott realized that “wow, we get to do this 1,500 times”
- Scott was even able to see the parallels to his own life, Scott’s radical life change from degenerate to humanitarian was analogous to the radical physical change of the patients

Read Alfred’s [full story](https://mercyglobal.serverbox.net/alfred/alfred_story.htm)

**A young woman with cataracts**

- A young woman became blind in her 20s due to huge, untreated cataracts
- Only took about 15 minutes inside the operating room to remove cataracts and fix her eyes
- 2 days later the bandages come off, and Scott is snapping pictures
- The woman starts to scream with joy, tackles Scott, hugging everyone
- Total “euphoria”
- Peter asks if this rekindled Scott’s childhood desire to be a doctor
- Scott felt as though he was living vicariously through the doctors

Read other stories and see more powerful photos on [Scott’s website](https://www.onamercyship.com/)

## Leveraging the art of storytelling to raise money and awareness while fighting temptations to fall into his previous life [1:33:30]

- While still in Liberia, Scott began blasting his contact list via email sharing the stories of Mercy Ships
- He [created a blog](https://www.onamercyship.com/) for his contacts to be able to follow along
- He got an amazing response from people who wanted to help
- His subscribers grew and grew over the year
- Scott believes his photos were “so arresting or disrupting due to the extreme nature of them,” before and after photos of giant tumors now removed, cataracts like saucers then gone
- Scott quotes [Carl Jung](https://en.wikipedia.org/wiki/Carl_Jung), *“Transformation can only take place in the presence of images”*

Adjusting to sobriety and temptations in NY

- He felt as if he was doing the complete opposite of his previous, self-serving life
- Literally paying money ($500 per month) to volunteer to help others
- Scott said that while on Mercy Ships, the transition was easy for him because he was so busy in a different direction, his entire environment had changed in a positive way (like going from the [Death Star](https://en.wikipedia.org/wiki/Death_Star) to being surrounded by light)
- In Peter’s experience with treating heroin addicts, he agrees it comes down to the environment, addicts can’t go back to where they came from, they need a new life, new friends, a new place to live
- Upon his return to NY, all the temptations were staring him in the face
- But even after restarting his job as a club promoter, he managed to remain sober and determined to follow his new path
- Scott gives credit to the new testament parable, [The Parable of the Prodigal Son](https://en.wikipedia.org/wiki/Parable_of_the_Prodigal_Son), for helping to forgive himself and stay the course

Raising money for Mercy Ships

- Scott put together a gallery/exhibition with all his photos and documentation of his time on Mercy Ships
- He tapped into all his old contacts and was able to raise over $100,000
- He was even able to convince people who were initially skeptical of charities that they could trust him
- Realized at this point that he had a gift for telling stories and raising money

## Discovering the water crisis that led to charity: water [1:46:45]

- In mid-2005, Scott goes back to Liberia for another 8 months
- This time he got permission to explore more of the country off of the ship
- In this process, he comes across the water crisis
- Turns out 50% of the people in Liberia didn’t have clean water
- People were drinking from swamps and brown muddy rivers filled with algae and worms

Advice from a mentor

- Dr. Gary Parker, a California surgeon who had initially signed up for a 3-month stint, had been there for 21 years, a “lifer”
- He encouraged Scott, if you want to really make an impact, you should follow this clean water idea, to bring health to the world and affect millions/billions
- Scott knew he wasn’t going back to his former life, so he decided to go all in and give it a shot

Scott was on a mission

- Back in NY, nearly broke, Scott was crashing on a friend’s couch
- A friend was doing heroin at the time with friends, so not an ideal living situation, but it was free
- *“I was on a mission, Peter, from day 1, I was like ‘I’m gonna be the clean water fighter. I’m gonna fight for clean water and therefore I’m going to be potentially the most effective doctor that the world has ever seen if I could get millions, tens of millions, maybe hundreds of millions of people the most basic need for health”*
- Scott began learning as much as possible
- Flying around meeting with water organizations
- Reading everything he could on the global water crisis
- Started traveling around to Africa
- But being broke created a challenge, he first filed for [501(c)(3)](https://en.wikipedia.org/wiki/501(c)(3)_organization), and then began raising money from people who believed in him even before his programs were developed
- He was basically getting the equivalent of VC money and angel investor money but for his charity “start-up”
- Scott officially started [charity: water](https://www.charitywater.org/) with a very clear mission: Bring clean drinking water to everyone on the planet

## How the lack of trust in nonprofits can cripple charities [1:54:00]

Scott had a big observation from the start: it was not going to be easy to raise money because of the general lack of trust in charities from the donors’ perspectives.

- *Where the money was going? What impact was it actually having? Is there a lot of overhead? Is the CEO getting paid too much?*
- Peter says that it may sound surprising to some, but in his business of fundraising he noticed that Americans were the most generous, with New Yorkers being the most generous of all

Using transparency to combat skepticism

- Borrowing an idea from [Paul Tudor Jones](https://en.wikipedia.org/wiki/Paul_Tudor_Jones), the founder of [Robin Hood Foundation](https://en.wikipedia.org/wiki/Robin_Hood_Foundation), Scott made a promise to the public that all money given to charity: water would directly fund water projects (as opposed to overhead and salaries)
- Scott built in this transparency by creating two separate bank accounts, he would raise money for overhead completely separately from the public donations for the actual programs
- Peter calls this idea of creating two separate streams “brilliant”

The stigma around the word “overhead”

- Peter interjects to make an important point, *“overhead is not a ‘dirty term’”*
- There is a must-watch video on this topic, a great [TED Talk](https://www.ted.com/talks/dan_pallotta_the_way_we_think_about_charity_is_dead_wrong?language=en) by [Dan Pallotta](https://twitter.com/danpallotta?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)
- Peter and his wife have decided to only support 100% overhead with their charitable donations
- *“Every dollar we give, we give directly to salary-supportive people that we believe in doing charity”*
- And they do this because they understand it is much easier to fundraise on the programmatic side
- Peter says that if the individual has an easier life, they will have the ability to do much better work

## The 4 pillars of charity: water that helped it overcome the stigma of nonprofits and become successful [2:01:00]

Pillar #1: 100% of the money donated goes towards the program

- charity: water will even pay the credit card fees
- The 2 bank accounts allow for all the money to be applied toward programs

Pillar #2: Show exactly where the donation money went

- Using satellites, charity: water can show actual proof with images of the well that your money helped to build, for example
- Complete transparency overcomes the lack of trust

Pillar #3: Build an iconic brand that feels different than the typical charity

- Historically, charities have used shame and guilt and what Scott calls “toxic marketing” to get people to donate (remember the [Sally Struthers commercials](https://www.youtube.com/watch?v=ePENcrE_xcQ) from the 80s?)
- Stopped using the term “give back” which implies that you have “taken” something so you must give out of “debt” or “obligation”
- Instead, the brand should be hope-based, inspired
- The message of charity: water in Scott’s words: *“We believe you have a mind-blowing capacity for compassion and empathy. We believe your capacity to be deeply generous…and help people you don’t have to help, people you don’t have a debt or an obligation to help but you can end the suffering because you choose to. And you’ll be blessed and possibly redeemed from moving from selfishness and accumulation to giving to others”*

Pillar #4: Have the local community build and complete the actual work

- For the work to be sustainable and culturally appropriate, it had to be done by locals
- Find the locals, scale them, and give them the credit

Scott summarizes by saying that charity: water’s role is to:

- Raise awareness
- Build a movement of people
- Raise money as efficiently and transparently as possible
- And have all the work be done by the locals leading their communities and countries forward

## Where to learn more about Scott’s work and charity: water [2:12:30]

The organization’s website: [charitywater.org](https://www.charitywater.org/)

Scott’s book: [Thirst](https://www.amazon.com/Thirst-Story-Redemption-Compassion-Mission/dp/1524762849/ref=sr_1_1?ie=UTF8&qid=1539792626&sr=8-1&keywords=thirst+by+scott+harrison&dpID=417p6Ubf80L&preST=_SY344_BO1,204,203,200_QL70_&dpSrc=srch) (all proceeds go to the organization)

Various talks online

- [Scott Harrison | INBOUND 2018 Keynote](https://www.youtube.com/watch?v=V4E1t2yIZlc)
- [Scott Harrison: Thirsting for a Life of Service](https://www.youtube.com/watch?v=HeiR9Bidnh4)
- [Scott Harrison’s keynote speech at the NYU Entrepreneurs Festival](https://www.youtube.com/watch?v=5XFlEm0YoHo)

Social media for charity: water

- Facebook page: [charity: water](https://www.facebook.com/charitywater/)
- Instagram: [@charitywater](https://www.instagram.com/charitywater/?hl=en)
- Twitter: [@charitywater](https://twitter.com/charitywater?lang=en)
- LinkedIn: [charity: water](https://www.linkedin.com/company/charity-water)
- Snapchat: [charitywater](https://www.snapchat.com/add/charitywater)
- YouTube: [charitywater](https://www.youtube.com/user/charitywater)

## Scott’s book recommendations [2:14:30]

1. [White Man’s Burden](https://www.amazon.com/White-Mans-Burden-Efforts-Little/dp/1594200378/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by [Bill Easterly](https://twitter.com/bill_easterly?lang=en)
2. [Practicing the Presence of God](https://www.amazon.com/Practice-Presence-God-Brother-Lawrence/dp/1515436888/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by [Brother Lawrence](https://en.wikipedia.org/wiki/Brother_Lawrence)
3. [The Character of Virtue: Letters to a Godson](https://www.amazon.com/Character-Virtue-Letters-Godson/dp/0802875793/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by [Stanley Hauerwas](https://en.wikipedia.org/wiki/Stanley_Hauerwas)

§

§

## Selected Links / Related Material

**Tim Ferriss podcast episode with amazing philanthropist, Cat Hoke**:[The Tim Ferriss Show: Catherine Hoke — The Master of Second Chances (#293)](https://tim.blog/2018/01/21/catherine-hoke/) | Tim Ferriss ([tim.blog](https://tim.blog/)) [2:15]

**Peter’s favorite watch with price in mind**: [Seiko Cocktail](https://seikousa.com/collections/presage) | ([seikousa.com](https://seikousa.com/)) [4:00]

**Diagnosis of Scott’s mom after overexposure to carbon dioxide**: [Multiple chemical sensitivity](https://en.wikipedia.org/wiki/Multiple_chemical_sensitivity) | ([wikipedia.org](https://www.wikipedia.org/)) [12:00]

**One of the five roots of trauma**: [Enmeshment](https://en.wikipedia.org/wiki/Enmeshment) | (wikipedia.org) [25:00]

**Episode of The Drive with Corey McCarthy that defines enmeshment**: [Corey McCarthy: Overcoming trauma, dealing with shame, finding meaning, changing the self-narrative, redemption, and the importance of gratitude (EP.12)](https://peterattiamd.com/coreymccarthy/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) [25:00]

**Famous venture where Scott’s high school band performed**: [CBGB](https://en.wikipedia.org/wiki/CBGB) | ([wikipedia.org](https://www.wikipedia.org/)) [34:00]

**Famous venue where Scott’s high school band performed**:[The Wetlands](https://en.wikipedia.org/wiki/Wetlands_Preserve) | ([wikipedia.org](https://www.wikipedia.org/)) [34:00]

**The blizzard in New York in 1996**: [North American blizzard of 1996](https://en.wikipedia.org/wiki/North_American_blizzard_of_1996) | ([wikipedia.org](https://www.wikipedia.org/)) [38:50]

**Scott’s video for the recent commencement ceremony at NYU**: [NYU Alumni Changemaker: Scott Harrison (CAS ’98)](https://video.alumni.nyu.edu/detail/videos/nyu-alumni-changemakers/video/5824430445001/nyu-alumni-changemaker:-scott-harrison-cas-98?autoStart=true) | ([nyu.edu](https://www.nyu.edu/)) [40:25]

**Famous nightclub where Scott worked**: [Nell’s](https://en.wikipedia.org/wiki/Nell%27s) | (wikipedia.org) [44:45]

**Episode of The Drive with Tom Bilyeu discussing finding fulfillment and true happiness**: [Tom Bilyeu: nutrition, fasting, meditation, mindset, immortality, and the secret formula of fulfillment (EP.08)](https://peterattiamd.com/tombilyeu/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) [55:40]

**Uruguay town where Scott had a revelation that he needed to get out of the life of club promotion**: [Punta del este](https://en.wikipedia.org/wiki/Punta_del_Este) | ([wikipedia.org](https://www.wikipedia.org/)) [1:01:00]

**Book Scott began reading when trying to find his way back to virtue**: [The Pursuit of God](https://www.amazon.com/Pursuit-God-W-Tozer/dp/1613828918/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by A.W. Tozer | (amazon.com) [1:03:40]

**Episode of The Drive with Paul Conti on the danger of suffering in silence and the importance of community**:[Paul Conti, M.D.: trauma, suicide, community, and self-compassion (EP.15)](https://peterattiamd.com/paulconti/) | Peter Attia ([peterattiamd.com](https://peterattiamd.com/)) [1:08:00]

**The charity Scott worked for about 2 years**: [Mercy Ships](https://www.mercyships.org/) | ([mercyships.org](https://www.mercyships.org/)) [1:15:00]

**The Mercy Ship Scott was aboard**: [Anastasis](https://www.mercyships.org/who-we-are/our-ships/the-anastasis/) | ([mercyships.org](https://www.mercyships.org/)) [1:15:00]

**Specialization of the doctors on Mercy Ships**: [Maxillofacial surgery](https://en.wikipedia.org/wiki/Oral_and_maxillofacial_surgery) | ([wikipedia.org](https://www.wikipedia.org/)) [1:22:15]

**The blog Scott created to document the stories and people from Mercy Ships**: [Scott’s blog](https://www.onamercyship.com/) | ([onamercyship.com](https://www.onamercyship.com/)) [1:28:00]

**The story of Alfred**: [Alfred by grace.](https://mercyglobal.serverbox.net/alfred/alfred_story.htm) | Scott Harrison ([onamercyship.com](https://www.onamercyship.com/)) [1:28:00]

**New Testament parable that helped keep Scott on the right path**: [The Parable of the Prodigal Son](https://en.wikipedia.org/wiki/Parable_of_the_Prodigal_Son) | ([wikipedia.org](https://www.wikipedia.org/)) [1:42:45]

**Charity with a unique fundraising approach that Scott modeled when creating charity: water**: [Robin Hood Foundation](https://en.wikipedia.org/wiki/Robin_Hood_Foundation) | (wikipedia.org) [1:56:15]

**Great TED Talk by Dan Pallotta on nonprofits**: [The way we think about charity is dead wrong](https://www.ted.com/talks/dan_pallotta_the_way_we_think_about_charity_is_dead_wrong?language=en) | Dan Pallotta ([ted.com](https://www.ted.com/)) [1:58:00]

**Sally Struthers commercials from the 1980s**: [Sally Struthers Christian Children’s Fund Commercial (1987)](https://www.youtube.com/watch?v=ePENcrE_xcQ) | mycommercials ([youtube.com](https://www.youtube.com/)) [2:03:15]

**Scott’s new book**: [Thirst: A Story of Redemption, Compassion, and a Mission to Bring Clean Water to the World](https://www.amazon.com/Thirst-Story-Redemption-Compassion-Mission/dp/1524762849/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Scott Harrison | ([amazon.com](https://www.amazon.com/)) [2:12:30]

**Scott’s various talks online**: [2:12:30]

- [Scott Harrison | INBOUND 2018 Keynote](https://www.youtube.com/watch?v=V4E1t2yIZlc) | INBOUND (youtube.com)
- [Scott Harrison: Thirsting for a Life of Service](https://www.youtube.com/watch?v=HeiR9Bidnh4) | Stanford eCorner (youtube.com)
- [Scott Harrison’s keynote speech at the NYU Entrepreneurs Festival](https://www.youtube.com/watch?v=5XFlEm0YoHo) | NYU Entrepreneurial Institute (youtube.com)

**Book recommendations by Scott**:

- [White Man’s Burden](https://www.amazon.com/White-Mans-Burden-Efforts-Little/dp/1594200378/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Bill Easterly | ([amazon.com](https://www.amazon.com/)) [2:14:30]
- [Practicing the Presence of God](https://www.amazon.com/Practice-Presence-God-Brother-Lawrence/dp/1515436888/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Brother Lawrence | ([amazon.com](https://www.amazon.com/)) [2:14:30]
- [The Character of Virtue: Letters to a Godson](https://www.amazon.com/Character-Virtue-Letters-Godson/dp/0802875793/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Stanley Hauerwas | ([amazon.com](https://www.amazon.com/)) [2:14:30]

§

§

## People Mentioned

- [Catherine Hoke](https://twitter.com/catherine_hoke?lang=en) (remarkable philanthropist) [2:15]
- [Tim Ferriss](https://twitter.com/timferriss?lang=en) (introduced Peter to Cat Hoke)[2:20]
- [Paul Attia](https://twitter.com/papaalphablog?lang=en) (attorney, Peter’s brother) [16:30]
- [Marcus Aurelius](https://en.wikipedia.org/wiki/Marcus_Aurelius) (stoicism) [27:45]
- [Seneca the Younger](https://en.wikipedia.org/wiki/Seneca_the_Younger) (stoicism) [27:45]
- [Stevie Wonder](https://en.wikipedia.org/wiki/Stevie_Wonder) (bought equipment from Scott, played at Scott’s event at Nell’s) [41:00]
- [Bret Easton Ellis](https://en.wikipedia.org/wiki/Bret_Easton_Ellis) (wrote books about nightclub life) [44:45]
- [Mick Jagger](https://en.wikipedia.org/wiki/Mick_Jagger) (big name that would come to his Voices at Nell’s events) [44:45]
- [Chaka Khan](https://en.wikipedia.org/wiki/Chaka_Khan) (big name that would come to his Voices at Nell’s events) [45:15]
- [Prince](https://en.wikipedia.org/wiki/Prince_(musician)) (big name that would come to his Voices at Nell’s events) [45:15]
- [Brian McKnight](https://en.wikipedia.org/wiki/Brian_McKnight) (big name that would come to his Voices at Nell’s events) [46:30]
- [Charles Taylor](https://en.wikipedia.org/wiki/Charles_Taylor_(Liberian_politician)) (dictator of Liberia) [1:17:45]
- [Alfred](https://www.onamercyship.com/alfred/alfred3.html) (amazing transformation story) [1:28:00]
- [Carl Jung](https://en.wikipedia.org/wiki/Carl_Jung) (quoted by Scott) [1:36:00]
- [Jeffrey Chodorow](https://en.wikipedia.org/wiki/Jeffrey_Chodorow) (donated food to Scott’s exhibitions) [1:45:30]
- [Dr. Gary Parker](https://mercyships.ch/en/dr-gary-parker_maxillo_facial_surgeon/) (Mercy Ship mentor to Scott) [1:48:15]
- [Paul Tudor Jones](https://en.wikipedia.org/wiki/Paul_Tudor_Jones) (Scott modeled his charity after Paul’s, Robin Hood Foundation) [1:56:15]
- [Dan Pallotta](https://twitter.com/danpallotta?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) ([TED Talk](https://www.ted.com/talks/dan_pallotta_the_way_we_think_about_charity_is_dead_wrong?language=en) about nonprofits) [1:58:00]
- [Sally Struthers](https://en.wikipedia.org/wiki/Sally_Struthers) (commercials with flies landing on the faces of kids) [2:03:15]
- [Nicholas Kristof](https://twitter.com/nickkristof?lang=en) (quoted by Scott, NY Times writer) [2:04:45]
- [Bill Easterly](https://twitter.com/bill_easterly?lang=en) (author of book recommend by Scott) [2:14:30]
- [Brother Lawrence](https://en.wikipedia.org/wiki/Brother_Lawrence) (author of book recommend by Scott) [2:14:30]
- [Stanley Hauerwas](https://en.wikipedia.org/wiki/Stanley_Hauerwas) (author of book recommend by Scott) [2:14:30]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/10/scott-bio-harrison-charitywater-500x281.jpg)

##### Scott Harrison

Scott Harrison is the founder and CEO of charity: water, a non-profit that has mobilized over one million donors around the world to fund over 29,000 water projects in 26 countries that will serve more than 8.4 million people. Harrison has been recognized on Fortune’s 40 under 40 list, Forbes’ Impact 30 list, and was ranked #10 in Fast Company’s 100 Most Creative People in Business. He is currently a World Economic Forum Young Global Leader and lives in New York City with his wife and two children. [[charitywater.org](https://www.charitywater.org/)]

Scott on Instagram: [@scottharrison](https://www.instagram.com/scottharrison/?hl=en)

Scott on Facebook: [ScottHarrisonCharityWater](https://www.facebook.com/scottharrisoncharitywater)

Scott on Twitter: [@scottharrison](https://twitter.com/scottharrison)

Scott on Wikipedia: [Scott Harrison](https://en.wikipedia.org/wiki/Scott_Harrison_(charity_founder))