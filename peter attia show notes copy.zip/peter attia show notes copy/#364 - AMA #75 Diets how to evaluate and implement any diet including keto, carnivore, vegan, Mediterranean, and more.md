# #364 – AMA #75: Diets: how to evaluate and implement any diet including keto, carnivore, vegan, Mediterranean, and more

**Source:** [https://peterattiamd.com/ama75/](https://peterattiamd.com/ama75/)

---

In this “Ask Me Anything” (AMA) episode, Peter explores how to determine the right diet for yourself rather than searching for a universal “best” diet. He begins by laying out five non-negotiable criteria that any sustainable eating pattern must meet—energy balance, metabolic health, adequate protein, micronutrient sufficiency, and long-term adherence—before introducing a practical rubric for evaluating different diets. Using this framework, Peter walks through the ketogenic, carnivore, vegan, and Mediterranean diets, highlighting their strengths, ideal candidates for each, and common pitfalls such as micronutrient gaps or adherence challenges. He explains why this guidance is aimed at people who feel overwhelmed by diet choices, not zealots defending a single approach, and provides practical advice on using tools like DEXA scans, lab markers, continuous glucose monitors, and symptom tracking to assess whether a diet is truly working.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #75 show notes page](https://peterattiamd.com/ama75/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- Peter’s family chess battle [A: 3:00, V: 1:27];
- Framing the diet discussion: moving past tribalism to practical frameworks for evaluating various dietary strategies [A: 5:00, V: 3:45];
- Peter’s high-level nutrition framework [A: 11:00, V: 1:20];
- Why diet is such a uniquely polarizing subject [A: 14:15, V: 14:15];
- The five non-negotiables that apply to any diet [A: 17:45, V: 18:23];
- How to think about energy balance in the context of evaluating a specific diet [A: 20:15, V: 21:10];
- How diet can address metabolic health [A: 21:45, V: 22:56];
- Protein as a dietary foundation [A: 23:30, V: 25:15];
- Micronutrient essentials: avoiding deficiencies in restrictive and processed diets [A: 24:45, V: 26:36];
- Why adherence and sustainability are essential for diet success [A: 27:15, V: 29:21];
- Examining the standard American diet through the five non-negotiables [A: 31:00, V: 33:57];
- The evaluation framework for specific diets [A: 33:30, V: 37:00];
- The ketogenic diet: defining ketosis, clinical origins, modern uses, and potential health benefits [A: 35:00, V: 38:33];
- The main strengths and weaknesses of the ketogenic diet [A: 43:00, V: 48:00];
- How to avoid micronutrient deficiencies while on a ketogenic diet [A: 47:15, V: 52:49];
- Electrolytes and fiber and the ketogenic diet: preventing magnesium loss and maintaining digestive health [A: 49:15, V: 55:22];
- Adherence challenges of the ketogenic diet [A: 51:30, V: 58:00];
- The carnivore diet: definition, motivations, anecdotal benefits, and possible mechanisms [A: 53:15, V: 59:58];
- The main strengths and weaknesses of the carnivore diet [A: 57:30, V: 1:05:03];
- Plant exclusion on the carnivore diet: nutrient gaps, gut changes, and unanswered questions [A: 1:03:15, V: 1:12:38];
- Adherence challenges of the carnivore diet [A: 1:04:45, V: 1:14:28];
- The vegan diet: definition, core beliefs, and various motivations for this strategy [A: 1:05:45, V: 1:15:46];
- The main strengths and weaknesses of the vegan diet [A: 1:09:15, V: 1:20:15];
- Adherence to the vegan diet: social acceptance, edge cases, and personal sustainability [A: 1:13:15, V: 1:24:40];
- The Mediterranean diet: definitional challenges, traditional patterns, and its relatively strong evidence base [A: 1:15:15, V: 1:26:57];
- Limitations of the Mediterranean diet: loose definitions and indulgence risks [A: 1:19:30, V: 1:31:45];
- Measuring diet success: why setting clear goals and tracking outcomes matter [A: 1:21:00, V: 1:33:51];
- Tracking body composition using DEXA scans [A: 1:22:15, V: 1:35:27];
- Tracking metabolic health: key blood tests and advanced glucose monitoring tools [A: 1:22:45, V: 1:36:07];
- Using elimination diets to identify food sensitivities that may cause digestive problems, autoimmune symptoms, or low energy [A: 1:23:30, V: 1:36:45];
- Evaluating “anti-inflammatory diets”: confirming inflammation through symptoms and hs-CRP testing [A: 1:25:15, V: 1:38:54];
- Final takeaways: flexibility, structure, and avoiding dogma in dietary choices [A: 1:27:00, V: 1:40:49]; and
- More.

---

The Peter Attia Drive

#364 – AMA #75: Diets: how to evaluate and implement any diet including keto, carnivore, vegan, Mediterranean, and more

---

## Show Notes


---

## Peter’s family chess battle [A: 3:00, V: 1:27]

Quick chess update (See [AMA #74](https://peterattiamd.com/ama74/) for previous chess talk):

- Peter’s family had an “in-house” chess tournament this weekend
- Peter made it to the finals with his youngest boy
- Peter was playing lights out until he made an idiotic blunder, and in a second, the game changed.
- Five moves later, it’s checkmate against Peter
- Nick pokes fun at Peter commenting: “*You started this by bragging about making it to the finals of an in-house chess tournament which was composed of three people. . .two of which can’t even drive yet.*”
- Peter claims there were more than 3 people: “*No, no, no. There were a few others. There were some other people in the tournament*.”
- Thankfully, Peter restrained himself and didn’t throw any pieces across the room

## Framing the diet discussion: moving past tribalism to practical frameworks for evaluating various dietary strategies [A: 5:00, V: 3:45]

Framing of the Episode

- Focus is not on which diet is “best,” but on how to evaluate diets pragmatically.
- This episode aims to help people navigate the overwhelming information on diets.
- The structure of the discussion:
- Start with five non-negotiables for any sustainable diet:
  - 1) Energy balance
  - 2) Metabolic health
  - 3) Adequacy of protein
  - 4) Micronutrient sufficiency
  - 5) Long-term adherence
- Use a framework for each diet:
  - Define the rules clearly
  - Identify strengths and who it suits best
  - Highlight weaknesses and pitfalls, plus how to mitigate them
- Apply the framework to four common diets: **ketogenic, carnivore, vegan, and Mediterranean**.
- End with practical takeaways for implementation and tracking progress.

Peter’s Reluctance and Motivation

- Peter admits he generally dislikes discussing diets because:
  - Conversations often degrade into tribal, moral, or religious-like arguments rather than scientific discourse.
  - He dislikes the fanaticism in diet culture.
- He was reluctant to record this episode but was convinced by:
  - Audience demand.
  - His team, especially Josh Roche, who framed it as targeting the 87% of confused, non-zealot individuals who just want clarity and practical guidance.
- Key mental shift: focus on the majority of people seeking common-sense frameworks, not extremists in dietary “camps.”

Nutrition vs. Diets

- Distinction Peter makes:
- Previous Nutrition AMA ([AMA #66](https://peterattiamd.com/ama66/) released in Dec. 2024) covered big-picture topics:
  - Is there a “best” diet?
  - Nutrition vs. exercise in health outcomes.
  - Protein requirements for maintenance vs. muscle growth.
- This episode focuses on dietary approaches themselves, their frameworks, and practical decision-making.
- Intention is to bridge the gap between nutritional biochemistry (his preference) and diet strategy/application (audience demand).

## Peter’s high-level nutrition framework [A: 11:00, V: 1:20]

**High-Level Nutrition Framework**

- Peter’s approach in medical practice:
  - Start by classifying nutritional status:
    - Over-nourished vs. under/adequately nourished
    - Adequately muscled vs. under-muscled
  - Add a second layer: metabolic health (healthy vs. unhealthy).
  - While correlated, over-nourishment doesn’t always equal poor metabolic health, and vice versa.

Greatest Risk Quadrant

- Over-nourished + under-muscled:
  - This combination puts individuals at highest risk for chronic disease.
  - Sadly, this is a large portion of the population.
  - Many in this group are also metabolically unhealthy.

![](https://peterattiamd.com/wp-content/uploads/2025/09/f1-quadrant-ama75.webp)

**Figure 1.** Two-by-two grid with muscle mass status at top and nourishment status along the side. After receiving DEXA measurements, each person can be classified within one of the four categories, which directs the subsequent interventions. [[source](https://peterattiamd.com/improving-body-composition/)]

- Primary needs for most people in this quadrant:
  - Reduce body fat (lower adiposity).
  - Increase muscle mass.
- [AMA #40](https://peterattiamd.com/ama40/) – case study for over-nourished + under-muscled person

[Framework](https://peterattiamd.com/my-nutritional-framework/) for Reducing Body Fat

- CR, DR, TR Framework (developed ~7–8 years ago):
  - CR – Caloric Restriction:
    - Focuses on how much you eat.
    - Doesn’t necessarily change food type or timing.
    - Most direct and effective approach, but also the hardest to sustain.
  - DR – Dietary Restriction:
    - Restricting specific macronutrients or food groups.
    - Examples: low-carb, low-fat, or low-animal protein diets.
    - Naturally tends to produce caloric restriction.
    - Most common method people use instinctively when trying to lose weight.
  - TR – Time Restriction:
    - Also known as intermittent fasting.
    - Limits eating window in the day, reducing total calorie intake.
    - Effectiveness increases as the window narrows.
  - See [AMA #72](https://peterattiamd.com/ama72/) for more on the CR/DR/TR framework

Dietary Restriction and “Diet Wars”

- DR is the most prevalent strategy.
  - Nearly everyone who has attempted weight loss has done it through dietary restriction in some form.
  - Far fewer have attempted pure caloric restriction (CR).
  - Time restriction (TR) has become more trendy in recent years.
- The prevalence of DR places it at the center of modern “diet wars.”

## Why diet is such a uniquely polarizing subject [A: 14:15, V: 14:15]

Why Diets Are So Polarizing

- Comparison to other interventions:
  - Tribalism exists in exercise but not in sleep.
  - Diet stands out as uniquely extreme and cult-like.
- Cultural and psychological factors:
  - Everybody eats — no avoiding it.
  - Diet is cultural, personal, and social.
  - Eating habits can act as markers of identity or status.

Role of Nutrition Research

- Nutrition research quality is generally poor:
  - Not due to lack of effort or competence of researchers.
  - The field is inherently difficult to study with rigor.
  - Results often lack the certainty needed to answer big questions.
- Limitations in answering critical questions:
  - Example: We can’t realistically randomize 10,000 people into different diets (keto, vegan, Mediterranean, carnivore) and follow them for 30 years.
  - Such a study could theoretically provide an answer, but it’s not feasible.

Individual Variability

- Even if large, long-term trials were possible, individual outcomes would still vary widely.
- Comparison to drug trials:
  - Even when dosage and drug are identical, genes, environment, and other inputs cause variability in results.
  - With diet, variability is likely greater than with drugs.

Podcast Goal Reiterated

- The goal is not to declare the “best” diet.
- Instead: provide frameworks for how to think about diets.
- Focus not only on the four diets covered (keto, carnivore, vegan, Mediterranean) but also on how listeners can evaluate future diets.

## The five non-negotiables that apply to any diet [A: 17:45, V: 18:23]

**Peter’s Five Non-Negotiables for Any Diet**

- Timeless principles:
  - These are fundamentals that were true 50 years ago and will still be true 50 years from now.
  - They form the foundation of dietary evaluation, regardless of trends or macros.

**1. Energy Balance**

- A diet must support energy balance.
- Both extremes are harmful:
  - Malnutrition (too few calories).
  - Overabundance (excess calories).
- Without energy balance, no diet can be considered successful.

**2. Metabolic Health**

- Distinct but related to energy balance.
- A person can be in caloric balance but metabolically unhealthy.
  - Example: calories come mostly from alcohol or candy bars.
  - Weight may look “normal,” but metabolic health is compromised.

**3. Sufficient Protein Intake**

- Essential for muscle protein synthesis and maintaining lean mass.
- Contentious topic for reasons that Peter criticizes as political and absurd.
- Protein adequacy is a physiologic requirement, not a political stance.

**4. Micronutrient Sufficiency**

- Adequate intake of vitamins, minerals, and trace elements.
- Often overlooked but vital for health.
- Will be discussed further in the episode.

**5. Long-Term Adherence & Social Sustainability**

- Even the “perfect” diet is useless if it cannot be followed long term.
- Adherence must be realistic for the individual’s lifestyle and social environment.
- Analogy: these five non-negotiables are like the foundation of a house.
  - The architectural style can vary, but without a solid foundation, the structure will collapse.

## How to think about energy balance in the context of evaluating a specific diet [A: 20:15, V: 21:10]

Energy Balance in Diet Evaluation

- Most common issue:
  - The majority of people experience positive energy imbalance (excess calories → weight gain).
  - Some experience negative energy imbalance (under-consumption → malnutrition/deficiency).
  - Both extremes are harmful.
- Tolerance and flexibility:
  - There’s no rigid “line in the sand” for perfect energy balance.
  - The human body is resilient and can tolerate a wide range before problems emerge.
- Achievability of energy balance:
  - Possible with virtually any diet type.
  - The key challenge is sustainability, not theoretical feasibility.
- Energy balance in practice vs. lab settings:
  - Lab setting (metabolic ward):
    - Strictly controlled calorie intake ensures energy balance.
    - Example: Even on poor-quality food, calorie-controlled conditions could maintain balance.
  - Real-world setting:
    - Poor-quality foods may disrupt hunger regulation → drive overeating → energy imbalance.
  - Thus, sustainability and food quality matter more in real life.
- Framework analogy:
  - Energy balance is one leg of the five-legged stool (with metabolic health, protein, micronutrients, and adherence being the others).
  - All legs are needed to maintain stability.

## How diet can address metabolic health [A: 21:45, V: 22:56]

Interplay Between Energy Balance and Metabolic Health

- Bidirectional relationship:
  - Energy imbalance and metabolic ill health often occur together.
  - Hard to determine causality (“cart-horse issue”):
    - Does poor metabolic health lead to energy imbalance?
    - Or does energy imbalance drive metabolic ill health?
  - Likely bidirectional → each worsens the other.
- Mechanisms described:
  - Insulin resistance → adiposity:
    - Dysregulated fuel partitioning drives fat storage even without excess calories.
  - Excess energy intake → insulin resistance:
    - Overabundance of energy drives fundamental hallmarks of insulin resistance.
  - Creates a self-reinforcing cycle of worsening metabolic health.

Using Diet to Improve Metabolic Health

- Tailoring macronutrients in specific metabolic states:
  - Example: patients in energy balance or slightly under but still have glucose dysregulation/insulin resistance.
  - Strategy: carbohydrate restriction to improve metabolic health without reducing total calories.
  - Rationale: These individuals don’t need fewer calories overall; rather, they need to shift macronutrient intake.
- Clinical observation:
  - Some patients consume adequate/low total calories but overconsume one problematic macronutrient subset (e.g., carbs).
  - Addressing macronutrient quality and distribution is key for metabolic health.

## Protein as a dietary foundation [A: 23:30, V: 25:15]

**Importance of Protein in Diet**

- Core function:
  - Protein is essential for building and maintaining lean body mass.
  - Supports physical function and reduces risk of injury as people age.
- Sarcopenia (loss of muscle mass with aging):
  - A widespread and underappreciated health issue.
  - Impacts both men and women (likely more prevalent in women).
  - Consequences:
    - Increased frailty.
    - Greater risk of falls and related complications.
    - Reduced quality of life.
  - Length of life vs. quality of life:
    - Traditional medicine (Medicine 2.0) emphasizes lifespan.
    - Sarcopenia negatively affects both lifespan (via frailty/falls) and day-to-day function/independence.

Protein Intake Recommendations

- Target range:
  - ~1.6 to 2.0 grams per kilogram of body weight per day.
- Adjustments by age and activity level:
  - Older individuals or those with higher physical activity should aim toward the higher end of the range.
    - Reason: **Anabolic resistance** (reduced efficiency of muscle protein synthesis with aging) requires higher intake to maintain/build muscle.

## Micronutrient essentials: avoiding deficiencies in restrictive and processed diets [A: 24:45, V: 26:36]

Definition & Importance of Micronutrients

- What they are:
  - Vitamins, minerals, and trace elements.
  - Act as co-factors in nearly all biochemical processes in the body.
- Impact of deficiency:
  - Can cause both short-term health issues and long-term consequences.
  - Adequate intake is critical regardless of diet.

When to Worry About Micronutrient Deficiency

- 1) High reliance on ultra-processed foods:
  - Processing reduces nutrient density.
  - Diets high in processed foods often require closer monitoring and supplementation.
- 2) Highly restrictive diets:
  - Example: the “all potato diet.”
    - Whole food based but still nutritionally incomplete.
    - Risks significant gaps in micronutrient intake despite being minimally processed.

Examples of Micronutrients to Watch

- Most common deficiencies monitored:
  - Vitamin A
  - Vitamin B6
  - Vitamin B9 (folate)
  - Vitamin B12
  - Vitamin C
  - Vitamin D
  - Vitamin E
  - Iron

![](https://peterattiamd.com/wp-content/uploads/2025/09/f2-micronutrients-ama75.png)

**Figure 2.** Common micronutrient deficiencies and their daily requirements. 1. [Second National Report on Biochemical Indicators of Diet and Nutrition](https://www.cdc.gov/nutrition-report/php/data-research/report-2012/index.html) (CDC, 2012). 2. Reference daily intakes ([FDA](https://www.fda.gov/media/99069/download)). 3. [Fact Sheets for Health Professionals](https://ods.od.nih.gov/factsheets/list-all/) (National Institutes of Health Office of Dietary Supplements).

- Additional important ones:
  - Zinc
  - Magnesium
  - Other trace elements

Practical Considerations

- Nutrient-dense whole foods should be the primary way to achieve sufficiency.
- Restrictive diets may require supplementation.
- Some diets make sufficiency easier than others.

## Why adherence and sustainability are essential for diet success [A: 27:15, V: 29:21]

**Core Principle: Sustainability Over Perfection**

- Compounding effect:
  - Health, like wealth, compounds over time.
  - Consistent, sustainable practices matter more than short-term perfection.
  - A theoretically “perfect” diet is meaningless if it can’t be adhered to long-term.

**Key Factors for Diet Adherence**

1 Practicality

- Cooking skills and time availability matter.
- Balance between home-prepared meals and eating out must be realistic for the individual.

2 Economics

- Affordability of maintaining the diet is critical.
- Some dietary patterns may require expensive food prep or restaurant reliance.

3 Social Compatibility

- Diets should not isolate individuals in social settings.
- Highly restrictive diets may make it difficult to participate in meals at others’ homes or in restaurants.

4 Psychological Sustainability

- Diet should avoid creating unhealthy relationships with food.
- Particular caution is needed for individuals with a history of eating disorders.
- Overly rigid restrictions may trade one problem for another.

5 Enjoyment

- Food should provide pleasure for most people.
- While some individuals view food strictly as fuel, most benefit from variety and enjoyment.
- A sustainable diet should allow for enjoyable meals.

*Anecdote: Social Challenges from Fasting*

- Peter recalls awkward situations during strict fasting:
  - Attending dinners while consuming only water.
  - Created discomfort not only for him but also for dining companions, especially in one-on-one settings.

## Examining the standard American diet through the five non-negotiables [A: 31:00, V: 33:57]

Framing of the Standard American Diet (SAD)

- Not a conspiracy:
  - Peter pushes back on the idea that SAD was designed to harm people.
  - Instead, it emerged as a business solution to problems of scale:
    - Make food cheap.
    - Make food taste good.
    - Extend shelf life.
    - Ensure portability.
- Historical context:
  - The domestication of agriculture and industrial food production (last ~200 years) led to today’s SAD.
  - Health outcomes were not part of the design criteria.

Reframing SAD → “See Food” Diet

- Peter calls it the “see food diet”:
  - You “see” food and you eat it.
  - Emphasizes environmental exposure and discipline challenges.
  - He even self-assesses his own food environment this way (how often he resists vs. gives in).

Evaluation of SAD Against the 5 Non-Negotiables

- 1) Energy balance:
  - Rarely achieved; SAD tends to drive caloric excess.
- 2) Metabolic health:
  - Indirectly compromised due to poor nutrient quality and excess calories.
- 3) Protein adequacy:
  - Often falls short, though not always.
  - Example: Peter’s version of SAD has sufficient protein, but excessive calories.
- 4) Micronutrient sufficiency:
  - Tends to rely on low-quality, nutrient-poor processed foods.
  - Results in deficiencies or insufficiencies.
- 5) Adherence / sustainability:
  - Strength: SAD is extremely sustainable.
  - Widely accessible, convenient, inexpensive, and socially easy to follow.
  - But sustainability here doesn’t equal health.

Overall Assessment

- The SAD/“see food” diet is highly convenient and enjoyable but fails at meeting core health requirements.
- At best, most people achieve 2–3 out of 5 non-negotiables, not all five.

## The evaluation framework for specific diets [A: 33:30, V: 37:00]

**Transition into Framework Application**

- Moving from fundamentals (5 non-negotiables) to applying a practical evaluation framework to four diets:
  - Ketogenic
  - Carnivore
  - Vegan
  - Mediterranean

Peter’s Framework Expansion

- The core framework remains the same (define → strengths → weaknesses → suitability).
- New addition:
  - Ask: “*Can you actually define the requirements of the diet?*”
    - Important because some diets lack clarity or precision.

Critique of Mediterranean Diet

- Peter highlights the Mediterranean diet as the biggest offender in vagueness:
  - Too broad and ill-defined.
  - “Umbrella so big you could host a circus under it.”
  - Multiple interpretations across studies and practitioners make evaluation difficult.

Framework Steps for Evaluation

- 1) Definition: Clarify exactly what the diet entails.
- 2) Strengths: Who benefits most, in what contexts.
- 3) Weaknesses: Pitfalls, risks, or implementation challenges.
- 4) Suitability: Identify for whom the diet might be a poor choice.

## The ketogenic diet: defining ketosis, clinical origins, modern uses, and potential health benefits [A: 35:00, V: 38:33]

**Ketogenic Diet – Definition**

- Unique among diets: defined by a metabolic state (nutritional ketosis), not food choices alone.
- Nutritional vs. starvation ketosis: distinction based on physiological context.
- Ketone bodies:
  - Beta-hydroxybutyrate (BHB) → most measured via blood finger stick.
  - Acetoacetate → can be measured via breath device.
  - Acetone → measurable in urine, but not typically used.
- Trigger: carbohydrate restriction (<50g/day in most cases).
  - Below this threshold, glycogen stores deplete → body shifts to fat oxidation.
  - Fat (endogenous + exogenous) converted to ketones to fuel brain, skeletal, and cardiac muscle.

Nuance in Carbohydrate Restriction

- Carb threshold depends on:
  - Energy expenditure (e.g., high-intensity training allows higher carb intake while staying in ketosis).
  - Metabolic adaptation: long-term keto users can become more metabolically flexible.
  - Fiber content: carbs with fiber have less impact.

Personal experience (Peter):

- Followed keto strictly from 2011–2014 (≈3 years).
- Monitored ketones daily → average fasting ketone ~1.7–1.9 mmol.
- Noted that 0.3–0.6 mmol is a “no man’s land” (too low for benefits, too high to rely on glucose).
- Felt best at levels consistently above 1 mmol.

Historical Use of the Ketogenic Diet

- Epilepsy:
  - Originally used for treatment-resistant seizures.
  - Peter recalls the rough outcomes as the following: ⅓ of patients would have a complete remission of seizures, ⅓ of patients would have a partial benefit, and ⅓ would basically have no effect.

**Modern Use Cases**

- Weight loss
  - Common reason people try keto today.
  - Debate: is weight loss due to appetite suppression, food monotony, or metabolic changes?
  - Restrictive nature may drive caloric reduction (similar to “potato diet” effect).
- Blood sugar control
  - Among the most dramatic diet-based interventions for glucose regulation.
  - Comparable only to gastric bypass in speed of improvement.
  - Useful for reversing insulin resistance and improving glycemic control.
- General health optimization
  - Proposed benefits: reduced inflammation, improved energy, mental clarity, neuroprotection.
  - Evidence still limited; more anecdotal than trial-supported.
  - Peter personally recalls heightened mental sharpness while on keto, but acknowledges confounding lifestyle factors (training volume, stress levels, etc.).

## The main strengths and weaknesses of the ketogenic diet [A: 43:00, V: 48:00]

Strengths of the Ketogenic Diet

- Weight loss effectiveness
  - With real, whole foods: most people lose weight without struggle.
  - With processed keto foods (bars, artificial sweeteners, etc.): easier to overeat, less success.
- Metabolic health improvement
  - Keto enhances metabolic health, though disentangling effects of weight loss vs. keto itself can be difficult.
- Blood sugar control
  - Improvements are almost universal.
  - Noticeable within ~3 months, especially in borderline individuals.
  - Less obvious if baseline blood sugar is already normal.

Weaknesses and Concerns

- Protein Adequacy & Gluconeogenesis
  - Too much protein → liver converts protein to glucose → suppresses ketone production.
  - Peter’s personal experience:
    - Ate excessive protein when starting keto → struggled to reach ketosis, felt unwell (hypotensive, orthostatic).
    - Found balance at ~120–140g/day protein.
  - Key: protein cannot be consumed “recklessly” on keto.
- Lipid Abnormalities (ApoB issue)
  - Subset of individuals (size unclear, perhaps 10–30%):
    - Experience extreme increases in ApoB and LDL cholesterol.
    - Resemble familial hypercholesterolemia phenotype (high LDL, high HDL, low triglycerides).
  - Peter’s stance:
    - Sky-high ApoB is not safe, contrary to some online claims.
    - ApoB is [causal](https://peterattiamd.com/understanding-cardiovascular-disease/) in cardiovascular disease (CVD).
      - For more on apoB and CVD check out [AMA #43](https://peterattiamd.com/ama43/)
  - Mitigation:
    - Don’t abandon keto if it’s helping in other ways (weight, insulin sensitivity, glycemic control, blood pressure).
    - Instead, use modern pharmacological tools to lower ApoB.
  - Positive note:
    - Hypertension is typically not a side effect of keto.
    - In fact, blood pressure often drops due to sodium wasting.

## How to avoid micronutrient deficiencies while on a ketogenic diet [A: 47:15, V: 52:49]

Micronutrient Gaps on the Ketogenic Diet

- Depends on the type of keto followed
  - Whole foods keto (Peter’s approach)
    - Included salads, leafy vegetables, olive oil, meats, eggs.
    - High caloric intake (~4,000–4,400 kcal/day) due to training demands.
    - Balanced sources of fat, protein, and micronutrients.
    - No major deficiencies observed.
  - Lower quality keto
    - Heavy reliance on processed or narrow food choices can lead to gaps.
    - Increased risk of micronutrient deficiencies.
- Challenges with calorie balance
  - Protein capped at ~140–150g/day, carbs capped at ~50g/day → ~800 kcal from protein + carbs.
  - Required ~3,200–3,500 kcal from fat.
  - Olive oil and vegetables made this achievable while maintaining nutrient variety.
- Potential problem areas & mitigation strategies
  - Organ meats
    - Provide micronutrients but Peter personally dislikes them (especially liver).
    - Tolerates freshly hunted animal liver but not store-bought.
  - Vegetables
    - Brightly colored vegetables help cover B vitamins.
  - Iron
    - Generally not an issue on keto (due to animal protein intake).
  - Magnesium
    - Deficiency more likely; may require supplementation (to be discussed further).

## Electrolytes and fiber and the ketogenic diet: preventing magnesium loss and maintaining digestive health [A: 49:15, V: 55:22]

**Electrolytes on a Ketogenic Diet**

- Initial changes when starting keto:
  - Insulin levels drop sharply (e.g., reducing carbs from ~500g/day to ~50g/day).
  - Leads kidneys to excrete more sodium with water.
  - To balance sodium, the body starts dumping potassium.
  - In turn, magnesium loss increases as well.
- Key electrolytes affected
  - Sodium (Na⁺): flushed out quickly when insulin drops.
  - Potassium (K⁺): also lost as body tries to maintain sodium balance.
  - Magnesium (Mg²⁺): tends to be most critical, with losses often causing major symptoms.
- Symptoms of imbalance
  - Muscle cramping (especially with activity).
  - Constipation (linked to magnesium depletion).
  - General fatigue or weakness.
- Recommendations
  - Supplement with sodium and magnesium (especially if normotensive).
  - Use a mix of fast-absorbing and slow-release magnesium formulations.
    - Poorly absorbed (e.g., magnesium oxide) → helps with constipation.
    - Slow-release (e.g., [Slow-Mag](https://slowmag.com/)) → better for cramping and steady absorption.

**Fiber on a Ketogenic Diet**

- General concern: limiting fruits, whole grains, and some vegetables can lower fiber intake.
- Peter’s experience:
  - On a whole-foods keto approach, actually consumed more fiber than ever (via vegetables and salads).
- Risk:
  - Fiber deficiency may occur if vegetables are heavily restricted.
- Recommendation:
  - Maintain a strong intake of high-fiber vegetables to avoid digestive health issues.

## Adherence challenges of the ketogenic diet [A: 51:30, V: 58:00]

Adherence Challenges with the Ketogenic Diet

- Peter’s reflection on adherence
  - Admits keto is not easy to adhere to long-term.
  - He followed it for a little over 3 years but struggles to imagine how he did it now.
  - Outsiders often perceive him as highly disciplined, but he attributes it more to context and environment.
- Difficulty of extremely low-carb intake
  - Carbohydrate restriction is severe and difficult to maintain.
  - Everyday foods like bananas, apples, bread, and rice are almost entirely off-limits.
  - Even small “normal” portions of fruit felt impossible unless tied to intense exercise (e.g., banana only during long bike rides).
- Allowed fruits
  - Berries were the exception—he could consume them in relatively high quantities without breaking ketosis.
- Diet monotony
  - Recalled eating a very repetitive, boring diet—essentially the same meals daily.
  - This may have reduced decision fatigue but limited enjoyment.
- Environmental and lifestyle factors
  - At the time Peter adhered to keto is was easier due to life circumstances:
    - Only one child, who was younger (less household food variety).
    - Household environment lacked a pantry full of tempting, high-carb foods.
  - Today: adherence would require much more mental energy due to constant exposure to “pantry temptations.”

## The carnivore diet: definition, motivations, anecdotal benefits, and possible mechanisms [A: 53:15, V: 59:58]

**Definition of the Carnivore Diet**

- Exclusively animal-derived foods: Meat, fish, eggs, animal fats.
- Excludes all plant foods: Vegetables, fruits, grains, legumes, nuts, seeds.
- Excludes foods neither plant nor animal: Mushrooms, seaweed, etc.
- Dairy: usually excluded, though some sub-groups allow limited dairy depending on tolerance.
- Ketosis: not the goal, but can occur incidentally if diet is high-fat (e.g., ribeye vs. lean cuts).
- *Quality matters*: can be done well or poorly (e.g., hot dog diet = technically carnivore, but unhealthy).
- Peter has not personally tried carnivore; notes it is the most recent of the “named diets” discussed.

Why People Try the Carnivore Diet

- Two main attraction groups:
- 1) Plant toxicity believers:
  - View phytochemicals, polyphenols, alkaloids as inherently harmful.
  - Avoid plants entirely to prevent exposure.
  - Peter expresses skepticism about this claim.
- 2) Chronic condition relief seekers:
  - Individuals with autoimmune, inflammatory bowel, skin, or metabolic conditions resistant to other treatments.
  - Report dramatic health improvements not centered on weight loss.
  - Anecdotal evidence is strong, though not well supported by research.

Possible Mechanistic Explanations for dramatic health improvements not centered on weight loss

- Gut antigen load reduction:
  - Eliminating plants may reduce exposure to compounds that trigger immune responses.
- Microbiome shifts:
  - Removal of plant matter changes microbial balance, possibly lowering inflammation.
- Incidental ketosis:
  - Some benefits may mirror ketogenic mechanisms (reduced inflammation, improved fuel utilization).
- Blood sugar control:
  - Almost universally, individuals report dramatic improvements in glucose regulation.
- Caloric restriction by default:
  - Diet is restrictive enough that overconsumption of food becomes unlikely.

## The main strengths and weaknesses of the carnivore diet [A: 57:30, V: 1:05:03]

**Strengths of the Carnivore Diet**

- Nutrient profile:
  - High in complete, bioavailable protein.
  - Provides all essential amino acids (especially if including organs, egg yolks, shellfish).
  - Expanded animal food choices make it possible to meet many micronutrient needs.
- Satiety and caloric restriction:
  - Highly satiating → people naturally eat less.
  - Restrictive nature reduces:
    - Food variety
    - Hyper-palatable foods
    - Overeating
  - May induce beneficial fuel partitioning that contributes to reduced intake.
- General principle:
  - Restrictive diets (low-carb, low-fat, etc.) often lead to more weight loss than “eat less” approaches.
    - Example cited: [JAMA meta-analysis](https://jamanetwork.com/journals/jama/fullarticle/1900510) (48 RCTs, ~10 years ago) → restrictive diets produced 6–9 kg (≈20 lbs) more weight loss at 6–12 months vs. control diets.
  - Peter cautions not to over-interpret carnivore’s weight loss benefits—it may just reflect the “potato diet effect” (restriction drives monotony and reduced intake).

Unique Strengths as an Elimination Diet

- Gut relief:
  - Eliminates fermentable fibers, sugar alcohols, gluten, wheat antigens.
  - More restrictive for gut health than [Whole30](https://whole30.com/) or [low-FODMAP](https://peterattiamd.com/ama59/).
- Highbrow vs. processed versions:
  - Benefits more apparent when avoiding “college kid” carnivore (processed meats) and focusing on high-quality animal foods.
- Practical result:
  - Removes many of the worst offenders for people with gut issues.

Who Might Benefit Most

- Autoimmune/GI disorder patients:
  - Anecdotal cases and reports of inflammatory bowel disease (IBD) symptom relief, comparable to drug-level improvements.
- Those needing structured calorie restriction:
  - Restrictiveness reduces junk food, hyper-palatable foods, and food fatigue.
- Metabolic syndrome/insulin resistance patients:
  - Especially when other restrictive diets (vegan, Mediterranean, low-fat) haven’t worked.
  - Removes nearly all carbohydrates → strong overlap with ketogenic diet benefits (glycemic control, insulin sensitivity).
- Data gap:
  - Less evidence than for ketogenic diet, but Peter’s intuition is that glycemic improvements would be similar.

**Concerns / Weaknesses**

- Micronutrient deficiencies:
  - Risk of low intake of magnesium, B1, calcium, vitamin C, etc.
  - Can be mitigated with supplementation.
- Lack of long-term data:
  - Very little evidence on health outcomes from decades of carnivore eating.
  - Historical claims (e.g., the Maasai diet) lack robust lifetime data.
- ApoB and LDL-C [elevation](https://cdn.nutrition.org/article/S2475-2991(22)10608-6/fulltext):
  - Likely even more pronounced than in keto.
  - Many carnivore eaters consuming high-fat meats → skyrocketing ApoB levels.
  - Must be addressed pharmacologically if diet otherwise confers benefits.
- Overall uncertainty:
  - Long-term health outcomes remain unknown and concerning.

## Plant exclusion on the carnivore diet: nutrient gaps, gut changes, and unanswered questions [A: 1:03:15, V: 1:12:38]

**Nutritional Gaps Without Plants**

- Zero plant matter → nutrient gaps inevitable.
- Proponents see this as a feature, not a bug:
  - They argue phytonutrients are harmful and avoidance is beneficial.
  - Peter finds those arguments unconvincing.

Uncertainty About Long-Term Consequences

- Peter emphasizes that we simply don’t know.
- Long-term health impacts of zero-plant diets remain unclear.
- He avoids overstating certainty—acknowledges lack of data.

Gut and Microbiome Changes

- Excluding all plant matter and fiber:
  - Alters food substrate available to gut microbes.
  - Results in changes in butyrate production (a short-chain fatty acid critical for colon health).
  - Alters colonic barrier integrity.
  - Whether these changes are better or worse is unknown.
- Butyrate & GLP-1 connection:
  - Butyrate plays an important role in GLP-1 production (hormone involved in insulin secretion, satiety, and glucose regulation).
- Again, Peter acknowledges that difference doesn’t equal harm, but we just don’t know enough yet.

## Adherence challenges of the carnivore diet [A: 1:04:45, V: 1:14:28]

Adherence Challenges with Carnivore Diet

- Like keto, it has similar social difficulties in maintaining.
- Cost factor:
  - Strict adherence, e.g., only grass-fed organic rib-eyes, makes it expensive.
  - Higher financial burden compared to less restrictive diets.
- Social challenges:
  - Strict carnivore eaters often have very narrow requirements.
  - Example: guest who only allowed salt on steak, no oil or any other preparation method.
  - Creates difficulties when eating outside the home, especially in restaurants where food prep cannot be strictly controlled.

## The vegan diet: definition, core beliefs, and various motivations for this strategy [A: 1:05:45, V: 1:15:46]

**Definition of the Vegan Diet**

- Excludes all animal-derived foods and ingredients:
  - No meat, poultry, fish, dairy, eggs.
  - No products made from animals: whey, honey, gelatin.
- Includes all non-animal foods:
  - Plants, fungi (mushrooms, yeast, seaweed), bacteria, fermented products.
- Essentially the mirror opposite of carnivore diet (not a perfect mirror, but close).

Belief Systems Underlying Veganism

- 1) Health-based belief
  - Animal products are harmful to the individual.
  - Concern with amino acids or molecules in animal foods being damaging.
- 2) Environmental belief
  - Industrialized animal production is harmful to the planet.
  - Choosing veganism as a form of climate or sustainability activism.
- 3) Ethical/animal welfare belief
  - Eating animal products is cruel.
  - Ethical stance against animal suffering.

Peter’s Reflections & Personal Experience

- Peter tried a vegan diet for six months about 20 years ago.
- Personally identifies most with the ethical/animal welfare reason (#3).
- Explicitly rejects belief #1 (animal foods being inherently harmful to humans), calling it “categorically untrue” if data is reviewed objectively.
- Shares a personal story about killing and eating an animal with a bow and arrow:
  - Believes there’s value in being connected to one’s food.
  - Suggests it’s “a mistake” how detached modern people are from food sources.
- When meeting vegans motivated by ethical reasons, he respects their position and doesn’t try to talk them out of it.

Vegetarianism Context

- Many vegetarians grew up without exposure to meat during formative years.
- As adults, meat feels unpalatable or foreign due to lack of exposure.
- Vegetarians still consume dairy and eggs, making protein needs easier to meet.
- Some eventually add fish, others don’t.

## The main strengths and weaknesses of the vegan diet [A: 1:09:15, V: 1:20:15]

**Strengths / Advantages of Vegan Diet**

- Lower calorie density of plant foods
  - Generally less calorie-dense than animal foods → supports weight management.
  - Exception: calorie-dense oils.
- Facilitates calorie control when done properly
  - Correctly followed = emphasis on whole foods (not ultra-processed vegan junk).
  - Avoids the “college vegan diet” trap (processed vegan products leading to weight gain).
- Fiber intake & gut health
  - High in fiber → increased production of short-chain fatty acids (notably butyrate).
  - Benefits shown in population studies:
    - Improves colonic health.
    - Supports immune function.
    - Reduces inflammation.

**Weaknesses / Pitfalls of Vegan Diet**

- Protein quality & quantity (harder to fix)
  - Plant proteins = lower in essential amino acids, especially leucine (key for muscle growth).
  - Less digestible → lower absorption.
  - Results in lower quality, lower availability, and lower intake unless carefully managed.
  - Requires deliberate planning to meet needs.
- Micronutrient deficiencies (easier to fix with supplementation)
  - Vitamin B12 – most common deficiency.
  - Iron – higher risk of deficiency; must monitor iron & ferritin levels.
  - Calcium – absence of dairy → reduced intake, important for bone health.
  - Omega-3 fatty acids (EPA & DHA)
    - Plants provide ALA (alpha-linolenic acid), but conversion to EPA/DHA is [very poor](https://ods.od.nih.gov/factsheets/Omega3FattyAcids-HealthProfessional/?utm_source=chatgpt.com#en3) (~10–15%).
    - Supplementation typically required.
- “College version” of vegan diet
  - Over-reliance on processed/ultra-processed vegan foods (fast food, packaged junk).
  - Similar pitfall as poorly executed keto or carnivore diets.

## Adherence to the vegan diet: social acceptance, edge cases, and personal sustainability [A: 1:13:15, V: 1:24:40]

Adherence and Sustainability of Vegan Diet

- Relative ease of adherence
  - Of the three diets discussed so far (keto, carnivore, vegan), vegan is likely the easiest to adhere to.
  - Reason: social acceptability has increased significantly.
    - Nearly every restaurant offers vegan menu options (except rare cases like In-N-Out Burger).
    - Makes eating out and maintaining diet in social contexts easier.
  - At home, assuming proper meal preparation, adherence is manageable.
- Edge cases: extreme restrictions
  - A minority of individuals treat veganism in an ultra-strict “religious” sense.
  - Example: refusal to use or ingest anything derived from animals—even non-food products.
    - Specifically, refusal to use heparin (a blood thinner derived from pigs/cattle) in medical settings, even when medically necessary (e.g., surgery, heart valve replacement).
  - These extreme cases highlight adherence challenges when rigid ideology overrides practicality.
- Personal sustainability (Peter’s perspective)
  - For him personally, veganism would be harder to sustain than keto.
  - Reason: he finds it more difficult to give up animal protein than to give up unlimited carbohydrates.
  - Highlights individual variability in adherence based on personal preferences and tastes.

## The Mediterranean diet: definitional challenges, traditional patterns, and its relatively strong evidence base [A: 1:15:15, V: 1:26:57]

**Definition and Clarity Issues**

- Lack of a single, clear definition
  - Peter admits guilt in sometimes speaking about the Mediterranean diet without precision.
  - Different studies (e.g., PREDIMED and Lyon Heart) use different definitions, leading to inconsistency.
  - Illustrates the broad and flexible umbrella under which many eating patterns can qualify as “Mediterranean.”
- Example of inconsistency
  - Some trials define it as including a minimum of two glasses of wine per day.
  - Raises questions: Are the health benefits from the diet itself or occurring despite alcohol intake?
  - Shows how study design choices complicate interpretation of results.
- General characteristics of the Mediterranean diet (pattern, not rigid rules):
  - High consumption of: vegetables, fruits, legumes, whole grains, nuts, olive oil, fish, dairy, red wine.
  - Low consumption of: red meat and processed foods.
  - Inspired by traditional eating habits of mid-20th century Southern European coastal populations (Greece, southern Italy, Spain).

**Reasons for Popularity and Endorsement**

- Strong research backing
  - Considered the best-supported diet in terms of mortality and long-term health outcomes.
  - Peter often points to it as the “best” diet when forced to pick, due to available evidence.

*Key supporting studies*

- [PREDIMED Trial](https://www.nejm.org/doi/full/10.1056/NEJMoa1800389):
  - Primary prevention trial.
  - Despite errors in randomization, corrected data still showed significant reduction in mortality for Mediterranean diet arms vs. low-fat arm.
  - Controversy around whether the “low-fat” comparison arm was actually sufficiently low-fat.
  - Required participants to consume at least one glass of red wine daily.
- [CORDIOPREV](https://link.springer.com/article/10.1007/s00394-019-02059-5) Study:
  - Secondary prevention trial.
  - Patients with established coronary heart disease.
  - Stricter limits on fat, red meat, and commercial baked goods compared to PREDIMED.
  - Found improvements in secondary prevention of cardiovascular disease.

*Takeaway*

While definitions vary, Mediterranean-style diets have consistent evidence showing cardiovascular and mortality benefits, across both primary and secondary prevention trials.

## Limitations of the Mediterranean diet: loose definitions and indulgence risks [A: 1:19:30, V: 1:31:45]

Core Limitation

- Risk of misapplication due to vague boundaries
  - Unlike keto, vegan, or carnivore (which have clear rules), the Mediterranean diet has loose, broad parameters.
  - This can lead to people misinterpreting indulgences as “Mediterranean.”
    - Example: drinking a bottle of wine daily.
    - Example: eating pastries under the justification of “French/Italian tradition.”

Peter’s Perspective

- Peter calls for more clarity/rigidity
  - Wishes there were a more clearly defined belief system or framework for what counts as Mediterranean.
  - A little more rigidity could prevent misuse.
- Common sense application is key
  - Recognize the difference between indulgence vs. health practice.
  - Enjoying wine, bread, and olive oil while traveling is fine—but shouldn’t be rationalized as a “health choice.”

True Spirit of the Diet (vs. Pitfalls)

- Not about excessive olive oil or wine consumption.
- Should emphasize:
  - High-quality fish
  - Vegetables
  - Monounsaturated fats (like olive oil)
  - Moderation in saturated fats

## Measuring diet success: why setting clear goals and tracking outcomes matter [A: 1:21:00, V: 1:33:51]

Core Message

- Measurement is essential: “What gets measured, gets managed.”
- Measurement should always be goal-specific, not arbitrary.

Common Patient Scenario

- Peter often receives texts from people saying they want to try a diet.
- He doesn’t respond with a simple “yes/no” but instead asks:
  - What are your goals?
    - Body composition improvement?
    - Better metabolic health?
    - Cognitive benefits (e.g., brain fog)?
    - Disease risk mitigation?

Why Goal Clarity Matters

- Without defined goals, people are flying blind in their dietary choices.
- Goals dictate what metrics to track and therefore how to evaluate success.
- Contrast with influencer-driven advice:
  - Social media often encourages diets without context.
  - Lacks personalization or tracking framework.

## Tracking body composition using DEXA scans [A: 1:22:15, V: 1:35:27]

Main Goal: Tracking Body Composition

- Best tool: [DEXA](https://peterattiamd.com/ama40/) scan (gold standard).
- Provides comprehensive detail on:
  - Body fat %
  - Visceral adipose tissue (VAT) (deep belly fat linked to health risks)
  - Lean mass (muscle mass)

Desired Outcomes

- Body fat: should decrease over time.
- Lean mass: at minimum should stay the same, ideally increase.
- Visceral fat (VAT): should decrease.
  - Even though VAT isn’t technically “body composition,” it strongly correlates with metabolic health and is usually reduced as body fat decreases.

## Tracking metabolic health: key blood tests and advanced glucose monitoring tools [A: 1:22:45, V: 1:36:07]

Core Metrics for Metabolic Health

- Basic bloodwork (easy, standard tests):
  - Fasting insulin – indicator of insulin sensitivity.
  - Fasting glucose – measures baseline blood sugar control.
  - Hemoglobin A1C (HbA1c) – reflects average blood glucose over ~3 months.
  - Fructosamine – shorter-term marker of blood glucose (2–3 weeks).
- More advanced / involved testing (optional):
  - Oral glucose tolerance test (OGTT):
    - Assesses body’s response to a glucose load.
    - Useful for detecting impaired glucose tolerance/early insulin resistance.
  - Continuous glucose monitor (CGM):
    - Tracks real-time glucose fluctuations throughout the day.
    - Provides detailed insight into diet, lifestyle, and stress effects on glucose.

## Using elimination diets to identify food sensitivities that may cause digestive problems, autoimmune symptoms, or low energy [A: 1:23:30, V: 1:36:45]

**General Approach**

- Elimination diet strategy:
  - Must be done deliberately and thoughtfully to best infer cause-and-effect.
  - Process begins with a hypothesis about which food(s) may be linked to symptoms.

**Step-by-Step Method**

- 1) Formulate hypothesis
  - Example: digestive, autoimmune, energy, or sleep issues may be linked to a specific food.
  - Hypothesis should be narrow (e.g., wheat → bloating), not overly broad.
- 2) Eliminate suspected food(s)
  - Remove completely from the diet for a set period (e.g., 4 weeks).
  - Be aware that foods like wheat can appear in hidden or “sinister” places.
- 3) Track symptoms
  - Maintain a daily log (energy, sleep, GI issues, skin, etc.).
  - Improvement = potential link; no improvement = food likely not the cause.
- 4) Reintroduction phase
  - Add the eliminated food back after the exclusion period.
  - Watch for symptom recurrence.
  - Recurrence strengthens causal inference.

*Example: Wheat and/or Gluten elimination test*

- Gluten often blamed for issues, but Peter notes:
  - Gluten = one specific antigen in wheat.
  - *Wheat* sensitivities appear more common than gluten sensitivities.
- Case example:
  - Remove wheat → symptoms improve → reintroduce wheat → symptoms reappear → stronger confidence in link.

## Evaluating “anti-inflammatory diets”: confirming inflammation through symptoms and hs-CRP testing [A: 1:25:15, V: 1:38:54]

Check out: [#301 – AMA #59: Inflammation: its impact on aging and disease risk, and how to identify, prevent, and reduce it](https://peterattiamd.com/ama59/)

\*\*\*

Clarifying the Goal

- Before evaluating an anti-inflammatory diet, you must first ask:
  - Do you actually have inflammation?

Symptoms That May Suggest Inflammation

- Potential signs:
  - Bloating
  - Indigestion
  - Headaches
  - Joint pain
  - Brain fog
- Caution: These symptoms are not specific to inflammation and can result from other, unrelated issues.

Testing for Inflammation

- hs-CRP (high-sensitivity C-reactive protein)
  - Provides an objective but imperfect measure of inflammation.
  - Often used in practice when low-grade elevations are detected.
- Other tests:
  - [ANA screen](https://medlineplus.gov/lab-tests/ana-antinuclear-antibody-test/) (particularly when autoimmune disease is suspected).

Approach if Elevated Inflammation Is Found

- “Inflammation hunt down” process includes:
  - Dietary triggers:
    - Dairy
    - Wheat
  - Lifestyle/health factors:
    - Dental hygiene (especially gum health).
    - Other non-dietary contributors.

Caution on Over-Diagnosis

- Many people report “feeling inflamed.”
  - Important not to dismiss these concerns but also avoid assuming pathology without evidence.
- If symptoms + tests (hs-CRP, ANA, etc.) are negative → individual may not actually have pathologic inflammation.

## Final takeaways: flexibility, structure, and avoiding dogma in dietary choices [A: 1:27:00, V: 1:40:49]

**Figures below:** Summary of example diets through the simple three-question framework. (Can you define it? What are its strengths? What are its weaknesses — and can you fix them?) Remember the non-negotiables: maintain energy balance, support metabolic health, provide adequate protein, meet micronutrient needs, and be sustainable long-term.

![](https://peterattiamd.com/wp-content/uploads/2025/09/f3-keto-ama75.png)

**Figure 3.** Ketogenic diet summary.

![](https://peterattiamd.com/wp-content/uploads/2025/09/f4-carnivore-ama75.png)

**Figure 4.** Carnivore diet summary.

![](https://peterattiamd.com/wp-content/uploads/2025/09/f5-vegan-ama75.png)

**Figure 5.** Vegan diet summary.

![](https://peterattiamd.com/wp-content/uploads/2025/09/f6-med-diet-ama75.png)

**Figure 6.** Mediterranean diet summary.

**Core Takeaway**

- No single “perfect diet” exists for everyone.
- The best diet is one that:
  - Meets the five physiologic non-negotiables (energy balance, metabolic health, protein adequacy, micronutrient sufficiency, long-term adherence).
  - Aligns with an individual’s personal goals and preferences.

Flexibility Over Time

- Diet suitability may change throughout a person’s life.
  - Example: Peter reflects on his ketogenic diet years.
    - At times, felt it was perfect and couldn’t imagine doing anything else.
    - Now, couldn’t imagine returning to it—but would reconsider if health circumstances required it.
- Emphasis: Be willing to adapt as health, lifestyle, or goals shift.

Mindset Toward Dieting

- Avoid making diets political, religious, or dogmatic.
- Encourage:
  - Curiosity
  - Fluidity
  - Willingness to test and adjust.

Role of Frameworks

- The diet frameworks discussed (non-negotiables + define-strengths-weaknesses rubric) are tools for:
  - Structuring decision-making.
  - Avoiding rigidity while maintaining clarity and consistency.
- Key distinction: Structure is important; rigidity is not.

---

## Selected Links / Related Material

**AMA episode of The Drive on nutrition and diets**: [328 – AMA #66: Optimizing nutrition for health and longevity: myth of a “best” diet, complexities of nutrition science, and practical steps for building a sustainable diet](https://peterattiamd.com/ama66/) | Peter Attia (peterattiamd.com) [9:45]

**AMA episode of The Drive that discusses the CR/DR/TR framework**: [#353 – AMA #72: Fasting: benefits for body composition and disease prevention, potential risks, and Peter’s updated practical framework](https://peterattiamd.com/ama72/) | Peter Attia (peterattiamd.com) [13:45]

**ApoB and its causality of CVD**: [45:00]

- [#229 ‒ Understanding cardiovascular disease risk, cholesterol, and apoB](https://peterattiamd.com/understanding-cardiovascular-disease/) | Peter Attia (peterattiamd.com)
- [#238 – AMA #43: Understanding apoB, LDL-C, Lp(a), and insulin as risk factors for cardiovascular disease](https://peterattiamd.com/ama43/) | Peter Attia (peterattiamd.com)

**A JAMA study demonstrating that restrictive diets (low-carb, low-fat, etc.) often lead to more weight loss than “eat less” approaches**: [Comparison of Weight Loss Among Named Diet Programs in Overweight and Obese Adults](https://jamanetwork.com/journals/jama/fullarticle/1900510) (Johnston et al., 2014) [58:00]

**Paper reporting ApoB and LDL-C elevation in individuals on a carnivore diet**: [Behavioral Characteristics and Self-Reported Health Status among 2029 Adults Consuming a “Carnivore Diet”](https://cdn.nutrition.org/article/S2475-2991(22)10608-6/fulltext) (Lennerz et al., 2021) [1:02:00]

**Plants provide ALA (alpha-linolenic acid), but the conversion of ALA to EPA and DHA is trivial (10-15%)**: [Omega-3 Fatty Acids](https://ods.od.nih.gov/factsheets/Omega3FattyAcids-HealthProfessional/?utm_source=chatgpt.com#en3) | (nih.gov) [1:12:00]

**Key supporting studies for the benefits of the Mediterranean diet**: [1:16:15]

- *Primary prevention trial (PREDIMED study)*: [Primary Prevention of Cardiovascular Disease with a Mediterranean Diet Supplemented with Extra-Virgin Olive Oil or Nuts](https://www.nejm.org/doi/full/10.1056/NEJMoa1800389) [1:16:15]
- *Secondary prevention trial (CORDIOPREV study)*: [Long-term dietary adherence and changes in dietary intake in coronary patients after intervention with a Mediterranean diet or a low-fat diet: the CORDIOPREV randomized trial](https://link.springer.com/article/10.1007/s00394-019-02059-5) (Quintana-Navarro et al., 2019) [1:16:15]

**AMA episode of The Drive about body composition and DEXA scans**: [#227 – AMA #40: Body composition, protein, time-restricted feeding, fasting, DEXA scans, and more](https://peterattiamd.com/ama40/) | Peter Attia (peterattiamd.com) [1:22:15]

**AMA episode of The Drive discussing the topic of inflammation**: [#301 – AMA #59: Inflammation: its impact on aging and disease risk, and how to identify, prevent, and reduce it](https://peterattiamd.com/ama59/) | Peter Attia (peterattiamd.com) [1:25:15]

---

## People Mentioned

- [Bob Kaplan](https://brokenscience.org/author/bobkaplan/)
- [Steve Finney](https://en.wikipedia.org/wiki/Steve_Finney)
- [Jeff Volek](https://en.wikipedia.org/wiki/Jeff_Volek)
- [Magnus Carlsen](https://en.wikipedia.org/wiki/Magnus_Carlsen)