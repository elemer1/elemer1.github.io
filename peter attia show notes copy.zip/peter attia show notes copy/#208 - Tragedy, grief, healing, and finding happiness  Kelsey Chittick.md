# #208 – Tragedy, grief, healing, and finding happiness | Kelsey Chittick

**Source:** [https://peterattiamd.com/kelseychittick/](https://peterattiamd.com/kelseychittick/)

---

Kelsey Chittick is the author of [Second Half: Surviving Loss and Finding Magic in the Missing](https://www.amazon.com/Second-Half-Surviving-Finding-Missing/dp/1951407490). In this episode, Kelsey describes her long healing process following the sudden death of her husband, former NFL player Nate Hobgood-Chittick. She describes her life with Nate before and after football, including her premonitions that something was off about Nate and the subsequent finding that he suffered from chronic traumatic encephalopathy (CTE). She speaks openly about how she handled his death with her children, the trauma and grief they faced in the aftermath, and how she’s found ways to be happy in her new life. She shares deep insights into her healing process, including her experience with psychedelics and how the concept of “radical acceptance” has helped her to find joy once again.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/kelseychittick/the_Drive_public.png)

Play

#208 - Tragedy, grief, healing, and finding happiness | Kelsey Chittick

#208 - Tragedy, grief, healing, and finding happiness | Kelsey Chittick

1x15s30s

0:001:54:37

## We discuss:

- Kelsey’s childhood in Florida as an athlete [2:15];
- Meeting Nate and early relationship with him [7:45];
- Nate’s unbelievable work ethic and desire to play in the NFL [12:30];
- Life with a professional football player, playing through pain, and head injuries related to football [17:00];
- Nate’s final days of football and early retirement struggles [23:30];
- The tough transition from the NFL to a “regular life” and how Nate found a way to serve others [28:45];
- Nate’s struggle with his weight and overall health after retirement [34:45];
- Kelsey’s anxiety and premonitions of Nate’s impending death, and Nate’s changing demeanor [37:30];
- The traumatic experience of learning of Nate’s death during her own spiritual journey to Jamaica [45:30];
- Breaking the news to her children of their father’s death [51:00];
- The darkest days following Nate’s passing and how her children were handling grief [55:30];
- A new relationship with death, finding happiness, and the duality of feelings [1:02:45];
- Nate’s autopsy results showing evidence of CTE [1:07:00];
- The grieving process [1:15:00];
- Dealing with grief with kids and how children grieve differently [1:19:15];
- Healing through her first psychedelic experience [1:23:00];
- The therapeutic potential of psychedelics, meditation, and more [1:33:45];
- The concept of “radical acceptance” and the peace that comes with it [1:42:30];
- The up-and-down experience of writing her book [1:47:45];
- More.

§

## Show Notes

**\*Notes from intro:**

- Kelsey Chittick is a writer, comedian, and inspirational speaker
- She’s the author of [*Second Half: Surviving Loss and Finding Magic in the Missing*](https://www.amazon.com/Second-Half-Surviving-Finding-Missing/dp/1951407490/ref=sr_1_1?crid=IEK8121RTXV2&keywords=Second+half%2C+surviving+loss+and+finding+magic&qid=1646659573&sprefix=second+half%2C+surviving+loss+and+finding+magic+%2Caps%2C311&sr=8-1)
  - A book about the death of her husband, former NFL player, [Nate Hobgood-Chittick](https://en.wikipedia.org/wiki/Nate_Hobgood-Chittick), who passed away suddenly at the age of 42 in front of their young children
- She’s also the co-creator of [KeepOn](https://keeponpodcast.com/), a podcast that explores how the greatest obstacles can turn out to be the greatest gifts
- Peter wanted to talk with Kelsey after his wife read her book
  - Full disclosure, his wife and Kelsey are friends
  - He saw his wife reading and crying through this book
    - This got him very interested in it and ultimately led to him wanting to sit down with Kelsey
- In this episode, we talk about Kelsey’s background and that of her late husband, Nate
  - How they met, growing up, going to college together, being athletes
- We talk about Nate’s experience with football
  - How hard football is on the player’s bodies
  - Nate’s experiences post football
- We speak about Nate’s passing
  - And in the aftermath, finding out that Nate suffered from [CTE (chronic traumatic encephalopathy)](https://en.wikipedia.org/wiki/Chronic_traumatic_encephalopathy)
  - How Kelsey handled his death with her children
    - The trauma and grief they faced in the immediate aftermath and even today
- We talk about how Kelsey was able to grieve while still finding ways to be happy and able to live her life post Nate
- We end the discussion around Kelsey’s experiences with psychedelics
  - This played a really important role in her recovery
  - How it fit into this idea of radical acceptance
    - Anybody who’s done DBT (Dialectical behavior therapy) or done this type of work will be familiar with that terminology

## Kelsey’s childhood in Florida as an athlete [2:15]

**Growing up in Florida**

- Kelsey grew up in [Winter Park, Florida](https://en.wikipedia.org/wiki/Winter_Park,_Florida)
- She began swimming at age 4 and racing at age 6
- Collegiate sports were not on the radar when she was a kid, as they are now
- She lived in Florida and wanted to be outside; she and her friends loved swimming
- She didn’t think about college sports until maybe 9th grade when she won
  - She got 2nd at state
  - In her sophomore year, she won state in 100 back and 100 fly
  - She was terrible at breaststroke
- In high school she didn’t know about recruiting; it wasn’t huge to get a scholarship
  - Especially for female athletes
- In her junior year her coach told her that she could get a scholarship
- Her family wasn’t into sports
  - Everybody did their own thing
  - Not  like now with parents driving their kids to special coaches and meets, etc.
- Kelsey remembers going to a basketball game with one of her girlfriends whose dad had gone to [UNC](https://en.wikipedia.org/wiki/University_of_North_Carolina_at_Chapel_Hill), maybe this was my junior year
  - Long story short, but her friend’s brother dated the swim coach’s daughter
  - The basketball game was huge in Chapel Hill; UNC might have been playing Duke Carolina game
  - Someone at the game remarked that UNC (Carolina) was impossible to get in out of state
    - Kelsey decided to try to get in
    - She met the swim coach and he said, “*Call me when you’re at the end of your junior year*”
- She doesn’t think she got into UNC at first
  - They had already given a scholarship to a girl from Ohio
- Kelsey got an offer for [Miami](https://en.wikipedia.org/wiki/University_of_Miami) and [FSU Florida](https://en.wikipedia.org/wiki/Florida_State_University)
  - She wanted to get out of Florida so badly
    - Everybody she knew was going there
    - She wanted to have a new experience
- She waited on accepting offers from Florida and that spring the girl decided to go somewhere else, so she got into UNC
- Kelsey turned down in-state scholarships
  - She didn’t want to swim against all the same people she grew up with
  - She was excited to have a new experience at UNC Chapel Hill
- She spent the 1st 2 years at UNC with just a tuition scholarship (her parents paid room and board)
  - Once she made [NC2A’s (NCAA)](https://en.wikipedia.org/wiki/National_Collegiate_Athletic_Association), she got a full scholarship
- She swam 100 back, 200 back, 100 fly
  - She didn’t want to swim the 200 fly
- Peter likes long distance swimming
  - When he swam in the pool, the only thing he could swim is breaststroke
  - He’s a pretty bad at freestyle despite the fact that he can swim it for a long period of time (but not fast)
- Kelsey graduated from high school in ’95 and Chapel Hill in ’99

## Meeting Nate and early relationship with him [7:45]

- She met Nate in 1998, the summer before starting her junior year
  - She had just finished her sophomore year swimming
  - She was a hot mess; she’d gained a ton of weight
    - She ate cream cheese and croissant sandwiches because they had training table
    - She had nights out
    - Her face and body were not primed for winning anything
  - She started dating a guy who had a weed problem and was running with a crowd that wasn’t conducive to being excellent
    - This guy was on the swim team
    - At Carolina at the time you couldn’t rush a sorority or fraternity if you were on a swim athletic team; the team was your group
    - She dated this guy for a while before she met Nate
- She didn’t love swim as much as she did in high school
  - She didn’t love that her scholarship depended on it and that all her friends did the same thing
  - In high school she had 12 girlfriends but everybody was different; she was the swimmer
  - Once she got to Chapel Hill, they were all fighting for NCAA or a spot on the relay
    - It was a different experience
- She met Nate at a bar; he was going into his 5th year, senior year
  - She remembers he was an absolutely enormous man with more confidence than you’ve ever seen in your life
  - He had more swagger for a huge fat guy; it was unbelievable
  - That night and he gave her this napkin that said, “*If you want the best, say goodbye to the rest. Go home with me and I’ll make you happy*.”
  - She met him that night but they didn’t really see each other for a while
- It turned out one of her roommates was dating a guy on the offensive line named Ryan and so a couple months later they had a house party where we watched *X-Files*, everybody partied and got drunk and danced, and Nate was there
  - At some point that night, the guy she was dating called and Nate just walked over and took the phone and was like, “*She’s with me now*.” And that was it
- From the minute she met him, she knew there was something
- He was from nothing; a poor kid from Allentown; a guy that hustled
- Her father was a lawyer and her mom was very politically active
  - She grew up in a country club life
  - Her town was very Southern and Christian
- When she met Nate, he was so different; he was connected
  - When he would sit and listen to her, she felt  like she was the most important person in the world
    - He did that with everybody

> “*There was a way when he walked into a room that you could tell everybody loved him and he loved them*”— Kelsey Chittick

- She knew that first night something was different about him
- The night they started dating, there was just a joy to Nate that was different
- He had an extreme way of living
  - Which was concerning then and throughout her entire life with him
- He was here for the moment
- He was here to have a good time and feel it all, experience it all
- He was the most loving human being you’ll ever meet
- She couldn’t understand how she was attracted to him because it didn’t match anything that she had imagined
- When they started talking, the things he was talking about were the same thing as her
  - What do you want to do with your life?
  - Who do you want to be?
  - What books have you read?
  - What type of spiritual practices do you have?
- They were 19 and 22
- She remembers he was on this deep search for meaning and purpose
  - How do we serve?
  - How do we get the most out of this life?
- They both started on a spiritual journey at a very young age
  - That’s what she always loved about him
- She married a really fat, 300 pound, amazing defensive tackle in 2002
- They got engaged at the World Trade Center in July 2001, at the top of the tower
  - A couple months before [9/11](https://en.wikipedia.org/wiki/September_11_attacks)
- He played for the [Giants](https://en.wikipedia.org/wiki/New_York_Giants); they lived in NY for a while

## Nate’s unbelievable work ethic and desire to play in the NFL [12:30]

**What did Kelsey think about Nate’s chances at playing in the NFL?**

- Peter notes, “*Nate was not the guy who was going to get drafted in the first round*.”
- She can hear Nate laughing when she said, “*You’ll never make it*”
  - He always replied, “*If I can just get a shot, I’ll just work my way*.”
- He almost lost his scholarship in college; he wasn’t a starter
  - He was 4th on the depth chart
- But they were young and she still had a year and a half of school
- He had a really fast 40; he had a good combine
  - Carolina had a great year
  - He was back-up to some guys who were going first and second round
- Their families (on both sides) weren’t into football
- The day of the draft, she didn’t understand it
- Nate thought, “*If I could just get a chance on a practice squad then I could make it. And then we could save a little bit of money and then we could maybe buy a house someday*.”
- When he got called by the [Giants](https://en.wikipedia.org/wiki/New_York_Giants) to be on the practice squad everybody was shocked

> “*There was nobody that made the good guys try harder than a guy like Nate, because he would just literally go until he couldn’t*”— Kelsey Chittick

- She was young then, and she was never that invested in his career
  - She just wanted him to make some money, get out safe, then they could start their real life

**Jeff Saturday**

- Peter asked if she knew [Jeff Saturday](https://en.wikipedia.org/wiki/Jeff_Saturday) when he and Nate were roommates
  - Jeff went on to become one of the greatest centers of the game
  - To think that he got overlooked…
- Yes, Jeff is still one of her best friends (and his wife)
- Jeff and Nate lived together from freshman year
- Jeff tells this great story about when he first met Nate
  - He went to introduce himself but Nate was sobbing, hugging his parents
  - He thought, “*Wait, I’m going to be rooming with this crybaby, what’s happening?*”
- Jeff was from Georgia; grew up in a rough life, very tough
- He and Nate ended up being best friends
  - They played together along with Chris Kaldor who was up for the [Heisman](https://en.wikipedia.org/wiki/Heisman_Trophy), there was a group of them
- When they were waiting for the draft, Chris had been the quarterback and Jeff was the center, and they were certain they were going to go
  - Fourth round, fifth round, and they all just sat there waiting for the phone to ring
  - And nobody called
  - The only person that got called was Nate
- So Nate went on to the Giants and got on the practice squad, and barely made it through that first cut
- Then he got released by the Giants and the [Colts](https://en.wikipedia.org/wiki/Indianapolis_Colts) picked him up right away
- Nate moved to Indianapolis
- At that time, Jeff got a shot at Baltimore on a practice squad but didn’t make it
  - So he came back to North Carolina, started working at a PepBoys
- They didn’t think he had a shot; it was over, he was too short
  - Nate used to always tell him that he has short arms; he’d never make it as a center
  - Nate just always went up against him in practice for four years
    - He always said, “*He’s the best fucking guy I’ve ever played against*.”
- Nate was still barely making the Colts,
  - You only get paid week by week if you make the team and if you play
  - At one point when Nate had a really tough practice, he realized the guys he played against weren’t even close to Jeff’s ability
  - So he walked into Polian’s office in dirty sweats
    - Polian doesn’t even know who he is
    - He is just like a guy trying to make the team.
- And he said “T*here’s a guy in Raleigh, North Carolina, that’s working in an auto parts store right now. His name’s Jeff Saturday. And he could kick all those guys asses that I just played*.”
  - The coach said, “*Well, if you want him to come live with you I’ll give him a shot*.” And then that was it
    - 6 pro bowls later; he would go on to become a hall of famer

## Life with a professional football player, playing through pain, and head injuries related to football [17:00]

![](https://peterattiamd.com/wp-content/uploads/2022/05/rams.jpeg)

**Figure 1.** Nate on the St. Louis Rams. [[source](https://www.tarheeltimes.com/bio1621.aspx)]

**In ‘99 Kelsey and Nate were at the** [**Rams**](https://en.wikipedia.org/wiki/1999_St._Louis_Rams_season)**, in St. Louis.  Did Kelsey think it was going to happen?**

- Peter remembers this year because of [Kurt Warner](https://en.wikipedia.org/wiki/Kurt_Warner)
  - This was the beginning of that playoff run
- It was really fun; they were winning
  - She was in college and would fly to see him
- [Kurt](https://en.wikipedia.org/wiki/Kurt_Warner) was an exceptional leader, spiritually, emotionally, everything
- The team just had a bunch of really good guys on it and it was fun to be a part of that team

> “*I’ve always felt like the energy matters the most*”— Kelsey Chittick

- The energy on this team was good
- Every time they won, they knew it may never come again
- They had [Dick Vermeil](https://en.wikipedia.org/wiki/Dick_Vermeil) as a coach
  - He’s still one of the greatest humans to her
  - He continues to come to her house twice a year to see the kids and just have dinner with them
  - He was an exceptional advocate for his players as human beings, way past their football
  - He was the one that gave Nate a shot multiple times just because of his character
    - He said “*He’s not that good but he really makes the other good guys better*.”
- St. Louis was on fire
- At the last playoff game, in the last second she remembers thinking, “*Whatever you do don’t put Nate in. Please don’t put him in*.”
  - Nate was very offended when she told him this
  - She didn’t want him to be that guy, if they lost the game
  - But they tackled the guy before he got in the end zone and the Rams won and it was just exceptional
- It was fun; they danced and had a great time.
- They never took any of it for granted; they loved all of it
- Even though Nate was in a ton of pain, always

**Nate worked hard through the pain**

- Peter comments on how early in his career he was in pain
  - He was 22 and trying to get into the NFL and already dealing with this type of discomfort
- Nate was banged up, because when you play on the line that’s a whole nother ball game
  - When you are not a starter that gets to take breaks

> “*So Nate was the workhorse and so he took so many hits*”— Kelsey Chittick

- He was not skinny when he got to college
  - He was a basketball player in high school
  - In order to play his football position at UNC, he had to gain a ton of weight
- He weighed maybe 300 lbs when they got married (compared to 200 lbs when he got to UNC)
  - To move that amount of weight around that fast and that often took a toll pretty early
  - His neck was a 21, could that be right? It was enormous
- The first night she slept with him, not literally, but she remembers thinking that his snoring wouldn’t work
- At age 22, when he got into the Giants, within a couple weeks they gave him a [sleep apnea mask](https://en.wikipedia.org/wiki/Continuous_positive_airway_pressure)
  - It is awful to look at but it has this wonderful white noise sound, your husband doesn’t snore, and it helps him sleep
- Early on she thought he was too big to do what he was doing without paying a price quite often
- He wasn’t a complainer; he always knew he chose this
  - But she could tell he spent a lot of time just managing where to put the pain
  - And just accepting this is what it takes to get them where we want to be
    - Which was to same some money to go and start a life, to serve people or whatever

**What did she think then, not having the perspective she does now**

- Did she imagine what he would be like at 50 as a result of the injuries he already had?
- Nate was always into health, always learning about his body
  - He took great care of himself and had great people like [Mike Clark](https://en.wikipedia.org/wiki/Mike_Clark_(American_football,_born_1954)) that were doing good things
  - He was aware of what he put into his body
  - He did ice baths and all that stuff
  - But he loved wings and beer and partying
- She thought when he was done with football, he would lose the weight
  - He’d become hot and skinny and they’d live a happy life
  - She never thought he would stay so big
    - She thinks being big is something these guys love about themselves; they don’t actually want to get that much smaller
    - She thinks Nate secretly loved being big because when he would lose weight and go down to 235 lbs he didn’t love himself as he did when he was 260
  - As the years went by, they would fight about when he was going to start losing weight and watch what he was eating

## Nate’s final days of football and early retirement struggles [23:30]

**Was it a happy day when Nate retired?**

- They got married in ‘02 and Nate retired right before their son was born in ‘04
- She had mixed feelings
  - He didn’t have a job or a lot of life skills
  - Email had just started and Nate was not great with technology

> “*He lived in a world way up in the sky. He lived in big dreams and big hopes.*”— Kelsey Chittick

- She was like, “*We have a baby on the way, and what are you going to do for a living?*”
- She was a pharmaceutical sales rep
  - Not her ideal job but a great job to have coming out of college
- A  lot of guys transitioning out of football have only played for 3-5 years
  - They’re dropped into a world where their friends from college have been working for 5-6 years
  - Now they are starting at an entry-level job with a salary of $40,000 a year
    - They used to make this in a week
  - It’s a huge transition
- Peter remarks on the median experience for a professional football player
  - The mean gets dragged up by guys like [Tom Brady](https://en.wikipedia.org/wiki/Tom_Brady) and [Aaron Rogers](https://en.wikipedia.org/wiki/Aaron_Rodgers)
    - Guys with remarkable longevity and skill, who make a ton of money
  - But a guy in the middle, 50th percentile, might be in the league for 3 years and made a million or 2 before paying taxes and agents
- The other thing to consider, what did this do to his life expectancy
  - How many years did he pay for that?
  - From this perspective, football is the worst
  - Boxing would be another example
  - It’s easy to see the guys at the top of that, but the pyramid those guys stand on is a wide base
    - And those guys at the base are getting crushed
- Kelsey continues to have a duel experience around football
  - It’s a great unifier and community builder that brings people together
    - It brings people joy and opportunity
  - There’s a whole other side that we don’t see often
    - The guys that played for 3 years are still beat up or don’t have any money
    - These guys have a hard time transitioning
- Watching the playoff games is so fun
  - It makes you love football
  - But she would never let her kid play

**Kelsey’s outlook on life after football [26:15]**

- She used to think she had all the answers about certain things
  - She had strong opinions
- Now she’s more conflicted about a lot of things
  - Maybe that’s a good thing
- She’s conflicted about football
- Nate’s not here but she would love to hear his perspective on this
  - His buddies view this as benign the king of what everybody wants to do, an opportunity that kids dream of
  - But there is a price and ESPN doesn’t show what these guys are doing 10 years later
- Where are these people that were so amazing 3 years ago or 5 years ago?
  - What do they do now?
  - Where do they live?
  - What does their crib look like today?
  - How are they financially?
  - How’s their relationship with their children, with their kids?
- She’s been surrounded by guys like [Tony Gonzalez](https://en.wikipedia.org/wiki/Tony_Gonzalez) and [Jeff Saturday](https://en.wikipedia.org/wiki/Jeff_Saturday) who are exceptional men, husbands, friends
  - But she knows that is not always the case
  - The [book](https://www.amazon.com/Second-Half-Surviving-Finding-Missing/dp/1951407490/ref=sr_1_1?crid=IEK8121RTXV2&keywords=Second+half%2C+surviving+loss+and+finding+magic&qid=1646659573&sprefix=second+half%2C+surviving+loss+and+finding+magic+%2Caps%2C311&sr=8-1) has brought out very strong opinions on both sides

***What city were you guys living in when Nate retired?***

- He got released by Kansas City; we went out to visit a friend that lived in [Manhattan Beach, California](https://en.wikipedia.org/wiki/Manhattan_Beach,_California)
- They were there when he got picked by up by (she doesn’t quite remember) the Rams again
  - Vermeil always grabbed him again when he could; he’s a good man
- He played another year and a half
- His last team was the [Cardinals](https://en.wikipedia.org/wiki/Arizona_Cardinals)
  - They gave him a shot, but he was done
- He was emotionally done
- You have to really want it
- He was really tired of sitting in meetings
  - There’s a lot of film and watching
  - Nate was like, “*After a while this cannot be my life. Can’t just be watching run X and O’s*”
    - He had big dreams to change the world

## The tough transition from the NFL to a “regular life” and how Nate found a way to serve others [28:45]

![](https://peterattiamd.com/wp-content/uploads/2022/05/family-photo-1024x1024.jpeg)

**Figure 2.** Family photo. [[source](https://www.esedf.org/in-loving-memory-of-nate-hobgood-chittick/)]

- Once he got cut, they moved back and moved to [El Segundo](https://en.wikipedia.org/wiki/El_Segundo,_California)
- She got pregnant pretty quickly after that
- He went back to school and got his masters in social work

**Did it surprise you that that was the chosen path?**

- His dad was a minister at Harvard and his mom was a professor at Holy Cross
- He comes from an academic, service-oriented family
- Some kids are told to be bankers; he was told to serve
  - That was pretty much in his soul
  - And he didn’t have a ton of skill sets
- He studied communications in college; Kelsey notes “*like we all did*”
  - This reminds Peter of a funny story; he’s not going to name names
  - A few years ago, he was helping out a buddy who wanted me to come and do some work with the kids who were going to be probably the top 10 picks out of college
    - They all went in the first 2 rounds, including Heisman trophy winner
    - So, there’s 10 of us there, the guy who brings Peter in to help, Peter, and then there’s these 10 kids
    - Some of these kids are playing right now and are the best in the NFL
  - So, the guy who had Peter come and talk to them, he’s like, “*Hey look, we did some blood work on them, we want to talk about nutrition, we want to talk about what can they do to optimize their performance*”
  - So, he brings me to a beautiful conference room in [Petco Park](https://en.wikipedia.org/wiki/Petco_Park) in San Diego
  - Peter begins by trying to explain some of the biochemistry, but he’s not going all in on this
    - He’s just asking, “*you know glucose?”*
  - The guy who won the Heisman, was like, “*I don’t understand any of this*”
    - And one of the other guys, who was probably the single most successful one that came out of that class, he’s like, “*Dude, did you not take biology? Well, I took it*.”
- Kelsey notes this class was 25 years ago; it was different back then
  - She managed a lot of Nate’s life then

> “*In a marriage they say someone’s the balloon and someone’s the rock, he was like the biggest, Goodyear Blimp on the planet earth. And I was the most uptight, neurotic, best rock you could, I mean, there was no fun, no joy, no nothing*”— Kelsey Chittick

- They had a lot of tutors in college; they needed a lot of help

**The transition from professional football player to a normal life, with a normal job is difficult**

- She can remember worrying about Nate getting a job, that it would be a disaster
- Your ego has to adjust to being nothing
  - From signing autographs as a super bowl champion, to being an assistant to whatever you get when you’re 24, 25
- School seemed like the best way to slowly modulate back to a normal life
  - To learn to be responsible and have due dates and deadlines
- He had a dream to help people, but he had no idea what it meant to be a social worker or how much you made,
- She remembers when he finished, graduated valedictorian
  - This was exceptional because he barely got out of Chapel Hill.
- He went to an interview and he’s like, “*they said this is $50,000 for the year… that is slavery*.”
  - She was like, “*wrong word*”
- He couldn’t believe that everytime he wanted to take a vacation he would have to ask somebody with a sheet and put the dates down
  - And it’s only for 10 days
  - He couldn’t believe it; he was floored
  - She was like, “*welcome to the real world*”
  - In football they had a good 4 months off to do whatever
- He was pretty depressed during that period of their lives
- She remembers early on asking, “*I need to know, can you do this? Are we going to make this?*”
  - They had a son now
- This transition was a problem for most football players
  - 70% of guys broke-up and divorced after they finished football
- The average years guys play is 3; they’re in their mid 20’s when they leave football

> “*So, there’s a lot of people that are literally falling off a cliff after they do professional football*”— Kelsey Chittick

- These guys go home and they work at a bar in their high school town because they want to feel good again
- Kelsey and Nate were just determined to find a new way
  - But it was bumpy
  - He was sad
  - And Nate was always very aware; she doesn’t know if he had anxiety but he had depression
    - She knows he didn’t want to feel bad, and he hated that he did, and he didn’t know why
  - He worked really hard
    - He was well read and he would try everything
- After a while, once he kind of started to find some purpose in social work, it got better
- But then at a certain point he’s like, “*I can’t live on the salary.*”
- And like every good athlete does, he decided to go into financial advising, because there’s nobody you want to manage your money more than a football player
- He felt that he’d seen so many guys lose a bunch of money to the wrong people
  - So he loved finance, investments, gambling in the stock market
- He moved into that at [Morgan Stanley](https://en.wikipedia.org/wiki/Morgan_Stanley) and loved it
- He ended up starting helping guys that were in unions, like just blue collar line workers and Verizon guys that needed help with the money that they’d saved
- He felt like he got the Allentown and the finance stuff and was able to serve
  - That ended up being his career that he took on for the rest of his life

## Nate’s struggle with his weight and overall health after retirement [34:45]

- Kelsey recalls, “*I rode that man so hard for his whole life. He could take more beatings from me verbally and from coaches and teams*.”
- She was tough on him
- He wanted to be better
  - He would have times when he really got in shape
  - He was the guy in their neighborhood who everybody listened to, health wise
    - He had all the information
  - He would be sober in January, February
  - And then the sun would come out again; things would get a little dicey in March and April
  - By summer he was full bore, having a ball; and once the Yankees started, the wheels were off
  - They would cycle through this

**Did he ever go visit a doctor during this period of time?**

- The NFL has a program where you go once a year
  - She doesn’t know the details, but they sign something where to say, you’ll never sue them, and they provide care
  - In this program they took a lump sum of money for the promise of never to sue them
  - In their program, guys are checked mentally and physically, once a year
- Kelsey recently found his records from his last year
  - Everything was fine except for this one page that was so not fine
    - This was his heart, his cholesterol, and his weight
  - They didn’t really talk about this
- If she could go back, she would take a different tactic
  - She was so sacred
  - It didn’t’ feel safe for him to tell her the truth so he put it aside and thought he would take care of it
- She always wanted him to be skinner
- His mom always asked him to lose weight
- This was really hard for him
- He always worked out; he was very physical and athletic
- Peter notes that people think a defensive lineman or defensive tackle is so big that they can’t be fast
  - But they are so fast

> “*He was the strongest man I’ve ever seen. And he had a work ethic. He could go forever. He could also rest forever too. He was extreme in every way, good and bad*.”— Kelsey Chittick

- Their daughter was born in 2008

## Kelsey’s anxiety and premonitions of Nate’s impending death, and Nate’s changing demeanor [37:30]

**Fast forward to November 2017 and Kelsey’s premonitions that something wasn’t right**

*Peter asks how much of this can she only appreciate in a retrospective scope versus what she thought at the time*

- Did she think something was wrong with her, that she was losing it?
- Her friends will say she was very vocal that something was wrong
- She was anxious
- Kelsey would say, “*I don’t know what’s wrong. Something’s not right*.”
  - She was scared and nervous
- At the time she was working in Chapel Hill, in medical recruiting
  - She had a team of guys she had gone to college with that played football
- Starting in 2012, she would go back every month because her team was there
  - She’d be gone 3-4 days
- But around 2014-2015 she started dreading leaving the family
  - This made no sense
  - The  kids were a great age
  - Nate was doing great
  - But her anxiety was through the roof; she would wake up sweating
- She doesn’t know woo woo-woo spiritual she can get here, but she felt like something was coming
  - She didn’t know what it was
  - There was something about Nate that was floating away and she was trying to get to him

**Was she an anxious person by nature?**

- Growing up, she didn’t think she anxious, but she needed to swim 6 hours a day; so it’s hard to say
- She doesn’t remember being nervous or fearful
- She admits she wasn’t a lot of fun
  - She wasn’t, the party girl; she didn’t do drugs
  - She wasn’t the one to say, let’s stay out all night
  - She was always like, we need to get home
    - She was never the one to say, lets just see where the wind takes us
  - She was very responsible but not anxious
    - She didn’t have panic attacks
    - Or those nights where you can’t stop your brain from going
    - Those happened more an more in the 2 years before he died
- Now she found herself trying to manage this unexplained anxiety
- She talked to Nate about her anxiety all the time

**What would she say to Nate?**

> “*Please don’t die*”— Kelsey Chittick

- Nate would say “*I promise I’m not going to. I won’t leave you. Don’t worry. I’m here*.”
- She would tell him that she couldn’t live without him
  - He was her best friend
  - The best dad in the world
- He would tell her that he’s right here and is never going to leave her
  - Now fast forward, she doesn’t think he’s left, in many ways
- He would tell her, “*you just need to calm down*”
- His big thing was to stop being afraid
- He would tell her, “*What if you just knew everything was okay?*”
  - This was his message, everything’s okay; you’re okay; we’re okay; the kids are okay
- Then there were nights where she would go to bed and he would be watching a show
  - Something like [Oprah’s](https://en.wikipedia.org/wiki/The_Oprah_Winfrey_Show) final show ([Mr. Holland’s Opus](https://en.wikipedia.org/wiki/Mr._Holland%27s_Opus)) and he’d be sobbing
  - She would ask what was wrong and he would say, “*I just hope I have enough time. I hope that I can make a difference in this world*.”
- Then there were times when she would wake up and couldn’t find him
  - She felt like he was gone
  - She would scream for him and he’d be like, “*I’m right here. I’m in the other room*.”

**Kelsey’s self-help journey to battle her fears and anxieties [41:00]**

- This is when she started to dig into self-help and spiritual books, looking for an answer
  - But this gave her a huge toolkit for what was coming
- [Vishen’s](https://www.vishen.com/) book [The Code of the Extraordinary Mind](https://www.amazon.com/Code-Extraordinary-Mind-Unconventional-Redefine/dp/1623367085/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1646939262&sr=8-1) was pivotal
  - She read it with Nate and gave it to Tony
- Then through a bunch of beautiful synchronicities, she got to go to an event in Jamaica
- She grew up in a spiritual family that was very open minded religiously
  - The idea was about love, and God, and being fearless

> “*I come from a very fear based family, but we really believed in being fearless. Just no one had mastered it quite yet*”— Kelsey Chittick

- Nate kept saying that she had to fix this; she couldn’t keep living like this
- Nate was doing great at this point
  - He was starting a nonprofit in Watt
  - He was really happy

**Changes in Nate near the end [42:30]**

- But she felt like something about him was floating away
- He knew something was wrong with him too
  - He would forget things
  - While barbecuing he set the fence on fire by accident
  - He would make little mistakes
  - He started doing mind exercises
  - He felt really sad the last year
- He was still in touch with Tony, Jeff, and all the guys
- She doesn’t know if he talked about it to a lot of people
- His best friend in the neighborhood Chris noticed that he wouldn’t share anything anymore
  - He didn’t seem like himself
- When Nate got together with his buddies, he would be much more normal
- The kids don’t remember his sadness; it was subtle
- She found his journal soon after he passed
  - Many entries were about being more connected or finding joy again
    - Trying harder
- At the time she didn’t realize how sick he was
  - She didn’t know what was wrong with him

> “*Once I found out I was devastated because I was so mean*”— Kelsey Chittick

- She wishes she could go back and be kinder, but she had no clue
- He would just deal with it on his own
- All of the sudden he seemed older; he become tired more quickly

## The traumatic experience of learning of Nate’s death during her own spiritual journey to Jamaica [45:30]

**Back to the Jamaica story**

- It’s early November 2017 and she doesn’t want to go on this trip
- They went to New York about a month before, for a birthday
- She had one of her biggest (and last) panic attacks
- One night she tells Nate that she doesn’t want to go to Jamaica; he pulls off his sleep apnea mask and tells her she’s going, she needs to live fearlessly
  - He tells her, “*You have all these gifts and you are trapped in our house and in all this fear, and it’s time for you to go. And I want you to go on that trip and I want you to come back changed*.”
  - This from a man who never told her what to do
  - He was very supportive, but this was non-negotiable
- Nate drove her to the airport for the trip
- On the way she was texting with Toby and got invited to [A-fest](https://www.afest.com/)
  - This event was a  spiritual retreat in Jamaica with amazing speakers
    - Wim Hof, Steven Kotler, Marisa Peers, Jim Kwik
- As she’s texting Toby, Nate grabs here hand and asked her to put her phone down
  - He never did this
  - He said, “*I just want to be with you for the next 5 minutes*”
- So they held hands until he dropped her off at the terminal
- As he dropped her off he told her, “*You’re the most amazing woman I’ve ever met in my life.  I’ve never met anybody like you. I just want you to know, I love you more than anything, and I hope you go have fun, and that you come back a better person, and ready to do what I know you’re meant to do. And I don’t want you to worry about anything because we are going to be fine. I love you so much, so go have fun*.”
  - She’s really crying
- They texted during her 4 days in Jamaica, the most beautiful texts you could ever imagine
- [Wim Hof](https://twitter.com/Iceman_Hof?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) spode on the last day
  - His wife had died when she was young and he was left with 4 kids
  - She remembers thinking how much that would suck
- After this she has a memory of swimming on her last day in Jamaica
  - She remembers feeling the divine all around her
  - It was like everything had changed and she now gets it; she doesn’t need to be afraid

> “*If you knew the time I was swimming in the water, and you knew what was happening in Los Angeles, it would blow your mind*.”— Kelsey Chittick

- She got out of the water, threw on some shorts, and was about to go to the last event (a boat excursion) when her phone rang
  - It was a number she didn’t recognize so she didn’t answer
- Then her best friend called
  - She told her not to freak out, but Nate was at Sky Zone Trampoline park and he fell
  - She was going to Kelsey’s brother-in-law’s to get the kids and Kelsey’s mom was heading over to UCLA
  - She said, “*he’s not dead*”
    - At that moment, everything in Kelsey’s body knew he was gone
- On some level, she knew Nate waited until it was her last day on the trip
- He was smart, he knew if she had been with him she would have been like, “*you don’t die on me*”
- All the information she got on her trip to Jamaica was super influential for her recovery, her grief work, and some of the psychedelic things
- She told Toby as they were preparing to go to the airport about Nate
  - Toby thought it was ridiculous that Kelsey wasn’t talking but just packing
- On the drive to the airport she got a call from her mom, the doctor wanted to speak with her
  - He said, “*I’m so sorry, Mrs. Chittick, we tried everything. We worked on him for 50 minutes because he looked so young. He didn’t make it. Your husband had a heart attack.*”
  - Kelsey simply said, “*My husband’s dead”* with no emotion

> “*And then began what would be the most transformative, painful, and probably beautiful last four and a half years of my life*”— Kelsey Chittick

## Breaking the news to her children of their father’s death [51:00]

**The trip home**

- There was 1 plane going back to the US that day; it was late Saturday night
- She wanted to get home to her kids
- There was 1 seat left
  - But when she got to the airport, there wasn’t enough time
  - Maybe 20 minutes until departure and the door was already shut
- Through a thousand miracles she got on the plane, got the last seat
  - A guy in baggage claim told her to hold on
  - Somehow he talked to someone and they opened the plane door
  - In Jamaica, people are a little more laid back but she didn’t think this was ever possible

> “*In your biggest challenges and crises, there are angels literally all around you*”— Kelsey Chittick

- Once on the plane she went into shock
  - She felt like she was having a break from reality
  - She started throwing up in the little whhite bag; she was hyperventilating
  - She couldn’t integrate it

> “*I’d never had had an experience where you thought you were going crazy*”— Kelsey Chittick

- Nobody talked to her then on the plane
  - Now she always talks to people when she sees them like that
- She panicked for about 20 minutes, then the seatbelt sign went off
- All of the sudden there’s a beautiful Jamaican woman in a gorgeous dress standing in the aisle next to her
  - She puts one hand on Kelsey’s shoulder and one hand on her forehead and says, “*Baby girl, I don’t know what you’re going through, or what awaits you on the other side of this plane, but I want you to know that there are so many people praying for you. God loves you. And I love you and you are stronger than you think. And she said, slow your breathing down, baby girl, and decide who you want to be when you land, when this plane lands*.”
  - This recalibrated her breathing
  - Kelsey spent the next 4 hours on that flight, the layover in Texas, and the flight home deciding who she would be in
    - A week from now
    - A month from now
    - 5 years from now
    - 10 years from now
- On that plane ride she got really clear that her kids had just lost their dad, but they weren’t going to lose her

> “*That became my I north star from then on*”— Kelsey Chittick

**Breaking the news to the kids**

- When she got to LAX, her mom picked her up and it was probably the worst drive you could ever imagine from the airport at midnight
- She went to her friend’s house where her kids were
  - They were 9 & 12 at the time
  - They had been waiting all day
- On the phone she lied to her kids and asked them, “*Is dad okay?*”
  - She told them he wasn’t doing well and they should keep praying for him
  - She couldn’t bear to tell them over the phone
  - Now they joke about it, that she lied about really big things
- She got to her friend’s house, gave both her kids a really big hug, and asked everybody to leave them for a few minutes
- She told them 3 things
  - 1 – “*Your father would’ve never left us if we weren’t going to be okay, it just wasn’t his style*”
  - 2 – “*I need you to know that I’m enough. I have no idea how I’m going to do this. I don’t know how to live life without your father. I don’t know how to raise you guys without your father. But I’m certain I’m going to figure it out and we’re going to have a great life, and you guys need to stay being 9 and 12, and don’t need to worry about anything because I’ve got this*.”
  - 3 – “*The most important thing I need to know is that you are not victims, that you had the best father for 9 and 12 years, and he focused all of his energy on you. He loved you with everything he had. He was the kindest, most patient, amazing human being I’ve ever met. And some kids don’t get that for a day. So, just always remember that you’re the lucky ones. Do you understand?*”
- She asked them both, what they needed from her
  - They said, “*if you’re okay, we’re okay*”
- Kelsey tells every mother, they would be okay too

> “*What we’ve done, from that point on, is fought for joy while acknowledging excruciating pain*”— Kelsey Chittick

## The darkest days following Nate’s passing and how her children were handling grief [55:30]

- The first 2 years were just brutal
- The first night
  - If you’ve ever lost someone suddenly, you feel like you’ve been set on fire
  - She can’t explain the physical pain of grief
  - She always thought it was mental, but grief and trauma are very physical
  - You want to get out of your body
  - She had never understood suicide
  - But when the pain is so big and you have no way to describe it
- She had tons of resources, and love, and support, and she still thought, “*This isn’t going to work*”

> “*The beginning was surreal*”— Kelsey Chittick

- It’s hard to imagine how you’re going to live in a world that so quickly becomes a planet you’ve never been on
- He was everything to them
- She didn’t even know an adult life without him in it
- He was a much better parent than she was, in a thousand ways
- When the numbness wore off and the memorials were over, there was a thousand hard times
- The morgue was exceptionally awful, to go see him dead
  - She didn’t want to go see him
  - But by the grace of God, she had another angel tell her she had to go say goodbye to her husband
  - She had one of the most beautiful experiences because she got some closure that she never thought she would get
  - At the morgue, there were police and nurses, and when they pulled him out of a freezer, he was still intubated
  - Somehow this all fades away and she started talking to him
    - For about 15-20 minutes she told him how much she loved him and, and how grateful she  was, and how she would do the best for him and the kids
- When you die in a public place in LA, you have to do a autopsy
- At about 6 months, she thought “*This won’t work*”
  - She’d never had suicidal thoughts though she had been depressed, she’d been anxious
  - But she had never thought, “*How do we get out of here?*”

**Were her kids an anchor to him, an anchor holding her to this earth? [58:15]**

- Her mom used to tell her, “*The one thing you lose once you have kids is the right to kill yourself… You can’t even kill yourself once you have them, because it wouldn’t be fair to them*.”
- But she remembers thinking, she wanted to take the kids with her; they have to get to him
- There were nights when she thought it wasn’t going to work
  - She had tried everything
  - She felt lost, so broken, so scared
  - Emotionally, spiritually, physically, financially, she didn’t know how they were going to do it

**How her children were handling the tragedy in the months after [59:15]**

- Thanksgiving and Christmas were a blur
- January’s dark to begin with, but when you’ve lost the person that you worshiped, the person that was the light in the family
  - He was just great; he was a great dad
- The kids were so sad and confused
  - Like they just got screwed for their whole lives and they’ll never be normal again
- And kids just want to be normal
  - They want to go to school and they don’t want to be the person that’s dealing with the great tragedy
  - They were embarrassed
  - They would say, it’s the worst to not have a dad; it’s so embarrassing; it’s just awful
- She talked to her son Jack; he was 12 and she knew he was in a bad spot
  - He told her, “*No one makes fun of me anymore. No one jokes with me. Parents look down when I walk past them.  Everyone avoids me because they don’t know what to say*.”
  - Then there’s always the kids whose parent wants them to talk to him about it
- They did a bunch of counseling, but it wasn’t working at the time
  - They couldn’t find the right fit for everybody
- She’s learned a lot about trauma since then
  - It was a little early for the kids to be forced to talk about it
  - In [Oprah Winfrey’s](https://en.wikipedia.org/wiki/Oprah_Winfrey) book, [*What Happened to You*](https://www.amazon.com/What-Happened-You-Understanding-Resilience/dp/1250223180/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1647011473&sr=1-1), she talks about how it takes kids a while to process what they’ve seen and felt
    - Whereas adults have enough life experiences to be able to talk about it
- She kept trying to force them to do counseling and talk about the day their dad died
  - They would just close their ears (literally/physically) and rock
- The therapists didn’t recognize immediately they the kids weren’t ready to talk about it yet
  - Her daughter didn’t want to draw about it
  - She needed to forget about it for a bit to integrate what she saw
- Her son was a little more mature and he really needed to talk to someone other than Kelsey
  - Over time, he had a great relationship with a therapist for a year
  - Then he said, “*I think I’m done for now. Thank you so much for your help and I’ll call you if I need you again*.”
  - Jack really had a clear intention at that age of what he needed through this
  - He enjoyed his time with the therapist, a woman who would just listen to him
    - This was a dig for her because he was like, “*All you do is talk to me*”

**One of her darkest nights**

- One night she thought, we’ve got to go, we’ve got to get to dad
- They use a lot of laughter in their house; tongue-in-cheek she told Jack, “*I’m thinking about killing all of us*”
  - He asked her how they were going to die
  - There were so many different ways, but she thought the best one was to drown the kids in the tub
    - He was like, “*Great*;” he was 13 at the time
    - He pointed out that he was 4-inches taller than her and so much stronger
    - Further, she only lets them put 2-inches of water in the tub because of the drought in LA
  - The more they talked about stuff, the better it got
- A couple weeks later Jack told her, “*You know mom, if I had a gun, I would kill myself*”
  - She didn’t tell him this was awful, don’t do it
  - She said, “*I totally get it*”
  - She remembers thinking, “I *know how to avoid this… We just won’t have guns in our house*.”
- She told him to hang on for today and tomorrow
- Then little, by little he was like, “*I don’t think I want to kill myself anymore*.”

## A new relationship with death, finding happiness, and the duality of feelings [1:02:45]

- For the first year, there was a lot of crying at night

> “*Nights are really dark when you have grief*”— Kelsey Chittick

- Little kids need so much; she didn’t think she had enough energy to be there for them on her own
- She didn’t sleep much that year
  - Somebody always needed something at night
  - Somebody would be crying; somebody would be losing it
  - Many times they slept together
- She thought she’d  never be able to leave the house again
  - She felt like her life was over, that she’d never have fun again, never be happy
- Amongst all of this, she also thought they were going to be okay
  - There was a knowing somewhere, that this was part of grief but it wasn’t always going to feel this way
- She toggled through hopefulness and devastation

> “*I knew we needed to hold onto the fact that this was appropriate and it wouldn’t last forever*”— Kelsey Chittick

**How this might have been different 10,000 year ago**

- It would not be uncommon to lose someone to infection or an animal attack

*Peter asks if she would have had an easier time 10,000 years ago because of expectation that something like this can happen anytime, and being supported in a community instead of stuck in her own house*

- Yeah, the expectation now is that everybody lives until their 90, happily married with 2 kids
  - That expectation has set us up to be much less resilient
  - The expectation is that it’s all about fun and joy
- 10,000 years ago, you saw people recover all the time from awful things
  - Babies died
  - People went to war
  - There was famine
- We have so much now, and our anxiety is higher than ever before
- It’s counterintuitive, when you have everything, you don’t want it to fall apart
  - With this comes anxiety
- Back then, they knew things weren’t good but they would handle it
- We’re not used to feeling extremely uncomfortable anymore
  - Life is so comfortable, things are so easy for people with resources
  - We have this idea that pain is bad and death is bad

> “*Now I have a completely different relationship with death*”— Kelsey Chittick

- She has a completely different relationship with what it means for the physical body to leave
  - Nate isn’t gone
  - They didn’t get screwed
  - There wasn’t a right time for him to leave or not
  - There’s so many nuances that, through the last 4.5 years, have changed the way she feels
- She’s still toggling between all the different ideas around grief
  - Her mother-in-law believes she will grieve forever
- Our country wants everyone to be happy and she’s not happy
  - But she’s fine with that choice

**Duality of feelings**

- Back to this football analogy of holding two beliefs at the same time, she believes she can be grieving very deeply and be very grateful at the same time
  - You don’t go through one stage then the other
- She misses Nate terribly and she’s so happy
  - She’s happier than she’s ever been in her life
- She’s been through the worst thing ever
- She also had some medical stuff; she thinks that came up from grief
- She’s so excited about life

## Nate’s autopsy results showing evidence of CTE [1:07:00]

**When did she get the autopsy results back?**

- He died of [cardiomyopathy](https://en.wikipedia.org/wiki/Cardiomyopathy) of the left ventricle
- The doctor called about 3 months after Nate died and said, “*We could tell right away he was a football player. His heart was so stretched out. It was so big*.”
  - You want big muscles, just not a big heart (physically)
  - When big men move that much weight around at that speed, it overuses it, and the muscle just gives out
  - The doctor said, “*Big men and big animals die early*”
  - All of his arteries were 98% blocked
  - His left ventricle had no more to give, it was like a water balloono that had been stretched out and there was just no pump anymore
  - He said,  “*Big fat people can live a long time if they sit all day and watch TV*”
- Nate died of an enlarged heart
  - She thought that was beautiful, because Nate had a really big heart
- They didn’t have the right tool at the LA County Morgue (or Coroners) to look at his brain, so they didn’t see anything

**When did she get Boston University involved?**

- A few year before she got a pamphlet from Boston university from the NFL
- She hadn’t watched [Concussion](https://en.wikipedia.org/wiki/Concussion_(2015_film)) yet, with Will Smith
- To be honest, she thought there might some compensation financially if he did have [CTE (chronic traumatic encephalopathy)](https://en.wikipedia.org/wiki/Chronic_traumatic_encephalopathy)
- She also wanted to know if he had it, so she could decide if she’d let Jack play
  - Jack was going to Loyola and wanted to play football
  - The heart thing pretty much sealed the deal
- She wondered what was was going on with Nate’s brain
- Boston University, [Dr. McKee](https://www.bu.edu/cte/about/leadership/ann-mckee-md/), and the whole group were exceptional
- The LA Coroners sent Nate’s brain tissue to Boston
- It took about a year to complete the analysis and clinical interviews

**Nate’s parents and brother**

- Nate’s parents had more of a feeling of him floating away and being different, as did his brother
- Because she lived with him day to day, it was harder to tell the changes because they’re so gradual
- Nate’s brother lives in LA, so they saw him a lot
  - For a long time they were trying to keep Luke alive
  - Then it switched, with Nate gone, Luke was still there and a huge part of their lives
- Luke said he felt the same sense that his brother was floating away
- Nate’s mom felt this too and said, “*He is not the son I knew*.”
  - This was 5 years before Nate passed

**Results of analysis of Nate’s brain**

- Dr. McKee found that Nate had stage II (almost stage III) CTE; he had lesions all over his brain
  - She said, “*That would’ve been a really hard life*”
- This gave Kelsey gratitude that she didn’t have to live with a man who was slowly deteriorating before her eyes
  - There are tons of people who have husbands that are healthy heart wise but not brain wise

**What does stage II or stage III CTE look like? [1:11:00]**

- [Junior Seau](https://en.wikipedia.org/wiki/Junior_Seau) was at stage II CTE (chronic traumatic encephalopathy) when he killed himself
- [Aaron Hernandez](https://en.wikipedia.org/wiki/Aaron_Hernandez) was at stage III when he killed himself
- Peter notes, “*If you looked at them from the outside, notwithstanding sort of the criminal side of what was going on with Aaron, they could tie their shoes and walk around, they don’t look like someone who’s in the last stages of Alzheimer’s disease. But if you understand their behavior, their moods and what people around them would say (and of course in the case of Hernandez, his behaviors leading up to everything), they were clearly not behaving the way they would’ve behaved if everything was totally normal*.”
- This is why this disease causes so much discussion and disagreements
  - Her mother and mother-in-law think football is the devil
  - On the other side, all the people who love it think the players know what they’re signing up for
- Back when Nate began playing football, nobody talked about CTE
  - Everybody was lying about it for a really long time
  - Fast forward, there is no compensation anymore for CTE
  - It would seem that anybody that dies, that’s played in the NFL probably has some level of CTE after the number of hits they take
- Kelsey notes, “*I cannot imagine living with Nate, the greatest man I ever knew, with a severe brain disease that would either put us at risk or him at risk at 42… That’s very young*.”

**What did the scientists/ doctors at Boston University say Nate’s next 10 years would have been like, based on his brain pathology?**

- They gave a list of symptoms; a lot of it was already there
  - Depression
  - Drinking
  - Wanting to be alone
  - Fatigue
  - Big outbursts of anger
    - Nate never yelled at her in 21 years; he was never mean
    - Then there were moments when he would snap
    - The doctors said that would have increased in frequency
- His brain scans show dead spots
- When some people get dementia, they’re kinder; CTE is not that way
- Either nothing is firing or it’s firing incorrectly
- She found solace in learning about his brain pathology; the kids did not
  - The kids would rather him still be there
  - It’s possibly they didn’t see Nate deteriorate like Kelsey did
  - They don’t like it when Kelsey says they’re lucky, lucky they didn’t have to see their dad deteriorate
    - So she honors them and doesn’t say this anymore
- Nate was their hero; he never did anything wrong in their eyes
- Jack agreed not to play football

## The grieving process [1:15:00]

**How long was it after Nate died that you had a good night’s sleep without medication?**

- She had never taken anything to sleep before
- The first couple weeks people were telling her to take [Xanax](https://en.wikipedia.org/wiki/Alprazolam), [Ambien](https://en.wikipedia.org/wiki/Zolpidem), something
- She took them for about a week
- But then she woke up and felt so far away from everything

> “*That was the first experience I had of traditional medicine taking you away from your pain and other things bringing you to it so you can work through it*”— Kelsey Chittick

- Medication wasn’t what she expected
- It was maybe 7-8 months before sleep became a really safe place
- For about 6 months after Nate died, she would wake up and have that nanosecond of forgetting what had happened

> “*It’s a surreal experience. It alters worlds, sudden death*.”— Kelsey Chittick

- Everyone asks, would you rather be sick or die suddenly?
  - The games we play with grieving
  - Peter wonders if people discussed this question 10,000 years ago
- She doesn’t wake up shocked anymore, doesn’t have the pit in her stomach
- The deep shock and grief have been gone since around 4 years
  - There started to be some space
  - There started to be some type of new neuro-pathways that they live in now
    - These were becoming not as worn but as comfortable as the old ones they lived in with Nate
  - For a while it felt like every neuro-pathway ended with Nate
    - Everytime the door would open, she would think of Nate
    - Everytime she would eat dinner, put the kids to bed, get in the car, etc.
    - He was like a shadow
- Over time, the more she did, the more she traveled, the more new people she met, things started firing and her brain started to adjust to a new world that didn’t have him in it
  - She could feel the stress go down

**With phones we have a billion photos and videos.  Did she ever make a decision about the frequency with which she would indulge in looking at these?**

- She talks about this all the time in grief groups
- When she thinks about a memory, she will give herself 7 minutes to go through some videos
- For a while she would call a girlfriend at night and spend hours going through videos and pictures
- Recently she’s started doing some Buddhist practices
  - Setting a time to feel
  - Her emotions were so big for so long and she still works on that
  - Being aware that her emotion is not her, but it’s just coming through her
  - She can get to close the door if she wants and she can open it when she wants
    - That has been a practice that’s changed her life the past 2 years
- Grief is a very tricky thing
- She feels like she knows how to help people that are grieving, because she’s felt it
- She doesn’t know how she feels about videos
  - She is grateful to have them
- Her kids don’t look at pictures; they don’t like them

## Dealing with grief with kids and how children grieve differently [1:19:15]

> “*Kids are a great thing to have and they’re exhausting to have during grief*”— Kelsey Chittick

- Kids keep you going in a regular life
- At the same time, you can’t really grieve until they’re gone
  - They don’t like to see you sad
- She’s talked to a ton of people who lost parents when they were younger
  - All of them remark that if only their mom had been okay, it wouldn’t have been great, but they felt like they lost their mom too because she never got happy again
  - This stuck with Kelsey
- In the beginning she felt like her kids needed to see her sad
- But this is a fine line; it scares them to see their parent sobbing
  - It doesn’t feel safe for a 9 and 12 year old

**Are kids innately wired to move on quicker?**

- Absolutely
- Kids live in the present moment; they haven’t played out a whole future
  - They don’t know their dad missed their wedding, their graduation, etc., because they never had these things
- If you create a home that is joyful and the trauma’s allowed to be spoken about when they want, then it’s not something bad that happened
  - It’s something that they experienced
  - And we get to decide how we want to tell the story
- Kids can survive amazing things, much better than adults because they don’t have preconceived ideas
- She was lucky this hit at the right age for her kids
  - At 12 year old, kids become so self consumed and their whole world becomes their friends
  - Once her kids were in this phase, parents were just part of the background of their lives
- They talk about Nate all the time; he’s very much alive in their house
- She took down a lot of pictures because it can become all consuming (this goes back to the videos)
  - Now the pictures in the house are mostly of the kids and her

> “*We laugh a lot about the way Nate died*”— Kelsey Chittick

- Who dies during toddler time wearing orange sticky socks?
- He’s the first person in history to die jumping on a trampoline,  playing basketball with his kids
- It’s just so bad it’s good at least for a comic
- It feels like a thousands nods to her that he died on 11/11 at 11 am
- It feels like they are okay, death happens all the time

## Healing through her first psychedelic experience [1:23:00]

- About 9 months after Nate died she had gone to an event in Estonia in the summer and a bunch of people were talking about psychedelics for grief work and trauma work
- She had gotten to a point where she was doing better, but she needed access to Nate
  - She had this deep desire to have a relationship with him, raise the kids with him, even if he wasn’t in this realm
- She remembers having a conversation about needing to get to him
  - She can talk to God and she doesn’t know where he is
  - She didn’t know how to get to Nate
- One guy asked if she had ever tried mushrooms
  - She was was like no, her brother did a lot in high school and she would never
  - She doesn’t like druggies
  - She thought to herself, “*I’m very uptight and I have two glasses of wine and I’m not fun and don’t even ask. And I’m going to judge you because that’s what I do best*.”
- Then they asked her if she’s ever tried MDMA
  - She thought this was ridiculous
- Her experience with her brother-in-laws addiction to Oxycontin and alcohol
  - He’s now been sober for 14 years
- Her experience with her brother as a partier
- Crazy people in highschool who were into psychedelics
- All of these experiences made her think, “*Why am I even talking to this weirdo? I’m never going to try that stuff*.”
- When he asked her why she realized she was afraid
  - She didn’t want to jump off a bridge after doing too many mushrooms
- He replied, “*But you’re already dead because you’re so afraid of everything*”
  - This really made her think
  - She talked to some of their friends and replied, “*I’ll be ready when I’m ready*”
- She got a call in October, almost a year after Nate died
- These friends were going to do a group with shamans and they wanted to know if she was interested
  - She was in

> “*I had probably a level 10 anxiety going into it because I had never done anything*”— Kelsey Chittick

- She wasn’t even a drinker really
- She had always been an old fashioned, uptight fear-based, neurotic person, classic
- Beforehand, the shamans called and asked what she wanted to work through
- She related a couple of really traumatic events
  - The morgue, the Coroners, telling her children about Nate’s death
  - Not remembering anything from the time she got the call until after the plane journey home
- It was a beautiful group
- They talked about intention and what they hoped to get out of it
- It was just a good group of people, loving and supportive
- It was the opposite of what she thought it would be, popping pills and dancing to rave music
- The first thing she took gave her a full blown panic attack
  - She wanted out
  - She raised her hand and was like, “*I told you so; it’s not working*”
- The shaman told her, “*We gave you a placebo because we knew that first hump was going to be a big one for you*”
- Then she did something similar to what the woman on the plane did
  - She put her hand on Kelsey’s head
  - Kelsey laid down and she actually breathed with her, through Kelsey’s panic attack
- Then she gave her a psychedelic, she wouldn’t tell her which one
- They were all lying in a circle
- Someone asked, “*Have you dropped in?*…*You’ll know when you drop in*.”

**Reliving the plane trip home**

- 3 minutes later she knew she was in
  - It was so ridiculous, so embarrassing
  - She thought they were going to have to babysit her all night
  - But within 3 minutes, she was back on the plane, right then
  - She started to cry; her friends tell her she was loud
- Everybody in the journey space came and sat next to her
- They did the flight together and she felt supported
- She cried and cried and said, “*This is so scary, he’s dead.*”
- They replied, “*We’re right here with you, you’re not alone. We’re right here, you’re safe. Look how strong you are. You’re going to your babies*.”
- It felt like 6 hours, but it was probably 5-6 minutes
- She did the whole flight again, but with support
- After this, she had peace about it
  - She remembered the whole thing, what seat she was in, transferring planes, all that stuff
- She got up, got some water and thought she was going to be drunk and crazy
  - But she was just regular again
  - She talked to some people
  - The shamans asked if she was going to go in again and she did
- All she had to do was lay down again

> “*This whole process was insane to me, that I could modulate my experience safely by my intention and whether I closed my eyes or no*t”— Kelsey Chittick

**Reliving the trip to the morgue to say goodbye to Nate**

- She revisited the morgue
  - She was really angry
  - She had a ton of anger that left her, that she had never accessed
    - Rage, thinking, “*You fucking left me at 40. You promised you wouldn’t, you’re a liar. You left me with a nine and 12 year old, you bastard. I told you to lose weight*.”
  - She had never went through this grief stage in the previous year
    - She just felt sad for him
    - Wondered where he was, hoping he was okay

**Finding Nate**

- After hours, her friend said, “*Why don’t you go find Nate? You’ve done the work. You’ve gone through a bunch of things*”
- She laid down again, one of the facilitators came and Kelsey asked, “*Can you just remember whatever I say? Because I think it’s going to be good. And I need you to write it all down*.”
- Fast forward to the next day of the integration and the facilitator remarked, “*It was too beautiful. I couldn’t remember anything. I just sat there and listened.*”
- She remembered laying on the couch, calling for Nate, and seeing him right in front of her
  - He told her, “*I’ve never left.  I’m still here, my body wasn’t serving me anymore*.”
  - She asked what he meant and he took his whole body and just threw it on the ground, like it was clothes
  - He showed her their kids
  - They agreed the kids are stronger than she thinks
  - He gave her some tips about what they needed from her and how to raise them
    - Slow down with Addison
    - Spend more one-on-one time with Jack
    - Only things he would know
  - Then he said, “*The biggest thing is, you’ve got to live fearlessly.  I’m going to show you what it feels like*.”
    - And then they flew around the universe and it was probably the first time in her life she felt free
  - He told her, “*You have a choice right now to just have the best life and I want you to go live it. And I’m right here, you can access me at any time. Just call for me*.”
- From that point on, they’ve had a great relationship
  - She feels him
  - He send her songs and birds and hummingbirds
  - If she pays attention, he’s everywhere

> “*I don’t know where you go or what happens, but I am very clear that if we’re made of energy and if I can talk to God, why wouldn’t I be able to talk to Nate?*”— Kelsey Chittick

- Now she talks to him all the time, and he just listens even more
  - He tells her things in very quick, 2-3 words, “*You’re fine. Yes. Slow down, stop talking*.”
    - There’s a lot of stop talking
- She asks him why he played football
  - He said, “*Because it was the easiest way for people to respect me and listen to me, so I could share with them about love.  I never really loved playing football, but I love that it gave me access to people, so I could talk to them about the stuff I really wanted to talk about, which was never about football*.”
  - He never talked about football once he was done
  - He loved watching it with his buddies
- He told her not to worry about him and that it’s exceptional where he is

**This experience was beautiful to her, probably one of her top 3 experiences in life**

- With Xanax and Ambien you just black out and have  no idea what happened
- The mushrooms and plant experience gave her an ability to go toward her grief, understand it, walk though it, and come out of it knowing they’re all okay
- She went from being most afraid of death
  - She didn’t want anyone she loved to die; she didn’t want to die
  - To a point where now she has a great peace about it

> “*I’m so fired up about plant medicine now*”— Kelsey Chittick

- She’s done it 5-6 times since then
- Nothing is quite a mind blowing as that first one

## The therapeutic potential of psychedelics, meditation, and more [1:33:45]

**What have subsequent trips been like?**

- She has had some with focused intention, looking for answers
- On others she’s been like, “*Just tell me what is.*”

> “*For me, it feels like a download of information*”— Kelsey Chittick

- It feels like a connection that is so much bigger than anything she could have in her day to day
- She’s spent her life trying to be great at everything and have people give her approval
- She noticed in her first experience (and in all the subsequence ones) that her ego completely goes away
  - She’s the biggest judgment
  - She’s a comic, she tries to make fun of everybody, use everything against people
- In these experiences, she has no judgements on anybody
  - It’s 10-11 hours where she is not worried about what people think of her or what she thinks of them
  - It’s such a relief
  - This is the biggest thing she gets out of it

**This is what it would be like if her ego got out of the way and she was just present with what is / who is, and she just sees good**

- She never felt that taking psychedelics was a mistake
  - It wasn’t scary
  - She hasn’t done any ayahuasca (yet)

> “*It’s a lot better than getting drunk and crying*”— Kelsey Chittick

- She stopped drinking pretty soon after Nate died, because she’d drink tequila and just sob
- It’s clear now that alcohol is a depressant
- If she drinks red wine or any type of alcohol now, it cues anxiety
  - The sugar makes her heart race
  - If she can’t sleep, her brain starts going; it’s not a safe place
  - Alcohol doesn’t work for her anymore

**Did you talk with your kids after the psilocybin experience?**

- No
- But if they see this podcast
- Jack is 16 now, so he would understand it
- They hate drunk people
- There’s been a connotation around drugs in their family, that it’s really not good
- She doesn’t know when the right age is to talk to her kids about it
- Peter hasn’t talked to his kids about psychedelics yet
  - Except to try and explain the legality of a drug is a second order consideration
  - First you want to think about the drug and what it will do
- Peter asks patients all the time, “*Tell me how many drinks you have in an average week. Tell me which recreational drugs you use*.”
  - It’s not judgemental
  - He discusses how certain drugs (like alcohol) **change your state** but don’t **change traits**
    - Other drugs change your state and can change your traits
  - Legal and illegal drugs are in both of these camps
    - It’s worth noting and respecting

> “*But really the things in this camp you have to really ask yourself, how often am I doing this? And why am I doing this?*”— Peter Attia

- Cocaine clearly changes your state
  - People have told him how great they feel on it
  - Peter’s never done cocaine and when he asks people, they can’t make a compelling case that it makes them better when they’re not on it
- He thinks the same is true for alcohol

**Peter’s takeaway: Psilocybin and MDMA have the potential (if done correctly) to make you a better version of you long after that medicine is gone**

- Kelsey agrees; she’s a different person (better) because of those experiences
  - She’s less afraid, more patient
  - She thinks she has less answers; she’s more open
  - All the things that you hope to get in therapy, but it’s very hard to get your brain to change
- Psychedelics opens up a pathway that was blocked
  - It was always there, you just hadn’t gone down it
- When she took psilocybin and it moved that blockade, there was a road she never knew that was just ease and love and fearlessness
  - And after she was done, she started to walk down that road more often in her day to day life
  - For so long, it wasn’t even accessible to her, and now it’s a road that she chooses quite often
- The same is true for MDMA, though she’s done that very rarely
  - It showed her how to be fun and connected again
  - It showed her how to be without judging, just listening
  - She used to be so edgy
- Now, even if she doesn’t do it, she remembers the feeling
  - She can access that neuro-pathway and be calm, not worry

**She can get herself to that new road she always had, but previously had a huge blockade in front of it**

- Peter notes, “*MDMA really has this ability to create this empathy that is very difficult for most people to access on command. Or frankly not under the influence of that medication. To me, if you can craft the intention around that, it’s an amazing thing for a relationship as well*.”
  - Kelsey agrees

> “*There’s been a ton of gifts of grief*”— Kelsey Chittick

- She’s really excited about plant journeys
- She understands that you have to be ready, be open to the experience, and want the experience

**Is it the best of both worlds to combine psychedelics with the traditional work of therapy?**

- Peter remarks, it’s dangerous when people think that the plant or molecule by itself can do all the work
- He feels psychedelics are incredible lubricants that allow you to do very difficult things, even when you’re long off the influence of those medications
- He asks, “*What fraction of your recovery has been predicated on that experience versus all that came before it and after it and around it?*”
- She’s done a ton of work, read a bunch

> “*The other big thing that I do that has supported all of that… meditation*”— Kelsey Chittick

- She’s militant about meditation
  - Before she did maybe 20 minutes a day, here and there
  - She used [Insight Timer](https://insighttimer.com/)
- Once Nate died, meditation became a must
- She noticed Peter has a [sauna bag](https://www.shape.com/lifestyle/mind-and-body/infrared-sauna-blanket)
  - She will sit in one of these with [Dispenza](https://drjoedispenza.com/)
- Dispenza’s work [and meditations] has changed her life the most in terms of a daily practice
  - Helped her change a thought
  - Or watching a thought
  - Or knowing that her feelings are transient
  - Knowing that she can change a feeling through it, changing a thought
  - Saying “*Stop*” doesn’t mean a thought/ feeling isn’t going to come, but she now has agency in how she feels like never before

**If you do the psychedelics in conjunction with a very deep meditation and committed spiritual practice that gives you peace, whatever that might be, you have a great shot at coming out of pretty much everything.**

- Peter finds it sad that meditations isn’t taught alongside English, science, math, to kids in school
- If kids had an emotional health class from the moment they entered kindergarten
  - If it was part of the core curriculum
  - If they learned to distance themselves from their thoughts 30 minutes a day, K-12
  - How many different habits could we develop
  - How could we equip ourselves

## The concept of “radical acceptance” and the peace that comes with it [1:42:30]

**Kelsey mentioned something in her book that resonated deeply with Peter— radical acceptance**

- Kelsey’s Mom was into this stuff for a long time
  - This was always in the background noise of her life
- Her dad left when she was 15 and her mom went on this journey
  - Books and people were part of it
- The idea of radical acceptance happened after Nate died
  - The idea that something wasn’t good or bad
- She knew of it in practice, but when everything seems good it’s hard to understand
- Before she experienced it, she thought it was an annoying statement
  - Like, “*Oh yeah, good luck to those people that have a sick kid or whatever. I hope they just accept what is*.”
- Now she sees what it is, and it’s beautiful
- It doesn’t mean things won’t feel hard or miserable
- It just means it is exactly what you are going through

> *“And the resistance to that and the wishing it was different is what kills you*”— Kelsey Chittick

- People will ask how she is doing so well
  - It’s because she doesn’t wish it were different

**Do the kids understand this, radical acceptance?**

- She doesn’t know; they were so young
- She is working on understanding that they have their own path
- They all have different relationships to Nate, and different stories they tell in their head
- She thinks they are surprised at how great life is compared to what they thought it would be when he first died
- Sometimes they’ll say, “*Isn’t it great we’re so happy again? Isn’t it great that we have fun again? Look at how good our life is*.”
  - That’s their way of saying they made it, they accept what is
  - They have continued to build a life that is beautiful
- They talk a lot in their house about what Nate would want them to do

> “*Nate would want us to be joyful*”— Kelsey Chittick

**So if you want to honor your dead person, the best way to do it is live the life they would want you to live if they were here.**

- The kids and her miss him, they’re happy, they accept it
- Radical acceptance gets easier the more you do it
- But until you have to practice it (because you’re in a dark spot), she doesn’t know that you can
- People ask if you can transform without going through something big
  - She doesn’t know if you can
- She had read it, intellectually knew it, but until she had to really dig into those practices and prepare with them
  - There’s a magic in that transformation when you do the work
- She asks Peter what he thinks, he has gone through hard things
  - He’s not equipped to answer that the way she is
- Peter’s good friend Ric Elias was on the USAir flight that was going to crash and somehow made the miraculous landing in the Hudson River in 2009
  - He was previously on the podcast, [#79 – Ric Elias: Earning the gift of life](https://peterattiamd.com/ricelias/)
  - Nothing bad happened to him
  - But there was a 2 minute period where he really thought, “*No, no, this is it, I am dead*.”
  - This was 13 years ago, and Rick is still living the life of a guy who was given a second chance
- Peter asks, “*Could Rick have come to this same set of principles that guide his life today without that?*”

**Peace comes from acceptance**

> “*There’s just a real relief when you stop wishing it was different, whatever it is*”— Kelsey Chittick

- When you stop wishing whatever you’re going through wasn’t and you just go, “*Let’s roll.  What have I got to learn? What’s on the other side of this? What will it feel like when it’s transformed into something different? What can I get excited about?*”
- She thinks that the practices work
- She believes that you can get through things
- She thinks her situation is fairly easy if you look at the resources she has
  - In grief, if a woman has resources, it’s a very different experience than if you don’t
- There’s a thousand things that interact to make your experience what it is

*But internally the Stoics and then the Buddhists and believing in something bigger than you, those are key pillars*

**What would you say to a man or woman or a child listening to this right now, who’s 3 months out from that tragedy, based on everything you’ve learned? [1:46:45]**

- To start, just hang on for now
- Humans are built to last, to make it through things and do the work

> “*Do the work*”— Kelsey Chittick

- Whatever that work is, wherever you’re trying to go, the work will eventually support you
- Think of it, if you’re over here and you’re trying to get over here, you got to build a bridge
  - Once you build the bridge, you’ll get over there
  - But you’ve got to work to build the bridge that  isn’t there yet

**And that’s where the meditation, and the reading, and the gratitude, and the changing your brain— those are each planks that you’re building to get over to the other side**

- And if you do the work, you’re going to look back and be like, “*Damn, I never thought I could build that bridge*.”
  - And you’re going to be more confident
  - And more joyful
  - Because you just saw you did something you never thought you could do
  - So life just got sweeter

## The up-and-down experience of writing her book [1:47:45]

[*Second Half: Surviving Loss and Finding Magic in the Missing*](https://www.amazon.com/Second-Half-Surviving-Finding-Missing/dp/1951407490/ref=sr_1_1?crid=IEK8121RTXV2&keywords=Second+half%2C+surviving+loss+and+finding+magic&qid=1646659573&sprefix=second+half%2C+surviving+loss+and+finding+magic+%2Caps%2C311&sr=8-1)

- She didn’t have any pressure
- For her, she had to get the story out
- It was very personal
- She wanted her kids to remember
- And she wanted to remember because she knew she was going to love again and have other relationships

> “*Time is a miracle when it comes to life, because as time goes on, the pain does gradually get better*”— Kelsey Chittick

- She wanted to make sure the story of this great man was recorded
  - So her grandchildren and great-grandchildren will know where they came from, and how all this happened
- Somewhere in the middle she thought, “*This is such shit.  I shouldn’t even show it to them to my worst enemy, because this is just blabber of nothing. And I’m so bored with what I wrote. It’s so dumb and it’s so ridiculous. Well I mean, just stop now, because this is torture for you and nobody’s… This is horrible*.”
- Then you get to a point where you’ve written enough and then it gets to an editor and they make it a little better and they give you some feedback and you just start cutting stuff out
- Then it got fun
  - To cut out the junk and just tell it like it is, and not worry what people think
- She so glad she wrote it
  - She can’t imagine doing it again
  - It feels surreal now
- It’s a unique experience, writing a book
  - The internal dialogue and anxiety and disgust with what you’re putting out is really epic

> “*It’s just double flogging*”— Kelsey Chittick

- You’re reading what you already hated that you wrote
- But she tells people to write it down because it’s going to help somebody
  - And, “*go easy on yourself with the book*”

**What’s the most surprising thing that you’ve received as a way of feedback?**

- So many people have written to thank her for being honest
- She thinks what this means is— not to play grief either way, the good or the bad
- There’s a duality to everything in life
  - This sense that everything isn’t good or bad
- People wrote in and told her, “*Thank you for letting us know that it was awful. And you felt like you were on fire and you couldn’t wait to have sex with other people. Thank you for knowing that you know that you lost the man of your dreams and you also get to meet other people and have a new experience. That it might be exactly what was meant to be*.”
- People thank her for sharing the multifaceted approach she has to this experience

**So there’s a whole life I’m going to have that I never even knew possible. And there was one that I really love that got taken away.**

- Peter asked, “*Did your kids read it before you published it?*”
  - No
  - And they don’t want to read it either
  - They are terribly embarrassed by it and secretly proud
- Jack took her book to the school counselor because the counselor asked about her job and all he could say is, “*she wrote a book*”
- The kids are way more private than her
- She’s learning to understand that they’ll tell it in their time
- And they’ll read it in their time
- And their experience will be very different from what she wrote

§

## Selected Links / Related Material

**Kelsey’s book**: [*Second Half: Surviving Loss and Finding Magic in the Missing*](https://www.amazon.com/Second-Half-Surviving-Finding-Missing/dp/1951407490/ref=sr_1_1?crid=IEK8121RTXV2&keywords=Second+half%2C+surviving+loss+and+finding+magic&qid=1646659573&sprefix=second+half%2C+surviving+loss+and+finding+magic+%2Caps%2C311&sr=8-1) by Kelsey Chittick (2021) | [0:45, 19:45, 27:45, 1:42:30, 1:47:45]

**Kelsey’s podcast**: [keepOn with October Gonzalez & Kelsey Chittick](https://keeponpodcast.com/) | [1:00]

**Vishen’s book**: [The Code of the Extraordinary Mind: 10 Unconventional Laws to Redefine Your Life and Succeed On Your Own Terms](https://www.amazon.com/Code-Extraordinary-Mind-Unconventional-Redefine/dp/1623367085/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1646939262&sr=8-1) by Vishen Lakhiani (May 2016) | [41:30]

**Oprah Winfrey’s book**: [What Happened to You?: Conversations on Trauma, Resilience, and Healing](https://www.amazon.com/What-Happened-You-Understanding-Resilience/dp/1250223180/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1647011473&sr=1-1) by Oprah Winfrey and Bruce D. Perry (2021) | [1:00:30]

**Previous episode of** ***The Drive*** **with Ric Elias**: [#79 – Ric Elias: Earning the gift of life](https://peterattiamd.com/ricelias/) Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (November 11, 2019) | [1:45:15]

**Stages of CTE**: [The Stages Of Traumatic Brain Injury: Learning From The Brains Of Athletes, Veterans, And One Head-Banger](https://www.forbes.com/sites/alicegwalton/2012/12/05/the-stages-of-repetitive-brain-injury-learning-from-the-brains-of-athletes-veterans-and-one-head-banger/?sh=228c00b555e7) | Alice Walton, *Forbes* (December 5, 2012)

§

## People Mentioned

- [Nate Hobgood-Chittick](https://en.wikipedia.org/wiki/Nate_Hobgood-Chittick) (Kelsey’s husband and former NFL player) [1:00, 7:45]
- [Jeff Saturday](https://en.wikipedia.org/wiki/Jeff_Saturday) (football center and Nate’s good friend) [14:30, 17:00, 23:00, 27:30, 43:15]
- [Bill Polian](https://en.wikipedia.org/wiki/Bill_Polian) (Colts football coach) [16:30]
- [Kurt Warner](https://en.wikipedia.org/wiki/Kurt_Warner) (football quarterback) [17:15]
- [Anthony (Tony) Gonzalez](https://en.wikipedia.org/wiki/Tony_Gonzalez) (football tight end and Nate’s good friend) [23:00, 27:30, 41:30, 43:15, 46:45]
- [Dick Vermeil](https://en.wikipedia.org/wiki/Dick_Vermeil) (Rams football coach) [18:00]
- [Mike Clark](https://en.wikipedia.org/wiki/Mike_Clark_(American_football,_born_1954)) (strength and conditioning coach) [22:15]
- [Tom Brady](https://en.wikipedia.org/wiki/Tom_Brady) (football quarterback) [24:45]
- [Aaron Rogers](https://en.wikipedia.org/wiki/Aaron_Rodgers) (football quarterback [24:45]
- [Vishen Lakhiani](https://www.vishen.com/) (author) [41:30, 46:45]
- [Wim Hof](https://en.wikipedia.org/wiki/Wim_Hof) (motivational speaker) [48:00]
- [Oprah Winfrey](https://en.wikipedia.org/wiki/Oprah_Winfrey) (talk show host and author) [40:45, 1:00:30]
- [Ann McKee](https://www.bu.edu/cte/about/leadership/ann-mckee-md/) (Professor and director of neuropathology core at Boston University) [1:09:00, 1:10:30, 1:13:30]
- [Junior Seau](https://en.wikipedia.org/wiki/Junior_Seau) (football linebacker) [1:11:00]
- [Aaron Hernandez](https://en.wikipedia.org/wiki/Aaron_Hernandez) (football tight end, suffered CTE, murder) [1:11:00]
- [Joe Dispenza](https://drjoedispenza.com/) (meditation expert) [1:41:00]
- [Ric Elias](https://www.instagram.com/_ricelias/?hl=en) (survivor of flight 1549) [1:45:15]

§

![](https://peterattiamd.com/wp-content/uploads/2022/05/bio-image-kelseychittick-500x500.png)

##### Kelsey Chittick

Kelsey Chittick is a writer, comedian and inspirational speaker. Over the past 14 years, she has performed stand-up comedy all over Los Angeles and speaks at events around the country. She is the co-creator of KeepON, an inspiring and humorous podcast that explores how our greatest obstacles turn out to be our greatest gifts.

Growing up in Florida, Kelsey was an accomplished student and athlete—an NCAA Championship individual qualifier and captain of the UNC women’s swimming team. She was married to Super Bowl champion Nate Hobgood-Chittick. [[Second Half](https://secondhalfbook.com/about-the-book)]

Instagram: [@kelseydchittick](https://www.instagram.com/kelseydchittick/?hl=en)