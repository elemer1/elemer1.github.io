# #96 – David Epstein: How a range of experience leads to better performance in a highly specialized world

**Source:** [https://peterattiamd.com/davidepstein/](https://peterattiamd.com/davidepstein/)

---

In this episode, David Epstein, best-selling author of [Range](https://www.amazon.com/Range-Generalists-Triumph-Specialized-World/dp/0735214484) and [The Sports Gene](https://www.amazon.com/Sports-Gene-Extraordinary-Athletic-Performance/dp/161723012X), discusses the evidence around the most effective ways to improve long-term performance and learning in our specialties, our sports, our careers, and our lives. David makes a compelling case that a range of experiences and skills are more likely to lead to expert performance compared to early specialization, and offers an in-depth critique of the much-publicized 10,000-Hour Rule. David also provides insights into our role as parents in the process of encouraging exposure to many things, the concepts of when to push them, when to give them space, and when to allow them to quit. Furthermore, David goes into many other fascinating topics such as the role of talent, genetics, and practice in reaching expert status, what differentiates a kind vs. wicked learning environment, the importance of “informal training”, and many case studies that suggest strategies for short-term success may not be best for long-term development.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/davidepstein/the_Drive_public.png)

Play

#96 - David Epstein: How a range of experience leads to better performance in a highly specialized world

#96 - David Epstein: How a range of experience leads to better performance in a highly specialized world

1x15s30s

0:002:37:10

## We discuss:

- A shared interest in Ayrton Senna, and pondering the value in participating in sports [2:30];
- Examining the 10,000-Hour Rule, and the importance of questioning existing dogma [15:00];
- How the medical profession is affected by bad science, and the importance of understanding individual variation [28:00];
- David’s most surprising findings when writing The Sports Gene [35:45];
- Kind versus wicked learning environments [40:45];
- How and why strategies for short-term success may not be best for long-term development [47:30];
- Contrasting the success stories of Tiger Woods and Roger Federer—which path is more common, and an argument for diversified training and experiences [59:15];
- Is there an age-range or “critical window” during which exposure is necessary to reach a certain level of proficiency or mastery of a skill or knowledge? [1:14:00];
- How diversifying your interests and unraveling your identity from your speciality could lead to more enjoyment and actually improve performance in your speciality [1:22:15];
- The undervalued importance of “informal training” [1:29:15];
- Advice for increasing match quality in your work—where interests and abilities align—to optimize both job performance and fulfillment [1:41:15];
- Would David want his own son to attend college given the current state of higher education? [1:51:15];
- The role of a parent—how to encourage sampling, when to push them, when to allow them to quit, and insights from the childhoods of Tiger Woods and Wolfgang Mozart [1:55:45];
- The need for varied perspectives and the ability to improvise—insights gained from the Space Shuttle Challenger tragedy [2:08:45];
- How a diversified background and identity could be the difference in life or death—the Hotshot firefighters case study [2:22:15];
- David’s takeaways from the inspiring story of Frances Hesselbein [2:29:00]; and
- More.

§

## Show Notes

## A shared interest in Ayrton Senna, and pondering the value in participating in sports [2:30]

**Ayrton****Senna**

- Both David and Peter were huge fans of [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna)
- Per David, one of the all-time great sports documentaries is [Senna](https://en.wikipedia.org/wiki/Senna_(film))
- The people of Brazil idolized Senna and his tragic death is something every Brazilian remembers vividly

> “Any time I meet someone from Brazil, we talk about Senna, and it is, without exception, they speak of him with a reverence that I don’t think Americans can relate to. There is no athlete we talk about, there is no politician, there’s no scientist we can speak about in the way a Brazilian talks about Senna.” —Peter Attia

*-More about Senna*

- A little know fact about Ayrton Senna was that he did a lot of charitable things quietly
- He was able to achieve unbelievable success but maintain his humility
- He felt a deep sense of responsibility to the people of Brazil

*-Why Peter loved Senna*

- Always been drawn to people that are incredibly passionate and great at what they do
- Peter says, “I do think that his desire to win probably also killed him”
- Peter notes that Senna’s willingness to push the envelope is something Peter found incredibly appealing which “*maybe speaks to my own demons*”
- Everyone who worked with Senna seemed to love him down to the car engineers whom Senna would spend hours and hours with trying to understand things and gain an advantage

⇒ Special Senna Moment: His [qualifying session](https://www.mclaren.com/racing/2018/legendary-laps/senna-1988-quali-lap-2119884/) in 1988 at Monaco… “*there is no explanation for what he did that day*”

\**Unfortunately, there was no onboard camera for that qualy in 1988, but here’s a great onboard look of Senna driving in 1990…*

**What is the value of sports? And why do people resonate with it so much? [11:15]**

- Senna was the example of an athlete who took his sport with the utmost seriousness
- And people loved him for it
- But the question is why did people love him for it?
- And why did Senna take a sport so seriously?

–[*The Grasshopper*](https://www.amazon.com/Grasshopper-Games-Life-Utopia/dp/155111772X) *by Bernard Suits (Canadian philosopher)*

- A grasshopper is playing games all summer while the ant is storing up food in the summer
- Come winter, the grasshopper doesn’t have any food and the ant does
- The grasshopper goes to the ant and asks for some food and the ant says, “No, you were playing while you should have been collecting food.”
- Reading this may lead one to believe there is no necessary or sufficient core value in sport
- But next in the book, the grasshopper is approached by his disciples who come saying, “You should be storing food. You’re going to die.”
- The grasshopper says, “No, this is who I am. I understand what’s coming, but this is the best thing I can be doing,”
- In other words, he’s engaging in this endeavor for the love of doing what he was doing
- Bernard Suits is basically saying that there IS a core value to all sports and game: **The core to all sports and games is the voluntary acceptance of unnecessary obstacles (**[lusory attitude](https://en.wikipedia.org/wiki/Lusory_attitude)**)**
- Bernard Suits defines the playing of a game as “*the voluntary attempt to overcome unnecessary obstacles*.”

*⇒* [*Aristotle*](https://en.wikipedia.org/wiki/Aristotle) *put actions into two categories*:

  1—One was **kinesis**: You’re doing it for the end (e.g., building a house)

  2—Two was **energeia**: You’re doing it for the doing, not for the end

- And he said these two things have to be separate
- Suits, on the other hand, is saying that sports combines these two categories
- There is an end that you’re going for, but the love of difficulty in the middle is what’s really important
- I’m sure Senna had that love of difficulty, says David
- In sports, you are “*intentionally doing something inefficient…in order to facilitate a certain experience*”

**The most efficient path may not be the best for long-term development:**

> “*Sometimes the things you can do to cause* ***the most rapid appearance of short-term progress can undermine long-term development****, and that actually you don’t always want to be as efficient as possible. . .I think that’s very much embodied in this love of difficulty in sports and games, where you are intentionally engineering in inefficiency in order to facilitate an experience that you hope has some value in some learning.*”

## Examining the 10,000-Hour Rule, and the importance of questioning existing dogma [15:00]

**David’s 2014 book**: [The Sports Gene](https://www.amazon.com/Sports-Gene-Extraordinary-Athletic-Performance/dp/161723012X)

**David’s** [**SI article**](https://vault.si.com/vault/2010/05/17/sports-genes) in 2010 which he is self-critical of, including citing it as wrong in his book, The Sports Gene

**The importance of “fact checking”**

- Prior to writing The Sports Gene, David read 10 journal articles a day for 1 year
- During this process, David realized that some of the things that the scientist told him about the findings of their studies were not actually backed up by the data (in their study)
- Peter is writing his book right now and has realized the importance of this as well
- In fact, it’s more than just fact checking, it’s also about interpretation of those facts

**Telephone game of citations**

- Many popular studies that have been cited hundreds of times, and the more it’s cited, the more people believe what is being said about it, and it gets to the point where the **people referencing it don’t even know what the paper says, let alone what it’s citing**
- When you really look into the papers and citations, oftentimes things are missed or extrapolated from bad science, yet it’s taken as fact

> “I have noticed that that sort of thing provides opportunities for people like me, where I’ll go and read the original research of things that have just been at the core of other bestselling books. If you’re willing to do it, it’s sort of a competitive advantage. It gives an opportunity.”

**Interpretation**

- Peter points out that getting a fact wrong is not nearly as big of a deal as mis-interpreting a fact
- A fact can be corrected
- But in the context of Peter’s book, he’s paranoid that he might mis-interpret something which can be much more difficult to “unwind”
- For this reason, Peter has hired an independent “fact plus interpretation” checker for his upcoming book

**The 10,000 hour rule**

- This is a term coined by [Malcom Gladwell](https://en.wikipedia.org/wiki/Malcolm_Gladwell) in his book, [Outliers](https://en.wikipedia.org/wiki/Outliers_(book)),
- And it was based on science done by [Anders Ericsson](https://en.wikipedia.org/wiki/K._Anders_Ericsson) (who has since [disputed](https://www.ncbi.nlm.nih.gov/pubmed/23111333) Gladwell’s interpretation)
- Paper by Ericsson that was the source of Gladwell’s ideas: [The role of deliberate practice in the acquisition of expert performance](https://projects.ict.usc.edu/itw/gel/EricssonDeliberatePracticePR93.pdf)
- Gladwell also cited [This Is Your Brain on Music](https://en.wikipedia.org/wiki/This_Is_Your_Brain_on_Music)
- In his book, [Talent Code](https://www.amazon.com/Talent-Code-Greatness-Born-Grown/dp/055380684X), [Daniel Coyle](https://danielcoyle.com/author/) also popularized the idea that a certain amount of hours (e.g., 10,000) of deliberate practice would lead to mastery and “*that is all that matters*”

**Questioning the study from which the 10,000-Hour Rule was born**

- When researching for The Sports Gene, David did not initially question the findings of the 10,000 hour rule
- But David decided to go back and read the [original paper](https://projects.ict.usc.edu/itw/gel/EricssonDeliberatePracticePR93.pdf) on this so-called 10,000 hour rule
- The study was with 30 violinists split into three groups
- The top 10 violinists (deemed to potentially be international soloists) were said to have done deliberate practice for an average of 10,000 total hours by the time they were 20
  - The first thing David noticed was that there were **no measures of variance reported in the study**
  - In other words, it didn’t report individual variation—it used the average hours and didn’t report the range of practice hours or the standard deviations of practice hours
  - Furthermore, another big issue was…
    - The hours were tracked by retrospective questionnaires
    - And they got a week’s worth of practice hours then extrapolated it

*–*[*Replica study*](https://royalsocietypublishing.org/doi/10.1098/rsos.190327) *of the 10,000 hours rule*

- Researchers tried to recreate the original study and could not do it
- There was someone at ~4,000 hours who got to the highest group, and someone ~11,000 hours who was still in the lowest group

–*When Ericsson finally did publish the measures of variance…*

- There was enormous variance in the original experiment
- Ericsson then made clear that their conclusions were wrong, that **there was not complete correspondence between the number of practice hours and the group that someone was in**
- Peter adds, “*you can’t even make an observation of statistical significance without variance so I don’t really understand what the paper is saying*”

⇒ Here is a video of David’s [Debate with Malcom Gladwell](https://www.youtube.com/watch?v=iXBhINPoKEk)

⇒ Here’s a [Business insider article](https://www.businessinsider.com/sports-gene-author-gladwell-10000-hour-rule-2013-8) about David’s criticism of the 10,000 hour rule

**So does baseline talent and genetics even matter?**

- Prior to his research for The Sports Gene, David was beginning to believe that talent and genes made less and less of a difference and that deliberate practice was mostly what mattered
- But then he started asking the simple questions
  - For example, David ran track in college and within a couple years he could beat the women’s world record
  - So shouldn’t genetics matter at least in that case?
- David contacted some defenders of the “deliberate practice only” papers
  - And he specifically asked her, “Wouldn’t you agree that a man and a woman who practice the same, the man has advantages, which is why we separate sexes in sports?”
  - She hedged and said, “Maybe not, if they all trained the same.”
  - To back up her theory she sent David citations and one of was a paper about racing dogs showing that practice about the equivalent to their lifespan of 10,000 hours produced that best ones in the class
  - But in the citations of that paper, one of them notes that **half of these dogs** have what is otherwise an incredibly rare myostatin mutation
    - If you knock out the myostatin gene, you look like a bodybuilder
    - Myostatin is a gene that inhibits muscle growth, and there are lots of myostatin mutants out there that all have hypofunctioning myostatin, and therefore are super muscular.
    - So racing breeders were trying to breed for this genetic trait
    - They were shooting for a single mutation, because of double mutation produced a “[bully whippet](https://www.genimal.com/wp-content/uploads/2019/02/Bully.jpg)” which was basically too muscular to move

**David’s point is this…**

“*These people aren’t reading the primary stuff that they’re citing, or they’re not tracking the references back. So, I started to have doubts.*”

## How the medical profession is affected by bad science, and the importance of understanding individual variation [28:00]

The [scientific method](https://en.wikipedia.org/wiki/Scientific_method) is the investigative method developed by [Sir Francis Bacon](https://en.wikipedia.org/wiki/Francis_Bacon)

- While many think the medical establishment is very rigorous, some of the most important public health measures are based on observational, heavily selected, range-restricted studies

  ⇒ See David’s article for ProPublica: [When Evidence Says No and Doctors Say Yes](https://www.propublica.org/article/when-evidence-says-no-but-doctors-say-yes)

- There’s a lot of poor science and there are a lot of things that continue to be done even once evidence shows they don’t work anymore
- This is typically when an idea clearly makes sense, it definitely should work, it’s just that when somebody does a randomized controlled trial, it doesn’t
  - What [Mike Joyner](https://www.mayo.edu/research/faculty/joyner-michael-j-m-d/bio-00078027) called “[bio-plausible](https://en.wikipedia.org/wiki/Biological_plausibility)”

–*Example 1*: Partial arthroscopic meniscus repair

- A [Finnish study](https://www.nejm.org/doi/full/10.1056/NEJMoa1305189) gave some people sham surgery (basically made an small incision) the sent them to physical therapy, and they did as well as the people who were getting the actual surgery
- But it turns out that some huge number of people have incidental tears that don’t have anything to do with their knee pain
- Yet this surgery is still done all the time today

–*Example 2*: [Ezetimibe](https://en.wikipedia.org/wiki/Ezetimibe) (Zetia), a drug that blocks cholesterol reabsorption by blocking the [Niemann-Pick C1-Like 1](https://en.wikipedia.org/wiki/NPC1L1) transporter

- When Zetia is given in monotherapy, it lowers cholesterol, but not that much and it doesn’t save lives.
- Therefore, it is not considered a first line agent, and it’s never considered something that should be used in isolation
- However, when you give it *with a statin*, it lowers cholesterol and reduces events (the things that you actually care about) more than just the statin alone
- **Peter’s take**: “*I actually think this drug alone would work if you actually only gave it to people who were hyper-absorbers, but that’s never been done because we can measure how much absorption capacity a person has, but that’s an advanced measurement. You wouldn’t normally do that in a clinical setting. But if you select for patients who have mega amounts of absorption, it’s certainly possible that those patients [would see a benefit].*”

**Per Peter—This a big problem with how studies are done in medicine**:

- Many studies end up diluting their findings because they use too heterogeneous of a population to test an intervention on
- Therefore, you’re not really powered to detect an effect because in your power calculation you’re using the entire population as your denominator
- In reality, it probably needs to be a subset of the population

**Summarizing the importance of understanding individual variation:**

-Example, *Cholesterol numbers person to person*

- Peter says there is staggering variance among individuals in their cholesterol
- With cholesterol, there are three variables:
  - How much do you make
  - How much do you absorb, and
  - How much do you clear out of circulation with the LDL receptor?
- The variation person to person is “overwhelming”
- Yet, the medical profession looks at just one metric, which is **how much LDL cholesterol is there**, and that’s going to be the basis for treatment

> “We often deem things important because they’re easily measured, not because they’re important.”

-Example, *the monotonic benefits assumption*

- This hypothesis says if you have two people who’ve never done something before, for every equal unit of practice, they should progress exactly the same amount
- And this assumption was underlying the 10,000 hour rule
- But after diving into the research, David could find no evidence supporting this
- The [Heritage Family Study](https://www.ncbi.nlm.nih.gov/pubmed/8978882) took two generations of 90 families who were totally sedentary, put them on six months of identical cycling training, and the range of variation was like 1000% doing identical training
- So it turns out that a simple task with the right practice shows that people progress almost exactly the same
- However, as the task gets more complex, people start diverging with more practice
- The monotonic benefits assumption has “*never shown up in a study of anything unless it’s an extremely simple task that everyone masters very, very quickly.*”
- So to reiterate, looking at the average (like the violinist study) is just obscuring individual variation

## David’s most surprising findings when writing The Sports Gene [35:45]

**David’s book**: [The Sports Gene](https://www.amazon.com/Sports-Gene-Extraordinary-Athletic-Performance/dp/161723012X)

- Judging by the title of The Sports Gene, one might assume that the book was about how the best athletes are genetically gifted which explains why they are so good
- But that’s not necessarily the case

*What was David surprised to see people fixated on from the book?*

- “*I didn’t think the thing that people were going to find the most controversial was the 10,000 hour rule*”
- It turns out people and organizations were literally building their strategy around getting exactly 10,000 hours of practice

*What was the most important thing in the book to David?*

- A close friend and training partner of David’s dropped dead while running a race
- He was a top ranked competitor
- David got a hold of his medical records and it turned out to be a textbook case of [hypertrophic cardiomyopathy](https://en.wikipedia.org/wiki/Hypertrophic_cardiomyopathy)
- It was misdiagnosed case (it’s not easy to diagnose)

*What were the most surprising findings for David when writing the book?*

- Most surprising were **things that he assumed were genetic, but turned out not to be**
- *One example* is the reflexes it takes to hit a hundred mile per hour fastball
  - Turns out that [major league baseball players don’t have faster reflexes](https://www.espn.com/blog/sweetspot/post/_/id/38831/the-curious-case-of-lars-anderson)
- The same is true for Formula 1 driver, says Peter
  - Turns out a big difference between a novice and a elite driver is how far ahead the elite driver is able to see what’s happening
  - This ability to keep your eyes down the road gives you time to make turns and decisions at the right moment which give off the *appearance* of faster reflexes

## Kind versus wicked learning environments [40:45]

*When learning a new skill, there are 2 things to affect your progress*:

1. The way you’re training
2. The environment that you’re training in
   1. And you can be in a Kind or a Wicked learning environment
   2. This idea was coined by psychologist, [Robin Hogarth](https://www.econ.upf.edu/~hogarth/Robin_M._Hogarth/Home.html)

**Kind learning environment**

–*A kind learning environment is one where*:

- All your information is clear
- The next steps and goals are totally clear
- Work tomorrow will look like work yesterday
- Patterns recur
- Whenever you do something you get feedback that is **immediate** and fully **accurate**
- Examples of kind learning: Golf and archery

**Wicked learning environment**

–*Wicked learning environment is one where*:

- you might not know exactly what you’re supposed to do next
- You might not even know the goal
- Human behavior might be involved
- There may be time pressure
- Work next year might not look like work last year
- And importantly, you don’t always get automatic feedback
- and sometimes when you get feedback it’s delayed and/or inaccurate
- E*xample of an extremely wicked feedback provided by Robin Hogarth*:
  - A New York doctor got wealthy and famous because he could miraculously predict who would get typhoid before they showed any symptoms by feeling around patients’ tongues with his hands
  - Turns out he was giving people typhoid by touching their tongues
  - The feedback he was getting was reinforcing the wrong lesson

–*Two components of a wicked environment makes it super challenging*

1. The number of scenarios you can face, and the unpredictability of them.
2. The second piece is this delay between feedback and reality

   —*Which one of these is harder to overcome?*

- Delayed feedback is usually a killer, says David
- The changing scenarios is easier to accommodate with “breadth of training”
  - A classic psychology finding can be summarized as “breadth of training predicts breadth of transfer”
  - Transfer being a term psychologists used to mean your ability to take skills and knowledge, and apply them to a situation you haven’t quite seen before.

**Delayed feedback**

⇒ [The Mythical Man-Month](https://en.wikipedia.org/wiki/The_Mythical_Man-Month), an essay by [Fred Brooks](https://en.wikipedia.org/wiki/Fred_Brooks)

- He had noticed that project managers, when their projects got behind in software…they would start adding more people to help, but that would cause the project to become *more* late (especially if they were complicated projects)
- [Brooks’s Law](https://en.wikipedia.org/wiki/Brooks%27s_law) says if you add people to an already late software project, it will become more late in proportion to how many people you add
- *Why?* ⇒  because there was a delay caused by new people who first needed to be assimilated into the team
- The managers never learned that lesson because of the delay of feedback so they keep doing the same thing over, and over, and over

⇒ A follow-up study called the [Experience Trap](https://www.ncbi.nlm.nih.gov/pubmed/18314637)

- You had project managers that would learn the ropes coming up the ladder with simpler projects where adding people DOES help it get done faster because they can right away figure out what to do.
- Then they get promoted, and promoted, and end up with more complicated projects
- And in those cases, they do the same thing (bring more people in), and they never learn about the assimilation delay that it takes.

## How and why strategies for short-term success may not be best for long-term development [47:30]

\*A big theme in David’s book, [Range](https://www.amazon.com/Range-Generalists-Triumph-Specialized-World/dp/0735214484), is the idea that the things that you can do that sometimes SEEM the best in the moment for short-term gains, *may not the best for long-term development*

**The** [**Air Force Academy study**](https://faculty.econ.ucdavis.edu/faculty/scarrell/profqual2.pdf)**:**

- The study followed a hundred professors and 10,000 students over a decade
- The students have to take a sequence of three math courses over 3 years
- The main finding was that there’s an inverse relationship between how well students with a certain professor did in the first course, and how well they did in the second and third, and how they rated their teachers.
- For example, the 6th best rated professor was in calculus one and his students got the 7th best scores overall
- However, in the next two math courses, those students were **dead last** in performance expectations (i.e., are they over- or under-performing?) — meaning they *progressed the least* compared to other students who came in with the exact same characteristics

*-Other findings*:

- The way to get students to do the **best in calculus one** was to teach a very narrow curriculum that was tailored to the test where they learn a lot of what’s called “***using procedures knowledge*****”**
- This is where they just learn how to execute algorithms, and things like that over and over
- The professors who got **rated worst by their students**, and their students did worse on the calculus one test… they learned calculus more via “***making connections knowledge***”
- This is where you have to draw together concepts, and you’re facing different types of problems instead of repeating the same type over and over
- Students taught with “making connections knowledge” have a more conceptual, flexible knowledge that translates better to more complicated problems (like those face in calculus 2 and 3) because they **learning how to match a strategy to a type of problem instead of just how to execute procedures**

–*One more finding*:

- It didn’t subjective “feel” as good to learn in the “making connections knowledge” format
- “*There’s this real conflict between how they feel they’re doing early, and how they rate their professors, and how they’re really being set up for later success, which is kind of wild.*”

**Desirable difficulties**

> “Active learning students actually learn more, but they rate themselves as having learned less, and they also rate their teachers worse. It turns out early on were not actually that good evaluators of how we’re doing because the feeling of fluency, and learning makes us think we’re doing well, but we’re actually not. This is what I wrote about called desirable difficulties.”

⇒ *A startling example with college math students that shows the problem of not learning by* ***deriving the answer*** *but instead by memorization*

- College students in a math course couldn’t prove how a math problem was correct outside of the way they solved it
- A simplified example being “500 plus 200 equals 700”
- Then when asked to prove it they’d say “Okay, 700 minus 200 equals 500.”
- But then they wouldn’t realize that they could also say “700 minus 500 equals 200” because they were taught to subtract the number on the right of the addition sign
- The professors would be shocked at this
- Students when interviewed would say “math is a system of rules and executed procedures”
- By contrast, the professors would says that went into math precisely because “I didn’t have to memorize stuff because you could derive it, and it makes sense, and it’s just concepts”
- Unfortunately, says David, this is how math is mostly taught these days

**More examples of the value in desirable difficulties:** Studies comparing “blocked practice” vs. “interleaved practice” (also called varied or mixed practice)

⇒ [This study](https://www.ncbi.nlm.nih.gov/pubmed/24578089) looked at 7th grade math classrooms were randomly assigned to different types of math teaching

- Some got what’s called “blocked practice”
  - This is where you get problem type AAAA, BBBBB, and so on
  - The students get better really quickly, and they rate their teachers well, and they rate their own learning well.
- Others got “interleaved practice”
  - It’s as if you threw all the problem types in a hat, and you pick out randomly
  - In that condition, students are frustrated at first, they rate their own learning low, they rate their teachers poorly
  - However, they’re learning how to **match a strategy to a type of problem** instead of just doing the same thing over and over
- **Results**: The interleaved practice students “blew the block practice students away”
  - “Largest effect size I’ve ever seen in an education study that was randomized”
  - 0.83 standard deviations
  - It was like taking a kid from the 50th percentile and moving them to the 80th percentile
- The Drawback?
  - Kids didn’t like it early on
  - They don’t feel like they’re learning

⇒ *Here’s a more recent study looking at interleaved learning*: [Interleaved Learning in Elementary School Mathematics: Effects on the Flexible and Adaptive Use of Subtraction Strategies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6385790/)

*As a teacher or parent, how do you balance* ***maintaining enthusiasm*** *with* ***optimal development?***

- On the one hand you don’t want to turn students off from a subject
- But you also want to do what’s right for them in the long term
- David says it’s challenging and this is what sets apart the better teachers…
- They figure out how to balance when to make things difficult, and when to allow things to be easy

## Contrasting the success stories of Tiger Woods and Roger Federer—which path is more common, and an argument for diversified training and experiences [59:15]

*After writing Range, what is David’s take on the importance of genetics vs. volume of practice leading to expert status?*

- Prior to the book, David’s thoughts were that genetics had little to do with it and that deliberate practice was what matter the most
- But after the book, David’s revised take is that both matter not only in terms of peak performance but also is how quickly one can become an expert

***Tiger Woods vs. Roger Federer ⇒ 2 very different paths to the top***

–[*Tiger Woods*](https://en.wikipedia.org/wiki/Tiger_Woods)*’ path to the top:*

- Tiger’s story is quite well-known
- From the time he was a toddler he was all about golf
- At 2 years old, he’s on TV [demonstrating a golf swing](https://www.youtube.com/watch?v=MxPmzIKBris)
- By 4 years old he’s saying, “I’m going to be the next Jack Nicklaus.”
- Fast forward to age 21, and he’s the greatest golfer in the world

*–*[*Roger Federer*](https://en.wikipedia.org/wiki/Roger_Federer)*’s path to the top:*

- Roger, on the other hand, had the opposite path
- And he’s become just as dominant in tennis, if not more than Tiger in golf
- Yet, we rarely hear his story which is…
- He played many different sports growing up (basketball, badminton, skateboarding, swimming, wrestling, soccer, handball, volleyball)
- He reluctantly dropped other sports, the last one being soccer
- He didn’t really focus on tennis until his teenage years

\*David used these contrasting stories in his book, [Range](https://www.amazon.com/Range-Generalists-Triumph-Specialized-World/dp/0735214484), to set the stage for the question of: *Which of these 2 stories is more common in the world?*

> “I sort of felt we should let people know what the norm is instead of always focusing on these very few exceptions that happened to be in the most kind learning environment, sports, and that aren’t that good to extrapolate to everything else.”

*-How much Roger’s success is attributed to the* ***psychology of not getting burned out*** *(and therefore able to continue to put in the work) versus. the* ***neuromuscular physiology*** *of developing synaptic connections that served him better in tennis?*

- David’s original thought was that most of the effect was going to be accounted for by the fact that if you allow people to **delay selection**
  - I.e., it’s more likely you get them in the sport that they’re the best at (versus pegging them into the wrong sport too early)
- However, David’s feeling today that it’s more about the **breadth of training that predicts breadth of transfer**
  - I.e., You’re exposed to much more neuromuscular and perceptual stuff that when the challenge gets harder as you go up, you need to draw on those other experiences

> “It turns out that the norm when scientists track athletes on route to becoming elite is that early on they tend to have what they call a ‘sampling period’ where they try a wide variety of activities. That often includes things like martial arts, and dance, and doesn’t just have to be other sports, gymnastics. And they learn these broad general, these physical skills, and they learn about their interests and their abilities, importantly, and delay specializing until later than peers who plateau at lower levels.”

⇒ *A few examples that support that conclusion*:

- [Studies of German soccer players](https://www.ncbi.nlm.nih.gov/pubmed/25440296) showed the ones who stood out most in their teens were those who did a wider variety of activities
- A physiologist for Cirque du Soleil named [Dean Kriellaars told David](https://www.trainheroic.com/blog/why-range-beats-specialization-for-young-athletes/) that he started implementing a program where performers started to practice and learn the basics of three other performer’s disciplines and said it **reduced injuries by 33%**
- Another [longitudinal study of young athletes](https://www.ncbi.nlm.nih.gov/pubmed/24463910/) found that the best predictor of an “adult-style overuse injury” was how specialized the athlete was ⇒ So there was some protective effect from diversifying

**The importance of diversified training goes UP the higher you get in a particular sport**

- Book called [Extraordinary Tennis for the Ordinary Player](https://www.amazon.com/Extraordinary-Tennis-Ordinary-Player-Simon/dp/0517511991) points about that in amateur tennis, 80 or 90% of the points are scored by just keeping the ball in play and someone making an error.
- But at the elite level, it’s exactly the opposite… 80-90% of points have to be **earned**
- So athletes will do better to have that breadth of training as they go up in levels

–*The specialization model can still work…*

- But mostly in the most kind learning environments
- Golf, for example, can work by being very specialized however you run the risk of burnout

> “The theme of the book is that things that’ll cause you to be the best today might not be the best for 5 or 10 years from now. Or the best way to develop a 10 year old might not be the best way to develop a 20 year old.”

**What about the sports where physiology is undeniably huge?**

- Swimming, cycling, and running are examples
- David says yes there are certain sports where to reach elite levels you need a certain genetic makeup
- And since training knowledge is much more widely available, the people who make it there are the ones with the combination of the genetics and the willingness to put in the right kind of work

## Is there an age-range or “critical window” during which exposure is necessary to reach a certain level of proficiency or mastery of a skill or knowledge? [1:14:00]

***Is there a critical learning window?***

⇒ In his book, [Why Michael Couldn’t Hit](https://www.amazon.com/Why-Michael-Couldnt-Hit-Neurology/dp/0716730014), neurologist Harold L. Klawans argues that there is indeed a critical learning window

- He argued that [Michael Jordan](https://en.wikipedia.org/wiki/Michael_Jordan) missed the critical window for developing the perceptual anticipation skill that you need to hit a baseball
- That said, there are exceptions, such as one of the most dynamic players in baseball, Lorenzo Cain, who did not play a game of baseball until age 16.

*Is there something neurologically important about that “window” or is it just that if you start too late you run out of time?*

- That is part of it
- And not only time, but you want your perceptual expertise to coincide with your peak physical maturity

Amaeteur golfer, [Dan McLaughlin](https://en.wikipedia.org/wiki/Dan_McLaughlin)

- He tried using the 10,000 hour rule to try to become a pro golfer by doing 10,000 hours exactly despite never playing golf before
- He even got Erickson to consult with him
- He never made the pros and he had to stop after about ~7,000 hours
- He got better than 90% of amateurs
- David pointed out that there’s huge individual variation so if Dan was going to make it to the pros, there was no chance it would take exactly 10,000 hours

**How many hours to master a sport?**

- Depends on the sport or skill in question
- David estimates many sports to be in the 4,000-6,000 hours
- Chess is much higher than 10,000
  - It takes [11,053 hours on average](https://www.researchgate.net/publication/226396370_Deliberate_Practice_Necessary_But_Not_Sufficient) to reach international master status but there’s huge variation from person to person
- There’s obscure sports like Skeleton ⇒ Paper called [Ice Novice to Winter Olympian in 14 months](https://www.ncbi.nlm.nih.gov/pubmed/19191166)

–*“Invasion” sports*:

- Some [studies](https://www.tandfonline.com/doi/abs/10.1080/17408980903273121) show that people who’ve done a variety of “invasion” sports will then pick up any subsequent invasion sport more rapidly
- Like one case where a woman who had played a variety of invasion sports and then it only took her 500 hours to become one of the best basketball players in the world

**What can we learn about critical periods from language learning?**

- Much of the research into language learning is contradictory and confusing, says David
- But one thing he did find pretty strong evidence for was that [people who grew up bilingual had an advantage for then learning a third language](https://www.ncbi.nlm.nih.gov/pubmed/19648456/) without being taught it formally
- Also, there is a [real sensitive period in language](https://www.scholastic.com/parents/family-life/social-emotional-learning/development-milestones/language-development-11-13-year-olds.html) where, about after age 12, you’re not going to make something your *native* language anymore
- David thinks this can be similar in certain sports and skills…
- Like in chess … If you don’t start studying chess patterns by age 12 your chances of reaching international master status drop from [1 in 4 to 1 in 55](https://www.researchgate.net/publication/226396370_Deliberate_Practice_Necessary_But_Not_Sufficient)

> “I think there are some critical periods, but for most things. . .I don’t think it’s nearly the expiration date that people think it is. I think most people can get better at most things than they think they can, and they can get better at most things than they think they can at older ages than they think they can too.”

## How diversifying your interests and unraveling your identity from your speciality could lead to more enjoyment and actually improve performance in your speciality [1:22:15]

- Peter points out that nearly all of us will never be good enough at a sport to make a living out of it
- In fact, Peter finds the process of making progress on the path to mastery more joyous
- And being the “absolute best” may not be where the joy comes from afterall:

“Maybe it’s not that much fun to be the best in the world at something because by definition you only have one way to go at some point and that’s probably a lot less enjoyable than working your way up the curve.”

⇒ *Examples*:

- [Ayrton Senna said](https://youtu.be/qYYIzDMJbpY) his favorite time in racing was in karting when there were “no politics” and it was “just racing”
- [Sasha Cohen said](https://peterattiamd.com/sashacohen/) in her appearance on The Drive that her favorite years competing were before she was the favorite to win gold
- David has also been noticing his enthusiasm for writing starting to slip but has found he can reinvigorate himself by practicing a new approach and continuing to learn
  - He’s also been reading the book, [Zen Mind, Beginner’s Mind](https://www.amazon.com/Zen-Mind-Beginners-Meditation-Shambhala/dp/1590302672/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=), where you just always keep your mindset as a beginner and never as “I’ve arrived”

**Unraveling your identity from the thing you “do”**

- Many athletes have a hard time in retirement because they’ve lost their identity
- David believes performers need to have something else they do ⇒ this [study](https://www.researchgate.net/profile/Kendell_Pawelec/publication/247857346_Arts_Foster_Scientific_Success_Avocations_of_Nobel_National_Academy_Royal_Society_and_Sigma_Xi_Members/links/00b4953c00f875f191000000.pdf) found that Nobel Laureates are 22 times more likely than a typical scientist to have a serious aesthetic hobby

⇒ David tells the story of [Petra Majdič](https://en.wikipedia.org/wiki/Petra_Majdi%C4%8D), Sylvanian skier at the Vancouver Winter Olympics in 2010:

- “one of the greatest things I’ve ever seen in sports live”
- She had been a top ranked skier her whole career but was “totally snake bitten” and had never medaled in the world championship or the Olympics
- In warm ups, she fell and hurt herself pretty badly but they thought it was just a bruise
- But in the competition she is basically screaming in pain with every turn but she pushes through
- She barely wins the bronze medal
- Then after closer inspection the doctors realize that she had broken ribs and a collapsed lung
- They said she needed to go to the hospital and skip the medal ceremony but she told them she’d rather than miss the medal ceremony

-David asked her sports psychologist about what got her here despite all the setbacks

- He said the *most important thing* was **diversifying her interests**
- She was getting so fixated on the sport
- And she was cracking under the enormous pressure
- So he basically forced her to start building a house and that became a task for her to do and a whole new thing and a new skill.

“…*building the house took the pressure off. It gave her some other part of her identity, so it wasn’t just as the person who’s always having something go wrong. And I just thought that was so interesting that what he felt was his main contribution was giving her a hobby, essentially, and that he thought that really allowed her not to feel the pressure that would break her in some way.*”

## The undervalued importance of “informal training” [1:29:15]

**Perverse incentives in science**

- Most science being done today is useless (90-95% says Peter)
- They increase the publication count of the person doing them, which is why they’re doing them.
- It’s an economic tool of the journals and it’s a promotional tool for scientists
- There may not be any absolutely nefarious actors in the situation, you just have a system with perverse incentives

⇒ 2005 paper by John Ioannidis: [Why Most Published Research Findings Are False](https://journals.plos.org/plosmedicine/article/file?type=printable&id=10.1371/journal.pmed.0020124)

**Humans don’t think scientifically**

- Genetics and evolution have never prepared us for science
- The scientific method is less than 400 years old
- In other words, the earliest signs of formal logic as a construct to describe the way we think represents less than 0.1% of our genetic existence.

⇒ Peter’s blog post: [Why we’re not wired to think scientifically (and what can be done about it)](https://peterattiamd.com/wired-think-scientifically-can-done/)

**Balancing the ridged (formal) training with informal training (aka being a generalists within science)**

**–**Formal training vs. being an “outsider”… *which is the advantage?*

- “we underestimate the importance of informal training” says David
- Especially in science and medicine where individuals are getting more and more specialized
- To clarify, it’s not that a historian (or someone picked at random to do science) is going to solve a complicated chemistry problem, it’s more so that someone from a tangential discipline might bring a new perspective
- That said… “*the tech community in particular would do well to interact with historians. Like I think there are a lot of things they could learn. Sometimes I feel like the Silicon Valley set maybe doesn’t respect history quite enough.*”

**An outsider can be the answer**

- In Range, David wrote about the story of a company called [InnoCentive](https://www.innocentive.com/)
- InnoCentive was born out of an experience that a man named [Alph Bingham](https://www.innocentive.com/alpheus-bingham-ph-d/) had while working at pharmaceutical giant [Eli Lilly](https://en.wikipedia.org/wiki/Eli_Lilly_and_Company)
- He realized at a certain point that chemists at Eli Lilly were getting *so specialized* that there were certain things they were great at, but it also narrowed their view
- Despite much pushback, Alph ended up taking a number of the problems in drug development that were stumping the specialist and posted them online
- To their surprise, **about ⅓ of the problems were solved** by “outsiders”
- **David’s favorite story**…An attorney was able to solve some important chemical synthesis project because he had worked on some tear gas copyright case or something and it reminded him of that
- InnoCentive now helps other companies post their problems needing solving online and they will give a cash reward to “solvers”

*To summarize*:

-1) **It’s not that specialist aren’t important**

- David says, “*I wouldn’t extrapolate InnoCentive to mean that specialists aren’t incredibly important*”
- Rather, his broad view of this is the same as physicist, [Freeman Dyson](https://en.wikipedia.org/wiki/Freeman_Dyson) that said (paraphrased):
  - “*We need birds and frogs. The frogs down in the mud looking at the granular details. The birds are up above. They don’t see the detail, but they’re integrating the knowledge of the frogs*. . .
  - . . .*The world is wide and deep. It’d be stupid to say one’s better than the other. You need both for a healthy ecosystem.” His concern was we’re telling everybody to be frogs. And so we’re not having birds*.”

-2) We are **too rushed to specialize**

- [Arturo Casadevall](https://en.wikipedia.org/wiki/Arturo_Casadevall) started the [R3 Initiative](https://www.jhsph.edu/departments/w-harry-feinstone-department-of-molecular-microbiology-and-immunology/academics-and-degree-programs/R3-PhD-program/r3-curriculum-overview), which is a graduate program at Johns Hopkins that starts even the most specialized graduate program with interdisciplinary classes that include philosophy, history, logic, ethics, statistics, communication, and leadership
  - For example, he has a course titled “How Do We Know What Is True?” which examines
    - types of evidence through history and across disciplines
    - The anatomy of scientific errors
    - And also how errors have sometimes led to breakthroughs.
  - So he’s just backing up the training into these broader concepts and saying, “*You can learn the more specific didactic stuff later. But if you don’t learn the broader conceptual stuff, you never get it. Because you’re only going to get more and more and more specialized from here*.”

> “One way we can approach this is just by backing up the [formal and specialized] training. Because…people will learn the specialized stuff in their field just by doing it and being ther. . .But the other stuff like scientific thinking. ‘How does it work? What constitutes evidence?’ They’ll never get that stuff if they don’t get it early in training.”

## Advice for increasing match quality in your work—where interests and abilities align—to optimize both job performance and fulfillment [1:41:15]

Peter’s advice to young students considering what they should study in undergrad if they want to go to med school:

- Peter’s answer is always “anything but pre-med”
- “But you are better off being a history major who goes to medical school than a biochem major who goes to medical school in my opinion”
- “You’re going to learn as much biochemistry as you’re going to need to learn when you get there. Both interpersonally and, frankly, in the breadth of thinking, you’ll be better of if you studied something else.”

Peter’s personal path:

- Peter used to fret about his path changing so much (going from engineering to med school to consulting and now back to medicine)
- His worry was that he “missed his shot” to get to 10,000 hours to master something
- But after reading Range, Peter came to realize that he’s discounting a bunch of things he learned during this unique path
- David makes the following insight after listening to Peter’s story, “*Your insight into yourself, your skills and interests in the world are constrained by your roster of previous experiences.*”

> “Your insight into yourself, your skills and interests in the world are constrained by your roster of previous experiences.”

**Match quality in a career**

- **Match quality**=A degree of fit between your interests and abilities and the work that you do
- Match quality is really important for how likely you are to *burn out as well as your performance*
- [Herminia Ibarra](https://twitter.com/HerminiaIbarra?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) studies match quality and how people seek this out and transition careers
- And she said, “We learn who are in practice, not in theory.”
- What she means is that the way we learn about what we want to do is we have to do stuff (rather than just ponder on it until you know)
- Rather, you should **act and then reflect on it**
- Match quality seems to be so important that spending some time in that experimentation is worth it

**Income is better with better match quality…**

⇒ A [natural experiment](https://www.nber.org/papers/w15522.pdf) in the higher ed systems of England and Scotland

- England students had to pick a specialty early on (in their mid-teens)
- Scottish students could keep sampling throughout university
- Results:
  - Early specializes jumped out to an income lead
  - But late specializes had better growth rates and passed them by in year 6 (presumably bc they had better match quality)
  - Early specializers started leaving their career tracks in much higher numbers because they’re made to pick so early that they, more often, make a wrong choice
  - The **return to match quality was higher than the return to getting a headstart** in domain specific skills.

**Fulfillment and match quality…**

- Peter tells his story about how for most of high school he sort of didn’t do well
- Peter was solely focused on boxing and training for boxing
- One day his math teacher pulled him aside and told Peter that he had a gift for mathematics
- This transformed Peter into a better student and he really started to enjoy math

⇒ See Peter’s [blog post](https://peterattiamd.com/thank-you-woody/) about his math teacher who changed his life trajectory

- Peter wonders about what allowed him to excel at math…?
- Was it just the pure grit that he had (like he had with training that he then applied to math)?
- Or was there a component of match quality with math (i.e., he had an interest and a skill for math)
  - David thinks it was more the latter

**Dark Horse Project, finding fulfillment**

- [The Dark Horse Project](https://lsi.gse.harvard.edu/publications/dark-horse-achieving-success-through-pursuit-fulfillment) which was this project by two Harvard researchers to figure out how people who find fulfillment in their work go about it in a wide range of careers
- They found that most of the people **did not stick on their first dream**
- Instead of sticking to an ironclad long term plan, they would respond to their lived experience by zigging and zagging and finding what they were good at

\*More resources about this project:

- *Subsequent book*: Dark Horse: [Achieving Success Through the Pursuit of Fulfillment](https://www.amazon.com/Dark-Horse-Achieving-Success-Fulfillment/dp/0062683632?creativeASIN=0062683632&linkCode=w61&imprToken=C9p77J6Vvs3dtrZ29yOmXw&slotNum=0) by Todd Rose and Ogi Ogas | (amazon.com)
- *A post about it on Medium*: [How Harvard’s Dark Horse Project is Shattering Old Beliefs about Success](https://medium.com/the-book-mechanic/how-harvards-dark-horse-project-is-shattering-old-beliefs-about-success-44d1d0897e72) | August Birch (medium.com)
- *And an article about it from the authors*: [How ‘dark horses’ flip the script of success and happiness](https://bigthink.com/big-think-books/what-is-the-dark-horse-project) | (bigthink.com)

## Would David want his own son to attend college given the current state of higher education? [1:51:15]

**Can David make a case that one does not need formal education to be successful (other than maybe a doctor/lawyer)?**

- David says something really needs to change about the way college is currently set up
- “*…if we keep ramping up people’s debt, then we will make sure that they fall prey to the* [*sunk cost fallacy*](https://en.wikipedia.org/wiki/Sunk_cost).”
- With college… “*the more time and debt we saddle people with, the more we make sure they will not respond to match quality information*”

⇒ [Study by Steve Levitt](https://www.nber.org/papers/w22487) where he had people flip a coin to determine major life decisions

- A very common life decision was “*Should I quit my job?*”
- And for those who flipped a coin that told them Yes to quitting where reporting feeling better off and happier when Steve checked in with them down the road
- David’s point being that you should pay attention to feelings of match quality and not be afraid to make a change

**A case against college education**

- [Bryan Caplan](https://en.wikipedia.org/wiki/Bryan_Caplan) wrote a book called [The Case Against Education](https://www.amazon.com/Case-against-Education-System-Waste/dp/0691174652)
- His argument was the college was mostly just about signaling to the job world that you are smart and committed enough to get a degree as opposed to being about what you learned (his ratio being 80/20)
- This is a case against college and the research seems to suggest that it doesn’t change people as much as we might think

**A case for college**

- David says that college does it give you a sampling ability
- So without college, David would want there to be some other mechanism for sampling
- David thinks there are some good online courses available and hopefully those will continue to advance

**So to answer the question of whether he’d want his own child to go to college 18 years from now…**

- “I would want him to be able to have a sampling period.”
- “I don’t know that the same kind of college model that we have now will be the answer.”
- “And I think there are other things that could expose him to more other things.”

⇒ Jason resonated with something [Angela Duckworth](https://en.wikipedia.org/wiki/Angela_Duckworth) said in her newsletter called “Summer is for Sampling.”

- She said, “Kids shouldn’t be [gritty](https://www.ted.com/talks/angela_lee_duckworth_grit_the_power_of_passion_and_perseverance/up-next?language=en) until they figure out what to be gritty in.” And she says, “It took me a decade of trying stuff to figure it out.”

⇒ See how the Army uses “Talent-based branching” in an attempt to retain more people when even more money wasn’t working: [Army helping cadets match talent to branch selection](https://www.army.mil/article/184591/army_helping_cadets_match_talent_to_branch_selection)

## The role of a parent—how to encourage sampling, when to push them, when to allow them to quit, and insights from the childhood of Tiger Woods and Wolfgang Mozart [1:55:45]

**How Jason summarizes his role as a parent**:

> “Help him know that a lot of things are available and how to get the maximum amount of signal about himself from each one. And I think there are ways that that can be done possibly more effectively and a lot more cheaply than the formal education structure right now.”

**As a parent,** ***how do you know when to push your kid or for how long?***

*Peter sets up 2 scenarios from his life about his daughter…*

-Scenario 1, playing drums

- His daughter started playing drums at age 4
- She loved it for years
- Then around age 7 she wanted to quit
- But Peter asked her drum teacher to dial back the formal lessons and sort of let her play what she wanted
- This decision seemed to revive her interest and drums and now she’s 11 and still loves drumming

-Scenario 2, tennis lessons

- His daughter takes tennis lessons from a really great teacher
- But she is not wanting to continue
- But in Peter’s mind, he knows how valuable learning tennis will be bc it’s a sport that she can play her whole life
- And she’s in that critical learning zone that she can really pick up this sport
- Peter’s fear is that she will regret not sticking to tennis ⇒ “*No 50 year old woman is running around playing pick up basketball. But you will still play tennis so why wouldn’t you continue to learn this now while you have this critical window in which you could get good at this sport.*”
- Peter admits that he’s still stuck to this idea of there being a “critical window” that she can assimilate skill
- David also adds that when you start young you have
  - 1) more time to put into it,and
  - 2) you are less concerned about mistakes which allows you to keep pushing forward

*-David says these 2 scenarios are great questions*:

- It sounds like in the drumming example Peter was able to “keep her foot in by changing what she was doing”
- Peter says, that’s true… but also, it would have never even occurred to me to put her in drums
- Instead, it was 100% his daughter insisting on it

**But what about scenarios where your kids are insisting on anything…**

*-Is there an age at which parents should force some of the sampling?*

*-Is there an age at which parents say you’ve sampled enough and it’s “okay” to quit?*

- David response: “*I should make clear. I don’t want to prescribe diversification anymore than I want to prescribe specialization.*”

**The childhood stories of Tiger Woods and Wolgang Mozart:**

*-In Tiger’s case…*

- He said his father never asked him to play golf
- Tiger says that “it’s the child’s desire to play not the parent’s desire to have the child play that matters”
- That resonates with the work of psychologist, [Ellen Winner](https://en.wikipedia.org/wiki/Ellen_Winner), who says ‘*it’s usually the kids driving their parents crazy…Not the reverse.*’
  - And the bigger problem is actually when the kid’s desire can’t be accommodated by the parents due to low socioeconomic status

*-In Mozart’s case…*

- The common misconception is that his father pushed music on Mozart and drove him to be this prodigy
- In reality, Mozart’s father never did that at all and was skeptical/aloof about Mozart’s capability
- It wasn’t until Mozart’s father finally paid attention and realized how talented Mozart was at a very young age
- And at that point his father only then began helping Mozart along the path

**The takeaway from the Tiger and Mozart stories**:

> “I don’t think we should be scared about missing a Tiger or Mozart. Because the best way to find one of those people is probably still to expose them to a bunch of things. And see if something lights their fire that way.”

⇒ [Ellen Winner](https://en.wikipedia.org/wiki/Ellen_Winner) says that child prodigies have a “[rage to master](https://howardgardner.com/2018/12/10/a-rage-to-master-a-blog-on-gifted-children-by-dr-ellen-winner/)” but that may never get ignited if they are never exposed to that thing

**When do you allow your kid to quit?**

- This is a very tough question, says David
- Grit expert, Angela Duckworth, advises to never quit on a bad day
  - The counter to that would be, what if you keep having bad days repeatedly? Maybe you should quit on a bad day
  - But this idea of quitting, it is really an underappreciated thing, isn’t it? Because sometimes it’s the … It’s time.
- David’s best formed advice would be the following:
  - 1) First, rather than quit try to vary up the process (like Peter did with his daughter playing the drums)
  - 2) Next, give them a break from the activity but keep their foot in the pool so they don’t completely detach from it
  - 3) Finally, allow them to completely detach but leave the door open for them to return bc maybe they will eventually come back to it

**Finishing thoughts on when to quit**:

- We tend to think of quitting as a *binary* choice
- **But varying up what you’re doing can be an alternative** ⇒ “*I think that’s incredibly undervalued. We act as if it’s a binary choice instead of, ‘Why don’t we see what else this area has to offer? Maybe you just need to get on a different track.*’”
- **Taking a break could work**… “*we know that progress comes from alternating stress and rest*” says David
- **A good coach can help**… “*the brilliance of good coaches is they help personalize that environment so that the person continues to be interested and continues to progress*.”

## The need for varied perspectives and the ability to improvise—insights gained from the Space Shuttle Challenger tragedy [2:08:45]

**Space shuttle Challenger story**

- In Range, David writes about the [fateful event](https://en.wikipedia.org/wiki/Space_Shuttle_Challenger_disaster) with the first space shuttle carrying a civilian, [The Challenger](https://en.wikipedia.org/wiki/Space_Shuttle_Challenger), exploded shortly after launch
- Specially, David focuses an emergency conference call the night before the launch, when the weather report came and that it was going to be an unusually cold day in Florida
- Turns out that there was evidence that the cold weather might compromise the “o-ring”
- However, the authorities asked the engineers to “quantify” the temperature which would cause a catastrophic disaster
- Since the people couldn’t tell them an exactly temperature, they decided to launch
- “the story is tragic on so many levels because it would almost be easier to accept a disaster like that if nobody had seen what could have been done. That’s what makes it so painful. But on a second reading, what makes it even more painful is the way that questions are being asked. . .
- . . .that’s not a linear question. Right? That’s an asymmetry question. That’s the question of, “So and so has an actuarial risk of having a heart attack of 5.4% in the next decade. Should you take preventative measures?” I don’t know. I mean, depends on your view of the world. What’s the upside, what’s the downside? What’s the risk of doing something about it versus the risk of not doing something about it? Those are very asymmetric risks.”
- Famous physicist [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) weighted in after the diaster:
  - Feinman was asking questions like this, like, “*What were you trying to get him to say?*”
  - They say, “*Well, he couldn’t quantify his cases because he didn’t have data.*”
  - And Feinman says, “*When you don’t have data, you have to use reason, and he was giving you reasons.*”
- David says that NASA was incredibly prudent and structured in order to avoid disasters…
- However… in this case they rigid structure backfired on them
- “*I think it’s worth getting a different view when you’re assessing that risk.*” says David

> “Insisting on perfect safety is for people who don’t have the balls to live in the real world.” —Mary Shafer, NASA engineer

[**Space Shuttle Columbia**](https://en.wikipedia.org/wiki/Space_Shuttle_Columbia) **accident**

- This space shuttle burned up upon re-entry
- Totally different issue, but the same “culture” could be blamed for the screw up
- A “cultural carbon copy” says David
- In fact, the investigation commission for the Columbia accident wrote in their conclusions, “This is so similar to the Challenger disaster, culturally, that we deem NASA not a learning organization because they didn’t learn from that experience.”
- NASA had an incredibly strong process culture
- They had this sign that said, “In God we trust. All others bring data,”
- They were super rigorous, which is a good thing…
- … But when they would get into these situations where you didn’t have the data you wanted, then continuing to ask for it and follow these very strict procedures, meant they **really constrained their thinking**.

## How a diversified background and identity could be the difference in life or death—the Hotshot firefighters case study [2:22:15]

**The story about hot shot firefighters**

- These were some of the most daring and extreme firefighters who are dropped into wild fires
- They are very good at their job but sometimes things would go wrong and they would die
- The psychologist [Karl Weick](https://en.wikipedia.org/wiki/Karl_E._Weick) studies these events and noticed that many of the men died still holding on to their hundreds of pounds of equipment (tools, chainsaws, drip torches, axes, etc.)
- The hypothesis was that these men so strongly held their tools as part of their identity as a firefighter that it was unthinkable to drop them even if it meant life or death
- In his book called [The Young Men and Fire](https://www.amazon.com/Young-Men-Fire-Norman-Maclean/dp/0226500624), [Norman Maclean](https://en.wikipedia.org/wiki/Norman_Maclean) wrote that being asked to drop your tools is like being asked to forget that you are a firefighter because that’s your whole group identity and all your training is built on, never getting rid of your tools. But an unfamiliar situation, holding onto them kills you.

The **first takeaway** from this story is something Peter points out ⇒ This story is an allegory for a question in life, “What are the tools that I am lugging around that are probably helping me 99% of the time, but 1% of the time, not only are they not helping me but they could be catastrophically wounding me?”

The **second takeaway** from this story is that the people with a more varied background (and therefore didn’t only identify as a firefighter) were more likely to survive

- The survivors would generally be the ones who dropped their tools
- In fact, during a famous disaster, the [Mann Gulch fire](https://en.wikipedia.org/wiki/Mann_Gulch_fire), the leader of the firefighters ordered his men to drop the tools and run, but most of them refused (and died)
- That same leader also realized he wouldn’t be able to outrun the fire so instead he improvised by lighting a fire in the area surrounded him and then jumping into the ashes which shielded him from the blaze
- Weick and McClean argued he was much better set up to improvise because he was used to improvising with tools

## David’s takeaways from the inspiring story of Frances Hesselbein [2:29:00]

**Frances Hesselbein**

- A woman named Frances Hesselbein took her first real job at the age of 54
- And that first job was the CEO of the Girl Scouts
- Before then, she had one semester of junior college under her belt in her entire life
- And when she actually interviewed for the CEO position, the people before her had had incredible leadership credentials—Captain Dorothy Stratton who started the women’s Coast Guard Reserve, and another was a university Dean. Another was Cecily Cannan Selby, a prominent scientist and leader in industry and education.
- Frances Hesselbein, on the other hand, was a leader of one of 355 local councils of Girl Scouts
- This is late ’60s, Girl Scouts is in total crisis, free fall of membership and volunteers.
- In the interview, Francis basically just decided to be as authentic as possible because what did she have to lose?
- They asked, “And what would you do if you took it over?”
- And she says she doesn’t want the job.
- But she then says she would, “Throw out our sacrosanct handbook. I’d replace it with ones that appeal to girls of different ages and start working on diversity. If an indigenous girl in Alaska opens a book, I want her to see herself in a Girl Scouts uniform.”
- She continued… “I’d sell some of the underused camp sites, even though it’d be painful, get rid of some of this homemaking stuff, educate girls about sex and drugs and math and science and all this.”
- She thinks there’s no way she will hear from them again after the interview (Of course, she gets the CEO job)

*-She totally transforms the organization*:

- Turned the cookie business into a third of $1 billion business, triples diversity representation, adds 130,000 volunteers people, she’s paying in a sense of mission, not in money, and basically saves the Girl Scouts.
- This story meant a lot to David because…
- One, people can make an impact when they’re older than they think they can.
- She’s now running the Frances Hesselbein Leadership Institute and teaching at West Point.
- “*Also, she never expected to do any of the things she did. Every time she got offered an opportunity, she’d say like, “Nope, I’m not doing it.” And then they’d tell her, “Well, then this Girl Scout troop’s going to have to be folded. Sorry.” And she’d be like, “Fine, I’ll do it for a month,” and would get to try it and be like, “Wait, I actually love this.” And that’s everything she did. So, she short term planned her way through life.*”

**She had two sayings that really stuck with David**:

One was, “*Leadership is a matter of how to be, not a matter of what to do*.”

- I think that’s a powerful thing to think about.
- So much about leadership is being a good example, not having to know everything.

Another one was, “*You have to carry a big basket to bring something home*.”

- What she means is that if you have the right mindset, you can always learn something new

![](https://peterattiamd.com/wp-content/uploads/2020/03/frances-hesselbein-davidepstein-1024x591.jpg)**Figure 1. Picture of Frances Hesselbein.** Image credit: [fortune.com](https://fortune.com/worlds-greatest-leaders/2015/frances-hesselbein/)

§

## Selected Links / Related Material

**Books authored by David**: [0:45]

- [The Sports Gene: Inside the Science of Extraordinary Athletic Performance](https://www.amazon.com/Sports-Gene-Extraordinary-Athletic-Performance/dp/161723012X) by David Epstein | (amazon.com) [2:40, 15:00, 33:40]
- [Range: Why Generalists Triumph in a Specialized World](https://www.amazon.com/Range-Generalists-Triumph-Specialized-World/dp/0735214484) by David Epstein | (amazon.com) [13:45, 48:15, 54:15, 1:35:45]

**One of the “great sports documentaries”**: [Senna (film)](https://en.wikipedia.org/wiki/Senna_(film)) | (wikipedia.org) [3:15]

**Where Peter hopes to soon the memorial of Ayrton Senna in São Paulo**: [Senna’s Grave Morumbi Cemetery](https://www.tripadvisor.com/Attraction_Review-g303631-d1724606-Reviews-Senna_s_Grave_Morumbi_Cemetery-Sao_Paulo_State_of_Sao_Paulo.html) | (tripadvisor.com) [7:30]

**Senna’s foundation that Peter hopes to visit**: [Instituto Ayrton Senna](https://en.wikipedia.org/wiki/Instituto_Ayrton_Senna) | (wikipedia.org) [7:30]

**Ayrton Senna’s qualifying session in 1988 at Monaco**: [SENSATIONAL SENNA IN MONACO](https://www.mclaren.com/racing/2018/legendary-laps/senna-1988-quali-lap-2119884/) | (mclaren.com) [8:45]

**Ayrton Senna onboard camera at the 1990 Monaco Grand Prix**: [F1 Classic Onboard: Senna On The Charge At The 1990 Monaco Grand Prix](https://www.youtube.com/watch?v=auXfAHHNSFo) | FORMULA 1 (youtube.com) [9:45]

**After crashing out in the 1988 Monaco Grand Prix race, Senna was disgusted with himself he gets out of the car, literally leaves, goes straight to his home in Monaco, doesn’t speak with anybody for days**: [Ron Dennis on Senna – Part one: the early years](https://web.archive.org/web/20140623141122/https://www.formula1.com/news/features/2014/4/15769.html) | (formula1.com)[10:45]

**Book by Canadian philosopher which suggests a value in sports is the voluntary acceptance of unnecessary obstacles**: [The Grasshopper: Games, Life and Utopia](https://www.amazon.com/Grasshopper-Games-Life-Utopia/dp/155111772X) by Bernard Suits | (amazon.com) [11:45]

**David’s SI article in 2010 which he is self-critical of, including citing it as wrong in his book, The Sports Gene**: [Sports Gene](https://vault.si.com/vault/2010/05/17/sports-genes) | David Epstein (si.com) [15:00, 59:30]

**Daniel Coyle’s book that Peter read which discussed mastery, deliberate practice, and the 10,000 hour rule**: [The Talent Code: Greatness Isn’t Born. It’s Grown. Here’s How.](https://www.amazon.com/Talent-Code-Greatness-Born-Grown/dp/055380684X) by Daniel Coyle | (amazon.com) [19:30]

**The original study from with the so-called 10,000-Hour Rule was born**: [The Role of Deliberate Practice in the Acquisition of Expert Performance](https://projects.ict.usc.edu/itw/gel/EricssonDeliberatePracticePR93.pdf) (Ericsson et al., 1993) [21:15]

**It takes 11,053 hours on average to reach international master status in chess but there’s huge variation from person to person**: [Deliberate Practice: Necessary But Not Sufficient](https://www.researchgate.net/publication/226396370_Deliberate_Practice_Necessary_But_Not_Sufficient) (Gobet and Campitelli, 2011) [22:45]

**A study that attempted to replicate the results from Ericsson’s original study which lead to the 10,000 hour rule**: [The role of deliberate practice in expert performance: revisiting Ericsson, Krampe & Tesch-Römer (1993)](https://royalsocietypublishing.org/doi/10.1098/rsos.190327) ( Macnamara and Maitra, 2019) [24:45]

**David’s ProPublica article about how evidence and practiced medicine don’t always align**: [When Evidence Says No and Doctors Say Yes](https://www.propublica.org/article/when-evidence-says-no-but-doctors-say-yes) | David Epstein (propublica.org) [29:00]

**Finnish study comparing results of meniscus repair surgery to sham surgery**: [Arthroscopic Partial Meniscectomy versus Sham Surgery for a Degenerative Meniscal Tear](https://www.nejm.org/doi/full/10.1056/NEJMoa1305189) (Sihvonen et al., 2013) [29:30]

**Study showing that identical cycling training in sedentary people in the same family produced huge variance in results**: [The HERITAGE Family Study: quality assurance and quality control.](https://www.ncbi.nlm.nih.gov/pubmed/8978882) (Gagnon et al., 1996) [34:45]

**In research for The Sports Gene, David was surprised to find that major league baseball players don’t have faster reflexes**: [The curious case of Lars Anderson](https://www.espn.com/blog/sweetspot/post/_/id/38831/the-curious-case-of-lars-anderson) | David Schoenfield (espn.com) [37:45]

**Formula 1 drivers don’t really have faster reflexes, they just have to eyesight way further down the road to they have more time to react**: [38:15]

- [Advanced Eye Strategy For Elite Racing Drivers](https://gts-rs.co.uk/2017/11/22/advanced-eye-strategy-elite-racing-drivers/) | (gts-rs.co.uk)
- [F1 driver eye-tracking versus a normal person](https://www.facebook.com/watch/?v=171929437071624) | WTF1 (facebook.com)

**In the Sports Gene, David wrote about how Muhammad Ali didn’t have extraordinary reflexes**: [The Sports Gene](https://download.e-bookshelf.de/download/0002/2517/13/L-X-0002251713-0005989885_mobile.XHTML/index.xhtml) [39:30]

**The example of a wicked learning situation where the famous New York doctor who got wealthy by being able to miraculously predict people would get typhoid and it turned out that he was the one giving it to them**: [Educating Intuition (book preview)](https://books.google.com/books?id=fsffJGkpwVIC&pg=PA85&lpg=PA85&dq=robin+hogarth+New+York+City+physician+typhoid+fever+educating+intuition&source=bl&ots=_eU_ODmbVb&sig=ACfU3U3IEg1nn4ITMZEHiocWjHHE_sP5dQ&hl=en&sa=X&ved=2ahUKEwjtxKuU0IboAhVI1qwKHf7JBuAQ6AEwAXoECAsQAQ#v=onepage&q=robin%20hogarth%20New%20York%20City%20physician%20typhoid%20fever%20educating%20intuition&f=false) | (books.google.com) [42:45]

- *Here’s a blogger’s write up of this same story of the typhoid doctor*: [Learning, Feedback and Intuition](https://j-dm.org/archives/744) | (j-dm.org) [42:45]

**Essay describing how adding more people to a software project that was taking too long only made it take longer**: [The Mythical Man-Month](https://en.wikipedia.org/wiki/The_Mythical_Man-Month), an essay by [Fred Brooks](https://en.wikipedia.org/wiki/Fred_Brooks) [45:45]

**Follow up study found similar results**: [The experience trap.](https://www.ncbi.nlm.nih.gov/pubmed/18314637) (Sengupta et al., 2008) [46:30]

**The US Air Force study looking at students’ performance in calculus courses with varied teaching approaches**: [Does Professor Quality Matter? Evidence from Random Assignment of Students to Professors](https://faculty.econ.ucdavis.edu/faculty/scarrell/profqual2.pdf) (Carrell and West, 2010) [48:30]

**Japan has a term called bansho that means the type of writing on the blackboard that tracks all these different approaches to the same problem**: [Bansho (What is it?)](https://theothermath.com/index.php/2017/08/20/bansho-what-is-it/) | (theothermath.com) [54:30]

**A study looking at blocked practice vs. interleaving practice in 7th grade math students**: [The benefit of interleaved mathematics practice is not limited to superficially similar kinds of problems.](https://www.ncbi.nlm.nih.gov/pubmed/24578089) (Rohrer et al., 2014) [57:30]

- *Another more recent study looking at interleaved learning*: [Interleaved Learning in Elementary School Mathematics: Effects on the Flexible and Adaptive Use of Subtraction Strategies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6385790/) (Nemeth et al., 2019)

**Tiger Woods demonstrating a gold swing at two years old on TV**: [Tiger Woods At 2 Years Old](https://www.youtube.com/watch?v=MxPmzIKBris) | pixies2105 (youtube.com) [1:02:00]

**Study of German soccer players showed the ones who stood out most in their teens were those who did a wider variety of activities**: [Practice and play in the development of German top-level professional football players.](https://www.ncbi.nlm.nih.gov/pubmed/25440296) (Hornig et al., 2014) [1:06:30]

**A longitudinal study of young athletes suggests the best predictor of an overuse injury was how specialized the athlete was, but there was some protective effect from diversifying**: [Overuse injuries and burnout in youth sports: a position statement from the American Medical Society for Sports Medicine.](https://www.ncbi.nlm.nih.gov/pubmed/24463910/) (DiFiori et al., 2014) [1:08:00]

**A book that points out that as tennis players rise in the ranks the way to win starts by just keeping the ball in play until the other player makes an error but when you get to the elite level, it’s exactly the opposite**: [Extraordinary Tennis for the Ordinary Player](https://www.amazon.com/Extraordinary-Tennis-Ordinary-Player-Simon/dp/0517511991) by Simon Ramo | (amazon.com) [1:08:30]

**Book that makes the case that there is a “critical window” for mastering a skill**: called Why Michael Couldn’t Hit [1:15:00]

**Guy who decided to try to become a pro golfer by doing 10,000 hours exactly of deliberate practice without any prior golfing experience**: [Dan McLaughlin (golfer)](https://en.wikipedia.org/wiki/Dan_McLaughlin_(golfer)) | (wikipedia.org) [1:16:30]

**More obscure sports take less time to rise to the top such as the Olympic sport called skeleton**: [Talent identification and deliberate programming in skeleton: ice novice to Winter Olympian in 14 months](https://www.ncbi.nlm.nih.gov/pubmed/19191166). (Bullock et al., 2009) [1:18:00]

**Some studies that show that people who’ve done a variety of “invasion” sports will then pick up any subsequent invasion sport more rapidly**: [1:19:15]

- [Comparative Study of Two Intervention Programmes for Teaching Soccer to School-Age Students](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6473480/) (Garcia-Ceberino et al., 2019)
- [Identification of non-specific tactical tasks in invasion games](https://www.tandfonline.com/doi/abs/10.1080/17408980903273121) (Memmert and Harvey, 2010)
- [The impact of a hybrid Sport Education–Invasion Games Competence Model soccer unit on students’ decision making, skill execution and overall game performance](https://journals.sagepub.com/doi/abs/10.1177/1356336X12440027) (Mesquita et al., 2012)

**People who grow up bilingual seem to have an advantage for then learning a third language**: [The bilingual advantage in novel word learning.](https://www.ncbi.nlm.nih.gov/pubmed/19648456/) (Kaushanskaya and Marian, 2009) [1:20:30]

**There appears to be a real sensitive period in language where, about after age 12, you’re not going to make something your** ***native*** **language anymore**: [Language Development in 11-13 Year Olds](https://www.scholastic.com/parents/family-life/social-emotional-learning/development-milestones/language-development-11-13-year-olds.html) | MICHELLE ANTHONY (scholastic.com) [1:20:30]

**Study showing that if you don’t start studying chess patterns by age 12 your chances of reaching international master status drop from 1 in 4 to 1 in 55**: [Deliberate Practice: Necessary But Not Sufficient](https://www.researchgate.net/publication/226396370_Deliberate_Practice_Necessary_But_Not_Sufficient) (Gobet and Campitelli, 2011) [1:21:45]

**Peter recently appeared on the Nock On Podcast where he was asked why he loves archery and driving a race car so much**: [PC 244 – Dr Peter Attia – Icon Series](https://nockon.podbean.com/e/pc-244-dr-peter-attia-icon-series/) | John Dudly  [1:22:30]

**Ayrton Senna saying his favorite time racing was while karting before politics were part of the picture**: [Senna (2010) ending – Ayrton Senna interview](https://youtu.be/qYYIzDMJbpY) | Fernando Amato (youtube.com) [1:24:00]

**Episode of The Drive with Sasha Cohen who said he favorite time ice skating was** ***before*** **she was expected to win**: [#78 – Sasha Cohen: The price of achievement, and redefining success](https://peterattiamd.com/sashacohen/) | Peter Attia (peterattiamd.com) [1:24:15]

**Nobel laureates are 22 times more likely to have a hobby**: [Arts Foster Scientific Success: Avocations of Nobel, National Academy, Royal Society, and Sigma Xi Members](https://www.researchgate.net/profile/Kendell_Pawelec/publication/247857346_Arts_Foster_Scientific_Success_Avocations_of_Nobel_National_Academy_Royal_Society_and_Sigma_Xi_Members/links/00b4953c00f875f191000000.pdf) (Root-Bernstein et al., 2008) [1:24:45]

**Book that David said helped him to realize the importance of always being open to learning new things**: [Zen Mind, Beginner’s Mind](https://www.amazon.com/Zen-Mind-Beginners-Meditation-Shambhala/dp/1590302672/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)  by Shunryu Suzuki | (amazon.com) [1:25:30]

**One of David’s favorite sports stories was of Petra Majdic, Sylvanian skier, at the Vancouver Winter Olympics in 2010 who medalled despite major injuries**: [Motivation Video Petra Majdič vancouver 2010 winter olympic games NEVER GIVE UP!](https://www.youtube.com/watch?v=M79oNtIc9GE) | rok yt (youtube.com) [1:26:30]

**2005 paper about the prevalence of bad science being published**: [Why Most Published Research Findings Are False](https://journals.plos.org/plosmedicine/article/file?type=printable&id=10.1371/journal.pmed.0020124) (John Ioannidis, 2005) [1:31:30]

**Peter’s blog post about why humans don’t naturally think scientifically**: [Why we’re not wired to think scientifically (and what can be done about it)](https://peterattiamd.com/wired-think-scientifically-can-done/) | Peter Attia (peterattiamd.com) [1:33:15]

**Company that helps other companies post their problems online for “outsider” to solve**: [InnoCentive](https://www.innocentive.com/) | (innocentive.com) [1:36:30]

**Arturo Casadevall found that the New England Journal of Medicine had the highest retraction rate**: [Retraction index](https://en.wikipedia.org/wiki/Retraction_index) | (wikipedia.org) [1:42:00]

**A natural experiment in the higher ed systems of England and Scotland comparing early specializers to later specializers**: [Discovering One’s Talent: Learning from Academic Specialization](https://www.nber.org/papers/w15522.pdf) (Ofer Malamud, 2009) | (nber.org) [1:45:00]

**The Harvard “Dark Horse” project trying to answer path makes people successful/fulfilled and have found that it’s usually a winding, not linear path with changing aims and rarely the original “dream”**: [Dark Horse: Achieving success through the pursuit of fulfillment](https://lsi.gse.harvard.edu/dark-horse) | (harvard.edu) [1:46:00]

- *Subsequent book*: Dark Horse: [Achieving Success Through the Pursuit of Fulfillment](https://www.amazon.com/Dark-Horse-Achieving-Success-Fulfillment/dp/0062683632?creativeASIN=0062683632&linkCode=w61&imprToken=C9p77J6Vvs3dtrZ29yOmXw&slotNum=0) by Todd Rose and Ogi Ogas | (amazon.com)
- *A post about it on Medium*: [How Harvard’s Dark Horse Project is Shattering Old Beliefs about Success](https://medium.com/the-book-mechanic/how-harvards-dark-horse-project-is-shattering-old-beliefs-about-success-44d1d0897e72) | August Birch (medium.com)
- *And an article about it from the authors*: [How ‘dark horses’ flip the script of success and happiness](https://bigthink.com/big-think-books/what-is-the-dark-horse-project) | (bigthink.com)

**Peter’s blog post about his math teacher that changed his trajectory in life**: [Thank you, Woody](https://peterattiamd.com/thank-you-woody/) | Peter Attia (peterattiamd.com) [1:46:15]

**Angela Duckworth’s TED Talk about the concept of ‘grit’**: [Grit: The power of passion and perseverance](https://www.ted.com/talks/angela_lee_duckworth_grit_the_power_of_passion_and_perseverance/up-next?language=en) | (ted.com) [1:47:50]

**Book that describes how con men always start with a small ask and go up from there to take advantage of the sunk cost fallacy**: [The Confidence Game: Why We Fall for It . . . Every Time](https://www.amazon.com/Confidence-Game-Fall-Every-Time/dp/0143109871) by Maria Konnikova | (amazon.com)[1:52:15]

**Steve Levitt, the Freakonomics economist, did a study where he had people flip a coin to determine major life decisions and found those who made a change rather than stand pat were happier**: [Heads or Tails: The Impact of a Coin Toss on Major Life Decisions and Subsequent Happiness](https://www.nber.org/papers/w22487) (Steven D. Levitt, 2016) [1:53:15]

**Book arguing against getting a college education**: [The Case Against Education](https://www.amazon.com/Case-against-Education-System-Waste/dp/0691174652) by Brian Kaplan | (amazon.com) [1:54:00]

**How the Army uses “Talent-based branching” in an attempt to retain more people when even more money wasn’t working**: [Army helping cadets match talent to branch selection](https://www.army.mil/article/184591/army_helping_cadets_match_talent_to_branch_selection) | David Vergun (army.mil) [1:56:15]

**Dr. Ellen Winter on a trait in some kids called a “rage to master”**: [“A RAGE TO MASTER”: A BLOG ON GIFTED CHILDREN BY DR. ELLEN WINNER](https://howardgardner.com/2018/12/10/a-rage-to-master-a-blog-on-gifted-children-by-dr-ellen-winner/) | (howardgardner.com) [2:04:40]

**The second NASA disaster that mirrored that of the Challenger accident**: [Space Shuttle Columbia](https://en.wikipedia.org/wiki/Space_Shuttle_Columbia) | (wikipedia.org) [2:19:40]

**Karl Weick resources about sensemaking and dropping tools**: [2:22:45]

- [The collapse of sensemaking in organizations: the Mann Gulch disaster](https://www.nrfirescience.org/resource/15592) | (nrfirescience.org)
- [Tool retention and fatalities in wildland fire settings: conceptualizing the naturalistic](https://www.nrfirescience.org/resource/16257) | (nrfirescience.org)
- [Drop your tools: an allegory for organizational studies](https://www.nrfirescience.org/resource/16256) | (nrfirescience.org)

**Book that described the Hotshot firefighters who wouldn’t drop their tools**: [The Young Men and Fire](https://www.amazon.com/Young-Men-Fire-Norman-Maclean/dp/0226500624) by Norman Maclean (amazon.com) [2:23:30]

- *Norman Maclean also famously wrote*: [A River Runs Through It](https://www.amazon.com/River-Runs-through-Other-Stories/dp/022647206X/ref=sr_1_1?qid=1583512352&refinements=p_27%3ANorman+Maclean&s=books&sr=1-1&text=Norman+Maclean) by Norman Maclean (amazon.com) [2:23:30]

**Big fire that claimed the lives of several Hotshot firefighters**: [Mann Gulch fire](https://en.wikipedia.org/wiki/Mann_Gulch_fire) | (wikipedia.org) [2:27:45]

**Frances Hesselbein’s Leadership program**:  [Frances Hesselbein Leadership Forum](https://uia.org/content/1536) [2:31:45]

§

## People Mentioned

- [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) [3:15, 1:24:00]
- [John F. Kennedy](https://en.wikipedia.org/wiki/John_F._Kennedy) [5:15]
- [Martin Luther King Jr.](https://en.wikipedia.org/wiki/Martin_Luther_King_Jr.) [5:15]
- [Emerson Fittipaldi](https://en.wikipedia.org/wiki/Emerson_Fittipaldi) [6:45]
- [Nelson Piquet](https://en.wikipedia.org/wiki/Nelson_Piquet) [6:45]
- [Pelé](https://en.wikipedia.org/wiki/Pel%C3%A9) [7:00]
- [Alain Prost](https://en.wikipedia.org/wiki/Alain_Prost) [9:20]
- [Usain Bolt](https://en.wikipedia.org/wiki/Usain_Bolt) [9:45, 1:00:45]
- [Bernard Suits](https://en.wikipedia.org/wiki/Lusory_attitude) [11:45]
- [Ludwig Wittgenstein](https://en.wikipedia.org/wiki/Ludwig_Wittgenstein) [12:00]
- [Aristotle](https://en.wikipedia.org/wiki/Aristotle) [12:45]
- [Bob Kaplan](https://twitter.com/bobkaplan?lang=en) [16:00]
- [Daniel Coyle](https://danielcoyle.com/author/) [19:30]
- [Bill Gates](https://en.wikipedia.org/wiki/Bill_Gates) [22:45]
- [Anders Ericsson](https://en.wikipedia.org/wiki/K._Anders_Ericsson) [23:30, 34:30, 1:19:30]
- [Tim Lightfoot](https://directory.education.tamu.edu/view.epl?nid=tlightfoot) [24:15]
- [Francis Bacon](https://en.wikipedia.org/wiki/Francis_Bacon) [28:20]
- [Mike Joyner](https://www.mayo.edu/research/faculty/joyner-michael-j-m-d/bio-00078027) [29:15]
- [Michael Jordan](https://en.wikipedia.org/wiki/Michael_Jordan) [36:00, 1:15:00]
- [Lewis Hamilton](https://en.wikipedia.org/wiki/Lewis_Hamilton) [38:15]
- [Muhammad Ali](https://en.wikipedia.org/wiki/Muhammad_Ali) [39:30]
- [Robin Hogarth](https://www.econ.upf.edu/~hogarth/Robin_M._Hogarth/Home.html) [41:00]
- [Woody](https://peterattiamd.com/thank-you-woody/) (“that teacher who I think sort of turned my life around”) [51:30, 1:46:15]
- [Tiger Woods](https://en.wikipedia.org/wiki/Tiger_Woods) [1:01:45, 2:02:00]
- [Roger Federer](https://en.wikipedia.org/wiki/Roger_Federer)  [1:02:00]
- [Brooks Koepka](https://en.wikipedia.org/wiki/Brooks_Koepka) [1:10:00]
- [Chris Froome](https://en.wikipedia.org/wiki/Chris_Froome) [1:10:30]
- [Ross Tucker](https://sportsscientists.com/who-are-we/) [1:13:15]
- [Wayne Gretzky](https://en.wikipedia.org/wiki/Wayne_Gretzky) [1:15:20, 2:02:45]
- [Lorenzo Cain](https://en.wikipedia.org/wiki/Lorenzo_Cain) [1:16:00]
- [Dan McLaughlin](https://en.wikipedia.org/wiki/Dan_McLaughlin_(golfer)) [1:16:30, 2:06:15]
- [Terry Fullerton](https://en.wikipedia.org/wiki/Terry_Fullerton) [1:24:00]
- [Sasha Cohen](https://en.wikipedia.org/wiki/Sasha_Cohen) [1:24:15]
- [Petra Majdič](https://en.wikipedia.org/wiki/Petra_Majdi%C4%8D) [1:26:30]
- [Francis Crick](https://en.wikipedia.org/wiki/Francis_Crick) [1:29:15]
- [John Ioannidis](https://profiles.stanford.edu/john-ioannidis) [1:31:30]
- [Alph Bingham](https://www.innocentive.com/alpheus-bingham-ph-d/) [1:36:30]
- [Freeman Dyson](https://en.wikipedia.org/wiki/Freeman_Dyson) [1:39:30]
- [Arturo Casadevall](https://en.wikipedia.org/wiki/Arturo_Casadevall) [1:40:00]
- [Albert Einstein](https://en.wikipedia.org/wiki/Albert_Einstein) [1:40:15]
- [Herminia Ibarra](https://twitter.com/HerminiaIbarra?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [1:44:00]
- [Steve Jobs](https://en.wikipedia.org/wiki/Steve_Jobs) [1:47:00]
- [Angela Duckworth](https://en.wikipedia.org/wiki/Angela_Duckworth) (grit) [1:47:50, 1:55:45]
- [Muhammad Ali](https://en.wikipedia.org/wiki/Muhammad_Ali) [1:49:00]
- [Mike Tyson](https://en.wikipedia.org/wiki/Mike_Tyson) [1:49:00]
- [Marvin Hagler](https://en.wikipedia.org/wiki/Marvelous_Marvin_Hagler) [1:49:00]
- [Jimi Hendrix](https://en.wikipedia.org/wiki/Jimi_Hendrix) [1:49:00]
- [Maria Konnikova](https://en.wikipedia.org/wiki/Maria_Konnikova) [1:52:15]
- [Steve Levitt](https://en.wikipedia.org/wiki/Steven_Levitt) [1:53:15]
- [Bryan Caplan](https://en.wikipedia.org/wiki/Bryan_Caplan) [1:54:00]
- [Ellen Winner](https://en.wikipedia.org/wiki/Ellen_Winner) [2:02:15, 2:04:40]
- [Wolfgang Mozart](https://en.wikipedia.org/wiki/Wolfgang_Amadeus_Mozart) [2:03:00]
- [Stephen J. Dubbner](https://en.wikipedia.org/wiki/Stephen_J._Dubner) [2:05:00]
- [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) [2:14:15]
- [Mary Shafer](https://yarchive.net/air/perfect_safety.html) [2:17:15]
- [Allan McDonald](https://www.linkedin.com/in/allan-j-mcdonald-0028b814/) (“if we called off that launch for Challenger, people would be called Chicken Littles”) [2:21:20]
- [Karl Weick](https://en.wikipedia.org/wiki/Karl_E._Weick) [2:22:45]
- [Norman Maclean](https://en.wikipedia.org/wiki/Norman_Maclean) [2:23:30]
- [Frances Hesselbein](https://en.wikipedia.org/wiki/Frances_Hesselbein) [2:29:30]
- [Captain Dorothy Stratton](https://en.wikipedia.org/wiki/Dorothy_C._Stratton)
- [Cecily Cannan Selby](https://www.radcliffe.harvard.edu/news/schlesinger-newsletter/life-devoted-inquiry-cecily-cannan-selby-46) [2:30:00]
- [George Washington](https://en.wikipedia.org/wiki/George_Washington) [2:32:30]

§

![](https://peterattiamd.com/wp-content/uploads/2020/03/bio-pic-davidepstein.png)

##### David Epstein

David Epstein is the author of the #1 New York Times best seller Range: Why Generalists Triumph in a Specialized World, and of the New York Times best seller The Sports Gene, which has been translated in 18 languages. He was previously a science and investigative reporter at ProPublica, and prior to that a senior writer at Sports Illustrated.