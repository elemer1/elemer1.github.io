# #117 – Stanley Perlman, M.D., Ph.D.: Insights from a coronavirus expert on COVID-19

**Source:** [https://peterattiamd.com/stanleyperlman/](https://peterattiamd.com/stanleyperlman/)

---

In this episode Stanley Perlman shares insights from his impressive career studying coronaviruses–both the common and more deadly ones, like MERS and SARS. In comparing preceding coronaviruses with SARS-CoV-2, Stanley discusses how other coronaviruses can aid our current understanding of, and be used to infer about, COVID-19. He also gives his thoughts on durable immunity, therapeutic strategies, and future outbreak preparedness.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/stanleyperlman/the_Drive_public.png)

Play

#117 - Stanley Perlman, M.D., Ph.D.: Insights from a coronavirus expert on COVID-19

#117 - Stanley Perlman, M.D., Ph.D.: Insights from a coronavirus expert on COVID-19

1x15s30s

0:001:43:56

## We discuss:

- His background and early work with coronaviruses [2:45];
- Coronavirus family—various types, common traits, and scientific understanding [9:00];
- The origin of viruses, animal to human transmission, R\_0, immunity, and more [17:45];
- Insights from the 2002 SARS outbreak [28:30];
- Insights from the 2012 MERS outbreak [35:00];
- Comparing SARS-CoV-2 to MERS, SARS, and other coronaviruses [42:00];
- COVID-19 survivor potential for long-term damage [53:30];
- Using the current pandemic for lessons on future preparedness [57:00];
- Genetic drift and the potential for long-term immunity to COVID-19 [1:07:00];
- Prevention and treatment strategies for COVID-19 and future diseases [1:22:30];
- Alternative hypothesis to the origin of SARS-CoV-2 [1:32:30];
- Determining durable immunity to COVID-19 and what a successful vaccine looks like [1:34:30]; and
- More.

§

## Show Notes

## His background and early work with coronaviruses [2:45]

- Stanley first got his Ph.D. in cell biology and developmental biology and virology
- He felt like he needed to get away from such a narrow focus on research and realized he’d like to do something with more relevance for general health issues
- So he then went to medical school where he became interested pediatrics and specifically how how baby brains interacted with viruses
- That interest then broadened into wanting to do research around how viruses interact with the brain
- In parallel, it turned out that coronaviruses in mice provided a model that could lead to potentially important information which he started to also work on
- Coronavirus has turned out to have an interesting ability to cause [demyelination](https://en.wikipedia.org/wiki/Demyelinating_disease)—which was similar to what we see in [multiple sclerosis](https://en.wikipedia.org/wiki/Multiple_sclerosis)
- Stanley spent about 20 years studying this multiple sclerosis-like disease before [SARS came about in 2002](https://en.wikipedia.org/wiki/Severe_acute_respiratory_syndrome)

## Coronavirus family—various types, common traits, and scientific understanding [9:00]

**What is coronavirus?**

- The [coronavirus](https://en.wikipedia.org/wiki/Coronavirus) is a group of related RNA viruses that cause diseases in mammals and bird that can cause respiratory tract infections that can range from mild to lethal
- This set of viruses all have a similar replication strategy
- The have a similar genetic makeup and also look similar through an electron microscope
- It doesn’t mean that they all can infect people, or they all can infect this animal or that animal
- In fact, they can all be very different

-Coronaviruses are unusually large

- The genetic information (the amount of RNA it has) of a coronavirus is about four times that of the poliovirus
- And yet the virus doesn’t seem to do that much more than polio virus
- So a little uncertain exactly why it needs all that genetic information

–*Compared to a human gene…*

- If you took genes and laid them side by side, it could be equivalent to 15 human genes laid side by side in terms of length.
- Coronavirus codes probably about 25 different proteins
- This is lot of information *for a virus*… but it’s nothing compared to the human genome which has ~20,000 genes
- Also, the vast majority of the human genome is **not for coding**
- With a virus, the vast majority is **for coding**

**Do viruses in general have an evolutionary purpose?**

*If you took away all the viruses in the world…*

- “Sure you’d eliminate some of the ones that cause human disease or nonhuman animal disease, but I think you might get away from others that are actually beneficial.”
- We don’t fully understand the role viruses play
- “*But there’s definitely viruses that without which there would be problems.*”

**What is the “corona” in coronavirus derived from?**

- Under the electron microscope, it has projections from the surface of the virus that look like either the corona of the sun or the corona of a crown

![](https://peterattiamd.com/wp-content/uploads/2020/06/figure-1.-stanleyperlman.jpg)

**Figure 1. The “corona”of coronavirus.** Image credit: [nature.com](https://www.nature.com/articles/d41586-020-00660-x)

**When did these coronaviruses show up as a common cold?**

- The first coronavirus was observed in the 1930s and 40s from chicken ([infectious bronchitis virus](https://en.wikipedia.org/wiki/Avian_coronavirus))
- In the 1960s, people [identified](https://pubmed.ncbi.nlm.nih.gov/16378050/) viruses that caused the common cold that had the same appearance as the infectious bronchitis virus
- It was isolated from people with colds and it had the same structure as coronaviruses in chickens and pigs so that’s how they knew it was in the coronavirus family

## The origin of viruses, animal to human transmission, R\_0, immunity, and more [17:45]

*Is it the exception or the rule that a virus that infects humans also has an animal host?*

- Hard to say because there are examples of both
- Measles and smallpox only infect humans (And that’s why we can eliminate them from human populations)
- Most coronaviruses can infect people and animals (making them hard to eradicate)
  - SARS-CoV-2, the cause of COVID-19, [**can** infect animals](https://www.nytimes.com/2020/04/06/nyregion/bronx-zoo-tiger-coronavirus.html) (So humans can infect animals)
  - [SARS-CoV-1](https://en.wikipedia.org/wiki/Severe_acute_respiratory_syndrome_coronavirus) certainly infected other animals
  - [MERS](https://en.wikipedia.org/wiki/Middle_East_respiratory_syndrome) is really a camel virus, so by definition affects other animals
  - Common cold coronaviruses are mostly just humans with the exception of at least one which can infect other animals

*\*The takeaway:* When virus can go from animals to humans and vice versa, it gives the virus a survival advantage

- Example, [West Nile virus](https://en.wikipedia.org/wiki/West_Nile_virus) keeps popping up even though we have an effective vaccine because the virus remains in birds and other animals

**Viruses with a high R\_0**

- Other viruses can survive in humans simply because it spreads so easily
- Measles, for example…
  - There is a large herd immunity to measles
  - But it keeps popping up every few years because the R\_0 is so high that it can manage to find any susceptible people
- Whereas influenza…It has an R\_0 that is just an order of magnitude lower

***Where did human viruses come from if they never had an animal host?***

- They all probably did initially have an animal host
- [Measles](https://en.wikipedia.org/wiki/Measles) is thought to evolve from [rinderpest](https://en.wikipedia.org/wiki/Rinderpest) which affects animals in Africa
- While a virus may start in an animal, it may evolve to be suited for humans and be unable to go back to animals (rendering it a “human only” virus thereafter)
  - So with SARS-CoV-2, we don’t really know if a bat could be infected by it because it may have changed enough even in the little bit of time it’s been out of the bat
- [*HIV*](https://en.wikipedia.org/wiki/HIV) *example*…
  - We have a very strong sense that HIV came from nonhuman primates
  - But now it’s a human virus

**Stanley’s work with coronavirus in the 1990s**

*Late 1990s…*

- Only two known coronaviruses which were [HCoV-229E](https://en.wikipedia.org/wiki/Human_coronavirus_229E) and [HCoV-OC43](https://en.wikipedia.org/wiki/Human_coronavirus_OC43)
  - These viruses manifested as common colds
- [SARS-Cov-1](https://en.wikipedia.org/wiki/Severe_acute_respiratory_syndrome) emerged in 2002-2004
- Then 2 more coronaviruses, [HCoV NL63](https://en.wikipedia.org/wiki/Human_coronavirus_NL63) and [HCoV-HKU1](https://en.wikipedia.org/wiki/Human_coronavirus_HKU1) were discovered after SARS-CoV-1
- In the 90s, however, coronaviruses weren’t on many people’s radar because “*They don’t make people that sick. Who cares?*“

*Takeaway that is relevant to COVID-19…*

- The people who got these common cold coronaviruses [**could be reinfected**](https://www.sciencenews.org/article/covid-19-coronavirus-what-antibody-tests-tell-us)
- So it could be that **if you have a** ***mild*** **infection, you may have a more** ***transient*** **immune response**

⇒ To learn more about the immune response to viruses, please check out [Peter’s discussion with David Watkins](https://peterattiamd.com/davidwatkins/)

- David explains the difference between the innate immune system & the adaptive immune system
- And the two branches of the adaptive immune system:
  - i) The humeral system, which relies on [B cells](https://en.wikipedia.org/wiki/B_cell) and their antibodies,
  - ii) And the cellular system which relies on [T cells](https://en.wikipedia.org/wiki/T_cell)

***Why did Stanley study coronavirus so extensively in the 1990s when it wasn’t a big problem for humans?***

*Mouse virus and multiple sclerosis*

- He was interested mostly in a mouse virus and the human disease, [multiple sclerosis](https://en.wikipedia.org/wiki/Multiple_sclerosis)
- The questions were:
  - How does a virus go into the brain, end up in the cells that make myelin, and how does the virus end up there?
  - How come the immune response can’t figure out how to rid the cells of the virus **without also destroying the cells themselves**, and destroying the function of their cells?
  - For those people that actually get better, how is that occurring?
- Ultimately, Stanley was trying to determine: *How does a virus that’s infecting the brain get cleared? Why does clearance always involve tissue destruction?*

## Insights from the 2002 SARS outbreak [28:30]

[**SARS-CoV-1**](https://en.wikipedia.org/wiki/Severe_acute_respiratory_syndrome_coronavirus) (virus that causes [SARS](https://en.wikipedia.org/wiki/Severe_acute_respiratory_syndrome))

- Emerged in 2002, became a big deal in 2003, and was mostly eliminated by July 2003
- Stanley heard about this virus that was causing a respiratory disease in southern China
- Initially thought this was going to be a kind of flu virus because flu viruses we know initiate often in southern China, particularly in the city of Guangzhou, which is across the bay from Hong Kong
- It then became clear that it was a coronavirus

*-How it spread*

- It came from a live animal market in Guangzhou, a “wet market”
- The SARS coronavirus was almost certainly a bat virus that spread to other animals including the human handlers
- Many of those handlers became sick and developed subclinical disease
- Up to a third of the handlers actually had antibodies to SARS-CoV
- In some cases, it would spread to mainland China and sort of stay there
- But in [one case](https://www.scmp.com/article/410652/inside-hospital-where-patient-zero-was-infected)…
  - A single animal handler became ill enough to see a physician
  - That physician then became quite ill while at a Hong Kong hotel and spread the virus to the other people in the hotel
  - Those people returned to their homes and that’s how the virus ended up spreading around the world

**R\_0 of SARS**

- The R\_0 was about 2-3
  - For context, [measles has an R\_0 of about 15](https://www.thelancet.com/journals/laninf/article/PIIS1473-3099(17)30307-9/fulltext)
  - Common cold coronaviruses have an R\_0 of about 1 on the average
- However, the R\_0 of 2-3 may be “misleading” says Stanley
  - Because SARS spread much more readily inside a hospital
  - SARS was a virus that really caused pneumonia and when in a hospital the virus was released into the air by procedures (intubation or suctioning), **then the R\_0 factor would be much more than 2-3**
  - Within the community, it really isn’t that contagious
  - So if you were to split up those 8,000 cases, the avg. would be 2-3 with quite a range depending on when the virus was acquired

**CFR and IFR of SARS**

- SARS gets widely quoted as having a 10% mortality rate (aka CFR)
- However, we don’t know the **true total** number of cases
- So **case fatality rate** may be 10%
- But the **infection fatality rate** is what really matters which is likely much lower given a unknown number of people probably didn’t have a severe enough version that they warranted hospitalization or testing
- [MERS](https://en.wikipedia.org/wiki/Middle_East_respiratory_syndrome) is much more deadly with a case fatality rate of about 35% (unknown IFR)

## Insights from the 2012 MERS outbreak [35:00]

**MERS-CoV** (virus that causes [Middle East Respiratory Coronavirus](https://en.wikipedia.org/wiki/Middle_East_respiratory_syndrome) aka MERS)

- MERS is similar to SARS in that it’s a deep lung disease
- The mortality (CFR) is estimated to be 35%

*Difference bt SARS and MERS*

- SARS-1 and SARS-2 are in the same beta family
- MERS is a slightly different subdivision of the coronavirus family
- They’re all in the same general group of coronaviruses and within the same subgroup of coronaviruses
- BUT, they’re slightly different in their **genome organization** and in some of their **coding** so they’re put into a separate category.
- So your immune system is less likely to protect you from MERS even if you’ve had SARS (however, MERS coronavirus is recognized **in part** by SARS coronavirus serum from people who survive)
- It’s like your third cousin instead of your first cousin

*When did MERS appear?*

- MERS in camels probably came along  in 1983
- MERS in people was found in 2012

*Mysteries about MERS coronavirus:*

- It’s only in people in the Arabian Peninsula even though camels in Africa also have MERS (it just doesn’t jump to people)
- Also, in camels these coronaviruses caused the *common cold* while in people it was **deadly**
- We still don’t know WHY it’s jumping from camels to people
- It’s occurring once or twice a week now where people are coming to the hospital with MERS (they often have comorbidities/diabetes)
- But it’s unclear HOW they are getting it because many times these people have no contact with camels

*Can MERS spread* ***human to human****? What is the R\_0?*

- Official R\_0 for MERS is somewhere between 0-4 (very broad because it’s dependent on the setting)
- *Outside of hospitals…* the R\_0 probably near to 0.3-0.5 (not impossible to spread from person to person, but it’s a small likelihood)
- *Inside a hospital…* This is where human to human transmission is most likely to occur
- MERS killed roughly one third of the people that were infected
  - ~900 deaths out of ~2,500 confirmed cases

*How it’s transmitted*

- Like SARS, it’s mostly transmitted from people who have severe lung disease
- Nosocomial spread (hospital spread), is a big problem because it’s quite rare so hospital staff doesn’t take the proper precautions every time a person with respiratory distress shows up
- When you put a breathing tube in somebody, you’re really creating an effective portal for the virus to get to you
- And then obviously we know how infections like that can spread through intensive care units and such.

## Comparing SARS-CoV-2 to MERS, SARS, and other coronaviruses [42:00]

*Why didn’t MERS turn into an epidemic, much less a pandemic?*

- The R\_0 of 0.3 (outside a hospital) really makes it very unlikely

*How did we eradicate SARS-CoV-1?*

- The combination of
  - i) there being no reservoir (i.e., no camels that can be transmitted to humans)
  - ii) the fact that because you weren’t contagious until you were sick
- Classic case of identification plus quarantining

**Possibility of being lulled into a false sense of security with SARS-CoV-2**

- With SARS-1, it’s feasible to identify and quarantine with only 8,000 cases around the world (especially when you must have severe symptoms to spread the virus)
- Peter is concerned we could be lulled into a false sense of confidence
- To date, most coronaviruses cause a bunch of colds
- Then a couple bad actors showed up (SARS and MERS) that can really hurt their host, but they’re nothing to really be afraid of because:
  - i) It can’t bounce back and forth between humans and animals
  - ii) You’re very unlikely to spread it if you’re not symptomatic
  - iii) you can just isolate people when they’re sick and treat them before they treat others
- \*None of this is true with SARS-2/COVID-19

***Is it possible that a future coronavirus could come along that’s as lethal as MERS and can spread as easily as SARS-CoV-2?***

- “I don’t think there’s anything that’s unlikely.” says Stanley
- “SARS-CoV-2 is like a mixture of the common cold coronavirus, and then plus either SARS or MERS coronavirus in the lungs.”

*What did SARS-1 and MERS do in the lungs to make it so lethal?*

- It’s the same thing that SARS-CoV-2 does in the lungs in those people who get severe disease.
- We think that there’s two main features:
  - i) there’s lots of virus in the lungs, and
  - ii) there’s a very strong and probably inappropriate immune response that’s causing much of the damage that we see in lungs.

*How do SARS-1 and MERS enter the pneumocyte compared to SARS-CoV-2?*

- SARS uses the ACE2 receptor just like SARS-CoV-2
- MERS uses at different receptor

*Infecting the upper and lower respiratory airway*

- SARS-CoV-2 infects **both the upper and lower airway**
- SARS-1 does NOT affect the upper airway (That’s why it was not so contagious because it stayed in the deep lungs until you went to the hospital and had that tube put down for breathing or some other procedure done)
- One of the common cold coronaviruses, NL63, uses the ACE2 receptor but only infects the **upper airway** and doesn’t affect the lungs (making it not deadly)
- The **upper airway** infection of SARS-CoV-2 could account for the high transmissibility of COVID-19 and the **lower airway** infection increases its lethality

**Comparing mortality rate of SARS, MERS, vs. SARS-CoV-2**

- Stanley suggests that SARS, MERS, and SARS-CoV-2 all have similar mortality rates **of those infected people who come down with pneumonia**
- But SARS-CoV-2 has a much lower infection fatality rate in large part because a majority of infections end up being asymptomatic, subclinical, have a cold, have something in the upper respiratory tract

## COVID-19 survivor potential for long-term damage [53:30]

*For a person who gets infected and has symptoms but survives…*

*What do we know about long-term* ***lung function****?*

- Stanley says we don’t know much about this
- He suspects people had residual problems which could be a few months or it could be forever
- For MERS, Stanley couldn’t get much information out of Saudia Arabia on this topic ⇒ “*I don’t know how much fibrosis was at the end of it all or how much permanent damage there was.*”

*Long term neurological issues?*

- Some people connect SARS to neurological disease without actually ever finding the virus in the brain
- Much of the neurological issues have been attributed to being on ventilators and corticosteroids for long periods of time
- Is a plausible scenario by which the virus could cause residual neurologic issues?
- We can’t find any evidence of the virus in the brain and it seems less likely that it’s direct virus infection.

## Using the current pandemic for lessons on future preparedness [57:00]

**Why didn’t more people think CV could be a pandemic in the future?**

*Peter asks if Stanley had any idea that a coronavirus could become a pandemic level situation*

- Stanley admits he didn’t necessarily predict such an event
- There were people thinking about this
- The DOD in 2010/2011 put out a a report about possible emerging viruses as being a major threat and coronaviruses were on that list
- Bill Gates predicted an event like this in his [2015 TED Talk](https://www.ted.com/talks/bill_gates_the_next_outbreak_we_re_not_ready?language=dz)

*When did Stanley first hear about the COVID-19 outbreak in China?*

- Late December, which is when the first official cases were reported
- Stanley thinks there may have been some in November
- At that time, we didn’t really know how much human to human transmission was happening
- Given the number of cases, we SHOULD have guessed that something unusual is going on
- But by early January or mid-January, we had 800 cases in the world, “*so it didn’t seem to be extraordinarily different from these other viruses*”
- Had there been more information about what was going on in Wuhan, Stanley says that we would have known that something different than SARS-1 and MERS was going on

*When did it become clear to Stanley that this was going to be a much bigger problem than SARS and MERS?*

- After speaking to his friends in China in late December he had a gut feeling that this was a big deal
- But he never felt like it was going to be THIS big of a problem
  - *Why?* ⇒ Mostly because all the previous diseases had remained geographically confined (SARS stayed mostly in China, MERS was really a disease in the Arabian Peninsula)
  - Of course, SARS-CoV-2 ended up being more transmissible and the people of Wuhan travel more frequently all leading to the major spread

*Examples of viruses that were less disastrous than people predicted (potentially contributing to the lack of alarm that people had when they heard about SARS-CoV-2)*:

- [H5N1 swine flu](https://en.wikipedia.org/wiki/Influenza_A_virus_subtype_H5N1)
  - In the late 90s, the H5N1 swine flu was looked at as a potential disaster
  - But it never became transmissible human to human so it never became a problem
- [H1N1 of 2009](https://en.wikipedia.org/wiki/2009_swine_flu_pandemic)
  - Identified in Mexico, it seemed to have a high lethality
  - As more cases were identified it became clear it just was TONS of cases and very little mortality

**Preparing for a future pandemic**

- With coronavirus, there was certainly some thought that it **could** emerge to be a disaster
- But it’s not as easy as simply saying it’s possible and therefore you have the resources to get what you need to be prepared
  - I. e., “*How do you decide what kind of resources you’re going to put to developing antivirals, developing vaccines against SARS, the disease that doesn’t exist anymore?*”
- Good ideas can get funding from the NIH
- However, you’re competing against other grants that make more compelling arguments for funding and deal with **diseases that are actually present**
- “You have to figure out a way to identify a disease that could be a problem without going overboard and using lots of resources for diseases that never will be a problem.”

**-Peter’s take** (on the topic of preparedness):

*–There are some generic things we would need on hand…*

- National stockpile of **PPE**
- Electronic infrastructure for **contact tracing**
- National stash of **nasal swabs and reagents** to develop serologic and PCR testing
  - That way, the moment we know the gene sequence of a virus, we could actually deliver a million tests a day without a big delay
- *On the therapeutic side*…a huge stockpile of **immune modulating drugs** since many of these diseases have an enormous component of an overactive immune response

*-Why is this so important?*

- A few billion dollars investment into this is “*not a staggering investment when you consider what we spend on healthcare and defense*” says Peter
- It’s also a smart way to hedge against the economy getting shut down again

## Genetic drift and the potential for long-term immunity to COVID-19 [1:07:00]

**Common cold coronaviruses**

- [HCoV-229E](https://en.wikipedia.org/wiki/Human_coronavirus_229E), [HCoV-OC43](https://en.wikipedia.org/wiki/Human_coronavirus_OC43),  [HCoV NL63](https://en.wikipedia.org/wiki/Human_coronavirus_NL63) and [HCoV-HKU1](https://en.wikipedia.org/wiki/Human_coronavirus_HKU1)
- They tend to be more prevalent in the winter or early spring
- These viruses are usually happier when it’s a little cooler and a little drier

*-Why don’t we develop long-term immunity to common colds?*

- There is an antibody response to these viruses but it seems to wane after a year and and go away after a couple years
- You need a specific kind of antibody, the IgA response, but they seem to wane as well
- The T-cell response for common cold coronaviruses is minimal because common colds usually go away in a few days before you actually have a T-cell response
- Opposite example would be [smallpox](https://en.wikipedia.org/wiki/Smallpox)—if you had smallpox in 1918, you’d still have strong antibody responses in 1995
- With SARS-CoV-2, understanding this immune response/antibody process is critical to understand the ability of people to be reinfected, the response to vaccines, and the concept of herd immunity as we try to get rid of this virus—”*So really important but not known.*”

**Explaining herd immunity for SARS-2**

- [Herd immunity](https://en.wikipedia.org/wiki/Herd_immunity) refers to what percentage of the population needs to be immune to a virus in order for the virus to not be able to spread
- The higher the R\_0 of a virus, the higher the percentage of the population needs to be immune (although, it doesn’t increase linearly)
- For measles, which has a high R\_0, you need about 95% of the population to be immune to reach herd immunity
- For most common viruses, herd immunity is thought to be 60% or 70%
- For SARS CoV-2, Stanley believes it’s probably in the 60-70% range (although some think it may be lower)

**How much did these coronaviruses genetically drift?**

- The common flu has enough genetic drift every year that it requires a yearly vaccine
- So needing a yearly vaccine is less about your immune system “forgetting” and more about the change of the flu strain year to year
- In fact, most coronavirus, including SARS and MERS, and the current SARS-2, don’t change much (exception being OC43 which seems to have different variants)
- And for SARS-CoV-2… there’s **no evidence so far that says this virus has changed in a way that makes it unlikely a vaccine will work, unlikely that a previous infection will protect you from a second infection**
- There may be reasons why it won’t, but *it won’t be because the virus is changing*

> *“There’s really no evidence so far that says this virus has changed in a way that makes it unlikely a vaccine will work, unlikely that a previous infection will protect you from a second infection–there may be reasons why it won’t, but it won’t be because the virus is changing.”*

*\*Important point to reiterate:*

- The doomsday scenario would be if the virus had enough genetic drift that your immune system never recognizes it again AND it retains its lethality despite the drift
- However, the good news is that we don’t have evidence of either of those things happening

**What can we learn about immunity from studying other coronaviruses?**

⇒ See [episode with David Watkins](https://peterattiamd.com/davidwatkins/)

- When you have a mild infection, you do not develop great immunity
  - For example, with common coronaviruses, they might not even stick around long enough to develop a T-cell response
- In terms of antibodies…
  - Six months after a person has a common coronavirus, we do see evidence of IgG antibodies
  - However, they are not necessarily binding and/or neutralizing antibodies
  - Human studies for the common cold coronaviruses suggests that [neutralizing antibodies are present following infection but it wanes with time](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2271881/) and a year later it may not prevent reinfection
- Stanley’s intuition is that with COVID-19, we will see the same thing for asymptomatic people or people who have mild infections, that **they will be susceptible to reinfection a year later**

[**2020 paper in Cell**](https://www.cell.com/cell/fulltext/S0092-8674(20)30610-3)

- 20 patients who had recovered from COVID-19
- Roughly 2/3 of them actually had a CD8 T-cell response and a correlated CD4 response
- Implication being that they looked to have been **at least partially aided in their response to SARS CoV-2 from T-cells that looked like they had been sensitized by other coronaviruses**

–*Stanley brings up some important caveats*:

- Most of these papers are measuring the activation of T-cell responses but not necessarily their functionality
- Also, the targets for the T-cell response is not the usual response that you get in terms of targets like you see after the wild-type SARS-CoV-2 infection
- Stanley does admit that the findings are “*really interestin*g”
- Although, the findings actually go against what he has seen in MERS patients where we don’t see much evidence of cross-reactivity

## Prevention and treatment strategies for COVID-19 and future diseases [1:22:30]

*Do you think there are other viruses or other vaccines that could provide cross-reactivity?*

- In terms of specifically getting at the coronavirus, “*I don’t think so*” says Stanley
- There are some ideas that you should immunize everybody with a vaccine for another virus in order to boost the immune system
  - Examples:
    - The [BCG vaccine for tuberculosis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7136957/) (And there are [clinical trials](https://clinicaltrials.gov/ct2/results?cond=COVID-19&term=vaccine%2C+bcg) testing this idea)
    - The [MMR vaccine for measles is also being looked at](https://asm.org/Press-Releases/2020/MMR-Vaccine-Could-Protect-Against-the-Worst-Sympto)
- Stanley does not see any reason to believe that your memory T-cells and B-cells to measles, mumps and/or rubella would offer any some protection against this particular coronavirus

-The takeaway:

- A boosted immune system from BCG, MMR, or agents that turn on interferon might be helpful if you got that vaccine within days before you were exposed to COVID-19
- “*But I wouldn’t want to be given BCG just for fun with the* ***possibility*** *that in the next two days I get exposed to the virus.*”

**Therapeutic preparations for a future pandemic**

- We need to be more thoughtful about thinking through ways to prevent/treat this virus
- We should stop the binary thinking such as, “*Is this drug good or bad?*”
- We need a more targeted therapeutic approach
- So with COVID-19, that might look like:
  - Early treatment with an antiviral with an immune amplifier
  - Late treatment is immune modulator and respiratory support

**The need for biomarkers for different stages of disease (and how that shapes treatment**)

- Stanley suggests we need better **biomarkers for different stages of disease**
- Because with different patients in different disease courses, one has to be ready to modulate therapy
- In other words, certain therapies may only be effective when administered at a particular stage of the disease process

*How might this be done? What might those biomarkers look like?*

- Ideally, you want to be able to look in the blood for things like cytokines and metabolic products
- You’d be trying to figure out whether a person was likely to progress to severe disease or not
- We’d also want to understand a person’s physiologic age (rather than chronologic age) since, for example, a 40 year old with diabetes might be more susceptible than a 60 year old who is metabolically healthy

*We will be much better prepared in the future if we use* ***machine learning*** *to help us combine our knowledge of*:

- Existing epidemiology data available about who is more susceptible
- Consider the different physiologic age (rather than chronological age)
- Plus the timing of “when” you are getting the disease

*-In practice:*

- Ideally, you’d like to take people, sample them every couple of days put them in a machine learning model to measure different cytokines and markers to determine whether or not that person is going to progress to severe disease
- Because that person, if you saw signs of things going badly, perhaps it would warrant the use of…
  - [Remdesivir](https://en.wikipedia.org/wiki/Remdesivir), for example, to stop the virus in its tracks, or
  - An immune activator if appropriate
- But.. “*We’re not there yet in terms of thinking about which markers are best*.”

## Alternative hypothesis to the origin of SARS-CoV-2 [1:32:30]

[**Wall Street Journal article**](https://www.mattridley.co.uk/blog/where-did-the-virus-come-from/) by [Matt Ridley](https://twitter.com/mattwridley?lang=en)

- Citing this [paper by Zhan et al.](https://www.biorxiv.org/content/10.1101/2020.05.01.073262v1.full.pdf)
- The article points out that the current coronavirus is remarkably fit for humans and that it appears to be a mostly a person-to-person transmission
- It calls into question whether this virus could have actually been transmitted from an animal to a human as recent as Nov/Dec 2019
- The implication is that SARS-CoV-2 could have evolved to live in humans for a long time before it appeared on our radar in December 2019

## Determining durable immunity to COVID-19 and what a successful vaccine looks like [1:34:30]

**Key questions**:

*For the tens of millions (perhaps hundreds of millions) of people who have been infected with COVID-19, what is going to be the durability of their immunity to getting reinfection?*

- We can make progress in our understanding of this question by measuring their antibody responses and their T-cell responses
- Stanley says that the most likely answer is that **we’re going to see waning immunity with people with mild disease** (like we see for the common cold coronavirus infections)

*What will a successful vaccine look like?*

- There’s two goals for a vaccine:
  - 1—To protect the individual who’s vaccinated from getting **severe pneumonia**
    - (actually, that may occur already … people who had a mild case may not be immune to reinfection but they may be immune to an infection that gives them severe pneumonia)
  - 2—How much immunity do you need to prevent transmissibility to other people?
    - This may be the most important question, not to the individual, but to society

*In the case where SARS-CoV-2 can’t be fully eradicated, how do we coexist with this virus moving forward?*

⇒ See [Peter’s post](https://peterattiamd.com/covid-framework-how-does-this-thing-end/) trying to answer this question

- This question becomes even more relevant if vaccines are somewhat risky
- Everything is going to be a risk tradeoff and it may be that you don’t not want to vaccinate everybody with the SARS-CoV-2 vaccine if the risk is slightly higher than we deem acceptable
- This generates a situation that warrants a cost-benefit analysis

*Will herd immunity even be possible if immunity to SARS-CoV-2 goes away after a year?*

- That’s really the key question, says Stanley
- One possibility is that you may see an ability to get reinfected but the reinfection will only produce a common cold and no pneumonia (but that would require a mutation that may not be likely)
- And furthermore, for those hypothetical people who are reinfected, what is their level of shedding (i.e., transmissibility)?
- The simplest study would be to take some human volunteers, give them a common cold coronavirus and then a year later come back reintroduce the same virus and see if:
  - i) do they get a cold? And
  - ii) How much shedding do they have?

§

## Selected Links / Related Material

**Episode of The Drive with David Watkins**: [#115 – David Watkins, Ph.D.: A masterclass in immunology, monoclonal antibodies, and vaccine strategies for COVID-19](https://peterattiamd.com/davidwatkins/) | Peter Attia (peterattiamd.com) [1:30, 24:45, 1:15:45]

**Discovery of corona virus in chickens in 1930s and people were identified with viruses that caused the common cold that had the same appearance as the infectious bronchitis in 1960**: [History and Recent Advances in Coronavirus Discovery](https://pubmed.ncbi.nlm.nih.gov/16378050/) (Kahn & McIntosh, 2005) [17:15]

**SARS-CoV-2, the cause of COVID-19, can infect animals**: [18:30]

- [Questions and Answers on COVID-19](https://www.oie.int/en/scientific-expertise/specific-information-and-recommendations/questions-and-answers-on-2019novel-coronavirus/) | (oie.int)
- [Bronx Zoo Tiger Is Sick With the Coronavirus](https://www.nytimes.com/2020/04/06/nyregion/bronx-zoo-tiger-coronavirus.html) | Joseph Goldstein (nytimes.com)

**Earliest coronaviruses discovered (mostly common colds)**: [23:45]

- [HCoV-229E](https://en.wikipedia.org/wiki/Human_coronavirus_229E) | (wikipedia.org)
- [HCoV-OC43](https://en.wikipedia.org/wiki/Human_coronavirus_OC43) | (wikipedia.org)
- [HCoV NL63](https://en.wikipedia.org/wiki/Human_coronavirus_NL63) | (wikipedia.org)
- [HCoV-HKU1](https://en.wikipedia.org/wiki/Human_coronavirus_HKU1)  | (wikipedia.org)

**A mild infection may results in a more transient immune response**: [COVID-19 and Postinfection Immunity Limited Evidence, Many Remaining Questions](https://jamanetwork.com/journals/jama/fullarticle/2766097) (Kirkcaldy et al., 2020) [24:15]

**Physician who is considered “Patient Zero” of SARS**: [Inside the hospital where Patient Zero was infected](https://www.scmp.com/article/410652/inside-hospital-where-patient-zero-was-infected) | SCMP Reporter (scmp.com) [30:30]

**Measles has an approx. R\_0 of 15**: [The basic reproduction number (R0) of measles: a systematic review](https://www.thelancet.com/journals/laninf/article/PIIS1473-3099(17)30307-9/fulltext) (Guerra et al., 2017) [32:00]

**The epidemic flu in 1918**: [Spanish flu](https://en.wikipedia.org/wiki/Spanish_flu) | (wikipedia.org) [48:15]

**Bill Gates’s 2015 TED Talk**: [Bill Gates: The next outbreak? We’re not ready](https://www.ted.com/talks/bill_gates_the_next_outbreak_we_re_not_ready?language=dz) | (ted.com) [57:45]

**For the common cold coronaviruses, neutralizing antibodies wane over time allowing for reinfection**: [The time course of the immune response to experimental coronavirus infection of man.](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2271881/) (Callow et al., 1990) [1:16:45]

**2020 Cell paper looking at 20 patients who recovered from COVID-19 to see if previous exposure to coronaviruses helped their immune response**: [Targets of T Cell Responses to SARS-CoV-2 Coronavirus in Humans with COVID-19 Disease and Unexposed Individuals](https://www.cell.com/cell/fulltext/S0092-8674(20)30610-3) (Grifoni et al., 2020) [1:17:00]

**Some think perhaps the BCG vaccine for tuberculosis could provide protection from COVID-19 via a boosted immune system**: [Is Global BCG Vaccination Coverage Relevant To The Progression Of SARS-CoV-2 Pandemic?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7136957/) [1:22:30]

- There are clinical trials testing this idea: [clinicaltrials.gov](https://clinicaltrials.gov/ct2/results?cond=COVID-19&term=vaccine%2C+bcg)

**Some think the MMR vaccine for measles could protect against the worst symptoms of COVID-19**: [MMR Vaccine Could Protect Against the Worst Symptoms of COVID-19](https://asm.org/Press-Releases/2020/MMR-Vaccine-Could-Protect-Against-the-Worst-Sympto) | (asm.org) [1:23:00]

**The Wall Street Journal that highlighted a possible alternative origin of SARS-CoV-2**: [SO WHERE DID THE VIRUS COME FROM?](https://www.mattridley.co.uk/blog/where-did-the-virus-come-from/) | Matt Ridley (mattridley.co.uk) [1:33:00]

**Paper cited in the WSJ article**: [SARS-CoV-2 is well adapted for humans. What does this mean for re-emergence?](https://www.biorxiv.org/content/10.1101/2020.05.01.073262v1.full.pdf) (Zhan et al., 2020) [1:33:00]

**Peter’s recent post trying to answer questions posed from his young son about the future of COVID-19 especially if it can’t be eradicated**: [COVID framework: How does this thing end?](https://peterattiamd.com/covid-framework-how-does-this-thing-end/) | Peter Attia (peterattiamd.com) [1:36:15]

§

## People Mentioned

- [David Watkins](https://peterattiamd.com/davidwatkins/) [1:30, 24:45, 1:15:45, 1:40:15]
- [T. Berry Brazelton](https://en.wikipedia.org/wiki/T._Berry_Brazelton) [7:15]
- [Bill Gates](https://en.wikipedia.org/wiki/Bill_Gates) [57:45, 1:05:30]
- [Matt Ridley](https://twitter.com/mattwridley?lang=en) [1:33:00]
- [Shing Hei Zhan](https://twitter.com/shingheizhan?lang=en) [1:33:00]

§

![](https://peterattiamd.com/wp-content/uploads/2020/06/bio-pic.jpeg)

##### Stanley Perlman, M.D., Ph.D.

Stanley is a professor of microbiology and immunology along with being a professor of pediatrics and the chair of virology at the University of Iowa. Stanley has researched coronaviruses for nearly four decades and his lab is currently using mouse models for SARS-CoV-1 and SARS-CoV-2, to better understand the more severe diseases that affect humans. [full bio at [medicine.uiowa.edu](https://medicine.uiowa.edu/microbiology/profile/stanley-perlman)]