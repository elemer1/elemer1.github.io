# #126 – Matthew Walker, Ph.D.: Sleep and immune function, chronotypes, hygiene tips, and addressing questions about his book

**Source:** [https://peterattiamd.com/matthewwalker4/](https://peterattiamd.com/matthewwalker4/)

---

##### Check out more content with sleep expert, Matthew Walker, Ph.D.:

- *(April 1, 2019)* [Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, and memory](/matthewwalker1/)
- *(April 8, 2019)* [Part II of III: Heart disease, cancer, sexual function, and sleep disruption](/matthewwalker2/)
- *(April 15, 2019)* [Part III of III: The penetrating effects of poor sleep from metabolism to genetics](/matthewwalker3/)
- *(June 17, 2019)* [AMA #1: Strategies for sleeping more and sleeping better](/matthewwalkerama/)
- *(October 28, 2019)* [AMA #2: short sleep mutants, optimal sleep environment, & sleep apnea](/matthewwalkerama2/)
- *(August 31, 2020)* [Sleep & Covid-19: Sleep and immune function, chronotypes, and hygiene tips](/matthewwalker4/)
- *(September 7, 2020)* [AMA #3: Fasting, gut health, blue light, caffeine, REM sleep, and more](/matthewwalkerama3/)

In this episode, sleep expert Matthew Walker returns by popular demand to dive deeper into many sleep-related topics, starting with what we’ve learned about sleep through the lens of the COVID-19 pandemic and how sleep impacts the immune system. He then covers topics such as how dreaming affects emotional health, the different sleep chronotypes, the best sleep hygiene tips, and the pros and cons of napping. Matthew finishes by addressing several of the errors that readers have pointed out in his book, Why We Sleep.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/matthewwalker4/the_Drive_public.png)

Play

#126 – Matthew Walker, Ph.D.: Sleep and immune function, chronotypes, hygiene tips, and addressing questions about his book

#126 – Matthew Walker, Ph.D.: Sleep and immune function, chronotypes, hygiene tips, and addressing questions about his book

1x15s30s

0:001:41:53

## We discuss:

- Three ways that the coronavirus pandemic has impacted sleep [3:30];
- The importance of dreaming for emotional health, and how the coronavirus pandemic has increased dreaming [11:45];
- The impact of alcohol consumption on sleep quality and stress levels [20:00];
- Sleep’s impact on the immune system, and implications for a future COVID-19 vaccine [27:45];
- What determines how much deep sleep and REM sleep you need? [36:30];
- Pros and cons of napping, and insights from the sleep habits of hunter-gatherer tribes [42:15];
- Sleep hygiene, wind-down routine, and tips for better sleep [56:45];
- Understanding sleep chronotypes and how knowing yours could help you [1:06:00];
- Night terrors in kids—what they are and why they happen [1:16:30];
- Addressing errors found in Matt’s book, Why We Sleep [1:20:45]; and
- More.

§

## Show Notes

## Three ways that the coronavirus pandemic has impacted sleep [3:30]

**The COVID-19 pandemic has impacted sleep in 3 ways**:

1. The amount that people are sleeping
2. The timing of the sleep
3. Dreaming

**1—Amount of sleep**:

A sleep tracking company that released [data on ~68,000 individuals](https://www.cnbc.com/2020/03/27/evidation-pulse-study-moving-less-sleeping-more-quarantine.html)

- They found total sleep time had increased across the entire country by ~20%

Two peer-reviewed [papers from Current Biology](https://medicalxpress.com/news/2020-06-covid-states-europe.html) added more nuance—

  1-Total amount of [sleep had increased by 15 minutes](https://www.cell.com/current-biology/fulltext/S0960-9822(20)30837-X?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS096098222030837X%3Fshowall%3Dtrue)

  2-[Social “jet lag” had decreased](https://www.cell.com/current-biology/fulltext/S0960-9822(20)30837-X?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS096098222030837X%3Fshowall%3Dtrue)

- Meaning, the difference between the sleep that you’re getting during the week versus the weekend
- Many people are sleeping less due to obligations during the week (getting kids to school, being at work on time, getting home late after a long commute, etc.)
- And then they sleep more on the weekends to “make up” for the lost sleep
- Since COVID-19 began, people are sleeping more during the week without those same week-day obligations and their “sleep opportunity” has increased

  3-Subjective [sleep quality had **decreased**](https://www.cell.com/current-biology/fulltext/S0960-9822(20)30837-X?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS096098222030837X%3Fshowall%3Dtrue) in a subset of people

*What Matt thinks is probably happening across the country*:

- There’s going to be at least two different clouds of data
  - i) people for whom sleep time AND quality both increased, and
  - ii) people for whom sleep became shorter and worse
    - *Why?* ⇒ They’ve either lost their job, may lose their job, or just in general they have a great deal of anxiety because of COVID.

**2—Timing of sleep**:

- This [study](https://www.cell.com/current-biology/fulltext/S0960-9822(20)30838-1?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS0960982220308381%3Fshowall%3Dtrue) showed people were going to bed about 30 minutes later and waking up about 50 minutes later the next morning
- Matt says “*night owls are being allowed to be much more owl-like and sleeping in harmony with their chronotype.*”

**3—Dreaming**: People have been reporting having more dreams since the pandemic began

(more on this in the following section)

## The importance of dreaming for emotional health, and how the coronavirus pandemic has increased dreaming [11:45]

***How has dreaming been impacted by the coronavirus pandemic?***

- Dreaming has increased
- Two different reasons—
  - 1) Timing of sleep, and maybe we can, at some point, go over the standard sleep schedule.
  - 2) Dreaming allows for the purging negative emotion or stress

*Two principle types of sleep—*

  1 | Non rapid eye movement sleep (non-REM sleep)

- Non-REM is then further subdivided into four separate stages
- Stage 1 and 2 are typically classified as “light” non-REM sleep
- Stage 3 and 4 are the “deep sleep” stage of non-REM sleep

  2 | Rapid eye movement sleep (REM sleep)

- REM sleep is typically associated with dreaming
- These are the dreams we think of as narrative-based, emotionally-filled, bizarre, hallucinogenic, dreams

*The 90 min cycle*

- non-REM and REM play out in this “beautiful battle for brain domination” throughout the night
- Every 90 minutes the battle is repeated to create the standard cycling 90-minute architecture
- The ratio of non-REM to REM within each 90-minute cycle changes as we move across the night
- In the first half of the night, the majority of those 90-minute cycles are going to be comprised of a lot of deep non-REM sleep (stages 3 and 4) and very little REM sleep
- In the second half of the night, the majority of those 90-minute cycles are comprised REM sleep

![](https://peterattiamd.com/wp-content/uploads/2019/03/architecture-of-sleep-1024x423.png)

**Figure 1. The architecture of sleep.** Image credit: [Episode #47 – Matthew Walker on sleep – Part I](https://peterattiamd.com/matthewwalker1/)

***So how has the coronavirus pandemic increased dreaming?***

Reason #1: People are sleeping in a little bit later into the morning

- If people are now, on average, going to bed a little bit later, and sleeping in significantly later in the morning…
- It means that they’re now **sleeping further into that REM sleep rich window** of the night

Reason #2: Dreaming is a way that we purge negative emotion or stress in some way

- One of the principle functions of rapid eye movement sleep that we now have understood is that it seems to provide a form of overnight therapy
- REM sleep tries to take the sharp edges off difficult experiences so that when you come back the next day without feeling as emotional as you did about those events the day before

> “REM sleep is emotional first aid. . .In other words, it’s not time that heals all wounds. It’s actually time during REM sleep and dreaming that provides this emotional convalescence.”

\*Interesting factoid about sleep:

- Sleep is responsive—it’s what we call homeostatically regulated, but also homeostatically reflexive
- So if something happens during the day that requires more of a specific stage of sleep, then sleep will respond by giving the brain a little bit more of that sleep to deal with it

⇒ Example—Learning and memory

- Matt has some *unpublished* data showing that after 3-4 hours of really intensive textbook learning you see an increase amount of the specific type of sleep that’s needed for the fixation of those memories
- And if one does a skill-learning task, like a specific sport, you will see a homeostatic response from sleep the following night to try and lock in those new skill memories

Same goes for **emotional experiences**—If you’ve upped your quotient of emotionally difficult experiences, sleep can respond with greater amounts of REM sleep (dream sleep) to try to help solve those emotional challenges

## The impact of alcohol consumption on sleep quality and stress levels [20:00]

Peter has found himself consuming more alcohol during the pandemic – he thinks it’s probably stress related

- Using his [Oura ring](https://ouraring.com/), Peter can clearly see that he sleep quality suffers if he has more than one drink too close to bedtime
  - Heart rate variability gets crushed
  - Resting heart rate goes up by 10-25%
  - Respiratory rate is up two breaths per minute, and
  - Core body temperature is up half a degree
- For peter, this is concerning enough on it’s own
- However, you now couple that with the fact that how alcohol disproportionately negatively impacts REM sleep (see previous episode of The Drive—[Matt Walker, Part 3](https://peterattiamd.com/matthewwalker3/))
- This creates an ironic situation, says Peter, “*I’m probably numbing a little bit of my anxiety with alcohol, which is impairing my ability to have REM sleep, which is paradoxically exactly the medicine I need*.”

**How alcohol disrupts sleep**:

1—Alcohol is a sedative—You actually “lose consciousness” faster when you put yourself in bed, but you’re not going into naturalistic sleep

2—Your [sleep becomes more fragmented](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2775419/) because the alcohol will actually stimulate the fight or flight branch of the nervous system which are wake promoting chemicals making you wake up more frequently throughout the night

3—Alcohol will [decrease the amount of REM sleep](https://www.ncbi.nlm.nih.gov/pubmed/23347102) that you get

*A self-fulfilling prophecy*:

- If you’re downscaling the amount of REM sleep that you get at night with alcohol, you may not be getting the necessary emotional benefit that you need to de-risk the emotional experiences and the anxiety that’s building up
- Then the next night you find yourself reaching for another glass of wine because of the increased stress from not enough REM sleep which then takes away the REM sleep once again

**Genetic difference in people in terms of how alcohol affects sleep**

- Alcohol impacts people differently
- Peter has made the observation in his patients that people are not all identical in how alcohol impacts their sleep
- For some, the true release of stress from a drink or two might outweigh any potential impact on sleep
- Matthew confirms this observation — if you do some of the genetic testing you can see that some people are fast metabolizers of alcohol (same with caffeine)
- And in those fast-metabolizers, by the time their brain is ready for REM sleep, the metabolic consequences of alcohol degradation—the aldehydes and ketones—are no longer present
- Of course, there are also people who have one drink at 3pm and it “crushes” their REM sleep

## Sleep’s impact on the immune system, and implications for a future COVID-19 vaccine [27:45]

We know that sleep improves immune function, *but have we learned anything new with respect to COVID?*

- Matt says that we don’t have any direct data yet regarding how a lack of sleep impacts your vulnerability to COVID, or if you are infected, the severity of progression

*What we do know*: There is a very intimate association between your sleep health and your immune health

- This [classic study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2629403/) showed that individuals getting less than seven hours of sleep a night are almost three times more likely to become infected by the rhinovirus (common cold)
- A [large prospective study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3242694/) of over 50,000 women found that women who were sleeping 5 hours or less were 70% more likely to develop pneumonia (a component risk in the equation of COVID)
- [Mouse study](https://www.academia.edu/18150148/Paradoxical_sleep_deprivation_impairs_mouse_survival_after_infection_with_malaria_parasites) suggesting a **causal relationship**: When mice are selectively deprived mice of various stages of sleep (particularly REM sleep) and exposed to malaria, they were far more likely to die as a consequence compared to the well-rested mice
- A [study](https://pubmed.ncbi.nlm.nih.gov/12243633/) looking at response to flu vaccines found that not getting sufficient sleep in the week before you get your flu shot resulted in producing **less than 50% of the normal antibody response** therefore rendering that flu vaccination significantly less effective

**![](https://peterattiamd.com/wp-content/uploads/2020/08/sleep-and-immunization-1024x402.png)**

**Figure 2. Sleep deprived subjects had less than 50% of the antibody titers in response to the flu vaccines compared to well-rested controls after 10 days.** Image credit: [Spiegel et al., 2002](https://pubmed.ncbi.nlm.nih.gov/12243633/)

*\*Matt’s point*: We do need to be *prospectively* looking at this when the COVID-19 vaccine comes out by tracking sleep—if your sleep in the days before you get your COVID vaccination determines whether or not it’s successful, we should know that and we should be smart about it

**Peter’s take on the COVID vaccine situation**:

- A vaccine is going to take a little longer than most people think
- It’s probably not going to be quite as safe as we think
- And some of the vaccines, potentially the really efficacious ones, may come with side effects that are undesirable
- Lastly, it might be years before we have enough vaccines available to cover all 300+ million US citizens

\**Peter’s main point*: If sleep could increase the efficacy of that vaccination by 50% (like sleep seems to due for flu vaccines) we should be very focused on that

- Peter is hopeful that in the many phase 2 studies looking at coronavirus vaccines that someone will do a subgroup analysis on things like,
  - How many soluble antibodies are you getting?
  - What type of T cell response are you getting?
  - And can we at least retrospectively look at the sleep quality going into that, if not prospectively?
    - It’s very simple to do using sleep trackers (or even just paper and pencil)

## What determines how much deep sleep and REM sleep you need? [36:30]

**Some nuance regarding the 90-minute cycle**:

- For the **average** adult, one sleep cycle seems to be about 90 minutes
- For some people it’s shorter, for some people it’s longer
- Scientists actually don’t really understand what determines the length of your sleep cycle
- But generally, the larger your brain mass relative to the rest of you, the longer your sleep schedule
- That said, scientist have no idea *why* sleep plays out in this 90 minute cycle

**What determines how much deep sleep and REM sleep you will need/get?**

- For deep, non-REM sleep—
  - How much deep sleep you need/get is determined by **how long you’ve been awake** and only *a little bit* on the basis of your circadian rhythm
  - How long you’ve been away is much more deterministic of i) how much deep sleep and ii) how deep that deep sleep is going to be
- REM sleep—
  - REM sleep is much more powerfully determined by the circadian time of night and is less determined by how long you’ve been awake
- NOTE: We still don’t understand the evolutionary functional reasons as to why Mother Nature drives it in that way

*What is the role of* ***melatonin, cortisol, and adenosine*** *in how much* ***deep sleep*** *you need?*

- *Little bit* of a function of the accumulation of melatonin
- *Somewhat* a function of how much cortisol you’ve managed to suppress
- *Very much* a function of the accumulation of adenosine

*Adenosine—*

- Adenosine is a chemical that starts building up in your brain the moment you wake up
- And the longer the amount of clock time that your brain has been awake, the more adenosine builds up
- This produces what we call “sleep pressure”
- That pressure, or sleepiness, is the weight of that chemical pressure of adenosine

## Pros and cons of napping, and insights from the sleep habits of hunter-gatherer tribes [42:15]

**Pros and cons of napping**

- Naps as short as 17 minutes can produce learning and memory benefits *(unpublished data from Matt)*
- And you can some benefit from a cardiovascular standpoint as well *(unpublished data from Matt)*
- Downside of naps is that it can take away which is sleep pressure which could exacerbate nighttime sleep issues

**So who should consider napping?**

- If you are struggling with falling asleep at night (sleep onset insomnia), **avoid naps** during the day
- You want to build up as much sleep pressure/sleepiness as you possibly can during the day

\*Advice for insomnia patients:

- For patients with insomnia, there is something called [sleep restriction therapy](https://en.wikipedia.org/wiki/Cognitive_behavioral_therapy_for_insomnia#Sleep_restriction_therapy) (part of [CBT-I](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4694188/))
- You should go to bed even later at night in order to elongate the amount of wakefulness to build up an even greater sleep pressure than normal
- As a consequence, you may only have a six-hour sleep window, but that six hours may be a very constant, solid sleep
- That 6 hours of consistent, solid sleep is better than lying in bed for eight hours and tossing and turning for two of them

> “*Quality of sleep matters just as much as quantity of sleep*.”

**In summary**:

- Avoid napping if you have trouble falling asleep at night
- On the flip side, if you are not struggling with your sleep at night, there’s no problem with napping regularly during the day

**Looking at** [**biphasic sleep**](https://en.wikipedia.org/wiki/Biphasic_and_polyphasic_sleep) **by hunter-gatherers**

- If you study hunter-gatherer tribes (whose way of life hasn’t changed for thousands of years), they don’t necessarily sleep the way that we do today
- During the summer months, they will typically have an afternoon nap
- This make sense because when you study human brains you see that somewhere between about 2:00 to 4:00 PM we have a drop in physiological alertness
- As a species, we’re almost pre-programmed to have this enforced dip in our alertness suggesting maybe we should be biphasically sleeping (as opposed to monophasically sleeping) at certain times during the year

*How long is the afternoon nap by the hunter-gatherers?*

- Typically pretty short, says Matt, less than 90 minutes
- Hunter gatherers would typically sleep just six-and-a-half hours at night, and then they would make the rest up with an afternoon nap (which matches most sleep experts recommendation that we get 7-9 hours per night)

*Is this like the “first and second sleep” of the Dickensian era?*

- No, this is very different to something else that’s been described in the literature, which is “***first sleep and second sleep***”, documented during the [Dickensian era](https://en.wikipedia.org/wiki/Charles_Dickens)
- People would sleep for the first four hours—then they would wake up in the middle of the night to write, drink, socialize, etc.—then they would go back for another four hours of sleep.
- Overall, that sleep pattern was more sociologically-driven rather than biologically-driven.

*Other interesting things about hunter-gatherers*:

1. **The concept of midnight**—it’s the middle of the night for them, i.e., “mid”-night because they usually go to bed around 8:30-9pm and then they’re awake just a little bit before dawn
2. **Temperature (not daylight) wakes them up**—A rise in temperature seems to happen before daylight starts to break and it seems the regulation of their sleep-wake rhythm is more tied to temp.

**Comparing humans to primates**

- It makes sense that primates have less REM sleep because they sleep in trees
- They can’t afford a lot of the loss of muscle tone that comes with REM sleep otherwise they might fall out of the trees
- Once we became safe on the ground, we could afford more REM sleep and the benefits that it provides

> “When we became safe on the ground from a sheer Newtonian physics’ standpoint, then all of a sudden REM sleep blossomed and with it, I think a whole constellation of new benefits for the hominid species.”

## Sleep hygiene, wind-down routine, and tips for better sleep [56:45]

**Five main sleep hygiene tips:**

1. **Regularity**: Going to bed at the same time, waking up at the same time.
2. **Light**: Getting lots of darkness at night because we are a dark-deprived society (and making sure you get daylight during the first half of the day)
3. **Temperature**: You need to get cool to get to sleep
4. **“Walk it out”**: Don’t lie awake in bed because trains your brain to be triggered by your bed and force you awake because you have a learned association (TIP: If you’ve been awake for 20 minutes, then get up, go and do something else and only come back to bed when you’re sleepy)
5. **Alcohol/caffeine**: Avoid alcohol and caffeine too close to bedtime

> “Sleep is much more like trying to land a plane. It takes time to gradually descend down onto that hard foundation of this thing that we call a stable night of sleep.”

**Additional advice for optimizing sleep:**

*1—Wind-down routine*

- This is absolutely critical to build it into your routine, says Matt
- Many people in society expect sleep to be like a light switch — it’s just not like that
- A routine might be 15 minutes for some, others it’s 30 minutes
- Things like light stretches, meditation, putting all of your phones and your gadgets away can be apart of the routine

*2—Remove clock faces*

- If you are struggling with sleep, remove all clock faces from your bedroom
- Knowing that it’s now 2:35 AM in the morning is only going to trigger more anxiety
- This [study](https://pubmed.ncbi.nlm.nih.gov/16793001/) from UC Berkeley by Allison Harvey showed that removing clock faces was helpful for poor sleepers with insomnia

*3—Remove technology from the bedroom*

- Technology (esp. phones) can cause “*anticipatory anxiety*”
  - Don’t make checking your phone (e.g., emails, texts, etc.) the first thing you do in the morning
  - This trains your brain in a “Pavlovian way” that even as your tucking yourself in bed at night to expect that anxiety waiting for you on your side table
  - This “anticipatory anxiety” actually lightens your sleep throughout the night because of that expectation
- Technology can result in “sleep procrastination”
  - Example would be scrolling through your phone looking for that next interesting thing and procrastinating the process of putting your mind to rest
  - Tip from Matt’s colleague, [Michael Grandner](https://www.michaelgrandner.com/about.html): **If you’re going to have your phone in your bedroom, make it a rule that you can only use it if you’re standing up. After 5-10 minutes of standing you just think, “God, I just want to sit down. I just want to get into bed.”**

*4—Set manageable goals*

- Matt references BJ Fogg, a researcher at Stanford, who looks at behavioral change and applies it to sleep—
  - If you are accustomed to checking your phone the moment you wake up, try to start by giving yourself five minutes without checking it
  - Next, keep pushing it longer and longer (10 min, 20 min, and so on)
  - Don’t set yourself up for failure, ease into it and set yourself up for success

\*Important Note: These tips are for improving your sleep performance, and are for people without a sleep disorder. If you do have an actual sleep disorder (insomnia, apnea, etc.) you need to get help from a physician.

## Understanding sleep chronotypes and how knowing yours could help you [1:06:00]

**Determining and understanding sleep chronotype**

Your sleep chronotype simply means—

- Are you a morning person? (25-30% of the population)
- Are you an evening person? (25-30% of the population)
- Or are you somewhere in between? (the rest of us 40-50%)

*Sleep science breaks it into 4 categories*:

1. Extreme morning types
2. Morning types
3. Middle evening types
4. Extreme evening types

**Genetic-component of sleep chronotypes**

Evidence that it’s genetic:

- 1-There is a significant degree of heritability
- 2-There are a collection of genes that will determine, to a degree, your chronotype

*Genes that determine your chronotype*:

- Data from [23andMe](https://blog.23andme.com/23andme-research/the-genetics-of-being-a-morning-person/) says there’s about 9 different genes that will contribute to your chronotype
- These genes are what we call “clock genes”—This refers to the fact that these genes control the rhythm of your circadian cycle
- These genes control WHEN that sinusoidal wave of your circadian cycle arrives on the clock face
- Said another way, if you have a certain type of gene compliment that makes you a morning type, your peak alertness is going to arrive **earlier in the day** and the **downstroke of your circadian rhythm will arrive earlier in the evening**.
- In other words, your circadian rhythm looks very similar in its sinusoidal pattern but WHEN the **peak** and the **trough** of that circadian rhythm arrive on the 24 hour clock face is very different to a morning type compared to an evening type

**Evolution of the sleep-wake cycle over your lifetime**

- No matter what chronotype you are, you will change as you develop from a young child to an adolescent teen, to an adult, to an older adult
- More of a morning type when you’re a kid
- A teen’s chronotype makes your bedtime later and your wake time later in the morning (sleeping more in tota)
- Note: This is a problem for early school start times
- Once you become an adult, bedtime becomes a little earlier
- As we get older, we tend to go to bed earlier and earlier (with earlier wake times)

**Your innate chronotype can still be twisted/contorted by non-genetic forces**

- Examples—modern social norms, light exposure, technology, etc.)
- Interesting experiment: [A camping study during Winter](https://pubmed.ncbi.nlm.nih.gov/28162893/)
  - At the end of the week, their melatonin levels began to rise 2.6 hours earlier
  - Going to be much earlier (more than two hours)
  - But they did NOT wake earlier
  - As a result, they got 2.3 hours more sleep (~9 hr was the median)
  - NOTE: This may not be realistic to normal life
  - And if you do the same in experiment in Summer you don’t get as dramatic an effect b/c of so much sun (almost like solstice effect in scandinavia)

**How to determine your sleep chronotype**:

- Paid genetic test like [23andMe](https://www.23andme.com/)
- Free online survey: [MEQ test](https://www.sleephealthfoundation.org.au/pdfs/World%20Sleep%20Day/Activity%20-%20Morning-Eveningness%20Questionnaire.pdf) – Decent approximation (concordance) with genetic tests

**How knowing your chronotype could benefit you**:

- Life gets in the way of your ideal sleep times
- (Think parents with young kids, college kids who stay up late simply because that’s the norm for your peers, teens having to wake up early for school)

*With that said, how would knowing your sleep chronotype provide a benefit?*

1—It would explain a lot about why you might struggle so much where other people seem to be just these energizer bunnies

2—Realizing that you’re not culpable, it’s not your fault

- E.g., A lot of night owls have gone throughout life being chastised
- Matt says society really needs to be much more understanding and then also modify how we do things in response

3—It can sometimes explain incorrectly diagnosed insomnia

> “When you fight biology, you normally lose. The way you know you’ve lost is often through disease and sickness.”

## Night terrors in kids—what they are and why they happen [1:16:30]

**Sleep terrors—what are they are and when they happen**

- Night terrors are typically where people (mostly kids) wake up with a terrible sense of dread and fear (the child is often inconsolable at that stage)
- Many parents report that young children seem to get [sleep terrors](https://www.mayoclinic.org/diseases-conditions/sleep-terrors/symptoms-causes/syc-20353524) (aka night terrors) when they are overly exhausted compared to when they are well-rested
- The night terror events seem to happen during deep **non-REM sleep** (i.e., dreamless sleep) rather than during REM sleep (which might explain why the child rarely remembers anything)
- When a child spends an extended time being awake or miss a nap (i.e., they are exhausted), they will typically then have a homeostatic increase in the amount of deep sleep
- So they’re probably going to go into deep non-REM sleep in a more intense fashion or with greater amounts of deep sleep duration
- This therefore means that the probabilistic likelihood of them having one of these night terrors is increased as a consequence

**Recommended pediatric sleep doctors**:

1-[Dr. Craig Canapari](https://drcraigcanapari.com/about/)—the Director of Pediatric Sleep at Yale Medical School.

- He’s written a [great book](https://drcraigcanapari.com/itsnevertoolatetosleeptrain) that parents can read about sleep and infants and children
- He’s got a [fantastic website](https://drcraigcanapari.com/) with tons of resources

2-[Jodi Mindell, PhD](https://www.babysleep.com/sleep-experts/jodi-a-mindell/)—the “godmother” of child and infant sleep

## Addressing errors found in Matt’s book, Why We Sleep [1:20:45]

- Matthew has just about completed a second addition to his bestselling book, Why We Sleep
- In this edition, Matthew is addressing some of the errors that made it into his book
- Matt has identified about 13 errors in the book that required correction
- For context, the book contains over 1,000 facts

For those who don’t want to wait for the 2nd edition of the book, Matt has written a [blog post](https://sleepdiplomat.wordpress.com/#cancer) describing all the errors and misinterpretations in the book along with a collection of detailed scientific literature

**The following are some of the mistakes Matthew addressed**:

1 | Regarding the association between sleep and cardiovascular disease

- The book stated that a study looked at over half a million individuals, but in fact it was actually 474,684 individuals (so less than half a million)

2 | Regarding the relationship between short sleep and cancer risk

- In the opening introduction of the book, Matt stated that short sleep can double your risk of cancer
- To clarify, Matt says short sleep does not double your risk of **all** forms of cancer
- Short sleep is associated with a [doubling of a risk of specific forms of cancer](https://sleepdiplomat.wordpress.com/#cancer), such as ovarian cancer or lung cancer

3 | Regarding the relationship between sleep deprivation and depression

- In a subset of patients with depression, if we deprive them of sleep for one night, we get this really interesting **paradoxical antidepressant benefit** where it helps them
- In fact, Matt has gone on to do [MRI studies](https://pubmed.ncbi.nlm.nih.gov/21430147/) where we’ve tried to understand what is going on in the brain to produce this paradoxical antidepressant benefit
- The issue in the book is that Matthew stated that somewhere between 30 to 40% of patients with depression will respond to sleep deprivation
- But since the book was published, there’s been a [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/28937707/) that’s now shown that it’s not 30 to 40%, but rather 45%

4 | Regarding the relationship between sleep loss and cardiovascular disease

- The book spoke about a study in over 4,000 individuals looking at cardiovascular disease
- But in the study, it was only a subset of those patients, 2,282, that were analyzed for that analysis Matt described

5 | Regarding the relationship between sleep loss/short sleep and cardiac arrests

- Matt stated short sleep was associated with an increased risk of cardiac arrests
- But in the paper, they were reporting the increase in cardiac events, not cardiac arrests
- So in addition to heart attacks, it also included other things like angina pectoris that required coronary bypass

6 | Regarding the relationship between long sleep and mortality risk

- Backstory—
  - One of the things that is clear in the literature is that there is not a LINEAR relationship between sleep and mortality risk
  - So it’s not that the more and more sleep you get the lower your mortality risk
  - That is true up to a point, but once you get to nine hours and beyond, your mortality risk stops going down and actually starts to go up
  - This has led to the misinterpretation that long sleep is bad for you and that it’s associated with a faster death
- Matt’s interpretation in the book—
  - The problem with the large epidemiological studies is that they had not measured all of the different disease outcomes in those studies
  - So when we get sick, the main thing that we want to do is curl up in bed and go to sleep.
  - Why?
  - It comes back to sleep and immune health because when you are sick, you release a whole collection of immune factors, particularly the cytokines that are sleep inducing
  - In other words, these patients were trying to “sleep themselves well” but whatever disease that they had was still too powerful and they still died
  - This artificially looked like long sleep was associated with a quicker death when in fact it could have been that long sleep was the thing that was desperately trying to save them, but failing in the end
  - In the book, that was the interpretation at the time, which Matt still believes to be true
- There is now a **second interpretation** that’s since come into the picture—
  - The second way to think about this is that long sleep is also associated with poor quality sleep
  - Poor quality sleep, independent of length of sleep, is itself associated with mortality risk
  - In other words, the lower and lower the quality of your sleep, the higher your risk of death
  - It’s also true that when people are not sleeping well, they typically try to stay in bed longer to try and get more sleep because the quality of their sleep is so bad
  - In this scenario, what’s happening is that poor quality of sleep is masquerading as long sleep, which is associated with higher risk of death
  - So it’s not really long sleep that’s the problem, it’s the poor quality of sleep that’s happening which results in people trying to stay in bed longer because they are still tired

7 | Regarding the claim that the WHO classified any form of nighttime shift work as a probable carcinogen

- Matt says that this is actually true, that the World Health Organization had [classified any form of nighttime shift work as a probable carcinogen](https://pubmed.ncbi.nlm.nih.gov/19271347/) (and confirmed that claim in a [2019 report](https://pubmed.ncbi.nlm.nih.gov/31281097/))
- Fact checkers pointed out that is was actually the International Agency for Research on Cancer, the IARC, that made that statement and not the WHO
- HOWEVER the IARC is actually part of the WHO, so Matt chalks this “error” up as a lack of clarity in his writing

§

## Selected Links / Related Material

**The 3-part podcast episode series with Matt Walker**:

- Part 1: [#47 – Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, memory consolidation, and more](https://peterattiamd.com/matthewwalker1/)
- Part 2: [#48 – Matthew Walker, Ph.D., on sleep – Part II of III: Heart disease, cancer, sexual function, and the causes of sleep disruption (and tips to correct it)](https://peterattiamd.com/matthewwalker2/)
- Part 3: [#49 – Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep](https://peterattiamd.com/matthewwalker3/)

**Two previous Ask Me Anything episodes with Matthew**: [0:45]

- [#58 – AMA with sleep expert, Matthew Walker, Ph.D.: Strategies for sleeping more, sleeping better, and avoiding things that are disrupting sleep](https://peterattiamd.com/matthewwalkerama/)
- [#77 – AMA #2 with sleep expert, Matthew Walker, Ph.D.: short sleep mutants, optimal sleep environment, sleep apnea, & rapid fire questions](https://peterattiamd.com/matthewwalkerama2/)

**Matthew’s bestselling book**: [Why We Sleep: Unlocking the Power of Sleep and Dreams](https://www.amazon.com/Why-We-Sleep-Unlocking-Dreams/dp/1501144316) by Matthew Walker PhD | (amazon.com) [2:00, 1:20:45]

**A sleep tracking company released data on 68,000 individuals since the pandemic began**: [Data from 68,000 fitness trackers show Americans are moving less and sleeping more under quarantine](https://www.cnbc.com/2020/03/27/evidation-pulse-study-moving-less-sleeping-more-quarantine.html) | Kif Leswing (cnbc.net) [4:00]

**Summary of the findings from 2 Cell Biology papers on sleep during the pandemic**: [How COVID-19 has altered sleep in the United States and Europe](https://medicalxpress.com/news/2020-06-covid-states-europe.html) | Cell Press (medicalxpress.com) [4:45]

- *Study showing that since the COVID-19 pandemic began, total sleep increased by 15 minutes, and social jet lag had decreased*: [Effects of the COVID-19 lockdown on human sleep and rest-activity rhythms](https://www.cell.com/current-biology/fulltext/S0960-9822(20)30837-X?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS096098222030837X%3Fshowall%3Dtrue) (Blume et al., 2020) [4:45]
- *Study showing that since the COVID-19 pandemic began, people are going to bed about 30 minutes later and waking up about 50 minutes later the next morning*: [Sleep in university students prior to and during COVID-19 Stay-at-Home orders](https://www.cell.com/current-biology/fulltext/S0960-9822(20)30838-1?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS0960982220308381%3Fshowall%3Dtrue) (Wright Jr, et al., 2020) [9:15]

**After consuming alcohol, sleep becomes more fragmented because the alcohol will actually stimulate the fight or flight branch of the nervous system which are wake promoting chemicals**: [Disturbed Sleep and Its Relationship to Alcohol Use](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2775419/) (Stein and Friedmann, 2009) [22:15]

**Alcohol consumption decreases the amount of REM sleep that you get**: [Alcohol and sleep I: effects on normal sleep](https://pubmed.ncbi.nlm.nih.gov/23347102/) (Ebrahim et al., 2013) [22:15]

**Peter’s article about the impact of stress (and hypercortisolemia) on the immune response viruses**: [SARS-CoV-2 and the host response: psychological stress](https://peterattiamd.com/sars-cov-2-and-the-host-response-psychological-stress/) | Peter Attia (peterattiamd.com) [28:00]

- *Experiment mentioned in the article about the impact of stress levels on the ability to fight infection from the five common colds*: [Psychological Stress and Susceptibility to the Common Cold](https://www.nejm.org/doi/full/10.1056/NEJM199108293250903) (Cohen et al., 1991)

**Study showing individuals getting less than seven hours of sleep a night are almost three times more likely to become infected by the rhinovirus**: [Sleep Habits and Susceptibility to the Common Cold](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2629403/) (Cohen et al., 2009) [29:15]

**A large prospective study found that women who were sleeping 5 hours or less were 70% more likely to develop pneumonia**: [A Prospective Study of Sleep Duration and Pneumonia Risk in Women](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3242694/) (Patel et al., 2012) [29:45]

**When mice are selectively deprived mice of various stages of sleep (particularly REM sleep) and exposed to malaria, they were far more likely to die as a consequence compared to the well-rested mice**: [Paradoxical sleep deprivation impairs mouse survival after infection with malaria parasites](https://www.academia.edu/18150148/Paradoxical_sleep_deprivation_impairs_mouse_survival_after_infection_with_malaria_parasites) (Lungato et al., 2015) [30:45]

**Not getting sufficient sleep in the week before getting a flu shot resulted in producing less than 50% of the normal antibody response therefore rendering that flu vaccination significantly less effective**: [Effect of sleep deprivation on response to immunization](https://pubmed.ncbi.nlm.nih.gov/12243633/) (Spiegel et al., 2002) [30:45, 35:30]

**Study showing removing clock faces can help people with insomnia**: [Sleeping with the enemy: clock monitoring in the maintenance of insomnia](https://pubmed.ncbi.nlm.nih.gov/16793001/) (Tang et al., 2007) [1:00:30]

**Data from 23andMe says there’s about 9 different genes that will contribute to your chronotype**: [The Genetics of Being a Morning Person](https://blog.23andme.com/23andme-research/the-genetics-of-being-a-morning-person/) | (23andme.com) [1:08:00]

**Experiment showing people sleep more without electricity and in the winter darkness**: [Circadian Entrainment to the Natural Light-Dark Cycle across Seasons and the Weekend](https://pubmed.ncbi.nlm.nih.gov/28162893/) (Stothard et al., 2017) [1:08:00]

**The free online sleep chronotype test**: [MEQ test](https://www.sleephealthfoundation.org.au/pdfs/World%20Sleep%20Day/Activity%20-%20Morning-Eveningness%20Questionnaire.pdf) | (sleephealthfoundation.org) [1:11:45]

**Book by Pediatric Sleep expert Dr. Craig Canapari**: [It’s Never Too Late to Sleep Train: The Low-Stress Way to High-Quality Sleep for Babies, Kids, and Parents](https://www.amazon.com/gp/product/1635652723/ref=as_li_qf_asin_il_tl?ie=UTF8&tag=drcraigcanapa-20&creative=9325&linkCode=as2&creativeASIN=1635652723&linkId=9935f05cc30428ba10456f0c168f241b) by Craig Canapari | (amazon.com) [1:19:45]

**The fantastic website of Pediatric Sleep expert Dr. Craig Canapari with tons of resources**: [drcraigcanapari.com](https://drcraigcanapari.com/) [1:19:45]

**Matt’s MRI studies trying to understand what is going on in the brain to produce this paradoxical antidepressant benefit of sleep deprivation**: [Sleep deprivation amplifies reactivity of brain reward networks, biasing the appraisal of positive emotional experiences](https://pubmed.ncbi.nlm.nih.gov/21430147/) (Gujar et al., 2011) [1:25:45]

**The WHO classifying any form of nighttime shift work as a carcinogen**: [1:32:30]

- *2007 report*: [Carcinogenicity of shift-work, painting, and fire-fighting](https://pubmed.ncbi.nlm.nih.gov/19271347/) (Straif et al., 2007)
- *2019 report*: [Carcinogenicity of night shift work](https://pubmed.ncbi.nlm.nih.gov/31281097/) (IARC Monographs Vol 124 group, 2019)

**Matt’s blog post discussing errors found in his book**: [Why We Sleep: Responses to questions from readers](https://sleepdiplomat.wordpress.com/#cancer) | (sleepdiplomat.wordpress.com) [1:34:45]

**Michael Pollan’s book on the potential positive health impact of caffeine**: [Caffeine: How Caffeine Created the Modern World](https://www.amazon.com/Caffeine-How-Created-Modern-World/dp/B083MYJXZT) by Michael Pollan | (amazon.com) [1:36:15]

**Another book by Michael Pollan mentioned by Matt**: [The Omnivore’s Dilemma: A Natural History of Four Meals](https://www.amazon.com/Omnivores-Dilemma-Natural-History-Meals/dp/0143038583) by Michael Pollan | (amazon.com) [1:37:15]

§

## People Mentioned

- [Buck Rogers](https://en.wikipedia.org/wiki/Buck_Rogers) (fictional character) [46:30]
- [Colin Chapman](https://en.wikipedia.org/wiki/Colin_Chapman) [56:00]
- [Michael Grandner](https://www.michaelgrandner.com/about.html) [1:01:45]
- [BJ Fogg](https://hstar.stanford.edu/team/bj-fogg/) [1:03:30]
- [Dr. Craig Canapari](https://drcraigcanapari.com/about/) [1:19:45]
- [Jodi Mindell](https://www.babysleep.com/sleep-experts/jodi-a-mindell/) [1:20:00]
- [Vin Miller](https://www.linkedin.com/in/vjmiller/) (Peter’s “fact checker”) [1:28:45]
- [Michael Pollan](https://en.wikipedia.org/wiki/Michael_Pollan) [1:36:15]
- [Michael Lewis](https://en.wikipedia.org/wiki/Michael_Lewis) [1:36:15]

§

![](https://peterattiamd.com/wp-content/uploads/2019/04/matthew-walker-image-2x1-500x500.jpeg)

##### Matthew Walker, Ph.D.

Dr. Walker earned his degree in neuroscience from Nottingham University, UK, and his PhD in neurophysiology from the Medical Research Council, London, UK. He subsequently became a Professor of Psychiatry at Harvard Medical School, USA. Currently, he is Professor of Neuroscience and Psychology at the University of California, Berkeley, USA. He is also the founder and director of the Center for Human Sleep Science.

Dr. Walker’s research examines the impact of sleep on human health and disease. He has received numerous funding awards from the National Science Foundation and the National Institutes of Health, and is a Kavli Fellow of the National Academy of Sciences.

Dr. Walker is the author of the International Bestseller, Why We Sleep. It has a singular goal: to reunite humanity with sleep.

In addition, Dr. Walker is an internationally recognized [speaker](https://www.sleepdiplomat.com/speaker), a successful [entrepreneur](https://www.sleepdiplomat.com/entrepreneur), and a Sleep Scientist for Google.

[sleepdiplomat.com]

**Twitter**: [@sleepdiplomat](https://twitter.com/sleepdiplomat?lang=en)

**Center for Human Sleep Science**: [https://www.humansleepscience.com/](https://www.humansleepscience.com/p-u-b-l-i-c-a-t-i-o-n-s)

**Matthew’s publications**: <https://www.humansleepscience.com/p-u-b-l-i-c-a-t-i-o-n-s>