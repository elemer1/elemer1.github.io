# #215 – The gut-brain connection | Michael Gershon, M.D.

**Source:** [https://peterattiamd.com/michaelgershon/](https://peterattiamd.com/michaelgershon/)

---

Mike Gershon is a Professor of Pathology and Cell Biology at Columbia University and has been at the forefront of studying neural control of the gut for the past 60 years. In this episode, Mike gives a tour de force on the pathways of gut-brain communication but first sets the stage with an overview of gastrointestinal tract development and anatomy. He then explains how the gut communicates with the brain and vice versa, from early observations in physiology and anatomy up to our present understanding of what makes the GI tract so unique and complex relative to other organs. He talks about how the gut responds to meals of different food qualities and how that affects satiety signaling to the brain. Additionally, he explains how antidepressants and other drugs impact digestion through effects on serotonin signaling, and he discusses the effects of antibiotics, and what’s really going on with “leaky gut.” Finally, Mike offers his thoughts on the utility—or lack thereof—of gut microbiome diagnostic tests, and wraps up the discussion by considering how diet, probiotics, and prebiotics impact the microbiome and GI tract.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/michaelgershon/the_Drive_public.png)

Play

#215 - The gut-brain connection | Michael Gershon, M.D.

1x15s30s

0:002:12:41

## We discuss:

- The basics of the gastrointestinal (GI) system [3:45];
- The very early development of the GI system [9:30];
- The unique properties of the blood supply and portal system in the GI tract [12:45];
- An overview of gut anatomy and innervation [16:30];
- Turnover of the epithelial lining and why cancer rarely develops in the small intestine [26:45];
- Nutrient and water absorption in the small and large intestine [30:30];
- Ways in which the gut and brain communicate [34:30];
- The gut’s role in the regulation of appetite [43:30];
- The impact of gastric bypass surgery on satiety signals [51:15];
- How varicella-zoster virus (VZV) can infect neurons in the gut and create issues later in life [54:30];
- The relationship between autism and gastrointestinal illness [1:02:45];
- The important role of serotonin in the gut, and the impact of SSRIs on serotonin in the gut [1:09:45];
- Defining “leaky gut” and its most common causes [1:16:45];
- The gut microbiome [1:30:45];
- Fecal transplants: use cases, limitations, and how they illustrate the importance of gut microbes [1:40:45];
- Gut microbiome diagnostic tests: why they aren’t useful outside of special cases such as cancer detection [1:50:30];
- Nutritional approaches to a maintain optimal flora in the gut [1:55:00];
- Prebiotics and probiotics, and getting your GI system back on track after a course of antibiotics [2:02:30]; and
- More.

§

## Show Notes

**\*Notes from intro:**

- Dr. Mike Gershon is a Professor of Pathology and Cell Biology at Columbia University
- His research focuses on the neural control of the gastrointestinal tract, and the role of serotonin in the gut as a neurotransmitter
- Mike earned his medical degree from Cornell University followed by a postdoctoral fellowship at Oxford
- Mike has received numerous awards and honors over the years
- He has published hundreds of peer reviewed papers on the nervous system
- He [authored a book](https://www.amazon.com/Second-Brain-Scientific-Groundbreaking-Understanding/dp/0060182520/ref=sr_1_2?crid=1WFTA9NNZ0ZXM&keywords=The+Second+Brain%3A+A+Groundbreaking+New+Understanding+of+Nervous+Disorders+of+the+Stomach+and+Intestine&qid=1648821166&sprefix=the+second+brain+a+groundbreaking+new+understanding+of+nervous+disorders+of+the+stomach+and+intestine%2Caps%2C109&sr=8-2) on the role of the brain and the GI system
- This episode’s different from a lot of our episodes; truthfully it comes across more as a bit of a med school lecture
  - It is really interesting, but I think at the surface it doesn’t really come across as highly applicable
  - The reality of it is you just have to get through some of the embryology, anatomy, and neurophysiology of the gut and the brain to understand how these things coexist
  - Expectations‒ if you’re coming into this thinking that this is going to be a podcast that’s about how to eat this and not that and affect your gut biome, it’s really not about that
  - This is a much more basic discussion, and I mean basic not in simple, but I mean basic in more elemental explanation, of how this system works
- Peter reflects, “*Truthfully I learned a lot in this episode, much more than I normally do. A lot of times I go into podcasts knowing the subject matter pretty well, and maybe increasing my knowledge by 20%, or something like that, but I think this was pretty different.”*
- Rather than give you a blow by blow of everything we talked about here, go into this assuming you’re not going to know much of what we talk about, and you’ll come out of this with a much greater appreciation for how your gut and your brain are connected
  - We’re only now beginning to think about how to translate this topic to clinical utility
  - We don’t yet have all of the insights
- We hope you don’t come away from this episode saying, “*Oh, all you need to do is eat this and your gut’s going to be healthier, and if your gut’s going to be healthier then your brain’s going to be better, or vice versa.*”
- This episode should give you a good foundational knowledge to evaluate half of the snake oil stuff that is out there
  - Peter feels that most of what’s out there on this topic is utter nonsense
    - Commercial tests that promise miracles don’t make any sense,
    - Similarly, supplements that don’t make any sense
  - We hope you’ll come away from this understanding how difficult it is to try to make the claims that are out there

## The basics of the gastrointestinal (GI) system [3:45]

**What brought you so much curiosity to study the GI system for 60 years?**

- Mike has been studying the GI for 60 years and there’s still more to study; it’s a very difficult subject

> “*As the saying goes, the further you get from shore, the deeper the ocean gets*”‒ Peter Attia

- There is a lot of fundamental foundational knowledge required to have a basic understanding before we can get into the nuanced stuff around the GI system
- It makes sense to start with some of the basics of the human GI including its embryology, anatomy, vascular supply, and ultimately we’re going to want to talk about its connection to the nervous system, which is quite distinct and unique (relative to even the peripheral nervous system)

**Characteristics of the GI tract and its function**

- The [GI system](https://en.wikipedia.org/wiki/Gastrointestinal_tract) is basically a tube that begins at the mouth and ends at the anus
- It’s hollow so the inside of the GI tract is really an internalized external space; it’s outside the body
  - If you bleed into your GI tract, you lose blood (even if you can’t see it)
    - This is one of the major crises in medicine‒ hidden bleeding in the GI tract
    - It can be very damaging, even if you don’t see any blood
- The inside of your gut is outside of your body, and it provides a space for a community of extra organisms to live
  - This space is immense
  - This space can be dangerous and a barrier is necessary to keep it separate from the rest of you
    - This barrier is defended by the body
  - It also allows food to be digested and absorbed
  - It has to maintain the communication with the lumen, which is what we call the inside of the GI tract

***There is a balance in the GI between protection of the body and allowing food stuff to come in***

- People understand that many bacteria colonize our nasal passages, skin, etc.
- And that when bacteria enter the body, [bacteremia](https://en.wikipedia.org/wiki/Bloodstream_infections) is a bad thing
- The GI tract has unique challenges because it must allow transmission of nutrients across its surface but not allow bacteria/ organisms to go through
- Further, the food we eat is not ready for absorption
  - Food has to be digested
- Not only does the gut have to absorb a variety of things, it does so in an awful witches brew that breaks down the food
  - All without digesting yourself

> “*The lining of the gut is absolutely remarkable*”‒ Michael Gershon

- Complex molecules that are not sterile are entering a non-sterile environment and somehow only sterile nutritional building blocks are allowed to cross the border of the GI tract

## The very early development of the GI system [9:30]

- During development the body forms a flat disc
- That disc undergoes a series of folds from head to toe, and from side to side, and the lateral or side folding produces the tube from which the gut forms
  - So the flat disc folds around to create an internal space, and that tube because the gut
  - This takes place during the 1st trimester
    - The gut is fully developed between the 2nd and 3rd trimester
- The first part of development is called embryogenesis
  - That is the fertilized egg forms the disc, the disc folds, the organs of the body form, and that’s the embryonic period
- The fetal period follows
- The fetal period models the organs into their appropriate developmental form so that they becomes functional enough to support a baby
- Peter recalls from med school (26 years ago), that fold turns into the tube which will become the entire length of the GI system, and *there are also these little outpouchings* that come along later
  - These become things like the pancreas and the bile duct, etc. which form other things that drain into the GI system and perform essential functions for digestion
  - For example, the pancreas and gallbladder drain into the gut
  - The lungs are also formed, and they do not drain into the GI system
  - The liver has a component that drains into the gut through the bile system
- The **foregut** forms the stomach, the first part of the small intestine, the lungs, the pharynx, pancreas, gallbladder
- The **midgut** is the business of small intestine and the first part of the large intestine
- The **hindgut** is the end of the large intestine
- Peter recalls that the foregut, midgut, hindgut basically tracked with the three vessels coming off the aorta‒ the celiac, the superior and inferior mesenteric

## The unique properties of the blood supply and portal system in the GI tract [12:45]

- The [foregut](https://en.wikipedia.org/wiki/Foregut) is defined as the part of the gut from the [celiac artery](https://en.wikipedia.org/wiki/Celiac_artery)
- The celiac artery is the most rostral, or anterior (closest to the head), see the figure below

![](https://peterattiamd.com/wp-content/uploads/2022/07/f1-gershon-828x1024.jpeg)

**Figure 1.  Blood supply to the GI tract and anatomy of the colon.**   Image credit: [GrepMed.com](https://www.grepmed.com/images/13526/diagnosis-arterial-supply-gitract-anatomy)

- The celiac artery supplies the pancreas, the stomach, the first part of the duodenum, and the liver and the gallbladder
- The [superior mesenteric artery](https://en.wikipedia.org/wiki/Superior_mesenteric_artery) supplies the midgut
  - That’s the longest part of the gut
  - That goes roughly to the mid-transverse colon
- The [colon](https://en.wikipedia.org/wiki/Large_intestine#Structure) has 3 parts, it folds
  - 1 – It has an ascending colon
  - 2 – A transverse colon going sideways
  - 3 – A descending colon, which goes down to the rectum and anus, which is out
- The [inferior mesenteric artery](https://en.wikipedia.org/wiki/Inferior_mesenteric_artery) supplies the end of the gut
- When the celiac gives rise to the stomach and first part of the small intestines arterial supply (that then breaks into capillaries, absorbs materials from the gut), those capillaries drain into veins in the gut
  - And in a unique way, those veins then form large vessels which then move into the liver
  - They then break into capillaries, small vessels within the liver called sinusoids
  - So the venous system that supplies the liver is actually acting as if it were an artery, but it begins in the gut
- So the [liver](https://en.wikipedia.org/wiki/Liver) depends on this venous system for its oxygen on blood that the gut has had a first crack at
  - And to keep the liver going, it gets a 2nd arterial supply from the [hepatic artery](https://en.wikipedia.org/wiki/Common_hepatic_artery)
  - *Basically the liver is perfused with blood coming from the gut*
    - And when it’s about to asphyxiate, a sphincter shuts that down, opens up, and it gets a breath of fresh blood (and gets some oxygen), and then it goes back to dealing with what it gets from the gut
  - *The reason it does that is the liver is the first step in the body’s ability to use the nutrients that the gut absorbs*
    - So when the gut absorbs fatty acids, the liver turns them into chylomicrons, which can go out and supply energy to the body
  - The liver is a major center of metabolism working on products from the gut
    - So it gets the first crack at what the gut has absorbed

## An overview of gut anatomy and innervation [16:30]

**How is the gut innervated?**

- The nervous system of the gut is complex and different
  - This includes the [enteric nervous system](https://en.wikipedia.org/wiki/Enteric_nervous_system) and [gut-brain axis](https://en.wikipedia.org/wiki/Gut%E2%80%93brain_axis)
- The gut has its own intrinsic nervous system, and Mike has called that “The Second Brain” (that’s the title of [his book](https://www.amazon.com/Second-Brain-Scientific-Groundbreaking-Understanding/dp/0060182520/ref=sr_1_2?crid=1WFTA9NNZ0ZXM&keywords=The+Second+Brain%3A+A+Groundbreaking+New+Understanding+of+Nervous+Disorders+of+the+Stomach+and+Intestine&qid=1648821166&sprefix=the+second+brain+a+groundbreaking+new+understanding+of+nervous+disorders+of+the+stomach+and+intestine%2Caps%2C109&sr=8-2))
  - *The reason he calls it “The Second Brain” is that like the brain in the head, the nervous system of the gut is able to function and control reflexes and behavior independently of any influence from the brain or spinal cord*
- So it’s the only nervous system of the body that can work on its own, so if you completely isolate the gut from the brain and the spinal cord, it will function; you’re not dead
- Years ago, when peptic ulcers were thought to be psychogenic, surgeons used to cut the [vagus nerves](https://en.wikipedia.org/wiki/Vagus_nerve), which are the major conduits that connect the brain and the gut
  - Afterward, the gut continued to soldier on
  - This never did all that much to fix peptic ulcer disease; that turned out to be caused by infection with the bacteria [*Helicobacter pylori*](https://en.wikipedia.org/wiki/Helicobacter_pylori)
- Before the discovery of *Helicobacter pylori*, it was believed that stress was driving peptic ulcer disease
  - The idea was that the central nervous system would communicate the stress to the gut via the vagus nerve
  - This wasn’t all wrong, the central nervous system can communicate stress to the gut via the vagus term, but that was not the cause of peptic ulcer disease
- This treatment did help to show that the gut could in fact be cut off from the brain and still work

**A history of observation of the connections between the brain and gut**

> “*The nervous system of the gut has been known to be present for a long time*”‒ Michael Gershon

- It was discovered about the time of the American Civil War; [Auerbach](https://en.wikipedia.org/wiki/Leopold_Auerbach) in Germany noticed the extremely large nervous system in the human gut at that time
- At the turn of the 20th century in the cold laboratories of England, [Bayliss](https://en.wikipedia.org/wiki/William_Bayliss) and [Starling](https://en.wikipedia.org/wiki/Ernest_Starling) cut all the nerves to the intestine of a dog
  - Starling is responsible for [Starling curves in cardiac physiology](https://en.wikipedia.org/wiki/Frank%E2%80%93Starling_law)
- When they cut all the nerves to the gut and then increased pressure inside the gut in the lumen, the gut would respond with the stereotypic behavior of oral contraction anal relaxation that they called the *law of the intestine*
- 17 years later, during WWI another German scientist by the name of Trendelenburg made important findings
  - He experimented with Guinea pig intestine *in vitro* (on a J-shaped tube)
    - When he blew into the J-shaped tube, it raised the pressure inside the intestine, and the gut blew back at him
    - This was a very profound observation because it showed that with nothing there but the gut the gut could respond, sense the pressure, and show a coordinated wave of activity in response to it

***This indicated that the intestinal nervous system is able to function independently of the*** [***CNS (central nervous system)***](https://en.wikipedia.org/wiki/Central_nervous_system)***; no other nervous system outside the CNS can do that (even the spinal cord can’t do that)***

- This is a universal finding preserved across species; all vertebrates have it
  - It begins with a little organism called [amphioxus](https://en.wikipedia.org/wiki/Lancelet), which undergoes metamorphosis, turns into a vertebrate
  - It gets more complex as vertebrates become more complex
    - A fish has only 1 layer of enteric nervous system, humans have 2 (some people would say 3)

**Back to anatomy of the GI**

- When you go from the lumen (see the diagram below) at the very inside all the way out you have a mucosal layer, a submucosa, and a muscular layer

![](https://peterattiamd.com/wp-content/uploads/2022/07/f2-gershon-1024x634.png)

**Figure 2.  Structure of the gut wall.**Image credit: [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Layers_of_the_GI_Tract_english.svg)

- The lining of the gut is called the mucosa
  - It has a superficial lining that is in contact with the lumen called an epithelium
- Underneath that is a loose nervous system called a lamina propria, but together that’s the mucosa
- Below that there’s a dense layer of connective tissue
  - Which allows the gut to be used for stringing tennis rackets; it allows the gut to be used to suture material; it’s tough, you can’t pull it out
- The next layer is a circular layer of smooth muscle, another layer of smooth muscle, a second one called the longitudinal layer
- Then, if it’s in the [peritoneal cavity](https://en.wikipedia.org/wiki/Peritoneal_cavity), there is another layer of very thin epithelium
- The major parts of the nervous system of the gut are the [submucosal plexus (the Meissner’s plexus)](https://en.wikipedia.org/wiki/Submucosal_plexus); that’s in that dense layer of connective tissue, and that’s the smaller of the 2
- The larger one is the [myenteric plexus](https://en.wikipedia.org/wiki/Myenteric_plexus), and that is in between the two layers of smooth muscle on the outside of the gut
- The 2 plexuses communicate with one another; they get input from the CNS, and speak back to the CNS
- *Although they can function independently of control by the brain, in practice they don’t*
  - There is a constant 2-way (bipolar) communication between the brain the the gut
  - The  brain acts very much like a CEO; it gives general commands
  - The detail of what the gut actually does, that behavior, is controlled by the bowel itself

**Peter’s summary of these 2 muscular walls**

- 1 of them runs longitudinally; it runs in the direction of the lumen
- 1 of the runs orthogonal to that; it runs circularly
- He remembers from anatomy was that you have these things where if the circular inner layer contracts, that shrinks the lumen
- Then, as the the longitudinal one contracts, it shortens it along its long axis
- Together this is what permits this remarkable [peristaltic rhythmic contraction](https://en.wikipedia.org/wiki/Peristalsis) of the gut

> “*The behavior of the gut is not so simple as to have just one peristaltic movement*”‒ Michael Gershon

- When you look at it it seems to be moving rhythmically, but it’s much more complicated than that
  - It doesn’t do that all the time

***The first part of the enteric nervous system, which is the myenteric plexus, sits between those two layers***

***Next there is the the submucosal plexus***

- This is beneath those muscular layers
- It’s in the tough, submucosal layer
- It’s between that circular muscular wall and the submucosa

***Inside the submucosa you have the mucosa, and then ultimately the lumen on the very inside with the enterocytes that form the endothelial lining of the gut***

## Turnover of the epithelial lining and why cancer rarely develops in the small intestine [26:45]

**What is the turnover time of this epithelial layer?  What is the median residence time of an epithelial cell in the gut?**

- This depends on the type of epithelial cell
- The gut epithelium turns over about once a week
  - [Enterocytes](https://en.wikipedia.org/wiki/Enterocyte) turn over very rapidly
- To get into the details, there are certain cells in the lining of the gut, such as a cell called the [Paneth cell](https://en.wikipedia.org/wiki/Paneth_cell), which lives for 3 weeks
  - They are in the base of the crypt; it’s a part of the folding of the lining of the gut
  - The Paneth cell has 2 major functions
    - 1 – Defense, it puts out a number of antibacterial proteins that keep the lining of the small intestine close to sterile (only a few thousand microorganisms for cubic milliliter)
    - 2 – Nurse the stem cells responsible for turn over of all the cells
    - These cells are not found in the large intestine
- [Gut endocrine cells](https://en.wikipedia.org/wiki/Enteroendocrine_cell) live a little bit longer
  - They produce hormones in the lining of the gut

**With this rapid turnover of cells, why is it that cancer almost never develops in the small intestine?**

- The colon is so susceptible to neoplasia (the formation of cancer), because it has at its surface a cell that is constantly turning over
  - As a result, there are more chances for genetic errors of replication that can produce oncogenic mutations
- People have speculated on this
- Part of the answer is the huge [microbiome](https://en.wikipedia.org/wiki/Microbiome) of the large intestine
  - It is orders of magnitude larger than that of the small intestine
- Another part of it is that the products that sit in the lumen of the large intestine sit there for much, much longer
  - Food goes through the small intestine, and is digested quickly
  - In terms of being exposed to environmental toxins, or toxins produced by organisms, or toxins that are split off from what you eat, the large intestine is exposed much longer

## Nutrient and water absorption in the small and large intestine [30:30]

**Is it correct to say that most nutrient absorption takes place in the small intestine and the large intestine mainly reabsorbs water?**

- Yes, but it’s not this simple
- The large intestine conserves/ absorbs sodium and secretes potassium
  - Water follows sodium as it comes back into the body
  - The colon acquired this function to enable organisms to live on land
  - When organisms lived in the water, conserving sodium and water was not such a problem
- However, the bulk of the water that the gut absorbs is not in the large intestine; it’s done in the small intestine
  - But the final 100 mL+ of water absorbed happens in the colon; it’s important in maintaining the body’s fluid content
  - If you lose this fluid (as happens with [cholera](https://en.wikipedia.org/wiki/Cholera)), you can die of dehydration in about 4 hours

**Tangent on what can be learned from fluid loss in the large intestine due to cholera**

- The [cholera toxin](https://en.wikipedia.org/wiki/Cholera_toxin) turns sodium absorption into chloride secretion, causing water to flow out
- Around [3 million](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4455997/) people get cholera each year, resulting in 21,000-143,000 deaths (primarily in Africa and Asia)
  - There have been major outbreaks of cholera along the coast of Peru that led to cases a for north at New Jersey, transmitted as people ate contaminated crab
  - Hati is the most famous large outbreak; it occurred after an earthquake destroyed a lot of their infrastructure
- Cholera is a simple illness, all one has to do is keep track of the water
  - Patients are put on what’s called a cholera cot; it has a gurney hole in the middle for the anus to be positioned over, and a bucket is put under it
  - The nurse puts a ruler into that bucket periodically to see how much fluid is coming out
  - This fluid is replaced intravenously and orally
  - A great life saving discovery was that although cholera blocked the absorption of sodium, it does not block the absorption of glucose in the small intestine
    - And so adding a little bit of sugar to the fluid used for oral rehydration has saved countless lives
- Antibiotics have no use in treating cholera
- Given enough time, the immune system will fight off the bacteria
- Supporting the hydration status of those infected buys them enough time for the immune system to clear infection

## Ways in which the gut and brain communicate [34:30]

**You made a point to talk about the** ***intrinsic innervation of the gut*****.  What is the difference between intrinsic and extrinsic neurons in the context of the gut?**

- The *intrinsic nervous system of the gut* is a term representing the nerve cells that live within the gut; there are 2 plexuses

- The *extrinsic innervation* includes the brain (which sends fibers to those neurons) and the sympathetic nervous system (which projects from outside the gut into it)
  - It also includes the [spinal cord](https://en.wikipedia.org/wiki/Spinal_cord) and the ganglia associated with the spinal cord
  - It includes sensory ganglia and [dorsal root ganglia](https://en.wikipedia.org/wiki/Dorsal_root_ganglion) (which provide a sensory innervation of the gut)
- Intrinsic means that the cell body of the nerve cell resides *within* the gut
- Extrinsic means that the cell body is *outside* the gut, wherever

**Everyone can appreciate the incredible pain that one experiences with distention of the bowel.  How is the pain of distention in the gut communicated to the brain?**

- When Peter practiced as a general surgeon, patients presenting with a bowel obstruction were in as much pain as those with a bowel perforation
- It’s important to be able to put a [nasogastric](https://en.wikipedia.org/wiki/Nasogastric_intubation) into them and decompress them
- Even if you haven’t had a bowel obstruction, simply being bloated can be incredibly uncomfortable

> “*The only way the gut feels pain is in response to dilatation or pressure*”‒ Michael Gershon

- One can cut the inside of the gut with impunity; surgeons do this all the time when they take biopsies from inside the gut without anesthesia
  - From the point of view of pain, the gut is innervated differently from the skin
  - The skin feels pressure but this is much less painful than cutting; for the gut, the reverse is true
- In the gut, most of the fibers that get excited by increased pressure are located in the dorsal root ganglia (hose are pain fibers)
- The [vagus nerve](https://en.wikipedia.org/wiki/Vagus_nerve) relays some pain, but not much
  - Mostly the vagus nerve carries information back to the brain that has to do with homeostasis

**Give an example of the type of information conveyed by the CNS to the gut**

- Earlier the CNS was described as functioning like a CEO, providing broad instruction but not necessarily minutia-driven, operational instructions
- Compare this to a scientist submitting a grant to the NIH to obtain funding for their research
  - The scientist submits a grant application; they present their research in the best possible light
  - The grant undergoes peer review and the government decides whether to fund it or not
  - While the scientist waits to hear back from the peer review process, he becomes acutely aware of the effect the CNS can have on their gut
    - Most people can resonate with this feeling of butterflies, this feeling of tension-induced diarrhea
    - This is coming by way of the CNS
  - Similarly, some people when they’re frightened or traveling just completely lose the ability to defecate; they become constipated
  - [Sympathetic nerves](https://en.wikipedia.org/wiki/Sympathetic_nervous_system) can slow the gut and make it less likely to defecate
    - This occurs in response to true fright (as opposed to anxiety)
    - For example, if you’re fleeing a foxhole because the enemy is coming, it’s best if you don’t have to stop to defecate

**How does the gut receive this message at the local level?**

- In the CNS, the sympathetic and parasympathetic system communicates that via [acetylcholine](https://en.wikipedia.org/wiki/Acetylcholine) and things like that

*Using the example of anxiety-induced diarrhea, what happens in the gut?*

- The action taken by the gut is more rapid peristalsis and less absorption
- This is due to the function of the enteric nervous system
- One theory (that Mike believes) is that [command neurons](https://en.wikipedia.org/wiki/Command_neuron) in the gut receive input from the CNS
  - It turns out that the number of fibers in the vagus nerve that are running to the gut are pretty small in humans, an estimated 3,000 – 5,000
  - The number of nerve cells within the gut are over 100 million
  - So the intrinsics outnumber the extrinsics by 3 orders of magnitude, if not more
  - That raises the question, how do these nerve cells control it?
  - The CNS, as a CEO uses the command nerve cells to get the reflexes going and keep things moving more rapidly
- The gut has a number of different behaviors; it’s not just propelling all the time
  - If the gut were constantly propelling (as he described it with oral contraction, anal relaxation, as it’s capable of doing), then social discourse of the kind we’re having right now would become impossible
  - Sometimes the gut has to stop
- 1 type of behavior in the gut is essentially *paresis*, the gut stops moving
- A 2nd type of behavior that the gut shows is *mixing*, where things go back and forth without propulsion
  - This is important for mixing the enzymes needed for digestion with food
  - And anyone who’s ever taken an organic chemistry lab will tell you nothing very much happens unless the reaction is stirred
- The gut is able to sense what is going on, when digestion  has occurred sufficiently, and it stops mixing and propels the contents on
- At night while you’re sleeping, a *cleaning process* going on in the gut
  - A wave begins in the stomach; it goes down the small intestine; it proceeds down the large intestines; and it cleans the gut out
  - Sphincters are opened so things that would ordinarily be too big to pass are allowed through
    - For example when a kid swallows a dime or even an open safety pin‒ it manages to get propelled all the way with the small end wons and almost never gets stuck

## The gut’s role in the regulation of appetite [43:30]

**What happens between the gut and the brain to control appetite (in the nonpathologic state)?**

- There are a number of factors
- 1 – Distension of the stomach tends to cause satiety and decrease the urge to eat
- 2 – Rise of blood glucose is sensed by receptors within the gut which send signals to the brain
  - Other cells in the brain are chemo sensitive and detect nutrients within the gut
- 3 – [Enteroendocrine cells](https://en.wikipedia.org/wiki/Enteroendocrine_cell) within the gut make hormones
  - Such as [cholecystokinin](https://en.wikipedia.org/wiki/Cholecystokinin), which can signal to the brain by going through the blood brain barrier to be received by neurons
  - [Leptin](https://en.wikipedia.org/wiki/Leptin) is made within the gut.
  - There are a large number of hormone receptors in the brain that can trigger your urge to eat, as well as nutrients that you absorb, and distension of the bowel itself

> “*The gut has receptors in it and the brain has signals within it that trigger the urge to eat*”‒ Michael Gershon

***Peter’s summary: the 2 mechanisms through which appetite is communicated are mechanical and chemical***

- - Mechanical communication occurs in the stomach and to a lesser extent in the small bowel
    - Information is transmitted from the gut to the CNS via the vagus nerve
  - The change in blood glucose is sensed directly in the CNS
    - This occurs because glucose easily passes through the [blood brain barrier](https://en.wikipedia.org/wiki/Blood%E2%80%93brain_barrier); so the gut doesn’t need to be involved

- Blood vessels that provide blood to the brain have transporters that allow certain chemicals from the gut, such as leptin and cholecystokinin to be transported so that they can affect the CNS directly

- [Ghrelin](https://en.wikipedia.org/wiki/Ghrelin) is another hormone from the gut that works in the opposite way what we’ve been talking about
  - Instead of decreasing food absorption, ghrelin is a gut hormone that promotes appetite

**What causes secretion of ghrelin?**

- Ghrelin secretion is affected by certain chemicals in foods eaten
- Nutrients that suppress ghrelin secretion include amino acids and fatty acids
- *The natural state is secretion of ghrelin and it’s the presence of nutrients that turn it down*
  - Ghrelin is secreted at a constant rate that can be turned up or down
  - Inhibiting secretion is important to prevent the development of the ghrelin effect

**How is secretion of ghrelin affected by the type of meal**?

- [Rudy Leibel](https://www.cuimc.columbia.edu/mdphd/profile/rlleibel) and [Mike Rosenbaum](https://www.pediatrics.columbia.edu/profile/michael-rosenbaum-md#research) have done a number of these experiments comparing mixed-meal-shakes versus solid food

*Is satiety affected purely through change in the speed of absorption or are there other differences between a liquid and solid meal that might factor into that?*

- There are a number of factors
- The rate at which the stomach empties varies tremendously depending on what you put into it
  - For example, if you just eat a saline meal, the stomach will empty much more rapidly than if there’s protein in it
  - And even protein will empty much more rapidly than if there’s fat in it

- Solids also delay gastric emptying; particles can’t get through the pyloric sphincter unless they’re ground down to a millimeter or less in diameter
  - One part of the stomach contracts massively and suddenly, this forces the bolus that’s in the stomach up against the pyloric sphincter (which is the exit of the stomach, and is shut tight); and this ramming action breaks up solids into small particles

***So the stomach senses the nutrients and the speed at which it empties, regulates the dilatation of the stomach and the signal that the stomach is sending back to urge satiety on the brain, which means that if you’re eating protein and fat, you will reach satiety much sooner than if you’re eating just salt and sugar***

**Main takeaway:** anything that slows the emptying of the stomach will tend to induce satiety and reduce the length of time during which you feel hungry and want to eat

## The impact of gastric bypass surgery on satiety signals [51:15]

**What happens during a gastric bypass and what benefits does it provide?**

- One of the most successful operations for the treatment of both obesity and Type 2 diabetes is a [gastric bypass](https://en.wikipedia.org/wiki/Gastric_bypass_surgery)
  - This reroutes the upper GI tract

***The gastric bypass triggers an emergency procedure in the small intestine to produce a larger satiety signal***

- People can ignore signals from the stomach when they overeat
- Signals from the small intestine act as a back up signal to stop eating; it makes eating objectionable

> “*What the gastric bypass is doing is to make eating so objectionable that it stops sooner and you eat much, much less”*‒ Michael Gershon

- Another way to do this is to put a band on the stomach and interfere with the process of grinding the food won; this allows large particles to move into the small intestine and the same thing happens (signals to stop eating are released)
- Peter notes, “*that would explain why both of these procedures can fail if a patient continues to consume very high calorie liquids… which includes alcohol*”

> “*One of the things I always say to people that are trying to lose weight is try not to drink any calories*”‒ Peter Attia

## How varicella-zoster virus (VZV) can infect neurons in the gut and create issues later in life [54:30]

- 30 years ago or so, Mike and his wife discovered that the gut is a source of infection by the [varicella-zoster virus (VZV)](https://en.wikipedia.org/wiki/Varicella_zoster_virus) (the virus of chickenpox and shingles)
- Shingles of the gut can occur; that can be very, very serious

**A primer on how VZV remains latent to cause shingles after causing chickenpox**

- After someone recovers from the chickenpox, VZV remains in the body (sleeping)
- When you get chickenpox, you clear the virus and it forms what is known as an [episome](https://en.wikipedia.org/wiki/Episome) in neurons and just sits there latent without causing infection for years and years and years
  - It just stays with you for life
- Then, for reasons that are unknown, the virus can reactivate
  - This gives rise to the reemergence of active virus, shown in the diagram below

![](https://peterattiamd.com/wp-content/uploads/2022/07/f3-gershon-1024x448.webp)

**Figure 3.  VZV establishes latency in ganglionic neurons after resolution of chickenpox (varicella) and can reemerge to cause shingles (zoster).**  Image credit: [*Nature Reviews Disease Primers* 2015](https://www.nature.com/articles/nrdp201516)

- Reactivation (reemergence) of VZV always starts in a nerve cell
  - Because it’s been latent in a nerve cell
  - During reactivation, the virus goes down the axon (or the process from the dorsal root ganglia) to the skin and causes a rash, shown in the previous figure
  - Because of immunity to the virus, it stays localized there in the nerve and skin and doesn’t cause systemic disease like the chickenpox
- Reactivation is called shingles (or zoster); this can be extremely painful because the nerve cells die and become extremely active (they’re pain nerve cells)
- About 15% of people develop [postherpetic neuralgia (PHN)](https://en.wikipedia.org/wiki/Postherpetic_neuralgia) where the pain persists for years and is very difficult to treat
  - This is pathological pain and the virus isn’t there
  - The nerve cells are no longer causing the pain; it’s coming from within the CNS
  - It’s sort of like a phantom limb in which you cut off a limb and people have the feeling the limb is still there, but it’s not
  - Some drugs that do some good like [Gabapentin](https://en.wikipedia.org/wiki/Gabapentin), but nothing is wonderful
- When Peter was a kid, everyone got chickenpox
- Kids now get vaccinated for chickenpox
- Mike’s wife [Anne](https://www.ihn.cuimc.columbia.edu/profile/anne-gershon-md) developed the vaccine

**Peter’s takeaway:** Despite how the virus comes into you (through natural infection and immunity of vaccine-induced immunity), it remains latent in the dorsal root ganglion

**Why doesn’t the immune system completely eradicate it like it does virtually every other virus we encounter?**

- When the virus is in the nerve cells, the immune system can’t see it

> “*Let’s call it a sequestered virus and it sits as a piece of DNA inside of your body*”‒ Michael Gershon

- Your immune system can’t see it because it’s not expressed on the surface of the nerve cells that have it
- The immune system has a very good look at it when it reemerges
  - It attacks it and kills the cells in which it reemerges
  - Even still, pain can continue in a small number of people
- Mike has discovered that the enteric nervous system can be infected by VZV when you have chicken pox or when you get the live virus vaccine
  - It can establish latency within the intrinsic nervous system of the gut, in the [enteric nervous system](https://en.wikipedia.org/wiki/Enteric_nervous_system)
- When the virus re-arises, even if it gets killed by the immune system, it’s killing nerve cells
  - This leads to diseases such as pseudo-obstruction in which the gut loses the ability to work and just becomes totally paralyzed
  - Or if the virus emerges and gets into the mucosa, the gut can perforate
  - This has just been discovered, so the frequency of this is unknown
  - He’s just [published](https://pubmed.ncbi.nlm.nih.gov/33932481/) on its reemergence in the esophagus, where it causes a disease called [achalasia](https://en.wikipedia.org/wiki/Esophageal_achalasia)
    - In this disease the ability of the esophagus to deliver food to the stomach is lost
    - The esophagus can’t open, so you can’t swallow at all
    - This only occurs during reemergence, not during the primary infection
- The causes of viral reemergence is not well understood
  - A weakened immune system is part of it, and this gets us to aging

***It seems likely that the virus keeps reactivating periodically throughout your life; and that when you have shingles, just exceed a threshold because the immune system has receded just enough to let it out, to reach the clinical threshold***

- The current vaccine ([Shingrix](https://en.wikipedia.org/wiki/Zoster_vaccine)) [for shingles/ zoster] is 2 shots separated by 6 months
  - Mike remarks, “*That has been a giant leap forward. That’s been amazing*.”
  - The purpose is to prime the immune system to the virus again, so it can catch the virus more quickly if it escaped
  - It’s about 97% effective, a remarkable vaccine
- Peter comments that he got his Shingrix vaccine early (he’s not quite 50 yet) and “*what a kick in the chops that vaccine is. That makes you sick. I’ve had my first shot. I’m dreading my second*.”
  - Michael points out, “*The older you are when you get it, the less likely you are to be bothered by the injection*.”

## The relationship between autism and gastrointestinal illness [1:02:45]

**Do children with autism have an increased severity of illness and increased prevalence of gastrointestinal illness?**

- Yes, this is an accepted observation
- [Autism](https://en.wikipedia.org/wiki/Autism_spectrum) is a disease that probably involves synaptic transmission
- It occurs in the CNS
  - The behavioral effects are well known
- It also occurs in the enteric nervous system
  - There is a smaller effect on the GI tract‒ often diarrhea and sometimes constipation

**Are there a higher degree of food sensitivities and allergies?**

- This is not well understood but seems to be related to activation of [mast cells](https://en.wikipedia.org/wiki/Mast_cell)
- Peter notes that many parents of autistic children are convinced that if they pay more attention to what their kids eat, they can reduce the severity of their symptoms

 **Is this a reasonable idea given the simple observation of this association?**

- Michael points out, “*there’s no regularity to the symptoms that you can point to. It’s hard to back it up. And people have been unable to produce any sort of rigorous background for that, so that when you put controls and constant observation, you just can’t document it*.”
- Peter replies that there must be so much variability; you need an empirical approach because no one size fits all here

**Tangent to discuss fraudulent studies by Andrew Wakefield**

- Mike further points out that this area is fraught with poor quality research; in 1991 the British gastroenterologist [Andrew Wakefield](https://en.wikipedia.org/wiki/Andrew_Wakefield) published….
  - Peter discussed this example with Brian Deer,  [#158 – Brian Deer: A tale of scientific fraud—exposing Andrew Wakefield and the origin of the belief that vaccines cause autism](https://peterattiamd.com/briandeer/)
- Wakefield associated autism with GI inflammation
  - The idea was that if you ate [gluten](https://en.wikipedia.org/wiki/Gluten), you could produce [endorphins](https://en.wikipedia.org/wiki/Endorphins) from what you were eating
    - You would eat an opiate-like material, then magically the enzymes of the digestive tract would liberate opiate-like products
    - These opiate-like substances would be absorbed and affect the immature, developing nervous system and cause autism
    - ***This is not true***
  - His idea was that if you got the [measles, mumps, and rubella vaccine (MMR)](https://en.wikipedia.org/wiki/MMR_vaccine), it would cause a defect in the gut that could lead to absorption of these opiate-like products
    - ***This was also incorrect***
  - Mike explains, “*You can’t train an enzyme to cut something differently than the way the genes have programmed it to*”
    - [Trypsin](https://en.wikipedia.org/wiki/Trypsin) looks for particular amino acids and cuts proteins there; it doesn’t care what kind of endorphin is sitting somewhere else
    - Then when [peptides](https://en.wikipedia.org/wiki/Peptide) are produced, they are not absorbed; only [amino acids](https://en.wikipedia.org/wiki/Amino_acid) are absorbed (maybe dipeptides or tripeptides)
    - Amino acids are the building blocks of peptides and proteins, shown in the figure below
      - An amino acid is the smallest functional unit or building block that is strung together to make up peptides and proteins
      - A peptide is made of less than 50 amino acids
      - For example, a small peptide of 9-11 amino acids is what the immune system recognizes
      - A protein is made up of more amino acids, thousands can be linked together in a complex protein
  - Peter clarifies, in the GI tract only single amino acids or maybe 2 amino acids joined are absorbed
    - This is smaller than an immunogenic peptide (what the immune system recognizes)

![](https://peterattiamd.com/wp-content/uploads/2022/07/f4-gershon-1024x347.png)

**Figure 4.  Comparison of amino acids, peptides, and proteins (from small to large).**  Image credit: [Peptide Sciences 2019](https://www.peptidesciences.com/information/peptides-vs-proteins/)

- Mike continues with Wakefield’s flawed logic, if by some miracle these peptides got absorbed, they couldn’t pass through the [blood brain barrier](https://en.wikipedia.org/wiki/Blood%E2%80%93brain_barrier)
  - In fact, they wouldn’t go past the liver
- Mike testified in Congress on this subject
  - The chair of the congressional committee on government oversight ([Representative Dan Burton of Indiana](https://en.wikipedia.org/wiki/Dan_Burton)) did not like his testimony
  - Burton’s grandson had autism and he was convinced he got it from a vaccine
  - He had to be restrained from throwing the gavel at Mike
  - They told him, if he didn’t recant his testimony, he would be charged with perjury
  - Afterward, Congressman Waxman from California came over to Mike and gave him a high-five

## The important role of serotonin in the gut, and the impact of SSRIs on serotonin in the gut [1:09:45]

**Serotonin levels are higher in a subset of kids with autism spectrum disorder (ASD).  What is the role of serotonin in the gut?**

- Most people associate [serotonin](https://en.wikipedia.org/wiki/Serotonin) with a hormone in the brain responsible for mood
- Mike has been working on serotonin since college
  - He did his senior thesis on it when he graduated from Cornell in 1958
- Serotonin was discovered in the gut
  - [Enterochromaffin cells](https://en.wikipedia.org/wiki/Enterochromaffin_cell), which are an endocrine cell of the gut responsible for making about 95% of the body’s serotonin
  - The brain produces about 2-3% of the body’s serotonin

> “*Although the brain serotonin is probably what makes life worthwhile (and is responsible for happiness among other things), in terms of amounts, it’s a little afterthought of evolution*”‒ Michael Gershon

**Serotonin in the gut sends important signals**

- Within the gut, serotonin is made in 2 places
- 1 – The bulk of it is made by the enterochromaffin cells, which are the small endocrine cells that are part of the GI epithelium
  - It’s a minor component of the epithelium, but a major component functionally of what the gut does
  - About 80% of the endocrine cells make serotonin
- 2 – The other source is serotonin-containing nerve cells within the enteric nervous system
  - It is a neurotransmitter and an endocrine substance in the gut
  - It’s very important in feeling pain in the gut; it’s important for triggering nausea
- In sending signals from the gut to the brain, serotonin is an important transmitting substance
- During development, serotonin is very important as a growth factor
  - The first nerve cells to form in the gut make serotonin
  - Subsequent nerve cells depend on serotonin, it triggers them to develop
  - If you knock serotonin out of the nervous system, the gut lines up with too few neurons, and it doesn’t work very well.
  - If you knock serotonin out of the epithelium, then there’s problems signaling back to the brain, and the peristalsis reflex is impaired
    - It’s not stopped, but it’s impaired because the endocrine cells in the gut can trigger peristaltic waves that are propulsive
    - But if you lose that, then in order to trigger it, you have to press harder and harder, and dilate the gut, and get the nervous system to do this directly
    - It also talks to the immune system; it triggers inflammation

***As you might imagine, from the amount of it that’s in the bowel, serotonin does everything; it’s a multifunctional molecule***

**What are the effects of SSRIs outside of the CNS? Do they impact the gut specifically?**

- [SSRIs](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor) prevent the reuptake of serotonin, this neurotransmitter in the brain, presumably leaving more of it around to exert positive effects
  - They’re used to treat the symptoms of depression

- They tend to cause nausea by enhancing the ability of serotonin to talk back to the brain
  - Similarly, drugs that are used in cancer chemotherapy also trigger the release of serotonin within the gut and trigger that reflex
- SSRIs also first make the gut go a little bit faster
  - But then when the gut keeps doing that, the receptors, that is the molecules upon which serotonin acts, desensitize
    - One way they do that is to internalize
    - They can actually block the effect of serotonin in transit
  - In terms of motility, they can make the gut go faster
  - Ultimately, they stop the gut and give rise to long term constipation, and have to be stopped
  - They are nauseating, they change motility
- During development, if you give SSRIs to a mouse during fetal development (give it to the mother during fetal development), you get an abnormal nervous system grown in the mouse’s nervous system

**Are SSRIs contraindicated in pregnancy?**

- They are used frequently and in large numbers, large amounts in pregnancy because pregnancy is very often associated with depression
- Fortunately, they are most commonly used postpartum
  - But even then it’s a problem because SSRIs can be communicated to the child in breast milk
- There is evidence that a number of conditions are increased in the offspring of mothers who are treated with SSRIs during pregnancy
  - Such as irritable bowel syndrome
- People worry about this, but depression is potentially lethal and if you have something to treat it; sometimes you have to use it

**Do alternatives have the same effect?**

- [SNRIs (Serotonin–noradrenaline reuptake inhibitors)](https://en.wikipedia.org/wiki/Serotonin%E2%80%93norepinephrine_reuptake_inhibitor) can be efficacious
- They do have some of the same effects, but SNRIs are less selective for serotonin
  - Additionally they target [norepinephrine](https://en.wikipedia.org/wiki/Norepinephrine), and that doesn’t get you anywhere

## Defining “leaky gut” and its most common causes [1:16:45]

- Consider the context of the enterocytes
  - On the luminal side, they have a never ending barrage of  toxins, microorganisms, bacteria, viruses, food stuff that have to be absorbed
  - At the same time, they can’t be digested by these things

**How do tight junctions fit into this picture?**

- [Epithelia](https://en.wikipedia.org/wiki/Epithelium) are the cells that line cavities
- Epithelia have 3 types of [junctions](https://en.wikipedia.org/wiki/Epithelium#Cell_junctions) that hold the cells together
  - 1 – [Desmosome](https://en.wikipedia.org/wiki/Desmosome), or a spot weld, is just very tenacious
    - It’s hard to pull out this connection between cells
  - 2 – [Tight junctions](https://en.wikipedia.org/wiki/Tight_junction) have protein in the membrane on one cell that forms an attraction to the membrane across the cell transmembrane, and it obliterates the space between 2 cells
    - The function of tight junctions are to prevent material going through the channel between two epithelial cells
    - *It’s a plug in the bathtub*
  - 3 –  [Adhesion junctions](https://en.wikipedia.org/wiki/Adherens_junction) are essentially like the spot weld, but are also is contractile,
- Tight junctions are what we’re talking about with leaky gut (shown in the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/07/f5-gershon-1024x658.jpeg)

**Figure 5. Characteristics of a leaky gut.**  Image credit: [sydneygp.com.au](https://www.sydneygp.com.au/can-leaky-gut-syndrome-cause-autoimmune-problems/)

- The more of these tight junctions you have between 2 epithelial cells, the less leaky or permeable that connection is between them
  - Anything that interferes with the tight junctions can make the channel open and allow material from the lumen to get into the body, but at the same time, allow material within the body to get into the lumen
- It’s very dangerous to have material going into the lumen
  - Anything going into the lumen is lost from the body
  - If you open tight junctions in the lining of the gut, you can essentially flow out into your bowel

**Is there ever a scenario where nutrients that were absorbed now go back into the lumen?**

- Besides the obvious water and electrolytes, yes
  - And worse than nutrient loss, proteins from the body can be lost
- It turns out that underneath the lining of the gut, the capillaries are very permeable
- There’s a lot of protein in the lymph, the fluid underneath the lining
- If you open the lining of the gut, that protein gets into the GI tract
  - That’s a disease called [Exudative Enteropathy](https://medlineplus.gov/ency/article/007338.htm); you lose protein
  - People with that disease can blow up and look like balloons because edema goes all over the body; it’s terrible

**What is the most common cause of leaky gut?**

- Allergy (hypersensitivity) where the immune system is reacting and causing tight junctions to open
  - It doesn’t have to be a food allergy specifically; the allergen doesn’t have to be in the lumen (but it can be)
  - A bee sting can cause this; allergies to a bee sting are a [type I hypersensitivity](https://en.wikipedia.org/wiki/Type_I_hypersensitivity)

**How does this epithelial layer replace itself while preserving the tight junction?**

- Epithelial cells slough off every week or so and new ones replace them
- *Does this mean we have several rows of cells ready to spring into action, already tightly bound to their neighbors?*
  - Similar to what happens in a great white shark, where they have multiple rows of teeth that are constantly pushing forward to provide new ones when teeth fall out
- The lining in the small intestine, and to a lesser extent the large intestine, is arranged so that the lining is highly folded
- There are projections that come up from the surface of the gut that look like fingers (called villi, shown in the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/07/f6-gershon-1024x490.png)

**Figure 6. Anatomy of the lining in the small intestine.**  Figure credit: [OpenStax Anatomy and Physiology](https://openstax.org/books/anatomy-and-physiology/pages/23-5-the-small-and-large-intestines#fig-ch24_05_02)

- Most absorption occurs on the surfaces of these villi
- Between the villi are invaginations called crypts
- At the base of crypts there are stem cells
- The stem cells, which live next to the [Paneth cell](https://en.wikipedia.org/wiki/Paneth_cell), can give rise to each of the cells that form the villi, or line the gut.
- There’s an escalation of those cells; the progeny of the stem cells keep rising
  - As new ones form, other ones move up

- In part, the proliferation in the crypt produces a pressure that causes cells to rise as they differentiate
  - But they’re also mobile; they crawl a little bit
- If the lining of the gut is wounded, then adjacent cells can crawl over the space and cut it off
- At the tips of the villi, there’s a zone called the extrusion zone
  - Cells are born at the base of a crypt, climb up the crypt, up the villis, reach the tip of the villis, die, and are puffed off at that point
  - They stay in contact with one another, and the desmosomes are finally lost when the cells die, and they pop off
  - The mechanism of death is called [apoptosis](https://en.wikipedia.org/wiki/Apoptosis); they’re programmed to die.

**Toxins, allergies, and things like that play a role in leaky and inflamed gut cells. Are there any reputable assays that can identify what these are in an individual that has otherwise vague symptoms?**

- If somebody has a substantially leaky gut, you could guess it from making a determination of the serum protein [albumin](https://en.wikipedia.org/wiki/Albumin)
  - If the gut is leaking, albumin will be low
- You can also look for an enzyme called [alpha-1 antitrypsin](https://en.wikipedia.org/wiki/Alpha-1_antitrypsin)
  - This is a protein found on the vascular side of the gut; it’s also in the blood/ plasma
  - It’s a protease inhibitor, it inhibits [trypsin](https://en.wikipedia.org/wiki/Trypsin) (produced by the pancreas) and other proteases
  - Loss of protein into the gut is a sign of leaky gut; alpha-1 antitrypsin is a protein that is measured  as a marker for intestinal protein loss
    - If it gets onto stool there’s a problem
- Deficiency in alpha-1 antitrypsin is a hereditary disease, *what symptoms do these patients have?*
  - Vascular and lung disease, because there’s too much digestive action damaging in those organs

**Do you have to see low albumin to make the diagnosis of leaky gut?**

- Low albumin in the plasma would indicate a very significant leaky gut

**Are there milder leaks that don’t allow something as massive as albumin to escape, but do allow toxins and microorganisms in?**

- This is controversial
- Toxins are not allowed in, at  least not to a great extent (maybe a little bit)
- You can look for toxin by giving various peptides or dyes ([fluorescein](https://en.wikipedia.org/wiki/Fluorescein)) that should be excluded from blood and then look for them in the blood
- Or you can measure leaks with certain sugars that should  not be absorbed
  - If the non-absorbable sugar gets into the body, then you’d assume it’s a slight leak of this kind

**Is it thought that there is a causal relationship between leaky gut and autism spectrum disorder (ASD)? Or are these things that move together due to a similar underlying pathology?**

> “*The problem in the gut in autism spectrum disorder is [it’s] a disorder of the nervous system. It has nothing to do with leaky gut.*”‒ Michael Gershon

- Leaky gut is part of the Wakefield hypothesis
  - There is no evidence this is correct

**Is leaky gut seen more often in patients with ASD?**

- Not really
- Consider this illustration, Mike and his collaborators have a mouse called G56
  - This mouse has a mutation in the [serotonin transporter (SERT)](https://en.wikipedia.org/wiki/Serotonin_transporter)
    - SERT is what the SSRIs inhibit, and they remove serotonin from circulation (or the synaptic cleft, when it’s a neurotransmitter)
    - The mutation in this mouse does not inhibit SERT, rather it makes SERT more active‒ *this is the super-SERT mouse*
    - This animal essentially has a deficiency of serotonin; its SERT is so effective at inactivating serotonin after it’s released that it doesn’t have a chance to act
  - These mice have a smaller nervous system in the gut, too few neurons
  - They have problems in the gut, slow transit
  - There are changes in the brain
    - They don’t interact socially with other mice; if you put them in a tube with a normal mouse, the one with the mutation backs out and lets the other mouse through every time
    - They have repetitive behaviors‒ foot tapping, hitting its head against the side of the cage

***These mice have central features that look like autism***

- This abnormality is seen in about 2% of ASD patients

> “*It’s not the cause of autism, but it’s a test case*”‒ Michael Gershon

- It’s one of the many genes that can give rise to autism
- Put into a mouse, it shows autism, and also defect in the gut
  - The defect in the gut has to do with serotonin, and the ability of serotonin to act as a growth factor
  - There’s a deficiency in terms of numbers of neuronal cells in the bowel
  - In a patient with autism spectrum disorder, similar kinds of things happen
- This, by the way, is exactly the opposite effect of giving a mouse during development an SSRI
  - If you give a mother a SSRI, her pups get *too many* nerve cells growing in the gut
  - Gut motility becomes defective
- If you knock out the transporter, you have *too many nerve cells* in the gut
- If you make the transporter more active, you have *too few nerve cells* in the gut

## The gut microbiome [1:30:45]

**How many bacteria are in different parts of the GI tract?**

- We mentioned earlier the difference between the small and large intestine, one difference is the flora (aka the [normal microbiota](https://en.wikipedia.org/wiki/Gut_microbiota))
- The greatest number of bacteria are present close to the colon
- It is thought that stomach acid sterilizes, to a large extent, the food that you eat
  - Some bacteria can survive in the presence of hydrochloric acid in the stomach, such as [*Helicobacter pylori*](https://en.wikipedia.org/wiki/Helicobacter_pylori)
- The small intestine benefits from stomach acid because very few organisms are dumped into it
- The small intestine neutralizes stomach acid
- Small numbers of organisms entering the small intestine and its motility contribute to keeping the number of bacteria down in the small intestine
- There are also cells (like [Paneth cells](https://en.wikipedia.org/wiki/Paneth_cell)) which make antibacterial proteins (called [defensins](https://en.wikipedia.org/wiki/Defensin)) which help keep the lumen of the gut close to sterile
- As you get closer and closer to the colon, these mechanisms are reduced and the number of organisms increases
  - The number of  Paneth cells decline, the gut slows down
- The small intestine is separated from the large intestine by the [ileocecal sphincter](https://en.wikipedia.org/wiki/Ileocecal_valve)
- When a bolus of food gets to the colon (by then its [chyme](https://en.wikipedia.org/wiki/Chyme), it’s been digested), it spends more time in the colon

***In the colon there are huge numbers of organisms***

- There are an equal number of microbial cells in the colon as all the human cells in the body, *trillions*

**Characteristics of the bacteria in the colon**

- A lot of [Gram-negative](https://en.wikipedia.org/wiki/Gram-negative_bacteria)
- Almost all are [anaerobes](https://en.wikipedia.org/wiki/Anaerobic_organism), they live in the absence of oxygen and are hard to grow in culture
  - They are characterized through molecular biology; you look for genes

*What are the broad categories of these facultative anaerobes?*

- There are about 16 different classes
- One of the largest of them is the [Firmicutes](https://en.wikipedia.org/wiki/Bacillota)
- Ones that we think of as good are the [Bifidobacteria](https://en.wikipedia.org/wiki/Bifidobacterium) and [Lactobacteria](https://en.wikipedia.org/wiki/Lactobacillus)
- Ones that are mostly bad (but not entirely) are the [Clostridia](https://en.wikipedia.org/wiki/Clostridi)
- Some of those bacteria are related to causing cancer
- Some are highly protective, and they do stuff for us
  - For example, one of the things we eat a lot of is fiber; celery or lettuce for example, we don’t digest that
  - We have bacteria in our gut that live on that fiber, they digest it and make short chain fatty acids from it
  - Those short chain fatty acids are absorbed by the lining of the colon
  - Our colonic epithelia are dependent on the bacteria to keep going
    - They get the bulk of their energy from the bacteria in the gut
  - The bacteria also makes certain vitamins that we can’t live without;  vitamin K being the most famous of them
  - They also seem to regulate things like mood and obesity

> “*It just strikes me as one of the most poorly understood connections for something that has such a high impact on human health*”‒ Peter Attia

- Mike agrees; we are ignorant because we can’t culture most of these organisms
  - They’re extremely difficult to study
  - It goes beyond them being anaerobic (an unable to grow them in the presence of oxygen)
  - We don’t know the nutrients they need to live
  - It’s easy enough to provide them with an atmosphere without oxygen
  - It’s not so easy to figure out what they need to live

> “*The colon produces a great environment. How to match it is not so easy to figure.*”‒ Michael Gershon

- Bacteria in the gut are able to get involved with the nervous system in a way that the bacteria of the skin do not
  - For example, the bacteria that are in the gut can activate lining epithelial cells, enteroendocrine cells to release serotonin, or other factors that can signaled by way of the vagus nerves to the brain
  - Chemical products that the bacteria make can also trigger nerve signals that send signals back to the brain, or even go through the blood brain barrier to affect the brain

**What happens in mice that lack the normal microbiota?**

- Experiments can be done for example with mice, in which one can breed [germ-free mice (gnotobiotic)](https://en.wikipedia.org/wiki/Germ-free_animal); they grow up without any contact or organisms
  - They’re born by cesarean section
  - They’re fed sterile food
  - They live in incubators
  - People handle them with gloves

*What’s the phenotype of these animals after 1 year?*

- The numbers of nerve cells in their gut, the motility, the lining of the gut‒ they’re all different, much more primitive
- There are changes in their immune system; they have no immune system
  - They have almost no spleen
  - They lack [Peyer’s patches](https://en.wikipedia.org/wiki/Peyer%27s_patch), important for talking to immune cells
  - They do have a thymus and can develop an immune system in a big hurry if they survive
- These mice can be used as vessels to recolonize the gut with organisms
  - If you colonize them with bacteria derived from a strain of mice that tend to be lean, the mice grow up to be lean
  - If you colonize them with bacteria from a strain of mouse that tends to be fat, the mice grow up to be fat

> “*That seems to indicate that bacteria can determine obesity, or lack thereof*”‒ Michael Gershon

## Fecal transplants: use cases, limitations, and how they illustrate the importance of gut microbes [1:40:45]

**How does this play out in humans?  We don’t have sterile humans but fecal transplants from lean to obese have been done.**

- With humans you have to take everything with a grain of salt because the experiments are very difficult to do
  - The experiments are all flawed because you can’t deal with pure organisms
- These studies have been done
- Anxiety seems to work in a similar fashion
- [Fecal transplantation](https://en.wikipedia.org/wiki/Fecal_microbiota_transplant) has an enormous potential
- The only approved use currently is for infection with [*Clostridium difficile*](https://en.wikipedia.org/wiki/Clostridioides_difficile_infection)
  - *Clostridium difficile* is a normal component of the GI tract; many people have it, and it sits there
- With organisms that make up the normal flora, one way the number of each type is controlled is through a balance of growth with other bacteria
  - There’s a competition for nutrients
  - Bacteria make toxins that affect other types
- A problem can arise when people take antibiotics; they have a major effect on the [microbiome](https://en.wikipedia.org/wiki/Microbiome)
- A lot of people are exposed to antibiotics in agriculture
  - About 60 years ago it was found that giving antibiotics to animals will cause them to grow faster, and get bigger faster
  - You can also  keep pigs more safely in small quarters by giving them antibiotics; it reduces infection

> “*This profligate use of antibiotics in agriculture exposes the human population to antibiotics, and changes our bacteria in ways that we would never have appreciated*.”‒ Michael Gershon

**For example, Mike’s son (who is now 60) got pneumonia when he was 2**

- A culture was taken, and it was found to be pneumococcal pneumonia
- He was given penicillin to treat it, he had an allergic reaction and developed an [exudate of enteropathy](https://en.wikipedia.org/wiki/Protein_losing_enteropathy)
  - His skin peeled off, his teeth came in mottled, his hair and fingernails changed
  - He nearly died

*How did he become allergic to penicillin at age 2 when he had never had it before?*

- Mike’s wife had a bad infection, so their son had to be bottle-fed after the first month of life
  - He had cow’s milk for a long time, nothing wrong with that
  - But now cow’s milk comes with penicillin in it because the agricultural industry treats with penicillin
  - His sone developed an allergy to penicillin
- Mike discovered many years later that he too is allergic to penicillin
  - This genetic susceptibility contributed to his son developing the same allergy
- He speculates that had his son been breast fed normally, the first time he got penicillin is when he would have been sensitized (the prerequisite for developing a [type I hypersensitivity](https://www.ncbi.nlm.nih.gov/books/NBK560561/))
- His son was exposed to penicillin in a way they never knew about
- These antibiotics in foods are affecting the microbiome

**Back to fecal transplants, how does this treat a** ***C. diff.*** **infection?**

- - The procedure is not zero-risk, even though in the case of *C. diff*, it’s life-saving
  - Patients often develop a *C. diff* infection after taking antibiotics
    - Antibiotics knock out the bulk of bacteria in their large intestine

- *C. diff* is resistant to these antibiotics so it emerges as the dominant bacteria

- *C. diff* produces a toxin that causes massive diarrhea
  - This can wipe you out very similar to the way cholera toxin does
  - It works in a different way by targeting the nervous system
- The first step to cure *C. diff* is to take [oral vancomycin](https://en.wikipedia.org/wiki/Clostridioides_difficile_infection#Medications); *C. diff* is sensitive to this antibiotic
- 25% of patients don’t respond to oral vancomycin, or the *C. diff* infection reoccurs and they can’t get rid of it, then the only thing that can be done is a fecal transplant
- Fecal transplant can be done as an enema, or an enteric-coated capsule
- Bacteria recolonize the antibiotic wiped-out gut
  - These bacteria then suppress growth of *C. diff*
  - This procedure is life-saving and it’s approved

**Difficulties with fecal transplantation**

- The stool used for fecal transplant has to be very carefully looked at to be sure it doesn’t contain any potentially dangerous organisms
  - There are perhaps 500 species of organism in your gut that are potentially lethal
- In the past, people were transplanting from husband to wife and doing these home-brews
  - A few patients were lost this way; it was not good

**Is there any potential for using synthetic biology to create the microorganism for transplant, so you could control exactly what people are given?**

- Most of the organisms in the large intestine cannot be grown in the laboratory so this can’t be done
- Mike notes, “*If you can’t grow them, you can’t produce them in such a way as to synthesize them*.”
- Knowing their genetic sequence is not enough

>  “*There is a huge amount of modern GI biology going into study of the GI microbiome*”‒ Michael Gershon

## Gut microbiome diagnostic tests: why they aren’t useful outside of special cases such as cancer detection [1:50:30]

**What about commercial home kits that tell you about your microbiome?**

- This field seems to be full of a lot of nonsense
- There was that company out of UCSF called [uBiome](https://en.wikipedia.org/wiki/UBiome) that turned out to be an outright [fraud](https://www.fiercebiotech.com/medtech/ubiome-co-founders-charged-fraud-by-sec)
- The promise was that if you gave them a stool sample, they would send you a lengthy report of what your gut microbiome is

*Are they able to do this accurately?*

- They can give you the classes or organisms and the % of total bacteria each of the classes represent
  - This turns out to be remarkably un-useful
- You need to know species by species, at a very fine level of detail before you have information you can really do something with

***Far too little resolution is being provided by these tests***

**Mike summary**: *You can say you can change anxiety; you can change body form with the microbiome. But to say that you can go look at the microbiome and then determine what that is, is not yet there*.

- The best kits he knows of are the ones that look for cancer, such as [Cologuard](https://www.cologuard.com/?gclid=Cj0KCQjw06OTBhC_ARIsAAU1yOUbUhJiVKIYRkL77YlcJEM20Fjw3lO7FcVl_w6uN8M-L5GHMUVAs-QaAsueEALw_wcB&gclsrc=aw.ds)
  - As the cells age and undergo apoptosis, they’re sloughed off into the lumen
  - Human DNA is in the lumen of the gut, as well as bacterial DNA
  - [What Cologuard does](https://medlineplus.gov/ency/article/007747.htm) is look at stool, at the DNA in the stool; it looks for the genetic signatures of a number of GI cancers
  - About 90% of GI cancer and be picked up effectively by Cologuard; it’s wonderful, it’s a great advance
- But using this test doesn’t mean you don’t have to go also do colonoscopy
  - The goal of a colonoscopy is to find a polyp that’s going to become cancer, not wait until you have cancer
- The problem with Cologuard is you may miss 10% of cancer; you don’t want that to happen

**Mike’s take on these commercial tests**:  *because they’re not doing it* [testing] *at a level that is sufficiently documented and sufficiently informative for you to be actionable on that information, they cost money abnormally, and they change what you do for reasons that are not well documented‒ you shouldn’t be following them yet.*

- Peter notes that a lot of these tests are paired with supplements, or probiotics, or prebiotics that are supposed to “fix the defects found in the test”; it’s a RxDx model

> “*What they’re really doing is making money. I think they’re a con*.”‒ Michael Gershon

- Peter notes that after a decade of looking at these test results in patients that have been adamant about having them done, he’s still looking for a great example of where it mattered
  - He worries there is a lot of noise created without a signal

## Nutritional approaches to a maintain optimal flora in the gut [1:55:00]

**Peter’s takeaway**: *One of the most important things nutritionally that people can do to make sure that they have the optimal flora for their gut*

- This is important for (1) general health maintenance and (2) after taking antibiotics
- Antibiotics are going to save our lives from time to time
- Peter has found himself more reluctant to take them; he resists as long as possible

**The role of nutrition in a healthy gut microbiome**

- From a general maintenance principle, for someone who is not taking a lot of antibiotics and wants to do what’s best for your gut, nutrition is one of the most important levers

> “*The best kind of diet is a balanced diet*”‒ Michael Gershon

- A balanced diet is better than the [South Beach Diet](https://en.wikipedia.org/wiki/South_Beach_Diet), or one of those diets for losing weight
- Having a balanced diet with appropriate nutrients, including vitamin C, and particularly fiber is good for your body
  - There’s no reason to have an excess of vitamin C
- Mike would be opposed to having a particular diet for cleansing, for example
- The microbiome is something we live with; it has evolved with humans for as long as there have been humans

> “*Cleansing the inside of the gut is not a good thing to be doing”‒* Michael Gershon

- Peter has heard of many variants of gut cleansing
- One method is done in preparation for a colonoscopy; *how much does this alter the gut flora?*
  - Even though it’s purpose is simply mechanical removal of all stool matter to allow visibility for an endoscopy
  - Mike replies that this type of cleanse “*doesn’t kill organisms or change the balance between them*”
- When people do dietary cleanses, they’re usually drinking a lot of water with pepper and presumably some nutrients; *is this similar to doing a bowel prep?*
  - Mike notes that sometimes they supplement this with enemas
  - He worries about these people getting into electrolyte imbalance
  - They are not killing the bacteria
  - But they’re not doing their body a favor by eating strange foods

**The importance of insoluble fiber in the diet**

*If people don’t eat much or any insoluble fiber, will this change their gut bacteria or impact their health negatively?*

- Not much research has been done on the negative impact of low fiber
- Research has focused on the health benefits of fiber and has found
  - 1 – fiber can absorb toxins; it is thought to decrease their long-term carcinogenic effects
  - 2 – It provides the colon something to “chew down on”; it’s good for motility and keeping the bowel going and in shape
  - 3 – It provides food for bacteria of the colon
    - These bacteria produce [short-chain fatty acids](https://en.wikipedia.org/wiki/Short-chain_fatty_acid), which are good for the lining of the gut
    - They also produce energy; a small amount can be absorbed and used by epithelial cells in the gut
- Fiber and polysaccharides are the most important  nutrients for fueling the bacteria of the gut
- These bacteria can live on everything that makes its way to the large interesting
  - Very little of the protein you eat gets to the colon

**What is the impact of artificial sweeteners or non-nutritive additives to food on the gut microbiome?**

- There are bacteria that can metabolize these molecules
- The net effect of this is not clear
- The literature on this is self-contradictory
  - Some people think there are impacts
  - Some people think the effect is negligible

**How many fatty acids make their way to the colon?**

- Most of the fatty acids that get to the colon are derived from fiber
- Usually they’re not exogenous, but not always
- Under abnormal conditions in which bile salts or pancreatic enzymes are deficient, then exogenous fats can get into the colon, and one gets fatty stool
  - Bacteria can’t metabolize that
- In celiac disease, for example, there’s a lot of fat in the stool
- In biliary tract disease, there’s often a lot of fat in the stool
  - The stool is described as greasy and foul smelling, because the bacteria do metabolize it

## Prebiotics and probiotics, and getting your GI system back on track after a course of antibiotics [2:02:30]

***If a person has to take a long course of antibiotics, what can they do to appropriately repopulate their gut?***

- Probably taking appropriate probiotics at the same time they’re taking those antibiotics, or afterward, is helpful

*What constitutes appropriate probiotics?*

- It varies; some people think that yeast-derived [*Saccharomyces*](https://en.wikipedia.org/wiki/Saccharomyces) is good
- Some people swear by [*Lactobacilli*](https://en.wikipedia.org/wiki/Lactobacillaceae) or [*Bifidobacteria*](https://en.wikipedia.org/wiki/Bifidobacterium)
- There is [evidence](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2868213/) that taking *Saccharomyces* at the same time as antibiotics can lessen the GI upset and complications

*What’s the difference between a pro and a prebiotic?*

- Probiotic is defined as an organism that has beneficial effects; you eat them
  - For example, Mike eats [Activa](https://www.activia.us.com/probiotic-yogurt/) every day now that he is older; it fights the problems of aging
    - He consults for Dannon
    - When he mentioned Activia, that doesn’t mean this is better than any other yogurt, it’s just one he knows about
- Prebiotic is defined as material that will enable the body to grow organisms that have beneficial effect
- The difference between them is that prebiotic enables you to make your own healthy organisms
- Fermented foods are probiotics
  - Yogurt is fermented
  - Additionally, something like Activia has [*Bifidobacterium animalis*](https://en.wikipedia.org/wiki/Bifidobacterium_animalis) in it, which actually survives the stomach acid, goes down the GI tract, and comes out in the stool
    - This is an [aerotolerant anaerobe](https://en.wikipedia.org/wiki/Aerotolerant_anaerobe)
    - It can get down in the gut and survive in the stool

> “*The importance of the probiotic is not only that it be there, but that it survive and do something in the GI tract.*”‒ Michael Gershon

**How can people navigate this world?**

- - There is a lot of opportunity for charlatans to sell you things that don’t have the bacteria they claim
    - Maybe the bacteria is dead
    - Maybe it doesn’t survive the transit from mouth to colon
  - You can trust the [FTC](https://en.wikipedia.org/wiki/Federal_Trade_Commission) and the [FDA](https://en.wikipedia.org/wiki/Food_and_Drug_Administration); claims cannot be made for foodstuff like a probiotic that are medical, unless it has been subjected to actual tests and pass FDA muster to show efficacy and safety
    - Most of what they call probiotic or prebiotic has not done that
  - Foodstuff, then, is regulated through the advertising by the FTC
  - For the yogurt Activia, the FTC looked very carefully at the claims made for that product, and wanted to see and carefully evaluate all of the evidence
    - Mike is a consult for Dannon and was called to testify for a hearing
    - In order to make the claims that Dannon makes for that product, they actually have to demonstrate to the FTC that they have the evidence that it does what they say it does
    - They say that if you eat as much as two cups a day of Activia, it will cause the GI tract to speed up
      - The answer is it will

- *How many* [*colony-forming units*](https://en.wikipedia.org/wiki/Colony-forming_unit) *are provided in that?*

- - - Mike is not sure, something on the order of 1011

**When it comes to getting your GI system back on track after a course of antibiotics, what are the most important elements to look for in the probiotic?**

- - Simply the ability to colonize the GI tract

- *Saccharomyces* works very well

*Do the pills need to be stored in the refrigerator?*

- Not necessarily, the probiotic just needs to survive; this depends on the probiotic
  - *Bifidobacterium animalis*, which is in Activia, has to be refrigerated; but so does the Activia, because it’s yogurt-based
- It does not need to contain a specific *Lactobacillus*, just the ability to colonize the GI tract
- *Saccharomyces* works very well in that case
  - Mike comments, “*That’s the one I’m trying to think of the trade name for*.”
  - It’s well-known, it’s a yeast-derived product, it’s [available over the counter](https://www.florastor.com/florastor-daily-probiotic-supplement-v768413.html)
  - [Florastor® by Biocodex Inc.](https://www.biocodex.us/en/our-products/microbiota/florastor-2/) contains [*Saccharomyces boulardii*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7344949/)

**Peter’s takeaway**: *It just seems to me that the big opportunity here is going to come with the bioengineering that’s necessary to grow these bacteria in culture. That seems to be just an enormous blind spot we still have in this space, both from a diagnostic standpoint, but also from a therapeutic standpoint*.

§

## Selected Links / Related Material

**Michael’s book**: [*The Second Brain: A Groundbreaking New Understanding of Nervous Disorders of the Stomach and Intestine*](https://www.amazon.com/Second-Brain-Scientific-Groundbreaking-Understanding/dp/0060182520/ref=sr_1_2?crid=1WFTA9NNZ0ZXM&keywords=The+Second+Brain%3A+A+Groundbreaking+New+Understanding+of+Nervous+Disorders+of+the+Stomach+and+Intestine&qid=1648821166&sprefix=the+second+brain+a+groundbreaking+new+understanding+of+nervous+disorders+of+the+stomach+and+intestine%2Caps%2C109&sr=8-2) by M Gershon (1998) | [1:15, 16:45]

**Primer on disease caused by varicella-zoster virus**: [Varicella zoster virus infection](https://www.nature.com/articles/nrdp201516) | *Nature Reviews Disease Primers* (AA Gershon *et al.* 2015) | [55:00]

**Reemergence of VZV in the esophagus**: [Association of Achalasia With Active Varicella Zoster Virus Infection of the Esophagus](https://pubmed.ncbi.nlm.nih.gov/33932481/) | *Gastroenterology* (RD Naik *et al.* 2021)  | [1:00:15]

**Discussion of Andrew Wakefield’s fraudulent publication on autism**:  [#158 – Brian Deer: A tale of scientific fraud—exposing Andrew Wakefield and the origin of the belief that vaccines cause autism](https://peterattiamd.com/briandeer/)| Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (August 10, 2020) | [1:05:15]

**Review of alpha-1 antitrypsin**: [The discovery of α1-antitrypsin and its role in health and disease](https://www.sciencedirect.com/science/article/pii/S0954611111000515) | *Respiratory Medicine* (SM Janciauskiene *et al.* 2011) | [1:24:30]

**Microbiota in the human gut**: [Introduction to the human gut microbiota |](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5433529/) *Biochemical Journal* (E thursby and N Juge 2017) |  [1:34:30]

**Fecal transplant overview**: [Fecal microbiota transplantation: Review and update](https://www.sciencedirect.com/science/article/pii/S0929664618305552?via%3Dihub) | *Journal of the Formosan Medical Association* (JW Wang *et al.* 2019) | [1:47:30]

**Benefits of taking** ***Saccharomyces*** **as a probiotic with a course of antibiotics**: [Systematic review and meta-analysis of *Saccharomyces boulardii* in adult patients](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2868213/) | *World Journal of Gastroenterology* (LV McFarland 2010) | [2:03:00]

**Probiotic containing the** ***Saccharomyces*** **used in the following study**: [Florastor®, Biocodex Inc.](https://www.biocodex.us/en/our-products/microbiota/florastor-2/) (2021) | [2:07:45]

- [Prospective randomized controlled study on the effects of *Saccharomyces boulardii* CNCM I-745 and amoxicillin-clavulanate or the combination on the gut microbiota of healthy volunteers](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5341914/) | *Gut Microbes* (TA Kabbani *et al.* 2017)

- **Review of this bacteria**: [*Saccharomyces boulardii*: What Makes It Tick as Successful Probiotic?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7344949/) | *Journal of Fungi* (P Pais *et al.* 2020)

**Michael’s faculty webpage**: [Michael D. Gershon, MD](https://www.cuimc.columbia.edu/mdphd/profile/mdgershon) | Columbia University Medical Center (2020)

**The New York Times article about Mike’s book**: [The Other Brain Also Deals With Many Woes](https://www.nytimes.com/2005/08/23/health/the-other-brain-also-deals-with-many-woes.html) | Harriet Brown, *The New York Times* (August 23, 2005)

§

## People Mentioned

- [Leopold Auerbach](https://en.wikipedia.org/wiki/Leopold_Auerbach) (19th century German anatomist and neuropathologist) [19:00]
- [William Bayliss](https://en.wikipedia.org/wiki/William_Bayliss) (early 20th century British physiologist) [19:45]
- [Ernest Starling](https://en.wikipedia.org/wiki/Ernest_Starling) (early 20th century British physiologist)  [19:45]
- [Rudolph (Rudy) Leibel](https://www.cuimc.columbia.edu/mdphd/profile/rlleibel) (Professor of Medicine at Columbia University, studies genetics of obesity) [47:30]
- [Michael (Mike) Rosenbaum](https://www.pediatrics.columbia.edu/profile/michael-rosenbaum-md#research) (Professor of Medicine at Columbia University) [47:30]
- [Anne Gershon](https://www.ihn.cuimc.columbia.edu/profile/anne-gershon-md) (Professor of pediatrics at Columbia University) [54:45, 58:15, 1:45:00]
- [Andrew Wakefield](https://en.wikipedia.org/wiki/Andrew_Wakefield) (British Gastroenterologist published fraudulent study on autism) [1:05:00, 1:09:15, 1:26:45]

§

![](https://peterattiamd.com/wp-content/uploads/2022/07/bio-pic-gershon-500x500.jpg)

##### Michael Gershon, M.D.

Michael Gershon, M.D. is a Professor of  Pathology and Cell Biology at Columbia University.  He earned his medical degree from Cornell University, followed by a postdoctoral fellowship at Oxford.  He has been called the “father of neurogastroenterology” because of his seminal work on neuronal control of gastrointestinal (GI) behavior and development of the enteric nervous system (ENS) and his efforts to raise awareness of the unique ability of the ENS to regulate GI activity in the absence of input from the brain and spinal cord.  To this end, he authored the book, *The Second Brain*, which has become a trade classic.  Dr. Gershon has published almost 400 peer-reviewed papers.  He has made major research contributions expanding our understanding of disorders of GI motility, irritable bowel syndrome, the role of serotonin as a GI neurotransmitter, and the ability of gut intrinsic sensory nerve cells to trigger propulsive motor activity.  Gershon discovered that the serotonin transporter (SERT) is expressed by enterocytes (cells that line the lumen of the gut) as well as by enteric neurons and is critical in the termination of serotonin-mediated effects. has identified roles in GI physiology that specific subtypes of serotonin receptor play and he has provided evidence that serotonin is not only a neurotransmitter and a paracrine factor that initiates motile and secretory reflexes, but also as a hormone that affects bone resorption and inflammation. He has called serotonin “a sword and shield of the bowel” because it is simultaneously proinflammatory and neuroprotective. Mucosal serotonin triggers inflammatory responses that oppose microbial invasion, while neuronal serotonin protects the ENS from the damage that inflammation would otherwise cause. Neuron-derived serotonin also mobilizes precursor cells, which are present in the adult gut, to initiate the genesis of new neurons, an adult function that reflects a similar essential activity of early-born serotonergic neurons in late fetal and early neonatal life to promote development of late-born sets of enteric neurons. Dr. Gershon has made many additional contributions to ENS development, including the identification of necessary guidance molecules, adhesion proteins, growth and transcription factors; his observations suggest that defects that occur late in ENS development lead to subtle changes in GI physiology that may contribute to the pathogenesis of functional bowel disorders. More recently, Drs. Michael and Anne Gershon have demonstrated that varicella zoster virus (VZV) infects, becomes latent, and reactivates in enteric neurons, including those of humans. They have demonstrated that “enteric zoster (shingles)” occurs and may thus be an unexpected cause of a variety of gastrointestinal disorders, the pathogenesis of which is currently unknown. [[Columbia University Irving Medical Center](https://www.cuimc.columbia.edu/mdphd/profile/mdgershon)]