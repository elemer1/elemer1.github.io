# #322 – Bone health for life: building strong bones, preventing age-related loss, and reversing osteoporosis with evidence-based exercise | Belinda Beck, Ph.D.

**Source:** [https://peterattiamd.com/belindabeck/](https://peterattiamd.com/belindabeck/)

---

Belinda Beck, founder of [The Bone Clinic](https://theboneclinic.com.au/) and a leading authority on exercise physiology and bone health, delves into the science of osteoporosis, bone density, and the lifelong importance of maintaining skeletal health. In this episode, she explains how the foundation for strong bones is established during childhood, offering valuable advice for parents on optimizing bone health for their kids. She also explores how bone remodeling occurs throughout life, driven by activity, nutrition, and hormones. Belinda highlights the power of resistance training in improving bone strength, even for those at risk of bone loss, and emphasizes the role of essential vitamins and minerals in maintaining bone health. She shares practical strategies, backed by research, for preventing fractures and combating osteoporosis.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/belindabeck/the_Drive_public.png)

Play

#322 - Bone health for life: building strong bones, preventing age-related loss, and reversing osteoporosis with evidence-based exercise | Belinda Beck, Ph.D.

#322 - Bone health for life: building strong bones, preventing age-related loss, and reversing osteoporosis with evidence-based exercise | Belinda Beck, Ph.D.

1x15s30s

0:001:39:49

## We discuss:

- Belinda’s journey into bone health research and training [2:45];
- The physiology of bone, and how bones adapt to mechanical loading [8:15];
- Bone development from birth to adulthood, why early life is a crucial period, the functions of osteoblasts and osteoclasts, and gender differences in BMD [14:00];
- How parents can optimize their children’s bone health through diet (calcium and vitamin D), sunlight exposure, and physical activity [27:30];
- The best sports and activities for promoting bone health, weight training for kids, and advice for parents [36:30];
- The impact of corticosteroid use on bone health in children and strategies to minimize the negative effects [48:30];
- Advice for people in middle age to preserve bone density: physical activity and bone-loading exercises [52:00];
- Bone loss during the menopause transition for women: hormone replacement therapy and other strategies to mitigate BMD losses [59:30];
- Interpreting the bone mineral density results from a DEXA scan: T-score, Z-score, and more [1:03:00];
- The LIFTMOR study: testing the effects of heavy weightlifting on bone health in postmenopausal women with low bone density [1:10:15];
- Profound benefits of weight training outside of BMD improvements: exploring the broader impacts on patients in the LIFTMOR study [1:19:30];
- Guidance for people wanting to use exercise designed to improve their bone health [1:29:30]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Belinda Beck is a professor of exercise science in the School of Health Sciences & Social Work at Griffith University in Queensland, Australia
- Her research is primary related to the effects of mechanical loading on bone
- In 2015 she established [The Bone Clinic](https://theboneclinic.com.au/) to roll out this ground-breaking program of research that we discuss in detail in this podcast
- She was the principle investigator of the [LIFTMOR](https://pubmed.ncbi.nlm.nih.gov/28975661/) and the [LIFTMOR-M](https://pubmed.ncbi.nlm.nih.gov/32176813/) clinical trials which demonstrated exercise as therapy for osteoporosis and low bone mass
- We dive into the physiology of bone
  - It’s important that you understand how bone works as a tissue
  - It’s easy to think of it as a static tissue, but it’s quite a reactive tissue
- We talk about how the foundation is set during childhood, and how the remodeling over the course of one’s life takes place based on activity, nutrition, and hormones
- We then talk about what can be done to prevent bone loss as we age
  - This begins with what we as parents should be doing to help our kids achieve their genetic potential prior to the fusion of their growth plates
- We talk about how to improve your bone health
  - Even once you’re past the point of your genetic potential, once you’ve reached your maximum point in your late teens and early ‘20s
  - What we can learn from the LIFTMOR studies in terms of how exercise can help and even reverse bone loss in people in the throws of osteopenia and osteoporosis

## Belinda’s journey into bone health research and training [2:45]

- Belinda was a runner and field hockey player, and she constantly suffered from sore shins and nobody could help her
  - Or tell her why she was getting them, much less how to prevent them or make them better
- In high school she knew she wanted to find out what was going on, and that’s where her research started
- In her Master’s she looked at **tibial stress injuries**: it became clear very, very early that this is a bone injury
  - This is not what everybody was saying: 2 hours posterior pulling on the border of that was all bunkum
- That set her down the path of figuring out what are the mechanical signals that stimulate bone to adapt to mechanical loading, pursuit of [Wolff’s Law](https://en.wikipedia.org/wiki/Wolff%27s_law)
  - Why does a change in mechanical loading cause the bone to change shape in this amazing way?
- As soon as she discovered bone did that, she was hooked (it’s an incredible tissue)
- She did an animal study for her PhD and quickly realized that that was not something she wanted to do for the rest of her life because it involved killing animals constantly
- She went to Stanford and did a postdoc and that’s where she learned about clinical trials

***She realized that osteoporosis is the greatest burden when it comes to bone problems***

> “*Being an exercise head, that’s something that I wanted to figure out ‒ exactly what was the ideal exercise program to assist people living with osteoporosis.*”‒ Belinda Beck

- Before the podcast, Peter figured out that they overlapped at Stanford for the entire 3 years of her postdoc (he was in medical school)

**Belinda’s clinical practice and research**

- She is not a clinician
- She’s an exercise physiologist and she’s never had a personal clinical load
  - Although exercise physiology is one of the allied health professions in Australia
- She came back to Australia to an academic position and has been teaching anatomy her whole professional career, but also continued bone research
- She’s a [professor at Griffith University](https://experts.griffith.edu.au/18574-belinda-beck) on the Gold Coast in Queensland

***Her career triangulated onto this question: there must be a way to load people who have osteoporosis in such a way that they can grow bone because everybody had been saying we couldn’t do that because their bones were so fragile***

- She’ll come back to the actual trials
- She realized, “*The nature of the exercise was not really safe for just anybody. And it needed to be applied in a certain way and very specifically. And it needed to be applied by somebody who really knew what they were doing because this is not a program that should be done unsupervised if you’re at high risk of fracture. And the only way to do that was to implement it in a clinic.*”
- Now, it’s hard enough to convince doctors who’ve been telling osteoporotic patients for years that they should not lift anything heavy
  - But to tell somebody in a clinic to start doing this exercise, she knew that was never going to happen
- This is why she set up [The Bone Clinic](https://theboneclinic.com.au/)
  - It’s a clinical and translational research facility where this program is implemented
  - Every patient that comes in is a research participant, and they agree to share their data
    - They do the same testing as was done in the [LIFTMOR trial](https://pubmed.ncbi.nlm.nih.gov/28975661/)

*Patients at The Bone Clinic*

- The initial appointment is 2.5 hours where baseline data is collected
- Then every year thereafter, patients are tested again with the same thing to see if the exercise program works in the real world
- Patients are also advised on things like diet
- This is not a clinical trial as there is no control group

***She has gathered an enormous amount of data***

## The physiology of bone, and how bones adapt to mechanical loading [8:15]

- Peter doesn’t recall getting much of an education on this, but given the ubiquity of [osteopenia](https://en.wikipedia.org/wiki/Osteopenia) and [osteoporosis](https://en.wikipedia.org/wiki/Osteoporosis), this is important for many physicians
  - [Discussed further in [AMA #37: Bone health](https://peterattiamd.com/ama37/)]

**A basic way to describe bones is according to their shape**

- Shape is completely related to function, the basis of [Wolff’s Law](https://en.wikipedia.org/wiki/Wolff%27s_law)
- You have **long bones**, like the long bones, the levers in your limbs and your feet and hands
- You have **short bones** like the little lumpy bones in your ankles and wrist
- You have **irregular bones** like your vertebrae and your scapula and so on

*All of them are comprised of 2 basic kinds of bone*

- 1 – Cortical bone is typically the shell of a bone
  - Every bone has cortical bone on the outside
  - It might be very thin in the case of vertical bone or it might be extremely thick as in the shaft of the diaphysis of the femur
  - Cortical bone is also called compact bone
- 2 – Most bones have some degree of trabeculae or trabecular bone in them
  - If it’s a [long bone](https://en.wikipedia.org/wiki/Long_bone), it’s in the ends
  - If it’s a [short bone](https://en.wikipedia.org/wiki/Short_bone), it fills the whole thing
  - If it’s an [irregular bone](https://en.wikipedia.org/wiki/Irregular_bone) (like a vertebrae), it fills the whole body of irregular bone
  - If it’s in the skull, it’s called [diploë](https://en.wikipedia.org/wiki/Diplo%C3%AB) and it’s sandwiched in between 2 layers of cortical bone
    - Ribs even have diploë (they’re a [flat bone](https://en.wikipedia.org/wiki/Flat_bone)) as well
  - Trabecular bone is also called spongy, or cancellous bone

![](https://peterattiamd.com/wp-content/uploads/2024/10/f1-belindabeck.png)

**Figure 1. (A) Anatomy of a long bone and (B) a flat bone**. Image credit: [OpenStax Anatomy and Physiology](https://openstax.org/books/anatomy-and-physiology/pages/6-3-bone-structure)

*The cool thing about the bone tissue itself is the microstructure*

- In **cortical bone**, you have a lamella structure, so layers and layers of bone, and that occurs because of the way [osteoblasts](https://en.wikipedia.org/wiki/Osteoblast) lay down bone [shown in the figure below]
  - In each adjacent layer, the collagen is laid down almost but not perfectly perpendicular to each other so that the lamellae combined ***to create a tissue that is beautifully resistant to torsion as well as the normal loading of compression and tension***

![](https://peterattiamd.com/wp-content/uploads/2024/10/f2-belindabeck.png)

**Figure 2. Cross-section of the femur showing details of cortical/ compact bone**. Image credit: [OpenStax Anatomy and Physiology](https://openstax.org/books/anatomy-and-physiology/pages/6-3-bone-structure)

- In **trabecular bone**, there are also some lamellae because of the way osteoblasts produce bone
  - Each individual strut is best aligned to the forces that are put on bone
- If you look at a cross section through the proximal femur [in the figure below], you’ll see that there’s wonderful arches that go all the way from the head through the neck and down past the greater trochanter
  - And from the greater trochanter, there are trabeculae that come from the surface of the trochanter and arch down to the other side and over towards the lesser trochanter

![](https://peterattiamd.com/wp-content/uploads/2024/10/f3-belindabeck-1024x680.jpeg)

**Figure 3. Cross-section of the proximal femur showing details of trabecular/ spongy bone**. Image credit: [OpenStax Anatomy and Physiology](https://openstax.org/books/anatomy-and-physiology/pages/6-3-bone-structure)

***You get this interconnection of bone that is beautifully arranged to best withstand the bending load that you will get from the opposition of the weight of the body on the head of the bone and the ground reaction force coming up the diaphysis, and that repeats itself throughout the body***

> “*If you look at any part of the body where trabeculae are, they’re just aligned in response to the forces, and that’s one of the things that will change if you change the nature of the loading*.”‒ Belinda Beck

**Explain Wolff’s Law and its relevance to bone**

- It has been paraphrased over the years to mean that bone will adapt to the nature of loading to which it is chronically exposed, and the purpose being that it’s best adapted to withstand forces to prevent fracture
- In actual fact, Belinda couldn’t recount what his actual law is because he was a mathematician and he was trying to describe this mathematically

***We’ve taken that notion and just encapsulated it into that law of bone adaptation in response to loading***

Peter asks, “*Now, is there a built-in assumption to Wolff’s Law that that adaptation can only happen in the setting of certain physiologic parameters being met? So for example, sufficient calcium, healthy osteoblasts, absence of certain disease pathology, or is this truly a universal law that is indeed axiomatic?*”

- Nobody knows that answer for sure, but Belinda believes that is true
- This is a physical phenomenon of how bone reacts to loading

## Bone development from birth to adulthood, why early life is a crucial period, the functions of osteoblasts and osteoclasts, and gender differences in BMD [14:00]

**Start at birth and talk about what the bones are like in a fetus and how they develop over the ensuing two decades**

*Talk a little about the difference between an osteoblast and an osteoclast and also how mineral makes it way into the bone*

- We start as a little cartilaginous model of a skeleton, and even by 8 weeks, we have that model in that tiny little bean, and that is progressively mineralized as it becomes skeleton
- There are 2 different ways of [ossification](https://en.wikipedia.org/wiki/Ossification), but the primary one is [endochondral](https://en.wikipedia.org/wiki/Endochondral_ossification)
- Once a baby is born, they have ossified the long bones, a portion of their skull bones, and most of the other bones that are around organs

***Ossification is this process of putting mineral into the cartilage and turning it from soft into hard***

- We talk about ossification when bone cells invade the cartilage, and once there’s a [bone cell](https://en.wikipedia.org/wiki/Osteoblast) in there, it’s considered to be ossified
  - The bone cell starts to excrete osteo, which then becomes mineralized
- Babies are not born fully ossified
  - They still have little cartilaginous hands and feet and they have lots of cartilage to different degrees in their skull bones, and those continue to ossify throughout life
- Some of our growth plates don’t even fuse until men are about 25 years old
- But largely most of your bones are fully formed and have bone in them by the time you are 2
  - And that’s coinciding with when you’re really starting to run around and load the skeleton
- The skeleton then continues to grow throughout the first 2 decades with the vast majority of growth happening when you’re very little toddlers and during puberty (what we all know as the growth spurt)

*During a growth spurt*

- That happens around age 12 for girls, and age 13-14 for boys
- It slows and ends around age 18 for girls and as late as age 25 for boys
- Once you have reached your peak bone growth there, your [epiphyses](https://en.wikipedia.org/wiki/Epiphysis) have joined to your [diaphysis](https://en.wikipedia.org/wiki/Diaphysis); the growth plates are fused [shown in the figure below]
  - You’re not going to grow anymore
  - And you almost certainly have all the bone that you’re ever going to have

![](https://peterattiamd.com/wp-content/uploads/2024/10/f4-belindabeck.png)

**Figure 4. Location of the epiphysis and diaphysis in a long bone**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Epiphysis)

> “*There’s definitely a ‘making hay while the sun shines’ mantra of those of us who work in the world of osteoporosis, because childhood is so incredibly important, people often call osteoporosis a childhood disease.*”‒ Belinda Beck

**Belinda explains, “*****The goal is to get as much bone as you possibly can.*****”**

- That’s limited by your genetics, and we can come back and talk about that if you want, but you do have a blueprint that you will achieve
- You want to get as much of that genetic capacity as you have

**Peter wants to make sure nobody misses this point: osteoporosis is a childhood disease**

- What she means is you will reach your maximum bone potential by the time your growth plates fuse
  - For most people this is probably late teens, maybe in the case of men, early 20s
- In that sense, it’s sort of like a glider: it’s sort of like saying this glider will reach its maximum altitude 20 years into your 80 or 90 year life, and you better get it really, really high because the best we can do is reduce the rate at which it declines
- But we’re not going to get it higher than it was at that point
- We’ll come back to this later because Belinda is going to tell us that maybe we can change the elevation of the glider later in patients with osteoporosis

***Anyone thinking about osteoporosis should also be thinking about it for their kids and asking the question, “What are my 10-year olds, 12-year olds, 15-year olds doing today to reach their genetic potential?”***

- Belinda agrees, that is one of the strongest messages
- She speaks mainly to older people and says, “*The horse may have bolted for you, but you have children and grandchildren, and this should be your mantra, get them outside and active every single day and doing X, Y, Z bone friendly activities*.”
- She explains further, “*When we talk about peak bone mass being achieved, we use the word end of the second decade because that’s the average between men and women. It can creep up a little bit, but nobody is growing any more bone after age 30, and most people are well and truly done by then.*”

***This is somewhat of an old-fashioned view because there is capacity to get the glider higher later in life, but the concept is you’re not going to grow the length of bone anymore, and growing bone becomes a lot more difficult***

**Contribution of genetics to bone density**

- Genes determine it’s been 70-80% of the bone that you’re going to have
  - This is an extremely important message
- So to a certain extent, you are working within some reasonably tight bounds

***You only have to look at your parents and grandparents to get an idea of what your risk is like ‒ if they are very osteoporotic, then your risk is also very high***

**How bone density is measured**

- The trouble is we measure it by bone density using a bone sonometer
- That is our proxy for bone mass because the only way to measure bone mass is to actually ash the bone, and you can’t do that in a living person
- Bone has been variously measured throughout the decades, and [BMD [bone mineral density]](https://en.wikipedia.org/wiki/Bone_density) is the most common way to do it

**If you look at BMD plots over the lifespan**

- You’ll see growth in childhood and then a plateauing and then a gradual loss
- And that flattening, plateauing or timing of loss is also genetic and individual, but that’s the thing that is most amenable to exercise intervention
- So somebody might have genes that allows them to get a peak bone mass of a certain amount that is the same as their neighbor, but because their rate of loss is different and their level of activity is different, they may lose more quickly
- Then you throw in [menopause](https://en.wikipedia.org/wiki/Menopause) (average age about 52 to 54 or something), and for women, you’ll see that loss rapidly accelerate for probably 5-8 years
  - This is because circulating estrogen almost vanishes from your blood
  - And estrogen is an incredibly important hormone for bone because of its effect on osteoclast: it largely inhibits osteoclast
    - It keeps a check on them and prevents them from over absorbing

**Cells responsible for remodeling bone**

- There are a number of different cells in bone

![](https://peterattiamd.com/wp-content/uploads/2024/10/f5-belindabeck.png)

**Figure 5. Four types of cells found within bone**. Image credit: [OpenStax Anatomy and Physiology](https://openstax.org/books/anatomy-and-physiology/pages/6-3-bone-structure)

- 1 – The main one is an [osteocyte](https://en.wikipedia.org/wiki/Osteocyte): that’s your standard bone cell that sits in bone tissue in its little cave
  - It’s responsible for maintaining the tissue around it and also for sensing what’s going on in the tissue environment
- 2 – [Osteoblasts](https://en.wikipedia.org/wiki/Osteoblast) (osteocyte precursors) are the ones that when they attach to a bone surface, they exude [osteoid](https://en.wikipedia.org/wiki/Osteoid) (which is the new bone tissue), which then becomes mineralized
  - They’re the bone forming cells
- 3 – [Osteoclasts](https://en.wikipedia.org/wiki/Osteoclast) are these big multinucleated cells that also attach to bone surfaces and resorb bone in packets
  - This is really important, and is not a bad thing
  - [This is part of bone remodeling]

**Bone remodeling is one of the most important ways that we maintain our skeleton, get rid of micro damage and also adapt to mechanical loading**

- Resorption and formation is happening throughout our life
- It is the way that we release calcium into the blood for when we need it, for all those other things we need calcium for
- It’s extremely important

*The trouble is estrogen does help to contain those osteoclasts when it disappears from the blood*

- Osteoclasts have a little bit of a party for a few years and resorb bone like crazy
- And so that explains why women at menopause have this dramatic loss of bone for a period of years
- Then it levels out again in women and sort of matches men

***Why more women than men are fracturing with osteoporosis [24:00]***

- More women fracture than men
- In our 20s, we don’t have as much bone as men, and then we lose more throughout life
- So by the end of life there’s this greater disparity
- Then add on to that, women fall more than men in later life
  - [Belinda misspoke and is referring to the greater action of osteoclasts at menopause which reabsorb bone resulting in the loss of BMD in women]
- And so you’ve got this perfect storm of this is why more women than men are affected by osteoporosis and fracture

Peter asks, “*Do we believe that women fall more because of a greater prevalence of sarcopenia?*”

- That’s a hard question
- Probably yes
- There’s a reasonable amount of evidence to show that women are less active throughout their life and when they’re older
- Men genetically have more bone and muscle to begin with ‒ they’ve started from a higher place

***So yes, a very frail woman has not very much muscle and not strong/ functional muscle***

- Their whole sort of neuromuscular package, if you like, has deteriorated to the extent that if their balance is perturbed, they will struggle to regain their balance before they fall

**Peter’s recap of bone remodeling throughout life**

- This is oversimplifying it a little bit
- 1 – We have osteoblasts and osteoclasts, and early in life, the balance probably favors the osteoblast
  - You’re adding more bone than you’re subtracting
- 2 – We get into an equilibrium where there’s a remodeling that’s constantly occurring
- And the bone acts in this sense as a reservoir also for something like calcium
  - If there’s a need for calcium, more of it comes out of the bone
- Rebuilding and remodeling repairs any damage to a bone
  - If you get shin splints, there has to be some healing that goes on
- 3 – Then we get into this state of decline where maybe the osteoclast starts winning
- And in women, this decline is really amplified in the 5-8 years following menopause when the most important hormone for bone preservation, estrogen is taken away
  - Estrogen being the thing that keeps osteoclasts in check is now gone, and the osteoclast now they really get to run amuck and women experience a disproportionate loss of bone mass compared to men (who are also in a state of decline)
- By the way, men’s estrogen levels are also declining because that is tethered to their testosterone levels
  - So as testosterone goes down, so does aromatized estrogen, and it goes down with it, and then they both sort of end up on the same parallel path again
  - [Peter explains hormones in more detail in [episode #256](https://peterattiamd.com/endocrinesystem/)]
- But the women are considerably lower because they’ve had that accelerated loss

**When Belinda teaches about bone growth, she emphasizes**

- The skeleton actually grows via cartilaginous proliferation and it’s replaced by bone

***The osteoblasts aren’t causing the growth of bone, they’re replacing the cartilaginous tissue with bone tissue***

## How parents can optimize their children’s bone health through diet (calcium and vitamin D), sunlight exposure, and physical activity [27:30]

**Lifestyle interventions to allow our kids to reach their genetic potential**

Peter asks, “*What can I be doing to ensure that my 7-year-old, 10-year-old, and 16-year-old are set up for the best life possible when it comes to bone health, given that I’ve already given them something pretty good? [genetics]*”

- The low-hanging fruit is diet
- A balanced diet is important for everything
- You probably need about 1000 mg of calcium a day and vitamin D so you can absorb it from your gut

***Dairy by far is the most abundant and bioavailable source of calcium, and you can get most of what you need from 250 mL of milk (8.5 ounces), 3 times a day***

> “*Not too many people drinking that amount of milk*.”‒ Belinda Beck

- There are other sources: cheese, yogurt, ice cream
- Low fat milk actually has more calcium in it just by virtue of the fact if you take the fat out, you can fit more calcium in the same volume
- Most milk is fortified with vitamin D

**By far the easiest way to get vitamin D is the sun**

- In Australia, the sun is extremely strong, and there is a high rate of skin cancer ‒ so people cover up, slather in sunscreen, hats to the extent that we’ve set ourselves up to have vitamin D deficiency

***It’s important to figure out when is a safe time to be in the sun and ensure that you get a little bit of sun because it is by far the most efficient way to get your vitamin D***

- You don’t have to even get close to getting sunburn
- In Australia, we should be able to get our vitamin D requirement before 10 a.m and after 2:00, possibly a little later
- If you’re in a really hot area in Hobart, in Tasmania in the middle of winter, you would need to stand shirtless for an hour in the sun to get what you needed
  - That’s when you’ve got to start thinking possibly about supplementation

Peter asks, “*What level matters? I don’t think any of my kids have ever had a vitamin D level checked, although in an adult we do this all the time. Is there a level beneath which you would say we’ve got to be supplementing you if you can’t do better than this with sunlight?*”

- The problem with vitamin D is that nobody can agree
- There are 2 schools of thought, 2 levels that have been published
- Belinda explains, “*If you’ve got smart people feeling that strongly 2 two different levels, it tells me that nobody really knows.*”

***The vitamin D deficiency cutoff is 30 ng/mL and 50 ng/mL is considered sufficient (other people say that 75 ng/mL is sufficient); in between that, you would have insufficiency***

- This isn’t Belinda’s area of expertise and she doesn’t want to say which is which
- We’ve discovered that hyperdosing with vitamin D is not safe and increases falls
  - To get somebody’s vitamin D up quickly, you have to hyperdose
  - So people have moved away from vitamin D as a strategy to prevent osteoporosis
- It’s really important that you try to encourage people to be sufficient, and so possibly they will need a supplement of a certain dose that’s going to depend on the person and all manner of other things
- Peter thinks most people are going to require a supplement to be above 50
  - He lives in Texas and is in the sun every day
  - He doesn’t put sunscreen on anything but his face
  - He’s not shirtless, but his arms and legs are constantly exposed
  - If he’s not supplementing, he’s lucky to be above 40 ng/mL
  - He supplements with 5,000 IR daily and that takes him to 50-60 ng/mL
- In the US, it’s not uncommon to see people unsupplemented in the 30’s
- Peter supplements for no apparent reason other than some loosely held belief that he’s going to be better off at 55 than 35
  - It’s more the precautionary principle
  - It’s more that he haven’t found any compelling evidence that he’s worse off at that level and there may be benefits to supplementing
- Thinking about this through the lens of children, Peter would worry more about supplementing a kid because it’s harder to measure vitamin D levels in them
  - You don’t want to go and poke them for blood all the time
- You would hope you could get enough vitamin D from milk (dairy) and sunlight

*Belinda adds that vitamin D assays are notoriously dodgy*

- So you may not get the same results from one to the next
- She’s never had hers measured, but she tracks her bones to make sure they’re doing okay, and that’s how she chose to manage it

**Peter’s takeaway:** ***Pay attention to getting enough calcium and sunlight***

## The best sports and activities for promoting bone health, weight training for kids, and advice for parents [36:30]

**Do you ever get asked the question, “*****Are there certain sports that are going to be better than other sports?*****”**

- It absolutely is extremely important, the type of loading you’re doing for bone
- If we’re talking about heart, lungs, mental health, metabolism, virtually anything is better than nothing
- But if you really want to make a difference for bone, get most bang for your buck, then you absolutely are looking for ***high load activities and they include things that include jumping and landing, and strong muscle movements***
- The other thing that is probably important is **variety** within the sport and across sports
- We do tend to find that **runners**, for example, who have only ever run, are less protected from bone stress injuries in their running career than people who grew up playing basketball and volleyball and tennis and running
- That variety, if we come back to Wolff’s Law, has probably made the bones adapt in a more robust shape to make them more resistant to loading in all manner of ways and also to loading in one direction

> “*My recommendation to parents is, aside from giving you kids the building blocks (being enough calcium and exposure vitamin D every day), then use those building blocks by getting them outside every day.*”‒ Belinda Beck

- If you tell people that, then you may get 4 days a week

***And of that exercise, you want it to be as vigorous as possible***

- **Swimming** isn’t going to do it, **walking** isn’t going to do it
- You need something that is just much more dynamic, varied and will impart a high strain on bone and a strain is a measure of deformation

***You’re trying to make those bones bend because it’s the bending that is actually forming the stimulus to stimulate bone adaptation***

- Swimming and walking both have enormous benefits, but you couldn’t have less bone loading (especially with swimming, it’s a very low G environment)
- Peter remembers reading a study that showed that runners didn’t have great immunity from osteopenia and osteoporosis, and based on what Belinda is saying, this makes a lot more sense

**If you’re just running**

- You’re adapting to one repeatable movement in one direction
- Whereas if you’re playing **soccer** or **basketball** now you’re not just running, you do run, but then you move laterally, you move backwards, you jump
  - There’s more force because you sprint
- So all of those things taken together make a bigger difference in creating the variety within the sport and then across the sports (if you play more than one)

**Studies of varsity athletes have shown the effect of different sports on BMD**

- There was a study done at Stanford in ‘92 by a friend of Belinda’s who looked at Stanford varsity athletes and compared them to sedentary controls (Stanford students who weren’t doing anything)
- It was really interesting to see that if you compared swimmers, cyclists, runners, and gymnasts to the sedentary controls on the scale of bone mineral density: swimmers were lowest, then cyclists were the same as sedentary controls (because they’re also in a weight supported activity), and runners were slightly higher, and gymnasts were off the scale
- [Belinda shared by email another [study](https://pubmed.ncbi.nlm.nih.gov/9041058/) with the same findings, shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2024/10/f6-belindabeck.png)

**Figure 6. Changes in bone mineral density in different types of athletes compared to nonathletic controls**. Image credit: [*Journal of Bone and Mineral Research* 1997](https://onlinelibrary.wiley.com/doi/10.1359/jbmr.1997.12.2.255)

- This was an observational trial; it’s subject to all of those selection biases
  - For example, you’re likely to have people who are lighter, so they have lighter bones who are good at swimming because they float better, so it makes them faster
- They may already have had lighter bones, but on the other hand, at that time they were doing about 6 hours of training a day in the pool and that was actually unloading their bones
  - This is amazing because the muscle loads that are occurring during swimming 50 meters of butterfly, there’s some big muscle forces, but it’s not enough

***It’s weight-bearing loading that is important, and we know this because of how much bone people lose if they go into microgravity***

- Cyclists were the ones who had BMD the same as sedentary controls
- Belinda adds, “*I don’t want anybody to take home that any of these activities are bad. They’re great for virtually every other tissue. It’s just that swimming and cycling and even running are not going to markedly increase your bone mass*.”
- When you watch those Olympic gymnasts do their tumbling runs and they land from one of those crazy tumbles boom on the floor, they are loading their bones like crazy
  - Not only are they getting these enormous forces that are stimulatory to bone, but again, this self-selection effect of gymnasts, the ones who had bones like iron to begin with, probably were able to remain in the sport because they weren’t getting injured
- Peter saw another [study](https://www.journalofexerciseandnutrition.com/index.php/JEN/article/view/10) that added other sports to the mix, and athletes participating in American football, powerlifting, and Jiu-Jitsu had the highest BMD [shown in the figure below]
  - Powerlifting is obvious, it’s literally lifting the heaviest weight imaginable
  - Football has the confounder that if you play football, you’re also lifting weights
  - In Jiu-Jitsu, a lot of force is being put on bones based on how hard they’re tugging and contorting

![](https://peterattiamd.com/wp-content/uploads/2024/10/f7-belindabeck.png)

**Figure 7. BMD of athletes and resistance-trained (RT) individuals**. Image credit: [*Journal of Exercise and Nutrition*](https://www.journalofexerciseandnutrition.com/index.php/JEN/article/view/10/7) 2018

**Peter’s takeaway: we should ask the question, what is it about that sport that’s doing so much for bone density and how can we replicate it?**

- Peter would think that most gymnasts have a lot of orthopedic problems later in life based on the nature of the sport
- Fortunately, many athletes today (runners, cyclists, and swimmers) are probably spending more time in the weight room today than they were in 1992
  - In the early ‘90s, swimming was a 6 hour in the water every day sport, whereas today, they’re spending less time in the water and more time on dry land

**Peter’s takeaway as a parent: diversity of sport and load bearing**

- Belinda agrees 100%
- Her other area of expertise is bone stress injuries
- She talks to coaches of swimmers, and the advice she gives is ***get them out of the pool, get them cross-training and lifting weights***

**How early should we get kids into weight training?**

- For years people were very scared of that thinking, “*You’ll stunt their growth… you’ll compress their growth plates*”
- There’s no evidence of that

***There is certainly nothing to suggest that you shouldn’t do resistance training when you’re a kid***

- The only reason that you wouldn’t do it is if they didn’t like it because the thing you don’t want to do is discourage a child from being active throughout their life

***The best thing you can possibly do is whatever that child loves to do, and then if that happens to be something that doesn’t include particularly bone loading, then just try and add that stuff in***

- Don’t force it down their throat; otherwise, it’s very counterproductive (as those of us with children know)
- This myth drives Peter bananas, and he’s tried and tried to find evidence that suggests that kids can’t lift weights and he’s come up empty handed
- Peter suggests: as a parent, the easiest thing you can do is have  your kids come in the gym with you when you’re lifting weights (especially if you have equipment at home)
  - They’re going to start copying you and start picking up stuff
  - It’s a great opportunity to teach them technique because what’s going to mess people up, not just kids if they’re not doing it right
- Belinda explains, “*You don’t want a kid just going over and trying to do a deadlift and not doing it right. So there’s your opportunity. Teach them from a young age, do a beautiful deadlift. There is one of the most useful exercises they can do their entire life.*”

## The impact of corticosteroid use on bone health in children and strategies to minimize the negative effects [48:30]

**What about the effect of** [**corticosteroids**](https://en.wikipedia.org/wiki/Corticosteroid) **(either inhaled or systemic) on bone?**

- Some kids will have asthma or other conditions that require the use of these drugs
- Peter sees this in his practice, when adults come in and he’s astonished to see astonishingly low bone density in an otherwise healthy person
  - They took [prednisone](https://en.wikipedia.org/wiki/Prednisone) for many years
- Belinda explains, “*There’s no evidence because we haven’t got long-term data as far as I’m aware, and again, not really my area.*”

***All she can say is corticosteroids should be minimized as much as possible throughout life***

- If a child or adult is able to manage their asthma just with [Ventolin](https://en.wikipedia.org/wiki/Salbutamol), which doesn’t seem to have any negative effect on bone, that is best
- Try to stay off steroid inhalers if you possibly can
- If you’re on high doses, try to titrate them down
- See if you can manage in other ways

> “*It is abundantly clear that corticosteroids are the enemy of bone, and the longer you’re on them, the more damage they do.*”‒ Belinda Beck

- Corticosteroids are lifesaving for some people
- If you have to go on them, just get off them as quickly as you can
  - Once your respiratory condition has calmed down

***If an adult is in a situation where you must take them and at high doses, then you would need to consider some bone medication to counteract that***

**Peter’s takeaway**: if your child requires corticosteroids, that’s all the more reason to double down on the other things we talked about

- Which are, 24 ounces of milk a day, out in the sun every day, lifting weights, and doing diverse sports

## Advice for people in middle age to preserve bone density: physical activity and bone-loading exercises [52:00]

**For men and women in their 30s and 40s, is there anything you would add to what we have talked about as important tools as a person enters middle life?**

- It’s exactly the same

***You’ve got to maintain your diet and levels of exercise because your bones need those two elements to maintain***

- In the old days, you can picture in your head the trajectory of bone growth, plateauing, and loss
  - And the mantra was this is inevitable; that’s what bone aging looks like

> “*For years I’ve been saying that’s what sedentary behavior looks like, and that’s what the sedentary effect on a skeleton is.*”‒ Belinda Beck

- Belinda believes, “*If you maintain your levels or increased your levels of physical activity, friendly bone loading, from the time you were 20 until the time you died, I would be willing to bet that you could go a long way towards maintaining that plateau. And the* [*masters athletes’ data*](https://pubmed.ncbi.nlm.nih.gov/34258508/) *seems to support that.*”

**BMD is maintained in masters athletes as long as they’re maintaining their activity**

- There may be a slight loss, yes, but that’s probably because the loads that they’re able to produce in their physical performance also reduce
  - But this is an atrophy effect, this is not a genetically programmed aging effect
- Belinda knows that there are many people around the world who would argue with her because she doesn’t have much data aside from the masters athletes long-term data, but it’s almost impossible to collect those data because those are lifelong studies and she would be dead before the study would be finished if she started it now

*Peter offers 2 arguments that suggest Belinda is right*

- 1 – When you look at spontaneous activity and movement of people as they age, you see a very similar pattern: a relative plateau preservation of not just activity but lean mass followed by a deterioration
  - Suggesting that as lean mass goes down, movement goes down, activity goes down, and then it feeds back on itself, it becomes a vicious cycle and away you go
- So again, it could be that what we see as a “physiologic decline” of bone loss is not that, it’s rather a proxy for muscle loss and reduced activity
- 2 – Anabolic resistance, something that [Luc van Loon](https://www.maastrichtuniversity.nl/ljc-van-loon) shared on the podcast recently [[episode #299](https://peterattiamd.com/lucvanloon/)]
  - Peter had always taken it as a given that anabolic resistance occurs due to aging because of course we see it clearly with aging
- Luc discussed some studies that demonstrated that anabolic resistance was most exacerbated by inactivity, and this was done with the [cast study](https://pubmed.ncbi.nlm.nih.gov/37994085/)
  - So you take a given individual, you cast one leg, not the other leg
  - Before you do that, you run the amino acid isotopes through them
  - You do this exercise for 2 weeks, you take the cast off, and you have an atrophied leg and a normal leg
  - You do the same amino acid isotopes and lo and behold, there’s 40% or 50% anabolic resistance on the leg that was in the cast
  - This is not because they got older in 2 weeks, it’s because they were inactive and they lost muscle activity
- If that’s true, it really suggests that we shouldn’t accept anabolic resistance as an inevitability of aging

***Peter is inclined to think Belinda’s hypothesis could be correct here, which is if you just don’t stop the movement, if you just don’t stop the exercise, this decline of BMD might be far better than what the actuarial data predict based on sedentary behavior***

**Don’t stop the movement**

- There are these beautiful [studies](https://pubmed.ncbi.nlm.nih.gov/31829806/) that have shown MRIs of masters athletes’ calves compared with an age-matched person who’s not active
- This is also compared with a young person’s calf
- The young and the masters look identical: the muscle volume and quality, there’s no fatty infiltration, and the sub-Q fat is virtually non-existent
- Whereas you look at somebody the same age as the masters athlete who’s not active and you’ve got this shrunken down little sarcopenic muscle belly, that fatty infiltration and a big wad of sub-Q fat

***The appearance of that masters athlete muscle, essentially it confirms that this is a sedentary problem, this is not an age problem***

**The problem with advising patients to exercise**

- A lot of people will say, “*Well, who cares? I know that 60% of the population will not do enough physical activity to maintain that*.”
- So we need to invent drugs that’ll do the same thing
- Belinda thinks we will struggle to ever find a drug that will be able to replicate the action of exercise, physical loading on muscle and bone because you can’t replicate the stimulus
- And any drug that is found to work probably will still need exercise for it to manifest its benefits

**There is an enormous interest from a pharmaceutical standpoint in anti-sarcopenic drugs**

- As it stands today obviously we have anabolic steroids and they’re very efficacious, but they require the training stimulus
  - You can give a person all of the testosterone in the world, but if they don’t train, they have virtually zero benefit, slight benefit
- The holy grail is: Can we give agents that can cause muscle growth even absent the profound training stimulus that is needed in other regards?
  - Peter’s answer is, “*Maybe, but will it be functional muscle? And to that extent will it be functional bone?*”
- So even if a drug like [Bima](https://en.wikipedia.org/wiki/Bimagrumab) or an IGF-1 agonist or some of these other drugs or molecules that are being touted potentially increase muscle size, it’s not clear that they’re going to increase strength, function and bony composition

> “*If we can take a pill, why would you expend any effort? And that’s unfortunately… going to be our undoing in terms of healthy aging.*”‒ Belinda Beck

## Bone loss during the menopause transition for women: hormone replacement therapy and other strategies to mitigate BMD losses [59:30]

- This is an area that Peter has become intensely interested in because he views it as one of the great tragedies of the past 25 years: this very popular [study](https://jamanetwork.com/journals/jama/fullarticle/195120) by the [Women’s Health Initiative](https://en.wikipedia.org/wiki/Women%27s_Health_Initiative) which basically scared an entire generation of physicians and women away from HRT
  - [Discussed in detail in [episode #253](https://peterattiamd.com/joannmanson/) and a [previous newsletter](https://peterattiamd.com/clearing-the-air-on-hrt/)]
- And as a result of that, not only has there been an unnecessary abundance of symptoms associated with menopause, but the real hidden tragedy has been the larger epidemic of osteopenia and osteoporosis in a group of women who may have otherwise received estrogen as they went through menopause

**Is there anything on the hormone side that you want to talk about beyond what we’ve already discussed, which is the important physiology, the important role estrogen plays specifically in managing the role of osteoclasts in bone remodeling?**

- The majority of patients coming to [The Bone Clinic](https://theboneclinic.com.au/) are postmenopausal women
  - There are thousands of people on the books
- They’ve been open for 9 years now, and an awareness has grown in the community about The Bone Clinic
  - People who are not postmenopausal but are aware that either they have low bone mass already or that mum or dad or granny or grandpa had low bone mass, they want to prevent it

***One of the happiest things that has happened is that people are realizing that premenopause is the time to start taking care of this issue***

- Most people don’t have any idea what their bone health is like until they either have a first fracture or they go through menopause and they have a savvy enough GP who says, we need to get your baseline [DEXA](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry), let’s get you started
- And all of a sudden, yikes, I have either osteopenia or osteoporosis, away you go to The Bone Clinic

Peter points out, “*You said something very important there, which you and I take for granted. I think it’s very important to reiterate for the listeners, for the female listeners in particular, which is you don’t want to wait until you’re into menopause to replace estrogen. You have to do it during the pre and perimenopausal stage to get the maximum effect.*”

- This is something not enough women are being educated on
- Women may think, “*Well, let me go through these two miserable years of perimenopause, wait I’m completely amenorrheic, my estradiol levels are unmeasurable and my FSH is through the roof and now we should start doing it.*”
- No, it turns out that there are data that suggest that they’ve actually lost quite a bit of bone up until that point

***This bone loss is preventable and Peter hopes women listening to this are sitting with doctors who can help them through that transition***

## Interpreting the bone mineral density results from a DEXA scan: T-score, Z-score, and more [1:03:00]

**When you get a** [**DEXA scan**](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry)

- Put aside the body composition part of it where you see body fat and lean mass
- Sometimes when you get a DEXA scan, it shows you total bone density and it says your total bone density Z-score is this, and your T-score is that, but it doesn’t give any segmental information
  - It doesn’t tell you about the lumbar spine or the hips or the femurs or anything like that
- And if you look closely, it might even give you a number in grams per centimeter squared as an actual number

**Help people make sense of what all those numbers mean**

*Why is it grams per centimeter squared, not grams per centimeter cubed as a density?*

*Explain the difference between a Z-score and T-score*

- Dual energy X-ray absorbed geometry is a low dose radiation tool, much lower dose than an X-ray of your chest
- The name describes what it’s doing: it’s sending two energies through the body in a way to determine the density of the tissue it’s going through
- Now, it is a misnomer: it is an areal density, which is a contradiction
  - Because it is a planar view, the X-ray source is underneath, you lie on the bed and the detector is in the arm above and it is a projected image of this two-dimensional density
  - They call it areal bone mineral density because without going into too much detail, the method of measuring is looking at what is detected according to the density of the material
  - So it’s not volumetric at all
    - If you want to volumetric density, you have to look at a three-dimensional method of measuring
- You can also get bone mineral content and area from the same scan and they derive from this density measure
- They talk about it in g/cm2 because it’s an aerial measure

*About total BMD (bone mineral density)*

- That is the amount of bone that you are observing from a whole body scan

***Normally if your doctor wants to know if you have osteopenia or osteoporosis, they will send you to their radiology clinic and they will do a standard spine and hip scan, not a whole body scan***

- The only reason you would do a whole body scan is if you want to look at body composition, lean mass
- Belinda wouldn’t use the the BMD value from the total scan as a marker or as any index for osteopenia or osteoporosis because **the WHO definition was actually based at the hip**
- In fact, it was based on femoral neck
- We’ve moved away from looking at femoral neck as the standard, and we look at total hip now because it can be quite a bit of variation of femoral neck because of the way that you analyze it

***Osteoporosis should be really diagnosed from hip BMD according to the definition of the World Health Organization: a T-score of -2.5 is definitive of osteoporosis, but a T-score between -1.0 and -2.5 is osteopenia (or low bone mass)***

*A T-score is a standard deviation. What is that compared to?*

- Your value is compared to a reference database and the T-score is actually comparing your score to what they call a ***young normal***
- It depends on the site (and that does vary), but let’s just say it is roughly a 20-year-old (between 20 and 30) of the same race and sex
- For example, a 52-year-old white woman, her value, her BMD value is going to be compared to the average BMD value of a white woman age 20 (that’s the T-score)

*The Z-score is comparing your value to someone the same age and sex*

- This same example would be compared to the average 52-year-old white woman
- If you’re looking at a plot, it starts at age 20: BMD is pretty much plateauing, and then it begins to go down
- If you went to age 52 and looked at the average value, that is what your BMD Z-score is being compared to
- It’s a standard deviation from there
- The T-score is being compared to the start of that plot

***The reason why they give us these two values is because it’s thought that at any stage of your life, if you are 2.5 standard deviations away from the amount of bone that you probably started with, then you are at increased risk of fracture***

- The problem with that is the fact that you could have started higher or lower than that average
  - And most of us did; few of us are actually average

***But the Z-score gives us information about where you lie in relation to your peers, how normal that is***

- The Z-score is normally not as scary as the T-score because you will have lost some bone

*The way Peter explains it to patients*

- If your Z-score is zero, you’re at the 50th percentile of the population
- If your Z-score is 1.0, you’re a full standard deviation above the mean
  - So what’s that?
  - You’re in the 85th percentile (if he’s doing the math correctly)
- Obviously, the T-score is always going to be lower because we’re comparing you to a perfect standard, we’re comparing you to that super healthy 20 to 30-year-old
- If you show up with a decent T-score (your T-score is 0, and your Z-score is +0.8), we say the win is keeping that T-score where it is and watching the Z-score go up
  - Because over time we want you being better and better and better than your age matched peers because they’re going down, and we’re going to hold you plateau
- That means we can’t improve you relative to the T-score, but we can improve you relative to your peers

## The LIFTMOR study: testing the effects of heavy weightlifting on bone health in postmenopausal women with low bone density [1:10:15]

**Peter learned about Belinda watching stuff on YouTube**

- Many years ago, he saw a clip from local news in Australia highlighting you talking about the LIFTMOR study

**Talk about the** [**LIFTMOR study**](https://pubmed.ncbi.nlm.nih.gov/28975661/)

- Around 2013, Belinda got to a point in her research career where she looked around and thought the exercise guidelines for osteoporosis are get your kids jumping and running and playing as much sport as possible, keep doing that for as long as you can
- But then when you get osteoporosis, stop doing all that and just prevent falls so you don’t break
- She thought, “*Are we done? Is this the best we can do? This is lame*.”
- All her animal research experience had told her that even with very low bone mass animals, if you load them, they can grow bone
- The only reason we hadn’t been doing that in research is because we were terrified of hurting someone
- It seemed to her that we hadn’t really tried
- And at the risk of hurting somebody, we decided to do it
- We had 3 physiotherapists on that trial, including the PhD student who ran it ([Steve Watson](https://www.linkedin.com/in/steve-watson-0878209a/?originalSubdomain=au))

*The intervention*

- We decided to do a brief exercise because bone doesn’t need a lot of loading, you just need to do one sprint to get those bone cells stimulated
  - You don’t need to run a marathon
  - We had twice a week, 30 minutes, 4 exercises, and we wanted them lifting heavy (so it was 85% 1 RM)
- We used compound movements, this needed to be an efficient project, we wanted to involve as much muscle as possible
- It needed to be weight-bearing, and we wanted something that would transfer to really useful daily activities

***Clearly a squat and a deadlift was going to be fundamental: these are fabulous compound movements that tick all those boxes***

- These are not on machines, this is with free weights because you want to engage as much of those other systems and capacities as possible
- We’re trying to improve **balance** because we’re trying to stop people falling
- Ideally we wanted it to be 12 months because you do need a fair amount of time to be able to detect change on DEXA because DEXA ionizing radiation picks up mineral
  - You can’t just measure new bone, which would be the [osteoid](https://en.wikipedia.org/wiki/Osteoid), unmineralized
  - You need a full period of time to allow for a full remodeling cycle and mineralized bone
- Because it was a PhD project, we couldn’t afford a full year for each person, so we just made it an 8-month intervention
  - Which Belinda was confident would be enough to detect a change
- We did really comprehensive bone and functional measures at baseline
- We recruited about 100 people randomly allocated them to this high intensity resistance and impact training [versus low intensity home program]
- Exercise research is really hard to blind to your participants, and blinding is so important in clinical trials
  - So we had to not tell our participants, which intervention we thought was going to be effective
  - We just said, if you got randomized to this low intensity home program, we were trying to see whether that worked too
    - Of course, we knew that that was not going to work because we’ve got years of experience to know that that is not going to improve bone
    - But we gave them things like walking, stretching, some body weight lunges and toe raises and things that would potentially improve their balance, so we weren’t completely ripping them off

***We had 8 months of this intervention (30 minutes, 2 times a week), and it was supervised***

- The maximum group size was 8, and we recruited post-menopausal women
  - We advertised for over 60 but did recruit 1 person who was 58 (she had been through menopause when she was young)
- We needed to be well clear of menopause; we didn’t want to be fighting that withdrawal of estrogen phase
- And they needed to have low bone mass, so they needed to be at least a T-score of -1.0 at either the spine or the hip
- Belinda reveals, “*I have to say we were looking through our fingers for a little bit and we were so incredibly conservative to begin with, and just being very careful that we weren’t hurting anybody*.”

> “*It became abundantly clear very quickly that we weren’t hurting anybody. In fact, we were making people feel a lot better.*”‒ Belinda Beck

- Peter found the [video](https://www.youtube.com/watch?v=2fx_LfZFxv0) really inspiring, even though it was just a local news segment
  - There were women there that were at some point basically able to pick up their body weight

**Am I remembering that correctly? Literally, these women were dead lifting their body weight.**

*How did you train them to do this?*

- Yeah
- The participants couldn’t have been doing any weightlifting (or anything) in the past 12 months because bone is a “use it or lose it” tissue
- We told them what the basic exercises were, so these had to be people who were willing to do this
- We never throw somebody straight into lifting something extremely heavy and certainly nobody would’ve expected that we would end up with people lifting their body weight (least of all, us)
- We just did it very systematically
  - You start with a broomstick and you make sure that people’s technique is good
  - We had people with fractures, so they had existing [kyphosis](https://en.wikipedia.org/wiki/Kyphosis), and you know what a kyphotic curvature looks like in a deadlift position (not a pretty thing)
  - But as long as they had an extensor moment, it was okay
- We don’t want people flexing and lifting weight because then we’re putting them at risk of fracture, but it’s all in the coaching

***That’s the reason why it’s so important that the person who is coaching somebody with osteoporosis knows what they’re doing; they can’t just be a strength and conditioning coach (although that really helps). They have to have some clinical training.***

- People come to you in a clinic with not just osteoporosis, but pelvic floor dysfunction, frozen shoulder, spondylolysis, vertigo, knee OA, and you’ve got to be able to manage that
- Many of those conditions were actually screened out of the LIFTMOR study because it was the first time we were doing it and we didn’t want to have to manage all of that

***It was all about just systematically training them in the technique and then gradually increasing the load***

- A lot of people think about old people as completely incapable of doing stuff and incapable of learning, but old people are you and me who just kept living longer
  - We have the capacity to learn, and older people are perfectly capable of learning how to do a deadlift and a squat
  - It might be pretty ugly to start with, but they get better and as they get stronger, they get even better
- Peter loves this so much; he agrees with all of that
- He thinks one of the saddest misconceptions people have is that once they get to a certain age, it’s too late and they sort of accept their fate
  - “*oh, I have this kyphotic spine and oh, my bones are too brittle, and I guess I’m just going to spend the next decade of my life doing nothing*”
- And studies like this demonstrate that that’s not the case

## Profound benefits of weight training outside of BMD improvements: exploring the broader impacts on patients in the LIFTMOR study [1:19:30]

**As you think about the evolution of this study, what else did you notice in the subjects?**

*What did they tell you? How did this translate into the rest of their lives?*

- Quality of life was the most important thing and that’s what made Belinda want to open the clinic
- Subjects had comments like, “*Oh my God, Belinda, I can see my shoulders in the mirror again.*”
  - Because their posture had changed
- When you do a clinical trial, you measure height and weight as the standard baseline
- Who knew that we would actually be citing **height as an outcome** because the control group shrank, whereas the intervention group grew a little (0.5 cm)
  - Of course they didn’t grow, but their **posture improved** to the extent that they were taller at the end of the study, and the difference between groups was significant
  - In only 8 months
- Examples of things subjects said:
  - My husband is hiking the Kokoda trail and I just thought I was going to be cheerleading; I can go with him now
  - I’ve got this incredible strength
  - I’ve basically got my life back; I can get into the garden and I can push the wheelbarrow full of potting mix around now, and I don’t feel like I’m going to break
  - I can lift my grandchild again
  - I can get my own shopping out of the car

***Subjects experienced major improvements in the quality of life***

**Improvement in BMD**

- We ended up with a net benefit of a bit over 4% at the spine
- That equated to about 3% improvement at the spine in BMD and about 1-1.5% loss in controls

***This program definitely has the biggest effect on the spine, and that’s a good thing because that’s one of the places that fractures most frequently***

*Progress at the hip was a real head scratcher*

- When Belinda first looked at the results, they had about 0.6% improvement at the femoral neck
- She was thinking about those women deadlift and squatting 70 kilos (154 lbs)
- We ended up with a significant difference because the controls lost 2.5%
- There was a net benefit, but she couldn’t figure it out
- Luckily, some 3D hip software allowed her to reanalyze the 2D BMD data from DEXA and look at the changes in geometry
- From that, you could see things like cross-sectional area of the femoral neck, cortical thickness and so on
- When you look at cortical thickness of the total femoral neck, there was a 13% net benefit in the intervention group
- And if you looked specifically at the lateral femoral neck cortex, there was a 27% improvement

***So it turns out that if you were just looking at BMD from DEXA, it would look like this kind of lifting only has a maintenance effect at the hip, but actually what’s happening is it’s changing the geometry. It’s making it stronger by making the cortex, that cortical bone, thicker and more resistant to bending.***

- It was a really novel outcome

Peter asks, “*Given that most of us clinicians don’t have access to that, can we in your opinion, rely on the stabilization of the Z-score or the improvement of the Z-score? The stabilization of the T-score is a win if we’re in that situation.*”

***Yeah, if you can maintain bone mass at the hip or bone mineral density, yes, that is absolutely a win***

- Probably the largest gain we had at the hip in the LIFTMOR study was about 6%, but on average, it’s something that you don’t always see

**Peter points out: if going on this type of a training program at best maintained you, there are 2 important points to consider**

- 1 – The controls are having the floor dropped from underneath them, so that gap between what you would be doing and what you’re doing is widening even if you’re not getting better
- The fact that you’re even getting better slightly is mind-boggling, but even if you don’t, the gap between where you are and where you would be is enormous
- 2 – Your fall risk is going down dramatically because you’re putting on muscle mass and you’re improving your balance
  - Belinda made the point that using these free weights improves balance
  - So you have more muscle, more balance, more motor control
  - The likelihood of falling to get in the position that you’re going to break a bone is going down so much
- When you add to the fact that cortical bone is increasing by 13%, this is just a win-win-win-win-win across the board
- Belinda adds, “*Show me a bone drug that does that.*”

**Functional outcomes**

- We had back extensor strength, leg extensor strength, and then we had tandem walk timed up and go, sit to stand, vertical jump, and we also measured [kyphosis](https://www.hopkinsmedicine.org/health/conditions-and-diseases/kyphosis)
- All of those things improved, but especially lower extremity strength and back extensor strength
- Back extensor strength is making them stand up straighter

*Dangers of kyphosis*

- If somebody has kyphosis and their posture is such that their vision is angled downwards, they’ve lost that peripheral vision for say when they’re walking to their car at the shopping center, which is not their comfortable environment
- Perhaps a little kid runs out in front of them and they haven’t seen them coming, and that’s when a fall can happen on a hard supermarket floor
- Walking outside their own home and the neighbor’s dog runs out
  - They don’t see it coming
  - They get a fright and they’ll fall

***So posture is actually really, really important to fall risk and risk of fracture because we know pretty much half the time you fall, you’re going to fracture***

- Peter adds, “*A reduction of visual input is a reduction of cortical stimulation (cortical meaning brain cortical) and that’s also increasing problems. So in addition to everything you said, which is this increased risk of falling as vision is getting narrower, you’re also reducing brain input, and I think you run the risk of also exacerbated or accelerated degeneration of the brain.*”
  - We know that hearing loss is a risk for dementia because it’s reducing sensory input to the brain, and we would argue that you see the same thing with a reduction of visual input

***That’s a really big deal to get somebody looking up and forward***

- He’s sure she saw an improvement in grip strength because you can’t deadlift without grip strength

> “*If a woman’s picking 70 kilos off the ground, think of how strong her hands are and think of the implication of that on mitigating fall risk.*”‒ Peter Attia

- Think about that person walking down a flight of stairs; now imagine the grip they have on the handrail as they confidently walk down the steps
- Think of the devastating injuries that people can have of any age, but certainly older people when they can’t hold onto a handrail and then they don’t have the leg strength to stop themselves

Peter reiterates this point, **“*****Yes, there are some really interesting and exciting drugs on the horizon for the management of this. Yes, pharmacology and endocrinology play a very important role in managing these things. I would argue estrogen more than any other drug out there, but none of these things compare or should ever be thought of as a substitute for what you’re describing.*****”**

**Risk factors predictive of your risk of falling**

- The tandem walk, sit-to-stand, timed up-and-go, and vertical jump
- Improving those things reduces your risk of falling
- Grip strength is also important
- This is why these Olympic lifts are so incredibly helpful because they are compound movements using virtually every muscle in your body when you’re doing it

## Guidance for people wanting to use exercise designed to improve their bone health [1:29:30]

**Peter’s takeaway**: there’s no chance that anybody listening to us at this point would call into question the value of this type of intervention

**For people listening who don’t have access to you and your clinic, what would the advice be for people in the same state as the women were in at the beginning of your study?**

- The minute Belinda opened [The Bone Clinic](https://theboneclinic.com.au/), everybody wanted the program,
  - The problem is, she didn’t want to initiate an avalanche of fractures for people doing the program and hurting themselves
- So they decided to license it and provide that program to physiotherapists what you guys call physical therapists and accredited exercise physiologists (or their equivalent)
- We have licensed probably about 60 in Australia at the moment and a growing number overseas now
  - It’s just starting to take on in the US
- Belinda is an academic, not a salesperson
- People come to her and that’s how they get it
- Without turning this into an advertisement for [Onero](https://onero.academy/), this is the program she delivers through The Bone Clinic

*Training for professionals:* [*Onero Academy*](https://onero.academy/)

- The training for that is a very comprehensive 6 hours online
- You must have these qualifications to do it, and then you are ready to deliver it to your patients in your clinic as long as you have the gea
- And they’ve always got access to Belinda and a lot of supportive information to do that safely
- The reason she wants physios and EPs to deliver it is because they have that background information that she discussed earlier
  - That clinical training that allows them to look after the millions of different comorbidities that are going to come into their clinic
- This is not something that the patients go to; this is something that the trainers go to become accredited
- If a person is listening and they want to find out where accredited people are they can go to The Bone Clinic site and [map](https://onero.academy/locations/)
  - On that map, you’ll see a little red tag
  - If you click on the tag, the contact details of that Onero provider will pop up.
- In the US, there’s not a huge number of them at the moment, but the demand is so incredibly high in the US
- Really the best thing that you could do if you were in that situation and you wanted to go to an Onero provider is go to your local PT or kinesiologist, exercise physiologist, some equivalent and say, “*Okay, you need this program. Here’s the website, contact Belinda*.”
  - She can get them licensed and away they go

**For Belinda, it’s research**

- There is a way for providers to contribute to our research program
- She gives them access to our database
- She explains, “*We can do a telehealth appointment with them and give them our very best advice for a program that they can do either at home or at a gym.*”

> “*I’m really interested in making sure that this work’s not just in our hands, and so that’s part of my research.*”‒ Belinda Beck

- If they don’t want to do that, then the next best thing they can do is just go to the gym and get some gym program
- Anything is better than nothing and start lifting weights

Belinda cautions, “*If you’ve got a T-score of -4.0, I’m not comfortable with you training by yourself. So even if you’re not doing Onero, get somebody to look after you.*”

**Belinda suggests 3 levels of intervention**

- 1 – If you can find an Onero provider, do supervised Onero
- 2 – [Call/ email](https://theboneclinic.com.au/contact/) The Bone Clinic and we’ll do a telehealth appointment and get you a program that you can do
  - Which would be the very best that we can come up with that you could do unsupervised
- 3 – The next level down, just get yourself to the gym with someone supervising you and do some weights of some kind
- Peter adds #4: Take a 2-week vacation to Australia and get some time at the clinic in Brisbane

> “*I think this is a remarkable demonstration of the power of exercise, and people hear me say this all the time, and I’m sure they’re sick of hearing me say it. It is the most potent drug available*.”‒ Peter Attia

**Peter’s takeaway**

- He’s a very pro-pharma guy, but there’s just no denying the evidence that there is nothing that a pill can do to touch the benefits of exercise
  - This is about as pointed as an example as you will see
- He loves hearing about how in such a relatively short period of time, these women had such a dramatic improvement in their quality of life
  - It’s such an exciting story
  - It’s really had a greater impact on their quality of life than he can think of any other intervention that any healthcare provider could demonstrate

§

## Selected Links / Related Material

**The Bone Clinic**: [The Bone Clinic](https://theboneclinic.com.au/) (2024) | [1:15, 7:30]

**LIFTMOR trial**: [1:15, 7:45, 1:11:15]

- [High-Intensity Resistance and Impact Training Improves Bone Mineral Density and Physical Function in Postmenopausal Women With Osteopenia and Osteoporosis: The LIFTMOR Randomized Controlled Trial](https://pubmed.ncbi.nlm.nih.gov/28975661/) | *Journal of Bone and Mineral Research* (S Watson et al 2018)
- [Published erratum](https://pubmed.ncbi.nlm.nih.gov/30861219/) | *Journal of Bone and Mineral Research* (S Watson et al 2019)
- [High-intensity exercise did not cause vertebral fractures and improves thoracic kyphosis in postmenopausal women with low to very low bone mass: the LIFTMOR trial](https://pubmed.ncbi.nlm.nih.gov/30612163/) | *Osteoporosis International* (S Watson et al 2019)

**LIFTMOR-M study**: [1:30]

- [The LIFTMOR-M (Lifting Intervention For Training Muscle and Osteoporosis Rehabilitation for Men) trial: protocol for a semirandomised controlled trial of supervised targeted exercise to reduce risk of osteoporotic fracture in older men with low bone mass](https://pubmed.ncbi.nlm.nih.gov/28611110/) | *BMJ Open* (A Harding et al 2017)
- [A Comparison of Bone-Targeted Exercise Strategies to Reduce Fracture Risk in Middle-Aged and Older Men with Osteopenia and Osteoporosis: LIFTMOR-M Semi-Randomized Controlled Trial](https://pubmed.ncbi.nlm.nih.gov/32176813/) | *Journal of Bone and Mineral Research* (A Harding et al 2020)
- [Effects of supervised high-intensity resistance and impact training or machine-based isometric training on regional bone geometry and strength in middle-aged and older men with low bone mass: The LIFTMOR-M semi-randomised controlled trial](https://pubmed.ncbi.nlm.nih.gov/32289518/) | *Bone* (A Harding et al 2020)
- [Exploring thoracic kyphosis and incident fracture from vertebral morphology with high-intensity exercise in middle-aged and older men with osteopenia and osteoporosis: a secondary analysis of the LIFTMOR-M trial](https://pubmed.ncbi.nlm.nih.gov/32935171/) | *Osteoporosos International* (A Harding et al 2021)
- [Geometry and bone mineral density determinants of femoral neck strength changes following exercise](https://pubmed.ncbi.nlm.nih.gov/36271264/) | *Biomechanics and Modeling in Mechanobiology* (D O’Rourke et al 2023)

**BMD compared in athletes of different sports**: [40:00]

- [High-impact exercise promotes bone gain in well-trained female athletes](https://pubmed.ncbi.nlm.nih.gov/9041058/) | *Journal of Bone and Mineral Research* (D Taaffe et al 1997)
- [Influence of sports participation on bone health in the young athlete: a review of the literature](https://pubmed.ncbi.nlm.nih.gov/21944303/) | *PM & R* (A Tenforde, M Fredericson 2011)
- [Bone Mineral Density in Competitive Athletes](https://www.journalofexerciseandnutrition.com/index.php/JEN/article/view/10) | *Journal of Exercise and Nutrition* (J Antonio et al 2018)

**Masters athletes data on the effect of exercise on BMD**: [53:15]

- [Regular Strength and Sprint Training Counteracts Bone Aging: A 10-Year Follow-Up in Male Masters Athletes](https://pubmed.ncbi.nlm.nih.gov/34258508/) | *JMBR Plus* (T Suominen et al 2021)
- [Bone mineral density in elite masters athletes: the effect of body composition and long-term exercise](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8166030/) | *European Review of Aging and Physical Activity* (A Kopiczko et al 2021)

**Episode of** ***The Drive*** **with Luc van Loon**: [#299 ‒ Optimizing muscle protein synthesis: the crucial impact of protein quality and quantity, and the key role of resistance training | Luc van Loon, Ph.D.](https://peterattiamd.com/lucvanloon/) (April 22, 2024) | [55:00]

**Cast study of effects of inactivity:** [One Week of Single-Leg Immobilization Lowers Muscle Connective Protein Synthesis Rates in Healthy, Young Adults](https://pubmed.ncbi.nlm.nih.gov/37994085/) | *Medicine and Science in Sports and Exercise* (A Holwdera et al 2024) | [55:15]

**Masters athletes’ calves compared to sedentary controls**: [Skeletal muscle size, function, and adiposity with lifelong aerobic exercise](https://pubmed.ncbi.nlm.nih.gov/31829806/) | *Journal of Applied Physiology* (T Chambers et al 2019) | [56:30]

**YouTube video**: [Osteoporosis Sufferers Using Weight Training](https://www.youtube.com/watch?v=2fx_LfZFxv0) | Physical Culture (2015) | [1:10:30]

**Training for professionals**: [Onero Academy](https://onero.academy/) (2024) | [1:30:45]

**Map of accredited providers**: [Onero Locations](https://onero.academy/locations/) (2024) | [1:32:45]

**Another clinical trial Belenda was the PI on, the MEDEX-OP trial**:

- [The influence of antiresorptive bone medication on the effect of high-intensity resistance and impact training on osteoporotic fracture risk in postmenopausal women with low bone mass: protocol for the MEDEX-OP randomised controlled trial](https://pubmed.ncbi.nlm.nih.gov/31492784/) | *BMJ Open* (M Fischbacher, B Weeks, B Beck 2019)
- [A Comparison of Bone-Targeted Exercise With and Without Antiresorptive Bone Medication to Reduce Indices of Fracture Risk in Postmenopausal Women With Low Bone Mass: The MEDEX-OP Randomized Controlled Trial](https://pubmed.ncbi.nlm.nih.gov/34033146/) | *Journal of Bone and Mineral Research* (M Kistler-Fischbacher et al 2021)
- [High-Intensity Exercise and Geometric Indices of Hip Bone Strength in Postmenopausal Women on or off Bone Medication: The MEDEX-OP Randomised Controlled Trial](https://pubmed.ncbi.nlm.nih.gov/35690931/) | *Calcified Tissue International* ( M Kistler-Fishbacher et al 2022)

§

## People Mentioned

- [Luc van Loon](https://www.maastrichtuniversity.nl/ljc-van-loon) (Professor of Physiology of Exercise and Nutrition and Head of the M3-research group in the Department of Human Biology at Maastricht University, The Netherlands) [55:00]
- [Steve Watson](https://www.linkedin.com/in/steve-watson-0878209a/?originalSubdomain=au) (Physiotherapist involved in the LIFTMOR trial) [1:12:15]

§

![](https://peterattiamd.com/wp-content/uploads/2024/10/bio-belindabeck.png)

##### Belinda Beck, Ph.D.

Belinda Beck earned a Bachelor of Human Movement Studies at the University of Queensland. She then attended the University of Oregon where she earned a Master’s in Sports Medicine and Ph.D. in Exercise Physiology. She did her postdoctoral training at Stanford University School of Medicine with Dr. Robert Marcus in the Department of Endocrinology, Gerontology, and Metabolism. Dr. Beck is currently a Professor in the School of Health Sciences & Social Work and member of the Menzies Health Institute Queensland at [Griffith University](https://experts.griffith.edu.au/18574-belinda-beck), Gold Coast, Australia and the Director of [The Bone Clinic](https://theboneclinic.com.au/about-us/) in Brisbane, Australia.

Dr. Beck’s research focuses on the influence of mechanical loading on bone. She has worked for more than 20 years to develop evidence-based, safe and effective management and prevention for osteoporosis, stress fracture, and osteoarthritis. Dr. Beck has authored over 100 scientific papers, and presented almost 200 abstracts at conferences and symposia nationally and internationally. Among these, results of the clinical trials [LIFTMOR](https://pubmed.ncbi.nlm.nih.gov/28975661/), [LIFOFOR-M](https://pubmed.ncbi.nlm.nih.gov/32289518/), and [MEDEX-OP](https://pubmed.ncbi.nlm.nih.gov/34033146/) re-established the benchmark of exercise as therapy for osteoporosis and low bone mass. She established the Bone Clinic and [ONERO](https://onero.academy/) research program to license practitioners in these interventions to prevent osteoporotic fracture. [[The Bone Clinic](https://theboneclinic.com.au/our_team/prof-belinda-beck/)]