# #155 – Chris Sonnenday, M.D.: The history, challenges, and gift of organ transplantation

**Source:** [https://peterattiamd.com/chrissonnenday/](https://peterattiamd.com/chrissonnenday/)

---

Chris Sonnenday is the Transplant Center Director for Michigan Medicine. As Peter’s senior resident while at Johns Hopkins, Chris made a lasting impression on him with his remarkable leadership and ability to maintain his humanity through the stressors of that challenging environment. In this episode, Chris tells the incredible backstory of the history of transplant medicine, focusing on the kidney and the liver. He discusses the surgical and immunologic developments that launched the field forward, but also lays out the challenges ahead for the field, such as the rising prevalence of chronic kidney and liver failure. Chris also tells many stories of tragedy and triumph that comes with working in organ transplantation, but ultimately explains the rewarding nature of being a witness to the gift of organ donation.

[\*WATCH PODCAST ON YOUTUBE\*](https://www.youtube.com/watch?v=fiDggmQgtJE)

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/chrissonnenday/the_Drive_public.png)

Play

#155 - Chris Sonnenday, M.D.: The history, challenges, and gift of organ transplantation

#155 - Chris Sonnenday, M.D.: The history, challenges, and gift of organ transplantation

1x15s30s

0:002:14:33

## We discuss:

- What attracted Chris to medicine, and his leadership in residency (3:30);
- How Chris maintained his empathy and humanity through the stresses of med school and residency (8:30);
- Why Chris chose a complicated field like transplant medicine (23:15);
- Explaining kidney transplantation to showcase the challenge of organ transplantation surgery (28:00);
- Overcoming the immune-based challenges of transplant surgery (37:00);
- How the discovery of cyclosporine transformed the field of organ transplantation (49:00);
- Rising chronic kidney failure due to the prevalence of pre-diabetes and metabolic syndrome (53:45);
- Why living kidney donations are superior, and the possibility of a market for kidney donation (59:30);
- Designing a fair system of organ distribution (1:17:30);
- The debate on what constitutes “death” when deciding when to take organs from a registered organ donor (1:21:45);
- Reflections on the gift of organ donation (1:33:15);
- The history of liver transplantation and why it’s so complex (1:39:15);
- Addressing acute liver failure and the amazing baboon experiment (1:46:15);
- The potential for the rising prevalence of NAFLD and NASH to overwhelm the liver transplant infrastructure in the US (1:54:45);
- The importance of teamwork in successful organ transplantations, and the most tragic event Chris has ever witnessed (2:05:45); and
- More.

§

## Show Notes

## What attracted Chris to medicine, and his leadership in residency [3:30]

**Chris’s leadership in residency**

- Peter has long wanted to do a podcast with Chris
- Chris was Peter’s chief resident at Hopkins and played a very important role in his professional development
- Peter has mentioned him in other episodes of [The Drive](https://peterattiamd.com/podcast/) and also on [Jocko Willink’s](https://en.wikipedia.org/wiki/Jocko_Willink) [podcast](https://jockopodcast.com/?s=peter+attia)
- Chris demonstrated “remarkable leadership” and made the difficult process of residency better
- Chris says Peter’s podcast has been very impactful to patients and providers and is a “cool way to see [Peter’s] leadership and impact extend”

**How Chris got interested in medicine**

- Grew up in DC, dad was a Presbyterian minister and mom was a medical social worker
- Only other doc was grandfather who was an internist and researcher in St. Louis
- Only plan in college was to play college soccer
- Parents would support whatever he did as long as he was serving other people
- Chose medicine for cliché reasons: exciting, challenging, problem-solving, serving others
- In med school he liked everything, chose surgery late in process

> “Being a surgeon provides this really unique opportunity to enter people’s lives in their scariest, darkest moments and to have the privilege to be able to walk that with them and try to help them navigate that time and to have skill in some cases to solve the problem.” —Chris Sonnenday

*What attracted Chris to Johns Hopkins?*

- The history of great physicians that went through the program
- He really liked the idea of having an individual mentor
- Consulted with [John Tarpley](https://www.vumc.org/surgical-sciences/person/john-l-tarpley-md), program director at Vanderbilt, who had spent a lot of time doing medical mission work in Africa
- Wanted to get a sense of whether he had a shot of getting into Vanderbilt’s program, but Tarpley encouraged him to apply to Hopkins
- Chris wanted to work with [Keith Lillimoe](https://www.massgeneral.org/doctors/18955/keith-lillemoe), the program director at Hopkins at the time, now the chair of surgery at Massachusetts General Hospital
- Seemed invested in the development and training of his residents, as surgeons, people, and leaders

> “When you feel like you’re just running with superstars every day, that does push you to be the best possible physician, surgeon, person you can be.” —Chris Sonnenday

## How Chris maintained his empathy and humanity through the stresses of med school and residency [8:30]

- Peter says Chris was in a league of his own even among the best: “It’s one thing to say you played for the Yankees, it’s another thing to say you were [Mickey Mantle](https://en.wikipedia.org/wiki/Mickey_Mantle) or [Joe DiMaggio](https://en.wikipedia.org/wiki/Joe_DiMaggio)”
  - Peter says that during residency, people become a bit broken and lose some of their humanity and empathy, lose tolerance for others’ mistakes
  - Chris was the only person he didn’t witness that in, and he was also the best clinically, “an unusual combination that I definitely want to understand … a bit more”
  - Chris says everyone’s inner battle is not visible on the outside
- Chris felt lucky to be there and obligated to maximize the experience
  - When he left, he thanked Keith Lillimoe and [John Cameron](https://en.everybodywiki.com/John_Lemuel_Cameron) for their high expectations that allowed him to accomplish things he didn’t think he could
- Doctors have a lot of hard days and a lot of pressure, but patients have always re-centered him: “That privilege that I was speaking of earlier of being invited into people’s lives in these crazy moments and actually having the opportunity to intervene”

> “The thing that always kind of re-centered me is reminding me that the people upstairs in those beds had it a lot worse off than I did. I think that the privilege of being involved in their care is kind of what recentered me and still does today.” —Chris Sonnenday

- Peter says he was always thrilled to learn he’s be working with Chris on a rotation
- In college Chris was a captain of the soccer team at Northwestern
- Always gravitated towards collaborative team activities, which is why he liked both soccer and transplant medicine
  - brought out the best in him, sometimes being with his team made him feel unstoppable
  - Can’t do transplant surgery without a team

**Morbidity and mortality (M&M) conferences**

- “One of the things that makes surgeons and surgery unique as a discipline is the sense of ownership, accountability, responsibility for the outcomes of the patients that you’re privileged to care for”
- At M&M, reviewed patient cases, especially those without a good outcome
  - Mike Mohan, former chair at Michigan, would say “you could look into a department’s soul by attending their morbidity and mortality conference”
  - Get a sense of accountability: do they blame others (nurse, anesthesiologist, etc.) or talk about what could do better?
- Hopkins M&M shaped the way Chris and Peter think about medicine and responsibility
  - [John Cameron](https://en.everybodywiki.com/John_Lemuel_Cameron), the chair at the time, would start with his own cases to model accountability
  - Peter says Stanford had a different culture, wasn’t nearly as rigorous

**Peter tells a story about one of Chris’s star moments**

- Chris did a very challenging hepatobiliary oncology fellowship with trauma every third night
- Would be told about multiple patients at sign off, and others said he didn’t need to see a patient who is being discharged soon
- But Chris to see him went and discovered something was wrong – maybe [compartment syndrome](https://en.wikipedia.org/wiki/Compartment_syndrome) – but Chris did an operation that likely saved the patient’s limb
- Was unheard of for an attending to go and check a patient whose discharge paperwork had already been signed and catch a mistake
- When Chris presented it at M&M, he never mentioned the circumstances or blamed anyone else; presented it as if it were his fault
- Peter says “That was one of the moments when I realized I’m not good enough to be in this profession”

> “I do certainly carry the philosophy in my work currently and certainly that there is not value in … assigning blame to individuals. There’s only value in recognizing opportunity for us as a system, as a team, to get better”—Chris Sonnenday

- Chris says he could be the one that missed it next time: “I think there’s some humility that has to enter into understanding that no one has all the answers nor should be expected to kind of catch everything”
- Chris thinks the focus of M&M has gradually changed from “whose fault was this?” to “what’s right for the patient?”
  - Better for patients, sets better example for trainees
  - It’s “an important piece of creating the right culture where everybody’s … oars are moving in the same direction”

## Why Chris chose a complicated field like transplant medicine [23:15]

- Chris chose transplant medicine because he loved everything and it allowed him to do lots of things
- Chris worked with [Bob Montgomery](https://en.wikipedia.org/wiki/Robert_Montgomery_(physician)), now the head of transplantation at NYU, on the transplant service during residency
  - Ended being one of the most important influences on Chris’s career
  - Chris aspired to be like him
- Also realized that transplant medicine was very innovative with a short time from bench to bedside (lab findings moving rapidly to clinical applications)
- He was interested in hepatobiliary surgery (surgery of the liver, bile duct, and pancreas) and transplantation was complementary to that
- In other countries, same surgeons do hepatobiliary and liver transplant surgery
  - He wanted to train in both and got to do it and does about half and half in his career
  - “I feel like I won the lottery”
- “Bench to bedside”
  - Transplantation is a young field
  - The first kidney transplants were in the 1950s
  - first liver, heart, and lung transplants attempted in the 1960s
  - not very successful until the 1980s with the development of effective immunosuppression
  - Once became feasible operations, had to develop systems to scale it up
    - so in 1990s when he was a resident, transplants being a reality at most medical centers was really only about 10 years old
    - would experiment with new methods and surgical techniques
    - “a major part of my practice now was created in the 1990s and early 2000s”

> “I think the ability to see innovation become reality in very rapid form was…inspiring. . .It made you feel like you could potentially have some impact in the development of a field that was nascent. . .I feel very fortunate to be a witness to that history and participate in some of it moving forward.” —Chris Sonnenday

## Explaining kidney transplantation to showcase the challenge of organ transplantation surgery [28:00]

**History of kidney transplantation**

- Today, the success rate for kidneys is so high that sometimes residents are allowed to do them
- Bob Montgomery and Peter once did 13 kidney transplants together in a period of around four days
- However, in the 1960s, the mortality rate was >50%
- Only understood anastomosis about 100 years ago, then had to understand the immune system to address both acute and chronic rejection
- Kidney was the first solid organ that seemed feasible to transplant
  - Could imagine how to make it work without doing an orthotopic transplant (taking out old organ and putting in new)
  - Kidney transplants are done heterotopically (give patient an extra kidney but don’t have to remove old ones)
  - Put in pelvis and attach blood vessels, connect ureter to bladder: much easier than removing old kidney and putting new one in same location
- There were lots of issues to work out
  - How do you mitigate the injury to the donor organ from cutting off its blood supply until it is transplanted?
  - How do you manage the recipient’s immune response?
  - The technical and preservation elements were developed before we figured out the immunologic component
- In 1954 at Brigham and Women’s Hospital, [Joseph Murray](https://en.wikipedia.org/wiki/Joseph_Murray) performed the first kidney transplant
  - transplanted one identical twin’s kidney into the other
  - This [proof of principle](https://en.wikipedia.org/wiki/Proof_of_concept) provided the vision that transplantation could work
  - Murray was a plastic surgeon who was interested in the immunology of tissue transfer
  - Knew that skin graft from yourself would likely survive but graft from someone else would not
- In 1950s and 1960s, most kidney transplants performed were between twins, which obviously limited the supply
  - First kidney transplant at UMichigan was performed between twin sisters in 1963, came back for the  5000th transplanted organ celebration
  - But this sidestepped the immunological barriers
- Over the next 4 decades, developed immunosuppressive drugs to make more widespread transplantation a reality
  - Figured out who had pre-formed antibodies to particular donors to avoid them
  - increasingly sophisticated immunosuppression strategies did work
  - drugs like [steroids](https://medlineplus.gov/steroids.html) and [azathioprine](https://medlineplus.gov/druginfo/meds/a682167.html) made transplants possible
- but mortality rates were 50-70%; some rejected the organ and others got infections due to immunosuppression
- But dialysis was not available everywhere and was not routinely covered by insurance
  - Dialysis patients couldn’t even get health insurance until a rider to the law that created Medicare in the 1960s
  - Survival on dialysis was only months to years (2-4 years would have been considered successful)
  - Infection from repeated access, hemodynamic and cardiovascular consequences
  - Average life expectancy on dialysis today is about 10 years because dialysis is more freely available even to those with comorbidities
  - But, “*there were no good solutions for patients with organ failure in those times*.”

## Overcoming the immune-based challenges of transplant surgery [37:00]

**Addressing the challenges of immunocompatibility**

- Today we talk about immune factors like the [major histocompatibility complexes](https://en.wikipedia.org/wiki/Major_histocompatibility_complex) (MHC1, MHC2), but couldn’t for many years
- First challenge was [blood typing](https://en.wikipedia.org/wiki/Blood_type): A, B, AB, O
  - Can give anyone O negative blood, but otherwise must be compatible
  - Our immune system recognizes our own tissues and identifies things that are different
    - Purpose is to recognize things like viruses and other infections
    - Our red blood cells have a particular protein signature that determines our blood type
  - If you have a person with type A blood and you give them blood from a donor with Type B, the recipient’s antibodies will destroy the Type B blood cells because they are identified as foreign
  - Even more complicated by Rh antigens, which give blood an additional characteristic of being positive or negative
  - People with Type O blood are universal donors because people without that blood type do not have preformed antibodies to it
  - Matching blood types is the first step in organ donor matching
- Blood type proteins are not the only proteins on the surfaces of cells that are recognized by the immune system
  - A group of proteins called [human leukocyte antigens (HLA)](https://en.wikipedia.org/wiki/Human_leukocyte_antigen) play a key role in differentiating one individual from another
  - Around 1900, scientists figured out that if you take a skin graft from person A and put it somewhere else on person A’s body, it tends to survive
    - If grafted skin from person B onto person A, would not work
    - If took a second graft from person B and put it on person A, it would die faster than the first graft, “as if the body was primed to destroy that new skin graft”
    - Peter points out that this sounds like a vaccine
  - “Second hit hypothesis:” the immune system learns to recognize foreign tissue and is even more effective in eliminating it after subsequent exposures to same foreign tissue
  - Some of the people who conducted these experiments around the 1950s got Nobel Prizes
- Debate for decades:
  - was there something circulating in the recipient’s serum that found and attacked this tissue, setting off the immune cascade to destroy the tissue?
  - Or was there some sort of priming event where the body presented foreign tissue to the immune system and then the immune system learned how to recognize it as foreign and destroy it?
- With blood incompatibility, there were soluble circulating antibodies that could be identified in a test tube
  - Blood type A has an A antigen, can test if recipient has anti-A antibodies in the lab (“precipitate out a solution”)
  - Can do a test like that for organ compatibility as an initial screening (transplant across match): mix donor and recipient cells, mix in an assay, and see if recipient has preformed antibodies to donor cells
- hyper acute rejection: organ would immediately start to thrombose and die: caused by antibodies to donor HLA antigens
- But in acute rejection, organ is rejected a day or months later
  - figured out it was not antibody mediated or humoral rejection (circulating antibodies) but rather cellular rejection
  - antigen-presenting cells ([T cells](https://en.wikipedia.org/wiki/T_cell)) carrying an antigen from the foreign tissue
  - There is recognition, priming the immune system by various means ([cytokines](https://en.wikipedia.org/wiki/Cytokine), eventual antibody formation, etc.)
- To depress immune system, used high dose steroids, azathioprine, and even total body irradiation in the early stages
  - [Francis Moore](https://en.wikipedia.org/wiki/Francis_Daniels_Moore) was doing this at the Brigham
  - But these things did not prevent cellular level rejection
- Didn’t have effective immunosuppressive agents until the 1980s, that led to longer term survival

**Preserving organs**

- Use solutions to preserve organ between donor and recipient, like the [Wisconsin solution [Viaspan]](https://en.wikipedia.org/wiki/Viaspan)
  - Predecessors of today’s solutions were around by the 80s
  - After remove organ from donor, flush out blood cells so doesn’t clot, put on ice to transport
    - Over decades, discovered that better organ preservation if create specific preservation solutions rather than using plain saline
    - Cellular processes are happening as vessels clamped and organ coming out and before blood flow restored
  - Can be mitigated with right solution
    - tried different electrolyte solutions and additives and other nutrients until they figured out which best mitigated the ischemic period
    - minor details have changed, but essentially have been preserving organs this way since the 1960s and 1970s; this piece was figured out early

## How the discovery of cyclosporine transformed the field of organ transplantation [49:00]

- Discovery of a drug called [cyclosporine](https://en.wikipedia.org/wiki/Ciclosporin) (that comes from a fungus) was a turning point for organ transplants
  - [Sir Roy Calne](https://en.wikipedia.org/wiki/Roy_Yorke_Calne) did experiments showing that cyclosporine prevented rejection in transplant models
  - Interferes with the process that happens when a foreign antigen is presented to a T cell, selective immunosuppressant for events downstream of T cell receptor
  - Affects [IL-2](https://en.wikipedia.org/wiki/Interleukin_2) secretion
- Both cyclosporine and [tacrolimus](https://en.wikipedia.org/wiki/Tacrolimus), which later became another widely used immunosuppressant, are [calcineurin inhibitors](https://www.ncbi.nlm.nih.gov/books/NBK558995/)
  - Debate about how exactly they work
  - function at the level of what are called [immunophilins,](https://en.wikipedia.org/wiki/Immunophilins) soluble intracellular components
  - affect the activation of cytokines, including IL-2, after T-cell recognition
  - they also seem to have other effects on the affinity of T cell receptor binding
  - tacrolimus also has a potent vasoconstrictor effect (constricting blood vessels) in certain organs
- “[Cyclosporine]  literally was a game changer overnight. So if you look at papers written in the 1980s about kidney transplant outcomes, there’s literally an inflection point.”
- Graft survival rates were in the 60-70% range, then went to 90% overnight with cyclosporine (and some refining of multi-drug regimens)
- Revolutionized the impact of kidney transplantation, which was crucial because high rates of end stage renal disease and chronic kidney disease
- Also reinvigorated interest in transplanting other solid organs
  - Liver, heart, and lung transplants had all been on a hiatus through the ’60s and ’70s, but now hope for them to last more than 90 days
  - In 1980s and early 1990s, major medical centers across country stated transplant programs for these organs

## Rising chronic kidney failure due to the prevalence of pre-diabetes and metabolic syndrome [53:45]

**Facing a shortage of kidney donors**

- Most of the demand for kidney transplants is from chronic disease
- Sometimes get acute injury (traumatic events, sepsis, post streptococcal,  etc.), but majority of transplants are due to diabetes or hypertension
- ~ 100,000 people waiting for a kidney transplant in the United States, ~400,000 on dialysis, and ~1,000,000 with chronic kidney disease
  - Impact is huge, really a public health problem
- Peter’s interest is figuring out how to help people live longer and better
  - He says it’s like flying a glider across a 200 foot chasm: if increase chasm to 300 feet, you must figure out how much higher the glider needs to fly
  - He realized that kidney function is key
- Goalposts change with longer life expectancy
  - A [glomerular filtration rate (GFR)](https://en.wikipedia.org/wiki/Glomerular_filtration_rate) in low 40’s at the end of life is ok if aiming for average life expectancy around age 71
  - But if we’re trying to figure out a way to help people live and live well into their 90s or beyond, you can’t have that level GFR in your 70s
  - Check not just [creatinine](https://en.wikipedia.org/wiki/Creatinine#Serum_creatinine) and other biomarkers but [Cystatin C](https://en.wikipedia.org/wiki/Cystatin_C), [microalbuminuria](https://en.wikipedia.org/wiki/Microalbuminuria) twice a year, etc. to catch these issues early
  - High BP now could mean going from a GFR of 95 to 85 in the next decade, which is too precipitous a decline
- “I think the demand for kidneys is only going to go up as we see the rampant explosion of pre-diabetes and metabolic syndrome” – Peter
  - Chris agrees and says we don’t do preventative care very well in this country
- We don’t have reliable measures for some parameters
  - for example, using serum creatinine to measure kidney function
  - The value is dependent on muscle mass and other variables, so there is no normalized number to use as an acceptable range
  - We should be using more sensitive markers like the ones Peter mentioned above
  - We also need to understand and accommodate the relationship among creatinine, GFR, and race
- Problems
  - 1) We don’t measure it well, which obscures size of problem
  - 2) Demand is going to skyrocket: why not transplant 70-year-olds if they’ll live to 90?
    - Pre-diabetes and [metabolic syndrome](https://www.mayoclinic.org/diseases-conditions/metabolic-syndrome/symptoms-causes/syc-20351916) are on the rise
    - progressive kidney dysfunction in an aging population
    - Chris transplanted an 81 year old recently
- Transplant will almost always provide better survival odds than dialysis if patients can tolerate the operation and the immunosuppression
- “So it is kind of remarkable to think of the scope of that problem and particularly to take a longevity lens on it. You know, it’s really kind of an interesting challenge to think about for the next 20, 30 years of transplantation.”

## Why living kidney donations are superior, and the possibility of a market for kidney donation [59:30]

**Living Donation**

- Peter says Bob Montgomery told him that “a **live donor** zero out of six HLA match is always going to beat a six out of six cadaveric match”

> “It’s pretty remarkable to consider the impact of living donation.” —Chris Sonnenday

- Living donation has been part of kidney transplantation from the beginning, as with the identical twins
- Became common in the 1990s
  - At Hopkins, [Lou Kavoussi](https://www.northwell.edu/about/leadership/louis-kavoussi-md) and [Lloyd Ratner](https://columbiasurgery.org/lloyd-e-ratner-md-mph-facs) developed laparoscopic donor nephrectomy, became safer and easier recovery for the donor
  - 18,000-20,000 kidney transplants a year in US now, roughly half with living donors, although the potential is higher
- If compare a patient on dialysis, a patient who receives a deceased donor kidney transplant, and a patient who receives a living donor kidney transplant (similar age, health, and immunosuppressive regimen for transplants) :
  - Dialysis will be less effective within 90 and 250 days depending on patient characteristics
  - But in addition, patients who get kidneys from living donors do better than those from cadavers
    - there is really no way to mitigate the fact that a deceased donor goes through the process and the trauma of brain death or cardiac death
      - the organ has to be put on ice and preserved and transported
      - can be six to 48, 72 hours in some circumstances
    - with living donor can do side-by-side operations, kidney comes from someone normal and healthy; timing can be under an hour
    - The ischemic period [time between removal from donor and putting into recipient] is critical and “almost linearly related to the graft survival”
    - Some of it is ischemia reperfusion injury – cascade that starts is a priming event for the immune system
    - Cadaver kidneys are also more prone to rejection
- Living donor is always preferable
  - Peter points put that also have more flexibility with immunocompatibility with living donor
  - Preferable to have a living donor without perfect HLA compatibility than a cadaver donation with perfect match because of ischemic period

*Paired kidney exchanges*

- The need for living donors has led to [paired kidney exchanges](https://www.donortodonor.com/paired-match#:~:text=A%20paired%20kidney%20exchange%2C%20also,live%20donor%20transplants%20would%20occur.&text=Donor%202%20would%20then%20give%20a%20kidney%20to%20Recipient%201.) to try to expand the compatibility of donors and recipients
  - Example: Chris needs a kidney, Peter is willing to donate, but they are not compatible
  - Perhaps they have different blood types, or Chris might have preformed antibodies to HLA antigens that Peter doesn’t
  - But what if could match them with another donor-recipient pair that doesn’t match?  It would work if Peter were compatible with that recipient and Chris with that donor
  - Then do an exchange where both Chris and other recipient get kidneys and both Peter and other donor give kidneys
  - Kidney swaps / paired exchange began in the 1990s and greatly expanded in the 2000s
- But there are ethical issues
  - Getting relatives on board (in the hypothetical case Peter’s wife Jill) is an important part of discussion
  - what if there’s a difference in kidney quality: for example, one donor is young and the other 75?
  - Or what if one recipient/donor are perfectly match (6/6 HLA) while the other pair is only 3/6?
  - Or one recipient has low level antibodies to the donor?
- A husband-and-wife team, [Dorry Segev](https://en.wikipedia.org/wiki/Dorry_Segev) (surgeon) and Sommer Gentry (mathematician), developed an [algorithm](https://www.baltimoresun.com/entertainment/bs-sm-segev-gentry-20121107-story.html) to maximize predicted outcome
- Now national networks for these kinds of matches which would not have been predictable in the 1990s
- completely dissociated the donor operation from the recipient operation: donors don’t have to travel, recipients have more access

***Should there be a market for kidney donation?***

- Why rely on altruism if we could increase the supply?
- Chris says it’s a “frequently debated and never resolved” proposal
- After cyclosporine, created national networks and infrastructure to distribute organs
  - Law setting up networks made it illegal to sell organs; belief that it should be a gift
  - Ethical principle is donor has autonomy over the decision and must make it freely
  - Concern that it could be coercive to the economically disadvantaged
- A [recent article](https://www.nytimes.com/2021/02/06/world/asia/selling-buying-kidneys-afghanistan.html) in the *New York Times* discussed the growth of the kidney transplantation market in Afghanistan, where wealthy people pay the poor for kidneys and do not care for them afterwards
- We are probably slowly moving towards offering some form of compensation here
- It has even been illegal to reimburse donors for things like transportation to the transplant center, time off work, etc.
  - There is a national advocacy group that provides resources and support to donors that will reimburse them for expenses
  - But what if, for example, we set an amount to compensate for recovery?
- And perhaps living donors should be guaranteed certain health care benefits so they don’t risk losing insurance if they have problems in the future
- Things like this are likely to happen gradually over time, but Chris says that the medical legal environment in the US “will not permit an open market for buying and selling of organs”
- Peter supports ongoing medical coverage for donors
  - Says it’s like the [debate about NCAA athletes](https://www.nytimes.com/2020/02/11/sports/should-college-athletes-be-paid.html) – they generate revenue for the university but can’t even accept small gifts
  - Peter thinks should at least cover their medical bills for life if have sports-related injuries because profited off them

## Designing a fair system of organ distribution [1:17:30]

There are some states in which you’re better off or more likely to get an organ, like a liver for example, than other states. *How does that work, and what would be the best states to live in if you’re vying for an organ versus the worst?*

- Some states Used to depend on factors like which state you lived in
  - Was a real problem when Peter and Chris were in residency, but it now much better after an intentional policy change
  - In a highly populous state like California or major urban centers like NYC, supply does not meet demand
  - But in less populated regions like parts of the midwest and south, more donors than recipients, so there was a disparity based on where you lived
- There are ~58 non-profit [organ procurement organizations](https://unos.org/transplant/opos-increasing-organ-donation/#:~:text=Organ%20Procurement%20Organizations%20(OPOs)%20are,their%20assigned%20donation%20service%20area.) (OPOs) throughout the US
  - Number varies by state: Michigan has one, Texas has 6
  - Identify organ donors and facilitating the process from procurement to transplant
  - Maintain waiting lists according to a predetermined algorithm of how that particular organ is prioritized
  - That way, every available organ can be matched with a recipient
- Used to prioritize region/state first, now offered based on distance from donor hospital
- Now less geographic variation across country so, for example, patients don’t have to go to a certain place if need a liver
- If you are very ill you will get transplanted more quickly because have access to more donors
- But if “medium” sick, very sick people will be ahead of you
  - need to expand donor pool (and living donors for kidney and liver)
  - “So the system has gotten more fair, but it’s only exposed the need even more”
- Peter is glad about these system changes because he thought the old system was unjust, especially for liver allocation

## The debate on what constitutes “death” when deciding when to take organs from a registered organ donor [1:21:45]

- Matters a lot because most donations are from cadavers, even with liver
- Can’t just look up definition of “brain death” in a medical dictionary
- The importance of establishing brain death was driven by the development of transplantation
- Cardiopulmonary death (when heart stops): is that death, or is it when the brain has lost function and control?
- Confusing to understand how body can be alive but brain dead
  - Brain sustains an injury from: anoxia (lack of oxygen), traumatic event (penetrating injury or head trauma), intracranial event (e.g., brain bleed that increases intracranial pressure, stopping or reducing blood flow and oxygen delivery to the brain and thus cellular processes)
  - Clinically, see “blown pupils” (fixed and dilated), no respiratory drive, loss of brain stem reflexes
  - To be formally diagnosed with brain death, person must be hemodynamically stable, not hypothermic, and not in a metabolic state that could confuse diagnosis
- Apnea test: stop breathing support to see if person has drive to breathe on own
- Use combination of brain death exams and studies to establish that blood flow to the brain has stopped
- Critical to come to a consensus on that definition
- If person meets definition but still has circulation, can be donor, but establishing brain death is critical so organ procurement is not causing death which clearly violates ethical principles
- Peter says important to understand that brain death still requires cardiopulmonary support; without a functioning brain your heart and lungs cannot work on their own
- Do apnea test while still hooked up to respirator – if turn it off and they don’t breathe, turn it back on so organs still getting oxygen
- Peter points out that the doctors taking care of patient for their underlying problem are not the same doctors who remove the organs: “that would seem a little grotesque”
  - Systems being completely separate is an “ethical principle that is central to not only the effective operationalizing of transplant, but also to the establishment of the public trust”
  - Must confirm brain death and establish willingness of family and patient through documentation to be a donor
  - Transplant team has no involvement in treatment decisions, only after brain death established
  - Clear transition from ICU team to transplant team
- Chris notes how generous it is for families to come forward to say they want loved one to be a donor on the worst day of their life
- Donation after cardiac death is more complicated
  - When patient will not live but not technically brain dead
  - still needs to be establishment of death before organ procurement
  - family chooses to withdraw care, person dies naturally, then decide if organs can be donated
  - family decides whether to donate before withdrawal of care so team can be ready, but person must be declared dead by a doctor separate from transplant team
  - “So I think even in the case of donation after cardiac death, we’ve kept that very clear delineation between individuals caring for the patient and individuals processing the gift of the donor for transplant”

## Reflections on the gift of organ donation [1:33:15]

- Peter’s childhood friend died in a car crash as a young man
  - His single mom had to make decision on worst day of her life, donated every part of his body
  - Multiple people benefited: two different recipients got his liver, others got kidneys, heart, lungs, corneas
- Friends of Peter’s named [Jeff and Teena Webster](https://www.nwaonline.com/news/2009/dec/20/organ-donor-family-meets-recipients/) had lost their 20-year-old son [Aaron](https://www.uatrav.com/news/article_ab273494-cbd4-59f5-8a7c-5a39225010f9.html) in a car accident
  - Donated all of his organs and got to know every one of the recipients
  - Man who got his liver has a tattoo of their son on his arm
- People ask Chris (and sometimes his oldest daughter if people know her father is a transplant surgeon) if they should be donors
  - People hesitate because of false ideas that it will impact their own healthcare
  - “But I always try to focus on the profound impact that transplantation can have, and try to share with them what I’ve learned from donor families over the years”
- Chris does advocacy work with donor families, who can tell poignant stories of what donation meant to them

> “The experience of organ donation and knowing that their loved one’s organs live on in another individual and saved their life is the only good thing about what was otherwise the worst day of their lives … [Donor families] took some solace in the fact that you were honoring their life by passing on the gift of their organs to another individual. So I think it’s important for people to hear that it can be a transformative gift.” —Chris Sonnenday

- Chris also tells people how great the need is
  - currently more than 100,000 people waiting for various organs but fewer than ~40% receive a transplant each year
  - “The gap between donation and supply grows each year”
- Outcomes for recipients also improve each year, sometimes normal quality of life and close to normal life expectancy
- But Chris does acknowledge it’s a personal decision and people must be comfortable with it
- People should make the decision themselves and tell their families
  - it’s very difficult for families to do it on such a difficult day in an unfamiliar hospital – it’s a gift to family that makes things easier for them
  - Peter says that having an advanced directive is the greatest gift you can give your family so there is no ambiguity about your wishes

## The history of liver transplantation and why it’s so complex [1:39:15]

**History of liver transplantation**

- A liver transplant is one of the most technically demanding operations in the transplant field
- In 1963, [Thomas Starzl](https://en.wikipedia.org/wiki/Thomas_Starzl), a newcomer no one had yet heard of, figured out that you could add the steroid [prednisone](https://www.kidney.org/content/what-you-need-know-about-prednisone) to Imuran (azathioprine) and greatly improve the survival rates of that time (he was getting ~70% survival at one year)
- But 4 years later, a 3-year-old bled to death on his operating table, which led to a moratorium on liver transplants

*What is it about the liver that is so difficult to surgically implant?*

- Complex anatomy of the liver
  - largest solid organ
  - Dual blood supply
    - supplied by the [hepatic artery](https://en.wikipedia.org/wiki/Common_hepatic_artery#:~:text=The%20common%20hepatic%20artery%20is,Details), a major branch of the [aorta](https://en.wikipedia.org/wiki/Aorta)
    - and the [portal vein](https://en.wikipedia.org/wiki/Portal_vein), which is the blood drainage of all of the intestinal blood flow
  - The liver filters all of the metabolites absorbed in the GI tract
  - Is above the [vena cava](https://en.wikipedia.org/wiki/Venae_cavae), the major vein returning blood from the lower part of the body back to the heart
  - below the [diaphragm](https://en.wikipedia.org/wiki/Thoracic_diaphragm) and right [atrium](https://en.wikipedia.org/wiki/Atrium_(heart)) with a complex venous network that drains into the vena cava
  - So it’s very difficult to transplant
  - Intrahepatic anatomy is complex as well
- Also, the diseases for which transplants are typically done ([cirrhosis](https://en.wikipedia.org/wiki/Cirrhosis) or the end stages of chronic liver disease and fibrosis) cause problems
  - Synthetic failure of liver: loss of ability to process some metabolites and make critical proteins like the ones necessary for blood clotting
  - Liver has also become scarred and [fibrotic](https://en.wikipedia.org/wiki/Fibrosis), it’s like the intestinal blood flow now passing through rock instead of sponge
    - Develop [portal hypertension](https://en.wikipedia.org/wiki/Portal_hypertension): pressure in portal venous system increases, blood needs to find another way back to the heart and collateral channels are formed
    - Collateral channels form [varices](https://en.wikipedia.org/wiki/Varices) in the GI tract and can lead to life-threatening hemorrhage and [ascites](https://en.wikipedia.org/wiki/Ascites) (fluid retention that causes a protuberant, distended abdomen)
    - The surgical field has become a “rat’s nest of collateral venous vessels”
- So large organ, challenging anatomy, and a patient at higher risk for bleeding but without normal clotting factors
- Liver failure also leads to [cachexia](https://en.wikipedia.org/wiki/Cachexia) (muscle wasting) and muscle loss, so the patients are debilitated and sick on top of having a major operation under suboptimal conditions
- Back when Tom Starzl and his contemporaries took that operation on in the 1960s, didn’t really have electrocautery, blood banks, or current critical care anesthesia
  - “it’s pretty remarkable that [a liver transplant] was even conceptualized, much less achieved technically”
  - Technically demanding and poor immunologic conditions
  - First dozens of transplants had no survivors past 90 days, so moratorium in late 1960s
- Problems unique to liver
  - liver patients are extremely ill
  - all other transplanted organs have some kind of extra corporeal support that can support or improve them prior to surgery, but liver does not
    - One of the many reasons for this is that a machine cannot regulate blood glucose
    - “It is so complicated to manage [gluconeogenesis](https://en.wikipedia.org/wiki/Gluconeogenesis), [glycogen](https://en.wikipedia.org/wiki/Glycogen) storage. …  You have to be able to regulate something to the milligram level with seconds to spare”
    - No mechanical and anatomic models for “liver dialysis” have been successful
  - Trying to remove toxins in bloodstream that damaged liver can’t filter
  - Can address portal hypertension to some extent, but not synthetic function
  - Could have a physiologic solution: hepatocytes can regenerate, so if someone has liver toxicity, can just support them until new hepatocytes form

## Addressing acute liver failure and the amazing baboon experiment [1:46:15]

- [Mel Williams](https://asts.org/about-asts/chimera-chronicles/profiles/g-melville-williams-md#.YFpfYq9KgdV) was a contemporary and a student of [David Hume](https://en.wikipedia.org/wiki/David_M._Hume), one of the godfathers of transplant and transplant immunology
- Trained in Hume’s lab, as had [Christiaan Barnard](https://en.wikipedia.org/wiki/Christiaan_Barnard), who did the first heart transplant
- Williams started the transplant program at Johns Hopkins
  - Had himself received a kidney transplant from his wife
  - Was a great storyteller

“*They decided, ‘Well, why don’t we address acute liver failure by hooking up the patient to a extra corporeal, essentially bypass circuit and put a baboon on the other side of the circulation*.’”

- Decided to hook patient up to a bypass circuit with a baboon with idea that the baboon’s liver would filter the toxins and then the filtered blood would be returned to the patient
  - Had done pre-clinical studies and somehow got IRB approval
  - Turns out it’s pretty hard to sedate a baboon, so they put the baboon in a body cast
  - “*unbelievably, it starts to work*”
  - Patient’s [encephalopathy](https://en.wikipedia.org/wiki/Encephalopathy) improves, looks over and sees baboon, begins pulling at lines so put him in a body cast too
- But showed that it would work to have a functional liver in cross-circulation with a diseased one

- Have done bypass successfully using family members of liver patients
- There is now an investigational product with a cell line that populates the hepatocytes
  - studies indicate it may be able to provide some limited short-term support
  - But lack of long-term extracorporeal support method means that patients will die without transplant

**Acute liver failure**

- Overdose case from Peter’s residency
  - 21-year-old woman who overdosed on Tylenol
  - Tylenol is quite dangerous yet widely available
  - LD50: the lethal dose at which 50% of the population would be dead from a drug
    - LD50 of Tylenol is ~ 10 to 20 times more than a normal dose
    - easier than one might think to overdose on Tylenol
  - This patient had taken a bottle of Tylenol after she broke up with her boyfriend, then regretted it
  - Before she went into acute liver failure and encephalopathy made her unaware, her [PT/INR](https://medlineplus.gov/lab-tests/prothrombin-time-test-and-inr-ptinr/), [PTT](https://medlineplus.gov/lab-tests/partial-thromboplastin-time-ptt-test/), and [LFT](https://www.mayoclinic.org/tests-procedures/liver-function-tests/about/pac-20394595)s were through the roof and she could understand that she was going to die without a liver transplant
  - She did get the transplant “and it was just amazing to see her wake up from that and realize she had another lease on life”
  - We all make mistakes and deserve a second chance
- Acute liver failure is the reason for ~5% of the liver transplants done in the United States
  - liver is fairly resilient
  - sometimes patients recover even after a catastrophic overdose with good critical care and other interventions
- but if need transplant, have to make decision about whether they’re good transplant candidate with limited information
  - sometimes they are not, for example if they have comorbid disease
  - but it’s often a young distressed person who made an impulse decision
    - most transplant centers try to get them a transplant “and then use all the appropriate resources afterwards to help support them and make sure that any mental health issues … are addressed”
    - tragic and dramatic circumstances, but can be incredibly rewarding transplants because patients are transformed

## The potential for the rising prevalence of NAFLD and NASH to overwhelm the liver transplant infrastructure in the US [1:54:45]

- Thought it was going to be [Hepatitis C](https://en.wikipedia.org/wiki/Hepatitis_C)
- instead will likely be [non-alcoholic fatty liver disease](https://en.wikipedia.org/wiki/Non-alcoholic_fatty_liver_disease) (NAFLD) / [non-alcoholic steatohepatitis](https://en.wikipedia.org/wiki/Non-alcoholic_fatty_liver_disease) (NASH), which may already be the leading indication for liver transplant in the developed world
- Hep C
  - viral bloodborne illness
  - Rarely causes acute illness
  - A few people can clear the virus, but most have chronic viremia and inflammation for years
    - In 70s and 80s many people got it through IV drug use or other exposures and some through blood transfusions
    - Now 20-30 years they have cirrhosis and eventually develop complications and need a transplant
  - For about 20 years, Hep C was the predominant indication for transplant in the United States
    - Meds to treat Hep C were not very effective (response rates  ~15-30%)
    - Would have recurrent Hep C after transplant and develop graft failure and cirrhosis
  - But in last 10 years, development of effective antiviral agents
    - Chris would categorize these medications as being in the top or 3 greatest medical advances he’s seen in  his career
    - Peter doesn’t think he’s seen anything more impressive in his adult life
    - Chris says maybe only the antiretroviral regimens that made HIV a chronic disease instead of a deadly one could rival it
  - Thought patients cured of Hep C who had already developed cirrhosis would still eventually need transplants
    - But once hep C is cleared from the body, liver able to re-compensate and repair somewhat
    - precipitous drop in the number of patients needing transplant for hepatitis C over last 3-5 years

*Two other kinds of liver disease are becoming major factors in liver transplants*

- **Non-alcoholic fatty liver disease (NAFLD)**

- - Fatty deposition in the liver that leads to chronic inflammation, fibrosis, and eventually cirrhosis
  - Increased with obesity and associated diseases
  - Predicted to become the leading indication for liver transplantation
  - Curve already starting to inflect up

- **Alcohol-related liver disease**

- - Numbers exploding
  - perhaps due to economic downturn in 2000s and made worse by pandemic
  - Approach to patients with alcoholic liver disease has evolved from “the Spanish Inquisition” into an approach “where we have developed resources, mental health professionals, [and] counselors … to support people in their sobriety to allow them to get transplanted successfully”
- Chris says we lack an intervention for fatty liver disease that will reduce the curve quickly
  - Unlike other kinds of liver transplant patients (alcohol, hep C), fatty liver disease population have co-morbidities like obesity (which poses a surgical risk) and other consequences of metabolic syndrome like cardiovascular disease and hyperlipidemia
- Liver transplant population is now similar to kidney transplant population “because they’re dealing with these cardiovascular comorbidities and other things that are threatening their long-term survival as much as their liver disease and immunosuppression is”

**Comparing opioid and alcohol use**

- Peter says it’s fair to throw opioid manufacturers and doctors who prescribed them too freely under the bus
  - The “elephant in the room” is why people are self-medicating with opiates
  - The outcomes are very binary and stark
- But acute alcohol toxicity is very rare; it’s a chronic problem
  - It’s transplant doctors or hepatologists who see the consequences
  - For most people it doesn’t register that opiates and alcohol are two sides of the same coin
- Chris says perception is different and we treat them differently both medically and sociologically
  - Prevents us from properly addressing the problem
  - Hepatologist at UMichigan, [Jessica Mellinger](https://ihpi.umich.edu/our-experts/jmelling), is dedicated to understanding alcohol-related liver disease
    - She treats it as a behavioral disease
    - Chris thinks you could make the same case for NASH, in which case we need to put resources into addressing the behavior
  - We’ve ignored alcohol abuse because have to go through a lot of machinations and destruction to get opiates
  - But it’s easy to get an equivalently damaging dose of alcohol, so it’s harder to address
- Chris is glad to see transplant and medical community focusing on how to help people escape the cycle
  - The population with alcohol-related liver disease is now “ridiculously young” – have drink enough to destroy their livers by their 20s and 30s, not like the 65-year-olds with cirrhosis and complications he used to see
  - Peter says people think of the Mickey Mantle story, but this is the same disease
- “One population numbs with an acute numbing agent, opiates, that have an acute toxicity, and the other numbs with a chronic numbing agent that has a chronic toxicity. And to somehow put those into different silos, when I think the underlying conditions are similar, is probably slowing our progress”

## The importance of teamwork in successful organ transplantations, and the most tragic event Chris has ever witnessed [2:05:45]

- Peter says transplant is a field (like pediatric cardiac surgery) that really involves teams
- Perfusionists, surgeons, anesthesiologists, nurses, ICU staff, and people carrying out the logistics of organ procurement
- [Tragic story about Michigan team](https://www.nytimes.com/2007/06/06/us/06docs.html)
  - Team of 6 people from Michigan flew to Milwaukee, procured lungs from a donor, and got on plane to deliver lungs to recipient in Michigan
  - Plane crashed and all 6 died: 2 pilots, 2 perfusion staff who care for organ in between donor and recipient, a surgeon and a fellow
  - Chris says, “It was the most devastating event that I’ve ever witnessed professionally”
  - Intended recipient was lying on operating table with an open chest
  - Made them aware of how valuable each member of team is and how much is at stake
  - Made the field ask if teams should be flying all over when qualified surgeons are close to the donor organ, which pilots and planes to use, etc.
  - These days, more than half of the time, the organ is procured and then shipped to the transplant team
  - Peter says hard to believe the plane crash was 13.5 years ago, remembers it like it was yesterday
- Peter has fond memories of sitting with Chris in the middle of the night between traumas
  - he’d rather be learning from Chris than sleeping
  - Patients are lucky to have Chris as their doctor
- Chris is glad Peter is using his platform to highlight the importance of organ donation

§

## Selected Links / Related Material

**Peter appearance on Jocko Willink’s podcast on which he mentioned Chris:** [56: Overcoming Stress, Sleep Deprivation, and The Darkness with Peter Attia](https://jockopodcast.com/?s=peter+attia) **|** (jockopodcast.com) [3:00]

**Normal value ranges for glomerular filtration rate**: [Glomerular filtration rate (GFR)](https://en.wikipedia.org/wiki/Glomerular_filtration_rate) (en.wikipedia.org) | [55:00]

**Article about Dorry Segev and Sommer Gentry’s algorithm to match pairs of kidney donors**[: ‘Genius’ pair rewrite rules of organ transplants, among other interests](https://www.baltimoresun.com/entertainment/bs-sm-segev-gentry-20121107-story.html) | Mary Carole McCauley, The Baltimore Sun | [1:10:15]

**Article about the market for kidneys in Afghanistan**: [In Afghanistan, a Booming Kidney Trade Preys on the Poor](https://www.nytimes.com/2021/02/06/world/asia/selling-buying-kidneys-afghanistan.html) | Adam Nossiter and Najim Rahim, *The New York Times* | [1:12:15]

**Summary of debate about whether college athletes should be paid**: [Should College Athletes Profit from Their Fame? Here’s Where the Debate Stands](https://www.nytimes.com/2020/02/11/sports/should-college-athletes-be-paid.html) | Alan Blinder, *The New York Times* | [1:17:00]

**The story of Aaron Webster donation all of his organs after tragic death**: [Where his treasure is: UA student makes a difference even in death](https://www.uatrav.com/news/article_ab273494-cbd4-59f5-8a7c-5a39225010f9.html) | Bailey Elise McBride (uatrav.com) [1:34:30]

**Article about plane crash that killed several members of Michigan transplant team**: [Transplant Team Dies in Jet Crash; Mechanical Problems Suspected](https://www.nytimes.com/2007/06/06/us/06docs.html) | Nick Bunkley, *The New York Times* | [2:06:45]

§

# DRUGS MENTIONED

- [Azathioprine](https://medlineplus.gov/druginfo/meds/a682167.html) (Imuran, Azasan): (Anti-rejection drug given to transplant patients) [34:00]
- [Steroids](https://medlineplus.gov/steroids.html) (e.g., [prednisone](https://www.kidney.org/content/what-you-need-know-about-prednisone)): (Corticosteroid drugs that suppress the immune system) [34:00, 1:39:00]
- [Cyclosporine](https://en.wikipedia.org/wiki/Ciclosporin) (Neoral, Sandimmune, Restasis): (Fungal-derived calcineurin inhibitor whose discovery transformed the field of organ transplantation) [49:00]
- [Tacrolimus](https://en.wikipedia.org/wiki/Tacrolimus) (Prograf): (Bacteria-derived calcineurin inhibitor that is more potent than cyclosporine) [50:30]

§

## People Mentioned

- [John Gretton “Jocko” Willink](https://en.wikipedia.org/wiki/Jocko_Willink) (Retired Navy SEAL, co-founder of the consulting company [Echelon Front](https://echelonfront.com/), and host of the [Jocko Podcast](https://jockopodcast.com/?s=peter+attia)) [2:30]
- [John Tarpley](https://www.vumc.org/surgical-sciences/person/john-l-tarpley-md) (Former director of the surgery program at Vanderbilt who encouraged Chris to apply to Hopkins) [6:15]
- [Keith Lillimoe](https://www.massgeneral.org/doctors/18955/keith-lillemoe) (Former director of the surgery program at Johns Hopkins, currently chair of surgery at Massachusetts General Hospital) [6:15, 9:45]
- [Mickey Mantle](https://en.wikipedia.org/wiki/Mickey_Mantle) (Hall-of-Fame baseball player for the New York Yankees who struggled with alcoholism and received a liver transplant) [8:30, 2:05:15]
- [Joe DiMaggio](https://en.wikipedia.org/wiki/Joe_DiMaggio) (Hall-of-Fame baseball player for the New York Yankees) [8:30]
- [John Cameron](https://en.everybodywiki.com/John_Lemuel_Cameron) (Former chief of surgery at Johns Hopkins) [9:45, 17:15]
- [Robert Montgomery](https://en.wikipedia.org/wiki/Robert_Montgomery_(physician)) (Director of the Transplant Institute at NYU whom Chris worked with at Hopkins and calls “a transformative figure in our field over the last couple of decades”) [23:30, 28:00, 59:30]
- [Joseph Murray](https://en.wikipedia.org/wiki/Joseph_Murray) (Surgeon who performed the first kidney transplant at Brigham and Women’s Hospital in 1954 and shared the 1990 Nobel Prize) [30:30]
- [Francis Moore](https://en.wikipedia.org/wiki/Francis_Daniels_Moore) (Pioneering American surgeon) [56:15]
- [Roy Calne](https://en.wikipedia.org/wiki/Roy_Yorke_Calne) (British surgeon Chris calls “one of the central figures in the history of transplants” who did experiments showing that cyclosporine prevented rejection in transplant models) [49:00]
- [Louis Kavoussi](https://www.northwell.edu/about/leadership/louis-kavoussi-md) (Surgeon who pioneered laparoscopic nephrectomy for renal transplants) [1:01:30]
- [Lloyd Ratner](https://columbiasurgery.org/lloyd-e-ratner-md-mph-facs) (Surgeon who performed the first successful laparoscopic live-donor nephrectomy in 1995) [1:01:30]
- [Dorry Segev](https://en.wikipedia.org/wiki/Dorry_Segev) (Surgeon at Hopkins who co-developed a model for a national paired exchange for kidney donation with his wife, a mathematician)  [1:10:15]
- [Sommer Gentry](https://en.wikipedia.org/wiki/Sommer_Gentry) (Mathematician who co-developed a model for a national paired exchange for kidney donation with her husband, a physician) [1:10:15]
- [Jeff and Teena Webster](https://www.nwaonline.com/news/2009/dec/20/organ-donor-family-meets-recipients/) (Arkansas couple who donated all of their son Aaron’s organs and later met all the recipients) [01:34:30]
- [Aaron Webster](https://www.uatrav.com/news/article_ab273494-cbd4-59f5-8a7c-5a39225010f9.html) (20-year-old college student whose organs were donated to multiple recipients after he died in a car crash) [01:34:30]
- [Thomas Starzl](https://en.wikipedia.org/wiki/Thomas_Starzl) (Surgeon who discovered that adding prednisone to azathioprine dramatically increases transplant survival rates and performed the first successful liver transplant) [1:39:00, 1:43:45]
- [G. Melville Williams](https://asts.org/about-asts/chimera-chronicles/profiles/g-melville-williams-md#.YFpfYq9KgdV) (Transplant surgeon who performed liver bypass between a human and baboon) [1:46:15]
- [David Hume](https://en.wikipedia.org/wiki/David_M._Hume) (Kidney transplant surgeon whom Chris calls “one of the godfathers of transplant and transplant immunology”) [1:46:15]
- [Christiaan Barnard](https://en.wikipedia.org/wiki/Christiaan_Barnard) (South African surgeon who performed the first human-to-human heart transplant in 1967) [1:46:15]
- [Jessica Mellinger](https://ihpi.umich.edu/our-experts/jmelling) (Hepatologist at UMichigan who focuses on alcohol-related liver disease) [2:03:15]

§

![](https://peterattiamd.com/wp-content/uploads/2021/03/bio-image-sonnenday-500x500.png)

##### Chris Sonnenday, M.D.

Christopher Sonnenday, M.D., M.H.S., is the Surgical Director of Liver Transplantation and Associate Chair for Clinical Affairs for the Department of Surgery at the University of Michigan. He is also an Associate Professor in the Department of Surgery and Associate Professor of Health Management and Policy at the School of Public Health. Dr. Sonnenday received his medical degree from Vanderbilt University and did his residency in general surgery at Johns Hopkins, where he also completed a Masters of Health Sciences in Clinical Investigation at the Bloomberg School of Public Health. He did fellowships in surgical oncology at Johns Hopkins and in abdominal transplant surgery at the University of Michigan. Dr. Sonnenday’s clinical interests focus on liver transplantation, hepatobiliary and pancreatic surgery, and general surgery procedures in patients with advanced liver disease.

Twitter: [@HPB\_Txp\_Surg](https://twitter.com/hpb_txp_surg?lang=en)