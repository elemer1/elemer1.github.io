# #10 – Matt Kaeberlein, Ph.D.: rapamycin and dogs — man’s best friends? — living longer, healthier lives and turning back the clock on aging and age-related diseases

**Source:** [https://peterattiamd.com/mattkaeberlein/](https://peterattiamd.com/mattkaeberlein/)

---

##### Check out more content with expert, Matt Kaeberlein, Ph.D.:

- *(Aug 20, 2018)* [Rapamycin and dogs — man’s best friends? — living longer, healthier lives and turning back the clock on aging and age-related diseases](/mattkaeberlein/)
- *(Sep 13, 2021)* [The biology of aging, rapamycin, and other interventions that target the aging process](/mattkaeberlein2/)
- *(May 16, 2022)* [AMA #35: “Anti-Aging” Drugs — NAD+, metformin, & rapamycin](/ama35/)

Matt is someone who is deeply interested in understanding the biology of aging. Why do we age? What happens to us as we age? What are the things we can do to slow the aging process? How can we delay or prevent the onset of age-related diseases? These are all questions that Matt thinks deeply about, and explores these questions with his research at the University of Washington. He is currently investigating many of these questions through the Dog Aging Project and the compound rapamycin—the only known pharmacological agent to extend lifespan all the way from yeast to mammals—across a billion years of evolution. We talk about cancer, heart disease, Alzheimer’s disease, healthspan, lifespan, and what we can do to provide longer, healthier lives for both people and dogs.

![The Peter Attia Drive](images/mattkaeberlein/the_Drive_public.png)

Play

#10 - Matt Kaeberlein, Ph.D.: rapamycin and dogs — man's best friends? — living longer, healthier lives and turning back the clock on aging, and age-related diseases

#10 - Matt Kaeberlein, Ph.D.: rapamycin and dogs — man's best friends? — living longer, healthier lives and turning back the clock on aging, and age-related diseases

1x15s30s

0:001:32:45

## We discuss:

- Matt’s early years and his aha moment on aging [4:00];
- Studying dogs [6:30];
- Dogs, rapamycin, and its effects on lifespan and healthspan [15:30];
- An unexpected finding in presumably healthy dogs [36:00];
- Rapamycin in cancer treatment [50:00];
- Why isn’t there a rapamycin trial for Alzheimer’s disease (AD)? [1:01:30];
- If Matt could do a definitive study on life extension in dogs, with resources not being a concern, what does that experiment look like? [1:16:00]; and
- More.

§

## Show Notes

## Matt’s early years and his a-ha moment [4:00]

- Matt’s background
- Matt’s aha moment after watching a talk by Lenny Guarente on the biology of aging
- Matt did his thesis on sirtuins (Sir2 in yeast) at MIT
  - He ultimately found that overexpressing Sir2 extends lifespan in yeast ([Kaeberlein et al., 1999](https://www.ncbi.nlm.nih.gov/pubmed/10521401))
  - His colleague, Heidi Tissenbaum, found the same (*sir-2*) in worms ([Tissenbaum and Guarente, 2001](https://www.ncbi.nlm.nih.gov/pubmed/11242085))

## Studying dogs [6:30]

- Origins of the [Dog Aging Project](https://dogagingproject.com/)
- When we’re talking about mammals in studies, we’re almost always talking about mice. What are the problems with that?
- The benefits of using dogs in studies
  - Dogs live in a similar environment as humans
  - Mixed-breed populations for more heterogeneous studies
  - Can do genetically-restricted studies as well
- Do dogs die of the same diseases, and in the same frequencies, as humans?
  - Most pet dogs die from euthanasia
  - NB: What people die from does not always equate with what people die with
  - Most people are dying of multiple comorbidities
  - In general, dogs get the same diseases as humans, but at different frequencies
  - Relatively little vascular disease in dogs
  - Some breeds die of heart disease
  - Cancer is the most common in most dogs
  - Kidney disease is a major cause of death in dogs
  - There’s a debate as to whether dogs get Alzheimer’s disease (they do get amyloid-beta in the brain)
  - Different breeds have a different predisposition to different diseases

## Dogs and rapamycin [15:00]

- Treating healthy dogs with rapamycin
- What level of risk should we tolerate when considering studies on “healthy normals?”
- There’s a very low tolerance for side effects and safety when it comes to treating healthy subjects
- Is the perception that rapamycin has a lot of side-effects the reality?
- Is there a “right” dose and frequency for rapamycin? Does the [peak or the trough](https://medical-dictionary.thefreedictionary.com/peak+and+trough) level play a bigger role in toxicity?
  - Data suggest that [trough](https://en.wikipedia.org/wiki/Trough_level) levels are most correlated with side effects
  - A lot of work that needs to be done on dose and timing to elucidate effects on lifespan and healthspan
- How can rapamycin be used as an immunosuppressant (i.e., reduce T cell proliferation) in some cases and become immunoprotective (i.e., improvement in T cell function) in others?
  - Data suggesting rapamycin can be used as an immunosuppressant is based on higher doses, in people who are also taking multiple drugs which are also immunosuppressants
  - Unclear whether rapamycin has immunosuppressant qualities as a monotherapy
  - When short-term treatment is followed by a washout, when vaccine response (i.e., immune function) is tested, you get a better response
  - One model: treatment with rapamycin is restoring immune function in an aged animal, probably through enhanced stem cell function, and you might need a washout period, if there is an immunosuppressant effect of the compound, to see the rejuvenation effects
- Matt’s [10-week study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5411365/) of rapamycin in middle-aged healthy companion dogs looking at heart function as their short-term measure
- Mouse data has shown that if you take a 20-24 month-old mouse (about the equivalent to a 60-65-year-old person), and look at the heart vs a 6-month-old mouse, you can see declines in heart function just as you can in people
- Rapamycin studies have mostly looked at left ventricular function of the heart (i.e., ejection fraction [EF], fractional shortening [FS], and E/A ratio) via echocardiography
- Three independent studies have shown that 6-10 weeks of rapamycin treatment is enough to cause those measures of heart function in old mice to bring the function back to about halfway to the young mice (takes a 60-65-year-old back to about a 30-year-old in a human equivalent approximation)
  - All three studies used encapsulated rapamycin (i.e., eRAPA or encapsulated rapamycin fed in the diet) vs injection (all three independent studies in mice used eRAPA)
  - About 80-85% of the studies done on aging in mice used eRAPA
  - Different from a pill or an injection
- Is dosing dogs the same as dosing humans?
  - Hard to translate dosing across species given different metabolisms
- How did Matt come up with dosing and scheduling rapamycin for dogs?
  - Connected with a group at the University of Tennessee (UT)
  - Based on their dosing and delivery protocol, Matt could increase his confidence in mitigating side effects
  - UT group’s strategy: 0.1 mg/kg 3x/week (M/W/F)
  - Matt went with this strategy for the highest dose
  - 0.05 mg/kg 3x/week for the lower-dose group
  - Dogs had to be ≥ 40 lbs and ≥ 6 years old without any preexisting conditions
  - Roughly the human equivalent of 55 years-old

## An unexpected finding in presumably healthy dogs [36:00]

- Why did Matt have to exclude so many dogs from his study?
  - 20% of dogs had asymptomatic heart disease showing up on an echocardiogram
  - Needed to have the discussion with the cardiologist: what’s normal aging vs what’s disease in these dogs?
- Main outcome: no evidence for increased side-effects (owners filled out weekly surveys)
- Blood chemistry: no significant changes
- Matt saw improvements in heart function (FS and E/A ratio reached statistical significance, EF reached a *p* value of 0.06) in the treated dogs
  - Ejection Fraction (EF): Percentage of the end-diastolic left ventricular blood volume that is ejected from the left ventricle during systole. [[Urfer et al., 2017](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5411365/)]
  - Fractional Shortening (FS): Percentage by which the left ventricular interior diameter is reduced at peak systole as compared to that of end-diastole. [[Urfer et al., 2017](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5411365/)]
  - E/A Ratio: Ratio of early- to late- diastolic velocity of blood flowing from the left atrium into the left ventricle. [[Urfer et al., 2017](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5411365/)]
- Dogs that got the biggest benefit with rapamycin are the ones that started with the lowest function
- A potentially fascinating case study of a Doberman and cardiac function from Matt’s study
  - Doberman’s are highly prone (60-65%) to [dilated cardiomyopathy](https://www.animalerc.com/pdf/cardiology/AERACardio_Client-Brochure_DCM-in-Dogs.pdf)
  - Owner of the Doberman in the study was giving her dog echocardiograms before coming into the study
  - Doberman happened to be randomized into the higher rapamycin group
  - Doberman had one of the best responses in cardiac function
  - Doberman went from borderline occult dilated cardiomyopathy to ~10% improvement in EF, which is well into the normal range
- Other larger-mammal studies using rapamycin?
  - Marmosets
  - Cancer studies in dogs rapamycin osteosarcoma in dogs
- Is autophagy (and rapamycin) a double-edged sword in cancer? What are we actually measuring when we’re measuring autophagy?
  - We don’t really know how to measure it
  - We don’t know what we mean when we say autophagy is increased or decreased
  - Matt’s view is that one of the ways in which an animal deals with stress is to turn up autophagy
  - Autophagy can be a response to a pathological condition
  - That response may not lead to productive autophagy
  - There may be a failure to bring the process to completion
  - Depending on how you activate autophagy, it could be detrimental or beneficial
  - Rapamycin seems to alleviate a block and get productive autophagy working again
  - Some evidence when looking at mitochondrial diseases in the brain, they see massive autophagosomes that are trying to digest mitochondria but can’t do it while the disease is progressing—somehow rapamycin fixes this

## Rapamycin in cancer treatment [50:00]

- Immune surveillance is one of the most important anti-cancer mechanisms, Matt says
  - And we know that immune function goes down with age
  - If you can boost age-related immune function with rapamycin, enhance immune surveillance, that’s going to have a potent anti-cancer mechanism
  - This might be why we’re seeing—in the studies in mice—that cancers are pushed back during aging by rapamycin
  - But if the rapamycin dose is too high, and it’s inhibiting immune function, it might be detrimental
- Matt’s [study on mice giving them the ‘party-dose’ (8 ml/kg/day injections) of rapamycin](https://www.ncbi.nlm.nih.gov/pubmed/27549339)
  - Completely different effects between male mice and female mice in this study
  - Male mice lived 60% longer after the end of treatment, better muscle function, less cancer
  - Female mice had no difference in lifespan, but they died with very different types of cancers (all had aggressive hematopoietic cancers whereas 30-40% in the vehicle-treated [not uncommon for these mice to get this cancer])
- Is there an opportunity for rapamycin with immune-based therapies?
- What best explains the increase in cancer incidence with age?
- Why Matt thinks that rapamycin does more than just reducing the rate of deterioration and decline in aging

## Why isn’t there a rapamycin trial for Alzheimer’s disease (AD)? [1:01:30]

- People should recognize AD as a disease of aging, Matt says
  - Rapamycin could not only halt progression, it’s possible the compound could make things better, Matt says
- Are rapamycin and caloric restriction (CR) working through the same mechanism?
  - From a metabolic perspective, it’s unclear whether rapamycin and CR are working through the same mechanism
  - One of the main things that CR does is inhibits mTOR, and we know that rapamycin inhibits mTOR
  - The mechanisms are likely overlapping, but distinct, Matt says
  - Not everything CR does, rapamycin does, and vice-versa
  - When you look at the gene expression profile, or the metabolic profile, they don’t look all that similar (at least at the low-doses of rapamycin), Matt says
  - Rapamycin might increase lifespan across a broader genetic background than CR
- If we want to find predictive signatures to show that an anti-aging intervention is working, where should we be looking?
  - The metabolome is one place to look for a serum signature, but is this reasonable to look at in a person vs a mice or a dog?
- Matt’s preliminary data in his [phase I study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5411365/) on the dog microbiome (MB) and rapamycin
  - Seeing changes in the MB with rapamycin
  - Looks as though, at least in dogs with dysbiosis, they were better by the end of the study
  - Too early to know whether dogs are going to look like what the literature has shown in mice
  - Matt suspects rapamycin will have an impact on the MB
  - Some of the changes in the MB could be causal for some of the effects of rapamycin, Matt thinks
  - Segmented filamentous bacteria (SFB) in the rapamycin-treated mice
  - There are links between SFB and type 2 diabetes, and obesity
  - Also links between SFB and T helper cell maturation
  - Could be the changes on this SFB are having effects on nutrient utilization and uptake, and immune function
- Duodenal ablation to ameliorate diabetes?
- Does loss of intestinal barrier function drive, or at least contribute to, [inflammaging](https://www.ncbi.nlm.nih.gov/pubmed/24833586): the increase of inflammation with aging?
- Metformin anti-aging study: The TAME trial

## If Matt could do a definitive study on life extension in dogs, with resources not being a concern, what does that experiment look like? [1:16:00]

- What does Matt’s 5-year study in dogs with rapamycin look like?
- “[The Dog Aging Project’s long-term goal](https://magazine.washington.edu/feature/uw-puzzle-of-aging/) is to obtain funding for a five-year study to really answer the questions: does rapamycin extend or improve lifespan in dogs like it has in mice, and if so, by how much?”
- Why is there a stigma associated with the field of aging research?
- Why has it been a struggle to get the metformin study funded?
- Could self-experimentation, in a rigorous way, push the needle?
- Why is it hard to get funded for rapamycin studies?

§

§

## Selected Links / Related Material

- **David Sabatini episode on mTOR and rapamycin**: [David Sabatini, M.D., Ph.D.: rapamycin and the discovery of mTOR — the nexus of aging and longevity? (EP.09)](https://peterattiamd.com/davidsabatini/) | The Peter Attia Drive ([peterattiamd.com](https://peterattiamd.com/)) [1:55]
- **Overexpressing SIR2 extends lifespan in yeast:** [The SIR2/3/4 complex and SIR2 alone promote longevity in Saccharomyces cerevisiae by two different mechanisms](https://www.ncbi.nlm.nih.gov/pubmed/10521401) (Kaeberlein et al., 1999) [5:40]
- **Overexpressing SIR2 extends lifespan in worms**: [Increased dosage of a sir-2 gene extends lifespan in Caenorhabditis elegans](https://www.ncbi.nlm.nih.gov/pubmed/11242085) (Tissenbaum and Guarente, 2001) [5:50]
- **Working with dogs and aging**: [Dog Aging Project](https://dogagingproject.com/) ([dogagingproject.com](https://dogagingproject.com/)) [6:30]
- **Rapamycin and improved immune function**: [mTOR inhibition improves immune function in the elderly](https://stm.sciencemag.org/content/6/268/268ra179) (Mannick et al., 2014) [15:00, 22:30]
- **Matt’s pilot study with dogs and rapamycin**: [A randomized controlled trial to establish effects of short-term rapamycin treatment in 24 middle-aged companion dogs](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5411365/) (Urfer et al., 2017) [2:51, 27:30]
- **Studies showing improved heart function of older mice taking rapamycin**: [Altered proteome turnover and remodeling by short-term caloric restriction or rapamycin rejuvenate the aging heart](https://www.ncbi.nlm.nih.gov/pubmed/24612461) (Dai et al., 2014) [29:00]
- **Studies showing improved heart function of older mice taking rapamycin**: [Late-life rapamycin treatment reverses age-related heart dysfunction](https://www.ncbi.nlm.nih.gov/pubmed/23734717) (Flynn et al., 2013) [29:00]
- **Studies showing improved heart function of older mice taking rapamycin**: [Rapamycin extends murine lifespan but has limited effects on aging](https://www.ncbi.nlm.nih.gov/pubmed/23863708) (Neff et al., 2013) [29:00]
- **Doberman’s have a high occurrence of dilated cardiomyopathy**: [Prevalence of Dilated Cardiomyopathy in Doberman Pinschers in Various Age Groups](https://onlinelibrary.wiley.com/doi/pdf/10.1111/j.1939-1676.2010.0479.x) (Wess et al., 2009) [42:00]
- **Data on dogs and rapamycin at the University of Tennessee**: [Pharmacokinetics of orally administered low-dose rapamycin in healthy dogs: A pilot study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5642271/) (Larson et al., 2017) [45:15]
- **Rapamycin study in marmosets**: [Metabolic consequences of long-term rapamycin exposure on common marmoset monkeys (Callithrix jacchus)](https://www.ncbi.nlm.nih.gov/pubmed/26568298) (Ross et al., 2015) [45:50]
- **Cancer study in dogs**: [Rapamycin Pharmacokinetic and Pharmacodynamic Relationships in Osteosarcoma: A Comparative Oncology Study in Dogs](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2882366/) (Paoloni et al., 2010) [46:30]
- **Current open trials of cancer studies in dogs**: [COTC021 and COTC022: Evaluation of Orally Administered mTOR inhibitor Rapamycin in Dogs in the Adjuvant Setting with Osteosarcoma Compared to Standard of Care](https://ccrod.cancer.gov/confluence/display/CCRCOPWeb/Current+Open+Trials) [46:30]
- **The ‘party-dose’ of rapamycin**: [Transient rapamycin treatment can increase lifespan and healthspan in middle-aged mice](https://www.ncbi.nlm.nih.gov/pubmed/27549339) (Bitto et al., 2016) [51:45]
- **The 2009 study where there was a greater survival benefit for females than males; Increased mean and maximal lifespan in both males and females when (rapamycin) initiated at 20 months of age**: [Rapamycin fed late in life extends lifespan in genetically heterogeneous mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) (Harrison et al., 2009) [53:00]
- **Podcast discussing mTOR/rapamycin with Tim Ferriss, David Sabatini, Peter, and Nav Chande**l: [The Tim Ferriss Show: My Life Extension Pilgrimage to Easter Island](https://tim.blog/2018/06/05/the-tim-ferriss-show-transcripts-peter-attia-david-sabatini-and-navdeep-chandel/) | Tim Ferriss ([tim.blog](https://tim.blog/)) [56:45]
- **Cognitive function in mice**: [Chronic inhibition of mammalian target of rapamycin by rapamycin modulates cognitive and non-cognitive components of behavior throughout lifespan in mice](https://www.ncbi.nlm.nih.gov/pubmed/22750207) (Halloran et al., 2012) [59:56]
- **Cognitive function in mice**: [Lifelong rapamycin administration ameliorates age-dependent cognitive deficits by reducing IL-1β and enhancing NMDA signaling](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3306461/) (Majumder et al., 2012) [59:56]
- **Increased mean and maximal lifespan in both males and females when (rapamycin) initiated at 20 months of age**: [Rapamycin, But Not Resveratrol or Simvastatin, Extends Life Span of Genetically Heterogeneous Mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3021372/) (Miller et al., 2011)
- **When approximately equal blood levels of rapamycin were achieved, lifespan response was also about equivalent in females and males**: [Rapamycin-mediated lifespan increase in mice is dose and sex dependent and metabolically distinct from dietary restriction](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4032600/) (Miller et al., 2014)
- **Hallmarks of aging**: [The Hallmarks of Aging](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3836174/) (López-Otín et al., 2013) [1:05:00]
- **Duodenal mucosal ablation for treatment of type 2 diabetes**: [Endoscopic Duodenal Mucosal Resurfacing for the Treatment of Type 2 Diabetes: 6-Month Interim Analysis From the First-in-Human Proof-of-Concept Study](https://www.ncbi.nlm.nih.gov/pubmed/27519448) (Rajagopalan et al., 2016) [1:12:40]
- **Inflammaging**: [Chronic inflammation (inflammaging) and its potential contribution to age-associated diseases](https://www.ncbi.nlm.nih.gov/pubmed/24833586) (Franceschi and Campisi, 2014) [1:14:00]
- **Metformin as an anti-aging drug and the targeting aging with metformin (TAME) trial**: [Metformin as a Tool to Target Aging](https://www.ncbi.nlm.nih.gov/pubmed/27304507) (Barzilai et al., 2016) [1:15:00, 1:27:10]
- **Metformin pilot study proposal**: [Metformin in Longevity Study (MILES)](https://clinicaltrials.gov/ct2/show/NCT02432287) (Crandall) ([clinicaltrials.gov](https://clinicaltrials.gov/)) [1:15:00, 1:27:10]
- **Story including the dog aging project and long-term goal of five-year study**: [The puzzle of aging: UW experts are piecing together new ways to live longer and better](https://magazine.washington.edu/feature/uw-puzzle-of-aging/) | The University of Washington Alumni Magazine ([magazine.washington.edu](https://magazine.washington.edu/)) [1:17:00]
- **Subhed quote**: [Dr. Matt Kaeberlein – The Dog Aging Project | Life Extension Advocacy Foundation](https://www.leafscience.org/dr-matt-kaeberlein-the-dog-aging-project/) ([leafscience.org](https://www.leafscience.org/))

§

§

## People Mentioned

- [David Sabatini](https://twitter.com/DMSabatini) (studies mTOR and rapamycin) [0:50, 56:45]
- [Len Guarente](https://en.wikipedia.org/wiki/Leonard_P._Guarente) (Matt studied under him at MIT) [0:50, 4:30]
- [Heidi Tissenbaum](https://www.umassmed.edu/tissenbaum-lab/members/) (colleague while at MIT who studied sirtuins in *C. elegans*) [5:50]
- [Stan Fields](https://www.gs.washington.edu/faculty/fields.htm) (University of Washington) [5:00]
- [Daniel Promislow](https://www.pathology.washington.edu/faculty/promislow) (Dog Aging Project) [6:40]
- [Joan Mannick](https://www.restorbio.com/our-team/joan-mannick/) (lead author on rapamycin paper showing immune benefits in elderly) [15:00]
- [Felipe Sierra](https://www.nia.nih.gov/about/staff/sierra-luis) (Director of the Division of Aging Biology at the National Institute on Aging, NIH) [34:00]
- [Nav Chandel](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=11123) (trip with Peter to Easter Island) [56:45]
- [Tim Ferriss](https://twitter.com/tferriss?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (trip with Peter to Easter Island) [56:45]
- [Richard Isaacson](https://weillcornell.org/risaacson) (runs the Alzheimer’s Prevention Clinic at Weill Cornell) [1:01:20]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/08/2015-kaeberlein-matt-web-profile-220x300.jpg)

##### Matt Kaeberlein, Ph.D.

Matt Kaeberlein, Ph.D., is recognized globally for his research on the basic biology of aging. The premise of his research is that understanding the molecular mechanisms of aging will lead to interventions that slow the onset and progression of age-related chronic conditions, such as cancer, diabetes, kidney disease, heart disease, Alzheimer’s and others. Dr. Kaeberlein received his Ph.D. from the Massachusetts Institute of Technology in 2002 and performed his post-doctoral research in the Department of Genome Sciences at the University of Washington. Dr. Kaeberlein was appointed as an Assistant Professor of Pathology in 2006 and was promoted to Associate Professor in 2011.

Dr. Kaeberlein has authored more than 140 publications in top scientific journals, including 19 published in Nature and Science, his work has also been featured in the popular press. Dr. Kaeberlein has been recognized with several awards, including a Breakthroughs in Gerontology Award from the Glenn Foundation, an Alzheimer’s Association Young Investigator Award, an Ellison Medical Foundation New Scholar in Aging Award, an Undergraduate Research Mentor of the Year Award, and a Murdock Trust Award. In 2011, he was named the Vincent Cristofalo Rising Star in Aging Research by the American Federation for Aging Research and appointed as a Fellow of the Gerontological Society of America, and in 2012 he joined the Board of Directors of the American Aging Association. Dr. Kaeberlein currently serves on the editorial boards for Science, Aging Cell, Cell Cycle, PloS One, Frontiers in Genetics of Aging, BMC Longevity and Healthspan, F1000 Research, Ageing Research Reviews, and BioEsssays.

In addition to his primary appointment, Dr. Kaeberlein is the Director of the Dog Aging Project, co-Director of the University of Washington Nathan Shock Center of Excellence in the Basic Biology of Aging, the founding Director of the Healthy Aging and Longevity Research Institute, and the current President of the American Aging Association. [[kaeberleinlab.org](https://kaeberleinlab.org/people/matt-kaeberlein)]

Matt on Facebook: [Matt Kaeberlein](https://www.facebook.com/matt.kaeberlein)

Matt on Instagram: [@mkaeberlein](https://www.instagram.com/mkaeberlein/?hl=en)

Matt on Twitter: [@mkaeberlein](https://twitter.com/mkaeberlein?lang=en)