# #17 – Mike Trevino: life-lessons from ultra-endurance, mindset, hard work, and removing limitations

**Source:** [https://peterattiamd.com/miketrevino/](https://peterattiamd.com/miketrevino/)

---

In this episode, ultra-endurance athlete and entrepreneur, Mike Trevino, discusses the lessons he’s learned from his remarkable athletic feats, and the training required to reach them. Not only is Mike’s advice practical for those looking to take their endurance training to the next level, but his lessons and insight are extraordinarily applicable to living everyday life.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/miketrevino/the_Drive_public.png)

Play

#17 - Mike Trevino: life-lessons from ultra-endurance, mindset, hard work, and removing limitations

#17 - Mike Trevino: life-lessons from ultra-endurance, mindset, hard work, and removing limitations

1x15s30s

0:001:56:06

## We discuss:

- Mike’s background, his crazy birthday tradition, and his transition from power to endurance [6:30];
- Mike’s breakthrough year: setting a course record, and completing the Badwater 135 [16:00];
- Race Across America (RAAM), perseverance, and extreme sleep deprivation [25:30];
- Mindset, nutrition, fasting, and other advice from Mike for those looking to take the next step in their training [49:00];
- What getting a parasite taught Mike about fasting [59:45];
- The risks involved with cycling [1:03:00];
- Mike setting the Trans-Iowa (RAGBRAI) record [1:10:15];
- PEDs, stimulants, and their effect on performance [1:15:00];
- What motivates Mike (and others) to do this extreme stuff? What led him to eventually pull back? [1:22:00];
- Life-lessons learned from training, and how to impart them to his kids, and others [1:35:30];
- The greatest beer in the world remains a mystery [1:46:15]; and
- More.

§

## Show Notes

## Mike’s background, his crazy birthday tradition, and his transition from power to endurance [6:30]

**Each birthday, Mike “runs his age” in miles**

- He is currently 43, started the tradition at 40
- Bed at 10, up at 4 am, started run at 5 am
- Averaged 8-minute mile
- Nutritional strategy during runs include zero calories, some Crystal Light packets, and $20 for emergency banana, if necessary
- Dinner the night before ended at 5 pm with a beer
- To do this on zero calories, Mike is extremely fat-adapted, he’s likely spending 600-700 kilojoules per hour and if not fat-adapted you’d be done after 2-3 hours relying on glucose alone

**In 2013, Mike ran 50 miles just to try Peter’s famous shake, “The Peter Kaufman”**

- Mike was training for a 275 mile run from Gaviota State Beach to San Diego to raise money for the [Navy Seal Foundation](https://www.navysealfoundation.org/)
- See the recipe for The Peter Kaufman which uses [Generation UCAN](https://www.generationucan.com/) in this previous post, “[What I actually eat, part III (circa Q1 2014)](https://peterattiamd.com/actually-eat-part-iii-circa-q1-2014/)”
- More about Generation UCAN in [this presentation by Peter](https://vimeo.com/51891286)

**Where did you grow up? What did you do athletically?**

- Iowa, played football player and wrestler
- Started riding a bike at 4 years old, started doing 50-100 mile rides by age 10-12
- Completed [RAGBRAI](https://ragbrai.com/) ride across Iowa in 1987 at age 12, 400 miles
- Dream was to play football at Notre Dame
- He was an O-lineman in HS, played inside linebacker in college (not at Notre Dame)

**How did you transition from power athlete to endurance athlete?**

- Wasn’t planned
- Decided to quit football, played some rugby, and finished school early
- First job was at a startup in Heidelberg, Germany
- Got invited to play on a semi-pro Rugby team, their practices were runs through the mountains, he fell in love with trail running
- He lost a bunch of weight, 218 lbs at peak, now he is about 170, races at 155-160 (Peter says Mike still looks like a “beast” at a lower weight, he remembers a picture of Mike at the 2014 [RAAM](https://www.raceacrossamerica.org/))
- You become “purpose-built,” says Mike
- “Your body is just a utility to achieve an outcome, so how do you achieve the outcome you want?”
- He eventually started doing marathons, ultra runs (2001-2003), and then transitioned to focus on cycling to prepare for the Race Across America (RAAM)
- When he dropped running and focused on cycling, “my body just changed”

## Mike’s breakthrough year: setting a course record, and completing the Badwater 135 [16:00]

- In 2000 he ran his first 50-mile race (before that was just marathons), it was the [PCT50](https://www.pct50.com/) on the Pacific Coach Trail
- 6 weeks later he did 100 miles at the [Angeles Crest 100](https://www.ac100.com/): starts in Wrightwood and ends in at Rose Bowl in Pasadena
- In 2001 did several 50s, the Boston Marathon, on 9/11/01 was going to Colorado to set a record of 14ers (to set a record), but postponed for a week and then did track run (San Diego One Day) in Nov of 2001
- Set a course record at the San Diego One Day, swore he would never run on a track again, hardest ever, so monotonous, ¼ mile track
- He says that run was at the end of his first “big year”

**What is the [Badwater 135](https://www.badwater.com/event/badwater-135/) race?**

- Running race that starts in Death Valley, CA (125 degrees at peak, the surface is hot)
- 135 miles through all kinds of ecosystems: desert, mountain town, ends with half marathon climbing to up to [Whitney Portal](https://en.wikipedia.org/wiki/Whitney_Portal,_California)
- He started the race at 10 am and finished “the next day” around noon or 1 pm
- Side note: had planned to mountain climb Mount Whitney after the race but, after the race took much longer, and was much more grueling than expected, told climbing partner “you don’t want me on the other side of the rope”

**Related agonizing story from Peter**

- In 2005 was training in Lake Tahoe, for a longer swim later that summer
- Picked a bad boat captain (some random local), clearly drunk
- The driver didn’t realize he was supposed to set the direction and he “followed” Peter
- Took 2.5 hours longer than expected, ran out of food, etc. “hardest swim of my life, mentally”
- Planned to meet his brother to ride 80 miles around the lake, but could barely walk after the swim

**Mike says, the training is what prepares you, it can be mentally demoralizing, it humbles you: the best stories come from training**

- Mike once rode 250 miles through the desert, and the heat melted his seat beam, and had to find a repair shop along the way to fix it
- One time climbing Mount Whitney, he got stuck in snow and ice, and an 8-hour climb turned into 22 hours
- “But those are the most memorable stories . . . provided you get out alive”

## Race Across America (RAAM), perseverance, and extreme sleep deprivation [25:30]

**[RAAM](https://en.wikipedia.org/wiki/Race_Across_America), the single most challenging cycling event, is a 3,000 mile transcontinental, non-stop cycling race from east to west coast**

- “Whistle blows and the first person to the east coast wins”
- Peter has a hard time fathoming that people can do it
- Comparable distance to Tour de France, but winner typically finish in 8 days, whereas Tour de France lasts 22 days
- Started in the early 80s
- Mike’s first exposure was watching Bob Breedlove compete
- Not just the rider, but logistics, your crew of people, race rules, multifaceted, must engineer the race well, food, bike equipment, several cars following, part of the fun
- Very hard on the crews who sometimes blow up and “world class riders drop out before Arizona”
- Peter was the crew chief for Forrest Nelson, the guy soloed around the Catalina, a 50-mile swim
- Longest time as a crew chief is 36-48 hours, so he can’t even imagine 8-9 days

**How the RAAM went down**

- Mike said he “broke his crew” in the first 45 hours
- After riding 800 miles for 28 hours straight on the bike, he was supposed to stop and sleep
- But tail winds came, and he wanted to take advantage, so he jumped right back on the bike immediately, on no sleep
- Rode for 44 hours before finally getting first rest
- This ended up being a great strategic move because they “gapped the field” who got stuck in a storm (hence the strong winds)
- Halfway through the race, he was neck and neck for first place with [Jure Robič](https://en.wikipedia.org/wiki/Jure_Robi%C4%8D), a seasoned veteran who was supposed to win the race by 2 days
- Mike was accused of cheating by Jure Robič’s team, mainly because they simply couldn’t believe a “rookie” was keeping with Robič
- Mike almost quit the race, after 2,000 miles he was 4-5 hours behind Robič, he was furious about the cheating allegations, and he was feeling demoralized
- So what did he do? He went for a run (yes, really, he did)
- “Running for me has always been my meditation . . . I get centered”
- He decided to finish the race and took 2nd place

**Sleep deprivation**

- The normal daily strategy that people take is on the bike for 20-22 hours, and sleep for 2-4 hours
- But Mike only slept around 10.5 hours over the 8 days
- At one point Robič told Mike, “you’re going to win, you don’t need sleep” after seeing how little rest Mike was taking
- At one point, the lack of sleep starting causing hallucinations and he even thought, why is there a van following me? (It was his crew) And he tried to “lose them” — more about this story at 1:23:00
- But Mike has since realized the importance of sleep
- “Sleep, I found, is more important than food and hydration when it comes to thermoregulation, muscle glycogen restoration, synapse repair and formation . . . I was clinically insane by the end of the race”
- There’s a [story in the *New York Times*](https://www.nytimes.com/2011/06/28/sports/cycling/in-cycling-race-across-america-sleep-is-shunned.html) about sleep deprivation and the RAAM

**Mike gets advice from [Pete Penseyres](https://en.wikipedia.org/wiki/Pete_Penseyres), a guy who held the RAAM record 27 years, 15.4 mph average speed for 8.5 days (includes off the bike time), probably more like 20 mph on the bike**

- He said that 2 things that will determine if you can win RAAM:

1. What is your speed after you’ve depleted muscle glycogen and you’re just cruising: your “all-day” speed
2. What’s your REM sleep cycle? So he would have someone watch his eye patterns while he slept and then wake him up immediately following his REM cycle: if you are woken up during REM you will feel sleepy — if your REM cycles were only 90 minutes, as opposed to say 2.5 hours, you could win RAAM

- This is like sleep engineering
- Pete Penseyres also advised him to “stay liquid” to let your body do little digestion

## Mindset, nutrition, fasting, and other advice from Mike for those looking to take the next step in their training [49:00]

**Mindset is first**

- We all have natural ability, all of us are born as athletes
- Know that you have in you, somewhere, the ability to do great things
- Change your mindset, change your perspective on what you think you can do, you have the innate ability to do amazing things, it’s just that most people haven’t figured out how to tap into that

**Check your assumptions at the door**

- Be open to all possibilities and realize that not everything you’ve been told is right
- Mike was told that you shouldn’t do more than 2 marathons a year and at one point he was doing a marathon per day
- He trained himself for desert runs by sitting in a sauna all day, chugging water, taking salts for electrolytes

**Know when to push, and when to pull back**

- Mike learned to use objective measures to judge himself: time, heart rate, power (on the bike)
- If he wasn’t performing well, didn’t feel right, he would dial it back
- If his heart rate wasn’t looking right, he wouldn’t train
- Don’t try to make up for “missed runs” or training time, you’ll overdo it

**Nutrition**

- If you are an ultra distance athlete you HAVE to be fat adapted
- Don’t want to be doing this with an [respiratory quotient](https://en.wikipedia.org/wiki/Respiratory_quotient) above .75 to .8
- Despite the common practice of carb-loading for long endurance events, Mike never felt good after carb loading: bloated, HR not good the next day
- Experimented with fat for energy, like coconut oil
- Peter says to Mike “you were ahead [of the curve] with fat”
- Started to notice that he could actually feel and perform better when fasted
- Started to phase things out: carbs, alcohol
- After reading a great book, [Climbing Light, Fast, and High](https://www.amazon.com/Extreme-Alpinism-Climbing-Light-High/dp/0898866545/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=), he learned that taking a shot of olive oil in altitude is better than carbs
- Applied it to his training, oil is more energy dense
- “Sugar is like a drug, if you have Twix at mile 20, you’ll want another at mile 25”
- Peter adds, “You’re hosed: you have now committed to a pure glycolytic strategy, and you better have it timed perfectly to the finish line”

## What getting a parasite taught Mike about fasting [59:45]

- In 2002, spent some time in Tibet, the Himalayas, he was on [Everest](https://en.wikipedia.org/wiki/Mount_Everest) for a couple months and they were eating Yak meat, which you can’t cook in altitude, so when he came back in 2003, he had parasites
- Doctor gave him meds, but also told Mike that historically our ancestors would fast to deal with parasites
- Mike did a 10-day fast, combined with the meditation, only drank warm water
- Day 1 and 2 was brutal, by day 3 it was “like 170-degree vision . . . I could see around myself . . . I could feel stuff . . . I could smell stuff” (in ketosis)
- Not only did it fix his parasite problem, he was also developing exercise-induced asthma, became allergic to certain foods, and all this went away in 2003, by fasting
- By day 7 he started training again because he felt good
- He then realized if he used oil and fasting, he could perform even better by just “throwing everything else out the window”
- Peter says there’s little downside to try fasting, coupled with medical therapy, for parasites
- Peter also says there’s certainly evidence to suggest that fasting coupled with chemo helps chemo work better, demonstrated by [Valter Longo](https://en.wikipedia.org/wiki/Valter_Longo) and [Dom D’Agostino](https://twitter.com/DominicDAgosti2?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (*note: Longo’s done more work with fasting and response to chemotherapy; D’Agostino’s focus is more on a ketogenic diet in combination with hyperbaric oxygen therapy*)

## The risks involved with cycling [1:03:00]

- Just like mountain climbers attempting Everest and K2 have a risk of death (approx. 1 in 8, and 1 in 3, respectively), cycling too, comes with serious risk
- Both Bob Breedlove and Jure Robič died in cycling accidents
- Mike doesn’t ride as much now that he has family
- Peter’s wake up call was in 2010 when a friend of his, Nick Venuto, won the Mount Palomar time trial a couple times, was killed in a freak accident when a car hit him from behind
- Peter had almost taken that same route that day, but decided by simple chance to go another way
- Mike was hit by a car once, most mentally scary, 2006, maybe 2007
- Went over the hood, hit his head, and couldn’t move one side of his body, really shook him up
- He had a hard time getting back on the bike so he bought a [CompuTrainer](https://www.racermateinc.com/computrainer/)

## Mike setting the Trans-Iowa (RAGBRAI) record [1:10:15]

- The trek is known as [RAGBRAI](https://en.wikipedia.org/wiki/RAGBRAI)
- Peter says it’s “the most ridiculous feat in the history of cycling”
- A bucket list thing for Mike growing up in Iowa
- Wanted to set speed record across Iowa in 2005
- To set a record you need a [UMCA](https://www.ultracycling.com/) an official present
- Depending on the route, 270+ miles, more climbing than you think
- Went east to west across Iowa
- Never had to unclip
- Finished in 10 hours 40 minutes
- 25.7 mph average
- Felt fantastic at the end, thought about continuing to cross the next state
- Looked at his Polar HR monitor when he finished, couldn’t believe the numbers: 10.5 hours and “it was fun”
- He didn’t have a power meter, but Peter estimates Mike was doing 310-320 watts on avg.
- Peter says this in line with the professionals, estimating Mike’s FTP ([Functional Threshold Power](https://roadcyclinguk.com/how-to/fitness-nutrition/three-training-sessions-to-improve-your-functional-threshold-power-ftp/)) to be 380-400
- Pros look at the metric of watts per kilo
- Best guys in the era of EPO ([blood doping](https://en.wikipedia.org/wiki/Blood_doping)) are doing 6.3-6.4 watts per kilo: “if you can do 5 without drugs that’s incredible”

## PEDs, stimulants, and their effect on performance [1:15:00]

- For Mike, endurance competitions were a sacred endeavor, he was never interested in using performance-enhancing drugs (PEDs)
- Peter mentions that [Modafinil](https://en.wikipedia.org/wiki/Modafinil), a non-stimulant drug for narcolepsy, seems like it could add an advantage for these multiple day rides
- It’s a non-stimulant that keeps you awake
- Peter says it was common in med school residency to use Modafinil to stay awake
- Peter uses it sometimes it for jet lag
- In an Air Force [study](https://www.ncbi.nlm.nih.gov/pubmed/15460629), they put pilots into a simulator and measured performance over 24 hours
- Placebo group predictably declined over time
- Caffeine group did better for longer but crashed at some point
- Modafinil group at a 200 mg standard dose had performance maintained for a long time but fell off at about 24 hours

**Mike says he prefers natural performance because, otherwise, where do you stop?**

- You’re no longer “answering the question” that you set out to answer about yourself when you’re doping
- Mike doesn’t even use any IV liquids
- EPO, for pro cycling, is better than any kind of steroids
- Stimulants can add an advantage, but you better know when to use them, and for how long, because you can fall off a cliff pretty quickly

**Mike says he’s been a part of a few studies involving Navy Seals, at the Navy hospital, Liberty Station, Point Loma**

- Studies were testing different things, SEALs on a whole cocktail
- Peter says Modafinil is much better than stimulants and would be good in this scenario where SEALs needed to stay alert
- Mike says stimulants create a horrible cycle of up and down, and have a negative psychological effect that can throw off your judgment
- Peter says he’s never tried a stimulant like [Adderall](https://en.wikipedia.org/wiki/Adderall) before, even though some people swear by a low dose (10 mg) for mental clarity, “they wouldn’t sit well with my system,” but for the right person it could be remarkable, but the question becomes frequency: at what point does it become too much?

## What motivates Mike (and others) to do this extreme stuff? What led him to eventually pull back? [1:22:00]

- For Mike, it really all started because he was “running away from stuff”
- In 1997, he was living on a friends couch, drinking beer every night after work, he was dealing with a bad break up, and he just decided he had to get out of there
- In 1998, he started to train for the NYC marathon
- But then it evolved, Chicago marathon, NYC marathon dressed as Batman
- Then realized that he might have an ability to pull off some decent times
- Moved to San Diego in 1999 to get serious and focus on it

**People always ask, *what do you think about when you’re out there for so long? Do you get bored?***

- “No, it’s very meditative for me”
- A time to think and work through stuff past and present
- Mike describes long distance running as his happy place, the only time he feels normal
- Peter asks, what felt *abnormal* when you weren’t running?
- The biggest thing, he just never was that social person, liked to build stuff, challenge himself, didn’t fit into the NY scene, preferred to just push himself

**People ask, *is it worth the sacrifice?***

- Mike calls it a privilege, “if it was a sacrifice, I wouldn’t do it”
- “I don’t choose a path of accepting that I have certain limitations and certain things aren’t possible, I think that’s bullshit”
- Most of the time, they’re wrong
- Mike says he was “really good at saying no” back then, “If it wasn’t on the critical path, I wouldn’t do it”
- For months at a time, he would cut off communication with family so he could focus

**Peter asks, *what lead to the transition from that to your priorities now?***

- The new priority order is family, company, then training
- Mike got married and found that during long training sessions he was asking himself, “What am I doing out here?”
- “I asked myself that question and I knew I was done”
- “I had answered most of the big questions”
- Peter says, [kind of like Forrest Gump](https://www.youtube.com/watch?v=pKKmzmeU5-0)

## Life-lessons learned from training, and how to impart them to his kids, and others [1:35:30]

- Tough question because “I only learned what I learned because I figured it out on my own . . . and so I want to expose them to stuff and let them take to what they take too”
- He has twins that are 8, and his son is 3
- Try to coach them to simply have fun
- “Nutrition and lifestyle is mostly what I try to impart, you don’t need to carb-load”

**Adversity and hard work**

- Want them to see that hard work comes in many forms, physical and mental
- Perseverance: lead by example, everything now gets outsourced
- At his software company, Mike says “I take out the garbage and I run the company, I’ll never stop”
- Nothing is beneath me
- Never give up, it’s that simple
- The person that keeps moving, even if you don’t win, you will finish the race

**Train smart**

- Be intelligent about when to push and when to back down
- Peter posits that Mike’s “greatest asset” outside mental toughness, is his intelligence in understanding which days are days to push and which are days to back down
- “The best approach is a cross-functional world-class expert team” . . . you think outside the box and bring in other ideas from other domains

**Translating this into general rules**

- Don’t limit yourself to thinking about just the marathon (or whatever you’re attempting to do), look at yourself, be objective, and think about what it’s going to take to achieve what you define as success
- Don’t be afraid to ask questions
- Don’t overthink it (data is good, but unless breaking a world record, just go out and have fun)

## The greatest beer in the world remains a mystery [1:46:15]

- This beer is “From another planet . . . a different animal”
- But don’t get excited, Peter and Mike will never reveal the name of it because they fear it will become less available
- As the story goes, Mike introduced Peter to the beer and he immediately bought out the entire US supply (260 bottles, thanks to the sleuthing by Nick Stenson)
- It is from a small brewery in Belgium, and they do very low volume

**The listeners’ consolation prize**

- 2nd best beer in the world: [Judgement Day, Lost Abbey Brewery](https://lostabbey.com/beer/judgment-day/) in San Marcos, CA
- Belgian Quad
- Unfortunately, Peter has been told that it is not profitable enough for it to be carried at [BevMo](https://www.bevmo.com/) anymore

§

§

## Selected Links / Related Material

- **Slow-releasing carbohydrate supplement for endurance training**: [Generation UCAN](https://www.generationucan.com/) | (generationucan.com) [10:00]
- **Peter’s shake recipe, “The Peter Kaufman”**: [What I actually eat, part III (circa Q1 2014)](https://peterattiamd.com/actually-eat-part-iii-circa-q1-2014/) | Peter Attia (peterattiamd.com) [10:10]
- **Peter’s presentation on the UCAN product**: [UCAN Presentation](https://vimeo.com/51891286) | Peter Attia (vimeo.com) [10:15]
- **Mike ran a race for this Navy SEAL charity**: [Navy Seal Foundation](https://www.navysealfoundation.org/) [11:30]
- **400-mile bike race across Iowa Mike completed at age 12 and then set the speed record in 2005**: [RAGBRAI](https://ragbrai.com/) [12:30, 1:10:15]
- **Mike completed a bike race across the entire United States**: [Race Across America](https://www.raceacrossamerica.org/) [15:00, 25:00]
- **Mike set a track record at this 24-hour race**: [San Diego One Day ultramarathon discontinued](https://legacy.sandiegouniontribune.com/news/health/fitness/20060721-9999-lz1s21ultrama.html) | San Diego Tribune (sandiegouniontribune.com) [16:00]
- **Mike’s first 50-mile run**: [PCT50](https://www.pct50.com/) [18:00]
- **100-mile ultramarathon Mike did in 2000**: [Angeles Crest 100](https://www.ac100.com/) [18:30]
- **Tough 135-mile ultramarathon race in 2001**: [Badwater 135](https://www.badwater.com/event/badwater-135/) [19:30]
- **Book covering the Race Across America**: [Race Across America: The Agonies and Glories of the World’s Longest and Cruelest Bicycle Race](https://www.amazon.com/Race-Across-America-Agonies-Cruelest/dp/1567960243) by Michael Shermer [34:40]
- **NYT story on sleep deprivation and the RAAM**: [In Cycling Race Across America, Sleep Is Shunned](https://www.nytimes.com/2011/06/28/sports/cycling/in-cycling-race-across-america-sleep-is-shunned.html) | Dave Seminara (nytimes.com) [34:30]
- **Salt Mike used to replenish electrolytes on long sweaty runs/rides**: [Celtic Sea Salt](https://www.amazon.com/Celtic-Sea-Salt-Resealable-Paleo-Friendly/dp/B000EITYUU?th=1) | (amazon.com) [53:00]
- **Book recommendation by Mike**: [Climbing Light, Fast, and High](https://www.amazon.com/Extreme-Alpinism-Climbing-Light-High/dp/0898866545/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=) by Mark Twight | (amazon.com) [57:30]
- **Valter Longo’s research on fasting and cancer treatment**: [Fasting and Caloric Restriction in Cancer Prevention and Treatment](https://www.ncbi.nlm.nih.gov/pubmed/27557543) (Brandhorst and Longo, 2016) [1:02:50]
- **Dom D’Agostino’s research on ketogenic diet and cancer**: [Targeting the Warburg effect for cancer treatment: Ketogenic diets for management of glioma](https://www.ncbi.nlm.nih.gov/pubmed/29294371) (Poff et al., 2018) [1:02:50]
- **Peter’s co-worker, who was killed in cycling accident**: [SR-56 bike victim was biotech executive](https://www.sandiegouniontribune.com/sdut-bicyclist-killed-was-a-poway-father-of-two-2011jun01-story.html) | Susan Shroder (sandiegouniontribune.com) [1:05:00]
- **Indoor cycle trainer used by Mike**: [CompuTrainer](https://www.racermateinc.com/computrainer/) | (racermateinc.com) [1:09:30]
- **Air Force study using modafinil**: [Modafinil’s effects on simulator performance and mood in pilots during 37 h without sleep](https://www.ncbi.nlm.nih.gov/pubmed/15460629) (Caldwell et al., 2004) [1:17:00]
- **Radiolab follows Patrick Autissier and Jure Robic, in the RAAM**: [Limits of The Body](https://www.wnycstudios.org/story/91710-limits-of-the-body/) | Radiolab (wnycstudios.org) [1:23:00]
- **Mental and physical challenges during the RAAM**: [That Which Does Not Kill Me Makes Me Stranger](https://www.nytimes.com/2006/02/05/sports/playmagazine/that-which-does-not-kill-me-makes-me-stranger.html) | Daniel Coyle (nytimes.com) [1:23:00]
- **Peter’s favorite story about Mike in Men’s Vogue**: [Ultra-Man](https://www.dropbox.com/s/rilp6b5w3lyvj14/MT%20Vogue%20Article.pdf?dl=0) | Ben Ehrenreich (Men’s Vogue, PDF) [1:29:20]
- **Ultramarathon bicycle race that Mike’s wife and father-in-law crewed for him**: [Furnace Creek 508](https://en.wikipedia.org/wiki/Furnace_Creek_508) | (wikipedia.org) [1:34:00]
- **40 mile run to in Hawaii to top of volcano crewed by his wife**: [Haleakalā](https://en.wikipedia.org/wiki/Haleakal%C4%81) | (wikipedia.org) [1:34:30]
- **The scene in Forrest Gump when he realizes he’s finished running**: [Forrest Gump – Run Scene](https://www.youtube.com/watch?v=pKKmzmeU5-0) | Tom van Geest (youtube.com) [1:35:00]
- **The best beer in the world**: [Click here to find out!](https://memegenerator.net/img/instances/55101809/ill-never-tell-muahahahaha.jpg) [1:46:15]
- **2nd best beer in the world**: [Judgement Day, Lost Abbey Brewery](https://lostabbey.com/beer/judgment-day/) | (lostabbey.com) [1:50:00]
- **Mike’s current company**: [Indigenous Software](https://indigenous.io/) [1:54:00]
- **Mike’s website**: [Team Trevino](https://www.teamtrevino.com/index) | (teamtrevino.com) [1:54:00]

§

§

## People Mentioned

- [Peter Kaufman](https://www.generationucan.com/directors_4.html) (Generation UCAN) [10:00]
- [Bob Breedlove](https://www.ultracycling.com/bob-breedlove/) (RAAM competitor admired by Mike) [26:20]
- [Forest Nelson](https://db.marathonswimmers.org/p/forrest-nelson/) (ultra swimmer Peter was a crew chief for) [29:00]
- [Jure Robič](https://en.wikipedia.org/wiki/Jure_Robi%C4%8D) (Beat Mike in the 2004 RAAM) [33:00]
- [Wolfgang Fasching](https://de.wikipedia.org/wiki/Wolfgang_Fasching) (3-time winner of RAAM) [33:40]
- Johnny Boswell (RAAM race official) [39:00]
- [Pete Penseyres](https://en.wikipedia.org/wiki/Pete_Penseyres) (held RAAM world record for 27 years) [43:00]
- [Valter Longo](https://en.wikipedia.org/wiki/Valter_Longo) (fasting) [1:02:45]
- [Dom D’Agostino](https://twitter.com/DominicDAgosti2?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (ketosis) [1:02:45]
- [Nick Venuto](https://www.legacy.com/obituaries/carmelvalleynews/obituary.aspx?n=nicholas-john-venuto&pid=151649433) (Peter’s co-worker killed in a cycling accident) [1:05:00]
- [Hal Higdon](https://en.wikipedia.org/wiki/Hal_Higdon) (former ultramarathoner, writer and coach) [1:42:45]
- [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) (cross-functional/triangulation approach) [1:43:00]
- Nick Stenson (Attia Medical analyst who tracked down the mystery beer) [1:48:00]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/09/mike-trevino-mugshot-500x500.jpg)

##### Mike Trevino

Vision, commitment, and integrity drive all of Mike’s endeavors – entrepreneurial, philanthropic, and physical.

Growing up in Fort Dodge, Iowa, Mike first excelled as an All-State/All-Academic football player and wrestler. His desire to pursue rigorous academics and athletics brought him to Cornell University, where he played football, was selected to be a Cornell Tradition Fellow for his interest in work and service, and was actively involved in advanced research on scientific reasoning and problem solving. Mike began his professional career at a startup in Heidelberg, Germany where he also earned a coveted starting spot on the Heidelberg RGH Rugby Team, the German Men’s National Champions at the time. Later, he returned to the US to work for Price Waterhouse Cooper before leaving to become an independent consultant.

In search of warm weather and endless outdoor activities, Mike relocated to San Diego and started his own company, Agilitas, Inc. Meanwhile, he was bitten by the running bug when he ran his first marathon in 1998.

One of his favorite experiences was winning the Badwater Ultramarathon, a brutal 135-mile race from the scorching heat of Death Valley to the thin air of Mount Whitney 8,600 feet above. Three months after winning Badwater, Mike shattered the record at the San Diego One Day, a 24-hour track race, running 144.3 miles in 24 hours.

Running is just one of Mike’s passions, however. An avid rock climber and mountaineer, he’s climbed peaks all over the world. In the fall of 2002, the Chinese government invited Mike and his friend Forrest to participate in a clean-up expedition on the North Face of Mt. Everest.

Mike then moved on to ultracycling, and in his first cycling competition, the Ultramarathon Cycling Association 24-Hour Race in Iowa, he finished in first place with an impressive 463 miles. This race designated him as one of a few elite cyclists qualified to race in the Race Across America (RAAM). In his first RAAM in 2004 he finished second, earning Rookie of the Year honors.

Mike has continued to challenge himself while serving others. In late 2013, he ran 275 miles non-stop down the coast of California to raise money for the Navy Seal Foundation and the Monarch School in San Diego.

Rather than retiring from endurance sports since beginning a family, Mike has found a way to incorporate them into his professional and personal endeavors. He uses the focus and discipline he’s developed as an ultra-athlete to build dynamic teams and companies. Several years ago, he founded Enduragive, a non-profit dedicated to supporting philanthropic endurance events and mentoring veterans.

Most recently, Mike and two friends finished third in the mixed division of the 81-mile Badwater Salton Sea Race. According to his teammate and former Army Ranger, “There’s no quit in him, he’s the most mentally tough person that I know. That guy amazes me.”

Mike lives in Rancho Santa Fe, California with his wife and three children. [[teamtrevino.com/bio](https://www.teamtrevino.com/bio)]