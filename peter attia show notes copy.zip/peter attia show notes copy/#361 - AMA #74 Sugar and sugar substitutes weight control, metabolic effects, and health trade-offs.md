# #361 – AMA #74: Sugar and sugar substitutes: weight control, metabolic effects, and health trade-offs

**Source:** [https://peterattiamd.com/ama74/](https://peterattiamd.com/ama74/)

---

In this “Ask Me Anything” (AMA) episode, Peter explains how to evaluate sugar and its substitutes in the context of health. Peter explores the role of sweeteners in three common use-cases – beverages, protein supplements, and sweet treats – and breaks down how our evolutionary craving for sweetness now clashes with today’s food environment. He examines whether sugar is uniquely fattening, the hormonal effects of sugar consumption, and the significance of timing in sugar intake. The episode compares natural versus refined sugars, sugar in beverages versus in solid foods, and the pros and cons of popular sweeteners including saccharin, aspartame, sucralose, allulose, and sugar alcohols like erythritol and xylitol. With a focus on weight management, glycemic impact, gut health, and long-term safety, this episode offers a comprehensive guide to navigating the sweetener landscape with clarity and nuance.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #74 show notes page](https://peterattiamd.com/ama74). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- A quick tangent on chess and parenting [A: 2:30, V: 1:00];
- Overview of key scenarios for evaluating sugar and sweeteners [A: 6:15, V: 5:15];
- Why humans are hardwired to crave sweetness [A: 13:30, V: 13:15];
- Evaluating whether sugar is uniquely fattening or more harmful than other macronutrients under isocaloric conditions [A: 15:15, V: 15:15];
- Why sugar drives appetite: low satiety, insulin response, and reward system activation [A: 18:45, V: 19:15];
- How sugar type, liquid vs. solid form, and processing level influence appetite and metabolic impact [A: 20:15, V: 21:15];
- Addressing the common belief that natural sugars are healthier than refined sugars [A: 26:00, V: 27:45];
- How the timing of sugar consumption alters the body’s metabolic response [A: 29:15, V: 31:55];
- How Peter advises patients on sugar intake, factoring in metabolic health, insulin sensitivity, and activity level [A: 34:45, V: 38:00];
- The most common sugar substitutes, their sweetness relative to sugar, and their caloric content [A: 36:30, V: 40:20];
- Evaluating the role of sugar substitutes in weight control: efficacy vs. effectiveness and limitations in study design [A: 40:15, V: 44:30];
- Assessing the real-world impact of sugar substitutes on weight, and the role of sweetness without calories [A: 44:00, V: 48:50];
- The impact of sugar substitutes on glycemic control [A: 47:30, V: 52:50];
- Are microbiome changes from artificial sweeteners substantial enough to cause obesity and diabetes? [A: 50:30, V: 56:30];
- How Peter advises patients on the use of sugar substitutes across different contexts [A: 52:30, V: 58:45];
- Allulose—a sweetener with unique satiety and glycemic benefits and potential for weight control [A: 57:15, V: 1:04:30];
- Emerging evidence that stevia, monk fruit, and sugar alcohols may provide modest metabolic benefits compared to sugar [A: 1:03:00, V: 1:10:45];
- Sugar alcohols explained [A: 1:04:15, V:1:12:20];
- Xylitol’s dental health benefits and considerations for use [A: 1:05:00, V: 1:13:20];
- Artificial sweeteners and cancer risk: evaluating evidence, the aspartame controversy, and the role of dose in toxicology [A: 1:07:15, V: 1:15:55];
- Sugar substitutes and cardiovascular disease: assessing flawed studies and the absence of direct risk evidence [A: 1:11:00, V: 1:20:15];
- Why artificial sweeteners seem to attract so many negative headlines [A: 1:12:45, V: 1:22:05];
- Balancing benefits and risks of sugar substitutes: guidance for desserts, beverages, and protein products [A: 1:14:15, V: 1:24:00]; and
- More.

---

The Peter Attia Drive

#361 – AMA #74: Sugar and sugar substitutes: weight control, metabolic effects, and health trade-offs

---

## Show Notes


---

## A quick tangent on chess and parenting [A: 2:30, V: 1:00]

**Chess anecdote – losing to his 7-year-old**

- Peter thought he was playing the best chess game of his life but made a blunder and lost in two moves to his 7-year-old son.
- His son now wins about six out of ten games, which is both enjoyable to watch and frustrating to experience.
- Nick jokes that based on Peter’s personality and his book, people might expect he wouldn’t handle losing to a child well.

**Peter’s competitiveness and sportsmanship lesson**

- Peter insists he is not externally competitive, only internally.
- Chess is the only activity where losing to another person makes him truly upset.
- He tries to model sportsmanship for his sons by shaking hands and saying “good game” after losing, however, in a recent incident he lost to his son and, out of frustration, smacked his chess king piece across the room instead of calmly resigning.
- His wife witnessed it and sarcastically praised him for being a great role model for sportsmanship at age 52.
- It may not help that is son is a bit of a trash talker
  - His son’s nickname is “Little Bag Smoker,” because he often taunts, “I’m going to smoke your bags.”

## Overview of key scenarios for evaluating sugar and sweeteners [A: 6:15, V: 5:15]

**Introduction to the topic**

- Today’s topic is sugar and sugar substitutes—chosen because it’s a common listener question and a daily decision point for many people.
- Plan to cover:
  - Why we’re wired to crave sugar.
  - Sugar’s effects on appetite, weight, and metabolic health.
  - Natural vs. refined sugar.
  - Timing of sugar intake vs. total quantity consumed.
  - Sugar substitutes: aspartame, sucralose, stevia, monk fruit, allulose.
  - Effects on weight, insulin, microbiome.
  - Sugar alcohols like xylitol and erythritol.
  - Long-term safety concerns (cancer, cardiovascular disease).
  - How to apply the science to personal and patient choices.

Peter’s two preliminary comments

- 1) Updated literature – This topic was covered in 2020 on [AMA #18](https://peterattiamd.com/ama18/), but new research (especially on non-nutritive sweeteners) justifies revisiting it. Science progresses, and there have been meaningful updates.
- 2) Framework focus – Despite diving into technical details, the goal is to land on practical recommendations for real-world scenarios.

Goal for the episode – key practical questions

- Is eating a lot of sugar “okay”?
- If not, is switching to sugar substitutes (while keeping the same quantity of food/beverage) a better option?
  - Example: Six regular Mountain Dews/day vs. six diet Mountain Dews/day.
- Trade-offs between real sugar and artificial sweeteners in different contexts.

The three main “use cases” for artificial sweeteners

- 1) Beverages – Regular vs. diet soda or other drinks.
- 2) Protein products – Protein powders and bars often require sweetening.
  - Protein is difficult to work with, tastes unpleasant without sweeteners, and is best obtained from whole food when possible.
  - Processed protein sources fall into:
    - Dry/salty forms (e.g., jerky, sticks).
    - Sweetened forms (e.g., shakes, bars).
  - If sweetened, the choice is between artificial sweeteners and real sugar.
    - Peter likes the [David Bar](https://davidprotein.com/?srsltid=AfmBOoroeK4fi4wVtP5qVyL5f8b78O_nhHNPhORZctI9ODzNTIS9YVCj)
- 3) Sweet treats – Desserts, candy, and other indulgences.
  - The question: Is it better to satisfy cravings with products sweetened by sucrose/HFCS or artificial sweeteners?

Setting expectations for the listener

- To answer these questions, listeners will need to understand some biochemistry.
- Peter apologizes in advance but stresses it’s necessary to “land the plane” with meaningful, actionable conclusions.

## Why humans are hardwired to crave sweetness [A: 13:30, V: 13:15]

***Why are humans so hardwired to crave sweetness?***

Framing the Question

- The discussion starts with why humans are hardwired to crave sweetness, from an evolutionary standpoint.
- This is important because, despite knowing sugar and candy aren’t “healthy,” resisting them is difficult for nearly everyone.

Peter’s Key Points on Evolutionary Basis

- Timescale of human evolution – For ~250,000 years as Homo sapiens, food scarcity/starvation was a far greater threat than obesity.
- Modern shift – Only in the last ~100 years have overabundance and obesity become the main problem.
- Genetic reality – Our genome has not evolved to protect against today’s issues (fatty liver disease, diabetes, etc.).
- Survival advantage of a sweet tooth –
  - Encouraged the intake of calorie-rich foods with quick energy (glucose, fructose).
  - Sweet flavors helped guide humans toward safer foods, avoiding potentially toxic/bitter foods.
- Aversion to bitterness – Many harmful or spoiled foods taste bitter, so an instinctive dislike for bitterness was also selected for.
- Takeaway – People shouldn’t overly blame themselves for liking sweets—it’s the product of hundreds of thousands of years of evolutionary selection.

## Evaluating whether sugar is uniquely fattening or more harmful than other macronutrients under isocaloric conditions [A: 15:15, V: 15:15]

***If calorie intake is held constant, does a high-sugar diet cause more weight gain or metabolic disease than a low-sugar diet?***

Peter’s Position

- There’s significant disagreement on whether sugar is uniquely fattening at isocaloric levels.
- Definition of “isocaloric” – Equal calories, but different proportions of sugar vs. other carbs (e.g., sucrose vs. glucose).
- Peter’s current reading of the evidence suggests to him that there’s no unique fattening effect under strict isocaloric conditions
  - That means if two people consume the same calories, one high-sugar and one low-sugar, the fat gain is likely similar.
- Real-world caveat –
  - Life doesn’t happen in a metabolic ward.
  - Sugar has a unique ability to:
    - Increase appetite
    - Alter perceived energy levels
    - Lead to downstream excess calorie intake
    - Possibly decrease energy expenditure
  - These indirect effects make sugar more likely to cause weight gain in free-living conditions.

Answerability of the Question

- Yes, it’s answerable – But only with metabolic ward studies (controlled environment).
- Practical challenges –
  - Requires long-term confinement for long-term answers.
  - Very expensive and logistically challenging.
  - No obvious funding source or “owner” of the question.
- Short-term vs. long-term – Easier to study short-term health impacts than long-term outcomes.
- Likelihood – Possible in theory, but unlikely to be funded or executed at scale.

*\*For more on this topic, see episodes of The Drive featuring*:

- [Eric Ravussin](https://peterattiamd.com/ericravussin/)
- [Gary Taubes](https://peterattiamd.com/garytaubes/)
- [Stephan Guyenet](https://peterattiamd.com/stephanguyenet/)

## Why sugar drives appetite: low satiety, insulin response, and reward system activation [A: 18:45, V: 19:15]

***Why does sugar seem to increase appetite more than other macronutrients?***

- Carbohydrates vs. fats & proteins
  - Carbohydrates, as a class, are less satiating than fats or proteins.
  - The feeling of fullness from carbs lasts for a shorter time.
- Physiological mechanism
  - Carbs are metabolized with insulin secretion.
  - Insulin lowers blood glucose rapidly.
  - Sometimes there’s an overshoot → glucose dips lower than baseline.
  - This triggers hunger signals as the body seeks to restore glucose.
  - This glucose regulation is designed to keep levels within a narrow range unless pathology exists.
- Sugar’s unique effect
  - Being a simple carbohydrate, sugar causes these effects faster and more dramatically than complex carbs.
  - Leads to shorter satiety duration.
- Brain reward system
  - Sugar strongly activates reward pathways.
  - Can stimulate continued eating even without hunger.
  - Example: Easily finishing a bowl of gummy bears despite not feeling hungry.
- Overall effect
  - Appetite returns quickly due to both metabolic fluctuations and reward-driven eating.

## How sugar type, liquid vs. solid form, and processing level influence appetite and metabolic impact [A: 20:15, V: 21:15]

**Questions**

- *What factors affect how much sugar can drive appetite?*
- *Does it differ if sugar is consumed as a sweetened beverage vs. solid food?*

Sugar composition & forms

- Sucrose: one glucose + one fructose molecule.
- High fructose corn syrup (HFCS): blend of free fructose and glucose, usually higher in fructose than sucrose → sweeter taste (fructose is inherently sweeter than glucose).
- Fructose in nature: mainly in fruit (with some glucose), generally not problematic at normal fruit consumption levels.
- Excess fructose: more likely than excess glucose to increase appetite and cause metabolic dysregulation.
  - See [Rick Johnson episode](https://peterattiamd.com/rickjohnson2/)

Why fructose has stronger effects

- ATP depletion:
  - First metabolic step of fructose is ATP-depleting.
  - Fructose consumes ATP faster than glucose, creating a transient “energy debt” perceived as starvation by the body.
  - Small amounts (fruit) are insignificant; large amounts (e.g., huge Twizzler pack) cause significant energy debt → repeated eating behavior.
- Brain effects:
  - Fructose [increases activity](https://www.sciencedirect.com/science/article/abs/pii/S2352154616300614) in neural circuits for food motivation and responsivity.
  - Glucose has the opposite effect (signals satiety).
- Hormonal signals:
  - Fructose stimulates satiety hormones (GLP-1, leptin) far less than glucose does ([1](https://www.sciencedirect.com/science/article/abs/pii/S0196978199000066),[2](https://www.cambridge.org/core/journals/british-journal-of-nutrition/article/effects-of-carbohydrate-sugars-and-artificial-sweeteners-on-appetite-and-the-secretion-of-gastrointestinal-satiety-peptides/E510F6CE46A82AB060B75A95F9C4318A)).

Liquid vs. solid sugar

- Absorption rate matters: faster absorption → stronger appetite-driving effect.
- Liquids (e.g., orange juice, soda):
  - Typically higher sugar concentration due to lack of fiber and water removal.
  - Faster gut absorption accelerates metabolic effects described above.
- Solids (e.g., candy bar):
  - Slower absorption due to solid form and presence of fat.
  - Fat slows digestion, reducing rapid glucose/fructose spikes.
- Real food vs. ultra-processed:
  - Real foods have more fiber and water → slower sugar absorption, less appetite stimulation.
  - Ultra-processed foods lack these buffers.

Overall takeaway

- The more processed, liquid, and fructose-heavy the sugar source, the greater its potential to drive overconsumption.

## Addressing the common belief that natural sugars are healthier than refined sugars [A: 26:00, V: 27:45]

***Are refined sugars more dangerous than “natural” sugars?***

No fundamental biochemical difference

- “Refined” sugars are extracted and concentrated from natural sources — the end product is the same basic glucose and fructose molecules.
- Example: cane sugar (sucrose) vs. high fructose corn syrup (HFCS):
  - HFCS may be worse if engineered with unusually high fructose (e.g., 70/30 mix vs. sucrose’s 50/50), but standard cane sugar and HFCS with similar ratios are essentially equivalent.

Marketing illusion

- Terms like “natural sweetener” often imply health benefits, but in practice, the metabolic impact is the same if macronutrient content is identical.
- “Raw sugar” still undergoes refining: extracted from cane, filtered, boiled, crystallized.
- Unless sugar is consumed in its whole food form (chewing cane, eating an apple), it’s refined.

Natural sweeteners (honey, maple syrup, agave)

- Often higher in fructose than many refined sugars.
- Fructose content — not the “natural” label — is more relevant to metabolic and appetite effects.
- Some possible additive benefits (e.g., micronutrients, bioactives in honey), but not enough to offset fundamental biochemical effects of the sugar itself.

Bottom line

- Choosing “natural” over “refined” sugar doesn’t change the underlying glucose/fructose load or its metabolic consequences.
- A candy bar with “natural sweeteners” is still a candy bar.

## How the timing of sugar consumption alters the body’s metabolic response [A: 29:15, V: 31:55]

***Does sugar timing matter for metabolic effects — e.g., post-workout vs. late-night consumption?***

Why timing matters

- Sugar (sucrose, glucose, fructose) isn’t inherently “bad” — effects depend on dose and the body’s capacity to metabolize/dispose of it.
- Glucose disposal capacity is influenced by:
  - 1) Insulin sensitivity
  - 2) Available glycogen storage space (“glycogen chamber”)

Best time to consume sugar

- Post-exercise:
  - Muscle glycogen stores are depleted → more room for glucose storage.
  - Insulin sensitivity is maximized → faster and more efficient glucose uptake.
  - This combination minimizes harmful metabolic effects.
  - Endurance athletes intentionally consume large amounts of simple sugars during events to sustain performance, sometimes training their gut to tolerate higher intakes without GI distress.

Worst time to consume sugar

- Late night / pre-bed (especially without recent exercise):
  - Circadian rhythm reduces insulin sensitivity → more insulin resistance at night.
  - Glucose spikes are larger, and clearance is slower.
  - Continuous Glucose Monitor (CGM) users can see much higher and more prolonged post-meal glucose curves at night compared to the same meal in the morning.

Practical takeaway

- For those who want to indulge in sugar but minimize negative impact:
  - Best to consume within ~1 hour after exercise.
  - Worst to consume late at night, especially without prior physical activity.
  - Metabolic responses vary depending on activity level and timing, so context matters.

## How Peter advises patients on sugar intake, factoring in metabolic health, insulin sensitivity, and activity level [A: 34:45, V: 38:00]

**Peter’s general approach to sugar intake recommendations**

- No universal, “canned” recommendation — advice is tailored to the individual.
- Peter’s guidance considers:
  - Metabolic health (including insulin resistance status).
  - Body composition.
  - Activity level.
  - Overall nutrition, with specific focus on macronutrient composition.

Different strategies for different metabolic profiles

- For patients with NAFLD/[MASLD](https://peterattiamd.com/juliawattacheril/) and significant insulin resistance:
  - Carbohydrate tolerance is generally low.
  - Limit carbohydrates per sitting to avoid glucose spikes (often 20–30 g max).
  - Avoid “wasting” carb allowance on simple sugars.
  - Prioritize low-glycemic or complex carbohydrates, used strategically for glycogen replenishment rather than treats.
- For metabolically healthy, highly active patients:
  - Greater carbohydrate tolerance (up to ~100 g glucose per sitting without adverse spikes).
  - More flexibility in sugar intake; fewer restrictions if metabolic health is optimal.

Philosophy: If a person’s metabolic system is functioning well (“if it ain’t broke”), no need to impose unnecessary dietary restrictions.

Carbohydrate tolerance and glucose response

- Some individuals experience rapid glucose spikes with small carb loads (20–30 g).
- Others can handle significantly higher carb loads (~100 g) without issue.
- Understanding personal carb thresholds is key to dietary planning.

## The most common sugar substitutes, their sweetness relative to sugar, and their caloric content [A: 36:30, V: 40:20]

**Categorizing sugar substitutes**

- Can be classified by:
  - Nutritive vs. non-nutritive:
    - Nutritive: Consumed in sufficient quantity to provide calories.
    - Non-nutritive: Consumed in amounts so small that calories are negligible.
  - Category: Synthetic vs. naturally occurring.

Most common low-calorie synthetic sweeteners (“big three”)

- Saccharin
  - Brand: Sweet’N Low (pink packet).
  - 0 kcal/g (non-digestible).
  - 300× sweeter than sucrose.
  - Example: To match sweetness of 10 g sucrose, use 10 ÷ 300 g saccharin.
- Aspartame
  - Brand: NutraSweet (blue packet).
  - 4 kcal/g (same as sucrose) but 180–200× sweeter.
  - Small amount needed, so calories are negligible (“rounding error”).
- Sucralose
  - Brand: Splenda (yellow packet).
  - 0 kcal/g (non-digestible).
  - 600× sweeter than sucrose (even sweeter than saccharin).

![](https://peterattiamd.com/wp-content/uploads/2025/08/f1-ama74-1.png)

**Figure 1.** Comparison of common sugar substitutes to sucrose (table sugar).

Naturally occurring low-calorie sweeteners

- Sugar alcohols: Sorbitol, xylitol, erythritol.
  - Sorbitol: 0.6× sweetness of sucrose, 2.6 kcal/g, can cause GI issues.
  - Xylitol: Equal sweetness to sucrose, 2.4 kcal/g, low-calorie but not zero.
  - Erythritol: 0.7× sweetness, 0.2 kcal/g (significantly reduced calories).

**Allulose** (we will discuss in more detail later on)

- Similar sweetness to erythritol (0.7× sucrose).
- Very low calorie: 0.2 kcal/g (~1/20th of sucrose’s caloric load).
- Has unique benefits that will be discussed in depth later.

## Evaluating the role of sugar substitutes in weight control: efficacy vs. effectiveness and limitations in study design [A: 40:15, V: 44:30]

Framing the complexity of sugar substitutes and weight loss

- Transitioning from straightforward to more complex territory when discussing sugar substitutes’ role in weight control.
- Importance of asking the right questions and defining the context.
- Large body of RCTs and animal studies exist, but results depend heavily on study design.

Efficacy vs. effectiveness distinction

- **Efficacy**: How well an intervention works under perfect, controlled conditions.
- **Effectiveness**: How well an intervention works in real-world conditions.
- Example: Testing if sugar is uniquely fattening — requires strict control in efficacy studies, but real-world scenarios can reveal different behavioral impacts (e.g., compensatory eating).

Limitations in current research designs

- Many studies control for other aspects of diet (e.g., matching total calories or macronutrients) to isolate biochemical effects.
- While good for understanding direct physiological effects, this approach may miss real-world implications on total caloric intake and dietary patterns.

Importance of comparison group selection

- Illustrative example using Coke, Diet Coke, and Topo Chico (all Coca-Cola Company products):
  - Coke: High in calories and sweet.
  - Diet Coke: No calories but sweet.
  - Topo Chico: No calories and not sweet.
- Raises the question: Should comparisons be between high-calorie sweetened vs. low-calorie sweetened, or between sweetened vs. non-sweetened options?

Proposed fairer experimental design example

- Coke group: Coke only (e.g., 40 g sugar = 160 kcal).
- Diet Coke group: Diet Coke + 160 kcal glucose from rice.
- Topo Chico group: Topo Chico + 160 kcal glucose from rice.
- This structure would better isolate the effects of sweetness vs. caloric content.

Key takeaway on experimental flaws

- Many studies fail to:
  - Control for total calories.
  - Account for substitution of sweetness.
  - Compare to a non-sweet baseline.
- This makes it difficult to draw firm conclusions about sugar substitutes’ impact on weight in the real world.

## Assessing the real-world impact of sugar substitutes on weight, and the role of sweetness without calories [A: 44:00, V: 48:50]

Overview of evidence on sugar substitutes and weight control

- When compared directly to sugar, most [studies](https://onlinelibrary.wiley.com/doi/full/10.1111/obr.13652) show sugar substitutes have a neutral or modestly beneficial effect on weight loss or prevention of weight gain.
  - The small benefits are seen in short-term RCTs so any potential long-term effects (positive or negative) are unclear due to lack of extended trials.
- Long-term data are primarily from epidemiology or animal studies and generally do not show a significant advantage for sugar substitutes.
  - Epidemiology often shows just the opposite, that use of sugar substitutes is positively correlated with body weight, though these studies are subject to biases and generally can’t distinguish between sweeteners used to replace sugar vs. sweeteners used in addition to normal diet

Challenges in interpreting long-term data

- Epidemiologic studies may contain confounders:
  - Could be that people consuming sugar substitutes are less healthy to begin with.
  - Alternatively, could be that sugar substitute consumers are more health-conscious.
- These opposing possibilities make causal conclusions difficult.
- Overall conclusion: any effect from sugar substitutes on weight is not large.

Practical substitution example — Coke vs. Diet Coke vs. Soda Water

- Replacing three regular Cokes/day with three Diet Cokes/day likely has little impact on body weight.
- Replacing three regular Cokes/day with three soda waters (e.g., Topo Chico, any non-sweet, non-caloric beverage) might lead to a meaningful weight reduction.

Possible mechanism for difference between Diet Coke and soda water substitution

- Diet Coke scenario:
  - Sweetness triggers reward pathways and post-absorptive signaling despite lack of calories.
  - Leads to compensatory eating — individuals seek extra calories elsewhere in their diet.
  - Example: Saving ~500 kcal/day from removing three regular Cokes can be offset by consuming ~500 kcal from other sources.
- Soda water scenario:
  - Absence of sweetness reduces reward-driven caloric compensation.
  - Net calorie reduction is more likely to persist, producing measurable weight loss.

## The impact of sugar substitutes on glycemic control [A: 47:30, V: 52:50]

**Glycemic Control & Sugar Substitutes**

- When calorie intake is the same, RCTs, epidemiology, and animal studies generally show worsened glycemic control in those consuming sugar substitutes compared to no sweetener.
- Example scenario:
  - Group A drinks three Diet Cokes/day.
  - Group B drinks three Topo Chico’s/day.
  - Group A shows poorer glycemic control.
- Practical implication:
  - If someone doesn’t already drink diet sodas, starting a habit (e.g., three per day) is likely a net negative.
  - Occasional diet soda is fine, but habitual high intake is discouraged.

Switching from Sugar to Sugar Substitutes

- Most listeners are not deciding between no soda and diet soda; they’re considering replacing regular Coke with Diet Coke.
- Acute glycemic response to sugar substitutes is smaller than to sugar.
- Long-term data (from epidemiology and animal studies) suggest no significant improvement in glycemic control when making this switch, especially in metabolically unhealthy individuals.
- This is counterintuitive to what many people expect.

Possible Mechanism – Gut Microbiome Impact

- Many low-calorie sweeteners are not metabolized by humans but are metabolized by gut bacteria.
- This may:
  - [Reduce](https://www.frontiersin.org/journals/microbiology/articles/10.3389/fmicb.2025.1531131/full) gut microbiome diversity.
  - Encourage growth of bacteria less effective at aiding glycemic control.
- Dietary context matters:
  - Diet Coke with a balanced, fiber-rich diet (e.g., daily salads) may have less impact on microbiome and glycemic control.
  - Diet Coke with a diet of mostly refined junk food likely worsens microbiome diversity and glycemic control.

Diet Context & Example Extremes

- Example extremes used to illustrate context effect:
  - “7-11 diet”: Processed junk food all day + Diet Coke.
  - “Whole Foods diet”: Balanced meals + Diet Coke.
  - Peter’s hypothesis: The Whole Foods diet scenario would be less negatively impacted by Diet Coke consumption.
    - No direct study comparing these scenarios, but likely differences due to overall diet quality.

## The impact of sugar substitutes on glycemic control [A: 47:30, V: 52:50]

Microbiome’s Role in Obesity & Diabetes

- Determining causality between microbiome composition and conditions like obesity and diabetes is challenging despite many studies exploring associations.
- Sugar substitutes — particularly saccharin, aspartame, and sucralose — have been shown in certain studies to directly alter microbiome composition.
- These microbiome changes can impair glycemic control, with effects depending on the dose consumed.

Studies & Evidence

- [Study](https://www.cell.com/cell/fulltext/S0092-8674(22)00919-9) that documented the microbiome-altering effects of certain sugar substitutes and their impact on glycemic control.
- Peter does not elaborate during this discussion for the sake of time.

Relative Importance of Microbiome Changes vs. Other Factors

- Peter suspects microbiome impact is only part of the explanation for the lack of metabolic benefit in switching to sugar substitutes.
- In controlled settings where calorie intake is matched, sugar substitutes likely do not cause additional harm.
- In real-world settings, people tend to overconsume calories elsewhere, negating the benefits of replacing sugary beverages with diet versions.

Real-World Beverage Substitution Problem

- Beverage substitution example: Switching from Coke to Diet Coke often leads to increased calorie intake from other sources.
- This overcompensation may be a bigger driver of poor metabolic outcomes than microbiome changes.
- Peter’s intuition (not proven) is that this behavior is the primary reason switching to diet beverages doesn’t produce significant metabolic improvements.

## How Peter advises patients on the use of sugar substitutes across different contexts [A: 52:30, V: 58:45]

**Framework for Deciding on Sugar Substitute Use**

- Intent Matters: Decision depends on the goal—reducing empty calories, improving palatability, or satisfying a sweet tooth.

Three Main Scenarios:

- 1) Swapping Sugary Soda for Diet Soda
  - Net positive in real-world human data.
  - At worst neutral, more likely beneficial compared to continuing sugary soda consumption.
  - Likely no significant weight loss due to compensatory calorie intake from other foods.
  - Replacement calories are often better quality than those from sugary soda.
- 2) Using Artificially Sweetened Protein Products (bars, powders)
  - Protein is the most important macronutrient; many people struggle to hit targets (1.6–2 g/kg/day).
  - Ideal to get protein from whole food sources (meat, fish, high-protein plants), but supplements are often necessary.
  - Trade-off is worth it—small amount of sweetener in exchange for adequate protein intake is a significant positive.
  - Protein products generally contain less sweetener than beverages.
  - Many products use blends of multiple sweeteners, not just one.
- 3) Using Artificially Sweetened Foods to Satisfy a Sweet Tooth
  - Likely a net negative.
  - Desserts are not eaten for nutrition but to satisfy cravings.
  - Sugar activates SGLT1 nutrient sensors in the GI tract, signaling the brain to stop seeking carbs; artificial sweeteners do not trigger this.
  - Lack of satiation leads to potential overconsumption, especially in high-calorie, high-fat, high-carb foods with artificial sweeteners.
  - Can result in higher calorie intake than if consuming natural sweet options (e.g., fruit).

## Allulose—a sweetener with unique satiety and glycemic benefits and potential for weight control [A: 57:15, V: 1:04:30]

***Are there certain sugar substitutes that are more satiating than others?***

- The answer is yes – “*this is one of those areas where I think the research has taught us a lot in the last few years*”
- Peter started talking about allulose about 10 years ago — it’s a very unique sugar substitute

Allulose’s Unique Properties & Mechanisms

- Unlike most sugar substitutes, allulose activates the SGLT1 nutrient sensor in the gut, which drives the satiating effect of real sugar.
- Caloric Profile:
  - ~70% as sweet as sucrose.
  - ~0.2 kcal per gram (1/20th the caloric density of sugar).
  - Mostly excreted in urine; minimal metabolism.
- Natural & Synthetic Sources: Found in trace amounts naturally; commercially produced synthetically.
- Impact on Glucose Absorption:
  - Competes with glucose for the SGLT1 transporter in the gut → slows or partially blocks glucose absorption.
  - Likely also competes for SGLT1 in the kidneys, leading to increased urinary glucose excretion (supported by small [RCTs](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0281150)).

Experimental & Anecdotal Evidence

- CGM Experiments (Anecdotal): For Peter, adding allulose to coffee lowered blood glucose more than coffee alone (with or without cream).
- Animal [Studies](https://www.nature.com/articles/s41467-017-02488-y):
  - Reduced food intake, improved glucose tolerance, stimulated GLP-1.
  - Positive effects in both normal-weight and obese diabetic mice.
- Human Studies:
  - Small [crossover RCT](https://www.mdpi.com/2072-6643/15/12/2802) in diabetics (n=20, each as their own control) → improved glycemic control.

![](https://peterattiamd.com/wp-content/uploads/2025/08/f2-ama74-1024x640.png)

**Figure 2**. Mean glucose level curves for all meals during the intake period of each diabetic diet group, based on CGM data. [[source](https://www.mdpi.com/2072-6643/15/12/2802)]

- Positive effects compared to sugar, water, and Stevia.
- Weight & Glycemic Control:
  - Allulose [shows potential benefits for both](https://www.nature.com/articles/s41467-017-02488-y), but human data is short-term.
  - Every study to date shows net positive effects, even compared to [pure water](https://pubs.acs.org/doi/full/10.1021/acs.jafc.6b05627) or [stevia](https://www.mdpi.com/2072-6643/16/12/1821).

Limitations & Practical Challenges

- Shelf Life Issue: Undergoes the Maillard reaction, leading to rapid changes in flavor, color, and firmness of packaged products.
- Formulation Constraints:
  - Limits the amount that can be used in commercial packaged foods.
  - Many food companies reduce allulose content to preserve texture/taste over shelf life.
- Best Use Cases:
  - Immediate consumption: coffee, tea, homemade baked goods.
  - Less suited for long-shelf-life packaged goods without careful formulation.

Takeaway & Position in Sweetener Landscape

- Nutritional & Metabolic Advantage: Only sweetener with both satiety signaling (via SGLT1 activation) and glucose-lowering potential.
- Potentially superior for weight loss and glycemic control compared to other sweeteners—pending more long-term human trials.
- Ideal for at-home use and short-term products; commercial replacement for other sweeteners is limited by stability issues.

## Emerging evidence that stevia, monk fruit, and sugar alcohols may provide modest metabolic benefits compared to sugar [A: 1:03:00, V: 1:10:45]

Broader Landscape Beyond the “Big Three”

- Most research historically centers on saccharin, sucralose, and aspartame—these generally show slight negative metabolic effects.
- Newer & alternative sweeteners:
  - [Stevia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2900484/) derivatives
  - [Monk fruit](https://www.sciencedirect.com/science/article/pii/S0022030220301302)
  - [Sugar alcohols](https://pmc.ncbi.nlm.nih.gov/articles/PMC9261844/) (e.g., erythritol, xylitol)
- Metabolic Impact: Compared to sugar, these newer alternatives may offer slight positive effects on weight maintenance and glycemic control.
  - The benefit is modest—roughly the same size as the negative effects seen with the big three, but in the opposite direction.

Allulose as a Standout

- Consistently shows remarkable and reproducible metabolic benefits in studies.
- Superior evidence base compared to other sweeteners.
- Comparison Framework:
  - Big Three → slight negative.
  - Stevia, monk fruit, sugar alcohols → slight positive.
  - Allulose → strong positive, more compelling data.

Practical Implications

- For Sugar Replacement:
  - Stevia, monk fruit, and sugar alcohols are likely better choices than the big three when the goal is weight or glucose management.
  - The effect size is helpful but not transformative—still dependent on overall diet and behavior.
  - Evidence Gap:
    - These alternatives lack the breadth and strength of research seen for allulose.
    - More long-term and high-quality human trials are needed to confirm and quantify benefits.

Simple Rule of Thumb when replacing sugar:

- Best choice (based on evidence) → Allulose.
- Moderately good choice if replacing sugar → Stevia, monk fruit, sugar alcohols.
- No impact and possibly even a slight negative impact → Aspartame, saccharin, sucralose.

## Sugar alcohols explained [A: 1:04:15, V:1:12:20]

Definition and Classification

- Sugar alcohols are more accurately called polyols.
- They are compounds derived from sugars.
- Key Difference from Sugar:
  - Absorbed and metabolized less efficiently.
  - The result is lower caloric content compared to table sugar.

Caloric and Sweetness Profile

- Calories per gram: Typically 0.7 to 2.5 kcal/g.
- Sweetness: Comparable to sugar in taste profile, making them suitable as sugar replacements in recipes and processed foods.

Natural vs. Synthetic Sources

- Natural Occurrence: Found in certain fruits and vegetables in small amounts.
- Commercial Production: Often synthesized in large quantities for use in food products—similar process to allulose production.

Functional Role in Diet

- Purpose: Provide sweetness with fewer calories.
- Metabolic Impact: Lower energy density due to reduced absorption and metabolism—beneficial for calorie reduction compared to sucrose.
- No “Magical” Properties: Their benefits come primarily from lower calorie content and reduced glycemic impact, not from unique physiological effects.

Key Takeaway: Sugar alcohols are partially absorbed, lower-calorie sugar derivatives that occur naturally in small amounts but are usually produced synthetically for food use. They mimic sugar’s taste closely while delivering fewer calories.

## Sugar alcohols and GI issues [1:05:00]

GI Side Effects of Sugar Alcohols

- Mechanism of GI upset:
  - Sugar alcohols are not fully digested in the small intestine.
  - They reach the colon, where gut bacteria ferment them, producing gas and causing bloating.
- Why Allulose is different:
  - Allulose is excreted via the kidneys (urine), bypassing the colon fermentation process.

Individual Susceptibility

- Tolerance varies:
  - People unaccustomed to sugar alcohols typically have worse symptoms initially.
  - Symptoms often diminish over time with continued consumption (mechanism unclear).
- Sex differences:
  - Women tend to tolerate higher doses than men, adjusted for body weight.
- Medical conditions:
  - People with IBS often experience stronger symptoms.
- Genetic variation:
  - Tolerance can differ based on genetic factors.

Consumption Factors Affecting Tolerance

- Food pairing:
  - Consuming sugar alcohols with other foods reduces symptoms.
  - Taking them in isolation or on an empty stomach increases severity.
- Concentration: Higher concentrations → more pronounced symptoms.

Differences Between Types of Sugar Alcohols

- Erythritol:
  - Gentlest on GI tract because it is more readily absorbed before reaching the colon.
- Xylitol:
  - Often well tolerated (Peter’s personal experience; aligns with general consensus).
- Sorbitol:
  - Generally the worst for GI distress.

**Maximal dose per meal to avoid laxative effect for major sugar alcohol sweeteners**:

![](https://peterattiamd.com/wp-content/uploads/2025/08/f3-maximal-dose-sugar-alcohol-ama74.png)

**Figure 3.** \*These numbers are approximations based on feeding studies typically involving administration of an isolated bolus of sweetened fluid, often in subjects unaccustomed to sugar alcohols. Adaptation or consumption with solid food can significantly raise thresholds for tolerability. [[source](https://onlinelibrary.wiley.com/doi/full/10.1155/2016/5967907)]

Key Takeaway: GI upset from sugar alcohols stems from incomplete digestion and bacterial fermentation in the colon, with tolerance varying by individual, consumption habits, and the specific type of sugar alcohol.

## Xylitol’s dental health benefits and considerations for use [A: 1:05:00, V: 1:13:20]

Unique Benefit of Xylitol

- Dental Health:
  - [Inhibits](https://onlinelibrary.wiley.com/doi/full/10.1002/cre2.724?utm_source=chatgpt.com) growth of pathogenic oral bacteria responsible for plaque buildup and gingivitis.
  - Can be beneficial in toothpaste, gum, candies, and other oral-contact products.

Personal Use Case (Peter Attia)

- Prefers xylitol-sweetened gum when chewing gum.
- Previously used xylitol toothpaste, but stopped due to convenience and availability (no negative reason related to efficacy).
- No personal GI side effects from xylitol, which increases usability for him.

Limiting Factor for Use

- GI tolerance determines maximum usable amount for an individual.
- People sensitive to xylitol may be limited in how much they can consume, despite oral health benefits.

Key Takeaway: Xylitol stands out among sugar alcohols for its oral health benefits—particularly reducing bacteria linked to plaque and gingivitis—making it an attractive choice in gum and toothpaste, provided an individual tolerates it well.

## Artificial sweeteners and cancer risk: evaluating evidence, the aspartame controversy, and the role of dose in toxicology [A: 1:07:15, V: 1:15:55]

**Overall Cancer Risk from Sugar Substitutes**

- Human Data:
  - No credible evidence linking common sugar substitutes to increased cancer risk at typical human consumption levels.
  - Large, longitudinal epidemiologic studies and human-dose-equivalent animal studies [do not show](https://pmc.ncbi.nlm.nih.gov/articles/PMC10822749/?utm_source=chatgpt.com) a signal for cancer.
- Animal Overdose Studies:
  - Cancer can be induced in animals with extreme doses (e.g., 3x body weight per day), but these conditions are unrealistic for humans.

> “*When you look at even the largest and most longitudinal epidemiologic studies, we just don’t see that signal. Does that mean that it’s not there? It’s very difficult to imagine that it is there in a clinically meaningful way and that it is not being picked up in the appropriate studies*.” —Peter Attia

Aspartame and WHO Carcinogen Classification

- WHO Decision:
  - WHO [labeled](https://www.who.int/news/item/14-07-2023-aspartame-hazard-and-risk-assessment-results-released) aspartame a carcinogen (~2 years ago), based largely on flawed rodent data from one research group.
  - Studies involved very high doses, starting in gestation and continuing for the animal’s life.
  - Doses often exceeded FDA’s acceptable daily intake (50 mg/kg body weight).
- Dose Context:
  - For a 175 lb adult, that’s equivalent to 20 cans of diet soda every day for life, starting in the womb.
  - The lack of a signal in human epidemiology for realistic intake levels further weakens the cancer risk claim.

Toxicology Principle — “The Dose Makes the Poison”

- Applies to all substances, even water (e.g., marathoners dying of hyponatremia from overconsumption).
- Important measure: LD₅₀ (dose lethal to 50% of test population).
- Current human consumption patterns for sugar substitutes are orders of magnitude below any toxic threshold—if such a threshold is even measurable.

## Sugar substitutes and cardiovascular disease: assessing flawed studies and the absence of direct risk evidence [A: 1:11:00, V: 1:20:15]

Headlines Linking Sugar Substitutes to Cardiovascular Disease (CVD)

- Main Studies Involved:
  - Two high-profile papers in recent years focused on sugar alcohols: one on [xylitol](https://pubmed.ncbi.nlm.nih.gov/38842092/), one on [erythritol](https://www.nature.com/articles/s41591-023-02223-9).
  - These studies formed the basis for much of the recent media coverage.
  - Peter’s team reviewed and “debunked” both in their newsletters, finding them not credible.
    - [More hype than substance: erythritol and cardiovascular risk](https://peterattiamd.com/more-hype-than-substance-erythritol-and-cardiovascular-risk/) (March 2023)
    - [Does xylitol increase risk of cardiovascular disease?](https://peterattiamd.com/xylitol-and-cvd/) (June 2024)

Key Issues with the Studies

- 1) Endogenous Production Confounding
  - Both xylitol and erythritol are naturally produced by the human body.
  - Production levels increase with inflammation, obesity, diabetes, and other disease states that already raise CVD risk.
  - Therefore, correlation ≠ causation — high circulating levels may be a marker of disease, not a cause.
  - No direct evidence that dietary intake of these sugar alcohols increases CVD risk.
- 2) Flawed Mechanistic Models
  - In vitro and in vivo experiments used doses far above typical human consumption.
  - These unrealistic exposure levels limit applicability to real-world dietary patterns.

Indirect Considerations

- While no credible evidence shows direct CVD risk from moderate consumption, obesity and metabolic disease are well-established CVD risk factors.
- If sweeteners indirectly contribute to weight gain or poor diet quality (e.g., encouraging overeating), they could indirectly increase CVD risk.
- The key factor is overall dietary context and moderation.

## Why artificial sweeteners seem to attract so many negative headlines [A: 1:12:45, V: 1:22:05]

Reasons for Recurring Alarmist Headlines on Sugar Substitutes

- Natural vs. Artificial Bias
  - Widespread belief: “Natural = healthy, artificial = harmful.”
  - People often seek studies or evidence that confirm this pre-existing belief (confirmation bias).
  - Many scientists may unintentionally design or interpret studies through this lens, overlooking flaws.
- Media Limitations
  - Many journalists lack the scientific literacy to critically assess study design, methodology, or limitations.
  - As a result, they may amplify flawed findings without proper scrutiny.
- Social Media Amplification
  - Alarmist narratives spread rapidly online.
  - Headlines and posts often oversimplify complex science into binary “good vs. bad” conclusions.

Core Message

- Natural does not equal automatically good
  - Harmful natural examples: arsenic, lead — dangerous even in modest amounts.
- Artificial does not equal automatically bad
  - Life-saving artificial examples: PCSK9 inhibitors, modern antibiotics.
- Reality is nuanced — safety depends on dose, context, and evidence, not whether something is “natural.”

> “*When you live in a black and white world, and everything has to be good or bad, and natural is good and not natural is bad, and you are a robot, life is a painful place to exist.*” —Peter Attia

## Balancing benefits and risks of sugar substitutes: guidance for desserts, beverages, and protein products [A: 1:14:15, V: 1:24:00]

Framework for Balancing Risk-Benefits of Sugar Substitutes

- 1) Understand Your “Why”
  - If the goal is to satisfy a sweet craving with fewer calories:
  - Sometimes better to eat a small portion of real dessert rather than a large portion of artificially sweetened dessert.
  - Best option: recalibrate palate toward natural sweetness from whole fruit (harder to overeat, provides nutrition, and offers natural satiety signals).
- 2) Food Use Cases
  - Fruit as a sweet fix:
    - Bananas, berries, and other fruit provide sweetness plus nutrients and fiber.
  - Avoiding large servings of artificially sweetened treats:
    - Example: Skip artificial licorice in favor of nutrient-dense options.
- 3) Beverage Use Cases
  - Hierarchy of choices:
    - Coke → worst for metabolic health.
    - Diet Coke → better than Coke if needing a stepping stone away from sugar-sweetened beverages.
    - Flavored sparkling water (no artificial sweeteners) → best long-term option.
  - Clinical observation:
    - Heavy daily consumption of diet sodas can make weight loss/metabolic improvements harder.
    - Eliminating diet sodas entirely often improves outcomes.
- 4) Protein Products
  - Preference for non-caloric sweeteners in protein shakes/bars over added sugar:
    - Example: Sucralose-sweetened protein powder is preferable to sucrose-sweetened if the goal is protein without excess carbs/calories.

Analogy to Nicotine Products

- Just as there is a clear hierarchy of harm for nicotine delivery methods (cigarettes > vapes > pouches), there’s a harm spectrum for sweetened beverages:
  - Coke > Diet Coke > Sparkling water

Key Takeaways

- Think about purpose and context when choosing sugar substitutes.
- Gradually transition from sugar → artificial sweeteners → no added sweeteners where possible.
- Whole fruit is the gold standard for satisfying sweet cravings.
- Monitor quantity and frequency of diet beverage consumption; overuse can hinder metabolic goals.

---

## Selected Links / Related Material

**Previous AMA episode of The Drive about sugar and sugar substitutes**: [#141 – AMA #18: Deep dive: sugar and sugar substitutes](https://peterattiamd.com/ama18/) | Peter Attia (peterattiamd.com) [7:00]

**Protein bar Peter likes**: [David Bar](https://davidprotein.com/?srsltid=AfmBOoroeK4fi4wVtP5qVyL5f8b78O_nhHNPhORZctI9ODzNTIS9YVCj) | (davidprotein.com) [8:30]

**Episodes of The Drive with guests discussing the topic of sugar, calories, obesity, etc.**: [18:00]

- [#324 ‒ Metabolism, energy balance, and aging: How diet, calorie restriction, and macronutrients influence longevity and metabolic health | Eric Ravussin, Ph.D.](https://peterattiamd.com/ericravussin/) | Peter Attia (peterattiamd.com)
- [#167 – Gary Taubes: Bad science and challenging the conventional wisdom of obesity](https://peterattiamd.com/garytaubes/) | Peter Attia (peterattiamd.com)
- [#212 – The neuroscience of obesity | Stephan Guyenet, Ph.D.](https://peterattiamd.com/stephanguyenet/) | Peter Attia (peterattiamd.com)

**Episodes of The Drive with Rick Johnson where he discusses the impact of fructose on metabolism and disease risks**: [21:00]

- [#87 – Rick Johnson, M.D.: Metabolic Effects of Fructose](https://peterattiamd.com/rickjohnson/) | Peter Attia (peterattiamd.com)
- [#194 – How fructose drives metabolic disease | Rick Johnson, M.D.](https://peterattiamd.com/rickjohnson2/) | Peter Attia (peterattiamd.com)

**Fructose increases activity in neural circuits related to food motivation and responsivity, whereas glucose actually has the opposite effect**: [Brain, hormone and appetite responses to glucose versus fructose](https://www.sciencedirect.com/science/article/abs/pii/S2352154616300614) (Page and Melrose, 2016) [23:00]

**Episode of The Drive with Tadej Pogačar discussing how athletes are getting better and better at training their guts to take in more simple carbs to fuel performance:** [#318 ‒ Cycling phenom and Tour de France champion Tadej Pogačar reveals his training strategies, on-bike nutrition, and future aspirations](https://peterattiamd.com/tadejpogacar/) 28:15

**Episodes of The Drive with Olav Aleksander Bu discussing how athletes are getting better and better at training their guts to take in more simple carbs to fuel performance**: 28:15

- [#294 ‒ Peak athletic performance: How to measure it and how to train for it from the coach of the most elite athletes on earth | Olav Aleksander Bu](https://peterattiamd.com/olavaleksanderbu/)  | Peter Attia ([peterattiamd.com](https://peterattiamd.com))
- [#331 ‒ Optimizing endurance performance: metrics, nutrition, lactate, and more insights from elite performers | Olav Aleksander Bu (Pt. 2)](https://peterattiamd.com/olavaleksanderbu2/)  | Peter Attia (peterattiamd.com)

**When comparing sugar substitutes against sugar itself, most studies indicate neutral or very modestly beneficial effects on weight loss or prevention of weight gain**: [Substitution of sugar-sweetened beverages with non-caloric alternatives and weight change: A systematic review of randomized trials and meta-analysis](https://onlinelibrary.wiley.com/doi/full/10.1111/obr.13652) (Tobiassen and Køster-Rasmussen, 2023) [44:00]

**Most evidence to date comes from preclinical studies, which have shown that synthetic sweeteners (i.e., sucralose, saccharin, & aspartame) tend to reduce microbiome diversity (a marker of microbiome health) and promote the growth of more pathogenic bacterial species which are less efficacious at helping with glycemic control**: [Synthetic vs. non-synthetic sweeteners: their differential effects on gut microbiome diversity and function](https://www.frontiersin.org/journals/microbiology/articles/10.3389/fmicb.2025.1531131/full) (Kidangathazhe et al., 2025) [49:00]

**Study documenting the microbiome-altering effects of certain sugar substitutes and their impact on glycemic control**: [Personalized microbiome-driven effects of non-nutritive sweeteners on human glucose tolerance](https://www.cell.com/cell/fulltext/S0092-8674(22)00919-9) (Suez et al., 2022) [49:00]

**Allulose studies**: [57:15]

- *Some small RCTs show that allulose is also competing for SGLT1 in the kidney and leading to renal or kidney excretion of glucose suggesting that allulose not only is an effective sugar substitute, it is also the only one that provides the satiating benefit and it is also potentially one that can lower glucose levels*: [Allulose for the attenuation of postprandial blood glucose levels in healthy humans: A systematic review and meta-analysis](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0281150) (Tani et al., 2023)
- *Allulose shows potential benefits for both weight control and glycemic control, but human data is short-term*: [GLP-1 release and vagal afferent activation mediate the beneficial metabolic and chronotherapeutic effects of D-allulose](https://www.nature.com/articles/s41467-017-02488-y)
- *Every study to date shows net positive effects, even compared to*:
  - Pure water: [Rare Sugar Syrup Containing d-Allulose but Not High-Fructose Corn Syrup Maintains Glucose Tolerance and Insulin Sensitivity Partly via Hepatic Glucokinase Translocation in Wistar Rats](https://pubs.acs.org/doi/full/10.1021/acs.jafc.6b05627) (Shintani et al., 2017)
  - Stevia: [The Metabolic and Endocrine Effects of a 12-Week Allulose-Rich Diet](https://www.mdpi.com/2072-6643/16/12/1821) (Cayabyab et al., 2024)
- *A small crossover RCT study in diabetics with 20 subjects acting as their own control that also supported the idea that Allulose had positive effects on glycemic control beyond just being a replacement for sugar itself*: [A Pilot Study on the Efficacy of a Diabetic Diet Containing the Rare Sugar D-Allulose in Patients with Type 2 Diabetes Mellitus: A Prospective, Randomized, Single-Blind, Crossover Study](https://www.mdpi.com/2072-6643/15/12/2802) (Fukunaga et al., 2023)

**Compared to sugar, these newer alternatives may offer slight positive effects on weight maintenance, metabolism, and glycemic control**: [1:03:00]

- *Stevia derivatives*: [Effects of stevia, aspartame, and sucrose on food intake, satiety, and postprandial glucose and insulin levels](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2900484/) (Anton et al., 2010)
- *Monk fruit*: [Effects of a synbiotic yogurt using monk fruit extract as sweetener on glucose regulation and gut microbiota in rats with type 2 diabetes mellitus](https://www.sciencedirect.com/science/article/pii/S0022030220301302) (Ban et al., 2020)
- *Sugar alcohols*: [Suitability of sugar alcohols as antidiabetic supplements: A review](https://pmc.ncbi.nlm.nih.gov/articles/PMC9261844/) (Msomi et al., 2021)

**Xylitol has been shown to inhibit the growth of pathogenic bacteria that contribute to plaque buildup and gingivitis**: [Effect of xylitol on Porphyromonas gingivalis: A systematic review](https://onlinelibrary.wiley.com/doi/full/10.1002/cre2.724?utm_source=chatgpt.com) (Chen et al., 2023) [1:05:00]

**There is no credible evidence to suggest that common sugar substitutes increase the risk of cancer in humans at the doses that humans consume them**: [The Impact of Artificial Sweeteners on Human Health and Cancer Association: A Comprehensive Clinical Review](https://pmc.ncbi.nlm.nih.gov/articles/PMC10822749/?utm_source=chatgpt.com) (Ghusn et al., 2023) [1:07:30]

**The WHO named aspartame as a carcinogen**: [Aspartame hazard and risk assessment results released](https://www.who.int/news/item/14-07-2023-aspartame-hazard-and-risk-assessment-results-released) | (who.int) [1:08:30]

**Headlines suggesting sugar substitutes cause CVD are mostly fueled by these two papers**: [1:11:00]

- *Xylitol*: [Xylitol is prothrombotic and associated with cardiovascular risk](https://pubmed.ncbi.nlm.nih.gov/38842092/) (Witkowski et al., 2024)
- *Erythritol*: [The artificial sweetener erythritol and cardiovascular event risk](https://www.nature.com/articles/s41591-023-02223-9) (Witkowski et al., 2023)

**Peter’s newsletters that debunked the two papers linking sugar substitutes to CVD**: [1:11:00]

- [More hype than substance: erythritol and cardiovascular risk](https://peterattiamd.com/more-hype-than-substance-erythritol-and-cardiovascular-risk/) (March 2023) | Peter Attia (peterattiamd.com)
- [Does xylitol increase risk of cardiovascular disease?](https://peterattiamd.com/xylitol-and-cvd/) (June 2024) | Peter Attia (peterattiamd.com)

---

## People Mentioned

- [Magnus Carlsen](https://en.wikipedia.org/wiki/Magnus_Carlsen)
- [Eric Ravussin](https://www.pbrc.edu/research-and-faculty/faculty/Ravussin-Eric-PhD.aspx)
- [Gary Taubes](https://garytaubes.com/)
- [Stephan Guyenet](https://www.stephanguyenet.com/about-stephan-guyenet/)
- [Rick Johnson](https://som.cuanschutz.edu/Profiles/Faculty/Profile/9426)
- [Tadej Pogačar](https://en.wikipedia.org/wiki/Tadej_Poga%C4%8Dar)
- [Olav Aleksander Bu](https://www.instagram.com/olavaleksander/?hl=en)