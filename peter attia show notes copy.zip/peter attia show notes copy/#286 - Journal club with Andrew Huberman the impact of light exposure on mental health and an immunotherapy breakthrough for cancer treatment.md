# #286 ‒ Journal club with Andrew Huberman: the impact of light exposure on mental health and an immunotherapy breakthrough for cancer treatment

**Source:** [https://peterattiamd.com/andrewhuberman3/](https://peterattiamd.com/andrewhuberman3/)

---

Andrew Huberman, professor of neurobiology at Stanford University and host of the [Huberman Lab podcast](https://hubermanlab.com/), returns for another special journal club episode. Andrew introduces an observational study investigating the influence of light exposure on circadian clock regulation and its link to mental health, while Peter covers a phase III clinical trial employing immune checkpoint inhibitors for the treatment of metastatic cancer. They delve into the essential findings of their respective papers, elucidate the reasons for their enthusiasm, and tackle potential limitations and unanswered questions. Additionally, they provide valuable insights into their approaches for comprehending research studies, aiding listeners in independently navigating this process.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/andrewhuberman3/the_Drive_public.png)

Play

#286 ‒ Journal club with Andrew Huberman: the impact of light exposure on mental health and an immunotherapy breakthrough for cancer treatment

#286 ‒ Journal club with Andrew Huberman: the impact of light exposure on mental health and an immunotherapy breakthrough for cancer treatment

1x15s30s

0:002:46:19

## We discuss:

- The intricate relationship between light exposure, circadian rhythms, and mental health [3:30];
- The importance of low solar angle sunlight, and other types of light needed for optimal mental and physical health [12:00];
- Promising new lightbulb technology that simulates low solar angle sunlight [17:45];
- The significance of both darkness and the need for direct light exposure to the eyes, specifically [20:00];
- Some tips and advice regarding optimizing light exposure, dark exposure, blue blockers, and the effect on the circadian rhythm [22:15];
- Andrew presents a paper which suggests avoiding light at night and seeking light during the day is associated with better mental health [25:45];
- Examining the data: the negative impact of increasing nighttime light exposure and the positive effects of daytime light exposure [34:30];
- Statistical analysis: the importance of focusing not only on statistical significance but also clinical relevance, power analysis, error bar range, and more [45:45];
- Takeaways from the study of daytime and nighttime light exposure [49:45];
- The practicalities of minimizing light exposure and screen time at night, the use of sleep trackers, and overall challenge of modern, indoor lifestyles [55:15];
- Potential limitations of the light exposure study, reverse causality, and the complex interplay of variables in epidemiological studies [1:06:00];
- A tangent on diet soda and sugar substitutes as an example of reverse causality [1:13:15];
- Andrew and Peter’s take on the causality vs. correlation of light exposure to mental health, the damage of circadian disruption, and the interpretation of observational data [1:17:30];
- A primer on the immune system as background for the paper Peter chose [1:25:00];
- Background on cancer: causes, how it evades the immune system, and the logic behind immune checkpoint inhibitor therapy [1:35:45];
- Peter presents a paper on immune checkpoint inhibitor therapy in cancer patients [1:50:15];
- Unpacking the results of the checkpoint inhibitor trial [1:59:45];
- Other noteworthy observations including the differing results between males and females [2:15:30];
- Adverse effects resulting from treatment with an immune checkpoint inhibitor targeting CTLA-4 [2:20:00];
- Why melanoma is especially responsive to immunotherapy, and the remarkable success story of immunotherapy for pancreatic cancer [2:25:15];
- Why immunotherapy may be the most important hope we have for treating cancer [2:35:30];
- Avoiding melanoma: the sunscreen debate, sunburn as the biggest risk factor, and more [2:38:45]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Welcome to another special episode, this is a dual episode with Peter’s dear friend Andrew Huberman
- We will release this conversation on both the *Huberman Lab* podcast and *The Drive*
- In this episode, Peter and Andrew team-up again for another round of journal club
  - This is the second time they’ve done this
  - Their [first journal club](https://peterattiamd.com/andrewhuberman2/) together was released in September 2023
  - They enjoy this so much that Peter suspects they are going to continue this, potentially once a quarter
- In today’s journal club, we start by looking at a [paper](https://www.nature.com/articles/s44220-023-00135-8) that Andrew highlighted which looks at how light exposure and dark exposure can affect mental health
- After that, Peter presents a [paper](https://www.nejm.org/doi/full/10.1056/NEJMoa1003466) which is a landmark study on a class of drugs that he believes are some of the most relevant in cancer therapy over the past 20 years: the so-called “checkpoint inhibitors”
- The hope here is that not only does this conversation give you insights in these specific papers, but equally importantly, that you can learn something about how to read scientific papers
  - What to look for
  - What the papers say and what’s being reported, and how that doesn’t necessarily match what the news is telling you
    - That’s a common issue
    - Peter rails against this, where the media will comment on a paper and completely misrepresent it
- There’s really only one antidote to this: learning how to read the papers yourself
  - Unfortunately, there really is no other way to do this than practice
- We hope that people will sit with us and take a look at the papers before they watch/listen the podcast
  - [The [paper](https://www.nature.com/articles/s44220-023-00135-8) Andrew chose, and the [paper](https://www.nejm.org/doi/full/10.1056/NEJMoa1003466) Peter chose]
  - And try to get a sense of what they notice about these papers, what questions arise, and if Peter and Andrew touch on similar topics
- As a brief reminder, Andrew is an [associate professor of neurobiology and ophthalmology](https://med.stanford.edu/profiles/andrew-huberman#research-and-scholarship) at the Stanford University School of Medicine and the host of the very popular [*Huberman Lab*](https://hubermanlab.com/) podcast
  - He’s also a former podcast guest on episodes [#249](https://peterattiamd.com/andrewhuberman/) and [#270](https://peterattiamd.com/andrewhuberman2/)

## The intricate relationship between light exposure, circadian rhythms, and mental health [3:30]

- Andrew is excited about this journal club because he gets to pick papers he’s really excited about, and he gets to hear about papers Peter is really excited about
  - They get to sharpen their skills at reading and sharing data, and people listening can do that as well
- Andrew is excited about this [paper](https://www.nature.com/articles/s44220-023-00135-8) for a number of reasons
  - It’s powerful in the sense that it examined light exposure behavior as well as dark exposure behavior
  - This was a study of >85,000 people as part of a cohort in the [UK Biobank](https://www.ukbiobank.ac.uk/)

*There’s a longstanding interest in the relationship between light and mental health and physical health, and we can throw up some very well agreed upon bullet points*

- 1 – There is such a thing as [**seasonal affective disorder**](https://en.wikipedia.org/wiki/Seasonal_affective_disorder)
  - It doesn’t just impact people living at really northern locations, but basically there’s a correlation between day length and mood and mental health such that for many people (not all) when days are longer in the spring and summer, they feel better, and they report fewer depressive symptoms
  - Conversely, when days are shorter, significantly more people report feeling lower mood and affect
  - There’s a longstanding treatment for seasonal affective disorder, which is to give people exposure to very bright light, especially in the morning
    - That’s normally accomplished with [SAD lamps (seasonal affective disorder lamps)](https://en.wikipedia.org/wiki/Light_therapy), and those lamps are basically bright (more than 10,000 [lux](https://en.wikipedia.org/wiki/Lux) lights)
    - They place on their kitchen counter or at their table in the morning or in their office so they’re getting a lot of bright light
    - That has proven to be fairly effective for the treatment of seasonal affective disorder
- What’s less understood is how *light exposure in the middle of the night* can negatively impact mood and health

***Where we are headed with this is that there seems to be (based on the conclusions of this new study) a powerful and independent role of both daytime light exposure and nighttime dark exposure for mental health***

- 2 – The **biological mechanisms** for all this are really well established
  - There’s a set of cells in the neural retina which lines the back of your eye
    - They’re sometimes called intrinsically photosensitive
    - [Retinal ganglion cells](https://en.wikipedia.org/wiki/Retinal_ganglion_cell) are sometimes called melanopsin retinal ganglion cells
  - It’s well known that those cells are the ones that respond to two different types of light input (not one, but two different types of light input) and send information to the [hypothalamus](https://en.wikipedia.org/wiki/Hypothalamus) where your master [circadian clock](https://en.wikipedia.org/wiki/Circadian_clock) resides
  - Then your master circadian clock sends out secretory signals (so peptides, hormones, but also neural signals) to the brain and body and say, “*Hey, now it’s daytime, now it’s nighttime, be awake, be asleep.*”
  - But it goes way beyond that
  - These melanopsin intrinsically photosensitive retinal ganglion cells also project to areas of the brain like the [habenula](https://en.wikipedia.org/wiki/Habenula), which can trigger negative affect, negative mood
    - They can trigger the release of [dopamine](https://en.wikipedia.org/wiki/Dopamine) or the suppression of dopamine, the release of [serotonin](https://en.wikipedia.org/wiki/Serotonin), the suppression of serotonin, and so they’re not just cells for setting your circadian clock
    - They also have a direct line (literally one synapse away) into the structures of the brain that we know powerfully control mood
    - The mechanistic basis for all this is there
- There’s just a couple of other key points to understand for people to really be able to digest the data in this paper fully
- 3 – There are basically **two types of stimuli that these cells respond to**
  - #1 is very bright light, as we just talked about
    - That’s why getting a lot of daytime sunlight is correlated with elevated mood
    - That’s why looking at a 10,000 lux artificial lamp can offset seasonal affective disorder

Peter asks, “*How many lux does the sun provide on a sunny day at noon?*”

- On a **really bright day** with minimal cloud cover, it could be 300,000 lux
- Most indoor environments [are dim], even though they might seem very bright, a department store with the bright lights, is probably only closer to 6,000 lux maximum and probably more like 4,000 lux

***Most brightly lit indoor environments are not that bright when it comes down to total photon energy***

- On a **cloudy day** when you’re outside, it can be as bright as an average of 100,000 lux, but it won’t seem bright because you don’t see the sun
  - Also, when there’s cloud cover, a lot of those long wavelengths of light (such as orange and red light) aren’t coming through
- 4 – The circadian clock (the [suprachiasmatic nucleus](https://en.wikipedia.org/wiki/Suprachiasmatic_nucleus)), it sums photons
  - “*It’s a photon summing system*”
  - If you’re outside in 8,000 lux, a very overcast UK winter day, and you’re walking around (hopefully without sunglasses because sunglasses are going to filter a lot of those photons out), your circadian clock is summing the photons
  - It’s an integration mechanism; it’s not triggered in a moment
- The experiments of recording from these cells (first done by [David Berson](https://vivo.brown.edu/display/dberson) at Brown) were historic in the field of visual neuroscience
  - When shown bright light on these intrinsically photosensitive cells, you could crank up the intensity of the light and the neurons would ramp up their membrane potential and then start spiking firing action potentials
  - Long trains of action potentials that have been shown to go on for hours
    - “*That’s the signal that’s propagating into the whole brain and body*”

***The important thing to understand is this is not a quick switch, and that’s why Andrew suggests on non-cloudy days, that people get 10 minutes or so of sunlight in their eyes in the early part of the day, another 10 minimum in the later part of the day***

- He recommends people get as much sunlight in their eyes as they safely can throughout the day
- The key time for people to get sunlight in their eyes is when the sun is low in the sky (low solar angle sunlight), and Andrew will explain more about this later
  - Since Peter is a physician, he had a [guest](https://peterattiamd.com/stevendell/) on talking about this recently
  - When the sun is low in the sky, you run very, very little risk of inducing cataract by looking in the general direction of the sun, you should still blink as needed to protect the eyes
  - It’s when the sun is overhead, there’s all those photons coming in quickly in a short period of time that you do have to be concerned about cataract and macular degeneration if you’re getting too much daytime sunlight
  - The idea is sunglasses in the middle of the day are fine, but you really should avoid using them in the early and later part of the day
    - Unless you’re driving into the sun for safety reasons

Peter asks, “*If a person is indoors, but they have large windows, they’re getting tons of sunlight into their space, and they don’t even need ambient indoor light. How much of the photons are making it through the glass and how does that compare to this effect?*”

***In general, unless the light is coming directly through the window, most of the relevant wavelengths are filtered out***

- In other words, if you can’t see the sun through the window, even if sufficient light is being provided, that’s *insufficient* to trigger this phenomenon
- However, if you have windows on your roof (skylights), that makes the situation much better
- The neurons in the eye that signal to the circadian clock and these mood centers in the brain reside mainly in the bottom two thirds of the neural retina and are responsible for looking up
  - Basically, they’re gathering light from above
  - These cells are also very low resolution
    - Think of them as big pixels
    - They’re not interested in patterns and edges and movement
    - They’re interested in how much ambient light there happens to be
- Keep in mind that this mechanism is perhaps the most well conserved mechanism in cellular organisms

## The importance of low solar angle sunlight, and other types of light needed for optimal mental and physical health [12:00]

- Types of light that one needs to see every 24 hours for optimal health
  - By optimal health, he really means mental health and physical health, but we’re going to talk about mental health mainly today in this paper

**Why exposure to low solar angle sunlight (at sunrise and in the evening) is important**

*Evolutionary conservation of a system to recognize the wavelengths of light present early in the day and in the evening*

- There’s a beautiful evolutionary story whereby single cell organisms all the way to humans, dogs, rabbits, and everything in between have at least 2 [cone opsins](https://en.wikipedia.org/wiki/Vertebrate_visual_opsin#Cone_opsins): one that responds to **short wavelength light** (AKA blue light), and another one that responds to **longer wavelength light** (orange and red)
  - Your dogs have this, and we have this
  - It’s a comparison mechanism in these cells of the eye
  - These neurons of the eye, they compare contrast between blues and orange or sometimes blues, and reds, and pinks (which are also all long wavelength light)
- There are two times a day when the sky is enriched with blues, oranges, pinks, and reds, and that’s low solar angle sunlight at sunrise and in the evening

***These cells are uniquely available to trigger the existence of those wavelengths of light early in the day and in the evening, not in the middle of the day***

- These cells have these two cone photopigments and they say, “H*ow much blue light is there? How much red light is there or orange light?*”
- The subtraction between those two triggers the signal for them to fire the signal off to the circadian clock of the brain

> “*That’s why I say, look at low solar angle sunlight early in the day*.”‒ Andrew Huberman

**Role in determining circadian rhythm**

- What that does is it **“phase advances” the clock**
  - This can get a little technical, and we don’t want to get too technical here
  - Think about pushing your kid on a swing
    - The the duration of that swing is a little bit longer than 12 hours
    - When you stand closer to the kid, so your kid swings back and you give it a push, you’re shortening the period; you’re not allowing the swing to come all the way up
    - That’s what happens when you look at morning sunlight: you’re advancing your circadian clock
  - Translated to English (or non-nerd speak): you’re making it such that you will want to go to bed a little bit earlier and wake up a little bit earlier the next day
- In the evening, when you view low solar angle sunlight, the afternoon setting sun or evening setting sun, you do the exact opposite: you’re **“phase delaying” the clock**
  - It’s the equivalent of your kid being at the very top of the arc
  - Let’s say 12 and a half hours is the duration of that swing, and you run up and you push them from behind and give them a little more push
    - That’s the equivalent of making yourself stay up a little later and wake up a little later

***These two signals average so that your clock stays stable, you don’t drift, meaning you’re not waking up earlier every single day or going to sleep later every single day; and this is why it’s important to view low angle sunlight in the morning and again in the evening as often as possible***

- This is done by that readout of those two photopigments

**Midday sun is different**

- It’s bright light, but you see it as white light
- It contains all of those wavelengths that equal intensity
- The middle of the day is the so-called **“circadian dead zone”**
- In the middle of the day, bright light triggers the activation of the other opsin (the [melanopsin](https://en.wikipedia.org/wiki/Melanopsin)) which increases mood, increases feelings of wellbeing, and has some other consequences
- But you can’t shift your circadian clock by viewing the sun in the middle of the day because it’s in the circadian dead zone
  - It’s the equivalent of pushing your kid on the swing when they’re at the bottom of the arc
    - You can get a little bit more but not much
    - In biological terms, you get nothing

***This is why looking at sunlight in the middle of the day is great, but it’s not going to help anchor your sleep wake cycle***

**This is incredible, right?**

- Every organism from single cells to us has this mechanism to know when the sun is rising and when the sun is setting
- It’s a color comparison mechanism which tells us that actually **color vision** evolved first, not for pattern vision, not for seeing beautiful sunsets and recognizing that’s beautiful or paintings or things of that sort, but rather for setting the circadian clock

Peter asks, “*What if you only do one of these? What if you get constant exposure to low morning light, but your job prevents you from doing the same in the evening (or visa versa)?*”

- It’s better to get the morning light, because if you have to pick between low solar angle light earlier or later in the day…
  - Keep in mind if you miss a day, no big deal
  - It’s a slow integrative mechanism averaging across the previous two or three days
  - But if you miss a day, you’ll want to get twice as much light in your eyes that next morning
  - The reason it’s better to do in the **morning** as opposed to the evening (although best would be to do both) is that most people are getting some artificial light exposure in the evening anyway
- Here’s the diabolical thing: your retina is very *insensitive* to light early in the day
  - You need a lot of photons to trigger this mechanism early in the day
  - As the day goes on, retinal sensitivity increases and it takes very little light to shift your circadian clock late in the day
- There’s a beautiful [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6831674/) published in *Science Reports* two years ago showing you can partially offset the negative effects of artificial light exposure at night
  - Think of this as your Netflix inoculation
  - ***The amount of*** [***melatonin***](https://en.wikipedia.org/wiki/Melatonin) ***suppression from nighttime light exposure is halved by viewing evening setting sun***
    - Keep in mind, you don’t need to see the sun cross the horizon; it can just be when it’s low solar angle
    - You’re looking for those yellow blue or blue pink, blue red contrast
    - And on cloudy days, believe it or not, they’re still there, just you don’t perceive as much of it coming through

***Andrew explains 3 things that we should all strive to do:***

- (1) view low solar angle sunlight early in the day,
- (2) view solar angle sunlight later in the day, and
- (3) get as much bright light in our eyes as we safely can, ideally from sunlight throughout the day

## Promising new lightbulb technology that simulates low solar angle sunlight [17:45]

**If you can’t do that, perhaps invest in one of these** [**SAD lights**](https://en.wikipedia.org/wiki/Light_therapy)

- They can be a bit expensive
- There are a couple of companies that are starting to design sunrise simulators and evening simulators that are actually good, that actually work
- A company that Andrew has no relationship to called the [TUO](https://www.thetuolife.com/) sells a lightbulb that was developed by the biologist at the University of Washington
  - The biologist who basically discovered these color opponent mechanisms
  - Those lights are not particularly expensive, but they do seem to work.
- Unpublished data seems to indicate that if you look at it for more than 5-6 minutes, it can induce a mild euphoria
  - That’s how powerful this contrast is

**More about the TUO lightbulb**

- What they did there in that light is they figured out that when most people look at **low solar angle sunlight in the morning**, they’re getting 19 reversals of blue orange per second
  - When you look at this light, it looks like a barely flashing white light, but it’s reversals of orange and blue, orange and red and blue, and it’s happening very fast
- Andrew has used one of these, it just looks like a flickering light
- Of course, there’s always the potential of a placebo effect

Peter asks, “*Is there a way to control for that by having something that looks the same to the user, but of course is not producing the same photo effect?*”

- They’ve done that with the 10,000 lux SAD lamps, which most people use to try and induce sunrise simulation in their home
  - But keep in mind that sunrise gives you this comparison of short and long wavelength light
  - ***Just a bright 10,000 lux light triggers one of the options, but it won’t set your circadian clock***

***Most of the SAD lamps that are out there are activating only one of the mechanisms in these cells that’s relevant and not the one that’s most relevant***

- Andrew is excited about what TUO is doing
  - He has no relation to them except he knows the biologists who do the work that provide the mechanistic logic for that engineering

> “*I still think we’re in the really early days of this stuff. What should be done is to have this stuff built into your laptop. It should be built into your phone, and hopefully it will be*.”‒ Andrew Huberman

## The significance of both darkness and the need for direct light exposure to the eyes, specifically [20:00]

- Andrew mentioned the color contrast thing in sunrise and sunset, and bright light throughout the day [3 important light signals]
- There is a **4th light stimulus** that turns out to be really important: **dark exposure at night** (independent of light exposure during the day) is important for mental health outcomes
  - Aka the *absence* of light at night

***This paper really drives home the importance of dark exposure at night even if people are not getting enough sunlight during the day***

- This is especially true in the context of mental health
- Some people seem more resilient to these light effects than others
  - Meaning some people also don’t suffer from jet lag too much
  - Some people can stay up late, get a lot of bright light exposure in the middle of the night and during the day, they’ve got their sunglasses on all day and they’re in a great mood all the time
  - Other people are more susceptible to these sorts of things, and we don’t know whether or not polymorphisms underlie that
- Andrew personally is very sensitive to sunlight in the sense that if he doesn’t get enough sunlight, he doesn’t feel well after a couple of days
- But he’s less sensitive to light exposure at night, for instance.

***It is perhaps the most fundamental environmental stimulus for levels of arousal and alertness, which correlate with all sorts of neuromodulator and hormone outputs***

- None of this should come as any surprise

**One last thing**

- There was a [study](https://www.science.org/doi/10.1126/science.1071697) published over 10 years ago from [Chuck Czeisler’s](https://connects.catalyst.harvard.edu/Profiles/display/Person/24237) lab at Harvard Medical School, it’s a phenomenal lab, exploring circadian human health behavior
  - There was a study that was in error where they had published in *Science Magazine*, that light shone behind the knee could shift circadian rhythms, and that paper was retracted, and a lot of people don’t know that it was retracted [discussed further in this [news article](https://www.science.org/doi/10.1126/science.297.5581.505)]

***Light exposure to the eyes is what’s relevant here***

- As far as we know the color of one’s eyes, the darkness or lightness of one’s eyes bears no relevance on their sensitivity to these types of mechanisms

## Some tips and advice regarding optimizing light exposure, dark exposure, blue blockers, and the effect on the circadian rhythm [22:15]

**Going back to the morning/ evening light**

- Peter spends  a lot of time looking at those types of skies just because of the nature of his hobbies
  - He’s always doing archery in the morning and rucking in the afternoon
- So it’s not uncommon that he’s seeing both of those

Peter asks, “*How relevant is it that the sun be above the horizon?*”

- For example, it begins to get light about 30 minutes before sunrise
  - If sunrise is at 7:30, first light is 7:00, and then 7:15 to 7:30 is actually quite bright
    - You can see anything and everything, and the same is true at sunset

Peter asks, “*Does that 30 minutes when the sun is beneath the horizon constitute part of that 10 minutes?*”

- It does
- In an ideal circumstance, you’d get outside and see the sunrise every day and you’d see the sunset every day, even on cloudy days
- Some people (like Andrew) wake up before the sun comes up

***In the absence of powers to make the sunrise faster, Andrew thinks the best thing to do is simply to turn on as many bright lights as you can indoors to trigger that melanopsin mechanism if you want to be awake***

- If you want to stay asleep or sleepy, then keep them dim
- Then get outside once the sun is starting to come out
  - Some people wake up after the sun has risen, in which case get what you can
- Some people wake up 10:00 AM or noon, in which case you can still get the bright light exposure, but you won’t shift your circadian clock

**Andrew’s advice**

- In the evening, especially in the winter months, it’s important to look west and try and get some sunlight in your eyes in the evening
- If you’ve ever gone into the clinic, for instance, at two o’clock in the afternoon after lunch in the winter and then come out and it’s dark when you’re walking to your car, it’s an eerie feeling
  - That eerie feeling may correlate with the fact that you missed a signal
- Your brain is trying to orient your brain and body in time, and that’s what all of this is
- Again, some people are more susceptible to that than others
  - Some people might like that feeling of, “*Oh, I went in when it was bright and I came out when it’s dark*.”
  - But the vast majority of people feel better when they’re getting this morning and evening sunlight exposure
- This is especially important in kids

***One of the things that this paper points out (and there are good data): people are spending approximately 90% of their time indoors nowadays, daytime time indoors, and those indoor environments are simply not bright enough***

**Andrew’s thoughts about blue light and light at night**

- You may think indoor lights are bright, and some people are putting blue blockers on in the middle of the day
  - This is the worst thing you could possibly do if you’re going to wear blue blockers
  - Andrew doesn’t think they’re necessary, but if you’re going to wear them, you’d want to wear them at night
- In the evening, you *don’t* need to wear blue blockers
  - You just simply should dim the lights and ideally have lights that are set a little bit lower in your environment, which the Scandinavians have been doing for a long time
  - Kill the overhead lights and don’t obsess about bright light exposure in the middle of the night
- For a long time people were saying (Andrew included), “*Oh, even just a brief flash of light in the middle of the night can quash your melatonin.*”
  - That’s true
  - But the other time in which you’re in this “Circadian dead zone,” is in the middle of the night
    - You can’t shift your circadian clock in the middle of the night
- All of this gets down to interweaving rhythms of light sensitivity, temperature, hormone output, cortisol ‒ there’s a whole landscape of circadian biology

## Andrew presents a paper which suggests avoiding light at night and seeking light during the day is associated with better mental health [25:45]

- This [paper](https://www.nature.com/articles/s44220-023-00135-8), which was published in a new journal Andrew is really excited about called *Nature Mental Health*, this journal was just launched recently, is entitled “Day and Night Light Exposure Are Associated with Psychiatric Disorders in Objective Light Study in More Than 85,000 People”
- Andrew thinks the title of this paper is terrible
  - It sounds like day and night light exposure is associated with psychiatric disorders, but that’s *not* the conclusion
- The **conclusion** is that getting a lot of sunlight exposure during the day and getting a lot of dark exposure at night is immensely beneficial for psychiatric health in a number of ways

**Previous to this study**

- This paper built off a previous study entitled “[Time Spent in Outdoor Light is Associated with Mood, Sleep and Circadian Rhythm Related Outcomes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8892387/)”
  - That was a cross-sectional longitudinal study in 400,000 Biobank participants
- This [UK Biobank](https://www.ukbiobank.ac.uk/) is an incredibly valuable resource

***There are now multiple studies establishing that one’s pattern of light exposure is extremely important***

- The previous study of 400,000 participants basically nailed home the idea that the more time you spend outdoors, the better is your mood, the better is your sleep, the better is the rhythmicity of your sleep wake cycles and on and on
- This is something that Andrew thinks even though people will say, “*We’ve known that for thousands of years*,” needed scientific substantiation

**Contributions of this new study**

- This new study essentially looked at the relative contributions of daytime light exposure and nighttime dark exposure
- They did that on a background looking in particular at people who had major depressive disorder, generalized anxiety, PTSD, bipolar disorder

**The basic takeaway**

- Andrew quotes them here, “*Avoiding night at light and seeking light during the day. May be a simple and effective non-pharmacologic means for broadly improving mental health*.”
- That’s a pretty bold statement, and Andrew loves that they say seeking because it implies that people aren’t reflexively getting the light exposure that they need
  - That this needs to be a practice, much like zone 2 cardio or resistance training

**What did they do in this study?**

- They gathered up a hundred thousand people or so
  - It eventually was paired down to about 86,000 participants because some just didn’t qualify or didn’t report their data back
- They equipped them with accelerometers on their wrists, and those wrist devices also could measure ambient light
- Caveat: that’s not a perfect tool, because what you’d love to do is measure ambient light at the level of the eyes
  - If it’s at the level of the eyes, then that’s what’s landing at the eyes
- Andrew adds a tangent, “*Will somebody design an eyeglass frame that changes color when you’ve gotten sufficient light from sunlight during the day and then at night is a different color?*”
  - Then if you’re getting too much light exposure, we’ll go to a different color frame
  - This has to be possible so that you don’t have to wonder if you’ve got enough light during the day

Peter asks, *“Do these wrist based devices potentially get covered by clothing in some place?”*

- Yeah, they had it on the outside of the sleeve, but they asked that people just keep it on their dominant hand
- It’s not perfect, but in some ways it’s nice that it’s not perfect
  - We could turn that disadvantage into an advantage by thinking when the person is out and about, they’re not often looking right at the sun
    - If you’re talking to a colleague under an overhang, for instance
- It’s directionally

**The hypothesis of this study**

- They had 2 primary hypotheses
- 1 – Greater light exposure in the day is associated with lower risk for psychiatric disorders
- 2 – Greater light exposure at night is associated with higher risk for psychiatric disorders and poorer mood

> “*This is, oh, so relevant for the way we live now. People on screens and tablets in the middle of the night*.”‒ Andrew Huberman

- Then they collected information about how much light exposure people were getting, as well as their sleep and their activity and so on

**About the people in this study**

- This was done in males and females
- It was a slightly older cohort than one is used to seeing, people in their 50s and 60s
- They had psychiatric diagnosis information
- They divided people into essentially two groups [Q1 + Q2 and Q3 + Q4]
- 1 – The Q1 and a Q2 (a lower quartile) were people that were getting less daytime light
- 2 – As opposed to the Q3 and Q4 who got more daytime light
- They also had a nighttime light exposure evaluation, and they had people in the low Q1 and Q2
  - So these people are getting less nighttime light versus Q3, Q4 (who got more nighttime light)
- Nicely, they also looked at sleep duration
- They looked at photo period, meaning how long the days were for those individuals, how active they were
  - Look, 10 hours a day, 14 hours a day, because the more active you are, the more opportunity for light exposure you have during the day or night, for instance
- They had fairly complete data sets then

Peter asks, “*Sleep duration, sleep efficiency, etc. was determined off the accelerometer?*”

- That’s right, as well as self-report
  - Not ideal, right?
- You’d love for people to be wearing a [WHOOP band](https://www.whoop.com/us/en/) or a [ring](https://ouraring.com/) or something of that sort, but this was initiated some time ago
  - They either didn’t have access to that technology or for whatever reason, didn’t select it

**To hit the top contour of what they did**

- What they did is they have information on who has major depressive disorder, who has PTSD, generalized anxiety, bipolar, psychosis, etc., and then they ran three models
- Andrew adds, “*You can tell me what you think about the power of these models, but as somebody who thinks about the mechanistic aspect of all of this a lot, but not somebody who’s ever run this type of study, I’d be really curious.*”

*Model 1*

- Model 1 examined the unadjusted association between day and nighttime light exposure and psychiatric outcomes
- Basically asking, “*Is there a relationship between how much light you get during the day and how much light you get at night and how bad your depression is or anxiety is?*”
- Looking at just a standard ratio of the probability that you have a certain symptom or set of symptoms versus you don’t given a certain amount of light exposure

*Model 2*

- Model 2 adjusted for the age of the person, their sex, and ethnicity, and photo periods
- They looked at how long the days were in that given person’s region of the world

Peter asks, “*These people were all in the UK or were they around the world?*”

- They were all in the UK

*Model 3*

- Then model 3 adjusted for employment: so employed versus unemployed
  - If you think about it, it’s pretty important.
    - An unemployed person has a lot more time to control these variables, but an employed person who’s doing shift work does not
- They incorporated information about employed versus unemployed physical activity, which turns out to be very important
- Then things like shift work, etc.

**Andrew’s takeaway about these models**

- We can say very safely the outcomes with each of these models, the results were very similar
- We don’t want to discard the differences between those models entirely
- But his read is in every figure of the paper, it doesn’t seem like model 1, 2, or 3 differ from one another in terms of total outcome

*Peter’s thoughts*

- That’s an unusual aspect of this paper
- These adjustments are very standard
- This is a classic tool that’s used in most epidemiology because you don’t have randomization
  - In an RCT there will be no models; it’s just, “*Here are the data.*”
- Andrew clarifies: no one was assigned to any groups or swap; there are not any controls
  - It’s just comparisons between groups

***Peter thinks it’s very unusual that there’s no difference between the unadjusted and the adjusted models***

- There’s probably two places out of 30 when you look at all the different quartile comparisons where you might creep from statistically significant just out of it or just into it
- You could simplify this figure two completely [shown below] by just showing one of the models and you would be getting 95% of the information

**Peter’s takeaway‒** ***that suggests that there’s less dependency on those variables***

- It still doesn’t address probably the greatest question Peter has here (which we’ll get to)

## Examining the data: the negative impact of increasing nighttime light exposure and the positive effects of daytime light exposure [34:30]

![](https://peterattiamd.com/wp-content/uploads/2024/01/f1-huberman3.png)

**Figure 1 (Figure 2 in the** [**paper**](https://www.nature.com/articles/s44220-023-00135-8)**). Associations of day and night-time light exposure with psychiatric disorders and self-harm**. Image credit: [*Nature Mental Health* 2023](https://www.nature.com/articles/s44220-023-00135-8)

- Andrew explains, what they’re looking at is what they call the **odds ratio,** which is the probability of something happening in one group divided by the probability of something happening in another group
  - An example would be if you’re going to look at the odds ratio of the probability of somebody getting lung cancer if they smoke, versus probability of somebody getting lung cancer if they don’t smoke

**What an odds ratio means**

- Peter adds, “*Odds ratios and hazard ratios are often confused. They’re very similar, and odds ratios generally refer to a lifetime exposure, whereas a hazard ratio is defined over a specific period of time, but the math is still effectively the same.*”
- Using the smoking example, if you took the odds ratio of death (let’s talk all-cause mortality for a smoker versus a non-smoker), and the answer was 1.78
  - Peter is making this up as an example, but that’s directionally correct
  - A 1.78 odds ratio, means there’s a 78% chance greater of the outcome of interest
    - In this case, death by any cause in the affected group, which would be the smokers
- So an odds ratio of 2 is 100% and an odds ratio of 3 is 200%
  - The math is take the number, subtract one, and that’s the percent

**Figure two of this paper is one of the key take homes**

- Look at the odds ratio of people who have **nighttime light exposure**
- The X-axis is showing the 2nd, 3rd, and 4th quartiles
  - Meaning they’re all being compared to the 1st quartile [lowest light exposure]
- “Panel a” is major depressive disorder if you are in the 2nd quartile, 3rd quartile, or 4th quartile of nighttime light exposure
  - 2nd being the least amount of nighttime light exposure, 3rd being more nighttime light exposure, and 4th being the most nighttime light exposure relative to the 1st quartile

**Peter points out about figure 2**

- If he was going over this figure in a lecture, it would make it easy to draw arrows on it that say increasing light exposure at night, and decreasing light exposure in the day [shown in the figure below]
  - It’s the same information, it just makes it easier for the reader to understand

![](https://peterattiamd.com/wp-content/uploads/2024/01/f2-huberman3.png)

**Figure 2. Annotated figure 2a indicating increased risk.** Adapted from: [*Nature Mental Health* 2023](https://www.nature.com/articles/s44220-023-00135-8)

**A teaching point for reviewing articles**

- Don’t be afraid to do that (scribble all over it)
- Andrew thinks one thing that scientific journals really, really need to do is start making the readability of the articles better for non-experts
- Chances are, if you can’t understand a graph (and this is true for everybody), chances are there’s a problem with the way it’s presented.
- Rarely, if ever, is it all spelled out clearly, but that’s what we’re trying to do here

**The way Andrew would have done figure 2a**

- Say that the 2nd quartile is low amounts of nighttime light exposure and define what that is
- 3rd quartile is more light exposure
- Then 4th quartile is maximum amount of light exposure at night
- And basically, what you see is that **the probability of having worse major depressive symptoms linearly increases** as you go from the second to third to fourth quartile

***Takeaway‒ more nighttime light exposure is worse for you, and there’s a dose response of the effect***

**The same thing is true for the other panels of figure 2**

![](https://peterattiamd.com/wp-content/uploads/2024/01/f3-huberman3.png)

**Figure 3. Effects of light exposure for generalized anxiety disorder (GAD) and bipolar disorder (figure 2c & 2e)** Image credit: [*Nature Mental Health* 2023](https://www.nature.com/articles/s44220-023-00135-8)

- Panel c shows nighttime light exposure for generalized anxiety disorder
- Panel e shows bipolar disorder
  - Although the difference between the 2nd and 3rd quartile in bipolar disorder isn’t as traumatic
  - Andrew explains, “*Once you get up to the 4th quartile, bipolar symptoms get much worse when people are getting nighttime light exposure. I really want to emphasize that point because they go on in the discussion of this paper to reemphasize that point several times.*”

***For people with bipolar disorder, it seems that light exposure at night is especially problematic independent of how much sunlight they’re getting during the day***

- The person with bipolar disorder who’s struggling with either a manic or a depressive episode, who’s making a point to get sunlight during the day, who’s also getting ***light exposure at night is making their symptoms worse***
  - Keep in mind they couldn’t completely control this, but this is largely independent of things like sleep duration
    - So that doesn’t necessarily mean that the person’s sleeping less, although in a manic episode, presumably they are
  - It’s independent of exercise, it’s independent of a bunch of other things because any logical person will hear this and say, okay, well, they gain more light at night because they’re doing a bunch of other things, but it’s largely independent of those other things

**PTSD**

![](https://peterattiamd.com/wp-content/uploads/2024/01/f4-huberman3.png)

**Figure 4. Effects of light exposure for PTSD (figure 2d)** Image credit: [*Nature Mental Health* 2023](https://www.nature.com/articles/s44220-023-00135-8)

- Likewise, the symptomatology of PTSD gets far worse with increasing light exposure at night
- Self-harm really takes a leap from being fairly medium at the 2nd and 3rd quartiles of artificial light exposure at night
- Then for people who get quite a lot of nighttime light exposure, self-harm goes up, the probability of psychotic symptoms

**The positive effects of daytime light exposure [40:15]**

*What’s nice about the data is that the exact inverse is basically true for daytime light exposure [as compared to nighttime light exposure], although not across the board*

- We can generally say that for major depressive disorder, generalized anxiety, and bipolar symptoms it’s a little more scattered
- With PTSD and self-harm, the more daytime light exposure (ideally from sunlight because that’s actually what’s being measured in most cases) is going to approximately linearly drop the probability or the severity of these symptoms
- Peter adds that the odds ratio now seems to be going down and explains, “*An odds ratio of 0.7 now refers to a 30% reduction in the variable of interest here*.”

**Panel f focuses on psychosis and is worth mentioning in a bit more detail**

![](https://peterattiamd.com/wp-content/uploads/2024/01/f5-huberman3.png)

**Figure 5. Psychosis odds ratio according to light exposure (figure 2f)**. Image credit: [*Nature Mental Health* 2023](https://www.nature.com/articles/s44220-023-00135-8)

- There’s a fairly dramatic reduction in psychotic symptoms as one gets more daytime light exposure independent of nighttime light exposure

**There’s a well-known phenomenon called ICU psychosis**

- Which is that people come into the hospital for a broken leg or a car accident
- They’re housed in the hospital, and the lighting environment in the hospital is absolutely dreadful for health (it’s absolutely counter to health)
  - Peter adds, “*Especially in the intensive care unit. I think the intensive care unit at Hopkins, the main one, the main SICU didn’t have windows.*”
- Andrew advises for people who go into the hospital with a brain injury or with a stroke or something that they get near a window and start controlling their **sleep-wake cycle**
  - Oftentimes, there’s nurses coming in and taking blood tests and measuring pulses in the middle of the night, and that’s disruptive
    - There’s bright light, not just blue light, and it’s noisy

***ICU psychosis is when anti-psychotic individuals start having psychotic episodes in the hospital because of nighttime light exposure, and in some cases, lack of daytime sunlight***

- We can say that with some degree of confidence because when those people go home, even though sometimes their symptoms for what brought them to the hospital in the first place get worse, *their psychosis goes away* and it’s independent of medication

**Andrew explains**

- There is a possibility that we are all socially jet-lagged, that we are all disrupting these mood regulation systems by not getting enough daytime light and by getting too much nighttime light

**What Peter finds interesting in figure 2b**

![](https://peterattiamd.com/wp-content/uploads/2024/01/f6-huberman3.png)

**Figure 6. Self-harm behavior according to light exposure (figure 2b)**. Image credit: [*Nature Mental Health* 2023](https://www.nature.com/articles/s44220-023-00135-8)

- Peter points out, “*There are a few that really stand out*.”
- The correlation to depression is very strong
- The relationship to light and self-harm in the upper quartile is interesting
  - So when you take those 25% of people with the most nighttime light, that relationship to self-harm is interesting and completely uncoupled from the other 75%

Andrew asks, “*By uncoupled, you mean that at the lower levels of light exposure at night, you’re not seeing an increase in self-harm.*”

- Not whatsoever
- Then once you get to that 4th quartile, it’s a big step: a 30% greater risk of self-harm
- The 1st, 2nd, and 3rd quartiles are totally flat (there’s no difference), then you get a big jump at the 4th quartile (an inverse relationship)

***As light increases during the daytime, you see this reduction in self-harm***

- Interestingly, the PTSD relationship based on nighttime light and the psychosis relationship based on daytime light, those are the ones that really jumped out to Peter
- Anxiety is relatively less impressive here, and bipolar disorder didn’t seem as strong as well [shown below]

![](https://peterattiamd.com/wp-content/uploads/2024/01/f7-huberman3.png)

**Figure 7. Anxiety and bipolar disorder according to light exposure (figure 2c & 2e)**. Image credit: [*Nature Mental Health* 2023](https://www.nature.com/articles/s44220-023-00135-8)

- Andrew agrees, there’s a bit more scatter on generalized anxiety and the degree of significant change is not as robust
  - In other words, getting a lot of daytime light, ideally from sunlight, is not necessarily going to reduce your levels of anxiety
  - Getting a lot of nighttime light exposure is not increasing nighttime anxiety that much, although 20% is not nothing for nighttime light exposure
- The [results for] psychosis, major depression, and self-harm, they leap out

**We can drill a little bit deeper on major depression**

![](https://peterattiamd.com/wp-content/uploads/2024/01/f8-huberman3.png)

**Figure 8. Major depressive disorder according to light exposure (figure 2a)**. Adapted from: [*Nature Mental Health* 2023](https://www.nature.com/articles/s44220-023-00135-8)

- Basically, when you go from the 2nd to 3rd quartile of nighttime light exposure (more nighttime light exposure), you basically go from no significant increase to almost a 20% *increase*
- Then as you get up to the 4th quartile (the most nighttime light exposure), you have about a 25% *increase* in major depressive symptoms ‒ that’s no joke
- We don’t have the data right here, but if we were to look at standard [SSRI treatment](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor) for major depression, people debate this pretty actively, but light is a very potent stimulus and the timing of light is critical because the inverse is also true

***As you get to the 4th quartile of daytime light exposure, you get about a 20% reduction in major depressive disorder***

## Statistical analysis: the importance of focusing not only on statistical significance but also clinical relevance, power analysis, error bar range, and more [45:45]

**What Peter likes about a study like this**

- It makes the error bars so easy to see on the data

*Why is that interesting?*

- There’s a belief that bigger is always better in **sample size** and we often talk about that through the lens of power analysis
  - So how many subjects do we need to reach a conclusion that is powered to this level?
- That’s true, but what isn’t discussed as often is the opposite of that, “*What if you overpower a study?*”
  - In other words, what if the [power analysis](https://peterattiamd.com/studying-studies-part-v-power-and-significance/) says to have a level of power at 90%, you need 1,000 subjects
  - Then you do 10,000 subjects
- You’re clearly powered for it, but you might be overpowered
- It could be a bad thing because it means you are very likely to reach statistical significance in things that might *not* be actually significant
- One thing about this study that is just a quick and dirty way to tell that it’s probably not overpowered is that you have **varying lengths of error bars**,
  - This is not a formal statistical analysis
  - It’s just like a back of the envelope statistical analysis
- If you look for example at **self-harm** in the top quartile, you actually have pretty big error bars
  - In fact, all the self-harm have slightly bigger error bars [see the figure below]
- Yet when you look at, for example, **depression**, even though the error bars aren’t all the same size, they’re tighter

![](https://peterattiamd.com/wp-content/uploads/2024/01/f9-huberman3.png)

**Figure 9. Self-harm and depression according to light exposure (from figure 2)**. Image credit: [*Nature Mental Health* 2023](https://www.nature.com/articles/s44220-023-00135-8)

- In fact, when you look at the relationship between depression and daytime light, the error bars are really, really small
  - That gives Peter confidence that there is variability in this, which paradoxically, you want to see because it tells me that this wasn’t just done
- There were 86,000 subjects and you realize that it *wasn’t* that this should have been done with a 10th of that or a half of that, and we’re picking up signal that is statistically relevant, but clinically irrelevant
- Andrew paid attention to the error bars, but he didn’t know that

**Andrew summarizes the error bar ranges for people that are listening**

- For self-harm, they’re running as much as 20% either side of the mean (the average)
- What Peter was saying is that when you get a very large sample size, you’re going to have some outliers in there and you can mask those outliers just by having so many data points
  - Because these error bars directly tell you whether or not you’re statistically significant

**Peter explains**

- The **line of unity** in this case is the odds ratio of 1.0 or the x-axis, and the **statistically significant confidence intervals** are defined at 95%
- For depression, the 2nd quartile didn’t reach statistical significance because the error bars are touching the line
- Just as the case for the 2nd and 3rd quartile for self-harm
- But when you look at the 4th quartile, you can see that the lower tip of the error bars isn’t anywhere near unity [the line]
- And so we know without having to look up the [p-value](https://en.wikipedia.org/wiki/P-value) that it’s smaller than either 0.05 or 0.1, however they defined it
- It’s really amazing when you see these **overpowered studies** (which are easier to do epidemiologically) where the p-value ends up being microscopic, they can drive their p-values down to anything low because sample size can be infinite
- But you can see that the error bar is just skimming above the unity line, but it’s so, so, so tight

## Takeaways from the study of daytime and nighttime light exposure [49:45]

 **One thing Andrew hopes people are taking away from this study**

- Imagine you’re somebody who has a very sensitive circadian mood system
- That would mean you need less daytime light exposure to *feel good* or less bad
- But it also means that you might need very little light at night in order to *negatively impact your mood systems*
- They make this argument in the discussion as an interesting point
- What Andrew likes about this study is that they’ve separated day and nighttime light exposure

**Drugs used to treat bipolar disorder**

- It turns out that many of the drugs that are used to treat bipolar disorder are effective, perhaps in part because they reduce the sensitivity of the light sensing circadian apparati

***If you think about this, these are drugs that can ameliorate some of the symptoms of bipolar, perhaps in part by reducing the extent to which nighttime light exposure can exacerbate bipolar symptoms***

- Conversely, there’s evidence that people who take certain antidepressants may suppress the ability for daytime light to positively impact the mood systems of the brain
- Of course, we don’t want people halting their medication on the basis of that statement alone (please don’t)
  - Talk to your psychiatrist
- We know one thing for sure, it’s that if you want a significant outcome and a paper as a scientist, give a drug, any drug, and look at the amount of rapid eye movement, sleep, or the circadian cycle
- Pretty much any drug alters the circadian rhythm, for better or worse
- We start to think about which medications might adjust our overall sensitivity to light
  - Sometimes this could be a good thing; think less sensitivity to light

***For people who have bipolar disorder, the amount of daytime light exposure isn’t that important for their overall mood regulation, but the amount of nighttime light exposure really is***

- In other words, darkness for 8 hours every night should be viewed (in Andrew’s opinion) as a treatment for bipolar disorder, not the only treatment

***It’s also clear that we should all be avoiding extensive really bright nighttime light exposure***

> “*If anything, my takeaway from this study is that darkness at night is the fourth key light stimulus.*”‒ Andrew Huberman

**To put this in perspective**

- Very bright moonlight, very bright candlelight is probably only 3-50 lux
- You can download a free app called [Light Meter](https://play.google.com/store/apps/details?id=com.willblaschko.android.lightmeterv2.free&hl=en_US&gl=US&pli=1) (Andrew has no relationship to it)
  - It gives you a pretty good read of what the lux are in that environment
  - Hold down the button and it tells you how many lux
  - It’s kind of fun; go out on a really bright moonlit night
    - You’re not going to get above 100 lux
- Peter had an interesting experience a couple of months ago on an elk hunt where it was a full moon
  - It was the first time he’s ever noticed his shadow in relation to the moon (that’s how bright it seemed the light was)
- It’s super interesting to think a full moon could be that dim
- Campfires are extremely bright, but they’re not that bright compared to a very densely overcast day

Peter asks “*What is [the lux of] your phone if you don’t use any sort of light mitigating tech on it?*”

- Distance matters
- With all the wavelengths cranked up, there is a nice feature intrinsic to the phone where you can eliminate the blues at night or this kind of thing, but if you crank it up to maximum light intensity, probably something like 500 to 1,000 lux
- Now keep in mind though, it’s additive, so it’s over time
- [Lux](https://en.wikipedia.org/wiki/Lux) is a measure of, Andrew thinks it relates back to candelas as the amount of light shown, and it’s like one meter away and there’s a squaring and a falling off of distance [1 lux = 1 lumen/meter2]

***Keep in mind that if you’re looking at your phone or tablet at 800 lux or 500 lux in the evening and you do that for two hours where you’re summing quite a lot of photons***

- Andrew explains, “*We’ve hammered on people about not shifting their circadian rhythm with light at night, but we know that the* ***middle of the day*** *and the* ***middle of the night*** *are* ***circadian dead zones****.*”
  - You can’t shift your circadian rhythm that well in the middle of the day and the middle of the night, but you can provide a wake-up signal for your body and brain

**Sunrise and sunset are critical for circadian rhythm**

- This is why Andrew said there are 4 things:
- 1 – See sunrise (you don’t need to see it cross the horizon)
- 2 – Bright light during the day
- 3 – Minimize light exposure at tonight (you don’t need pitch black)
  - Pitch black probably increases the frequency of injury as most people get up in the middle of the night to use the bathroom
    - Use dim lights
    - Some people use red lights
- 4 – [see the sun set (light exposure in the early evening), mentioned earlier]

## The practicalities of minimizing light exposure and screen time at night, the use of sleep trackers, and overall challenge of modern, indoor lifestyles [55:15]

**A funny story about Rick Rubin (a mutual friend) and red lights**

- Rick was a guest at Peter’s house last summer
- He came down after the first night and was like, unacceptable accommodations
- He removed all the lighting that existed in that room and replaced it with red light bulbs, which Andrew later used when he stayed at Peter’s, and then later stole when I left
  - Andrew loves them
- At Rick’s place, he has mostly either no lighting or red lighting
- During the day, he just goes by ambient light and then red light in the evening or candlelight, and it’s great
- People hear red lights and they think they have to buy these expensive red light units, but that’s not what we’re talking about
  - You can literally buy red party lights or just a red bulb
- Andrew dims the lights in his home at night
- When he travels, sometimes he will bring one of the stolen red lights from Rick Rubin

**An instance where Peter has softened his tune**

- He used to be a hard-liner, no blue light in the evening guy
- Everything was red light at night as far as his phone, using flux on the computer, whatever it was
- He suspects that that matters somewhat, but he thinks what matters more is the stimulation that may come from those things

***What Peter has come to realize at least for him (which means it probably is true in at least some others) is that what he’s doing on his phone matters more than how bright the phone is***

- In other words, if he’s got the best blue light filter in the world on his phone, but he’s doom scrolling social media and getting lit up on email, that’s way worse for him than if he’s got his phone on maximum light and watching YouTube videos of F1 cars and driving around having fun
  - It’s a totally different experience
  - So the context matters, and for that reason, he would want people to be mindful of the whole picture
    - Going to bed under a period of intense duress brought on by something, that’s an equally dangerous component to all of this that’s distinct from what we’re talking about [light exposure]

**Andrew’s advice**

- If you’re going to stay up past your normal bedtime, if you’re going to get a lot of light in your eyes, he would hope that it will be for fun reasons and for reasons you enjoy
  - You should definitely spend some nights out
  - You should definitely do some all-nighters studying if it’s going to help you get the grade that’s permanent
    - He certainly has done all-nighters studying and grant writing for years
    - There are going to be the inevitable all-nighters due to trip to the hospital or you heard something on the news that really amped you up or you just simply can’t sleep

***The goal should be to minimize light exposure at night***

- And what Peter just said is especially true
  - For instance, people talk about the negative impact of social media
    - Is it the fact that people are looking at this little box for so many hours per day?
    - Is it all the things they’re not doing?
    - Is it what they’re looking at per se?
    - All of those things interact and are really important
- We know based on studies from the Stanford Sleep Lab that if you wake up in the middle of the night, looking at what time it is can be very disruptive to your ability to fall back asleep
  - And to your sense the next day, it’s a placebo effect, but it’s a powerful one, of how tired you are the next day
  - They’ve done this where they wake people up in the middle of the night and then they say it’s 4:00 AM versus 2:00 AM versus 6:00 AM and people’s perceived levels of energy during the day in some ways correlate with how much sleep they think they got
- Likewise, and this is one of the concerns, potential concerns with **sleep trackers**, [Alia Crum](https://profiles.stanford.edu/alia-crum?releaseVersion=10.5.2) talked about this when she came on the [*Huberman Lab* podcast](https://www.hubermanlab.com/episode/dr-alia-crum-science-of-mindsets-for-health-performance)
  - If people see a poor sleep score, they often feel worse than if they see a good sleep score
    - Now, of course, physiology matters
    - You can’t lie to yourself and say you got a great night’s sleep simply by virtue of a sleep score, but Andrew worries more about the false, if it’s false negative
    - We don’t want to put valence on this, seeing a bad sleep score and then deciding that you’re going to have a terrible day
  - A bad sleep score is an indication that you might need to dial some things in a bit better
  - Getting a great sleep score is an indication that you might be doing a number of things right and start looking at these things as averages
- Peter agrees about sleep scores and doesn’t think it’s much different from [CGM](https://en.wikipedia.org/wiki/Continuous_glucose_monitor)
- CGM is an amazing tool to provide insight after a relatively short period of time
  - In 30-90 days you know all you need to know about how the inputs affect the outputs
  - Thereafter, if you choose to use it, it’s a behavioral tool (you’re using this to build in a [Hawthorne effect](https://en.wikipedia.org/wiki/Hawthorne_effect))
- He thinks the same is true of sleep trackers
  - Most people have this profound sense of learning when they first encounter one of these things
    - Again, you’ve heard it all 100 times, “*Oh my God, I can’t believe what alcohol does to my sleep.*”
- Andrew relates this to caloric trackers: [Layne Norton’s](https://biolayne.com/coach/layne-norton/) app [Carbon](https://www.joincarbon.com/) has taught him that he consumes a lot of calories in the form of certain things at certain times of day
  - There’s a lot of good learning in that
  - He has no financial relationship to this app

***It’s the act of tracking that helps you manage it, and similarly, it’s the act of knowing you’re going to be looking at that score that gamifies it, that helps people do the right things***

- That said, Peter thinks that **recovery scores** and things like that are just notoriously *poor* at predicting performance
  - There’s a reason that serious athletes would never use things like that
    - They would tend to rely on the more tried and true methods of predicting behaviors such as heart rate, maybe heart rate variability, but morning resting heart rate probably more predictive than anything else, and then in workout, things such as heart rate, heart rate recovery, lactate threshold, things like that
- Andrew does some tracking (not as much as Peter), and he loves things that seem to work the first time and every time in terms of our natural biology based on a couple of criteria
  - Where there’s an established mechanism, and it’s been explored in the context of pathology
    - Like mental health disorders as well as pro-health in healthy individuals
  - That it makes really good sense at the level of wellness and let’s just say ancient health

**Andrew’s explains how living indoors affects our light exposure**

- When you’re talking about getting a lot of sunlight during the day, a lot of people will say, well, of course, get outside and play
- About not getting too much light at night, people say, “*Of course, this is just ‘good old-fashioned’ advice*.*”*
- People spend 90% of their time indoors now
  - Their daytime environments are too dim, their nighttime environments are too bright, and this misleading aspect of artificial light that when you see a bright bulb, you think “*I’m getting a lot of photons*,” is part of the problem and the fact that when you’re out on an overcast day and you think the sun “isn’t out,” it’s hidden by cloud cover
    - Just think about how well you can navigate that environment without a flashlight versus at night where you would require a flashlight
- We evolved under this dramatic difference in day-night availability of photons independent of whether or not you can see the sun, and it’s just very clear that all the mechanisms in our brain and body that regulate mood are just powerfully regulated by this stuff

**Andrew has made it a point to really reduce the amount of nighttime light that he’s getting**

- But he is less concerned about flipping on the light switch to use the bathroom as he used to be
- He used to think, “*I’m quashing all my melatonin. This is terrible*.”
  - He knows he can’t shift his circadian clock
  - He knows that, that light while it’s bright, if it’s brief, he’s not going to worry about it too much
- Would it be better to have a dim light on as opposed to a bright light [at night]?
  - Sure, but he’s not going to stress in a hotel bathroom or walk around shielding his eyes
- People will sometimes ask him, “*Is it different to look at the phone directly versus if you tilt the phone away?*”
  - Well, it absolutely is
  - Think about a flashlight shown on the ground in front of you, very few photons are getting in your eyes versus shown directly into your eyes
  - Think about ambient light from the sun going everywhere versus looking in the general direction of the sun
    - So east in the morning, west in the afternoon
  - ***The directionality of the light matters***

**A funny story about avoiding direct light at night**

- Andrew is not saying that you need to peek at your phone as if you’re looking over the edge of a bowl or something into it
- Andrew’s friend, [Samer Hattar](https://www.nimh.nih.gov/research/research-conducted-at-nimh/principal-investigators/samer-hattar) is head of the chronobiology unit at the National Institute of Mental Health, and they used to room together at meetings
  - They stopped because he’s a terrible snorer
    - There were a few times when Andrew considered suffocating him in the middle of the night since he was already suffocating himself
  - Andrew caught him looking at his phone in the middle of the night and he would tilt it away like he’s holding a platter, and looking over at the screen there
    - This is ridiculous
    - Samar said, “*I’m trying not to get so much light in my eyes*.”
    - That’s a little extreme, but it illustrates the point, which is how much direct light exposure you get at night matters
- How much direct sunlight exposure you get, especially early morning, late afternoon, and throughout the day, it really matters

**Peter asks, “*****What is the wavelength of sunlight?*****”** [1:05:15]

- Sunlight is going to include all visible spectrums
- This [RISS sensor [used in this study]](https://www.broadcom.com/products/optical-sensors/ambient-light-photo-sensors/apds-9007) detected 470 nanometer to 650 nanometer light, so that’s going to be blue and ultraviolet [see the table below]
  - They’re measuring blue to orange
- Red light is going to be around 680, and far red is going to be 720 and up
- Blue light is going to fall somewhere in the low 400s
- Ultraviolet is getting down into the high 300s and lower

![](https://peterattiamd.com/wp-content/uploads/2024/01/f10-huberman3.png)

**Figure 10. Visible spectrum of light**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Visible_spectrum)

- In midday light, you’re getting what looks like white light
  - You’ll see the sky is blue and the sun is bright white light
  - It’s not even yellow to your eye, and of course, don’t stare at it, especially in the middle of the day
  - You’re getting all visible spectra, so you’re getting everything from UV all the way out to red light
    - It’s just coming in at equal intensities

## Potential limitations of the light exposure study, reverse causality, and the complex interplay of variables in epidemiological studies [1:06:00]

**Peter asks, “*****Is that a potential limitation of this study in that it didn’t have a sensor that could pick up the full spectrum of light?*****”**

- Potentially
- We don’t think of humans as UV capable (being able to perceive UV light)
- A ground squirrel, for instance, has UV sensors in its eyes
  - Turns out, when the ground squirrels sit up on their haunches, they’re actually signaling one another: they rub urine on their belly and it reflects UV
- *The New York Times* for some reason has been running a series of [articles](https://www.nytimes.com/2023/10/20/science/glowing-fluorescent-mammals-ultra-violet.html) about naturally occurring fluorescence at night in all sorts of species, scorpions and monotremes like the platypus
- No one really knows the reason for these odd wavelength of light emissions for all these animals, but we view things in the blue, violet, and up to red, and we’re not pit vipers
- We can’t see far red, but we can see lower than 470 nanometers and we can see higher than 650

Peter asks, “*Is there a technology reason why they had such a narrow band in these sensors? Is it not possible that they could have used a RISS sensor that was wider?*”

- This study was initiated in 2013
- The tech was probably far worse than it is now
- Andrew would love for somebody to design an eyeglass where it’s measuring how many photons you’re getting across the day
  - He’s not a big fan of having everything be app-ified, so he would love it if the frame would just shift color across the morning
  - For instance, if you go outside on a cloudy day and wear these glasses…

**Andrew points out about sunlight viewing**

- It’s fine to wear eyeglasses or contacts for sunlight viewing, for setting your circadian rhythm
- People ask, “*Well, why is that okay, and a window is not?*”
  - Corrective lenses are actually focusing the light onto your retina
  - Windows and windshields are scattering the light and filtering

Peter asks, “*How much are sunglasses filtering this out?*”

- Too much
- They’re probably causing a tenfold decrement in the total lux count that’s landing on your retina
- But of course, sunglasses are important [to wear when] driving into sun, and some people have very sensitive eyes
  - Andrew can’t sit at a cafe with a brightly reflective table in the afternoon; he squints like crazy
  - Andrew’s dad, who’s darker eyed, and he is South American descent, he can just sit there just fine
  - People differ in their light sensitivity

**Peter wonders how much reverse causality can exist in these observations?**

- These observations demonstrate very tight correlations, very strong associations, especially in the five areas that we highlighted
- But it’s possible that part of what we’re seeing is reverse causality brought on by both the treatments (which Andrew already kind of alluded to) and also the condition itself

*Peter explains reverse causality and the Hawthorne Effect*

- The **Hawthorne Effect** is an effect that is named after an observation of what took place in a factory where they were actually studying worker productivity with light, of all things
- What it refers to is the idea that people will change their behavior when they are observed
- So if Peter said, “*Well, I really want to know what a day in the life is like for Andrew Huberman, I’m going to follow him around for a day*.”
  - It’s very unlikely that his behavior that day will be exactly as it was if Peter wasn’t there
  - Andrew points out, “*It’d be the most boring video in the world, because it’s mostly me reading and underlining things*.”
    - His schedule is pretty scripted, unless he’s traveling
    - It’s morning sunlight, hydration, and some cardio or weight training, and then a lot of time reading papers
- Peter points out, “*It’s why game-ifying things can be beneficial, right?*”
  - It’s why a CGM can be beneficial, because it’s sort of like somebody’s watching you, and you’re going to modify what you eat in response to it
  - Or why tracking can really be an effective way to reduce input, because there’s a sense of being monitored by doing that, especially if someone literally monitors it
  - In other words, you can set up an accountability partner where your health coach or someone is actually seeing the data
- Now as far as **reverse causality**, when you look at variables… let’s just pick a common one that’s unrelated to this

**Example: there’s an association that more diet soda consumption is associated with greater obesity (it’s a bit paradoxical)**

- It has been postulated by some to suggest that non-nutritive sweeteners, such as aspartame or sucralose or things like that, are actually part of what’s causing obesity
  - And while there are probably some arguments you could make around the impact that those things might have on the gut microbiome, and maybe there’s some way that’s happening
  - It’s also equally likely, if not probably more likely, that there’s reverse causality there
- Reverse causality: a person who is obese is therefore contemplating how much they’re eating or thinking, “H*ey, what’s an easy way that I can reduce calories? How about instead of drinking a Coke, I drink a diet Coke?*”
  - And so there, the causality which you would impute to mean the drink is causing the obesity, it might be no, ***the obesity is causing the choice of drink***

**In this study, the question is: how much of the effect we’re seeing is a result of the condition that’s being studied?**

- How much of the disruption in both day and night light exposure is the result of the depression?
- It’s dysregulating sleep
  - Maybe they’re sleeping more during the day and more awake at night because of depression
  - Again, you can’t know this
  - This is where epidemiology never allows us to determine this, and sadly, these questions can only be answered through either direct randomization or [Mendelian randomization](https://en.wikipedia.org/wiki/Mendelian_randomization),

Peter asks, “*Do you know if anyone has examined this from a* [*Mendelian*](https://en.wikipedia.org/wiki/Mendelian_randomization) *standpoint?*”

- Peter doesn’t know enough about the biology to know what [SNPs](https://en.wikipedia.org/wiki/Single-nucleotide_polymorphism) would be study-able, but that would be interesting

*Andrew explains*

- If you knew something about the genomes of these people, you would be in a great position to, perhaps even link up light sensitivity genes with genes for pathways involved in major depression, bipolar
- Getting to this issue of reverse causality, it’s very straightforward to imagine that the person who’s experiencing a manic episode is going to be up for two weeks at a time, sadly, and getting a lot of nighttime light exposure
- Nighttime dark exposure as a treatment for bipolar is something that people are starting to talk about
  - So making sure that even if those people are awake, that they’re at least blue blocking at night, reducing their online activities
  - But people with severe manic episodes have a hard time regulating their own behavior, of course
- Peter clarifies that it’s not one or the other
  - He doesn’t want the question to come across to the listener that it has to be one or the other
    - It’s only A can cause B, or B can cause A
  - No, it’s actually, a lot of times these things feed off each other

## A tangent on diet soda and sugar substitutes as an example of reverse causality [1:13:15]

- Going back to the soda example, Peter actually thinks there’s a bit of both
  - There’s a real clear, body habitus dictates beverage choice
  - But he also is starting to think that in susceptible individuals, non-nutritive sweeteners will alter the gut biome, and that alters metabolism

**Andrew asks about hunger? Do diet sodas stimulate appetite?**

- He remembers [Layne](https://biolayne.com/coach/layne-norton/) talking about a study showing water is probably better than diet soda
- It’s something about the perception of sweet as driving hunger, whereas not eating, or drinking anything with any sweetness doesn’t seem to
- This is one of the things that Andrew wonders if it impacts why some people like intermittent fasting
  - Because for some people, he wonders if the perception of sweetness, even just the smell of food, we know, can stimulate appetite
  - You can imagine the perception of sweetness in the mouth, even if there’s no calories there, he doesn’t think it necessarily makes people hypoglycemic, but perhaps it makes them think about: sweet means food
- For instance, for years, Andrew loved the combination of a Diet Coke and a slice of pizza whenever he was in New York
  - Now every time he has a Diet Coke (which isn’t that often, but he likes Diet Coke, especially with a little lemon in it), he thinks about a slice of cheese or mushroom or pepperoni pizza
    - Andrew explains, “*It’s like I want it, I crave it more*.”

***There’s a paired association there that Andrew thinks is real***

- Work from [Dana Small’s](https://medicine.yale.edu/profile/dana-small/) lab at Yale shows there’s a **paired association** between the sweetness from sucralose and there’s an insulin response
  - They had to stop the study in kids because they were becoming pre-diabetic, which unfortunately meant the study was never published

**Peter wrote a** [**premium newsletter**](https://peterattiamd.com/sugar-substitutes/) **on all things related to sugar substitutes last August**

- The short of it is, the data are a little bit noisy, but there is indeed, some sweeteners in some studies do result in that phenomenon you described, the cephalic insulin response
- Peter came away from the research that went into that, which was Herculean effort on the part of the team, a little bit more confused than when he went in
  - He’s even more cautious around artificial sweeteners than he was going in
  - And not for the reasons of finding any evidence that these things are cancer-causing (that’s the headline stuff people worry about)
  - He came away more cautious about the potential for these things to be mucking around with both your brain chemistry and your gut chemistry, which can pertain to your metabolism

***Peter’s takeaway on sugar substitutes was buyer beware: use limited amounts only***

- The only one that still emerged to him as reasonable/safer is [xylitol](https://en.wikipedia.org/wiki/Xylitol) (it’s the only one he uses)
  - Xylitol for chewing, so for gum, and [allulose](https://en.wikipedia.org/wiki/Psicose) as an additive
- Andrew will have a Diet Coke every now and again, and he drinks things with [stevia](https://en.wikipedia.org/wiki/Stevia) in it, but he generally avoids [sucralose](https://en.wikipedia.org/wiki/Sucralose)
  - He doesn’t like the way sucralose taste’s
  - [Monk fruit](https://en.wikipedia.org/wiki/Siraitia_grosvenorii#Sweetening_agent) is too sweet

## Andrew and Peter’s take on the causality vs. correlation of light exposure to mental health, the damage of circadian disruption, and the interpretation of observational data [1:17:30]

**To finish up this first paper**

Peter asks, “*If you had to just lay on your judgment, if it were a hundred to zero, you would say the light is 100% causal in the effects we’re seeing. If it were zero to a hundred, you’d say, nope, the behavior is 100% causal of the exposure to light. Again, you can’t know it, but what does your intuition tell you?*”

- Andrew begins with, “*There’s my intuition, and then there’s my recognition of my own bias*.”
- Andrew started working on these circadian pathways originating in the eye back in ‘98, as a graduate student at Berkeley
  - The cells, these melanops and intrinsically sensitive retinal ganglion cells were discovered in the early 2000’s by a guy named [Iggy Provencio](https://bio.as.virginia.edu/people/ip7m), [David Berson](https://vivo.brown.edu/display/dberson), [Samer Hattar](https://www.nimh.nih.gov/research/research-conducted-at-nimh/principal-investigators/samer-hattar), [Satchidananda Panda](https://www.salk.edu/scientist/satchidananda-panda/), and others
    - It was one of the most important discoveries in all of biology, clearly
- So Andrew has been very excited about these systems
- Setting that bias disclosure aside

***Andrew thinks 65-75% of the effects are likely due to light directly***

- It’s impossible to tease those apart

**To play devil’s advocate and consider the level of light exposure of person with depression**

- You could imagine that the depressed individual is laying around indoors with the curtains drawn
- They didn’t sleep well the night before, which gives you a photosensitivity that isn’t pleasant
  - It sucks to have bright light in your eyes first thing in the morning, especially if you didn’t sleep well
- And then they’re making their coffee in a dimly lit, what they think is brightly lit, environment
- Then they’re looking at their phone, and the state of the world sucks, and their state of their internal landscape is rough, and maybe they’re dealing with a pain or injury or something, and their likelihood of getting outside is low, and when they do get outside, they’re going to shuffle and not

***So Andrew could see how the behaviors could really limit the amount of light exposure***

- Then evening rolls around, they’ve been tired all day, and a common symptom of depression, they fall asleep, and then two or three in the morning they’re wide awake
  - What are you going to do at two or three when you’re wide awake, sit in the dark?
    - No, you’re going to get online; you’re going to listen to things
    - Andrew is not recommending this, but they may have an alcoholic drink in order to try and fall asleep
  - This is the pattern

***Shaking up that pattern is really so much of Andrew’s public health work these days is about, and trying to get people onto a more natural daylight, night dark rhythm***

- But yeah, it’s impossible to tease apart

**Andrew explains more about circadian rhythm**

> “*We do know this, and this is really serious. We know that in almost every instance, almost every psychopathology report of suicide, in the weeks, but especially in the days, preceding suicide, that person’s circadian rhythms looked almost inverted from their normal patterns*. *And that’s true of non-bipolar individuals as well.*”‒ Andrew Huberman

- Circadian disruption and disruption in psychiatric health are inextricable
- Conversely, positive mood and affect and circadian behavior seem very correlated
- If you want to **become an early riser**, get light in your eyes and get activity in your body early in the day
  - You entrain to those rhythms so that you start to anticipate that morning workout, you start to anticipate the morning sunlight
  - Just one more scientific point, we know that **when you view bright sunlight in the morning** (or just sunlight that’s illuminating your environment, you don’t even have to see the sun itself), that there’s a 50% increase in the amplitude of the morning [cortisol](https://en.wikipedia.org/wiki/Cortisol) spike
    - Which is a good thing because the amplitude of the morning cortisol spike is inversely related to the amplitude of the evening cortisol spike
    - And high evening cortisol is associated with middle of the night waking, and on and on
- Andrew is very bullish on these mechanisms
- He loves that they’re so deeply woven into our evolutionary history that we share with single cell organisms
- But of course there’s going to be a bi-directionality there, and it’s impossible to see where one thing starts and the other one stops

**Interpreting epidemiologic data, thinking about correlations and causality, and the purpose of the discussion [1:21:15]**

**Peter’s takeaway**

- Peter, with far less authority than Andrew, agrees with Andrew’s assessment, and might be a little bit more bullish
  - He might put it at 80/20
- This stems for from his fastidious battles with epidemiology in general, because so much of the world that he lives in still has to rely on epidemiologic data

*H*ow *do you make sense of epidemiologic data?*

- The truth of it is, most of it is really pretty bad

**Peter finds himself looking at the** [**Austin Bradford Hill criteria**](https://en.wikipedia.org/wiki/Bradford_Hill_criteria) **all the time**

- Sir Austin Bradford  Hill was a statistician, who basically proposed a set of [9] criteria
  - The more of these criteria that are met within your correlations, the more likelihood that you will find causality

![](https://peterattiamd.com/wp-content/uploads/2024/01/f11-huberman3.png)

**Figure 11. Austin Bradford Hill criteria**. Credit: Wikipedia

**When Peter thinks of data here, the data in this paper, what makes these correlations seem to have causality within them, in the direction that’s being proposed:**

- 1 – The dose effect is always present
  - Dose effect matters, and this is done in quartiles, and that’s a very elegant thing
  - If they just did it as on/off (or high/low), it would be harder
- 2 – Biologic plausibility
  - In other words, sometimes you have to look at epidemiology and ask, is there a biologic explanation?
  - And here, there is.
- 3 – Evolutionary conservation is added to the biologic plausibility
- 4 – Then you can talk about animal models, or experiments in humans over short durations, that generally support these findings

***Those are just a couple of the Bradford Hill criteria that lead to Peter’s belief that, yeah, there’s reverse causality here, but it’s not the full explanation, and that more of the explanation is probably the direction that’s being proposed***

**At the end of the day, what’s the purpose of the discussion?**

- The purpose of the discussion is, if you are under the influence of any of these psychiatric conditions, in addition to the treatments you’re doing now, what else can you do?

*The takeaway is follow these light behaviors*

- That’s a relatively low lift, when you consider some of the other things
  - For example, Peter is asking people to do zone 2 for 3 hours a week, and VO2 max workouts, and all this other stuff
    - He thinks all those things matter for mental health as much as physical health
  - But this strikes him as on the spectrum of ‘low asks’
    - If it’s only even 30% causality, 70% reverse causality, he would still instate that

**How to implement this**

- Andrew explains, “*It’s taking your coffee on the balcony*”
- People ask, “*Well, how do you do this with kids?*”
  - The kids should be doing it, too
- It means popping your sunglasses off, it means getting out for just a few minutes in
- And the fact that it’s additive, that these photon counting mechanisms, they sum
- This paper also says, “*If you missed your daytime light ration, get your nighttime dark ration. They are independent and additive*.”
  - Ideally, you get both
- Andrew appreciates Peter’s expertise in parsing epidemiology
  - Andrew looks at fewer studies of that sort, but he learned from Peter, and that’s one of the reasons he loves doing these journal clubs (to learn)

## A primer on the immune system as background for the paper Peter chose [1:25:00]

- The [paper](https://www.nejm.org/doi/full/10.1056/NEJMoa1003466) Peter chose is the landmark study of a class of drugs
- In the same way that Andrew picked a paper that has a much broader overarching importance, the reason Peter picked this paper (from the *New England Journal of Medicine*, it’s about 13 years old), is because ***it is the landmark study in a class of drugs that Peter believes are the most relevant class of drugs we’ve seen so far in cancer therapy***
- Even though the net effect of these drugs has only served to reduce mortality by maybe 8-10% (which is not a huge amount), it’s the manner in which they’ve done it that gives him great hope for the future

**Context and background before we get into the paper**

*The human immune system is a remarkable thing*

- It’s hard when you’re trying to imagine what’s the most amazing part of the human system
  - Maybe it’s Peter’s bias as well, because just as Andrew spent his time in the light system and the photo sensing system, Peter spent his time in the immunology world
- It is remarkable how our immune systems evolved

*They have this really brutal task, which is, how can they be tuned to detect any foreign pathogen that is harmful, without knowing a priori what that could be?*

- In other words, how can you tune a system to be so aggressive that it can eradicate any virus or bacteria billions of years into the future, without knowing what it’s going to be, but at the same time, it has to be so forgiving of the self that it doesn’t turn around and attack the self?
- It’s remarkable
- Of course, we can always think of the exceptions: there are things called **autoimmune conditions**
  - Clearly, the system fails, and the immune system turns around and attacks the self
  - If you see a person with [vitiligo](https://en.wikipedia.org/wiki/Vitiligo), Peter has a little bit of vitiligo on his back (a couple of spots), clearly the immune system is attacking something there and destroying some of the pigment
  - There are lots of more serious autoimmune conditions
    - Somebody that has [lupus](https://en.wikipedia.org/wiki/Lupus), or the immune system can be attacking the kidney, the immune system can be attacking anything
    - Autoimmune conditions can be deadly, but fortunately they were very rare
- For the most part, this immune system works remarkably well

**How does the immune system work, and why is it that cancer seems to evade it virtually all of the time?**

- Peter is going to simplify it by only talking about one system, which is how T-cells recognize [pathogens] and get activated

*How T-cells recognize antigens*

- We have something called an [antigen](https://en.wikipedia.org/wiki/Antigen): an antigen is an antibody generating-peptide
  - It’s almost always a protein
    - They can be carbohydrates, but they’re almost always proteins
  - And they’re very, very small peptides, as little as 9 amino acids, maybe up to 20 amino acids
    - It’s amazing that in such a short peptide, the body can recognize if that’s Andrew or not Andrew
    - We talk about proteins in [kilodaltons](https://en.wikipedia.org/wiki/Dalton_(unit)), in terms of thousands of amino acids that make up every protein in your body

***Yet, if the immune system samples a protein and sees this little 9-15 amino acid part, it knows it’s not you and it’s bad, and therefore it’s going to generate an immune response to it***

**We have what are called antigen-presenting cells**

- These are cells that go around sampling peptides, and they will, on these things called MHC class receptors, bring the peptide up to the surface and serve it up to the T-cell [shown in the figure below]
  - This is the [major histocompatibility complex](https://en.wikipedia.org/wiki/Major_histocompatibility_complex), and there are two types of theses: [MHC class I](https://en.wikipedia.org/wiki/Major_histocompatibility_complex#MHC_class_I), and [MHC class II](https://en.wikipedia.org/wiki/Major_histocompatibility_complex#MHC_class_II)
  - We refer to them that way because of the context in which they were discovered, which was for organ rejection

![](https://peterattiamd.com/wp-content/uploads/2024/01/f12-huberman3.png)

**Figure 12. An antigen-presenting cell shows T cells peptides on MHC receptors**. Image credit: [*Frontiers in Endocrinology* 2022](https://www.frontiersin.org/articles/10.3389/fendo.2022.1010279/full)

- Not surprisingly, when you need to put a kidney into another person, if that kidney is deemed foreign, it will not last long
  - The early days of organ transplantation were rife with immediate rejections
    - Due to [A/B/O incompatibilities](https://en.wikipedia.org/wiki/ABO_blood_group_system)
  - But the next layer of incompatibility was MHC incompatibility, which would lead to, within weeks the organ is gone, as opposed to within hours
- So you have these two classes of MHC
  - **MHC class I** is what we call **endogenous**: this is basically what happens when a protein or an antigen is coming from *inside* the cell

**Consider the flu**

- If you get the flu, the influenza virus infects the respiratory epithelium of your larynx, and viruses can’t replicate on their own
  - What they do is they hijack the replication machinery of the host, and they use that, either to insert their RNA or DNA, to replicate
  - And in the process proteins are being made
  - Well those proteins are the proteins of the virus, not of us
  - Some of those peptides get launched onto these MHC class I
    - Think of it like a glove that comes up to the surface, and a T-cell comes along
    - In the case of MHC class I, it’s seen by a CD8 T-cell (aka killer T-cell)
  - The [T-cell receptor](https://en.wikipedia.org/wiki/T-cell_receptor) meets the MHC class I receptor with the antigen in it, and if that’s a lock (the T-cell realizes that’s my target), then it begins to replicate and proliferate and target those
    - And that creates the immune response
    - By the way, that’s how it works when you vaccinate somebody, you’re basically pre-building that thing up

Andrew asks, “*Would this fall under the adaptive immune response, or the innate immune response?*”

- This is [adaptive](https://en.wikipedia.org/wiki/Adaptive_immune_system)
- [Innate](https://en.wikipedia.org/wiki/Innate_immune_system) is just these pure antibody responses on the B-cell side
  - We won’t get into that for the purpose of this discussion

**The other example [of antigen presentation] is MHC class II**

- That’s part of the innate system, which is more what we call the exogenous form
- These are peptides that are usually coming from *outside* the cell

***We’re going to focus more on the MHC class I, because this is peptides that come from inside the cell***

**More about the immune system**

- So just keep in the back of your mind, if a foreign protein gets presented from inside a cell to outside a cell, the T-cell will recognize that, and they will mount a foreign response
  - And that’s why we basically can beat any virus
- If you consider how many viruses are around us, the fact that we almost never die from a viral infection is a remarkable achievement of how well this immune system works
  - We’re way better at fighting viruses than bacteria
- BTW, we don’t really have very effective antiviral agents
  - It’s not like antibiotics; we have antibiotics up the wazoo
- Andrew has always wondered about this: to what extent is our ability to ward off viruses on a day-to basis as an adult reliant on us having been exposed to that virus during development?
  - Maybe today Andrew will be exposed to a hundred thousand different viruses
  - He asks, “*Would you say that half of those I’ve already got antibodies to, because I was exposed to them at some prior portion of my life?*”
    - That’s hard for Peter to quantify
  - Andrew assumes that on a plan, he’s in a swamp of viruses, and most of them he’s already been exposed to as a little kid
    - So he’s got all the antibodies and they’re binding and destroying the viruses
- Peter thinks it’s part that, and also our body can destroy some without mounting much of a systemic inflammatory response
- You also have huge barriers: the skin, the hairs in your nose
- Also, there are certain viruses that are totally useless floating in the air: [Hep C](https://en.wikipedia.org/wiki/Hepatitis_C), [Hep B](https://en.wikipedia.org/wiki/Hepatitis_B), [HIV](https://en.wikipedia.org/wiki/HIV) (the viruses most people are really afraid of)
  - If they’re sitting on a table or floating around the air, they’re of no threat to your
  - They have to transmitted through the barrier
- Some of these viruses you’re going to defeat without an enormous response
- Then some of them, why is influenza such a “bad virus,” whereas the common respiratory cold kind of sidelines you for a day?
  - It’s the immune response that you’re feeling
  - The bigger the immune response to the virus, the more you’re feeling that
  - You feel your immune system going crazy
    - The interleukins that are spiking
    - The [third spacing](https://en.wikipedia.org/wiki/Fluid_compartments#Third_spacing) that occurs to get more and more of the immune cells there
    - The spike of your temperature as your body basically tries to cook the virus
    - The fatigue

**Just to close the loop on autoimmunity, Peter explains how we learn not to attack ourselves**

- That’s something called [thymic selection](https://en.wikipedia.org/wiki/Thymocyte) that occurs in infancy
- In an adult, the thymus is tiny, but in a child, the thymus is quite large
- The purpose of the thymus is to educate T-cells and basically show the T-cells what self is
  - It’s a really clever system, where we basically teach you to recognize self at a very early age, and if you can’t do that, you’re weeded out
- Then the thymus involutes thereafter, because it’s served its purpose

## Background on cancer: causes, how it evades the immune system, and the logic behind immune checkpoint inhibitor therapy [1:35:45]

**What do we know about cancer?**

- Cancer is a genetic disease, in the sense that every cancer has genetic mutations
  - Most of those mutations are [somatic](https://en.wikipedia.org/wiki/Somatic_mutation), which means most of those mutations are mutations that occur during the course of our life
    - They’re not [germline mutations](https://en.wikipedia.org/wiki/Germline_mutation) (germline being egg and sperm)
- Andrew comments, “*I love that you pointed out that cancer can be genetic, but isn’t necessarily inherited. People hear genetic and they think inherited. Inherited is always genetic, to some extent, but genetic isn’t always inherited*.”
- There are a handful of cancers that are derived from inherited mutations:
  - [Lynch syndrome](https://en.wikipedia.org/wiki/Hereditary_nonpolyposis_colorectal_cancer) and [hereditary polyposis](https://en.wikipedia.org/wiki/Familial_adenomatous_polyposis) are examples
  - Where you have a gene that gets passed through the germline, and that gene codes for a protein, like all genes do
    - And it’s either you have too much of a gene or too little of a gene
    - So it’s either a gene that promotes cancer, and you have too much of that
    - Or it’s a gene that prevents cancer, and you have too little of it, or a dysfunctional version of it
- [*BRCA*](https://en.wikipedia.org/wiki/BRCA_mutation) is an example of the latter
  - *BRCA* is hereditary, *BRCA* codes for a protein, and in some cases  having a *BRCA* mutation almost guarantees breast cancer, it’s because of a defective copy
    - So it’s like they don’t get the protein that they need to protect them from breast cancer
- In cancer, our cells become cancerous because they are hijacked, they have these mutations, and as a result of these mutations, they make proteins that allow cancers to behave differently

**Cancers behave differently from non-cancerous in two very critical ways**

- 1 – They do not respond to cell cycle signaling
- So if you cut your skin, it heals, but how does it know to heal just right and not to keep growing and growing and growing and growing and growing?
  - It knows that because there are cell cycle signals that tell it, time to grow, time to stop
- An extreme example: if you donated to me half of your liver, within months, you would regenerate a full liver
  - Isn’t that amazing?
  - And it knows how much to grow back
- When the cell is perfectly functioning, it knows how much to grow, but cancer loses that ability

***That is one of the hallmarks of cancer: it just keeps growing***

- It doesn’t grow faster, by the way, that’s a misnomer
  - There’s no real evidence that that’s the case
  - They just don’t stop growing
- 2 – The capacity to leave the site of origin, go someplace else, and take up residence
  - That’s the [metastasis](https://en.wikipedia.org/wiki/Metastasis) component

***Think about it for a minute: a cell that never stops replicating, and has the capacity to up and leave and move and take up residence, is clearly different from the cell itself***

- If it keeps growing and growing, it must have different proteins

> “*The question then becomes, why does cancer even exist? How has our immune system not figured out a way to just silence this and eradicate it the way it does to virtually every virus you encounter?*”‒ Peter Attia

**How evolutionarily clever cancer is**

- It does a lot of things to trick the immune system
- It has its own secretory factors that tamp down the immune system
- It grows in an environment because of its nature
  - One of the things that’s long understood about cancer is it’s heavily glycolytic [the [Warburg effect](https://en.wikipedia.org/wiki/Warburg_effect_(oncology))]
    - And when something is heavily glycolytic, it’s going glucose to pyruvate, to lactate nonstop
    - There’s a lot of reasons for that
  - When [Warburg](https://en.wikipedia.org/wiki/Otto_Heinrich_Warburg) proposed this, probably in the 1920s, he thought he mitochondria of cancer cells were defective and hence the cell had to undergo glycolysis
    - [Discussed in [episode #187](https://peterattiamd.com/samapple/)]
  - We now know this is not the case; this has nothing to do with defective mitochondria
    - Others have proposed several mechanisms, and there’s probably more than one thing going on

**An influential** [**paper**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2849637/) **on the Warburg effect**

- In 2009, Matt Vander Heiden, Craig Thompson and Lew Cantley [proposed](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2849637/) that the reason that cancer cells do the Warburg Effect is that they’re not optimizing for energy, they’re optimizing for cellular building blocks
  - And if you do the mass balance, it completely makes sense: dividing cells need building blocks more than energy
- [Glycolysis](https://en.wikipedia.org/wiki/Glycolysis), while very inefficient for generating [ATP](https://en.wikipedia.org/wiki/Adenosine_triphosphate),  is much more efficient at generating substrate to make more cells

**But another proposed mechanism**

- Glycolysis lowers the surrounding pH because of lactate
  - Lactate attracts hydrogen, pH goes down

*Guess what that does to the immune system*?

- Detracts the immune system
- It’s also a way to hide from the immune system
- Andrew explains, “*Like a pH cloaking, leveraging pH to cloak the signal that the immune system would otherwise see.*”
- Then when you layer on top of that, that it knows how to secrete things like [IL-10](https://en.wikipedia.org/wiki/Interleukin_10), [TGF-beta](https://en.wikipedia.org/wiki/Transforming_growth_factor_beta), all of these other secretory factors that also inhibit the immune system

***Basically it’s figured out a way to hide itself from the immune system***

- Andrew reacts, “*The way you describe it, cancer sounds like a virus.*”
- He asks if there any examples of contagious cancers
  - Tasmanian devils get cancers and tumors growing on their faces
    - It was like a literal physical interaction that could transmit cancer from one animal to the next
- Peter explains, “*It’s less that. There are viruses that cause cancer. So in that sense, you could argue yes, there are contagious cancers.*”
  - [HPV](https://en.wikipedia.org/wiki/Human_papillomavirus_infection), [Hep B](https://en.wikipedia.org/wiki/Hepatitis_B), [Hep C](https://en.wikipedia.org/wiki/Hepatitis_C), but there are even cancers like cutaneous cancers that arise from viruses
    - Peter doesn’t know if that’s quite the same as what Andrew is saying
- About HPV, Andrew explains, “*What you’re saying is an important point… that’s increasing susceptibility to cervical cancer. Now there’s a vaccine against HPV, right? There wasn’t when we were in college.*”

***Direct transmission of cancers from one organism to the next is more rare***

**There’s this really incredible thing about cancer and our immune system that blows Peter’s mind**

- At least 80% of solid organ tumors have antigens that are recognized by the host’s immune system
- We’re going to mostly talk about solid organ tumors because that’s where the field of oncology has made very little progress
- If you go back 50 years, where has oncology made huge progress?
  - It’s made great progress in blood tumors, leukemias, and some kinds of lymphomas
- There’s two kinds of lymphomas where the progress has been remarkable
  - 1 – Hodgkin’s lymphoma
  - 2 – Immunotherapy, in a type of B-cell lymphoma where that B-cell demonstrates or presents something called a [CD19 receptor](https://en.wikipedia.org/wiki/CD19#Cancer)
    - In B-cell lymphomas with CD19, there’s a very unique niche immunotherapy (we won’t talk about that today) called [CAR T therapy](https://en.wikipedia.org/wiki/CAR_T_cell) that has got rid of those guys
  - And then leukemias have also been pretty good
- In solid organ tumors, there’ve been only 2 real breakthroughs in the last 50 years
  - 1 – Therapy for a certain type of testicular cancer, and it’s really just a chemotherapy cocktail that has been found to work really well
  - 2 – In a rare kind of gastric cancer called the [GI stromal tumor](https://en.wikipedia.org/wiki/Gastrointestinal_stromal_tumor), which happens to result from one mutation in a kinase pathway
    - And there’s one drug that can now target that and cure the cancer (it’s kind of amazing)

**The big 5 causes of cancer death**

- Lung
- The breast
- The prostate
- Colorectal
- Pancreas

***These cause more than 50% of cancer deaths in Americans, and these are what we call the solid epithelial tumors***

> “*More than 80% of those cancers have antigens that are recognized by the host’s immune system*”‒ Peter Attia

- At least 80% of those cancers actually generate an antigen, meaning a little peptide in that cell gets presented to the T-cell and it is recognizable

**The question is why is that not sufficient to induce remission?**

- And the short answer is there are not enough T-cells that are able to act and or they are being sufficiently inhibited from acting
- This gets to the point of this paper: one of the ways in which the body inhibits the immune system is something called the [immune checkpoints](https://en.wikipedia.org/wiki/Immune_checkpoint)
  - We should remind ourselves that immune checkpoints are an important thing
- Back to the idea Peter talked about before, you have an [antigen-presenting cell](https://en.wikipedia.org/wiki/Antigen-presenting_cell) and it brings up an MHC receptor with a peptide on it (shown in the diagram below)
  - There is a T-cell coming

![](https://peterattiamd.com/wp-content/uploads/2024/01/f13-huberman3.png)

**Figure 13. An antigen-presenting cell shows T cells peptides on MHC receptors**. Image credit: [*Frontiers in Endocrinology* 2022](https://www.frontiersin.org/articles/10.3389/fendo.2022.1010279/full)

- The MHC receptor with the peptide is sitting there and it binds to the T-cell receptor on the T-cell
- But there is another receptor on the T-cell, a [CTLA-4 receptor](https://en.wikipedia.org/wiki/Cytotoxic_T-lymphocyte_associated_protein_4) that binds to a receptor
  - The names don’t matter, but there’s another receptor on the antigen-presenting cell that binds to CTLA-4, and that acts as the breaks in the reaction
- When CTLA-4 (on the T-cell) binds to another CD receptor on the antigen-presenting cell, and it says, “*Tamp down the response*.”
  - The reason for that is we want to keep our immune system in check
  - This basically is a way of asking the immune system
    - Because remember, when the immune system sees that antigen, it wants to go nuts, it wants to start replicating and killing
- This is a [CD8 T-cell](https://en.wikipedia.org/wiki/Cytotoxic_T_cell), it is a targeted killer T-cell; and the checkpoint says, “*Let’s double check that. Let’s be sure. Let’s tamp down the response.*”

***What if you take away the brakes that stop T-cells? [1:47:30]***

A thought experiment emerged: *What if we block CTLA-4? What if we block the checkpoint?*

- Could we unleash the immune system a little bit more?
- At the time it was proposed, it seemed a bit far fetched that simply blocking the checkpoint would have any effect, because of the complexity of the immune system
- It’s also worth noting that prior to this, one immunotherapy had found some efficacy, which was trying the exact opposite strategy
  - Rather than blocking the inhibitor, it was throwing more accelerant at the fire, which was giving something called [interleukin-2 [IL-2]](https://en.wikipedia.org/wiki/Interleukin_2)
    - Interleukin-2 is, for lack of a better word, candy and fuel for T-cells
  - The idea was if we have T-cells that innately recognize a cancer antigen, can we just give high doses of interleukin-2 and have them undergo proliferation and response?
    - And the answer turned out to be yes, but only in two cancers (melanoma and kidney cancer) and only at very small levels, about 10% of the population would respond to these things
    - But that’s 10% of people who were going to be dead within 6 months because these are devastating cancers, and once they spread, there are no treatments that have any efficacy whatsoever
    - The median survival for metastatic melanoma at the time was probably four months (a very grim death sentence)

***The idea now was about doing the exact opposite approach: instead of trying to throw more fire at the T- cell, what if we can take its breaks down? Instead of giving more gas, let’s give less brakes.***

- There were some phase I studies that demonstrated efficacy, and phase II studies
- The [paper](https://www.nature.com/articles/s44220-023-00135-8) Peter is going to talk about today is the phase III study that compared the first version of these

**The anti-CTLA-4 drug called Ipilimumab**

- There is another drug out there that came along shortly thereafter that is an [anti-PD-1 drug](https://en.wikipedia.org/wiki/Cancer_immunotherapy#PD-1_inhibitors)
- [PD-1](https://en.wikipedia.org/wiki/Programmed_cell_death_protein_1) turns out to be another one of these checkpoints on T-cells,
  - and the [2018 Nobel Prize in Physiology or Medicine](https://www.nobelprize.org/prizes/medicine/2018/press-release/) was actually awarded to the two scientists who discovered CTLA-4 and PD-1
  - Peter believes this is the only Nobel Prize in medicine for immunotherapy (it’s a very big deal)

## Peter presents a paper on immune checkpoint inhibitor therapy in cancer patients [1:50:15]

**This** [**study**](https://www.nejm.org/doi/full/10.1056/NEJMoa1003466) **sought to compare the effect of anti-CTLA-4 to a placebo**

- The placebo in this case was not a real placebo, it was a peptide vaccine called [Gp100](https://en.wikipedia.org/wiki/Gp100:209-217(210M))
- This study **asked the question**: in patients with metastatic melanoma, what would be the impact on median survival and overall survival?
- Peter used to read these papers a lot, it was his bread and butter, but he doesn’t read them that much anymore
  - So it was kind of amazing how long it took him to remind himself of stuff he used to remember

**You have to go back and read the methods and figure out who were the patients in this, what was the eligibility criteria, why did they do it this way?**

- First, these are all patients who had progressed through every standard therapy
  - So these are patients for whom there were no other options
- These patients either had very advanced [stage III](https://en.wikipedia.org/wiki/Cancer_staging#Overall_stage_grouping) melanoma, which means it was local regional melanoma, but it couldn’t be resected
  - An example of that would be a cancer that was completely engulfing
  - Let’s say the primary site was the cheek and it had completely grown into all of the surrounding soft tissue
    - It hadn’t spread anywhere, but it was all the lymph nodes of the neck
    - Peter has seen patients like this and it’s just completely disfiguring
    - And they’d already been through the standard chemotherapy and nothing was working and the thing was growing
- It was mostly made up of patients with [stage IV cancer](https://en.wikipedia.org/wiki/Cancer_staging#Overall_stage_grouping)

**Melanoma staging system**

- In cancer, we typically talk about something called the [TNM staging system](https://en.wikipedia.org/wiki/TNM_staging_system)
  - It is the standard way that cancers are staged
  - T refers to the tumor size
  - N refers to the lymph node status
  - M refers to the presence or absence of metastasis
- For most cancers, it is a very simple system
  - T is typically a number 1, 2, sometimes up to 3 and 4
  - N is typically 0, 1, or 2
  - M is 0 or 1 (either there’s no mets or there are mets)
- For example, in colorectal cancer, the T staging determines the depth in the colon wall that it went
  - N is: did it go to metastasis?
    - Peter thinks colon has N 0, 1, or 2 depending on how many lymph nodes [the cancer spread to]
  - M 0: did it go to anything beyond that, like to the liver, lung, etc, or not?

*Melanoma is a bit more complicated*

- It has M0 meaning no metastasis, but it also has M1a, M1b, M1c, and M1d
  - And within each of those it has a threshold for high and low [lactate dehydrogenase (or LDH)](https://en.wikipedia.org/wiki/Lactate_dehydrogenase#Testing_in_cancer)
- So it’s both a staging based on imaging and biochemical [analysis]
- The reason for that is LDH level is such a strong prognostic indicator of survival, in addition to M staging
  - **Higher LDH levels** tend to reflect more acidity, which we talked about why that’s problematic, tends to reflect faster growing tumors, higher turnover, higher metabolic activity
- M1as are cancers that have metastasized to surrounding soft tissue or soft tissue anywhere in the body
  - So anywhere else on the skin
  - And you might think, “*Well, that’s kind of crazy. How does that happen?*”
    - And it’s really bizarre, you can have a patient who had a melanoma that showed up in one part of their body, and then they have metastasis on other parts of their skin
- M1b, Peter always get b and c confused
  - He thinks b is the lung
- M1c is metastasis to any internal organ, so the liver etc.
- M1d is metastasis to the CNS

***As those numbers increase, as those letters increase, the prognosis gets lower and lower and lower***

**The patient population in this study**

- One of the first things Peter always looks at when he looks at a paper like this is, tell me about the patient population?
  - What was the breakdown of patients?
  - In clinical papers like this, table 1 is always baseline characteristics [shown below]

![](https://peterattiamd.com/wp-content/uploads/2024/01/f14-huberman3.png)

**Figure 14. Baseline characteristics of patients (table 1)**. Image Credit: [*NEJM* 2010](https://www.nejm.org/doi/full/10.1056/NEJMoa1003466)

**About the study design**

- This was done as a 3 to 1 to 1 randomization
- In the simplest form, the study would have 2 groups (a treatment group and a placebo group)
- But in this arm you had 3 groups with 1 of them being the placebo
- The placebo got just Gp100 (which is just a cancer vaccine)
  - This is a cancer vaccine that never showed any efficacy
  - It was a cancer vaccine that had been tested both with interleukin-2 directly and as an adjuvant for patients who had melanoma resected who were tumor free and then given the vaccine as adjuvants to see, did that have an effect on outcomes (and it didn’t)
  - So it’s kind of a known placebo
- So you had that group, then you had the anti-CTLA-4 group, and then you had anti-CTLA-4 plus Gp100

Andrew asks, “*What’s the rationale for the 3 to 1 to 1?*”

- It basically increases statistical power
- This total study was a little under 700 people
- They put 400 in the anti-CTLA-4 plus Gp100 group, and then a little over 130 in each of the other two groups
- So you’re always going to be able to make these two comparisons
- **What you can check by doing this**: is there any effective Gp100 in this setting, which had never been done before?
- **Gp100** is a known protein expressed by melanoma, and all of these people were haplotyped to make sure that their immune system would recognize it
- The question was, would giving people anti-CTLA-4 (i.e., taking the brakes off their immune system) with or without Gp100 make a difference?

**What we can learn from table 1**

- Going through this, you can see it sort of skews about 60% to 40% male to female
- They talk about something called the ECOG performance status: that refers to how healthy a patient is coming in
  - ECOG zero is no limitations whatsoever, which is kind of amazing when you really consider something
    - This speaks to just how devastating this disease is
    - These are patients who all have 6 months to live, a year max, and yet look at this, 58-60 percent of them have no limitation on their quality of life at this very moment
  - ECOG 1 has some limitation
  - You can see that ECOG 1 + ECOG 0 is basically 98% of the population
- You can see the staging there
  - Very, very few of these patients are the M 0 category
    - M zeros are people who have stage III disease that is so aggressive, it can’t be resected
    - That’s about 1%
    - But the majority of these people are the M1a, M1b, M1c

***These are people with very aggressive cancers***

- You can also see that about 10-15 percent of these people also have CNS metastasis ‒ the poorest prognosis of the poor
- You can see about 40% of them have the LDH level above cutoff

***All of this is to say we’re talking about a group of patients who have a very high likelihood of not surviving more than a year***

- Basically more than 70% of these people have visceral metastasis
- A third have high LDH, and more than 10% have brain metastasis
- They’ve also all progressed through standard therapy
  - And the chemo for melanoma can be a toxic chemo that really just doesn’t really do anything

**Andrew asks, “*****Is it commonplace to use a treatment that failed in clinical trials as a placebo in these sorts of studies?*****”**

- Referring to Gp100
- Peter thinks the thinking was, “*Okay, it hasn’t been effective in other treatments. For example, when combined with IL-2 or as an adjuvant, but never before has it been tried with a checkpoint inhibitor (which is the technical term for this type of drug).*”
- There was also some belief that it would be easier to enroll patients
  - Peter doesn’t think they stated this, but that’s often the case
  - It would be easier to enroll patients if they would know that even in the placebo arm, they’re still getting an active agent
- There’s always the possibility that the combination of the failed drug with a new drug would work
  - So you’re increasing the probability for novel discovery
- If you go back to the randomization of 3:1:1, it’s really only 1/5th (or 20%) of the participants that would get just the Gp100
  - So in other words, you’re basically telling people when they come into this study, “*There’s an 80% chance you’re going to get anti-CTLA-4.*”
  - That’s a much better set of odds than your typical study where you’re going to be 50% likely to get the agent of interest
  - And people who are literally dying of cancer, they don’t want to be in the control group

## Unpacking the results of the checkpoint inhibitor trial [1:59:45]

**The primary outcome for this study actually changed in the study**

- They have to get permission to do that
- The original primary endpoint was the best overall response rate

*Peter explains how response rates are measured*

- This is a bit complicated
- All of these patients, by definition have measurable visible cancer, by visible either on the surface of their body body, but more likely on an MRI or CT scan
- All of these patients had to be scanned head to toe within 12 weeks of enrollment

***When a study like this takes place, it usually takes place over many years***

- So it’s not the case that all 700 of these patients were enrolled on the same day and finished observing them on the same day
- This took place for a very long period of time
- This took place across tens of centers
- And so every center really needs to adhere to a very strict protocol
- And you have a central organization that is running this
- A drug company (Bristol Myers Squibb) that makes the drug, they provide the drug
- A CRO (a clinical research organization) is basically managing the trial
- Enrollment was completed for this in 2008
- It probably started in about 2004, 2005
- Therefore you had to kind of have real clear protocols around this

**There are 3 responses: complete response, partial response, and no response**

- A **complete response (CR)** is the easier of these to understand: everything vanishes completely
  - That’s very rare in cancer therapy
  - So instead, what we look for is a partial response
- A **partial response (PR)**: A partial response is at least a 50% reduction by diameter
  - There are different ways/ criteria to define this, but this is the most common way you define a partial response
  - Remember, in this type of imaging, you’re looking at 2D versus 3D
    - So if you’re looking at a lung lesion and it’s this big, if it’s two centimeters long, it has to go to at least one centimeter in diameter
    - So it’s a 50% reduction at least of every single lesion with no new lesions appearing and no lesions growing
  - It’s very strict criteria, right?

***CR means everything vanishes, and PR means at least a 50% by diameter***

- PR is a much bigger reduction in terms of tumor volume when you consider the linear versus the third power relationship of length and volume of every single lesion with nothing new appearing regardless of how small and no lesion growing
- You have **no response (NR)** or progression

*Initially, the primary endpoint of this was going to be the best overall response rate*

- What was the proportion of patients that hit PR?
- What was the proportion that hit a CR?
- That’s very common in this type of paper where the outcomes are typically so dire

*An amendment was made to change the primary endpoint to overall survival at some point during the study*

- That tends to be the metric everybody cares most about
- The **overall survival for metastatic melanom**a is zero, with the exception of people who respond to high dose interleukin-2, and that will boost the overall survival rate to somewhere between 8-10 percent (very, very low)
- These patients, many of whom had already taken and progressed through interleukin-2 (about a quarter of these patients)
  - And by definition, the fact that they’re in this study means they had already progressed through that, and that treatment had failed

**Figure 1**

![](https://peterattiamd.com/wp-content/uploads/2024/01/f15-huberman3.png)

**Figure 15. Kaplan-Meier curves for overall survival and progression-free survival (figure 1)**. Image credit: [*NEJM* 2010](https://www.nejm.org/doi/full/10.1056/NEJMoa1003466)

- Figure 1 is a figure that probably looks really familiar to people who look at any data that deal with survival
  - It’s called a Kaplan-Meier Survival Curve
- On the X-axis for this curve is time, and time here is shown in months
- On the Y-axis is the overall survival: at the very top 100%, and at the bottom, 0%
- It has three graphs (or three curves) that are superimposed on one another for each of the three groups
  - 1 – The control group, which is the Gp100
  - 2 – Anti-CTLA-4 group by itself [Ipi]
  - 3 – Anti-CTLA-4 plus Gp100 [Ipi plus Gp100]
- One of the characteristics of a Kaplan-Meier curve is by definition, they have to be decreasing in a monotonic fashion because it’s **cumulative overall survival**
  - That just means it can’t come down and go back up (nobody comes back to life)
  - Once a person dies, they are censored from the study and the curve drops and drops and drops
- It makes the graph a little harder to read when they put some of those marks on there to highlight
- But what really becomes clear when you look at this is that there’s a clear distinction between the curve for the placebo group (the Gp100 group) and the other two (the two treatment groups)
- Notice at the very end that the two treatment groups appear to separate a little bit (we’ll come back to that)

**When Peter looks at figure 1 [above], the first thing he always turns his attention to is the right-hand side of the graph**

*What is that really telling you?*

- The tail of this is showing the true overall survival
- In the Gp100 group (the placebo group), it is kind of amazing to think that there is still one person who is alive at 44 months
- The next thing he asks himself is, “Well, how long did half of the people make it?”
  - That’s called **median survival**
  - To do that, you go up to the Y-axis and you draw a little line from the 50 over and then you bring that down
    - That’s awfully low
  - The table will tell us exactly what that is because it’s really hard to eyeball that stuff
- There’s always a table that will accompany these things [table2: survival, response to treatment, and time to events; shown below]

![](https://peterattiamd.com/wp-content/uploads/2024/01/f16-huberman3.png)

**Figure 16. Survival, response to treatment, and time-to-event data (table 2)**. Image credit: [*NEJM* 2010](https://www.nejm.org/doi/full/10.1056/NEJMoa1003466)

- There is also 2 subgroup analysis of overall survival [figure 2 below]

![](https://peterattiamd.com/wp-content/uploads/2024/01/f17-huberman3.png)

**Figure 17. Subgroup analysis of overall survival (figure 2)**. Image credit: [*NEJM* 2010](https://www.nejm.org/doi/full/10.1056/NEJMoa1003466)

- Peter likes to staple table 2 and figure 2 together
  - Andrew likes writing in the margins and using little mini clips
- That one person who is still alive in the treatment group is not a complete responder
  - Because under evaluation of therapy in table 2 it says, “Best overall response,” and “Complete responders, 0”
  - There were zero complete responders in the placebo group
  - There were 2 partial responders
    - **Partial responder**: some lesions got smaller, some got bigger
    - **Stable disease**: it didn’t really change that much
    - **Progressive disease**: it went beyond

Andrew asks, “*When you say partial response, lesions got smaller, are they literally just tracing the circumference of one of these skin lesions and saying, ‘Okay, it got bigger, smaller,’ just morphology?*”

- Yes
- Andrew thinks this feels so crude in terms of modern medicine to simply measure a lesion and notice that it grew from 3 mm to 6 mm, literally drawing boundaries around little blotches on the skin
  - But it makes total sense
- Peter points out that most of this measuring is happening in the radiologist suite because most of the disease for these patients is inside the body
  - Most of this is looking at a CT scan or an MRI for the brain
  - More than 70% of these patients had visceral metastasis: liver, soft tissue, lung, brain
    - And if you include lung, liver, brain, and viscera, it’s pretty much *all* the patients

**The median response rate should be shown pretty prominently**

- But it’s on page 715 of the paper
- 10 months was for the anti-CTLA-4 plus Gp100 and 6.4 months for the Gp100 alone (that’s the control
- 10.1 months for the anti-CTLA-4 alone ‒ Peter is always going back to the paper to ask, “*Does that make sense?*”
  - And yeah, Andrew said median survival was about 8
  - It turns out it’s actually 6 and change because it has that little ding in it, and it’s out to a little past 10 on the 2 others

**The net takeaway here is so profound**

- 50% of the patients in the control group were dead in 6 months
- 50% of the patients in both treatment groups, were dead in 10 months

***What that means in cancer speak is these drugs extended median survival by 4 months***

- That’s an important concept when we think about how has cancer therapy changed over the past 50 years

**Advances in cancer therapy in the past 50 years [and where progress is lacking]**

- Median survival for metastatic cancer has increased across the board
- A person today with metastatic colorectal cancer, or a woman today with metastatic breast cancer or a person with metastatic lung cancer, these people will live longer with those diseases today thanks mostly to treatments
  - This is not an early detection lead time bias issue
- This is treatments are allowing people to live longer
  - And that’s an important part of the story, but it’s only half of the story
- The other half of the story (and what Peter thinks is more important) is what is **overall survival** doing?
  - If you go back to those cancers, the answer is zero

***Overall survival hasn’t changed for solid epithelial tumors: it was 0% in 1970 and it’s 0% today (everyone dies)***

- There’s those niche examples Peter mentioned
  - Testicular cancer is now an exception
  - GI stromal tumors would be an exception
  - He’s not including leukemias and lymphomas, where now there are exceptions

**Look at the tail of the graph in figure 1**

- Andrew points out that all but 1 person in the placebo group is dead
  - They’re all dead at 44 months
- But when you look at how long it takes for everyone to be dead in the treatment groups, it’s 53-54 months
  - And they’re not dead; they’re hanging in there
- Andrew is someone who lost 2 of 3 scientific advisors to cancer (the other was lost to suicide)  [discussed in [episode #249](https://peterattiamd.com/andrewhuberman/)], and **having an extra 8-10 months** with your kids or with your spouse, or to “get your affairs in order” is a big deal
  - Those 2 cancers were due to [*BRCA2* mutations](https://en.wikipedia.org/wiki/BRCA_mutation)
- Peter points out that when the observation period stops, some of these patients are still living

***Overall survival is the most important metric and it’s the highest bar***

- It’s certainly *not* the bar any drug company is ever going to want to talk about for a cancer drug
  - Because none of [the drugs] work
  - They only want to talk about extending median survival
- Peter explains, “*It’s a real racket in oncology today where drugs that are extending median survival by 4 weeks are being put on the market at a tune of $50,000-100,000 per treatment*.”
  - That’s not uncommon in oncology
  - There was one drug that was approved for pancreatic cancer., and Peter believes it extended median survival by 9 days, and it cost $40,000
    - That was a statistical significant improvement in median survival
- It’s really understandable why people are very skeptical of the pharma industry, and Peter thinks a much more nuanced view is necessary
  - Clearly, he doesn’t think pharma is all bad
  - But he really understands why people lose faith in pharma when these types of products somehow make regulatory approval

**Andrew asks, “*****Does insurance cover these kinds of drugs?*****”**

- It often does
- It depends on the FDA approval and the indication
- There’s a societal cost to these things, but there’s also a patient cost
- A lot of times insurance doesn’t fully cover it and a patient has to bear the cost difference
- That on top of the question, “*What if your quality of life is dramatically compromised as a result of this treatment?*”
  - And yes, statistically you’re going to live 9 days longer or 3 weeks longer, but at what cost to your health in those final remaining days?
  - And by the way, you’re potentially straddling your loved ones with enormous debt in your absence
  - It’s a super complicated topic
- Andrew adds, “*There’s a dignity component too*.”
  - He’s seen this in people dying, at some point they become such a diminished version of their former selves that they don’t want to be seen by people that way

## Other noteworthy observations including the differing results between males and females [2:15:30]

- This paper is not the one that shows it
- The reason Peter chose this paper is because it was the 1st approval
- A 2nd drug came along that is an [anti-PD-1 drug](https://en.wikipedia.org/wiki/PD-1_and_PD-L1_inhibitors) (called [Keytruda](https://en.wikipedia.org/wiki/Pembrolizumab)), and that drug turned out to be even better
  - It has even a greater response rate both in terms of median survival and overall survival
- But this was the landmark paper
- Peter also has a slight bias here (and he’ll disclose in a moment why), but he thinks it talks about very interesting biology

**A couple of things that stuck out to Peter in this paper**

- The first thing that stuck out to Peter, and the authors *didn’t* comment on it (unless they did and he missed it), is look at figure 2 (the subgroup analysis) where you are showing a similar graph to the one you showed earlier

![](https://peterattiamd.com/wp-content/uploads/2024/01/f18-huberman3.png)

**Figure 18. Subgroup analysis of overall survival (figure 2)**. Image credit: [*NEJM* 2010](https://www.nejm.org/doi/full/10.1056/NEJMoa1003466)

- Earlier they talked about the change in response rate between the groups and put error bars on it
- This is a **95% confidence interval**
  - So does it touch the unity line?
- These are called **tornado plots** typically
- What you’ll notice is that in the top it’s comparing the anti-CTLA-4 [Ipi] with GP-100 versus the GP-100 [placebo alone]
- And in the bottom you’re looking at the anti-CTLA-4 versus GP-100

***At a glance you can see GP-100 is not doing anything ‒ that’s the first takeaway of comparing A to B***

- What Peter finds *most interesting*: look at the subgroup analysis of females

***Notice that in females, while there’s a trend towards risk reduction for overall mortality***

- Peter restates that the primary outcome of this trial was changed to overall survival
  - Which he thinks is the better outcome

***Overall, for all patients, when you compare anti-CTLA-4 plus placebo versus placebo, there was a 31% risk reduction in overall mortality***

- That’s the mathematical interpretation of what you’re seeing at the tail end of that Kaplan-Meier curve
- Patients receiving anti-CTLA-4 are living longer, and that sounds like a big difference
  - You’re really looking at basically 0% surviving in the placebo group versus 20% of people are still alive at 56 months in the treatment group
- But look, that means 80% have died
- When you just look at the anti-CTLA-4 plus GP-100 in the subgroup B, that hazard ratio is even showing more compression
  - It’s a 36% reduction in risk of death

**But notice that the females did** ***not*** **reach significance**

- In the first group, they barely do
- And you can see that because the confidence interval runs from 0.55-0.92 and notice the error bar almost touches the line
- And in the second one, it does not reach significance at all
- Peter went and did a little reading on this after to ask the question, “*Was this an outlier study?*”
  - And it turned out it wasn’t
  - About half the studies of anti-CTLA-4 did indeed find that the drug was less effective in women than men

*Peter couldn’t find any great explanation for why this drugs was less effective in women, but the most plausible explanations fit into 2 categories*

- 1 – Maybe there are differences in the immune response to the drug, if you’re a man or a woman
- 2 – Dosing: these drugs are not like a pill where it’s like everybody gets 50 mg of this; they’re all dosed based on weight
  - In this study, Peter believes the drug was dosed at 3 mg/kg
  - And because most men are heavier than women, men are getting a higher dose than women
  - Weight and body surface area and immune system, these things are not all perfectly linear
- Peter wonders if this difference [in survival] is simply explained by men on average getting a higher dose than women

## Adverse effects resulting from treatment with an immune checkpoint inhibitor targeting CTLA-4 [2:20:00]

- The last thing Peter wants to talk about here is in table 3 ‒ always an important table to look at in any paper
- This table shows what are the **adverse outcomes**?
  - Where are the adverse effects of the drug?

![](https://peterattiamd.com/wp-content/uploads/2024/01/f19-huberman3.png)

**Figure 19. Adverse events (table 3)**. Image credit: [*NEJM* 2010](https://www.nejm.org/doi/full/10.1056/NEJMoa1003466)

- Andrew confesses, “*I definitely don’t want cancer to the extent that I can avoid it, but this table made me wonder whether or not I would also want to just avoid cancer treatment given the life extension provided. I mean, these adverse events are pretty uncomfortable.*”
- Peter puts it in perspective: you always have to be mindful of how many of these adverse events are occurring in people just because they’re disease is progressing

**The first thing Peter always wants to look at is total adverse events in all 3 groups**

- Grade 3 and grade 4 are real toxicities
- Grade 4 toxicity is life-threatening toxicity; grade 3 is pretty significant toxicity
- Grade 1 and 2, that’s not that severe: a little rash, put some corticosteroids on it, went away kind of thing
- In the treatment plus GP-100 group, 98.4% of people reported some event
  - So all but 1.6% reported an adverse event
- In the anti-CTLA-4 group alone, it was 96.7%
  - So only 3.1% did not
- But in the placebo group it’s 97%

***Keep in mind, everybody’s having some adverse effect***

**Looking at just the most severe events**

- Let’s just talk about grade 4 toxicities
- There were 6.1% of those in the placebo group, 8.4% in the anti-CTLA-4 group, and 6.8% in the combined group
  - So not a huge difference in grade 4 toxicity

Andrew asks, “*Meaning that whatever adverse events are occurring may not be related to the treatment?*”

- They may not be related to the treatment
- It’s a very awful, sad, morbid thought to imagine: you’re looking at the adverse responses of people more than 80% of whom died during the course of a very, very short study
- It’s very difficult to disentangle what effects or what side effects a person is having just from that process, as they are from the actual treatment

**An area where there’s a really clear difference in side effects**

- It’s down in the autoimmune category ‒ if you look at any **immune-related events**
- You can see in groups receiving anti-CTLA-4 about 60% in both of those treatment groups [had an *immune-related event*] versus 30% [in the placebo group]
- And if you look at the *grade 3 and 4 toxicities*: it’s 10% in the anti-CTLA-4 plus Gp100, 15% in the anti-CTLA-4 alone group, and only 3% in the placebo
  - That’s a real difference
- Andrew thinks it makes sense that people getting this drug would have autoimmune issues because it’s an immunomodulator
- Peter explains that anti-CTLA-4 is taking the ‘breaks’ off the immune system

Andrew asks, “*Pruritus, is that an irritation of the skin?*”

- Andrew’s not a physician, but he knows that any “itis” is going to be inflammation, and “oma” is likely a cancer or cell replication
- Peter explains, “*Yeah, irritation of the skin*.”
- Peter points out the gastrointestinal differences and the vitiligo (3.7%, 2.3%, 0.8%)
  - The GI stuff is the most common stuff you’re going to see there
  - Colitis and diarrhea ‒ so significant
    - These patients require IV fluids

**What you don’t see here is how many of these patients actually required** [**corticosteroids**](https://en.wikipedia.org/wiki/Corticosteroid) **to reverse the autoimmunity**

- A lot of times what’ll happen with these drugs is the autoimmunity becomes so significant that you have to stop the drug and give corticosteroids
  - Do the exact opposite: you now have to shut the immune system down
  - So you just took the brakes off it with the drug and now you need to shut it down with corticosteroids
- When Peter was in his fellowship, he wrote a [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1473965/) about autoimmunity correlating with response rate in anti-CTLA-4 early on
  - This was during the phase II work
  - The NCI was a very early adopter of participating in these trials
  - This paper was about the hypothesis, “*Is there any correlation between autoimmunity and response?*”
    - And it turned out the answer was yes, there was a very strong correlation
    - This paper looked at 2 dosing schedules: 3 mg/kg versus 1 mg/kg (phase II trial)
    - There was no difference in autoimmunity between the doses, but there was a big difference between the response rate that tied to autoimmunity
  - ***In other words, autoimmunity predicted response***
- Over time, the doctors who administer these treatments are getting better and better at catching autoimmune conditions earlier
  - They can actually be devastating

## Why melanoma is especially responsive to immunotherapy, and the remarkable success story of immunotherapy for pancreatic cancer [2:25:15]

- When [Keytruda](https://en.wikipedia.org/wiki/Pembrolizumab) came out (around 2013-2014), it was for treatment of metastatic melanoma

**Tangent on pancreatic cancer**

- On a very personal note, a friend of Peter’s got pancreatic cancer (the bad type of pancreatic cancer: [adenocarcinoma of the pancreas](https://en.wikipedia.org/wiki/Pancreatic_cancer)) [we’ll come back to that in a minute]
  - This is a non-survivable type of cancer
  - Furthermore, his was unresectable
- About 20% of people who have pancreatic cancer technically have it in a way where you could still take out the head of the pancreas (using the [Whipple procedure](https://en.wikipedia.org/wiki/Pancreaticoduodenectomy))
  - Tragically, most of those patients will still recur
- Andrew’s understanding is that pancreatic cancer progresses from anterior to posterior in the pancreas, and that the Whipple is a removal of the front end, the anterior
  - So if the cancer has progressed far enough coddle into the posterior pancreas, then there’s nothing left to cut out basically

Andrew asks, “*Can we survive without a pancreas for any amount of time?*”

- Oh yeah, absolutely

Follow-up question, “*So why don’t they just remove the whole pancreas?*”

- That’s Peter’s point: it’s already micro-metastasized
- The surgical procedure is not the challenge anymore
  - It used to be
  - At Johns Hopkins, which is one of the hospitals where this was pioneered, the 30-day mortality for a Whipple procedure was around 80%
    - The reason was the pancreas is such an awful organ to operate on, because its enzymes are designed to digest anything and everything
    - So imagine now you have to cut the pancreas in half, take out the head of the pancreas with the duodenum, and then somehow sow that open half of a raw pancreas to the end of the jejunum and not let it digest itself
  - At Hopkins is where they figured out the way to put drains in the surgical technique, how to do it in two layers, what type of stitches to use
  - All of the nuances of this were worked out in a few places
  - Even 25 years ago at a major center like Hopkins, the mortality of that procedure was <1%
- The point is, this surgery is no longer the bottleneck (taking out the pancreas safely, as complicated and challenging as that is)
- If you need a Whipple procedure, you only want to have it done by someone who just does that night and day
  - You don’t want weekend warriors doing it
- That’s not why people are living or dying

***They’re dying because the cancer just comes back***

- It was already spread to the liver by the time you did the surgery, you just didn’t realize it yet
- So whether you took out the whole pancreas or the head of the pancreas or the tail of the pancreas, the location of the tumor is predictive of survival only in the extent that it basically is a window into how soon did symptoms occur

***Pancreatic cancers in the tail tend to be more fatal, even though they’re way easier surgically to take out, because by the time you develop symptoms of a tail pancreas cancer, it’s a big cancer***

Andrew asks, “*Given the link between the immune system and these cancers, is there an idea in mind that people who are, let’s say, 40 and older (or 50 and older) who they’re not diagnosed with any cancer, would periodically just stimulate their immune system to wipe out whatever early cancers might be cropping up? Just take a drug to just ramp up the immune system even to the point where you start having a little diarrhea, maybe a few skin rashes, and then come off the drug. Just basically to fight back whatever little cell growths are starting to take place in skin or liver for three weeks out of each year? I mean, why not?*”

- Peter thinks this is an interesting question
  - He has never thought of it through that lens

**The question is, “*****What can we do to keep our immune systems as healthy as possible as we age?*****”**

- Andrew’s answer, “*Stay on a normal circadian schedule; there’s evidence for that*.”
- Peter agrees, there’s evidence that certainly if it promotes sleep, anything that promotes better rest is going to promote immune health
- Because if you ask the macro question, which is, “*Why does the prevalence of cancer increase so dramatically with age?*”

**There are certain diseases where it’s really obvious why the prevalence of the disease increases with age**

- Age-related [macular degeneration](https://en.wikipedia.org/wiki/Macular_degeneration)
- [Cardiovascular disease](https://peterattiamd.com/category/diseases/heart-disease-prevention/) is by far the most obvious because it’s an area under the curve exposure problem
  - The more exposure to lipoproteins and the more the endothelium gets damaged, the more likely you are to accumulate plaque
  - It totally makes sense why 10 year olds don’t have heart attacks and 80 year olds do
- But when you acknowledge that, well, hey, anybody’s accumulating genetic mutations, we’re always surrounded and being bombarded by things that are altering the genome of ourselves, is it simply a stochastic process where the longer you live, the more of these mutations you’re going to occur until it some point one of them just wins?
  - Peter thinks that’s got to be a big part of it

***Another part of it is that our immune system is getting weaker and weaker as we age***

- Clearly he’s not alone in thinking this
- People become more susceptible to infections as they get older
- That’s equally playing a role in our susceptibility to cancer

**The question is how do you modulate immunity as you age?**

- That is one of the most interesting things about [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) potentially
  - When taken the right way, it seems to enhance cellular immunity [discussed in [episode #272](https://peterattiamd.com/davidsabatini-mattkaeberlein/)]
    - That’s potentially a really big deal
  - At least in short-term human experiments in response to vaccination, it’s enhancing vaccine response
- So the question is, would that translate into cancer? (nobody knows)
  - Could that be one of the reasons why animals treated with rapamycin live longer and get less cancer? (Don’t know)
- It could also be that rapamycin is at a fundamental level that’s targeting nutrient sensing

**To back up:** ***Why melanoma?***

- We didn’t really know this 30, 40 years ago in the early days of immunotherapy, but what we know now is that ***most cancers probably have about 40 mutations in them***
  - Ballpark 40-50 mutations is standard fare for a cancer

> “*But melanoma happens to be one of the cancers that has many, many more mutations, and the more mutations a cancer has, the more likelihood that it will produce an antigen that’s recognized as non-self*.”‒ Peter Attia

- That’s why in the early days of immunotherapy, the only things that worked were IL-2 against metastatic melanoma and kidney cancer
- Because kidney cancer turned out to also be one of those cancers that for reasons that are not clear, produced hundreds of mutations

***And so it’s no surprise that the early studies of checkpoint inhibitors were also done in metastatic melanoma, where you basically have more shots on goal***

- If you’re going to take the breaks off the immune system, you might as well do it in an environment where there are more chances for T-cells to find something to go nuts against

**An interesting example of how this treatment was able to work: Peter’s friend with Lynch syndrome**

- In 2013, Peter’s friend was diagnosed with [Lynch syndrome](https://en.wikipedia.org/wiki/Hereditary_nonpolyposis_colorectal_cancer)
  - Lynch syndrome is one of those few hereditary or germline mutations that results in a huge increase in the risk of cancer
  - This friend had already had stage III colon cancer at about the age of 40, and had survived that
  - Then, five years later, he developed pancreatic cancer
    - And when he went to see the surgeon, they said, there’s nothing we can do; it’s too advanced
    - To put that in perspective, that is a death sentence
    - That’s a six-month survival
- And at around that time, there was a study that had come out in the *New England Journal of Medicine* that had talked about how patients with Lynch syndrome had **lots of mutations** [also discussed in [*Nature* 2012](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3401966/)]
- Peter explains that they talked with his doctors about the possibility of enrolling him in one of the Keytruda trials (one at Stanford)
  - The thinking being, you would want to target a checkpoint inhibitor against somebody who has a lot of mutations
    - And even though typically we don’t see that in pancreatic cancer, his is a unique variant of it because it’s based on this
- Sure enough, he was tested for these mismatch repair genes
- He enrolled in the trial, and amazingly had not only a complete regression of his cancer, but he’s still alive and cancer-free today 10 years later
- But the treatment worked so well at activating his immune system that his immune system completely destroyed his pancreas
  - So he effectively had a pancreatectomy based on his immune system
    - Now he actually has type 1 diabetes, has no pancreas left
    - He has to use insulin

***It’s remarkable that you could completely unleash the immune system of a person and you eradicate the cancer and the rest of the cells around it***

**There are many organs we could live without, and there are certain organs you can’t live without**

- You can’t live without your heart, lungs, liver, kidneys
- But many things that kill people arise from organs [you can live without]
  - The breast
  - Prostate, you could live without all prostate tissue
- What Peter is saying is, “*If you had metastatic cancer and you had a bullet that could selectively target a tissue, you would take it.*”
- Right now the only tissue we can do that against is a [CD19 B cell](https://en.wikipedia.org/wiki/CD19#Cancer), and that’s what those [CAR T cells are](https://en.wikipedia.org/wiki/CAR_T_cell)

***Right now, these are not tissue-specific treatments, but they’re mutation-specific***

## Why immunotherapy may be the most important hope we have for treating cancer [2:35:30]

**The last thing Peter found interesting in this paper**

- Peter was surprised they didn’t comment on if there was any correlation between autoimmunity and response
  - They obviously acknowledged the autoimmunity in table 3
  - He would’ve loved to have seen a statistical analysis that said if there any correlation between response rate and autoimmunity
  - “*So we’re left wondering what the current state of that is*.”

***The reason Peter thought this was an interesting paper to present is that he still believes that immunotherapy is probably the most important hope we have for treating cancer***

- While we’re still only scratching the surface of it, collectively, the overall survival increase for patients with metastatic solid organ tumors is about 8% better than it was 50 years ago
- Virtually all of that improvement has come from some form of immunotherapy (that is promising)
- The holy grail (meaning the next step, if you go back to where we started the discussion) is coming up with ways to engineer T-cells to be even better recognizers of antigens
  - And there’s many ways to do that
  - One is to directly engineer them
  - Another is to find T-cells that have already migrated into tumors
    - Those are called [tumor infiltrating lymphocytes (or TIL)](https://en.wikipedia.org/wiki/Tumor-infiltrating_lymphocytes) and expanding those
    - And engineering them to be better and younger

**Andrew asks, “*****Is it possible to engineer our own T cells to be more pH variant tolerant?*****”**

- Meaning, since low pH is cloaking the local area, could we pull some T cells? [explained next]
- Andrew is always thinking about the inoculation stuff
  - Like pull some T-cell as part of our standard exam when we’re 30 and grow some up in an environment that the pH is slightly more acidic than normal and then reintroduce them to the body
    - After all, they are T cells; in other words, give them a little opportunity to evolve the conditions they can thrive in
    - Or even just keep them in the freezer in case we need them
- Peter points out, that we don’t know if simply getting T cells to be comfortable at a lower pH would be sufficient
- There are still so many other things that the cancer is doing as far as using other secreting factors
- It seems that by far the most potent thing comes down to expanding the number of T-cells that recognize the antigen and making sure that you can get that number big enough without aging them too much
  - So in some senses, it has become a longevity problem of T-cells

***The way to think about it is you want an army of soldiers who are wise enough to recognize the bad guys (which comes with age), but young enough to go and kill***

- And right now, both extremes seem to be unhelpful
- When you go and find tumor infiltrating lymphocytes in a tumor, they’re very wise
  - They’ve demonstrated that they can do everything
    - They can outmaneuver the cancer
  - But they’re too old to do anything about it
  - And when you take them out to try to expand them by three logs (which is typically what you need to do, expand them by a thousand fold), they can’t do anything

## Avoiding melanoma: the sunscreen debate, sunburn as the biggest risk factor, and more [2:38:45]

**Andrew asks, “*****What about avoiding melanoma all together?*****”**

- Avoid sunburn

*Somehow Andrew got couched as anti-sunscreen, and that’s absolutely not true*

- He said some sunscreens contain things that are endocrine disruptors
- He’s going to do whole episode on sunscreen
  - Peter was planning something on that as well
- Andrew explains that some very skilled dermatologists reached out and said that indeed, some sunscreens are downright dangerous
- But of course, melanoma is super dangerous
- No one disputes physical barriers for sunscreen
- Everyone agrees that that is unlikely to have endocrine disruption

*But aside from limiting sunlight exposure to the skin, what are some other risks for melanoma?*

- Peter thinks that is the biggest risk factor
- He does not think smoking poses a risk for melanoma, and if it does, it’s going to be very small
- There are hereditary cases
  - One needs to be pretty mindful when taking a family history
- There are really weird genetic conditions that link melanoma to other cancers such as pancreatic cancer
- So whenever Peter is taking somebody’s family history and he hears about somebody that had melanoma and someone that had pancreatic cancer, there’s a couple genetic tests he’ll look at to see if that’s a person that’s particularly sensitive from a genetic predisposition

***Peter thinks melanoma is less about sun exposure and more about sunburn***

- Although it’s not completely agreed upon
- He’s sure there’s somebody listening to this who will chime in and apply a more nuanced response
- There’s a fundamental difference between I’m out in the sun getting sun, making some vitamin D, versus I’m getting scorched and undergoing significant UV damage
- There might also be something to be said for the time in one’s life
- Peter has certainly seen things that suggest that early repeated sunburns would be more of a risk
- It’s not a controversial point in the sense, “*Who wants to be sunburned?*”
- Whatever one needs to do to avoid be sunburned: whether it’s being mindful of what the UV index is, wearing the appropriate cover, wearing the appropriate sunscreen
- Peter also finds the whole anti-sunscreen establishment to be a little bit odd

**Andrew is trying to open the door for a nuanced discussion about the fact that some sunscreens really do contain things like benzines and things that are real endocrine [disruptors], and you’re spraying them on kids**

- But when you look at the good old-fashioned mineral sunscreens, they’re perfectly safe
  - As far as we know… dare we cross the seed oil debate into this
    - Some of the folks who are really anti-seeded oil also claim that seed oils increase risk for [sunburn]
- Andrew explains, “*Peter and I are smiling because we have teed up a debate soon with some anti-seeded oil and less anti-seeded oil experts. So that’s forthcoming. That’s going to be a fun one*.”
- This was Peter and Andrew’s second journal club and they look forward to the third

> “*I hope people are learning and not just learning the information, but learning how to parse and think about papers*.”‒ Andrew Huberman

§

## Selected Links / Related Material

**Andrew’s podcast**: [Huberman Lab](https://hubermanlab.com/) (2023) | [1:15, 3:00]

**First journal club with Andrew**: [#270 ‒ Journal club with Andrew Huberman: metformin as a geroprotective drug, the power of belief, and how to read scientific paper](https://peterattiamd.com/andrewhuberman2/)s (September 11, 2023) | [1:15, 3:15]

**Paper Andrew presents**: [Day and night light exposure are associated with psychiatric disorders: an objective light study in >85,000 people](https://www.nature.com/articles/s44220-023-00135-8) | *Nature Mental Health* (A Burns et al 2023)| [1:30, 22:21]

**Paper Peter presents**: [Improved Survival with Ipilimumab in Patients with Metastatic Melanoma](https://www.nejm.org/doi/full/10.1056/NEJMoa1003466) | *NEJM* (F Hodi et al 2010) | [1:45, 1:46:54]

**First episode of** ***The Drive*** **with Andrew**: [#249 ‒ How the brain works, Andrew’s fascinating backstory, improving scientific literacy, and more | Andrew Huberman, Ph.D.](https://peterattiamd.com/andrewhuberman/) (April 3, 2023) | [3:00, 2:12:45]

**How to offset the negative effects of artificial light exposure at night**: [Early evening light mitigates sleep compromising physiological and alerting responses to subsequent late evening light](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6831674/) | *Scientific Reports* (M Kulve, L Schlangen, & W van Marken Lichtenbelt 2019) | [17:00]

**Lightbulbs for seasonal affective disorder**: [TUO Circadian Smart Products](https://www.thetuolife.com/) | [20:00]

**Effect of light shown behind the knee on circadian rhythm**: [Absence of Circadian Phase Resetting in Response to Bright Light Behind the Knees](https://www.science.org/doi/10.1126/science.1071697) | *Science* (K Wright & C Czeisler 2002) | [21:45]

**Previous study on the relationship between time spent in outdoor light and mood**: [Time Spent in Outdoor Light is Associated with Mood, Sleep and Circadian Rhythm Related Outcomes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8892387/) | *Journal of Affective Disorders* (A Burns et al 2021) | [26:30]

**Episode of** ***Huberman Lab*** **with Alia Crum**: [Dr. Alia Crum: Science of Mindsets for Health & Performance](https://www.hubermanlab.com/episode/dr-alia-crum-science-of-mindsets-for-health-performance) (January 23, 2022) | [59:30]

**Peter’s premium newsletter on all things related to sugar substitutes**: [Sugar substitutes: deep dive into the pros, cons, available options, and impact on metabolic health](https://peterattiamd.com/sugar-substitutes/) | K Birkenbach and P Attia (August 29, 2023) | [1:15:15]

**The Warburg effect is the cell optimizing for cellular building blocks not energy**: [Understanding the Warburg Effect: The Metabolic Requirements of Cell Proliferation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2849637/) | *Science* (Vander Heiden, Cantley, & Thompson 2009) | [1:41:15]

**Autoimmunity correlates with response rate to anti-CTLA-4 treatment**: [Autoimmunity Correlates With Tumor Regression in Patients With Metastatic Melanoma Treated With Anti–Cytotoxic T-Lymphocyte Antigen-4](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1473965/) | *Journal of Clinical Oncology* (P Attia et al 2005) | [2:24:15]

§

## People Mentioned

- [David Berson](https://vivo.brown.edu/display/dberson) (Professor of Ophthalmology and Visual Science at Brown University) [9:15, 1:20:15]
- [Charles (Chuck) Czeisler](https://connects.catalyst.harvard.edu/Profiles/display/Person/24237) (Professor of Sleep Medicine at Harvard Medical School) [18:22]
- [Rick Rubin](https://en.wikipedia.org/wiki/Rick_Rubin) (influential record producer) [55:15]
- [Alia Crum](https://profiles.stanford.edu/alia-crum?releaseVersion=10.5.2) (Associate Professor of Psychology at Stanford University and expert on the placebo effect) [59:30]
- [Samer Hattar](https://www.nimh.nih.gov/research/research-conducted-at-nimh/principal-investigators/samer-hattar) (NIMH chief of section on Light and Circadian Rhythms) [1:04:30]
- [Layne Norton](https://biolayne.com/coach/layne-norton/) (expert in nutritional sciences, and founder of BioLayne) [1:00:45, 1:13:30]
- [Dana Small](https://medicine.yale.edu/profile/dana-small/) (Professor Adjunct of Psychiatry and Director, Modern Diet and Physiology Research Center at Yale School of Medicine) [1:15:00]

- [Iggy Provencio](https://bio.as.virginia.edu/people/ip7m) (discovered melanops and intrinsically sensitive retinal ganglion cells) [1:18:00]
- [David Berson](https://vivo.brown.edu/display/dberson) (discovered melanops and intrinsically sensitive retinal ganglion cells) [1:18:00]
- [Samer Hattar](https://www.nimh.nih.gov/research/research-conducted-at-nimh/principal-investigators/samer-hattar) (discovered melanops and intrinsically sensitive retinal ganglion cells) [1:18:00]
- [Satchidananda Panda](https://www.salk.edu/scientist/satchidananda-panda/) (discovered melanops and intrinsically sensitive retinal ganglion cells) [1:18:00]

§

![](https://peterattiamd.com/wp-content/uploads/2023/04/bio-pic-andrewhuberman-500x500.jpeg)

##### Andrew Huberman, Ph.D.

Andrew Huberman earned his Bachelor’s degree from the University of California, Santa Barbara. He went on to earn a Master’s degree in Neurobiology and Behavior from the University of California, Berkeley, and a PhD in Neuroscience from the University of California, Davis. He completed his postdoctoral training at Stanford University.

Dr. Huberman is currently an Associate Professor of Neurobiology and an Associate Professor (by courtesy) of Psychiatry and Behavioral Sciences at Stanford University. His laboratory studies neural regeneration with the goal of developing treatments to prevent and reverse vision loss. They also study neuroplasticity and circuits for anxiety and visually-driven autonomic arousal.

In 2021 Andrew started the [*Huberman Lab* podcast](https://hubermanlab.com/) where he discusses neuroscience and the connections between the brain, our organs, our perceptions, our behaviors, and our health. This has become one of the top-10 podcasts on Apple Podcasts and Spotify. [[Stanford](https://med.stanford.edu/profiles/andrew-huberman#bio)]

Twitter: [@hubermanlab](https://twitter.com/hubermanlab?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

Instagram: [hubermanlab](https://www.instagram.com/hubermanlab/?hl=en)