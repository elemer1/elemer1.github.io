# #199 – Running, overcoming challenges, and finding success | Ryan Hall

**Source:** [https://peterattiamd.com/ryanhall/](https://peterattiamd.com/ryanhall/)

---

Ryan Hall is the fastest American ever to run the marathon (2:04:58) and half marathon (59:43) and is the author of the book [Run the Mile You’re In](https://www.amazon.com/Run-Mile-Youre-Finding-Every/dp/0310354374). In this episode, Ryan discusses his amazing successes and epic failures during his remarkable running career and what he’s learned through these experiences. Ryan explains not only the physical aspects of running – including his training routine, fueling regimen, and recovery process – but he also emphasizes the mental aspect of the sport. He discusses how accepting and reframing negative thoughts can empower you to take on challenges and reach your potential. Additionally, Ryan discusses the traits that make the best competitors, the keys to overcoming setbacks, and his amazing feat of 7 marathons in 7 days as a goodbye to the sport that gave him so much.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/ryanhall/the_Drive_public.png)

Play

#199 - Running, overcoming challenges, and finding success | Ryan Hall

#199 - Running, overcoming challenges, and finding success | Ryan Hall

1x15s30s

0:002:55:54

## We discuss:

- How Ryan got into running and his formative years of training [4:45];
- The advantages of altitude—living high and training low [9:45];
- Progressive overload, blood flow restriction, and switching up your workout routine [14:15];
- Lessons learned from competing in the Beijing Olympics [16:45];
- Importance of speed, power, and strength for runners [22:15];
- The crazy idea that got Ryan hooked on running [35:15];
- The mental aspect of training and the power of reframing negative thoughts [37:45];
- The importance of fueling, and Ryan’s marathon diet [52:00];
- Boosting performance with Tylenol and keeping core temperature down [59:00];
- Ryan’s early struggles and later success at Stanford [1:09:45];
- Keys to overcoming difficulty: faith, mindset, and being a better teammate [1:15:45];
- Ryan’s professional running career and his discovery of his gift for marathon distances [1:22:00];
- Reflections after breaking the American half marathon record, and challenges faced by retired athletes [1:32:45];
- Ryan’s marathon training regimen at the Mammoth Track Club in 2010 [1:39:45];
- Optimal body weight for competition and the pros and cons of going below your natural weight [1:48:45];
- Training volume, importance of mixing up the intensity level, and zone 2 and zone 5 for longevity [1:53:45];
- The most impactful adjustments Ryan made to his training leading up the to 2011 Boston Marathon [1:58:15];
- A new personal record at the 2011 Boston Marathon and lessons on maximizing your own potential [2:03:30];
- Learning from failure and takeaways from his disappointing performance at the 2012 Olympics [2:12:30];
- Utilizing cardio and strength training for overall health, and how Ryan uses blood flow restriction in his workouts [2:24:45];
- Performance enhancing drugs (or lack thereof) in marathon runners [2:29:15];
- Traits of the greatest marathon runners [2:32:30];
- 7 marathons in 7 days on 7 continents—saying goodbye to the sport [2:38:45];
- Reflections on what running has given Ryan [2:49:30]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Ryan is a retired American long distance runner who holds the US record in the half marathon at 59 minutes and 43 seconds
- He became the first US runner to break the 1-hour barrier
- He also holds the American record in the marathon and is the only American to run sub 2:05, running 2:04:58
- Ryan is generally regarded as one of the greatest American distance runners
- He retired in 2016 after a really difficult 4-year period, following the [London Olympics](https://en.wikipedia.org/wiki/2012_Summer_Olympics), which was plagued by lots of injuries
- He’s really transformed his body in a way that is almost difficult to imagine without looking at a picture of him then versus now
- Ryan now is a coach
  - He coaches his wife, who is also a professional runner, and he coaches runners of all category and talent levels through his training program called [Run Free Training](https://www.runfreetraining.com/)
- He’s written a book called [Run The Mile You’re In](https://www.amazon.com/Run-Mile-Youre-Finding-Every/dp/0310354374/ref=sr_1_1?crid=2JT6MSUTOTJKQ&keywords=Run+The+Mile+You%27re+In&qid=1640010221&sprefix=run+the+mile+you%27re+in%2Caps%2C76&sr=8-1)
- Peter remarks, “*this is one of the few podcasts where I really felt like I came into it with kind of a sense of where I wanted to go and I completely came off that. I never really come into podcast with a list of questions, but I usually have a sense of direction and here I deviated from it completely. I don’t think that’s a bad thing. I think it just speaks to how much I couldn’t stop wanting to get into details of his training and just how intrigued I have been by his transformation.*”
- Ryan is an enormous physical specimen, probably over 190 lbs
  - He is into power lifting and carrying on many extreme feats of physical strength
  - Some of which we talk about, but many of which you can see on [his Instagram account,](https://www.instagram.com/ryanhall3/) which Peter can’t recommend that highly enough
    - It’s just amazing to watch
    - For example, his last one was doing a 500 lb deadlift and then immediately running into a 5-minute mile
      - He didn’t succeed in that
      - He went 5:22 or something, but he’s going to take another shot at it
- We also talk about one of the most crazy of his fitness challenges that he does for himself
- Today he says his testosterone is about a 1000 ng/dL, which places him at about the 90th percentile
- Obviously that’s a testament to how he’s changed his nutrition and the fact that he’s not running 110 miles a week.
- In this episode, we talk about his career, but not in the necessarily in the most linear way
  - His amazing successes and his epic failures
  - What he’s learned through these experiences

> “*I think this is just kind of an amazing interview, even if you’re not a runner. But I think it really talks a lot about the mindset of what it means to be successful.*” – Peter Attia

- Ryan is just an incredibly optimistic person
  - He’s the kind of person who really never seems to let failure get to him in a way that maybe some of us certainly myself would
  - Peter think’s his optimism is kind of what’s allowed him to bounce back from so many setbacks

## How Ryan got into running and his formative years of training [4:45]

- Peter has been a fan of Ryan’s for a long time
- Running is sort of like [F1 racing](https://en.wikipedia.org/wiki/Formula_One_racing)
  - It’s not really popular in the US, but it is becoming more so
  - The Netflix series [*Drive to Survive*](https://en.wikipedia.org/wiki/Formula_1:_Drive_to_Survive) has made F1 very popular
  - People are starting to becomes more aware of runners
    - [Kipchoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge)‘s two hour sub effort kind of got a lot of people in this country excited about it
- Peter’s interest in running began in the early 2000s
  - He use to swim with [Allan Webb](https://en.wikipedia.org/wiki/Alan_Webb_(runner))
    - Allan was this phenom who set the high school record for the mile
    - Peter often swam next to this guy, in the next lane and just became kind of interested in his journey
  - Then Peter learned about Ryan Hall and the other runners of that generation

**Growing up at altitude**

- Ryan grew up in [Big Bear, CA](https://en.wikipedia.org/wiki/Big_Bear_City,_California); it’s at altitude
  - It was a really cool place to grow up
  - It’s 2 hours from the beach
  - It’s one of the few places someone can both surf and snowboard/ ski in the same day
  - He lived a mile away from [snow summit](https://en.wikipedia.org/wiki/Snow_Summit)
- Many of the best runners in the world come from places that are 7,000 feet altitude, such as Ethiopia and Kenya
  - So he found himself in the perfect scenario for a distance runner in the sense of being able to live high and train low
- When he was growing up in high school, his dad was his coach
- His dad started a cross country and track team just so he could run
  - There wasn’t even one available at Big Bear High School
  - The team would drop down twice a week, drive an hour down to sea level, get on a track at sea level, run some super hard interval sessions and then pop back up to altitude
  - This was before research and studies showed how beneficial this kind of training is
  - But they were doing it because it just made sense
  - This  was the environment in which he found himself in

**The benefits of training the cardiovascular system during the formative years**

- It’s pretty crazy to look back on it now and see how things like that really did contribute to the trajectory of his path
- Peter suspects there is something to being in that environment when you’re young, during the formative years of the cardiovascular system
- He looks at his daughter who’s 13 and she loves volleyball and basketball, but doesn’t like cross country or track
  - He’s trying not to be a psycho about it, but he’s also telling her, “*You have this really narrow window in which your cardiovascular system is quite malleable*.”
- He’s very fortunate that because he was involved in boxing when he was young
  - He had to do so much cardio, both aerobic and anaerobic training during those formative years
  - Even though he’s a fraction of that level of fitness today, he can still ride on what he had then
- Peter thinks if one doesn’t push their system hard in the teenage years, it’s very hard to develop it later
  - He doesn’t know if this is true, but this is his impression
- To be able to take this one step further with altitude is unbelievable
- Ryan agrees that the effects of cardio at a young age definitely play on later in life
- Now, for example, Ryan is focused on strength training
  - He is just trying to get as big and strong as he can
  - His weight went up from 167 to 192 over 9 months
  - He was literally doing zero running, none; no other cardio, no biking, no swimming, nothing
    - He hopped on a treadmill at the end of that period when he was at his heaviest, just to see where his mile was at
    - He was going to train for this challenge— he tried this 500 lb deadlift into a sub five minute mile
    - He hopped on a treadmill after his weight session— 5:18 for the mile, with zero training
- Ryan thinks when someone develops their cardio early on, later, they just need little touches here and there
- He takes pretty short rests between a lot of his lifts and he thinks that’s enough to keep him in 5:8 mile shape without even trying
- There are lots of interesting things about how the body develops
  - Kids who are born at altitude and how they have greater potential for cardio-development over time
  - Looking at his family, he’s in the middle of 5 kids
    - His youngest brother, Chad is super into endurance stuff
    - And he was born at altitude, where Ryan was born in [Seattle, Washington](https://elevation.maplogs.com/poi/seattle_wa_usa.474.html)
    - His family moved to [Big Bear, CA](https://en.wikipedia.org/wiki/Big_Bear_City,_California) when he was 5 (elevation 6,772 ft)
  - His brother was a really good runner
    - He won the national championships in high school cross country
    - He went to Oregon on scholarship
  - But between Ryan and him, there’s not a huge difference in their top end potential for cardio

## The advantages of altitude—living high and training low [9:45]

- Peter thinks it is important that he became interested in looking for ways to improve his training, in the years when he was a swimmer
  - He looked at the matrix of living high, living low, training high, training low
  - And coming up with what was the optimal scenario
  - There is a clearer answer to this today than there was 20 years ago
  - Today, the answer is crystal clear— best results are attained from living high and training low, when it comes to intensity
  - It is important to live high and train high for low end aerobic efficiency
  - But one has to train that anaerobic peak at sea level
- Peter remembers swimming up in [Colorado Springs](https://en.wikipedia.org/wiki/Colorado_Springs,_Colorado) at the [Olympic Training Center](https://en.wikipedia.org/wiki/United_States_Olympic_Training_Center) as a guy who lived at sea level
  - He would go there for camps and try to push it hard in Colorado; this was a total waste of time
  - This was the exact opposite of what to do
- He had friends who lived at sea level but they would sleep in oxygen deprivation tents to replicate living in altitude, so they could train at sea level
- How Ryan grew up was the perfect way to do this; they accidentally discovered the efficacy of living high and training low
- Ryan notes that it felt good; anytime he would pop down to sea level to do track workout, it was as Peter described
  - This was different from training at altitude, running 400 meter repeats on short or longer aerobic efforts
  - Or trying to do the mile reps super fast at altitude
  - The workouts have to be structured different at altitude
    - He does a lot of intervals when training at altitude, just to break things up
    - For example, he would run a bunch of 200s on really short rest
- At sea level, one can spend a lot of time at race pace, working on that turnover, which just can’t be done at altitude without breaking it up more
  - Going down to sea level for workouts felt really good, it worked, and the results were obvious
- His wife [Sara](https://en.wikipedia.org/wiki/Sara_Hall) is a professional marathon runner, she grew up at sea level in Santa Rosa, CA
  - She’s run 2:20 for the marathon, which is the second fastest ever by an American
- Thinking of altitude, there is also the effect of how many years someone has spent in altitude
  - For example, he is super good at altitude in terms of running
  - He can run pretty close to his sea level times at 7,000 feet altitude for a marathon

**Marathon training** [12:30]

- One of the most important things about marathon training is someone’s threshold
- For a 15 mile threshold, he just runs 15 miles at the marathon intensity
- He could run 12, 15 miles at 4:48 per mile, which is about marathon pace at 7,000 feet
- If he pops down to sea level, maybe he runs a 4:42 pace, 4:40 pace, but he didn’t get a huge conversion from altitude to sea level
- Whereas someone like his wife, Sara, who wasn’t as accustomed at altitude, she’ll get maybe 20 seconds a mile where she’s running that much slower at altitude than she would at sea level
  - But she’s gotten better as she’s spent more time at altitude

**Benefits his wife, Sara, has seen living at altitude**

- They moved to [Mammoth Lakes](https://en.wikipedia.org/wiki/Mammoth_Lakes,_California) (elevation 7,880 ft) out of college after they graduated from [Stanford](https://en.wikipedia.org/wiki/Stanford_University) in 2005
  - She hated living in Mammoth, at 8,000 feet for such a long time
  - But gradually over time, she’s gotten much, much better at altitude
  - Probably still not as good as he was when he was in his prime, but now they have to even go up to higher altitudes to get similar effects to what they were getting before
- They have a place in [Crested Butte, Colorado](https://en.wikipedia.org/wiki/Crested_Butte,_Colorado), where they’re sleeping at 9,400 feet
  - Every time she goes up there, they see a massive jump in her fitness just from doing a month up there
- One has to keep playing with it because the science is there and his experiences are true, but also the body is dynamic
  - The body is always changing
  - One just can’t repeat the same thing over and over and over again
  - The body is always changing, always adapting

## Progressive overload, blood flow restriction, and switching up your workout routine [14:15]

**The importance of switching-up training to see growth**

- That’s a big thing he’s learned lifting weights; if he’s just doing the same lifting all the time and not trying new mechanisms to add weight to the bar, or different tactics, he’s just not going to see growth
- That is the fun of running, training, lifting— it’s all a giant experiment; he’s always tweaking little variables
  - He loves to see growth
  - He loves the frustration of not seeing growth, of getting black toes and thinking “*What is going on right now?*”
  - His mind will chew on this for months, and he’ll make little tweaks until he finds it

> “*Then you find it, and bang! It clicks, whether it’s in the weight room or running all of a sudden you’re doing what you couldn’t do before*” – Ryan Hall

**Progressive overload**

- Peter notes that [progressive overload](https://en.wikipedia.org/wiki/Progressive_overload) is one of the hardest things to do when one is training themself, as most people are
  - Most of us we’re just weekend warriors and we’re sort of our own coaches and it is very easy to get comfortable
  - The challenge of being able to progressively overload doesn’t always mean weight; it can mean sets, reps, reduction in rest time
- Recently Peter has become obsessed with [blow flow restriction (BFR training)](https://en.wikipedia.org/wiki/Blood_flow_restriction_training) and weight training; that becomes another way to progressively overload, using a fraction of the weight one would normally use
  - See podcast [#179 – Jeremy Loenneke, Ph.D.: The science of blood flow restriction—benefits, uses, and what it teaches us about the relationship between muscle size and strength](https://peterattiamd.com/jeremyloenneke/) (Oct 11, 2021)
  - Also check out [AMA #32](https://peterattiamd.com/ama32/) to see how Peter incorporates BFR into his workouts
  - Ryan notes he has been using BFR training too

**Recovery from injury** [16:00]

- BFR training is helpful for runners, especially after he got hurt
  - Ryan was training for the Beijing Olympics
  - He was at the [Olympic training center](https://en.wikipedia.org/wiki/United_States_Olympic_Training_Center) at [Chula Vista](https://en.wikipedia.org/wiki/Chula_Vista,_California), working with a strength coach
  - He was on one of those vibrating platforms to warm up for squatting
    - They were great; he was able to warm up and get into a much deeper squat than he ever had gotten into before
    - But as a runner (most runners are super tight), the ankle mobility wasn’t there
  - He should not be down in a butt to the ground squat; it’s just not beneficial for distance runners
  - Long story short, he ended up tweaking the connection to his patella and that bothered him all the way up to Beijing
    - In Beijing, he was kicking myself so much for getting hurt lifting

## Lessons learned from competing in the Beijing Olympics [16:45]

**Beijing olympics**

- Peter recalls that Ryan had a pretty good run in [Beijing](https://en.wikipedia.org/wiki/Athletics_at_the_2008_Summer_Olympics_%E2%80%93_Men%27s_marathon); he finished 10th
  - Yea, but for Ryan it wasn’t about what place he finished, it was the sensation of clicking
  - He wrote a book about that whole experience, so much went into that
    - [Running with Joy: My Daily Journey to the Marathon](https://www.amazon.com/Running-Joy-Daily-Journey-Marathon/dp/0736944125/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=) (published in 2011)
  - But it was also that he wasn’t clicking in training
  - When things are clicking he feels like [Tigger](https://en.wikipedia.org/wiki/Tigger), just bounding along as effortless like, *“this is going to be fun…you’re kind of licking your chops*”

**Lessons learned— a break for recovery is important and the impact of expectations**

- He didn’t take a big break after running 2:06 at the [London Marathon in April 2008](https://en.wikipedia.org/wiki/2008_London_Marathon)
  - He didn’t take his customary 2 week break where he would put on 10 lbs and not run at all
  - So then he was just flat for the whole build up to Beijing; he wasn’t right going into that race
- It’s interesting talking to scientist at the Olympic training center, prepping for the race
  - Talking about how hot and humid it’s going to be
  - This was one of those big life learning experiences for him, where the storyline is— it’s going to be so hot and humid, it’s going to be slow
  - The race will be won in 2:12, 2:11
  - They just hearing this story over and over again
  - He didn’t do what he learned to do after that, which is, “*You got to be like the Samurai… you got to be ready for any situation that’s going to come and not expect anything*”

> “*Expect nothing, be ready for anything*” – Ryan Hall

- He wasn’t in that state of mind, he was thought it was going to be chill for the first mile
  - Right from the gun, Sammy’s just gone; the guy who ended up winning the gold medal
  - He just took it out super hard
  - Mentally, Ryan got hit in the chin with an uppercut, right out of the gate because he wasn’t ready for that scenario at all
- So then he got back and was in 60th place and he’s trying to win a medal but thinking, “*You don’t win a medal from 60th place*”
  - At that point, he doesn’t have momentum on his side

> “*A lot of competing well in anything is getting excited while you’re out there*” – Ryan Hall

- One has to be holding this snowball of excitement as the race is playing out
  - He was having the opposite experience of that
  - He was not where he wanted to be
  - He was too far back; he couldn’t even see the leaders; the he helicopter was way off in the distance
- He had to coach himself through that
- And actually how he did that was by encouraging other guys around home, which isn’t a normal tactic
  - But as he encouraged other people, it encouraged himself
  - He felt better from just trying to help other people out
  - It shifted what was happening inside his mind, inside his heart
  - Then he was able to find his own rhythm and start to work his way up in that race
  - He finished 10th
    - Which he wasn’t stoked about at the time
    - He was trying to get a medal
    - But it’s funny the further removed he gets from these things and the older he gets, he appreciates it more
    - So now he looks back on it, proud of the performance

**Running with Meb Keflezighi**

- Peter recalls, “[*Meb*](https://en.wikipedia.org/wiki/Meb_Keflezighi) *got a silver if I recall in* [*Athens in 04*](https://en.wikipedia.org/wiki/Athletics_at_the_2004_Summer_Olympics_%E2%80%93_Men%27s_marathon)*, right?*”
- Meb Keflezighi wasn’t there in ‘08
  - He and Ryan were training together up in Mammoth Lakes and he was dealing with a lot of injury issues going into it
  - Ryan thinks he had a DNF at the trials that year in 2007; he had some gnarly hip stuff going on
    - It was actually really cool to see Meb in that situation where he went through so many injuries, so many down times and even mentally struggling with how to handle that and see him pop out at the end of that, win New York, win Boston
- He and Meb were neighbors training in Mammoth; they lived 400 meters apart; and he’s always been like a big brother to Ryan
- He was in that race when Meb won [Boston](https://en.wikipedia.org/wiki/2014_Boston_Marathon) and that was such a special experience
- Ryan remembers he was having a bad day that day
  - He was coming up over Heartbreak Hill and he remembers just yelling at the spectators on the side, asking how Meb was doing when he came past
  - And they were like, “*He was winning when he came past*”
  - Ryan knew if Meb got over Heartbreak Hill in the lead, he was going to win that thing; that was special
- Peter notes, it’s hard to believe this was 2014, it was one of those races that is seared into his mind
  - He remembers it well because he trained at the same place as Meb in San Diego, at [Fiesta Island](https://en.wikipedia.org/wiki/Mission_Bay_(San_Diego)); that’s where all the cycling time trial races are held
  - Peter would train at Fiesta Island 3-4 days a week; it’s 7 Km and perfectly flat
  - Meb would do his tempo runs there
  - Early on a Tuesday or Thursday morning, they’d be the only 2 guys out there; Peter on his bike and Meb running

## Importance of speed, power, and strength for runners [22:15]

- It’s worth pointing out to people listening to this who aren’t familiar with some of these times, just how fast you guys run
  - For a marathon pace 4:42 to 4:48 [12.5-12.8 mph], these are such insanely fast speeds that the likelihood that a person could run that speed for half a mile, is virtually zero, right?
    - Peter knows right now he could not go out and run 800 meters, half a mile at that pace
- Peter used to have a sign in his office, it was a pace clock that said 4:42
  - Many, many years ago, they had a treadmill set up to that pace [12.76 mph]
  - The idea was they had random people show up and run, to see how long they could sustain that pace
  - They would put a harness around a person’s waist and they’d make them run at 4:42
  - And these people were getting shot off the back of this treadmill after 30 seconds, 40 seconds, one person made it a minute. Right?
  - The reason Peter put this sign up in his office was because he was put off by the notion that people would say, “*Hey man, we’re training for a marathon, not a sprint*”
  - He tried to make the point that if someone wants to win a marathon, it feels like sprinting
- It’s one thing to go out and run a marathon and take hours to do it
- It’s another thing to go out and win a marathon
- If someone is trying to win a marathon, they have to understand the pain that these guys are in
  - They have to understand what 4:42 means; it is insanity
  - For Ryan, it’s below his threshold, but his threshold is so high
- For Peter, looking at Meb win that race, having seen him in the months prior, running so fast doing tempo repeats while Peter was on his bike, it is really amazing

> “*I wish everybody could try to run at that pace… because otherwise I think a lot of what we’re going to talk about today is very hard to understand from a physiological standpoint*” – Peter Attia

- Ryan agrees; his half marathon pace is a 4:33 mile [13.2 mph]; so that’s 34 seconds per 200 meters
  - Go out to the track and try to run 200 meters in 34 sec; it’s pretty crazy
  - The guys who win the race make this look so effortless
  - Like [Kipochag](https://en.wikipedia.org/wiki/Eliud_Kipchoge), when he’s running sub 2— it looks so slow, but it’s 34 seconds per 200 meters
    - That’s very fast

**Distance runners need speed**

- This is important, distance runners are not slow world class marathoners
- He wants the guy he’s coaching right now to run 400 meters in 49 seconds
  - That’s the kind of speed that is needed to win
  - One doesn’t have to have that speed while they’re doing marathon training, but they need to have had that speed before that, as a kid growing up
- This is why, when Ryan coaches kids he tells them, “*Get as fast as you can, because if you want to be a world class marathoner, you need 49 second speed, right?*”
  - That will carry one on to be able to run a great mile and a great 5K
  - It’s all built off speed
- This is what he work on with training— develop the 5K speed, the mile speed first
  - This is directly correlated to the sprint speed
  - Develop that first, then grow into the 10K speed, the the half marathon speed, then the marathon speed
- When he’s training for a marathon, he’s doing 50 meter sprints twice a week in the middle of marathon training
  - 50 meter sprints, little hill sprints
  - He’s in the weight room; it’s a power to weight ratio— one has to have power
    - This is an area where he has grown a ton since he retired from running
- As he looks back at the weights he was doing, he thinks, “O*h, I wish I could go back and do things a little bit differently in the weight room*”
  - He doesn’t think he used his time effectively there

**Strength training for power and speed**

- Power is so important for all distance runners
- A marathon runner has to have that speed
  - Maybe it’s not as important for super ultra stuff
- Peter agrees that power matters
- He knows Meb was doing deadlifts as he was preparing for 2014
  - He talked to a guy who had overseen part of his strength training program; one of the things he was really fixated on was his strength to weight ratio as measured by a deadlift
  - A hex bar deadlift with a high concentric and a dropped eccentric
    - So one picks it up then drops it; pick it up, drop it
    - The reason for that being the eccentric tears the muscle fibers, and tearing muscle fibers is what’s creating [hypertrophy](https://en.wikipedia.org/wiki/Muscle_hypertrophy)
    - They didn’t want any hypertrophy; they just wanted the strength
    - So it was pick it up, drop it, pick it up, drop it
  - When Meb first started, his strength to body weight ratio for a single rep max was 1.3
    - This isn’t great
    - Peter thinks when he was going into Boston he was 1.3 or maybe 2.7

**How strength factors into running form and speed**

- When someone runs, they have to hit the ground with a toe
- Let’s assume the toe is striking the ground, not the heel
  - The harder one hits the ground, the harder the ground hits them
  - The harder the ground hits, the higher one goes
  - The higher one goes, the further their stride
- They calculated that for Meb to run the pace he wanted to run in Boston that year, he needed to add 4 inches to his stride
  - To do that basically required taking his maximal force per unit, body weight from something like 1.3 to 2.7
  - That was going to translate to 4 more inches of stride
  - So he didn’t increase his stride rate; he just increased stride length and that was done through strength
- Peter suspects this is more widely understood in running now
  - Because there was a day when runners were told “*don’t lift weights… you want to be as skinny as possible; it’s not about that type of strength*”
- Ryan agrees, now runners are super into strength training
- His understanding has changed so much throughout the years
  - He used to always think about the action of his foot hitting the ground
  - He always thought of it like being a tiger paw and pulling the ground
    - That’s not what a runner is going for
  - Like Peter was saying, a runner is stomping the ground
    - A runner is putting force into the ground that’s going to shoot them up and out
    - He never thought about it that way; he was always just trying to paw the ground
  - This is where a runner wants to use their [glutes](https://en.wikipedia.org/wiki/Gluteus_maximus); they are the strongest, biggest muscle
    - Yet so many runners (himself included) had very underdeveloped glutes
    - He would’ve been way faster, way better if his glute strength was better
    - Peter notes that his [hamstrings](https://en.wikipedia.org/wiki/Hamstring) were probably weak and incredibly tight
    - Ryan agrees
- Peter asks if these insights came from sprinters
- He thinks [Usain Bolt](https://en.wikipedia.org/wiki/Usain_Bolt) probably has the greatest force per unit mass ever measured on a [force plate](https://en.wikipedia.org/wiki/Force_platform) treadmill
  - These treadmills tell how much force the runner is putting into the ground.
  - He thinks Usain Bolt is able to put 6 times his body weight into the ground with each foot strike
    - It’s crazy to think how strong that is

> “*For people who are listening, if you’re a runner, like try that next time you go out, try like pushing through the ground rather than trying to paw the ground*” – Ryan Hall

- How one contacts the ground is so important
- A lot of people are rolling through the ground
- It’s very difficult to utilize those glutes to really put force into the ground when one is rolling from their heel to their toe
- A runner has to contact the ground midfoot and just stomp the ground
  - Weight training helps tremendously with that
  - This is so important for sprinters
  - The hex bar deadlift – “That’s his favorite lift”
    - When he coaches runners, that’s the first lift that they do; it’s the most important one
    - This is one that he’s always trying to increase the amount of load they’re able to handle

**Analyzing running stride to improve speed** [31:00]

- Peter asks if he has used a device called a [G flight](https://strongbyscience.net/2017/12/01/g-flight/#:~:text=The%20G%2DFlight%20is%20a,reactive%20strength%20index%20(RSI).)
  - It’s these two little red boxes that shine a laser beam between them and they measure how high someone can jump and their ground contact time
  - This has become part of Peter’s training
  - It shins a little laser across the floor; one lays the device on the floor and stands between them static then jumps up and down
  - It will tell, with incredible precision how high one has jumped because it measures how long they were off the groups
  - This is a simple physics formula to figure out how high the person jumped
- It can be used for a static vertical jump, but Peter thinks it would be more interesting for runners to used it for depth jumps
- So now one puts it in front of a box and has the athlete jump off the box, hit the ground and jump up
  - Now it provides 2 pieces of information
  - 1) It tells how long the athlete was in contact with the ground and
  - 2) How high they went
- The marker of a great runner (or a person who is very good at generating force) is they should have a higher vertical jump when they jump off a box and land and go up than just a static jump
- Most people will jump higher static off the ground than off the box
- The reason is their ground contact time is way too long and they dissipate too much force
- Peter forgets the metrics but thinks you want to be under 0.28 seconds of ground contact time
  - He’s been working on this
  - He is still jumping higher from static than a box
  - And his ground contact time is always north of 0.3 seconds
- This is interesting for him not because he’s interested in running fast, but because he’s interested in his feet becoming very good at load dissipation and load transfer and force transfer
  - He thinks this is a very important skill as one ages, whether one is walking down a flight of stairs or hiking
  - But for a runner, he would suspect if people could get down to a ground contact time of 0.2-0.25 this would increase their speed
- Ryan is reminded of [Jim Ryun](https://en.wikipedia.org/wiki/Jim_Ryun); he was a heel striker, as was [Dathan Ritzenhein](https://en.wikipedia.org/wiki/Dathan_Ritzenhein)
  - He wonders how these guys can run so fast from heel striking
  - Peter thinks it a combination of things:
    - 1) Some people really adapt to a certain way of doing things and it might be that they run really well despite that
    - 2) Experts on this suggest that fore-foot to toe striking is the way we were meant to run
    - If one were to look at how our ancestors ran and how force transfer would be most efficient; it’s not striking on the heel
- Ryan agrees and is interested not in what someone can get away with but what is optimal
- He has spent a lot of time training in Kenya and Ethiopia; runners there don’t go and cool down after a run
  - The best runners on the planet don’t cool down
  - He learned the importance of cooling down in middle school cross country
  - He always asks himself, what is optimal

## The crazy idea that got Ryan hooked on running [35:15]

- Peter notes that it was the [Houston marathon](https://web.archive.org/web/20071108235140/https://www.thefinalsprint.com/2007/01/ryan-hall-sets-new-north-american-record-for-the-half-marathon/) where Ryan became the first American to break an hour for a half marathon; and he still holds the American record for that

![](https://peterattiamd.com/wp-content/uploads/2022/03/f1-ryanhall-684x1024.png)

**Figure 1. Ryan Hall’s record time for the North American half marathon**. Image credit: [Way Back Machine](https://web.archive.org/web/20071108235140/https://www.thefinalsprint.com/2007/01/ryan-hall-sets-new-north-american-record-for-the-half-marathon/)

- Peter asks how old he was when he started running
- Ryan was 13 years old
- Peter read somewhere that his first run was around Big Bear Lake, a 15 mile run; he asks “*How much did that hurt?*”

> “*Oh, it was the pain train the whole time. There was no magic to that run*.” – Ryan Hall

- He was suffering the whole time
- He was wearing basketball shoes
- He had no idea what he was doing
- His legs just felt like they just got pounded into a million little pieces halfway through it
- He had to stop multiple times
- He stopped at a liquor store and got a SOBE drink
- He stopped to ice his legs
- If his dad wasn’t there, he probably wouldn’t have made it around the lake

> “*But that was such a learning experience for me now as a dad of, for myself being like, how do we respond to our kids and their crazy ideas?*” –  Ryan Hall

- He thinks about this crazy thing he decided to do when he was 13 and what it did
  - It changed the trajectory of his entire life
  - It all started with some crazy idea
  - It would have been very easy for his dad to suggest that he start with a 2-mile run instead of a 15-mile run
  - But that wouldn’t have captured him in the same way
  - He needed a hook to be forever changed, something big
  - He’s so glad his dad didn’t gun down his ideas but supported him to go and do it
- Peter can’t imagine the pain; he had a similar experience when he was 12
  - He woke up one day and just wanted to go run 5 miles
  - He wanted to see how fast he could run 5 miles
  - He put on his crappy shoes and went out and ran 5 miles
    - It hurt so much
  - The next day though he wanted to do it again
    - So he did it again and it hurt so much
    - And again on the 3rd day, and it hurt so much
    - Then on the 4th day it changed; he felt awesome
    - Then he never stopped; he just started adding more distance

## The mental aspect of training and the power of reframing negative thoughts [37:45]

- Running is very nonlinear
  - The pain he was feeling at 5 miles; this is a quarter of the distance of 13 miles in terms of effort
- Peter wonders what was going on in Ryan’s mind at the 5 mile mark, at the 8 mile mark
  - Did he love the pain, love proving to himself that he could do it; or was he thinking “*why am I doing this?*”
- Ryan notes, “*the thing about distance running is… what’s going on in your head is hugely important*”
- Now when he trains athletes he tells them “*you got to have a whole bunch of different arrows essentially that you can pull out and use. Cause sometimes you use one thing, it doesn’t work; you’ve got to go to something else*.”
- He has all these different tactics and managing pain and discomfort, but honestly, one of the biggest ones that is most helpful is simply turning the mind off
  - Turn the mind off and keep putting one foot in front of the other
  - It sounds so simple and basic
  - But in the last 5K of the Boston Marathon when he is in a world of pain, there are no profound thoughts going on in his mind
    - It’s as simple as putting one foot in front of the other as fast as one can
    - In moments like that he often turns his brain off and just keeps moving

**The importance of being in the present moment**

- He gets in trouble when he starts thinking too far down the road
  - It’s easy to get overwhelmed with the scope of the challenge, especially when trying to do something one has never done before and being in the worst discomfort
    - That’s what makes people give up and give in
- Ryan has found if he can bring himself back to the present moment of what he’s doing right now; there is always enough to get him through the moment
  - There’s not always enough to get him through all that’s coming down the line
  - But if he only tries to do what is in front of him, run the mile he is in and bring himself to the present moment, there is always enough to get through that moment
    - This is why he titled his book [*Run the Mile You’re In*](https://www.amazon.com/Run-Mile-Youre-Finding-Every/dp/0310354374/ref=sr_1_1?crid=2JT6MSUTOTJKQ&keywords=Run+The+Mile+You%27re+In&qid=1640010221&sprefix=run+the+mile+you%27re+in%2Caps%2C76&sr=8-1)

> “*You just got to bring yourself back to being present in this moment, and there’s always enough to get you through this moment*.” – Ryan Hall

**Comparing running to swimming— expectations are important in each**

- Peter compares the difficulties of running to swimming
  - “*One of the things about running that strikes me as difficult in that regard is you can’t disassociate yourself from the visual cues of how much lies ahead*”
  - In contrast, when swimming long distances he had a rule to never look up towards short
  - He would only know he was near land when he started to see the bottom of the ocean
    - This happens around half a mile from shore
- He remembers a bad experience swimming across [Lake Tahoe](https://en.wikipedia.org/wiki/Lake_Tahoe)
  - It wasn’t supposed to be a difficult swim
  - It was 12 miles and should have taken a little under 6 hours
  - The boat captain he hired didn’t understand the navigation
  - They ended up zigzagging across the lake instead of going straight across
  - When he hit the 5 hour mark he thought he should be 2 miles from the shore
    - He asked the captain how much farther but looking toward the shore the number made sense
    - “*I stupidly looked towards the shore and had a mental image of what it looked like*”
    - He couldn’t make out any details, trees or anything on shore
    - He put his head down and hammered for 1 more hour thinking he should see the bottom of Lake Tahoe soon
  - But after an hour, he lifted his head up and everything looked exactly the same
    - This is the closest he ever came to quitting a swim
    - He was mentally destroyed
  - He asked how far they were from the shore and the captain said maybe 4 miles
    - Peter was pissed; he had in his mind that he was much closer
    - He wasn’t in that moment
    - Unlike running, he could swim with his eyes closed
- Peter notes the fortitude needed to run the race
  - The example Ryan talked about of being in Beijing, knowing he was in 60th, seeing the helicopter over the leaders a quarter mile up the road
    - That requires an extra level of mental fortitude to stay competitive in the race
    - Ryan replies, “*it all comes back to getting excited, right? If you’re going to perform well, you’ve got to be excited about how you’re doing…  find something to get excited about in that moment*”
- Ryan talks a lot about like reframing things in one’s mind
  - This is one of the most helpful things he does all the time

**The Grand Canyon “farmers carry” challenge**

- For example, he was doing a crazy challenge he calls chop wood, carry water
  - He splits a cord of wood at his house in [Flagstaff](https://en.wikipedia.org/wiki/Flagstaff,_Arizona), and then drives to the [Grand Canyon](https://en.wikipedia.org/wiki/Grand_Canyon)
  - He runs down to the bottom of the Grand Canyon, holding these 7-gallon water jugs
    - They weigh about 62 lbs each when they’re full
  - It’s a 10K (6.3 mile) run down to the bottom of the Grand Canyon; it drops 5,000 feet
  - He gets to the Colorado river, fills them up and farmer-carries them out of the Grand Canyon
- He remembers being down at the bottom and filling up those jugs and just looking up at the trail he had just run down
  - He thought, “*what did I get myself into?*”
  - The sun was already getting down super low
  - And that was the hardest part of the whole challenge for him was just starting back up
    - Because he knew what was waiting for him; how far he had to go
- Peter clarifies, “y*ou carried 63 lbs in each hand of water up 6.3 miles*”
  - Yes, up a 7% grade, 5,000 feet
  - It took 6 hours
- Peter asks about his hands, did he use wraps around his hands or something?
  - No, he just has good calluses on his hands from all the lifting he’s been doing
  - His hands took a beating
  - But it was more cardio than strength
  - He would stop every 50 meters or so to put them down; so it was a lot of carries
- Peter notes, “*That is actually more insane than your deadlift 500 lbs run a five minute mile attempt, which also was super impressive. But this farmer’s-carry thing is ridiculous.*”
- Ryan agrees, it was a crazy experience
  - He had to reframe a lot
  - He initially thought it would take him 4 hours to carry these out; his goal was to beat the sun
  - But it was already 3 or 4’oclock when he got down to the bottom
  - He found himself getting frustrated about how it was going
  - Thoughts of, “*I’m never going to get out of here*” were going through his mind

**The power of accepting and reframing negative thoughts**

> “*I had to reframe it and come to peace with what was happening out there and just accept it and then get excited about it*” – Ryan Hall

- He was looking at the moon coming up; it was so epic
- It was dark
- His buddies were there cheering for him, giving him food and water and stuff
- It was just such a beautiful experience

> “*But I had to reframe it to be able to see it that way because how I was seeing it at the bottom of the canyon was like, oh man, this is going to suck, what I get myself into; I don’t know if I can get out of here*” – Ryan Hall

- Once he was able to accept all those negative thoughts and then reframe it, then he was able to embrace this really beautiful experience
- This was one that was life changing for him
- One that he’ll never forget; getting to the top of that canyon and putting those jugs down
  - How good it felt to finish

> “*But I had to kind of like change how I was thinking about the whole situation, which is what you have to do when you’re in a race and it’s not unfolding… how you want it to unfold*.” – Ryan Hall

- This is something Peter can relate to on a number of his swims where things didn’t go well
  - Ryan is right, there is something about saying, “*I’m not going to quit; I’m going to put my head down and I’m going to do this*”
  - When one gets to the other end, it’s pretty remarkable
- One of the things Peter learned from watching other swimming coaches is— when a swimmer says they want to quit, don’t let them do it
  - Tell them to give it another 10 minutes then talk about it again
  - He makes them do this 3 times
  - Part of it is just to show them that they can swim for another 30 minutes
  - So maybe if one can swim for another 30 minutes, then they could probably swim another 4 hours or whatever the time is
  - He acknowledges their desire to quit and after 30 minutes, that is fine, they can
  - But there is no substitute for the feeling one has when finishing

**Ryan’s pace during the farmers-carry up the Grand Canyon**

- Ryan’s challenge strikes Peter as the hardest physical thing he could ever imagine doing
- He asks what kind of pace Ryan was at, a slow jog?
  - It was basically a fast walk
  - He wanted to make his legs and heart do as much of the work as possible
  - Just holding  that much weight in ones hands becomes an issue
- This was harder than running a marathon because during a marathon his [heart rate](https://en.wikipedia.org/wiki/Heart_rate) is around 167
  - In this challenge it was probably 195, 197
  - He has a really low heart rate to begin with
  - He couldn’t get it over 200
  - When he was at his fittest, his resting heart rate was 27
  - Now it is nowhere near that
- The first 17 or 20 miles of a marathon feel pretty good
  - He’s conversational
  - He’s floating along; it’s just fun; he’s enjoying the ride
- This challenge was like doing interval training
  - He was going into his 32nd carry, set it down, take as minimal rest as possible
    - Maybe a 30 second rest
    - He would catch is breath and go again
  - He was breathing super hard when he set it down
    - He sounded like a truck the whole time
    - He is going to have a video coming out pretty soon and it shows him breathing super hard
  - This carried on for 6 hours; doing the most intense thing he had ever done before
  - He was not used to breathing that hard for so long
- Peter asked how much he drank

> “*The amount of water and calories I was taking in was insane*” – Ryan Hall

- He had a lot of buddies helping him
  - One guy was in charge of doing his food and water after every 3rd carry
  - He was taking in water and then sugar— eating gummy worms like a maniac
  - He probably took in 3000 calories coming up from the canyon
  - He was burning so many calories
  - He weighed 183 lbs, was carrying 124 lbs of water, and going up 5,000 feet
  - His metabolism was unreal
    - This was a big part about why he wanted to do this
    - The most important part of training is consistency

> “*It blows my mind what my body’s capable of doing; and my athletes are capable of doing when you’re just consistent*” – Ryan Hall

**Training for this challenge**

- When he was training for this, most of the time he did 20 minute carries every other day
  - 20 minutes with 65 lbs in each hand
  - 20 minutes of— 30 seconds on, 30 seconds off; 30 seconds on, 30 seconds off
- He was able to do a 6-hour carry out of the canyon
- He trained on flats
  - He could have trained better but he’s: a full-time dad, coaches his wife, has an online training business ([Run Free Training](https://www.runfreetraining.com/))
  - He didn’t have time to do hour-long water carries
- It’s easy to be consistent when it’s 20 minutes; he would get home late at night and put on the headlamp
  - He could be consistent with 20 minutes not with an hour

> “*I think a big part about being successful in running fitness is like, just make the bar low, make it easy to be consistent”* – Ryan Hall

## The importance of fueling, and Ryan’s marathon diet [52:00]

- He knows how important fueling is when doing any kind of ultra stuff
- He knew if he took in enough calories and stayed hydrated, he was going to be okay in the Grand Canyon challenge
  - With proper fueling, he could get through anything

**Learning from mistakes**

- Peter asked how much he needed to experiment with fueling because this is something he has experimented with a lot on his own
- Even for modest forms of endurance training, learning the fuel and making dumb mistakes was important
- Peter did one training swim many years ago
  - It was the longest swim he would do before the actual, 24 mile swim
  - It was 18 miles
  - Someone told him a good way to avoid getting the runs is to take [Imodium](https://en.wikipedia.org/wiki/Loperamide)
  - Peter had never had the runs when swimming, but would hate to get it so he tried the Imodium before this swim
    - But he didn’t take the recommended dose, he took 2x
  - He thinks his regimen was to drink 200 mL fluid every 20 minutes
    - 1 hour of fluid multiplied by a 7-8 hour swim
  - The last 4 miles, he thought he was going to die
    - He was so bloated and it didn’t occur to him why— 8 hours earlier he had taken Imodium
  - His swim started in [La Jolla](https://en.wikipedia.org/wiki/La_Jolla); he swam up to [Solana beach](https://en.wikipedia.org/wiki/Solana_Beach,_California) and then back down
  - When he got back to shore, his friend who was guiding him, pulls up the kayak on the beach and Peter picks up the front of the kayak and carries it with him
  - It’s a beautiful day in La Jolla; families are playing everywhere
  - This kid had dug a big hole in the ground next to his sandcastle
  - As Peter walked by he puked into this hole; it looked like the 8 L of whatever he was drinking
  - Then he realized, Imodium is not for swims
- The fuel is important
  - He knows some athletes who get sick if they eat sugar; the have to use more complex carbohydrates
- How deliberate was Ryan in figuring out the right ratio of fuels?
- Ryan was super specific when he was running professionally and those experiences carried over into the farmer-carry Grand Canyon challenge
- One can train their gut to take in stuff
- Problems arise when one eats new stuff they’re not used to

**Ryan’s pre-marathon diet and fuel during the race**

- 2 days before a marathon, he’s carbo-loading
  - The nutritionist he worked with advised him to spread the load out so he wouldn’t feel bloated and terrible the day before the race
  - He would eat 400 calories of extra carbohydrates for 2 days before the race
    - This was on top of the carbohydrates he would normally eat when training hard
- Those carbs would be super simple
  - He wanted to make it easy on his system
  - There is a time and place for complex carbs and a high fiber diet; not before a race
  - He would eat white rice, pasta; he really liked [sourdough bread](https://en.wikipedia.org/wiki/Sourdough) because of its lower glycemic index and it digests easily
  - [Maltodextrin](https://en.wikipedia.org/wiki/Maltodextrin) is a carb he likes to take in; it’s a tasteless, liquid calorie
    - He can mix it with protein powder, shake it up, and shoot it down
    - But you has to be careful, he’s had some bad experiences with other branded stuff
- You never wants to try something new leading up to a race; always try it in training
- His pre-race meal was a liquid meal because he would wake up really full from all the carb loading he had done the day before
  - 3 hours before the race he would shake liquid maltodextrin with protein powder, and add a little bit of olive oil as a health fat to help slow things down a little
- He would take a gel right on the starting line
- He would be sipping on a water bottle the whole time
- He would be able to put a water bottle on a table every 5K
  - These would start off dilute and get increasingly concentrated as the race went on
    - The reason for this is that the body absorbs things more easily when it’s not tired
    - He wanted to make sure he was front loading his carbon intake during the marathon because the body can process it a lot easier
    - When you’re 40K into a marathon, you don’t feel like taking in carbs at all
    - Often he would take a swig of a water bottle and spit it out; it tricks the body into thinking it’s getting carbs but it doesn’t get anything
    - This would give a little jolt of energy with just 2K to go
- He would have a gel at 15K; at 30K he would have a caffeinated gel
  - He would time his caffeine intake to where he was taking it 75 minutes prior to the start of the race
  - Caffeine is really interesting; when it came on board he couldn’t imagine doing a race without it
    - There was no going back
    - People can have very different experiences with it though
    - He’s learned from science that it increases one’s core temperature which is detrimental to endurance activities; but that hasn’t been his experience
    - He is 100% faster with caffeine on board than without it

## Boosting performance with Tylenol and keeping core temperature down [59:00]

- Peter asks if he ever experimented with [Tylenol](https://en.wikipedia.org/wiki/Tylenol_(brand))
  - No, Ryan never did
- Peter was talking to [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) about it a couple weeks ago and this came up
  - He never used Tylenol in the tour but it’s a pretty remarkable performance enhancing drug
  - Perfectly legal
  - It gives a 1-2% boost
    - It’s not clear if this comes through temperature reduction of pain reduction
    - Peter used it during [time trials](https://en.wikipedia.org/wiki/Track_time_trial)
    - A time trial is basically an hour of threshold; it’s super painful
    - Sometimes he felt like he even gained 3% from Tylenol
    - Peter would take 1000 mg before a race
    - He’s curious if other athletes have tried it
- Ryan is not familiar with it but is definitely going to try it with his athletes now
- Peter notes, [Tylenol](https://www.rxlist.com/tylenol-drug.htm) reduces pain in a way that is different from [NSAIDs](https://en.wikipedia.org/wiki/Nonsteroidal_anti-inflammatory_drug)
  - One  needs to be careful with the dose because it’s a very liver toxic drug at high doses
  - But in normal amounts, 1000 mg is incredibly safe
- Ryan asks if there is any application to lifting
  - If it keeps the core temperature down, it seems like that would be helpful
  - Peter hasn’t seen any literature on lifting with Tylenol
- Funny story, about 8 years ago Peter saw some papers that looked at how [Viagra](https://en.wikipedia.org/wiki/Sildenafil) improved lifting
  - So he tried it but couldn’t use Viagra because of the symptoms he was getting
    - It’s a [vasodilator](https://en.wikipedia.org/wiki/Vasodilation); his blood pressure isn’t high but is kind of low so he would get light-headed using it
  - But research shows that 25-50 mg of Viagra boosts muscle endurance and performance
    - You would probably see more benefit on your best 10 rep deadlift as opposed to a max deadlift

**Keeping the core temperature cool can boost performance**

- Thinking of core temperature, Ryan asks if Peter has played at all with [palm cooling](https://en.wikipedia.org/wiki/Palm_cooling)
  - No
- Peter used to check his core temperature before and after long swims because he had the opposite problem
  - Swimming in cold water, his temp would drop 4-5 degrees
  - Sometimes he would actually swim with a rectal probe just to see
  - He would start at 98 or 99o F and would come out of the water at 93, 94
  - There would be a performance detriment with the core temperature went too low
- Too much or too little temp is pretty bad
- Ryan mentions [Dr. Huberman](https://en.wikipedia.org/wiki/Andrew_D._Huberman), a Stanford neuroscientist who [studies palm cooling](https://hubermanlab.com/supercharge-exercise-performance-and-recovery-with-cooling/)
  - There is some pretty remarkable research about this and its effects on strength training and endurance
  - The best way to lower cort temp is through one’s face, the upper face where there is no hair
    - The next best is through the hands and bottoms of the feet
  - They developed this glove to dump heat
    - It’s not icy cold, just cool
    - One doesn’t want it too cold
    - It doesn’t change vasodilation
    - It dumps heat and brings the core temperature down
- Ryan has been playing a little with holding a cold pack in his hands between lifts or putting his hands in cool water to dump his temp
  - It’s the type of thing that makes sense to him
- Thinking from a perspective of evolution, why can humans do these persistent hunts?
  - They go and chase an animal down; the animal overheats
  - The animal is not as good at dumping temperature whereas humans are better at regulating temperature
- If one can keep their temperatures in an optimal range, in theory, it should increase their endurance
- He loves exploring this stuff and trying new tactics like this
- Peter has tried a cooling helmet
  - The helmet had gel pack inserts that could be frozen in the freezer
  - When he would ride his trainer wearing this cooling helmet, it definitely made a difference
  - He couldn’t bring himself to use it in a race
- He noticed something similar the first summer he lived in [Austin](https://en.wikipedia.org/wiki/Austin,_Texas)
  - It got much hotter in Austin than what he was used to in Southern California
  - He never used a cooling device when driving a race car; he would just drive
  - He’s in a closed-cockpit car with a fire suit on; so it’s not a formula car, there’s no wind
  - The cars are hot; there’s no air conditioning; there’s all this engine heat coming through
  - It gets really hot and he would just suffer through
  - Many people invest in a [cooling vest](https://en.wikipedia.org/wiki/Cooling_vest); it’s a vest that runs ice water around one’s torso
    - Finally Peter got one and it was a game changer
- Ryan is interested in this because he plays around with a cooling vest too
  - He has an archaic one that he freezes then it slowly gets back to temperature
- Peter notes this would not be great for a runner because it would be too heavy;
  - His is more of a shirt with little cables running up and down
  - It has a box that runs cold water through the cables and in the car
  - There’s a power unit; it runs out of the car
  - It weights maybe 6 lbs
  - He has wondered what the cost trade-off would be of wearing it on a bike; thinking about its weight and the performance gain one would have
- In a car, it’s an enormous performance booster
  - This is more important in closed cockpit cars
    - In formula cars, it’s not as big a deal because there is so much air blowing in
- Using the cooling vest made a difference in how tired he felt after the race
  - It was the difference between feeling like one was going to die and feeling tired but okay

**How cooling could be incorporated into running**

- Peter can see how cooling could be used in strength training but wonders how it could be incorporated into a marathon
- Ryan thinks cooling would be useful before a race when the athlete is warming-up, doing drills and strides
  - This would help get the core temperature back down by dumping some heat
- In interval training, cooling could be done between sets
  - He’ll use a bucket of cold water at the track for the athletes to put their hands in inbetween sets
    - It feels like it makes a big difference
- He has used those instant cold packs; break them open and hold them for about 2 minutes
  - It’s kind of a hindrance, but it’s worth it to get the performance benefit
- He hasn’t tried the gloves they have at Stanford but he’s curious about them
  - He knows they use it on the football team and a lot of the athletic programs
  - But one can’t stop their run in the middle of a race and put their hands in some cold glove; but who knows what the application could be for running
- For the bike, it would be cool if they could make the handlebars colder
  - Peter agrees, this would be a great idea if they could make it really light
    - Most bikes are coming in below the [UCI](https://en.wikipedia.org/wiki/Union_Cycliste_Internationale) limit of 14.9 lbs
    - So most cyclist actually add weight to their bikes to get them up to the legal weight

## Ryan’s early struggles and later success at Stanford [1:09:45]

- Peter asks about Ryan’s time at [Stanford](https://en.wikipedia.org/wiki/Stanford_University)
- He assumes he was recruited heavily from every top running powerhouse program
  - Ryan agrees, this was cool
- Growing up, he was in the middle of 5 kids
  - His dad was a teacher
  - His mom was a stay at home mom
  - They were always pinching their pennies
  - He thought running might take him to a good college; he was going to have to earn his way there
  - It was cool to be recruited all of the the place
  - At the time he felt that Stanford was definitely not one of the places he was going to, because he wasn’t heavily focused on academics in high school
    - He didn’t want to be super challenged both academically and athletically

**Achievements at Stanford**

- His time at Stanford was 3 years of really big struggle
- He hit one cross country season really well
  - He was part of a NCAA winning team, 2 years there in cross-country
- In his 4th year at Stanford, things just clicked
- This is what he loves about running and fitness in general
  - Things can be going wrong for so long yet when they start to click, it’s such a good feeling to push through and get to the point where it feels easy
- That’s how he felt during his 4th year
  - He and his teammate [Ian Dobson](https://en.wikipedia.org/wiki/Ian_Dobson_(athlete)) went 1, 2 in track
- At that point he was having a very lackluster career at Stanford
  - He had never been to NCAA championships in track; but in running, this doesn’t matter
    - It’s just the runner and the clock and the other guys there
- Now everything was clicking and he had the opportunity to run professionally
- He and his wife Sara were planning to come back to Stanford for a 5th year
  - But he had seen other teammates have a really good 4th year and no do well their 5th year and end up with no contract
- Peter asked, “*Did you* [*Redshirt*](https://en.wikipedia.org/wiki/Redshirt_(college_sports)#:~:text=The%20term%20redshirt%20freshman%20indicates,year%20both%20academically%20and%20athletically.) *your first year*?”

> “*I redshirted my freshman year. I was on the struggle-bus. I was hurt, I was injured, I was sick, I’d get poison oak every winter. It was the perfect combination of everything going wrong*.” – Ryan Hall

**Ryan’s struggle with depression**

- Ryan was struggling academically
- He struggled with depression and actually left Stanford for a quarter in his sophomore year
  - He was going to go back to the last place where everything was clicking for him, where everything was working— he was going back home
  - He was sick of the struggle
  - But back at home he became even more depressed
  - He realized he was supposed to be back at Stanford
- So he went back to Stanford and gradually things started to get better
- He had his struggles at Stanford, but it was a beautiful place to go to school
  - He loved the people; he loved the environment
  - He still likes to go back and visit
- It was a struggle athletically and academically until his 4th year
  - Then the doors came open to run professionally and he left the farm after that

**Running a mile in under 4 minutes** [1:13:00]

- Peter asked what changed, what clicked?
- In highschool, was Ryan running a 4:02 mile?
- Peter knows Ryan wanted to break that 4 minute barrier
  - This is pretty rare to [run a mile in under 4 minutes in high school](https://en.wikipedia.org/wiki/List_of_American_high_school_students_who_have_run_a_four-minute_mile)
  - Only a few have done this, including [Jim Ryun](https://en.wikipedia.org/wiki/Jim_Ryun) and [Alan Webb](https://en.wikipedia.org/wiki/Alan_Webb_(runner))
- When Ryan was in high school, there were only 4 guys who had run a mile in under 4 minutes
  - Alan and he did it in the same year
  - He was good friends with Alan
  - He remembers watching him run 3:53 and he was blown away; it was out of this world
- Alan went to [Michigan](https://en.wikipedia.org/wiki/University_of_Michigan)
  - He struggled his sophomore year
  - They have a lot of parallels, even the year they both hit it big— 2007
  - [Alan](https://en.wikipedia.org/wiki/Alan_Webb_(runner)#Collegiate) set the American record in the mile [3:46.91]
  - [Ryan](https://en.wikipedia.org/wiki/Ryan_Hall_(runner)#Collegiate) set the American record in the half [marathon, 59:43]
  - They were roommates in Europe in 2006; they were racing and both struggling for various reasons
  - They both had very high highs and very low lows
  - They are similar, but Alan is definitely one of the most talented runners Ryan has ever seen
- Alan has such a good work ethic; he would do hurdle drills, pliers, and stuff for hours
  - Ryan noted his intense focus was great when it was clicking
- If the Olympics would’ve been that year, he’d been a gold medalist without a doubt

## Keys to overcoming difficulty: faith, mindset, and being a better teammate [1:15:45]

**Reflecting on training**

- Peter asked what changed in Ryan’s senior year
- Ryan has always been very interested in the nuts and bolts of training
  - It’s important to understand how he’s doing what he’s doing as an athlete
  - What’s what’s going on in his heart, in his head— this is more important that what he’s actually doing
- He has a tendency to try to prove himself to himself in training
  - He wants to know if he’s fit and ready to go
  - Sometimes he’s going harder in training than racing
  - But this isn’t the best way for his body to absorb the work

> “*I need to be making deposits not making withdrawals when I’m training*” – Ryan Hall

- He’s in a much better place if he going into these workouts confident in who he is, knowing the purpose of the workout

**How his mindset led to depression**

- In his senior year, his identity was all wrapped up in his performances
- This is why he struggled with depression
  - He would look in the mirror in the morning, he was struggling with running, he was hurt
  - He was frustrated with how things were going; he wasn’t getting better

> “*I just saw myself as a failure and it was very difficult to have that happen every single morning, get up, look in the mirror failure*” – Ryan Hall

**Focusing on his faith helped him change his mindset**

- Faith had always been a huge part of his life; when he went back home he started to realize that he needed to see himself as God sees him
  - How God sees him has nothing to do with his performance
  - Compare this to how a parent thinks about their kids, it doesn’t matter how good they are in a certain sport; a parent loves their kids
  - It’s unconditional love
- He wondered if he could love himself that same way
- Oftentimes people are able to love others and treat others better than they treat themself
- He started to realize that God loves him regardless of how he performs
- He decided he was going to choose on a daily basis
  - This is something he had to cultivate, even to this day
  - He decided to choose to love himself regardless of how he was performing
  - What makes him special has nothing to do with how fast he is or how much weight he can lift
  - As that began to sink in, it took the pressure off
    - He stopped hating himself
  - He discovered he could love himself whether he had a great workout or a bad workout; he became cool with who he was
    - That just took the weight off
    - It made him fearless too
- The Africans have this mentality too
  - They go with the lead group
  - If they blows up, they don’t take it personally; they get up and go again next time
  - They don’t take their failures personally
- Americans, like Ryan, take it super personally
  - To fail at a workout is to fail personally
- For Africans, to fail is part of the process
  - Who cares? Just go again
- As Ryan’s approach to his workouts changed, thing started to click a lot better
- Another big thing he learned is that he didn’t have to beat his work or his teammates in training anymore
  - Instead, he could just work with them
  - He didn’t have to try to drop them, even if he could
  - He became secure in who he was
- This was a huge shift but results didn’t come all of a sudden
  - This took years and years to turn into something

> “*That was really the most freeing, I think I’ve experienced in my career in terms of what’s going on internally that freed me up to enter into my full potential in running*” – Ryan Hall

**Improving communication helped Ryan be a better teammate**

- Peter remarks that despite being a very friendly person, coming to every workout in the mode of hammer time probably alienated a lot of teammates
- Ryan agrees 100%
- Ryan would go home over the summer where one is supposed to be chill and just building base training
  - He would train his brains out and would come back blasting everyone all the time
- He remembers talking to one of his good friends and teammates in Dobson; his friend remarked that the team used to not be a fan of Ryan
  - Because Ryan would always come back in super good shape and was always taking it to them
- This changed for Ryan as he was able to communicate and work with the team better
- It’s different to tell the guys that he’s feeling really good and is going to pick up the pace than to just take off without saying anything
- In a group environment, it’s crazy how just that little communication can really shift the dynamics of the group
  - It makes everyone cool with what’s happening

## Ryan’s professional running career and his discovery of his gift for marathon distances [1:22:00]

- Ryan turned pro in 2005; his lead sponsor was ASICS
- Peter asks if he thought then that his sweet spot would be in the half marathon to marathon world, or if he was thinking he was going to be a 5K, 10K guy
- Ryan never thought he would run a marathon

**His focus on speed and the 5K**

- Ryan grew up loving the movie [Prefontaine](https://en.wikipedia.org/wiki/Prefontaine_(film)) and that scene where the lead character says, “*no one’s going to tell me I’m not fast enough*”
- But Ryan wasn’t fast enough; he wanted to be a miler
- He ran 50 for 400 in high school
- But only having that kind of speed limited his upper end potentia
  - In the 5,000 meters guys are closing in 52
  - So if his top end speed is 50, he’s going to have a hard time closing in 52
- His best 5K was 13:16
  - To put this in perspective, the American record for the 5K is around 12:50
  - At the time, his 5K was one of the faster times
- But after spending a year in college focusing on his 5K he didn’t improve
- The Beijing Olympics were on the horizon; the trials were coming up the following year
- He needed to figure out his vision for running; he always wanted to run with the best guys in the world
  - He tried to figure out what event he would be most competitive at
  - He was 23 at the time
  - All the sudden he had an openness to longer distances where as before he was very closed minded and focused on running a world class mile

**The path to marathon running**

- He had run zero half marathons before Houstin in 2007; this was his first
  - He had run a couple of 20Ks, which is just 1K less than a half marathon
- He got worked on the track that first year and he’ll never forget
  - He was in London racing against the world record holder ([Bekele](https://en.wikipedia.org/wiki/Kenenisa_Bekele) at the time) for the 5,000 meters
  - He was coming down the back stretch of the track and was watching on the jumbotron Bekele and [Craig Mottram](https://en.wikipedia.org/wiki/Craig_Mottram) finish in this kicking dual
  - And he was nowhere even close to them
  - This was one of those moments where he realized, “*this isn’t my best event*”
    - A moment of realization
    - So then that openness allowed him to start experimenting with longer stuff
- In the summer he started training for longer distance
- He did the World 20K Championships then the US National 20K Championships
  - It was all clicking pretty well
- In the winter he got into marathon training
  - He was planning to debut in the Los Angeles Marathon

**The 2007 half marathon in Houston**

- Peter asks him to go back to his first half marathon in Houston “*because obviously the result of that race is so out of this world that it’s easy to miss that little detai*l”
  - This race was in January of 2007
  - At the time the American record for a half marathon is 1 hour and 55 seconds
  - Peter asks what he was thinking at the starting line; what were his expectations
- This was in the days before GPS watches so he had written down on his hands 3 different categories of times he was going for
  - If he was having an A day, he would finish just under the American record pace (60:55)
  - If he was having a B day, he would finish in 61:30
  - If he was having a C day, he would finish in 62 flat
- His training was going phenomenally well
  - He was blowing his own mind

> “*About that day, I described Houston as being heaven and hell at the same time*” – Ryan Hall

- That day was heaven because he was floating the whole time; it felt easy the entire way
  - It was the coolest bodily sensation he has ever experienced; it was unreal
- It was also hell and haunted him because he could never get back to that feeling
- It was his best half marathon by far; he never broke 61 again
- He finished the half marathon at 59:43
  - He obliterated the American record by over a minute
- He remembers looking at his Timex watch and what’s happening in that first mile
  - He pictured himself back on Green Church Road in Mammoth where he trained and thought— if he was running a 13 mile threshold, could he maintain this effort that he’s currently at?
    - The answer was yes
  - He ran the first mile in 5:35
  - It felt too easy; he wasn’t supposed to be running that fast
  - He knows he can hold that effort to the finish
  - The next mile was 4:32, then 4:28
  - He was starting to scare himself a little bit and thought, “o*kay let’s not screw this thing up; obviously you’re going to have a heck of a day today*”
  - No one else was around

> “*From the very first mile it was just me and the roads*” – Ryan Hall

- He was so mentally clicked in; all was as it was supposed to be
- It was the most magical sensation he’d ever had
- So he just kept pushing and waiting for it to get hard… and it never did

- He had 1 issue around mile 9 where his stomach got a little bit turny
  - In a half marathon he’s not taking in any fluids if the weather is cool
  - It was a nice cool, perfect day day to run in Houston, a flat course
  - But this feeling passed a couple minutes later
- Literally it was easy the entire way
  - He’s curious, if he had a pacemaker and if it was a full marathon, he wonders what he could have run that day
  - He was in really good shape
- Looking back on it, this is why he is such a big proponent of speed now
  - He had spent 10 years (from 13-23) working on speed, working on his 5K
  - Then all the sudden, he piled on marathon training and was hitting longer thresholds and higher volume
  - This is why he emphasizes 5K speed with the athletes he coaches

> “*The further away I got from that 5K fitness, the harder the half felt, the harder the marathon felt*” – Ryan Hall

- Peter asked if Ryan thought he could have gone harder after he crossed the finish line
- Ryan replied, “*That’s interesting because I’m talking about how easy it felt yet I wasn’t leaving anything in the tank necessarily*”
- He got a huge hit of adrenaline when he crossed the finish line
- Breaking 60 was a lifetime goal and to do it on his first half marathon; it was crazy
- Staring at the people on his team has hugely, emotionally empowering for him
- He’ll never forget the finish line
  - The lead car zipped up the road a bit and dropped off his parents and wife, Sara 200 meters before the finish line
  - They were running to get to the finish line before him
  - He’s coming down the final stretch and sees his mom just booking it, trying to make it to the finish line before he got there
    - He actually passed her
    - If you look at some of the pictures, she’s in the back sprinting behind him
  - He’ll never forget coming across the finish line, giving his parents a big hug, giving his wife a big hug, his coach
  - He had the sensation of, “*We did this*”
  - It wasn’t special because he felt like he had done something incredible
  - Instead, it was “*We all did this thing together; and it was just an amazing lifetime moment that I’ll never forget*”

## Reflections after breaking the American half marathon record, and challenges faced by retired athletes [1:32:45]

- Peter asks if his life as a professional runner changed in that moment
- It was huge; he went from a guy who was decent on the track in NCAA champs to the top 10, all-time performers for a half marathon
- All of the sudden he realized he had a chance of medaling in [Beijing](https://en.wikipedia.org/wiki/Athletics_at_the_2008_Summer_Olympics_%E2%80%93_Men%27s_marathon)
- There was the excitement of, “*I found it*” after struggling for so long with the shorter distance stuff
  - He had the feeling of, “*This is what I was created to do*”
  - Everyone searches for their giftedness and purpose; the moment of finding it is incredible
  - More than anything, it was a cool moment of realizing he was in the club with the best guys in the world

> “*After that, I never showed up in another race thinking I couldn’t win or not having high expectations for the race*” – Ryan Hall

- Peter notes that Ryan realized his gift and acknowledged that it is something very fleeting
  - There’s a narrow window when one gets to be really good at this; for a runner it’s technically one day
  - He might be very good for a decade but would look back at this as the best  he could ever do
- Houston in 2007 was his best half marathon
- 4 years later was his best marathon (2:04:58 in the [2011 Boston Marathon](https://en.wikipedia.org/wiki/2011_Boston_Marathon))

![](https://peterattiamd.com/wp-content/uploads/2022/03/f2-ryanhall-1024x450.png)

**Figure 2. Ryan Hall’s Best times.**

- Is being past one’s prime, a retired athlete, a difficult process?
  - Absolutely
- Ryan talks with his wife about this
  - Sara is turning 39 in April and she’s running the best stuff she’s ever run
  - Women age better than men in a lot of ways

**Savoring the moment**

- What was impactful for him at the end of his career was a moment when he was in an airplane
  - He was reflecting on everything trying to get clarity about what was going on
  - He had just been through 4 years of massive struggle
  - He felt like having a little prayer session with God and sensing a reminder that this is not meant to last forever

> “*When you’re in it, you feel like it is going to last forever and it is supposed to last forever, but [it doesn’t and] that’s actually what makes life so beautiful*” – Ryan Hall

- So having that moment realization that it’s okay for it to not last forever
  - That was his day
  - He savored it for everything it is worth. Right
- This is what he tells his athletes— savor every second of it
- But life is going to change
- He tells them, “*You’re going to enter into new seasons and life is beautiful every single day, all around you*.”
- Have this perspective of, “*Yes, this is very important. This is what we’re going after. But true beauty is around us all the time. If we have the eyes to see it and the ears to hear it.*”
- Ryan notes that removing one’s self from performance can be super helpful in some ways
  - When one is in the sport or in transition out of the sport
  - Realizing the performance is “*something that is adding to my life. It is not my life*.”
  - Realizing he can have this day, this beautiful experience of going for a walk outside, looking at the trees, sun, and stars
    - Feeling gratitude for life by simply entering nature and being fully present in it
- His perspective has changed
  - For a long time he was all wrapped up in his performance
    - It’s easy to be that way
    - He enjoys performances and loves seeing growth and going after big goals
  - He still loves seeing growth and thinks this is something that helps people transition out of this sport
    - Many people talk about having a sense of identity loss when they stop their sport
- He had to figure out how to stay true to who he is
  - Running was just an expression of who he is; it was like his painting
  - Now he has to find another mechanism to express who he is
- He has moved on to lifting and crazy challenges
  - He loves physical challenge
  - He loves seeing growth
  - He expresses himself now through lifting
  - And when that comes to an end at some point, he will find another way to express it
- He thinks what humans want is having that experience
  - When one loses the ability to express themself, things can get dark pretty quick

> “*I think as long as we’re continually finding ways to be ourself and to express ourself, we’re going to be happy individuals*” – Ryan Hall

## Ryan’s marathon training regimen at the Mammoth Track Club in 2010 [1:39:45]

**Why Ryan left the Mammoth Track Club**

- Peter notes Ryan’s experience after breaking the half marathon record parallels what happened in 2011
- Ryan goes to [Beijing in ‘08](https://en.wikipedia.org/wiki/Athletics_at_the_2008_Summer_Olympics_%E2%80%93_Men%27s_marathon)
  - His trajectory was unbelievable, he went from 60th to 10th place
  - Though he went into this race with the expectation of the running world to earn a medal, 10th place is still impressive
- Peter asked how Ryan felt going into the [Boston Marathon in 2011](https://en.wikipedia.org/wiki/2011_Boston_Marathon)
- Prior to this Ryan had a big transition
- He was training up in Mammoth; in 2010 he decided to leave the [Mammoth Track Club](https://www.mammothtrackclub.com/)
- His faith played a big part in this decision
  - He’s always been a super spiritual person; he loves that spiritual dimension
  - He was desperate to experience God in some way
- He decided to leave the Mammoth Track Club and essentially have God as his coach
  - But really that just looked like spending a lot of time in prayer trying to connect with God
  - This is where he got this revelation, “*It’s not about what I do. It’s about how I do what I do.*”
- He went through this season experimenting with some new styles of training that he had never done before
  - New stimulus is always helpful for the body
  - He had always been in the same routine, doing the same structure training

**Structure of workouts with the Mammoth Track Club in 2010**

- Peter asks about the structure of his workouts in the 2010 Mammoth days
- On a typical week, Ryan would do intervals on Tuesday
  - This was working on that 5K-specific speed, things like 6 by mile, 10 by K, 800 meter repeats, 400 meter repeats
- Now he has gravitated more toward shorter distance repeats— 400s, 200s, things like that
  - He thinks this is more important for marathoners because one wants a lot of differential between how fast those Tuesday intervals are compared to the Thursday/Friday threshold
- Peter asks, before Ryan left the Mammoth Track Club, were his 1-mile or 1K repeats a set of 10 by a km or 6 by a mile?
  - What was the warm up
  - What was the first thing he would do when he arrived at the track?
- First, he would do an easy 20-minute jog around
  - This was at an 8 minute mile pace; he would be conversational the whole time, not breathing hard
- Then come back and do some dynamic flexibility or maybe some static stuff
  - There was not a lot of static stretching
  - Stretching has not been a huge part of his running at all
  - He wants some tension in his legs
    - The leg muscles are springs; a tightly wound spring is going to respond to the ground quicker compared to a slinky that’s super slow
  - He wants a full range of motion so he would do lots of mobility work to get that full range but still keep some tension in the legs
  - So he would spend 5-10 minutes on drills and strides
    - The strides are maybe 6x 100 meters
    - This is all on his [Run Free Training YouTube channel](https://www.youtube.com/channel/UCJ-ue9QMc9mKdZ7LoL1_JLw)
- Then he would change into his racing shoes and go straight into the workout
- Peter asks, if he’s doing the 6 by a mile, how fast would he run that mile?
  - If his half marathon pace was 4:32 and his marathon pace was 4:42 to 4:45, how much faster does need to run that mile?
- If he was doing it at altitude (7,000 feet), he would typically run around a 4:30 pace
  - At sea level, this is equivalent to 4:20 or so
- So the 6 by a mile and the Ks, that’s more of a 10K-specific workout., but he’d gravitate more towards 5K specific stuff, a little bit quicker
- He would keep the rest fairly short; within the mile he would rest 90 seconds to 2 minutes
  - At altitude, he would rest a little bit more
  - But as you get fit you recover super fast
  - The intensity was not like doing max sprints; that requires a 10 minute break between springs
  - When sprinting in a 10K range, ideally you are running at an effort you can hold for 10K and you’re stopping at a mile; you’re not killing it
- Peter asks if he is walking or standing still during this recovery
  - Sometimes he’s doing a slow walk-jog, it depends
- He likes doing in and out intervals too
  - That was one of [Prefontaine’s](https://en.wikipedia.org/wiki/Steve_Prefontaine) workouts, where he would do 200 meters fast, 200 meters moderate
  - So the moderate part would be at 8-minute pace or even faster, 7-minute pace
  - Then for the fast part, the goal is a 5K pace or slightly slower than a mile pace
  - There are a lot of different variations that they would take on those workouts
- The cool-down would be 20 minutes
- They would spend the rest of the day doing some mobility work, eating, ice bathing
  - The science on the ice bath has changed quite a bit
  - They would go from these workouts and long runs straight to the creek, into cold water
  - Now the science is showing the benefits of having the body to respond to the inflammation first
  - Now they don’t do a ton of ice baths
  - But there are a whole bunch of other good, positive effects of ice bathing, like [dopamine](https://en.wikipedia.org/wiki/Dopamine) going up tenfold
- He would come back in the afternoon for a 30-35 minute easy run then go straight to the weight room and do leg lifts
- A mistake he sees a lot of runners make is to do all their leg stressors on the same day
  - No one feels like doing weights after a hard run
    - Do the hard run first
  - Ideally, do the hard run in the morning and come back in the afternoon to do the weights
  - You can do weights right after a hard run but they probably won’t get as much out of it because you’re bringing fatigue into the lifting
    - It feels better to space it out a little bit more
- After a day like this, he would head home to eat and go to bed early

**The need for sleep**

> “*I always describe my life as more of a professional sleeper than a professional runner*” – Ryan Hall

- He felt like he was sleeping all the time
  - He would book every day from 1-3 pm for a nap
  - He would probably sleep 9-10 hours every night
- Ryan notes that, “*Pro runners are very lazy people from day to day. We don’t go for walks or hikes or do anything. It’s just train, eat, sleep, stay off your feet. And you’re always aware of that energy expenditure. You’re trying to save as much as you can for your training*.”
- Peter remembers in high school, growing up in Canada, they had a lot of amazing Jamaican runners, sprinters
  - They used to tease each other saying, “*Look, we are the laziest people you will ever meet. And if you want to make us run faster, just put a couch at the finish line. Whoever can get to the finish line first gets to lay on that couch*”
  - But it was hard work; these were super intense workouts

## Optimal body weight for competition and the pros and cons of going below your natural weight [1:48:45]

**Intense training is hard on the body**

- Peter notes that cyclists have to work hard and deliberately restrict calories
  - Often they would show up to [huge stage races](https://en.wikipedia.org/wiki/Classic_cycle_races) like the Tour de France, the Giro, the Alta, calorie depleted
    - They are trying to be as light as possible
    - Everything comes down to this 1 metric— watts per kilo
  - “*If you lined up all the cyclists at the beginning of the Tour de France, and you could know what everybody’s threshold was in watts per kilo, that would predict the order they would finish, barring a strategic mishap or an injury or an accident*”
- Ryan agrees, his lifestyle and training was very specific
- Training at that level wasn’t the most healthy lifestyle; it wasn’t optimal for his health
  - His [testosterone level](https://en.wikipedia.org/wiki/Testosterone) was clinically low every time he tested it— in the 100’s, 150
  - Peter notes, this is the level normal for women
- Ryan wonders how one can run so fast with such low testosterone
- Peter remembers his testosterone was in the 220s when he finished residency, and this was low due to sleep deprivation etc
  - But in the 100s is staggering low
- Ryans testosterone level would come up after a 2-week break

**The pros and cons of low body weight**

- Thinking of weight, Ryan is 5’ 10” and his weight got down as low as 127 lbs
  - He noticed his running got worse if he was less than 137 lbs
- Peter compares this to cycling and talking to Lance Armstrong
  - Lance’s race weight was 160-165 lbs; he’s 5’ 9-10”
    - That’s a lot of weight for a guy who is such a good climber
    - Now the GC contender probably weights 140 lbs
  - He talked with Lance in this podcast: [#178 – Lance Armstrong: The rise, fall, and growth of a cycling legend](https://peterattiamd.com/lancearmstrong/)
- Ryan would take a 2-week break where he wouldn’t run at all
  - It was like a donut-eating competition for 2 weeks straight
  - He would literally put on over 10 lbs in that 2-week period
  - It wasn’t good for him emotionally or mentally, but it worked every single time for his build up
  - His problem was he was getting so lean and so light
  - He should have taken a more healthy approach to putting on weight, to being good to his body
    - He should have shifted his macros around during that time off and gained weight in a healthy way
    - He would get up to 150-ish, then it’d be a 6 month gradual reduction in body weight to 137, a couple weeks before his competition
- Weight is highly specific for athletes
  - His brothers, who aren’t athletic, walk around at 160-170 lbs
    - So this was probably the natural range of his body weight
  - When he was trying to get down to weights that were pretty far from his normal, it was unhealthy and that’s why he couldn’t stay in the 137’s, 140s for very long
    - He would get rundown, his motivation would go down, his training would go to crap
  - Take his wife Sara for example, she weighs around 110 lbs and if she wasn’t running, she’d probably be about the same weight
  - Whereas for his, it’s not healthy to be down at 137

## Training volume, importance of mixing up the intensity level, and zone 2 and zone 5 for longevity [1:53:45]

- Peter asks what his weekly mileage was
- It was probably around 110 or so; this was pre-Garmin days
  - He thought it was more, but when they got [Garmins](https://en.wikipedia.org/wiki/Garmin#Wristwear) and started measuring a lot of the loops they were doing for easy runs, he realized the were a mile shorter than they thought

> “*I think this is the other mistake that a lot runners make is they’re just running the same all the time*” – Ryan Hall

- There’s a place for running the same all the time but it’s not going to get you to the next level
- To really see how good you can get, one needs to have super hard days and easy, super chill days
  - Sometimes Ryan runs 12 miles in under a 5 minute pace
  - The next day he will do an easy run— 8m, 30 pace
- Having that variance between pacing is super important
  - This allows one to stress the body, then rest the body (keep repeating the cycle)
  - The body will adapt
- Peter agrees; proper training is one thing he spends a lot of time talking about with patients
  - Most people are training in this garbage zone where it’s too high in intensity to build a true aerobic foundation, and too low in intensity to truly stress the body glycolytically
  - He describes it as [zone 2](https://www.trainingpeaks.com/blog/zone-2-training-for-endurance-athletes/)— he defines it by lactate metabolism
    - Zone 2 is that all day pace; the lactate is below 2 mM
    - Metabolically, it’s a pace that can be maintained all day; it probably can’t be maintained all day from a muscular and structural standpoint
    - This is an easier pace than people are used to training
    - Read more about [how Peter prescribes exercise to his patients](https://peterattiamd.com/how-peter-prescribes-exercise-to-his-patients/?utm_source=roundup-email&utm_medium=email&utm_campaign=220127-ru-stability&utm_content=220127-ru-stability-email-subs)
  - Then at the other end of the spectrum, there’s got to be this real push pace, a 4 by  4 pace
    - 4 on and 4 off
    - Most people aren’t used to that level of discomfort; there are 2 problems
    - 1) Training in a physiologic no man’s land
    - 2) There’s no variability in the intensity of the workouts

> “*I don’t think enough people understand both for performance and also longevity why you have to be at the more extremes of zone 2; zone 5 is where the progress comes*” – Peter Attia

**Caffeine**

- Ryan notes that caffeine helps; he recommends only having caffeine before hard training days
  - Then on the easy day it feels like death because you’re tired fromt he workout but also because of the lack of caffeine
    - This forces you to take it really slow
- Peter notes that some athletes really benefit from caffeine; he never felt that
  - He can have coffee at any time of day; it has no bearing on his sleep
  - So he gets no up from it, no down from it
- There are different genes that are responsible for [caffeine metabolism](https://en.wikipedia.org/wiki/Caffeine#Pharmacology)
  - So people do vary in that
  - Peter has always been incredibly envious of the people who are very sensitive to caffeine because it’s an awesome tool to have in your toolkit for just this purpose

## The most impactful adjustments Ryan made to his training leading up the to 2011 Boston Marathon [1:58:15]

**Peter asks how Ryans workouts changed when he became self-coached** — *What did he do leading up to the* [*2011 Boston Marathon*](https://en.wikipedia.org/wiki/Ryan_Hall_(runner)#Sub-2:05:00_at_the_2011_Boston_Marathon)?

- One big adjustment was to space things out
- He ran intervals on Tuesday and then a long threshold on Friday, with 2 easy days before that
- The **threshold run** is a constant pace, slightly higher than race pace but a shorter distance
  - The pace approaches race pace as the distance gets longer
  - He starts out with 5-6 miles and progresses to 15 miles straight, without stopping
  - He would do 3 of these every week, for 12 weeks building up to the marathon
  - He would be sure to get 3 of these long thresholds in
    - They were his biggest indicator workouts
  - He doesn’t fully taper for this workout and just bang the heck out of it and be like, “*Oh, I can run this for a marathon*”
  - For this workout, your legs need to little bit of fatigued; you need to be in the middle of hard training

> “*Generally speaking, whatever you can run for that 15 mile threshold, you can hold for a marathon, which is also mind blowing and hard for first time marathoners to believe*” – Ryan Hall

- It’s hard to believe that one can go 11 more miles at this pace, but this is the magic of tapering the energy out on the course, carb loading, etc.
  - That body finds a way to hold that through
  - That 15 mile threshold of varying distances on Friday, then Sunday comes back with a long run
- The **long run** occurs when there is already a little bit of fatigue in the legs
  - That would be anywhere from 1 hour 45 to 2.5 hours
  - But during this time, sometimes he would run over the marathon distance
  - These are high quality efforts
  - Oftentimes its at a medium pace, 6-minute mile for the first half and  slower on the second half
    - Just hitting that aerobic end a little bit harder towards the end of the run
- A lot of it is just mentally learning how to turn your legs on when you feel really dead, 25 miles into a race
  - Learning what cues to turn things on and to change gears here
  - Because it doesn’t matter if you’re running a 6-minute pace or an 8-minute pace, when you get 20 miles into your run, you feel tired

> “*And so you got to just learn what mental cues you can pull on to turn everything on*” – Ryan Hall

**How Ryan tweaked his formula after 2011**

- He started spacing things out a little bit more
- He would take 2 easy days between every session
- He was focused on a 9-10-day cycle
  - But was making those workouts higher quality, bigger
- Sometimes instead of those short Tuesday sessions he would do 20 by 1000 meters with a 200-meter easy job between each 1000 meter
  - This was done at a faster than marathon pace
  - The goal is to drive your threshold down
  - He spent a lot of time running threshold at a certain pace; this was a tad bit quicker and it broken up these threshold runs
    - His marathon target pace was 3 minutes per kilometer (for a 2:06:30 marathon)
    - This workout pace would be 2:55; 5 seconds per K
  - He loved this workout for marathon training
  - He may have gotten too far away from 5K fitness then
- Peter asked how many weeks he would succeed in this quicker pace for this Tuesday workout
  - Most days
  - This worked because he wasn’t trying to bite off more than he can chew
  - He wasn’t trying to hit home runs in workouts
  - These were workouts where he was set up to see success
  - Often his thresholds would get better every time he attempted it
  - As the build up is going, he’s getting stronger, getting in better shape, getting lighter
  - He would see good progress in the 12-week buildup to a marathon
- More likely than not, in nearly every build up he would get a little pain
  - Foot  pain, knee pain; little things just pop up
  - This is usually what would cause him to miss a workout
  - This is when he would go to cross training
- He utilizes cross training more now as a coach than when he was running

> “*When I was a runner, I was just kind of the old school, run or die kind of mentality, which is not a helpful mentality to have*” – Ryan Hall

## A new personal record at the 2011 Boston Marathon and lessons on maximizing your own potential [2:03:30]

- Ryan was coming off a terrible half marathon a month before Boston
  - It was one of those scenarios where he began with really high expectations
  - Things weren’t clicking in the race and it created a negative mindset that snowballed
  - He was just trying to get to the finish line
- He can’t remember his time; it was 66 minutes or something
  - Which is 7 minutes off  his personal best
- Training had been going super well; things were clicking; he thought he was in really good shape
- He doesn’t know why the half marathon went so bad
  - This makes it hard to manage mentally
- But he got back up and started training again

> “*I found this over and over again, not just with myself, but with athletes that I coach, oftentimes these races, when you’re in heavy marathon training, won’t go well, but then they’ll turn something on inside of you*” – Ryan Hall

- He came out of this race and started feeling phenomenal; it was a very quick change
- He took his training to the next level
- He headed back to Stanford to train at sea level
  - This was how he’d utilize altitude pre-kids
    - He has kids now, so he can’t do this

**Cycling between training at altitude and sea level**

- He spent 2 months up at altitude, dropped down to sea level for a month; go back up, drop back down
- He took this idea from [Jack Daniels](https://en.wikipedia.org/wiki/Jack_Daniels_(coach)) who has done a ton of research in the running space
  - Daniels is probably one of the most brilliant minds in running
  - He said this type of training produces a dramatic increase in [hematocrit](https://en.wikipedia.org/wiki/Hematocrit), [hemoglobin](https://en.wikipedia.org/wiki/Hemoglobin#Diagnostic_uses), early on in those 1st 3 weeks and then it just starts to taper off
    - This goes back down at sea level
    - But when you go back up to altitude again, it produces another big dramatic shift
    - The goal is to keep shifting up
- There are positives to training at sea level
  - He sleeps better at sea level
  - He runs faster
  - He can do workouts at sea level he can’t do at altitude
- Things started clicking

**Training before Boston**

- He started having caffeine every single day; this was the first time in his career he started doing this
- He started running his easy runs a lot quicker
  - He was just floating through it at a 5:30, 5:20 pace
- Even the day before the race, he did an easy 30-minute run plus 6 x 100 meter strides
  - That was a custom run of his before the marathon
  - He was glad his wife, Sara wasn’t there because she would have killed him for running as fast as he did
  - He was by himself and just hammering at a 5:30 pace
    - But it was easy
- Peter asks what his hematocrit would vary by between sea  level and elevation
- Ryan doesn’t remember; he wasn’t super great about doing blood work
  - It would come up pretty significantly in those 1st 3 weeks for sure
- He felt like a million bucks going into Boston
- But he did have the half marathon performance hanging over him; the feeling of having just tanked

**Talk of a tailwind foreshadows his record-breaking race**

- The day before the race he remembers talking to one of the race organizers; she mentioned they were supposed to get a good tailwind for the race
  - Ryan just lit up inside when he heard this because he gets excited about running fast

> “*I’d rather break a world record than win a gold medal*” – Ryan Hall

- Ryan remembers talking to [Bill Rodgers](https://en.wikipedia.org/wiki/Bill_Rodgers_(runner)) (who won the Boston Marathon 4 times and the New York Marathon 4 times)
  - Bill told him, “*about once every 10 years you get a wicked tailwind in Boston, then you can really roll*”
  - Bill had a year when he got a tailwind, he stopped 4 times in the race to tie his shoe, to walk, to get water, and he still ran 2:09
  - These words were in Ryan’s head at the starting line in [Hopkinton](https://en.wikipedia.org/wiki/Boston_Marathon#Course) that morning

**Race Day— the 2011 Boston Marathon**

- At the start of the race Ryan thought, “*I’m never going to get a day like this again. I’m going to make the most of it*.”
- He always likes to go to the front and lead; this was his signature
- He didn’t let one moment in the race go by where he wasn’t pressing
- He thought, “*I’m going to get everything I can out of every single mile*”
- A lot of his miles were 4:30 in that race
- He came through the half in 61:52
- The race organizer was on a motorcycle in front of him, and he saw Ryan’s split at the halfway point and he radioed his clock eyes, “*Hey, you guys messed up the clocks. It says 61:50*.”
  - And they confirmed, “*Yeah, that’s right*”
  - At the time the world record, was around 2:04
  - So he was under the world record pace
- The first half of the Boston Marathon is slightly down, and he had the wind at his back
- There is Heartbreak Hill at the very end
- From mile 17.5 through mile 20, it’s all up and down hills
  - It’s known as a challenging, slow course
  - But again, if you get the right wind and you make the most of it…
- These aren’t pace races either
  - In most fast races, there are pacemakers there, and they’re in charge of pace
  - Guys are just tucked in for most first 20 miles at least, and then they’re off and running the last 10K
- In this race he was at the front, just hammering and all of Africa was sitting behind him enjoying the ride
  - But he didn’t care; he was going to make the most of that day
- One memory from that race; it was one of the guys on the side of the road…
  - Some of the spots, especially early on in Hopkinton, you’re just going through neighborhoods and stuff; people are out in their lawn chairs
  - One of the guys yelled at me, “*Hey Ryan, don’t let him steal your tailwind*”
  - And he was thinking about that for a while,
- It was just cool to be with those guys, be in the lead group, and also to get to push them along to something that would’ve… It was a super historic day
- The top 2 guys went on to run 2: 03 low, maybe 2:03:04
  - This was almost a minute under the world record at the time.
- And Ryan finished 4th and ran 2:04:58

**The last mile**

- Another memorable part of the race was coming through with a mile ago
  - It was right at two hour
  - But he’s in the serious pain cave
  - He went out super fast, super late in the race
  - No one’s around him and he’s just holding on for dear life
  - He saw 2 hours flat and  was like, “*okay, if I break 5 minutes for this last mile, I’m going to be under 2:05*”
    - His PR at the time was 2:06:17
    - He was already going to run a big PR no matter what
    - 2:05 was insane; that sounds pretty good
- There was a part of him that was like, “*just enjoy this last mile, run 5:30; just soak it all in and just enjoy it*”
- But another part of him thought, “*you know what? You might never be here again. Why don’t you just put your head down, grit your teeth and bear it, try to break five and get under 2:05?*”
- And so that’s what he did
  - And it was a world of pain
  - That last mile is a blur
  - The crowds in Boston were just insane
  - He’ll never forget running down Boylston Street, and the crowds just going crazy
  - He was in fourth place, but he didn’t even care because his performance shifted away from beating other people, to maximizing his own potential
    - And that’s what he get most excited about

> “*It’s about me optimizing what I’ve been given, my gift. And also just seeing the fun part of the growth and the improvement*.” – Ryan Hall

- Coming across the finish line, he just put his hands out and soaked it all in, yelled super loud
- His wife was there at the finish to give him a big hug, and it was a super special moment
- He felt he’d won the race even though he hadn’t
- But it was one of those magical moments (like Houston) that you may never get again
  - So he just soaked it all in and enjoyed it

## Learning from failure and takeaways from his disappointing performance at the 2012 Olympics [2:12:30]

**Going into the 2012 Olympics in London after Boston**

- Peter remarks, “*the most amazing part of your journey is not the successes. It’s the way in which you’ve been able to kind of carry yourself through the failures*.”
- There is this parallel between ’07 and ’08; and then again in ’11 and ’12
  - In how he was feeling going into [London](https://en.wikipedia.org/wiki/Athletics_at_the_2012_Summer_Olympics_%E2%80%93_Men%27s_marathon)
  - The expectations early in that season were very high
- Ryan agrees, coming out of a 2:04, he was going to take a shot at winning this race, even though he’d just been beaten by a minute by those guys
  - He knew he wasn’t expected to necessarily win, but he knew he had a shot
  - If you run 2:04 for the marathon, in those days, you have a chance to win a gold medal
- Talking about not putting on the weight after he ran London, this was a theme going back to [Beijing](https://en.wikipedia.org/wiki/Athletics_at_the_2008_Summer_Olympics_%E2%80%93_Men%27s_marathon)
  - Leading up to the buildup for Beijing and he did the same thing; and it made his training run flat
  - This is where having a coach is a helpful thing
  - If he would’ve told a coach what he was going to do, the coach would say, “*That’s a really bad idea. Let’s just stick with what we know works for you in this situation. And that’s putting on 10 pounds*.”
  - But instead of doing that … his heart was good, his intentions were good
  - He really wanted to hear God, and a way that people across all traditions do this is through fasting
  - So instead of putting on 10 pounds, he did a 1-week fast

**Preparing for London and lessons learned about not depleting his body**

- Peter asks how close this was to the Olympics
  - Boston was April 15th; the Olympics were in August
  - There was enough time for him to get a full buildup for the game
  - He had plenty of time to put on weight and do his usual thing
- But he wanted clarity on how to train for this thing
- So instead of his weight going from 137 to 150 during that 2-week period, it went from 137 to 130 flat
- He started the training in a really depleted state
  - His body wasn’t in a good state
  - Mentally and spiritually, he was in the best spot he’d ever been
  - But his body wasn’t ready to go at all; it needed a break after that
- He began his training and was running pretty well initially, but it went downhill from there
- It became a miracle that he even made it to the starting line, considering how poorly his training was going
  - Just nothing was working
- And this is what he tells himself in the weight room all the time now
  - When he’s getting stale in training and not seeing growth
  - If he’s not taking in enough calories; it doesn’t matter how he’s training, it’s not going to work
- That’s how it was for him in that buildup, his body was depleted
  - He didn’t have enough calories on board
  - It was a frustrating period of training leading up to that
  - He took his watch off for all his workouts because it was so discouraging to see how slow he was running compared to what he was accustomed to
  - It was helpful to get away from the data but it wasn’t enough to get his body back into the state it needed to be in

**Optimism at the start of London but injury leads him to drop out**

- He’s a very optimistic person, so he’s pretty good at generating hope, and there was some genuine hope at the starting line in London
- Sometimes training can go really badly and then, pop, you can have one big day
- He always has the thought that something special could happen today
- But early on in the race the pace felt super hard, super fast
  - This is often the case when he gets too lean and too light; then he has injury issues
- Luckily his chiropractor, John Ball, had him in one piece at the starting line
- But early in the race his right hamstring started hurting, and that’s ultimately what led him to drop out as I was in the middle of that race
  - He was already starting to limp a little seven miles into the race
  - He had to be smart, because this is his livelihood, and he’s looking out for the long term
  - He’s willing to be that guy who comes limping in 7 hours after everyone and gets the cheers and inspires people for just hanging in there
  - But at the same time, he also wants to be good to his body, and he’s not been good to his body a lot
  - It was just kind of a moment where he had a sense of clarity that he needed to be good to himself and call it a day

> “*So that was actually the first race I ever dropped out of in my life, the London Marathon*” – Ryan Hall

- It felt so surreal
- It’s a looped course, so you’re going past the finish and the start a number of times
- He remembers the second loop when he dropped out; he almost started of running again because it just felt so wrong, so weird
  - It felt he was in someone else’s movie or something
  - But then ultimately he just walked off the course and then began the long process of working through that mentally and emotionally

**Mourning London and restoring hope with the next challenge**

- It started with Cinnabon
- The next day he’s touring around with his family in London and sees a Cinnabon
  - He tends to go to food when feeling emotionally low
- He’s sitting out on the curb, just eating it; and he looks up and someone’s taking a picture of him eating this Cinnabon
- He’s learned to pick himself up so many times; he’s gotten a lot better at it.
- For him he needs this period of just just letting himself be sad for however long that takes, a period of mourning the loss
  - Because London was a big goal
- And then the next step is to restore hope, to decide the next thing he’s going after
- Then he has a little meeting with myself of things he’s going to tweak, to do differently, to do better
  - That gives him way more hope that he’s not going to repeat the same experiment
- After London, he’s going back after this sub-5 minute mile and sub-5 deadlift.
  - He’s going to tweak this, this and this, and he really believes it’s going to work this time

> “*You have to believe that your training is going to work*” – Ryan Hall

- That’s why it’s so important for athletes to believe in their coach
  - If you don’t don’t think it’s going to work, it doesn’t matter what’s prescribed, it’s probably not going to work.
  - Belief is so important
- He picked himself up and got going again

**Injuries** [2:20:15]

- But he had a problem with compensation issues
  - This is common in runners
- He had an issue in his upper high hamstring where it attaches, but he just ran through it
  - That issue began because he had plantar fasciitis when training for the 2012 Olympic trials
    - He got that right before the trials, and had no choice but to run through it
    - Then that persisted for eight months
  - And so a little compensation resulted in an injury on the other side, in upper hamstring in the games
- Then he tore his left quad building up for New York
- He tore his right quad building up for Boston
- Then he got a sacral stress fracture on his left side after that, training for the next marathon
- It was literally marathon after marathon
  - He’d sign up for it, get the deal all worked out, then not be able to do it because he’d get some huge injury that would put me out for a long time
- He didn’t have a lot of injuries before this and always considered himself to be super durable
- It was a 4 years of a wild ride trying everything he could think of but ultimately nothing was working

**Should have used better nutrition**

- Looking back on it, a big piece of it was nutrition
- He got to a better point mentally where he didn’t have to use food binging as a mechanism after bad races
- But he still needed to put on weight
  - Looking back, this is a big part of why he had so many struggles from 2012 through his retirement in 2016
- He still needed to get his body in a good spot and wasn’t doing that because he didn’t need to do it from an emotional, mental standpoint
  - Physically, this was killing him

**Should have taken more time off**

- If he could go back, he would do something his mom always wanted for him
  - He would take 3 months completely off and not run at all
  - At the time he thought this suggestion was crazy
  - But it would have been super helpful, just to get away from it and get his body back into a good spot

**Why Ryan feels so much better physically and mentally nowadays**

*Recovery and weight lifting*

- Now he feels better in his current lifestyle, focused on lifting and doing minimal on the endurance end
- His testosterone is better; it was recently tested at 1000
  - He didn’t think this was possible for him
  - This is a result of his lifestyle shift: lifting heavy, eating more calories, having his body in a better state, sleeping a tone
  - His body has been restored
- Lifting has helped him give back to his body
- Lifting is something he’s not genetically gifted at, but he loves the challenge

> “*So every single day I’m in the weight room, I go to failure. And I know that’s not recommended, but that’s just who I am. That’s what I love to do*.” – Ryan Hall

- He feels good where he is now, but he wonders if he would have allowed himself to get into this state back when he was running, how that could have went
- But the competitive running ship has sailed
  - He now weighs 185
  - Running feels completely differently compared to when he weighed 137

## Utilizing cardio and strength training for overall health, and how Ryan uses blood flow restriction in his workouts [2:24:45]

- Ryan notes that hormonal health really affects mental health, motivation, and energy levels
- For him, he can run every single day and be healthy
- But as you get older, you need to do something to offset how depleting of the body this can be
- For him, this is where weightlifting comes in
- He knows a lot of runners don’t want to lift weights; he was the same way
  - But there are ways around this
  - [BFR (blood flow restriction)](https://en.wikipedia.org/wiki/Blood_flow_restriction_training) is one approach
- He’s been lifting super heavy for 6 years and has never gotten hurt lifting
  - It’s not because his form is good
  - It’s because he’s intuitive; if something doesn’t feel right, he doesn’t put on the weight
  - He’s very cautious in the weight room
- There are healthy ways to lift weights
- For runners, he loves to prescribe hex bar deadlifts with the handles up
  - This way you’re not going down as low
  - You’re not loading up the lower back as much

> “*That’s a much more running specific strength that is going to be great for your power development*” – Ryan Hall

- He loves half squats for the same reason
  - A lot of running is just hip extension
  - Every time your foot contacts the ground, your hips have to extend to get out of that position
    - So we need to do things that really focus on that; half squats are great for that
  - And your liability of getting hurt half squatting is way less than butt to the ground
  - So you can load up the bars super heavy with the half squat and get all the hormonal benefits of lifting heavy
    - Get the bone benefits of loading up a bar and having it on your back, and avoid stress reactions
    - Get your bone density up that way and just feel really good coming out
- He’s been playing around a lot with BFR
- He thinks BFR is a way for runners who are maybe skinny, or more concerned about getting hurt, to get the same benefits of lifting heavy without having to put a bunch of weight on the bar
- Peter comments that a couple weeks ago he did some sets on the [Airdyne Bike](https://www.schwinnfitness.com/schwinn-airdynes/?adID=DOSG2BSL01&pk_source=google&pk_medium=cpc&pk_campaign=&gclid=Cj0KCQiAubmPBhCyARIsAJWNpiNYg3RrRswPhXO2f0DR844jNtcIbupijRiX0nLWxtvA5RDRxlVHKCgaAm04EALw_wcB) with heavy BFR on his upper thighs
  - He thought he could hold 300 watts for 2 minutes, but no freaking way
  - He struggled to hold 200 watts for 2 minutes
  - The problem wasn’t his heart and lungs, it was the absolute pain in his legs
  - He wondered if this would be a good form of cross training for cycling
- He wonders if this would translate to running
  - He can’t really walk when he’s in the full BFR
- Ryan thinks this is interesting and is going to try BFR on a run

## Performance enhancing drugs (or lack thereof) in marathon runners [2:29:15]

- Peter asks about drug use in running; for competitive cycling drug use is the norm
- Why is it that marathon runners, who would benefit from tons of performance enhancing drugs (PEDs), traditionally haven’t used them?
- Ryan thinks it’s the culture
- He knew guys who 100% were not on drugs and were winning races
  - [Meb](https://en.wikipedia.org/wiki/Meb_Keflezighi) for example, he won Boston, New York, metals
  - Dean won a medal at the Olympics, and 100% he’s not on it

> “*If you can think of one person who’s doing what you want to do and they’re not on it; you’re like, then I can too*” – Ryan Hall

- Look at [Lance](https://en.wikipedia.org/wiki/Lance_Armstrong) and the cycling culture; this is not the case
- Ryan always chose to believe everyone was innocent, even if he heard rumblings
  - He chose this outlook because he didn’t want to be at a mental disadvantage
  - If he believed the person next to him was on something, then they already had one on him
  - He would think they are going to be superhuman on performance enhancing drugs
  - So he always just believed that everyone was innocent and never concerned himself too much with it
- He’s been around a lot of training groups in the US, a lot of different athletes and never heard of anyone talking about these drugs or having access to them
  - He’s been in Kenya and they do talk about it there
  - There have been guys busted, all over the world
  - So it does happen occasionally in running
- Peter asks, “*What are the drugs of choice? Is it EPO? Is it testosterone?*”
- EPO, and a lot of gray line stuff too
- Where people are just looking for every advantage they can get and maybe crossing some of those lines with [Alberto Salazar](https://en.wikipedia.org/wiki/Alberto_Salazar) and all that
  - He was involved with a doping case that supposedly went down
  - Ryan didn’t follow it closely

## Traits of the greatest marathon runners [2:32:30]

**Ethiopia**

- Peter asks about Africa
- Ryan adopted 4 girls from Ethiopia which speaks to his love of children and how much he’s embraced the East African culture
- What makes Africans great runners?
- Ryan notes it’s a perfect storm or highly motivated individuals who are highly genetically gifted
- There are some theories about a small pelvis being helpful for distance running
- When he walks behind his kids sometimes on hikes he notices how narrow their shoulders are and how small their bone structure is
  - It’s crazy; they’re just so small

**Famous long-distance runners**

- Ryan reminisces about running next to [Haile Gebrselassie](https://en.wikipedia.org/wiki/Haile_Gebrselassie) (one of the greatest distance runners of all time)
  - The first time he ran with him at the London marathon, he caught up to his group and was excited to be running with him
  - He could not get over how small he was
- Their body structure gives them a huge advantage
- He thinks they can run a lot faster than they’re running
- He’s curious about their approach to training versus our approach
  - Who is doing it right?
  - Maybe a blend of these 2 approaches is best
- Peter asks what makes [Kipchoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge) so great
  - He is perhaps the greatest marathon runner today
- Ryan never ran with him; they were coming up at the same time; they’re very similar in age
- He saw him at the London marathon a couple year ago
- Kipchoge is genetically gifted but also humble (that is huge)
  - When you start to think you’re great and done all this great stuff, it almost makes it harder to get back there, or to exceed it
  - He feels like when you buy into how great you are, it kind of sets the limit on you
  - He’s never seen anyone as successful as Kipchoge
- He must get huge paydays to do these marathons, yet he lives in a super simple place
  - He shares a room with training partners
    - How many multimillionaires do that?
- Ryan thinks there’s something about his mentality and humbleness, and that’s really what he’s always found most inspiring about African runners
  - This is why he has fallen in love with their culture, whether it’s Kenya or Ethiopia
  - They have a carfree, fearless mentality of, “*I’m just going to put myself in it and go for it*”
- But Kipchoge also balances that with being very controlled
  - This sets him apart when you read about his training
  - He’s always talking about running like 80% max and everything being super controlled
- Ryan hasn’t gotten results with that type of training, but it works for Kipchoge
- He’s by far in away the greatest marathoner to ever walk the planet
- So whatever he is doing is working
- Ryan thinks a big part of it is his mentality

> “*His mental approach to training and racing is the most composed I’ve ever seen in an athlete*” – Ryan Hall

- Peter asks, “*Do you think we will see a sub two hour marathon as an official marathon in our lifetime?*”
- Without a doubt
- So a woman just ran 62 minutes, 62:50 or something for half-marathon; which is absolutely insane
  - She could be the first woman to break 2:10 for the marathon
  - We’re seeing huge performances like this

**How do the shoes factor in?**

- With the new technology people are running two minutes faster over the marathon with these shoes on
- But I think it’s affected the psyche a ton

> “*What people think is possible now has just been blown up*” – Ryan Hall

- Now people are trying insane stuff, like a sub-2 hour marathon
- That would have never happened without these shoes

## 7 marathons in 7 days on 7 continents—saying goodbye to the sport [2:38:45]

- Peter recounts some of Ryan’s stunts—7 marathons in 7 days on 7 continents sounds ridiculous
  - But it’s made more ridiculous by the fact that he didn’t train for it
- Ryan was retired from pro running when one of his pastor friends from LA ([Matthew Barnett](https://en.wikipedia.org/wiki/Matthew_Barnett)) texted him about this challenge
- Something about it captured Ryan, and he felt like he did at 13 when he was going on that first big run around Big Bear Lake
- He was doing zero runs at this point; he was only in the weight room, focused on strength
- He ended up joining this challenge

**Training**

- He started training because if he was going to do this, he wanted to enjoy it
  - He didn’t enjoy the training
  - He started getting a lot of the same fatigue issues that came with professional running
  - So he decided to stop training and enjoy his life for the 9 months leading up to this
  - He ran 3 days a week, between 5-8 miles
  - 8 miles was his longest run leading up to this challenge where he was going to run 183 miles in 1 week
    - This is by far the most he’s ever run in a week
    - Prior to this maybe he ran 140 miles
    - This challenge involved hopping on airplanes

**Details of the challenge**

- It was a trip of al lifetime
- There was a group of 30 of them
- [Richard Donovan](https://en.wikipedia.org/wiki/Richard_Donovan_(runner)) put it on; it’s called the [World Marathon Challenge](https://en.wikipedia.org/wiki/World_Marathon_Challenge)
- The trip and the challenge cost about $40,000

**Antarctica**

- It starts in Antarctica; this was the coolest marathon
  - It was a 7 mile loop course
  - He thought it was going to be flat and just white
  - There were all these mountains
  - They were on a glacier
  - They had to take a Russian airplane to get there
  - It looked like something out of a movie
- He felt pretty good during the run
- He was super into lifting at the time
- His idea was to take in 50 g of protein every 7 miles or so because he didn’t want to lose his gains
  - This is the opposite of what he usually does
  - Usually he takes in simple sugar
  - With this new nutrition by mile 23 he is completely out of it; he needed sugar stat
  - His protein bar hardly has any carbs in it
  - At a support tent (which was unmanned) they had laid out dried fruit and candy
    - He crawls in there and grabs as much candy as he can
    - He started feeling better immediately
    - He learned his lesson
- He thinks he ran that marathon in 3:30 or so
  - Peter comments on how amazing this is; 3:30 is still fast for a marathon

**Chile**

- The second marathon was in Chile
- They got to sleep in a hotel that night which was nice
  - There were only 2 nights during the week where they got to sleep in a hotel room
- That marathon felt pretty good
- Antarctica was supposed to be really cold, but it didn’t feel that bad
  - Maybe it was a dry cold
  - He wore his regular run stuff that he would use in Flagstaff in the wintertime
  - Full tights, long sleeve, a shell jacket, and gloves/ mittens, and a beanie
  - He wasn’t sweating at all
  - They say you don’t want to sweat because it freezes on you and can cause hypothermia
  - He was good
- He thinks his time in Chile was a little bit faster than Antarctica but not a lot
- Antarctica was nice because running on the snow doesn’t beat up your legs; it’s a little bit softer
- He also used the most cushy shoe he could find because he knew his legs were going to take a beating
- He weighed around 170 at the time

**Miami**

- 3rd they flew to Miami and that was fun; it was like a homecoming back in the states but also warm
- He had more trouble with this one
  - Maybe he ran Miami at 3:30 or something

**Spain**

- 4th they flew to Spain
- He had the words day ever in Spain
- Luckily one of his Dutch friends came over and rode his bike with him on this run

> “*Even when I was running professionally running can be your best friend and your greatest enemy all at the same time*” – Ryan Hall

**Morocco**

- 5th was Morocco for Africa
- They got a hotel room for that one
- Considering how bad he felt in Spain, his goal was to start out super chill and just make it through this one

> “*The mystery of running, why you’d all of a sudden feel so good? I have no idea, but I just started feeling like a million bucks.*” – Ryan Hall

- He started out chill but started feeling good, like his old self
  - He was mentally super engaged, he started charging, and came home super quick
- He ended up running this one around 3:04
  - Which for zero training was really good
- From then on he was pumped

**Dubai**

- 6th was Dubai
- The problem after Morocco was he developed a bit of a limp; his hip was bothering him
  - He thought he could shake it off
  - But in Dubai his hip was on fire and he knew something was really wrong
  - He ended up walking the back half of that marathon
- His time was probably over 4 hours

**Sydney**

- Last they headed to Sydney to finish in Australia
- The whole thing was crazy
  - They were on a private jet with food, movies, everything
  - He didn’t watch 1 movie the entire week
  - Whenever he was on the plan he was asleep; he was so tired
- When they landed in Sydney he tries to stand and put weight on the leg where the hip was bothering him and the pain took his breath away
  - The pain was super sharp
  - He knew he was in trouble
  - He had a hard time putting any weight on it at all
- He was also sick of all the tiny things you do as a pro runner
  - Mobility stretching, etc
  - He wasn’t doing any of this
  - He didn’t wear compression socks the entire week
  - When he got to Sydney his ankles looked like elephant ankles, they were so swollen
    - It was actually painful
- In Sydney he put on the same singlet he wore at his first marathon in London in 2006 or 2007
  - He was thinking, “*this is my last marathon…this is my goodbye tour*”
- He went in with the same attitude he had for his 15 mile run around Big Bear
- He wanted to go out with a bang

> “*I never got to say goodbye to the sport. It’s like, I just faded out. And all of a sudden I was gone and my body wasn’t able to run.*” – Ryan  Hall

- This was his chance to say goodbye to the sport that he loved
- The last marathon was at Manly beach
  - They did a mile out, mile back for the whole marathon
  - It was sick, the beach was lit up by the moon and the stars
  - They were running at 1:00 am for some reason
  - He would have rather gotten more sleep
  - He thinks Richard scheduled the run at night was to give people enough time to finish
  - He needed the extra time that day
    - He got a massage in the middle of the run
    - When he got home and had a MRI he found out he had a stress reaction in his hip
    - Massages aren’t the best for a stress reaction
  - He’ll never forget coming across that finish line
    - The sun was up
    - It took him 5.5 hours
    - It was the longest, slowest, most painful marathon
    - Every time he put his leg down on that concrete he felt the zing of a super sharp pain
    - But after running 6 marathons in a row he was like, “*I’m doing whatever it takes to get through this seventh one. I’m not stopping now and never signing up for this trip again. So I got to get it done.*”
    - He came across the finish line, took off his shoes and left them there
    - This was a finish he stole from Olympic wrestlers who leave their shoes on the mat after they have wrestled their last match
    - It was a symbolic way of saying, “*I’ve given everything I have to give…it’s over, I’m walking away*”

> “*I was tearing up as I was walking back to the hotel just because running gave me so many gifts. It was so life altering for me and the most beautiful part of all of it was the people. Meeting my wife, my kids, all the people I crossed paths with continue*.” – Ryan Hall

## Reflections on what running has given Ryan [2:49:30]

- The people he met are what he holds most dear from that experience
- What’s cool about it is that it doesn’t matter what level you run at
- We all get to experience that when you sign up for any race
  - You’re out there with a 50,000 amazing people that are on a journey with you
  - We get to do it together
- That whole sentiment just hit him super hard; saying goodbye to the sport he loves
- But then, it’s been such a beautiful transition though of realizing that that whole season was about seeing how good he could get
- Since then he’s realized it wasn’t just for him
  - Everything he’s learned in that season was meant to be passed down
  - It was meant to be shared and meant to help other people
- This launched him into the season coaching
  - Coaching his wife, coaching other athletes in person
  - He started [Run Free Training](https://www.runfreetraining.com/) where he coaches runners of every single discipline
    - Every level
    - Super slow people
    - Middle school kids
    - Because it doesn’t matter where you’re at, we just want to be on the journey with you and we want to guide you and help you on your journey
- So it was really special to realize that even all the mistakes that he made, they weren’t for naught
  - He’s on this podcast, he’s able to share it with the listeners
  - And hopefully they won’t make the same mistakes and they’ll be better off for it
- That is his goal now— how he can help people
  - Not just with running but with living
  - Living happier
  - He’s far more concerned with his athletes happiness than with how fast they are

> “*I want them to enter into the good life. And I think running is a way to do that. Lifting can be a way to do that, it adds to that, but more than anything I just want them to find joy*.” – Ryan Hall

- Peter comments that he would love to meet Ryan in person
  - They would have fun lifting together
  - He would love to try some of the crazy challenges Ryan has done
    - He wouldn’t be able to do the farmers-carry up the grand Canyon with a fraction of the weight Ryan used
    - This is something he could see wanting to do one day
- The Grand Canyon is an amazing place
  - Peter has only been there once, but it’s still one of the most significant things he’s ever done
  - When he was there, he made it a hiking / swimming trip
  - He swam in the Colorado river and then in each of the waterfalls on the way up
    - There are thes 4 huge waterfalls that get progressively smaller as you go up

§

## Selected Links / Related Material

**Ryan’s coaching website**: [Run Free Training](https://www.runfreetraining.com/) | [1:45, 51:30, 2:50:45]

**Ryan’s book**; [Run The Mile You’re In: Finding God in Every Step](https://www.amazon.com/Run-Mile-Youre-Finding-Every/dp/0310354374/ref=sr_1_1?crid=2JT6MSUTOTJKQ&keywords=Run+The+Mile+You%27re+In&qid=1640010221&sprefix=run+the+mile+you%27re+in%2Caps%2C76&sr=8-1) by Ryan Hall (April 2019) | [1:45, 40:00]

**Ryan’s Instagram account**: [ryanhall3](https://www.instagram.com/ryanhall3/) | [Instagram](https://www.instagram.com/) (December 2021) | [2:30]

**Ryan’s book about training and marathon running**: [Running with Joy: My Daily Journey to the Marathon](https://www.amazon.com/Running-Joy-Daily-Journey-Marathon/dp/0736944125/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=) by Ryan Hall (February 2011) | [17:15]

**Dr. Huberman who studies palm cooling**: [Huberman Lab: Supercharge exercise performance & recovery with cooling](https://hubermanlab.com/supercharge-exercise-performance-and-recovery-with-cooling/) | (May 2021) | [1:02:45]

**Cooling gloves from Stanford**: [Stanford researchers’ cooling glove ‘better than steroids’ – and helps solve physiological mystery, too](https://news.stanford.edu/2012/08/29/cooling-glove-research-082912/) | Max McClure, Stanford News (August 29, 2012) | [1:02:45, 1:08:45]

**Ryan’s YouTube channel**: [Run Free Training](https://www.youtube.com/channel/UCJ-ue9QMc9mKdZ7LoL1_JLw) | [1:43:30]

**Wikipedia page on Ryan**: [Ryan Hall (runner)](https://en.wikipedia.org/wiki/Ryan_Hall_(runner)) | [Wikipedia](https://en.wikipedia.org/wiki/Main_Page) (December 2021) |

**Article about Ryan’s injuries**: [Ryan Hall is at a Crossroads](https://web.archive.org/web/20210307154811/https://www.runnersworld.com/races-places/a20802855/ryan-hall-is-at-a-crossroads/) | John Brant, *Runner’s World* (October 4, 2013)

**Interview with Ryan’s wife, Sara**: [Sara Hall Gives the Marathon Another TryIn Chicago on Sunday, she’ll try to overcome her disappointing debut in March](https://web.archive.org/web/20160315063703/https://www.runnersworld.com/chicago-marathon/sara-hall-gives-the-marathon-another-try) | Peter Gambaccini, *Runner’s World* (October 5, 2015)

**Article about Ryan’s retirement**: [Ryan Hall, America’s Fastest Marathoner, Retires at 33](https://web.archive.org/web/20210121094011/https://www.runnersworld.com/news/a20859932/ryan-hall-americas-fastest-marathoner-retires-at-33/) | Peter Gambaccini, *Runner’s World* (January 15, 2016)

**Article about Ryan’s retirement**: [His Strength Sapped, Top Marathoner Ryan Hall Decides to Stop](https://www.nytimes.com/2016/01/17/sports/ryan-hall-fastest-us-distance-runner-is-retiring.html) | Lindsay Crouse, *The New York Times* (January 15, 2016)

**Article about Ryan’s transition to weightlifting**:

- [Ryan Hall: from beast on the race course to beast in the gym](https://runningmagazine.ca/the-scene/ryan-hall-from-beast-on-the-race-course-to-beast-in-the-gym/) | Ben Snider-McGrath, *Canadian Running* (July 16, 2020)
- [How America’s top marathoner packed on 40 pounds of muscle after retiring](https://www.si.com/edge/2016/11/15/american-marathoner-ryan-hall-retires-gains-weight-muscle-lifting) | Ask Men, *Sports Illustrated* (November 15, 2016)
- [The Routine That Helped This Runner Put On 40lbs Of Muscle](https://www.menshealth.com/uk/building-muscle/a756652/the-routine-that-helped-this-runner-put-on-40-pounds-of-muscle/?utm_campaign=buffer&utm_medium=social&utm_source=twitter.com&utm_content=buffer246aa) | *Men’s Health* (August, 9 2016)

**Ryan completes 7 marathons in 7 days**: [Ryan Hall says 7 marathons in 7 days gave him ‘sense of closure’](https://olympics.nbcsports.com/2017/02/01/ryan-hall-marathon-world-challenge-antarctica/) | Nick Zaccardi *NBC Sports* (February 1, 2017)

**Documentary of Ryan’s experience at the 2012 Olympics and the redemption that followed**: [The 41st Day](https://www.imdb.com/title/tt12013532/) (2019)

**Ryan’s first ultramarathon**: [Ryan Hall Has Run Six Times in 2020. One of Them Was His First Ultramarathon](https://www.runnersworld.com/news/a33966878/ryan-hall-ultramarathon/) | Andrew Dawson *Runner’s World* (September 9, 2020)

**Comeback of Ryan and Sara**: [The Reinvention of Ryan and Sara Hall](https://www.runnersworld.com/runners-stories/a35537956/reinvention-ryan-sara-hall/) | Rachel Levin, *Runner’s World* (February 23, 2021)

**Instagram post on learning from failures**: [Instagram](https://www.instagram.com/p/CU6VO_4lrVj/) | ryanhall3 (October 11)

§

## People Mentioned

- [Eliud Kipchoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge) (ran a marathon in under 2 hours in 2019) [5:00, 25:00, 1:30:45, 2:34:45]
- [Allan Webb](https://en.wikipedia.org/wiki/Alan_Webb_(runner)) (triathlete Peter used to swim with) [5:15]
- [Sara Hall](https://en.wikipedia.org/wiki/Sara_Hall) (Ryan’s wife and professional marathon runner) [12:15]
- [Meb Keflezighi](https://en.wikipedia.org/wiki/Meb_Keflezighi) (silver medalists in the 2004 Olympic Marathon) [20:15, 24:15, 27:30]
- [Usain Bolt](https://en.wikipedia.org/wiki/Usain_Bolt) (world record sprinter) [29:45]
- [Jim Ryun](https://en.wikipedia.org/wiki/Jim_Ryun) (Olympic track and field athlete; ran the mile in under 4 minutes in highschool) [33:30, 1:13:15]
- [Dathan Ritzenhein](https://en.wikipedia.org/wiki/Dathan_Ritzenhein) (professional long-distance runner) [33:30]
- [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) (retired professional road racing cyclist, won the Tour de France 7 times) [59:15; 1:50:45,  2:30:45]
- [Andrew Huberman](https://en.wikipedia.org/wiki/Andrew_D._Huberman) (neuroscientist at Stanford, studies palm cooling) [1:02:45]
- [Ian Dobson](https://en.wikipedia.org/wiki/Ian_Dobson_(athlete)) (Ryan’s teammate running at Stanford) [1:11:15]
- [Alan Webb](https://en.wikipedia.org/wiki/Alan_Webb_(runner)) [1:13:15]
- [Kenenisa Bekele](https://en.wikipedia.org/wiki/Kenenisa_Bekele) (record holder for running the fastest 5000 meters) [1:24:30]
- [Craig Mottram](https://en.wikipedia.org/wiki/Craig_Mottram) (Australian runner who specialized in 5000 meters) [1:24:45]
- [Steve Prefontaine](https://en.wikipedia.org/wiki/Steve_Prefontaine) (long-distance runner and inspiration for the movie *Prefontaine*) [1:45:15]
- [Jack Daniels](https://en.wikipedia.org/wiki/Jack_Daniels_(coach)) (running coach) [2:05:15]
- [Bill Rodgers](https://en.wikipedia.org/wiki/Bill_Rodgers_(runner)) (former record holder for the marathon) [2:08:00]
- [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) (legendary cyclist) [2:30:45]
- [Alberto Salazar](https://en.wikipedia.org/wiki/Alberto_Salazar) (long-distance runner accused of doping) [2:32:00]
- [Haile Gebrselassie](https://en.wikipedia.org/wiki/Haile_Gebrselassie) (Ethiopian long-distance runner) [2:34:00]
- [Eliud Kipchoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge) (Kenyan distance runner) [2:34:45]
- [Matthew Barnett](https://en.wikipedia.org/wiki/Matthew_Barnett) (pastor friend from LA) [2:39:30]
- [Richard Donovan](https://en.wikipedia.org/wiki/Richard_Donovan_(runner)) (runner who put together the World Marathon Challenge) [2:41:00]

§

![](https://peterattiamd.com/wp-content/uploads/2022/03/1x1-ryanhall-500x500.jpeg)

##### Ryan Hall

Ryan Hall is a two time Olympian for the United States in the 2008 and 2012 Marathon.  He is the fastest American to ever run the marathon (2:04:58) and half marathon (59:43) distances. Ryan retired from professional running in January of 2016 and now is focused on being a good husband, father, and coach.  He is also an author, speaker, and enjoys his hobby of weightlifting with current best of 405 lb deadlift, 395 lb squat and a 315 lb bench press. [[RunFreeTraining.com](https://www.runfreetraining.com/ryan-hall)]