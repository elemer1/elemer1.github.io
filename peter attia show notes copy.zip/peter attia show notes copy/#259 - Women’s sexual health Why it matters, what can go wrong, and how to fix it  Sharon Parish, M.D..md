# #259 – Women’s sexual health: Why it matters, what can go wrong, and how to fix it | Sharon Parish, M.D.

**Source:** [https://peterattiamd.com/sharonparish/](https://peterattiamd.com/sharonparish/)

---

Sharon Parish is a Professor of Medicine in Clinical Medicine and Clinical Psychiatry at Weill Cornell Medical College and a prominent sexual medicine specialist who has been practicing for 30 years. In this episode, Sharon tackles the topic of women’s sexual health, including the conditions associated with decreased sexual function and desire and available treatment options. She explores the influence of sexual health on overall well-being while also examining the potential effects of childbirth, birth control, metabolic health, and more on sexual function and desire. Through case studies, Sharon teases apart the differences between desire and arousal, explains the various factors that affect them, and walks through hypothetical treatment plans for the case study patients. In addition, she delves into the subject of menopause, addressing its impact on sexual health as well as the misguided fears around hormone replacement therapy. Stay tuned for next week’s launch of our complementary podcast on men’s sexual health.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/sharonparish/the_Drive_public.png)

Play

#259 - Women's sexual health: Why it matters, what can go wrong, and how to fix it | Sharon Parish, M.D.

#259 - Women's sexual health: Why it matters, what can go wrong, and how to fix it | Sharon Parish, M.D.

1x15s30s

0:002:48:57

## We discuss:

- Sharon’s interest in sexual medicine and the current state of the field [3:00];
- How hormones change in women over time and how that impacts sexual function [8:15];
- Changes after childbirth and its impact on sexual function [11:00];
- The role of metabolic health and systemic vascular health in sexual health [20:15];
- Conditions associated with decreased sexual function and the importance of sexual health for overall wellbeing [26:15];
- Sexual dysfunction case study #1: A 41-year-old mother of two, the sexual response cycle, and difference between arousal and desire [38:45];
- Medications that may reduce sexual desire [49:45];
- The effect of birth control pills on sexual desire [56:30];
- The importance of testosterone in women for sexual function and desire, and why the FDA hasn’t approved exogenous testosterone as a therapeutic [1:01:15];
- Challenges faced by physicians who are open to prescribing off-label testosterone for women, and Sharon’s approach in managing this aspect with her patients [1:14:30];
- A hypothetical treatment plan for the patient in case study #1 [1:26:45];
- The role of DHEA (a precursor to testosterone) in female sexual health [1:32:15];
- Case study #2: A 30-year-old woman with anorgasmia (inability to orgasm) [1:38:30];
- Resources for helping women and their partners to enhance the pleasure experienced during sex, overcome anxiety, and increase desire [1:51:30];
- Two drugs for premenopausal women with low desire [1:59:30];
- Why treatments are potentially underutilized for both desire and genitourinary syndrome of menopause [2:13:15];
- Case study #3: A menopausal woman with symptoms [2:19:00];
- Addressing the misguided fears around hormone replacement therapy and cancer [2:24:15];
- Symptoms and treatment of genitourinary syndrome of menopause [2:32:45];
- Age 65 and beyond, and resources for finding a provider [2:37:30]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Dr. Sharon Parish is a prominent sexual medicine specialist and Professor of Medicine in Clinical Psychiatry and Clinical Medicine at Weill Cornell Medical College
- Throughout her career she has become a leading expert in sexual medicine, focusing her work on helping patients overcome sexual dysfunction
- She has published numerous articles and book chapters on sexual health and is a sought after speaker and educator on the topic
- In this episode we focus the entire conversation around women’s sexual health
  - For folks who are curious about men’s sexual health, next week we’ll be launching the complementary podcast that focuses exclusively on that
- In this episode we review the female physiology and anatomy to better understand some of the potential problems and treatments available
- We speak about how sexual health and sexual dysfunction can affect a women’s wellbeing
  - And how childbirth and metabolic health can affect women’s sexual health
- We cover a variety of issues that women may face throughout her life by looking at three different case studies
- Using these case studies we differentiate and tease apart the differences between desire and arousal
  - We talk about different classes of drugs that are available to women as it relates to desire and arousal
  - We talk about the impact of birth control
  - We talk about treatments for women who are having difficulty achieving orgasm, including testosterone and DHEA
  - We talk about the role of hormone replacement in addition to many other things
- Peter points out that he learns something with every podcast, regardless of how well he knows the subject beforehand, “*This episode in particular taught me more that I didn’t know relative to any other podcast I can recall. So I think it’s safe to say, whether you’re a man or a woman, you will learn a lot from this episode that will improve the quality of your life.*”

## Sharon’s interest in sexual medicine and the current state of the field [3:00]

**At what point did you realize your interest was in sexual health?**

- Sexual function in woman is a topic where there seems to be a lot of misunderstanding, a lot of asymmetry in attention
- Sharon went to medical school and did her residency in internal medicine and primary care
  - She had a focus on ambulatory medicine and being a general medical physician with a focus on primary care and academic general medicine
- When she was in med school, she struggled to decide if she wanted to be a general internist, a psychiatrist, or a gynecologist
  - This interface between women’s health, the mind and the body, behavioral issues and comprehensive/ holistic care was always tugging at her in three different directions
  - As an internist, she takes care of men’s sexual health as well
- When she found  her way to sexual medicine, it just brought it all together
- In residency she did some projects on women’s health and reproductive issues
  - For example, she worked in a contraception clinic, an adolescent medicine program/ STD program
- After residency, she did a fellowship at NYU Bellevue in psychosocial and behavioral medicine in the general medical field
  - There, she worked with then some sexual medicine experts, and that’s when she really moved more deliberately toward the field

**How does the field stand today? How many physicians in the US have your degree of training and clinical focus?**

- The field of men’s sexual health is a little more clearly defined
  - There are many psychiatrists, urologists, and even men’s health internists who have a clear distinction
- Women’s sexual health is less clear, but there are gynecologists, some internists, family medicine physicians, a few psychiatrists, and then there’s psychological therapists (it goes across disciplines)
  - It’s hard to define but there are many fewer physicians that clearly identify with women’s sexual health
- Sharon went to the [International Society for the Study of Women’s Sexual Health](https://www.isswsh.org/) annual meeting a couple weeks ago, and there were 500-600 attendees
  - That probably represents most people who work in the field
  - There’s sex therapy meetings and pelvic floor physical therapy meetings that have others

***If you’re looking at the field of sexual medicine, it’s not robust***

- As a point of comparison, if you go to the [AUA](https://store.healthecareers.com/aua), everybody there (20,000 people), they could probably handle male ED problem

**What is encompassed in this field?**

- Peter notes that there is a [supratentorial](https://en.wikipedia.org/wiki/Supratentorial_region) component to this, there’s also an anatomic/ physiologic component to this
- Sexual medicine involves integration of the mind, the body, a genital response, and a hormonal response
- Sharon always takes people back to the concept of the [biopsychosocial model](https://en.wikipedia.org/wiki/Biopsychosocial_model) to understand the sexual response
  - There is a bio component, psycho, social, and contextual component
- For sexual health problems, the brain is a really active organ
  - Thinking and feeling on a physiological level translates into neurotransmitter and the interactions with with hormones and pathways, brain neural pathways, neural networks
- And there’s the psychological concepts of conditioning and learning and unlearning
  - The general medical state, our vascular system, nervous system, and systemic medical issues might have an impact
  - It’s fascinating how all that might interact
- Hormones get stimulated by the master glands in the brain, our genitals (that makes [sex steroids](https://en.wikipedia.org/wiki/Sex_hormone)), our [adrenal gland](https://en.wikipedia.org/wiki/Adrenal_gland), and our [thyroid](https://en.wikipedia.org/wiki/Thyroid) ‒ these potentially play a role in sexual health
- The local genital milieu might include the vascular system, the nervous system, small nerves, the mucosa, the surface
  - There are muscles and soft tissue in the genital tract
- The bladder, the rectum, the breasts, also play a role in stimulation

## How hormones change in women over time and how that impacts sexual function [8:15]

**How do these things change during a woman’s life?**

- Obviously, **puberty** is a very important milestone, but Peter suspects **menopause** is an equally important transition that is much more abrupt (at least from an endocrine standpoint than men would experience at the same age)
- Sharon thinks there are times when hormones play a more master role in sexuality and sexual response
- What’s tricky about this is that the body is programmed and smart; there are a lot of life cycle and life stage things happening
  - Whether one commands the other or not, it’s hard to know
- [Menopause](https://en.wikipedia.org/wiki/Menopause) is a longer process than people think
  - There’s [perimenopause](https://en.wikipedia.org/wiki/Menopause#Perimenopause), there’s menopause, there’s [postmenopause](https://en.wikipedia.org/wiki/Menopause#Postmenopause) and there’s a lot of life cycle stuff going on
- Menopause is probably the most defining moment for women in that it interfaces with no longer being able to reproduce, and there are significant changes in hormone levels
  - [Estrogen](https://en.wikipedia.org/wiki/Estrogen) affects the level of vaginal comfort
  - [Androgens](https://en.wikipedia.org/wiki/Androgen) decline at the same time, and that might affect desire
- When you’re starting up with [puberty](https://en.wikipedia.org/wiki/Puberty), hormones are roaring  up and getting going
  - You’re also developing the cognitive skills of relational issues and sexual relationships
- Puberty and menopause are two peak times
- Sharon has worked with adolescents, but she has more experience with mid-life women (that’s the focus of her practice)

***Data suggests (as does her personal experience) that the time people are most interested in looking into this is during the perimenopausal/ late reproductive/ early postmenopausal years***

- People may have a problem and want to understand it better
- They might want to be proactive and preserve their sexuality
- Something is changing that they weren’t expecting, and they want to know why
  - They want to make it better
- People have a little trouble sorting out:
  - Is it the relationship at this point?
  - Is it the menopausal changes overall?
  - Is it sexual function?
  - Or is it all of it?
- That’s what makes the midlife sexual medicine challenges the most complex and challenging, but also the most interesting and the most rewarding

**Midlife women are youthful, they’re young, they’re active, they’re connected**

- They’re not like some other time in our universe where they’re becoming the wise woman sitting in the tent, retiring from childbearing and everything else
- Often, women are peaking in their career
- If they had children later, they’ve got teenage children, college children, aging parents, big careers, bodies changing, and wanting partners (there’s a lot going on)
- So they’re the most likely to seek attention, actually
- We can say a lot about helping them today

## Changes after childbirth and its impact on sexual function [11:00]

**How does a woman’s anatomy change post-childbirth, and does that have anything to do with sexual function?**

- Peter lists some problems he can think of off the top of his head:
  - Low sexual desire (hypoactive sexual desire)
  - Inability to have an orgasm
  - Discomfort or pain ‒ clearly, a big problem for women post-menopause due to vaginal atrophy
- Sharon adds **arousal**, the forgotten sister of desire
- She has women who come to her saying, “*I not longer get turned on*”
  - Is it about wanting?
  - Is it about mental, subjective, or cognitive excitement?
  - Is it about thinking and actually being in the moment and being excited?
  - Or is it about their genitals no longer responding?
    - Sometimes that can be tied to orgasmic difficulties
- In the field, this is an area of discussion and even controversy
- For women, it’s hard to separate what they’re asking for
  - Some women come to Sharon and say, “*I no longer want sex, but everything works okay.*”
  - Or, “*I love this person*”
  - Or “*I want to have sex with myself, but nothing is turning on. I’m not feeling anything.*”
- Learning about that for one’s body and being able to articulate that
  - It commonly gets tied to orgasmic changes

- Peter adds that over a woman’s life, there are these two enormous hormone swings
  - The swing-on is reasonably quick
  - The swing-off is relatively abrupt, but it occurs over years (not months)
    - [Estrogen](https://en.wikipedia.org/wiki/Estrogen) and [progesterone](https://en.wikipedia.org/wiki/Progesterone) are coming off really quickly
    - [Testosterone](https://en.wikipedia.org/wiki/Testosterone) is not coming off as quickly

- Childbirth is *not* typically the time where people come to Sharon with sexual problems
  - Also, she’s not a gynecologist
  - But this is also not a time when sexual problems kick-in and stay
- Postpartum tends to be relatively transient, but this depends on how many kids a woman has and at what age

**The pelvic floor**

- The [pelvic floor](https://en.wikipedia.org/wiki/Pelvic_floor) might be impacted by childbirth
- The pelvic floor is a basket of muscles and they attach from various parts of the inner pelvis, so onto the pubis ramus, onto the ischial spine, onto the bones around our pelvis, internally and into the walls, and then also into the organs

![](https://peterattiamd.com/wp-content/uploads/2023/06/f1-sharonparish.png)

**Figure 1. Pelvic floor muscles**. Image credit: [Physiopedia](https://www.physio-pedia.com/Pelvic_Floor_Muscle_Function_and_Strength)

- They create a basket around the uterus, around the urethra
  - For example, there’s a sling around the urethra in the anus that holds it up and also holds up the uterus
- They also provide motion during childbirth, they allow for the childbirth process
- They’re quite active during sexual activity, they contract and release
- They help us with urination, with defecation and so forth

***The pelvic floor is a basket of muscles that hold things up and help things move***

- Broadly speaking, when they’re not working properly, it can result in difficulty with urination, incontinence, pain during sexual activity, changes in orgasmic function
- With pregnancy, those muscles stretch a lot
  - Sometimes women will notice improvements in their sexual function
- With delivery, they get stretched, they can get irritated and torn
  - It’s rare that any of those things persist unless there was a birth trauma
  - This often gets confused with other things that happen during childbirth such as [episiotomies](https://en.wikipedia.org/wiki/Episiotomy), lacerations, suturing where there can be scarring or inflammation around a suture line, etc.
- Muscle stretching during childbirth is one thing; during pregnancy it’s different from any injury occurring during the birthing process of vaginal delivery
- As an aside, vaginal deliveries are better for women than a [C-section](https://en.wikipedia.org/wiki/Caesarean_section)
  - Most people have this idea that they’re going to preserve the size of their vaginal canal or prevent their pelvic floor muscles from stretching, etc.
  - The truth is, most of that goes back after 4-6 weeks
  - Having an abdominal surgery where you are opening the abdominal wall, there are muscles, this results in scarring that sometimes leads to other kinds of difficulties that people don’t anticipate
  - It’s safer for the mother and the baby not to have surgery
- Peter asks, “*What’s the incidence of C-section versus vaginal birth today in the US?*”
  - This varies from state to state; the rate of C-sections ranges from 22.9-38.2% ([CDC, 2020](https://www.cdc.gov/nchs/pressroom/sosmap/cesarean_births/cesareans.htm))
- The biggest concern Sharon hears in sexual medicine discussions is this idea that it is better for sexual health not to deliver babies vaginally
- The number of C-sections has been going up and it’s alarming

> “*Routine scheduled C-sections to preserve sexual health for a whole number of reasons isn’t really better for women… have your baby vaginally, and most people preserve their sexual function*.”‒ Sharon Parish

- The problem that people come to her practice for is postpartum
- A breastfeeding woman is essentially like a postmenopausal woman because their hormones are dipping way down
  - They keep ovulating “off” by breastfeeding
  - They’re experiencing vaginal dryness
  - Irritation will sometimes change sex drive
  - They’re not aware of the effects of breastfeeding on sexual function, on vulvovaginal changes and the sexual response
    - There are easy things to do for that, especially the vulva and vaginal symptoms

**How high are** [**FSH**](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone) **and** [**LH**](https://en.wikipedia.org/wiki/Luteinizing_hormone) **are during breastfeeding? How low is estradiol?**

- There is so much variability
- It depends on if you’re completely breastfeeding and completely [anovulatory](https://en.wikipedia.org/wiki/Anovulation) ‒ women can look postmenopausal (that’s defined as an FSH >35)
  - Most women aren’t fully anovulatory, they’re having irregular cycles and ovulating intermittently
- The numbers are all over the board, but you can have estradiols as low as 20 or 30
- Everybody’s [HPA axis](https://en.wikipedia.org/wiki/Hypothalamic%E2%80%93pituitary%E2%80%93adrenal_axis) and sensitivity to lactation is a little bit different
- Sometimes women aren’t breastfeeding completely, and the correlation with how much milk they’re making and whether they’re ovulating isn’t clear cut either
- If you’re breastfeeding and you’re not having menses for six months, the likelihood that you’re hormonally similar to a postmenopausal woman is higher and that you’re completely anovulatory
- If you’re having dryness and difficulty and pain and low sexual function, then you should talk to your doctor because they’re things that to do about it (some of the same things that we’ll probably get into in a little while)
- Peter adds, “*If there’s one thing we want listeners to take away from this program, it’s that there’s really no reason for any woman of any age to be struggling with vaginal dryness regardless of how far she is into menopause or whatever. We have the technology to solve that problem all day long, right?*”
- Sharon agrees, that is the most manageable amongst these conditions
  - There are a number of approaches
- She’s a card-carrying general internist, and even though she’s gotten quite specialized in her worksome of her colleagues say, “*Well, you’re not doing procedures, you’re not a gynecologist. What’s the big deal? Do you just come to me, hand them a lubricant, a moisturizer, maybe some vaginal hormones? What’s the complexity of the concept or the consult?*”
- The number one concept that she gets a referral for is to help women understand what’s happening in their body
  - Understand the difference between things she can offer them and how to put them together and use them
  - Then how to integrate that into their sex life

## The role of metabolic health and systemic vascular health in sexual health [20:15]

- In men this is really clear, there is a similar concept of endothelial damage among those with ASCVD, type 2 diabetes, microvascular disease and this leads to a higher incidence of [erectile dysfunction (ED)](https://en.wikipedia.org/wiki/Erectile_dysfunction)

**Do the things that drive glycosylation of proteins and microvascular disease in other parts of the body contribute to sexual health in women as they do in men through the ED pathway?**

- This is an emerging discussion in the field
- There is clear literature and guidance that if a man is having ED, it may be a mirror to small vessel/ cardiovascular/ vascular disease
  - They can use surrogate markers like looking at [Doppler studies](https://en.wikipedia.org/wiki/Doppler_ultrasonography#Blood_vessels) in the urologist’s office of penile and genital blood flow, or a coronary calcium score (or even a coronary CT), and look and see if there’s good evidence supporting that these conditions mirror one another
    - A Doppler study uses waves to look at blood flow through blood vessels
    - It’s very helpful when you’re looking through these smaller blood vessels that you wouldn’t otherwise be able to get a good look into
- If a man has erectile dysfunction (and sexual dysfunction associated), they should have a cardiovascular assessment
- Sharon was just at a two-day meeting where this was discussed ‒ understanding the presentation of erectile dysfunction as a marker for cardiovascular disease
  - And if someone has cardiovascular disease, what kind of recommendations should we make about asking men about sexual function?
    - And then what do you do about it?
    - Do vasodilators work? Do [PDE5 inhibitors](https://en.wikipedia.org/wiki/PDE5_inhibitor) that dilate the small vessels work?
  - Sharon’s participation in this particular conference was about the discussion of do we have similar measures in women?
    - If a woman lacks genital sensation, does that mean she has vascular disease?
    - It’s not as clear cut as when a man comes in because he can’t get an erection
- When a woman lacks genital sensation, you can’t be sure exactly what that is
  - Is this due to the vasculature or the nerves?
  - There has been some research using something called [Clitoral Color Doppler Ultrasound (CDU)](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8458448/) with assessment of the blood flow, which is called the pulsatile index, looking at resistance to blood flow as an objective measure of how to assess arousal on women
    - This is at the research level and not being used clinically except in a very few selected practices that also research this
- So if someone comes in and says, “*I don’t feel*”, you can look with a clitoral Doppler and see if that [lack of blood flow] is the explanation
- Secondly, how well does this correlate with risk factors seen in men?
  - Things like metabolic syndrome, hyperlipidemia, diabetes
  - And if someone has those things, should she then be asking her about clitoral sensation and doing testing, both to understand her sexual function and also as a mirror for her systemic blood vascular risk?
  - Research is just starting to study that
- There is a concept called the **female genital vascular district**, and does that whole area (the larger vessels and the small vessels) give us a correlate or a window?
  - Can we use that as markers for small vessel disease? And then vice versa?
- Is the patient with metabolic syndrome and a high [A1C](https://en.wikipedia.org/wiki/Glycated_hemoglobin), obesity, diabetes, hyperlipidemia, etc. a high risk patient that she should be counseling and talking to about sexual medicine?
  - Then using that as a reason to manage those issues to preserve sexual health?
- First, we need to define the role of clitoral Doppler testing
  - There’s no research on coronary calcium scores in women (or coronary CTs) and they’re correlate with sexual function
- The question of, “*Can we use these both as mirrors of sexual function and predictors of other issues, other vascular issues for women?*” is the most important
- This field needs to catch-up, we can just hand a woman lubricant because shes complaining she’s postmenopausal and not feeling things
  - That’s very crude compared to what we have available for understanding in men

***This is an area of great fascination, but we don’t have a lot to offer women in the office yet***

- In the clinic, Peter often sees a guy with a [hemoglobin A1C](https://en.wikipedia.org/wiki/Glycated_hemoglobin) of 5.9, he doesn’t have type 2 diabetes but he clearly has too much blood glucose and dyslipidemia
  - A year later when he has improved his biomarkers, he also notices that he doesn’t need his [Cialis](https://en.wikipedia.org/wiki/Tadalafil) anymore
  - Peter doesn’t think it’s a huge stretch to assume that women could experience the same thing
- When Sharon talks about this, she likes to say, “*There’s the motivator and there’s the mirror*”
  - It’s obvious when you’re talking about a man
  - You discuss these parameters and ask about their sexual function, ask about difficulty with erections
  - If they report on it, she tells them it can sometimes go hand in hand, and that’s good motivation for many men to want to improve and lose weight
  - She thinks we need to think about women the same way
- We also don’t teach that prevention, lifestyle, and disease management is important for sexual health
  - And validate how important that is for quality of life

> “*There’s all these reasons you don’t want to have heart disease. We should be saying you don’t want to have sexual dysfunction.*”‒ Sharon Parish

***There’s not enough education of people before they have issues***

## Conditions associated with decreased sexual function and the importance of sexual health for overall wellbeing [26:15]

**What can we say about sexual health and general health, over wellbeing as a function of sexual health?**

- They already established causality in the other direction ‒ when your metabolic health and vascular health is poor, it can impact sexual health
- Peter asks, “*Independent of that, if a person is otherwise healthy physically but still having sexual dysfunction, how does that translate into the rest of their life?*”
- Most of the research is association research, so it’s a little hard to tell
- There is a difference between a risk factor and cause and effect
- We know which lifestyle and health factors seem to be associated with better sexual function, better satisfaction, better sexual activity
  - Most of the research is actually in desire when it comes to that
- For example, in women, there’s interesting research that being resilient (having a positive attitude) especially as they get older, having a partner, being connected socially, having support, having a normal BMI ‒all of those things are associated with good sexual function
  - The Mediterranean Diet probably has to do with overall health and wellbeing and the other benefits
- All of these findings are an association, but it doesn’t matter because they’re both are good
- Where it matters as a motivator is that validating the importance of sexual function to quality of life is critical for people feeling that they have permission
  - To preserve sexual function feels indulgent
  - Why go to the gym just to have better sexual function
  - But people realize, “*I can’t have heart disease, I have to go to the gym*”

**Conditions associated with decreased sexual function**

- On the other hand, we know what the heavy hitters are in terms of overall sexual function and biological medical conditions and psychiatric disorders (there is association data)
  - 1 – Metabolic syndrome in women
  - 2 – Obesity
  - 3 – Hypertriglyceridemia
  - 4 – Coronary artery disease
  - 5 – Diabetes
- Interestingly, #4 & #5 is that the condition itself isn’t as clearly correlated as the psychological adaptation (or relationship to the disorder) is for women
  - For example, if someone had a heart attack (or has heart disease) and they’re a female, it’s more about how they see themselves and their interest or enthusiasm in becoming reengaged with activity, than the severity of cardiac disease
  - It’s more about the impact of the disease ‒ are they depressed because they have diabetes?
  - Do they not like wearing monitors, so they’re embarrassed to have sex
  - Or are their feet numb and it makes them negative (rather than an impact of theri blood sugar control)
  - It could be that we don’t have good research, or it might be different in women
- In men, it’s clear, the higher the A1c, the more sexual dysfunction, neurovascular disease, etc.

**Other things associated with lower sexual function and sexual problems in women**

- Cancer: breast cancer, gynecologic cancer, cervical and urinary cancer, ovarian cancer
- Depression and anxiety, and their treatments

*Peter is curious about both of those in both directions*

- For example, if you take two women who are identical in all ways, but one of them is sexually active and sexually healthy and the other one is having sexual dysfunction (for whatever reason, and let’s assume it’s not a physiologic reason, so let’s assume it is a supratentorial reason) and she’s just not sexually active

**Do we have a sense of their quality of life, their wellbeing as a result of that? How important is sexual health for overall wellbeing in particular in this case for women?**

- There’s a collection of different buckets of research looking at this
- The strongest and most consistent research comes out of the desire literature, and looking at the impact of **hypoactive sexual desire disorder** (which is more like a diagnosable condition or distressing low desire on overall quality of life)
- There are a number of well done survey studies (in the community and population studies and clinical data studies collected in clinical settings) suggesting that there’s a strong correlation with impaired desire and overall quality of life
- The problem with this research is that dichotomy or distinction you’re making that it’s purely supratentorial or psychological, relational lifestyle is sometimes so hard to tease out because no one person has zero biology impacting sexual function
  - As a clinician when someone comes to you, you look at the biology and you look at the psychological factors
  - Sometimes it’s past sexual function or sexual trauma or religious upbringing or how they saw themselves as a sexual being from the time they were young
  - Then you look at the relationship and how that is or the culture, and then you look at the things that you think are contributing and those that are amenable to intervention
  - Sometimes you get the idea that it is psychology, but you’d want to be careful not to assume, and be careful that you have thought about everything in their biology
- Back to the question about the condition of someone who has a psychological sexual dysfunction, and what the level of distress is like
  - When people identify it and they want it to be different, it’s extremely distressing and quite impairing to quality of life
- In studies that look at the level of distress and the qualities, they show for example: loss of sexual desire, despairing, hopeless, feeling old, feeling ugly, don’t feel connected, feeling sad, feeling hurt
- Typically in this research, they also look at discrepancy; for example, the discrepancy between a clinician’s perspective and the patient’s when they’re asked by an independent reviews
  - It’s usually way underestimated how distressing/ impairing it is to quality of life

***We don’t do a great job of understanding this***

> “*Part of it is legitimizing this, and that’s what we’re doing here today is really legitimizing this is a real thing for you. It affects your quality of life.*”‒ Sharon Parish

- Sharon wants patients to know, “*It’s okay to tell me, and it’s okay to want this to be different.*”
- When women are given that permission, they embrace it because it is something they are feeling, they’re feeling an impaired quality of life

***This is worth emphasizing, giving this audience permission to understand that you can seek assistance or understanding or even treatment for these things***

- It’s not something you should put as an afterthought in your life because first of all, it’s good for quality of life, it’s good for your relationship
- There is some research supporting the idea that it improves overall health
- Peter adds, “*There’s plausibility to that based on other things that we understand about the relationship between hypercortisolemia, HPA dysfunction, stress, all sorts of things that we know do directly impact physical health.*”
  - His way of thinking about these things is they may or may not impact the length of your life, but the quality of your life is at least as important, if not more important

***Just because evolution didn’t care about something, doesn’t mean we shouldn’t***

- Atherosclerosis is a good example
- Evolution has no interest in preventing atherosclerosis
  - If it did, it would’ve got rid of [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B) hundreds of thousands of years ago because we didn’t need it
  - But it didn’t interfere with our reproductive fitness
  - Now that we can live longer, we have every reason to care about it, and we’ve taken great pains to reduce our risk of dying from it

**Do women have it harder when it comes to sexual health because evolution didn’t necessarily care about their sexual function post-childbearing years, whereas in theory, evolution might care if men could reproduce through the length of their life?**

- Yes, absolutely
- This is a really important topic for discussion
- Sharon often makes the point, “*Women who are perimenopausal, menopausal and postmenopausal aren’t sick*”
  - Sometimes people talk about it, when you have [postmenopausal vulvovaginal atrophy](https://en.wikipedia.org/wiki/Atrophic_vaginitis) (a horrible term)
    - A decade ago, the [North American Menopause Society](https://www.menopause.org/) and [International Society for the Study of Women’s Sexual Health](https://www.isswsh.org/) came up with the terminology **genitourinary syndrome of menopause (GSM)** (Sharon was involved with this process)
    - Things atrophy, but that’s not what they want women to think about
    - This name took away the disease state; it’s a syndrome not an illness

**Genitourinary syndrome of menopause**

- Vulvovaginal atrophy can lead to genitourinary symptoms during and after menopause and the syndrome of menopause
- There are hormone changes as the ovaries stop making things
- The brain does other things to sex steroid hormones
- Testosterone declines in both ovarian and adrenal production
- There are physiologic changes which lead to aging, lead to decreased sexual function, and even complete loss of good sexual function
- Pain doesn’t allow women to engage in quality-of-life-improving sexual activities, relationship-building activities

> “*Evolution has not been kind to women in a whole collection of ways*”‒ Sharon Parish

- In her field, although women aren’t sick, they have the skills, tools, and sophistication to manage it and reverse it
  - This allows a very different outcome than evolution would command

**Challenges in the field**

- Not medicating this too much
  - The aim is balanced therapy to optimize outcomes without giving people other problems
  - For example, if you give a hormone, you don’t want to give breast cancer or endometrial cancer
  - Or if you give estrogen, you don’t want to cause cardiac disease
- Learning how to trick Mother Nature (or evolution) safely but optimize all these things: sexual function, quality of life, longevity

## Sexual dysfunction case study #1: A 41-year-old mother of two, the sexual response cycle, and difference between arousal and desire [38:45]

**A hypothetical case study and Sharon’s workup**

- A 41-year-old mother of two, married, comes into your office and says, “*I love my partner. I just don’t want to have sex. I’m just not in the mood.*”
- The kids are old enough that she’s not sleep-deprived (waking up every 10 minutes)
  - The kids are 10 and 12
- At her age, she’s premenopausal
- Sharon asks, “*Who of you have you seen* [*Masters of Sex*](https://en.wikipedia.org/wiki/Masters_of_Sex#Premise)*?*”
- The whole concept of how to organize sexual dysfunction was first based on the work of [Masters](https://en.wikipedia.org/wiki/William_Masters) and [Johnson](https://en.wikipedia.org/wiki/Virginia_E._Johnson) in the late 50s, early 60s ‒ there is a **response cycle** that has an order
  - Their concept was it was all physiologic because they mostly looked at physiologic parameters
  - 1 – People start with getting aroused, physically and mentally excited
    - Their concept was simple, you engage in sex and you got aroused
    - They didn’t distinguish what came first, desire or arousal
  - 2 – This escalates and reaches a peak or plateau, that can be variable
  - 3 – The classic response cycle results in orgasm (there are different patterns for that to)
  - 4 – The refractory or resolution phase
- For many decades, this is how people organized their thinking
- In the 70s, [Helen Singer Kaplan](https://en.wikipedia.org/wiki/Helen_Singer_Kaplan) (a psychologist at Cornell) added this idea of wanting or **desire** that was distinct
  - It involved thinking about it, anticipating, willingness to engage
  - If you didn’t separate this quality, you were missing something that could be a problem for someone, like this 41-year-old mother of two

**Sharon’s workup**

- This mother might say she’s exhausted between her kids and her job
- Sharon will ask her if she gets turned-on? (yes)
  - Does she have an orgasm? (yes)
  - Is that satisfying? (yes)
  - But the woman says, “*Yea, but I don’t want to have sex*”
- If you get rid of the idea that desire is separate, you miss that last one
  - There’s a lot of variation on that
- Some patients will say, “*Theoretically, I really want to be with this person, but I know that things aren’t going to work. I’m not going to feel anything. I’m not going to get wet. I’m going to have pain, so I avoid and I don’t want because of that reason.*”

***Over the last decade, books have come out in the lay press that are smooshing desire and arousal together, saying they’re indistinguishable for women, but Sharon feels they need to be separated***

- In Sharons’ clinical experience, you need to walk people through this to understand the problem by separating them
- Secondly, the available treatments target different things
  - And the physiologic plausibility for separation is strong in terms of risk factor and response to treatment intervention and the opportunity for future direction in improving sexual function
  - If we keep them [desire and arousal] together, we’re going to lose that

**Separating desire and arousal [44:00]**

- The psychiatric compendiums has now combined desire and arousal, as one thing called [female sexual interest and arousal disorder](https://en.wikipedia.org/wiki/Female_sexual_arousal_disorder)
  - The [DSM-5](https://my.clevelandclinic.org/health/articles/24291-diagnostic-and-statistical-manual-dsm-5) came out about 10 years ago insisted on keeping them the same
    - This was revised in 2022, and Sharon was involved as a medical reviewer, but they insisted, “*We’re not separating them.*”
    - This is based on the idea that for women who show up in psychological and psychiatric offices, it’s often interchangeable
  - It is still separate for men
- Whereas the sexual medicine societies have put out strong position statements as well as nomenclature papers suggesting that we have to have these categories be separate
- The upcoming [ICD (International Classification of Diseases)](https://www.who.int/standards/classifications/classification-of-diseases) is going to maintain separate coding for desire and arousal for both men and women

**The circular incentive model**

- [Rosemary Basson](https://sexologysupervisors.org/faculty_member/rosemary-basson/) is the mother of this model called the [circular incentive model](https://en.wikipedia.org/wiki/Sexual_arousal#Basson%27s_sexual_response_cycle)
- The idea is that instead of a linear response cycle, for some women the cycle is circular
  - What drives sexual response in women isn’t the linear, “*I want to have desire. I want sex. I’m going to go find my partner. I’m going to initiate.” Or, “I’m going to receive, and then I’m going to be turned on, and then I’m going to have an orgasm. It’s going to be great.*”
    - Lots of people when they hear this think they must be abnormal because they don’t feel that way
  - Instead, the circle starts with the motivation and incentive to be close, to drive toward intimacy
    - They’re not feeling spontaneous sexual desire, they’re mostly neutral
- They are close to their partner and want to feel the benefits that come from a sexual encounter with either a partner or oneself
- They are receptive or seek the stimuli, but not because they’re feeling sex hunger (classic desire), but because of this other motivation
- If everything’s intact (psychological and biological influences that govern arousal ability), they’re going to have that arousal
  - Their brain’s going to turn on, their bod
  - Heart rate is going to go up
  - Nipples become erect
  - You’re going to feel the genital sensations, and that will trigger engagement or arousal
  - That’ll make you feel more invested and then more desire and then more arousal, and that will lead to satisfaction and maybe an orgasm
    - It’s a chain reaction
- It’s modeled as a circle, but it’s the idea that that satisfaction, knowing it’s good, knowing you’re going to feel close
  - “The afterglow” is what motivates it, how you feel together
  - How she feels connected in the relationship

***The idea is, if you don’t normalize that thing where desire and arousal are smooshed together (when everything works), you’re going to make people think there’s something wrong with them that they don’t have spontaneous sexual desire***

- Some books out there want to make it okay that you can be motivated by other reasons

- - For example, [Emily Nagoski](https://www.emilynagoski.com/the-facts) wrote a book called [*Come As You Are*](https://www.amazon.com/Come-You-Are-Surprising-Transform/dp/1982165316/ref=sr_1_1?crid=2LEFPWFPGYGUS&keywords=Come+As+You+Are&qid=1681322581&sprefix=come+as+you+are%2Caps%2C202&sr=8-1)
  - Some of the work of [Lori Brotto](https://www.loribrotto.com/)

***Where this model gets confusing is that it doesn’t normalize low sexual desire where you can’t make it work***

**Questions for the patient with low sexual desire, case study #1 [47:30]**

*Back to the hypothetical 41-year-old mother of a 10- and 12-year-old*

- For her, everything works fine, she has a good experience, but she feels that she doesn’t want to have sex
- The **circular incentive model** doesn’t apply to her
  - This model forgets that it isn’t normal to not feel motivated to re-engage
- These people don’t feel reinforcement, they don’t have the desire, the willingness, or the interest in sex
  - It isn’t normal
- Sharon finds this model *does work* for people who are neutral, they engage to be closest in long-term relationships because they know what makes the relationship work

**Sharon will ask this patient**

- Do you feel sex hunger?
- Do you initiate?
- Are you receptive?
- The patient finally says, “*No, no, I avoid it. I finally give in because I know he’s grouchy.*”
- The degree to which Sharon asks specific questions is variable
  - It can be general questions like, “*Do your genitals get turned on? And do you peak? Do you have an orgasm.*”
  - It can be more  specific, “*How does everything work? Does your brain turn on? Do you get breast sensations? Does your body get general arousal? Do you get genital sensations? Do you feel engorged? Do you get lubricated?*”
- Sometimes women aren’t sure so she tries to help them understand what it is they are experiencing
- Sharon always asks if they have **pain with sex**
  - This is often forgotten
- This is a premenopausal woman, she’s no longer breastfeeding, she’s probably ovulating regularly (having regular menstrual cycles)
- Sharon will interweave this with the gynecologic history, the menstrual history
- A 39-year-old could be having early menopause
  - She makes sure she’s not missing that ‒ emerging dryness, pain, discomfort
- Are they taking other medication? Are they on an antidepressant?
- For someone with low desire, she would collect medication information

## Medications that may reduce sexual desire [49:45]

**What are some of the worst offenders [medications that reduce desire]?**

- Peter knows that [SSRIs](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor) wreak havoc in men
- Antidepressants and all categories of psychotropics can affect general sexual dysfunction in a variety of phases
- SSRIs and [SNRIs](https://en.wikipedia.org/wiki/Serotonin%E2%80%93norepinephrine_reuptake_inhibitor) are probably the most well-known to cause multi-phase dysfunction
- This is an area where Sharon works closely with psychiatry because not all drugs are the same
  - It’s a class effect, but there are better drugs, and there are other categories
  - For example, [bupropion (brand name Wellbutrin)](https://en.wikipedia.org/wiki/Bupropion) is more dopaminergic, is a different choice for a variety of reasons
- The classic SSRIs are more likely to reduce desire by around 33-40%
  - This is called **treatment-emergent sexual dysfunction**
- There is some new research that is debunking some of this
- Examples of SSRIs that are associated with decreased desire: [Prozac](https://en.wikipedia.org/wiki/Fluoxetine) (generic fluoxetine), [Zoloft](https://en.wikipedia.org/wiki/Sertraline) (sertraline), [Paxil](https://en.wikipedia.org/wiki/Paroxetine) (paroxetine), [Lexapro](https://en.wikipedia.org/wiki/Escitalopram) (escitalopram)
  - Patients will say, “*I developed low desire on Prozac*” or “*I have difficulty with orgasm on sertraline, on Paxil, but not on Prozac*”
  - So she will try a few different ones
- Peter’s experience is the same, “*There’s a class effect, but at the end of the day, it’s kind of drug-specific*”
  - He doesn’t prescribe those, a psychiatrist does
  - But he always says, “*The probability that you’re going to get it right on the first one in terms of efficacy and side effects is actually not that high. So you have to be willing to switch drugs to find that right combination of efficacy and avoidance of side effects. And you’ll be able to stay within the same class, usually, but there seem to be non-trivial effects*”
- These drugs are used to treat depression or anxiety (or both)
- The other category of drugs are the [SNRIs](https://en.wikipedia.org/wiki/Serotonin%E2%80%93norepinephrine_reuptake_inhibitor), the serotonergic-norepinephrine drugs
- There is more variability in the data on SNRIs
- Commonly used SNRIs: [Effexor](https://en.wikipedia.org/wiki/Venlafaxine) is probably the most common (generic venlafaxine), [Cymbalta](https://en.wikipedia.org/wiki/Duloxetine) (duloxetine), [Pristiq](https://en.wikipedia.org/wiki/Desvenlafaxine) (desvenlafaxine)
  - These are probably similar to the SSRIs
- Venlafaxine is interesting because at a low dose, it functions more like an SSRI (up to 75 is probably low)
  - Somewhere over 150, it functions more like a SNRI
  - So teasing out he sexual dysfunction and the dose dependency is a little tricky for that one
- There are some data on desvenlafaxine that suggest it’s less likely to cause sexual dysfunction
  - It probably has to do with the chemical composition and how it’s different than venlafaxine
- Vilazodone and vortioxetine, have very unique and different mechanisms, and they seem to be better
  - They’re complex serotonergic, dopaminergic transporters
  - They’re a little complicated in their mechanism, but the bottom line is they work both with serotonergic transporters as well as dopaminergic drugs
- The drug with the best data for fewest sexual side effects is vilazodone
- The problem with the research on desvenlafaxine, vortioxetine, and vilazodone (the newest drugs), is that there was high sexual dysfunction pre-treatment
  - So separating the effects of placebo and treatment are difficult
  - It may be simply that treating the disease state of depression improves sexual function
- The other drug is [mirtazapine](https://en.wikipedia.org/wiki/Mirtazapine) (brand name Remeron)
  - It is an atypical SSRI
  - There is very low sexual dysfunction associated with it as compared to other SSRIs
  - It has some other problems with side effects ‒ it can be sedating (which is good for people who don’t sleep), some people report weight gain (maybe because of the dopaminergic component)

**Back to case study #1, the 41-year-old woman** [54:30]

- There’s some research that’s come out (for both menopausal women and women in general) that the best thing to do for a depressed person for sexual function is to treat their depression
- Sharon is still having trouble teasing this out
- Probably the best thing to do is pick the best drug to treat their depression

***It’s more important to get them undepressed in terms of sexual function, even though the numbers in other studies say 30-40% will get treatment-emergent sexual dysfunction***

- If their depression improves but their sexual dysfunction does not, then it’s probably due to the drug
  - So then you try switching the drug around

**Other drugs that may disrupt sexual function**

- The other big category of drugs are antipsychotics and anxiety meds
  - They are less commonly prescribed
  - They all have some issues around sexual function
- Blood pressure medication is another category to think about
- A collection of pain medications are another big bucket
- Hormone-suppressing drugs, such as an [aromatase inhibitor](https://en.wikipedia.org/wiki/Aromatase_inhibitor) for cancer prophylaxis

![](https://peterattiamd.com/wp-content/uploads/2023/06/f2-sharonparish.png)

**Figure 2. Medications associated with low sexual desire in women**. Image credit: [*Sexual Medicine* 2018](https://www.sciencedirect.com/science/article/pii/S2050116118300266?via%3Dihub)

## The effect of birth control pills on sexual desire [56:30]

**Let’s assume this 41-year-old is not taking any of those psychotropic meds. Would her oral contraceptive have any effect on desire?**

- This is a very important topic for this age group (hormonal contraception)
- This is a very confusing area where people are very polar and opinionated
- It’s not just oral contraceptives, it’s [combined systemic hormonal contraception](https://en.wikipedia.org/wiki/Hormonal_contraception)
- For example, birth control pills have estrogen and progesterone
- Patches like like the [Ortho Evra patch](https://en.wikipedia.org/wiki/Contraceptive_patch), and the ring ([NuvaRing](https://en.wikipedia.org/wiki/Ethinylestradiol/etonogestrel)) also use a combination
- Sharon points out, “*What are you doing when you give hormonal contraception? You’re turning off the brain and that feedback loop that makes you ovulate, make a lining, shed it, and be able to have a pregnancy, and then shed it if you don’t. And you’re turning that all off by giving super high doses of hormones.*”
- A small percentage of women (10%) get that high level of estrogen, but the vulvovaginal doesn’t recognize it, and they can develop a [vestibulodynia, a vestibulitis](https://en.wikipedia.org/wiki/Vulvar_vestibulitis)
  - The vestibule is that tissue around the entrance to the vagina, not so much inside the vagina, but that surrounding tissue called the vestibule
  - The vestibule is very sensitive to the drop in these endogenous estradiol, and sometimes the synthetic estrogens don’t do their trick, and women develop pain and dryness
    - They almost look like a postmenopausal woman
- A similar number of women using a ring or patch are probably affected in this way too, but it’s not as well documented

***Low-dose oral contraceptives (20 micrograms) have been implicated in this, and people do better if they have a more robust/ high dose (the standard 35 milligram pill)***

**Is** [**Lo Loestrin**](https://en.wikipedia.org/wiki/Ethinylestradiol/norethisterone_acetate) **considered low?**

- Yes, that’s an example
- The ultra-low ones tend to be the biggest culprits
  - The experts in the field feel this is very important, but the ordinary gynecologic community thinks it’s relatively insignificant
  - Whether they are under-detecting this is something that needs more development
- Birth control pills can also have an effect on neurotransmitters
  - Sometimes women will develop mood issues with high-dose oral contraceptives, and that may have an impact on the neurotransmitter milieu that leads to sexual dysfunction and low sex drive
- As women get older, oral contraceptives can have an effect on the local vulva tissue
  - This is particularly an issue with the **lowest-dose estrogen pills**
- Another issue depends on the androgenicity of the birth control pill
  - It may change sensitivity or even lead to pain
  - There are androgen receptors in the vulvovaginal tissue
- The second thing is that intersection with brain neurotransmitters and mood, and that effect on sexual function could also be clinically important

**Sex hormone-binding globulin (SHBG)**

- When you send all that hormone into someone’s body, you increase the production of [SHBG (sex hormone-binding globulin)](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin)
  - 100% of women who take birth control pills have increased levels of SHBG
- SHBG goes up in other states such as pregnancy or when you take a thyroid hormone or when you take birth control pills
- SHBG helps carry around estrogens and androgens (or testosterone)
  - This binds up circulating testosterone, and you may be lowering free testosterone ‒ this might be another potential contributor to low desire

## The importance of testosterone in women for sexual function and desire, and why the FDA hasn’t approved exogenous testosterone as a therapeutic [1:01:15]

**How does testosterone affect desire?**

- This probably happens at the level of brain receptors and turning on those pathways of desire
- Also, there’s some genital changes
  - The metabolites of the androgens change sensitivity, and that might impact desire, but that’s a secondary state
- The level of testosterone doesn’t change abruptly with menopause like ovarian hormones do
  - It’s more of a gradual decline

**The intersection between contraception and women in their late 30s and early 40s and testosterone is interesting**

- By the time a woman is in her late 30s/ early 40s, her testosterone is about half what it was at age 18
- Then it levels off at a somewhat lower level in her 40s/50s before it goes up a little past age 60, then it levels off
- For the woman on birth control pills, that curve is way down
  - A woman at age 40 might be much more sensitive to that effect than she was if she was on a birth control pill at age 25
  - That difference in her free testosterone may be significant and drive her to come in and say, “*I have no sex drive*” or “*I have no general sensitivity*”

> “*That’s an important thing that most people don’t tell their patients when they put them on a birth control pill or combined contraception for 20 years*”‒ Sharon Parish

**What happens to the level of** [**SHBG**](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin) **when a woman switches from a birth control pill to an IUD?**

- Let’s say a woman takes a birth control pill from age 20-40
- Then she switches to an IUD after her second or third baby (this happens a lot)
- [Claudia Panzer](https://www.comp-endo.com/our-physician.html) did a really good [study](https://pubmed.ncbi.nlm.nih.gov/16409223/) on this in 2006
  - She looked at current users of oral contraceptives, never users, and users who stopped six months ago
  - The bottom line is that users who stopped six months ago had SHBG levels in between the other two groups
    - SHBG levels had not gone down to normal
- No one has studied this out to three or four years

***In Sharon’s experience if a woman has stopped taking oral contraceptives, her SHBG levels are always going to be higher than the person who never used them***

- The theory is that her free testosterone at age 40 is lower than it would’ve been if she hadn’t used birth control pills for 20 years
- Roughly 85% of the androgen binding is coming through SHBG
  - [Albumin](https://en.wikipedia.org/wiki/Albumin) is a relatively small contributor to this process

***Sharon clarified by email that 5% of testosterone in circulation is strongly bound to SHBG, 30-45% is loosely bound to albumin, and a small fraction (1-3% is circulating as “free testosterone”***

**Part of the controversy is it’s not clear that free testosterone is the bioactive component to what makes desire happen both in the cells and in the brain**

- Naysayers say this is not necessarily the active component, and looking at SHBG and free testosterone might not be what we need to be doing
- Peter dives into the nuance of measuring testosterone
  - There’s an assay that breaks apart and separates testosterone from albumin, from SHBG, and you actually measure in nanograms per deciliter (ng/dL) the concentration of testosterone in that plasma
  - When people talk about free testosterone, that’s *not* measured, it’s calculated
    - It’s *estimated* based on the measured testosterone, the measured SHBG, and the measured albumin
- There is a whole other issue which Peter doesn’t think gets enough attention (he plans to explore this in subsequent podcasts) ‒ androgen receptor saturation

**A clinical example of androgen receptor saturation that Peter see’s in men (it applies to women too)**

- Two guys both have a total testosterone of 500 (assume their free testosterones are estimated to be roughly the same); you give them both testosterone so they have a total testosterone of 1000
- One feels significantly better, but the other doesn’t really notice a difference

***There’s an argument that says that the guy who doesn’t feel any different already had his androgen receptors saturated***

- So yes, you drove up his testosterone and more of it is free, but where it matters most in the nucleus, at the androgen receptor, this hasn’t increased
- The first guy who says, “*Oh my God, you’ve changed my life. My libido is higher. I’m recovering from workouts better. I’m putting on muscle. Everything feels better,*” ***he was probably undersaturated***
- We don’t have a way to measure this clinically
- Sharon agrees, this is part of it
- There is a lack of clarity about female testosterone, less is understood about the role of circulating free testosterone, what is bioavailable, and how it’s interacting with the androgen receptor both in genomic and non-genomic mechanisms
- What cells are responsive in a woman?
  - Is it her brain? Is it her genitals? Is it her nipples? We don’t know.

***The theory is that the most important place testosterone acts is in the brain***

- Where is that happening at the cellular level in the brain?
- The most general concept is that testosterone (and its metabolites) is the hormone of desire
  - It interacts with brain neurotransmitters to turn on pathways of desire
- The early work of the psychologist [Helen Singer Kaplan](https://en.wikipedia.org/wiki/Helen_Singer_Kaplan) talked a lot about this, she said, “*The goal is to fine tune that just the right amount of giving exogenous testosterone safely to turn the reign back on to where she was when she was satisfied (meaning premenopausal satisfied), but not invoking lethality and keeping her safe.*”
  - This is Sharon’s mantra
  - That titration is the work of desire treatment when you’re using pharmaceuticals
- The argument is:
  - Do we know what’s actually happening?
  - Do we know what we want to fix?

**Why the FDA has not approved testosterone for women [1:08:15]**

- Getting back to this 41-year-old mother of two…Let’s say she took birth control pills for 20 years, and she stopped them on and off to have kids, but she’s still taking them
- Her SHBG is high, and her free T measures low, and she has low desire
  - Is this enough to say, “*That’s why*”?
  - Then, will stopping her birth control pill solve the problem if SHBG doesn’t come down
    - Or is Sharon going to give her a doomsday prognosis
    - Women ask, “*Well, what if it doesn’t come down? Will I be like this forever?*”

**Is she a candidate for exogenous testosterone if she’s premenopausal and still menstruating?**

- Peter points out, “*We think of testosterone as the man’s hormone, [and] estrogen, progesterone as the women’s hormone, [which is] not entirely correct*”
- One of the challenges is that labs report different units for estrogen and testosterone
  - Testosterone is typically reported in nanograms/deciliter (ng/dL)
  - Estrogen is reported in picograms/milliliter (pg/mL)
  - When you convert these to the same units so you can do an “apples to apples” comparison, ***you realize that testosterone is much higher in a woman than estrogen is***

> “*A woman has much more testosterone in her body than she has estrogen. This is a staggering thing that surprises most women and most men alike.*”‒ Peter Attia

- To Peter, the implication is that given that testosterone is the most abundant sex hormone in a woman’s body (both pre- and post-menopause), it’s not surprising that changes in testosterone can be just as important in women as they are in men
  - There is an even bigger gap in the difference between testosterone and estrogen postmenopausal because of the rapid decline in estrogen
  - Testosterone is thought to be largely responsible for **desire**
- Sharon agrees, this is such an important point, and people have a hard time wrapping their brain around it
  - Women think the only hormone they should be talking about is estrogen
- There is this idea that estrogen supplementation improves sexual function, but that’s a whole different discussion

***The importance of  testosterone to the function of a woman’s sex organs, sexual function, and sexual desire is poorly understood***

- Peter adds, “*This is where I think there are lots of places we can fault the medical system*” (we’ll get to those in a minute)
- One is the double standard and lack of scientific rigor around **evaluating testosterone replacement for woman**
  - There were two studies, a [gel](https://pubmed.ncbi.nlm.nih.gov/16183220/) and a [transdermal](https://pubmed.ncbi.nlm.nih.gov/16014407/) testosterone product ([Intrinsa](https://en.wikipedia.org/wiki/Testosterone_(patch))), and they found a benefit
- There was a **Johnson and Johnson patch (300 micrograms, 𝜇g)**, and it raised testosterone, improved sexual function, and the side effect profile was not of concern
  - This drug should have been approved
  - Peter asks, “*Why did the FDA not approve it?*”
- There was a wonderful [meta-analysis](https://pubmed.ncbi.nlm.nih.gov/31353194/) of around 50 studies published in *Lancet* in 2019
- There have been a number of randomized controlled trials using patches
  - The Intrinsa brand by Johnsona nd Johnson was a campaign that was brought to the FDA based on their randomized trial
- Sharon uses the [2000 study by Jan Shifren](https://www.nejm.org/doi/full/10.1056/nejm200009073431002) in the *New England Journal of Medicine* a lot
  - It used a 300 micrograms testosterone patch in [oophorectomized](https://en.wikipedia.org/wiki/Oophorectomy) women, young women who had low desire
    - 300 micrograms was the estimated physiologic amount, the amount you would expect in mid- or late-reproductive age (age 27-38)
  - The outcome of interest was Hypoactive Sexual Desire Disorder or sex drive or libido
  - It showed positive improvements based on both self-report of satisfying sexual events as well as other phase responses (arousal, orgasm, overall satisfaction)
  - It showed no adverse effects in the short run
    - In 18% of women it caused [hirsutism](https://en.wikipedia.org/wiki/Hirsutism), a little hair growth on the face and along the nipple, and it caused mild acne
  - It looked at intermediate cardiovascular outcomes, cancer outcomes and metabolic outcomes
  - It was a 24-week trial (six months)
  - The women did well and they liked it
- The issue for the FDA wasn’t efficacy of the Johnson and Johnson 300 microgram patch, it was **lack of long-term safety data**
  - A lot of Sharon’s colleagues were very upset that it wasn’t approved
  - It did get approved in Europe for that indication ‒ oophorectomized women with low desire
    - And it was used off label in other postmenopausal women
    - It went off the market for reasons other than efficacy or safety
    - It’s no longer available in Europe as a 300 microgram patch

***No patch is available anywhere in the world for women***

## Challenges faced by physicians who are open to prescribing off-label testosterone for women, and Sharon’s approach in managing this aspect with her patients [1:14:30]

**Bad science and fear surrounding the use of hormones in women**

- Peter points out, “*One of the reasons given for the fear around this use of topical testosterone was extracted from the incorrect and erroneous fear that still lingered from the* [*Women’s Health Initiative*](https://jamanetwork.com/journals/jama/fullarticle/195120)”
- The second problem is the double standard, “*How many topical, injectable, transdermal testosterone products are approved for men right now in the United States?*”
  - At least two dozen depending on how you look at the indication, whether it’s for hypogonadism versus sexual dysfunction
  - Those products get approved on biochemical efficacy
  - They don’t require the five-year safety window because we’ve already established over decades that exogenous testosterone at physiologic doses is safe
  - You can prescribe it off-label to women

**Why does this matter?**

- The first drug [LibiGel](https://biosantepharma.com/LibiGel.php) never made it to the FDA, they withdrew their application
  - It didn’t have efficacy
  - They looked at the data for out to five years, and had seven years of women patient data research, and it didn’t show any hits for being unsafe
    - It was loaded for women with cardiovascular risk factors
    - There was no increased rates above baseline rates of cardiovascular disease, of breast cancer, of intermediate markers for metabolic or cardiovascular risk like A1C lipids, inflammatory markers
  - And they reached the therapeutic level in the blood
  - They could clearly state this represented safety data, but the efficacy hit wasn’t met so they did not take it further to the FDA
    - And that’s been the last effort since then

**Why don’t they approve these testosterone products?**

- The concept has been proven, we know the FDA makes the assumption that it’s safe
- The problem is the hormone and reproductive and reproductive end
  - There’s no precedent

***The expert consensus in the field is that it’s safe, but you can never get there if you don’t approve something at 24 weeks***

**Australia is the only place in the world where a government has approved testosterone**

- [AndroFeme](https://www.nps.org.au/assets/medicines/47d5a936-d106-46a4-9278-a53300ff76e5-reduced.pdf) and it’s 5 milligrams (manufactured by [Lawley](https://www.lawleypharm.com.au/products/))
- You can go up to 10 milligrams, that gives you this physiologic amount of testosterone
- People get confused because the patch was 300 micrograms
- AndroFeme is based on the same research, the same numbers, the same blood levels, the same outcomes
  - There’s a way for practitioners from other countries by sending their licensing information to actually order it for patients, but it’s not done very much
- There is no where else in the world where testosterone is approved for women

**You ask, “*****Why does it matter?*****” we prescribe testosterone off-label**

- The problem is there’s no regulation
- Study of the 300 microgram patch that was [rejected FDA](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC535443/) was discussed earlier
  - There have been a number of randomized controlled trials looking at similar doses, mostly in patches looking at women on and off estrogen, pre and post-menopausal surgical and natural menopause that have shown the same efficacy with the outcome of HSDD (Hypoactive Sexual Desire) being the primary outcome and showing other parameters with improvement like arousal, orgasm satisfaction, etc.
  - The [consensus papers](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8064950/) that have come out in the last couple of years say that there are two different guidances ‒ this is indicated for women in late reproductive age and definitely in postmenopausal women

***You can prescribe testosterone, it’s off-label, but it’s supported by all of this efficacy and safety data. The problem is, it’s impossibly hard to prescribe it carefully and with precision, unless you’re in Australia.***

**The lack of precision is a problem**

- Peter points out that you’re using a male topical product and the doses are wrong, *You’re stuck using* [*Androgel*](https://www.androgel.com/)*, which by the way I think is a suboptimal product even for men*”
- You can take an FDA-approved patch and cut it into little pieces
- You cannot use the FDA-approved injectable because the concentration is too high (200 mg/mL), basically you would need just what’s in the needle (not the syringe)
- You’re left with three options and none are an FDA-approved product
  - A compounded cream, a compounded injection (they can compound it at 20 mg/mL of testosterone which is 1/10 of the male dose), or compounded pellets
    - For the pellets, you can get an FDA certificate for the raw ingredient, but it’s not an FDA-approved product in the way that the [Vivelle-Dot](https://www.drugs.com/mtm/vivelle-dot-skin-patch.html) topical estrogen is

**Normal ranges of testosterone in women**

- [Irwin Goldstein](https://www.sdsm.info/meet-dr-goldstein) was involved with work to characterize normal ranges of testosterone for women

![](https://peterattiamd.com/wp-content/uploads/2023/06/f3-sharonparish.png)

**Figure 3. Testosterone (T) and androgen levels in adult females**. Image credit: [*The Journal of Clinical Endocrinology and Metabolism* 2005](https://pubmed.ncbi.nlm.nih.gov/15827095/)

- The idea is, when you treat a woman, you want to go to the physiologic range for a mid-late reproductive age woman
- You can measure using a standard direct total testosterone assay
- Treating women with testosterone was found to be safe and efficacious ‒ 36 randomized controlled trials (close to 8,500 women) were analyzed in a [systematic review and meta-analysis](https://pubmed.ncbi.nlm.nih.gov/31353194/)
  - Data is not lacking
- There is decent outcome data for up to 4-5 years and randomized trial data for up to 24 weeks
  - This is not any different than what we have for men
  - But for men, there are FDA-approved products and data about their long-term use
- Peter adds, “*it’s a little bit of a cart horse problem, which is we’re stuck in this paradigm where unless we get some approval, we can’t get out of it to do the longer studies that you’ll see post-market… effectively the Phase 4 trial.*”

***For women, you need to use 1/10th of a male dose because that’s what probably gets you to the physiologic range***

- The [product](https://www.nps.org.au/assets/medicines/47d5a936-d106-46a4-9278-a53300ff76e5-reduced.pdf) approved by the Australian government does this
- So you start there and monitor the levels
  - There’s not cut-point for saying “*this testosterone is the one*”
  - You don’t treat testosterone, you treat a syndrome (HSDD)
- Sharon usually checks baseline testosterone levels to make sure they’re not high
  - Someone may come to her at age 52 and their testosterone is surprisingly high, for them this is not the solution
  - But if it’s low (not abnormal but normal for their age), then Sharon treats them to that reproductive physiologic level using 1/10th of the male dose

***The*** [***position papers***](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8064950/) ***Sharon has been involved with state that because it’s so hard to get consistent concentrations, the recommendation is to use transdermal male products at female doses as opposed to compounding***

- - If you’re going to compound, you’re probably better off with transdermal than a pellet or an injection because of the peaks
    - ***The key thing is, you don’t want to get into that super physiologic level, which hasn’t been demonstrated to be safe in women***

- ***It’s so hard to use one-tenth of a male dose***

- Sharon prescribes a 30-day supply of 1% testosterone tubes
  - The pharmacist often rejects the prescription because it’s not covered by insurance
  - Sharon tells patients to look at a cost saving app and find the cheapest place to fill the prescription, usually $200
  - ***She has patients waste one tube, divide it into 10 little piles and figure out how much they need to apply everyday to get to the physiological level***
    - You can buy a 5 cc syringe at the pharmacy and squirt the tube in and use half a cc a day
    - One of Sharon’s patients is a baker, and she discovered that a cooking spoon somewhere between a pinch and a smidge was 1/10th of her packet
    - The patient does a blood test in 3-4 weeks

> “*That is not the kind of medicine I want to practice*”‒ Sharon Parish

**What’s the instruction you give women for how and when to apply?**

- Apply to a relatively hairless area (buttock and outer thigh or back of the calf) just so it gets absorbed
- You don’t want to wash within a couple of hours
- The time of day doesn’t matter, but it makes sense to do it at the same time every day
- Be mindful that testosterone in the cream can transfer by skin-to-skin contact, so put it somewhere where it won’t transfer
  - Think of children you are holding
  - Or if you have a female partner, it will transfer by skin-to-skin contact
  - This is *not* insignificant
- If you’re going to get a blood test, don’t put it where you will have the blood draw, or wait some hours so you get a little bit of a peak
  - Even though with daily use of a transdermal cream, it’s more of a steady-state
- The other caveat is, if there is a potential for getting pregnant, be on a good contraception
  - Every now and then a menstrual cycle peaks, “*and all of us have heard of an unexpected pregnancy in those women*”
  - By the time you discover you’re pregnant, the testosterone is not going to do much harm to the fetus because it’s usually only been a few weeks
  - But you don’t want people using testosterone and getting pregnant

## A hypothetical treatment plan for the patient in case study #1 [1:26:45]

**Back to this 41-year-old mother of two**:

- The solution is *not* to leave her on a birth control pill and give her testosterone
  - First of all, it’s *not indicated* for premenopausal women
  - Secondly, you’re trying to correct a hormone imbalance
- You would switch her to an [IUD](https://en.wikipedia.org/wiki/Intrauterine_device) if [SHBG](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin) levels were still sufficiently high

***Combined contraception birth control pills are the problem, patches and rings are extremely effective, and most women don’t have a problem***

- Let’s say her testosterone was in the 40th percentile
- Sharon would bring her free testosterone up to the 50th percentile
  - That’s just a guidepost because ultimately it’s symptoms you’re treating
- Sharon will decide if this is the right intervention based on the woman’s biological, psychological, and social factors

- Talk to your doctor about what IUD to start with
- Sharon counseled her college-age daughter, IUD’s prevent unwanted pregnancies
- Some women aren’t sensitive to the increase in [SHBG](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin) caused by birth control pills
  - Some women aren’t sensitive to the non-endogenous estradiol in their vestibule, and you can’t predict this
- Sharon thinks, “*More gynecologists need to offer informed consent so women can choose more carefully at the onset, and this is an important campaign that gets missed. There’s no informed consent. They just hand people a prescription at 21.*”

**Difficulties using testosterone cream in women**

- You have to follow testosterone levels in women to make sure that you’re achieving safe doses (enough to reach physiologic levels, but not too much)
  - Absorption of that 1/10th of a male dose is variable
  - These creams were not designed for women
- The data in Australia is very positive
- Sharon works very closely with [Susan Davis](https://research.monash.edu/en/persons/susan-davis), and she [reports](https://pubmed.ncbi.nlm.nih.gov/33518180/) the ability to get good steady-state blood levels using a controlled product designed for women in Australia
  - This is what we need here
- It’s not clear if **monitoring total T** (testosterone) is the best marker for knowing whether that’s the way to tell whether testosterone is helping a patient in their genital cells, their brain, and some other body cells too, but this is the grossest measure we  have
- Measuring **free T** is a calculated number, and we don’t know if that’s the bioactive component
- Testosterone is a very complex area of endocrinology ‒ it hits cells and gets converted into metabolites and DHT
  - Testosterone enters the cell through the [androgen receptor](https://en.wikipedia.org/wiki/Androgen_receptor) and **has both genomic and non-genomic effects**, ie. it causes changes in gene expression and has other direct actions

***Sharon thinks total T is the best measure of both not being too toxic and also targeting what you want***

**What is the best type of total T?**

- Sharon points out, “*If you send your patient to your hospital lab or Quest or LabCorp, they’re imprecise when you use them for women. They’re not the best measure, but they’re good enough for what we’re doing and what we’re talking about.*”
- Mass spectrometry testing has fancy names used in research and clinical labs, LCMS
- Peter orders LCMS for his patients because supplements you’re taking can dramatically impact the readings
  - He first noticed this in men ‒ normal male estrogen levels might be 25-40, but he was seeing guys with an estrogen level of 200 without symptoms (impossible), and he came to realize that some supplement he was on impacted the assay
  - His LCMS came back normal

## The role of DHEA (a precursor to testosterone) in female sexual health [1:32:15]

- [DHEA](https://en.wikipedia.org/wiki/Dehydroepiandrosterone) is a precursor to testosterone, and it’s not regulated in the US (you can buy it over the counter)
- Testosterone and its metabolites and its precursors are also an area of confusion
- Testosterone gets metabolized to things such as [5-alpha DHT](https://en.wikipedia.org/wiki/Dihydrotestosterone), which is probably the most potent metabolite and aromatase to estradiol
- Question ‒ do you want to look at a precursor or a metabolite, or what’s actually working in the body (in the cell)?
- There have been some trials looking at oral DHEA for treating low sexual desire, and they have not been convincingly positive
  - Further, safety has not been well studied in comparison to the randomized trials of efficacy and safety for a 300 microgram testosterone patch for women
- Testosterone is measured in picograms/mL while oral DHEA is administered in milligrams
- The outcome studies of DHEA have been small, and their design problematic, “*All the criteria for good randomized trials haven’t been met. And there’s no good safety data really looking at this. But the biggest thing is that efficacy has not been demonstrated.*”

***Sharon does not recommend oral DHEA for the indication of HSDD because there’s not good control data on this***

**Intravaginal DHEA**

- In contrast, there is very good [data](https://pubmed.ncbi.nlm.nih.gov/31928093/) supporting the use of a intravaginal DHEA for treating vulvovaginal atrophy resulting in genitourinary symptoms of menopause
  - The [brand is Intrarosa (the chemical is prasterone)](https://en.wikipedia.org/wiki/Prasterone)
  - The indication is [dyspareunia](https://en.wikipedia.org/wiki/Dyspareunia) pain post menopause
  - ***It has very good efficacy and safety data with very little systemic absorption for that indication***

**The rationale for using intravaginal DHEA instead of an estrogen local product**

- There are mixed receptors in the genitals that need both estrogen and androgen
- DHEA gets metabolized into both androgens and then eventually to estrogens at the intracellular level

**For a woman with a common presentation, how do you decide whether you’re going to use an estrogen or a DHEA suppository?**

- The data suggesting differences in efficacy isn’t there
- Even among estrogen products, there are lots of choices: creams, rings, inserts, tablets
  - All local vaginal estrogen products that help with dryness and pain with sexual activity
- For DHEA, the [Intrarosa](https://us.intrarosa.com/) product is an option

***The standard practitioner will start with an estrogen product, and if it doesn’t work, switch to Intrarosa***

- Sharon has some educated patients who request Intrarosa
- Intrarosa doesn’t have a black box warning, and some people like not seeing that warning
- Estrogen has a black box warning around endometrial and breast cancer and vascular thromboembolism (clots)
  - The idea is that they’re applying the risk factor data primarily from the [WHI](https://jamanetwork.com/journals/jama/fullarticle/195120) for *systemic* estrogen therapy
  - There is a class labeling requirement on low-dose products which haven’t demonstrated any of the same negative outcomes
    - Even systemic hormone therapy could be dissected
  - Some practitioners and patients prefer not having this black box warning even though there’s no proof that it’s any more or less likely to cause any cancer
  - The other issue is that in cancer survivors, it doesn’t have the black box
- Sharon might feel that some patients are quite androgen deficient, and Intrarosa might be a better choice to start with
- For example, Sharon has a 40-year old who had an oophorectomy and doesn’t want to go on systemic hormone therapy
  - But her testosterone and androgen levels have plummeted by half

***In every woman, about half of your androgens are made in your adrenal gland and half in your ovary, and the part that goes down in later reproductive years and through the menopausal transition is the ovarian component***

- The androgen component stays about the same; there is some decline in that

***So when you take someone’s ovaries out at a young age, you’re lopping off her androgens, and for these women (who are not using systemic hormones) DHEA/ Introsa might be a better option***

- It’s worse in younger women to have androgen removed abruptly
- Those are the people that are the most likely to have physiological/ organic sexual desire difficulties from low testosterone

## Case study #2: A 30-year-old woman with anorgasmia (inability to orgasm) [1:38:30]

- The second hypothetical patient is 30, she has no kids, she’s been sexually active for 12 years, and she is complaining of anorgasmia
  - She says, “*I have desire and I do get aroused somewhat, but I have never been able to either alone or with a partner achieve what I think I’m told an orgasm is.*”
- In males, an organism tends to be more binary

**How would you counsel this woman?**

- This is not an uncommon scenario
- The first thing Sharon tries to figure out is if it’s primary anorgasmia (never had an orgasm) or secondary (has had an orgasm before and now suddenly it’s gone)
  - This seems to be a case of primary anorgasmia
- Sharon will ask, “*Why are you now coming here to talk to me about this? What is different?*”
- Let’s say she is with an amazing sexual partner and everything is perfect, and she’s just wondering if there is something wrong with her
  - The inability to have an orgasm is interfering with her relationship; it’s creating stress where her partner feels inadequate

**What is an orgasm?**

- It’s a peaking
- A woman becomes interested, they talked about arousal earlier
  - There is mental excitement, her body feels turned on
- There are physical changes, a sensation that feels throughout the body of peaking and maximal pleasure, an overall sense of an escalation to something
- You can talk about what’s happening in the genitals when you get stimulated
  - There’s sensory input ‒ you get a stimulation to the sensation
  - It causes a response that heads to the spinal cord
  - It can trigger the [autonomic nervous system](https://en.wikipedia.org/wiki/Autonomic_nervous_system), first, the [parasympathetic nervous system](https://en.wikipedia.org/wiki/Parasympathetic_nervous_system) to cause vasodilation
    - The pelvic muscles sometimes can relax during sexual activity
    - You get muscle relaxation, vasodilatation, and then it triggers eventually as you become more and more aroused
- Interestingly, the [sympathetic nervous system](https://en.wikipedia.org/wiki/Sympathetic_nervous_system) gets triggered and that’s what triggers an orgasm
  - And in women, it can be a sensation of pleasure in the brain
- FMRI studies have actually looked at this, but generally it’s pelvic floor
- The pelvic floor muscles contract, blood vessels become maximally dilated, and nerve stimulation results in the local release of some neurotransmitters, which cause secretions and lubrication
  - For example, the neurotransmitter [vasoactive intestinal polypeptide (VIP)](https://en.wikipedia.org/wiki/Vasoactive_intestinal_peptide)
  - There’s some involvement with [nitric oxide](https://en.wikipedia.org/wiki/Biological_functions_of_nitric_oxide#Vasodilation_and_smooth_muscles) and CMP, like in men, contributing to both vasodilation secretion and so forth

***In a woman an orgasm involves stimulation of the parasympathetic nervous system, then sympathetic nervous system, then muscle contraction, local hormones, brain chemistry, secretions, and she gets this sense both of wellbeing, pleasure, and pelvic floor contraction. She may get secretions, there’s a lot of variability***

- Some people just feel intense central or mental pleasure
- Others feel a warm, intense sensation in their genitals but don’t notice lubrication
- Some people will ask her, “*How come I don’t squirt?*”
  - That’s a whole other discussion
  - Is that supposed to happen?

**What proportion of women have that sort of ejaculatory response with an orgasm?**

- Some experts believe it’s part of every sexual response, and that it’s just not being perceived
- About 20% of people are aware of it
- There is this whole other theme in the sexual medicine literature about whether women have prostate function in the local genital milieu that results in the squirting of fluid
  - It’s controversial as is the structural location of the female prostate
  - It’s more common for Sharon to hear when people are having a normal orgasmic or arousal response that the lubrication from the mucosal surface becomes robust
    - This is probably due to the interaction between vasodilation, the nervous system, and local hormones such as [VIP](https://en.wikipedia.org/wiki/Vasoactive_intestinal_peptide) and [nitric oxide](https://en.wikipedia.org/wiki/Biological_functions_of_nitric_oxide#Vasodilation_and_smooth_muscles)
  - Sharon doesn’t think the squirting of fluid is the biggest piece of the orgasm
- Peter wonders, “*Is that a super orgasm? Some women have that every single time?*”
- People aren’t bothered by the lack of the squirting of fluid, rather it’s that they aren’t getting that overall sensation and peaking sensation in both their brain and genitals
  - It’s that sensory experience and the intensity and the muscle contraction that they’re probably not experiencing

**Tangent on secondary anorgasmia**

- This is when a woman has the capacity of orgasm and loses it
- Two things could have happened
- 1 – Significant psychological impact such as trauma or relationship struggle
- 2 – A physiologic factor such as a medication or a neurologic condition
- One of Sharon’s colleagues is really into the nerve damage from spinning classes
  - That doesn’t mean to go out and get rid of your Peloton
- In men, nerve damage can blunt sensation and may interfere with orgasm

**Back to the 30-year-old woman who has not had an orgasm**

- First, Sharon wants to find out why and make sure nobody is pressuring her
  - Some people are like, “*I don’t really care, but my partner wants me to have an orgasm so I just fake it, and he’s bugging me and I’m coming here to see if I can have a real one*.”
    - Sharon explores this further
    - She never accepts the answer at face value
    - She wants to know if she has given up or doesn’t really worry about it
- Some people in the field feel that not having an orgasm can be normal for some women; Sharon avoids this
  - It’s important to find out about it
- Sharon encourages her patients to learn techniques or strategies for seeing if they can reach this experience (orgasm)

**There are multiple kinds of orgasms**

- The big buckets are clitoral, vaginal, or both
- Roughly 30% of women reach orgasm through clitoral stimulation, 30% through vaginal,a nd 30% have flexibility
- The techniques for reaching orgasm vary widely across women
  - Some women can have orgasms just thinking about it
  - For other’s it’s nipple stimulation
    - Some women report it with even breastfeeding or the shower water hitting their nipples
  - Some women need direct clitoral stimulation, manual, oral
  - Some women like vibrators
  - Other women through the thrusting of intercourse.
- There is the question of where the G-spot fits in
  - This spot that’s a spongy spot just inside the roof of the vaginal canal
  - That’s an area of sensitivity

***The bottom line is there’s lots of nerve bundles in lots of places and a lot of them can be stimulating enough to trigger this whole mechanism***

- The big thing is for a woman to figure out whether you’ve learned where you can be most stimulated to have a more intensified response
  - This is where Sharon begins her conversation with patients
  - Whether it’s clitoral, vaginal, through intercourse (or  not)
  - It’s more about what the stimulation patterns are, and how much they’ve explored learning about that

**Do we have a sense of the correlation between the number of women who would present as this patient as a woman who is young in her reproductive years who is anorgasmic who also does not masturbate?**

- Peter asks if part of the problem is that she is unaware of what her sensations/ mechanisms are and therefore cannot reach that threshold on her own
  - Or isn’t able to communicate that with her partner
  - Or is there no association between that?
- The data is a little hard to tease out
- Primary anorgasmia versus secondary does somewhat correlate with age
  - Younger women are more likely to have primary anorgasmia, whereas other sexual functions get more marked with age, desire and arousal problems due to some of the factors we’ve been talking about
  - Primary anorgasmia tends to get better with age when women can learn more about their orgasmic response
- In large population-based studies, anorgasmia is the least common reported sexual dysfunction (either primary or secondary)
  - But maybe we just don’t know how to ask about it
- For example, there was this large population-based study called the [PRESIDE study](https://pubmed.ncbi.nlm.nih.gov/18978095/)
  - 50,000 women were surveyed and 31,000 women reported
  - It was a self-report of distressing sexual problems
  - Overall, sexual dysfunction desire was somewhere around 10 to 15%, and orgasmic problems were like three to 6% of the women reporting those problems (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2023/06/f4-sharonparish.png)

**Figure 4. Prevalence of sexual dysfunction in women (filled circle, desire; open triangle, arousal; filled square, orgasm; open diamond, any)**. Image credit: [*Obstetrics and Gynecology* 2008](https://pubmed.ncbi.nlm.nih.gov/18978095/)

- Midlife women were the most likely to report any type of sexual dysfunction
- Primary anorgasmia is most likely reported in younger women
- Once a woman learns about her orgasmic response, she doesn’t usually lose it unless an organic of psychological factor intervenes (as discussed earlier)

**Back to the 30-year-old woman. How are you going to do the workup?**

- It’s a pretty quick workup, mostly it’s the story
  - Tell me about your sexual function, your history
  - Does she have sex with herself? Has she tried masturbating
  - Does she have a partner? What does she do with her partner?
  - What does she know about being able to stimulate herself?
  - Does she know the structure?
    - Does she know where her labia are? Her clitoris?
    - Has she tried nipple stimulation?
  - What have they tried as a couple?
    - Has she tried using a vibrator?
    - She gets into her knowledge about techniques for stimulation and what she has used and what her partner has tried
    - What is she able to communicate with her partner

***The real question is does she know what stimulates her, and can she teach/ train/ ask her partner to do that for her?***

- There are two problems
  - 1 – The woman doesn’t know what stimulates her
    - The prescription might be learning more about that
  - 2 – Communication between partners, she isn’t sure how to teach her partner to do what she knows works
- Sharon makes sure the woman is not on birth control pills and is not having pain

## Resources for helping women and their partners to enhance the pleasure experienced during sex, overcome anxiety, and increase desire [1:51:30]

- Many women need more stimulation with age even in the absence of underlying pathology (diabetes, vascular disease) because the sensitivity goes down
- Sharon normalizes the use of **vibratory stimulation** because it helps a lot
- Sharon asks patient #2 if she has tried techniques for improving or enhancing stimulation
  - Vibratory stimulation also helps for younger women, but usually younger women don’t need as much stimulation

**The biggest factor is that women don’t know their structures**

- The actual [clitoris](https://en.wikipedia.org/wiki/Clitoris) isn’t the most sensitive, it’s the sides/ flanks of it
- Sensitive areas are the sides of the [clitoral hood](https://en.wikipedia.org/wiki/Clitoral_hood), around the [vestibule](https://en.wikipedia.org/wiki/Bulb_of_vestibule), just inside where some people call the [G-spot](https://en.wikipedia.org/wiki/G-spot)
  - These are where the neurovascular bundles are concentrated
- The top of the clitoral hood is very easily irritated and doesn’t like being rubbed very much
  - Some partners do too much rubbing

**Sharon sends people to books**

- [*Becoming Orgasmic*](https://www.amazon.com/Becoming-Orgasmic-Sexual-Personal-Program/dp/0671761773/ref=sr_1_1?crid=14FGP7125Q97X&keywords=becoming+orgasmic&qid=1681149907&sprefix=becoming+orgasmic%2Caps%2C107&sr=8-1) (first published in 1976)

- [*The Joy of Sex*](https://www.amazon.com/Joy-Sex-Ultimate-Revised/dp/0307587789/ref=sr_1_1?crid=4E0IHJVPQUIT&keywords=the+joy+of+sex&qid=1681149753&sprefix=the+joy+of+sex%2Caps%2C98&sr=8-1) has been republished and published, and it’s still a great book (first published in 1972)
- [*For Yourself*](https://www.amazon.com/Yourself-Fulfillment-Female-Sexuality/dp/0451202007/ref=sr_1_1?crid=28XI2R105HZNQ&keywords=for+yourself&qid=1681150713&sprefix=for+yourself%2Caps%2C104&sr=8-1)
- [Sandra Leiblum](https://en.wikipedia.org/wiki/Sandra_Leiblum) has a couple of different [books](https://www.amazon.com/s?i=stripbooks&rh=p_27%3ASandra+Leiblum&s=relevancerank&text=Sandra+Leiblum&ref=dp_byline_sr_book_1); she’s a sex therapist who is no longer with us
  - Most of her work is on desire
- [Lori Brotto](https://www.loribrotto.com/) talks about mindfulness and learning how to stimulate yourself
- There is also a website [omgyes](https://start.omgyes.com/join) (as in “oh my God, yes”)
  - It’s a very responsibly produced website that has a lot of education for women
  - It costs a small amount of money for a subscription
  - It has a lot of educational videos for clitoral stimulation techniques and other kinds of stimulation
  - This is a site designed for female stimulation but it could be for the partner just as much as the individual

> “*Sometimes it’s easier for someone to sit and watch a video with their partner than to have to show them themselves*”‒ Sharon Parish

- Sharon has no commercial investment in any of this
- Sharon is not a sex therapist, she counsels, but she also sends patients to a sex therapist

**Psychological therapy and sex therapists**

- There is some data for using mindfulness-based therapy and cognitive therapy for an array of sexual disorders
- For anorgasmia the sex therapists use much more explicit techniques
  - Sharon is a medical physician who does kind of a multifaceted analysis and intervention
  - If she thinks a patient needs more work, she might suggest that patient go to a sex therapist
- Sex therapists these days are not like it was with [Masters and Johnson](https://en.wikipedia.org/wiki/Masters_and_Johnson#Television) (in the TV series [*Masters of Sex*](https://en.wikipedia.org/wiki/Masters_of_Sex)) ‒ they don’t go behind a room with a glass window and have sex in front of the sex therapist
- Instead, they will discuss technique in more detail, and they’ll give homework assignments
  - There may be advice or guidance about positioning
  - They might bring the partner in and discuss positioning
  - They might use something called [sensate focus](https://en.wikipedia.org/wiki/Sensate_focus)

**Techniques to overcome anxiety**

- Often people develop a lot of anxiety and that makes the problem worse
- They may develop what’s called **spectator and performance anxiety**
- 1 – One technique to overcome this is to gradually introduce levels of sexual and partner communication (this works for any sexual dysfunction)
  - This is helpful for people who become very anxious about the thought, “*Am I going to have an orgasm*”
  - This is a sensate focus prescription done by sex therapists, and it starts with very non-threatening things like: you sit, you hold hands, you hug
- 2 – Mindfulness and cognitive therapy can be introduced by people who specialize in this
  - To overcome distraction and low desire
- 3 – Work with a psychological person to understand sexual aversion disorder
  - Sometimes Sharon discovers a deep-seated psychological issue linked to low desire
  - Sexual aversion disorder was previously in the DSM but was removed for a variety of reasons
  - This could be due to a past sexual trauma that has left the person with a genital aversion
  - Every time they enter a sexual encounter, they’ll have an intrusive thought
  - There may be some PTSD
  - Maybe there is a strong religious or cultural prohibition
  - Working with a psychologist can improve their sexual quality of life and happiness
  - This pertains more to primary anorgasmia
- Sharon also looks at the relationship, the timing, the lifestyle factor
  - Back to the first case study, she is 41 and may say, “*I have two kids. There’s homework, there’s dinner. I work all day. There’s the house, there’s the laundry. Then I have to answer my email at 12 o’clock, and then it’s one in the morning… I’m too tired.*”
  - Maybe their partner is not helping them
- When someone comes to Sharon with low desire, she looks at these lifestyle factors, then she looks at medication factors, she looks to see if another sexual dysfunction is contributing to low desire
  - She looks at relationship counseling factors
  - She may refer the patient for psychotherapy or sex therapy
- If she doesn’t see another modifiable factor, and the woman is postmenopausal, she may consider adding androgens
- If she reaches the point of wanting to use something explicitly for sexual desire in postmenopausal women, testosterone is an option
  - Candidates for this are people who’ve had oophorectomy at a young age, early menopause, or postmenopausal women with distressingly low desire

***Sharon first does a biopsy psychosocial assessment before using a pharmaceutical***

## Two drugs for premenopausal women with low desire [1:59:30]

**Let’s go back and look at two drugs we didn’t talk about**

- Besides testosterone
- For **premenopausal women** for whom Sharon reaches the conclusion that they have distressingly low desire, and there are no modifiable factors (discussed earlier), there are two FDA-approved products
  - They have been around but very few people know about it or come to her for a prescription
  - People are shocked to hear they are available

**1 –** [**Flibanserin (brand name Addyi)**](https://en.wikipedia.org/wiki/Flibanserin) **is a centrally-acting drug, it acts on serotonergic and dopaminergic receptors (FDA approved since 2019)**

- Their [website](https://addyi.com/) has good information for patients; no generic is available
- It has a [complicated mechanism](https://www.rxlist.com/addyi-drug.htm) that is not fully understood; it acts on serotonergic and dopaminergic receptors
  - It’s a mixed [serotonergic agonist](https://en.wikipedia.org/wiki/Serotonin_receptor_agonist) and [antagonist](https://en.wikipedia.org/wiki/Serotonin_receptor_antagonist) (5-HT2A and 5-HT1A)
  - It has mixed agonist/antagonist activity at [dopamine receptor D4](https://en.wikipedia.org/wiki/Dopamine_receptor_D4)
  - It has moderate affinity for other serotonergic receptors, [2B](https://en.wikipedia.org/wiki/5-HT2B_receptor) and [2C](https://en.wikipedia.org/wiki/5-HT2C_receptor)
- It was studied for depression but discovered to be helpful for low desire
  - Kind of like [Viagra](https://en.wikipedia.org/wiki/Sildenafil) was studied for blood pressure and found to be helpful for erectile dysfunction
  - That’s not to say that women who respond to this are getting it because they’re depressed, but one wonders
  - There may be a spectrum of why people have no libido as a presenting complaint and why a centrally-acting drug could be helpful
- You’re supposed to rule out other stuff and manage the biopsychosocial factors before you consider this drug, but it is FDA-approved
- The effect seems to be pro-sexual
- Addyi is taken daily at bedtime, on demand, as a single 100 mg dose
- Sharon was more involved with its FDA approval than testosterone
  - She spent a lot of time at the FDA advocating for its approval
- For some time it had a [REMS](https://en.wikipedia.org/wiki/Risk_Evaluation_and_Mitigation_Strategies), meaning there was a risk mitigation strategy where doctors had to take a test before they could prescribe it
  - Initially they did a lot of research looking at hypotension and syncope and its interaction with alcohol
  - At the pharmacy, patients had to sign a form that they wouldn’t drink alcohol, and the pharmacist had to sing that they counseled patients
- Since then, it has been reevaluated and found to be no different than any drug in class
  - For example, [SSRIs](https://en.wikipedia.org/wiki/Selective_serotonin_reuptake_inhibitor) give [hypotension](https://en.wikipedia.org/wiki/Hypotension) if you take them and drink alcohol (this makes you feel woozy or sedated)
  - But there’s still a black box because the FDA wouldn’t go all the say, but it’s similar in class to SSRIs
    - The side effects are similar
- You take it at night and go to sleep, it can cause a little sedation
  - It’s sort of like [mirtazapine](https://en.wikipedia.org/wiki/Mirtazapine)
  - Most people say they sleep better and are not drowsy

***You probably see maximum effect after taking it for about four weeks***

- They recommend taking it for 8-12 weeks, and if it works, continue it
- Generally, it’s about as effective as an SSRI is for depression
- Studies looked at both desire ratings (on a validated scale called the FSFI) and satisfying sexual events, and it was found to be moderately effective
  - In responders, it was quite effective
- You take it for 6-12 months and then stop and reevaluate
  - There can be some neuroplasticity and brain rewiring; we don’t have that research
  - It’s unclear how long to treat and whether we can stop
- The **side effects** are similar to SSRIs
  - About 10-12% of people get dizzy or tired, but that’s fine if you take it at night
  - A handful get dry mouth
  - It’s as safe as any central-acting drug that people prescribe routinely
- There are some **contraindications ‒** it can interact with [CYP3A4 inhibitors](https://en.wikipedia.org/wiki/CYP3A4#Ligands) and can worsen the side effects of SSRIs
  - It’s not contraindicated to prescribe it with a SSRI, and it is sometimes used as a remedy for SSRI induced side effect of emergent sexual dysfunction
  - But you may have augmented side effects, and this is something to watch out for
- This is *not* Sharon’s first treatment strategy

**2 –** [**Bremelanotide (brand name Vyleesi)**](https://en.wikipedia.org/wiki/Bremelanotide) **is completely different**

- Their [website](https://www.vyleesi.com/?gclid=CjwKCAjwitShBhA6EiwAq3RqA_fbLyGtvtPXPu9UGZKpaaPj4eAzJYZn4dordrByuFxC2FhIlfdSxRoCFPoQAvD_BwE) has good information for patients; no generic is available
- It’s a cyclic seven amino acid [melanocortin receptor agonist](https://www.rxlist.com/vyleesi-drug.htm#clinpharm) with a high affinity for the [melanocortin receptor, MCR4](https://en.wikipedia.org/wiki/Melanocortin_4_receptor#)
- It’s an analog of [MSH (melanocyte stimulating hormone)](https://en.wikipedia.org/wiki/Melanocyte-stimulating_hormone)
- It acts in brain pathways that stimulate dopaminergic pathways
  - So it’s a direct hit for desire
  - The other one (Addyi) is a little more complicated like in cooking, you’re like sprinkling a little of this receptor and that receptor
  - This one hits the dopaminergic pathways
- It’s given on demand as a self-injected treatment
  - It looks a little like an [EpiPen](https://en.wikipedia.org/wiki/Epinephrine_autoinjector)
  - It has a fine needle, and when you stab your thigh it releases it
  - It’s very painless; patients report they feel it less than a finger stick or a [PPD (TB skin test)](https://en.wikipedia.org/wiki/Mantoux_test)
- You inject 1.57 mg (0.3 mL of a solution) subcutaneously with this autoinjector into your abdomen or your thigh (a thick muscle)
- It takes about five seconds to go in,so you count 1, 2, 3, 4, and then you pull it out
  - You can also see that the liquid’s gone down
- You don’t feel anything at first

*Do you only take this drug when you want to have sex?*

- Yes, it’s taken on demand
- You should take it about 45 minutes before
- Presumably, it lasts in your body for about 24 hours
- Women say that a little while after taking this, the idea of sex seems more interesting
  - This is where this bridge between desire and arousal comes into play
- Then when they engage in the activity, arousability is more intensified
- It’s supposed to provide intra-event improvement and an overall sense of satisfaction, and this fits into the idea that it fuels the future
  - Patients know that they might be neutral or even not interested, but if they do this, they’re going to feel more turned-on and the experience is going to be more pleasurable because they’re going to feel both more mentally desirous and more arousal

**How much do these drugs cost?**

- Flibanserin (brand name Addyi) is available everywhere
- Bremelanotide (brand name Vyleesi) has a specialty pharmacy that you can see on their [website](https://www.vyleesi.com/?gclid=CjwKCAjwitShBhA6EiwAq3RqA_fbLyGtvtPXPu9UGZKpaaPj4eAzJYZn4dordrByuFxC2FhIlfdSxRoCFPoQAvD_BwE)
- If your insurance doesn’t cover it, both of them have guaranteed maxes between $40-$90 per month
  - Many insurance companies don’t cover this, but they guarantee a maximum
- For flibanserin (Addyi), you get a 30-day supply
- For Vyleesi, you get a four-week supply from the specialty pharmacy

**Do they need to be refrigerated?**

- No
- You keep it in a cool, dry place

**Efficacy and side effects**

- There have not been any head-to head studies between the two drugs, but the outcomes are pretty good
- Studies looked at both improvements in this desire rating scale (the FSFI) as well as clinical events like satisfying sexual events
  - Clinical meaningfulness has been good, with moderate to solid outcomes
- The main thing with this is that with the first couple of doses of flibanserin (brand name Addyi) people get **nauseous** (about 45% of people)
  - The nausea lasts about two hours, and that tolerates out
  - By the second dose, the data suggests it’s down by about somewhere on 24 to 40% (it goes down to about 8%)
  - And then most people don’t mention that they feel nauseous

**Do you advise that women maybe use it a couple of times without trying to have sex so that they get over the nausea?**

- You can go to sleep or just lay down
- Some people prescribe a dose of anti-nausea pill with it for the first dose or for a couple of doses
- Sharon doesn’t find the nausea to be clinically problematic, but if people have it, it’s over in a couple hours and it doesn’t happen the second time

**How do you decide which of these two drugs might be more appropriate?**

- Putting aside cost, insurance, or hesitancy with an injectable versus a pill
- They are probably equally effective
- Sharon considers patient preference
  - Do they want it on demand?

**Side effects for Bremelanotide (brand name Vyleesi)**

- For Vyleesi there is a rare occurrence of focal hyperpigmentation when used more than 8 times a month (1% affected in the clinical trial)
  - To limit this risk, she tells patients to limit use to 4x a month
  - Hypopigmentation occurs on the face, gingiva, breast, in melano-receptor-sensitive tissues
  - It’s not clear if it goes away when you stop using the drug
  - It’s not thought to occur if you don’t’ use it beyond the recommended guidance (<8 times a month)
- There are two contraindications: uncontrolled hypertension and known cardiovascular disease
  - There was a small increase in blood pressure (8-10 mmHg of systolic and diastolic)
    - This contraindication is probably overkill
    - It was originally studied as an intranasal squirt and it raised blood pressure so they switched to an injectable
- There were some trials in men, and colleagues think about how this might be used off-label for an array of male sexual dysfunctions
- There is at least one good RCT in postmenopausal women for Addyi (chemical flibanserin)
  - [SNOWDROP trial](https://pubmed.ncbi.nlm.nih.gov/24281236/)
  - [PLUMERIA study](https://pubmed.ncbi.nlm.nih.gov/28583342/)

**Why is this not approved for postmenopausal women?**

- This has to do with the FDA again
- The FDA required that the companies go for indication of a category because this goes to the reproductive group of the FDA, and they’re required that they put in an application for either pre- or post-menopause
  - They started with pre, so they didn’t have to deal with all the hormonal complications of hormonal status/ hormonal replacement, and never went back for post

**Is it typically prescribed off-label for postmenopausal women?**

- There is good RCT data for postmenopausal woman that is strong and suggests there’s no difference in either outcomes or risk and safety for flibanserin, there are no RCTs for bremelanotide (brand name Vyleesi)

> “*You’re in no man’s land if you’re prescribing this off-label for postmenopausal women, but there’s no physiologic plausibility for the risk*”‒ Sharon Parish

**Could you give Addyi and testosterone to postmenopausal women without contraindication?**

- This would be off-label for both
- Sharon doesn’t usually start with two
  - She’s a purist and starts with one thing, then she will either layer or switch
  - That’s a clinical art
- She has multiple younger postmenopausal women on Addyi and they understand it’s off-label; she has clear informed consent
- She has not used Vyleesi in postmenopausal women
  - Some of her colleagues have
  - Sharon is nervous because there’s no data, but there’s no biological plausibility that it should be harmful

**Are these schedule IV? Are they controlled or uncontrolled?**

- They are not controlled, but testosterone is
- For testosterone you have to have a DA number, and you can only give out a month at a time
  - This is easy for women because you give them a box of 30 and for them this is 10 months
- The only reason these are FDA-approved for premenopausal women and not postmenopausal women is because the approval process required companies to choose one indication
  - They pursued approval for premenopausal women and never went back for further approval of postmenopausal women

**Considerations for choosing one of these drugs**

- There is patient preference
- Are there any contraindications?
  - There is the CYP3A4 inhibitor issue for flibanserin
    - If their on HIV drugs, CYP34A inhibitors, or if they’re taking a lot of antibiotics or [diflucan](https://en.wikipedia.org/wiki/Fluconazole)
    - There is guidance about how long to wait between all the CYP3A4s
  - If someone is on other psychotropic drugs and is worried about oversedation, she might not choose flibanserin
  - Liver disease is another contraindication for flibanserin because of its metabolism
  - Vyleesi would be a good choice in these cases
  - Vyleesi would also be good if someone has high blood pressure or any aversion to getting nauseous (from the first dose)
- Some people are terrified of injecting themself

## Why treatments are potentially underutilized for both desire and genitourinary syndrome of menopause [2:13:15]

**Sharon is the only person at Weill Cornell that routinely offers these drugs to people**

- Surprisingly, she doesn’t get a lot of requests
- She is a referral source
- She works both in medicine and psychiatry, and when she talks about it in meetings, people are not writing a lot of prescriptions for these drugs and she doesn’t know why
- Peter comments, “*what you’re saying seems to suggest that these are potentially underutilized*”
  - Possibly, it depends on the setting
  - Sharon has colleagues who have sexual medicine practices that are purely private and community-based who write lots of prescriptions for this every month
  - It might be how and what people are seeking in certain settings
  - She doesn’t know if they’re underutilized but they are certainly under-recognized

> “*I think that there are probably a lot of women out there who don’t know what tools are available to them or their doctors with respect to the entire spectrum of sexual dysfunction*”‒ Peter Attia

**There is a lot of misunderstanding and confusion about what is normal**

- This goes back to the earlier discussion of blending the ideas of desire and arousal
- If a woman doesn’t ever want to have sex, but can get an orgasm, a doctor may think, “*Why should she take a drug for desire?*”
  - A woman then might not feel legitimized in saying, “*I want to want*”
- Or maybe a woman stopped taking birth control pills and six months later, they still have no desire
  - Why not try Addyi
  - They need to be validated ‒ it’s okay to want to want (that’s part of the issue)

**Treatment of vulvovaginal atrophy causing genitourinary syndrome of menopause (GSM)**

- There are lots of treatment options that are safe:
  - 1 – Lubricants for comfort
  - 2 – Moisturizers for moisture
  - 3 – Topical hormones for resurfacing (they’re not systemically absorbed)
- People are erroneously worried about in terms of the black box and other things

***It’s easy to treat, but there is low recognition and lack of uptake***

- At least it’s normalized that a woman should not have to be in pain

> “*I can’t tell you how many women soldier on either avoiding sex or in pain because they don’t either know or feel validated to seek treatment for GSM*.”‒ Sharon Parish

- Normalization of desire is lower, where people feel legitimized and validated that they should go to their doctor and get treatment for low desire and take a medicine every day
  - That’s seen as indulgent

**Do you think that that’s generational, Sharon, or do you see just as much of that in younger women as you do older women?**

- This drug is available for premenopausal women
- People can come and get a prescription but they’re not banging down the door
- There is a whole other phenomenon going on in younger people, it feels like the connection to sexuality and quality of life is delayed
- Peter hears [Bill Maher](https://en.wikipedia.org/wiki/Bill_Maher) talk a lot about this and make the same comment
- The most common age group in Sharon’s practice is midlife women, but she also does work in menopause too
- Sharon has been in practice for 30 years, and her most common patient would come in for menopausal symptoms ‒ hot flash, night sweats, sexual function changes, relationship issues, mood
- It seems like people having boyfriends and girlfriends and partners in their 20s who are wondering about the quality of their relationship and thinking about the sexual relationship has gone down
- People are seeking help at older ages
- The concerns of people in their 20s has more to do with STD prevention
- The other thing in this age group is pain such as [vulvodynia](https://en.wikipedia.org/wiki/Vulvodynia) and [vestibulodynia](https://en.wikipedia.org/wiki/Vulvar_vestibulitis) (not really sexual dysfunction), and how to deal with [herpes](https://en.wikipedia.org/wiki/Genital_herpes)
- The college-age, young 20-year-olds she knows aren’t having partners; they’re just floating around and not engaging in meaningful discovery about sexuality in a way that sets them up  for future relationships
  - Peter has heard these observations in multiple channels, and it begs the question, “*Why?*”
    - Is there anything pathological about that?
    - Does that produce a state later in life that diminishes happiness, etc?

## Case study #3: A menopausal woman with symptoms [2:19:00]

**Characteristics of hypothetical patient #3**

- A woman who is two years since her last period
  - There’s no ambiguity about the fact that she’s in menopause
- Her estradiol level is 10, FSH is 75
- She is having some vasomotor symptoms ‒ she still gets hot flashes and night sweats
  - She hates waking up with her sheets soaked at night
- She’s starting to experience vaginal dryness and discomfort, and as a result she has some hesitancy about sex
- Her mom had breast cancer and so she thinks hormones are the worst thing in the world
- She has osteopenia
- The first thing Sharon tries to do is break it down, what will attribute to the menopausal transitional symptoms?

Symptoms of menopause transition

- Hot flashes and night sweats can lead to fatigue and difficulty sleeping
- Independent insomnia
- Cognitive fogginess
- A little bit of mood instability
  - She is careful to say that a significant mood disorder shouldn’t be attributed to menopause
  - This is a vulnerable time and mental health issues may have to do with hormonal changes as neurotransmitters are sensitive to fluctuations in hormones
- As a woman proceeds through the menopausal transition and becomes postmenopausal, this stuff lasts for 3-5, 5-7, or 1-2 years
  - Typically it’s worse right before and right after the years that your menses ceases
- Bone density is a potential disease progression that is hormonally related
  - This reflects the effects of systemic levels of hormones
- The effect of decreased hormone levels on vaginal tissue can possibly cause discomfort with sexual activity
  - This can produce changes in sexual enthusiasm or interest
  - Decline in androgens parallels this timeframe

***Sharon first figures out which things to start with, and what can be addressed with a single intervention***

**Who is more likely to have symptoms?**

- People who are a heavier body weight, exercise less, already have sleep difficulties and other problems are more likely to have symptoms than people with lower body weight who are exercising
- People that have relationship stress may be more likely to be sensitive to the changes in their partner being upset that there’s decreased frequency in sex
  - Because they’re more tired
  - Or maybe they can’t communicate with their partner and can’t teach them to use a lubricant because they’re afraid to ask
- Sharon asks patients, “*Tell me about your relationship. Tell me what’s going on. Are you working? Do you have kids? Do you have older parents?*”
- She also wants to know about their health status is in terms of metabolic disease and other factors

- There is lifestyle stuff, counseling and relationship stuff

**For loss of hormones**

***The single best treatment for disruptive vasomotor and collection of [menopausal] symptoms is combined estrogen, progesterone therapy (no progesterone if someone doesn’t have a uterus)***

- For example, you can decrease hot flashes by 75-80%, even more (at least 50%)
- This is for the woman who is having a hot flash every hour or two, who is waking up and can’t sleep, and nothing is helping
  - They need to go on hormones

## Addressing the misguided fears around hormone replacement therapy and cancer [2:24:15]

**Hormone therapy and cancer fear**

- Using hormones for a period of time, at the lowest dose that treats the symptoms the most effectively, is not going to give you breast cancer, most likely
- Sharon can’t promise that you won’t get breast cancer, because one in eight or nine women get it anyway, and you might be genetically likely
  - But not from a short-term use of the lowest dose possible to suppress your symptoms
- Peter adds, “*That’s the important distinction there, right? Of course you have no idea if a woman’s going to get breast cancer given that it’s so prevalent.*”
- A future podcast will go into the conditions of the [Women’s Health Initiative (WHI)](https://jamanetwork.com/journals/jama/fullarticle/195120)
  - Even there, the absolute increase in risk of cancer with hormone replacement therapy was 0.1%
  - And that was only in the incidence of breast cancer in the women receiving conjugated equine estrogen and MPA, both products that we are not using today
  - Secondly, there was no increase in breast cancer mortality (we still follow those women today)

**Sharon provides a short version summary of the WHI**

- It used oral synthetic estrogens and oral progesterones, but nobody uses these anymore
- Usually people use oral estradiol and oral progesterone that are bioidentical, the doses are different and lower
  - There are also transdermal products available now
- The problem is that there’s never been as large a RCT for the length of time
- Shorter term data showing that there’s other ways to have even better outcomes and maybe even no outcomes
- There’s also been extensive reanalysis of both the actual data and subgroups
- Women age 50 to 59 are very different than people who started hormones
- The WHI wasn’t for symptoms, it was for disease prevention (osteoporosis and cardiovascular disease); women in the study were asymptomatic
  - The women were older when they started hormone therapy, and it doesn’t apply to this patient at all
- Peter adds, “*The data are unambiguously clear that if there’s any negative effect of the combined hormone therapy in the WHI, it had to be due to the MPA, because the conjugated equine estrogen group alone got better.*”
  - They almost achieved statistical significance by a *p-*value of 0.2 for reduction in incidence of breast cancer, and this effect has persisted for over 20 years (every sub-analysis looked at this)
- The reanalysis of subgroup by age, and then teasing out the effects of each of the components, have debunked the things that people think are scary or risky about hormone therapy
- The WHI never analyzed by symptom indication

**Sharon’s advice to the patient**

- There is a slew of lifestyle things (mentioned earlier)
- There is some over-the-counter stuff like [black cohosh](https://en.wikipedia.org/wiki/Actaea_racemosa#Herbalism) and [soy](https://en.wikipedia.org/wiki/Soybean#Lignans)
- But none of that works as well as systemic estrogen and potentially with progestin therapy too
- The reason for adding the [progestin](https://en.wikipedia.org/wiki/Progestogen_(medication)) is it protects the uterus against endometrial hyperplasia
- The risk of venous thromboembolism risk is probably a little higher, but better with transdermal products
- Sharon almost never puts people on oral products; she uses patches or gels that contain both estrogen and progestin
  - [Estrogel](https://www.estrogel.com/);
  - There’s also a ring called [Femring](https://www.femring.com/)

**In women who struggle with systemic progesterone, do you sometimes use systemic estrogen with a progesterone coded IUD to provide the progesterone?**

- This is not a labeled indication, but you can use a progesterone IUD for endometrial protection
- There have been some prevalence studies or risk studies looking at this, and they’re looking at the outcomes of the number of people who have adverse outcomes when they use the IUD
  - They don’t point to a signal
  - There has not been a randomized clinical trial
- There are many clinicians who feel like there’s good data to justify using an IUD for endometrial protection
  - Usually it’s the higher dose IUD ([Mirena](https://www.mirena-us.com/)), and it’s good for 5-7 years
    - Though some feel you could leave it in for longer and still get protection because the levels remain present for some time
- This is a strategy used by many
- You could put it in before the patient doesn’t tolerate progestin
- The theory is it is also an alternative, but it might provide overall less progestin exposure

***Remember, hormone treatment is for all these symptoms, so you could try it for a year or two; it’s also a very good treatment for osteoporosis (longer treatment)***

- However, it’s not considered a treatment for osteoporosis but a preventative measure
- Peter believes, “*Prevention is everything when it comes to bone loss*”
  - You don’t want to wait until someone has osteoporosis to whip out the [bisphosphonates](https://en.wikipedia.org/wiki/Bisphosphonate)
    - Which frankly don’t necessarily have an enormous impact on fracture risk because while they’re increasing bone mineral density, it doesn’t necessarily come with some of the torsional qualities of bone that we might want to see in a healthy bone that hasn’t gone through that period of degradation
  - “*If you do the math, far more women will die as a result of fractures of femur, hip, pelvic bones later in life that could be ameliorated by the use of judicious hormone replacement therapy to prevent them from getting there than will ever die from breast cancer as a result of hormones.*”
    - It’s not even close, it’s orders of magnitude difference, and this is what he finds most frustrating the the HRT (hormone replacement therapy) discussion
  - “*It’s a real tragedy to me that there is an entire generation of women for the past 20 years that have been largely deprived this therapy on the basis of very bad science and far worse reporting and interpretation of said science*”

***Sharon’s take is that hormone replacement therapy is probably going to help with menopausal symptoms***

- Let’s say this woman has tried the over-the-counter stuff (black cohosh) and she’s ate some soy, but she’s coming in for help
  - You have to eat a lot of soy everyday to make it work
- Sharon would advise her to try hormone replacement therapy, “*This is going to help you. Let’s use the safest, lowest dose. You’re certainly not going to get cancer from this. You might get it.*”

> “*The other thing is that people don’t know that other things they do are riskier for breast cancer than their hormone [therapy]… Drinking alcohol, more than one drink a day.*”‒ Sharon Parish

***Drinking alcohol, having insulin resistance, not exercising, being overweight, having metabolic dyslipidemias/ high blood sugar/ metabolic syndrome are probably more important for breast cancer risk than small doses of transdermal hormones for a couple of years***

## Symptoms and treatment of genitourinary syndrome of menopause [2:32:45]

**Continuing hormone replacement therapy beyond a few years, through age 60, the first 10 years**

- That is a different conversation
- But you’re already getting at the point that there’s a lot of data and a lot of reasons to keep going
- Sharon has heard from a few different experts, including [JoAnn Manson](https://prevmed.bwh.harvard.edu/joann-e-manson-md-dph/) (who was an original PI on the WHI) that it’s very clear that hormone therapy is the best treatment for menopausal symptoms
  - Joann seems to be the one who has reversed most of the initial sort of fear around the WHI
- The [North American Menopause Society,](https://www.menopause.org/) and some of the other formal experts, say to use hormone replacement therapy for the shortest dose for the period of time that you need to manage symptoms
  - Sharon adds, “*At a minimum, we need to turn around anybody who doesn’t understand that.*”

**Other treatments for menopausal symptoms**

- You can use SSRIs for hot flashes, but we already explained they have some issues and they don’t work as well
- You can use [clonidine](https://en.wikipedia.org/wiki/Clonidine), which has low rates of success and a lot of side effects, or [gabapentin](https://en.wikipedia.org/wiki/Gabapentin), same thing
- These are not Sharon’s first choices for treatment

**Treatment for dryness and discomfort**

- There is the question if transdermal hormones get to the vulva and vaginal tissue
  - Some patients say their lubrication is fine, they’re not dry
  - Other patients need more local delivery
    - It’s not contraindicated to give both, in fact, it’s indicated

**Main symptoms of GSM (genitourinary syndrome of menopause)**

- Vulva adrenopathy
- General urine syndrome or syndromes of menopause
- Vaginal dryness
- Pain with sexual activity
- A collection of genital urinary symptoms, even independent of sex

**Treatments for GSM**

- Lubricants can help with comfort with sexual activity
- Vaginal remoisturizing agents are given multiple times a week
  - They’re available in gels, suppositories, lotions
  - Some have hyaluronic acid, some have other chemicals or polymers that help draw out moisture and resurface, but they don’t change the mucosa
- [Dilators](https://en.wikipedia.org/wiki/Dilator) can be useful in people who have been sexually inactive for a while and the tissue is tight (she guides them on that)
- As an aside on sexual function, Sharon reminds them that they might need more stimulation
  - Adding vibrators
- Lubricants can help with comfortable stimulation
  - Silicone particularly, although it’s slippery

> “*There is with sexual function the ‘use it or lose it’ phenomenon*”‒ Sharon Parish

- Promoting regular sexual activity means sex with oneself to help with keeping regular lubrication occurring in combination potentially with lubricants with activity (even with one’s self)
- Use of lubretory stimulation to enhance the response
- Regular use of vaginal moisturizers for any symptoms independent of sexual activity

**If a woman does these things and still has pain**

- Sharon adds a low dose vaginal hormone
  - There’s rings, tablets, cream, inserts
  - There’s [Intrarosa](https://en.wikipedia.org/wiki/Prasterone) (manufactured by [Millicent Pharma](https://us.intrarosa.com/))
- There’s an oral SERM that’s indicated just for **vulva vaginal atrophy** causing [dyspareunia](https://en.wikipedia.org/wiki/Dyspareunia) it’s called [Osphena](https://en.wikipedia.org/wiki/Ospemifene) (the chemical is ospemifene)
  - This is good for somebody who wants to take an oral pill, 60 mg a day
  - It has some of the SERM issues, but it is indicated
  - One of the main benefits is some argue it may be good for breast protection in people at risk
  - It’s not an estradiol, it’s a **serotonin estrogen receptor modulator (SERM)**
  - A lot of people don’t know it’s FDA-approved, and it’s not commonly prescribed
  - It’s not indicated for protection from breast cancer, but theoretically it may be useful for people with a family history because it’s a serum
  - It might have positive effects on bone, but it’s not indicated for that
  - Sharon doesn’t use it very often

## Age 65 and beyond, and resources for finding a provider [2:37:30]

**Do you find that the longer period of time a woman was deficient of hormones, the greater the likelihood she will need additional treatments beyond the systemic estrogen?**

- Tissue changes are progressive
- The answer is a little nuance because it depends on when you catch someone
- If you catch someone three to five years out, they’re going to have more tissue changes than someone who is one to two years out
  - So if you decide that that woman doesn’t need it yet, she could be educated on lubricants, moisturizers, using vibrators for stimulation, and regular sexual activity to improve that
  - But by the time she’s three to five years out… you’re not going to prevent the tissue changes five years later
- Early on, it’s common for women to just be dry and some of the non-pharmacologic things work fine
- If they’re on a systemic hormone, it may be enough because it’s going to leak in the the tissue and tissue changes will not to occur
- But as time progresses, they may start to need it 5, 10, 15 years out
- It’s not unusual for Sharon to have someone come to her at 65 or 70, and they’ve reached the threshold where prior to this, lubricants were working, and now they’re not
- Sharon likes to avoid things that have lots of chemicals in them
  - Like warming liquids and scented things
  - That tissue is sensitive
- But she also has patients who are 80 and just need lubricant

***Even though everyone gets the changes, there is variation in the severity of tissue changes, mucosal, loss of cushioning, decreased lubrication, tightness, and shortening***

- 100% of people get atrophy, but the degree and severity varies
- There are some endogenous hormone factors such as whether they’ve had an oophorectomy
  - The use of systemic hormones probably figures into that, because some probably leaks down there

**There are some barriers**

- Someone in their 20s, they have sex, they get satisfaction, they have an orgasm, they’re not paying much attention to their vulva, thair vagina, their vestibule, their urethra
- And now you’re asking them to put this there, put that there, use this dilator ‒ people don’t want to mess with this
  - It feels like a lot
  - They complain that they didn’t have to do anything for their vulva and vagina at age 25 or 30
  - Sharon replies that they didn’t use Botox or face cream then either, “*It’s just the way it is*”

**Peter’s takeaway‒**

- There are probably a lot of women who are unnecessarily experiencing some form of sexual dysfunction because they don’t realize what’s available to them in terms of systemic tools, local tools, therapeutic tools, medications, therapy, etc.
- There is a journey over time and the changes in women are more dramatic than men
  - They probably require a little bit more willingness to be attentive to oneself, and be a little bit more proactive potentially during that aging cycle
  - The obvious changes are hormones
  - But some of these anatomic changes are just as important
  - Not to mention the health-related changes that may be feeding into the metabolic stuff

**The importance of education**

- It worries Sharon that education about menstruation and STD prevention is being pulled out of schools in certain states
  - We have to be very proactive to make sure this doesn’t go in the wrong direction

> “*In the community, in healthcare, education about sexual health and sexual function across the lifecycle is really a need*”‒ Sharon Parish

- Learning about how to choose contraception and sexual function in your late teens and early twenties
  - And know what your choices might be and why
  - Learning about the impact of childbirth
- Learning in your later reproductive years why you’re still menstruating, but your sexual desire might be dwindling
- Learning how to integrate my brain and my body, if I’m under a lot of stress and anxious and depressed
- Exploring questions:
  - Should I take a medication?
  - What are the implications for my overall quality of life?
  - As I enter menopause what do I do about my system?
    - One thing with hot flashes, if you’re not sleeping and you’re exhausted and you’re feeling poorly, you’re not going to be enthusiastic
    - You’re also going to notice changes in your vagina, your vulva, your genitals, and these need to be addressed
    - Don’t just lump it all together like, “*Oh,  it’s menopause. That’s supposed to happen to me because that’s what the clock says.*”
- They didn’t discuss much older women much (70s, 80s, 90s)
  - Sharon gets women coming to her with some of the same , but also different questions
  - Some studies are of women up to 100

> “*People can be sexual well into their long years*”‒ Sharon Parish

**There’s a lot of ageism**

- There is menopausal sexual health ageism, and menopausal ageism as a woman gets past 70, 75
- It would not be surprising for an 80-year-old man to come to the doctor for erectile dysfunction, but a woman showing up with a question would be

***There’s a long lifespan, there’s a lot of different issues, and we need to work on clinical skills, resources, treatments, as well as education in every forum for teaching women how to think about this***

**If a person wants to find a doctor like you, what are they searching for? What’s the qualification? How do they ask their primary care physician for a referral to someone of your skill?**

- There are sexual medicine physicians
- There are sexual medicine societies,and they all have “find a provider” websites:
  - [International Society for the Study of Women’s Sexual Health](https://www.isswsh.org/) and [find a provider](https://app.v1.statusplus.net/membership/provider/index?society=isswsh)
  - [Sexual Medicine Society of North America](https://www.smsna.org/) and [provider directory](https://app.v1.statusplus.net/membership/provider/index?society=smsna)
- You could ask your clinician, “*Can I have a referral to someone who does sexual medicine or deals with sexual health?*”
- For menopausal medicine, the [North American Menopause Society](https://www.menopause.org/) has a bigger meeting, there’s several thousand, and they also have a [find a provider website](https://portal.menopause.org/NAMS/NAMS/Directory/Menopause-Practitioner.aspx)
- [AASECT](https://www.aasect.org/) has a website with [find the provider](https://www.aasect.org/referral-directory)
- There is a [national physical therapy website](https://aptapelvichealth.org/) with [find a therapist](https://ptl.womenshealthapta.org/)
- The keywords or buckets of professionals to look for are:
  - Sexual medicine specialist
  - Menopause specialist
  - Pelvic floor physical therapist
  - Sex therapist

§

## Selected Links / Related Material

**Book about desire**: [Come As You Are: Revised and Updated: The Surprising New Science That Will Transform Your Sex Life](https://www.amazon.com/Come-You-Are-Surprising-Transform/dp/1982165316/ref=sr_1_1?crid=2LEFPWFPGYGUS&keywords=Come+As+You+Are&qid=1681322581&sprefix=come+as+you+are%2Caps%2C202&sr=8-1) by Emily Nagoski (March 2021) | [44:15]

**Oral contraceptives associated with a chronic increase in sex hormone-binding globulin (SHBG)**: [Impact of oral contraceptives on sex hormone-binding globulin and androgen levels: a retrospective study in women with sexual dysfunction](https://pubmed.ncbi.nlm.nih.gov/16409223/) | *The Journal of Sexual Medicine* (C Panzer et al. 2006) | [59:45]

**Studies of testosterone replacement for women with low sexual desire**:

- [Treatment with percutanous testosterone gel in postmenopausal women with decreased libido–effects on sexuality and psychological general well-being](https://pubmed.ncbi.nlm.nih.gov/16183220/) | *Maturitas* (J Nathorst-Boos et al. 2006) | [1:08:00]
- [Testosterone patch increases sexual activity and desire in surgically menopausal women with hypoactive sexual desire disorder](https://pubmed.ncbi.nlm.nih.gov/16014407/) | *The Journal of Clinical Endocrinology and Metabolism* (J Simon et al. 2005) | [1:08:00]

**Systematic review and meta-analysis of testosterone for women**: [Safety and efficacy of testosterone for women: a systematic review and meta-analysis of randomised controlled trial data](https://pubmed.ncbi.nlm.nih.gov/31353194/) | *Lancet Diabetes & Endocrinology* (R Islam et al. 2019) | [1:08:45]

**Trial of 300 microgram testosterone patch in women**: [Transdermal Testosterone Treatment in Women with Impaired Sexual Function after Oophorectomy](https://www.nejm.org/doi/full/10.1056/nejm200009073431002) | *NEJM* (J Shifren et al. 2000) | [1:09:15]

**Women’s Health Initiative study and fears of hormone therapy**: [Risks and Benefits of Estrogen Plus Progestin in Healthy Postmenopausal Women: Principal Results From the Women’s Health Initiative Randomized Controlled Trial](https://jamanetwork.com/journals/jama/fullarticle/195120) | *JAMA* (J Rossouw et al. 2002)  | [1:11:45, 1:33:30, 2:22:00]

**Guideline for the use of testosterone in women**: [International Society for the Study of Women’s Sexual Health Clinical Practice Guideline for the Use of Systemic Testosterone for Hypoactive Sexual Desire Disorder in Women](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8064950/) | *Journal of Women’s Health* (S Parish et al. 2021) | [1:15:00, 1:20:15]

**Normal levels of testosterone in women by age**: [Androgen levels in adult females: changes with age, menopause, and oophorectomy](https://pubmed.ncbi.nlm.nih.gov/15827095/) | *The Journal of Clinical Endocrinology and Metabolism* (S Davison et al. 2005) | [1:17:45]

**Systematic review and meta-analysis of testosterone use in women**: [Safety and efficacy of testosterone for women: a systematic review and meta-analysis of randomised controlled trial data](https://pubmed.ncbi.nlm.nih.gov/31353194/) | *The Lancet Diabetes & Endocrinology* (R Islam et al. 2019) | [1:18:45]

**Review of therapeutic testosterone use in women**: [Use of Testosterone in Postmenopausal Women](https://pubmed.ncbi.nlm.nih.gov/33518180/) | *Endocrinology and Metabolism Clinics in North America* (S Davis 2021) | [1:26:30]

**Review of use of DHEA, pratersone for treatment of genitourinary symptoms of menopause**: [An overview of dehydroepiandrosterone (EM-760) as a treatment option for genitourinary syndrome of menopause](https://pubmed.ncbi.nlm.nih.gov/31928093/) | *Expert Opinion on Pharmacotherapy* (M Holton, C Thorne, & A Goldstein 2020) | [1:31:15]

**The PRESIDE Study**: [Sexual problems and distress in United States women: prevalence and correlates](https://pubmed.ncbi.nlm.nih.gov/18978095/) | *Obstetrics and Gynecology* (J Shifren et al. 2008) | [1:46:30]

**Recommended books to learn about stimulation and orgasm**:

- [Becoming Orgasmic: A Sexual and Personal Growth Program for Women](https://www.amazon.com/Becoming-Orgasmic-Sexual-Personal-Program/dp/0671761773/ref=sr_1_1?crid=14FGP7125Q97X&keywords=becoming+orgasmic&qid=1681149907&sprefix=becoming+orgasmic%2Caps%2C107&sr=8-1) by Julia Heiman and  Joseph LoPicccolo, Ph.D., illustrated by David Palladini (December 1987) | [1:49:30]
- [The Joy of Sex: The Ultimate Revised Edition](https://www.amazon.com/Joy-Sex-Ultimate-Revised/dp/0307587789/ref=sr_1_1?crid=4E0IHJVPQUIT&keywords=the+joy+of+sex&qid=1681149753&sprefix=the+joy+of+sex%2Caps%2C98&sr=8-1) by Alex Comfort (December 2009) |1:49:30]
- [For Yourself : The Fulfillment of Female Sexuality](https://www.amazon.com/Yourself-Fulfillment-Female-Sexuality/dp/0451202007/ref=sr_1_1?crid=28XI2R105HZNQ&keywords=for+yourself&qid=1681150713&sprefix=for+yourself%2Caps%2C104&sr=8-1) by Lonnie Barbach (December, 2000) | [1:50:00]
- [Getting the Sex You Want: A Woman’s Guide to Becoming Proud, Passionate and Pleased in Bed](https://www.amazon.com/Getting-Sex-You-Want-Passionate/dp/0812932846/ref=sr_1_1?crid=2R9HSR9IS6E68&keywords=Sandra+Leiblum&qid=1681150816&sprefix=sandra+leiblum%2Caps%2C196&sr=8-1) by Sandra Leiblum and Judith Sachs (February 2002) | [1:50:15]
- [Better Sex Through Mindfulness: How Women Can Cultivate Desire](https://www.amazon.com/Better-Sex-Through-Mindfulness-Cultivate/dp/1771642351/ref=sr_1_2?crid=1KU81K4JHRPS9&keywords=Lori+Brotto&qid=1681150971&sprefix=lori+brotto%2Caps%2C101&sr=8-2) by Lori Brotto (April 2018) | [1:50:15]
- [The Better Sex Through Mindfulness Workbook: A Guide to Cultivating Desire](https://www.amazon.com/Better-Sex-Through-Mindfulness-Workbook/dp/1771648376/ref=sr_1_1?crid=1KU81K4JHRPS9&keywords=Lori+Brotto&qid=1681150971&sprefix=lori+brotto%2Caps%2C101&sr=8-1) by Lori Brotto (October 2022) | [1:50:15]

**Recommended website to learn about stimulation and orgasm**: [OMGYES](https://start.omgyes.com/join) | [1:50:30]

**RCT data on using flibanserin (brand name Addyi) in postmenopausal women**:

- [Efficacy and safety of flibanserin in postmenopausal women with hypoactive sexual desire disorder: results of the SNOWDROP trial](https://pubmed.ncbi.nlm.nih.gov/24281236/) | *Menopause* (J Simon et al 2014) | [2:07:15]
- [Flibanserin in Postmenopausal Women With Hypoactive Sexual Desire Disorder: Results of the PLUMERIA Study](https://pubmed.ncbi.nlm.nih.gov/28583342/) | *The Journal of Sexual Medicine* (D Portman et al. 2017) | [2:07:15]

**Sexual medicine societies**:

- [International Society for the Study of Women’s Sexual Health](https://www.isswsh.org/) | [Find a provider](https://app.v1.statusplus.net/membership/provider/index?society=isswsh) | [2:41:45]
- [Sexual Medicine Society of North America](https://www.smsna.org/) | [Provider directory](https://app.v1.statusplus.net/membership/provider/index?society=smsna) | [2:41:45]
- [American Association of Sexuality Educators, Counselors, and Therapists](https://www.aasect.org/) | [Find a professional](https://www.aasect.org/referral-directory) | [2:42:15]
- [Academy of Pelvic Health Physical Therapy](https://aptapelvichealth.org/) | [Find a physical therapist](https://ptl.womenshealthapta.org/) | [2:42:15]
- [Society for Sex Therapy & Research](https://sstarnet.org/) | [Find a therapist](https://sstarnet.org/find-a-therapist/)

**Menopausal medicine societies**:

- [North American Menopause Society](https://www.menopause.org/) | [Find a provider](https://portal.menopause.org/NAMS/NAMS/Directory/Menopause-Practitioner.aspx) | [2:42:00]
- [Academy of Pelvic Health Physical Therapy](https://aptapelvichealth.org/) | [Find a physical therapist](https://ptl.womenshealthapta.org/) | [2:42:15]

**Review of treatment for genitourinary syndrome of menopause**: [Practical Treatment Considerations in the Management of Genitourinary Syndrome of Menopause](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6764929/) | *Drugs & Aging* (R Kagan, S Kellogg-Spadt, & S Parish 2019)

§

## People Mentioned

- [William Masters](https://en.wikipedia.org/wiki/William_Masters) (Gynecologist who pioneered research in the human sexual response and diagnosis and treatment of sexual dysfunction) [37:15, 1:52:30]
- [Virginia Johnson](https://en.wikipedia.org/wiki/Virginia_E._Johnson) (Sexologist and member of the Masters and Johnson research team) [37:15, 1:52:30]
- [Helen Singer Kaplan](https://en.wikipedia.org/wiki/Helen_Singer_Kaplan) (professor of psychiatry at Weill Cornell Medical College and the Payne Whitney Psychiatric Clinic; she founded the first clinic in the US for sexual disorders) (38:45, 1:04:30]
- [Rosemary Basson](https://sexologysupervisors.org/faculty_member/rosemary-basson/) (expert in sexual dysfunction in woman, was the Director of the University of British Columbia BC Sexual Medicine Program for 20 years) [42:00]
- [Emily Nagoski](https://www.emilynagoski.com/the-facts) (sex educator and author) [44:15]
- [Lori Brotto](https://www.loribrotto.com/) (Professor of Obstetrics and Gynaecology at the University of British Columbia, Psychologist and author)  [44:15, 1:50:15]
- [Claudia Panzer](https://www.comp-endo.com/our-physician.html) (Endocrinologist and founder of Comprehensive Endocrinology) [59:45]
- [Irwin Goldstein](https://www.sdsm.info/meet-dr-goldstein) (Director and clinical practitioner at San Diego Sexual Medicine) [1:18:00]
- [Susan Davis](https://research.monash.edu/en/persons/susan-davis) (Professor of Chronic Disease & Aging at Monash University) [1:26:30]
- [Sandra Leiblum](https://en.wikipedia.org/wiki/Sandra_Leiblum) (Sexologist and author) [1:50:15]
- [Bill Maher](https://en.wikipedia.org/wiki/Bill_Maher) (Comedian, commentator, actor, television host) [2:13:30]
- [JoAnn Manson](https://prevmed.bwh.harvard.edu/joann-e-manson-md-dph/) (Chief of the Division of Preventive Medicine at Brigham and Women’s Hospital (BWH) and Professor of Medicine and Professor of Epidemiology at Harvard) [2:30:15]

§

![](https://peterattiamd.com/wp-content/uploads/2023/06/bio-image-sharonparish.jpeg)

##### Sharon Parish, M.D.

Dr. Sharon Parish is a prominent sexual medicine specialist and Professor of Medicine in Clinical Medicine and Clinical Psychiatry at Weill Cornell Medical College who has dedicated her career to improving the sexual health and wellbeing of individuals and couples. She obtained her Bachelor of Science degree from Union College and her medical degree from Albany Medical College. After completing medical school, Dr. Parish completed a residency in Internal Medicine and Primary Care at the George Washington University Medical Center. She then pursued further training in psychosocial and behavioral medicine, completing a fellowship at the New York University School of Medicine and Bellevue Hospital. [[Weill Cornell Medical College](https://vivo.weill.cornell.edu/display/cwid-shp9079)]