# #14 – Robert Lustig, M.D., M.S.L.: fructose, processed food, NAFLD, and changing the food system

**Source:** [https://peterattiamd.com/roblustig/](https://peterattiamd.com/roblustig/)

---

In this episode, Rob Lustig — a researcher, an expert in fructose metabolism, and a former pediatric endocrinologist — discusses what’s wrong with the current food environment, and what we can do to reduce our chances of becoming part of the obesity, diabetes, metabolic syndrome, and nonalcoholic fatty liver disease (NAFLD) epidemics. Rob recently earned a Master of Studies in Law because he believes that educating people about sugar from a scientific standpoint is only half the equation: the other half involves changing policy, which he explains in this episode.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/roblustig/the_Drive_public.png)

Play

#14 - Robert Lustig, M.D., M.S.L.: fructose, processed food, NAFLD, and changing the food system

#14 - Robert Lustig, M.D., M.S.L.: fructose, processed food, NAFLD, and changing the food system

1x15s30s

0:001:23:17

## We discuss:

- What’s the difference between glucose and fructose? [7:00];
- Do we have biomarkers that can give us some indication of average exposure to fructose over a given period of time? [14:20];
- What’s the difference between ALT and AST? [18:45];
- Inflammation, endothelial function, and uric acid [21:30];
- Is there something that fructose does better than glucose? [23:45];
- For children that undergo a remarkable shift from metabolic health to metabolic derangement, is there a concern that these kids suffer an epigenetic hit that makes it harder for them later in life? [26:15];
- How many times do you have to introduce a savory food vs a sugary food to an infant before they will accept it? [29:30];
- How are alcohol and fructose similar in how they affect the brain? [33:51];
- Advice for parents and kids for creating a sustainable environment that’s going to prevent them from running into metabolic problems [40:30];
- Why do some populations have a higher risk of NAFLD? [45:42];
- What causes NAFLD? [48:45];
- Is insulin resistance the result of NAFLD or is NAFLD the result of insulin resistance? [56:00];
- HRV, cortisol, and norepinephrine [1:00:30];
- What are the actual mechanisms that links metabolic syndrome, insulin resistance, fatty liver, and type 2 diabetes? [1:03:00];
- Is the food industry still saying that all calories contribute equally to adiposity and insulin resistance? [1:09:00];
- What is the difference between soluble and insoluble fiber and why do you need both? [1:13:00];
- How can we change the food system when 10 companies control almost 90 percent of the Calories we consume in the US? [1:15:00]; and
- More.

§

## Show Notes

## What’s the difference between glucose and fructose? [7:00]

**Glucose**

- ‘Glucose is the energy of life
- It’s so essential that it’s inessential from the diet: you can consume zero glucose and you will manufacture it yourself’

**Fructose**

- ‘Fructose is vestigial to all animal life
- A storage form of energy in plants
- They can use it for energy
- We can metabolize a limited amount for energy
- Your gut bacteria (they are plants) are more adept at metabolizing fructose than you are
- Fructose is more plant food than animal food’

**Biochemical differences**

- Glucose is a 6-membered ring
- Fructose is a 5-membered ring

Every monosaccharide exists in 2 forms:

1. Ring form
2. Linear form

- ‘The linear form has the capacity to bind to proteins: called the Maillard reaction, also known as the Amadori rearrangement, a biochemical process that occurs normally
- It is the browning reaction: ‘It causes bananas to Brown, it causes humans to brown: in fact, we’re all browning right now because our mitochondria in our cells are engaged in the Amadori rearrangement, it is what makes people age’
- The aldehyde moiety of the glucose, in the linear form, will bind to an epsilon amino group of lysine, which is at position 1 in haemoglobin, and form a shift base which then spontaneously decomposes to form a covalent linkage, which won’t come off and basically will stay there until that hemoglobin molecule is recycled by the spleen’
- This is why you can measure glucose levels through hemoglobin A1c is because, the higher the glucose level in the blood, the more this reaction occurs, and therefore the higher the A1c
- Glucose causes that browning reaction at a relatively low rate
- Fructose makes that reaction occur at seven times faster rate
- In addition, every time it happens, ‘it’s causing those proteins to become less flexible, so less functional, and every time it happens, it throws off a reactive oxygen species (hydrogen peroxide), which then can do damage unless it’s quenched by an antioxidant’
- In the face of antioxidant deficiency, which is called processed food, it can actually cause inflammation and non-alcoholic steatohepatitis (NASH), and many other problems related to the inflammatory response’

**Maillard reaction** [10:00]: a chemical reaction between amino acids and reducing sugars that gives browned food its distinctive flavor. [[Wikipedia](https://en.wikipedia.org/wiki/Maillard_reaction)]

**Amadori rearrangement** [10:00]: an organic reaction describing the acid or base catalyzed isomerization or rearrangement reaction of the N-glycoside of an aldose or the glycosylamine to the corresponding 1-amino-1-deoxy-ketose.[1] The reaction is important in carbohydrate chemistry, specifically the glycation of hemoglobin, as measured by the HbA1c test. [[Wikipedia](https://en.wikipedia.org/wiki/Amadori_rearrangement)]

**Schiff base** [10:50]: A Schiff base (named after Hugo Schiff) is a compound with the general structure R2C=NR’ (R’ ≠ H). They can be considered a sub-class of imines, being either secondary ketimines or secondary aldimines depending on their structure. The term is often synonymous with azomethine which refers specifically to secondary aldimines (i.e. R-CH=NR’ where R’ ≠ H). [[Wikipedia](https://en.wikipedia.org/wiki/Schiff_base)]

**Fructose and ghrelin**

- ‘A third thing that is different is that when you put glucose in the stomach, your hunger hormone called ghrelin goes down
- When you put fructose in the stomach, it doesn’t change
- When you consume a lot of fructose your brain doesn’t know you’ve eaten and so you end up consuming more’

**Fructose lights up the reward center**

**Glucose** is metabolized in the brain: ‘the areas that basically metabolize glucose and give you a functional MRI signal are areas that have to do with the sensory-motor cortex for the most part, and for the basal ganglia ‘

**Fructose specifically lights up the reward center** ‘and now has been shown to induce the same physiology in the brain that cocaine, heroin, nicotine, alcohol, or any hedonic substance also generates’

‘Fructose and glucose are not the same: the food industry would have you believe a calorie is a calorie, a sugar is a sugar…and it is absolute garbage: they are quite different, and it does matter’

## Do we have biomarkers that can give us some indication of average exposure to fructose over a given period of time? [14:20]

- ‘Fructose also binds to hemoglobin, but it does not buy that position 1, therefore you don’t measure it in hemoglobin A1c
- It binds at positions 66 and 110
- The A1c assay is not set up to look at 66 and 110
- There are some indirect measures of fructose biotoxicity, like uric acid or ALT’

**Uric acid**

- ‘The more sugar you consume, the higher your serum uric acid goes, and the more risk you have for gout
- Since fructose can only be metabolized in the liver, because the liver has the GLUT5 transporter, every time a fructose molecule enters a liver cell it has to be phosphorylated
- It goes from fructose to fructose one phosphate and the enzyme that does that is called fructose kinase
- The phosphate has to be donated and ATP is the donor
- ATP becomes ADP
- There is a scavenger enzyme in the liver called adenosine deaminase 1: it then takes ADP down to AMP, then to inositol monophosphate (IMPase), and finally to uric acid
- [Rob’s] group has shown that serum uric acid in children and adolescents correlate with sugary beverage consumption, for example’
- Other people have shown that uric acid is the inhibitor of the endothelial nitric oxide synthase (eNOS)
- An enzyme that exists in your vascular tree that vasodilates the blood vessels, and that keeps your blood pressure down, and we have shown that every increase by 10 percent in fructose consumption increases your blood pressure by 2 millimeters of mercury consistently, and that increases your risk of stroke by 10 percent
- So we have data, and it’s also been shown by Dan Feig at UC San Antonio, that if you give an inhibitor of uric acid synthesis, allopurinol, which is what we give to patients, you can actually lower adolescence blood pressures when they have essential hypertension.
- So this is a mechanistically valid problem and it is a surrogate proxy biomarker sort of, for sugar consumption’

**Alanine aminotransferase (ALT)**

- ‘ALT is a biomarker for degree of liver fat
- ALT goes up when your liver stores fat’
- Peter wants uric acid below 5 in his patients, even though the assay says it considers normal up to 7.0
- Rob uses cutoffs of ALT at 25 and uric acid at 5.5

## What’s the difference between ALT and AST? [18:45]

- ‘Aspartate aminotransferase (AST) is a biomarker for mitochondrial function
- Alanine amino transfer (ALT) is a biomarker for degree of liver fat
- AST is much more minute to minute (i.e., what did you eat at your last meal?)
- ALT is more stable over time
- [Rob’s] group showed that when you cut sugar, AST changes, suggesting mitochondria are actually getting better
- The ranges on these two tests keep drifting upward for what people deem acceptable
- When [Rob] entered medical school in 1976, the upper limit of normal for ALT was 25’
- NB: normal limits come from the population mean and 2 standard deviations around the mean
- Peter wants ALT in his patients below 20 (‘but today’s normal upper limits are about 42’)
- ‘Did something happen to the assay? “No: something happened to us, because now everyone has fatty liver disease”
- The Dallas Heart Study showed that 40 percent of normal people have hepatic steatosis (i.e., liver fat)
- That makes your ALT go up
- So, what I say is 25 was the upper limit of normal 25 should still be the upper limit of normal despite what it says on the lab slip, cause that’s just looking at two standard deviations above the mean. So we use that very specifically in clinic to show parents and kids what is happening to them, and why sugar is the bad guy, because when we get them off sugar, the ALT drops within a month’

## Inflammation, endothelial function, and uric acid [21:30]

In terms of cardiovascular disease, while the endothelial story gets overlooked, the inflammation story is now getting its day based on those two very recent trials, Peter says

- One recent trial and [one that was halted](https://www.cardiobrief.org/2018/05/21/nih-halts-large-cardiovascular-inflammation-reduction-cirt-trial/) likely because of a significant improvement in the outcome of using methotrexate
- ‘When you look at the impact of uric acid on eNOS, when you look at the impact of homocysteine on asymmetric dimethylarginine (ADMA), which also, then, in turn, inhibits nitric oxide, these things start to make a bit more sense
- We always sort of knew uric acid was bad, and we always kind of knew having high homocysteine was bad, but now we’re seeing these mechanistic reasons why: to have vasoconstriction in your coronary arteries’

‘The fact matter is we didn’t have the empirical data. We always had the plausibility argument, but we didn’t know how important it was. Now we have the empirical data, and we have interventional data, to say that this phenomenon is quite important, and it’s not its own phenomenon. It is another manifestation of this global phenomenon we call metabolic syndrome. And when you look at it that way, and say, well, if it’s doing this, what else is it doing, all of a sudden things start piecing together. It’s like a puzzle, you needed the piece in the middle to fit all the other things together, to be able to tell what’s really going on. And uric acid is part of that puzzle.’

## Is there something that fructose does better than glucose? [23:45]

- ‘You will replete your liver glycogen faster
- There is a back door where you can turn fructose back into glucose which can then restore your liver glycogen
- Now the sports drink industry makes a huge deal about this: I think this is truly a tempest in a teapot: I think this is really irrelevant, and the reason is because after you’ve spent three hours on the gridiron you’re not going to spend another three hours on the gridiron
- And you will, by tomorrow, have depleted those glycogen stores anyway, just from eating real food: so the idea that somehow you have to replete your glycogen rapidly does not hold water
- It’s fine to expend your glycogen stores in your liver, and real food will get you back to the same place by tomorrow. ’

## For children that undergo a remarkable shift from metabolic health to metabolic derangement, is there a concern that these kids suffer an epigenetic hit that makes it harder for them later in life? [26:15]

- Very concerned because epigenetics is ‘the gift that keeps on giving’
- It’s possible this may be happening, maybe likely it’s happening, Rob says
- ‘It might explain why things keep getting worse year after year is because we’re adding on all the time and more people are entering this epigenetic disaster
- Animal work Children’s of Philadelphia and also from the Liggins Institute in New Zealand, show that maternal hyperglycemia causes epigenetic changes in utero
- Changes in [H19](https://www.ncbi.nlm.nih.gov/pubmed/29769440), different epigenetic markers that we have on chromosomes, that then portend metabolic dysfunction later on
- We know that from a biochemical standpoint, animals that are stressed or animals that consume large amounts of sugar during pregnancy ended up with offspring that will manifest various aspects of metabolic syndrome later’

## How many times do you have to introduce a savory food vs a sugary food to an infant before they will accept it? [29:30]

- The median for savory food: 13 times
- The median for a sweet food: 1 time

> Imagine a moment when the sensation of honey or sugar on the tongue was an astonishment, a kind of intoxication. The closest I’ve ever come to recovering such a sense of sweetness was secondhand, though it left a powerful impression on me even so. I’m thinking of my son’s first experience of sugar: the icing on the cake at his first birthday. I have only the testimony of Isaac’s face to go by (that, and his fierceness to repeat the experience), but it was plain that his first encounter with sugar had intoxicated him—was in fact an ecstasy, in the literal sense of that word. That is, he was beside himself with the pleasure of it, no longer here with me in space and time in quite the same way he had been just a moment before. Between bites Isaac gazed up at me in amazement (he was on my lap, and I was delivering the ambrosial forkfuls to his gaping mouth) as if to exclaim, “Your world contains this? From this day forward I shall dedicate my life to it.”

— MICHAEL POLLAN, *Botany of Desire*, 2001

- ‘There’s data on desensitization of taste buds and one of the reasons why you keep wanting more and more sweet is because the taste buds get down regulated
- There’s also the desensitization of dopamine receptors because dopamine receptors go down in response to constant bombardment by dopamine’

Peter makes the point that cocaine has two problems

1. You have a nonlinear asymmetric risk of something really bad happening as far as cardiac arrhythmia. So why would you take that risk?
2. Down-regulation of dopamine receptors that develops this tolerance and therefore makes it actually harder for you to experience joy subsequently

‘Neurotransmitters are either excitatory or inhibitory’

- ‘Neurons like to be excited: that’s why they have receptors in the first place
- But neurons like to be tickled, not bludgeoned
- Chronic overstimulation of any neuron leads to neuronal cell death
- Any neuron that is excitatory: it’s downstream of an excitatory stimulus — it wants to protect itself
- It has a failsafe: downregulates the receptor
- There’s less likelihood that any given molecule will find the receptor to bind to thereby reducing the risk for cell death

What does this mean in human terms?

- ‘You get a hit, you get a rush, receptors go down
- Next time you need a bigger hit to get the same rush, and the receptors go down
- And then you need a bigger hit, and a bigger hit, and a bigger hit, until finally, you get a huge hit to get nothing: **that’s called tolerance**
- When the neurons actually do start to die because chronic stimulation causes neuronal cell death: **that’s called addiction**
- And those neurons that don’t come back once they’re dead they’re dead
- This limits the ability to be able to experience that same level of reward, because now you don’t even have dopamine to be able to do it because those neurons are dead’

**Ethanol [33:00]**

- ‘The problem is ethanol in the brain also because it’s polar and dissolves lipids
- It also creates acid aldehyde
- That’s the first step in terms of metabolism of ethanol, which then can cause that Maillard reaction
- Because you’ve made an aldehyde which then generates reactive oxygen species: so you can kill neurons, not necessarily from excitation, but from the biochemistry of the molecule’

## How are alcohol and fructose similar in how they affect the brain? [33:51]

‘They both stimulate the reward center though it seems through different mechanisms likely through different mechanisms’

- ‘There are a lot of different dopamine stimulators
- They have different mechanisms, but they all ultimately impact on dopamine the same way’

‘We also have behaviors that are addictive: gambling, shopping, internet, social media, pornography’

- ‘There is an ‘aholic’ next to every one of those because they’re stimulating dopamine
- But they’re not chemicals, they’re behaviors
- But they still generate that same dopamine response, and therefore they still induce the same phenomenon of tolerance
- But they don’t have withdrawal
- Withdrawal is the effects of these substances on the peripheral body, not the brain, because cocaine has effects at every adrenergic synapse’

Alcohol withdrawal can sometimes be physiologically deadly

- When Peter used to operate on patients who were alcoholics, they would actually just continue ethanol throughout the surgery
- You can kill a patient if you take alcohol away from them too abruptly, whereas opiates the withdrawal is unbearable, but you won’t kill the patient by removing it

## Advice for parents and kids for creating a sustainable environment that’s going to prevent them from running into metabolic problems [40:30]

‘It’s not the added sugar you know, it’s the added sugar you don’t know’

- ‘What we say to the parent is we don’t worry about target numbers: what we say is processed food is the problem because processed food is high sugar low fiber — what you want is a low sugar, high fiber diet — that’s called real food
- Every diet out there that works — the traditional Japanese diet, the Atkins diet, ketogenic diet, Paleo diet, Mediterranean diet — they all work because they’re all real food
- The problem is parents don’t know the difference
- If there’s a label on the food, that’s a warning label, because that means it’s been processed: real food doesn’t need a label’
- Is there a nutrition facts label on broccoli? No
- Is there a nutrition facts label on carrots? No
- Is there are nutrition facts label on the meat in the meat case? No
- The reason is because it’s all real food
- We need to make a conceptual change
- Patients and parents are asked to purchase and consume real food
- All of the new patients in on the same day
- They do an hour-long teaching breakfast and the dietitian narrates why those foods are available for breakfast’

## Why do some populations have a higher risk of NAFLD? [45:42]

- ‘When you look in particular along ethnic lines, about 50 percent of Hispanic boys who were obese had NAFLD’
- Latinos are more at risk of developing NAFLD
- There’s a genetic predisposition
- They have a specific polymorphism of a specific gene called PNPLA3 (G;G)
- A little sugar in your diet makes a lot of liver fat and 19 percent of Latinos have the homozygous (G;G) polymorphism
- The biochemistry changes the behavior
- We know from our study where we actually substituted starch for sugar the kids actually couldn’t even eat as much food as we had to supply’

## What causes NAFLD? [48:45]

What is the etiology of NAFLD? Too much fat, fructose, obesity, caloric excess?

- ‘This is an environmental insult
- And the good news is we figured out what the insult is: the bad news is there are dark forces on the other side keeping it that way’

How do you make the case that it’s fructose that is disproportionately driving this versus some of these other factors?

‘It’s very easy to imagine how you get liver fat: there’s production and then there’s clearance: the amount of liver fat is the equilibrium between those two phenomena’

There are two methods for production:

1. Dietary fat
2. de novo lipogenesis (DNL) (i.e., the creation of new fat): it’s the process of turning sugar into fat

‘DNL had been discounted for years because of one study ([Parks et al., 1999](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC408572/)): the fractional DNL was shown to be only 3 percent’

The reasons why it was only 3 percent:

1. ‘These were healthy people
2. They were fasting, which means they were glycogen depleted: so the fructose went into repleting the glycogen
3. There were also people who hadn’t been large fructose consumers in advance, and we now know that fructose absorption at the level of the gut is inducible: basically they’ve got malabsorption because their enzyme hadn’t been induced yet’

‘But if you continue to supply it, the process increases’

- ‘And we now know the reason for that is a protein in the intestinal epithelial cell called thioredoxin-interacting protein (Txnip), work from Richard Lee and his colleagues at Harvard ([Dotimas et al., 2016](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5059142/))
- There were a whole bunch of reasons why people thought that de novo lipogenesis was a minor pathway: It’s not a minor pathway, it is a major pathway
- Donnelly ([Donnelly et al., 2005](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1087172/)) showed in 2005 that DNL was worth about 25 percent of the fat in the liver’

How much of that is getting exported in VLDL?

‘That’s the clearance side: there are two ways to clear:

1. Fatty acid oxidation
2. Export: can be through VLDL or phosphatidylcholine’

Two inputs and two outputs: so what’s changed to cause the epidemic?

- ‘Our dietary fats have gone down, so that ain’t it
- But our DNL has gone up
- Looking at exports: fatty liver actually makes things worse because it causes inflammation, which ends up making mitochondria less functional, which causes less fatty acid oxidation, and we have data on that, and we have high triglycerides in patients who consume fructose’
- If that pathway out is going up, then you know that if you’ve got fatty liver, it’s because more is coming in
- Bottom line: the DNL is the driver’

## Is insulin resistance the result of NAFLD or is NAFLD the result of insulin resistance? [56:00]

One aspect of metabolic syndrome that everyone agrees on is this phenomenon called insulin resistance — the question is: where does the insulin resistance come from?

- ‘Everyone assumes, “well, you get fat, therefore your fat cells make cytokines like TNF-a and IL-6, those then go via the portal system to the liver, and cause the liver to be dysfunctional, and therefore you increase hepatic glucose output, that then causes your beta cells to have to overproduce insulin, and then that drives the insulin resistance”
- That’s what you learn in medical school
- I actually think that’s actually a rare way that this happens: maybe 10% — I don’t think that’s the majority, but that is one way, we’ll call it the adipogenic hypothesis of metabolic syndrome’
- Because clearly, that patient is not insulin resistant at the adipocyte as evidenced by the fact that they can increase the size of their adipocyte, Peter points out
- Muscles don’t need insulin to import glucose: if they did then every diabetic would be paralyzed
- The reason insulin works at the muscle is to import amino acids: for muscle growth, but not for muscle metabolism’

![](https://peterattiamd.com/wp-content/uploads/2018/09/glut-1024x627.png)

**Figure 1. SLC2 – Facilitative GLUT transporter family**. Adapted from [Mueckler and Thorens, 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4104978/).

- ‘So that’s one pathway of metabolic syndrome, starting at the fat cell: and I think that’s rare
- There’s a second metabolic syndrome: we see it in clinical depression
- Clinical depression causes weight loss, so you’d think that that would actually obviate metabolic syndrome, but in fact, clinical depression increases metabolic syndrome
- It decreases obesity, but it increases metabolic syndrome: and when you do CT scans or MRIs across the abdomen of people with clinical depression, they have increased visceral fat
- Now, why do they have increased visceral fat? Cortisol drives visceral fat accumulation, we know that from the Cushing syndrome patients: glucocorticoids drive that
- So the question is, why are stressed people you know, accumulating visceral fat, irrespective of their subQ (subcutaneous) fat?
- And the answer is because, the sympathetic nervous system, normally which is lipolytic, at least acutely, becomes lipogenic, chronically
- And the reason is because of the cofactor that’s released with the norepinephrine, called neuropeptide Y (NPY)
- NPY actually changes what would be a lipolytic stimulus, to a lipogenic stimulus’
- So, chronic overstimulation of the sympathetic nervous system leads to visceral fat accumulation
- And of course, chronic stress increases cortisol: the two together increase visceral fat
- That visceral fat will make the cytokines, independent of subcutaneous fat
- The cortisol, and the sympathetic piece, the norepi (norepinephrine) piece, both, basically are conspiring to be both pro-lipogenic
- Acutely, norepi will cause lipolysis through the beta-3-adrenergic receptor, at the level of the adipocyte, but it causes lipogenesis when NPY is available’

## HRV, cortisol, and norepinephrine [1:00:30]

- An interesting correlation Peter’s noticed (using his Oura ring which measures heart rate variability (HRV) and other sleep metrics), the lower the measured HRV, the higher the sympathetic tone, and generally the higher the glucose levels
- Peter always assumed it was just cortisol coming along for the ride
- Cortisol does go up at 5-8 AM (i.e., diurnal variation): interesting how much cortisol plays a role
- ‘Cortisol plays a major role, and we know this from all the data from the [Whitehall studies](https://en.wikipedia.org/wiki/Whitehall_Study), in terms of stress’

‘The point is:

1. You can have visceral fat, which releases cytokines and goes to the liver, so can come from the subQ fat, that would be obesity
2. It can come from the visceral fat, that would be stress
3. There’s a third way, and that is, making the liver sick straight away, mainlining the toxin: that’s called sugar’

‘And sugar is the one I think is the biggest problem because it’s probably the one that’s increasing the most’

**HRV**

HRV measures the specific changes in time (i.e., variability) between successive heartbeats.

The raw measurement is the [interbeat interval](https://en.wikipedia.org/wiki/Interbeat_interval) (IBI): IBI is used in reference to the time interval between individual beats of the heart.

![](https://peterattiamd.com/wp-content/uploads/2018/09/1103px-SinusRhythmLabels.svg_-300x296.png)

**Figure 2. Schematic representation of normal ECG.**

From there, HRV can be expressed in 2 domains: time or frequency. The Oura ring shows time domain, which is expressed in raw RMSSD (Root Mean Square of Successive RR Differences).

![](https://peterattiamd.com/wp-content/uploads/2018/09/2000px-ECG-RRinterval.svg_.png)

**Figure 3. RR interval**. The RMSSD looks at the successive RR differences.

Frequency-domain methods: frequency domain methods assign bands of frequency and then count the number of RR intervals that match each band.

- The bands are typically high frequency (HF) from 0.15 to 0.4 Hz,
- low frequency (LF) from 0.04 to 0.15 Hz,
- and the very low frequency (VLF) from 0.0033 to 0.04 Hz ([Wikipedia](https://en.wikipedia.org/wiki/Heart_rate_variability#Frequency-domain_methods), accessed 9/8/18)

Oura doesn’t show frequency domains because they claim that the low-frequency to high-frequency (LF/HF) ratio often does not accurately measure cardiac sympathovagal balance (personal communication; [Billman, 2013](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3576706/)). Also, different programs may use different scales to define LF vs HF, which may also skew the results. Oura does claim that it could provide an accurate measure of sympathovagal balance because of the high precision of the IBI measurement from the ring (personal communication).

## What are the actual mechanisms that links metabolic syndrome, insulin resistance, fatty liver, and type 2 diabetes? [1:03:00]

- ‘Liver dysfunction which occurs due to those cytokines from either the subQ or the visceral fat
- Or because you have primary hepatic dysfunction as in NAFLD
- What’s going to happen is you’re going to have increased hepatic glucose output, because now you’re insulin resistant at the level of the liver
  - Your liver can’t inhibit the enzymes that cause gluconeogenesis
  - The process of hepatic glucose output is because the insulin phosphorylates FOXO1, which is a forkhead protein, that normally goes into the nucleus of the liver cell, and transcribes the enzymes that are involved in glycogenolysis and gluconeogenesis
  - That’s how you raise your serum glucose when insulin is unavailable
  - Insulin is supposed to suppress that by phosphorylating the FOXO1
  - If you’re insulin resistant because there’s liver fat, or because of the cytokines coming in, now you can’t phosphorylate FOXO1, you can’t transduce just that insulin signal, so that your hepatic glucose output goes up, which then increases your serum glucose, which then goes to your beta cell and your beta cell then has to make extra insulin, and it’s making it fast’
- ‘It’s not just making insulin in response to a meal, it’s making it all the time (i.e., there’s no “off-switch”), and insulin is both good and bad
  - It’s good when it lowers your blood sugar
  - It’s bad when it does everything else
  - Insulin’s job is to store energy
  - It is not to keep your glucose normal, it is to store energy
  - It keeps your glucose normal as a function of storing energy
  - If you’re storing energy, you’re going to gain weight’
- ‘In addition, insulin stimulates a different pathway in cells
  - [The MAPK/ERK pathway](https://en.wikipedia.org/wiki/MAPK/ERK_pathway) (i.e., the proliferation pathway)
  - This pathway is responsible for vascular smooth muscle proliferation, coronary artery vascular smooth muscle proliferation, thereby making your coronary arteries tighter, and less likely to be able to vasodilate when they need to, thus increasing the risk for a heart attack’
- ‘It also causes cell division because insulin is a mitogen
  - It causes cells to divide
  - If it causes your breast cell to divide you might end up with breast cancer’
- ‘Hyperinsulinemia is associated with all of the chronic metabolic diseases because of this second phenomenon that insulin does
  - Not just lowering glucose, which it does as a sidelight of storing energy, but in fact, because it causes both inflammation and cell division’
  - Peter’s hope is that as time goes on more and more physicians will realize that hyperinsulinemia, independent of what’s happening at the level of glucose, or A1c, should be taken as seriously as we would take diabetes
- ‘If you look at all of the diabetes studies that are out there in terms of diabetes control, they all improve hemoglobin A1c, and the patient dies anyway
  - The UKPDS (The **UK P**rospective **D**iabetes **S**tudy) ([Bailey and Grant, 1998](https://www.ncbi.nlm.nih.gov/pubmed/9863806)) Yes the ACCORD (**A**ction to **C**ontrol **C**ardi**o**vascular **R**isk in **D**iabetes) study ([Gerstein et al., 2008](https://www.ncbi.nlm.nih.gov/pubmed/18539917)) and several others all show that you can lower blood glucose, you can reduce microvascular complications: diabetic retinopathy, neuropathy, nephropathy, all small vessel complications, by lowering the glucose
  - But what you do is you exacerbate the large vessel complications, like coronary heart disease or cancer, and you end up dying just the same’
- ‘Getting your blood glucose down is only half the job in diabetes
  - Getting your blood insulin down is the other half, and taking drugs that increase your insulin ain’t the way
  - The objective is to increase your insulin sensitivity, and the only way to do that is by diet
  - Not even by exercise alone — you can’t outrun a bad diet — you have to fix the insulin problem, and exercise won’t fix the insulin problem by itself
  - We have a study now that is ultimately, if all goes well, and so far it is, we’ll put the final nail in the coffin on a calorie is not a calorie, and will basically prevent the food industry from ever saying it again – that’s my goal’

## Is the food industry still saying that all calories contribute equally to adiposity and insulin resistance? [1:09:00]

- ‘They are all saying it’s about obesity, and therefore it’s about energy balance, therefore it’s about calories, therefore all calories are the same
  - That’s what they say: it is absolutely not true
  - We have empirical data, we have mechanistic data, we have plausibility data, we have hard data, that show that is just not the case’
- ‘Example: let’s start yeah let’s talk about fiber
  - 160 kcals from almonds
  - You absorb about 130 kcals
  - What happened to the 30?
  - The soluble and insoluble fiber in the almonds forms a gel on the inside of the intestine
  - You can actually see it on electron microscopy a whitish gel that’s going to act as a secondary barrier preventing absorption of some of those almond calories early on
  - If they don’t get absorbed in the duodenum, where they go next?
  - Jejunum: what’s in the jejunum that’s not in the duodenum? The microbiome
  - The duodenum is essentially sterile: it’s got a pH of 1 — only *H. pylori* can live there
  - The lining is formed in the duodenum to prevent your liver from getting the whole dose, because anything that’s absorbed in the duodenum goes straight to the liver’
- ‘Only half (or less) the fructose that you would eat in a piece of fruit, for example, might actually get to the liver
  - The area under the curve will be wider, which means the insulin response will be lower, which is what you want, because it took longer, but a lot of it won’t get absorbed
  - It will be digested: it doesn’t come out in the stool, it gets digested by the gut bacteria who use it for their own purposes’
- ‘Here’s the thing that I only learned about a month and a half ago which is absolutely essential
  - If you don’t consume fiber, that means that your gut bacteria are not getting the food they need
  - Because you’re absorbing it all early, but your bacteria still have to survive: so what do they do?
  - They proteolyze and lipolyze the mucin layer
  - They autodigest the mucin layer that sits on the surface of your intestinal epithelial cells, protecting them
  - You can actually see on electron microscopy an increased apposition of the bacteria with the intestinal epithelial cell, which likely causes damage, possibly a leaky gut, and possibly GI diseases like colitis, and even maybe Crohn’s’

‘The idea is to feed your bacteria or your bacteria will digest you’

## What is the difference between soluble and insoluble fiber and why do you need both? [1:13:00]

- ‘Psyllium is soluble fiber, it’s not insoluble fiber: you need both
  - Fiber has soluble enzymes, like pectins, what holds jelly together
  - Insoluble fiber, like cellulose, the stringy stuff in celery
  - You need both to make that gel: the insoluble fiber forms the latticework’
- ‘Let’s say you put a layer of petroleum jelly on a strainer, you would have an impenetrable water barrier
  - The insoluble is like the strainer and the soluble becomes the thing that fills in the lattice
  - When you have both, it works, and there’s data that shows that if you have either one or the other, it doesn’t work: you need both
  - You get both in real food’
- ‘The food industry keeps adding soluble fiber like psyllium husk to food, like fiber bars
  - Doesn’t make a damn bit of difference
  - They have insoluble fiber in things like certain breakfast cereals, but if you don’t have the soluble fiber, also doesn’t work: you need both
  - Real food has both’
- ‘What the food industry keeps doing, and keeps telling us, that it’s good because it’s got extra fiber
  - Wrong: it doesn’t have functional fiber: it doesn’t have the fiber that does what you want it to do
  - That’s one reason that a calorie is not a calorie all by itself’

## How can we change the food system when 10 companies control almost 90 percent of the Calories we consume in the US? [1:15:00]

- ‘The food system needs to change
- They’re not going to change it from the inside, because right now sugar is their business model
- It’s the thing that increases their sales
- When high fructose corn syrup and the Dietary Guidelines of 1977 were first available, the profit margin of the food industry went from 1% per year to 5% per year: this is their juggernaut, their gravy train
- They add more sugar, they sell more food, and they know it: and that’s why there’s sugar and all the food because when they had it you buy more for all the reasons we’ve discussed
- They have to change the food, which means they have to change the business model: so how do you change the business model?’

‘There are four potential ways to change the business model:

1. **Educate the public**, so that they don’t want that food, in which case then they won’t sell it: we’re trying to do that. That’s one reason I am the chief science officer of a non-profit trying to do just that called [Eat Real](https://eatreal.org/)
2. **Executive branch efforts** like the FDA, or the USDA, but not in this administration: if anything, they’ve rolled back opportunities for that, like the nutrition facts label
3. **Legislate specific changes**: they’re not doing that because they’re all paid off from the American Legislative Exchange Council and other concerns
4. **Judicial impact**: there are lawsuits against the food industry going on, as we speak, in an attempt to try to regulate from the bench, which no one thinks is optimal, but seems to be the only thing that’s available at the moment, aside from education’

- ‘My goal would be to get rid of food subsidies
- The food subsidies are what enable the junk food to be basically half the price of real food
- It’s about the subsidy making junk food cheap
- If you got rid of the subsidies then the market would work
- Any subsidy distorts the market, and there’s no reason for food subsidies
- Would food get more expensive if we got rid of all food subsidies?
- The price of wheat wouldn’t change, the price of soy wouldn’t change, only corn and sugar
- That is where the dietary sugar in our food comes from
- The farm bill is reapportioned every five years: and right now there’s actually tension around that farm bill
- I would like to see the metabolic cost of food built into the farm bill, because right now our government has not yolked the productivity and economic costs of Medicare, Medicaid, and Social Security with food
- I would like to see that link strengthened because the data is there’

§

§

## Selected Links / Related Material

- **Panel that Lustig and Attia were on together**: [Panel: Eating dangerously – why should you be worried about consuming fat and sugar? Can we live longer and better?](https://www.credit-suisse.com/microsites/conferences/aic/en/media-hub/virtual-aic/eating-dangerously.html) | Credit Suisse (www.credit-suisse.com) [5:45]
- **Methotrexate trial halted**: [NIH Halts Large Cardiovascular Inflammation Reduction (CIRT) Trial](https://www.cardiobrief.org/2018/05/21/nih-halts-large-cardiovascular-inflammation-reduction-cirt-trial/) | Larry Husten ([cardiobrief.org](https://www.cardiobrief.org/)) [20:25]
- **The sugar you don’t know**: [There are known knowns](https://en.wikipedia.org/wiki/There_are_known_knowns) (Donald Rumsfeld) | Wikipedia ([wikipedia.org](https://www.wikipedia.org/)) | [40:30]
- **Paper discounting de novo lipogenesis as a source of liver fat**: [Effects of a low-fat, high-carbohydrate diet on VLDL-triglyceride assembly, production, and clearance](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC408572/) (Parks et al., 1999) [52:30]
- **Paper by Lee and colleagues finding Txnip regulates fructose absorption**: [Diabetes regulates fructose absorption through thioredoxin-interacting protein](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5059142/) (Dotimas et al., 2016) [53:30]
- **Paper by Donnelly and colleagues showing DNL worth about 25% of liver fat**: [Sources of fatty acids stored in liver and secreted via lipoproteins in patients with nonalcoholic fatty liver disease](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1087172/) (Donnelly et al., 2005) [53:50]
- **Glucose transporters**: [The SLC2 (GLUT) Family of Membrane Transporters](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4104978/) (Mueckler and Thorens, 2014) [58:00]
- **The Whitehall study on stress**: Whitehall Study | Wikipedia ([wikipedia.org](https://www.wikipedia.org/)) [1:00:30]
- **HRV and sympathovagal balance**: [The LF/HF ratio does not accurately measure cardiac sympatho-vagal balance](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3576706/) (Billman, 2013)

§

§

## People Mentioned

- [Benjamin Franklin](https://en.wikipedia.org/wiki/Benjamin_Franklin) (gout and fructose) [16:00]
- [Daniel Feig](https://www.childrensal.org/dr-daniel-feig-md-phd-mph-nephrology) (research on uric acid) [17:50]
- [Rick Johnson](https://www.ucdenver.edu/academics/colleges/medicalschool/departments/medicine/renal/research/Pages/JohnsonLab.aspx) (research on uric acid) [21:00]
- [Michael Pollan](https://twitter.com/michaelpollan) (describing sugar in *The Botany of Desire*) [30:30]
- [Gabor Maté](https://twitter.com/DrGaborMate) (on addiction) [38:45]
- [Donald Rumsfeld](https://twitter.com/RumsfeldOffice) (known knowns) [40:45]
- [Elizabeth Parks](https://nep.missouri.edu/faculty_parks.html) (showing fractional DNL was 3%) [52:30]
- [Marc Hellerstein](https://vcresearch.berkeley.edu/faculty/marc-hellerstein) (showing fractional DNL was 3%) [52:30]
- [Richard Lee](https://connects.catalyst.harvard.edu/Profiles/display/Person/17340) (fructose metabolism, thioredoxin) [53:30]
- [Kerry Donnelly-Peterson](https://www.uwstout.edu/directory/petersonke) (showed DNL worth about 25% of liver fat) [53:50]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/09/Robert-Lustig-2-x-1-e1536434095159-500x324.jpeg)

##### Robert Lustig, M.D., M.S.L.

Robert H. Lustig, M.D., M.S.L. is Professor emeritus of Pediatrics, Division of Endocrinology at the University of California, San Francisco (UCSF). He specializes in the field of neuroendocrinology, with an emphasis on the regulation of energy balance by the central nervous system. His research and clinical practice has focused on childhood obesity and diabetes. Dr. Lustig holds a Bachelor’s in Science from MIT, a Doctorate in Medicine from Cornell University. Medical College, and a Master’s of Studies in Law from U.C. Hastings College of the Law.

Dr. Lustig has fostered a global discussion of metabolic health and nutrition, exposing some of the leading myths that underlie the current pandemic of diet-related disease. He believes the food business, by pushing processed food loaded with sugar, has hacked our bodies and minds to pursue pleasure instead of happiness; fostering today’s epidemics of addiction and depression. Yet by focusing on real food, we can beat the odds against sugar, processed food, obesity, and disease. [[robertlustig.com](https://www.robertlustig.com/)]