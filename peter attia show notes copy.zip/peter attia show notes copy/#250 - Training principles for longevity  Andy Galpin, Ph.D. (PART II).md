# #250 ‒ Training principles for longevity | Andy Galpin, Ph.D. (PART II)

**Source:** [https://peterattiamd.com/andygalpin2/](https://peterattiamd.com/andygalpin2/)

---

Andy Galpin is a Professor of Kinesiology at California State University at Fullerton, where he studies muscle adaptation and applies his research to work with professional athletes. In this episode, Andy returns to the podcast and continues the conversation about training for longevity. He examines the training practices of powerlifters, Olympic weightlifters, Strongmen/women, CrossFit athletes, and sprinters in order to extract insights that can be applied to the individual wanting to optimize for longevity. Andy goes into detail about exercise load and repetition, training volume, the importance of learning proper movement patterns, the advantage of working to technical failure instead of the number of reps, and much more. Andy ties the discussion together by providing a hypothetical training plan for an individual wanting to optimize for longevity and offers advice for avoiding injury.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/andygalpin2/the_Drive_public.png)

Play

#250 ‒ Training principles for longevity | Andy Galpin, Ph.D. (PART II)

#250 ‒ Training principles for longevity | Andy Galpin, Ph.D. (PART II)

1x15s30s

0:002:46:55

## We discuss:

- Review of the function and organization of skeletal muscle [3:15];
- Review of muscle fiber types [9:30];
- Hypertrophy: changes in muscle fibers and the underlying mechanisms that make a muscle grow [19:30];
- Defining sarcoplasmic hypertrophy and how it relates to the number of reps in a set [30:15];
- Training for maximum strength: what we can learn from powerlifters and a hypothetical training plan [32:45];
- Ideal reps, volume, and load for the powerlifter [44:45];
- What should powerlifters do on their off days? [56:45];
- Are there consequences of powerlifting on long-term health? [1:02:00];
- Defining Olympic weightlifting: a test of power [1:04:30];
- Training principles of Olympic weightlifting [1:07:45];
- Tracking power output when training [1:17:15];
- Frequency of training for Olympic weightlifting [1:22:15];
- How post-activation potentiation (and the opposite) can improve power training and speed training [1:24:30];
- The Strongman competition: more breadth of movement, strength, and stamina [1:32:00];
- Training principles of Strongmen and advice for someone new to the Strongman competition [1:36:45];
- CrossFit: a combination of weightlifting movements, endurance, and circuit training [1:50:15];
- Learning from elite athletes, heart rate recovery, V02 max, and other metrics [1:58:45];
- Optimizing towards being a well-rounded athlete as opposed to a specialist [2:09:45];
- What we can learn from the sprinters about speed, acceleration, peak velocity, and technique [2:17:45];
- A training plan for the “centenarian athlete” [2:24:30];
- Debunking some training and exercise myths [2:33:00];
- The “do nots” of training and tips for avoiding injury [2:34:15]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Our returning guest this week is Dr. Andy Galpin; he was a previous guest back on e[pisode #239 (January of 2023)](https://peterattiamd.com/andygalpin/), where we discussed the structure of muscle fibers, the difference between the different types of muscle fibers, hypertrophy, and how to start strength training
- We never got to finish what we started in our first discussion
  - This is because we went a little deeper than either of us expected into the basic physiology of muscle
  - Our podcast is known for going deeper into subject matter than you’ll typically find in other podcasts, but the price you have to pay for that is time
- We start here by providing a very quick, but important recap of the first conversation around muscle cells, functions, types of fibers, hypertrophy, things like that
- Then, we use that to go into the rest of the discussion, which gets into the construction of a matrix about training
- If you heard the first discussion, you will remember that we talked about the different phenotypes: the powerlifters, the weightlifters, the Strongman, the CrossFit athletes, sprinters
- What we do here is we build out the principles of training in terms of frequency, intensity, volume, rest, recovery, everything that has to do with it
- We then organize all of that information and ask the question, how would you tie that in for someone who’s training for the Centenarian Decathlon?
  - For Peter personally and for his patients, they’re less interested in becoming powerlifters, weightlifters, Strongmen, CrossFit athletes, etc.
  - They’re more interested in being the most strong, physically fit, able people who in the final decades of their life are functioning like people who are two decades younger
- Andy earned his masters in Health Movement Sciences from the University of Memphis, followed by a PhD in human energetics from Ball State University
- Andy is a professor of Kinesiology at California State University, Fullerton, where his research spans adaptations from whole muscle to cellular level changes, which he has applied to his work with professional athletes for more than 15 years

## Review of the function and organization of skeletal muscle [3:15]

- Let’s begin with a review of the major topics covered last time
- The discussion last time was pretty technical; today’s discussion will be a little less so, but will assume that the viewer/ listener has some familiarity with what was talked about

**What cells of muscles look like and how they function at the big, whole-muscle level**

- The term muscle refers to a collective group
- For example, your quadriceps (thigh) is made of four muscles (that’s why it’s called a quad)
- The biceps is multiple bicep muscles, orientation and insertion
- In general, the way that humans move is, muscles will contract, and the end of muscles will come together to form a tendon
  - Those tendons connect to bone
  - When you contract muscle, it pulls that connective tissue (the tendon), that pulls the bone, and you move
- You’ve got muscles throughout your body up and down, and they have different orientations, and they have different responsibilities
  - Some are meant to be what we call antigravity; this is to keep you up all day, and they don’t produce a lot of force for speed, but they’re meant to be non-fatigable
  - And others are the opposite, they provide explosion, power, propulsion
- For example, consider the **calf muscles**; the [gastrocnemius](https://en.wikipedia.org/wiki/Gastrocnemius_muscle), that big one in the middle; if you point your toe to your face that pops out at you
  - That’s meant to be for power, sprinting, and jumping
  - The one that’s actually lower near [soleus](https://en.wikipedia.org/wiki/Soleus_muscle) is meant to be on all day, so that you can stand, walk all day, and not get fatigued
  - This despite the fact that both of them come together to form the Achilles that wraps around the bottom of your heel, inserts the bottom of your foot, and that’s what makes your foot go up and down
- In general, muscle is meant to create movement
- Muscle actually does a lot of other things though that are vital to health, including **pumping fluid up and down**
  - Because of gravity, blood will pull towards the lower part of your body
  - Muscle contraction is in large part what squeezes the blood back up into your heart, and into your lung
- Muscle is the **amino acid reserve**
  - That’s the place where you store amino acids, so that you can use them to create red blood cells, or immune cells, or anything else
- Muscle is also the primary place actually where you **regulate blood glucose**, including glucose/ glycogen storage
- Andy could go on and on, but muscle in general has a very important function in your body for movement as well as signaling
- The last part to acknowledge here is, we typically will call muscle an **endocrine organ**, meaning it will send signals out through the body, through what are called [myokines](https://en.wikipedia.org/wiki/Myokine), or what some people will call [exerkines](https://en.wikipedia.org/wiki/Neurobiological_effects_of_physical_exercise#Exerkines_and_other_circulating_compounds) (if they’re coming out as a responsive exercise)
  - That’s sending signal to your liver, or kidney, or brain, or lung, or anywhere else

**At the level of the individual muscle**

- Each muscle is actually made up of billions, if not more individual muscle fibers

***Muscle fibers or cells, myofiber, cell fiber ‒ these can be used interchangeably***

![](https://peterattiamd.com/wp-content/uploads/2023/04/f1-andygalpin2.png)

**Figure 1. Diagram of a skeletal muscle fiber**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Skeletal_muscle)

- Muscle fibers are basically long cylinders
  - If you think about this like a ponytail
    - A ponytail is nothing but a collective, a whole bunch of individual hairs; and this is how you can think of skeletal muscle
  - [Skeletal muscle](https://en.wikipedia.org/wiki/Skeletal_muscle) is a long, long cylinder; it is very strong
  - [Cardiac](https://en.wikipedia.org/wiki/Cardiac_muscle), and [smooth muscle](https://en.wikipedia.org/wiki/Smooth_muscle) are quite different

***The function of the muscle fiber is to contract***

- If you look at the whole muscle, it is surrounded by a bed of capillaries
- As **blood goes into a muscle**, it comes in the big artery, then it’s going to go through a bunch of capillaries, and those capillaries are really surrounding, and mixing in and out that whole ponytail
  - Capillaries all over, and so they’re circulating around the individual fibers
  - That’s going to get you nutrients in (like glucose or anything else), and get waste products out (like carbon dioxide, etc.)
- Visualize that big long cylinder, the capillaries are around it, and you have a whole bunch of **organelles** that do things
- Probably the most pertinent is what are called [nuclei](https://en.wikipedia.org/wiki/Cell_nucleus), these are called [myonuclei](https://en.wikipedia.org/wiki/Skeletal_muscle#Skeletal_muscle_fibers)
- If you remember basic biology, the nucleus is what controls any cell

***Most cells in the world have one nucleus, but skeletal muscle is unique, because there are an infinite number of nuclei spread throughout the duration of the muscle, and that gives you a lot of what we call plasticity***

- The more nuclei you have, the more control centers you have, the easier it is to respond to stressors, damage, adaptations, etc.
- That’s why skeletal muscle is so adaptable to either good stimuli or bad stimuli
  - An example of bad stimuli would be the case of spaceflight, or physical inactivity
- In addition to that are your [mitochondria](https://en.wikipedia.org/wiki/Mitochondrion), and that’s what’s going to be able to produce a lot of your cellular energy

**Finally, you’ve got what we call the contractile units**

- The things that make your muscle fibers [contract](https://en.wikipedia.org/wiki/Muscle_contraction#Vertebrate) together and squeeze on top of each other are [actin](https://en.wikipedia.org/wiki/Actin), and [myosin](https://en.wikipedia.org/wiki/Myosin)
  - The figure below shows actin in green and myosin in purple
  - These are two molecules that reach up, the myosin grabs the actin, and pulls it together, smashes it literally on top of the cell
  - That’s why, when you flex a bicep muscle, it actually gains height, because you’re stacking things on top of each other, and that requires the muscle to go vertically

![](https://peterattiamd.com/wp-content/uploads/2023/04/f2-andygalpin2.png)

**Figure 2. Macro view of muscle contraction**. Figure credit: [OpenStax Anatomy and Physiology Figure 10.10](https://openstax.org/books/anatomy-and-physiology/pages/10-3-muscle-fiber-contraction-and-relaxation#fig-ch10_03_03)

## Review of muscle fiber types [9:30]

**Can you explain, at that cellular level, what the difference is between the gastrocnemius and the soleus?**

- Earlier Andy drew a contrast between the soleus and the gastrocnemius, and alluded that one is slow to fatigue and one is fast to fatigue (the figure below identifies these muscles in the calf)

![](https://peterattiamd.com/wp-content/uploads/2023/04/f3-andygalpin2.png)

**Figure 3. Muscles of the leg.** Image credit: [NCI](https://training.seer.cancer.gov/anatomy/muscular/groups/lower.html)

- We call muscle fibers one-on-one, but really there’s a distinction between them
- All the way back to the invention of the microscope (by [Antonie Van Leeuwenhoek](https://en.wikipedia.org/wiki/Antonie_van_Leeuwenhoek)); one of the first things the microscope was used for was looking at individual cells
  - He started looking at muscle in whales, in codfish, and a bunch of other stuff
  - He started to notice that some of these cells are really small, and some of them are really big, and that’s the very first time we started to functionally distinguish between big fibers and small fibers
  - Pretty quickly after that, he started to realize that some of them are really red and some of them are more white
- For a number of centuries we distinguished muscle as these fiber types (either red cells or white cells), and it took a long time to figure out why that mattered or what that meant
- Eventually, it became clear that the ones that are red are red, because they have more of capillaries, more blood flow, more mitochondria
  - They have more iron which gives an actual look of being red
  - The white ones have less of it
- For a long time after that, we didn’t know functionally what that meant
- As soon as histology came around we started to realize that we can test the individual muscle fibers for their power output (contraction)
  - You take individual muscle fibers out of the muscle, put them in a Petri dish, tie one end to a forced transducer, try the other end to a fixed unit, and put it in a bath of calcium, ATP, and a bunch of other stuff
  - And those fibers just start contracting unlimited, and you can actually measure how much force is being produced
- This allowed us to go from distinguishing these fibers via color (red versus white), to distinguishing them by their contractile properties
  - I.e. is it contracting with a lot of force or a small amount of force?
- In fact, **force** wasn’t really the distinguishing factor, it was **speed**, and because of that, we started the nomenclature involved to now describe them as **fast-twitch**, or **slow-twitch**
  - That really specifically describes the twitch or the contraction speed

***Two ways to distinguish muscle fibers are by color or contractile speed***

**Eventually, we started to figure out their enzymatic differences (a 3rd way to categorize muscle fibers)**

- Muscle fibers that had more mitochondria (red fibers) were better at using [aerobic metabolism](https://en.wikipedia.org/wiki/Cellular_respiration)
  - This is carbohydrate and fat metabolism
- The ones that were white or fast were much better at using [glycolysis](https://en.wikipedia.org/wiki/Glycolysis) from the [anaerobic](https://en.wikipedia.org/wiki/Anaerobic_glycolysis) part of the equation
  - This occurs in the cytoplasm, outside of the mitochondria
  - You might have heard them described as fast oxidative or fast glycolytic
- Initially when this distinction was drawn, there were two [types of muscle fibers](https://en.wikipedia.org/wiki/Skeletal_muscle#Fiber_types) ‒ Type I and Type II
  - **Type I** is the slow-twitch fibers, the red fibers, the oxidative fiber
  - **Type II** were the fast-twitch
- In the 1950s, we started to figure out that there is a 3rd distinct fiber type
  - This fiber type was more closely aligned to the fast-twitch fibers than the slow-twitch
- So now we have Type I, Type IIa, and Type IIb
  - **Type IIa** and **Type IIb** are distinct but are more similar to each other than they are to Type I fibers
- Some years passed and in 1990 we eventually realized that ***humans don’t have Type IIb***
- However, humans do have what’s called **Type IIx**

**Andy’s summary of muscle fiber types:**

- Humans have three muscle fiber types (Type I, Type IIa, & Type IIx), while most other animals have four types (Type I, Type IIa, Type IIb, & Type IIx)
- In terms of speed Type IIb are ultrafast, Type IIb > Type IIx > Type IIa > Type I
- Type I muscle fibers are less fatigable; they have more mitochondria but don’t produce as much force; they’re slower
- As you move from Type IIA to Type IIx they become faster but more fatigable (because they are more reliant upon glycolysis and carbohydrate metabolism)

![](https://peterattiamd.com/wp-content/uploads/2023/04/f4-andygalpin2.png)

**Figure 4. Summary of muscle fiber types (Type IIb are not found in humans)**

**How does the soleus and gastrocnemius compare in humans?**

- The gastroc in most humans is around 60-70% Type IIa fibers (maybe even up to 80%), and so they’re very, very fast
- The gastroc will again cause a fast contraction, but they won’t hold on for very long, because they are fatigable
- The soleus can be up to 90% slow-twitch

***This is a great comparison, because most muscles in your body are some combination of fast- or slow-twitch, but the soleus and the gastroc are probably the best example of the two extremes***

- In mice, the soleus is 100% slow-twitch
- In humans, if a biopsy showed their soleus was 80% slow-twitch, that would be pretty high
- Likewise, in humans if their gastroc was 70% fast-twitch, that would be pretty high
- This matters functionally
  - If you have a compromised soleus, you’re probably less likely to be standing; you’re going to sit and be less physically active
  - If the [gastroc] is compromised, it’s hard to move fast and powerfully

**How modifiable is that distribution? Is it purely genetic, or is there a trainable component to the ratio of fast to slow-twitch fiber in a given muscle?** [16:40] tk

- It is extremely trainable; it comes down to stimuli and time
  - The more stimuli you give it, and the more time you give it, the more it will change
- Like anything else, an asymptote exists here
  - If you are untrained, physically inactive, in a cast for two months, go into space flight ‒ responsiveness to training happens faster
  - If you are well-trained, as months and years go on, you start changing really, really slowly, because you are closer to the end of the spectrum

![](https://peterattiamd.com/wp-content/uploads/2023/04/f5-andygalpin2.png)

**Figure 5. Hypothetical responsiveness to training is untrained and well-trained individuals**. (Asymptote from [Wikipedia](https://en.wikipedia.org/wiki/Asymptote))

- Functionally, there is no limit to how far you can go, given enough total exposure

***To put some realistic numbers on the gastroc, in an untrained individual who hadn’t exercised for 5+ years, 8 weeks of exercise could cause 10-15% change in fiber type***

**Does this mean more type II muscle fibers are expressed and less type I? Is this change due to making new cells and apoptosis of old cells?**

- Generally no
- There’s this idea called [hyperplasia](https://en.wikipedia.org/wiki/Hyperplasia); hyperplasia is when you would grow a new cell
  - That is very, very uncommon in normal human situations
  - It can happen with extreme eccentric training
  - It looks like it probably happens with a lot of exogenous testosterone use over many, many years
  - You can get it in cell culture, and you can get it in animal models
  - But in normal human situations, hyperplasia is very uncommon
- In humans, what more commonly happens is the current fiber type will transition its type

***Remember there are three fiber types in humans; that’s not actually true either; there’s a whole combination of what we call hybrids***

- If you were to take any one individual muscle cell, it might be entirely IIa on one end of the cell, but it might be what we call a I-IIa, and this is a single muscle fiber that expresses both Type I and Type II
  - Depending on the length of the cell, it may be different fiber types in different spots
  - The same thing happens in IIa, IIx; you have have a triple hybrid and have Type I-IIa-IIx (where all three muscle fibers are expressed)
- These muscle fibers are expressed in response to stimulus, or lack thereof

## Hypertrophy: changes in muscle fibers and the underlying mechanisms that make a muscle grow [19:30]

**If you compared a biopsy of Peter’s biceps to that of a professional bodybuilder, how do the muscle fibers look different?**

- Let’s use the VL ([vastus lateralis](https://en.wikipedia.org/wiki/Vastus_lateralis_muscle)), the outside quad muscle as an example, just because we have thousands of biopsy studies from there
- There are a couple of things to understand
  - 1 – Counting muscle fibers total is a very challenging thing, because the only true way to do it is to take your entire muscle, cut it in half, and count it
  - 2 – Estimates involve taking the whole muscle size, average size of the muscle fibers, accounting for fluid and stuff; that’s tricky at best
  - 3 – We have good data from animal models but humans are more challenging

***In general, fast-twitch fibers are bigger than slow-twitch fibers by diameter (they’re wider)***

- But, when you throw training in the equation, that all goes out the window
- Andy has analyzed thousands of slow-twitch fibers that are bigger than fast-twitch fibers in that individual person

**Does that tell us anything about the individual?**

- If you look at an extreme endurance athlete who is getting as much potential out of their slow-twitch muscle fibers as possible, you will see remarkable hypertrophy of the Type I fiber
  - Classic endurance training results in fiber-type-specific hypertrophy
    - Steady-state runner, cyclist, swimmer, rower, things like that
    - Their slow-twitch muscle fibers (Type I) are large, as large as or larger than their fast-twitch muscle fibers (Type II)
  - Don’t consider intervals and other things because scientifically, that’s hard to do
  - There can be exceptions; when you’re actually pulling out one muscle fiber at a time, you’ll see some really wild stuff
- If you were to invoke any strength training, the difference at the level of the cell between powerlifters, or bodybuilders is not that different; but it is different from steady-state cycling or something
  - With strength training, the IIa fibers are going to be very large
  - However, you wouldn’t be able to pull a IIa fiber and distinguish between a bodybuilder, a powerlifter, or a weightlifter
- Exogenous [testosterone](https://en.wikipedia.org/wiki/Testosterone) throws a wrench into this
  - [Satellite cells](https://en.wikipedia.org/wiki/Myosatellite_cell) will be changed, and total muscle buffer size is probably going to get exceptionally large

**Peter’s takeaway** ‒ So if you compare Peter’s [VLO](https://en.wikipedia.org/wiki/Vastus_lateralis_muscle) to the VLO of Jay Cutler (a world-class bodybuilder), if you do an ultrasound, there’s no question that the total size of his muscle is so much bigger, he probably has more fibers because he’s using exogenous testosterone (Peter is not), and his type II fibers are bigger than Peter’s

- Andy agrees, the type II fibers would be very, very large
  - He biopsied one individual powerlifter/ bodybuilder., and some of his fibers were so large, they were comparable to rhinoceros muscle fibers (not all of them, but a handful)
  - The size would be fairly similar to a hair; you could see it with your naked eye
    - But even smaller skeletal muscle fibers in humans can be seen with the naked eye, in the VL especially
- Peter notes, “*There is no other cell in the body that we spend so much time thinking about the actual size of the cellular unit. We don’t really care about the size of your hepatocytes, we care about the functional units, and how they integrate. We care about the function…*”
  - He has never given much thought to, “*Are my hepatocytes the same size as your hepatocytes? If mine get bigger or smaller, what’s happening?*”
  - In the case of [NAFLD](https://en.wikipedia.org/wiki/Non-alcoholic_fatty_liver_disease), he guesses there would be changes in intra, and extracellular fat accumulation

**What happens with hypertrophy training? What actually causes the enlargement of a muscle? [24:10] tk**

- Let’s keep this simple and *not* consider the use of exogenous testosterone; we’re *not* talking about hyperplasia (the creation of new cells)
- By definition, we know that the myofibril has gotten larger; it has expanded in diameter

*What led to that?*

*How much of that is intracellular water?*

*How much of that is the synthesis of new organic matter (amino acids or something else)?*

- We’re going to distinguish chronic hypertrophy (permanent hypertrophy) from acute hypertrophy and focus on chronic hypertrophy
  - An example of **acute hypertrophy** would be you just left the gym and your muscles are bigger, full of fluid
  - **Chronic hypertrophy** refers to sustained muscle growth over time
- Chronic [hypertrophy](https://en.wikipedia.org/wiki/Muscle_hypertrophy) is either going to be a result of either **contractile hypertrophy** or **sarcoplasmic hypertrophy**
  - In either case, the muscle cell got larger; the diameter is expanded

The question now is, *what actually changed inside that cell that caused it, or allowed it to be permanently larger?*

- In the case of *sarcoplasmic hypertrophy*, this is very new that we even thought it existed
  - Folks have been talking about this from the bodybuilding perspective in those communities for a very long time, and we always called it broscience
  - [Mike Roberts](https://auburn.edu/academic/education/ed/collegedirectory/profile_page.php?uid=mdr0024), in his lab at Auburn, started looking into it and [found](https://www.frontiersin.org/articles/10.3389/fphys.2020.00259/full) that actually was happening [increases in metabolic enzymes and muscle tissue fluid]
- A *contractile hypertrophy* happens as a result of increasing proteins on those myosin and actin
  - That may or may not be important
  - For the myofilaments here, you don’t add more actin or myosin, you just add more protein, globulin to them and this increases their diameter
- Imagine myosin and actin working like a circle of friends
  - If you were to extend your arms out to the side, grab your friend’s hand, and bring your hands closer to your midline, then your friends would come closer to you
  - If everybody did it at the same time, the entire diameter of that circle would get much smaller, than expand
  - Well, if you were to double your size, but your friends stayed the same distance away from, and then a friend doubled her size, all of a sudden, when you reach your hand out to grab them, you’re already touching them
  - When everyone becomes larger, the whole circle can expand; and this is called lattice spacing
- **Lattice spacing** is the spacing between actin and myosins; this is very, very important
- Back to the circle of friends analogy, if you continue to get larger, eventually, you would tell the friend next to you, “Hey, you scoot over a few inches, because you’re crowding on my personal space.”
  - And then that friend would say the same thing to their neighbor
  - Now the standing circle starts to expand
  - This is probably the biggest explanation for why muscles increase in diameter

***As you put more proteins in the contractile units, the muscle fiber diameter need to increase to maintain optimal spacing [contractile hypertrophy]***

**Does contractile hypertrophy come with increased contractile force as well?**

- Peter thinks because you’re putting more “hooks,” you’re creating more actin and myosin filaments to grab and contract
- Andy explain this is true, “*Number one, in general, especially early in someone’s exercising career, as you get stronger, you’ll add more muscle mass*”
  - That [R score](https://en.wikipedia.org/wiki/Coefficient_of_determination) is not 99 or 100%
- Optimizing for muscle growth is not the same as optimizing for strength (and visa versa): at some point they will start to diverge, but at the very beginning they are tightly linked
- As you continue with your training career, you get stronger and stronger, but the link between muscle size and strength starts to go away
  - It never goes away entirely because if you’re tacking on contractile units, it’s going to come with some increase in force (even if it’s not optimizing strength)
- Think of powerlifting, strongman, wrestling, MMA ‒ generally, as you go up in physical size, you go up in strength
  - This doesn’t mean you couldn’t find a 155-pound athlete who’s stronger than a 170-pound athlete
- If you add on some muscle, you’re going to get stronger
- If you just strength train, you’re probably going to tack on some muscle as well; they’re both going to come along for the ride

## Defining sarcoplasmic hypertrophy and how it relates to the number of reps in a set [30:15]

**Going back to sarcoplasmic hypertrophy, what was it that the bodybuilding community was proposing that science only recently came to recognize?**

- For a long time, exercise scientists proposed an optimal range of 8-12 repetitions for maximizing muscle hypertrophy
- But, if you look at bodybuilders, they were doing all kinds of other stuff
  - Sets of 20-30
  - Different styles of training
  - Scientists considered that muscular endurance or strength but not hypertrophy
- Further research, much of it by [Brad Schoenfeld](https://www.lehman.edu/academics/health-human-services-nursing/health-promotion-nutrition/fac-schoenfeld.php) showed that hypertrophy is pretty much equal anywhere between 5 reps to 30 reps per set, if other things are equated for (see studies listed under selected links)

**Do the reps in reserve have to get close to failure in both low reps per set and high reps per set (so the** [**RPE**](https://www.cdc.gov/physicalactivity/basics/measuring/exertion.htm#:~:text=The%20Borg%20Rating%20of%20Perceived,like%20your%20body%20is%20working.) **gets to the same point)?**

- Yes, at then end of 30, you need to be hurting as much as you would be at the end of 7
  - That’s very hard, because you’re going to start hurting at 15 reps
  - Higher reps are more time under tension and can be more taxing to your cardiovascular system
- What the bodybuilding community would say is, if you lift in this fashion 5-10 reps, you might increase contractile units, and that’s why you’re getting stronger

***Higher repetition ranges produce sarcoplasmic hypertrophy ‒ this is exclusively explained by increases in fluid retention (non-contractile hypertrophy), and this is why you can get bigger but you’re not getting stronger***

- This was something that the science community didn’t recognize; the technology wasn’t there to measure it
- [Mike](https://auburn.edu/academic/education/ed/collegedirectory/profile_page.php?uid=mdr0024) developed technology to distinguish between **cytoplasmic hypertrophy** [sarcoplasmic hypertrophy] and **contractile hypertrophy** [myofibril number], and see how this changes over the course of training
  - His [review paper](https://www.frontiersin.org/articles/10.3389/fphys.2020.00816/full) shows a graph he’s developed that shows what happens over the course of your training experience (below)
  - This shows changes in cytoplasmic hypertrophy [the green line below shows muscle fiber CSA, cross sectional area or volume] and contractile hypertrophy [the blue line below shows myofibril number] over years of training

![](https://peterattiamd.com/wp-content/uploads/2023/04/f6-andygalpin2.png)

**Figure 6. Changes in sarcoplasmic hypertrophy with years of resistance training**. Image credit: [*Frontiers in Physiology* 2020](https://www.frontiersin.org/articles/10.3389/fphys.2020.00816/full)

![](https://peterattiamd.com/wp-content/uploads/2023/04/f7-andygalpin2.png)

**Figure 7. Two proposed mechanisms of muscle fiber hypertrophy**. Image credit: Image credit: [*Frontiers in Physiology* 2020](https://www.frontiersin.org/articles/10.3389/fphys.2020.00816/full)

## Training for maximum strength: what we can learn from powerlifters and a hypothetical training plan [32:45]

**Let’s compile a matrix of different athletes and training variable by comparing training of a powerlifter, an Olympic weightlifter, a Strongman, a bodybuilder, a CrossFit athlete, a track and field athlete in terms of training frequency, volume, and intensity (as a % of 1RM or VO****2** **max)**

*Peter’s ultimate goal in doing this is to extract from each of these phenotypes how to train to be the best Centenarian Decathlete*

- In other words, Peter is training for the 90-year-old version of himself to be like a very fit 70-year-old

**The powerlifter**

- Powerlifting **definition** ‒ it consists of only only three lifts, and you are scored on the basis of the total amount of weight you move in a [deadlift](https://www.youtube.com/watch?v=WAn7OPr2RdE), a [bench press](https://youtu.be/5E1mXrOm9YE), and a [squat](https://youtu.be/7yFbBWTB8y0)
  - Nobody cares what you look like, how fast you can do it, or how many reps you can do
  - Those guys are strong
- Andy will use the terms **strength** and **force** interchangeable
- Technically, **maximal strength** is what’s the maximal amount you can do one time
- The difference between **force** and **power** is **speed**

***In powerlifting, there is no speed component; it is explicitly a test of pure and absolute strength***

**What can a human deadlift?**

- Andy has worked with [Stefi Cohen](https://www.hybridperformancemethod.com/steficohen) a little; she has 25 world records
  - In one of her competitions she weighed around 119 lbs and deadlift 525 [[545 lbs in 2019](https://www.hybridperformancemethod.com/steficohen), 4.4x her bodyweight)
  - Deadlift is her thing, but she’s still probably benching 200-something and squatting well over the 400s, and for a 120 lb female, that’s pretty strong
- This is unbelievable; at Peter’s strongest he couldn’t deadlift 525 lbs (this was at his peak, age 18, and he weighed 160 lbs)
- Peter deadlifted today, and the main set was four rounds of 1-minute, as many reps as possible with 315 lbs, with a 3-minute rest in between rounds
  - It’s a different stress; it hurts in a totally different way
  - Andy notes, “*You’ve got good leverage for pulling. You’ve got long arms. You’re probably pretty efficient at deadlifting.*”
  - Peter agrees, deadlifting was his best of the three powerlifting exercises, by far
    - Bench was his worst; 270 was his best (at a weight of 160, which is not that good)
- Powerlifting is a little complicated because you have to consider tested versus untested athletes (it’s a big difference)

- The maximal human potential (on all the steroids) is [AJ Roberts](https://www.westside-barbell.com/blogs/the-blog/a-j-roberts); his best squat was 1,250 or 1,240 lbs
  - He was 308 lbs for that meet; so this is a 4x squat
- The all-time record is north of 1,300 lbs
- It’s not common, but a handful of people have deadlifted 1,000 lbs or benched 1,000
- A lot more people have squatted 1,100+

***These people are insanely strong***

- Peter has no desire to ever do a maximum rep deadlift, bench press or squat ever again
- Instead, he’s interested in the principles of how powerlifters train

**Training for strength like a powerlifter: [40:00] tk**

*Hypothetical person*

- Let’s assume this is not a world-class athlete with an enormous training age, nor is it someone who has never lifted a finger
- Let’s assume this person has some exercise exposure, but not specific to this endeavor
  - Maybe they grew up playing sports
  - They’re reasonably fit
  - They understand what lifts are but have never been to a powerlifting meet
- Andy make distinguishes between what is **theoretically optimal** and what is **technical optimal**
  - The latter being what is more realistic and practical
  - Peter distinguishes these as efficacy versus effectiveness
    - With max **efficacy**, in theory you can do everything perfectly and will get the best results
    - **Effectiveness** is what happens in the real world ‒ you might stay up late because your kids are sick or you may have a deadline at work that cuts into your training time
- In either case, **specificity** is always the answer
  - If you want to get better at writing, you need to write
  - If you want to get better at sprinting, you need to sprint

***Theoretically, if you want to get stronger, you should practice picking up 100% of your max every single day; but that’s not realistic because the frequency of injury is too high***

- An elite athlete might be able to do something close to that
- For example, the [Bulgarian method](https://www.muscleandfitness.com/workouts/workout-routines/everything-you-should-know-about-bulgarian-method/) (this would be weightlifters, not powerlifters) uses a [one-rep max](https://en.wikipedia.org/wiki/One-repetition_maximum) in the snatch, clean and jerk, and squat every day
  - These people probably have assistance; they are 5-9 years into their training career, and in between they’re getting massages
  - [Naim Suleymanoglu](https://www.greatestphysiques.com/male-physiques/naim-suleymanoglu/), aka Pocket Hercules, he didn’t train this way all-year round, but he did for certain phases of his training

***If you train at high specificity, you’re going to get better at those things; and what you want to do is get as close to that as you can while not inducing overload injury***

**Realistic scenario**:

- A **realistic scenario** is to work on that movement pattern for 1-5 days per week; two days would be good for a lot of people
  - If you want to get stronger at squatting, squat twice a week
    - If you recover well, squat well, your mechanics are good, then squatting three days a week would be a really, really good program
- If you wanted to do all three (like in powerlifting) ‒ bench twice a week, deadlift once a week, and squat once a week
  - If you wanted to squat twice a week and deadlift twice a week, you could maybe get away with that, depending on other variables
- This could be as little as two days a week of training, because you could do a bench, squat day and a bench, deadlift day
  - For this person they’re describing (and a lot of people), they would get stronger
  - This wouldn’t be optimal, but it would be effective for a lot of folks

## Ideal reps, volume, and load for the powerlifter [44:45]

*What do you recommend for the person who is willing to be in the weight room four days a week?*

- Look into what’s called **conjugate**; there are many forms of this
  - The [Westside Barbell Louie Simmons form of conjugate](https://www.westside-barbell.com/blogs/the-blog/conjugate-system) is a little bit of pure strength work at the beginning, there’s a muscular endurance phase, there’s a speed phase, and it rotates through each week
    - They power through: bench, squat, deadlift, bench squat…
    - One day you’re going to do a max deadlift and some assistance work in your low back/ glutes/ hamstrings/ etc.
    - The next day, maybe it’s a max bench and work on your triceps/ shoulder/ rear delts/ neck/ etc.
    - It’s a very easy model
    - See more in the selected links section

*Is the only time you’re going to have this athlete moving insanely heavy weights in the three formal lifts?*

- Andy would stick mostly to the lift because specificity wins here
- This person is not a professional athlete, so you can make the argument that they need more variation
  - Variation will give you a push toward overall safety because it’s less overuse of the same movement pattern and loading pattern
- However the more variation there is, the less specificity
  - There is also less direct direct adaptation and less likelihood of overuse
- For this person, the core of the day will focus on that exact movement ‒ a [barbell back squat](https://youtu.be/7yFbBWTB8y0)
  - This is the focus for 8 weeks prior to competition
  - On the off-season, he might introduce variation and do other stuff
- In the specificity phase, you would focus on the primary lift and do a ton of accessories
  - If the hard work was focused on the barbell back squat, then maybe add a [goblet squat](https://www.youtube.com/watch?v=ubV_MaOsjDw), [split squat](https://youtu.be/VncTA2oFMuo), [lateral lunges](https://youtu.be/qTE4YdlLL4A), [reverse hypers](https://youtu.be/3vmbvoT2m-U), etc.
  - For the accessories, use a higher repetition range *not* a max-effort set-up

> “*You might do sets of five, eight, something like that, to really support the joints and make everything feel good, but you’d keep your pure, pure strength work for that core lift*.”‒ Andy Galpin

**Let’s pick the deadlift, for example. What’s the rep range you’re going to have them working in? Is there a number of reps that is so high that it’s getting you too far away from max strength?**

- Five and less
- When you get past five, you start losing force production

*Are you recommending 5 reps at 85% of the* [*1RM*](https://en.wikipedia.org/wiki/One-repetition_maximum)*?*

- This depends a lot on fiber type and movement
  - The same is not true for a deadlift versus a bench
- It’s a roughish number
- The Prilepin chart (shown below) tells you how many total reps to do throughout the week at a given percentage of your 1RM
  - It give an idea of the max effort you can get away with and how much supporting work you need to do
  - To do this you need to know your 1RM

![](https://peterattiamd.com/wp-content/uploads/2023/04/f8-andygalpin2.png)

**Figure 8. Prilepin’s Chart of reps at % 1RM**. Image credit: [Power Athlete](https://powerathletehq.com/prilepins-chart/)

**Velocity transducers can project your 1RM**

- Peter has a velocity transducer; it’s a device that sits on the ground and has a strap that goes on the bar
  - One example is [Gym Aware](https://gymaware.com/productsmain/)
  - This will measure the speed of the exercise, you input the weight, and it tells you your projected 1RM based on the speed you’re doing the exercise and your level of fatigue
- Peter finds it is less accurate with lower weight
  - For example, if he’s warming-up with 135 lbs on the bar, there’s no amount of speed you can put on it that will get you anywhere within the range of what it’s prediction is
  - But, it’s pretty accurate once you get into that five rep range

**Is a velocity transducer accurate enough for someone who doesn’t want to do a 1RM?**

- There are a number of online calculators to do a one-rep max test
  - Use a weight you’re comfortable with, and do it anywhere between 3-10 reps
  - The estimates that go up to 20 reps per set are not very accurate; so stay below 8 reps when you do this
- Peter reflects, “*You said something earlier that now I think kind of resonates. I have never found those calculators to work for me*.”
  - They’re not accurate for a slow-twitch guy
  - Andy notes, “*Whatever you’re doing at your 85%, you’re doing 15 reps. I’m going to do four. I’m a super fast-twitch guy.*”
- You also need to take into consideration your genetics and training history

**How many working sets do you need to do in a day?**

- Let’s say you’re doing the Westside Barbell approach where the working sets are around the deadlift (the main set of the day), and you’ll do accessory and endurance stuff later
- Begin with a warmup
- Andy said earlier not to go over 5 reps
- In the beginning, you can *maximize strength* using the **3 to 5 concept**:
  - 3-5 days per week
  - 3-5 exercises at 3-5 reps per set
  - 3-5 total sets with 3-5 minutes rest between each set
  - This only works if you’re loading heavy; if you’re going light, it’s not going to work
- If you go as low as 3 days per week, you’re going to do 3 exercises for 3 sets of 3; and the intensity will be high
- If you go all the way to 5 days a week, 5 exercises, 5 sets of 5; that volume is going to be really taxing if your loading it appropriately under the powerlifting category
- Another method that is super easy to understand is the **1 to 5 concept**
  - Andy didn’t invent this; you can find it in books from the 1990s and earlier
  - This is also in the powerlifting matrix for optimizing strength

**Evaluating intensity of effort** [53:15] tk new section?

- [RPE (rating of perceived exertion)](https://en.wikipedia.org/wiki/Rating_of_perceived_exertion) and [reps in reserve (RIR)](https://blog.nasm.org/reps-in-reserve#:~:text=What%20Does%20Reps%20in%20Reserve,the%20lift%20with%20good%20form).) are two ways to think about this
- RPE is a scale of 6-20 (the [original Borg scale](https://en.wikipedia.org/wiki/Rating_of_perceived_exertion#Set_points_on_the_RPE_scale)); ***the top of the scale (20) is the hardest repetition you could ever do***
  - If you use a scale of 1-5, 4 is probably the sweet spot
- Reps in reserve is a similar idea; if you thought you could do 10 reps and you wanted to do 2 reps in reserve, you would stop at 8 reps (so there are 2 reps left in reserve)
  - You would do a set of 4 and have 1 rep in reserve; so you get to the end of that 4 and maybe have 1-2 reps in reserve
- Peter thinks that reps in reserve is easier to explain to people, but at the same time, you have to know what failure is
  - This is not something you can figure out by yourself
    - You have to have the experience of dropping a bar on your chest and having the guys run across the gym to pick it up
- Andy suggests using a machine to safely determine RPE and RIR
  - People who are not highly trained fail epically when trying to determine RPE and RIR
    - People will think they are at a RIR of 2 but it is really more like a 7
    - People are way stronger than they realize

**For the 3 to 5 system to work, are you aiming for 1-2 reps in reserve?**

- Closer to 1 rep in reserve

> “*Remember, you’re not going to get stronger by going at sub-maximum weights; you’re not going to optimize.*”‒ Andy Galpin

- The whole idea of getting stronger, you’ve got to test the limits of where you’re at, within a safe range
- If you’re just starting, take your time to ramp up
  - Take 6-8 weeks
- Another caveat Andy always adds is, if you want to get stronger and you’re really untrained, you don’t have to go this heavy
  - You can get very strong doing sets of 20
  - But this avatar was someone who was past that point, and they needed to really get closer to optimal strength (this is why they’re going heavier)

## What should powerlifters do on their off days? [56:45]

**Last question for the powerlifter, will doing a bunch of cardio on the other 3 days a week make them a better powerlifter?**

- No

*What do you advise they do on their off days if the objective is maximizing strength?*

- Powerlifters are notorious for being lazy
  - If they’re not lifting one at max, they’re going to be circling Walmart for two and a half hours to get a closer parking spot
- More recently, people in that community have started to realize the need for some level of fitness simply to handle the training volume
- If you’re pouring sweat getting through your warmup and tying your shoes, you probably shouldn’t be doing one rep maxes all day
- You need to get fit first

**Andy’s advice**

- Do the training discussed and finish each workout with a set of 8-12; that little bit of volume will help to add fitness
- To maximize strength, rest on the off days if you’re fit
  - Do recovery stuff, maintenance, mobility, breath work
  - Zone 2 or lower movement
  - Just don’t do much work, because every amount of work contributes to systemic fatigue
- Preserving muscle glycogen is not a huge deal if you’re doing 3 sets of 3
- But your nervous system requires carbohydrates for metabolism, and it takes time to recover
  - To restore muscle glycogen, phosphocreatine, and ATP

***As long as you have some baseline fitness, there is no reason it would give you an advantage to do more endurance work in-between days at the gym, lifting weights***

**Peter remembers training in high school and seeing how powerlifters train**

- The gym he went to was a powerlifting gym (which is why he got into it)
- His primary goal was to train for boxing
- He was doing infinitely more volume than the powerlifters
- Two things stand out to him 32 years later: *how incredibly and insanely strong these men were and how little they did*
  - They would come in, they would put their slippers on, put their suits on, chalk up, do a set, rest for what seemed like an hour, do another set, rest for what seemed like an hour, do another set, and leave
  - Admittedly, they were lifting cars
  - Peter remembers thinking, “*How can you do so little?*”
  - Now he understands “*Every single match has to go into burning for that flame*”

**Why powerlifters need recovery time**

- Andy agrees, “*You’re trying to put 1,000 pounds on your back. There’s just no room for a percentage of fatigue… The consequences are quite dire*.”
- Think about it this way: even though 1,000 pounds may represent their one-rep max, and you could do 250 pounds (your one rep max); this is not the same thing
  - Even though both are 100% of your one-rep max, there’s an absolute load that is on a physical human body that does not scale, and that’s the major difference
  - The connective tissue is not scaling linearly
- When they go do their heavy squat day or their deadlift day, if they can squat 1,000 pounds, their 70% day is squatting 700 lbs
  - And those are their light reps, their maintenance reps
- That load just takes so much more rest than when you do your 70% and you can come back tomorrow and squat and be fine, because it was 220 pounds
- That relativeness doesn’t scale
- Even if you’re talking about people that aren’t crazy strong (a 700-pound squatter); that’s still absurdly heavy
  - Their practice reps are 520 pounds

***That’s a ton of load on a human body, and that takes a lot to recover from***

## Are there consequences of powerlifting on long-term health? [1:02:00]

*If they have good mechanics, can they live a long, healthy life that is free of orthopedic disability in their final decade of life?*

- Scientifically, there is no data
- Anecdotally, “*I don’t think you would find a very highly competitive powerlifter who is under the illusion that this is great for their health*”
- Andy can name a ton of people who are world record holders (or close) who feel fine
- He can also name a ton of people who lift recreationally in the gym who are beat to hell
- You can find examples on both sides
- It depends on how they train
- Peter points out, “*Because we don’t have randomization, we don’t know if the people who are just doing great would be doing great no matter what they did, and the people who are all beat up to hell are going to be beat up regardless of what they do*”
- Andy doesn’t even count people like [Louie Simmons](https://en.wikipedia.org/wiki/Louie_Simmons) trained with a broken back
  - That’s not normal
- All the people trying to break world records are training hurt
  - The same is true about professional fighters, “*It’s a hurt sport*”
    - Here too, a bunch of them are wrecked for their whole life afterwards, and a bunch are okay
- If you push to extremes in any sport, you’re asking to not be able to use your shoulders [insert body part] for the rest of your life; it’s the extremity not the sport per se that is the issue

## Defining Olympic weightlifting: a test of power [1:04:30]

**Remind people what Olympic weightlifting is, and why they are among the most powerful athletes in the world**

- Olympic weightlifting is a competition of who can lift the most amount of weight one time, and there are two exercises:
  - [The snatch](https://youtu.be/0GIumbHwfh8)
  - [The clean and jerk](https://youtu.be/2qIVRgE5yRE) has two parts but it’s one exercise
- You add up the weight lifted in the snatch and the clean and jerk and the person with the highest total gets the goal medal
- It’s one rep, your best score in one repetition, and it’s the most amount of weight you can put on the bar
- Why this is not truly a maximum strength test (like powerlifting) is because both movements require you to take the bar from the ground and throw it over your head and catch it
  - There is a speed requirement
  - You can’t do it slowly, while you can deadlift/ bench/ squat slowly
- The snatch is the single highest power-producing exercise that has ever been studied
  - Nothing else produces more power per exercise than a snatch, and that’s because you have to take the bar from the ground and throw it over your head and try to catch it
  - You can’t do it slowly

***Power = strength x speed (or force x velocity)***

- If you did a speed squat and you jump in the air, the bar would smash you in the back of your neck and your head
- In a bench press, you can’t accelerate through the end of the range of motion, because the bar would leave you
  - You actually decelerate towards the end of a bench.
- Things like throwing a medicine ball are great, and they are very powerful, but they’re not as powerful as a snatch, because the load is so low (6, 8, or 20 lb ball)
- A snatch might be 100, 300 lbs; it’s a lot heavier so the force component is higher and the power output is higher

***Olympic weightlifter are the most powerful athletes because they’re doing the most powerful movements***

- If you were to look at the vertical jump height on these individuals, it’s absurd how high they can jump while still being exceptionally strong
- These are people who aren’t squatting 1,000 pounds, but at the same weight, they might be squatting seven or 800, 900 pounds
  - They’re not jumping as high as a basketball player, but they’re doing it with 600 pounds, 400 pounds, 500 pounds
  - They’re doing it at speed

***You could find higher jumpers, and you could find higher squatters, but Olympic weightlifters have this wonderful combination of being really strong and really fast, and that’s why they produce so much power***

## Training principles of Olympic weightlifting [1:07:45]

**Let’s say our avatar now is the middle-aged woman who was an athlete in college and wants to try a new sport (Olympic weightlifting). How should she train for strength in these movements?**

- She’s trained and not a stranger to exercise, but she’s never done Olympic weightlifting (these two movements)
- Going back to what was said earlier, to *optimize for strength,* they’re not doing 12 reps; they’re doing less than 5 reps
- You would first learn the movement with a light load, use a broomstick the first time you do a clean and jerk (or a snatch)
- There is a ton of technical work to learn these movements (we’re not going to get into this)
  - If you are simply snatching a PVC pipe, you’re not going to generate any strength; you’re not going to produce any power because the load is way to light
  - It’s super fast; it’s hard; it’s awkward
  - You can’t throw a PVC pipe over your head very fast
  - You can’t jerk it overhead
- Step 1: Build the technical skills
- Step 2: Then build strength doing, for example, a [front squat](https://youtu.be/7pyxT5hqmQY), a [push press](https://youtu.be/9-sGJjjMOpI), an [overhead press](https://youtu.be/0n86YPrgDBs) (stuff like that)
- You won’t have the technical ability to get heavy enough on the snatch and clean and jerk for quite some time because you’re going to be so limited by technique rather than strength or speed
  - That’s going to hold you back for a long time
  - This is why a lot of folks will not use these movements (which Andy thinks is a mistake)
- Andy puts this in perspective, “*If you were the classic personal trainer and you got a client coming in once a week, are you really going to invest three months in teaching them how to snatch before they actually burn any calories, gain any muscle or get stronger? It’s probably a losing endeavor.*”
- If someone is committed to invest 5 or 10 years, then it’s probably worthwhile because it’s total body

> “*It’s a deadlift mixed with a vertical jump, mixed with an overhead press and a catch, mixed with an overhead squat*”‒ Andy Galpin

- You’re jumping up and then down
- Then, you’re catching yourself; this requires balance and [proprioception](https://en.wikipedia.org/wiki/Proprioception)
- Your lats are going to go to keep your position in the back
- Your core has to be there for the overhead squat

***With the exception of horizontal pressing, it covers just about everything else, and so it’s a very economical, well-rounded movement***

- It’s peak [concentric](https://en.wikipedia.org/wiki/Muscle_contraction#Concentric_contraction) and [eccentric](https://peterattiamd.com/avoiding-injury-part-i-eccentric-strength/) because the amount of deceleration you have to do in that movement is insane
  - Whereas, in powerlifting, you don’t really get to test the eccentric phase to the same extent
    - There’s no landing, no absorption, no movement in space (which is very important for neural control and keeping your brain healthy

**Peter’s brother’s experience with Olympic weightlifting**

- In law school he became obsessed with setting his school record
  - He played football, and one of the tests they put the team through was the clean and jerk and he won
  - He weighed about 185 lbs and he lifted about twice his body weight
- What was interesting was how he trained
  - He would put 135 on the bar as the max amount and do that as perfectly and quickly as possible
    - He would film himself to make sure elbow/ bar travel was perfectly straight
  - Then he would do insanely heavy front squats and shrugs and all sorts of other accessory movements
  - On the day of the competition, he just went up
    - There was three and a half plates on the bar (350 lbs) and he just did it that one time and that was it
  - He never had trained above 135
- Andy would take a different training strategy
- Andy guesses he could probably front squat 450 at that time and back squat 500
  - He was probably limited by his technique rather than his strength

- It’s a smart idea to invest in technical proficiency
- You have technique and horsepower and he had way more horsepower than technique

**Example of Olympic weightlifting at the lower weight classes**

- A few people can manage triple their body weight
- Realize that this doesn’t scale with size
  - For example, [Lasha](https://en.wikipedia.org/wiki/Lasha_Talakhadze) (the best guy on the planet for the last 6-8 years), he lifts about 265 kilos (585 lbs) and probably weighs 350 lbs; he’s never going to double his body weight
  - But the guys who are 140 lbs can get to three times their body weight
- Andy was able to clean and jerk double his body weight and that got him 7th in the nation
  - Now it wouldn’t even get you to the competition (not even close)
  - National level competition as a male requires 2-2.5x bodyweight
  - To place internationally, it’s closer to 3x bodyweight

**How are we going to train this woman?**

*Peter’s starting point:*

- We’re not going to load her up on the clean and jerk and on the snatch
- She’s going to be using more weight than a PVC pipe and an empty bar
- She’s using 10-pound bumpers for most of the time until we she gets that working just right

*How are you training her strength so that she’s building up the horsepower to match the technique she’s building?*

- She’s using reps and sets based on the 3 to 5

*What exercises should she do to meet the needs of what she’s ultimately going to do when her technique is good enough?*

- Consider peak power production (the red line in the graph below)
  - Force is how much load is on the bar
  - Plot force against velocity
  - At some point, if the load is too light, but very, very heavy, it’s not powerful
  - At the opposite end of the spectrum, the same thing happens

![](https://peterattiamd.com/wp-content/uploads/2023/04/f9-andygalpin2.png)

**Figure 9. The relationship between force, velocity,and power**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Muscle_contraction#Force-velocity_relationships)

**So where is the crossover point where there is enough velocity and enough mass**?

- This is hyper-specific to the exercise
- Andy notes, “*The more trained you are, the more that curve gets shifted to the right, so you can produce more power at a higher load, relative load.*” (shown below)

![](https://peterattiamd.com/wp-content/uploads/2023/04/f10-andygalpin2.png)

**Figure 10. Shift in the force versus velocity curve after training**. Image credit: [Thirst Training](https://www.brandonsmitley.com/thirst-gym-terre-haute-the-strength-speed-continuum-and-force-velocity-curve-for-sports-performance/)

- For an exercise like a [bench press](https://youtu.be/5E1mXrOm9YE) or even a [tricep extension](https://www.youtube.com/watch?v=SLYwsE_W1eM), that’s probably going to happen at somewhere 30 to 40% of your one rep max
  - This is where you’ll have peak power
  - For example, if you can bench press 200 lbs and you want to train power on the bench press, you should probably put 80 pounds on the bar (30%)
- If you move to a more compound movement like a [squat](https://www.youtube.com/watch?v=7yFbBWTB8y0), instead of training at 30-40% of your peak, train at 40-50%
  - For example, if your max in the squat is 200 lbs, maybe put on 100 lbs
- If you go to a [clean and jerk](https://www.youtube.com/watch?v=2qIVRgE5yRE) (or a [snatch](https://www.youtube.com/watch?v=0GIumbHwfh8)), that  number gets much higher (80-90%)
  - A lot of folks won’t hit **peak power** in a snatch until they get to 90% of their max
  - If you do 90% of your 1RM on a bench press, you’re going to be moving super slow and you will not be producing any power
- This person is not going to get stronger from these exercises if there is a technical limitation
  - You may have to do a heavy [kettlebell swing](https://youtu.be/xWgl1rEiCeQ)
  - Maybe you want to do an [RDL](https://www.youtube.com/watch?v=0Sd1AZZ77aw&t=127s) (Roman deadlift), a [deadlift](https://www.youtube.com/watch?v=WAn7OPr2RdE), a [step-up](https://www.youtube.com/watch?v=KvNxrnM57Ds), or any number of exercises like that until they can get to a technical proficiency to where they can get 50, 60, 70% (or higher)
  - You’re not really going to be truly testing strength because you’re still going to be super limited by technique, and you’re not at the peak power yet
- Peter has never thought of peak power through the lens of how it varies so much by exercise
  - Maybe you’re going to hit peak power at 30-40% of your 1RM for the bench press, tricep press down, or bicep curl (a super low load)
  - If you did a leg press, squat or deadlift it might be 40-50% of your 1RM
  - This also depends on the person
- Once you move to something insanely technical, you’ve got to get close got 80-90% of the 1RM
  - This is because of the nature of the exercise
  - The triple extension allows you to explode ‒ it’s an explosive hip, knee, and ankle extension
  - This will solely be limited by skill
  - You’ve got to go heavy before you’re getting to peak power, let alone peak strength

## Tracking power output when training [1:17:15]

**Peter’s leg press machine**

- Last year, Peter swapped out his seated-leg press machine for a [Keiser](https://www.keiser.com/fitness-equipment/strength-training/air300-leg-press) one
  - It’s a pneumatic device that gives power by rep
- Peter uses power as the metric he’s training to
  - He’s able to see fall off and fatigue
- Now he’s going to pay more attention to when he hits peak power (is it 50% of his 1RM?)
  - In Andy’s experience, if you’re pretty trained it might be 60% 1RM

**Andy’s experience with a Keiser leg press machine**

- 20+ years ago, Andy spent 6-8 weeks training to hit the highest watt output he could (to optimize power output)
  - He didn’t care how many reps or sets it took
  - He would take a break and rest, then try again and go until he got a higher number

**Training with a velocity transducer**

- The [velocity transducer](https://gymaware.com/gymaware-rs/) is another way of training for strength or power that is velocity-based training
- Instead of worrying about the weight or the rep ranges, you’re simply trying to hit the largest power output possible
  - You do as many reps as you can (with breaks) and maximize power output

***You simply go up to peak power output instead of an arbitrary number of reps***

- Peter has a target meters/sec for a particular load, and when he can’t do that twice consecutively, the set is over
  - Sometimes the set ends at 5 and sometimes it end at 8

**Are you better off resting and coming back and doing it again faster and harder in three minutes than eeking out more slow reps?**

- Yes, there is strong science to support that
- [Bryan Mann](https://miamihurricanes.com/staff/dr-bryan-mann/) at the University of Miami has [done](https://pubmed.ncbi.nlm.nih.gov/?term=bryan+mann+velocity+training&sort=date) a ton of great stuff on velocity-based training

**There’s a training concept called cluster sets**

- Clusters have been shown to be highly effective for strength, power, and even hypertrophy
- Let’s say you were to do 5 repetitions in your set; you could do 5 reps with no breaks in between
- A **cluster set** says you’re going to do 1 rep then take a 5-20-second rest, then repeat the rep and rest a total of five times
  - You’re still doing 5 reps, but you might accumulate it
  - You have micro breaks
- Cluster sets are extremely effective because the quality of output (in power, velocity, etc.) is much higher
  - You reduce fatigue as compared to reps of 3, 4, or 5
  - You’ll get 5 first reps
  - It’s more important to get 5 higher quality reps

***In cluster sets, the aggregate quality, force output, and total achieved velocity is much higher so it’s very, very effective for pure strength; it may not be optimal for hypertrophy or other things***

- Olympic weightlifters have done this naturally for 50 years
  - When they do a set of triples of a clean (or a snatch), no one ever goes, boom, boom, boom
  - They drop it, reset, shake their hands, regrip, take a breath, reset
  - It takes 5-10 seconds before they do it again
  - Their 3 reps take a minute

**Would you advocate this if you’re trying to increase your deadlift?**

- “*Oh, yeah*”
- If you’re going for pure strength, and are going to do 5 reps on a deadlift, it would be better to do 5 ones with a 10-second break in between
- A little caveat, if your goal was not simply pure strength, but was to increase strength *and* accumulate a little muscular endurance, then you may not want to take that break
  - This is what Andy loves about coaching, everything matters ‒ the goal of what you’re trying to achieve matters

## Frequency of training for Olympic weightlifting [1:22:15]

**How often do you want this woman in the gym?**

- Because the load is low, you can do this every day
- You’re talking about a small number of reps, not to fatigue (light weight)
- There’s no reason why you couldn’t do some power training every day
  - This is no different than playing a sport every day (basketball)
- Keep the training high quality
- If you’re doing 2 fatigue sets of 20, with 5 seconds rest in between, then that’s a whole different thing
- Non-fatiguing sets are what you need to develop power and skill

> “*This is a very important point, for power and skill development, they need to be non-fatiguing. If you’re getting to fatigue, you’re not doing either one of those things.*”‒ Andy Galpin

- You can get to fatigue if you’re trying to produce a different adaptation
  - Such as maintenance of power through fatigue, but that’s not the same thing as improving peak power
  - You’re not going to improve your peak power by fatigue
- Power training/ power development sessions are going to be a little boring, and this is why they are not very popular
  - You’re not going to get a big sweat
  - You’re not going to throw up on the floor afterwards
- People will become more powerful but they won’t look any different, despite the fact that it is very high quality training

**Which type of athletes that are not weightlifters do you have doing these exercises?**

- Basically everyone
- It’s hard to pick a sport where power development is not important

## How post-activation potentiation (and the opposite) can improve power training and speed training [1:24:30]

- Peter recalls something he used to do that ties into both weightlifting and powerlifting
  - He really enjoyed doing it, and empirically, it seemed to work
  - It was 2-4 reps of a heavy deadlift, and it was super setted with a plyometric (jump or drop) in between
  - The empirical observation was both helped each other, and it seemed to make him stronger
    - Maybe that was psychological
    - There was a “bro science” belief that he was getting the muscle fiber ready for the heavy lift
- There is science to support this experience; you’re referring to a phenomenon called [post-activation potentiation](https://en.wikipedia.org/wiki/Complex_training)
- This is a very classic [Elwood Henneman](https://en.wikipedia.org/wiki/Elwood_Henneman) [size principle](https://pubmed.ncbi.nlm.nih.gov/15523522/#:~:text=Henneman's%20size%20principle%20relates%20the,of%20motor%20units%20during%20movement.); there was a series of publications about this in the mid-50s
- Fast-twitch and slow-twitch muscle fibers were discussed earlier
- There are things called [motor units](https://en.wikipedia.org/wiki/Motor_unit)
  - When a nerve comes down and goes into a muscle, it goes into a whole bunch of muscle fibers
  - That nerve and all the fibers collected together is called the motor unit, and they are all the same fiber type (all fast-twitch or all slow-twitch)
- When you do a low velocity movement, you use low threshold motor units, and these tend to be slow-twitch fibers
  - For example, if you go to scratch your eye, you don’t want to produce max force
- The best strategy is to start with the lowest force output humanly possible and then work your way up
- Muscle contraction follows an “all or none” principle
  - When a muscle contracts, it contracts with 100% effort
  - You can’t regulate it up or down; there’s no dimmer switch
- The only way you regulate force production is to increase (or decrease) the total amount of motor units that are activated
  - When you activate a motor unit, all the fibers get activated, and all of them contract at 100%
  - The motor units that are activated first are the smallest and weakest
- When you do a deadlift, because of the size principle and you’re requiring force production, you are activating **higher threshold motor units**
- Then when you put the barbell down, you go to do your jump, those are still engaged and activated
  - So now you can actually jump with more force and velocity
- The work of [Lee Brown](https://hhd.fullerton.edu/knes/facultystaff/LeeBrown.php) on this is legendary; he’s a Lifetime Achievement Award winner
- Training can also go the other way (this is fun)
- When it comes to **power training** or **speed training**, people think about resistance
  - For example if your sprinting and dragging a sled (or have a parachute on)
  - If you’re doing vertical jump training and you have bands that hold you down
  - Added resistance is fine for teaching your acceleration (or moving over inertia quickly), however, if you want to get fast, you want to practice moving faster than you can currently move
- Peter had a friend in college who was a sprinter and would do downhill sprints
  - A 40-yard dash down an inclined of 6%
    - Andy thinks 6% is pretty aggressive
    - Either way, it’s overspeed
  - Their legs were turning over at a speed they would not normally be used to turning over
- So instead of dragging a parachute, you turn around and have the bungee cord pull you a little bit
- Andy has a device in his lab that is a harness that comes down to you, and you can reduce your body weight by 5-20%
  - It’s great for vertical jump training, which they did with the volleyball team for one semester
  - This is the same as post-activation potentiation (PAP) just in reverse

***You’re learning to move faster than you could possible move, so then when you go to actually do your work, you move faster***

- For example, you’ve seen baseball players swing a bat before they go up to play, or they go up to their bat and put what’s called a donut on it (to add weight)
  - The bat feels heavy when you swing it with the donut on it; then, you take it off and your bat feels light and it’s awesome
- [Lee Brown](https://hhd.fullerton.edu/knes/facultystaff/LeeBrown.php) compared swinging a wiffle ball bat (super light, plastic bat) to swinging a baseball bat with a donut, and which one improved baseball bat velocity more
  - The wiffle ball bat actually improved baseball bat velocity more so than the donut did
- Using the donut is an example of PAP (post-activation potentiation), and it’s super effective, but an unloaded super fast swing is equally effective

***If you want to maximize velocity, you should play a little with both ends of the spectrum***

- You can do this with bands and chains
  - Take a heavy band that you deadlift with and put it underneath your lap and hook it to a thing above you to do assisted vertical jump training
- This is the reason why when Peter did deadlifts and plyo, he felt that combination helped both exercises
  - Plyo helped the deadlift because of the overspeed thing
  - This is called [complex training](https://en.wikipedia.org/wiki/Complex_training) (aka post-activation potentiation)
- If you’re going to do this, you need to stick within the same principles:
  - The total reps should still be 3-5
  - You could do 2 deadlifts and 3 vertical jumps, but don’t do 5 deadlifts and 5 vertical jumps (a set total of 10)
- You can do this all kinds of ways:
  - A [bench press](https://youtu.be/5E1mXrOm9YE) then [medicine ball shot put](https://youtu.be/ll49l_RMvzY) or rotational movements
- At the time, Peter thought why doesn’t a sprinter do a heavy set of 3 deadlifts before they hit the blocks
  - Andy points out that they do, when they can
  - You don’t see it often because of the logistics
  - Depending on the facility, they’ll be in the back doing deadlifts, then walk out, put on their spikes, and go
    - There’s a window that you have to do this in
    - You can’t do the deadlift then 1.5 hours later go and run and go faster

## The Strongman competition: more breadth of movement, strength, and stamina [1:32:00]

- The feats of a Strongman competition require a lot of stamina
- Peter’s favorite is tire flipping
  - There was a 450-lb tire at the gym he used to belong to, and how long it would take you to do 25 slips was a metric of your insane stamina
- Andy loves [farmer carries](https://www.youtube.com/watch?v=z7E_YU9P1jU); there’s tons of rope poles

***We are going from the highly specific powerlifter (where there are 3 exercises), to the weightlifter (where there are 2 exercises), to the Strongman where there is more breadth***

- You could argue that the Strongman is more functional, more versatile, and more engaging
- At the outset Andy said the three things that mattered most were specificity, specificity, and specificity

**When you’re dealing with something that has so many components, how do you wrap your mind around specificity versus generality?**

- Andy got into this because the Strongman was played on ESPN at three in the morning in the 90s
- There is still some specificity when you get into those competitions because they know which events they’re going to do
  - Someone who has optimized grip strength for holding atlas stones is not going to be the person who is optimized for the deadlift carry or overhead press
  - You’ll see people who win three straight events and they’ll get dead last in another one
    - CrossFit has a very similar feel; you’re tested in a bunch of different planes
  - If you’re great at deadlift, your probably going to be poor at pressing

***The way you win the Strongman (or woman) is how many reps you can do at a very heavy load; you’re not technically the “strongest” in the world***

- The Strongman is a global feat of strength, but it’s not to the same level of high precision
- If you were to take everyone from a strongwoman competition in the same weight class as everyone from an equivalent level of powerlifting competition, the squat would probably be higher on aggregate in the powerlifting competition
- However, if you asked the winner to see how many reps they could do at 95% max, the strongwoman would smash the powerlifter
- The Strongman takes extremely heavy loads and does them to fatigue
  - They do it a little bit safer; you generally don’t see a bench press to fatigue (or deadlift)
  - They do something like a car lift, and the reason is because you can actually load the bar a lot higher in the air
    - It becomes closer to a RDL (Roman deadlift)
    - When you take that knee cross out of it, it allows you to do a lot more reps
  - They do a farmer’s carry as heavy as possible and drop it when they’re done, to hedge in that direction
  - A snatch (or a clean and jerk) is way to risky; they do a log press overhead

> “*It’s still brutal, still insane. That’s why they do some funky stuff like that.*”‒ Andy Galpin

- For a tire flip, you’re never fully lifting a 450 lb thing off the ground
  - The first movement of the deadlift, it might be 250 lbs that you’re lifting up
  - Then by the time you’re pushing it, you’ve got the momentum helping you
  - It’s infinitely safer
  - Your cardiorespiratory and muscular fatigue hit almost at the same time
- Five to six years ago they started putting heart rate monitors on people in these competitions and broadcasting them
  - They’re pegged the whole time, at 180 (max heart rate); it’s insane
- This is one reason you could argue the Strongman is better for global health
  - It’s human movement
  - It’s varied
  - It requires stabilization and all kinds of random movements
  - It’s super heavy
  - You work to high levels of fatigue

## Training principles of Strongmen and advice for someone new to the Strongman competition [1:36:45]

**The next avatar ‒ how would you train a person who is new to this?**

- A guy who has never powerlifted, never weightlifted, never done a Strongman
- He goes to the gym and does a little bit of cardio and a little bit of strength training, but there’s never been specificity to the training
- He doesn’t have any injuries that we need to worry about
- Nothing is truly off limits, but he has no technique
  - He has no foundation of knowing what it’s like to deadlift at least twice his body weight
- He thinks the Strongman competition would be fun and it’s inline with his health goals
  - But he doesn’t want to get injured, and he wants to be able to do this for quite some time
- First, build a week of frequency and exercises you do throughout the week so you are not doing too many things too often in the same matter
  - For example, if you’re going to work on [farmer’s carries](https://www.youtube.com/watch?v=z7E_YU9P1jU) one day, you wouldn’t want to work on a movement like a deadlift the next day because your grip is going to be fatigued
  - The next day pick something like a [yolk walk](https://www.youtube.com/watch?v=zRsFkNPxaMM)
  - Be conscious of how many day in a row are you hinging or holding or pressing directly overhead

***The first step is to vary the movement patterns***

- In terms of repetition range, stick to 5-8 initially
  - In the beginning, it’s heavy and you’re practicing

***You want to practice perfect repetition; instead of going to a RER (or RPE), go to technical failure***

- For example, do a [goblet squat](https://www.youtube.com/watch?v=ubV_MaOsjDw) with a 100-150 lb sandbag (or medicine ball) in front of you
- Do [front squats](https://youtu.be/7pyxT5hqmQY)
- As soon as you break technical, you’re done

***That’s going to get this person a lot of fatigue, a lot of strength, but also keep them very safe, and they’re going to learn to hold technique/ hold position***

- If you start to get into bad positions in your lower back, you’re done; so **working to technical failure** is the way to go
  - This is also true for overhead pressing

**Comparing the avatar of the Strongman to powerlifting and weightlifting**

- You can do these exercises more frequently than the same avatar could in powerlifting because the movements are more varied
  - The recovery is going to be a little bit higher because you’re not locked in position and moving in just one plane, and this will allow you to do more volume
- You will get sore but there is not as much eccentric landing demand as there is in weightlifting

**Going back to the powerlifter and weightlifter, why would we also** ***not*** **force technical failure into the mix?**

- In Olympic weightlifting, if you have a break in position, you’re probably going to miss the lift
  - It’s self-limiting, especially when you get past a certain load
  - You could do 30% of your 1RM with very poor technique, but this becomes more self-limiting at higher loads
- The technical demands of something like a [bench press](https://www.youtube.com/watch?v=5E1mXrOm9YE) are fairly low
  - There are only a couple of joints that need to be taken care of
- When you do a [snatch](https://www.youtube.com/watch?v=0GIumbHwfh8), every joint has to be in the right spot or it can go wonky
  - A [deadlift](https://www.youtube.com/watch?v=WAn7OPr2RdE) is the same thing (just not as complicated)
- A squat is fairly complicated, and there are also variations that you’re going to do
  - A [box squat](https://www.youtube.com/watch?v=ZJrUiIprYVw) or [chair squat](https://www.youtube.com/watch?v=vVpojWs8lQg) is going to limit the range of motion
- Lastly, since the goal of powerlifting is to achieve a one-rep max, you’re actually not trying to achieve optimal range of motion
  - In fact, you go the opposite
  - ***Physics-wise, work = force x distance***
  - In maximizing force you want to minimize distance because this minimizes the amount of work you have to do
  - Powerlifters intentionally limit the range of motion
  - Powerlifters don’t maximize human strength, they maximize the score on the barbell

**What percentage of powerlifters deadlift with a traditional narrow grip versus a sumo?**

- Andy doesn’t know an actual number
- For Peter, sumo is more comfortable than a narrow grip
- Andy notes that [sumo](https://www.youtube.com/watch?v=GMQ5wsP9ui8) is easier on the low back
- The grip depends on three factors:
  - 1 – Shank to femur ratio
  - 2 – Femur to upper back
  - 3 – Arm length
  - 4 – Hip versus back strength; strong hips do well with sumo

**Peter’s takeaway ‒** ***the Strongman is training frequently; it’s highly varied; they’re doing more reps; they’re training to technical failure***

- The reason Andy brought up technical failure is because you’re doing a combination of high load and high fatigue
  - It’s too risky to break form

**How many hours a day is the Strongman training?**

- This is not the guy who’s driving around Walmart for two hours trying to find a parking spot
- This person is fit; they’re burning matches all day
- There is no science on this, because how do you quantify holding a 100 pound medicine ball in your chest and see how many steps you’re going to take?
  - In weightlifting, you can quantify how many reps you did over 70% of your 1RM, and there are two exercises, so it’s very easy
  - With the Strongman, how do you equate time?
  - How do you equate the fact that you did one exercise and you did it for 40 yards?
    - With the other exercise, you did it for seven reps, and Andy would give you a basic progression recommendation of 10%

**Andy’s advice for progression**

- Keep it below 10% progression per week
- Start lower than you think

> “*In general, regardless of physical exertion, if you increase your total volume by more than 10% per week, you tend to start getting into problems.*”‒ Andy Galpin

**Measuring progress in Strongman training is difficult**

- In lifting, you can keep a tally of sets and reps per body part
- How do you do that with a 100 lb medicine ball for 7 steps, versus a 50 lb medicine ball for 25 steps?
  - They both hurt about the same
- This is the problem exercise science has for comparing lifting to endurance
- Peter recalls that cycling uses what’s called the [TSS (Training Stress Score)](https://trainright.com/training-stress-score-what-is-tss-for-cycling/)
  - There is a chronic and acute TSS
  - As a cyclist, he used to take the date from his [power meter](https://www.bikeradar.com/advice/buyers-guides/best-power-meters/): maximum heart rate, FTP (Functional Threshold Power, which is the highest number of wattage average for 60 minutes), kilojoules of energy utilized, average power and normalized power (in watts)
  - With this data, the algorithms are so good at telling where you are in terms of overtraining/ undertraining
- If only there were some way you could get that out of more complicated movements
- Obviously, you can get heart rate and [heart rate variability (HRV)](https://en.wikipedia.org/wiki/Heart_rate_variability)
- You could probably get that out of ventilation, if there were a way to capture ventilatory rate
- Other than that, we’ just don’t have the metric for power
- Andy suggests looking at physiology
  - Heart rate would not be a great one

> “*Who cares if you’re at X amount of reps per week if your physiology is fantastic*”‒ Andy Galpin

- People who spend their career coaching in this area probably have a better answer
- Andy would look at physiology metrics
- One of the things Peter used to look at before we had HRV was resting heart rate in the morning and basically the willingness to train
  - It sounds silly, but it turns out to be very highly correlated with burnout
  - Andy agrees, “*It’s still the single best metric you can take*”
- Peter used a score of 0 to 3
- It ties in very tightly to HRV
- Resting heart rate is okay, but it’s too slow, and the magnitude of change is too little
  - HRV is much more sensitive
  - You’re not going to see a change in resting heart rate until you get far down the road, and you’re getting cooked
  - With HRV you can see in a matter of days, certainly within a week
- There are a number of ways you can assess mood and how much you want to train
  - Andy has done this with giant data sets
  - That number alone is going to run the same as HRV
  - There will be outliers day to day, but it will give you a pretty good sense

**Peter’s takeaway ‒** ***knowing how you feel the day of and listening is really important; if you do not feel like pushing yourself hard in the gym on a given day, that’s a really good sign that you shouldn’t***

- Give it until after the warmup phase before you make the decision and get on to the working sets
- Just because you feel crappy doesn’t mean you don’t exercise that day; it’s a question of how hard are you going to push that day
- Peter would argue, “*There’s no day you shouldn’t be doing something*”

**This is where autoregulation training becomes awesome**

- If you use a velocity transducer and you know that when your at 50% you’re typically 1 m/s (etc); knowing your metrics is a pretty good indicator if “this is not today”

## CrossFit: a combination of weightlifting movements, endurance, and circuit training [1:50:15]

- There is a pretty decent overlap between CrossFit and Strongman; these are events that take a really long time
- There are certain sets that can take 20 minutes that are metabolically as demanding as what most people could barely do in an hour

**Tell folks how CrossFit works**

- We’ll call it competitive circuit training
- One of the really cool things about sports is we get to invent new ones all the time and continue to test human capability
- CrossFit is a nice combination
  - There are some weightlifting movements
  - One of the competitions might be a one-rep max snatch
  - There is endurance; you might have to run/ cycle a marathon
  - You might see more circuit training, where you do as many rounds a you can in 10 minutes ‒ 20 [kettlebell swings](https://www.youtube.com/watch?v=xWgl1rEiCeQ), plus 3 [snatches](https://www.youtube.com/watch?v=0GIumbHwfh8), plus a [vertical jump](https://youtu.be/RgboWFzSUKo), plus 20 [pull-ups](https://youtu.be/NBOmFfctBWQ)
- The idea is you combine a bunch of these things, and every event gets scored (just like Strongman), and at then end of the competition, whoever has the highest amount of points wins
  - Just like the Strongman, it’s not a single, structured exercise, it’s a combination of many exercises
- Similar to weightlifting in tech, CrossFit uses barbell movements
  - Big, complex movements
- It’s similar to powerlifting in that sometimes max rep matters
- Compared to Strongman, the absolute loads are lower
- The winner of a Strongman competition might with with 5-15 reps
  - If it’s a log press, you’re not doing 100 reps
- The volume of reps in a CrossFit competition tends to be way higher
  - Sometimes it’s hundreds of repetitions per event
- Athletes in CrossFit are still very, very strong and powerful, but you won’t see anybody ever touch 600 lbs
  - Every Strongman is 600+ lbs; you might see 1,600 lbs
  - But you won’t see Strongman ever reach 65 reps in an exercise
- The avatar for a highly competitive male CrossFitter is 5’9” to 5’11”, 190-210 lbs
  - For the Strongman, it’s 6’2” to 6’6”, 330-400 lbs
- There are some weight classes in Strongman now ‒ big, medium, and little
- Gender and age are the only distinction you have in CrossFit
- In CrossFit, you’re going to get punished for being heavier in some of the endurance events and punished for being lighter in some of the strength events
  - There are also a lot of gymnastics-based movements (hanging and pulling), and you’re going to get hammered if you’re over 200 lbs and you have to do 100 pull-ups in 5 minutes

**The misconception about elite athletes in any of these categories**

- CrossFitters are way more cardiovascularly fit than Strongman, and certainly way more than powerlifters and weightlifters
- But you’re not going to find the average Crossfitter that has the same [VO2 max](https://en.wikipedia.org/wiki/VO2_max) as the average, equivalently high-level cyclist

***What you’re misrepresenting here is not that they have done something that we have never seen before, it’s the fact that they’re just phenomenal athletes***

- If you were to take a high-level cyclist, their peak power is astronomically high despite the fact that these are “pure endurance” athletes
  - The wattage they can kick out on a 20-second peak burst on a bike would torch anything you have ever seen
- Peter’s greatest regret in speaking about this stuff is that he has yet to come up with a way to explain what wattage feels like
  - People have an intuitive understanding of what 500 lbs feels like
    - You’ve been to Home Depot and picked up the 50 lb bag of salt and can say, “*Wow, deadlifting 500 pounds would be like picking up 10 of these at once.*”
- When [Bradley Wiggins](https://en.wikipedia.org/wiki/Bradley_Wiggins) absolutely smashed the one hour record (which is generally regarded as the most pain a human being can endure in any sport), he held 440 watts for one hour, crunched in a tuck position with his iliac vessels folded on top of each other
  - Peter adds, “*I can’t tell you what that’s like if you’ve never pedaled.*”
  - If you put the average person on a bike set to 440 watts, they’re going to be dead at 20 seconds
  - The average person might weigh 180 lbs, Bradley probably weighed 138 lbs (maybe 145)
  - Wiggins was tall (probably 6’1”), but he looked like a bean pole, and the force he could generate for 60 minutes is more than you could generate for 30 seconds
- Andy adds, 1,000 watts is a big, big number, but that wouldn’t be crazy for a cyclist to do in a 20-second burst
  - Further a cyclist could do that after riding for 6 hours at an average of 250 watts
  - Again, most people can’t hold 250 watts for 2 minutes

***This is not suggesting that cycling training is great for power development, instead world-caliber athletes are good at a lot of things***

- A highly power-trained person could kick out 1,200/ 1,300 watts for sure

> “*When you say these CrossFitters are a miracle, they’re not. They’re just so fit. They’re so strong. They’re unreal.*”‒ Andy Galpin

- Peter thinks what makes them special is, how good they are at so many things
  - They’re great generalists; there’s nothing they are the best at
  - The gymnast is better at gymnastics
  - The weightlifter is better at weightlifting
  - The powerlifter is better at powerlifting
  - The Strongman is better at Strongman
  - The endurance athlete is better at endurance
- You also hear the comment that they could do a CrossFit competition and then go do a weightlifting competition the next day
- Back in the original days, they would come up with all kinds of stuff to try to get [Rich Froning](https://en.wikipedia.org/wiki/Rich_Froning_Jr.) to lose; it didn’t matter, he smashed everything

***You can’t come up with enough accolades to describe how talented these people are…. The men, the women, what they can do is phenomenal***

## Learning from elite athletes, heart rate recovery, V02 max, and other metrics [1:58:45]

- Peter thinks it comes back to what Andy said at the outset, “*Ultimately specificity wins*”
- Peter wrote about this in his book ‒ when he was cycling, it was all he was doing
  - He was a one-dimensional athlete
  - His upper body was useless
  - He wasn’t even good at running, even though he had the engine
  - If he was sprinting, he couldn’t get his heart rate over 130 because he didn’t have the leg-pounding strength to cope with it
    - No lateral movement, no flexibility, no balance
  - There was no other dimension to it, other than turning pedals over quickly
  - Not to take anything away from the best cyclists in the world, they’re marvels of human physiology
    - But it’s super, super specific
- He thinks this is true for all the athletes they’re talking about
- Once you get into these Strongmen and CrossFit athletes though you start to see remarkable feats of strength and endurance across the great range
  - In some ways this is more impressive
- Think about elite marathon time; let’s call it 2 hours to make the math easy
  - Technically [Kipochoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge) did it once, unofficially
  - If you break that down, it’s a 4:40 mile, maybe even quicker (it’s insane)
  - Hardly anyone could hold that pace for a quarter of a mile
  - Break it down further, it’s a 65 second 400-meter dash or a 12 second 100-meter dash

> “*The best marathoners in the world would smash almost everyone you know in a 100-meter dash. They’re blazingly fast*.”‒ Andy Galpin

- The same is true for cycling, with [Bradley Wiggins](https://en.wikipedia.org/wiki/Bradley_Wiggins)
- The difference in running is most people can understand, they can remember back to high school gym class how hard it was to run a quarter mile in 66 seconds
- Andy tells people all the time to go run a 400-meter dash and see how long it takes them
  - They think they can do it in 60, then they come in at 85 seconds

***Don’t conflate world-class/ best we’ve ever know athletes to thinking these concepts are wrong, because we’re talking about general concepts***

**How is the CrossFit athlete able to balance the volume as they’re pushing the envelope between strength, power, and endurance?**

- We don’t have any science on this stuff
- Andy has never coached CrossFitters, but there are some really, really smart people coaching CrossFitters
- In general though, if you just look at physiology, **specificity** does matter
- If you’re going to **optimize for strength**, you could have one of two philosophies
  - 1 – We’re really strong, good at this stuff, and we recover well from it, so we’re going to keep doing more of these strength-type things (we’ll get in more total volume)
    - Maximize strength
  - 2 – We’re going to do a lot of strength because that’s our weakest part, and we’re going to try to bring our weakness up
    - Minimize your biggest limitation
  - Everyone does it differently
  - Andy doesn’t have any numbers on standard amount of volume these people do
- What is beautiful about CrossFit is you need to have a ton of baseline aerobic capacity
  - You need to have some peak power
  - You need to have some strength
  - You need to be highly anaerobic
  - You need to have real high recovery from anaerobic efforts
- The most fascinating thing is, how do you train for this?
  - Nobody had an answer
  - It’s just strategy
- The other strategy is just to hammer everyone and see who’s left

**What do we know about heart rate recovery as a model of fitness?**

- [Heart rate recovery](https://en.wikipedia.org/wiki/Heart_rate#Heart_rate_recovery) is a strong metric of fitness
- There are a number of places where you can get a VO2 max test done for around $100, and if they’re good, they’ll give you the 1-, 2-, and 3-minute heart rate recovery as well
  - You can glean a lot of insight from that

**What are the metrics we care about for the 30-, 60-, 120-second recovery?**

- 80% in 2 minutes
- Say you are at 200, after 2 minutes of recovery, you should be well below 160 beats
  - If your max was 200, then 160 would be 80%
  - This is a minimum
  - Although, there’s no reason you should be above 160, 2 minutes in
- That’s slower than Peter expected

*What is considered excellent?*

- 60%
- In the example of a max of 200, you would go down to 120 beats in 2 minutes (almost resting)
- If you’re above 80% after 2 minutes of recovery, sound the alarm ‒ this is a big problem; walk yourself down

**Do we care what an athlete’s maximum heart rate is? Or heart rate recovery? Or what they can do at their max heart rate?**

- Surprisingly, [VO2 max](https://en.wikipedia.org/wiki/VO2_max) is not correlated with speed
  - vVO2 max is (velocity at VO2 max)
- In running, vVO2 max matters more than VO2 max
- In cycling, VO2 max is not nearly as important a pVO2 max (power at VO2 max)
- When Peter was training in cycling, they were not looking at heart rate recovery, but he wonders if that was a metric he should have been paying more attention to
  - In addition to pVO2 max and [FTP](https://www.trainerroad.com/blog/what-ftp-really-means-to-cyclists/) and all those other metrics
- Andy can’t comment on cycling, he doesn’t know that literature
- In the running literature, there are 3 main components that are going to predict endurance
  - 1 – VO2 max
  - 2 – Running economy
  - 3 – Lactate threshold
  - VO2 max is only one of these
  - Any one of these, on the face of it is not going to get you anywhere, and all 3 of them are still not going to get you everywhere
- Andy predicts that movement economy on a bike is probably similar
  - It’s probably your power ratio
- Peter adds, [FTP](https://www.trainerroad.com/blog/what-ftp-really-means-to-cyclists/) to weight is important
- Which is efficiency, “*How far you can travel on a bike per push*”
- For Peter, that’s what makes cycling such a remarkable feat of engineering, “*It’s basically just machines*”
  - It depends on your functional threshold power (FTP) divided by how many kg you are
  - If you line up everybody at the beginning of the Tour de France and rank them in that order, that is the order they will finish
    - Barring an accident or a strategic blunder
- This is because **efficiency** on a bike is super high, whereas efficiency in human movement is around 20%
- Are you going to find max heart rate to be a predictor of performance?
  - No, with the exception of whether people stop way prior to hitting a max heart rate
  - The same is true for VO2 max, people stop before their actual max
- Andy has had a lot of high-level athletes, very fit championship fighters who have a max heart rate of 172-175
  - In UFC there are 5-minute rounds
  - They can cruise at 158 for a whole round, take a 1-minute rest and do that again
  - Their ability to hand on at 95-98% for minutes is amazing
- When most people get to 98%, they have seconds of life before they’re gasping for something
  - Andy includes himself in this and his max heart rate is well over 200

**Andy’s stats**

- If Andy does a VO2 max test and he’s lower than 1.3, he knows it was not a max text
  - Technically, you’re not supposed to get over 1.1, 1.35, 1.38
    - Those are not crazy numbers for him to hit
    - He just handles that stuff super well

*What’s your resting* [*RER (respiratory exchange ratio)*](https://en.wikipedia.org/wiki/Respiratory_exchange_ratio)*?*

- Typically, 0.75
- Those numbers are all over the place
- His CO2 tolerance is also very, very high (55 or 58; he’s never crossed 60)
  - His VO2 max is not particularly high relative to these things
- The problem is, when heart rate gets too high, you start limiting time to fill
  - Your preload is low and your stroke volume goes down
  - It’s not always the best thing to be super high
  - There are some other factors to pay attention to in terms of accuracy and measure
- Andy did a [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3544519/) in Sweden with cross-country skiers in their 80s and 90s
  - He talked about this [last time](https://peterattiamd.com/andygalpin/)
  - Their average max heartbeat at their age was 150, 148
  - They were lifelong athletes; these guys never got out of shape
  - They were world champions in the 40s and 50s and never stopped
  - Their VO2 maxes are probably still in the mid-30s
  - If Andy remembers correctly, one 92-year-old, his VO2 max was 38
  - Several of them age 86, 88 had a VO2 max of over 40
- Andy was in Stockholm doing this study, and he doesn’t speak Swedish and they didn’t speak English
  - They were in a hospital with cardiologists
  - During a VO2 max test, you’re yelling and encouraging, “*Go, go go*” while they are cycline
  - One finishes, he sat and took three breaths, then said he didn’t understand the instructions and wants to try again
  - He go up and started getting back on the bike in 15 seconds, ready to go
    - The cardiologist said, “*No*”

## Optimizing towards being a well-rounded athlete as opposed to a specialist [2:09:45]

- Peter thinks of all the athletes discussed, the CrossFit athlete in some ways is the most representative of our long-term goal
  - Not necessarily at that extreme, but in terms of being a generalist

**Is there anything that is off limits? How much of your time and energy is going into max rep powerlifting movements given that you need to do so much other stuff to build a base of endurance?**

- Let’s assume you’re **optimizing for being the most well-rounded athlete**, not a spike in one domain over another
- Excluding pre-existing injury
  - We’re not talking about someone with a labral injury who can’t do power cleans and snatches

***The number to aim for is 70, 20, 10***

- This is a number Andy got from his friend Kenny Kane who ran CrossFit LA (one of the original ones)
  - He’s in Santa Monica and still coaches
  - He doesn’t have a lot of CrossFit competitors
  - The avatar described is pretty much his client; people age 30-50
- 70% of the time you’re in the gym is for **practice**
  - You’re doing a full workout, but the core here is practicing technical proficiency with a little bit of fatigue
  - You’re getting better at hip hinging, breath mechanics, pressing overheat
  - Use fatigue and load to get better at something
  - 100% emphasis on quality without caring about the score
- 20% of the time, you’re going to **compete**
  - You’re going to try to get your best score on that workout
  - For example, in 10 minutes, how many rounds can you get to?
  - If you’re doing a box jung, you aiming for the most reps not jumping as high as you can every time
  - You’re doing the minimum amount of work to get up  and back down; trying to get the highest score
- 10% of the time, you’re basically going to **death**
  - “Balls to the wall”
  - You’re trying to get to death’s door as fast as you can and live in the suck
- Let’s say the average person is going to the gym 12 times **per month** (3x a week for 4 weeks)
  - 8 of those workouts (twice a week) will be focused on practicing
  - 3 of those workouts are competition ones
  - 1 of those workouts, you go absolutely nuts
    - You’re not holding back
    - You’re going to lay on the ground for an hour afterwards because it was just awful

**One big problem we see with people that also have real jobs, is how much time they spend in sympathetic drive**

- They end up just torching themselves
- It’s too much high intensity too often, and they don’t understand when to dial it back
- In this model, 2 days a week, you’re working out, blood pumping, feeling good; in recovery, you’re going to feel great
- Only 1 day a week are you going to push it harder
- Then only 1 of those days in 4 weeks are you going to push really, really, really hard
  - That’s enough for most people that have other life stressors
  - You’ll be able to recover from that
  - You’ll also feel that you’re getting something out of your training
- Peter is glad he brought up this point about the sympathetic drive
  - When he was 18, he was physiologically much stronger and fitter, but a big part of it was there was no other sympathetic drive
  - Anyone who’s got a teenager knows, they’re the singularly most selfish creatures on the face of the earth; they’re incapable of caring about anything that is not themselves
  - At 18, everything in his life revolved around his workouts
  - Everyday had 4 workouts in it
  - One day when he came home from school to do the 3rd of 4 workouts, he forgot his key and couldn’t get in the house
    - He smashed a window to break into the house to make sure he could do the workout
    - It didn’t strike him as a weird thing to do
    - He didn’t bother to clean it up, and was in the basement hammering the weights when his mom came home and thought there was a break-in
  - There was no other stress in his life; nothing else mattered other than training
  - It’s different when you’re 50 and all of a sudden, life is stressful

**Is there a way to quantify and help people think about that as it factors into the training load equation?**

- There’s a scientific name for it called [allostatic load or allostasis](https://en.wikipedia.org/wiki/Allostatic_load)
  - This refers to all stressors combined
- Andy has his own algorithm that he uses to factor in everything
  - He breaks it up into visible and hidden stressors
- **Visible stressors** are things you see or feel
  - For example, you know if you didn’t sleep well last night
  - You know if your thirsty
  - You know if you ate food that was not the best choice, alcohol, cigarettes, etc.
- **Hidden stressors** are things you won’t necessarily feel in the moment
  - For example, maybe your carbohydrate or protein ratio is off
  - Maybe you have some medical condition ‒ pathogen, micronutrient deficiency, excessive inflammation
  - You’re doing all the right things but your recovery sucks
- Andy’s algorithm scores all of these things and factors this into a training program
- Adaptation in the body happen because of stress, but that **stress bucket** can be overfilled
  - What you want to do is fill that bucket with the type of stress you want, and dump out as much of the stress that you don’t want
  - If you’re already pre-filled with other stuff, and then you add a little bit of training stress, you start overfilling this bucket

> “*You just want it filled with the right stresses that go in the right direction. Specificity, right? The more specific the stress can get, the more specific the outcome can get.*”‒ Andy Galpin

## What we can learn from the sprinters about speed, acceleration, peak velocity, and technique [2:17:45]

- Sprinters are insanely strong if you put them on a force plate treadmill
  - Peter has heard that [Usain Bolt](https://en.wikipedia.org/wiki/Usain_Bolt) hit at 4x his body weight
- This is highly technical; technique and efficiency really, really matter
- Force is not the real driver here, speed is
- You have to have absolute acceleration, and then you have peak velocity
- When Usain comes out of the gate, that’s **acceleration**, and he’s not particularly strong relative to other folks (his force production is not exceptionally high)
  - However, once he gets vertical, his **peak velocity** is outrageous, and he is able to maintain peak velocity
  - What really separates him from others is his ability to maintain peak velocity so much longer than anyone else
    - This made it look like he was passing everybody, but he wasn’t; they were just slowing down
- For other field sports, you have change of direction and agility
- There is a fallacy of thinking that an elite athlete is good at a lot of things
  - That doesn’t mean they are optimized for a lot of things
- They need to be strong because they have to overcome force for a 100- or 200-meter dash
  - There’s the acceleration piece
  - They have to have true elite speed, which is a function of how fast you can turn your feet over in running, as well as stride length
- When training for peak speed target strength and peak velocity
  - Use light resistance, 30% or less; lighter than training for power
  - To train peak velocity use normal or overspeed training

***Speed training and power training are almost identical***

- You can do them at a very high frequency
- You want to do complex movements
  - You don’t want to do isolation, single joint movements
- If you’re an elite sprinter, you’ve got to be careful of your hamstrings, etc.
- For the most part physiological fatigue is low
- It’s low volume, high quality
- You’re going lighter so you can move faster

**Are you saying that the running workout using a slight tag run, for example, can be done frequently?**

- Yes, there’s not fatigue really, no joint beat up
- This is in contrast to CrossFit training
  - CrossFit has the most systemic fatigue associated with it because you’re doing high-intensity stuff so often
  - CrossFit is whole muscle, cardiovascularly driven, there’s a massive endocrine response
  - Training for the other athletes discussed is pretty much localized
  - Strongman might have some systemic fatigue

**When we discussed the powerlifter/ weightlifter, we talked about the neurologic component of this, can you say a bit more about that?**

- In powerlifting, more in weightlifting, and certainly in true speed stuff with the sprinter, there is such a high component to neural activation
- We need to make sure that we’re optimize all the motor units we need
  - And in the case of speed, you have to do it in the right sequence
- Movement mechanics, being smooth, and having the **rhythm** to move fast is very, very challenging
- This is called **synchronization** ‒ you have to fire the right muscles in the right group, in the right order, throughout your gait while running
  - This is not necessary in powerlifting because everything is on maximally
  - You’ll commonly hear sprinters say, “*You got to be in the right rhythm*”
  - You might get faster without actually improving your velocity ability by just getting in better rhythm
  - This means learning what to fire, what to relax, so a joint can move, and then be ready to strike again, and again
    - It can be both autonomic and conscious
    - The idea would be to make this as subconscious as possible, so in the moment you’re relaxed and moving
    - Initially when you learn it, it’s going to be very conscious

**What is the most taxing workout that the sprinter is doing during the week?**

*What is the workout from which they need a recovery?*

- True peak speed stuff
- If you’re trying to train maximum speed, and you’re 5% slower tomorrow, then we’re not trying maximum speed anymore
- To hit a new peak velocity, the level of recovery has to be higher
  - It’s not that you’re super sore, generally you’re going to feel fine
  - But your numbers are 3% slower, and you know you’re not recovered enough

## A training plan for the “centenarian athlete” [2:24:30]

**Let’s now tie this all together for a totally different type of athlete:** ***the centenarian athlete***

- We’re not starting with people who were world-class Olympic cross-country skiers in their 20s who never stopped
- We’re talking about somebody in their 40s who has the epiphany that says, “*Wait a minute, it’s cool to be a powerlifter. It’s cool to be a weightlifter. It’s cool to be a CrossFitter, a Strongman, an elite runner, cyclist, swimmer, whatever, but I’m going to pick a different sport. I’m going to pick a sport where the optimization is around my ability to be as physically robust as possible in the last decade of my life, which means I want to be able to do a bunch of things that most people can’t even fathom when they’re 80 or 90 years old.*”
  - That means being able to run up an escalator if it’s broken, carrying luggage
  - Put a 25 lb bag in the overhead compartment of the airplane
  - Pick up a grandchild out of a crib
  - Play on the floor and stand up on your own with no issues
  - Go for a hike on rocky terrain and not slip and fall
  - These are all things you would do blindfolded today, but few people in the last decade of their life can do this
- One of the biggest trade-offs you have to make is optimizing against getting injured
  - Because the compounding effect of training is so strong that it’s rivaled only by the compounding effect of not training

> “*You will lose it way faster than you will gain it, and therefore, you could argue rule number one of what I’m proposing is, you can’t ever stop training*”‒ Peter Attia

**What would we take from training for each of these phenotypes into our centenarian decathlon?**

- Let’s work backwards, beginning with physiology
- There are 3 things you need to train, and you can mix and match from any of those areas
- 1 – High-quality functioning muscle
- 2 – Nervous system (peripheral and central), our motor control needs to be very, very astute
  - The distinction of the brain is important because if you go into something like powerlifting, the lack of variation and lack of range of motion is a problem
- 3 – Cardiopulmonary system needs to be high functioning

**Maintaining brain health**

- Andy mentions [Tommy Wood’s](https://www.peds.uw.edu/user/1778) [paper](https://www.mdpi.com/2073-4409/11/18/2789) on late-onset dementia
- One of the key components to maintaining brain function throughout life is [proprioceptive](https://en.wikipedia.org/wiki/Proprioception) innervation, so you need to be moving in space and learning
  - You need to have some physical activity that is uncontrolled
  - You don’t want to be moving up and down, same foot positions all the time
  - This could be an outdoor hike where you are engaging with the environment, and the steps are non-uniform,the terrain is slippy
  - It could be a sport such as surfing, badminton, etc.

***You need one physical activity in your plan that requires you to react to the world; this is the first thing that’s needed***

- Strongman probably checks that box a little, maybe not maximally
- Olympic weightlifting checks that box
- Running, sprinting checks that box
- Cycling probably wouldn’t check that box very well

**The second thing that’s needed is high force production**

- This preserves your nerves by asking them to do a lot of different things
- Tommy’s [paper](https://www.mdpi.com/2073-4409/11/18/2789) speaks to asking all the motor units to work

***Something throughout your week has to be high force production, > 80% of your max***

- This could be powerlifting, weightlifting, Strongman, CrossFit

**The cardiovascular system**

- 1 – It needs to be able to sustain consistent work output over a minimum of 30 minutes with no interval, no break (call this zone)
- Weightlifting does *not* check that, nor does powerlifting
- You might be able to do a 25-minute CrossFit workout with almost no dip, but you may actually need to integrate more classic stead-state stuff
- This might be an Air Bike, a sled push, a jog, a swim
- 2 – You need to get to max heart rate
- CrossFit, Strongman, powerlifting (if you go heavy enough) are all going to get you there
  - You can get blood pressures of 450/ 350 during a max deadlift, but this is probably not the place to start max heart rate training

**How many times a week do we think a person needs to experience their max heart rate for this athlete?**

- A minimum of once a week would take the systemic fatigue out of it
- Twice a week would be really, really good
- The same is true for the steady state piece, once a week is good and twice a week might be better
  - It depends on what you’re doing
  - If you’re doing a lot of long walking, you might want to hedge your bets
- 3 – Recovery from high-intensity exercise
- Being able to get your heart rate up high, come back down, regulate and go back up and then regulate yourself back down
- This could be done with CrossFit or Strongman

**Weekly plan to strengthen cardiovascular health and neurological health**

- 1 day a week playing an uncontrolled activity/ sport
- 1 day high-force
- 1 day max heart rate
- 1 day sustained heart rate
- Those could all be combined
  - There’s no reason you can do 10 minutes of pure strength training, then go play some pickleball, do max strength stuff for 10 minutes, do a CrossFit/ 20-minute AMRAP (as many reps as possible)
  - You can do this whole thing in 40 minutes

**Muscular health**

- The muscle needs to be able to do a handful of things
- It needs to be sufficiently strong
- It needs to be a sufficient size
  - There is some minimum requirement as we age

**Do you think about that from a standpoint of ALMI?**

- Peter holds patients to a very high standard, he wants them above the 75th percentile for [ALMI (appendicular lean mass index)](https://peterattiamd.com/ama40/)
  - You see a big step up in mortality benefit above that
- Andy thinks [FFMI (fat free mass index](https://ffmicalculator.org/)) is okay, if you get into the above average (or higher)
- The idea that too much muscle mass is detrimental to your health as you age is a giant misnomer

## Debunking some training and exercise myths [2:33:00]

**Peter still has 9 other topics that he wants to discuss that they will discuss in part 3**

- Such as, exploring the myth that strength is paradoxically harmful as you age; that strength athletes struggle with age
- Uncoupling of size and strength
  - Both are highly correlated with longevity
  - The literature suggests that strength trumps size
- One of the arguments that size does matter goes back to the non-structural component of muscle (the metabolic component)
  - We can never lose sight of the fact that muscle is our greatest glucose reservoir, and the metabolic benefits of having a huge glucose sink are enormous
    - This is a key component if you want to keep your inflammation low
- Muscular endurance is also important for walking up 15-20 steps
  - You need to be able to do something for 20 repetitions in a row
  - This is not going to be cardiovascularly limited, but limited by local muscular endurance and strength
  - When people are out of breath because they walked up a flight of stairs, they think, “*Wow, I’m so out of shape*”
    - No, you’re weak because what happened is every step was 85% of your one rep max, and you just did 12 steps at 85%
    - If you were stronger and that was 50%, you wouldn’t be out of breath
    - The strength to weight ratio factors into fatigue
- People think there is a J-shaped curve of too much muscle mass as you age being linked to higher mortality when in reality, it’s a U-shaped curve

## The “do nots” of training and tips for avoiding injury [2:34:15]

- They talked about some of the things you need to do for training, but also want to discuss some of the “do nots”
  - Peter does not want to see people getting injured
  - He wants to make sure there is no interruption of training
    - The older we get, anytime we have interruptions in training, the cost of regain is so high

**Exercise-induced injuries happen in a couple of ways**

- Rarely is muscle the problem
- The only problem you have with the cardiopulmonary system or cardiovascular system is systemic fatigue, and this is **systemic fatigue**
- So, if you’re not overdoing it globally, then you won’t feel rundown or get sick often
- Overdoing it globally can be associated with any number of hormone cascades
  - Out of whack cortisol, testosterone, estrogen
  - This affects mood, appetite, makes it difficult to sleep ‒ these are markers of systemic fatigue
- If you talk about your knee hurts, you threw out your back, your neck, etc. ‒ this is joint pain

***The only reason joints really get hurt is repetition over bad movement patterns***

> “*So as long as you’re moving well in those joints… then you can really do unlimited amounts of volume theoretically, until the point you hit systemic fatigue, because it’s not going to be muscle that’s going to be the problem.*”‒ Andy Galpin

- You will have some muscle strains, but this is not going to put you off for 3 months
  - Unless you tear something off the bone, tear connective tissue
- You need to move properly to keep connective tissue and joints integrated

***If you had a 40-year timeframe, Andy would invest heavily in understanding proper movement patterns, then he would load them very specifically***

- 1 – Make sure you can do the movement pattern perfectly with assistance
  - Do a squat with your hands under the rail; squat all the way down and up
  - Use a band for assistance
- 2 – Move on to [bodyweight only squat](https://youtu.be/m0GcZ24pK6k)
- 3 – Add a little bit of eccentric load; lower down in a full range of motion

**If you can do things eccentrically, you’re holding proper position**

- Andy doesn’t care what the load is, it could be your body weight
- You can control the descent of the push up and hold the proper position of shoulder, neck, low back, all the spine ‒ this is great; now fall on the floor, then start back at the beginning
- Once you’ve mastered it with two limbs, then you can look into doing it unilaterally
  - Can you do it great with your left side?
  - Can you do it great with your right side?
- Given enough time, volume, and repetition, we’re going to start seeing a weakness, which means we’re going to have a compensation movement
  - This is why all of the sudden your low back might start hurting, or your left knee, or your right ankle
  - Something was probably moving slightly wrong in one position (in either an unloaded or loaded exercise)

**Introduce load next, then speed**

- Once you master the movement, then you can introduce load
- Once you can do all those things with load, then you can add speed into the equation
  - Can you do these things in the exact same positions as fast as possible?

**Second to the last step is to add fatigue**

- When most people start a new workout, the majority of the way they progress is by adding volume
  - If someone hasn’t run in forever, they may start out by running 1 mile today and 1.5 miles tomorrow

***When you add volume on top of dysfunctional movement, what do you expect to happen in week 6?***

- Good form will allow you to move perfectly well both [eccentrically](https://peterattiamd.com/avoiding-injury-part-i-eccentric-strength/) and [concentrically](https://en.wikipedia.org/wiki/Muscle_contraction#Concentric_contraction)
- You want to be able to do it in both a bilateral and unilateral position
- You want to be able to do it with load
- You want to be able to go fast
- You want to go through a variety of movement positions ‒ overhead pressing, overhead pulling, horizontal pressing and pulling, lower body hinging, lower body pressing, rotational, unilateral support, diagonal

**Improving the cardiovascular system first is a good strategy**

- There is [data](https://journals.physiology.org/doi/full/10.1152/japplphysiol.01013.2012) to suggest that 45-minutes of steady state endurance training (such as cycling) before hypertrophy training (aka strength training) results in more muscle growth
- So being in good aerobic fitness is quite powerful and important, even if you’re trying to get muscle mass

**In that study, was it because the cycling trained group had a higher work capacity when they were doing the hypertrophy training?**

- Andy recalls that the total workload accomplished was the same, but he would have to look at this study again (he might be wrong)

**Injuries**

- One of the injuries Peter sees a lot is a [torn Achilles](https://en.wikipedia.org/wiki/Achilles_tendon_rupture)
  - This seems to happen to the athlete who has been inactive for a while, then he goes right back to that indoor soccer match and boom, it’s so loud you can hear it across the gym
- This occurs when you ask connective tissue (the Achilles tendon) to do maximum contraction on a hyper loaded eccentric stop and change when it’s never contracted more than 50% of it’s max for years
  - You’re going to tear something somewhere
  - It’s probably not going to be an [ACL](https://en.wikipedia.org/wiki/Anterior_cruciate_ligament_injury), the Achilles is going to go first
- In pro sports it’s the opposite, the Achilles is going to handle the load and the ACL will tear first
- This is easy to avoid with some tissue tolerance, which is a fancy way of saying expose that tissue to demand slowly, and slowly increase the demand over time
- One thing Peter finds is great for this is **warming up with some sort of jumping**
  - Especially as he is getting older
  - It’s multiplanar
  - It’s simple back and forth, side to side, and then one leg out
    - Like doing the clock, one o’clock, two o’clock, three o’clock, four o’clock, five o’clock, and by five and six o’clock, you’re actually having to spin yourself backwards, and you’re always coming back to the center of the clock, if that makes sense
  - These aren’t huge jumps
  - The goal is to introduce lower leg variability and tension with the tendons and connective tissue at unusual angles
- This is why Andy is now more of a proponent of running for health than he used to be
  - Initially he wa apprehensive because of the high rate of injury from running
  - But now he has changed his thoughts on that because a small amount of running is enough to keep tissue tolerance through most of the lower half
  - A few miles a week; a normal human should be able to run a mile
  - A little bit of sprinting in the straightaways is good too; do two laps and walk the corners
  - This will help you stay away from a lot of foot- and Achilles-related injuries

§

## Selected Links / Related Material

**Previous episode of** ***The Drive*** **with Andy Galpin**: [#239 ‒ The science of strength, muscle, and training for longevity | Andy Galpin, Ph.D. (PART I)](https://peterattiamd.com/andygalpin/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (January 23, 2023) | [0:45]

**Sarcoplasmic hypertrophy reported by Mike Roberts**: [Skeletal Muscle Protein Composition Adaptations to 10 Weeks of High-Load Resistance Training in Previously-Trained Males](https://www.frontiersin.org/articles/10.3389/fphys.2020.00259/full) | *Frontiers in Physiology* (C Vann et al. 2020) | [26:15]

**Hypertrophy is equal between 5 and 30 reps per set**:

- [Muscle hypertrophy and strength gains after resistance training with different volume-matched loads: a systematic review and meta-analysis](https://pubmed.ncbi.nlm.nih.gov/35015560/) | *Applied Physiology, Nutrition, & Metabolism* (L Carvalho et al. 2022) | [31:15]
- [Loading Recommendations for Muscle Strength, Hypertrophy, and Local Endurance: A Re-Examination of the Repetition Continuum](https://www.mdpi.com/2075-4663/9/2/32) | *Sports* (B Schoenfeld et al. 2021) | [31:15]
- [Effects of Low- vs. High-Load Resistance Training on Muscle Strength and Hypertrophy in Well-Trained Men](https://pubmed.ncbi.nlm.nih.gov/25853914/) | *Journal of Strength and Conditioning Research* (B Shoenfeld et al. 2015) | [31:15]

**Mike Roberts review showing changes in muscle protein gains over time**: [Sarcoplasmic Hypertrophy in Skeletal Muscle: A Scientific “Unicorn” or Resistance Training Adaptation?](https://www.frontiersin.org/articles/10.3389/fphys.2020.00816/full) | *Frontiers in Physiology* (M Roberts et al. 2020) | [32:30]

**Westside Barbell Louie Simmons form of conjugate training**:

- [The Conjugate Method](https://www.westside-barbell.com/blogs/the-blog/conjugate-system) | Louie Simmons, Westside Barbell (Oct 18, 2016) | [45:00]
- [Understanding the Standard Template](https://www.westside-barbell.com/blogs/the-blog/understanding-the-standard-template) | Burley Hawk, Westside Barbell (Aug 8, 2022) | [45:00]
- [Using the Conjugate System](https://www.westside-barbell.com/blogs/the-blog/using-the-conjugate-system) | Louie Simmons, Westside Barbell (Oct 18, 2016) | [45:00]

**Prelepin’s chart**: [Strength 101- Reverse Engineering with Prilepin’s Chart](https://powerathletehq.com/prilepins-chart/) | Cal Hinzman, Power Athlete (July 2014) |

**Andy’s study of life long skiers now over 80 years old**: [New records in aerobic power among octogenarian lifelong endurance athletes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3544519/) | *Journal of Applied Physiology* (S Trappe et al. 2013) | [2:08:30]

**Tommy Wood’s paper on late-onset dementia**: [Demand Coupling Drives Neurodegeneration: A Model of Age-Related Cognitive Decline and Dementia](https://www.mdpi.com/2073-4409/11/18/2789) | *Cells* (J turknett & T Wood 2022)| | [2:28:00]

**45 minutes of endurance training before resistance training enhances hypertrophy**: [Aerobic exercise does not compromise muscle hypertrophy response to short-term resistance training](https://journals.physiology.org/doi/full/10.1152/japplphysiol.01013.2012) | *Journal of Applied Physiology* (T Lundberg et al. 2013) | [2:40:00]

§

## People Mentioned

- [Michael (Mike) Roberts](https://auburn.edu/academic/education/ed/collegedirectory/profile_page.php?uid=mdr0024) (Professor of Kinesiology, Auburn University) [26:15]
- [Brad Schoenfeld](https://www.lehman.edu/academics/health-human-services-nursing/health-promotion-nutrition/fac-schoenfeld.php) (Professor of Exercise science, Lehman College) [31:00]
- [Stefi Cohen](https://www.hybridperformancemethod.com/steficohen) (25x world record holding powerlifter) [37:00]
- [AJ Roberts](https://www.westside-barbell.com/blogs/the-blog/a-j-roberts) (Powerlifter) [39:15]
- [Naim Suleymanoglu](https://www.greatestphysiques.com/male-physiques/naim-suleymanoglu/) (46 world recording holding weightlifting champion) [43:15]
- [Louie Simmons](https://en.wikipedia.org/wiki/Louie_Simmons) (powerlifter and coach for more than 50 years) [1:03:45]
- [Lasha Talakhadze](https://en.wikipedia.org/wiki/Lasha_Talakhadze) (two-time Olympic champion weightlifter and six-time world champion in the super heavyweight category) [1:13:00]
- [Bryan Mann](https://miamihurricanes.com/staff/dr-bryan-mann/) (Director of Olympic Performance Sports Science)
- [Elwood Henneman](https://en.wikipedia.org/wiki/Elwood_Henneman) (neurophysiologist who studied motor neurons) [1:25:45]
- [Lee Brown](https://hhd.fullerton.edu/knes/facultystaff/LeeBrown.php) (Professor of Kinesiology, California State University, Fullerton) [1:28:00, 1:29:30]
- [Bradley Wiggins](https://en.wikipedia.org/wiki/Bradley_Wiggins) (cycling legend, winner of both World and Olympic championships and the Tour de France) [1:55:30]
- [Rich Froning](https://en.wikipedia.org/wiki/Rich_Froning_Jr.) (professional CrossFit athlete, won “Fittest Man on Earth” four times) [1:58:30]
- [Eliud Kipchoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge) (Elite long-distance runner, holds the world record for fastest marathon) [1:59:45]
- [Usain Bolt](https://en.wikipedia.org/wiki/Usain_Bolt) (Elite sprinter, holds the world record for 100 meters, 200 meters, and 4 x 100 meters relay) [2:18:00]
- [Thomas Wood](https://www.peds.uw.edu/user/1778) (Research Assistant Professor of Pediatrics at UW Medicine) [2:28:00]

§

![](https://peterattiamd.com/wp-content/uploads/2023/04/bio-andygalpin2-500x500.png)

##### Andy Galpin, Ph.D.

Andy Galpin earned his undergraduate degree in Exercise Science at Linfield College where he played football and won a DIII National Championship. He earned his Master’s degree in Human Movement Sciences from the University of Memphis and his Ph.D. in Human Bioenergetics from Ball State University. Andy is a Professor of Kinesiology at California State University, Fullerton where he is also the Director for the Center for Sport Performance. He is an active member of the National Strength and Conditioning Association & American College of Sports Medicine. He serves on the advisory board of many private and non-profit companies in the area of human performance. He is the author of the best-selling book [*Unplugged*](https://www.amazon.com/Unplugged-Technology-Upgrade-Performance-Consciousness/dp/1628602619/ref=sr_1_2?crid=1JBAYTZDR5EIX&keywords=andy+galpin&qid=1671638199&sprefix=andy+galpin+%2Caps%2C89&sr=8-2)  and routinely speaks at conferences, clinics, and podcasts around the globe. Andy also works as a high performance coach and consultant to numerous professional athletes (MMA, Boxing, Wrestling, BJJ, MLB, NFL, etc.). [[CSU Fullerton](https://hhd.fullerton.edu/knes/facultystaff/AndyGalpin.php)]

Website: [andygalpin.com](https://www.andygalpin.com/)

Instagram: [@drandygalpin](https://www.instagram.com/drandygalpin/?hl=en)

Twitter: [@DrAndyGalpin](https://twitter.com/drandygalpin)