# #24 – Tom Dayspring, M.D., FACP, FNLA – Part V of V: Lp(a), inflammation, oxLDL, remnants, and more

**Source:** [https://peterattiamd.com/tomdayspring5/](https://peterattiamd.com/tomdayspring5/)

---

##### Check out our 5-part series with Thomas Dayspring, M.D., FACP, FNLA, a world-renowned expert in lipidology:

- *(October 15, 2018)* [Part I of V: An introduction to lipidology](/tomdayspring1/)
- *(October 16, 2018)* [Part II of V: Lipid metrics, lipid measurements, and cholesterol regulation](/tomdayspring2/)
- *(October 17, 2018)* [Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins](/tomdayspring3/)
- *(October 18, 2018)* [Part IV of V: statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain](/tomdayspring4/)
- *(October 19, 2018)* [Part V of V: Lp(a), inflammation, oxLDL, remnants, and more](/tomdayspring5/)
- *(September 21, 2020)* [**FOLLOW-UP:** The latest insights into cardiovascular disease and lipidology](/tomdayspring6/)

In this five-part series, Thomas Dayspring, M.D., FACP, FNLA, a world-renowned expert in lipidology, and one of Peter’s most important clinical mentors, shares his wealth of knowledge on the subject of lipids. In Part V, Peter and Tom talk about inflammation, endothelial health, and oxidative stress as they pertain to cardiovascular disease, and our attempts to monitor them using biomarkers. They also discuss a couple of very important risk factors that too few people (and doctors) know about. Tom closes the five-part series with a tragic story about his good friend that is likely all-too-common for many practicing physicians, that both haunts and motivates Dr. Dayspring to learn as much as he can about the number one killer in the United States.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/tomdayspring5/the_Drive_public.png)

Play

#24 - Tom Dayspring, M.D., FACP, FNLA – Part V of V: Lp(a), inflammation, oxLDL, remnants, and more

#24 - Tom Dayspring, M.D., FACP, FNLA – Part V of V: Lp(a), inflammation, oxLDL, remnants, and more

1x15s30s

0:001:29:39

We discuss:

- Lp(a) [2:30];
- Inflammation [17:15];
- Oxidative stress markers: Lp-PLA2 and oxLDL [20:45];
- Endothelial health markers: ADMA and SDMA [34:30];
- Remnants [43:45];
- Omega-3 fatty acids (EPA and DHA) and apoC-III [55:30];
- Red blood cells and cholesterol transport [1:07:45];
- Tom’s friend Earl [1:10:00];
- Peter’s friend JP [1:18:15]; and
- More.

§

## Show Notes

## Lp(a) [2:30]

Peter Attia: So, let’s go from the statin back to the PCSK9. This will be a good way to dovetail, niacin, statins, and PCSK9 inhibitors. What lipoprotein have we not discussed today that would tie in a discussion of those three? Well the astute listener realizes, it’s our good friend Lp(a). Alright, why do I bring this up? So Lp(a), there are some people who still argue, “Hey, niacin makes sense because it lowers Lp(a).” I’m going to save everybody on this podcast the brain damage of listening to us discuss that for the next 20 minutes and just bypass us to the more interesting question, which is, “Why don’t statins lower Lp(a)?”

Tom Dayspring: Well, first of all, we need a better understanding of Lp(a) clearance. I’m personally of the belief that it is the LDL receptor ([Romagnuolo et al., 2015](https://www.ncbi.nlm.nih.gov/pubmed/25778403)). There is a plasminogen receptor that could clear some things, and there are macrophage receptors that, depending on what else is going on, might internalize some Lp(a) and get rid of it that way. But it’s the LDL receptor that clears it.

Peter Attia: Okay, now let’s pause for one second, because I realize even though we’ve already [done an entire podcast on what is Lp(a)](https://peterattiamd.com/lpa/), there’s someone listening to this who hasn’t heard it. You’ll go back and listen to it, I’m sure, I’m going to do future podcasts where I interview the world’s expert on the topic [Sam Tsimikas]. But Tom, can you give in two minutes a description of what Lp(a) is?

Tom Dayspring: Yeah, it’s an LDL-like particle which is adhering to another apoprotein that shouldn’t be there, and it’s called apoprotein little a [apoprotein(a)]. And you must pronounce it as “little-a,” that means small case rather than capital A. Lipoprotein capital A is apoprotein A-I, that’s the main apoprotein on an HDL particle (apoA-I). So if you tell me you’ve got lipoprotein-a, how do I know, are you talking about HDL particles or are you talking about little-a, which clearly identifies to me this potentially pathogenic, atherogenic LDL particle. So use the correct terminology with everything. And [Peter’s got that nice podcast on it](https://peterattiamd.com/lpa/), are metrics of, is that present in you. Most labs are running Lp(a) mass, which is the weight in a deciliter of plasma, the weight of all of your LDL particles, everything that’s in them. Their triglycerides, their cholesteryl ester, their phospholipids (Figures 1-8).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-127.png)

**Figure 1. Lp(a) particle clearance: apo(a) or Lp(a) can be cleared by plasminogen receptors or LDL receptors.** Since PCSK9 inhibitors significantly increase the number of LDL receptors compared to statins, PCSK9i are more efficacious at reducing Lp(a) concentrations.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-129.png)

**Figure 2. An Lp(a) particle is an LDL-like particle to which an additional apolipoprotein, called “little a” is attached to the apoB moiety of LDL.** Apoprotein(a) consists of protein loops called kringles (Types IV and V). Type 4 consists of ten subtypes numbered 1-10 and subtype 2 has a variable number of subunits (called copies). In graphic above KIV-2 is colored green. IV-subtype 1 is red, V-subtypes 3-10 blue and KV yellow. The LDL particle shown above, like the two Lp(a) particles depicted, has apoB-100 but no apolipoprotein(a) attached.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-131.png)

**Figure 3. The protein loops on many coagulation-related proteins are called kringles.** Apoprotein(a) consists of protein loops called kringles (Types IV and V) whereas Plasminogen has five (I-V). In apolipoprotein (a) Type 4 consists of ten subtypes numbered 1-10 and subtype 2 has a variable number of subunits (called copies).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-133.png)

**Figure 4. The mass of Lp(a) particles can vary considerably due to variable MW of apo(a) and the very variable content of the other molecular species in LDL particles (phospholipids, free cholesterol, cholesteryl ester, triglycerides, other apoproteins, etc).**

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-135.png)

**Figure 5. Distribution of LDLs and LP(a) by density.**

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-137.png)

**Figure 6. Plasminogen and apoprotein(a) structure.**

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-139.png)

**Figure 7. Lp(a)-like blood types are inherited from both parents in a “co-dominant” fashion.**

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-140.png)

**Figure 8. Lp(a)-P vs Lp(a) mass concentrations.** Because one of the contributors to Lp(a) mass is the molecular weight of apoprotein(a), part of the Lp(a) macromolecular structure, there can be discordance between Lp(a) mass and Lp(a)-P.

Peter Attia: Meaning any lipoprotein that is carrying an apolipoprotein(a). You weigh the entirety.

Tom Dayspring: All of the LDL density. so you’re weighing everything, you’re not weighing apolipoprotein(a), you’re not measuring apolipoprotein(a), per se. Yes, that has a molecular weight, but the molecular weight of apoB is way higher than the molecular weight of apoprotein(a). But you’re measuring that, too, when you do an Lp(a) mass.

Peter Attia: But, the molecular weight of apoB is known, because it’s pretty much the same. Whereas the molecular weight of apo(a) is variable.

Tom Dayspring: It’s very variable, so that’s another reason Lp(a) mass becomes a useless metric. And how do I know how many cholesterol, triglyceride, phospholipid, 10,000 other lipid moieties, other proteins are on that particle? I don’t. And you have heterogeneous mixtures of particles that would have variable amounts of all of those constituents. So you can see there’s going to be a weakness to measuring Lp(a) mass. Now, if it’s really high, you’ve probably got too many Lp(a) particles. But since there’s almost no more debate that the best metric for our LDL particles is low density lipoprotein particle number, there’s no debate among those who will truly understand that HDL particles numbers, your best available metric on quantifying a number. And that is a better metric than guessing at using HDL cholesterol or LDL cholesterol. Wouldn’t you rather have a really nice finite count? If Lp(a) particles are dangerous, wouldn’t you like to have a excellent, accurate concentration of them?

Tom Dayspring: Well, the only way you can do that nowadays, NMR provides those other HDLs, and NMR cannot assay Lp(a) particles, because NMR assays *lipid* content of particles. Not *protein* content. So the only way I can give you a Lp(a) particle count is I have to separate all lipoproteins electrophoretically, and you’ll see little bumps on the electrophoretogram. VLDLs congregate here, LDLs congregate here, HDLs congregate here. And what’s that little bump that is in this person but it’s not in that person? Oh, that’s Lp(a), because that’s due to its surface charge, where it migrates between the cathode and the anode, and the gel that you separate them on.

Tom Dayspring: So if I then take that little Lp(a) hump and I immunostain it with an antibody that bonds to apoB (Figure 9)-

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-142.png)

**Figure 9. Electrophoretic separation of lipoproteins.** Immunofixation in the Lp(a) distribution enables determination of Lp(a)-apoB [there is one apoB molecule per Lp(a) particle].

Peter Attia: You’ve just counted the number of particles.

Tom Dayspring: I’ve just counted the number of particles that are in the Lp(a) distribution range. I theoretically should not call that an Lp(a) particle count, I should call it Lp(a)-apoB.

Tom Dayspring: It’s too much of a mouthful, it doesn’t fit on a request form. So of course it’s abbreviated, Lp(a) dash p. And to me, the downside to that is most people think it’s an NMR measurement, which it absolutely is not. Basically if you want that metric, and we already announced I do work for True Health Diagnostics, I was working with a different lab before that, the lab that actually did the development of the Lp(a)-apoB assay. Which True Health absorbed and got proprietary rights to when they did it. So that’s it. And believe it or not, there are people who are going to have discordance with Lp(a) mass, the weight of the whole kit and caboodle, versus the number of the LDL particle counts. In general they correlate, but if you really want to know.

Tom Dayspring: And also I find it useful, at least those of you who are doing LDL-P by NMR, you have your total LDL particle count. But what does that really include? It includes LDLs that don’t have apo(a) attached, it includes that LDLs that do have apo(a) attached. Now I throw a statin at you, and we started to talk about this, that statin is not going to budge your Lp(a) particle count at all. But the statin is going to dramatically lower your LDLs that don’t have apo(a) attached to it. So your LDL total particle count will go down a little bit, but part of that is your Lp(a) particle count. But this shows you you are getting benefit when you give a statin to somebody with high Lp(a).

Peter Attia: Yeah, you’re going to have to go after residual risk. And one of the best examples I saw of this was an unusual case where a guy had an LDL particle of 1600-ish nanomole per liter, but he had an Lp(a) of 600 nanomole per liter. So, even though it’s an apples and oranges assay, directionally speaking he’s got 600 [nanomoles of] Lp(a) particles. And a thousand nanomoles of non-Lp(a)’s. But when you give him that statin, you’re really only targeting the thousand.

Tom Dayspring: Correct.

Peter Attia: And so you’ll be surprised at the lack of response you might see, because you’re not getting to target those 600 [nanomoles].

Tom Dayspring: No, but you’ll still get your 30, 40, yeah, but your total LDL-P may still be higher than you wish it to be, and unfortunately that is Lp(a) particles. Then you can get into the theoretical discussion right now if I could get rid of them, and basically the only way you can do that now is the maybe try niacin, which is weak lowering of 20 percent, or PCSK9 inhibitor.

Peter Attia: Seems like 30 to 50 percent.

Tom Dayspring: Well, it would be an individual response. It’s in that range.

Tom Dayspring: So if somebody could at least afford that drug, you can’t get it covered by a third party because they don’t have that indication to help you manage Lp(a) patients. That’ll never come, because could I ever prove to anybody that the PCSK9 inhibitor, because it’s lowering Lp(a) is reducing events? No. Because they’re going to turn around and say, “Well, it’s event reduction, they’re just getting rid of the remnants and the LDL particles, has nothing to do with lowering Lp(a).” And how would you argue against that? We need a drug that only lowers apo(a) or Lp(a), and does nothing to LDL particles, and that drug is under investigation right now. It’s an apo(a) synthesis inhibitor, where your liver’s going to stop making the vast quantities of apo(a) that these people who genetically inherit that propensity.

Peter Attia: This is courtesy Isis [i.e., Ionis/AKCEA].

Tom Dayspring: Yeah. Let’s not hold our hold our breath. So until then. Are there people in the lipidology world who would say, “Tom, until then, I’m going to continue to use niacin, because lowering it has to work.” I been around too long, these things saying it lowers this and lowers that, and they don’t work. So, is niacin going to have the same toxicity that I think it has in other people in Lp(a)? I don’t know. But if you want to use that because you want to make a patient happy because you’re improving some metric, be my guest. I would not, I know many lipidologists who would not. But there are ones, and look, Sam Tsimikas is probably the world authority on this, and Sam uses niacin in his practice.

Tom Dayspring: And I hope Peter has him on one day with a podcast. He would tell you, “Until we get our data on these other drugs, I’ll try and lower it a little bit.” If nothing else, he’ll say I’m lowering apoB a little bit, too, and I don’t know if it matters, but I’m raising whatever HDL metric. By the way, although fibrates are probably our best available drug now to raise HDL particle count (HDL-P), niacin, which blows away fibrates on raising [HDL-C], does nothing to HDL particle counts. I didn’t mention that before. Because niacin makes the HDLs bigger.

Peter Attia: I was just about to say, that could actually suggest it’s worsening LDL and HDL function.

Tom Dayspring: Yeah, you’re right. But the niacin people will convince you that the big HDLs are protective, it’s [not true], and the small HDLs are harmful. Whereas VA-HIT has data that are opposite.

Tom Dayspring: Because the lipid-poor HDLs are the ones that can accept the most lipidation.

Peter Attia: Ones that can go out and do the work.

Tom Dayspring: You know, you’re never going to have definitive answers on any of that, but yeah there’s a lot of BS around.

Peter Attia: So, what’s the best explanation for why a statin, which causes the liver to upregulate LDL receptors, does not lower Lp(a)? Whereas a PCSK9 inhibitor, which also net results in more, or longer, transiency of LDL receptors, seems to lower Lp(a) (Figure 1). Even though that’s not its primary objective.

Tom Dayspring: And by the way the data certainly tells us now that the main determinant of Lp(a) mass or Lp(a) particle concentration, is apo(a) production in the liver, not clearance. So until we can really inhibit production of apo(a), who knows what you’re doing. But until then, how do LDL receptors clear these particles? Well, earlier I think I mentioned that LDL receptors looking for apo(a), for a section of the apoB that it can latch onto. There’s a very specific area on the apoB protein on any of the apoB particles that, because of surface charges, will bind to a specific part of the LDL receptor. That area on [apolipoprotein B] is called the LDL receptor binding domain.

Tom Dayspring: So if, here comes an LDL particle, and that domain is sticking right out, it’ll stick right to any expressed LDL receptor. But what if there’s something camouflaging the LDL receptor binding domain on apoB? Such as, an interloper like apo(a). I could see where that could slow the clearance of an Lp(a) particle, because it’s not going to bind as rapidly and avidly to an LDL receptor. So most of these people have way too many LDL particles, we express whatever LDL [receptors] we want. We try and express more with a statin, what are they [i.e., receptors] going to grab first? The LDL particles that don’t have apo(a) attached. And only then will they maybe then start even grabbing apo(a) particles.

Tom Dayspring: Do we all really have enough LDL receptors? Most of us, for a variety of reasons, do not. Other things retard the clearance, too. The apoC-III I talked about, other proteins that may be affecting clearance, too. So there are just other factors at play. But right now, my guess is apo(a) is affecting totally efficacious binding to an Lp(a) particle. It’s camouflaging the LDL receptor binding domain on apoB. And therefore, I better learn how to inhibit synthesis of it.

Peter Attia: So Sam will obviously, hopefully we do get Sam on the show and we’ll talk about this, but this is basically going after the jugular issue, which is you inhibit the synthesis of apo(a).

Tom Dayspring: Yeah. And hopefully you do that. The million dollar question has always been why do we even have apo(a) to begin with? Did it ever serve some physiologic function, or is it important in any other aspect of human life? I guess we’ll know it if we eliminate it and there’s some bad outcomes in that trial. And obviously, it absolutely will be looked at for every safety aspect anybody can ever think of right now as they’re developing that drug. So right now, I don’t think there’s anything they’re worried about. Sam might know more than I. But yeah, if we can reduce statin, I don’t know if we can shut it down completely, but he can drastically lower apo(a) and Lp(a) levels.

Tom Dayspring: You know, everybody thinks you either have it or you don’t, there’s a lot of people who have what’s considered a physiologic or non-adversarial concentration of Lp(a) in their system. You don’t have to make it go to zero, where risk is concerned. In fact, the only people that are ever going to study this drug is people like you just mentioned, people who have an Lp(a) mass or particle count up in that [very high] range (Figure 10). They’re not going to take people with borderline Lp(a)’s and risk a clinical trial on them. Just like the first statin trials were done in sort of FH type people.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-144.png)

**Figure 10. Lp(a) particle number is determined using an Lp(a)-apoB assay (it is not measured using NMR).** The NMR-determined total LDL-P is actually the sum of Lp(a) particles plus LDL particles that do not contain apo(a). Statins very effectively reduce total LDL-P by enhancing clearance of the LDLs that do not contain apo(a). However, LDLs with apo(a) attached [Lp(a)-particles] are not as readily cleared. So even though statins do not lower Lp(a)-P, they do lower total LDL-P.

Peter Attia: Yeah, they’re enrolling for phase three on that trial, aren’t they?

Tom Dayspring: Mm-hmm (affirmative).

Peter Attia: Is it secondary prevention or primary prevention?

Tom Dayspring: I’m pretty sure it’s secondary prevention. I remember there is some data in the apheresis world, that if you pull out Lp(a) particles, they’re not randomized blinded trials, because how would you do that with apheresis? Apheresis, for the non-physician, it’s a dialysis where you take the blood out, you get rid of the LDL particles, and you give the residual blood back. And for at least a week or two they have less. But there’s so many other things you’re clearing, the regular LDLs, all sorts of rheological things, all sorts of other hyperosmotic proteins and things that who knows why apheresis really works.

## Inflammation [17:15]

Peter Attia: I don’t want to get us too far off our main theme of lipidology, but because they’re both quite recent, let’s just really, really briefly talk about two other interesting drug trials which look at a completely different component of the atherosclerotic mechanism pathway, which is the inflammatory pathway ([Ridker and Lüscher, 2014](https://www.ncbi.nlm.nih.gov/pubmed/24864079)). So there was an agonist to IL-1, I believe, was it IL1 or IL6?

Tom Dayspring: IL1.

Peter Attia: And then there was also a trial that looked at using a low dose of methotrexate ([Mangoni et al., 2017](https://journals.sagepub.com/doi/full/10.1177/1179559X17741289)).

Tom Dayspring: Which is still ongoing, there was some preliminary words that this is looking good, but it’s not been definitively released.

Peter Attia: That’s right, we won’t know until the fall.

Tom Dayspring: But there is the theory, this, “Hey, reduce inflammation and you will certainly help vascular health in capacities maybe even that have nothing to do with lipids.” And so, what’s a great anti-inflammatory drug? Well, we’ve been using low dose methotrexate in people with inflammatory disorders without a lot of toxicity for a long time, rheumatoid arthritis, etc. psoriasis, very powerful anti-inflammatory colchicine ([clinicaltrials.gov](https://clinicaltrials.gov/ct2/show/NCT02551094)), big outcome trial undergoing with that. I believe within the next year we’re going to have data on both of those trials.

Tom Dayspring: And the problem, this IL-1 inhibitor that Peter talks about, which has already published nice outcome data ([Ridker et al., 2017](https://www.nejm.org/doi/full/10.1056/NEJMoa1707914)) by inhibiting that, but it’s a 30,000 dollar drug. And there was downside to it, because by you seriously inhibiting the inflammatory system, there was a slight increase in cancers in some people. You’re immunological system has uses in the body, so you better be careful how much you knock it out. Because of course, because of that downside, it will never get an indication to, for me and you to use it. Again, if you’re some multi-billionaire.

Tom Dayspring: It’s already been approved, for certain rare inflammatory conditions ([ILARIS, 2016](https://www.accessdata.fda.gov/drugsatfda_docs/label/2016/BLA125319_858687lbl.pdf)), you can use it.

Peter Attia: I think the bigger issue is really as more and more of these drugs become available, hopefully it leads to a more and more personalized type of intervention where if you’ve got somebody who’s walking around with a low C-reactive protein (CRP) and a low fibrinogen, and their issue is elevated LDL-P, I don’t see why you’d want to use an IL-1 antagonist on that patient.

Tom Dayspring: No, clearly not.

Peter Attia: So, it comes down to basically stratification of what’s the driver. Again, this comes back to this idea of necessary but not sufficient, sufficient but not necessary, neither necessary nor sufficient. Inflammation is necessary, but not sufficient. You do need an inflammatory response, but you can have an inflammatory response and that by itself doesn’t necessarily-

Tom Dayspring: No, a certain degree of inflammation is critical for you to get rid of certain pathologies, so you never want to stop the immunological system.

Tom Dayspring: So, look I believe like Peter does, these are multifactorial diseases. We’ve spent a lot of time on apoB and LDL, but there are many other contributors that go into this. So I believe the better we can evaluate using biomarkers, the better we can identify many of the known existing pathologies. I’m sure there’s many we don’t fully understand yet. And then, perhaps we can better individualize our therapeutic suggestions to these people and know what we have to do, both nutritionally and pharmacologically, if that’s necessary to normalize whatever you’re trying to normalize. It’s a complex world out there and you got to look at a lot of things.

## Oxidative stress markers: Lp-PLA2 and oxLDL [20:45]

Peter Attia: So we’ve already discussed many biomarkers on the lipid front, and we’ve alluded to some of the biomarkers on the inflammatory side, C-reactive protein, fibrinogen. What are some other biomarkers that you find helpful, as far as understanding even more diffusely endothelial dysfunction or other markers of oxidized states that can give us more of an indication and say, “Look, you might have two people with the same degree of dyslipidemia, but one has a greater burden of oxidation going on than the other.” Which would be presumably worse.

Tom Dayspring: Presumably, yes, and the problem is going to be when you even start expanding. I can throw some markers at you that you might want to measure that would tell you there’s a pro-oxidative state going on, if your mission is to reduce atherothrombotic events. Trials that, “Oh, yeah if we improve this oxidative marker, that oxidative matter, people do better.” They’ve never, ever, been adjusted for apoB or LDL particle count. So, even though you may show some nice data on them, if you really just normalize apoB and LDL particle counts, would it even matter? I mean, and don’t tell me what common sense suggests, and look, I’m all for it. I use oxidative markers now mostly to try and convince people to do certain nutritional therapies, rather than, “I got a wonderful drug for you to reduce inflammation.” “cause right now, I really don’t. I know if I lower apoB, I reduce inflammation.

Tom Dayspring: That’s one perhaps, that’s your first therapeutic initiative, lowering apoB by nutrition or, if the risk category is high enough, a drug, fine. But if I could measure something that tells me you have a pro-oxidative state? Yeah, and people do LDL levels in the blood, but they have no idea what they’re measuring. Remember an LDL, a truly oxidized LDL particle, which is the only type that a macrophage in your arterial wall can internalize, is oxidized in the wall of the artery. And what is oxidized? It’s the phospholipids on their surface. Or maybe some free-sterols, be it a phytosterol or cholesterol. That oxidized surface lipids is what the scavenger receptor on a macrophage is going to pull that particle into it, and then you start accumulating cholesterol, and you have a sterol laden foam cell. Bingo, you got the disease. But can I measure oxidized LDL in the plasma? No, LDLs don’t get oxidized in the plasma, there’s too many natural antioxidants in plasma where they don’t occur (Figure 11).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-146.png)

**Figure 11. Oxidation hypothesis and atherogenesis.** As apoB particles, most of which are LDLs, enter the intima, they bind to proteoglycans and are subject to oxidation by reactive oxygen species – oxLDL are internalized into macrophages by various scavenger receptors, which creates sterol-laden macrophages called foam cells. In turn, they secrete a variety of proinflammatory molecules and set up the maladaptive inflammatory response typical of atherosclerosis.

Tom Dayspring: So what you can measure in plasma is called minimally oxidized, alright there’s a little bit of oxidation occurring, but it’s not the phospholipids. It’s some of the [amino acids] on the apoB segment are being changed into aldehydes (Figures 12 and 13), which is what the monoclonal antibody picks up, it picks up aldehydes on apoB. Those aldehydes wouldn’t have formed if there wasn’t a little bit of a pro-oxidative state. So when you’re measuring oxLDL, it’s really apoB, well a measure of apoB oxidation. But where is apoB? It’s on remnants and on LDL particles. So just understand what you’re measuring. But of all the LDL particles that are floating around, if you get an abnormal oxLDL you’re looking at maybe five percent of the total particles. Now, you might make the case that when they do enter the artery wall, forced in by the particle number, they’re going to be even further enhanced, so maybe they got a leg up on an un-oxidized LDL particle, okay. So I would use that as a measure of a pro-oxidative state, and I’d try and give you whatever nutritional things I believe might fight oxidative states. I’m not aware that I got a drug, including a supplement that ensures me it can do that or not. Other than, if I had to reach for a supplement it might be for an omega 3 fatty acid, but it’s another story.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-149.png)

**Figure 12. Oxidation.** One of the more popular ways of assaying oxidized LDL is to look at aldehyde formation of the apoB amino acids.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-151.png)

**Figure 13. Oxidized LDL assay (oxLDL).** Note that this assay detects minimally oxidized LDLs, which are a minuscule fraction of total circulating LDL particles.

Tom Dayspring: So that’s what you’re measuring with the oxLDL. I think they’re are better markers of pro-oxidative states, and look a lot of oxidation is the granulocytes oxidizing a variety of tissue. So myeloperoxidase, it’s a granulocyte-secreted, pro-oxidative enzyme, we can measure that easily in the blood. That would be a signal of a pro-oxidative state. And I think the best of all is, as fatty acids get oxidized their derivatives form. They’re shorter chain fatty acids and they’re put in a big group called isoprostanes, and you can easily assay something called F2-isoprostanes, which have clearly been linked to pro-oxidative states. Now it’s a urine test, it’s not a serum test, but it’s a small urine sample. They’re not 24 hour urine.

Tom Dayspring: So I like to do F2 isoprostanes. So whatever you like to do, be it oxLDL, be it myeloperoxidase, or be it the F2-isoprostanes, I can use that as useful information and maybe even convince you that nutrition is important here. And that is the best way to try and change them around. So those are some of the pro-oxidative markers, what I would not use as a pro-oxidative biomarker that way too many people are is lipoprotein phospholipase A2. First of all, the data is pretty poor. Most people don’t even know the only thing the FDA has given that approval for is as a screening test in primary prevention, never ever for anybody on a lipid modulating drug or who has known coronary atherosclerosis. [Figures 3,4,10,11,14-20]

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-153.png)

**Figure 14. Oxidized phospholipids on Lp(a).** Certain lysine-rich segments of specific kringles serve as binders and carriers of oxidized lipid moieties.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-155.png)

**Figure 15. Lysine binding segments of apoprotein(a).**

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-157.png)

**Figure 16. The isomers called ADMA and SDMA, which, because of their effect on potent vascular regulator nitric oxide (NO), serve as biomarkers related to endothelial function.**

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-159.png)

**Figure 17. Note that ADMA blocks the conversion (inhibits the enzyme nitric oxide synthase, or NOS) of L-arginine to NO.** SDMA reduces cellular concentration of L-arginine (needed for synthesis of NO) by blocking its uptake from plasma. Also note ADMA, but not SDMA, can be catabolized within the cell by the enzyme DDAH. The only route for SDMA to be excreted is renal, which is why it also serves as a biomarker of kidney function. Finally, note that both homocysteine and oxidative stress inhibits catabolism of ADMA, which in turn, would inhibit NO production.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-161.png)

**Figure 18. Data revealing that the vast majority of oxidized phospholipids in plasma are on Lp(a) particles.**

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-162.png)

**Figure 19. The enzyme Lp-PLA2 binds with great affinity to Lp(a) particles.**

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-164.png)

**Figure 20. Two biomarkers indicative of oxidative stress are urinary F2-isoprostanes and serum oxLDL (which is a measure of minimally oxidized LDL particles).** There are no fully oxidized LDLs in human plasma.

Tom Dayspring: For the simple reason that Mendelian randomization has shown that your level of Lp-PLA2 activity or mass has nothing to do with outcomes, sort of like the HDL cholesterol story. And even more important there have been two mega trials where pharmaceutical industry has developed Lp-PLA2 inhibitors, gave them to patients, shut down Lp-PLA2 activity, drastically reduced Lp-PLA2 mass. Levels plummeted, no outcome reduction whatsoever.

Peter Attia: And Lp-PLA2 is an enzyme made by the endothelium ([O’Donoghue et al., 2014](https://jamanetwork.com/journals/jama/fullarticle/1900827))?

Tom Dayspring: No, it’s made by macrophages, it’s just like myeloperoxidase are made by granulocytes.

Peter Attia: But the MPO data are equally unimpressive, aren’t they?

Tom Dayspring: If you want to come down to, it depends what you’re using it for.

Peter Attia: I stopped using MPO two years ago.

Tom Dayspring: I don’t do it [i.e., MPO] myself, look oxLDL, I do it. It’s easy to do, it’s there. And it’s more linked to the process that I can see. MPO? I don’t know, you could have some other vasculitis going on or something.

Peter Attia: Yeah, my take on MPO is I found it to be unhelpful. And I agree with you that Lp-PLA2, it’s one of those things you really only need to check once. Where I find it actually somewhat helpful, and again I could just be deluding myself, is you take the patient with an elevated Lp(a) who has an elevated Lp-PLA2 and not only do you have a tongue-twister, but you also have a patient who might be a little higher risk (Figure 19).

Tom Dayspring: And I wondered if I whispered that into Peter’s ear over the years.

Tom Dayspring: But anyway, I would tend to agree with him, so here’s why. Lp-PLA2, which is an enzyme that does oxidize those phospholipids on an LDL, when, after that LDL enters the arterial wall, is exposed to reactive oxygen species and some of the fatty acids on the phospholipids start oxidizing. Then Lp-PLA2 activity kicks in and it de-esterifies the fatty acids from the phospholipids, so now you got oxidized phospholipids floating around, and a byproduct called lysolecithin, which is a pretty pro-atherogenic molecule. So Lp-PLA2 is involved with the production of them in the arterial wall. That’s not where we’re measuring Lp-PLA2 (Figure 21).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-166.png)

**Figure 21. This slide highlights the important role Lp-PLA2 plays in the oxidation of LDL.**

The oxidatively modified phosphatidylcholine component of the lipoprotein particle is the most favored substrate for the enzyme Lp-PLA2.

The hydrolytic activity of Lp-PLA2 generates oxidized fatty acids (oxFA) and lysophosphatidylcholine (lyso-PC).

*Tselepis AD, Chapman MJ. Inflammation, bioactive lipids* and *atherosclerosis: potential roles of a lipoprotein-associated phospholipase A2, platelet activating factor-acetylhydrolase. Atheroscler Suppl 2002; 3:57–68*.

Tom Dayspring: But, hey if it’s on the particle when it goes in the artery wall, who’s artery’s wall in today’s environment doesn’t have reactive oxygen species sitting there waiting to attack something? What particles entering artery wall are going to have the most Lp-PLA2 mass on it, when that’s where you’re going to turn on Lp-PLA2 activity? And by the way, the assays available everywhere, they no longer measure the mass. They measure the activity. We’re the last company who finally ran out of reagents, so we’re going to activity now. Across the board the studies show either Lp-PLA2 mass or activity are identical in predicting risk, if that’s what you’re using it for. But, believe it or not the activity assay is so much easier technically to do, less costly. That’s what all labs are doing nowadays, the activity.

Tom Dayspring: So, Lp-PLA2 jumps on LDL, yeah there’s a little bit on HDL particles, but most of it is on LDL particles. HDLs are a heterogeneous species of normal sized big and small LDL particles. You’ll find way more copies of Lp-PLA2 on the smaller LDL. Perhaps one of the reasons people believe small LDLs are more atherogenic than larger sizes. I don’t know, once they’re in the artery wall, which is driven pretty much by particle number, but everybody with small LDLs is probably got too many LDL particles.

Tom Dayspring: So they’re very prone to oxidation when they do go in the artery wall, not that a big LDL can’t be oxidized, it could be. But it would have less Lp-PLA2 on it. But if I really wanted to know the number of copies of that enzyme, Lp-PLA2, where would I find it in the blood? On Lp(a) particles. That’s where it’s all carried. You know I think Peter hinted on it in his Lp-PLA2 podcast, that there’s another attribute to Lp(a) other than quantifying it or weighing its mass and that’s; we do know there are people with high Lp(a) who do not get [CV events], and they may be a minority, but they’re out there.

Tom Dayspring: Just like not everybody with FH is going to have a heart attack. Some go through life without it. Most get some events, but many do not. And clearly there are people without Lp(a) who get heart attacks for other reasons. So, if you came to me with a very high Lp(a) whatever, do I just say, “Life’s over get your will in order. I got no drugs that can really help me with this and you can’t afford a PCSK9 inhibitor, so I can’t even experiment there.”? Maybe the ones who are at most risk, part of a functionality, part of the atherogenic potential of an Lp(a) particle is one of the functions perhaps of apo(a) is it’s a garbage truck that scavenges oxidized lipid moieties, phospholipids, sterols. And it brings them back to wherever, maybe it’s macrophages that clear them and detoxify them.

Tom Dayspring: So it’s some sort of a little rescue truck, garbage truck of clearing it. But, what happens if you got way too many Lp(a) particles, too many LDL particles? So some of them are going in your artery wall. Now you have an Lp(a) particle that’s not only got a potentially pro-atherogenic apo(a) protein on it, but that thrombotic, if it is a pro-thrombotic protein, there’s plenty of evidence suggesting it is causative of arterial, not so much venous thrombosis. Many people have dismissed Lp(a) as being linked to venous thrombosis, I don’t know, but if you talk to Sam on that, he will tell you.

Peter Attia: Oh, that’s interesting. So I stand corrected, because I think I was probably quoting some old data when I said that the VTE hazard ratio was about two.

Tom Dayspring: Yeah, but it’s just weak sort of data.

Tom Dayspring: So, when you talk to Sam talk to him more about that. So maybe it is, maybe it isn’t.

Peter Attia: Athero, but aortic stenosis.

Tom Dayspring: Worry athero first. Yeah, and aortic stenosis. And part of the pathology may be it’s just trafficking these oxidized lipid moieties into your particle, which is going to just stimulate this whole inflammatory mess that’s going on in your arterial wall. And maybe it’s a pro-thrombotic mess, if that’s a pro-thrombotic protein, too. Little double whammy going in with it. And I think Peter covered it nicely in his discussion, aired already segments on apo(a) called kringles. And there are a couple of kringles that have a large essence of lysine amino acid that is like flypaper for oxidized lipid moieties, so they really bind to these lysine rich segments on apo(a). So if we could start measuring oxidized phenomenon and tying it into-

Peter Attia: Now Sam has written about this in his papers (Figures 14 and 15).

Tom Dayspring: Well, yeah, Sam has published the data showing that’s who you worry about with Lp(a). If they have oxidized apoB phospholipids elevated, and Sam’s got an assay for that. It’s not available widely (Figure 18).

Peter Attia: Yeah, so the oxPL. That’s a shame.

Tom Dayspring: And Sam will tell you, that yes we’re measuring it on apoB particles, but the apoB particles that carry the vast majority of these oxidized PL are Lp(a) particles. Yeah, it could be a remnant or two, or the oddball LDL particle, but mostly it’s your Lp(a), so that is again a double whammy. So I think maybe in the future we’re going to be screening with whatever you want, Lp(a) mass.

Tom Dayspring: In the future, we’re going to be screening with whatever you want. Lp(a) mass, Lp(a) particle count, I hope we never use Lp(a) cholesterol. It’s like all cholesterol metrics should be, and the only way you can assay it is a poor assay nowadays anyway. Is all right, you do have excess Lp(a) whatever in your system, let me now do this follow up test, and if that’s also up, let’s discuss everything we can possibly do until that miracle drug, hopefully miracle drug comes along, and we got a cure for you.

Tom Dayspring: And maybe it’ll be covered in those people because, for 3rd party payers, because like all these new antisense drugs, it’s going to come with a price.

## Endothelial health markers: ADMA and SDMA [34:30]

Peter Attia: Yeah. Before we leave biomarkers, anything you want to say about asymmetric or symmetric dimethylarginine?

Tom Dayspring: It’s a very interesting biomarker also. Where we talked about endothelial function, perhaps even some of the antioxidant function is this miracle molecule every endothelial cell makes. Extremely transient, it makes and it’s gone. It’s nitric oxide.

Tom Dayspring: Nitric oxide is a powerful regulatory molecule that regulates vascular reactivity by oxidation. The thrombotic potential of an endothelial surface initiating a thrombus is highly dependent on nitric oxide (Figures 16 and 17).

Tom Dayspring: So when endothelial cells make nitric oxide, which is by far, the most important molecule they make, where does that come from? Arginine. The amino acid, arginine. So arginine gets converted into nitric oxide. So, last thing I want is things that are going to screw up arginine pools, which is needed to make nitric oxide. In two proteolytic molecules, we know byproducts of basically catabolism of nuclear proteins is something called symmetric, and the other one is called asymmetric dimethyl arginine. They’re isoforms of one another. They’re mirror images of one another, but they’re actually different molecules. One directly, and the other indirectly inhibits the synthesis of arginine.

Tom Dayspring: So if I measured ADMA.

Peter Attia: The synthesis of nitric oxide, you mean?

Tom Dayspring: Right. Yes. Well, ultimately the synthesis of arginine, which results in the synthesis of nitric oxide.

Peter Attia: Oh. See, I always thought that SDMA inhibited the synthesis of arginine, but ADMA inhibited NOS directly.

Tom Dayspring: I should correct what I said. One inhibits the synthesis, and the other enhances the catabolism of arginine, so at the end of the day, you’re going to have less arginine and less nitric oxide. And they’re both markers that we can easily measure.

Tom Dayspring: And if we measure them, and they’re high, you might presume, maybe that’s a blood test that actually tells us something about endothelial function. I don’t think we have another that has anything close to makes that hypothesis.

Peter Attia: I think the nice thing about the ADMA, SDMA is it creates a biologically plausible mechanistic explanation for why we see an association between high homocysteine and greater disease because homocysteine really inhibits the clearance of ADMA and SDMA, and that’s very clear when you correct it.

Tom Dayspring: Which would therefore screw up nitric oxide production. So it brings even oxidation into the process, would disturb that process too. So if a pro-oxidative state, if hyperhomocysteinemia is adversarial to the vascular tree, that’s one of the pathways in which it is. So what can we do? Well, we can measure it.

Tom Dayspring: So how would I measure ADMA? So if you came to me, and you’re on your third bypass or fourth stent, I think it’s a pretty safe assumption you have screwed up endothelial function, so I don’t know. Do I even need to mention that?

Peter Attia: And of course, the bigger question is what do we do about it?

Peter Attia: So one thing is, look, if they have impaired renal function, hypertension, you know, those are things that you go after. The homocysteine, especially in the MTHFR mutation patients, you give methylated B vitamins, which is still controversial in sort of mainstream circles. Because even though it lowers homocysteine, some will point to that and say, “Well, you have no outcome data on lowering homocysteine.”

Tom Dayspring: But you have plenty of data that in people with homocystinuria, lowering homocysteine drastically improves their vascular outcome. So it’s possible, at a certain threshold of homocysteine that probably makes sense, and if you really understood the pathway of catabolism of methionine, you’d understand this better. And remember, in that pathway is going to be the production of a lot of neurotransmitters, too. So, there’s a lot going on if you have the genotype that’s going to screw up methylation or the enzymes involved with that. That’s another story.

Tom Dayspring: But, perhaps the best use of ADMA, SDMA is in the primary prevention setting, where you got a little borderline apoB or LDL-P, you’re not going to do lifestyle- do I really want to throw you on a drug or something. If those markers are up, that tells me whatever is going on in you, you have endothelial dysfunction, so you’re down the road towards vascular pathology. So it might be a marker to kick you in the rear to at least be super aggressive nutritionally. Even, hey, I’m sorry, whatever nutrition we tried, you still have abnormal endothelial function. See, I would rather improve these markers that will take a drug to get them to where I want them to be. So maybe we could use it in that setting.

Tom Dayspring: If you also want to tell it to me, “Tom, you said, ‘Hey, if you’ve been through a bypass, or a stent or something, why do it?'”

Tom Dayspring: But what if I have such a patient who I’ve maxed out on lipid therapy, done everything else to homocysteine, or insulin resistance, and they’re still up? Should I lower apoB even further with a PCSK9 because, I mean you use it for what you want to use it for, but as a marker of endothelial function.

Tom Dayspring: And very interesting, of the two, you get both, and you also get an arginine level in the same assay. And SDMA is cleared by your kidneys. ADMA is catabolized in the cells, so kidney function has nothing to do with ADMA, but SDMA, one of the things that’ll elevate it, is renal disease. And when SDMA goes into serum, it can back flux right into the cell and decrease nitric oxide production, probably part of the pathology in people with renal failure.

Peter Attia: I was just about to say, the thing I like about the ADMA SDMA stuff, even though we don’t have all this great, long term details it’s one biochemical pathway that provides very clear evidence for two observations that are undeniable: elevated homocysteine, and renal function.

Tom Dayspring: The SDMA will, not the ADMA.

Peter Attia: But you get both.

Tom Dayspring: Yeah. You get both, it’s not like your ordering them selectively. You order, you’ll get all three of those markers.

Peter Attia: And they’re addressing both sides of that equation.

Tom Dayspring: Yeah. So, it’s a very interesting little biomarker there. And hey, who doesn’t want another renal function test? Most are using creatine and that’s kind of a poor- you should be using cystatin-C and SDMA will be further enforcement.

Tom Dayspring: And mild degrees of renal impairment go ignored in this country, and if you’re even in the early, even stage two, but certainly by stage three, which could be a clearance of 70 or something, or 60, that gets ignored, even though EGFR is being reported to people. And that’s a major league risk factor that you ought to say, “Your vascular path, you’re at risk for vascular disease. I got to see what I can do to you therapeutically to lower your risk.”

Tom Dayspring: But it gets ignored until a creatinine clearance is 32, and you need dialysis or something, you know?

Peter Attia: Yeah. This is one of those things I do talk about with a subset of my patients, especially these young patients in their 40s, 50s, who by cystatin-C and creatinine, and maybe even a touch of micro albumin. Their GFR is 80. And I say, “If you’re 40 and your GFR is 80, there’s a problem if you want to live to be 100.

Peter Attia: Because I don’t know where you’re going to be at 80.

Tom Dayspring: Yeah. And look, if you got albumin in your urine, you got a serious vasculopathy someplace, maybe it’s just your glomerulus and you got a kidney disease, but you probably have some other vascular disease too. So albumin just asking something else.

Tom Dayspring: Something’s as big as the proteins escaping in urine. You got some membrane problems that are lining some, either a glomerulus or a blood vessel some place.

Tom Dayspring: And it’s interesting because Peter, in his little world, sees a lot of these people who are well trained athletes, take care of themselves. And some of them, maybe even Peter probably encouraged them to build up muscle mass, which can influence creatinine, and makes it far less useful as a marker of renal. Cystatin-C is not influenced by muscle mass, so that’s where it picks up some of the imperfections, the weaknesses.

Peter Attia: We check both.

Tom Dayspring: And if you do both, which is, by the way, if you read the kidney guidelines, they’ve actually developed a nice equation where your clearance, and we provide this at THD, and I don’t know any other lab that does. We give you a clearance based on creatinine. We give you a clearance based on Cystatin C, and we give you the best clearance of all based on both of those parameters.

Peter Attia: And then you segregate by African American, non African American.

Tom Dayspring: You do, because creatinine is very different in African Americans, so there’s a lot more to those eGFRs if you haven’t studied it lately that might be going on. And if I’m going to do it by a marker, if there’s no other restrictions, and look, that might be a third party payer, or somebody else, I’d rather do the most informative biomarker, and that would be the dual eGFR. And maybe some ADMA, or SDMA thrown in as a renal marker anyway.

Tom Dayspring: And that SDMA, ADMA marker, I really wish we could take you to ([El-Khoury, 2018](https://www.aacc.org/publications/cln/articles/2018/october/the-search-for-a-high-sensitivity-creatinine-assay)). Just be five or six PowerPoint slides, and you’d see these pathways, and maybe I’ll tweet them in the next week or so, individual slides.

Peter Attia: Yeah, or we can just attach them here, easily to the show notes (Figures 16 and 17).

Tom Dayspring: You’ll see it’s staring you right in the face, how they work and what they’re doing.

## Remnants [43:45]

Peter Attia: Now we touched on something earlier that I know you wanted to come back to, and we were deliberately short on it. I’m trying to kind of think about how to land this plane here. You want to go back and talk a little bit about what a remnant is? It gets so much confusion. About remnants (Figures 22-24), they’re talked about like they’re one homogeneous entity.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-169.png)

**Figure 22. VLDLs are a heterogeneous collection of variably sized and composed, and typically TG-rich, lipoproteins.** Many methodologies exist to separate VLDL particles.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-170.png)

**Figure 23. Note measuring VLDL-P added little (beyond LDL-P) to the prediction of CVD in Framingham Offspring.**

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-171.png)

**Figure 24. Notice apoC-III is a potential way to identify remnants: apoC-III gives a VLDL increased plasma residence time where it can acquire more cholesterol via CETP-pathway.** It is the CE-richness of remnants that contribute to their atherogenicity.

Tom Dayspring: First of all, every known lipoprotein class, including Lp(a) has remnants. All a remnant is is this smaller part of its sister particle that’s in the same density class. So VLDLs come in multiple sizes. You got the big ones, which are only found in people with triglyceride abnormalities. If you don’t have a triglyceride disturbance, you will never have a big VLDL particle, you’ll have medium size, and very often just small LDLs.

Tom Dayspring: But if you look at your LDLs, there’s a normal sized particle, there’s big LDLs, and there’s small LDLs. Everybody has a heterogeneous mixture. There’s no human on the planet who has 100% exact diameter of every single sub fraction of a lipoprotein HDLs vary widely in their density and their size, and their diameters. Even IDLs, there’s a certain diameter range or density range where, here’s the upper limits of what you would call an IDL, and here’s the lower limits of when do you not call it an IDL, it’s an LDL. Or when does a small VLDL, I can’t call it a small VLDL anymore, it’s called an IDL.

Tom Dayspring: But wait a minute. Wouldn’t an IDL be a remnant of a VLDL? If that LDL has a VLDL or IDL origin, isn’t an LDL a remnant of a IDL or maybe a VLDL. Chylomicrons as they lose their triglycerides and phospholipids, they become smaller chylomicrons. Chylomicron remnants which are, for the most part, if you’re lucky, cleared by apoE receptors somewhere, but there’s chylomicron remnants floating around.

Tom Dayspring: So what is the only particle I really care about? An apoB particle that could wind up artery wall, get oxidized, and deliver the sterols and oxidize them, and then you got plaque.

Tom Dayspring: So what forces them in? It’s particle number. Now, I’ve also explained, all right, if it’s apoB particle number, LDL-P is your first biomarker, apoB is simply an LDL-P biomarker. It’s not counting VLDL particles because there’s so few of them. You’re certainly not counting chylomicrons because there are even fewer of those. So apoB is identifying to you way too many LDL particles in this person, but there is absolutely no doubt, even though you have way more LDL particles than you do have VLDL particles, because VLDL particles are two or three times bigger than an LDL, the volume of the sphere is the third power of the radius, they do carry more cholesterol molecules per particle than an individual LDL particle.

Tom Dayspring: But of course, you have so many more LDL particles than even VLDL, or whatever you think a VLDL remnant is, most of the cholesterol getting into your artery wall is still LDL delivered. But I am not denying that VLDL particles cannot deliver cholesterol and get oxidized when they enter the artery wall. They can.

Tom Dayspring: So, what has been the classic definition of a VLDL remnant? Well, they’ve always said, “Do that conversion factor we talked. Divide triglycerides by five. If that’s high, the VLDL cholesterol is high. They have too many VLDL remnants.”

Tom Dayspring: And no doubt, if we really had a VLDL test, that’s true. But it would not be true in other people. So, it’s a poor man’s test of remnants.

Peter Attia: And try to clarify what you’re saying because I think it’s a bit confusing to the listener. You can estimate VLDL cholesterol in two ways. You can take triglyceride and divide by five, and the higher the triglyceride level, the less accurate that becomes. You can take non-HDL cholesterol and subtract LDL cholesterol from it, and you’ll get an estimate as well.

Peter Attia: Those two don’t often agree, by the way, but nevertheless, you have two estimates. But that still doesn’t answer the question. Which of those go onto become pathologic remnants?

Tom Dayspring: Correct. So all you’re identifying there is, you have increased cholesterol content in VLDL particles, and because the ones we fear the most are remnants, we’re just presuming, there’s got to be remnants here.

Tom Dayspring: Whatever therapy you’re thinking of doing in this person, you better get rid of, apply some remnant therapy too. Well, all of the FDA approved drugs that lower apoB, whether it’s statin, ezetimibe, fibrates, which are approved to lower LDL cholesterol, even though they don’t really do it that much, referring to fibrates, clear all apoB particles including remnants.

Tom Dayspring: So, your first solution might be nutritional, if it’s not somebody coming off their bypass or is in the nightmare risk range classification where I think you’d need a lifestyle and pharmacology day one. Too many decades have passed. You shouldn’t be putzing around on real short time.

Tom Dayspring: You know the nutritional therapy, if I think you have remnants is going to be. I’m going to address insulin resistance in you. So I, being an advocate of, some degree of carbohydrate restriction and, certainly a clear advocate, for a lot of reasons, apart from even apoB, would be the fasting as part of your diet.

Tom Dayspring: So, great. If you want to use your VLDL cholesterol, and it makes you think there’s remnants, and you’re going to suggest a therapy. I would tell you if you’re a total drug guy, that got to have a drug, then that’s the person you give a fibrate to with your statin because that’s where the fibrates really do well.

Tom Dayspring: But I can tell that ezetimibe to statin clears as many remnants as that combination too, but I think fibrates bring other things to the table that perhaps Zetia doesn’t, in people with triglyceride-rich lipoproteins.

Tom Dayspring: And one of them’s going to be, so it’s how I really think we’re going to have to identify remnants. There’s a laboratory that produces, they separate VLDL particles by ultracentrifugation. The NMR people used to report total VLDL-P, but they would also give you large VLDL-P, plus medium VLDL-P, plus small VLDL-P, and we used to say, “Well, the small VLDL-P, those are the remnants. That’s the mark.”

Tom Dayspring: Well, they don’t do that anymore. They only give you the large VLDL-P anymore, those large NMR generating labs that have the proprietary ability to release the LDL particle data, and that’s not all in on that.

Peter Attia: Is that LipoScience or LabCorp?

Tom Dayspring: Well there is no more LipoScience, it’s LabCorp.

Tom Dayspring: So you will get a large VLDL-P. It has one reason, and one reason alone. It’s a lipoprotein marker of an insulin resistant state. That’s it. It’s not a goal of therapy. It’s nothing. There’s no data. If what you do to VLDL-P affects outcomes, well, I’d make the case that maybe it does, but it’s just an IR marker.

Tom Dayspring: I can measure small dense LDL cholesterol, HDL-2 cholesterol, just small LDL particle concentration. I can do an insulin level and 10 other tests that tell me you’re insulin resistant, so I don’t need any VLDL-P marker.

Peter Attia: Yeah. I mean they were using that as part of their IR algorithm score.

Tom Dayspring: Yeah. So if you don’t have that, and they factor in VLDL size there, because the big triglyceride rich VLDLs are a mark of insulin resistance. But if you’re measuring insulin levels, and other insulin biomarkers, they’re no better than that. I don’t know that they’re any better than just measuring small LDL particle concentration, at least in a drug naïve person.

Tom Dayspring: So, you will find it is a marker of insulin resistance, but this other lab, they centrifuge them, they tell you, “Look at our smaller VLDL cholesterol. Those are remnants.”

Tom Dayspring: How do they know? All they know is that person has extra cholesterol in their small VLDL particles. But VLDLs depending on two things, it’s apoE content, and it’s apoC-III content, is going to be virtually instantly cleared.

Tom Dayspring: So, if your small VLDL particles are being rapidly cleared by your apoE, apoB100 receptors.

Peter Attia: So in other words, if you took a bunch of small VLDLs, and some of them had lots of apoE and very little apoC-III, those aren’t remnants. They’re not pathological. They’re not sticking out.

Tom Dayspring: They’re small VLDLs, that’s what they are. But are they disease causing VLDLs? Some of them probably get in, but very few compared to LDL particle number.

Peter Attia: And very few relative to a small VLDL that would be high in apoC-III and/or low in apoE.

Tom Dayspring: Yeah which is never going to be cleared. There’s a lot of downsides to apoC-III, it’s a pro-inflammatory protein, it really enhances VLDL production in the liver, but it just retards their clearance, and it probably interferes with the hydrolysis induced by lipoprotein lipase (LPL). So you’re increasing half-lives of all triglyceride-rich lipoproteins, which lets CETP exchange occur longer.

Tom Dayspring: And what is CETP exchange doing? Bringing more cholesterol into your VLDL particles, enhancing cholesterol enrichment. Those VLDLs are losing triglycerides but they’re gathering cholesterol.

Tom Dayspring: So these are all the pathologies that might go on if you have delayed clearance, and C-III is going to delay the clearance for multiple reasons of these particles. So, I want a blood test that tells me the apoC-III content of your apoBs. LDLs that have apoC-III cannot be cleared. In one of the early Pravachol trials of pravastatin and CARE trial ([Sacks et al., 2000](https://www.ncbi.nlm.nih.gov/pubmed/11034934)), they went back and they [looked at], “Who with high triglycerides gets coronary events?”

Tom Dayspring: And this is Frank Sacks, up in Boston. And maybe then, maybe they’ve been able to measure this in sophisticated lipid labs for a long while. If your LDL had apoC-III on it, pravastatin was a useless drug. Didn’t reduce any events ([Sacks et al., 2002](https://www.ncbi.nlm.nih.gov/pubmed/11914249)).

Peter Attia: It still reduced apoB, but it didn’t reduce events?

Tom Dayspring: It would clear some LDL particles. It didn’t reduce events in people that had high triglycerides.

Tom Dayspring: So the apoC-III, it’s not measuring triglycerides that matters, it’s apoC-III. And a lot of people with apoC-III might only have a triglyceride of 110 or 120.

Peter Attia: Wait. Which trial was this?

Tom Dayspring: CARE trial, Cholesterol And Recurring Events ([Sacks et al., 1996](https://www.ncbi.nlm.nih.gov/pubmed/8801446)). It was the second secondary prevention trial. Simvastatin 4S was ferrous. And that was Swedes with super high LDL cholesterol and heart attacks. This was done in Boston at the Brigham, where they enroll people with unremarkable, at the time, LDL cholesterol, 130 or lower, who had heart attacks. And they gave them pravastatin and got pretty much the same event reduction as they got in the 4S trial.

Peter Attia: But the ones that had high trigs didn’t have the reduction?

Tom Dayspring: So they went back in a post hoc analysis, and those that had high trigs, Pravachol lowers triglycerides. Does it matter that’s one of the benefits of pravastatin? The only people that got event reduction where pravastatin lowered triglycerides were those who had apoC-III enriched LDL particles. ApoC-III becomes your biomarker.

Peter Attia: Is Sam’s company also working on-

Tom Dayspring: Yeah. In production is an antisense molecule that’s going to stop apoC-III production because, Peter, I believe you also know the Mendelian thing there is gain a function loss of function of apoC-III is tied into longevity also.

Peter Attia: Actually, I think this is, of all the major longevity genes, I do not believe, and I could stand corrected, but I’m in the process of writing for the book now, I don’t think there is a longevity gene on cardiovascular disease that is a stronger predictor of longevity than hypo functioning apoC-III.

## Omega-3 fatty acids (EPA and DHA) and apoC-III [55:30]

Tom Dayspring: Yeah. So interestingly we just tweeted about it, I’m sure, within the last week. A very interesting trial, that if you’re going to use an omega-3 fatty acid, when they compared DHA versus EPA, DHA is the one that lowers apoC-III, not EPA. So all of these mega advocates of EPA, I don’t know. If apoC-III’s involved there may be a better use for DHA

Peter Attia: Well, I got to be honest with you. I used to see myself as more of an EPA guy. And then my focus on DHA, I think, became more something I saw in the mild cognitive impairment literature, which was the importance of DHA in the brain.

Peter Attia: But I didn’t realize this DHA C-III relationship ([Rader et al., 2018](https://www.ahajournals.org/doi/abs/10.1161/circ.126.suppl_21.a19030)).

Tom Dayspring: For my mind, for years, it’s been omega-3s are not lipid drugs. Ignore them. Don’t use them to putz around with lipids because you don’t know what they’re doing.

Tom Dayspring: That’s changed now. Clearly high dose prescription strength EPA can be a helpful adjunct of therapy to lower apoB. And whether it’s with remnants or whatever it’s doing, it’s lowering apoB an addition 8-10%. Great. And it’s a pretty innocuous [i.e., safe] therapy.

Tom Dayspring: I always worried about those who might not be able to convert EPA to what I believe is the necessary DHA also, especially in the brain. But I can measure that in the plasma.

Peter Attia: You know, I’ve been thinking about, I’d like to have Bill Harris on the show as well to have a discussion about this because, at least at the time of our recording today, I would say that the mainstream view of EPA and DHA is that they’re useless. That’s the press today.

Tom Dayspring: That’s the mainstream view.

Peter Attia: Yeah, the mainstream view is abandon all these dumb, sort of, supplements. As is often the case, when the mainstream says something in a declarative fashion, they’re usually wrong.

Tom Dayspring: Especially on a nutrient, where they’re looking about what you’re eating, not taking pharmacologically. Where you might have a real serious trial.

Peter Attia: They’re confused by supplements versus pharmacological.

Tom Dayspring: Most of the trials that they would quote as omegas being useless, they’re using not a pharmacologic dose of these things. And they’re not measuring even who’s deficient in omegas. And if you’re not deficient in it, why would I even give you an omega?

Tom Dayspring: Measuring fatty acids in the blood, I would encourage you to measure red blood cell omega-3s that are, like a glycohemoglobin, have a 60- 90 day half life, rather than a plasma free fatty acid omega which might be, “What did you eat for lunch?”

Tom Dayspring: There’s other intricacies involved, but nonetheless, they’re just all things to think about there. And this DHA with apoC-III is kind of interesting.

Tom Dayspring: Now look, some people, if you’re just going to drown them in EPA, do convert it to DHA so it’s not an issue, but we can measure that. And I think we’d know, “Oh boy, and you, you got to have some of that either eaten or supplemented.”

Peter Attia: Are you pushing patients towards, closer to 10% red blood cell EPA DHA level these days?

Tom Dayspring: Well, I don’t see patients anymore, but if you want to ask me, Bill Harris would tell you, “Why not make it 14%?”

Tom Dayspring: But we don’t have any data that would show, “Hey, that’s harmful.” We don’t have any data showing you can even make it that high.

Peter Attia: Not even epistaxis and things like that? Easy bruising?

Tom Dayspring: So far, anything with that, they’ve never turned anything from an omega-3 into coagulation disturbance.

Tom Dayspring: It’s old data that, “Hey, some Eskimos might’ve had a bloody nose one day. And what else, they’re eating EPA and DHA all day long.”

Tom Dayspring: So I don’t know. That would have to be tested in a clinical trial.

Peter Attia: By the way, Tom, I just have to take issue with that, as a Canadian, I think we refer to them as Inuit now.

Tom Dayspring: Oh I’m sorry. Eskimos is an old New Jersey term.

Peter Attia: Super culturally insensitive. I’m not going to stand for that.

Tom Dayspring: I’m an old Jerseyite. So you’re right.

Peter Attia: But I really do need to get Bill on the show because Bill’s one of these guys, and again, many of the listeners won’t know who Bill Harris is, but I hope to change that. This is a guy who is as devoted to understanding the entire body of literature and science of omega fatty acids in general-

Tom Dayspring: Fatty acids in general, especially omega-3s and 6s.

Peter Attia: -As you are into lipids.

Tom Dayspring: Way more than me. And he was a colleague I worked for three or four years with. I love the guy. We had lunch all the time. We would go out, so he has taught me so much, and he is the guy who developed the red blood cell phospholipid fatty acid assay, so he knows what he’s talking about.

Tom Dayspring: And it gets so intriguing because even for those of you listening who may be taking an omega-3 or prescribing an omega-3, be it a supplement or be it a prescription product, what vehicle are you prescribing a free omega-3 fatty acid? You’re not. There is an FDA approved product that the company who developed it has not brought to market yet.

Tom Dayspring: So you’re either prescribing esterified omega-3 fatty acids or it’s esterified to something else, or it’s esterified to glycerol as phospholipid, such as esterified to a glycerol backbone, where it has three fatty acids, but only one of them is an omega-3. Or are you buying a super enriched, that all three fatty acids are esterified to an omega-3?

Tom Dayspring: So what is the vehicle in your favorite supplement that’s carrying? All of that comes into the realm of pharmacodynamics.

Peter Attia: I just realized, because there’s only two supplements over the counter that I fancy. One is Carlson’s, the other is Nordic Naturals, just based on some of the toxicology stuff. But I don’t know the answer to the question you just asked.

Tom Dayspring: And you can’t get that information unless your brother works there and is privileged to that. The companies won’t even tell you what they esterify. And look, you hear about these krill products. They’re phospholipids, and that means there’s one fatty acid on them. So you got to prescribe a lot of krill pills to achieve a certain omega-3 level. Way less than you would if you had a diesterified or luckily enough a triesterified triglyceride vehicle.

Peter Attia: I’m always happiest when I see my patients just eat enough salmon.

Tom Dayspring: So listen, at the end of the day, that’s all cool, it’s good to know. Whatever way they’re somehow getting omega-3s into your body, if you’re normalizing the omega-3 index, does that even matter, all that other stuff?

Tom Dayspring: So it all depends, but I would implore you to follow up, please.

Peter Attia: Yeah I want to dig into this a little bit. I got to be honest with you, I’m ashamed to admit this because I hate being the guy who makes dumb assumptions and is too lazy to follow up. I’ve always assumed that the high quality EPA and DHA supplements were triacylglycerides.

Tom Dayspring: Almost none of them are. They’re mostly monoglycerols, but it’s glycerol with two other fatty acids plus one omega-3 fatty acid.

Tom Dayspring: And what are those other fatty acids? If nothing else, they’re calories that you may or may not need. Or they’re a harmful fatty acid even. Who knows?

Peter Attia: Interesting. We’ll get to the bottom of this. And there’s no pharma grade DHA? To your knowledge.

Tom Dayspring: No. But here’s what there is, and it’s already FDA approved, but the company that developed the product has not brought it to market, but I think they’re going to because this November, at the American Heart Association, you are going to get the people at risk, who are on statins, and half of them are getting statins plus EPA, and the other half are getting statins plus EPA placebo, no EPA.

Tom Dayspring: And we’re going to get outcome then.

Peter Attia: What dose of EPA?

Tom Dayspring: It’s high. It’s three, four grams.

Tom Dayspring: It’s the prescription strength. So are we going to see cardiovascular? All indications, and we’re all optimists, are it’s going to be a positive trial. They haven’t stopped it, at least, for futility. They certainly haven’t stopped it for toxicity. The trial is over. They’re generating the data now. Wouldn’t they have just stopped at futility and gone away if it didn’t work? So we’re all expecting that it’s, EPA added, it’s going to work. Why wouldn’t it? It’s an EPA. It probably has other physiologic attributes. It can reduce certain inflammatory markers. It’s a nice apoB additional lowerer.

Tom Dayspring: Now, the company that has developed free omega-3 fatty acids, so they’re not esterified to anything. That means they’re very bioavailable, you just swallow it. Remember, anytime you swallow an esterified omega-3 fatty acid, you have to secrete pancreatic enzymes to de-esterify it. Because it can’t be absorbed without that. Even phospholipids, krill oil, has to be de-esterified by a specific lipase coming out of your pancreas.

Tom Dayspring: Free fatty acid is going to come right in, but we don’t eat a lot. You might in certain foods, but even most of the foods you eat, it’s triglycerides that are delivering-

Peter Attia: Don’t free fatty acids taste horrible?

Tom Dayspring: I don’t know. Maybe that’s why they’re not there, or, I think most of the time they’re stored as energy, as not free fatty acids. So they got to be de-esterified. But anyway, this company that has them, this is a company that manufactures a statin. And what they were hoping was, they thought the people making EPA, the FDA was going to give them an indication based solely on additional LDL cholesterol lowering, or apoB lowering that, we’ll let you come on the market pending you’re outcome data because non HDL is better whatever.

Tom Dayspring: The FDA didn’t. The FDA even told them they couldn’t do it. The company, which is Amarin, actually took the FDA to court, and Supreme Court says, “No. Even though you don’t have an approval for it, you could at least go share this with doctors.”

Tom Dayspring: That Amarin EPA product, Vascepa has skyrocketed in sales because doctors believe this additional data with the Vascepa. So you would add Vascepa to your favorite statin of choice, and then you’re taking two drugs.

Peter Attia: Which statin do they make?

Tom Dayspring: No they don’t make a statin. They make EPA, so they want you to add Vascepa to whatever statin you’re-

Peter Attia: Oh I thought they also made a statin.

Tom Dayspring: No they don’t. So you can pick your favorite statin, but now you have, like ezetimibe, you might add to a statin, you can now add Vascepa.

Peter Attia: I’m going to wait ’til November.\*

\* **Note from Tom Dayspring**: Good news, the trial is positive ([AMARIN, 2018](https://www.vascepahcp.com/?gclid=CjwKCAjwo_HdBRBjEiwAiPPXpDCtyYSyRHccpzSrk-dGSHA11HOpz-Yi26OMhKoZbRy-sIRTfNsrghoC0GwQAvD_BwE&gclsrc=aw.ds)).

Tom Dayspring: I would too. Not that I wouldn’t be using EPA DHA for perhaps other reasons, cognitive or whatever. Just cell membrane health, but the other company that makes a statin called Rosuvastatin, and that would be called Astrazeneca’s one that owns this ([Kastelein et al., 2014](https://www.ncbi.nlm.nih.gov/pubmed/24528690); [Dunbar et al., 2015](https://www.ncbi.nlm.nih.gov/pubmed/26328624)).

Tom Dayspring: So what they were clearly hoping to have, Amarin got an indication tatted to a statin. They would’ve released a combo product using rosuvastatin and their EPA product. And you would have, in one pill, your statin plus your proper dose of omega-3s. And it would be free omega-3 fatty acids, which would zoom right into your body. I got a feeling if, and by the way, they are completing their own big outcome trial with rosuvastatin plus the non-esterified free fatty acids. So they’ll wait for their trial too but if this first trial works, why would theirs not even work better because it’s combining it with the most potent statin.

Tom Dayspring: All these people who’ve been bad-mouthing omega-3s with no trial data might have to change at least some of that talk come November at the American Heart Association. It’s the biggest trial going to come out of AHA this year, at least in the lipid world, so pay strict attention. [The results are out. The trial is positive. See: [AMARIN, 2018](https://www.vascepahcp.com/?gclid=CjwKCAjwo_HdBRBjEiwAiPPXpDCtyYSyRHccpzSrk-dGSHA11HOpz-Yi26OMhKoZbRy-sIRTfNsrghoC0GwQAvD_BwE&gclsrc=aw.ds).]

Tom Dayspring: Well, a month or so before, normally they don’t leak out that data because that somehow prohibits publication in prestigious journals but some companies do because it just means so much financially to them that it’ll get published somewhere. I don’t know. One way or another, we’re going to have it in November.

## Red blood cells and cholesterol transport [1:07:45]

Peter Attia: We’ve danced around this idea of red blood cells for a while, they keep coming up. So let me redirect us to another topic which is, you’ve already said red blood cells per molecule carry many, many, more molecules of cholesterol than any lipoprotein does.

Tom Dayspring: Right ([Hellerstein and Turner, 2014](https://www.ncbi.nlm.nih.gov/pubmed/24362356)).

Peter Attia: Why don’t red blood cells cause atherosclerosis?

Tom Dayspring: Because they’re not invading your arterial wall and not subject to oxidative forces where a macrophage is going to ingest the red blood cell.

Peter Attia: Do they not invade the artery wall because they can’t penetrate the subendothelial space?

Tom Dayspring: Yeah. They’re gigantic. Now listen, can a red blood cell get into plaque? Yeah, through the vasa vasorum.

Peter Attia: So the vasa vasorum, meaning from the other side?

Tom Dayspring: Yeah, or even the artery walls get arterial supply, they need oxygen. Even plaque has little capillaries. Are there red blood cells in expanding plaques? Sure. But that’s not your primary delivery of oxidized phospholipids and sterols into the artery wall. Red blood cells are not being entered into the artery wall and being oxidized you know? Like the apoB particles are.

Peter Attia: Yeah so this gets back to this casualty issue of low density lipoproteins.

Tom Dayspring: Although also red blood cells carry way more cholesterol molecules, you have bazillions more apoB particles than you have red blood cells. So yes quantity wise, they’re carrying a lot of cholesterol but not particle number wise. Not red blood cell number wise versus LDL number wise.

Peter Attia: So the size of the LDL particle obviously is what enables it to easily get into and out of-

Tom Dayspring: Yeah number and size, but as you know and I told you this a long time ago, any VLDL under 70 nanometers can work its way into an endothelial gap or arterial wall through a scavenger receptor whatever. So not to say remnants aren’t capable of arterial invasion they can’t get in because remnants are way bigger than an LDL, no they could. But, there’s just more of the LDL particles so if this is a diffusion gradient forcing them in, there’s a hell of a lot more LDL trouble makers than there are remnant trouble makers. Not to say some big tough guy isn’t a big trouble maker by himself, he is, but which would you rather have a thousand guys coming at you or your one guy? I’d take my odds that I could beat one guy rather than a thousand guys you know?

Peter Attia: It’s hard to believe we’ve been going at this for almost seven hours and I feel like there’s at least another hour or two we could go but at the same time I want to be sensitive to the listener. Normally I say I want to be sensitive to the guest but I know you and I could keep talking about this for another six hours and we’re going to go have dinner with Jamie Underberg [last year’s NLA President] tonight and just continue this discussion. I wish I had a microphone for dinner because I have a feeling that’s going to be equally interesting.

## Tom’s friend Earl [1:10:00]

Peter Attia: One of the things you talked about at the very outset was a really close friend of yours who got you into hockey. Took you to your first game in Madison Square Garden, got you hooked. You were both obsessed with being firefighters. He went on to become a firefighter and you went on to become a lipid educator.

Tom Dayspring: Yeah so let me just pick up that. If you look back in life who are some of your absolute best friends, your high school buddies, who you really spent all that enjoyable time, the type of enjoyment you can have at that age that you never can have at another age and you can do things, especially when we grew up. We were in high school ’59 and ’63, you could get away with a lot of junk in those days. Whereas today, you would be expelled really quickly or so with some of the shenanigans we did.

Tom Dayspring: Look, I joked with Peter when I was telling this story. I think he really wanted to be my best friend because my father was a fire chief in the town of Paterson, New Jersey, where we went to high school. But even if that was true, I loved firefighting. What do I care if he loved firefighters. We used to get on our bikes and ride to fires all the time together and watch fires, or drive to fire houses. So we were really tight for a million reasons and we just got along personality wise. But he’s the guy who invited me to my first ice hockey game which was certainly impacted my life and my son’s life, in mega ways. My son’s a very successful guy and he would tell you he would never be half as successful had he not played ice hockey and developed the team work and the comradery. Speaking of a fire engine…

Peter Attia: It’s perfect timing to have a fire truck going down.

Tom Dayspring: I’m going to just keep talking over this firetruck because it’s not high lipid science. So my buddy there (Figures 25 and 26), he went and became, and I know him all my life and I went and became a doctor. But in that same city or in the suburb of that city, so it’s not like he didn’t know where to find me. At a certain point earlier in life, I knew my buddy, hey you’re a doctor now I got this cholesterol problem. They tell me my cholesterol is up in the blood. And I was probably at the point where we were really taking cholesterol serious and you got to do something about it. All right, you got to come and see me, come on. I was probably even the days before, I was solely dwelling on lipoproteinology and lipidology but I was very aggressive with it, on the understanding cholesterol, knowing, look who I evolved into so it would have probably been a smart choice for him to come up.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-172.png)

**Figure 25. Paterson NJ Battalion Chief and friend of Dr Dayspring, Earl.**

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-173.png)

**Figure 26. Earl (left) and Tom (right) celebrating high school graduation.**

Tom Dayspring: It’s not like I was going to charge him and he couldn’t afford me. He’s a fireman [who became a Battalion Chief] in a big city. He had the best health insurance you could ever get, so it’s not like it would have cost him ten cents. A lot of fireman did pick me as their doctor because of who my father was and they knew he’s the [doctor] who likes fire engines. We used to see him as a kid in the fire house. I want him to be my doctor, he knows what I do.

Tom Dayspring: Earl was just one of these people who thought the farther I stay away from doctors, the better. I don’t want to hear what they got to tell me. I don’t want to be on a medicine. I don’t want to do anything. And Earl got buried in his mid-50’s with a sudden acute myocardial infarction sitting at home watching TV. He could have been climbing a ladder at a fire. By the way, if he did die in a fire, his name would be on the memorial monument up in that city but he died at home the next day. I really wish it was because he’s such a [dedicated firefighter], but there is such a needless death and I think across America all the time there are many young aged needless deaths occurring with a very preventable, treatable disease that’s being ignored totally because they don’t go and get it checked or they’re getting bad advice based on the wrong metrics.

Tom Dayspring: So my buddy there is the perfect example but what a tragedy because had he made the right…I liked this guy. He’s my best buddy, he’s not going to screw me or do anything wrong. Let me go to him. He didn’t. Every time I saw him I’d remind him, “Earl, come up, come up. Please come up.” “Yeah, yeah, Tom.” He never did.

Peter Attia: Well anyways, that’s probably the reasonable and sad way to end this discussion but it also brings it back to why do we get so animated about this topic. Well, I think as you said, we think of this as one of the big three diseases that kills most people in the civilized world once they get out of childhood. Any by civilized I really mean developed, if people know what I mean. Of the big three diseases, this is the one where we know the most about it and therefore by extension, it’s probably the one that’s most delay-able. Never want to say preventable. We use that term but in reality, what does that mean? It means delay. And so if Earl died in his early ’50s, maybe with the right care he could have died in his late ’60s, you know? Again, if a guy’s dying in his ’50s of heart disease, he’s probably got really bad disease.

Tom Dayspring: Yeah, he needed therapy at a really young age but he could have hung around for a while and he’s got grandkids and children who really wish he was still here. The fire department, his beloved firemen and they all wish he was still around. He’d be retired by now but he’s just one of these people God sends to Earth that do nothing but good while they’ve been here through their whole life. He had saints as parents and he was so tragic that he left us at such a young age and got driven to the graveyard on the back of a fire truck with a flag on it. Vietnam veteran. So, so sad.

Tom Dayspring: Listen, I want to wrap this up myself. I used to wrap up a lot of lectures I did with this. My lectures were all high science, no matter what group I was speaking to. You want to come out of this lecture that I give and maybe with all the things if you really sat through everything we talked about today to say, “Tom’s an idiot” or “he’s on to something and I thought I understood this topic but maybe I need to understand it at a higher level”. So everything is study, study, study.

Tom Dayspring: I didn’t learn this stuff overnight. My life has been in this field.

Peter Attia: Yeah, well I’ll say a couple things. I’ll say a couple things on that. So first of all, I obviously want to thank you for the influence you’ve had on me and I don’t know, I just feel really lucky. I think that I got plugged in to you and Allan and Ron. Just out of the gate, to have met the three of you so early in my interest in this topic saved me so much time because it’s one thing. No one can substitute the amount of time you have to spend obsessing over this topic and learning it but boy, when you can have that curriculum curated for you, you short cut it by three ex I’m sure.

Tom Dayspring: It’s a gift and I’ll just extrapolate on that because Peter named three guys he can get in contact with pretty quickly and get answers. As I evolved in this world, I had 20 guys around the world who liked me a lot because the way I explained things, what I could illustrate for them. So I’d been blessed by, I mentioned a few today: It would take me another 15 minutes to list them all but so many of them, I call them the “Lipid Gods” out there, the people who have spent their real life in research laboratories and clinical trials and taking care of people in the worst lipid clinics. They are still available to me, but that’s who I use. I don’t go on the internet and read or make stuff up. I try and ask experts about a lot of things. Not that you’ll ever get consensus on anything but those of us who do have those avenues open, which many do not, but they’re not afraid to still pontificate about something, that’s kind of sad.

## Peter’s friend JP [1:18:15]

Peter Attia: Yeah and I can’t remember if I made this, this will be my final point on the topic. I can’t remember if I made this point on a previous podcast or not and if I did, to the listener, I apologize. I started out in mathematics and engineering and really loved those things. I excelled at those things. Took great pleasure in being a first principles thinker.

Peter Attia: One silly story at the end of my freshman course in sort of dynamics, kinematics, sort of Newtonian physics. You take a final exam and you are allowed one piece of 8×10 paper that you can write on both sides, as much as you want, whatever formula you want because there were just so many equations you would have to know to go in and ace one of these exams.

Peter Attia: Now, I was cocky beyond words and I was really lucky as a freshman I used to study in this dark part of the stacks where I met a real upperclassman guy. His first name is JP, I can’t remember his last name but I’ll never forget him. He was the only guy I’d ever met who decided to take two engineering disciplines and finish them both in four years. So he did electrical and mechanical engineering in four years. The price he had to pay for that was he studied every minute of every day but he also told me, he didn’t have the opportunity to learn everything. Because you couldn’t. If you wanted to take all of electrical and mechanical in four years, you had to accept that there were certain things you couldn’t know.

Peter Attia: All of his study focused around first principles inference. He taught me this early and so he saw me studying for one of my exams and I was writing out something called the Coriolis equation which basically explains centrifugal forces under the condition of a changing radius. And he said, you don’t need to memorize that formula. You know how to derive it. I was like, what? What are you talking about? He goes, write out the formula for angular position and take the derivatives of it. You know calculus. So I did and sure enough, I was getting the same formulas.

Peter Attia: To make a long story short, I’ve become totally inundated by JP’s reasoning. I go into my final exam and oh, you have to turn in your cheat sheet at the end of the exam. This is again, I’m not saying this to brag about how cocky I was so I just have to state-

Tom Dayspring: I understand.

Peter Attia: But the point is, I wanted to show the professor how well I understood this material. The only thing I wrote on my cheat sheet in big block letters was the sum of the forces equals mass times acceleration. Because I was like if you know the simplest of Newton’s laws, you can actually derive everything at this level of physics. We’re not talking quantum physics at this point.

Peter Attia: And I remember JP said look, on every question, write it out. Show them how you can go from one to the other. Because if you make a mistake at least they’ll see what you’re doing. I ended up acing that exam and that lesson sort of stuck with me and it served me very well through the rest of engineering and mathematics including when it got really, really complicated. In the end, if you truly wanted to understand something at first principles, you could derive so much.

Peter Attia: Okay, fast forward a few years now I find myself in medical school. I was not a pre-med. So I’m in medical school, not as a pre-med but as a former engineer, math guy who barely squeaked into medical school. Meaning I took the MCAT having not even taken a course in biology yet, I had to take my bio class after. And I’ll tell you that first semester in med school was brutal for me because I learned the hard way that you couldn’t first principles your way through biology. At least not at the level, at least not until you’ve gained a certain amount of familiarity with the basics. I couldn’t walk into my histology class look under the microscope and on first principles know the difference between the Golgi apparatus and the endoplasmic reticulum. You just have to know that stuff. I couldn’t go into anatomy and physiology and pathology and just first principles my way into stuff.

Peter Attia: Eventually you can but you have to have an enormous basis. So I sort of forgot about all that pain. You get through medical school and by the end it became, it was very enjoyable but it wasn’t until I got to the lab, to NIH, where my mentor told me a great story. Now he’s probably one of the most brilliant scientists I’ve ever known and did a PhD in biophysics specifically for the purpose of wanting to make sure he was never in his words intimidated by a differential equation, despite the fact that he was an immunologist. And he told me a story and I need to get the details of it because I don’t remember the physicist he’s referring to but he told me this story about a physicist turned biologist who lamented once that the moment he switched from physics to biology he could never again take a bath in peace. Because as a physicist he could sit in the bath and wax philosophically and think about lots of things on first principles and be very theoretical in his understanding. But as a biologist, sitting in the bath, he always realized there was always one more fact he needed to remember before he could draw a conclusion and so he had to keep getting out of the bathtub to go and look up a certain fact. And that obviously disrupted the beauty of taking the bath.

Peter Attia: And I think that long rambling story is a way of saying the following. I find this subject matter to be as complicated as any I have ever tried to learn and unfortunately, every time I have a brilliant idea, just based on first principles, I still have to go and check if it’s grounded in the foundation of science. And sometimes it is but many times it is not. I come up with an idea and I’m like, this has got to be right, but, oh, it’s physiologically impossible and there’s even an experiment that one day suggested this. I made an assumption but I can clearly see that it was not the case. I understand your frustration and I share it and I think unfortunately, that is the nature of biology.

Tom Dayspring: Yup and I remain an eternal optimist. I continue to teach lipids. I think clinicians know a bit more than we know. In 1995, when I started this journey teaching. So that’s all, if I have to do it one at a time with people, I try and teach them what I know and hopefully you’ll do your continuing education. That’s one of the nice things about medicine but you gotta do it. None of this comes easy and it does. And there’s a lot of complexities in medicine nowadays. We’re talking because it’s a highly pathologic state and leading cause of trouble but there’s so many other things to take to a much higher level nowadays.

Peter Attia: Well Tom, people will certainly by the end of this will know where to find you but on Twitter, which is where you spent the most of your time here [@Drlipid](https://twitter.com/Drlipid), correct?

Tom Dayspring: That’s me. Yup.

Peter Attia: And we’re generally in our brief existence as a podcast already known for probably producing the most thorough show notes ever. I’m suspecting that this, this episode which we’ll probably break into several parts, will have the most robust show notes that we’ve done. I love by the way that there’s another fire truck going down. It’s perfect. It’s totally appropriate.

Tom Dayspring: It’s the perfect end.

Peter Attia: But also if there’s anything else that you think of let’s just talk about it where, offline even we can just get to it. Were there other resources you think people ought to go to? Again, we’ll steer people away from your 2000 to 2004 writings but I think there’s going to be a number of people who listen to this who say, “I might have missed half of what those guys talked about, but there’s something there I want to make sure I understand better” because in the end, every doctor wants to do the best by their patient.

Peter Attia: I believe that wholeheartedly. I get very frustrated when I hear people say that doctors are in the pockets of PhRMA companies and they’re just in it for the money, Sure there’s going to be some of those people but I haven’t met those guys. The doctors that I meet, the men and women that I meet who take care of patients, they all want to do the best by their patients. And I think those are people who are going to want to invest a little bit of their time and understanding this problem a little better.

Tom Dayspring: Now I can’t say any more than that. As you listen to these seven and a half hours you can hopefully peace meal marker. Clearly, depending on the listener, there’s going to be things over your head. Even if you are a super skilled lipidologist, there’s going to be some things you said “what, let me read about that” or so. But it’s just trying to open your mind and understand there’s a lot going on here. The field is infinitely more complex than you ever imagined. It took me a long time, and I’m a, as Mike Davidson calls me, Tom’s a self-taught lipidologist. Meaning I didn’t spend two years down at the National Heart Lung and Blood Institute, even though the director of that NHLBI, Alan Remaley and I just authored a 70 page chapter in the Tietz book of molecular and clinical biochemistry ([Rifai, 2018](https://evolve.elsevier.com/cs/product/9780323359214?role=student)). All about lipids and apoproteins so I think to be an invited author with them.

Peter Attia: And you sent me a pre-print of that.

Tom Dayspring: So it’s an expensive book. I don’t expect you [to buy it] if you’re not a lipidologist or somebody seriously into this inclination, but that’s what you go out and buy. But, there is a lot of information out there so, just be careful on what you, “that’s ridiculous” or “my own thought up theory based on no clinical trials or sciences is what I believe.” Fine, believe it. This is America here. I can’t lock you up. I’m not the lipid police.

Peter Attia: Yeah well on that note. Tom, thank you very much. It’s hard to believe this has been seven hours of discussion today. But it’s been worth every minute to me and I’ve learned a lot in this discussion so, to me that’s always, I mean for selfish reasons, that’s sort of my primary objective is to learn as much as I can and along the way, if others can learn too that’s a bonus.

Tom Dayspring: And without a year of my intermittent fasting program from Peter and Nicole, I could never have had the energy to say, even to use my tongue or brain so thank you again Peter.

Peter Attia: Yeah, my pleasure Tom. Thanks.

§

§

## Selected Links / Related Material

**Lp(a) catabolism**: [Lipoprotein(a) catabolism is regulated by proprotein convertase subtilisin/kexin type 9 through the low density lipoprotein receptor](https://www.ncbi.nlm.nih.gov/pubmed/25778403) (Romagnuolo et al., 2015) [3:00]

**Lp(a) podcast**: [Deep Dive: Lp(a) — what every doctor, and the 10-20% of the population at risk, needs to know (EP.07)](https://peterattiamd.com/lpa/) | Peter Attia (peterattiamd.com) [3:30]

**Inflammation and CVD**: [Anti-inflammatory therapies for cardiovascular disease](https://www.ncbi.nlm.nih.gov/pubmed/24864079) (Ridker and Lüscher, 2014) [17:30]

**Low dose methotrexate**: [Methotrexate and Cardiovascular Protection: Current Evidence and Future Directions](https://journals.sagepub.com/doi/full/10.1177/1179559X17741289) (Mangoni et al., 2017) [17:45]

**Powerful anti-inflammatory drug**: [Colchicine Cardiovascular Outcomes Trial (COLCOT)](https://clinicaltrials.gov/ct2/show/NCT02551094) (clinicaltrials.gov) [18:00]

**IL-1 inhibitor that Peter talks about**: [Antiinflammatory Therapy with Canakinumab for Atherosclerotic Disease](https://www.nejm.org/doi/full/10.1056/NEJMoa1707914) (Ridker et al., 2017) [18:30]

**Canakinumab approved for certain rare inflammatory conditions**: [Prescribing information](https://www.accessdata.fda.gov/drugsatfda_docs/label/2016/BLA125319_858687lbl.pdf) (ILARIS, 2016) [19:00]

**Darapladib trial**: [Effect of Darapladib on Major Coronary Events After an Acute Coronary Syndrome — The SOLID-TIMI 52 Randomized Clinical Trial](https://jamanetwork.com/journals/jama/fullarticle/1900827) (O’Donoghue et al., 2014) [26:45]

**Creatinine assays**: [The Search for a High Sensitivity Creatinine Assay](https://www.aacc.org/publications/cln/articles/2018/october/the-search-for-a-high-sensitivity-creatinine-assay) (El-Khoury, 2018) [43:30]

**CARE trial**: [VLDL, apolipoproteins B, CIII, and E, and risk of recurrent coronary events in the Cholesterol and Recurrent Events (CARE) trial](https://www.ncbi.nlm.nih.gov/pubmed/11034934) (Sacks et al., 2000) [53:15]

**CARE and HDL-C & TG**: [Coronary heart disease in patients with low LDL-cholesterol: benefit of pravastatin in diabetics and enhanced role for HDL-cholesterol and triglycerides as risk factors](https://www.ncbi.nlm.nih.gov/pubmed/11914249) (Sacks et al., 2002) [53:30]

**CARE trial**: [The effect of pravastatin on coronary events after myocardial infarction in patients with average cholesterol levels. Cholesterol and Recurrent Events Trial investigators](https://www.ncbi.nlm.nih.gov/pubmed/8801446) (Sacks et al., 1996) [54:00]

**EPA study**: [REDUCE-IT TOPLINE RESULTS ANNOUNCED](https://www.vascepahcp.com/?gclid=CjwKCAjwo_HdBRBjEiwAiPPXpDCtyYSyRHccpzSrk-dGSHA11HOpz-Yi26OMhKoZbRy-sIRTfNsrghoC0GwQAvD_BwE&gclsrc=aw.ds) (AMARIN, 2018) [1:06:00]

**Omega-3 study**: [Omega-3 free fatty acids for the treatment of severe hypertriglyceridemia: the EpanoVa fOr Lowering Very high triglyceridEs (EVOLVE) trial](https://www.ncbi.nlm.nih.gov/pubmed/24528690) (Kastelein et al., 2014) [1:06:00]

**Omega-3 study**: [Effects of omega-3 carboxylic acids on lipoprotein particles and other cardiovascular risk markers in high-risk statin-treated patients with residual hypertriglyceridemia: a randomized, controlled, double-blind trial](https://www.ncbi.nlm.nih.gov/pubmed/26328624) (Dunbar et al., 2015) [1:06:00]

**Red blood cells (RBCs) carry more molecules of cholesterol than lipoproteins do**: [Reverse cholesterol transport fluxes](https://www.ncbi.nlm.nih.gov/pubmed/24362356) (Hellerstein and Turner, 2014) [1:07:45]

**Dayspring and Remaley chapter on lipids and apoproteins**: [Tietz Textbook of Clinical Chemistry and Molecular Diagnostics, 6th Edition](https://evolve.elsevier.com/cs/product/9780323359214?role=student) (Rifai, 2018) [1:27:00]

§

§

## People Mentioned

- [Sam Tsimikas](https://twitter.com/Lpa_Doc?lang=en) (Lp(a) research) [11:30]
- [Frank Sacks](https://www.hsph.harvard.edu/frank-sacks/) (apoC-III research) [53:30]
- [Bill Harris](https://omegaquant.com/dr-william-s-harris/) (Omega-3s, DHA, and EPA) [57:00]
- [Jamie Underberg](https://nyulangone.org/doctors/1538167127/james-a-underberg) (last year’s NLA President) [1:10:00]
- [Allan Sniderman](https://www.cardiomuhc.ca/allan-sniderman) (one of Peter’s lipid mentors) [1:16:45]
- [Ron Krauss](https://profiles.ucsf.edu/ronald.krauss) (one of Peter’s lipid mentors) [1:16:45]
- [Michael Davidson](https://www.lipid.org/about) (past NLA President) [1:26:30]
- [Alan Remaley](https://www.nhlbi.nih.gov/science/lipoprotein-metabolism/people/remaley-alan) (NHLBI, co-authored chapter on lipids and apoproteins with Tom) [1:26:30]
- [Nicole Vantress](https://www.linkedin.com/in/nicole-vantress-rd-cnsc-94554b42/) (Director of Health and Nutrition at Attia Medical, PC) [1:28:00]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/10/tom-dayspring-300x300.jpg)

##### Thomas Dayspring, M.D., FACP, FNLA

Thomas Dayspring, MD, FACP, FNLA is the chief academic officer for True Health Diagnostics, LLC. He provides scientific leadership and direction for the company’s comprehensive educational programs. Dr. Dayspring is a fellow of both the American College of Physicians and the National Lipid Association. He is certified in internal medicine and clinical lipidology.

Before relocating to Virginia in 2012, Dr. Dayspring practiced medicine in New Jersey for 37 years. Over the last two decades, he has given over 4,000 domestic and international lectures, including over 600 CME programs on topics such as atherothrombosis, lipoprotein and vascular biology, biomarker testing, and women’s cardiovascular issues.

Dr Dayspring is an Associate Editor of the Journal of Clinical Lipidology. He has authored or co-authored numerous manuscripts published across leading journals such as the American Journal of Cardiology, the Journal of Clinical Lipidology, and several lipid-related book chapters. He was the recipient of the 2011 National Lipid Association President’s Award for services to clinical lipidology. [[truehealthdiag.com](https://truehealthdiag.com/leadership/thomas-dayspring/)]

Disclosures:

- Employed full time for last three years by True Health Diagnostics, LLC, which provides biomarker diagnostics and clinical services to clinicians, patients, and healthcare organizations
- 2017: small consulting project for Abbvie

Tom on Twitter: [@DrLipid](https://twitter.com/Drlipid)