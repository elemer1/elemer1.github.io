# Peter Attia Show Notes 优先阅读列表

> 25篇核心内容，按价值密度排序，附完整文件路径

---

## 开始前必读：参考文档

| 顺序 | 文档 | 大小 | 价值 |
|------|------|------|------|
| **0a** | [LAB_REFERENCE_GUIDE.md](LAB_REFERENCE_GUIDE.md) | 15K | Medicine 3.0实验室指标速查表 |
| **0b** | [TOPIC_INDEX.md](TOPIC_INDEX.md) | 39K | 27个主题分类索引 |

---

## 第一优先级：核心框架 (7项)

### 1. Longevity 101 - 长寿框架基础
**为何第一**: Peter官方设计的入门总览，覆盖四骑士+运动+营养
```
#311 - Longevity 101 a foundational guide to Peter's frameworks for longevity, and understanding CVD, cancer, neurodegenerative disease, nutrition, ex.md
```
大小: 85K

### 2. Medicine 3.0 - 核心哲学
**为何第二**: Medicine 1.0→2.0→3.0演进，风险评估思维框架
```
#231 - AMA #41 Medicine 3.0, developments in the field of aging, healthy habits in times of stress, and more.md
```
大小: 51K

### 3. 胰岛素抵抗大师课 - 代谢疾病核心
**为何第三**: 四骑士之一，代谢疾病的分子机制
```
#140 - Gerald Shulman, M.D., Ph.D. A masterclass on insulin resistance-molecular mechanisms and clinical implications.md
```
大小: 78K

### 4. Tom Dayspring 脂质学系列 (5集) - CVD根因
**为何第四**: 四骑士之首(心血管疾病)的完整教育
```
#20 - Tom Dayspring, M.D., FACP, FNLA - Part I of V an introduction to lipidology.md (95K)
#21 - Tom Dayspring, M.D., FACP, FNLA - Part II of V Lipid metrics, lipid measurements, and cholesterol regulation.md (126K)
#22 - Tom Dayspring, M.D., FACP, FNLA - Part III of V HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins.md (83K)
#23 - Tom Dayspring, M.D., FACP, FNLA - Part IV of V statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain.md (155K) ★最大文件
#24 - Tom Dayspring, M.D., FACP, FNLA - Part V of V Lp(a), inflammation, oxLDL, remnants, and more.md (108K)
```
系列总计: 567K

### 5. Matthew Walker 睡眠系列 (3集) - 被低估的支柱
**为何第五**: 睡眠对CVD/癌症/代谢/认知的系统性影响
```
#47 - Matthew Walker, Ph.D., on sleep - Part I of III Dangers of poor sleep, Alzheimer's risk, mental health, memory consolidation, and more.md (41K)
#48 - Matthew Walker, Ph.D., on sleep - Part II of III Heart disease, cancer, sexual function, and the causes of sleep disruption (and tips to correct.md (54K)
#49 - Matthew Walker, Ph.D., on sleep - Part III of III The penetrating effects of poor sleep from metabolism to performance to genetics, and the impa.md (49K)
```
系列总计: 144K

### 6. Zone 2 训练 - 运动基石
**为何第六**: Peter最推荐的训练方式，代谢灵活性核心
```
#85 - Iñigo San Millán, Ph.D. Zone 2 Training and Metabolic Health.md
```
大小: 67K

### 7. 情绪健康与长寿 - 被忽视的维度
**为何第七**: 心理健康直接影响寿命
```
#298 - The impact of emotional health on longevity, self-audit strategies, improving well-being, and more  Paul Conti, M.D..md
```
大小: 139K

---

## 第二优先级：深度专题 (10项)

### 8. 癌症深度探讨
```
#62 - Keith Flaherty, M.D. Deep dive into cancer- History of oncology, novel approaches to treatment, and the exciting and hopeful future.md
```
大小: 124K

### 9. 优化大脑健康 (阿尔茨海默/APOE)
```
#251 - AMA #46 Optimizing brain health Alzheimer's disease risk factors, APOE, prevention strategies, and more.md
```
大小: 99K

### 10. ApoB/LDL-C/Lp(a)/胰岛素与CVD
```
#238 - AMA #43 Understanding apoB, LDL-C, Lp(a), and insulin as risk factors for cardiovascular disease.md
```
大小: 61K

### 11. 癌症筛查的复杂性
```
#170 - AMA #25 ﻿Navigating the complexities and nuances of cancer screening.md
```
大小: 45K

### 12. Zone 2 深度回顾 (Part 2)
```
#201 - Deep dive back into Zone 2  Iñigo San-Millán, Ph.D. (Pt. 2).md
```
大小: 101K

### 13. 力量训练与长寿
```
#239 - The science of strength, muscle, and training for longevity  Andy Galpin, Ph.D. (PART I).md
```
大小: 131K

### 14. "抗衰老"药物 (NAD+/二甲双胍/雷帕霉素)
```
#207 - AMA #35 "Anti-Aging" Drugs - NAD+, metformin, & rapamycin.md
```
大小: 97K

### 15. 断食作为代谢疾病的解药
```
#59 - Jason Fung, M.D. Fasting as a potent antidote to obesity, insulin resistance, type 2 diabetes, and the many symptoms of metabolic illness.md
```
大小: 86K

### 16. 膳食蛋白质需求
```
#224 - Dietary protein amount needed, ideal timing, quality, and more  Don Layman, Ph.D..md
```
大小: 116K

### 17. 创伤与自我同情
```
#15 - Paul Conti, M.D. trauma, suicide, community, and self-compassion.md
```
大小: 35K

---

## 第三优先级：实用补充 (8项)

### 18. 百岁老人十项全能训练
```
#261 - Training for The Centenarian Decathlon zone 2, VO2 max, stability, and strength  Peter Attia, M.D..md
```
大小: 55K

### 19. 优化睡眠实操
```
#233 - AMA #42 Optimizing sleep - bedtime routine, molecule regimen, sleep trackers, sauna, & more.md
```
大小: 59K

### 20. 心肺训练指南 (任何水平)
```
#379 - AMA #79 A guide to cardiorespiratory training at any fitness level to improve healthspan, lifespan, and long-term independence.md
```
大小: 98K

### 21. 优化营养
```
#328 - AMA #66 Optimizing nutrition for health and longevity myth of a "best" diet, complexities of nutrition science, and practical steps for building.md
```
大小: 55K

### 22. 补充剂评估框架
```
#340 - AMA #69 Scrutinizing supplements creatine, fish oil, vitamin D, and more-a framework for understanding effectiveness, quality, and individual n.md
```
大小: 73K

### 23. 下背痛
```
#287 - Lower back pain causes, treatment, and prevention of lower back injuries and pain  Stuart McGill, Ph.D..md
```
大小: 132K

### 24. 习惯养成
```
#183 - James Clear Building & Changing Habits.md
```
大小: 97K

### 25. Rhonda Patrick 综合讨论
```
#252 - Latest insights on Alzheimer's disease, cancer, exercise, nutrition, and fasting  Rhonda Patrick, Ph.D..md
```
大小: 126K

---

## 快速启动路径

如果时间有限，按以下顺序阅读：

1. **LAB_REFERENCE_GUIDE.md** - 先理解指标
2. **#311 Longevity 101** - 框架总览
3. **#231 Medicine 3.0** - 核心哲学
4. **#238 ApoB/CVD** - 心血管实操
5. **#85 Zone 2** - 运动起点

完成以上5篇即可建立基础框架。

---

## 统计汇总

| 优先级 | 数量 | 总大小 |
|--------|------|--------|
| 第一优先级 | 7项 (含15集系列) | ~1.1 MB |
| 第二优先级 | 10项 | ~890 KB |
| 第三优先级 | 8项 | ~695 KB |
| **总计** | **25项** | **~2.7 MB** |

---

*生成时间: 2026年1月*
*基于382期节目的系统分析*
