# #41 – Jake Kushner, M.D.: How to thrive with type 1 diabetes and how everyone can benefit from the valuable insights

**Source:** [https://peterattiamd.com/jakekushner/](https://peterattiamd.com/jakekushner/)

---

In this episode, Jake Kushner, pediatric endocrinologist specializing in helping people with type 1 diabetes and Medical Director of McNair Interests, discusses the best strategies to live and thrive with T1D, especially as it relates to diet and exercise. We also discuss why many patients who control their blood sugar with high amounts of exogenous insulin are at a substantially higher risk than people who can control their blood sugar at lower levels of insulin. This concept has great implications for non-diabetics as well considering the increasing prevalence of diseases related to insulin resistance. We also cover some of the basics, the history, the increasing prevalence of type 1 diabetes, and more importantly, what we can do to help kids with this disease, and their families.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/jakekushner/the_Drive_public.png)

Play

#41 - Jake Kushner, M.D.: How to thrive with type 1 diabetes and how everyone can benefit from the valuable insights

#41 - Jake Kushner, M.D.: How to thrive with type 1 diabetes and how everyone can benefit from the valuable insights

1x15s30s

0:002:07:31

## We discuss:

- How Jake became interested in type 1 diabetes [5:30];
- The pathophysiology of type 1 diabetes, the increase in prevalence, and the role of beta cells [17:00];
- The role of body weight and BMI in the risk of developing T1D [27:00];
- Genetics of T1D and the risk of inheritance [32:00];
- Hemoglobin A1c [36:15];
- Insulin: the amazing story of its discovery, its effect on cellular metabolism and IGF-1, and why the hell it’s so expensive [39:15];
- Diabetes Control and Complication Trial: blood glucose and the complications associated with diabetes [54:45];
- Cognitive impairment, epigenetic changes, and other dangers associated with high, peak blood glucose, and big swings in blood glucose levels [1:09:15];
- Depression, anxiety, and other challenges of living with T1D [1:15:30];
- Jake’s realization that the current standard of care of T1D is inadequate [1:26:15];
- Managing diabetes with exercise [1:30:15];
- The Bernstein method, and protein’s impact on glucose and insulin [1:36:15];
- Jake radically changes his approach to treating patients [1:45:00];
- What other tools are there for controlling T1D? [1:49:45];
- Is the ketogenic diet appropriate for those with T1D? [1:52:45];
- The most important lessons that can be applied by the non-diabetic population [1:59:00];
- The two dream measurements Peter wishes were available [2:04:00]; and
- More.

§

## Show Notes

## How Jake became interested in type 1 diabetes [5:30]

- Peter and Jake had dinner one night in Houston, Texas
- Jake was the first person to introduce Peter to the [CGM](https://www.dexcom.com/continuous-glucose-monitoring)

Advisor for [Sanofi](https://en.wikipedia.org/wiki/Sanofi)

- Working on the exciting drug [sotagliflozin](https://www.lexpharma.com/pipeline/sotagliflozin) ⇒ a new class of drugs that will hopefully benefit people with [type 1 diabetes](https://en.wikipedia.org/wiki/Diabetes_mellitus_type_1) (T1D)
- Peter says, “Super interesting, not just for type 1 diabetes, but potentially Type 2. And frankly if you subscribe to the idea that lower levels of glucose and insulin are just better overall, there may even be other applications.”

**Jake’s path to becoming a** [**pediatric endocrinologist**](https://en.wikipedia.org/wiki/Pediatric_endocrinology)

- Trying to decide in between being a pediatrician and being a molecular biologist
- “I thought I would do that and the classical path as an endocrinologist is to go and find a rare disorder and discover the molecular basis for it and find some unique product that you could then replace and provide it”
- Was also interested in pediatrics
- undergraduate at Berkeley working continuously in basic science research labs
- Several years afterwards as a research technician, first at UCSF and then Oregon.
- Medical school at Albany Medical College in New York
- Pediatric resident at Brown University
- Enamored by endocrinology in general, so he applied and got fellowship at Children’s Hospital Boston
- Also served as a research fellow at the Joslin Diabetes Center at Harvard Medical School

**How Jake became so interested in type 1 diabetes**

> “As a first year endocrine fellow, we’re running around an incredibly busy service, and we’re interacting with families of children who are newly diagnosed with type 1 diabetes. And I just thought, ‘Wow, this is really an amazing and challenging problem.’ And it has so many aspects of medicine that I appreciate. It has, most importantly human elements, but there’s also basic science.”

- Jake saw the toll it took on people and especially parents
- He also saw how often is was either completely missed or a misdiagnosis was given
  - About 30% of the kids that are diagnosed present with [diabetic ketoacidosis](https://en.wikipedia.org/wiki/Diabetic_ketoacidosis) (DKA) which implies that they’ve had the illness for quite some time
  - “When they present with diabetic ketoacidosis, it means that they have somehow managed to slip through the cracks. Nobody’s figured out that their glucose level is through the roof, or that they’re becoming acidotic or do these other things. And what actually brings them into the hospital is a septic-like situation.”

Onset of T1D in adults

- The presentation of DKA is less frequent in older people, who generally become diabetic at a slower pace which is known as cryptic type 1 diabetes
- In these people… they probably have autoimmune antibodies, and they have some degree of loss of [beta cells](https://en.wikipedia.org/wiki/Beta_cell) ⇒ “and this phenomenon explains some of the adult onset diabetes that you just don’t quite understand”

**How many people in the United States have type 1 versus type 2?**

- So Type 1 is approximately one in 300 people
- The typical age of onset is around nine years old
- And they live into adulthood, and many can survive into their 80s
- “It’s the most common life threatening, medication requiring, illness of childhood.”

> “And when you’re working in a fancy medical school, it’s quite sort of tempting to focus on a rare, unique condition that most people don’t get a lot of exposure to, and bypass the really common things. But for me, type 1 diabetes was the elephant in the room. It was just so compelling and I ended up being the first clinical fellow at Boston Children’s in 10 years to go into type 1 diabetes.”

## The pathophysiology of type 1 diabetes, the increase in prevalence, and the role of beta cells [17:00]

> “At a very high level, there are genetic, as well as environmental contributors”

**The molecular pathophysiology**

- [Autoimmune condition](https://en.wikipedia.org/wiki/Autoimmune_disease)
- Largely driven by [T cells](https://en.wikipedia.org/wiki/T_cell), but there is also a contribution of [B cells](https://en.wikipedia.org/wiki/B_cell)
- And because of that, you can detect antibodies in the serum that indicate autoimmunity
- By some combination of bad luck, genetics and possibly the foods you eat (to a very modest degree) this stochastic phenomenon begins to move forward:
  - whereby the beta cell, which secretes insulin, begins to dump off antigens
  - And the antigens begin to provoke the immune system locally
  - And some of those immune cells start to destroy beta cells and dump out more antigens

The role of the [pancreas](https://en.wikipedia.org/wiki/Pancreas)

- Exocrine=About 95% of the pancreas by mass serves an exocrine function, which is it’s mostly there for local digestion
- Endocrine=However, about 5% of the pancreas by mass, including these cells called [beta cells](https://en.wikipedia.org/wiki/Beta_cell), acts as an endocrine organ (versus an exocrine organ), which means it’s secreting systemic hormones into the system (insulin, glucagon, somatostatin, and pancreatic polypeptide)

“When they begin to dump off their antigens and provoke autoimmunity, you can get this sort of death spiral. Where ultimately, the end result is a progressive autoimmunity, where you lose beta cells over time. And I don’t think that there’s any one single, for instance, virus that can be conclusively ascribed to autoimmunity and type 1 diabetes.”

BMI and T1D

- In populations, the heavier you are, the more likely you are to have T1D (note: this doesn’t seem to hold up in individuals)
- “…which implies either that the work of the beta cells contributing to the autoimmunity, or alternatively the work of the beta cell and the relative beta cell insufficiency reveals this autoimmunity that otherwise would have been cryptic.”

**What has been the relative change in the incidence of type 1 diabetes?**

- Doubled since 1960
- Possible explanations?
  - Environmental factors (i.e. obesity)
  - Viruses we’re now exposed to
  - We’re simply better at diagnosing

Diagnosing kids with T1D

- Greater awareness than in the past
- Can be caught as early as 6 months, however, they don’t have classical signs and symptoms
- if nobody bothers to check the serum glucose, you might never know that they in fact have life threatening diabetic ketoacidosis and new onset type 1 diabetes. It’s a disaster.

Kids vs adults

- Kids have a more aggressive onset
- The condition becomes life threatening quicker and their autoimmunity is more aggressive because they don’t have the reserve of beta cells
- Adults have a greater reserve of beta cells so their onset takes longer and is slowly progressing
- This makes it difficult for a precise diagnosis

Misdiagnosing adults

- People are getting diagnosed at type 2, when instead they have cryptic type 1
- This leads to incorrect treatment

**The role of B cells**

- The idea of an antigenic spread…
- “The beta cells make very unique things, and when you break them open and destroy them, you begin to dump them out. There is both the B and a T cell response.
- We can test for antibodies in the serum of people with type 1 diabetes, and they make unique antibodies against insulin and GAD, glutamic acid decarboxylase, as well as a protein, tyrosine phosphatase called ICA 512
- And so those antibodies are commonly used in the diagnosis of type 1 diabetes, which we believe to be a T cell disease
- But that doesn’t make complete sense because antibodies are made by B cells, so there must be some contribution

**⇒ Proof of the role of B cells in T1D**: [Rituximab, B-Lymphocyte Depletion, and Preservation of Beta-Cell Function](https://www.nejm.org/doi/10.1056/NEJMoa0904452)

- A huge clinical trial using [Rituximab](https://en.wikipedia.org/wiki/Rituximab), which alters B cell function, alters the ability of the B cells to make antibodies
- They were able to delay the course of type 1 diabetes

*Other autoimmune diseases that share this phenomenon where you have this B cell, T cell component:*

- [Autoimmune thyroid disease](https://en.wikipedia.org/wiki/Hashimoto%27s_thyroiditis), where you can get thyroid peroxidase and thyroglobulin antibodies ⇒ Largely that’s a T cell mediated disease
  - And by the way, autoimmune thyroid disease is associated with type 1 diabetes or vice-versa.
  - Meaning patients who go on earlier in life to develop type 1 diabetes would be much more likely than patients without it to go onto get [Graves’ disease](https://en.wikipedia.org/wiki/Graves%27_disease) or some of the other autoimmune thyroid disorders
  - Typically Type 1 would present, and then they can get autoimmune thyroid disease.
- Adrenal disease
- [Sialadenitis](https://en.wikipedia.org/wiki/Sialadenitis) (rarely) which is autoimmune disease of the salivary gland
- [Oophoritis](https://en.wikipedia.org/wiki/Oophoritis) of the ovaries (also rare)
- [Pernicious anemia](https://en.wikipedia.org/wiki/Vitamin_B12_deficiency_anemia), the ability to produce B12 ⇒ And so that’s presumably an autoimmune disease of the cells that make B12
- Celiac disease

## The role of body weight and BMI in the risk of developing T1D [27:00]

Do we believe that there are any exposures that are **withheld** from kids that may be predisposing them to Beta cell destruction?

- There’s no one precise thing
- But there is some evidence that a higher BMI could predispose kids to T1D
- “…this implies that the Standard American Diet (SAD) may be predisposing the population in aggregate ever so slightly towards more type 1 diabetes, which is a scary thought.”
- **Paper that has some evidence for the SAD being linked to T1D in kids**: [Excess BMI in Childhood: A Modifiable Risk Factor for Type 1 Diabetes Development?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5399656/)

## Genetics of T1D and the risk of inheritance [32:00]

[HLA alleles](https://en.wikipedia.org/wiki/Human_leukocyte_antigen)

- There are certain HLA alleles that are quite common in the human population
- Example, HLA-DR3 and HLA-DR4, and others
- And when certain HLA are combined it increases the odds of having a child with T1D
- The people who have T1D often have these alleles, and also these other minor alleles that by themselves contribute a small amount of risk, but in aggregate it increases quite a bit

Risk of a child getting T1D if one of their parents has it

- Statistically, it adds up to a 10x increase that your child will have T1D if you have it
- However, since T1D is 1 in 300 for the general population, a 10x increase only brings it to 1 in 30
- Or said another way, there’s still a 97% chance your child will NOT inherit T1D

T1D in twins

- Identical twins
  - Concordance within the first few years is only around 50 or 60%
  - But by adulthood it’s about 80%
- Fraternal twins ⇒ 10x increase relative to general population

## Hemoglobin A1c [36:15]

What is [hemoglobin A1c](https://en.wikipedia.org/wiki/Glycated_hemoglobin)?

- It’s a way to understand the average blood glucose a person has
- It measures the amount of glycosylation, or how much glucose is sticking to hemoglobin
- If we take the assumption that hemoglobin has a relatively finite, fixed, predictable life before the red blood cells themselves get broken down, we can measure the hemoglobin A1c and then impute the average blood glucose

Diagnosing type 2 diabetes (T2D)

- Today, a diagnosis of T2D is made solely on the hemoglobin A1c being greater than 6.5%
- It no longer relies on the insulin or glucose level during an [oral glucose challenge](https://en.wikipedia.org/wiki/Glucose_tolerance_test)

Translating A1C to average blood glucose

![](https://peterattiamd.com/wp-content/uploads/2019/02/A1c_med_ref_table.png)

**Figure 1. A1c to average blood sugar.** Image credit: [webmd.com](https://www.webmd.com/diabetes/guide/glycated-hemoglobin-test-hba1c)

## Insulin: the amazing story of its discovery, its effect on cellular metabolism and IGF-1, and why the hell it’s so expensive [39:15]

**The story about the discovery of insulin:**

*Banting and Best discovered insulin in 1921*: [Banting and Best: The Extraordinary Discovery of Insulin](https://www.spedmjournal.com/files/section/e8_s120_banting_and_best_the_extraordinary_discovery_of_insulin_file.pdf)

*Book recommendation*: [The Discovery of Insulin](https://www.amazon.com/Discovery-Insulin-Canada-150-Collection/dp/1487516576) by Michael Bliss

- Prior to the discovery of insulin in 1921, patients who presented with symptoms of diabetes would die within days, weeks or months from [diabetic ketoacidosis](https://en.wikipedia.org/wiki/Diabetic_ketoacidosis) (DKA)
- Then along came [Frederick Madison Allen](https://en.wikipedia.org/wiki/Frederick_Madison_Allen) who created the [Allen Starvation Diet](https://www.empoweryourhealth.org/taxonomy/term/191)
  - Essentially a low calorie high fat nutritional regiment that had almost no enriched carbohydrates
  - If you used that approach they were able to extend life to a few months, in some cases a few years, but it required incredible precision
  - But it was still a death sentence:

> “It was one of these things that people feared greatly, because if your kid got type one diabetes that was it, you were gonna watch them disappear.”

**The anabolism of insulin**

- Insulin is a key factor in regulating virtually every cell in the body
- It’s recognizing whether a cell is in a state of feast or famine
- If in feast: it take the nutrients and parks them in the cell
- In a famine: it will mobilize some nutrients and make them available to keep the organism alive
- Insulin is a master regulator of your state of metabolism

*In the fat cell:*

- There’s basically one door into a fat cell of esterification or re-esterification
- And then there’s the door out, which is glycolysis
- Insulin acts very prominently at both of those, so free fatty acids and triglycerides are highly regulated by insulin at both ends of that adipose cell

![](https://peterattiamd.com/wp-content/uploads/2019/02/fat-flux.png)

**Figure 2. The in-and-out doors of a fat cell.** Image credit: [How to make a fat cell less not thin: the lessons of fat flux](https://peterattiamd.com/how-to-make-a-fat-cell-less-not-thin-the-lessons-of-fat-flux/)

*In a muscle cell:*

⇒ In a fed state…

- It’s promoting glucose uptake into skeletal muscle
- The insulin signal tell the glucose transporter to move to the cell wall
- GLUT4, a glucose transporter, translocate from the cytosol to the cell wall which make the muscle cell permeable for glucose to be shuttled in

⇒ In a state of starvation…

- At a cellular level, people with T1D are starving
- Muscle is broken down and used for gluconeogenesis
- It creates a profound negative nitrogen balance

“Many of the major steps of protein metabolism are influenced by insulin. . .in the presence of insulin you’re putting more glycogen into skeletal muscle, or in the absence you’re gonna break it down.”

> “And because it’s so fundamental to eukaryotic cells it seems to also influence things that you would never even imagine, like for instance lifespan and aging.”

**Insulin and IGF**

- *Insulin goes up, free IGF-1 goes up* ⇒ “The more hyperinsulinemic a patient is, all things equal, the higher you tend to see their IGF”
- This is because insulin drives down the IGF binding proteins (i.e. [IGFBP1](https://en.wikipedia.org/wiki/IGFBP1))
- insulin and IGF-1 one really are intensely overlapping in the way they work
- Insulin is a [heterodimer](https://en.wikipedia.org/wiki/Protein_dimer)

> “When you block these heterodimeric receptors, you can completely alter metabolism, implying that the role of IGF-1 on glucose homeostasis is really quite powerful.”

**For more on IGF, see the following episodes of The Drive with [Rhonda Patrick](https://peterattiamd.com/rhondapatrick/) and this episode with [Nir Barzilai](https://peterattiamd.com/nirbarzilai/)**

**Back to the story of Banting and Best discovering insulin…**

- Banting is a struggling surgeon in London
- He’s a reader, and he’s thinking about ways to try to contribute
- He reads [this journal article](https://insulin.library.utoronto.ca/islandora/object/insulin%3AT10001) which describes how people who have stones in the pancreas end up with these strange islet like structures, or islets of cells
- Essentially what happens is the pancreas, for whatever reason, if it’s obstructed by a stone and it has a blockage, what you end up with, in the residual after the pancreatitis occurs, are these weird round cellular structures…
- So it had been known from a couple other scientists that there might be something in there that was involved in diabetes…
- So Banting comes up with the following idea: “Wow, maybe what I could do is block the outflow of the exocrine pancreas, which makes these digestive enzymes, force the pancreas it eat itself alive, and then I will take this residual muck that comes from the pancreas and try to purify whatever is within it to see if that is some sort of medicine that might be useful for type one diabetes.”
- It’s a genius moment that comes to him in the middle of the night

![](https://peterattiamd.com/wp-content/uploads/2019/02/notebook-981x1024.png)

**Figure 3. Image of the Banting’s notebook from the middle of the night in which he wrote down his idea. It reads, “Diabetus. Ligate pancreatic ducts of the dog. Keep dogs alive till acini degenerate leaving Islets. Try to isolate the internal secretion of these to relieve glycosurea”.** Image credit: [Banting and Best: The Extraordinary Discovery of Insulin](https://www.spedmjournal.com/files/section/e8_s120_banting_and_best_the_extraordinary_discovery_of_insulin_file.pdf)

- Banting then goes to the University of Toronto and convinces a reluctant professor ([Dr. John Macleod](https://en.wikipedia.org/wiki/John_Macleod_(physiologist))) of metabolism to let him try this experiment
- Banting recruits a medical student to help, Charles Best
- Amazingly they are able to isolate this substance that has the ability to lower blood glucose in dogs

*The process of making insulin to treating a human:*

- Carry out the intervention
- The pancreas eats itself alive
- They get this muck, and they’re able to isolate some crude extract
- They then take it and put it back into a dog that they’ve removed the entire pancreas of, and it lowers the blood glucose in the dog
- Shortly thereafter, they give insulin to a medical student with T1D and are able to lower his blood glucose
- Then they [write the paper](https://www.translationalres.com/article/S0022-2143(22)90384-1/abstract), and the paper gets rejected, then they’re able to submit it to a Canadian journal and it gets accepted
- [Banting and Macleod were awarded the Nobel Prize in 1923](https://www.nobelprize.org/prizes/medicine/1923/summary/)

![](https://peterattiamd.com/wp-content/uploads/2019/02/banting-best-photo-2843-landscape-gallery.jpg)

**Figure 4. Charles Best and Frederick Banting with a diabetic dog**. Image credit: [nobelprize.org](https://www.nobelprize.org/prizes/medicine/1923/banting/photo-gallery/)

*How long until* [*recombinant insulin*](https://www.thefreedictionary.com/recombinant+human+insulin) *was created?*

- Insulin for human treatment originally came from pigs
- A company called [Genentech](https://en.wikipedia.org/wiki/Genentech) produced [the first recombinant insulin](https://www.gene.com/media/press-releases/4160/1978-09-06/first-successful-laboratory-production-o)
- An “amazing article” about the molecular biology of modern insulin and the race to create it: [Cloning Insulin](https://www.gene.com/stories/cloning-insulin)

*Why the hell is recombinant insulin so expensive?!*

- It used to be so cheap, about $25 for 1,000 units (a month’s supply)
- Now 1,000 units costs $300-$400

Peter: *How is it that we have more competitors in the space, better technology today, and we’ve watched a log fold increase in the price of this stuff?*

Jake:

> “It’s a disaster on many levels. It’s really a disaster for people who are on the margins of society but want modern care and are willing to pay for it, but they can’t get insulin at the same price that, for instance, you could if you walked into a pharmacy in Spain. You could buy a vial of insulin for 25 bucks there. It’s three or 400 dollars here. The difference, unfortunately, is that the federal government is a … How shall I say it? A promiscuous customer. So they, thus far, have not been able to drive the price down because they’re willing to essentially pay whatever the sellers charge. That’s a big problem, and it speaks to the lack of market influence in things like insulin.”

## Diabetes Control and Complication Trial: blood glucose and the complications associated with diabetes [54:45]

*Why does diabetes lead to amputations, blindness and other microvascular complications?*

- *Blindness is from abnormal vessel growth* ⇒ there’s a series of damages that happen in the vascular endothelium, and then there’s new vessels that are created, and the new vessels are fragile and they can ultimately break and bleed
- *In the kidneys* ⇒ Basically very high glucose can alter the epithelia of the kidney that’s involved in filtering blood and making urine
- *Amputations are due to altered healing* ⇒ There are 2 parts to this:
  - First, there’s something called [diabetic neuropathy](https://en.wikipedia.org/wiki/Diabetic_neuropathy) where the nerves simply don’t work well and when exposed to high glucose they lose their responsiveness
  - The second part is abnormal healing because the the microvasculature isn’t behaving appropriately
  - Together, these issues can be very bad diabetic wounds that fail to get better with antibiotic and ultimately result in amputation

> “This is the most common cause of preventable amputation in the United States. It’s also the most common cause of preventable blindness in the United States, and probably also renal failure.”

[Diabetes Control and Complication Trial (DCCT)](https://www.ncbi.nlm.nih.gov/pubmed/8366922)

- The DCCT set out to test whether tight control of blood glucose (i.e. near normal ranges) confers protection against diabetes complications
- They found the answer to be yes, and they published their results in 1993
- In other words, as the average blood glucose increases, the microvascular complications increase as well
- Prior to the 1993 paper from the DCCT, it wasn’t obvious that the differences in these complications could be explained by the differences in their average blood glucose

*The challenge of controlling blood sugar in people with T1D*

- However, you can’t just throw a bunch of insulin at the problem because it could cause hypoglycemia, dangerously low blood glucoses
- The crux of the problem is the volatility in blood glucose
- So it’s not just so simple that you can figure out the amount of carbohydrates you’re gonna eat and take some insulin and your blood sugar is gonna be normal
- Stress, sleep quality, exercise all have an impact
- And the other things in food, like fat and protein, also alter gastric emptying and the end result is a tremendous amount of variance in the system
- So there is no exact formula of insulin to carb ratio

> “Your level of stress, how much sleep you had last night, how much exercise you’ve done or not done can even in the presence of the identical foodstuff produce completely different insulin requirements.”

*Details of, and the controversy around, the DCCT*

- Some well-meaning physicians thought is was foolish and dangerous to test this theory
- They were worried about hypoglycemia
- It’s a very difficult trial to do, because there were no established best practices to achieve near or normal blood glucoses at the time
- 1,441 patients with T1D
- Their average hemoglobin A1c for the population is around 9% at the time
- Their life expectancy is truncated dramatically and their quality of life is going to be, even by their 40s, they’re going to be quite compromised
- we know now from Swedish studies that somebody with with an average A1C of 9% has a six-fold increase risk of cardiovascular disease
- So the DCCT decided they wanted to get people under 6% A1C
- With a ton of effort, they managed to put together a plan that allowed them to achieve this
- Diabetic retinopathy and diabetic nephropathy were the outcomes they were measuring
- Trial was supposed to run for 10 years
- But the trial was stopped 7 years because the treatment group was seeing so much benefit from the intervention that it was no longer ethical to deprive the general population of this treatment

> “In some ways, it really makes the field of modern type 1 diabetes care, because it says there really is something you can do other than hold somebody’s hand and look for complications. But on the other hand, it actually breaks the field because we don’t have the apparatus to routinely achieve the kinds of outcomes that the NIH was able to do, because they had near infinite resources. They spent over $100 million for a relatively small number of patients.”

*Side effects of tight control of blood glucose:*

- Hypoglycemic events
- Weight gain

*Why did people gain weight?*

- This is one of the continual problems with type 1 diabetes, is if you jack up the insulin and your blood glucose is low, there’s only one thing you can do to get your glucose back up, eating refined carbohydrates
- You are essentially “chasing carbs”
- In the years since the DCCT, what we’ve seen is a huge number of people with type 1 diabetes have gained weight, in some cases, uncontrollably. And that is a really serious problem and moreover, the people who have gained the most weight have had poor cardiovascular outcomes.
- **Really important question**: Is the weight gain in type 1 diabetes absolutely obligate? Is it coincident with tight control? And it was argued by many that the only way towards tight control would be weight gain.

**30 year follow up to the DCCT:** [Update on Cardiovascular Outcomes at 30 Years of the Diabetes Control and Complications Trial/Epidemiology of Diabetes Interventions and Complications Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3868002/)

- Following the 7-year DCCT trial, the cohorts were merged followed for another 23 years
- During the 23 years, their A1C averaged about 8% (compared to 6% of the tightly controlled group)

*The amazing finding:*

- The group that received tight control for 7 years, had less cardiovascular disease and death than the group that received “conventional” treatment
- In other words, the 7 years of tight control still retained some benefit from the seven years, 30 years earlier

![](https://peterattiamd.com/wp-content/uploads/2019/02/DCCT-1024x469.png)

**Figure 5. Patients that received Conventional therapy had more cardiovascular events over the 20+ years following the experiment than those receiving the Intensive therapy during the DCCT.** Image credit: ([Lachin et al., 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3868002/))

## Cognitive impairment, epigenetic changes, and other dangers associated with high, peak blood glucose and big swings in blood glucose levels [1:09:15]

**Blood glucose peak and variability in T1D patients**

- In some of Jake’s more difficult patients, he sees the following:
  - Blood glucose around 180-200
  - With a standard deviation of 100

Peter’s personal standards

- Blood glucose of 90
- Standard deviation of…
  - +/- 10 (when fasting or keto)
  - +/- 15 when eating ad lib

> “100 means you’re bouncing around non-stop and never normal. . .and so that kind of volatility has just driven everybody insane, because they think there’s gotta be a better way.”

*Future “cures”*

- Many future treatments that could “cure” this are perhaps decades away, such as:
  - stem cells
  - maybe an auto-loop pancreas that would measure your glucose and administer insulin
  - Maybe some sort of beta cell regenerative therapy
  - Or something that just shuts down the autoimmune system.
- *So now the question becomes:* What do you do now to support people who live with type 1 diabetes today? How do you reduce that volatility?

**Dangers of exposure to high blood glucose and/or variability**

*Cognitive impairment*: Peter’s reading of the literature suggests that people, especially developing children, could have cognitive impairment associated with *high blood glucose variability*

*Epigenetic changes*:

- Jake says it could be the variability or it could the exposure to *high peak levels of blood glucose* could actually cause epigenetic changes
- Now there’s a whole rich field that’s devoted to this idea of these windows of hyperglycemia permanently altering these important cells that ultimately contribute to diabetes complications

> “Very short exposures to high blood sugars can completely change gene expression in a whole bunch of genes, like endothelial cells. So there’s a school of thought that says that diabetes complications are really around the exposures to these weird toxic levels of blood glucose that can occur.”

## Depression, anxiety and other challenges of living with T1D [1:15:30]

**Challenges of managing blood glucose**

- There is no perfect formula to manage it that is also practical and easy for a patient
- Jake said many doctors still struggle with this:

> “We this fantasy that we’re just going to sort of make people live in what I call the Diabetes ICU, which is a prescribed number of carbohydrates and timing and then we’re going to work towards making sure that everything was very predictable and the blood glucoses would be near normal much of the time. . .And I lived in that fantasy world unperturbed by reality until I became close friends with several people who have type 1 diabetes and then I began to see what they do.”

*The ultimate bio hack*

- Jake tells a story of a friend of his who lives with T1D
- She meticulously combs through her food to make sure she doesn’t eat anything that perturbs her glucose levels too much
- But it’s not just carbs she has to watch, she has to understand the balance of fats and proteins which can affect things as well
- But ultimately, she is finding a way to live her life while keeping her blood glucose “near normal”

*Parenting a child with T1D*

- Sending your small child to a birthday party where they eat 2 cupcakes and it can have devastating ramifications
- Jake has seen kids die when they go to college from fatal hypoglycemic episodes when they suddenly have tempted college kid stuff (drinking and eating) and they can’t manage their blood glucose even when taking the same insulin dose they did before

**Cognitive Load of living with diabetes**

- Jake defines the *cognitive load* as the burden of having to think nonstop about your diabetes
- “Nobody ever really just gets to be a parent or a kid, because there’s this constant fear of what’s my blood sugar? Is it high or low?”
- This leads to **anxiety and depression** for many of those with T1D ⇒ About 40-50% of people with T1D

*Quantifying the cognitive load with the “diabetes distress scale”*

- It’s a 1 to 10 scale that the patient answers
- 1=you know you have diabetes but it’s not holding you back at all. It’s there it’s in the back of your mind, it’s not bothering you. You get to do what you wanna do.
- 10=you have diabetes and you can’t think about anything else and it’s pretty much omnipresent and it alters your ability to carry out the things you wanna do.
- Average score of a teenager on a high-carb diet=7 or 8

*Guilt and shame*

- Jake says these people, especially teens, are rarely ever asked, *“How do you feel?”*
- Jake has teens burst in tears the moment he asks the question and they say “Ten”
- Up until that point they’ve been told they are listening and are being “non-compliant”, when in fact they are constantly thinking about it and living with the burden
- Jake says the medical establishment is reinforcing this:

> So this endless cycle of blame and shame and negativity is unfortunately in many cases, reinforced by the medical establishment. ‘Cause now you come and you got a hemoglobin a1c of 14 and what do you get? . . . you get a lecture about how you need to do a better job. You’re told you’re not compliant. You might even be threatened with being fired by your doctor unless you do a better job.”

*Changing lives with treatment*

- Jake says when he can connect with a patient and manage to get their A1C from 14 down to 7, for example, it changes their life (and Jake’s life)
- “They are finally able to think and feel and see the world around them and the love all these people who were trying to help them have that they couldn’t even recognize.”

## Jake’s realizes that the current standard of care of T1D is inadequate [1:26:15]

- Jakes original career plan upon finishing his fellowship and getting his first job as a professor at UPenn was that he was going to use basic science to advance outcomes for people with T1D by figuring out ways to grow new beta cells safely and reliably
- Meanwhile, he also had a clinical practice focused on T1D and other endocrine disorders
- He starts to become close friends with T1D and he is following them closely and watching the challenges and hacks they use
- In 2007, Jake is introduced to the original model of the continuous glucose monitor (CGM) made by Dexcom
- Jake is very excited thinking that this device will change everything
- However, it turns out that this first device was frustrating for patients because they didn’t really know what do with the information
- And the doctors involved in treating these patients didn’t have much advice other than to badger them to do a better job with managing their insulin doses and carbohydrate feedings
- Doctors would tell patients, “Oh, you need to check your blood glucose 20 minutes before the meal and give yourself insulin 20 minutes before the meal and do that in a very reliable way so that your blood glucose is normal.”

> “There’s a major problem in that we live in this fantasy world in medicine, where we think people just need to carry out their lives with more precision and that will be the answer but the reality is variance is contained in human behavior. It’s just what we do. So that idea of badgering people doesn’t work.”

## Managing diabetes with exercise [1:30:15]

**Insulin-dependent vs insulin-independent**

- The non-athlete gets most glucose into muscle via *insulin-dependent* pathway whereby insulin signals GLUT4 to move to the cell membrane (as described earlier at xx:xx)
- But there is an *insulin-independent* pathway to get glucose uptake into muscle

Exercise

- People can use exercise can help people control their diabetes
- Part of the mechanism is via the *insulin-independent* glucose uptake into skeletal muscle via [AMP kinase](https://en.wikipedia.org/wiki/AMP-activated_protein_kinase)

AMP kinase

- An enzyme that is sensing the energy status of the cell
- If you alter the energy status of the cell through a tremendous amount of work (exercise), it signals the GLUT4 to translocate to the membrane of the skeletal muscle
- So now you get insulin-independent glucose uptake into skeletal muscle

The unanswered question Peter still wants to know:

- What explains the increase in insulin sensitivity through exercise?
  - Is it that you are more sensitive to insulin itself (i.e. 1 unit of insulin invokes more GLUT4 translocation in someone who is exercising vs when they are not exercising) OR…
  - Is it more about AMPK and its effect on GLUT4 translocation?

Peter’s amazing patient with T1D

- Only takes 5 units per day (many people takes 60-70 per day)
- He walks 6-10 miles per day
- Only carbs he eats come from veggies
- Super low body fat, “I’ve never seen a higher [adiponectin](https://en.wikipedia.org/wiki/Adiponectin) and lower [leptin](https://en.wikipedia.org/wiki/Leptin) in a human I’ve ever measured. He is a lean, mean, machine.”

**Aerobic vs strength training**

- Jake believe aerobic is better for this purpose
- *What about HIIT training versus long durations?*
- - Jake says he sees long distance aerobic being most effective at dramatically reducing their total amount of insulin
  - However, it’s not known for sure… “there’s relative debate and this is not well-studied so you’d like to really carry out a proper study with high-intensity exercise versus very slow, long duration exercise.”

> “But this idea of trying to sort of hack the system to reduce the total exposure to insulin and therefore reduce the volatility and the hyperglycemic excursions, that’s really exciting, and I suspect that the people like your patient, who are done to [five] units of insulin, these people have really cracked the code.”

## The Bernstein method, and protein’s impact on glucose and insulin [1:36:15]

**Figure 6. Cover of Dr. Bernstein’s Diabetes Solution.** Image credit: [amazon.com](https://www.amazon.com/Dr-Bernsteins-Diabetes-Solution-Achieving/dp/0316182699)

[Dr. Richard Bernstein](https://en.wikipedia.org/wiki/Richard_K._Bernstein)

- He has a clinical practice in Westchester, New York treating specializing in diabetes
- He himself has type 1 diabetes
- He has been his own self-experiment for years and year

**Dr. Bernstein’s book transformed Jake’s thinking about treating diabetes**: [Dr. Bernstein’s Diabetes Solution: The Complete Guide to Achieving Normal Blood Sugars](https://www.amazon.com/Dr-Bernsteins-Diabetes-Solution-Achieving/dp/0316182699)

*The Law of Small Numbers:*

- If you consume more carbs, you need more insulin and therefore there’s a greater opportunity to make a mistake
- If you consume fewer carbs, you will consume less insulin and you’ll have fewer mistakes
- “It’s a very simple idea. It’s laid out along with a ton of practical tips in his book. He’s incredible.”

More details about his book and method:

- The book helps both those with type 1 and type 2 diabetes
- He figured out that if you avoided carbohydrates and if you give *medium and long acting insulin* to cover protein and fat and basal metabolic requirements, that you could get blood glucoses very, very close to normal
- He typically prescribes a *low carb, high protein diet* ⇒ It’s not low carb, high fat, it’s not ketogenic

Protein’s impact on insulin and how the Bernstein method manages it

- “In my patients with type one diabetes who consume protein and don’t cover it with insulin, they can get these massive glucose excursions.”
- we think in general there’s a ratio of around 10 grams of protein to end up being 6 grams of carbohydrate
- But the problem is the kinetics are not immediate, you don’t get gluconeogenesis in a matter of seconds, it’s delayed over hours
- And the essence of the Bernstein method is to try cover protein with insulin
- And he uses regular insulin (i.e. human insulin), not [fast-acting insulin](https://en.wikipedia.org/wiki/Insulin_aspart) (i.e. Novolog)
- And the idea is that regular insulin, which is human insulin, has a peak of onset within approximately an hour or two, and it lasts for six to eight hours
- So the regular insulin very roughly corresponds with the kinetics of what protein will do to your glucose

> “Unfortunately the insulin pump companies and even the insulin companies have advocated an approach that says, ‘Look, people who live with type one diabetes have tough lives. We need to support them, and they should be allowed to eat what they want. And they should just cover for it.’ . . .And the problem is you end up with these crazy oscillations. And the oscillations are associated again with a tremendous burden of illness and this cognitive load and this fear and this anxiety.”

## Jake radically changes his approach to treating patients [1:45:00]

- Jake’s patients are seeing great results
- Their average A1C is 5.7 (“normal as normal gets” says Peter)
- They also have fewer hypoglycemic events than most T1D patients with a A1C of 7

*How is he able to achieve this?*

- [CGM by Dexcom](https://www.dexcom.com/) has been tremendously helpful
- He encourages his patients to join the facebook group, [TypeOneGrit](https://www.facebook.com/Type1Grit/)
- And he has fully implemented the Bernstein method with his patients
- He also now sees way less patients so that he can spend much more time with each person

*Why see less patients?*

⇒ Jake says the question he wanted to answer is… if doctor’s have limitless resources that they could make available to a single patient, and the doctor would really try to listen and understand and support people, could these patients have transformative outcomes?

> “Medicine has essentially given up on these teenage kids who have hemoglobin A1cs of 10 or 12 or 14, who are basically on a super highway to death. These are the people who are going to have their first heart attacks when they’re 35. And they feel paralyzed. And they’re looking for somebody who can really understand how difficult it is and to provide a level of comfort and compassion.”

## What other tools are there for controlling T1D? [1:49:45]

First and foremost, a [continuous glucose monitor](https://www.dexcom.com/get-started-cgm/40?sfc=701f30000018vibAAA&gclid=Cj0KCQiA14TjBRD_ARIsAOCmO9ZLBdNUVujsH5EsQe1nyInRs2oJOfQ8cFijAek8zvJuAHkxpiC9lcUaAoRpEALw_wcB) (CGM) by Dexcom is essential (current model is the G6)

Next, it’s important to be informed:

- **Bernstein’s book**: [Dr. Bernstein’s Diabetes Solution: The Complete Guide to Achieving Normal Blood Sugars](https://www.amazon.com/Dr-Bernsteins-Diabetes-Solution-Achieving/dp/0316182699)
- **Book by Adam Brown**: [Bright Spots & Landmines: The Diabetes Guide I Wish Someone Had Handed Me](https://www.amazon.com/Bright-Spots-Landmines-Diabetes-Someone/dp/0692875174)
- **Facebook group**: [TypeOneGrit](https://www.facebook.com/Type1Grit/)
- **Various podcasts** ([here’s one](https://www.ontrackdiabetes.com/all-webinars-podcasts) as an example)
- **Youtube videos**: [Low Carb Down Under](https://www.youtube.com/user/lowcarbdownunder) created by [Dr. Rod Taylor](https://lowcarbdownunder.com.au/about/)

**Must watch video of lecture by** [**Dr. Troy Stapleton**](https://twitter.com/drtroystapleton?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor):

## Is the ketogenic diet appropriate for those with T1D? [1:52:45]

*People with T1D that are trying to get into nutritional ketosis have a few unique problems:*

**1 Diabetic ketoacidosis (DKA)**

- The normal person has an insulin response that suppresses ketones once it reaches the 6 or 7 millimolar level, where someone with T1D does not have the insulin to do this
- So they could reach dangerous levels of ketones resulting in DKA
- In other words, prolonged fasting in a person who lives with type one diabetes

**2 Euglycemic DKA**

- This is a new phenomena
- This is seen in T1D patients that are using sodium glucose co-transporter inhibitors ([SGLT2 inhibitors](https://en.wikipedia.org/wiki/Gliflozin))
- Mostly seeing this is people with T1D, not so much T2D
- WARNING: These are not safe (yet) for type 1 diabetics, however, Jake is involved in clinical trials looking to add safety and monitoring mechanisms
- How is euglycemic DKA happens:
- While taking the SGLT2, your CGM could be artificially showing a “normal” or low level of blood glucose
- So if you were to forget to take a shot of insulin, or your pump doesn’t recognize you need insulin, you could be in danger
- Because elevated blood glucose is the primary biomarker of life threatening insulin deficiency for people who live with type one

**3 Nutritional ketosis and hypoglycemic awareness**

- People who are in hardcore ketosis who have circulating beta-hydroxybutyrate may become completely immune to low blood glucoses
- In other words, there can be cases where someone has dangerously low blood glucose (say 25) and yet they feel fine due to the presence of ketones
- The problem, however, is that they may go from feeling fine to fatally low blood glucose without warning

## The most important lessons that can be applied by the non-diabetic population [1:59:00]

**Hyperinsulinemia leads to cardiovascular disease**

> “I think you have this unique population [type 1 diabetics] where you see the insulin that goes into them and you see it’s direct impact on weight gain. So we know that people consume very high carbohydrate diets and gain a bunch of weight in type one diabetes. They’re at risk for cardiovascular illness. And to me that just says that there’s something about the Standard American Diet that’s making us sick. And ultimately we will be at risk for cardiovascular disease.”

**Lessons from observing treatment options for type 2 diabetics**

*2 types of treatments*

1. Metformin, which lowers blood glucose
2. Drugs that raise insulin (to indirectly suppress blood glucose)

- Both of these groups have the same amount of microvascular outcomes (retinopathy, nephropathy, and neuropathy)
- But the higher insulin treatment groups get more macrovascular diseases (coronary disease, cerebrovascular disease, and peripheral vascular disease)
- This suggests that insulin is playing a bigger role on the macrovascular disease, and the glucose is playing the role in the microvascular disease

**In the case of SGLT-2 inhibitors…**

- They are the first drugs to have really shown a profound impact on cardiovascular diseases, says Jake
- [Empagliflozin](https://en.wikipedia.org/wiki/Empagliflozin), for example, which directs glucose to the urine and therefore reduces circulating insulin, reduces cardiovascular diseases by 40%
- Jake cites the work of [Cynthia Kenyon](https://en.wikipedia.org/wiki/Cynthia_Kenyon) (see the “Selected Links” section for more)

**Lessons learned from Peter’s patient with T1D**

*Jake believes there’s something to learn from people like Peter’s patient who has type 1 diabetes:*

- Low BMI
- Very active
- Low doses of insulin

> “And I just wonder whether carrying out these tricks to try to reduce your circulating insulin could be incredibly beneficial.”

## The two dream measurements Peter wishes were available [2:04:00]

- First, metabolic signature for [autophagy](https://en.wikipedia.org/wiki/Autophagy)
- Second, a way to measure the amount of insulin made by your pancreases over the previous 24 hours (a.k.a. Insulin AUC)

§

## Selected Links / Related Material

**Jake is an advisor for this pharma company who is developing** [**sotagliflozin**](https://www.lexpharma.com/pipeline/sotagliflozin)**, a drug for T1D**: [Sanofi](https://en.wikipedia.org/wiki/Sanofi) | (wikipedia.org) [6:00]

**Company that makes the best** [**continuous glucose monitors**](https://en.wikipedia.org/wiki/Continuous_glucose_monitor): [Dexcom](https://www.dexcom.com/) | (dexcom.com) [6:30, 1:27:45, 1:49:45]

**Top 5 pediatric centers in North America**: [9:30]

- [Boston Children’s Hospital](https://en.wikipedia.org/wiki/Boston_Children%27s_Hospital) in Boston | (wikipedia.org)
- [The Hospital for Sick Children](https://en.wikipedia.org/wiki/The_Hospital_for_Sick_Children) in Toronto | (wikipedia.org)
- [Children’s Hospital of Philadelphia](https://en.wikipedia.org/wiki/Children%27s_Hospital_of_Philadelphia) (C.H.O.P.) | (wikipedia.org)
- [Texas Children’s Hospital](https://en.wikipedia.org/wiki/Texas_Children%27s_Hospital) in Houston | (wikipedia.org)
- [UCSF Benioff Children’s Hospital](https://en.wikipedia.org/wiki/UCSF_Benioff_Children%27s_Hospital) in San Francisco | (wikipedia.org)

**Where Jake studied type 1 diabetes**: [Joslin Diabetes Center](https://en.wikipedia.org/wiki/Joslin_Diabetes_Center) | (wikipedia.org) [16:45]

**Proof of the role of beta cells in T1D**: [Rituximab, B-Lymphocyte Depletion, and Preservation of Beta-Cell Function](https://www.nejm.org/doi/10.1056/NEJMoa0904452) (Pescovitz et al., 2009) [25:15]

**Paper that has some evidence for the SAD being linked to T1D in kids**: [Excess BMI in Childhood: A Modifiable Risk Factor for Type 1 Diabetes Development?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5399656/) (Ferrara et al., 2017) [30:00]

**The work and research of Dr. George Eisenbarth on the genetics of T1D by looking at twins**: [George S. Eisenbarth: Insulin and Type 1 Diabetes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3661806/) (Pugliese et al., 2013) [35:30]

**The story of Banting and Best discovering insulin**: [Banting and Best: The Extraordinary Discovery of Insulin](https://www.spedmjournal.com/files/section/e8_s120_banting_and_best_the_extraordinary_discovery_of_insulin_file.pdf) | Cardoso et al., 2017 ([spedmjournal.com](https://www.spedmjournal.com/)) [39:15, 47:15]

**Book recommendation about the discovery of insulin**: [The Discovery of Insulin](https://www.amazon.com/Discovery-Insulin-Canada-150-Collection/dp/1487516576) by Michael Bliss | (amazon.com) [39:45]

**Article describing the Allen Starvation Diet**: [I Have Diabetes: What Can I Eat? A Journey Through the History of the “Diabetic Diet”](https://www.empoweryourhealth.org/taxonomy/term/191) | Alison Evert, MS, RD, CDE ([empoweryourhealth.org](https://www.empoweryourhealth.org/)) [40:15]

**The journal article read by Banting which lead to his famous idea about insulin**: [Relation of the Islets of Langerhans to diabetes with special reference to cases of pancreatic lithiasis](https://insulin.library.utoronto.ca/islandora/object/insulin%3AT10001) (Moses Barron, M.D., 1920) [47:45]

**The original paper published by Banting and Best after their discovery**: [The internal secretion of the pancreas](https://www.translationalres.com/article/S0022-2143(22)90384-1/abstract) (Banting et al., 1922) [50:45]

**An “amazing article” about the molecular biology of modern insulin and the race to create it**: [Cloning Insulin](https://www.gene.com/stories/cloning-insulin) | (gene.com) [52:00]

**First paper published by the Diabetes Control and Complications Trial (DCCT)**: [The effect of intensive treatment of diabetes on the development and progression of long-term complications in insulin-dependent diabetes mellitus.](https://www.ncbi.nlm.nih.gov/pubmed/8366922) (Diabetes Control and Complications Trial Research Group et al., 1993) [55:00]

**30 year follow up to the DCCT suggesting the 7 year intervention had retained benefits 23 years later**: [Update on Cardiovascular Outcomes at 30 Years of the Diabetes Control and Complications Trial/Epidemiology of Diabetes Interventions and Complications Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3868002/) (Lachin et al., 2014) [1:07:45]

**Cognition impaired during developmental years by higher variability of glucose**: [Alterations in White Matter Structure in Young Children With Type 1 Diabetes](https://care.diabetesjournals.org/content/37/2/332) (Barnea-Goraly, et al., 2014) [1:12:00]

**Cognition impaired during developmental years by higher variability of glucose**: [Longitudinal Assessment of Neuroanatomical and Cognitive Differences in Young Children With Type 1 Diabetes: Association With Hyperglycemia](https://diabetes.diabetesjournals.org/content/64/5/1770) (Mauras et al., 2015) [1:12:00]

**Dr. Bernstein’s book that transformed Jake’s thinking about treating diabetes**: [Dr. Bernstein’s Diabetes Solution: The Complete Guide to Achieving Normal Blood Sugars](https://www.amazon.com/Dr-Bernsteins-Diabetes-Solution-Achieving/dp/0316182699) by Richard Bernstein | (amazon.com) [1:35:15]

**Company that holds the conference calls amongst physicians and researchers interested in type 1 diabetes**: [Virta Health](https://www.virtahealth.com/) | (virtahealth.com) [1:36:30]

**A facebook group that offers a community and support for those living with T1D that is highly recommended by Jake**: [TypeOneGrit](https://www.facebook.com/Type1Grit/) | (facebook.com) [1:45:30, 1:51:00]

**Highly recommended YouTube channel about the intersection between low carb and T1D**: [Low Carb Down Under](https://www.youtube.com/user/lowcarbdownunder) | (youtube.com) [1:51:15]

**Must watch video of a lecture by** [**Dr. Troy Stapleton**](https://twitter.com/drtroystapleton?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor): [Dr. Troy Stapleton – ‘Low Carb Management of Type 1 Diabetes’](https://www.youtube.com/watch?v=n6LXtQqu0Ow) | Low Carb Down Under (youtube.com) [1:51:45]

**Book recommendation as a great resource on T1D**: [Bright Spots & Landmines: The Diabetes Guide I Wish Someone Had Handed Me](https://www.amazon.com/Bright-Spots-Landmines-Diabetes-Someone/dp/0692875174) by Adam Brown | (amazon.com) [1:52:15]

**Company that Adam Brown works for that is dedicated to improving the lives of people with diabetes**: [Close Concerns](https://www.closeconcerns.com/) | (closeconcerns.com) [1:52:15]

**An amazing drug that reduces circulating insulin which then reduces cardiovascular complications by 40%**: [Empagliflozin](https://en.wikipedia.org/wiki/Empagliflozin) | (wikipedia.org) [2:02:00]

**Cynthia Kenyon’s experiments in worms showing she could double their lifespan**: [2:02:45]

- [A C. elegans mutant that lives twice as long as wild type](https://www.ncbi.nlm.nih.gov/pubmed/8247153) (Kenyon et al., 1993)
- [daf-16: An HNF-3/forkhead family member that can function to double the life-span of Caenorhabditis elegans.](https://www.ncbi.nlm.nih.gov/pubmed/9360933) (Lin et al., 1997)
- [The first long-lived mutants: discovery of the insulin/IGF-1 pathway for ageing](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3001308/) (Kenyon, 2011)

§

## People Mentioned

- [Richard Bernstein](https://en.wikipedia.org/wiki/Richard_K._Bernstein) (The Bernstein method, author of the book that transformed Jake’s practice) [4:30, 1:36:15, 1:51:00]
- [Kevin Sayer](https://www.dexcom.com/dexcom-leadership/kevin-sayer) (CEO of Dexcom, got Peter hooked on CGM) [6:45]
- [Mark Pescovitz](https://boingboing.net/2010/12/13/mark-pescovitz-1955.html) (published proof that beta cells have a role in T1D) [25:15]
- [Maria Redondo](https://www.texaschildrens.org/find-a-doctor/maria-j-redondo-md) (published paper on BMI and T1D) [30:00]
- [Dr. George Eisenbarth](https://www.ucdenver.edu/academics/colleges/medicalschool/centers/BarbaraDavis/Pages/George-Eisenbarth.aspx) (genetics of T1D) [35:30]
- [Michael Bliss](https://en.wikipedia.org/wiki/Michael_Bliss) (author of The Discovery of Insulin) [39:45]
- [Frederick Banting](https://en.wikipedia.org/wiki/Frederick_Banting) (discovered insulin) [39:15]
- [Charles Best](https://en.wikipedia.org/wiki/Charles_Best_(medical_scientist)) (helping Banting discover insulin) [39:15]
- [Frederick Madison Allen](https://en.wikipedia.org/wiki/Frederick_Madison_Allen) (The Allen Starvation Diet) [40:15]
- [Elliott P. Joslin](https://en.wikipedia.org/wiki/Elliott_P._Joslin) (pioneer in diabetes research) [40:30, 1:01:45]
- [Derek LeRoith](https://icahn.mssm.edu/profiles/derek-leroith) (studies IGF) 46:30
- [Moses Barron](https://en.wikipedia.org/wiki/Moses_Barron) (wrote the 1920 journal article read by Frederick Banting that lead to Banting’s famous discovery of insulin) [47:45]
- [Maryanne Quinn](https://www.childrenshospital.org/directory/physicians/q/maryanne-quinn) (pediatric endocrinologist, and friend of Jake’s, who has T1D herself) [1:17:51, 1:26:15]
- [Morris White](https://www.childrenshospital.org/research/researchers/w/morris-white) (Jake worked is his lab studying insulin signaling) [1:26:45]
- Natalie Bellini (pharmaceutical sales rep that Jake is friends with who sells drugs for T1D and she herself has T1D) [1:27:30]
- [Laurie Goodyear](https://www.joslin.org/_diabetes-research/Laurie-Goodyear-PhD.html) (studies AMPK at Joslin Diabetes Center) [1:34:45]
- [Dr. Rod Taylor](https://lowcarbdownunder.com.au/about/) (Low Carb Down Under) [1:51:15]
- [Dr. Troy Stapleton](https://twitter.com/drtroystapleton?lang=en) ([must watch lecture](https://www.youtube.com/watch?v=n6LXtQqu0Ow)) [1:51:45]
- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) (American scientist who significantly advanced the diabetes mellitus research of the 20th century) [1:58:30]
- [Peter Thiel](https://en.wikipedia.org/wiki/Peter_Thiel) (“Is this a feature or a bug?”) [1:58:45]
- [Dr. Cynthia Kenyon](https://en.wikipedia.org/wiki/Cynthia_Kenyon) (insulin signaling work where she was able to make worms lives twice as long) [2:02:45]

§

![](https://peterattiamd.com/wp-content/uploads/2019/02/bio-image-1.jpg)

##### Jake Kushner, M.D.

Dr. Jake Kushner, a nationally renowned expert in type 1 diabetes research, served as Chief for Texas Children’s Diabetes and Endocrinology and the Section of Pediatric Diabetes and Endocrinology at Baylor College of Medicine from 2011 to 2017. Dr. Kushner is a University of California at Berkeley graduate. He earned his medical degree from Albany Medical College in New York and completed his residency in pediatrics at Brown University and clinical fellowship at Children’s Hospital Boston as well as a research fellowship at the Joslin Diabetes Center at Harvard Medical School. Dr. Kushner was previously with the University of Pennsylvania School of Medicine and the Children’s Hospital of Philadelphia (CHOP) as an assistant professor in the division of endocrinology and diabetes. His research is focused on the insulin-secreting beta cells of the pancreas. His clinical interests include the care of children with type 1 diabetes, cystic fibrosis related diabetes, and the treatment of children with hypoglycemia. [[bcm.edu](https://www.bcm.edu/about-us/leadership/office-of-the-president/initiatives/mcnair-scholars-program/mcnair-scholars/jake-a-kushner)]

Jake currently serves as medical director of McNair Interests, a private equity group with investments in type 1 diabetes and other chronic illnesses. His primary focus is to leverage existing and future medical-related investments and resources for McNair Interests to help individuals with chronic illnesses.

Twitter: [@JakeKushnerMD](https://twitter.com/jakekushnermd)