# #281 ‒ Longevity drugs, aging biomarkers, and updated findings from the Interventions Testing Program (ITP) | Rich Miller, M.D., Ph.D.

**Source:** [https://peterattiamd.com/richardmiller2/](https://peterattiamd.com/richardmiller2/)

---

Richard Miller is a professor of pathology and the Director of the Center for Aging Research at the University of Michigan, as well as a [previous gues](https://peterattiamd.com/richardmiller/)t on *The Drive*. In this episode, Rich provides an update on the exciting work of the Interventions Testing Program (ITP), an initiative designed to assess potential life-extending interventions in mice. Rich covers the notable successes like rapamycin, 17⍺-estradiol, and acarbose as well as notable failures like nicotinamide riboside, metformin, and resveratrol, providing valuable lessons about the intricacies of the aging process. Rich delves deep into aging biomarkers and aging rate indicators, unraveling crucial insights into the science of geroprotective molecules. Additionally, Rich discusses some surprising successes of recent molecules tested by the ITP and concludes with an optimistic look at future frontiers, including bridging the gap from mice to humans.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/richardmiller2/the_Drive_public.png)

Play

#281 ‒ Longevity drugs, aging biomarkers, and updated findings from the Interventions Testing Program (ITP) | Rich Miller, M.D., Ph.D.

#281 ‒ Longevity drugs, aging biomarkers, and updated findings from the Interventions Testing Program (ITP) | Rich Miller, M.D., Ph.D.

1x15s30s

0:002:23:57

## We discuss:

- An overview of the Interventions Testing Program (ITP) [3:45];
- How the mice used by the ITP are superior for research relative to mouse models used in most research [11:15];
- Design of ITP studies, outcomes tested, and metrics of interest [19:00];
- The process and challenges of drug formulation for mice [30:00];
- Four drugs identified by the ITP that extends the lifespan of mice [36:30];
- The success of rapamycin and what that tells us about the biology of aging [43:15];
- Other measures of healthspan evaluated by the ITP in stage 2 studies [50:45];
- Distinguishing aging rate indicators from biomarkers of aging [57:30];
- Aging rate indicators identified through the examination of slow-aging mice [59:15];
- Why proteomics are essential to understand changes in the cell [1:12:15];
- Unraveling aging rate indicators: dose-effect, duration, and future frontiers [1:21:45];
- A closer look at the aging rate indicators: bridging the gap from mice to humans [1:27:00];
- What do laboratory mice die from? [1:38:45];
- Distinguishing between a drug that improves an age-sensitive outcome and a drug that improves all aspects of aging [1:42:00];
- The ITP study of 17⍺-estradiol: mechanisms of life extension and surprising sex differences [1:43:30];
- Unsuccessful drugs studied by the ITP: resveratrol, metformin, and nicotinamide riboside [1:51:30];
- Over-the-counter successes in the ITP: meclizine and astaxanthin [2:01:00];
- A senolytic drug, fisetin, fails to extend lifespan [2:07:00];
- Can targeting senescent cells slow aging? [2:13:00];
- Optimism about future findings [2:16:30]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Dr. Richard Miller (Rich) was a previous guest in [February of 2021](https://peterattiamd.com/richardmiller/), and that was such a remarkable episode that Peter knew at that time we were going to have to do another one
  - And we’re going to do a part three at some point as well
- Rich is a professor of pathology at the University of Michigan where he is also the director of the university’s Paul F. Glenn Center for Biology of Aging Research
- He is also one of the principal architects of the [Interventions Testing Program (ITP)](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp), created to evaluate potential life-extending interventions in mice
- Rich received a bachelor’s degree at Haverford College and then went on to earn an MD and PhD at Yale, followed by postdoctoral training at Harvard and Memorial Sloan Kettering
- You have no doubt heard Peter talk about the ITP, not only in the first episode with Rich, but it seems to come up all the time when we talk about geroprotective molecules [see previous episodes of *The Drive* listed under “selected links”]

***Geroprotective means molecules that extend lifespan, but not through targeting a very specific disease process, but rather by targeting the hallmarks of aging***

- In this episode, we talk about the ITP, not in as much detail as we did in the [first episode](https://peterattiamd.com/richardmiller/) because if you really want to understand that, you can go back and listen to it
  - But for those who don’t remember or haven’t listened to the first episode, we certainly cover enough here so you can understand it
    - What its purpose is
    - How its mouse model is significantly different and demonstrably better than all the other mouse models used out there
    - How the studies are conducted: what the metrics of interest are, how drugs are dosed and delivered, and more
- We also talk about how the ITP looks at healthspan, not only lifespan
- We cover notable successes from the ITP including rapamycin, 17⍺-estradiol, acarbose, canagliflozin, and a few others of late
- We talk about some of the most recent successes, including one that absolutely blew Peter’s mind: meclizine, which is an over-the-counter drug used to treat seasickness
- Additionally, we do a deep dive into the idea of biomarkers of aging and what we know about various aging rate indicators
  - Peter found this to be the most important and interesting part of the discussion because he’s quite steeped in some of the drug stuff
- We end the discussion speaking about some of the most notable failures, including nicotinamide, riboside, metformin, and resveratrol

## An overview of the Interventions Testing Program (ITP) [3:45]

- The [ITP](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp) was developed by the [National Aging Institute (NIA)](https://www.nia.nih.gov/) under the leadership of [Huber Warner](https://www.nia.nih.gov/news/nia-mourns-loss-dr-huber-warner) about 20 years ago
  - We are now finishing our 20th year
  - We’ve sent in applications and may get five more years of funding
- The ITP represents work being done by three different research laboratories
  - 1 – Rich’s at the University of Michigan
  - 2 – [Randy Strong’s](https://barshopinstitute.uthscsa.edu/team-member/strong-randy/) at the University of Texas Health Science Center at San Antonio
  - 3 – And a program at the Jackson Labs where [David Harrison](https://www.jax.org/research-and-faculty/faculty/dave-harrison) was in charge
    - David will be stepping down next April and he will be replaced by [Ron Korstanje](https://www.jax.org/research-and-faculty/faculty/ron-korstanje) as the first new appointment for the ITP leadership at the Jackson Labs

***The ITP tries to find drugs that will slow aging and extend mouse lifespan***

- We have a national announcement every year internationally
  - Anyone who wants to suggest a drug sends us an application and they tell us why they think we should test their drug and why they think it will be good and not hurt the mice
  - We have a committee that evaluates those and then we pick 5-7 each year to see if giving them to the mice will extend lifespan

**ITP findings and more about their studies**

- We’ve had four published significant hits
  - Another two or three that are significant, but really small
  - And two others that are in-press that should be accepted soon
- We give these drugs to mice at varying doses to see if it’s dose sensitive
- We look at the methodology
- We make tissues that we can give away to other investigators for collaborative studies
- We try to reason about mechanisms of aging and control points for aging based upon which drugs work and which drugs don’t work
- A lot of people see this as a stalking horse for the important goal of ***finding drugs that would extend lifespan by slowing aging in people*** (and Rich agrees)
  - That is an important element, *but there are many steps between a mouse drug and a human drug*

***The other major things that our program does is it really gives us a lot of insight into the biology of aging, and it should give us many clues as to what to look at that may be successful***

**How many candidates typically get nominated for testing?**

- It varies a lot from year to year
- This year was our winner with 28 suggestions
- They have enough money to test 5-7 of them
- In a typical year, 10-15 drugs are nominated, from which they pick 6
- Sometimes we fill up those slots with things that we want to do
  - For instance, we found a couple of years ago that [captopril](https://en.wikipedia.org/wiki/Captopril) (FDA approved in people for blood pressure) gave a really small increase in lifespan in mice
    - Mice don’t die of hypertension, they don’t get strokes, etc., so Rich was betting against that, but it was a really small effect
    - We decided in the current year to try captopril again, but at a higher dose
- Some of the slots each year at taken up with other doses, other dosage forms
- Often, if a drug works when you give it to young adults, we next test it in middle-aged mice
  - Everyone would like to know whether a drug would only work if you give it to young adults
  - We would love to find drugs that work in middle age, so that often fills up one of those available slots

**What is the budget? What does the NIA provide to the three laboratories?**

- They give $1 million a year to each of the three sites in *direct costs*
  - The actual cost to the taxpayer is probably about 50% more than that because each university will also receive *indirect costs* to pay for the building and the heat and the police force and the library and the president and all of that stuff
  - In total, it’s about $4.5 million per year
    - Peter thinks this is a relatively poultry sum of money when you consider the insights that come out of the ITP (that’s his way of lobbying for the budget being increased)
- In the first 10 years they had half a million dollar and the NIA thought they were doing good work so they doubled their budget

**There are 17 divisions within NIH, of which NIA is one. What is the NIA’s annual intramural and extramural budget?**

- Rich doesn’t know but it’s one of the larger institutes now (it didn’t used to be)
  - However, that’s misleading because more than half of their budget goes to Alzheimer’s disease
    - They have, through a variety of negotiations, been designated the lead agency for Alzheimer’s
- Their budget is big, but their budget for all of biology is only ⅙ of the NIA budget
  - And for the kind of biology that Rich cares about, it’s much, much less
- A lot of the good biology is what happens to bone aging
  - What happens to eye aging
  - What happens to aging of the immune system
- All of that is interesting research, but the stuff Rich cares most about is aging as a global phenomenon
  - What you can do to slow aging
  - How it is that aging increases your risk of almost everything you don’t want to happen to you
  - That part of the NIA budget is small

**Is there an opportunity for philanthropic giving to plus-up the NIA contributions?**

- Rich doesn’t think the NIA accepts donations
- However, a philanthropist, should he or she be listening to this podcast, can certainly set up independent arrangements
  - For instance, if they wish to have support for all three sites in the ITP, one can imagine a situation in which a foundation makes awards
  - The universities do have the flexibility to take gifts and target them to specific research groups or specific research projects, either independently or as a consortium

## How the mice used by the ITP are superior for research relative to mouse models used in most research [11:15]

**Tell us about the standard, off-the-shelf mouse model**

- One of the hallmarks of the ITP is the mouse model used is different from some of the more typical mouse models used in biomedical research
- Most requests for aged mice to the National Aging Institute were for the same kind of inbred mouse: its formal name is C57BL/6, and everybody calls it the [B6 mouse](https://www.jax.org/strain/000664)
  - This is the standard mouse and it’s a really bad thing for science, not just aging science, but that science in general relies on an inbred mouse
- **Problems with inbred mice**: it’s a single genotype and it has been shown many times now that if you have a drug that works in BL6 mice, it might or might not work in another kind of mouse
  - It might have the opposite effect in another kind of mouse
- People study the BL6 mice in the mistaken belief that it’s sort of like mice in general, despite the now really quite convincing evidence that it isn’t

**The ITP made the decision to use a genetically heterogeneous mouse called** [**UM-HET3**](https://www.jax.org/strain/036603?utm_source=google&utm_medium=ppc&utm_campaign=2023_aging&utm_content=search&gad_source=1&gclid=CjwKCAjwkY2qBhBDEiwAoQXK5VXOh5cF6Z12y6J8Zy-X1DRZWqcBYhdV3s3g3hcLu_ShdooNibISmBoCc7AQAvD_BwE)

- It was controversial but in retrospect was a really good decision
- UM refers to where it was first derived, and HET is for heterogeneous
- These are mice which essentially have the same set of grandparents [illustrated in the figure below]
  - So any two mice in our population share half of their genes, just like you would share half of your genes with a brother or sister
    - But it’s a random half
    - So if we have two mice, we don’t know which genes they’ll share though we know it’ll be half of them and half of the genes will be different

![](https://peterattiamd.com/wp-content/uploads/2023/11/f1-richmiller2.png)

**Figure 1. UM-HET3 mice are generated by crossing four inbred strains**. Image credit: [*Science* 2022](https://www.science.org/doi/10.1126/science.abo3191)

- The advantage of this system is you can make as many of these mice as you want anywhere in the world at any time, year after year after year, you’ll get the same *population* characteristics

***No two mice are identical, but all populations of UM-HET3 genetically are identical with one another; so it’s a form of reproducible heterogeneity***

- If we tested a drug that worked in BL6 and only tested in BL6, we really wouldn’t know whether it would work in any other stock
- Similarly, if we had tested a drug that failed to work in BL6, we would’ve fooled ourselves into thinking that it was a loser drug

***Since there are hundreds of thousands of genotypes available in the UM-HET3 population, it’s really unlikely that one weird genotype would either trick us into believing something to be true when it really isn’t or trick us by missing a good response***

**The other ancillary benefit is you can map genes**

- There’s a set of collaborators, including [Rob Williams](https://www.uthsc.edu/faculty/profile/?netid=rwilli10) at Tennessee and [Johan Auwerx](https://people.epfl.ch/johan.auwerx?lang=en) in Switzerland, which have taken these mice
  - We’ve given them at this point something like 12,000 DNA samples from mice that have a known lifespan and they have already published a [paper](https://www.science.org/doi/10.1126/science.abo3191)
  - It came out last year in Science and there’s another paper in the pipeline now that says, “*Here’s a gene that tells you how long the females will live. Here’s a gene that tells you how long males and females will live. Here’s a gene that tells you how long you’ll live, but it only counts if you’ve made it past the midpoint, it only works on the oldest half of the mice*.”

> “*There are hints to human genetics lying within that and it gives you new tools for thinking about and then working out ideas about the ways in which your inheritance modifies your aging and maybe even your response to drugs.*”‒ Rich Miller

**For listeners who aren’t as familiar with genetics, explain the significance of the UM-HET3 mouse relative to the BL/6**

- BL/6 mice are not only identical, they are [homozygous](https://en.wikipedia.org/wiki/Zygosity#Homozygous)
  - The gene from the mom and the gene from the father are the same (inbred)
- We don’t have a human phenotype that is that inbred
  - People avoid inbreeding because you get very sick people, a lot of deaths, a lot of deformities, a lot of mental disabilities
- Inbred mice almost always have something terribly wrong with them
  - Nearly every kind of mouse that’s used in aging research is fully deaf by one year of age
  - Many of them are blind
  - Many of them get a single disease which is not representative of mice in general

***The problem with inbred mouse strains, is what is the likelihood that what you learn is relevant to strains that are not inbred and people***

- Rich explains, “*If you want to see if your drug works, you sort of have to test it on people who are not identical genetically to one another. Yet that sort of thing, which is so obvious in human analogies, is ignored by nearly all mouse scientists.*”

**Why is biomedical research being done in the BL/6 model if we want to have some translational insight?**

- Tradition: if you’re a scientist setting up you own lab, your mentor used BL/6, so all of your preliminary data us ub BL/6
  - You may want to test it in other mice but money is limited and you can only afford one kind of mouse
  - They don’t look at a roadmap or think about the optimal path to take
  - They just followed the person who trained them, who’s following the person who trained them, etc.

**What inbred mice are good for**

- 1 – They’re almost always sick, so they’re good if you want to study some kind of sickness
  - If you want to study lymphoma, you use an inbred mouse strain that gets lymphoma
  - Or hereditary deafness or something
- 2 – They are critical for transplantation
  - There are a lot of experimental designs where you have to take cells from one kind of mouse and stick it into another mouse, but for that to work, both mice have to have the same [genotype](https://en.wikipedia.org/wiki/Genotype)
    - Inbreds are still bad for that
    - The right ones you want to do are the children of two different kinds of inbred mice, called an [F1 mouse](https://en.wikipedia.org/wiki/F1_hybrid)
    - F1 mice are better because they live longer, they’re less sick
- 3 – You can use inbred mice to construct real mice, like the HET-3 mice
  - They’re good building blocks, like Lego blocks, but to do science on them is almost always a mistake

## Design of ITP studies, outcomes tested, and metrics of interest [19:00]

**What are the metrics of interest?**

- 1 – The primary outcomes, the things that we do our statistics on are the proportional hazard, the risk of death over the whole lifespan
  - The closest easily understood term is the median lifespan
    - It’s not quite correct, statistically, but nearly always it’s a good shortcut to say, “*See, this extended the median lifespan by 20% or 5%,*” or whatever
  - The **median lifespan** is the ***age at which half the mice have died and half are still alive***
    - So if half of the mice in the normal group died by 800 days and in the drug-treated group, half of the mice were still alive on day 880, that’s 80 days later, then that’s a 10% increase in lifespan (a nice big jump)
- 2 – We also always calculate some measure of maximum lifespan
  - The actual **maximum lifespan**, the age at death of the last mouse to die is statistically not very useful, not valid
    - It varies so much depending on the population size and just the luck of the draw
  - What we do is a better way, which was worked out by [David Allison](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=allison) about 20 years ago
  - The test statistic we use is we wait until 90% of the mice are dead in both populations, the control and the treated population, and then ***on the date when the 90th percent mouse dies, we say what fraction of the mice are in the treated group of the ones that are alive and what fraction of the mice are in the control group***
    - With a good drug 80% of the mice on this date will be in the treatment group and only 20% in the control group
- Peter checks his understanding, “*You have to wait until, in both groups, there’s only 10% or less remaining? Because that’s obviously going to occur at a different time.*”
  - Yes
  - What you do is you make your list of all the ages of death in both groups
    - Then you figure out what age is the age at which 10% is still alive in the pool together and 90% have died in both groups
  - So your looking at both groups in the total pool of mice in the experiment

***When 10% of the pool is alive, you see what fraction of these mice are in the treated group***

- If it’s a 50-50 mix, the drug doesn’t work
- If it’s 80% treated and 20% untreated, you’ve got a winner

**Was there ever a test that looked at the 95th percentile for each group and compared those time horizons as a surrogate or proxy for maximal lifespan?**

- You can do that, you can do the 99th percentile, but there are a couple of technical concerns
  - The further you push that up (95, 99, 99.9), the fewer mice you have to work with and the [statistical power](https://en.wikipedia.org/wiki/Power_of_a_test) drops
  - You’ll miss a lot of stuff if you only have one or two mice alive at that age
- We’ve picked the 90th percentile because there’ll still be a few dozen mice alive at that age, at the 90th percentile
- The other thing you want to be really careful of is defining your test and then picking the test that looks best
  - We could have some groups actually do this, though it’s sort of unethical
  - They look at the 80th percentile, the 85th, the 90th, the 95th, and then they say, “*Oh, it looks best at the 90th. Let’s pick the 90th*.”
    - That’s not a good thing
    - You will fool yourself
    - You’ll get false positives
- So we define, arbitrarily, 90th, and we’re going to do it at the 90th percentile all the time
  - It’s pre-specified

**Do you come up with a new power analysis for each experiment, or do you generally power them the same and therefore have the same number of mice in each ITP?**

- Yeah, we use the same number of mice in the control group and the same number of mice in the treated group each and every year
- Of course, before we start, we don’t know whether it’ll be a good year or a bad year
  - Some years the mice live 5% longer or shorter than in previous years
- And we also don’t know which drugs will work, and the ones that do work, we don’t know how big an effect they’ll have
- With the assistance of two professional statisticians, we worked out the number of mice we want to have in each group, and our criterion is we wanted to have at least an 80% chance of picking up a significant result, even if one of the three sites had a disaster (like an air conditioning failure or a viral infection)
  - This was 21 years ago, and so far we’ve only had something like that happen once
  - We want to have an 80% chance of picking up an effect that’s at least a 12% effect, up or down (a two-sided test), even if only two sites survive
  - We use that amount to determine how many mice we’re using
- Now, in practice, we can almost always combine all three sites together
  - We almost never have a site-specific disaster
  - And that means ***in practice that we have 80% power to detect drugs will give us about an 8% increase or a 10% increase***
    - 12% was kind of conservative

**What does that amount to in total mice usage for a given drug?**

- At each site, we are using 100 male controls and 100 female controls
  - So pooling [each of the 3 sites] that’s 300 males and 300 females in the control group each year
- And for each drug we use 50 males and 50 females
  - That is half as many as the controls, again, at each site
  - So for any one drug, 50 times three is 150, we have 150 male mice distributed across three sites and 150 female mice distributed across three sites
- We over sample the controls as we double the size of the control group because we’re going to compare controls to Drug A, controls to Drug B, controls to Drug C
  - So in a sense we’re reusing, we’re getting our best mileage out of the controls since we can increase statistical power for every one of those pairwise comparisons by adding extra mice to the control group
- In other words, if you’re doing a five-drug trial, there will be a total of 300 male, 300 female controls, but there will be 750 total male, 750 total female on the combination of drugs being tested

**What is the range or variability in lifespan, both median and maximal, for the controls?**

- Rich has done this now for nearly 20 years
- We got something we didn’t expect to see, but we’ve seen it almost every year for the last 20 years
- We were hoping that the **three survival curves** (that is one at each site) would always be superimposable, because we’re all really good at taking care of mice
  - For females, that was correct
    - There’s been one year, 2017, where that was not the case, but most of the time it’s the same
  - For males however, there is a persistent and consistent difference that we do not understand
    - Males at Michigan always live 5%-10% longer than males at the other two sites
    - We’ve tried to do everything we can to eliminate it and we have failed
- We also know that there are site-specific differences that are read out as weight, and here it works in both males and females
  - The Michigan mice controls are about 10% lighter, both in males and females than mice at the other two sites
- Despite our best efforts, we get the food from the same place, the bedding from the same place, the mice from the same place, we breed them in the same months,
  - Trying desperately to get them to come out the same way in all three sites, and we’ve gotten close, better than many people would do, but not perfectly
- Peter finds it interesting that both males and females at Michigan are 10% lighter
  - Presumably they’re eating less or moving more
  - Yet it only translated to a survival benefit in the males and not the females
    - The causality of that is uncertain

**Does that allow you to still pool the results for the males?**

- Yes, but we do it with a very standard, not an esoteric statistical trick
- These sites stratify
- That is, the survival curve for the Michigan males controls is compared to the survival curve for the Michigan drug treated mice
  - And the survival curve for Texas controls to the Texas drug treated mice, etc.
- Then what the statistical program does is it pools those three sets of results to come up with one overall statistic
- In every paper, we also report separately, here’s what we saw at Michigan, here’s what we saw at Texas, here’s what we saw at the Jackson Labs
- But our primary hypothesis, the thing that allows us to put the name of the drug with the word winner in the title of the paper is the pooled result in which the results have been stratified
  - And we stratify the test for maximum lifespan, the [Wang-Allison test](https://pubmed.ncbi.nlm.nih.gov/15491681/), we adjusted that to make it stratified also

## The process and challenges of drug formulation for mice [30:00]

**How much complexity is there year after year, drug after drug to create a good formulation of the drug to give the mice?**

*How are you thinking about the dosing frequency, the dose itself?*

*And how do ensure that the animals indeed get the amount that you want?*

- We’ve put a lot of effort both in planning it and then executing it
- The University of Texas is led by [Randy Strong](https://barshopinstitute.uthscsa.edu/team-member/strong-randy/) who’s a pharmacologist and he has a colleague, it used to be [Marty Javors](https://directory.uthscsa.edu/academics/profile/javors) and now [Brett Ginsburg](https://directory.uthscsa.edu/academics/profile/ginsburg) has taken over that role and devotes a lot of his time to asking exactly that sort of question
- For example, before we give any food to mice, we make a batch of food with drug in it and Brett’s lab takes it and measures the amount of drug in the food
  - And if it’s 5% of what we thought it would be, something has gone wrong
    - And so we try to work out, should we dissolve it first in alcohol? (again Brett is an expert at this)
    - Should we incorporate it in the form of a corn oil suspension?
    - What’s the best way to get it into the food?
- Brett works with [Peter Reifsnyder](https://www.jax.org/research-and-faculty/research-labs/the-harrison-lab) (who runs the lab at the Jackson Labs), and when Brett and Peter have shown that they can make food with the stuff in it and is at the right dose, we then give it to mice for 8 weeks
- Tissues from these mice then go back to Brett so Brett can say, “*Yep, the tissue of the drug treated mice has this amount of drug in the liver and this amount of drug in the plasma*.”
- It’s only at that point that we actually press the button to say, “Y*es, we are going to use this drug in a lifespan experiment*.”
- From those **pilot mice**, Rich’s lab gets their livers and look at a batch of mRNAs
  - We’ve picked RNAs in the liver that we know are almost always sensitive to drugs
- If the drug was given to the mice and nothing happened in the liver, we start to get worried
  - Maybe the drug was excreted quickly and didn’t have any biological effect whatsoever

**A famous problem occurred early on in testing rapamycin**

- About 90% of the rapamycin that was given to mice in the food never made it into the mouse because it’s digested in the stomach
- It was degraded in the acidic conditions of the stomach
- [Randy](https://barshopinstitute.uthscsa.edu/team-member/strong-randy/), with colleagues of his, worked out a way to encapsulate the rapamycin in a plastic capsule that makes it through the stomach and dissolves in the more alkaline conditions of the small intestine
  - That was a way of tricking the body into getting the rapamycin to the portion of the GI tract where it could be absorbed
- It’s not uncommon for Brett to have to say, “*Well, this is not going to work unless we dissolve it in a little bit of alcohol before we mix it into the food.*”

**Data on blood concentrations can alert us to potential problems**

- For instance, in many of our papers we published (12 papers now on rapamycin), almost always rapamycin has been giving a larger percentage increase *in females* than in males
- The Texas group showed that the blood concentrations are threefold higher in females than in males
- We haven’t proven that that’s why the females live longer or have a greater percentage increase, but it’s certainly very plausible
- We’ve stumbled onto a similar situation with [canagliflozin](https://en.wikipedia.org/wiki/Canagliflozin) ([published](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7710304/) a few years ago)
  - We found lovely lifespan increase but it was in *males only*, not in females, which is really weird because it’s a great drug for diabetes in men and women without sex differentiation
  - We thought it would work great in both sexes
  - It turns out that the blood concentration in female mice is 3x higher than in males, and as they get older and older and older, the blood concentration in the old females is 10x the concentration of young males
    - And it’s probably toxic
  - We now are going back to test a much lower dose in females (maybe that’ll work)
    - Or let’s give it to females but stop when they’re middle-aged so it won’t ever reach the really high toxic concentrations

***All of these assessments of drug levels allow us to be on the alert for problems of that sort and to come up with ideas for how we might solve them***

**Is every candidate drug administered in food?**

*You’re not testing intravenous drugs or intramuscular drugs?*

- That’s correct, although there’s a footnote that we’ll get to
- We could give a drug in water if there was some reason in which it wouldn’t get into the food
- We can’t give it to animals intravenously or intramuscularly because it’s so much work
  - To give 150 males, 150 females, giving 300 shots a day or a week or a month would be a mess
  - In addition to which we’d have to have a separate control group that got a saline shot
  - And we couldn’t use regular old mice as our control; we’d have to have a separate control group to do that
- A footnote: you can imagine a specific situation if someone said, “*I’ve got an antibody*,” or something, and “*All you really have to do is give it to them once and it will flip their immune system forever into a good configuration. Please give my drug. Has to be given by injection, but only one time.*”
  - We could consider that
  - We might need a separate once only sham group [control group] also, but that’s the only exception to the rule that we would think seriously about

**How are you regulating the actual dose?**

*In other words, how are you monitoring the amount of chow that’s consumed since the amount of chow that’s consumed is proportional to the drug that’s consumed?*

- We have no idea how much food any one mouse eats, and therefore we have no measurement on a mouse-by-mouse-basis on how much of the drug they’ve consumed
- We know, of course, that smaller mice eat less food than larger mice, so they will get less drug per mouse but probably about the same amount of drug per gram of lean body mass, or something like that
- There’s no way to control that other than by putting individual mice in individual cages, which has its own major problems
  - Mice are very social creatures and they don’t like isolation cages any more than people do
- Monitoring the actual amount of food a mouse eats is a fiction
  - No one can really do it
  - They can put a number down and get into the paper, but it’s a fictitious number
  - The reason is that mice chew their food and leave a lot on the floor of the cage
    - So you don’t know how much food the mouse has actually gotten into itself because you haven’t measured little crumbs on the cage floor

## Four drugs identified by the ITP that extends the lifespan of mice [36:30]

**In total, how many drugs have been run through the protocol in the last 20 years?**

- It’s about 100 [listed on the [NIA website](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp/supported-interventions)]; Rich would have to go to their recent [review article](https://www.thelancet.com/journals/ebiom/article/PIIS2352-3964(16)30554-0/fulltext) and then add some more drugs to it

*So there are many more experiments than a hundred?*

- Yes, that’s right

**What was the first exogenous molecule that proved a lifespan extension success for the ITP?**

- [Rapamycin](https://en.wikipedia.org/wiki/Sirolimus), our [2009 paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) had a really big effect
  - We picked a dose that seemed like it might work, and it did
  - It’s less than the optimal dose, but the dose we chose, both males and females, had a significant lifespan extension

***To put this into perspective, these drugs are giving at the middle dose 15-20% increase in median lifespan***

- To give a sense of what that means, if you had a cure for cancer in people and no one over the age of 50 ever got cancer, the median lifespan of humans would go up by 3%
- The same is true if you had a drug that abolished heart attacks
  - That’s work done by Jay Olshansky and Bruce Carnes, and published in [*Science*](https://www.science.org/doi/10.1126/science.2237414) in 1990
- We’ve now identified four drugs that give more than a 10% increase in lifespan

> “*In terms of proportional change of healthy lifespan [these four drugs] are doing about 3x better than some hypothetical drug that abolished cancer in people or abolished heart attacks in people. That’s a really significant chunk of additional healthy lifespan*.”‒ Rich Miller

- To Rich’s knowledge, that first rapamycin paper was also the first drug where anyone had showed that a drug works quite well even if you *start in really old mice*
  - Some of the mice that were exposed in that paper didn’t start until 20 months of age, where the median survival is about 24 for males and 26 for females
  - It took Rich very much by surprise
    - We thought if a drug is going to slow aging, you really do have to start it when you’re young because a lot of aging is what happens between the ages of 20 and 60 or something like that
  - Rich adds, “*It was stunning that a drug could start as late as that and still have a full lifespan benefit. That really was news scientifically*.”

**Other drugs also work when you begin giving them in old mice**

- [17α-estradiol](https://en.wikipedia.org/wiki/17%CE%B1-Estradiol) works great if you start it at 16 or 20 months of age in male mice
  - It’s male-specific
- [Acarbose](https://en.wikipedia.org/wiki/Acarbose) still works if you start it in middle age
  - It’s significant in males and females, though better for males
  - It’s only about half as good as starting it early, but it still works
- Data on [canagliflozin](https://en.wikipedia.org/wiki/Canagliflozin) hasn’t been published yet
  - For males, it’s terrific
  - For females, it isn’t good, and they suspect the drug concentrations in the blood of females may be toxic

**Do you have a sense of why rapamycin and canagliflozin are being more concentrated in females, and are you seeing that with any of the other successful candidate drugs?**

- We don’t know the answers for any one of those drugs
- It wouldn’t be too hard to find out
  - Pharmacologists could look at how quickly is absorbed, how quickly is it conjugated, how quickly is it excreted?
  - Does it go out in the urine, does it go out in the feces?
  - All of that very standard, 50 year old methods for answering that question and Rich thinks that would be important to address
- There’s a generic answer which is really quite firmly established: the enzymes that the liver uses to deal with foreign drugs (these are called enzymes of [xenobiotic metabolism](https://en.wikipedia.org/wiki/Drug_metabolism)) are radically different between men and women and between male and female mice
  - Most of them not all, but most of them are a lot higher in females, but some are a lot higher in males
    - And this is also true for people
  - So the pace at which drugs are conjugated, put into the bile or put into the urine, or excreted in the feces or excreted in the urine very often are sex-specific
- It doesn’t surprise anyone to find that the blood concentrations may be different in men and women or different between male and female mice
- We haven’t looked at the details on a drug by drug yet
- As a footnote for acarbose (that has nothing to do with these enzymes), nearly all of the ascarbose stays in the gut
  - It doesn’t get absorbed into the body so excretion is not the key issue
  - Why the acarbose has such a big effect in males and a small (but significant) effect in females is unknown
    - It presumably has to do with males being more sensitive to high glucose levels
    - Acarbose probably works by limiting very high glucose levels and maybe for unknown reasons that triggers something horrible in the males, and not so much in females

**A tangent on sex differences in drug metabolism and why this isn’t considered for dosing**

- Peter points out, “*When you talk about the difference in the pharmacokinetics between male and female mice, we can only extrapolate and say that our* [*cytochrome P450 system*](https://en.wikipedia.org/wiki/Cytochrome_P450) *as humans must have sex differences. But what I can’t tell you for the life of me, Rich, is one drug that I’m aware of that we really differentially dose in males and females beyond a weight difference.*”
  - We don’t seem to take into account the sex of the patient when we give a person an antibiotic or a statin or a chemotherapy
    - They’re all based on either weight or nothing at all
  - “*It’s kind of remarkable that we don’t have a better set of the pharmacokinetics of these drugs, and their differences in human sex and how that maybe should factor into how we think about dosing them.*”
- Rich would love to see Peter have a real pharmacologist on the show who knows how to answer that question, “***Aren’t there differences between men and women in the rate at which drugs are excreted? And why isn’t that informing our recommendations for drug doses in people?***”
  - Rich doesn’t know the answer
- Peter thinks this seems like an enormous missed opportunity to get that level of granularity

## The success of rapamycin and what that tells us about the biology of aging [43:15]

- People who listen to this podcast are very familiar with rapamycin
- A [recent episode](https://peterattiamd.com/davidsabatini-mattkaeberlein/) had [David Sabatini](http://www.nasonline.org/member-directory/members/20038940.html) and [Matt Kaeberlein](https://halo.dlmp.uw.edu/people/matt-kaeberlein/) on together, and we did a pretty good deep dive on rapamycin

**On the off chance that someone’s coming to this as their first exposure to rapamycin, do you remember who made that nomination for the 2009 paper?**

- [Dave Sharp](https://directory.uthscsa.edu/academics/profile/sharp)
- This was almost an in-house nomination

*What was the logic at the time?*

- 10 years earlier the drug had been FDA-approved for solid organ transplants, it was an immune-suppressant
- People had just begun to make invertebrates (worms and flies) with the genetic modulation of the TOR pathway
  - TOR is the target of rapamycin, the enzyme that rapamycin inhibits
  - And they were long- lived
- In fact, when you studied some of the [yeast stuff](https://www.cell.com/cell-metabolism/fulltext/S1550-4131(12)00237-9?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS1550413112002379%3Fshowall%3Dtrue) that [Matt Kaeberlein](https://halo.dlmp.uw.edu/people/matt-kaeberlein/) was in on this early on with [Brian Kennedy](https://medicine.nus.edu.sg/bch/faculty/brian-kennedy/), many of the things that seemed to influence yeast lifespan were also related to the TOR pathway
- So Dave said, “*I wonder whether if you inhibited TOR in mice, they would also live longer.*”
  - It really didn’t have to do with the notion of immune-suppression
  - It had more to do with control of growth and following up on the genetic data in the invertebrates
  - Now in retrospect 20 some years later, we understand that the notion of rapamycin as an immunosuppressant is the sort of tip of the iceberg
  - There are some immune functions which it increases and some that it decreases [discussed in [episode #272](https://peterattiamd.com/davidsabatini-mattkaeberlein/)]
    - It’s dose dependent and context dependent
- By an interesting coincidence, the same year that our lifespan paper appeared, there was another [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4020596/) also from Michigan (not Rich’s lab) in which they gave rapamycin to some old mice and showed that their influenza vaccine response was terrific if they’d had rapamycin
  - What rapamycin appears to do in their model is it increases the production of B cells from the bone marrow
    - So the mice would respond to influenza vaccine and then they were exposed to live virus and they survived, whereas untreated controls did not survive

***So in some circumstances, rapamycin is actually immune-boosting***

- That was also [demonstrated](https://pubmed.ncbi.nlm.nih.gov/25540326/) by [Joan Mannick](https://milkeninstitute.org/events/fhs19/speakers/39958) and [Lloyd Klickstein](https://srfcure.org/lloyd-klickstein/) six years later using [everolimus](https://en.wikipedia.org/wiki/Everolimus)
  - In humans it also improves vaccine responses on some circumstances to influenza, and vaccination in humans

**With the challenge getting rapamycin formulated, why did you decide** ***not*** **to abort the study when you finally got the food formulation done?**

*The mice are geriatric at this point (20 months old)*

- There are two decisions: (1) Randy Strong’s initiative and creativity in saying, “*I’ll bet we can get this into mice. I’ve got buddies who do encapsulation. Let’s encapsulate it and see if that stuff works.*”
- The mice were originally going to get rapamycin starting at 4 months of age
- (2) We either throw this batch of mice out or give them rapamycin
- They used this batch of food twice: some went to the mice that were 20 months old and the rest went to young mice the next year
  - They expected the drug to fail in the old mice and maybe work in the young mice
  - It worked well in both ages

**What was the difference between the male/ females in the 20-month onset versus the four-month onset, both by sex?**

- [Scott Pletcher](https://medicine.umich.edu/dept/molecular-integrative-physiology/scott-pletcher-phd) did that analysis, and when you compare within sex (older females to younger females), there’s no difference (surprisingly)

***In both sexes, starting as late at 20 months of age does not diminish the ability of rapamycin to extend lifespan***

**What does that tell us about the biology of aging?**

*Does it tell us more about aging or more about the drug?*

- It tells you something about both, about the drug and its interaction with the aging process
- The inevitable conclusion is that by the time a mouse is 20 months of age (which is sort of like 55 or 60 years old in a person), damage will have occurred that’s irreversible
  - This is not yet at the median survival, but getting pretty close
  - Collagen cross-linking and death of some brain cells and clogging of the arteries or whatever’s going to get you has already started
  - ***But apparently there’s still some further stages of that process that occur afterwards (after we started to administer the drug at 20 months of age) which are dependent on aging and the drug inhibits***
    - That’s the news that we would not have known if we hadn’t done an experiment starting in late middle age
- Now what those processes are, whether they are same processes as affected by many different drugs, that’s unknown
- Clearly we’ve got a lot to learn now about what is happening that is drug sensitive, even in middle-aged mice
- The fact that [acarbose](https://en.wikipedia.org/wiki/Acarbose) works half as well in middle-aged mice, [canagliflozin](https://en.wikipedia.org/wiki/Canagliflozin) works at least in males quite well in middle-aged mice (which is unpublished), and that [17α-estradiol](https://en.wikipedia.org/wiki/17%CE%B1-Estradiol) works great even in middle-aged male mice suggests that it’s a general phenomenon
- When [Mike Garratt](https://www.otago.ac.nz/bms/expertise/profile?id=2975) was in Rich’s lab (he’s now set up his own lab in New Zealand), he took a lot of mice and he put them on 17⍺-estradiol or acarbose in middle age and he [found](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6413653/) that their grip strength is great, much better than untreated old mice, and their ability to stay on a rotating rod
  - Which is a complex phenomenon having to do with balance and muscle strength and motivation
  - That is much better even if they started the 17α-estradiol or acarbose in middle age
  - It’s not just a matter of the things that are going to kill you, these mice don’t die of dizziness or loss of grip strength or something, but a whole batch of stuff that is age sensitive is slowed by these mice

## Other measures of healthspan evaluated by the ITP in stage 2 studies [50:45]

**The next frontier that Rich wants his labs and other labs in the ITP to dive into is cognition**

- Michigan has just recruited an absolutely top-notch mouse neurobiologist, a woman named [Catherine Kaczorowski](https://medicine.umich.edu/dept/mni/catherine-kaczorowski-phd), and we already have several studies underway, in which we’re going to be treating mice with these drugs and test them for cognition, in addition to looking at their lifespan
  - The obvious hypothesis is that the drugs that extend lifespan will also postpone loss of cognitive function
  - For complicated reasons, Catherine thinks that will be untrue, but Rich thinks it is true
    - We’ll see who is correct

**What other measures of healthspan are you capturing? What else can you say about these mice and their health, beyond just the elongation of life?**

- Obviously cognition is a piece of healthspan, and Rich already mentioned grip strength and some complex motor tasks and stamina tasks

*Do you look at muscle mass at the time of demise in these mice?*

- We have stage 1 and stage 2 studies
- In a **stage 1 study**, lifespan is the only thing we measure in addition to body weight at four ages
  - We do this for every new drug
  - We could throw in other tests, but it’s really expensive to do that and to standardize it so that all three labs get the same numbers proved to be really tricky

***If we did devote lots of our efforts to looking at these secondary measures of health in addition to lifespan, we would test only three drugs a year or maybe four drugs a year***

- **Stage 2** studies are done for candidate drugs that pass the stage 1 studies
- For every drug that makes it to stage 2, we have developed a protocol that takes advantage of the strengths and weaknesses and interests of each site
- For instance, [Dave Harrison](https://www.jax.org/research-and-faculty/faculty/dave-harrison) had many tests of visual acuity, hearing acuity, strength, body temperature regulation
  - So the stage 2 experiments at the Jackson Labs incorporated many of those tests
- [Randy Strong](https://barshopinstitute.uthscsa.edu/team-member/strong-randy/) and his colleagues were interested in glucose control and glucose homeostasis
  - So the stage 2 stuff that was done at Texas always had some taste of that
- Rich’s lab is interested in pathology so we would take a lot of these stage 2 mice, euthanize them at 22 months of age, send them to a veterinary pathologist, and come back with a long list of:
  - Here’s what’s happening in the liver, but look, it didn’t happen in the drug treated mice
  - Here’s what’s happening in the gut, but look, it didn’t happen in the drug treated mice
- The other hope is that once we have a winner, the laboratories that have a specific interest in aging of the aorta and aging of the heart and aging of the lung (and who knows what they’re doing) will just ask us for tissues
  - They can buy the drug and treat their own mice (hopefully not B6 mice), and test their organ specific functional or pathological outcome tests
  - Or if we have tissues in our freezer, they can ask us for tissues

**Frozen stockpiles of treated animals**

- Since 2015, every drug, whether it’s a winner or a loser, we’ve been putting aside 20-40 mice, euthanized at age 22 months and frozen
  - This is changing next year (he’ll get to that in a minute)
- Anyone who wants those tissues just writes us a note saying, “*Here’s what I want. This is the tissue I need, here’s what I’m going to do with it. Here’s my power analysis.*”
  - And we send them the tissue
- It’s a national/ international resource
- We can’t study everything

***This program is called*** [***CIP (the Collaborative Interactions Program)***](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp/collaborative-interactions-program)

- Unfortunately, it’s probably going away next year
- The National Aging Institute (NIA) has decided that instead they want to replace it with a new program, which they’re calling **Interventional Biogerontology Repository** in which the tissues will *not* be requested from us
- Requests will go directly to the NIA and they will make all decisions as to who gets the tissues, who doesn’t get the tissues, how much tissue they get
  - Rich is not so sure that’s a grand idea
  - The worst thing is that they will have a call only once a year
    - Rich adds, “*When people send us a note, we generally can make a decision within two or three weeks and they can generally get the tissue within a month or two*.”
    - Adding an extra year of time for the NIA staff to sort of figure out who gets the tissue or not is not going to speed things up

**Based on these tissues, what have you learned through collaborations with people looking at epigenetic changes in the treated versus untreated mice?**

- Peter imagines there is some difference in gene expression and that would be one way to look at it
- [Steve Horvath’s](https://altoslabs.com/team/principal-investigators-san-diego/steven-horvath/) lab does lovely work, and we have sent him tissues
- For anybody else who is working on some aspect of either global or localized tissue specific epigenetic change, we’d be delighted to send them tissues
- [Vadim Gladyshev](https://dms.hms.harvard.edu/people/vadim-gladyshev) at Harvard has gotten lots of tissues and has published metabolomic assays
  - Rich doesn’t think any of his epigenetic stuff has come out yet, though he’s not certain
- The [paper](https://www.science.org/doi/10.1126/science.abo3191) that [Johan Auwerx](https://people.epfl.ch/johan.auwerx?lang=en) just published with [Rob Williams](https://www.uthsc.edu/faculty/profile/?netid=rwilli10) and [Maroun Bou Sleiman](https://people.epfl.ch/maroun.bousleiman/?lang=en) in *Science* has some epigenetic materials in it

***The problem is that no one at this point knows enough to know what tissue to look at***

- It may be that a particular drug is working because it sensitizes the liver to high glucose levels or something
  - So you’d want to then look at liver tissue or pancreas tissue or eyelid tissue or fat tissue or quite plausibly tissue of some obscure cell type in the hypothalamus, which regulates hormones that make you hungry or not hungry
- Rich is going to guess the liver is important, and looking at all the epigenetic changes in the liver is a very crude way of addressing that
- In his view, the progress will come when someone says, “*Hey, look, this drug works by hitting this enzyme in this set of hypothalamic neurons. Now let’s look at the epigenetic change in those neurons.*”
  - We’re not there yet

## Distinguishing aging rate indicators from biomarkers of aging [57:30]

**What are aging rate indicators, and how does that factor into the ITP work?**

- Everybody is familiar with the concept of biomarkers of aging
  - By analogy, it’s sort of like the odometer in your car, and your odometer tells you how far the car has been driven
  - A biomarker of aging in a crude sense tells you how far your body has been driven

***Aging rate indicators by this analogy are the speedometer; they tell you how quickly you are aging and not how far you’ve gone***

**What are the odometers of aging [biomarkers]?**

- That’s a complicated issue and Rich doesn’t think we have very many at all
- But conceptually, you can imagine, if someone comes into your test facility and they’ve got a lot of high-affinity antibody, and their vision is terrific, and they’ve got no cataracts, and they’re great at hearing, and they can do a hundred pushups, and they’re great at running up and down a hill, and their skin is smooth, etc.
  - All 10 or 20 domains, they sort of look like they’re 40
  - You could say, okay, they are biologically young
- Peter agrees, we have lots of functional tests that give you odometer-like insights, but when you think about a biomarker that is assay-based, there’s nothing there

## Aging rate indicators identified through the examination of slow-aging mice [59:15]

- Rich explains, “*We were looking for things that always change in the same direction, in every kind of slow-aging mouse. That would distinguish not how old they were, but how rapidly they were going to be aging*.”
  - We have 9 published and 1 unpublished slow-aging mice
  - We have 4 genetic mutants: the Snell, the growth hormone receptor knockout, the Ames Dwarf, and the PAPP-A [discussed in [*GeroScience* 2023](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9886707/)]
  - We have a famous calorie restriction diet [discussed in [*The Journals of Gerontology Series A* 2009](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2691799/)]
  - And we have at least 4 well-vetted drugs: acarbose, canagliflozin, 17α-estradiol, and rapamycin
- Rich looked for something that is changed in the same direction in all 9 kinds of mice [listed above]
  - And this is true for the 10th kind: [PTEN](https://en.wikipedia.org/wiki/PTEN_(gene)) over-expressors (just submitted for [publication](https://pubmed.ncbi.nlm.nih.gov/37669771/))

***The pleasant surprise is that we now have 13 things that always change in the same direction in all 10 kinds of slow-aging mice***

- Even when they are young adults, and that’s the crucial thing
- The **biomarkers** are useless until the animal or the person gets *old*
  - They’ve got to have a certain amount of aging behind them to see if they are young-like in comparison to control untreated people, or people with a different gene
- The **aging rate indicators**, because they’re measures of speed, you can look even when the animal is *young*, hypothetically when a human is a young adult
- So most of the work that we’ve done on mutant mice was done on animals that were 4-6 months of age, and the work on the drug-treated mice was when animals were 12 months of age

**Changes observed in slow-aging mice**

- There are changes that are in famous molecules, molecules whose connection disease is not just fanciful
- 1 – One of these is [UCP1 (uncoupling protein 1)](https://en.wikipedia.org/wiki/Thermogenin): it’s a mitochondrial protein that allows your mitochondria to burn fat without doing a lot of work
  - It just turns the fat into heat
  - It’s involved in thermogenesis
  - It’s long been known that having a lot of UCP1 is something happens when you exercise (exercise increases UCP1)
  - And mice that have a lot of UCP1 live a long time
  - It’s thought to play a major role in protecting you from obesity, from diabetes, from metabolic syndrome, from inflammation

***Every one of our slow-aging mice has a lot of UCP1 in the white fat under skin in the white, fat in the abdomen, and also in the brown fat between the scapulae***

**The exception to that rule is very informative**

- Remember the two drugs (canagliflozin and 17α-estradiol) extend lifespan in males only
- UCP1 goes up in males only for those two drugs
- That is a strong indication that whatever process is making the drug slow the mortality rate and increase longevity is the same process (at least in its sex-specificity) as the UCP1 story

**How are you measuring UCP1**

- We take the fat and we look at the protein by [Western blot](https://en.wikipedia.org/wiki/Western_blot)

*How much biologic noise do you think exists in that on a day-to-day basis?*

- Peter explains his question thinking about a normal control mouse on the control diet, “*If you sample his fat every day for a month, and some days you put him on his treadmill wheel, some days you don’t. Some days he doesn’t eat that much, some days he does.*”
  - Some activities might either be associated with a longer life or associated with a  behavior that increases the protein of interest
- Even if everything Rich said were true, it would be really troublesome if UCP1 spiked on those days, because then it wouldn’t really be a useful speedometer

*There are 3 issues here*

- 1 – In a normal mouse where you’re not making them exercise and you’re not feeding them foie gras, if hypothetically you get a little bit of fat from that same mouse every single day, or every hour over the day, would there be much change in UCP1?
  - That experiment of course can’t be done
  - But it doesn’t invalidate our findings because even if that would introduce some noise, the consistent difference between the mutant mice, or drug-treated mice, and the controls, the noise is already built in, budgeted into that
  - If there was a lot of noise, too much noise, we wouldn’t see a significant effect of drug, or the diet, or the genetic intervention
- 2 – Could one perturb this by getting an animal to exercise?
  - People have done that: UCP1 is changed by chronic exercise
  - It’s one of the reasons why it’s thought to be amongst the mediators of the health benefits attributed (in people and in mice) to exercise

*Peter’s follow-up question: If you took an otherwise sedentary mouse and exercised the hell out of him for a day and checked it then, would you be fooled by an elevated level [of UCP1]?*

- Rich doesn’t know
- This is an empirical question, not hard to address
  - It may already have been done
- 3 – The related question is about the time of day, and we try to normalize it
  - The mice are always euthanized between 9-10 in the morning
    - So it’s not the case that some of the mice are morning mice, some of them are afternoon mice, some of their evening mice
  - Also, they are fed ad lib, and that does introduce some variation
    - Some may have had an early morning snack, and some may have had their last meal four hours ago before the lights go on

**How are the animals euthanized?**

- We use a method that makes them go unconscious within 5 seconds
  - We put them into a plastic bag, and then we fill the bag quickly with carbon dioxide gas
  - They take a few breaths, and within 5 seconds they’re unconscious, and within 10 seconds they stop breathing
  - Because the carbon dioxide is highly sedating, this minimizes the hormonal stress at the end of life
- Rich points out, “*The American Veterinary Medical Association recently (that is five years ago) made the method we use a suspect method. We still have permission to use it, and we’ve talked to the vets about it, so we’re not violating any of the rules.*”
  - They now recommend that mice be placed in a cage and the carbon dioxide gas be added gradually
  - He thinks this is a rotten decision because it takes 7 minutes for them to lose consciousness, and over that 7 minutes, their adrenaline level goes up
    - Their glucose doubles, their blood becomes acidic, the pH drops
    - We would never want to do that because who knows what that’s doing to all the protein kinases and the metabolites?
    - Anything that is glucose or hormone-sensitive is going haywire
- Peter finds an interesting parallel here with the way animals are harvested for human consumption
  - Unfortunately, the way most animals are harvested is very stressful on the animal, and therefore it actually erodes the quality of the food that you’re about to consume based on the stressful environment of the animal and the way it dies

**Are there any other candidates besides UCP1 that serve as a fantastic indicator of an “aging speedometer”?**

- The same woman that did the UCP1 study ([Xinna Li](https://www.pathology.med.umich.edu/faculty/xinna)) also looked at [**macrophages**](https://en.wikipedia.org/wiki/Macrophage#) **in the fat** (there are two kinds)
  - M1 macrophages make a lot of inflammation
    - In all of these slow-aging mice, they go down
  - M2 macrophages prevent inflammation
    - In these mice, that goes up

***So at least in the fat, all of these influences of genes, diet and drugs make the fat much less inflammatory; and that’s likely to be important because a lot of diseases involve inflammation***

- High inflammation is a sign of stress, and it’s really bad for you
- It may be that these drugs/ diets/ genes are working in part by reducing inflammatory tone

**Rich has also looked at proteins in the brain**

- 1 – [BDNF (brain-derived neurotrophic factor](https://en.wikipedia.org/wiki/Brain-derived_neurotrophic_factor)) is thought to protect brain cells from stress
- 2 – [Doublecortin (DCX)](https://en.wikipedia.org/wiki/Doublecortin) is a sign that brain cells are making new brain cells (neurogenesis)
- These go up in the brain in all of the slow aging mice
- Again, the exception being the two drugs that are sex-specific
  - Where here, the BDNF and doublecortin changes are also sex specific and seen in males only

**The M2 macrophages were in the fat cell, was UCP1 also in fat or was it in the liver?**

- The macrophages were in the fat depot
- We looked at UCP1 in three different fat depots: brown fat, inguinal white fat (which is subcutaneous), and in the perigonadal white fat (which is abdominal)
- The macrophage changes are seen in each of the depots

***UCP1 (which is in*** [***adipocytes***](https://en.wikipedia.org/wiki/Adipocyte)***) is also seen in all three of these fat depots***

**Other candidates**

- We have many other now, but one that Rich thinks is thrilling is a *protein made by the liver and fat* called [GPLD1](https://en.wikipedia.org/wiki/GPLD1)
  - What it does: there are lots of proteins that stick out on the outside of the cell that are linked by a sugar bridge ([glycosylphosphatidylinositol or GPI](https://en.wikipedia.org/wiki/Glycosylphosphatidylinositol)), and GPLD1 cleaves that
    - The result is that GPLD1 releases lots of different kinds of proteins [[GPI proteins](https://en.wikipedia.org/wiki/Lipid-anchored_protein#GPI_proteins)] from cellular surfaces
- We thought this was interesting because Horowitz [showed](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7879650/) 2-3 years ago that if you exercise, GPLD1 goes up
  - It’s true for mice, it’s true for people
  - More exciting is if you have GPLD1 go up, cognition goes up (for reasons unknown)
    - There is evidence that GPLD1 goes up in the liver and in fat
- What we found now in our lab was that all 10 kinds of slow-aging mice also have elevated GPLD1 production in the liver, and amount of it in the plasma of the mice
- We can’t prove that that’s why BDNF and doublecortin go up in the brain
- Some of these mice are known to have great cognition, we can’t prove that it’s due to GPLD1
  - But obviously we are hoping that that is the case
- GPLD1 is also exciting to Rich because in another part of his lab, a guy named [Gonzalo Garcia](https://www.richmillerlab.com/laboratory-members) was looking at differential mRNA [translation](https://en.wikipedia.org/wiki/Eukaryotic_translation#), and he had discovered that all slow-aging mice have a lot of [cap-independent translation](https://en.wikipedia.org/wiki/Eukaryotic_translation#Cap-independent_initiation)
  - That is they can pick a subset of the messenger RNAs and translate them in a special way, and cause proteins to be made in ways that are independent of the amount of RNA for that protein
  - We’ve [published](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9470888/) now that GPLD1 is one of those proteins
    - It is controlled not by changes in the transcription of the DNA into the RNA, but by the differential translation of the RNA into protein, in a cap-independent translation module
    - This is our first serious link between the molecular biology of protein translation (Gonzalo’s stuff) and the physiological effects like cognition and BDNF (which was Xinna’s domain)

***Rich is pleased see these two different lines of experimentation get tied together here through the GPLD1 protein***

## Why proteomics are essential to understand changes in the cell [1:12:15]

**Is this an example where the epigenome might not matter as much? Presumably that would have a greater impact on transcription, but this is a purely translational phenomenon.**

- Rich agrees with that about 90%
- Many, many labs just look at RNA levels
  - Transcriptome biology is relatively easy, and now you can follow it up with epigenetic exploration of what controlled trends
  - Most of the published omics information is lists of RNA as that go up or down

***However, RNA is very poorly correlated with protein, and it’s the protein that counts***

- There’s a lovely pair of studies from the Jackson labs, [Ron Korstanje](https://www.jax.org/research-and-faculty/faculty/ron-korstanje) and [Gary Churchill](https://www.jax.org/research-and-faculty/research-labs/the-churchill-lab) were involved
  - They took B6 mice of four different age groups, and they measured the changes in proteins [and mRNA]
  - They made a long list of proteins that change with age, and they did it in two tissues [[kidney](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8096428/) and [heart](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9104701/)]
- Rich explains, “*It turns out that the correlation between the RNA and the protein was 30%. That is, only 30% of the age effect on protein level could be blamed on/attributed to changes in the underlying transcription data.* ***So if all you’ve got is the transcription data, which is what most people have, you have sort of blinded yourself to the 70% of what is controlling protein levels****. And it’s the proteins that actually do stuff in the cell.*”

> “*I think, until people come to grips with that discontinuity, they won’t really be motivated to look at the proteins, which are harder to study but doable. And I think it is the proteomic data collection that will be valuable*.”‒ Rich Miller

- Rich’s lab has shown that proteins can be modified by both **differential mRNA translation** (cap independent translation, [publication](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8135077/)) and **differential degradation** ([Joe Endicott’s](https://www.richmillerlab.com/laboratory-members) work, [publication](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8032237/))
  - They are not the first to show this
  - Subsets of proteins are degraded by the [lysosome](https://en.wikipedia.org/wiki/Lysosome) through [chaperone-mediated autophagy](https://en.wikipedia.org/wiki/Chaperone-mediated_autophagy)

***These processes mold the proteome in ways that are completely independent of the mRNA for the underlying proteins, and this is a big part of the story, which people are gradually waking up to***

- Peter did not know that fact about the poor correlation between protein translation and mRNA transcription and reacts, “*That’s a very big deal… Without the proteomic assessment, the story is incomplete.*”

**The Bio 101 explanation for how we turn DNA into mRNA and tRNA and protein**

- 1 – In high school, you learn that DNA can be [transcribed](https://en.wikipedia.org/wiki/Transcription_(biology)) into mRNA
  - It has the same sequence more or less, and codes for proteins
  - That’s where [epigenetic](https://en.wikipedia.org/wiki/Epigenetics) control comes in
    - Proteins made only by the liver are in large part because the liver has turned some transcripts on and others off
    - The same is true for the eye and the brain, etc.
    - So now each cell has its own complement of RNAs
- Peter adds, “*The liver, and the eye, and the muscle have the same DNA. Why does the hepatocyte make a protein that the liver needs, whereas the neuron makes a protein that it needs? This is where turning on and off the gene, the epigenome matters.*”
  - Rich agrees, ***people used to think only the genome mattered, but many of the differences between neurons, skin cells, blood cells, and liver cells are because they express different mRNAs from the same DNA template***
    - It’s just like if you have a library of books, and someone decides to read *The Trollop* and somebody else wants to read Emily Dickinson
    - They have different experiences, even though they have the same library to work with
- 2 – So you’ve got a batch of RNAs that you’ve transcribed selectively, depending on the cell, and now you have to make them into protein
  - The ribosome will generally bind to them and turn out protein [in the process of [translation](https://en.wikipedia.org/wiki/Eukaryotic_translation#)]
  - The sequence of the protein will be based upon the sequence of the bases in the messenger RNA
  - Most ribosomes start this by binding to the very end of the message at a place called the [five-prime cap](https://en.wikipedia.org/wiki/Five-prime_cap)
    - That’s not where the translation starts, but the sort of “start here” signal
  - Then the ribosome bumbles its way down to the place where it’s going to start, and then it starts making proteins
- Most translation is [cap-dependent](https://en.wikipedia.org/wiki/Eukaryotic_translation#Cap-dependent_initiation): the ribosome can only find and get working on that messenger RNA by binding to the cap, bumbling down to the start site, and then making the protein
- So the default presumption (which turns out to be *wrong*) is that once you’ve got those RNAs out there because of transcription into the mRNA, the rest is automated
  - They just churn out proteins based upon the RNA that they’ve got

**There are now lots of studies that say the idea that the set of proteins depends only on what mRNAs you’ve got is really a poor approximation**

- What [Gary Churchill](https://www.jax.org/research-and-faculty/research-labs/the-churchill-lab), and [Ron Corstanza](https://www.jax.org/research-and-faculty/faculty/ron-korstanje), and their buddies accomplished was, they actually looked at this in the context of aging in a systematic way
  - They looked at a tissue like [kidney [publication]](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8096428/) (which is Ron’s special favorite tissue)
  - They looked at kidneys of 6, 12, 18, 24-month old mice, and they made a long list of which genes change at the RNA-level as aging progressed
  - Then, they did the same thing, but at the protein-level
    - Same tissue, same age, same genetic stock, same mice
  - They now have two parallel lists, and the old-fashioned default assumption would be that if you are on the winner list for age sensitivity for the mRNA, you’re going to be on the winner list for the proteins encoded by that messenger, RNA
    - And that was right 30% of the time; not a hundred percent, but 30%

***There were big differences [in protein levels] with age in the kidney and one other tissue [the*** [***heart publication***](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9104701/)***], but only 30% of those changes corresponded to the same change, same amount, same direction in the mRNA, the rest came in somewhere else***

**Is it post-translational?**

- That’s what we don’t know

*There are a batch of possibilities*

- 1 – Rich has pointed to differential translation
  - This is [Garcia’s](https://www.richmillerlab.com/laboratory-members) work on cap-independent translation where the ribosome doesn’t care about the cap, it can bind to something else on some of the mRNAs
  - So that could be selective RNA translation
- 2 – There’s also selective RNA sequestration where the RNA can be hidden and not made available
- 3 – There’s selective RNA degradation
- 4 – Once the protein has been made, it can be degraded, chopped up into amino acids in many different ways
  - The proteasome can do that
  - Lysosomes can degrade a small percentage of proteins (that’s [Joe Endicott’s](https://www.richmillerlab.com/laboratory-members) specialty)

***There are changes in RNA stability, changes in RNA location, RNA translation,and  protein degradation (of many different flavors) that will, in important ways, modify the amount of the protein independent of any underlying changes in the messenger RNA***

- We’re talking in the context of aging about non-transcriptional pathways that mold our proteome, but the same principles apply to any disease-specific process, any drug response

> “*Once people buckle down and sort of learn this, they will not devote their entire labs to analysis of [mRNA] transcripts.*”‒ Rich Miller

- Once people understand this, they will pay more attention to proteins
  - And also to the  subtleties of what happens between transcription of the DNA to the RNA stage
  - And then eventually the stable, steady-state level of the protein

## Unraveling aging rate indicators: dose-effect, duration, and future frontiers [1:21:45]

- In the study of 10 cases of slower-aging mice: 4 are genetic mutations that result in slower aging, there is caloric restriction, and 4 drugs

**Is there a dose-effect that you’re seeing?**

- Presumably these 9-10 cases have slightly different lifespans and therefore are slightly differentially aging

*Rich answers this in the context of things we don’t know, things we want to know, and things we could find out in the next few years (if given the opportunity)*

- One of the things we would really like to know is, what about the next three drugs?
  - Do they do the same things to the same aging rate indicators?
    - That’s a test of our hypothesis
    - If the answer is yes, yes, then that is great
    - If the answer is no, something has gone wrong and we need to reconsider the whole foundational idea
- Another important question is, if you give a drug to a mouse, how long does it take for the aging rate indicators to switch?
  - If it takes a few months, that is terrific because that means we can take a hundred drugs and test all 100 of them not for lifespan (which is really expensive), but test them for the ability to switch aging rate indicators
    - If we test 100 drugs and 5 of them switch all of the aging rate indicators, those are the 5 that we think are most likely to be winners for the lifespan experiment
    - So we could use these as a screen to try to identify drugs that are more likely than not to work in the context of a lifespan experiment
- We also don’t know how long they stay switched
  - Let’s say we give a mouse rapamycin (or 17 ounce estradiol or a mystery drug) and 8 weeks later, all the aging rate indicators are at the slow-aging level
  - Then, we remove the drugs. Will these indicators stay where they are?
    - We don’t know that for drugs

**Great experiment with** [**Andrzej Bartke**](https://www.siumed.edu/andrzej-bartke.html)**, inventor of the Ames dwarf mouse (a long-lived mouse)**

- Andrzej found that these [Ames dwarf mice](https://www.jax.org/strain/001618) have very low growth hormone, very low IGF-1, and they live 40% longer
  - [Published](https://pubmed.ncbi.nlm.nih.gov/8900272/) [in 1996]
  - He [found](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2992365/) that if you give them growth hormone shots when they’re a little baby (starting at two weeks of age, and only for six weeks; stop giving them shots when they’re eight weeks old) that’s enough to *turn off* the whole anti-aging program
    - They are no longer long-lived
    - We found that they no longer have stress-resistant cells, and we found they no longer have low inflammation in the brain (they go back to normal)
- Rich got from Andrezej Bartke some 20-month-old mice that were treated when they were babies
  - So any epigenetic change that happened to them, they’d have to do it in that growth hormone-treatment period and “remember” it for 20 more months
- The answer is that the changes in all the aging rate indicators, easily seen in the 20-month-old mutant mice, they all *went away* in the mice that had gotten the growth hormone shots in the juvenile period

***The exposure to growth hormone shots for a brief period of time in youth was sufficient to lead to lifelong reversion of the aging rate indicators to the normal (away from the slow-aging position)***

- What Rich wants to do now is the inverse of that
- He wants to give them something that’s good for them and see if we turn on these aging rate indicators
  - To slow aging and then see if it stays up forever

***The next frontier: if you give these drugs to people, do the people change the aging rate indicators? If the answer is yes, that opens up a massively productive frontier for aging research in people.***

**Question about the Ames mice: What happens with the reverse experiment? If you give them growth hormone once they’re fully matured, do you shorten their life or revert their life back to normal?**

- No, we’ve tried that
  - We tried starting the shots at 4 weeks of age in [Snell dwarf mice](https://www.jax.org/strain/000510) (which are more or less the same)
    - We started shots at 4 weeks of age, then it took 3 years for the mice to age, and it had no effect on lifespan
- Bartke also did it starting at 4 weeks of age too, and he failed
  - He didn’t give up; he did it over again but starting at 2 weeks
- When you start at 2 weeks it works [the mice have a shortened lifespan], when you start at 4 weeks, it doesn’t [change the lifespan]

## A closer look at the aging rate indicators: bridging the gap from mice to humans [1:27:00]

**Going back to the biomarkers** [**BDNF**](https://en.wikipedia.org/wiki/Brain-derived_neurotrophic_factor) **and** [**DCX**](https://en.wikipedia.org/wiki/Doublecortin)**, how are you measuring those?** [1:27:00] biomarkers?

- We take bits and pieces of the hippocampus, make a suspension of the proteins and do a western blot to measure the amount of protein in the brain

**As you think about the application of bringing this to humans, what would it look like to bridge that gap?**

- In other words, if you wanted to know if this type of exercise routine versus that type of exercise routine, this type of diet versus that type of diet, or your home brew of rapamycin versus not, is having a benefit, at some level we will need to get this out of plasma
  - It will be very difficult to do this out of CSF or even fat biopsies

*How difficult a bridge is that?*

- There are two steps Rich and colleagues are taking:
- 1 -A collaboration with [Steven Cummings](https://sfcc.ucsf.edu/steven-r-cummings-md) and Theresa Mao and their colleagues; they have a project at UCSF called [SOMMA](https://sommaonline.ucsf.edu/)
  - They have a collection of several hundred human volunteers all in their seventies, in good health
  - These people took a lot of functional tests
    - How good are they at thinking?
    - How fast are they?
    - How strong are they?
    - And they allowed tiny, tiny muscle biopsies and tiny fat biopsies
- We have requested (and are likely to receive) tiny bits of muscle and fat from these brave volunteers, and we will test: do those that have a lot of the muscle-specific change (in a protein called [FNDC5](https://en.wikipedia.org/wiki/FNDC5)), and the fat-specific change (like [UCP1](https://en.wikipedia.org/wiki/Thermogenin) for instance)
  - Our prediction is that amongst the 70 year olds, the really fit ones will be the ones that look as though they have always had youthful aging rate indicators
- That will be one way in humans of beginning to test internal tissues to compare with plasma
- But that’s impractical for clinical use, so what we really need now is ways of extending our results to plasma
- Two of the things that we can measure in plasma (and published)
- 1 – It turns out that [irisin](https://en.wikipedia.org/wiki/FNDC5) (which is the product of FNDC5) it goes up in all of our slow-aging mice
  - Irisin is the thing that goes from muscle to fat; it’s in in plasma
- 2 – The other is [GPLD1](https://en.wikipedia.org/wiki/GPLD1) (discussed earlier); it is also in plasma and it also goes up in all of our slow aging mice
- We’ll be able to evaluate that in human plasma samples

**We really want more than that**

- One of the studies that we’ll be doing in the next few years with [Catherine Kazowowski](https://medicine.umich.edu/dept/mni/catherine-kaczorowski-phd) and [Costus Lisiatas](https://medicine.umich.edu/dept/molecular-integrative-physiology/costas-lyssiotis-phd) at Michigan (he’s a metabolomics expert) is we will take a batch of healthy young, UM-HET3 mice (the same kind that the ITP uses), and we’ll take blood samples from them
  - We will measure the aging rate indicators in the blood but also in the muscle, fat, liver and brain of all these mice
  - And Costus will measure several hundred metabolites in the blood of the same mice
  - Our goal will be to ask which 2 or 10 or 20 or 100 plasma metabolites correlate with the plasma and the internal tissue ARIs [aging rate indicators]?
  - If we can derive from this exploratory exercise a list of 5 or 10 things you can measure in mouse and human plasma that tell you where the ARIs would be internally, that’s great
- There’s a terrific younger scholar named [Hamilton Oh](https://profiles.stanford.edu/hamilton-oh), working at Stanford with [Tony Wyss-Coray](https://profiles.stanford.edu/tony-wyss-coray)
  - Hamilton has been able to deconvolute plasma signals by saying these represent changes in the pancreas, these represent changes in the liver, these represent changes in the brain
  - He’s not working in mice yet, but in principle, it can be done

***We hope that you will be able to detect plasma molecules which correlate with tissue specific levels of ARIs, and that will be the bridge to human studies***

**Is he doing that by looking at cell-free DNA?**

- Rich can’t answer that for two reasons: (A) he doesn’t understand it, and (B) it was at a [Gordon Conference](https://en.wikipedia.org/wiki/Gordon_Research_Conferences) and he’s not allowed to talk about it

**Candidate aging rate indicators: irisin, FNDC5, and GPLD1 [1:31:45]**

**Irisin is the product from what protein?**

- It is a cleavage product of a muscle protein called [FNDC5](https://en.wikipedia.org/wiki/FNDC5)
- So we do two things: we measure FNDC5 as a protein in *muscle*, and we measure irisin as a peptide or protein in the *plasma*
  - In our hands, they always go up and down together

***All the slow-aging mice have more of the protein [FNDC5] in the muscle and more of the irisin in their blood***

- Peter recalls a study in [*Nature* in 2012](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3522098/) identifying that irisin concentrations were high in people post-exercise, and the promise of the paper was we now have the exercise drug
  - Just give people irisin as an “exercise pill”
- Peter suspects the temptation for any of these things is the same
  - Presumably somebody will think that [GPLD1](https://en.wikipedia.org/wiki/GPLD1) in a pill is a good thing

**What is the clinical efficacy of administering irisin or GPLD1 in a pill?**

- Irisin has a checkered history
  - The original papers said what Peter described, but it turned out that the assay they were using for irisin was highly inaccurate in the sense that they overestimated the concentration of irisin by a factor of about 100 (not subtle)
  - The people who were skeptical of the original results worked out a mass spec-based assay for irisin (the gold standard) and proved that the original antibodies were not specific enough to be useful to actually measure irisin levels
  - And so many people who had felt those original papers were highly promising (as indeed they were) discounted the whole system
  - It now looks as though they were throwing out the proverbial baby with the bathwater
  - Now there are better antibodies that are sensitive enough to detect irisin at actual levels
- When Xinna Li brought Rich her irisin data he didn’t want to publish it until they had data on the precursor protein (FNDC5) in the muscle
  - Because of the terrible reputation of irisin antibodies
- The western blot data on irisin in plasma and FNDC5 in muscle showed these proteins were paralleling one another, and Rich believes both of them because they always come out the same

**Why not just do the mass spec on irisin in that situation?**

- We’re no good at mass spec and we know how to do western blots

**Do we think that these molecules are merely biomarkers of all of the myriad good things that these behaviors, drugs, or exercises do?**

- Rich doesn’t have any secret inside dope
- He will bet you that pharmaceutical companies thrilled with what [ozempic](https://en.wikipedia.org/wiki/Semaglutide) and its competitors are doing, have devoted tons of money to figuring out whether they can get something like irisin into you in a way that doesn’t hurt you and does you some good.
  - He will bet the pharma companies have devoted tons of money into looking at that
  - He thinks it’s a highly promising area of research, although he imagines a lot of it currently is proprietary
- [GPLD1](https://en.wikipedia.org/wiki/GPLD1) is a protein, and swallowing a pill might not work, because it might be digested in the stomach
  - Just like every bit of meat you eat is digested to amino acids
  - The same is true with irisin
- Presumably, these are going to need to be injectables
- Unless you can come up with a small factor that turns on FNDC5 in your muscles
- We have those; they’re called anti-aging drugs, and [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) does that
- This is the part that Peter is trying to wrap his head around, because on the one hand we have molecules that are now doing things that are impacting aging at a fundamental level
  - It’s not counterintuitive to me that exercise or calorie restriction induce a longer life in the right model
  - It’s a little counterintuitive to me that rapamycin does
- It’s remarkable to Peter that a molecule is able to act at a fundamental level of aging, as opposed to way, way, way downstream in the way that a lipid lowering drug works, where it works on one disease pretty much, and it works through one path
  - And the proof of that is indeed your aging accelerator: that is in fact the proof of geroprotection
    - It almost becomes the sine qua non of a molecule being geroprotective versus simply targeting a disease
- Rich phrases it another way: if you have a drug that extends mouse lifespan, he think that’s a critically important step towards making a case that it’s slowing aging, but it’s *not* the last step
  - He would not fully endorse that hypothesis unless someone has shown that the mice treated with that drug also retain lots of youthful function, in addition to living a long time
    - Their muscles are great, their hearing is great, their cognition is improved, their bones are better
- Rich explains, “*We’ve gone through all those steps with the Snell dwarf mice, the Ames dwarf mice, for the calorie-restricted diet, for the growth hormone receptor knockout mice. We’re beginning to make that kind of a story for acarbose. Our first acarbose paper had grip strength and blood glucose control. We’re beginning to make that case for 17*⍺-*estradiol as well.*”
- Building those cases brick by brick by brick is really necessary to say it’s not merely an anti-cancer drug, something that was a broad spectrum anti-cancer drug
- To make Rich happy, it has to be an anti-aging drug and the evidence has to be effects on many different age sensitive properties
- We have great evidence now for at least three mutants, and the calorie-restriction diet and the methionine-restriction diet, and we’re getting there for rapamycin and several of the other drugs that came along 5-8 years after that

***Rich thinks there will be a very strong case that these drugs are acting by slowing the aging process and delaying maybe not quite all, but maybe all of the aspects of aging that make people unhappy about getting older***

- He agrees with Peter, it’s a fundamental reorientation of instinct
  - That’s what this experimentation is designed to do: it’s designed to reset one’s instinct on these points

## What do laboratory mice die from? [1:38:45]

- We’ve talked a lot about the problems with the B6 mouse, and Rich has alluded to the fact that they’re basically genetically programmed to die of cancer

**What is the natural history of your mice, and how does the natural death of the mice in the control group by cause compared to the treated mice, in success cases?**

- We’ve already obviously talked about length of life
- The context that’s necessary here is that nearly all of the mice that are available throughout the world for medical experimentation come from the [Jackson Laboratory](https://www.jax.org/), which for 30 or 40 years was mostly interested in cancer
  - So whenever a mouse got cancer, they kept it
  - Most of the strains were positively selected for getting a lot of cancer
- [UM-HET3 mice](https://www.jax.org/strain/036603?utm_source=google&utm_medium=ppc&utm_campaign=2023_aging&utm_content=search&gad_source=1&gclid=CjwKCAjwkY2qBhBDEiwAoQXK5VXOh5cF6Z12y6J8Zy-X1DRZWqcBYhdV3s3g3hcLu_ShdooNibISmBoCc7AQAvD_BwE) have 4 different grandparents, and cancer is the cause of death in about 80% of these mice, but it’s varied
  - 30-35% of deaths in  males is some sort of lymphoid or leukemia cancer
  - Pulmonary cancer and liver cancer are both prominent
  - In females it’s not so much pulmonary but breast cancer, liver cancer, again hemangiosarcoma
  - Then for 30% of both sexes: 1% will die of this cancer, 2% will die of another cancer, 3% will die of another cancer
  - 80% of the time it’s some sort of neoplasia that is the lethal injury
    - ***That’s why one could make initially a case that all these drugs are doing is slowing down every single kind of cancer***
    - ***That’s why we have to look at a lot of things that are not cancer***
- To the second part of the question: does the proportion of different kinds of cancers or causes of death change in these different mice?
- That’s a hard question to answer because when we do a necropsy series at the end of life, we usually have only about 60 mice in the treated group and about 60 mice in the control group
  - If say liver cancer kills 10% of the mice, you only have 6 cases
  - Statistically, they don’t have enough cases to be confident
- We had a drug that was extending lifespan in males and females, but it did not increase the age at death of the females dying of breast cancer
  - So one could have made a case that breast cancer is caused by something that is not related to this drug’s anti-aging mode
    - That’s something we’re always on the lookout for

***The number of autopsy cases is almost always too small to really have a good grip on it***

## Distinguishing between a drug that improves an age-sensitive outcome and a drug that improves all aspects of aging [1:42:00]

**Do you know if there are cases of drugs that do not improve lifespan but do improve, say grip strength and treadmill time?**

*In other words, are there drugs that are improving healthspan without lifespan in the ITP that you’ve documented?*

- No one has looked for it, and that’s because the ITP stage 1 assays don’t do it
  - They only do detailed studies on things that extend lifespan
- The reason that things extend lifespan is basically it postpones all the bad stuff that lead to death
- We could screen a lot of drugs for age-sensitive variables and the hope is that we would find one that made age-sensitive variables go away but didn’t have any effect on lifespan
  - Rich is not so sure that we would find any
  - It’s trivially easy to do that
    - If you teach a mouse to do pushups, you will postpone age associated changes in muscle mass and muscle strength, and if you teach them they won’t get food until they solve a maze, they’re going to get pretty darn good at solving that maze

***System specific postponement of age-sensitive outcomes is not too hard to achieve, but it’s not really relevant to the issue of what you can do to postpone all the aspects of aging together***

## The ITP study of 17⍺-estradiol: mechanisms of life extension and surprising sex differences [1:43:30]

- One of the successes of the ITP that perplexes Peter is [17⍺-estradiol](https://en.wikipedia.org/wiki/17%CE%B1-Estradiol)

**Remind me what the difference is between 17⍺-estradiol and 17ꞵ-estradiol**

- The dominant form in both males and females is [17ꞵ-estradiol (traditionally called estrogen)](https://en.wikipedia.org/wiki/Estradiol)
- Chemically, 17⍺-estradiol is the same as 17ꞵ-estradiol, except for one of the bonds instead of pointing up out of the plane, points down in the opposite direction
  - It’s a stereoisomer: they have the same chemical formula (all the atoms are attached in the same place) it’s just that two of them are pointing up instead of pointing down
  - And because of that manipulation, it doesn’t bind very well to the traditional famous estrogen receptors
- 17⍺-estradiol is doing something, it’s got to be binding to something, but it probably is not the traditional estrogen receptors, or it might be that plus something else to get an effect on estrogen sensitive tissues
  - You can do it with 17⍺-estradiol, you just have to use a lot more, maybe tenfold more is what [Jim Nelson](https://barshopinstitute.uthscsa.edu/team-member/nelson-james/) found when he did that titration

**What was the scientific rationale for why 17⍺-estradiol would be geroprotective when this was proposed to the ITP?**

- [Jim Simkin](https://directory.hsc.wvu.edu/Profile/38338) recommended it
  - He’s a steroid physiologist, neuroendocrinologist
- He reasoned that estrogens are good for you, and that’s why females live longer than males
  - Let’s find an estrogen we can give to males
  - We don’t want to give them 17ꞵ-estradiol, because they’ll turn into girls and they won’t like that
  - So let’s use 17⍺-estradiol because they won’t turn into girls
    - It does not turn on secondary sexual characteristics.
  - Maybe it will do all the good stuff that estrogen 17ꞵ-estradiol actually does
  - Jim’s argument was very plausible, but a lot of this was *wrong*
- It turns out that if you give 17⍺-estradiol to male mice, it pushes their lifespan way beyond females
  - It’s not merely mimicking the good stuff, if there is good stuff that 17ꞵ-estradiol does in females; if so, it wouldn’t go much further than females are
  - ***It goes significantly beyond normal females or drug-treated females,*** ***because the drug doesn’t affect female longevity at all***

**What 17⍺-estradiol binds to, in which cells, in which tissues, what it’s turning on biochemically is at this point quite obscure**

- There are at least two labs working on this:
- 1 – [Mike Stouts](https://alliedhealth.ouhsc.edu/Departments/Nutritional-Sciences/Faculty-and-Staff/Bio/michael-b-stout-phd) in Oklahoma
- 2 – [Mariana Sadagurski](https://clasprofiles.wayne.edu/profile/ez3862) at Wayne State, who is Rich’s former student
- They’ve published some really nice papers getting at the issue of what a 17⍺-estradiol actually [doing](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10312580/), physiologically, what does it [bind](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7744101/) to?
- Mariana, her last three papers and her just awarded grant are focused on what 17⍺-estradiol does in the [brain](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8751796/)
  - What it does to estrogen-sensitive and estrogen-insensitive parts of the brain
- Rich wishes there were more labs diving into that question:
  - What is the target?
  - What is the receptor?
  - What is the physiological effect?

**Is 17⍺-estradiol as potent in males as rapamycin?**

- Rich would have to double-check
- He thinks it’s about a 19% increase [[data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3954939/) pooled from the 3 ITP sites showed a mean lifespan increase of 12%]
- The original dose of rapamycin is there or slightly below that
- We now have a better result with rapamycin
- Further, when rapamycin is combined with acarbose, we can kick the male lifespan up to a 29% increase
  - It’s the largest percent increase we’ve ever gotten, and also it’s the first time we’ve gotten an increase by combining two drugs together

> “*We now have a better result with rapamycin. When we combine it with acarbose, we can kick the male lifespan up to 29% increase… That’s our winner.*”‒ Rich Miller

**Have you combined 17⍺-estradiol with rapamycin yet?**

- We’re testing it now, and several other groups are testing it also, because it’s a good idea
- Rich knows of at least on startup company that’s trying it as well
- Peter finds the 17⍺-estradiol fascinating ‒ there’s something about the lack of clarity around  the mechanism of action, and there’s the sex difference that can’t be attributed to any mimicking of 17ꞵ-estradiol
  - Given that males leapfrog the females and the females accrue no benefit

**Insight into what Rich though was going on with 17⍺-estradiol, and how badly they were wrong**

- [Mike Garratt](https://www.otago.ac.nz/bms/expertise/profile?id=2975) collaborated with a guy named [Mo Jain](http://www.jainlaboratory.org/mohit-jain/) to [look](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6052402/) at steroids in the tissues of mice treated with 17⍺-estradiol (among other things), and he noticed something really interesting
  - He found two steroids that were members of the estriol family (not estradiol) that were elevated at least 20-fold in males that got the drug
    - [[reported](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6052402/) as estriol‐3‐sulfate and 16‐oxoestradiol 3‐sulfate, metabolized from 17⍺-estradiol]
    - And they were not elevated in females at all
  - It was a male-specific production of estriol when 17⍺-estradiol was given, and we knew it was sex specific because if he castrated the males before the drug, you didn’t see the estriol production
- The conversion from estradiol to estriol depended upon testosterone or some other testicular hormone
- So Rich thought estriol was going to be the one that is going to work in both males and females
- The dataset is 90% complete, and we’ll probably start writing it up in a month or two when we have 90% of the mice dead, but we had 50% of the mice dead
- We’ve presented at meetings, and the data says that that guess was partially right and partially wrong
- The hydroxy version of estriol is great for males
  - It’s actually at least as good as 17⍺-estradiol
  - We won’t know until we have the last few deaths, but it’s terrific
  - That was a good guess: you don’t need 17⍺-estradiol because the estriol works terrific
- However, we thought it would work in females, and it is the first drug we’ve found that *diminishes* lifespan in females
  - So the idea that it would work to benefit females was wrong
  - It is for mysterious reasons harmful in females

**To be clear is this straight** [**estriol (E3)**](https://en.wikipedia.org/wiki/Estriol)**?**

- It’s 16-hydroxy estriol

*Why did you pick 16-hydroxyl estriol as opposed to 4-hydroxy, 2-hydroxy, or just pure estriol?*

- Rich doesn’t know the answer, we could ask Mike Garratt
- Maybe it was commercial availability
- Maybe it was prior studies of toxicity in mice
- Mike has his reasons, and Rich read the application three years ago and doesn’t remember what specifically led him to suggest this compound

**The female mice that are dying at an accelerated rate, is there anything specific about the manner of death?**

- We don’t know yet; we haven’t done any necropsies

## Unsuccessful drugs studied by the ITP: resveratrol, metformin, and nicotinamide riboside [1:51:30]

- For Peter, three drugs come to mind that everybody thought were “home runs” that didn’t pan out: resveratrol, metformin, nicotinamide riboside

**Are there any other drugs that should be on that list?**

- These are the ones that have gotten the largest numbers of notices in AARP bulletins and on social media and at the conventions where people want to mingle with snake oil salesmen
- There’s a different level of enthusiasm for each one of them
- 1 – [Metformin](https://en.wikipedia.org/wiki/Metformin) has been very sensibly proposed as a potential anti-aging drug in people
- Rich doesn’t know enough about its benefits and side effects
- A case has been made because it’s so very safe in people that it could be used in people to postpone aspects of aging
  - Rich can see real reasons not to believe that, but at least you can make a case for that
- The ITP showed that metformin doesn’t work in mice, and now several other groups have confirmed that result
- [Rafael de Cabo](https://irp.nih.gov/pi/rafael-de-cabo) at one point [claimed](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3736576/) that it worked in mice, but he used a very weird statistical test, and Rich suspects that if he had used the standard statistical test, it would’ve failed in his lab as well
  - Rich hasn’t seen the data, so he’s not sure of that
- 2 – [Resveratrol](https://en.wikipedia.org/wiki/Resveratrol) was hyped for many years
  - People often with commercial interests or who had a grant or who wanted to get a lot of money for clinical trial would start to talk with a beautiful bottle of red wine and then say resveratrol is in red wine, and [sirtuins](https://en.wikipedia.org/wiki/Sirtuin) are important, and resveratrol influences sirtuins
    - And just take some of my resveratrol or sirtuin activating agent and you’ll live forever
- None of that was right
  - It has been shown very clearly now that the amount of resveratrol in red wine, to get enough of it, you need to drink 30 bottles a day
  - Its status as a sirtuin activator has been questioned by very serious and skilled biochemists
  - The original data on worms has been *disconfirmed* by a couple of very good labs
  - People made a lot of money by selling companies that had an interest in sirtuin activators
  - We tested it because the director of the National Aging Institute, [Richard Hodes](https://www.nia.nih.gov/about/staff/hodes-richard), for the first and last time, said, “*You will test resveratrol or you will not get any money this year*.”
    - We said, “*Yes, sir, yes sir*.” So we tested it
    - We checked with [David Sinclair](https://sinclair.hms.harvard.edu/people) and asked what concentration we ought to use?
    - And it didn’t work
  - Subsequently, many groups now (including groups that Dr. Sinclair is associated with) have shown that it doesn’t work to extend lifespan of regular mice
  - A [famous paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4990206/) was one where the mice were poisoned with a 60% coconut oil diet, and they weren’t dying of aging, they were dying because their liver swelled up to the point that it crushed their lungs and they couldn’t inhale (they couldn’t breathe)
    - This is not a good model for the aging response

**Does it surprise you how ubiquitous resveratrol supplements are still on the internet?**

- Rich replies, “*Sorry to be cynical, people are very easy to fool. It’s easy to come up with eight or 10 things that people believe because they read them about the internet or they watched them on Fox News or whatever, and they’re strong about this, but people are very, very gullible.*”

**An anecdote about resveratrol that gives you a sense of what that time was like**

- Rich had a friend, a neurologist at Michigan, who had been given a huge grant to give resveratrol to Alzheimer’s patients at the early stage to see if it would slow Alzheimer’s
- He came around to a meeting of resveratrol biologists that Rich was attending, and he asked people what dose to use
- The range of suggested doses as milligrams of drug per person per day ranged over a million-fold (from 1 to 1 million mg)
  - That is among the world’s experts on resveratrol
  - This is a sign of a field that is making it up as it goes along

**3 – NR is the last of the three drugs Peter mentioned**

- Rich had high hopes
- Peter adds that there was probably more hype with [NR](https://en.wikipedia.org/wiki/Nicotinamide_riboside) than resveratrol
- The ITP tested it and it didn’t work; it didn’t extend most lifespan
- Some people said, “*Oh, well you have to use* [*NMN*](https://en.wikipedia.org/wiki/Nicotinamide_mononucleotide).”
  - A metabolite that would have a more bioavailability and better profiles, and this is reasonable
- Rich adds, “*If someone makes a good case that we should test NMN and we could afford it (the commercial sources are expensive), we would probably test that as well, I think*.”
- Peter imagines that some commercial party would donate the drug at this point
  - Yes, the ITP is in negotiations with one such company
- Rich hopes this is right, but he’s *not* a non-believer
  - He’s a non-believer of resveratrol
- For NM and the whole nicotinamide modulating family, he thinks the book is still open and there’s a reasonable chance that some really good stuff could come out of that
  - It might be that you’d have to give an enzyme that modified an inhibitor of one of the metabolizing enzymes, or a different form
  - Rich has a colleague who has suggested that NR may work in combination with another drug
    - His ideas are good and have been accepted by the ITP
    - The ITP is going to try NR plus something else
  - It could be that some other trick will lead to physiologically important modulation of [NAD](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide) availability in some cell of interest
    - It could be that what counts is changing the availability in a cell, in the hypothalamus, or in the pancreatic beta cell, or in the lymph nodes, or something
- Finding a dose that is appropriately good for the cells that count but doesn’t produce side effects in other cells may be tricky, but it might work
- Rich would love to test other things in that general nature

> “*It goes without saying, I should have said this earlier, the fact that something fails in mice doesn’t mean it’s going to fail in people*.”‒ Rich Miller

- Testing it in people is going to be much harder
- It’s easier to sell stuff that’s untested
- But in principle, one could actually test it in people and see if it does anything good

**Peter’s takeaway‒** ***the failure of resveratrol in the ITP is a dispositive that that drug never worked in any circumstance anywhere***

- Rich explains that his evidence is *not* dispositive, but it’s one brick in building the case
  - It could be true that it doesn’t work in mice, but it works great in people
  - Or it could be that it would work in mice at a 20 times higher dose

**Rich’s takeaway‒** ***resveratrol has been overhyped, and if you look in detail at the evidence suggesting it has health benefits, most of those studies are unconvincing, and many of the ones that are convincing were submitted by people who are trying to sell something***

- The one [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4990206/#SD1) that Peter finds really convincing is the one Rich mentioned where mice were force-fed coconut oil (that’s problematic)

**Takeaways on NR and metformin**

- What he hears Rich saying with NR and metformin is, “*Even if we repeat these studies over and over again in ITPs, which you won’t directly, but you will potentially in other combinations, you have more faith in the possibility that those could still be viable in humans*.”
- Yes, the theoretical case of metformin might be good for you is plausible
  - It’s not proven, but it’s sensible
  - The same is true for things that are attempting to rescue age-associated changes in NAD
- As Rich mentioned earlier, in a good year the ITP gets 20-25 applications [and they test 6]

***Most of those good plausible cases yield negative results, and that’s expected***

**One of the nice things about aging rate indicators**

- If they are flipped by drugs in a short period of time, then we hope our hit rate will…
- Right now, our hit rate is about 10% of drugs tested give us big effects, and a total of 15% give us significant effects
- If we can get that up to 50% by prescreening with aging rate indicators so that half of the drugs we throw into lifespan studies actually give a lifespan benefit, that would be nice

## Over-the-counter successes in the ITP: meclizine and astaxanthin [2:01:00]

- 15-20 years ago, Peter used to spend a lot of time on small boats, 30-foot boats out in really rough water
  - He doesn’t know how many hours of his life he’s spent 30, 40 miles off the coast of California getting thrown around like crazy
  - He’s pretty lucky that he has only been seasick once in his life
    - Most people he spent time with out there got seasick a lot more

***One of the drugs that people take for seasickness is an over-the-counter drug called*** [***meclizine (brand name Bonine)***](https://en.wikipedia.org/wiki/Meclizine)

- Peter would occasionally take it

**Meclizine is included in the latest paper for the ITP (submitted but not yet published)**

- There are two drugs: meclizine and [astaxanthin](https://en.wikipedia.org/wiki/Astaxanthin), which in *males*, led to a significant increase, about 10% in the lifespan of the males
- Meclizine was suggested to us by [Gino Cortopassi](https://ptx.ucdavis.edu/people/gino-cortopassi)
  - He knew that rapamycin was good as an anti-aging drug and it was a [mTOR inhibitor](https://en.wikipedia.org/wiki/MTOR_inhibitors)
  - He took several thousand FDA-approved drugs, and in a tissue culture assay, he asked, “*Which of these inhibit mTOR? Maybe a safe drug that inhibits mTOR could find a place as an anti-aging remedy*.”
    - To everyone’s surprise, at the top of that list was meclizine
- Meclizine is famous as an antihistamine and also has mysterious CNS effects, which is why it’s so good for seasickness
- Rich doesn’t think it was known as a mTOR inhibitor, but Gino found that it was, and so he suggested that we test it

***Meclizine, at the dose we used, led to a significant increase in the lifespan of the male mice (about 10% increase)***

- It did not affect females, so we’re going to try it again at higher concentrations and see if we can get that to go
- We haven’t proven that the effect is mediated by mTOR inhibition
- It has a lot of CNS effects, and maybe the good stuff that it’s doing to the male mice is unrelated to mTOR
  - Maybe it has to do with changes in serotonin or histamine production in some critical nucleus in the brain
  - We need to now look at that

**That paper [submitted, not yet published] has two points of interest, and the other one is astaxanthin**

- Astaxanthin is also available over-the-counter
  - You can buy it in your local drugstore
- It is alleged to have health benefits, but they’re all over the map and Rich can’t assess the strength of the evidence for health benefits
- It’s also alleged to have many different physiological effects like an antihistamine or an anti-inflammatory or an antioxidant
  - It’s been alleged to do a little bit of everything

**Astaxanthin is a food dye, isn’t it?**

- We eat it all the time
- It’s famous because it’s what turns farm-grown salmon pink
  - People literally dump truck loads of astaxanthin into the water and the salmon turn pink
  - It’s not that you dip the salmon into astaxanthin
  - Natural salmon eat a lot of crustaceans which have this stuff in their shells, and you can mimic that effect in farm grown salmon by giving them synthetic or naturally derived astaxanthin
- In any case, there’s a company in Hawaii that believes it might have health benefits, and they asked the ITP to test it
- We tested it and that also has a significant effect, and also it’s *males only*
- Hopefully this paper will be accepted soon and out for people to judge the strengths of the evidence
- Neither of these led to a change in our measurement of **maximum lifespan**
  - This test of percentage of live mice at the 90th percentile
  - Possible that at a higher or maybe even a lower dose, it might have done that
- We’re going to need to go back and do more complete dose-response curves

***The reason this paper is likely to be of particular interest to the general public is that it is the first time we’ve gotten winners that you can buy without a prescription, over-the-counter***

- They’re not as strong in terms of lifespan benefit as the four drugs we were talking about earlier on in our discussion, and of course we don’t know if they will work in humans at all
- But the position of the FDA that you can’t test a drug claiming it has an anti-aging effect will be of less relevance if some of the over-the-counter non-prescription medicines actually slow aging, first in mice and then maybe also, eventually, in people
  - That’s an interesting political and legal question
- In terms of the science, we now need to figure out:
  - What is astaxanthin doing?
  - Is meclizine acting through mTOR or through some other target?
  - As any new drug does, it opens up new possibilities for mechanistic exploration
- You can bet we’re going to be looking at the aging rate indicators in tissues from meclizine-treated and astaxanthin-treated mice

## A senolytic drug, fisetin, fails to extend lifespan [2:07:00]

**The last thing in the paper that many people will be interested to know is we’ve tested fisetin**

- [Fisetin](https://en.wikipedia.org/wiki/Fisetin) was suggested to us by [Paul Robbins](https://robbins.umn.edu/dr-paul-robbins-phd) and [Jim Kirkland](https://www.mayo.edu/research/faculty/kirkland-james-l-m-d-ph-d/bio-00096544) and [Tamara Tchkonia](https://www.mayo.edu/research/departments-divisions/department-physiology-biomedical-engineering/about/faculty-staff?letter=T) and their colleagues
- Fisetin is undergoing a lot of human trials because of claims that it is a [senolytic](https://en.wikipedia.org/wiki/Senolytic) drug
  - There are some people (not Rich) who think that there’s such a thing as a senescent cell, and that you get a lot of them when you get old and that they’re bad for you, and that a drug that removes senescent cells therefore will be good for you

***Fisetin was given to us as a drug to test the hypothesis that if you remove senescent cells from mice by giving them fisetin, they would live longer***

- Rich thought it wouldn’t work, but it was a very reasonable and important thing to do
- We gave fisetin two different dose regimes suggested by Dr. Kirkland
  - The dose he used in his lab with his kind of mice

**We thought we were trying to replicate his stuff in our mice at a much larger scale, and the take home messages were two**

- 1 – First, it had no effect whatsoever on **lifespan** of male or female mice using either of the dosage regimes that Dr. Kirkland recommended
  - However, that is not dispositive because it turns out it didn’t remove any senescent cells either
- There are quite a number of surface markers like [p16](https://en.wikipedia.org/wiki/P16) that the senescent cell gurus say is a marker of [senescent cells](https://en.wikipedia.org/wiki/Cellular_senescence)
  - They go up with age
- We looked at three different tissues, done by [Paul Robbin’s](https://robbins.umn.edu/dr-paul-robbins-phd) lab and [Jim Kirkland’s](https://www.mayo.edu/research/faculty/kirkland-james-l-m-d-ph-d/bio-00096544) lab
  - We sent them tissue, and it was blind, so they wouldn’t know which ones were controls and which ones were treated
  - They sent us back this number of [beta-galactosidase](https://en.wikipedia.org/wiki/%CE%92-Galactosidase) positive cells, the number of p16 positive cells, and the amount of [p21](https://en.wikipedia.org/wiki/P21),
  - When we unblinded it, there was *no effect* of fisetin on brain, on liver, on muscle, on kidney at either lab for any marker that we looked at
- 2 – We thought we were testing the notion that **removing senescent cells** would be good for you, and it turned out we were testing the notion that fisetin removes senescent cells
  - Everyone was disappointed

**Say more about your lack of belief around the role of senescent cells**

*Do you mean you don’t believe in senescent cells, or you don’t believe that senescent cells drive aging, or you don’t believe removal of senescent cells slows aging or reverses an aging phenotype?*

- It’s a long story, but let me give you an analogy
- If someone says, “*Do you believe in stress?*” The answer is, “*Sure, I believe in stress*.”
  - But that doesn’t end the conversation because there’s the stress of being about to undergo a tense podcast discussion, or the tension of having to give a talk before the National Aging Institute’s Committee, or the stress of dental work (Rich hates dental work)
  - Or the chronic stress of being locked into a marriage or a job that you really hate, or getting a diagnosis of cancer, or dropping a bit of poison into your GI tract
  - All of those things produce stress, but they’re radically different things and they produce different physiological effects

***To say, “Do you believe in stress or is this caused by stress?” is a way of blinding yourself accidentally to the critically important distinctions***

- Rich believes that there is such a thing as a [senescent cell](https://en.wikipedia.org/wiki/Cellular_senescence)
  - If you take cells in human cells and culture, they stop dividing, and those have been called senescent cells
  - They exist; no question about it, and they’re caused by [telomere](https://en.wikipedia.org/wiki/Telomere#) shortening
- Now, if you take another kind of cell and you zap it with X-rays, you get a different kind of cel
  - They make different proteins, they don’t have telomere problems
  - People have referred to those as senescent cells
- If you have cells, when you get older, they have p16 on them, people have referred to those as senescent cells
- By saying that this drug removes senescent cells, they are hoping you won’t begin to think about what the *vague* definition of what a senescent cell is
  - In laboratory A, these proteins are called the senescence secreted proteins
  - In lab B, it’s two of those plus seven more
  - In lab C, well, they don’t see those, but they do see changes in the nucleus, which they view as senescent
- Rich believes that there certainly are cells that accumulate in mice and in people when you get old that do stuff that’s bad for you
  - Some of them might make this set of [cytokines](https://en.wikipedia.org/wiki/Cytokine)
  - Some of them maybe they can’t divide anymore, and that’s bad for you
  - Some of them may even have two of these problems together
  - Maybe some of that has changed because [*RAS*](https://en.wikipedia.org/wiki/Ras_GTPase) has been mutated or DNA has been damaged or something
- And exploring what causes those things, how they become bad for you, whether removing that cell type is good, that’s wonderful

***In Rich’s view, if you say, “These are senescent cells. I’ve got a drug that removes senescent cells,” you are skipping all the interesting stuff***

## Can targeting senescent cells slow aging? [2:13:00]

**A story about a famous paper where** [**Judy Campisi**](https://www.buckinstitute.org/lab/campisi-lab/) **was the key author**

- This is the [paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC40985/) that introduced [beta-galactosidase](https://en.wikipedia.org/wiki/%CE%92-Galactosidase) as the way to count senescent cells, and she looked at the skin of a lot of people, young and old people
- She counted the number of senescent cells and proved that it went up a lot with age
- That was a very influential paper
- In this original paper (which was many years ago), the scores were -, +, ++, and +++
  - Not actually a percentage of cells that were beta-gal positive in the skin sections
  - And only one person was 4+, was a 90 some year old grandmother
  - The actual cell counting was done by a friend of Rich’s, [Monica Peacock](https://www.legacy.com/us/obituaries/nytimes/name/monica-peacocke-obituary?id=14494333), who is a dermatopathologist, and Rich asked her, “*Okay, Monica, how many cells do you have to get, to be 4+?*” And she said, “*Yeah, that’s 10 to the -4.*”
    - The skin section that had the highest number of beta-gal positive cells had only 1 positive cell in 10,000
    - Everybody else, all the 70s, 60s, 50s, all of those people had fewer than one cell in 10,000

***The statement is literally true that senescent cells go up with age, but they did emphasize the fact that even in the very oldest people, the number of actual senescent cells was really quite small***

- Peter wonders if the difference between +, ++, and +++ refer to log differences
  - [The paper states in Table 2, “‒ no staining; ± 1 positive cell: + 2-4 positive cells; ++ several positive cells in the dermis, clusters in the epidermis; +++ positive cells in all sections of dermis, multiple clusters in all sections of epidermis]

***For Rich, the take-home message here is that senescent cells, at least as indicated by that one marker, beta-galactosidase, are so rare that they’re virtually absent from the skin of people of any age (10 to the -4 and lower)***

- But this paper has been very influential, and Rich believes a much overly emphasized, over influential concept
- He was hoping we would show that fisetin would remove senescence cells from mice, and there would be a lifespan effect
- But in fact, that didn’t seem to actually remove p16 or p21 positive cells from any of the tissues that we evaluated, so we’re back at square one

**Peter’s takeaway‒ What we have learned is that fisetin doesn’t do jack. What we haven’t learned is if removing senescent cells is or is not beneficial.**

- It might work in people as Jim Kirkland believe, and he could be right
- You can get it to work even in mice if you administer it as a bolus dose, a huge dose once a day rather than gradually in the food

**Another popular anti-senescent drug is a chemotherapy**

- People often give [quercetin](https://en.wikipedia.org/wiki/Quercetin) plus [dasatinib](https://en.wikipedia.org/wiki/Dasatinib)

*Has that been proposed yet as part of the ITP?*

- Yes, but Rich is not allowed to discuss anything that comes in except the things we accept
  - It was not accepted

## Optimism about future findings [2:16:30]

**There will be a lot ot catch up on in a few years**

- We’re going to need to do a rundown on the repeat studies of 17⍺-estradiol plus rapamycin
- We’re going to need to understand the tier 2 studies of meclizine and astaxanthin
- We’re also going to have to see how they validated against the aging indicators
- Presumably, we’ll also have a little bit more insight into the link between the aging indicators and plasma biomarkers that may start to bridge that gap towards actually assessing interventions in humans
- Rich would love to know whether these drugs slow cognitive failure
- Peter thinks this point about really understanding healthspan can’t be overstated, and some might argue it’s even more important than lifespan

**One of the nice things about the ITP is that it’s designed to stimulate work in other labs**

- There are a lot of labs that are really good at cognition or heart failure or bone failure, and we send these people tissues all the time
- Papers have begun to appear showing that the drug does this or it fails to do this or whatever
- The hope is that for every paper we publish with a new drug that works, this will trigger work in a couple dozen labs using that drug with our tissues or with their own tissues
  - And that some of those will come up with disease-specific indications, disease-specific functional benefits

***The ITP can’t do everything by itself, but we’re really hoping that publicization of our results will trigger others into doing good work***

- One of the reasons Rich was so pleased to be invited back to speak with Peter was that the last time he was invited on the podcast was the most productive interaction he had had
  - Not just in the sense of how enjoyable it was to chat with Peter
  - But also for several weeks after that, he got a lot of people writing to him with ideas and offers to collaborate

> “*This particular podcast is listened to by a lot of smart people who pay attention to what is going on, and that’s a major resource*.”‒ Rich Miller

- Peter agrees and adds that we don’t have the largest audience, but he would argue that we have the most intelligent, most curious, and also those who participate a lot
- This is another reason why Peter asked about other mechanisms for funding
  - He thinks it’s a rather poultry sum that is spent on the ITP when you consider the utility that can come of it
    - Especially with some of the other tools that are being bundled into it
    - Such as neurocognitive assessment and the aging biomarkers
  - He sees this as a very important program, and even when you include the indirect costs (at $4.5 million per year), there are lots of philanthropists out there who would happily put their dollars to work if they could double the throughput of these molecules and the biomarkers and the insights
    - Peter knows there are people listening who think this has a higher ROI than giving a couple million dollars to a university to put an endowed chair in place
- Peter is hopeful that a lot of good comes of this research

§

## Selected Links / Related Material

**Previous episode of** ***The Drive*** **with Rich Miller**: [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) (February 8, 2021) | [1:00]

**Previous episodes of** ***The Drive*** **that discuss geroprotective molecules**: [2:00]

- [#276 ‒ Special episode: Peter answers questions on longevity, supplements, protein, fasting, apoB, statins, and more](https://peterattiamd.com/peter-faq/) (October 23, 2023)
- [#272 ‒ Rapamycin: potential longevity benefits, surge in popularity, unanswered questions, and more | David Sabatini, M.D., Ph.D. and Matt Kaeberlein, Ph.D.](https://peterattiamd.com/davidsabatini-mattkaeberlein/) (September 25, 2023) | [2:00, 43:15]
- [#270 ‒ Journal club with Andrew Huberman: metformin as a geroprotective drug, the power of belief, and how to read scientific papers](https://peterattiamd.com/andrewhuberman2/) (September 11, 2023)
- [#246 – AMA #45: Pros and cons of GLP-1 weight loss drugs and metformin as a geroprotective agent](https://peterattiamd.com/ama45/) (March 12, 2023)
- [#222 ‒ How nutrition impacts longevity | Matt Kaeberlein, Ph.D.](https://peterattiamd.com/mattkaeberlein3/) (September 12, 2022)
- [#207 – AMA #35: “Anti-Aging” Drugs — NAD+, metformin, & rapamycin](https://peterattiamd.com/ama35/) (May 16, 2022)
- [#204 – Centenarians, metformin, and longevity | Nir Barzilai, M.D.](https://peterattiamd.com/nirbarzilai2/) (April 25, 2022)
- [#175 – Matt Kaeberlein, Ph.D.: The biology of aging, rapamycin, and other interventions that target the aging process](https://peterattiamd.com/mattkaeberlein2/) (September 13, 2021)
- [#171 – Steve Austad, Ph.D.: The landscape of longevity science: making sense of caloric restriction, biomarkers of aging, and possible geroprotective molecules](https://peterattiamd.com/steveaustad/) (August 9, 2021)

**Longevity genes in UM-HET3 mice**: [Sex- and age-dependent genetics of longevity in a heterogeneous mouse population](https://www.science.org/doi/10.1126/science.abo3191) | *Science* (M Sleiman et al 2022) | [14:30]

**Canagliflozin extends the lifespan of male not female mice**: [Canagliflozin extends life span in genetically heterogeneous male but not female mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7710304/) | *JCI Insight* (R Miller et al 2020) | [33:15]

**Review of ITP**: [NIA Interventions Testing Program: Investigating Putative Aging Intervention Agents in a Genetically Heterogeneous Mouse Model](https://www.thelancet.com/journals/ebiom/article/PIIS2352-3964(16)30554-0/fulltext) | *eBioMedicine* (N Nandon et al 2017) | [36:45]

**2009 rapamycin ITP results**: [Rapamycin fed late in life extends lifespan in genetically heterogeneous mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2786175/) | *Nature* (D Harrison et al 2009) | [37:15]

**Hypothetical lifespan extension if major degenerative diseases were cured**: [In Search of Methuselah: Estimating the Upper Limits to Human Longevity](https://www.science.org/doi/10.1126/science.2237414) | *Science* (J Olshansky, B Carnes, and C Cassel 1990) | [38:00]

**Treating old mice with rapamycin improves their response to influenza vaccine**: [mTOR Regulation and Therapeutic Rejuvenation of Aging Hematopoietic Stem Cells](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4020596/) | *Science Signaling* (C Chen et al 2009) | [45:00]

**Studies by Joan Mannick and Lloyd Klickstein showing immune-boosting effects of rapamycin in elderly**: [45:30]

- [mTOR inhibition improves immune function in the elderly](https://pubmed.ncbi.nlm.nih.gov/25540326/) | *Science Translational Medicine* (J Mannick et al 2014)
- [TORC1 inhibition enhances immune function and reduces infections in the elderly](https://pubmed.ncbi.nlm.nih.gov/29997249/) | *Science Translational Medicine* (J Mannick et al 2018)
- [Targeting the biology of ageing with mTOR inhibitors to improve immune function in older adults: phase 2b and phase 3 randomised trials](https://www.thelancet.com/journals/lanhl/article/PIIS2666-7568(21)00062-3/fulltext) | *The Lancet Healthy Longevity* (J Mannick et al 2021)

**Mike Garratt’s work on 17-⍺ estradiol in mice**: [17‐α estradiol ameliorates age‐associated sarcopenia and improves late‐life physical function in male mice but not in females or castrated males](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6413653/) | *Aging Cell* (M Garratt et al 2019) | [50:15]

**10th kind of slow-aging mouse, PTEN overexpression**: [PTEN activates chaperone-mediated autophagy to regulate metabolism](https://pubmed.ncbi.nlm.nih.gov/37669771/) | *Autophagy* (S Endicott and R Miller 2023) | [1:00:00]

**GPLD1 goes up with exercise**: [Blood factors transfer beneficial effects of exercise on neurogenesis and cognition to the aged brain](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7879650/) | *Science* (A Horowitz et al 2020)| [1:10:00]

**GPLD1 expression in long-lived mice**: [Cap‐independent translation of GPLD1 enhances markers of brain health in long‐lived mutant and drug‐treated mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9470888/) | *Aging Cell* (Xinna Li et al 2022) | [1:11:30]

**Protein levels are only 30% correlated with mRNA levels in aged mice**: [1:13:00]

- [Proteomic and transcriptomic profiling reveal different aspects of aging in the kidney](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8096428/) | *eLife* (Y Takemon 2021)
- [Genome-wide transcript and protein analysis highlights the role of protein homeostasis in the aging mouse heart](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9104701/) | *Genome Research* (I Gyuricza et al 2022)
- [Global and tissue-specific aging effects on murine proteomes](https://www.cell.com/cell-reports/fulltext/S2211-1247(23)00726-X?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS221112472300726X%3Fshowall%3Dtrue) | *Cell Reports* (G Keele et al 2023)

**Growth hormone treatment of long-lived mice makes their lifespan normal**: [Early life growth hormone treatment shortens longevity and decreases cellular stress resistance in long-lived mutant mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2992365/) | *FASEB* (J Panici et al 2010) | [1:24:30]

**Irisin as an “exercise pill”**: [A PGC1α-dependent myokine that drives browning of white fat and thermogenesis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3522098/) | *Nature* (P Bostrom et al 2012) | [1:32:15]

**What 17⍺-estradiol binds to and what it’s doing physiologically**: [1:46:30]

- [Health benefits attributed to 17α-estradiol, a lifespan-extending compound, are mediated through estrogen receptor α](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7744101/) | *eLife* (S Mann et al 2020)
- [17α-estradiol Alleviates High-Fat Diet-Induced Inflammatory and Metabolic Dysfunction in Skeletal Muscle of Male and Female Mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10312580/) | *bioRxiv* Preprint (M Bubak et al 2023)
- [Metabolic benefits of 17α-estradiol in liver are partially mediated by ERβ in male mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10055366/) | *bioRxiv* Preprint (S Mondal et al 2023)
- [17-α-Estradiol Has Sex-Specific Effects on Neuroinflammation That Are Partly Reversed by Gonadectomy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8751796/) | *The Journals of Gerontology Series A* (L Debarba et al 2022)

**17⍺-estradiol extends lifespan in male mice**: [Acarbose, 17-α-estradiol, and nordihydroguaiaretic acid extend mouse lifespan preferentially in males](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3954939/) | *Aging Cell* ( D Harrison et al 2014) | [1:47:00]

**Male mice treated with 17⍺-estradiol have elevated levels of estriols**: [Male lifespan extension with 17‐α estradiol is linked to a sex‐specific metabolomic response modulated by gonadal hormones in mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6052402/) | *Aging Cell* (M Garratt et al 2018) | [1:48:45]

**Resveratrol improves survival of mice on a diet of 60% coconut oil**: [Resveratrol improves health and survival of mice on a high-calorie diet](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4990206/) | *Nature* (J Baur et al 2006) | [1:54:30, 1:59:30]

**Beta-galactosidase as a marker of senescent cells in skin and its accumulation with age**: [A biomarker that identifies senescent human cells in culture and in aging skin in vivo](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC40985/) | *PNAS* (G Dimire et al 1995) | [2:13:15]

§

## People Mentioned

- [Huber Warner](https://www.nia.nih.gov/news/nia-mourns-loss-dr-huber-warner) (1936-2019, Led the NIA in developing the ITP) [4:15]
- [Randy Strong](https://barshopinstitute.uthscsa.edu/team-member/strong-randy/) (Chair in Aging, Professor of Pharmacology, Director of the NIA Aging Interventions Testing Center, and Director of the Nathan Shock Center of Excellence in the Biology of Aging at the University of Texas Health Science Center at San Antonio) [4:45, 30:15, 32:15, 46:15, 52:45]
- [David Harrison](https://www.jax.org/research-and-faculty/faculty/dave-harrison) (Professor at The Jackson Laboratory and leader in ITP testing) [4:45, 52:30]
- [Ron Korstanje](https://www.jax.org/research-and-faculty/faculty/ron-korstanje) (PI at the Jackson Laboratory who will take over leadership of ITP testing in 2024) [4:45, 1:13:00, 1:18:00]
- [Robert (Rob) Williams](https://www.uthsc.edu/faculty/profile/?netid=rwilli10) (Professor of Genetics, Genomics & Informatics at The University of Tennessee Health Science Center) [14:15, 56:30]
- [Johan Auwerx](https://people.epfl.ch/johan.auwerx?lang=en) (Professor of Integrative Systems Physiology at EPFL, Switzerland) [14:15, 56:30]
- [David Allison](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=allison) (Professor of Epidemiology and Biostatistics at Indiana University Bloomington School of Public Health) [20:30]
- [Martin (Marty) Javors](https://directory.uthscsa.edu/academics/profile/javors) (Professor of Psychiatry and Pharmacology at the University of Texas Health Science Center at San Antonio) [30:15]
- [Brett Ginsburg](https://directory.uthscsa.edu/academics/profile/ginsburg) (Professor of Psychiatry at the University of Texas Health Science Center at San Antonio) [30:30]
- [Peter Reifsnyder](https://www.jax.org/research-and-faculty/research-labs/the-harrison-lab) (Research Lab Manager of David Harrison’s lab at Jackson Laboratories) [31:00]
- [David Sabatini](http://www.nasonline.org/member-directory/members/20038940.html) (expert in mTOR signaling pathway) [43:15]
- [Matt Kaeberlein](https://halo.dlmp.uw.edu/people/matt-kaeberlein/) (Professor of Pathology and Co-Director of both the Dog Aging Project and the UW Nathan Shock Center of Excellence in the basic Biology of Aging at the University of Washington) [43:15]
- [Dave Sharp](https://directory.uthscsa.edu/academics/profile/sharp)  (Professor Emeritus at the University of Texas Health Science Center at San Antonio and rapamycin expert) [43:30]
- [Brian Kennedy](https://medicine.nus.edu.sg/bch/faculty/brian-kennedy/) (Professor of Biochemistry and Physiology and Programme Director for the Healthy Longevity Translational Research Programme at National University of Singapore) [44:15]
- [Joan Mannick](https://milkeninstitute.org/events/fhs19/speakers/39958) (Co-founder of resTORbio and expert in treating aging-related diseases) [45:30]
- [Lloyd Klickstein](https://srfcure.org/lloyd-klickstein/) (CSO of the Scleroderma Research Foundation and expert in drug development) [45:45]
- [Scott Pletcher](https://medicine.umich.edu/dept/molecular-integrative-physiology/scott-pletcher-phd) (Professor of Molecular and Integrative Physiology at the University of Michigan) [47:30]
- [Mike Garratt](https://www.otago.ac.nz/bms/expertise/profile?id=2975) (conducts aging research at the University of Otago in New Zealand) [50:00, 1:48:45]
- [Catherine Kaczorowski](https://medicine.umich.edu/dept/mni/catherine-kaczorowski-phd) (Professor of Neurology at the University of Michigan) [51:00, 1:29:45]
- [Steve Horvath](https://altoslabs.com/team/principal-investigators-san-diego/steven-horvath/) (PI at Altos Labs, former Professor of Human Genetics and Biostatistics at UCLA, expert in epigenetic markers of aging) [53:34]
- [Vadim Gladyshev](https://dms.hms.harvard.edu/people/vadim-gladyshev) (Professor of Medicine at Harvard, aging expert) [56:15]
- [Maroun Bou Sleiman](https://people.epfl.ch/maroun.bousleiman/?lang=en) (Scientist in the Laboratory of Integrative Systems Physiology at EPFL, Switzerland) [56:30]
- [Xinna Li](https://www.pathology.med.umich.edu/faculty/xinna) (Assistant Research Scientist in Rich Miller’s lab at the University of Michigan) [1:07:30, 1:34:00]
- [Alana Horowitz](https://www.linkedin.com/in/alana-horowitz-3096b34b) (Engagement manager at McKinsey & Co, former PhD student of [Saul Villeda](https://villedalab.ucsf.edu/team) at UCSF) [1:10:00]
- [Gonzalo Garcia](https://www.richmillerlab.com/laboratory-members) (Assistant Research Scientist in Rich Miller’s Lab at the University of Michigan) [1:11:00, 1:19:30]
- [Gary Churchill](https://www.jax.org/research-and-faculty/research-labs/the-churchill-lab) (PI at the Jackson Laboratory investigating the genetic contribution to disease) [1:13:00, 1:18:00]
- [Joe Endicott](https://www.richmillerlab.com/laboratory-members) (Research Instructor in Rich Miller’s lab at the University of Michigan) [1:14:15, 1:20:00]
- [Andrzej Bartke](https://www.siumed.edu/andrzej-bartke.html) (Professor Emeritus and Director of Geriatric Medicine in the Departments of Internal Medicine and Physiology at Southern Illinois University School of Medicine; he developed the Ames dwarf mouse) [1:24:15]
- [Steven Cummings](https://sfcc.ucsf.edu/steven-r-cummings-md) (Emeritus Professor of Medicine, Epidemiology and Biostatistics at UCSF and Research Scientist at California Pacific Medical Center Research Institute) [1:28:00]
- [Costas Lyssiotis](https://medicine.umich.edu/dept/molecular-integrative-physiology/costas-lyssiotis-phd) (Associate Professor, Molecular & Integrative Physiology at the University of Michigan) [1:29:45]
- [Hamilton Oh](https://profiles.stanford.edu/hamilton-oh) (PhD student in Stem Cell Biology and Regenerative Medicine in the lab of Tony Wyss-Coray at Stanford) [1:30:45]
- [Tony Wyss-Coray](https://profiles.stanford.edu/tony-wyss-coray) (DH Chen Professor II of Neurology at Stanford) [1:31:00]
- [James (Jim) Nelson](https://barshopinstitute.uthscsa.edu/team-member/nelson-james/) (Professor of Cellular and Integrative Physiology at the University of Texas Health Science Center at San Antonio) [1:44:45]
- [James Simkin](https://directory.hsc.wvu.edu/Profile/38338) (Professor of Neuroscience and Director of the Center for Basic & Translational Stroke Research at West Virginia University) [1:45:00]
- [Mike Stouts](https://alliedhealth.ouhsc.edu/Departments/Nutritional-Sciences/Faculty-and-Staff/Bio/michael-b-stout-phd) (Professor of Nutritional Sciences at the University of Oklahoma) [1:46:15]
- [Mariana Sadagurski](https://clasprofiles.wayne.edu/profile/ez3862) (Associate Professor of Integrative Biosciences at Wayne State University) [1:46:15]
- [Mohit Jain](http://www.jainlaboratory.org/mohit-jain/) (Associate Professor of Medicine and Pharmacology at UCSD) [1:48:45]
- [Rafael de Cabo](https://irp.nih.gov/pi/rafael-de-cabo) (PI at NIA and Chief of translational Gerontology) [1:52:45]
- [Richard Hodes](https://www.nia.nih.gov/about/staff/hodes-richard) (Director of the NIA at the NIH) [1:54:00]
- [David Sinclair](https://sinclair.hms.harvard.edu/people) (Professor of Genetics and President of the Academy for Health and Lifespan Research at Harvard) [1:54:15]
- [Gino A Cortopassi](https://ptx.ucdavis.edu/people/gino-cortopassi) (Professor of Molecular Biosciences at UC Davis) [2:03:00]
- [Paul Robbins](https://robbins.umn.edu/dr-paul-robbins-phd) (Professor of Biochemistry, Molecular Biology and Biophysics and Associate Director of the Institute on the Biology of Aging and Metabolism and the Medical Discovery Team on the Biology of Aging at the University of Minnesota)  [2:07:15]
- [James (Jim) Kirkland](https://www.mayo.edu/research/faculty/kirkland-james-l-m-d-ph-d/bio-00096544) (Professor of Physiology at the Mayo Clinic and expert in cellular senescence) [2:07:15]
- [Tamara Tchkonia](https://www.mayo.edu/research/departments-divisions/department-physiology-biomedical-engineering/about/faculty-staff?letter=T) (Associate Professor of Physiology at the Mayo Clinic)  [2:07:15]
- [Judity (Judy) Campisi](https://www.buckinstitute.org/lab/campisi-lab/) (Professor at the Buck Institute and expert in cellular senescence and age-related diseases) [2:13:15]
- [Monica Peacocke](https://www.legacy.com/us/obituaries/nytimes/name/monica-peacocke-obituary?id=14494333), (1955-2020, Dermatologist and expert in cellular senescence) [2:14:00]

§

![](https://peterattiamd.com/wp-content/uploads/2021/02/1x1-richard-miller-500x500.jpeg)

##### Richard Miller M.D., Ph.D.

Richard A. Miller, M.D., Ph.D., is a Professor of Pathology, Associate Director of Research for the Geriatrics Center, and Director of the Paul F. Glenn Center for Biology of Aging Research at the University of Michigan.  He received the BA degree in 1971 from Haverford College, and MD and PhD degrees from Yale University in 1976-1977.  After postdoctoral studies at Harvard and Sloan-Kettering, he began his faculty career at Boston University in 1982 and then moved to his current position at Michigan in 1990.

Dr. Miller has served in a variety of editorial and advisory positions on behalf of the American Federation for Aging Research and the National Institute on Aging, and served as one of the Editors-in-Chief of Aging Cell.  He is the recipient of the Nathan Shock Award, the AlliedSignal Award, the Irving Wright Award, an award from the Glenn Foundation, and the Kleemeier Award for aging research.  He has been a Senior Scholar of the Ellison Medical Foundation, and is a Fellow of the American Association for the Advancement of Science and a member of the American Association of Physicians.  At Michigan, he directs the Paul Glenn Center for Aging Research.

His research program includes ongoing studies of the mechanisms that link stress, nutrients, and hormones to delay aging in mice, development of new approaches to slow aging and disease through drugs and targeted mutations, and studies of the ways in which cells from long-lived birds, rodents, and primates differ from those of short-lived species.

For fun he sometimes photographs wildlife or landscapes; you can check it out [here](https://richardmiller.zenfolio.com/). [[RichMillerLab.com](https://www.richmillerlab.com/biog)]