# #67 – AMA #8: DNA tests, longevity genes, metformin, fasting markers, salt, inflammation, and more

**Source:** [https://peterattiamd.com/ama08/](https://peterattiamd.com/ama08/)

---

In this “Ask Me Anything” (AMA) episode, Peter answers a wide range of questions from subscribers. Bob Kaplan, Peter’s head of research, asks the questions. If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/). You can also watch (or listen) to this full episode on our website at the AMA #8 [show notes page](https://peterattiamd.com/ama08). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Do DNA kits provide actionable info for cancer, CVD, diabetes, Alzheimer’s, nutrition, or exercise? [1:45];
- What genes increase longevity? And do those genes show up on genetic tests like 23andMe? [12:00];
- Who are some people that Peter would like to have as guests on The Drive? [15:00];
- Inflammation: Is CRP a useful marker? What can one do to reduce it? And what other inflammatory markers can I look at to gauge health? [18:30];
- What lipid test does Peter now use on his patients? What are the three best cardiovascular laboratories? [28:00];
- Metformin for longevity: What considerations should one think about before doing taking metformin for longevity purposes? [32:30];
- What is Peter’s take on salt and its role in things like high blood pressure and stomach cancer? [40:00];
- What markers does Peter find most interesting (and surprising) during his quarterly fasts? [47:30]; and
- More.

§

The Peter Attia Drive

DNA tests, longevity genes, metformin, fasting markers, salt, inflammation, and more

§

## Show Notes

## Do DNA kits provide actionable info for cancer, CVD, diabetes, Alzheimer’s, nutrition, or exercise? [1:45]

**Let’s go back to the** [**human genome project**](https://en.wikipedia.org/wiki/Human_Genome_Project)

- 20 years ago we were on the cusp of decoding the human genome
- We now know we have 20,000-30,000 genes
- But this notion that knowing the genome was going to change everything, **it hasn’t panned out**

**Cancer**: *Do genetic tests help?*

- We would think that the genetic revolution would help and that by knowing your genes you might know your susceptibility to a type of cancer
- However… there’s a difference between **germline mutations and somatic mutations**

⇒ Germline mutations

- Germline is the genes that you inherit
- So when you do a test like a [23andMe](https://en.wikipedia.org/wiki/23andMe) (not withstanding the huge inaccuracies that show up when you do these short kit SNP tests) what you’re doing is looking at the template you inherited (henec, germline)
- There are a subset of cancers where just knowing you inherited a certain gene dramatically increases your risk of that cancer
  - [BRCA mutation](https://en.wikipedia.org/wiki/BRCA_mutation) (you risk depends on which variant of it you have, but it approaches 80% with at least one of the variants)
  - [Lynch Syndrome](https://en.wikipedia.org/wiki/Hereditary_nonpolyposis_colorectal_cancer) (if you have the gene, it’s virtually guaranteed you’re going to get cancer)
- So *would knowing you have those genes be helpful*?
  - Yes, however, as a general rule, if you know your parents (i.e., not adopted) you will likely know you have this *without* the genetic test
  - However, patients who are adopted **probably benefit from this**

⇒ Somatic mutations

- Peter estimates that more than 95% of cancers are [somatic mutations](https://en.wikipedia.org/wiki/Somatic_(biology)) (and not germline)
- They are mutations that are acquired **after** you’ve received all of your genetic material
- The current type of genetic tests **don’t measure those somatic mutations**
  - You can’t find those mutations in the DNA of the base cell
  - You have to look for those cells like a needle in a haystack
  - You’re looking for those cells, usually in the blood
- W*hat tests do find these mutation*?
  - [Liquid biopsies](https://en.wikipedia.org/wiki/Liquid_biopsy)
    - where you could do a blood test, and in theory, you could find that needle in a haystack…you could find that cancer cell
    - For more on liquid biopsies see [Peter’s talk with Keith Flaherty](https://peterattiamd.com/keithflaherty/)

> “From the standpoint of cancer, I don’t think there’s a lot of value.”

**Cardiovascular disease**: *Is there value in genetic testing?*

- Probably “very little”
- The most important genetic test that you would look at from a heart disease standpoint would be [LP(a)](https://en.wikipedia.org/wiki/Lipoprotein(a))
- About 8 and 12% of the population has it and that is important to know
- HOWEVER…
- You don’t need a genetic test to do that
- Just measure the phenotype…you can actually measure LP(a)
- Plus it’s even easier to measure

> “I think if you go deep enough on the phenotypic side, you will get that information and you will get it in an even better way and you will have a metric with which to track as you try to reverse the process.”

**Diabetes**: *Is genetic testing useful*?

- Knowing whether someone is susceptible to T2D is not nearly as helpful as knowing they have hyperinsulinemia (when they are still non-diabetic)
- Subtle markers of insulin resistance, the elevation of [ferritin](https://en.wikipedia.org/wiki/Ferritin), patterns of glucose disposal, “*these things matter a lot more*”
- Wearing a [CGM](https://en.wikipedia.org/wiki/Continuous_glucose_monitor) … is orders of magnitude more insightful, and perhaps more importantly, more actionable

\*Check out [Peter’s discussion with Dexcom’s CEO](https://peterattiamd.com/kevinsayer/) for more on CGM technology

**Alzheimer’s disease**: *Is genetic testing useful?*

- Somewhat… and definitely more so than the previous examples
- Knowing your APOE status is “quite an empowering thing”
- However…Peter says even if you have a lower risk APOE profile (i.e., no copies of APOE4) it should not detract someone from taking an all hands on deck approach to avoiding dementia

⇒ See [Peter’s discussion with Richard Isaacson](https://peterattiamd.com/richardisaacson/) for more on Alzheimer’s

- 25% of the population has APOE4 positive gene, and they make up 2/3 of the cases of Alzheimer’s disease
- That means, however, that ⅓ of the cases of AD are people without E4
- So in that sense, knowing you have an **E4 may be helpful if you need a little extra motivation to work harder**

**Nutrition & exercise**: *Are genetic tests helpful?*

“I am not convinced that we can extract much value vis-a-vis what we should be eating or how we should be tailoring our exercise from the current genetics [tests].”

Promising tests?

- There are probably certain genes in the [PPAR family](https://en.wikipedia.org/wiki/Peroxisome_proliferator-activated_receptor), for example, that might speak to our ability to metabolize fat, that might speak to whether or not we will do better or do worse on a certain type of diet
- Peter would counter that by saying, “*you can empirically determine that so easily that I’m not sure it’s adding value*”
- Even if you saw that you had a genetic predisposition to one diet or another, it still doesn’t mean that that’s going to work. You still have to go through the empirical step.

**Peter concludes** that it’s very rare that a piece of information from a genetic test has changed the way he does something with a patient… “*overall, the yield is not that high and one should calibrate their expectations for that.*”

## What genes increase longevity? And do those genes show up on genetic tests like 23andMe? [12:00]

- For most “longevity genes”, you don’t necessarily pull those out of the genetic tests
- One exception, FOXO genes (i.e., you have a favorable FOXO3A genotype)
- That said, you will know if you have a subset of “longevity genes” simply by seeing your parents and grandparents living until their 80s and 90s and doing so relatively healthfully

*What are those genes?*

-Tier 1 genes would be:

- [APOC3](https://en.wikipedia.org/wiki/Apolipoprotein_C3)
- [APOE](https://en.wikipedia.org/wiki/Apolipoprotein_E)
- [FOXO3A](https://en.wikipedia.org/wiki/FOXO3)
- [CETP](https://en.wikipedia.org/wiki/Cholesterylester_transfer_protein)
- [IGF-1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1)
- [GHR](https://en.wikipedia.org/wiki/Growth_hormone_receptor)

-Second tier:

- [LPA](https://en.wikipedia.org/wiki/Lipoprotein(a)) (the gene for LP(a))
- [TSHR](https://en.wikipedia.org/wiki/Thyrotropin_receptor)

**What’s more interesting to me than these genes… is what’s the phenotype of these genes and why do these genes matter?**

[FOXO genes](https://en.wikipedia.org/wiki/FOX_proteins)

- Favorable FOXO genes tend to reduce risk across the board

Lower risk of cardiovascular disease

- Favorable [PCSK9](https://en.wikipedia.org/wiki/PCSK9), favorable LP(a), favorable [CETP](https://en.wikipedia.org/wiki/Cholesterylester_transfer_protein), favorable [APOC3](https://en.wikipedia.org/wiki/Apolipoprotein_C3)
- Every one of those genes drives a **phenotype** that lowers your risk of cardiovascular disease

Lower cancer risk

- Favorable [IGF](https://en.wikipedia.org/wiki/Insulin-like_growth_factor), favorable [GHR](https://en.wikipedia.org/wiki/Growth_hormone_receptor)

Lower Alzheimer’s risk

- APOE genes (e.g., not having an E4 variant reduces your risk of AD)

> “If you are genetically blessed to become a centenarian, the gift you got is that you have genes that **delay your receipt of chronic disease by what appears to be about 20 years.”**

## Who are some people that Peter would like to have as guests on The Drive? [15:00]

- [Dwayne “The Rock” Johnson](https://en.wikipedia.org/wiki/Dwayne_Johnson) (because why not??)
- [Banksy](https://en.wikipedia.org/wiki/Banksy)
- [Dana Jack](https://fairhaven.wwu.edu/users/djack) (depression in women)
- [Terry Real](https://www.terryreal.com/about/) (depression in men)
- [Esther Perel](https://twitter.com/estherperel?lang=en) (expert in relationality)
- [Dave Chappelle](https://en.wikipedia.org/wiki/Dave_Chappelle) (b/c Peter’s a fanboy)
- [Kevin Hart](https://twitter.com/KevinHart4real) (b/c Peter’s a fanboy)

⇒ Side note: Peter wants to put together a compilation of all of his favorite stand up bits (Dave Chappelle, [Jim Gaffigan](https://en.wikipedia.org/wiki/Jim_Gaffigan), [Jim Jeffries](https://en.wikipedia.org/wiki/Jim_Jefferies_(comedian)))

- [Sasha Cohen](https://en.wikipedia.org/wiki/Sasha_Cohen) (aka Borat and Ali G)
- [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) (Peter would like to tease out the “drug era” and talk about what physiologic machines these cyclists really were)

Pipe dream guests:

- [George W. Bush](https://en.wikipedia.org/wiki/George_W._Bush)
- [Barack Obama](https://en.wikipedia.org/wiki/Barack_Obama)
- “*Politics aside, they are both incredibly interesting people.*”

## Inflammation: Is CRP a useful marker? What can one do to reduce it? And what other inflammatory markers can I look at to gauge health? [18:30]

[C-Reactive Protein](https://en.wikipedia.org/wiki/C-reactive_protein) (CRP)

- Secreted by the liver, it is **nonspecific** relative to tissue
- Any time the chemokines that arrive from macrophasias, monosites, differentiated, etc. show up in the circulation, the liver’s picking up on that and it’s raising CRP
- Yes, it is helpful to know CRP
- However, it’s more helpful when you pair it with another marker called [fibrinogen](https://en.wikipedia.org/wiki/Fibrinogen)

Fibrinogen

- a clotting factor
- Also nonspecific

If fibrinogen and CRP are elevated, it could mean…

- Something related to cardiovascular disease
- But, more commonly, it means there is something in the diet causing low-level of irritation
- The two most common foods that cause this?
  - Wheat
  - Dairy

Specific markers of inflammation for the cardiovascular system

- [Lp-PLA2](https://en.wikipedia.org/wiki/Lipoprotein-associated_phospholipase_A2)
- [Ox-LDL](https://en.wikipedia.org/wiki/Low-density_lipoprotein#Oxidized_LDL)
- \*These are related to the health of the [endothelium](https://en.wikipedia.org/wiki/Endothelium)
- And how many of the [LDL particles](https://en.wikipedia.org/wiki/Low-density_lipoprotein) are being oxidized.

Another marker: [Myeloperoxidase](https://en.wikipedia.org/wiki/Myeloperoxidase)

- However, Peter says he stopped looking at this because “I haven’t found it to add more value above and beyond what I’m currently doing”

Another marker: Interleukins

- You can start to individually look at various [interleukins](https://en.wikipedia.org/wiki/Interleukin)
- In particular [interleukin 1](https://en.wikipedia.org/wiki/Interleukin#Interleukin_1) and [interleukin 6](https://en.wikipedia.org/wiki/Interleukin#Interleukin_6)

**What to do when there is inflammation?**

First of all…

- make sure we’re not overreacting to it.
  - Example, if someone’s CRP is 45 (and normal is less than one), it’s likely their test was compromised by the person being sick (or something)

**A more useful (and challenging) case to consider**: *Diffuse inflammation* (for which you don’t have a clear answer)

- We look at [erythrocyte sedimentation rate](https://en.wikipedia.org/wiki/Erythrocyte_sedimentation_rate) (ESR) and it’s normal
- All their lipid-specific markers are fine
- Their [homocysteine](https://en.wikipedia.org/wiki/Homocysteine) is fine
- But their CRP is above 1 and their fibrinogen is also elevated
- “*That’s the person you go down the path of,* ***how can we start doing dietary elimination?***”

⇒ The approach:

- Strict elimination of dairy for two months, retest
- If nothing…
- Strict elimination of wheat, retest.
- 60 to 80% of the time one of those two interventions, if done correctly, fixes the issue

⇒ If it doesn’t fix the issue:

We try heavier doses of things like [curcumin](https://en.wikipedia.org/wiki/Curcumin) ([Pure Encapsulations](https://www.pureencapsulations.com/curcumin.html) brand)

- 500 mg twice a day
- \*If cost is not an issue, there’s a better version called [theracurmin](https://www.amazon.com/Integrative-Therapeutics-Theracurmin-Supplement-Bioavailable/dp/B0765DHTVL?th=1) (Integrative Therapeutics)

In the case of normal CRP but elevated fibrinogen…

- Peter will try [nattokinase](https://www.webmd.com/vitamins/ai/ingredientmono-1084/nattokinase) ([Jarrow brand](https://www.jarrow.com/product/245/NattoMax))

\*QUICK TIP: **Nattokinase is very helpful for people with hypercoagulability when they travel via airplane** ⇒ This is probably a top 10 best kept secrets on the internet is that you have an over-the-counter supplement that has double blinded placebo control data to reduce the risk of DVT and it rivals the pharmacologic equivalent, which is called Lovenox.

*Other quick tips to reduce inflammation*:

- Get more sleep
- Dial in nutrition (beyond just trying to eliminate dairy or wheat)
- Fasting ⇒ “*When fasting, there’s something very positive that comes. . . I think it’s also something that should always be in the inflammation toolkit.*”

*One final note*: **Not all inflammatory responses are a bad thing**

- Inflammation goes up transiently after exercise
- But exercise can also help lower baseline and chronic inflammation
- Chronic elevation is the problem

\*Check out [Peter’s discussion with Nav Chandel](https://peterattiamd.com/navchandel/) for more on the role of reactive oxygen species (ROS)

- They’re potentially signaling molecules and therefore knocking out ROS completely is a bad thing
- We certainly know that someone who can’t mount an immune response and an inflammatory response doesn’t live very long

## What lipid test does Peter now use on his patients? What are the three best cardiovascular laboratories? [28:00]

- Peter has now stopped using [NMR](https://ww5.allinahealth.org/ahs/allinalabs.nsf/page/ColorreportGraph.pdf/$FILE/ColorreportGraph.pdf) on patients for LDL
- He now uses [lipoprotein electrophoresis](https://www.ncbi.nlm.nih.gov/pubmed/18647703)
  - *Why?* ⇒ NMR cannot differentiate between an LP(a) and an LDL [whereas the electrophoresis can](https://www.ncbi.nlm.nih.gov/pubmed/25451955)

The three best cardiovascular labs:

- [True Health Diagnostics](https://truehealthdiag.com/)
- Berkeley Heart Lab
- [Boston Heart](https://bostonheartdiagnostics.com/)

**The takeaway**:

- If you have the ability to do so and your doctor has the willingness to use the labs, I think it’s worth doing advanced cardiac testing through one of those 3 labs.
- To be clear, [LabCorp](https://www.labcorp.com/) and [Quest](https://www.questdiagnostics.com/) are great labs in general, but when it comes to the really nerdy stuff like LP(a) and LDL and HDL-P, etc., I think you want to go with these best-in-class labs

\*For a masterclass on lipids, check out [Peter’s 5 part discussion with Tom Dayspring](https://peterattiamd.com/tomdayspring1/)

## Metformin for longevity: What considerations should one think about before doing taking metformin for longevity purposes? [32:30]

*What considerations should I think about before taking metformin?*

- **Step 1, 2, and 3**: Listen to [Peter’s talk with Nir Barzalai](https://peterattiamd.com/nirbarzilai/)

*What about* [*berberine*](https://en.wikipedia.org/wiki/Berberine)*?*

- It is a weak AMPK activator
- “A poor man’s metformin”
- However, it is over the counter (e.g., [Thorne brand](https://www.thorne.com/products/dp/berberine-500?gclid=CjwKCAjwpuXpBRAAEiwAyRRPgXy6sJt0ov7g5wySlBXaIvTGrZuuNNlP9t5-J7Jnoj_nT4wAmV_6jBoCOI8QAvD_BwE))
- Berberine should lower hepatic glucose output
- For more on berberine, **check out** [**AMA #3**](https://peterattiamd.com/ama03/)

[**TAME study**](https://www.afar.org/research/TAME/)

- The question Peter hopes is answered: *Does someone who does NOT have diabetes, pre-diabetes, hyperinsulinemia, is there a benefit to them using metformin?*
- Data is quite clear that: If you have Type 2 diabetes (or you’re hyperinsulinemic and pre-diabetic) that metformin has a significant benefit with respect to cancer reduction

***What is the harm in taking metformin?***

- “I don’t think I know the answer yet.” says Peter
- Theoretical arguments that by impairing complex one of the mitochondria you can impair mitochondrial performance and mitochondrial efficiency,

*Peter recently changed how he doses metformin*:

- Used to take 1,000 in the morning and 1,000 in the evening
- Now just take 1,500 before bed and I don’t take a morning dose

> “I’m trying to have a little less metformin in my system when I’m awake and active and a little more metformin in my system when I’m sleeping and trying to hit my liver over the head and tell it to stop spitting out so much glucose.”

**Peter’s thesis on drugs that come from nature**:

“*I think the most exciting drugs in the world are drugs that come from nature.*”

Examples:

- Metformin comes from a plant in France
- Rapamycin comes from a bacteria that were found on Easter Island
- Statins are just a more potent versions of something you find in red yeast rice

> “These drugs that have some of the most remarkable properties in our toolbox, I don’t think it’s an accident that they all came from nature. I think that nature gave us a billion years to refine how to create a drug that would be toxic to one plant and not to another. For example, the bacteria, streptomyces hygroscopicus that came up with what would be called Rapamycin was clearly a tool to keep something else, probably yeast, at bay. It had to be potent enough to do that but not so potent that it would kill itself.”

## What is Peter’s take on salt and its role in things like high blood pressure and stomach cancer? [40:00]

“*It’s a complicated topic, but not as complicated as we make it out to be*,” says Peter

**Stomach cancer**

- Stomach cancer is very hard to identify salt (sodium) as the driver of that because the sodium itself comes along for the ride with other things
- “I don’t find any of the data on sodium and cancer to be remotely interesting.

*Tangent on MSG*:

- Peter does NOT believe [MSG](https://en.wikipedia.org/wiki/Monosodium_glutamate) is much of a problem either in terms of cancer
- Not convinced of any of the data that demonized MSG.. I
- “I think MSG is a perfectly reasonable substance. I think, again, it’s just a victim of some really bad epidemiology”

\*Check out [Peter’s five-part Studying Studies series](https://peterattiamd.com/ns001/) for more on the limitations of epidemiology

**Blood pressure**

- More salt in the plasma means more osmotic pressure ⇒ more osmotic pressure means more blood pressure
- By that logic it’s impossible to imagine that more sodium doesn’t result in higher blood pressure
- And that argument *would be true* were it not for the [nephron](https://en.wikipedia.org/wiki/Nephron)

*The kidney*

- The nephrons in the kidney regulate sodium levels
- When ingesting more sodium, it superficially seems like it would increase blood pressure, however, when you really dig into the renal physiology it doesn’t appear to be the case
- The kidney is more than sophisticated enough to figure out how to buffer and/or balance more or less sodium (also potassium, magnesium, chloride, hydrogen, etc.)

“*Acid based physiology is super complicated and the kidney has it pretty dialed in.*”

*Does that mean no amount of salt is harmful?*

- Peter says “no, I think that’s also equally naïve”
- Such as cases where people have [kidney disease](https://en.wikipedia.org/wiki/Kidney_disease)
- There probably are a **subset** of patients whose hypertension is mediated through sodium
  - The challenge is…*how do we identify those patients?*

**Best paper on salt and blood pressure**: [Sodium Intake in Populations: Assessment of Evidence](https://www.nap.edu/read/18311/chapter/1#v) (IOM, 2013)

- They clearly didn’t find was that the answer was “Have less sodium.”
- So even though “less sodium” is a mainstay position of the CDC… “*I think it’s very difficult to find helpful evidence to make that point.*”

*The positive side of restricting sodium*:

- If you take somebody on [Standard American Diet](https://en.wikipedia.org/wiki/Western_pattern_diet) and tell them to eat less salt generally going to eat a hell of a lot better
- So in that sense, you get good things out of sodium restriction…but it’s not from the sodium restriction, per se

⇒ In other words:

- Someone eating Mr. Chunky soup out of a jar (chock full of sodium) and switch them to making their own veggie soup (and they add the same amount of salt) their likely going to be getting healthier from that switch
- In the end, it’s most likely that the benefits of eating less sodium is coming from the reduction of processed foods (i.e., less potato chips and more salads)

## What markers does Peter find most interesting (and surprising) during his quarterly fasts? [47:30]

*Peter is most intrigued by the following*:

1. [Reverse T3](https://en.wikipedia.org/wiki/Reverse_triiodothyronine) skyrocketing (just such an awesome demonstration of physiology… see video about thyroid physiology COMING SOON)
2. Testosterone dropping
3. [Uric acid](https://en.wikipedia.org/wiki/Uric_acid) increasing (“mind boggling”… uric acid and bhb compete for the same transporter in the kidney and ketones out compete)

  “*Those three just constantly amaze me the most.*”

*Most surprising finding*: Adiponectin stays the same (unsure why, should get higher…plans to ask [Rudy Leibel](https://peterattiamd.com/rudyleibel/))

*How to Peter feel, physically, during his fasts?*

- Typically Peter feels pretty good while fasting
- That said, Peter has had times where he felt miserable during a fast (for unexplained reasons)
- But more often, Peter feels really good
- During a recent fast, he almost forgot he was fasting (“the only time I ever felt like I could do this for a month”)

> “So to me the experience is just beautiful and it’s humbling and honestly it just gives me something to look forward to every quarter when I go into these fasts. . .it’s always going to be a different adventure and there’s always going to be some crazy physiology and I’m going to have to figure out how to adapt.”

§

## Selected Links / Related Material

**Popular genetic test**: [23andMe](https://en.wikipedia.org/wiki/23andMe) | (wikipedia.org) [1:45]

**Exciting genome sequencing project that didn’t pan out in terms of solving/curing many diseases (i.e., cancer)**: [**Human Genome Project**](https://en.wikipedia.org/wiki/Human_Genome_Project) | (wikipedia.org) [2:00]

**Gene that increases your risk for cancer**: [BRCA mutation](https://en.wikipedia.org/wiki/BRCA_mutation) | (wikipedia.org) [4:30]

**Gene that virtually guarantees you will get cancer**: [Lynch Syndrome](https://en.wikipedia.org/wiki/Hereditary_nonpolyposis_colorectal_cancer) | (wikipedia.org) [5:15]

**For more on liquid biopsies see Peter’s talk with Keith Flaherty**: [#62 – Keith Flaherty, M.D.: Deep dive into cancer— History of oncology, novel approaches to treatment, and the exciting and hopeful future](https://peterattiamd.com/keithflaherty/) | Peter Attia (peterattiamd.com) [6:30]

**Check out Peter’s discussion with Dexcom’s CEO for more on CGM technology**: [#54 – Kevin Sayer, CEO of Dexcom: Continuous glucose monitors – impact of food, sleep, and stress on glucose, the unmatched power of CGM to drive behavioral change, and the exciting future of CGM](https://peterattiamd.com/kevinsayer/) | Peter Attia (peterattiamd.com) [8:15]

**See Peter’s discussion with Richard Isaacson for more on Alzheimer’s**: [#18 – Richard Isaacson, M.D.: Alzheimer’s prevention](https://peterattiamd.com/richardisaacson/) | Peter Attia (peterattiamd.com) [9:00]

**Genes that may increase life span**: [12:00]

-Tier 1 genes would be:

- [APOC3](https://en.wikipedia.org/wiki/Apolipoprotein_C3)
- [APOE](https://en.wikipedia.org/wiki/Apolipoprotein_E)
- [FOXO3A](https://en.wikipedia.org/wiki/FOXO3)
- [CETP](https://en.wikipedia.org/wiki/Cholesterylester_transfer_protein)
- [IGF-1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1)
- [GHR](https://en.wikipedia.org/wiki/Growth_hormone_receptor)

-Second tier:

- [LPA](https://en.wikipedia.org/wiki/Lipoprotein(a)) (the gene for LP(a))
- [TSHR](https://en.wikipedia.org/wiki/Thyrotropin_receptor)

**Curcumin brand Peter recommends**: [Pure Encapsulations](https://www.pureencapsulations.com/curcumin.html) | (pureencapsulations.com) [23:00]

**Theracurmin brand Peter recommends**: [Integrative Therapeutics](https://www.amazon.com/Integrative-Therapeutics-Theracurmin-Supplement-Bioavailable/dp/B0765DHTVL?th=1) | (amazon.com) [23:00]

**Nattokinase brand Peter recommend**: [Jarrow Formulas NattoMax](https://www.jarrow.com/product/245/NattoMax) | (jarrow.com) [24:00]

**Check out Peter’s discussion with Nav Chandel for more on the role of reactive oxygen species (ROS)**: [#31 – Navdeep Chandel, Ph.D.: metabolism, mitochondria, and metformin in health and disease](https://peterattiamd.com/navchandel/) | Peter Attia (peterattiamd.com) [27:00]

**The lipid test that Peter uses with patients ⇒** ***Lipoprotein Electrophoresis***: [Immunofixation electrophoresis (IFE) of serum apolipoproteins: a new tool for probing lipoprotein disorders and the atherosclerosis risk.](https://www.ncbi.nlm.nih.gov/pubmed/18647703) (Semprini et al., 1992) [28:00]

**The electrophoresis test can differentiate between an LP(a) and an LDL whereas the NMR test cannot**: [Validation of a lipoprotein(a) particle concentration assay by quantitative lipoprotein immunofixation electrophoresis.](https://www.ncbi.nlm.nih.gov/pubmed/25451955) (Guadagno et al., 2015) [28:00]

**The three best cardiovascular labs**: [30:45]

- [True Health Diagnostics](https://truehealthdiag.com/)
- Berkeley Heart Lab
- [Boston Heart](https://bostonheartdiagnostics.com/)

**For a masterclass on lipids, check out Peter’s discussion with Tom Dayspring**: [31:30]

1. [#20 – Tom Dayspring, M.D., FACP, FNLA – Part I of V: an introduction to lipidology](https://peterattiamd.com/tomdayspring1/)
2. [#21 – Tom Dayspring, M.D., FACP, FNLA – Part II of V: Lipid metrics, lipid measurements, and cholesterol regulation](https://peterattiamd.com/tomdayspring2/)
3. [#22 – Tom Dayspring, M.D., FACP, FNLA – Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins](https://peterattiamd.com/tomdayspring3/)
4. [#23 – Tom Dayspring, M.D., FACP, FNLA – Part IV of V: statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain](https://peterattiamd.com/tomdayspring4/)
5. [#24 – Tom Dayspring, M.D., FACP, FNLA – Part V of V: Lp(a), inflammation, oxLDL, remnants, and more](https://peterattiamd.com/tomdayspring5/)

**For everything you need to know about metformin check out Peter’s discussion with Nir Barzalai**: [#35 – Nir Barzilai, M.D.: How to tame aging](https://peterattiamd.com/nirbarzilai/) | Peter Attia (peterattiamd.com) [32:30]

**Brand of berberine supplement Peter recommends**: [Thorne Berberine-500](https://www.thorne.com/products/dp/berberine-500?gclid=CjwKCAjwpuXpBRAAEiwAyRRPgXy6sJt0ov7g5wySlBXaIvTGrZuuNNlP9t5-J7Jnoj_nT4wAmV_6jBoCOI8QAvD_BwE) | (thorne.com) [33:00]

**For more on berberine check out a previous AMA**: [#26 – AMA #3: supplements, women’s health, patient care, and more](https://peterattiamd.com/ama03/) | Peter Attia (peterattiamd.com) [33:30]

**Nir’s study trying to show that metformin can slow the aging process**: [TAME Trial](https://www.afar.org/research/TAME/) | (afar.org) [33:45]

**Check out Peter’s five-part Studying Studies series for more on the limitations of epidemiology**: [44:30]

1. [Studying Studies: Part I – relative risk vs. absolute risk](https://peterattiamd.com/ns001/)
2. [Studying Studies: Part II – observational epidemiology](https://peterattiamd.com/ns002/)
3. [Studying Studies: Part III – the motivation for observational studies](https://peterattiamd.com/ns003/)
4. [Studying Studies: Part IV – randomization and confounding](https://peterattiamd.com/ns004/)
5. [Studying Studies: Part V – power and significance](https://peterattiamd.com/studying-studies-part-v-power-and-significance/)

**Best paper on salt and blood pressure**: [Sodium Intake in Populations: Assessment of Evidence](https://www.nap.edu/read/18311/chapter/1#v) (IOM, 2013) [45:15]

§

## People Mentioned

- [James Watson](https://en.wikipedia.org/wiki/James_Watson) (human genome project) [2:15]
- [Richard Isaacson](https://vivo.med.cornell.edu/display/cwid-rii9004) (Alzheimer’s) [9:00]
- [Dwayne Johnson](https://en.wikipedia.org/wiki/Dwayne_Johnson) (someone Peter wants as a guest on The Drive) [15:30]
- [Banksy](https://en.wikipedia.org/wiki/Banksy) (someone Peter wants as a guest on The Drive) [15:30]
- [Dana Jack](https://fairhaven.wwu.edu/users/djack) (depression in women, someone Peter wants as a guest on The Drive) [15:30]
- [Terry Real](https://www.terryreal.com/) (depression in men, someone Peter wants as a guest on The Drive) [15:30]
- [Esther Perel](https://v) (relationality, someone Peter wants as a guest on The Drive) [15:30]
- [Dave Chappelle](https://en.wikipedia.org/wiki/Dave_Chappelle) (someone Peter wants as a guest on The Drive) [16:15]
- [Kevin Hart](https://en.wikipedia.org/wiki/Kevin_Hart) (someone Peter wants as a guest on The Drive) [16:15]
- [Jim Gaffigan](https://en.wikipedia.org/wiki/Jim_Gaffigan) (stand-up comedian Peter enjoys) [16:15]
- [Jim Jeffries](https://en.wikipedia.org/wiki/Jim_Jefferies_(comedian)) (stand-up comedian Peter enjoys) [16:15]
- [Borat](https://en.wikipedia.org/wiki/Borat) [17:15]
- [Ali G](https://en.wikipedia.org/wiki/Ali_G) [17:15]
- [Sasha Baron Cohen](https://en.wikipedia.org/wiki/Sacha_Baron_Cohen) [17:15]
- [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) (someone Peter wants as a guest on The Drive) [17:15]
- [George W. Bush](https://en.wikipedia.org/wiki/George_W._Bush) (someone Peter wants as a guest on The Drive) [18:00]
- [Barack Obama](https://en.wikipedia.org/wiki/Barack_Obama) (someone Peter wants as a guest on The Drive) [18:00]
- [Navdeep Chandel](https://peterattiamd.com/navchandel/) (reactive oxygen species) [27:15]
- [Tom Dayspring](https://www.linkedin.com/in/thomas-dayspring-md-facp-fnla-3aaa876/) (expert in lipids, former guest on The Drive) [29:30]
- [Nir Barzilai](https://peterattiamd.com/nirbarzilai/) (metformin, TAME study) [32:30]
- [Rudy Leibel](https://peterattiamd.com/rudyleibel/) (Peter wants to ask him why his adiponectin doesn’t go up during a fast) [49:15]

§