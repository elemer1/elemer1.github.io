# #165 – AMA #24: Deep dive into blood glucose: why it matters, important metrics to track, and superior insights from a CGM

**Source:** [https://peterattiamd.com/ama24/](https://peterattiamd.com/ama24/)

---

In this “Ask Me Anything” (AMA) episode, Peter and Bob dive deep into blood glucose and why it matters so much with respect to metabolic health and longevity. They explain the need to pay close attention to metrics like average blood glucose, glucose variability, and peak glucose numbers. Additionally, Peter explains why he encourages all his patients, even nondiabetics, to utilize a continuous glucose monitor (CGM) which gives important insights that traditional lab testing and metrics consistently miss.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #24 show notes page](https://peterattiamd.com/ama24/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- The problem with traditional blood tests and metrics for determining metabolic health [1:10];
- The superior insights from a continuous glucose monitor [6:15];
- Why lower is better than higher: average glucose, glucose variability, and glucose peaks [12:00];
- Deep dive into average blood glucose and the importance of having the lowest average blood glucose possible [14:45];
- Deep dive into glucose variability and why less variability is better [33:15];
- Example of how HbA1c and traditional measures could catch metabolic issues too late [41:45];
- Postprandial dips in blood glucose as a predictor of subsequent hunger and energy intake [43:00];
- Exploring the idea that the suppression of fatty acids is actually causing hunger rather than a low blood glucose [49:45];
- Deep dive into peak glucose and why lower peaks is better [57:15];
- What the best rodent models tell us about the impact of peak glucose levels [1:06:25];
- Why Peter encourages all his patients to wear a CGM [1:14:30]; and
- More.

§

The Peter Attia Drive

Deep dive into blood glucose: why it matters, important metrics to track, and superior insights from a CGM

§

## Show Notes

§

## The problem with traditional blood tests and metrics for determining metabolic health [1:10]

**In terms of testing**, Peter favors the [oral glucose tolerance test](https://en.wikipedia.org/wiki/Glucose_tolerance_test) (OGTT) over things like fasting glucose and HbA1c measurements as those can be misleading

**Some great questions from subscribers**:

- “With insulin measurements. And also wearing a CGM to get a better sense of glucose homeostasis. My understanding is that OGTTs and CGMs are typically reserved for people with diabetes.”
- Why does Peter find these tests useful in “healthy” people?
- What is Peter looking for when assessing someone’s glucose levels?
- What does he like and hate to see?
- How does Peter define normal versus abnormal control of glucose?
- If I’m not diabetic, do I have anything to worry about here?”
- “Are you able to do a breakdown on what you look for on different people’s CGM data and what you would advise to improve their numbers similar to the AMA you did on lab tests?”

*Peter’s reaction to these questions*:

- “*These are the perfect questions, the most salient questions, the most important questions and this might become by extension* ***one of the most important AMAs we do in terms of the aggregate impact it could have on health and longevity***.”

> “The mainstream medical system is just so out of sync with what I believe the future of medicine is going to be.” —Peter Attia

**Defining T2D and HbA1c**:

- Type 2 diabetes is defined as having a [hemoglobin A1c](https://en.wikipedia.org/wiki/Glycated_hemoglobin) (HbA1c) concentration greater than 6.5% which it corresponds to an average glucose of approximately 130 milligrams per deciliter
- The way it HbA1c works is it measures the concentration of glycosylated hemoglobin. So it’s taking out red blood cells and it’s looking at how much glucose is stuck to them
- the more glucose that is stuck to them, the more you can infer that the average concentration of glucose is higher during the period of a red blood cell’s life

*This is* ***potentially misleading*** *in both directions because, for example:*

- if a red blood cell has a very short life — GI bleeding issues, patients with gastritis, et cetera, women with a heavy menstrual period — So people who are losing significant amounts of blood have a higher turnover of red blood cells, they’re going to have an **artificially low** hemoglobin A1c
- Conversely, people who have red blood cells that stick around a very long time — people with a microcytic pattern, meaning they have very small red blood cells that are less likely to get chewed up in the splanchnic system which is where we ultimately break down red blood cells — they’re going to have an **artificially elevated** hemoglobin A1c because their red blood cells are living longer on average than the typical person which is about 90 days

*\*The broader point*:

- Unhelpful to simply say if your hemoglobin A1c is above 6.5 and you have type 2 diabetes, you have “a disease”
- If it is below 6.5 you are normal or even if we go one step further and say well there’s a pre diabetes which is defined as 5.7 to 6.4 and those people we have to watch out for
- but anybody at 5.6 and down is completely normal
- As though there’s some enormous difference between 5.6 and 5.7 or 6.4 and 6.5
- on the one hand I understand the need to simplify things, I think oversimplification is erroneous and I think we should view these as a continuum
- glucose at the average level is a continuum
- “I am a far greater proponent of [continuous glucose monitors] (CGM)”

##

## The superior insights from a continuous glucose monitor [6:15]

**Continuous glucose monitor (CGM)**

- As its name suggests, it measures glucose continuously
- “And while I do not have diabetes and while most of my patients don’t have diabetes, many of them along with I wear this device”
- This podcast will get into the “why”

*Using a CGM:*

- Your CGM connects to your phone and every five minutes it is spitting out a number in a 24 hour fashion
- For Peter, his last 24 hours I’ve averaged about 90 milligrams per deciliter
- His variability/standard deviation has been about 9 or 10 milligrams per deciliter
- His peak level was 102, his nadir was 77 — So a range of 77 to 102
- There are reports that will spit out your average glucose over 1 day, 7 days, 14 days, 30 days, 60 days, 90 days, etc. along with the standard deviation and more
- A CGM is not actually measuring in the blood, it’s measuring in the interstitial fluid, a “remarkable technology”
- It’s able to impute what the glucose level is in the blood without actually having to sample the blood

**Bob asks Peter:** ***Have you looked at your CGM and compared say like your three month data to your HbA1c?***

- Yes, “there’s no comparison” says Peter
- Peter has something called [beta thalassemia minor](https://www.hopkinsmedicine.org/health/conditions-and-diseases/beta-thalassemia) (or he carries the trait for beta thalassemia) which means he has tiny little red blood cells
  - His mean corpuscular volume and mean corpuscular hematocrit are very low, but he’s not anemic because his body makes up for it by having a lot of them
  - In result, he has a normal hemoglobin hematocrit oxygen carrying capacity but his hemoglobin A1c always runs high
  - He’s measured it as high as 5.8, and the lowest he’s ever measured is 5.1
  - After wearing a CGM for almost six years, if he goes back and checkers his A1c versus his trailing 90-day CGM, it almost always suggests that the hemoglobin A1c is higher by 0.5 to 0.8
  - If he measures a 5.7 on the hemoglobin A1c, it’s overstating his blood glucose and it should really be about a 5.1 or a 5.2
- It’s also possible to see the opposite situation in some people where their CGM is actually showing a much higher level of average blood glucose than what their hemoglobin A1c predicts
- So it’s important to understand hemoglobin A1c is a measurement that predicts average blood glucose
- CGM actually gives you average blood glucose and you can reverse engineer and impute at A1c
- The latter is much more interesting because you’re directly measuring the variable of interest

**Peter’s hope for the future of medicine and doctor’s visits**

- The obvious reason why everyone isn’t wearing a CGM is that they are cost prohibitive and certainly back then they were quite involved
- But they’re getting better and better and better, says Peter
- “I’d like to believe that there will be a day when you go to your first visit at your doctor or prior to your first visit with your doctor they mail you a CGM and you wear it for 30 days and that data is looked at by your doctor and by the time you arrive in the office he or she has that information.”
- “And instead of looking at an A1c or a fasting glucose they can really look at what your glucose excursions have looked like over a period of time in the real world.”

*For example*, some docs (including Peter) will do this for blood pressure (using a [sphygmomanometer](https://en.wikipedia.org/wiki/Sphygmomanometer))

- Peter says, “Most of our patients there’s a particular blood pressure monitor we fancy and we have them keep it at home. We have a special log.”
- “Unfortunately in the wearable space blood pressure is still far from primetime”, says Peter, “but I think there’s going to be wearables in the blood pressure space soon”

##

## Why lower is better than higher: average glucose, glucose variability, and glucose peaks [12:00]

**Important CGM metrics**

*For so-called “normal people” or the non-diabetic population, Peter would argue the following 3 points:*

1 — **lower average blood glucose is better**

- A hemoglobin A1c of 5.1 is better than a hemoglobin A1c of 5.5 even though neither of those people are anywhere near having type 2 diabetes

2 —  **The more you can minimize glucose variability the better.**

- And of course glucose variability is very difficult to measure without a CGM
- Using a GGM, the standard deviation is the obvious mathematical tool to do that, and lower is better
- For instance—
  - Say you have two people who both have an average glucose of 100 milligrams per deciliter (which corresponds to about an excellent HbA1c of 5.0 to 5.1)
  - And one of them has a standard deviation of 10 milligrams per deciliter and the other one has a standard deviation of 20, the person with the lower one is better off.

3 — **Minimizing glucose peaks is important (**irrespective of the average glucose and variability)

- Obviously the more peaks you have it’s going to, all things equal, push up glucose and it will certainly increase variability
- But Peter would argue specifically that glucose peaks are problematic and that we want to minimize them

*How Peter uses these metrics with patients:*

- For Peter’s patients, he will have them do a baseline assessment for 30 days to get these metrics
- In other words, your average blood glucose was this, your variability was this, and you went over some threshold—usually start at 140—X number of times per week
- From there Peter will methodically go down the path of reducing those metrics

##

## Deep dive into average blood glucose and the importance of having the lowest average blood glucose possible [14:45]

**Average glucose: why lower is better than higher**

- No shortage of data to support that lower avg. glucose is better than higher (ironic given that it is not something that is generally thought of)

To restate the question: *When you’re excluding patients with type 2 diabetes, is it better to have a lower average blood glucose than higher average glucose?*

- most of the data we have to look at here is observational so we’re not going to probably get a great answer because it’s going to be very difficult to do a randomization experiment to answer this question
- we can look at these cohorts prospectively, but they’re going to be done in an observational fashion

*What are some of the metrics we look  at in terms of outcomes? What do we care about here?*

- All cause mortality
- Then what’s most likely to kill us
  - cardiovascular disease and cardiovascular disease mortality
  - Cancer
  - cognitive decline and dementia
  - correlation with frailty
  - More recently looking more at respiratory viruses or in this case in the last couple of years with COVID-19 as well to see what’s going on there in diabetics and nondiabetics as well

**A couple of representative studies below showing associations between average glucose and mortality**

[**A 2011 prospective study**](https://link.springer.com/article/10.1007/s00125-011-2162-0):

- In nearly 20,000 nondiabetic participants, they found a continuous increase in the associated risk for death throughout a broad range of HbA1c values
- Mean age was 59
- And they did an 11 year followup and in this case they looked at all cause mortality, cardiovascular death, and cancer related death.
- They had the baseline and then they followed up on average about 11 years and looked at those metrics
- The table below shows the accrued incidence rates and they had the adjusted hazard ratios for each one of these
- **Note about confounding variables**: With an observational study they try to adjust for confounding variables in the groups. And in this case they looked at age, sex, systolic blood pressure, total cholesterol, smoking, waist to hip ratio, alcohol consumption and physical activity to try to adjust for some of the confounding variables

![](https://peterattiamd.com/wp-content/uploads/2021/06/F1.-ama24-Table-2-from-Pfister-et-al.-2011-1024x282.png)

**Figure 1.** Table 2 from [Pfister et al., 2011](https://link.springer.com/article/10.1007/s00125-011-2162-0)

- 1,000 people below a hemoglobin A1c of 4.5
- 2,800 between 4.5 and 5.0
- 6,500 between 5.0 and 5.5
- 5,200 between 5.5 and 6.0
- 1,300 between 6.0 and 6.5
- 348 above 6.5
- **The point here**: This is *mostly people without type 2 diabetes*

*Observations*:

- Then the next line in this table shows you all cause death
- then you see the absolutely mortality rate
- you see the unadjusted death rate per thousand
- And notice the complete monotonic increase  —
  - At the lowest level when your hemoglobin A1c is below 4.5 that amounts to 5.7 deaths per thousand person years rising slightly to 6.2 deaths at 4.5 to five
  - then when you get up to five to 5.5 you’re at 8.7 deaths per thousand person years
  - then you have this pretty big jump to 12.1
  - then 18.5
  - by the time you have diabetes it’s 24.6 deaths per thousand person years

*Why is it that we can’t just look at those numbers? Why do we have to look at the adjustment?*

- There are many things that can confound that data
- Just look at age, for example –you would almost see like a continuous increase in age when you go from their reference which is 5% to 5.5%
- Those people who are diabetic generally are going to be older
- And so you’re going to want to try to “correct for that”
- Those are two very different populations
- You can never really adjust for everything but you got to try at least
- Anytime you’re comparing someone with a hemoglobin A1c of 6.5, by definition that person has metabolic dysfunction
- A person with metabolic dysfunction also has more likely elevated blood pressure, atherosclerosis to a greater extent, et cetera

![](https://peterattiamd.com/wp-content/uploads/2021/06/F2.-ama24-Table-3-from-Pfister-et-al.-2011-1024x268.png)

**Figure 2.** Table 3 from [Pfister et al., 2011](https://link.springer.com/article/10.1007/s00125-011-2162-0)

- Notice that the investigators don’t even put a P-value up on the unadjusted rate because you don’t even need statistics to see how significant it is, but it’s irrelevant

*When we adjust them, what do we find?*

- 6 groups
- If you look at the adjusted HR for 5.0 to 5.5 group, that’s going to be 1.0 because that’s the reference group
- Then they look at if the number gets larger, then that’s an associated increase in risk and if the number gets smaller it’s a decrease in risk

If we look to the left of the reference group, you’ve got the two groups:

- The less than 4.5
- And 4.5 to 5.0
- and the adjusted rates are pretty close to 1.0
- Less than 4.5 is 94, but it’s not statistically significant

The ones that we’re looking at to the right hand side were all *statistically significant* when we start going up in HbA1c values

- The really quick and easy way you can always tell that: Anytime a confidence interval crosses the reference value of 1.0, it is NOT statistically significant

*Going back to the examples on the left, how do you know that .94, i.e. a 6% reduction in risk, is not statistically significant?*

- You know it because the 95% confidence interval range is 0.72 to 1.22 — so it crosses 1.0 — That’s telling you that our 95% confidence interval is somewhere between a 28% reduction in risk and a 22% increase in risk
- Similarly, .86 to 1.13 crosses 1.0 — We don’t think it’s statistically significant, it’s no different from the reference range
- However, when you go to the right, you see that they are NOT crossing 1.0
- And our 95% confidence interval then puts us between 2% and 19%, 14% and 46%, 16% and 80%
- So we would say **there is an associated relative risk increase of 10%, 29%, and 45%**
- “*I don’t think it’s any surprise that a person with type 2 diabetes has a 45% increase in all cause mortality*.”
- **The main point:** In the nondiabetic populations, including all the way down to 5.5 to 6.0, you still have an increase in the risk of mortality

*-Disease specific data*

- They also did this for disease specific
- cardiovascular death and cancer related death
- Looking at cardiovascular death… if we just look at the crude rates, again, you see this continuous increase in the rate of death in each group going from less than 5.0 all the way up to greater than or equal to 6.5
- When they looked at the adjusted hazard ratios compared to the reference group, there was a 21% increase, a 39% increase, and a 61% associated increase in the risk of cardiovascular death as you went from the 5.5 to less than 6.0 group, and then the 6.0 to 6.5 group, and then over 6.5 group.

***-Was this an underpowered study?***

Peter says:

- “*What I found interesting in this study is when they looked at cancer, they just barely did not get significance on the multivaried analysis and they did get it on the age and sex adjusted…*
- *I think it truthfully speaks to this being underpowered because they only had 348 subjects there and they weren’t really trying to capture diabetics*”

Bob adds:

- *“One of the other things too…with some of the observational studies where they adjust for all these different factors…*

- *…when you’re looking at something like, let’s say, glucose and you think that it’s causing things, like it’s in the causal pathway.*

- For instance*, “if you have somebody with, say diabetes, typically, I think it’s more common than not, they have a number of comorbidities. If dysregulated glucose or glucose homeostasis is actually causing some of these other problems, like higher blood pressure for example.*
- *So, if you start taking those out, you start correcting for those things, you might actually be diluting an actual effect if it actually is there. Like if you did a randomized control trial or something to that effect over the course of 11 years, they might also have hypertension along with their blood glucose*.”

**The take home message**:

- The most important point here is that this type of statistical analysis is “bending over backwards to dilute the impact of glucose”
- In other words, what it is showing you is only the mortality effect of the glucose and not the mortality effect of everything that comes with it
- Someone with an average blood glucose of 130 is certainly also going to have fatty liver, elevated triglycerides, early atherosclerosis (if not advanced), etc.
- When an analysis like this is done, which I think it had to be done just to be statistically rigorous, it creates an **artificially low true hazard ratio**
- if you’re thinking about this from a public health perspective, you actually want to look at the unadjusted numbers

> “The unadjusted numbers tell the real world story, which is once your blood sugar goes up, and this happens monotonically from a very low level, your rate of mortality skyrockets. That’s the take home message here.” —Peter Attia

[**Japanese study from 2013**](https://care.diabetesjournals.org/content/36/11/3759) [27:45]

*Overview*

- This is a prospective study in more than 7,000 people in the general population in Japan (i.e., they didn’t pick out necessarily nondiabetics in this case)
- Mean age was 52
- Did a 15-year follow-up on crude and adjusted mortality from all-causes and cardiovascular disease

![](https://peterattiamd.com/wp-content/uploads/2021/06/F3.-ama24-Table-2-from-Sakurai-et-al.-2013-1024x302.png)

**Figure 3.** Table 2 from [Sakurai et al., 2013](https://care.diabetesjournals.org/content/36/11/3759)

- You see similar divisions
- They do include people who are technically defined as having type 2 diabetes (those with a hemoglobin A1c about 6.5%) and they’re generally underrepresented so 1,700 of those people
- It notes that 2,300 people were actually being treated for diabetes so that implies that a number of people who were close to that level were also being treated as though they had diabetes
- 2,300 in the 6.0 to 6.4
- 13,000 in the 5.5 to 5.9
- 49,000, the lion’s share of people, were in the 5.0 to 5.4
- 30,000 beneath 5.0 (Probably says the Japanese population is healthier than the US population)

***What did we learn?***

- This corroborates the [previous study](https://link.springer.com/article/10.1007/s00125-011-2162-0) mentioned above
- The reference range in this case was less than 5% HbA1c, whereas the other one looked at 5.0 to 5.5 as the reference range
- Similarly, if you look at the mortality rates, you see this continuous increase as you move up the line with the HbA1c
- The same thing with cardiovascular disease mortality, although the associated increases in risk are a little bit larger, particularly for the 6. to 6.4% groups

*Peter was surprised at something*:

- The unadjusted rates of death are higher in the Japanese study compared to the UK study
- This could be explained by the fact that the study went longer (15 years vs. 11 years)
- However, the fact that the mean age in the Japanese population was 52 (compared to 47 in the UK study) should have captured that difference
- Peter expands on his confusion: “*When I looked at this paper, I was surprised…Not surprised by the monotonicity of the rise and the magnitude in terms of one group to another. But surprised that the group that was below 5.0 was at 6.4. One message here is it’s very difficult to compare cohorts, even in randomized control trials*.”

**Final takeaways from these studies looking at average blood glucose**:

- Even when you adjust for confounding variables, you really start to see a rise in mortality with rising blood glucose
- That said, the adjustment is artificially diluting the true impact, significantly
- Peter likes how the studies calculate what each percent increase in hemoglobin A1c means to your mortality—for all cause mortality, each increase in hemoglobin A1c accounts for
  - a 20% increase in adjusted mortality
  - and a 32% increase in cardiovascular mortality
- “*This makes a very compelling case that* ***you want to have the lowest average blood glucose possible***.”
- NOTE: What’s excluded here  is people with type 1 diabetes where too low glucose is a risk because you risk hypoglycemic events
- But if a nondiabetic person we’re choosing between two different dietary/exercise/sleep patterns that gives them a lower blood glucose and one that gives them a high blood glucose, they are better off in that lower range
- Peter notes that this is precisely how he manages his patients—by getting them to the lowest blood glucose that they can maintain

##

## Deep dive into glucose variability and why less variability is better [33:15]

**Glucose variability**

- Glucose variability means how much it is rising, falling, et cetera
- Hard to measure: Absent a continuous glucose monitor or doing inpatient studies where people are using the euglycemic clamps or insulin suppression tests, it’s very hard to measure this

*What did Bob and Peter find in the literature?*

- They looked at fasting insulin almost as a proxy for altered glucose metabolism was one way
- They looked at some of the studies on not only fasting insulin but the HOMA-IR
- One of the ways that they would look at glucose variability where they looked at what’s called visit-to-visit variability
  - They take your fasting glucose when you’d go into the clinic to get your baseline
  - then after a couple of years they would take your fasting glucose
  - Then after four years from baseline, they looked at glucose and they looked at the glucose variability in that way (obviously not as accurate as CGM where you can see glucose variability in real time)

**HOMA-IR**

- HOMA-IR is a very simple formula—fasting glucose multiplied by fasting insulin divided by 405
- For instance: if your fasting glucose is 100 and your fasting insulin is 8, your HOMA-IR would be about 2.0
- So, 100 x 8 = 800, then divided by 400 is 2.0
- Most labs consider a HOMA-IR below 2.0 to be normal, but Peter wants to see below 1.0
- So “normal”, would be something like… fasting glucose of 100 with a fasting insulin below 4 so that 4 x 100 = 400, then divided by 4 equals 1.0

[**2019 study**](https://care.diabetesjournals.org/content/42/3/486)

- Divided people into quartiles
- The cohorts were based on the lowest 25th percentile, the next 25th percentile, the next, and the next, et cetera
- They made the lowest quartile the reference range

![](https://peterattiamd.com/wp-content/uploads/2021/06/F4.-ama24-1024x193.png)

**Figure 4.** Data from a 2019 prospective study in more than 4,000 nondiabetic participants (mean age ~65) in the U.S. (ALLHAT cohort) with a 5-year follow-up: visit-to-visit variability (VVV) in FPG and all-cause mortality. Unit of each quartile of the measure of variability is mg/dL. Model 4: includes adjustment for age, race/ethnicity, sex, education, smoking status, BMI, use of aspirin, average cholesterol, eGFR, history of CVD, use of antihypertensive medications, average SBP, average FBG. *Source:* [*Echouffo-Tcheugui et al., 2019*](https://care.diabetesjournals.org/content/42/3/486)

- Looking at the above table…
- Four different models which is just different ways that they were trying to adjust for confounding variables
- We’re just going to look at the model four which adjusted for the most things that they could
- The first quartile was the reference
- The second quartile, it looks like it goes up a little bit, but again, if you look at the confidence intervals, there’s a pretty big range there where it’s between 0.61, which would actually look like a reduction in risk in all cause mortality, and then all the way up to 1.9, which is a big swing. So could just be noise
- Third quartile: But then when they went to the third quartile they saw a pretty big uptick where it was associated with more than a twofold increase in risk. 2.06 is the number there for the third quartile and for the hazard ratio
- For the fourth quartile, it went up even more, which was 2.67

*-Peter’s commentary*:

- In all of their models basically the same thing was found, which was the second quartile didn’t have a statistically significant increase in mortality risk but the third and fourth quartiles did right across the board
- And it’s not trivial, it’s a **doubling of risk**
- There are several challenges:
  - There’s one issue that is solved for here, which is by definition each of these groups has the same number of people in it. You’ve uniformly divided the number of people across it, which we did not have in the previous cohort analysis
  - Of course, the drawback is this isn’t the best proxy for variability
  - This is also showing us something, which is those that have greater variability are also the people who are getting sicker
  - They’re the people whose glucose is getting worse and worse controlled as time goes on

*-What conclusions can be drawn from this 2019 study?*

- Changes in glucose
- they show an increase from visit to visit over this time
- But if your glucose homeostasis is out of whack where you’re not consistently … The first quartile is probably the closest thing to having a steady glucose, which I think also the first quartile is the lowest blood glucose in general.
- Any swing is probably going to be a problem. The bigger the swing, the bigger the problem

[**Study in 2018 using OGTT**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6057684/):

- 60 participants, nondiabetic
- Used an oral glucose tolerance test
- Peter believe that that’s a much better study than the [2019 study](https://care.diabetesjournals.org/content/42/3/486)
- The [2018 study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6057684/), you’re actually taking a group of people, you’re giving them an oral glucose tolerance test and you’re measuring how much glucose variability you saw with that test

–*How Peter does OGTTs in his practice*:

- If you were going to do an OGTT, to me the best way to do it is to have a continuous glucose monitor on and every minutes you’re getting the glucose level and you can follow it until it normalizes again
- In practice when we do this, because we’re also sampling for insulin, we do with actual blood draws every 30 minutes and we carry that out four times
- we do a fasting level, they drink the 75 grams of Glucola, then at 30, 60, and 90 minutes we again measure
- Truth be told, I would like to go to 120 minutes and even 150 minutes out to two or two and a half hours, but at some point the patient starts to feel like a pin cushion and they want to get back to work and not just sit there and be poked all day
- For most people we can get the answer, the clinical diagnosis, based on those looking 90 minutes out
- What you typically see is the peak glucose occurs at about 30 minutes and the nadir usually occurs at about 90 minutes, but not always… sometimes people really bottom out big time at 60 minutes and then start to rebound

*-In this* [*2018 study*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6057684/)*, what did they find?*

- All of the participants were seemingly normal in terms of their glucose tolerance, as define by HbA1c
- In this case they basically just looked at their CGMs over the course of time and they actually found that “severe glucose variability” was present in 25% of normal glycemic individuals
- They also noted that glucose levels reaching pre diabetic ranges happened 15% of the time
- They said it suggests that **glucose dysregulation is a lot more prevalent than we probably think it is if we’re just looking at fasting glucose and HbA1c**
- Peter’s reaction:
  - Not that surprising when you go back to the discussion with [Gerry Shulman on The Drive](https://peterattiamd.com/geraldshulman/)
  - Shulman’s studies were focusing on insulin resistance where he’s taking a bunch of healthy, nonsmoking, admittedly generally inactive undergraduate students at Yale and doing OGTTs in them and he’s noticing the amount of hyperinsulinemia he’s seeing even in normoglycemic responses

> “Hyperinsulinemia on an [oral glucose tolerance test], even in the presence of normoglycemia, is the canary in the coal mine.” —Peter Attia

- An OGTT is an important test and even CGM can be fooled
- Because before your CGM starts to go batty, you’re going to see dysregulated insulin response on the OGTT
- So until we have a continuous way to sample insulin, there’s always going to be a role for an OGTT in the clinical diagnosis here

##

## Example of how HbA1c and traditional measures could catch metabolic issues too late [41:45]

- Say you’ve got your HbA1c for glucose, now imagine you have some similar value for insulin, say over the course of three months
- You look at an individual and let’s say that every year they get a checkup and typically they look at the HbA1c and say it’s 5.1, 5.1, 5.1, 5.1 over the course of baseline in three years
- Then pretend you have a magical piece of equipment that could look at insulin
- You see that okay, baseline insulin is this, and then you see it’s climbing each year.
- That would be a canary in the coal mine where you’re looking at it and saying, “Okay, your glucose looks like it’s regulated” but you’re using a lot more insulin now in order to do that, which is probably stressing the system
- In other words, it’s basically telling you that at some point you’re not going to be able to crank out enough insulin to regulate the system and you’re going to start to see glucose going up
- What is problematic, says Peter, is generally these patients don’t come to medical attention until they’re so far gone that their average blood glucose has gotten so high that it’s now being flagged on an HbA1c, which can be way too late
- Frankly, their fasting glucose might take a long time before it’s in the 110 to 120 range at which point most doctors would start to pay attention

##

## Postprandial dips in blood glucose as a predictor of subsequent hunger and energy intake [43:00]

[**Recent paper in 2021**](https://www.nature.com/articles/s42255-021-00383-x)

- A recent publication looked at CGM and studied the extent to which the postprandial glucose dip was predictive of appetite
- Just looking at glucose variability, it could just be that over time you’re looking at people’s glucose levels rise
- There are studies in type 1 diabetics where they look at periods of hypoglycemia
- But a lot of the studies looking at “normal” people, they’re often not looking for hypoglycemia necessarily, they’re often looking for rises in blood glucose
- In [this case](https://www.nature.com/articles/s42255-021-00383-x), this is actually looking at postprandial **glucose dips**, i.e., looking at what happens to your glucose after a meal

*-Interesting findings:*

- They used CGM and looked at more than 1,000 participants
- Looking between two to three hours after a meal, they found that the actual ***dips*** **in your blood glucose were a better predictor of subsequent hunger and energy intake than peak glucose and glucose area under the curve**
- After that two to three hour period, they would look at how quickly they would have their next meal and they saw that the glucose dip actually predicted the subsequent amount of food that they ate after that period than the participant’s self reported hunger level
- Peter says that this “makes so much physiologic sense”
- The person who’s going to have the greatest dip probably has a few things going on:
- They probably had the greatest peak, which led to the greatest amount of insulin production, which then led to the great dip.
- That speaks to the underlying challenge that person has with fuel partitioning, which speaks to the underlying metabolic dysregulation

*-Response to a high carb “normal” meal*

- Average glycemic responses to standardized breakfasts
- The OGTT is the standard one so they had 75 grams of carbohydrates, all of it in the form of sugar.
- But when you look at the high carb meal, it’s not that much higher in carbohydrates at about 96 grams of carbohydrates, of which 55 is sugar
- “What blows my mind”, says Peter, “is how high these glucose levels are getting”
- So on the Y axis you’re seeing plasma glucose in millimole (millimole is about an 18th or 19th of a milligram per deciliter)
- So just to be directional, multiply the number on the Y axis by 20 and you’re getting about the glucose level in milligrams per deciliter
- That means they’re all starting out just below 100 (averaging probably 90 to 95 milligrams per glucose at start)
- But they’re peaking sort of between 30 and 60 minutes at nearly nine millimole—that’s about 175 milligrams per deciliter
- And these aren’t people that were force fed 500 grams of glucose… this is a *normal* breakfast
- That would be considered an unacceptable peak by any stretch of the imagination in my book.
- We never want to see you above 140
- Peter says: “*On my CGM, I have an alarm set at 130. So anytime I go above 130 it lets me know. And I don’t like to ever go above 130. Obviously I do from time to time, but that’s the standard I’m holding to.*”

\*\*\*

Peter tells a quick story about the highest blood glucose he has ever had, personally

- from a meal, I think the highest I’ve ever seen … I’ve seen 170
- It was at a very famous vegan restaurant in New York City. I think it’s called Candle 69 or Table 79 or something like that. It’s on 79th
- we had this awesome meal
- it was basically a pure carbohydrate meal
- something about the way they had to process everything to make it just really boosted the glycemic index
- the entrée we had was vegan veil
- you could not distinguish from real veil.
- it was apparently just made of wheat
- we had as a appetizer coupled with that, coupled with the dessert, which was probably just pure sugar
- I remember my CGM buzzing
- it was like 174 or something
- And I couldn’t believe it. I was like, I didn’t know that was physiologically possible for me. But apparently it was.

\*\*\*

- The point: The meals from this study is very breakfast stuff
- Oatmeal, scrambled eggs, that kind of stuff
- “kind of surprised to see this” says Peter
- Average glucose dip just below 4 (That’s 70 to 75, which is not out of this world)

**Peter concludes**: “*Nevertheless, I found this to be a very interesting study and I think there is a growing body of literature that suggests this vicious cycle of high peak, high insulin, big dip, more appetite*.”

##

## Exploring the idea that the suppression of fatty acids is actually causing hunger rather than a low blood glucose [49:45]

**What happens with free fatty acids**

- In the early 1950s, Jean Mayer [published work relevant to this topic](https://www.nejm.org/doi/full/10.1056/NEJM195307022490104)
  - He had a glucose stat hypothesis about periods of low glucose or hypoglycemia is going to induce hunger
  - They wonder whether it’s the low glucose per se, or if the low glucose might be a proxy for suppression of free fatty acids or lipolysis, which can also be a fuel that you can utilize
  - In Peter’s recollection of Mayer’s work, it was that glucose level did not by itself appear to be a predictor of appetite

In the [2021 paper](https://www.nature.com/articles/s42255-021-00383-x)…

- They were also just looking at fasting glucose
- One of the issues too is whether higher glucose itself necessarily suppresses appetite, “*and I don’t think that that’s the case*” says Bob
- They have the responses to the standardized meals and one of those is an OGTT

![](https://peterattiamd.com/wp-content/uploads/2021/06/F5.-ama24-1024x336.png)

**Figure 5.** [[Wyatt et al., 2021](https://www.nature.com/articles/s42255-021-00383-x)]

![](https://peterattiamd.com/wp-content/uploads/2021/06/F6.-ama24-1024x566.png)

**Figure 6.** [[Wyatt et al., 2021](https://www.nature.com/articles/s42255-021-00383-x)]

![](https://peterattiamd.com/wp-content/uploads/2021/06/F7.-ama24-1024x529.png)

**Figure 7.** [[Wyatt et al., 2021](https://www.nature.com/articles/s42255-021-00383-x)]

- They look at the change in hunger and in that case (the OGTT) it’s the biggest increase in hunger as well as the biggest glucose dip
- You can look at that and say “okay, you’ve got a correlation between the glucose dip and the change in hunger”, however, from Bob’s fat-centric viewpoint, he also thinks about the fact that with OGTT you’re taking straight glucose, you’re taking straight carbohydrates, so you’re not getting any fat from the meal
- So in that particular case, if you’re suppressing free fatty acids, your glucose levels are dropping, and you haven’t taken in any endogenous fat, which could also be utilized in this situation post meal
- Bob would says that is a confounder —
  - He would just think directionally that if your glucose is dropping the most on an OGTT, AND if the free fatty acids are also suppressed the most…
  - …it might be that the hyperinsulinemia itself is what’s actually creating the hunger —  so it could be the **higher the insulin the more responsive you are to it in terms of suppressing lipolysis in the adipocytes**

[Clamp study from 1985](https://pubmed.ncbi.nlm.nih.gov/3897769/)

- They did a hyperinsulinemic-hyperglycemic, hyperinsulinemic-hypoglycemic, and euinsulinemic-hyperglycemic clamps and then asked them how hungry they were

![](https://peterattiamd.com/wp-content/uploads/2021/06/F8.-ama-24-table-1-clamp-study-1024x582.png)

**Figure 8.** [[source](https://pubmed.ncbi.nlm.nih.gov/3897769/)]

- After the clamps, they allowed subjects to drink a liquid meal at the end of the study from a container that was hidden from view so they wouldn’t know how much they drank

![](https://peterattiamd.com/wp-content/uploads/2021/06/F9-ama24-table-3-clamp-study-1024x372.png)

**Figure 9.** [[source](https://pubmed.ncbi.nlm.nih.gov/3897769/)]

*Results*:

- With the hyperinsulinemic, both the high glucose and the low glucose, there were increases in hunger
- If it was euinsulinemic and hypoglycemic, there was no increase in hunger even though they had low glucose levels
- They’re actually pegging the glucose levels to be low, at least relative to the reported hunger levels
- There was no difference in intake between the hyperglycemic and hypoglycemic groups, suggesting that hypoglycemia was not driving hunger

To explain what those studies are…

- Those are studies where you’ve basically got an IV in each arm
- One arm is running glucose into you, the other arm is running insulin into you
- When we talk about clamping, you can clamp either variable and then use the other one to titrate
- In a hypoglycemic clamp you’re fixing the glucose at a low level, say 60 milligrams per deciliter, roughly three millimole
- And you can let the insulin level go up or down, and/or you can change the insulin level up or down while holding the glucose there

> “*To me, that’s quite* ***definitive evidence to suggest that it’s less about the glucose level and more about what it takes to get there***.” —Peter Attia

**Effective concentration of insulin to inhibit lipolysis [53:29]**

![](https://peterattiamd.com/wp-content/uploads/2021/06/F10.-ama24-1024x969.png)

**Figure 10.** The effective concentration of insulin to inhibit lipolysis, to drive glucose uptake in the muscle, and then to inhibit gluconeogenesis. Numbers in rectangular boxes indicate mean insulin concentration for 50% effect (EC50) on the stimulation of peripheral glucose uptake, as determined in different studies of non-obese adults. [[source](https://bmcmedicine.biomedcentral.com/articles/10.1186/s12916-018-1225-1)]

- This shows the effective concentration of insulin to inhibit lipolysis, to drive glucose uptake in the muscle, and then to inhibit gluconeogenesis
- For fasting insulin level — the median level is 46 and they’re showing you the 75th percentile within the box there
- Note: these are done in picomole per liter which is typically higher than micro units per ML (which is what Peter prefers to use) — So pay less attention to the numbers and more to the scale on the Y axis
- *What’s the effective concentration of 50?* — The effective concentration is concentration for 50% effect, in this case on the inhibition of lipolysis
- Peter says this is “just amazing” — you do not need to see a big increase in insulin to start to completely inhibit lipolysis, which is the process by which the fat cells stop liberating fat (i.e., they stop letting triglycerides in the form of free fatty acids out of the fat cell)
- That’s really not much of an increase needed — It’s a 50% increase above baseline
  - For instance, if the average person walks around with an insulin level of 10, just getting it to 15 shuts off lipolysis

*Bringing this back to a very important clinical situation…*

- Let’s says a person comes to you and says, “I really want to lose weight”
- What does Peter say? “Nope. You want to lose **fat**.”
- “Oh okay. What does that mean?”
- Well, unless you’re going to get liposuction it means that **each of your fat cells needs to get smaller**
- If each of your fat cells needs to get smaller, they need to undergo **net lipolysis**—They need to expend more fat than they are taking in
- It’s very difficult to expend more fat than you are taking in when you have inhibition of lipolysis

> “So when I see a patient with a fasting insulin level of 15, the first, second, and third strategy is we have to lower your fasting insulin.” —Peter Attia

- If you’re sleeping with an insulin level of 15 (nevermind after a meal), you’re going to have a really difficult time getting fat out of your fat cells
- What’s interesting too is if you look at the contrast with that lipolysis inhibition to glucose uptake
- So if you’re looking at the amount or half the maximal stimulation, the 50% of glucose uptake
- it requires basically an insulin concentration that’s, I think they said in the paper eyeballing too, that was about six times higher compared to that required for the 50% inhibition of lipolysis to suppress the glucose uptake
- And even just going to turn off gluconeogenesis, the process of making more glucose. It’s not surprising to me that that’s lower than glucose uptake but it is kind of surprising and amazing that it’s still higher than the inhibition of lipolysis
- “*This is a very elegant analysis that really speaks to why we want to keep insulin levels low*.” says Peter. “*It speaks to basically the macro thesis here which is glucose variability drives insulin levels. We want to keep insulin levels low for all the reasons stated above.*”

##

## Deep dive into peak glucose and why lower peaks is better [57:15]

**The goal with peak glucose:** Lower peaks and fewer peak glucose levels

- Peter looks at two things:
  - 1) Peak: What are the peaks?
  - 2) Frequency: How many times per week are you hitting the peak?
- In practice:
  - Over the course of the week, Peter will look at how many times you hit a peak glucose
  - He also pays attention to what the peak number actually is
  - For instance, let’s say the first threshold of 140 and the patient averaged 10 times a week of going over 140
  - Peter’s first goal would be — *Can we reduce that to less than 10? Can we get you down to three times over 140 per week?*
  - Once the patient gets to the point where they’re not really going over 140 often, Peter will lower the threshold to 130
  - “*We’re basically lowering the ceiling and reducing the frequency*.”

**Many ways to measure this**

1. Can measure this with an OGTT
2. Clinically we do it with CGM
3. Experimentally, infusion tests in which you can clamp glucose… in this case we’d be clamping glucose or clamping insulin
4. Meal tests which are similar to an OGTT but more real because you’re using actually food as opposed to just sugar water

*Using real world meals…*

- We do bagel tests, rice tests, things like that
- the OGTT is a bit of a false test. Most people don’t drink 75 grams of Glucola
- did an OGTT on myself a couple of months ago. I hadn’t done one in years and I just wanted to do it with the standard substrate, the Glucola
- This isn’t giving me great insight because I’ll never drink this
- was interested in the insulin levels because obviously I get the glucose levels every time I ea
- what I was really doing was trying to understand my insulin levels in response to the test.
- how this impacts them in the real world so we’ll say, “Look, what is your favorite high carb meal?
- I don’t care if its got 100 grams of glucose in it. But if that’s the meal you’re going to be eating often, let’s actually measure your insulin and glucose response to that meal.” So yeah, we do this all the time.

**What’s wrong with peak glucose levels? Why would that be problematic?**

- Bob looked at the literature and was actually kind of surprised by some of the results that he saw there just acutely
- Let’s say, for instance, that you did one bad meal a day and you just had a spike and then it goes away, but overall maybe your average glucose looks fine — so why WOULD that be a problem?
- Some of the studies would look at the endothelial function during periods of hyperglycemia
- There are actually a bunch of replicated experiments like this that they would look at oral glucose tolerance tests

-In one case they actually did a glucose infusion

- They looked at healthy nondiabetic individuals in these studies, and they basically found endothelial dysfunction
- it’s flow mediated dilation is how they assess it, but they found it again and again
- if that’s the case that those glucose peaks could have accelerated the development of atherosclerosis, even in those with normal glucose tolerance in those people
- This population that with something that maybe we’re not seeing or we’re missing in general “healthy” nondiabetics

One step further…

- To Bob’s point, this is something that’s not necessarily captured in the first two pillars of what we’re talking about (average glucose and the glucose variability)
- Especially the first one, the average glucose
- To your point, if you’re eating one crappy meal per day, for instance, and you’re a relatively healthy person, you’re going to spend most of the day with a pretty low glucose
- But if that one meal per day is overboard and you have an enormous spike, you are transiently inducing endothelial dysfunction
- And that’s correlating with things that go far beyond just the flow mediated dilation — That’s associated with higher carotid intimal thickening which of course is a harbinger of cerebral vascular disease
- It’s very difficult to imagine that that same effect is not also causing coronary atherosclerosis along with carotid atherosclerosis
- There are also some prospective studies too where they would look at elevated postprandial glucose and they would try to actually control for fasting glucose
- Bob found some independent associations too with the stuff that we looked at before like all cause mortality, cardiovascular disease mortality, cancer mortality, frailty

[**2009 study out of Taiwan**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2732157/)

- more than 15,000 nondiabetics in Taiwan
- mean age of 53
- looked at two hour postprandial glucose

![](https://peterattiamd.com/wp-content/uploads/2021/06/F11.-ama24-Lin-et-al.-2009-1024x261.png)

**Figure 11.** [[Lin et al., 2009](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2732157/)]

- For cardiovascular and all cause death, what they found was similar to that other study with the HbA1c,
- They also looked at a continuous increase
- In this case the two hour glucose they’re looking at 1.0 millimole (~18 milligrams per deciliters)
- Highlighted in pink the table, the model that they adjusted for the most confounding variables
- Per 1.0 millimole increase, an associated 26% increase in cardiovascular death and a 10% increase in all cause death
- We’re also looking at different quintiles of the two hour postprandial glucose — And so when they compared the fifth quintile (the highest glucose levels compared to the reference), they saw an associated 98% increase in cardiovascular death risk and a 58% increase in all cause mortality.
- Peter says it’s interesting how it only shows up at that fifth quintile,
- “I would have expected more gradation the way we saw it with average glucose. . .almost suggests it becomes kind of binary.”
- Peter says it begs the question,
- “*what’s that threshold? What is that cutoff*?”
- “*The people who were in that fifth quintile, what was that number that flipped for them?*”
- The table below gives insights into Peter’s questions:

![](https://peterattiamd.com/wp-content/uploads/2021/06/F12.-ama24--1024x573.png)

**Figure 12.**

*Tough to adjust for everything*:

- It’s tough to adjust for some of the things that they adjust for (i.e., you can’t adjust for a whole person, you’re kind of looking at these almost like a sliver of a person)
- If you think about metabolic syndrome, you’ve got five factors that I think you look at. You look waist circumference and then you look at low H where you look at your HDL cholesterol, your triglycerides, your blood pressure and your book glucose
- So when you try to control for some of these things, a lot of these things come in packages and they’re looking at a lot of the factors for metabolic syndrome
- When you control for somebody who has elevated glucose or they have glucose dysregulation after a two hour meal, it’s very difficult to get a complete picture of what’s going on in the individual because that person will often have i) lower HDL cholesterol, ii) higher triglycerides, iii) higher blood pressure, and iv) higher waist circumference
- It’s close to like 90% of adults have at least one of those things

*The other thing in this study worth noting…*

- Possible they also missed a lot of people
- If they only looked at the two hour postprandial glucose, there are lots of people who are back to normal at two hours that didn’t have a peak at 30, 60, 90 along the way
- “T*o me, if they didn’t sample in that group and they were only there for catching people who were still elevated at the two hour mark, then yeah, you’re really catching the sickest of the sick or the most dysregulated, but you might be missing others and that might be why there’s such a step function between the fourth and fifth quintiles.”*

##

## What the best rodent models tell us about the impact of peak glucose levels [1:06:25]

***Acarbose and Canagliflozin***

- These two molecules have been studied by the [Interventions Testing Program (ITP)](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp)
  - \*See [podcast with Rich Miller](https://peterattiamd.com/richardmiller/)
- The ITPs, which are incredibly rigorous studies, there are a handful of molecules that have been shown to meaningfully extend life in that rodent model system
- Those two molecules are acarbose and canagliflozin

**Acarbose**

- Acarbose is a drug that is often used in people with type 2 diabetes and it reduces the rate of digestion of carbs (it limits postprandial hyperglycemia)
- So glucose peaks are basically blunted because acarbose inhibits an enzyme that breaks down starch in the intestine
- The ITP chose that because they felt that it would be a CR mimetic (i.e., it would mimic caloric restriction, thesis put forth by [David Allison](https://en.wikipedia.org/wiki/David_B._Allison))

[**2014 acarose study by the ITP**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3954939/)

- Started treating mice at **4 months of age** and treated them until death
- Extended the median survival of the males and females 22% and 5% respectively
- It extended peak lifespan by 11% and 9% respectively.

-The question is: *Was it due to the caloric restriction effect? Was all of this benefit due to an improvement in the ones who lived longer lost more weight?*

- One of the interesting findings in the study is that when they looked at the body weight and the body weight reductions in acarbose, they’re actually greater in the female mice
- the median lifespan extension was 5% compared to 22% in males, yet you’ve got greater weight loss in the females than the males and the males extend their lifespan nearly three and half fold more than the females
- So you can probably take the body weight reduction in this case out of the picture as far as whether that caused the extension in lifespan

-The next question would be…*Maybe the acarbose mice live longer because they had lower average blood glucose. And how did that analysis shake out?*

- in this case surprisingly it was the fasting glucose levels were higher in the acarbose mice versus the control mice
- Their HbA1c levels were unaltered
- They had higher fasting glucose, no difference in HbA1c, but basically the researcher said that it was consistent with the concept that it might just be the glucose peaks rather than average glucose
- So the **glucose peaks alone could be the factor here**
- Peter thinks they didn’t see a difference in A1c and they saw a higher fasting glucose because fasting glucose is measured after a long period of not eating and he animals that were taking acarbose would have a slower release of glucose in their GI tract
- Peter says it’s not surprising that they would have more blood glucose in their circulation in the morning, i.e., meaning just when they’re fasted then the non treated animals
- “*It speaks to the point that the last variable here that’s not explained is the peaks*.”

[**2016 follow up publication on acarbose by the ITP**](https://pubmed.ncbi.nlm.nih.gov/27312235/)

- Gave mice the same dose as the first study, but they gave it to them at **16 month of age** in this case
- In this case if we look at the median survival, it extended the median survival in the male mice but not the female mice by 7%.
- When they looked at the 90th percentile survival (“maximum longevity”) where you’re looking at the 90th percentile, both male and female mice saw extension — male and female by 12 and six respectively
- The results suggest that you can give this later in life and still see some effect, although it doesn’t seem like the effect is as great if you’re giving it earlier in life
- The same thing was shown here — which is the *effect did not seem to dependent on weight or average blood glucose*

**In 2019,** [**mice were again treated with acarbose**](https://pubmed.ncbi.nlm.nih.gov/30688027/)

- This time at different doses:
  - Lowest dose at 400.
  - The same one as previous studies at 1,000
  - A higher dose at 2,500 parts per million
- Started treating at **8 months of age** (human equivalent 20s or 30s)
- The males did better — 11%, 17%, and 16%
- It really didn’t matter when you went to the higher dose, the 1,000 parts per million was the sweet spot
- For females, the results were — less than 1% (basically no effect), 5% and 4%
- The point here is less that it works, it’s more about the **why**
- The females continue to have a greater reduction in body weight (they’re getting more of the CR benefit but not the longevity benefit) — This suggests something else is going on here
- **The take home point:** The peaks in glucose matters independent of average glucose, independent of weight or caloric intake, and the earlier you start in life, the better

> “So don’t wait until you’re 60 to start caring about this. You can care about this in your 20s.” —Peter Attia

**Canagliflozin**

[Study by the ITP on canagliflozin](https://insight.jci.org/articles/view/140019)

- Based on the success on acarbose the next candidate that was tried in the ITP of the same idea of glucose lowering was canagliflozin
- Canagliflozin is an SGLT2 inhibitor (inhibits glucose reuptake in the kidneys) and the net effect of this is similar to acarbose in that you lower glucose
- It’s a drug that is also used in people with type 2 diabetes
- It has a different mechanism of action — Acarbose works in the gut, canagliflozin works in the kidneys so you end up peeing out more of your glucose

–*What did this study show?*

- They gave it to mice at 7 months of age
- It extended median and 90th percentile survival of the male mice by 14% and 9% respectively
- But it did not extend lifespan in female mice
- It showed a lower fasting glucose and improved glucose tolerance in both sexes but only the longevity benefit in the male mice
- This is again suggesting that it was not the reduction of fasting glucose or even the improved glucose tolerance which might speak to the ability to minimize variability,  but *something else is going on here*
- Again, body weight was reduced more in the females than the males suggesting it is not that this was a CR mimetic by mechanism where the female mice peed out more glucose and therefore had fewer calories

> “I find these two studies, even though not in humans, to be very compelling in terms of suggesting that the fewer peaks you have, the longer life you live.” —Peter Attia

##

## Why Peter encourages all his patients to wear a CGM [1:14:30]

- There’s a reason why Peter encourages all of his patients to wear a CGM
- It’s not just a tool for people with diabetes, it’s a tool for anybody who’s interested in improving their health because it gives you the best real world insight into these three metrics:
  - What’s your average blood glucose?
  - How much does it vary?
  - How high are the peaks and how often do you have them?

§