# #151 – Alex Hutchinson, Ph.D.: Translating the science of endurance and extreme human performance

**Source:** [https://peterattiamd.com/alexhutchinson/](https://peterattiamd.com/alexhutchinson/)

---

Alex Hutchinson is a sports science journalist, author of the book Endure—which explores the science of endurance and the real limits of human performance—and former competitive runner for the Canadian national team. In this episode, Alex tells the story of his “aha moment” during a meaningless track meet that catapulted his running career and seeded his interest in the power of the mind. He then explains the science behind VO2 max, the difference between maximum aerobic capacity and efficiency, and extracts insights from examples of extreme human performance, such as the recent attempts to break the 2-hour mark in the marathon. Finally, he brings it back to what this all means for the everyday person: optimal exercise volume for maintaining health, how to avoid acute and chronic injuries, how to diversify your exercise portfolio, HIIT protocols, and much more.

\*[WATCH PODCAST ON YOUTUBE](https://www.youtube.com/watch?v=LRlpoMjaHK0)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/alexhutchinson/the_Drive_public.png)

Play

#151 - Alex Hutchinson, Ph.D.: Translating the science of endurance and extreme human performance

#151 - Alex Hutchinson, Ph.D.: Translating the science of endurance and extreme human performance

1x15s30s

0:002:13:44

## We discuss:

- Alex’s background and passion for running (3:00);
- The power of the mind: Alex’s “aha moment” that catapulted his running career (9:00);
- Pursuing a Ph.D. in physics while prioritizing his running career, and doing the hardest thing possible (19:00);
- Career transition to journalism, tips for improving your writing, and insights from the best writers (26:00);
- Breaking down VO2 max: Definition, history, why it plateaus, and whether it really matters (38:15);
- The case study of Oskar Svensson: Why a higher VO2 Max isn’t always better, and the difference between maximum aerobic capacity and efficiency (49:15);
- The sub 2-hour marathon: The amazing feat by Kipchoge, and what will it take to “officially” run a 2-hour marathon (1:01:00);
- Comparing the greatest mile runners from the 1950s to today (1:14:45);
- How the brain influences the limits of endurance (1:20:15);
- Relationship between exercise volume and health: Minimum dose, optimal dose, and whether too much exercise can shorten lifespan (1:23:45);
- Age-associated decline in aerobic capacity and muscle mass, and the quick decline with extreme inactivity (1:40:45);
- Strength or muscle mass—which is more important? (1:47:00);
- Avoiding acute and chronic injuries from exercise (1:48:45);
- High intensity interval training: Evolution of the Tabata protocol, pros and cons of HIIT training, and how it fits into a healthy exercise program (1:54:15);
- The importance of understanding why you are engaging in exercise (2:03:00);
- How we can encourage better science journalism and reduce the number of  sensationalized headlines (2:05:45); and
- More.

§

## Show Notes

## Alex’s background and passion for running [3:00]

**Background**

- Alex authored the book [Endure: Mind, Body, and the Curiously Elastic Limits of Human Performance](https://www.amazon.com/Endure-Curiously-Elastic-Limits-Performance/dp/0062499866) — “I literally couldn’t put it down” says Peter
- He’s written many articles for [Outside Online](https://www.outsideonline.com/1745511/alex-hutchinson#close) and [Runner’s World](https://www.runnersworld.com/author/4924/alex-hutchinson/)
- He has a PhD in physics from the University of Cambridge
- He received a masters in journalism from Columbia University
- He was a collegiate runner at [McGill](https://www.mcgill.ca/) and also the University of Cambridge

**Running passion and early career**

- Running was the “most important thing in my life until I was 28”
- After 28, continued training seriously into his early 30s
- Still runs six days a week — “always been the guy who liked to run around and I ran elementary school cross country”
- Joined a track club when he was 15 at the University of Toronto Track Club and was hooked
- High school was at a school called the University of Toronto Schools
- Undergrad was at [McGill](https://www.mcgill.ca/), a great academic school in Canada, but they don’t have athletic scholarships
- Alex was a top tier runner in high school but was ill and didn’t run his senior year so he did not end up getting a scholarship

**Time at** [**McGill**](https://www.mcgill.ca/)

- At McGill, he was a 1,500 meter runner when he showed up and with the assumption that I would be moving up to 5,000 meter
- Alex says he didn’t have a lot of sprint speed
- And the 800 meter run is “the most painful race there was”
- In the context of workouts specifically at McGill, they were more sprint-oriented workouts: hard two-minute effort and a longer rest
- Alex found that challenging — “The intuition would be you want to ask your coach for more recovery, but it was the opposite for me.”
- A two minute all out effort is the single way to get the highest possible lactate levels and that’s synonymous with extreme suffering
- In some ways, Alex would rather run a marathon than an 800 meter race

> “There’s an assumption that longer equals harder, and man, no, there’s a whole different world of pain that you can get into if you’re willing to push yourself hard in those two minute efforts to 10 minute efforts.” —Alex Hutchinson

## The power of the mind: Alex’s “aha moment” that catapulted his running career [9:00]

**Turning point in his running career**

“*This started my movement away from just, ‘we can calculate everything from physiology, that endurance is a little more complicated than the equations that you might start with.’*”

***His “aha moment”***

- Alex was about to compete at a “totally meaningless meet”
- It was his third year at McGill University
- At that point, for almost 3.5 years, he’d been running between 4:01 and 4:03 for the 1,500 meters
- A career goal for Alex was to break 4 minutes
- At this meaningless meet, there was no competition, he going to win the race no matter what
- At the last minute, he just decided he was going to “go hard and just see what I can do”
- In this indoor track, your splits get called out every 200 metersAnd indoor track is 200 meters long so you get splits every about 30 seconds
- The timekeeper called out 27 seconds for the first 200 meters (about five seconds faster than four minute pace)
- 27 seconds is extremely fast and it’s a terrible way to start a 1,500 meters race if you are trying to run sub four minutes
- “I had conflicting emotions of like, ‘Oh God, you idiot’ with ‘Oh, I actually feel surprisingly relaxed’”
- But there’s some magic that happens in a race, and you can sometimes dismiss those discrepancies
- He was way ahead of the pace after the third lap

At that point in the race, two things were happening:

- 1- He realized he was having a really good day
- 2 – Realized that the splits were no longer meaningful because you memorize the splits for the races you think you’re going to run

Next, he made the best decision of his life:

- He stopped listening to the splits and decided to “put his head down and go for it”
- He finished with a time of 3:52, — nine seconds faster than his personal best at the time
- For context, a **one second** personal best would have been a huge victory — “*Nobody PBs by nine seconds after they’ve been training hard for four years, five years*”
- Alex says it was “absolutely mind boggling”

**Post race analysis**

- One of his teammates had been privately keeping Alex’s splits and told him that he actually did NOT go out at 27 seconds, in fact he was closer to 30 seconds (and same thing was lap 2)
- In other words, the timekeeper calling out his splits was actually wrong at the time
- Alex was basically “fooled” into thinking he was having an amazing day, **and then did**

**What happened next?**

- That was a very bizarre circumstance
- But then the question is: ***what happens after that? Do I become a four-minute runner again? Or can I run 3:52 again? And the answer is neither.***
- In his next 1,500 meter race, he ran 3:49
- The next race after that, he ran 3:44 which qualified him for the Olympic trials

**Reflecting on this “aha moment”**

- He realized something has changed within him
- In hindsight, it also changed his understanding of what this whole endeavor was about and what we were trying to optimize
- When his book, Endure, was released, his old coach from high school read the book and asked to see Alex’s training log
- His conclusion was that Alex was in shape to run 3:55, for sure, but he was not doing workouts that predicted 3:44
- So, in a way, the first breakthrough might’ve been in some ways just catching up to the ways he was holding himself back — overthinking, stressing out, etc. all these things that people do in competitive scenarios.
- Then, however, that gave him so much confidence that it slingshotted him right past where he “should” have been able to run

> “The farthest above my baseline workout fitness were in the months after that breakthrough, because I was just riding that high, and I believed I was semi-invincible.” —Alex Hutchinson

**His first Olympic trials**

- Alex’s first Olympic trials for the 1,500 was in 1996
- It did not go as well as he’d hoped
- He came close to dead last in the final (but note he did make the final)
- He was standing line next to Graham Hood (the Canadian record holder at the time) on the starting line
- “*It looks like I’m waking up from a dream and looking around and in my pajamas or something like that. You know I don’t belong on there and you know I don’t believe I belong there*.”

- A year later, he returned to the Olympic trial and ran well — he came in fourth place

*Peter asks Alex if he could have broken a 4 minute mile at his peak:*

- “You’re poking your finger into a raw wound here.” says Alex
- The official conversion tables suggests that he would have run a flat 4:00
- Only a few thousand people have ever broken 4 min mile (more people have stood on top of Everest)
- But Alex believes he would have done it, if he had the chance to try

## Pursuing a Ph.D. in physics while prioritizing his running career, and doing the hardest thing possible [19:00]

**Decision to pursue a PhD**

- Completed a three-year PhD from 97 to 2000 PhD in Britain at Cambridge
- His PhD was in semiconductor physics
- After undergrad, he didn’t know what he wanted to do
- He decided to follow a piece of advice he’d gotten when leaving high school: “***If you don’t know what you want to do, do the hardest thing possible***.”
- One reason why that is relevant is, for example, *you can study physics and then become a journalist, but you can’t study journalism and then become a physicis*t — “You can only slide in one direction”
- Continuing his education was also a way of allowing him to continue his running career
- To be clear, he was considering physics as a career, but his decision was framed in a way that even if he left physics, he would have zero regrets about spending three years in England, studying physics

**How did your training change when you went to England versus Canada?**

- Huge culture difference in collegiate sports
- In the U.S., collegiate sports are a big deal, a medium deal in Canada, and they’re not a big deal in the UK
- The athletic scene at Cambridge, for example, is student run (i.e., there’s no coach)
- But the flip side is you have a lot of autonomy and you take responsibility for your training and your success
- Why this approached in the UK might foster longer term love of sport:
  - “I think the lifelong retention, the extent to which people develop lifelong habits, lifelong love of sport and activity and competition, I think is much higher because you learn to be autonomous in university, as opposed to the classic thing in the U.S is you’re there for four years, you’re representing your college and then college ends.”
  - “There’s no encouragement to stay involved in sport. And you haven’t developed the skills required to self-motivate, self-organize.”

**Decision on what to do after PhD**

- After completing his PhD in 2000, running was still his priority
- He was 25 at the time
- At that point, he was coming back from this three-year injury process
- He was on the right trajectory in terms of his running training in 1998, but injuries set him back for a few years
- He wanted to give himself one year to see if could get back to form and have a shot of making the Olympics
- Moved back home with parents and did some tutoring of high school students
- Spent a ton of time reading in the library (classic books from the 19th century literature)
- He spent a year running, qualified for some national teams, but hadn’t progressed as much as he’d hoped

*Physics postdoc*

- Simultaneously, he was applying for postdocs and took  one at the University of Maryland sponsored by the National Security Agency in quantum computing
- It was a hedge bet: “*I’ll take this, because the research sounds really interesting and the people are fun and it may lead to a physics career*.”

*Running still a priority*

- “The one thing about academic life is if you choose, you can make other things like running your priority.”
- Trained for 2.5 years with a very good training group led by a guy named [Matt Centrowitz Sr.](https://en.wikipedia.org/wiki/Matt_Centrowitz)
  - His son, [Matthew Centrowitz Jr.](https://en.wikipedia.org/wiki/Matthew_Centrowitz_Jr.), went on to win the [Olympic gold medal in the 1500 m in 2016](https://www.youtube.com/watch?v=YkKqN0jVglw)

## Career transition to journalism, tips for improving your writing, and insights from the best writers [26:00]

**Decision to pursue journalism**

- Hard to explain, says Alex, but he started to notice he enjoyed writing
- He actually enjoyed writing his PhD dissertation (most people hate that part)
- So he thought he might like writing as a career
- Applied for a bunch of internships, but didn’t get any
- He decided it was a credentialing issue, he needed to show people he was serious about journalism
- So while doing his physics postdoc, he applied to a few different journalism schools for master’s programs (this was in 2004)
- Timing wise, he decided to give one last shot at the Olympics, but if it didn’t work out, he could start journalism school right after that

**Farewell to running**

- He got a stress fracture in his lower back three months before the Olympic trials
- Went to the Olympic trials anyway as a “farewell to running”
- “My Olympic dreams were officially over.”

**Transition to journalism**

- He wanted something else to be passionate about
- Alex realized at some point that when he went home from his physics job, he had no interest in thinking about physics any more
- Alex figured that journalism could be a way to pursue his interests  in a professional way

> “So I needed to find something. . .that I wanted to keep doing. Where the work and the play overlapped.” —Alex Hutchinson

\*\*\*

**Running books that influenced Alex back in high school**

- Alex is a reader and when he got into running in high school, he read books on the subject
- One of the first books he read was [Lore of Running](https://www.amazon.com/Lore-Running-4th-Timothy-Noakes/dp/0873229592) by [Tim Noakes](https://twitter.com/proftimnoakes?lang=en)
- He also remembers reading another book called [Better Training for Distance Runners](https://www.amazon.com/Better-Training-Distance-Runners-2nd/dp/0880115300) co-written by a physiologist named David Martin
- “*I could talk about VO2 max and lactate threshold with other people who were interested in this stuff. But I wouldn’t say I had a deep understanding of where it came from. I had a superficial acquaintance with the concepts*.”

\*\*\*

**Back to journalism career**

- He completed one year of journalism school
- Then did 16 months as an intern at a newspaper called the [Ottawa Citizen](https://ottawacitizen.com/) where he learned to write on deadline — “*when you’re the lowest man on the totem pole at a daily newspaper, you learn to write fast, multiple stories a day*”
- After his internship finished he became freelance (because there were no jobs)
- About 2008, he started to get into writing about the science of running

**Lessons learned from journalism school and interning at the Ottawa Citizen**

*What he got out of journalism school*:

- First, an understanding of the jargon
- Secondly, the forms
  - In high school, he learned the “hamburger essay”: five paragraphs, an introduction, three main points, and a conclusion
  - Turns out that there are underlying forms for most of the articles we read
    - A news story uses the “inverted pyramid”
  - For good writers that form is invisible
  - You don’t need to be slavishly following those forms, but you need to understand what the forms are, so you can understand when you’re deviating from them you’re doing it on purpose
  - Also, using forms helps you understand what a reader’s expectation is (even if the reader himself or herself doesn’t realize what that expectation is)
- **In summary**,
  - he learned about forms — but learning about form is “not the same as mastering the form”
  - He learned by doing — “rarely getting more than a day to write a story”
  - He notes that “doing” was beneficial only because he had a sense of what the structures are that you’re trying to transcend

*What good writers do—*

- You’re trying to be more than just plugging in the pieces of a jigsaw puzzle
- Every piece of writing has form—whether it’s a news story, grant application, scientific publication
- Also must have a good understanding of who the audience is — “*If you understand who the audience is, you understand what their expectations are in terms of what the piece is going to flow like*.”

**How to improve your writing:**

- Practice: Doing a lot of writing on your own
- Reading critically and studying good writers: Look at the writing that you like and try to break it down…
  - What are they doing here?
  - What makes this work?

**The parallel of the talent of great athletes to great writers**

*Peter makes the following point*:

- Somewhat like athletes, you could have the same debate about good writers being born versus made in terms of scientific writers
- Sid Mukherjee, for example, is incredible — “It’s no different than watching a remarkable athlete do something.” says Peter

*Alex extends the parallel*

- We can look at Michael Phelps swimming and say, “I will never be able to swim like that.”
- But it’s a mistake to then say, “Swimming is also all genetic and therefore I am doomed not to get better at swimming than I am right now.”

> “Most people don’t come anywhere close to fulfilling their “genetic potential.” —Alex Hutchinson

- Alex is especially blown away when fiction writers take their skills into non-fiction — “*The level of language and imagery; To be honest it’s sometimes a little depressing to me*.”

\*Final tip for writers: **Own who you are**

- “*I’m not a poetic writer, but what I hope to be is a very clear expository and explanatory writer. So I will never paint the picture that I really admire in some other writers’ writing, but hopefully I can excel at another aspect of it*.”

## Breaking down VO2 max: Definition, history, why it plateaus, and whether it really matters [38:15]

what VO2 max is, both in an absolute term, and then in a manner that we normalize it by weight, and what it is and what it isn’t. How it’s measured, how it matters, and maybe we’ll even talk about some notable exceptions.

**What is VO2 max**

- The first order analogy = it’s the size of your engine
- Physiologically, VO2 max is telling you how quickly you can take oxygen from the air into your lungs, get it into your blood, pump it to your muscles, and then have your muscles use it in the metabolic processes that will provide energy to move you
- VO2 max is a rate ⇒ how much oxygen per unit time can you process going max effort

**Quick backstory**

- VO2 max was first discussed/measured in the 1920s by a guy named [A.V. Hill](https://en.wikipedia.org/wiki/Archibald_Hill), a very good runner himself
- If you ask someone to go out and run at a gentle pace, let’s say they consume 2 liters of oxygen per minute
- Tell them to speed up and now they’re doing 3 liters of oxygen per minute
- Tell them to speed up again and now they’re going really fast and they’re losing 4 liters of oxygen per minute
- Tell them to speed up again and they are still only using 4 liters of oxygen a minute
- In other words, there’s a plateau—a point at which, even though you’re working harder, you’re not using any more oxygen

*What it means when you plateau*

- Basically, you’ve reached a point where no matter how hard you push yourself, you can’t get more oxygen
- You can still go faster, because you’re starting to use other forms of energy, but this is the limits of your aerobic system
- VO2 max does NOT tell you exactly how fast you can run, but it tells you what sort of aerobic engine you have to play with

**Explaining the unit of measurement**

*How body size affects your VO2 max*

- When Alex was tested back in high school, he could get to around 5.1 or 5.2 liters per minute
- A good rower, by comparison, would be using 7 liters a minute or more
- However, the rower is much bigger than Alex
- So his higher liters per minute doesn’t necessarily mean that that rower is better at using oxygen, because the rower has way more muscle
- The amount of oxygen reaching any given muscle cell may actually be lower

**Milliliters per kilogram**

- A better comparison between athletes is to divide by weight
- Rather than liters of oxygen per minute, VO2 max numbers are typically reported in **milliliters of oxygen per minute, per kilogram of body weight**
- For Alex, 5 liters of oxygen per minute works out to something like 80 milliliters of oxygen per minute, per kilogram of body weight

*An even better comparison*

- Peter says a better comparison would be total liters per minute divided by lean mass, normalized at time
- Then you’re at least getting the metabolically active tissue, presumably.

***Does it even matter?***

- At a certain point, it doesn’t matter that much anyway because you can’t just measure someone’s VO2 max and know how fast they’re going to race
- It’s really not that useful, especially for comparing between people
- Now comparing within yourself and how you improve, does tell you something, but in that sense it doesn’t matter what you’re dividing by

**What is it that causes VO2 max to plateau?**

- Researchers love the VO2 max test because it is separated from motivation — “if you tested endurance by simply having someone run a mile as fast as possible, any test like that depends on motivation”
- The nice thing about VO2 max is that, in theory, it’s independent of motivation
- So if you see a plateau, you know that’s a property of their body and not a product of whether they were excited about the study

*-So what’s causing the plateau?*

- It could be in the lungs
- heart
- circulation
- the muscle’s ability to extract oxygen
- It’s still a controversial topic

*-The picture that emerges*:

- Almost every part along this cascade is engineered more or less to what it needs to be
- And so if you perturb any of those elements, you can get limitations
- For example, the conventional wisdom is that your lungs are not a limitation, that you can always breathe enough in
  - And for decades, it’s been conventional wisdom that the lungs don’t respond to training because they’re overbuilt
  - There was a big [review paper](https://pubmed.ncbi.nlm.nih.gov/32790594/) published recently arguing that in some cases the lungs aren’t overbuilt and one of the situations is highly trained endurance athletes
    - They can be limited by their ability to get enough oxygen in
- You can also run into situations where an athlete is so fit, their heart is so strong, it pumps blood past your lungs so quickly that it doesn’t have time to fully stock up on oxygen
  - get something called [exercise induced arterial hypoxemia](https://pubmed.ncbi.nlm.nih.gov/17089876/)
  - usually an issue at altitude, but in elite endurance athletes is actually about half of them exhibit it even at sea level
- At every stage of the way, there can be limitations if anything is knocked off kilter
  - Right down to the ability of the muscles to first extract the oxygen from the bloodstream and then to make use of it metabolically in the mitochondria
- “*There isn’t one single answer*”

***Is there a better way to test where the limitation is coming from?***

Peter says he’s always wanted to see this kind of experiment:

- Take a group of athletes and run them all to max
- Then you reduce the FiO2 of the incoming oxygen
  - With room air, for context, you’re getting a fractional inhalation of oxygen of 21%
- The way they’re calculating how much oxygen is being consumed is they’re measuring the concentration of oxygen on the way out and calculating the delta
- Peter thinks it would be interesting to start selectively dropping FiO2 21%, 20%, 19%, 18%, etc.
- Presumably if the lungs aren’t the limitation, you should still see the same absolute delta
- This experiment would least start to eliminate one of those variables—which would be FiO2 and capillary exchange—and then you start pointing to some of these other variables

**The lactate paradox**

- It’s interesting when you go to higher altitude and you reduce the amount of oxygen, “f*unny things happen*”
- First, you would think what would happen is you can’t get enough oxygen, so you’re going to be go anaerobic sooner, you’re going to produce more lactate
- And yet, the opposite happens — something called the [lactate paradox](https://journals.physiology.org/doi/full/10.1152/nips.01382.2001)
- Also, if you try and exercise to exhaustion at *lower levels of altitude*, you actually give up when your lactate levels are lower than you would at sea level
- The picture that makes sense to Alex is that these things are not just about how much oxygen is making it to the muscle:
  - It’s also like, “What is your brain oxygen level?”
  - Other circuit breakers that are starting to come down that aren’t even on this path from mouth to lungs, to blood, to muscle.
  - “There’s other factors that are saying, ‘*Whoa, wait a second. Oxygen is getting a little low, we’re going to actually cut off the supply to the muscles or reduce it in order to make sure that we don’t get stupid*.’”

## The case study of Oskar Svensson: Why a higher VO2 Max isn’t always better, and the difference between maximum aerobic capacity and efficiency [49:15]

[**Oskar Svensson**](https://en.wikipedia.org/wiki/Oskar_Svendsen)

⇒ **See Alex’s profile on Oskar Svensson**: [The Story of the Cyclist with the Highest-Ever VO2 Max](https://www.outsideonline.com/2398524/highest-ever-vo2max-cyclist-oskar-svendsen)

- Oskar Svensson was a former downhill skier who had taken a talent screening to see whether he’d be suitable for something like cycling
- At age 17, completely untrained, he scored something like 74 milliliters per kilogram per minute in VO2 max
- He started training as a cyclist as a teenager and pretty quickly scored 83, then 85, then 92
- Then, a [scientific journal was eventually published](https://pubmed.ncbi.nlm.nih.gov/31194601/) saying his score was 96.7 when he was 18 years old
- This is not only the highest recorded score in human history, but it’s also higher than all the rumors

*History of high scores*

- Reports exists of people in the 90s, but high VO2 max numbers sprout very easily because it’s hard to do these tests right
- The garden variety machinery used to do these tests is not designed to handle seven liters of oxygen per minute
- The previous VO2 max record holder was [Bjorn Daehlie](https://en.wikipedia.org/wiki/Bj%C3%B8rn_D%C3%A6hlie), the greatest cross country skier in history who in the late 90s reputedly tested 96
- The Norwegian ski team leaked it to the press as a kind of PR move, it was never published in a journal
- [Matt Carpenter](https://en.wikipedia.org/wiki/Matt_Carpenter_(runner)) reported measured 90.2
- [Kílian Jornet](https://en.wikipedia.org/wiki/K%C3%ADlian_Jornet_Burgada) reported measured 89.5
- [Steve Prefontaine](https://en.wikipedia.org/wiki/Steve_Prefontaine) measured 84
- A lot of people who have high numbers, but virtually none of them are published in the scientific literature

**Oskar’s VO2 max**

- Oskar’s score of 96.7 is “higher than the rumors, but it’s way higher than the verified numbers”
- They even disassembled the machine and send it back to the manufacturer to get it calibrated
- It came back showing that it was indeed working properly
- After his retirement they [published the data](https://pubmed.ncbi.nlm.nih.gov/31194601/) and shared it
- He was tested again several months later, he has put on 2.5 kilos of body weight
- His VO2 max number came down into the 80s
- But his **absolute level of maximal oxygen consumption had barely come down**
  - Alex finds this second test to be the most convincing argument that the original test was accurate

**Oskar’s cycling career, and why VO2 max doesn’t correlate perfectly with performance**

⇒ See [Why a Higher VO2 Max Isn’t Always Better](https://www.outsideonline.com/2407295/why-higher-vo2max-isnt-always-better)

- He turned pro at age 20 with team called [Joker](https://en.wikipedia.org/wiki/Joker_Fuel_of_Norway)
- The expectations were out of line with what was reasonable
- Officially announced his retirement when he was 23

*Why wasn’t he successful?*

- Reanalyzing his data:
- History of VO2 scores:
  - Starts at 74, goes past 80, hits 90 something, then tops at 96
  - Then he actually comes back down and after he retired from cycling, he was back down to 77
- Looking at his efficiency:
  - A much more interesting story
  - He started out at his most efficient when he was untrained
  - The more he trained, the less efficient he got, meaning he could deliver more aerobic energy, but he used more aerobic energy in order to maintain a given pace.
  - For a given output, *how much input (oxygen) do you need to get this output?*
    - An athlete over time should get better and better
    - For a fixed wattage, you want to see what’s called PvO2 (power at a given VO2) come down as you get better
      - In running, this would be the vVO2
  - In other words, for a given oxygen consumption, you want velocity to go up just as you would want power to go up
  - Peter is very surprised by that — “*I would have been less surprised if it had been unchanged, but I was very surprised that it deteriorated*.”

Long-standing debate: *Is there an inverse relationship between VO2 max and efficiency?*

- Said another way, *if you build your engine bigger, do you necessarily end up with a less efficient engine?*
- Still no consensus on this
- If you just take a bunch of elite athletes and you measure their VO2 max, you tend to see an inverse relationship — The people who have the highest VO2 max tend to have slightly lower, slightly worse economies
- People that have the best economy, tend to have **slightly worse VO2 max**

*-Possible explanations for this phenomenon*:

- Possibility #1: You don’t tend to hit the lottery twice
  - If you happen to have a VO2 max that’s 92, then you’re not going to have the best possible economy
  - And when you’re only looking at elite athletes, that means that everyone else there’s going to have something special
  - So if they don’t have the best VO2 max, by definition they have to have a great economy, because they have to have something that’s exceptional
  - you see this inverse relationship that either you have good economy or you have good VO2 max
- Possibility #2: There’s actually a trade off—if you’re optimizing one physiological parameter it may come at the cost of the other physiological parameter
  - The Oskar Svensson data points to this  explanation
  - The training he did must have been pretty good for increasing VO2 max
  - But it may have actually been bad for his economy at a metabolic level
  - A paper was published in response to this Svensson case study [reanalyzing his data](https://www.outsideonline.com/2398524/highest-ever-vo2max-cyclist-oskar-svendsen)
    - That paper was pointing to a potential cell level explanation of what’s happening to certain enzymes at a given point
    - The upshot of the paper:
      - If you’re doing a lot of training that requires very high VO2 max level outputs, your metabolism and your cells need to make choices to produce high output, instead of to be as efficient as possible.
      - And over time that’s what you’ll get better at and you’ll lose that efficiency. And so you’ll pay a slight penalty for optimizing your training for VO2 max
  - The question worth considering is what would have happened if you took Svensson’s genetic gift of an engine and instead of maximizing on VO2 max, you train him and he’d get up to 85 or 90 maybe, but you put much more effort into sort of [zone 2](https://peterattiamd.com/ama19/) (right at lactate of 2.0)

*-Looking at his training In the* [*original paper*](https://pubmed.ncbi.nlm.nih.gov/31194601/)*…*

- Oskar was spending a lot of time in the 300 to 400 watt range, but he could have probably been in the 300 watt range where he’s still just under two millimole of lactate, but he’s dramatically increasing mitochondrial efficiency
- If that [zone 2](https://peterattiamd.com/ama19/) work represented two thirds of his training volume, he’d likely have a lower VO2 max, but he might have been a better cyclist
- “*Whatever he did, he paid too high a price for that VO2 max, just by definition, it didn’t work out.*”
- This observation agrees with the prevailing wisdom among endurance athletes that about 80% of your training should be easy, conversational pace (i.e., [zone 2](https://peterattiamd.com/ama19/))

⇒ See [AMA #19](https://peterattiamd.com/ama19/) for a deep dive into zone 2 training

## The sub 2-hour marathon: The amazing feat by Kipchoge, and what will it take to “officially” run a 2-hour marathon [1:01:00]

**Alex’s 2014 prediction**

- In 2014, Alex wrote an [article for Runner’s World](https://www.runnersworld.com/uk/training/marathon/a774501/what-will-it-take-to-run-a-2-hour-marathon/) predicting that it was possible to run a sub two-hour marathon, but that it wouldn’t happen until around 2075
- His prediction was based on how marathons as they are currently run
- But, he did say that if it’s going to happen, it’s going to happen on an optimized course — one that optimizes for temperature, terrain, curvature, etc.
- “*Marathons are this kind of anomaly where they’re run in a Tour de France style, in a very uncontrolled environment which differs from race to race. And yet we care about time*.”
- The world record in 2014 was 2:02:57 by a guy named [Dennis Kimetto](https://en.wikipedia.org/wiki/Dennis_Kipruto_Kimetto)
- To break 2 hours, someone would need to shave 3 minutes off the record — For context, it took about 30 years to shave 4 minutes off a marathon time when the world record was 2:06:50, by [Belayneh Densamo](https://en.wikipedia.org/wiki/Belayneh_Dinsamo) in 1988
- Of course, things are getting optimized as we go so you would expect the curve to be leveling out — “*There’s less and less low-hanging fruit to get*”

**Breaking2 project**

- In 2016, Alex was assigned to report on a top secret Nike project called [Breaking2](https://www.nike.com/running/breaking2) — a race they eventually held in spring of 2017 ([video](https://www.youtube.com/watch?v=pN5sla8vDr4))
- They’d spent about several years with 20 people full-time working on it, trying to engineer a sub two-hour marathon
- Brought 20+ of the best runners to labs to measure their VO2 max and their economy and various other things
- They narrowed it down to three runners before choosing [Eliud Kipchoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge)
  - Check out Alex’s article: [We Now Have the Lab Data on Nike’s Breaking2 Runners](https://www.outsideonline.com/2418570/nike-breaking2-runners-lab-data)
- The track they chose was [Monza](https://en.wikipedia.org/wiki/Italian_Grand_Prix), the Formula One race track in Northern Italy
- They used the junior loop because that was the straightest possible with just the barely perceptible curves
  - it doesn’t have much elevation change
  - close to sea level
  - They optimized the nutrition, the aerodynamics by sticking adhesive bumps onto the legs of the runners to try and reduce the drag when they’re swinging their legs back and forth
- The two most significant things they did were
  - 1) Having ~7 pacemakers basically blocking the wind for the chosen runners for the whole way
    - They had to have runners dropping out every couple of laps and new runners swapping in (not allowed according to the official rules of marathoning making this race “unofficial”)
  - 2) They used a whole new type of shoe that had a curved carbon fiber plate embedded in the sole that improves running economy by about 4% on average
- Eliud Kipchoge was the reigning Olympic champion and he had the second or third fastest time in history at that point

**Results of the first Breaking2 race**

- Kipchoge ended up running **2:00:25** (two and a half minutes faster than the world record)
- While he didn’t run sub-two, it was considered a victory because nobody thought that all optimizations would actually add up to a human running that fast

*The sequel:* [*Ineos 1:59 Challenge*](https://en.wikipedia.org/wiki/Ineos_1:59_Challenge)

- In 2019 in Vienna, funded by the petrochemical company, INEOS, instead of Nike, they basically replicated most of what Breaking2 had done
- Kipchoge at this point had set the marathon world record of 2:01:39 at the Berlin Marathon on September 16th, 2018
- In this Ineos 1:59 Challenge, [he ran 1:59:40](https://www.youtube.com/watch?v=IAxYQJewtbU) and “it has galvanized and polarized the running world”
- These events left a bad taste in the mouths of a lot of people, both for the circus-like quality, but also because of the shoes
- The shoes became very controversial because it’s not clear whether shoes that make you 4% more efficient are within the spirit of the sport or within the rules of the sport

**What role should advancing equipment play in record books?**

- Peter says this sounds an awful lot like where swimming was in 2008 and 2009
- The tech suits from basically 2000 to 2008 had gotten so quick that by 2009 FINA said it would no longer allow the suits beyond 2009
- There are still some world records that stand nearly 12 years later, from those 2009.
- There was this sense that banning those suits would just completely change the record book, but it has turned out that swimming has continued to advance
- It’s an analogous debate, says Alex, of *What role should the equipment play in a sport that is not like Formula One, whose inherent attraction is its simplicity?*
- Looking at cycling
  - consider a bicycle today versus a bicycle 20 years ago
  - if you look at the bikes ridden in the late ’90s versus today, they’re not even the same thing. They’re not even close

*Alex’s overall take regarding the* ***advancement in running shoes***:

- The key that I would say is… anyone who thinks that the progress of the sport over the last 10 years, much less 50 years, much less 100 years is all about, “Well, we’ve learned more and we’re digging deeper,” is kidding themselves.
- Technology is baked into the improvement curve, changes in circumstances, environment and technology are baked into those curves right from the get go
- You can acknowledge that and still say, “*I understand the curve’s going like this, but I don’t want it to* ***drop off a cliff***.”
- The world records have been absolutely knocked silly in the last two years, since these shoes have become common
- So it’s a tough call, says Alex
- “I don’t think it was obvious that you could ban them until they’d already been used enough to realize that, ‘Oh, wait, this is real. This is a big advantage.’ By which time it was kind of too late to ban them
- Alex is sort of used to press releases every year of new tech that promises to append the sport of running, so he kind of ignores that stuff
- Additionally, carbon fiber plates had been used before—including to set world records—it’s just that Nike finally got the recipe right
- So in a sense, it changed the sport, and in the long run things will settle back into parody and we won’t worry about it
- But, there was a period about 2016 to 2019 where it’s like, if you didn’t have the right shoes you probably weren’t going to win the race. And that is a little unfortunate.

**Alex’s revised prediction**

*When do you think 2 hours will be broken on a legitimate road course with full marathon rules that will constitute a world record?*

- “It’s not going to be 2075.”
- But the answer depends on what you define as legit
  - e.g., Is a loop course legit? Can they pick a start time depending on weather forecasts?
    - For the record, Alex *would* consider those option “legit”

The key thing that needs to change for it to be official in Alex’s mind: **Pacemaking**

- You can’t have people jumping in halfway, that’s the number one thing they have to change for me to consider it a legit sub two-hour marathon
- Alex now thinks it could happen sometime in the next 10 years

## Comparing the greatest mile runners from the 1950s to today [1:14:45]

Peter asks:

*What is the difference between* [*Roger Bannister*](https://en.wikipedia.org/wiki/Roger_Bannister) *and the fastest miler today?*

*How much of that difference is technology, how much of it is training/nutrition?*

*What would be the buckets you would classify as the improvements?*

- Bannister’s fastest mile was 3:58 which he ran in 1954
- Today’s record is 3:43 set by [Hicham El Guerrouj](https://en.wikipedia.org/wiki/Hicham_El_Guerrouj) set in 1999
- The biggest change from Bannister to now is training, says Alex
- Bannister trained with four or five miles a day, five, six days a week — “he was training at a very, very light level”
- Even one of Bannister’s contemporaries, [Emil Zátopek](https://en.wikipedia.org/wiki/Emil_Z%C3%A1topek) was starting to push the boundaries of how hard you could train,  doing 60 by 400 instead of 10 by 400
- “S*o, it’s not like nobody understood that training worked, but Bannister versus today, it’s training is the difference*.”
- The track quality and the quality of the spikes is negligible
- Nutrition for a mile run is just not that big of a deal

*If you fast forward to the 1960s…*

- People like [Jim Ryun](https://en.wikipedia.org/wiki/Jim_Ryun)—who ran 3:51 for the mile as a teenager in 1967—he’s training like a beast with 40 by 400 meters
- His pace was probably 65 seconds per 400 with a couple minutes of light jogging between each 400
- At that volume, in the context of high mileage, he was doing them at a pace that was extremely challenging
- Zátopek’s the guy who’s holding his breath between phone poles on his run — So, he was all about just making stuff hard
- Whereas Ryun was taking that to a systematic level with his coach [Bobby Timmons](https://www.nytimes.com/2015/08/06/sports/bob-timmons-91-a-demanding-coach-who-developed-a-star-runner-is-dead.html)

**Not much change in training from the 1960s to today**

- You can’t make much distinction between the training of the 1960s and the training of today
- If you take Jim Ryun’s mile time of 3:51, it’s only 4 seconds off the current world record
- By the 60s, training was mature
- All the other stuff that we worry about—nutritional aids, nomadic compression devices, ice baths, etc.— “*I’m not saying it doesn’t help on an individual basis, but* ***you can’t see it in the record curves*** *or anything like that.*”

**Overlaying this against horse racing**

- Horse racing time records have stagnated since the 1950s
- [Secretariat](https://en.wikipedia.org/wiki/Secretariat_(horse)) is hands down the fastest horse that’s ever run
- Peter read a very interesting argument that made the point that we’re getting further from Secretariat now because we’re actually seeing less diverse breeding of horses
- Secretariat’s times were unbelievable when you think about it through the lens of even running, to run a mile in a quarter and to negative split by mile all five miles
- “*Secretariat’s winning times at Belmont, I don’t think any horse will come close to that*.”
- It’s important to note…
  - Whatever amount of money we have in the running world that is allowing us to optimize nutrition and training, and yet there’s way more running in horse racing.
  - If there were physiological advances that allowed us to run faster, they would be using those on horses

## How the brain influences the limits of endurance [1:20:15]

**Insights into the limits of endurance**

- Alex eventually was able to focus his journalistic work to researching and writing about running
- Initially, he was doing so in a very conventional way—what heart rate should you do, your running tempo, etc.
- Then he starting taking a closer look at the literature
- He came across a [paper](https://www.researchgate.net/publication/6078653_Does_Dehydration_Impair_Exercise_Performance) around 2007/2008 in the journal of physiology debating whether or not dehydration impaired endurance performance
  - In the paper, [Tim Noakes](https://twitter.com/proftimnoakes?lang=en)—a very notable contrarian scientist—was arguing that we have NOT shown that dehydration itself impairs performance, rather it’s thirst that impairs performance
  - In other words, if you drink enough that you’re not thirsty—even if you’re dehydrated—it doesn’t impair performance
  - Alex’s reaction to this was, “*Oh wait. One of the things that I thought was beyond debate is debatable*.”
- Following this thread, he discovered that Tim Noakes had proposed this idea called the [central governor model](https://en.wikipedia.org/wiki/Central_governor)—when you exercise as hard as you can, the reason you stop or slow down is NOT because your legs aren’t capable of going faster, it’s because your brain is protecting you
- This concept started to make the connection to his “aha moment” in his 1500 meter race — “*If it’s just ‘multiply your VO2 max by your running economy divided by your lactate threshold’… there shouldn’t be any change.*”
- This got him interested in **role of the brain** in the limits of human performance
- This was the seed of his eventual book, [Endure: Mind, Body, and the Curiously Elastic Limits of Human Performance](https://www.amazon.com/Endure-Curiously-Elastic-Limits-Performance/dp/0062499866)

> “There should be a book about this. . .about how do we bring the brain in, not just in a sense of you have to really want it to try really hard, but to understand how the brain is influencing, or controlling, or playing a part in determining the limits of endurance.” —Alex Hutchinson

## Relationship between exercise volume and health: Minimum dose, optimal dose, and whether too much exercise can shorten lifespan [1:23:45]

**Where does endurance sports fit into health?**

- The purpose of the sport is to be fast—to have endurance and speed at the right combination
- But even if one is not competing, endurance based exercise is still an important pillar of health, says Peter

*Many people misinterpret their body’s distress signals*

- Alex says one of the barriers to being physically active is when people interpret the distress signals when you start exercising as signs that your body is reaching its limit
- You’re panting, you’re out of breath, your legs are burning, and thinkin “I’m giong to die”
- Many people will stop at that point
- But it’s not so much about how to change your limits… but about understanding what those limits represent and understanding that **they are not signs that you’re going to die**

*Some discomfort is necessary*

> “Any meaningful form of exercise that’s going to do substantial amounts of good is going to involve dealing with discomfort in one form or another.” —Alex Hutchinson

- Get to a place where you understand that the feelings of discomfort are not signs that something is going wrong with your body, but they are just information
- The signals are telling you where you are on the road to reaching your limits
- You don’t have to go to your limits but you also don’t have to stop
- Instead, you can just interpret that as information and say, “Okay, understood. I’m out of breath, but I can keep going.”

**Opposing points of view on the relationship with volume of exercise and health**

Two opposing points of view with respect to exercise:

1—One point of view is that the exercise longevity curve is J shaped

- At the far end of the spectrum, no exercise is a really bad thing for mortality
- As you increase exercise mortality improves, improves, improves, improves, improves, improves until you reach your best all-cause mortality
- And if you continue to increase exercising beyond a certain volume, you see a little uptick in mortality
- And a lot of times this is harm that comes in the form of cardiac dysrhythmia, or even atherosclerosis through endothelial damage, fibrosis, etc.

2—The other point of view is that the exercise longevity curve is more or less a monotonically improving

- Alex’s perspective on the idea that too much exercise can lower mortality:
- First, alex admits his bias that he is skeptical of the idea of a reverse J curve
- Secondly, there’s no doubt that there’s a reverse J curve to some degree – e.g., If you try to run 20 hours a day it’s not going to be good for you
- Thirdly, while Alex’s generally doesn’t think the data of a reverse J curve is very convincing, he said that the studies did lead to something interesting:
- A few studies came out and showed that the dose you need to get most of the health benefits is **very small** — I.e., *you do not need to train for a marathons in order to be optimally healthy*

**Minimum effective dose of exercise**

- Hypothetical: Someone who is 40 years old, their waist is five inches too big, they have metabolic syndrome, etc.
- What is their minimum effective dose? I.e., How many hours or how many miles do I need to do a week to just get 80% of the benefits for 20% of the efforts?
- The [Cooper Clinic study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4131752/) looked at 50,000 people or so and their number was 5 to 10 minutes a day (an hour a week)
  - Alex, however, says: “That’s not my definition of an **optimal** exercise routine.”
    - For one thing, it lacks any high intensity cardio or strength training

**Optimal dose (and Alex’s routine)**

*Alex’s routine*:

- Alex runs about 20 miles a week
  - Six days a week
  - half an hour with a couple of hard days
- Alex says he thinks he would be even healthier/live longer if he did MORE running that this (such as adding one longer run a week)
- “I *come from a background where I’m already used to running, 20 miles a week doesn’t stress me very much. . .just slows down my decline*”
- Alex would also add more strength training to his routine
- In fact, he would prioritize strength training if he was planning to add more exercise volume to his routine

**Tips for exercises and injury prevention if you’re just starting out:**

*Dose and frequency*

- 5 to 10 minutes a day is a good place to start if you’re the 45 year old sedentary getting back into it
- If you’re doing 60 minutes a week, Alex says not to do 10 minute chunks, but rather at least 20 min at a time

*Injury prevention*

- Metabolically unfit individuals are likely to gain metabolic fitness more quickly than they improve/strengthen ligaments, tendons, and muscle strength
- This is important to keep in mind so that you progress slowly to allow those aspects to catch up to aerobic fitness

**Casting doubt on the reverse J curve idea [1:33:15]**

Two main studies on which this whole J curve hypothesis was founded:

 1-The [Copenhagen study](https://pubmed.ncbi.nlm.nih.gov/25660917/)

 2-[Cooper Clinic data](https://www.abstractsonline.com/Plan/ViewAbstract.aspx?sKey=32617aef-b494-41b8-b2bc-3d49357a8976&cKey=984e0396-f663-4068-bbf3-1dc4023c17e1&mKey=%7bFCDB1C1C-280A-4DF1-95F8-2DAA9AB6A8BE%7d)

- Copenhagen study reanalyzed their data with a new co-author and concluded that running too much or too fast was bad
- Two deaths in the group that ran too fast (the confidence interval was essentially infinite)

*The major issue with the data from both studies*:

- When you have a big study of 50,000 people who were just randomly selected, they’re not all the same.
- They all have different characteristics, so you have to find some way of adjusting for various characteristics
- Basically they statistically adjusted for things like cholesterol levels, weight, blood, sugar levels, blood pressure ⇒ It’s meaningless if you compare the non-runners who died sooner than the runners because they were also likely 20 pounds heavier and had all these other risk factors — So you want to equalize it
- But there’s a problem that if you equalize it you’re essentially saying, “Well, what are the health benefits of exercise if you don’t do any exercise?” Because the health benefits of exercise are precisely in helping you regulate things like blood pressure and blood sugar and weight
- “*To me, that was statistical misconduct*.” says Alex
  - “You basically penalize them for having lower weight, better lipids, better blood sugar, better blood pressure” — But you can’t adjust for a **mediating variable**
  - “You bring them in line so that they’re just as overweight and just have all the other risk factors, then you see this J curve.”
- When they actually [published the data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4131752/) in a peer reviewed journal two years later, the J curve had disappeared

**Peter’s take on the reverse J curve data, and the importance of diversifying your exercise portfolio**

- First of all, 99% of people are not exercising too much and don’t even possess the fortitude to exercise too much
- We’re really just discussing hyper exercisers

But here’s the bigger point:

- It’s less relevant whether or not they’re spending too many hours cycling, swimming, running, etc.
- It’s more about the portfolio allocation of how they’re spending it that’s the bigger problem
- They “hyper exercisers” are typically not well-rounded and they’re **not actually in pursuit of longevity**
- Think about the athletes in the Tour de France: Those guys finish the tour, anemic osteopenic, their upper bodies are emaciated, their posture is horrible
- They’re physiologic marvels but their health span sucks.
- How would we extrapolate that to the 40 year old who just can’t hang up the dreams of being a professional athlete?
- Maybe he’s out there running or riding or doing all of that stuff nonstop, but at the expense of something beneficial; For example:
  - No pilates to work on core strength
  - Not working on stability,
  - not working on strength
  - not varying the intensity of their workouts to work different energy system

**Summary**:

- Exercising too much is less of an idea that the issue of having a lousy portfolio of various exercise types
- Training for a marathon may not be bad, but it’s an opportunity cost of other things you could be doing that would probably work better in pursuing longevity
- There are other potential issues with lots of endurance training, such as arrhythmias
- So there may be downsides to training *really* hard
- “On balance overall, I would say, I don’t lie awake at night, worrying about people who are running 50 miles a week” says Alex
- We should worry far more about people who are eating poorly, smoking, who are stressed out of their minds, than over-exercisers

**Benefit of social exercise**

- [One study](https://www.sciencedirect.com/science/article/abs/pii/S002561961830538X) suggested tennis and badminton were associated with the most longevity largely due to that social interaction in those activities
- Alex says it might be perceived that running is a solitary thing, but he says it’s his primary social outlet, where he meets his friends, etc.

## Age-associated decline in aerobic capacity and muscle mass, and the quick decline with extreme inactivity [1:40:45]

If you could reverse engineer where you want your VO2 max to be when you’re 90, what should it be?

- When I’m 90, the real risk is that I won’t be able to get up out of a chair more than that I won’t have the VO2 max
- Far before his VO2 max is too low, he’s going to be the guy who falls on the floor and can’t get up
- If he could wave a wand, he would put on some muscle mass
- For people who have the opposite problem (plenty of muscle mass), Alex stresses that they need to really work on their aerobic fitness

**Inevitable decline with aging**

With muscle, there’s an inevitability of decline

- If you do nothing, you’re going to lose X pounds of muscle per decade if you’re lucky with a tailwind
- If you train really hard, you might be able to reduce it to X amount of loss
- If you really go hard, you might even be able to keep it flat

With aerobic capacity…

- There are tables that predict decline, but the problem with the tables is that they draw a nice smooth line
- According to the table, you lose something like 9% per decade until you get into your seventies when it gets even steeper
- Now, that table may work on a population level, but what actually happens is the decline is not that steep for any individual
- Generally what happens is you have certain events in your life—an injury that prevents you from training, or worse, bed rest for a week
- That even may make you lose 7% in the course of a week, and you only get 2% back
- This points to the importance of making sure you try to avoid big injury setbacks to the extent possible
- In the absence of those events, the decline doesn’t have to be that steep,  you can hang on probably better than people used to think

**The impact of extreme inactivity**

- Huge difference between being bedridden versus going on vacation to Europe, but you’re still walking everyday
- Bed rest is terrifying, says Alex
- A professor named [Luc van Loon](https://www.maastrichtuniversity.nl/l.vanloon) in the Netherlands is focusing his research on muscular strength, and he’s done studies showing the negative effect of bed rest
  - ⇒ Check out: [Individual Responses to Resistance Type Exercise Training – Prof. van Loon](https://www.youtube.com/watch?v=Cd6wWzdxdRs&feature=youtu.be)
- It’s really, really hard to get old people to put on muscle, but it [can be done](https://www.sciencedirect.com/science/article/pii/S0531556518306673?via%3Dihub) with many months of training
- But [another study](https://pubmed.ncbi.nlm.nih.gov/27358494/) showed that just one week of bedrest and you can lose all of that muscle gained
- “They did this Herculean effort to shepherd these people through strength training for a long period of time with full support” … only to lose it in one week

**Upshot**:

*Generally speaking…*

- If you stop training for one full month, you may lose up to 10-20% of your exercise capacity
- But it really depends where you’re starting—
  - If you’re well-trained for a short period of time, you’ll lose it quickly.
  - If you haven’t been training, then resting doesn’t make any difference
  - And if you’re well-trained over a long period of time, then you have structural adaptations that are going to take a lot longer to disappear

*It’s okay to take a break*

- This is not a recommendation that you should never take a break from exercise
- “Y*ou shouldn’t be terrified of missing a day, but you should be terrified of bed rest*.”

## Strength or muscle mass—which is more important? [1:47:00]

**What matters more, strength or muscle mass?**

- Alex recently wrote an [article](https://www.outsideonline.com/2263346/delay-death-lift-weights) that mentioned a [study](https://www.ncbi.nlm.nih.gov/pubmed/28991040) which put together six different cohorts with a total of about 50,000 people
  - They found that strength was actually a better predictor than muscle mass for all-cause mortality
  - In other words, it’s better to have the functionality than it is to have a bunch of muscle if you’re not good at using it
- For a lot of people, they have enough muscle mass, but they’re untrained and the neuromuscular connections are not optimized, says Alex

![](https://peterattiamd.com/wp-content/uploads/2021/03/strength-better-than-mass-hutchinson-1024x706.png)

**Figure 1**. LLM=low muscle mass; LMS-low muscle strength. The reference group, on the right side in the front, is those without either condition. In comparison, those with both conditions were 2.66 times as likely to die during the study. Having low muscle mass but normal strength, on the other hand, didn’t seem to be such a bad thing. [[souce](https://www.outsideonline.com/2263346/delay-death-lift-weights)]

*Peter’s take*:

- Both strength and muscle mass are important for different reasons
- Strength is important for functional things
- Grip strength is just [highly correlated with survival](https://www.stack.com/a/grip-strength-life-span), for example
- Getting up out of the chair, getting up off the floor
- Muscle mass is important for storing glycogen
- The physiologic things like glycogen stores and glucose disposal and glucose homeostasis and insulin sensitivity

## Avoiding acute and chronic injuries from exercise [1:48:45]

Alex has [written](https://www.outsideonline.com/2411261/injury-prevention-acute-chronic-workload-ratio-research) [a lot](https://www.outsideonline.com/2414066/overtraining-theories-study-oxidative-stress) about injuries in terms of different competing theories around injury

- 80% of running injuries are a result of what he would call “training errors”
- Most of what we need to worry about is **doing too much too soon**

> “For people who are starting out or ramping up an exercise program, patience is so important and that understanding that you will probably overestimate what you can accomplish in the short term. And you’ll probably underestimate what you can accomplish in the longterm.” —Alex Hutchinson

You can gain metabolic fitness more quickly than you can alter the structure of your joints and ligaments

**Takeaway message**:

- It’s not about the magical gadget or the new way of running or the measuring device.
- Just be patient, be smart.
- Err on the side of safe until you start getting a better handle on which aches and pains are normal and which ones aren’t

⇒ See Alex’s article: [The New Training Rule for Injury Prevention](https://www.outsideonline.com/2411261/injury-prevention-acute-chronic-workload-ratio-research)

**Acute to chronic workload ratio**

- Runners used to be taught the 10% rule which said never increase your mileage more than 10% (Basically, the idea is trying to avoid the too much too soon problem)
- [Acute to chronic workload ratio](https://www.outsideonline.com/2411261/injury-prevention-acute-chronic-workload-ratio-research) is a more sophisticated version of that rule:
  - How much are you doing now versus how much is your body used to?
  - What’s your weekly load?
  - What’s your average weekly load over the last four weeks?
  - If you’ve done something for four weeks in a row and you’re feeling okay, then you can kind of assume that your body’s able to handle that load
- It can also be a quick way of seeing if there’s any deviations:
- For example, in one week if you do 50% more than your four-week average, then that bad sign
- It doesn’t mean you’re going to get injured, but it’s good to have it as one input into your larger matrix of things you’re considering—
  - Do I feel any aches and pains?
  - What’s my absolute load, not just the ratio, but is this more than I’ve ever done before?
- Keeping track of how hard you’re going now versus how hard you’ve been going in the previous month, is useful
- Some people who say that, “The supposed predicted value of acute to chronic workload ratio is a statistical artifact.”
- But this is not about statistical predictive power. It’s just about keeping an eye on trends related to whether you’re way out of whack with what you’ve been doing before”

**General rule**:

- If you’re 20% higher, then that’s a time to start making sure you know what you’re doing
- So, unless you have some compelling reason to think that you can handle that, be cautious and ideally back off

## High intensity interval training: Evolution of the Tabata protocol, pros and cons of HIIT training, and how it fits into a healthy exercise program  [1:54:15]

For someone who is not a specific athlete who’s training to run the mile or the marathon, but the person who’s trying to be healthy… *How much can intervals help in terms of efficiency?*

- Using the Tabata interval as an example, you’re going all out for 20 seconds, resting for 10, and repeating it eight times
- In Alex’s research for Endure, he says it seems like going “out all” for 20 seconds isn’t truely possible
- Even [Usain Bolt](https://en.wikipedia.org/wiki/Usain_Bolt) doesn’t go “all out” in a 200 meter race, he’s pacing himself to some degree

**Where do intervals fit into a healthy exercise routine?**

- They are super important, says Alex

*History*:

- Circa 2008, high-intensity intervals started to be a big buzzword
  - But Alex remembers thinking,  “*How is this a buzzword? That’s how runners train.”*
- [One study](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0154075) by the McMaster Group looked at 10 sprints per minute
  - Alex thought to himself, “*That’s the Roger Bannister. That’s how he broke the four-minute mile in 1954. What’s new about this?*”

**What are the limits of how much it’s possible to shrink the sprint intervals and still get benefit?**

Two general points Alex makes:

1—As a runner, one thing I know is that you will never, ever run fast relative to your abilities if you don’t do interval training

2—You probably won’t run as fast as you could if you *only* do interval training

- Studies like to compare things like eight weeks of three interval workouts a week versus eight weeks of three 45 minute sustained sessions
- That’s interesting and somewhat useful to know, “*but I really don’t think that’s what is optimized*”
- It would be more useful to compare one short sprint interval session, one medium interval session, and one 45 minute session, or some portfolio
- Say you can get the same improvement in insulin sensitivity, but the mechanisms may be different if you’re doing a sprint interval session versus sustained training
- And if that is the case (two different mechanisms), maybe we should be hitting them both because presumably we’re going to get a little 1 + 1 = more than 2

> “I would 100% recommend to anyone that they should be including some form of interval training in their routine if they’re interested in health or performance.” —Alex Hutchinson

**How short can we actually make a HIIT protocol?**

A [recent study](https://journals.lww.com/acsm-msse/Abstract/9000/Inertial_Load_Power_Cycling_Training_Increases.96122.aspx) out of UT Austin by physiologist Ed Coyle

- They looked at **4 seconds** all-out sprints with 56 seconds of rest for 15 minutes
- Then they progressed to basically four seconds all-out twice a minute for 20 minutes
- The study showed improvements with this protocol

⇒ NY Times: [Can 4 Seconds of Exercise Make a Difference?](https://www.nytimes.com/2020/12/30/well/move/can-4-seconds-of-exercise-make-a-difference.html?referringSource=articleShare)

*Issue with these types of studies*:

- They’re usually comparing the intervals to doing nothing
- And is that better than sitting on the couch? Yes, of course
- But you have 40 minutes a day, the question is could I come up with a more efficient way to get a benefit?
- Next, you must think about efficacy versus effectiveness
- People like Peter and Alex enjoy exercise so much that they tend to focus on **efficacy** — i.e., what would produce the best results
- But many people don’t enjoy exercise and therefore the real-world applicability of a problem becomes its **effectiveness**
- In that sense, Peter is a bit more accepting if people are willing to do shorter interval workouts, provided they don’t get injured, rather than the “perfect” allocation of exercise
- That said, Peter is concerned that people may jump into HIIT workouts without any of the foundational strength they require for it
- “*I just hope that I can convince people that they’re better off learning to love exercise, which again, I think is why [*[*Endure*](https://www.amazon.com/Endure-Curiously-Elastic-Limits-Performance/dp/0062499866)*] is so great*.” —Peter Attia
- Alex agrees: “*It’s not about what does better in this lab context. It’s what will people do?*”

Alex’s take:

- He’s skeptical that four seconds at the intensity that you have to do those intervals is more acceptable to the average person than, say, one full minute
- The very first HIIT protocol was the [Wingate test](https://en.wikipedia.org/wiki/Wingate_test)—which is 30 seconds all out and makes people puke
- You can really suffer in those 30 seconds, says Alex
- So maybe it works in the lab, but will it work in real life?

*So what is practical?*

- Protocols like 60 seconds on, 60 second off came from the thought that it’s easier for people to accept 60 seconds *pretty hard* than it is to expect them to “imagine the homicidal drill sergeant yelling at them to get all of that out of themselves in 30 seconds”
- Because, in reality, you have to be **100% on** to get the most out of this “four-second” or “ten-second” interval stuff
- There’s a ton of debate understandably about what it is that people will actually do—
- Would they rather do 20 minutes at medium, or 40 minutes easy, or four seconds hard?
- Truthfully, people just like different things
- But the assumption that is being made by these studies which are looking at the question of how short can you make the interval? … “*I’m not sure that’s true for everyone*”

⇒ Check out Alex’s article: [Customize Your HIIT Workout Based on Your Goals](https://www.outsideonline.com/2392207/hiit-workouts-study)

## The importance of understanding why you are engaging in exercise [2:03:00]

A big challenge

- A lot of people aren’t clear on the **why they are engaging in exercise**
- If you’re thinking about the 90-year-old version of you in a chair—He needs to be able to get up—that gives you the motivation to do strength training

“*The more people can tether what it is they are doing this for to something real, it becomes a little easier to do these abstract workouts*.” —Peter Attia

- Once you stop competing in something, all this exercise stuff becomes abstract
- Frankly, the practice of medicine doesn’t do a great job communicating the why, says Peter

*⇒ Example*: Your body’s natural ability to fight off cancer when you’re fit is a much easier task than fighting cancer when you’re unfit simply based on the energetics of your immune system

- See Alex’s article: [A New Theory on Exercise’s Anti-Cancer Effect](https://www.outsideonline.com/2415412/exercise-energy-cancer-theory)

## How we can encourage better science journalism and reduce the number of  sensationalized headlines [2:05:45]

**Peter’s critical view**

- Peter has been pretty critical of most science journalists — “Truthfully, I think most of them are really bad. And I think many of them actually border on negligent. And I think they cause on some levels more harm than good to the public.”
- Most of the articles are just sensationalized headlines and lack detail
- Peter says a news story should be written with the understanding that very few people are going to go back to the primary source and read it … and this places an enormous responsibility on scientific journalism

**Alex explaining the issue with most science journalism**:

- Alex perceives the problem to be that journalism now follows the audience
- In 2006, for example, we were just at the point where news organizations were first starting to be able to see how many people clicked on a story
- This was one of the great catastrophes of journalism in some ways because it’s unhealthy for the news organizations to find out what people click on
- Example: The big newspaper in Canada is [The Globe and Mail](https://www.theglobeandmail.com/)
  - Shortly after they introduced this feature, Alex looked at the top 10 stories on the website, and three of them are about Britney Spears (or something similar)

“*To encourage good science journalism, you need people to read good science journalism.*”

*Losing trust*

- But newspapers are realizing that following the audience has turned out to be a bad move because they’ve ended up losing the trust in audience
- By giving people what they thought they wanted, you ended up basically giving them crap. And then having people recognize that they were being fed crap and then rebel against it.

**Alex’s approach**

- When he first started his sports science journalism career around 2008, he started a blog for people who were interested in the details of what the study says
- His articles started to get taken on by Runner’s World in 2012 and then moved over to Outside in 2017
- So, it turned out **there was an audience for that**

***So, how do you fix scientific journalism more broadly?***

- News organizations aren’t going to insist on scientifically qualified journalists unless there’s repercussions or feedback when there’s bad journalism
- The initial signals were the opposite—i.e., the less complicated it was and the more sensational it was, the more clicks they got

*One possible solution*: We need to move away from advertising and towards subscription-based models

§

## Selected Links / Related Material

**Alex’s book**: [Endure: Mind, Body, and the Curiously Elastic Limits of Human Performance](https://www.amazon.com/Endure-Curiously-Elastic-Limits-Performance/dp/0062499866) by Alex Hutchinson | (amazon.com) [1:15, 3:15, 9:00, 1:20:00]

**Alex’s many articles**: [3:30]

- [Outside Online](https://www.outsideonline.com/1745511/alex-hutchinson#close)
- [Runner’s World](https://www.runnersworld.com/author/4924/alex-hutchinson/)

**YouTube video of Alex at his first Olympic trials where he said he felt like he didn’t belong**:  [1996 Canadian 1500 Olympic trials](https://www.youtube.com/watch?v=8dSLUVmK1Ik) | Reid Coolsaet (youtube.com) [16:45]

**First couple books Alex read about running**: [30:30]

- [Lore of Running](https://www.amazon.com/Lore-Running-4th-Timothy-Noakes/dp/0873229592) by Tim Noakes | (amazon.com)
- [Better Training for Distance Runners](https://www.amazon.com/Better-Training-Distance-Runners-2nd/dp/0880115300) by David Martin | (amazon.com)

**Canadian paper that Alex interned with when starting out in journalism**: [Ottawa Citizen](https://ottawacitizen.com/) | (ottawacitizen.com) [31:15]

**A review paper arguing that in some cases the lungs aren’t overbuilt and one of the situations is highly trained endurance athletes**: [Is the healthy respiratory system built just right, overbuilt, or underbuilt to meet the demands imposed by exercise?](https://pubmed.ncbi.nlm.nih.gov/32790594/) (Dempsey et al., 2020) [46:15]

**Alex’s article about Oskar Svensson**: [The Story of the Cyclist with the Highest-Ever VO2 Max](https://www.outsideonline.com/2398524/highest-ever-vo2max-cyclist-oskar-svendsen) | Alex Hutchinson (outsideonline.com) [49:15]

**Paper that published the data around the VO2 max of Oskar Svensson**: [Case Studies in Physiology: Temporal changes in determinants of aerobic performance in individual going from alpine skier to world junior champion time trial cyclist](https://pubmed.ncbi.nlm.nih.gov/31194601/) (Rønnestad et al., 2019) [52:15]

**Alex’s article reanalyzing the Oskar Svensson data including looking at his efficiency at each point during his training**: [The Story of the Cyclist with the Highest-Ever VO2 Max](https://www.outsideonline.com/2398524/highest-ever-vo2max-cyclist-oskar-svendsen) | Alex Hutchinson (outsideonline.com) [54:00]

**Alex’s article for Runner’s World analyzing the prospects for a sub 2-hour marathon**: [What will it take to run a 2-hour marathon?](https://www.runnersworld.com/uk/training/marathon/a774501/what-will-it-take-to-run-a-2-hour-marathon/) | Alex Hutchinson (runnersworld.com) [1:01:30]

**Nike’s 2017 top secret project to get a runner to break a 2-hour marathon**: [Breaking2](https://www.nike.com/running/breaking2) | (nike.com)  [1:03:45]

- Video: [Sub 2 Hour Marathon – NIKE #BREAKING2​ Attempt](https://www.youtube.com/watch?v=pN5sla8vDr4) | Runners Awesome (youtube.com)

**The 2019 sequel by INEOS held in Vienna where Kipchoge beat the 2-hour mark**: [*Ineos 1:59 Challenge*](https://en.wikipedia.org/wiki/Ineos_1:59_Challenge) | (wikipedia.org)  [1:07:15]

- Video: [1:59:40! Kipchoge runs historic first sub-2 hour marathon](https://www.youtube.com/watch?v=IAxYQJewtbU)  | NBC Sports (youtube.com)

**Secretariat’s winning times at Belmont may be the pinnacle of horse racing**: [1973 Belmont Stakes](https://en.wikipedia.org/wiki/1973_Belmont_Stakes) | (wikipedia.org) [1:19:30]

**2007 paper debating whether dehydration impairs endurance performance**: [Does Dehydration Impair Exercise Performance?](https://www.researchgate.net/publication/6078653_Does_Dehydration_Impair_Exercise_Performance) (Sawka and Noakes, 2007) [1:20:45]

**Tim Noakes’s central governor model**: [Central governor](https://en.wikipedia.org/wiki/Central_governor) | (wikipedia.org) [1:22:00]

**The Reverse J-Curve for Exercise hypothesis**: [Training for Longevity: The Reverse J-Curve for Exercise](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7431070/) (O’Keefe et al., 2020) [1:30:00]

**The Cooper Clinic study which initially said too much exercise could lead to higher mortality — in published paper it instead mentioned the effectiveness of just 5 to 10 minutes a day of exercise**: [Leisure-Time Running Reduces All-Cause and Cardiovascular Mortality Risk](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4131752/) (Lee et al., 2014) [1:30:45]

**The Copenhagen study about volume of exercise and longevity**: [Dose of jogging and long-term mortality: the Copenhagen City Heart Study.](https://pubmed.ncbi.nlm.nih.gov/25660917/) (Schnohr et al., 2015) [1:33:15]

**Alex’s article critical of the data on the reverse J curve of exercise**: [Don’t Worry About Exercising Too Much](https://www.outsideonline.com/2358586/dont-worry-about-exercising-too-much) | Alex Hutchinson (outsideonline.com) [1:34:45]

Another good article by alex: [The Runner’s Heart](https://www.christinefennessy.com/uploads/8/3/2/7/83277728/rw1016_heart.pdf)

**Peter’s podcast with James O’Keefe discussing the idea of excessive exercise**: #134 – James O’Keefe, M.D.: [Preventing cardiovascular disease and the risk of too much exercise](https://peterattiamd.com/jamesokeefe/) | Peter Attia (peterattiamd.com) [1:40:15]

**A long-term prospective study suggesting exercise with a social element produced the best longevity effects**: [Various leisure-time physical activities associated with widely divergent life expectancies: The Copenhagen City Heart Study](https://www.sciencedirect.com/science/article/abs/pii/S002561961830538X) (Schnohr et al., 2018) | [53:00]

**Study showing that elderly individuals can add muscle with a lot of hard work with resistance training**: [Muscle mass and strength gains following 6 months of resistance type exercise training are only partly preserved within one year with autonomous exercise continuation in older adults](https://www.sciencedirect.com/science/article/pii/S0531556518306673?via%3Dihub) (Snijdersa et al., 2019) [1:45:00]

[**Luc van Loon**](https://www.maastrichtuniversity.nl/l.vanloon)**’s bedrest study showing just one week of bedrest resulted in 2.6 kilograms of muscle loss:** [One Week of Bed Rest Leads to Substantial Muscle Atrophy and Induces Whole-Body Insulin Resistance in the Absence of Skeletal Muscle Lipid Accumulation](https://pubmed.ncbi.nlm.nih.gov/27358494/) (Dirks et al., 2016) [1:45:00]

**Study showing strength was actually a better predictor of longevity than muscle mass**: [Associations of Muscle Mass and Strength with All-Cause Mortality among US Older Adults](https://www.ncbi.nlm.nih.gov/pubmed/28991040) (Li et al., 2018) [1:47:00]

- *Alex’s article which mentioned the above study*: [To Delay Death, Lift Weights](https://www.outsideonline.com/2263346/delay-death-lift-weights) | Alex Hutchinson (outsideonline.com) [1:47:00]

**Alex’s article discussion acute vs chronic injuries**: [The New Training Rule for Injury Prevention](https://www.outsideonline.com/2411261/injury-prevention-acute-chronic-workload-ratio-research) | Alex Hutchinson (outsideonline.com) [1:48:45]

**80% of running injuries are a result of what Benno Nigg would call training errors**: [The Seven Pillars of Running Wisdom](https://www.runnersworld.com/training/a20861889/the-seven-pillars-of-running-wisdom/) | Alex Hutchinson (runnersworld.com) [1:49:00]

**Study by the McMaster Group studying 10 intervals per minute (what Roger Banniser did, per Alex)**: [Twelve Weeks of Sprint Interval Training Improves Indices of Cardiometabolic Health Similar to Traditional Endurance Training despite a Five-Fold Lower Exercise Volume and Time Commitment](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0154075) (Gillen et al., 2016) [1:56:00]

**Study looking at four seconds all-out sprints with 56 seconds of rest**: [Inertial Load Power Cycling Training Increases Muscle Mass and Aerobic Power in Older Adults](https://journals.lww.com/acsm-msse/Abstract/9000/Inertial_Load_Power_Cycling_Training_Increases.96122.aspx) (Allen et al., 2020) [1:58:45]

**NY Times covering the study investigating 4 second sprint intervals**: [Can 4 Seconds of Exercise Make a Difference?](https://www.nytimes.com/2020/12/30/well/move/can-4-seconds-of-exercise-make-a-difference.html?referringSource=articleShare) | Gretchen Reynolds (NYTimes.com) [1:58:45]

**The first HIIT protocol was Wingate test which included 30 secs “all out” sprints**: [Wingate test](https://en.wikipedia.org/wiki/Wingate_test)  | (wikipedia.org) [2:01:15]

§

## People Mentioned

- [Matt Centrowitz](https://en.wikipedia.org/wiki/Matt_Centrowitz) [25:15]
- [Matt Centrowitz Jr](https://en.wikipedia.org/wiki/Matthew_Centrowitz_Jr.) [25:15]
- [Tim Noakes](https://twitter.com/proftimnoakes?lang=en) [30:30, 1:20:45]
- [Sid Mukherjee](https://en.wikipedia.org/wiki/Siddhartha_Mukherjee) [36:30]
- [Michael Phelps](https://en.wikipedia.org/wiki/Michael_Phelps) [37:00]
- [A.V. Hill](https://en.wikipedia.org/wiki/Archibald_Hill) [39:30]
- [Oskar Svensson](https://en.wikipedia.org/wiki/Oskar_Svensson) [44:30]
- [Bjorn Daehlie](https://en.wikipedia.org/wiki/Bj%C3%B8rn_D%C3%A6hlie) [50:30]
- [Matt Carpenter](https://en.wikipedia.org/wiki/Matt_Carpenter_(runner)) [51:30]
- [Kílian Jornet](https://en.wikipedia.org/wiki/K%C3%ADlian_Jornet_Burgada) [51:30]
- [Steve Prefontaine](https://en.wikipedia.org/wiki/Steve_Prefontaine) [51:30]
- [Bradley Wiggins](https://en.wikipedia.org/wiki/Bradley_Wiggins) [53:30]
- [Euclid Kipchoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge) [1:01:00]
- [Dennis Kimetto](https://en.wikipedia.org/wiki/Dennis_Kipruto_Kimetto) [1:03:00]
- [Belayneh Densamo](https://en.wikipedia.org/wiki/Belayneh_Dinsamo) [1:03:15]
- [Roger Bannister](https://en.wikipedia.org/wiki/Roger_Bannister) [1:15:00, 1:56:00]
- [Emil Zátopek](https://en.wikipedia.org/wiki/Emil_Z%C3%A1topek) [1:15:30]
- [Jim Ryun](https://en.wikipedia.org/wiki/Jim_Ryun) [1:16:30]
- [Bobby Timmons](https://www.nytimes.com/2015/08/06/sports/bob-timmons-91-a-demanding-coach-who-developed-a-star-runner-is-dead.html) [1:17:45]
- [Secretariat](https://en.wikipedia.org/wiki/Secretariat_(horse)) [1:18:45]
- [James O’Keefe](https://peterattiamd.com/jamesokeefe/) [1:28:30, 1:40:15]
- [Luc van Loon](https://www.maastrichtuniversity.nl/l.vanloon) [1:44:45]
- [Benno Nigg](https://contacts.ucalgary.ca/info/kn/profiles/196-1265) [1:49:00]
- [Izumi Tabata](https://en.wikipedia.org/wiki/Izumi_Tabata) [1:54:30]
- [Usain Bolt](https://en.wikipedia.org/wiki/Usain_Bolt) [1:55:30]
- [Ed Coyle](https://education.utexas.edu/faculty/edward_coyle) [1:58:45]

§

![](https://peterattiamd.com/wp-content/uploads/2021/02/1x1-hutchinson.jpg)

##### Alex Hutchinson, Ph.D

Alex is a sports science journalist, author of the book [ENDURE: Mind, Body, and the Curiously Elastic Limits of Human Performance](https://www.amazon.com/Endure-Curiously-Elastic-Limits-Performance/dp/0062499866), and former competitive runner for the Canadian national team. He currently writes the [Sweat Science](https://www.outsideonline.com/1745511/alex-hutchinson) column for Outside Online. Prior to his journalism career, Alex acquired a Ph.D. from the University of Cambridge. He spent a few years as a postdoctoral researcher with the U.S. National Security Agency working on quantum computing and nanomechanics while simultaneously competing as a middle- and long-distance runner for the Canadian national team.