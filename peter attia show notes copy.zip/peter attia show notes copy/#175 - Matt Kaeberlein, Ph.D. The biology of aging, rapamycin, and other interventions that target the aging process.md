# #175 – Matt Kaeberlein, Ph.D.: The biology of aging, rapamycin, and other interventions that target the aging process

**Source:** [https://peterattiamd.com/mattkaeberlein2/](https://peterattiamd.com/mattkaeberlein2/)

---

##### Check out more content with expert, Matt Kaeberlein, Ph.D.:

- *(Aug 20, 2018)* [Rapamycin and dogs — man’s best friends? — living longer, healthier lives and turning back the clock on aging and age-related diseases](/mattkaeberlein/)
- *(Sep 13, 2021)* [The biology of aging, rapamycin, and other interventions that target the aging process](/mattkaeberlein2/)
- *(May 16, 2022)* [AMA #35: “Anti-Aging” Drugs — NAD+, metformin, & rapamycin](/ama35/)

Matt Kaeberlein is globally recognized for his research on the biology of aging and is a [previous guest](https://peterattiamd.com/mattkaeberlein/) on The Drive. In this episode, Matt defines aging, the relationship between aging, chronic inflammation, and the immune system, and talks extensively about the most exciting molecules for extending lifespan. He discusses the current state of the literature of testing rapamycin (and rapalogs) in animals and humans, including Matt’s Dog Aging Project, and provides insights into how we can improve future trials by conceptualizing risk, choosing better endpoints, and working with regulators to approve such trials. He also examines the connection between aging and periodontal disease, biomarkers of aging, and epigenetic clocks. Finally, they explore some of the biological pathways involved in aging, including mTOR and its complexes, sirtuins, NAD, and NAD precursors.

\*[WATCH PODCAST ON YOUTUBE](https://youtu.be/_vsNw-OCciU)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/mattkaeberlein2/the_Drive_public.png)

Play

#175 - Matt Kaeberlein, Ph.D.: The biology of aging, rapamycin, and other interventions that target the aging process

#175 - Matt Kaeberlein, Ph.D.: The biology of aging, rapamycin, and other interventions that target the aging process

1x15s30s

0:002:40:39

## We discuss:

- The various definitions of aging [3:25];
- The relationship between disease and the biology of aging [16:15];
- Potential for lifespan extension when targeting diseases compared to targeting biological aging [22:45];
- Rapamycin as a longevity agent and the challenges of targeting the biology of aging with molecules [32:45];
- Human studies using rapalogs for enhanced immune function [39:30];
- The role of inflammation in functional declines and diseases of aging [50:45];
- Study showing rapalogs may improve the immune response to a vaccine [56:15];
- Roadblocks to studying gero-protective molecules in humans [1:01:30];
- Potential benefits of rapamycin for age-related diseases—periodontal, reproductive function, and more [1:12:15];
- Debating the ideal length and frequency of rapamycin treatment for various indications like inflammation and longevity [1:21:30];
- Biomarkers of aging and epigenetic clocks [1:29:15];
- Prospects of a test that could calculate biological age [1:37:45];
- The Dog Aging Project testing rapamycin in pet dogs [1:42:30];
- The role of the mTOR complexes [1:58:30];
- mTor inhibitor called Torin2, mitochondrial disease and other potential pathways [2:09:45];
- Catalytic inhibitors, sirtuins, and NAD [2:19:15];
- NAD precursors: help or hype? [2:28:15]; and
- More.

§

## Show Notes

## The various definitions of aging [3:25]

- Last time Matt was [on the podcast](https://peterattiamd.com/mattkaeberlein/), they talked about [rapamycin](https://en.wikipedia.org/wiki/Sirolimus) and the mammalian target of rapamycin ([mTOR](https://en.wikipedia.org/wiki/MTOR)) [pathway](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4214394/)
- Peter finds Matt to be very thoughtful across longevity topics, so wants to have an even broader discussion today
- What’s the best way to define aging?
  - It varies depending on the situation
  - Can be molecular: the types of molecular damage and their consequences
    - [mitochondrial](https://en.wikipedia.org/wiki/Mitochondrion) dysfunction, [telomere](https://en.wikipedia.org/wiki/Telomere) shortening, [cellular senescence](https://en.wikipedia.org/wiki/Cellular_senescence), etc. all happen at the cellular and molecular level and contribute to functional decline and diseases
  - Matt has begun to develop a greater appreciation for a **functional** definition of aging
    - There are functional declines across every organ system in the body
    - Things like frailty are an important component of defining aging
  - Other aspects of aging, like the social component, intersect with the biological part and are as important to quality of life
- Over time, scientists have established the [nine hallmarks of aging](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3836174/) [*see special supplementary section for details*]

![](https://peterattiamd.com/wp-content/uploads/2021/09/f1-mattk2-1024x656.png)

**Figure 1. The Nine Hallmarks of Aging.** Image credit: [López-Otín et al. 2013](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3836174/)

- There are also outward expressions of these processes: frailty, diseases like cancer, cardiovascular disease, and dementia
- Peter asks if disease is the link between cellular and phenotypic declines
  - Matt says he thinks of it the other way around: the functional declines often precede  disease and are as (or more) important from a quality of life perspective as we get older
- These functional declines happen in every organ and tissue, often long before one is diagnosed with any disease
  - At 50, Matt has not been diagnosed with any age-related diseases, but he has a lot of functional declines compared to his 25-year-old self
  - Functional declines are often the first observable signs of aging
  - Two points:
    - we really don’t have a good understanding of when the pathology of the disease is no longer normative aging
    - we have some understanding of the molecular cellular mechanisms that drive biological aging and contribute to our risk of developing age-related diseases that are major causes of death and disability
  - But at some point, disease pathology is not necessarily at a molecular mechanistic level and becomes something different
- There’s not yet a consensus whether rapamycin affects biological aging

> “It’s not clear that the same intervention [that affects biological aging] is going to be effective once a pathology progresses to the point that it’s not the same mechanism anymore. So I think that’s a really important point that sometimes gets lost in this discussion of aging and disease.” —Matt Kaeberlein

Peter asks how this point can be illustrated with one of the “big three” age-related diseases: [atherosclerosis](https://en.wikipedia.org/wiki/Atherosclerosis), cancer, and dementia

- Matt says cancer provides a good illustration of the concept
  - mTOR, the protein that rapamycin inhibits, plays a fundamental role in regulating cell division and cell cycle
  - if you inhibit mTOR in a non-cancerous cell enough, you will stop the cell cycle
  - but some cancer-causing mutations will not respond to the mTOR inhibition
  - so rapamycin will be quite effective at preventing cancer before a mutation happens, but afterwards the cell will not respond to rapamycin anymore an the cell cycle will not be affected
  - the mechanism has changed, so the mechanisms that are important for preventing cancer before that mutation occurred are different from the mechanism that might halt the growth of that cancer after the mutation has occurred
- Peter says it’s similar to nutrition: as far as there is an optimal nutrition program to prevent a condition, it might not be the same as the optimal nutritional strategy to treat the disease once it develops
  - Peter thinks a ketogenic diet is probably the best treatment for someone with type 2 diabetes, which is essentially a carbohydrate intolerance disorder
  - But one likely does not need to be on a ketogenic diet to prevent diabetes

**Normative aging vs. disease [14:30]**

- [Cynthia Kenyon](https://en.wikipedia.org/wiki/Cynthia_Kenyon) [has observed](https://www.ucsf.edu/news/2007/01/103427/aging-disease-conversation-cynthia-kenyon) that using a disease-based definition for aging is not quite the right framework because it’s not clear at what point a disease is a disease
  - If everyone who lives to a certain age has cancer, it’s become normative aging rather than a disease
  - 0.0004% of people live to 100 because they did not succumb to a disease – what does that say about their normative aging process vs. everyone else’s?
- Peter reflects, “I literally still don’t think I understand what aging is”

> “I don’t think I will ever understand aging fully. And I don’t think the field will. … But I also believe that we don’t have to understand it fully to be able to have an impact on the biology of aging through interventions. … I feel like I’ve got a conceptual flavor for what aging is … and enough information that I can come up with rational approaches to target those mechanisms … that should have an impact on health and longevity. … And then we have to test those predictions.” —Matt Kaeberlein

## The relationship between disease and the biology of aging [16:15]

- The relationship between disease and the biology of aging is underappreciated
  - Matt notes that people often debate whether the biology of aging (the molecular hallmarks) cause diseases like [Alzheimer’s disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease), cancer, and cardiovascular disease
  - Matt thinks the data show that they do make a causal contribution to disease, but he also thinks “it just doesn’t matter whether aging causes disease or creates a permissive physiological state for disease”
  - Biological age is the single greatest risk factor for every major cause of death and disability in developed countries
  - The point is to find the most effective way to prevent those diseases and keep people healthier longer
  - Whether aging is a disease or whether aging causes disease are not the right questions to ask
- Peter used to give talks in which he’d ask the audience what is the greatest risk factor for atherosclerosis is
  - People would guess things like smoking, high blood pressure, [apoB](https://en.wikipedia.org/wiki/Apolipoprotein_B), [LDL-C](https://en.wikipedia.org/wiki/Low-density_lipoprotein), inflammation, etc.
  - But the greatest risk factor is age
  - A 70-year-old with “everything perfect about them” has a worse 10-year predicted mortality than a 20-year-old “train wreck”
- Of the “big three,” we have a far better understanding of what drives atherosclerosis and how to prevent it than we do cancer and Alzheimer’s disease
  - Lowering apoB (either through diet or pharmacologically) and improving metabolic health (regulating glucose, insulin lowering apoB) are probably the best ways to reduce risk
  - But these things are not directly targeting the nine hallmarks of aging (although they do so indirectly)
  - Giving a patient a [PCSK9](https://en.wikipedia.org/wiki/PCSK9#As_a_drug_target) inhibitor, which specifically targets a protein that allows the body to clear more apoB particles out of circulation, is not targeting one of the nine pillars, but it has a measurable impact on reducing their risk of disease

> “In the end, that’s the part that I think is hard for some people to understand within the aging community, is that you can still target metrics of a disease specifically without going after a hallmark.” —Peter Attia

- Matt says we focus so much on the hallmarks because it’s easy, but they are not necessarily complete surrogates for the molecular mechanisms of aging
  - It makes sense to intervene at the hallmark level upstream of disease or at the level of the bridge that links the hallmarks to disease
  - But you wouldn’t literally impact the biology of aging at all

> “For many diseases of aging, there comes a point where the pathology of the disease is not normative aging anymore. And so you can quite successfully treat or cure a disease of aging in an individual without impacting the biology of aging.” —Matt Kaeberlein

- Almost exclusively, what is done clinically is to alleviate the symptoms of the disease or cure the disease
  - You don’t need to affect the biology of aging to do either of these things successfully, but …

> “Impacting the biology of aging is going to be a much more effective and efficient approach from the overall health perspective. … I think an important point to make is that if you don’t actually confront the biology of aging, you’re really only impacting that one disease, …but you haven’t done anything to the biology of aging. …You still have all of these other functional declines and diseases of aging that are increasing essentially exponentially as you’re getting older.” —Matt Kaeberlein

- So focusing on a cure or symptom reduction for a specific disease will have a small overall impact on health and longevity

## Potential for lifespan extension when targeting diseases compared to targeting biological aging [22:45]

- [Jay Olshansky](https://en.wikipedia.org/wiki/S._Jay_Olshansky) ran numbers on potential lifespan extension
  - if we had cures for all cancers, life expectancy for a typical 50-year-old American woman would increase by roughly 3 years
  - If we could cure heart disease, also increase life expectancy by 3 years or so
  - Curing both is roughly additive and increase life expectancy by about 7 years
- Targeting biological aging is still theoretical in humans
  - but extrapolating from a dozen or so interventions that increase lifespan in lab mice by roughly 15-30%, we could theoretically increase the human life span by 20 years
  - and also likely to improve healthspan and quality of life by slowing all of the functional declines of aging simultaneously
- It’s important to recognize the big difference in impact
  - 19th-20th century medicine was the “disease first” approach
  - Hopefully 21st century medicine will be able to target the biology of aging
- Peter says he’d love to have Jay on the podcast
- But, although he agrees with the spirit of Jay’s analysis, he doesn’t agree with his numbers: “his analysis is very actuarial, but it’s not actually very biological”
  - Jay’s analysis considers each disease independently
  - but in actuality, disease risk would be interrelated
  - For example, if you have eliminated cardiovascular disease, you have also significantly reduced inflammation and the burden of microvascular disease
  - Matt says the math may be reasonably close for cancer
- Peter agrees that disease-based approach will not be nearly as effective as targeting the foundation / basic biology of aging
- The work of [Nir Barzilai](https://en.wikipedia.org/wiki/Nir_Barzilai) and [Tom Perls](https://www.bumc.bu.edu/busm/profile/thomas-perls/) with centenarians
  - They don’t live longer with chronic diseases, they get them later, which is not what Peter would have guessed
  - They don’t seem to have any enhanced protection from a disease once they get it (“when they get cancer, they’re just as hosed as the rest of us”)
  - But they do have a [phase shift](https://www.mathsisfun.com/algebra/amplitude-period-frequency-phase-shift.html) in that they get the diseases 20-30 years later than average
  - So Peter thinks that “the sooner you begin prevention, the more you can mimic the centenarian”
- We don’t fully understand why people with increased longevity live longer, but we know a few factors
  - more likely to have [APOE](https://en.wikipedia.org/wiki/Apolipoprotein_E) e2 versus e3 or e4
  - less likely to have [APOC3](https://en.wikipedia.org/wiki/Apolipoprotein_C-III), high regulation versus low
  - related to epigenetic modulation
- It’s very difficult to study the biology of aging in humans
- In clinical trials you pick a disease and a clear, targeted endpoint
  - That’s very difficult if your endpoint is something like nutrient sensing
- Matt says it’s a challenge to figure out how to test in humans the interventions that work in lab animals
  - There is a genetic component to being a centenarian, probably around 25-30%
  - they tend to not have the high risk genetic variants for Alzheimer’s disease, certain types of cancer, heart disease, etc.
  - There are other factors (environmental and perhaps luck) that are poorly understood
- But why don’t we see variants in longevity genes like [SIRT6](https://en.wikipedia.org/wiki/Sirtuin_6), mTOR, or [FOXO](https://en.wikipedia.org/wiki/FOX_proteins) that allow people to live to 180?
  - We can do the equivalent in mice or the [nematode](https://en.wikipedia.org/wiki/Nematode) (roundworm) [*Caenorhabditis elegans*](https://en.wikipedia.org/wiki/Caenorhabditis_elegans)
  - Peter points out that, although it has a weak effect on longevity, the FOXO3A variant [is increased](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2650329/) in centenarians
- So far the effects of genetic variation tend to be small
  - Matt doesn’t think it’s because humans are fundamentally different from mice
  - He thinks it’s because their effects could be dangerous
  - For example, even in mice, strong effect variants in mTOR are incompatible with life and development
  - Humans with these variants might not survive through gestation or might end up sterile
  - Matt hypothesizes that there’s a strong selective pressure against variants that might allow people to live until 160-170
  - The lab mice that survive 25-30% longer are “all significantly defective from an evolutionary perspective,” so we’re not likely to see such mutations in people
- But doesn’t mean that we can’t intervene in key pathways to have an impact on health and longevity

## Rapamycin as a longevity agent and the challenges of targeting the biology of aging with molecules [32:45]

- 15 years ago, Matt would not have thought we could slow aging in elderly mice; he would assume we’d have to start interventions at 6 months
  - Some interventions can actually be initiated in middle or even late age in mice – not just slowing decline but reversing it
    - There is a strong case for caloric restriction
    - Giving rapamycin to an elderly mouse makes it functionally younger and extends lifespan
- Peter notes that you would not want to give rapamycin to still-developing children and would need to wait until at least age 25
  - A natural variation that mimicked the effects of rapamycin probably not be selective because it can’t be adjusted like a drug dose can
  - We don’t know what the optimal treatment period to get the largest benefits is
  - All interventions carry some risk, and even with rapamycin we still don’t really know much about the risk (in part because we haven’t had long-term controlled clinical trials at multiple doses, multiple strategies of intermittent versus continuous treatment, etc.)
- Some people (perhaps like Matt and Peter) who self-experiment with rapamycin think that once a week rather than dosing is better and also take it in cycles (take it for 3 months and then not for 6 months)
  - But that’s a guess – there’s not much data to back it up in the absence of long-term, large-scale controlled clinical trials
  - There is not yet a good strategy for how to answer these questions in a clinical setting
- Peter says an even bigger problem is that we run clinical trials on people who are at very high risk or who already have a disease
  - But if we really want to find out how geroprotective certain molecules are (e.g., metformin, rapamycin, or canagliflozin), we need to follow people before they have the disease
    - First, our current regulatory environment is unlikely accept that risk (“I would love to see the [Institutional Review Board](https://en.wikipedia.org/wiki/Institutional_review_board) (IRB) submission that says, ‘We’re going to test rapamycin in healthy 50-year-olds whose ten-year risk of death is less than 1%’”)
    - Second, it’s not really possible logistically to follow people in a study for 50 years, so we would need to have really good biomarkers of aging
- Peter has been cycling on and off taking rapamycin weekly for 2.5 years
  - He has played around with his dose (has varied from 5-8 mg once a week)
  - But he’s flying blind
  - He uses dosing and frequency data from [Joan Mannick](https://www.linkedin.com/in/joan-mannick-8089a614/) and [Lloyd Klickstein](https://www.linkedin.com/in/lloyd-klickstein-69b26870/)‘s [2014 paper](https://pubmed.ncbi.nlm.nih.gov/25540326/) using [everolimus](https://en.wikipedia.org/wiki/Everolimus), which is reasonably similar to rapamycin
  - He deduced that 5 mg was about the right balance between side effects and efficacy
  - But the ITP studies use continuous administration of rapamycin, so it’s hard to compare
  - And it’s hard to know what to make of the “remarkable results regardless of when it’s initiated”

## Human studies using rapalogs for enhanced immune function [39:30]

![](https://peterattiamd.com/wp-content/uploads/2021/09/f2-mattk2-1024x425.png)

**Figure 2. Phases of a Clinical Trial**.  Image credit: [ILD Collaborative](https://www.ildcollaborative.org/resources/phase-iv-ipf-clinical-trials)

- The [Phase III](https://en.wikipedia.org/wiki/Phases_of_clinical_research) clinical trial at reSTORbio (now [Adicet Bio](https://www.adicetbio.com/about/)) has not been published yet, but it failed
- The [2014 paper by Mannick / Klickstein paper](https://www.researchgate.net/publication/270002631_mTOR_inhibition_improves_immune_function_in_the_elderly) was done when they were both at Novartis
  - Studied the effects of everolimus
  - Everolimus is known as a [rapalog](https://en.wikipedia.org/wiki/MTOR_inhibitors#Rapamycin_and_rapalogs) because it is a derivative of rapamycin
  - It has the exact same mechanism as rapamycin biochemically
  - It was a Phase II clinical trial to determine whether a six-week treatment with everolimus could boost healthy older adults’ response to an influenza vaccine
  - This study was based on a [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4020596/) in Pan Zheng’s lab at the University of Michigan which showed that when elderly mice were treated with rapamycin for 6 weeks, it enhanced the ability of a flu vaccine to protect the mice against the lethal dose of influenza

*⇒ Check out the episode of The Drive with Joan Mannick:* [*#123 – Joan Mannick, M.D. & Nir Barzilai, M.D.: Rapamycin and metformin—longevity, immune enhancement, and COVID-19*](https://peterattiamd.com/joanmannick-nirbarzilai/)

**Rapalogs and the immune system**

- [Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3883080/) that provided the basis for human trials (Matt calls it his favorite)
  - Groups of old and young mice
  - Got the influenza vaccine and then, 2 weeks later, a dose of influenza that would be lethal if they had not been vaccinated
  - All of the young mice had a vaccine response and were protected
  - Half the elderly mice got 6 weeks of rapamycin treatment and half did not
  - About 2/3 of the older mice not given rapamycin did not have a sufficient response to the vaccine
  - But 100% of the elderly mice given rapamycin had a full vaccine response
  - “So at least for that measure of immune function, rapamycin fully restored the immune system back to that of a youthful immune system”
  - Matt is not sure if it was a memory B cell or a T cell response
- Peter points out that this data has implications for what we’re seeing with COVID vaccination, which is still poorly understood
  - Some people with naturally acquired COVID have no circulating [IgG](https://en.wikipedia.org/wiki/Immunoglobulin_G) within 6 months
  - We do not know if they have [memory B cells](https://en.wikipedia.org/wiki/Memory_B_cell) or [memory T cells](https://en.wikipedia.org/wiki/Memory_T_cell) and thus an immune response to COVID
  - Peter is guessing they will still have an immune response without circulating IgG
- Matt points out that it’s not just one simply mechanism that’s likely involved with rapamycin and everolimus
  - Joan Mannick has published [data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6810249/) showing that everolimus and another mTOR inhibitor called RTB101 boost antiviral gene expression
  - And at least in mice but probably also in humans, rapamycin reduced the chronic [sterile inflammation](https://www.nature.com/articles/nri2873) (inflammation not caused by microorganisms) of aging, whose mechanisms are still unknown

> “I think it’s probably multiple things that are going on that can impact immune function in different ways when you treat with rapamycin, especially in the context of an old animal or an old person.” —Matt Kaeberlein

- Lessons from the Mannick / Klickstein [paper](https://pubmed.ncbi.nlm.nih.gov/25540326/)
  - Took 65-year-olds and divided them into four groups of roughly 80 people each: placebo group, 1 mg/week, 20 mg/week, and 5 mg/week
  - Treated them for 6 weeks and then 2 weeks after treatment they got a flu vaccine
  - Obviously can’t give a lethal dose to humans like they did with the mice, so they used measurements like antibody titers
  - It looked like those who got everolimus responded better to the vaccine than the control group, particularly in the 5 mg/week group
  - There was little difference in side effects between the different everolimus groups (especially the 5 mg/week) and the placebo group
  - This, the first Phase II trial, is why we’re guessing that people can benefit from once a week dosing with few side effects
  - Peter says that among those who are very interested in mTOR, like Matt and himself and [Dave Sabatini](https://biology.mit.edu/profile/david-sabatini/), this was an interesting and landmark paper
- Until this study, the only human application for rapamycin had been immune suppression
  - It is given to transplant patients (along with other drugs like [cyclosporine](https://medlineplus.gov/druginfo/meds/a601207.html), [prednisone](https://medlineplus.gov/druginfo/meds/a601102.html), and [mycophenolate mofetil](https://www.drugs.com/mtm/mycophenolate-mofetil-oral-injection.html) (MMF)) to suppress the immune system
- When the [first study](https://pubmed.ncbi.nlm.nih.gov/19587680/) from the National Institute of Aging’s [Interventions Testing Program](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp) (ITP) came out in 2009, suggesting rapamycin could be a tool to increase longevity in mice, it seemed unlikely to be applicable to humans
- How do we reconcile the data from Joan’s paper with the fact that rapamycin is at least in theory immunosuppressive with regard to organ transplantation?
  - Matt says that many clinicians still believe (incorrectly, he thinks) that rapamycin and rapalogs are immunosuppressants
  - It’s the dose that’s key

> “Every drug has a dose response, right? And that you can get different effects, different outcomes, different side effects, depending on the dose.” —Matt Kaeberlein

- The study used low, weekly dosing in elderly people in functional decline
  - You would not have seen a functional improvement in vaccine response in younger subjects
  - Organ transplant patients are taking rapamycin in high doses and also in conjunction with other known immunosuppressive drugs
- But Matt is not aware of any strong clinical data indicating that rapamycin alone has substantial immune suppressing effects
  - It probably does in high doses, but we don’t have the data
  - Peter wonders what data led to FDA approval of rapamycin for organ transplant patients in 1999

## The role of inflammation in functional declines and diseases of aging [50:45]

- Matt says that when we talk about the immune system we use broad terms, like saying the immune system doesn’t function as well as we age
  - That is true, but it’s not necessarily functioning at a lower level
  - In elderly people and mice, there is immune activation resulting in sterile inflammation

> [As we age,] “it’s not necessarily that the immune system is functioning less, it’s functioning inappropriately.” —Matt Kaeberlein

- The benefits of rapamycin we see in mice are likely due to tamping down the inappropriate age-related inflammation and immune system activation
  - Through mechanisms that are still unknown, rapamycin seems to be more effective at targeting the problematic part of the aberrant immune response while still allowing some beneficial immune effects
- Immune function is not inherently good or bad – there are different types of immune responses and you need the right one at the right time
- Peter says there is a parallel with reactive oxygen species (ROS)
  - They are vital signaling molecules, but they can also cause damage if they run amuck

> “A lot of biology is in the Goldilocks framework of not too much, not too little.” —Peter Attia

- 15 years ago, Matt would not have guessed that chronic inflammation and immune function would play a major role in aging
  - Based on his work with yeast and worms, he would have guessed factors such as translation, autophagy, and mitochondria
  - Those are all important for affecting inflammation and immune function
- Matt has become “very bullish on ‘inflammaging’ as critically important for many of the functional declines and diseases of aging that we see in people”
  - Many of the interventions Matt is excited about translationally seem to decrease the chronic sterile inflammatory signaling that happens with aging
  - Scientists are now enthusiastic about [senolytics](https://en.wikipedia.org/wiki/Senolytic) and [reprogramming](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6300877/), but Matt thinks they probably work very similarly to rapamycin
- Ideally we will figure out whether combinations of these interventions are work better than an individual one
  - These interventions all seem to reduce the markers of senescence ([inflammatory cytokines](https://en.wikipedia.org/wiki/Inflammatory_cytokine), [P16](https://en.wikipedia.org/wiki/P16), [P21](https://en.wikipedia.org/wiki/P21)) in aged mice, which may explain the functional improvements we see
  - Peter has also become convinced of the importance of inflammation in diseases like [Alzheimer’s disease](https://en.wikipedia.org/wiki/Alzheimer%27s_disease) and atherosclerosis
    - Sometimes people with risk factors for these diseases do not develop them and they tend to have a demonstrably low measured amount of inflammation
    - But is there a direct target of inflammation or do you simply reduce inflammation by targeting other mechanisms?

## Study showing rapalogs may improve the immune response to a vaccine [56:15]

**Joan Mannick’s** [**phase 2 study in 2018**](https://www.researchgate.net/publication/326339577_TORC1_inhibition_enhances_immune_function_and_reduces_infections_in_the_elderly#:~:text=TORC1%20inhibition%20enhances%20immune%20function%20and%20reduces%20infections%20in%20the%20elderly,-Article%20(PDF%20Available&text=Inhibition%20of%20the%20mechanistic%20target,immune%20function%20in%20model%20organisms.)

- mTOR is a kinase, an enzyme that adds phosphate groups to other proteins
  - at a higher level, it is sensing the environment and regulating the output based on what is going on
- They had not seen any substantial side effects in the first Phase II trial with everolimus
- In the [next trial](https://www.researchgate.net/publication/326339577_TORC1_inhibition_enhances_immune_function_and_reduces_infections_in_the_elderly#:~:text=TORC1%20inhibition%20enhances%20immune%20function%20and%20reduces%20infections%20in%20the%20elderly,-Article%20(PDF%20Available&text=Inhibition%20of%20the%20mechanistic%20target,immune%20function%20in%20model%20organisms.) they added in a drug called [RTB101](https://www.restorbio.com/pipeline/)
  - inhibits not only mTOR but other kinases too (sometimes it’s called a dual kinase inhibitor, but it’s more than just two)
  - So it’s a “dirtier” drug than rapamycin, which specifically inhibits a part of mTOR called mTOR Complex 1 ([MTORC1](https://en.wikipedia.org/wiki/MTORC1))
- Part of the rationale was that a new molecule would have intellectual property protection (as thus be profitable), but Joan Mannick has also said unpublished data suggested that the RTB010 doses they used in the trial were also MTORC1-specific
- The subjects were older adults without preexisting age-related conditions
  - Groups were a control, everolimus alone, RTB101 alone, and both
  - Looked at both influenza vaccine response and also upper respiratory tract infections over the next season
- Saw **improved vaccine response** in both the everolimus + RTB101 and the RTB101 alone groups (the everolimus alone group didn’t reach statistical significance)
  - And there was also a **lower risk of upper respiratory tract infection** over the next season
  - “So that suggested that not only is it boosting vaccine response, but it’s also broadly conferring protection against a variety of immune challenges in this older population”
- Some people claim mTOR inhibitors cannot be used for aging due to side effects, but there have actually been few adverse effects at the doses tested so far
  - Peter says [statins](https://en.wikipedia.org/wiki/Statin) have worse side effects than rapamycin
    - They are very widely used but 5-10% of patients go off them because of debilitating muscle aches
    - Other people get elevated liver function tests from statins
  - Given this, it’s frustrating to hear people say rapamycin has too many side effects – there is no data to support that right now

## Roadblocks to studying gero-protective molecules in humans [1:01:30]

[**PROTECTOR study**](https://www.globenewswire.com/news-release/2019/11/15/1947932/0/en/resTORbio-Announces-That-the-Phase-3-PROTECTOR-1-Trial-of-RTB101-in-Clinically-Symptomatic-Respiratory-Illness-Did-Not-Meet-the-Primary-Endpoint.html) **— the 2019 phase 3 study by resTORbio**

- In the Phase III trial, they took out everolimus and only tested RTB101
  - Failed to hit the endpoint and was terminated halfway through
  - The company that was doing the clinical trial, resTORbio, merged with a [CAR-T cell therapy](https://en.wikipedia.org/wiki/Chimeric_antigen_receptor_T_cell) company and gave up on RTB101 because of the failed clinical trial
- The data from that failed trial has not been shared and the details of what happened aren’t known, but we do know that the difference from earlier trials is that there was no longer a rapalog
  - Joan Mannick has said the FDA required them to change the endpoint from laboratory confirmed infections to something that involved patient self-reporting and the changed target was not hit
  - Matt is guessing that “it probably worked and they probably got screwed by being forced to change the right end point of that clinical trial”
- He sees the way the FDA manages trials concerning aging as requiring more thought and discussion
  - If the goal of a trial is to test whether or not an intervention is affecting a functional decline that goes along with aging (or aging itself), what is the appropriate endpoint and level of risk?
    - Matt thinks the culture at the FDA does not appropriately evaluate risk reward
  - The FDA wants to see very low risk in subjects deemed healthy for their age
    - But a typical 65- or 70-year-old is functionally impaired
    - We need to be realistic about the normal aging process

> “Regulators, society, [and] policymakers, really need, I think, to start taking a realistic look at what normal aging is. It is a progressive, chronic decline in function that at some point will lead to overt disease and with a hundred percent probability will lead to death, right? So if we can intervene in that process to slow it down or reverse it, there should be some level of risk that is acceptable for that potential outcome.” —Matt Kaeberlein

- What are we claiming to be studying and in whom?
  - Studies are designed to look at the progression and outcomes of disease
  - But aging is not easy to fit into that discrete definition

> “Until we really get people to center around … there being no such thing as a healthy 70-year-old, until we realize that at the regulatory level, at the policy level, even at the scientific level, it’s going to be very difficult to study the things that will have an opportunity to give step function changes in longevity” —Peter Attia

- Peter has talked to Nir Barzilai and [Steve Austad](https://en.wikipedia.org/wiki/Steven_N._Austad) about the choice of [metformin](https://en.wikipedia.org/wiki/Metformin) over rapamycin in the [TAME trial](https://www.afar.org/tame-trial)
  - Peter says the regulators will not consider trials involving rapamycin
  - Matt disagrees – he points out that he just mentioned trials that were done with everolimus, which is essentially rapamycin, so you can do rapamycin trials
  - He thinks there was good reason to test metformin in the context of the TAME trial
  - “I think that people with expertise in the field can come to differing opinions as to what the best shot on goal is”
- Matt is sure that the FDA would allow a rapamycin trial “where you had an endpoint that was quantitative and functional and related to quality of life in people”
- He thinks some challenges with rapamycin are
  - 1) it’s off patent so there’s limited money to be made
  - 2) uninformed concerns about side effects
  - But the biggest challenge is identifying the right endpoints for a clinical trial on aging
    - Can’t do lifespan like you can in dogs
- We need to think about the approaches we might consider
  - The TAME trial is one approach: ask if your intervention (in that case metformin) can delay the onset of an age-related disease in people who have another age-related diseases
  - We have a good idea how long the average time is between the onset of the first and second age-related diseases, so we can see if an intervention increases that time
  - But it’s not a true healthy aging study because it’s not taking people who are of normal health status for their age and asking whether the intervention can improve or extend the healthy period of their lives

> “What I would do is … try to identify the best single endpoint or set of endpoints that correspond to a significant functional deficit that impacts quality of life in older people and assess whether or not my intervention improves that.” —Matt Kaeberlein

- Ideally you’d have quantitative markers of the endpoint

## Potential benefits of rapamycin for age-related diseases—periodontal, reproductive function, and more [1:12:15]

- The endpoints of the resTORbio trial (vaccine response and infections over the next season) were very noisy
  - He respects Joan Mannick and thinks the trial likely failed for reasons beyond her control
  - But future trials could aim for less noisy endpoints
  - One example is periodontal disease

**Periodontal disease**

- Matt published a [paper](https://elifesciences.org/articles/54318) showing that, while aged mice get periodontal disease, it can be reversed by 8 weeks of rapamycin treatment
- Roughly 2/3 of older adults have or will get periodontal disease
  - Those with periodontal disease are at higher risk for dementia, cardiovascular disease, and diabetes
  - it’s connected in some way to other age-related diseases
- Peter recently did a [podcast](https://peterattiamd.com/patriciacorby/) on this topic (with [Pat Corby](https://www.dental.upenn.edu/faculty/patricia-corby/)) suggesting that the immune inflammatory pathway may connect oral and systemic disease
- Matt points put that the endpoints are extremely quantitative
  - Measured gingival inflammation, bone around the teeth (which can be measured crudely by pocket depth and more quantitatively by X-ray), and microbiome
  - A simple, non-invasive way to do a human trial is to do a dental exam before and after treatment
  - Could do it in a reasonable timeframe: treat people for 8 weeks or 3 months and then see what the intervention’s impact was
- A PhD student in Matt’s lab named [Jonathan An](https://halo.dlmp.uw.edu/people/jonathan-an/), who already has a DDS, came up with this idea
  - He’s now a faculty member at the University of Washington
  - submitting a grant for a 3-year Phase II study now (RO1 size, ~ $200K a year)

*Peter asks what secondary endpoints Matt would add if money were not a factor*

- First could repeat what was done with everolimus (called RAD001 in the study)
- Add hearing loss
  - A recent [study](https://www.frontiersin.org/articles/10.3389/fncel.2021.658972/full) showed that rapamycin reversed age-related **hearing loss** in mice
- Immune function
- [Sarcopenia](https://en.wikipedia.org/wiki/Sarcopenia) and muscle function (things like grip, strength, walk, and speed)
- Cognitive function / dementia would be interesting, but also a messy endpoint
- Heart function

**Rapamycin and reproductive function [1:19:00]**

- It would also be useful to have a trial looking at reproductive function
  - in female mice, there is pretty good evidence that you can reverse or delay reproductive declines associated with aging
  - Peter points out how amazing an effect on reproductive function would be
    - Aneuploidy (having the wrong number of chromosomes in an egg, such as missing one or having a duplicate) is a big cause of infertility as women age
    - These kinds of defects usually result in miscarriage, while some variants like trisomy 13 ([Patau syndrome](https://en.wikipedia.org/wiki/Patau_syndrome)) or trisomy 21 ([Down syndrome](https://en.wikipedia.org/wiki/Down_syndrome)) survive
    - Peter wonders what kind of effect rapamycin might potentially have on a 40-year-old woman with low or reasonable AMH but significant aneuploidy
  - Matt says there is not enough data to know: the studies have been done in mice and even that data didn’t include much on magnitude of effect
    - To find out, you’d need to design a study on premenopausal women (maybe in their early 40s) and do 8 weeks of treatment followed by a [washout period](https://medical-dictionary.thefreedictionary.com/washout+period), then look at endpoints
    - Or for women undergoing IVF, see if you get an improvement in outcome

## Debating the ideal length and frequency of rapamycin treatment for various indications like inflammation and longevity [1:21:30]

Peter wonders if 8 weeks of treatment would be enough time in most studies

- Matt says a longer treatment period might increase risks of side effects
- In vaccine studies, they waited about 2 weeks after treatment ended to give the influenza vaccine (washout period)
  - Did this because they were thinking about rapamycin as an immunosuppressant
  - We don’t know if they would have seen the same effects on immune function if the subjects had still been taking the drug when they got the vaccine
- If some functional responses require hyperactivation of mTOR, you might impair that by doing continued treatment with rapamycin
- So far 8 weeks seems long enough to give you the full benefit for a functional improvement
  - Perhaps not for lifespan – may need multiple eight week transient interventions in that case

- In one of Matt’s studies, giving mice three months of rapamycin treatment between 20 and 23 months of age produced an end-of-life effect similar in magnitude to ITP data (seemed “reasonably close to continuing treatment”)
- Does 8 weeks in mice translate to a few years in people?
  - If you linearly extrapolate, yes, but we don’t really know the answer
  - Matt as personally tried 8-10 week courses of rapamycin
    - He had a lot of shoulder pain from playing softball and couldn’t play catch with his son
    - He had frozen shoulder (inflammation of the shoulder capsule), which happens to some people as they age
    - The doctor did not recommend a cortisol shot because it can degrade the cartilage
    - After 2 weeks of rapamycin 8 mg once a week, he had half his range of motion back, and within 8 weeks he was back about 95%
    - He thinks it’s unlikely to be placebo given the dramatic reduction in pain and increase in range of motion
- We may be able to reset inflammatory-driven, age-related conditions with about 8 weeks of rapamycin
- Matt suspects senolytics would do the same
  - Senolytics are usually defined as drugs that kill the senescent cells, so in this way rapamycin is not a senolytic itself
  - But it does decrease the chronic inflammatory signaling that is driven by p16, p21, and [NF-κB](https://en.wikipedia.org/wiki/NF-%CE%BAB), as we have seen in mice
- Matt thinks terminology around senescence has not been precise
  - a lot of what people call senescence isn’t truly derived from senescent cells but rather from p16- or p21-mediated inflammatory cytokines
  - Matt is confident that rapamycin is affecting inflammation through the mTOR pathway
    - Rather than targeting a senescent cell directly, it somehow shuts off chronic inflammatory signals
    - Seems to target [senescence-associated secretory phenotypes](https://en.wikipedia.org/wiki/Senescence-associated_secretory_phenotype) (SASPs)
    - Matt says it’s natural in science to look at what we know (“We look under the lamppost. We measure what we know to measure, right?”)
  - There may be other factors besides SASPs

> “I tend to think based on my personal experience and the little bit of data from these two clinical trials, that [8 weeks] is probably long enough for at least some endpoints that are driven primarily by immune dysregulation and chronic inflammation.” —Matt Kaeberlein

- Peter followed an 8 weeks on, 6 weeks off cycle when he started taking rapamycin
  - then a while ago he said he was not coming off
  - Maybe 8 on, 5 off is good because that would be 4 cycles a year
  - He wishes there were a biomarker to indicate the right thing to do

## Biomarkers of aging and epigenetic clocks [1:29:15]

**Aging biomarkers**

- What would biomarkers for aging look like?
  - When Peter had Eileen White on the podcast, she pointed out that we don’t even have biomarkers for something as important as [autophagy](https://en.wikipedia.org/wiki/Autophagy)
  - We don’t know how long a human should fast to generate a meaningful amount of autophagy (in mice it’s a day, and in humans 7 days is likely enough, but we don’t precisely know)
  - We can measure telomere length, but Peter does not think this is a helpful measurement for aging: “I think there’s plenty of data to suggest that while telomere length is a very important marker of cellular division, it really speaks very little about the organism’s state of aging”

**Epigenetic clocks**

- Peter doesn’t think [epigenetic clocks](https://en.wikipedia.org/wiki/Epigenetic_clock) are useful either because they can easily be manipulated by short-term interventions that don’t seem biologically relevant
- The epigenetic clock refers to chemical marks on DNA that regulate gene expression (whether or not a gene is turned on or off)
  - these marks change with age in pretty much every organism where it’s been studied
  - We have identified patterns of change at specific locations in the genome that correlate very strongly with chronological age
  - So we have tried to create clocks that look at specific chemical marks in the DNA to determine how long that that organism has been alive
- You can identify individuals whose chemical marks are not in line with what we would expect given their chronological age
  - They seem to be aging faster or more slowly than expected
  - And indeed, those individuals who tend to be off the line turn out to be at lower or higher risk for specific diseases depending on whether they seem to be aging more slowly or more quickly
  - This adds some weight to the argument that epigenetic clocks are measuring biological age
- Can we develop epigenetic clocks that will, in a predictive way, tell you how old you are biologically?
  - Some companies are selling these tests right now
  - Human tests are based on markers in the blood, but it’s not clear whether the “biological age” of the blood reflects the biological age of the entire body
  - They are mostly looking at [peripheral blood mononuclear cells](https://en.wikipedia.org/wiki/Peripheral_blood_mononuclear_cell) (PBMCs) and maybe saliva tests, but Matt’s not sure how the commercial companies are doing it
- Peter discounts clocks that use inputs like glucose or vitamin D level, because they vary widely from day to day and are easy to manipulate
- Matt thinks the data and correlations of epigenetic clocks are strong
  - But he’s skeptical that there are so many data points in the epigenome that you can find a pattern that will fit pretty much anything you look for
  - It may not be a robust predictor of biological age, but they are telling us something
- Peter would like to have [Steve Horvath](https://en.wikipedia.org/wiki/Steve_Horvath) on the podcast to talk about the details of data from epigenetic clocks
- Matt says that people are now “going beyond the epigenetic clocks to try to look at every possible thing you could measure, sometimes combining that with the epigenetic clock to build these multi-element clocks”
  - Now you have tens of thousands of additional data points, which makes it more likely you can find a pattern
  - We’re not yet at the point of getting to biological explanations for what the patterns are telling us
  - Are the genes at the mark locations causal for biological aging in any way?  We’d need to understand the mechanism to know

> “We have a lot of biomarkers of aging. We just don’t have any validated biomarkers of aging. …You can identify all sorts of things that correlate with age.  How do you get to the point of convincing yourself … that these things are actually telling you something about biological aging that can then be used to understand whether an intervention is working?’” —Matt Kaeberlein

- The goal would be to develop a test you could take to find out if something you are doing (fasting, taking metformin or rapamycin, etc.) is working based on a set of biomarkers
- We are not there yet

## Prospects of a test that could calculate biological age [1:37:45]

- Steve Austad was [recently on](https://peterattiamd.com/steveaustad/) the podcast and made a similar point about the ITP studies
  - They out a lot of time and money into it, but you can argue that the technology simply wasn’t mature enough
  - Now, 30 years later, we have “omics,” machine learning, etc.
- Maybe it could be done today, but it might be too disjointed a project for academia
  - But it’s not a particularly good commercial endeavor because you’d have to invest far too much up front before it would pay off
  - “someone’s got to pony up a lot of money to develop the foundation of a pyramid that will ultimately become a great tool for drug discovery”
- Matt thinks there isn’t much of a barrier to doing it pre-clinically now
  - You could do a [multiomic](https://en.wikipedia.org/wiki/Multiomics) analysis of aging in mice
  - Apply machine learning to identify patterns that predict the effect of interventions and individual outcomes for longevity
  - Would be restricted to looking at blood if wanted to do a longitudinal study because you could not kill the animals
- The biotech company [Calico](https://www.calicolabs.com/) has the resources and expertise to do this kind of study
  - They are interested in multiomic signatures of different aging processes
  - They’re a kind of hybrid between academia and industry
  - You could develop a test of, say, 24 factors that give you 95% confidence on remaining life
  - Then you could do an independent study to see if it works
- It would be really impressive if you could predict how long mice would live at the individual level when they are 6 months old, and even more impressive to show that a specific intervention can predict they’re going to live 30% longer
  - But you can’t use this approach in humans
  - It takes a long time to do the validation step and know that you have actually changed somebody’s biological state so that they are at lower risk for disease and are likely to live some X percent longer
  - You are almost obligated to have some level of faith in the test at that point
- It’s not clear what you’d have to do before you could convince regulators that you can actually go out and tell the general public that this test works (although they are not really stopping people who are already doing that)

## The Dog Aging Project testing rapamycin in pet dogs [1:42:30]

[**The Dog Aging Project**](https://dogagingproject.zendesk.com/hc/en-us)

- Joint project at the University of Washington, Texas A&M, and several other institutions understand the biology of aging in companion (pet) dogs
- There are two parts of the project
  - The first is a large-scale, longitudinal, purely observational study of aging
    - Designed to understand the most important genetic and environmental factors that influence healthy aging in dogs
    - measure as much as we can about those dogs every year in order to be able to identify patterns that are associated with health outcomes during aging
  - The second part (Matt’s focus) is to explore whether we can slow or reverse biological aging in pet dogs to increase healthy lifespan
    - The first clinical trial is with rapamycin

*Why study pet dogs?*

- They have “interesting and powerful genetic architecture” – have a few hundred pure breeds (like inbred strains) but also a mixed-breed population with phenotypic diversity
  - Dogs are even more genetically diverse than people: for example, there are huge difference in size and lifespan (Great Dane 8-10 years, chihuahua 16-17 years)
  - Really useful for mapping genotype onto lifespan
  - Dogs are far more genetically similar to humans than mice
- With the exception of diet, dogs share almost all aspects of the human environment
  - Bridges lab studies, where variation is limited, and human studies
- Dogs live substantially shorter than humans, so we can track them for life
  - We know that dogs age about 7 times faster than humans do
- They age very similarly to the way that people do
  - get essentially all of the same age related diseases
  - show the same functional declines as humans (like arthritis, which starts as a functional decline)
- Dogs are “a very powerful animal in which to understand aging and test interventions” within a feasible time frame
- Even if we believe metformin is going to extend lifespan in people, you’re not going to do a clinical trial to prove it, so do it in dogs instead

**TRIAD study [1:47:45]**

- Test of Rapamycin in Aging Dogs ([TRIAD](https://dogagingproject.zendesk.com/hc/en-us/articles/1500001690382-What-is-the-TRIAD-Cohort-)) is a clinical trial on rapamycin in older dogs
- Dogs get the drug for the entire 3 years
- It’s designed to be statistically powered to detect a 15% change in lifespan within a three-year window
  - Matt is concerned that it might be underpowered
  - Clinical trials are a lot of guesswork – you can’t test every dose or duration or an unlimited number of study subjects
  - He thinks they’ve done the best design they could given the resources they have
  - 15% might be a high bar, but it’s consistent with the lower end of what we see in mice
    - it’s reasonable given that the ITP low dose studies of rapamycin in mice found a 14% effect in females and a 9% effect in males
- We don’t know if we will see a sex difference in dogs
  - We’re not sure why we see one in mice, but it’s correlated with blood levels so it may be that male mice either take up rapamycin less effectively or break it down more quickly
  - So far there is no evidence of that in dogs (or humans)
  - In mice, at low doses females show a bigger lifespan extension, at middle doses females and males are the same, and at very high doses male mice actually get a bigger lifespan extension
  - Seems to be related more to effective concentration than a truly sex-specific response
- For TRIAD, they are dosing dogs at 0.15 mg/kg once a week
  - Was based on their observations from 0.05 mg/kg three times a week
- Lifespan is the primary endpoint, and Matt thinks this is the first clinical trial with lifespan in a healthy, normal health status population as the endpoint
- Also tracking multiple secondary endpoints to give us a picture of is rapamycin broadly impacting the aging process
  - Periodically fitted with activity monitors to look at spontaneous activity
  - Every 6 months the dogs get echocardiograms to look at heart function, cognitive assessments, blood chemistry, serum metabolome, and fecal microbiome
  - Also tracking disease incidence
  - Matt hopes that in 3 years, even if they don’t see a statistically significant lifespan extension, they’ll be able to detect changes in other secondary endpoints if there is a broad effect on multiple age related outcomes
- They will have two groups, placebo and dose, and about 175 dogs in each group
  - They probably would have needed about 500 dogs to power for a 10% effect size
- There is data from 3-4 mice studies on rapamycin and age-related declines in heart function
  - Several measures of left ventricular function decline with age
  - 8-10 weeks of rapamycin is enough to reverse the changes and make the heart appear younger by echocardiography
  - There’s also strong evidence in mice that rapamycin can reverse dilated cardiomyopathy
  - Matt’s first clinical trial in dogs
    - Just a safety trial
    - 24 dogs got echocardiograms before and after the treatment period
    - 16 got rapamycin and 8 got the placebo
    - The rapamycin dogs showed statistically significant improvements in two of the three measures of left ventricular function
    - none had clinically diagnosed heart failure, but some had normal, age-related declines in function
    - the improvements were found exclusively in the dogs that came in with lower function
    - it was a small cohort, but Matt senses that this observation is real
    - it makes intuitive sense that function-restoring interventions would primarily be effective in those who have lost function
- In the TRIAD study, if a benefit is shown, it will be interesting to see if the dogs with the lowest baseline function benefit the most
- The criteria for TRIAD are: at least 7 years old (middle aged) and between 40 and 100 lbs
  - Smaller dogs live longer and develop age-related diseases and functional declines later, so bigger dogs are better for the timeframe of this study
  - But brain aging and cognitive function may be an exception – in a chronological sense, the rate of cognitive decline in big dogs looks very similar to the rate in small dogs
  - The big dogs die at an earlier age but don’t seem to show accelerated cognitive decline, and it will be very interesting to find out more about the mechanism

## The role of the mTOR complexes [1:58:30]

mTOR is a kinase (an enzyme) that acts in a complex with other proteins

![](https://peterattiamd.com/wp-content/uploads/2021/09/f3-mattk2-1024x702.png)

**Figure 3. The mTOR pathway can promote age-associated diseases**.  Activation of mTOR may promote cellular stress (protein aggregation, organelle dysfunction, and oxidative stress), which can lead to cell damage accumulation, reduced cell function, and stem cell exhaustion, reducing tissue repair and promoting tissue dysfunction. In this way, the mTOR activation pathway promotes the development of aging-related diseases. mTOR inhibitors like rapamycin might be able to extend lifespan by preventing these effects. Image credit: [Stallone et al. 2019](https://pdfs.semanticscholar.org/d07c/0024af88fd0e175e96339c32e9c818084e9a.pdf)

- mTOR has at least two different complexes, mTORC1 and mTOR complex 2 ([MTORC2](https://en.wikipedia.org/wiki/MTORC2))
  - some things are the same across the complexes, but their partner proteins are unique and the two complexes do functionally different things in the cell

![](https://peterattiamd.com/wp-content/uploads/2021/09/f4-mattk2-1024x775.png)

**Figure 4. The mTOR complexes**.  Image credit: [Foster & Fingar 2010](https://www.jbc.org/article/S0021-9258(20)54851-5/fulltext)

- mTORC1 is most responsive to nutrient levels
  - When nutrients signals are low, it leads to lower mTORC1 activity
  - Downstream mTORC1 activity regulates things like autophagy and [mRNA](https://en.wikipedia.org/wiki/Messenger_RNA) [translation](https://en.wikipedia.org/wiki/Translation_(biology)) and has effects on metabolism
- We know a lot less about what mTORC2 does
- Aging biology has focused on mTOCR1
  - almost all of the data for rapamycin or mTOR as a regulator of aging is thought to be mediated by inhibition or reduced signaling through mTORC1
  - The only data linking mTORC2 and lifespan is from *C. elegans*, a worm
- Rapamycin is known to be a specific inhibitor of mTORC1
  - Rapamycin binds to another protein called FKBP12 (or FPR1 in yeast)
  - The rapamycin- FKBP12 complex breaks apart mTORC1, inhibiting it
  - Rapamycin is a “clean” drug (has very specific effects just on mTORC1)
- Chronic, long-term inhibition of mTORC1 can have feedback effects on mTORC2
  - but it’s not clear how because data shows both inhibition and activation (seems to be inhibition in the long term)
  - There seems to be more of an effect on mTORC2 at higher doses of rapamycin
- Dave Sabatini and [Dudley Lamming](https://www.medicine.wisc.edu/people-search/people/staff/4646/Lamming_Dudley)’s work led to the idea that rapamycin’s side effects (especially metabolic) are caused by chronic inhibition of mTORC2
  - Matt thinks this is at least partially wrong
  - In mice, rapamycin induces a pseudo diabetes
    - in humans, chronic long-term treatment leads to glucose intolerance
    - A mouse who has taken rapamycin for a year will not clear glucose as rapidly as a mouse that never took rapamycin
  - Most of the data linking this effect with chronic effects on mTORC2 comes from genetic experiments with mTORC2-deficient mice
    - While Matt considers this a reasonable model, “I have yet to see a really clean experiment showing that that’s what accounts for the rapamycin effects on glucose tolerance”
    - the experiments that have been done involved genetic manipulation of mTORC1 and mTORC2 rather than experiments where mice were given rapamycin
  - Peter doesn’t think [Rich Miller](https://medicine.umich.edu/dept/dcmb/richard-miller-phd) did this in any ITP studies, but he wonders whether, in studies where the animals are getting rapamycin every single day, they had impaired glucose tolerance despite longer life
    - Matt doesn’t think the ITP studies measured this, but he thinks some studies using the C57 black 6J mouse strain (different from the strain used in ITP studies) found changes with a glucose tolerance test on older mice at a higher dose (42 ppm)
    - there’s evidence in organ transplant patients for impaired glucose homeostasis as well
  - Matt does think it’s due to mTORC2 because there is no reason to doubt it, but he just doesn’t think there’s clean evidence yet
- But he is less convinced than Dudley Lamming that these glucose homeostasis effects are bad
  - It might reflect is an underlying change in metabolism that could account for part of the beneficial effects of rapamycin
  - It could be a shift away from primarily relying on glucose as the preferred carbon source and switch over to fat metabolism (and maybe even ketogenesis to some extent)
  - in that context, when you challenge them with a non-physiological amount of glucose, they don’t respond the same way
  - Instead of a defect in glucose homeostasis, it might reflect a different underlying physiological state, but we don’t really know
  - rapamycin treatment has pretty profound effects on fat mobilization, fat metabolism, adipogenesis, and, at higher doses, ketogenesis
    - that metabolic adaptation could account for some of the beneficial effects of rapamycin and also result in the apparent aberrant response to a glucose tolerance test
  - Another doc who uses rapamycin liberally showed Peter some of his data that was quite dramatic (although also messy and uncontrolled)
    - Triglycerides fell from unhealthy levels of 200 mg/dL to 70 mg/dL
    - And this doc is seeing improved glucose homeostasis
  - When you do an oral glucose tolerance test on people who are calorie or carbohydrate restricted, you can see a physiologic insulin resistance, but that initial form of muscle insulin resistance is actually protective

*Other animals models have been successful with daily dosing – why did Matt decide to use once a week for his dog study?*

- Based in part on human data and in part on data that suggests weekly dosing is as good as daily for immune system / inflammatory effects
- Weekly dosing also has fewer side effects, which is important when you’re dealing with people’s pets because there is an extremely low tolerance for significant side effects
- It’s also more practical to give it once a week rather than daily or 3 times a week – better compliance and fewer mistakes

## mTor inhibitor called Torin2, mitochondrial disease and other potential pathways [2:09:45]

- [Torin2](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3760004/) is a different kind of mTOR inhibitor from rapamycin
  - rapamycin is an [allosteric](https://en.wikipedia.org/wiki/Allosteric_regulation) inhibitor – it does not interact through the [active site](https://en.wikipedia.org/wiki/Active_site) of the enzyme
  - Torin2 is a [catalytic inhibitor](https://en.wikipedia.org/wiki/Reaction_inhibitor) (or an ATP competitive inhibitor) of mTOR because it affects the active site
- There haven’t really been studies of torin2, [torin1](https://en.wikipedia.org/wiki/Torin-1), or other catalytic inhibitors’ effects on aging in mice, but Peter and Matt are not sure why
  - They are important studies to do, not just to answer the critical question if how they affect aging but also for implications for mitochondrial disease
- Matt’s lab has worked on a mouse model of a childhood mitochondrial disease called [Leigh syndrome](https://en.wikipedia.org/wiki/Leigh_syndrome)
  - The mice are defective in [complex 1](https://en.wikipedia.org/wiki/Respiratory_complex_I) of the [electron transport chain](https://en.wikipedia.org/wiki/Electron_transport_chain) of the mitochondria

![](https://peterattiamd.com/wp-content/uploads/2021/09/f5-mattk2-1024x793.png)

**Figure 5. Oxidative phosphorylation by the electron transport chain.** Multiple steps, including the oxidation of NADH by complex 1 (translocating protons across the membrane and producing NAD+), are required to produce adenosine triphosphate (ATP). This process is known as oxidative phosphorylation. Image credit: [MIT OpenCourseWare](https://www.flickr.com/photos/mitopencourseware/3588961075)

- The mice only live about 55-60 days
- They develop many of the same molecular and neurological phenotypes as kids who have Leigh syndrome
- Kids with Leigh syndrome die anywhere from infancy to around age 9, and they usually do not make it to the teen years
- Matt found that rapamycin could roughly double or triple the survival of these mice and basically prevent the neurodegeneration and brain lesions that are thought to limit lifespan in both the mice and the kids with Leigh syndrome

- Peter guesses that when you knock out complex 1, you destroy [oxidative phosphorylation](https://en.wikipedia.org/wiki/Oxidative_phosphorylation), to which neurons are particularly sensitive
- Matt says the affected component of complex 1 is an accessory stabilizing factor
- The mice aren’t 100% deficient, but they have low levels of complex 1 (having none is probably not compatible with survival)
- Current theories
  - they can’t generate enough ATP, which negatively impacts a particular subset of neurons
  - They are generating high levels of reactive oxygen species (ROS), to which subsets of neurons are especially sensitive
  - There is neuroinflammation in the brain regions where the lesions occur, but we don’t quite understand the mechanism
    - But work from [Vamsi Mootha](https://en.wikipedia.org/wiki/Vamsi_Mootha) and [Isha Jain](https://ishajainlab.com/team/) has shown that hypoxia rescues these mice to a greater extent than rapamycin, which is at the very least consistent with an oxidative stress model
    - Perhaps when you’re deficient in Complex 1, the neurons do not use as much oxygen because they switched over to non-oxidative glycolytic metabolism and [fermentation](https://en.wikipedia.org/wiki/Fermentation)
    - That leads to higher oxygen levels in the brain and thus higher oxidative damage
- Peter wonders if Matt has tried giving the mice excessive levels of [lactate](https://en.wikipedia.org/wiki/Lactic_acid), which would theoretically allow neurons to bypass the electron transport chain
  - Matt hasn’t, but the mice have higher levels of lactate in their blood, which is common in mitochondrial disease because they switch over to fermentation
  - rapamycin suppresses the high level of lactate as well as the accumulation of all the glycolytic intermediates upstream of lactate
  - so there is some reason to believe that oxidative stress is important
- The mice also have a dramatic fat loss
  - Rapamycin has some effect on fat mobilization and [adipogenesis](https://en.wikipedia.org/wiki/Adipogenesis) that prevents the mice from using up all their fat
  - They probably become so lean because they are trying to burn the fat in some way
- Matt and [Judit Villen](https://www.gs.washington.edu/faculty/villen.htm) at the University of Washington did a [study](https://pubmed.ncbi.nlm.nih.gov/33324011/) on the effect of rapamycin on the proteome and the phospho-proteome in the knockout mice compared to wild type with and without rapamycin treatment
  - Found that mTORC2 components were at decreased at the protein level
  - This finding is compatible with the idea that high dose rapamycin chronically leads to inhibition of mTORC2
- There was also an associated inhibition of [protein kinase C](https://en.wikipedia.org/wiki/Protein_kinase_C), another kinase that’s regulated by mTORC2 and is known to regulate some aspects of inflammation
  - They hypothesized that some of the effects of rapamycin, at least in this mouse model, are through protein kinase C and mTORC2 rather than solely through mTORC1
  - They tested a few drugs that are known inhibitors of protein kinase C, and they rescued part of the lifespan of the mitochondrial diseased mice
    - weren’t as good as rapamycin, but they did result in significant increases in survival and delayed some of the neurological symptoms
  - So rapamycin may inhibit mTORC2 and protein kinase C
  - They also found that, in this model, Torin2 seems to work as well as rapamycin
- Matt and some collaborators are currently working in another mouse model of a severe childhood metabolic disease, which Matt cannot say much about yet because it has not been published
  - But they saw “dramatic rescue” with rapamycin and Torin2 for a disease which is on the surface completely unrelated to complex 1 of the mitochondria
- mitochondrial disease might be a good model for normal aging in some respects
  - mitochondrial dysfunction is one of the hallmarks of aging
  - Matt thinks that interventions that address severe mitochondrial dysfunction might also be effective in the context of normative aging
- Matt wonders if Torin2 or other catalytic inhibitors of mTOR might be as effective as rapamycin in the context of aging (and maybe even more effective in some contexts)
  - For now it’s a “gaping hole” in the literature

## Catalytic inhibitors, sirtuins, and NAD [2:19:15]

- RTB101, the drug in the resTORbio phase III clinical trial, is a catalytic inhibitor of mTOR as well as other kinases
  - Biochemically at least, it would fall into the Torin2 class as opposed to the rapamycin class
- Rapamycin is made by bacteria and was discovered on the island of [Rapa Nui](https://en.wikipedia.org/wiki/Easter_Island) (aka Easter Island)
- Matt says they would need to ask Dave Sabatini about the origins of Torin2, but he thinks it came from traditional chemical screening as a mTOR inhibitor and then was modified to be a more potent catalytic mTOR inhibitor
- It does not appear that Torin1 or Torin2 is in the FDA pipeline or has an IND application
  - RTB101 is being developed for FDA approval
  - There are other dual kinase inhibitors that are used clinically that hit mTOR in addition to others (like [phosphoinositide 3-kinases](https://en.wikipedia.org/wiki/Phosphoinositide_3-kinase) (PI3Ks), a different class of kinase)
  - But there doesn’t seem to be much effort to develop the more specific mTOR catalytic inhibitors, and Matt is not sure why

**Sirtuins and NAD**

- Peter has had [David Sinclair](https://en.wikipedia.org/wiki/David_A._Sinclair) on the podcast a [couple](https://peterattiamd.com/davidsinclair2/) of [times](https://peterattiamd.com/davidsinclair/) to explain what [sirtuins](https://en.wikipedia.org/wiki/Sirtuin) are, how they work, and why they require [nicotinamide adenine dinucleotide](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide) (NAD)
- Sirtuins are a class of mostly [deacetylases](https://en.wikipedia.org/wiki/Protein_deacetylase) that primarily take acetyl groups off of other proteins
- Their activity requires and consumes NAD, a [co-factor](https://en.wikipedia.org/wiki/Cofactor_(biochemistry)) for many metabolic reactions
  - it gets converted between NAD+, which is the oxidized form of the coenzyme, and NADH, which is the reduced form
  - Many different metabolic reactions use NAD, including the electron transport chain, [glycolysis](https://en.wikipedia.org/wiki/Glycolysis), and fermentation
  - Matt does not think that sirtuins are the only or even primary reason why NAD is important
- But sirtuins are fundamentally different in that they use up NAD
  - NADH, the reduced form of NAD+, inhibits sirtuins
  - The NAD+ to NADH ratio can be used as a proxy of sirtuin activity

![](https://peterattiamd.com/wp-content/uploads/2021/09/f6-mattk2-1024x729.png)

**Figure 6. The role of specific sirtuins**. Sirtuins are proteins that regulate cellular homeostasis.  The 7 identified sirtuins have a variety of functions, including regulating the cellular stress response and the biogenesis of mitochondria. ([Chromatin](https://en.wikipedia.org/wiki/Chromatin) is a DNA and protein complex that packages DNA to prevent damage to the strands.) Image credit: [David Jockers](https://drjockers.com/sirtuins/)

- Matt worked on this when he was a grad student in [Lenny Guarente](https://en.wikipedia.org/wiki/Leonard_P._Guarente)’s lab
  - Showed that you could overexpress the yeast sirtuin, called [SIRT2](https://en.wikipedia.org/wiki/Sirtuin_2)
  - Overexpression of SIRT2 increases the yeast lifespan
  - other people have since shown that activation or over expression of sirtuins in worms or flies or mice can have effects on aging
- Matt and David knew each other from Lenny’s lab when Matt was a grad student and David was a postdoc
  - Though Matt and David have had scientific disagreements over the years, Matt credits David with mentoring him, being an important influence on his early career, and guiding him to the project looking at SIRT2
  - Lenny’s lab, which was a great environment full of smart people, established sirtuins as important in aging and in multiple model systems
- Although David might disagree a bit, Matt thinks the evidence that sirtuins are potent regulators of lifespan in mice is mixed
  - Few studies have been published, but unpublished studies found no effects on mouse lifespan from manipulating or activating sirtuins
    - One study found that brain-specific activation of one of the sirtuins (SIRT1) could slightly extend lifespan
    - Another that overexpression of a different sirtuin (SIRT6) could slightly extend lifespan, but only in males
  - But these studies found nowhere near the reproducibility or magnitude of effect of other things, including rapamycin, so Matt finds it unconvincing
- There is good evidence that metabolic markers of health (particularly heart disease with some evidence for cognitive function) can be improved by activating sirtuins
- Matt thinks there is a lot of confusion in the field about the relative strength of data for different interventions
  - He says there is no comparison between the effects you get from inhibiting mTOR and the effects at least so far that people have reported from activating sirtuins
  - mTOR has a much greater magnitude of effect
- Despite this, Peter says the number of questions people ask him is inversely related to the magnitude of effect – he gets many more questions about sirtuins than rapalogs
- In general, the model is that amplifying sirtuins is beneficial in the context of aging
  - But that is oversimplified because there are 7 sirtuins that do different things in different tissues

**The significance of NAD**

- If NAD activates sirtuins, then people assume more NAD is beneficial
- NAD homeostasis becomes impaired with aging, and in many tissues the ratio shifts towards more NADH and less NAD+
  - That same shift is seen in mitochondrial disease, but much more pronounced
  - the cells switch over to glycolysis and fermentation to lactate
  - fermenting to lactate restores NAD levels
- this probably reflects an underlying metabolic defect, which could be mitochondrial in origin, that leads to the shift towards the reduced form of NAD with age
- The prediction is that if we could boost NAD, it would restore sirtuin activity and have positive effects on aging
- this led to the development and popularization of molecules called NAD precursors or NAD boosters

## NAD precursors: help or hype? [2:28:15]

- The two that get talked about the most are [nicotinamide riboside](https://en.wikipedia.org/wiki/Nicotinamide_riboside) (NR) and [nicotinamide mononucleotide (NMN)](/does-nmn-improve-metabolic-health-in-humans/)
  - Both are precursors of NAD that can be converted into NAD within cells
- there’s a large body of literature in a variety of model organisms showing that treatment with NR or NMN sometimes leads to benefits associated with healthy aging (and in one study lifespan extension in mice)
  - but there is also a large body of literature that doesn’t reproduce these results, much of it unpublished
  - These studies include the ITP data, which Peter considers the gold standard for mice data
  - The ITP model is a different genetic background than C57 black 6, could be why it worked in one context and didn’t work in another context
- A collaborator Matt trusts found that NMN could increase lifespan in a mitochondrial disease mouse model
  - But Matt has tried multiple times with both NR and NMN in that mouse model and has not found lifespan extension
  - There is something we don’t understand about delivery or uptake
- Peter has read that when supplements are shipped, it’s highly unlikely that they still have the biologic activity that they would have had if they had been refrigerated
  - Matt thinks there is probably some truth to that
  - in his studies they keep the mouse food in the fridge
- But he thinks it reflects a bigger problem with the NAD precursor field
  - there’s an NR camp and an NMN camp, and each says the other’s molecule doesn’t work for a variety of reasons
  - there’s a lack of clarity around biological availability and efficacy in the preclinical literature
  - results are not replicable in many fields for many reasons, but it seems to be a bigger problem in the NAD precursor field, which Matt has experienced in his lab as well
- There is a lot of smoke with sirtuins and NAD precursors
- Contrary to what some believe, Matt is not anti-sirtuin: he’s the one who first showed an association between overexpression of sirtuins and increased lifespan
  - He’s just seen a lot of data that scientists have struggled to reproduce, while in contrast, the rapamycin data has been reproduced many times
  - So he’s less enthusiastic about sirtuins and NAD precursors, but he does think they are important for aging
  - We still need to figure out how to tweak the experimental process to get robust and reproducible experimental results
  - [Resveratrol](https://en.wikipedia.org/wiki/Resveratrol) was not able to activate sirtuin as intended
  - Peter wonders if maybe you need to both provide more of a precursor and activate sirtuin
- Matt says it should be easy to determine whether or not a drug has boosted NAD levels by measuring NAD, but it’s often not done
  - Need to measure both blood and target tissue levels
- When patients ask, Peter says he thinks the only downside of taking NR or NMN is financial
  - But he doesn’t really see the upside
- Matt would like to test NR or NMN or both in dogs because the risk is low and the data could tell you if it works

> “I think if I saw NR slow aging, increased lifespan, and or improve multiple functional measures of aging in dogs, I’d be much more bullish on taking NR myself. Wouldn’t prove it’s going to work in people, but it’s … a pretty big part of the way there.” —Matt Kaeberlein

- But no one will do the definitive clinical trial in humans because they can sell it now without proving it works

**A note about the history of** ***The Drive*** **…**

- About 5 years ago, Peter had dinner in NYC with Matt and [Yousin Suh](https://www.genetics.cuimc.columbia.edu/profile/yousin-suh-phd), who was at Einstein but now runs a reproductive aging center at Columbia
- Peter wished he had recorded the dinner conversation, and that’s what inspired him to start this podcast

- Peter says Matt is one of the few people in the field of longevity who can have a discussion that is both very wide and very deep

§

# SUPPLEMENTARY SECTION: THE NINE HALLMARKS OF AGING

Source: [López-Otín et al. 2013](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3836174/)

- **Genomic instability**

- Genetic damage accumulates with age
  - Mutations, translocations, and chromosomal defects become more prevalent
  - Cancer is one result of unrepaired DNA damage
- In both humans and mice, individuals with compromised DNA repair processes show multiple signs of accelerated aging

- **Telomere attrition**

- [Telomeres](https://en.wikipedia.org/wiki/Telomere) are sequences of nucleotides located at the end of linear chromosomes
- Telomeres shorten with age in both people and mice
  - Mice genetically engineered to lack telomerase have shown some symptoms of premature aging
  - Mice engineered to express higher levels of telomerase than normal have been reported to live longer

- **Epigenetic alterations**

- [Epigenetics](https://en.wikipedia.org/wiki/Epigenetics) means changes to inherited characteristics that are not caused by direct changes to the DNA
  - Often involves changes in gene expression or activity
  - Examples include changes in DNA methylation patterns and remodeling of chromatin and histones
- The sirtuin SIRT6, an epigenetic enzyme, appears to affect longevity

- **Loss of proteostasis**

- [Proteostasis](https://en.wikipedia.org/wiki/Proteostasis) involves both maintaining the stability of proteins and facilitating the degradation of unneeded proteins
- Proteins are folded in precise, complex shapes that begin to misfold with age
  - Misfolded proteins are dysfunctional and may also aggregate together
  - Alzheimer’s disease is an example of an age-related disease caused by abnormal protein aggregation
- Both genetic and drug-induced enhancement of protein quality control will extend life in mice

- **Deregulated nutrient sensing**

- The [hypothalamic–pituitary–somatotropic axis](https://en.wikipedia.org/wiki/Hypothalamic%E2%80%93pituitary%E2%80%93somatotropic_axis) (HPS axis), which regulates organism growth, involves hormones like [growth hormone](https://en.wikipedia.org/wiki/Growth_hormone) (GH) and [insulin-like growth factor 1](https://en.wikipedia.org/wiki/Insulin-like_growth_factor_1) (IGF-1), which has the same signaling pathway as [insulin](https://en.wikipedia.org/wiki/Insulin)
- The [insulin and IGF-1 signaling pathway](https://pubmed.ncbi.nlm.nih.gov/15272501/) targets mTORC1, mTORC2, and the FOXO [transcription factors](https://en.wikipedia.org/wiki/Transcription_factor) and is connected to aging
- Dietary restriction (DR) increases lifespan or healthspan
  - Reducing food, using drugs like rapamycin that mimic the state of limited nutrients, or inhibiting insulin or IGF-1 improve health and increase lifespan in mice and other species

- **Mitochondrial dysfunction**

- Decreased efficacy of the electron transport chain leads to reduced ATP production
- This may lead to excessive [reactive oxygen species](https://en.wikipedia.org/wiki/Reactive_oxygen_species) (ROS), which can further damage cells

- **Cellular senescence**

- [Cellular senescence](https://en.wikipedia.org/wiki/Cellular_senescence) occurs when cells stop dividing
  - Senescent cells increase with age
  - Can damage the surrounding area
- Telomere attrition is one (but not the only) cause of cellular senescence
- It’s not clear if senescent cells contribute to aging or just prevent the growth of damaged or tumor cells
  - Perhaps organisms do not clear senescent cells or generate replacement cells well enough as they age
- Senescent cells have been linked with inflammation

- **Stem cell exhaustion**

- The ability of tissues to regenerate cells and repair damage decreases with age as a result of a decline in stem cell activity
- Stem cell rejuvenation may be a promising therapy

- **Altered intercellular communication**

- Cells communicate through [the endocrine system](https://en.wikipedia.org/wiki/Endocrine_system) (hormones), the nervous system, and the interaction between them as the brain regulates hormone levels ([neuroendocrine system](https://en.wikipedia.org/wiki/Neuroendocrinology#Neuroendocrine_system))
- These pathways become deregulated with aging
  - Immune surveillance is decreased
  - Chronic low-level inflammation (“inflammaging”) occurs and damages surrounding tissues
- Studies suggest that the blood of young animals contains molecules that can actually rejuvenate damaged tissue in older adult animals

§

## Selected Links / Related Material

**Peter’s first podcast with Matt**: [#10 – Matt Kaeberlein, Ph.D.: rapamycin and dogs — man’s best friends? — living longer, healthier lives and turning back the clock on aging and age-related diseases](https://peterattiamd.com/mattkaeberlein/) | Peter Attia, [*The Drive*](https://peterattiamd.com/podcast/) (August 20, 2018) | [3:45]

**Overview of the mTOR pathway**: [mTOR pathway: A current, up-to-date mini-review (Review)](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4214394/) | *Oncology Letters* (Zarogoulidis et al. 2014) | [3:45, 11:45, 56:45, 1:59:00]

**Paper describing the nine hallmarks of aging**: [The Hallmarks of Aging](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3836174/) | *Cell* (López-Otin et al. 2013) | [7:15, supplementary section]

**Cynthia Kenyon on normal aging vs. disease**: [Is Aging a Disease? A Conversation with Cynthia Kenyon](https://www.ucsf.edu/news/2007/01/103427/aging-disease-conversation-cynthia-kenyon) | *UCSF Magazine* (January 10, 2007) | [14:30]

**Study indicating that the FOXO3A variant is associated with increased longevity**: [Association of *FOXO3A* variation with human longevity confirmed in German centenarians](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2650329/) | *PNAS* (Flachsbart et al. 2009) | [30:30]

**Study showing that everolimus enhanced response to the influenza vaccine in the elderly**: [mTOR inhibition improves immune function in the elderly](https://pubmed.ncbi.nlm.nih.gov/25540326/) | *Science Translational Medicine* (Mannick … Klickstein 2014) | [38:30, 45:00]

**Paper that found rapamycin enhanced the ability of a flu vaccine to protect the mice against a lethal dose of influenza**: [mTOR Regulation and Therapeutic Rejuvenation of Aging Hematopoietic Stem Cells](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4020596/) | *Science Signaling* (Chen, Liu, Liu & Zheng 2009) | [40:30]

**Paper showing immune benefits of rapamycin in mice that has been used as the basis for human trials**: [mTOR modulates the antibody response to provide cross-protective immunity to lethal influenza infections](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3883080/) | *Nature Immunology* (Keating et al. 2013) | [41:15]

**Data showing the effects of everolimus and RTB101 on antiviral gene expression**: [TORC1 Inhibition with RTB101 as a Potential Pan-Antiviral Immunotherapy to Decrease the Incidence of Respiratory Tract Infections Due to Multiple Respiratory Viruses in Older Adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6810249/) | *Open Forum Infectious Diseases* (Mannick et al. 2019) | [44:15, 56:30]

**First ITP study suggesting that rapamycin could extend lifespan in mice**: [Rapamycin fed late in life extends lifespan in genetically heterogeneous mice](https://pubmed.ncbi.nlm.nih.gov/19587680/) | *Nature* (Harrison et al. 2009) | [47:45]

**Article about reprogramming senescent cells**: [Age reprogramming and epigenetic rejuvenation](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6300877/) | *Epigenetics & Chromatin* (Singh & Newman 2018) | [54:30]

**Joan Mannick’s phase 2 study in 2018 studying rapalogs in humans for immune function**:  [TORC1 inhibition enhances immune function and reduces infections in the elderly](https://www.researchgate.net/publication/326339577_TORC1_inhibition_enhances_immune_function_and_reduces_infections_in_the_elderly#:~:text=TORC1%20inhibition%20enhances%20immune%20function%20and%20reduces%20infections%20in%20the%20elderly,-Article%20(PDF%20Available&text=Inhibition%20of%20the%20mechanistic%20target,immune%20function%20in%20model%20organisms.) (Mannick et al., 2018) [56:15]

**PROTECTOR study — the 2019 phase 3 study by resTORbio that failed to meet its endpoint**: [resTORbio Announces That the Phase 3 PROTECTOR 1 Trial of RTB101 in Clinically Symptomatic Respiratory Illness Did Not Meet the Primary Endpoint](https://www.globenewswire.com/news-release/2019/11/15/1947932/0/en/resTORbio-Announces-That-the-Phase-3-PROTECTOR-1-Trial-of-RTB101-in-Clinically-Symptomatic-Respiratory-Illness-Did-Not-Meet-the-Primary-Endpoint.html) | (globenewswire.com) [1:01:15]

**Paper showing that rapamycin can reverse periodontal disease in aging mice**: [Rapamycin rejuvenates oral health in aging mice](https://elifesciences.org/articles/54318) | *eLife* (An … Kaeberlein 2020) | [1:13:15]

**Peter’s podcast on periodontal disease**: [#166 – Patricia Corby, D.D.S.: Importance of oral health, best hygiene practices, and the relationship between poor oral health and systemic disease](https://peterattiamd.com/patriciacorby/) | Peter Attia, [*The Drive*](https://peterattiamd.com/podcast/) (June 21, 2021) | [1:14:30]

**Study about rapamycin reversing age-related hearing loss in mice**: [Rapamycin Added to Diet in Late Mid-Life Delays Age-Related Hearing Loss in UMHET4 Mice](https://www.frontiersin.org/articles/10.3389/fncel.2021.658972/full) | *Frontiers in Cellular Neuroscience* (Altschuler et al. 2021) | [1:17:00]

**Peter’s podcast discussing the ITP studies**: [#171 – Steve Austad, Ph.D.: The landscape of longevity science: making sense of caloric restriction, biomarkers of aging, and possible geroprotective molecules](https://peterattiamd.com/steveaustad/) | Peter Attia, [*The Drive*](https://peterattiamd.com/podcast/) (August 9, 2021) | [1:37:45]

**Paper describing Torin2**: [Characterization of Torin2, an ATP-competitive inhibitor of mTOR, ATM and ATR](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3760004/) | *Cancer Research* (Liu … Sabatini et al. 2013) | [2:09:45]

**Matt’s paper on the effect of rapamycin on the proteome and the phospho-proteome of mice**: [PKC downregulation upon rapamycin treatment attenuates mitochondrial disease](https://pubmed.ncbi.nlm.nih.gov/33324011/) | *Nature Metabolism* (Martin-Perez … Kaeberlin, & Villen 2020) | [2:16:00]

**Peter’s podcasts with David Sinclair about sirtuins and NAD** | [2:21:15]

- [#27 – David Sinclair, Ph.D.: Slowing aging – sirtuins, NAD, and the epigenetics of aging](https://peterattiamd.com/davidsinclair/) | Peter Attia, [*The Drive*](https://peterattiamd.com/podcast/) (November 5, 2018)
- [#70 – David Sinclair, Ph.D.: How cellular reprogramming could slow our aging clock (and the latest research on NAD)](https://peterattiamd.com/davidsinclair2/) | Peter Attia, [*The Drive*](https://peterattiamd.com/podcast/) (September 9, 2019)

§

## People Mentioned

- [Cynthia Kenyon](https://en.wikipedia.org/wiki/Cynthia_Kenyon) [14:30]
- [S. Jay Olshansky](https://en.wikipedia.org/wiki/S._Jay_Olshansky) [22:45, 25:30]
- [Nir Barzilai](https://en.wikipedia.org/wiki/Nir_Barzilai) [26:45, 1:06:45]
- [Thomas Perls](https://www.bumc.bu.edu/busm/profile/thomas-perls/) [27:15]
- [Joan Mannick](https://www.linkedin.com/in/joan-mannick-8089a614/) [38:30, 40:00, 44:156, 45:00, 48:15, 58:00, 1:03:15, 1:12:30]
- [Lloyd Klickstein](https://www.linkedin.com/in/lloyd-klickstein-69b26870/) [38:30, 40:00]
- [David Sabatini](https://biology.mit.edu/profile/david-sabatini/) [47:00, 2:02:45, 2:05:00, 2:19:45, 2:36:45]
- [Steve Austad](https://en.wikipedia.org/wiki/Steven_N._Austad) [1:06:45, 1:37:45]
- [Jonathan An](https://halo.dlmp.uw.edu/people/jonathan-an/) [1:15:45, 1:16:30]
- [Steve Horvath](https://en.wikipedia.org/wiki/Steve_Horvath) [1:35:15, 1:36:00]
- [Dudley Lamming](https://www.medicine.wisc.edu/people-search/people/staff/4646/Lamming_Dudley) [2:02:45, 2:05:00]
- [Richard A. Miller](https://medicine.umich.edu/dept/dcmb/richard-miller-phd) [2:04:00]
- [Vamsi Mootha](https://en.wikipedia.org/wiki/Vamsi_Mootha) [2:14:00]
- [Isha Jain](https://ishajainlab.com/team/) [2:14:00]
- [Judit Villen](https://www.gs.washington.edu/faculty/villen.htm) [2:16:00]
- [David Sinclair](https://en.wikipedia.org/wiki/David_A._Sinclair) [2:21:15, 2:23:15, 2:24:00]
- [Leonard P. Guarente](https://en.wikipedia.org/wiki/Leonard_P._Guarente) [2:22:45, 2:23:15, 2:24:00]
- [Yousin Suh](https://www.genetics.cuimc.columbia.edu/profile/yousin-suh-phd) [2:35:45, 2:36:15, 2:37:00]

§

![](https://peterattiamd.com/wp-content/uploads/2021/09/bio-image-mattk2-500x500.png)

##### Matt Kaeberlein, Ph.D.

Dr. Matt Kaeberlein is a Professor of Pathology, Adjunct Professor of Genome Sciences, and Adjunct Professor of Oral Health Sciences at the University of Washington. His research interests are focused on basic mechanisms of aging in order to facilitate translational interventions that promote healthspan and improve quality of life. He has published nearly 200 papers in top scientific journals and has been recognized by several prestigious awards, including a Breakthroughs in Gerontology Award, an Alzheimer’s Association Young Investigator Award, an Ellison Medical Foundation New Scholar in Aging Award, a Murdock Trust Award, a Pioneer in Aging Award, and the Vincent Cristofalo Rising Star in Aging Research. His contributions have also been recognized with Fellow status in the American Association for the Advancement of Science, the American Aging Association, and the Gerontological Society of America. Dr. Kaeberlein is a past President of the American Aging Association and has served on their Executive Committee and Board of Directors since 2012. He has also served as a member of the Board of Directors for the Federation of American Societies for Experimental Biology and is currently the Chair of the Biological Sciences Section of the Gerontological Society of America. Dr. Kaeberlein serves on the editorial boards for several journals, including *Science* and *eLife*. Dr. Kaeberlein’s scientific discoveries have generated substantial public interest, with featured stories in major media outlets including appearing on the front page of the New York Times, the Today Show, CNN, the UK Telegraph, Popular Science, Time Magazine,

Scientific American, NPR, USA Today, National Geographic, and many others. In addition to his primary appointments, Dr. Kaeberlein is the co-Director of the University of Washington Nathan Shock Center of Excellence in the Basic Biology of Aging, the founding Director of the Healthy Aging and Longevity Research Institute at the University of Washington, and founder and co-Director of the Dog Aging Project. [[kaeberleinlab.org](https://kaeberleinlab.org/people/matt-kaeberlein)]

Matt on Facebook: [Matt Kaeberlein](https://www.facebook.com/matt.kaeberlein)

Matt on Instagram: [@mkaeberlein](https://www.instagram.com/mkaeberlein/?hl=en)

Matt on Twitter: [@mkaeberlein](https://twitter.com/mkaeberlein?lang=en)