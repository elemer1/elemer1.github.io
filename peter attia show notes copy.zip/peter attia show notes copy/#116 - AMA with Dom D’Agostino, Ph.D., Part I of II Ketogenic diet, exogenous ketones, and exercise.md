# #116 – AMA with Dom D’Agostino, Ph.D., Part I of II: Ketogenic diet, exogenous ketones, and exercise

**Source:** [https://peterattiamd.com/domdagostinoama01/](https://peterattiamd.com/domdagostinoama01/)

---

##### Check out more content with Dom D’Agostino:

- *(July 16, 2018)* [Dom D’Agostino, Ph.D.: ketosis, n=1, exogenous ketones, HBOT, seizures, and cancer](/domdagostino/)
- *(June 22, 2020)* [AMA with Dom D’Agostino, Ph.D., Part I of II: Ketogenic diet, exogenous ketones, and exercise](/domdagostinoama01/)
- *(July 20, 2020)* [AMA with Dom D’Agostino, Ph.D., Part II of II: Ketosis for cancer and chronic disease, hyperbaric oxygen therapy, and the effect of ketosis on female health](/domdagostinoama02/)

Back by very popular demand for a special AMA episode, [ketosis](/ketosis-advantaged-or-misunderstood-state-part-i/) expert Dom D’Agostino joins Bob Kaplan, Peter’s Head of Research, to address many lingering questions about the ketogenic diet, [exogenous ketones](/experience-exogenous-ketones-2/), and exercise for overall health. Dom also shares valuable insights from his personal experience with training, supplements, intermittent fasting, and other nutritional strategies to optimize his own health and performance. If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA.  If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on the website [show notes](https://peterattiamd.com/domdagostinoama01) page. If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Dom’s recent and ongoing projects [3:00];
- Benefits of a ketogenic diet for an otherwise healthy person [7:00];
- Book recommendations for getting knowledgeable on the ketogenic diet [11:30];
- Best devices for measuring ketones [13:45];
- Genetic factors that influence how someone responds to the ketogenic diet [24:45];
- Ketogenic diet for those with the APOE e4 allele [28:15];
- Impact of long-term ketogenic diets on thyroid function [34:25];
- Low-carb and ketogenic diets for appetite control and weight management [39:00];
- Ketogenic diet and the microbiome [43:00];
- Comparing monounsaturated fat versus saturated fat on the ketogenic diet [45:55];
- Implications of long-term genetic and epigenetic adaptations to a ketogenic diet [47:45];
- Why some people see a rise in LDL-C and LDL-P when on a ketogenic diet and what they can do about it [50:15];
- Should someone with familial hypercholesterolemia consider the ketogenic diet? [55:00];
- Exogenous ketones—benefits, therapeutic uses, and ketone supplements that Dom has tested [56:45];
- Ketogenic protocols for management of traumatic brain injuries [1:06:00];
- Comparing the benefits and therapeutic uses of various medium-chain fatty acids—caprylic acid (C8), capric acid (C10), MCT oil, and coconut oil [1:08:45];
- Nootropics, caffeine, and other stimulants [1:16:15];
- Supplemental use of testosterone, DHEA, and creatine for muscle growth and performance [1:23:45];
- Impact of fasted-state training on strength and performance [1:30:15];
- Stacking exogenous ketones with MCTs for optimal effectiveness [1:33:30];
- BCAA supplements during a fast for muscle preservation [1:35:45];
- What app is Dom using for tracking his macros? [1:42:00];
- Getting enough micronutrients while on a ketogenic diet [1:47:15];
- Ideal macros for staying in ketosis while getting enough protein for strength training [1:48:15];
- Pros, cons, and ideal macros of one meal a day [1:51:15];
- Dom’s take on “carb backloading” [1:54:45];
- Dom’s take on “carb up” days for ketogenic dieters [2:01:00];
- Dom’s thoughts on the carnivore diet and the paleolithic ketogenic diet [2:05:30];
- Advantage of the ketogenic diet for extreme endurance athletes [2:10:30];
- Impact on strength, power, and performance of the adaptation period to the ketogenic diet [2:14:00];
- Fasted-state elevation in growth hormone and its impact on training [2:17:45];
- Is it possible to build muscle on a ketogenic diet? [2:23:30];
- Why Dom took a year off from weight training [2:28:00];
- What does Dom do for cardio exercise? [2:30:45];
- Protocols for hard training recovery [2:33:15];
- Dom’s personal approach to fasting, time-restricted eating, and sleep [2:35:45];
- People, books, and other resources that shaped Dom’s training and nutrition [2:38:45]; and
- More.

§

The Peter Attia Drive

Part I of II: Ketogenic diet, exogenous ketones, and exercise

§

## Show Notes

## Dom’s recent and ongoing projects [3:00]

**The main objective in last 2 years**: Trying to move the laboratory science into human applications

**Projects**:

[*NASA Extreme Environment Mission Operations*](https://en.wikipedia.org/wiki/NEEMO) *research*

- Dom was a crew member for [NEEMO 22](https://en.wikipedia.org/wiki/NEEMO#NEEMO_22:_June_18%E2%80%9327,_2017)
- His wife was a crew member for [NEEMO 23](https://en.wikipedia.org/wiki/NEEMO#NEEMO_23:_June_10%E2%80%9322,_2019)
- This project is evaluating the effects of hyperbaric environments, extreme environments on human physiology
- They now have an IRB protocol for cognitive function, body composition, gut microbiome, sleep, heart rate variability, and stress

*Effects of ketones on cancer cachexia*

- They are looking at the effects of ketones on mitigating cancer [cachexia](https://en.wikipedia.org/wiki/Cachexia) and wasting associated with metastatic cancer
- Dom just [published a manuscript](https://onlinelibrary.wiley.com/doi/full/10.1002/jcsm.12554)

*Metabolic therapies for various genetic diseases*

- Example being [Kabuki syndrome](https://ghr.nlm.nih.gov/condition/kabuki-syndrome)
- They are developing ketone metabolic therapies as a means to treat these diseases not only from a metabolic perspective, but as a means to influence epigenetic pathways that may be used to treat the disease
- Ketones may be a form of metabolic [“epigenetic therapy” for genetic disorders like Kabuki syndrome](https://www.pnas.org/content/114/1/125)

## Benefits of a ketogenic diet for an otherwise healthy person [7:00]

**Intermittent ketosis**

- The main benefit is that it promotes **metabolic flexibility**
- Most people are adapted to frequent carbohydrate feedings
- And they are not adapted to using fat as a major energy source during times of limited carbohydrate availability or calorie availability during periods of fasting
- Ketosis (and/or fasting) activates a genetic program that allows you to burn fat and make ketones more efficiently
- It may take some time, but you have an innate ability to be metabolically flexible, so the more you do intermittent ketosis (or fasting), the more benefits you derive from it over time

**Glucose-ketone index and insulin suppression**

**⇒** [The glucose ketone index calculator: a simple tool to monitor therapeutic efficacy for metabolic management of brain cancer](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-015-0009-2)

- The thing to target would be the [**glucose-ketone index**](https://keto-mojo.com/glucose-ketone-index-gki/)
  - For example, you could restrict calories by 50% on a ketogenic diet and do that for six days a month and achieve, a **glucose-ketone index between 1 and 2**
- Insulin suppression also occurs
- Doing a restricted ketogenic diet combined that with time-restricted feeding, you’re hitting all the major drivers of the benefits that you’d get from fasting such as:
  - suppressed mTOR
  - suppressed insulin
  - It’s also probably stimulating autophagy

**\*Suggestion from Dom**: Once a month, try to do 5-7 days of a ketogenic diet restricting calories by 50%

## Book recommendations for getting knowledgeable on the ketogenic diet [11:30]

- **General info**: [The Ketogenic Bible](https://www.amazon.com/gp/product/1628601043/ref=as_li_qf_asin_il_tl?ie=UTF8&tag=ketonutrition-20&creative=9325&linkCode=as2&creativeASIN=1628601043&linkId=3d8c45c58461f5b787d05d42d262c7ef)—comprehensive overview of the ketogenic diet and recipes
- **For the athlete**: [The Art and Science of Low Carbohydrate Performance](https://www.amazon.com/gp/product/0983490716/ref=as_li_qf_asin_il_tl?ie=UTF8&tag=ketonutrition-20&creative=9325&linkCode=as2&creativeASIN=0983490716&linkId=88d284f8c3c5d8eece17c7b9e0e8116f) by Jeff Volek and Stephen Phinney – “book that really influenced me”
- **For the layman**: [Keto Answers](https://www.amazon.com/Keto-Answers-Simplifying-Everything-Confusing/dp/1544504624/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=)—great book for the layman, defines modified ketogenic diet, recipes, tips, troubleshooting, etc.
- **Clinical info**:
  - [Ketogenic Diet and Metabolic Therapies](https://www.amazon.com/Ketogenic-Diet-Metabolic-Therapies-Expanded/dp/0190497998)—for listeners that are interested in the science
  - [The Ketogenic and Modified Atkins Diets, 6th Edition: Treatments for Epilepsy and Other Disorders](https://www.amazon.com/Ketogenic-Modified-Atkins-Diets-Treatments/dp/1936303949/ref=sr_1_2?dchild=1&qid=1591031117&refinements=p_27%3AEric+Kossoff+MD&s=books&sr=1-2&text=Eric+Kossoff+MD) by Dr. Eric Kossoff – for those interested in a *modified ketogenic approach* from a clinical perspective
- **For Alzheimer’s**: [Complete Book of Ketones](https://www.amazon.com/gp/product/1684421608/ref=as_li_qf_asin_il_tl?ie=UTF8&tag=ketonutrition-20&creative=9325&linkCode=as2&creativeASIN=1684421608&linkId=d9f84654357db2e3e0138ae80858ef26)

## Best devices for measuring ketones [13:45]

**Urine tests**

- [The Siemens Multistix SG](https://www.cliawaived.com/siemens-bayer-multistix-8-sg.html)
  - Pretty good for a “yes or no” if you’re in ketosis

**Blood tests**

- [Precision Xtra](https://abbottstore.com/precision-xtra-blood-glucose-ketone-monitoring-system-1-pack-9881465.html)
  - well validated, very reliable
  - may be measuring slightly lower than an official lab test
- [Keto-Mojo](https://bestketonetest.com/?afmc=2b&utm_campaign=2b&utm_medium=affiliate&utm_source=leaddyno)
  - Dom likes this one because it includes GKI ([glucose-ketone index](https://keto-mojo.com/glucose-ketone-index-gki/))
  - Strips are less expensive
  - Keto-Mojo may be measuring slightly higher when in the low ranges
- **Note**: When ketones get into the 2 to 3 range, the Precision Xtra and the Keto-Mojo will correlate

**Breath acetone testing**

- [BioSense Breath Ketone Analyzer](https://mybiosense.com/)
  - “*the most quantitative breath meter*”
  - It’s “exceptionally good” and correlates well with BHB **when in a fasted state**
  - But if you have alcohol, a meal prior, or even chewing gum prior to the test it will not be accurate
  - Dom says this is his second favorite way to measure ketones after measuring blood
  - Breath acetone is a **very strong indicator of fat oxidation**
  - The acetone is “basically derived from fat”

–*What’s happening when you’re measuring acetone?*

- When in ketosis, you have beta-hydroxybutyrate in the blood
- And as BHB rises, so does acetoacetate (ratio is about 4 to 1)
- Acetoacetate can then spontaneously decarboxylate into **acetone**
- Note: when you’re “using” ketones, then your acetone would go down
  - For example, exercise:
    - Exercise can really lower my acetone level breath ketone as it does with blood beta-hydroxybutyrate
    - But when you are at rest, levels will come back up because you’ve ramped up
      - Metabolism
      - fat oxidation
      - Ketogenesis
      - and you start building up ketones, *but you’re not using them*

**George Cahill’s** [**40-day fasting experiment**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2194504/pdf/tacca00002-0213.pdf)

–*Interesting takeaways:*

- Glucose was relatively stable throughout
- IV infusion of 20 IU’s of insulin caused fatty acids and ketones in the blood to go sharply down
  - In other words, ketogenesis and fat mobilization for fuel is really *a function of insulin suppression*
- This has implications in regards to exogenous ketones
  - Does exogenous ketones elevate insulin?
  - If yes, will it then decrease your own endogenous ketone production?
    - Dom says exogenous ketones have many therapeutic applications
    - So it’s really important to understand what’s going on in the liver, in the muscle, and in the brain when delivering exogenous ketones
    - Dom’s been focusing on that question in himself and in the lab

## Genetic factors that influence how someone responds to the ketogenic diet [24:45]

How an individual responds to a ketogenic diet and/or fasting can depend on certain **genetic factors**

- Some people don’t adapt as well as others to keto diets/fasting
- And by “adapt”, Dom means they don’t adapt well to an insulin suppression state that would allow access to the body’s fuel stores in terms of fatty acid mobilization and ketogenesis

Factors include…

- Beta-oxidation defects affect some people
- There are about 30+ different enzymes that can be potentially affected by a wide range of genetic diseases or [SNPs](https://en.wikipedia.org/wiki/Single-nucleotide_polymorphism)
- A class of enzymes called [ACADs](https://en.wikipedia.org/wiki/Acyl-CoA_dehydrogenase) such as MCAD, LCAD, and VLCAD and those are disorders of not being able to metabolize medium chain fatty acids
- [CPT1](https://en.wikipedia.org/wiki/Carnitine_palmitoyltransferase_I#Clinical_significance) and [CPT2](https://en.wikipedia.org/wiki/Carnitine_palmitoyltransferase_II_deficiency) deficiency

[Hormone-sensitive lipase](https://en.wikipedia.org/wiki/Hormone-sensitive_lipase)

- It’s is induced by fasting and by the [catecholamines](https://en.wikipedia.org/wiki/Catecholamine) that are released by fasting
- Stimulation of [beta-1 adrenergic receptor](https://en.wikipedia.org/wiki/Beta-1_adrenergic_receptor) and [beta-2 adrenergic receptor](https://en.wikipedia.org/wiki/Beta-2_adrenergic_receptor) activates hormone sensitive lipase
- That’s why things like [Beta-adrenergic agonist](https://en.wikipedia.org/wiki/Beta-adrenergic_agonist) like [Ephedrine](https://en.wikipedia.org/wiki/Ephedrine) or [Clenbuterol](https://en.wikipedia.org/wiki/Clenbuterol) are very powerful fat burning agents.
- People who poorly adapt to a ketogenic diet and/or fasting may have lower sensitivity—meaning their hormone sensitive lipase is not activated by catecholamines as robustly as other people

[Lipoprotein lipase](https://en.wikipedia.org/wiki/Lipoprotein_lipase)—another thing to look at

- Low insulin with high glucagon would stimulate that.
- In some people it’s very robust and in other people it’s not.
- And I think this is one of the biomarkers that we need to look at for people that adapt well to a ketogenic diet.

[Beta-ketothiolase deficiency](https://en.wikipedia.org/wiki/Beta-ketothiolase_deficiency)—a genetic disease where you cannot make ketones

- That person would need to eat frequent meals
- And if those people are subjected to fasting or even carbohydrate restriction, they become
  - Extremely tired
  - Hypoglycemic, and
  - Have seizures

## Ketogenic diet for those with the APOE e4 allele [28:15]

*For someone who has two copies of* [*APOE e4*](https://pubmed.ncbi.nlm.nih.gov/8346443/)*, what do they need to think about or do differently when it comes to the ketogenic diet?*

**First, Dom mentions a couple resources**:

- [Dr. Dale Bredesen](https://www.apollohealthco.com/dr-bredesen/) has influenced his thinking in this area
- [Dr. Mary Newport](https://coconutketones.com/mary-newport-md-bio-books/) as well
  - She wrote a [book](https://www.amazon.com/Complete-Book-Ketones-Practical-Supplements/dp/1684421616/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) about using ketones as a therapy for Alzheimer’s disease (AD)
  - She also has a [book](https://www.amazon.com/Alzheimers-Disease-There-Story-Ketones/dp/1681626802/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) about her husbands battle with AD

**Dom’s take**:

- If you have one APOE e4 (and especially if you have two) the **main thing to do is manage glucose and insulin**

–*Important things important to track*:

- Hemoglobin A1c is a really good indicator
- Triglycerides
- Your level of systemic inflammation using a high sensitivity C-reactive protein (hs-CRP) test
- You want these to all be as low as possible: glucose, hemoglobin A1C, triglycerides, insulin, hs-CRP
- Dom’s uses this at-home test: [ZRT Labs CardioMetabolic Test Kit](https://www.amazon.com/ZRT-Cardiometabolic-Profile-Blood-Insulin/dp/B01NH11LMW?SubscriptionId=AKIAIOCEBIGP6NUBL47A&camp=2025&creative=165953&creativeASIN=B01NH11LMW&linkCode=xm2&tag=ketonutrition-20)

–*Another important metric:* ***Blood pressure***

- High blood pressure correlates with poor outcomes if you’re APOE e4 positive

**High LDL when on a ketogenic diet**

- Some people experience are huge spike in LDL when on a keto diet
- If that is the case, a few suggestions would be…
  - Limit saturated fat
  - Maybe take a low dose of a statin (a half a pill two times per week, like on Monday, Thursday)
  - Rather than ketogenic, modify the diet to be higher protein, moderate fat, low carb diet may be with the fat source coming in the majority form of monounsaturated fat

**Sleep and exercise**

- Both are important for prevention of Alzheimer’s disease, says Dom
- Sleep might be **most important** for people with one or two copies of APOE e4 because it’s preventing amyloid accumulation and we know that the glymphatic system helps to clear out some of the toxins and amyloid accumulation as we age

## Impact of long-term ketogenic diets on thyroid function [34:25]

**Long-term keto diets and thyroid function**

- Dom has observed that some people see an see increase in their [reverse T3](https://en.wikipedia.org/wiki/Reverse_triiodothyronine) when on a keto diet (as well as when intermittent fasting)
- Suppression of insulin can contribute to an increase in [reverse T3](https://en.wikipedia.org/wiki/Reverse_triiodothyronine) (which could suppress thyroid function)
- A side effect of elevated reverse T3 is a decrease in body temperature and feeling cold

*Ways to prevent this*:

- Do not reduce calories too quickly
- When switching to a low carb diet, don’t eliminate all carbs immediately
- If you’re doing a calorie restricted ketogenic diet, you might do a “refeed” every 3 to 4 days where you just eat a higher volume of keto-friendly foods
  - This would activate pathways that would prevent an increase in reverse T3
  - It also could allow your metabolism to keep cranking and prevent a slowing of metabolism commonly seen with long term calorie restriction
- Certain micronutrients can help with maintaining thyroid function on a ketogenic diet
  - High selenium and high iodine foods (salt) are important
  - Dom’s favorites are **sardines**, **liver**, and **Brazilian nuts**

Dom also points out that the **some people** have high reverse T3 even when **not calorie restricted**

- Which implies that the thyroid issue may have more to do with the suppression of insulin than it does the restriction of calories
- It’s more common in women than men
- This suppression of thyroid probably affects up to 40% of women, says Dom
- But it’s hard to deconstruct what’s happening because some of them are over-exercising or calorie restricted or taking intermittent fasting a little too often.
- Dom suggests doing these things intermittently rather than continuously
- “And your body adapts to that state if you’re doing it all the time, so I believe it’s important to use it intermittently.”

## Low-carb and ketogenic diets for appetite control and weight management [39:00]

**Bob’s experience with the keto diet**

- Bob gained about 30 pounds in college
- First, he tried just eating less, moving more, and found himself hungry and tired all the time
- Next, he tried the Atkins diet (meat, fish, fowl, eggs, cheese, leafy green vegetables) with no restriction on volume
- He was surprised at how he was never too hungry and never too full
- For the first time he found himself almost “forgetting to eat” at times
- The keto diet lowers insulin and glucose to a point that allows you to then use your own body fat as fuel source (especially when you have fat to lose)
- In a way, you’re not really calorie restricted—“*I almost think of it as you’re eucaloric, but more of your calories are coming from within.*”
- **Important**: It might be better to give your body time to get into ketosis and/or adapt to using internal fat stores before dropping calories significantly

**Dom on ketogenic diets for appetite control and weight management**

- The ketogenic diet allows you to control your appetite instead of your appetite controlling you
- Dieting by cutting calories but still eating refined carbs can lead to people becoming “neurotic about food” and can produce really disastrous and damaging eating behaviors
- Low carb eating (not necessarily ketogenic) can really help to attenuate a lot of those cravings and is better for weight control in Dom’s opinion

> “If you restore insulin sensitivity. . .you’re better able to access and burn fat, so that becomes a key feature.”

## Ketogenic diet and the microbiome [43:00]

*What’s the long-term impact of a ketogenic diet on the microbiome?*

*How to maintain proper gut motility, microbiome diversity on a ketogenic diet?*

**The ketogenic diet and the microbiome**

- Some people respond very well clinically with a carnivore diet, i.e., no [soluble fiber](https://en.wikipedia.org/wiki/Dietary_fiber) or “fuel” for your intestinal bacteria
- But fiber does have an important role in the microbiome
- After eaten, soluble fiber breaks down to short-chain fatty acids ([butyrates](https://en.wikipedia.org/wiki/Butyrate), [acetate](https://en.wikipedia.org/wiki/Acetate), [propionate](https://en.wikipedia.org/wiki/Propionate))
- The colonocytes (epithelial cell of the colon) then use that for fuel
- Butyrates are also an epigenetic regulator in the form of [histone deacetylase (HDAC) inhibitor](https://en.wikipedia.org/wiki/Histone_deacetylase_inhibitor)
- Acetate and propionate also play an important role so that microbiome diversity is key

Dom’s take:

- For Dom, personally, getting some amount of fiber is important
- That being said, Dom says some people respond very well clinically to a diet that’s completely devoid of carbohydrates, such as in the case of those with [small intestinal bacterial overgrowth](https://en.wikipedia.org/wiki/Small_intestinal_bacterial_overgrowth) (SIBO)
- But generally, he would not recommend to completely eliminate fiber all the time
- Having some amount of fiber in the diet promotes microbiome diversity
- But it doesn’t necessarily all have to come from plant foods
- You can get [probiotics](https://en.wikipedia.org/wiki/Probiotic) from fermented foods, like *sour cream* with cultures, or *yogurt* with certain cultures
- But [prebiotic fiber](https://en.wikipedia.org/wiki/Prebiotic_(nutrition)) is really important for the long term, says Dom

> “Some prebiotic fiber is really important long term for gut motility, microbiome diversity, and just for the overall microbiome.”

## Comparing monounsaturated fat versus saturated fat on the ketogenic diet [45:55]

- When first going onto a keto diet, he was following a mainly **dairy fat** based ketogenic diet and he noticed a skyrocketing of LDL
- His triglycerides were also pretty high
- Dom notes that he still eats a very high level of saturated fat
- However, he has made an effort to add more monounsaturated fats
- And that transition from saturated fat to more monounsaturated fat has given him a more favorable lipid profile
- So for those seeing “abnormalities” in their lipid profile, that would be something Dom recommends
- Dom’s approach is to simply limit his saturated fat intake to under 100 grams of saturated fat for one or two days a week

**What about polyunsaturated fat?**

- Admittedly, he doesn’t pay a whole lot of attention to PUFA
- He mainly just focuses on getting a lot of omega-3
- His omega-3 to omega-6 ratio is probably about 2:1
- He eats a lot of fish which brings up his omega-3 intake
- He also takes an omega-3 supplement especially on days when not eating fish

## Implications of long-term genetic and epigenetic adaptations to a ketogenic diet [47:45]

- A lot of unknowns on this topic
- That said, there are clearly some epigenetic modifications going on with a long-term ketogenic diet which may have implications as it relates to *genetic diseases*
  - *For example*, there is likely some activation of a genetic program to stimulate a wide range of fatty acid oxidation enzymes like [hormone-sensitive lipase](https://en.wikipedia.org/wiki/Hormone-sensitive_lipase)

*The following indicators suggest that when on a keto diet you’re really* ***activating epigenetic programs that are shifting your metabolism away from glycolytic to more fatty acid oxidation****, ketogenic, ketogenesis, ketolysis, and ketone transport*:

- Accelerating beta oxidation
- Ketogenesis is likely upregulated over time
- Ketolysis (breaking ketones down for energy in the mitochondria to make ATP) is upregulated
- Ketone transport via the monocarboxylic acid transporters is [upregulated](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6543248/) over time
- Increase in the proteins that are transcriptional translation of proteins that are associated with the MCTs

⇒ Study showing ketones may be a form of [metabolic “epigenetic therapy” for genetic disorders like Kabuki syndrome](https://www.pnas.org/content/114/1/125)

**The next frontier of research into a long-term keto diet**

*Dom’s really interested in specific genes that are impacting…*

- Oncogenic transformation
- Neuroprotection
- Amyloid degenerative processes associated with dopaminergic neurons degenerating

## Why some people see a rise in LDL-C and LDL-P when on a ketogenic diet and what they can do about it [50:15]

**Mechanism by which LDL seems to skyrocket in certain people on a keto diet**

- Dom admits this is a confusing topic which needs to be further investigated

–*What you can do about it*:

- For Dom, he drops his saturated fat intake down to below 100 grams for a few days a week
- For others, saturated fat might need to be dropped to close to 25 grams per day

**The important role of LDL particles (LDL-P)**:

- It’s an important transport molecule for things like triglycerides and phospholipids
- It also aids in growth and repair

**Curious cases of high and low LDL**

- In the case of athletes…
  - They tend to have a higher LDL when on keto because there’s a lot of turnover associated with the breakdown of protein and tissue, especially with hard training
- In cancer patients…
  - Dom has observed that cancer patients have a remarkably low LDL which is correlated with a high tumor burden
  - Some indication that having a low LDL predisposes you to cancer
    - Initial thought was that it was because of some of the statins being used
    - But recent reports suggest that it’s independent of statins
  - ⇒ Science Daily: [Low LDL cholesterol is related to cancer risk](https://www.sciencedaily.com/releases/2012/03/120326113713.htm)

**What does LDL rise dramatically for some people?**

- Dom says the reason for the skyrocketing LDL in the body is still unclear
- [Dave Feldman](https://twitter.com/DaveKeto?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) ([previous podcast guest](https://peterattiamd.com/davefeldman/)) has a hypothesis that he refers to as [lean mass hyper-responders](https://peterattiamd.com/davefeldman/)
  - Due to higher trafficking of fatty acids through VLDL secretion, the VLDLs are getting pumped out by the liver and they’re delivering triglycerides
  - The lean person doesn’t have a lot of adipose to draw from
  - And so there’s just really a lot of turnover of the VLDLs in the liver
  - The VLDLs then become LDLs, so essentially they’re remnants of those VLDLs, and they stick around a lot longer in the blood
  - So if you look in someone’s bloodstream, they’re going to show up with an elevated LDL cholesterol or LDL particle number as well in particular.

⇒ Phinney and Volek’s paper: [Paradox of Hypercholesterolaemia in Highly Trained, Keto-Adapted Athletes](https://pubmed.ncbi.nlm.nih.gov/30305928/)

**But does a high LDL-p even matter when other markers improve?**

- Dom is *partly* convinced that it’s not something to be really concerned about if it’s independently elevated
- Especially when arguably more important biomarkers are unaffected or even improved with a ketogenic diet, such as:
  - triglycerides down
  - HDL the same or slightly elevated
  - inflammation down
  - insulin down
- Furthermore, it’s pretty common that in the first three months of a keto diet the LDL numbers will go up only to come down and normalize later on

> “There just needs to be more research on this, but I’m not particularly concerned that the LDL is atherogenic.”

## Should someone with familial hypercholesterolemia consider the ketogenic diet? [55:00]

***The keto diet is “worth considering” for someone with*** [***FH***](https://en.wikipedia.org/wiki/Familial_hypercholesterolemia)**, but Dom has some important advice**:

\*These tips are especially important for someone over 70 years old\*

- 1) Don’t transition from high carb directly to a ketogenic diet
  - Instead, cut carbs over the course of 2 to 3 weeks
- 2) Comprehensive blood work should be done to indicate normal liver function, kidney function, etc.
- 3) Consider working with a ketogenic dietician (At least for the first week or so)
  - There’s a lot of trial and error with the ketogenic diet and you can really improve the learning curve
  - You can find a [list of dieticians](https://www.ketonutrition.org/consulting) on [KetoNutrition.org](https://www.ketonutrition.org/)

⇒ Dom’s new study: [Metabolic Switching Is Impaired by Aging and Facilitated by Ketosis Independent of Glycogen](https://pubmed.ncbi.nlm.nih.gov/32369441/?from_term=ketogenic+diet%2C+elderly&from_sort=date&from_pos=2)

**More resources**:

- [Art De Vany](https://en.wikipedia.org/wiki/Arthur_De_Vany) is in his 70s and he’s doing well on an approach of fitness training while on a keto diet plus intermittent fasting
- Dom recommends the IHMC podcast episodes with Art De Vany:
  - [EPISODE 30](https://www.ihmc.us/stemtalk/episode-30/): ART DE VANY TALKS ABOUT HOLLYWOOD ECONOMICS, THE PALEO WAY, AND THE ROLE OF FITNESS AND DIET IN AGING
  - [EPISODE 105:](https://www.ihmc.us/stemtalk/episode-105/) ART DE VANY TALKS ABOUT HEALTHSPAN, LIFESPAN AND HEALING THE WOUNDS OF AGING

## Exogenous ketones—benefits, therapeutic uses, and ketone supplements that Dom has tested [56:45]

**What are some potential benefits from taking exogenous ketones?**

Still many unknowns, but benefits are likely very numerous for different medical conditions:

- Seizures
- Metabolic disorders are very responsive
- Glucose metabolism disorders, for example, where the ketones function as alternative energy substrates
- Range of neurological disorders where the underlying etiology is associated with glucose hypometabolism and/or neuroinflammation
- Traumatic brain injury (TBI)
- Enhanced wound healing
- Metabolic management of cancer
- Appetite suppression for weight loss

*-Traumatic brain injury (TBI)*

- This could be an example of neuroinflammation
- With TBI comes a decoupling of metabolism as it relates to pyruvate dehydrogenase function, so a decrease in PDH function and overall PDH levels
- The glucose transporter in neurons tends to be internalized when you have a brain injury or neuroinflammation
- And ketone bodies would bypass that and help to restore and preserve brain energy metabolism

*-Wound healing*

- Dr. Shannon Kesl [did work](https://scholarcommons.usf.edu/cgi/viewcontent.cgi?article=7300&context=etd) showing that adding exogenous ketones to a standard diet of high carbohydrates enhances wound healing (in an ischemic model of wound healing)
- But it also happened in *younger* animals too with trends for enhanced wound healing (work yet to be published)

–*The glucose lowering effect of ketones*

- Dom calls this the **most important** observation
- Consuming exogenous ketones can lower glucose and help people achieve a [GKI](https://keto-mojo.com/glucose-ketone-index-gki/) that we know could be therapeutic
  - That has implications for the **metabolic management of cancer**
  - Also helpful in terms of appetite suppression for those needing to **lose weight**
    - A lack of appetite is associated with just an elevation of ketones

**Exogenous ketones in the form of ketone salts**

- A [ketone salt](https://en.wikipedia.org/wiki/Exogenous_ketone#Ketone_salts) is the most common form of [exogenous ketones](https://en.wikipedia.org/wiki/Exogenous_ketone)
  - (Another form is [ketone esters](https://en.wikipedia.org/wiki/Exogenous_ketone#Ketone_esters))
- A ketone salt is when beta hydroxybutyrate is combined ionically with an electrolyte such as sodium, potassium, calcium, or magnesium
- They are ingested orally
- Typically get your BHB levels in the range of one to two millimolar of **D-β-hydroxybutyrate**
- Many of the products out there are **racemi**c, so they include both D-β-hydroxybutyrate and L-β-hydroxybutyrate and
- **\*Important Note**: Ketone meters only read the amount of the “D” enantiomer
  - So, if you took a racemic ketone mixture and you see 2.0 millimolar of D beta-hydroxybutyrate on the meter, your total beta hydroxybutyrate are likely 4.0 millimolar
- Dom suggests targeting a BHB level between 1.0-2.0
- Many suggest going as high as 2.0-5.0, but Dom calls that unphysiological ⇒ “*I think that it’s an extra amount of energy that the body has to do something with. I believe you’re spending resources to eliminate that energy in the body and they could probably do bad things.*”

**Benefits of exogenous ketones**:

- From an everyday perspective, they can be a good source of energy
- Stimulating a mild state of ketosis with exogenous ketones may be turning on genes and having signaling effects that are promoting a healthier metabolic state over time
- Many researchers in this field adamantly believe that beta hydroxybutyrate is a pretty potent longevity molecule
  - Dom says he’s “waiting for the science” on that claim
  - However, if using exogenous ketones to optimize and preserve metabolic health then that can contribute to longevity

**Different functions of the D-β-hydroxybutyrate and L-β-hydroxybutyrate**

- A pure D beta-hydroxybutyrate ester was not very efficacious against [oxygen toxicity seizures](https://en.wikipedia.org/wiki/Oxygen_toxicity)
- The most robust effect in preventing oxygen toxicity seizures is a molecule that elevated D and L beta-hydroxybutyrate in the blood, and also [acetoacetate](https://en.wikipedia.org/wiki/Acetoacetic_acid) all at the same level
- Acetoacetate has a remarkable anti-convulsive effect

–*If you consume a* ***racemic*** *mixture of beta hydroxybutyrate…*

- The D form gets metabolized and used in skeletal muscle more efficiently, i.e., it’s generating more ATP resulting in greater metabolic efficiency
- Whereas he L beta-hydroxybutyrate sticks around in tissues longer and has beneficial signaling effects such as…
- Suppression of the NLRP-3 inflammasome
- Histone deacetylase activity
- It may also activate different receptors that have anti-inflammatory effects (e.g., [GPR109A receptor](https://en.wikipedia.org/wiki/Hydroxycarboxylic_acid_receptor_2))

–*In summary,*

- **L-beta-hydroxybutyrate** is more therapeutic… it could be a drug-like molecule that’s a drug that’s derived from an endogenously made molecule, but you’re delivering it and having drug-like effects
- The **D form** may be more appropriate for an an athlete

\*\*\*

**List of ketone products that Dom has tested**: [KetoNutrition.org/ketones](https://www.ketonutrition.org/ketones)

**Dom’s recent review article**: [History and Rationale for Ketone Esters and Metabolic Alternatives.](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6803688/)

**Interesting study in Lancet using Ketone Salts**: [D,L-3-hydroxybutyrate treatment of multiple acyl-CoA dehydrogenase deficiency (MADD)](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(03)13105-4/fulltext)

## Ketogenic protocols for management of traumatic brain injuries [1:06:00]

In the case of a [traumatic brain injury](https://en.wikipedia.org/wiki/Traumatic_brain_injury)…

- 80% of people with **penetrating** traumatic brain injuries have seizures
- To prevent seizures, the ketogenic diet makes sense, but it’s hard to implement says Dom
- A more sustainable concept would be a **low carb diet with supplemental ketones** (esters or salts)
- The goal would be to achieve a **glucose ketone index of 1.0 to 2.0**
  - This would lower inflammation
  - And provide an alternative energy source to the brain

*Should you dose someone with ketones* ***immediately after the injury****?*

- I don’t know the answer to that question, says Dom
- However, it might be prudent to do so in a way that’s not shooting ketones up to like five or six millimolar, but I think a mild state of ketosis anywhere between one to three millimolar would be beneficial

**Long term management of TBI**

*Salt or ester?*

- The easiest way to do that is with a ketone ester
- However, a ketone salt is more efficacious therapeutically

*Salts plus MCTs*

- Dom says that the best approach is to mix the ketone salt with [medium-chain triglycerides](https://en.wikipedia.org/wiki/Medium-chain_triglyceride) (MCT oil or MCT oil powder) in **one-to-one combination**
- Exogenous ketones provides immediate substrate and the MCT molecule is stimulating ketones to be made in the liver
- Whereas if you bolus ketone salts, you could be potentially **reducing** hepatic ketone production

## Comparing the benefits and therapeutic uses of various medium-chain fatty acids—caprylic acid (C8), capric acid (C10), MCT oil, and coconut oil [1:08:45]

**Caprylic acid vs. capric acid**

- [Caprylic acid](https://en.wikipedia.org/wiki/Caprylic_acid) (aka C8, aka octanoic acid) is **more ketogenic** than [capric acid](https://en.wikipedia.org/wiki/Decanoic_acid) (aka C10, aka decanoic acid)
- In self experiments, Dom sees about 20% more of an increase in ketones with C8 vs C10
- But C10 may have [anti-seizure benefits](https://pubmed.ncbi.nlm.nih.gov/26608744/) outside of the ketone production

**MCTs**

- [Medium-chain triglycerides](https://en.wikipedia.org/wiki/Medium-chain_triglyceride) (MCT) are not metabolized like long-chain fatty acids (LCFA)
- LCFA are packaged into chylomicrons and absorbed in the [lacteal glands](https://en.wikipedia.org/wiki/Lacteal) before getting into circulation
- MCTs, on the other hand, go right to the liver by a hepatic portal circulation and stimulates beta oxidation of fatty acids very robustly
- Not only do you get a burst of ketones entering circulation, but the MCTs also enter circulation and MCTs can cross the [blood-brain barrier](https://en.wikipedia.org/wiki/Blood%E2%80%93brain_barrier) (BBB)
- In terms of energy for the brain, the C8 would offer a bigger advantage than C10
- However, C10 may have independent advantages in addition to being able to cross the BBB
- **Dom recommends** just going with the cheaper MCT oil (he like the [NOW brand](https://www.amazon.com/NOW-Foods-MCT-100-Oil/dp/B00KPZXER6))

**Coconut oil**

*-What’s the makeup of coconut oil in terms of C8, C10, etc.?*

- Depending on the coconut oil, about 20% to 30% MCTs

*-Lauric acid*

- Coconut oil has [lauric acid](https://en.wikipedia.org/wiki/Lauric_acid) which may have immune boosting effects
- Lauric acid encapsulates and surrounds viruses and can have [antiviral effects](https://ateneo.edu/ls/sose/sose/news/research/potential-coconut-oil-and-its-derivatives-effective-and-safe-antiviral)
- Dom says he’s “relatively convinced that the science is there”
- That would give credence to the idea that the coconut oil should ALSO be delivered with the MCT

*-Mary Newport’s* [*book*](https://www.amazon.com/Alzheimers-Disease-There-Story-Ketones/dp/1681626802/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) *mentioned she was giving her husband a lot of coconut oil*

- She gave her husband coconut oil and documented an improvement in a well-established test for Alzheimer’s disease (the [clock drawing test](https://www.verywellhealth.com/the-clock-drawing-test-98619), and the [Mini-Mental Status Exam](https://www.alz.org/alzheimers-dementia/diagnosis/medical_tests))
- Plus, he has an acute improvement in just the matter of a day or two
- Dom had dinner with [Mary Newport](https://coconutketones.com/mary-newport-md-bio-books/) and her husband 10 years ago
  - He watched her husband consume a vial of MCT plus coconut oil and saw his tremors to slow down as well as his facial expressions become more animated
- Dom says that Steven was evidence that there are people that are responsive to a metabolic intervention
- Dom estimates about **30% to 50% of people are fairly responsive to a metabolic intervention**

**Ketone esters**

- Ketone esters are 10 times more potent than coconut oil
- Dom says we need to direct research funding into evaluating ketone esters as a potential therapy, not only for Alzheimer’s disease, but for a wide range of neurological diseases

**Brain energy metabolism**

- [Dr. Stephen Cunnane](https://u.osu.edu/ketodiet/speaker-bios/stephen-cunnane-phd/) is spearheading research into imaging brain energy metabolism
- Instead of a FDG-PET, they can essentially look at ketone metabolism via a dual PET imaging to look at **glucose versus ketone metabolism**

⇒ Study by Stephen Cunnane: [Ketogenic Medium Chain Triglycerides Increase Brain Energy Metabolism in Alzheimer’s Disease](https://pubmed.ncbi.nlm.nih.gov/29914035/)

*-The bottom line is this…*

- Glucose hypometabolism is a very well established hallmark of aging in the brain
- However, while glucose metabolism decreases with age, ***ketone metabolism*** *stays relatively elevated*
- The implications are that a ketogenic metabolic therapy in the form of a ketone ester or just MCTs would be more efficacious as a means to energize the brain than a sugar based metabolism or sugar based intervention
- A lot of this research has been spurred by Mary Newport’s books:
  - [Alzheimer’s Disease: What If There Was a Cure?](https://www.amazon.com/Alzheimers-Disease-There-Story-Ketones/dp/1681626802/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)
  - [The Complete Book of Ketones](https://www.amazon.com/Complete-Book-Ketones-Practical-Supplements/dp/1684421616/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)

## Nootropics, caffeine, and other stimulants [1:16:15]

**Caffeine**

- Dom uses caffeine to enhance motivation and performance
- However, he acknowledges people can become addicted or habituated to caffeine
- Dom recently listened to Michael Pollan’s audiobook, [Caffeine](https://www.amazon.com/Caffeine-How-Created-Modern-World/dp/B083MYJXZT/ref=sr_1_1?dchild=1&gclid=Cj0KCQjwuJz3BRDTARIsAMg-HxWITnNTqFFAVkVXTQGqTsgAI1QumfaoEkuFcTfvLsA5UaevQE_vrFUaAh35EALw_wcB&hvadid=416984884785&hvdev=c&hvlocphy=9061129&hvnetw=g&hvqmt=b&hvrand=3178636184956414073&hvtargid=kwd-875178362351&hydadcr=15523_10340803&keywords=michael+pollan+caffeine&qid=1592244486&sr=8-1&tag=googhydr-20)
  - This idea that we wake up with caffeine withdrawal and we go for coffee basically to relieve caffeine withdrawal symptoms over time
- How Dom uses it…
  - He likes the buzz from caffeine for a mild boost in motivation
  - He makes sure to stop consuming it around noon
  - For him, the “coming down” from caffeine actually facilitates sleep

*-Caffeine and ketones and brain energy*

- Steven Cunnane [demonstrated](https://pubmed.ncbi.nlm.nih.gov/28177691/) that when you administer caffeine with MCTs, you convert more of those MCTs to ketones
- MCT oil becomes more ketogenic when you consume it with caffeine because it stimulates the beta oxidation of fats
- If you deliver caffeine with ketones, there’s a synergy that results in enhanced brain energy metabolism

**Ephedrine**

- [Ephedrine](https://en.wikipedia.org/wiki/Ephedrine#:~:text=Ephedrine%20is%20a%20medication%20and,is%20not%20the%20preferred%20treatment.) is very powerful stimulant
- It can also stimulate ketogenesis
  - In a fasted state, taking a beta receptor agonist, which activates [hormone-sensitive lipase](https://en.wikipedia.org/wiki/Hormone-sensitive_lipase), you can really boost your ketone levels

**Modafinil**

- [Modafinil](https://en.wikipedia.org/wiki/Modafinil) is a drug that Dom uses very sparingly as a mild nootropic
- Particularly when he is sleep deprived and has to drive or work against a deadline
- He generally takes only 50 milligrams
- The dose usually comes in 200 milligram tablets
- Dom gets splitting headaches when taking 100 mg or more at a time
- But 50 mg combined with a cup of coffee provides a noticeable effect

–*More about modafinil*

- It’s a fairly moderate stimulant
- It has amphetamine like effects, but it doesn’t trigger a pulse of dopamine like amphetamine
- This is important because it doesn’t really have addictive properties like amphetamine
- The literature also [showed that you don’t habituate to it](https://pubmed.ncbi.nlm.nih.gov/10828434/)… meaning you can use it continuously use the same dose and you’ll get the same benefit
- The military uses it as a “[go pill](https://pubmed.ncbi.nlm.nih.gov/10828434/)” for combat readiness or in the case of a pilot needing to stay alert for long durations
- For more on modafinil see previous episode of The Drive: [AMA #4](https://peterattiamd.com/ama04/), [AMA #7](https://peterattiamd.com/ama07/)

–*How does modafinil work mechanistically?*

- Still unclear
- But Dom speculates that it’s probably…
  - Through catecholamines (e.g., dopamine)
  - Maybe also through anti-gaba effects
  - It may be enhancing glutamatergic neurotransmitter activation or receptors, so maybe AMPA and NMDA receptor activation through glutamate

**Theanine and phenibut**

- Dom sometimes will take [theanine](https://www.webmd.com/vitamins/ai/ingredientmono-1053/theanine#:~:text=Theanine%20is%20an%20amino%20acid,glutamic%20acid%2C%20another%20amino%20acid.) or [phenibut](https://en.wikipedia.org/wiki/Phenibut) which is a phenylated GABA that is crossing the blood brain barrier
- Dom calls it a **mild CNS depressant** where he feels less inhibited and the thoughts flow making him feel smarter and more creative
- Sort of the opposite effect of a stimulant (which might cause too many neurons to fire and create analysis paralysis)

## Supplemental use of testosterone, DHEA, and creatine for muscle growth and performance [1:23:45]

**Testosterone**

- Testosterone is an effective compound that will help grow muscle
- If you are *deficient in testosterone*, Dom is in favor of supplementing with a doctor’s help
- “*I think it’s more important to figure out why your testosterone would be low in the first place.*”

**DHEA**

- [Dehydroepiandrosterone](https://en.wikipedia.org/wiki/Dehydroepiandrosterone) (DHEA) is a precursor that will break down into other hormones
- Dom takes **25 milligrams of DHEA** as a single dose upon waking up
- An hour later, Dom will have a 20 or 25% increase in testosterone
- And if he stops taking the DHEA, his testosterone levels are normal suggesting that taking DHEA isn’t messing up his body’s ability to make testosterone on it’s own
- However, if you’re using DHEA multiple times throughout the day, you’ll probably quickly shut down your own testosterone

*-DHEA’s effect on cortisol*

- When taking DHEA, Dom notices that his morning cortisol is slightly below normal
- So the one thing that has changed is that my cortisol is slightly below normal.
- The lower cortisol may be contributing to a lower glucose level as well
- Cortisol is an important hormone… it’s good marker for your adaptation to training and progress with training, I think cortisol correlates highest with gains from training (per [Layne Norton](https://www.instagram.com/biolayne/?hl=en))
- However, a slightly lower level in the morning may not be a bad thing, says Dom

**Creatine**

- Creatine has always been a staple for Dom
- He takes it upon waking every morning
- For Dom, it’s a noticeable effect in terms of his **strength levels**
- And also seems to give him a **brain boost**
- Creatine can also [help in the case of a mild TBI](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6094347/)—creatine can help restore brain energy metabolism and mitigate effects of a brain injury if you’re already taking it
- Ideal dosage
- Dom says **everyone could benefit from about 3 grams of creatine daily**
- “*It’s cheap. It’s effective. And it has a very, very good safety profile.*”

*Effect on strength*

- Dom says he does a loading phase of about 10 g per day for a week
- This will put on 2 or 3 lbs of body weight
- He will also be able to get an extra 2 reps or so on certain lifts

## Impact of fasted-state training on strength and performance [1:30:15]

**Dom’s 500 lb deadlift after a 7-day fast**

- Dom once fasted for 7 days and then deadlifted over 500 lbs ([watch this clip from Joe Rogan](https://youtu.be/keSoSyu9m7c?t=7930))
- He didn’t want to “push it” but felt like he could have done more
- Most people think your strength is going to tank when you go a couple of days without eating, but your body is very adaptable

**When does Dom feel strongest?**

- Dom feels strongest when fasted for about 8 to 16 hours as long as he’s well fed the days before
- He tends to always get his PRs when he 8-16 hours fasted coming of 2 days of a calorie surplus

**Pushing vs. pressing in a fasted state**

- “I wouldn’t try benching because I do think you might be a little bit dehydrated from depleting glycogen.”
- “That cellular leverage you have when you’re in a fed state, it’s going to transfer to pressing exercises, whereas pulling exercises not so much.”
- “I do feel better, lighter on my feet, and my CNS can just fire and recruit more muscle, if I’m in that fasted or semi-fasted state doing things like squats and deadlifts. and pull ups, too.”

## Stacking exogenous ketones with MCTs for optimal effectiveness [1:33:30]

**Stacking for optimizing efficacy of ketones**

- BHB and MCT is a stack that you’d want to use if you’re considering exogenous ketones
- Ketones and/or MCT can be stacked with caffeine

⇒ For a list of products Dom recommends [click here](https://www.ketonutrition.org/ketogenicfoods)

**Research**

- Dom’s research into ketones has mostly been studying them in isolation
- However, they’re now doing more stacking of compounds together
  - *Example*, taking a ketone ester, ketone salt, and then MCTs and then trying to determine what combinations would be best to deliver ketone metabolic therapy for…
    - Seizures, and
    - Performance optimization/resilience especially in the context of the high pressure oxygen

## BCAA supplements during a fast for muscle preservation [1:35:45]

**Thoughts on branched-chain amino acid (BCAAs) and essential amino acid (EAA) supplements**

- Dom used BCAAs for years and more recently was using EAAS
- However, he generally feels they unnecessary in most cases

*When they might be beneficial…*

- They may have benefit for people in a calorie restricted state
- And if you use them intra-workout
- Someone who is a bit older (65+) may benefit because you become anabolic resistant with age
- So for that person, Dom might suggest…
- Taking a BCAA-EAA mix upon waking and intra-workout (two scenarios where you’re in a catabolic state)
  - Total muscle mass is a function of protein breakdown and anabolic activity
  - You’re slowing muscle degradation and probably stimulating mTOR in skeletal muscle (if the leucine content is high enough)
  - In the context of training, mTOR stimulation in skeletal muscle is important and also may have anticancer effects

One experiment [showed](https://www.cell.com/cell-metabolism/pdfExtended/S1550-4131(17)30490-4) that in mice on the ketogenic diet, there was mTOR inhibition, but there was actually more activation of mTOR in the muscle

*In short…*

- Skeletal muscle mTOR activation=good.
- Cancer tumor mTOR activation=bad.

**Dom’s** [**work**](https://www.fasebj.org/doi/abs/10.1096/fasebj.28.1_supplement.824.2) **sponsored by Scivation on BCAAs**

- Scivation is a company that we use BCAAs with a ketogenic diet
- **Hypothesis**: There was the idea that driving mTOR with BCAAs would it fuel tumor growth
- The study did NOT find tumor growth and actually found trends for the opposite
- There were trends for an *increase* in survival time
- There was a small advantage weight management and a preservation of body weight when the BCAAs was mixed with a keto diet

**Are BCAAs helpful for muscle preservation during prolonged fasting?**

- Dom says the results would be minimal, if any
- BCAAs also have calories, so it would be sort of like eating egg whites
- “*You’d probably see an effect with skeletal muscle protein synthesis soon after you took it, but I think it kind of all balances out in time*.”
- ***Bob’s input***: For someone with a ton of weight to lose, they might actually have the ability to break down excess skin for example into “essential” amino acids that can be reconstituted and used for preserving some muscle

**Current Supplements Dom uses**:

- Creatine monohydrate
- Alpha Lipoic Acid
- CoQ10
- MSM
- Glucosamine
- Chondroitin
- Melatonin

## What app is Dom using for tracking his macros? [1:42:00]

**Carbon – Smart Diet Coach**

- Dom hasn’t done too much with macro tracking apps in the past
- But recently he was trying out the [Carbon – Smart Diet Coach app](https://joincarbon.com/)
- It was developed by a natural bodybuilder named [Layne Norton](https://www.instagram.com/biolayne/?hl=en) (friend of Dom’s)
- Layne wanted Dom to evaluate the ketogenic diet option
- Dom says he really, really liked it
- It’s quite simple, and the database is fantastic
  - For example, Dom uses [KetoLogic](https://ketologic.com/?afmc=dom&utm_campaign=dom&utm_source=leaddyno&utm_medium=affiliate) products and those are loaded in there and pop right up

Dom’s observations about himself from using the app:

- He realized he’s eating about 10-20% more calories than he estimated
- But his weight has stayed the same after 8 days
- His baseline calorie needs are really 4,000 per day
- Was also eating more carbs than he thought but he was still staying in ketosis
- Dom recommends using the app if just for the learning experience

## Getting enough micronutrients while on a ketogenic diet [1:47:15]

**Dom’s take on micronutrients**

- He doesn’t worry about it
- You can get all the micronutrients you really need with foods like liver, fish, egg yolks, and sardines
- There may be some benefits from plants, but “*I don’t think it’s absolutely necessary*”

## Ideal macros for staying in ketosis while getting enough protein for strength training [1:48:15]

*Overall thoughts*:

- Your macro breakdown to remain in ketosis depends on the individual
- The “lowest fat macro percent for staying ketosis” depends on your total calorie intake

**Carb intake**

- On *high calorie* days, Dom can be at 125 grams of carbs (a third being fiber) and stay in ketosis
- Carbs being 10-15% of this macros
- Yet, his ketones are anywhere between 1.2 and 2.2 throughout the day

*\*Dom’s tip*:

- Pay attention to how you feel and take notice of your ketone levels when you feel your best
- For Dom, he’s found that being in the 1-1.5 mmol range is when he feels best

**Fat intake**

- Dom gets about 400 grams of fat per day

**Protein intake**

- 120 g on the lowest days
- 200 or more on the highest days
- Usually stays in the 1.5 grams per kilogram
- But he likes to pulse his protein once or twice a week up  to 200 grams (approx. 2 g/kg of body weight) to help with recovery after some harder training days

## Pros, cons, and ideal macros of one meal a day [1:51:15]

Cons

- Hard to get all calorie and macro needs into one meal
- However, this approach might work for someone with lower calorie needs (~1,500)
- But it would be difficult for an athlete
- Dom says: “*I could never maintain my weight, or strength, doing that day in and day out. I would have to eat an amount of food that I think would just not be optimal for a nutrient uptake, and I would tend to eat it later in the day, and I think that would disrupt my sleep.*”

In terms of macros for that one meal…

- Take in lower protein if you’re not training hard, and boost your protein if you are training hard
- Dom does do OMAD often but will every once in a while
- His one meal might be a ribeye, fatty salad with olive oil and feta
- ~80 grams of protein, ~100 grams of fat, and ~30 grams of fibrous carbohydrates, so about ~1500 calories
- He might also sneak in his favorite [keto chocolate mousse](https://www.instagram.com/p/BIvhpWGgAjy/) for dessert ([on Dave Asprey podcast)](https://blog.daveasprey.com/85-in-a-state-of-ketosis-with-dominic-dagostino-podcast/)
- “*I could not really take in the calories and the macros that my body needs in that small eating window. So, that would be the major con.*”

Pros

- It’s a very effective way to produce a calorie deficit for those needing to lose weight
- Don’t have to do it daily, could try every other day or even just once a week
- A narrow eating window could also enhance insulin sensitivity

## Dom’s take on “carb backloading” [1:54:45]

**Does Dom do carb backloading?**

- Sort of…
- He eats all his carbs right with dinner and after dinner snacks
- But it’s mostly fibrous carbs, so it’s like “slow-carb backloading”

**Advantages to keeping SOME carbohydrates in the diet**

- Taking in 50 to 100 grams of carbs per day of slow-burning carbohydrates is enough to aid in repair (especially if you’re working out)
- It will also prevent you from completely suppressing [pyruvate dehydrogenase complex](https://en.wikipedia.org/wiki/Pyruvate_dehydrogenase_complex) (PDH)
- It will allow you to keep insulin sensitivity high with keeping the PDH pathway open
- For Dom, carbs consists of
  - fibrous carbs,
  - avocado,
  - fruits like blueberries, grapefruits, nectarine
  - Nuts
  - Dark chocolate (which he has every night)
  - For Dom, that ends up at 70 to 100 grams of carbs

> “I like to restrict carbs enough to keep the body kind of ‘hungry’ for carbs. And that way, when I consume a little bit of carbs, you’re highly efficient at utilizing and getting that glucose where it needs to be to replenish some muscle glycogen, or to have a restorative, reparative, effect.”

**Total carb restriction**

- With prolonged total carb restriction, you will produce a physiological glucose/carbohydrate intolerance
- And if you go back to eating carbs, you’re going to have a hyper-insulin response and hyperglycemia
- Whereas just keeping a little bit of carbohydrates in, you can maintain your carbohydrate tolerance

**Carb backloading concept**

- [Kiefer](https://twitter.com/dhkiefer?lang=en) came up with the idea of carb backloading
- It basically looks like…
  - Breakfast and lunch is low-carb/keto
  - Exercise later in the day or the evening, and that’s when you would ramp up the carbohydrates
- Kiefer’s rationale:
  - You’re more insulin sensitive in the morning and a little more insulin resistant at night (just general circadian rhythm)
  - Therefore, you may be more susceptible to storing your energy as fat when you’re more insulin sensitive in the morning
  - So you basically ride out the overnight fast, which increases fat oxidation, keep carbs at a minimum
  - Then you train and exercise and eat the carbs right after your exercise
  - The thought is that after a hard workout you’d partition more glucose to the muscles and less to fat, in part because of the [non-insulin mediated glucose uptake](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2894300/#:~:text=In%20the%20human%20body%2C%20glucose,%2Dinsulin%2Dsensitive%20tissues%20(i.e.), and in part because the fat cells may be a little more insulin resistant at night
  - Furthermore, the carbs Kiefer suggested eating were higher glycemic (e.g., cherry turnovers) which would spike insulin and spike the growth after a workout

**-Dom’s take**:

- Dom says the slow-carbs with high fiber are better for him personally
- A square of 80-85% dark chocolate is a good dessert option and doesn’t make him want to devour the whole bar ⇒ “*It’s very satisfying just to have, so it’s kind of self-limiting.*”
- Eating cherry turnovers or other sugary hyper-palatable things is especially bad for those who are inclined to have binge eating behaviors

## Dom’s take on “carb up” days for ketogenic dieters [2:01:00]

**Carb up days**

- Dom doesn’t do “carb up” days
- Rather, he will increase his total calories by about 25% a couple days a week
- But he just eats more of the same foods he already eats
- Generally, this means a bit more protein around his heavy training days
- When “carbing up” in the past, it would trigger a roller coaster in energy levels for Dom
- “*I get the same effect without the hormonal roller coaster.*”

*\*Beware if you have addictive eating behaviors*

- Some people are proponents of carb up day and cheat days
- Like the [cyclical ketogenic diet](https://www.healthline.com/nutrition/cyclical-ketogenic-diet) approach, or the [Anabolic Diet](https://www.healthline.com/health/food-nutrition/anabolic-diet) by [Mauro Di Pasquale](https://en.wikipedia.org/wiki/Mauro_Di_Pasquale) where one day a week you flip the macros and go high carb, low fat
- But Bob points out that for people who are addicted to bad foods, this can backfire
  - Sort of like a smoker who tries to just have one cigarette or smoke cigarettes “in moderation”
- [Dr. Steve Phinney](https://www.virtahealth.com/people/stephen-phinney) describes something called “intrusive thoughts of hunger” where a person might have a voice in their head that says, “*Wouldn’t you like to have that donut?”*
  - The good news is that this voice goes away over time, “*And it’s amazing that you might not miss those things as much as you think you would.*”

**PET scans showing addictive behavior**

- PET scans of the brain of people eating meals [show](https://www.karger.com/article/FullText/338328) that obese people leave “no doubt that the obese person is activating the same mechanisms of addiction with this kind of feeding”

## Dom’s thoughts on the carnivore diet and the paleolithic ketogenic diet [2:05:30]

⇒ For Dom thoughts on the carnivore diet check out this [YouTube video](https://www.youtube.com/watch?v=8nRBKrrg6Mk)

**The paleolithic ketogenic diet**

- A group in Hungary called [Paleomedicina](https://www.paleomedicina.com/en/) is studying the [paleolithic ketogenic diet](https://www.paleomedicina.com/paleolithic-ketogenic-diet/) (similar to the carnivore diet)
- It’s shown to be pretty effective for managing a number of things, especially **autoimmune disorders** and **gut health**
- Diet includes a lot of pork, organ meats, no dairy, no nuts, no plants at all
- Note: Dom says he personally eats plants but if he eliminated them he doesn’t think it would either help or harm his health
- The Paleomedicina folks would be of the opinion that plants are doing harm, especially ones high in oxalates like broccoli

**Type 1 diabetes**

- They’ve been using the diet to type 1 diabetes and argue that they may be actually restoring some of the insulin function with the diet (at least when looking at [C-peptide](https://en.wikipedia.org/wiki/C-peptide))

**Gut health**

- Dom calls this the most convincing thing about their approach
- They use PEG 400 as a means to determine gut health
- You consume it orally, collect it in the urine, and you can see an index of gut permeability as it pertains to leaky gut
- Leaky gut being defined by gaps in the gastrointestinal mucosa and being compromised by openings of the tight junctions that hold the cells together
- And the therapeutic response to the paleolithic ketogenic diet correlates to [restored gut function and decreased gut permeability](https://www.paleomedicina.com/en/blog/2015/11/crohns-disease-and-the-paleolithic-ketogenic-diet-a-graduation-thesis)

⇒ Dom says to check out their Paleomedicina’s [website](https://www.paleomedicina.com/en/) and look through their [papers](https://www.paleomedicina.com/en/?page=tartalom&tipus=cikk)

**⇒ Another resource**: [Dr. LÁSZLÓ G. BOROS](https://www.ddcenters.com/dr-laszlo-boros/) is a pioneer with the science of deuterium depleted water and getting your body in a fat-adapted state

## Advantage of the ketogenic diet for extreme endurance athletes [2:10:30]

**Keto and ultrarunners**

- Dom thinks it could work really well for ultrarunners
- [Zach Bitter](https://twitter.com/zbitter?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) is an example of someone who thrives on high fat, low carbs
- However, athletes need to give their body time to fully adapt

*Logistical advantage*

- One big advantage is the logistical aspect – less need to be refeeding during a race
- Essentially, fat adapted runners have better access to their fat stores for fuel and you can see this by looking at the [respiratory quotient](https://en.wikipedia.org/wiki/Respiratory_quotient)
- An **RQ of 0.7** is a pretty good indication that they have extremely good access to their stored body fat
  - For more on fat burning zones and respiratory quotient check out [AMA #9](https://peterattiamd.com/ama09/) as well as this [blog post](https://peterattiamd.com/my-quantified-self-part-i/)
- Even a lean person has ~30,000 calories in the form of fat, whereas our carbohydrate calories would maybe be like 2000, 2500, and you can burn through that in an ultramarathon

*Recovery advantage*

- The keto diet promotes many adaptations that can enhance recovery from the crazy workouts
- Some guys can do an ultra marathon and then do another one immediately afterwards
- And that was previously unheard of and Dom thinks being low carb, high fat has allowed for that to happen

*GI system*

- Constant refeeds of goos and gels is hard on the GI system and so the less refeeds needed the better
- Also, the gut is 70% of the immune system so these strenuous endurance events put extra stress on the GI so less refeeds could mitigate that to some degree

## Impact on strength, power, and performance of the adaptation period to the ketogenic diet [2:14:00]

**When first starting a ketogenic diet…**

- You’re likely to experience a negative hit to your *physiological, cognitive, and even immunological* performance because it’s a stress to your body
  - You’re basically forcing it to use another fuel that you’re not fully adapted to using
- You can compare this stress to exercise adaptation—if you go from 20 min of exercise and increase to 2 hours, you’re going to be in pain and sore
- But skeletal muscles are incredibly adaptable including the process of adapting the energy system being used in the skeletal muscle
- In time, with the keto diet
  - i) the fatty acid oxidation skyrocket, and
  - ii) your liver to beta oxidation of fatty acids and ketone production will skyrocket over time

**⇒ Dom’s study**: [Ketogenic diet does not affect strength performance in elite artistic gymnasts](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3411406/pdf/1550-2783-9-34.pdf)

**The magnitude of the negative consequences will depend on the individual**

- Example – Endurance athletes may already be somewhat keto adapted because there’s post-exercise ketosis. And if you exercise long enough and deplete your liver glycogen, you enter a state of ketosis.
- The normal everyday person probably will go through a time of discomfort during the adaptation period
  - NOTE: Not everybody’s going to adapt, but most people will
  - Those people will just have to accept this initial phase and know it will get better

*How long to adapt?*

- Phinney and Volek, in [The Art and Science of Low Carbohydrate Performance](https://www.amazon.com/Art-Science-Low-Carbohydrate-Performance/dp/0983490716), discuss keto adaptation could be weeks to months
  - Specifically, the heart and the skeletal muscle increase their utilization of fatty acids over time
  - On the low end, it might be a couple of weeks
- But Dom thinks you’re not really getting full adaptation until about **six months**

\*The best way to fully adapt is to **train while in the state of ketosis**—to put your body under extreme stress in that physiological state

## Fasted-state elevation in growth hormone and its impact on training [2:17:45]

**Growth hormone (GH)**

- GH elevation occurs during a fast
- But Dom is not convinced it gives a training advantage or helps with muscle gain
- There are advantages to training in a fasted state
  - E.g., Eating a large meal before training could have a 500% or more increase in blood flow to your gastrointestinal system, to the organs, to the liver, pancreas, gallbladder, small intestines, large intestines and your stomach
    - That’s taking away blood that could otherwise be going to your muscles
  - Caveat: A small meal may work for people (~500 calories or less)

*Why does GH rise in a fasted state?*

- The elevation in growth hormone is just a consequence of our physiology and to liberate more fat for energy through the lipolytic effect
- It may have an anti catabolic effect—so enhancing lipolysis may be sparing muscle to some extent
- Growth hormone is anabolic to some extent…but growth hormone will cause an increase in tissue of all your organs too
- Whereas things like anabolic steroids are sort of tissue specific to skeletal muscle protein synthesis

But to the question of, *Is there a significant advantage to the GH elevation associated with faster training?*

- “*Maybe, but it’s not something that I think about*” says Dom
- Rather, he’s focused on being in an optimal physiological state for training—fully fed the prior day, glycogen is up, and he’s well rested
- He then goes into the workout fasted between 8 and 16 hours and that’s when he has his best workouts and when he most often hits his personal records

## Is it possible to build muscle on a ketogenic diet? [2:23:30]

**If you’re training in a fasted state…**

- The key thing to remember is that you’re probably going to be a little bit **dehydrated** which means your blood volume is down and it’ll be harder to get a pump and maintain a high workout intensity
- Tips:
  - Drink water
  - Take some sugar free electrolytes that has salt (Dom uses [LMNT by Robb Wolf](https://drinklmnt.com/pages/robb-wolf?utm_source=RobbWolf&utm_medium=Blog&utm_campaign=CLEAN_ELECTROLYTES&utm_content=ELECTROLYTE_IMBALANCE_SYMPTOMS_FIX_IT))
  - Creatine might also be helpful (Dom takes 5 g prior to his workout)

**Adding muscle on a keto diet**

–*Maintenance mode*

- Dom is now doing mostly maintenance with no aspirations to be any bigger or heavier
- He’s noticed that if I stops doing heavy compound lifts (deadlifts, squats, etc.) he will lose some weight
- His workout for maintenance are really quick
- But I take a low volume in my training’s really quick
- In one hour a week, he can maintain his muscle

⇒ **Dom’s review**: [Anticatabolic Effects of Ketone Bodies in Skeletal Muscle](https://www.sciencedirect.com/science/article/abs/pii/S1043276019300128)

*-Adding muscle using a ketogenic diet*

- Dom says he would need to double or triple his training volume in order to add muscle mass
- Two or three hours a week of really intense, structured training
- But most important in adding mass happens with nutrition
- Dom spikes protein two or three times a week if I’m trying to gain and does so to correlate with recovery from heavier workouts
- So adding muscle on a keto diet is “*definitely possible*”

⇒ **Dom’s study**: [The effects of ketogenic dieting on skeletal muscle and fat mass](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4271639/pdf/1550-2783-11-S1-P40.pdf)

## Why Dom took a year off from weight training [2:28:00]

- Dom recently moved to a farm property that needed a lot of work
- The work was time consuming and physically demanding
- He took this time to prioritize and experiment with body weight exercises
- He has a weighted vest that allows him to add resistance as well
- He was also able to turn the property work into “farm strength” such as the process of lighting logs into the back of a truck

## What does Dom do for cardio exercise? [2:30:45]

- Dom doesn’t do deliberate/traditional cardio exercises
- He does a lot of walking, typically 30 minutes with the dogs after a meal
- He will do high rep deadlifts
- 315 lbs for 60 seconds, 3 rounds
- He tends to get his “cardio” in by doing work around his property, e.g., tree cutting and lifting them into a chipper

“I am convinced that it’s the reason why I’ve never really been injured. Just growing up bailing hay. I was like 12, 13 years old. And then I kind of built the foundation of farm strength. And then that really helped me later on.”

## Protocols for hard training recovery [2:33:15]

**Red Light therapy**

- Dom uses the [Joovv Elite](https://joovv.com/pages/dom?afmc=mb&utm_campaign=mb&utm_source=leaddyno&utm_medium=affiliate) red light system
  - (for more devices Dom uses [click here](https://www.ketonutrition.org/toolsanddevices))
- 2 or 3 times per week after a heavy lift
- There’s a ton of [research](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3288797/) on photobiomodulation
- “*The Joovv Elite system is like the best system that I know.*”
- Dom says he feels like he recovers faster and feels less sore

**Dead hangs**

- Dom does this every day
- Grab onto a pull up bar and hang for 60 secs
- Not only works your grip, but it’s stretching all the muscles underneath the intercostal muscles, the AB muscles, it’s also decompressing the spine.
- Will sometimes do weighted hangs sometimes too
- “*And I feel like it’s really strengthening the grip and my lats and everything.*”

**Nutrition**

- Nutritionally, he will bump up protein in order to boost calories by about 25%

**Walking**

- “I feel it’s important to just take a walk after big meals.”

## Dom’s personal approach to fasting, time-restricted eating, and sleep [2:35:45]

**Dom’s 7 day fast**

- Dom doesn’t do many multiple day fasts
- But he did do one experiment where he fasted for 7 days
  - And at the end he deadlift 500+ lbs for 10 reps
  - On the other days during that specific fast, *what did he do for exercise?*
  - Mostly body weight exercises (push ups and chin ups)
  - One day at the gym training shoulders and arms
- Other observations:
  - Feeling cold – By the 7 day mark, Dom felt cold like his metabolism might be slowing down ([See Peter explaining this here](https://www.instagram.com/tv/B7EAX5RAxc6/?utm_source=ig_web_copy_link))
  - No soreness – Two days after his heavy lift, when he would normally experience delayed onset soreness, he had absolutely no soreness at all

**How Dom typically incorporates fasting into his life**:

- Dom doesn’t fast every day
- Maybe 2 or 3 times a week he will do some time-restricted feeding
- On days when he is planning to train in the evening, he makes sure to have breakfast otherwise he can’t seem to get in all the calories he needs post-workout without disrupting his sleep

**Sleep**

- Dom prioritizes his sleep
- Early bedtime and has a sleep routine
- He tracks it with Oura Ring and Fitbit Inspire
- Bob asks Dom how he manages to get so much deep sleep (from Dom’s instagram posts)
- “*I have to do everything right. I have to be really tired.*”

## People, books, and other resources that shaped Dom’s training and nutrition [2:38:45]

In Dom’s early days…

- [The New Encyclopedia of Modern Bodybuilding](https://www.amazon.com/New-Encyclopedia-Modern-Bodybuilding-Updated/dp/0684857219) by Arnold Schwarzenegger
- [Dorian Yates](https://en.wikipedia.org/wiki/Dorian_Yates)
- [Mike Mentzer](https://en.wikipedia.org/wiki/Mike_Mentzer)
- [Ed Coan](https://en.wikipedia.org/wiki/Ed_Coan) and his [powerlifting templates](https://www.castironstrength.com/ed-coan-10-week-training-template/) ([book](https://www.amazon.com/COAN-Man-Myth-Method-Powerlifter-ebook/dp/B017A5HZRI))

In the 2000s…

- [Skip Lacour](https://skiplacour.com/about-skip-la-cour)
- [Layne Norton](https://www.instagram.com/biolayne/?hl=en)

Now, Dom’s more focused on longevity

- [Doug McGuff](https://www.drmcguff.com/about-doug/) ([IHMC podcast](https://www.ihmc.us/stemtalk/episode-24/), [lecture](https://www.ihmc.us/lectures/20191010/))
- [Art De Vany](https://en.wikipedia.org/wiki/Arthur_De_Vany) ([IHMC talks](https://www.youtube.com/user/TheIHMC/search?query=art+de+vany))

Other:

- Book by [Fred Hatfield](https://en.wikipedia.org/wiki/Frederick_Hatfield) aka Dr. Squat: [Hardcore Bodybuilding: A Scientific Approach](https://www.amazon.com/Hardcore-Bodybuilding-Dr-Frederick-Hatfield/dp/1502598116)

§

## Selected Links / Related Material

**Previous episode of The Drive with Dom D’Agostino**: [#05 – Dom D’Agostino, Ph.D.: ketosis, n=1, exogenous ketones, HBOT, seizures, and cancer](https://peterattiamd.com/domdagostino/) | Peter Attia (peterattiamd.com)

**Dom’s work with NASA Extreme Environment Mission Operations**:  [4:00, 2:38:00]

- Dom was a crew member of [NEEMO 22](https://en.wikipedia.org/wiki/NEEMO#NEEMO_22:_June_18%E2%80%9327,_2017) | (wikipedia.org)
- Dom’s wife was a crew member for [NEEMO 23](https://en.wikipedia.org/wiki/NEEMO#NEEMO_23:_June_10%E2%80%9322,_2019) | (wikipedia.org)

**Dom’s manuscript on ketones and cancer cachexia**: [Ketone Bodies Attenuate Wasting in Models of Atrophy](https://onlinelibrary.wiley.com/doi/full/10.1002/jcsm.12554) (Koutnik et al., 2020) [5:15]

**Ketones may be a form of metabolic “epigenetic therapy” for genetic disorders like Kabuki syndrome**: [A ketogenic diet rescues hippocampal memory defects in a mouse model of Kabuki syndrome](https://www.pnas.org/content/114/1/125) (Benjamin et al., 2017) [6:00]

**The glucose ketone index calculator**: [The glucose ketone index calculator: a simple tool to monitor therapeutic efficacy for metabolic management of brain cancer](https://nutritionandmetabolism.biomedcentral.com/articles/10.1186/s12986-015-0009-2) | (nutritionandmetabolism.biomedcentral.com) [7:30]

**Book recommendations for getting knowledgeable on the ketogenic diet**: [11:30]

- **General info**: [The Ketogenic Bible](https://www.amazon.com/gp/product/1628601043/ref=as_li_qf_asin_il_tl?ie=UTF8&tag=ketonutrition-20&creative=9325&linkCode=as2&creativeASIN=1628601043&linkId=3d8c45c58461f5b787d05d42d262c7ef) by Jacob Williamson and Ryan Lowery | (amazon.com)
- **For the athlete**: [The Art and Science of Low Carbohydrate Performance](https://www.amazon.com/gp/product/0983490716/ref=as_li_qf_asin_il_tl?ie=UTF8&tag=ketonutrition-20&creative=9325&linkCode=as2&creativeASIN=0983490716&linkId=88d284f8c3c5d8eece17c7b9e0e8116f) by Jeff Volek and Stephen Phinney | (amazon.com)
- **For the layman**: [Keto Answers: Simplifying Everything You Need to Know about the World’s Most Confusing Diet](https://www.amazon.com/Keto-Answers-Simplifying-Everything-Confusing/dp/1544504624/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=) by Anthony Gustin and Chris Irvin | (amazon.com)
- **Clinical info**:
  - [The Ketogenic and Modified Atkins Diets, 6th Edition: Treatments for Epilepsy and Other Disorders](https://www.amazon.com/gp/product/1936303949/ref=as_li_qf_asin_il_tl?ie=UTF8&tag=ketonutrition-20&creative=9325&linkCode=as2&creativeASIN=1936303949&linkId=7e4a6c5a4d80a03c72ec8c10ed1d4130) by Eric Kossoff MD | (amazon.com)
  - [The Ketogenic and Modified Atkins Diets, 6th Edition: Treatments for Epilepsy and Other Disorders](https://www.amazon.com/Ketogenic-Modified-Atkins-Diets-Treatments/dp/1936303949/ref=sr_1_2?dchild=1&qid=1591031117&refinements=p_27%3AEric+Kossoff+MD&s=books&sr=1-2&text=Eric+Kossoff+MD) by Dr. Eric Kossoff | (amazon.com)
- **For Alzheimer’s**: [he Complete Book of Ketones: A Practical Guide to Ketogenic Diets and Ketone Supplements](https://www.amazon.com/gp/product/1684421608/ref=as_li_qf_asin_il_tl?ie=UTF8&tag=ketonutrition-20&creative=9325&linkCode=as2&creativeASIN=1684421608&linkId=d9f84654357db2e3e0138ae80858ef26) by Dr. Mary Newport | (amazon.com)

**Urine ketone tester**: [The Siemens Multistix SG](https://www.cliawaived.com/siemens-bayer-multistix-8-sg.html) | (cliawaived.com) [14:00]

**Blood ketone measurement devices**: [14:15]

- *A reliable device*: [Precision Xtra](https://abbottstore.com/precision-xtra-blood-glucose-ketone-monitoring-system-1-pack-9881465.html) | (abbottstore.com)  [14:15]
- *Dom’s preferred device*: [Keto-Mojo](https://bestketonetest.com/?afmc=2b&utm_campaign=2b&utm_medium=affiliate&utm_source=leaddyno) | (bestketonetest.com) [14:30]

**Best breath test for ketones**: [BioSense Breath Ketone Analyzer](https://mybiosense.com/) | (mybiosense.com) [16:00]

**Another breath test for ketones that Bob has experimented with**: [Ketonix](https://www.ketonix.com/) | (ketonix.com) [17:15]

**George Cahill’s famous study fasting subjects for 40 days**: [Ketoacids? Good medicine?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2194504/pdf/tacca00002-0213.pdf) (Cahill and Veech, 2003) [22:45]

**Books by Dr. Mary Newport who used ketosis and ketones to manage her husband’s Alzheimer’s disease**: [28:45, 1:11:20, 1:15:30]]

- [The Complete Book of Ketones: A Practical Guide to Ketogenic Diets and Ketone Supplements](https://www.amazon.com/Complete-Book-Ketones-Practical-Supplements/dp/1684421616/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Mary Newport | (amazon.com)
- [Alzheimer’s Disease: What If There Was a Cure?: The Story of Ketones](https://www.amazon.com/Alzheimers-Disease-There-Story-Ketones/dp/1681626802/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) | Mary Newport | (amazon.com)

**Dom’s uses this at-home test for HbA1c**: [ZRT Labs CardioMetabolic Test Kit](https://www.amazon.com/ZRT-Cardiometabolic-Profile-Blood-Insulin/dp/B01NH11LMW?SubscriptionId=AKIAIOCEBIGP6NUBL47A&camp=2025&creative=165953&creativeASIN=B01NH11LMW&linkCode=xm2&tag=ketonutrition-20) | (amazon.com) [29:45]

**Low LDL may be related to cancer risk**:  [Low LDL cholesterol is related to cancer risk](https://www.sciencedaily.com/releases/2012/03/120326113713.htm) | (sciencedaily.com) [51:45]

**Dave Feldman on The Drive podcast**: [#19 – Dave Feldman: stress testing the lipid energy model](https://peterattiamd.com/davefeldman/) | Peter Attia (peterattiamd.com) [52:30]

**Phinney and Volek’s paper about hypercholesterolemia in their fat-adapted elite endurance athletes**: [Paradox of Hypercholesterolaemia in Highly Trained, Keto-Adapted Athletes](https://pubmed.ncbi.nlm.nih.gov/30305928/) (Creighton et al., 2018) [52:45]

**Art De Vany on the IHMC podcast**: [56:15]

- [EPISODE 30: ART DE VANY TALKS ABOUT HOLLYWOOD ECONOMICS, THE PALEO WAY, AND THE ROLE OF FITNESS AND DIET IN AGING](https://www.ihmc.us/stemtalk/episode-30/) | (ihmc.us)
- [EPISODE 105: ART DE VANY TALKS ABOUT HEALTHSPAN, LIFESPAN AND HEALING THE WOUNDS OF AGING](https://www.ihmc.us/stemtalk/episode-105/) | (ihmc.us)

**Adding exogenous ketones to a standard diet of high carbohydrates enhances wound healing**: [Metabolic Therapy for Age-Dependent Impaired Wound Healing](https://scholarcommons.usf.edu/cgi/viewcontent.cgi?article=7300&context=etd) (Shannon Lynn Kesl, 2016) [58:00]

**List of ketone products that Dom has tested**: [KetoNutrition.org/ketones](https://www.ketonutrition.org/ketones) | (ketonutrition.org) [1:00:00]

**Dom’s review article on ketone esters as metabolic therapy**: [History and Rationale for Ketone Esters and Metabolic Alternatives.](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6803688/) (Poff et al., 2019) [1:00:00]

**Interesting study in Lancet using Ketone Salts**: [D,L-3-hydroxybutyrate treatment of multiple acyl-CoA dehydrogenase deficiency (MADD)](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(03)13105-4/fulltext) (Van Hove et al., 2003) [1:00:00]

**Capric acid (C10) may have anti-seizure properties independent from the ketone production**: [Seizure Control by Decanoic Acid Through Direct AMPA Receptor Inhibition](https://pubmed.ncbi.nlm.nih.gov/26608744/) (Chang et al., 2016) [1:09:15]

**Audiobook about caffeine that Dom recently listened to**: [Caffeine: How Caffeine Created the Modern World by Michael Pollan](https://www.amazon.com/Caffeine-How-Created-Modern-World/dp/B083MYJXZT/ref=sr_1_1?dchild=1&gclid=Cj0KCQjwuJz3BRDTARIsAMg-HxWITnNTqFFAVkVXTQGqTsgAI1QumfaoEkuFcTfvLsA5UaevQE_vrFUaAh35EALw_wcB&hvadid=416984884785&hvdev=c&hvlocphy=9061129&hvnetw=g&hvqmt=b&hvrand=3178636184956414073&hvtargid=kwd-875178362351&hydadcr=15523_10340803&keywords=michael+pollan+caffeine&qid=1592244486&sr=8-1&tag=googhydr-20) | (amazon.com) [1:16:30]

**If you administer caffeine with MCTs, you convert more of those MCTs to ketones**: [Caffeine Intake Increases Plasma Ketones: An Acute Metabolic Study in Humans](https://pubmed.ncbi.nlm.nih.gov/28177691/) (Vandenberghe et al., 2016) [1:17:30]

**MCTs and brain energy metabolism in Alzheimer’s disease**: [Ketogenic Medium Chain Triglycerides Increase Brain Energy Metabolism in Alzheimer’s Disease](https://pubmed.ncbi.nlm.nih.gov/29914035/) (Croteau et al., 2018) [1:17:30]

**You don’t habituate the modafil meaning you don’t build up a tolerance for it and you can stay at the same dose and get the same effect**: [Long-term Efficacy and Safety of Modafinil (PROVIGIL((R))) for the Treatment of Excessive Daytime Sleepiness Associated With Narcolepsy](https://pubmed.ncbi.nlm.nih.gov/10828434/) (Mitler et al., 2000) [1:20:15]

**One experiment showed that in mice on the ketogenic diet, there was mTOR inhibition, but there was actually more activation of mTOR in the muscle**: [A Ketogenic Diet Extends Longevity and Healthspan in Adult Mice](https://www.cell.com/cell-metabolism/pdfExtended/S1550-4131(17)30490-4) (Roberts et al., 2017) [1:37:30]

**Dom’s study looking at BCAA and cancer cachexia**: [Study](https://www.fasebj.org/doi/abs/10.1096/fasebj.28.1_supplement.824.2) | (fasebj.org) [1:38:15]

**App Dom uses to track macros**: [Carbon – Smart Diet Coach](https://joincarbon.com/) | (joincarbon.com) [1:42:00]

**Wine Dom drinks**: [Dry Farm Wine](https://www.dryfarmwines.com/?wickedsource=google&wickedid=363175116941&wtm_term=dry%20farm%20wine&wtm_campaign=2062114788&wtm_content=77837471682&wickedplacement=&wickedkeyword=dry%20farm%20wine&gclid=Cj0KCQjwirz3BRD_ARIsAImf7LOavaokieTJOHvE_62ZWnV7UuOc7eOchcaceVC7wZbLfmvQIGIcO7waAhfDEALw_wcB) | (dryfarmwines.com) [2:00:00]

**PET scans of the brain of obese people eating meals show activation in the same mechanisms of addiction**: [Brain PET Imaging in Obesity and Food Addiction: Current Evidence and Hypothesis](https://www.karger.com/article/FullText/338328) (Iozzo et al., 2012) [2:04:45]

**Group in Hungary studying the paleolithic ketogenic diet**: [PaleoMedicina](https://www.paleomedicina.com/en) | ([paleomedicina.com](https://www.paleomedicina.com/en)) [2:05:30]

**The paleolithic ketogenic diet**: T[he history of the Paleolithic Ketogenic Diet™](https://www.paleomedicina.com/paleolithic-ketogenic-diet/) | (paleomedicina.com) [2:05:30]

**Therapeutic response to the paleolithic ketogenic diet correlates to restored gut function and decreased gut permeability**: [Crohn’s disease and the paleolithic ketogenic diet: a graduation thesis](https://www.paleomedicina.com/en/blog/2015/11/crohns-disease-and-the-paleolithic-ketogenic-diet-a-graduation-thesis) | Zsanett Rontó (paleomedicina.com/en) [2:08:30]

**Full list of papers from Paleomedicina group**: [SCIENTIFIC ARTICLES](https://www.paleomedicina.com/en/?page=tartalom&tipus=cikk) | (paleomedicina.com/en) [2:09:30]

**Dom’s study suggesting the keto diet does not negatively impact performance of elite gymnasts**: [Ketogenic diet does not affect strength performance in elite artistic gymnasts](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3411406/pdf/1550-2783-9-34.pdf) (Paoli et al., 2012) [2:14:00]

**Book which discusses the duration needed for keto adaptation in the heart and muscles specifically**: [The Art and Science of Low Carbohydrate Performance](https://www.amazon.com/Art-Science-Low-Carbohydrate-Performance/dp/0983490716) by Jeff Volek and Stephen D. Phinney | (amazon.com) [2:16:00]

**Sugar free electrolytes that Dom takes when training in a fasted state**: [LMNT by Robb Wolf](https://drinklmnt.com/pages/robb-wolf?utm_source=RobbWolf&utm_medium=Blog&utm_campaign=CLEAN_ELECTROLYTES&utm_content=ELECTROLYTE_IMBALANCE_SYMPTOMS_FIX_IT) | (drinklmnt.com) [2:24:30]

**Dom’s review of the anti-catabolic effects of ketones**: [Anticatabolic Effects of Ketone Bodies in Skeletal Muscle](https://www.sciencedirect.com/science/article/abs/pii/S1043276019300128) (Koutnik et al., 2019) [2:25:00]

**Dom’s study looking at the effects of the keto diet on muscle and fat mass**: [The effects of ketogenic dieting on skeletal muscle and fat mass](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4271639/pdf/1550-2783-11-S1-P40.pdf) (Rauch et al., 2014) [2:26:00]

**The Red Light system Dom uses for muscle recovery from hard workouts**: [Joovv Elite](https://joovv.com/pages/dom?afmc=mb&utm_campaign=mb&utm_source=leaddyno&utm_medium=affiliate) | (joovv.com) [2:33:30]

**Research on photobiomodulation**: [The Nuts and Bolts of Low-level Laser (Light) Therapy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3288797/) (Chung et al., 2013) [2:33:30]

**Dom on Joe Rogan’s podcast**: [Joe Rogan Experience #994 – Dom D’Agostino](https://youtube.com/watch?v=keSoSyu9m7c) | Powerful JRE (youtube.com) [2:35:45]

**Dom on Tim Ferriss’s podcast**: [2:35:45]

- First appearance: [Dom D’Agostino on Fasting, Ketosis, and the End of Cancer (#117)](https://tim.blog/2015/11/03/dominic-dagostino/) | (tim.blog)
- 2nd appearance: [Dom D’Agostino Returns (Full Episode) | The Tim Ferriss Show (Podcast)](https://www.youtube.com/watch?v=yopZxm4smOI) | Tim Ferriss (youtube.com)
- 3rd appearance: [Dom D’Agostino Returns (Full Episode) | The Tim Ferriss Show (Podcast)](https://www.youtube.com/watch?v=3dH8X7PK3og) | Tim Ferriss (youtube.com)

**Peter explaining why you feel cold while fasting**: [@peterattiamd](https://www.instagram.com/tv/B7EAX5RAxc6/?utm_source=ig_web_copy_link) | (instagram.com) [2:26:30]

**Sleep tracking devices that Dom uses**: [2:37:45]

- [Oura ring](https://ouraring.com/) | (ouraring.com)
- [Fitbit Inspire](https://www.fitbit.com/us/products/trackers/inspire) | (fitbit.com)

**Resources that shaped Dom’s approach to training and nutrition**: [2:38:45]

- [The New Encyclopedia of Modern Bodybuilding : The Bible of Bodybuilding, Fully Updated and Revised](https://www.amazon.com/New-Encyclopedia-Modern-Bodybuilding-Updated/dp/0684857219) by Arnold Schwarzenegger and Bill Dobbins | (amazon.com)
- Ed Coan’s powerlifting templates: [Ed Coan – 10 Week Training Template](https://www.castironstrength.com/ed-coan-10-week-training-template/) | Marc Keys (castironstrength.com)
- Ed Coan’s book: [COAN The Man, The Myth, The Method: The Life, Times & Training of The Greatest Powerlifter of All-Time](https://www.amazon.com/COAN-Man-Myth-Method-Powerlifter-ebook/dp/B017A5HZRI) by Ed Coan | (amazon.com)

- Book by [Fred Hatfield](https://en.wikipedia.org/wiki/Frederick_Hatfield) aka Dr. Squat: [Hardcore Bodybuilding: A Scientific Approach](https://www.amazon.com/Hardcore-Bodybuilding-Dr-Frederick-Hatfield/dp/1502598116) | (amazon.com)

**IHMC lectures Dom recommends**: [2:41:15]

- [Doug McGuff: Resistance Exercise](https://www.youtube.com/watch?v=RwgywNZzEi4&feature=emb_logo) | TheIHMC (youtube.com)
- [YouTube: TheIHMC—Art De Vany](https://www.youtube.com/user/TheIHMC/search?query=art+de+vany) | (youtube.com)

§

## People Mentioned

- [Dr. Andrew Koutnik](https://www.andrewkoutnik.com/) [5:15]
- [Thomas Seyfried](https://www.bc.edu/bc-web/schools/mcas/departments/biology/people/faculty-directory/thomas-seyfried.html) [5:30]
- [Sara Moss](https://pubmed.ncbi.nlm.nih.gov/?term=Moss%20S%5BAuthor%5D) [6:30]
- [Jeff Volek](https://www.virtahealth.com/people/jeff-volek) [11:30, 52:45, 2:16:00]
- [Stephen Phinney](https://www.virtahealth.com/people/stephen-phinney) [11:30, 52:45, 2:04:15, 2:16:00]
- [Dr. Eric Kossoff](https://www.hopkinsmedicine.org/profiles/results/directory/profile/0012386/eric-kossoff) [13:00]
- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) [22:45]
- [Dale Bredesen](https://www.apollohealthco.com/dr-bredesen/) [28:45]
- [Mary Newport](https://coconutketones.com/mary-newport-md-bio-books/) [28:45, 1:11:20]
- Steve Newport (Mary’s husband with Alzheimer’s disease) [28:45, 1:11:20]
- [Art De Vany](https://en.wikipedia.org/wiki/Arthur_De_Vany) [56:15, 2:18:30]
- [Dr. Stephen Cunnane](https://u.osu.edu/ketodiet/speaker-bios/stephen-cunnane-phd/) [1:08:45, 1:14:30, 1:17:30]
- [Michael Pollan](https://michaelpollan.com/) [1:16:30]
- [Layne Norton](https://www.instagram.com/biolayne/?hl=en) [1:27:30, 2:40:15]
- [Kiefer](https://twitter.com/dhkiefer?lang=en) [1:57:45]
- [Mauro Di Pasquale](https://en.wikipedia.org/wiki/Mauro_Di_Pasquale) [2:02:15]
- [Fred Hatfield](https://en.wikipedia.org/wiki/Frederick_Hatfield) [2:02:15]
- [Dr. LÁSZLÓ G. BOROS](https://www.ddcenters.com/dr-laszlo-boros/) [2:09:30]
- [Zach Bitter](https://twitter.com/zbitter?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [2:10:30]
- Jeff Bullock [2:12:30]
- [Ed Coan](https://en.wikipedia.org/wiki/Ed_Coan) [2:27:30]
- [Paul Attia](https://www.linkedin.com/in/paul-attia/?originalSubdomain=ca) [2:31:15]
- [Arnold Schwarzenegger](https://en.wikipedia.org/wiki/Arnold_Schwarzenegger) [2:38:45]
- [Dorian Yates](https://en.wikipedia.org/wiki/Dorian_Yates) [2:39:30]
- [Mike Mentzer](https://en.wikipedia.org/wiki/Mike_Mentzer) [2:39:30]
- [Skip Lacour](https://skiplacour.com/about-skip-la-cour) [2:40:15]
- [Doug McGuff](https://www.drmcguff.com/about-doug/) ([IHMC podcast](https://www.ihmc.us/stemtalk/episode-24/), [lecture](https://www.ihmc.us/lectures/20191010/)) [2:41:15]
- [Art De Vany](https://en.wikipedia.org/wiki/Arthur_De_Vany) ([IHMC talks](https://www.youtube.com/user/TheIHMC/search?query=art+de+vany)) [2:41:15]

§

![](https://peterattiamd.com/wp-content/uploads/2020/06/dominic-dagostino-bio-image-500x500.jpg)

##### Dom D'Agostino, Ph.D.

Dom is an Associate Professor at the University of South Florida where he teaches at the Morsani College of Medicine and the Department of Molecular Pharmacology and Physiology. He focuses on neuropharmacology, medical biochemistry, physiology, neuroscience, neuropharmacology. Dom holds a PhD in neuroscience and physiology. [See full bio at [KetoNutrition.org](https://www.ketonutrition.org/about)]

Twitter: [@DominicDAgosti2](https://twitter.com/DominicDAgosti2?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)

Instagram: [@dominic.dagostino.kt](https://www.instagram.com/dominic.dagostino.kt/?hl=en)