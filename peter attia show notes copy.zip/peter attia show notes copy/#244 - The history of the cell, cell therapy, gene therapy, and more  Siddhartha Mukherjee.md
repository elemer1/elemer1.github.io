# #244 ‒ The history of the cell, cell therapy, gene therapy, and more | Siddhartha Mukherjee

**Source:** [https://peterattiamd.com/sidmukherjee2/](https://peterattiamd.com/sidmukherjee2/)

---

Siddhartha Mukherjee is an oncologist, Pulitzer Prize-winning author, and [previous guest](https://peterattiamd.com/sidmukherjee/) on The Drive. In this episode, Sid discusses many of the subjects of his latest book, [*The Song of the Cell*](https://www.amazon.com/Song-Cell-Exploration-Medicine-Human/dp/1982117354/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=), including the incredible discovery of the cell and how it transformed medicine. He explains the evolutionary drive to go from single-cell to multicellular life and unpacks the four different types of cell-based therapies and the problems they are attempting to solve. He also provides the latest in gene therapy, such as CRISPR, and the ethical questions around human gene editing. Additionally, he touches on a number of fascinating topics, such as the challenges of medical science, the human brain, learning styles, his writing process, mental health, and more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/sidmukherjee2/the_Drive_public.png)

Play

#244 ‒ The history of the cell, cell therapy, gene therapy, and more | Siddhartha Mukherjee

#244 ‒ The history of the cell, cell therapy, gene therapy, and more | Siddhartha Mukherjee

1x15s30s

0:001:40:45

## We discuss:

- How the cell brings the genome to life, and how Sid’s recent book fits into his prior work to tell a story [2:30];
- How the germ theory of disease and an understanding of the cell fueled a big leap in medicine [9:45];
- What is the evolutionary drive for multicellular life? [17:15];
- Four types of cell therapies and the challenges of gene therapy [26:00];
- CAR T-cell therapy: promising gene therapy for cancer [36:30];
- The possibility of using gene therapy to treat germline mutations like sickle cell disease [41:45];
- The incredible revolution of gene editing with CRISPR [45:15];
- Ethical questions around human gene editing [52:30];
- The complex role of genetics in mental illness [1:01:30];
- Two types of problems in science: the “eye in the sandstorm” problem and the “sand in the eye” problem [1:06:15];
- Understanding neural networks: an example of the “sand in the eye” problem being solved [1:08:45];
- Importance of learning by doing: comparing the learning styles of a doctoral student to a medical student [1:16:30];
- Sid’s unique and brilliant style of writing [1:20:45];
- Falling as the leading cause of accidental death: a liability of multicellular existence [1:25:00];
- Sid’s struggle with depression and his desire to change the stigma around mental illness [1:29:15]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Siddhartha Mukherjee was a previous guest on [episode #32](https://peterattiamd.com/sidmukherjee/) (December 2018)
- Siddhartha is a cancer researcher and a practicing oncologist
  - He’s an Assistant Professor of Medicine at Columbia University and a staff cancer physician at the Columbia University NYU Presbyterian Hospital
- He also happens to be a luminary author; he’s written four books
  - [*The Emperor of All Maladies*](https://www.amazon.com/Emperor-All-Maladies-Biography-Cancer/dp/1439107955/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1674486272&sr=8-1)
  - [*The Laws of Medicine*](https://www.amazon.com/Laws-Medicine-Field-Uncertain-Science/dp/1476784841/ref=sr_1_1?crid=FWWPECIPQ2G2&keywords=The+laws+of+medicine&qid=1674487445&sprefix=the+laws+of+medicine%2Caps%2C132&sr=8-1)
  - [*The Gene*](https://www.amazon.com/Gene-Intimate-History-Siddhartha-Mukherjee/dp/1476733503/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)
  - [*The Song of the Cell, an Exploration of Medicine and The New Human*](https://www.amazon.com/Song-Cell-Exploration-Medicine-Human/dp/1982117354/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=), his most recent book
- In the [first podcast with Sid](https://peterattiamd.com/sidmukherjee/), we mostly discussed *The Emperor of All Maladies: the Biography of Cancer*
  - A book that won him the Pulitzer Prize
- In this podcast, we primarily discuss his most recent book, *The Song of the Cell*
- This is a book that Peter just devoured
  - He wouldn’t have thought he could find a book about the history of the cell so interesting
- In this episode we talk about everything from the evolutionary drive to go from single cell to multicell organisms, all the way up to cell therapy, gene therapy, and CRISPR
- We talk a lot about Siddhartha’s writing process, given that he’s such a prolific writer
- We talk about some very personal things, including his decision to open up about his own depression in his writing

## How the cell brings the genome to life, and how Sid’s recent book fits into his prior work to tell a story [2:30]

**Give us a sense of where your most recent book fits into your prior work**

- [*The Song of the Cell*](https://www.amazon.com/Song-Cell-Exploration-Medicine-Human/dp/1982117354/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) is part of a trilogy and possibly a quartet that Siddharthais working on, broadly called “The Life Series”
- The attempts of these books is to try to explain and understand how we understand life and how we’re manipulating life, living things (particularly humans)
- The first book was *The Emperor of all Maladies,* the second, *The Gene*, and now *The Song of the Cell*
- The best place to probably start is with [*The Gene*](https://www.amazon.com/Gene-Intimate-History-Siddhartha-Mukherjee/dp/1476733503/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)
  - The gene being the smallest unit of information
  - As you end *The Gene*, you realize that genes which are encoded in the molecule DNA, are lifeless
    - They don’t have any autonomous life
    - A gene is just a molecule, it’s a chemical, and it’s the cell that brings it to life
    - Without the cell, all of that code would be useless

> “*I likened the human genome (or any genome) to a score of music, but a score is lifeless. There’s no music in a score, it’s just a code. You need a musician to bring it to life, and the cell is that musician.*”‒ Siddhartha Mukherjee

- There’s no music in a score, it’s just a code
- You need a musician to bring it to life, and the cell is that musician
  - Hence the title of the book, the Song of the Cell
- The second book, to some extent is *The Song of the Cell*, and then the third book, bizarrely enough, is the first book (*The Emperor of All Maladies*)
  - It’s sort of like Star Wars, the prequel to the sequel to the prequel
  - Where you learn about what happens when cells become average

***One way to read the series of books‒ start with*** [***The Gene***](https://www.amazon.com/Gene-Intimate-History-Siddhartha-Mukherjee/dp/1476733503/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)***, move on to*** [***The Song of the Cell***](https://www.amazon.com/Song-Cell-Exploration-Medicine-Human/dp/1982117354/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)***, and finally end up with the dysfunctional average cell, and what happens to it when its genes go haywire (***[***The Emperor of All Maladies***](https://www.amazon.com/Emperor-All-Maladies-Biography-Cancer/dp/1439107955/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1674486272&sr=8-1)***)***

- A completely different way would be to read them as they appeared
  - They progressively go downwards and delve deeper and deeper into mysteries of that history
- The first book was of course a history of cancer and cancer therapy.
- What did we not understand about cancer? Obviously genes and genetics
- What did we not understand about cancer in terms of its cell biology when the cancer genome atlas was completed?
- And what do we understand now?

***If you read chronologically from the first to the third, you would get a different kind of story***

**In** ***The Song of the Cell*****, that era of science had fewer tools and their discoveries are mind blowing**

- This might be tainted by a bit of recency bias because Peter read the books in chronological order, and he just finished reading *The Song of the Cell* (which he enjoyed immensely)
  - He felt more surprised and in awe of the characters in this book than the previous books
  - Peter notes, “*The characters of this story blew my mind even more because of the time and the era in which they had to do their science. There were fewer tools at their disposal.*”
- The characters of that book are uncovering things that are very fundamental
- If you were to do a historical comparison with the history of genetics, you would start with [Gregor Mendel](https://en.wikipedia.org/wiki/Gregor_Mendel) (being the pioneer here)
- There is an enormous period of silence that follows Mendel (almost 40 years) in which basically nothing happens
- Then his work is ultimately picked up by folks like [Thomas Morgan](https://en.wikipedia.org/wiki/Thomas_Hunt_Morgan) and others
- But for a long period of time, nothing happens and nothing is relevant

**What you see in this book is very different because you see a continuation of development**

- After the microscope is invented in the 17th century, you see a gradual blossoming of science
- Ultimately ending up with someone like [Rudolph Virchow](https://en.wikipedia.org/wiki/Rudolf_Virchow), who can make really audacious statements that are missing in the history of genetics until much later
  - The audacious statement that Virchow makes is every function that we carry out, regardless of its origin or regardless of what that function is, is a consequence of cellular physiology
  - “*We, our cells and everything that we do is cellular, is a consequence of something happening in some cell.*”
  - Other statements he says (which are equally audacious), “*Every illness is the consequence of some cell behaving incorrectly*”
  - These statements are made in the mid to late 19th century, almost contemporaneous with Mendel

***You have enormous sets of leaps in cell biology, which is why this book might feel that these characters are doing things while genetics is still plotting its way, trying to understand Mendel’s first very important paper; and there’s a remarkable 40 years of silence, whereas in cell biology, there isn’t that 40 years of silence***

- Peter thinks we take for granted the ingenuity that was necessary to even build the tool to permit their discoveries
  - What the process is like to put together a microscope, to grind the glass and create the lens to give a window into this otherwise invisible/microscopic world
- Siddhartha tried to make make one of [Leeuwenhoek’s](https://en.wikipedia.org/wiki/Antonie_van_Leeuwenhoek) microscopes, and it was not an easy task; it was a disaster
  - And Leeuwenhoek made 500 of them
  - These are single lens microscopes, and they are about the size of half a sheet of paper
  - The lens is smaller than the size of your eyeball
  - There is a sense of the enormous amount of labor of love put into making this thing that’s mounted with tiny screws and tiny little apertures, so that when you look through your eye through the lens in a droplet of water, you can actually see these microscopic forms

***There’s an enormous sense of wonder about how people even began to see these and how they found them and what the consequences of that finding were and are***

## How the germ theory of disease and an understanding of the cell fueled a big leap in medicine [9:45]

- In Peter’s book (which Siddharthaha has read), he talks about this transition from medicine 1.0 to medicine 2.0 (and then the transition from 2.0 to 3.0)
  - He talks about that first transition as two big events, but they were really transition of process
  - 1 – The [Scientific Revolution](https://en.wikipedia.org/wiki/Scientific_Revolution) changed the way we thought
    - The scientific method was introduced in the late 15th century
    - This was a new way of thinking about observation and hypothesis
    - All of the sudden, the idea of bad humors went away
  - 2 – The [Germ Theory of Disease](https://en.wikipedia.org/wiki/Germ_theory_of_disease) was the big moment
    - Once we understood microbial agents and that we had a treatment, we really leapfrogged into the era of modern medicine
    - There has been no bigger reduction in human mortality, than the reduction of death that comes from infectious diseases
- What Peter never thought of until he read *The Song of the Cell,* was that couldn’t have happened without this deep understanding of the cell

> “*This book describes how medicine went from effectively witchcraft, into where we are today*”‒ Peter Attia

- Siddhartha agrees; think of any procedure, childbirth, any surgical procedure, anything that we do, and think of the effect of antibiotics on that procedure
  - Think of how important it is that these antibiotics are now available and the lives saved
  - Just childbirth alone, the capacity of saving lives through antibiotics, has been enormous and transformative
- What’s astonishing in the piece that Siddhartha wrote about microbial biology and the discovery of microbes, is that microbes were imagined in the abstract, long before they were seen
- What’s interesting is, people like [Lister](https://en.wikipedia.org/wiki/Joseph_Lister) (the great surgeon who began to sterilize his instruments), folks like [Semmelweis](https://en.wikipedia.org/wiki/Ignaz_Semmelweis) discovered that doctors were transmitting microbes

**The story of Semmelweis**

- Siddhartha writes about it in his book, and Peter writes about it in his book
- It breaks Peter’s heart when someone dies without getting what they are due, and Semmelweis is the heartbreaking example of that
- It’s also a remarkable story of this transition
- Semmelweis was a junior obstetrician in Vienna
- It’s important that he was so junior, and he made an incredibly important discovery
- Semmelweis was delivering children, and there were [two maternity wards (ward I and ward II)](https://en.wikipedia.org/wiki/Ignaz_Semmelweis#Analysis_of_childbed_fever_mortality)
- This illustrates why it is important in medicine to listen to your patients
- The **most important question** that you ever ask in medicine when you’re trying to diagnose a patient is, to ask the patient, “*What do you think the problem is?*”
  - And it’s the one we forget the most
- A bizarre aberration was going on‒ in ward I, the maternal mortality rates from childbirth were astronomically high; whereas in ward II, with the same people, the maternal mortality rates were much lower
  - One in five women were dying in ward I
- Semmelweis began to ask the question **why**?
- He looked at all sorts of variables; he was a classical epidemiologist
- He found that ward I was run by doctors, and these doctors were running between autopsy rooms (doing autopsies) and then without cleaning their hands, examining patients and delivering babies
- Ward II was run by nurses; nurses who were not doing autopsies or touching any dead material
  - And there was no mortality
- Semmelweis made the **hypothesis** that doctors were transferring (in his words), “*some material substance from the decaying, decomposing dead bodies that they had autopsied, into the bodies of the women that they were examining internally and thereby transmitting that material substance. And that material substance was the source of the putrefaction (or the infection) that these women were getting.*”
- Semmelweis insisted that the doctors wash their hands with a diluted version of bleach, and he saw that suddenly now the [mortality rate plummeted](https://en.wikipedia.org/wiki/Historical_mortality_rates_of_puerperal_fever#Mortality_rates_at_the_Vienna_General_Hospital)
- Remember, he didn’t have a microscope; so this is all in the abstract
- He made this argument that this material substance was responsible for what was then called Childbirth Fever (or maternal infections), and the transfer of the material substance could be removed by hand washing
- In the abstract sense, he had basically founded the Germ Theory
- It was not bad air, it was not bad humors, it was a material substance
- And of course, if he had the capacity to look down the microscope, he would’ve found out that that material substance was in fact nothing else but germs
- He is ridiculed, the last thing that the doctors want to do is to admit that they’ve been infecting other women
- Semmelweis is ridiculed and he’s sent off to an insane asylum, and ultimately he dies impoverished and never vindicated

**Advances in medicine**

- What really captivated Peter about the book is all that we take for granted in medicine is what really allowed this leapfrog, far more so than the genetic revolution
- We thought once the human genome was coded, we would get an equal leapfrog forward, but this didn’t happen

## What is the evolutionary drive for multicellular life? [17:15]

- This is a question Peter had never contemplated until he read this book

**Consider first, single cell organisms**

- Bacteria, protozoa, yeast, etc.
- They’re extraordinarily successful
- They live in virtually every environment you can think of
  - Boiling water, thermal vents, inside volcanoes

> “*The bizarre question you should ask is, ‘why we exist at all?’*”‒ Siddhartha Mukherjee

- We have trillions of cells, why do we exist? Why aren’t we all bacteria?
- The initial idea in the ‘80s, was that there was a massive evolutionary leak from single cell organisms to multicellular organisms
- What is surprising in evolutionary history is, that multicellularity evolved from single cell organisms, not once, but independently multiple times
  - It used to be called a major transition
  - It actually turns out to be a minor transition
  - There was a great evolutionary drive towards becoming multicellular
- You can ask the question then, if single cell organisms are so damn successful, why ever be a multicellular organism?
  - The quick answer is, we don’t know
  - But all the evidence suggests that it has to do with several possibilities
  - The leading possibility is predation; it’s much harder for a predator to eat a multicellular organism for several reasons.
    - It’s bigger
    - It has defense systems
    - It can move away through specialized apparati
  - The other idea is about how multicellular organisms can access food and resources

***Single cell organisms are still the champions. We are just a minor fixture in the world. If you took by weight all the single cell organisms in the world and their diversity, you would be shocked at how successful they still are.***

**Ratcliff’s experiments with yeast**

- [William Ratcliff](https://biosciences.gatech.edu/people/will-ratcliff) is a professor who studies this evolutionary transition from single cell to multicellular organisms
- He did an extraordinary simple [experiment with yeast](https://www.pnas.org/doi/full/10.1073/pnas.1115323109), that he just thought about it over Christmas with his advisor
- He said, “*Well, why don’t we just take some yeast and culture them, and we basically allow them to grow, and we just collect the sediment, and we allow that sediment to grow again in another cycle of evolution.*”
  - Remember that yeast are single cell organisms, and anything multicellular is going to sink to the bottom of the flask
  - This is sort of Darwin in a bottle
  - He did this for 30-40 cycles and found that the yeast evolved
- There are pictures in Siddhartha’s book of these multicellular yeast, these snowflake-like, multi-fingered, multicellular forms (really a new organism)
- What is interesting is when they are left by themselves (no more recollection, no more sedimentation), they continue to propagate as multicellular yeast

***In other words, he created a new lifeform, which is multicellular***

- Even more interesting is when he looked at these multicellular yeast, they started to acquire specialized functions
- You would imagine that one way that these multicellular yeast would reproduce, is that one cell could bud off and create a new multi-fingered, multicellular yeast
  - But that’s not how they reproduce
  - Instead, they use a specialized series of cells that sit in the middle of this [snowflake](https://www.nature.com/articles/ncomms7102?origin=ppub), and commit a purposeful cellular death, such that this snowflake can break into two parts, two snowflakes and grow out new fingers
- From an evolutionary standpoint, this organism learned how to create a specialized furrow in its middle where it can divide into two forms
- Ratcliff has done many versions of this experiment (with [algae](https://royalsocietypublishing.org/doi/10.1098/rsos.180912) and other organisms)

***He finds there are even more specializations. These new “creatures” form little channels to deliver nutrients. They form pores, secondary structures… He created a new kind of life by doing nothing, just by allowing it to evolve naturally.***

- This involved just 30-40 cycles; maybe 60-90 days
- You can imagine over the course of several billion years of history, the extraordinary amount of diversity and specialization that could happen in evolution that leads to people like you and me, having trillions of cells, very committed to doing one thing or another
- Peter thinks about his boys who are 5 and 8, and are obsessed with dinosaurs; for them paleontologists are the most important people in the world
- Peter wonders when he watches these recreations of what dinosaurs looked like, “*How did evolution allow something so large to be in existence so many millions of years ago? And are we basically seeing a correction now?*”
  - Did the pendulum swing too far towards multicellularity where creatures can really defend themselves, get away, go after prey, but are too sensitive to a reduction in food or something like that
  - Had it not been for volcanic eruptions and things like that, maybe we wouldn’t be here today and dinosaurs would be the sentient higher order creature
- Siddhartha replies that this is a “*little bit outside my paygrade… but there are lots of theories*”
  - We know that these life forms were very successful in their environment
  - The problem was that they reached a maximal capacity of size and smaller mammal-like creatures became much more adaptable to the environment
  - But there are a thousand theories about dinosaur extinction, including changes in the atmosphere, meteors and various other volcanoes and events, which you can read in most paleontology textbooks
- When Peter was reading the part about the fitness of the cell, he wondered if there was something about their size that became their downfall, beyond the obvious external factors
- There is an [essay](https://hermiene.net/essays-trans/size_and_shape.html) by [Steven Jay Gould](https://en.wikipedia.org/wiki/Stephen_Jay_Gould) where he talks about a natural biophysical limitation on size
  - That’s because the volume to surface area ratio of any creature reaches a place where it is no longer sustainable
  - Because the surface area of a creature is no longer able to deliver the oxygen and the nutrients required for aerobic living

## Four types of cell therapies, and the challenges of gene therapy [26:00]

**Four types of cellular therapy**

- 1 – A drug or substance used to change the behavior of a cell
  - The simplest example is an antibiotic; it’s used to kill a microbial cell while sparing human cells
- 2 – Transfer of cells from one body to another without modification
  - For example, a blood transfusion
- 3 – Use of a cell to synthesize something
  - DNA is a lifeless molecule, but if you put it inside the right cell, in the right context, the cell will start making proteins out of DNA, and those proteins could be very useful
  - An example is how [insulin](https://en.wikipedia.org/wiki/Insulin#Medical_uses) is made from cells
  - Another example, [Herceptin](https://en.wikipedia.org/wiki/Trastuzumab) is an antibody made by cells and used to treat breast cancer
- 4 – Make a genetic modification in a cell and either transplant it or use if for a therapeutic reason
  - For example, [CAR T-cells](https://en.wikipedia.org/wiki/CAR_T_cell) are an example of genetically modifying T cells and putting them into a human

**Siddhartha’s experiments on bone marrow transplants is an example of this fourth typology**

- Siddhartha has been doing a series of experiments on bone marrow transplants in which they genetically modify the bone marrow (using CRISPR and other techniques), and then transfer them into humans
  - This is essentially creating genetically engineered cells

> “*Gene therapy is really cell therapy*”‒ Siddhartha Mukherjee

- People often talk about gene therapy, and Siddhartha always reminds them that gene therapy is really cell therapy
- If you put the gene in the wrong cell in the wrong place or the wrong time, you get nothing/ disaster
- Gene therapy is really a mechanism to put a gene inside a cell, and that would be the fourth typology
- The book goes through elements of these four typologies, examples, and elements of these four typologies as medicines

**The story of Jesse Gelsinger**

- [Jesse Gelsinger](https://en.wikipedia.org/wiki/Jesse_Gelsinger) (and 18-year-old in 1999) is one of the earliest example of gene therapy in a human
- Jesse had [genetic disease](https://en.wikipedia.org/wiki/Ornithine_transcarbamylase_deficiency) where he had a defect in an enzyme related to the processing of ammonia and ammonia-related substances
- This work was done at the University of Pennsylvania
- The idea was to create a virus that would go to Jesse’s liver and start making the correct version of the gene; that this would ameliorate his disease
- They created a virus they thought would be harmless (a variant of an adenovirus), and they modified it to include the corrected version of the gene Jesse had a problem with
- They infused that virus into Jesse’s body hoping it would infect cells and deliver it’s cargo (the corrected gene), and thereby correct Jesse’s disease
- Peter clarifies‒ we don’t consider viruses in the same category as bacteria, yeast, and fungi
- He asks, “*Are they not living things on their own? They basically contain DNA and RNA, but they’re sort of parasites in that they need us to replicate.*”
- Siddhartha agrees, “*Viruses don’t meet the criteria of living things.*”
  - They are essentially a strand/ multiple strands of RNA (or DNA) that have been packaged usually with an envelope and decorated with some proteins on top
  - By themselves, they can’t reproduce, which is one of the reasons that they’re not considered living
  - The only way they can reproduce is they go and attach themselves to cells, and use the reproduction apparatus present in the cell to make copies of themselves
  - Once they’ve made copies of themselves, they butt out of the cell and then they go in and infect more cells and make more copies of themselves and so forth
- In Jesse Gelsinger’s case, the idea was that this virus would infect his cells
  - And because the virus was genetically modified, it would insert its genetic payload, (the normal gene) into Jesse’s liver cells
  - The liver cells would now start making the protein that was defective, and this is gene therapy.
  - In doing so, it would reverse his relatively mild disease
- A rather terrible thing happened
- Siddhartha has a very moving testimony from his father, which is in [*The Gene*](https://www.amazon.com/Gene-Intimate-History-Siddhartha-Mukherjee/dp/1476733503/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)
- In retrospect, we think that Jesse mounted a very vigorous immune response to the virus
  - A virus is a foreign body, and you mount an immune response to it, especially if you for whatever reason, have been exposed to that virus before
  - [Adenovirus](https://en.wikipedia.org/wiki/Adenoviridae) can cause the common cold; they are in circulation
  - There is suspicion that Jesse had been exposed to the wild form of that virus before (perhaps through a common cold or something like that), and his immune system went berserk, because it was now recognizing not one virus particle, but millions of particles suddenly into his body

***Unfortunately, Jesse died from the consequences of this very hyperactive risk immune response raised against that virus and, the whole field of gene therapy was frozen for almost a decade as we slowly learned the cause of that death and how we could prevent it in other people***

**What is a safer place to consider using gene therapy?**

- There are safe harbors in the body; these are places that the immune system doesn’t usually reach easily
  - For example, the retina
  - The testes is another place, although we have not used that for gene therapy
- There are also new drugs that can dampen down the immune response
  - Think of the immune response as a dial
  - What you can do is you can dial the immune response down so that the immune response doesn’t respond so briskly to the gene therapy
- You can hide the virus; you can make a virus that your body has not seen before, that won’t raise a brisk immune response
- You can do is you can give the gene therapy in small doses
  - It’s called hyperfractionation
  - Fractionation being small fractions so that the immune system doesn’t again go berserk seeing this massive bolus of a dose of virus
- These strategies they’ve been very successful such that now, the number of deaths from this hyperactive immune response are much, much, much more controlled than in Jesse Gelsinger’s times (but the possibility of this remains)

## CAR T-cell therapy: promising gene therapy for cancer [36:30]

**CAR T-cells are one of the great successes of cancer treatment, explain how gene therapy works in that regard**

- [CAR T-cells](https://en.wikipedia.org/wiki/CAR_T_cell) are a very special example of gene therapy
- What happens is you extract normal [T cells](https://en.wikipedia.org/wiki/T_cell) from a human who has cancer, and you use gene therapy to weaponize the T cell so that they can attack cancer cells
  - A T cell is part of the immune system; its job is to hunt out and kill foreign cells
    - Cells that have been infected by viruses, or foreign cells that have somehow entered the body.
    - A T cell is a foreign cell detector built into your body
  - So now you take that T cell and weaponize it to recognize the cancer cells as foreign, you grow them in a Petri dish in the laboratory, and you re-inject them into the body
- Siddhartha’s lab has done a lot of this work
  - Siddhartha co-founded the startup [Immuneel](https://immuneel.com/company/#leadership) to reduce the cost of CAR T-cell therapy in India
- The cost of doing this in the US is astronomical, almost $500,000 to $1 million per person
- They are trying to reduce that cost 20-fold (or even 50-fold) in India using new technologies
- They’ve treated 11-12 patients already and just released the [data](https://immuneel.com/wp-content/uploads/2022/12/Immuneel-IMAGINE-Study-Phase-II-Varnimcabtagene-autoleucel-Early-Results-Press-Release.pdf), and it looks very good
- CAR T-cell therapy is used to treat blood cancers like lymphoma, leukemia, and myeloma
- It has not been successful in treating solid tumors, for reasons that we’re still trying to understand

> “*That’s what a CAR T-cell is. It’s a weaponized T-cell that goes and kills cancer cells in your body.*”‒ Siddhartha Mukherjee

**Why is there a 20-50-fold reduction in cost doing this in India as opposed to the US?**

- Peter notes that cancer is full of marginal treatments that extend median survival by two months, at a cost of $100,000
- Siddhartha explains that some of it is a structural problem in  America
- 90% of drugs fail, and pharmaceutical companies make the argument that they’re trying to recoup the R&D costs of those failed drugs with the successful
  - That’s a complicated and somewhat specious argument because you could ask, “*Why do these drugs fail in the first place? Is it because drugs always fail? Is it because you didn’t understand something about the human body before you therefore took this drug all the way to spend millions, perhaps even billions of dollars on the drug?*”
- The second reason is that CAR T-cells are intrinsically expensive to make
- The success rates of CAR T-cells are incredible, not just 1-2 month survival
- Siddhartha’s book begins with the story of Emily Whitehead
  - She was seven when she was treated with CAR T therapy
  - Now she is 16-17, applying to college, completely cured

> “*We’ve seen people who’ve had terrible leukemia [and CAR T-cell therapy] essentially eradicate the leukemia forever and [they] become cured*”‒ Siddhartha Mukherjee

- The problem is that CAR T cells are intrinsically hard to make
  - The quality control that’s required is much, much greater than making aspirin or making any other tablet
  - You have to grow T cells in an incredibly sterile environment (GMP facility) where you have to basically put on a hazmat suit to go in
    - It has to be monitored because a single bacteria or a fungal infection will take that entire batch of T cells away

*They reduce the cost several ways*

- 1 – They make the virus in a much cheaper way (reduced the cost of the patent burden)
  - They don’t have to recoup all that R&D cost
- 2 – They’ve changed the machinery used to harvest the cells
- 3 – Hospital treatment and therapy in India is much cheaper to begin with

***All of this comes to a 10-20-fold reduction in cost***

## The possibility of using gene therapy to treat germline mutations like sickle cell disease [41:45]

**Are we in the realm of approaching success here?**

- A person with a [germline mutation](https://en.wikipedia.org/wiki/Germline_mutation) that results in pathology (like Jesse) is much harder to treat
- [Sickle cell](https://en.wikipedia.org/wiki/Sickle_cell_disease) is an amazing example because a single amino acid difference has such catastrophic consequences on the life of a person
  - We know exactly what gene drives that
    - A mutation in the [hemoglobin gene (*Hb*)](https://en.wikipedia.org/wiki/Hemoglobin), the oxygen carrier in the blood
    - Sickle cell is caused by a [mutation in the *HbA* gene, known as *HbS*](https://en.wikipedia.org/wiki/Sickle_cell_disease#Genetics)
  - If you inherit two copies of the mutation, you get terrible disease
  - In a low oxygen environment the red blood cells form sickles (shown in the figure below) and clog up  small blood vessels all over the body (micro strokes)
    - This causes terrible pain

![](https://peterattiamd.com/wp-content/uploads/2023/02/f1-sid2.png)

**Figure 1. Altered blood shape in sickle cell disease clogs blood vessels.** Image credit [*JAMA* 2023](https://jamanetwork.com/journals/jama/fullarticle/2800764)

- Fantastic new results in sickle cell anemia have been published in very major journals and will continue to get published (reviewed in [*Blood* 2021](https://ashpublications.org/blood/article/138/11/932/476349/Gene-therapy-for-sickle-cell-disease-moving-from))
- Two or three approaches have been tried to use gene therapy to fix the mutated gene (illustrated in the figure below)
- 1 – [Gene therapy](https://en.wikipedia.org/wiki/Gene_therapy) to introduce the normal version of hemoglobin (*HbA*)
- 2 – [Gene editing technology](https://www.nejm.org/doi/10.1056/NEJMoa2031054?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed) has been used to change both copies of the gene to make them normal
  - Take a bone marrow sample (where blood cells are made), change the gene from the abnormal form to the normal form, then reinfuse that back into the patient
  - This is the **gene correction strategy**

![](https://peterattiamd.com/wp-content/uploads/2023/02/f2-sid2.png)

**Figure 2. Gene therapy for sickle cell disease**. (A) Antisickling globin expression as a gene-therapy strategy to prevent RBC sickling. (B) Gene-addition strategy to deliver antisickling genes. (C) Gene-editing approaches to induce *HbF*. Image credit: [*Blood* 2021](https://ashpublications.org/blood/article/138/11/932/476349/Gene-therapy-for-sickle-cell-disease-moving-from)

- 3 – Another strategy involves [fetal hemoglobin (*HbF*)](https://en.wikipedia.org/wiki/Fetal_hemoglobin)
  - The human fetus has a special kind of hemoglobin (different from adult hemoglobin) because the fetus has to extract oxygen from mom’s blood
    - And mom’s blood, by the time it reaches the fetus, has already been depleted of oxygen because it’s gone through her body
  - The fetus has a special form of hemoglobin that can even extract oxygen out of mom’s blood
  - Another approach to sickle cell anemia is to forget about the sickle gene problem and reactivate/ express/ make fetal hemoglobin in an adult
    - In that case, you don’t need to correct the gene, you leave the gene as it is
    - You just make fetal hemoglobin, which is very, very avid as an oxygen delivery machine
  - Now the cells don’t sickle anymore because they don’t have this problem in a low oxygen environment
  - This approach has also been successful

***To summarize, you can either (1) give gene therapy to express a corrected version of the sickling gene (HbA), (2) use a second approach where gene editing technology is used to change the gene back to its normal form (HbS → HbA), or (3) reactivate expression of fetal hemoglobin (HbF) to correct the defect. All three are in trials, and all three have shown various measures of success.***

> “*My impression is that during our lifetime, we’ll see a cure, a permanent cure for sickle cell anemia*”‒ Siddhartha Mukherjee

## The incredible revolution of gene editing with CRISPR [45:15]

- Siddhartha remarks, “*The world of genetics was turned upside down in a very important way by the discoveries of* [*Jennifer Doudna*](https://en.wikipedia.org/wiki/Jennifer_Doudna)*,* [*Emmanuelle Charpentier*](https://en.wikipedia.org/wiki/Emmanuelle_Charpentier) *and several others I should mention* [*Feng Zhang*](https://en.wikipedia.org/wiki/Feng_Zhang) *and* [*George Church*](https://en.wikipedia.org/wiki/George_Church_(geneticist))*. And there’s a history of this, which is in the book.*”
- Imagine the human genome as a massive library
  - If it was printed in normal text, it would contain 80,000 books
- Imagine that you wanted to make a change in one word in that library
  - You want to take book 61 on shelf 47 and make a change from verbal to herbal in that library
  - This was a dream of scientists for a long time and no one could do it
- And then Jennifer Doudna, Charpentier, assisted by Feng Zhang and other people figured out that there was a bacterial system that evolved millions of years ago that could make that precise change in one word in that entire library
  - Either deleting that word (erasing it, the simplest change) or potentially changing the word to another word

> “*It’s an incredible genetic revolution. As we move forward into this new universe, we have the capacity to change the human genome in a deliberative and a processed manner.*”‒ Siddhartha Mukherjee

- Consider the sickle cell anemia example discussed before, we can change that gene to the normal gene using the [CRISPR gene-editing](https://en.wikipedia.org/wiki/CRISPR_gene_editing) technology
- We can change the abnormal cystic fibrosis gene to a normal gene (or the wildtype version) using this technology
- This is exciting because we couldn’t change genes to new genes before, but now we have the capacity to do this
- We can do this with embryonic stem cells, bone marrow cells, T cells CAR T-cells)

***It’s a revolution, the depth and breadth of this is enormous***

**Explain using the library analogy how this system differs from the approach that was used 20 years ago in the case of Jesse Gelsinger that we described where an adenovirus was used?**

- Again, imagine the human genome as a massive library, 80,000 books printed on a page
- The old technology that was used with Jesse Gelsinger is the technology in which I’m using metaphors and analogies here
- We would insert a new page into that 80,000 page library
- The librarian could come in this case, that immune response (the T-cell or the B-cell immune response) and say, “*Wait a second that’s not a page that belongs*,” and that’s what happened with Jesse Gelsinger and other people
  - The librarian being the human body would come and say, “*Wait a second, you are inserting new pages into a library, that’s no good*,” and they would prevent that
- Peter notes that it seems it was much harder to know where to put that page; if you wanted it to be between page 87 and 88, you might accidentally insert it somewhere else
- Siddhartha agrees, you’re reading along and all of a sudden you find a new page that’s been taped in, the virus that’s carried in the new gene,and you say, “*Wait a second, that doesn’t belong there*”
  - And that was where the technology sat for years and years until [Jennifer Doudna](https://en.wikipedia.org/wiki/Jennifer_Doudna), [Charpentier](https://en.wikipedia.org/wiki/Emmanuelle_Charpentier) and others discovered a method in which you would do just quite the opposite
- With CRISPR, you can go into one page, in the right volume of the right book and change one word
  - The first change was just deleting a word
  - Then with more and more research, you could change the word
  - You could change the word verbal to herbal by changing a single letter, and leave the rest of the library intact (for the most part)
  - And if you were a very vigilant librarian, you would say, “*That’s okay, you haven’t put an extra page in Charles Dickens’ book. You’ve actually gone to the right book and changed the right word in the right space, in the right time from one to another*.”

***CRISPR allows us to make extraordinarily precise changes in extraordinarily precise ways in a massive library, which would not be possible otherwise***

## Ethical questions around human gene editing [52:30]

**JK and the CCR5 gene**

- All the details are in [*The Song of the Cell*](https://www.amazon.com/Song-Cell-Exploration-Medicine-Human/dp/1982117354/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)
- A Chinese scientist who goes by [JK He](https://en.wikipedia.org/wiki/He_Jiankui) made a somewhat bizarre decision
- The human gene CCR5 (the lack of it) makes cells resistant to HIV infection
- He Jiankui decided that he was going to make a change in human embryos with gene editing technology (CRISPR), which would make the child of a couple in which the man was HIV positive and the woman was HIV negative
  - He would make that change in the embryo so that they would be HIV resistant, and implant those altered embryos into the mom
- This sounds great on paper, but the risk of these children to acquire HIV is basically zero, since they were produced by [IVF](https://en.wikipedia.org/wiki/In_vitro_fertilisation)
  - The sperm doesn’t carry HIV
  - This was not medically necessary

**Siddhartha makes a very big distinction between disease and desire**

- Disease is fundamentally linked to suffering
- When we talk about desire, we talk about the idea or aspiration to ameliorate suffering even where there’s no suffering involved as far as we can tell
- Now, in this case, there was no disease; the children had no risk of disease
- The desire was an entirely scientific desire to create a genetically modified embryo
  - That He Jiankui would be the first in human history to create a human embryo with genetically altered cells

**Outcome of gene editing IVF**

- JK went ahead with this project and created two girls
  - We don’t know their real names; they’ve been called Lulu and Nana
- What he obtained was not exactly what he hoped for, which is not that precise erasure of verbal to herbal in a single book in the entire library of 80,000 books
- What he obtained was a much cruder version of that
- Scientists across the world were concerned about the duty of informed consent
  - Did the parents even understand the language that we’re using?
  - The risk of these children getting HIV was zero
  - They had no disease, there was only this desire to create someone who was potentially resistant to HIV infection

***This is a very unusual situation‒ the desire to push the frontier of science and change human embryos where there is not disease***

- The scientific world became extraordinarily incensed about the idea that this scientist had crossed the boundary between disease and desire
- If this had been some disease that the children had inherited, cystic fibrosis, sickle cell disease, Huntington’s disease, some terrible thing that they would encounter in their lifetime, the scientific community would’ve been much more sanguine about it

> “*There’s probably no greater example of the relationship between science and philosophy*”‒ Peter Attia

**Where does one draw the line?**

- This is why a doctoral degree is formally called a doctoral of philosophy
- Peter notes, “*When you think about this question, it becomes kind of difficult*”
- This topic is explored in [Walter Isaacson’s](https://isaacson.tulane.edu/) biography of Jennifer Doudna ([*The Code Breaker*](https://www.amazon.com/Code-Breaker-Jennifer-Doudna-Editing/dp/1982115858/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1674655152&sr=8-1)) and in [*The Song of the Cell*](https://www.amazon.com/Song-Cell-Exploration-Medicine-Human/dp/1982117354/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)
- [Huntington’s disease](https://en.wikipedia.org/wiki/Huntington%27s_disease) is a great example in the sense that you have an acquired genetic mutation that is 100% penetrable
  - It’s a devastating disease that shortens life and leads to immense suffering
  - Would we find many philosophers of science who would say that it is wrong to alter the embryos of adults who have Huntington’s disease or carry that trait, that gene to prevent it from going to their offspring?
  - If you play the thought experiment out, that would eliminate Huntington’s disease altogether because these are germline mutations
- How does the scientific and philosophical community merge over questions of that nature?
- And then eventually do we move that further to [*APOE4*](https://en.wikipedia.org/wiki/Apolipoprotein_E), [*LPA*](https://en.wikipedia.org/wiki/Lipoprotein(a)), and other genes that are not as [penetrant](https://en.wikipedia.org/wiki/Penetrance)?
- Siddhartha discusses the example of how devastating *APOE-ε 4* (AP4) can be for people who have combinations of AP4 that increase their risk for early Alzheimer’s disease
  - The penetrance of this gene is not huge as it is for Huntington’s
  - A gene with **high penetrance** means if you inherit the gene, the chances that you’ll have the disease is very high
  - With **lower penetrance** genes, you might inherit some mutation in a gene, but you might *not* get the disease
    - [*BRCA1*](https://en.wikipedia.org/wiki/BRCA1) is a good example, you may inherit this gene but escape having breast cancer in your lifetime
- The biomedical community would say that for diseases like Huntington’s disease, it’s probably worthwhile doing an intervention, whatever that intervention might be
- But in this case for HIV, it is *not* warranted; it simply isn’t necessary

> “*It moves towards desire without moving towards disease*”‒ Siddhartha Mukherjee

**Ethical debate**

- Peter notes other examples of things clearly on the desire spectrum‒ enhancing intelligence or physical traits like strength, size, etc.
- The area he finds most interesting is around mental health
  - Autism and schizophrenia have an enormous genetic component
  - On the surface it might seem like it would be great if fewer people were born with autism/ schizophrenia
    - But it’s nowhere near that simple, is it?
- There’s  a Pandora’s box upon which we have no idea what we could lose as a society if we were to sort of “sterilize” some of these conditions

## The complex role of genetics in mental illness [1:01:30]

**The last cellular territory are the cells of the brain**

- For Peter, the brain has the most complicated cells in the body
- This is one area where it’s very difficult to appreciate a phenotype under a microscope or in a scanner
- Part of it has to do with the complexity of these genes

**What questions might society face around the use of this type of precision gene editing when it comes to genetic conditions of the brain?**

- Siddhartha agrees, “*The brain is the most complex of all organs, and it’s important to understand that complexity*”
- When thinking about diseases, like autism and schizophrenia , there are (broadly speaking) two kinds of genes in the entire spectrum of genetics that have to do with mental diseases
- 1 – Siddhartha calls a **shove gene**; shove, meaning it pushes you really hard
  - Think about height; height has a strong genetic component
    - Tall parents tend to produce tall children, and short parents tend to produce shorter children
    - So, we know there’s a genetic component to it
  - There are genes in the spectrum of controlling height that are very powerful shove genes
    - They shove you in one direction or the other
  - One example is [Marfan syndrome](https://en.wikipedia.org/wiki/Marfan_syndrome), a genetic disorder caused by a single gene
    - If you inherit copies of that gene, you will likely be extremely tall, and you might have other medical and other complications, but you’ll be tall for sure
    - There’s a story that Abraham Lincoln may have inherited the Marfan gene
  - ***Shove genes are relatively rare in the human population***
- 2 – The more common variant is what Siddhartha calls **nudge genes**; nudge versus shove
  - Nudge genes move you little by little, by little, by little, by little towards increasing height
  - There might be hundreds (or tens of hundreds) of genes that may increase your height little by little, by little, by little, by little until you get five feet 10 inches, five feet 11 inches, six feet, etc.
- Now, transfer that same idea to mental health
- There are certainly genes in the human genome that change your neuron physiology, the physiology of your nerves that are shove genes
  - In other words, if you inherit them just like Marfan syndrome, you are much more likely to have mental illness (in whatever form it is)
  - They are relatively rare, and they are inherited in families
  - There’s a great book on this written recently about a family that has multiple kids with schizophrenia, etc. called [*Hidden Valley Road*](https://www.amazon.com/Hidden-Valley-Road-Inside-American/dp/038554376X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1674657060&sr=8-1)
- Most mental illness is not a consequence of this shove phenomenon, but are consequences of “death by a thousand cuts”, small nudges that would push you towards depression, schizophrenia, autism, etc.
- And in fact, in some cases we haven’t even found those genes yet, even though we know they exist
- The capacity to change those genes is very limited because the examples that I gave you of gene editing, gene alteration technology, are limited to one gene, two genes, three genes
- It’s very, very hard to find a way to change hundreds, potentially tens of hundreds of genes in the mental health spectrum
- So, it’s not as if we can all of a sudden wake up one morning and say, “*I’m going to change your mental health or change the mental health of your embryo based on the understanding of our shove genes*,” because it just won’t happen

## Two types of problems in science: the “eye in the sandstorm” problem and the “sand in the eye” problem [1:06:15]

**The complexity issue around the brain**

- Peter remarks, “*You do a great job of it in the book describing the mystery. And you came up with a way to describe it that I thought was fantastic, which was…*
- *You said there were two types of problems in science. There are the eye in the sandstorm problems versus the sand in the eye problems. And as the cellular biologists and neurobiologists were getting deeper and deeper into the brain, and it really seemed like they had figured out this thing, these axons, the movement of electricity, these action potentials. They were figuring this out, but they had a little piece of sand in their eye.*”

**What was that piece of sand?**

- It’s a fanciful description, and it’s an important, philosophical distinction
- The **eye in the sandstorm problem** is a problem in which you encounter something in medical sciences where the information just doesn’t fit
  - It’s being in the sandstorm
  - An example is when we made the transition in physics between Newtonian physics, and quantum mechanics, and Einsteinian understanding
  - In other words, you reached a place, and all of a sudden, everything didn’t fit
    - The bending of light, the presence of relativity, etc.
    - So, you needed a completely new theory, a new paradigm, a total shift in paradigmatic thinking
  - There’s sandstorms everywhere, and you can’t make sense of the real world
  - That’s one kind of problem, and Siddhartha is interested in those problems
- The **sand in the eye problem** is a different kind of problem; it is when everything fits except one fact
- It’s very important to understand that both of those are really interesting because the sand in the eye problem says that our theory is almost right, but it’s not right because there’s a fact that won’t fit

## Understanding neural networks: an example of the “sand in the eye” problem being solved [1:08:45]

- When people discovered neurons in the brain, they figured out basically by looking at anatomy that there was a space between neurons, that nerves weren’t just wires
  - If you were an electrician fitting out an electrical situation in an apartment, what you wouldn’t do is put spaces between the wires so that all of a sudden, that space would become a communication between wires; you just hook the whole apartment up
  - When people like [Ramón y Cajal](https://en.wikipedia.org/wiki/Santiago_Ram%C3%B3n_y_Cajal) and other scientists figured out how to solve this problem, they understood all of a sudden, that nerves have spaces in between them (called a [synapse](https://en.wikipedia.org/wiki/Synapse))

**The synapse turns out to be extraordinarily important for neuroscience**

- What happens between nerves is that an electrical conduction moves from one end of a nerve to the other, and then it changes from an electrical conduction to a chemical signal between one nerve to another, and that chemical signal resparks an electrical conduction
  - So it’s going chemical, electrical, chemical, electrical, chemical, electrical
  - This is important because what your nervous system is doing is in that transmission between electrical, chemical, electrical, chemical, is it’s putting weights, so that in the chemical transmission, an electrical impulse could come down a nerve
- Let’s say there are 10 nerves (10 neurons/ nerve cells) that are impinging on one nerve cell
  - You could assign a weight as to how much this one was transmitting versus another one
  - And by assigning those weights/ calibrations, you could say one is louder than the other
    - One is softer than the other
    - One inhibits the other
  - And it’s those combinations of inhibition, loudness, etc. that allow profound things like sentience, and conversation, and consciousness and so forth
- This analogy explains how neural networks work
  - There are weights put on how one layer of communication communicates with a second layer of communication
  - In other words, some are louder than others, some are softer than others
- Imagine discriminating a dog from a cat
  - You could say that a very loud signal in that discrimination is if the animal happens to bark
    - You know that for sure that’s not a cat
  - A very soft signal could be the weight of the animal
    - Some dogs are lighter than cats
  - A very loud signal could be the way that the snout of an animal is fixed with the head of the animal
    - Dogs have a particular snout, head combination
    - Cats have a particular snout, head combination
  - So, by adjusting the weights of these combinations, we think by analogy that this is how the brain can discriminate between dogs and cats
  - We don’t know this for sure because this is an area of science that’s still in process

**Siddhartha’s takeaway‒**

- This classic example, in the 1950s of the idea of why on earth would you take an electrical signal, convert it to a chemical signal, and then convert it back to an electric signal?
- The answer is because if it was just an electrical signal, we’d be a box of wires
- And a box of wires without the weight between individual signals (between the wires) is a useless box
  - Because we cannot understand how to construct a learning network between a box of wires
  - Whereas we can understand how we can construct a learning network between electrical and chemical stimulations because we can modulate the strength of that chemical simulation such that we can really actually learn a process

**Another way Peter likes to explain it is using music**

- Think of the electrical signals that travel down the axon as digital
  - It’s either completely on or completely off; there’s no modulation
  - Imagine an orchestra where every instrument could only play at one maximum decibel level or not at all
  - You would have no modulation of sound, and it would be a very awful sounding music
- But if you could have analog adjustment of music, and now each of those instruments can go up and down, crescendo, decrescendo, and modulate
  - Now we can make songs

**How did evolution figure this out?**

- Siddhartha thinks the reason is learning
- In a purely electrical system there is no modulation
  - By analogy, everything in music has the same volume, same tempo, same time
    - That’s not music; that’s not the “song of the cell”
- Our evolution converged on the idea that music has tempo, it has space, some pieces are softer, some pieces are louder
  - And by altering this loudness, softness as we move along in our neurons, that we can produce not just a mechanical output of the score

***We are not producing a mechanical output; rather, we’re producing a learned output, and that mature output has to do very much with modulation***

- In the mature output, some parts are louder, some parts are softer, some parts speed up in rhythm, some parts slow down in rhythm
  - And that is ultimately the music of the cell, but also, the music of the brain

## Importance of learning by doing: comparing the learning styles of a doctoral student to a medical student [1:16:30]

- Peter notes, when Siddhartha went to Oxford to do his PhD as a Rhode scholar, he ended up in a lab where he learned immunology from his mentor [Enzo](https://en.wikipedia.org/wiki/Vincenzo_Cerundolo)
- He would go on to Harvard Medical School and get a great medical education
- But he was committed to this path of becoming a scientist first, a physician second

**What is it that was bestowed on you from a learning perspective, as a doctoral student that we don’t really get in medical school?**

- It’s a very different kind of thinking process
- Siddhartha likes to make medicines, medicines that are important for human life, hopefully for saving lives
  - He talked about some of them in a [prior podcast](https://peterattiamd.com/sidmukherjee/)
- Textbook knowledge in medicine and biology is important because it lays the groundwork and the foundations of what we know and what we understand
- But textbook knowledge only gets you so far because when you come into the actual laboratory, you understand that there are things that are predictable, there are things that are not predictable
- And then you get into these “eye in the sandstorm” and “sand in the eye problems”, which are very important
- You learn to recognize failure
- You learn to recognize how to troubleshoot your way out of failure

***None of this is in a textbook***

- Open a textbook of biology, any textbook of biochemistry, biology, and try to find me a section on troubleshooting
- Troubleshooting your way out of failure is the most standard way that we think about medicine and biology
- Nothing in a textbook will tell you about to select a patient for a clinical trial
- A textbook won’t tell you how to manage a patient with complications for a clinical trial
- You run an experiment which will set you up for a clinical trial
  - There is no information in that textbook about how to troubleshoot, where and how to do that science that allows you to make it into human medicine
  - What if for instance, you suddenly find that the medicine that you’re working with or you’re trying to create isn’t pure, that there’s a contamination?
    - How do you remove that contamination?
    - There is no method; you can’t find a textbook
- What you do is you ask your peers who’ve done this before you

***There is a kind of learning that we do by doing, that we be by being, that we acquire by acquiring, that cannot be found in any book or textbook in the medical sciences, and there’s no way around it***

> “*I wanted to write about that process of learning by doing, learning by being, learning by experiencing*”‒ Siddhartha Mukherjee

## Sid’s unique and brilliant style of writing [1:20:45]

- Peter comments on what an amazing writer Siddhartha is; he calls it a gift but doesn’t want to suggest it doesn’t require an obscene amount of hard work
- He says, “*I think you are hands-down the best writer who happens to write about anything that has to do with science in medicine*”

**At what point in your education did you realize you had a brilliant way to write?**

- Writing is not an easy process for Sid; it’s a weird process
  - He throws in everything
  - He has a policy in which there’s nothing that’s outside of his box
- Writing is a way for him to think and work through his thoughts
- The analogies and metaphors of his writing are not really in service of writing but in service of making him think and understand why a certain phenomenon is related to another phenomenon
- He draws from mythology, philosophy, conversations, interviews… everything goes into a book
- Medical writing was about medicine; it wasn’t personal
  - There was sharp distinction between memoir and case histories
  - There was sharp distinctions between deep history and an interview or journalistic writing
  - Siddhartha felt these distinctions are arbitrary
- Siddhartha thought, “*Why not erase all of them and make a new kind of writing in medicine or in life?*”
- The most important thing that people told Siddharthaabout medical writing was when people read writing about medicine, they want to enter your cosmos
- People want to know what it’s like to be like you
  - It’s absolutely intense exhilaration when a clinical trial is successful, absolute depths of depression and crisis when a clinical trial fails

- Absolute anticipation, absolute apprehension, absolute admiration for people on whose shoulders he stands
- He’s like you, he has terrible days, very good days, exhilarating days
- He makes inventions; some of them work and some of them don’t
- All of it is wonderful and terrifying at the same time

***Siddhartha will combine memoir, journalistic writing, traveling writing, philosophy, mythology, everything. He’ll throw everything in there so that you understand what it’s like to be like him.***

## Falling as the leading cause of accidental death: a liability of multicellular existence [1:25:00]

- Two things Siddhartha wrote about in different parts of the book are completely unconnected, but in Peter’s mind they were immediately connected
- Peter thinks a lot about the end of life
  - How we can delay and push of the end of life
  - How quickly life can vanish in an older person when they fall
- Siddhartha wrote very openly about his own depression (that kicked in a year after his father’s death, which resulted from a fall)
- And near the very end of the book, he wrote about the end of [Virchow’s](https://en.wikipedia.org/wiki/Rudolf_Virchow) life
  - Peter was completely unaware that he ultimately died as a result of a fall and a broken femur

***Falls are the leading cause of accidental death***

- If a person over the age of 65 falls and breaks their femur, mortality is anywhere from 10-30% at 12 months (depending on the study)
- When a lot of people are confronted with that fact, they simply can’t understand it, but Siddhartha does a very good job explaining it
  - Peter couldn’t believe how Siddhartha tied it back to the cell
  - It starts with the [osteoclast](https://en.wikipedia.org/wiki/Osteoclast), the [osteoblast](https://en.wikipedia.org/wiki/Osteoblast), and the matrix of the hip, and ultimately, it leads to organ failure
    - That’s not a leap that’s easy to make; it’s not obvious

**It’s obvious when you think about Virchow’s idea that the body is a citizenship**

- Imagine a citizenship in any capacity
- All of a sudden, your Bureau of Transportation decides to take a leave for 20 days
  - The trains in New York City stop running
  - Therefore, people can’t go to work and the economy collapses
  - The economy collapses, and all of a sudden, people who are dependent on small changes in their lifetimes, wage workers, collapse
  - And then the entire system, the network of systems collapses, all because the Department of Transportation closed down for two days
- That’s what happens in the human body
- That’s the liability (in some ways) of multicellular existence
  - There are many advantages of multicellular existence (discussed earlier)
- One example of a liability‒ you depend on your pancreas for insulin
  - Your brain doesn’t make insulin
  - You depend on your brain for sentience and consciousness
  - You depend on your muscles for movement
  - Your brain can’t produce movement without muscles
- There’s a citizenship that bodies develop and have developed with each other so that we, together, perform as organisms; and if you take away one piece of that (a broken bone), it pings into a capacity not to move
  - The capacity not to move wastes your muscles
  - Your wasted muscles then communicate with the rest of your body (via hormones)

## Sid’s struggle with depression and his desire to change the stigma around mental illness [1:29:15]

**How much did you weigh the pros and cons of writing about such personal matters as your own depression?**

- Peter adds, “*We o still live in a world where it’s not entirely clear to me why we view depression different from hypertension*”
- It was a conscious choice for Siddhartha; he talked to his family about it
- Depression can be what’s called an organic disorder
  - A disorder in mood-regulating neurons in your brain
  - Just like type 1 diabetes is an organic disorder, a disorder in the inability of pancreatic beta cells to secrete insulin
- The reason these are viewed differently is that we associate a kind of victimhood to mental disorders, and that kind of victimhood is punitive
  - It blames victims for being victims in a way
  - We don’t say, “*Oh. You’re hypertensive because you have genetics or have behaviors, etc. that are related to your hypertension.*”
  - But depression and mental disorders, grief, and perhaps even more complex disorders (schizophrenia), have a sense of blaming the victim (the person who’s experiencing the disorder)
- This has to do with the idea that the brain is separate from the rest of the body; it’s a special organ
- But on the other hand, it’s also an organ that has physiology, just like your pancreas has physiology, just like your heart has physiology
- Siddhartha wanted to get away from is this idea of special victimhood and talk about the brain as a cellular cluster
  - And thereby remove this or defend or even challenge this idea of victimhood and responsibility, because most people who experience severe clinical depression experience it as a consequence of environmental and emotional stimulation
    - The grief of dying, the grief of their situation
  - But there are neuronal or nerve cells and nerve cells circuits that push them in biochemical and chemical ways towards the state in which they cannot function
  - And he wants to highlight that absence of function

***If Virchow was alive today, he would say that absence of function (or that dysfunction) is not dissimilar to a person who has a failing heart or a failing liver because that function is a dysfunction of mood-regulating circuits and neurons in the brain, just as type 1 diabetes is a dysfunction of insulin-regulating cells in the pancreas***

- Siddhartha thinks that idea is important and radical in this book
- Peter spoke to [Karl Deisseroth](https://profiles.stanford.edu/karl-deisseroth) about this
  - Both agree that his book is excellent, [*Projections: A Story of Human Emotions*](https://www.amazon.com/Projections-Story-Emotions-Karl-Deisseroth/dp/1984853694)
- Karl was a classmate of Peter’s in medical school, and he talks about this idea that in psychiatry, we have not one biomarker or radiographic finding that lends itself to a diagnosis
- In the example of a failing heart or failing liver, we have a menu of things to aid in the diagnosis
- It’s much easier to make that diagnosis today than when William Osler had to make the diagnosis 125 years ago
- The inside of our brain is still this black box, in some ways
  - Peter can’t help but wonder where we will be in 20 years; he feels like there is enormous potential
- Siddhartha agrees, biomarkers are helpful, but ultimately, it’s a clinical decision
- He always tells people who haven’t been in clinical medicine, “*When you see depression, you know depression*”
- This is what humans can see about other humans
- There is a disproportionality or a disconnection between the level of grief that a person experiences and the level of grief that persists when a person is clinically depressed
  - The ennui, the level of psychomotor inability to move
- Even in the absence of biomarkers, there is a new age that is coming, and a respect for the autonomy of patients who experience neurological and psychiatric diseases
- [Deisseroth](https://profiles.stanford.edu/karl-deisseroth) writes about them very carefully and very thoughtfully
- [Andrew Solomon](https://sps.columbia.edu/faculty/andrew-solomon) has [written](https://www.amazon.com/Noonday-Demon-Atlas-Depression/dp/1501123882/ref=sr_1_1?crid=7WX6PNSG59CF&keywords=andrew+solomon+books&qid=1674833321&sprefix=andrew+solomon%2Caps%2C106&sr=8-1) about all of this

**It’s very important because we could find therapies for these**

- Some of them may be related to alterations in diets, alterations in diets plus medicines, alterations in human physiology that could reset brain circuits
  - Or electrical stimulation, as [Helen Mayberg](https://profiles.mountsinai.org/helen-s-mayberg) and others have been doing
- To treat the problem as if it was a sort of an epiphenomenon is to minimize what the problem is

**To be continued…**

> “*You have a wonderful way of explaining complicated ideas*”‒ Peter Attia

- Peter remarks, “*Sid, there’s so much more I wanted to talk with you about*”
  - The immune system
  - The epigenetic phenomenon
  - Cellular reprogramming and [Yamanaka factors](https://en.wikipedia.org/wiki/Induced_pluripotent_stem_cell)
  - We only got through about half of what he wanted to talk about
- Perhaps the single most important thing Peter wanted to talk about today was the future of science and the culture of anti-science that is propagating
  - We couldn’t do that justice with a glib and short discussion
- Once Siddhartha’s book tour is over, we will have to continue with part 2

§

## Selected Links / Related Material

**Previous episode of** ***The Drive*** **with Sid**: [#32 – Siddhartha Mukherjee, M.D., Ph.D.: new frontiers in cancer therapy, medicine, and the writing process](https://peterattiamd.com/sidmukherjee/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (December 10, 2018) | [0:45, 1:17:45]

**Siddhartha’s books**:

- [The Emperor of All Maladies: A Biography of Cancer](https://www.amazon.com/Emperor-All-Maladies-Biography-Cancer/dp/1439107955/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1674486272&sr=8-1) by Siddhartha Mukherjee (November 2010) | [1:15]
- [The Laws of Medicine: Field Notes from an Uncertain Science](https://www.amazon.com/Laws-Medicine-Field-Uncertain-Science/dp/1476784841/ref=sr_1_1?crid=FWWPECIPQ2G2&keywords=The+laws+of+medicine&qid=1674487445&sprefix=the+laws+of+medicine%2Caps%2C132&sr=8-1) by Siddhartha Mukherjee (October 2015) | [1:15]
- [The Gene: An Intimate History by Siddhartha Mukherjee](https://www.amazon.com/Gene-Intimate-History-Siddhartha-Mukherjee/dp/1476733503/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) (May 2016) | [1:15, 3:30, 32:45]
- [The Song of the Cell: An Exploration of Medicine and the New Human](https://www.amazon.com/Song-Cell-Exploration-Medicine-Human/dp/1982117354/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Siddhartha Mukherjee (October 2022)  | [1:15, 3:00, 53:15, 58:15]

**Essay on the biophysical limitation of size**: [Size and Shape by Stephen Jay Gould](https://hermiene.net/essays-trans/size_and_shape.html) | Reprinted in “[The Richness of Life: The Essential Stephen Jay Gould](https://www.google.com/books/edition/The_Richness_of_Life/yfXJhKmp1wUC?hl=en&gbpv=1&dq=size+and+shape+by+stephen+jay+gould&pg=PA319&printsec=frontcover)” edited by Steven Rose (2006) | [25:15]

**Siddartha’s company working on CAR T-cell therapy in India**: [Immuneel](https://immuneel.com/) | [37:45]

**Early results of CAR T-cell therapy in India**: [Immuneel IMAGINE Study Phase-II Varnimcabtagene autoleucel Early Results Press Release pdf](https://immuneel.com/wp-content/uploads/2022/12/Immuneel-IMAGINE-Study-Phase-II-Varnimcabtagene-autoleucel-Early-Results-Press-Release.pdf) (December 2022) | [38:00]

**Review of gene therapy approaches to treat sickle cell disease**: [Gene therapy for sickle cell disease: moving from the bench to the bedside](https://ashpublications.org/blood/article/138/11/932/476349/Gene-therapy-for-sickle-cell-disease-moving-from) | *Blood* (A Abraham & J Tisdale 2021) | [42:30]

**Walter Isaacson’s biography of Jennifer Doudna**: [The Code Breaker: Jennifer Doudna, Gene Editing, and the Future of the Human Race by Walter Isaacson](https://www.amazon.com/Code-Breaker-Jennifer-Doudna-Editing/dp/1982115858/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1674655152&sr=8-1) (March 2021) | [58:15]

**Book about a family that has multiple kids with schizophrenia**: [Hidden Valley Road: Inside the Mind of an American Family](https://www.amazon.com/Hidden-Valley-Road-Inside-American/dp/038554376X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1674657060&sr=8-1) by Robert Kolker (April 2020) | [1:04:45]

**Karl Deisseroth’s book about mental illness**: [Projections: A Story of Human Emotions](https://www.amazon.com/Projections-Story-Emotions-Karl-Deisseroth/dp/1984853694) by Karl Deisseroth (June 2021) | [1:33:30]

**Andrew Solomon’s book about depression**: [The Noonday Demon: An Atlas Of Depression](https://www.amazon.com/Noonday-Demon-Atlas-Depression/dp/068485466X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1674833321&sr=8-1) by Andrew Solomon (June 2001) | [1:36:00]

§

## People Mentioned

- [Gregor Mendel](https://en.wikipedia.org/wiki/Gregor_Mendel) (Austrian Monk and “the Father of Genetics”) [6:30]
- [Thomas Hunt Morgan](https://en.wikipedia.org/wiki/Thomas_Hunt_Morgan) (American geneticist, discovered chromosomes) [6:45]
- [Rudolph Virchow](https://en.wikipedia.org/wiki/Rudolf_Virchow) (German physician and “Father of modern pathology” [7:15]
- [Antonie van Leeuwenhoek](https://en.wikipedia.org/wiki/Antonie_van_Leeuwenhoek) (Dutch microbiologist pioneered the microscope, the “Father of Microbiology”) [9:00]
- [Joseph Lister](https://en.wikipedia.org/wiki/Joseph_Lister) (British surgeon and pioneer of antiseptic surgery) [12:15]
- [Ignaz Semmelweis](https://en.wikipedia.org/wiki/Ignaz_Semmelweis) (German physician and proponent of hand disinfection) [12:15]
- [William Ratcliff](https://biosciences.gatech.edu/people/will-ratcliff) (Associate Professor of Biological Sciences at Georgia Tech) [20:00]
- [Steven Jay Gould](https://en.wikipedia.org/wiki/Stephen_Jay_Gould) (American paleontologist and evolutionary biologist) [25:15]
- [Jesse Gelsinger](https://en.wikipedia.org/wiki/Jesse_Gelsinger) (first person to have died from gene therapy) [29:15]
- [Jennifer Doudna](https://en.wikipedia.org/wiki/Jennifer_Doudna) ([Professor](https://doudnalab.org/) of Chemistry at UC Berkeley, [Nobel laureate](https://www.nobelprize.org/prizes/chemistry/2020/summary/)) [46:00]
- [Emmanuelle Charpentier](https://en.wikipedia.org/wiki/Emmanuelle_Charpentier) ([Director](https://www.mpg.de/9343753/science-of-pathogens-charpentier) of the Max Planck Unit for the Science of Pathogens, [Nobel laureate](https://www.nobelprize.org/prizes/chemistry/2020/summary/)) [46:00]
- [Feng Zhang](https://en.wikipedia.org/wiki/Feng_Zhang) ([Professor](https://zlab.bio/) of Neuroscience at MIT and member of the Broad Institute) [46:00]
- [George Church](https://en.wikipedia.org/wiki/George_Church_(geneticist)) (“Father of genomics” Professor at both [Harvard](https://icgd.bwh.harvard.edu/team/george-church) and [MIT](https://hst.mit.edu/faculty-research/faculty/church-george)) [45:15]
- [He Jiankui (JK)](https://en.wikipedia.org/wiki/He_Jiankui) (Professor of Biology at the  the Southern University of Science and Technology in Shenzhen, China; created first genetically edited human babies) [53:15]
- [Walter Isaacson](https://isaacson.tulane.edu/) (Professor of History at Tulane and author) [58:15]
- [Santiago Ramón y Cajal](https://en.wikipedia.org/wiki/Santiago_Ram%C3%B3n_y_Cajal) (Spanish pathologist, neuroscientist and [Nobel laureate](https://www.nobelprize.org/prizes/medicine/1906/cajal/biographical/) who characterized microscopic structure of the brain) [1:09:15]
- [Vincenzo Cerundolo (Enzo)](https://en.wikipedia.org/wiki/Vincenzo_Cerundolo) (Professor of Immunology at Oxford) [1:16:45]
- [Karl Deisseroth](https://profiles.stanford.edu/karl-deisseroth) (Professor of Bioengineering and Psychiatry and Behavioral Sciences at Stanford University) [1:33:15]
- [Andrew Solomon](https://sps.columbia.edu/faculty/andrew-solomon) (Professor of Clinical Psychology at Columbia) [1:36:00]
- [Helen Mayberg](https://profiles.mountsinai.org/helen-s-mayberg) (Neurologist at Mount Sinai, pioneered deep brain stimulation) [1:36:30]

§

![](https://peterattiamd.com/wp-content/uploads/2023/02/siddhartha-mukherjee-1x1-1-500x500.jpeg)

##### Siddhartha Mukherjee M.D., Ph.D.

Siddhartha Mukherjee was born in New Delhi, India. He holds a BS in biology from Stanford University, a PhD in immunology from Oxford University (where he was a Rhodes Scholar), and an MD from Harvard Medical School. He completed his internal medicine residency and an oncology fellowship at Massachusetts General Hospital. Dr. Mukherjee is an assistant professor of medicine at Columbia University Medical Center. He is a hematologist and oncologist who specializes in lymphoma, myeloma, and myelodysplastic syndrome at NewYork-Presbyterian / Columbia University Irving Medical Center.

He is the author of the Pulitzer Prize-winning book, [*The Emperor of All Maladies: A Biography of Cancer*](https://www.amazon.com/Emperor-All-Maladies-Biography-Cancer/dp/1439107955/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1674486272&sr=8-1); [*The Laws of Medicine: Field Notes from an Uncertain Science*](https://www.amazon.com/Laws-Medicine-Field-Uncertain-Science/dp/1476784841/ref=sr_1_1?crid=FWWPECIPQ2G2&keywords=The+laws+of+medicine&qid=1674487445&sprefix=the+laws+of+medicine%2Caps%2C132&sr=8-1); the *New York Times* bestseller, [*The Gene: An Intimate History*](https://www.amazon.com/Gene-Intimate-History-Siddhartha-Mukherjee/dp/1476733503/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=); and his most recent book was named a *New York Times* Notable Book of 2022, [*The Song of the Cell: An Exploration of Medicine and the New Human*](https://www.amazon.com/Song-Cell-Exploration-Medicine-Human-ebook/dp/B09RX45W14?ref_=ast_sto_dp).

Dr. Mukherjee’s research focuses on the biology of blood development and malignant and premalignant diseases such as myelodysplasia (MDS) and acute myelogenous leukemia (AML). His goal is to develop novel drugs to treat these diseases. [[Columbia](https://www.cancer.columbia.edu/profile/siddhartha-mukherjee-md)]

Twitter: [@DrSidMukherjee](https://twitter.com/drsidmukherjee)

Website: [siddharthamukherjee.com](https://siddharthamukherjee.com/)