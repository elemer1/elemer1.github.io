# #349 – AMA #71: Building strength and muscle mass: how to optimize training, nutrition, and more for longevity

**Source:** [https://peterattiamd.com/ama71/](https://peterattiamd.com/ama71/)

---

In this “Ask Me Anything” (AMA) episode, Peter dives deep into the topic of muscle mass and strength, examining their essential roles in both lifespan and healthspan. Drawing from over 30 hours of prior discussions with experts including Layne Norton, Andy Galpin, and Mike Israetel, this episode distills the most important insights into one comprehensive and up-to-date conversation. Peter explores why muscle matters for longevity, metabolic health, and injury prevention, and clarifies the differences between muscle mass and strength, including which is more vital for aging well. He breaks down practical strategies for building muscle safely and effectively, including progressive overload, training intensity, rep ranges, and the importance of explosive power. Peter also covers key nutrition strategies—like protein intake, timing, and creatine supplementation—and offers practical advice for everyone from beginners to seasoned lifters on building and maintaining muscle safely and sustainably.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #71 show notes page](https://peterattiamd.com/ama71). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Peter’s humorous experience talking nutrition with a second grader [2:30];
- Overview of topics, episode structure, and reasoning for focus on muscle mass and strength [6:00];
- Defining key terms: muscle mass, strength, hypertrophy, power, and more [8:15];
- The importance of muscular strength, muscle mass, and cardiorespiratory fitness for longevity [10:30];
- Grip strength as a simple yet powerful predictor of all-cause mortality [16:45];
- Is muscle strength causal or just a marker of health? [20:00];
- Why VO2 max, strength, and muscle mass are powerful health markers: a reflection of long-term consistent effort [22:30];
- How muscle mass and strength enhance healthspan by supporting metabolic health, inflammation control, recovery from illness, mobility, and fall prevention [23:45];
- How muscle mass and strength decline with age, and why it’s essential to act early to slow decline and preserve function later in life [30:30];
- The foundational principles of building muscle strength and size through resistance training [35:30];
- How to apply “progressive overload” for long-term strength and muscle gains [39:30];
- The difference between concentric and eccentric muscle contractions and how each impacts strength, hypertrophy, and injury prevention [44:45];
- The differences between muscle fiber types, and how aging disproportionately affects fast-twitch fibers responsible for power [50:15];
- How to effectively train for power [52:00];
- Training intensity: the benefits and safety of using the “reps in reserve” method [53:00];
- How to balance compound and isolation exercises in a workout routine, and why compound lifts are foundational [55:45];
- Can bodyweight exercises build muscle as effectively as weight training? [57:45];
- How women can effectively build strength and muscle: key considerations [59:15];
- Effective methods for tracking progress in strength [1:01:15];
- Effective methods for tracking progress in muscle mass, and how to interpret results from a DEXA scan [1:04:30];
- How to balance workout frequency with recovery for optimal results [1:06:45];
- How to recognize signs of overtraining and when to consider taking rest days [1:10:15];
- Avoiding injury: how beginners or returning lifters can start resistance training safely [1:15:15];
- Protein: recommended intake, quality sources, timing of consumption, and more [1:17:30];
- How fasting and calorie restriction affect muscle mass and what can be done to minimize muscle loss [1:24:15];
- Key nutritional factors beyond protein that support muscle growth: hydration, creatine, and recovery [1:27:45];
- The impact of hormones, sleep, stress, and consistency on muscle building and recovery [1:28:45];
- How to structure an effective workout routine for a younger person that is new to resistance training [1:31:30];
- How to modify beginner resistance training programs for older individuals to prioritize safety and gradual progress [1:35:30];
- Should beginners start with machines or free weights when resistance training? [1:36:30];
- How experienced lifters should modify their training to support healthspan and performance in later life [1:38:00]; and
- More.

---

The Peter Attia Drive

#349 – AMA #71: Building strength and muscle mass: how to optimize training, nutrition, and more for longevity

---

## Show Notes


---

## Peter’s humorous experience talking nutrition with a second grader [2:30]

**Peter’s Story: Lunch at His Son’s School**

- Peter shares he had lunch at his son’s school, something he occasionally enjoys doing.
- His son wasn’t in the mood to have lunch with him, so Peter ate alone at a cafeteria table.
- A group of his son’s classmates eventually joined him out of sympathy.
- The casual conversation evolved into a back-and-forth Q&A session about science and other topics.

The Diet Soda Incident

- One student noticed Peter drinking a Fresca and pointed out it contains a sweetener “500 times sweeter than sugar.”
- The student warned, “You know that causes cancer, right?”
  - Peter internally decided it wasn’t the right time to debate scientific literature on artificial sweeteners.
- The student clarified it wouldn’t kill Peter quickly because he was only drinking a small amount.
- Peter appreciated the child’s awareness and concern, calling it an “astute comment” for a 7-year-old.

Closing thought on the school visit

- Peter notes he had a great time and would be interested in returning to his son’s school for lunch again.
- Nick reminds the audience that Peter usually avoids talking about his work at adult social events.
- He finds it amusing that Peter got pulled into a detailed health discussion by second graders instead.
- Podcast episode idea: gather a panel of elementary school kids to share their thoughts on health topics—nutrition, exercise, protein, microplastics, seed oils, etc.
  - He says if the audience wants it, he’s game to gather a group of 7-year-olds and have a deep dive into health issues from their perspective.

## Overview of topics, episode structure, and reasoning for focus on muscle mass and strength [6:00]

**Intro to the Episode’s Focus**

- Today’s AMA will cover a single topic: muscle mass and muscle strength.
- This topic has been discussed on previous podcast episodes but is being addressed here as a focused, standalone AMA.
  - [Layne Norton](https://www.instagram.com/biolayne/) – [previous podcast guest](https://peterattiamd.com/laynenorton/)
  - [Andy Galpin](https://hhd.fullerton.edu/knes/facultystaff/AndyGalpin.php) – [previous podcast guest](https://peterattiamd.com/andygalpin/)
  - [Mike Israetel](https://rpstrength.com/pages/team/michael-israetel) – [previous podcast guest](https://peterattiamd.com/mikeisraetel/)

The conversation will explore:

- Why muscle mass and strength are important
- The differences between the two
- Which one matters more
- How to increase both (for all ages and genders)
- The role of nutrition and protein
- Different training and programming options for different populations

*Why Dedicate an AMA to This Now?*

1. High Volume of Listener Questions

- Muscle-related topics remain one of the top three most frequently asked topics in their audience Q&A submissions.
- It’s a highly relevant and in-demand topic that continues to generate interest.

2. Information Overload Across Multiple Episodes

- There is already ~20+ hours of podcast content on this topic, spread across various episodes and interviews.

This AMA aims to:

- Streamline and organize all that content into one accessible conversation.
- Deliver the essential takeaways at the “zeroth and first order levels” for easy digestion.
- Use show notes and supplemental materials to allow deeper exploration for those who want to dive further.

## Defining key terms: muscle mass, strength, hypertrophy, power, and more [8:15]

**Defining Muscle Mass and Muscle Strength**

- Muscle mass and muscle strength are often used interchangeably but are in fact distinct.
- Muscle mass = the total amount of skeletal muscle in the body.
- The three types of muscle in the body:
  - Cardiac muscle: resembles skeletal muscle but functions continuously throughout life.
  - Smooth muscle: quite different from skeletal muscle; found in organs like the digestive tract.
  - Skeletal muscle: the majority of muscle mass; has contractile properties to generate force and plays both:
    - Structural roles (e.g. movement, posture)
    - Metabolic roles (e.g. glucose uptake, energy expenditure)
- Muscle Strength = the ability to exert force to overcome resistance.
  - Though it may seem intuitive, Peter emphasizes it’s different from mass and worth clearly defining.
  - Strength is functionally relevant: not about size, but about output.

Two Additional Key Concepts

- 1. Hypertrophy
  - Refers to the size of the muscle.
  - Distinct from strength, though related.
  - Central concept in bodybuilding and strength programming.
- 2. Power
  - Often under-discussed, though critical.
  - Related to strength, but not the same:
    - Power = strength × velocity (speed of movement)
  - Involves an inverted-U relationship:
    - As resistance increases, power rises—up to a point.
    - If resistance becomes too high, speed drops, and power declines, even if strength is still increasing.

## The importance of muscular strength, muscle mass, and cardiorespiratory fitness for longevity [10:30]

**Why Muscle Mass and Strength Matter for Lifespan**

*Why should muscle mass and strength matter to anyone concerned with lifespan?*

- Although the conversation will include both mass and strength due to how studies report them, the primary focus is strength because:
  - Strength has a stronger causal relationship to mortality outcomes than muscle mass.
  - Muscle mass is easier to measure across populations (e.g., via [DEXA](https://www.youtube.com/watch?v=FYW82ii_RFQ)), so it’s commonly used as a proxy for strength, despite not being a perfect substitute.
  - Strength is more predictive of:
    - All-cause mortality
    - Cardiovascular disease
    - Neurologic disease
  - Peter adds:
    - While some wiry people are stronger than they appear and some muscular people aren’t as strong, on average, muscle mass and strength are reasonably correlated (excluding outliers).

Quantifying the Impact on Mortality: Strength & Muscle Mass as Predictors of Mortality

- I*s there data showing how much of a difference mass and strength make for lifespan*?
  - The single biggest predictor of mortality is age.
  - To reframe the discussion, Peter references [Gompertz Law](https://en.wikipedia.org/wiki/Gompertz%E2%80%93Makeham_law_of_mortality), which shows that mortality increases exponentially with age.
  - He notes that biological aging clocks don’t outperform chronological age in predicting mortality.
    - This is a criticism of “biological age” concepts based on clocks.

Hazard Ratios (HRs) for Mortality Risk

![](https://peterattiamd.com/wp-content/uploads/2025/05/f1-ama71-1024x693.png)

**Figure 1.** Chart comparing various risk factors for mortality (excluding age).

Sources: [Mandsager et al 2018](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428); [Kokkinos et al 2010](https://pubmed.ncbi.nlm.nih.gov/20697029/); [Newman et al 2006](https://academic.oup.com/biomedgerontology/article-abstract/61/1/72/549632?redirectedFrom=fulltext&login=false); [Srikanthan and Karlamangla 2014](https://pmc.ncbi.nlm.nih.gov/articles/PMC4035379/); [Liu et al 2022](https://pmc.ncbi.nlm.nih.gov/articles/PMC8978015/); [Zhou et al 2018](https://www.nature.com/articles/s41598-018-27377-2); and [Kenfield et al 2008](https://pmc.ncbi.nlm.nih.gov/articles/PMC2879642/#:~:text=Compared%20to%20never%20smokers%2C%20current,major%20cause%2Dspecific%20mortality%20evaluated.)

- Cardiorespiratory Fitness (VO₂ max)
  - Comparing above-average (50–75th percentile) to elite (top 2%):
    - 2x reduction in mortality
  - Comparing low (bottom 25%) to elite (top 2%):
    - 5x increase in mortality risk
- Grip Strength
  - Every 10 kg reduction in grip strength → 30% increase in all-cause mortality
- Muscle Mass
  - Comparing bottom quartile to middle quartile:
    - 2.3 hazard ratio (i.e., 130% increased mortality risk)
- Other Common Risk Factors
  - Type 2 diabetes → ~40% increased mortality
  - Uncontrolled high blood pressure → ~60%
  - Smoking:
    - Hazard ratio ~2.8 in one study
    - As low as 1.4 in others (depends on duration)
    - Still among top modifiable risk factors

Key Takeaway

- Beyond aging, strength, muscle mass, and cardiorespiratory fitness are among the most important predictors of lifespan.
- These physical attributes outweigh other common risk factors in some comparisons.

## Grip strength as a simple yet powerful predictor of all-cause mortality [16:45]

**Grip Strength as a Predictor of Mortality**

Why Grip Strength Is Used

- Grip strength is one of the easiest strength metrics to measure.
- Unlike muscle mass (which is often measured with [DEXA](https://peterattiamd.com/ama40/) scans), grip strength doesn’t require expensive or complex tools.
- It’s highly reproducible and correlates well with upper body strength.
- Individuals with strong grip strength typically also have strong upper bodies.
- Poor grip strength limits one’s ability to perform upper body tasks.

Grip Strength and Mortality – Study Highlights

- [PURE Study](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(14)62000-6/abstract):
  - Involved approx. 140,000 participants across 17 countries.
  - Found a 16% increase in all-cause mortality for every 5 kg (~10 lb) reduction in grip strength.
  - This strong correlation makes grip strength a powerful, practical proxy for assessing mortality risk.
- [Study](https://academic.oup.com/biomedgerontology/article-abstract/61/1/72/549632?redirectedFrom=fulltext&login=false) looking at the eighth decade of life:
  - Focused on individuals aged 70 to 79, followed for seven years.
  - Participants were divided into quartiles based on:
    - Muscle mass (measured with [DEXA](https://peterattiamd.com/ama44/)).
    - Strength (likely measured via leg extension for lower body; grip strength possibly used for upper body).
  - Data was analyzed using Kaplan-Meier survival curves.

![](https://peterattiamd.com/wp-content/uploads/2025/05/f2-ama71-1024x485.png)

**Figure 2.** Strength and mortality in females. Source: [Newman et al., 2006](https://academic.oup.com/biomedgerontology/article-abstract/61/1/72/549632?redirectedFrom=fulltext&login=false)

![](https://peterattiamd.com/wp-content/uploads/2025/05/f3-ama71-1024x510.png)

**Figure 3.** Strength and mortality in males. Source: [Newman et al., 2006](https://academic.oup.com/biomedgerontology/article-abstract/61/1/72/549632?redirectedFrom=fulltext&login=false)

- Results:
  - Mortality increased consistently across time in all groups (as expected).
  - The strongest and most muscular quartiles consistently had the highest survival rates.
  - The steep mortality differences reflect the older population sampled; such curves would look flatter in younger populations (e.g., ages 50–59).

## Is muscle strength causal or just a marker of health? [20:00]

**Causality Between Muscle Strength/Mass and Mortality**

*Is strength just a proxy for better overall health, meaning strong people live longer simply because they’re healthier, not because strength itself is causative?*

- Peter argues bidirectionality is key:
  - Being healthy makes it easier to build strength and muscle.
  - But doing the things that build strength and muscle (i.e., training, eating well) also leads to better health and longer life.
  - Therefore, there’s likely a mutually reinforcing relationship between health and strength/muscle mass.
- Evidence from Mendelian Randomization
  - True randomized controlled trials are difficult in this area, so [Mendelian randomization](https://en.wikipedia.org/wiki/Mendelian_randomization) (MR) offers an alternative.
  - MR studies assess genetic traits related to strength or muscle mass and look at their relationship to health outcomes, minimizing confounding.

Example Study: [Finnish Biobank](https://academic.oup.com/biomedgerontology/article/79/4/glae064/7623674#google_vignette)

- Study of 300,000–350,000 participants.
- Researchers used a polygenic score as a proxy for grip strength.
  - A polygenic score aggregates many genes known to contribute to grip strength.
- Findings per 1 standard deviation increase in grip strength:
  - Vascular dementia risk reduced by 7%
  - Obesity risk reduced by 6%
  - Type 2 diabetes risk reduced by 5%
  - MACE (major adverse cardiovascular events) risk reduced by 4%
  - All-cause mortality risk reduced by 3%

Conclusion

- These findings support the idea that grip strength is not merely a marker of overall health but may play a partially causal role in improved health outcomes and longevity.
- The data suggest that the observational associations between muscle strength/mass and mortality are not purely correlational.

## Why VO2 max, strength, and muscle mass are powerful health markers: a reflection of long-term consistent effort [22:30]

**Why Muscle Strength, Mass, and VO2 Max Are Strong Health Predictors**

- Comparison to VO₂ Max
  - Nick draws a parallel between VO₂ max and muscle strength/mass as metrics that cannot be quickly improved.
  - VO₂ max is considered a powerful health metric because it reflects long-term consistent effort, not short bursts of training.
- Peter’s Agreement and Extension
  - Peter confirms the analogy and expands on it:
    - VO₂ max, muscle mass, and strength all serve as integrators over time, meaning they reflect cumulative effort over months or years—not short-term change.
    - These metrics show up strongly in predictive health models for precisely this reason.
- Patient Context and Realistic Expectations
  - Peter gives a clinical example:
    - A patient who scores in the bottom 5% for muscle mass, strength, and fitness should not expect a quick turnaround.
    - Unlike biomarkers like ApoB or insulin resistance, which can sometimes improve in weeks or months, developing high fitness or muscle mass is a multi-year process.
- Estimated Timeline — a realistic trajectory:
  - Moving from a VO₂ max of 30 to 50 could take up to three years, depending on one’s baseline.
  - It can be done, but requires long-term commitment and training consistency.

## How muscle mass and strength enhance healthspan by supporting metabolic health, inflammation control, recovery from illness, mobility, and fall prevention [23:45]

**Why Muscle Mass and Strength Matter for Healthspan**

- Even if exercise did not improve lifespan, Peter would still do it because of the benefits to healthspan.
- Thankfully, this is a false dichotomy—exercise improves both.

*Metabolic Health Benefits of Muscle*

- Skeletal muscle = [primary glucose sink](https://pmc.ncbi.nlm.nih.gov/articles/PMC2811436/#:~:text=These%20studies%20support%20the%20notion,%2C%20glucagon%20concentrations%20(20).)
  - Major site for both insulin- and non-insulin-mediated glucose uptake
  - Having more muscle helps buffer blood sugar levels, which reduces:
    - Risk of type 2 diabetes
    - Heart disease
    - Dementia
    - Cancer
- Ideal muscle characteristics:
  - Able to store 300–500g of glucose as glycogen
  - Insulin-sensitive, to minimize insulin demand during glucose uptake
- For more on understanding and improving your metabolic health, see [AMA #51](https://peterattiamd.com/ama51/)

*Inflammation and Myokines*

- Skeletal muscle is an endocrine organ:
  - Secretes signaling molecules known as myokines
    - Notably: Interleukin-6 (IL-6) and Irisin
    - [IL-6 is anti-inflammatory](https://journals.physiology.org/doi/full/10.1152/physrev.90100.2007) when released by muscle (unlike most inflammatory ILs)
- Historical efforts to replicate exercise through myokines:
  - 14 years ago, Irisin was seen as a possible “exercise in a bottle”
  - Peter references [Mike Israetel](https://www.instagram.com/drmikeisraetel/?hl=en)’s optimism that someday we may [replicate exercise’s effects with injections of myokines](https://peterattiamd.com/mikeisraetel/)
    - Peter himself is skeptical, believing the cascade of exercise benefits is too complex to reduce to a few molecules
- For more on inflammation and what to do about it, see [AMA #59](https://peterattiamd.com/ama59/)

*Muscle as Protein Reservoir in Illness*

- Muscle is the only meaningful protein reservoir in the body
  - Unlike fat and carbs, protein isn’t stored outside of muscle
  - This matters during:
    - Illness
    - Surgery
    - Infection
    - Hospitalization
    - Burns
- Individuals with more muscle lose less and recover better during periods of stress

*Movement, Mobility, and Aging*

- Mobility = vitality
- Peter states: “*The more you move, the more you’re alive. The less you move, the less you’re alive.*”
- This ties to his “centenarian decathlon” mental model—aiming to maintain functionality in one’s final decade of life

*Falls and Mortality*

- Fall-related hospitalizations and deaths:
  - 300,000 hospitalizations per year in the U.S. from falls
  - For individuals over 60 with femur fractures, 10–30% one-year mortality
  - Most will never return to baseline mobility
- Death rates from falls by age group (per 100,000 people):

![](https://peterattiamd.com/wp-content/uploads/2025/05/f4-death-per-100000-ama71.png)

**Figure 4.** Deaths from falls by age (from [CDC](https://wonder.cdc.gov/controller/datarequest/D140;jsessionid=10A940BF9DBBF844B8EC97E68866), data from 1999-2016)These stats reveal an *exponential mortality curve* tied to falls—highlighting the critical role of maintaining strength and balance with age.

## How muscle mass and strength decline with age, and why it’s essential to act early to slow decline and preserve function later in life [30:30]

**Muscle Gain, Loss, and Aging**

Peak Strength and Age-Related Decline

- Muscle strength typically peaks in one’s 30s to early 40s.
  - Power peaks earlier due to its dependence on speed.
- After this peak, strength declines approximately 1–2% per year.
  - This decline is largely uninterrupted unless interrupted by significant changes in health status.
- After age 70, this decline accelerates more steeply.

Population vs. Individual Decline Patterns

- [Luc Van Loon](https://www.maastrichtuniversity.nl/ljc-van-loon), a prior [guest](https://peterattiamd.com/lucvanloon/) on the show, emphasized how the average decline curves in muscle mass, strength, and activity appear “smooth” and “physiologic” when viewed at a population level.
- In reality, individual declines are typically slow and steady, interrupted by rapid drops due to periods of inactivity.
  - These periods of inactivity are often caused by injury.
  - Peter’s #1 rule for people in their 50s and beyond: Don’t get injured, as missing workouts due to injury is one of the greatest threats to long-term strength maintenance.

Importance of Avoiding the Inactivity Spiral

- Injuries in one’s 60s or 70s are particularly worrisome, as they often result in months-long training interruptions that accelerate functional decline.
- The following figure outlines three distinct aging curves based on activity levels:

![](https://peterattiamd.com/wp-content/uploads/2025/05/f5-ama71-1024x773.png)

**Figure 5.** Source: [Gustafsson and Ulfhake, 2024](https://www.mdpi.com/1422-0067/25/20/10932)

- Green curve: Highly active individual—slower decline.
- Blue curve: Population average—moderate decline.
- Red curve: Sedentary individual—steep decline.
- Key takeaway: You don’t want to end up on the red curve and realize too late that everything (strength, mobility, independence) is deteriorating. The earlier you shift toward a higher-activity trajectory, the better.

Maximizing Your Peak and Managing Decline

- Nick adds that there are two sides to the curve:
  - If you haven’t hit your peak yet, raise it as high as possible.
  - If you’ve already passed your peak, decline as slowly as possible.
- Peter agrees and gives an example from his youth (ages 13–19), where he trained extremely hard.
  - Though this led to injuries and scars (especially to his back), it also gave him a very high baseline for fitness, including VO2 max in the 70s or even low 80s.
  - Even though he’s lower now, starting from a high base has helped preserve performance with age.
- Peter urges younger listeners—or parents of kids—to help maximize genetic potential early, so they have a higher base to decline from later in life.
  - Doing so without injury is key. Peter acknowledges many of his youthful injuries were due to ignorance, not necessity.

## The foundational principles of building muscle strength and size through resistance training [35:30]

Training Goals: Strength vs. Hypertrophy

- The first step is defining your specific training goal: Are you optimizing for strength or for hypertrophy (muscle size)?
  - These two goals require different training strategies.
- Peter gives two extreme examples to illustrate the difference:
  - [Lane Norton](https://x.com/biolayne?lang=en), training for a powerlifting competition, focuses on strength.
    - Despite “power” being in the sport name, it’s a pure demonstration of maximum strength.
  - [Mike Israetel](https://www.instagram.com/drmikeisraetel/?hl=en), training as a bodybuilder, focuses on hypertrophy.
    - His routines are structured to maximize muscle growth.
- Though both are lifting weights in the gym, their routines differ significantly in terms of reps, sets, and rest protocols.

Where Most People Fall

- Most people are not training at either extreme.
  - Peter describes himself as training for strength but not maximum strength.
    - He hasn’t done a 1-rep max (1RM) in over 15 years and doesn’t plan to again.
    - He still uses strength-based principles, including lower rep ranges, but isn’t strictly optimizing for hypertrophy or muscular endurance.

Universal Principle: Progressive Overload

- Regardless of goal (mass or strength), progressive overload is the underlying principle.
- This means gradually increasing the demands on the muscles to force adaptation.
- See [episode #235 with Lane Norton](https://peterattiamd.com/laynenorton3/) for more on progressive overload

Key Adaptation Mechanisms

- 1) Muscle Fiber Recruitment
  - Muscles consist of Type I (slow-twitch) and Type II (fast-twitch) fibers.
  - As load and volume increase, the body recruits higher-threshold motor units (fast-twitch fibers) that are more responsible for strength and size.
  - Differences in fiber types also reflect:
    - Force capacity
    - Metabolic characteristics (oxidative vs. glycolytic)
- 2) Muscle Protein Synthesis (MPS)
  - Muscles need amino acids (from protein intake) to repair and grow after resistance training.
  - Providing the necessary substrates is essential for hypertrophy.
- 3) Neurologic Adaptation
  - A critical, often overlooked component.
  - Muscles must be trained not just physically but neurologically—improving the motor units’ ability to fire in sync and with control.
  - Peter shares an example of his daughter (a young track athlete and gym enthusiast) who overtrains and becomes neurologically fatigued.
    - He emphasizes the importance of recovery for both muscular and nervous system adaptation.

Broad Takeaway

- Effective resistance training involves:
  - A clear understanding of the goal (mass vs. strength),
  - Applying progressive overload principles,
  - Recruiting the right muscle fibers,
  - Supporting recovery through nutrition and rest,
  - And recognizing that neurologic conditioning is essential for long-term performance and safety.

## How to apply “progressive overload” for long-term strength and muscle gains [39:30]

Overview of Progressive Overload Strategies

- Progressive overload is the foundational principle for building muscle and strength: consistently applying increased stress to muscles to trigger adaptation.
- It can be achieved through multiple levers, not just increasing weight.

Methods of Progressive Overload

- Increase the load/weight:
  - Most common and intuitive method.
  - Works well for exercises where joint stress is minimal (e.g., bicep curls).
  - Peter avoids increasing weight on exercises that load the spine or stress joints unnecessarily (e.g., axial-loaded lifts).
- Increase the number of reps:
  - A valid approach, especially when sticking to the same weight.
  - Helpful if you’re progressing from 2 RIR (reps in reserve) toward 0–1 RIR.
  - Caution: going beyond 12–15 reps starts shifting the benefit toward muscular endurance instead of strength/hypertrophy.
- Increase the number of sets:
  - Adds volume without increasing weight.
  - Effective for stimulating muscle growth if weight or rep changes are not ideal.
- Decrease rest time between sets:
  - Useful to increase overall workout intensity and time under tension.
  - Often applied in supersets or circuit formats.
- Increase time under tension (Peter’s personal favorite):
  - Slow down the tempo of each rep, particularly the eccentric (lowering) phase.
  - Allows for lower weight while still challenging the muscle.
  - Ideal for those with joint issues or who want to reduce injury risk.
  - Example: Peter does slow dumbbell bench presses due to arthritis in his AC joint—less weight, more control, same benefit.

Personalization Based on Context

- Not every method is suited for every person or every exercise.
- Consider safety, training environment (e.g., lifting alone vs. with a spotter), and joint tolerance.
- Different overload methods can be chosen based on:
  - Body part being trained
  - Training experience
  - Injury history

Mindset Toward Progression

- Always look for some way to challenge yourself—don’t stagnate.
- Beginners can improve total load by 5–10% per week.
- Advanced lifters may only manage 1% per week increases due to approaching their ceiling.
- Deload weeks and backing off periodically are still part of a long-term plan but are excluded from this discussion about continual progression.

Summary Takeaway

- The essence of progressive overload is ongoing challenge—through load, reps, volume, time under tension, or shortened rest.
- There is no one-size-fits-all approach; the key is consistency and safely pushing limits over time.

## The difference between concentric and eccentric muscle contractions and how each impacts strength, hypertrophy, and injury prevention [44:45]

Definitions and Basic Understanding

- Concentric Contraction:
  - Muscle shortens while generating force.
  - Example: lifting a dumbbell in a bicep curl (muscle shortens as weight is lifted).
  - Main use: power and force generation.
  - The faster the concentric action, the more power is produced.
- Eccentric Contraction:
  - Muscle lengthens while under tension.
  - Example: lowering a dumbbell in a bicep curl (muscle lengthens as weight is lowered).
  - Main use: inducing muscle damage for hypertrophy and increasing control.
  - Slower movements = greater eccentric tension = more muscle fiber micro-tears = more growth.

Training Applications of Concentric Phase

- Peter emphasizes explosive concentric training to develop power:
  - Uses the Keiser leg press machine (pneumatic resistance) for single-leg explosive reps.
  - Does this after warming up and during pre-fatigue, not with maximum weight (usually ~⅔ of high-strength load).
  - The Kaiser machine measures speed, force, and power.
  - Ends the set when performance drops below 92% of peak power to stay focused on power optimization.

Training Applications of Eccentric Phase

- Eccentric phase is often neglected but critical for muscle growth and injury prevention.
  - Example: during leg curls, letting the weight snap back without control increases injury risk.
  - Slowing down the return movement increases stress on the muscle fibers, aiding hypertrophy.
- Bodybuilders emphasize eccentric control because:
  - It causes more mechanical damage to muscle fibers.
  - It enhances hypertrophy through more microtrauma and repair.

Balance and Emphasis

- Peter emphasizes the importance of being in control during the eccentric phase, even if you’re not focusing on exaggerating it.
- The ideal emphasis between concentric and eccentric depends on goals (e.g., strength, hypertrophy, performance, injury reduction).

Advanced Training Example: Cyclist Strength Without Size

- While training for cycling (where strength is desired without added mass), Peter used:
  - Very heavy trap bar deadlifts for 5 reps with drop sets (drop the bar at the top to avoid eccentric load).
  - This maximized concentric power and strength without hypertrophy.
  - Doing this eliminated eccentric stress, allowing for faster recovery and frequent training (3–4x/week).
- Additional Context
  - He combined this with:
    - Plyometrics
    - Post-activation potentiation (PAP) workouts: technique to improve explosive movement after a heavy load exercise.

Takeaway

- Understanding and utilizing both concentric and eccentric movements allows more targeted training:
  - Use concentric for power and strength gains.
  - Use eccentric for muscle growth and joint safety.
- Adjust emphasis based on personal goals (e.g., performance vs. size vs. longevity).

## The differences between muscle fiber types, and how aging disproportionately affects fast-twitch fibers responsible for power [50:15]

Type I (Slow Twitch) Fibers

- Associated with endurance activities.
- Contract more slowly with less force.
- Metabolically favor fat as a fuel source.
- Highly metabolically flexible.
- Characterized by:
  - Lots of mitochondria.
  - Rich capillary network.
  - Red in appearance due to myoglobin and blood supply.

Type II (Fast Twitch) Fibers

- Associated with strength and power activities.
- Produce more force and contract more quickly.
- Metabolically more glycolytic (favor glucose as a fuel source).

Aging and Muscle Fiber Decline

- A key insight from Peter’s [conversation with Andy Galpin](https://peterattiamd.com/andygalpin/):
  - One of the earliest and most significant muscle-related effects of aging is the atrophy of type IIa fibers (fast-twitch fibers responsible for power and explosiveness).
  - This process begins as early as the 30s and 40s, not just in the elderly.
- Order of Decline With Age:
  - Power
  - Strength
  - Size
- This is important because:
  - Power is often overlooked in training, yet it deteriorates first.
  - It’s critical to incorporate power training at all ages to preserve fast-twitch fiber function and overall muscular capacity.

Key Takeaway

- Even for those not focused on athletic performance, maintaining power through deliberate training is essential for long-term functional capacity and aging well.

## How to effectively train for power [52:00]

**How to Improve Power in the Gym**

- Primary Recommendation:
  - Focus on moving quickly through the concentric phase of an exercise.
  - This explosive movement pattern is key for developing power, and it is distinct from traditional resistance training, which often emphasizes slower, controlled movements.
- Supporting Evidence:
  - Peter references a [review](https://link.springer.com/article/10.1007/s40279-016-0489-x) of 13 studies that compared traditional strength training with power training.
    - Power training (lifting weights quickly) was found to be superior in improving power output.
    - When participants lifted the same amount of weight, the group that lifted explosively saw greater gains in power.
- Key Principle:
  - Specificity matters: “You become better at whatever it is you train for.”
    - If your goal is to improve power, then your training needs to reflect that goal through intentional speed-focused execution.
- Key Takeaway
  - To improve power, train explosively by lifting weights with speed during the concentric portion of the movement, rather than just increasing weight or volume.

## Training intensity: the benefits and safety of using the “reps in reserve” method [53:00]

**Understanding Training Intensity**

- Defining Intensity in Resistance Training:
  - Muscular failure: The point at which you physically cannot complete another rep.
    - Not necessary to reach this often.
    - Carries increased risk of injury.
    - Peter only hits failure once or twice per workout, unintentionally.
- Technical failure: The point at which form begins to break down.
  - Occurs more frequently and is easier to identify for experienced lifters.
  - Examples of technical failure include:
    - Slight body rocking during curls
    - Incomplete reps
    - Bouncing at the bottom of a movement
  - Not always bad—some experts advocate for cheat reps beyond technical failure to push through plateaus.
- Rep in Reserve (RIR) Framework:
  - Preferred intensity framework for most people.
  - 1-2 RIR = Stopping a set when you could still perform 1 or 2 additional reps with good form.
    - Safe and effective: Minimizes injury risk while still providing near-maximal benefits.
    - Approaching failure without crossing into it unnecessarily.
  - To learn how this feels, occasional failure is useful:
    - Choose low-risk exercises and have a spotter present when needed.
    - Avoid failing on movements with higher risk, like a solo bench press.
- General Recommendation:
  - Most people should live in the 1-2 RIR range.
  - Training to absolute failure is rarely necessary unless training for power or maximal strength.

Key Takeaway

- Use the 1-2 reps in reserve (RIR) method to train at an effective and safe intensity level—near failure, but not to failure—unless you have very specific high-level strength goals.

## How to balance compound and isolation exercises in a workout routine, and why compound lifts are foundational [55:45]

**Compound vs. Isolation Movements in the Gym**

Value of Compound Exercises

- Compound exercises engage multiple muscle groups and joints simultaneously (e.g., squats, deadlifts, presses, rows).
- These exercises form the foundation of both strength and muscle mass development.
- The “big three” powerlifting movements—squat, deadlift, bench press—are essential for general strength.
  - Peter notes “powerlifting” is a misnomer and prefers the term strength lifting.
- Even bodybuilders, whose primary goal is hypertrophy, incorporate some form of these foundational lifts (or their variations) into their routines.

Role and Relevance of Isolation Exercises

- Isolation exercises also have a valuable place in a training routine.
- Their importance depends on individual goals and time constraints.
  - If short on time: prioritize compound lifts.
  - If time permits: add isolation/accessory work to target smaller muscles or weaknesses.

Programming Strategy

- Peter typically begins his own workouts with compound exercises, then adds accessory movements afterward if time allows.
- Sequence matters: compound lifts come first due to their technical and physical demands.

Technical Challenge of Compound Lifts

- Compound lifts require coordination, control, and technique, not just raw strength.
  - Example: Learning to properly perform squats and deadlifts.
- Performing these lifts improperly increases risk of injury.
- Peter emphasizes the mental and technical satisfaction of mastering compound movements—they are not mindless or simplistic.

Key Takeaway

- Build your training around compound lifts for maximum return on strength and size, then add isolation movements based on time and goals—always respecting the technical skill required to perform compound lifts safely.

## Can bodyweight exercises build muscle as effectively as weight training? [57:45]

**Effectiveness of Bodyweight Exercises vs. Resistance Training**

Primary Message

- Resistance training with weights is the most effective way to build muscle mass and strength.
  - It offers a more direct path to reaching optimal levels of hypertrophy (muscle size) and strength.

Bodyweight Training: Where It Works

- Not the only option: Bodyweight exercises can build muscle—especially effective for beginners.
- Exercises like pull-ups and push-ups can bring individuals close to failure (i.e., 1 rep in reserve or “1 RIR”), which is important for hypertrophy and strength gains.

Limitations of Bodyweight Training

- Difficult to achieve sufficient resistance in many bodyweight exercises to stimulate significant hypertrophy.
  - For example:
    - Pull-ups: Great because they often bring people into an ideal rep range (few people can do a high number).
    - Push-ups: Once fit, most people can do many—so they tend to fall into the muscular endurance zone, not hypertrophy.
- For people whose goals are size and strength, bodyweight training alone is less optimal.

Overall Conclusion

- Bodyweight exercises are useful and can improve muscle endurance, but weights are more effective for serious strength and muscle development goals.

Key Takeaway

- While bodyweight exercises can help build strength and endurance, resistance training with weights is the most effective and reliable method for increasing muscle mass and overall strength, especially for non-beginners.

## How women can effectively build strength and muscle: key considerations [59:15]

**Resistance Training Considerations for Women**

General Training Principles Apply Equally

- No need for radically different training protocols between men and women.
  - Same rep ranges, same progressive overload principles.
  - Protein requirements are generally the same as well.
- Women do not need to train at a different level of intensity (e.g., fewer reps in reserve or lower volume).

Key Physiological Differences

- Strength-to-weight ratios tend to differ; men typically have more absolute strength.
- Joint laxity is generally higher in women.
  - This may increase the risk of injury.
  - Therefore, women may benefit from focusing more on tempo work and eccentric control.
- Hormonal changes—especially during menopause—introduce unique challenges:
  - Loss of estrogen and testosterone increases risk of sarcopenia (age-related muscle loss).
  - Resistance training becomes even more important to preserve muscle mass and function during this time.

Practical Implication

- Women, especially as they age or go through menopause, should prioritize resistance training just as much—if not more—than men.
- It plays a vital role in maintaining strength, mobility, and quality of life.

Supporting Example

- Peter references a [podcast episode with Belinda Beck](https://peterattiamd.com/belindabeck/):
  - Describes a clinical trial involving women in their 60s lifting heavy weights.
  - Results showed improvements in strength, bone density, and overall quality of life.

Overall Message

- The differences that do exist should not discourage women from lifting weights.
- The benefits are universal and essential for long-term health.

Key Takeaway

- Women should train just as seriously as men when it comes to resistance training. Despite some physiological differences, the core training principles remain the same, and building strength becomes increasingly critical with age and hormonal changes.

## Effective methods for tracking progress in strength [1:01:15]

**Tracking Strength and Fitness Progress in the Gym**

Traditional Strength Metric: One-Rep Max (1RM)

- Using 1RM (maximum weight you can lift once) is a valid way to track strength progress.
- Peter used to rely on 1RM metrics like squat, deadlift, and bench press.
- He often avoided doing actual 1RMs by using predictive formulas (based on 2–5 rep failures) to estimate 1RM.
- Training close to failure requires knowing your limits, and a 1RM test helps by showing what failure feels like and allowing for personalized intensity. A 1RM test, the gold standard for measuring maximal strength, determines the heaviest weight you can lift for one rep with proper form, either by testing to failure or estimating using a calculator with submaximal lifts.
- Predictive formula to estimate 1 rep max:

![](https://peterattiamd.com/wp-content/uploads/2025/05/f6-reps-1RM-ama71.jpeg-.png)

**Figure 6.** Calculated 1 RM from submaximal testing. Displayed as % of 1RM — to get calculated 1RM divide the weight used by the % 1RM. (e.g., if you lifted 93 kg 2 times, your 1RM would be 93/.93 = 100 kg)

- W*hy Peter No Longer Uses 1RM*:
  - He now focuses on a broader set of metrics, emphasizing strength, power, and aging resilience.
  - Prioritizes functional tests over pure max lifts.

Current Personal Fitness Metrics Peter Tracks

- Standing Broad Jump:
  - Measures explosive concentric power and eccentric control (needed to “brake” the landing).
  - A personal benchmark: be able to jump as far as or further than his height (6 feet).
  - Does this regularly as a long-term measure of power maintenance.
- Pull-Ups:
  - Control and form are essential.
  - Goal:
    - Males: 5+ reps with a 3-second eccentric (lowering).
    - Females: 3+ reps with same eccentric emphasis.
- Dead Hang:
  - Measures grip endurance and shoulder stability.
  - Goal:
    - Males: 2 minutes.
    - Females: 90 seconds.
- Wall Sit:
  - Simple test for lower body endurance.
  - Goal: 2 minutes for both men and women with thighs parallel to floor.
- Farmer’s Carry:
  - Measures grip, shoulder, and core endurance.
  - Goal:
    - Men: 100% of bodyweight (50% in each hand) for 1 minute.
    - Women: 75% of bodyweight (half in each hand) for 1 minute.
- Box Step-Ups:
  - Good for testing hamstring and glute strength.
  - Goal: 5 reps per side holding 25% of bodyweight in each hand.
- Wall Push-Ups:
  - Wall positioning helps eliminate cheating (no rocking back/forth).
  - Goal:
    - Men: 20 high-quality push-ups.
    - Women: 10 well-controlled push-ups.

![](https://peterattiamd.com/wp-content/uploads/2025/05/f7-target-metrics-ama71-1024x567.png)

**Figure 7.** Target metrics for several example exercises.

Mindset Around Metrics

- The goal isn’t just to hit a specific number but to make continual progress.
- Consistent improvement matters more than achieving any single benchmark.

Key Takeaway

- Peter recommends using functional strength and power metrics like pull-ups, broad jumps, farmer’s carries, and dead hangs to track progress. These metrics not only gauge performance but also serve as markers of aging well. More important than any one number is your rate of improvement over time.

## Effective methods for tracking progress in muscle mass, and how to interpret results from a DEXA scan [1:04:30]

Check out [AMA #40](https://peterattiamd.com/ama40/) and [AMA #44](https://peterattiamd.com/ama44/) for more on interpreting DEXA scan results

\*\*\*

**Using** [**DEXA Scans**](https://peterattiamd.com/ama40/) **to Assess Muscle Mass**

Common DEXA Metrics for Muscle Mass Evaluation

- DEXA scans can provide useful data for assessing muscle mass, but:
  - Most DEXA reports do not directly provide the key indexes Peter uses.
  - You may have to manually calculate the relevant metrics.

Primary Metrics to Focus On

- Appendicular Lean Mass Index (ALMI):
  - Represents the sum of lean mass in the arms and legs.
  - How to calculate:
    - Add lean mass (in kilograms) from the left arm, right arm, left leg, and right leg.
    - Divide that number by height in meters squared.
    - Use a nomogram to convert this to a percentile.

![](https://peterattiamd.com/wp-content/uploads/2025/05/f8-ama71-1024x488.png)

**Figure 8.** ALMI nomogram.

- Fat-Free Mass Index (FFMI):
  - Represents total body mass minus fat mass, divided by height².
  - Slightly easier to compute than ALMI because it’s already total lean mass.

How to Interpret Results

- While ALMI and FFMI are usually concordant (aligned), they can sometimes differ.
- Peter’s general goal for patients: be at or above the 75th percentile for both metrics.
  - This threshold aligns with optimal muscle mass levels for long-term health.
  - However, not everyone will realistically reach that level.

Consideration of Genetic Variability

- Some individuals, especially those with smaller builds, may never reach the 75th percentile, and that’s okay.
  - Example: Peter’s wife has a naturally small frame and won’t reach that level, but still focuses on strength over size.
- The emphasis should ultimately be on functional strength, not just lean mass.

Key Takeaway

- While DEXA scans can offer insight into muscle mass through ALMI and FFMI, the focus should remain on strength and progress, not just percentile targets. Use these metrics as guides, not strict goals.

⇒ For more, check out Peter’s article: [Body composition: impact on disease risk and how to assess and improve it](https://peterattiamd.com/improving-body-composition/)

## How to balance workout frequency with recovery for optimal results [1:06:45]

Factors That Influence Ideal Training Frequency

- Training frequency and rest needs depend heavily on individual context:
  - Training age (how long someone has been training)
  - Biological age
  - Genetics
  - Life stressors
  - Nutrition
  - Sleep quality
- Peter emphasizes: if you’re young, well-rested, well-fed, and stress-free, you might train every day. But for most people, time and recovery constraints make that unrealistic.

Time Constraints and Practical Application

- Most patients (and listeners) don’t have unlimited time or recovery bandwidth.
- Strategy: Optimize limited time with correct exercise selection, volume, and intensity.

Body Part Training Frequency

- You don’t need to train each body part more than once a week if intensity and volume are appropriate.
  - Even elite bodybuilders have trained this way.
- Peter applies this model personally:
  - Three resistance training sessions per week
  - Each muscle group trained once a week with high intensity
  - Recovery can take 2–3 days for that body part

Split Training vs. Full Body Workouts

- Full body workouts 2–3x/week work well for beginners.
- More experienced lifters might prefer split routines that focus on specific muscle groups per session.

Example of Peter’s Routine

- Monday: legs → soreness often lasts 1–2 days
- Tuesday: limited to a Zone 2 cardio ride, not VO2 max intensity
- This routine demonstrates respect for recovery time

Deloading and Time Off

- Deloading = intentional reduction in training volume or intensity
- Referenced past advice from [Mike Israetel](https://www.instagram.com/drmikeisraetel/?hl=en):
  - Every 8 weeks: take a light week or full week off
  - Once per year: take up to two full weeks off
- Peter’s approach:
  - Doesn’t routinely recommend structured deloads to patients
  - Believes life naturally provides breaks (vacations, family events, etc.)

Key Takeaway

- You don’t need to train every body part multiple times per week to see gains—as long as your workouts are intense and intentional. Recovery, time constraints, and life context all matter.

## How to recognize signs of overtraining and when to consider taking rest days [1:10:15]

**Identifying Overtraining and Knowing When to Rest**

Primary Indicator: Willingness to Train

- Peter’s most trusted signal: reluctance or willingness to train.
- Two distinct scenarios:
  - 1) Mental Resistance: “I don’t want to leave my desk” or “I’m busy.”
    - Once warmed up, the individual feels motivated and it’s not a problem.
  - 2) Physical Resistance: “I’m in the gym, warmed up, but still don’t want to train.”
    - This is a red flag indicating a need for rest or change.

Training Experience as a Factor

- More experienced individuals can accurately interpret reluctance as a recovery signal.
- Novices should not rely solely on willingness—it may be misleading until they’ve built consistent training habits.

Using Wearables and Biometrics (HRV)

- Heart Rate Variability (HRV) can be a helpful supplemental signal, but must be used correctly:
  - Don’t compare your HRV to others. Compare it to your own baseline.
  - Look for consistently low HRV paired with elevated resting heart rate.
    - This suggests fatigue, low parasympathetic activity, and elevated sympathetic drive.
  - Even with high sympathetic tone (a sign of fatigue), a single workout might still be great due to the temporary energy spike.
    - However, chronic sympathetic dominance is harmful and should be addressed.
- **Recommended tool**: [Morpheus](https://trainwithmorpheus.com/) HRV device (Peter has no affiliation with Morpheus), which uses an optical sensor on the arm or a chest strap for accurate readings.
  - Peter prefers it over wrist-based wearables due to accuracy.

Other Red Flags and Physical Signals of Overtraining

- Persistent muscle soreness:
  - Soreness that doesn’t subside indicates incomplete recovery.
  - Take a break from training the affected body parts.
- Decreased performance:
  - Track performance metrics to spot trends.
  - Example: Peter notices his bike performance drops by 5–7% in Austin summers.
    - Not due to overtraining but heat—an example of environmental performance drag.
  - Still, consistent declines without explanation may indicate fatigue or overtraining.
- Pain or early signs of injury:
  - Joint pain, or pain that worsens with use, should be taken seriously.
- Mood changes and irritability:
  - Can also indicate overtraining, but are non-specific and harder to act on alone.

*Overall, identifying overtraining requires a combination of signals and a self-aware mindset built over time.*

## Avoiding injury: how beginners or returning lifters can start resistance training safely [1:15:15]

**Advice for Beginners Starting Resistance Training Safely**

Key Mindset: Start Fresh, No Matter Your Past

- Even if someone was highly athletic in the past (e.g., high school football player), Peter advises:
  - Approach resistance training as if you’ve never done it before.
  - The goal is long-term consistency without injury.
  - Injury prevention is prioritized over intensity or ego.

Foundational Guidelines for Injury Prevention

- Gradual progression is essential.
- Learn and master:
  - Foundational movement patterns
  - Correct form and technique before adding intensity or load

Understanding the Risks

- Most joint injuries come from:
  - High load
  - Fatigue
- Therefore, all movements (both concentric and eccentric) should be controlled:
  - Use tempo like 1:1 or 1:2 (concentric:eccentric) even if not exaggerated
  - Avoid explosive or jerky reps early on

Recommended Training Tactics for Beginners

- Assisted movements are critical early on:
  - Example: Band-assisted pull-ups allow for full range of motion and proper scapular control
  - Prevents compensation and overuse of secondary muscles
  - Minimizes risk to shoulder and elbow joints
- Bodyweight exercises are helpful at the start:
  - Focus on mastering movement patterns rather than using weight prematurely
  - Once you’ve learned optimal positioning, progress to external load
- Use eccentric load as a way to:
  - Build strength and control
  - Reduce weight used during training
  - Lower injury risk
- Unilateral Training as a Safety and Effectiveness Strategy
  - Peter emphasizes single-leg (unilateral) training:
    - He estimates 50% of his leg day includes unilateral movements
  - Benefits:
    - Lower total load on spine and joints
    - Improved coordination
    - Equally effective muscular stimulus with less weight

## Protein: recommended intake, quality sources, timing of consumption, and more [1:17:30]

For more detail on protein intake, check out this article from Peter: [Optimizing protein quantity, distribution, and quality](https://peterattiamd.com/protein-intake-distribution/)

\*\*\*

Recommended Protein Intake

- RDA Baseline: 0.8 grams per kilogram per day
  - This is only to prevent malnutrition, not to build or maintain muscle mass
- Target Intake for Muscle Growth:
  - 1.6 to 2.4 grams per kilogram/day
  - Translates to 0.8 to 1 gram per pound of body weight
- Older Adults & Inactive Individuals:
  - May need to exceed 1 gram/pound due to anabolic resistance
- Suboptimal Levels:
  - Anything around 0.4–0.5 g/lb is almost certainly insufficient

Protein Types and Quality

- Essential Amino Acids (EAAs)
  - 20 amino acids in total, but 9 are essential
  - Leucine is particularly important for triggering muscle protein synthesis (MPS)

Protein Source Considerations

- Animal Proteins:
  - Higher completeness (all essential amino acids)
  - Better digestibility
  - Top choices: dairy, eggs, beef
  - If these are included in diet, one can confidently meet protein needs
- Plant-Based Proteins:
  - Can work, but require more effort
  - Higher total protein intake needed
  - Cooking helps improve digestibility and absorption
- Patients often vary:
  - Some avoid beef but consume eggs/dairy
  - Others avoid all animal products
- Key focus for plant-based diets: hit essential amino acid targets

Protein Timing

- General Approach
  - The field is evolving; Peter used to stress timing more
  - Depends on protein source (e.g., whey vs. casein)
    - Whey is fast-digesting; casein digests more slowly
  - Liquid protein studies (e.g., radio-labeled isotopes) suggest:
    - Small, multiple protein doses
    - Post-workout bolus (~30–40g)
    - Ongoing stimulation throughout the day
- Peter’s Current Strategy
  - Focuses less on specific timing now
  - Eats 4 servings of 40–50g of protein per day via whole food
  - Avoids low-dose protein servings (e.g., just 10g at a time)
- Post-Workout Protein and the Anabolic Window
  - The “anabolic window” is more forgiving than once believed
  - Peter still eats protein soon after workouts, but not obsessively
    - Often doesn’t eat before workouts
    - Feels hunger will guide behavior post-exercise
    - Anabolic window likely spans 4 to 6 hours
    - No need to rush post-workout meals

## How fasting and calorie restriction affect muscle mass and what can be done to minimize muscle loss [1:24:15]

Impact of Caloric Deficit on Muscle

- When weight loss is caused by any form of caloric restriction it places muscle mass at risk—whether through:
  - Time-restricted eating
  - Intermittent fasting
  - Multi-day fasting
  - Or general dietary restriction
- Maintaining muscle mass while losing weight is extremely difficult unless enhanced with high levels of anabolic hormones

Steroids and Exceptions

- People using high-dose anabolic steroids can better resist muscle loss despite caloric deficit
- The conversation here excludes those using performance-enhancing drugs or uses them only at physiologic replacement levels

How to Mitigate Muscle Loss

- Two main levers to minimize muscle loss while losing weight:
  - 1) Meet protein needs (~1 gram per pound of body weight)
  - 2) Maintain high levels of resistance training

Peter’s Personal Fasting Experience

- During his extended fasts:
  - He created a large caloric deficit
  - Even with resistance training, it didn’t preserve muscle mass
  - Hypothetically, even if he consumed 200g of protein (~800 kcal), the deficit was too steep
    - Protein would likely be converted to glucose, not used for muscle building
    - Insufficient anabolic stimulus to prevent loss

What Bodybuilders Can Teach Us

- Drug-free and drug-enhanced bodybuilders avoid rapid weight loss
- They maintain muscle by:
  - Precision dieting
  - Careful pacing of caloric deficit
  - Consistent protein intake
  - Resistance training

[Luc van Loon](https://www.maastrichtuniversity.nl/ljc-van-loon)‘s Analogy: Bricks & Bricklayers

- Protein is the brick
- Training is the bricklayer
  - Together they enable muscle protein synthesis (MPS)
  - Inadequate calories = not enough labor or materials

What the Data Suggest

- [Studies](https://www.sciencedirect.com/science/article/pii/S2161831322012881?via%3Dihub) show that you can retain some muscle mass even with a 30–40% caloric deficit, if:
  - Protein is sufficient
  - Training is maintained
- But: it’s a delicate balance
  - Most people will lose some lean mass when cutting weight
  - Rapid weight loss increases the risk

## Key nutritional factors beyond protein that support muscle growth: hydration, creatine, and recovery [1:27:45]

**Additional Nutritional Factors for Supporting Muscle Gain**

Hydration

- Muscles are composed of ~70% water
- Therefore, hydration is essential for proper muscle function
- Dehydration impairs performance and reduces the muscle’s ability to grow and recover

Creatine Supplementation

- Creatine plays a key role in muscle function by acting as a phosphate donor
  - Helps regenerate ATP, the body’s energy currency
  - Enables quick energy replenishment during high-intensity exercise
- Backed by strong [evidence](https://www.mdpi.com/2072-6643/16/21/3665):
  - Numerous clinical trials and meta-analyses show its effectiveness
  - Benefits include improvements in:
    - Strength
    - Power
    - Muscle mass
- Peter’s recommendation:
  - Creatine is one of the very few supplements he universally endorses
  - He views it as a safe, well-supported supplement with broad application for nearly anyone exercising
- ⇒ See [AMA #69](https://peterattiamd.com/ama69/) for more on creatine

Recovery

- Often overlooked but critical for muscle growth
- Failure to adequately recover can negate gains from training, especially in those who may be overtraining
- Tied into both:
  - Nutrition (hydration, supplementation)
  - Rest and recovery routines

## The impact of hormones, sleep, stress, and consistency on muscle building and recovery [1:28:45]

**Lifestyle Factors That Affect Muscle Gain**

Hormones

- Testosterone is a critical anabolic hormone:
  - Higher testosterone = easier muscle gain
  - This is true regardless of:
    - Gender (applies to men and women)
    - Menopausal status
- Cortisol is catabolic and works against muscle development:
  - Chronically elevated cortisol impairs muscle growth
  - Seen most extremely in conditions like Cushing’s disease, which causes muscle wasting
  - Most people don’t have Cushing’s but still may walk around with excess cortisol levels due to chronic stress

Stress Management

- Reducing perceived stress is essential for muscle maintenance and growth
- There’s no pill to reduce cortisol—only lifestyle improvements like:
  - Better sleep
  - Mindful stress-reducing practices
  - Consistent recovery habits
- Cortisol management is often overlooked but can significantly impact training outcomes

Sleep

- Vital for recovery and muscle growth
- Most rebuilding happens during sleep
- The more stress the body is under (e.g., from intense training), the more sleep it requires
  - Example: Bodybuilders often sleep 9–10 hours per night to allow sufficient recovery

Consistency

- Long-term progress comes from consistency over time, not one-off bursts of hard work
- A great month followed by an inconsistent one won’t yield lasting results
- Progress is a cumulative process, much like compounding in finance
- Building and retaining muscle requires sustained effort, not intermittent spurts

## How to structure an effective workout routine for a younger person that is new to resistance training [1:31:30]

**Programming for a Younger Beginner New to Resistance Training**

General Approach

- No single “right way” to program—many viable options exist.
- The following is one method Peter uses with patients who are new to resistance training.
- This demographic (younger and new to lifting) often sees rapid progress if they stick with the plan.

Training Schedule

- Three-day full-body program (great for beginners, less optimal for advanced lifters):
  - Suggested weekly schedule: Mon/Wed/Fri or Tues/Thurs/Sat
  - 1-hour per workout
- Other weekly exercise hours (e.g., cardio) can complement this program.

Volume and Structure

- 10–20 total sets per body part per week
  - Spread across the 3 sessions
- Per workout:
  - 3–4 sets per exercise
  - 6–15 reps per set
  - Each exercise ~90 to 120 seconds of effort
- Use of supersets:
  - Especially effective in full-body sessions
  - Alternate opposing or unrelated muscle groups
    - E.g., do a back exercise, then “rest” that muscle by training chest
    - Efficient use of time and volume

Training Intensity

- Start at 3–4 RIR (reps in reserve)
  - Beginner-friendly level
- Progress toward 1–2 RIR as they adapt

Peter’s Superset Clarification

- **Superset definition**: Pairing two exercises back-to-back with minimal rest, targeting opposing or unrelated muscles
  - Example: bicep curls + tricep extensions
- Why superset?:
  - Time efficient
  - Allows “active rest” for the opposing muscle
- Avoid supersets that fatigue supporting muscles:
  - E.g., chest + tricep or back + bicep
  - Exception: Use that pairing strategically for pre-fatigue or plateau training—but not for beginners

\*\*\*

**SAMPLE TRAINING PROGRAM**:

**Program Overview**:

- Frequency: 3 days per week (e.g., Monday, Wednesday, Friday or Tuesday, Thursday, Saturday)
- Sets per exercise: 3-4 sets
- Rest between supersets: 90-120 seconds

**Day 1**

- Superset 1:
  - Deadlift or Hinge Dominant Movement (RDL, Glute Bridge) – 3 sets x 6-8 reps
  - Pull-Up or Vertical Pull Movement – 3 sets x 8-10 reps
- Superset 2:
  - Dumbbell Step-Up or Lunge Variation – 3 sets x 10-12 reps per leg
  - Dumbbell Chest Press or Horizontal Press Variation – 3 sets x 8-10 reps
- Superset 3:
  - Overhead Press or Vertical Press Movement – 3 sets x 8-10 reps
  - Single-Leg Romanian Deadlift or Split Stance Hinge Movement – 3 sets x 10 reps per leg
- Superset 4:
  - Cable Lateral Raises – 3 sets x 10-12 reps
  - Machine Leg Curl) – 3 sets x 10-12 reps
- Superset 5:
  - Pallof Press – 3 sets x 10-12 reps per side
  - Stability Ball Rollouts – 3 sets x 8-10 reps

**Day 2**

- Superset 1:
  - Front Squat or Variation of Knee Dominant Squat Pattern – 3 sets x 6-8 reps
  - TRX Rows or Bilateral Horizontal Pull Movement – 3 sets x 10-12 reps
- Superset 2:
  - Romanian Deadlift with Dumbbells  – 3 sets x 8-10 reps
  - Incline Dumbbell Chest Press – 3 sets x 8-10 reps
- Superset 3:
  - Lateral Lunges with Dumbbells – 3 sets x 10 reps per leg
  - Single Arm Vertical Press Movement – 3 sets x 8-10 reps
- Superset 4:
  - Cable Tricep Pushdown – 3 sets x 10-12 reps
  - Dumbbell or Cable Bicep Curl – 3 sets x 10-12 reps
- Superset 5:
  - Half Kneeling Lift – 3 sets x 10-12 reps per side
  - Hanging Leg Raise – 3 sets x 8-10 reps

**Day 3**

- Superset 1:
  - Trap Bar Deadlift or Hinge Dominant Movement – 3 sets x 6-8 reps
  - Chin-Up or Another Bilateral Vertical Pull Movement – 3 sets x 6-8 reps
- Superset 2:
  - Bulgarian Split Squat with Dumbbells or Alternate Lunge Variation – 3 sets x 8-10 reps per leg
  - Dumbbell Chest Fly or Variation – 3 sets x 10-12 reps
- Superset 3:
  - Barbell or Dumbbell Hip Thrust  – 3 sets x 10-12 reps
  - Dumbbell Lateral Raise – 3 sets x 12-15 reps
- Superset 4:
  - Dips or Press-down Variation – 3 sets x 8-10 reps
  - Concentration Curl – 3 sets x 10-12 reps per arm
- Superset 5:
  - Half Kneeling Chop – 3 sets x 10-12 reps per side
  - Stability Ball Rollouts – 3 sets x 8-10 reps

## How to modify beginner resistance training programs for older individuals to prioritize safety and gradual progress [1:35:30]

**Programming for an Older Beginner New to Resistance Training**

Same Core Principles as Younger Beginner

- Still a novice, so fundamental training principles (e.g. progressive overload, total volume targets, movement selection) remain consistent
- Focus is on gradual progression and consistency over intensity

Key Adjustments for Older Individuals

- Lower volume and lower intensity to start
  - Important for minimizing injury risk and avoiding discouragement
- Gradual increases in load and intensity over time, based on individual capacity and recovery
- Emphasis on proper form
  - Extra attention to learning and reinforcing correct movement patterns
- Slower movement tempos
  - Especially important for control and joint safety
  - Slower reps also help build stability and coordination

Exercise Selection and Session Flow

- May avoid supersets, especially if age or mobility makes transitions or complexity challenging
  - This also reduces volume compared to a non-stop superset-style session
  - Allows more rest and focus per movement
- Same one-hour session length, but likely fewer exercises completed due to lower pace and more rest

## Should beginners start with machines or free weights when resistance training? [1:36:30]

**Machines vs. Free Weights for Beginners**

Individual Setup Matters

- Peter emphasizes that the answer depends heavily on the person’s setup:
  - Do they have access to a qualified trainer?
    - If yes, they can likely begin with free weights safely—even with complex movements—if taught properly.
  - If not, the decision might shift based on comfort level and safety.

The [LIFTMOR Study](https://pubmed.ncbi.nlm.nih.gov/28975661/)

- He cites [Belinda Beck](https://theboneclinic.com.au/our_team/prof-belinda-beck/)’s LIFTMOR study, where 65-year-old women with no prior lifting experience were safely taught how to deadlift. (see [episode #332](https://peterattiamd.com/belindabeck/) with Belinda for more)
  - Takeaway: Even complex lifts can be learned at any age if instruction is good.

Benefits of Machines for Newcomers

- Safer and simpler to use without professional instruction
- Can be less intimidating than navigating free weights, especially in a busy or male-dominated gym environment
- Helps build confidence and familiarity with basic movement patterns
- Reduces the risk of form-related injuries early on

Peter’s Bottom Line

- Doesn’t believe machines are required for beginners, but sees them as a very reasonable, accessible starting point
- Main goal: get people moving safely and consistently, regardless of modality

## How experienced lifters should modify their training to support healthspan and performance in later life [1:38:00]

**Training Advice for Seasoned Lifters Focused on Lifespan & Healthspan**

Tailoring for Life Stage and Goals

- Advice shifts dramatically for experienced lifters.
- For those who love lifting but want to optimize for lifespan and healthspan, it’s no longer about simply gaining size or strength.
- Peter emphasizes the “[Centenarian Decathlon](https://peterattiamd.com/training-for-the-centenarian-decathlon/)” approach:
  - Define what physical activities you want to be capable of doing in your final decade of life (e.g. hiking, biking, swimming, playing sports with grandkids).
  - Train to ensure you can still do those specific movements as you age.

De-risking as a Priority

- Peter personally stopped deadlifting after realizing the risk-reward tradeoff wasn’t worth it for his goals.
  - Even though most sessions went fine, once a month his back would feel off—too risky over time.
  - Instead, he now does movements that minimize axial loading (e.g., belt squats, split squats).
  - These alternatives provide similar muscle stimulus without the spinal stress.
- Safer exercises might not maximize size or strength, but they lower injury risk, which is more important for long-term function.

Focusing on Weak Links

- Example: Peter worries about Achilles injuries (common in middle-aged athletes).
  - These often happen when muscle power exceeds the ability of connective tissue.
  - Prevention includes:
    - Explosive movements with caution
    - Calf raises and “bouncing” exercises to train the Achilles and other tendon areas.

Precision Training for the Marginal Decade

- Peter views this as “finishing school” for training:
  - Not about building foundational strength anymore
  - About refining the body to stay functional in older age
- Peter mentions his company [10 Squared](https://10squared.com/), which was created to help people train precisely for their final decade of life with as much care and specificity as elite athletic training.

---

## Selected Links / Related Material

**Previous episodes of The Drive that dove deep into muscle mass and strength**: [6:30]

- [#163 – Layne Norton, Ph.D.: Building muscle, losing fat, and the importance of resistance training](https://peterattiamd.com/laynenorton/)
- [#239 ‒ The science of strength, muscle, and training for longevity | Andy Galpin, Ph.D. (PART I)](https://peterattiamd.com/andygalpin/)
- [#335 ‒ The science of resistance training, building muscle, and anabolic steroid use in bodybuilding | Mike Israetel, Ph.D.](https://peterattiamd.com/mikeisraetel/)

**Studies that described hazard ratios for all-cause mortality for factor like cardiorespiratory Fitness (VO₂ max), grip strength, muscle mass, and other common risk factors**: [13:45]

- [Association of Cardiorespiratory Fitness With Long-term Mortality Among Adults Undergoing Exercise Treadmill Testing](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2707428) (Mandsager et al., 2018)
- [Exercise capacity and mortality in older men: a 20-year follow-up study](https://pubmed.ncbi.nlm.nih.gov/20697029/) (Kokkinos et al., 2010)
- [Strength, But Not Muscle Mass, Is Associated With Mortality in the Health, Aging and Body Composition Study Cohort](https://academic.oup.com/biomedgerontology/article-abstract/61/1/72/549632?redirectedFrom=fulltext&login=false) (Newman et al., 2006)
- [Srikanthan and Karlamangla 2014](https://pmc.ncbi.nlm.nih.gov/articles/PMC4035379/) (Srikanthan and Karlamangla 2014)
- [Predicted fat mass and lean mass in relation to all‐cause and cause‐specific mortality](https://pmc.ncbi.nlm.nih.gov/articles/PMC8978015/) (Liu et al., 2022)
- [Uncontrolled hypertension increases risk of all-cause and cardiovascular disease mortality in US adults: the NHANES III Linked Mortality Study](https://www.nature.com/articles/s41598-018-27377-2) (Zhou et al., 2018)
- [Smoking and Smoking Cessation in Relation to Mortality](https://pmc.ncbi.nlm.nih.gov/articles/PMC2879642/#:~:text=Compared%20to%20never%20smokers%2C%20current,major%20cause%2Dspecific%20mortality%20evaluated.) (Kenfield et al., 2008)

**PURE study that measured grip strength and connection with mortality risk**: [Prognostic value of grip strength: findings from the Prospective Urban Rural Epidemiology (PURE) study](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(14)62000-6/abstract) (Leong et al., 2018) [17:30]

**Study finding that strength, more so than muscle mass, is associated with mortality**: [Strength, But Not Muscle Mass, Is Associated With Mortality in the Health, Aging and Body Composition Study Cohort](https://academic.oup.com/biomedgerontology/article-abstract/61/1/72/549632?redirectedFrom=fulltext&login=false) (Newman et al., 2006) [18:00]

**Finnish study looking at grip strength and mortality risk**: [Genome-Wide Polygenic Score for Muscle Strength Predicts Risk for Common Diseases and Lifespan: A Prospective Cohort Study](https://academic.oup.com/biomedgerontology/article/79/4/glae064/7623674#google_vignette) (Herranen et al., 2024) [21:15]

**Episode of The Drive with Luc Van Loon**: [#299 ‒ Optimizing muscle protein synthesis: the crucial impact of protein quality and quantity, and the key role of resistance training | Luc van Loon, Ph.D.](https://peterattiamd.com/lucvanloon/) | Peter Attia (peterattiamd.com) [31:30]

**A review of 13 studies that compared traditional strength training with power training**: [Ageing, Muscle Power and Physical Function: A Systematic Review and Implications for Pragmatic Training Interventions](https://link.springer.com/article/10.1007/s40279-016-0489-x) (Byrne et al., 2016) [52:30]

**Device Peter uses to measure HRV**: [Morpheus](https://trainwithmorpheus.com/) [1:12:30]

**Studies showing that you can retain some muscle mass even with a 30–40% caloric deficit, if protein is sufficient and training is maintained**: [Recent Advances in the Characterization of Skeletal Muscle and Whole-Body Protein Responses to Dietary Protein and Exercise during Negative Energy Balance](https://www.sciencedirect.com/science/article/pii/S2161831322012881?via%3Dihub) (Carbone et al., 2019) [1:26:45]

**Peter’s company which was created to help people train precisely for their final decade of life with as much care and specificity as elite athletic training**: [10 Squared](https://10squared.com/) [1:41:15]

---

## People Mentioned

- [Layne Norton](https://www.instagram.com/biolayne/?hl=en)
- [Andy Galpin](https://www.andygalpin.com/)
- [Mike Israetel](https://www.instagram.com/drmikeisraetel/?hl=en)
- [Luc Van Loon](https://www.maastrichtuniversity.nl/ljc-van-loon)
- [Belinda Beck](https://theboneclinic.com.au/our_team/prof-belinda-beck/)