# #299 ‒ Optimizing muscle protein synthesis: the crucial impact of protein quality and quantity, and the key role of resistance training | Luc van Loon, Ph.D.

**Source:** [https://peterattiamd.com/lucvanloon/](https://peterattiamd.com/lucvanloon/)

---

Luc van Loon is an internationally renowned expert in skeletal muscle metabolism. In this episode, Luc starts with an exploration of the roles of insulin and triglycerides in endurance exercise, highlighting their impact on skeletal muscle metabolism, and he offers profound insights into the significance of protein in this context. He elucidates how different protein types and forms influence muscle protein synthesis rates, exploring the nuances of protein absorption, digestibility, amino acid quality, and their implications for performance and recovery. Delving deeper, he differentiates between animal and plant protein sources, unraveling the distinctive properties of various protein types, from the differences between whey and casein to the emerging trends in collagen protein supplementation. Moreover, Luc dissects the intricate connections among physical activity, lean muscle mass, muscle protein synthesis induced by resistance training, and dietary protein.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/lucvanloon/the_Drive_public.png)

Play

#299 ‒ Optimizing muscle protein synthesis: the crucial impact of protein quality and quantity, and the key role of resistance training | Luc van Loon, Ph.D.

#299 ‒ Optimizing muscle protein synthesis: the crucial impact of protein quality and quantity, and the key role of resistance training | Luc van Loon, Ph.D.

1x15s30s

0:002:30:06

## We discuss:

- Luc’s background and insights about fuel selection during exercise [3:30];
- Fuel utilization during endurance exercise [9:30];
- Fat metabolism, intramuscular lipids, and the nutritional dynamics of endurance sports [17:15];
- The optimal window for replenishing intramuscular fat stores and glycogen post-exercise [25:15];
- Luc’s interest in protein metabolism and exploration of amino acids’ dual role as building blocks and signaling molecules in driving muscle protein synthesis [32:15];
- How protein metabolism differs between sedentary individuals and those engaged in predominantly strength training or endurance training [38:45];
- The basics of how proteins are digested and absorbed, and how muscle protein synthesis is measured [50:30];
- How factors like food texture, cooking methods, and protein composition’s impact on muscle protein synthesis, and the importance of protein distribution throughout the day [59:45];
- Differences in whey and casein proteins, and the ability of ingested protein to stimulate muscle protein synthesis [1:03:30];
- Dietary protein distribution and quantity for the maximization of muscle protein synthesis [1:09:00];
- Muscle loss with age and inactivity and the importance of resistance exercise to maintain type II muscle fibers [1:17:15];
- Differences between whey and casein proteins, and the importance of both quantity and quality of protein sources [1:28:30];
- Optimizing muscle protein synthesis: exercise, timing of protein intake, protein quality, and more [1:37:00];
- How to preserve muscle while trying to lose weight [1:46:00];
- Anabolic resistance and overcoming it with physical activity [1:55:45];
- Importance of protein intake and physical activity in hospitalized patients [2:06:30];
- Reviewing the efficacy of collagen supplements [2:13:30];
- Plant-based diets: how to ensure a balance of amino acids, and other considerations [2:20:30];
- Future research: understanding protein metabolism in the brain [2:23:45]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Luc van Loon is a professor of physiology and exercise, and the head of the [M3 research unit](https://www.m3-research.nl/)
  - Which is part of the department of Human Biology at the Faculty of Health Medicine and Life Sciences at Maastricht University
- He is internationally renowned for his research that is focused on skeletal muscle metabolism in humans
- He is focused on 4 main fields of interest: skeletal muscle metabolism, exercise metabolism, sports and clinical nutrition, and aging
- Peter first came across Luc when he saw a video from a lecture he gave many years ago
  - And it’s not common that Peter is watching a video of somebody talking about protein where he’s actually stopping and watching it for great lengths because he’s actually learning something
  - Peter immediately became hooked and became more and more familiar with his work and ultimately wanted to have him on the podcast
- Luc received his Ph.D. from Maastricht University in the Department of Human Biology
- Subsequently, he did an internship at the Department of Kinesiology and Health Education at the University of Texas at Austin
- Then he did a couple of post-doctoral fellowships: one in Australia and one back at Maastricht University
- Luc is also the associate editor at the *International Journal of Sport Nutrition and Exercise Metabolism* and is on the editorial board of the *European Journal of Sports Science*
- In this episode we talk about the role of insulin and glucose for endurance exercising
  - We talk about the role of protein in all of this
- We speak about how different types of proteins in different forms will foster muscle protein synthesis at different rates
  - We talk specifically about the absorbability, digestibility, amino acid quality, and other features
  - We talk about the differences between animal sources and plant sources of protein
  - Using more helpful designations than that, we get into specific types of proteins
    - Even if you’re talking about milk-based protein: what is the difference between whey and casein?
- We also talk about the use case (if at all) for collagen protein
- We talk about how protein digestion is impacted not just by the type of food, but the preparation of the food
- We cover the relationship between activity, lean mass, building muscle protein from resistance training and the role that protein plays in that in terms of timing and type of protein

## Luc’s background and insights about fuel selection during exercise [3:30]

- Luc didn’t didn’t know where to go to college
- Most exercise physiologists are field athletes, so we want to know how our genetics can be compensated for by science
- He wanted to do movement sciences, so he studied movement sciences at Maastricht in the Netherlands
- After that, he went to Austin, Texas to work with [Jack Wilmore](https://education.utexas.edu/profile/jack-h-wilmore/) at UT for his Master’s internship
- After that, he finished his PhD in Maastricht again
- Then, he went to Melbourne to work with [Mark Hargreaves](https://findanexpert.unimelb.edu.au/profile/15778-mark-hargreaves)
- After spending some time in Melbourne, he came back and has spent the rest of his career in the Netherlands
  - From assistant prof to associate and to full professor, over the past 15 years

**The focus of this episode**

- Today, we’re going to not talk so much about the movement stuff, although that would be very interesting to our audience
- Instead we’re going to talk more on the nutrition side of things, specifically (and in great detail) about protein

**Protein is not necessarily your first foray into nutrition, correct?**

- No, that’s correct
- Luc’s main interest in the beginning and also in his PhD was in **fuel selection**
  - Substrate selection during exercise, and most of that stuff is done during endurance-type exercise
- And if you’re thinking about substrates, you’re not thinking about protein, which is from a quantitative point of view is not a very good substrate
  - Instead, it’s carbohydrate and fat metabolism
- The most interesting thing for him at that time was that they had set up a stabilizer dope research facility where you could track metabolites
- The first things that that lab did is actually measure carbohydrate oxidation rates
  - You would simply throw in some stable isotope labeled carbohydrates in your drink and simply by the oxidation of those carbohydrates, you would exhale 13CO2
    - If it’s labeled with [13C](https://en.wikipedia.org/wiki/Carbon-13), you get 13CO2 after you oxidize it
  - And by simply acquiring your expired breath, you can calculate how much of your energy came from a sports drink
  - Luc explains, “*That was so cool for me at that time*.”

**Just to be clear, you would also need to know the amount of oxygen consumption to be sure that that CO****2** **came from glucose and not from fat, correct?**

- Yeah, it’s a combination of indirect telemetry, so that’s total oxygen uptake and total carbon dioxide production, combined gives you total energy expenditure and also total oxidation of carbohydrates and fats
- Then, because you know what percentage of the carbohydrates derived CO2 was expired by 13CO2, you could calculate back how much of the carbohydrate is coming from your drink
  - That is cool, because then you’ll see how much of the drink are you actually using
- Peter mentions a method that uses deuterated water in C-13 ([doubly labeled water](https://en.wikipedia.org/wiki/Doubly_labeled_water)) to measure energy expenditure in a free living environment over a long period of time

**Is the method you are referring to only using labeled carbon and therefore only suitable for a short period of time to evaluate glucose oxidation, or do you also label oxygen and potentially get energy expenditure over a long period of time?**

- If you use doubly labeled water, you need several days to do that
  - You’re getting carbohydrates in, you start oxidizing them, that CO2 is also mixed in your blood
- It takes a while before the expiration of labeled carboy is a good proxy for the amount of carbohydrates that you’re oxidizing
- In 2 hours, they’re in a nice steady state
  - That’s why he’s measuring oxidation rate at 1-2 hours for endurance athletes
  - That’s only for exercise trials

Peter asks, “*Did this tend to be more accurate than the estimate you would get of carbohydrate oxidation rate just using the indirect calorimetry and the Weir equation? Or was the point here to determine not total carbohydrate metabolism, but specifically how much is coming from the drink?*”

- Exactly, you can see how much of that carbohydrate is coming from your drink (versus glycogen)
- You have your glycogen coming from your liver, you have your glycogen coming from your muscle, you can actually detect that with an intravenous glucose tracer with a different label, and then you have your 13C label in your drink, so you can actually see all 3 substrates
  - You can see what is coming from the drink, what is coming from your muscle glycogen, and what is total coming from your plasma glucose
    - Plasma glucose includes the drink, but you can subtract that from the total
- That was not enough for Luc, he also wanted to know what **fatty acids** are being used from your intramuscular triglycerides (the fat inside your muscle fibers) and what is come actually from the fat tissue that is releasing fatty acids and then transported to the circulation and taken up in the muscle
  - Because that is also an important topic for athletes, and also diabetes patients

## Fuel utilization during endurance exercise [9:30]

**Peter is preparing for a long endurance event**

- An event that’s going to take about 20 hours
- It’s been so long since he’s thought about how to prepare energetically for something like this
- Peter believes that nutrition can make or break you in these 20-hour marathon events

**What did you learn about the rate of carbohydrate metabolism, muscle glycogen, liver glycogen in the steady state?**

- One of the most important things is that all the glucose that is coming into circulation will be used for oxidation during exercise

***It’s a good idea to have a continuous supply of glucose coming from your gut***

- To keep your liver glycogen intact, or at least not to deplete too fast
- You want to maximize your liver glycogen
- We know that glucose polymers are oxidized at a rate of 1.0-1.1 grams per minute
  - About 60-70 grams per hour
  - However it can be a little bit higher if you add some fructose
    - Because fructose requires a different transporter
    - So if you combine glucose with fructose, you can get a little bit higher, but that’s only for the high-end athletes that can actually gain that high energy expenditure
    - Then you go up to maybe 1.3-1.4 grams per minute

***If you’re doing a 20-hour endurance event and you’re well-trained, you’ll actually be using quite a lot of fat***

**You require fat stores in your muscle as well as in your fat tissue**

- Theoretically, if you are a 70 kilogram weighing lean man, you can run for 24 hours to 3 days
- The amount of fat inside your skeletal muscle tissue is very relevant when you appreciate that your muscle glycogen storage increases as you become a better endurance athlete
  - Same goes for intramuscular triglycerides
- A couple of years ago, Peter had [Gerald Shulman](https://medicine.yale.edu/profile/gerald-shulman/) from Yale on the podcast [[episode #140]](https://peterattiamd.com/geraldshulman/)
  - Jerry is one of the world’s experts on insulin resistance
  - We spoke about the mechanism by which intracellular fat (diacylgluceride, not triacylglyceride within the cell) was one of the hallmarks of insulin resistance

**Are you talking about something different here? Are you talking about triglyceride between the muscle cells and not in?**

- You will notice that a lot of work done by clinicians focus on clinical work and the exercise physiologists focus on exercise work and sports, or sports supplements
  - A lot of work done in these 2 fields does not get used by either side
- When Luc was studying substrate metabolism in muscle and regulation of how substrates are selected, he was first interested in carbohydrates
  - Because during moderate to high intensity exercise, carbohydrates are the most important substrate source (from a quantitative point of view)
  - As exercise intensity increases, you depend more on your endogenous carbohydrate source
- But during moderate intensity exercise (and lower), much of the fat is actually being used by athletes and that also increases during high-intensity exercise as you become a better athlete

***As a good athlete, you can oxidize more fat, and that is a benefit because you need less of your limited carbohydrate stores***

**The muscle of an athlete adapts to store more glycogen, but it also adapts to store more fat (inside muscle fibers)**

- That’s intramyocellular lipids: that’s lipid droplets that you can see inside the muscle fiber
- In those days, Luc was cutting up muscle biopsies and looking under the microscope at individual fibers
  - He could see a lot of lipid droplets
- That storage is amply used by athletes
- In those days, [Hans Hoppler](https://journals.biologists.com/jeb/article/216/24/4499/11826/A-life-in-science-a-celebration-of-the-career-of) was one of the first to take electron microscopy pictures of that
- If you look inside one of those lipid droplets, you see a [mitochondrion](https://en.wikipedia.org/wiki/Mitochondrion) attached to it like a backpack
- Luc was one of the first to start measuring how much of that lipid inside the muscle fiber was being used during exercise
  - They did that using those [stable isotopes](https://en.wikipedia.org/wiki/Stable_isotope_labeling_by_amino_acids_in_cell_culture) indirectly
  - And also by taking muscle biopsies before and after exercise, and looking at the number and size of these small lipid droplets (and that goes down)

***Athletes use lot of the intramyocellular lipid for their energy provision, and particularly in the beginning of exercise***

- That makes sense because when you start exercising, lipolysis in your fat tissue takes time to get going
- This is almost immediate access (prime the pump)
- Peter was never aware that you could actually see mitochondria on the fat droplets within the cell of the muscle

**Would this be a fundamental distinguishing feature between the muscle cell of an athlete and the muscle cell of somebody with type 2 diabetes (which will also have fat within the muscle)?**

*Will the latter simply not have the mitochondria and, therefore, not be turning to it as an energy source out of the gate?*

- Very likely
- Luc has never seen electron microscope pictures of that
  - It’s difficult to quantitate because there’s so many lipid droplets
- There were other people in his department looking at diabetics, and then Luc became interested in the difference
- If you compare an endurance-trained athlete and a diabetic, they both have huge intramyocellular lipids
  - The differences is the athlete uses it, depletes it, builds it up again, but the diabetic doesn’t
  - If we actually exercise the diabetics, they’re not really using that intramyocellular lipid, and that makes perfect sense
    - Because their blood is full with free fatty acids
    - So the muscle is not going to use those limited stores in the muscle, because it’s constantly getting free fatty acids from the circulation

***In the muscle of diabetics, it’s a permanent storage [of lipids] with very little turnover, while in the athletes, it’s a substrate source that is constantly being used, and so the turnover of that substrate is the important factor driving towards actually insulin sensitivity [as opposed to insulin resistance]***

## Fat metabolism, intramuscular lipids, and the nutritional dynamics of endurance sports [17:15]

- Peter remembers reading a paper 12 years ago that very erroneously came to the conclusion that athletes on a ketogenic diet who had high amounts of intramyocellular lipids were insulin resistant, and he was shocked because he couldn’t believe they could fail to look at turnover rate and actually differentiate a static from a dynamic process
- This is obviously a more important example and a more relevant example

**What Luc saw in athletes**

- In the beginning of exercise, they use a lot of intramyocellular lipids
- But in the second stage of their endurance exercise, they stopped using them
- They wondered why
- This happens that when your free fatty acids in circulation go up

***By the time your adipose tissue is constantly feeding free fatty acids, you’re not using the fat stores in the muscle anymore***

- As soon as free fatty acids went up, the use of intramyocellular lipids went down

**Luc wondered what would happen if you reduced the free fatty acids in diabetics during exercise**

- They [gave](https://pubmed.ncbi.nlm.nih.gov/16096823/) [type 2 diabetics] [Acipimox](https://en.wikipedia.org/wiki/Acipimox) that blocks adipose tissue lipolysis, and suddenly they started using intramyocellular lipids
- And that improved post-exercise insulin sensitivity

***It’s a very nice way to stimulate the turnover of intramyocellular lipids, and it’s probably one of the mechanisms that makes insulin sensitivity improve after exercise***

**What role does insulin play in accessing the intramyocellular fat store?**

- Insulin along with maybe the hormone sensitive lipase play the most important role in determining the rate of esterification versus lipolysis in the fat cell
  - Obviously, we know the role insulin plays for glucose into the muscle cell
  - There is also non-insulin-dependent glucose uptake

*Where does insulin factor into both the athlete and the diabetic with respect to how fat is getting into and out of the muscle, or into the muscle and then oxidized?*

- Insulin also stimulates fatty acid uptake

***In an exercise setting, insulin doesn’t play an important role anymore during and immediately after exercise***

- Because stimulation of your [AMPK pathway](https://en.wikipedia.org/wiki/AMP-activated_protein_kinase) also stimulates glucose uptake
- The [GLUT4 transporters](https://en.wikipedia.org/wiki/GLUT4) are actually translocating to the outer membrane via insulin-dependent or exercise-dependent (2 separate pathways [for glucose entry into the cell])
- For fatty acids, it’s even a lot more difficult, because a lot of the free fatty acids [enter the cell by] facilitated diffusion
- Luc made the chance finding when they were measuring depletion of intramyocellular lipids in the leg in a noninvasive way using [MRS (magnetic resonance spectroscopy)](https://en.wikipedia.org/wiki/Nuclear_magnetic_resonance_spectroscopy)
  - For fun, they also measured this in the arm, and you’re not cycling with your arm
  - They did an [MRI](https://en.wikipedia.org/wiki/Magnetic_resonance_imaging) before and after exercise
    - The fat in the muscle went down in the legs, but it actually *increased* in the arm

**Their finding:** ***the greater turnover of free fatty acids in inactive muscle increased the amount of intramyocellular lipids (a lot of it is not regulated)***

> “*The muscle just takes what it can get. It’s very opportunistic.*”‒ Luc van Loon

**What do we know about the endurance athlete’s capacity to consume fat enduring a steady state exercise?**

- For example, if Peter is doing a 20-hour activity and his energy needs are going to be relatively low (500 kcal per hour)
  - He could almost meet that through ingested glucose, but that would be punishing on the GI system for 20 hours
    - That would be 1.25 grams per hour
  - Potentially, you might want to limit that to 30 grams per hour of carbohydrate (which would meet half of those needs)

*Would the rest be met through endogenous fat stores and a little bit of endogenous glycogen?*

- Or would you say, “*No, you could prime that with a little bit of additional substrate that is presumably fatty acid.*”?
- That’s a difficult question because nobody had done a lot of work in long-term endurance-type activities
- If you do nutrition research, you start with carbohydrate-related research
- Luc thought the be-all and end-all of everything is liver and muscle glycogen, but then he realized that **intramuscular triglycerides** are an important substrate source as well
  - What happens if you deplete them after a few hours of exercise
  - How fast do you replenish them?
    - Because if you were to do a next session with depleted intramuscular triglycerides, you wouldn’t have that prime that you’re referring to
    - so repleting [or replenishing} that is also important

***Then they realized that only carbohydrates is not enough, you also need fat, and of course, now that he’s actually doing a lot of research in protein, we now know that we also need protein, and then we’re back to food (but that’s another discussion)***

**Back to the question of how to fuel for a long endurance event**

- When Luc saw that fat was important in the muscle, they started looking at post-exercise fat depletion

***You have enough fat to provide enough fatty acids during a 20-hour endurance event, but you should not start that event with a low level of intramuscular fat***

- When Luc started talking with ultra endurance athletes, they proved him right
  - They said things like, “*Look, I can’t really perform in several day events (so multi-day events) if I don’t eat enough fat,*”
- Maybe that’s because you want to replete your intramyocellular lipid storage for several days
- If you do more of these 20-hour events back-to-back, then replenishing intramyocellular lipid stores are important
  - For a single event, Luc wouldn’t think it would be that important
- Peter points out that we tend to quantify glycogen capacity of a healthy, athletic, reasonably-sized male at 100 grams of glycogen storage capacity in his liver and 300-350 g in the muscle
  - Some athletes are even higher

**Do you have a sense of how many grams of fat could be stored in the muscle of a healthy athlete?**

***This is going back 20 years for Luc, he thinks it was around 100-200 grams***

- Peter thinks that’s still a lot because the caloric density of fat is higher
  - That’s functionally as many calories as you would have from glycogen

*Yes, but Luc thinks the calories are not the most important part*

***The intramuscular lipids provide the priming dose to cover from activating the adipose tissue towards having enough free fatty acid in the circulation, and that takes about 30-45 minutes***

## The optimal window for replenishing intramuscular fat stores and glycogen post-exercise [25:15]

**What does the window of time look like in which an athlete has the greatest opportunity to replenish intramuscular fat stores and intramuscular glycogen?**

*Presumably it’s a window following exercise. How long does that window remain open?*

- We don’t know exactly, but within about the first 4-5 hours, we see that glucose uptake is less or almost not insulin-dependent
- So basically, the more carbohydrates you ingest, the more it goes into the muscle, but then as your glycogen levels increase, then you get a break on glycogen deposition, so glycogen storage is inhibited simply by its content
  - It’s a self-limiting process, which is great, because if you don’t, you actually have a muscle disease

***For the first few hours, all the GLUT4 transporters are in the*** [***sarcolemma***](https://en.wikipedia.org/wiki/Sarcolemma)***, so all the glucose that comes into circulation gets sucked into the muscle***

- Peter clarifies, “*Meaning, just the contraction of the muscle alone during exercise is getting that GLUT4 transporter into the membrane without the need of insulin, and it’s open field running for glucose coming into the cell.*”
- Exactly, and that’s one of the reasons why exercise is so good for maintaining glucose homeostasis
- It’s not only the total amount of muscle, but especially the way you use the muscle

> “*The easiest way to actually cruise through your glucose tolerance test is, before you go to your GP, you actually run for 2 hours, because then you’ll have the lowest OGTT that you’ll ever see*.”‒ Luc van Loon

- Peter did this once, just as a test
  - He wanted to see how insulin-sensitive he could make his muscles before a 2-hour [OGTT](https://en.wikipedia.org/wiki/Glucose_tolerance_test)
  - He doesn’t remember the exact results, but it was astonishing
  - At the start, glucose is maybe 80 mg/dL
    - 30 minutes, 1 hour, and 2 hours later, it never went above 100 mg/dL
  - To Luc’s point about insulin independence, Peter doesn’t think his insulin went above 11
    - Even a fasting insulin above 11 is not uncommon

***Luc adds that this insulin effect improves glucose homeostasis for up to 24 hours***

- This is the reason why it is recommended for diabetics to get 150 minutes of exercise throughout the week (minimum; at least every other day)

**What about the fat window? Is that also about a 4-hour window?**

- Fatty acids don’t seem to be tightly-regulated, because of the facilitated diffusion of fatty acids
- If you are an athlete and you’re consuming a huge load of carbohydrates (especially during exercise), you’re going to limit your lipolysis and then you have less free fatty acids
- It seemed like at 48 hours, the intramyocellular lipid was almost at the same level again

Peter asks, “*Just to be clear, are you saying that most of the filling of the muscle with fat will come from endogenous fat stores via lipolysis, or is there a role for exogenous, ie. dietary fat in the post-exercise phase to boost that further?*”

- Peter wants to make sure the listener understands the relationship between carbohydrate ingestion and lipolysis
  - ***The more carbohydrate you ingest and the higher insulin goes, the more you inhibit lipolysis (which is the breakdown of fat from the stored fat cell)***

***Luc explains, in a well-trained athlete, about 50% of the fat oxygenation during exercise comes from your intramuscular triglycerides and the other 50% comes from free fatty acids released from your adipose tissue, transported through your blood and taken up by muscle cells***

- Luc explains, “*There’s not much reason to take fatty acids because there’s enough fatty acids being released from your adipose tissue*.”
- They did play around with [medium-chain triglycerides (MCT)](https://en.wikipedia.org/wiki/Medium-chain_triglyceride) (they are smaller fatty acids, the tail is less long)
  - They can be transported directly into the mitochondria, so they don’t need [CPT1](https://en.wikipedia.org/wiki/Carnitine_palmitoyltransferase_I)-facilitated transport
- They thought it was nice to get a faster oxidation labeled substrate, and they showed that MCTs are oxidized even during high intensity exercise
- The idea is that oxidizing medium chain triglycerides could save carbohydrate use
  - So you can maximize fat use during high-intensity exercise and therefore spare oxygen and improve performance
- It works with MCTs, but when they tried to see if they could make it quantitatively interesting, almost everybody got diarrhea
  - The big challenge with getting sufficient MCT volume is the gastrointestinal distress
    - For most people consuming 30 CC of pure oil is really pushing it
- 12 years ago, when Peter was hard on MCT oil, he could do 2 tablespoons [30 mL]
- Peter has seen products where they somehow [lyophilize](https://en.wikipedia.org/wiki/Freeze_drying#) MCT into a powder form

**Have you seen these lyophilized MCT products?**

- Yeah, Luck has seen suggestions that there are MCT-like products that presumably have less issues on the gastrointestinal tract
- He hasn’t used them
- He would contemplate, “*In what amounts do they actually contribute substantially, so that it improves performance?*”
- Luc thinks, as long as you can actually reach your goals with carbohydrates, why would you play around [with that]?

**Is there a role for MCT oil immediately following exercise as a very quick rapid source of fatty acid in the muscle?**

*Or are you saying no, because right after exercise, your insulin is so low, just let the lipolysis fill the tank? Why would you bother adding? We all want to lose a little bit of adipose tissue anyway, right?*

***Luc doesn’t think it has any relevance in practice***

## Luc’s interest in protein metabolism and exploration of amino acids’ dual role as building blocks and signaling molecules in driving muscle protein synthesis [32:15]

**How did your professional interests pivot from this to protein metabolism?**

- One of the interesting things Luc saw was what’s called “The athlete’s paradox” ‒ high intramyocellular fatty acids (lipid stores) in both diabetic, obese people and also in athletes

*What’s the difference between them?*

- Luc started coding some diabetes related research and exercise work in diabetics to improve insulin sensitivity and to improve substrate metabolism
- His mentor back then was the physician Dr. Hans Kaiser, and he was teaching him how to take muscle biopsies
- What they often saw is when you took a biopsy from an *athlete*, it’s like a chunk of muscle sitting there, like a piece of good steak
- But if they took a biopsy from a diabetic (often sedentary people), it was like a blob
  - It wasn’t standing up, it didn’t have any structure, it was like liquid

***It was obvious that with diabetes or a more sedentary lifestyle, comes changes in muscle quality; and if you start thinking about muscle quality, you start thinking about protein synthesis and protein metabolism***

- Luc was working with older people and this was very interesting

**What’s happening in athletes with that muscle?**

- You automatically go from only substrate to protein metabolism
  - And that’s where he got stuck and still has more questions

**Background on what is a protein**

- People have a clear understanding of the 4 major macronutrients: carbohydrates, fats, protein, and ethanol
- Protein consists of [amino acids](https://en.wikipedia.org/wiki/Amino_acid), and amino acids are the building blocks of both protein and our cells
  - Because all our tissues are mainly protein
- It depends on how you define it, but we have 20-22 amino acids
  - Of which 9 are [essential](https://en.wikipedia.org/wiki/Essential_amino_acid), and the rest are non-essential
    - Essential means that we can’t make it ourselves (there’s no endogenous synthesis in our bodies)
    - Non-essential means you can make these amino acids, to some extent

> “*That doesn’t mean that your non-essential amino acids are not essential in your diet… because you can’t simply just throw away all the protein and start feeding amino acids*.”‒ Luc van Loon

- They are called amino acids because they have a very clear structure: a carboxyl head (an organic acid) and a nitrous tail [amino group], with a carbon in between

![](https://peterattiamd.com/wp-content/uploads/2024/04/f1-lucvanloon.png)

**Figure 1. Generalized structure of an amino acid.** Image credit: [LibreTexts Biology](https://bio.libretexts.org/Courses/University_of_California_Davis/BIS_2A%3A_Introductory_Biology_%28Easlon%29/Readings/04.3%3A_Amino_Acids)

- **Nitrogen** is the big piece that we don’t see in carbohydrates and fat
- Carbohydrates and fat are basically carbon, hydrogen, oxygen
- Here you have carbon, hydrogen, oxygen, but you also have this big piece of nitrogen (we will talk about nitrogen balance)
- You have other things thrown in there: methionine has a little sulfur in it

***The point is biochemically, they all have a similar backbone, but what differentiates the 20 or 22 of them is what’s in the middle***

- What’s in the middle [R in the figure above] is the special sauce for each one and that’s what differentiates them
- That also defines their individual characteristics
- Amino acids are important as our own **building blocks** of course, and so that’s why we need to consume protein because they provide us with those building blocks
- What is interesting is that those amino acids are more than building blocks, they’re also **signaling molecules** that directly stimulate muscle protein synthesis (we’ll talk about this later)
  - They directly activate the [mTOR pathway](https://en.wikipedia.org/wiki/MTORC1#) driving muscle protein synthesis

*How Luc explains it to 1st year students*

- You have a building site where you actually have bricks being delivered and the bricks themselves pick up the phone and call the bricklayers to come over
- It’s really amazing how that works: simply eating stimulates your muscle protein synthesis

**Luc is a muscle physiologist, and most of his work is on muscle**

- He’s been starting to work on different organs because this is of interest and there’s not a lot of data there available

***What we do know is you’re synthesizing about 300 g of protein on a daily basis***

- That includes tissues, hormones, enzymes, blood proteins, everything together
- As most of the listeners will consider, they are consuming about 70-100 grams of protein per day
- That means that for a man weighing 70 kilograms, they will be recycling 230 grams of protein
  - This is something that people don’t realize

***Yes, we consume foods and we need those building blocks, but you’re also constantly using amino acids that are being released from the breakdown of tissues, and then you use them again***

- You’re making 300 grams, but you’re only ingesting 70 grams; so that means on a 24-hour basis, you’re recycling 230 grams of amino acids from your own body
  - So you’re very sustainable

## How protein metabolism differs between sedentary individuals and those engaged in predominantly strength training or endurance training [38:45]

**How protein metabolism differs in an active person ‒ compare 3 people**

- 1 – An active person who is doing strength training
- 2 – An active person who is doing steady-state cardio training
- 3 – A person who is not training
- Luc doesnt think anybody would have data on that because this is on the whole body level (organs, tissues, guts, everything)

*If we’re asking these questions, we have to move back to a muscle-centric perspective*

Peter asks a technical question, “*Explain to people the methods that you use to actually do these types of measurements*.”

- We already discussed one isotope method with respect to carbohydrate metabolism
  - What about the study of amino acids?
- You have stable isotopes: [Carbon-12](https://en.wikipedia.org/wiki/Carbon-12) (carbon is a weight of 12 in nature)
  - There is also carbon-30, it has an extra neutron in its core, and it’s stable (it doesn’t fall apart)
- [Carbon-14](https://en.wikipedia.org/wiki/Carbon-14) is an unstable, radioactive isotope
- You can purchase [carbon-13](https://en.wikipedia.org/wiki/Carbon-13)-labeled metabolites such as **carbon-13 labeled phenylalanine**
  - Nowadays, we often use phenylalanine as the tracer because it’s an essential amino acid that is hardly metabolized in muscle (or not metabolized in muscle), and it’s not as volatile as leucine (for example)
    - And leucine of course has a lot of other effects
    - So you want to have a nice stable amino acid that is a good representation of other essential amino acids
- You can put 13C labeled phenylalanine and dilute it in a bag of saline, infuse it in the body, and then you can have 5% of all the phenylalanine [labeled] in circulation
- Then you take a muscle biopsy, take the muscle out of the biopsy, take the protein out of the biopsy
  - You can even separate mitochondrial protein or myofibrillar protein (that’s actin and myosin) and then hydrolyze that protein back to its free amino acids and use [mass spectrometry](https://en.wikipedia.org/wiki/Mass_spectrometry) to look at how many of those amino acids are coming from the 13C labeled phenylalanine
    - [[Actin](https://en.wikipedia.org/wiki/Actin) and [myosin](https://en.wikipedia.org/wiki/Myosin) are responsible for muscle contraction, discussed in episodes [#250](https://peterattiamd.com/andygalpin2/) and [#179](https://peterattiamd.com/jeremyloenneke/)]
- A few hours later, you take a new biopsy and you see how much more of that 13C phenylalanine is built into the muscle protein
- If you divide that by the availability in the circulation and the time between the 2 biopsies, you have a **fractional synthetic rate** generally expressed in percent per hour
- Now, on a daily basis, that’s about 1-2% per day
  - It’s always confusing, to Luc, it’s always magic
  - That means if all the proteins in your muscle are generic (which they aren’t of course, but assume an average), then they are actually completely refurbished in 50 to 100 days

> “*I always ask people to look at their own arm and realize that in 50 to 100 days they have a new arm, it’s completely refurbished*.”‒ Luc van Loon

***The individual proteins in the muscle are broken down and built up again, and we can measure that by infusing those labeled amino acids and simply measuring their synthesis rates***

- Peter finds this amazing even though we don’t take it as so earth-shattering that every 3 months, our entire hematopoietic system turns over
  - Every 90 days, a red blood cell is gone and it’s replaced with a new one
  - When you talk about it through the lens of muscle, it’s much more complicated and difficult to wrap your mind around
    - You don’t notice the difference

**What preserves the architecture?**

*This gets to what is being replaced and what is technically not being replaced?*

*How does the shape change so that we don’t look different, so that we’re not a constantly morphing creature?*

- Peter has more questions than Luc can ever answer, but he hopes to come back to that later

**Findings from Luc’s research**

- As they started measuring turnover rates of tissues other than muscle, it got even more freaky
- He started to wonder, “*How is this regulated?*”
- Let’s not do this because it will be confusing, but
- They also [measured](https://pubmed.ncbi.nlm.nih.gov/29432531/) protein turnover in the human brain, and if you see those turnover rates, then you have different questions [discussed briefly at the end of the episode]

**Focusing on the muscle**

***In order to keep and maintain muscle mass, you need to stimulate [muscle protein synthesis] because the breakdown will continue***

- You actually have anabolic stimuli that stimulate the synthesis
- We come back to nutrition and exercise, because it’s food intake (in particularly protein intake) and exercise that stimulate muscle protein synthesis
- How these 2 stimuli know which proteins to build and in what structure is just an enigma
- In his lecture, Luc will show a picture of Lance Armstrong or one of the Mr. Universes as guys who have huge protein synthesis after an exercise session, **but the phenotypic response is completely different**

***After resistance exercise, you build a lot of myofibrillar protein, while the endurance athlete will build a lot of mitochondrial proteins***

**How is it directly regulated?**

- The body knows by the recruitments of your muscle fibers, which proteins should be synthesized
- We know a lot of molecular pathways
- First we thought we had everything by measuring mRNAs
- Then we thought we had everything by measuring protein content (with western blots) and then protein phosphorylation
- Then we went to transcriptomics, and then we suddenly knew that we had post-translational modification and then we had mRNA splicing
- It’s getting more and more complex

**Let’s compare a world-class endurance athlete and a world-class bodybuilder**

- Let’s simplify the equation and take drugs out of it
  - Let’s not talk about the best bodybuilder because they are using high amounts of anabolic steroids, but a world-class natural bodybuilder (who by any metric is enormous)

*The question is, how does the body know in the case of the bodybuilder, to disproportionately build myofibrillar protein, whereas in the endurance athlete, to disproportionately build mitochondrial protein?*

- To Peter, the obvious answer seems to be the training stimulus
  - The bodybuilder is pushing enormous amounts of weight repeatedly within the confines of certain reps in certain sets
  - And the endurance athlete is never ever stressing the muscle at a single rep
    - If you think about it, an endurance cyclist might be 80 to 180 to 100 cadence, and they’ll do hundreds of thousands of those repetitions, but none of them are as hard as the reps that the bodybuilder is doing for 6-12 reps, so that’s an obvious difference

*Is the question that we don’t understand how that is translating a signal into the MPS [muscle protein synthesis]?*

- Yes, we don’t know
- If Luc asks a 2nd or 3rd year student this question, they would move away from the real answer by saying, “*Hey, it’s different fibers*.”
  - That’s part of the answer because resistance type athletes will more likely recruit the [type II fibers](https://en.wikipedia.org/wiki/Skeletal_muscle#Fiber_types)
    - The type II fibers are more likely to build mass
    - [muscle fiber types are explained in [episode #250](https://peterattiamd.com/andygalpin2/)]
    - In bodybuilders, you see huge type II fibers
- When you get older, you get smaller type II fibers, and that’s were most of the **muscle loss with aging** comes from
- With the endurance athlete, you don’t see much happening with the size of the fibers
  - We just see greater capillary density
  - We see more mitochondria, higher density of mitochondria, subcycling mitochondria

***The adaptive response is completely different in the bodybuilder and the endurance athlete***

- Part of it is because of what **fibers** you recruit, but that’s not the complete answer
- For example, in the discussion about high reps, low reps, low weight, high weight, there’s now very nice studies that show if you do high reps with a low weight to exhaustion, you also start using the type II fibers and you also get hypertrophy
  - That’s a nice way, especially in rehabilitation, that you can actually drive those type II fibers without putting too much effort on the hip or the leg or that was just operated on
- There’s more going

*What is exactly the signal?*

- The molecular signal from the tension on the muscle towards the synthesis of the specific sets of proteins
- There’s enormous amounts of pathways involved, and Luc is not sure whether we’ll ever completely know what is happening now and where that selection is going to be

**Would it be reasonable to assume that the bodybuilder has more up regulation of mTOR than the endurance athlete, or is that even a stretch in terms of an assumption, given that it’s difficult to measure that?**

- We know that a lot of the hypertrophy is actually mTOR
- The stimulation of muscle protein synthesis can be mTOR independent
- There are so many parallel pathways that are driving responses
  - For example, if you ingest protein, you stimulate mTOR signaling, you stimulate mRNA translation initiation, and you get greater protein synthesis
    - But it actually is not continuously stimulated if you do not provide all the building blocks
    - If we, for example, after exercise (or even at rest) provide people with the branch-chain amino acids, mainly leucine,is driving that anabolic response
    - It’s the signaling response: you stimulate muscle protein synthesis and for up to 2 hours
  - But if we give the same amount of leucine (or in this case branch chain amino acids), in a similar amount of milk protein, we see that response is actually sustained over more prolonged period of time
    - So containing the same amount of branch chain amino acids plus all the other amino acids
  - So it’s not only the stimulation, it’s the stimulation in combination with the right amount of building blocks at the right amount of time

*How Luc explains it to students*

- You have a parking lot where you want to park as many cars as possible
- You can put the light on green to drive in, but if there’s no cars, nothing’s going to happen

***And so it’s a combination of the right signaling responses plus the availability of your substrate***

- There was a recent [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10772463/) that Luc was an author on that looked at the duration of muscle protein synthesis following the digestion of different types of amino acids (we’ll come to that)

## The basics of how proteins are digested and absorbed, and how muscle protein synthesis is measured [50:30]

**Let’s take a step back for a moment and make sure we at least cover the basics of how protein is digested**

- Peter wants to talk about 3 types
- 1 – A whole meal, a meal of protein that often comes with fat (such as eating a steak)
- How that differs from 2 milk-based proteins
  - 2 – Whey protein
  - 3 – Casein
- Peter wants to understand what is actually happening from a digestive standpoint and how the thing that you actually consume and put in your mouth, turns into building blocks that presumably are being absorbed somewhere in the ilium or jejunum

*Luc will first explain protein and then go to specific protein sources or meals*

- Protein is ingested, it goes to your stomach and acid is added to it
  - You get clotting of protein due to the acids
- Then you have enzymes being unloaded on your protein (if they can get access to it) and they produce the free amino acids
- A lot of people suggest that for small proteins (oligopeptides, di and tripeptides), there are transporters in the gut that would allow them to enter intestinal cells
  - We think from a quantitative point of view, it’s hardly relevant, but it’s possible
- Part of the amino acids are then actually incorporated into intestinal protein because the gut also has a very rapid protein [synthesis], much faster than muscle
  - Part of it remains in the intestinal tissues as protein
- Some of it is released on the other side of the intestine in the portal vein
  - The portal vein transports it to the liver
- The liver can do something with the amino acids if it wants to make proteins, but most of it is actually released in the circulation where it will go to all those different tissues, be taken up and used for muscle protein synthesis
- That’s the whole pathway
- We don’t have a real **storage depot [for amino acids]**
- There’s a small free amino acid pool, if you compare it with the intact protein pool
  - They always say it’s very small in muscle, but acutely after a meal, it can actually vary a lot
  - It’s a temporary buffer, but we don’t really have real storage sites for amino acids

- Peter points out: unlike fat, which can be stored in unlimited quantities
  - And glucose, which can initially be stored in glycogen, although that’s a relatively finite store
    - And then eventually can be stored as fat through de novo lipogenesis

**What exactly happens to excess protein if we consume it?**

- Let’s just use an extreme example: you eat a 200 gram protein meal
  - Make it whatever number you want, such that the point is, you clearly have excess amino acids once fully digested

*What does your body do with those excess amino acids?*

- There is no storage of amino acids
- Glucose is stored as glycogen and fatty acids are stored as fat
- Amino acids are stored as protein, but is it a real storage depot?
  - We hope we’re not losing muscle
  - If we’re in a concentration camp, then we’re quite happy that we have a storage depot of amino acids in the form of muscle
  - [Muscle] is a storage depot of amino acids, but we hope that we are not using it
- The literature says that excess protein that you can’t immediately process is oxidized

***The*** [***study***](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10772463/) ***by*** [***Jorn Trommelen***](https://cris.maastrichtuniversity.nl/en/persons/jorn-trommelen) ***published a few weeks ago showed that a 100 g oxidation in the first 12 hours after ingested is very overestimated, but if you keep eating more protein, and in a setting of excess calories, you simply store the protein as fat***

- Peter vaguely remembers from biochemistry classes more than 25 years ago that amino acids could undergo [gluconeogenesis](https://en.wikipedia.org/wiki/Gluconeogenesis) to become glucose and then either glycogen or fat
  - This is what Luc is referring to
- It’s different for different amino acids and it’s very inefficient
  - The inefficiency is one of the reasons why people tend to get less fat accumulation if they overeat in the form of protein (besides the satiety effect)
  - There’s a thermogenic and thermodynamic loss or use of energy just in the metabolism of protein, that itself is obviously beneficial if your goal is to store less energy

**How muscle protein synthesis is measured**

*Luc has something to say about he techniques that he uses*

- His lab does protein synthesis measurements all the time

***Luc wanted to know more about the digestion and absorption prior to stimulating muscle protein synthesis, and in order to understand that, you need those stabilized traces, not only in an infusate, but you would like to have those labeled amino acids in the foods as protein (you can’t purchase those)***

- About 15-20 years ago, he worked with a [Yves Boirie](https://www.researchgate.net/profile/Yves-Boirie) in France, they already made intrinsically labeled protein
- They infused a cow with those labeled amino acids, and the cow integrates those labeled amino acids in the milk
  - Then you can actually use the milk in clinical experiments
- Luc wanted to take it one step further because they wanted to have the number of labeled amino acids in the milk so high as to actually see the digestion and absorption, and even the incorporation in the muscle
  - That is very expensive, and they spent more than 50,000 euros on tracers
- That’s pretty challenging the first time, because you infuse it in the cow and you hope you are going to see that money back

***They put labeled phenylalanine in a cow, the cow made milk, they extracted the milk, then they made it into protein powder, and they used it in clinical experiments to assess digestion, absorption, release, extraction over the lag and incorporation in the muscle***

- They did this study to see the difference between casein and whey (we’ll come back to this)
- A year later, they used this labeled protein powder in an older subject, and in that study, they took a muscle biopsy
  - That muscle biopsy has the same amino acids integrated in the muscle, they dissolve it and analyze it by mass spec, and now they have the same amino acids [as was in the labeled protein powder]
    - That amino acid has been around for 4 years: it went from a lab in the US (where they originally bought it), through a cow’s blood and into its milk, to protein powder that sat on Luc’s desk, and back into somebody else
    - That’s amazing

**Give me a sense of the yield. When you made the casein or the whey protein from the cow’s milk, what fraction of the phenylalanine was actually labeled with the isotope?**

- We got 25% of the tracer back in the milk
  - And so you can imagine as a Dutch person Luc is supposed to be cheap; so losing 75% of that money in a cow is not something that you can sleep on
    - So they butchered the cow

*How much of the phenylalanine did you find in the meat of the cow then?*

- It gets difficult because you have to multiply it by the total amount of meat, and if you butcher a cow, you don’t get all the meat
- They sampled all the organs, and that was a starting point for them to start measuring turnover of other organs in humans

***What was interesting is that different muscles had different enrichment, but it was all ballparked the sam***e

- They never calculated whether it actually came back to 75%, but it must have been very close

## How factors like food texture, cooking methods, and protein composition’s impact on muscle protein synthesis, and the importance of protein distribution throughout the day [59:45]

**To get back to Peter’s other question: to see whether there’s a difference in the digestion and absorption when you ingest meat as a steak, or if that same steak was first put in a meat grinder and you had basically minced meat**

- They used the meat from this cow

***There is a huge difference***

- With minced meat, you get more rapid digestion and absorption, which should also expedite your muscle protein synthesis
  - Because the more rapid absorption, the greater and faster the release of leucine, the greater the stimulation of muscle protein synthesis
- An epidemiology study in the ‘60s showed accelerated digestion and absorption of minced meat versus steak potentially improves anabolic responses
  - Specifically, it showed that older people who still had their own teeth generally also have their muscle still in tact

> “*That was a nice link to say that your mom has been right on a lot of things because I mean, I spent probably 30 million euros of research money in the last 30 years, to provide clinical proof that my mom was right on a lot of things.*”‒ Luc van Loon

- You’re mom was right when she said chew your food
- But even something as simple as sitting upright has a huge effect on digestion and absorption
- Chewing is a factor that drives the anabolic response to feeding
- It’s really funny then if you go to **mixed meals** ‒ if there’s micronutrients coming together, a lot of energy will actually slow down gastric emptying
  - That is one factor

***Important factors affecting digestion and absorption: the matrix of foods, the chewing of the food, whether you cook it or not, there’s so many topics here***

- Luc did a [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9644172/) with eating eggs that were raw or cooked and it had a huge effect on digestion and absorption
  - He tried to have have Sylvester Stallone on that paper, but unfortunately he never responded
  - They basically said, “*Was Rocky right or wrong?*”
  - Because in the first movie, he’s ingesting raw eggs
  - Would it not be better to actually cook those eggs because you have more rapid digestion and absorption?
  - Peter thinks of how many raw eggs he consumed as a child because he watched [*Rocky*](https://en.wikipedia.org/wiki/Rocky); it’s a miracle he didn’t get salmonella

**Back to the example of steak versus ground beef**

- This [study](https://www.sciencedirect.com/science/article/pii/S0002916523051407?via%3Dihub) was not just isocaloric but iso protein
  - Everything about them is the same (same amount of fat), but one is ground and one is not
- The most important factor is that all the enzymes that are being released in the duodenum are *accelerated* with ground beef
  - You have more rapid gastric emptying
  - The acid has already had more space to actually have its effect, faster gastric emptying then it gets into the duodenum
  - You don’t have these big chunks of meat, instead enzymes can actually attach everywhere much easier
    - So you get more rapid digestion and absorption
  - It’s similar to casein and whey: athletes say we need whey protein
    - 20% of the proteins in milk are whey and 80% are casein

## Differences in whey and casein proteins, and the ability of ingested protein to stimulate muscle protein synthesis [1:03:30]

**The first** [**study**](https://www.sciencedirect.com/science/article/pii/S000291652302275X?via%3Dihub) **Luc did with intrinsically labeled protein compared whey and casein proteins**

- They got the labeled milk, processed it down to micellar casein and whey
- For all those years, companies were telling Luc that predigested protein (the hydrolyzed protein) is more rapidly digested and absorbed, but he asked, “*Where’s the proof?*”
  - All they had were [*in vitro*](https://en.wikipedia.org/wiki/In_vitro) assays (in tubes and glass things)
  - To Luc, the human [*in vivo*](https://en.wikipedia.org/wiki/In_vivo) system is much more complex
  - When he told them he would infuse a cow and then do this and that, they looked at him like he was completely crazy
  - It took Luc 7 years until they funded it
- They predigested micellar casein with enzymes to get a casein hydrolysate
- Then they checked these proteins for digestion and absorption

*Findings*

- Hydrolyzed casein and whey proteins are much more rapidly digested and absorbed than the micellar casein
- Because the micellar casein in the acidity of the gut starts coagulating like spoiled milk
  - The gastric emptying is probably reduced or slowed down, but also the capacity of the enzymes to basically start digesting the foods

***That’s how we now know that rapidly digestible protein is more likely to stimulate muscle protein synthesis to a greater extent***

**There’s 2 characteristics of a protein: the digestion of it and the rate of digestion**

*But then you would expect that a pre-digested casein would do exactly the same as a whey protein, but it doesn’t*

***The pre-digested casein is as rapidly digested and absorbed, but the whey protein still has a greater anabolic response***

- And that might have something to do with the amino acid composition
- We know that whey protein has a higher **leucine** content
- And so if we add, for example, free leucine to casein, we get a greater anabolic response

***Obviously the amount of leucine is important factor***

> “*In a nutshell, two characteristics of a protein and their capacity to stimulate muscle protein synthesis is digestibility, the rate of digestion and the amino acid composition with particularly the amount of leucine in the protein. And anything that slows down the gastric emptying or the release of leucine in circulation will likely also slow down the anabolic response.*”‒ Luc van Loon

**Let’s unpack that a bit because there’s a lot there. We’re collapsing digestibility and rate of digestion into one feature, although can’t they be disentangled a little bit?**

- In the example of the whole meat versus mince meat, one has effectively been broken down

*Wouldn’t the ground beef have a higher rate of digestibility?*

- No, Luc thinks with cooked meat, the digestibility is the same
- It will take a little bit longer for the steak than for the minced meat

*What about the rate of digestion, wouldn’t that be quicker for ground beef?*

- Yes
- Nutrition scientists love to work with a single ingredient because otherwise we don’t know what’s going on
- But normal people don’t eat protein powders, protein isolates, or concentrates
  - We eat foods
- If you go back to the literature and look at how many studies have assessed the anabolic response to eating foods, that is very slim because nobody is interested in foods
  - It’s often protein X versus this because if you start having meals, everything comes together: plant-based proteins, animal-based proteins, the processing of the protein, whether it’s heated or not heated, whether it’s cut fine, minced, not minced, chewing well, not
    - Whether it’s combined, how much on the plate, how many fibers, all of these things together actually determine the anabolic response to feeding

***Then the digestibility becomes most important***

- In 99% of our studies, the digestibility is not an issue because we use extracted proteins
- Also, when we go to plant-based proteins it’s often still a little less than animal derived proteins, but it’s not a major issue anymore
  - It’s a major issue if it comes in the form of whole foods

## Dietary protein distribution and quantity for the maximization of muscle protein synthesis [1:09:00]

**Before we get into the details, Peter asks, “*****How much does it clinically matter the rate at which muscle protein synthesis is stimulated?*****”**

**Peter’s takeaway so far**: there are 3 factors that will determine the rate at which muscle protein synthesis takes place: (1) digestibility of what you are ingesting, (2) rate at which this protein is digested, and (3) the composition of the amino acids

- For #1 digestibility, this could be the difference between a plant-derived protein and an animal-derived protein
  - This could be the difference between a cooked protein versus a not cooked protein
  - This could be the difference between 2 types of proteins
- For #2 the rate of digestion, you can picture a curve with the X-axis being time and the Y-axis being digestion, the rate of digestion will speak to the shape of that curve
  - Examples discussed would be how the food is cut, and it could be ground beef versus whole beef
    - How well the person chews
- For #3 Luc has alluded to [leucine](https://en.wikipedia.org/wiki/Leucine) many times
  - On the podcast, we’ve talked about leucine and the most potent mTOR stimulator
    - [Episodes [#272 with David Sabatini & Matt Kaeberlein](https://peterattiamd.com/davidsabatini-mattkaeberlein/), [#224 with Don Layman](https://peterattiamd.com/donlayman/), and [#163 with Layne Norton](https://peterattiamd.com/donlayman/)]
  - Obviously there are other amino acids: [lysine](https://en.wikipedia.org/wiki/Lysine) and [methionine](https://en.wikipedia.org/wiki/Methionine)
    - These are probably more pro-anabolic
  - Therefore the concentration and distribution of amino acids plays a role

**The macro question: for a person looking to maximize/ optimize/ maintain/ increase lean body mass, what can we do nutritionally?**

- Peter adds that anything we can do nutritionally to maximize or increase MPS should be good, but the one thing that we’re missing is the window over which that happens

*Do we want to maximize that for the highest peak independent of the base, or do we want more of a time-release effect where we say, “Look, we’ll take a lower rate or a lower peak muscle protein synthesis, but I’d like to sustain that for many, many hours.”?*

- Luc explains that these are all the questions that the field has and that we all have
- One factor that we didn’t discuss is the amount of protein, “*The amount of protein also has an effect on the curve, and you can compensate with the amount*.”

***Estimations of up to 2-3 grams of leucine in a meal will induce a rapid increase in circulating leucine and that will stimulate MPS, and if you have enough building blocks available, you have an anabolic response for at least up to 5 hours***

- This has lead most of the field to believe that it’s best to ingest 20 grams of protein to maximize MPS for up to 4-5 hours after a meal, and this is why you see in so many packages 20 grams of protein
  - This is for healthy, active males or females
- That comes from studies showing that ingestion of 40 grams of protein does not result in greater muscle protein synthesis rates than 20 grams of protein
  - So it’s assumed that 20 gram is the optimal amount in healthy people
- We have discussions [of exceptions]
  - If your under 20 kg [44 lbs], you probably need more
  - If you’re 50 kg [110 lbs], you probably need less

> “*If you assume that you would have an anabolic response to each main meal, then the advice is there to ingest 20 grams of protein with each main meal.*”‒ Luc van Loon

- If you are becoming older, there are suggestions you need more to compensate for that

**Recommendations for young, healthy people**

- That’s 20, 20, 20, and possibly also an evening protein snack (20), and then you already have 80 grams of protein, which for most people is already more than 1-1.1 grams protein [per kg] per day
- The idea is distribution of protein that every meal is an anabolic response

**Luc explains, “*****We are people that believe that you actually could use more protein*****”**

- This automatically happens when you become active because when you become active, you eat more and then you easily eat more than 1.1

Peter asks, “*This 20 grams is the maximum amount of protein you need to get maximum protein synthesis. Muscle protein synthesis was based on what type of protein?*”

- There was a study on milk and there was a study on egg (whole foods)
- That’s a very important point because if your digestibility is not 100% (which in a meal is never of course) and you have a delay in digestion and absorption, then 20 grams could be suggested to be a *minimum*
- What Peter is hearing is if you’re going to try to get this through food, by definition, you’re going to be working with an inferior protein from the standpoint of speed in terms of digestibility and rate of digestion, and you might need a protein meal that’s **30 grams** or more
  - And if your 90 kilos (198 lbs), you’re probably on the bigger end of that and might need 40 g
  - Luc agrees

**With these discussions, when Luc says you need to ingest more protein, other look at him like he’s advocating a high-protein diet, but consider:**

- If you have a 65 kg weighing Tour de France cyclist (143 lbs), and they only consumes a very little amount of protein in the form of only 10% of their energy intake
  - They’re still ingesting probably more than 2.5 grams of protein per kilograms body mass per day
  - Even though they absolutely don’t need it for their limited amount of muscle

***The more active you become and the more healthy you are, the more protein you consume***

- The World Health Organization says 0.8 grams [of protein] per kilogram body mass per day, and maybe you can survive on that,but it’s certainly in Luc’s belief, not optimal
- The recreational athlete already consume between 1.1 and 1.3 grams of protein per kilo body miles per day, and they’re not even trying to consume more protein

***Peter is typically pushing patients to be closer to 1.6 kg [of protein] per kilo per day, and if they’re trying to put muscle on people and their training volume is high, they’re closer to 2 g per kilo***

- Luc agrees, “*It’s great if you can reach that.*”

## Muscle loss with age and inactivity and the importance of resistance exercise to maintain type II muscle fibers [1:17:15]

**Luc’s clinical work in the hospital**

- He [evaluates](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6399806/) protein intake in the elective hip and knee surgery patients
- This is an older population, but they’re not sick
- This is a new generation of patients, because in the past that was associated with a lot of fear, pain
  - These are patients that want to go skiing with their grandchildren again, so they want the new hip or new knee
- They come in, they’re very healthy, but in the 4 days that they’re in the hospital, they’re being delivered is 0.8 grams of protein per kilo of body weight
  - And they consume 0.5, which is ⅓ of the clinical guidelines for the advised amount
  - They lose about 1.4 kg [3 lbs]

**Peter has talked about his extensively on the podcast ‒ how quickly you lose lean mass versus low long it takes to get it back**

- He talks about this a lot in the context of falls that result in fractures because here it’s an even more vulnerable population (for many reasons)
  - Unlike elective hip or knee replacement where patients are generally very healthy and able to get back to PT quickly
  - People who are falling and fracturing the neck of femur and hip, they’re typically not as healthy and they’re much longer to get back to recovery and they’re potentially bedridden for much longer periods of time
  - Oftentimes they never make it back to the level of muscle mass, strength and function prior to
- [Adam Cohen](https://adamcohenmd.com/about-adam-cohen-md-top-orthopedic-doctor-nyc) on this podcast [[episode #264](https://peterattiamd.com/adamcohen/)] mentioned that we talk a lot about the 15% to 30% of people over 65 who will die within a year of a hip fracture
  - What we don’t talk a lot about of the people who don’t die die within a year (the 70% to 85%), 50% of them never regain their same function pre-fall
    - In many ways Peter finds that statistic even more profound

[**Study**](https://pubmed.ncbi.nlm.nih.gov/28329045/) **of hip fracture in elderly women**

- Luc was giving a lecture for a group of older people in the general public and mentioned those numbers (not thinking about what he was saying), and half of the people turned white
  - There were a lot of people who actually broke their hip
- Luc took biopsies from patients coming in with hip fractures after falling, and they compared that muscle with aged matched people that didn’t have a hip fracture (didn’t have a fall), and they compared it with young women
- Most women are the ones with the hip fractures because the men have already passed away

***They saw that the size of the type II fibers were tremendously smaller in the women with the hip fracture than the ones that didn’t have the hip fracture***

- Even though they matched for almost everything, lifestyle
- Peter thinks what interesting there is the causality could be in reverse
  - You could also make a very compelling case that having smaller type II fibers (which means having less power, having less force generating capacity) would make you more susceptible to a fall
- Peter wouldn’t be surprised if there’s a bidirectional association
  - So lower type II muscle fiber size and density, much more predisposition to a fall
  - Once you are inactive, you now experience even greater atrophy of type II muscle fibers,

***Peter argues that atrophy of the type IIA muscle fiber should be described as one of the hallmarks of aging right up there with decreased mitochondrial functioning, increased senescent cells, all of the things we typically think of with aging***

- Luc adds, “*That’s why there is more than maintaining muscle. It’s also especially maintaining the type II fiber size*.”
- What we now often with patients going home earlier (especially with COVID) is when a lot of older people go home, their bed is put downstairs, and those people will never walk stairs anymore
  - So they never recruit the type II fibers anymore
- They might go for walks, but you don’t recruit those type II fibers
  - You need those to stand up from the toilet several times in a row

***You need to have somebody do resistance training with you or walk the stairs. You need to recruit those type II fibers because otherwise it just goes down.***

**Age related muscle loss**

- We now believe that age-related muscle loss is due to short successive periods of reduced physical activity
  - After which they don’t fully regain their muscle
  - It’s a demographic, it’s not a physiological process of a slow decline in muscle
- That adds up in the last 2 decades of life, and that seems to be contributing to the muscle loss that we see in those demographics

**Peter double-clicks on this important point**

- We have looked at all sorts of data, and the decline starts somewhat slowly, and by about the 7th decade, it starts to accelerate
- By the 8th decade (when a person is in their 70s), the decline is so rapid that it appears almost irreversible
- But a minute ago, Luc said something entirely different, which suggests that ***age-related decline is not inevitable and that it is not a continuous slope of decline that reflects some physiologic process within the atrophying muscle, but instead it’s a series of discrete declines, each one precipitated by a period of inactivity***
  - Some of them perhaps deliberate, meaning, “*Hey, I’m going on vacation for a week and I’m just going to sit on the beach and do nothing.*”
  - Some of them forced upon us by injury or illness

*Did Peter get it right? Is that what you basically said?*

- Yes, Luck thinks everybody has that observation

**Think of parents or grandparents that you saw in the last 10 years before they died**

- Everybody will say it started with that urethra infection
- It started with that surgery on the hip, and then you actually have all these little episodes and then you saw that happening
- But this is of course muscle centric, talking about muscle loss
- Of course, if we’re talking about cardiovascular disease and progression, that’s a different story
- But for the muscle loss it’s not something we don’t believe anymore that it’s in an individual
  - There’s not a gradual loss over time because in the individual level it can be completely different
  - The demographic showed this because as we age, there are more people in that situation where they have short successive periods of reduced physical activity
- One of the first peer people to actually publish this was [Douglas Paddon-Jones](https://www.sciencedirect.com/science/article/pii/S0022316623025130?via%3Dihub) (who unfortunately passed away himself at a way too young age), and he called it the “catabolic crisis model”

**When a person becomes sedentary**

- Peter finds it interesting that Luc mentioned that maybe this doesn’t apply to a decline in cardiovascular function

***But Peter would argue that a muscle centric view could potentially be the most important view because when your movement stops, everything else deteriorates with it***

- He would argue that it  has everything to do with heart health or brain health
- When a person becomes sedentary, everything deteriorates in its wake
  - Of course, your cardiovascular system will deteriorate at an accelerated rate
  - We know unequivocally your brain will erode at an accelerated rate when you become inactive
  - We know that the quality of your life, your happiness, your wellbeing will deteriorate as you become inactive
- And so you could make a very compelling case that a muscle centric view might be the most important view
- Luc agrees

**Luc has done** [**bedrest studies**](https://diabetesjournals.org/diabetes/article/65/10/2862/35009/One-Week-of-Bed-Rest-Leads-to-Substantial-Muscle) **in healthy people**

- Healthy young people are often used as a model to see what inactivity does
- Besides that 1.4 kg of muscle loss in 1 week [3 lbs], we also see a massive decline in oxidative capacity and insulin sensitivity
  - If a [leg is immobilized](https://pubmed.ncbi.nlm.nih.gov/37994085/), almost 220 grams of muscle is lost in a week

***All of these markers that we have for cardiovascular metabolic health go down in a single week of inactivity***

- Of course, in one person it might be the cardiovascular decline that is driving the muscle loss while in the other person it’s the muscle loss that’s driving the cardiovascular decline

**The centenarian decathlon**

- This is another idea that we talk a lot about on this podcast
- This idea that the best way to avoid this fate is when you’re in your middle age, when you’re young, whenever, is to be very deliberate and specific about the type of training and of course nutrition that is necessary to have the most physically robust final decade of life (what we call the marginal decade)
  - So if you train with great specificity to be very active and very independent and free of pain and all of those things in the last decade of your life, by definition, you’re going to be doing a lot of varied forms of exercise, and you’re going to have to be supporting that nutritionally to get there

## Differences between whey and casein proteins, and the importance of both quantity and quality of protein sources [1:28:30]

- Peter wants to go back to one last housekeeping issue on the protein side, which was the difference between [whey](https://en.wikipedia.org/wiki/Whey_protein) and [casein](https://en.wikipedia.org/wiki/Casein) protein in identical amounts relative to the parameters Luc discussed (digestibility, speed of digestion and amino acid composition)

**What are the differences and where do you see the use cases clinically between them?**

- The digestibility is the same between micellar casein and whey protein
- But if you compare casein versus whey protein, ***the whey protein is much more rapidly digested and absorbed***
  - You see a greater spike in your essential amino acid concentrations in your blood, including leucine, and you get a greater stimulation of muscle protein synthesis as a result
  - However, the longer you measure, the more the casein catches up in the whey

**Tell us about that** [**study**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10772463/) **that just came out a few weeks ago, which seemed to challenge a lot of the conventional thinking around the amount of usable substrate that one could ingest**

- Traditional thinking had been that it’s awfully hard to use more than 40-50 g protein in a meal for MPS
- Luc’s recent study had 3 groups: 0, 25 g, and 100 g milk concentrate
  - That means it was 80% casein and 20% whey proteins
- This was a [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10772463/) where they used that intrinsic labeled protein combined with intravenous infusions of amino acids, and that allows them not only to measure muscle protein synthesis, but also how much protein is actually released in the circulation from what you ingest
  - They could make a full quantitative assessment of what is happening

*Previous work*

- Previously, most studies were completed during office hours so you have 2 hours of a run-in period, maybe 1 of an intervention, and then 4-6 hours of postprandial (so after a meal) measuring of muscle protein synthesis, and those are long days
- Most of the studies so far show that 20 grams of protein does not do better than 40 grams of protein to stimulate protein synthesis for up to 4-6 hours
  - Because that’s the typical time point measured
  - Why do we always measure 4-6 hours?
    - That’s the time between 2 meals, so that makes sense
- In studies from a lot of other labs, it looks like 40 g [of protein] produced a greater response than 20 g, but it’s not significantly different

*Data from Luc’s lab*

- What Luc’s group saw with the intrinsically labeled protein is that a lot of the protein is not digested yet, or at least not released into circulation
  - So the longer you measure, the more of that protein is released into circulation
- As Luc explained earlier, the casein is catching up to the whey protein because a lot of the casein is not absorbed yet
- [Jorn](https://cris.maastrichtuniversity.nl/en/persons/jorn-trommelen) wanted to have subjects ingest 100 g of protein
  - Which was crazy enough, but he wanted to have more treatments (which were too expensive)

*This* [*study*](https://www.cell.com/cell-reports-medicine/fulltext/S2666-3791(23)00540-2) *just published*

- Tested 0, 25, and 100 g of protein
  - 25 g is what is being advised
  - 100 g is an absolutely impractical amount
- Measured at 4, 8, and 12 hours after ingestion

***What they saw is that if you measure for an extended period of time, that 100 gram is still increasing muscle protein synthesis for a longer period of time resulting in a greater response over time***

![](https://peterattiamd.com/wp-content/uploads/2024/04/f2-lucvanloon.png)

**Figure 2. Use of ingested protein for muscle protein synthesis (green) or oxidation for energy (red)** Image credit: [*Cell Reports Medicine* 2023](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10772463/)

- So the suggestion that you can’t get a greater response with more protein is biased
  - It’s biased because you don’t measure long enough
- Luc explains, “*This is a study that everybody, at least in my field, needed to see to better understand what is happening, but it doesn’t necessarily translate..*.”
- People started asking, “*Should I eat one meal a day?*”
  - No, that’s not what Luc is saying

***Luc thinks it’s good to have a distribution of protein throughout the day, that every meal has an anabolic response, but it doesn’t mean if you have small meals that you’re going to disappear in 3 weeks***

> “*The body adapts and if the body has a huge meal, it’s still being used*.”‒ Luc van Loon

- This makes sense, and as they wrote in the discussion: if you have a snake or a crocodile that once in so many days devours a goat (or a chicken or whatever), then you can actually see that animal actually stuck in the gut for weeks and it’s actually consuming it
  - To some extent, humans can also do that
- It just shows you that there’s no limitation in the response and it can actually range longer than what is previously expected

**Do you think if you did that experiment but instead of using a milk concentrate (which the was majority casein), you used a pure whey isolate, do you believe that you would’ve still seen muscle protein synthesis at the 12 hour mark, or do you think that the rapid digestibility of whey would’ve changed the kinetics significantly and you would’ve been largely done at the four to six hour mark?**

- Luc thinks the difference between the 25 and the 100 grams might’ve been smaller, but it would still be evident because then the duration of the extension is smaller with the whey than with micellar casein
- But the comparison with milk is very small because, milk is still very rapid
  - It’s always funny that people say this is slow or this is fast (it’s all relative, and here’s it’s very fast)

**The work with intrinsically labeled milk is all concentrated proteins, and if you compare it with full meals, you get a completely different picture**

- [Philippe Pinckaers](https://cris.maastrichtuniversity.nl/en/persons/philippe-pinckaers) in Luc’s group [compared](https://www.sciencedirect.com/science/article/pii/S0022316623727235?via%3Dihub) a vegan meal versus a typical Dutch meal (of vegetables, potatoes, and a piece of meat)
- Those 2 plates had exactly the same energy and same amount of protein
- But now we have that digestibility factor in there because we weren’t using powders in a drink
  - The vegan plate was cooked protein, but it has a little bit more fiber
  - The vegan plate is also a little bit bigger because the energy density is smaller

***They saw no measurable anabolic response with the vegan meal and a massive anabolic response (MPS) with the omnivorous meal***

- Luc explains, “*The point is that an omnivorous meal with animal-derived proteins has a greater response when you compare it in the same amount of protein. So quality counts.*”

**What does the kinetics curve for a casein shake look like compared to ground beef or whole steak?**

- That’s similar
- Cooked beef is still very fast
- If you have cooked meat or concentrated protein isolate from an animal source, it’s all very rapidly digested and absorbed with peak amino acid levels 30-75 minutes

***If you have a full meal with potatoes, veggies, fibers in it, it will take 2-3 hours longer***

## Optimizing muscle protein synthesis: exercise, timing of protein intake, protein quality, and more [1:37:00]

**Timing protein intake to maximize muscle protein synthesis**

- Peter always does his strength training in the morning, and many days he runs out of time to eat before he needs to jump into stuff
  - He’s not always diligent about consuming protein right after that workouts
- Consider 2 scenarios:
  - 1 – Consume nothing but water or coffee for 3-4 hours after strength training before having a high protein meal versus
  - 2 – Consume 25 grams of a whey protein shake immediately after exercising then eat a protein-rich meal (40 g) 4 hours later

*Is there a significant difference in muscle protein synthesis between these 2 scenarios, or does it all come out in the wash assuming that you get iso amounts of protein throughout the day?*

- On 24 hours definitely there’s a difference
- For example, if you ingest protein immediately after exercise, for the first 4-5 hours, you definitely have a much greater response because **exercise makes the muscle more sensitive to the anabolic response to food intake**
- However, what people forget is that your response to breakfast the **next day** is still increased and probably also your lunch and dinner the next day

***So if you do an exercise session today and you get all freaked out that you didn’t get a milkshake after your session, don’t worry because the next day all your 3 meals are going to be greater responses because of the exercise***

- Luc has been asked many times, “*How important is the meal before or after the exercise?*”
  - His reply is, if you do a consistent training, then there’s always 3 meals before your session and after your session because you train every day
  - So then every meal is still responding to the previous exercise session

*Is there a benefit of immediately after exercise versus a few hours later?*

- Luc has done that study
- Pre-sleep protein feeding is a topic he’s been working a lot on with patients
- In a [proof of principle study](https://journals.physiology.org/doi/full/10.1152/ajpendo.00325.2016), they had people exercise in the evening and then gave them 40 or 60 g of protein (Luc can’t remember [the study stated 60 g]), and then measured the response the next morning after breakfast (of 20 g protein)
- What Luc was thinking: if there is a window of opportunity, then if you give 60 grams of protein immediately after exercise, maybe you shorten the window of opportunity
  - If you already provided the exercise after the session, you don’t respond as well to the next dinner the next morning

**Peter’s takeaway:** ***if you have 100 units of response in you, the timing of your meal might not impact the total amount of response, it just determines when that response occurs***

- So if you have 25 g of whey protein as you walk out of the gym, you will get more of your 100 units of response then, but you will get less of it 4-5 hours later when you have a big protein lunch

**This fits with what Luc’s learned about glycogen**

- When you ingest carbohydrates immediately after exercise, you expedite glycogen resynthesis
- But if you don’t exercise until 2 days later, it doesn’t make a difference because then you have a full 100% recovery of your glycogen

*This is very different from the way Peter grew up*

- When he grew up as an endurance athlete, the traditional thinking was you need to be mainlining carbohydrates the second you get off the bike (or out of the water or whatever) because you have this very small glycogen window where for an hour you’re going to maximally assimilate
  - And it might be the case that your maximum assimilation would occur in that window, but you will still incorporate carbohydrate into glycogen later, it just might not occur at his higher rate

**Is that kind of the same situation?**

***If you’re exercising every Saturday, it doesn’t make a difference***

- [Louise Burke](https://www.acu.edu.au/research-and-enterprise/our-research-institutes/mary-mackillop-institute-for-health-research/our-people/louise-burke) has clearly [shown](https://journals.physiology.org/doi/abs/10.1152/jappl.1995.78.6.2187) within 24 hours your glycogen goes back to normal
- If you are in the Tour de France and you have to excel every day, you’re going to miss the third day of the tour if you don’t start taking in carbohydrates off the session

**Back to Luc’s study of protein ingestion after an exercise session the evening**

*Does that impact your response to morning?*

- The other [trial](https://journals.physiology.org/doi/full/10.1152/ajpendo.00325.2016) was no protein after the exercise and doing the same thing in the morning
- Luc thought that the response to breakfast will be reduced if you already ingested the 60 grams of protein in the evening ‒ it didn’t
  - The responses to breakfast were exactly the same (to his surprise)

**Net outcome:** ***the people ingested the 60 grams prior to sleep had a benefit in that timeframe, and whether it’s caught up later on at 24, 48 to 72 hours, Luc doesn’t know***

- The studies with infusion of tracers are almost always limited to about 12-24 hours
  - Why? Because you have this turnover of the tissues
  - At some point your tracer will become available from the breakdown, and then you are measuring tracer recycling
    - It’s different techniques, and we go into that with D2O, there’s different techniques to counter that, but if there’s acute tracer infusion studies, you’re limited to 12 to up to 24 hours

***So far long-term training studies basically have shown that protein supplementation can further increase gains in muscle mass and muscle strength (that evidence is there)***

- The evidence becomes smaller when people eat more protein and it gets stronger if you look at people that do not consume enough protein
- They had a black and white [response](https://pubmed.ncbi.nlm.nih.gov/22770932/) to frail elderly: 6 months of training, if we didn’t provide them additional protein, they didn’t gain more muscle

> “*The more frail people are, the more important the amount of protein gets, but it’s also because they’re not consuming a lot*.”‒ Luc van Loon

**If a listener wants to do everything to maximize the odds of optimization and maximization of muscle mass, they’re going to consume 25 g of whey protein following every workout**

- Peter points out, “*We don’t really know over the long term (meaning over months and years) if there is a benefit to consuming a very highly digestible, rapidly absorbed good quality amino acid composition protein in the immediate aftermath following exercise. It sounds like it’s still unclear if there could be a net benefit.*”
- From a caloric intake, it’s irrelevant because it’s 100 calories (less than 5% of your daily intake)
- But it would arguably be the most efficient way to deliver amino acids

*Is there any reason not to do that?*

*Is there any downside of doing that as opposed to going through the hassle of consuming a meal when you finish your training?*

- No, absolutely not
- The only problem Luc has is that if you advocate using protein supplements and stuff like that too much, then people stop thinking about their foods
- People often say, “*Oh, I put a lot of interest in my nutrition in my diet,*” and when asked how they do it, they say, “*Yeah, I take 29 supplements.*”

**Luc’s advice:** ***first think about your nutrition, and if every meal contains good solid foods and with ample, ample protein, if you’re then on top of that, decide that it’s easier, more practical to take protein supplements after training session, be my guest***

> “*But if all the rest is crap, then please do not even consider those whey protein supplements because first think about your nutrition.*”‒ Luc van Loon

- Luc has had a lot of people ask how important it is to take a protein shake before or after a training session, but he has never had someone ask, “*Look, how important is it if I skip one training session or I miss one training session?*”

***Consistent training is the benefit ‒ consistent training so that every meal is a greater impact on your muscle protein synthesis***

- It’s the same question he gets at interviews on the radio and they say, “*Luc, what should we eat in order to lose weight?*”
  - He has only one response, “*It’s less*.”
- It’s easier to drink a whey protein supplement than actually leave the house at 6:00 in the morning and do an extra session of training

## How to preserve muscle while trying to lose weight [1:46:00]

**Strategies to eat less**

- 1 – **Caloric restriction** is the only way that you directly go about eating less
  - Track every macronutrient, every calorie
  - Bodybuilders are shrinking that volume of calories lower and lower to reach an energy imbalance that is sufficient for the amount of fat loss that they’re trying to produce
  - You could argue that this is the most flexible way to go about weight loss because it is agnostic to when you eat or what the actual constitutive elements are of the diet
- 2 – **Dietary restriction**
  - Luc just talked about a vegan diet where you’re taking a lot of things out of the diet, and many of them are energy dense
  - Similarly with a ketogenic diet or something of that nature, you’re going to generally eat a lot less
  - And it’s that effect of the diet on your appetite and food choices that’s going to result in lower energy intake and therefore energy imbalance
- 3 – **Time restriction**, which people call intermittent fasting
  - Here you’re going to make a larger and larger window of non-eating, and by extension, a smaller and smaller window of eating that eventually results in a caloric deficit
- In Peter’s practice, they have historically cautioned people about excessive use of time restriction for people who are **under muscled**
  - Because with calorie restriction comes protein restriction, and with protein restriction comes not just a reduction in mass but a disproportionate loss of lean mass

**Does this resonate with you, all of these trade-offs?**

- Luc fully agrees on that
- #3 time restricted feeding works for people, but it doesn’t work in a scientific setting
  - Studies are coming out on that
  - If you standardize the nutrition (so the caloric content of the diet), you actually see exactly the same fat loss or weight loss with the time-restricted feeding versus the same feeding
    - But then X percent of less caloric intake doesn’t make any difference
  - ***So if you normalize for calories across the course of the day versus in a shrunk window, if it’s the same number of calories, there’s no weight loss***
- For Luc, intermittent feeding (or time restricted feeding) works because he goes to the university, spend most of his day there, has no time to eat running back and forth, and then he comes home, he sits behind a computer doing emails and revisions of manuscripts, and he starts eating way too much and also crap food
  - More than 70% of his food intake energy intake is between 7:00 or 8:00 and 12:00 at night
  - If he does time restricted feeding from say 10 to 6:00, he will lose weight because he wouldn’t have time to eat that amount of calories in that timeframe
- And that’s good for a lot of people because they actually change their homeostasis and for a few weeks they lose a lot of fat mass
  - And then they start eating differently, and then they gain weight again

***So sometimes it’s easy to change your routine and your bad nutritional habits, but the time of feeding is not a metabolic effect to lose more weight***

**What Peter likes to do is try to get around the effect of people losing too much lean mass**

- This is particularly important in women who want to lose weight using a time restricted feeding approach, but who already have an LMI or an FFMI that’s in the bottom 20%
  - LMI and FFMI are two different ways that we measure and quantify lean mass on people
- These are people who are under muscled
- We will say, “*Look, if you want to eat between 2:00 PM and 7:00 PM, that’s your feeding window, you have a 5-hour window to eat*,” so 19 hours of not eating, 5 hours of eating, and we find that it’s very difficult to consume your total amount of protein if we’re trying to get you to 1.6 or 1.8 grams per kilogram in a 5-hour period
  - Because it is mostly women that experience this, but it could be true for anybody
  - Furthermore, you have that 19 hour window where you’re missing one of the major inputs to muscle protein synthesis.
- A workaround is to have 2 shakes that are virtually no calories but are going to give you 50 g of protein
  - A 25 g whey protein shake, mixed with water at 8:00 in the morning and again at 11:00
  - Then at 2:00, you’re going to eat a meal and at 7:00 you’re going to eat a meal
  - So you still get your total amount of protein
  - You’ve sort of cheated on your time restricted feeding because you’ve had 200 calories outside of it
    - But let’s be honest, the purpose of this is caloric restriction, and that 200 is relatively small compared to what you would’ve consumed throughout the day

**Would you take that approach as a better way to tackle 2 simultaneous goals (lose fat mass and preserve or gain lean mass) simultaneously?**

- Luc would completely agree, but he missed one factor (that he’s sure Peter added)
- Of course, the training effect
  - Resistance training
- Old studies show that if you have a caloric restriction, you lose fat-free mass (you lose muscle mass), but if you do twice a week a resistance training session (even in a caloric deficit), you don’t lose muscle mass

***You can prevent the [loss of] muscle mass with simply 2 sessions of resistance type exercise a week (preferably more); so besides that protein, it’s the exercise that makes you respond way more to the same or less amount of protein that you ingest***

Peter asks, “*In the scenario I described… it’s probably not that important where the training session goes within that day at this point.*”

- For many people it’s just convenient to exercise in the morning
- This is why people always ask Luc, “*Should we ingest the protein immediately after or an hour after exercise? Does it make a difference?*”

***No, not really, because every meal following your training session will have a greater response***

- It’s a continuous consistent effect of training to make your response better to the same amount of protein

**And also in the hospital, exercise is essential**

- Simply feeding people more protein because they’re deficient and losing muscle is not the only solution
- Actually, if you make them a little bit more active between meals, every meal has more effect

> “*If we do a little bit of exercise, more of the meal will actually be converted to muscle.*”‒ Luc van Loon

**Using that intrinsic labeled protein, Luc shows that you are what you eat (and the effects of exercise)**

- In fact, you are what you just ate
- If you eat that same protein after you’ve done a little exercise, more of that protein is converted to muscle
  - So if you’re physically active, you are more of what you just ate

***Now, every athlete is using this, and every coach knows this, but we hardly use it in medical care***

**With physical inactivity, you become anabolically resistant**

- If you become physically less active, you are less of what you just ate
- The problem is when you become sick or ill, or you get surgery, you have 2 issues
  - 1 – You exercise less (or you become less physically active)
  - 2 – You also eat less, so it’s a double whammy downwards
  - And that’s what makes someone so susceptible and vulnerable to a short period of inactivity or sickness

## Anabolic resistance and overcoming it with physical activity [1:55:45]

- With with insulin resistance, we can actually explain mechanistically what’s happening
- [Jerry Shulman](https://medicine.yale.edu/profile/gerald-shulman/) provided a very, very elegant explanation of what’s happening intracellularly, what the triglyceride or diglyceride is doing in the cell and how it’s impeding the signal transduction to move the GLUT4 transporter up to the translocated site to bring more glucose in, etc. [in [episode #140](https://peterattiamd.com/geraldshulman/)]
- Luc hasn’t followed that discussion
- It’s still a discussion of which fatty acid intermediate is actually causing the whole signaling
  - Is it the storage of fat?
  - Is it the inflammation that you get from storage of fat?
  - Is it diacylglycerol?
  - Is it the ceramides, the fatty acetyl-CoA?
- It’s at least the inability to process that fat in the muscle that is inducing the insulin resistance

**Do we have the same level of detail around what is actually inducing anabolic resistance?**

- That’s the million-dollar question
- The first time that term anabolic resistance was coined, it was published in 2005 by the people in Dundee, the late [Mike Rennie](https://ajcn.nutrition.org/article/S0002-9165(22)02538-2/pdf)
- Mike did a [study](https://pubmed.ncbi.nlm.nih.gov/15596483/) where he provided essential amino acids to people (young and elderly), and when they provided a greater amount of essential amino acids, you saw in the *young people* a greater muscle protein synthetic response
  - As we discussed before it got the greatest response, the highest muscle protein synthesis following the provision of 10 grams of essential amino acids
    - Which is perfect because 10 grams of essential amino acid translates to about 20 grams of protein
    - So it nicely fits with those other studies
- If he gave 20 grams of essential amino acids, there was no significant further increase over the next few hours
- That was normal response and in line with everything that we discussed before
- If he did the same thing with the *older population*, he saw that that increase in muscle protein synthesis was less steep and also leveled off more rapidly

**It took Luc’s lab almost 10 years to verify or confirm those data**

- Because they wanted to show the same thing with a less lab-based approach, with that 20 grams of intrinsically labeled protein
- And when they finally managed to do that [study](https://www.sciencedirect.com/science/article/pii/S0002916523020828?via%3Dihub) over a long period of time, they saw that basal protein synthesis is *not different* between young and elderly

***If they’re relatively active, basal protein synthesis is actually higher in elderly than a young (if there’s actually a difference), but the response to the 20 grams of protein is less in the older population***

- So the same amount of protein that was ingested did not lead to the same amount of protein synthesis
- And with the intrinsic labeled protein, they could show that less of the ingested protein was converted to muscle
  - That is also anabolic resistance in a more single meal like type of approach

**The big question is what is causing anabolic resistance?**

- That could be digestion
- This could be absorption
- This could be what is called [splanchnic](https://en.wikipedia.org/wiki/Splanchnic) sequestration (what happens between taking up amino acids in the gut and releasing them into circulation)
  - Splanchnic sequestration generally means they don’t know what they’re talking about
  - It simply means we don’t know to what extent the amino acids that were actually going to the portal vein are actually being absorbed in the intestinal tissues and not being released in the circulation
  - Where are the amino acids?
    - Are they still in the intestine?
    - Are they taken to other tissues in between the portal vein, like the lymphatic system?
    - We don’t know exactly
- Regarding release into circulation, insulin plays a role because if there’s not enough insulin, and insulin is not stimulatory but permissive
- How much of the tissues are being perfunded so they get blood
  - Because if the blood doesn’t perfuse the muscle, those free amino acids are never going to be seen by the muscle
- Then we have the uptake in the muscle, and then you have those signaling responses (the mTOR pathway in the muscle)

***On all these levels, anabolic resistance can reside, so it’s impossible to find it. A lot of people are focusing on all these different areas.***

**The problem with every study where we compare young and older people (to look at aging)**

- We don’t follow the same person for 40-50 years, because that takes too long
- That’s why we use animal or model organisms like *C. elegans* or whatever

***If we compare young and old, we’re not comparing the same person. We’re actually comparing lifestyle, comorbidity, pharmacological interventions that they have, food intake, all of these things.***

**The role of physical activity**

- Luc just said that physical activity makes the muscle more sensitive to the anabolic properties of amino acids

*Does it make perfect sense to say that less physical activity makes the muscle less sensitive to amino acids?*

- The only way to study this is to immobilize young people
- Luc’s [study](https://pubmed.ncbi.nlm.nih.gov/37994085/) put one leg in the cast for a week
  - If you didn’t believe the story about 1-2% turnover of muscle, you know because even after a week when the cast comes off, you don’t need an MRI scan to see which leg had been in the cast because you actually see the loss of muscle in that leg

**Have you been able to study this longitudinally in a mouse, for example?**

- No, Luc only does human studies *in vivo*
- He does some animal work with collaborators

*Is anybody studying this?*

- Peter thinks Luc raises a good point, which is without a longitudinal assessment (which would not be possible in humans), we really are stuck without understanding the nuances
- In humans, you can do a crossover between active and inactive,a nd that might provide an answer to the question
- As Peter listens to this list of differences in absorption, circulation, the splanchnic sequestration ‒ he’s never considered that
  - The perfusion-related makes total sense, uptake in the muscle, lower mTOR activity
    - We know mTOR activity is lower in the elderly
  - Peter thinks it could be any of the above
- Peter points out, “*At the end of the day, we know what you need to do. Control what you can control, be more active, consume more protein.*”

**Back to Luc’s** [**study**](https://pubmed.ncbi.nlm.nih.gov/37994085/)

- If they take that previously immobilized leg and give that person an amount of protein, they see a 35% difference between the leg that was previously immobilized and the leg that was not immobilized

***There’s a 35% anabolic resistance after one week of inactivity. That is much more than we see as a difference between the young and the older.***

- Within 1 week of inactivity, you can make a young leg or a young muscle respond completely like a senescent muscle

**Luc’s studies in older people**

- If he takes an older person and has them do some exercise and gives them protein, he sees a completely normal response
- If he takes a biopsy of an older person,he sees  smaller type II fibers
- If he trains that person for 3 months, the type II fiber is bigger than the type I fiber, and he doesn’t see any difference in the response to a younger person
- He can say the same thing about [satellite cells](https://en.wikipedia.org/wiki/Myosatellite_cell)
- Muscle itself actually doesn’t seem to get that old
  - It actually still responds completely normally, and he can normalize for age by physical activity

*Peter points out that these 2 examples completely change the discussion*

**Peter’s takeaway**

- Luc took a group of young healthy people, presumably who have lots of anabolic capacity, and put them in a cast for a week
- He immediately demonstrated upon removing the cast that the leg that has been immobile for a week is 35% less responsive to protein assimilation than the other leg
  - That’s an anabolic resistance factor of 35%
    - Which he also pointed out is far greater than what you see in an aged individual
- The other thing he said was you can take an aged individual who might have 20 or 30% less anabolic response to protein than a young person, but if you exercise them, you can bring them up to the same level as a younger person

***These 2 factors suggest that activity might be the main determinant of anabolic resistance, and an aging individual or age within an individual is simply a proxy for activity***

- Luc points out that it’s more difficult for older people to do the same training loads, but the muscle itself is still responsive

> “*The good news is you don’t have to start exercising when you’re 40 to actually have good muscle when you’re 80. You can still do it at 70*.”‒ Luc van Loon

- Now it’s better to do it at 40 as well, but at any age, and that’s also 100+, the muscle is still very responsive to physical activity
- It has nothing to do with **hormones**, and that is also something that Luc gets so fed up with

## Importance of protein intake and physical activity in hospitalized patients [2:06:30]

**Luc just finished a** [**study**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10505531/) **with prostate cancer patients**

- Now, you know what happens when they get [androgen deprivation therapy (ADT)](https://en.wikipedia.org/wiki/Androgen_deprivation_therapy)?
  - They lose a lot of muscle mass, they gain a lot of fat mass, they have an increased risk of becoming diabetic, developing cardiovascular disease
  - Besides the effects that they become a little bit lethargic
- They did training with them, resistance training, 2-3 times a week, and the ADT had no effect on the muscle mass
  - They actually gained muscle mass despite the fact that they had no testosterone
    - They were basically chemically castrated
  - Resistance training 2-3 times per week increased muscle mass, increased muscle strength, and attenuated fat mass gain
- Luc explains, “*It’s that easy. It’s ridiculous that people go on ADT and are not immediately getting resistance training in addition to it because it prevents all the negative side effects*.”

**This is a point that Peter thinks is really frustrating and difficult to hear, there’s such a disconnect in medicine when it comes from doing really wonderful things to then missing the boat on the support system that’s needed**

- Peter hopes there are people out there in a position to do something about this
- It makes sense to put a man on androgen deprivation therapy if he has a metastatic or inoperable high-grade prostate cancer
  - Peter has seen many of these men and they are miserable because they’re losing lots of muscle mass, they’re gaining lots of fat, and they’re becoming metabolically profoundly unhealthy
- You would think that for every oncologist that puts a patient, or every urologist who manages a patient through androgen deprivation therapy, it should be as important that prescribed alongside that androgen deprivation therapy is a resistance training program and a proper diet around high protein intake

***Peter would recommend resistance training 4-5 times a week as that is the most potent thing you have to counterbalance ADT***

**Improving protein intake of hospitalized patients is an easy intervention**

*The other example Luc gave is sedentary hospitalized patients who are basically being protein restricted*

- We talk so much in the United States about the cost of healthcare and the burden of healthcare and the burden of the sick individual
  - How so many dollars of a person’s healthcare allotment are spent at the end of life when the quality is so low
  - And yet the system itself is broken in that it doesn’t even understand the basic fundamentals of exercise and nutrition
- Peter adds, “*This is what I think gives much of the population a total lack of trust in the medical establishment. Because they see, you guys don’t know about exercise and nutrition, so why should I believe you on these other things where you actually do have an authority?*”
  - It seems like this has been accelerated over the past few years, and COVID clearly didn’t help

***There’s something even deeper than that, which is just a general belief that the medical system doesn’t communicate through a strong position of knowledge when it comes to the real way to use exercise and nutrition as medical interventions***

> “*I think everybody knows that lifestyle is important, but they sometimes just do not realize how relatively easy it is to do it.*”‒ Luc van Loon

- Luc suggests that we should have scientists and clinicians talk more
- It’s changing, but it’s going very slow

**Providing hospitalized patients protein in the evening is one way to boost their protein intake and minimize muscle loss**

- When you’re in the hospital, you get your last meal around 5-6 o’clock (if you’re lucky), and then breakfast the next morning is around 8-9 o’clock
  - You’ve spent 15 hours fasting when you’re at risk of losing muscle
- That’s stupid
- Not a single athlete in the world will do that

*Luc wondered if you provide protein prior to sleep, does your gut actually process it while you sleep*

- The elderly subjects he works with ar amazing
  - They even call him looking to participate in a study
- For this [study](https://journals.physiology.org/doi/full/10.1152/ajpendo.00321.2011), they take a muscle biopsy, then put a nasogastric tube down the nose and into the gut
  - Subjects sleep in the hospital overnight
  - At 2:00 am they push 40 grams of pre-heated intrinsic-labeled protein into their gut (without them waking up)
  - In the morning, they do another muscle biopsy

*What happens if while they’re sleeping, you provide the protein in the gut?*

***It’s rapidly digested and absorbed just as easily as in the morning (so there’s no restriction there), and they actually synthesize muscle protein at night***

- The next morning they saw that the protein was incorporated in the muscle
- When Luc published that study, he got phone calls from coaches all over the world asking him where they could buy those nasogastric tubes
- He had to explain, “*This is a proof of principle study to show you that the gut functions while we sleep, but if you want to do something, just give people a protein-rich snack between dinner and going to bed because that will expedite reconditioning, help you with your recovery from training. And more importantly, it might help older people or people in the hospital to attenuate muscle loss while in the hospital.*”

**The second part is you can actually start doing that with a small protein snack in the evening**

*Does it actually work in the hospital?*

- Because if you provide a protein-rich snack, do people still eat the same the next morning?
- Luc just wanted to have people bring around cheese cubes in the evening in the hospital and see how it affected 24-hour food intake in patients [[2024 study](https://www.sciencedirect.com/science/article/pii/S0261561424000906)]
- It went up by 20%
- So that is stuff that we don’t even manage with supplements because people don’t eat them
  - They get a supplement with the meal; it’s just thrown away

***So bring people a nice protein-rich snack in the evening, they increase protein intake by 20% (it’s that easy)***

## Reviewing the efficacy of collagen supplements [2:13:30]

- People ask Peter all the time if they should be consuming collagen supplements
- He doesn’t know and thinks they are better off consuming high quality protein that has a balance of all the amino acids

**What is collagen, and is there a unique benefit to consuming it as a supplement?**

- [Collagen](https://en.wikipedia.org/wiki/Collagen) is a protein that is pretty prevalent in your body because it’s the main protein that is a structural protein
- Collagen is in your cartilage, your bone, your tendons, your ligaments, and it’s also in muscle (in very small amounts, relatively)
- It’s important to transfer the force of your muscle towards your tendons
  - So even in the muscle, all of your contractile proteins need to be linked to collagen or connective tissue proteins in order to transfer the force
- A lot of people ingest collagen supplements because it helps you with strength force, skin, bone, ligaments and stuff like that
- Luc is interested in it because it’s a very nice source of [glycine](https://en.wikipedia.org/wiki/Glycine) and [proline](https://en.wikipedia.org/wiki/Proline)
  - About 50% of your collagen is glycine and proline
    - So it’s a poor protein from a total perspective
    - It’s not as balanced as an animal derived meat protein or a milk protein, but it contains a lot of glycine and proline.

***What you could say is that your ligaments, your cartilage, your bone also contains a lot of glycine and proline, and so collagen is a good source of these two amino acids***

- The story makes sense, but it’s a little bit like if you eat something that you need, it’s going to be better for you

*But the question is, do we already get enough glycine and proline in our diets and is additional via collagen of additional value?*

- Now, that is something that we don’t know
- Luc’s team has been starting to look at this
  - Ingesting collagen and whey protein after exercise, and then we look at myofibrillar protein synthesis, but also muscle connective protein synthesis
- [Exercise stimulates](https://journals.humankinetics.com/view/journals/ijsnem/31/3/article-p217.xml) both myofibrillar as well as muscle connective protein synthesis
- So the adaptive response in muscle is both connective proteins as well as myofibrillar proteins
- Now, if you ingest protein, it further increases the response to exercise and you see *greater* myofibrillar protein synthesis
- However, the ingestion of dairy protein or protein does *not* seem to increase muscle connective protein synthesis rates
- For at least for up to 6 hours after exercise, your contractile muscle responds to protein in addition to exercise, but your muscle connective tissue does not

***We’ve*** [***tried***](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10487367/) ***that also with collagen, but*** **w*****e do not see a greater increase in connective tissue protein synthesis rates in muscle following collagen supplementation***

- So either it is not happening in the first 5 hours and the exercise is already a stimulus enough and the response is later on, or there’s enough glycine and proline in dairy protein

**How much protein synthesis are you seeing in the muscle connective tissue response to dairy?**

- It pales in comparison to the exercise
- There is no significant increase in muscle connective protein synthesis *in addition* to the **exercise effect**

*Have you done this activity or this experiment without exercise?*

- Yes, they’ve also done it without exercise and it does not seem to be responsive to nutrition
- There is one exception, we saw it in the [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10772463/) by Jorn that used 100 grams of protein
  - This was a study over a longer period of time, but that was exercise as well

**Peter’s takeaway:** ***It seems that based on those data, there is no benefit in both myofibrillar or muscle connective tissue protein synthesis using collagen versus using whey or casein***

- The data would say that for an exercising person, the idea of taking collagen protein to help increase the strength of connective tissue is *not correct*
  - Over 5 hours

**Luc still holds an option open for ligaments, tendons, bone, cartilage**

- Because when he looks at muscle connective protein, the fraction that we actually take out of the muscle contains only a few percent of collagen
  - The muscle doesn’t contain a lot of collagen

*The question is, is it not more important for tendons, ligaments, bone, and cartilage?*

- Luc wouldn’t say it’s not working there
- As a scientist, he hasn’t seen evidence that it leads to greater connective tissue protein synthesis rates
- But if Luc were to break his hip (or have a major issue with his knee) and he’s recovering and rehabilitating, he would take both a protein supplement and a little bit of collagen to be sure he gets enough glycine and proline

- Peter points out, “*The other point to consider is if there are people listening to this who are just using collagen as their supplemental protein source, they’re undoubtedly compromising myofibrillar muscle protein synthesis because as you said, they’re basically just getting a lot of proline and glycine, and they’re probably really missing out on leucine, lysine, methionine, and the other amino acids that are far more potent.*”
- Luc agrees that collagen is a very low quality protein from the perspective of amino acid balance
  - But it’s a nice source of glycine and proline
- But if you take in enough protein, there is probably already sufficient glycine and proline in your diet

***However, if you have major issues with ligaments, tendons, or other almost purely collagen-based structures, it [a collagen supplement] might be a benefit… That is something that we still want to look at for the next few years***

## Plant-based diets: how to ensure a balance of amino acids, and other considerations [2:20:30]

- Earlier Luc mentioned that 2-3 grams of [leucine](https://en.wikipedia.org/wiki/Leucine) in a meal will kick muscle protein synthesis into overdrive

**Do you have any other rules of thumb around specific amino acids?**

- One of the things Peter tries to talk to patients about (especially patients who are plant-based), is rather than just have them worry about the different bioavailability of this protein versus that protein is just focus on how much leucine, [lysine](https://en.wikipedia.org/wiki/Lysine), [methionine](https://en.wikipedia.org/wiki/Methionine) they’re getting across the course of a day or even in the course of a meal
- Luc explains, “*many of the plant-derived proteins are low in lysine and/or methionine.*”
- If you eat a lot of meat alternatives, often these meat alternatives lack or have a low amount of lysine or methionine, so a lot of these projects are spiked or **fortified** with those individual amino acids
- However, if you eat a **well-balanced meal**, you typically have different plant-based proteins in your meal that often compensate for low lysine or low methionine
  - For example, one protein has high lysine and the other one has relatively high methionine, so they compensate
  - That’s why also your mom would say, have a diet that is balanced with a lot of different sources
    - Then the problems become smaller, and you don’t have to expect huge issues
- Luc explains, “*You can compensate for lesser quality by greater quantity*”

**The confusion with** [***The Game Changers*** **documentary**](https://en.wikipedia.org/wiki/The_Game_Changers)

- If you have a huge football player and he’s consuming a massive amount of foods, it doesn’t matter where the protein comes from
  - Because simply by the mass of protein, he or she already compensates for lesser quality by the large amount of protein

*They hype is also here*

- Luc was asked by somebody in the hospital if they should only get plant-based foods for their patients
- His thought was, “*Oh, no, because quality becomes important when you actually have a low quantity of food.*”

***For people that eat less (due to cancer or pain), don’t give them a high plant-based food diet***

- It sounds like you’re doing a good thing, but you’re not helping them at that stage in life
- The most vulnerable people, the smallest people, the people eating the least, the people who are in this case greatest at risk for loss of lean mass, need to disproportionately focus on the highest quality sources of protein

**A plant-based diet means well**

- But this is where communication between clinical care and science [often breaks down]

***A plant-based diet is healthier if you’re over-consuming energy***

- If you need a more plant-based diet to allow you to eat less energy, become less overweight
- But that doesn’t necessarily mean it’s good for everybody

## Future research: understanding protein metabolism in the brain [2:23:45]

**Over the next 12-24 months, what is the single most interesting question you would like to explore in your lab?**

- Luc doesn’t think he’s going to answer it in a year
- His group measured protein synthesis in brain tissue in humans
  - In people that have severe epilepsy, they get surgery in the brain, so the skull is lifted
  - These people were great; they actually wanted to participate in research
- They infused labeled amino acid tracer and actually got part of their neocortex
- They measured the synthesis rate of these amino acids incorporation in the human brain throughout surgery
- The turnover rate of the human brain is almost three times as high as muscle, and of course, there are slowly-turning proteins and fast-turning proteins in your brain

***Generically on an average level, you can actually translate that into: you have a new brain in about 3 weeks***

**Why do you still think you’re you?**

- That’s an interesting question

Peter asks, “*Do all amino acids cross the blood-brain barrier?*”

- Luc thinks so, but there might be differences on the large neutral amino acid transporters basically for all amino acids

*Do you have any sense of which amino acids are disproportionately used by the cortex?*

- No, and Luc is not a brain physiologist
- They [published](https://pubmed.ncbi.nlm.nih.gov/29432531/) this work in the brain, about amino acid composition 2 years ago
  - The brain was not that much different from muscle
  - But the turnover of your brain and plasticity (just like the liver) [was much greater]
- They are now looking at tumors

![](https://peterattiamd.com/wp-content/uploads/2024/04/f3-lucvanloon.png)

**Figure 3. Protein synthesis rates in muscle and brain**. Image credit: [*Brain* 2018](https://pubmed.ncbi.nlm.nih.gov/29432531/)

***Everything [in the brain] is growing and breaking down at an immense rate, and you don’t notice it***

> “*The amino acids in your brain now might be in your toe tomorrow morning. How does the body do this and how do all these organs communicate? It’s really amazing.*”‒ Luc van Loon

§

## Selected Links / Related Material

**Previous episode of** ***The Drive*** **with Gerald Shulman**: [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) (December 7, 2020) | [12:15]

**Blocking lipolysis in adipose tissue allows diabetics to use intramyocellular lipids**: [Inhibition of adipose tissue lipolysis increases intramuscular lipid use in type 2 diabetic patients](https://pubmed.ncbi.nlm.nih.gov/16096823/) | *Diabetologia* (L van Loon et al 2005) | [18:15]

**Effects of raw eggs compared to boiled eggs on post-exercise MPS**: [Raw Eggs To Support Postexercise Recovery in Healthy Young Men: Did Rocky Get It Right or Wrong?](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9644172/) | *The Journal of Nutrition* (C Fuchs et al 2022) | [1:01:30]

**Differences in MPS after eating steak versus ground beef**: [Minced beef is more rapidly digested and absorbed than beef steak, resulting in greater postprandial protein retention in older men](https://www.sciencedirect.com/science/article/pii/S0002916523051407?via%3Dihub) | *The American Journal of Clinical Nutrition* (B Pennings et al 2013) | [1:02:15]

**Differences in whey and casein protein**: [Whey protein stimulates postprandial muscle protein accretion more effectively than do casein and casein hydrolysate in older men](https://www.sciencedirect.com/science/article/pii/S000291652302275X?via%3Dihub) | *The American Journal of Clinical Nutrition* (P Bart et al 2011) | [1:03:30]

**Protein intake of healthy older people in the hospital**: [Protein Intake Falls below 0.6 g·kg-1·d-1 in Healthy, Older Patients Admitted for Elective Hip or Knee Arthroplasty](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6399806/) | *Journal of Nutrition, Health & Aging* (M Weijzen et al 2019) | [1:17:30]

**Previous episode of** ***The Drive*** **with Adam Cohen**: [#264 ‒ Hip, knee, ankle, and foot: diagnosis, treatment, and surgery of the lower extremities | Adam Cohen, M.D](https://peterattiamd.com/adamcohen/). (July 31, 2023) | [1:19:30]

**Loss of type II muscle fibers in elderly women with hip fracture**: [Extensive Type II Muscle Fiber Atrophy in Elderly Female Hip Fracture Patients](https://pubmed.ncbi.nlm.nih.gov/28329045/) | *The Journals of Gerontology Series A* (I Kramer et al 2017) | [1:20:00]

**Bed rest and muscle loss**: [One Week of Bed Rest Leads to Substantial Muscle Atrophy and Induces Whole-Body Insulin Resistance in the Absence of Skeletal Muscle Lipid Accumulation](https://diabetesjournals.org/diabetes/article/65/10/2862/35009/One-Week-of-Bed-Rest-Leads-to-Substantial-Muscle) | *Diabetes* (M Dirk 2016) | [1:20:00]

**Single leg immobilization and muscle loss**: [One Week of Single-Leg Immobilization Lowers Muscle Connective Protein Synthesis Rates in Healthy, Young Adults](https://pubmed.ncbi.nlm.nih.gov/37994085/) | *Medicine and Science in Sports and Exercise* (A Holwdera et al 2024) | [1:27:15, 2:02:30]

**Study finds no upper limit on use of ingested protein for protein synthesis**: [The anabolic response to protein ingestion during recovery from exercise has no upper limit in magnitude and duration *in vivo* in humans](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10772463/) | *Cell Reports Medicine* (J Trommelen et al 2023) [1:30:30]

**A vegan meal compared to a typical meal**: [Higher Muscle Protein Synthesis Rates Following Ingestion of an Omnivorous Meal Compared with an Isocaloric and Isonitrogenous Vegan Meal in Healthy, Older Adults](https://www.sciencedirect.com/science/article/pii/S0022316623727235?via%3Dihub) | *The Journal of Nutrition* (P Pinckaers et al 2023) | [1:34:45]

**Consuming protein in the evening does not limit response to protein eaten the next morning**: [Presleep protein ingestion does not compromise the muscle protein synthetic response to protein ingested the following morning](https://journals.physiology.org/doi/full/10.1152/ajpendo.00325.2016) | *American Journal of Physiology Endocrinology and Metabolism* (B Wall et al 2016) | [1:39:15]

**No protein after exercise and response to protein eaten the next morning**: [Presleep protein ingestion does not compromise the muscle protein synthetic response to protein ingested the following morning](https://journals.physiology.org/doi/full/10.1152/ajpendo.00325.2016) | *American Journal of Physiology Endocrinology and Metabolism* (B Wall et al 2016) | [1:41:15]

**Increase in muscle mass of frail elderly in response to resistance exercise requires protein supplementation**: [Protein supplementation increases muscle mass gain during prolonged resistance-type exercise training in frail elderly people: a randomized, double-blind, placebo-controlled trial](https://pubmed.ncbi.nlm.nih.gov/22770932/) | *Journal of the American Medical Directors Association* (M Tieland et al 2012) | [1:43:00]

**Anabolic resistance in elderly**: [Anabolic signaling deficits underlie amino acid resistance of wasting, aging muscle](https://pubmed.ncbi.nlm.nih.gov/15596483/) | *FASEB* (D Cuthbertson et al 2005) | [1:57:00]

**Basal protein synthesis is not different in young and elderly**: [Exercising before protein intake allows for greater use of dietary protein–derived amino acids for de novo muscle protein synthesis in both young and elderly men](https://www.sciencedirect.com/science/article/pii/S0002916523020828?via%3Dihub) | *The American Journal of Clinical Nutrition* (P Bart et al 2011) | [1:58:30]

**Prostate cancer patients on ADT can increases muscle mass with strength training**: [2:06:15]

- [Resistance Exercise Counteracts the Impact of Androgen Deprivation Therapy on Muscle Characteristics in Cancer Patients](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10505531/) | *The Journal of Clinical Endocrinology & Metabolism* (M Overkamp et al 2023)
- [Resistance Exercise Training Increases Muscle Mass and Strength in Prostate Cancer Patients on Androgen Deprivation Therapy](https://journals.lww.com/acsm-msse/fulltext/2023/04000/resistance_exercise_training_increases_muscle_mass.2.aspx) | *Medicine & Science in Sports & Exercise* (H Lisanne et al 2023)

**The gut processes protein at night and uses it for MPS**: [2:11:00]

- [Intragastric protein administration stimulates overnight muscle protein synthesis in elderly men](https://journals.physiology.org/doi/full/10.1152/ajpendo.00321.2011) | *The American Journal of Physiology Endocrinology & Metabolism* (B Groen et al 2012)
- [Protein Ingestion before Sleep Increases Overnight Muscle Protein Synthesis Rates in Healthy Older Men: A Randomized Controlled Trial](https://www.sciencedirect.com/science/article/pii/S0022316622106322?via%3Dihub) | *The Journal of Nutrition* (W Kouw Imre et al 2017)

**Cheese snack in the evening increases protein intake in hospitalized patients**: [Access to a pre-sleep protein snack increases daily energy and protein intake in surgical hospitalized patients](https://www.sciencedirect.com/science/article/pii/S0261561424000906) | *Clinical Nutrition* (M Weijzen et al 2024)  | [2:13:00]

**Exercise plus protein stimulates MPS in connective tissue**: [Exercise Plus Presleep Protein Ingestion Increases Overnight Muscle Connective Tissue Protein Synthesis Rates in Healthy Older Men](https://journals.humankinetics.com/view/journals/ijsnem/31/3/article-p217.xml) | *International Journal of Sport Nutrition and Exercise Metabolism* (A Holwerda et al 2021) | [2:16:00]

**Collagen protein supplementation does not increase protein synthesis in connective tissue**: [Collagen Protein Ingestion during Recovery from Exercise Does Not Increase Muscle Connective Protein Synthesis Rates](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10487367/) | *Medicine & Science in Sports & Exercise* (T Aussieker et al 2023) | [2:17:45]

**Protein turnover in the brain is much higher than in muscle**: [Brain tissue plasticity: protein synthesis rates of the human brain](https://pubmed.ncbi.nlm.nih.gov/29432531/) | *Brain* (J Smeets et al 2018) | [2:25:15]

**Review on nutritional strategies to maximize MPS in response to exercise**: [Eat like an athlete: insights of sports nutrition science to support active aging in healthy older adults](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8599603/) | *GeroScience* (S Oikawa et al 2021)

**Elderly maintain the ability to make gains in muscle mass and strength with strength training**: [Muscle Mass and Strength Gains Following Resistance Exercise Training in Older Adults 65–75 Years and Older Adults Above 85 Years](https://journals.humankinetics.com/view/journals/ijsnem/34/1/article-p11.xml) | *Human Kinetics Journals* (G Marzuca-Nassr et al 2023)

§

## People Mentioned

- [Jack Wilmore](https://education.utexas.edu/profile/jack-h-wilmore/) (1938-2014, Distinguished Professor and Professor Emeritus of Kinesiology and Health Education at The University of Texas at Austin) [4:15]
- [Mark Hargreaves](https://findanexpert.unimelb.edu.au/profile/15778-mark-hargreaves) (Professor of Exercise Physiology and Metabolism at The University of Melbourne) [4:30]
- [Gerald Shulman](https://medicine.yale.edu/profile/gerald-shulman/) (Professor of Medicine and Cellular & Molecular Physiology at Yale, expert in type 2 diabetes) [12:15]
- [Hans Hoppeler](https://journals.biologists.com/jeb/article/216/24/4499/11826/A-life-in-science-a-celebration-of-the-career-of) (was a Emeritus Professor of Anatomy at University of Bern, Switzerland) [14:30]
- [Jorn Trommelen](https://cris.maastrichtuniversity.nl/en/persons/jorn-trommelen) (Faculty in Health, Medicine, & Life Sciences at Maastricht University, the Netherlands) [54:15]
- [Yves Boirie](https://www.researchgate.net/profile/Yves-Boirie) (Professor of Human Nutrition at the University Clermont Auvergne Clermont-Ferrant, France) [56:00]
- [Adam Cohen](https://adamcohenmd.com/about-adam-cohen-md-top-orthopedic-doctor-nyc) (Orthopedic surgeon with expertise in the shoulder, elbow, hip, inee, and ankle) [1:19:30]
- [Douglas Paddon-Jones](https://www.sciencedirect.com/science/article/pii/S0022316623025130?via%3Dihub) (1969-2021, leader in recognizing the importance of muscle health for optimizing health span who proposed a protein threshold of 30 g protein/meal) [1:25:45]
- [Philippe Pinckaers](https://cris.maastrichtuniversity.nl/en/persons/philippe-pinckaers) (Faculty in Health, Medicine, & Life Sciences at Maastricht University, the Netherlands) [1:34:45]
- [Louise Burke](https://www.acu.edu.au/research-and-enterprise/our-research-institutes/mary-mackillop-institute-for-health-research/our-people/louise-burke) (Professor of Exercise and Nutrition at the Mary MacKillop Institute of Health Research at Australian Catholic University in Melbourne) [1:41:15]
- [Gerald (Jerry) Shulman](https://medicine.yale.edu/profile/gerald-shulman/) (Professor of Medicine and Cellular & Molecular Physiology at Yale and expert in type 2 diabetes) [1:55:45]
- [Michael Rennie](https://ajcn.nutrition.org/article/S0002-9165(22)02538-2/pdf) (1946-2017, was a Professor of Life Sciences at the University of Dundee, Scotland and an expert in protein metabolism in human muscle) [1:57:00]

§

![](https://peterattiamd.com/wp-content/uploads/2024/04/bio-lucvanloon.png)

##### Luc van Loon, Ph.D.

Luc van Loon studied movement sciences at Maastricht University in the Netherlands, after which he completed an internship at the University of Texas at Austin in the Department of Kinesiology and Health Education. He then earned his Ph.D. in the Department of Human Biology at Maastricht University, where he studied the effects of exercise and nutrition on muscle fuel selection. Next, he completed post-doctoral research at both Maastricht University and Deakin University in Melbourne, Australia. Currently, Dr. van Loon is a Professor of Physiology of Exercise and Nutrition in the Department of Human Biology and head of the [M3-research group](https://www.m3-research.nl/) at Maastricht University Medical Centre. The objective of his research is to gain insight in the benefits of more physical activity and exercise training on health and performance, and the impact of nutrition on the skeletal muscle adaptive response to exercise training.

Dr. van Loon has expertise in the area of skeletal muscle metabolism and has published over 500 peer-reviewed articles. Current research in his laboratory focuses on the skeletal muscle adaptive response to physical (in)activity, and the impact of nutritional and pharmacological interventions to modulate metabolism in both health and disease. The latter are investigated on a whole-body, tissue, and cellular level, with skeletal muscle as the main tissue of interest. To support the use of stable isotopes in biomedical research, Luc is also scientific coordinator of the Stable Isotope Research Centre (SIRC) at Maastricht University Medical Centre+. [[Maastricht University](https://www.maastrichtuniversity.nl/ljc-van-loon)]