# #104 – COVID-19 for kids with Olivia Attia

**Source:** [https://peterattiamd.com/covid-19-for-kids/](https://peterattiamd.com/covid-19-for-kids/)

---

In this episode, Peter sits down with his daughter to answer questions from her and other kids about COVID-19.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/covid-19-for-kids/the_Drive_public.png)

Play

#104 - COVID-19 for kids with Olivia Attia

1x15s30s

0:0034:16

## We discuss:

- What is a virus? [1:45];
- How did this version of coronavirus (SARS-CoV-2) start? [4:30];
- How does COVID-19 compare to SARS and MERS (previous coronaviruses)? [6:00];
- Will COVID-19 come back again after we resolve the current issue? [7:15];
- When will kids go back to school? [7:45];
- How has the US surpassed China in total cases, and how could we have been better prepared for this? [8:30];
- Should have we started to quarantine sooner than we actually did? [11:45];
- What about herd immunity? Would it be easier if we all just got the virus so we could be immune? [13:45];
- Which age groups are the least and most at risk for getting a deadly version of the virus? [15:00];
- Why do we have to wipe down packages that are delivered to our homes? [16:30];
- How a lack of preparation and discipline led to this troubling situation [18:45];
- Is China to blame for all of this? [24:15];
- What did Olivia think when her parents pulled her out of school before it was mandated? [26:30];
- What’s been the hardest part of this for Olivia? [27:50];
- What does Olivia appreciate now that she probably didn’t appreciate in the past? [28:50];
- How are Olivia’s zone 2 workouts going? [30:00]; and
- More.

§

## Show Notes

## What is a virus? [1:45]

- A virus has genetic material so it’s sort of “alive”
- However, it can’t survive (and replicate) on its own… so it needs a “host”
- It’s very tiny ⇒ invisible without a microscope
- When it infects a host, many times the host is unharmed
- But other times it causes bad colds, or a nasty stomach bug or other types of pain and suffering to the host as part of its replicating process

## How did this version of coronavirus (SARS-CoV-2) start? [4:30]

- This version of coronavirus is called SARS-CoV-2
- When SARS-CoV-2 infects a person, they develop the disease called COVID-19
- The virus originated in bats
- The best evidence suggests that the virus went from a bat to a pangolin to a human
- It’s thought that a person probably illegally poached the pangolin and used it’s scales for medicinal purposes and that is how the first person got infected
- That first person lived in Wuhan, China and got this virus in November 2019
- That person then spread it to the people around him and then the virus continued to spread all around the world

## How does COVID-19 compare to SARS and MERS (previous coronaviruses)? [6:00]

- Previous versions of the coronavirus, like SARS and MERS, were more lethal ⇒ meaning they killed a higher percentage of the people that they infect
- SARS killed about 10%
- MERS killed about 30%
- The good news is that those viruses didn’t spread very far so very few people got them

**In the case of COVID-19…**

- it spreads VERY easily and so it can kill more people in total even if only a small percentage of people who get it will die from it
- Currently over 1 million confirmed cases, but probably tens of millions of unconfirmed cases

## Will COVID-19 come back again after we resolve the current issue? [7:15]

- It’s too early to say, but “probably” says Peter
- *Could another one show up?*
- - Yeah.

## When will kids go back to school? [7:45]

*Will kids go back to school this year?*

- “I don’t really know, but if I really had to guess. I don’t think you’re going back to school this year.”

*Some people say that not even until maybe next year…Is that true?*

- We just don’t know yet

**There is a lot we don’t know right now…**

- We don’t actually know how many people have this infection
- It could be that a lot of people already have the infection and they’re doing really well and it’s not causing that much harm.
  - And in that case, people who aren’t at very high risk for getting very sick could go back to school
- But it’s also possible that we have to be much more careful and much more concerned
  - And if that’s the case, this quarantine might be something that lasts a little bit longer.

## How has the US surpassed China in total cases, and how could we have been better prepared for this? [8:30]

- Basically we didn’t do a good job of preparing for it
- We also deep heed the warnings
- We had lots of evidence that it could easily spread outside of China
- but we didn’t take a bunch of steps we should have taken

*This is a much bigger problem that goes back a number of years…*

- We don’t really have the infrastructure in place to prepare for something like this
- For example, we don’t have a national stockpile of the type of equipment that doctors and nurses would need to be protected from this if they’re taking care of a bunch of people that got sick

*Lack of testing:*

- We didn’t take advantage of the work that the Chinese people already did for testing
- In January, Chinese scientists had already DNA sequenced the virus
- That would have been a great time to have doubled down on developing tests in the United States or taking tests that others had developed and making sure we had enough of them
- South Korea did this, for example, and they’ve had way less deaths per million people than the US even though this started around the same time in both countries

**How could we have been better prepared for this?**

- It’s having the infrastructure in place to deal with pandemics
- It’s also having a pandemic preparedness program that is well funded
- “*I just don’t think our leaders we’re doing a great job.*”

## Should have we started to quarantine sooner than we actually did? [11:45]

- Yes, especially in places like NYC which has…
  - A high density of people
  - And a lot of public transit being used

## What about herd immunity? Would it be easier if we all just got the virus so we could be immune? [13:45]

*Some people are saying they just want to get the virus and be over it, meaning they won’t have to quarantine anymore since they’ve already been exposed to the virus.* ***Does Peter think that’s a good idea?***

- That’s a really good question, says Peter
- The technical term for that idea is called **herd immunity**
- This is basically saying that once you get it, you probably can’t get it again, so we might as well get it “over with” and then be immune
  - Just like chicken pox

*However… there’s a couple reasons why this might not be the best idea*

1. We actually don’t know yet if that is completely the case

- While the majority of people recover from the virus…
- We don’t know if that immunity is going to last them for another six months, another year, another five years for the rest of their lives

1. There are certain people who are at high enough risk to get sick from the virus that you might not want to take the chance of letting them just get infected
   - Kids are not at risk
   - No kids Olivia’s age have died from COVID-19 in the US (as of 4/5/20)
   - But, kids can transmit it to more at risk people who could die from it

## Which age groups are the least and most at risk for getting a deadly version of the virus? [15:00]

Kids are very low risk

- No kids Olivia’s age have died from COVID-19 in the US (as of 4/5/20)
- But, kids can still transmit it to more at risk people who could die from it

Age risk

- Your age doesn’t change you chance of getting the virus
- But it changes your risk of needing hospitalization and death from it
- The younger you are the less at risk you are

Underlying conditions

- Underlying conditions also affect risk
- So if you have high blood pressure, diabetes, heart disease, etc. you are more at risk

## Why do we have to wipe down packages that are delivered to our homes? [16:30]

There was a [study](https://www.nih.gov/news-events/news-releases/new-coronavirus-stable-hours-surfaces) that was published about three weeks ago that actually looked at putting the virus on different surfaces like cardboard, plastic, steel, copper, etc.

- Turns out that this virus can live for a day or two on cardboard
- It’s unclear if there is enough of the virus left on the package to actually infect you… but it’s better to just be extra cautious
- What we’re doing is we’re opening Amazon packages outside, we’re cleaning off the contents of them, and then just washing our hands really thoroughly.
- Wash hands for 20 seconds!

## How a lack of preparation and discipline led to this troubling situation [18:45]

Peter is very upset with how unprepared we were for this pandemic

- He says that we had plenty of evidence to know this was going to happen eventually
- But our leaders failed to take the preemptive actions to be prepared
- And this goes back many many years, not just recent evidence

> “The underlying theme to how we got here is we didn’t really do the things we needed to do before it was too late. . .it’s sometimes really hard to do things for which the payoff is far in the future.” -Peter Attia

Analogy:

- What if Olivia’s parents never forced her to clean her room, eat well, study, play sports, and instead let her watch TV all day?
- It might be fun for a little while but eventually it would become a disastrous situation
- S*o how do you make that trade off*?
- You have to have **discipline now so that it can benefit you later**.
- Just like [Jocko Willink](https://en.wikipedia.org/wiki/Jocko_Willink) says, “[***Discipline equals freedom***](https://www.youtube.com/watch?v=yoEv5PxrDvs).”

⇒ This unpreparedness for this virus pandemic is a perfect example of  “*adults not doing their homework, not saving their allowance, not eating their vegetables, not exercising, not doing their homework, just completely dropping the ball and now we’re paying the Fiddler.*”

## Is China to blame for all of this? [24:15]

- It’s become convenient for people to put the blame of this mess all on China, says Peter
- Peter uses the following analogy to explain it
  - China is like someone who cut you off on the freeway
  - If you were being vigilant and paying attention, you would have been able to avoid a disaster
  - However, if you were speeding, texting, not wearing a seat belt, etc. and then you get cut off and you end up in a huge crash and disaster…
  - The point is: China didn’t do everything right, but we need to take responsibility for the fact that we were not paying attention

## What did Olivia think when her parents pulled her out of school before it was mandated? [26:30]

- Peter and his wife pulled their kids out of school before it was officially mandated for schools to be closed
- Olivia said she thought they were crazy at first and a weird thing to do since none of her friends were pulled out
- And she was a little mad at them, she didn’t want to fall behind on schoolwork or miss her friends
- But soon after this happened, schools were officially closed

## What’s been the hardest part of this for Olivia? [27:50]

- No friends
- “*I’m a really social person.*”
- She also misses not playing sports (her basketball season just started)
- School is also more challenging because she cannot really ask questions when a teacher is going through a lesson so it’s easier to get lost

> “I have a headache after each class and yeah I do not like online school. I wish we could have school back.” -Olivia Attia

## What does Olivia appreciate now that she probably didn’t appreciate in the past? [28:50]

“*Just school in general. Like me and my friends are saying how we took school for granted and we didn’t realize how amazing it was to have school.*”

## How are Olivia’s zone 2 workouts going? [30:00]

*How many Watts are you up to?*

- I’m at 65 to 70
- She thinks she can go higher now
- She’s been increasing the duration of her workouts no problem

*What was Olivia’s last lactate level at 70 watts?*

- 2.1-2.3

§

## Selected Links / Related Material

**Study that looked at putting the virus on different surfaces (such as cardboard) to see how long it would live**: [New coronavirus stable for hours on surfaces](https://www.nih.gov/news-events/news-releases/new-coronavirus-stable-hours-surfaces) | (nih.gov)

§

## People Mentioned

- [Jocko Willink](https://en.wikipedia.org/wiki/Jocko_Willink)

§