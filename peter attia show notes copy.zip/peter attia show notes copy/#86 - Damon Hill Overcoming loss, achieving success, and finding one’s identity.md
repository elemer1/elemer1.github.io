# #86 – Damon Hill: Overcoming loss, achieving success, and finding one’s identity

**Source:** [https://peterattiamd.com/damonhill/](https://peterattiamd.com/damonhill/)

---

In this episode, Damon Hill, 1996 Formula 1 World Champion, opens up about his personal struggles with depression, feelings of inadequacy, loss of identity, and his ultimate path to healing following his remarkable racing career. Damon’s life was given a tragic jolt at 15 years of age when his father and legendary F1 driver Graham Hill died suddenly—the common string that ties together so much of his life and has forged so much of who he is to this day. We discuss Damon’s unique and remarkable racing career including his legendary battles with Michael Schumacher as well as Damon’s firsthand account of what happened that tragic day on May 1st, 1994, when his teammate, Ayrton Senna, died at Imola. But this is not just about racing; rather it’s a human story that’s cloaked in a racing one.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/damonhill/the_Drive_public.png)

Play

#86 - Damon Hill: Overcoming loss, achieving success, and finding one's identity

#86 - Damon Hill: Overcoming loss, achieving success, and finding one's identity

1x15s30s

0:002:27:00

We discuss:

- Graham Hill—Legendary F1 driver (and Damon’s dad), and the high risk of death for F1 drivers in the 1960s [7:40];
- The impact of losing his father to a tragedy [21:45];
- Damon’s path to auto racing [26:15];
- 33 year-old rookie—The unlikely beginning of Damon’s F1 career [40:00];
- Ayrton Senna’s death—Damon’s firsthand account of what happened and why it happened [53:45];
- An out of body experience while racing, and why Damon is uncomfortable with praise [1:24:45];
- The controversy with Michael Schumacher when Damon barely missed winning the championship in 1994 [1:35:15];
- Winning the World Drivers’ Championship in 1996 [1:42:00];
- Damon’s final few years racing, and retirement [1:48:30];
- Struggles after retirement—a “half-cooked” identity, confronting depression, & reorienting perspective [1:53:30];
- What advice might Damon have given his 25-year-old self if he could talk to him now? [2:04:30];
- Does the sport of Formula 1 become less interesting as it gets more and more safe for the drivers? [2:07:00];
- Why Damon likes to read the obituaries of strangers [2:11:15];
- The importance of being a good parent to your kids [2:15:30];
- Living an examined life, unanswered questions, and the importance of knowing your identify [2:18:00]; and
- More.

§

## Show Notes

## Graham Hill—Legendary F1 driver (and Damon’s dad), and the high risk of death for F1 drivers in the 1960s [7:40]

Peter highly recommends Damon’s book: [Watching the Wheels](https://www.amazon.com/Watching-Wheels-Autobiography-Damon-Hill/dp/1509831932)

- Damon says the book wasn’t about his success as a race car driver
- It was more about the emotional struggles that were tangled up in his identity
- Was he motivated to live up to his father’s name? Was this what he really wanted?

> “I’m pleased because it’s reached people who have experienced, maybe they’ve been experiencing, depression in some way, or they’ve had some difficulty in their life. And I just wanted to make it clear that it’s never plain sailing if you achieve success in sports or you achieve success in the world. And a lot of people like to gloss over the difficult bits.”

**Graham Hill (Damon’s father)**

![](https://peterattiamd.com/wp-content/uploads/2019/12/graham-hill-damonhill-1024x679.jpg)

**Figure 1.** **Graham Hill.** Image credit: [wikipedia.org](https://en.wikipedia.org/wiki/Graham_Hill#/media/File:Graham_Hill,_Bestanddeelnr_924-6564.jpg)

- Damon’s father, Graham Hill, was a legendary F1 driver
- Graham is the only person to have won the [Triple Crown of Motorsport](https://en.wikipedia.org/wiki/Triple_Crown_of_Motorsport)
- He was a star of the sport, great speaker, impeccably dressed, perfect mustache

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-2.-damonhill-1024x736.png)

**Figure 2. Damon Hill sitting in a toy car at his christening watched by Bruce McLaren, Stirling Moss, Tony Brooks, his father Graham Hill, Jo Bonnier and Wolfgang von Trips, July 17, 1961.** Image credit: [espn.com](https://en.espn.co.uk/f1/motorsport/image/2899.html)

**High prevalence of driving deaths in F1 during Graham Hill’s era**

⇒ Peter’s favorite documentary on F1: [1 (2013 film)](https://en.wikipedia.org/wiki/1_(2013_film))

- Graham Hill drove from 1958-1975
- In those days there might have been 26 or so drivers
- Each year about 2 of them would die
- That’s like a ~12% chance of death
- And then you stack those odds year after year
- It’s a miracle that guys like Graham Hill and Jackie Stewart survived
- In [1964 at Indianapolis](https://en.wikipedia.org/wiki/1964_Indianapolis_500), drivers [Eddie Sachs](https://en.wikipedia.org/wiki/Eddie_Sachs) and [Dave MacDonald](https://en.wikipedia.org/wiki/Dave_MacDonald) were killed in the same race yet the competition carried on until it was finished

*-Why was the sport (and drivers) so seemingly cavalier about deaths during F1 competitions?*

- If you grew up during the war era, you were witness to so many men and women dying in the war
- Flying bombers and fighting the Germans, risking your life
- So racing might be dangerous but it’s also fun and you get paid
- And much better than the alternative of being shot at in war

-A more gentlemanly approach to driving:

- In those days, compared to now, drivers were more careful in terms of not be responsible for another drivers crash
- Since the risk of death from crash was so much higher, the drivers were more “gentlemanly” than they are nowadays

**Pushing fear to the back of your mind**

- [Jackie Stewart](https://en.wikipedia.org/wiki/Jackie_Stewart) wrote in his [book](https://www.amazon.com/Winning-Not-Enough-Jackie-Stewart/dp/0755315391/ref=sr_1_3?qid=1576170180&refinements=p_27%3ASir+Jackie+Stewart&s=books&sr=1-3&text=Sir+Jackie+Stewart) about how frequently he would attend funerals of other drivers during his career in the 1960s
- Being a driver means you have to have some ability to push fear to the back of your mind
- Damon recently observed this skill in the documentary, [Free Solo](https://www.nationalgeographic.com/films/free-solo/), when [Alex Honnold](https://en.wikipedia.org/wiki/Alex_Honnold) climbs [El Capitan](https://en.wikipedia.org/wiki/El_Capitan) without a rope
- In 1994, Damon witnessed his teammate, [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna), die in a [crash at Imola](https://en.wikipedia.org/wiki/Ayrton_Senna#Death)
- But he had to figure out how to push that fear into the back of his mind and keep racing
- It was a very dangerous time to be driving in the 1990s

> “If you make an error, then you pay the price, and that’s your fault. So you do concentrate a lot harder when you know that the risk of injury is great.”

## The impact of losing his father to a tragedy [21:45]

**Graham Hill’s death**

- Damon’s father retired from racing in 1975
- It was a “relief” to his family that he survived some a dangerous time to be in motor racing
- However, on November 29th, 1975, just months after retiring, Graham Hill tragically died a plane crash
- In Damon’s book, he describes the nightmare, the phone call, his mom screaming…
- “…*we don’t get over things like that. It’s the worst thing that you can imagine happening…*”

*How therapy can help with these types of trauma*:

> “A lot of therapy is about people getting over those experiences, but I don’t think you can possibly ever unremember the emotions. What you can do is you can recognize that those emotions had a relevance there and then at that time, and if you’ve locked them away and haven’t revisited them and kind of exercise them, then they come back to you in other situations when you’re not conscious of why you’re feeling those emotions at that time.”

*When did Damon finally realize he had those unprocessed emotions?*

- A couple years after he retired from racing
- Once he retired he was questioning who he was
- Who am I? Am I different to my dad?
- Damon did not want to suffer the same fate as his father

*Is doing something dangerous irresponsible or a necessary part of life?*

- Damon wasn’t afraid of dying for the sake of his own life
- But he was very afraid of putting his family through that knowing what it was like for him, his siblings, and his mother
- But at the same time, Damon points out that humans put themselves into dangerous situations all the time…
- …and it is for the purpose of helping others than it shouldn’t be a negative thing

> “We can’t go through life in cotton wool. We have things we have to do as humans to fulfill ourselves. . . by taking . . . calculated chances that have a benefit somewhere, somehow. [I hope] that my children would also not be afraid of doing those things.”

## Damon’s path to auto racing [26:15]

**Motorcycle racing**

- Before his dad died, Damon was into motorcycles
- He wanted to race dirt bikes from a young age
- Not long after his dad died, Peter Gethin (a Formula 1 driver) took Damon to Brands Hatch to watch motorcycle racing
- Damon said he loved it … whereas he was almost bored with watching F1 racing
- On a motorcycle it was much easier to see the actual person who was steering and controlling the vehicle whereas in F1 the driver is mostly hidden
- After that experience, Damon decided to do bike racing

**Transitioning to car racing**

- Almost all F1 drivers come for a [kart racing](https://en.wikipedia.org/wiki/Kart_racing) background which leads nicely into car racing
- But Damon did not, since he raced motorcycles
- Damon said this put him at a bit of a disadvantage
- One day, Damon got invited by Mike Knight to come to the [Winfield Racing School](https://winfieldracingschool.com/) in France to drive a 2000 Formula Renault to see how he liked it
- This was right around the time that Damon was starting to win every bike race in which he participated
- But there was no money to be made in bike racing
  - Unless you were [Barry Sheene](https://en.wikipedia.org/wiki/Barry_Sheene)
  - Or if you wanted to risk your life at the [Isle of Man TT](https://www.iomtt.com/)
- At the end of the day, Damon made the decision to give up bike racing to pursue car racing

https://www.youtube.com/watch?v=iRWp9rhfS\_0

***How did the fact that Damon’s father was a Formula 1 driver impact his decision?***

- Damon speculates that there must be something genetically that makes people want to race
- For Graham Hill, the first time he ever drove a racing car he knew immediately… He calls it a light bulb moment
- Damon felt the same way after he got on a motor bike
- Even Damon’s grandma rode a motorbike
- There might even be an epigenetic factor that gets passed down, says Damon

-Racing was partly about getting to know his dad

- The motivation to do it I think was also to get to know my dad
- You have some way of relating to him even though he wasn’t there

> “It’s a very hard thing to differentiate yourself from your parents, and I don’t necessarily believe that it’s possible to be completely an individual.”

*–*Interesting parallels between Damon’s career and his father’s career:

- Graham Hill [lost a teammate](https://en.wikipedia.org/wiki/Jim_Clark#Death) ([Jim Clark](https://en.wikipedia.org/wiki/Jim_Clark)) in a crash but then went on to win a [championship for his team in 1968](https://en.wikipedia.org/wiki/1968_Formula_One_season)
- Damon Hill also lost a teammate ([Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna)) but then went on to win a [championship for his team in 1996](https://en.wikipedia.org/wiki/1996_Formula_One_World_Championship)
- Damon points out one difference is that his father was extremely good at being practical and courageous in moments of chaos (Damon feels less equipped for that)

## 33 year-old rookie—The unlikely beginning of Damon’s F1 career [40:00]

**How did Damon manage to get on the Williams team?**

- Damon managed to get the test driver spot with [Williams car](https://en.wikipedia.org/wiki/Williams_Grand_Prix_Engineering) in 1991 led by [Frank Williams](https://en.wikipedia.org/wiki/Frank_Williams_(Formula_One))
- In 1992, [Nigel Mansell](https://en.wikipedia.org/wiki/Nigel_Mansell), who was driving for Williams, won the F1 championship and immediately retired to go to [IndyCar](https://en.wikipedia.org/wiki/IndyCar)
- In 1993, [Alain Prost](https://en.wikipedia.org/wiki/Alain_Prost) was signed by Williams to be their top driver but the #2 spot was open since Nigel had moved to IndyCar (mostly because he didn’t want to be teammates with Prost)
- Damon was left as the only person around who knew how to drive so he became the #2 for Williams

**The FW15**

- In 1993, the [FW15](https://en.wikipedia.org/wiki/Williams_FW15C) car was introduced with active suspension allowing you to adjust the height of the car
- It was thought of as the “most advanced car in the history of Formula One for its time”
- \*Peter still says his favorite F1 car of all time is the [McLaren MP4/4](https://en.wikipedia.org/wiki/McLaren_MP4/4)\*
  - For more, check out [Step inside the MP4/4](https://www.youtube.com/watch?v=uAyT9zPQYUk)
- For all of 1992, Damon was testing out this new technology
- He never thought he be actually competing in this car in 1993… “*it was a pipe dream*”

**32 year old rookie**

- In 1993, Damon was a rookie driver at 32 years old
- This is impossible to imagine happening nowadays ([Sebastian Vettel](https://en.wikipedia.org/wiki/Sebastian_Vettel) is 32 and he’s been driving for 12 years)
- And considering Damon had not come from a karting background, this was an amazing situation
- At age 29, Damon and his wife had their first child who has down syndrome
- He had just lost in [Formula 3](https://en.wikipedia.org/wiki/Formula_Three)
- He’d just bought a house with a mortgage rate at 17%!
- But he still wanted to race cars
- “*I was mad. What madness was this that made me press on?*”

-Peter quotes [Louis Pasteur](https://en.wikipedia.org/wiki/Louis_Pasteur): “*Chance favors the prepared mind.*”

- The idea is that when you look at scientific breakthroughs, people think of it as a spark of inspiration or a flash of genius
- The point is no, it’s not…It’s a lot of hard work, toiling, failing and failing some more
- Great scientists always talk about this idea that what separates the good ones from the great ones
  - The great ones are able to see the right thing at the right time
  - They’re able to extract from the data that which others don’t see
  - But that requires being there, that requires being in the trenches
- Peter relates that to 1992 when Damon was hired to be part of the Williams car team
  - He put your head down, you were in the trenches, you showed up every day, you test drove that car, and he did it without an agenda
  - And so when the situation arose with Nigel going to IndyCar, Williams was incredibly lucky to have Damon there

**Driving with Alain Prost**

- Having [Prost](https://en.wikipedia.org/wiki/Alain_Prost) as the top Williams driver in 1993 made it easier for the team to plug Damon in as the #2 despite his lack of experience
- *Was Damon intimidated by Prost*? ⇒ No, Prost was a “very decent chap” according to Damon
- Damon would go on to finish in third place in 1993 (Prost was first, Senna was second)

*What did Damon learn from him?*

- He is a very quiet guy and it was quite interesting.
- The engineers that were running his car said the amazing thing about Alain Prost is **he doesn’t use any brakes, but he’s incredibly quick, and uses very minimal hand movements.**
- He’s clearly ahead of the car and able to anticipate it
- “*He was a hell of a fighter, but out of the car you’d never know that the guy was such a formidable competitor.*”

**Donington in 1993**

- In 1993, Senna produced arguably the “Greatest lap in the history of Formula 1”
- During the [first lap at Donington](https://www.youtube.com/watch?v=3GOEorrE4mY) Senna managed to pass 3 other drivers in the **rain** including both Prost and Damon in an “inferior” car

*What does Damon remember about that?*

- “My brain was fried.”
- “that was just so embarrassing”
- “It was not one of our finest weekends as a team or for Alain.”

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-3.-senna-hill-and-prost-podium-donington-damonhill-1024x678.jpg)

**Figure 3. Ayrton Senna after embarrassing both Damon (left) and Alain Prost (right) at the 1993 European Grand Prix at Donington Park.** Image credit: [ayrtonsenna.com](https://www.ayrtonsenna.com.br/en/as-historias-mais-curiosas-da-vitoria-de-ayrton-senna-em-donington-park/)

## Ayrton Senna’s death—Damon’s firsthand account of what happened and why it happened [53:45]

[The 1994 season](https://en.wikipedia.org/wiki/1994_Formula_One_World_Championship#Drivers_championship)

- After 1993, Prost retired from Formula 1
- This opened the door for [Frank Williams](https://en.wikipedia.org/wiki/Frank_Williams_(Formula_One)) to sign [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna), something he had wanted for a long time
- Damon was still the #2 driver and considered himself unbelievably spoiled to have Nigel, Prost, and now Senna to learn from in his short F1 career
- The [FW16](https://en.wikipedia.org/wiki/Williams_FW16) car was introduced which Damon says was **difficult to drive**
- The first two races (Brazil and then Japan) did not go well for Senna, Damon and the Williams team
- [Michael Schumacher](https://en.wikipedia.org/wiki/Michael_Schumacher) was building a commanding lead with the [Benetton team](https://en.wikipedia.org/wiki/Benetton_Formula)
- The third race was the [1994 San Marino Grand Prix](https://en.wikipedia.org/wiki/1994_San_Marino_Grand_Prix) in Imola, Italy

**Going into the Imola race…**

- Ayrton Senna was a bit frustrated
- He was concerned with the performance of the cars
- He also thought that maybe the Benetton team (with Michael Schumacher) were cheating with something to do with their traction control
- During the qualification round, [Roland Ratzenberger](https://en.wikipedia.org/wiki/Roland_Ratzenberger) died in a crash
- Damon says Ayrton Senna was shaken by the crash
- “He seemed almost angry.”
- On race day, Senna was having an uncommon (for him) conversation with Damon’s wife, asking her what it was like to have a family
- After Senna died, they actually found a folded up Austrian flag (Ratzenberger was from Austria) that Senna has planned to fly after the conclusion of the race at Imola

“*[Senna] internalized a lot. I think he took a lot upon himself. I think he felt* ***enormous responsibility for people in Brazil*** *and the projects he had to do with helping young people. And I think he really felt that he had a job to do, which he couldn’t, somehow racing enabled him to do. Through his racing he was able to be Ayrton Senna and then he could do these great works that he had planned.*”

**Damon’s take on how and why Ayrton Senna crashed that day**

-Before reading Damon’s book, Peter had always believed Senna crashed due to a technical problem with the car (a broken steering column) rather than a mistake made by Senna

-Damon’s account of the crash:

- Looking at the data
- And looking at the [onboard footage](https://www.youtube.com/watch?v=8qYXVfY_9IE) of Senna’s car
- As well as Schumacher’s onboard camera
- Damon could see that Senna was putting “opposite lock” on the car and controlling the car which is the opposite of what you’d do if the steering column had actually broken

-Ultimately, Damon says…

- Senna was going too fast
- His car was heavy with a full tank of gas
- He had cold tires that were low in pressure which produces more lateral movement
- These conditions created a scenario where the car “springs back” and at that speed it can throw you off the track

> “I think he was so motivated to win this race that I think he was putting himself right out there at the end of the branch. And maybe even a guy like Ayrton couldn’t drive that car beyond a certain point without something giving somewhere.”

**In summary, Damon describes the events leading to Ayrton Senna’s death as follows**:

“*If you put someone under, even someone as brilliant as Ayrton, under a lot of stress with lots of different doubts, lots of different questions, lots of different problems, and then you put them in a very competitive situation and you expect them to perform with a clear head in the same way that they have done in the past, I think something’s got to give somewhere. You add in the fatality of the previous day, the emotional state of the guy, the determination to win, and the fact that he’s on a different team and it’s not going the way he wanted it to in the championship. If you put someone like Ayrton in that situation, is he going to back down? No, he’s not going to back down. He’s going to be Ayrton Senna. He’s going to go further beyond where he’s ever been before because that’s what Ayrton Senna was. He’s not going to go, ‘Okay, I’ll feather the throttle through Tamburello.’ He wouldn’t be Ayrton Senna.*”

**The days that followed Senna’s death and what Senna meant to Brazil**

- At first, Damon had hesitations about going to Brazil for Senna’s funeral
- He wanted to be with his family, and not he didn’t want to live through the pain of it (the last funeral he went to was for his father)
- But Jackie Stewart called Damon and said, “*You will regret it till your dying day if you don’t go. . .You want to be a racing driver? You can’t just sidestep the nasty bits.*”
- The funeral ended up being “the most extraordinary event”
- You saw how he affected people of Brazil and that’s what he lived with.
- That’s what he’d been carrying that nobody in F1 really saw
- The country stopped for three days and more than a million people lined the streets for this funeral

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-4.-sennas-funeral-damonhill.jpg)

**Figure 4. The funeral procession of Formula 1 Champion Ayrton Senna, an estimated 3 million people lined the streets making it one of the largest recorded gathering of mourners in modern times.** Image credit: [reddit user: u/Blodje](https://www.reddit.com/r/HistoryPorn/comments/2qos9a/the_funeral_procession_of_formula_1_champion/)

*Was Damon afraid to get back in the car for the next race?*

- “I’ll put it like this. The enjoyment of driving had evaporated from that point on. It was a task I had to do.”
- “I wasn’t sure whether I could cope with carrying all the hopes of the entire team.”
- “I was not Ayrton Senna as it was abundantly clear.”

*How did having a family affect his driving?*

- I was affected with the thought that because Ayrton’s accident was incredibly public and shocking that I definitely did not want my children to see anything like that happen to me.
- So, protecting the kids from any potential shocking incident was also part of our lives
- [Enzo Ferrari](https://en.wikipedia.org/wiki/Enzo_Ferrari) used to say, “A driver with children was a second and a half slower.”
- That said…
  - There was a lot of world champions with children.
  - And I think in some sense is, the goal is to survive.
  - So if the goal is to survive, then you’re doing the responsible thing by performing to the very highest level you possibly can without going over that threshold.

**Dealing with the aftermath of a deceased loved on**

When someone dies, all the evidence of their life remains…

- Their clothes, their stuff
- It has to be dealt with
- Do you keep it? Throw it away? Was the right thing to do?
- Damon went through this with the death of his father

> “You go through all those thoughts. You just go through all these little questions and you can’t find the answers to them.”

## An out of body experience while racing, and why Damon is uncomfortable with praise [1:24:45]

**An out of body experience while racing**

- Despite the slow start to the [1994 season](https://en.wikipedia.org/wiki/1994_Formula_One_World_Championship), Damon found himself in 2nd place behind Michael Schumacher
- There were 2 races left and Damon had a shot to win the championship
- But in order to have a chance to win the championship, he had to beat Damon in the 2nd to last race of the season taking place in [Suzuka, Japan](https://en.wikipedia.org/wiki/1994_Japanese_Grand_Prix)
- The conditions were wet
- Damon found himself in the lead towards the end of the race but felt like he was losing steam and Schumacher was catching up to him
- At that moment, he basically asked the now deceased [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) for help…“*Aryton, if you’re up there watching me, I need your help right now.*”
- Immediately following his request to Senna, he said he felt “possessed”
- “*I swear to God, it was like someone had got my foot and planted it flat on the floor and I couldn’t lift it off.*”
- “*I literally was disconnected from what my body was doing. And it was just like I was willing it to win, willing it just purely through thought, through some sort of telepathic kind of way I was controlling things.*”
- Damon says after one lap he basically decided he was being pushed too hard and he more or less said “*I’ll take it from here.*”
- “I can remember literally feeling like I was coming back into the car.”
- Damon went on to win the race

> “We have more potential than we are aware of and sometimes to release that potential we have to play tricks with our mind.”

⇒ Peter points out that this experience was similar to how Senna described his experience during is famous [qualifying lap at Monaco in 1988](https://www.youtube.com/watch?v=xn8gh39SsrM&t=2s)

**Why is Damon uncomfortable with praise?**

- Despite being a legendary F1 driver, Damon is very modest
- This comes through in [Damon’s appearance on This is Your Life](https://www.youtube.com/watch?v=r5ASe2DlYPU)
- Damon says he is uncomfortable with being praised
- He’s not sure why, but he’s rather be told what he’s doing wrong so he can improve himself

*-Damon believe we tend to over-celebrate achievements as a society*

- “I think we celebrate far too much people’s achievements, the parts they don’t warrant so much celebration as we give them.”
- Damon explains that in driving for example, the competitors are competing for a championship which is a selfish achievement, so it seems silly to him to shower that person with praise
- (especially when overlayed against a doctor saving lives in a third world country or something)
- Peter counters with the fact that watching someone achieve greatness and their pursuit of a goal gives observers hope in many ways
- And someone like Senna for example literally changed millions of lives through his driving
- Damon agrees, and points out that in many cases people are grateful when a person who is given an opportunity makes the best of it… so in a way they are praising you for doing good with what you were given

## The controversy with Michael Schumacher when Damon barely missed winning the championship in 1994 [1:35:15]

- The final race of the 1994 season was at the [Adelaide Street Circuit in Australia](https://en.wikipedia.org/wiki/1994_Australian_Grand_Prix)
- Whoever did better between Damon and Michael Schumacher would win the 1994 championship
- Towards the end of the race, Schumacher was starting to pull away from Damon
- However, Schumacher slipped up and crashed and was out of the race
- As Damon tried to pass him, Schumacher turned his car to get in the way of Damon
- His car hit Damon’s car and damaged the suspension
- This would mean that both drivers had to retire the race without finishing
- Therefore, Schumacher would win the championship
- This ending sparked a lot of controversy, with many people thinking was Schumacher did was unfair

*Feelings toward Schumacher*

- Despite this, Damon holds no contempt towards Schumacher for this and doesn’t really think what he did was unfair
- Peter, on the other hand, has never been a fan of Schumacher
- “*I always felt he played in a gray area of the sport.*”
- His team, Benetton, refused to submit F1 data in 1994 despite [accusations of doing something fishy with their traction control](https://en.wikipedia.org/wiki/1994_Formula_One_cheating_controversy) (Senna was outspoken about this)
- Peter even thinks that if Schumacher wasn’t racing at Imola in 1994 that Senna would not have died
- However, he is quick to admit that is not necessarily Schumacher’s fault
- Although Peter says he’s never really forgiven Schumacher was the role he played

**Ayrton Senna had flaws**

-Damon and Peter discuss Senna’s personality traits, the good and the bad

- Senna was very volatile
- And despite the fact that Peter is the biggest Senna fan ever… he does acknowledge Senna’s flawed qualities
- Peter says: “*My wife asked me about this. She goes, ‘You sort of have a double standard with Senna. Like, you’re very quick to overlook his flaws.’ I don’t know that that’s true. I think what it is, I think it’s how open a book he was and how volatile he was that I actually see as appealing. There’s no ambiguity of where you stood with him.*”
- Damon calls watching Senna like “Greek theater”
- “He’s kind of destined. He hadn’t got any choice in the matter. His life, his personality, the things that made him who he was, these forces were driving him.”
- [*Alain Prost*](https://en.wikipedia.org/wiki/Alain_Prost)*, a rival of Senna’s,* [*commented in 1990*](https://www.ayrton-senna.net/ayrton-senna-alain-prosts-legendary-rivalry/) *in the heat of their rivalry*: “Ayrton has a small problem, he thinks he can’t kill himself, because he believes in God and I think it is pretty dangerous for other drivers”

## Winning the World Drivers’ Championship in 1996 [1:42:00]

[The 1996 F1 season](https://en.wikipedia.org/wiki/1996_Formula_One_World_Championship)

- A lot of good things were coming together and it became clear that this was Damon’s year as long as he executed properly
- Damon had a new up and coming teammate named [Jacques Villeneuve](https://en.wikipedia.org/wiki/Jacques_Villeneuve)
- But Damon’s experience was a big advantage
- Villeneuve had a bit of a cocky attitude which led to a discussion about the **2 types of successful people**

**2 phenotypes of successful people towards self criticism**

1. Those that believe they are never wrong, that they know everything and don’t need help
2. Those who are extremely self-critical and first to admit that were wrong and need to do better

- Both phenotypes can lead to success
- But evidence suggest people of the first phenotype are more fragile and will tend to more easily fracture when things aren’t going well
- Michael Schumacher, for example, when things weren’t going well, he fell apart, says Damon
- Alain Prost, on the other hand, was openly self-critical and willing to accept a little bit of his fallibilities
- Damon says people who are the best are generally more self-critical of themselves so that actually they’d see themselves as work in progress and they’re always trying to improve

**Winning the World Drivers’ Championship**

- Damon had a tremendous 1996 season
- He held off his impressive rookie teammate, Villeneuve, who got 2nd place
- Michael Schumacher end up 3rd overall
- Damon became the **first world champion driver who was also the son of a world champion driver**

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-5.-1996-championship-damonhill.png)

**Figure 5. Damon Hill wins 1996 championship.** Image credit: [in2motorsports.com](https://www.in2motorsports.com/damon-hill/)

## Damon’s final few years racing, and retirement [1:48:30]

- After his 1996 championship, Damon left Williams and [signed with Arrows in 1997](https://en.wikipedia.org/wiki/Damon_Hill#Arrows_(1997))
- His final two seasons where with [Jordan](https://en.wikipedia.org/wiki/Jordan_Grand_Prix)
- Damon’s first Grand Prix victory since leaving Williams, and the last victory of his career, came at the [1998 Belgian Grand Prix in Spa](https://en.wikipedia.org/wiki/1998_Belgian_Grand_Prix)
- 1999 was his final season
  - Damon came back for the last year of his contract with the Jordan team
  - He had hopes for a good season but about half way through he was ready to retire
  - He ended up finishing the season, however, with his last race being at the [1999 Japanese Grand Prix at Suzuka](https://en.wikipedia.org/wiki/1999_Japanese_Grand_Prix)

**His final race**

- While driving in his final race, it got to the point where Damon was far enough behind that he would not finish in the points
- Rather than finish the race, he pulled the car over and stopped early
- “*We’ve got no chance. We’re way out on the points, … a wheel could fall off, I could hit a barrier and kill myself, and then it would all have been stupid, wouldn’t it? Why risk it? So I came in*.”

**What was it like in the immediate days after retiring?**

*“I was very relieved and happy. I thought I was home and dry. I thought I’d escaped. . . I made it. I made it out. I made it through in one piece.”*

## Struggles after retirement—a “half-cooked” identity, confronting depression, & reorienting perspective [1:53:30]

Lacking an identity

- Damon says he never really fully identified as an F1 driver
- “*I felt like I denied my identity by being shoehorned into being a racing driver.*”

Confronting depression

- Some years after retirement, Damon said he felt frustrated, confused, and angry
- He was just beginning to acknowledge and deal with depression

**⇒ Damon’s take on depression**:

“*Depression is a way of telling us we’re going the wrong direction. So it’s a profound signaling, a running out of energy, an energy that is depleting and it’s actually starting to go the other way. It’s actually starting to drag you down. And it’s because it’s trying to tell you something. You are sort of doing this to yourself. You actually need to* ***reorientate your perspective*** *on things. How do you do that? And that’s easy to say, and as anyone who’s had depression knows, someone can’t say to you, ‘Just cheer up.’*”

At one point, Damon had a bit of a turning point

- He was at an art exhibit looking at a painting depicting a sunny sky that turned darker and darker as you looked down
- “*I remember looking at this painting and just going, ‘I don’t want to go down there.’*”
- Damon felt like that was his path if he didn’t make some kind of change

**A “half-cooked” identity**

- Identity is fundamentally important, says Damon
- In Damon’s case, he felt like he had a “half-cooked” identity
- Damon felt like his dad being powerful and recognized, then dying a tragic  death played a role in this struggle:
  - *“Your dad’s famous, and then he dies. Who are you? Are you your dad’s son?*”
  - “*And when I’d start racing, I just expressed something that I had, maybe I was just play acting my dad. Those are the sort of questions you ask yourself.*”
- In other words, Damon spent 20+ years pursuing something that he wasn’t/isn’t even sure was about him or if it was about reconstituting the life that he had before his father got killed
- Damon felt an obligation to get this depression/identity thing figured out so that his kids wouldn’t “lose” their father (in an emotional way)

> “In a way, and partly in my mind, if I restructured my family, then I’d restructured the family that was shattered, that was destroyed.”

![](https://peterattiamd.com/wp-content/uploads/2019/12/fig-6.-damon-with-dad-in-car-damonhill-1024x680.png)

**Figure 6. Damon as a kid with his father.** Image credit: [motorsportmagazine.com](https://www.motorsportmagazine.com/archive/article/november-2015/66/had-dad-not-died-i-doubt-i-would-have-become-racing-driver)

**Parent’s relationship**

- - The more you dig into your parents’ relationship, the more you realize that your parents’ relationship was not as ideal as it should have been.
  - Damon started to talk to his mom about her relationship with her husband
  - “But then if I started to criticize him then she would suddenly come to his defense.”

- **Part of Damon’s criticism was this idea that his father was doing something “noble” by driving a racecar**

- - Damon points out that people praise drivers as doing something “noble” or good
    - Really? Was it that noble when you’ve got family and stuff, is it really that admirable that you’re putting all that at risk?
- The sad irony is that Damon’s dad dodged the bullet of racing and then [died in a plane crash](https://en.wikipedia.org/wiki/Graham_Hill#Death) 6 months after retiring from driving

## What advice might Damon have given his 25-year-old self if he could talk to him now? [2:04:30]

1. **Don’t try to impress others because you think it might help you**: just do your job really well and that will be good enough
2. **Focus on the things you can control**: And don’t waste time worrying about things you can’t
3. **Enjoy it**: don’t put yourself through torture because you think this is something that means a lot. We’re going around in circles chasing each other and trying to come first.

- Racing isn’t some noble thing, say Damon
- Some people actually I think looked at Formula One and were put off, they thought it’s a disgusting thing.  ⇒ “*I can understand why they felt that way.*”
- Damon says its incredibly impressive what F1 drivers are able to do, but he says let’s not confuse that this it being a wonderful or noble thing, “
- We like to embellish it and make it seem like it’s such a wonderful thing ⇒ “*let’s not get it too far out of our context*”

## Does the sport of Formula 1 become less interesting as it gets more and more safe for the drivers? [2:07:00]

- There has been significant improvement in the safety of F1 driving
- When Senna was killed, [Max Mosley](https://en.wikipedia.org/wiki/Max_Mosley) (president of F1 at the time) made the statement, “*the question isn’t ‘why did Senna crash?’ The question is ‘why did he die?*’”
- In Senna’s case, it was a very fluky death
- Peter says 99 out of 100 drivers would have survived the crash that Senna died in

**When you take away the risk of F1, do people still appreciate the skill of the sport?**

- Damon admits this is a tough question
- But certainly, you can’t say there should be MORE risk
- There’s a difference between hazard and risk
- Hazard is what can happen
- Risk is the chance of that happening
- We’ve taken away many of the hazards to someone being hurt in a crash (but not necessarily the risk of crashing)
- Damon says when you take away hazard and/or risk, you have to then replace the challenge
  - Example would be giving the cars more power or more difficult to drive
- “*If it looks easy then nobody cares. They’re not going to be watching.*”

## Why Damon likes to read the obituaries of strangers [2:11:15]

*Attending funerals*

- Peter says that attending funerals can be an amazingly *grounding experience*
- Listening to the eulogies, you realize people talk about the type of person you were than what your achievements were
- It focuses you on what matters most in life

*Why Damon has a habit of reading obituaries*

> “It’s unbelievable the kind of lives people have and the things they do, modest people do extraordinary things.”

- It’s those stories which I think are profoundly moving because you don’t know who these people are
- They may be people have dismissed them as being ineffectual and they’ll do something really remarkable
- ***How has this impacted Damon?***
- - “It’s made me wonder whether I’m one of those people or not.”
  - “I shudder to think I might have to kind of make a decision as to whether I go in a burning building or not.”
  - “But there are people who do that without even batting an eyelid.”
  - “Human beings are extraordinary creatures . . . And I like learning more and more about them . . . and what we’re capable of.”
  - “I’m still in awe of people who are skilled or people who are educated in all kinds of ways and are able to make things happen.”

## The importance of being a good parent to your kids [2:15:30]

- When Damon retired, Peter remembers him mentioning he was MOST excited about being able to take his kids to school
- Damon says his kids gave him purpose after retirement from racing
- He believes how we raise our kids can change the world for the better

> “The world can completely changed with one generation. And it’s all about how we nurture our children and what we advise them in and the opportunities we give to them.”

## Living an examined life, unanswered questions, and the importance of knowing your identify [2:18:00]

A story from his battle with depression:

- When feeling quite depressed, Damon got a olive tree from a friend for his 40th birthday
- But soon the tree was infested with bugs that would kill the tree if he didn’t stop the bugs
- But then he found himself asking the questions, *What do I do? Do I let them kill the tree? Do I kill the bug? Do I leave it? Do I leave it be, do I not have any involvement? What is my purpose here? What should I be doing?*
- *“That’s the kind of stuff that stops you in your tracks when you’re heavily in those mindsets, you kind of get caught between those unresolvable questions.*”
- Maybe I should just chuck the whole thing in the skit
- Peter describes that scenario as an extreme version of an examined life
- Living in examined life is uncomfortable
- But it’s also necessary in a sense you when you open questions about who you are
- Damon has said that since he’s feeling better now, he is able to recognize the “unanswerable” questions when he says feels “liberating”

**Importance of knowing your identify:**

> “I don’t feel like I’m going to slip into that abyss and I think that the abyss was a complete loss of identity. . .I think when you have questions about your identity, you don’t know who you are. And on that point I would say what I’ve also realized is that identity is very much a compound of your relationship to others. And this is where I think it becomes a healing thing when you recognize that who you are is what you are to other people as well as who you want to be for yourself.”

Peter highly recommends [Damon’s autobiography](https://www.amazon.com/Damon-Hill-Watching-Wheels-Autobiography/dp/1509831908)

“*it’s a great story about overcoming loss, I think it’s a great story about struggling with one’s identity. And I think anybody that reads it is going to get something out of it special.*”

§

## Selected Links / Related Material

**Damon’s book (an autobiography) which Peter highly recommends**: [Watching the Wheels](https://www.amazon.com/Watching-Wheels-Autobiography-Damon-Hill/dp/1509831932) by Damon Hill | (amazon.com) [5:00, 7:45, 21:45, 1:10:50, 2:24:15]

**Company Damon now works for**: [Sky Sports](https://www.skysports.com/f1) | (skysports.com) [7:00]

**Graham Hill is the only person to have won the triple crown of motor racing**: [Triple Crown of Motorsport](https://en.wikipedia.org/wiki/Triple_Crown_of_Motorsport) | (wikipedia.org) [10:15]

**Graham Hill’s first F1 championship came in 1962**: [1962 Drivers’ Championship – final standings](https://en.wikipedia.org/wiki/1962_Formula_One_season#1962_Drivers'_Championship_%E2%80%93_final_standings) [12:45]

**Peter’s favorite documentary about Formula 1**: [1 (2013 film)](https://en.wikipedia.org/wiki/1_(2013_film)) | (wikipedia.org) [14:15]

**n 1964 at Indianapolis, drivers Eddie Sachs and Dave MacDonald were killed in the same race yet the competition carried on until it was finished**: [1964 Indianapolis 500](https://en.wikipedia.org/wiki/1964_Indianapolis_500) | (wikipedia.org) [15:00]

**Jackie Stewart’s book when he made it clear that going to a guy’s funeral and seeing the family every other week was common and tough**: [Winning is Not Enough](https://www.amazon.com/Winning-Not-Enough-Jackie-Stewart/dp/0755315391/ref=sr_1_3?qid=1576170180&refinements=p_27%3ASir+Jackie+Stewart&s=books&sr=1-3&text=Sir+Jackie+Stewart) by Sir Jackie Stewart | (amazon.com) [17:00]

**The film showing the Alex Honnold climb** [**El Capitan**](https://en.wikipedia.org/wiki/El_Capitan) **without a rope**: [Free Solo](https://www.nationalgeographic.com/films/free-solo/) | (nationalgeographic.com) [18:30]

**Video of motorcycle racing zooming by spectators at the Isle of Man TT**: [Greatest✔️Show⚡️On Earth ✅ 322.km/h-200.MPH Street Race . ISLE of MAN TT](https://www.youtube.com/watch?v=iRWp9rhfS_0) | Lockk9 TT Racing (youtube.com) [34:50]

**Graham Hill’s teammate who was killed while racing after which Graham Hill went on to win a championship (sort of like Damon did after he lost his teammate-Senna)**: [Jim Clark: Death](https://en.wikipedia.org/wiki/Jim_Clark#Death) | (wikipedia.org) [38:45

**Graham Hill win the championship in 1968**: [1968 Drivers’ Championship final standings](https://en.wikipedia.org/wiki/1968_Formula_One_season#1968_Drivers'_Championship_final_standings) | (wikipedia.org) [38:45]

**The “most advanced car in the history of Formula 1 for its time” which was used in 1993 by Damon Hill and Alain Prost**: [Williams FW15C](https://en.wikipedia.org/wiki/Williams_FW15C) | (wikipedia.org) [41:45]

**Peter’s favorite F1 car ever**: [McLaren MP4/4](https://en.wikipedia.org/wiki/McLaren_MP4/4) | (wikipedia.org) [41:45]

- For more, check out: [Step inside the MP4/4](https://www.youtube.com/watch?v=uAyT9zPQYUk) | McLaren (youtube.com)

**The greatest lap in F1 history (driven by Senna against Prost and Damon Hill)**: [F1’s Greatest Lap? Ayrton Senna at Donington 1993](https://www.youtube.com/watch?v=3GOEorrE4mY) | FORMULA 1 (youtube.com) [51:15]

**Car driven in 1994 by Damon Hill and Ayrton Senna (car Senna was killed in)**: [Williams FW16](https://en.wikipedia.org/wiki/Williams_FW16) | (wikipedia.org) [55:45]

**The tragic death of Ayrton Senna in 1994**: [Death of Ayrton Senna](https://en.wikipedia.org/wiki/Death_of_Ayrton_Senna) | (wikipedia.org) [58:00]

**Onboard camera of Ayrton Senna’s fatal crash**: [Senna Fatal Crash Onboard (Hill/Schumacher/Senna)](https://www.youtube.com/watch?v=8qYXVfY_9IE) | iLOVEtheseVINYLS  (youtube.com) [1:04:45]

**The race in which Damon had an “out of body” experience while driving**: [1994 Japanese Grand Prix](https://en.wikipedia.org/wiki/1994_Japanese_Grand_Prix) | (wikipedia.org) [1:24:45]

**Senna’s 1988 qualifying session in Monaco in which he described it as he was “part of the car”**: [Remember Senna](https://www.youtube.com/watch?v=xn8gh39SsrM&t=2s) | McLaren (youtube.com) [1:25:45]

**Damon’s appearance on This is Your Life**: [This Is Your Life – Damon Hill O.B.E](https://www.youtube.com/watch?v=r5ASe2DlYPU) | Steffan Bowen (youtube.com) [1:29:30]

**Quote about how we all worship something by David Foster Wallace**: [David Foster Wallace > Quotes > Quotable Quote](https://www.goodreads.com/quotes/100888-because-here-s-something-else-that-s-weird-but-true-in-the) | (goodreads.com) [1:33:00]

**The controversy in 1994 around what the Benetton team (Michael Schumacher) might be doing against the rules with Senna being the loudest voice about it**: [1994 Formula One cheating controversy](https://en.wikipedia.org/wiki/1994_Formula_One_cheating_controversy) | (wikipedia.org) [1:38:45]

**Alain Prost tells reporters that Ayrton drives like he thinks he can’t die**: [Ayrton Senna and Alain Prost’s legendary rivalry](https://www.ayrton-senna.net/ayrton-senna-alain-prosts-legendary-rivalry/) | (ayrton-senna.net) [1:40:15]

**Charles Bronson movie that was mentioned**: [Death Wish (1974 film)](https://en.wikipedia.org/wiki/Death_Wish_(1974_film)) | (wikipedia.org) [1:41:15]

**The race that Jacques Villeneuve said he was going to win (and then did it) in 1996**: [1996 Portuguese Grand Prix](https://en.wikipedia.org/wiki/1996_Portuguese_Grand_Prix) | (wikipedia.org) [1:43:30]

**Damon’s last first place finish was at**: [1998 Belgian Grand Prix in Spa](https://en.wikipedia.org/wiki/1998_Belgian_Grand_Prix) | (wikipedia.org) [1:48:50]

**Where Damon saw the artwork that inspired him to make a change**: [TATE MODERN EXHIBITION—ROTHKO](https://www.tate.org.uk/whats-on/tate-modern/exhibition/rothko) | (tate.org.uk) [1:58:45]

**Philosophers mentioned by Damon**: [2:18:30]

- [Gödel’s incompleteness theorems](https://en.wikipedia.org/wiki/G%C3%B6del%27s_incompleteness_theorems)
- “Whereof one cannot speak, thereof one must be silent.” by [Ludwig Wittgenstein](https://en.wikipedia.org/wiki/Ludwig_Wittgenstein)

§

## People Mentioned

- [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) [4:15, 18:00, 20:00, 51:00, 58:00, 1:25:30, 2:07:30]
- [Michael Schumacher](https://en.wikipedia.org/wiki/Michael_Schumacher) [4:15, 30:45, 58:40, 1:24:45, 1:29:00, 1:40:30]
- [Graham Hill](https://en.wikipedia.org/wiki/Graham_Hill) [4:45, 10:00, 21:45, 38:45, 2:03:45]
- [Lewis Hamilton](https://en.wikipedia.org/wiki/Lewis_Hamilton) [7:15]
- [Dick Dastardly](https://en.wikipedia.org/wiki/Dick_Dastardly) (pencil mustache like Graham Hill)[11:45]
- [David Niven](https://en.wikipedia.org/wiki/David_Niven) (pencil mustache like Graham Hill) [11:45]
- [Errol Flynn](https://en.wikipedia.org/wiki/Errol_Flynn) (pencil mustache like Graham Hill) [11:45]
- [Bruce McLaren](https://en.wikipedia.org/wiki/Bruce_McLaren) [13:00]
- [Stirling Moss](https://en.wikipedia.org/wiki/Stirling_Moss) [13:00]
- [Jo Bonnier](https://en.wikipedia.org/wiki/Jo_Bonnier) [13:00]
- [Taffy von Trips](https://en.wikipedia.org/wiki/Wolfgang_von_Trips) [13:00]
- [Tony Brooks](https://en.wikipedia.org/wiki/Tony_Brooks_(racing_driver)) [13:00]
- [Jim Clark](https://en.wikipedia.org/wiki/Jim_Clark) [14:00, 38:45]
- [Jackie Stewart](https://en.wikipedia.org/wiki/Jackie_Stewart) [14:30, 17:00, 27:00, 1:13:00, 1:56:50]
- [Alex Honnold](https://twitter.com/AlexHonnold?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) (Free Solo climber) [18:30]
- [Gilles Villeneuve](https://en.wikipedia.org/wiki/Gilles_Villeneuve) [20:00]
- [Rubens Barrichello](https://en.wikipedia.org/wiki/Rubens_Barrichello) [20:00, 1:02:30]
- [Roland Ratzenberger](https://en.wikipedia.org/wiki/Roland_Ratzenberger) [20:00, 1:01:00]
- [Niki Lauda](https://en.wikipedia.org/wiki/Niki_Lauda) [20:30, 1:51:15, 1:56:45]
- [Pedro Lamy](https://en.wikipedia.org/wiki/Pedro_Lamy) [20:30]
- [Johnny Herbert](https://en.wikipedia.org/wiki/Johnny_Herbert) [20:30, 30:45]
- [Martin Donnelly](https://en.wikipedia.org/wiki/Martin_Donnelly_(racing_driver)) [20:30]
- [Peter Gethin](https://en.wikipedia.org/wiki/Peter_Gethin) [26:45]
- [Mike Knight](https://www.linkedin.com/company/winfield-racing-school/about/) (founder of Winfield School of Racing) [32:15]
- [Alain Prost](https://en.wikipedia.org/wiki/Alain_Prost) [33:00, 40:45, 48:30, 1:39:30, 1:45:30]
- [Patrick Tambay](https://en.wikipedia.org/wiki/Patrick_Tambay) [33:00]
- [Jacques Laffite](https://en.wikipedia.org/wiki/Jacques_Laffite) [33:00]
- [Barry Sheene](https://en.wikipedia.org/wiki/Barry_Sheene) [34:30]
- [Emerson Fittipaldi](https://en.wikipedia.org/wiki/Emerson_Fittipaldi) [39:30]
- [Jo Ramírez](https://en.wikipedia.org/wiki/Jo_Ram%C3%ADrez) [39:30]
- [Martin Brundle](https://en.wikipedia.org/wiki/Martin_Brundle) [40:00]
- [Mark Blundell](https://en.wikipedia.org/wiki/Mark_Blundell) [40:15]
- [Nigel Mansell](https://en.wikipedia.org/wiki/Nigel_Mansell) [40:30, 54:45, 1:34:45]
- [Frank Williams](https://en.wikipedia.org/wiki/Frank_Williams_(Formula_One)) [40:45, 1:23:40]
- [Riccardo Patrese](https://en.wikipedia.org/wiki/Riccardo_Patrese) [40:45]
- [Sebastian Vettel](https://en.wikipedia.org/wiki/Sebastian_Vettel) [45:00]
- [Patrick Head](https://en.wikipedia.org/wiki/Patrick_Head) [47:00, 1:23:40]
- [Adrian Newey](https://en.wikipedia.org/wiki/Adrian_Newey) [47:00, 1:11:00, 1:24:15]
- [Paddy Lowe](https://en.wikipedia.org/wiki/Paddy_Lowe) [47:45]
- [Josh Hill](https://en.wikipedia.org/wiki/Josh_Hill_(racing_driver)) (Damon’s son) [55:00, 1:48:00]
- [Enzo Ferrari](https://en.wikipedia.org/wiki/Enzo_Ferrari) [1:19:50]
- [David Foster Wallace](https://en.wikipedia.org/wiki/David_Foster_Wallace) [1:33:00]
- [Charles Bronson](https://en.wikipedia.org/wiki/Charles_Bronson) (actor in Death Wish film from 1974) [1:41:15]
- [Jacques Villeneuve](https://en.wikipedia.org/wiki/Jacques_Villeneuve) [1:42:00]
- [Jack Nicklaus](https://en.wikipedia.org/wiki/Jack_Nicklaus) [1:44:15]
- [David Letterman](https://en.wikipedia.org/wiki/David_Letterman) [1:46:45]
- [Eddie Jordan](https://en.wikipedia.org/wiki/Eddie_Jordan) [1:48:45]
- [James Hunt](https://en.wikipedia.org/wiki/James_Hunt) [1:56:00]
- [Max Mosley](https://en.wikipedia.org/wiki/Max_Mosley) [2:07:30]
- [Elon Musk](https://en.wikipedia.org/wiki/Elon_Musk) [2:15:00]
- [Boyan Slat](https://en.wikipedia.org/wiki/Boyan_Slat) (young guy invented new way to clean up the ocean) [2:15:00]
- [Abe Lincoln](https://en.wikipedia.org/wiki/Abraham_Lincoln) [2:18:00]
- [Kurt Gödel](https://en.wikipedia.org/wiki/Kurt_G%C3%B6del) [2:18:30]
- [Ludwig Wittgenstein](https://en.wikipedia.org/wiki/Ludwig_Wittgenstein) [2:18:30]

§