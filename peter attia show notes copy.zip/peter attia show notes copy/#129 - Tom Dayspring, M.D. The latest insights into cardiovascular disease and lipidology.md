# #129 – Tom Dayspring, M.D.: The latest insights into cardiovascular disease and lipidology

**Source:** [https://peterattiamd.com/tomdayspring6/](https://peterattiamd.com/tomdayspring6/)

---

##### Check out our 5-part series with Thomas Dayspring, M.D., FACP, FNLA, a world-renowned expert in lipidology:

- *(October 15, 2018)* [Part I of V: An introduction to lipidology](/tomdayspring1/)
- *(October 16, 2018)* [Part II of V: Lipid metrics, lipid measurements, and cholesterol regulation](/tomdayspring2/)
- *(October 17, 2018)* [Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins](/tomdayspring3/)
- *(October 18, 2018)* [Part IV of V: statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain](/tomdayspring4/)
- *(October 19, 2018)* [Part V of V: Lp(a), inflammation, oxLDL, remnants, and more](/tomdayspring5/)
- *(September 21, 2020)* [**FOLLOW-UP:** The latest insights into cardiovascular disease and lipidology](/tomdayspring6/)

World-renowned lipidologist Tom Dayspring returns to give an update on the current thinking in lipidology as a follow-up to his 2018 [five-part podcast series](https://peterattiamd.com/tomdayspring1/). In this episode, Tom discusses the growing consensus that atherogenic lipoproteins are essential drivers of atherosclerotic vascular disease. Tom further emphasizes apolipoprotein B (apoB) and lipoprotein(a) (Lp(a)). He provides insights into risk assessment, including which lab metrics to use, how to interpret them, and the appropriate therapeutic targets. Additionally, Tom discusses the most recent developments in lipid-lowering drug therapies—from the continued evolution of PCSK9 inhibitors, to the latest understanding of EPA and DHA, and the most recent addition of bempedoic acid to the list of  therapeutic agents.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/tomdayspring6/the_Drive_public.png)

Play

#129 - Tom Dayspring, M.D.: The latest insights into cardiovascular disease and lipidology

#129 - Tom Dayspring, M.D.: The latest insights into cardiovascular disease and lipidology

1x15s30s

0:002:00:04

## We discuss:

- The latest in the field of lipidology and cardiovascular disease [3:45];
- Apolipoproteins—the key to understanding lipid biology [9:30];
- ApoB as a preferred metric over LDL-P [16:30];
- Therapeutic goals for apoB concentration [21:45];
- Drivers of atherosclerosis [34:15];
- Overview and current thinking on high density lipoproteins (HDLs)—Is it a useful metric? [37:00];
- Lipoprotein(a)—the most dangerous particle you’ve never heard of [55:00];
- Are low density lipoprotein triglycerides (LDL-TGs) a useful metric? [1:13:15];
- Tom’s preferred lab measurements [1:17:45];
- The latest in lipid-lowering therapies [1:21:30];
- The different pathways among various lipid-lowering drugs [1:30:45];
- The latest on EPA and DHA [1:38:15];
- Fibrates—an underappreciated treatment for hypercholesterolemia [1:49:45] and;
- More.

§

## Show Notes

## The latest in the field of lipidology and cardiovascular disease [3:45]

**Many patients are eager for in-depth information about lipidology**

- The first podcast with Tom was the longest Peter has ever done (about 8 hours)
  - It was made into a five-part series ([1](https://peterattiamd.com/tomdayspring1/), [2](https://peterattiamd.com/tomdayspring2), [3](https://peterattiamd.com/tomdayspring3/), [4](https://peterattiamd.com/tomdayspring4/), [5](https://peterattiamd.com/tomdayspring5)) that has become very popular; Peter was surprised at the level of interest, but it shows the topic’s broad appeal
- There have exciting new developments in lipidology and CVD in the two years since the last podcast and we’ll go through those things today

**Recent updates in lipidology**

- Atherogenic lipoproteins are really the issue behind clinical atherosclerotic vascular disease
  - The data have become overwhelming, so guidelines reflect this now
  - Atherogenesis is sterol-mediated, but sterols are trafficked within apoB-containing lipoproteins, which is how they are transported into artery wall where they can start the pathological process

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-1-tom-1024x735.png)

**Figure 1. The process of atherogenesis.**

- Atherogenic lipoproteins are still diagnosed using various cholesterol metrics, but ApoB is within every guideline now (Allan Sniderman has been advocating for this for a long time)
- **What contributes to the atherogenicity of lipoproteins?**
  - TGs have taken center stage – affect concentration and functionality

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-2-tom-1024x685.png)

**Figure 2. Lipoproteins trafficking triglycerides.**

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-3-tom-1024x733.png)

**Figure 3. Lipoprotein structure with high TG levels.**

- HDL is no longer considered informative to use
  - [Lp(a)](https://peterattiamd.com/lpa/) has emerging significance
- Pharmacology has also advanced

\*\*\*

**Topics on today’s agenda:**

- Atherogenic lipoproteins (apoB/LDL-P) are front and center in pathogenesis of CVD
- Methods of risk assessment (e.g., HDL no longer primary)
- What’s developed in therapies – more data around ezetimibe, PSCK9 inhibitors, omega 3 fatty acids, and a few other treatments (expanding on [what we spoke about with Bill Harris](https://peterattiamd.com/billharris/))

## Apolipoproteins—the key to understanding lipid biology [9:30]

**ApoB** & **LDL-P** are used interchangeably, but this is not quite accurate.

*What’s the difference from a biology and lab standpoint?*

- Lipids can’t travel around the body because they are hydrophobic

- - So they attach to apolipoproteins, which solubilize them and provide structure and stability to the lipoprotein
- The main structural protein that enwraps lipids in our plasma is Apolipoprotein B
  - 500 kilodaltons, so pretty big and attracts lots of lipids to bind to it
  - Once bound, it’s a water-soluble lipid transportation vehicle
- The HDL particles have ApoA-I instead of ApoB
- Called beta-lipoproteins with ApoB and alpha-lipoproteins with ApoA-I
- ApoB is made by liver

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-4-tom-1024x784.png)

**Figure 4. Production of apoB particles by the liver.**

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-5-tom-1024x766.png)

**Figure 5. Secretion of apoB particles by the liver.**

- The small intestine, which absorbs a lot of lipids, also makes ApoB
  - The liver produces a large size called apoB100, in intestine truncated version called ApoB48 (chylomicrons are the lipoproteins made by intestine)
  - From intestine goes into lymphatics, from liver secreted directly
- Chylomicronemia is not a major problem for people without genetic issue, they’re postprandial
- Liver makes apoB100 particles, some secreted, others catabolized into smaller particles: VLDL, IDL, and LDL, and Lp(a) if produced (not everyone does in significant amounts)
  - The names derive from ultracentrifugation, float if lower density
  - So apoB family is VLDL, IDL, LDL, and Lp(a) if have it
- But have to look at plasma residence times since these are the things that traffic sterols into artery wall
  - Chylomicrons: half life minutes, plasma residence a few hours
  - VLDL: half life 2-6 hours depending on how rapidly catabolized

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-6-tom-1024x631.png)

**Figure 6. VLDL lipolysis.**

- - ID:  around for an hour or two, not a player
  - LDL: plasma residence 2-5 days
- the longer it’s there, the more particles you have
- Because of half life, 90-95% of apoB particles are LDL particles
  - So apoB is basically just another way of saying LDL particle count. Even if there are remnants, their particle number is small, so LDL is king and metrics use it (and non-HDL cholesterol)

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-7-tom-1024x683.png)

**Figure 7. Lipoprotein carriers of apoB.**

## ApoB as a preferred metric over LDL-P [16:30]

- Peter switched to ApoB in practice due to consistency factor
  - Had used LDL-P, but went through 3 technologies (2 generations of NMR plus electrophoresis)
  - electrophoresis most accurate, but problematic when don’t know what comparing it to –  1st generation NMR (probably still used by many commercial labs) is inaccurate compared to 2nd generation NMR, but those percentiles are still what we use to understand where someone lies
  - With diagnostics, it matters where the reference range is and if you’re moving it
- We can’t always use the same lab, so apoB a better thing to measure
  - Pick your favorite metric and stick with it (Peter and Tom both use ApoB)
  - For all biomarkers, try to use the same lab and assay
  - ApoB assay is commonly available and doesn’t vary widely like NMR
- All guidelines talk about ApoB and get you fewer false positives when using ApoB
- As NMR got better, we started to see unexplained discordance between LDL-P and ApoB
  - Peter says 2nd gen NMR is almost too sensitive, seeing discordance that exceeded predicted discordance, so started using ion mobility assay
- Also economic reason – not expensive to measure ApoB (in Canada, $3-4), so that’s not an excuse
  - Allan Sniderman just mentioned the cost of ApoB assays in a [paper](https://www.atherosclerosis-journal.com/article/S0021-9150(18)31456-4/fulltext) – it’s [no longer true](https://www.sciencemag.org/news/2017/12/it-time-retire-cholesterol-tests#:~:text=Sniderman%20asserts%20that%20routine%20apoB,many%20others%20from%20unnecessary%20treatment.) that it’s prohibitively expensive

## Therapeutic goals for apoB concentration [21:45]

**Smoking and hypertension** are two biggest risk factors for CVD, and both seem to do so by creating an injury to the [endothelium](https://en.wikipedia.org/wiki/Endothelium).

But are we sure that it’s apoB-bearing particles in presence of injured endothelium that begins this destructive process of taking cholesterol into the injured space and creating inflammatory response that results in so much damage?

- Peter’s patient (woman in late 60’s): TC 300, LDL 220, apoB 170, and her CAC is zero, not treated with any lipid lowering therapy
- Not all smokers get lung cancer – why not?  Have to individualize risk factors.
  - Particle number is usually a major factor but not always
  - Endothelial function matters, but it’s hard to measure
  - More and more, we see it’s not just particle concentration but also quality.  Look at other components: other proteins that are on them, complex lipidome, etc. Maybe in you, a given particle concentration is more worrisome than in another person.
- Atherosclerosis is a multi-complex, multifactorial disease. Don’t just get a patient’s numbers down – focus on other things that might be injuring the endothelium of artery wall

***Is there a limit to the benefit of reducing numbers?******Diminishing returns or even harm?***

- Peter has talked about this with [Ron Krauss](https://peterattiamd.com/ronkrauss/) before. The causal relationship between ApoB and atherosclerosis is as strong as anything we see in medicine (for which we can’t do a perfect experiment)
- But it might not be clear what dose/response looks like—What do we know about risk reduction in lowering from 60 to 40 to 20, both pharmacologically and non-pharmacologically (e.g., in [Mendelian randomization](https://en.wikipedia.org/wiki/Mendelian_randomization) studies)?
- In studies we come across the concept that **lower is better** — That said, you do need a few apoB-containing lipoproteins because they traffic other lipids, but hypobetalipoproteinemia is not a problem like abetalipoproteinemia.
- Studies suggest getting a **50% reduction** as the most “bang for your buck” — Beyond that, you do get an incremental reduction, but it’s a much smaller increment of risk reduction.
- And there’s no signal of harm with [proprotein convertase subtilisin/kexin type 9 inhibitors (PCSK9i)](https://www.mayoclinic.org/medical-professionals/cardiovascular-diseases/news/pcsk9-inhibition-a-game-changer-in-cholesterol-management/mac-20430713), we are routinely seeing patients who can get apoB into the 20-40 mg/dL range.

***How much of our cholesterol is in circulating lipoproteins vs. in cell membranes?***

- Plasma glucose represents a tiny fraction of total body glucose. Likewise, plasma cholesterol is a small portion of total body cholesterol (most is in the cell membrane or steroidal producing tissue and the circulating amount is a very narrow part of it).  When measure total body cholesterol in plasma, (say 200 mg/dL down to 100), have not cut cholesterol half, only cut the amount carried by lipoproteins in plasma by half
- We have total body cholesterol: brain (separate system that not discussing today), all peripheral cells, or circulating in plasma
  - Within plasma: a tiny amount bound to albumin, more within lipoproteins (apoB and ApoA), and red blood cells (RBCs), which carry more cholesterol than all of your lipoproteins put together
  - The amount of cholesterol in lipoproteins has no correlation with the amount in cells or RBCs
  - Modulating lipid cholesterol metrics says nothing about cellular cholesterol content.  Don’t worry if LDL cholesterol is low – still have plenty.  You have *de novo* synthesis, put in cell membrane or other organelles, and if steroidogenic tissue the body can produce a little more.  Under low LDL-C circumstances, no cell is being deprived of cholesterol

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-8-tom-1024x666.png)

**Figure 8. Cholesterol pool sizes—there’s more cholesterol in red blood cells than the amount in all lipoproteins combined.**

## Drivers of atherosclerosis [34:15]

**Driver of atherosclerosis**

- RBCs, which contain a lot of cholesterol within their membranes and are able to traffic past the endothelium — but they are NOT the primary driver of atherosclerosis
- Histologically we know it’s [foam cells](https://en.wikipedia.org/wiki/Foam_cell)
- *Where do foam cells get sterols?* ⇒ From **ingesting oxidized lipoproteins** carrying cholesterol
- There is no evidence that RBCs are the driver

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-9-tom-1024x775.png)

**Figure 9. The vaso vasorum and luminal sides of an artery wall.** Image credit: Dayspring graphic published in Textbook of Atherectomy, Chapter 1, by Peter P. Toth and Nicolas W. Shammas.  HMP Communications LLC, 2016.

- The vaso vasorum (located on the non-luminal side) of an artery wall needs blood vessels to keep the artery itself alive, as opposed to the luminal side, where the endothelial lining is damaged by everything
- Histology makes a clear case it’s not the membrane cholesterol that’s doing this, it’s the trafficked cholesterol that ultimately becomes a foam cell when macrophages ingest sterol-laden lipoproteins

As plaque grows, it becomes prone to erosion or rupture:

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-10-tom-1024x742.png)

**Figure 10. Plaque erosion and rupture**

The vaso vasorum could be contributing clotting factors or something else to that process, so it’s not totally uninvolved, but it’s also not a major factor. It comes in only once there is damage.

## Overview and current thinking on high density lipoproteins (HDLs)—Is it a useful metric? [37:00]

**History**

- 1950s to late 1970s: Ancel Keys [postulated](https://web.archive.org/web/20140327233831/https://www.epi.umn.edu/cvdepi/essay.asp?id=33) an association between lipids and CAD, [identified the relationship](https://www.ahajournals.org/doi/10.1161/01.CIR.28.3.381) in an early study, and then [established](https://en.wikipedia.org/wiki/Seven_Countries_Study) the association with a large study involving multiple countries. The top and bottom 10% serum cholesterol groups have big differences in atherosclerosis.
- Early 1980s: scientists just starting to talk about subfractionation of cholesterol (different densities)
- Late 1970s and into 1990s: HDL emerged as a contrast to LDL. Jerry Reaven was [starting to identify](https://www.sciencedirect.com/science/article/abs/pii/0899900797908789?via%3Dihub) metabolic syndrome (then called syndrome X). Higher levels of HDL cholesterol were associated with the syndrome

> “Folks, there’s one cholesterol molecule. …  If I drew you the structure of cholesterol it’s identical. How dare we put an adjective on it like that’s “good” and that’s “bad”?  How do you know?  You don’t.  So they’re silly terms.” —Tom Dayspring

It’s ridiculous to call HDL “good” and LDL “bad” – cholesterol molecules are the same.  But why was HDL considered so important when now it’s an afterthought?  All current risk algorithms still use HDL as a risk-determining metric, but it’s 40-50 years old

- All those studies were never adjusted for anything else – turns out that most people with low HDL cholesterol also have high apoB, which is what’s driving atherosclerosis
- Use HDL-C to figure out lipid component of overall risk, but no trial has ever shown there is CV benefit to changing HDL numbers

Multiple trials have used technical approaches to raise HDL number, but at best those trials (as well as [Mendelian randomization](https://en.wikipedia.org/wiki/Mendelian_randomization) trials) have shown it is neutral and at worst harmful.

One can have high HDL-C and plaque or low HDL-C and not much risk.  The metric HDL cholesterol by itself is useless. It’s measuring the concentration of cholesterol within HDL particles but tells you nothing about the functionality of that particle.

- Allan Sniderman and Ron Krauss have said that the relationship of LDL biology to risk is [relatively simple](https://www.tandfonline.com/doi/pdf/10.2217/17460875.3.3.257) – all you have to do is lower it.  It’s the HDL biology that’s really [complicated](https://www.meandmydiabetes.com/2010/03/26/ldl-cholesterol-ron-krauss-md/).  HDL is what the 21st century will be about
  - We need a test for HDL functionality, which may be beyond the scope of labs. You can measure apoB and LDL – the more you have, the more problems you have. With HDL, the problem is way harder and we don’t have a clue what we’re talking about
- We use lab metrics to figure out what a given biomarker tells us and what to do, but HDL-C is the only available metric – can also get an HDL particle count, but it’s not particularly useful beside the metric.
- HDL must perform some function in the body, maybe preventing plaques or “putting out arterial wall plaque fires,” but how can we measure its functionality?  HDLs are like fire engines, but fire departments have many kinds of trucks that all supply something different. What type of truck do we need at a scene?  Depends on the scene.

***What do HLDs do?***

- They traffic some amount of cholesterol, but may be just to make it spherical so other things can attach.  HDLs are tiny and don’t carry much cholesterol.  The average size HDL particle carries about 45 cholesterol molecules, while the average LDL carries 1500-2000
- If HDL is carrying extra TG, it can’t carry much cholesterol.  If HDLs have different surface phospholipids or proteins, all have apoA-I, but what else are they carrying? Those proteins have a multitude of functions.
- Dan Rader used to tell Tom that HDLs are part of the [innate](https://pubmed.ncbi.nlm.nih.gov/16046400/) [immune](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2828473/) [system](https://pubmed.ncbi.nlm.nih.gov/20686620/) – little fire engines carrying things that go into areas with inflammation. Maybe they carry immunomodulatory functionality molecules, or maybe they inflame it further.

- 150 different proteins might be scattered on various HDL subpopulations.  In our lifetime there might never be an affordable, reproducible, high-throughput way of evaluating this.  It’s so complicated and it could be doing both positive and negative things with cholesterol.  The HDL function panel will consist of dozens of tests, but we won’t do the research and no one will pay for them.
- Peter says we do not know what to do with existing HDL panels.  Peter doesn’t even look at apoA-I anymore: looks at VLDL (as proxy for remnants), TG, ApoB, Lp(a), and metabolic markers– glucose, insulin, homocysteine, uric acid, BP, etc.
- Tom says HDL panels are being offered to generate revenue – they’re hocus pocus. They are reporting HDL size, but you can have 1-5 molecules of ApoA-I on each HDL, so it doesn’t tell you much.  Compared against ApoB, ApoA-I contributes nothing
- Need research on HDL functionality.   Would love to test flux of HDL: how do they mature, fill with cholesterol, what do they do with cholesterol?  Are they catabolized or not catabolized?   Are HDLs pulling cholesterol out of the artery wall?  Do they then share with an LDL that puts it right back into the artery? But right now, don’t waste your money, time, or brain energy on figuring out HDL metrics.

## Lipoprotein(a)—the most dangerous particle you’ve never heard of [55:00]

**Lp(a) resources**:

- Previous podcasts covering Lp(a): [Part 5 with Tom Dayspring](https://peterattiamd.com/tomdayspring5/), [AMA #15](https://peterattiamd.com/ama15/), and [Deep Dive: Lp(a)](https://peterattiamd.com/lpa/)
- Peter hopes to have [Sam Tsimikas](https://twitter.com/lpa_doc?lang=en), an expert on Lp(a), on the podcast in the near future.

\*\*\*

**Overview of Lp(a)**

- About [1 in 10 people have an elevated Lp(a)](https://www.sciencedirect.com/science/article/pii/S0019483218312781#:~:text=According%20to%20the%20National%20Heart,(ASCVD)%2C%20calcific%20aortic%20valve), which is the greatest genetic driver of atherosclerosis
- Some people have heart attacks young, and generally it’s Lp(a) until proven otherwise
- Everyone needs to find out if they’re a high Lp(a) carrier (See Anahad O’Connor’s [NYT story](https://www.nytimes.com/2018/01/09/well/heart-risk-doctors-lipoprotein.html) about Lp(a) carriers)
- We might not learn much more about HDL, but we’re just scratching the surface of Lp(a) with Mendelian trials providing evidence of Lp(a) being dangerous

**Structure of Lp(a)**

LDL is cholesterol, TG, and phospholipids wrapped by a single molecule of ApoB.  The subclasses are heterogeneous.

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-11-tom-1024x808.png)

**Figure 11. LDL structure.**

Lp(a) has an LDL particle, but co-attached to ApoB is another protein called apo(a) that shouldn’t be there.  So Lp(a) is basically an LDL carrying an extra passenger, apo(a)

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-12-tom-1024x727.png)

**Figure 12. Structure of LDL with and without Lp(a)**

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-13-tom-1024x768.png)

**Figure 13. Relationship between Lp(a) and LDL-P**

**Risk of having high Lp(a) and apo(a)**:

- Some people with high Lp(a) are fine
- Others have disease early in life
- We need to understand the *quality of Lp(a)* – such as why is the [apo(a)](https://en.wikipedia.org/wiki/Apolipoprotein_A1) attachment terrible for some people and not others?

*Apo(a) —*

- Apo(a) has thrombogenic properties
- However, another function might be that it’s a scavenger protein that binds with great affinity to oxidized lipid moieties (oxidized phospholipids and sterols) and maybe brings them back to the liver or other tissue that can catabolize them therefore preventing oxidized moieties that tend to be destructive to cells from reaching the cells.

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-14-tom-1024x770.png)

**Figure 14. Oxidized Phospholipids on Lp(a)**

Metrics are available to measure these oxidized lipid moieties on apo(a), called oxidized phospholipids on ApoB [oxPL-apoB].

- The vast majority of ApoB particles trafficking oxidized phospholipids are Lp(a) particles
- If 2 people both have elevated Lp(a), who should be more concerned?
  - One has normal oxidized phospholipids in ApoB but they are elevated in the other
  - Based on work by [Sam Tsimikas](https://twitter.com/lpa_doc?lang=en), we should be more worried about the person with elevated oxidized phospholipids
  - Because at this point, we’re nowhere near being able to test for thrombogenicity of apo(a)

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-15-tom-1024x766.png)

**Figure 15. Relationship between Lp(a) and apo(a)**

- While we’re waiting to get him on the podcast, you can follow the work of Sam Tsimikas on twitter ([@Lpa\_Doc](https://twitter.com/lpa_doc?lang=en))
- New European guidelines say have an Lp(a) test once in your life. It’s a genetically determined marker, you either have it or not.  But first let’s do a good CV risk assessment no matter what your numbers are. This test should be part of history and work up

**What do you do for someone with high Lp(a)?**

- The strategies are mostly attacking apoB or other factors (Drugs in pipeline may stop liver from making apo(a))
- If Lp(a) is elevated and problematic in a patient (which shows up in family history – e.g., lots of heart attacks before age 60 – and is not subtle), this is the only strategy.
- The Journal of the American College of Cardiology recently published a [study](https://www.onlinejacc.org/content/76/7/781) and an [editorial](https://www.onlinejacc.org/content/76/7/794?download=true) – looked at people with bad family histories and who had issues with Lp(a) or not
  - It concluded that high Lp(a) is a problem, and bad family history a problem, but having both is the worst.
  - The best advice is to choose healthier parents! (wink wink)
- If a patient has high Lp(a) and a bad family history or positive CAC, etc., historically we’d **lower all other risk factors** (apoB and metabolic parameters like BP, uric acid, homocysteine, etc.) to the extent possible.

**What if we could control the liver’s ability to make apo(a)?**

- This is very early in the pipeline, but the idea is the following:
- Could we mess with genes and stop cells from making apo(a)?
- Then there would be no Lp(a) particles.
- Inhibiting synthesis would be good, but what if that has a downside and screws up something else?
- Drugs are in early development now and will get better over subsequent generations
- We must invest many millions up front, need first trial to work so will only use sicker patients like those with previous MI or stroke and really high Lp(a).
- It takes 3-5 years to show efficacy and safety, then subtrial analysis, then will anyone even fund a primary prevention trial?
- You’re going to wait 5-10 years, and not for prevention

**Until 5 years ago, statins were the most potent drugs to lower LDL (and apoB), but they have virtually** ***no effect on Lp(a)*****.**

**So how are the latest PCSK9 inhibitors able to lower Lp(a)?**

1) There are enough trials to show that risk depends on your apo(a) makeup – do you produce low or high molecular weight apo(a)?  Smaller molecular weight apo(a) seems to be more associated with atherosclerosis, allowing the liver to produce more and thus a high particle count. Statins can induce synthesis of the smaller apo(a) but do not affect synthesis of larger apo(a) moiety. (Even Sam Tsimikas will say don’t worry about statins raising Lp(a) – it’s a minority LDL particle.) Statins are still lowering the LDLs that matter clinically

2) PCSK9i don’t have an effect on the synthesis of apo(a) in the body, but we’re still trying to understand how Lp(a) particles are catabolized and cleared; it’s probably by multiple receptors.  You get more LDL receptors with PCSK9i than a statin can. PCSK9i reduce the catabolism of apoB receptors and 3-4 other lipoprotein-clearing receptors, so on PCSK9i you get better clearance of particles than you do with LDL receptor expression mediated by statins (or statins plus another drug). Most of the time we use a stain plus a PCSK9i unless the patient can’t tolerate a statin. We still don’t have a lot of information about clearance of Lp(a) particles

- In Peter’s practice, he sees 0-70% reduction in Lp(a) in patients on PCSK9i.  This is a very broad range and the median reduction is maybe by a third
- But keep in mind that Lp(a) is *not an acceptable goal of therapy yet* because there is no trial data to support it, so we are not making therapeutic decisions based on Lp(a) concentration

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-16-tom-1024x786.png)

**Figure 16. The effect of PCSK9 inhibitors on LDL receptors**

## Are low density lipoprotein triglycerides (LDL-TGs) a useful metric? [1:13:15]

***What about the experimental metric LDL-TG concentration?*** (an easy assay made by Denka)

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-17-tom-1024x685.png)

**Figure 17. Components of serum triglycerides**

Having other molecules on or within LDLs and HDLs make them less clearable and more atherogenic. A very recent [study](https://heart.bmj.com/content/106/10/738) showed that there are Lp(a) particles that carry ApoC-III. You’re not going to clear that if you make it

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-18-tom-1024x803.png)

**Figure 18. ApoC-III promotes inflammation.**

If he could only have one lipid concentration, Tom would pick LDL-TG level instead of LDL cholesterol level. (He’d really take ApoB, but that is a lipoprotein metric, not a lipid metric)

The TG part of any lipoprotein has a lot to do with plasma residence time, what else is attached, or even something like [what Dan Rader calls “fat” HDLs](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2803051/) – not carrying many cholesterol molecules but carrying TGs. Dan has discussed how [TG-rich HDLs act differently](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1679714/)

- If TGs get into LDL, it has a great affinity for lipase enzymes that are looking for TGs. It binds to it and hydrolyzes TGs, and now you have small LDL or dense LDL.
- There is evidence that an increased total LDL particle number is not good, but small LDLs are more atherogenic than the more buoyant, larger LDLs.  If LDL-TGs are high, there’s a high LDL particle count, a high ApoB, and small LDL particles.
- The TGs probably came from VLDLs and chylomicrons which became remnant-like proteins. TGs invading HDL particles affect their functionality too.
- In studies looking at LDL-TG, many inflammatory markers are high because those particles set off the inflammasome in endothelial cells and elsewhere. It’s a simple easy metric that tells us a lot. If it’s high, you’re likely dealing with an insulin resistant person rather than some less common genetic TG problem.

***Why are we not bringing LDL-TG to a wider market?***If you look at VLDL cholesterol and markers of insulin resistance along with lipoprotein markers, you get the story

## Tom’s preferred lab measurements [1:17:45]

**Peter’s take**:

- Peter thinks it’s worth doing apoB over non-HDL cholesterol
- Yet others say if you have non-HDL you do not need to measure apoB because non-HDL = LDL cholesterol + VLDL cholesterol.

***What does Tom think?***

- Tom is in the Allan Sniderman school of thought:
  - Non-HDL gives you slightly more info than LDL cholesterol.
  - But as [several](https://www.ahajournals.org/doi/10.1161/CIRCRESAHA.119.315019) [Sniderman](https://pubmed.ncbi.nlm.nih.gov/23068583/) [studies](https://pubmed.ncbi.nlm.nih.gov/12745098/) show, even though non-HDL chol correlates a bit better with apoB than does LDL cholesterol, they are discordant in 20-30% of the population (eg, IR, diabetics).
  - When they’re discordant, even with non-HDL and ApoB, **risk follows ApoB**.
  - It’s foolish to say that if you’ve normalized non-HDL, then you have eliminated your LP-mediated risk

> “At the end of the day, I see no need to follow your non-HDL cholesterol.” —Tom Dayspring

***How does Peter determine VLDL cholesterol in his patients?***

- Not by dividing TGs by 5 as in the Friedewald formula.
- Instead, he would use a lab that measures VLDL cholesterol,
  - And if this were not available he would subtract LDL-C and HDL-C from TC.
- But TG/5 is not a very accurate way of calculating VLDL-C.
- You cannot do the calculation VLDL = TC – (LDL + HDL) if you have only calculated LDL – the VLDL-C formula only works with directly measured LDL

## The latest in lipid-lowering therapies [1:21:30]

**Overview and latest with statins**

- There have been no new statins in the last 10+  years; the most recent (pitavastatin, brand name Livalo) was introduced in 2009. Third party payers are not going to pay for a new branded statin; there are 7 on the market so there won’t be a new one.  New ones are unlikely to avoid statin downsides.
- Used to put people on statin for trivial increase in LDL or just to reduce MI risk. Now,  once you cross a certain threshold of risk, it makes sense to consider statin, but more than just LDL level is a factor.  Consider CAC, Lp(a), family hx, BP etc. – current guidelines say use these to help make decisions. No one says statins should be in the drinking water anymore!

*Process for choosing a statin*

- Peter’s practice only uses 4 of 7: Livalo (pitavastatin), Crestor (rosuvastatin), Lipitor (atorvastatin), and Pravachol (pravastatin).
- Peter still pushes for brand name when he can get it – his default position is that generics are crap until proven otherwise.
- Use Livalo and Pravachol for stain-sensitive patients, others are workhorses.  Pravastatin is safer than simvastatin or lovastatin for reasons mostly related to drug-drug interactions.  Livalo is even better at minimizing drug-drug interactions. People are often taking many supplements, not just other prescription drugs, so you can’t always check for interactions and will have less trouble if you use a low drug interaction option.
- Rosuvastatin is way more potent than pravastatin (both are hydrophilic and somewhat hepatoselective), so Tom uses it most of the time (unless third party payor issues). Hydrophilic statins are less likely to get into the brain

**Therapeutic options**

- Current guidelines say to pick one of the two most potent stains (Lipitor or Crestor) and prescribe at the maximum dose with the assumption that the lower level the better.
- However, Tom thinks statins’ real contribution to risk reduction is **apoB reduction**
- The idea is to start with a smaller dose of statin (depending on risk) and optimize with a second apoB-lowering drug such as:
  - [Ezetimibe](https://en.wikipedia.org/wiki/Ezetimibe)—shown to be effective by trials as well as Mendelian randomization studies with the Niemann Pick C1-like 1 (NPC1L1), and/or…
  - [Bempedoic acid](https://en.wikipedia.org/wiki/Bempedoic_acid)—the “*new guy on the street*”—a weaker cholesterol synthesis inhibitor affecting an earlier cholesterol synthesis step (which has [also been suggested to be effective with Mendelian randomization](https://www.nejm.org/doi/10.1056/NEJMoa1806747))

**In summary**: A triple therapy—statin, ezetimibe, and benpedoic acid—can be used to avoid the expense of PCSK9 inhibitor

## The different pathways among various lipid-lowering drugs [1:30:45]

The cholesterol synthesis pathway has 37 different steps, each with its own enzyme.

- Statins—
  - Inhibit the rate-limiting enzyme at the 3rd step (HMG CoA Reductase) in a dose-dependent fashion
  - You really want to focus on liver cells, which have the greatest propensity to target the LDL receptors that clear apoB
- Ezetimibe—
  - If you can deplete cholesterol pools beyond what statins can do in the liver, you will express more LDL receptors.
  - **Ezetimibe** blocks intestinal absorption of cholesterol or the backflow of bile cholesterol into the liver, increasing expression of LDL receptors and further depleting hepatic cholesterol pools
- Bempedoic acid (BA)—
  - BA is a newer option — it is an ATP citrate lyase inhibitor
  - The first step in cholesterol synthesis is converting citrate to acetyl CoA, which becomes HMG and so on.
  - BA is a pro drug—It is taken up only by the liver and inhibits a liver enzyme so that you cannot make acetyl CoA.
  - The less you make, the less HMG you make, providing even less substrate for statins, and the result is lower ApoB

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-19a-tom-1024x578.png)

**Figure 19a. Pathways of lipid-lowering drugs**. Image credit: Dayspring created graphic that served as the basis for a figure that appeared in a treatment-MOA article by [Michos et al., 2019](https://www.nejm.org/doi/10.1056/NEJMra1806939?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed)

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-19b-tom-1024x510.png)

**Figure 19b. Corresponding steps in figure 18a.**

The biggest downside of statins is myopathic symptoms (weak muscles, muscle aches)

- BA is hepato-selective and has no uptake in muscle cells.
- Rosuvastatin is somewhat hepato-selective but can still get into muscle and give you aches.
- Even PSK9 inhibitors had some evidence of muscle soreness (even though the mechanism is unclear like it is with statins), although the same is true with placebo.

The FDA approved BA (brand name Nexletol) but said a big outcome trial was needed, which the manufacturer is doing. [Mendelian analysis has suggested it would work.](https://www.nejm.org/doi/10.1056/NEJMoa1806747) The FDA let it on the market after a Phase 3 safety trial. (For ezetimibe, Mendelian studies suggested that reducing intestinal absorption of cholesterol would decrease CV events, and that turned out to be correct in outcome trials.)  You can add BA to a statin in people with familial hypercholesterolemia (FH), very high-risk people, or statin-intolerant patients, and/or you can give it with ezetimibe.

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-20-tom-1024x806.png)

**Figure 20. Pathway of bempedoic acid.**

So we have several apoB-lowering options today that follow a standard path: statins, ezetimibe, bempedoic acid, rarely used bile acid sequestrants, and PCSK9 inhibitors.

> “It’s a fun time to be in the apoB world. We have a lot of therapies.” —Tom Dayspring

And we’re not even talking about TGs, for which there are also therapies that might contribute to apoB lowering.

***Statins work by regulation of hepatic LDL receptors. How does BA work? Is it about inhibiting synthesis?***

- If it inhibits synthesis, it will also upregulate LDL receptor expression (and maybe other receptors too), so in the end it’s depleting the hepatic cholesterol pool.
- BA is attractive because it is more hepatoselective (even if less potent)
- Trials suggest that BA monotherapy produces 10-18% lowering of LDL (similar to ezetimibe) and a 10-12% decrease in apoB.
- Ezetimibe + statins result in a wide range of decreases because people’s reactions vary.

## The latest on EPA and DHA [1:38:15]

- Mendelian studies suggest that certain genes are involved with TG and atherosclerosis, so it’s plausible that you could reduce disease if you improve TGs.  For a long time, we used lifestyle, niacin, and fibric acid (until they did badly designed trials that concluded fibrates didn’t work because they didn’t give them to any subjects with high TGs). But there has always been an idea that omega-3s could lower TGs.
- [As Bill Harris says](https://www.ahajournals.org/doi/full/10.1161/CIR.0000000000000709), to get lower TGs with omega-3s, you need to use serious doses (not 1 or 2 g). Omega 3s likely have other as yet unknown attributes, as they are a crucial part of cell membranes and signaling. Use maximum dose – about 4000 mg/d – if you want to use omegas to help lower TGs.
  - Trials were done giving 4 g/d to people who had high TGs (many of whom also had low HDL). The [first](https://pubmed.ncbi.nlm.nih.gov/17398308/) [trials](https://pubmed.ncbi.nlm.nih.gov/18667204/) were done in Japan about 10 years ago, giving subjects EPA only (we’re not sure why) on top of a stain.  The patients did not necessarily have high TGs, but many did.  The studies were not blinded but produced evidence that EPA at a high dose (4 g) reduces macrovascular outcomes when given with a statin.
  - Amarin, the company that makes branded EPA (Vascepa), did a major clinical trial called [REDUCE IT](https://www.nejm.org/doi/full/10.1056/nejmoa1812792) which enrolled people taking stains to get LDL below 70 (generally high risk people). You had to have TG = 135+ to get into trial; most were around 150.  They were maximized on whatever stain they used to get LDL-C under 100.  High dose EPA (2 g BID with food) led to almost 30% residual risk reduction.
- Tom and Bill Harris believed you could also just give 4 g of EPA/DHA. DHA is important too (brain and cell membranes need it), and although most people can convert EPA to DHA, not all can.
- AstraZeneca acquired a free omega-3 fatty acid (not an ethyl ester, so has better absorption, pharmacokinetics and bioavailability) called Epanova, which is free EPA and free DHA. It enrolled high TG patients in the STRENGTH trial but [stopped the study after 2 years](https://www.cardiovascularbusiness.com/topics/lipids-metabolic/astrazeneca-stops-epanova-trial-early) (in November 2019) and the data has never been published. [1:44:50] Stopping the study took a lot of people off guard. AstraZeneca announced that it stopped the trial because there was no signal.  There has been surprise and annoyance that the data has not been published, and the reason remains unclear, arousing suspicion.

*Peter asks****: Was the difference the EPA/DHA combo or the vehicle of delivery?***

We aren’t sure and you should have Bill Harris back on to discuss that. We want to achieve a certain level of omega 3s in the blood or cell membrane (they did not measure omega 3 index in the REDUCE IT trial, but rather serum omega 3 FA levels, and this data has been presented but not published). The efficacy of an EPA-only product highly depends on the serum EPA level you achieved in the serum, which supports 4 g/day rather than 2 g/day.

\*\*\*

\* Take home points for EPA/DHA:neFA \*

***Should we use EPA or an EPA/DHA combo?*** You have to go with EPA 4g/d for those in a high-risk category if you want to be evidence based.

***What if TG < 150 (say TG = 100) but still residual apoB risk?***  Not answerable right now.  Tom is not afraid to keep using combo and is a fan of measuring the Omega-3 index.  If you take 4 g EPA but your index shows adequate DHA, he would know that some of that EPA is being converted and be happy.

***What if you take 4 g EPA but your index shows inadequate DHA?*** Then start giving a little DHA too.  Tom doubts that a little DHA is negating EPA, but who knows – maybe it’s true?  We need published data. Peter says the Epanova study did not have enough in common with REDUCE IT to answer that question, but maybe it gives us a clue.  We are doing more EPA trials and sub-analyses now so we will get more information, and we have some angiographic data [[published](https://academic.oup.com/eurheartj/advance-article/doi/10.1093/eurheartj/ehaa652/5898836) after this podcast was recorded]. Plaque looks a lot better if you are taking 4 g of EPA, which is encouraging.

## Fibrates—an underappreciated treatment for hypercholesterolemia [1:49:45]

Tom thinks [**fibrates**](https://en.wikipedia.org/wiki/Fibrate) **are a widely underused drug**.

If identify TG-rich lipoproteins or IR or diabetics, fibrate subtrial analysis shows “miraculous things” for both macro and microvascular endpoints (retina, peripheral nervous system, renal function). They may screw up creatinine levels a bit, but you are improving eGFR (because overproduction of creatinine is not reflective of eGFR).

- [Fenofibric acid](https://en.wikipedia.org/wiki/Fenofibrate), sold as Trilipix, is the purest as it is the only one that isn’t a prodrug. If you have to use one, use Trilipix.
- A new fibrate is pemafibrate (Parmodia), a selective peroxisome proliferator-activated receptor alpha receptor modulator (SPPARM). There are big outcome trials going on right now, so it won’t be used for a while yet.

Niacin, on the other hand, is a “dead drug” that is no longer included in guidelines.  Some Lp(a) advocates (like Sam Tsimikas) will still use niacin in certain cases, but few still agree with that approach

*Back to fibrates*:

- Peter has 3-4 patients on Trilipix and it’s a “world beater.” One patient looked like he had FH & also familial high TG. Peter knew he’d end up on both a statin and a fibrate at some point but wanted to see what would happen with just Trilipix.  TG had been about 400 and apoB > 200, went to TG 100 and ApoB 80-100.  It’s not irrational to try this unless super high risk.
- With Peter Jones, Tom has published [data](https://www.lipidjournal.com/article/S1933-2874(11)00093-6/pdf) using NMR on rosuvastatin and fenofibric acid. Some subjects had very good reductions in LDL-P with fenofibrate, but got much more reduction in remnants with fibrate than with a statin (If TG = 400, you would expect that there is some contribution from remnants)

![](https://peterattiamd.com/wp-content/uploads/2020/09/fig-21-tom-1024x667.png)

**Figure 21. Remnant lipoproteins.**

**The upshot**: \*Don’t forget fibrates!\*

> “A tragedy to me [is that] young lipidologists are not being taught about [fibrates].  Few of them can give you a dissertation on fibrates and how they work. … I find that sad.” —Tom Dayspring

People don’t know the trial history even though there are 40 years of trials; they condemn fibrates without knowing what they’re talking about.

\*\*\*

**Wrap up**

- Peter feels lucky to have been “trained by dinosaurs,” and Tom feels lucky to work with bright young doctors because it keeps him up to date and he can’t rest on his laurels
- Peter discloses that Tom is now working for Attia, mostly on the research side, but he’s brought into maybe 30% of clinical cases and all CV cases.  Tom will also be contributing some written materials to Attia
- We didn’t discuss genetic analysis of lipoproteins, specifically genetic lipidoses like FH.  In the future, we should discuss who needs that type of testing and who doesn’t, what you can do for it, etc.

§

## Selected Links / Related Material

**Allan Sniderman on the cost of Apo B assays:**

- [ApoB in clinical care: Pro and Con](https://www.atherosclerosis-journal.com/article/S0021-9150(18)31456-4/fulltext) **|** (Sniderman & Robinson, 2018) [20:19]
- [Is it time to retire cholesterol tests?](https://www.sciencemag.org/news/2017/12/it-time-retire-cholesterol-tests#:~:text=Sniderman%20asserts%20that%20routine%20apoB,many%20others%20from%20unnecessary%20treatment.) **|** Mitch Leslie (sciencemag.org, December 6, 2017) [20:19]

**Ancel Keys identifies relationship between serum cholesterol and CAD**: [Coronary Heart Disease among Minnesota Business and Professional Men Followed Fifteen Years](https://www.ahajournals.org/doi/10.1161/01.CIR.28.3.381) (Keys et al. 1963) [37:06]

**Jerry Reaven’s presentation about metabolic syndrome (then called syndrome X)**: [Banting lecture 1988: Role of insulin resistance in human disease](https://www.sciencedirect.com/science/article/abs/pii/0899900797908789?via%3Dihub) (Reaven, 1988) [37:06]

**Allan Sniderman comparing LDL’s and HDL’s relationships to risk**: [The case against ApoB and the ApoB:ApoA-I ratio: are they right?](https://www.tandfonline.com/doi/pdf/10.2217/17460875.3.3.257) (Sniderman 2008) [44:07]

**Ron Krauss on the complexity of HDL biology:** [LDL Cholesterol – Ron Krauss MD](https://www.meandmydiabetes.com/2010/03/26/ldl-cholesterol-ron-krauss-md/) **|**  Shelley Schlender (meandmydiabetes.com, March 26, 2010) [44:07]

**Evidence that HDLs are part of the innate immune system:**

- [Human high density lipoproteins are platforms for the assembly of multi-component innate immune complexes](https://pubmed.ncbi.nlm.nih.gov/16046400/) (Shiflett et al., 2005) [47:03]
- [Blockade of T Cell Contact-Activation of Human Monocytes by High-Density Lipoproteins Reveals a New Pattern of Cytokine and Inflammatory Genes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2828473/) (Gruaz et al., 2010) [47:03]
- [HDL interfere with the binding of T cell microparticles to human monocytes to inhibit pro-inflammatory cytokine production](https://pubmed.ncbi.nlm.nih.gov/20686620/) (Carpintero et al., 2010) [47:03]

**About 1 in 10 people roughly have an elevated Lp(a)**: [Lipoprotein(a): An independent, genetic, and causal factor for cardiovascular disease and acute myocardial infarction](https://www.sciencedirect.com/science/article/pii/S0019483218312781#:~:text=According%20to%20the%20National%20Heart,(ASCVD)%2C%20calcific%20aortic%20valve) (Enas et al., 2019)  [55:00]

**Anahad O’Connor’s NYT article on Lp(a):** [A Heart Risk Factor Even Doctors Know Little About](https://www.nytimes.com/2018/01/09/well/heart-risk-doctors-lipoprotein.html) **|** Anahad O’Connor (New York Times, January 9, 2018) [55:43]

**Journal of the American College of Cardiology article and editorial on high Lp(a) and family history**:

- [Lipoprotein(a) and Family History Predict Cardiovascular Disease Risk](https://www.onlinejacc.org/content/76/7/781) (Mehta et al., 2020) [1:03:32]
- [Family History and Lipoprotein(a) Contribute Independently to Risk Assessment and Clinical Management](https://www.onlinejacc.org/content/76/7/794?download=true) (Durrington, 2020) [1:03:32]

**Recent study showing that Lp(a) particles carrying apoC-III are atherogenic**: [ApoCIII-Lp(a) complexes in conjunction with Lp(a)-OxPL predict rapid progression of aortic stenosis](https://heart.bmj.com/content/106/10/738) (Capoulade et al., 2020) [1:13:44]

**Dan Rader study showing that TG-rich HDLs act differently**: [Molecular regulation of HDL metabolism and function: implications for novel therapies](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1679714/) (Rader, 2006) [1:14:40]

**Sniderman studies showing discordance between non-HDL and ApoB:**

- [ApoB: The Power of Physiology to Transform the Prevention of Cardiovascular Disease](https://www.ahajournals.org/doi/10.1161/CIRCRESAHA.119.315019) (Sniderman et al., 2019) [1:17:55]
- [Discordance analysis of apolipoprotein B and non-high density lipoprotein cholesterol as markers of cardiovascular risk in the INTERHEART study](https://pubmed.ncbi.nlm.nih.gov/23068583/) (Sniderman et al., 2012) [1:17:55]
- [Concordance/discordance between plasma apolipoprotein B levels and the cholesterol indexes of atherosclerotic risk](https://pubmed.ncbi.nlm.nih.gov/12745098/) (Sniderman, 2003) [1:17:55]

**Mendelian study suggesting bempedoic acid could work**: [Mendelian Randomization Study of ACLY and Cardiovascular Disease](https://www.nejm.org/doi/10.1056/NEJMoa1806747) (Ference et al., 2019) [1:28:55]

**Bill Harris on using high omega-3 doses to lower TGs:** [Omega-3 Fatty Acids for the Management of Hypertriglyceridemia: A Science Advisory From the American Heart Association](https://www.ahajournals.org/doi/full/10.1161/CIR.0000000000000709) (Skulas-Ray et al., 2019) [1:39:40]

**Japanese trials on EPA and statins**:

- [Effects of eicosapentaenoic acid on major coronary events in hypercholesterolaemic patients (JELIS): a randomised open-label, blinded endpoint analysis](https://pubmed.ncbi.nlm.nih.gov/17398308/) **(**Yokoyama et al., 2007) [1:39:40]
- [Effects of EPA on coronary artery disease in hypercholesterolemic patients with multiple risk factors: sub-analysis of primary prevention cases from the Japan EPA Lipid Intervention Study (JELIS)](https://pubmed.ncbi.nlm.nih.gov/18667204/) (Saito et al., 2008) [1:39:40]

**REDUCE IT (EPA trial)**: [Cardiovascular Risk Reduction with Icosapent Ethyl for Hypertriglyceridemia](https://www.nejm.org/doi/full/10.1056/nejmoa1812792) (Bhatt et al., 2019) [1:39:40]

**Article about AstraZeneca’s aborted Epanova trial**: [AstraZeneca stops Epanova trial early due to disappointing results](https://www.cardiovascularbusiness.com/topics/lipids-metabolic/astrazeneca-stops-epanova-trial-early) **|** Anicka Slachta (cardiovascularbusiness.com, January 13, 2020) [1:44:50]

**Angiographic data from EPA trials:** [Effect of icosapent ethyl on progression of coronary atherosclerosis in patients with elevated triglycerides on statin therapy: final results of the EVAPORATE trial](https://academic.oup.com/eurheartj/advance-article/doi/10.1093/eurheartj/ehaa652/5898836) (Budoff et al., 2019) [1:46:39]

**Tom’s paper with Peter Jones on rosuvastatin and fenofibric acid**: [Effects of Fenofibric Acid in Combination with Statin Therapy on LDL and HDL Particle Number in Patients with Mixed Dyslipidemia](https://www.lipidjournal.com/article/S1933-2874(11)00093-6/pdf) (Jones, Dayspring et al., 2011) [1:51:44]

§

## People Mentioned

- [Allan Sniderman](https://www.cardiomuhc.ca/allan-sniderman) [6:44, 20:19, 44:07, 1:17:55]
- [Bill Harris](https://omegaquant.com/dr-william-s-harris/) [8:49, 1:39:40, 1:46:39]
- [Ron Krauss](https://www.chori.org/Principal_Investigators/Krauss_Ronald/krauss_overview.html) [26:26, 44:07]
- [Jerry Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) [37:06]
- [Dan Rader](https://www.med.upenn.edu/apps/faculty/index.php/g275/p17778) [47:03, 1:14:40]
- [Ancel Keys](https://en.wikipedia.org/wiki/Ancel_Keys) [37:06]
- [Sotirios “Sam” Tsimikas](https://profiles.ucsd.edu/sotirios.tsimikas) [55:03, 1:00:09, 1:10:21, 1:51:44]
- [Peter H. Jones](https://www.cardiometabolichealth.org/peter-jones.html)  [1:51:44]
- [Anahad O’Connor](https://en.wikipedia.org/wiki/Anahad_O'Connor) [55:43]

§

![](https://peterattiamd.com/wp-content/uploads/2018/10/tom-dayspring-300x300.jpg)

##### Thomas Dayspring, M.D., FACP, FNLA

Thomas Dayspring, MD, FACP, FNLA is the chief academic officer for True Health Diagnostics, LLC. He provides scientific leadership and direction for the company’s comprehensive educational programs. Dr. Dayspring is a fellow of both the American College of Physicians and the National Lipid Association. He is certified in internal medicine and clinical lipidology.

Before relocating to Virginia in 2012, Dr. Dayspring practiced medicine in New Jersey for 37 years. Over the last two decades, he has given over 4,000 domestic and international lectures, including over 600 CME programs on topics such as atherothrombosis, lipoprotein and vascular biology, biomarker testing, and women’s cardiovascular issues.

Dr Dayspring is an Associate Editor of the Journal of Clinical Lipidology. He has authored or co-authored numerous manuscripts published across leading journals such as the American Journal of Cardiology, the Journal of Clinical Lipidology, and several lipid-related book chapters. He was the recipient of the 2011 National Lipid Association President’s Award for services to clinical lipidology. [[truehealthdiag.com](https://truehealthdiag.com/leadership/thomas-dayspring/)]

Disclosures:

- Employed full time for last three years by True Health Diagnostics, LLC, which provides biomarker diagnostics and clinical services to clinicians, patients, and healthcare organizations
- 2017: small consulting project for Abbvie

Tom on Twitter: [@Drlipid](https://twitter.com/Drlipid)