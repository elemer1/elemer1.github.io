# #54 – Kevin Sayer, CEO of Dexcom: Continuous glucose monitors – impact of food, sleep, and stress on glucose, the unmatched power of CGM to drive behavioral change, and the exciting future of CGM

**Source:** [https://peterattiamd.com/kevinsayer/](https://peterattiamd.com/kevinsayer/)

---

In this episode, Kevin Sayer, CEO of Dexcom, discusses the remarkable benefits of a continuous glucose monitor for the diabetes population. Peter shares his own invaluable insights he’s learned from wearing a CGM including the impact of sleep and stress on glucose as well as the unmatched power of a CGM to drive behavioral change. Kevin also reveals some of the exciting partnerships and future advancements of their products benefiting not only those with type 1 and 2 diabetes, but also for the growing community of people interested in optimizing health and wellness.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/kevinsayer/the_Drive_public.png)

Play

#54 – Kevin Sayer, CEO of Dexcom: Continuous glucose monitors – impact of food, sleep, and stress on glucose, the unmatched power of CGM to drive behavioral change, and the exciting future of CGM

#54 – Kevin Sayer, CEO of Dexcom: Continuous glucose monitors – impact of food, sleep, and stress on glucose, the unmatched power of CGM to drive behavioral change, and the exciting future of CGM

1x15s30s

0:001:44:35

## We discuss:

- How they met, and Kevin’s path to becoming CEO of Dexcom [7:00];
- How CGM technology works, and what makes Dexcom’s G6 the best model yet [15:15];
- Challenges of working in the US healthcare system and getting CGM insured [21:45];
- Developing an even smaller, more user-friendly, and less costly product while maintaining performance and accuracy [33:15];
- Next thing on the horizon for type 1 diabetes patients [43:30];
- The incredible accuracy of the G6, recommended over-the-counter glucose meters, and the unmatched power of CGM to drive behavioral change [48:15];
- Software improvements for type 2 diabetics, and the remarkable benefits of real-time feedback for driving behavioral change [58:15];
- Dexcom vs. the competitors, the less invasive options, and the fundamental problems needing to be solved with CGM technologies [1:07:00];
- The cost of CGM, why you need a prescription, and when might there be a OTC option? [1:12:00];
- Smartwatch integration, bluetooth technology, and exciting collaborations and partnerships [1:22:00];
- Future places for CGM: Hospitals, nutrition apps, general health and wellness, and more [1:27:15];
- Dexcom’s unique company culture [1:34:15];
- Parenting advice from Kevin [1:37:30];
- Lessons learned through failures and success [1:38:45]; and
- More.

DISCLAIMER: The Dexcom G6 Continuous Glucose Monitoring System (Dexcom G6 System) is a real time, continuous glucose monitoring device indicated for the management of diabetes in persons age 2 years and older. Do not use the G6 if you are pregnant, on dialysis, or critically ill. It is not known how different conditions or medications common to theses populations may affect performance of the system. G6 readings may be inaccurate in these populations. The system requires a prescription (Caution: U.S. law restricts the sale of the G6 Mobile to sale by, or on the order of, a physician). Contact Dexcom Toll Free at 877-339-2664 or https://www.dexcom.com/safety-information for detailed indications for use and safety information.  Future devices are not available for sale in the United States (Caution: Investigational device. Limited by U.S. law to investigational use).

This presentation contains “forward-looking” statements that are based on our management’s beliefs and assumptions and on information currently available to management. Forward-looking statements include all statements other than statements of historical fact contained in this presentation, including information concerning our business strategy, objectives and opportunities; market sizes and potential market growth opportunities; future business and product development; product goals, attributes and performance; the successful integration of acquisitions and commercial relationships; the successful completion of, and timing expectations for clinical trials. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that may cause our actual results, performance or achievements to differ materially and adversely from those anticipated or implied by our forward-looking statements, including, but not limited to, those related to the successful development, regulatory approval and commercialization of our products; the design, implementation and outcomes of our clinical trials; the outcomes of meetings with regulatory agencies; our dependence on third party clinical research organizations, manufacturers and suppliers; market acceptance of our potential products; our ability to develop and maintain collaborations and license products and intellectual property; the impact of competitive products and therapies; our ability to manage the growth and complexity of our organization; our ability to maintain, protect and enhance our intellectual property; and our ability to continue to stay in compliance with applicable laws and regulations. You should refer to the section entitled “Risk Factors” set forth in our Annual Report on Form 10-K, Quarterly Report on Form 10-Q and other filings we make with the Securities and Exchange Commission (SEC) from time to time for a discussion of important factors that may cause our actual results to differ materially from those expressed or implied by our forward-looking statements. You should not rely upon forward-looking statements as predictions of future events. Neither we nor any other person assumes responsibility for the accuracy and completeness of the forward-looking statements. The statements in this presentation are accurate as of September 21, 2018, and we undertake no obligation to update any forward-looking statements after the date of this presentation except as may be required by law.

This presentation also contains estimates and other statistical data made by independent parties and by us relating to market size and growth and other data about our industry. These data involve a number of assumptions and limitations, and you are cautioned not to give undue weight to such estimates. Projections, assumptions and estimates of the future performance of the markets in which we operate are necessarily subject to a high degree of uncertainty and risk.

In addition to our filings with the SEC, press releases, public conference calls and webcasts, we use our website (www.dexcom.com) as channels of distribution of information about our company, our products, our planned announcements, our attendance at upcoming conferences and other matters. Such information may be deemed material information and we may use these channels to comply with our disclosure obligations under Regulation FD. Therefore, investors should monitor our website in addition to following our SEC filings, press releases, public conference calls and webcasts.

Without limitation, this presentation does not constitute an offer, an invitation to offer or a recommendation to enter into any transaction, an offer to sell or the solicitation of any offer to buy any securities, and its contents should not be interpreted as investment, legal, tax, medical or any other advice.

§

## Show Notes

## How they met, and Kevin’s path to becoming CEO of Dexcom [7:00]

How they met:

- Peter and Kevin met on an airplane
- Bonded over watches
- Spoke for an hour before Peter realized Kevin worked at [Dexcom](https://www.dexcom.com/)
- Now Peter is a big proponent of [Dexcom](https://www.dexcom.com/), currently wears the [G6 CGM](https://www.dexcom.com/g6-cgm-system)

Before Dexcom:

- Worked as a finance person with [Medtronic](https://www.medtronic.com/us-en/index.html) starting in 1994
- Medtronic designed the first continuous glucose monitor
- Left Medtronic, and worked for a [drug-eluting stent](https://en.wikipedia.org/wiki/Drug-eluting_stent) business called [Biosensors International](https://en.wikipedia.org/wiki/Biosensors_International) as the head of the US operations and CFO of the entire company
- Moved his family from LA to San Diego in 2011 to be CEO of Dexcom

## How CGM technology works, and what makes Dexcom’s G6 the best model yet [15:15]

[How CGM technology works](https://www.youtube.com/watch?v=PRSKJoUbQmc)

- Designed to measure glucose only
- Small thin wire (like a human hair) inserts into subcutaneous tissue
- That wire and those membranes then generate electrochemical signal that goes up into a transmitter that sits on top of the sensor
- And inside that transmitters is an algorithm that converts that electrochemical signal to a glucose value
- The key is it’s an **enzymatic reaction** which means that it can be done without multiple washes ⇒ Which means this device can’t measure lipoproteins or insulin

How deep is that that little filament that sits inside the patient?

- With the new [Dexcom G6 model](https://www.dexcom.com/g6-cgm-system)
  - Half inch under the skin
  - The insertion technology of the sensor, it goes in with a needle and the needle comes out
  - The needle is in your skin less time that it takes a hummingbird to flap its wings a couple of times so a patient doesn’t feel it
  - And then the sensor rests in the subcutaneous tissue and you really don’t feel that sensor at all
- Most CGM (and even the previous Dexcom G5) are a bit uncomfortable
- Both Kevin and Peter have had patients who just can’t bring themselves to stick the needle in

What makes the G6 so accurate compared to previous models and competitors?

- New membrane technology
- New algorithm

![](https://peterattiamd.com/wp-content/uploads/2019/05/DexcomG6.png)

**Figure 1. The Dexcom G6 CGM.** Image credit: [dexcom.com](https://dexcom.com)

## Challenges of working in the US healthcare system and getting CGM insured [21:45]

How many patients in the United States have type 1 diabetes and type 2 diabetes?

- T1D=Between 1.3-2 million
- T2D=1.5 million who intensively use insulin

How many of those patients use a CGM?

- Between 20 and 30%
- “These percentages have grown rapidly over the past couple of years as we’ve gotten better and as other products of come to the market.”

Who are Dexcom’s main competitors?

- Abbot
- Medtronic

Insurance for type 2 diabetes?

- In January of 2017, they approved the use of CGM for “intensive insulin using” type 2 diabetes patients
- “*That was a step that we really needed.*”

Insurance can be a hassle:

- As the technology advances, more and more people are able to take advantage of the easy use and practicality
- But insurance is paying for these at such an increasing rate that they try to “slow down” the use of them
- So it is a constant battle with between doctors and insurance companies to get the patients covered
- This is frustrating because as Kevin says, “80% of the type 1 population should be using continuous glucose monitoring”

[**This paper suggests**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4928227/) **that a major cost that CGM prevents is hospitalizations**

- Ranging from $10-30k for that one hospitalization
- Some patients are [hypoglycemia unaware](https://www.medicinenet.com/script/main/art.asp?articlekey=22381), who aren’t aware when their blood sugar goes too low
- **The share feature of the G6**:
  - The CGM gives them alerts and alarms and also alarms others who give care to those patients meaning someone in another country could be alerted and can take action (like calling the patient and waking them up)
  - “*That share feature is really one of the most remarkable things we’ve done here.*”

Big savings on the long-term complications of diabetes by using CGM

- Looking at A1C, [studies show](https://www.ncbi.nlm.nih.gov/pubmed/23063035/)…
  - At least a half a point drop over the course of a twelve month period, compared to multiple finger sticks
  - A full point drop for the patient’s, if you just look at them independently on continuous glucose monitoring use for a six-month period that is sustained
  - And that drop in A1C leads to *reduced costs in the healthcare system*

**Here’s the challenge with insurance companies…**

They have a short-term outlook:

- A 25 year-old probably isn’t generating all those complications yet
- And a 25 year-old is with an insurance plan for two years before they move to their next job, and they’re on another insurance plan for two years
- In other words, the insurance company doesn’t care if they get sick in 30 years, they only care about the next couple years

⇒ “*We have to do a better job as a company documenting these economic benefits.*”

- Need run more studies to see how much quality of lives improved, to see what we can prevent
- Dexcom currently building outcome type base models to whereby they can go into an insurance or company or a payer and say, “Look, here’s what we think we can save you if we can put everybody on CGM.”

Medicare

- Recently got [Medicare approval for CGM devices](https://www.dexcom.com/faq/medicare)
- It happened rather quickly, to Kevin’s surprise
- But took some extra time to get approval for the phone app use as well due to “health care industry hurdles”
- “*When you’re creating an industry like that, there are all sorts of hurdles that you run into that you don’t contemplate. You just, kind of, have to react.*”

**The challenge of doing business with the US healthcare system**

- Tough challenge for businesses like Dexcom, “because you don’t exactly know, from a long-term planning standpoint, exactly what changes are going to come about.”
- Benefit of a single-payer system (like Canada): the incentive is aligned between the payer, the patient, the provider, over a long term
  - Example, if you have that 25 year old, and the difference between them have a hemoglobin A1c of 8% vs 6% means nothing in the short run, “*but in 20 years, it matters beyond words”*
  - There are many downsides as well to the single payer system, and it’s probably unlikely to ever be the implemented in the US

⇒ Kevin says

- The good news is that “we’re covered by 99% of all reimbursement authorities”
- Where our coverage is a little spotty still, is in the Medicaid programs
- Where it gets difficult, is the documentation the patients have to provide, or the physicians have to provide, and consistency of co-pays and things of that nature.

⇒ Peter says,

- “We have a really complicated health care system. . .But look, there are some things that I think it does well. And I think one of the things it does well, is it seems to set up an economic engine that allows for an innovation, that I think is hard to do outside of the United States.”

## Developing an even smaller, more user-friendly, and less costly product while maintaining performance and accuracy [33:15]

**Exciting partnership with** [**Verily**](https://en.wikipedia.org/wiki/Verily)

- Verily is Alphabet Inc.’s (Google) research organization devoted to the study of life sciences
- Verily approached Dexcom about partnering: Dexcom to focus on performance and accuracy while Verily will focus on miniaturization and convenience and what consumers like
- Mutually decided it was a great partnership
- So now they are co-developing future Dexcom sensors (much of the electronic side, communication, Bluetooth, etc. have been driven by the Verily engineers)
- “We focus on performance, patient convenience, and usability, and then taking costs out.”

![](https://peterattiamd.com/wp-content/uploads/2019/05/dexcom-verily-cgm.png)

**Figure 2. The smaller sensor (right) being developed with Verily’s for a future model.** Image credit: [dexcom.com](https://dexcom.gcs-web.com/static-files/b7e18dca-02dc-46a6-b89f-c28ac2940a2c)

**Framework and priorities for developing new products**

1 Performance

- Top priority is performance/accuracy of the device
- “If it doesn’t perform, who cares what else it does.”

2 Patient experience

- Next priority is patient experience:
  - Size
  - Ease of use
  - How often do you have to change out the sensor
  - Software

3 Cost

- Trying to make it as economically viable for the most amount of people

***Performance****: Have you maxed out the performance capability or is there more to gain in future models?*

- As far as just bringing the overall accuracy percentage down, there’s not a whole lot to gain
- Where there is to gain on the performance side is pushing the bell curve in on the performance of the sensor to whereby every experience is the same ⇒ aka “eliminating the outliers”
- Consistency and reliability enables us to do two things
  - Number one, it enables us to do very sophisticated things with people who want to control their insulin dosage whether through an artificial pancreas system, or on their own using our data
  - But the other thing it enables us to do, if that performs the same all the time, it will enable us to go out to broader markets because people won’t question or challenge the data.

*With the current model (G6), where does the sensor sit to be able to measure glucose?*

- It sits in the subcutaneous fluid (not in the blood)

*Is it an issue for extremely lean people such as little kids?*

- Only in rare cases

> “One of the most humbling things about this job is when I go out to a diabetes function and meet the children or the adult patients who has had this device save their life, or changed their life the way that it has. . . I know they’re so indebted to our company, and it’s really why we come to work every day, what keeps us going.”

## Next thing on the horizon for type 1 diabetes patients [43:30]

> “The next thing on the horizon for type one diabetes is to develop algorithms to go with the sensor. . . for automated insulin delivery.”

Currently, the G6 will tell you…

- Glucose value
- The trend
- The speed at which you are going up and down
- It will give you alerts and alarms based on what’s going on
- “But we don’t tell you **what to do”**

**New partnership with** [**Tandem**](https://www.tandemdiabetes.com/)

- [Tandem has a new insulin pump](https://www.tandemdiabetes.com/products/t-slim-x2-insulin-pump) that has software to read the information from the Dexcom sensor
- The pump (size of a pager) sits on your body with an insulin cartridge inside
- The pump will decided to turn your insulin on or off/up or down based on the glucose readings from the Dexcom sensor
- Consumer feedback “has been wonderful”

Future advancements in the algorithms

- In time, the algorithms will be able to regulate your insulin delivery all throughout the day whether you’re high or you’re low and detect things like meals (he just ate food, lets delivery insulin now)
- Just acquired an existing algorithm that helps with insulin dosing *during the night time*
- For those without an insulin pump…
  - Decision support: “*We also think we can take these algorithms and apply them to people who use multiple daily injections as well to develop decision support.*”

[CGM can reduce A1C](https://jamanetwork.com/journals/jama/fullarticle/2598770) (and incidences of hypoglycemia)

- Reduced A1C (even if only 8.0 to 7.8 that can make a big difference in long run)
- Reduction in incidences of “bad outcomes” like hypoglycemia and hyperglycemia

⇒ Peter says the *old* thought process was that hypoglycemia was the main thing to worry about even if you needed a higher A1C to avoid hypos (and also that hyperglycemia was not a big deal)

- “*I think the tide is changing. I think people are understanding that because of how long a person is going to live with type one diabetes, the microvascular complications are real*.”
- It’s now thought that [better glycemic control in kids can predict better intellectual performance in school](https://diabetes.diabetesjournals.org/content/64/5/1770)

## The incredible accuracy of the G6, recommended over-the-counter glucose meters, and the unmatched power of CGM to drive behavioral change [48:15]

**Standard deviation**

- CGM allows Peter to see his standard deviation of his glucose levels which is “*another variable that I find very informative.*”
- In his seven day CGM report, he always wants to know the average blood glucose and his standard deviation
- Peter has a condition called [beta thalassemia minor](https://en.wikipedia.org/wiki/Beta_thalassemia#Beta_thalassemia_minor) which means his red blood cells stick around for longer period of time which artificially raises his A1C number (rendering it useless as a measurement)

![](https://peterattiamd.com/wp-content/uploads/2019/05/14dayCGMreport5-1024x872.png)

**Figure 3. Peter’s 14-day CGM report from 2016.**

**The accuracy of the Dexcom G6**

- You are able to calibrate the G6 daily
- Peter is stunned by how accurate the G6 is when he tests it against a finger stick blood meter
- The reliable nature of the G6 allows for Peter to stop doing their finger sticks which can be incredibly painful (think about those poor young kids having to stick their fingers multiple times per day for their whole life!)
- “*Just 14 days of that kind of checking, my fingers are all blue, and they hurt like crazy*.”
- The new algorithms can identify a finger stick that is inaccurate (when trying to calibrate the CGM)

\*Tips for finger sticking and recommended over-the-counter blood glucose meter

- **Tip**: you can get false readings if you have any food/crumbs on your finger so make sure to wash your hands and use an alcohol pad on your figure before sticking it
- **Peter’s recommended meter**: [OneTouch Ultra](https://www.onetouch.com/products/glucose-meters/onetouch-ultramini)

**CGM is a driver of behavioral change**

- Peter believes that the use of a CGM, at the very least, is a powerful driver of behavioral change
- “*It is really hard to not pay attention to how activities in your life, mostly food, but not just food, stress*” affects your glucose readings.

Stress and glucose levels

- “It’s amazing what stress can do to your glucose level.” says Peter
- Doing his own measurements, Peter was able to correlate his nighttime cortisol levels to how much glucose level would rise in the morning
- Peter tells patients that fasting glucose is not nearly as helpful as people think it is inside of a reasonably physiologic range
- Fasting glucose of 130, that’s a different situation, there’s something going on there
- But a fasting glucose of 100 instead of being 90 can very easily be explained by cortisol or hepatic glucose output for some other reason that’s not a function of insulin resistance

![](https://peterattiamd.com/wp-content/uploads/2019/05/stressCGM-821x1024.png)

**Figure 4. The impact of a stressful dental procedure on Peter’s glucose level: “Had a \*fun\* dental procedure today at 930 am. Glucose was 83 at start of procedure. Must have been stressful enough to ramp up cortisol production and hepatic glucose output!!.”** Image credit: [@peterattiamd](https://www.instagram.com/p/Br5y6ydA5kd/)

Junk food horror stories

⇒ Trail mix

- Peter loves trail mix when at the airport (comfort food)
- His glucose will spike to 130+ after eating it
- But recently he bought a bag at the airport but decided NOT to eat it because of the CGM (he didn’t want to watch that number rise)
- “I promise you if I didn’t have that CGM, I would’ve eaten it.”

⇒ Yogurt covered raisins

- Kevin once at a huge cup of yogurt covered raisins and his glucose spiked over 200
- “That was my only ever above 200 glucose spike in my life, and it only took 30 minutes.”
- His body “overshot” his insulin and dropped his glucose down to 70

![](https://peterattiamd.com/wp-content/uploads/2019/05/CGM-after-junk-food-819x1024.png)

**Figure 5. Peter’s glucose after indulging: “The price of indulgence. Peak glucose was 121 mg/dL. I inhaled a bag of kettle popcorn which prob had biggest impact on glucose.”** Image credit: [@peterattiamd](https://www.instagram.com/p/BoXkazzBnIW/)

## Software improvements for type 2 diabetics, and the remarkable benefits of real-time feedback for driving behavioral change [58:15]

> “The real problem in type 2 diabetes is that we have fixated so much on just the glucose and not worrying about how we get there.”

- Drugs that increases endogenous insulin production and/or when you use more insulin, you can reduce the glucose and reduce the [microvascular](https://clinical.diabetesjournals.org/content/26/2/77) complications, but “***you do not save lives***”
- Still getting cancer/heart disease/dementia at a much higher rate
- The real **challenge in type 2 diabetes is the combination of the** ***hyperglycemia with the*** [***hyperinsulinemia***](https://www.mayoclinic.org/diseases-conditions/type-2-diabetes/expert-answers/hyperinsulinemia/faq-20058488)

*What therapies save lives with type 2 diabetes?*

- [Metformin](https://en.wikipedia.org/wiki/Metformin), where you’re actually fixing the glucose side of the equation and not just adding more insulin to the system
- The SGLT2 inhibitors, these are the things that are getting the glucose out of the system

*Is there any way it is algorithmically possible to estimate the average insulin that a non-diabetic would make over the course of the day based on glucose data points?*

- We do believe that it’s possible to measure how quickly insulin reacts and how much by the slope of the glucose curves, but not at our five-minute measurement intervals
- “I think over time that might be something that we’ll look at, but it also might be something somebody might be able to look at better than us.”
- Dexcom is openly sharing information with other platforms to try to collaborate on these types of future developments

**Real time feedback as a driver of behavioral change**

- Peter is boycotting grapes after being shocked by his glucose reaction
- Kevin hasn’t touched yogurt covered raisins since his experience
- “I really think that **CGM has the potential to change the way people eat** more than any other technology I have ever laid eyes on.” says Peter
- “I also believe in real-time feedback. I think it’s very difficult to curb a person’s behavior when the feedback loop is too long like the weight on the scale, or the blood test that you get at your doctor every six months.”

*Building software to help type 2 diabetics (and non-diabetics)*

⇒ Example of software improvements…

- An analysis at the end of the day where we complement somebody, “*you kept your glucose within range extremely well*“
- Prompts from the monitor to help you do better ⇒ “*What did you eat for dinner today?*”
- Integrating the CGM data into a food database with photos (i.e. take a picture of the foods you eat)
- Then you can look back and say, “*Well, I ate those scrambled eggs this morning, and my glucose values didn’t go up. Maybe scrambled eggs for breakfast is a good thing for me.*”
- Then you take a picture of pancakes and the software recognizes them and you get reminded ⇒ “*You know, you had pancakes a month ago, and that may not have been the outcome that you’re looking for.*”

**Exercise and stress: the effect of your psychological state**

⇒ Exercise

- It’s not just what you eat, but it’s the physiologic state you are in when you eat it
- It’s a very different glycemic response if you eat a bowl of pasta after you’ve exercised intensely for 30 minutes versus eating it after having not exercised

⇒ Stress

- “It can’t be understated how much higher my glucose levels are when my sleep is crappy.”
- The correlation between high glucose levels (by proxy high cortisol) and crappy sleep

## Dexcom vs. the competitors, the less invasive options, and the fundamental problems needing to be solved with CGM technologies [1:07:00]

*How does Dexcom perform compared to its competitors?*

- Dexcom [has studies](https://www.ncbi.nlm.nih.gov/pubmed/30681379) that they’’ve published comparing Dexcom CGM to other ⇒ “*We maintain our performance all the time*.”
- Peter has been vocal about this, “it’s not a subtle difference.”
- “We perform extremely well across all the range of glucose in the low and in the high range.”

*Do you think that you will be able to maintain performance as the sensor gets smaller and smaller?*

- One of Dexcom’s goals is to have a smaller sensor with a shorter needle
- Currently the needle goes down to the [interstitial fluid](https://en.wikipedia.org/wiki/Extracellular_fluid#Interstitial_fluid), but they are testing ones that go even shallower
- But there are complications of a shorter sensor (*What do the membrane layers look like so you can get an extended wear on a 14-day sensor? How’s electrochemical reaction on a longer life sensor if it’s shorter versus the one that we have now?*)
- A lot of trial and error while trying to determine what is the best combination of all of these features
- “I think we’ll have a shorter one. Right now, we’re very comfortable with the interstitial fluid.”

⇒ Peter’s take on the pain related to the insertion of the sensor: “*Once it’s in there, I don’t actually know the difference between it being in me versus on the skin*.”

*Why can’t this be done optically (i.e. without going into the skin)? Or with a “pulse oximeter where you put it on your finger”?*

- It has been tried on numerous occasions
- For example, the [Cygnus GlucoWatch](https://en.wikipedia.org/wiki/Cygnus_Inc)
  - Sat on your wrist and would take fluid out of your skin through reverse iontophoresis and measure it that way
  - It would leave a red mark on the outside of your arm

*Are these “non-invasive” options accurate?*

- “Not accurate enough, and none of them have been to market yet, but only time will tell. People will continue to look. But they’re not solving the fundamental problem.”
- And also, how do you define invasive?
  - “To me, invasive is… does it invade your lifestyle? And does it produce the result that you’re looking for?”

**The fundamental problems needing to be solved with these CGM technologies:**

1. Accuracy
2. Conveniency
3. The cost
4. And can they produce a health care outcome

*Kevin’s take:*

“Not having the little wire in your skin, while one can try and paint a horror story around that, it’s not really that invasive to your body.”

“Anything that comes has to solve one of those problems better than the technologies that are on the market. And if somebody can do that with an infrared sensor, optical sensor, then we’ve had a wonderful technological step and we’ll all figure out where we move from there. We just haven’t seen anything yet that’s accurate enough or performs well enough.”

*Peter’s take:*

“For me and for my patients, [accuracy] is the highest priority, and what you give up right now is cost.”

## The cost of CGM, why you need a prescription, and when might there be a OTC option? [1:12:00]

- The cost of the CGM is the biggest barrier to getting more users
- Additionally, you need a prescription, and unless you have diabetes, you will be paying out of pocket for it

Insurance coverage

- Type 1 diabetes gets covered by insurance
- It depends for type 2 diabetes because it depends on which payer and also which region you are in
- Kevin says they are constantly negotiating with the insurance companies to get more things covered
- Currently…
  - Typically our patients pay 20% of the cost (standard co-pay for durable medical equipment)
  - And depending upon the timing of the year, if you buy the first of the year and their co-payments and their deductibles have not been met, it’s more expensive for them

*What about cash cost?*

- It’s the same cost across the nation
- Sensors come in boxes of 3
- Peter’s practice typically buys them 9 at a time (about a 3 month supply) for patients
- And they pay about $9-$11 per day

***Why can’t the CGM be a nonprescription product?***

- Peter points out that Dexcom as a business is basically doing incredibly well serving just a tiny fraction of people (T1D and some T2D)
- But another 10% of the population is pre-diabetic
- And then another huge chunk of people are focused on “wellness” and longevity and would benefit from better glycemic control
- Peter’s practice write prescriptions for non-diabetic patients and those patients have to pay cash

*What are the challenges of making this non-prescription and a viable product?*

- There’s a lot of steps we’d have to go through at the FDA
- A nonprescription device would need to have a different software experience
- Currently it is a class 2 medical device

*As it currently stands, when non-diabetic patients get a prescription from their doctor…*

- Physician writes prescription
- patient gets it filled
- Their all-in cost is about $9 per day to wear this thing
- And they are seeing the exact same data using the exact same device with the exact same algorithms that a patient with Type 1 diabetes

The role of the FDA

- Must go through clinical trials particularly **if labeled for use for people with diabetes** to demonstrate the accuracy and consistency of the product across all glucose ranges
- “The FDA in all candor on has been very progressive with Dexcom.”
  - First company ever to go directly to the phone
  - We’re the first company to share data
  - We’re the first company ever to have a sensor perform the accuracy levels that we have
  - In fact, most every “first” with the FDA in our industry has come through companies that are partnering with Dexcom

Interconnected CGM (iCGM)

- The FDA recently created a new category for continuous glucose monitoring
- For “intensive diabetes”, the products have to demonstrate on a statistical basis that the product is capable of doing the things that we wanted to do (which is properly dosing insulin)
- With iCGM, Dexcom can connect to other devices and the FDA has made an easier path for other devices to connect to Dexcom’s sensors

**Over-the-counter CGM**

- But in the case that a *real-time glucose value* is displayed…
  - That’s a [Class II medical device](https://en.wikipedia.org/wiki/Medical_device#United_States)
  - As of today, that requires a prescription
- In the future, Dexcom would love to have a OTC device to sell through nutrition programs but that a patient could NOT use to dose insulin

*Why does the FDA say an OTC product cannot be used to dose insulin?*

- Maybe that will change over time, but for now those are the rules that Dexcom has to play by
- Peter points out how frustrating this can be to patients who are willing to pay for it out of pocket
  - Especially because not every doctor understands the benefit of this
  - “So now that patient who is actually says, ‘Look, I’m willing to make an enormous investment in this because it’s my health and I believe that this is going to matter.’ Well, they can’t do it.”

*When and what needs to happen for an OTC product?*

- Kevin is hopeful that this will happen
- Dexcom would have to present again is a case as to how somebody *would never harm themselves*
- The fact that there is a needle that needs to be inserted complicates this issues ⇒ There may be standards and rules around needles
- So I can’t speculate how we’d get there, but I think over time that’s something we would like to take on.

*How would the OTC device differ from the current G6 product?*

- It would not be a device used for diabetes treatment
- Would need to create a device that would fit into the current regulatory environment which means some of the functionality would need to be dumbed down
- The accuracy and performance would still be in line with the diabetes device, but **the information that’s presented to the individual would have to be reduced/changed**
- In part that means you would have to take away the real-time information (and present it a day later)

## Smartwatch integration, bluetooth technology, and exciting collaborations and partnerships [1:22:00]

Smart watch integration

- Dexcom is currently working on a “direct to watch” transmitter to send data directly from sensor to the Apple Watch (and other smart watches such as Android)
- The watch would then become a patient’s receiver and the data could still be shared without having to go through your phone
- This is about convenience

![](https://peterattiamd.com/wp-content/uploads/2019/05/applewatchCGM.png)

**Figure 6. Dexcom CGM display on Apple Watch.** Image credit: [dexcom.com](https://dexcom.com)

Bluetooth technology

- G6 can store data and then back load it once it gets within range of your phone
- That way people can put their phones in another room while they sleep
- The transmission range of our product, I believe it’s labeled for 20 feet
- “We went with Bluetooth because we didn’t want our patients to have to put the phone close to the device. We wanted the continuous feed. I think there is a place for near-field and it’s quite possible we’d have both chips in a future one.”

**Exciting collaborations and partnerships**

Apple

- “Apple has been a wonderful partner for us in getting the device to the iPhone and getting our apps working on Apple Watch.”

Verily/Onduo

- Partnership with Verily includes work with a company that they have called [Onduo](https://onduo.com/) that is focused on **type 2 diabetes** and specifically developing solutions that could help people make better decisions
- Onduo is helping to develop apps that combine everything they’ve learned about diabetes with a lot of Google technology and they’re in pilot phases with various payers on the type 2 side

United Healthcare

- Doing a lot of work with United Healthcare on *type 2 diabetes*
- In the future with United, planning to develop some *prediabetes models* as we take this Gen 6 technology out

## Future places for CGM: Hospitals, nutrition apps, general health and wellness, and more [1:27:15]

**Peter asks:** ***Why isn’t the Dexcom CGM in the ICU of all places?***

- “We tried.”
- Had a joint venture with [Edwards Lifesciences](https://www.edwards.com/) but the FDA was extremely strict on accuracy and performance and it didn’t quite get there
- Learned a lot and now planning to make another attempt with G6

*⇒ How would it help in the hospital?*

- Monitor patients (especially diabetics) and dosing insulin
- Connect the Bluetooth to the nurses station so can see glucose in real time
- Currently, nurses may have to finger stick a patient every 30 minutes (48 finger sticks in a 24-hour period)

*⇒ Does taking* [*acetaminophen*](https://en.wikipedia.org/wiki/Paracetamol) *(Tylenol) affect the accuracy/performance of the G6?*

- No, it does not affect the G6 (it affected previous models)
- Dexcom ran a [very large study](https://www.ncbi.nlm.nih.gov/pubmed/29334775) and put a lot of acetaminophen into patients with no performance problems

⇒ Challenges with CGM in ICU patients

- They are typically on a bunch of drugs
- Also, they “[third space](https://www.nursingcenter.com/journalarticle?Article_ID=859815&Journal_ID=606913&Issue_ID=859810)” like crazy so their interstitial looks totally different from a normal person’s

⇒ Pay me now or pay me later

- “If we can get this in the right configuration in the hospital on most every patient, at least every patient over 50 that comes in, forget whether or not they have diabetes, that **hyperglycemia effect on healing we know is a very difficult thing**. If we can get it on everybody and make this affordable and fit within the normal workflow of the hospital, that’s a tremendous market for us.”

**Gestational diabetes**

- It’s crazy that pregnant women aren’t able to take advantage of the CGM
- But it’s not yet approved for gestational diabetes
- Need to run a study in gestational diabetes to get that label
- The CGM as a diagnostic
- This gets back to hemoglobin A1C and other measures
- One of the things that we look at is this product, is it diagnostic as well?
- Right now you drink that real sugary drink, glucose goes way high, then it goes way low (an awful swing)
- What about a blinded sensor on somebody for a week?
- Then develop the algorithms to see what we can predict with respect to gestational diabetes
- Those are the type of studies that we want to run in the future and the way we like to go about that market

**The health and wellness CGM market**

- Dexcom would like to combine CGM with some of the nutrition apps
- For example, [Weight Watchers](https://www.weightwatchers.com/us/) app…
  - If that had glucose data and you ate your 32 points today but your glucose factor was still high, maybe we take you down to 26
  - And vice versa
- CGM can integrate wonderfully (without showing a glucose value that you dose insulin off of)

⇒ Peter thinks glucose values are a much better metric for health than weight loss

- “I just think in the end it’s a much better metric for health and I think health matters more than weight.”
- “Weight is correlated with health, but the correlation is not exceptional. It’s reasonable, but it’s so far from great.”
- “And my prediction would be when those trials are done, your average blood glucose, your standard deviation of blood glucose over a three month period is going to tell you infinitely more than whatever the fluctuations were in your weight.”

*Type of weight* matters more than *total* weight loss

- Subcutaneous fat not as “bad” as visceral fat
- Also, where that fat *resides* on somebody probably tells us much more about their metabolic health

**Lessons you learn from wearing a CGM**

“*I just don’t see why I wouldn’t want someone to have this information continuously, in real time, every minute of every day, under any physiologic circumstance.*” says Peter

- What you learn is going to alter your behavior
- You learn other really interesting things:
  - How much even exercise can transiently raise your blood glucose, but what the benefits are after the fact ( which is your ability to dispose of glucose goes up significantly)
  - For Peter, he gets about a 30 point spike in a workout, but for the rest of the his average glucose is about 10 points lower

> “It’s it’s so amazing to think that such a simple biomarker as glucose, something we take for granted on every chemistry test we do on patients . . .what the utility of that is when you can have it measured every five minutes.”

## Dexcom’s unique company culture [1:34:15]

**Dexcom**

- Fairly big public company
- Market cap is ~$12 billion

*In some ways they still operate like a startup*

- Peter calls Kevin’s story about how he personally went to a pharmacy to finger stick himself to test various glucose measuring devices a “startup CEO move”
- Kevin: “I’ve had to learn to be less startup as we’ve grown. . .we’re trying to mix all of those things together.”
- There are competing thoughts internally where some people think they should go back to being a startup and others think they need more structure to be bigger
- Both are true, says Kevin

*Blending startup mentality with structure of a big company*

- For a startup: “The nimbleness of a startup in an industry where you’re creating everything is absolutely essential. You’ve gotta remain nimble. You’ve got to be willing to fail. You’ve got to be willing to start over. You’ve got to be willing to do what’s right.”
- For a large company: “Conversely, that big company structure where you have systems and balances and checks to make sure you’re doing the right thing and you start watching dollars more is a different culture.”
- Blending them together: “So we’re mixing those two together. We’re kind of like a mixed family here.”

*Dexcom’s employees*

- When Kevin started it was about 300 in 2011
- Now they’re up to ~2,500+
- “We have several people with Type 1 diabetes that work here because they can lend us perspective for our patients that we don’t have on our own. So that’s important to us as well. A lot of the things that we learn are through those in-house studies and through that in-house wear process.”

## Parenting advice from Kevin [1:37:30]

- Kevin has 5 kids
- Oldest is 15 years older than the youngest
- And an 8 year gap between number four and five

**Kevin’s advice to parents**:

- “We can’t be afraid to let our kids fail.”
- “I once told a coach to cut my son so he would learn something if he wasn’t going to play him.”

> “We learn in life as much from our failures as we do our successes. Sometimes we learn more and sometimes they motivate us to be great and motivate us to do great things.”

- “But we oftentimes, as parents, shelter our kids so much from that what appears to be traumatic.”
- “We just try and manage and regulate everything so much all the time.”
- “[My first kid] would tell you that I was very tough on him, but I let him carve his own way and it’s a good thing to let him learn.”

## Lessons learned through failures and success [1:38:45]

**1 Be better prepared in how you deliver your message**

- Kevin was once had a leadership position at a company which he strongly believed needed to shift course if it were going to be successful
- After presenting his point of view, it was rejected
- He put his head down and worked for many more month before presenting again and was rejected again

⇒ Lesson learned from that experience: “Be better prepared in how I give my message.”

- I attribute failures like that to me, I don’t blame the others.
- Be more thoughtful, do more research, and be more strategic
- “*That was the one time where it felt like I didn’t get done what we could have got completed*.”

**2 Sometimes the biggest blessings are the little failures along the way**

- “We’ve all had numerous little failures. Sometimes, again, our failures are our biggest blessings.”
- Kevin considers the many job opportunities that he fail to get were learning experiences that allowed him to get the *even better* opportunity down the road

**3 Surround yourself with great people**

> “*You’re only as good as those people that are around you.*”

- “And it becomes clearer and clearer to me the longer I work. This team we have here at Dexcom, they are committed, they work hard. We are all engaged in our business each and every day. I never go to a meeting with another company where their people are as engaged in what they do as ours.”

§

## Selected Links / Related Material

**Kevin is CEO of Dexcom, a developer of continuous glucose monitoring technology**: [Dexcom](https://www.dexcom.com/) | (dexcom.com) [7:00]

**Peter’s podcast about type 1 diabetes with Jake Kushner**: [#41 – Jake Kushner, M.D.: How to thrive with type 1 diabetes and how everyone can benefit from the valuable insights](https://peterattiamd.com/jakekushner/) | Peter Attia (peterattiamd.com) [8:45]

**Company that Kevin worked at prior to Dexcom and where** [**Alfred Mann**](https://en.wikipedia.org/wiki/Alfred_E._Mann) **developed the insulin pump and the company put out the first ever CGM in 1999**: [Medtronic](https://www.medtronic.com/us-en/index.html) | (medtronic.com) [4:15]

**Companies that “own” the stent market**: [13:45]

- [Abbott](https://www.abbott.com/)
- [Medtronic](https://www.medtronic.com/us-en/index.html)
- [J&J](https://en.wikipedia.org/wiki/Johnson_%26_Johnson) (but [no longer does](https://medcitynews.com/2011/06/end-of-jj-stent-business-carries-lessons-for-medical-device-innovators/))
- [Boston Scientific](https://en.wikipedia.org/wiki/Boston_Scientific)

**Where Peter worked in risk consulting**: [McKinsey & Company](https://en.wikipedia.org/wiki/McKinsey_%26_Company) | (wikipedia.org) [14:15]

**Over 1 million people in the US have T1D**: [National Diabetes Statistics Report, 2017: Estimates of Diabetes and Its Burden in the United States](https://www.cdc.gov/diabetes/pdfs/data/statistics/national-diabetes-statistics-report.pdf) | (cdc.gov) [21:45]

**Dexcom’s biggest competitors in the CGM market**: [22:00]

- [Abbott FreeStyle Libre](https://www.freestylelibre.us/)
- [Medtronic](https://www.medtronicdiabetes.com/products/guardian-sensor-3)

**The major cost that CGM prevents in the acute setting is the cost of hospitalizations**: [The Potential Cost Implications of Averting Severe Hypoglycemic Events Requiring Hospitalization in High-Risk Adults With Type 1 Diabetes Using Real-Time Continuous Glucose Monitoring](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4928227/) (Bronstone et al., 2016) [25:00]

**Improvement in hemoglobin A1C with CGM**: [26:00]

- [Comparative analysis of the efficacy of continuous glucose monitoring and self-monitoring of blood glucose in type 1 diabetes mellitus.](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3570843/) (Floyd et al., 2012)
- [Glycaemic control in type 1 diabetes during real time continuous glucose monitoring compared with self monitoring of blood glucose: meta-analysis of randomised controlled trials using individual patient data.](https://www.ncbi.nlm.nih.gov/pubmed/21737469) (Pickup et al., 2011)
- [Comparative effectiveness and safety of methods of insulin delivery and glucose monitoring for diabetes mellitus: a systematic review and meta-analysis.](https://www.ncbi.nlm.nih.gov/pubmed/22777524) (Yeh et al., 2012)
- [Effect of Continuous Glucose Monitoring on Glycemic Control in Adults With Type 1 Diabetes Using Insulin Injections: The DIAMOND Randomized Clinical Trial.](https://jamanetwork.com/journals/jama/fullarticle/2598770) (Beck et al., 2017)

**Organization dedicated to helping and furthering research for kids with T1D**: [Children with Diabetes](https://childrenwithdiabetes.com/) | (childrenwithdiabetes.com) [38:30]

**Company that makes the insulin pump that Dexcom partner’s with**: [Tandem Diabetes Care](https://www.tandemdiabetes.com/) | (tandemdiabetes.com) [43:45]

**Jake Kushner was able to drop HbA1c and also reduce hypoglycemic events**: [#41 – Jake Kushner, M.D.: How to thrive with type 1 diabetes and how everyone can benefit from the valuable insights](https://peterattiamd.com/jakekushner/) | Peter Attia (peterattiamd.com) [46:45]

**Better glycemic control in kids when they’re young can predict better intellectual performance in school**: [Longitudinal Assessment of Neuroanatomical and Cognitive Differences in Young Children With Type 1 Diabetes: Association With Hyperglycemia](https://diabetes.diabetesjournals.org/content/64/5/1770) (Mauras et al., 2015) [46:45]

**Red blood cell condition that Peter has which artificially raises his A1C**: [Beta thalassemia minor](https://en.wikipedia.org/wiki/Beta_thalassemia#Beta_thalassemia_minor) | (wikipedia.org) [48:00]

**For finger stick glucose measurements, Peter prefers**: [OneTouch Ultra](https://www.onetouch.com/products/glucose-meters/onetouch-ultramini) | (onetouch.com)  [52:30]

**Company developing ways to analyze and track the foods you eat to tell you how you reacted to them**: [Nutrino](https://www.nutrinohealth.com/) | (nutrinohealth.com) [1:06:00]

**Dexcom’s study comparing their CGM to competitors**: [Accuracy, Utilization, and Effectiveness Comparisons of Different Continuous Glucose Monitoring Systems.](https://www.ncbi.nlm.nih.gov/pubmed/30681379) (Welsh et al., 2019) [1:07:00]

**A partner company with Verily that is developing apps that combine everything they’ve learned about diabetes with a lot of Google technology**: [Onduo](https://onduo.com/) | (onduo.com) [1:26:15]

**Dexcom partnered with this company in an attempt to get CGM into the ICU at hospitals**: [Edwards Lifesciences](https://www.edwards.com/) | (wikipedia.org) [1:27:30]

**2001 NEJM paper that changed how glucose levels were managed using intensive insulin therapy in the ICU**: [Intensive insulin therapy in critically ill patients.](https://www.nejm.org/doi/full/10.1056/NEJMoa011300) (Van den Berghe et al., 2001) [1:28:15]

**G6 accuracy not affected by acetaminophen (Tylenol)**: [Resistance to Acetaminophen Interference in a Novel Continuous Glucose Monitoring System.](https://www.ncbi.nlm.nih.gov/pubmed/29334775) (Calhoun et al., 2018) [1:28:15]

§

## People Mentioned

- [Jake Kushner](https://twitter.com/jakekushnermd?lang=en) (told Peter about Dexcom) [8:45, 46:30]
- [Alfred Mann](https://en.wikipedia.org/wiki/Alfred_E._Mann) (designed the insulin pump) [11:15]
- [Terry Gregg](https://www.dexcom.com/news/30121881-kevin-sayer-assumes-role-president-and-chief-executive-officer-terry-gregg-transitions) (dear friend of Kevin’s, previous CEO of Dexcom before Kevin) [11:45, 15:00]
- [Andy Conrad](https://en.wikipedia.org/wiki/Andrew_Conrad) (Verily) [37:30]
- [Frederick Banting](https://en.wikipedia.org/wiki/Frederick_Banting) (discovered insulin) [43:00]

§

![](https://peterattiamd.com/wp-content/uploads/2019/05/bio-image-2.png)

##### Kevin Sayer: Chairman, President and Chief Executive Officer DexCom, Inc.

Kevin serves as the Chairman of the Board of Directors, President and Chief Executive Officer at DexCom, Inc. As Chief Executive Officer, Kevin has direct responsibility for strategy and operations. Prior to assuming the CEO role in 2015, Kevin served as DexCom’s President and Chief Operating Officer. In this role, he led DexCom’s core functions responsible for designing, developing and commercializing the company’s Continuous Glucose Monitoring (CGM) systems.

Before joining DexCom in 2011, Kevin served as Chief Financial Officer of Biosensors International, a medical technology company focused on the development, manufacturing and commercialization of medical devices used in interventional cardiology and critical care procedures. Prior to that, he was the CFO of MiniMed, Inc. from 1994 until its 2001 acquisition by Medtronic, Inc. In this role, he was responsible for the company’s finance, accounting, investor relations and treasury functions.

Kevin received his Master’s and Bachelor’s degrees in Accounting and Information Systems from Brigham Young University.