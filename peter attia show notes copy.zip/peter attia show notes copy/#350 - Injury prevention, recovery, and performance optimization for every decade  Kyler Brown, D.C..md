# #350 ‒ Injury prevention, recovery, and performance optimization for every decade | Kyler Brown, D.C.

**Source:** [https://peterattiamd.com/kylerbrown/](https://peterattiamd.com/kylerbrown/)

---

Kyler Brown is a sports rehab chiropractor who specializes in injury recovery, pre- and post-surgical rehabilitation, and guiding clients from rehab back to peak performance. As co-founder of the private training program 10 Squared alongside Peter, Kyler shares his approach to injury prevention and performance optimization—highlighting how overlooked movement patterns can quietly lead to chronic issues over time. He outlines a practical framework for assessing and treating individuals, highlights the importance of understanding movement dynamics and asymmetries, and discusses personalized rehab strategies through real-world case studies. The conversation also explores the psychological side of recovery, including the role of fear and mental barriers in rehabilitation. Kyler shares actionable tools to evaluate movement patterns and implement training strategies that support long-term strength and health.

A companion video series demonstrating exercises for common problem areas—such as the lower back, neck, shoulders, and knees—is available exclusively to subscribers on the show notes page.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/kylerbrown/the_Drive_public.png)

Play

#350 ‒ Injury prevention, recovery, and performance optimization for every decade | Kyler Brown, D.C.

#350 ‒ Injury prevention, recovery, and performance optimization for every decade | Kyler Brown, D.C.

1x15s30s

0:001:44:45

## We discuss:

- The personalized rehab strategy for Peter’s shoulder surgery that sparked creation of a training program called 10 Squared [3:00];
- Training for the marginal decade: why precision and purpose are essential for quality of life [11:00];
- The Centenarian Decathlon: how training for long-term capacity enhances both current and future quality of life [18:00];
- How the shortcomings of conventional rehab and performance systems led to the creation of 10 Squared, a personalized training model focused on long-term physical capacity and individualized care [23:45];
- Case study: how personalized assessment and treatment at 10 Squared helps uncover the root causes of injuries [31:00];
- The role of the “core” in movement and injury prevention, and the importance of training stability before strength [40:15];
- The layered assessment process used at 10 Squared to determine whether a person is ready to perform dynamic movements [47:45];
- Case study: the rehab plan designed to treat a hamstring injury while preserving fitness and preventing reinjury [51:45];
- Training approach for clients with minimal training history: risk reduction, habit-building, and long-term consistency [55:30];
- How to train foot reactivity, tendon resilience, and explosive capacity in a safe, progressive way [1:00:00];
- Peter’s foot and ankle pain: how to diagnose, treat, and strengthen the lower extremities [1:04:15];
- How fear and perception influence recovery, what drives back pain, and when to choose surgery vs. treatment [1:13:15];
- Could AI and app technology eventually deliver an individualized rehab and training experience? [1:22:30];
- Kyler’s professional evolution from traditional chiropractic care to a degree-agnostic, performance-based rehab philosophy [1:25:00];
- How 10 Squared provides precision rehab and training in a remote format [1:30:30];
- How Peter resolved a severe back pain flare-up using DNS-guided isometric exercise instead of passive treatments [1:33:15];
- How to identify and treat common joint pain (neck, back, knee, shoulder) using a rehab framework that strengthens supporting structures and helps avoid surgery [1:39:00]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dr. Kyler Brown is a sports rehab chiropractor who specializes in sports injuries, pre- and post-surgical rehabilitation, and bridging the gap from rehab to performance
- He is the co-founder (along with Peter) of 10 Squared
  - An Austin based, private member training program focused on building and maintaining exceptional muscle capacities for the marginal decade
- Originally this was a conversation that was recorded just for the 10 Squared audience, but once we saw how much the clients there appreciated it, we decided to repurpose it as a podcast for all of you

In this episode we discuss

- The principles behind injury prevention, recovery, and performance optimization
  - Including how small movement dynamics can lead to chronic issues
- A framework for assessing and treating individuals
  - The importance of understanding (from doing movement patterns) functional asymmetries and personal rehab approaches
- Specific case studies including Kyler’s work with professional athletes and others to demonstrate the benefits of individualized strategies
- The role of fear in movement and rehabilitation, and how overcoming mental barriers is just as important as physical recovery
- Actionable strategies for you to assess your own movement patterns and implement proactive training techniques to build strength and longevity
- In addition to this conversation, Kyler also filmed a short series of videos in the gym demonstrating exercises for common issues like lower back, neck, shoulder, and knee pain
  - These are designed to help you put some of these concepts from today’s episode into action
  - The videos are only available to subscribers, and can be found on the show notes page

## The personalized rehab strategy for Peter’s shoulder surgery that sparked creation of a training program called 10 Squared [3:00]

- A few years ago, when Peter was in the throes of recovery from shoulder surgery, he and Kyler had this idea to put together 2 things that seemed unrelated
  - His recovery from an injury
  - The idea of a Centenarian Decathlon in a marginal decade
    - [[episode #261](https://peterattiamd.com/training-for-the-centenarian-decathlon/) goes into detail about the Centenarian Decathlon]
- Peter met Kyler 4 years ago, as soon as he moved to Austin
  - They worked on preventative stuff: [DNS](https://pmc.ncbi.nlm.nih.gov/articles/PMC3578435/#:~:text=Dynamic%20Neuromuscular%20Stabilization%2C%20or%20%E2%80%9CDNS,of%20developmental%20kinesiology%20(DK).) and routine maintenance
    - [[episode #152](https://peterattiamd.com/michaelrintala/) goes into detail about DNS]
- On the second or third visit, Kyler asked about Peter’s shoulder
- And that kicked off this whole conversation because in Kyler’s world, this idea of just doing one technique or providing one service isn’t really a complete approach
- Peter had torn his [labrum](https://www.hss.edu/conditions_shoulder-labrum-tears-overview.asp) before
  - The diagnosis was made in 2009 when he had his first [arthrogram](https://en.wikipedia.org/wiki/Arthrogram) done
    - This is a MRI where prior to you going in the scanner, the radiologist takes a needle about 4 inches long, shoots the needle into the capsule and injects contrast so that it really allows the MRI to show the labrum and how much it’s detached from the [glenoid fossa](https://en.wikipedia.org/wiki/Glenoid_fossa)
  - It was significantly torn but not as torn as it would be 13 years later
- Peter had largely avoided surgery by doing as much as he could to strengthen the rotator cuff
- And frankly, he was afraid to have surgery
  - He didn’t want to trade one problem for another
  - He didn’t want to trade want to trade pain and instability for immobility
- Folks listening may recall his discussion with the amazing surgeon [Alton Barron](https://altonbarronmd.com/about/) on the podcast [[episode #232](https://peterattiamd.com/altonbarron/)] who ultimately did the repair
- What Peter was most impressed by in that experience was that Kyler and Alton started working as a team

**Talk a little about what you guys did 8 weeks prior to Peter’s shoulder surgery**

- One of the things as a rehab professional that Kyler really appreciated was how Alton didn’t want to just cinch down that joint to where his liability was so covered that that shoulder would be strong, but then have Peter lose a ton of function
- One of the key things that Alton did was he put the staples and the sutures in the right places to where that shoulder would be functional (he did just the right amount)
- And Kyler worked with Peter to get his shoulder well before more significant structural compromise
- It’s a really important window to do so
- Kyler remembers that conversation ‒ Peter had a date several months out where he was like, “*I’m going to have to use my arm a lot. I need to be strong.*”
- Peter wanted to be able to hunt in September
- So the surgery needed to be no later than March

**It was January, and the question was should he do the surgery right away or use 2 months to prehab?**

*How did you think about that question?*

- That conversation was one of Kyler’s favorites because he’s done this before where if we know the big picture goal as well as the near term surgical date, and then we reverse engineer
- Okay, I want to check off a certain amount of things preoperatively to where that joint is ready
- Essentially in the most simple terms, what you’re looking for in that situation, is you want to make all the muscles around the shoulder just awesome
  - Especially with the shoulder because it’s such a mobile joint
  - But we need to do so in a way that doesn’t make the surgery more complicated or injure you more
- He combined a lot of things
  - Technology like BFR [blood flow restriction discussed in [episode #179](https://peterattiamd.com/jeremyloenneke/)]
  - Aggressive approaches on core stability
- The way the scapula interacts with ribs and all these things have an effect on how the shoulder moves
- If the mobile shoulder that has a torn labrum isn’t stable and doesn’t have a support infrastructure around it, you’re always going to ask for more pain
- Once things were healing from the surgery itself, all those other ancillary things were actually functioning really well
- So now we only had to really target the shoulder itself because the rest of the human was really strong and ready

*What Peter remembers*

- How much rotator cuff work he did ahead of time, particularly around [supraspinatus](https://en.wikipedia.org/wiki/Supraspinatus_muscle)
  - He got that muscle as strong as possible in 8 weeks
  - Anyone who’s gone through that type of rehab knows it’s uncomfortable
  - You’re burning a tiny muscle that’s not used to working that hard

> “*The second thing that I remember and hands down the most important thing was what you and Alton decided to do postoperatively completely shattered everyone’s understanding of what we do with these patients.*”‒ Peter Attia

- Peter didn’t have a slap tear, his labrum was hanging on by a thread
- Traditionally a surgeon’s primary objective is to make sure that is never unstable again
  - Cincy it down really tight
  - The patient will be in a sling for 4-6 weeks, and that’s going to give it plenty of time to heal
- But you’ll never regain mobility, never regain the healthy range of motion, and you’ll probably atrophy away

**⇒** Alton’s goal was to have Peter out of a sling in 24 hours

Kyler points out, “*The broader picture here is what we touched on, the liability. And it’s really difficult for modern physicians and rehab pros to integrate.*”

- Professional sports try to achieve this as well, but they have time constraints and all these other constraints with how many people they’re working with
- Ignoring all those layers, the most important thing is Alton and Kyler had these conversations in detail and Alton was really specific about, “*Okay, did we get the training we talked about? Is that supraspinatus, the serratus anterior, all these other muscles that help stabilize? Are those really good?*”
- Kyler had some metrics he was able to discuss with Alton, and Alton felt confident in the stability of Peter’s shoulder

***The decision about no sling was based on the preparation they did and what they knew***

**The other thing was Peter followed everything to a T**

> “*One of the big complications in rehab (athlete or not) is are people following the rules?*”‒ Kyler Brown

- If we take this individual out of a sling, are they going to forget about it and all of a sudden go reach for the cereal or are they going to follow the rules?
- Peter was definitely a rule follower
- So Alton and Kyler had high confidence in minimizing the risk

**Peter learned a lot the hard way from his first orthopedic surgery in 2000**

- He’s not even convinced he received post-operative instructions
  - And if he did, he didn’t read them
- He was breaking every rule there were

**Peter’s labrum repair surgery**

- The stakes were higher here in a way
- Peter was very mindful
- When you have surgery, you tend to go on YouTube to learn all about it
  - He wanted to see everything: the post-operative, the rehab process

*Post-surgery exercise*

- One of the big milestones you see for people with labral surgery is when they basically can dangle the arm and rotate a light weight
  - Alton was really clear, “*You’re not going to be doing that for a while. We’re talking about range of motion without stress on the repair*.”
- Very early on pre-operatively and post, we were able to do very gentle but targeted [isometrics](https://en.wikipedia.org/wiki/Isometric_exercise) where there wasn’t complexity in the joint itself, but we were loading the tissues in a very articulate and specific way
- And that’s how you again put the support structure around it
- Kyler describes as the roll cage in a car, we want all the muscles around that to be ready to absorb force
- So those joint structures that are getting the staples or whatever else in there aren’t stressed
  - We don’t want to yank on those things while they’re healing

## Training for the marginal decade: why precision and purpose are essential for quality of life [11:00]

**In parallel to this, Peter continued to refine his thinking around the idea that we’re all going to have this marginal decade one day**

- It comes across as a depressing thought
- Nobody wants to think about the idea that there will be a day when you enter the final decade of your life
- But at the same time, to act as though it’s not true won’t make it not so

***It occurred to Peter that the more deliberately we can train for that last decade (as though we are athletes), the more we can enjoy it***

- Peter has had both the privilege and curse of watching people in the final decade of their lives, and the thing people complain most about is what’s taken away from them physically
- There are lots of people in the last decade of their life that are lonely because they were miserable sons of bitches and they don’t have family or friends
- There are many people whose cognition has failed them long before their body has failed them

**⇒** Really thinking about this in terms of large numbers, more than 2/3 of people in the final decade of their life when they’re really thinking about what’s impacting the quality of their life, it’s the physical part that they’ve lost that they miss the most

- Sometimes it could simply be freedom from pain, but more often it is restriction of activity

**Kyler’s experience working with professional athletes**

- It’s interesting to see these mature athletes who’ve been playing their sport for 8-10 years and they’re starting to look at this reality that their career is going to be over
- They start recalibrating how they train because they start thinking about the long term
- What’s really fun for Kyler is when they start to get that perspective of it’s not just about this weekend, it’s about the long game here

Kyler explains, “*To your point, a lot of people out there have the best intentions and they’re maybe even working hard, but there’s no precision.*”

- Nothing’s accounting for their specific details, their nuances of their joints and how they move and how their body feels when they move and their trust in their body and all these variables

***A lot of people either want to put in the effort and don’t know where to start, or a lot of people are putting in the effort but it’s not calibrated***

**Peter began to observe that in himself**

- He was doing a lot of activities because historically, he’d always done them
  - We fall in a groove, this the type of exercise I enjoy doing

*He had to take an honest assessment*

- For every activity (just like for every investment), there is a risk and there is a reward
  - Think about how investing in your 20s is different from how you should be investing in your 60s, 70s, and beyond
- Risk and reward changes over time
- For example, when you’re 20, the risk is inherently lower because you have better tissue
- Younger people can get away with doing things incorrectly
  - Some of the most gifted athletes actually have horrible patterns of movement, but because t hey’re so gifted, it doesn’t seem to matter
- Specialization is one example
  - Some people are just born jumpers and then you train it and they practice it when they play and they get better and better at jumping

Kyle points out, “*But moreover, it’s almost like we’re set up for failure.*”

- We’re set up with this baseline norm of, “*I could bench press 225 when I was a senior in high school*,” but then that individual is not accounting for the 20 years of lack of activity
  - Lack of practice
  - They’ve atrophied
- Then they jump right back into the gym and they hurt things or they feel like they “*Can’t do it anymore.*”

***The reality is it’s all about capacity: If you don’t use it, you lose it***

- A lot of us aren’t really thinking about, “*What if I actually actively lost, from an activity standpoint?*”
  - Is it jumping? Is it mass, is it strength?
- Kyler often sees this on the pain and injury side

**Injury doesn’t show up out of no where**

- It has reasons why it shows up
- It’s compounded by emotional stress and all these other kind of multi-factorial things
- When our brain perceives threat, we feel pain
- Sometimes that’s a physical threat
  - I haven’t jumped in a long time; I started jump roping
  - All of a sudden I wake up, my Achilles is sore
  - That doesn’t mean I ruptured my Achilles, but it does mean I was not prepared for that movement because I’ve been on the shelf for a long time

*The analogy of an investment strategy is fantastic*

- People should make sure they’re accounting for all the buckets that their body needs to do
  - Not just what they want to do
- Demographics, western society, age, all these things play a role too
- If you pull up the stats, a lot of people will have a high risk for low back [injury] or high risk for an ankle [injury] or whatever

Jumping is a great example

- When Peter was in his training peak (age 13-20), he was training a lot, and jumping was an enormous part of what he did
- He was skipping rope 25 minutes every single day
  - Lots of those are doubles
  - Absurd amount of [plyometrics](https://en.wikipedia.org/wiki/Plyometrics)
- Then from age 20 to 40, he didn’t jump at all
- One of his realizations was that he’d lost a lot of tissue pliability

***Now something that he does a lot of is low level jumping***

**The importance of play in maintaining capacity**

- Sometimes he gets really worried about having an Achilles rupture (that’s a middle-aged man injury)
  - Playing soccer with his kid, he’s just waiting for it

Kyler sees this all the time in his private practice

- What he always tells people is, “*Look at your kids.*”
- If you go to a coffee shop with your kids, one of them will run and jump off a rock and do a twist and land it
- When was the last time one of us did that? Right?

**⇒** That’s why they say maintaining play and always playing games and increasing that to where it’s randomized games (you’re actually reacting to things, because there’s the neuroplastic effects as well), but just for the tissues, rehearsed load on the Achilles in the foot [this maintains capacity]

- If you go and get a job and you drive to work and you sit at your cubicle all day and you drive home and you didn’t jump, that times 5 or 20 years is going to **cause a lot of lack of capacity in your tissues**
  - And you don’t want to learn that the hard way
- What Peter has been doing in the intervening 25 years was swimming and cycling (non impact)
- Hiking is fine, but it’s still not jumping, it’s not reactive

*Part of what made Peter start to realize this was playing sports with his kids*

- When you play basketball, soccer and baseball with kids, you realize it’s not a predictable movement
  - It’s never the same movement exactly twice
  - There are a lot of variables there

## The Centenarian Decathlon: how training for long-term capacity enhances both current and future quality of life [18:00]

- This gets to the idea of the Centenarian Decathlon
  - [[episode #261](https://peterattiamd.com/training-for-the-centenarian-decathlon/) goes into detail about the Centenarian Decathlon]

**Give me some of the things on your Centenarian Decathlon**

- Wrestling with his kids and grandkids
  - Which means getting down on the floor, having the flexibility
  - That bonding that you get when little kids are wrestling on the ground
  - Kyler saw his dad recently doing that and he thought that was really cool
    - He’s over 70 and he’s on the ground messing with Kyler’s three-year-old
    - It was hard for him, but he got down there and he could do it and he didn’t suffer from it
- Kyler fell in love with rucking over the last couple of years and so he wants to be able to really crank out some mileage, especially in national parks as he gets older
  - He’s not looking to be an ultramarathoner per se, but he really want to be able to hike long distances with a pack on

Peter asks, “*When you’re in your marginal decade, how many pounds would be your expectation? Give me some numbers. How many miles? How many pounds?*”

- Kyler thinks his numbers will be a little distorted because he’s a big guy (6’3” over 200 lbs.)
- He should be able to carry at least 20 lbs. without worrying about too much for 4-6 miles
  - Peter likes that goal
- Not too technical of terrain (not boulders and rocks), but he’d definitely like to go up and down hills (dirt track)

What else?

- Kyler grew up being an athlete
- His youngest seems to be more inclined to be an athlete
- As Kyler ages, he wants to be able to hang with him as long as he can
- That means throwing, hitting a baseball as long as possible
- Who knows how his son’s career will evolve, but the odds are they’re not going to be pros
- Kyler wants to keep that base where he can keep playing with them as long as possible

> “*To me it’s all about being able to still play with the grandkids because family is one of the most important things out there, and if your grandpa is sitting there and can do cool stuff, I think that serves as a great role model*.”‒ Kyler Brown

- Whereas if you’re suffering from an injury, you’re not healthy, then they want to hang out with you, but at the same time, kids want to go do stuff and Kyler doesn’t want to be left out
- Peter agrees, kids typically don’t want to come into your world; you have to go into their world
  - You have to be able to go fishing, hike

**⇒** People listening to us who have young kids should not waste the opportunity to observe what young kids do

- There’ll be different technologies in 25 or 30 years, but the principles will be the same
- Peter knows that kids like to play and therefore playing with his kids today is giving him a dry run of what he wants to be able to do in 30 years

Kyler warns, “*If you aren’t building up these areas of need or you’re accidentally letting these certain athletic movements fall by the wayside, all of a sudden you’re like, ‘Oh man, I can’t do that anymore.’*”

- He loves coaching his kids’ basketball team
- A grandpa of one of the other kids was out on the court with them one day
  - He was 74, he was moving, he could shoot (no dunks), and every kid there, their eyes lit up
  - They’re like, “*Grandpa can shoot. That’s crazy.*”
  - That was a cool moment

***That’s why playing with kids might be Kyler’s whole CD [Centenarian Decathlon]***

**When Peter first introduced this idea of the Centenarian Decathlon to the first of his patients**

- One of the bits of pushback he got (especially from people in their 30s and 40s) was, “*Peter, I’m not that interested in my 80s and 90s… I want to be a kick-ass 40-year-old.*”

*What’s the flaw in that logic?*

- Everyone’s drawn to this high performance, be awesome right now, and that’s like a boom-bust strategy
- You might pull it off, but you’re high risk and eventually you’ll hit the wall for a race car

But if we’re thinking long-term

- Then by default, if I’m going to be an awesome 70 or 80-year-old, I kind of have to be an awesome 45 or 55-year-old
- We’re going to be doing things now that make you crazy strong to help your lean muscle mass, that burns your fat, all those health risk things
- But you’re also going to be way more prepared for whatever life throws at you

***If your buddy talks you into going skiing or going to do a volleyball game or whatever else, you’re going to be way more ready for it if you’re thinking long-term and building this crazy robust foundation rather than just chasing the newest technique or the newest technology***

**The archery analogy Peter uses**

- Archery is something Peter enjoys
- What you’re trying to do is train to be exceptionally accurate at 100 yards
- This pushback from patients is telling him that they don’t care about 100 yards, they just want to be accurate at 40 or 50 yards
- Peter is telling them, “*Trust me, if you’re an ace at a hundred yards, it’s like shooting fish in a barrel at 40 yards*.”

This analogy has a deeper layer of truth

- It’s a very nonlinear thing
- 100 yards isn’t twice as difficult as 50, it’s 4 or 5x more difficult

***Similarly, to be really fit and healthy in your 90s is dramatically more of a demanding feat than just to be a fit 50-year-old***

- Kyler agrees, there’s a lot stacked against you
- Plus variables that we’re not prepared for, we could roll our ankle
- But give me somebody who’s strong all day and if they sprain their ankle coming out of the bar, odds are they’re actually going to sprain it less

**⇒** All this insulation and capacity we put around us with the individual goals is crucial to prevent injury and these injuries can stack up and cause a lot of trouble, and then we get less healthy

- That’s how you get these multipliers where I was on track to be really good, but this knee arthritis or this multiple meniscus repairs I had to get because I wasn’t stable
  - Caused me to actually lose my hiking ability and then all of a sudden I got less healthy

## How the shortcomings of conventional rehab and performance systems led to the creation of 10 Squared, a personalized training model focused on long-term physical capacity and individualized care [23:45]

**Back to Peter’s shoulder recovery**

- Peter realizes how fortunate he was to have known Alton for a while, then to have met Kyler
- He asked Kyler about building a business that just focuses on the training piece that’s outside of Peter’s practice, outside of Kyler’s practice
  - A business that integrates it with everything that’s necessary to train a person for the marginal decade
- Kyler brings in all of the cardio training, all of the strength and conditioning, the coaches to integrate the whole thing
- They’re doing all of these things now in [10 Squared](https://10squared.com/)
- Peter thinks what Kyler does is the hardest for people to wrap their heads around
- People understand this training will
  - Help them get a high [VO2 max](https://peterattiamd.com/category/exercise/vo2-max/)
  - Boost their [Zone 2](https://peterattiamd.com/category/exercise/aerobic-zone-2-training/)
  - Make them [stronger](https://peterattiamd.com/category/exercise/strength-muscle-mass/)

**How do clients look at you? What do they figure is going on with you?**

The assessment

- The assessment takes 2 days and we’re looking under the hood a lot in a lot of different ways
- In Kyler’s career, he had experience working with teams, and he became an off-season person for these athletes
- By  default he had to almost become a strength coach
  - Not because he wanted to or that was his goal
  - Because these athletes needed that bridge from “*I’m injured*” to, “*I might be injured*” to, “*Hey, I’ve got the green light for performance*.”
- All humans are moving up and down that spectrum based on our recovery and all these variables
- What’s been fun at 10 Squared is Kyler gets to do all the assessment he wants, and it’s not really a clinical assessment
- On the one hand, he’s looking at things that either have pain or that individual member has had a previous injury with and he’s accounting for that and making sure that’s on track or could be improved (and we add those things)
- He also gets to play around and look at what else is weak
  - What is this individual at risk for?

*For example, Kyler has a client who loves to surf*

- He’s got a shoulder issue, so by default surfing and swimming on a surfboard is a different position than a traditional freestyle stroke
- So we had to make his shoulder uniquely robust in certain directions
- And so that’s part of his strength program

One of Kyler’s biggest pet peeves in the rehab world is when people give someone 30 exercises that are really tedious and boring

- No human sticks to that
- They might do it for a week or 2
- But if it’s not bridging to what they love and want to do, it won’t get there

***If we can bake-in, ensuring that all the strength training won’t make them worse and we’re baking-in their little corrective exercises (or improving the gaps), that’s where you make a huge difference in how someone feels and how they can perform***

**How do you help a person who is not getting better?**

- They’ve had a “fill in the blank” injury (tennis elbow, lower back pain, shoulder pain), that’s not getting better

*How do you help that person think about whether or not there’s an underlying structural problem that needs a surgical intervention or a more direct intervention versus you are not being instructed to do the right things or you’re being instructed and you’re not doing it?*

- It’s a heavy lift with a lot of details

***Your orthopedic surgeon or your neurologist and then your rehab pro have to be in sync and have a relationship***

- And that’s very rare
- What’s really interesting is the philosophy and the individual just spirit of either surgeon or the rehab pro: they have to be committed to the service oriented field
- If they’re just doing it for money, they’re going to do it to scale like the PT mill
  - Where there’s 4 clients with 1 therapist, and that therapist is probably doing the best they can
  - They’re outnumbered and they’re not accounting for those 4 different people all at once

***First off, it has to be one-on-one: a therapist cannot rehabbing you the same way they could rehab your grandma who had a shoulder issue***

Peter asks, “*Are you saying that in some facilities, one PT will work with multiple clients at the same time and put them through the same workouts even if they’re quite different?*”

- Yes
- Typically it’s a very cookie cutter approach
- Usually it’s an insurance model thing where they know that these certain exercises and putting ice or stim is going to be reimbursed by the insurance company
- So that PT clinic is going to do that on everybody regardless of what they need

*#1 One of the biggest pitfalls [of PT] is it’s never one-on-one; it’s not custom*

- In the same way Kyler has had pro athletes come in and we’re supposed to do shoulder rehab that day and the night before they did a ton of stuff to their shoulder
  - So guess what? He’s not doing anything
  - They actually need to recover that day
- It needs to be customized

**To go back to the original question of how do people navigate this world**

- Kyler thinks your rehab clinic needs to do more than just offer services
- They need to offer a plan
- They offer cupping or dry needling or whatever it could be

**⇒** One service doesn’t ever fix anyone, and it definitely doesn’t increase their capacity over time

***The magic word of “capacity” is what it’s all about ‒ are you building me back to what I want to do?***

- If your rehab clinic is a bunch of passive modalities on tables and a bunch of techs doing ultrasound and stuff, that’s a red flag because they’re not going to build you to get stronger and stronger

*#2 The orthopedic needs to actually be hunting down that physical therapy*

- A lot of times, what Kyler sees in the orthopedic world is they have to give their clients something for rehab guidance
- They’re not totally sure if their client’s going to go do rehab, can they afford one-on-one and all these other factors
- So they give them this handout

**⇒** A lot of times this handout is from 30 years ago and it’s the same 5 or 6 cookie-cutter exercises, but then there’s no accountability, there’s no nuance

- There’s just a lot of holes in this path to try to get your shoulder or your back or your knee from: It hurts. Do I need surgery or not?
- Built that all the way back up to: I can do whatever I want

**Is this taking the extreme example at the other end, which is professional athletes come with deeper pockets than others and come from leagues?**

- Kyler has worked with golfers, football players, basketball players, baseball players, tennis players, runners

*For example, when you’re talking about the NFL players, is that problem completely solved?*

- No, not at all
- There’s a lot of environmental problems
- Kyler has friends that work with all these professional teams, and they’re handcuffed because they only have their athlete for so long
- All of a sudden you get this problem of “multiple cooks in the kitchen” where even if everyone has no ego and the best of intentions and they’re mostly science-based people, they’re still not sure, what the athlete did last week
  - What are we trying to do?
  - Are you in a contract year?
  - There’s so many variables for a pro athlete

## Case study: how personalized assessment and treatment at 10 Squared helps uncover the root causes of injuries [31:00]

**Example: Peter’s wife is a client at 10 Squared**

- Jill is a runner
- Peter is very hands off anything that has to do with her

**What did you learn when you did an assessment of her, and how did that impact how she works with the other members of the team (on the cardio side, on the strength and conditioning side)?**

- Jill’s a really great example because she had some pain when she showed up
- Kyler’s job immediately was to evaluate that pain
  - Is that a structural insufficiency?
  - Are we worried about a real injury here, or is that just an annoying nuance?
- His clinical team is way more detailed than what he would normally do in his private practice because at 10 Squared we have the time and we want to remove confirmation bias
  - So we don’t just say, “*Your hamstring hurts. Let’s order an MRI.*”
  - Instead, let’s test it 6 ways and in a smart conservative way, and if all 6 of those indicate that, then we’re going to do an MRI

With Jill, he saw some proximal hamstring issues

- She’s an endurance athlete and her profile, her demographics, her running history all pointed to there might be a tendonopathy there
- The testing reinforced that
- The next step was to get an MRI to really evaluate that tendon
- Because we knew in the near term, within a year she wanted to run Boston
- And as an injury person, Klyer realized that while she’s okay now (it hurts), once she starts stacking up mileage, that is a thing that’s going to get in the way
- Normally she only runs 1 marathon a year, but last year she ran 2
  - Her Boston qualifying marathon and 7 weeks later the London Marathon
- After London, she started getting a little bit of knee pain for the first time ever
  - The knee on the other side from her hamstring issue

**Can you explain why you didn’t think that was a coincidence?**

- Kyler saw her for knee pain to get her through London
- What a lot of people don’t appreciate about the way runners move, even though they’re moving straight ahead, technically, it’s a unilateral or single-leg rotation, propulsion drill
- It’s counterintuitive
- Golfers are actually the same
- They’re single leg actually rotates to create that torque
- Kyler’s favorite term that’s out there right now is called the **“spinal engine,”** which really speaks to this ***reciprocal movement of the spine on top of the pelvis and then the feet through the ground***

**⇒** What happens is those 3 domains work in unison to propel you forward

- It’s a lot like with sailing, like you put the sail relative to the wind and it points me in direction
- All three of those domains have to work in sync
- When Kyler sees an athlete like Jill who wasn’t new to running but added volume in a short window ‒ that is a great recipe for injury

***That right knee flaring up told him there’s something going on at either her feet or her pelvis that’s not in sync because essentially with her mileage, she overloaded that right knee and created a repetitive stress injury***

- That’s why Kyler was saying earlier, “*Injuries don’t just show up for fun.*”
- Whenever you see a story like that and then you do the evaluation and the way her pelvis was rotating, the way her core and her spine were set up, and also the way that left hamstring was affecting her motion, she was basically dumping into that right knee over and over
- 10 miles for someone like her, no big deal
- You stack up 2 marathons pretty close with that much mileage, and all of a sudden that right knee really flares up

*The right knee flare up was actually an indicator of something else going on functionally*

- It wasn’t only about making her knee better, which is what traditional medicine does
  - Rest it, ice it, [Meloxicam](https://en.wikipedia.org/wiki/Meloxicam) treatment, rehab, whatever
- Traditionally, those people go run again and 3 or 5 months later it comes back

**⇒** We we need to look at these asymmetries everywhere else, not just the side of pain

**If the knee is caused by the hamstring, what do you think is the cause of the hamstring injury and why are middle-aged women so susceptible to this injury?**

- Demographically, a lot of middle-aged women don’t strength train
- So the health of their tendons and the muscle fibers and the mass of the muscles just aren’t normally as high and as strong as someone else
- Especially if they’re an endurance athlete

***Runners nowadays know that they need to cross-train, but how they’re doing it, there’s is still a big gap***

*Using the word “cause” is always tricky in biomechanics because it’s always like the snake eats the tail: they’re all intertwined*

- The most simple way of describing it is that **tendon overuse**

**Back to Jill’s assessment and treatment**

- What we found out with her MRI is that she had a true tendinopathy damaged to that proximal hamstring tendon, as well as one of the hip rotators that inserts on the same site next to that hamstring had a little damage and irritation
- That area was a byproduct of the way she was rotating through her pelvis and the way that spinal counter rotation was happening
- Jill has a tiny bit of scoliosis, which sets her up for that asymmetry
- So her brain subconsciously was basically forced with the decision of, “*Do I jam my right low back or do I really try to pull with that left hamstring?*”
- And that combination over time created a little fraying in the tendon

Peter points out, “*The other thing I would add to this, which I suspect any woman listening to us who’s had kids will appreciate is even though Jill is tiny, she said her body never went back to pre-pregnancy.*”

- She talks about how she used to run before 2008 (when their first child was born)
- She ran a bunch of marathons before then and she’s run a bunch of marathons since and she weighs the same
  - She’s been very fortunate in that regard that her body weight hasn’t changed in that period of time
- She says she cannot biomechanically do what she used to be able to do
- Peter assumes her pelvis was mechanically changed having kids and she feels it, but she can’t articulate it (nor can he necessarily), but she just said there’s something different
- She felt like she used to float and now she feels like she runs
- Kyler can see that and thinks a lot of women feel that way
- His wife  had the same experience
- If a running back were to blow an ACL, we know exactly what to do and there’s a protocol
  - 8 months later this athlete will be back
- For women, everyone cares about the baby
  - The baby is born, even mom cares about the baby
- Women sacrifice their own body just to make sure this little creature grows up and gets everything it needs

***This focus on what women need the first year after childbirth is very lacking and one of the biggest crimes in modern medicine today***

**Peter hopes somebody’s listening and thinking of another type of 10 Squared focused on what are we doing for women immediately post-baby**

- Vaginal delivery and C-section are 2 totally different things
- There should be really robust rehab paths to get them back in amazing shape immediately as opposed to we’ll come back to this in 10 years
- Kyler speaks to the complexity of what they deal with: not only do they just add weight by adding this human
  - The relaxant hormone creates areas of stress and laxity that will shorten up and tighten up over time, but it affects different women differently
  - Some women’s feet change in that environment of more relaxant and carrying more weight: the arch and the foot gets affected
- In a way he looks at it like all these areas suffered a little bit of what you might call an injury, but it’s a natural process
- How do we account for all these layers?
- No one out there is telling women to do foot strengthening when they’re 2 months pregnant, but they should be
- Just like [the strengthening] he did for Peter’s shoulder, Kyler advises women, “*If you find out you’re pregnant, you should start doing some foot strengthening things, some core stability stuff. There’s a ton of things you could do prehab*.”
- Then after try to start to strengthen the right way

*There’s something about the pelvic floor that is absolutely decimated in pregnancy (or delivery more to the point)*

- Peter believes (no pun intended) that is part of what has gone wrong in her hamstring
- It’s a common complaint in many of her friends
  - It doesn’t present as a hamstring injury
  - It presents as a knee injury or an ischial tuberosity pain (which is the sit bone) and they say it’s not comfortable to sit

One of Kyler’s favorite orthopedic surgeons in town (he’s a hip ortho) called him to help with his wife

- She had been doing traditional PT for 8 months and it was no better
- It’s very common
- Pelvic floor specialists are rising (very cool to see)

***Kyler is not an expert in the pelvic floor but it is very much a big player in how we pressurize our intra-abdominal stability***

- It’s basically the flooring of that whole canister that we’re supposed to create with proximal stability
- So if the diaphragm or the pelvic floor isn’t doing its job, then our body’s going to immediately start to compensate and create rotations and tilts around things

## The role of the “core” in movement and injury prevention, and the importance of training stability before strength [40:15]

- Peter hates the term “the core” because it’s so misused
- The way he talks about it is most closely aligned with how DNS thinks about it
  - Dynamic neuromuscular stabilization [discussed in [episode #152](https://peterattiamd.com/michaelrintala/)]

**Comment on this thorough the lens that we think about the core as a cylinder as opposed to “abs”**

- The starting point Kyler wishes everyone could automatically understand is that if you have really prominent [rectus abdominis](https://en.wikipedia.org/wiki/Rectus_abdominis_muscle), that has nothing to do with how you stabilize your trunk,
  - Especially if you’re doing things in multiplanes like tilting and rotating
- It’s not just your obliques either

***It’s the deep stabilization system that not only pressurizes with our diaphragm, the pelvic floor, but it’s also all the small muscles up and down my spine, including*** [***multifidi***](https://en.wikipedia.org/wiki/Multifidus_muscle) ***‒ do all those muscles kick on and create stiffness in the right way at the right time?***

- A lot of times people are accidentally over-coached into thinking they only need stiffness
- The second step to that is, okay, now I can activate that deep stabilization system (I have that bracing. I’m pressurized.)
  - I’m using my [transverse abdominis](https://en.wikipedia.org/wiki/Transverse_abdominal_muscle), all these other structures down there
- Now, can I do that with motion?
  - And that’s where you start looking at someone kicking or running or throwing

***That needs to be a dynamic system, not just a stiff system***

- A lot of people don’t have the first one, so they see a ton of these exercises like the **DNS three month or dead bugs** that create deep core stabilization, but they don’t see the next step after that
  - Which is, okay, now how do I maintain that pillar and that strength and then I get a free shoulder blade or a free hip to move?

*Kyler’s experience with a client who had a lot of radicular nerve pain from a disc issue*

- This was one of the most fascinating cases in recent memory, because with him we were able to actually **find a trigger point that referred pain**
  - That mimicked that radicular nerve pain
  - When we literally pressed on his [glute minimus](https://www.physio-pedia.com/Gluteus_Minimus), he got referral [pain] that he thought was a tribute to his back
- So that was a window towards [learning] that this was a muscular issue, that’s not the spine causing trouble
- Then we gave him these stabilization drills which helped that glute just relax for once

*Something Kyler sees all the time in the clinic*

- Muscles are meant to be a muscle
  - My bicep is meant to contract and relax
- It’s not meant to be a shoulder stabilizer

**⇒** But if my stabilization isn’t doing its thing, then that bicep and the trap and all these other muscles try to help

- And that’s where we lose freedom of movement because your body’s essentially perceiving a little threat, a little instability, and so it tightens other structures up
- People will ask for dry needle work or soft tissue work, then go to the stretch place
  - That’s going to be a 6 hour benefit

***If we activate this deep stabilization system and get all the parts moving in unison and in sync, all of a sudden those movement problems go away and you’re much more robust and strong***

- Peter wishes there was another word for stability that didn’t imply static
- We think of that as things that are not moving (rigid, stable, etc.)
- But the truest way to appreciate stability is **kinetic stability**

**Peter uses the analogy of a race car to explain stability**

- When he wrote about stability in his book, [*Outlive*](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.--JeJHXaTizre_2a8KUiq1QegfrPy8qjvM-fJrFyxpDyjtAjWwU8b6Pq3wttOruG5BcUqj9OyIlUjMQjsRCccOisiNkrdQOLkgqGGtJ1NMCulsOe6HTQ4O44b0HPoeCToudoPpOgukz6DE-2vLeyKDz-LECV1k9AIDLIDeU_0RgTPEeZH1uikqBvUHhFXg9D0nf8WKDRU1b-8vh9hxexjcfI01uwPJw2wDzRZnxCVwM.Rc77d3dHeeVT6ZttkTwrFLkdlFILSfMeNzDx8Nsa-Kc&qid=1738956034&sr=8-1) (much against the desire of his publisher who hated it)
- You’re thinking, “*How does a race car explain stability?*”
- One of the fundamental differences between a race car and a street car is that in a race car, you’re transferring much more of that horsepower to the tires than you are in a street car
- In a street car, a lot of energy seeps out because the chassis is not very stable
- And you might say, “*Well, why?*”
- In the case of a car, because it’s more comfortable
- Race cars are not being optimized for comfort, they’re being optimized for performance
- If you’re optimizing for performance, you actually want more stability in the chassis and the suspension so that you’re transmitting more force to the tires and the tires to the surface

***Similarly, when you think about an individual who has stability, they are able to transmit force much more directly to the outside world, and they are able to receive force more safely from the outside world***

- And that’s why no matter how long you ever gave Peter, he could never throw a 100 mile an hour fastball
  - It’s not that he doesn’t have the strength
  - He doesn’t have the stability to be in motion and stabilize the capsule of his shoulder and transmit force like a whip through his arm
- You wouldn’t look at a pitcher and think that’s stability, but it’s remarkable stability (dynamic stability)

**The analogy Kyler uses in his practice – compare steering an old truck and a go-kart**

- He had this really old (mid-80’s) Chevy truck he was working on, and when you turned the wheel (let’s say his hands are at 9 and 3), it wouldn’t turn until his hands got to 12
  - The steering on that thing was sluggish
  - That dynamic stability wasn’t very good
- Where as a F1 car, a go-kart moves with micro movement
- If you translate that to the human body ‒ do a skater hop where you leap laterally from one side to the other
  - Can you stick that landing or are you falling over as you go?
- There’s a million **variables involved** there, but the big ones are your rate of force
  - Can you absorb that?
  - Can all your tissues, the arch, the Achilles, the IT band, the hip, your core, can all those tissues kick on at the same time to create stiffness, number one?
  - And a precursor to that is where’s your balance?
  - To generate that first force, were you organized or did you have to throw your head in hands a weird way to generate the force, but now I’m not in an optimum landing position?
- What a lot of times you see in youth athletes is people rush to put strength on them
  - A really good strength coach can put strength on a college athlete in 8 weeks
- But do they have speed?
  - Do they have organized movement?
  - Are they quick in all planes of motion?
- Is their balance really good because now my nervous system, my software is ready to absorb all these things, and then you put strength on top of that, that’s a great athlete

**A lot of these genetic people that are just naturally really good, they have some of that underlying ability to where they can land and organize well**

- [Stability comes first], and then later they put strength on
- Pick a sport and you can show me somebody who was really athletic and they weren’t really big and strong, but you can put the strength on later
- That’s one of Kyler’s biggest personal passions: 14 to 15 year olds who just get berated in the gym and then they tweak their back
- One local golf team, about 30% of their athletes had a stress fracture in their lumbar spine

Peter asks, “*How was the strength coach not getting fired?*”

- Kyler reached out to the head coach and the strength coach
- And to give all these people a little bit of a pass, they’re not really equipped because they’re managing 200 kids
  - It’s just a bad setup
  - You have 200 athletes that you’re supposedly managing a program for and you’re not watching technique
- Whether or not you know what you’re talking about, it’s a whole nother argument

Problem: The idea of we’re going to do a high performance on a 14-year-old and put strength on them, but no one’s watching technique or teaching them the foundations of lifting

***While at the same time they’re 14, we should be making them quick athletic and coordinated first because that’s a platform you want to build an athlete on***

- You don’t want to make a kid really slow but really strong when they’re 15
- It’s really hard to train speed as you get older

## The layered assessment process used at 10 Squared to determine whether a person is ready to perform dynamic movements [47:45]

**When a client comes into 10 Squared and you do an assessment, how do you gauge how far they are away from being able to do the dynamic movements?**

- One thing Peter loves doing is a broad jump
  - He wonders how late in life can he still do a broad jump of his height?
  - He doesn’t have it on his Centenarian Decathlon because he’ s strict about that only having 10 things
  - He loves it because it combines 2 things: concentric strength (the power to leap) and the eccentric strength to land and decelerate really quickly (more important and at least as difficult as the first)
    - [read more about concentric and eccentric strength in this [newsletter](https://peterattiamd.com/avoiding-injury-part-i-eccentric-strength/)]

Peter asks, “*How do you know when you look at someone if they’re ready to do that, for example?*”

- Kyler did a ton of work in the literature and the science

***Start with isometrics, the progress people to more explosive or compound movements (assuming no injury risks)***

Peter asks, “*And you would determine that based on just my history?*”

- No
- History, testing, demographic risk
- There’s a lot of variables we look into for having concern about musculoskeletal injury (that’s #1)
- Every person is different that way
- We’ve had people come in who’ve had multiple surgeries and injuries, and then we’ve had other people come in who they’re high risk for injury, but overall they’re a pretty good package to work with (not a lot of medical concern)

***Ignoring all the medical side of it, Kyler really likes following the principle that the exercise is the test because they basically look at everything about 4-5 different ways***

> “*I really like following the principle that the exercise is the test.*”‒ Kyler Brown

For example, if he watches someone do a [wall squat](https://youtu.be/PYva1ogC49s)

- That’s an isometric load
- It’s what we all used to do in high school where it burns your quads and your patellar tendons
- We can even set you up to where you’re in the right position, and that’s going to tell us (A) your comfort with the position

Peter asks, “*Is failure constituted by pain or not doing it for a certain length of time?*”

- Every metric they have has a qualitative and a quantitative associate
- The quantitative, we have minimums: it’s either time or percentages of body weights for every test
  - Or distances like you mentioned on the broad jump
- But then there’s also how does it look?
  - One is the vague part of the movement world, so you’re going to have your coach and Kyler both looking at it
- But then we have other ways where we’re confirming that with our motion capture machines, with our force plates, with our videos that analyze the movement
- There’s a lot of ways to confirm, and you can also see these things cross over

For example, how does someone do on the double-leg versus the single-leg provides information

- On 2 legs, they’re really strong and solid
- On a single leg, they’re abnormally less functional and weak and don’t have the range

***Kyler is immediately thinking there’s a balance control issue***

- Because they’re really stable on 2 legs, on 1 leg, they’re significantly less stable
- It’s much more complex for the body
- If their scores show they’re strong and their quads have capacity, but when they’re on single leg, they’re not as strong and they can’t stabilize
- That gives him a window to say, “*This person has a major balance risk or things like that.*”

Peter asks, “*In the case of that individual, do you not progress them?*”

- No
- We find their floor and we build from there
- Some people will have really cool robust Instagram-worthy exercises for one region, but another area we’re filling in gaps

***We’re building foundations, and we’re basically building them up from wherever those floors are***

- The key for us is this big grid we have where we have every category movement we care about, and then we build them from their floor
- Kyler is a really visual person, but he always says, “*Okay. We have this baseline floor maybe for their upper body pole, they’re on the third floor, they’re badass, they’re killing it. But then their core stability in one plane is in the basement*.”
- Kyler is worried about a lumbar stenosis or a nerve issue ‒ that takes precedence first
- Because he doesn’t want this person to experience pain and he wants to build them up to where they’re all on the first, second, third floor of the building

## Case study: the rehab plan designed to treat a hamstring injury while preserving fitness and preventing reinjury [51:45]

**Back to Jill**

- She got this diagnosis and figured out why her knee was hurting
- We now have a radiographic diagnosis that completely comports with what’s being seen on the physical exam and symptoms
- These are stubborn injuries

*What was the next step?*

- First, you have to have a parts approach
- If I have a damaged part, we need to determine if that needs intervention or not?
  - How are we going to address that?
- With Jill, we knew her foundational underlying movement patterns (or dysfunctions) that were contributing to that

***Kyler put a package together for her program that was all of those underlying structural functional issues that didn’t make the hamstring worse***

- We started building those right away while we considered [platelet-rich plasma](https://en.wikipedia.org/wiki/Platelet-rich_plasma)
- She actually ended up going for it to create essentially regeneration of that tendon at the damaged site, which she did perfect with
- We had to have a lot of “come to Jesus conversations” about, ***you cannot run too soon***
  - If we’re going to go through all this trouble and financial costs, we want to make sure that can heal as much as it can
- Everything we did in her programming was to ensure we didn’t flare that up
- Conversely, we really communicated with not just the strength team at 10 Squared, but also her physical therapist offsite and her running coach, and all of us had to put together this **6 month plan** where her running coach didn’t accidentally flare it up because he doesn’t have a window to everything we’re doing
  - He definitely needs to talk to the PT, as did we, to where she could get “medically cleared”

Peter should know, but doesn’t remember exactly how long she had to stop running

- It was right after the first and second [PRP](https://en.wikipedia.org/wiki/Platelet-rich_plasma) injections
- Does 8 weeks sound right? Yeah
- Because of her timing for the race and she wants to run Boston, we had a little extra runway
- The more healing time you can get, the better
- We have a lot of people who are really impatient, dying back to run
  - If you’re a pro athlete, you don’t have that luxury

**That’s what’s been fun for Kyler at 10 Squared: he doesn’t have all these environmental constraints**

- When you’re training for an event that’s 30 years from now, you don’t have to take shortcuts

> “*Let’s take a breath and be really detailed.*”‒ Kyler Brown

With Jill

- The PM&R docs and the physiatrist will always give you different amounts
- Usually 2 rounds of PRP for her issue
  - You do one round of PRP, basically do nothing, and then you do another round about two weeks later
  - And then you slowly let that heal and you start to add physical therapy
- With Jill, we were doing a ton of stuff around the area of the injection right away

***That’s imperative: you don’t stop everything***

*Kyler’s approach to healing an injury*

- You just protect the area and you train everything else
- That is going to be one of the reasons why we get a lot of success with her
- We did targeted physical therapy for that site to promote the healing
- On the physical therapy side, they’re using a ton of things like [BFR](https://en.wikipedia.org/wiki/Blood_flow_restriction_training), [dry needling](https://en.wikipedia.org/wiki/Dry_needling) (where necessary), everything you can to just help those parts heal
  - Foster that growth hormone
  - Foster that protein synthesis
  - Build that muscle up without a lot of force in the tendon
  - All those things that a traditional physical therapist that knows what they’re doing, they can crush that
- For 8 weeks, she had to swim
  - She was pleasantly open-minded
  - It’s hard for every athlete to not do their sport
- Kyler has delivered that medicine over and over for a long time
- So she swam; she didn’t lose any true cardio
- She lost a little bit of running strength, but someone with her background and her base and then keeping everything else really strong
- She’s going to hit the ground running and she’s running now and doing really well

**Kyler always says he has 2 athletes**

- 1 – The athlete to encourage
  - Those tend to be more your traumatic acute ACL type people, where you got to show them in the lab and show them in the gym that it is okay
  - Keep pushing, you’re good
- 2 – Then he has the other athletes where you have to hold them back
  - Jill’s going to be that one like, “*Let me go, let me go*.”
  - And we have to play bad cop just enough where science supports that, so that she doesn’t flare it up again
  - Because we need her to have a nice smooth progression
- Kyler would rather her be really balanced and athletic and strong and feeling good on race day, not like a bunch of junk miles and that tendon in the knee start to hurt her again and stuff like that

## Training approach for clients with minimal training history: risk reduction, habit-building, and long-term consistency [55:30]

**A hypothetical client who comes to 10 Squared**

- They’ve never really been an athlete
- They feel fine
- They’re not training a lot, but they’re young enough that it hasn’t caught up with them yet

***Those people typically don’t do very well on the assessment ‒ you can’t hide from not having done the work***

**How do you think about where to start when there is so much work to do?**

*Back to the building analogy ‒ we’re going to focus on the basement*

#1 we got to build the habit

- That’s a big part of this: your coach is basically in contact with you every day as much as you want to help bend and twist and develop that formula
  - Encouraging that person to do it

***You want to get to where they enjoy it, they like it***

- Kyler has had people tell me, “*Yeah, this core stuff makes sense, but I just hate getting on the floor.*”
- Okay, we got to pivot and change the program
- If he tries to convince you to do an exercise that you hate doing, it’s not going to last

#2 we want to really mitigate the risks of injury

- You get some momentum going on the psychological habit side, and then, “*I pulled my hamstring, I’m devastated.*”
- We got to get those foundations going, but then usually we look at the medical risk side
- For some people, the [CPET test](https://en.wikipedia.org/wiki/Cardiac_stress_test#) was terrible
  - Their VO2 number are bad
  - [VO2 max testing was discussed in detail in [episode #331](https://peterattiamd.com/olavaleksanderbu2/)]

***In our society, you got to have a good heart ‒ we want to get that off the table from a risk factor***

> “*We will probably really put that routine cardio in, in a manner in which we don’t flare up the things that could create an injury*.”‒ Kyler Brown

**One client had a fall risk**

- One client Kyler had recently, never had leg or foot issues at all, but his testing, his calves [showed] a big fall risk
  - His calves were crazy weak
  - He didn’t know it, he didn’t bring it up
- His balance wasn’t good because he didn’t have strength
- That’s definitely a high risk for an Achilles [injury]

Peter asks, “*How old is this person?*”

- 52
- Peter wouldn’t expect to see that in somebody so young
- This guy just poured himself into his career
  - Really successful, really smart, cool guy
  - But he just hasn’t trained a lot of stuff and he had kind of a health scare, which is what motivated him to get organized and get this stuff right
- It was interesting to see his really successful analytical brain use that scare to decide that he’s got to get sorted out
- You can see he operates his business the same way
  - Problem identification, what’s a solution?
  - Problem, solution, problem, solution

***So with him, he didn’t know he had any of these risk factors, but he was a textbook for having a fall or blowing out his Achilles because of the weakness and the lack of capacity and strength he had***

Peter asks, “*If you were to handicap that, how many years away would he have been from something like that being quite likely? Is this something that’s going to happen before he was 60?*”

- He could have been
- It’s a little fear-mongery, but he wasn’t set up to [deal with] having to change direction quickly
  - Maybe trips off a curb after dinner in New York
- He was a big guy too, top-heavy
  - Big trees fall hard
- With him, he wasn’t even aware of that weakness
- The last thing we’re going to do is give him a running program

***We got to design his CPET stuff and his VO******2*** ***max training and his Zone 2 training around these inefficiencies with his body; and so the workout in the gym needs to link up perfectly with those risks***

**What is the most important thing for him right now?**

Peter asks, “*Is that difficult to communicate to clients because do they ever feel like, ‘Hey, I’m not doing enough.’*”

- A lot of people are overwhelmed
- But what’s been really nice is the data, but then the calibration

***For clients Kyler has had for several months now, consistency is always the name of the game***

- Especially when we’re playing the long game like we are

**If someone’s going on a two-week vacation**

- We want to know, where are you staying?
- What does the gym look like?

***We will change your workout so that you can keep doing it while you’re on vacation***

- And if you tell us you’re going to be really active in the day and want to decompress
  - For instance, you’ve been working in your basement garage really hard for 3 months
  - Great, let’s take care of the total human
  - Let’s give him a 30-minute small thing to where he can almost have that lightening of the mental load (just decompressed), but he’s still making gains and he’s still building that up
- With this, if we get a video of your gym and we know you don’t have a bench that goes to incline, but you do have TRX and a treadmill that goes to incline
  - Or they don’t have a bike

> “*We can change their workout to where they keep marching along, and it’s in an agreeable way for them.*”‒ Kyler Brown

- It’s not just like, “*Oh, I was on vacation. I didn’t work out for two weeks*.”

**⇒** Because you get muscle atrophy if you don’t work out for two weeks (you go backwards)

## How to train foot reactivity, tendon resilience, and explosive capacity in a safe, progressive way [1:00:00]

**This idea about foot reactivity is so important**

- Peter has been much more attentive to it in the past couple of years
  - [discussed in [episode #296](https://peterattiamd.com/courtneyconley/)]
- He’s noticed the number of times when he’s lost his footing and regained
  - He never had a fall
  - It’s never resulted in anything because it’s been caught
- But he keeps thinking to himself, “*This is the type of slip that can be devastating*.”
- Because these are really [type II fibers](https://en.wikipedia.org/wiki/Skeletal_muscle#Fiber_types) that are doing it
- **⇒** And the type II fibers atrophying as we age

Peter asks, “*Are the types of jumping things that we do sufficient to preserve it? If you’re someone like me and you who, part of our CD involves probably walking on uneven surfaces one day*.”

- It’s like walking on pebble gravel, you’re always going to lose your footing somehow and you have to be able to regain it

**What are the most important exercises that you need to be doing to maintain all of the characteristics of tissue and nervous system to preserve?**

- The best way to answer that is more principle-based

1 – We behave in a three-dimensional space

- So this idea of only doing calf raises, my toes pointed straight ahead [is] insufficient
- To Peter’s point, there’s going to be moments where my toes are out or one toe is out

***We want to do all these strength exercises in multi planes of motion, and that doesn’t mean even in a static position ‒ you want to train in three-dimensional space***

- That’s like a lunge ‒ **lunging to the side; lunging backwards**
- All of your training should account for that
- If we’re just doing bicep curls and calf raises, it’s like I’m on these railroad tracks, but the minute you make me go sideways or rotate, it’s trouble

2 – To get motor unit recruitment to really make sure that those muscles are firing you need to do really heavy loads or things that are really fast, to get that nervous system to wake up and respond

- The problem with that is not a lot of us are ready for that
- What you usually start with is **really long-hold** [**isometrics**](https://en.wikipedia.org/wiki/Isometric_exercise)
  - So we put you in these different positions and find ways to resist that and pull and create stiffness and remodel those tendons
- We’re essentially making those parts ready to start going into the danger zone that is explosive, powerful movement
  - Maybe not danger zone as much as a higher ask or risk zone
- Heavy overcoming isometrics: one of Kyler’s favorites is that [mid-thigh pull](https://youtu.be/67JcdhZYbM0?si=0I2jj6xizyjGHCVk)
  - It’s kind of a standard in the sports science world where you have a bar and you basically calibrate the machine to where the bar is about the mid-thigh, and it’s almost like the very top of a deadlift. And you just pull, but the bar doesn’t get to move
  - And the sensory input is like the [ForceDecks](https://valdperformance.com/products/forcedecks), and they’re measuring your balance of your force and all these other cool metrics
  - Holding that over time, we’re now isometrically loading the heck out of my grip
  - You are loading the heck out of my shoulders
  - We’re getting into my feet, my quads, my hips, and I’m just holding that for time
  - That sets all these tendons up

Peter asks, “*And you just do this with a super, super heavy loaded bar that’s too big for you to lift?*”

- Not necessarily
- You can actually do an empty bar, but you pull it up against the safety bars or the rack or something like that

***There’s a lot of ways to load these heavy isometrics, because that gets your tissues ready, and you build that up over several weeks and that tendon adapts and now it’s ready to resist force***

**⇒** The way you bridge that is you start doing deloaded [plyometrics](https://en.wikipedia.org/wiki/Plyometrics)

- Maybe we do some sort of a [band-assisted pogo](https://youtu.be/julMQOePte8?si=dtMnLDey4RBWwDhG)
  - Where I’m actually pulling on a band overhead, pulling down on that band essentially lightens me, because the band’s going to pull me back up
  - Now I get to train that speed and that quickness through the ground, but it’s not my full body weight
- That’s a great way to bridge from: now I’ve got the parts ready, can I deload the amount of force and train the speed?

***Once I’ve got the speed going and the parts, now I get to become an athlete and do bodyweight and beyond***

Kyler explains, “*That’s where you see these really high level athletes, even at early ages, their trainers know how to build that paradigm up and bridge it across to where you don’t get any injuries along the way, but you get a really springy force-resistant person.*”

- So many of us don’t train pogos, we don’t train plyometrics
- If you go out to the local men’s or women’s soccer league, how many people there are over 40?
  - Not very many
  - There’s a lot of reasons why that is

> “*We’re not playing games and we’re not reacting to stuff. And so we need to make the gym a safe space where we can recreate these things and essentially test out these movements so I don’t lose it.*”‒ Kyler Brown

## Peter’s foot and ankle pain: how to diagnose, treat, and strengthen the lower extremities [1:04:15]

**Peter’s biggest source of nag in the past 12 months has been foot and ankle**

*Why are those injuries occurring?*

- They’re not debilitating and don’t prevent him from doing anything
- But he wants to know if this is a harbinger of something
- Kyler points out that Peter has very mobile feet (swimmers have great, mobile feet)
  - It really speaks to how your tissues adapt over time
  - Your feet have a ton of motion in them; they are not restricted
- Peter’s feet are actually pretty strong too
  - If we test your big toe and your smaller toes, you don’t test outside the normal limits for strength requirements
- Peter’s biggest gap is that multi-positional stiffness, and that ability to create force absorption through your tissues
  - He is actually set up for that because he can move so much, he doesn’t find either the bony in-ranges or those tendons can’t grab, because there’s so much play in that pattern

***What Peter accidentally does all the time is he’ll go on a ruck or go on a hunt where he’s off-road, and he’s getting all these angles that will slowly flare up a tendon***

Peter’s recent injury

- Two months ago, Peter decided to pick up a pogo stick
  - Just to add another activity
  - Use it to go up and down the driveway
- The second he started he realized it was not a good idea

Kyler responds, “*Yeah, that goes in the bucket of, you should have called me first.*”

**⇒** Tendons are notorious for not really hurting at the time, but they hurt like crazy the next morning

What’s common for [plantar fasciitis](https://en.wikipedia.org/wiki/Plantar_fasciitis) or [patellar tendonitis](https://en.wikipedia.org/wiki/Patellar_tendinitis)

- It hurts and feels really creaky and sore when you first get up in the morning
- That’s because tendons love blood flow, they love movement and they love motion
- All those chemicals that come with inflammation, if we’re just sitting around or sleeping, that’s the opportunity to get stiff and really sore and achy

**⇒** With that kind of symptom pattern, you’re not really lost on what it is: that’s classic tendon

- You can walk, we can load it, there’s no failure
- We’re not worried about a muscular strain or any other damage
- But that tendon gets really hot and spicy, especially in the mornings if you’re not creating that stiffness

Just to be clear, Peter is at 9-10 weeks since his pogo sticking debacle

- It’s no longer as bad
- But every single morning when he gets up, there’s still incredible and sharp pain right at that tendon

*Why is it taking so long [to heal]?*

- Tendons are one of the slowest things to heal
- Kyler guarantees if we really zoomed in and looked at all of it, Peter probably has a little tendinopathy in those tendons
  - A little damage here and there that could be contributing to that irritation

**⇒** The most important thing is understanding that tendons take months to regenerate

- With Kyler, Peter has had a pretty consistent attack with it, and they finally got him on a really good rehab program that Peter is doing himself
- Where we’re loading the heck out of it with these isometrics and we’re building the load more and more
  - And we’re loading those isometrics in different positions

**Example isometric exercises Peter is doing**

The front foot hover

- But Peter is actually plantar flexing
  - So when he’s driving, he’s doing as much of a calf raise as he can in that split squat position
  - And then we make you hold that while you do that split squat; so it changes the whole angle and the relationship
- It’s a complex movement
- A plate is in front of Peter, basically creating a step
  - Like a 45 bumper plate; a mini step
  - We’re 2.5-3 inches up
- The ball of the front foot and toes are on that
- He’s in a split squat

Peter asks, “*What am I doing with that front foot? I’m lifting it into plantar flexion?*”

- Yeah
- Peter’s toe-off was one of the problems
- What happens with him is when his heel lands, he’s driving his body forward and his foot’s behind him
- He would do a little bit of a rotation out and create a little bit of a whip through where it wasn’t nice and pure rotation rolling through the foot and the toe

***It was complex and putting extra stress at the ankle ‒ that times 10,000 steps a day will really pick at that tendon and make it sore***

- Which is why Peter wakes up the next day hurting

Kyler’s approach

- What we’re trying to do is put these tendons at different lengths and then putting a lot of load through them
- The complexity we’re adding isn’t necessarily at that joint
- We’re actually adding motion and complexity above with the lunge, and also the requirement of you having to stabilize centrally in that mid part of your body, while that foot is locked in

**⇒** Someone with a really mobile foot, you tend to really use that foot for everything, and that’s how you spice up those tendons

***Kyler is essentially putting that foot in a position where that tendon has to heal and it has to get stronger and he’s making the other parts of Peter’s body reach that complexity and meet the demand***

**What Peter can do to prevent a recurrence of this problem**

- This is the second time Peter has had this flare up
- The first time was a year and a half ago when he really started increasing rucking volume
  - [rucking was the focus of [episode #292](https://peterattiamd.com/jasonmccarthy/)]
- This time, it was caused by an acute incident on the pogo stick
  - It was extreme dorsiflexion that did it

*What do you think was driving it on the rucking side and more importantly, what does this mean for me?*

- While this doesn’t matter right now, Peter is concerned about the long-term
  - If this keeps happening and he’s in his 80s, this is the difference between reacting and not reaction and being able to get around

Peter asks, “*How do I prevent this from being a lifelong problem?*”

- That dorsiflexion when your toe is up
- When it’s a sudden acute force like on the pogo, you probably also just create a little bit of a joint irritation
- It’s analogous to jamming your finger
  - If you move those two joint structures together really hard quickly and your body can’t absorb that force, that’ll get a lot more sore than if it’s just kind of a slow, repetitive stress like the rucking
- They’ve noticed the relief when we do the manual therapy and things like that
  - That’s a nice short-term, “*Ah, feels a little better, a little less pain.*”

Kyler explains what the bigger picture and the ask of your body is, “*Teaching it, how can it respond to this and how do I build that force in those tendons to where not only does that tendon start to regenerate and heal, but then it’s also ready to react to all the things you do*.”

- Knowing that Peter loves to use those feet, and the more barefoot he is, the more likely he is to do that ‒ his prescription is

***We need to do a ton more quick work with you that’s deloaded to train all those tendons***

- There are so many tendons in the lower leg and the ankle

**⇒** We need to train all those tendons to get quick and stiff in different positions so you don’t jam the joint or create a stress in the tendon

**Should Peter be doing less barefoot activity?**

- No
- That’s a pathway to frailty
- You want to stimulate the receptors in the bottom of your foot

*Don’t go to extremes*

- Does Kyler want Peter running on a river barefoot with sharp rocks?
- No, because that’s going to cause other problems

***Having you barefoot makes your foot mobile and strong***

- Then if we piggyback that with this specific type of training for where your gaps are, it’s a huge payoff

**Let’s look at the other side**

- Most people don’t have Peter’s situation

**⇒** More often than not, people have a really rigid foot that’s weak and stiff

- So we’re actually going with a whole other direction where we’re trying to get motion in the foot
- We’re teaching that foot to separate rear foot and forefoot

Peter asks, “*How do those people present? What’s the pain or what’s the injury they present with?*”

- Interestingly, they actually get a lot of symptoms up the chain
- Our foot has so many bones and all these articulations where we’re supposed to comply to the ground
- If that shock absorption goes away
  - Like let’s say I’m wearing these big goofy running shoes that they sell now that have the rocker ‒ it’s like patching holes in the boat rather than optimizing movement
- If we have a foot that is stiff, those force factors go up through the body
- So now my knees, my hips and my spine have to figure out that force distribution because one of my best shock absorbers is the foot and the ankle

**⇒** If the foot and the ankle are not doing their job, everything else pays the price

**When the soleus (lower part of the calf) is weak**

- That control of their tibia as either walk or lunge isn’t there
- So that ankle just walks up and then they send all that force to their knee

> “*That’s why one of my favorites is anyone with a chronic knee issue, I’m going right at that foot and ankle first*.”‒ Kyler Brown

***Because if the foot and ankle isn’t up to the task, then the knee’s going to take a beating***

- Peter doesn’t want to jinx himself by saying this: despite all the crazy stuff he’s done, all the miles he ran growing up, he never really had a knee issue
- But boy does he get these feet issues
- Kyler observes that Peter has really good, wide, mobile feet
- And Peter’s knee gets to be a knee
- If that rotation, that pivot joint that’s supposed to happen at the ankle isn’t pronounced to the amount you want and it isn’t mobile enough, then that knee and that force vector’s going to happen at the upper tibia and the femur where now you start to get these little meniscus things that show up out of nowhere
- That torsion has to happen somewhere

## How fear and perception influence recovery, what drives back pain, and when to choose surgery vs. treatment [1:13:15]

- Sounds like you see this fear at 10 Squared where you have clients that are just coming in for the training piece of this
- Peter wonders if there is any common thread to this or does it come in all walks of life?
- He’s seen it in former athletes who are injured, but the injury is so bad that they just never quite want to go back down the path, especially if they’ve had multiple re-injuries
- He assumes Kyler sees this in people who are not necessarily athletes

**What do you think is going on there, and how do you work up the confidence to accept that the pathway back isn’t necessarily pain-free or injury-free but it’s more of a trajectory that’s going to get better?**

Kyler makes the point, “*The graph is always going to have peaks and valleys*.”

- When your brain perceives threat, not only is your heightened awareness up, your nervous system is kicked up, but you’re more sensitive to pain
  - Whatever that threat could be, maybe your dad hurt himself playing football, so you’re scared to play football

**⇒** Certain things hurt more when we’re ill or when we’re stressed than if we’re not

- If we stick to just movements themselves, a lot of people are afraid of certain movements because it hurt them in the past
  - Or they heard it could hurt them
  - Or maybe they just haven’t done it a long time
  - So they’re nervous about it

***You can actually empower people if you show them there’s a rational reason why that fear could be there or why that pain is there***

Kyler makes the point, “*Pain does not always mean injury. Pain is your brain telling you, ‘Hey, I don’t like what’s happening here.’ But it doesn’t always mean you’re broken or busted.*”

Another thing to think about is your image isn’t always a death sentence

- If we MRI a 100,000 low backs, there’s going to be wear and tear, especially if you’re over 30 years old
- Same goes for every other joint in the body
- Does that mean we design your whole clinical plan around that?
- No. We really need to think about, okay, how much is there?
  - What do they want to do?
  - What are their strengths?
  - What are their weaknesses?
  - All those things we already spoke to

***So when there’s fear involved, you really have to address that because the individual needs to know that A, you have a plan for them, that you understand their fears; and then B, we got to account for those fears in one way or another***

**Kyler’s experience in his practice with patients who have low back flare-ups**

- He’s talking about just your traditional back spasm, not a surgical candidate
  - High back pain, but no damage

**⇒** The amount of those people that have come in when their wife’s about to go into labor or they’re worried about getting fired from their job, where they have an **emotional mental stress** in their life, the amount of those people is infinite

- Kyler has had thousands of people come in who say, “*My back flared up out of nowhere.*”
- Then you start to dive in, “*What else is going on?*”
- And they’re really worried or stressed about something

***The goal there is you can’t always fix those external, cultural, psychological, emotional things, but we can address them and identify them***

- And sometimes they need therapy, they need other things to address those
- More importantly, we need to empower that individual and give them rational reasons why you’re like, “*Hey, this might be why you flared up in that glute or in that mid back. And this is what we’re going to do about it.*”

***If you outline those plans for people and give them the tools, now you’ve equipped them to actually help themselves ‒ it’s really about empowerment with education***

- This whole game of, “*I’m going to take an X-ray view and look, oh, there’s one little bone spur, but now I’m going to scare you into a 40-visit package to my chiropractor clinic*.”
- That game needs to go away fast
- Because the only thing you’re doing is making people feel more frail, more afraid, and you’re actually only helping the bottom line of your business
- You’re not helping that individual

**What is it that you would see when somebody comes in with a lower back complaint that would make you say, “*****Actually, the answer is seeing a surgeon or complete and total rest.*****”**

#1 evaluate the neuros

- If there’s weakness or you don’t have bowel or bladder function and things like that, right away get evaluated, right?
- Because the way nerves work, if there’s pressure on nerves, it could over time create permanent damage
- Now, a lot of nerve pain is sensory, that electrical sciatica-type stuff
  - It’s that tingling and that weird thing like that

***The real #1 thing that you look at is, do they have weakness or do they have loss of some sort of foundational control?***

- That’s when you got to get integrated with neuro and orthos right away
- If we don’t have that, now you’re in the decision-making domain

Peter asks, “*So this means you’re going to do the rectal exam, make sure sphincter tone is there?*”

- Yeah, exactly
- That’s definitely on the long list of things Kyler refers out for

**If you’re in that kind of mechanical low back pain or even some disc nerve issues, but no weakness, now there’s a ton of strategies we can do**

*A first diagnostic step to see how your body responds*

- We’re not going to do some crazy aggressive therapy or treatment or manipulation of the spine
- We’re going to do some sort of intervention like muscle work or [McKenzie exercises for discs](https://en.wikipedia.org/wiki/McKenzie_method), to see how the body responds to those things
  - Which are highly researched and really effective
- If your body responds in a positive way, even for 2 hours, that’s a great indicator
- Let’s keep going down this road because even the best surgeons that Kyler and Peter have both talked with about mutual clients, they’ll say, “*Let’s give this little time and see what your body does. Things can heal. The natural process of the body can take care of themself*.”

**One of Kyler’s favorite examples is a disc herniation**

- She confirmed on MRI, she was doing McKenzie protocol (which again is fantastic)

*The* [*McKenzie protocol*](https://mckenziemethod.com/) *for back pain*

- This is a really great system
- You essentially put the patient in various positions and you do this gentle arching or pumping, and you’re basically trying to take pressure off that disc, to where slowly over time, that bulge can recenter and balance out
- Their website has a [database](https://mckenzieinstitute.org/patients/find-a-clinician/) where people can find clinicians in their town

**⇒** If you have nerve pain, it’s a great place to start because all those [McKenzie practitioners](https://www.mckenzieinstituteusa.org/disclaimerTherapist.cfm#) know what Kyler just outlined (and if this method can help)

- What’s fascinating about McKenzie is sometimes even in the room, they’ll get reduction of nerve symptoms while they’re in that position
- Nerves provide very productive information
- You can trust symptoms of a nerve really well.
- If Kyler gets what they call a “centralization,” meaning, “*I had sciatic pain all the way down the leg, and then you put me in this one McKenzie position, and now it centralizes to the hamstring…*”
  - That’s a great diagnostic indicator

**⇒** Just because that individual might have an MRI with a disc herniation, that doesn’t mean it’s an injection or surgery right away

- Part of the decision making is what are they having to deal with in their life?
  - What is their timeline?
  - All those other factors

***If you can encourage a hot disc patient to wait and make sure that they’re actually letting things heal and run their course, they could be much better off in 4 to 10 weeks***

Peter adds, “*It’s almost always the sign of a great spine surgeon, which is, once you rule out the acute weakness, the thing that is a surgical necessity, the ones that want to wait are generally the better surgeons.*”

**Back to the case of disc herniation**

- She had a confirmed [disc herniation](https://en.wikipedia.org/wiki/Disc_herniation), and then she had an annular tear
  - Which basically the [annulus](https://en.wikipedia.org/wiki/Intervertebral_disc) is a part of the disc
- Best analogy to describe it is she had a little thing that was equivalent of a cuticle that was just kind of peeling off
- The traditional protocol, we started her on McKenzie’s
- But she was really hurting
- So we worked with her for like 2-3 weeks, and every time we put her in that McKenzie position, it hurt her worse
  - It was local pain
  - But the radicular symptoms reduced
- Long story short, what we learned over time was that the disc herniation was actually taking care of itself, but the annular tear was still sticking out and creating extension-based pain
- After about a year of rehab, her body was able to scar up and that healed (and it was fine)

***What was really interesting to Kyler was she needed McKinsey’s early, but then we actually had to cease the McKinsey’s because we were jamming that annular tear***

- Then we restored just more pillar strengthening, dynamic neuromuscular stabilization, all those other things

**⇒** Different [therapeutic] things at different times played a big role

**The impact of back pain**

- Back pain is common; Peter can’t imagine there’s too many people listening who down have personal or indirect experience with it
- He can really relate to it being nerve-wracking
  - It can be terrifying and just demoralizing when your lower back hurts in a way that it’s not the same as if your shoulder, elbow, knee, or hip hurt

- If you sprained your wrist, you might have to wear a brace or something, but you can generally function
- But when your ribs or your back is hurting, you can’t do anything without it affecting you
  - Not only are those muscles much more big and powerful, so when they react in spasm, they’re really good at it
  - The group of muscles in the low back are really good at freaking out
  - The [type I fibers](https://en.wikipedia.org/wiki/Skeletal_muscle#Fiber_types), postural stuff, a lot of detail
  - Sitting in a movie hurts, walking hurts, it affects you constantly

Kyler explains, “*A big part of the rehab story is finding these little wins where they can actually do something and it either does get worse (heaven forbid) or makes them feel a bit better.*”

## Could AI and app technology eventually deliver an individualized rehab and training experience? [1:22:30]

**Is this type of treatment scalable?**

- Peter feels fortunate that they’re able to take care of people and have the luxury of doing this very bespoke approach
- Integrate your strength and conditioning with your cardio, with your PT rehab and all that stuff and it’s all great

*Do you see a day when this could all be app and AI-driven where any person out there with any set of lower back symptoms could be provided with the feedback that they would need to take care of themselves?*

- If they execute, absolutely

**How would you get the feedback if you have good enough image recognition software? (would that be a necessary step?)**

- Peter thinks the advantage of being able to do this the first few times with an actual person is that the cuing is so important
  - A lot of these exercises are not natural
- Especially if you’re that person who’s suffering from that injury, then odds are you didn’t perform these exercises well subconsciously
  - That’s what set you up for it [the injury]

***What is interesting is the video recognition software is getting fantastic***

- Kyler has demoed a few now where the AI is actually watching someone do movements and saying, “*Hey, this was too far out that way or whatever*.”
- But that also goes in the bucket of everyone moves differently
  - My femur length is different than yours
  - So the angles with which I’m going to lunge are going to be a little different

**⇒** This idea that if you take principles and you know the symptoms and then most importantly you know how people react to really conservative loads, that almost tells you more than did their tibia rotate 3 degrees or not

- Kyler could care less about 3 degrees of tibial rotation based on AI software and way more about: if they did lunges in this setup and activates some neuromuscular reaction to where their glute fired a little bit better and their knee felt way better
- When people give him that good, quality feedback, now you know how to trim up that program

***The AI part is going to be more about how did the patient respond to each drill that’s safe? And that’s where training the AI is much more nuanced and complicated***

- And less about: what degree did it move?

*Image recognition is one thing, but it’s knowing what to do with that information*

- Knowing am I going to do an overhead dumbbell (on a DNS three month and all these other nuances) versus the legs
  - There’s certain cases that Kyler will do that one for one and the other for another
  - It’s really a matter of knowing what you got to start with, and then we test it a little bit
  - And then we test it a little bit more, and then the outcomes are dictated by how did they respond to that exercise

## Kyler’s professional evolution from traditional chiropractic care to a degree-agnostic, performance-based rehab philosophy [1:25:00]

**Kyler’s training and expertise in rehab**

- He went to chiro school and then immediately went out and did a sports medicine thing
- He worked with the NY Giants

*Why did you opt into the role you’re doing now, which is much more in the PT rehab space than it is what people assume of traditional chiropractic (which is a 40-adjustment schedule)?*

- It speaks to a bigger thing, which is Kyler is really degree-agnostic in the sense that he hopes someday in the future there’s a more clear certification or degree where there are chiros and PTs and strength coaches
  - All 3 of those people he would trust way more to do a rehab and get someone better
  - He would trust all 3 of those people to send his mom to if they have certain skill sets and approaches
  - Independent of degree or credential
- Chiro was his baseline training and where his license is
- But the traditional view of what chiro is with the manipulations and the adjustments, that’s 5% of Kyler’s week at his practice

> “*Our practice, we have chiros and PTs, but you can’t really tell who’s who because everybody’s doing what we call as active rehab*.”‒ Kyler Brown

One of the things Kyler always tells people is it’s about the one-to-one relationship

- He doesn’t care what their degree is
- It’s not group but one-to-one
- If they’ve got a bunch of weights in there as well as the traditional bands and stuff, that’s an indicator that these guys are going to build me back up to something actually strong
  - Not just make me come here forever and do rehab purgatory where I do the same micro drill over and over
  - We got to build over time

*Kyler tried to create a residency for himself right out of chiro school*

- Back then it was really manual-therapy-based
- He learned a ton
- He was by far the lowest guy in the totem pole, but he was there to soak it up
- Everyone always thinks pro sports is the top
  - And it is in a lot of ways
  - But it wasn’t really for Kyler in terms of an official team relationship because he just didn’t like that personal schedule
- It was pure chaos: you’d spend a week fixing somebody up and then they’d go out there and get blasted again
  - It’s kind of like when his son builds his tower Magna-Tiles and then his sister knocks it over
  - The look on his face was Kyler every Sunday
- Kyler enjoys he off-season side ‒ he really enjoys the project

> “*I realized early on that when you’re only doing pain relief, manual therapy work, there’s a lot missing. We’re not building people up*.”‒ Kyler Brown

That’s when Kyler started to do this deep dive to learn from as many people as he could about the foot and balance and neuromuscular training and all these other things

- To where it’s a compliment at his private clinic when people are like, “*What are you?*”
- We actually have people come into our office now who are like, “*I need to go see my chiropractor later.*”
  - And one of the other docs will be like, “*Well, I’m a chiropractor.*”
  - And they had no idea

Kyler explains, “*Regardless, we’re solving problems*.”

**What is the role for what most people think of when they hear chiropractic, the adjustments?**

- Peter doesn’t want to ask Kyler to be critical of a profession, but the fact that he’s not out there doing it 24/7 suggest something

*Do you think it’s a great plan when chiropractors recommend a package of 40 visits for X number of dollars, and see patients for 8 minutes a week, twice a week annually?*

- No
- Kyler has benefited from getting adjusted himself
  - Things get out of whack, things get stiff (that’s a real thing)

***It’s a tool in the tool belt, and the really good practitioners have a bunch of tools***

- Kyler could say the same thing about chiro adjustments as he could [dry needling](https://en.wikipedia.org/wiki/Dry_needling) or [active release](https://en.wikipedia.org/wiki/Massage#Active_release_technique) or [McConnell taping](https://en.wikipedia.org/wiki/Patellofemoral_pain_syndrome#Braces_and_taping:~:text=The%20technique%20of%20McConnell%20taping%20involves)
  - Like, a million tools out there

**⇒** The really good practitioners have a huge tool belt and they know when to use which one at what time

- So just throwing cupping at somebody and hoping their muscles get better, it’s insufficient
- In the same way Kyler  would say just adjusting someone over and over, it’s not enough
  - There’s more that could be done

**Kyler’s advice when friends ask about aches and pains**

- He gets asked a lot, especially now that he’s older and all his friends are older
- There’s exponentially more questions because they’re all getting sore and hurting

***His answer is to find someone who’s got a bunch of tools in their belt and who is going to treat your case as something unique every time***

- A big **red flag** at a practice: is everybody signed up for twice a month

**Kyler’s advice: you have to be adding strength**

- That’s what makes things stick
- That’s what optimizes movement
- That’s what makes people feel empowered and less frail
- Frankly, it builds more of like a moat around you to where if you do step off a curb weird or you sleep weird on a plane, you’re less of a triage patient
  - It’s more of just almost sore today, but you’ll still work out and the workout helps it

Peter asks, “*Is it safe to say then that whatever the suite of underlying modalities are (from adjustments to taping to cupping to needling, to active release to manual, you name it), the goal of all of these (and the more of them you can utilize, the better) is to create a window in which the individual is safe and out of pain so that they may do the work to retrain a movement pattern and increase strength?*”

- Absolutely
- We say that sometimes about even [cortisone injection](https://en.wikipedia.org/wiki/Cortisone#:~:text=A%20cortisone%20injection)
  - Kyler doesn’t like people racing to get a cortisone injection
  - If you tell someone to strengthen a knee that really hurts when they do a lunge, they’re going to look at you like you’re a jerk
  - At some point, we need to do something to get that pain down so then we can open that door and run through it, and running through it with strengthening and making them stronger

## How 10 Squared provides precision rehab and training in a remote format [1:30:30]

- Peter points out that they’ve gone really deep down 1 of the 3 pillars
- You now have basically 2 things you’re trying to do
- 1 – You’re trying to do everything you’re doing in concert with a broader agenda of creating a precision training program
  - Not an exercise program, not a workout program
  - A training program for an athlete whose sport happens to be life
  - And you have to be able to do it with the strength and conditioning coaches, the cardio coaches
- 2 – The other thing you have to be able to do is you have to be able to do this remotely because most of the 10 Squared clients are remote
- They come to Austin for two days, they do a whole bunch of assessments, they go away for 6 months, then they come back
  - Some of them go away for less [time]
  - A lot of them, they go away for a year because they’re out of the country and it’s just not easy for them to be here

**How are you able to do this remotely? What are the challenges and what enables it to make sense? What do they need when they’re back home?**

- Some of the athletes Kyler manages travel a lot (like golfers)
  - He has the luxury of knowing so much about them, how they move, and what their body looks like
  - So when they say their back hurts from the hotel room, he can rule-out the scary medical stuff and try some exercise
- He is able to get a lot of results for these athletes who are about to tee off in 2 hours and compete
- Kyler has taken this model, and when he designed the assessments at 10 Squared, one of the biggest themes was, “*We need enough time to know as much as we can.*”

***A lot of people want it to be faster, but that initial step needs to be so in-depth that we are certain about all the factors of how you move and where you’re strong and things like that***

- When Kyler has that certainty, he’s not flying blind when someone calls him about a sore knee after doing certain exercises

**⇒** They can hop on a zoom and just talk real quick and Kyler can actually test them on zoom because the exercise is the test

- So many people think they need a doctor to do a lock rinse test and pull on their leg, the story, their profile

> “*How they respond to the exercise, that is the test*.”‒ Kyler Brown

***We can program exercises really effectively in a remote way to probe the fence or test it, and if it responds the right way, we definitely can fix it quickly***

**Kyler’s client this week**

- His shoulder was bugging him
- We did a Zoom call, took about 20 minutes
- We have our library at 10 Squared and Kyler fired him off a few exercises

***He messaged Kyler and he feels a lot better; and he didn’t have to go to a doctor, he didn’t have to go anywhere***

- Now obviously if the story was different and Kyler was worried medically, he’d concierge that in the sense of he’d find him someone local and refer out
- But if he’s not worried medically and if we think it can respond to load, we’re going to load it

***And a lot of times people are shocked that we can make their neck tension go away with an exercise in the same way that if they traditionally got a massage or something, they’d get that relief***

**⇒** It has to do with what your body does when things are off and if you load, it’ll actually respond more because your nervous system’s involved as well

## How Peter resolved a severe back pain flare-up using DNS-guided isometric exercise instead of passive treatments [1:33:15]

**Peter’s incredible experience with DNS**

- This would have been 2018, 2019
- It was the first flare-up of his lower back since 2000 when he had a botched surgery
  - He had gone 18, 19 years without a single flare-up
- Peter was working with a guy, the first person he’d ever met who did [DNS](https://pmc.ncbi.nlm.nih.gov/articles/PMC3578435/#:~:text=Dynamic%20Neuromuscular%20Stabilization%2C%20or%20%E2%80%9CDNS,of%20developmental%20kinesiology%20(DK).)
- He had already learned about intra-abdominal pressure (he was doing all that stuff)
- When Peter went to see him, his back was totally fine ‒ he had tennis elbow
- He figured out pretty quickly that Peter’s tennis elbow was completely due to his scapular instability
- Peter’s chief complaint was when he does a lot of pull-ups, his elbow hurts (he doesn’t even play tennis)
- After his elbow was fixed, Peter thought, “*This is amazing. I want to know what else is going on*.”
- Then independent of that, he gets this lower back flare-up
- He’s seeing this guy one day and he’s in the worst pain he’d had for years
- This guy is a chiro by training who probably hadn’t done an adjustment in 20, he focused on DNS
- Peter will never forget the exercise he had him do
  - He had Peter lay on his back, get into an imaginary leg press position
    - Imagine those old-school leg press machines where you’re pressing up
    - Not the one where it moves on a slope, but the rack moves vertically
  - Now this guy is laying on top of Peter ‒ he’s got his pecs on Peter’s feet and he’s cuing Peter through really good intra-abdominal pressure and isometric contraction (pushing)
  - And low and behold, Peter’s back is getting better and better as they are doing sets (10-second, 20-second, 30-second)
  - At some point, Peter is getting so strong he needs more resistance
  - They build a makeshift thing under the squat rack where he has infinite resistance
    - Kind of how Kyler described with the partial deadlift
- When Peter walked in there, he was getting to the point where he wouldn’t have been able to push 10 lbs. away from himself (that’s how much pain he was in)
- Now he was convinced he was pushing 600 lbs. of force against that immovable bar, and he’d never felt better

***He couldn’t understand how that could happen – how could he limp into that guy’s gym in so much pain and spasm and an hour later, feel like a million bucks?***

**Kyler points out: this story speaks ot how pain is inhibitory**

- When your brain is perceiving that threat in that pain, it goes into preservation mode where it’s like, “*Look, I’m not going to have you run the fastest forward of your life because I don’t trust all these movements. I’m trying to figure this out.*”
- Kyler’s analogy is that hand on the buzzer with Family Feud
  - Where the brain, whenever it feels threat, it’s like, “I*‘m going to hit this buzzer and I’m going to send you a pain signal*.”
  - It doesn’t mean you’re damaged
  - It’s just like I’m hovering
  - And if you’re really stressed or it’s a really high-level pain, it’s going to do it at first sign of trouble

*How do we get the brain to take the hand off the buzzer?*

- What loads can we introduce to cause reciprocal inhibition in these muscles?
  - To explain this term: if I’m going to contract my bicep like crazy, my tricep almost has to eventually get enough signals where it can’t fire
  - Your brain might be trying to fire it and it’s got this co-contraction going on and there’s that protection going on
  - But the more stimulus you give that bicep, eventually that tricep has to let go
- What he was doing was putting Peter in very specific positions to where Peter had to load something
- Where neurologically, his brain says, “*I’m going to turn this other thing off and I got to actually meet the demand of this force*.”
  - Because force is how your nervous system responds
- He was loading one direction so much that eventually that [QL](https://en.wikipedia.org/wiki/Quadratus_lumborum_muscle) (or whatever else could have been spasming with Peter) had to eventually kind of melt and let go
- Not only was Peter now activated and stable and feeling stronger, but that muscle that was in this inhibitory contracted state and then it let go

**In Kyler’s first 5 years out of school, he was working on QL all the time**

- His thumb has scars from it
- He doesn’t touch the QL anymore
- 10 years ago, he realized you don’t have to beat someone up so much
- In a weird way, these kind of exercises are more gently
  - They’re more therapeutic, more long-term, they’re active
- You’re tapping into that nervous system

> “*Having someone do a very specific exercise based on their profile and their symptoms is actually a great way to make someone feel better and you just got to give them the right stuff*.”‒ Kyler Brown

**Peter’s takeaway**

- Peter considers that one of the most profound experiences of his life from a physical perspective and also in how much it changed his point of view about what back pain is and isn’t
- He’s not suggesting that if you have back pain, that’s the answer (to go find a guy to do that)
- Instead, there’s so much more going on than we realize
- So much of back pain is not surgical

***So much of back pain can be healed with retraining a movement pattern and getting our nervous system to get out of the way***

- Kyler has a lot of clients that are nervous about the chiro thing
- They want help with their neck, though
- Kyler knows there’s a million other ways to cook this recipe
  - To normalize the motions of your joints and make the muscle strong again
  - To reestablish the relationships of your shoulders, your scapula, your neck

***There’s a million ways to make someone feel better with exercise where you don’t have to do aggressive therapies***

- Kyler doesn’t care if it’s stem cells, PRP, prolo, dry needling, or chiro (it doesn’t really matter)

**⇒** Exercise needs to always be the answer and you can do therapeutic exercise that actually does a lot for people and drops the pain too

## How to identify and treat common joint pain (neck, back, knee, shoulder) using a rehab framework that strengthens supporting structures and helps avoid surgery [1:39:00]

**Exercises for what 80% of people complain about: neck, lower back, knee and shoulder**

- Kyler points out that some of these don’t look like a knee exercise, but it could help the knee
- It’s this idea of working around a structure that has pain to help that structure feel better
- These regions are really common, really debilitating, and frankly, generally people whiff on these a lot

*Kyler’s framework*

1 – Going back to that bifurcation he talked about earlier: do we need to consult an orthopedic or neurosurgeon (that’s #1)

- Kyler makes that decision based on the story, the incident, what it looks like
  - 1 – If it’s a knee and they’re a soccer player who twisted it weird yesterday
    - If it’s all swollen on the joint line; he’s more worried about the joint
  - 2 – If it’s a runner where the pain has been off and on for a long time, there’s no acute incident
    - No joint-line swelling and the pain is kind of vague
  - Those are 2 very different presentations and (1) is more of an ortho consult while (2) is better for tinkering around with a rehab pro to see what you can do

***That’s the first bifurcation, determining the right path***

- Kyler points out that the best orthopedic surgeons don’t want to do surgery or inject everyone right away
- They’re referring out all the time
- A lot of clinics nowadays have a physical therapy in-house
  - And there’s all kinds of constraints with that
- The best orthos don’t just give someone a list of every PT clinic in town
- They’re actually referring to different clinics based on that clinic’s strengths and experience
  - Some clinics specialize in running, some specialize in strength training

**⇒** If your ortho is specifically searching out different PT clinics, that’s a great sign they know what they’re doing

- If your ortho just gives you a handout and they’re like, go call somebody
- That means they think all PT’s the same and all rehab’s the same (and it’s not) .

2 – Once you know that it’s a  rehab case, the protocol turns into what is the safest and smartest way to create change

- Maybe it’s a manual therapy maybe
- Maybe it’s one of those treatments Kyler spoke to earlier or maybe it’s a strategic load
- A lot of times, that decision is based on the patient’s comfort
  - Read the room: are they a cattle rancher dude who wants to push through pain and they’re going to go back to work tomorrow?
  - Or are they someone who’s really scared because the pain is high?
  - We got to build trust
  - We got to get them some sort of pain relief to show that we’re medically being responsible and making sure we’re going the right direction
- Once we’ve created that change, then we start to load it

*If working on a patient with a total knee replacement*

- A lot of times if Kyler is working on a joint that is permanently compromised (say it’s someone with a total knee replacement), he’s not going to beat up the knee a lot
- Traditional insurance-based rehab is going to go after that joint because that’s the code that’s associated with it, and they know they’re going to do that really well
- What Kyler going to go for first is the foot, the ankle, the hip, and their pelvis in general
  - There’s a lot of low fruit there
  - He can enhance the pelvis strength or the foot strength

***He can actually buffer that knee to where it doesn’t have to work nearly as hard and those people get a reduction in symptoms overnight***

**Goals for the exercise videos**

- Show people a few examples of what they can do and how they can put this into their own practice
- Kyler wants to focus on what people could do for themselves right away (without having to make an appointment somewhere)

*Looking at 3 things that can go wrong*

- 1 – In the musculoskeletal tissue
- 2 – In the joints
- 3 – In the motor controller exercise window
- He’s going to dive into some of these exercises that might not be expected to be helpful for your neck or your shoulder, but actually indirectly can load those structures to try to get that relief just like Peter experienced with his lower back

***Kyler’s going to show people a set of exercises around each of those 3 pillars per joint***

- He’s going to dive in and show this is what you can do for the tissue, this is what you can do for the joint
- Most importantly, these are some loads you could do that actually help reprogram that software to where you actually stop overloading the area that hurts and get everybody else back on track

§

## EXERCISE VIDEOS

- We are going to transition to show some of the stuff we’ve been talking about
- Obviously, it’s a finite number of things we can show

**You’ve been pretty deliberate about the exercises you’ve chosen, why is that?**

- It goes without saying, nothing beats an assessment
- Kyler wanted to make sure the exercises we provided people are safe for almost everyone
- It’s worth noting, that if you’re worried or have had an acute traumatic injury, nerve pain, or things like that ‒ get evaluated by a medical professional
- He wanted to make sure these were accessible to everyone
  - You shouldn’t have to do homework or have a ton of equipment
  - He wanted to highlight exercises that people could do at home on the floor, or they could use minimal equipment

**⇒** If you have neck pain or knee pain, you can do a lot of good for those body parts by working on something somewhere else

- What you’ll see as we go through this is that the neck section may have exercises in the shoulder or mid-back

***We’re not directly attacking the joint that is painful, and that’s an important way to do this responsibly***

\*\*\*

**Lower back**

- This is near and dear to Peter’s heart personally, and most people go through at least one bout of acute lower back pain in their life
- We talked about how much of a cost this is to society and frankly how debilitating it can be
  - Not just in physical pain
  - But psychologically, this is a devastating injury for many people, and there’s a real fear of, “*I’m never going to get better.*”
- We’ve learned a lot along the way about how lower back pain is treated
- One thing is clear: complete and total rest is not the answer

***While rest has its place, a more active approach to recovery is better***

*How do you think we’re going to get through that?*

- When someone is in debilitating pain, you come across as curt or unempathetic if you suggest they go for a walk and power through it
- The reality is, you’ve got to find a place to start movement, start downloading your body, and downregulating your pain
- The exercises chosen are aimed at not only pulling from that DNS world where you’re generating intraabdominal pressure, but also start to load the core a little bit
  - Which has a lot of benefits on respiration and downregulating pain
- These exercises were intentionally chosen so everyone could do them, they’re really easy to do, and they’re generally very safe for the low back

DNS 3 month:

DNS prone 4.5 month:

Half kneeling halo:

\*\*\*

**The knee**

- We’re limiting this to chronic knee pain
  - We’re not talking about the running back who gets tackled and tears his ACL

*Isn’t it the case that the knee is one of those systems where if there’s a chronic pain, it’s often tied to a dysfunction at a different joint?*

- That’s very common
- The knee is almost always the victim in those kind of scenarios
- One general rule, whenever Kyler has a patient with chronic knee pain or knee arthritis, the first thing he wants to look at is everything else
  - He’s going to make sure that foot and ankle are working really well
  - He’s going to make sure the hip and core are functioning well
  - More importantly, making sure there’s not an overload to one side
- The 2 exercises chosen are intentionally covering a lot of these bases at once
- These exercises are slow and pragmatic so that the user at home can try them out and see how they feel
  - The videos clearly explain where you should feel discomfort or effort happening, versus the knee

DNS hanging stance:

Soleus Bridge:

\*\*\*

**Neck**

- The neck is another one of those areas that is similar to lower back pain: when it is flared-up, it seems to consume all of your attention
  - It can cause a great deal of physical discomfort and emotional discomfort
- It’s safe to say, we are seeing an increase in the incidence of neck pain
  - Part of that has to do with changes in posture as near work has become more frequent (phones have accelerated that) ‒  radiologists have this term called “tech neck” which describes that unnecessary flection
- While diagnostics are really important, and there’s a lot of real estate in a very small area, the types of problems that can occur if left unchecked are pretty significant

*How are you going to go through that?*

- It always comes down to that point of stress
- If you have symptoms (structural or not), the neck is working really hard for us all the time

***These exercises are targeting the areas around the neck***

- If your neck is already working really hard, and then you have a lot of restrictions in your thoracic spine
  - Or your rotator cuff isn’t active and strong like it should be
  - Then your neck and the areas at the bottom of the neck have to work even harder to help you perform daily tasks
- While we can’t evaluate every person listening to this podcast to rule-out if they have radicular nerve pain, we wanted to go after their shoulder, their thoracic spine
  - To decrease the tension in that whole chain
  - So you can determine if that relieves your neck pain
  - The problem might be something that’s not the actual neck structure

Supine touchdown:

Eldoa T6-T7:

Prone W’s:

\*\*\*

**Shoulder**

- The shoulder is another system that is near and dear to Peter’s heart
  - This is something he’s injured and gone through the process of getting better
- It’s a special joint, given that evolution has allowed for us to have incredible mobility that’s allowed us to do wonderful things
- But that mobility has come at a cost, and the cost is susceptibility to injury that we don’t necessarily see in the hip
  - An otherwise similar joint that is far less mobile

*What are we going to talk about with respect to how to deal with this joint that is so important for life yet prone to injury?*

- Kyler wants to show very simple ways to activate stabilization
- There’s this ratio in the body where if it needs a lot of stability, and it has a lot of motion ‒ we need to make sure it’s really stable
- Other areas are by default, built stable

**⇒** The most important point Kyler likes to drive home: because the shoulder is hyper mobile (and it’s supposed to be mobile), you can have high levels of pain and nothing wrong structurally; and you can also have minimal pain and structural compromise

- For example, Peter was fairly functional even though his labral tear was pretty significant
- Kyler wanted to come up with some safe ways to activate that stabilization
- People in his clinic are sometimes shocked at how the right exercise, in the right position, and activating that relationship with all that stability can drop their pain a significant amount

Plank saw:

Kettlebell arm bar:

Prayer stretch:

---

## Selected Links / Related Material

**More content on**:

- [Centenarian decathlon](https://peterattiamd.com/category/exercise/centenarian-decathlon/)
- [High intensity training](https://peterattiamd.com/category/exercise/high-intensity-zone-5-training/)
- [Stability](https://peterattiamd.com/category/exercise/stability/)
- [Strength and muscle mass](https://peterattiamd.com/category/exercise/strength-muscle-mass/)
- [VO2 max](https://peterattiamd.com/category/exercise/vo2-max/)
- [Zone 2](https://peterattiamd.com/category/exercise/aerobic-zone-2-training/)

**Episode of** ***The Drive*** **with Alton Barron**: [#232 ‒ Shoulder, elbow, wrist, and hand: diagnosis, treatment, and surgery of the upper extremities | Alton Barron, M.D.](https://peterattiamd.com/altonbarron/) (November 28, 2022) | [5:00]

**Episode of** ***The Drive*** **about BFR**: [#179 – Jeremy Loenneke, Ph.D.: The science of blood flow restriction—benefits, uses, and what it teaches us about the relationship between muscle size and strength](https://peterattiamd.com/jeremyloenneke/) (October 11, 2021) | [7:00]

**Personalized training to prepare for the marginal decade**: [10 Squared](https://10squared.com/) (2025) | [24:15]

**Episode of** ***The Drive*** **Bout DNS**: [#152 – Michael Rintala, D.C.: Principles of Dynamic Neuromuscular Stabilization (DNS)](https://peterattiamd.com/michaelrintala/) (March 8, 2021) | [40:15]

**Episode of** ***The Drive*** **about the importance of foot strength**: [#296 ‒ Foot health: preventing and treating common injuries, enhancing strength and mobility, picking footwear, and more | Courtney Conley, D.C.](https://peterattiamd.com/courtneyconley/) (April 1, 2024) | [1:00:00]

**Episode of** ***The Drive*** **about rucking**: [#292 ‒ Rucking: benefits, gear, FAQs, and the journey from Special Forces to founding GORUCK | Jason McCarthy](https://peterattiamd.com/jasonmccarthy/) (March 4, 2024) | [1:09:45]

**McKenzie Method for treating back pain**: [The Original McKenzi](https://mckenziemethod.com/)e (2025) | [1:18:45]

**Find a McKenzie clinician**: [1:19:00]

- [The McKenzie Institute USA: Find a Provider](https://www.mckenzieinstituteusa.org/disclaimerTherapist.cfm#) (2025)
- [The McKenzie Institute International: Find a Clinician](https://mckenzieinstitute.org/patients/find-a-clinician/) (2025)

---

## People Mentioned

[Alton Barron](https://altonbarronmd.com/about/) (Orthopedic surgeon specializing in the shoulder, elbow, and hand; Clinical Associate Professor of Orthopedic Surgery at NYU Langone Medical Center, Senior Attending Physician at the Roosevelt Hand to Shoulder Center at OrthoManhattan; and Medical Director of Pinnacle Surgery Center in Austin) [5:00]

---

![](https://peterattiamd.com/wp-content/uploads/2025/05/bio-kylerbrown-600x600.jpeg)

##### Kyler Brown, D.C.

Kyler Brown earned his BA at the University of California, San Diego (UCSD), and Doctorate of Chiropractic from Palmer West. Dr. Kyler Brown (DC, CCSP) is a sports chiropractor with deep experience across multiple professional sports leagues (including the NFL, NBA, NHL, PGA, LPGA and MLB) and has always been fascinated with optimizing physical performance for both athletes and the general population. Kyler co-founded [10 Squared](https://10squared.com/) with Peter.

Kyler specializes in bridging the gap from post-surgical rehabilitation, all the way back to high performance. As the Director of Injury Prevention at 10 Squared, Kyler brings his deep clinical expertise to all of the 10 Squared assessments and programs to pursue high performance while simultaneously accounting for injury history and potential risks.

Instagram: [@drkylerbrown](https://www.instagram.com/drkylerbrown/)