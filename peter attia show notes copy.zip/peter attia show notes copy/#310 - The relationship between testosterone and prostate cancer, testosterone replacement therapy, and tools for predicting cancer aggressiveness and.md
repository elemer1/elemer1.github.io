# #310 – The relationship between testosterone and prostate cancer, testosterone replacement therapy, and tools for predicting cancer aggressiveness and guiding therapy | Ted Schaeffer, M.D., Ph.D.

**Source:** [https://peterattiamd.com/tedschaeffer3/](https://peterattiamd.com/tedschaeffer3/)

---

Ted Schaeffer is an internationally recognized urologist specializing in prostate cancer and a returning guest on The Drive. In this episode, Ted provides insights into the role testosterone plays, or doesn’t play, in the initiation and progression of prostate cancer. He unpacks the findings and limitations of the recent TRAVERSE trial, exploring the complex relationship between testosterone and prostate cancer. Ted delves into the molecular nature of prostate cancer, explaining the androgen receptor saturation theory and the potential impact of testosterone on cancer growth. He also discusses the use of the Decipher test to predict cancer aggressiveness and guide targeted treatment. Furthermore, Ted shares how he counsels patients regarding testosterone replacement therapy (TRT), including its safe administration in patients with low-grade prostate cancer. Additionally, he highlights advancements in prostate cancer therapies and biomarkers that help develop precise treatment strategies while minimizing the need for broad androgen deprivation therapy.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/tedschaeffer3/the_Drive_public.png)

Play

#310 - The relationship between testosterone and prostate cancer, testosterone replacement therapy, and tools for predicting cancer aggressiveness and guiding therapy | Ted Schaeffer, M.D., Ph.D.

#310 - The relationship between testosterone and prostate cancer, testosterone replacement therapy, and tools for predicting cancer aggressiveness and guiding therapy | Ted Schaeffer, M.D., Ph.D.

1x15s30s

0:0047:53

## We discuss:

- Background on the TRAVERSE trial: insights into exogenous testosterone and prostate cancer risk [3:00];
- The androgen receptor saturation theory: how different organs respond to varying levels of testosterone [10:30];
- The relationship between testosterone levels and prostate cancer aggressiveness: how aggressive prostate tumors have lower androgen receptor activity and rely on different growth mechanisms [16:15];
- Using the Decipher score to assess prostate cancer aggressiveness and guide personalized treatment strategies [23:45];
- Considerations for testosterone replacement therapy: how Ted counsels patients, how TRT can be safely administered in patients with low-grade prostate cancer, and more [31:15];
- Advancements in prostate cancer therapies and PSA as a biomarker for precise treatment decisions minimizing the need for broad androgen deprivation therapy [38:30]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Dr. Ted Schaeffer was a guest previously in [episode #273](https://peterattiamd.com/tedschaeffer2/) in October of 2023 and [episode #39](https://peterattiamd.com/tedschaeffer/) in February of 2019
- Peter wanted to have Ted back on to speak about one very specific topic: testosterone and prostate cancer, given a [recent study](https://pubmed.ncbi.nlm.nih.gov/37326322/) that came out since our last conversation
- He figured it would be great to have Ted back on to speak about this, given the interest in this topic that Peter sees in his practice, in addition to all of the questions that are constantly come in from the website and social media
- Throughout this podcast we reference the [TRAVERSE trial](https://pubmed.ncbi.nlm.nih.gov/37326322/) and we talk about what the trial directly showed in addition to what was not entirely clear from the study
  - This is a study Peter has [written](https://peterattiamd.com/traverse-trial-and-trt-in-men/) about in the past, some of its limitations
- The essence of this discussion is understanding the role testosterone plays in prostate cancer initiation and propagation
- Even though this is a topic Peter spends a lot of time reading about and discussing with experts, he came away quite surprised with some of the insights from Ted
- Given the ubiquity of testosterone replacement therapy today, this is an important topic for anybody who’s ever considered it or anybody who cares about someone who’s ever considered it
- Unfortunately, there’s a lot of bad information out there when it comes to the role of testosterone in prostate cancer
- Fortunately, the literature provides a lot of evidence for how testosterone can be safely used, and when it should not be used
- Ted is an international recognized urologist and prostate cancer oncologist, author, and speaker
  - He’s the chair of the Department of Urology at the Feinberg School of Medicine and the Urologist in Chief at Northwestern Memorial Hospital and program director there
  - He is also the co-author of one of the definitive textbooks in urology: [*Dr. Patrick Walsh’s Guide to Surviving Prostate Cancer*](https://www.amazon.com/Patrick-Walshs-Surviving-Prostate-Cancer/dp/1538726866/ref=sr_1_4?crid=E70A0SEF22CV&keywords=Dr.+Patrick+Walsh%E2%80%99s+Guide+to+Surviving+Prostate+Cancer&qid=1695059493&sprefix=dr.+patrick+walsh+s+guide+to+surviving+prostate+cancer%2Caps%2C237&sr=8-4)

## Background on the TRAVERSE trial: insights into exogenous testosterone and prostate cancer risk [3:00]

- The [TRAVERSE trial](https://pubmed.ncbi.nlm.nih.gov/37326322/) was published a year ago, and it set out to answer the question: *Does the use of exogenous testosterone increase the risk of ASCVD in men?*
- Peter has [written](https://peterattiamd.com/traverse-trial-and-trt-in-men/) about this trial
- We’re not going to go into great detail with respect to its primary outcome of ASCVD

***The short answer is it did not increase the risk of ASCVD***

- Peter and Ted found themselves discussing a question of prostate cancer

**Tell folks a little bit about what we did and didn’t learn with respect to prostate cancer from the TRAVERSE study**

- This study looked at men who were [hypogonadal](https://en.wikipedia.org/wiki/Hypogonadism), who presented with some degree of symptoms, and then the idea was to replete their testosterone, bring it up to a eugonadal level
  - The bump that they had in the TRAVERSE was pretty small, 140 ng/mL, so a tiny bump with bearing in mind about a 60%+ dropout rate at 5 years
    - Very few people were actually maintaining the protocols that they originally set out to do at the beginning of the study
- With that in mind, the idea was: **does supplementation of someone’s endogenous testosterone with exogenous testosterone increase one’s risk for being diagnosed with prostate cancer**, with the implication that this could address 2 potential concerns
  - 1 – Exogenous T would fuel the progression of an pre-existing prostate cancer
  - 2 – And/or exogenous T would induce a cancer de novo in somebody with a low T state when you bring them into a higher testosterone state

*There is a lot of detail about who was enrolled in the study*

- Everybody was hypogonadal and the mean [PSA](https://en.wikipedia.org/wiki/Prostate-specific_antigen) for individuals in TRAVERSE in both arms was around 0.9 ng/mL
  - So this is a low risk group of men because we know PSA is the main way that we screen for prostate cancer
  - In general, the higher one’s PSA, the higher one’s risk would be of being diagnosed with prostate cancer

***On average, these are men in their 60s with low testosterone and low PSAs on average ‒ they are a low risk group, and you take them from a hypogonadal to barely eugonadal state***

- Ted explains, “*The bottom line for the trial in a secondary analysis pre-specified, was that there were no more prostate cancers diagnosed in men on T replacement versus on placebo.*”

*The total number of prostate cancers in TRAVERSE that were detected was very low*

- In a cohort of 5,300+ men, there were 23 total cases of prostate cancer in the TRAVERSE study [12 in the testosterone group and 11 in the placebo group, see the figure below]
- The features of the individuals who had prostate cancer in TRAVERSE were on average higher PSAs than the median
  - Again, the median PSA on entry was around 0.9
  - Individuals who were diagnosed with prostate cancer had higher median PSAs and had higher shifts in their PSA while in the TRAVERSE trial than those men that did not develop or were not diagnosed with prostate cancer

![](https://peterattiamd.com/wp-content/uploads/2024/07/f1-tedschaeffer3.png)

**Figure 1. Incidence of prostate cancer in the TRAVERSE trial**. Image credit: [*NEJM* 2023](https://www.nejm.org/doi/suppl/10.1056/NEJMoa2215025/suppl_file/nejmoa2215025_research-summary.pdf)

**What this study tells us about prostate cancer risk is reassuring in many ways**

- 1 – Men with low PSAs have a low risk of being diagnosed with prostate cancer
- 2 – You can use PSA in generally similar fashions when you’re supplementing a man on exogenous testosterone
  - That is, you can look at changes in the PSA
  - For most men in TRAVERSE, their PSA did not change
    - It changed less than half a point over the course of the trial
    - And for those individuals whose PSA did go up, those were the men that were at risk for or were subsequently at higher risk for being identified as having or harboring a prostate cancer

**There was a figure in the paper that showed the non-statistical significance in the difference between the incidence of prostate cancer in the groups**.

- Even though it never comes close to reaching statistical significance (because in large part the sample size is so low), and even if there was a difference, it would be very hard to see
  - The incidence curves do diverge a little bit

![](https://peterattiamd.com/wp-content/uploads/2024/07/f2-tedschaeffer3-1024x372.png)

**Figure 2. Estimated cumulative indices of prostate cancer in the TRAVERSE trial**. Image credit: [*JAMA* 2023](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2813293)

- The study wasn’t long enough or wasn’t large enough to see if this was increasing the incidence or recognition of prostate cancer [the mean duration of follow-up was 33 months]

*What are your thoughts on that line of inquiry?*

- This is a large cohort [5246 men]
- Ted felt like there is pretty limited data to suggest that levels of testosterone or supplementation of testosterone really are strong and correlated with the induction of or the precipitation of a preexisting prostate cancer
- He personally felt that supplementation of individuals in a hypogonadal state to a eugonadal state is not going to increase their risk for the induction of or the propagation of a pre-existing prostate cancer

**In this study, you’re bringing somebody from a state where they have low T to a more eugonadal state, and there’s some interesting work that helps us understand what happens when a prostate grows**

- One of the main growth components for a prostate are androgens, either in the form of testosterone or [dihydrotestosterone](https://en.wikipedia.org/wiki/Dihydrotestosterone) (which has a much higher affinity for the [androgen receptor](https://en.wikipedia.org/wiki/Androgen_receptor))
- And this really does 2 things:
  - 1 – It causes growth and differentiation
  - 2 – The sensitivity of prostate cancer cells to these growth hormones (for them androgens or [DHT](https://en.wikipedia.org/wiki/Dihydrotestosterone)) is different between a cancerous and a non-cancerous cell
    - There’s actually much higher densities of androgen receptor within a benign prostatic cell, and therefore they’re much more sensitive to supplementation of testosterone

***With that in mind, most of the studies that have looked at supplementation of testosterone in eugonadal men have shown more often than not, that they actually have worsening of their BPH or urinary symptoms***

- And that’s thought to be due to the greater sensitivity of benign cells to exogenous T than actually the development or progression of a prostate cancer
- So that’s TRAVERSE plus a couple of other smaller but consistent studies that have been published over the last 2-3 decades within the urology space

## The androgen receptor saturation theory: how different organs respond to varying levels of testosterone [10:30]

- The [androgen receptor engages](https://en.wikipedia.org/wiki/Androgen_receptor) with testosterone, it engages with dihydrotestosterone; and when that engagement occurs, it moves from the cytoplasm to the nucleus and binds to androgen responsive elements, and you get production of androgen dependent genes and proteins down the road
- The idea behind the saturation theory is that once you reach a certain level of androgens within a particular end-organ (prostate muscle, CNS, hair follicle for example), once you reach a certain level, the receptor is fully saturated and anything above and beyond that level, you’re going to get limited “bang for your buck” in terms of the kind of output from the receptor engaging the DNA
  - i.e. at a certain level giving additional levels of testosterone or having additional levels of T or DHT within that organ are not going to result in any worse or augmented effects
  - We believe this is true
- There’s a series of studies that have suggested that the saturation theory and thresholds for saturation of the androgen receptor exist
- You can look at that within the prostate, and that those levels of saturation of the androgen receptor vary by the organ you’re evaluating
  - For example, it’s thought and it’s been modeled that the saturation of the androgen receptor levels of T that saturate AR within the prostate are probably around serum levels of 2 to 250 ng/mL (which is pretty low actually)
  - Whereas in muscle, levels probably have to be much higher to get the anabolic effects from a steroid in muscle to promote muscle growth and muscle mass
  - Hair follicles are probably more similar to prostate
    - Why? They have high densities of [5⍺-reductase](https://en.wikipedia.org/wiki/5%CE%B1-Reductase), and so they can convert T to DHT
  - There’s also an effect on the central nervous system and cognitive function, etc.
- So there’s variation in terms of the effect of T on a variety of end-organs, and that variation in the effect of T on these end-organs is probably related to this idea of the saturation theory that is not unique to the androgen receptor
  - It’s something that’s pretty common within a variety of different receptor super families, but certainly we think it exists within AR

***And this probably underscores the idea that supplementation of your serum testosterone levels to higher levels will have an end-organ effect that’s positive perhaps within muscle growth, but has pretty limited results in terms of its impact on the prostate growth and initiation and propagation of prostate cancers***

*Some of these examples and numbers are mind-boggling to Peter*

- Prostate tissue and hair follicles might reach saturation as low as 250 ng/dL of testosterone
  - This level is very low ‒ it’s probably at the 10th percentile of the population for men over 18
  - This suggests that 90% of men walking around even not taking testosterone replacement therapy are already at levels of saturation for hair follicles and for prostate
- Ted alluded to the fact that presumably for anabolic needs in the muscle, the saturation level would be much higher

*The way Ted thinks about it*

- In the prostate and in hair follicles, there’s [5⍺-reductase](https://en.wikipedia.org/wiki/5%CE%B1-Reductase)
- As soon as testosterone enters a prostate epithelial cell, it is immediately converted to DHT, which is about 10 times more potent than testosterone
- So if you really wanted to fiddle with the math, if you didn’t have DHT around, the saturation level that you would need for prostate maximal saturation, you could argue, would be 2,500 ng/L

***But the idea is that there’s amplification of the effect of T by converting to DHT by about maybe 10X***

Peter asks, “*Does that imply that on average, if a man is taking exogenous testosterone, let’s say he started out at 300 ng/dL (which truthfully would still be considered hypogonadal), and he gets replaced to 800 ng/dL, would you not expect him to experience a BPH trajectory growth or hair loss or any of the things that might be associated with the increase that he’s going to experience in both testosterone and DHT?*”

- Yeah, most of the data on T supplementation within the prostate, you’re going to see more of a precipitation of [BPH](https://en.wikipedia.org/wiki/Benign_prostatic_hyperplasia) symptoms
  - We talked about the differential, and so there may be a little bit of a bump in terms of lower urinary tract symptomatology, but it’s pretty subtle
- In fact, one of the biggest genes that is androgen responsive is [PSA](https://en.wikipedia.org/wiki/Prostate-specific_antigen)
  - For most people, when you augment their testosterone, that’s how they measured or estimated the saturation to be between 200-250 ng/dL
    - [Mo Khera](https://drmohitkhera.com/about/) did a nice [study](https://pubmed.ncbi.nlm.nih.gov/24011426/), he’s a former *Drive* guest [[episode #260](https://peterattiamd.com/mohitkhera/)]: they estimated to be around 250 ng/dL
  - In most people that you supplement from let’s say 3-800, you’re not going to see a big bump in their PSA, and so that would be the premise
  - Whereas if someone’s at 3, they may have pretty limited muscle mass, and yet you bump them to 800 and you see a real nice impact

## The relationship between testosterone levels and prostate cancer aggressiveness: how aggressive prostate tumors have lower androgen receptor activity and rely on different growth mechanisms [16:15]

- Ted and Peter discussed a [paper](https://pubmed.ncbi.nlm.nih.gov/12824459/) on his first appearance on *The Drive* [beginning at 1:53:15], published in the *NEJM* back when they were residents: *it suggested the lower a person’s testosterone, the greater the risk of high-grade prostate cancer*

**Bring us up to speed on the findings of that paper**

- The main driver that people have always focused on, the dependent fuel for prostate cancer has always been postulated to be testosterone
- In a normal prostate cell, we talk about these different thresholds
- Obviously, when the gland undergoes mutations and prostate cancers develop, some of the wiring is skewed and you can develop a cancer
- The [initial study](https://pubmed.ncbi.nlm.nih.gov/10687985/) basically showed a correlation between grade and aggressiveness of prostate cancer with testosterone and PSA values

***Showing a lower PSA was associated with a higher grade prostate tumor***

- That concept was something that always intrigued Ted
- And when they did their first [podcast in 2019](https://peterattiamd.com/tedschaeffer/), he had been studying that exact same concept: if a higher grade prostate cancer is a cancer that is less similar to a benign prosthetic gland, it’s more dissimilar, it’s more altered, what are the factors that are associated with causing it to grow and causing it to be aggressive?

**Ted did a very deep** [**study**](https://aacrjournals.org/clincancerres/article/25/22/6721/81917) **to try to characterize this based on a much more comprehensive assessment of the engagement of the androgen receptor with the ARE and the prostate cancer cell and the output of that engagement within a tumor**

- This study was not based on PSA values and grade
- And so he developed an androgen receptor activity [AR-A] signature that basically looked at the endpoint of androgen receptor activity within a prostate cancer
- He found similar observations and similar findings: ***the more aggressive a tumor was, the less it relied on output of a canonical*** [***AR***](https://en.wikipedia.org/wiki/Androgen_receptor) ***engagement with its traditional receptors existed***
- And so that again underscores the observation that paper we talked about back in their first podcast: ***cancers that are more aggressive are probably less reliant on the traditional growth and differentiation factors that a prostate epithelial cell has in its normal microenvironment***
  - And these tumors are much more aggressive than AR-high tumors
  - These tumors rely on different growth mechanisms to be aggressive, and they have different vulnerabilities in terms of sensitivity to agents that we may use when they present at later stages
- The initial observation was something that was always at front of Ted’s mind, and he’s done a lot of work in the lab to try to understand why those higher grade tumors are often found with lower PSA values and what the reasoning is
  - And then what makes them look the way they are and act the way they do

**The 9 canonical genes that make up the AR-A [androgen receptor activity] score**

- There are hundreds of genes that have canonical androgen responsive elements within them
- Ted did basically a rank ordering and identified the top 10, and for reasons that are a little subtle, he kicked 1 of them out
  - [The [9 genes](https://pubmed.ncbi.nlm.nih.gov/31515456/) are *KLK3, KLK2, FKBP5, STEAP1, STEAP2, PPAP2A, RAB3B, ACSL3, NKX3-1*]
- But there are many actually different androgen responsive signatures
  - You can look at ones from benign cells, you can look at ones from early cancers, and you can look at ones from advanced cancers
- The fundamental principle is that there’s this cohort of androgen responsive genes (it’s pretty consistent), and if you look at them in any of these different stages in the benign cell signature, a localized prostate cancer signature, androgen responsive, or even in advanced disease, the same theme is true

***That is the tumors that rely and have a signature that is less AR high-like, they are more aggressive***

Peter asks, “*Is this something that you’re doing post-biopsy and/or post-prostatectomy where you’re looking at the actual patient’s genes and presumably you are finding mutated genes or you’re finding SNPs that are known to be higher risk of a given set of genes?*”

- Yes
- The analysis is based off of an [Affy 1.0 ST chip](https://www.thermofisher.com/order/catalog/product/901086) that basically looks at gene products, presumably after the engagement of the antigen receptor
  - You’re doing an assay on the tissue biopsy to look at mRNA
- You can actually characterize tumors upfront from a biopsy or you can characterize tumors that have already been resected with surgery
  - Or frankly, you could characterize a tumor from a metastatic location if you really wanted to
- It’s an mRNA-based assay looking at gene expression, and the presumption is you could actually just look at antigen receptor gene expression within the tumors
  - They did, and you see a similar story
- But as you know, when you just say, “*We’re going to take the nuclear hormone receptor and look at its 10 targets,*” you’re going to get an amplification of that particular signal
- So they thought they would have a broader array of expression to look at if we developed a model that wasn’t just a single gene (in their case it was 9 genes)
  - Others have built ones that are 250 genes, 600 genes
- They’ve tested them, they all show the same and tell us the same story
  - They tell us that within a prostate cancer, agnostic of grade, agnostic of stage, there are tumors that have signatures that are consistent with high antigen receptor output

**The way Ted explains tumors with high androgen receptor output to patients**

- Those are weeds in your garden
  - They’re really large above the surface, but have very thin tiny roots
  - They’re big and they’re well differentiated, but they’re **not aggressive**

**Then there are tumors that don’t look like a normal prostate gland at all, and they have signatures that reflect very low antigen receptor signaling**

- They have amplification of other signaling pathways ([*PTEN*](https://en.wikipedia.org/wiki/PTEN_(gene)), [Myc](https://en.wikipedia.org/wiki/Myc), etc.), and those are associated with a **much more aggressive phenotype** in terms of metastasis, in terms of progression, in terms of resistance to traditional therapies that we use for individuals who have prostate cancer

## Using the Decipher score to assess prostate cancer aggressiveness and guide personalized treatment strategies [23:45]

**Are these CLIA-based approved studies?**

Peter asks, “*If a patient is seeing a doctor who’s not you or not one of the doctors that has one of these AR-A assays and they undergo a biopsy, is it a given that they can get this type of analysis done?*”

- Yeah, they can
- This is a [CLIA](https://en.wikipedia.org/wiki/Clinical_Laboratory_Improvement_Amendments)-approved assay
- It is the collaboration that Ted undertook over 10 years ago with this company called Decipher, and they are now owned by [VeraCyte](https://www.veracyte.com/)
- You can do a [Decipher assay](https://www.veracyte.com/decipher-prostate/): this is a mRNA-based assay that gives you a single assessment of how aggressive your prostate cancer is (it’s called the **Decipher score**)
  - That looks at 20 or 22 genes that are associated with aggressiveness in prostate cancer
  - In addition, they keep the data from the other 40,000 different spots on the Affy array
  - That’s how they build this AR-A signature
- Through your physician, you can get access to what we call the **grid signature**, and within the grid you can actually look at the AR activity of your individual tumor
  - You can model whether or not the tumor is a more **basal-like** or a more **luminal-like** tumor

***These features are important within localized prostate cancers, but more important are to understand some of the vulnerabilities of the tumors***

**A hypothetical patient**

- Let’s assume that a patient presents with either a high PSA or a significant enough change in PSA that it triggers an MRI
- And let’s say that that MRI shows a [RAD score](https://radiopaedia.org/articles/prostate-imaging-reporting-and-data-system-pi-rads-1?lang=us) that when combined with some other factor like the PSA or the PSA density, creates enough suspicion for a biopsy
  - [RAS score was discussed in [episode #273](https://peterattiamd.com/tedschaeffer2/) with Ted, refer to the section beginning at 2:13:15]
- You do the biopsy and let’s say that biopsy returns something that is a Gleason 3+3
  - We’ve talked in previous podcasts about what the Gleason score is [in [episode #273](https://peterattiamd.com/tedschaeffer2/) starting at 2:27:00]

Peter asks, “*So this is a watch and wait, correct?*”

- Yes

Peter asks, “*How does the finding of the AR-A impact your decision-making in the Gleason 3+3 patient? Is it something where it changes the frequency with which you want to do surveillance, or is there some other metric that changes in response to the genetic output or the transcription of those genes?*”

- For **lower grade prostate cancers**, ones that we would typically follow in surveillance, there are some outliers that are more aggressive in terms of their molecular features, but on average, those tumors are really benign-looking from a transcriptomic molecular profiling level

***Within the low grade tumors, you very rarely will see a tumor that is aggressive by the Decipher score; it’s about 7% of the time***

**It’s worth it to look if you really want to have a sense for: do you have an outlier tumor?**

- Now, can you identify the outliers with normal surveillance tactics that we’ve discussed on prior podcasts? Yes, you can
- Ted explains, “*For the lower grade tumors, understanding the molecular phenotypes for me personally is less important. But as the tumors become more aggressive, understanding the molecular characteristics that drive those tumors I think is very important*”

***We can’t precisely say now that if you have a low AR output tumor (a tumor that perhaps is not as dependent on androgens to grow), we can’t say at this point in time that that kind of tumor needs a more aggressive or different type of treatment than a high AR tumor as the tumors get more aggressive***

- But there are a couple of radiation-based trials that are using the Decipher score to molecularly profile the tumors, and then actually, again, begin to answer that question as to, if you are an AR-A low tumor and you have a high grade prostate cancer and you choose radiation, perhaps you shouldn’t just get standard androgen suppression along with your radiation, but perhaps you should intensify that with a more advanced, newer agent like [enzalutamide](https://en.wikipedia.org/wiki/Enzalutamide), [apalutamide](https://en.wikipedia.org/wiki/Apalutamide), or [darolutamide](https://en.wikipedia.org/wiki/Darolutamide)

**We have evidence from analyzing phase III trials that if you’re low AR-A, you have a much enhanced sensitivity to this dual doublet-based therapy**

- So one could surmise that if you’re somebody with a localized tumor that’s of higher grade and you’re going to have radiation, **you’d want to know your AR-A score**, for example, because that may inform whether or not you should intensify your ADT or just get standard ADT
  - Those studies are actually ongoing, and they’re fully accrued
  - The [NRG](https://www.nrgoncology.org/GU010) is a radiation-based trial group, and they’ve accrued individuals in these higher risk cohorts looking at their genomics and then basically stratifying them to different therapies
    - We’re going to know the results of those studies within the next 2 years, and they’ll be fascinating to understand

***This idea of the real precision medicine within prostate cancer is here, and how you deploy it and how you deploy it to enhance the outcomes for patients is actually we’re on the forefront of understanding that (lots to come)***

Peter asks, “*Is it an oversimplification to say that in a patient with a Gleason 3+4, this is a cancer that needs to come out, with a low AR-A score, is that a patient that should or should not be on androgen deprivation therapy? Is that a patient where you say, we are much better off doing a surgical resection here than we are opting for radiation and androgen deprivation therapy?*”

- Yeah, that’s exactly right
- Obviously radiation is biologically modifiable, surgery is extirpation, so you’re not going to really modify anything that you do with ADT and surgery

> “*If you can treat someone’s localized prostate cancer and save them the morbidity from systemic hormonal therapy, that’s a huge win for the patient. And so that’s exactly another way that you could use the AR-A score*”‒ Ted Schaeffer

- If this is a low AR-A tumor, let’s do surgery because we can treat them successfully with surgery and avoid any exposure to total androgen suppression, which you know is incredibly morbid for these individuals

**Does radiation ever alter this, Ted? In other words, is there any scenario by which radiation increases androgen sensitivity?**

- No, but **androgen deprivation increases radiation sensitivity**, so it’s used to augment the effect
  - Androgen suppression induces DNA damage, so you’re already making the cells vulnerable to further damage by reducing some baseline DNA damage upfront with androgen suppression

***After androgen deprivation, you hit them with radiation and the effect is synergistic***

## Considerations for testosterone replacement therapy: how Ted counsels patients, how TRT can be safely administered in patients with low-grade prostate cancer, and more [31:15]

- We’ve just gone down the rabbit hole pretty deep on the molecular nature of prostate cancers and particularly the prostate cancers that are most lethal
- Now let’s talk about a patient who wants to receive testosterone
  - They present in a hypogonadal state, are symptomatic, and by all measures should benefit from TRT

**What are the things that give you pause in that patient’s clinical picture, either PSA level, family history, prostate size, presence of BPH, anything?**

*How would you counsel that patient specifically around the risk of cancer? And are there any scenarios where in a cancer-free patient you would advise against TRT?*

- Ted can’t think of any scenarios where he really advises against TRT for somebody who is symptomatic
- There’s so many other potential negative outcomes for a patient who has low T besides the possible development or detection of a prostate cancer

*Benefits of TRT*

- If you’re hypogonadal, Ted wants to maintain your cardiovascular health, he wants to maintain your bone health, your muscle mass, your cognitive function
  - He wants to make you eugonadal

> “*For an individual who has prostate cancer, who has low T, it really comes down to how aggressive is their prostate cancer in terms of what I would advise them*.”‒ Ted Schaeffer

- So for somebody who has low-grade prostate cancer who’s in surveillance, Ted wants to maintain them in a eugonadal state
  - Ted’s doing surveillance to optimize their total health
  - So if they’re on T replacement and they get diagnosed with prostate cancer (low-grade), he’ll maintain them on T replacement

> “*Ted, that’s a remarkable statement… it really flies in the face of what most doctors would believe*.”‒ Peter Attia

**Peter’s takeaway**: You’re basically saying, if I’ve got a guy who’s on TRT and his testosterone is humming along at 800 mg/dL and he’s been on exogenous T for a couple of years, but in the course of something, whether it be a rising PSA, he gets a workup, he finds his way into my office, we ultimately do a biopsy after an MRI and find that he’s got a Gleason 3+3… you’re saying you’re not going to tell that guy he has to stop his testosterone

- Yeah, Ted explains, “*There’s no evidence that says exogenous T replacement causes acceleration or propagation of someone’s prostate cancer*”
- 30% of the population has a T that’s 800 or higher depending on their age
  - So it’s within the normal distribution
- Would Ted encourage someone to be higher than that? No
- If that’s where they’ve titrated their dose to relieve their symptoms and so forth, Ted is comfortable having the discussion with the patient to explain how to monitor and follow their prostate cancer
- There’s plenty of people out there that he monitors and follows their prostate cancers that have normally produced T’s that are over 800
  - In his mind, it’s no different than anybody else who’s within that normal distribution
  - Ted adds, “*It is a radical thing. If you just think about it, it’s actually not that radical really at all.*”

**Peter summarizes**: if you have two people sitting in front of you, one of whom is supplementing to a level of 800, the other one is naturally at 800 and they show up with the same Gleason 3+3 cancer, you’re going to monitor both of them. You wouldn’t say to the guy who’s on TRT, “*I have to take your prostate out as a result of this or make you stop the T*.”

**In a normal prostate, testosterone is a differentiation factor**

- Testosterone will differentiate a prosthetic cell towards a fully functional, benign epithelial cell
- Conceptually, at the very beginning, high T is probably associated with a more well differentiated tumor
  - Not 100% of the time
  - But that’s what it’s doing biologically within the prostate gland, it’s differentiating these cells
- Of course cancer is maybe a little bite more genomically unstable than a benign cell

**Conversely, if you have a tumor that is in a low T environment, they’re less dependent on androgens to grow**

- i.e., the original publications we talked about in [*NEJM*](https://www.nejm.org/doi/full/10.1056/NEJMoa030660) way back or other anecdotal series, the tumors that develop in a low T environment
- They often use other growth pathways to be aggressive, and actually Ted thinks they’re more worrisome because you don’t exactly know how you’re going to attack it or treat it if it actually progresses

**Hypothetical patients: two guys come in with low-grade prostate cancer, one with a T of 600 and one you’re supplementing his T to 600**

- Ted recommends you follow both carefully and in the same way

**How do you handle a tumor that requires treatment?**

- A Gleason 7, 4+3=7 or 4+4=8 (more serious stuff)
- That’s where you really come into differences

***If someone is leaning towards radiation, that’s where those individuals go on aggressive androgen suppression (and they need to)***

*Let’s just say you’re supplementing to 600 or 800, and now you’re taking them and you’re making them zero again*

“*Most men become incredibly symptomatic when you take their T to zero*”‒ Ted Schaeffer

- That’s part of the **radiation sensitization** that you need to do to treat a higher grade prostate cancer with radiation
- For those individual men, Ted will talk to them and **recommend surgery**
  - Why? We can maintain your testosterone
  - We may not run you at 800; we may bump you down to let’s say 400 (that’s just Ted being comfortable)
    - As we talked about with the **saturation theory**, we’re probably fully saturated at any of those levels
  - We can treat him with surgery, and as long as his pathology is favorable after surgery, he can continue with testosterone supplementation so that he can maintain his full body health
- Ted thinks more radiation oncologists are hesitant to restart exogenous T in somebody after 6 months or 2 years of [ADT](https://en.wikipedia.org/wiki/Androgen_deprivation_therapy) with their radiation, because when you do radiation, you’re not removing all the prostate tissue
  - So if you have any **residual benign tissue** in your prostate after radiation (which you’re going to have), and you give back T, you may cause a false positive in terms of a recurrence for that particular patient’s tumor

***For those individuals, radiation can actually be more harmful because you’re not able to supplement back up someone’s low T to their normal range afterward***

- Which of course not only happens in the man who we talked about who was hypogonadal before their diagnosis or before their treatment, but frankly, only 50-60% of men will actually recover normal levels of T after 2 years of hormonal suppression anyway
- So you’re really talking about inducing more **hypogonadism** in those men than you would’ve even before

## Advancements in prostate cancer therapies and PSA as a biomarker for precise treatment decisions minimizing the need for broad androgen deprivation therapy [38:30]

- Given how much better radiation therapy is today than 20 years ago
- In many ways, radiation therapy and surgical therapy have improved in parallel fashions over 20 to 30 years
  - The morbidity of both of them has gone down so much
  - The efficacy of both have gone up so much

**Is the bigger issue for you in helping a patient whose cancer is really amenable to either treatment, is your primary point of differentiation more around the androgen deprivation therapy than it is the morbidity differences between surgery and radiation?**

*In other words, do you feel that those cancel each other out now given that both have come such a long way?*

- Peter clarifies: we’re not talking about patients that present with [metastatic disease](https://en.wikipedia.org/wiki/Metastasis) where there’s a very clear direction they need to go in
  - And we’re not talking about patients who are in a surveillance pattern
  - We’re talking about that 3+4, who could go either way or sometimes the 4+4
- Ted agrees that they’ve definitely improved substantially
- He thinks Peter put the whole picture together
- For sure it’s at the top of the list in terms of the discussion as can we save this individual from systemic suppression of their testosterone levels, which have profound impacts on how they feel
  - That’s a critical component of the discussion
- There’s other subtle things about urinary function, sexual function, life expectancy and so forth that we put into the equation, but it’s definitely at the forefront of our mind
- That’s why there’s 3 ongoing NRG trials [[NRG-GU009](https://www.nrgoncology.org/Clinical-Trials/Protocol/nrg-gu009-1?filter=nrg-gu009-1), [NRG-GU010](https://www.nrgoncology.org/GU010), & [NRG GU-011](https://www.nrgoncology.org/Clinical-Trials/Protocol/nrg-gu011?filter=nrg-gu011)] that really are looking at intensification and de-intensification of androgen suppression in these higher grade prostate cases that are treated with radiation in a way to expose fewer men potentially to androgen suppression

***Because we may find that there are tumors that look like an 8, but are actually on the inside, not so aggressive, and they don’t need androgen suppression for as long or as aggressively as we previously thought***

**Was there ever an adjuvant study that was done?**

- Peter asks, because the experience for breast cancer is completely different
  - In breast cancer, when a woman has an [ER-positive breast cancer](https://en.wikipedia.org/wiki/Hormone_receptor_positive_breast_tumor), even if it is completely amenable to surgical resection and it is removed, and there is no evidence that the cancer has spread, she is still going to be placed on an adjuvant regimen of **anti-estrogen therapy**
- And just as the man who is placed on anti-androgen therapy is going to experience pretty bad side effects, so too do the women who are placed on anti-estrogen therapy
  - They are at a dramatic increase for osteoporosis, they go through basically menopause
  - And for many of these women, they’re quite young, and this can be quite morbid
- Now, the data suggests that that therapy does reduce the incidence of a recurrence, though it’s not clear that it translates to a survival benefit
  - So there’s a little bit of controversy there
  - Although within that community, it doesn’t seem very controversial
    - Most oncologists Peter speaks with are pretty adamant that that therapy be used, and again, they can point to the clinical trials that demonstrate a reduction in recurrence of cancer

Peter asks, “*Are there such trials that have been done in prostate cancer? Was there a day when status post-radical prostatectomy men were still put on androgen deprivation therapy as an adjuvant, to basically see if that prevented recurrence?*”

- One of the big benefits that we have in the prostate cancer space is we have this exquisitely sensitive biomarker, the [PSA](https://en.wikipedia.org/wiki/Prostate-specific_antigen)

***PSA was first described as a way to measure the efficacy of your treatment after you received it, and breast cancer does not have that biomarker (that’s the big difference)***

- That’s when people begin to try to compare as equals, as apples and apples outcomes with breast and prostate, that analogy falls far short because women with breast cancer are on suppression for 5 years, on average
- We don’t do that in prostate
- We can measure exquisitely if they have a recurrence

> “*We are much more conservative about adjuvant therapy because we have this incredibly sensitive biomarker [PSA] that detects whether or not there’s a recurrence of frankly, 100, 200 cells*.” ‒ Ted Schaeffer

- You’ll pick up something [PSA changes] at that low level, and so we have ways to more aggressively deploy early salvage therapies

Peter asks, “*So instead of just taking this bazooka approach, you can be a sniper?*”

- That’s right
- We had that luxury, and Ted thinks it’s one of the great benefits in the prostate cancer space.
- If you’re listening to this and you’re a woman contemplating, “*God, what if I develop estrogen-dependent breast cancer?*” the hope is that we see the acceleration of liquid biopsies that are going to be amenable to looking at cell-free DNA as a way to monitor for recurrence so that breast cancer can take a page out of the prostate cancer playbook and do more targeted therapy
  - And then basically, you would like to only have to give androgen deprivation to the women who need it, and not to probably the 90% of women who don’t
- Ted agrees, that’s where all those cell-free, DNA-based biomarker assays are really spectacular, and the newer ones really look impressive for almost all cancers
- But for prostate cancer, we just don’t need necessarily to “gild that lily” much more

§

## Selected Links / Related Material

**Previous episodes of** ***The Drive*** **with Ted Schaeffer**: [1:00]

- [#273 ‒ Prostate health: common problems, cancer prevention, screening, treatment, and more | Ted Schaeffer, M.D., Ph.D.](https://peterattiamd.com/tedschaeffer2/) (October 2, 2023)
- [#39 – Ted Schaeffer, M.D., Ph.D.: How to catch, treat, and survive prostate cancer](https://peterattiamd.com/tedschaeffer/) (February 4, 2019)

**TRAVERSE trial results**: [1:15, 3:00]

- [Cardiovascular Safety of Testosterone-Replacement Therapy](https://pubmed.ncbi.nlm.nih.gov/37326322/) | *NEJM* (M Lincoff et al 2023)
- [Prostate Safety Events During Testosterone Replacement Therapy in Men With Hypogonadism](https://pubmed.ncbi.nlm.nih.gov/38150256/) | *JAMA* (S Bhasin et al 2023)

**Peter’s newsletter on the TRAVERSE trial**: [Is testosterone replacement therapy both safe and effective in men with higher cardiovascular risk factors?](https://peterattiamd.com/traverse-trial-and-trt-in-men/) | PeterAttiaMD.com (S Lipman, K Birkenbach, P Attia 2023) | [1:45]

**Ted is co-author on a textbook on prostate cancer**: [*Dr. Patrick Walsh’s Guide to Surviving Prostate Cancer*](https://www.amazon.com/Patrick-Walshs-Surviving-Prostate-Cancer/dp/1538726866/ref=sr_1_4?crid=E70A0SEF22CV&keywords=Dr.+Patrick+Walsh%E2%80%99s+Guide+to+Surviving+Prostate+Cancer&qid=1695059493&sprefix=dr.+patrick+walsh+s+guide+to+surviving+prostate+cancer%2Caps%2C237&sr=8-4) by Patrick Walsh, Janet Worthington, and Edward Schaeffer (October 2023) | [2:45]

**Mohit Khera study on androgen receptor saturation**: [A new era of testosterone and prostate cancer: from physiology to clinical implications](https://pubmed.ncbi.nlm.nih.gov/24011426/) | *European Urology* (M Khera et al 2014) | [16:00]

**Episode of** ***The Drive*** **with Mohit Khera**: [#260 ‒ Men’s Sexual Health: why it matters, what can go wrong, and how to fix it | Mohit Khera, M.D., M.B.A., M.P.H.](https://peterattiamd.com/mohitkhera/) (June 26, 2023) | [16:00]

**Paper suggests low testosterone associated with risk of high-grade prostate cancer**: [16:30 35:45]

- [Is low serum free testosterone a marker for high grade prostate cancer?](https://pubmed.ncbi.nlm.nih.gov/10687985/) | *Journal of Urology* (M Hoffman, W DeWold, A Morgentaler 2000)
- [The influence of finasteride on the development of prostate cancer](https://pubmed.ncbi.nlm.nih.gov/12824459/) | *NEJM* (I Thompson et al. 2003)

**Ted’s study of androgen receptor engagement and prostate cancer**: [Transcriptomic Heterogeneity of Androgen Receptor Activity Defines a de novo low AR-Active Subclass in Treatment Naïve Primary Prostate Cancer](https://pubmed.ncbi.nlm.nih.gov/31515456/) | *Clinical Cancer Research* (D Spratt et al 2019) | [18:15]

**Test for Decipher score**: [Decipher Prostate Genomic Classified](https://www.veracyte.com/decipher-prostate/) | Veracyte (2024) | [24:15]

**NRG study of treatment for unfavorable intermediate risk prostate cancer**: [Can gene risk based on the Decipher risk score inform hormonal therapy treatment with radiation for unfavorable intermediate risk prostate cancer?](https://www.nrgoncology.org/GU010) | NRG Oncology (2024) | [28:45]

**NRG prostate cancer trials**: [40:00]

- [NRG-GU009](https://www.nrgoncology.org/Clinical-Trials/Protocol/nrg-gu009-1?filter=nrg-gu009-1)
- [NRG-GU010](https://www.nrgoncology.org/GU010)
- [NRG-GU011](https://www.nrgoncology.org/Clinical-Trials/Protocol/nrg-gu011?filter=nrg-gu011)

§

## People Mentioned

- [Mohit Khera](https://drmohitkhera.com/about/) (Urologist, Professor and Chair of Urology at Baylor College of Medicine, and expert in testosterone therapy)  [16:00]

§

![](https://peterattiamd.com/wp-content/uploads/2023/09/bio-image-tedschaeffer2.jpeg)

##### Ted Schaeffer, M.D., Ph.D.

Edward (Ted) Schaeffer earned his MD/PhD from the University of Chicago. He completed his internship in general surgery followed by a residency in urology at Johns Hopkins. He is a board certified urologist with an active practice specializing in prostate cancer.

Dr. Schaeffer is Chair of the Department of Urology at Feinberg School of Medicine and Program Director of the Genitourinary Oncology Program at the Robert H. Lurie Comprehensive Cancer Center of Northwestern University. His globally recognized prostate cancer [research](https://www.cancer.northwestern.edu/research/membership/profile.html?id=6cc14a9069084ee44bc0f6dec58fcc5c) focuses on at-risk populations, diagnosis, treatment outcomes, and the molecular biology of lethal prostate cancer. [[Northwestern Medicine](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=34261)]

Website: [TedSchaefferMD.com](https://tedschaeffermd.com/)

X: [@EdwardSchaeffer](https://twitter.com/EdwardSchaeffer)