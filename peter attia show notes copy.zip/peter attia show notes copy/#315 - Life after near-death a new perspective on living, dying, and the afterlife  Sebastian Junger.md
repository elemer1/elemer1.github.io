# #315 ‒ Life after near-death: a new perspective on living, dying, and the afterlife | Sebastian Junger

**Source:** [https://peterattiamd.com/sebastianjunger2/](https://peterattiamd.com/sebastianjunger2/)

---

Sebastian Junger is an award-winning journalist, bestselling author, and previous guest on The Drive. In this episode, Sebastian returns to discuss his latest book, [In My Time of Dying: How I Came Face to Face with the Idea of an Afterlife](https://www.amazon.com/My-Time-Dying-Came-Afterlife/dp/1668050838/ref=sr_1_1?crid=HFHN8EVWHUMY&dib=eyJ2IjoiMSJ9.BoTYIvwbTa2HEQjJOvD6339_ZkhPtYy1ue36N2POECrE1Wvr9QNQM5RGJQxPGtS1-vzIqtd2ubwYUIuG56-pBqkBiwGqChftA1ooxxTJsZTpVLtUcia2sE21NMUYLsktkivWK9x7C8CXhLOUEHwIRLq5gMJ8pJAlVPQA22NqlsMTRq4S9uismmJXw__Xuah368B8a0H8P554J55NZ7rqcHIkW7SZaLkl64MYT1WH6zA.eh5sTUy4sxUE0-87_OgRRhVFENlN5DepSWexpN8bHTs&dib_tag=se&keywords=sebastian+junger+in+my+time+of+dying&qid=1719585279&sprefix=sebastian+Junger+%2Caps%2C99&sr=8-1). This episode delves into Sebastian’s profound near-death experience and how it became the catalyst for his exploration of mortality, the afterlife, and the mysteries of the universe. They discuss the secular meaning of what it means to be sacred, the intersection of physics and philosophy, and how our beliefs shape our approach to life and death. He also shares how this experience has profoundly changed him, giving him a renewed perspective on life—one filled with awe, gratitude, deeper emotional awareness, and a more engaged approach to living.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/sebastianjunger2/the_Drive_public.png)

Play

#315 ‒ Life after near-death: a new perspective on living, dying, and the afterlife | Sebastian Junger

#315 ‒ Life after near-death: a new perspective on living, dying, and the afterlife | Sebastian Junger

1x15s30s

0:002:03:46

## We discuss:

- How Sebastian’s near-death experience shaped his thinking about mortality and gave him a reverence for life [3:00];
- The aneurysm that led to Sebastian’s near-death experience [6:30];
- Emergency room response, his subsequent reflections on the event, and the critical decisions made by the medical team [16:30];
- Sebastian’s reaction to first learning he nearly died, and the extraordinary skill of the medical team that save his life [26:00];
- Sebastian’s near-death experience [37:00];
- The psychological impact of surviving against overwhelming odds [48:00];
- Ignored warning signs: abdominal pain and a foreshadowing dream before the aneurysm rupture [54:30];
- Sebastian’s recovery, his exploration of near-death experiences, and the psychological turmoil he faced as he questioned the reality of his survival [58:15];
- A transformative encounter with a nurse who encouraged Sebastian to view his near-death experience as sacred [1:03:30];
- How Sebastian has changed: a journey toward emotional awareness and fully engaging with life [1:08:45];
- The possibility of an afterlife, and how quantum mechanics challenges our understanding of existence [1:15:15];
- Quantum paradoxes leading to philosophical questions about the nature of reality, existence after death, and whether complete knowledge could be destructive [1:26:00];
- The sweet spot of uncertainty: exploring belief in God, post-death existence, and meaning in life [1:37:00];
- The transformative power of experiencing life with awe and gratitude [1:53:00]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Sebastian Junger is a previous podcast guest ([February 2022](https://peterattiamd.com/sebastianjunger/))
- Peter wanted to have him back on to discuss his recently published book, [*In My Time of Dying: How I Came Face to Face with the Idea of an Afterlife*](https://www.amazon.com/My-Time-Dying-Came-Afterlife/dp/1668050838/ref=sr_1_1?crid=HFHN8EVWHUMY&dib=eyJ2IjoiMSJ9.BoTYIvwbTa2HEQjJOvD6339_ZkhPtYy1ue36N2POECrE1Wvr9QNQM5RGJQxPGtS1-vzIqtd2ubwYUIuG56-pBqkBiwGqChftA1ooxxTJsZTpVLtUcia2sE21NMUYLsktkivWK9x7C8CXhLOUEHwIRLq5gMJ8pJAlVPQA22NqlsMTRq4S9uismmJXw__Xuah368B8a0H8P554J55NZ7rqcHIkW7SZaLkl64MYT1WH6zA.eh5sTUy4sxUE0-87_OgRRhVFENlN5DepSWexpN8bHTs&dib_tag=se&keywords=sebastian+junger+in+my+time+of+dying&qid=1719585279&sprefix=sebastian+Junger+%2Caps%2C99&sr=8-1)
- Sebastian is an award-winning journalist, documentary filmmaker, and New York Times bestselling-author
- Some of his previous works include:
  - [*The Perfect Storm*](https://www.amazon.com/Perfect-Storm-True-Story-Against/dp/039304016X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9._rJvN4QGhryqwvkXKWr-Dn0kwr8RL0cvXiDM970qRzTqxMerJDTkkXYVhnKNFbnJYv5owWC9je3aV4C0YM3fCLJHt88Kb5VGlwkvfdZSkOLZ8UhKMRLunCGkir-sgp4ZbO8jx9cgIbTf3wSGyi9DjOzC7tuMFWAmEW9SeQI7HeNxLYme2QovVlPrRmWPuzq7_xl7wX4m7h2ISjRGng1YBsX9-yHH3TWH_Ypukhie1qg.GjoTz7itAsCMv3wf0_GFRQAc7DNqC9ySLbCUGSWiyAU&qid=1720440203&sr=8-4)
  - [*Tribe*](https://www.amazon.com/Tribe-Homecoming-Belonging-Sebastian-Junger/dp/1455566381/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9._rJvN4QGhryqwvkXKWr-Dn0kwr8RL0cvXiDM970qRzTqxMerJDTkkXYVhnKNFbnJYv5owWC9je3aV4C0YM3fCLJHt88Kb5VGlwkvfdZSkOLZ8UhKMRLunCGkir-sgp4ZbO8jx9cgIbTf3wSGyi9DjOzC7tuMFWAmEW9SeQI7HeNxLYme2QovVlPrRmWPuzq7_xl7wX4m7h2ISjRGng1YBsX9-yHH3TWH_Ypukhie1qg.GjoTz7itAsCMv3wf0_GFRQAc7DNqC9ySLbCUGSWiyAU&qid=1720440285&sr=8-2)
  - [*Freedom*](https://www.amazon.com/Freedom-Sebastian-Junger/dp/1982153415/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9._rJvN4QGhryqwvkXKWr-Dn0kwr8RL0cvXiDM970qRzTqxMerJDTkkXYVhnKNFbnJYv5owWC9je3aV4C0YM3fCLJHt88Kb5VGlwkvfdZSkOLZ8UhKMRLunCGkir-sgp4ZbO8jx9cgIbTf3wSGyi9DjOzC7tuMFWAmEW9SeQI7HeNxLYme2QovVlPrRmWPuzq7_xl7wX4m7h2ISjRGng1YBsX9-yHH3TWH_Ypukhie1qg.GjoTz7itAsCMv3wf0_GFRQAc7DNqC9ySLbCUGSWiyAU&qid=1720440285&sr=8-5)
- Peter was compelled to have this conversation with Sebastian after devouring his book
- It really is a special book, and it’s not just because of the nature of what Peter focuses on professionally
  - It really is the type of book that anybody would read and be moved by because at the end of the day, we all are a little bit afraid of our mortality and curious about what it implies
- In this conversation, Sebastian shares his story of his near-death experience
- And how that’s the substrate and launching pad towards the investigation that leads toward this book
- We talk about how the universe works, what we understand about physics
- What does it mean to be sacred (secular meaning)
- And discuss whether or not there may be an afterlife
  - Absent any sort of religious overtone ‒ these two can be quite uncoupled
- We discuss how our beliefs might impact how we live our lives and what shapes our value in our own experience
- Peter found this to be a very intriguing conversation, and one that is a bit more philosophical than our usual discussions on *The Drive*
  - It offers a chance to reflect on the themes related to how we think about death, our spiritual beliefs, and this idea of an afterlife

## How Sebastian’s near-death experience shaped his thinking about mortality and gave him a reverence for life [3:00]

**Peter found Sebastian’s latest** [**book**](https://www.amazon.com/My-Time-Dying-Came-Afterlife/dp/1668050838/ref=sr_1_1?crid=HFHN8EVWHUMY&dib=eyJ2IjoiMSJ9.BoTYIvwbTa2HEQjJOvD6339_ZkhPtYy1ue36N2POECrE1Wvr9QNQM5RGJQxPGtS1-vzIqtd2ubwYUIuG56-pBqkBiwGqChftA1ooxxTJsZTpVLtUcia2sE21NMUYLsktkivWK9x7C8CXhLOUEHwIRLq5gMJ8pJAlVPQA22NqlsMTRq4S9uismmJXw__Xuah368B8a0H8P554J55NZ7rqcHIkW7SZaLkl64MYT1WH6zA.eh5sTUy4sxUE0-87_OgRRhVFENlN5DepSWexpN8bHTs&dib_tag=se&keywords=sebastian+junger+in+my+time+of+dying&qid=1719585279&sprefix=sebastian+Junger+%2Caps%2C99&sr=8-1) **to be really a fantastic book**

- It’s hard to describe the experience of reading it
  - It’s so beautiful it can almost bring you to tears in certain sections because there are the stories within it that sort of tell us about our mortality
- Peter is curious if others have explained their reaction to Sebastian
  - Which is you can feel so incredibly insignificant reading this, which is actually a nice thing
  - It makes this whole thing (death) seem a little less scary
- Our insignificance in the cosmos does take the pressure off
  - We don’t mean anything and that’s both terrifying and liberating
- One of the things Sebastian talks about in the book is a kind of reverence for life
- It’s quite hard to find one’s way to that reverence in the busyness of daily life in our modern society without having been terrified

**After effects of Sebastian’s near-death experience**

- Once Sebastian was terrified by almost dying, the flip side of that terror was **reverence**
  - And he has found it quite easily after that
- At one point after his near death experience, he had a lot of **psychological struggles**, and his wife asked, “*Sebastian, do you feel lucky or unlucky that you almost died? I mean, not that you survived (of course you’re lucky), but that it happened at all. If you could go back and push a button, have it not happen, would you push that button?*”
  - He honestly didn’t know how to answer
- The psychological consequences of almost dying and what he saw (remembered) on the threshold was so devastating that he absolutely felt cursed
- In struggling to answer, he tracked down the origin of the word blessing

***Sebastian is an atheist, but he feels that there are secular meanings to beautiful words like blessing or sacred***

**The origin of the word blessing comes from the Anglo-Saxon word meaning blood**

- The idea being that there is no blessing without a wounding, without a sacrifice
  - And maybe there’s no wounding without a blessing
- And that battlefields are sacred because blood has been shed
- Childbirth is sacred because blood has been shed
- In pre-Christian Europe, often animals were sacrificed on holy days to bless fields, to bless buildings, to bless people

***The twinning of blessing and wounding, they’re aspects of the same thing***

- “When I realized that, it allowed me to make an important psychological step where I stopped feeling cursed by too much knowledge”
  - That I’d somehow gotten too much knowledge on the threshold of death and couldn’t continue daily life with that knowledge
  - It was too burdensome, it was too scary, it was too true
  - And once I read the origin of the word blessing, I was like, “*Oh, I’m free.*”
    - It’s both; how wonderful

## The aneurysm that led to Sebastian’s near-death experience [6:30]

**Recount the story of what happened in June of 2020 and how much luck played a role in Sebastian sitting here today**

- He discussed it a little bit on their last podcast [[episode #195](https://peterattiamd.com/sebastianjunger/)]
- Last night (June 16) at his book reading at *BookPeople* in Austin, because of the time difference with the east coast, he was able to say, “*This moment exactly four years ago, I started dying*.”
  - It was during COVID
  - He was living with his family at the time: his daughters (a 3-year-old girl and a 6-month-old girl) and his wife (Barbara)
  - They were living in an old house in a remote part of Massachusetts at the end of a dead end dirt road, deep in the woods, no cell phone service, landlines that would short out when it rained and often didn’t work (in other words, paradise)
- He was in his 50s, a lifelong athlete, in extremely good health, strong, never thought twice about emergency transport to a hospital
  - Why would he?
    - He’s not a walking heart attack
    - He doesn’t have high cholesterol, etc.
    - He didn’t think he had anything that would drop a middle-aged man in his tracks
- One afternoon, some neighbors down the road called, and the teenage girls offered to come over and babysit, and that was a rare opportunity
- He and his wife went off to a cabin that’s even deeper in the woods, an even more beautiful spot, and completely cut off from everything
  - They were able to spend a couple of hours there, and thank God they did and he didn’t go running or something that would’ve put him even more off the grid (because he would’ve died had that happened)
- They were in this cabin and in mid-sentence he felt this stab of pain in his abdomen
  - It wasn’t unbearable, but it really got his attention
  - And it wouldn’t go away; unlike certain digestive pain, nothing would ease it
- He finally stood up to walk it out and the floor went reeling away from him and he almost fell over
- He sat back down and said words he never thought he’d have to say, “*Honey, I think I’m going to need help. I’ve never felt anything like this.*”
- She half dragged him out of the cabin and down the trail and they made it to the dirt driveway and she put him in the passenger seat of the car and ran in to tell the babysitters, “*Try to call the ambulance. Something’s wrong with Sebastian.*”
- As he’s sitting in the car, he starts going blind
  - The sky turns electric white
  - The electric white takes over the trees and the house and everything around me
  - He didn’t know it, but he was in and out of consciousness
  - ***These were all the symptoms of catastrophic blood loss***
- What had happened was he’d had an aneurysm, an unnatural ballooning at one spot in his pancreatic artery (which is really quite rare)
  - It was the result of having a ligament in the wrong place in his abdomen that occluded his [celiac artery](https://en.wikipedia.org/wiki/Celiac_artery)
  - It’s all rather complicated, but basically the celiac is this garden hose and when you’ve cut it off with this ligament in the wrong place, the blood has to flow somewhere else and it flows through these smaller arteries
  - And if one of them has a weak spot or a vulnerability, that weak spot will balloon
    - The bubble will get bigger and bigger and the arterial wall will get thinner and thinner and it can rupture
  - And if it ruptures, you’re now bleeding out into your own body, into your own abdomen
- If someone just had done you the favor of stabbing you in the stomach when they got you to the hospital, the doctors would know where to put their finger to stop the bleed
  - In some ways, it’s an easier proposition
- But with internal hemorrhage, it can be quite hard to find the location
  - To the layman, your abdomen is just a big bowl of spaghetti
- He didn’t know that he had an undiagnosed aneurysm that had been growing (probably for decades) and it had finally ruptured in that moment
- He was losing a pint of blood every 10 or 15 minutes into his abdomen
  - There’s 10 units of blood in the human body, thereabouts, and you can lose maybe two-thirds of it before you cross over to territory where it’s really hard to come back from, even if you’re transfused
- They lived a 1-hour drive from the nearest hospital
  - He was literally a human hourglass
- The ambulance finally came, he had rebooted a bit
  - He went into compensatory shock, which makes you feel a little bit better for a little while.
- An hour later, they pulled into the hospital and he went out of compensatory shock right then into end stage [hemorrhagic shock](https://en.wikipedia.org/wiki/Hypovolemic_shock), deeply hypothermic, not of right minds and actively dying and would probably have been dead in the next 10 or 15 minutes had he not been in an ER at that moment
- They rushed him into the trauma bay and started trying to save his life

**An anecdote from Peter’s days in the trauma center at Johns Hopkins**

- Time to either surgery or IR (interventional radiology) is the single most important metric
  - Which is where you life is saved
- There’s an amazing guy named [Eddie Cornwall](https://www.encyclopedia.com/education/news-wires-white-papers-and-books/cornwell-edward-e-iii) who was at the time the chief of trauma surgery at Hopkins who wanted to test this because of an interesting observation he had made
- When he was a trauma surgeon in Los Angeles, he noticed that the gang bangers who were brought in by their buddies were surviving at a slightly higher rate than those that were brought in by ambulance with IV fluid
  - This is very counterintuitive
  - This is all penetrating trauma ‒ it’s what we call the knife and gun club
- What Eddie and his colleagues postulated was what could possibly be better about being thrown in the back of a truck than being in the ambulance?
- He realized, technically those guys are getting to them sooner because no one’s putting an IV in them, no one’s checking their vital signs, no one’s doing anything else
- They did a **crazy experiment**, where depending on the day of the week, all ambulances were going to basically randomize the trauma victims to either
  - 1 – Business as usual
    - Which means when a penetrating trauma victim is found, you do everything that you would normally do
    - You put the IVs in them, you stabilize them, you start running IV fluids and you go
  - 2 – What they called scoop and run
    - Which is the ambulance would get there and wouldn’t do a thing, would literally pick them up, throw them in the ambulance and get them into the hospital

***A randomized experiment can infer causality; when you randomized to scoop and run, you did bette***r

- When Peter had read this, his thought was, “*Barbara, just take him right to the hospital now, don’t do anything (don’t call an ambulance)*

**The bottom line is Sebastian’s life could only be saved in an operating room or in an IR suite**

- He needed a blood transfusion as he was rolling into those places
- In an ambulance, you get IV fluid, but you don’t get blood
- When the ambulance showed up, they were at his place for probably 15-20 minutes

**Back to what happened to Sebastian**

- When the ambulance arrived, Sebastian thought he was fine and probably didn’t need to go in
  - He almost talked the ambulance into leaving
- His wife insisted that he go to the hospital, explaining, “*10 minutes ago, he was passing out and going blind and I don’t care if he seems a little better right now, he’s going downtown. You’re taking him right now.*”
- At the time, a famous statistic flashed through his mind, “*Married men live longer*.”
- They took his blood pressure, and because he had gone into compensatory shock, his blood pressure was okay
  - 80/50 would have been compensated enough for him to not pass out, but that’s not a normal blood pressure
- They suggested that he stay and drink some water and rehydrate in the shade, which would’ve killed him

## Emergency room response, his subsequent reflections on the event, and the critical decisions made by the medical team [16:30]

- But they got to the ER and rushed him into the trauma bay
- The doctors knew immediately what was going on
- He was pale as a sheet and had blood loss, internal hemorrhage written all over him.

**The** [**book**](https://www.amazon.com/My-Time-Dying-Came-Afterlife/dp/1668050838/ref=sr_1_1?crid=HFHN8EVWHUMY&dib=eyJ2IjoiMSJ9.BoTYIvwbTa2HEQjJOvD6339_ZkhPtYy1ue36N2POECrE1Wvr9QNQM5RGJQxPGtS1-vzIqtd2ubwYUIuG56-pBqkBiwGqChftA1ooxxTJsZTpVLtUcia2sE21NMUYLsktkivWK9x7C8CXhLOUEHwIRLq5gMJ8pJAlVPQA22NqlsMTRq4S9uismmJXw__Xuah368B8a0H8P554J55NZ7rqcHIkW7SZaLkl64MYT1WH6zA.eh5sTUy4sxUE0-87_OgRRhVFENlN5DepSWexpN8bHTs&dib_tag=se&keywords=sebastian+junger+in+my+time+of+dying&qid=1719585279&sprefix=sebastian+Junger+%2Caps%2C99&sr=8-1) **is a semi-memoir: it’s about his own experience**

- As a journalist, he hasn’t done much of that
- In fact, he’s been averse to making himself the topic his entire life
- But because he’s also a journalist, he wrote a first person account of something very intense and profound
  - He also interviewed everyone he could to confirm to himself that his memories are roughly correct and to just do some reporting
  - He interviewed all the doctors who would talk to him
  - He even interviewed his wife
  - He interviewed the guy who was in the back of the ambulance
- He was able to read all of the medical records and timestamp the moment you arrived in the ER, how many units of fluid, how many units of blood, all that stuff
- As a writer, the language in these specialty fields is so fascinating, even if you don’t quite understand what’s a French Omni Flush, whatever
  - The language is cool, and sometimes he put the language in there just because it gives you the feeling of, wow, we’re in this world
- A couple of the doctors didn’t want to talk to him, maybe they’re skittish for legal reasons (even though the outcome was amazing)
- They rushed him into the trauma bay
- His memories were semi-confirmed by people who were there
- Sebastian had no idea he was dying

**What did you think was happening at that moment when you were sitting in the trauma bay?**

- He knew it was not a heart attack
  - He didn’t have pain on his left side
  - He has a healthy heart
- Maybe it was a stroke
  - Is that why he went blind for a while?

**How much pain did you still have in your abdomen when you arrived?**

- A lot of pain
- It wasn’t kidney stone pain (which is all but unbearable)
- He was visibly in pain, wincing and sure
  - Maybe like the pain of a broken leg

**Was your abdomen swelling at all?**

- He doesn’t know
- There was abdominal guarding, which is the muscles tensing in the abdomen to protect an injured area
  - But he didn’t know that
- He had the grim thought, “*You know what? You might have cancer or something. You might have a tumor in your abdomen that ruptured*.”
  - He was making this stuff up as I went along
  - He was aware of the possibility that he was going to wake up in the morning with some pretty grim news (you’ve got six months)
- But he had no idea that he was dying right now

**Did an aneurysm cross your mind?**

- Peter points out that Sebastian’s aneurysm is a very obscure one
- But if you think of the two most common aneurysms in the abdomen
  - 1 – An abdominal aortic aneurysm
  - 2 – A splenic artery aneurysm
    - Which is not that far from where Sebastian’s was, although the cause is hereditary
- Sebastian’s was caused by the [median arcuate ligament](https://en.wikipedia.org/wiki/Median_arcuate_ligament)
- One of Sebastian’s best friends had an operation to replace his aorta
  - They had to open him up and fix his aortic because he had an aortic aneurysm
- So he knew about this, but at one point, a nurse rushed in because they did a CAT scan on him, and he’s convulsing
  - He’s in deep shock and he’s got a heated blanket on him a
  - She came up to him and she said, “*You didn’t hear it from me, but good news, it’s not your aorta*.”
    - In his civilian, non-medical mind, he thought the aorta is part of your heart, why are we talking about this

***The short answer is no, he had no idea it was going down right now***

- He’s so glad he didn’t because he would have been absolutely terrified
  - He would have been thinking about his family

**When you went back to interview your wife, what did she think as the ambulance was leaving? What was her level of concern?**

- She was very worried because she’d seen him go in and out of consciousness and had a sense that at some point he’s not going to come back
- She kept squeezing his hand, saying, “*Honey, stay with me. Stay with me.*”
- He’d wake-up and babble and not make any sense and then go out again
- She couldn’t follow him in the ambulance because of COVID restrictions
- The ER doctor called and it took him a while to get through because the phone lines weren’t working and there was no cell service
- He told her to get to the hospital as fast as possible
- The doctor told the hospital to waive the COVID restrictions so that she could come in
  - She knew it wasn’t good
- Later Sebastian looked up the odds for surviving what he had, and they’re pretty grim (with quick transport time)
  - It took him an hour and a half to get there from the onset
- Thank God he’s healthy because if he had a bad heart or whatever
- Peter points out that the artery that had the aneurysm is quite small
  - Had it been a splenic artery, or if it was the abdominal aorta, he wouldn’t have made it out of the cabin

> “*A slightly larger artery, and I don’t think you’ve survived, given that you probably lost 60% of your blood volume into your abdomen*”‒ Peter Attia

- If Peter were in that situation, he would assume it was a gastric ulcer gone bad

**Did they tell you what else they were assuming this was?**

- At some point they would have drawn his blood and seen that his hematocrit instead of being 14 (normal) was 10 or less
- The doctor said he had almost never seen hemoglobin so low
- Sebastian’s blood pressure was 60 over 40, but it was the hemoglobin that really alarmed the doctors
- The doctors had a very difficult decision to make: take him to the cath lab or to the OR
  - Sebastian did a great job in the book of explaining the pros and cons of each (they made the right choice)
- He stabilized on 3 units of blood
  - Which is amazing because that’s a fraction of the blood that he lost (probably 6-7 units)
  - It must have created enough pressure around in what’s called the [retroperitoneum](https://en.wikipedia.org/wiki/Retroperitoneal_space) to create just enough to prevent more blood from going in so that when they gave him those 3 units, those 3 units stayed in his vasculature as opposed to just continued to leak out
- The problem with going into the OR and opening you up is you lose that back pressure and your blood geysers out of there
  - They have to find the bleed before you bleed out
  - It just sounds like a ghastly nightmare
- Peter explains their only option in that situation, “*is to do what’s called cross clamp the aorta… Literally, as ridiculous as that sounds, you take a big clamp and you go above the diaphragm, they might even open your chest, and they put a clamp across the aorta.*”
  - What that does is it absolutely stops any blood flow below that point
  - The good news is your heart and your head are going to be fine
    - Because your heart gets perfused above the aorta
    - Those are the two most important things
  - What’s going to happen is your kidneys are going to start dying
  - Everything below the body is going to have no perfusion, but that buys them enough time to find what’s wrong

Sebastian asks, “*Can they find it if it’s not bleeding?*”

- It’s very difficult because they’re going to have to go and see where the clot was, and then they’re going to let the clamp off, see what comes, reclamp

## Sebastian’s reaction to first learning he nearly died, and the extraordinary skill of the medical team that save his life [26:00]

- They stabilized him with 3 units over the course of an hour and then sent him into the IR suite while they were trying to track down the interventional radiologist
  - By now it was 9 pm
- They called [Dr. Phil Dombrowski](https://physicians.capecodhealth.org/ma/hyannis/27-park-street-dombrowski.html) in from dinner
  - He was known in the hospital as “The Magician” because he was super good at his job
- **Interventional radiology** involves putting someone on a [fluoroscope](https://en.wikipedia.org/wiki/Fluoroscopy) (which is like a video feed X-ray machine) and inserting catheters (so rubber tubes or wire) into the venous system, usually through the right groin, into the femoral artery
  - And then threading it around through your body, trying to get through the twists and turns of your vasculature, trying to get it to the site that needs work and your aorta or your pancreatic artery or whatever it may be
  - That avoids having to open the person up because you can work from inside the vascular system
  - It’s a rather lesser known of the medical specialties, but absolutely crucial

*Then you can look for, where is it bleeding?*

- His wife finally got to the hospital and they stuck her in the basement
  - Because of COVID, there’s no real waiting room, so she’s in a room by herself
- After hours, the doctor sprinted through shouting on his cell phone, “*It’s the pancreas. It’s the pancreas.*”
  - She didn’t know, they he was talking about Sebastian
- They’d finally located the bleed in his pancreatic artery
  - One of the 5 that goes into the pancreas
- So they started trying to get the catheter from my right groin in through my vasculature to the pancreatic artery
- And partly because of this strange anatomy that he has, the vasculature at his abdomen is very difficult to navigate
  - Over the course of some hours, they just kept failing to get there

Peter listened to his book on audio and asks, “*Are they’re figures in the actual book? Did you have an anatomic diagram of what the* [*celiac artery*](https://en.wikipedia.org/wiki/Celiac_artery) *looks like coming off the aorta into its pancreatic tributaries?*”

- There’s no diagrams

![](https://peterattiamd.com/wp-content/uploads/2024/08/f1-sebastianjunger2.png)

**Figure 1. Anatomy of the celiac trunk**. Image credit: [*StatPearls*](https://www.ncbi.nlm.nih.gov/books/NBK459241/)

**This was a difficult problem**

- Imagine what it’s like to put a catheter in the femoral artery (which is in the groin) and then you have to snake it up the femoral artery (which is really easy)
- It becomes the aorta (no problem)
- And then you’re going to pass some major branches
- The first thing you’re going to pass on the right and left will be the renal arteries (one going to each kidney)
- Then there’s these little vertebral arteries and things on the way
- The really big ones you’re going to see will be 2 big ones that go to the gut called [mesenteric arteries](https://en.wikipedia.org/wiki/Mesenteric_arteries)
- Then you get to the [celiac](https://en.wikipedia.org/wiki/Celiac_artery), and the problem with the celiac is it’s coming down
  - Sebastian’s is more problematic because it’s compressed by the median arcuate ligament

***The problem is how are they going to get the catheter to go up, then come down, then twist this way, then twist that way? That’s the real challenge with that big 180 degree hairpin turn***

- Sebastian’s vasculature around the pancreas was very contorted and distorted by the ligament in the wrong place
- He’s in the IR suite and he’s conscious
  - They didn’t sedate him
  - They gave him a little bit of fentanyl
- He’s in enormous pain because all this blood has settled around his kidneys and his back
  - His back was just in agony

**Are you conscious of time?**

***No, he knew it had been forever, but he didn’t have a normal sense of how many hours it had been***

- He was in and out of some minds
- At one point, he started seeing terrifying faces in the machinery and the fluoroscope that was above his head
  - That was really terrifying and reminded him of a very scary incident in Africa that happened to him years earlier
- He watched the doctors come to this moment where one of them shrugged his shoulders and basically was like, “*We tried. This isn’t going to work.*”
  - Sebastian couldn’t believe that he was watching this
- Dr. Dombrowski suggested going through his left wrist instead of his groin, and that somehow allowed them an approach that ultimately worked
  - They went through his left wrist and through the celiac from above
- They had to get through the occlusion because the ligament was completely blocking the celiac (and had been for his entire life)
- They inflated it; they were able to push it open and pass a catheter through that and eventually get it to the spot where they could embolize the rupture
  - They could block the rupture and pull their gear out, and they’re on their way to saving his life

> “*Medicine is so extraordinary, and I’m alive because of any number of people, the team that was in the room, but decades of doctors and researchers inventing this incredible technology, and the 10 people who donated blood that they pumped into my veins to keep me alive*.”‒ Sebastian Junger

**Interventional radiology, and how Sebastian felt after learning he almost died**

- Sebastian owes his life to many people

*A German doctor named* [*Werner Forssmann*](https://en.wikipedia.org/wiki/Werner_Forssmann) *invented the venous catheter*

- It’s a funny story; it’s almost exactly 100 years ago
- He was a young doctor in a small German hospital
- He had this idea: why can’t you push a catheter from a vein into your heart? Why can’t you do that?
  - Or from an artery
- He asked the director of the hospital for permission to do it on a patient. And the director’s like, “*No, we’re here to heal them, not to experiment on them*.”
  - Sebastian thinks it was 1923 in Germany
- Then he asked , “Okay. Well, how about a dying patient?”
  - But the director still said no
- So he snuck into the hospital, he had a confederate in a young nurse, and he told her that he was going to do this procedure on her, and she would be the first person to have a catheter inside her heart
  - Sebastian thinks she was kind of sweet on him
  - It doesn’t seem like much of an inducement, but she went for it
- She laid on the table and he strapped her arm down to get ready for the procedure
- After she was strapped down, he turned away and numbed his own arm and cut his arm open and threaded a catheter into his venous system in his arm and pushed it through. And he had the tube marked off to where it would be just about in his heart, and he pushed it to the marker, and then he released her from the table
- She was absolutely furious, apparently, that she had been cheated out of being a medical first
- They walked down the hall to X-ray, and he told the technician to take an X-ray and prove that he was in his own heart with a catheter

**Peter remembers the first time he put a catheter into the heart**

- He was a medical student
  - Today it might not be something they would let medical students do
  - Of course it was under supervision
- He put what was called a [Swan-Ganz catheter](https://en.wikipedia.org/wiki/Pulmonary_artery_catheter) from the subclavian vein into the heart and then ultimately into the pulmonary arteries to measure the pressure of the pulmonary system
- When you’re doing this, you can’t believe that you can do this
  - You can’t believe the human body, which on the one hand is so delicate and you’ve seen what these walls of veins look like
    - And that’s even more scary than the walls of arteries because they’re so thin
- You think, boy, if you screw this up, this person will be dead in about a minute
- Then you fast-forward to what Sebastian experienced and the level of skill that is required to put a balloon catheter from the subclavian vein into the pulmonary artery is not that difficult
  - You have to absolutely know what you’re doing, but what happened in Sebastian’s case is 2 orders of magnitude more skill required because they’re threading something very small from your radial artery all the way up into the subclavian, into the aorta, retrograde down
  - And then of course, they still have to do everything Sebastian just described
  - And again, you can’t use too much force
    - You can’t be a brute
    - It’s a finesse thing

**Sebastian was talking about his book at a reading a couple of weeks ago in Atlanta**

- Talking about putting the line into his jugular, and there was a guy in the audience who had needle phobia
  - Sebastian watched him pass out in his seat while he was talking about this
- He called for a doctor, “*Is there a doctor in the audience?*”
  - He never thought he’d have to say that
- 2 guys came rushing forward
  - A younger guy who was a paramedic who wrote a wonderful book called [*A Thousand Naked Strangers*](https://www.amazon.com/Thousand-Naked-Strangers-Paramedics-Wild/dp/1501110837/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.m8tzQ4uD_ZEg69mFBjF7I_mWkOQLHGjv6pn-2KpTkV-p_sIk7GNfmmBNq50vzBmF_umwTDd3lbBuM13XGqRHItQSSsyQeqg9_K0QFh07md-vltkzUpCGJBLiOfDurq6HrCCmBGeUqFr1G8D4RQpx9-jwlZkDtYK1m39IJeRGurGSXwpR_5tqS7TqFMNCY6zjhSFZXNrhDwClLPPqUg4mG1OSeUXF-ZLLUkO-lyj4K3w.7uRhouAvbT5KMCnGAzzJVL8GViT0lJHjuDadkzLKMXI&qid=1719852352&sr=8-1) (Which is a book about working on an ambulance)
  - And then another older guy came forward and they helped this guy
- The guy was fine
- The older guy who came forward had trained with the guy who saved Sebastian’s life, [Dr. Dombrowski](https://physicians.capecodhealth.org/ma/hyannis/27-park-street-dombrowski.html), this older guy in the audience was the mentor of Dr. Dombrowski
- He said maybe 5% of interventional radiologists could have done what Dr. Dombrowski did
- He said, “*You’re really, really lucky. Extraordinarily lucky. You really threaded the needle here medically.*”

**Back to Sebastian’s care at the hospital, and when he learned that he almost died**

- After many hours they managed to embolize the rupture
- They just knocked him out and sent him up to the ICU
- Sebastian briefly remembers seeing his wife and holding her hand afterwards as he was getting rolled out
- His back was still in agony
- He woke up to the sound of nurses’ voices in the ICU the next morning, completely ignorant that he’d almost died
- It was the ICU nurse that said, “*Man, no one can believe you’re alive. You made it*.”

## Sebastian’s near-death experience [37:00]

*The profound discussion with the nurse*

- As soon as she said, “*Mr. Junger, congratulations. Good morning. You made it. It’s a miracle,*” Sebastian was shocked, horrified
- Then he had this memory from when he was on the threshold
  - It came back to him instantly

> “*I had this memory from when I was on the threshold. It came back to me instantly. Particularly for me as an atheist, this was the central mystery of my experience. And whether it’s brain chemistry or not, this is the central mystery that I’ve grappled with.*”‒ Sebastian Junger

- When he was in the trauma bay, the doctor asked permission to put a line through his neck into his jugular (which didn’t sound like a lot of fun)
  - Sebastian had no idea he was dying and didn’t know what all the fuss was about
- Sebastian asked, “*Is that really necessary? Why?… In case there’s an emergency?*”
- The doctor said, “*This is the emergency, Mr. Junger*.”
  - The doctor was a young guy, probably 25, and Sebastian was like, “*Kid, I’m 3x your age.  What’s happening here?*”
- The doctor started working on him; they used an ultrasound probe
- This whole procedure that probably doesn’t take particularly long, it felt like a long time to him
- He’s lying there and feeling this pressure on his neck while they’re starting to prep the area
- He’s under a sterile clear plastic sheet
- The doctor asked if he’s claustrophobic
  - Apparently this is common for people who have been in combat
- Sebatsian said, “*I am actually,*” and he said, “*Well, that’s too bad.*” And he put the sheet over him
  - Sebastian was like, “*Oh, finally, someone with a sense of humor*.”
- They’re working on his neck and to his shock, to his horror, suddenly beneath him on his left, he senses this black void that opens up
  - This abyss, and it’s like this infinitely dark pit without dimension
  - And Sebastian is getting pulled into it
- He has no idea that he’s dying, but he was like a wounded animal

***He just had this animal sense: don’t go into the pit because if you go into the pit, you’re not coming back***

- He is conversing with the doctor
- It’s not like he visually saw it, but he felt it
- Suddenly there was this pit, he was standing on the edge of a cliff
  - You can kind of feel the void
- He was like, “*Oh my God, I’m getting pulled into this hole.*”
  - It was a completely new experience; he hadn’t felt it before
  - It was there very suddenly, and it was unopposable
- Sebastian got very scared
- Suddenly he saw his dead father above him and to his left
  - Not only is Sebastian an atheist, but his father was an atheist
  - His father died 8 years earlier
  - His father was a physicist, a rationalist, and trained Sebastian well in that way of thinking about the world
    - His mother, who was a bit on the “woo-woo side,” he drove her crazy by asking precise questions about her beliefs (it’s amazing they stayed married)
    - What do you mean bad energy?
    - How does bad energy make you sick?
- Sebastian was shocked to see him because he’s still talking to the doctors
- It’s not like he had cardiac arrest and he’s in some netherworld; he’s still there
- His father is above him in the room, and he communicated something along the lines of, “*It’s okay, you don’t have to fight it. You can come with me. I’ll take care of you.*”
- Sebastian was absolutely horrified
  - It was almost grotesque
  - He was almost offended like, go with you?
    - You’re dead. Why would I go with you? I’m alive.
    - We have nothing to talk about
- But he loves his dad and said, “*We have nothing to talk about here. I’m not going anywhere with you*.”

**Why do you think you weren’t comforted by him in some way?**

- From the book, it’s clear that Sebastian has an amazing affection for his father
- Peter wonders if his aversion to his father’s presence suggests something about engaging with him in any way was tantamount to death
- His father was clearly inviting him to join him where he was (dead)
- It felt like his father was part of an outbound journey that you’re not coming back from, into the nothing
- Sebastian was offended that his father would imagine that he would prefer to go with him into that than to stay in his life
- He worried that he would hurt his father’s feelings
  - On the level of, don’t you want to spend time with your daddy?
  - But he was like, “*No, you’re dead… We’ll talk later.*”
- He wanted to spend time here for the rest of his life

**One of the theories about near-death experiences is that it’s an adaptive behavior that’s a form of comforting**

- It’s comforting to the dying person that they see beloved loved ones
- It’s not just leaving this life, you’re crossing over into this beautiful world of all these dead people that you miss and it’s going to be fine

***That was absolutely not the case for Sebastian, he was horrified***

- Sebastian said to the doctor (because the doctor kept fumbling around with his neck), “Y*ou got to hurry. I’m going.*”
- He didn’t know where he was going
- He didn’t know he was dying, but he knew he was going somewhere where he wasn’t coming back
- The doctor got the line in and they started transfusing him

**Are you realizing this for the first time in the ICU the next day, or are you just remembering it and now experiencing it sort of through your memory the second time?**

- In the ICU, Sebastian remembered experiencing it for the first time
- It was an extremely powerful memory and it was terrifying
- He had just woken up from whatever they put him under with, and he was woken up by the nurse talking over him, talking to the other ICU nurse
  - He was woken up by voices
- He opened his eyes, and she said, “*Good morning, Mr. Junger. Congratulations*.”
- And as soon as she said it, he remembered that he’d had this terrifying encounter, this horrifying encounter with his father and with the pit
- His brain was so confused in those moments
  - It was like he was extremely drunk or something like that
  - He was rational enough to speak to the doctor, but he was in a very strange state of mind
  - So it wasn’t like in that moment he was thinking, “*Oh my God, oh my God, oh my God, I’m seeing my dead father*.”
    - He didn’t have that kind of self-conscious awareness of the moment, the way when we might now
    - But it was the first thing that came back to him when he woke up
- It was the first thing he asked his wife
  - Because again, he’s a journalist and a skeptic, and he was sort worried that he’d somehow unconsciously cooked all this up later
  - He asked my wife, “*When you came into the room, what happened?*”
  - And she said, “*The first thing you said to me was I almost died last night and I saw my father.*”
  - Whatever that means Sebastian is confident that he had some sort of experience in those moments and not one that was conjured later retroactively

**So say more about this nurse, what else did she tell you?**

- She dropped that bomb on him and left to go attend to the other patients
- He’s lying on the bed
- He’s got 6 units of blood sloshing around in his abdomen
  - He’s got 10 people’s blood inside him
- He’s got tubes all over the place
- He’s in incredible pain
- He’s throwing up blood because somehow the blood got into his digestive system
  - He was throwing out blood that whole morning
- He’s trying to digest this news that he almost died

**It just seemed inconceivable**

- Sebastian didn’t know anything about what dying feels like
- He’d pictured it to feel way more catastrophic than what he experienced
- He was in compensatory shock the whole drive down there
- And then he was in a very, very weird state and in a lot of pain
- It was inconceivable to him that this was it
  - This is the big deal
  - This is dying
- It just seemed like there’d be more blood on the floor, there’d be something
  - He had belly pain

Peter asks, “*But it didn’t resonate to you yet that if there were 10 pieces of Swiss cheese that were placed on top of each other, you happened to be one of those 10 stacks where a pencil still made it through. Did that occur to you yet? Because… there’s so much freakish luck. We could recount it all, but we don’t need to. At this point there were 10 things, all of which had to happen for you to survive right up into including having the right interventional radiologist there. Did that resonate yet?*”

***Not until later***

- When he found that out, as he started to do the research, every time he encountered another facet of how unlikely it was he would get incredibly depressed
  - It still depresses him
- When he talked to the mentor of the guy who saved his life and he said, “*You know Dr. Dombrowski is one of maybe in the 5% of all IR guys who could have saved your life*.”
  - He felt his spirits just plummet
  - There wasn’t any of this sort of former athlete of like, “Y*eah, I did something almost no one else can do*” (there wasn’t any pride in there)

## The psychological impact of surviving against overwhelming odds [48:00]

**Is there a sense of awe in that, or do you believe there’s meaning in that, or do you believe that there’s no meaning in that and it’s just as much luck as the world is full of bad luck?**

- We all are sort of looking for meaning in the universe and there are no coincidences and everything happens for a reason
- All those sort of narratives that we put on
- Sebastian thinks it’s a fairly random universe, random but for the laws of physics

*But in terms of the events of our life, Sebastian’s experience at an American purpose in Afghanistan*

- He was shocked to feel some sand flick into the side of his face
  - Bullets travel faster than sound
  - The outpost would get attacked from about 500 meters out, which is quite a long shot for an [AK-47](https://en.wikipedia.org/wiki/AK-47) or a [PKM](https://en.wikipedia.org/wiki/PK_machine_gun#), and the bullets arrive way before the sound does. So some sand flicked into the side of my face
- He just had time to think, “*What was that?*”
  - He was standing against some sandbags, and then he heard
- That was the first burst of an hour-long firefight, and the bullets had to have hit with maybe an inch or 2 from his forehead

> “*In my opinion, utterly random.*”‒ Sebastian Junger

- He was blown up by an [IED](https://en.wikipedia.org/wiki/Improvised_explosive_device), it went off under the engine block instead of under them
- The Taliban guy with the clacker and the ravine missed it by a second
- But the whole rest of his life unfolded is contained in that second in some ways because they were spared
- At one point when he was reading early on, right when the book came out, and a guy raised his hand at the end, he was quite agitated, and he said, “*I’m Christian, and you are alive because of God’s grace, and you have to come to Jesus and understand that it was only God’s grace that saved you*.”
  - Sebastian said to him, one of my best friends, my brother, my colleague Tim Heatherington was killed in combat in Libya on an assignment I was supposed to be on
  - His death was what got me out of war reporting, and then had a family, etc.
  - He also bled out, but he was in a war zone and they couldn’t save him
  - Sebastian told him, “*My with that way of thinking that there’s some purpose here, some meaning here is why me? Why me and not Tim? For that matter why me and not some nine-year-old with cancer? I’m sorry. And if God is running a random lottery for his grace, I don’t want any part of it. I think that the universe, it unfolds in random ways and I just got super, super lucky.*”

***But the fact that Sebastian got that lucky makes him profoundly grateful, and is also incredibly depressing to him for reasons that he can’t quite understand***

- He thinks about what was statistically supposed to happen by a factor of maybe 10:1 or something or more (probably more)

**Have you spoken with others?**

- That **gratitude** makes a lot of sense to Peter
- He is curious if Sebastian has spoken to others who have survived similar experiences
- Peter thinks of his friend [Ric Elias](https://www.ted.com/speakers/ric_elias) who was on that US Airways flight that had to emergency land in the Hudson
  - [discussed in episodes [#79](https://peterattiamd.com/ricelias/) & [#241](https://peterattiamd.com/ricelias2/)]
  - [Captain Sullenberger](https://en.wikipedia.org/wiki/Sully_Sullenberger) is the 1 out of 50 guys who could have made the right decision with enough time to spare and then carried it out
- Peter never asked him this question and it’s an interesting topic, “*How many people on this planet are alive only because of monumental luck?*”

**What is the balance between the gratitude and the heaviness of that that tips into dysthymia?**

- Sebastian thinks it would be psychologically a little easier if he didn’t have children
- His death would’ve left them with was such a legacy of pain and absence
- His poor wife, that made it harder
- The things that would’ve consoled him: holding his daughter
  - He survived, and here he’s holding his daughter in his lap and he immediately thinks, “*Oh, but this wasn’t supposed to happen. Right? She’s supposed to be grieving me right now, by odds of 100 to 1 she should. And it’s a miracle.*”
  - The he would just spin out into what could have happened
- Sebastian eventually talked to a shrink (with his wife’s encouragement), and it was a great thing to do
- His therapist was basically like, “*Listen, if you keep telling yourself this narrative that you almost died, you’re never going to escape this incredible anxiety and panic disorder and depression that you’ve worked yourself into. You have to stop telling yourself this story.*”
  - She was absolutely right

***Apparently this sort of negative storytelling is very, very common in people who almost died. And the sequence of really, really profound anxiety and fear, medical paranoia, that it’s going to happen again***

**That fear finally eased off and Sebastian wound up in an unbelievable depression**

- He’s never been depressed in his life
- He’s not a particularly anxious person

> “*I was amazed at how debilitating depression was.*”‒ Sebastian Junger

- He’s had friends who have struggled with depression, he lost a friend to suicide, and now he understood
  - He had wondered what they were talking about: why bother going through the rest of your life? That kind of thought. He had no idea
- It really opened a door into like to what depression is about, and it was quite frightening

**Sebastian was having trouble understanding, being confident about what reality was and what it wasn’t**

- Part of that stemmed from this somewhat clairvoyant dream that he had
- Sebastian reiterates, “*I’m really not a spiritual mystical or woo-woo person. I’m really not. Which is why this stuff unsettled me so much.*”

## Ignored warning signs: abdominal pain and a foreshadowing dream before the aneurysm rupture [54:30]

**36 hours prior to his near-death experience**

- The only symptoms Sebastian had that something was awry in his abdomen was a sort of intermittent pain that would come and go
- If he were more responsible, he would’ve gone to the doctor and they would’ve scanned him and they would’ve seen a big ass aneurysm in my pancreatic artery, and they would’ve fixed it without all the drama
  - But he didn’t do that, and it wasn’t consistent enough to get him to the doctor
- He just thought, “*Anything that’s going to kill me is going to be agonizing*.”
- He thought he had irritable bowel syndrome, a thought cooked-up from some internet Googling
- What it probably was was the aneurysm starting to dissect a little bit and leak a little bit of blood into his abdomen

***His body on some level knew there was a five alarm fire coming***

*36 hours prior to nearly dying he was woken up at dawn by this horrific nightmare*

- His family co-sleeps on a big pad on the floor
- In the nightmare, he was already dead
- He’s a ghost, a spirit
- He doesn’t know that he’s dead and his family is below him and they’re grieving
  - He realizes they’re grieving him, but he doesn’t know that he’s dead
- So he’s waving his arms and shouting, “*Hey, I’m over here. I’m right here. I’m right here.*”
- They can’t hear him and they can’t see him

***Then he’s made to understand that it’s too late, that because of his own stupidity, he didn’t take his life seriously***

- He assumes this to mean that intermittent pain in his abdomen
- Because he was cavalier about life and now it’s too late, there’s no going back ‒ he’s dead
- In the dream, he was so frantic with terror and anguish and an incredible sense of shame

***In the dream he had the feeling that he had somehow squandered this great treasure of life***

- And now there’s no going back, there’s no retrieving it
- It woke him up
- Suddenly he’s in my bed and like, “*Oh, thank God I’m not dead*”
  - Because it had felt so real
- He woke up next to his eldest daughter and he clutched her like he’s seen her clutch her stuffies
  - Just like, “*Oh, thank God you’re here; that I’m here*.”
  - He was overwhelmed with gratitude and fear

**Was the abdominal pain present when you woke up?**

- No, it wasn’t
- The pain was very rare and intermittent, but unmistakable

*How long had it been going on?*

- About 6 months

Peter asks, “*You had a full day after that dream before the day this all happened. In that one lucid day, did it cross your mind?*”

- Sebastian talked to his wife about it
- He’s an older dad, and sort of ascribed it to anxiety about being an older dad (how long is he going to live into their lives?)
  - He had his first child at age 55

***He didn’t really think about it***

**He has lots of compartments in his head where he puts things in places where he can’t reach them**

- Dealing with fear and other things
- As a journalist, you need those compartments or you can’t function
- He got extremely good at having these firewalls that separate him from emotions that are problematic and get in the way of what he’s trying to do
- To some degree, it’s adaptive and helpful in our lives, and after a certain point, it’s maladaptive
  - And clearly he’d got to that point, but he didn’t know it

## Sebastian’s recovery, his exploration of near-death experiences, and the psychological turmoil he faced as he questioned the reality of his survival [58:15]

**After coming back from the hospital**

- He was in the ICU for 5 days and then in the general floor population for a couple days before they discharged him
- He recovered very, very quickly
- He got home and started researching [NEDs (near-death experiences)](https://en.wikipedia.org/wiki/Near-death_experience), and they fall into half a dozen basic buckets (basic scenarios)
  - A black pit, a tunnel with a light at the end of it, dead relatives showing up, hovering over your body

**Peter finds it interesting that this is agnostic to technology and culture**

- To Sebastian it seems like a more universal experience
- One of the **classic NDE experiences** is hovering over your family or over the sort of surgery bay where the doctors are losing you, unable to communicate and you’re sort of above them and you’re getting tugged between this force that’s pulling you outwards into the beyond and these last ties to your earthly coil
- Prior, Sebastian had no interest in NDE’s at all
  - He didn’t know anything about them
- So he had these experiences with a rather clean slate
  - He’s not culturally prepped for these experiences

***Sebastian realized he had a rather classic NDE’s both in the moment and also in this weird dream***

- And this was the fear that he was seized with, along with how paranoid and anxious he was
- Sebastian thought, “*Oh my God, obviously I died in my sleep. My dream was my experience of actually dying and my wife woke up to her dead husband in the bed and I don’t know it because I continued on under the illusion that I went to the hospital, that I came back, that here I am holding my daughter in my lap. And it’s one long dying hallucination and I’m not really here, I’m a ghost and I’m imagining all this. It’s laughable except it’s not disprovable.*”
  - Peter agrees, that’s the challenge

**Sebastian had been traumatized in combat and know there’s a bumpy road to recovery afterwards**

- He knows it well
- It fades over time (like grief)
- Humans were amazing, we’re resilient
  - Unless you are particularly traumatized when you’re young, which makes resilience harder
- So he knew that terrain
- This was completely eclipsed anything from combat, and he was really traumatized by this
- When you’re a war reporter, you’re making a conscious choice to go to the poker table and bet your chips
  - Maybe I’ll get a book out of it
  - “I’m going to come back with more chips before I lose my shirt”
  - “I’m going to leave the poker table before I lose everything and I’m going to come back with these sort of riches, whatever they may be (experiential riches, professional riches)”
- He stopped “going to the poker table” when Tim got killed
- When Tim got killed, Sebastian thought, “*I’m going to get cleaned out the next time I’m leaving the poker table*.”
- Sebastian had a family, and what was so traumatizing was that he thought he was safe
- It’s like owing the mafia money: there’s nowhere you can go where you won’t have to pay this back
  - They will find you
- And that basically is what the universe is doing
  - It loaned you some carbon to make your body out of, and they  will be reclaiming that eventually Mr. Junger
- Sebastian thought he could sort of delay that
  - And you can’t

> “*None of us know that this isn’t the last day of our life*.”‒ Sebastian Junger

- Sebastian woke up that morning with not a clue other than this crazy dream, not a clue that this was it
- And that’s what was so incredibly disturbing is thinking that you’re not alive
  - It’s a common delusion for people who almost died (it’s a known thing)
  - It was what warped his mind afterwards
- Likewise, the depression and anxiety was something that many people have gone through
  - People who have almost died for medical reasons
  - There was some comfort in that knowledge

## A transformative encounter with a nurse who encouraged Sebastian to view his near-death experience as sacred [1:03:30]

- In the hospital, Sebastian woke up to the sound of the voice of a middle-aged woman with a heavy Boston accent
  - Which makes sense because he was in Hyannis, Massachusetts, and she and the other nurse were discussing him
- The nurse says, “*Ah, good morning, Mr. Junger, congratulations, you almost died last night.*”
- Then they left to attend to other patients
- Sebastain sat there just thinking about this news
  - Are you kidding?
  - It was horrifying, absolutely crushing
- Physically, he was incredibly compromised, in a lot of pain, throwing up blood
- He was thinking about how he almost died and didn’t know it
- She came back an hour later to see how he was doing
- He told her that what she had told him is terrifying and he can’t stop thinking about it
- She said, “*Try this. Instead of thinking about it like something scary, try thinking about it like something sacred.*”
- She walked out, and he lay there thinking about that
- He doesn’t go to church, he doesn’t believe in God, but the word **“sacred”** he feels is one that secular people have every right to use
  - There’s very, very fine secular meanings that you can bring to it
- A sacred task is anything that allows people to live with more dignity, more love, more freedom, less fear
- Religion can be sacred because it can achieve those things
  - It can really elevate human dignity, applied in the right ways
  - It can also obviously destroy it
- Therapists can have it, school teachers, even journalists
  - What do journalists do on their best days?
    - We go to places that are at least difficult and hard and intimidating, if not downright dangerous, and we try to come back with information that society, the human race, can make some use of to chart a better course
    - To maybe protect human dignity in Ukraine a little bit, to help the human lot a little bit
    - That is a sacred task
- Sebastian has done this his whole life, and it’s a responsibility, an honor that he takes extremely seriously
  - And he’s proud to be able to do it, and feel quite humble about it
- It’s one of those things that he is the most proud of in his life
  - Being not just a father, but a good father and a good husband
  - Being a good journalist for a number of years
- He thought, “*What about now?*”
  - He stopped going to the front lines
- But then he went to the ultimate front line: his own death, his own mortality
  - This thing that we all face and almost all of us fear

> “*I was allowed to go to the precipice, look over the edge, and then allowed to come back. Did I come back with any sacred knowledge?*”‒ Sebastian Junger

- Any knowledge that will help him or other people live with more dignity, less fear, more connection, more love, etc. ‒ that’s the task
  - That’s what this nurse asked him to do
- After Sebastian recovered and started thinking about writing a book, he thought, “*I got to talk to this lady, this amazing woman. What did she mean?*”
- He had trouble finding her
  - Maybe she was a traveling nurse or the staff forgot about something
  - Or just hospital bureaucracy, they couldn’t figure out who she was, or she didn’t want to talk to the press

**Because Sebastian had such trouble figuring out what was reality and what wasn’t, it crossed his mind that maybe he imagined a nurse**

- He saw his dead father
- Maybe he imagined a nurse who had exactly the information, the idea that he needed at that moment
  - Which, of course, is contained somewhere in him, he just didn’t have access to it, who had the information that I needed at that moment
- Who knows? And it doesn’t really matter, but it was an extraordinary experience

## How Sebastian has changed: a journey toward emotional awareness and fully engaging with life [1:08:45]

- Peter explains, “*Anybody who remembers our* [*first discussion*](https://peterattiamd.com/sebastianjunger/)*, and who’s familiar with your work, knows that no one’s ever accused you of being disconnected.*”
  - Sebastian wasn’t distracted, he wasn’t a guy numbing the pain of life with hedonic pleasures
  - He was the only person Peter knew who didn’t have a smartphone, who lives as close to off the grid as possible
- All of that allowed Sebastian to have this remarkable connection with the people who matter most (his family)
- So, it’s almost a little ironic that if we consider this a gift, it was given to you
  - You almost think that if anybody needs a gift like this, it’s someone like Peter
    - A guy who is way more distracted, and way more frenetic
    - And maybe, like most people listening
    - Who could use the realignment of what is sacred

**What has changed in you?**

- As Sebastian went into midlife, he dropped a number of things that made him feel very, very good when he was young
- He enjoyed alcohol, and 9 years ago, he stopped drinking
  - He never did drugs
  - He wasn’t an alcoholic
- He was a totally obsessive athlete
  - He was a pretty good marathon runner and distance runner
  - When he was young, he ran 4:12 for the mile
    - Which isn’t world-class, but it’s a decent time
  - He ran 2:21 for the marathon, 30 minutes for 10K
    - Decent times, requiring an obsessive amount of effort
  - The effort consumed his life
    - He was running 100-120 miles a week at a 6 minute pace
    - He was clearly avoiding something
- Looking back, he was avoiding a certain emotional experience that he didn’t feel prepared for, and probably wasn’t mature enough for, wasn’t ready for yet
- His father really was quite a brilliant physicist in his specialty of acoustics
  - He was very, very clearly on the spectrum, spectrum disorder runs through his family
    - Disorder is a bad word because it has so many adaptive uses
- There is a certain focus of mind, that you’re looking at the world through a toilet paper tube, you’re seeing the small circle of light and that’s all you’re seeing, which means you can focus incredibly intensely on it, and you’re pretty oblivious to everything else
  - Sebastain watched his father do this and seen in himself a watered down version of this
    - This dogged pursuit of some kind of penetrating insight, some kind of excellence, some kind of transcendent accomplishment
- Sebastian writes good books that affect people
  - He figured out how to do it
  - It requires a huge amount of concentration
- His father really advanced physics in interesting ways
- A lot of his fellow physicists are exactly the same way, just ask their wives
  - Out to lunch most of the time

***The cost of that is that you’re not experiencing your life in emotional terms, and when there are emotions in your life that are unpleasant or even terrifying to deal with, you could actively turn on this obsessive focus in order to avoid dealing with it***

- So, there’s a passive, “I don’t notice, I don’t notice”, but then when a threatening emotion comes along, like a painful breakup or whatever it may be, then you can really turn on the jets, and really blast off into whatever direction you’re doing
- For a while it was 120 miles a week, then later in Sebastian’s life it was this pursuit of journalism, and this maniacal focus that he’s capable of
- Once you get into that rhythm of being able to go through life, you’re richly rewarded for the accomplishments that come with that kind of focus
  - Society is around you saying, “*Well, done, sir. Awesome. Amazing. Your book changed my life. Your blah, blah, blah, whatever it may be*.”
    - It comes in all flavors

***You think your life is a raging success, but actually, you’re not experiencing the actual feeling of being alive all the time***

**Sebastian remembers at one point in his second marriage**

- His first marriage didn’t work; he’s still very good friends with his ex-wife
- Any divorce is incredibly sad and painful, even if it’s amicable (which theirs was)
- He was still going through this legal process of divorce, and was very sad, and found himself in this wonderful new relationship that turned into his second marriage, and his family
- In this process, because he’s not in touch with his feelings at all (unless absolutely necessary), he would just drop into these pits of sadness
  - And he didn’t know what they were
- His wife Barbara said one day, “*Honey, something seems up today, are you all right?*”
  - He replied, “*No, I’m not. I feel really strange, I don’t know what it is*.”
  - She said, “*You’re going through all this stuff, maybe you’re just really sad.*”
  - He realized she was right, that was what the feeling was
  - He couldn’t believe her insight

***All that to say he was not distracted, he was tuned-out***

- He was not as bad as his father, but it was enough to be problematic
- During painful emotional territory he found a good refuge in athletics and then in his professional endeavor in journalism that he so completely fell in love with

## The possibility of an afterlife, and how quantum mechanics challenges our understanding of existence [1:15:15]

- Sebastian has alluded to the fact that he’s an atheist, yet whether a person is an atheist or a believer doesn’t speak to the question: Is there or is there not an afterlife?
- There’s a 2-by-2 we should consider [shown below]
  - Is there a God or a creator, or is there not?
  - Is there an afterlife, or is there not?

![](https://peterattiamd.com/wp-content/uploads/2024/08/f2-sebastianjunger2-1024x219.png)

**Figure 2. 2-by-2 of belief in God and an afterlife**.

- Peter has been thinking a lot about this because the God problem is an enormous problem
  - On the one hand, he doesn’t actually understand how any of us exist
    - In the sense that if you just think about it, stochastically, it doesn’t make any sense
  - There’s no amount of knowledge he has about biology, mathematics, and physics that explains why he’s sitting here, and why you’re sitting here, and why we’re doing what we’re doing right now
    - The 3 billion base pairs that define you, the 3 billion base pairs that define me, each of those base pairs has 4 possible DNA molecules that could define them, the numbers are so big they don’t add up
- You can go down the path of, well, there must be a creator, but then you’re stuck with the who created the creator problem
  - Let’s not even interrogate that

***If we just focus on this afterlife question, which, doesn’t require a God necessarily, it’s hard to do it without talking about physics***

- At the end of the day physics is what the world is, that’s what reality is made up out of
  - It’s particles and atoms and the laws of physics that govern them
- One of the things Sebastian wrote about in his book was his relationship to one of the greatest physicists of the last 100+ years: [Erwin Schrödinger](https://en.wikipedia.org/wiki/Erwin_Schr%C3%B6dinger)

**Do you want to recount the story of how you find yourself within his sphere?**

- Sebastian’s father grew up in Europe, he was born in Dresden, his father was Jewish, his mother was Austrian/Italian, Catholic
  - This pairing was unheard of  back in the 19-teens, 1920s

*His father was born in 1923 right after World War I*

- 10 years later is the [Reichstag Fire in Germany](https://en.wikipedia.org/wiki/Reichstag_fire), and they decamp for Spain
- His dad’s dad was Sephardic and Ashkenazi Jewish, so he spoke Spanish and Russian and German
- His dad went to Spain and was there for 3 years when the fascists come in under Franco (his dad was 13)
- So now they leave Spain for France, and he goes to French high school
- Then when he is 17, the Germans come into France
- They flee France, wind up in Portugal, and he picks up Portuguese along the way
- And then he lands in America, and learns English
- Sebastian is fond of saying, “*Thanks to the fascists, my father spoke 5 European languages fluently.*”
- That’s how he came to America, but his mother’s side of his family was from Austria, from Salzburg; upper middle class

*Sebastian’s father’s mother was born in 1900*

- She was known as a great beauty in the small city of Salzburg
  - As were her twins, Ithi and Viti
  - They were renowned as teenage girls for being really beautiful

*The family happened to know the Schrödingers*

- [Schrödinger](https://en.wikipedia.org/wiki/Erwin_Schr%C3%B6dinger) was this preeminent physicist: [Schrödinger’s cat](https://en.wikipedia.org/wiki/Schr%C3%B6dinger%27s_cat), one of the fathers of quantum mechanics, won the [Nobel Prize](https://www.uzh.ch/en/researchinnovation/excellence/nobelprize/schroedinger.html#:~:text=In%20a%20surprising%20fashion%2C%20however,1933%20Nobel%20Prize%20in%20Physics.)
- Schrödinger was in his 40s and had a family, and was a bit of a dog
  - Affairs all over the place (as many people had then and still do)
- At one point, these girls (the twins), they’re failing high school math (they’re 16), and the mother has the great idea of calling Schrödinger’s wife, saying, “*I know your husband’s a mathematician, my girls are failing math, do you think they could come visit for the summer in Germany, where the Schrödinger’s were living, come visit for the summer, and maybe he can tutor them in math?*”
  - You just have to understand how completely ridiculous… It’s like Einstein, right?
- So, off the girls go for a summer in Germany, and Schrödinger falls in love with Ithi, one of the twins
- He manages to get them through their math tests
  - The math is so simple that he actually doesn’t understand it very well because it’s so simple
  - So, he has consult with his wife’s lover, who’s a mathematician
    - The romantic drama of these people is just extraordinary
- Ithi and Schrödinger tastefully wait until she’s 18, and he’s 45 or something, and they have this passionate affair that lasts some years
- Tragically, she got pregnant, the pregnancy was aborted, and as a result, she was never able to have children
- Sebastian knew her much later in her life, when he was a child, and she was married and a rather sad figure
  - Probably due to what was really a tragedy in a young woman’s life of losing the ability to have children
- Schrödinger was really in love with her
  - Sebastian has handwritten letters and poems that he wrote her
- There’s a wonderful biography of Schrödinger that came out in the 80s or 90s, and the bookmark Sebastian’s father used in it is a handwritten letter by Schrödinger to Ithi
- That’s his family history of Schrödinger

**The experiment with Schrödinger’s cat**

- Many people know the experiment; it’s a thought experiment, and it speaks to one of the challenges of understanding quantum mechanics

*Briefly explain this thought experiment and what purpose it serves in understanding this*

- The **central enigma and mystery of quantum physics** is the fact that if you don’t observe what a subatomic particle is doing, it appears to be in all possible places (it’s a waveform)
  - Sebastian is speaking as a civilian who read and tried to understand physics
  - He’s doing his best to render it understandable, but he’s not a physicist
- And if you fire, say a photon at a steel plate with two slits in it
  - The photon, unobserved, will go through both slits and leave a signature on the strike plate on the other side, that shows it simultaneously went through both slits
- We can’t do that, we cannot walk through 2 doorways at the same time
  - In the macroscopic world, you’re in one place or the other
- But unobserved, a subatomic particle appears to be able to go through 2 slits at the same time
  - It’s basically a huge potentiality that only collapses into 1 single thing (it only goes through 1 slit) if you actually observe it, and measure it
- Unavoidably, the thought arose to these early physicists: ***Is our conscious observation of subatomic reality creating the thing that we observe? And if so, is our observation of the entire universe creating the universe as observed?***
  - Early physicists being [Heisenberg](https://en.wikipedia.org/wiki/Werner_Heisenberg) and [Schrödinger](https://en.wikipedia.org/wiki/Erwin_Schr%C3%B6dinger) and a number of others, most of whom were from the German-speaking world, and [Dirac](https://en.wikipedia.org/wiki/Paul_Dirac), from England

***What exactly is happening, and are we creating what we see by seeing it?***

- Schrödinger came up with a thought experiment
- He put a cat in a box, with what he called a fiendish mechanism (German translation)
  - And the fiendish mechanism is an isotope that has exactly a 50/50 chance of decaying in the next hour
  - Sebastian is a little rough on the details
- If it decays in a certain way, it will emit enough radiation to kill the cat, and if it doesn’t, the cat is fine
  - Basically, it’s just that there’s a 50/50 chance that this decaying isotope will kill the cat or not kill the cat
  - Sebastian thinks the radiation triggers the release of a gas that instantly kills the cat
- There’s another step, but it doesn’t matter
- The cat is in this enclosed box, and after 1 hour there’s 100% chance that 1 thing or the other happened, there’s no 3rd possibility (it’s completely binary)
- Likewise, at the subatomic level, particles are in one place or another (it’s a complete binary)
- There isn’t, like in the macroscopic world, a pendulum swings and traverses through all the different spaces
- At the quantum level, you’re in one place or another, likewise, the cat is alive or dead
- It’s a massive waveform

***And Schrödinger said the cat, in quantum terms, is both alive and dead simultaneously, until you open the box, and observe either a dead cat or a living cat***

## Quantum paradoxes leading to philosophical questions about the nature of reality, existence after death, and whether complete knowledge could be destructive [1:26:00]

**There’s a great description in the** [**book**](https://www.amazon.com/My-Time-Dying-Came-Afterlife/dp/1668050838/ref=sr_1_1?crid=HFHN8EVWHUMY&dib=eyJ2IjoiMSJ9.BoTYIvwbTa2HEQjJOvD6339_ZkhPtYy1ue36N2POECrE1Wvr9QNQM5RGJQxPGtS1-vzIqtd2ubwYUIuG56-pBqkBiwGqChftA1ooxxTJsZTpVLtUcia2sE21NMUYLsktkivWK9x7C8CXhLOUEHwIRLq5gMJ8pJAlVPQA22NqlsMTRq4S9uismmJXw__Xuah368B8a0H8P554J55NZ7rqcHIkW7SZaLkl64MYT1WH6zA.eh5sTUy4sxUE0-87_OgRRhVFENlN5DepSWexpN8bHTs&dib_tag=se&keywords=sebastian+junger+in+my+time+of+dying&qid=1719585279&sprefix=sebastian+Junger+%2Caps%2C99&sr=8-1) **of an experiment that Peter wasn’t aware of**

- This experiment that took place off the coast of Spain in the Canary Islands
- The experiment is very complicated, but it actually illustrates this point, with a little more nuance

***The point is, when you look at the path of these electrons or particles, unobserved, they are indeed behaving this way… it’s so mind-boggling***

*It’s called* [*delayed-choice quantum erasure*](https://en.wikipedia.org/wiki/Delayed-choice_quantum_eraser)

- Sebastian included the technical description of the experiment in the book because for the civilian, it’s just absolute madness
- It’s describing the physical setup of the experiment, with lasers and mirrors, and telephone cable, and fiber optics cable…

***This is an example of: this is how far out there these scientists are getting, that we don’t even understand the language that they use to describe how they understand the universe***

**Entangled particles**

- There are things called [entangled particles](https://en.wikipedia.org/wiki/Quantum_entanglement#Concept), and entangled particles are subatomic particles that affect each other instantaneously, and have to do the same or corresponding things
- If you do something to 1 particle that’s entangled with another particle, the entangled particle reacts in the same complementary way instantly
  - And instantly means faster than the speed of light
  - And information cannot travel faster than the speed of light
- What they found is that entangled particles, even on opposite sides of the universe, if you do something to one, the other entangled particle is affected instantaneously (those are entangled particles)
- That’s how the universe works for some reason

*So, they figured out a fiendish mechanism for tricking the universe*

- They take entangled particles (Sebastian doesn’t understand how they do this) and you fire one at a double slit, unobserved
  - In the classic double slit experiment
- We know for sure that it goes through both slits at the same time, because it’s unobserved, we know that that’s how it works
- And then, with a tiny delay, you send its entangled twin through double slits and you observe it, and it’s forced, because of observation, it’s forced to go through one slit
  - The reason the entangled particle has to pick a slit is because it’s being observed
  - It’s now in the physical world again, it’s no longer a probability distribution, it’s going to behave like things that are observed behave
    - Pick a doorway, one or the other, but not both
- But now, the universe has a **problem** because entangled particles have to do the same thing, and we know that they’ve just done different things
- Meanwhile, it’s twin that was fired off an instant before was unobserved, and so it remains, as you say, a probability distribution, and physically goes through both slits at the same time, and hits the strike plate on the other side with a classic waveform signature that physicists well know means it pass through both slits
- So, when they observed the second entangled particle going through one slit (as it has to because it’s being observed), and then they look at the results of the first particle that was unobserved and had to go through both slits
  - When they look at the strike plate, it shows a signature of having only gone through one slit, because entangled particles have to do the same thing
- What this means is that not only do they infect each other instantaneously, but effectively speaking, **the mechanism reached back in time and changed the outcome** of the first entangled particle, it’s delayed choice quantum erasure

***What Sebastian says in the book is that if there a post-death existence for the individual, it would have to work on a level of just sheer weirdness that delayed choice quantum erasure exists***

Peter asks, “*Do physicists believe that what you are describing is, to quantum theory, what quantum theory was to Newtonian mechanics? In other words, is there now a third layer of physics that is set free from what we understand today, and is yet to be described potentially?*”

- [Newtonian physics](https://en.wikipedia.org/wiki/Classical_mechanics) explains everything we see
  - We see airplanes fly, that doesn’t make a lot of sense
    - If you were one of our ancestors saw that they wouldn’t understand it, but we can understand how an airplane flies (that’s Newtonian physics)
- What happened with the quantum revolution in the early part of the 20th century is physicists realized that Newtonian physics breaks down at the atomic level, and you need new physics to explain what’s happening there
- Sebastian is not sure and explains that many physicists themselves (Schrödinger and Einstein) were unnerved by this
  - The results just didn’t make sense

**There’s this other experiment where Einstein comes to the conclusion that either particles are moving faster than the speed of light, or they are containing within them deciding information**

- Neither could be true, he sets out to prove it, and the only way he can prove it is to violate something withheld in quantum theory itself
  - Peter believes it was through the [photoelectric effect](https://en.wikipedia.org/wiki/Photoelectric_effect)
- This is why Sebastian chose math over physics, he’s not smart enough to do quantum theory
- He almost had this thought, “*Whoa, careful what we try to find out*.”

**Sebastian provides a metaphor**:

As you approach the speed of light, mass gets infinitely heavy and you can never get to the speed of light as you approach infinite mass…

So as we approach complete knowledge, *does the experimentation and the theories get increasingly inaccurate and misleading so that we never quite get there*?

- Because if we get there, if we have complete knowledge of everything, does that destroy everything?
- Because if we get there, if we have complete knowledge of everything, does that destroy everything?
- Is there an element of: consciousness can’t fully understand consciousness, or if it does, it cannot sustain itself?
- That’s just thought experiment wordplay, but it did sort of make him, on a human level, just be a little queasy
- Do we really want to interrogate God about how all this stuff works?
- Are you sure you want to know this? Are you sure you want to understand delayed-choice quantum erasure?

Peter asks, “*Would knowing this help us live better lives on this planet?*”

- The answer is probably no
- Where it becomes really unsettling is when you contemplate life or existence or nature or matter (whatever) *post life*
- For Peter, this is the part where it’s very difficult to let this go
- Which is if my belief is that once I experience death as defined very clearly and very medically, there is no existence versus, no, there might be something there, even though we can’t imagine what it is

***You could argue maybe knowing that does make it easier to live today***

- This is where Peter usually ends up putting his head in the sand after an hour of thinking about it and just goes back to watching F1 videos on YouTube
- [Arthur Eddington](https://en.wikipedia.org/wiki/Arthur_Eddington#) observed [a total solar eclipse in 1919 on the island of Príncipe off the west coast of Africa] and validated Einstein’s prediction [that light “bends” as evidence of [general relativity](https://en.wikipedia.org/wiki/Arthur_Eddington#Relativity)]
  - He said something like, “*Something we don’t understand is doing we know not what.*”
    - That was his ultimate evaluation of what’s going on in the universe
  - He felt that if you want to propose a theory, you must offer the scientific community ways to disprove it
    - If I’m wrong, these will be the numbers
    - Investigate the numbers
  - This is what he did with the eclipse, he predicted the bending of light during a complete solar eclipse
    - A star in one position should be in another position because of the bending of light, and if it’s not in that position, he’s wrong
    - Eddington helped confirm the theory of general relativity

**As a nice little tie into everything, do you know how Einstein died?**

- An abdominal aneurysm
- He was in his 70s and he refused treatment

## The sweet spot of uncertainty: exploring belief in God, post-death existence, and meaning in life [1:37:00]

**To the question about is this good for us or not**

- Other than the completely abstract and terrifying, maybe we don’t want to know everything because the universe will collapse into a spacetime of zero radius (or whatever the phrase is)
- Sebastian is still an **atheist**
  - God is not part of his daily practice
  - It’s not how he understands reality
  - God does not guide his decisions and his values
    - He is a moral person in his own right and he does fine with it
- He doesn’t particularly like the term **agnostic** (which he is happy to talk about)

Peter asks, “*Meaning you feel you need to either shit or get off the pot?*”

- Sort of

**Sebastian’s analogy to understand the meaning of agnostic**

- To put it in human terms, if you’re in a happy marriage and you have no suspicions that anything is going on that would upset you about your spouse at all, and someone said, “*Is your wife cheating on you?*”
  - And you said, “*I’m agnostic on that, I don’t know.*”
  - You wouldn’t say that unless you actually had some reason to doubt
- So when you say, “*I’m agnostic about God*,” what troubles Sebastian is that there’s absolutely no evidence that your wife’s cheating on you. Right?
  - Just absolutely no evidence that God exists
  - If that’s the case
  - If there is some evidence, she said she was going to the movies and she didn’t go to the movies, now I can say I’m agnostic
  - But until then, until I’ve seen some evidence that God exists
- If Sebastian saw overwhelming proof of God, he would be a believer
- If he saw some evidence that God exists, he would be agnostic
  - He’d be like, “*Well, I’m on the jury and I don’t know*.”

***Sebastian thinks the way most people use the word agnostic is inaccurate***

- He thinks most people are in one camp or the other, and they’re just not willing to admit it

**Maybe we don’t have a clear definition of God**

- Peter thinks this is a challenge with the terminology
- For example, many different religions will have many different versions of what a God is
- And then there are probably some people who wouldn’t subscribe to anything within an organized religion but would describe themselves still as spiritual and might still argue that there is a God but not “The God” kind of thing
- It gets so complicated, but that’s why Peter wanted to separate it away from that because **there is a really clear situation of none of that matters**
- And we’re still wrestling with the question at hand, which is: *What does it mean to die on this planet?*

**What does it mean to die in this physical body that stops respiring to which we are rushing towards entropy?**

- After his near-death experience, Sebastian was faced with some very, very puzzling, very, very puzzling memories
- Specifically seeing his dead father in some form above him
- And is it just neurochemistry? Yeah, possibly
- It would have to be at some quantum level, some post death existence that we just don’t understand?
- For the first time in his life, he would honestly say, yeah, possibly
  - He’s agnostic on it, agnostic for specific reasons
  - He actually has evidence
    - There’s evidence on both sides
    - It’s a hung jury

***He doesn’t know beyond a reasonable doubt, but the idea has been open to him that the suspect is possibly innocent (for the court analogy). Maybe there is something.***

**Sebastian’s** [**book**](https://www.amazon.com/My-Time-Dying-Came-Afterlife/dp/1668050838/ref=sr_1_1?crid=HFHN8EVWHUMY&dib=eyJ2IjoiMSJ9.BoTYIvwbTa2HEQjJOvD6339_ZkhPtYy1ue36N2POECrE1Wvr9QNQM5RGJQxPGtS1-vzIqtd2ubwYUIuG56-pBqkBiwGqChftA1ooxxTJsZTpVLtUcia2sE21NMUYLsktkivWK9x7C8CXhLOUEHwIRLq5gMJ8pJAlVPQA22NqlsMTRq4S9uismmJXw__Xuah368B8a0H8P554J55NZ7rqcHIkW7SZaLkl64MYT1WH6zA.eh5sTUy4sxUE0-87_OgRRhVFENlN5DepSWexpN8bHTs&dib_tag=se&keywords=sebastian+junger+in+my+time+of+dying&qid=1719585279&sprefix=sebastian+Junger+%2Caps%2C99&sr=8-1) **is divided into 2 sections: what and if**

- 1 – What happened to him
- 2 – And what if there were some post-death existence
  - Theoretically, as a thought experiment, how would it work?
  - There’s almost certainly not, but if there were, how would it work?
  - And that’s where he wound up in quantum physics

**Sebastian had a hilarious conversation with some colleagues of his father who he tracked down after his near death experience**

- Guys who were very fond of his father and half a generation younger than him (half a generation older than Sebastian)
- They had lunch, and Sebastian told them what happened to him, that his dead father appeared over him
- He asked them what his father would think of this
- Rodolfo said, “*Well, your father was a hopeless romantic*.”
- Sebastian thought that would be news for his mother
  - His parents eloped to San Francisco to get married, timed to coincide with the weekend of the annual meeting of the American Acoustical Society in San Francisco
- Rodolf explained that Sebastian’s father was deeply in love with the Helmholtz resonator and talked about it constantly
  - There’s something called the [Helmholtz resonance](https://en.wikipedia.org/wiki/Helmholtz_resonance) in acoustics
- Right after Sebastian’s parents were married, his mom was cooking dinner and his dad was in the armchair reading in front of the fire
- He mutters, “*Oh my God, that is so beautiful. That’s the most beautiful thing I’ve ever seen. That’s just absolutely gorgeous.*”
- She tiptoes over to see what he’s looking at, and he has a book open
  - Both pages are covered with numbers and equations and symbols

***That’s what’s so beautiful to him. That was his brain. These are the gentleman that Sebastian is having lunch with.***

Sebastian asks these guys, “*Okay, guys, what are the odds that my dead father could appear above me in some form while I’m dying?*”

- He assumed it was a rhetorical question
- To his amazement, the guys are thinking about this, sort of running the numbers
- They say something on the order of, “*I think 10 to the minus 60*”
  - So 1 chance in a number that has 60 zeros after it
- He explained, “*Well, it’s roughly the chance that all of the oxygen molecules in the air of this room would just randomly, through statistical mechanics, just randomly collect in one corner of the room and asphyxiate us. Almost impossible, but it’s theoretically possible. Well, likewise, it’s probably the odds of your father rematerializing above you, roughly on that order of unlikely.*”
- But then it turns out, if you look at the odds of the universe existing, it’s way, way more unlikely
  - It’s 10 to the minus 230 (1 chance in a number that has 230 zeros after it)
  - It’s millions and millions of times less likely than finding one specific grain of sand in all the sand on the earth on the first try
  - Something like 30 parameters have to be in very precise places for a physical universe to exist, the force of gravity, all these arcane things that most humans don’t know about
  - And then for conscious life to develop, it’s almost infinitely unlikely

***At least according to Rodolf, it’s way more unlikely that the universe exists in the first place (and we know that it does because we’re here) than Sebastian’s father appearing above him***

- That’s actually, in the realm of chance, way more likely than the universe existing in the first place (which we know it does)

> “*We don’t understand it, but I can imagine that it’s possible.*”‒ Sebastian Junger

- This is where Peter finds himself: he’s not smart enough to understand this stuff
  - He doesn’t understand consciousness; he can’t explain it
  - It doesn’t matter how much he reads
- Sebastian proposes, “*It’s possible that we understand reality as well as a dog understands a television screen, just no concept of the wider mechanics, the wider reality, the wider context that produces the flickering images that the dog sees on the screen that we see in reality. And there’s a much vaster colossus around that that produces what we see, and we just don’t have the equipment to understand it.*”

**Schrodinger’s opinion was that there was a universal consciousness**

- It was a sort of vaguely Buddhist idea
- He felt that we as individuals are part of that universal consciousness and sort of reunited with it when we die
- His theory wasn’t very articulated, but that was his sort of general belief, as was Sebastian’s father’s

**There’s a theory called biocentrism**

- Biocentrism is unprovable and undisprovable, which basically holds that if it’s true that conscious observation creates the reality that it observes, then the entire universe might have collapsed into its specific form from one enormous possibility
- One enormous spectrum of possibility with the arrival of conscious thought, and that creates the universe that we’re in
- In this sort of snake-eating-its-own-tail way
- And that consciousness is part of the physical makeup of the universe at the quantum level the way gravity manifests itself in matter
  - Something called the [Higgs boson](https://en.wikipedia.org/wiki/Higgs_boson), which is what manifests gravity in matter
- And that there might be something akin to that that is connected to consciousness, which gives rise to the physical universe that in turn allows for consciousness

***It’s hopelessly circular***

*The Higgs boson has been observed in the last 15 years*

- This force that’s throughout the universe, that is one of the basic reasons the universe can exist, it is there because there’s a subatomic particle called the Higgs boson

***Maybe there’s an equivalent for consciousness (this is all theorizing)***

- And that if that’s true, that our individual consciousness (mine, yours, all of ours) is actually part of this sort of colossus of matter and consciousness, which is the universe
- Not provable, not disprovable, but there is on the sort of human level something close to a comforting thought in that
  - The idea of being conscious like we are now for eternity
- The idea that you die and then the real thing starts that lasts forever
  - There’s no exit, you can’t kill yourself to get out of this deal, you are going to be conscious, whatever that experience is, and it may be horrific for eternity
    - Thank you, no. Sebastian will take a long nap, he doesn’t need that

***An eternal afterlife isn’t that appealing, but the annihilation of death is also quite terrifying***

- Sebastian explains, “*The idea that there’s some sort of ill-defined consciousness that we return to and can manifest itself at these threshold moments of life and death where the dead are maybe in some way “there with us,” that to me is the sort of sweet spot.*”
  - It’s just comforting enough to allow us to face death but without this implausible fantasy that we’re in a hammock with a daiquiri for eternity
  - The idea that the afterlife is just one big long vacation, that sounds hellish also

**If we knew for sure there was an afterlife**

- If there was actual proof
- If the afterlife went on forever
- If you’re alive for these troubled 70, 80 years and then whatever happens, your afterlife starts and you’re just cruising for eternity

***It strips all of the meaning, all the dignity, all the struggle, all of the victory out of those 70 years of struggle and joy and pain and sorrow and everything***

- It’s like, “*Don’t worry about it. Eternity is going to start soon enough. There’s an afterlife.*”

> “*It really strips from us the value of the one thing we do know exists, which is our own experience right now in this moment, this continuity of moments. That would be a pity, to have that stripped away from us.*”‒ Sebastian Junger

- As hard as we work in this place
- This is all we know we get

**On the other hand, if we could prove that there was no afterlife**

- If we’re completely biological beings (God or no God), then when we die, that’s it
- There’s no soul, no nothing, you’re dead
  - It’s just carbon transfer
  - It’s as if you never happened, it’s zero, it’s nothing

***That might be so psychologically troubling that we actually have trouble living those 70 years with dignity***

**The sweet spot of where we are**

- We can’t prove there is or isn’t an afterlife (there might be)
- There’s some reason to hope so we don’t have to be too scared
- But there’s also some reason to think there might not be, so make the most of today because that’s all we know we’ll get

***This sweet spot of ambiguity is actually perfectly attuned to making this life both psychologically survivable and meaningful***

- To borrow a Christian word, another of the sort of “miracles” of all this
- Like, wow, you really landed it, God, if you’re out there
  - You really landed us in just the right spot to absolutely maximize the meaningfulness of this thing we do have, which is life

## The transformative power of experiencing life with awe and gratitude [1:53:00]

Peter recalls that Sebastian wrote something so beautiful near the end of the book, “*Without death, life does not require focus or courage or choice. Without death, life is just an extraordinary stunt that won’t stop.*”

- Sebastian thinks this is a terrifying idea in its own right
- Anything that won’t stop is a terrifying idea

**Dostoevsky’s brush with death**

- After Sebastian finished the book, he read about [Dostoevsky’s](https://en.wikipedia.org/wiki/Fyodor_Dostoevsky) extraordinary life (the great Russian writer)
  - Had he read it when he was doing the book, he probably would’ve put it in there
- When Dostoevsky was in his twenties, he was a bit of a political radical, and he had a bunch of radical friends, an intellectual circle
  - They would sit around and they’d talk about stuff
    - For example, freeing the serfs, outrageous ideas like that
  - This was in the 1840s
    - Basically, the same conversation were happening in the United States about slavery
- The czar (Nicholas I) was not particularly pleased by this talk, and his police rounded these boys up and threw them in jail
  - They spent 8 months in jail
  - It wasn’t a particularly serious crime, so they were getting their wrists slapped, but no one was particularly worried about anything
- Then finally after 8 months, they were shown to the door of the prison and loaded onto a carriage, and they just assumed they were going to be driven to the court and discharged and released to their families and the nightmare’s over
- And so they’re bouncing along through the streets and instead of going to the court, they’re driven to a city square and they’re tied to posts and a firing squad is lined up in front of them
- They’ve had to make the transition psychologically from, “Going home to my family,” to, “I’m going to die in a few minutes.”
  - They had to make that transition almost instantaneously
- They’re tied to posts, and the order is given for the soldiers to charge their weapons and level them and aim
- And Dostoevsky and his buddies are waiting for the command, “*Fire*,” when their chest would be torn open by musket balls
- What happened was this was theater (sadistic, cruel theater)
  - It was a mock execution just to scare them
- And a rider galloped into the square just in time and said, “*The czar forgives them.*”
- And they were untied and sent to a penal colony in Siberia for a while, but they survived
- 2 of the 6 men who went through this were insane for the rest of their lives
  - They could not bear the thought of afterlife
  - The unfiltered vision of infinity, starting 30 seconds from now, without any warm up, without any time to adjust
  - Just from life to death in some minutes was so psychologically traumatizing that they were deranged for the rest of their lives
    - They never psychologically recovered

*Dostoevsky recovered, and he took that experience and put it into some of this amazing work*

- What we know because of him, we know what the nearly hallucinatory quality that reality takes on when you do this transition abruptly from, “*I’m alive, yay,*” to, “*Oh my God, I’m going to be dead in a minute.*”

*What does the world look like through the eyes of someone who’s experiencing that?*

- He said he looked out and he saw sunlight glinting off the roof
  - The steeple of a church
  - And he thought to himself, “*In moments, I’ll be part of the sunlight. I’m going to become part of all things. And if I somehow survive this, I’ll live the rest of my life turning every moment into an infinity*.”
- And he did survive it
- And he took the wisdom of that vision…

***Which of course, if we just stopped, erased the busy slates of our brains and just stopped and looked around at just the insane, surreal miracle that anything is, the New York City subway, a tree, the ocean, your foot, whatever, I mean, just look at any of it, you’ll be like, “Oh my God, that exists and I’m here to see it? Are you kidding?”***

- That was what he got

***If you can incorporate a little bit of that, the strangeness of that vision allows for awe and gratitude***

- And when you become accustomed to it, when it becomes an everyday thing
  - It’s a problem with long marriages sometimes, right? You’re just like, “*Oh yeah…*”
    - You fall in love
    - This person’s amazing, and then you adjust, and they’re just another person
    - And you love them or whatever, but the sort of awe that this person is with you, if you can keep that in your marriage, you have a good marriage
- If you can keep that “awe” in your life, you have a good life
- And that was the blessing that came with the curse of what Dostoevsky went through

**Sebastian has gotten a little bit of that in his life, and it changed his life in a way that religion often changes people’s lives**

- He’s not religious
- It’s changed it in an equivalent way, in a profound gratitude, not just for my life as he’s living it, but the fact that he has a life at all and that any of us do

**Would you go through all of this again?**

- Yes he would
- As painful as it is to say
- Sebastian wonders if Dostoevsky would
  - He’s  guessing he would
  - And those poor guys who never recovered, they wouldn’t
- Sebastian had access to a really good shrink, a very loving family
- It was touch and go for a while
- He still has a sort of weird panic, anxiety disorder around health issues, and he’s prone to imagining that something’s catastrophically wrong with him
- That paranoid feeling comes flooding into him, and it’s a direct result of almost dying on a beautiful June day
- So it’s not without its costs, but because he’s blessed to have some incredibly wonderful, beautiful things going for him in his life, he was able to pull it off

**Peter’s takeaway from the book**

- The book is really, really special
- If you’re willing as the reader to let yourself really contemplate and imagine what’s being described and accept the impossibility of being able to understand it and being able to resolve it and being able to find it proof, it certainly offers more questions than answers
  - That’s what makes it worth living, right?

§

## Selected Links / Related Material

**Episode of** ***The Drive*** **with Sebastian**: [#195 – Freedom, PTSD, war, and life through an evolutionary lens | Sebastian Junger](https://peterattiamd.com/sebastianjunger/) (February 14, 2022) | [1:00, 6:30, 1:08:45]

**Sebastian’s latest book**: [In My Time of Dying: How I Came Face to Face with the Idea of an Afterlife](https://www.amazon.com/My-Time-Dying-Came-Afterlife/dp/1668050838/ref=sr_1_1?crid=HFHN8EVWHUMY&dib=eyJ2IjoiMSJ9.BoTYIvwbTa2HEQjJOvD6339_ZkhPtYy1ue36N2POECrE1Wvr9QNQM5RGJQxPGtS1-vzIqtd2ubwYUIuG56-pBqkBiwGqChftA1ooxxTJsZTpVLtUcia2sE21NMUYLsktkivWK9x7C8CXhLOUEHwIRLq5gMJ8pJAlVPQA22NqlsMTRq4S9uismmJXw__Xuah368B8a0H8P554J55NZ7rqcHIkW7SZaLkl64MYT1WH6zA.eh5sTUy4sxUE0-87_OgRRhVFENlN5DepSWexpN8bHTs&dib_tag=se&keywords=sebastian+junger+in+my+time+of+dying&qid=1719585279&sprefix=sebastian+Junger+%2Caps%2C99&sr=8-1) by Sebastian Junger (2024) | [1:00, 3:15, 1:26:00, 1:40:45]

**Other books written by Sebastian**: [1:15]

- [The Perfect Storm: A True Story of Men Against the Sea](https://www.amazon.com/Perfect-Storm-True-Story-Against/dp/039304016X/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9._rJvN4QGhryqwvkXKWr-Dn0kwr8RL0cvXiDM970qRzTqxMerJDTkkXYVhnKNFbnJYv5owWC9je3aV4C0YM3fCLJHt88Kb5VGlwkvfdZSkOLZ8UhKMRLunCGkir-sgp4ZbO8jx9cgIbTf3wSGyi9DjOzC7tuMFWAmEW9SeQI7HeNxLYme2QovVlPrRmWPuzq7_xl7wX4m7h2ISjRGng1YBsX9-yHH3TWH_Ypukhie1qg.GjoTz7itAsCMv3wf0_GFRQAc7DNqC9ySLbCUGSWiyAU&qid=1720440203&sr=8-4) by Sebastian Junger (1997)
- [Tribe: On Homecoming and Belonging](https://www.amazon.com/Tribe-Homecoming-Belonging-Sebastian-Junger/dp/1455566381/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9._rJvN4QGhryqwvkXKWr-Dn0kwr8RL0cvXiDM970qRzTqxMerJDTkkXYVhnKNFbnJYv5owWC9je3aV4C0YM3fCLJHt88Kb5VGlwkvfdZSkOLZ8UhKMRLunCGkir-sgp4ZbO8jx9cgIbTf3wSGyi9DjOzC7tuMFWAmEW9SeQI7HeNxLYme2QovVlPrRmWPuzq7_xl7wX4m7h2ISjRGng1YBsX9-yHH3TWH_Ypukhie1qg.GjoTz7itAsCMv3wf0_GFRQAc7DNqC9ySLbCUGSWiyAU&qid=1720440285&sr=8-2) by Sebastian Junger (2016)
- [Freedom](https://www.amazon.com/Freedom-Sebastian-Junger/dp/1982153415/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9._rJvN4QGhryqwvkXKWr-Dn0kwr8RL0cvXiDM970qRzTqxMerJDTkkXYVhnKNFbnJYv5owWC9je3aV4C0YM3fCLJHt88Kb5VGlwkvfdZSkOLZ8UhKMRLunCGkir-sgp4ZbO8jx9cgIbTf3wSGyi9DjOzC7tuMFWAmEW9SeQI7HeNxLYme2QovVlPrRmWPuzq7_xl7wX4m7h2ISjRGng1YBsX9-yHH3TWH_Ypukhie1qg.GjoTz7itAsCMv3wf0_GFRQAc7DNqC9ySLbCUGSWiyAU&qid=1720440285&sr=8-5) by Sebastian Junger (2021)

**Book written by a paramedic**: [A Thousand Naked Strangers: A Paramedic’s Wild Ride to the Edge and Back](https://www.amazon.com/Thousand-Naked-Strangers-Paramedics-Wild/dp/1501110837/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.m8tzQ4uD_ZEg69mFBjF7I_mWkOQLHGjv6pn-2KpTkV-p_sIk7GNfmmBNq50vzBmF_umwTDd3lbBuM13XGqRHItQSSsyQeqg9_K0QFh07md-vltkzUpCGJBLiOfDurq6HrCCmBGeUqFr1G8D4RQpx9-jwlZkDtYK1m39IJeRGurGSXwpR_5tqS7TqFMNCY6zjhSFZXNrhDwClLPPqUg4mG1OSeUXF-ZLLUkO-lyj4K3w.7uRhouAvbT5KMCnGAzzJVL8GViT0lJHjuDadkzLKMXI&qid=1719852352&sr=8-1) by Kevin Hazzard (2016)| [36:30]

**Episodes of** ***The Drive*** **with Ric Elias**: [51:30]

- [#79 – Ric Elias: Earning the gift of life](https://peterattiamd.com/ricelias/) (November 11, 2019)
- [#241 ‒ Living intentionally, valuing time, prioritizing relationships, and more keys to a rich life | Ric Elias (Part 2)](https://peterattiamd.com/ricelias2/) (February 6, 2023)

§

## People Mentioned

- [Edward (Eddie) Cornwell III](https://www.encyclopedia.com/education/news-wires-white-papers-and-books/cornwell-edward-e-iii) (one of  the top trauma surgeons in the US) [12:15]

- [Phil Dombrowski](https://physicians.capecodhealth.org/ma/hyannis/27-park-street-dombrowski.html) (Sebastian’s doctor, specialized in interventional radiology in Cape Cod, MA) [26:30, 36:30]

- [Werner Forssmann](https://en.wikipedia.org/wiki/Werner_Forssmann) (invented the venous catheter) [32:15]
- [Ric Elias](https://www.ted.com/speakers/ric_elias) (Peter’s friend and previous podcast guest who survived US Airways flight 1549; CEO and cofounder of Red Ventures, a portfolio of fast-growing digital businesses) [51:30]
- [Sully Sullenberger](https://en.wikipedia.org/wiki/Sully_Sullenberger) (Airline captain who successfully landed US Airways flight 1549 in the Hudson River, January 2009) [51:45]
- [Erwin Schrödinger](https://en.wikipedia.org/wiki/Erwin_Schr%C3%B6dinger) (1887-1961, Nobel Prize-winning physicists who coined the term “quantum entanglement”) [1:47:30]
- [Arthur Eddington](https://en.wikipedia.org/wiki/Arthur_Eddington#) (1882-1944, English astronomer, physicist, and mathematician) [1:35:15]
- [Fyodor Dostoevsky](https://en.wikipedia.org/wiki/Fyodor_Dostoevsky) (1821-1881, Russian novelist and journalist who focused on the human condition in 19th-century Russia) [1:53:30]

§

![](https://peterattiamd.com/wp-content/uploads/2022/02/bio-junger.jpeg)

##### Sebastian Junger

Sebastian Junger is the #1 *New York Times* Bestselling author of *The Perfect Storm, Fire, A Death in Belmont, War, Tribe, Freedom*, and most recently, *In My Time of Dying: How I Came Face to Face with the Idea of an Afterlife.* As an award-winning journalist, a contributing editor to *Vanity Fair,* and a special correspondent at *ABC News*, he has covered major international news stories around the world, and has received both a National Magazine Award and a Peabody Award. Junger has also written for magazines including *Harper’s*, *The New York Times Magazine*, *National Geographic Adventure*, *Outside* and *Men’s Journal*. His reporting on Afghanistan in 2000, profiling Northern Alliance leader Ahmed Shah Massoud, who was assassinated just days before 9/11, became the subject of the National Geographic documentary *Into the Forbidden Zone*, and introduced America to the Afghan resistance fighting the Taliban.

Junger is also a documentary filmmaker whose debut film *Restrepo*, a feature-length documentary (co-directed with Tim Hetherington), was nominated for an Academy Award and won the Grand Jury Prize at Sundance. Junger has since produced and directed three additional documentaries about war and its aftermath. [[sebastianjunger.com](http://www.sebastianjunger.com/about)]