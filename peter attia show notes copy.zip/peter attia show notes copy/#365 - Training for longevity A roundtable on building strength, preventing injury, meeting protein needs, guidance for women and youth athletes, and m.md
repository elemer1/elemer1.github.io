# 365 ‒ Training for longevity: A roundtable on building strength, preventing injury, meeting protein needs, guidance for women and youth athletes, and more | Gabrielle Lyon, Mike Boyle, Jeff Cavaliere

**Source:** [https://peterattiamd.com/trainingforlongevity/](https://peterattiamd.com/trainingforlongevity/)

---

In this special episode of The Drive, Peter hosts a strength and conditioning roundtable with three experts in the field—Gabrielle Lyon, Jeff Cavaliere, and Mike Boyle. Together they explore why maintaining muscle mass, strength, and power is essential for healthspan and longevity, and examine how resistance training supports metabolic resilience and injury prevention across the lifespan. The conversation covers practical strategies for getting started and staying consistent, the importance of a protein-centered diet tailored to age and activity level, and approaches to resistance training for peri- and post-menopausal women—including tendon care and optimal programming. They debate single-leg training versus heavy bilateral lifts, share knee-friendly lower-body options, and highlight exercises that belong in the “graveyard” due to poor risk-reward ratios. Finally, the group discusses youth sports specialization, emphasizing the long-term value of variety for developing lifelong athletes.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/trainingforlongevity/the_Drive_public.png)

Play

#365 ‒ Training for longevity: A roundtable on building strength, preventing injury, meeting protein needs, guidance for women and youth athletes, and more | Gabrielle Lyon, Mike Boyle, Jeff Cavaliere

#365 ‒ Training for longevity: A roundtable on building strength, preventing injury, meeting protein needs, guidance for women and youth athletes, and more | Gabrielle Lyon, Mike Boyle, Jeff Cavaliere

1x15s30s

0:002:15:29

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- Personal career journeys and philosophies of each guest that shaped their approaches to strength, conditioning, and lifelong health [A: 3:30, V: 1:17];
- Why so few people engage in resistance training despite its proven health benefits [A: 8:30, V: 6:58];
- Mike’s low-stress, high-consistency method for training beginners to resistance training [A: 18:45, V: 18:06];
- How resistance training enhances metabolic health and body composition even in lean, highly active endurance athletes [A: 25:30, V: 26:16];
- The dominant role of nutrition in shaping physique and achieving low body fat, the synergistic effect of resistance training, and the unrealistic expectations about muscle growth and fat loss [A: 28:30, V: 29:45];
- Why Jeff advocates for five meals a day, and why meal timing matters less than overall protein intake and caloric consistency [A: 38:00, V: 40:25];
- Optimizing protein for every stage of life: quality, quantity, and guidelines for diverse diets and body types [A: 44:15, V: 47:33];
- The advantages of unilateral lower-body training over heavy bilateral lifts: impact on strength, athleticism, recovery, and functional movement [A: 51:45, V: 56:05];
- Rethinking heavy squats and deadlifts: risk-reward, aging bodies, and the case for reverse lunges and other single-leg alternatives [A:1:01:15, V: 1:06:59];
- Adapting with age: Gabrielle on injuries, hip dysplasia, and the shift to smarter training [A: 1:10:15, V: 1:17:56];
- Exercises that belong in the “iron graveyard”: unnecessarily risky exercises and their safer alternatives [A: 1:19:15, V: 1:27:28];
- The downside of early sports specialization in children and the long-term benefits of encouraging kids to play multiple sports [A: 1:25:00, V: 1:34:03];
- Advice for preventing an Achilles injury: calf strength, ankle mobility, and listening to pain signals [A: 1:33:15, V: 1:43:42];
- Shoulder pain: how to keep training the upper body when shoulder pain limits pressing movements [A: 1:40:45, V: 1:52:45];
- Effective strength training strategies for women before, during, and after the menopausal transition [A: 1:43:15, V: 1:55:35];
- Best practices for strength training and athletic development in children, and the pitfalls of early sports specialization [A: 1:50:30, V: 2:03:41];
- How to foster healthy habits and an interest in fitness beyond playing sports [A: 2:00:00, V: 2:14:32];
- Something each guest has changed their mind about in the last five years [A: 2:04:00, V: 2:19:12]; and
- More.

---

## Show Notes

\***Notes from intro**:

- This is special episode of *The Drive*, a roundtable conversation devoted to strength and conditioning with the following guests:
- Dr. Gabrielle Lyon ‒ a fellowship trained physician in geriatrics and nutritional sciences, founder of [Muscle-Centric Medicine®](https://drgabriellelyon.com/muscle-centric-medicine/) and author of *The New York Times* bestseller [*Forever Strong*](https://www.amazon.com/Forever-Strong-Science-Based-Strategy-Aging/dp/1668007878/ref=sr_1_1?crid=2XSB91ARHLOAN&dib=eyJ2IjoiMSJ9.tk-qlP5uJdIuh4JEA6MRnqeZW324Hx_wlgqJjqTYX2nXYYu8CYYGF-CBSJAXvEnilNMh7vzrBe4rAZPvWZYih8kVPrm9TBbsiARO430xJx7HGLRLRVPjQ2RZrsp171BgkvA-TK7AOI4coVljFJ-zj9I3Xp4su0MBNEelc8fOJbi92DINer9YdErwl2R4MCyA6JI1Qmp_yVujFzBO7EwGYLttZVEotWrRHmWnst0MGm4.X7DNm71Os0HwDZIVRc_SvEgRq-RADS02B-Rn2rI9ytQ&dib_tag=se&keywords=forever+strong&qid=1754337180&sprefix=forever+strong%2Caps%2C116&sr=8-1)
  - She runs a clinical practice in Houston and continues to publish research on skeletal muscle health and metabolism
- Jeff Cavaliere ‒ a physical therapist and former head strength coach and physical therapist for the New York Mets who parlayed that experience into his incredibly popular [YouTube channel](https://www.youtube.com/@athleanx)
  - Using an injury smart approach to make athletic training accessible to millions
- Mike Boyle ‒ a pioneering strength and conditioning coach, now in his 43rd year
  - He popularized NFL Combine training in the 1980s and spent the 1990s with the Boston Bruins
  - He opened the first for-profit strength and conditioning facilities in the US
  - He was also part of one of the Boston Red Sox championship winning team

In this episode, we discuss

- The critical importance of strength training for longevity
- How muscle mass, strength, and power protect healthspan as we age
- The participation gap in strength training, and why closing it is crucial for lifelong health
- More on strength training regarding
  - Injury prevention
  - Metabolic resilience
  - The barriers that keep most people from getting started and staying consistent
- The importance of building a protein-centered diet
  - How age, activity, and metabolic health drive how much protein and carbohydrate each individual really needs
- Resistance training across both peri- and post-menopause
  - Including tendon care strategies
  - Why good programming matters
- Single-leg training versus heavy back squats and deadlifts
  - The risk-reward calculus that led Mike to swap most bilateral lifts for unilateral work
  - Reverse lunge mechanics and other knee-friendly lower body substitutes that still let you load heavy and grow stronger
- The “exercise graveyard” ‒ why unsupported chest flies, Cuban presses, and other classics may be more risk than reward
  - And what you should be doing instead
- Early sports specialization myth for kids and why variety in sports at a young age is still valuable and necessary to becoming a lifelong athlete

## Personal career journeys and philosophies of each guest that shaped their approaches to strength, conditioning, and lifelong health [A: 3:30, V: 1:17]

- This is our second version of a roundtable
- [The first one focused on longevity, [episode #333](https://peterattiamd.com/longevityroundtable/)]
- Unlike the first one where Peter had interviewed the 3 guests multiple times, the guests today have never been on the podcast

**The “non-bio” version of who each guest is**

Dr. Gabrielle Lyon

- Gabrielle is a fellowship trained physician in geriatrics and nutritional sciences
- She did her fellowship at WashU, and at the time she was very reluctant to do geriatrics because it can be an arduous and sad experience
- But she was fascinated by the nutritional research side
- There was a moment we were working on a study looking at body composition and brain function and she really took to one of the participants
  - She imaged her brain, and at her mid 50s she looked like the beginning of an Alzheimer’s brain
  - And in that moment, muscle-centric medicine, which is the concept that Gabrielle practiced and founded

**⇒** [Muscle-centric medicine](https://drgabriellelyon.com/muscle-centric-medicine/): skeletal muscle is the focal point of all our health and wellness

- Gabrielle is the author of a *New York Times* bestseller called [*Forever Strong*](https://www.amazon.com/Forever-Strong-Science-Based-Strategy-Aging/dp/1668007878/ref=sr_1_1?crid=2XSB91ARHLOAN&dib=eyJ2IjoiMSJ9.tk-qlP5uJdIuh4JEA6MRnqeZW324Hx_wlgqJjqTYX2nXYYu8CYYGF-CBSJAXvEnilNMh7vzrBe4rAZPvWZYih8kVPrm9TBbsiARO430xJx7HGLRLRVPjQ2RZrsp171BgkvA-TK7AOI4coVljFJ-zj9I3Xp4su0MBNEelc8fOJbi92DINer9YdErwl2R4MCyA6JI1Qmp_yVujFzBO7EwGYLttZVEotWrRHmWnst0MGm4.X7DNm71Os0HwDZIVRc_SvEgRq-RADS02B-Rn2rI9ytQ&dib_tag=se&keywords=forever+strong&qid=1754337180&sprefix=forever+strong%2Caps%2C116&sr=8-1) [the accompanying [playbook](https://www.simonandschuster.com/books/The-Forever-Strong-PLAYBOOK/Gabrielle-Lyon/9781668085622) will be published in 2026]
- She continues to do research and work within the space
- She has a [medical practice](https://drgabriellelyon.com/new-patient-inquiry/) and sees patients
- She just submitted a [paper](https://pubmed.ncbi.nlm.nih.gov/40684267/) on the relationship between sexual function and muscle mass

Michael Boyle

- Mike is a coach, this is his 43rd year coaching
- He was lucky enough to bounce right out of college and into a coaching job
- He started out as an athletic trainer
- He invented training for the [NFL Combine](https://mboyle1959.wordpress.com/2016/02/25/) in the ‘80s
- He worked in the NHL for the Boston Bruins from ‘90-’99 while he worked at BU [Boston University]
  - Strength coaches were part-timers at that point in time
  - He worked at BU for 30+ years
- He opened one of the first [for-profit businesses](https://www.bodybyboyle.com/) around strength and conditioning in 1997
- In 2012, he left BU and jumped over to the Red Soc for 2 years, where he was able to get a world series ring in 2 years
- He realized that was not very conductive with being a good father, a good husband ‒ so he left pro sports
- Currently, he coaches his son and his friends who play college lacrosse
- He still works as a personal trainer and as a strength conditioning coach
- More than anything, he’s a practitioner
- He sees patients that range from age 11 to 80
  - He doesn’t take kids until they are 11 because we really don’t want the min the gym before that
  - His oldest client right now is 89 ‒ that’s his son’s pediatrician
  - He has a couple of 3 generation families all training in the same space

Jeff Cavaliere

- Jeff is a physical therapist by trade
- He moved out of the clinic at an early stage, got a great opportunity to work in that role for the New York Mets
  - Which was a dream come true for him because he was a die-hard Met fan growing up
- From there, he piggybacked into how could he continue this education of athletes on a broader platform
- He was well aware of the power of the internet at that time, so he started a [YouTube channel](https://www.youtube.com/@athleanx)
- Now it’s not just about training athletes and empowering athletes, but [empowering people](https://athleanx.com/?srsltid=AfmBOoq9zKx7P0iHogOKOjP73MABKH7omQm4LuLzNZtTcslE3ge_lYdM) who want to be more athletic, feel more athletic, move more athletically in daily life
  - That became his mission
- Beyond having to maintain a certain level of consistency (because he wants to practice what he preaches), he has two young boys (twins)
  - He started late; he’s 40
  - He wants to make sure he can keep up with them when they’re ready to have him run and play
- He has a lot of motivation to keep doing what he’s doing and stay in shape
- He believes that requires having an understanding of injury, training around injuries
  - Because no matter what, as we get older, things do start to break down and you have to have strategies to be able to push through that and train around that
- And that’s where his big strength is as a PT to provide that background to help people do that more readily

## Why so few people engage in resistance training despite its proven health benefits [A: 8:30, V: 6:58]

**Do we have a sense of what percentage of people in the United States do not practice resistance training?**

Gabrielle Lyon

- We know that 50% of Americans are not training or doing any kind of exercise
- Probably 70% in total do not meet the criteria for both activities

Mike Boyle

- It’s lower than 30% when you’re talking about resistance training
- 20% of people belong to a gym
- Home gym stats aren’t very good in terms of people

> “*The home gym person who actually has one and uses it is probably more unicorn than we think they are.*”‒ Mike Boyle

- If you start looking at that number: 20% have a membership, 50% of those people use it

***Which now brings us down to only 10% of people in the United States are actually in a gym***

- Then you look at that and say what percentage of them are resistance training?
- Maybe now we’re down to 5% because you see a lot more hamster wheel people who are just walking on a treadmill or walking on a stair climber or whatever it is

***Mike thinks the numbers of people resistance training are pretty low (maybe 5%)***

Jeff Cavaliere

- We have digital statistics that actually show people who have signed up to [train with our programs](https://athleanx.com/ax-training-system), let’s say either be at home or at the gym

***The percentage of people that make it through our programs is only 20%***

- And that’s twice the industry standard for digital (which is usually 10% or so)
  - Those are people who showed the commitment, made a purchase, put their hard-earned dollars behind it, have everything they need in terms of the tools and sets and reps and what’s supposed to be done and only 10% will finish a program

> “*I think there’s a lot more of a desire to do things, but the ability to actually follow through is where, I think, we’re having the hardest time*.”‒ Jeff Cavaliere

Peter points out

- Gabrielle’s stat is 70% of 50
- The reciprocal of that is 30% of 50 (or 15%)
- Peter has never been shy about his thesis, which is of all the pillars that we have to embark on improving our health, whether it be changing our nutrition, improving our sleep, taking the medications and supplements, that can be actually quite important

***Peter doesn’t see any evidence that anything trumps exercise***

- Purely from an actual lifespan perspective and from the standpoint of reducing the risk of chronic disease
- When you then layer in the benefits it has on quality of life, it’s just a no-brainer

**What do you think explains the disconnect between the fact that we have this incredible tool that will lengthen your life, improve the quality of your life, make you look and feel better, and yet 5%, 10%, at most 15% of people engage in it? What are the barriers?**

*Mike, I’m going to start with you because you’ve been at this the longest*

Mike Boyle

- The biggest barrier is just life
  - Lifestyle, kids, jobs, people thinking
- You really have to commit to [the time to do it}
  - Is it getting there early?
  - Is it going there after work?
  - Whatever it is, it’s adding hours to your day
- In some ways, that’s economic
  - People don’t have the economic freedom to say, “*Hey, I can devote*.”
  - That’s why he laughs sometimes when he hears people talking about hours per week of exercise and hours per week of cardio
  - If he can get someone to do 2 hours a week

***Mike thinks 75 hard minutes a week is a realistic amount of time to spend training***

- But even 150 minutes, some of the guidelines are crazy
- And then there’s a lack of awareness
  - You don’t know you’re losing the battle until it’s too late
- This is what he sees in his business
  - People come in at 50, or thank God they got here now at 55 because the end for them was going to be bad
- Mike has been following Peter for a while, and he’s getting the message out in a way that it hasn’t gotten ot before
- Before the message was geeky or nichey, but it wasn’t this, “*Hey, this is really good for you and this is going to make you live longer and live better. It’s a double bonus.*”
  - You want to live longer, but who wants a long, shitty life?
- Mike and Jeff have talked about this, and Mike has experienced 50 to 65

> “*I’ve experienced 50 to 65 and trust me, it’s not fun. The decline is rapid and the decline is significant*.”‒ Mike Boyle

***If you don’t wake up by the time you’re 50, you’re going to be in real trouble by the time you’re 65***

*Gabrielle, how much of a difference do you see between men and women who are new to resistance training in terms of barriers to entry?*

> “*There’s nothing more important for maintaining health and wellness than taking care of muscle health.*”‒ Gabrielle Lyon

- Whether it’s strength training, mobility resistance ‒  skeletal muscle health is really what we’re talking about

Part of the disconnect from men versus women or people in general is cultural

- We live in a society of comfort
- It’s very easy to take the escalator or take an elevator
- When it comes to nutrition, we all have to eat, but we don’t all have to move
  - You literally could sit at home, order groceries from Amazon Prime everything, and never had to take more than 300 steps
- For women, typically strength and strength training has not been the focus, even just from a standpoint of walking to the gym (you’re starting to see it more)
- Gabrielle feels like we are on the precipice of women recognizing the importance of strength and muscle, especially with new conversations around menopause and more potent conversations
- People are busy
- The other aspect of that is there are self-imposed limitations
  - A woman would look at a 40 pound weight and go, “*I can’t lift that*.”
  - But she would look at her 40 pound toddler and go, “*I’m going to lift that and then I’m going to carry my groceries. I’ve got it*.”

***Gabrielle makes the point, “That’s really where I think that we can change the disconnect is re-educating the importance of muscle and then also changing the cultural conversation.”***

**Peter notices that Gabrielle is really fit. Has resistance training always been something you have enjoyed?**

- She grew up doing it
- By the time she was 5, she was riding 10 miles on a bike
- Yes, she has always trained

> “*With the conversation around children, if we teach them good habits now, then we don’t have to have them spend a lifetime outgrowing old habits*.”‒ Gabrielle Lyon

- Peter is in the same boat (he’s always trained), and he suspects that true for this group

**One of the challenges Peter has when talking to patients who are more representative of the “real world” is that people don’t enjoy the feeling of lifting weights**

- People say it hurts and they don’t like it
- Peter can appreciate the honesty, but he can’t relate
  - It’s hard when you can’t relate to what your patient is saying
- He can relate when they complain about having to watch what they eat because that’s a struggle he has

*Do you think that that’s a function of having started early?*

*Or do you think that there are literally just, just as we have people with different eye colors and different heights, there are truly differences in genetic hard-wiring that would speak to an individual’s appetite for that kind of discomfort?*

Jeff Cavaliere

- Jeff thinks it’s the latter
- There are some people who are more inclined to enjoy that type of stress
- For him, it doesn’t matter how much he runs, he does not enjoy the stress of running
  - He doesn’t enjoy the feeling he gets in his lungs when he’s sucking for air
- He’ll do it because he knows he has to, but there’s no enjoyability about that
- Training hard and lifting weights and pushing himself to the utmost level of effort, that’s always been something he actually enjoys

***Anyone can learn to enjoy training hard and lifting weights, and you can get better at it***

- Just like he can learn the discipline to continue to push and run when he doesn’t want to
- After doing it for a while, when you start to see results, the results actually might become motivating enough to go like, “*Well, there is a trade-off here. I’m seeing the trade-off.*”

***Often what’s stopping people is the perceived level of what they’re going to have to do is usually bigger than what they have to do***

**Jeff has mentioned before that you can build a great body on 6 exercises**

- The [row](https://youtu.be/gfUg6qWohTk?si=2OZLkyQB8imdszK5), squat, deadlift, bench, pullup, curl (done) [demonstrated in the video below]
  - You’ve got everything you need, you don’t have to complicate it

Jeff adds, “*If you keep trying to get stronger at those exercises, now you might get bored to tears, but you can build the prerequisite foundation to get a better body.*”

- Sometimes people want to complicate it in their heads so that they have an easier “out”
  - It makes it easier to say they don’t have time for all that

Jeff’s analogy

- He’s known a few people who’ve wanted to start businesses
- They have this great idea, they’re gung-ho and want to do it, and then they get caught up in, “*I don’t know if I should set up an LLC or if I should do it as a corporation. I want to get my business cards. I can’t figure out my logo.*”

***They’re doing all that stuff and they never actually take the step of actually just starting what their service is going to be (and they never get going)***

People do the same thing in terms of fitness

- They make it bigger and they make the commitment larger so that they can almost have a safe landing spot to be like, “*Yeah, I just couldn’t get it going.*”

> “*It’s our job to educate them as to how simple it [training] can actually be, simple being what you need to do. But I think the commitment to actually showing up and doing it, that’s hard*.”‒ Jeff Cavaliere

## Mike’s low-stress, high-consistency method for training beginners to resistance training [A: 18:45, V: 18:06]

**Mike, what percentage of the people that walk into your gym are coming to resistance training for the first time?**

- Maybe 50% (if he was guessing)
- Some of them were high school athletes and have some basic relationship with strength training

***What percentage of them are approaching intelligent strength training for the first time? 100%***

- People come in and they look at us like, “*What are you doing?*”
- When you were talking about people saying the discomfort, Mike’s first thing would be like, “*What discomfort? There shouldn’t be any discomfort*.”
  - If you come in and start working with him, his whole goal is that you should get out of bed the next day and be like, “*I think I worked out. I felt okay*.”
  - He always tells everybody, “*If you get up in the morning and you’re crippled, I suck. I did a really bad job. You should not be uncomfortable at all.*”

> “*This is slow and steady wins the race, 1% better, however you want to look at it*.”‒ Mike Boyle

**Mike is a big attendance guy**

**⇒** If he can get you to show up 2 days a week for a year, you’ll be remarkably different

- You might not have ever had “balls to the wall” or go to failure
  - We would’ve done none of that. Zero.
  - And yet you would look at somebody and think, wow

Mike adds, “*If you came into our place, everybody looks younger than they do. I am 100% certain not just of the longevity benefit, but about the physical change that people undergo*.”

- He’ll show you people and say, “*Yeah, that guy’s an 80-year-old, two-time cancer survivor*.”
  - People are amazed
  - They all look different, they all look younger
- What is that? Is it hormonal? Mike doesn’t know

***He knows that it works and he knows that it doesn’t have to be hard and it doesn’t have to be uncomfortable***

**Case study #1: a 50-year-old guy who has traded his health for wealth and has recently had a health scare**

- Maybe his blood pressure is really high or there’s something going on
- Maybe he’s just confronted his own mortality: he lost a parent
  - That’s a big “wake-up call” for someone in their 50s
- He played sports in high school, but that was about it
- He doesn’t really do much of anything now and somehow has landed in Mike’s gym
  - Maybe he saw [Jeff on Instagram](https://www.instagram.com/athleanx/?hl=en) and was like, “*That guy looks incredible. I’ve got to do something. What he’s doing sounds cool.*”

*Mike, how do you interview this guy?*

*How do you find out what  his goals are?*

*How do you create that show-up attendance pattern that’s going to make sure he can give you a year of 2 days a week?*

Mike Boyle

- The show-up attendance pattern is a big thing, and  there’s a really good book called [*Never Lose a Customer Again*](https://www.amazon.com/dp/0735220034/?bestFormat=true&k=never%20lose%20a%20customer%20again&ref_=nb_sb_ss_w_scx-ent-pd-bk-d_k0_1_17_de&crid=38WFLJBX02QTB&sprefix=never%20lose%20a%20cust)
- Mike approaches his business much more like a restaurant: [*Unreasonable Hospitality*](https://www.amazon.com/Unreasonable-Hospitality-Remarkable-Giving-People/dp/0593418573/ref=sr_1_1?crid=21GR6A0DLS6W9&dib=eyJ2IjoiMSJ9.CaG7MeqWeyBrb6iCrqmf8DxrtfsWvV4gi-GpaQaAPuzo0P4Evek2fTnFMblc5eIL3gEm-cQeEIM8C0qb2xbO2-qYvSIy3yiOaH3tyDblvuym5dGwiNe4OCgC9s2--ePfdkBOzDK_R_Kf7h1lXRjKhOI72SCwsDfkuiUJjGSg_5Bip7va49tv4RdQQzSw2chmKyYqXo8oWcJiJhjzK8KnB-jJSg-BpcKkPOgTIfIC22Q.NBvJxnV0r_9InQo2b3HPu4TDmkrytwE6c2F37kB_vQ4&dib_tag=se&keywords=unreasonable+Hospitality&qid=1754400466&sprefix=unreasonable+hospitality%2Caps%2C95&sr=8-1) is the Will Guidara book

***Mike trains his coaches (he refer to them coaches more than trainers) way more in the customer service skills because we realize that we want to get the person to come back***

**⇒** That’s the goal: get them to get through the first workout and get them to come back

- We don’t interview people a lot
- Mike doesn’t talk to people about their goals
  - Your goal is to not be the sad sack of shit that you are right now (unfortunately), and we just want to get you going
  - It’s like just get them on the conveyor belt and carry them through
- This is one thing that [CrossFit](https://en.wikipedia.org/wiki/CrossFit) did well: they created a community

***You need to create a community where people feel comfortable***

- One of the problems that Mike had was people would say, “*Oh, I can’t go there. It’s all athletes.*”
  - Because they come in and just from a marketing standpoint, there’s jerseys all over the place and it looks like a place where athletes train, but 65% of our business are people like us
- Just getting them to be comfortable in that environment and getting them to show up again
- We tell everybody, “*If you’ve got new people in your group, you should text them that day and you should text them the next day*.”
  - How was it?
  - How did you feel this morning?
- We’re trying to build a relationship because it’s relationship marketing: know, like, trust
  - All the things that you read about
  - Get them to know you, like you, trust you, want to come back, want to be part of it
  - And then we can take care of the training part

> “*The training part to me is relatively easy. It’s the getting that person to be consistent and to come [to the gym]*.”‒ Mike Boyle

- Mike calls them “check the box” clients

***If you check the box (which means you got to Mike Boyle’s twice this week) you will get better, you will feel better***

**Say a little bit about the programming**

Mike Boyle

- It’s very assembly line-ish
- Mike always talks about the idea that it’s a recipe and not a menu, so no one gets to pick what they want to do
  - You come in, this is how the cake is made, it’s in this order, this is what you get
  - Don’t like it? Go someplace else where they like the meal
    - Go to Planet Fitness, you can make your own cake
  - You want to come here? You do it the way we do it
- Everybody foam rolls, everybody stretches, everybody does their immobility work, everybody does dynamic warm-up, everybody throws medicine balls, everybody does some sort of power training, plyometrics (not really, actually some sort of jump training)
- Then they’ll go and they’ll lift, the lift takes 36 minutes
- And then they’ll go and they’ll do some type of conditioning work
- We’ll start really easy, try to give them something that’s very achievable, don’t get them particularly tired; and then boom, out the door
  - They’re in and out in an hour (door to door)

***36 minutes of that is actual resistance training, but everything that’s leading up to it and on the back of it is clearly training as well***

- For the older client, we always talk about the first 15 minutes is more important
  - Getting people to roll, to stretch, to start to deal with their tissue limitations
  - Because most everybody that comes in has something that hurts (no one comes in healthy)

***Progress is made mostly by advancing weight***

- It’s trying to get them to engage in progressive resistance
- When someone says they’ve been doing 5 lb. dumbbells for the last year, Mike thinks, “*Oh, you only wasted 50 weeks.*”
- He tries to get them to pick up something a little heavier and figures out ways they can do it
  - It could be [isometrics](https://en.wikipedia.org/wiki/Isometric_exercise)
  - It could be [eccentrics](https://en.wikipedia.org/wiki/Eccentric_training)

Mike explains, “*We try to vary it because with our adult clients, we’re in the ‘entertrainment’ business a little bit in terms of we’ve got to keep it interesting*.”

- You can do 6 exercises, but we have to figure out, are there 14 different versions of those 6 exercises that we can do to keep somebody not thinking they’re doing the same thing over and over again?
- If we get one complaint, it might be that we do the same exercises a lot
  - It’s because we do the good ones

**Mike, are there any things that are off limits?**

***Our adults don’t touch a barbell***

- They don’t barbell bench press, they don’t barbell deadlift, they don’t barbell squat
- No one squats anyway, that’s another whole conversation
- Almost all of our lower body stuff is [unilateral](https://youtu.be/X-VbgTuRohI?si=VhfiS84ZeV3BkZjb)
  - We’ll do [goblet squats](https://youtu.be/tS9y8s39_fM?si=_aMcQs-kTkUSZ4HT), basic stuff with people that are really de-conditioned because we need them to be capable with two legs before they’re going to be capable on one leg
- We’re really smart and really safe
  - That’s what you want to be if you want to keep people coming back

Mike adds, “*You can be really smart and not be really safe, and you can be really safe and not be really good, and the mid-ground is where we want to operate.*”

## How resistance training enhances metabolic health and body composition even in lean, highly active endurance athletes [A: 25:30, V: 26:16]

**Gabrielle, what’s the biggest thing you’re thinking about when a patient is in your practice and they’re coming along well on many of the other lifestyle adjustments?**

**Case-study #2: a female life-long cardio rat who loves to run**

- They run 2 marathons a year, they’ve been running forever
- They’ve got some nagging injuries
- Especially for female runners, the probability that her proximal hamstring isn’t torn up is pretty low
  - Especially if she’s had kids, now her pelvis is tilted a little bit
- She’s lean and doesn’t need to lose weight

*How are you making the case to her that this muscle-centric approach matters?*

- She’s going to want to be active her whole life and the more healthy her skeletal muscle mass is…
- There seems to be somewhat of a disconnect, people talk about strength and then disassociate it from mass
- Gabrielle has patients like this in the practice that are very lean, have always been runners, but we’ll see their glucose creep up
  - We will see an increase in visceral fat

**⇒** Increased blood glucose levels and increased visceral fat can be course corrected by addressing skeletal muscle mass

- Gabrielle is thinking about one patient in particular: she’s around 60, she runs 100 miles (she’s an ultra)
  - Her body composition was not nearly as good as it is now just by adding in 2 days a week of resistance training
  - We added in 2 days a week, we pulled back on some of the mileage
  - She’s able to move more weight; she is incredible
  - By pulling back her training and increasing her weights and being very specific about, by changing up the movement patterns, she was able to really increase her lower body strength
    - Obviously Gabrielle doesn’t program, but she works with coaches that program,
  - She also improved her labs: fasting insulin, glucose, and triglycerides

**Do you think that improvement in her labs is purely a function of having a larger reservoir to put the glucose into?**

*Or do you think that it also speaks to the insulin sensitivity?*

*Does it even make sense to try to disentangle those two?*

Gabrielle thinks the larger reservoir is important for a number of reasons

- The metabolic component of muscle: muscle is a primary site for glucose metabolism and metabolism of free fatty acids at rest
- It enables her to have more dietary flexibility

***We think about nutritional sciences and we think about triglycerides, insulin, glucose, what we’re really looking at is the health of skeletal muscle***

- The markers of [metabolic syndrome](https://en.wikipedia.org/wiki/Metabolic_syndrome) are the markers of healthy skeletal muscle
- Does her activity improve insulin sensitivity?
  - Yes, but her running, she’s going to be very insulin sensitive as is

***It’s really that metabolic component of having healthy skeletal muscle mass***

## The dominant role of nutrition in shaping physique and achieving low body fat, the synergistic effect of resistance training, and the unrealistic expectations about muscle growth and fat loss [A: 28:30, V: 29:45]

**Jeff, you’re working with people a lot of times at the opposite end of the spectrum. People are coming to you often because they want to have 7% body fat**

Jeff Cavaliere

- Maybe they’re an actor and they’re about to do a role where they have to look a certain way
- Alternatively, it might be an athlete who probably doesn’t need to be at 7% body fat, but might want to be at 7% body fat

*Is it safe to say that these people that are coming to you are so long on motivation that that’s not really an issue anymore?*

- When your goals start to become 7% body fat, Jeff is assuming that you’re probably not 35 or 40 [% body fat] with aspirations to be 7%
- These guys are usually coming in 12%, 13%, 14%, 15% body fat desires to want to get leaner for whatever reasons
- Jeff always tell the athletes they have to be very conscientious of not falling in love with what they see in the mirror because ultimately they’re not getting paid to look that way
  - Unless they are, sometimes he works with WWE athletes who do get paid to look a certain way and perform at a certain level

***These people are usually pretty good at being able to dial in; they’ve oftentimes done this multiple times before too***

- So they’ve done this and had a history of being able to get down there
- They just don’t have ability to sustain it

**⇒** 7% body fat is always going to be achieved through nutritional consistency; it has nothing to do with training

- The level that you’re able to get down to is just a reflection of how many sacrifices you’re willing to make
- You want to still drink a couple of times a week? That’s fine, you’re going to have to bump it up a notch or two
- Because you really need to be able to make some cuts
- Jeff doesn’t do it himself
  - He does not make sacrifices to the point where he’s eating boiled chicken and steamed broccoli
- He eats meals that are good meals (a meal that anybody can eat)
- But he’s very disciplined in not straying from those meals
- Your ability to stay that way is going to determine how low you’re able to get and how low you’re able to stay

> “*I always say, if you’re eating, let’s say, 5 times a day and that’s a 7-day week, it’s 35 meals. If you could stay 90% or above, you don’t have to be perfect.*”‒ Jeff Cavaliere

**⇒** If you could stay 90% or above on those meals, you’re looking at 3 meals in a week that aren’t perfect

- He’s not saying go hog wild and go down to Buffalo Wild Wings and start eating everything you can
- They just aren’t perfect meals
- Your body almost completely ignores those [imperfect, “cheat” meals]
  - It just overlooks it, you keep going and the consistency overrides that and you’re able to get to levels that you weren’t able to achieve before

But people can’t sustain it because

- Either they make it too difficult or it is actually difficult
- Because getting yourself to the gym for 1 hour, 5 times a week (2 times a week, whatever that might be, even 36 minutes), that’s one level of commitment

***It’s what you do in the other 23 hours of the day that determines your look because that is the nutritional responsibility that a lot of us don’t have the ability to manage well***

**Do you think the average person appreciates the role of nutrition in how you look? Or do you think most of them assume that person must be spending 12 hours a week lifting weights?**

Jeff Cavaliere

- This is a sore spot for him
- People always think exercise first
- To the point where he has people that will say to him if they see his abs or something, they’ll say, “*Oh, what exercise did you do for that?*”
  - And they pat there, usually it’s a big belly that they’re patting
- It’s not an exercise, it’s more pushing yourself away from the table

***No, people don’t have an appreciation for it at all; their instinct tells them it’s just exercise***

Gabrielle Lyon

- Gabrielle totally agrees

**⇒** The data supports the synergistic effect of resistance training activity and a calorie-controlled diet

- Which people could connect the dots that ***it is not simply training***

- But to be fair, training is the most potent stimulus to muscle
- What do they say? “*You cannot out-train a bad diet*.” That’s true
  - Peter feels like you could when you were 14

When Peter was 14

- He was running 14, 15 miles every morning before his workouts
- All he did was eat, but it was like a garbage disposal
  - Breakfast was a box of Froot Loops in a large Tupperware bowl (you could put the whole box in the bowl)
- But something changes when you’re 20 and you can’t do that anymore

Gabrielle explains, “*When you’re 13 and younger, you’re very anabolic. The balance between what drives muscle changes as we age*.”

- When you’re young, you’re very driven by insulin
- For example, Gabrielle’s daughter who is 5, she could have 5 grams of protein, she doesn’t need to have a meal threshold of 30 to get an anabolic response
  - Because when you are younger and you are still growing, you’re very anabolic

***After you are done growing, you want to shift from the insulin usage to the stimulus, which now exercise becomes much more important***

Mike Boyle

- Mike thinks about it in a simpler sense

We go from being extremely active to extremely sedentary

- Suddenly you get into your 20s and you get a job and you’re commuting and maybe you might be sitting on your ass for 10 hours a day every day
- And then you might go to a bar with your friends after
- He doesn’t think people sense the shift

Mike explains, “*I think our problem is that the shift is happening and then people don’t pick up on it until it’s too late*.”

- Suddenly, you look down at yourself and think, oh my God, what happened? I gained 40 pounds and I’m in horrible shape and I’m completely sedentary
- Then they think, oh, I have to do something about this
- But then they tend to revert back to whatever information they might’ve had
  - Think about what your relationship was with exercise in high school
  - If you’re not an athlete,, you have a terrible relationship with exercise in high school because it’s something that you’re made to do (it’s not fun)
  - You probably don’t understand strength training
- Mike recalls a great presentation where someone said, “*I’m going to bring in the most important person in fitness.*” And they brought in a woman who was a member and had her do a half hour talk
  - She talked about just having the money to join the gym
  - Learning how to train by following a pretty girl who seemed to know all the machines
    - She would stay 2 machines behind her so the girl didn’t realize she was following her
    - She would do what the girl did
- Mike realized this is how people were learning

> “*We all learned to exercise, somewhere along the way somebody created that initial imprint on us. And most people’s initial imprint is really bad.*”‒ Mike Boyle

- Mike recalls that what he learned to do in his teens was just moronic in terms of the way he would look at it now (and he tells everybody this)

> “*I’ve done everything conceivably wrong that you can do, and I have all the orthopedic maladies to show for it.*”‒ Mike Boyle

**Do you guys have nutritionists in your business that also help people when also trying to lose weight in addition to improved strength and other metrics?**

Mike Boyle

- He’s tried a whole bunch of different ideas and none of them have ever really stuck
- He has another one ongoing right now
  - One of the guys that works for him is trying nutritional consults

***Mike has never found a nutritional approach that a lot of people would do***

- We deal in the most basic nutritional information that we can
  - Hydrate better
  - Eat more protein
- He still has people who ask, “*What’s a protein?*” (adults who don’t understand)

Sometimes we’re “up here” and our consumer (even our intelligent consumer) is way “down here” with these incredible disconnects, misconceptions

- Women will say, “*Well, I don’t want to start lifting because I don’t want to get too big*”
  - He’s like, “*Trust me buddy. That’s not what we’re worried about right now.*”
  - Gabrelle adds that she’s still trying to get big and she’s 110 lbs. and she’s killing herself in the gym to build muscle

***It’s not easy for anybody to build muscle***

- It’s not easy to do for males ‒ we see too much steroid use and then we seek too much responders
- If you look at NFL guys, there’s people that are a way higher responder level than other people,
- When Mike was a kid coming up, he was looking at people taking drugs, but he didn’t know they were taking drugs
  - He thought, “*I could look like*…”

He remembers he’d go to bodybuilding shows, looking at [Boyer Coe](https://www.greatestphysiques.com/male-physiques/boyer-coe/) [shown below] and thinking, “*I can look like that, and* [*Frank Zane*](https://en.wikipedia.org/wiki/Frank_Zane)*. I can look like that.*”

![](https://peterattiamd.com/wp-content/uploads/2025/09/f1a-647x1024.jpg)

**Figure 1. Professional bodybuilder Boyer Coe**. Image credit: [Greatest Physiques](https://www.greatestphysiques.com/male-physiques/boyer-coe/)

- And then suddenly in his 20s realizing that these guys were taking drugs and that was why they looked like that
- But he spent years frustrated: “*Why don’t I look that good? I’m doing all the right stuff.*”
- It’s good to try to get people to see the reality

## Why Jeff advocates for five meals a day, and why meal timing matters less than overall protein intake and caloric consistency [A: 38:00, V: 40:25]

**Jeff, you talked a minute ago about 5 meals a day. Double click on that a little bit**

- Peter’s view is that most people think they’re only supposed to have 3 meals a day
  - Or just 1 meal if they’re intermittently fasting
- Jeff knows a lot of people that do intermittent fasting and actually do quite well with that

***People tend to do better with more frequent meals simply because they tend to get hungry throughout the day and they don’t have good management of hunger and portion control***

- They don’t have willpower to wait to that next meal
- If they are hungry in the mid-morning and they have nothing pre-planned or prepared for a snack, they’ll just go into the kitchen at work and start picking and grazing

**⇒** In those grazing snacks is where a lot of the calories throughout the day are consumed, not in those 3 main meals, but in the grazing that happens

- They can’t make it to the next meal

***Jeff has found that it’s been easier to fuel more often (especially from the athletic world), and in the world of the regular individual who wants to be more disciplined with their nutrition, it’s easier to actually program in 2 additional snacks***

**⇒** Nothing big but just snacks in between should still focus and center around a protein

> “*I believe that protein should be the cornerstone of every one of our meals and snacks because we don’t get enough.*”‒ Jeff Cavaliere

- If you ate breakfast at 8 o’clock and then now your next meal is at let’s say 12 or 12:30, when it’s 10 o’clock
  - If you get hungry and you have a snack there, you don’t have to get through 4 hours of willpower (that you don’t have right now) to get to that lunchtime
  - You only have to get through 2 hours and of those 2 hours, you weren’t hungry the whole time anyway, only the last half hour
- So you’re teaching yourself willpower over the course of an hour and a half
- Jeff has actually dropped back a little bit to where he’s not necessarily doing 5 meals in a day now I’ll maybe do 4
  - But he has easy willpower

***A planned snack is enough to keep somebody more metabolically stable until the next meal, and it also starts to teach them the willpower to wait until the next meal***

**Walk me through a day in the life for you**

*Not on a day when you’re here and traveling. So you’re at home, your first meal is what time?*

Jeff Cavaliere

- 7:30 or 8 o’clock
- Usually it’s oatmeal and egg whites
- His pumpkin oatmeal contains walnuts, Splenda brown sugar (or brown sugar if you don’t care about calories), and pumpkin mixed inside with whipped cream on top
  - It tastes good and it’s something he actually enjoys
  - He could never just eat boiled oatmeal for the rest of his life

Peter asks, “*And then egg whites because you’re just trying to cut the calories. You want the protein without the total calorie of the egg?*”

- Yeah
- He keeps frozen egg whites; he doesn’t want to start cracking full eggs
- He’s a little bit simplistic when it comes to his nutrition; he knows what works for him
- Although when he’s at a hotel, he’ll eat the prepared eggs
- He has no problem mixing in 1 or 2 full eggs and thinks people should
- With that, he’ll have either milk or a protein shake
- They’re not small meals

***That will take him through until lunchtime***

Snack #1

- In the past, he would’ve had another small snack
  - Some pretzels, jerky, or something
  - Some protein and then some carbohydrates, and then he’ll go to lunchtime

Lunch

- Jeff’s preferred lunch is a grilled chicken wrap with vegetables and yogurt, and some fruit
- Or he’ll have cereal and yogurt
  - He’s still a cereal addict and we have lots of cereal choices, but he tries not to choose the *Cinnamon Toast Crunch* that his son prefers, and he’ll have something else
- With lunch, he’ll have a protein shake

Peter asks, “*How much protein are you getting in that meal?*”

- His protein shake is 30 g, plus the yogurt (another 8-12 g), and then there’s a little bit in the cereal and more in the milk too

***He gets enough protein from that meal; it’s a little bit less preferential in terms of where the carbs come from***

“*I don’t really get crazy about the carbs, I just try to pick lower sugar carbs.*”‒ Jeff Cavaliere

Snack #2

- The afternoon snack would be the same type of thing as the first snack was
- He likes jerky and some type of crunch food (a handful of pretzels would be easy for him)
- He’ll have another protein shake after he trains
  - He may train at 5:00 or randomly before he finishes up work
  - Most often, he winds up having this shake and then trains late, late at night

Peter notices, “*I think we have an input into the sleep issue*.”

- Jeff could fall asleep right after dinner
- The issue for him is that when he gets home, his kids have been waiting to see him all day, and he makes himself available to them
  - We play, we run, we go in the pool, whatever it might be, and then they go to bed a little bit late
  - We have a busy household (including 4 dogs); it’s a lot to put everybody down, but they go to bed around 9:00, 9:30 P.M.
- When he finally gets to the gym, it could be 10:30 P.M.
- He doesn’t like to train on a full stomach (he hates the feeling), so he’ll opt to have his dinner afterwards
- That means dinner could come at 11:30 P.M., sometimes even 12 o’clock at night
  - That’s not recommended
- But he thinks he could dispel the myth of: don’t eat after 6:00 at all
  - Your body, especially if you’re carrying a good amount of muscle (which is why we want to) can utilize those calories, can utilize that protein, can utilize those carbs throughout the day, whenever they do come in
  - Jeff doesn’t think that just magically eating after 6 P.M. is the death knell to having low body fat
  - That’s not part of his equation

Peter points out, “*It might be impacting your sleep more than anything else. It’s clearly not impacting your fuel partitioning.*”

- Jeff has been blessed to have the ability to hit the pillow and fall asleep within minutes and stay asleep
- He doesn’t sleep very long (5-6 hours), but his quality of sleep is usually very high
  - He doesn’t wake up at all
  - He wakes up when it’s time to wake up in the morning

## Optimizing protein for every stage of life: quality, quantity, and guidelines for diverse diets and body types [A: 44:15, V: 47:33]

**What type of guidance are you giving your patients on protein?**

*Is there any difference between men and women and are you differentiating it based on age?*

Gabrielle Lyon

- Age, yes
- Men and women, no
- When we talk about protein, typically we talk about one thing, but it’s 20 different amino acids, 9 of which are [essential](https://en.wikipedia.org/wiki/Essential_amino_acid)
  - We actually eat for those nine essentials
- There is a lot of nuance around protein in general
- Each of those amino acids do something different; for example:
- [Leucine](https://en.wikipedia.org/wiki/Leucine) is critical for muscle, for muscle protein synthesis
- [Threonine](https://en.wikipedia.org/wiki/Threonine) is important for mucin production in the gut

Why are we eating protein?

- We need about 250 g a day
  - We recycle much of that
  - We don’t eat that
- Maybe 75% of that goes towards visceral tissue for turnover and maintenance
- Maybe 25% of that goes to muscle
- We have to continue to get these essential amino acids so that we can maintain rebuilding and repairing
- Which the efficiency of that changes as we age: anabolic resistance, protein efficiency decreases

**Gabrielle makes 3 important points**

- 1 – One reason why we need dietary protein just to maintain the tissue integrity and the structure
- 2 – Women and men do not need a different amount of protein; it’s is not sex-specific; it’s body weight-specific
- 3 – The minimum amount of protein Gabrielle would ever recommend would be 100 g for men or women

**⇒** If you’re a 150 lb. woman and you’re following the RDA at 0.8 g/kg, that is 45 g of protein or so ‒ that’s not enough

- Part of the failure there is that we have to recognize that protein is different amino acids, and so when we talk about muscle health, ***we need to get enough leucine to support muscle health*** and that is probably the recommendation is 2-3 g a day
  - For optimal health, it’s probably around 8 or 9 g a day

**How do you get folks to think about that because now all of a sudden you get into dramatic differences in terms of protein source**

- Peter doesn’t think we should get into the [PDCAAS](https://en.wikipedia.org/wiki/Protein_digestibility_corrected_amino_acid_score), but it’s important to understand that foods are created differently
  - [[episode #224](https://peterattiamd.com/donlayman/) with Don Layman touched on this briefly after 41:15]
- You can look at an ingredient label of something that says 30 g of protein, but they don’t list out the amino acids
  - They don’t tell you that this one has more leucine or more methionine and this one doesn’t

**⇒** Peter points out certain themes that we know: we know that dairy-derived protein, beef-derived protein, and egg-derived protein seem to have the highest amount of the more important amino acids

*So when you’re saying to that person, “Hey, I want you to eat a minimum of 100 g per day,” does it come with the caveat of assuming you’re getting your protein sources here?*

Gabrielle Lyon

- What you’re pointing out is **protein quality**
- There are plant sources of protein and there are animal sources of protein
- Just from hard, fast biological numbers, we considered a **high quality protein** to be: eggs and dairy, fish, chicken (any of the animal source proteins)

**⇒** The lower quality proteins would come from plants

Gabrielle shares, “*When we educate our patients in the practice, we have them choose, and we really don’t focus on plant proteins as a source of protein. While they do have amino acids, and certainly a combination is wonderful. We like to focus on plant foods for fiber.*”

- Let’s say we take out soy
- We really want to focus on high quality animal source foods because let’s say it makes up 30% of our diet

**⇒** Nearly 100% of our calcium, our bioavailable iron and zinc, and selenium comes from the animal-based foods

We should also talk about nutrient quality

- Whether someone decides to get their protein from plants or animals, it isn’t just about protein
- It is also about those nutrients of concern
  - For women, like bioavailable iron
  - For kids, bioavailable iron
  - Nutrients that primarily come from animal sources

Gabrielle emphasizes, “*I just think are really important, and again, nothing wrong with plant-based proteins, but we eat plants for fiber and phytonutrients.*”

**Presumably you have some patients as I do who are vegetarians and in some cases it’s ethical, religious, whatever the reason is**

*Most vegetarians will at least be able to consume the dairy portion, but if you have someone who’s vegan and who is purely looking at animal sources of protein, how much of an uphill battle is that?*

- The challenge is the carbohydrate consumption
- Gabrielle was listening to what Jeff was saying, and he was absolutely right
  - He was saying that he has maybe 100 g of carbs and he have no problem with it
- For someone like him who is super active, he’s able to dispose of those carbohydrates

**⇒** For a normal person, our **carbohydrate threshold**, if you calculate the disposal from skeletal muscle organ systems, it is not much: it is about 40 grams in a 2-hour period. Anything above, say 40 or 50 grams in a non-exercising adult will result in a robust insulin response

- We do not want that

***We do not want to be utilizing insulin to help support glucose; we want to use activity or have the health of our skeletal muscle be able to balance that***

- What we’re talking about is carbohydrates, and unless you are highly active (like Jeff), then we also have to think about the carb portion of this and designing a diet

**⇒** Typically, for us, we think a lot about a one-to-one ratio of protein to carbs at a meal (depending)

*Peter thinks about that in himself*

- That’s pretty tough
- You have to be pretty deliberate about withholding carbohydrates
- He’s probably eating a gram of protein per pound of body weight, so it’s not like he’s skimping on protein
- Gabrielle points out that he’s metabolically healthy
  - That goes back to this hierarchy of how we determine protein
  - Peter agrees, “*I think you have a longer leash if you’re active*.”

Gabrielle explains, “*When we make protein decisions in the practice when we’re designing a diet, [the hierarchy involves] it’s age, it’s activity, and it’s metabolic health.*”

- If you are metabolically healthy, then you can tolerate [more carbohydrates], there’s no problem
- Carbs aren’t the enemy, but once we find out someone is metabolically unhealthy (which you can see from blood work)
  - You don’t change your protein amount because as you restrict calories, you keep protein the same or higher because you must protect lean tissue and also it’s better
  - We’ve seen this in the data

**Case study #3: a man who is overweight (250 lbs.)**

- Let’s assume you did a [DEXA](https://en.wikipedia.org/wiki/Dual-energy_X-ray_absorptiometry) on this guy (although you don’t need to, you can look at him)
  - This guy is carrying way too much fat
  - The DEXA just gives you some numbers: 40% body fat

*When you’re trying to tell him how much protein to eat, are you doing it based on an ideal body weight or are you doing it based on his 250 lbs. that he’s carrying around?*

Gabrielle Lyon

- His target body weight
- Let’s say you’re targeting him for 16% body fat, her approach would be to calculate how much lean tissue he would have and what would be his ideal body weight at 16% body fat

## The advantages of unilateral lower-body training over heavy bilateral lifts: impact on strength, athleticism, recovery, and functional movement [A: 51:45, V: 56:05]

- Peter wants to pivot and talk about something that Mike brought up earlier
- This speaks to how these round tables get totally messy because he’s not done with nutrition (he’ll come back to it)
- This is a topic of unilateral lower extremity training
  - A topic near and dear to Peter’s heart

Peter provides the context for this

- When Peter grew up, power lifting was one of the things he did on the side
  - It wasn’t a sport
- Boxing was his life
- He was hooked on being in the gym
  - The gym he belonged to was an old man dungeon: 2 stories underground with no windows
  - He didn’t realize how lucky he was at the time, but this happened to be the power lifting epicenter
  - You basically just had a bunch of middle-aged men who were machines
    - Everybody could bench press 2x their body weight, squat 3x their body weight, deadlift 4x their body weight
    - That’s what Peter grew up doing
- Peter was like, “*We bench, we squat, we deadlift, and we do it really, really heavy.*”
- Not surprisingly, over time he started to get injured
  - He injured his back by the time he was in medical school and kind of decided, “*I don’t know if this is worth the risk anymore.*”
  - He didn’t see the need to have 4 plates on his back squatting anymore

***Almost through necessity, Peter had to discover single-leg training***

**I want you [Mike] to say more about that experience, help somebody, because I have patients who really can’t believe that you can achieve optimal lower body hypertrophy without a barbell on your back or without picking a barbell up off the floor**

Mike Boyle

- Mike had the same background as Peter
- He got into competitive power lifting in college
- He was no longer an athlete and he was looking for an outlet and it was like, “*Okay, I’m good at lifting weights.*”
  - So he started competing in power lifting
  - He started hurting himself: back problem, shoulder surgery
- With his athletic training background, he got to college as a strength coach and started to see the same things
  - He’s got athletes with back problems

**⇒** Everybody’s back problem seems to come down to one thing, back squatting (not the deadlift)

- We were the old school squat, bench, power clean because that was the football mentality at that time
- But the people with back pain, it always related to the back squat
- Mike started to look at that and think, “*Okay, if we’re doing something that we know is hurting 20% of our population, should we continue to do that?*”
- For a while we had to because the football coaches mandated it, but when he got to the point where  he was fully in control, he said, “*We’re not going to do this anymore.*”
  - And then we went the unilateral route

Peter asks, “*When you say football coaches, are you saying even at the level of the NFL?*”

- At every level
- The football coaches want to know how many guys can bench press 400 lbs. and how many guys can squat 500 lbs.
  - It’s still a very old-school mentality
  - It’s getting better (especially the NFL level)
- Everybody’s still benching, and still benching 225 as a strength test
- They do an endurance test for strength
- We could talk about the foolishness of the Combine too
  - The same [Combine](https://mboyle1959.wordpress.com/2016/02/25/) that Mike helped train people for

Mike always tells people, “*It’s like getting a copy of the SAT and all you got to do is cheat. Got to practice the event, practice the questions, you know the answers, practice, you’ll get good at it. We developed that thought process.*”

- We started going just down this unilateral rabbit hole
- The biggest thing that people have to understand is when you get into the bilateral deficit research, you are stronger on one leg

**⇒** You have more strength capability on 1 leg than you do on 2

Peter points out, “*It’s so interesting how difficult it is to appreciate that when you’re not doing unilateral exercises.*”

Mike Boyle

- People don’t try it
- And then it’s very dogma-oriented because we’ve all grown up around the squat poems and all these things about, “*King of all lifts,*” and all this bullshit that people spout
  - Mike is always spouting the anti of that
- The reality is when we first started testing, what happened was one of his assistants (this guy Jeff Oliver, who’s been at Holy Cross for 25 years) said to him, “*If we could test one-legged strength, would you stop squatting?*”
- Mike was like, “*Yes.*”
- So then they figured out how to test
  - We started making up these half-assed one-leg squat tests doing rep maxes in different split squat variations and things

***When tested one-legged strength, the results blew us away in terms of the ability to be stronger than we were (or as strong as we were) bilaterally***

- The first year Mike did it with his hockey team (2000, maybe ‘06), everybody could [split squat](https://youtu.be/vSjYwubBgU8?si=ectWDIGR8rodHACb) what they could front squat (the same amount)
  - So if he did a back split squat test, everybody that could back split squat 300 lbs. was a 300 lbs. front squatter
  - Everybody that could back split squat, project out to a 400 lb. max, was a 400 front squatter, right across the board
  - It was exactly dead, even one leg to two legs
- Then people would say, that’s because they’re using their back leg
  - They were trying to come up with all these rationales for why it wasn’t, but the numbers were just glaring
- Then we went to a split squat test and we had one kid who did 240 lbs. for 20 reps
  - The bilateral equivalent is 480, 420 lbs.
  - He’s a 200, 190 lb. hockey player
- The numbers started to smack us in the face a little bit
- Then you look at the **grip strength** research, bilateral deficit: right-hand plus left hand will be more than a combined two-hand

***Mike’s theory is that we neurologically know that we are unilateral***

- If he said to you, “Try to dunk a basketball,” he’s going to guarantee you’re going to jump off your left foot, you’re going to hold the ball in your right hand
  - Everybody here is going to do it, except 10% of us are lefty, so 10% of us are going to grab it in our left hand
- If he says to you, “*Throw a baseball*”…

***We understand neurologically and then we deny it when we start strength training (because we want to deny it), and it’s actually limiting***

Mike has said to people, “*I think I spent a lot of time probably  making people less athletic.*”

- In the past he had some of his super elite NFL wide receiver type guys who would be very resistant to really heavy back squats and deadlifts and things like that
  - They would always say (they were like cats), “*I don’t like it. I don’t like it. It makes my back sore. I don’t feel right.*”

**⇒** And what you realize is you are probably dampening their nervous system

Mike’s analogy

- If you think [The Mountain](https://en.wikipedia.org/wiki/Gregor_Clegane), the guy from Game of Thrones [shown below]
- He was an Icelandic basketball player, decent mid-level player

***When he became one of the world’s strongest men, he was a worse basketball player***

![](https://peterattiamd.com/wp-content/uploads/2025/09/f1-SR.png)

**Figure 2. Hafþór Júlíus Björnsson as Gregor Clegane (or The Mountain) in the Game of Thrones**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Gregor_Clegane)

- Mike used to go to power lifting meets and he’d be like, “*Nobody here looks athletic, no one*.”
- Then he’d go to an Olympic lifting meet and he’d be like, “*Ooh, these cats are athletic. They can jump and they can sprint, and they’ve got big traps and big asses*.”
  - They looked more like what he wanted my athletes to look like
- Whereas power lifting, it was sort of like a semi-mobile refrigerator imitation
  - Just people lumbering
- Then you go to a track meet and go watch the sprints and the jumps and you’re like, “*Oh, wait, that’s what I want. That’s what I’m trying to get everybody to*.”
- So Mike became a big [Charlie Francis](https://en.wikipedia.org/wiki/Charlie_Francis) guy in the ’90s, he started looking at how the fastest people in the world, how the people that jump the highest in the world, are training
  - You started to see more unilateral plyo work, unilateral strength work
  - It was sort of this rabbit hole that he went down and never came back from

 Peter points out that a lot of people don’t realize Charlie Francis’s coaching genius

- A lot of people will have a negative thought associated with him because of the association with [Ben Johnson](https://en.wikipedia.org/wiki/Ben_Johnson_(Canadian_sprinter))
- Sadly he passed away kind of young due to cancer

**Can you say a little bit more about Charlie?**

- He was someone in the field that Mike would have liked to meet
- He developed world-class sprinters in Canada, almost all of them from the greater Toronto area
  - The probability of doing that is really, really low
- He was so far ahead of his time
- If you read [*Charlie Francis Training System*](https://www.amazon.com/Charlie-Francis-Training-System-ebook/dp/B008ZK0WR8/ref=sr_1_1?crid=2BE3UF5OSVYRG&dib=eyJ2IjoiMSJ9.OAlSZ6SjZuLjYJMp25YNvDhnKU4jRLW0DXQhWk1m63p7QjmQuMm4aHFGYgjKjjWdoPJgnb7Y2xUO32cQFk_hgm83iGiI6iHyif1WEu3PDRh4m0V3eZQPFOQnvxSK5kAscHT6PCg9YCPAPcgJKwGblrihGmkvhCGTnLT8sGYefQo.Vm_ZghSZUzp14-ZGNMUQrcp1guHBWSovqmIQuB6uNDk&dib_tag=se&keywords=Charlie+Francis+training+system&qid=1754423803&sprefix=charlie+francis+training+system%2Caps%2C236&sr=8-1#detailBullets_feature_div) right now, he’s talking about recovery, regeneration, massage
  - It was originally published as Charlie Francis training system
  - Then after he got in trouble, they republished it as [Training For Speed](https://www.amazon.com/Training-Speed-Charlie-Francis-ebook/dp/B09LCL39YN/ref=sr_1_2?crid=2BE3UF5OSVYRG&dib=eyJ2IjoiMSJ9.OAlSZ6SjZuLjYJMp25YNvDhnKU4jRLW0DXQhWk1m63p7QjmQuMm4aHFGYgjKjjWdoPJgnb7Y2xUO32cQFk_hgm83iGiI6iHyif1WEu3PDRh4m0V3eZQPFOQnvxSK5kAscHT6PCg9YCPAPcgJKwGblrihGmkvhCGTnLT8sGYefQo.Vm_ZghSZUzp14-ZGNMUQrcp1guHBWSovqmIQuB6uNDk&dib_tag=se&keywords=Charlie+Francis+training+system&qid=1754423803&sprefix=charlie+francis+training+system%2Caps%2C236&sr=8-2) (it’s the same book)
- This book was written in the ’80s, but you would read it right now and think, “*My God, this thing was written a month ago.*”
- He was using words Mike hadn’t even seen yet

**⇒** That’s when he started to do massage work with his athletes; that’s when he started foam rolling

- Because he realized he couldn’t get massage for all of his athletes, but he could get everybody to foam roll
- He was always talking about tissue quality and tissue resets, and they would bring therapists to training camps that they were doing
- It was so forward-thinking
- That was 35 years ago, right?
- He was so far ahead of the field frighteningly to the point where it still encouraged people to read his stuff

***Mike read everything Charlie Francis wrote***

- He read [*Speed Trap*](https://www.amazon.com/Speed-Trap-Biggest-Scandal-Olympic/dp/0312048777/ref=sr_1_2?crid=BI0ZB5QDIA1G&dib=eyJ2IjoiMSJ9.WEgcqRO4b5WICufJXuD2vBiQBa-ERWZym8QUmQzyOhw7qywk7CEe09uKrT1dJYq75wXmOEB-cFZwqwtQfPAPQ3JmHpZF8gbm0vBawMHtUxo3xhDlVbsB2R8Z_tDrBC2xOJ2kbQRdosYtJJDVpDtkW8iI0oD5p-qo5xbFDf4L-FD_vhZptAm46kTuuFskeF1yHi0Fe6XvPN8UdSzjwRRJqEe49Fmi9cE_DtuCO9A4NvY.o4BtlmDXbzhg9x0vMVPUe3Xcnq65L5fw9ng1oRdbmLY&dib_tag=se&keywords=charlie+francis&qid=1754572928&sprefix=charlie+francis%2Caps%2C94&sr=8-2), which was more about what had happened to them in the process
- [Then he read [*Running Risks*](https://www.amazon.com/Running-Risks-Angela-Issajenko/dp/0771591209/ref=sr_1_1?crid=277UI88PRRX47&dib=eyJ2IjoiMSJ9.cNzROprqF8AsW88Hl0Jg4Q.E7KPPbcBecd2gQC2-GJy0bV-kgAbuaK0pX4uk9pir6Y&dib_tag=se&keywords=Angela+Issajenko&qid=1754573071&sprefix=angela+issajenko%2Caps%2C208&sr=8-1) by] Angela Issajenko, who was one of his sprinters
- Mike just read everything he could consume about Charlie Francis to see: is there another little nugget of something that I’m missing from the track and field thing

***Then we started to look at rehab and we realized that from a rehab standpoint, it was all unilateral and it was all what they were calling “functional” (or “closed chain”)***

- And suddenly, it all made sense
- So we’ve been doing [unilateral training] for 30 years

## Rethinking heavy squats and deadlifts: risk-reward, aging bodies, and the case for reverse lunges and other single-leg alternatives [A:1:01:15, V: 1:06:59]

**Jeff, in your world, training people the way you are, what are the exceptions to those rules for you?**

*Are there times when you still see that the risk reward trade-off for someone in a certain position is there for a barbell back squat or a sumo deadlift or something like that?*

Jeff Cavaliere

- There’s the argument that people have already learned bad mechanics for squats that are going to totally break down their body by continuing to  pile more and more weight on
  - Especially in Mike’s world
- When you can intervene with somebody at an early age and teach them biomechanically how to squat better
  - It’s a complicated lift; it’s not easy to dissect that lift
  - There’s a lot of moving parts
  - You have to be willing to spend a lot of time with that person to teach them from the ground up
- In those instances when you can, could probably teach somebody how to squat more safely
- That doesn’t take away the fact that if you can do it and not have to load that way, then the benefits might still outweigh the risks in terms of is this better than a single-leg squat
  - Especially as we talk about the aging population

***You can probably teach that lift, but you have to be willing to teach that person to either unlearn the bad things that they’ve already learned, or if they’re starting out early, learn how to do it more properly***

- And you could do it in stages to: by [squatting to a box](https://youtu.be/q1fCgfieNEs?si=MnN_Evs18KmL0CE3&t=63), you can biomechanically fix a lot of people’s issues because having the target (or the safety net) behind them is enough to get them to move in a better way

**⇒** But you don’t want to train that way without ultimately going to a freestanding squat if they’re going to be ultimately playing sports

- Playing sports and needing needing to do something like let’s say an offensive lineman coming off the line

***Jeff is actually in Mike’s camp in terms of the value of single-leg training***

> “*It’s how we’re wired, how we are actually preferred to move*.”‒ Jeff Cavaliere

- Jeff does so much single-leg training with ATHLEAN-X because he believes that it’s not just the unloading that we get from the single-leg squat
- Anytime you pick up a leg from the ground, it’s functional training

**⇒** Jeff built a whole program with the Mets around step-ups and lunging because we knew how important that was

Jeff did other forms of bilateral lifting

- We would do trap bar dead lifting to clean up some of the issues that people had

Jeff explains, “*If you want to learn how to squat, take a dumbbell, hold it between your hands or kettlebell and just let the dumbbell, the weight go straight down to the ground. It will put you biomechanically in almost a perfect position because you’re just letting the weight drop straight down your center of mass. (That’s a great tool for teaching what people it’s supposed to feel like)*”

- But when you then go put the bar on their back, as soon as they don’t have thoracic mobility, all the things that they’re lacking start to change that dramatically
  - You think it’s the same exercise because you’re going straight up and down
  - But it’s a very different exercise because now when your hands are up, and again, thoracic extension is more required, they don’t have that and the whole system gets thrown out of whack
- It’s still done in certain circumstances, and you’re always going to still encounter people who insist that they still have to squat and they want to learn how to do it and do it more safely
  - Having the willingness or the ability to still coach them through that is important

***Hopefully because of guys like Mike and stuff that Jeff talks about, people are less reliant on those [squats] as the only things that they can do***

**Peter is a little conflicted about squats and deadlifts**

- Up until about 18 months ago, Peter was still squatting and dead lifting regularly though with much less weight
  - He was never going below 5 reps and frankly targeting 8-12 most of the time
- His rationale for it: he viewed it as an amazing audit of his chain
  - He filmed every set (he has a tripod in the gym, and his phone would sit on it from the warm-up set to the last set)
  - His recovery was watching the video
- The truth of the matter is, despite that, about 1 in every 8 workouts, he just screwed something up, and he would spend the next 4 days in pain
  - He’d be sitting in the shower running hot water on his back
  - Was it anything catastrophic? No, not at all
  - His erectors just flared up; it wasn’t the end of the world

***What it said to Peter was (people watching us might be offended by the statement) “I’m getting old. I’m getting old.”***

> “*All of us would agree, the name of the game when you’re old is never getting out of the game.*”‒ Peter Attia

- It’s one thing to get injured when you’re 20, you’re going to be back
- But if a 55-year-old, never mind a 70-year-old, has to take a year off because of some devastating injury, it’s really difficult to come back
- And so Peter very sadly decided that the risk that he was going to do something dumb…

The straw that broke the camel’s back

- Peter used to do a lot of **tire flipping**, he used to have this 450 lb. tire
- His absolute favorite activity was there were different games you would play
  - How many times could you flip it?
  - How long did it take you to flip it 25 times
- When he moved to Austin, he didn’t have his tire (it was out in San Diego)
- So he has his assistant call and find a guy who could find the closest tire to 450 lbs.
  - He found one that was 407 lbs.
- The guy delivered; he’s like, “*What the hell do you want this thing for?*”
- Peter started flipping it again, and his friend goes, “*Have you ever hurt yourself doing that?*”
  - Peter said, “*Never*.”
  - He goes, “*You are in a remarkable amount of lumbar flexion right now, and I would just be careful. The lumbar spine does not like to be in this position when it is that loaded.*”
- Peter realized that he was right
  - He can absolutely see how under fatigue, he could just do something too much

***The point was, Peter basically decided the risk-reward trade-off wasn’t there for him***

- As much as he loves this exercise, as much as it’s: a great audit, he’s learning, he loves the idea of critiquing his form between sets

**Do you think that’s a mistake? Do you think that I should have stuck with it and made other modifications?**

Jeff Cavaliere

**⇒** Jeff doesn’t think there’s a compromise in the benefits you’re getting from single-leg training (you’re probably getting more benefits from that)

- Jeff is in the same boat; probably from age 35-45
- He has bad knees
  - That probably comes from his flat feet
- Wanting so badly to not have to squat because every time he did, it would kill
  - The next day his knees would be horrifyingly in pain
  - And his lower back would ultimately wind up taking on that same brunt (he knows exactly the same spot Peter is talking about)
- Yet he kept telling himself, “*You have to squat. It’s just what we do*.”

It wasn’t until he watched Mike and others say, “*It’s not a requirement to get what I’m trying to get out of it*.”

**⇒** Squatting isn’t a requirement to get leg hypertrophy, stronger hips

> “*I’m trying to get stronger hips. I’m trying to stay injury-free.” And so, my favorite exercise at that point became a reverse lunge*.”‒ Jeff Cavaliere

- He’ll do a [reverse lunge](https://youtu.be/Q59ZvPhpySM?si=Wv2fro7co1r4MaFA&t=122) with a barbell or with dumbbells
  - It’s a little easier with the barbell because you don’t have to worry about the grip of holding the dumbbells
  - [Jeff explains proper technique in this [video](https://youtu.be/Q59ZvPhpySM?si=Wv2fro7co1r4MaFA&t=122)]

Peter asks, “*So reverse lunge, meaning you’re starting in a standing position and you’re doing a step back?*”

- Step backward, step backward
- Peter has seen a great [video](https://youtube.com/shorts/sWVeFUVcsuQ?si=-20kn9-bliSUbOLT) where Jeff emphasizes how wide he’s stepping out
  - This is where some of the functional training stuff comes up
  - People will say that’s a balance exercise not a strength exercise

Jeff explains, “*It’s not a balance exercise. If you can’t keep your feet wide enough, all you have to do is just step back and out. You’ll maintain a wide enough base where you still have support, and then it’s a strength exercise.*”

Jeff’s second big tip on that exercise

- He calls it screwing yourself into place (but you’re really not)

***As you go down, you take just a little bit of a rotation towards the front leg***

- You take your torso a little bit over the front leg
- This will basically stabilize that front leg a little bit more
- When you’re doing a reverse split, it’s about 75% on the front leg
- So you’ve still got 25% going back on the back leg, and that’s enough to support you and make sure you’re not falling all over the place
- Lunging forward is fine, but people that have knee issues, that doesn’t feel too good either, so why not do it this way?

***This is a safer way that has less orthopedic issues for people ‒ the*** [***reverse lunge***](https://youtu.be/Q59ZvPhpySM?si=Wv2fro7co1r4MaFA&t=122) ***is Jeff’s favorite substitute***

## Adapting with age: Gabrielle on injuries, hip dysplasia, and the shift to smarter training [A: 1:10:15, V: 1:17:56]

**Gabrielle wishes should could say she gets less hurt**

- Earlier today she mentioned she has a right torn hamstring
  - It’s a proximal and quad fem (which is very unusual), glut med and glute min
- She loves to overachieve, and about 8 years ago, she thought it was a great idea to keep up with her husband
  - He’s a former SEAL who’s now a Baylor
- She thought they would do a 50-hour event, and she was not physically capable (or prepared) to do that
- For him, it’s just another Tuesday

***She tore her left hamstring on a sprint, and since that time it’s changed her ability to squat***

- She kept going back to the squat, but she’s not able to do that at all now

***Gabrielle stopped squatting 6 months ago***

- She also found out that she has [hip dysplasia](https://en.wikipedia.org/wiki/Hip_dysplasia)
- Gabrielle’s advice for the listener, “*If something doesn’t feel right to you…[listen]*”
- Jeff talks about taking that wide step back

***She had been squatting in a much too narrow position for someone that has hip dysplasia, and so she ground out her hip***

- She’s somewhat stubborn and just kept doing it because she believed that we should squat

***Needless to say, she’s now in a position where she is only doing single-leg movements and really trying to pull back***

- She will probably be doing some [PRP](https://en.wikipedia.org/wiki/Platelet-rich_plasma) for this injury

Gabrielle agrees with Peter, “*The worst thing that you can do is stop.*”She thinks about [Doug Paddon-Jones’s](https://www.utmb.edu/scoa/news-and-events/2022/05/20/in-memoriam-doug-paddon-jones-phd-facsm) work, the [Catabolic Crisis Model](https://pmc.ncbi.nlm.nih.gov/articles/PMC10196581/#:~:text=to%20propose%20the%20%E2%80%9C-,Catabolic%20Crisis%20Model,-%E2%80%9D%20of%20muscle%20size) [illustrated in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/09/f2-SR.png)

**Figure 3. The catabolic crisis model**. Image credit: *T*[*he Journal of Nutrition* 2023](https://pmc.ncbi.nlm.nih.gov/articles/PMC10196581/)

***The catabolic crisis model is when you’re off the table [not training], you lose muscle mass and strength rapidly, and that continues per decade***

**Gabrielle’s training has changed dramatically**

- She does more high intensity on the bike or the air dyne versus any kind of long, slow, steady state (which I would love to get back into), and then also the lifts

Peter asks, “*So you’re able to do high intensity stuff on a bike with a high hamstring tear?*”

- This is new
- She just got her MRI back 2 days ago
- She won’t be able to, but this is her plan when she’s recovered

**How is this going to change your training (once you’re recovered) going forward, and how will that impact what you modify in terms of your patients?**

- Peter points out that they are all practitioners, and they are students, “*We do a lot of self experimenting. We make a lot of mistakes on ourselves*.”
- That gets them curious about the lessons that can be learned
  - How to make sure clients/patients don’t make the same mistakes

Gabrielle Lyon

**⇒** It doesn’t have to be these big lifts; we don’t all have to squat

- Prior to this recent injury, Gabrielle was starting to do more **unilateral work**
  - And she will go back to this
- She was also being much more particular about **form**

“*As lifelong exercisers, we can compensate a lot. People that are somewhat athletic compensate very well.*”‒ Gabrielle Lyon

- Gabrielle has to hold herself to a much higher standard, otherwise she knows she will continue to get injured
- Also she wants to add in more [Zone 2](https://peterattiamd.com/category/exercise/aerobic-zone-2-training/)

Peter remembers

- A trainer showing him videos of incredible athletes doing workouts, and he was pointing out all the horrible mistakes they were making
- The point was, they’re not great athletes because of how they’re training
  - They can get away with training that way because they are such great athletes

**How much did you see that, Mike, when you were training pros?**

Mike Boyle

- He literally just wrote down, “*The better the athlete, the better the compensator.*”
- Jeff adds, “‘*Masters of Compensation’ is what we used to call it.*”
- Mike used to look at these guys and think, “*My God, it’s amazing what they can get away with at that level*.”

Back to squats ‒ Mike’s analogy

- If you substituted slamming your hand in a car door for squatting, and then had the same conversation with yourself saying, “*Hey, I just hurt my hand, I slammed it in the car door, and I can’t wait till my fingers heal up because I’m going to go back and slam my hand in the car door*”
- Peter and Gabrielle agree, “*We’ve all done that*.”
- That’s why Mike wrote the [article](https://mboyle1959.wordpress.com/2016/01/23/more-on-why-we-dont-squat/), because people do it all the time
- Peter thinks the analogy is more like: I love slamming the car door because I love the noise, but I like to also reach in the car when I’m doing it
  - And normally, it’s fine, but on every 8th slam… Oh
- Mike might edit the article for that and say, “*Okay, even if it was only every eighth time you did it, would you go back and slam the car door eight more times? You wouldn’t.*”
  - No, that’s absolutely stupid
  - The risk-reward doesn’t work
- But for some reason squatting has such a visceral attachment in strength and conditioning (it’s religious)

Jeff Cavaliere

- Exercises like “[the clean](https://www.crossfit.com/essentials/foundational-movement-clean-what-is-a-clean)” don’t have that type of religion
- Everyone can relate to the squat, so there’s the attachment
  - The squat is something we do every day, every time we get out of a chair, every time we go to the bathroom

Peter points out, “*People are confusing a goblet squat or effectively a sumo deadlift with a goblet, which is, it’s all the same hip hinge. They’re confusing that with this. This is the unnatural part, I think.*”

Mike Boyle

- Mike teaches everybody to [goblet squat](https://youtu.be/tS9y8s39_fM?si=_aMcQs-kTkUSZ4HT) and [sumo deadlift](https://youtu.be/7BAiJqftNmo?si=mCzRmbhUv5eTaxSV)
- People argue for the squat: you got to be able to go to the bathroom
  - Mike points out that you’re not going to piggyback someone [onto the toilet] ‒ that’s not how it’s going to work

**⇒** You only need to be able to body weight squat

“*Once you can body weight squat, you’re good. Let’s do unilateral stuff for loading.*”‒ Mike Boyle

People ask, “*What’s an adult? What’s an athlete?*”

- Mike makes it simple, “*An adult has a job that does not involve playing sports*.”
- Mike was doing a presentation for [*Perform Better*](https://www.performbetter.com/), one of the things he said, “*Pickleball players aren’t athletes*.”
- People that are adult recreational athletes, they’re not athletes because if they get hurt, if you get hurt at 50 or 60, it’s really debilitating
  - You don’t heal
  - Even the rate of healing, you’re seeing that now
  - The rate of healing is totally different
- Mike looks at his son and his friends, they’ll get hurt, and 2 days later, they’ll be like, “*I’m fine.*”
- He looks at them and thinks, “*I’d be six months crippled if I did what you did*.”
- People don’t see this change

Mike’s analogy, “*Life is this gradual transition of filet mignon to beef jerky. Right? And I’m in the beef jerky stage of life, firmly in the beef jerky stage of life.*”

- Peter jokes, “*I’m thinking I’m a New York strip at the moment, just getting a little firmer.*”

> “*The number one cause of injury in old men is thinking they’re young men*.”‒  Michael Boyle

![](https://peterattiamd.com/wp-content/uploads/2025/09/f3-SR.png)

**Figure 4. Michael’s advice**. Image credit: [Instagram](https://www.instagram.com/p/DEiNLLYxza-/?utm_source=ig_web_copy_link)

- When people ask Micheal should they squat? Should they deadlift?
- He always says, “*No*.”
- The problem with that is when you start letting people do these things, you then have to become the ringmaster in the circus
- He just eliminated the events
  - If nobody squats and deadlifts in our adult program, then we’re just better off
- With his professional athletes, he had one guy in the Red Sox who squatted
  - He insisted after Mike really fought with everybody about it, every single guy except one
  - He was a pitcher that looked like a linebacker ‒ he looked like [Brian Urlacher](https://en.wikipedia.org/wiki/Brian_Urlacher)
- The college kids he works with have to squat because Mike wants them to be able to go back to school and his college weight room and participate in the program the way they’re supposed to participate

Peter feels like people don’t appreciate the nuance of what Mike is saying

- That it can easily be turned into, “*Mike thinks no one should squat.*”

***What you’re saying is there is a threshold, a risk-reward trade-off***

- Peter agrees with this idea that if you’re not getting paid to play a sport, you have to reconsider how you’re treating that sport

## Exercises that belong in the “iron graveyard”: unnecessarily risky exercises and their safer alternatives [A: 1:19:15, V: 1:27:28]

Jeff Cavaliere

- It’s also not as if the alternatives are sacrifices in terms of what they’re delivering

Jeff talks about the “iron graveyard”

- There’s a few exercises that just belong in there
- One of them is the [upright row](https://www.verywellfit.com/how-to-do-the-upright-row-3498316) (it’s a garbage exercise)
  - The way that old school taught how to do the lift: you hold the barbell and you lift it up here up under your chin, your elbows are much higher than your wrists are
  - You’ve got lots of weight usually on the exercise
  - Fully pushing your arms down to internal rotation
- As a physical therapist, the funny thing about that is that that position is literally the test that we would put somebody in to try to see if they have **impingement in their shoulder**
  - We would put them in this position, push down, if it gets a lot of pain in there, likely something’s getting pinched (supraspinatus tendon, something)
- Jeff did that exercise for 40 years
  - He never got hurt on it
- He wants you to do something called a [high pull](https://youtu.be/bZq2D3kdwdY?si=SDyICVLrsmUsJXTh&t=495)
  - Drop your elbows lower than your wrists
  - By doing that, now instead of internally rotating the shoulder, I’m externally rotating the shoulder
  - I’m still working my delts
  - I’m still working my traps
  - I get zero sacrifice of what I’m trying to do the exercise for in the first place, and I eliminate the part that I don’t like
  - He doesn’t care if you haven’t gotten hurt, but ultimately doing it over and over and over again, can potentially cause a problem down the road
  - Even just the potential of it
    - He’s not saying that you can’t get injured on any exercise ‒ you can
  - On this exercise, I’m lowering the risk and not sacrificing the benefit
- When Mike talks about squatting, the fact is if you can do something that’s giving you a better or even equal benefit and it takes away some of those downsides to the exercise (especially as the population who’s performing it is less appropriate to be performing the exercise and more appropriate to be doing the alternative), what’s the whole point?

Gabrielle Lyon

- It makes her think about: How do we re-educate people?
- Because we’ve all suffered from these narratives of, “*You have to squat, you have to deadlift,*” and it’s similar to nutrition

**Gabrielle asks, “*****Do you think there’s a way that we re-educate getting to our youth potentially so the younger that we can educate, the less likely we’re going to have adults in their 50s having to have serious injuries?*****”**

- And then, Mike, you wouldn’t have to have this conversation about no more squatting

Mike Boyle

- No
- Mike think’s we’re doing it right [in this podcast[

“*The ability to mass produce this and to have people hear it and see it is something that we weren’t really able to do before.*”‒ Mike Boyle

- Mike talked about the fact when he was a kid coming up, he had to wait for the new [*Strength & Health*](https://en.wikipedia.org/wiki/Strength_%26_Health) and [*Ironman*](https://en.wikipedia.org/wiki/Iron_Man_(magazine))to come out to the news stand (he waited and he visited the daily news stand)
  - Peter remembers, “*We lived by these magazines.*”
  - Because that was our only connection to the training world
- And now, you’ve got 14 million subscribers on YouTube
- Someone asked Mike, “*What’s the greatest thing you’ve seen, or the greatest change in strength and conditioning?*”
  - He said, “*The computer.*”
  - They were like, “*What do you mean?*” He said, “*There was no computer.*”

***Now with podcasts and YouTube, we can educate people***

- But our problem is that we copy dumb people
- There’s too many dummies on the internet and not enough people
- In his old age, Mike has taken to calling out the bullshit
  - Sometimes he’ll just say on Twitter, “*That’s a bad take.*”
  - Because if you don’t, then people get to establish themselves as experts because
- This is the loudest voice situation now in terms of who’s going to influence, and now there’s a lot of AI
- If you look at Twitter’s got all these AI things going that are showing people, and sometimes Mike will just write, “Total garbage,”
  - It shouldn’t be on the internet; it shouldn’t be anywhere
- Peter agrees, “*We need that.*”

**Jeff, give us a couple more things in the “iron graveyard”**

Jeff Cavaliere

- [1 – The [upright row](https://www.verywellfit.com/how-to-do-the-upright-row-3498316), discussed earlier]
- 2 – The [Cuban press](https://barbend.com/cuban-press/) for the same reason
  - When the elbows go up and the arms come down and then press from there
  - It’s an unnecessary adaptation that we don’t need
- 3 – The [chest fly](https://gymgeek.com/exercises/chest/chest-flys/)
  - He puts the unsupported bench fly in the graveyard simply because of his history of working with pitchers and knowing how susceptible the shoulder caps that can become from chronic over-stretching and then we apply a load in that position at the same time
- A fly machine is much, much safer
- We’ll do a [floor fly](https://youtu.be/S298ziysRdI?si=yE1oe4KmjiMmdxMu) ‒ we’re getting the eccentric overload
  - The benefit of a floor fly is that you’re going to have the safety net  of being on the floor
  - If I’m doing the exercise because I like the eccentric overload, I can actually apply a little bit more weight, a little bit more eccentric stress to the chest
  - The benefit of the exercise is the stretch of the exercise
  - I can apply a heavier load but in a much safer way, and my shoulders aren’t going to be vulnerable
- But because the chest fly is an Arnold favorite and it’s an Arnold Classic
  - Jeff believes he tore his pec once on the fly, so it had repercussions for him too

***Nothing is in Jeff’s graveyard that doesn’t have an alternative that’s equally good***

- The only reason why he would throw an exercise into that category is become there’s something that could be done to eliminate some of the risk and still delivers [benefits] just as good

## The downside of early sports specialization in children and the long-term benefits of encouraging kids to play multiple sports [A: 1:25:00, V: 1:34:03]

- Peter has 3 kids, they all love playing sports
- One of them in particular (the youngest) has taken a real love of baseball; he just turned 8 about a month ago
- Peter grew up never playing baseball
  - It wasn’t a sport that was particularly popular where he grew up
- Peter has now become obsessed with baseball
  - He can really fully understand how people can get obsessed with this sport
  - It’s not just the numbers and the data
  - There’s so much art in nuance in learning about all these different pitches and how they hold the ball and all this kind of stuff
- We live in a world now where coaches want kids to specialize earlier and earlier
- They’re playing 3 seasons a year in baseball right now: fall ball, spring ball, there’s this little summer ball tournament
- The kids are playing one position now

***Peter was a little bit surprised at the end of his 7-year-old season that most kids have a position coach outside of the team***

- Peter’s intuition is that just doesn’t make sense

**Tell me what you guys think of that**

Mike replies, “*Do you have a soapbox available for me to jump up on?*”

Mike Boyle

- Follow the money
  - Most of these people that are telling you that kids need year-round sports are making their living from year-round sports
- If you look at what most professional athletes are doing, they’re not doing that with their kids
- If you look at what most coaches are doing, they’re not doing that with their kids
- What you usually find is some entrepreneur who has developed Joe’s Baseball and he needs income year-round because he doesn’t have Joe’s Baseball and Lacrosse
- He just says, “*Joe’s Baseball.*” So as a result, they start telling you, they start giving you that **early specialization myth**
  - They start using words like development and exposure

***No, that’s bad information***

**⇒** Mike’s advice for an 8-year-old who really likes baseball: #1 make him do something else besides baseball

- Mike’s daughter was a full scholarship ice hockey player (very, very good); she played a year in the Women’s professional league
  - She had a scholarship when she was 15 years old
- Mike didn’t let her play in a summer tournament until she was 13
  - People would ask him why all the time, and ask what she was doing
  - She was going to the lake, she was going to water ski, she was going to be on the swim team
  - She took up diving one summer because they needed a diver, and she became the U12 diver because the guy saw her throwing herself off the diving board and said, “*Oh, she’s fearless. I’ll teach her to dive.*”
    - It was a couple hours a week
  - He made her play soccer
  - She did judo and was the state judo champion when she was 12

Mike adds, “*The kids that are better athletes do better in the long run.”*

When kids specialize early you end up with an **early succeeder phenomenon**

- They won the “genetic olympics”
  - They tend to form groups that develop earlier and tend to be ahead
  - They were the ones that were shaving in junior high school
  - They were much better in junior high football than the rest of us were because they weighed 190 lbs. and we weighed 130 lbs.
- You look at that and that’s not going to have any bearing on the end
  - This is the literal marathon versus sprint argument; a developmental marathon

***The kids who sample different sports tend to do better, because we’re trying to develop general athletic attributes***

- Your kid loves baseball now, but you don’t necessarily know that it will always be the case
- Mike’s son loved hockey, he also played lacrosse and baseball

Peter asks, “*Do you feel this way even if the kid is themselves wanting to play all the time, would you sort of force the kid kid?*”

- Yeah, Mike forced his daughter
  - All she wanted to do was hockey
  - She wasn’t thrilled about the idea that he wasn’t letting her play in a summer tournament
  - She was angry with him at times, they had fights about, “*Why can’t I do this.*”
- Mike said to her, “*I don’t care if you’re the best player when you’re 12. I care if you’re the best player when you’re 18. Being the best player at 12, I’m not getting any ego gratification by going to this tournament and realizing that you made the 12-year-old All-Stars or something like that*.”

**⇒** Just because they want to do it, doesn’t mean it’s right for them

What you see in kids who play several sports

- You’ll see the kids in hockey that played soccer because they’re kids that can pick up pucks in their feet
- Mike’s son picked up lacrosse really fast because he played baseball and he played hockey and he understood the whole idea, “*Oh, we score. There’s a net. I can catch things extended*.”
- But if you weren’t sampling, you don’t know

A terrible analogy (but Mike going to use it anyway)

- If your son came to you and said, “*I really like cocaine at this point, it’s the only thing that I want to do*,” you would be like, “*No, we’re not going to do that.*” Right?
- But suddenly, because he used up…
- You have to do a little heroin, you need to do a little meth, you have to drink a few beers

***You see the absurdity of that (Mike likes absurd analogies)***

- If you substitute that for baseball
- Yeah, you love baseball and that’s great, but you should learn to swim, and you should learn to do some sort of sport that involves your feet (soccer)

Some sort of combative sport are really good for kids

- The instructors when Mike’s daughter was doing judo was [Rhonda Rousey](https://en.wikipedia.org/wiki/Ronda_Rousey) and [Kayla Harrison](https://en.wikipedia.org/wiki/Kayla_Harrison)
  - What are the odds that you go to the best judo school in America that is 15 minutes from your house?
  - Mike’s daughter can still say that she was taught by Rhonda Rousey and Kayla Harrison, having to go out on a mat and fight another kid
  - It is really good for a 12-year-old girl

> “*If we can think of the worst possible thing you can do for your kid, it is to let them specialize.*”‒ Mike Boyle

- Even if the kids want to specialize and when you don’t let them, they argue, “*Dad, I don’t like you. You’re mean. You’re not a good person because you’re not letting me do what I want to do.*”
- You’ve got to look at them and think, “*That’s why I’m the parent. That’s why I’m in charge.*”

Gabrielle Lyon

- Gabrielle’s kids are both in gymnastics and jujitsu
- Her daughter hates jujitsu and she excels in gymnastics
- We chose gymnastics because it allows for the development of her fine motor skills and her musculature
- She loves it

> “*We know that the healthier, fitter and more active these kids are, the greater their metabolic health as adults is*.”‒ Gabrielle Lyon

**Sports injuries**

- In the US, we see a lot more injuries than in other places because of this always having a season
  - Think about this from a standpoint of longevity

Jeff Cavaliere

- Jeff doesn’t know why we haven’t stopped and questioned it a little bit sooner because it’s not like injury rates are going down
- We’re playing more and getting injured more
  - That’s what we’ve seen across all levels of sport
- Jeff and Mike were discussing the rash of [Achilles tendon injuries](https://en.wikipedia.org/wiki/Achilles_tendon_rupture) ‒ a lot of it has to go back to the repetitions in the mileage

One thing that Mike brought up that Jeff thought was really interesting was the way the style that the game is played now

- Let’s say basketball, there’s so much more because it’s really: come down, chuck up a three, go down, chuck up a three, come down
  - There’s a lot less of that inside game going on
  - The game is faster
  - They run more: 200 more miles a year per team
  - Just because of the way the style of the game is played
  - And they’re not all linear miles ‒ they’re start, stop, start, stop, start, stop
  - There’s a lot of cumulative stress on the Achilles tendon doing that
- This is on top of the fact that as teenagers, they are playing all year long
- It’s not like it used to be when Larry Bird was playing
  - He played his season and he went home and probably played something else

***We need to start looking at these extensive seasons and these multiple seasons per year because it’s not helping***

- If it was helping, we wouldn’t have all these athletes being injured
- Things are worse now than they’ve ever been

## Advice for preventing an Achilles injury: calf strength, ankle mobility, and listening to pain signals [A: 1:33:15, V: 1:43:42]

**Say more about the Achilles injuries**

- That’s the injury Peter personally fears the most at this point because he plays soccer and baseball with his kids a ton
  - Despite all the multilateral training he does
  - He’s especially worried about soccer ‒ he’s worried he’ll be diving for the soccer ball and ping
- Mike jokes, “*It’s the beef jerky injury*.”

*What’s the protocol? How do you think about maximizing the odds of survival?*

Mike Boyle

- 1 – Foam rolling and stretching
- He’s a huge foam roll and stretch person and thinks everybody should be doing it

Peter asks, “*Specifically you’re talking about the soleus, you’re talking about rolling all the way down onto the tendon?*” [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/09/f4-SR.png)

**Figure 5. Anatomy of the lower leg including the soleus and Achilles tendon**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Achilles_tendon)

Mike Boyle

- Yep, the calf
- 2 – Doing ankle mobility work
  - Basic [ankle rocks](https://youtu.be/F6SjIvBA1UQ?si=uiAnTGrp6iQSQ8bb)
- This is where you talk about dogma ‒ all of a sudden, the **front foot elevated work** is becoming popular (on a toe-plate)
- When you think about it from a preventative standpoint, it makes perfect sense
- We were always told that correct technique is to have your whole foot on the ground
- Mike’s physical therapist friend ([David Gray](https://www.spoonerpt.com/therapists/david-gray-pt-dpt/)) explained, “*If you want to get your foot engaged and you want to get your gastroc engaged, it just makes sense to put your foot on there [on a toe-plate]*”

> “*Functional training is training that makes sense when you think about things*.”‒ Mike Boyle

That’s why [chest] flies don’t make any sense, unless you’re a professional face slapper

- Jeff adds that it’s probably better on the pec dec
- Mike doesn’t have his clients do chest flies
- Peter adds from a hypertrophy standpoint, there’s a lot of reasons to do it
  - There’s something you must be getting out of that movement

Jeff Cavielere

- Jeff looks at the amount of abduction you’re getting: any press, any dip, any pushup, it’s all limited to a range of motion
  - But if I can actually open it up even further and get more stretched
  - We know the benefit, hypertrophy-wise, of applying stretch to a muscle
- But that’s an exercise where you are also entertaining end range shoulder mobility and then excess stress on the anterior capsule
- So if you’re a bodybuilder or in certain sports where the aesthetic matters, it could be the difference between 1st and 2nd place
- Educating people about what those risks might be is an important first step to having a discussion of whether they should do it or not
- But again, if he can provide an alternative where you could get additional benefits without the risk, then why do it?

**What else do you think is important in the playbook of minimizing the risk of the Achilles injury?**

Jeff Cavaliere

- **Ankle mobility** is something that no one pays attention to
  - We don’t try to mobilize our ankles at all
- **Tight calves** are common in people and they don’t really ever address them
- And it all starts at the ground ‒ everything starts at the ground
- If you have any **compensation**, if you lack ankle mobility, your knee is going to pay the price for sure

**⇒** The **knee** is like that consequential joint in between the hip and the foot, and it’s just reacting to what’s happening above and below

Jeff shares, “*My knees in particular, like they got beat up and they never really were to blame. All they were trying to do is just hinge back, and forth and they couldn’t do a good job because they were being betrayed by flat feet and weak hips.*”

***If people pay more attention to strengthening their hips and to mobilizing their ankles, you can feed that chain up and down***

- And if your calf isn’t tight or if your ankle is more mobile, then there’s less of that tension being placed down through the tendon itself, then taking a step forward in terms of decreasing your risk of actually snapping that thing

**In terms of strengthening the calf, do we think the soleus or the gastroc plays a greater role?**

*Do you need to have both knee bent and knee straight?*

Jeff Cavaliere

- We always focus on both
- A lot of people will always talk about the [gastroc](https://en.wikipedia.org/wiki/Gastrocnemius_muscle) specific strengthening with the knee straight just because it’s the one that gives you the better contraction
  - But Jeff doesn’t care about that
- Jeff cares about making sure that all the muscles in the body are strengthened

**⇒** We’ll do equal amounts of seated versus standing calf raises

- If you’re doing 3 sets in a day of standing, you’re doing 3 sets seated as well
- Every time we program calf training, it’s seated and standing together
- Jeff doesn’t think one versus the other is more responsible for the tears

***As a group together, our ankles are lacking mobility, and because the ankles are lacking mobility…***

Effect on the ankles of sleeping at night

- Your feet are down, especially if you keep those blankets tight at the end of your bed, they’re down quite a bit
- You’re spending 6, 7, 8 hours in that position
- You’re not doing yourself any favor in terms of encouraging mobility at the ankle and flexibility through your calves
- So we need to be much more aware of those areas and do more work towards that

**We talked about in the very beginning: What do I have to do to be in shape?**

- Sometimes you have to own little mini parts of your program because specific to you, they’re important

***This big fear of that Achilles tendon tear, that would be part of your program that you have to add another 5 minutes of mobility work for your ankle and do that 3-4 times a week***

- Jeff is right there with Peter: it’s a devastating injury that will take you out for quite a while
- That time starts to add up and people start making choices, and their choices
  - Again, cutting all the little stuff, because no one’s going to see my ankle development
  - They want to see my arms or my chest or something, and so they do more work there
  - But when you make those decisions to cut those little parts of the program, those are the ones that usually keep you injury free

**Speaking of single leg, the difference between doing calf raises with two feet versus single leg, that was one of the most profound eye openers for Peter**

- The difference in strength and how much less weight you could do with one leg at a time
  - It’s not half the weight
  - There’s some sort of interesting compensation when you’re doing it two legs at a time

Mike Boyle

- We started adding that back into our adult program
- We never put calf work in, and then Mike remembered trying to do some calf raises, and he was so sore

***You realize it’s kind of a use it or lose it scenario where if you’re no longer sprinting and jumping, then that flexibility, the mobility of that complex and the ability of that thing to absorb force***

Mike’s advice

- 1 – Avoid doing it if your calves are sore
- Look at both [Tatum](https://en.wikipedia.org/wiki/Jayson_Tatum) and [Haliburton](https://en.wikipedia.org/wiki/Tyrese_Haliburton) had previous calf strains that they were playing with, ended up with Achilles tendon tears
- Mike saw a great meme yesterday [shown below]

![](https://peterattiamd.com/wp-content/uploads/2025/09/f5-SR.png)

**Figure 6. Meme about pain**. Image credit: [@9GAG on X](https://x.com/9GAG/status/1231564624169984008?lang=en)

- You’ve got to be able to look at that and realize that it shouldn’t hurt at all

***If you’re thinking your calves or shins are sore ‒ that’s indicating to you that you were doing something that wasn’t kind, and that now you’ve got to give that enough time to recover so that that’s not sore anymore***

- Sometimes we get into the kind of hard guy stuff
- Mike wrote an article one time called [*Does it Hurt?*](https://www.strengthcoach.com/resource/62c890931ce9f0e6260935ad)
  - It’s a, “*Yes*,” or, “*No*,” question
  - And any equivocation is, “*Yes*.”
  - After I warm-up, it doesn’t hurt (that’s a “*Yes*”)

Peter adds: you’re using that as a sign that says, “*I need to understand why it hurts.”*

- It’s not, “*You don’t train.*”
- You need to figure out what’s wrong with your movement pattern

## Shoulder pain: how to keep training the upper body when shoulder pain limits pressing movements [A: 1:40:45, V: 1:52:45]

Mike Boyle

- And figure out what Jeff was alluding to: upright rows and [rotator cuff](https://en.wikipedia.org/wiki/Shoulder_problem#Rotator_cuff_tendinopathy_(tendinitis,_bursitis,_impingement_syndrome,_and_rotator_cuff_tears)) ‒ what is it that’s making your shoulders sore?
  - What’s the movement that’s aggravating?

**⇒** For some people, we find that [standing cable pressing](https://youtu.be/T_rqWNrF6yk?si=ZyriTZrcVqvSdYX3) is the one thing that everybody can do that doesn’t hurt

- Mike’s goal is to get you to press pain-free, and we can build off that

 Jeff Cavliere

- What people don’t understand too is that it’s okay to go through periods of restriction to a single movement like a standing cable press, to actually allow the shoulder to heal to a point where you actually could get back to doing other variants of the press

Jeff had a [labrum tear](https://en.wikipedia.org/wiki/SLAP_tear) and an inability to do any type of pressing

- He had to restrict himself simply to a variation of a crossover that wasn’t even a pure crossover, but just something that he could do where he could actually pull in a little bit and then cross over my body [typical [crossover](https://youtu.be/qBDTDrnEpSs?si=04SCX_MW4-zSElYU) technique]
- Because that was the only thing he could do pain-free
- He could still work his chest in a way that allowed him to do something
- He knew he could do something completely different, like a [horizontal row](https://youtu.be/gfUg6qWohTk?si=TpY4sfqntesbjWge)
- By doing that, he’s getting shoulder movement in a way that was different
- It’s almost like the specialization in sport, not just doing all chest stuff but trying to actually attack the chest through a different way by still looking at the shoulder joint
- Jeff would do a lot of rowing, which probably was good just posturally to balance out some of the imbalance he had in the shoulder
  - Also to just give him more joint range of motion in the shoulder because he’s getting all this extension
- The combination of those 2 things got him to a point where his shoulder doesn’t hurt
- Now he can actually go back to pressing again in a smart way with dumbbells [[dumbbell bench press](https://youtu.be/CqLo6br92dI?si=IFo7MCrJylF_lvei&t=90)]

***Jeff doesn’t barbell bench press, but he does it with dumbbells, and he has none of the pain that he had years ago when that was going on***

- It’s okay to understand that this is a long game and you might want to take a step back and stay with the exercises that don’t cause pain and allow yourself a chance to be actively mobile to still recover at the same time
- Instead of sitting on the sidelines (that’s not going to turn out well)

## Effective strength training strategies for women before, during, and after the menopausal transition [A: 1:43:15, V: 1:55:35]

**Gabrielle, what are you noticing as the most important things as women are making the transition from perimenopause into menopause?**

Gabrielle Lyon

- 1 – Don’t wait until you start to feel that your body composition is changing

> “*The fitter they [women] are going into perimenopause and menopause, the better they’re going to be both metabolically and just activities of daily life, everything. Those women seem to suffer much less*.”‒ Gabrielle Lyon

Symptoms that appear when hormones are changing

- Sleep is poor
- One of the signs of menopause is this frozen shoulder
- Gabrielle believes in [HRT](https://en.wikipedia.org/wiki/Hormone_replacement_therapy) or menopause therapy
- When it comes to training, in the literature Gabrielle hasn’t seen evidence that training is sex-specific

***There is not something specific for women that needs to happen other than following good foundational principles of strength training, hypertrophy, and cardiovascular activity***

- 2 – One of the things that Gabrielle looks at is if women are at risk of injury of the tendon or joints
  - This is something that changes
- But once we treat them, she doesn’t see a reason to change
- Good programming is good programming
  - Progressive stimulus is progressive stimulus

Mike Boyle

- When Mike read [[*Forever Strong*](https://www.amazon.com/Forever-Strong-Science-Based-Strategy-Aging/dp/1668007878/ref=sr_1_1?crid=2XSB91ARHLOAN&dib=eyJ2IjoiMSJ9.tk-qlP5uJdIuh4JEA6MRnqeZW324Hx_wlgqJjqTYX2nXYYu8CYYGF-CBSJAXvEnilNMh7vzrBe4rAZPvWZYih8kVPrm9TBbsiARO430xJx7HGLRLRVPjQ2RZrsp171BgkvA-TK7AOI4coVljFJ-zj9I3Xp4su0MBNEelc8fOJbi92DINer9YdErwl2R4MCyA6JI1Qmp_yVujFzBO7EwGYLttZVEotWrRHmWnst0MGm4.X7DNm71Os0HwDZIVRc_SvEgRq-RADS02B-Rn2rI9ytQ&dib_tag=se&keywords=forever+strong&qid=1754337180&sprefix=forever+strong%2Caps%2C116&sr=8-1)], it was very reinforcing for him because he’s getting that question more from female clients
  - Because people like Gabrielle are talking about it
- It always comes back to strength and conditioning

***Get stronger, get in better shape, get them to challenge themselves more with weights and not be content***

**There’s an ego component that’s absent in females that is very present in males**

Mike Boyle

- Males will look at what Jeff did, and might think, “*Oh, I’m going to try that*.”
- Females just don’t have that ‒ they’re very internally driven
  - And sometimes, that will cause them to underachieve in the weight room because they’re not worried about being top dog, they’re not worried about who lifted the most weight
  - It makes them better clients
- Mike has a lot of really elite females that are great hockey players and lacrosse players and stuff, and they’re the best people to train by far because they don’t have a lot of the extra baggage sometimes that the guys have
- Females are way more compliant
  - They just listen to what you say
  - They don’t argue with you
  - They don’t worry about what Jeff is doing

Mike’s advice for women

- Encouraging them to continually get stronger
- Look at it as conditioning versus cardiovascular workout
- Pushing them to do more intervals, pushing them to do more aggressive intervals
  - You might call it a VO2 max workout
  - He loves [Andy Galpin’s](https://www.andygalpin.com/) idea of getting your heart rate up really high once a week
    - [Andy was a guest in episodes [#239](https://peterattiamd.com/andygalpin/) & [#250](https://peterattiamd.com/andygalpin2/)]
  - Wear a heart rate monitor and don’t be afraid to push your heart rate
  - Don’t be afraid to be out of breath and feel like you want to lay on the floor kind of thing

***Mike thinks intervals on a big*** [***AssaultBike***](https://www.assaultfitness.com/products/airbike-classic?srsltid=AfmBOoqLK60nMZ8c8T2Gqo8gS2XdM_Wr7kdMoLCp14kCcMi4tNFS7y8h)***/***[***Airdyne***](https://www.schwinnfitness.com/schwinn-airdynes?srsltid=AfmBOoqUZxuwtVEdkeJJt8qOwxArzJXpMQ_jrpmBgxNThzT_LZusNAo9) ***is the most efficient way to hit your cardiovascular system with no orthopedic costs***

- He bets Gabrielle would be able to bike with her hamstring injury
  - Because you’re not weight-bearing and you’re not getting a lot of aggressive hip extension and aggressive hip flexion
  - You can probably torture yourself on there for a long time with out having any negative effects
- She’s planning on trying it later today

With women, the biggest things is getting them over that, “*I’m going to get big so I don’t push myself*,” kind of thing

- Mike films a lot of women and asks them to talk about their weight
- He has 2 of the best lacrosse attackers on the US team that are in their mid-20s and have been here for 5 years
  - They’ve gained no weight
  - They’re stronger, they’re faster

**⇒** But females gaining lean mass is really difficult

- You have to really be a super responder
  - You will get the occasional really [mesomorphic](https://en.wikipedia.org/wiki/Somatotype_and_constitutional_psychology#The_three_types) female where she really does respond to weights, but they’re super rare
- Mike always says, “*Apples end up like apples, oranges end up like oranges*.”
  - It’s not like suddenly one day the apple is going to wake up and the next day going to be an orange
  - If you’re an [ectomorph](https://en.wikipedia.org/wiki/Somatotype_and_constitutional_psychology#The_three_types), you’re an ectomorph
- You will get the occasional really mesomorphic female where you do think, “*Oh wow, she really does respond to weights*,” but they’re super rare

**Jeff, are you seeing in women specifically that you’re training, especially during that transition through menopause?**

Jeff Cavaliere

- As Gabrielle pointed out, the training specifics are pretty much the same
  - What is good smart training for men is equally applicable to women

1 – From a PT standpoint, biomechanically, there are some differences in terms of something called the [Q angle](https://en.wikipedia.org/wiki/Genu_valgum#Q_angle), the angle of the hip of the femur coming down to the knee [illustrated in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/09/f6-SR.png)

**Figure 7. How the Q-angle is measured**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Genu_valgum#Q_angle)

- It does create a lot more valgus at the knee for women than it does for men
- You just have to be aware of those things

***When you’re doing certain activities, you want to be able to coach better in terms of being aware of positioning***

- The tendency for a lot of women when they **jump** is to land in a much more valgus knee state, which could put more and more stress
- We’re not fearful of them blowing out in a training session, but as we talked about before, that cumulative stress of every time you land, you’re getting more and more stress on the [MCL](https://en.wikipedia.org/wiki/Medial_collateral_ligament) or the [ACL](https://en.wikipedia.org/wiki/Anterior_cruciate_ligament)

***That would be something that you’d want to coach around and make them aware of because you could strengthen that***

- You could work on biomechanically improving those things
  - Put a band around their knees and have them jump that way and land that way
  - They’re l**earning how to activate their abductors in their hip**
  - All men could benefit from that, but it’s not an additional requirement because we’re not dealing with the same biomechanical angles

2 – Because of hormones, women will have more laxity at different times of the month that will make them susceptible to different stresses

- You just have to be aware of the education side of it and coaching through that

**⇒** As far as the exercises, the programming, we also found that women just tend to be much stronger than men in terms of their output pound for pound

- And given the differences in sex, they’re able to proportionally push more weight, especially with their lower body than men can (much stronger)

Jeff asks, “*Have you found that too, Mike, that women are incredibly strong in terms of their output in strength comparative to men?*”

- Mike hasn’t thought about that in terms of pound for pound
- The one thing we found is that they’re much stronger in their upper body than they think they are
- Mike has got women doing weighted chins with 45 pounds for 5
  - 45 for 7 is the best he’s seen

Peter reacts, “*What? Wow!… 45 pounds wrapped around her waist and she’s doing 7 chin-ups.*”

Mike Boyle

- Yes, [Alex Carpenter](https://en.wikipedia.org/wiki/Alex_Carpenter)
- In Mike’s gym, he really emphasizes it and most of his men can do that
  - One did 90 for 2 the other day, and he weighs 180
  - Mike really emphasizes pulling

## Best practices for strength training and athletic development in children, and the pitfalls of early sports specialization [A: 1:50:30, V: 2:03:41]

- Peter comes back to something Mike said at the outside talking about kids
- The youngest he trains is 11

**You drew a hard line in the sand about that age. How come?**

Mike Boyle

- Mike doesn’t want to be in the childhood stealing business
- He thinks kids should be kids and they don’t need a strength and conditioning coach when they’re 7, 8, 9, 10 years old
- They probably need a playground and a bike and a swing set and a slide

***There’s a lot of things that kids could be doing that are way more fun than being in Mike’s gym***

- Mike drew the line at 12 initially, but the sports brackets are 11, 12
  - When we realized that we drew the line at 12, people then started coming and wanted to bring a team
  - So eventually we bumped it down and then we just resisted bumping it down more because Mike doesn’t want to run a kinder gym kind of program
    - He doesn’t want birthday parties
- At 11 you’re going into middle school
  - You can start to understand that there may be some commitment involved in terms of, “*Hey, if I want to make a team, I’m going to probably have to learn to work at this thing and I’m going to have to learn to train*.”
- It’s very good if you look at long-term athletic development models, that 11, 12 is a good learning to train age to get kids in and get them kind of oriented to how to do the exercises

Mike’s training is very “learn to train” oriented at that stage

- Mike tells his coaches all the time, “*I don’t care if any of these kids get stronger. I could care less. I really care that they’re good lifters*.”

***If they’ve been here 10 weeks, and by the end they can do exercises with correct form: gobble squat, sumo deadlift, do a clean, do a chin-up, and do a pushup ‒ then mission accomplished***

- Peter finds all of that fantastic

**It flies in the face of what many people think, which is, “*****Oh my god, an 11-year-old lifting weights? It’s going to stunt their growth, Mike. Aren’t you crazy?*****”**

- Mike literally wrote that down, it’s funny
  - That was in his notes in the beginning about the misconception stuff
  - We’re still dealing with this stunted growth thing
- *The New York Times* did an [article](https://archive.nytimes.com/well.blogs.nytimes.com/2010/11/24/phys-ed-the-benefits-of-weight-training-for-kids/) where they tried to pull the string on where the stunted growth thing came from
  - The only study they could find was on Japanese forced child labor
  - Kids who were forced into child labor tended to be smaller than their age-matched peers; and they were malnourished
- But you still have doctors talking about growth plate stuff

***There’s no evidence of growth plate damage in kids who lift weights***

- Gabrielle talked about gymnastics
- Mike always tells people that figure skating and gymnastics are 10,000x more aggressive than anything we would do in the gym
  - It’s not even good for kids when you look at what they’re trying to do with these young bodies: the rotation, spin around 3x and land
  - In the gym, he’s going to ask a kid to hold 10 lbs. and squat up and down

Peter hasn’t pushed any of his kids

- Peter’s daughter decided at some point she wanted to start lifting greats
- The boys like to come in the gym and he plays goofy games with t hem

Jaco and Leif have this fun little card game they play

- It’s basically like you designate what’s a spade, what’s a heart, what’s a diamond, etc.
  - You pick an exercise, like this is a pushup, this is a burpee, this is a sit-up
  - Then if you flip a 10, you do 10 of that thing, you do 10 of them
  - If you get a 7, you do 7 of them
- They’ll come into the gym with us and play that game

The problem with the boys is they want to “one-up” each other

- Once one of them goblet squats this amount of weight, the next guy wants to go to the heavier kettlebell and the next guy wants to go to the heavy kettlebell
- Peter gets a little worried because he sees their form deteriorate
  - They go into what he calls “turtle back” ‒ they go from lumbar extension, they start getting into lumbar flexion

**What advice would you have for trying to help little boys who want to start lifting, but you just want them to develop the form?**

Jeff Cavaliere

- It’s funny because if you were to ask them to jump onto something or even to walk upstairs two steps at a time, their form usually is going to look quite good when it’s just a naturally occurring activity that they’re doing in their life
- When you then ask them to do an exercise a pushup
  - If they were to get themselves off the floor, it would probably look a lot prettier than it does when they ask them to do a pushup
  - Their ass is up in the air, their shoulders are wide, they’re kind of moving in all different kinds of segments
- It’s this disconnect

**⇒** It’s not that they lack the athletic skills or the strength to do what it is you’re asking them to do; they lack the awareness of what it is you’re asking them to do

- When it’s packaged as an exercise, they’re not really sure what that is

***It’s our responsibility to make it easy to understand and tell them where they’re supposed to be feeling it***

The #1 question people ask when they’re starting an exercise program (anyone, not just kids)

- What am I supposed to work?
- What am I feeling here?
- Where am I supposed to feel this?
- Because if they’re not feeling it there, what do they have to do to get it to feel it there?

Kids need to learn the proper form and biomechanics of how to do the exercise

- Kids possess a lot more athletic skill and natural abilities than we give them credit for
- When we just have them start doing exercises, that break down

***Take the time to do the exercises right ‒ start with bodyweight and have them learn the mechanics of that***

- The [drop squat](https://youtu.be/Ud9hEOxJMpQ?si=uWo4J-1UI17j5A-X&t=153) is where they can add weight and learn better than it could be if they were trying to learn a body weight squat
  - That actual implement would assist them in learning how to do it properly because it’s going to take their center of mass straight down

***Jeff has worked with kids in the 11 to 12-year-old bracket, and that’s what we try to focus on learning the movement, go slow (don’t speed through it)***

**⇒** Speed is something that usually breaks down in any attempt at good form

- Learn the movements and then we could always speed them up and we could always add weight
- But if you don’t learn the form, you’re going to basically set up a foundation that’s going to ultimately crack
- Especially if they get away with that for their teen years and now they’re in their 20s, and then really now that competition starts to kick in and competing with your buddies and then things get really ugly

**Are either of you guys doing sports specific training for these 12-year-olds?**

*For example, if you’ve got a 12-year-old who’s a pitcher versus a 12-year-old who’s a basketball player, are you having them do different exercises?*

Mike Boyle

- Nothing

“*I always say sports specific training is bullshit. It’s absolutely nonsense.*”‒ Mike Boyle

- If you want to go get better at baseball, then go play baseball
- If you come to the weight room, Mike has trained guys in every major professional sport and it’s at most 80/20, probably 90/10
  - 90% of what we do is the same
  - 10% of what we do is different
  - And that 10% is totally irrelevant to a 8, 9, 10, 11, 12-year-old (it makes absolutely no difference)

Peter finds that counterintuitive

- He would’ve thought that if you’re a pitcher, you’ve got be taking more care of the rotator cuff than maybe the guy who’s the hockey player

Mike explains

- That would be the 10%: the 10% with baseball would be that shoulder care stuff that you might not really worry about with your hockey players or your football players. That’s where your difference in program would be like that one spot (the rotator cuff)
- But with kids, Mike looks at it thinking, “*You shouldn’t be a pitcher. You’re not a pitcher, you’re a baseball player. And you might end up being a catcher. You might end up being a shortstop*.”
- Because [Nomar Garciaparra](https://en.wikipedia.org/wiki/Nomar_Garciaparra) went to Georgia Tech and tried to kick on the football team, and he loves soccer
  - He married [Mia Hamm](https://en.wikipedia.org/wiki/Mia_Hamm); he’s a huge soccer fan
  - Mike used to train him, and he told Mike one time, “*I would absolutely be playing soccer if I didn’t live in the United States. But I realized the best use of my athleticism was Major League Baseball. And that playing in the MLS would never have given me the type of career that I would’ve had in Major League Baseball.*”

> “*Most every great athlete that I’ve seen was a great multi-sport athlete, but we’ve got this self-fulfilling prophecy now of specialization*.”‒ Mike Boyle

- People point to [Tiger Woods](https://en.wikipedia.org/wiki/Tiger_Woods) as an example of specializing
- If you can find one specialist, Mike can find you 1000 generalists who have all achieved
- But you continue to use the specialist as the example because that’s what you want to believe as achievement oriented people

**⇒** For kids, it’s the polar opposite: for them to be great at something down the road, they probably need this super broad based skill set

- The base of the pyramid versus the height of the pyramid: the bigger the base, the larger the height
- If you build an obelisk out of the gate, you’re probably not going to accomplish much

Jeff Cavaliere

- [Carl Crawford](https://en.wikipedia.org/wiki/Carl_Crawford) didn’t get those scholarship offers for 3 different sports because he started playing at 18 or 17
  - He obviously was playing all those sports at a young age and developing all those athletic skills to where he could select the one that was most appropriate for him, either financially or…

Mike agrees

- Carl Crawford was the best
- Some of this is genetic lottery
- Carl could do a standing backflip at 230 lbs.
- He’s still the most athletic person Mike has ever seen, but he would’ve been that in any number of sports
- He doesn’t buy the argument of specialization
  - The fact that he chose baseball
  - Europeans specialize in soccer ‒ they don’t have the choices that we have over here
  - We’ve got a lot of opportunities that maybe aren’t present in other countries, so people will cherry-pick because they want to support their thesis

## How to foster healthy habits and an interest in fitness beyond playing sports [A: 2:00:00, V: 2:14:32]

Peter points out

- Virtually no kid is going to be a professional athlete

**Peter’s interest is in, how do you use the interest in sports first to fuel the spark that says lifelong activity is an important pillar of health?**

- Second, how do I make sure that when you are done playing sports [you remain active]?
  - Which for most people is the end of high school
  - There’s a narrow subset that’ll say it’s the end of college, and then there’s virtually nobody who’s playing sports after that.
  - Because to your point, pickleball with your buddies on Sunday, that’s not sports

***So we all stopped playing sports pretty young, and yet we are going to need to train for the rest of our lives***

*How do we use youth sports as a tool to set you up to be an athlete for life where the sport changes to life?*

Mike Boyle

***Sports can be used to teach life lessons***

- They say sports can build character or can build characters
- Do you have to use it to build the kid’s character?
- And sometimes that may be saying you’re not just going to get what you want
- For example, a kid likes baseball, but we’re going to play soccer in the spring because we think they need to be exposed to more things
  - And the kid learns that lesson
- Sometimes kids learn this micro focus really early on, and then later on when they don’t achieve, they think, “*Oh, I wish I’d done more things. I wish I’d sampled more. I wish I’d explored more*.”
- It’s looking at the real body of evidence versus looking at the evidence that’s presented to you by the person who’s trying to get your money (which is what usually happens now)

Jeff Cavaliere

- Where we’re going off track: coaches and parents are overemphasizing the importance of what it is children are actually competing in
- As Mike pointed out: because of money that we have all these additional leagues throughout the year
- But it’s also because everyone thinks their kid’s going to be a pro (they’re not)

Peter points out: people don’t want their kid to be left behind

Jeff Cavaliere

- There’s all these social pressures behind this feeding into the problems that we see
- This is taking away from the fact that this is introducing lifelong habits
- To the point where it’s degenerating something that should be very positive into something that becomes, at worst, destructive

***You’re overdoing something, and you’re actually a lot of times also making a lot of these kids hate athletics by the time they’re 17, 18, 19***

Peter agrees

- Peter can’t tell you the number of people he’s met who grew up with collegiate swimming and now cannot stand swimming
- It’s such a shame because swimming is, while it’s not good for bone density, it’s pretty much good for everything else
- Peter adds, “*It’s not the only exercise you should do, but boy, if I think about if there’s one exercise I could insert into everybody’s life, it would be some amount of swimming*.”

Mike Boyle agrees

- Swimming was his best sport
- He went to the first swimming meeting at Springfield College
- He still remembers [Red Silvia](https://en.wikipedia.org/wiki/Charles_Silvia) (famous Division III coach) ‒ the first words out of his mouth were, “*The first practice is at*”
  - Twice a day, before school and after school
  - Mike was thinking, “*He’s talking per day here, right?*”
- Mike sat politely through the whole meeting like this and nodded and went to the football meeting and tried out for freshman football because there was no way he was going in the pool twice a day
  - It was the end of his swimming career
- Now he has terrible shoulders, and he can’t stand swimming because it hurts

Gabrielle Lyon

Gabrielle shares about her kids, “*Maybe it’s not a standardized training program. They’re in there, they’re doing stuff with us every day*.”

- Her kids are 4 and 5 and they train with her
- They might not be doing the same lifts, but we let them play with a kettlebell, pick things up, put them down, and we let them run

***We let our kids do things that they would physically be able to do without a lot of queuing***

**⇒** Thinking about some of the data on tendon health, we know that the earlier people start, the better and more resilient those tendons are

- Because they’re not starting later in life, not getting injured
- The earlier they start, the better
  - This might be counterintuitive because we’ve all heard how kids shouldn’t lift weights or train
  - Maybe it’s not a standardized training program, but they’re in there doing stuff with us

## Something each guest has changed their mind about in the last five years [A: 2:04:00, V: 2:19:12]

**If you think back to the last 5 years, is there something significant you have changed your mind on that has changed the way you behave, the way you help other people?**

Gabrielle Lyon shares, “*I don’t think body fat percentage is nearly as important as we think it is, I think that it is going to be somewhat of an outdated metric*.”

- She believes that [intermuscular adipose tissue (IMAT)](https://en.wikipedia.org/wiki/Intramuscular_fat) is going to be much more predictive of disease
- Gabrielle interviewed [Melanie Cree](https://som.cuanschutz.edu/Profiles/Faculty/Profile/22449) on her [podcast](https://youtu.be/A4riq7IyY2g?si=UlG1QZtEjV0gjQv2)
  - We were talking about [PCOS](https://en.wikipedia.org/wiki/Polycystic_ovary_syndrome) and Gabrielle was thinking: metabolic PCOS, what is the body fat percentage that’s going to change the outcome?
  - Melanie looks at her, she goes, “*Gabrielle, it has nothing to do with body fat percent. It had to do with their intermuscular adipose tissue.*”

***Intramuscular adipose tissue is going to be an upcoming theme. It’s much more specific to insulin resistance and these metabolic outcomes that we care about.***

Peter points out: this can be measured easily with CT scans and with MRIs, but it’s difficult with DEXA

Peter asks, “*Is ultrasound viable? Obviously you wouldn’t be able to get whole body, but you could sample the quads.*”

- Yes

**⇒** That would be the canary in the coal mine: if you’re accumulating intramuscular fat in your quads

Gabrielle Lyon

- But that would be difficult to test
- MRI seems to be where a lot of the data is
- We’re not there to measure it
- This is something that we are going to see so much more of, and we are all focused on a muscle-centric approach

***For the last 50 years it’s been all about obesity, and it’s almost that we’re looking where it’s obvious, but it doesn’t mean that that’s where it’s effective***

Peter agrees

- Pharmacologically, he thinks a muscle-centric approach is the next frontier
- What the [GLP-1 agonists](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist) have done over the past 5 years with the introduction of the third and fourth generations of those drugs (the first two were largely failures) is we’re at a point where people can see that you can address the crisis of overabundance from a nutrition standpoint

People realize the new problem that is yet to be addressed is [sarcopenia](https://en.wikipedia.org/wiki/Sarcopenia)

- When Peter is looking at what’s at the leading edge in the frontier of biotech right now, it’s all around anti-sarcopenia drugs

***We have another great drug that works against sarcopenia: it involves holding iron and eating certain types of foods***

> “*People are waking up to the idea that it’s not enough to solve the adiposity problem. You must address the sarcopenic problem.*”‒ Peter Attia

*What about you, Mike? What have you changed your mind on?*

Mike Boyle

- Digestive health
- He had a bowel resection 9 months ago (they took a foot of his colon out)
- He did a presentation for his staff called, *You Don’t Know Shit*

***Digestive health is the most neglected area of health right now because we don’t want to talk about it (it’s uncomfortable)***

- Until you experience it firsthand, you don’t realize **how important fiber** is
- How important water is: **chronic dehydration** seems like it’s really not a big deal, but it suddenly it’s a big deal

Mike’s dumpster analogy

- You have a dumpster your whole life that’s out in the back of your house and it just gets emptied all the time, and then suddenly one day you realize that they can’t empty the dumpster anymore
  - Like I’m in trouble
  - And that’s us
- We’re worried about our muscular system, we’re worried about our nervous system, we’re worried about our endocrine system, and our digestive system is just this thing that’s supposed to be this dependable system that’s just going to take care of us forever
- Then suddenly in our 50s and 60s, it starts to fail and we don’t want to talk about it
- Mike was in the hospital ‒ it was a major surgery to remove a foot of his colon and put it back together again

***Mike now takes a fiber supplement, he puts fiber in his shakes***

**⇒** People are way more fiber deficient than they are protein deficient

- They’re going to suffer the effects way down the road and it’ll be too late for them to realize

Mike’s advice, “*Drink more water, eat more fiber, because you don’t want a bowel resection.*”

*What about you Jeff?*

Jeff Cavaliere

- Jeff has twin 9-year-old boys, and in the last 5 years, they’ve gone from 4 to 9
  - Mom was definitely the favorite for the 1st 4 years, then he stepped in and became the fun guy
- He’s realized through their interactivity with him to appreciate things he didn’t appreciate before
- In the first half of his adult life, Jeff was focused on professional achievement
  - Whether it be working for the Mets or starting his business
    - Going all hours of the night to try to build a business

***Jeff has really learned to better prioritize his time with his kids***

- To the point where it’s difficult for him to make travel plans to do podcasts because he really wants to be around them
- His boys are on the spectrum and he has really learned to appreciate their wins every day
- He doesn’t take anything for granted
- If the situation was different, he probably would’ve continued to work, work, work

From a professional standpoint, one of the things that’s overlooked is **balance training**

- It’s an area that people are going to probably have to spend a little bit more time focusing on
- Like digestive health, it’s another one of those things that’s going to get worse as you get older for a number of reasons
  - 1 – Your reaction times will get worse
  - 2 – Your proprioceptive sense is going to get worse, which is essentially your sense of body position
  - 3 – Your strength is going to get worse inevitably decade by decade
- They talked earlier about the fear of Achilles tendon injury

**⇒** 20-30 years from now, our biggest fear should be falling

- Because when you fall, you’re likely going to live a pretty difficult end of your life and it might lead to a much faster end of life

***Training balance is another one of those things that’s going to have to get sectioned into that 5 minutes of extra work that you’re going to want to do for yourself***

**Example of a balance exercise**: standing on one leg and drawing an alphabet with your other foot

**⇒** The most important thing when you’re training balance is to close your eyes

- When you don’t close your eyes, you’re actually one dimensionally creating an environment that’s not actually what we’re going to face
- Most people fall in the dark because they don’t have that visual feedback to correct
- By the time you send that signal down to your ankle to make an adaptation, it’s too late
  - Or our reaction times are delayed too

***Balance is a skill you can improve by working on it***

- Jeff has noticed all of these things happening, including worsening eyesight

Jeff’s advice, “*Making a dedicated effort is something that I think people should probably invest some time into because it’s well worth the investment for that long range safety.*”

**Peter’s takeaway**

- The theme here is we all agree on the gravitational pull of aging
- Despite the fact of what some of the popular biohackers might have you believe, none of us are getting out of this alive
- Each of us can remember what it was like to be 10 years younger regardless of whatever age we are today
- But this idea is: you do have a choice at the rate at which this glider is going to come down
  - The glider will come down. Gravity always wins.

***You can train to reduce the rate of decline ‒ the training has to be specific***

- It’s not obvious or intuitive that you should do some of these exercises

A lot of the things that you guys have talked about today are exercises Peter just loves

- The front foot on a 45 pound plate, putting the front foot up there, going into a lunge, taking a plate and doing little twists
  - The amount of stress that that puts on the proprioceptive capacity of that front foot is insane
  - What a dumb looking, unsexy exercise that never shows up in the mirror and yet what a phenomenal exercise
- Peter agrees 100% on all of these balance drills with eyes shut
  - It is frustrating to be on one foot with your eyes shut
  - Third layer is to turn your head when you’re doing that
  - You don’t want to do things you suck at, but you kind of have to do this

Peter adds, “*I just hope that people realize that ignoring it won’t make it less likely.*”

- It’s a relatively small price to pay
  - You’re not asking people to be in the gym 12 hours a week

***If someone could give 2 great hours a week in the gym***

- It breaks Peter’s heart that people say, “*It’s too late.*” or “*It’s too hard.*” or “*I’ll do it tomorrow*”
  - For whatever reason
  - For whatever belief system

Peter appreciates this conversation even though we didn’t cover a single thing he had written down

- We talked about good stuff
- He wishes they had another 3 hours

---

## Selected Links / Related Material

**Muscle-centric medicine**: [Muscle-Centric Medicine®](https://drgabriellelyon.com/muscle-centric-medicine/) | [1:15]

**Gabrielle’s book**: [Forever Strong: A New, Science-Based Strategy for Aging Well](https://www.amazon.com/Forever-Strong-Science-Based-Strategy-Aging/dp/1668007878/ref=sr_1_1?crid=2XSB91ARHLOAN&dib=eyJ2IjoiMSJ9.tk-qlP5uJdIuh4JEA6MRnqeZW324Hx_wlgqJjqTYX2nXYYu8CYYGF-CBSJAXvEnilNMh7vzrBe4rAZPvWZYih8kVPrm9TBbsiARO430xJx7HGLRLRVPjQ2RZrsp171BgkvA-TK7AOI4coVljFJ-zj9I3Xp4su0MBNEelc8fOJbi92DINer9YdErwl2R4MCyA6JI1Qmp_yVujFzBO7EwGYLttZVEotWrRHmWnst0MGm4.X7DNm71Os0HwDZIVRc_SvEgRq-RADS02B-Rn2rI9ytQ&dib_tag=se&keywords=forever+strong&qid=1754337180&sprefix=forever+strong%2Caps%2C116&sr=8-1) by Gabrielle Lyon (2023) | [1:15, 5:00, 1:45:30]

**Jeff’s YouTube channel**: [ATHLEAN-X](https://www.youtube.com/@athleanx) | [4:30]

**Playbook that goes along with Gabrielle’s book**: [The Forever Strong Playbook](https://www.simonandschuster.com/books/The-Forever-Strong-PLAYBOOK/Gabrielle-Lyon/9781668085622) by Gabrielle Lyon (2026)

**Gabrielle’s recent paper on the relationship between sexual function and muscle mass**: [Exploring the link between muscle quality and erectile dysfunction: assessing the impact of mass and strength](https://pubmed.ncbi.nlm.nih.gov/40684267/) | *Sexual Medicine Reviews* (M Duan et al. 2025) | [5:00]

**Jeff Cavaliere’s YouTube channel**: [ATHLEAN-X](https://www.youtube.com/@athleanx) | [7:30]

**Mike’s book recommendations to build the attendance habit**: [21:15]

- [Never Lose a Customer Again: Turn Any Sale into Lifelong Loyalty in 100 Days](https://www.amazon.com/dp/0735220034/?bestFormat=true&k=never%20lose%20a%20customer%20again&ref_=nb_sb_ss_w_scx-ent-pd-bk-d_k0_1_17_de&crid=38WFLJBX02QTB&sprefix=never%20lose%20a%20cust) by Joey Coleman (2018)
- [Unreasonable Hospitality: The Remarkable Power of Giving People More Than They Expect](https://www.amazon.com/Unreasonable-Hospitality-Remarkable-Giving-People/dp/0593418573/ref=sr_1_1?crid=21GR6A0DLS6W9&dib=eyJ2IjoiMSJ9.CaG7MeqWeyBrb6iCrqmf8DxrtfsWvV4gi-GpaQaAPuzo0P4Evek2fTnFMblc5eIL3gEm-cQeEIM8C0qb2xbO2-qYvSIy3yiOaH3tyDblvuym5dGwiNe4OCgC9s2--ePfdkBOzDK_R_Kf7h1lXRjKhOI72SCwsDfkuiUJjGSg_5Bip7va49tv4RdQQzSw2chmKyYqXo8oWcJiJhjzK8KnB-jJSg-BpcKkPOgTIfIC22Q.NBvJxnV0r_9InQo2b3HPu4TDmkrytwE6c2F37kB_vQ4&dib_tag=se&keywords=unreasonable+Hospitality&qid=1754400466&sprefix=unreasonable+hospitality%2Caps%2C95&sr=8-1) by Will Guidara (2022)

**Charlie Francis Training System**: [Charlie Francis Training System](https://www.amazon.com/Charlie-Francis-Training-System-ebook/dp/B008ZK0WR8/ref=sr_1_1?crid=2BE3UF5OSVYRG&dib=eyJ2IjoiMSJ9.OAlSZ6SjZuLjYJMp25YNvDhnKU4jRLW0DXQhWk1m63p7QjmQuMm4aHFGYgjKjjWdoPJgnb7Y2xUO32cQFk_hgm83iGiI6iHyif1WEu3PDRh4m0V3eZQPFOQnvxSK5kAscHT6PCg9YCPAPcgJKwGblrihGmkvhCGTnLT8sGYefQo.Vm_ZghSZUzp14-ZGNMUQrcp1guHBWSovqmIQuB6uNDk&dib_tag=se&keywords=Charlie+Francis+training+system&qid=1754423803&sprefix=charlie+francis+training+system%2Caps%2C236&sr=8-1#detailBullets_feature_div) by Charlie Francis (2012) | [1:00:00]

**Mike’s article about squatting**: [More On Why We Don’t Squat](https://mboyle1959.wordpress.com/2016/01/23/more-on-why-we-dont-squat/) | Mike Boyle’s [Strengthcoach.com](http://strengthcoach.com) (2016) |  [1:14:15]

**Mike’s article about not exercising through pain**: [Does it hurt](https://www.strengthcoach.com/resource/62c890931ce9f0e6260935ad) | Mike Boyle’s [Strengthcoach.com](http://strengthcoach.com) | [1:41:00]

**Episodes of** ***The Drive*** **with Andy Galpin**: [1:47:00]

- [#239 ‒ The science of strength, muscle, and training for longevity | Andy Galpin, Ph.D. (PART I)](https://peterattiamd.com/andygalpin/) (January 23, 2023)
- [#250 ‒ Training principles for longevity | Andy Galpin, Ph.D. (PART II)](https://peterattiamd.com/andygalpin2/) (April 10, 2023)

**Article debunking the myth that lifting weights is harmful for kids**: [Phys Ed: The Benefits of Weight Training for Children](https://archive.nytimes.com/well.blogs.nytimes.com/2010/11/24/phys-ed-the-benefits-of-weight-training-for-kids/) | *The New York Times* (Gretchen Reynolds November 24, 2010) | [1:53:00]

**Gabrielle’s podcast with Melanie Cree**: [The Science of Optimal Hormone Health | Dr. Melanie Cree PHD](https://youtu.be/A4riq7IyY2g?si=Y6WyNgw2RnCGvEbA) | Dr. Gabrielle Lyon (April 15, 2025) | [2:05:15]

---

## People Mentioned

- [Charlie Francis](https://en.wikipedia.org/wiki/Charlie_Francis) (1948-2010, Canadian Olympic sprinter and sprint coach) [58:15]
- [Doug Paddon-Jones](https://www.utmb.edu/scoa/news-and-events/2022/05/20/in-memoriam-doug-paddon-jones-phd-facsm) (1969-2021, Professor of Nutrition and Metabolism and the Sheridan Lorenz Distinguished Professor in Aging and Health at the University of Texan Medical Branch at Galveston, expert in muscle mass regulation and function) [1:12:45]
- [Andy Galpin](https://www.andygalpin.com/) (Executive Director of the [Human Performance Center](https://www.parker.edu/human-performance-center/) at Parker University, expert in strength and conditioning [1:46:45]
- [Red Silvia](https://en.wikipedia.org/wiki/Charles_Silvia) (All-American competitive swimmer for Springfield College, and a Hall of Fame swimming coach for Springfield from 1937 through 1978) [2:03:30]
- [Melanie Cree](https://som.cuanschutz.edu/Profiles/Faculty/Profile/22449) (Professor of Pediatrics-Endocrinology and Director of the Multi-Disciplinary PCOS clinic at the University of Colorado Anschutz Medical Campus) [2:05:15]

---

##### Gabrielle Lyon, Mike Boyle, & Jeff Cavaliere

**Gabrielle Lyon**

Dr. Gabrielle Lyon™ is an accomplished physician and the New York Times Best-Selling author of [FOREVER STRONG: A New, Science-Based Strategy for Aging Well](https://www.amazon.com/Forever-Strong-Science-Based-Strategy-Aging/dp/1668007878/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=AUTHOR&dib=eyJ2IjoiMSJ9.2nN0ZDG57Y0D-PSgrsqmkUuHG_YfWAhdYJFi2kr3WAkiMUSPkoNP9ZHFs70nZWaiqmeyRY4UskwcQdEaPH_CBuAP6F8yfJGh-XGjBQPyg7g.P1QFuhvRDG-BGroyCuYh0pdkIpGQuqohKSpa1-2ASSo). At the forefront of modern medicine, Dr. Lyon is leading a revolutionary movement focusing on the body’s largest organ—skeletal muscle. Her mission is to promote longevity and combat the pervasive threats of obesity, heart disease, and diabetes by supporting muscle health.

Dr. Lyon’s educational and research background includes dual clinical fellowships in geriatrics and nutritional sciences at Washington University, along with undergraduate training in nutritional sciences at the University of Illinois. A highly sought-after educator and consultant, she is an authority in the practical application of protein types and levels for health, performance, aging, and disease prevention. Dr. Lyon also works closely with members of the United States Special Operations Forces.

Through her thriving [private practice](https://drgabriellelyon.com/muscle-centric-medicine/), [TEDx Talk](https://youtu.be/rvHfNEX09Iw?si=9Q4qxkpROkiO1_qQ), [YouTube channel](https://www.youtube.com/@DrGabrielleLyon/featured), [podcast](https://drgabriellelyon.com/podcast/), online community, and bestselling book, Dr. Lyon is dedicated to empowering people to foster strength and well-being in the weight room and in their daily lives and communities. [[DrGabrielleLyon](https://drgabriellelyon.com/about-us/)]

Facebook: [Gabrielle Lyon](https://www.facebook.com/gabrielle.lyon.754/)

Instagram: [drgabriellelyon](https://www.instagram.com/drgabriellelyon/?hl=en)

LinkedIn: [Dr. Gabrielle Lyon](https://www.linkedin.com/in/dr-gabrielle-lyon-00175a1a8/)

Podcast: [Dr. Gabrielle Lyon Show](https://drgabriellelyon.com/podcast/)

TEDx talk: [The Midlife Muscle Crisis: why we’ve gotten obesity all wrong](https://youtu.be/rvHfNEX09Iw?si=9Q4qxkpROkiO1_qQ)

Website and medical practice: [Muscle-Centric Medicine®](https://drgabriellelyon.com/muscle-centric-medicine/)

X: [@drgabriellelyon](https://x.com/drgabriellelyon?lang=en)

YouTube channel: [Dr. Gabrielle Lyon](https://www.youtube.com/@DrGabrielleLyon/featured)

**Mike Boyle**

Michael Boyle is one of the foremost experts in the fields of strength and conditioning, functional training, and general fitness. Mike served as the Head Strength and Conditioning Coach at Boston University for 15 years, also for the past 25 years was the Strength and Conditioning Coach for Men’s Ice Hockey at Boston University. Mike was the Boston Red Sox strength and conditioning coach in 2013 that won the World Series. In addition to his duties at Boston University and the Red Sox, from 1991-1999 Boyle served as the Strength and Conditioning Coach for the Boston Bruins of the National Hockey League. Michael was also the Strength and Conditioning Coach for the 1998 US Women’s Olympic Ice Hockey Team, who were gold medalists in Nagano and 2014 silver medalists in Sochi, and served as a consultant in the development of the USA Hockey National Team Development Program in Ann Arbor, Michigan.

In 1996, he co-founded [Mike Boyle Strength and Conditioning](https://www.bodybyboyle.com/), one of the first for-profit strength and conditioning companies in the world. Mike Boyle Strength and Conditioning exists for one reason: to provide performance enhancement training for athletes of all levels. Athletes trained range from junior high school students to All Stars in almost every major professional sport. Mike has published a number of [books](https://www.amazon.com/stores/author/B001KE9AVK/allbooks?ingress=0&visitId=def4e056-df37-42fd-ab35-f443288f6c7c) on strength and conditioning including [*New Functional Training for Sports*](https://www.amazon.com/Functional-Training-Sports-Michael-Boyle/dp/1492530611/ref=sr_1_1?crid=1GULQBZ4VMJK0&dib=eyJ2IjoiMSJ9.W-z-YGKZoEOiu3HYmlkH1oEC-8mmVGXqlGGaKr8sZT21b1skb1IOQ4s7GY-HMYX01qDJmXRYctxoXuc1NVC-q5KS7OBJv2Ihm4y1TSRzmqOsyAT18y4nQaeldBggAO1j8MUVdazndagSqltj5KNHiv779ErfShHNR9DKXzYNrbAJd8EpiNGVbhlzaOre-4u9.hAu2AqBMOMuBfl6QDnwzn6TTIrP5wFcYJRzd5EGteOA&dib_tag=se&keywords=michael+boyle+functional+training+for+sports&qid=1755196353&sprefix=michael+boyle+functional+training+for+sports%2Caps%2C101&sr=8-1). Currently Mike spends his time lecturing, teaching, training, and writing [[MBSC](https://www.bodybyboyle.com/team/ownership-group)]

Facebook: [Michael Boyle](https://www.facebook.com/michael.boyle.5264)

Instagram: [michael\_boyle1959](https://www.instagram.com/michael_boyle1959/?hl=en)

Website MBSC: [Mike Boyle strength & conditioning](https://www.bodybyboyle.com/)

Website [StregthCoach.com](http://stregthcoach.com): [Michael Boyle’s StrengthCoach](https://www.strengthcoach.com/home)

X: [@mboyle1959](https://x.com/mboyle1959)

YouTube Channel: [Mike Boyle Strength & Conditioning](https://www.youtube.com/user/mbscvideo)

**Jeff Cavaliere**

Jeff Cavaliere is a fitness guru, social media star, personal trainer, and previous head physical therapist of the New York Mets ( professional baseball team). Jeff earned a Bachelor of Science in Physioneurobiolgy/Premedicine and a Masters degree in Physical Therapy from the University of Connecticut.  He is a Certified Strength and Conditioning Specialist (CSCS) by the National Strength and Conditioning Association (NSCA). Jeff served as both the Head Physical Therapist and Assistant Strength Coach for the New York Mets during the National League East Championship 2006, 2007 and 2008 seasons. During this time, he coached some of the game’s most accomplished players including future hall of fame pitchers Tom Glavine and Pedro Martinez, and perennial all-stars Carlos Delgado, Carlos Beltran, David Wright, Jose Reyes, and Billy Wagner to name just a few. In addition to physiotherapy and training, Jeff is an author and lecturer speaking on topics such as baseball injury prevention, sport specific conditioning, sports training, and injury rehabilitation and prevention. Jeff founded [ATHLEAN-X Training System](https://athleanx.com/ax-training-system) to share methods and techniques used by some of the greatest athletes to forge explosive and strong physiques. This is a science based training system allowing anyone to get the same results as professional athletes. [[AX](https://athleanx.com/the-coach?srsltid=AfmBOor8zfSiDjtrMo-7PiwyeEPgFGPcJUVWhe0iE153rRrKlAd8jxox)]

Facebook: [ATHLEAN-X](https://www.facebook.com/athleanx/)

Greatest Physiques: [Jeff Cavaliere](https://www.greatestphysiques.com/male-physiques/jeff-cavaliere/)

Instagram: [ATHLEAN-X](https://www.instagram.com/athleanx/?hl=en)

LinkedIn: [Jeff Cavaliere](https://www.linkedin.com/in/athleanx/)

Website: [ATHLEAN-X](https://athleanx.com/?srsltid=AfmBOoq9zKx7P0iHogOKOjP73MABKH7omQm4LuLzNZtTcslE3ge_lYdM)

X: [@trainer2thepros](https://x.com/trainer2thepros?lang=en)

YouTube Channel: [ATHLEAN-X](https://www.youtube.com/@athleanx)