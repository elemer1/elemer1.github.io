# #95 – Luke Bennett, M.D.: The emotional, cognitive, and physical demands that make Formula 1 a unique and special sport

**Source:** [https://peterattiamd.com/lukebennett/](https://peterattiamd.com/lukebennett/)

---

In this episode, Luke Bennett, Medical and Sports Performance Director for Hintsa Performance, explains the ins and outs of Formula 1 with a focus on the behind-the-scenes human element, and what makes it so emotionally, cognitively, and physically demanding for the drivers as well as the many team members. Luke first talks about his fascinating background with the Royal Flying Doctor Service in Australia which lead to his current position with Hintsa working closely with F1 drivers to improve their health and performance despite jet-lag and sleep constraints due to an unrivaled travel schedule. Luke also sheds light on the underappreciated level of sheer physical strength and endurance it takes to drive an F1 car combined with the extreme cognitive aptitude, spatial awareness, and ability to navigate a socially complex environment that is needed to be successful as a driver. Additionally, Luke gives an overview of how the F1 season and races work, the incredible advances in car technology and safety measures, and what Luke and Hintsa hope to bring in the near future to the unique and special sport that is Formula 1.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/lukebennett/the_Drive_public.png)

Play

#95 - Luke Bennett, M.D.: The emotional, cognitive, and physical demands that make Formula 1 a unique and special sport

#95 - Luke Bennett, M.D.: The emotional, cognitive, and physical demands that make Formula 1 a unique and special sport

1x15s30s

0:001:38:31

## We discuss:

- What it’s like to be a “flying doctor” in Australia, and how Luke ended up working in Formula 1 with Hintsa [3:10];
- Behind the scenes of Formula 1—crazy travel, jet lag, massive teams, and fascinating human storylines [10:45];
- The incredible physical strength and cognitive aptitude needed to be a F1 driver [19:00];
- The technological leap to hybrid electric engines [29:30];
- The trend towards younger drivers in F1 [32:30];
- Advancements in safety—the history and recent upgrades [36:00];
- How Hintsa manages the athletes through the incredible social complexity of the sport [41:45];
- Explaining the difference between F1, F2, F3, and F4, and the path to reaching the F1 [47:30];
- Comparing F1 in the 60s & 70s to today—Incidences of deaths, number of crashes, physicality of driving, new regulations, and more [53:45];
- Women in F1—Past, present, and future [1:06:10];
- How F1 teams manage their cars and engine over the season, & some new regulations coming in 2021 [1:09:15];
- What insights has Luke taken from his time as a triathlete to working with F1 drivers? [1:12:50];
- How Luke survived cancer, and gained an increased sense of empathy [1:15:45];
- How Luke manages his health against the brutal travel and lifestyle that comes with working in Formula 1 [1:19:40];
- New training techniques, technology to monitor the physiology of drivers, and other things Luke is hoping to bring to Formula 1 [1:22:40];
- How long does it take a driver to learn a new circuit? [1:27:45];
- The incredible emotional control needed to be a successful F1 driver [1:30:00];
- Which F1 teams are showing signs of competing in future seasons? [1:32:15]; and
- More.

§

## Show Notes

## What it’s like to be a “flying doctor” in Australia, and how Luke ended up working in Formula 1 with Hintsa [3:10]

**What is a flying doctor?**

[Royal Flying Doctor Service of Australia](https://en.wikipedia.org/wiki/Royal_Flying_Doctor_Service_of_Australia)

- Australia is the size of Western Europe, yet only has 2 million people
- And most of them are in [Perth](https://en.wikipedia.org/wiki/Perth)
- It doesn’t make economical sense to build and fund big hospitals all around the country
- Instead, the Royal Flying Doctor Service has set up small bases where you’d have a crew of a doctor, a nurse, and a pilot flying to retrieve patients, then taking them to the capital city (Perth)
- Often, a patient is at best 3-4 hours away from help and even a full day away depending on location
- Childbirth can be tricky and Luke had to learn obstetrics “on the fly”
- Locally, there’s reasonable basic resuscitation equipment in these small nursing posts=

*Where is Luke from?*

- Grew up in Brisbane and live more recently on the sunshine coast. Beautiful place called Noosa Heads.

*What drew Luke to this flying doctor stuff?*

> “It was really the nature of the work that attracted me to Western Australia, and it’s a beautiful part of the world and it’s amazing. Remote desert and coastal scenery up there, and it was just a new adventure and something that I look back on as probably the most professionally satisfying part of my career clinically so far.”

**Luke now works for** [**Hintsa**](https://www.hintsa.com/)

- Before that, Luke did a lot of  volunteering to work track side doing trauma and rescue for different motor sport events (such as the Australian Grand Prix in Melbourne)
- During that time, he met [Adam Costanzo](https://www.linkedin.com/in/adamcostanzo/?originalSubdomain=au) (who was Lewis Hamilton’s physio)
- Through Adam, Luke met the founder of Hintsa, [Dr. Aki Hintsa](https://fi.wikipedia.org/wiki/Aki_Hintsa), in 2014 and was in the “*right place at the right time*” to take a role with Hintsa

**A little bit about Dr. Aki Hintsa and his philosophy of training**

- [Dr. Aki Hintsa](https://fi.wikipedia.org/wiki/Aki_Hintsa) was a Finnish trauma surgeon doing humanitarian work in Ethiopia in the mid 90s,
- Originally, he was thinking about human well-being through a humanitarian lens
- But met Haile Gebrselassie and other legendary Ethiopian Olympic runners during his time there, and translated some of those principles into the needs of an athlete
- When he moved back to Finland, [Mika Häkkinen](https://en.wikipedia.org/wiki/Mika_H%C3%A4kkinen) asked him to start to support him and his family trackside, and Mika won a couple of world championships with Aki supporting him in ’98, ’99.
- He then became the McLaren team doctor and then famously had long associations with Lewis Hamilton, and Kimi Räikkönen, and Sebastian Vettel, and others

## Behind the scenes of Formula 1—crazy travel, jet lag, massive teams, and fascinating human storylines [10:45]

**Recommended Book**: Peter recommends [Damon Hill’s autobiography](https://www.amazon.com/Damon-Hill-Watching-Wheels-Autobiography/dp/1509831908)

**Recommended Netflix Series**: [Formula 1: Drive to Survive](https://www.netflix.com/title/80204890)

- The release on this podcast episode was to coincide with Season 2 which was released on February 28

*Peter and Luke describe F1 as follows…*

- Peter says Formula 1 is like having a Super Bowl every 2 weeks, says Peter
- “It’s the world’s most interesting and expensive circus, really. It’s endlessly fascinating on the social level, on the human level”, says Luke

**The human element**

- Many people don’t realize the fascinating story lines going on off the track
- “The human stories that are going on behind the scenes is phenomenal”

**Viewers**

- Outside of probably the NFL and the World Cup, F1 races are the most viewed
- 300,000+ people attend the events in person

**Crazy Typical travel schedule & dealing with jet lag**

- Races per season ⇒ There is now 22 races per F1 season
- The races are all over the world making the travel a big challenge for all involved
- “*It’s a great privilege to work in Formula 1, but it’s very, very hard on, particularly, mechanics, engineers, catering staff, people with families at home.*”
- The most brutal time of year is when they have seven or eight long haul flyaway races (back and forth to Asia a couple of times plus Russia)
- Most people have done a dozen long haul intercontinental sectors over the last month or so.
- “This is the time when championships are being won or lost” says Luke
- Luke says **S*****leep management is ke*****y**
- Luke recently listened to the Q&A episodes with [Matthew Walker](https://en.wikipedia.org/wiki/Matthew_Walker_(scientist)) ([Part 1](https://peterattiamd.com/matthewwalkerama/) and [Part 2](https://peterattiamd.com/matthewwalkerama2/)) and says that they try to adhere to as much as possible

–*Narrow window to adjust to the new timezone*

- Often times there is very little time to adjust to a new timezone
- Occasionally they will use a sleeping pill or sleep aid to make sure that at least that first night in the new timezone goes okay so as not to set a terrible outlook and mindset for the rest of the week
- “*But the reality of the schedule, the weekend schedule, the flights that can be chosen, there’s a limited number of flights to take a thousand people into each destination with limited flexibility.*”

**The makeup of the giant teams**

- There are a total of 20 drivers in F1
- 10 teams so 2 per team
- At the factory, there may be 900-1,000 people (at Mercedes, for example)
- And then another 600-800 people building engines for Mercedes in a separate facility
- An average of a thousand people per car up and down the 10 teams (Although there’s a budget cap coming which may reduce that number)

–*How many people travel with the teams to the races?*

- There are about 43 operational people who are allowed to touch the car and interact with the race event itself
- At a typical large event like Monaco or Austin, the traveling staff might be something around 150 per team
- Marketing, communications, and media people in addition to the team’s activities for that week
- Bunch of engineers, catering team, and the truck logistics guys
- Those numbers vary depending on whether its a European event or a long fly away event

## The incredible physical strength and cognitive aptitude needed to be a F1 driver [19:00]

**G forces**

- Drivers currently experience G forces between 5 and 6G at the highest point
  - The final turn at [Monza](https://www.racingcircuits.info/europe/italy/monza.html), for example
- The implications of this mean drivers need to be physically fit enough to resist those forces
  - Example being they have a four kilo head plus helmet and you’ve got to resist that with your neck muscles ⇒ “it’s an extremely physical activity”

> “It’s probably equivalent to doing a pretty intense CrossFit circuit for two hours with a maximum of five or 10-second breaks around it, while someone else is doing CrossFit trying to push you out of the way off your equipment, and someone’s in your ear asking you to solve math equations, and there’s 300 million people watching.”

**Spacial awareness and proprioception**

- Not only is it physically intense…
- But drivers also must have a very special talent for proprioception
- Cockpits are so low
- Can only turn your head a couple degrees in each direction
- Mirrors give very little view

⇒ [Sebastian Vettel Apologises to Lance Stroll for Tagging Him During the Italian Grand Prix](https://www.essentiallysports.com/sebastian-vettel-apologises-to-lance-stroll-for-tagging-him-during-the-italian-grand-prix/)

> “It’s almost unfathomable the way they can race in close quarters, literally millimeter perfect, sweeping the front wheel of one car across and missing the tires of their colleague and the other, so crazy.”

- Peter says watching [Senna onboard laps in Monaco](https://www.youtube.com/watch?v=auXfAHHNSFo) shows this amazing skill
- Luke says **proprioceptive aptitude** separates the great drivers from the good
  - (the good ones sense their adhesion of the car and the track through their back, legs, and connection to the seat)

> “I think the truly great drivers just have this unbelievable level of truncal proprioception and sensory awareness that allows them to feel what the car is doing. I think perhaps if there’s ever a way that we can measure and train that, it might lead to some steps forward in driver skills training.”

**The ability to make complex decisions while racing**

- Drivers not only have to deal with driving the car and everything that comes with that
- They are also having to **listen to and communicate complex situations** over the radio with their team
- On the team level, there’s probably 10 or 20 different radio networks involving all of the key personnel (from the team boss, to the strategist, to the chief engineer, to the individual driver engineers)
- There’s hundreds and hundreds of streams of data, which sort of ultimately have to feed through this one person, which is the individual **driver’s race engineer**
- The art of being a race engineer is being able to not only understand and manage your driver *emotionally*, but to filter that information and deliver it in a way that’s **concise and useful**.

**The complexity of the car**

- Just the steering wheel has 20-25 buttons
- Each control a menu, or submenu on their screens
- The and driver can only be given a limited amount of instruction from the people as to what settings to use
- Drivers are more or less changing the settings of the car between each corner, so that it’s optimized for each particular corner.
- A few of the things they are managing include brake bias, differential settings, and then nowadays they have these modern engines which are “*absolutely incredible hybrid pieces of art*”

**Luke on the incredible cognitive load required from drivers**:

“*The really great drivers not only have this proprioceptive feel, they’ve got a bandwidth access where they can really tune into the car, they can make all these changes fairly automatically around a lap. They have just the experience and the knowledge to understand how the car is going to work. And then, on top of that, they have enough cognitive capacity leftover to sort of sit above the race to understand what their competitors are doing, what is the context of their pit stop strategy, and when they need to push, when they need to conserve tires. So, it’s really an incredible cognitive load, and that’s a big part of what we are managing with our coaching staff across a race weekend*.”

## The technological leap to hybrid electric engines [29:30]

-Prior to 2015, the engines were a pure naturally aspirated, was it a V6

-From 2015 to present, F1 cars have been using electric hybrid engines

- There’s braking energy recovered from the vehicle
- There’s heat energy from the turbocharger
- And these are fed back through a battery to augment the engine power
- About a quarter or a third of the engine’s power comes from this recovered electrical energy

-Drivers now have to figure out how to deploy that energy in the most appropriate way around a lap

⇒ For example,

- how to save the energy for a period where you might be trying to defend from an overtake
- But deploy it in the parts of the lap where it’s going to give you the maximum benefit in terms of lap time
- “It’s just a massive engineering puzzle”

Prior to 2015…

- the thermal efficiency of the F1 engines minimally increased from maybe 20%, 25% to 28% or 30%
- But since 2015, F1 has taken that efficiency from about 28%, 29% to over 50%
- A “quantum leap” in the way engines work

F1 may catch slack for their carbon footprint…

- but this amazing engine technology could be applied to all cars and make a huge impact on the environment
- Peter also points out that they advance **automotive safety** as well

## The trend towards younger drivers in F1 [32:30]

*As the sport gets more complex, why are we seeing a trend towards younger and younger drivers?*

**First**… the gaming culture might play a role

- But now, with gaming culture, a lot of our younger drivers do a lot of gaming and Luke thinks there is probably an element to that.

**Secondly**… in the past, people simply didn’t think you could be a Formula 1 driver at all before the age of 23 or 24

- But once it finally happened, people opened up their mind to the idea
- [Max Verstappen](https://en.wikipedia.org/wiki/Max_Verstappen) started at age 16
- Other teenage drivers: [Lance Stroll](https://en.wikipedia.org/wiki/Lance_Stroll), [Esteban Ocon](https://en.wikipedia.org/wiki/Esteban_Ocon)

**Third**… the cars are less of that brutal, raw, explosive, which required huge muscular power

- It still takes extreme physicality, but perhaps not quite as much as say the “brutal V10 engines”
- “I think that will trend very strongly towards longer careers. So, people will come in early and there’ll be retained for longer. You’ll have to have a much stronger case to bring an unproven rookie into the sport.”

## Advancements in safety—the history and recent upgrades [36:00]

**The Halo**

![](https://peterattiamd.com/wp-content/uploads/2020/02/halo-lukebennett.jpg)

**Figure 1. The Halo first introduced in F1 in 2015 and made mandatory in 2018.** Image credit: [wheels24.co.za](https://www.wheels24.co.za/FormulaOne/f1-cars-to-use-halo-protection-device-from-2018-20170720)

![](https://peterattiamd.com/wp-content/uploads/2020/02/no-halo-senna-lukebennett.jpg)

**Figure 2. Pre-halo (Senna).** Image credit: [autosport.com](https://www.autosport.com/f1/news/135733/10-unforgettable-ayrton-senna-moments)

- Two years ago, the [halo](https://en.wikipedia.org/wiki/Halo_(safety_device)) was implemented
- The halo is a cage-like device that sits over the top of the driver’s cockpit
- F1 cars are typically “open cockpit”
- The halo is this device which has been constructed over the top to protect the head of the driver, which was the one last remaining big vulnerability in terms of safety
- Though Luke was skeptical, the halo has prevented a significant impact to the driver’s head in a few distinct crashes recently
- It’s not “pretty” but it is here to stay
- It’s made with seven kilos of titanium
- You can put a 10 ton load  (a large bus) right on the top without deforming the cage at all
- “Remarkable technology”

**The HANS**

- The [HANS device](https://en.wikipedia.org/wiki/HANS_device) (Head and Neck Support) has been in F1 for about 15 years
- HANS is actually one of several brands that are on the market, but it’s the one used most commonly in open wheel series
- It’s why the driver can’t turn his head very well in Formula 1

![](https://peterattiamd.com/wp-content/uploads/2020/02/physics-of-HANS-device-lukebennett.jpg)

**Figure 3. Physics of HANS device.** Image credit: [caranddriver.com](https://www.caranddriver.com/features/a15121817/the-physics-of-how-the-hans-device-saves-lives-feature/)

![](https://peterattiamd.com/wp-content/uploads/2020/02/F1-driver-wearing-HANS-device-lukebennett-1024x683.jpg)

**Figure 4. Driver wearing a HANS device.** Image credit: [thepitcrewonline.net](https://www.thepitcrewonline.net/2018/07/30/safety-in-motorsports-week-the-hans-device/)

*-What is the HANS doing and how is it saving a life?*

- It’s a carbon fiber device that sits on the top of the shoulders of the driver.
- It has the race harness, the seatbelt straps over the top of the device, pressing it down into the driver’s shoulders, and then the helmet is attached by some very high tents or straps to this device.
- The effect of that is that if the driver has a head on or a rotational impact, the movement of the head, especially the flection of the neck, is greatly limited.
- It has no doubt saved many, many drivers from high cervical fractures
- One potential side effect is that the force transmission down the spine seem to result in thoracic and lumbar injuries a lot more commonly.
- It would be more in a very high speed impact for this to occur
- While not great, it’s much better than the alternative (i.e., high cervical fractures)

**Another example of the incredible space awareness needed for the driver**

- Drivers are almost lying flat on their backs
- The fact that you’re more or less lying flat on your back with limited visibility because of the HANS (and other factors)

> “The modern F1 car is very long and very wide, and very heavy as well, and controlling those cars with limited visibility in traffic is a very underappreciated part of the art.”

## How Hintsa manages the athletes through the incredible social complexity of the sport [41:45]

**Social complexity of F1**

Hinta’s model is to provide each driver with a performance coach (aka trainer or physio)

- Will attend all of the races and train with the driver in between races all year
- Hintsa mainly appoints sports scientists to this role
- Good broad understanding of the physical preparation
- Nutrition
- Training
- Sleep management, and
- The other things that we need to think about across the race season.

-But probably the most important role for the coaches is the **management of the cognitive bandwidth of the driver across a race weekend**

- Drivers will have about seven hours in the vehicle across a race weekend
- In addition to that, there’s ~10 hours of engineering meetings in which they get very, very deep in the data, and the analysis of what’s happened on track.
- Then, endless hours of media or marketing commitments
- And finally, just all managing the politics of any athlete’s career
- In contrast to the NFL or NBA where only 2 teams are playing a game…
- In F1, every two weeks you have 100% of the competitors in the world-all the driver, all the team owners, etc.
- You also have the principal regulators of the sport, the promoters, and all of those people are mingling freely with the media.

> “It does add a real social complexity to what these athletes need to get out and do, which is ultimately drive the car, and our coaches get to know their drivers. They manage a lot of their key relationships. They manage the time of their driver. They will usually develop a role where they can sort of interface between the marketing team and the media commitments and things, and certainly, recognize when the driver needs to be left alone.”

**Video of Senna saying his favorite time racing was karting when there was “no politics”…**

**Even professional athletes are human beings with flaws**

- Regardless of the funding, regardless of the techniques, and the science, and the innovation available, professional sport is just about human beings and all their flaws and faults.
- Peter adds… “even the people who are the best, most of them still have the same sorts of doubts that “normal person” would experience. And you see it across seasons, where people get into slumps and you get a bad bounce. You get things that just don’t go your way for a period of time and all of a sudden it sort of shakes your confidence.”

## Explaining the difference between F1, F2, F3, and F4, and the path to reaching the F1 [47:30]

**The path to reaching F1**

- It is pretty straight forward
- Drivers typically go from F4 to F3 to F2 and then F1
- Drivers in F2 are very much on the radar of the Formula 1 teams and bosses.
- F2 cars a tad slower and less complex in terms of controls (and it gets less complex as you go down to F4)
- The tires, however, and very similar in F2 and F3 so drivers learn that art in those categories
- And typically, how old are the folks in F2 and F3?
- An age range of 16 to early 20s
- Since so few drivers make it all the way, every race is guys racing for their careers (which makes for some exciting events)
- F4 is more or less the graduation point from [karts](https://en.wikipedia.org/wiki/Kart_racing) to open wheel racing
- National F4 champions generally feed through to the higher categories

**How does a kid go from** [**karting**](https://en.wikipedia.org/wiki/Kart_racing) **to F4?**

Typically there are 2 paths to Formula racing

1. A parent with a little bit of disposable money (and prior interest in the sport) will fund their kids hobby… or someone will sort of sponsor them… and hope the develop enough skill to get onto a junior driving team
2. A kid is obviously, outrageously naturally talented and will get picked up by one of the three or four big teams, and inducted into a junior driver program

–*Does it matter where you are from?*

- Europe is the geographical center of the sport
- It’s very difficult to succeed from Asia, or from any of the Americas without ultimately ending up in 3 or F2 in Europe, because that’s simply where the racing is conducted under the nose of the F1 teams.
- It’s very rare since there’s only 20 drivers in F1 so anyone who even gets their [super license points](https://en.wikipedia.org/wiki/FIA_Super_Licence) to be eligible to compete in F1 will have a lot of merit (championships in junior categories)

**Depth of drivers in the sport**

- There is a lot of depth in terms of talent making it very competitive and a compelling storyline
- The [Netflix series](https://www.netflix.com/title/80204890) showcased this competition within the mid-tier of F1 teams
- Luke notes that the Netflix cameras add an extra level of social complexity to the driver’s job, “*having a private conversation in a corner somewhere, and suddenly you find a Netflix boom microphone over your head*”

## Comparing F1 in the 60s & 70s to today—Incidences of deaths, number of crashes, physicality of driving, new regulations, and more [53:45]

**Historical safety and death in F1 racing**

- Back in the 1960s, 70s, and 80s, there was a very good chance you might die racing before you would retire
- There is now some belief that Formula 1 today is so insanely safe to as not be interesting
- D*oes Luke think that that’s true*?

“It’s a really delicate argument because I think if we’re honest with ourselves, there has to be a small element of danger at least to provide that depth of interest in what the drivers are doing. It has to be hard.”

- That said, even though so many advances in the car, track, medical rescue have been made, there is always some “unaccounted for possibility that can still result in a death”
- Just recently a [driver was killed at the F2 Belgian Grand Prix](https://www.bbc.com/sport/motorsport/49537761) in a “nose to side impact”
- Peter will never forget what [Max Mosley](https://en.wikipedia.org/wiki/Max_Mosley) said after Senna’s death,
  - “*The question isn’t, ‘why did Senna crash.*’” (That’s all anybody wanted to talk about) “*The question is, ‘****why did he die****?*’
  - Max’s point was that the sport is being played at the absolute limit of mechanical and human capability so there will always be crashes… but nobody should ever **die** in a crash

> “Let’s be honest, the crashes are a massive part of the appeal of motor sport, especially to the more casual fan. It’s spectacular when a vehicle crashes and there’s parts flying everywhere, and it adds to the drama and the human tension as well.”

**Senna’s death**

- After the 1970s, there were a lot of “low hanging” fruit changes made in terms of safety
- It was 14 years since the last fatality in F1 when Ayrton Senna died in 1994
- “Senna’s death probably had a greater impact on the safety of F1 than any single tragedy in the history of this sport.”
- At Senna’s time, the drivers were sitting much higher out of the car.
- After Ayrton died, that was one of the big innovations, getting the head and the shoulders of the driver better protected with a shroud around the head and the helmet, which limits any sort of intrusion, and the cockpit sides are much higher

*Safety has come a long way*

- In 2010, [Mark Webber had an unbelievable crash](https://www.youtube.com/watch?v=2kNZzqqdhM0) but was able to walk away

https://www.youtube.com/watch?v=2kNZzqqdhM0

> “*It’s very hard to injure yourself in a Formula 1 car.*”

**The amazing G forces of crashes**

- A mandatory check up from the medical staff is when the crash impact is at least 15G
- The real high risk for injury comes when the impact is at least 40Gs
- Interestly, the worst crashes come in good weather, dry tracks on Sunday when the drivers are really pushing the limits in close quarters with other cars
- 90% of “medical incidents” happen in dry weather
- And more than two thirds of the incidents happened on race day (Sunday)
- [Fernando’s massive crash in Melbourne](https://www.bbc.com/sport/formula1/35854879)

https://www.youtube.com/watch?v=J8NGkqCz4qg

**The amazing physical strength needed to drive F1**

- Not only is the incredible G forces a risk hazard
- But it also takes massive amount of physical strength to resist those forces
- After races, drivers “*look as exhausted as someone who’s done two hours of a brutal CrossFit workout*”
- Drivers lose weight from sweating so much during a race

⇒ Example, [Singapore Grand Prix](https://en.wikipedia.org/wiki/Singapore_Grand_Prix) is the archetypal physical race

- Full two hours
- More corners than any other circuit
- All 90 degree turns at moderate speed
- Drivers will often lose 3-4 kilos in weight (6 to 9 lbs)
- Car have a water bottle that might have 1.2 to 1.5 liters of water
- Plus the water gets so hot in the car it’s like “drinking tea”
- The driver error at the end of the Singapore Grand Prix is “quite something to behold” presumably due to exhaustion and dehydration

> “Driver’s coming in flushed and exhausted, and a faraway look in their eyes, and that’s a race where recovery is particularly important.”

**Rule changes to driver’s weight**

- Historically, drivers have always had a pressure on them from the engineering teams to maintain their weight at the minimum possible
- And that was because teams were spending millions of dollars trying to shave hundreds of grams off the car so losing a kilo off the driver is a relatively easy thing for the teams to ask

–*New rule*

- There’s now a [new regulation](https://f1i.com/news/290402-f1-teams-put-80kg-weight-behind-drivers-2019.html) that says the driver (plus his suit and helmet) cannot below 80 kilos… and if they are then it will be ballasted up to 80 kilos
- It basically takes the driver weight out of the equation to a large degree (which the drivers are absolutely delighted with)
  - They can put on a little bit more muscle
  - Nutrition’s just not quite the daily misery that it used to be

## Women in F1—Past, present, and future [1:06:10]

**Women who have competed in Formula 1**

- Over the years, there have been a few women who have competed
- Lella Lombardi scored half a point in the 70s
- [Susie Wolff](https://en.wikipedia.org/wiki/Susie_Wolff) was the first woman to take part in a Formula 1 race weekend in 22 years, when she participated in the first practice session at the British Grand Prix at Silverstone

![](https://peterattiamd.com/wp-content/uploads/2020/02/women-in-F1-lukebennett-1024x543.png)

**Figure 5. Women who have competed in Formula 1.** Image credit: wikipedia.org

**The W Series**

- The [W Series](https://twitter.com/WSeriesRacing?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) is an all-women’s racing series in Europe
- “It’s been really a huge success on many levels,” says Luke, “I look forward to seeing that develop over the next decade or so”
- I think there’s a perception that driving an F1 car is like being a fighter pilot, for example, where I think intuitively men and women should be relatively equal.
- It’s a fine motor and a cognitive skill, but the truth is that as we’ve discussed, Formula 1 is an extremely physical activity.
- I think a woman absolutely can succeed in F1, says Luke
- The main obstacles are
  - 1) a very small pipeline of competitors coming through, and
  - 2) the lower tiers (F4, F3, F2) have cars that are more physical to drive and they’re up against teenage males with differences in risk-taking behavior, testosterone levels

## How F1 teams manage their cars and engine over the season, & some new regulations coming in 2021 [1:09:15]

**A look at horsepower to understand the advancement in engine technology**

- A Formula 1 car today is *less* than a thousand horsepower
- The electrical power makes them very responsive so the the acceleration is staggering
- In 1988, the [MP4/4](https://en.wikipedia.org/wiki/McLaren_MP4/4) that was a 1200 horsepower car (With a manual gearbox)
- And back then, they would use the engine once for an hour and then throw it away— “*the engine was there to be blown up at the maximum speed possible*”
- The advancement towards electrical has a positive environmental aspect which is that the reliability of these engines is unbelievable
- They now only need three engines for the entire season

–*Three engines for the entire season*

- The engine comes in different parts
  - There’s the heat recovery system
  - the kinetic recovery system
  - the battery
- You can replace some of those parts individually without some penalty.
- But basically, you’ve got to do your Friday practices, you’ve got to do your Saturday qualifying, and a third of the races on one engine.
- This was an extraordinary step forward from where we were even from 2001
- Not only is this a cost cutting measure for F1 teams…
- But this is something that absolutely will flow through to the reliability of regular road cars used by the public

**As for tires…**

There’s 12 sets of tires for every race weekend

**2021 F1 rule changes**

- The car is going to have some simplified aerodynamic characteristics
- The engines probably will stick to something very similar to the current formula
- A new budget cap will probably more apply to the teams—what they can do in terms of the number of upgrades, the number of different parts, the level of activity that they can bring into upgrading the car through the season.

–*The new tire regulations*

- Going from 13-inch wheels to 18-inch wheels
- The tire will be a lot smaller in profile
- Bringing in an 18-inch wheel with a very much narrower tire sidewall is going to change everything in terms of suspension, and braking, and aerodynamics over the cars.
- That’s a huge challenge for the engineers that are working on adjusting the car for it as we speak

## What insights has Luke taken from his time as a triathlete to working with F1 drivers? [1:12:50]

In 1985, Luke just happened to watch the Australian Grand Prix

“*I just caught the bug. . .I haven’t missed a race in the 34 years since.*”

**Luke was a triathlete**

- Did his first race in 1988 and
- “struggled through a couple of ironmans”
- Learned a lot about being an athlete actually even by being a hopeless weekend warrior

*-What did you learn from that that translated to what you’re doing today?*

- I have a basic understanding of
  - what it’s like to do a training session that might be a bit of a chore on that particular day.
  - The difference between aerobic and anaerobic training
  - an appreciation for what it’s like to have to stick to a training program, and then compete
- He would do many things differently nowadays in terms of nutrition, sleep, structure of training now, etc.
- For his F1 drivers, Luke relies on the Coaching director, [Pete McKnight](https://twitter.com/petemcknight?lang=en), to implement the technicalities of coaching to the F1 drivers

**Drivers today are more attuned to their health and training**

- Senna was kind of the outlier in the seriousness with which he took his fitness, his training was the stuff of legends
- A big contrast to someone like James Hunt… “*amazing driver, not training*”
- Niki Lauda was another driver who was one of the first examples of somebody who really implemented a serious physical training regimen.
- Michael Schumacher did as well
- In 2020, most of the drivers have a pretty reasonable understanding of what a strength workout is and what their aerobic capacity needs to be to get through a two-hour race (even if they aren’t interested in absolute peak physical shape)

## How Luke survived cancer, and gained an increased sense of empathy [1:15:45]

- 10 years ago, Luke found out he had testicular cancer
- It was non-seminoma with a pulmonary metastasis
- Additionally, he had a “pretty profound” paraneoplastic thrombophilia
- In some cancers, in some people, they’ll get a clotting tendency
- When Luke had permanent catheter implanted to receive the chemotherapy drugs, a “[port-a-cath](https://nurse.org/articles/what-is-a-port-a-cath/)” which sits in the large vein next to the heart, it clotted up completely ([superior vena cava syndrome](https://www.cancer.net/coping-with-cancer/physical-emotional-and-social-effects-cancer/managing-physical-side-effects/superior-vena-cava-syndrome))
- Luke says that while he never felt too much like his life was threatened, it turns out his case was a little more severe than originally thought
- “It was really only at the end of the process that it was absolutely understood to have been a stage 4 tumor”
- (same as Lance Armstrong has which gave him a 50/50 chance of survival)

*⇒ Lesson learned*: **Increased level of empathy for patients**

> “It was an interesting lesson in the realities of being a patient. I think I had always been a relatively empathetic doctor, but just the logistics of having to go to appointments, having to be stabbed with needles multiple times a week, the fatigue of the drugs, having to find a car parking space at the hospital every day. I think it just gives you a great appreciation for the experience of being ill and being a patient.”

## How Luke manages his health against the brutal travel and lifestyle that comes with working in Formula 1 [1:19:40]

-Luke only spent about 40 nights in his home in Switzerland in 2019

–*How does he manage the toll of this type of schedule for himself, and for his team of people at Hintsa?*

- Luke says there’s almost no other job he would accept this demanding of a travel schedule than the one he has
- The passion for F1 is the only thing that makes it worth it

**How he manages his health**:

- Exercise: It’s been really difficult to do any sort of structured, formal physical training.
- Sleep: He does pay a lot of attention to sleep.
  - Really try and prioritize seven or eight hours sleep whatever we do, wherever we go.
- Nutrition: He implements time-restricted eating
  - Inside the paddock there is an abundance of really palatable, excellent food, and team buffets
  - But there are many desserts there which are hard to pass up
- Get outdoors: He tries to get outdoors, get in the sunlight as much as possible

*In summary*:

- Luke has to be a little more careful with respect to sleep and exercise than his default environment is set up for
- It COULD be an extremely unhealthy job if not careful

## New training techniques, technology to monitor the physiology of drivers, and other things Luke is hoping to bring to Formula 1 [1:22:40]

Luke says Formula 1 is the pinnacle of excellence terms of the engineering and the development of the car

But on the human side (i.e., the drivers), there’s still a lot of low hanging fruit, says Luke

1—Luke is now trying to innovate on the “hundreds of scientifically proven interventions that you can make for an athlete”

- But the challenge and the “art” is fitting that into the lifestyle, the travel schedule, the attention span, and interest level of the individual athlete they are working with
- He’d like to do things like improve **cognitive skills**, **eye training**, and **proprioception** (to name a few)

2—Upgrading the physiological monitoring of the drivers

-There’s an incredible lack of physiological monitoring of the driver while in the car being sent back to the paddock

*Why is that?*

**-One**, it’s a simple matter of the regulations

- The race suits and the fireproof underwear that the drivers are wearing are heavily, heavily regulated.
- There’s been a real limitation of what you can attach to a driver in terms of physiological monitoring.

**-Secondly**, teams will not add ANY weight to the car—even a hundred grams of some kind of measuring or monitoring device in the vehicle would not be acceptable

**-Third**, it’s low priority compared to the time pressure that’s involved in just getting a car out on the track and getting it developed

- So the bandwidth for any sort of human innovation has traditionally been relatively narrow.

**-Fourth**, the FIA also mandates that any sort of monitoring on the driver has to be purely for a **safety purpose** so at present, there’s not a lot of interest from the governing body in terms of performance or physiological measurement for understandable reasons.

- In the last two years, for example, a biometric sensor glove was introduced for the drivers so that the track side intervention services can see what’s happening physiologically (HR, for example) to the driver after a crash or impact

*In the future…*

- There may be some pressure from television and digital streaming as well to measure physiological parameters of the driver in the car as well (an idea that has NOT received a warm reception from the drivers themselves)
- That said… “*I think we’ll see more of this. We’re looking at a couple of devices now, which will probably be compatible with the regulations, and we’ll have a couple of projects potentially next year where we’re measuring in the car a lot more.*”

## How long does it take a driver to learn a new circuit? [1:27:45]

Take the [Vietnam Grand Prix in 2020](https://www.formula1.com/en/racing/2020/Vietnam.html), how long does a driver have to prepare to learn that in a simulator?

- Just 6 laps give or take and they are pretty close to on pace
- The simulator is also important … but it’s not the same as being out there sitting in the seat and feeling the forces
- They start the simulator about 10 days prior to race weekend (for a half day or so) which helps with…
  - Learning the particulars of the circuit
  - evaluating other aero parts and other upgrades to the car

*Do drivers learn the circuit in the offseason?*

- At the European circuits, they will have driven most of the circuits many times in the junior categories.
- The long haul flyaway races are where a rookie driver will be encountering the circuits for the first time
- But they have engineering briefings across the weekend to help familiarization
- Then a handful of laps in practice
- By Sunday, they should have a **very limited disadvantage to people who’ve been there before**.
  - Each circuit is different from year to year
  - The adjustments that are being made to the car from corner to corner will change with the characteristics of the car from year to year.
  - So even people who’ve been there before are kind of re-learning how to drive the circuit in this year’s car to achieve the optimal lap time.

## The incredible emotional control needed to be a successful F1 driver [1:30:00]

> “I don’t consider myself one who lacks in cognition, but I could never manage the cognitive load that these guys manage. But then there’s this other piece which is the emotional piece, which is it’s not a sport where getting pissed off does you much good.” —Peter Attia

**Emotional control is incredibly important**

- In the car
  - For making the best decisions with a clear head
- In front of the media
  - For example, an arrogant comment can create an enormous amount of stress next week at the next race, let alone contract renegotiations and fighting for one of those precious 20 seats.
- As the drivers get younger this gets harder…
  - Some F3/F2/F1 drivers are still teenagers
  - Despite the wisdom available to them, there’s a point where a young person doesn’t even have enough life experience to understand the lesson that they’re being given
  - Luke calls it gratifying to see a driver develop through the junior categories and then some point in their early 20s start to draw from the pieces of insight and for it start to come together.

> “And they just have gathered enough experience to understand how all the strands of their behavior, and their approaches to things, and the motives, and the layers of social complexity around them all come together, and can be coordinated in a way that’s to their advantage.”

## Which F1 teams are showing signs of competing in future seasons? [1:32:15]

- Luke seems hopeful that some “mid-field” teams will start to compete at a higher level in 2021
- But Luke points out that with regulation changes, generally the teams with the most resources have an advantage in dealing with the changes

*The bright future of McLaren*

- McLaren has had a massive cultural transformation in the last 18 months yet they’ve made quick progress
- “It has been a surprise to see how quickly they’ve started to turn things around.”
- “You can make a case that the traditional private team that’s not a manufacturer-owned team could be a truly endangered species in Formula 1 now. So, it’s to the credit of everyone at McLaren who’s been able to turn that project around”

§

## Selected Links / Related Material

**Company Luke works for**: [Hintsa Performance](https://www.hintsa.com/) | (hinsta.com) [00:50, 7:15]

**Luke was part of the Remote Emergency Aeromedical Retrieval with the:**: [Royal Flying Doctor Service of Australia](https://en.wikipedia.org/wiki/Royal_Flying_Doctor_Service_of_Australia) | (wikipedia.org) [1:00, 3:45]

**Netflix documentary on Formula 1 that Luke and Peter highly recommend**: [Formula 1: Drive to Survive](https://www.netflix.com/title/80204890) | (netflix.com) [2:15, 11:45, 52:30, 1:34:45]

**Damon Hill’s autobiography, a book that Peter recommends**: [Damon Hill Watching The Wheels: My Autobiography](https://www.amazon.com/Damon-Hill-Watching-Wheels-Autobiography/dp/1509831908) by Damon Hill | (amazon.com) [10:45]

**The Q&A with sleep expert, Matthew Walker, that Luke said he used to help shape his sleep advice to the drivers**: [15:15]

- [#58 – AMA with sleep expert, Matthew Walker, Ph.D.: Strategies for sleeping more, sleeping better, and avoiding things that are disrupting sleep](https://peterattiamd.com/matthewwalkerama/) | Peter Attia (peterattiamd.com)
- [#77 – AMA #2 with sleep expert, Matthew Walker, Ph.D.: short sleep mutants, optimal sleep environment, sleep apnea, & rapid fire questions](https://peterattiamd.com/matthewwalkerama2/) | Peter Attia (peterattiamd.com)

**The two biggest of 10 teams in F1**: [16:45]

- [Mercedes-Benz in Formula One](https://en.wikipedia.org/wiki/Mercedes-Benz_in_Formula_One) | (wikipedia.org)
- [Scuderia Ferrari](https://en.wikipedia.org/wiki/Scuderia_Ferrari) | (wikipedia.org)

**The 2019 Italian Grand Prix when Seb Vettel came back on track without looking left and Stroll almost hit him, and then Stroll did the exact same thing 30 seconds later**: [Sebastian Vettel Apologises to Lance Stroll for Tagging Him During the Italian Grand Prix](https://www.essentiallysports.com/sebastian-vettel-apologises-to-lance-stroll-for-tagging-him-during-the-italian-grand-prix/) | DHRUV GEORGE (essentiallysports.com)  [21:30]

**Onboard camera of Senna driving at Monaco in 1990**: [F1 Classic Onboard: Senna On The Charge At The 1990 Monaco Grand Prix](https://www.youtube.com/watch?v=auXfAHHNSFo) | Formula 1 (youtube.com) [22:45, 57:30]

**Peter mentions a scene in Rush when the character playing Niki Lauda talks about how he was gifted with a great ass**: [Rush (2013 film)](https://en.wikipedia.org/wiki/Rush_(2013_film)) | (wikipedia.org) [24:30]

**The invention of the internal combustion engine ate 1800s**: [History of the internal combustion engine](https://en.wikipedia.org/wiki/History_of_the_internal_combustion_engine) | (wikipedia.org) [30:45]

**Seb Vettel caught on radio sayin’ “bring back the fuckin’ V12s”**: [Sebastian Vettel Team radio AFTER RETIREMENT! “Bring back the v12’s”](https://www.youtube.com/watch?v=e_Piw0hTNNM) | F1Fun4u (youtube.com) [46:30]

**Scene at the end of the “Senna” documentary talking his favorite time racing was when he was karting when there was “no politics”**: [Senna (2010) ending – Ayrton Senna interview](https://www.youtube.com/watch?v=qYYIzDMJbpY) | Fernando Amato (youtube.com) [46:50]

**Only Formula 1 title awarded posthumously**: [Jochen Rindt](https://en.wikipedia.org/wiki/Jochen_Rindt) | (wikipedia.org) [54:00]

**Recent fatality in any of the Formula driving levels was one in F2 when Anthoine Hubert died at the Belgian Grand Prix**: [Formula 2 driver Anthoine Hubert killed in Belgium crash](https://www.bbc.com/sport/motorsport/49537761) | Andrew Benson (bbc.com) [55:45]

**Amazing crash 10 years ago when Mark Webber walked away unhurt**: [Webber crash Valencia 2010](https://www.youtube.com/watch?v=2kNZzqqdhM0) | Nicky Van der Merwe (youtube.com) [58:45]

**Fernando Alonso survives a massive crash in Melbourne a couple of years ago**: [Australian Grand Prix crash: Fernando Alonso suffers huge accident](https://www.bbc.com/sport/formula1/35854879) | Andrew Benson (bbc.com) [1:00:15]

**A rule change in F1 made it so the driver’s weight (plus his gear) had to be at least 80 kilograms**: [What’s new for F1 in 2019? Six changes for the season ahead](https://www.telegraph.co.uk/formula-1/2019/03/14/new-f1-2019-six-changes-season-ahead/) | Luke Slater (telegraph.co.uk) [1:03:45]

**The all-women’s racing series in Europe**: [W Series](https://wseries.com/) | (wseries.com) [1:06:45]

**The horsepower of F1 cars used to be much higher, the example being the MP4/4 in 1988 that was a ~1200 horsepower car**: [McLaren MP4/4](https://en.wikipedia.org/wiki/McLaren_MP4/4) | (wikipedia.org) [1:09:30]

§

## People Mentioned

- [Adam Constanzo](https://cla.tamucc.edu/humanities/history/faculty_pages/costanzo.html) [8:15]
- [Lewis Hamilton](https://en.wikipedia.org/wiki/Lewis_Hamilton) [8:15, 35:00]
- [Dr. Aki Hintsa](https://fi.wikipedia.org/wiki/Aki_Hintsa) [8:15]
- [Haile Gebrselassie](https://en.wikipedia.org/wiki/Haile_Gebrselassie) [9:00]
- [Mika Häkkinen](https://en.wikipedia.org/wiki/Mika_H%C3%A4kkinen) [9:00]
- [Kimi Räikkönen](https://en.wikipedia.org/wiki/Kimi_R%C3%A4ikk%C3%B6nen) [9:00]
- [Sebastian Vettel](https://en.wikipedia.org/wiki/Sebastian_Vettel) [9:00, 21:30]
- [Sid Watkins](https://en.wikipedia.org/wiki/Sid_Watkins) [9:45]
- [Gary Hartstein](https://en.wikipedia.org/wiki/Gary_Hartstein) [10:15]
- [Damon Hill](https://en.wikipedia.org/wiki/Damon_Hill) [10:45, 33:15]
- [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) [11:00, 22:45, 56:30]
- [Matt Walker](https://en.wikipedia.org/wiki/Matthew_Walker_(scientist)) [15:15]
- [Patrick Friesacher](https://en.wikipedia.org/wiki/Patrick_Friesacher) [20:30]
- [Zsolt Baumgartner](https://en.wikipedia.org/wiki/Zsolt_Baumgartner) [20:30]
- [Lance Stroll](https://en.wikipedia.org/wiki/Lance_Stroll) [21:30, 34:00]
- [Niki Lauda](https://en.wikipedia.org/wiki/Niki_Lauda) [24:30, 1:15:15]
- [Lando Norris](https://en.wikipedia.org/wiki/Lando_Norris) [32:50]
- [Charles LeClerc](https://en.wikipedia.org/wiki/Charles_Leclerc) [32:50]
- [Max Verstappen](https://en.wikipedia.org/wiki/Max_Verstappen) [32:50]
- [Esteban Ocon](https://en.wikipedia.org/wiki/Esteban_Ocon) [34:00]
- [Kimi Räikkönen](https://en.wikipedia.org/wiki/Kimi_R%C3%A4ikk%C3%B6nen) [35:15]
- [Jochen Rindt](https://en.wikipedia.org/wiki/Jochen_Rindt) [54:00]
- [Peter Revson](https://en.wikipedia.org/wiki/Peter_Revson) [54:30]
- [Gilles Villeneuve](https://en.wikipedia.org/wiki/Gilles_Villeneuve) [54:30]
- [Anthoine Hubert](https://en.wikipedia.org/wiki/Anthoine_Hubert) [55:45]
- [Max Mosley](https://en.wikipedia.org/wiki/Max_Mosley) [56:30]
- [Jim Clark](https://en.wikipedia.org/wiki/Jim_Clark) [58:00]
- [Roland Ratzenberger](https://en.wikipedia.org/wiki/Roland_Ratzenberger) [58:45]
- [Mark Webber](https://en.wikipedia.org/wiki/Mark_Webber) [1:05:00]
- [Charlie Whiting](https://en.wikipedia.org/wiki/Charlie_Whiting) [1:05:15]
- [Susie Wolff](https://en.wikipedia.org/wiki/Susie_Wolff) [1:06:15]
- [Pete McKnight](https://twitter.com/petemcknight?lang=en) [1:13:45]
- [James Hunt](https://en.wikipedia.org/wiki/James_Hunt) [1:15:00]
- [Michael Schumacher](https://en.wikipedia.org/wiki/Michael_Schumacher) [1:15:15]
- [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) [1:18:15]

§

![](https://peterattiamd.com/wp-content/uploads/2020/02/bio-pic-lukebennett-500x500.png)

##### Luke Bennett, M.D.

Luke is the Medical and Sports Performance Director for Hintsa Performance, a company focused on human well-being and athletic performance with a particular emphasis in motor sport. Luke received his medical degree as well as his master’s degree in sports medicine at the University of Queensland. He then spent seven years training in intensive care before working for six years in Remote Emergency Aeromedical Retrieval with the Royal Flying Doctor Service of Western Australia.