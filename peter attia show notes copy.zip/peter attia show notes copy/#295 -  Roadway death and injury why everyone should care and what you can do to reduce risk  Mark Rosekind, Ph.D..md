# #295 ‒  Roadway death and injury: why everyone should care and what you can do to reduce risk | Mark Rosekind, Ph.D.

**Source:** [https://peterattiamd.com/markrosekind/](https://peterattiamd.com/markrosekind/)

---

Mark Rosekind is an expert on road safety and a policy leader with more than 30 years of experience enacting strategic, practical, and effective data-based solutions that enhance driver and pedestrian safety and health in complex environments. In this episode, Mark delves into the persistent issue of accidental deaths resulting from roadway accidents, a concern for those focused on longevity given its consistent risk throughout life. From exploring statistics on car crashes to identifying the demographics most at risk and the key locations of incidents, he uncovers various risk factors including distractions like smartphone usage, the influence of alcohol and cannabis, the dangers of sleep deprivation, and speeding. Mark also provides practical advice for both drivers and pedestrians to enhance safety, while delving into the potential and challenges of emerging technologies such as autonomous vehicles. Additionally, Mark provides valuable resources for listeners, particularly parents navigating the road safety landscape with teenage drivers.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/markrosekind/the_Drive_public.png)

Play

#295 ‒ Roadway death and injury: why everyone should care and what you can do to reduce risk | Mark Rosekind, Ph.D.

#295 ‒ Roadway death and injury: why everyone should care and what you can do to reduce risk | Mark Rosekind, Ph.D.

1x15s30s

0:002:29:08

## We discuss:

- Mark’s background and education, and the profound impact of transportation accidents on human lives [4:15];
- From sleep science to safety leadership: Mark’s journey in transportation innovation [14:15];
- Stats on transportation accidents and fatalities [18:00];
- Historical trends in road fatalities and the key contributors—impairment, distraction, and more [28:00];
- The demographics of drivers involved in crashes, and the life-saving potential of better driver education programs [34:30];
- The most critical areas where drivers need to be hyper-aware to protect themselves [41:00];
- The role of the National Transportation Safety Board (NTSB) in accident investigations, and the importance of data sources like event data recorders (EDRs) in accident reconstruction and investigations [47:00];
- The dangers of phone use while driving [53:45];
- How drunk driving was addressed through advocacy and legal changes [1:01:30];
- The need to address distracted driving and the psychological impact of distracted driving accidents on both victims and perpetrators [1:07:15];
- Navigating the roads and lowering your risk of accidents: weather, human error, and defensive driving [1:15:45];
- The impact of impaired driving: alcohol, cannabis, prescription drugs, and more [1:26:15];
- Mitigating the effects of vehicle speed [1:38:15];
- The promise and challenges of autonomous vehicles for road safety [1:44:15];
- Automatic emergency braking (AEB): the effectiveness and challenges of implementing AEB as a standard feature in new vehicles [1:53:00];
- Sleep deprivation: the impact of poor sleep, drowsiness, and disrupted circadian rhythm on driving [1:58:15];
- Protecting pedestrians: strategies for reducing the risk of fatal accidents with pedestrians on foot or bicycle [2:02:30];
- Empowering safe driving: essential resources and tips for parents and teenage drivers [2:14:00];
- Promoting a culture of proactive safety: parting thoughts from Mark [2:19:15]; and
- More.

§

## Show Notes

\***Notes from intro**:

- Mark Rosekind is a safety, sleep, fatigue, and policy leader with more than 30 years of experience in acting strategic, practical, and effective database solutions that enhance safety and health in complex environments
- He was the Chief Safety Innovation Officer at [Zoox](https://zoox.com/), an Amazon owned autonomous mobile company from 2017-2022
- He was also appointed the [Distinguished Policy Scholar](https://publichealth.jhu.edu/departments/health-policy-and-management/people/distinguished-policy-scholar) in the Department of Health Policy and Management at the Johns Hopkins Bloomburg School of Public Health between 2020 and 2022
- Previously, he was appointed by President Obama as the 15th administrator of the [National Highway Traffic Safety Administration (NHTSA)](https://www.nhtsa.gov/)
- Before becoming the NHTSA administrator, he was appointed by President Obama and served as the 40th member of the [National Transportation Safety Board (NSTB)](https://www.ntsb.gov/Pages/home.aspx)
  - This is the organization that is always investigating plane crashes, train crashes, and other disasters
- Additionally, Mark previously directed the [Fatigue Countermeasures](https://hsi.arc.nasa.gov/groups/fatigue/) program at NASA Ames Research Center and was the Chief of Aviation Operations Branch in the Flight Management and Human Factors Division
- He earned his Bachelor’s degree from Stanford and his Master’s and Doctorate from Yale University, and he complete post-doctoral training at Brown University Medical School
- In looking at what we internally call the “death bars” and use to identify threats to our lifespan, you may recall that while the “4 horseman” generally get the lion’s share of our attention, there’s always this pesky 5th cause of death: **deaths due to accidents**
  - While we typically speak about 1 subset of those (accidents due to falls, because they disproportionately increase later in life), there’s one cause that seems relatively consistent throughout life: **accidental deaths due to transport**
- Peter wanted to do a deep dive into this topic because when he considers his own mortality over the next decade, this occupies a disproportionate share of what might account for his relative risk of death
  - He knows that for many listeners, that is also true
- In this conversation we talk about Mark’s background which is quite unique in how it led him to become an expert in this
- We look at the statistics of car crashes and how that’s changed over time
- We talk about the groups that are most at risk and the locations where most of these incidents take place
- We look at various things that can increase the risk
  - Being on your phone and being distracted
  - The role of alcohol and cannabis
  - Sleep deprivation and drowsiness
  - Speed
  - And weather
- We talk about autonomous vehicles and new safety technology
- We talk about what pedestrians need to be aware of
- We talk about what resources are available for people to learn more
  - Especially parents, and this is something Peter is thinking a lot about as his daughter is on the cusp of beginning to drive

## Mark’s background and education, and the profound impact of transportation accidents on human lives [4:15]

- This is a topic that given the consequences doesn’t get enough enough attention
- People may not appreciate the frequency of such interactions, and Peter is hoping to understand how much of what we are going to discuss today is under our control
  - In particular the role of fatigue in accidental deaths

> “*We’re all in vehicles moving around, and yet we have come to accept the carnage in ways that should just be unacceptable in our society*.”‒ Mark Rosekind

- This is prevalent in everybody’s life
  - Just being on the road
  - Everyone is a pedestrian at some point
- Mark will discuss what you can control, what you should be doing to be safer, and what you can’t control

**Mark’s background and the loss of his father at a young age**

- Mark lost his father a long time ago, but it is still challenging to talk about

- It was not until his Senate confirmation hearing to be administrator of [NHTSA](https://en.wikipedia.org/wiki/National_Highway_Traffic_Safety_Administration) that he talked publicly about this very much
- His father was a San Francisco motorcycle policeman
- He was chasing a traffic violator and somebody ran a red light, hit him, and he was killed in the line of duty
- Behind Mark is a shadow box with his badge and Purple Heart
- His father was 30 years old
- Mark was 3 and his brother was 2
  - They were raised by a single parent
- This just points out, this is personal for Mark, but he doesn’t wear that as a badge on his shoulder every time we have the conversation

***His father’s death was clearly foundational to what put him on a lifelong path of pursuing safety and how to make people’s lives safer***

**The human part of statistics**

- One of the things he often talks about is how many lives were lost
  - The exact number is important because every one of those is a father or sister or brother or some relative or one of your neighbors, etc.
  - Those are real people and we cannot bring them back
- Too often when we start talking about all the statistics, we walk right by the human part of this and that gets lost
- Peter agrees, and there is a quote he is not remembering exactly, but it speaks to the idea that a million people is a statistic, but a small number of people is a story
- We can get numb to what those numbers mean
- There’s a [series on Netflix](https://www.netflix.com/title/81303911) right now that takes old footage from World War II and does some remarkable technology application where it puts it back into color ‒ it’s stunning
  - What’s hard to fathom as you go through this is the loss of life (60-80 million)
    - Peter realized as he came to the end of this that he doesn’t even know what that means
    - He has never seen 1 million people
  - What this series does very well is what Mark has done ‒ get a few stories that are very representative of the horrific nature of what happened
    - Then imagine multiplying that by a thousand or a million
- Mark agrees, “*The numbers numb you.*”
- Often in talks he starts with what we call “the business of bent metal”
  - Having been at the NTSB, he’ll literally take photos from investigations (minus the humans)
  - It’s like: this was Dawn at 20 years old, she not only lost her life, but the people in this minivan you see (4 out of 5 died, and the only one who didn’t was a child in a car)
    - That makes it real for people
- What you hope is people translate that to understand that it could be you or a partner or your kids or your neighbor (people that matter)

***There’s this huge gap between those numbers (which most people have no concept), and when somebody actually in your circle loses their life in some kind of crash***

**Before we get into those statistics, explain your training: what brought you to Yale, what you studied, and how that led to what you are doing now**

- The arc of this is more of a zigzag
- Mark is trained as a scientist
- He was a pre-med at Stanford and had the incredibly good fortune to take a course called *Sleep and Dreams* when he was a sophomore
- It was taught by [William Dement, MD, PhD,](https://en.wikipedia.org/wiki/William_C._Dement) a professor in the medical school
  - Dr. Dement was part of the team that discovered REM sleep, and some believed he was actually the guy who coined the term REM sleep
    - We’ve only known about non-REM and REM sleep since the mid-50s
  - Dr. Dement came to Stanford and started one of the first sleep centers and was teaching this undergraduate course and it was just fascinating
  - He was this passionate charismatic professor who was engaging
  - Here’s this medical school professor teaching an undergraduate course
- At the time, the 2 most popular courses were *Sleep and Dreams* and *Human Sex* (taught by another medical school professor)
- What was really brilliant about what Bill did is he actually offered a couple courses
  - You could take a course and become a TA for *Sleep and Dreams,* or you could take another course and learn where to put electrodes and how to score sleep and actually get involved in research
- The summer after Mark’s sophomore year, he signed up to be a research assistant staying up all night in a laboratory
  - As an undergraduate, that was an incredible experience
  - Everything got canceled that summer except 1 project which was studying the effects of the water bed surface on sleep
    - This was the ’70s, and Mark met his wife during that study
- You don’t usually get the opportunity to be involved in research as an undergraduate and that changed everything

**When he graduated, Dr. Dement made an offer for him to stay and run research projects**

- If you knew where the electrodes went, and this is a K complex, a sleep spindle, here’s how you score sleep, you could run projects
- Mark did that for a few years and he tells people, “T*hat was like doing a postdoc before going to graduate school.*”
- Mark applied to med school but changed because at the time, there was no sleep speciality, no sleep medicine fellowship
  - Dr. Dement was pushing to make that real
- So if he wanted to spend a career looking at sleep, he had to get a Ph.D.
- Yale had a great academic research program and Mark could also get clinical training
  - He could get clinical training in clinical psychology but still do research
- The interesting spin is that after he finished his Ph.D., someone he knew from Stanford asked him to do a postdoc ‒ [Mary Carskadon](https://en.wikipedia.org/wiki/Mary_Carskadon)
  - She had been at Stanford with Bill and they created what is now the gold standard for objectively measuring sleepiness called the “[Multiple Sleep Latency Test](https://en.wikipedia.org/wiki/Multiple_Sleep_Latency_Test)”
  - She moved Brown Medical school as an assistant professor and had 1 technician
- The plan was for Mark to stay at Brown, get on the faculty, etc.
- Instead, he ended up going back and working for Bill, running a human research program for a while

## From sleep science to safety leadership: Mark’s journey in transportation innovation [14:15]

**Mark was a hardcore sleep academic, but part of his job was to get new projects going**

- He got engaged with NASA Ames Group, which is one of the NASA facilities in Mountain View, California, and they were doing fatigue jet lag research
  - NASA didn’t have many actual sleep people helping them do that, some chronobiology circadian people
  - It was fascinating because they were doing a study that required recording EEG in a cockpit and they weren’t really sure how to do that
  - Part of Mark’s job was to help them problem solve that so they could record pilot’s brain and eye movement activity in an ongoing way during flights

***That was a transition really out of the very specific academic environment to NASA***

**Mark’s time at NASA**

- Mark was recruited to work with the NASA Ames Group and directed the program at the NASA Ames Fatigue Countermeasures program for 7 years
  - It was fantastic

***This illustrates what has become a clear focus of his career: the application of the science into real world application***

- That has really been a force for him throughout my career
  - Hence the safety emphasis, great sleep science
  - How do you use that to help people every day, whether that’s driving a car or flying a space shuttle? What do you do to make that better?
- He worked with commercial and military pilots, astronauts, controllers at Johnson Space Center, etc.
  - Fantastic, incredible work

**Then he started his own company**

- Which broadened it from aerospace to basically everybody
- When he had his own company, they worked with folks in all modes of transportation, all over the world in healthcare, energy, military operations, you name it
  - It was fantastic

**The next part that was so interesting, part of the zag was Mark had the opportunity to become a board member at the National Transportation Safety Board [NTSB]**

- There are 5 members on the [NTSB](https://en.wikipedia.org/wiki/National_Transportation_Safety_Board)
- These are the positions where they call you, you don’t actually submit a resume
- Mark had done some work at NASA helping them identify fatigue in a DCA crash in Guantanamo Bay before anybody knew that there was a Naval air station there
- At the NASA group, they helped the NDSP define the methodology to investigate fatigue
  - They ended up identifying fatigue as the probable cause in that particular crash
  - And that has become the methodology that they use
- So 10 years later, it was amazing to get a phone call asking, “*Would you like to be considered for a board member position?*”

*Mark was a board member at the NTSB for 5 years*

- He launched on 7 crashes and sat through about 50 investigations that they voted on

**Mark was ready to stay for a second 5-year term when he got a call to become the head of** [**NHTSA**](https://en.wikipedia.org/wiki/National_Highway_Traffic_Safety_Administration) **(which is the National Highway Traffic Safety Administration)**

- That’s the administrator of the organization within the Department of Transportation that is responsible for all car and vehicle safety regulation and enforcement
- He was there for just a couple of years because that one is tied to the president,

***If you think about what we just talked about, which is how do you take the science and data and actually apply it to make things safer/ better, that was an incredible experience***

**When Mark left Washington, he came back and worked as the Chief Safety Innovation Officer at Autonomous Vehicle Company**

- Working at the other end of the continuum has been fascinating as well

**Peter’s takeaway**: there’s this marriage between the interesting work Mark has done in the world of sleep and also his interest in safety and crashes, and we are going to talk about both of these things today

- Mark was fortunate to have been at Stanford, which in many ways was the epicenter of sleep research

## Stats on transportation accidents and fatalities [18:00]

**What is the risk for death or injury associated with the road?**

*Whether you’re driving a vehicle, you’re a passenger, you’re a pedestrian, you’re a cyclist*

*Give me a sense of what that looked like in 950-ish versus 1970-ish versus 2000-ish versus today?*

- Let’s start with the [final numbers from 2021](https://crashstats.nhtsa.dot.gov/Api/Public/ViewPublication/813527), which is the last year we actually have complete data

***42,929 people lost their lives on our roadways ‒ that’s 118 people every single day***

- A lot of times people often say, “*So how come I don’t hear more about this? Or Why aren’t we…*”
  - During the pandemic, it was all hands on deck: let’s go get this
  - How can we put up with this?
- When you think about it, these happen geographically separated
  - These are happening all over the country, and very often it could be an individual in one of those vehicles
  - It may affect your family or your community, but very often, most of these go unreported in the general media or visibility for our society
- Just to put it in context, along with that, we have about **2.5 million injuries**, which are everything from slight to very serious life-changing injuries
  - And those are in the context of **6+ million crashes** every single year
- To put it on a global scale, it’s **about 1.4 million people globally every year**, and that’s about 3,700 people every single day
- But we’re going to focus just on the United States

**We know, over the years, road deaths have come down very significantly with all kinds of different things (we’re going to talk about)**

- Literally 100 years ago in 1923, it used to be about 18.5 deaths per 100 million miles
- Now we’re down to about 1.5
- We often talk about **vehicle miles traveled (VMT)**, and that’s important just because of the number of miles driven and the number of people that are out there doing
  - There’s a lot of different ways to cut this

**The** [**NHTSA**](https://nhtsa.gov) **keeps all kinds of data on this**

- You can look up any year you want, and it’s segmented by ages and geography states.
- The level of detail is unbelievable
- The reason Mark cites ‘21 is because it’s the last year that we have actual final data
  - We can talk about what we know from 2023, but those are just estimates done on a quarterly basis

**Peter’s initial takeaway**

- Those stats are approximately 1/10th the mortality for cancer, and that’s incredible
  - In the US, it’s a little bit better than 1/10th, but globally, it’s actually slightly worse than 1/10th
- The second thing that just jumps out at Peter when you talk about this is something he remembers somebody saying once that he thinks is absolutely true: if you read about a death in the newspaper, it’s because the manner in which it happened was so unexpected or is somehow so horrific to us, and that’s why you don’t read about people having heart attacks
  - Let’s not lose sight of the fact that heart attacks are the leading cause of death and that occurs 20x more frequently than what we’re talking about
  - Peter doesn’t know the last time he read about somebody having a heart attack for the sake of having a heart attack and dying if it’s somebody famous or whatever
  - Common things generally don’t get reported on, and sadly, that’s probably why we are a little bit numb to what’s going on here
    - Even though Peter would argue that there’s a difference in those of us who are driving by and see this carnage are kind of left a bit visibly shaken by it

**The difficulty in getting information about local crashes**

*Peter finds it difficult to get information*

- For example, he lives in Texas and there are big roads that are big and fast, and a lot of them are not necessarily set up as the safest roads
- There’s a particular road near where he lives where there’s probably a fatal accident on this road 3-4x a year, and yet even after it happens, Peter will go and do a quick search to see if he can get more information and it’s not readily available
  - It’s not entirely obvious what just happened

***If that’s happening under his nose where he’s seeing the accident (or seeing the aftermath of it within 25 minutes or something), he can completely appreciate why most of these deaths go unnoticed by all those except for the people directly impacted by the relationship***

- Mark explains, “*That’s the numbness. They’re off the radar. They’re not visible, even locally to many people*.”
- That’s why Mark often cites NTSB statistics because there’s usually a lot of people involved
  - There have to be fatalities
  - Very often they get investigated, and that takes a year to 18 month
- As Peter pointed out, if it’s not in the local police blotter, there’s almost never a follow-up that explains what actually happened
- When the NTSB investigates these, it’s always a chain of events (it’s never just 1 thing) and it takes a while to figure that out
- A lot of this comes down to local resources
  - In the last few years, traffic enforcement resources in local police departments have gone down
  - So the ongoing investigation may be checking a box on a form

***These crashes stay below the radar for most people, unless you’re in the circle where that person touches your life***

- Peter struggles with this a lot because he feels like there is this enormous missed opportunity
- At an intersection no more than 3 miles from his house, he has already seen 3 fatal accidents in the 4 years he has lived there
  - And  he’s can’t find any good information about the chain of events and what happened
  - He has some sense, but why aren’t there 4-minute videos being made that explain every one of these as a, “*Here’s what not to do,*” and why aren’t there warning signs?
    - At this time of day when the light is this way, this is a very easy mistake to make
- In this example, he’s not saying that 3 people have died but he’s seen 3 fatal accidents
  - Probably 6-7 people have died there in 3 years
- Peter points out that the other thing we don’t really have a sense of is the **near misses**

**What would be your guess as to how many near misses have occurred there that could have resulted in fatalities?**

*Do you have a sense of how you could even estimate that?*

- You could
- 2 thing about this
- 1 – You’re describing in what we call in human factors that safety pyramid [shown below]
  - Crashes are at the top, near misses are right underneath that
  - But a bigger layer, and the layer underneath that are **errors**
    - And this is why you see proactive safety in aviation, they do a lot of work trying to capture those errors knowing that they lead to near misses

![](https://peterattiamd.com/wp-content/uploads/2024/03/f1-markrosekind.png)

**Figure 1.** [**Heinrich’s triangle**](https://en.wikipedia.org/wiki/Accident_triangle) **is a theory of accident prevention**.

- When near misses get more visible: for example, you see the panic in aviation right now because those are the precursors to crashes
- Mark thinks you could calculate that and he wants to make a list because there are some concrete things that either he or Peter need to pursue

***#1 is we need to make these more visible***

- Rather than just the family and community feeling it, it’s Peter’s point, which is even in a 4-minute video, you could capture what happened and what was learned from that, and that could be enough for people to say, “*Okay, I got to pay attention to that because I go through that intersection every day twice*.”
- Peter reiterates, “*4x a day,  I am driving through that place that is the Bermuda Triangle of death, and once a year there’s going to be a death or series of deaths… Probably 60 times a day, there’s an error that could’ve even been a near miss. And yet I don’t actually know the predisposing factors.*”
  - Peter is extrapolating and making this up from the data he knows
  - This is very troubling

## Historical trends in road fatalities and the key contributors—impairment, distraction, and more [28:00]

**Can you give some commentary on what these numbers would’ve looked like 20 years ago, 40 years ago, 60 years ago?**

- One has to think that with airbags, seat belts, better cartechnology in terms of the collapsibility of cars that things have gotten better

*Is it easier to start in the 1950s where presumably it was just mass carnage?*

- Mark explains that when cars became more prevalent, the numbers when up
- In the ‘50s you saw huge numbers, and that was part of what initiated efforts to establish the [National Highway Traffic Safety Administration [NHTSA]](https://en.wikipedia.org/wiki/National_Highway_Traffic_Safety_Administration)
  - They had responsibility for creating federal motor vehicle safety standards, like crash testing, all of those
- If you go 100 years back, we’re probably over 90% reduced to where we are today

***In the ‘50s and ‘60s is where you probably saw the peak of those numbers and they’ve been coming down***

- We’re talking about this in the statistical sense
- What’s interesting is we have population level statistics (42,929 [deaths in 2021])
- We get these estimates every quarter and then it takes a while to finalize the numbers
- The NHTSA collects reports from every police department in the country to come up with these numbers
  - So it takes a long time to collect all that data, review it, finalize it, etc.
- Mark points this out because the estimates often prompt people to say, “*Oh, we’re down 3% this quarter from last quarter.*”
  - He thinks we should celebrate those lives that have been saved
  - At the same time, that 2%, 3%, 4% up or down within the context of the overall population numbers, we haven’t budged much

**Mark gives one example: drunk driving**

- A lot of people think we’ve cured drunk driving
- It’s been around forever, and we know about it
- There are all these things we can do

***When you look at the 42,929, the top 3 causes are impaired driving related to drunk driving, and that has stayed about 30% for 20 years***

> “*30% of the lives lost are due to that [drunk driving] for about 20 years. So the absolute number has come down, but the percentage has stayed about the same for 20 years*.”‒ Mark Rosekind

- #2 on that list right below that is **speeding**
- #3 is **distraction** (we’ll talk about all of those)

**Back to the numbers**

- In the ‘50s we started seeing that peak
- Now it’s down to about 1.5 per 100 million miles
- But when you look at the quarterly to quarterly estimate, it goes up or down by 1-2%, but in the larger population, things aren’t changing dramatically enough if we’re ever going to get to zero deaths on our roadways

*You mentioned that alcohol contributed to about 30% of those fatalities. What is the approximate contribution of speed and distraction?*

- Speed is 20-25%
- Distraction is very difficult, it used to be considered around 12%
  - [Larry Blincoe](https://www.researchgate.net/profile/Lawrence-Blincoe) (a great statistician in NHTSA) started to think it could be up to 30%
  - Distraction is more than just your phone
  - When you look at all of it, the impairment is more than alcohol now
- Realize these are not individual numbers: somebody’s drinking, they could be on their phone, they could be going too fast
  - They all mix and match, but they’re pretty big numbers

**Peter’s takeaway:** ***impairment is a broader category of which alcohol is probably still the most prevalent***

- At NHTSA impairment was always 3 Ds: drunk, drugged, distracted
- Mark credit’s his son for asking, “*Where’s the 4th D dad? Drowsy.*”
- Any one of those would be enough to impair your driving ability, but yes, alcohol is still #1

**On the topic of distracted driving, is there an appreciable signal in the data that suggests the downward trajectory of mortality has been slowed (or in any way altered) with the introduction of mobile phones 20-25 years ago?**

- Mark explains that we stopped seeing the decrease [in mortality] that we had been seeing
- 1 – It’s really hard to measure the distraction numbers
  - Same thing with sleepiness
- 2 – The evolution of the phones: where first people were just on a phone call, but now it’s texting and looking stuff up
  - The activities you could be engaged in are just so diverse
- They way to think about it is that we were making progress in a bunch of ways that flattened or maybe got a little bit worse, and we may not be able to appropriate all of our “variance,” to specifically just phones
  - But it took the distractions you could get in your car to a new level
    - Some of them have been around for a long time: playing with the radio, kids in the back seat
    - We can talk about buttons versus touch screens, etc.
- As those other distractions were getting more controlled, you saw the numbers come down, and with the use of  phones, we could look at it more as a flattening out [our progress]

## The demographics of drivers involved in crashes, and the life-saving potential of better driver education programs [34:30]

**Has there been any significant change in the past 40-ish years with respect to the demographics of the drivers at fault in these crashes?**

*Are we seeing a shift to younger people, to older people? Anything that you can point to that there’s a causal explanation?*

- There are 2 groups that seem to be most at risk
  - 16-17 year olds
  - 65-70+

***Clearly we’re talking about people who are just learning to drive and who are at an age that don’t have their frontal cortex fully developed***

- Mark’s friend (Greg Belenky) always talked about it’s like there’s a hole in their head right there
- We’re letting those people behind a couple tons of metal who have very little experience and just learning stuff
- And at the other end, you’ve got people getting older who some of it may be aging-specific effects
- More men than women die in these crashes ‒ many questions with that
- The causal or contributing parts of that would just be hypotheses about what’s actually causing those differences and things

**What was the rationale for letting people drive at the age of 16?**

- Peter thinks about other things that are mandated by age: you have an age at which you can join the military, vote, drink alcohol, purchase firearms
- There are various things that seem tethered to age, but driving is the youngest
- Peter didn’t get his driver’s license until he was almost 18 because he viewed it as a badge of honor to ride his bike and take the bus everywhere and he didn’t want to be lazy
  - He was a weird kid in that way
  - He personally can’t relate to what it’s like to be a 15-year-old who’s dying to get his license,
- Peter asks why that age hasn’t been pushed up

***Nobody has ever asked Mark that question before, so he’s going to look it up***

- No one has really had a discussion around that
- The discussion is all about our education system, driver’s ed
  - In so many other areas, we’ve got recurrent training
- He doesn’t know they actually came up with that age and came up with what are we going to do around that age to actually prepare these people for lifelong driving experience
- It’s fascinating because he would also say part of Peter’s point is we’ve actually not gone back to question whether we need to change that or not
- Peter could pontificate and say that kids are working jobs and need to be able to get there
  - Is that true today?

**Thoughts about drivers education**

- Peter loves driving and all things motorsport related
- Peter’s daughter is 15 and he’s been trying to organize a course for her and some of her friends with a group of really good driving instructors on a 20-acre ski pad to teach them high-end driving skills
  - Stuff he didn’t learn when he was young
  - Things he has learned driving a race car, which is everything not to do
    - Your natural inclination when this happens is going to be to do this, and you will spin the car
    - And if you’re lucky, nothing else will happen
    - If you’re unlucky, you’ll hit something else
    - And if you do this, you’ll actually flip the car
- Peter doesn’t believe that you can just academically outlearn that
  - You have to just do the reps
  - You have to be on the track in the car doing it over and over again
- He’s guessing that there has been some calculation that has said we can’t justify putting those resources into mandatory driver education
  - People have decided that we just can’t request that kids learn that
- Mark doesn’t think this is the case
- Instead, it’s the first part of Peter’s question: people haven’t questioned from the beginning, why did we even start there?
  - Are we preparing these kids well enough for this life experience of driving?
  - How do we revisit that in our knowledgeable technology-driven society?
  - How do we actually go and upgrade that to something that could actually save their lives and the people around them better?
  - He doesn’t think those questions have been asked

***Mark agrees, the intellectual academic part of lessons is great, but unless you do the muscle memory part of the behavioral piece of actually experiencing it, there’s no question***

- Mark knows Peter is familiar with [F1](https://en.wikipedia.org/wiki/Formula_One), and Mark has gotten to know [Jean Todt](https://en.wikipedia.org/wiki/Jean_Todt) over the years
  - What is fascinating: he is now the UN’s sort of ambassador for global road safety
  - He has taken that on from his F1 days and his Ferrari days, and asked, “*How do we take what we’ve learned there and apply it?*”
- If we teach kids early how to be better at driving than the ones who just sit in a course or do it online (that’s not much education)
  - It’s a lifelong investment

***It’s not the case that the analysis has been done, and we should write it off. Instead, people haven’t asked those questions or taken the time.***

- Mark suggests they send [Jean](https://en.wikipedia.org/wiki/Jean_Todt) a letter about what Peter is doing because this investment could be huge in saving lives and costs

## The most critical areas where drivers need to be hyper-aware to protect themselves [41:00]

**Peter tells his patients there are 3 areas where you need to have a heightened sense of awareness to protect yourself**

- 1 – You have to be hypervigilant in intersections: both the standard 4-way intersection and also a T-intersection (when you’re coming out of a gas station or something like that)
- 2 – The 2-way traffic without a median
  - In Texas there are 60 mph roads with no median, and those roads scare Peter but they’re unavoidable
- 3 – On freeways, and in particular around exits and on-ramps where people are sometimes acting irrationally
  - Merging, trying to get off at the last second, trying to get on
- What Peter is saying is, “*Look, if you can harness the power of your attention only selectively while driving, make it those three spots*.”

**What would you say to that? What would you add to that?**

*Can you comment on what fraction of fatalities are a result of crashes under those 3 scenarios?*

- Mark thinks Peter has nailed it
- He’s not sure he can give the exact percentages for each one of those, but it’s in the order Peter stated
- Mark would add to this to include:
  - Any intersection
  - Any road separation: not only for vehicles but also pedestrians and bicyclists
    - You think about a median in the middle, but it’s also on the sides where in the last 10 years we’ve seen a 50% increase in pedestrian deaths
    - You need separation of vehicles from all of these
  - Any kind of on and off ramp system
    - The issue there is the speed differential
    - The challenge is trying to figure out not just that you have to merge, but the speed you need to merge with
- It’s great for us to talk about statistics, and we love to hit [bell curves](https://en.wikipedia.org/wiki/Normal_distribution), but we’ve also got to talk about those edge cases because that’s where lives get lost

***One of Mark’s mantras is “never again,” and you need to share that data, and this is where the idea of a 4-minute video is so interesting (whether it’s a common case or an edge case)***

- You shouldn’t need every intersection in the world to go through that kind of loss of life to decide we should change something
- We should do something different here in some way

***Unless you make it visible, understanding the causal and contributory factors, you can’t make those changes***

**Accidents where a drives makes a slight mistake, but it becomes catastrophic**

- Peter always thinks back to 1994 when his hero [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) died, May 1st at Imola [Italy]
  - [Max Mosley](https://en.wikipedia.org/wiki/Max_Mosley) was the head of the [FIA](https://en.wikipedia.org/wiki/F%C3%A9d%C3%A9ration_Internationale_de_l%27Automobile) at the time
    - Mark knew Max
- Max said something very insightful at the press conference in the days following Senna’s crash
  - The press understandably were completely fixated on why he crashed
  - When asked, “*How did Senna crash?*” Mosley said, “*You’re asking the wrong question. He crashed because he is the best driver in the world driving a car at the physical mechanical limit of what it is capable of doing. Crashes are going to occur. The question isn’t why did he crash?* ***The question is why did he die?***”
  - Max really made sure that the sport took a turn at that moment: we will not tolerate drivers dying
    - We might not be able to stop the crashes, but there will be no more deaths
- Knock on wood, there has only been 1 death in F1 in the 30 years since

***What Peter finds troubling is that this analysis isn’t being done for the 42,000+ people who died in 2021 where someone is saying what contributed to the death and what can be learned about making that the ultimate thing that we put a buffer between?***

- For example, when a person makes a mistake, you always want to have **more of a buffer** for that mistake to not result in the nature of force that could kill them
  - In a racetrack, that’s the difference between having a bigger runoff than a smaller runoff
  - That’s the difference between having more impact-absorbing things in areas where we expect people to potentially go off
- Peter’s guess is that analysis on the individual basis isn’t necessarily being done
  - Mark agrees and adds: analysis that we can cite is more at the population level than into the specifics of a particular crash, at a particular site, with particular individuals
- At the NTSB it takes a year plus to do an investigation because you’re going to look at all of the factors that are involved there, identify both the probable cause as well as contributing factors, and then make recommendations so it doesn’t happen again
  - Those investigations are reactive, but they’re intended to take information so you can prevent them from reoccurring again in the future
  - This is what separates NTSB investigations from the local police department level: they’re so thorough
  - Locally, they just don’t have the resources or time to go and do those kinds of analyses

## The role of the National Transportation Safety Board (NTSB) in accident investigations, and the importance of data sources like event data recorders (EDRs) in accident reconstruction and investigations [47:00]

**Does the NTSB only investigate trains, airplanes, and huge sorts of things?**

*Obviously they can’t do this type of analysis for cars*

- Exactly right
- The NTSB is required to investigate every aviation crash
  - That’s the big commercial stuff
  - That’s also the local general aviation stuff that happens in every community all over the place
- It also investigates specific crashes that occur that have national importance, in every mode of transportation
  - Mostly buses and trucks because those are big
  - When there are fatalities, there’s usually more involved, but they can do single individual crashes as well

*When Mark was at the NTSB, they did several investigations related to distraction with folks on their phones*

- When you go into it, you don’t know exactly what you’re going to find, but you get enough information to say, “*We should go after and see this because it would allow us to make recommendations that would have national importance to do that.*”

**How would the NTSB make a decision or determination that this car accident is potentially one we’re going to put resources towards?**

- Peter is thinking about the sheer volume of crashes and wonders what makes one the illustration case?
- The NTSB investigates all aviation crashes

- Pipeline and hazardous materials fits under their jurisdiction too
- Calls for investigation come from everywhere
  - A local PD might call about one
  - An official from the FAA let’s you know about a crash
- There’s a 24/7 op center at the NTSB that gets all of those phone calls
- You won’t know ahead of time, but somebody may say, “*Well, we think this was involved,*” and you have to make a decision to investigate or not

***From the investigation, you hope to make recommendations to the entire industry (or individuals) to try and get changes***

**The black box data recorder**

- When Peter thinks of the NTSB and aviation, he thinks of the black box
  - This amazing data recorder contains not only what the pilots said up until the moment of impact, but also the telemetry
  - You actually see this was the position of this aileron, this was the thrust on this engine, this was the yaw… you know every detail of it

*What do cars have in them that allow the NTSB to do that kind of thorough investigation?*

- Cars have those boxes and they’re orange
- Vehicles do have an [EDR (electronic data recorder)](https://en.wikipedia.org/wiki/Event_data_recorder), and there’s actually no reason you would even know that because you don’t really have access to it.
- Some of these things that are controlled at the federal level through [NHTSA](https://en.wikipedia.org/wiki/National_Highway_Traffic_Safety_Administration), [federal motor vehicle standards](https://en.wikipedia.org/wiki/Federal_Motor_Vehicle_Safety_Standards), and other kinds of regulatory authorities that are there
- Many of these things are controlled at the state level
- EDRs are where there’s a basic federal requirement
- In aviation, there are hundreds (sometimes now with the newer ones, thousands) of variables that you can get from those recorders

***EDRs in most vehicles only provide the basics***

- There’s always this tension between the industry about how much data they want to leave out versus those on the investigation side (where they know more is better)
- Very recently, some of these only recorded 30 seconds or a minute worth of data, maybe 3 minutes back
- This is a debate even in the aviation ones
  - In the old days, they used to record over
  - For those of us who want to say, “*How long have they been braking hard like that? Or how long have they been at that speed for whatever else?*”
- In a vehicle on the road EDR, you may not have a long period of data to track that kind of thing

***It’s both the variables that are recorded and the amount of time that it records, and that it’s available to you post-crash to be able to look at all that and reconstruct what actually happened there***

**Are EDRs one of the more important data sources you would rely on when the NTSB did come in for auto accidents?**

- Absolutely
- That and you talk to everybody: witnesses not only in the scene, but you talk to family and other people, work, all of that kind of thing
- Within the fatigue realm, for example, if this is a trucker who was on the road, you’re looking at where’s their hotel/motel key and can you actually see that they got in the room?
  - Then we have to look to see if they were on their cell phone or not?
  - Were they’re actually sleeping
  - You go with the electronic pieces, and then there’s all the other human elements of that which you use to try and piece at a minimum the 3 days before the crash

**One of the hardest things is people speculating in the first 24-48 hours of what happened**

- Having launched on 7 different investigations
  - The first one was a [Reno airshow crash](https://en.wikipedia.org/wiki/2011_Reno_Air_Races_crash) (air races)
  - The media in particular in the first 24-48 hours want to report on what caused that, and before you know it, it’s already established
- Mark used to go back to the DC and say, “*Okay, so how often do we actually see that first 24-48 hour speculation end up in the final report?*”
  - People couldn’t really think of many
  - Maybe a little element of it shows up

***The thorough investigation uncovers things you would’ve never known if you stopped at that first 48 hours***

- Mark’s biggest thing from a safety standpoint is if you’re not careful, you take action based on the **speculation**, now you’ve spent a year doing a bunch of changes and things that may actually not have had any role in the crash that you were investigating
  - The speculation can really bite you if you’re not careful
  - Hence, the data sources, like EDRs, are critical

## The dangers of phone use while driving [53:45]

**What can you glean about phone use in the car?**

- Peter points out that it’s so common now
- He has this innate anger when he passes somebody and they’re on their phone
  - You can see them holding their phone when you drive past them

*Is this much different than if you were drinking a beer and I could see the bottle?*

Peter asks, “*How much data are they able to infer if a person wasn’t actually speaking on the phone, which I assume is the easiest thing to figure out from the cell signal?*”

> “*Let’s actually start with if you’re going 55 miles per hour and you take five seconds to look at your phone, your eye’s off the road, you can travel the distance of a football field*.”‒ Mark Rosekind

- That’s playing with the radio, on your phone, whatever it is
  - 5 sec at 55 mph is enough to take you a football field

***It’s very straightforward, when you’re driving there are 3 things you need to be taking care of: you’re hands on the wheel, your eyes on the road, your head in the game***

- When you talk about distraction, anything that pulls you away from 1 of those is going to be a problem

***We now know that talking on the phone (even hands-free) can degrade your performance equivalent to performance decrements associated with a blood alcohol level of  0.08***

- As you know, there’s no such thing as **multitasking**, it’s switching
- People argue that hands free is legal, it’s okay
  - Mark explains, “*No, it’s not, because if you’re engaged in that conversation, then your head’s not in this game*.”

**One of the challenges when you look at all of this is how diverse they are**

- The NTSB will go and get all kinds of data
  - Locally, they’re probably never going to get that

Mark asks, “*So what would you look for?*”

- Mark often thinks about that when he drives by these people (staring at their phone) because he’s going the speed limit and they’re going less than that in a faster lane
- He’s thinking he knows enough to ask the police department to get those phone records
  - He wants to know if a signal was bouncing off a tower somewhere locally
- Nowadays we have more cameras everywhere, and so you can show that they actually were on that phone at a certain place, whether it’s their video or video from a vehicle you might be in
  - There are more sources for that kind of information

***If you didn’t know about an EDR or video or an investigation at the NTSB, you can get a subpoena if the phone company won’t give it to you and literally get the records to know if they were on the phone during a certain time***

- In most crashes, insurance companies even aren’t going to necessarily pursue all of that, but those things would be available depending on what happened for you to
- Again, like any other investigation at the NTSB level, you could go after that stuff to determine what was really there

**Mark shares a story from a couple of weeks ago, when he was on El Camino in California**

- It’s 3 lanes, 35 mph speed limit
- We’re stopped and we see a motorcycle officer who had stopped somebody a while back, and all of a sudden now he’s coming up on the left
  - We’re in the middle, there’s another vehicle on the left, but the guy’s coming up splitting the lane because we’re stopped
  - And he’s literally looking in the cars (Mark can see his helmet turning and looking in the cars)
  - The guy next to us was on his phone ‒ Mark was sitting there just watching him, and the cop came up and looked in there and starts shaking his head and the guy put it down
- That’s the difference when you actually have someone looking at you, whether it’s video or something else that says, you shouldn’t be doing that
- You know that as soon as the cop went by, this guy is back on the phone again, right?

**Have there been any technological solutions proposed to dramatically lessen the burden of phone use while driving?**

- Peter asks this as someone who uses long drives as a chance to get caught up on phone calls and to listen to podcasts and audiobooks
- Even though his hands are on the wheel and his eyes are on the road, there’s no doubt that it takes his head out of the game a little bit
- Mark replies that phone companies did oppose it quite a bit, but now there is usually a button that says “*Don’t call*,” or it’ll send a text/voicemail that basically says, “*I’m driving now, call you later, or leave a message*.”

*But that requires the user to take an action. How can you make this so that you don’t have to opt into it?*

- Those could exist and they do
- Phones can now tell when your vehicle’s moving (accelerometers and other sorts of things)

***Right now, you could just make the decision: I’m going to shut it off***

**When Mark was at the NTSB,** [**Debbie Hersman**](https://en.wikipedia.org/wiki/Deborah_Hersman) **was the chairman, and they were investigating a couple of crashes where clearly cell phones were an issue**

- We made a recommendation that cell phones should not be used in cars except for emergency situations
- Mark remembers exactly around that time because he used to call Debbie and we would be talking about stuff, and she had a long commute and she used to use that to catch up with all kinds of stuff
- Then all of a sudden, we were doing these investigations and he would keep getting her voicemail
- As we got closer to our recommendation, he realized what was going on
  - She goes, “*Yeah, I wanted to know what it would be like to shut the phone off or put it in a bag in the back, and you know what? It’s really inconvenient, but I’m a better driver when I’m doing this than when I’m doing it the convenient way*.”

**There’s a societal question**

- Do we make that vote and say, “*No, we’re not going to let you do that if you’re moving*.”
- You always have the personal choice about if it’s important enough to you, you can decide
  - In some cases it could also mean you can differentiate
    - If you’re on a strange road and you’re going a little faster
    - If you’ve got more people in the car
    - As opposed to on an open road, going the speed limit, there’s nobody around
- Peter justifies phone use in his own mind (perhaps erroneously)
  - He’s now steeped in the practice of identifying hotspots, and whatever he’s listening to or if he’s on the phone, he’s convinced himself that he will pay more attention at the intersection, looking both ways, even when you have the right of way, or that kind of thing

## How drunk driving was addressed through advocacy and legal changes [1:01:30]

- You could install a breathalyzer in every vehicle that allows it not to start without a blood alcohol below 0.08 (or make it even more egregious at 0.05 or something)
  - It would be hideous to look at
  - Peter thinks they have devices like that for people who have been convicted of drinking and driving
- When you look at the numbers of deaths due to intoxication and distraction, it begs the question, how much would we be willing to be inconvenienced to save… call it 50 lives a day?

**Is that a pretty good estimate that if people couldn’t have phones in their cars, and they couldn’t have alcohol in their system when they drove, about 50 people per day would be alive?**

- Yeah, ⅓ of 118 is maybe 40
- Mark points out that Peter is different in a good way because he’s actually cognizant
  - He’s thinking about those things and what risk they would create
  - In his framework he’s thinking about, “*What can I control? What’s out of my control?*”
  - Most people aren’t even thinking about those things
  - That makes Peter safer in those situations than someone who isn’t even thinking there’s an issue with talking on the phone and playing with the radio
- Congress just passed a [law](https://en.wikipedia.org/wiki/Infrastructure_Investment_and_Jobs_Act#Transportation_safety) that new cars will have to have a technology that can detect whether you’re at the 0.08 level or higher
- That technology has actually been in the works for a long time
  - One of them is called [DADSS](https://dadss.org/breath-technology/): it has a breath analyzer in the hood and also stuff that’s in the steering wheel that literally is looking at molecules in the air, and the car won’t start if it hits [a certain level]
- Take it as a model for what you’re talking about with phones

*How will that differentiate between someone in the car who is incredibly inebriated and the driver, who is not?*

- This is why it has sensors on the wheel and another one
- They’ve done enough research to be able to differentiate those
- The legislation that has passed is more of a performance target than it is the mechanism

**It took decades to get legislation to say we should have this in every car because of the lives it could save**

- Part of the debate was about technical things more often that what this conversation started with (the societal value)

**When did drunk driving fall out of favor?**

- Peter gets the sense that there was a day in which driving drunk was a normal thing to do
- Clearly that’s not the case today, despite the fact that the numbers are still as high
- Mark explains, “*I will apologize to them, but it really was about* [*MADD (Mothers Against Drunk Drivers)*](https://en.wikipedia.org/wiki/Mothers_Against_Drunk_Driving)*, and the woman who started it lost a child in a drunk driving crash.*”
  - In the early ‘80s
  - They were the first ones to say this should not be allowable anymore
  - They put faces to a set of crashes and a cause
  - They took it to the State House to Congress
- People don’t know this, but MADD actually provides counseling services and all kinds of other things
- They are the model of a victim group that said, “*We need this issue in front of our society. It’s not okay*.”
- Every state has to vote for what the blood alcohol level has to be, each one is different

***MADD pushed especially hard for the limit to be higher; they finally got it to 0.08, and they’re the ones who will make sure that the pressure stays on to see the technology actually integrated within vehicles***

- Work by MADD is an example of what Peter is talking about
- It could be a crash, high visibility, maybe a celebrity, what do we do about this?
- Or it can be this new model that was created with MADD, which we see in other arenas as well

## The need to address distracted driving and the psychological impact of distracted driving accidents on both victims and perpetrators [1:07:15]

**The case of Libby Zion**

- Peter always finds that the individual cases do more
- [Libby Zion](https://en.wikipedia.org/wiki/Libby_Zion_Law#Death_of_Libby_Zion) was a woman admitted to a Mount Sinai hospital in New York
- She was admitted to the ER
- A resident who technically probably wasn’t even qualified to make a decision that was being made about her care, made a decision to give her a medication while she was already on an [MAOI](https://en.wikipedia.org/wiki/Monoamine_oxidase_inhibitor), and it resulted in her death
- It became the linchpin case that her father basically took against the medical community about **resident work hours**
- Peter doesn’t think this was just about fatigue, but more about resident supervision
- It might’ve taken 15 years from her death until the changes that were imposed on resident work hours, which was at the end of Peter’s training period
- But again, it all came back to this woman’s death
  - It wasn’t about the million other insane stories that resulted from medical residents being exhausted

**Have we had that moment yet with distracted driving?**

- Do we have the equivalent of Mothers Against Drunk Driving or do we have the equivalent of Libby Zion’s death?

*Peter’s story about distracted driving*

- Peter used to work with a guy named [Nick Venuto](https://www.nbcsandiego.com/news/local/cyclist-killed-by-suv-remembered/1899184/), and they sat opposite each other in their offices
- Nick was a really amazing guy, a remarkable cyclist
  - He was so committed to his family that he used his long commute on his bike to do the bulk of his training so that he didn’t have to do any cycling during the week, and he could just do his main training on the weekends
- He had just won one of the most remarkable time trials in Austin (the Mount Palomar climb), which is an epic climb, one of the hardest climbs in the United States
- It was a Tuesday afternoon in May of 2011
- They left the office together, and Peter was going to drive home to get on his bike to then ride to where he did his intervals that day and Nick was riding home
  - Peter remembers thinking there were 2 places he could go and ride that day: up Torrey Pines or on the bike path of 56, which ran along a freeway (that was the road that Nick always took home)
  - Peter ultimately ended up deciding to go up Torrey Pines that day
- That day when Nick was cycling home, a woman was in an SUV in the right-hand lane
  - This is the lane adjacent to the bike path where there’s a hill that you have to go up
  - It’s about a 12-foot hill at about 40 degrees with a fence
- This woman was on her phone
- What Peter thinks happened is the car in front of her stopped and she drove up the hill, through the fence, hit and killed Nick on a path that Peter rode on most day
- Peter spent the next 2 years so goddamn angry that he wanted to start carrying a gun when he rode his bike to shoot any motorist that got anywhere near him
- He thought to himself, “*How many times does this happen?*”

***This is one guy that Peter just happened to know who died, but this is happening constantly***

**Why are people not more irate? Why is something not being done about this?**

*Is there a movement around victims of distracted drivers?*

- It’s not just cyclists and pedestrians, it’s other drivers who are victims of the distracted driver
- Peter adds, “*I want to say one more thing. I am a distracted driver sometimes. I could easily have been that woman. There are times when cars in front of me are stopping and I haven’t caught it until the last second. And just because it hasn’t resulted in an accident, I don’t know that it makes me morally any better than that woman.*”
- Mark notes that it’s personal for Peter too
- Mark paused at the beginning because he doesn’t often talk about his father, but it’s personal for a lot of people

> “*The stories actually aren’t told enough. That’s what we’re talking about [with] MADD. They told the stories, this should stop*.”‒ Mark Rosekind

- We have not reached the societal unacceptability, the societal outrage that Peter just portrayed at the level of “*We just got to stop it*.”
- That’s why Mark said MADD helped bring the visibility
- But the legislation for technology in the vehicle just got passed
  - It’s not even in the cars yet, right?
  - It’s still got to figure out how to do that part

**To the question, “*****Could we do the same thing with distraction?*****”**

- The good part is people are asking questions like what Peter just did
- How do we take this to the next step?
- We have models, alcohol impaired driving, we have ways to go after this and even do better with technology and things
- How do we do that in the realm of distraction?
- Peter has also identified why it’s so hard

***The bad part is even us people who are trying to be really good, trying to save lives and do the right thing, it’s hard***

- There’s still some things where we make choices (even knowing choices) that’s not really the best thing to do
  - That’s a challenge, even really good folks who know what’s going on

***We need all the available mechanism strategies we have to change many of these things, and what you’re getting to is there are so many of them***

- We can look at the top three, but that doesn’t necessarily get rid of all of them

**What are the things that are under your control?**

- For you, if that means watching a little bit more about when you’re on those calls, and how you’re paying attention to them hands on or hands off, etc.
- Peter is already different because he’s thinking about where those danger zones are
- Someone who doesn’t even think about that is at a higher risk

> ““*This is risk management… what you choose to actually try and control and take care of, [and] others that will still put you at risk in certain situations*.”‒ Mark Rosekind

**Peter has often wondered, is there any research into the lives of those who kill other people on the road and how their lives are forever impacted?**

- It’s not until now that Peter has told this story that he ever once gave a thought to that woman who killed nick
  - Truthfully, he hated her guts, but he doesn’t know if that’s fair
  - He doesn’t know anything about her life today, or how often she thinks about Nick
- It’s Peter’s impression that there are 2 deaths at every death, and that part of the person who killed this person is at risk
- This a very different type of homicide
  - This is not first-degree murder
  - This is involuntary vehicular manslaughter
  - Nobody wakes up thinking they want to kill someone today in their car

*Peter knows Mark’s training is in psychology, and he wonders if there’s any aspect of his training that gives him a sense into what those people go through*

Peter asks, “*Is that something we should be tapping into to help create more of a zeitgeist around this? It’s not just the lives of those who die, it’s those who live.*”

> “*25 to 33% of people in a crash are going to have PTSD within 30 days or longer*.”‒ Mark Rosekind

- There is a literature on that
- Going from the statistics to the individual, MADD is quite good at not only having victims’ families talk about what’s going on, but they have drivers who have killed someone that are also part of who speaks to folks about what this does to change their life
  - And sometimes that’s jail time
  - Sometimes even if they don’t go to jail, it changes their life forever because they are waking up every morning with survivor’s guilt
    - Anybody who really cares about humanity is going to carry that with them for the rest of their lives

***Those numbers are close to a third of people are going to have PTSD, some aspect of that, and then telling those stories can be very powerful***

## Navigating the roads and lowering your risk of accidents: weather, human error, and defensive driving [1:15:45]

**Where does weather rank on this list, whether it be rain, snow, ice, sudden darkness or cloud? How much does that contribute?**

- NHTSA did a [study](https://crashstats.nhtsa.dot.gov/Api/Public/ViewPublication/812506) that came out in 2015 [2018] that showed in the chain of events the last event before a crash, that 94% of the time it’s a human choice or error
  - That’s Mark’s language, “*Human choice or error*”
- The question is, what are the other 6%?
  - 2% are vehicle defects, 2% are the environment, and 2% other
- The environment is both the physical environment, potholes, road conditions, etc., and then things like weather

**Peter’s takeaway:** ***it’s virtually nothing***

- It does happen, but it’s going to be small compared to the other
- We can talk a little more about the 94% because there’s been some controversy about that number, but that’s a soapbox for Mark

**Where’s the controversy around that? Are there people who are arguing that number’s too high, that that’s overstating it?**

- Nobody has actually addressed that number

> “*This is why a crash is not an accident. A crash is preventable. An accident implies it’s inevitable.*”‒ Mark Rosekind

- Most people don’t know this, but the word **accident** started getting used mostly in occupational environments like the work setting in the ‘20 and ‘30s when companies didn’t want any responsibility of on the job injuries and deaths
  - Mark always says it’s like it was an act of God
  - It was an unintentional, nobody could do whatever

***Part of the reason Mark brings that up is because if you believe in safety that by investigating, you can determine the causal and contributory factors and then intervene in some way by changing, so you prevent it from reoccurring, you prevent whatever, then that’s what safety’s about***

- If you didn’t believe in that and you really think it’s an accident that’s inevitable, why are you trying to make changes, investigating?

***The mission of the NTSB is to investigate those crashes, to make recommendations so they don’t reoccur***

**NTSB findings and recommendations on human error and safety misdirection**

- As a NASA scientist, pretty much you could start any paper with 70% of incidents [are due to **human error**]
  - Because it was so well established, it was just a given
- The Institute of Medicine reports: [To Err is Human](https://nap.nationalacademies.org/resource/9728/To-Err-is-Human-1999--report-brief.pdf), a 100,000 medical errors every year due to human [error]
- So 94% shouldn’t actually surprise anybody

*There is something which I call “safety misdirection” and that’s where 2 things are going on*

- 1 – Denial, let’s not deny what the causal or contributory factor was
- 2 – Blame
- The old version of safety misdirection is the car companies are just blaming the drivers for stuff
  - It’s kind of like the corporate accident language
- What Mark learned at the NTSB is you can have safety or you can have blame

***If you want to blame people, that’s not going to get you to the safety; the safety part is identifying the causal and contributory factors and then intervene, so those things don’t happen again***

- When it’s something about our human behavior that’s hard to change, ask, “*What’s the technology we might be able to use that either supports, helps or just eliminates the ability to do that?*”
- The controversial part that’s been interesting is people saying, “*Well, if you talk about 94%, you’re just trying to blame the drivers, etc*.”
  - There are some car companies and some people in the autonomous vehicle space that love to do that; again, how they use the data

***Scientifically, a huge part of this is human choice or error***

**We still have the challenge of then how do we address those to make sure those things don’t reoccur again in another place?**

- Nobody has actually argued that number, it’s more the blame and shame part, which doesn’t get your safety
- Blaming is not going to get things fixed for you or save lives
- The other 6% shows that the last event in the chain is a very small percent
  - It’s going to be weather or potentially defects

**While we’re on the topic of cause and fault, of the people who died last year, do we know how many of them were the cause of the mistake that led to the crash versus people who were presumably not doing anything that would’ve led to a mistake?**

- We don’t have that level of detail of those specific crashes that occurred to be able to tell that

*Peter asks to make the point that there are 2 elements to this*

- 1 – What can I do as a driver to make sure I’m not the one who makes the mistake?
- 2 – What can I do as a driver to make sure that when the other driver makes the mistake, I’m in a position to react better or see their mistake before it’s happening?
- Peter thinks about this a lot as a dad who is starting to talk about this with his daughter
  - If he’s driving her to school, it’s a nonstop lecture, “*Hey, Olivia, did you see how I did that? Did you notice why I did that? Why did I look there? Did you see what that driver just did?*”
- It’s not enough to just say, “*I’m going to drive at a responsible speed and I’m not going to hold my phone and I’m not going to drink.*”
  - That’s a great first step, but not the complete step
- This is the mantra Peter uses, “*I want you to imagine that somebody woke up today with the stated purpose of killing you. So they’ve been handed an envelope. The envelope contains your name and they’re told to kill you today. But here’s the catch. They’re not allowed to use a gun. They’re not allowed to poison you. They have to do it with their car*.”
  - And he says, “*Armed with that knowledge, how would you drive differently today?*”
  - It’s only 1 car, and you’re going to see thousands of cars today
  - What will that knowledge do to your attention and how will you treat each intersection, each on-ramp, each off-ramp, each T joint?
  - His wife thinks this is a little grotesque
  - Peter doesn’t know if that’s a great way to live your life, it’s a bit morose, but it’s the only heuristic he’s come up with to help with the other half of the equation
- Peter doesn’t know how to quantify the effect size of each of these things
- Is it worth the baggage and the overhead, the emotional overhead of playing that game?
- Mark agrees, it could be your life, so yeah, it’s worth it
- As Mark said at the beginning, “*Thank you for bringing this topic up because at the core, like you say, your mantra of what’s under your control, what’s out of your control, that’s what we’re talking about here.*”

**Even with things that are out of your control, you can be more vigilant to some of the risk factors or other things that you could do**

- Part of this is **situational awareness (SA)**
  - You know this in racing, it’s a big thing in aviation
  - This is what Peter articulated with his daughter, and this is huge
- The second part is what we would typically frame as **defensive driving**
  - There are people that are out here that are not making the good choices you are
    - People who are on their phone or drunk or haven’t had enough sleep
    - You don’t have any control over that
  - But with your situational awareness and driving defensively, there are things you can do
    - Besides scanning here, looking there, you can come back again
    - You can look at those intersections where things are higher so that if that raises your vigilance, that could be enough for you just to pause at that stop sign longer, and it becomes not even an error, let alone a near miss or worse
    - Mark thinks that is what Peter is portraying

***Situational awareness includes following the rules, doing the good, and then the other is the defensive driving part is don’t think everyone else is doing the same thing (they’re not)***

**It’s so easy to drive nowadays, and some people have their heads so far out of the game**

- People have lost situational awareness
- It’s all about the music, the conversation, etc.
  - Especially with some of the newer technologies

***When you’re doing your training, that needs to be in there too: the mental game of making the right choices and knowing that other people won’t, then what you can do***

## The impact of impaired driving: alcohol, cannabis, prescription drugs, and more [1:26:15]

**Substance use**

*We’ve talked about alcohol, what does it take to reach 0.08?*

> “*Most people in the safety arena with alcohol like to say that impairment starts with the first drink*.”‒ Mark Rosekind

- As soon as you pull up alcohol, that’s going to start changing your reaction time
  - Everything’s going to start changing

*Peter has a great model to demonstrate this*

- He drives a **racing simulator**, and he’s done this game where he will have a glass of wine and get in the simulator
  - To be completely clear with a glass of wine, he does not perceive anything in his own level of awareness
    - Because he weighs a lot, he doesn’t feel a buzz
- However, in the simulator, there’s a noticeable difference, even at a glass of wine where he’s sure he is below 0.08
  - He doesn’t drive as well
  - He misses the apex more
  - He’s more likely to spin

***It’s a subtle difference, but it’s absolutely noticeable in that environment, which is much, much more demanding than just driving home from the restaurant***

- Peter has never taken a breathalyzer test, so he doesn’t actually even know what 0.08 is
- Mark explains, “*For you, that’s going to be 2-3 beers and one good shot of hard liquor.*”
  - Within 1-2 hours
- This brings up a great point, which is why Mark always hesitates to give to much information about that
- You can go online with some pretty good [BAC estimators](https://alcohol.org/bac-calculator/)
  - This is affected by your age, your weight, your health
- There is less alcohol content in beer and wine versus hard liquor
- You also have to consider the time course, how much did you eat, and what did you have in your stomach when you read [the [BAC](https://en.wikipedia.org/wiki/Blood_alcohol_content)]

*Mark thinks Peter’s story illustrates another important point*

***There is very often a disconnect between this subjective experience and the objective one, which is that very often people think they’re doing a lot better***

- We see this parallel in alcohol and sleep loss
  - People say “*I’m doing great, I’m really fine,*” when if you look at the objective performance measures, they’re just doing horribly or they’re off, but don’t realize how off they are

***That disconnect is really important, and it is actually bigger risk than sometimes the exact amount of alcohol you have in your system***

- Peter would argue that sleep is the same
- If he doesn’t have a great night’s sleep, it shows
- The cool thing about a simulator is you’re simulating driving around at 200 MPH and at that speed, things are happening 3x faster than when you’re in a car on the road, even on a freeway
  - Of course, you’re turning constantly
  - So the stakes are so much higher, and the forces and inputs are so much more subtle
  - Any wrong input will lead to a significant change in output

***It is remarkable how you can feel fine for the mundane task, but not for the drive***

- Mark suggests Peter adds this to the [driving] course he is creating
  - In addition to creating muscle memory, sleep loss is a challenge
  - Give the rating on a 1-10 scale and show the objective measurements in driving, even the mundane ones

**Cannabis use and driving, what do the data say?**

- It’s not good
- With alcohol, there’s a really good established protocol and what impairments means at 0.08
- There are [drug recognition experts (DREs)](https://en.wikipedia.org/wiki/Drug_Recognition_Expert) that can use behavioral measures on scene, and we know they hold up in court with cannabis

*There is still ongoing debate of what defines impairment*

- If you can’t even get that defined and you have no roadside measures
- It’s harder, whether you’re using breath, hair, all these other things that people are trying to do
  - It sticks around in your system longer, or it can be in the follicles for this long
  - It’s like there is no good measurement

***We don’t have the impairment definition, and we don’t have good measures to get us there to figure out how we do that***

**The other thing which is really dangerous is poly usage**

- It’s rarely one of these on their own
- With cannabis, you see alcohol or other kinds of things that people are using at the same time
- That makes it even more difficult to figure out what people are using, especially in the roadside environment
- Mark was the administrator 6, 7 years ago, and all this research was still going on to try and define this
- As all these states now start making it more legal, he always tells people, “*When you’re voting for that in your state, don’t think about the sport of cannabis, but instead think about what that’s going to mean if somebody next to you on the roadway has been smoking, and in some way is like the level of impairment of alcohol.*”
  - People just don’t think of that part
- Unfortunately, while the alcohol is pretty well defined, the cannabis part is very poorly defined
- In that time, we still don’t have it figured out yet

**Is there a manner in which we can at least extrapolate from the standpoint of understanding?**

- Peter reasons that alcohol is a CNS depressant, and at the risk of talking through something that seems self-evident, he asks, “*What is the mechanism by which you think ethanol is contributing to mistakes?*”

**2 big categories of mistakes that lead to bad crashes and potential fatalities**

- 1 – Performance related ones are degraded or impaired: sustained attention, reaction time, and decision making
- 2 – Subjective perception is disconnected: they have no decision making
- Mark talks about this the same way with fatigue: there’s a **continuum** where you’re asleep on one end and you’re awake on the other end, but the alertness in between is a continuum
  - Most people would agree that being asleep at the wheel is not good
- Related to that continuum, we know that with sleep loss circadian disruption, alcohol, that your performance will degrade way before you actually fall asleep or are drunk enough to go unconscious
- That’s why Mark calls that *degraded* as opposed to the *impairment* where literally you can’t perform at all

*Degradation in the sleep realm*

- We can see 50% reduction in your decision-making, 30% reduction in your memory
- We can see 50-75% increase in your reaction time
- These very specific things when you’re in the driving mode trying to deal with the situation are going to affect you and your ability
- That’s why Mark always tells people, it’s like, “*Way before you have that fall asleep, go unconscious, you’ve got these performance degradations that put you at risk*.”

**Peter’s takeaway:** ***sleep and cannabis seem very similar in that they’re sedating, and there’s clearly a spectrum from completely debilitated to loosely less functional, and there’s no real way to measure it directly, the way you can use a breathalyzer for alcohol***

**Are there differences between how we view drowsiness due to sleep deprivation, or sleep interruption, and cannabis use?**

- Peter is bringing up cannabis, not because it’s the only other substance out there besides alcohol, and it’s becoming more and more ubiquitous
  - There’s a belief on some level, maybe somewhat warranted that it could be less toxic than alcohol
  - A lot of people are turning to cannabis now over alcohol, and he wonders if there are unintended consequences of that with regard to this domain
    - Mark is in agreement that this remains a hypothesis
- With everything we know about how physiology in the brain, and things work, it’s got to be ‒ we may not be able to quantify it quite yet
- A comment Mark often makes about sleep loss, and circadian disruption, “*When you lose sleep, you disrupt the clock, all aspects of human capability are degraded or impaired in some way.*”
- Mark mentions that because a new study comes out, and says, “*Oh, we just link this now to cancer in a new way or immune function in a new way*.”
  - His takeaway is: now we have more data and we can be more exact in certain areas (a good thing)
- But the overall comment holds, which is that everything we know about how cannabis works in the brain, how it’s going to affect us physiologically performance wise, we know that’s *not* going to improve things
  - It’s going to degrade them

***While we may get better at quantifying how bad that is, let’s be clear, it’s not a good thing for driving under the influence of that [cannabis]***

- There’s some great people at NIH and other places that are working on how to get that impairment level defined to think about what the test could be
  - We’ll get there
- It took a decade or two to get the alcohol ones the way they are now
- But for the moment, let’s be clear, everything we know is that’s a negative

**Another general comment about sleep**

- Everyone sleeps and they think they’re an expert
- Everyone is like, “*Yeah, I’ve lost some sleep, and I’m still here, I’m fine, etc.*”
- Whereas people will think about alcohol and cannabis: that’s more of a choice
  - And by the way, I don’t drink, or I don’t do this
  - No one’s ever going to say, “*Yeah, I think that sleep thing, I just stopped it.*”
    - That’s a requirement for our existence
    - So, it’s slightly different that way

**Are there any other prescription drugs that play a significant role in this?**

- The obvious ones that come to mind for Peter would be [benzodiazepines](https://en.wikipedia.org/wiki/Benzodiazepine)
- Mark is glad Peter brought this up because drunk and drugged includes prescription medication and over-the-counter medication

***Any antihistamine that makes you drowsy, any sedating antidepressant (trazodone) ‒ any of those have the potential to affect your sleepiness, alertness level when you’re driving***

- With a prescription, you don’t want to just read the label, you want to talk to your healthcare provider and see how much it could affect you
  - The same for over-the-counter medications
- You see a lot of polypharmacy, and after the fact investigators are trying to pull out exactly what people were taking
  - This is after after the fact post-hoc in an interview people will say it’s allergy season
    - Are you taking an allergy med that’s sedating or are you taking a non-drowsy version

## Mitigating the effects of vehicle speed [1:38:15]

- Speed makes up a pretty sizable fraction of the contributing forces

**Is that less today than it was 30 years ago?**

*It seems that cars are faster today than they used to be, but are people driving them faster today?*

*Is that not offset by the far greater impact of technology (seatbelt and airbags)?*

- It’s a big factor
  - Force = mass x acceleration
  - It’s all about the energy
- When you’re going faster and a crash happens, there’s literally more impact of what’s going to come out of that particular collision
- Speed has gone up, and that has more to do with the capability of the vehicles, roadways, and the technologies
- Peter thinks that outside of SUVs, cars are probably getting a lot lighter

*Does that not offset it on the car side of the equation?*

- Not very much, because generally, cars are getting bigger: now that we’ve added SUVs and others
- When we look at what’s going on out there, people describe it as a weight bloat that’s occurred
- Unfortunately, they do protect you
  - If you’re in one of those energy related kinds of crashes, the bigger the protective cage you have around you, the better off
  - People have a tendency to say, “*I want to be in that vehicle, not in the little small version where I could get killed doing that sort of thing*.”

***This is why it’s so complicated***

- During the pandemic, the deaths go down, but sometimes other particular things, like speeding goes up
- We can have all kinds of hypotheses about, “*Are there fewer people on the road, is just the density different, etc.?*”
  - They’re all hypotheses
  - We don’t really know
- Interesting that even the economic environment of our society can end up having effects beyond the usual causal or contributing factors (that we’re mostly focused on in this conversation)

**Road design is also used to control speed**

- The use of roundabouts or what they call “speed diets” where 2 lanes become 1 lane
- Having a dedicated pedestrian or cycling lane

**There is a huge debate on the use of technology**

- Not about alcohol where legislation was recently passed about using technology
- There is a lot of discussion about speed limiters
- Oftentimes when society has a choice or things we want to deal with, we go to technology

***All of a sudden now speed cameras, and speed limiters in vehicles are in more discussion than they have been in a decade***

**Peter goes back to another “deconstruct the accident” question. Do you have a sense or are these data knowable as to what fraction of those fatalities in the vehicle are a result of the integrity of the vehicle being lost due to the collision itself versus a flip?**

*In other words, how often is avoiding the flip of the vehicle with a lower center of gravity a relevant part of this equation?*

- Yeah, that’s actually a big deal
- When you look at the **crash tests** that are done, it’s interesting, they don’t actually crash vehicle to vehicle
- The crash worthiness of your vehicle is tested against a big block of cement basically
  - But now, there are different versions of that (such as a side impact)
  - Over the last few years, there’s also an angled one as well, and then rear end, and then you can add all kinds of other variations of that
- This is the sort of thing Mark doesn’t keep in his head anymore, but there are some databases that get a into things like **rollover**, and that’s where the side impact is critical
  - It’s mostly going to happen with the center of gravity, and when you’re up on a curb or some other thing that’s going to tip you potentially
  - The direction that you’re hit is important
- There is some data on that to show which are the versions, and that’s why they added things like the angled collision recently, just to figure out the crashworthiness of vehicles when they’re hit in an angle like that

**Are electric vehicles significantly safer than non-electric vehicles on the basis of a lower center of mass, and on the basis of not having an engine typically in the front during a front collision, therefore can have much more force absorptive capacity, or is that more of a marketing strategy?**

- We don’t have sufficient data yet to make that factual comment per se
- This is a range of the factors that differentiate electric vehicles from standard vehicles
- As you know, right now, one of the biggest things is just getting the myths separated from the fiction that is told
- There are still more fires in [ICE](https://en.wikipedia.org/wiki/Internal_combustion_engine) vehicles than there are in EVs
  - Some of that’s about battery
  - Some of that’s about the population that’s out there of these different
- You’ve got to get into that level of data analysis ‒ the segmentation and stuff
- Resources to dig into this:
  - [nhtsa.gov](https://www.nhtsa.gov/) is one place
  - [The Insurance Institute for Highway Safety](https://www.iihs.org/), they do a lot of great crash testing
- Mark’s caution is always that some of that is still in development as far as understanding the kind of differences
  - On the level of segmentation to actually make factual statements, Mark thinks we’re still developing a lot of that

## The promise and challenges of autonomous vehicles for road safety [1:44:15]

- Peter reasons: if you believe that north of 90% of these crashes have at their root cause errors by humans, then you would think that an autonomous vehicle [could be the answer], provided that the entire network of vehicles are autonomous
- That’s always been the big if, right?
- It’s not enough to just have *some* autonomous vehicles
  - That could actually make things worse

***You have to have everything being autonomous to have the potential to do better***

- Peter doesn’t think it goes from 94% to zero, but it seems that there’s a glide path

**What is your view of autonomous vehicles, and the hope that they bring to this problem?**

- In many ways Peter wonders if this is the solution as opposed to built-in speed limiters and breathalyzers
  - He was also going to half jokingly suggest that if we can put all of those things in cars, we can also probably put in eye flicker sensors, and we can track micro sleep
    - When he thinks back his residency and how tired he would be driving home (he could barely hold his eyes open)
- There are clear things you can build in to make humans less likely to hurt themselves
- Mark asks, “*When society has issues that are around human behavior, and choices, and errors we make, then do we look to technology as a way to help us do better, save lives, improve situations?*”

**Another** [**NHTSA study**](https://crashstats.nhtsa.dot.gov/Api/Public/ViewPublication/812069) **looked at lives saved over 52 years by 14 different technologies**

- These were as straightforward as seat belts, airbags, electronic stability control
- 613,501 were saved, and those are just the 14 technologies they looked at
  - These were related to the Federal Motor Vehicle Safety Standards, and other things that are in vehicles
- [To extrapolate from these numbers] you can’t do this, but Mark points out at 40,000 lives a year, we could have gone 15 years with no lives lost on our roadways
  - Kind of our conversation, not necessarily injuries or crashes,

***Technology works, and the potential is unbelievable, but we still have to prove it’s going to work and acknowledge that these new systems will also introduce new risks***

- There are going to be software risks, risks from machine learning and technology that are introduced
- We’ve got to make sure we address those as well
- Mark explains, “*Having said that, what you just described actually is the way I think we need to be using technology.*”
  - Peter identified the 2 big areas where technology can help: crashes due to speeding and drunk driving

**The higher level is a fully autonomous vehicle**

- This is where you take out the steering wheel, the pedals, and everything else
- The car will do the entire task
- [SAE](https://en.wikipedia.org/wiki/SAE_International) separates this into **5 levels** (we won’t get into all of that), but the human can be responsible for the lower levels of monitoring the environment and the vehicle
  - There’s an interim level (level 3) where the vehicle will do some of those things, and if it needs you back in the loop, it’s going to let you know
    - For example, it can tell you, “*Take the wheel*”
  - At level 4 and higher, the vehicle is going to do it for you: monitor the environment and the vehicle, and handle the driving task

**Is** [**Tesla**](https://www.tesla.com/) **the best example of commercial technology that is the furthest along in driver assist?**

- Mark is not sure it’s further along, but it has the most integrated systems of pulling those separate systems in
- The label “autopilot” is often used for this and it gives a sense that it is autonomous driving
  - When in fact, it’s actually a collection of driver assistance systems
    - That are made publicly because of regulatory requirements
    - That’s level 2
- Tesla is probably one of the more integrated systems that uses all these different things, but you’re seeing even traditional automakers offer all these different systems that are in there

***We have 280-300 million cars on the road today, and it can take anywhere from 10-12 years to penetrate the fleet with new technology***

- Peter thinks this timeline is optimistic, he was going to say it would take 20 years to overturn that fleet
- That is going to be one of those moments where Peter imagines a real regulatory challenge
- Peter loves internal combustion engines, but he has a belief that they are not going to be made for very long
- For example, you can still drive a 1967 Corvette today even though it doesn’t meet a single safety or emission standard that exists today
  - It gets grandfathered in as you go along
- But when we start to think about autonomous vehicles, and you get to this point where you say, “*Well look for the system to really work, every vehicle must be a level 4 or level 5,*” that is a totally different regulation
  - That’s no longer just saying to the car producer, “Y*ou can’t make a car that doesn’t meet these requirements.*”
  - It’s saying to the consumer, “*Oh by the way, you can’t have that car anymore*.”

**Is that what’s necessary here?**

- Mark compares it to horses: people still own them, breed them, and race them
  - You’ll still have it around

*This brings up the enormity of the problem*

- Yeah, this is the biggest infrastructure problem Peter can imagine
- When Mark was administrator, they actually put out the first Federal Automated Vehicles Policy, and people were screaming, “T*hat’s a nice policy, but what are you going to regulate?*”
- It’s a huge issue, and the autonomous vehicles aren’t there yet

***There’s some great programs going on demonstrating the potential of autonomous vehicles, but they’re not there yet for full deployment throughout our entire society***

- They’re great demonstration pilot programs, larger ones, and there are a lot of problems that are going on with some of the companies
  - It remains to be proven
  - We also need to understand where the risks are with that model
- One of the ways to conceptualize this is we’re probably on a path
- We used to debate, “*Do we just go along the levels, 1, 2, 3, 4, until we get up to 4 and 5 (fully autonomous), or do we jump right to 4 and 5, and let’s go for the full thing?*”
- [ADAS](https://en.wikipedia.org/wiki/Advanced_driver-assistance_system) is stepwise
  - Get people familiar with the technology, and see where the advantages are
  - See where it helps you and might save lives
- That will help move us eventually to where you can get your hands off the wheel for your commute or something else (let the vehicle do it)
  - If you want to race or do something else, that’s a different environment and a different task

*Mark thinks that question has been answered*

- We’re probably going to go through these steps where technology has been introduced
- We need to get enough data to show it’s really going to make a difference
- Once people see that it’s built in and it’s working, then they’ll be more comfortable with the technology

## Automatic emergency braking (AEB): the effectiveness and challenges of implementing AEB as a standard feature in new vehicles [1:53:00]

- When Mark was administrator, one of the things they did was challenge the auto industry to make [Automatic Emergency Braking [AEB]](https://en.wikipedia.org/wiki/Automated_emergency_braking_system) standard on every new vehicle by 2022 (or at least 95%, 99% of all the new vehicles)
- We originally had 10 manufacturers
- A couple months later, when we launched this program to try and get this going, we had 20 manufacturers basically covering about 95-99% of all new vehicles
- The whole idea was they would get in the room, and spend some time saying, “*What are the criteria that we want to see everybody?*”
- It’s called democratizing safety
  - It’s not just if you buy a higher-end car or it’s an option
  - Democratized means every new vehicle, [AEB](https://en.wikipedia.org/wiki/Automated_emergency_braking_system)

**The** [**Insurance Institute Highway Safety**](https://www.iihs.org/) **says, “*****If every car had AEB, we could probably reduce 50% of the rear-end crashes*****”**

**Peter clarifies**: “*This is not the warning that comes on when you’re about to hit somebody, but it actually will brake if the distance and rate of speed between you and the car in front of you triggers an algorithm that says, ‘You’re going to hit this thing.’*”

- Mark explains that this is why it’s so great to have time to discuss this stuff

[**AEB**](https://en.wikipedia.org/wiki/Automated_emergency_braking_system) **actually has multiple elements to it**

- The warning is one
- Another is, if you don’t brake, it’ll brake for you
- Another one is, if you brake but you don’t brake hard enough because of the distance, it will actually add braking power to what’s going on
- What this working group was saying is, “*Let’s figure out what the performance criteria will be for this AEB mandate.*”

***Mark brings this up is because it was not a regulation, and almost every regulation that has come through recently came from them challenging the manufactures and seeing who would agree***

- We ended up having 20 manufacturers come together
- Somebody recently put out a [report](https://www.iihs.org/news/detail/automakers-fulfill-autobrake-pledge-for-light-duty-vehicles) that said new cars meet that requirement
- These are new cars, and there’s still plenty of cars that don’t have this yet

**It’s going to take a while for all of that to change**

- It’s not a secret, but most people don’t understand this: to get a regulation through, you need to have the [Office of Management and Budget (OMB)](https://en.wikipedia.org/wiki/Office_of_Management_and_Budget) do a [cost-benefit ratio](https://en.wikipedia.org/wiki/Benefit%E2%80%93cost_ratio)
  - They’ve got to do a calculation that says, “*It’s worth it.*”
  - It usually takes a penetration of at least 10% of the vehicle population to get enough data to do that kind of analysis

**How does the OMB assign a cost to life?**

- The numbers are they, that’s always debated [[DOT valuation of a life](https://www.transportation.gov/office-policy/transportation-policy/revised-departmental-guidance-on-valuation-of-a-statistical-life-in-economic-analysis)]
- Peter points out, “*The cost of life doesn’t include loss or pain and suffering to the people who are left behind. It’s economic loss of life, meaning, you lost 10 years of your life working where you would’ve made this amount of money. So, it’s probably an underestimate of the true value of life by far.*”
  - Mark agrees
- You need to have at least 10% penetration of a technology in the vehicle population to collect the most basic data to send to the OMB so they can do the cost-benefit analysis
  - How many lives do you think you’re going to save, and what data to you have to demonstrate it
  - Substantiate it enough for the cost to the car, the manufacturer, and the society

***This is one of the challenges you see with these stepwise additions to these driver assist systems that are getting added, and things like AEB that are now standard have allowed that***

- The agency recently came out with something called an [Advanced Notice for Proposed Rulemaking, and a Notice for Proposed Rulemaking](https://www.nhtsa.gov/press-releases/heavy-vehicles-automatic-emergency-braking-proposed-rul): basically they’re now going to regulate AEB
- Part of the reason that they’ll be able to do that at an even better level (extending it to trucks, heavier vehicles) is because of this other work that was done that may democratize it as something that needs to be out there that everyone should be able to have in their vehicles

***Mark thinks we will continue to see stepwise progress***

**When we want to get to the full autonomous vehicle, the mixed fleet is going to be a huge problem for everybody**

- We’re going to have at least 3 groups: fully autonomous vehicles, vehicles that have a lot of the ADAS support systems, and people that are just driving cars that don’t have any of that stuff in it
  - They’ll all be on those streets, and you won’t know which is which, necessarily
- Mercedes just came up with a different color light for when it’s in autonomy for some of the things that they’re doing
- Back to the earlier conversation about defensive driving, just think about how more challenging that kind of environment is going to be

## Sleep deprivation: the impact of poor sleep, drowsiness, and disrupted circadian rhythm on driving [1:58:15]

- Peter realizes this is Mark’s life’s work, and it’s also the one that listeners are very familiar with
  - The implications of sleep deprivation

**What are the most important things you think you want people to understand with respect to how compromised sleep impacts driving?**

***When you lose sleep, you disrupt your circadian clock, and you will pay for it by having human capabilities degraded or impaired across the board***

> “*I don’t care what your job is or what task you’re on, but if you’re not getting the right sleep at the right time, you’re going to pay for it. This is one of those: you can’t fool human nature… There will be a price to pay.*”‒ Mark Rosekind

**Is there any regulation about when a truck driver can drive?**

- Peter understands there are clear regulations about how many hours he/she can drive, but do any of the regulations say, “*We’d like you to stay within your circadian rhythm, and do your driving … We’d like you to see a sunrise, and sunset, and drive accordingly, even though I know that that’s not necessarily convenient, and it might be far more convenient to drive through the night?*”
- If you understand sleep and the clock, some of what we do as a society is exactly opposite the way the world actually runs
- There are regulations in aviation, trucking, rail, for resident training hours, etc.

*There’s 2 physiological elements you’ve got to deal with: the sleep part and the clock*

- Usually it’s easier to deal with the sleep part, and people still don’t do that well
  - If you don’t have 10 hours off your job (you’re commuting), getting 8-9 hours of actual sleep opportunity [doesn’t happen]
    - Sleep opportunity doesn’t mean you’re going to get the sleep
- The circadian piece is a lot harder to keep stable in a 24/7 society with military operations, air traffic control, moving goods, operating airports

**Peter’s takeaway**: ***We’re going to quickly approach the limits of what humans are willing to do in terms of the sacrifices they’re willing to make. Therefore, we have to come up with technology to work around that.***

- We are not willing to live in a society where nothing happens at night, so we have to automate those processes so we don’t have to rely on individuals functioning a fractional reserve and fractional capacity
- We are so far away from that in our society now
- It might not be in our lifetime

**Start at the beginning, which is the information**

- The naivete and ignorance of society around the dangers, not just the performance [loss]
- This is still an emerging topic even though it’s been going on for a while
- [Bill Dement](https://en.wikipedia.org/wiki/William_C._Dement) who was Mark’s professor and became a friend and colleague, he was one of the leading voices who said, “*We got to pay attention to this because the price is too high.*”
- He pointed out that if we don’t start with education so that people appreciate not just what the cost is, but if you ***appreciate what the benefits are of getting the sleep you need and keeping the schedule***, that should outweigh putting yourself through this other stuff
  - That’s the individual piece

**If we accept that as a society, then we have to move to: what are the solutions going to be?**

- It’s not always intervening on the individual, give them drugs, do this
- It’s going to be these other things like technology that’s helps us offset those choices we make as a society that could still put us at risk

## Protecting pedestrians: strategies for reducing the risk of fatal accidents with pedestrians on foot or bicycle [2:02:30]

**What can an individual do as a foot pedestrian to minimize their risk?**

*How many times is a pedestrian killed when they have the right of way in a situation (they’re not jaywalking across a red that they shouldn’t be, they’re doing the right thing, they’re either up on the sidewalk and a car comes up on them, or they’re crossing when they should be crossing and someone runs in)?*

- This is a great question and Mark is not sure we have that data because of the categories these would be placed in
- If they weren’t doing something illegal, he’s not sure that kind of information would necessarily be collected
- Peter assumes data are tabulated for every time the pedestrian is “at fault”
  - He know we’re trying to get out of the at-faunt  mentality here and just solve the problem
  - Could you say, of the 42,000 people who died, 6,000 were pedestrians, and we have a clear example of 1,000 of those pedestrians were the ones at fault, and the driver tried to avoid them at the last second but couldn’t
    - Therefore, the other 5,000 pedestrians were not “at fault”?

*What does a pedestrian need to be on the lookout for to reduce those odds?*

> “*It is worth noting again, in the last decade, that number has gone up 50%. This last year the estimates are 7,500 people have died as pedestrians… So that’s significant.*”‒ Mark Rosekind

*Specific choices*

- 1 – If there is a sidewalk, walk on it because that’s a separation from the driving that’s going on
- 2 – If there’s no sidewalk, you actually want to walk against traffic (for visibility of stuff going on)
- 3 – When you’re crossing an intersection, find an intersection that’s got a crosswalk if you can and has some system of stop signs or counting for when you should go
  - Follow those rules as best you can
  - Even though 64-67% of pedestrian fatalities occur outside of intersections [the other 33-36% occur in intersections]
- 4 – Visibility, make sure people can see you, especially at night
  - Over 50% of these fatalities occur at night
- 5 – Situational awareness is critical
  - It’s amazing how many people could either be drinking or on their phone with their head down
  - Distraction, and the kinds of things you think about as a driver also apply to pedestrians and cyclists

*Are cyclists included in that 7,500 deaths per year?*

- No, Mark thinks those are just pedestrians
- He doesn’t remember the cyclist number
- Peter shares, “*As someone who rides his bike still outside, though not nearly as much as I used to, and frankly a lot of that is due to just my lack of faith in drivers, I certainly adhere to the principle of always assuming the car doesn’t see me, and always assuming that the driver is a moron.*”
  - The amount of people that will pass you (so they’ve presumably seen you), only to turn right in front of you is remarkable
- As a general rule as a pedestrian, assume drives *don’t* see you
  - They’re calibrated to look for bigger, faster things than you
- Mark points out, “*In California, pedestrians have the right of way wherever they are*”
  - But having a law on your side means nothing if you’re hit and dead or injured
  - Peter suggests, “*Assume you never have the right of way. Even when you do have the right of way, when you have that big green light and the big walking sign, still assume that a driver’s going to make a mistake because the consequences are much higher for you than them even though legally the law’s on your side.*”
- 6 – Peter reiterates looking both ways through the intersection
  - He tells people look left, then right, then left again because that left one is going to kill you when you’re driving
  - Even when you have the right of way

**When driving on a 4-lane road (2 lanes in each direction without a median)**

- Peter is never in the left lane unless passing just because it’s much harder for somebody to cross and weave into his lane
  - He stays in the right lane
- He thinks it’s funny that they have these 75 mph roads with no median that are typically 2 or 3 lanes in total
  - 2 in 1 direction, 1 in the other
  - Sometimes they’re 1 and 1 (those are nerve wracking)
    - Peter will not talk on the phone or listen to a podcast
    - All he’s doing is imagining how quickly he could veer off to the right if a truck got into his lane

> “*Don’t expect or assume that people are going to actually follow the rules.*”‒ Mark Rosekind

- Mark adds a slight nuance to what Peter said as part of the defensive driving piece
  - Don’t expect or assume that people are going to actually follow the rules
  - You may be at that intersection and looking, but don’t think because someone’s got a stop sign that they’re going to follow the rules
    - That includes yellow lights, red lights

***If there’s someone there and they’re a potential risk, your choice is whether you decide to proceed through, slow down, pause. Those are things that are under your control.***

**Peter’s experience 2 days ago**

- Peter was driving somewhere and he was in the right-hand lane and he was going to make a right-hand turn into something
- This is a 50 mph road
- He didn’t realize there was a driveway before where he was going to make a right
- He put his right blinker on
- It was about 300 feet before where he was about to turn right, and a woman came to the edge of the road (where he didn’t realize there was a road as it’s easy to miss), and she looked at him, saw his blinker, and just pulled out assuming he was going to turn there
  - You could argue that technically she’s right because he had his blinker on
  - But he had that blinker on long before she showed up thinking he was going to turn there and not at the next one
- He had to really slam on the brakes not to hit her
- She would’ve taken the brunt of that, not him
  - It’s not about fault
  - It’s what is the consequence of this awful collision?
- Peter was amazed that she pulled out when his rate of speed hadn’t even begun to slow
- He wondered, “*How does she not see how fast I’m going? What did she think I was going to do… to allow me to turn that quickly?*”
- This is a perfect example of what Mark just explained: don’t assume people are going to follow the rules or that what you’re seeing is what’s going to happen
- She wasn’t thinking, she just assumed that the right signal meant you were turning into where she is

***Peter suggests you take fault out of this and think about root cause effect***

**The only accident Peter has ever been in was a very bad accident where the other person was 100% at fault**

- They ran a red light while he was going the correct speed limit (50 mph) through an intersection
- Luckily for this woman, he hit the passenger side, not the driver’s side
  - He was the only person in the car
  - He was in a pickup truck, she was in a sedan
- He hit her so hard that both vehicles were a write-off
- It’s the only vehicle he’s been in where the airbags deployed
- What struck Peter was at how quickly it happened because he was driving this way and she was stationary to make a left
- He saw her the whole time but never thought she would jet out in front
- She erroneously thought she had a green light to go even though she had a red arrow
- She just pulled out slowly
- He did probably get the brakes on before he hit her
- He thinks about that and had she had a passenger in that car, it could have been a very different situation

***It happens so quickly that you don’t have to make the mistake to suffer the consequence***

**Mark appreciates Peter telling these stories**

- Some people are good at it, some people don’t like to talk about them, but this touches everybody
- Mark adds, “*You’ve lost someone in a roadway and the emotions you were experiencing are so justified and understood, and your approach to how you think about it now [is] based in all of that.*”
- These 2 drivers did different things, but neither one of them thought, “*I’ll go out today and see if I can get killed… [or] let me see if I can run into somebody*.”

**It’s a complex dynamic environment with humans that are imperfect and make bad choices and also errors in what they do**

*How do we try and do that more safely?*

- That encapsulates everything we’ve been talking about, big societal changes, how do we make this better for everyone?

***But a lot of it comes down to your behavior, what you can control***

- The stuff that’s out of control, you can still do something about [it] in some situations

**There’s a whole culture around cars, and that’s part of what’s going on here too**

- It’s our independence, it’s economics, it’s family, it’s just sort of the American way of “don’t tell me how”
- This is why Mark thinks whe we ever have fully autonomous cars we can save lives
  - He’s not sure we know that yet
  - Maybe we can work toward that way when the data can justify it

***For the moment there’s a huge car culture that’s in operation here that clearly is affecting our choices and willingness to give certain things up for these other societal benefits that we know we could attain***

## Empowering safe driving: essential resources and tips for parents and teenage drivers [2:14:00]

**Are there any resources you would point people to who are interested in the “what can I do?”**

*Especially for parents who have teenage kids who are starting to drive and want to get them started in the best way possible*

- There are a few websites
- 1 – [NHTSA.gov](https://www.nhtsa.gov/) it has a [VIN](https://en.wikipedia.org/wiki/Vehicle_identification_number) lookup and you can search your car to see if it has a [defect and recall](https://www.nhtsa.gov/recalls) you should take care up
  - You can look up [car seats](https://www.nhtsa.gov/vehicle-safety/car-seats-and-booster-seats) [scroll down halfway]: put your kid’s birthdate, height, weight, and it’ll give you recommendations of whether it’s a backwards or forwards booster seat, etc.
  - All the data we’re talking about that Mark can’t keep in his head is on that website
- NHTSA runs a [New Car Assessment Program (NCAP)](https://www.nhtsa.gov/ratings)
  - It’s the five stars, stars for cars
  - It’s what’s on the [Monroney label](https://en.wikipedia.org/wiki/Monroney_sticker) on your new car
    - That’s the stars evaluating its crash worthiness and some other factors

> “*When you’re thinking about where should I start, well, just start with the ratings*.”‒ Mark Rosekind

- 2 – The [Insurance Institute for Highway Safety (IIHS)](https://www.iihs.org/)
  - They do a lot of the crash testing, but they also have a lot of research that they do
  - They’re the ones who do the [Top Safety Pick](https://www.iihs.org/ratings/top-safety-picks) and other kinds of things
- That AEB challenge Mark talked about, that was a collaboration between NHTSA and IIHS doing that challenge for the industry to democratize AEB
- Besides the crash information, they also have other studies and things they do
- 3 – The [National Safety Council (NSC)](https://injuryfacts.nsc.org/) have great data because they all have car stuff, they have [pedestrian](https://injuryfacts.nsc.org/motor-vehicle/road-users/pedestrians/) stuff, they have [cyclist](https://injuryfacts.nsc.org/home-and-community/safety-topics/bicycle-deaths) information
  - They’re really good for general resources for safety
- 4 – [Safe Kids Worldwide](https://www.safekids.org/): they [certify car seat technicians](https://cert.safekids.org/become-tech) because 60, 70% of car seats are installed incorrectly (it’s >50%)

*When you get to teenagers*

- AAA has different kinds of [driver contracts](https://exchange.aaa.com/wp-content/uploads/2021/03/Parent.Teen_.Driving.Agreement.pdf) you can use
- The insurance company also has a foundation, so they have a lot of good auto safety information there as well
- You should also look this up because depending on the state, they may have [graduated licensing](https://en.wikipedia.org/wiki/Graduated_driver_licensing)
  - That licensing for new drivers actually includes can you have other kids in the car? No.
  - Can you drive after dark? No.
  - This for six months, this for a year, etc.
- You should look at the [AAA graduated licensing](https://exchange.aaa.com/safety/teen-driver-safety/licensing-process/) and just see what the elements are and then come up with your own
- Do your own assessment
  - Could you measure some of that in the simulator?
- Whatever you could do to bolster her [a teen] with more education experience would make her more situationally aware and defensive when she’s driving would be a great benefit

**Younger drivers are less and less interested in getting their driver’s licenses right away**

- This is something Mark has seen in the last 5-10 years
- There are college kids that don’t know how to drive
  - Or they’re waiting until after college when they have a job
  - Or they’re picking their location by public transit
- Peter thinks that might be a great trend given what Mark said about the maturation of kids

**Peter’s daughter is not psyched about driving a manual transmission truck**

- Every time she fusses about it he will say “*I mean you could take the bus. That’s cool too. But if you want to drive, you’re going to be driving stick.*”
- A big part of that is the connection to the drive and it reduces at least 1 of those variables, which is the distractibility
- She’s nervous about rolling backwards on hills, and Peter’s like, “*Good. Concentrate harder.*”
  - Learn that skill so it becomes a non-issue for you

## Promoting a culture of proactive safety: parting thoughts from Mark [2:19:15]

**Peter’s overall takeaway**

- This has been really illuminating and quite disturbing
- He wishes there was a way to convey every 1 of the 42,929 stories of people who died 2 years ago (the most recent data we have)
- Unlike when we think of all the chronic diseases that Peter spends most of his time thinking about and talking about
  - They disproportionately affect older people
  - Your risk of death from cardiovascular disease, stroke, cancer, and Alzheimer’s disease, this is disproportionately a disease of the elderly
- When Peter last looked at this in 2020, the thing that stuck out to him the most was that automotive deaths were the most uniform cause of death by decade of *anything* in the top 10 causes of death
  - There was nothing more uniform than dying in a car
  - Equal opportunity killer

**Mark points out parallels between health and road safety**

- One of the reasons he really looked at safety and transportation from a sleep interest is death can be instantaneous
  - You don’t get to say goodbye to your grandmother whose had cancer for 2 years
  - That’s one thing that separates it in some ways from those chronic illnesses
- There are some real significant parallels when he things about this

***One of the big pushes Mark has tried to make happen in the automotive realm is to move from a reactive safety culture to a proactive one***

- He thinks the parallel of what Peter does for prevention and thinking about how do we eliminate or mitigate the things we know that can cause bad stuff
  - How do we promote what we know will make good stuff happen
- Having worked in NASA as a NASA scientist on the aviation side, they’re very proactive
- In aviation, they went 12 years where no person in the US died in a commercial aircraft crash
  - And then it was one
- Mark always tells people, it’s so hard to get there, but it’s even harder to stay there, saving all those lives

***That takes a proactive culture that says we’re going to do what we can to eliminate or mitigate, diminish what those risks are and promote the good stuff we know that’s going to make a difference***

- Mark points out that Peter does that all the time, and this is why he said thank you at the beginning
  - Thank you for bringing this into that realm, and not just public health

***This is societal safety; there’s a real parallel there, there’s a chance to be more proactive***

- When you think about it, an investigation is reactive
  - A bad thing happens and we investigate

***To make it proactive, what we learn from the investigation has to be translated into some action that’s going to prevent it from happening again***

- Just having people discuss this and think about it, tell their story to someone else ‒ those can save lives
- Mark doesn’t know Peter’s daughter, but she’s way better off for the fact that Peter has talked about this, thought about it, and will provide context and a skill set to her
  - Peter may not even be around when it saves her life or her kids life or some other person in her sphere
    - That’s the societal change and a proactive way that’s going to make the big difference
- We need to save them one at a time
- The consequences are so significant, because we can’t bring those back
- The question is, “*How do we use those as opportunities though to make the future for you, your daughter, her family, my kids, et cetera? What do we do to make that in a proactive way safer for the future?*”
- Mark notes that Peter is doing that straight on with the healthcare
- The parallel is there in this realm because the costs are so high
- From this conversation, Peter realizes there are so many pieces that are changing with the technology that are going to move us in the right direction

**If Peter could make a change based on what was discussed, he wishes that for every significant accident or fatality that occurred in a given city, the story was told from 2 fronts**

- 1 – In the human sense so that we understood the life (or lives) that were lost, the consequences, and how that’s going to ripple through forever
  - How Nick’s wife lost her husband and Nick’s kids lost their dad
- 2 – Also, in a very clinical autopsy like manner of the accident, if all of us could see a 60-second video that would say, “*This This is what happened on this date and this time, and these are the contributing factors.*”
- And everybody has to invest
  - That’s not a big price to pay for those of us who are alive
  - That every time somebody dies, you’ve got to invest a minute hearing how it happened
- This is going to make us better drivers
- Mark agrees and would extend this to not just identify the causal contributing factors, but also include if there’s any action that people could take to do things differently
- Think about the local  intersection Peter talked about earlier, without what Peter just described, it’s going to keep happening
  - People aren’t going to know what happened there or if there’s anything different they could do to spare lives

§

## Selected Links / Related Material

**NHTSA**: [NHTSA: National Highway Traffic Safety Administration](https://www.nhtsa.gov/)  | [1:30]

**NTSB**: [NTSB: National Transportation Safety Board](https://www.ntsb.gov/Pages/home.aspx) | [1:45]

**Fatigue countermeasures program**: [Fatigue Countermeasures Laboratory @ NASA Ames Research Center](https://hsi.arc.nasa.gov/groups/fatigue/) | [2:00]

**Final traffic stats from 2021**: [Traffic Safety Facts 2021: A Compilation of Motor Vehicle Crash Data](https://crashstats.nhtsa.dot.gov/Api/Public/ViewPublication/813527) | [18:45]

**Stats on road safety and crash testing**: [National Highway Traffic Safety Administration: NHTSA](https://www.nhtsa.gov/) | [20:00, 1:44:00, 2:14:45]

**Breath technology to measure blood alcohol**: [Breath Technology – dadss – Driver Alcohol Detection System](https://dadss.org/breath-technology/) | [1:04:45]

**Human error causes most crashes**: [Critical Reasons for Crashes Investigated in the National Motor Vehicle Crash Causation Survey](https://crashstats.nhtsa.dot.gov/Api/Public/ViewPublication/812506) | NHTSA (2018) | [1:16:15]

**Institute of Medicine report of medical errors**: T[o Err is Human: Building a Safer Health System](https://nap.nationalacademies.org/resource/9728/To-Err-is-Human-1999--report-brief.pdf) | National Academies (1999) | [1:18:30]

**Data on car safety**: [1:44:00, 2:14:45]

- [National Highway Traffic Safety Administration: NHTSA](https://www.nhtsa.gov/)
- [IIHS-HLDI](https://www.iihs.org/)

**Lives saved by 14 technologies over 52 years**: [Lives Saved by Vehicle Safety Technologies and Associated Federal Motor Vehicle Safety Standards, 1960 to 2012](https://crashstats.nhtsa.dot.gov/Api/Public/ViewPublication/812069) | NHTSA (C Kahane, 2015) | [1:46:00]

**Report that autos now meet the AEB requirement**: [Automakers fulfill autobrake pledge for light-duty vehicles](https://www.iihs.org/news/detail/automakers-fulfill-autobrake-pledge-for-light-duty-vehicles) | IIHS (2023) | [1:55:00]

**2023 estimate for traffic fatalities**: [Early estimate of Motor Vehicle Traffic Fatalities For the First 9 months (January-September) of 2023](https://crashstats.nhtsa.dot.gov/Api/Public/ViewPublication/813530) | NHTSA (2023)

**Pedestrian safety and fatalities**: [2:04:00, 2:16:00]

- [Pedestrian Safety](https://www.nhtsa.gov/book/countermeasures-that-work/pedestrian-safety) | NHTSA (2024)
- [Road Users: Pedestrians](https://injuryfacts.nsc.org/motor-vehicle/road-users/pedestrians/) | NSC injury facts (2024)

**Cyclist safety and fatalities**: [2:05:30, 2:16:00]

- [Bicycle Safety](https://www.nhtsa.gov/book/countermeasures-that-work/bicycle-safety#:~:text=From%202010%20to%202021%2C%20bicyclist,2022%3B%20Stewart%2C%202023).) | NHTSA (2024)
- [Bicycle Deaths](https://injuryfacts.nsc.org/home-and-community/safety-topics/bicycle-deaths) | NSC injury facts (2024)

**NHTSA recalls**: [Check For Recalls](https://www.nhtsa.gov/recalls) | NHTSA (2024) | [2:14:45]

**Car seat recommendations for kids size**: [Car seats and Booster seats](https://www.nhtsa.gov/vehicle-safety/car-seats-and-booster-seats#find-compare-seats) | NHTSA (2024) | [2:15:00]

**New car assessment program**: [Ratings](https://www.nhtsa.gov/ratings) | NHTSA (2024) | [2:15:15]

**Vehicle top safety pick**: [2023 Top Safety Picks](https://www.iihs.org/ratings/top-safety-picks) | IIHS (2024) | [2:15:45]

**National safety council**: [2:16:00]

- [Roadway safety for all roadway users](https://www.nsc.org/road) | NSC (2024)
- [National Safety Council injury facts](https://injuryfacts.nsc.org/) | NSC injury facts (2024)

**Safe Kids Worldwide**: [Safe Kids Worldwide](https://cert.safekids.org/become-tech) (2024) | [2:16:45]

**AAA driver contracts for teens**: [2:17:00]

- [AAA StartSmart Parent-Teen Driving Agreement](https://exchange.aaa.com/wp-content/uploads/2021/03/Parent.Teen_.Driving.Agreement.pdf)
- [Parent-Teen Driving Agreement](https://www.aaa.com/AAA/005/public/resources/downloads/parent_teen_driving_agreement.pdf)

**AAA graduated licensing**: [Licensing Process](https://exchange.aaa.com/safety/teen-driver-safety/licensing-process/) | AAA Exchange (2022) | [2:17:30]

§

## People Mentioned

- [William Dement](https://en.wikipedia.org/wiki/William_C._Dement) (1928-2020, American sleep researcher and founder of the Sleep Research Center at Stanford University) [11:00, 2:01:30]
- [Mary Carskadon](https://en.wikipedia.org/wiki/Mary_Carskadon) (Professor of Psychiatry and Human Behavior and Director of the EP Bradley Hospital COBRE Center for Sleep and Circadian Rhythms at Brown University) [13:30]
- [Lawrence (Larry) Blincoe](https://www.researchgate.net/profile/Lawrence-Blincoe) (statistician at the NHTSA) [31:15]
- [Jean Todt](https://en.wikipedia.org/wiki/Jean_Todt) (French motor racing executive, previously the Scuderia Ferrari Formula 1 team principal) [39:45]
- [Ayrton Senna](https://en.wikipedia.org/wiki/Ayrton_Senna) (1960-1994, Brazilian racing driver, winner of 3 F1 Worlds Championships) [44:15]
- [Max Mosley](https://en.wikipedia.org/wiki/Max_Mosley) (1940-2021, former president of the Fédération Internationale de l’Automobile (FIA), the governing body for F1) [44:15]
- [Deborah (Debbie) Hersman](https://en.wikipedia.org/wiki/Deborah_Hersman) (12th chairman of the NTSB) [59:45]
- [Nick Venuto](https://www.nbcsandiego.com/news/local/cyclist-killed-by-suv-remembered/1899184/) (Peter’s former coworker killed while cycling home from work) [1:08:30]

§

##### Mark Rosekind, Ph.D.

Mark R. Rosekind earned his A.B. with honors from Stanford University, his M.S., M.Phil., and Ph.D. from Yale University. He completed a postdoctoral fellowship at the Brown University Medical School.

Dr. Rosekind is a dynamic, visionary on safety, sleep/fatigue, and policy leader with more than 30 years of experience enacting strategic, practical, and effective data-based solutions that enhance safety and health in complex environments. He launched his professional career as the director of the Center for Human Sleep Research at the Stanford University Sleep Disorders and Research Center. He then directed the Fatigue Countermeasures Program at the NASA Ames Research Center and was chief of the Aviation Operations Branch in the Flight Management and Human Factors Division. He brought his expertise to the private sector by founding Alertness Solutions, a scientific consulting firm that specialized in fatigue management, and served as the company’s first president and chief scientist.

Dr. Rosekind was appointed by President Obama and served as the 40th member of the National Transportation Safety Board (NTSB) from 2010 to 2014. He was the on-scene board member for seven major transportation accidents and participated in almost 50 accident Board Meetings. He advanced the agency’s advocacy goals on substance-impaired driving, fatigue, fire safety, and rail mass transit.

Dr. Rosekind was appointed by President Obama as the 15th Administrator of the National Highway Traffic Safety Administration (NHTSA), serving from 2014 to 2017. While at NHTSA, his initiatives included the development and issuance of the first-ever Federal Automated Vehicles Policy, the founding of the Road to Zero coalition to develop a 30-year plan to eliminate traffic fatalities, and aggressive oversight of safety in the automobile industry, including leading the Agency through the nation’s largest product safety recall in U.S history.

Dr. Rosekind was the Chief Safety Innovation Officer at Zoox, an Amazon owned autonomous mobility company, from 2017-2022. He also was appointed the Distinguished Policy Scholar in the Department of Health Policy and Management at the Johns Hopkins Bloomberg School of Public Health for 2020-2022.

Dr. Rosekind is an internationally recognized expert on human fatigue, credited with leading the field in innovative research and implementing programs in all modes of transportation. His work has been widely published. His awards include NASA’s Exceptional Service Medal and six other NASA group/team awards; the Lifetime Achievement Award from the National Sleep Foundation; the Mark O. Hatfield Award for Public Policy from the American Academy of Sleep Medicine; two Flight Safety Foundation honors; and Fellow of the World Economic Forum in Davos, Switzerland.