# #363 ‒ A new frontier in neurosurgery: restoring brain function with brain-computer interfaces, advancing glioblastoma care, and new hope for devastating brain diseases | Edward Chang, M.D.

**Source:** [https://peterattiamd.com/edwardchang/](https://peterattiamd.com/edwardchang/)

---

Edward Chang is a neurosurgeon, scientist, and a pioneering leader in functional neurosurgery and brain-computer interface technology, whose work spans the operating room, the research lab, and the engineering bench to restore speech and movement for patients who have lost these capabilities. In this episode, Edward explains the evolution of modern neurosurgery and its dramatic reduction in collateral damage, the experience of awake brain surgery, real-time mapping to protect critical functions, and the split-second decisions surgeons make. He also discusses breakthroughs in brain-computer interfaces and functional electrical stimulation systems, strategies for improving outcomes in glioblastoma, and his vision for slimmer, safer implants that could turn devastating conditions like ALS, spinal cord injury, and aggressive brain tumors into more manageable chronic illnesses.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/edwardchang/the_Drive_public.png)

Play

#363 ‒ A new frontier in neurosurgery: restoring brain function with brain-computer interfaces, advancing glioblastoma care, and new hope for devastating brain diseases | Edward Chang, M.D.

#363 ‒ A new frontier in neurosurgery: restoring brain function with brain-computer interfaces, advancing glioblastoma care, and new hope for devastating brain diseases | Edward Chang, M.D.

1x15s30s

0:001:53:25

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- The evolution of neurosurgery and the shift toward minimally invasive techniques [A: 2:30, V: 1:17];
- Glioblastomas: biology, current treatments, and emerging strategies to overcome its challenges [A: 10:45, V: 10:58];
- How brain mapping has advanced from preserving function during surgery to revealing how neurons encode language and cognition [A: 16:30, V: 17:39];
- How awake brain surgery is performed [A: 22:00, V: 24:22];
- How brain redundancy and plasticity allow some regions to be safely resected, the role of the corpus callosum in epilepsy surgery, and the clinical and philosophical implications of disconnecting the hemispheres [A: 26:15, V: 29:02];
- How neural engineering may restore lost functions in neurodegenerative disease, how thought mapping varies across individuals, and how sensory decline contributes to cognitive aging [A: 39:15, V: 43:46];
- Brain–computer interfaces explained: EEG vs. ECoG vs. single-cell electrodes and their trade-offs [A: 48:30, V: 54:40];
- Edward’s clinical trial using ECoG to restore speech to a stroke patient [A: 1:01:00, V: 1:09:02];
- How a stroke patient regained speech through brain–computer interfaces: training, AI decoding, and the path to scalable technology [A: 1:10:45, V: 1:20:41];
- Using brain-computer interfaces to restore breathing, movement, and broader function in ALS patients [A: 1:28:15, V: 1:41:10];
- The 2030 outlook for brain–computer interfaces [A: 1:34:00, V: 1:47:56];
- The potential of stem cell and cell-based therapies for regenerating lost brain function [A: 1:38:00, V: 1:52:35];
- Edward’s vision for how neurosurgery and treatments for glioblastoma, Parkinson’s disease, and Alzheimer’s disease may evolve by 2040 [A: 1:42:15, V: 1:57:54];
- The rare but dangerous risk of vertebral artery dissections from chiropractic neck adjustments and high-velocity movements [A: 1:44:45, V: 2:00:43];
- How Harvey Cushing might view modern neurosurgery, and how the field has shifted from damage avoidance to unlocking the brain’s functions [A: 1:46:15, V: 2:02:31]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dr. Edward Chang is the chair of neurosurgery at UCSF and a leading innovator in functional neurosurgery and brain-computer interface
- Edward’s work bridges the operating room, the research lab, and the engineering bench to restore speech and movement for patients who have lost these traits

In this episode, we discuss:

- How modern neurosurgery evolved
  - Dramatically reducing collateral damage and recovery time
- What happens during awake brain surgery
  - Why the brain feels no pain
  - How realtime mapping protects language and motor function
  - The split-second decisions surgeons make at the edge of the eloquent cortex
- Breakthroughs in brain-computer interfaces
  - Neural engineering’s next frontier
  - Fully emplantable, wireless brain-computer interfaces and functional electrical stimulation systems that may bypass damaged nerves to restore breathing or limb control
- How genomic profiling, immune based strategies, and more extensive resections are slowly turning glioblastoma (a once uniformly fatal tumor) into a slightly longer, survivable disease
- Edward’s vision for 2030 and beyond
  - Slimmer, safer brain implants to restore speech for people with paralysis and other injuries
  - How advances will help turn conditions like ALS, spinal cord injury, and even aggressive brain tumors into more chronic, manageable illnesses

## The evolution of neurosurgery and the shift toward minimally invasive techniques [A: 2:30, V: 1:17]

- There’s so much Peter wants to talk about with respect to Edward’s career, the field of neurosurgery today, and how the bounds are really being pushed
- Neurosurgery remains a little bit of a black box

**What were the typical problems that would’ve presented to a neurosurgeon in the latter part of the 19th century, and what were the tools they had at their disposal?**

- We’re speaking after the development of anesthesia
- It’s a very small group of physicians that are taking care of fairly severe indications
- It’s a rarefied field that requires very long training in addition

If we go back 100 years, we’re talking about the era of [Harvey Cushing](https://en.wikipedia.org/wiki/Harvey_Cushing) who’s considered the father of modern neurosurgery

- That was a clear inflection point in the history of medicine, in the history of neuroscience, and the history of neurosurgery
- It was really the beginning of what we’d call the modern neurosurgery
- Cushing was a really an astute observer, an incredibly technically skilled surgeon, and also an incredible internist
  - He diagnosed some of the first pituitary tumors and the effects of those on endocrine function
- This was the era of modern tools of craniotomy
  - Opening the skull to get access to brain tumors and everything followed since then

**⇒** The **main categories of neurosurgery** have to do with tumors, the vascular system (which are aneurysms and strokes and blood clot), the spine, and then probably the most recent one is the one we call “functional”

- **Functional neurosurgery** has to do with understanding the functions of brain circuit but also intervening to change how they work using deep brain stimulation or other ablation methods
- Harvey Cushing would be credited for the development of the [electrocautery](https://en.wikipedia.org/wiki/Cauterization#Electrocautery)
  - It’s hard to imagine you could operate without one of those
  - It’s the key of controlling bleeding in any surgery, but particularly in the brain (it’s a tricky thing)

***Harvey Cushing was just the starting point of modern neurosurgery***

Then there’s [Wilder Penfield](https://en.wikipedia.org/wiki/Wilder_Penfield)

- He who was an American but really did some incredible work in creating the Montreal Neurological Institute, and that was really the beginning of what we would consider modern [epilepsy surgery](https://en.wikipedia.org/wiki/Epilepsy_surgery)
  - Surgeries that are designed to stop people from having seizures
- He popularized this thing that we all learn in medical school called the [homunculus](https://en.wikipedia.org/wiki/Homunculus) [shown in the figure below]
  - It’s this picture of the little man there and essentially the part of our brain that controls every muscle in our body and how it’s laid out in that particular part of the brain
  - It’s something that we all learn

![](https://peterattiamd.com/wp-content/uploads/2025/09/f1-edwardchang.png)

**Figure 1. Homunculus**. Image credit: [Evidence-Based Medicine Consult](https://www.ebmconsult.com/articles/homunculus-sensory-motor-cortex)

- He was also a brilliant scientist who helped us understand some of the basic things that we know about language and, from a technical perspective, really popularized and developed the concept of awake brain surgery
- Awake brain surgery is really something that’s captivated Edward since medical school and what he specializes in now

**Fast forward to the ‘70s and ‘80s, what was state of the art 40, 50 years ago with respect to vascular management, oncologic management of masses in the brain relative to today?**

*What were the plateaus in technology?*

- Some of the things that we do now are almost identical to the way that Cushing did it over 100 years ago, and then some of it is radically different
- One of the workhorse surgeries that we do is called a [craniotomy](https://en.wikipedia.org/wiki/Craniotomy)
  - That basically means where you remove a piece of bone temporarily (you replace it at the end of the procedure) to access something like a brain tumor that’s in the frontal or a temporal lobe
  - That’s still being performed today and still really indicated
- But where we are now, there’s ways of using laser probes through very small incisions to get to deep targets in the brain to ablate them
- There are ways of now even using [focus ultrasound](https://en.wikipedia.org/wiki/Focused_ultrasound) that can be targeted to specific nuclei in deep parts of the brain in order to control someone’s tremor for example

***This is what we would consider a relatively non-invasive approach to do a neurosurgery ‒ so things have changed radically***

One other area where we have seen tremendous disruption is in the vascular neurosurgery field

- Back in the ‘80s and ‘90s, you’d have a large craniotomy and incision probably about 7-9 inches long, removal of a piece of bone and then using an operative microscope to dissect down to the deepest parts where the blood vessels are coming to fix, let’s say, an aneurysm
  - An aneurysm is essentially a ballooning of a blood vessel that when it ruptures, can be fatal
  - That is a lot of what Edward trained on

**⇒** Nowadays, 90% of those procedures are now done through a catheter in the groin that’s visualized

- We put coils into the aneurysms to help secure them
- We can now do stents ‒ a huge change now being able to retrieve and dissolve clots that are causing acute severe strokes

Probably the most dramatic things that we’ve seen

- Someone comes in, not able to talk, paralyzed on half side of the body

- In the old days, we would just give some medications keeping our fingers crossed that that would work
  - It rarely worked; it was really the minority of cases that it helped
- Nowadays, there’s a much bigger fraction of patients where you can put the device in and retrieve the stroke
  - These are really game-changing things when someone can go home the next day after such a huge thing

***We’re starting to see things like stroke become more like heart attacks***

- The cath labs are not just treating heart attacks but they’re also treating what we call “brain attacks” or strokes
- Some things are relatively similar to 100 years ago and then some things have just been totally changed

**If 30 years ago, a neurosurgeon was doing a craniotomy virtually every time they were addressing a pathology, today it might be less than half the time?**

- Yeah, that’s right
- Peter notices that’s not a dissimilar parallel to what we see in other parts of surgery
- He was just talking to a vascular surgeon a couple of weeks ago who finished his training around the time Peter did and Peter asked, “*How many open surgical procedures are you doing?*”
  - Peter was talking about AAAs and all sorts of Fem-Pops and things like that
  - He said it’s virtually all done with stents… even carotid arteries, the whole thing
  - Peter was really blown away at how little they’re operating now in an open sense

***What’s happened with surgery is the force of evolution is guiding us towards things that are more minimally invasive, with less collateral damage to get to the targets and get people back to life sooner***

> “*It’s a very exciting time, actually, to be in medicine with all this technology that’s coming on board.*”‒ Edward Chang

## Glioblastomas: biology, current treatments, and emerging strategies to overcome its challenges [A: 10:45, V: 10:58]

- Whenever Peter thinks of the brain, he thinks of [GBMs](https://en.wikipedia.org/wiki/Glioblastoma) (these awful tumors)

**Tell folks what a GBM is, and why a GBM is truly one of the cancers that gives cancer a bad name**

*Given that traditional surgery has historically never worked for this tumor, you simply can’t resolve it; and you think about the transition away from craniotomy, big, open procedure, is there anything on the horizon for GBMs to render them less lethal?*

- GBM stands for glioblastoma multiforme
- If you break it down, what it’s referring to: the glial part of that word refers to the cell origin
- The brain has different types of cells and, if you look in the big buckets:
  - There’s neurons, which are the ones that primarily are the ones that allow us to do thinking and function
  - There’s a large population of support cells that we call glia
- That’s the first part, **glioblastoma** originates from those support cell population (the glia)
- Then **multiforme** refers to these original descriptions histologically of the tumors that really showed multiple form, multiple histology

***Some of the key features of it are the necrosis, the tumor grows so quickly that it outstrips its blood supply and, in its wake, it leaves cell death (what we call necrosis)***

- It really is a terrible disease and condition
- We are making progress, specifically around understanding what causes it
- 10 years ago, you would remove one of these tumors, you send it to the lab and you could get the diagnosis that this is a glioblastoma
- Now, in most academic medical centers, you’ll also get a genetic profile of the tumor
  - So, nowadays, we actually know specifically what kind of mutations are involved in the tumor, and that’s going to be really critical for this next chapter which is using those genetic alterations to tailor and personalize chemotherapy and more

***This has big implications because we’re now moving from an era where we use a visualization of the histology → to this molecular profiling (which is more mechanistic)***

- The new chemo agents are really going to be targeting mechanisms as opposed to general things like cell cycle and metabolism and things like that
- These are the things that are changing and we need it to change faster

**There are also really exciting things that we’re seeing around new ways to train the immune cells to target things**

- It turns out that glioblastomas actually suppress parts of the immune system so they like growing in stealth, and they activate molecules and cells in a cloak way that can’t be recognized by immune cells anymore
- If we can basically allow the tumors to be recognized by the immune system, that could be something that really unlocks therapy in the future too

**The things that we do know that work pretty well right now, at least in terms of prolonging survival for patients (and really meaningful survival) is still around surgery**

- We do know that, the more extensive the resection, the longer the survival is and that’s been really well characterized now but it’s not curative
- We can remove 99% or even 100% and beyond what we see on the MRI
- Unfortunately, there’s usually microscopic cells that go beyond what we can see on the MRI that are still there and, over time, they will repopulate the tumor
- It is a really complicated and tough disease but we’re working really hard on it

**Do we have any idea what predisposes an individual to this from a risk perspective?**

- The short answer is no
- It affects young, it affects old
  - Peter has watched children die of this, teenagers, people in midlife, people at the end of life, it seems to have no apparent pattern
- Part of that has to do with its mechanisms
- It’s not something that we consider as a heritable risk, but what it does rely on is a set of mutations and it’s rarely the same set
  - It’s a very polygenic condition, and that’s what makes it tricky to treat
- When we talk about glioblastoma, we’re actually not talking about one thing, we’re talking about a system of genetic alterations that, together, have cascaded into the form that we see

**The future of treating brain cancer**

- Edward alluded to chemotherapeutic agents that can be used whether it’s to treat glioblastoma or anything else including metastasis of other epithelial cancers that spread to the brain
- The [blood-brain barrier](https://en.wikipedia.org/wiki/Blood%E2%80%93brain_barrier) poses a challenge for treatment

*Do you think the future lies in treatment within the CSF (treating directly inside intrathecally or directly into the central nervous system), or do you think it’s designing drugs that cross the blood-brain barrier?*

- Edward thinks it’s going to look like all of the above
- This is a situation where we do need to look at all possible options
  - This is not the kind of thing where we’re thinking non-invasive or minimally invasive
  - Really, something that will work as the first priority
- One of the technologies Edward is really interested in following is how this develops and he’s doing research on this at UCSF using [focus ultrasound](https://en.wikipedia.org/wiki/Focused_ultrasound)

**⇒** Most people know about ultrasound to diagnose but, if you change the energy profile of it, you can actually use acoustic energy through an ultrasound to actually open up the blood-brain barrier and targeted parts of the brain

- There is a lot of development on using that as a way to do delivery as opposed to putting a catheter or something directly in the brain
- And then with that set of new agents that can be really molecularly specific to get to targets once you open up that blood-brain barrier

## How brain mapping has advanced from preserving function during surgery to revealing how neurons encode language and cognition [A: 16:30, V: 17:39]

**What attracted you to neurosurgery?**

*Was it something you knew you wanted to do when you went to medical school or did you figure it out while there?*

- Edward was always really interested in neuroscience, but it wasn’t until he was in medical school that he was actually exposed to it
- He remembers clearly, in his first year, he had this neuroanatomy professor ([Diane Rolson](https://synapse.library.ucsf.edu/?a=d&d=ucsf20000518-01.2.6&e=-------en--20--1--txt-txIN--------)) who was an incredibly kind person who was patient with Edward as he was learning
  - You probably remember in med school learning hundreds of different parts of the brain anatomy ‒ that’s part of our ritual in medical school to learn all of those terms and locations
  - Certain teachers just make such a huge difference
  - She took him to the operating room one day and [Dr. Berger](https://braintumorcenter.ucsf.edu/people/mitchel-berger) (who would ultimately become his mentor) was doing awake surgery on a patient with a glioblastoma
- The surgery itself was pretty interesting but the part that left Edward awestruck and the part that basically made it very hard for him to sleep for a couple days was really just seeing an exposed brain, what the cortex looks like
  - The [cortex](https://en.wikipedia.org/wiki/Cerebral_cortex) is the outermost part of the brain, it pulsates, it moves but those are not from the mechanics of the brain itself, those are all just from the breathing and the heart rate, etc., as the blood flow is coming through
  - [the anatomy of the cerebral cortex is shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/09/f2-edwardchang-1024x611.png)

**Figure 2. Anatomy of the cerebral cortex**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Cerebral_cortex)

- The thing that really struck off for Edward was seeing a patient talking, and not fully comprehending but really being in awe of the computations that must be happening in this part of the brain
  - It’s not like you’re looking at a computer, you’re looking at an organ composed of biological cells (86 billion neurons in the human brain)
- That scene, to him, was deeply inspiring and he was basically hooked

Edward shares, “*I was so hooked that I didn’t really understand what I was signing up for because the training for it after that was pretty difficult, I have to say, seven years but it was worth it.*”

- He loved every minute of it and he’s still learning

> “*We’re at the very beginning of a new inflection point in neurosurgery which is understanding how the human brain works.*”‒ Edward Chang

**There was an epiphany you had at some point in residency, wasn’t there?**

- We have really privileged access to use the information on what we call **“brain mapping”**
- We do the brain mapping because we want to be very precise about how we’re approaching, for example, a brain tumor or a spot of the brain that’s causing seizures
- And we do the brain mapping so that we can map out the areas that are really important for language or the ability to move your arm
- We want to identify those areas so we can protect them during the surgery, and at the same time, do the maximal resection like he spoke about earlier
  - The more that we can remove the tumor, the longer the survival
  - The more that we can remove of the seizure zone, the more likely someone is going to be cured of their epilepsy
- In neurosurgery, there can always be a cost and that cost would be paralysis or aphasia (which is a condition where you lose the ability to speak)
  - We’re always trying to balance: is it worth it to go that extra couple of millimeters versus not

***In many cases, these are really profoundly important decisions that have to be made right then and there in the operating room and brain mapping is a way that we figure this out***

- In the old days, [Wilder Penfield](https://en.wikipedia.org/wiki/Wilder_Penfield), 120 years ago, would use an electrical stimulator and would apply it to the cortex and that will temporarily activate or disrupt the function of a specific part of the brain while someone is trying to speak or move and that’s traditionally how we’ve done mapping
- And that’s one of the tools, the techniques we still use today in order to make sure our patients are safe during these procedures

***One of the revelations Edward had during residency is that we can do a lot more than just applying stimulators to do the mapping***

- We’ve developed technologies to record from the brain that allows us to, not only do the mapping, but also is really the first window that we have of understanding essentially how neurons work
  - How neurons convey information about words, for example
- In the conversation we’re having, there’s a part of your brain in the [temporal lobe](https://en.wikipedia.org/wiki/Temporal_lobe) which is right above your ear on both sides
  - The one on the left in particular (you’re right-handed) ‒ 99% of right-handers are dominant for language on the left side and there’s this one spot in the temporal lobe which is just about two centimeters above your left ear that’s processing all the words that I’m speaking to you right now
- We’ve used this technology, not only to map those critical functions
  - That’s where the science was about 10 or 15 years ago, figuring out where these functions are in the brain
- Now we’ve moved the science to understanding how those areas work by a progressive evolution of new technologies to get us to higher and higher resolution

**⇒** We can measure the neural activity of cells and cell populations and then link them to, for example, different consonants and vowels and that’s been really an extremely exciting development in human neuroscience

## How awake brain surgery is performed [A: 22:00, V: 24:22]

- The traditional way that surgery is done requires general anesthesia, and general anesthesia typically requires 3 things
  - It requires one type of medication to blunt pain, another type of medication to block memory, and another type of medication to paralyze you
- If things go wrong (and things have gone wrong), sometimes patients are paralyzed but they feel pain but they can’t communicate it
  - These are catastrophic but, fortunately, very rare events that occur in anesthesia
- Correct anesthesia is done where a patient has no sense of time or memory of anything, they can’t feel anything, and they can’t move which means they’re actually safe (that’s to save them as well)

**Help us understand how it is that you can do surgery without all three of those conditions being present**

- This is an extreme form of medicine, an extreme form of surgery

***In a nutshell, it can be done because the brain itself doesn’t have any pain receptors***

- The pain receptors are the ones that are in our nerves that are in the scalp, that are throughout our body, these are actually the way that we perceive pain and touch
- It’s paradoxical to many people at first, but the brain itself which is processing that information in the body actually doesn’t have those receptors itself

***The way that we typically do this is to numb the scalp***

- We use things (like when you go to the dentist office) like [lidocaine](https://en.wikipedia.org/wiki/Lidocaine), we can inject around the site of the incision
- The bone, by the way, doesn’t have any pain receptors itself either
- The membrane on top of the brain (that we call the [dura](https://en.wikipedia.org/wiki/Dura_mater)) does have some pain receptors; so sometimes we have to be sensitive around that and do some local anesthesia around the dura

***There are some other areas like around the blood vessels that can be sensitive, but they can be numbed ‒ this allows us to do these surgeries awake***

**More details about neurosurgery on awake patients**

- The patient is rolled into the OR, they’re not intubated (no endotracheal tube)
- A [Foley catheter](https://en.wikipedia.org/wiki/Foley_catheter) is used for some comfort, but primarily so that we can monitor the urine output during the surgery
- You begin by drawing where you want to make your incision
- The head is fixed so it’s not like someone’s sitting in a chair and moving around
- The patient is somewhat sedated (a light level), and then you can lift the sedation
  - Like [propofol](https://en.wikipedia.org/wiki/Propofol), but a much, much lower dose
  - It’s okay for them to be in “la la land,” but we want the sedation off once we have to get inside
- The period that someone is actually awake during the surgery is usually only 1-2 hours, even if the surgery is 6 or 8 hours long

***Primarily for comfort, we’ll do sedation at the very beginning, we’ll have the sedation turned off so the patient can be fully awake for the brain mapping***

- Then you can ramp up the sedation to finish the procedure and close them

**⇒** It’s all done at the level of a colonoscopy, not the level of general anesthesia

## How brain redundancy and plasticity allow some regions to be safely resected, the role of the corpus callosum in epilepsy surgery, and the clinical and philosophical implications of disconnecting the hemispheres [A: 26:15, V: 29:02]

**One of the things that blew Peter’s mind**:

- Edward and Peter were talking before the podcast about how in Peter’s second month of general surgery, he rotated through neurosurgery
- When you look at textbooks and you study the homunculus and you look at all of the vasculature and then you actually look at the brain, it’s just like any other organ
- It’s like looking at the pancreas for the first time, you’re like, “*That’s it? How do I know where everything is?*”
- What makes the brain different is there’s probably no part of the body where the real estate matters so much
- When you’re operating on other parts of the body, for example, if you’re operating on the heart, you can really see what you’re doing
  - You know where the left anterior descending artery is, you know where the occlusion is
  - And even though it’s a very technically complicated surgery, there is complete anatomic clarity of what is happening
- The thing that struck Peter the most the first time he saw neurosurgery was, “*How the hell do they know what they’re doing? How many billion cells did we just lop off there?*”
- And obviously, this speaks to what you’re talking about from a functional standpoint but, a lot of times, you’re not doing that

**If a patient has a** [**meningioma**](https://en.wikipedia.org/wiki/Meningioma) **or some other tumor, how do you bracket that trade-off?**

- Do you say, “*Look, there are places where you never want to have a tumor.*”
  - For example, right above my left ear, that would be a really difficult place to have to resect because the real estate is so precious and that’s where we’re going to probably recommend doing an open awake procedure to help guide us
- That’s exactly right ‒ to say the real estate is critical is an understatement
- But that being said, there are some really expensive real estate in there and there’s also some cheaper real estate
  - Peter compares it to Manhattan: there’s no cheap real estate in Manhattan (some areas are $10,000 a square foot, but there’s probably nothing less than $4,000 a square foot)

**There’s this popular idea that we only need 10% of our brain**

- Peter doesn’t know what it means; it sounds like malarky to him (Edward agrees)

**⇒** What it really means is that there is maybe about 10 or 15% that is very critical for our basic functions

- Our ability to move, to talk, to see, etc.; it’s actually a lot more than that

***It’s also referring to this point that there are parts of our brain that are extremely redundant with other parts of the brain***

- So, the [frontal lobes](https://en.wikipedia.org/wiki/Frontal_lobe), for example, we do surgeries there routinely and oftentimes people really have no effect
  - Even in terms of judgement, because we always think of the frontal lobe as where we have executive function
  - Peter joked that one of his friends in med school had no frontal lobe because he couldn’t stop saying the most inappropriate things
- The frontal lobe actually has a lot of critical function for executive decision, impulse control, etc., but Edward’s point is that it’s redundant
  - Meaning that different parts of the frontal lobe actually have similar purposes and a similar role

***For the most part, a lot of our patients can accommodate a fairly large surgery, sometimes even removing the entire frontal lobe***

Peter asks, “*On both sides?*”

- No, not both sides
- Usually these pathologies are only on one side

**If you took the entire frontal lobe from the left or right side, would there be a substantial difference?**

- Edward has done that many times, and it really depends on the case and scenario
- If someone’s been having something that’s slower growing there and there’s been time for the brain to reorganize (what we call plasticity), a lot of those functions will essentially no longer be in that right frontal lobe and they’ve moved to the left side

Peter asks, “*What is the mechanism by which that happens?*”

- Time and function meaning these things don’t happen overnight, they take sometimes weeks and years
- Basically what happens is some neurons get lost over time and then others will compensate in terms of that function

**Let’s posit that we have a slow growing lesion in the left frontal lobe**

*What is the left frontal lobe doing to communicate with the right frontal lobe to say, “Hey, these neurons are being compromised, their function is deteriorating. You guys need to pick up the slack.”*

*How is that message being transmitted?*

- Part of it is that both parts of the frontal lobe for most people are both doing the function most of the time
- So it’s not like it’s just transferring the information
- It’s that both sides were originally involved in those functions and then one side gets weaker and the other one has to pick up that slack

***At a cellular level, this is what we call*** [***synaptic plasticity***](https://en.wikipedia.org/wiki/Synaptic_plasticity)

- The weights essentially make up who we are
- These are just the weights that neurons use to communicate with one another

**⇒** All of our learning is towards shaping that weighting of synapses that occur where neurons touch each other

- And that can happen, that can change throughout our life
- Every time we learn a new word, those are new synapses that have formed that were never there, new connections

Precisely from the left to the right side, there is this structure that we call the [corpus callosum](https://en.wikipedia.org/wiki/Corpus_callosum) [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/09/f3-edwardchang.png)

**Figure 3. Anatomical location of the corpus callosum**. Image credit: [NeuroscienceNews.com](http://neurosciencenews.com)

**⇒** The corpus callosum is an information highway that connects the left part of our brain from the right side

- There was a [Nobel Prize](https://www.nobelprize.org/prizes/medicine/1981/summary/), [Roger Sperry](https://en.wikipedia.org/wiki/Roger_Wolcott_Sperry) did really incredible early experiments describing patients who had surgeries where you split that and in certain instances you have this phenomena where people essentially have two functioning brains, but they’re not communicating to each other

***It does require that there is this connection between the two areas where they’re being reorganized***

**Outside of epilepsy, why else would the corpus be severed?**

- That’s really the main one that we use it for

*Can you describe how patients that undergo that procedure behave?*

There’s a phenomenon that we call a **dissociation syndrome**

- The clinical indication, the medical indication for why someone would undergo this nowadays is that some patients with seizures have severe seizures where they fall down, what we call drop attacks
  - Usually what that means is that the seizure is spreading so quickly across the brain that people lose the tone in the body and then basically fall
  - And why that becomes a problem, the injury of the seizures, is that people actually injure themselves
  - It’s not uncommon for people who have these kinds of seizures to actually to be wearing helmets all the time because they’re at such high risk of falling
- These are just medically recalcitrant seizures, they cannot be prevented

**⇒** There’s not one small spot that’s causing the seizure, it’s the whole half or quadrant of the brain

- **What a seizure is**: basically when you have this very uncontrolled synchrony of a large mass of the brain cells

Analogy to understand how the brain normally works and what changes with this syndrome

- Normally, if you think about the brain and the neurons within the brain, it’s like people in a stadium, they’re having their individual conversations
  - That’s the way the brain normally works
- But let’s say all of a sudden everyone’s doing a wave and something hyper coordinated, all of those normal conversations are now gone
  - The brain has now become hijacked by this other phenomena where everything has become very coordinated
  - That’s why people lose consciousness because all the normal function is basically shut down

***The way the brain can become synchronized is through its connectivity***

- Every cell connecting to its adjacent cell and every cell connected to all the other cells in the brain through the things like the corpus callosum that connects the left to the right

**⇒** When you get that hyper synchrony, people can essentially lose consciousness almost instantaneously

- One of the reasons historically why the corpus callosotomy was invented in the very first place was to **sever the connection between the left and right hemisphere** ‒ which doesn’t stop the seizure, it just limits the spread
- It doesn’t stop the seizure, but what it does is stops the very fast propagation of the seizure from one side to the other
- In order for someone to lose consciousness, you basically have to have both sides of the hemisphere or a deeper structure like the thalamus “out”
- So these kind of drop attack seizures are ones that people black out, fall

***One way you can actually dramatically stop a lot of these drop seizures is disconnecting the left from the right hemisphere***

**For that patient, how is their life different aside from the fact that hopefully their drop seizures are gone?**

*What’s the change in the way that their left and right behave now disconnected?*

- Most of the time when we do this nowadays, we disconnect about the anterior 2/3 of the corpus callosum
- And the reason why we don’t typically transect the whole corpus callosum is because of some of the side effects that people can have and it’s what we call a **dissociation syndrome**, where you can basically have a dissociation between what the left brain is doing in the right brain
- For example, someone essentially feeling something on the right hand, which is processed by the left part of the brain, and the right part of the brain really having no awareness of what’s going on
- People can get by with that, but it does affect how they can get along

**⇒** So nowadays, we try to just do the front part of it and leave the back part, that helps reduce some of those side effects

- It doesn’t cure the seizures, but it really just stops the propagation of the seizures so that people don’t lose consciousness
  - Leaving ⅓ in the posterior section of the corpus callosum connected prevents propagation of the seizures across the hemispheres (in many cases)
- In some cases, nowadays still, we have to do a total [callosotomy](https://en.wikipedia.org/wiki/Corpus_callosotomy)
  - It’s a very delicate surgery because the corpus callosum that connects the left and the right, it’s not sitting on the top of the brain. It’s actually very deep within the brain
- To get there, you actually have to physically separate the left and right hemisphere
  - We do that from the top
  - We do a craniotomy that’s centered over the midline
  - But it can’t be right over the midline because we have a large draining vein there called the [superior sagittal sinus](https://en.wikipedia.org/wiki/Superior_sagittal_sinus)
  - So we have to either choose the left side or the right side, and then we have to very carefully separate the left from the right and through that narrow corridor transect those connections

Peter asks, “*What’s directly underneath it that prevents you from running that* [*bovie*](https://en.wikipedia.org/wiki/Electrosurgery) *a little too hot?*”

- There is a blood vessel that runs along the top of the corpus callosum, and that’s actually the most critical part of the surgery is that we separate those two branches, those [pericallosal arteries](https://en.wikipedia.org/wiki/Anterior_cerebral_artery#:~:text=bifurcation%20forming%20the-,pericallosal,-and%20callosomarginal%20arteries)
- Those arteries are really important because they supply the part of the brain, the medial frontal cortex
- And the part of that that is part of the [motor cortex](https://en.wikipedia.org/wiki/Motor_cortex) actually is what supplies and controls our legs
- So if you have a stroke, let’s say, as a side effect or complication of that procedure, then someone would be paralyzed in the leg

Edward shares, “*It’s a fun, delicate surgery. It’s amazing to see that exposure of the corpus callosum. It’s glistening white. That’s how we can see it. And it’s very distinct from the cortex because it’s really clear white.*”

- That white comes from the [myelin](https://en.wikipedia.org/wiki/Myelin)

**⇒** The corpus callosum is a heavily, heavily myelinated structure because it’s conveying information from the left side of our brain to the right side on the order of milliseconds, a super-fast connection

**Do you ever think philosophically about what the implications are for human consciousness by the fact that you can do a complete transection of the corpus and seemingly produce two people?**

- That’s right
- Or potentially two consciousnesses
- That goes back to a harder question of how do you define what consciousness is in the first place?
- There’s a lot of philosophical debate about that

Peter asks, “*Do you trouble yourself with such debates?*”

- Not really
- Edward does think about it from the practical clinical perspective, not so much the philosophical
  - Is a patient in a coma or not? And why?
  - And how do we get them out of that?
  - Traumatic brain injury, certain strokes, epilepsy, etc.
  - We think about consciousness from that perspective literally all the time every day

## How neural engineering may restore lost functions in neurodegenerative disease, how thought mapping varies across individuals, and how sensory decline contributes to cognitive aging [A: 39:15, V: 43:46]

- Peter points out that medicine to date has been pretty unimpressive when it comes to treating neurodegenerative disease
  - Whether we’re talking about Alzheimer’s disease or even other non-degenerative forms of dementia
  - Whether we’re talking about Parkinson’s disease, Lou Gehrig’s disease
- We just don’t seem to be able to treat these diseases; whatever medications we throw at these things
  - Maybe in the case of Parkinson’s disease, we can delay progression a little bit

**Would you agree with that assessment that the traditional approach to treating neurodegenerative diseases has been largely unsuccessful?**

- Edward would largely agree, with a caveat that a lot of progress is being made to understand what’s going on
- And from that, I think there’s a lot of promising therapies
- He would generally agree that within neurology and neurosurgery traditionally, therapy has really been designed to stop things from getting worse or slowing progression
- Replacing function has never really been possible until very recently

**Do we need to revisit our approach to these diseases more from an engineering perspective than from a peripherally administered medication perspective?**

- The traditional approach to treating disease would be medication
  - You take an injection, you take a pill, you take something, and you hope that enough of it gets across the blood-brain barrier and it starts to treat the condition at hand
- It’s hard to look at a patient with [Parkinson’s disease](https://en.wikipedia.org/wiki/Parkinson%27s_disease), which is a motor defect disease, admittedly that stems from the CNS, and not at least think this is a functional condition

*Why isn’t there (or is there) an engineering approach that could be taken to this?*

- It’s a good question
- Medications are always going to be a really important goal, not only to reduce symptoms, but hopefully find cures
- But there’s this whole other class of therapies that are coming online that have to do with this other property of brain cells, which is very different than, let’s say the pancreas or the liver
  - It’s the electrical side of the equation

***There’s the chemical and biological side, but then there’s this electrical side; and the brain is an electrical organ***

**⇒** Our thoughts are really dependent on these electrochemical kind of processes that happen at individual neurons and the collection of them

- There’s this large and growing field that we call **neural engineering** that is really trying to use computers, sensors, chips in order to interpret, eavesdrop on how the neurons are signaling to each other regardless of their pathology or the biology

The questions are:

- What are neurons saying to one another?
- Can we eavesdrop on that?
- Can we interpret it?
- Can we decode it?
- More importantly, can we use that information actually to guide more normal signaling?

> “*Why this is potentially important is that at the end of the day, the function is from that electrical activity.*”‒ Edward Chang

**⇒** It’s the propagation of those action potential by neurons, which gives rise to our thoughts, our ability to communicate, our ability to walk, move our arm

- Without that, it’s not there

***In Edward’s view, neuroengineering as a complement to the biological or pharmaceutical approaches***

**If all the electrical activity in Peter’s brain could be mapped to a computer, and the same could be done with Edward’s, and they are thinking the same thing**

*Would the outputs on the computer screen be similar?*

*Would the computer be able to appreciate similar electrical output?*

*Or could two people that are doing the best job they can to have the same thoughts, not be able to produce that?*

In other words, is there a one-to-one map of thought to electrical activity?

- The short answer is both
- In that example, if they are both looking at the same picture of a scene on the beach
  - Yes, the same part of our brain is going to be processing those images in the very back of the brain that we call the occipital lobe
  - The primary visual cortex is going to be parsing that space into what we call retinotopic space, essentially where those different pixels are located in the image
    - That part is going to be highly conserved, not identical, but highly conserved between your brain and mine
    - It’s where these computations go further upstream where they become much, much more differentiated, much more specific to our brain, much more dependent actually on our history, history of thoughts, our personality, everything that’s interacting with the rest of the brain

Another example: the way that you may hear Spanish or French or German can be very different than someone who is a native speaker of those languages

- Your brain is going to process some of those sounds
- You’ll hear them, but you’re not going to be able to pick out the words very easily
- Or the way Peter hears an engine versus the way his wife hears an engine
  - He loves the sound
  - She’s mildly annoyed by the sound
  - They’re hearing the same thing

***So there are parts that are going to be very similar (like how we process some of the sensory attributes), and then the further you go deep into the system, the more it becomes very, very tailored***

- Some of this is hardwired
- For our visual system: early on, a lot of it is hardwiring, it’s heavily influenced by what we see

Peter asks, “*Seeing a snake should automatically produce a negative response that doesn’t have to be learned, in theory, I assume. Evolution has probably hardwired us for that*.”

- Yeah, correct ‒ there are some things that are instinctual
- Certain odors, we’d be hardwired not to like things that are going to smell rotten or something like that

**Going back to the we’re showing you the picture of the beach, how much do you change over time?**

*If we did that experiment when you were 10, 20, 30, 40, 50, would that also change?*

- It will change, but less
- Over time these things become refined and over time actually lose their refinement

**⇒** As we age, some of those representations actually become less clear

- If we talk about **hearing**, for example, there are a lot of people in the population for whom over time, it’s very hard for them to be in a crowded restaurant where there’s a lot of background noise, competing conversations going on, and yet these individuals can have perfect hearing

***Signal processing is becoming the problem***

- It’s not an ear problem per se
- It’s a perceptual problem and largely in the brain, and that has to do with the fidelity of the cells [how it processes information]

Peter asks, “*Is that a harbinger of something bad?*”

- Independently, no
- But we do know that when people have that problem, they tend to be more **socially isolated**
- There’s a lot of secondary things that happen
- We do know that a lot of people have **unrecognized hearing loss**

**⇒** What people don’t fully appreciate is that if you don’t have access to communication, to conversation, your brain is not getting those same signals; it’s becoming deprived

***What we do know through many studies now is that the cognitive effects of that hearing loss actually can be quite profound: it accelerates age-related memory loss***

Internally in Peter’s practice, they believe that this is causal to cognitive decline

- A [study](https://pubmed.ncbi.nlm.nih.gov/37478886/) came out about 2 years ago that suggested it wasn’t
  - Although the study had a partial retraction, the methodology was a little flawed
  - Peter doesn’t know if it’s been repeated

**The question being:** if you correct hearing loss, do you correct or prevent or reverse it [cognitive decline]?  (Let’s say you randomize a group of people with early MCI and you correct hearing loss)

- Again, if there’s causality there, you would expect that you would

**What about visual input?**

- As people get older and they develop cataracts or things of that nature and their visual acuity goes down

*Does it have the same effect on depriving them of enough neural stimulation to maintain? Or is it not as much because it’s not a language issue?*

- It’s not as much, and Edward is less aware in the prevalence of something that’s age-related just in the visual cortex (for example)

## Brain–computer interfaces explained: EEG vs. ECoG vs. single-cell electrodes and their trade-offs [A: 48:30, V: 54:40]

**Back to the brain-computer interface. How would you explain this to somebody at a party?**

First, let’s break apart the terms

- Brain refers to really any kind of thing that interfaces with the cortex or the deeper structures
- The computer is a digital device on the outside
- A lot of people now call this [***BCI (brain-computer interface)***](https://en.wikipedia.org/wiki/Brain%E2%80%93computer_interface)for short
  - It’s a very messy term because it could mean a lot of different things

***In a nutshell, what it means for most people is a system that is recording from the brain (whether it’s non-invasive from the scalp or something that’s fully invasive within the brain itself) and connecting those signals to a computer that analyzes the signal and then does something with it***

- In many cases of BCI research, the application is, for example, replace speech words for someone who’s severely paralyzed and unable to talk anymore

***It’s about interpreting brain signals and then using a computer to interpret those signals and then transform them into a form that’s useful to us***

**A patient with aphasia who can’t speak**

- A lot of the work that we’ve done is on people that have a severe form of paralysis
- [Aphasia](https://en.wikipedia.org/wiki/Aphasia), we typically refer to as someone who’s got, let’s say, a stroke in the language centers of the brain
- Where we focus recently is on patients that have a severe form of paralysis like [ALS](https://en.wikipedia.org/wiki/ALS)
  - There the problem is they have largely normal language, but they can’t get the motor signal out to the vocal tract, the lips, the tongue, the jaw, the larynx
  - Those descending fibers are severely affected by ALS, they degenerate; and that’s why people progressively become paralyzed and lose ability to speak

*An important part of ALS is that they lose ability to speak, but they still have full cognition*

- For that individual, by attaching a computer to their brain, you’re able to hopefully extract in written cursive text across the computer screen, what they’re wishing to say

**2 ways to extract what a person wishes to say**

- 1 – A non-invasive way where presumably you’re putting electrodes all over a head (that’s as well-shorn as Peter’s)
  - An [EEG](https://en.wikipedia.org/wiki/Electroencephalography) is where sensors are placed on the scalp directly, recording non-invasively
  - You can remove them at any time
- 2 – A very invasive way where you actually remove the scalp and you lay these things on the cortex itself
  - Electrodes that are actually placed into the brain, the most invasive approach
  - [ECoG](https://en.wikipedia.org/wiki/Electrocorticography) would be electrodes that are on the brain surface

**ECoG is short for Electrocorticography**

- That’s where Edward has done the vast majority of his research
- That’s just placed on the surface of the cortex, under the [dura](https://en.wikipedia.org/wiki/Dura_mater)
- What’s nice about that is that you don’t have the injury to the brain itself from the insertion of the electrodes
- It’s a stable recording over time

**⇒** We now use ECoG devices to help people with seizures, for example, where you can basically have a pacemaker now that records from the brain surface and then stimulates to help stop the seizures

Peter asks, “*Is this a fully implanted device?*”

- It’s moving towards that
- The work Edward has done in a [clinical trial](https://pubmed.ncbi.nlm.nih.gov/34260835/) is using an array that’s surgically placed but connected through a port
  - We call it a **percutaneous port** because it’s actually physically attached and anchored to the skull, an array on the brain, it comes out the dura and is anchored in the skull
  - The port exits the body right on the top of the scalp, and that’s the main problem with this early prototype (BCI)
- There’s other groups around the world that are using similar things, primarily to show if it’s possible to code brain activity for useful purposes

**What’s happening right now in the field is a lot of these technologies are now going to become wireless over time**

- One of the main reasons is that we want to move away from the percutaneous
  - We want to move away from the ports which are infection risks, on top of other problems
  - Move to things that are fully implantable, fully wireless

Peter asks, “*How long do you feel you’re away from that?*”

- About a year
- Edward’s lab has been working on it for quite some time
- It’s it’s a really interesting time where we’re seeing a convergence of what’s possible with electrical engineering and high bandwidth wireless (it’s way beyond what we can do with Bluetooth)
- Advanced electronics that now allow us to print some of these sensors on a substrate that is thinner than a piece of paper
  - Really, really small and on a substrate that can conform to the convolutions, the different peaks and valleys of the human cortical surface

**What is the trade-off between ECoG and sensors inserted directly in the brain? What’s the resolution difference?**

- That’s a very important question that we and many other people are trying to figure out right now
- Most of the time when people are putting an electrode into the brain, there has to be some gain for that
  - And usually that’s for recording a higher resolution
  - Usually trying to record the activity of single neurons (a single cell)

Peter asks, “*How can you isolate a single cell?*”

- Super small electrodes
- We do a lot of work with this in our research

**The challenge for the field**

- 1 – It’s very hard to stably record from single cells more than a couple of hours or days
- 2 – When you put the electrodes into the brain, it can create a reaction
- Those glial cells that we talked about at the very beginning (those support cells), they actually have immune function as well
  - They detect that there is a foreign body and they’ll activate and they’ll react to it
  - They create a scar around the electrodes
- The **advantage** of having electrodes in the brain to do this very microscopic kind of recording is that you can get a finer signal from single cells
- The **disadvantage** is that it can create a reaction that reduces the fidelity of those signals over time
- One of the reasons Edward has been most interested in using these sensors on the brain cortex is we’ve learned over time that if you don’t have the electrodes penetrating through the peel surface of the cortex (that’s the outermost, very thin membrane that’s covering the cortex)
  - You can avoid a lot of those immune reactions
  - Avoid a lot of that scarring
  - Preserve the function that’s underlying
  - This is something that we’re actively trying to understand

**Just to give me a sense of magnitude, if EEG on the surface is one, one unit of resolution, what would ECoG be?**

*And what would the implanted electrode be? Is it 1, 10, 100? What’s the scale at which you’re thinking of that resolution?*

- From the scalp, let’s arbitrarily call that 1.0
- Then you think about what you could do with this ECoG ‒ let’s say 1,000x better resolution

> “*We’ve been able to answer very fundamental questions about how the brain works using those kind of surface recordings in a way that’s impossible with surface scalp electrodes*.”‒ Edward Chang

- Then once you go take that further to single neurons and you’ve got another resolution, probably 6,000-5,000x

Peter asks, “*The big jump is just going from an EEG to an ECoG?*”

- Directly to the brain
- That’s a 3 log change, whereas you’re a 5x change going deeper
- One of the reasons for that is the skull and the scalp are a major loss of signal
  - The signals are small to begin with, so once you’re trying to interpret them through the skull or scalp, they’re basically gone and very diffuse too
- So trying to understand where they came from in any precise way, it’s almost impossible

***When you’re recording directly on the surface, you’re basically at the source itself***

- The single-cell recordings are terrific for trying to understand that ultra-fine resolution
  - Primarily in the case that we use them for is research to understand what’s happening at those units
- But still to this day, there’s really no way that you can chronically and stably record from the same cells
  - Because of the immune reaction
  - Also because of how fine of a problem it is, how precise it has to be
  - We’re talking about a single cell, a couple of microns in diameter, and you’ve got an electrode
  - Any micro-motion at all, anything changes that
- Typically, what we see with a lot of those systems that record from those is there’s a lot of turnover from day to day or hour to hour
  - Meaning you’re drifting between which neuron you’re recording in

**Neighboring neurons are not identical**

- Earlier, Edward said that there are 82 billion neurons in our brain
- You put a probe into one and it moves over to the next one and the next one, etc.
- Someone like Peter would naively assume they’re all the same
  - Those are like three row homes that are all basically identical on the Upper West Side

*Does it really matter if the probe moves between those three neurons?*

- The answer is yes
- Because we now know that cells that are right next to each other can have some very different information
- Now that being said, when you go through a column of the cortex, the column is this vertical organization
- Typically what we’re thinking about when we look at is the two dimension of the surface, but there’s a third dimension of information processing, which is the different layers of the cortex (we call the lamina), and typically in some of the sensory areas for example, if you put an electrode, it’s primarily going to be tuned to the same information across those different neurons across that depth
- So in certain areas Peter is correct, you may have neurons that are tuned to the exact identical thing
  - And for decoding purposes, that may actually not be a big deal to have the probe not be very stationary over time
- In other instances, where you’re trying to code from areas where it’s a lot more intermixed, it could have really profound implications where you have to recalibrate the algorithms that the machine is doing to interpret the signals every couple of hours or days

**When you do ECoG, how do you direct the sensor at the part of the brain you want to go to?**

- Peter assumes it’s far more nuanced than just where you slap it on the cortex
- Edward loves that this conversation is getting into the details

**⇒** This alludes to one of the things we were talking about earlier, the part of my brain and the part of your brain that is responsible for speaking, especially in the motor control part, it’s largely the same

- It’s in the same ballpark
- There’s a lot of variation when we come down to the details, the micro geography, but it’s in the same, largely in the same city
- If we’re talking about geography, where your house is first, versus my house, etc. ‒  that’s going to be a little bit varied within that

***One of the nice features about using ECoG is that you can put an array over that entire area safely and you can sample very, very densely across the entire city; and so it doesn’t really matter at the end of the day, if one person’s there and the others [are somewhere else], basically you’re going to cover it***

Peter’s takeaway, “*that seems to actually be a feature, not a bug, right?*”

- Absolutely
- Analogy: the bug is, you give up the resolution at what’s happening in the kitchen of that house, but you now get to look at all the houses
  - And you get to do it in a way that’s very safe and scalable
  - You give up roughly 80% of the resolution

## Edward’s clinical trial using ECoG to restore speech to a stroke patient [A: 1:01:00, V: 1:09:02]

**With ECoG, how many words per minute could you capture from a patient with ALS?**

- In Edward’s [clinical trial](https://pubmed.ncbi.nlm.nih.gov/37612505/) at UCSF, he worked with a participant named Anne
  - [78 words per minute with a median word error rate of 25% was achieved in this 2023 publication]
- She had a very severe brainstem stroke about 20 years ago when she was in her 20s
  - It wasn’t long after she had gotten married, after her second daughter was born, she was playing volleyball with her friends when she collapsed and was taken to the hospital
- It was a [vertebral artery dissection](https://en.wikipedia.org/wiki/Vertebral_artery_dissection) (such a scary thing)
  - Everyone’s heard of the [carotid arteries](https://en.wikipedia.org/wiki/Common_carotid_artery), they come up through our neck, and they primarily give the blood flow to the front part of the brain
  - The vertebral artery is an equally, if not more important set of arteries that supply the brain stem, which connects the brain to the spinal cord in the back of the brain

**⇒** We have these two pairs of really important blood vessels that come to our brain, the carotid and then the vertebral arteries [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/09/f4-edwardchang.png)

**Figure 4. Anatomical location of the carotid and vertebral arteries**. Image credit: [University Hospitals](https://www.uhhospitals.org/services/heart-and-vascular-services/conditions-and-treatments/vascular-disease/conditions-and-treatments/cervical-artery-dissection)

- Anne had an injury while she was playing, and it was really just unfortunate, but she had this stroke in the vertebral artery that blocked the blood supply to the brain stem

Peter asks, “*Does it have to be bilateral to cause the injury? Or if it happens on one side, can the other side not profuse around the circle of Willis? Why does that injury happen?*”

- Unlike the carotid artery, the vertebral arteries, you have a left and right vertebral artery ‒ they come up through your neck and then they go through the base of the skull through the foramen and magnum, essentially where the spinal cord is coming through the base of the skull
- When they enter the skull, they become one artery ‒ it’s called the [basilar artery](https://en.wikipedia.org/wiki/Basilar_artery)
- The basilar artery and the small perforating arteries that come off that supply the brain stem are absolutely critical
- So it all depends on where the dissection occurs
  - If it occurs before the bifurcation, you’re probably fine
  - If it occurs above the bifurcation or where they join, it’s not the bifurcation, but yes
- Sometimes, for various reasons, we actually have to occlude a vertebral artery, and then the other one just gives the collateral flow
- The basilar artery, however, doesn’t have that kind of insurance policy
  - It’s “mission critical”
  - It’s is such a critical structure, and when there’s a problem there, it’s usually terminal
- Anne survived this stroke, but she was left quadriplegic (meaning she couldn’t move her arms and legs)
- In addition to that, she couldn’t speak because the nerves that come through the brain, down through the brain stem and go to the cranial nerves, which supply the vocal tract, those were also directly affected
  - Those would be the lower cranial nerves
  - In particular around the lower ones and those distributions that allow the control of the tongue
    - That’s a hypoglossal nerve, number 12
    - It’s number 10, the vagus
  - But it’s not precisely the nerves; it’s actually the brain stem nuclei (where the nerves originate)
- That’s not something one predicts from any type of stroke
- It’s simply the nature of what part of the brain stem was affected

Peter asks, “*Was the paralysis a result of her cerebellum also having infarcts?*”

- No; it was all brain stem related
  - In the part that we call the [pons](https://en.wikipedia.org/wiki/Pons) [shown in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/09/f5-edwardchang.png)

**Figure 5. Anatomical location of the pons in the brain stem**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Pons)

- It was devastating
- Anne is in her 40s now, and for 20 years she’s been in a wheelchair, unable to speak
- It was about 18 years after her stroke that she decided to participate in this trial [the [BRAVO trial](https://changlab.ucsf.edu/speech-neuroprosthesis)]
- Edward had talked to her a year earlier and she said, “*I really want to wait to participate in this trial because I want to wait until my daughter graduates and then I can do this with you guys*.”
  - Peter assumes she said that because the risk of something catastrophic happening was high enough that she felt she needed to wait
  - She’s a mom
- She reached out to Edward because he had an earlier participant who also had a brain stem stroke, and she read about the trial he did with her

*How did she communicate at that point in time?*

- The main way that she communicates is through devices that can track her eye movements
- Those are translated to a pointer that can point on a screen to individual letters or words
- It’s a very painstaking way of communicating

Edward shares, “*One thing I’ve learned about Anne is she’s just a tremendous person, positive person. She’s just a force of nature. She recently actually used that same system to write a book chapter. Just incredible*.”

- Edward started this trial called [The BRAVO trial](https://changlab.ucsf.edu/speech-neuroprosthesis)
- He worked with the FDA very closely to get approved because it requires a brain surgery, it requires this percutaneous port that he talked about earlier
- The reason we were able to get it approved in this form was that a lot of the components that we were using were actually existing medical materials
- So the safety of it was largely already known in terms of its biocompatibility, its biostability

> “*What was not known is that if someone has not spoken for a decade or two, whether or not those parts of the print actually would still work*.”‒ Edward Chang

- Peter finds this really interesting because we know that if a person loses their sight for X number of years…
- He’s guessing that the occipital lobe doesn’t work the same way
  - It’s not processing the information
  - He doesn’t know that it actually physically atrophies
  - But the neurons aren’t firing the same way

Peter reacts, “*What would be interesting is we just don’t know if Anne’s inner monologue is still happening the same way.*”

- Edward agrees that ultimately that was the biggest risk
- There’s a lot of emphasis on the technology, but the basic biology of how the brain works and whether that information is still being processed, are really the more important questions

**Edward did a surgery where he implanted an array of 253 ECoG sensors in Anne**

- These are the sensors that are densely spaced.
- We’re talking about something about the surface area of a credit card, and it’s filled with electrode sensors that are spaced about three millimeters apart
- Each sensor is about a millimeter in diameter
- Basically you’ve got this credit card sized array that was placed on the part of her brain that processes words
  - In particular, the motor production of the words, the parts that control the lips, the jaw, the larynx, the tongue
  - Areas that were functionally disconnected from her vocal tract because of this stroke in the brain stem, which connects the brain to those muscles
- 3 weeks after the surgery, we started our research sessions with her
- We connected the cable
  - It’s basically an HDMI cable that is attached to a head stage
- The head stage transforms the analog signals from her brain
- These are a small voltage recordings

Peter asks, “*Can you explain why the brain is analog and why you have to convert that to digital?*”

- To some degree, there is a level that is digital
  - Single neurons, action potentials firing yes or no, like a digital form
- But when we’re recording a lot of these, especially at the ECoG, it’s an analog
- It’s looking at the average of these from a population of let’s say a couple thousand of those neurons activating
- The work that we’ve done actually over the last decade and a half, which led up to this, using methods like ECoG, we’ve learned from that there’s a map
  - What we all alluded to in the very beginning (the [homunculus](https://en.wikipedia.org/wiki/Homunculus)), but a mini-homunculus that is corresponding to those parts of the vocal tract, the larynx, the tongue, the jaw

**⇒** We figured out essentially how those signals correspond to every consonant and vowel in English about a decade ago

> “*The impetus for starting this clinical trial was that we essentially had identified what the neural code was like, what part of the brain and how that neural activity corresponds to all the movements that create syllables (for example.)*”‒ Edward Chang

## How a stroke patient regained speech through brain–computer interfaces: training, AI decoding, and the path to scalable technology [A: 1:10:45, V: 1:20:41]

**How big a data set was required to create that knowledge?**

- Data from about 36 participants just to get the basic idea

Peter asks, “*Is this something where if that were 36,000, it would be how much better?*”

- Near perfect (Edward will get to that later)

**How does this scale?**

*How do we use the information from other individuals to help “n of 1” for example?*

- In Anne’s particular case, we started from the beginning
- We actually didn’t use that data
- We knew that it was possible
  - We knew what the nature of that data and that code would look like
- At the same time that we’re doing all of this research ‒ AI is developing in parallel
- All of these tools that we now are using every day, transcribing our voice right now into text
  - We use that technology
  - We can use those same technologies that generate voices called speech synthesis
- We’ve used a lot of the same tools, machine learning tools that are in modern day AIs
- We’re now applying them on the brain activity and trying to use them to not translate, for example, text and synthesize speech
- But now the equation is different: it’s translating it from brain activity to synthesize speech
  - The input is not text
  - The input is the ECoG activity across these 253 sensors

**If you ignore the cost of compute, is there an advantage to doing it that way because you take out an intermediary step?**

- Yes
- It’s because we know that the ballpark is there, but we know that everyone’s brain at that level of detail, if you’re going to reconstruct their words, you can’t just be in the ballpark
  - You have to know basically what each leaf of grass on that ballpark is doing
  - And that’s highly variable across individuals

**What does the machine have to do? What is the training set for AI?**

- The way that we train the algorithm, the way that we started this was we would give Anne prompts on a screen in text, and we would ask her to try to say it
- She can move her lips a little bit, but she can’t speak
  - She has what we call [anarthria](https://en.wikipedia.org/wiki/Dysarthria)
  - She can vocalize a little bit, but none of it is intelligible in any form
- Peter wonders about her inner monologue
  - If you put up the word, “*The cow jumped over the fence*,” and she says, and in her mind the signal is, “*The cow jumped over the fence,*” then he totally sees how it works
  - At that point, you have infinite training data
  - You would basically just have her read *War and Peace*

Edward clarifies

- The area that we are decoding from is not the part of the brain that is processing either inner monologue or reading
- It really is this part that is about this volitional intent to speak
- So it’s not about her perception; it’s not the reading

If Peter is reading, “*The cow jumped over the fence,*” what part of his brain is internalizing this?

- Your visual cortex
- And then as it goes further, it’s going to some of the language areas
- But it’s not necessarily activating the lips, jaw, and the larynx, the areas that are paralyzed
- We’re tapping into a part of the brain that is really…

**This is a hard exercise; this takes a lot of effort on her part**

- For days, what we would do is have a sentence on a screen, and we’d give her the start time and the end time
- And during that, she would just look at the sentence, she’d give a go cue and then try to say it
- Nothing intelligible comes out
  - She may or may not be moving the lips, jaw
- But just trying to say, that turns out to be very important
  - You can’t just think about it; you can’t just read it
- We started with a very simple vocabulary of about 27 words
  - The words that we chose are the **NATO code words**: Alpha, Bravo, Charlie, Delta, Echo
  - We did that because we could measure the accuracy of the decoder that was analyzing those brain signals and translating them into those 26 different code words

***On the first day, we were able to train the algorithm on a data set of maybe about an hour and a half to get to about 50% accuracy***

Peter asks, “*Does 50% accuracy mean she could get half of them right? Or anytime you showed her one, there was a 50% chance it would be correct?*”

- Both
- What Peter just said is in a sense identical
- There was a bias towards a subset of them that she was always getting right and others that she was always getting wrong
  - Some of them were more discriminable than others
  - It was based on the number of syllables and some of the phonetic properties

**⇒** One of the reasons why NATO code words was a really useful training task for us is because NATO code words were developed in the first place by the military to improve communication accuracy

- The reason why we actually use those code words is because sometimes if you just say A, B, D, Z, there’s a lot of confusion
- That’s why we actually use those code words ‒  it increases the discriminability and intelligibility
  - Where in a lot of those settings, you just can’t make those errors
  - For example, pilots and the call numbers

***We used the NATO code words because it has high discriminability, and on that first day, we got about 50% accuracy***

- This is going straight to text
- Edward was just trying to figure out if he could decode which word it was

How the training with Anne progressed

- Over the next 6 days, the performance got better and better
- Then by about a week into this, she was up into the 95, 100% range (that was unexpected)

***It was incredible to see the performance increase so quickly, but that did take a full week***

**How would one develop the most efficient series of words for training?**

- Peter is sure that the NATO code is not designed for this purpose, but presumably one could concoct a series of words that contain within them the full range of tones, of phonetics, of syllable juxtapositions that would allow you to use the smallest possible training data to get the largest possible outcome
- This is a really important problem and more profound that you may realize

**⇒** What Peter is referring to is the generative property of speech and language

- What Edward means by generative is that you can take these individual elements like consonants and vowels (which by themselves have no meaning at all) and give rise to all possible meanings from just different combinations of them
- Just like DNA ‒ with DNA, we’ve got 4 base pairs essentially as a code for all of life
  - Except DNA is so much easier because it’s finite and the rules are always the same (you can define all the rules)
  - With DNA you have, there’s only 4 base pairs, and they can only combine in 2 ways
  - And everyone has a one-to-one mapping with what it’s going to become
- Here you have 26 letters they can combine in a near infinite ways, and then there are all these dumb exceptions
- That’s where AI comes in

How the AI algorithm works

- We don’t go from the brain activity directly to speech and words and sentences
- In the very beginning with the NATO [words], that’s what we do
  - You can use an algorithm called a “classifier,” and it’s going to look at the pattern activity and then just say, “*Okay, it looks mostly like beta. Another one looks mostly like echo. Another one looks like Charlie.*”
- To get to expressive normal speech, you need something that actually can open up much more combinatorial potential to generate sequences of syllables, words, and sentences
- What we did was we built a decoder that translates the brain activity patterns in very small segments: 10 to 20 millisecond little chunks of brain data, really small signals, small windows of signals

***And the machine learning is looking at those small windows and making an educated guess***

How does the mapping of that brain activity relate to a given consonant or vowel?

- Edward is talking about using a consonant and a vowel just because it’s easy to understand
- The reality is he used a speech unit (a [pheneme](https://en.wikipedia.org/wiki/Tagmeme)), but actually something that was statistically derived from a speech recognition algorithm
  - It was statistically derived
  - It was not something that was linguistically or that you read about
  - It’s really a computational unit that we know if you can decode a hundred of these units, you can generate fluent comprehensible speech
- We used AI actually to derive what those units would be in the first place
- We took a speech recognition system that Meta had made open source about 5 years ago
  - It’s one of the leading speech recognition algorithms.

***We took essentially the neurons and what they do in that neural network, and then we try to map those actually to the brain activity patterns***

- That’s on the very front end
- The first step of the decoding is translating the neural activity patterns to these individual speech units that are just 10-20 milliseconds long
- Then it knows the sequence of these units over time because it’s part of the algorithm calculation
- And we use something called a [language model](https://en.wikipedia.org/wiki/Language_model)
  - Which is something that all of us are now familiar with
  - When you’re texting, it auto corrects your speech
  - Why? Because it has got a model of English in there and that it knows what the particular sequence of the things should be like

Edward explains, “*So even if a lot of the data is kind of fuzzy, as more data accumulates, you get a sequence and then it can basically use a best guess over time, what we call “probabilistic inference” of what was the most likely word or phoneme at any given time point; and ultimately we could construct sentences*.”

**Did you get a sense from Anne as to how her level of fatigue with this progressed?**

*What becomes the bottleneck?*

*Does it get easier and easier for her to go through this talking motion as she practices more?*

*Is it just like any other muscle that we think of that has sort of atrophied and now she’s sort of getting her talking back in shape?*

- It is a bit of that
- We’re trying to make that easier over time
- In the beginning days, we’re trying everything to get it to work, and a lot of it has to do with this volitional intent to speak
  - That turns out to be the most critical thing

One of the things that Edward thought was really interesting

- We were doing so much decoding through these tasks that over time,, and it reports to us the strength of her oral facial muscles, her jaw, tongue
- A couple months into this, her oral facial muscles were getting stronger through this constant therapy/rehabilitation

>  “*I think right now everything is about just decoding the brain activity to an artificial digital thing. But I do think that in the future, BCIs are also going to be a way that we can do rehabilitation*.”‒ Edward Chang

[BCIs](https://en.wikipedia.org/wiki/Brain%E2%80%93computer_interface)

- It’s a way that we have this direct readout of what the brain is trying to do
- You can essentially build a prosthetic that helps people speak, but in the process, someone who hasn’t spoken for a while regains some of that natural strength over time

***That’s a new indication that we’re thinking about in the future: How do you use this technology actually to augment and accelerate rehabilitation?***

**If Anne had that stroke today, how different would this process look, if you were working with a person who had spent 18-20 years without speaking?**

- There’s no question that it would work faster
  - There’s less to learn

For her, not speaking for 18 years basically meant

- That she had to relearn how to speak, and we had to keep up with her relearning
- Her brain was probably reorganizing, relearning, actually some of those fundamental things
- And she could see the feedback of essentially whether or not what she was trying to say was right or wrong, and it was very intense work
- We’re trying to make that easier over time

Edward adds, “*I think certainly the more preserved, the more recent that activity is, those memories, the synapses we talked about earlier, the more stable, the more functional they are, the easier it is to actually decode them.*”

**What will be the ceiling for the current technology? Where will this asymptote?**

*How many words per minute and at what resolution or accuracy do you think the current technology, because this was ECoG in her case, correct?*

- Right
- We’re seeing a lot of progress in this field
- At the same time or soon after what we were doing, there were other groups that basically could see similar effects
  - Edward’s work was primarily from the brain surface
  - A close colleague of his was able to now do this with electrodes that were inside the brain and using these intracortical arrays
  - So it seems that it’s possible with different approaches

***Edward shares: what is going to be a key question is what’s going to be the right form moving in the future for many patients?***

- With Anne, we were able to get about 80 words per minute on average, so sometimes much faster than that
  - For comparison, Peter and Edward are probably speaking 150, 160 words per minute right now
  - Peter finds it amazing that she could speak at half this rate
- It’s not like the speech was coming out super slow
- It’s just that there’s this built-in latency time that we use to translate the brain activity into those words and sentences
  - What he [published](https://pubmed.ncbi.nlm.nih.gov/40164740/) more recently had a very short had a very short latency

In Edward’s [‘23 paper](https://pubmed.ncbi.nlm.nih.gov/37612505/)

- The decoding strategy was to take this sequence of decoded phonetic elements, and we could look at that sequence and then apply the decoding algorithm in the language model to reconstruct full sentences
- And then we could even synthesize them and personalize them actually to her pre-injury voice
- In a more recent study that he just [published](https://pubmed.ncbi.nlm.nih.gov/40164740/) this year, we were able to do this in a streaming way with less than a second latency between each phonetic element

***So it’s not like we’re waiting for the whole sentence to occur, but we’re doing decoding on the fly and it’s intelligible and fast ‒ that will get up to as quickly as she can say the words***

- This is all with the same hardware, totally different algorithm

**Challenges on the hardware side**

- On the intracranial hardware, obviously there’s a big material science push to come up with the most immunologically inert substance possible
  - That’s your challenge there

*With the ECoG, is there another hardware step function you’re waiting for?*

- Not really

***The thing that’s most exciting about this is that we have the technology now, we got to optimize it in the right form factor; it’s just moving to a fully implantable device***

- Implantable so you don’t have the infection risk

We need to have an array that will have a lot more channels

- Earlier, Edward talked about a credit card sized array with 253
- We’d like to have something that has 4X that amount of sensors
- Peter thinks this seems completely achievable when you think about what [Nvidia](https://en.wikipedia.org/wiki/Nvidia) is doing or [TSMC](https://en.wikipedia.org/wiki/TSMC)
- It is, and we’re doing it right now

With any medical device, you got to put it all together and improve it

- We’ve taken these components that have very high bandwidth wireless, connect it to this array
- In many ways we’ve done the hard part already: what Anne did, what Pancho did (one of Edward’s earlier participants), what Walter is doing (real pioneers)
  - These are incredible people that were really the first people in the world actually to be able to achieve this
  - That was the hard part
- The hard part is always the first time (proof of concept)

***Everything now is just about optimization***

**Do you think of this more as an engineering problem now?**

- It is; yes

## Using brain-computer interfaces to restore breathing, movement, and broader function in ALS patients [A: 1:28:15, V: 1:41:10]

- You have the proof of concept for the engineering problem that says brain works, motor system doesn’t work, we can extract speech

**What about these other problems: What about ALS? Not for speech, but for respiratory function**

- Peter doesn’t know much about a patient with [ALS](https://en.wikipedia.org/wiki/ALS), but he assumes they ultimately succumb to respiratory complications
  - Whether it be aspirations or things like that

*If we could overcome that problem and bypass the degenerative motor neurons, is there an engineering solution to ALS based on the type of technology we’re seeing today?*

- To go beyond the ability to talk and help a patient breathe normally and ultimately not lose motor function outside of the CNS is another couple of step functions in the engineering

You are basically talking about bypassing a pretty significant section of the nervous system

- So you’re going to tap into the brain to get some of the control signals
- For some of this you don’t even need to tap in the brain
  - For breathing, a lot of it is wired; we’re not thinking about it
- Central pattern generators in the brainstem, for example, are really important for that breathing pattern

**Why is it that we couldn’t wire into all of the cranial nerves outside of the cranium and create a respiratory system that is fully automated?**

- Like almost think of an [AICD](https://en.wikipedia.org/wiki/Implantable_cardioverter-defibrillator) for the diaphragm and chest wall
- We’ve spent most of this time talking about the brain side, but then you can imagine another whole new enterprise and **endeavor of building the electronics that****go directly to the muscles**
  - They don’t necessarily even tap into the cranial nerves let’s say, or the cervical nerves that go to the diaphragm, but you bypass those too
- There is a field [of this research]
- Edward is not directly doing this research, but it’s highly related to where the future is

**⇒** It’s called [FES (functional electrical stimulation)](https://en.wikipedia.org/wiki/Functional_electrical_stimulation): coupling the brain-computer interface (the device that’s decoding the brain activity), translating into the control signals, and then actually acting on the muscles through stimulating electrodes that are in the muscles themselves and doing that coordinated movement

- Breathing actually is a really interesting one because it’s not as complex
  - It’s like restoring our hand

Peter points out

- Everybody assumes today, if you really want to be in the forefront of technology, you need to be on the [CS](https://en.wikipedia.org/wiki/Computer_science) side
- But the truth of the matter is you need just as much horsepower on the bioengineering side
  - Electrical engineering, biomedical engineering, mechanical engineering
  - These are material science

***This type of problem is the intersection of everything that is high-tech from AI to computer science to all disciplines of engineering, coupled with medicine***

- You have to have the surgeon too

Edward agrees, “*I think that you hit the nail on the head because in many ways that’s the challenge actually more than the technology itself is really how do you get the engineer in the room with a neurosurgeon, with a neurologist, the neuroscientist all thinking in a really concerted way about solving this problem.*”

**What you’re going to see in the future actually is that this is going to evolve more and more as a biological problem**

- Thinking about biology is the next technology solution
- Engineered cells that are interfacing with the brain as opposed to metal electrodes

***New ways of doing computing that are through biology that are not through semiconductors is ultimately where Edward thinks things are going to go in the future***

*Some people are already talking about this, but Peter would like to understand more what you mean by that because it’s complicated*

- It is complicated
- Edward is talking about the next couple of steps
- One of the reasons why this comes up is that you’ve got this electrode system
  - Let’s say you’re recording from one cell
  - Best case scenario, you beat an electronic system that can maybe do 10, maybe 40 in the future, 1000 channels; but the denominator is 86 billion
- We’re not in the same regime of scale

Biology has solved a lot of these scaling problems

- Cells that have the same genetic programming multiply because of their environment, other factors ‒ it becomes specialized for a specific function
- That’s how our brain is
- Each individual cell has the same genetic program, but because of its local milieu, it ends up having a different identity, different purpose

That is really thinking outside of the electronical engineering, really moving into the realm of bioengineering

- This field is moving pretty fast
- There’s a whole field that we call [organoids](https://en.wikipedia.org/wiki/Organoid)
  - This is building mini-brains from cell cultures or stem cells
- It’s primarily being used as models of disease right now, but also as ways to test new drugs

***Edward predicts that we’re going to see organoids interfacing with the world of brain-computer interfaces (it’s very exciting)***

- It’s not near-term, but there certainly is something about the future of technologies actually in biology

## The 2030 outlook for brain–computer interfaces [A: 1:34:00, V: 1:47:56]

**What is your stretch goal for the field in 2030? (if things go well; not science fiction)**

- Edward hopes these systems are available to a much broader market
- We have shown in a research setting (a very controlled setting) that this can be done, the proof of concept
- What really needs to be done is a lot of hard engineering to make this practical, usable, useful for people with a variety of different neurological conditions
  - Not just ALS, but spinal cord injury, stroke, multiple sclerosis
  - Everyone may have a very specific need ‒ we need to be able to solve that (it can be solved)

Edward adds, “*Let’s get a couple of these across the finish line so that they’re actually out in the world helping people.*”

**Is there a current company (or set of companies) that are the natural owner to solving this problem based on their existing expertise, or is what you’re talking about basically new companies that have to become capitalized and do this** ***de novo*****?**

*Who would be the natural owner of this?*

- It’s both
- The most famous probably is [Neuralink](https://neuralink.com/) ([Elon Musk’s](https://en.wikipedia.org/wiki/Elon_Musk) company) that has a very specific approach where you have a robot that is surgically inserting and sewing electrodes into the brain and trying to record from that very finest resolution
  - There’s a lot of progress with that, but also we’ve seen a lot of challenges
- It’s a really hard technical problem to solve at that scale
- There’s a variety of other companies in that vein

One of the things Edward is working on is a highly customized ECoG approach

- We already know that it works from a lot of the work that we’ve done, and we can make it a lot higher resolution than we’ve done before and make it much safer with a fully implantable system
- We’re going to see more and more over time that this is going to become less and less invasive
- Just like surgeries have become less invasive over time (as he talked about at the beginning of this conversation)

> “*Brain-computer interfaces will become less invasive. We’re at the very beginning of this story*.”‒ Edward Chang

***Getting the most amount of data right now is the most important with highly invasive approaches***

- As time goes on, we’re going to back out from that invasiveness
- That’s always how things evolve to make it more generalizable, easier, and safer for people to do

**When you say less invasive, do you think there will ever be a day when you can do this off an EEG on the surface?**

*Or do you think, no, it will be more like minimally invasive surgery to open surgery where instead of a craniotomy, we’re going to bore a single hole in there, we’re going to put a small tiny chip in through the dura, implant it on there, and we’re done?*

- The latter
- Peter reasons, “*The resolution at the outside of the skull is probably never going to be good enough.*”
- This is a physics problem that a lot of people have tried to solve
  - Peter compares it to: batteries will  never store energy nearly as well as hydrocarbons

***That level of resolution that we have from the scalp [is possible] in theory; but in practice, no one has been able to crack that***

- A lot of smart people have worked on that problem

***Devices can continue to be miniaturized and surgery can continue to be safer***

- Edward predicts, “*We will see this point in history where devices at some point are not going to just be about medical applications. They’ll be essentially enhancement level. There’s huge ethical questions that we’re going to have to deal with when that time comes. We’re not there right now.*”
- We’re not talking about breaking any rules and laws of physics in order to get there
- We’re just talking about miniaturizing electronics in a way that is just a smaller form factor, but over time everything becomes less invasive

## The potential of stem cell and cell-based therapies for regenerating lost brain function [A: 1:38:00, V: 1:52:35]

**Going back to the origin of Anne’s story, so many people suffer brain injuries**

*If you could wave a magic wand, you would just hope for some regeneration of the injured portion of her brain*

- Peter guesses that in her case, the total volume of cells that are damaged is small
  - It could be half the size of your thumb
  - But it just happened to be in the most precious part of real estate in her entire body

*Do you have any point of view on the potential future of stem cell-like interventions for the purpose of regeneration specifically in the* [*CNS*](https://en.wikipedia.org/wiki/Central_nervous_system)*?*

- This is an area that got a lot of focus and attention maybe about 10 or 15 years ago,  and the results were pretty modest at best
- It’s coming back now because of a lot of cell-based therapies, organoids (building miniature models of brains on cell cultures basically)

***Edward thinks the first things we’re going to see is very focal delivery in replacing cells that have been lost in small targets of the brain***

**In Parkinson’s disease**

- You’ve got degeneration of dopaminergic neurons in the [substantia nigra](https://en.wikipedia.org/wiki/Substantia_nigra)
- The goal is can you replace and basically transplant some stem cells into that part of the brain?

*Remind me why the cells in the substantia nigra, do we know what’s killing them?*

- It could be multiple faults
  - It’s partially genetic: there are certain genes that predispose to degeneration there
  - There are certain environmental toxins that can cause the degeneration
  - And then there’s a huge bucket we still don’t know what’s causing that
- At the end of the day, there is a degeneration of those very specialized cells
- Most of the treatments are around dopamine replacement medications

*How close do you think we are towards transplant?*

- It’s already been done around 20, 30 years ago using fetal grafts
- Some of them took and some patients got benefit from it
- The side effects were fairly severe
  - If you have too much dopamine, you can actually get [dyskinesia](https://en.wikipedia.org/wiki/Dyskinesia) (hyper movement)
- One of the cardinal symptoms of Parkinson’s is [bradykinesia](https://en.wikipedia.org/wiki/Hypokinesia#Bradykinesia:~:text=initiate%20voluntary%20movement.-,Bradykinesia,-(%CE%B2%CF%81%CE%B1%CE%B4%CF%8D%CF%82%20bradys) ‒ specifically where you have slowed movements, slow to initiate movements as well

Edward explains, “*If you have cells that are just pumping out dopamine, they can also be putting out too much and you get the opposite effect. So it’s not as simple as just putting them in there.*”

- They actually have to be tuned in the right way to put out the right levels

***There’s a new generation of new therapies that we’re really interested in trialing at UCSF that are much better cell models, much better control of dopamine that’s involved, much better delivery systems***

**Could you imagine engineering your way out of Parkinson’s disease?**

- Edward is working on it

*What about synthetic cells where you completely get to control it?*

- Peter notes the substrate problem
- But if it’s truly a synthetic cell, then presumably it can make dopamine as well
  - As opposed to an implantable slow leak dopamine that you come up with some slick way to refill

*What do you think is more likely, the more pure engineering approach or the more biologic transplant approach where you just try to tune it?*

- The near term is taking some cell cultures that are not purely synthesized
- That is still a huge goal outside of the brain: can you generate a cell *de novo* without some origins?

Peter asks, “D*oes that require immune modulation?*”

- Absolutely; it’s a full transplant
- A of these patients initially will be on immunosuppression for that, but that’s also improved a lot
  - Similar to an immunosuppressive given to patients who receive a kidney, liver, or heart transplant
- Right now, this is at the level of precaution

**There is progress being made in trying to make these things as least immunogenic is possible**

- That’s where a lot of the engineering is focused on is to make it the least immunogenic to avoid a rejection scenario
- And that’s some of the biological engineering that Edward was talking about
  - The future of technology, really coming back to the biology, moving a little bit away from the electrical engineering

## Edward’s vision for how neurosurgery and treatments for glioblastoma, Parkinson’s disease, and Alzheimer’s disease may evolve by 2040 [A: 1:42:15, V: 1:57:54]

**In 15 years (2040)**

- Edward will still be operating
- He’ll probably be in the final decade or 15 years of his career
- By surgeon standards, there is plenty of work to do

*What do you think the world looks like in 2040? Which major problems that stand in front of you today do you expect to fall and what will be the implications?*

- The course we’re on and how things are changing, how things are being unlocked, Edward thinks we’re getting close
- Some of these things are not standard because of the side effect profiles are too severe, but they can have therapeutic efficacy
- We need to do that tuning this optimization
- There’s a lot of proof of concept out there

***99% of the work is in the optimization in that engineering***

**Glioblastoma**

Edward adds, “*Now that we understand what are the molecular and genetic drivers of a disease as devastating as glioblastoma, we will have way more powerful tools that will hopefully make it a chronic condition as opposed to a life, a death sentence in 18 months (on average).*”

- That being said, with surgeries, we can get out to many years
- But a goal would be to make it a chronic [disease], potentially cure
- By essentially attacking the mechanisms
- We now know the genes that are altered
- We need to be able to turn on the immune system to recognize [the cancer]
- Huge amount of effort in trying to figure this out

**Edward is very optimistic around neurodegenerative disorders**

*Including the cognitive ones like Alzheimer’s?*

- Edward thinks earlier diagnosis and earlier treatment is going to be the first things where we’re going to have the best effects
- [Alzheimer’s] is a really difficult one
- But around Parkinson’s where there’s a focal problem, you can regenerate those cells

***Edward is more optimistic on the movement disorders than he is on the cognitive disorders***

- Partly because the target in the cell loss is very focal [in Parkinson’s disease]
- We can get cells [into the brain] through a surgery

**⇒** When we’re talking about Alzheimer’s, it’s a bit trickier because it involves multiple systems in the brain simultaneously

- There are studies even using electrical stimulation in parts of the brain that are really important for encoding memory
- These things are promising, but for these step functions that what everyone wants, it’s either stall the disease or reverse it
- It’s going to take more time

***Edward thinks early detection [for Alzheimer’s disease] is going to be a game changer***

## The rare but dangerous risk of vertebral artery dissections from chiropractic neck adjustments and high-velocity movements [A: 1:44:45, V: 2:00:43]

**Do you have a point of view on things that place people at risk for vestibular artery dissections?**

- This came up through the story of Anne
- For example, Peter has always been afraid of having anybody adjust his neck for fear of having a vestibular artery dissection

*Is there any truth to that risk?*

*Are there other things that people should be aware of given the low probability, but very, very high severity of such an injury?*

- It’s not a wives’ tale

***It’s statistically proven that certain kinds of chiropractic movements around the neck can cause an injury to the wall of the vertebral artery***

- And that term dissection means that the wall of the artery has dissected
- There’s usually multiple different layers to that vessel wall

**⇒** What happens with the dissection is the vessel is injured and then blood actually starts splitting the wall of the artery more up until the point where it becomes occluded

- It’s a very, very dangerous situation, and a critical part of the brainstem

***Edward recommends: avoiding severe, aggressive movement***

- Sometimes you see this injury around sports where you have a very high velocity movement and posture around the neck
- That being said, this is a **very low incidence**, very low probability of happening
- It’s not at the level that you could really tell people to avoid certain sports or anything like that

## How Harvey Cushing might view modern neurosurgery, and how the field has shifted from damage avoidance to unlocking the brain’s functions [A: 1:46:15, V: 2:02:31]

**If we could bring** [**Harvey Cushing**](https://en.wikipedia.org/wiki/Harvey_Cushing) **back from the dead, then you could have dinner with him tonight, what do you think he would say if she saw what was going on in the field that he created?**

- Edward thinks that there would be one part of him that is looking at some of the surgeries that we do where we’re still doing craniotomies, and he would say, “*That looks pretty similar to what we did 150 years ago*.”
  - That’s part of his genius,that we still do it
  - That means it still works
  - A lot of that credit goes to Dr. Cushing
- There will be things that he could have ever never conceived
  - The way that we’re retrieving blood clots that are reversing strokes
  - What we’re doing with brain-computer interfaces: decoding brain activity at the substrate of thought to replace communication for people who are paralyzed
- Back then, our knowledge was so limited and electronics was nowhere even close to being able to imagine what could be done now

A lot of what we’re seeing actually relies on technology that has evolved, like artificial intelligence

- A lot of the work that we did on decoding the brain just couldn’t work, even though we had the hardware maybe 10 or 20 years ago, probably even earlier than that

***The decoding was not possible until this modern machine learning***

- These things are just accelerating very, very fast right now

**Progress in medicine over the last 150 years**

- When Peter was a resident, he used to have this very famous picture on his wall of the 5 physicians who were the founding physicians at Hopkins
  - [Halstead](https://en.wikipedia.org/wiki/William_Stewart_Halsted) in surgery
  - [Osler](https://en.wikipedia.org/wiki/William_Osler) in medicine
  - [Kelly](https://en.wikipedia.org/wiki/Howard_Atwood_Kelly) in gynecology [and internal medicine]
  - [[Welch](https://en.wikipedia.org/wiki/William_H._Welch)] in pathology
  - [Harvey Cushing](https://en.wikipedia.org/wiki/Harvey_Cushing) in neurosurgery
- Peter thinks if you could bring all of them back to life today to see how much each of their fields had progressed, he thinks that Cushing would be the one most blown away because what we’ve talked about today is unimaginable
- Of course, Osler would see medications that he never could have conceived them
  - The profound effect a [GLP-1 agonist](https://en.wikipedia.org/wiki/GLP-1_receptor_agonist) could have on weight loss
  - He could never conceive at the time that there would be a medication that could eradicate cholesterol, let alone an [injection](https://en.wikipedia.org/wiki/Inclisiran) once every 6 months that could do it
  - He might have not even conceived obesity back then
  - Although, he was tasting urine, so he certainly knew about diabetes
- Peter thinks about the mental leap to where we are
- Maybe the pathologist would’ve never imagined the genomic sequencing that we could do of tumors today
  - Back then it was all histology

> “*It is amazing to me how much medicine has changed in 100 years.*”‒ Peter Attia

- It doesn’t take a leap to imagine that if we’re still around as a species in 100 years, the next 100 years is going to offer far bigger changes
- The pace of acceleration now is unprecedented

**The complexity of the brain**

- The underlying reason why Edward thinks Cushing would be the one that would be the hardest to understand what’s happening now is because we are talking about the brain
- We are talking about an organ system that we’re just starting to fathom and put our heads around the complexity

Edward puts this in context, “*For the last 150 years, neurosurgery has really actually been about how do you avoid injuring the brain? How do you take a tumor out of it? How do you deal with the plumbing, which is the vascular system, the blood supply?*”

The biggest open-ended questions are really being addressed right now in the coming decades

- How does the brain itself work?
- How do we tap into that to address a large variety of neurological and psychiatric conditions?
- The history of neurosurgery was actually primarily about trying to avoid injury, stay outside of the brain, etc.
- Now it’s much more inward-looking, trying to understand actually how the system works, how the organ works

> “*It’s a super exciting time because every time we unlock essentially a function of a certain part of the brain, there’s a very high probability that there’s going to be a therapy either through a brain-computer interface or through a new biological approach*.”‒ Edward Chang

- Every time we unlock a new mechanism, there’ll be something that we can do to treat it, and that’s what the future’s going to look like

**One of Peter’s hidden agendas of this podcast is to encourage as many young people as possible to go into medicine**

- Medicine today is not nearly as attractive a career as it was 20, 30, 50 years ago
- The best and the brightest are typically going elsewhere

***A podcast like this (and many of the podcasts Peter does with doctors), showcases that we need the best and the brightest to go into medicine***

- This is not saying we don’t need another brilliant person doing AI or investment banking or law or wherever else the top people go

***There is really an opportunity to bend the arc of civilization by choosing a career in medicine***

- Peter thinks what Eddie is doing is really on the forefront of that
  - Especially the way it combines all disciplines of science, medicine, and technology
  - It’s super exciting

---

## Selected Links / Related Material

**Hearing loss may not be causal to cognitive decline**: [Hearing intervention versus health education control to reduce cognitive decline in older adults with hearing loss in the USA (ACHIEVE): a multicentre, randomised controlled trial](https://pubmed.ncbi.nlm.nih.gov/37478886/) | *The Lancet* (F Lin et al. 2023) | [47:30]

**Electrocorticography clinical trial**: [Neuroprosthesis for Decoding Speech in a Paralyzed Person with Anarthria](https://pubmed.ncbi.nlm.nih.gov/34260835/) | *The New England Journal of Medicine* (D. Moses et al. 2021) | [52:15]

**About the BRAVO Clinical Trial**: [52:15, 1:10:30]

- [Speech Neuroprosthesis](https://changlab.ucsf.edu/speech-neuroprosthesis) | Chang Lab (2025)
- [Discoveries](https://changlab.ucsf.edu/discoveries#bci:~:text=Restoring%20Communication%20with%20Brain%2DComputer%20Interfaces%20(BCIs)) | Chang Lab (2025)

**Edward’s 2023 clinical trial with Anne**: [A high-performance neuroprosthesis for speech decoding and avatar control](https://pubmed.ncbi.nlm.nih.gov/37612505/) | *Nature* (S Metzger et al. 2023) | [1:01:15]

**Edward’s 2025 paper**: [A streaming brain-to-voice neuroprosthesis to restore naturalistic communication](https://pubmed.ncbi.nlm.nih.gov/40164740/) | *Nature Neuroscience* (K Littlejohn et al. 2025) | [1:26:00]

---

## People Mentioned

- [Harvey Cushing](https://en.wikipedia.org/wiki/Harvey_Cushing) (1869-1939, pioneer of brain surgery, first exclusive neurosurgeon, first person to describe Cushing’s disease) [3:45, 1:46:15]
- [Wilder Penfield](https://en.wikipedia.org/wiki/Wilder_Penfield) (1891-1976, neurosurgeon who expanded brain surgery techniques and mapped functions of various regions of the brain, including the homunculus) [5:30, 20:15]
- [Diane Daly Ralston](https://synapse.library.ucsf.edu/?a=d&d=ucsf20000518-01.2.6&e=-------en--20--1--txt-txIN--------) (1938-2000, Professor of Medicine at UCSF, neuroanatomist, neurosurgeon, and expert in pain research) [17:00]
- [Mitchel Berger](https://braintumorcenter.ucsf.edu/people/mitchel-berger) (Director of the UCSF Brain Tumor Center) [17:30]
- [Roger Sperry](https://en.wikipedia.org/wiki/Roger_Wolcott_Sperry) (1913-1994, cognitive neuroscientist and Nobel laureate, expert in split-brain research) [31:45]

---

![](https://peterattiamd.com/wp-content/uploads/2025/09/bio-edwardchang.jpg)

##### Edward Chang, M.D.

Edward Chang earned a Bachelor’s in Chemistry at Amherst College. He earned his Medical Degree from UCST and completed a residency in neurological surgery there. He completed a postdoctoral fellowship in cognitive neuroscience at UC Berkeley. Dr. Chang is a Professor and Chair of Neurological Surgery at the UCSF Weill Institute for Neurosciences. He is a neurosurgeon who treats patients with epilepsy, brain tumors, and cranial nerve nerve compression syndromes such as trigeminal neuralgia and hemifacial spasm.

Dr Chang specializes in advanced brain mapping methods to preserve crucial areas for speech and motor functions in the brain. He also has extensive experience with implantable devices that stimulate specific nerves to relieve seizure, movement, pain and other disorders. Dr. Chang is a member of both the National Academy of Medicine and National Academy of Sciences. He was awarded the [2025 Gruber Neuroscience Prize](https://gruber.yale.edu/prize/2025-gruber-neuroscience-prize) for his landmark discoveries in the neural basis of human speech.

Dr Chang’s research focuses on the brain mechanisms for speech, movement and human emotion. He co-directs the Center for Neural Engineering and Prostheses, a collaborative enterprise of UCSF and the University of California, Berkeley. The center brings together experts in engineering, neurology and neurosurgery to develop state-of-the-art biomedical technology to restore function for patients with neurological disabilities such as paralysis and speech disorders. [[UCSF](https://profiles.ucsf.edu/edward.chang)]