# #331 ‒ Optimizing endurance performance: metrics, nutrition, lactate, and more insights from elite performers | Olav Aleksander Bu (Pt. 2)

**Source:** [https://peterattiamd.com/olavaleksanderbu2/](https://peterattiamd.com/olavaleksanderbu2/)

---

Olav Aleksander Bu is an internationally renowned sports scientist acclaimed for his coaching prowess with elite athletes spanning a diverse range of sports disciplines. In this episode, Olav returns to dive deeper into his groundbreaking work as an endurance coach, exercise scientist, engineer, and physiologist. The discussion explores his data-driven approach to coaching, unpacking key performance metrics like functional threshold power, VO2 max, and lactate threshold, while emphasizing the importance of consistent testing protocols. Olav shares insights on how training methodologies differ across sports, the impact of nutrition on endurance performance, and the evolving strategies for carbohydrate metabolism in fueling athletes for races. Olav concludes with a discussion on the use of artificial intelligence for optimizing training insights and performance.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/olavaleksanderbu2/the_Drive_public.png)

Play

#331 ‒ Optimizing endurance performance: metrics, nutrition, lactate, and more insights from elite performers | Olav Aleksander Bu (Pt. 2)

#331 ‒ Optimizing endurance performance: metrics, nutrition, lactate, and more insights from elite performers | Olav Aleksander Bu (Pt. 2)

1x15s30s

0:002:16:12

## We discuss:

- Olav’s unique, engineering-driven approach to endurance coaching [2:45];
- Definitions and applications of key performance metrics: FTP, power, anaerobic threshold, and lactate threshold [4:45];
- Lactate threshold: factors affecting lactate threshold, testing protocols, and how elite athletes’ efficiency affects their performance and lactate profiles [14:15];
- VO2 max: definition, testing, factors affecting its accuracy, and methods for optimizing oxygen utilization in elite athletes [22:15];
- Testing VO2 max: common mistakes and key factors to consider—preparation, warm-up, timing, and more [34:00];
- VO2 max testing continued: measuring instruments, testing protocols, and advanced insights gained from elite athletes [41:45];
- The influence of supplements like beetroot concentrate and adaptogens on VO2 max and performance [49:45];
- How respiratory quotient (RQ) reflects metabolic shifts during exercise, the challenges in measuring and interpreting RQ in elite athletes, and the physiological adaptations needed for prolonged endurance events [53:30];
- Triathlon training: the challenge of maintaining elite performance across triathlon distances, metabolic efficiency, and swimming challenges [1:03:15];
- How reducing drag in swimming could revolutionize performance and the role of biofeedback tools in optimizing efficiency across various endurance sports [1:07:00];
- How endurance athletes prioritize effort regulation using RPE, heart rate, and power output, and the role of lactate in cardiac and athletic efficiency [1:20:00];
- Lactate’s role as a fuel, buffering methods to combat lactic acidosis, and the variability in athlete response to bicarbonate supplementation [1:25:45];
- The physiological mechanisms behind differences in performance between two elite athletes: lactate transport, cardiovascular efficiency, and compensatory systems [1:33:00];
- Comparing interventions like acetaminophen to enhance performance in high-heat conditions versus natural adaptations to heat [1:37:15];
- Advancements in nutrition science, changes in cyclist body composition, and the impact of fueling strategies on athletic performance and growth [1:39:30];
- Optimizing endurance performance with utilization of carbohydrates, and the potential role of ketones [1:48:00];
- Insights gained from elite performers in the 2020 and 2024 Olympics [1:58:30];
- The use of artificial intelligence to optimizing training insights and performance [2:06:30]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Olav Aleksander Bu was a guest in March 2024 [[episode #294](https://peterattiamd.com/olavaleksanderbu/)], and at the time of that conversation, Peter realized they hadn’t gotten through the majority of what he wanted to speak about
  - It was inevitable that he would have him back
- Olav is an endurance coach, exercise scientist, engineer, and physiologist
- He is the Head of Performance for Norway Triathlon and is best known for coaching 2 of the world’s top triathletes: [Kristian Blummenfelt](https://en.wikipedia.org/wiki/Kristian_Blummenfelt) and [Gustav Iden](https://en.wikipedia.org/wiki/Gustav_Iden)
- In this episode, we review his work, his approach to coaching, and the way that he relies very heavily on data
- We talk about and define various performance metrics: FTP (functional threshold power), critical power, anaerobic threshold, lactate threshold, VO2 max
  - And the importance of consistent protocols when testing these performance metrics
  - And how they can vary depending on an athlete’s training
- We discuss differences in training methodologies across sports
  - And how different sports influence power, pace, and endurance
- We look at the significance of nutrition in endurance sports
  - How athletes train to properly fuel themselves for races, and why this is so different from what has been done historically
  - We got into this difference in carbohydrate metabolism
- Just like the first time Olav and Peter spoke, this is a discussion that can be quite complex
  - We get a little bit into the weeds
  - Because of nature of what we’re talking about, it’s very difficult to talk about these things meaningfully and superficially
  - Patience is always appreciated, and the rewards are there if you’re able to stick with it

## Olav’s unique, engineering-driven approach to endurance coaching [2:45]

- Last time we spoke really about the most nuanced ins-and-outs of cardiorespiratory fitness [[episode #294](https://peterattiamd.com/olavaleksanderbu/)]

**For the person who didn’t catch that episode, can you give the one-minute version of what you do and why you’re certainly one of the few people that would be poised to talk about what we’re going to talk about today?**

- Olav’s background is in engineering, and that principle has guided him through his journey in endurance sports (or sports in general)
- He embarked on a journey 15 years ago of extreme in-depth longitudinal studies on 2 of the arguably fittest athletes in the whole world [[Kristian Blummenfelt](https://en.wikipedia.org/wiki/Kristian_Blummenfelt) and [Gustav Iden](https://en.wikipedia.org/wiki/Gustav_Iden)]
- A large part of that involves technology development simply because he is working at the edge of available information
  - In some cases they have to develop technology to allow them to gain a more granular understanding of why things are the way they are
- In many ways, he’s an applied scientist

**Is your laboratory both a** [**CPET lab**](https://en.wikipedia.org/wiki/2-day_CPET) **and a racing environment where you work with triathletes?**

- Yes and no
- Olav works with a mixture of athletes, between triathletes, cyclists, runners, track and field, to even sailors (which is on the explosive end of the domain and not endurance)

## Definitions and applications of key performance metrics: FTP, power, anaerobic threshold, and lactate threshold [4:45]

**We’re going to use a lot of terms today (anaerobic threshold, lactate threshold, VO****2** **max, FTP). Can you define FTP (functional threshold power)?**

- There are a couple definitions, the original definition of FTP (by [Andy Coggan](https://shhs.indianapolis.iu.edu/connect/directory/coggan-andrew.html)) was to do a 5-minutes all-out effort, have a short pause, then do a 20-minute all-out effort, and then subtract 5% from that to find your FTP
- Typically that would be your 20-minutes all-out effort minus 5%
- The reason for that is to try to get a ballpark idea of your sustainable power output over an hour
- Over the years we have learned  that this is not accurate and there have become different ways of doing it
- Some people do a warmup, then do 20-minutes all-out and subtract 5% (that’s different)
- Peter used to do a gentle warmup for a hour, do 20 minutes, and then subtract 10%

*Peter wants people to understand the spirit of FTP and not get mired in the details*

***FTP approximates an energy zone that is more than just an all-out, but clearly less than what you could hold indefinitely ‒ it’s directionally about the highest output you could have for an hour***

- There are different ways to approximate it
- Olav adds that **it’s more important to determine this consistently** using the same protocol for comparisons

**How does FTP differ from another term that is used interchangeably (erroneously), which is critical power?**

- Critical power is determined from doing multiple all-out efforts
  - You apply a reverse extrapolation to figure out the critical power

> “*I like the critical power approach a little bit better*.”‒ Olav Aleksander Bu

*What is that trying to approximate?*

- Critical power is where you try to divide something into 2 zones (that’s an oversimplification)
  - To distinguish between non-severe and a severe state
  - In the same way as FTP is trying to figure out what power you are capable of staying at for a prolonged period
    - Where you get into a territory where small changes have a huge consequence on the duration that you’re capable of holding it

*Where does critical power typically lie in relation to FTP?*

- This depends a little on how you test FTP
- How FTP has been used recently had deviated from how the authors originally devised it
- Normally, FTP would be slightly lower in power output than critical power
  - But this depends on how critical power is defined
- From a metabolic perspective, critical power sits somewhere between your maximum lactate steady state (anaerobic threshold) and [VO2 max](https://en.wikipedia.org/wiki/VO2_max)
  - Typically, it’s more close to VO2 steady state (we’ll define that soon)

**Many of these metrics (FTP, critical power) are easiest to think about in terms of cycling because we use power meters. Do the same concepts still apply in swimming and running?**

- Yes
- For simplicity, it helps to use 1 condensed number such as **critical pace**
- Testing this in running and swimming is not too different from what you would do in cycling

***However, you have access to more granular information that you lose when you call it FTP or critical power***

- If you present only that number, you have taken 2-dimensional information and made it 1-dimensional (meaning that you only look at the Y-axis and you take away the how long you are able to sustain something)
- When you first do **critical power testing**, it’s more interesting to know how how far you are able to get over 1 minute, 5 minutes, and 50 minutes
  - And then see what happens the next time you do it for 1 minute, 5 minutes, and 50 minutes
  - It’s quite crucial to understand what’s happening with the different balances in the body
- Most people think of **FTP** as a 20-minute power, so it’s even simpler (more condensed) information

**2 things can normally happen with training**

- 1 – You increase your general capacity (power and/or capacity are increased)
- 2 – At some point we are all time limited, and this is where we need to prioritize what’s more important for us: explosive speed or endurance

***This becomes interesting for how you guide training, understanding what’s happening between different power or pace and durations***

**How do we define anaerobic threshold (AT)?**

- Olav compares this to how we call chatGPT AI
- It’s an extremely broad term that tries to encompass what they just talked about
- It’s the difference between where something is at steady state and where it is unsteady
  - Where you can hold something for a longer duration and where it can only be held for a short duration

***It’s a misconception to think that anaerobic threshold means when you become anaerobic (that’s not the case, it’s a continuum not a switch)***

*If we’re talking about cyclists with a power meter, where does anaerobic threshold tend to sit relative to FTP?*

- We can use lactate as a tool for trying to figure out where this is

***When you use the gold standards on maximum lactate steady state, the typical anaerobic threshold would normally sit below the critical power or FTP (at a lower power output)***

*The difference in anaerobic threshold depends on what kind of an athlete you are (high-power or endurance)*

- If you are a high-power athlete, you’ll typically see larger % differences in the anaerobic threshold
- For endurance athletes, it will be smaller
  - You could call these minute difference
  - It’s not going to be 10% apart in terms of power, it’s going to be a couple % to 5%

**Define lactate threshold**

- There are probably more limitation in the methods used to measure the lactate threshold
- We know that lactate is something you produce all the time, even when you’re sleeping
- The difference is where you find a first inflection point on a **lactate curve** when you do it as a [function of] increasing intensity

*One thing that is easy to get wrong here*

- If you start out at a low enough power or low enough pace, it looks like there is no increase in lactate production as you increase power/pace
- The problem is the way we measure
  - We don’t measure lactate in the muscle, we measure in the bloodstream
  - For changes to be reflected on the instrument, there needs to be a large enough lactate production in the muscles such that they are not able to metabolize the lactate immediately, and it starts to get transported out into the bloodstream and reflect as an increase in lactate in the blood
- Differences are also dependent on the protocol, and that will change

***There are some challenges when you start to mix something external with something internal***

## Lactate threshold: factors affecting lactate threshold, testing protocols, and how elite athletes’ efficiency affects their performance and lactate profiles [14:15]

**If we did a lactate protocol, a sped or power escalation [to determine lactate threshold]**

- We talked about this last time [[episode #294](https://peterattiamd.com/olavaleksanderbu/#:~:text=Define%20what%20a%20lactate%20threshold%20is%20and%20how%20it%E2%80%99s%20measured%C2%A0) after 2:10:30]
- The way Peter used to do it swimming was to swim 200 yards at a modest pace then check lactate
  - Rest then do it again 5 seconds faster per 200 yards and then check lactate; repeat
- You graph pace on the X-axis and lactate on the Y-axis, and the curve is very distinct
  - [see the example in the figure below]
  - It is very flat and then it’s not
  - We would draw these tangent lines between the 2, and that point was the lactate threshold

![](https://peterattiamd.com/wp-content/uploads/2025/01/f1-olav2.png)

**Figure 1. Velocity versus blood lactate concentration (vAnT is the velocity at anaerobic threshold)**. Image credit: [*International Journal of Sports Medicine* 2011](https://pubmed.ncbi.nlm.nih.gov/22052025/)

*If we did this on a bicycle, where would that typically lie?*

- It would be easy to do the power checks

*How long a duration would you have an athlete do this if you were doing it on an* [*ergometer*](https://en.wikipedia.org/wiki/Ergometer)*?*

- It depends on how you’re going to utilize it
- If you’re going to use it for actively controlling the intensity outdoors, using a lactate meter ‒ in that case, it really doesn’t matter
  - Even taking into account the lag between what’s happening in the muscle and what’s happening in the blood
- Initially you would find a lactate concentration of LT1 and LT2
  - [an example is shown in the figure below]
  - You can also call this LT1 [lactate threshold] and LT2 or AT [lactate threshold 2 or anaerobic threshold]

![](https://peterattiamd.com/wp-content/uploads/2025/01/f2-olav2.png)

**Figure 2. Results of a lactate threshold test**. Image credit: [Loughborough University](https://www.lboro.ac.uk/sport/news/2020/april/training-zones)

Olav explains, “*It’s also a misconception to think that your LT2 is always a constant value because this will be influenced by many factors.*”

- We measure the lactate concentration in the blood and the blood is influenced by hydration and things like this
  - For example, a change in [hematocrit](https://en.wikipedia.org/wiki/Hematocrit) ‒ from the beginning of a session to the end of the session, you can see changes in hematocrit of more than 10% (as you get dehydrated)
  - This will influence the lactate concentration
- As a guiding principle, it doesn’t really matter how long your steps are; you’re looking for a concentration value and then you’re going out into the field and trying to figure out where this is
- A simple example of an endurance value is a LT1 of 1 mmol and LT2 (or anaerobic threshold, AT) of 2.5 mmol
- Peter doesn’t really differentiate between LT1 and LT2
  - He looked at the single inflection point using 2 lines [indicated with an arrow in the first figure]
- Peter usually sees people in the range of 3-4 at that inflection point

*Are you saying that corresponds to LT2?*

- Yes
- And this comes back to what kind of athlete you are
- Peter was mostly swimming when he tested this, and he found that swimmers had the highest lactate capacity
  - For how much lactate they would produce and tolerate
  - But it was a small sample size
- Olav points out that it depends on what kind of swimmers you are testing
- Peter was looking at 2-400 breaststroke, butterfly individual medley
  - He measured on several elite swimmers lactates over 20 mmol
- He always assumed it was 2 things
  - 1 – In an individual medley, you’re using every muscle in the body (not like in cycling or running)
  - 2 – At that distance, you’re really in the “pain train,” you’re not able to do this fully anaerobically and your maximizing aerobic then toppin up anaerobic

> “*I think very often it helps to think that metabolism is basically the same, the body is the same no matter what kind of sport we do.*”‒ Olav Aleksander Bu

**Olav explains that it’s easy to understand if we think of the kind of sport as a function of intensity and duration**

- For a 200-400 meter swim, Let’s say the fastest swimmers take 2-4 minutes
- Compare this to a 1500 meter run, and you’ll find pretty much the same lactate concentration
- The moment you go a little bit longer, then you will see this is not the case

**It helps to distinguish between the highest value of lactate concentration and lactate production**

- Because lactate production is even more complicated
- We can’t really measure lactate production then we need to integrate for time
  - You have to do a pre-measurement, a post-measurement; and there are many weaknesses to an approach like this
  - You have to derive it based more on calculation that you can measure it directly
- How high of a lactate concentration you can get is also valuable because it tells you something about how much you are able to buffer in your body

**This comes back to the main question of how do you use lactate testing**

- For **endurance athletes** (marathoners, triathletes, and other that have a very long duration and don’t have very much top speed), it is not uncommon to see the second inflection point (LT2) below 2 mmol
  - Even validated by maximum lactate steady state

**Peter’s summary**

- When you look at the **most elite endurance athletes**, these people have either some combination of such low lactate production and or such high lactate clearance that frankly the need to buffer it becomes secondary
- They’re producing such a high degree of power
- They’re generating so much work with so much aerobic efficiency that their steady state lactate doesn’t even need to hit 2 mmol
  - Which of course you can sit at 2 mmol all day long and not notice it from an acid base standpoint

*Olav adds more detail*

- Elite athletes have a higher blood volume (larger plasma volume), so lactate production could be higher still, but it shows up as a smaller concentration in the body
- What we distinguish is the point where you are continuing at the same pace (or power), but now the lactate doesn’t remain steady anymore
  - If you measure the same pace, same power after 5 minutes, 10 minutes, and so on until you start the see the lactate rise (it’s not stable anymore)
- That is one of the fewest concepts where it becomes easy to translate and compare the value between people
- The moment you start to talk about anaerobic threshold, it depends on how you define it
  - A 20-minute power, a 60-minute power
  - What kind of duration, what kind of protocol
- When you are a better endurance athlete, you need to have a sustainable energy supply for the duration of the event
  - The faster you can go for that duration, the more beneficial it is
  - This has to do with utilization

## VO2 max: definition, testing, factors affecting its accuracy, and methods for optimizing oxygen utilization in elite athletes [22:15]

**Olav defines utilization**

***Utilization can be defined as race-based oxygen consumption versus your*** [***VO******2*** ***max***](https://en.wikipedia.org/wiki/VO2_max)

- Often in scientific literature it is defined as your oxygen consumption at maximum lactate steady state versus VO2 max
- For example, it could be that at your maximum lactate steady state, you see an oxygen consumption that is 80% of your VO2 max

Peter asks, “*Is that what you would typically see in an elite athlete?*”

- That’s low
- A marathoner would be at 94,95% VO2 max
  - [Kristian](https://en.wikipedia.org/wiki/Kristian_Blummenfelt) and [Gustav](https://en.wikipedia.org/wiki/Gustav_Iden) would be around there when they do Ironmans
- Now that Peter has a [VO2 Master](https://vo2master.com/), he’s testing his VO2 max at sub max levels all the time and looking at how that corresponds to lactate levels

**Define VO****2** **max and then we’ll come back to this point**

***VO******2*** ***max is normally defined as the maximum oxygen your body is able to consume over 1 minute***

- This is also something that is debated, the protocol influence
- For example, you can do an all-out effort in the field and you will be able to produce higher numbers than what you would be able to do on a standard graded exercise protocol

*Peter has found this to be true for himself*

- He likes to do it **outdoors, on his bike, on a hill** (6% grade)
  - He’s in the saddle the whole time, in the big chain ring, and it’s “go for broke” (make sure you’re dead at the top)
  - 4 minutes of climbing and that produces a VO2 max
- There’s going to be a level usually near the very top of the hill, in the last minute where he reaches the maximum volume of oxygen that he’s consuming
- If he **test his VO****2** **max indoors**, he hates doing it on a stationary bike so he uses a StairMaster
  - Now he’s sprinting up stairs, doing the same thing
- He gets a comparable number, but it’s a little bit lower
- He hasn’t tested his VO2 max running on a treadmill, but he predicts he would have a higher VO2 max
  - Even though he’s very inefficient at running ‒ his heart rate is always higher when he runs than when he cycles

Peter asks, “*Do you think that would be the case?*”

- Normally Olav would say that should be the case, but there could be other factors involved
- For example, **Formula One drivers** will sit for 1.5 hours with **extremely high heart rates**
- Peter thinks a lot of this is driven by [g-forces](https://en.wikipedia.org/wiki/G-force)
- The first time Peter looked at an F1 driver’s telemetry, he thought it was a mistake
  - He had never seen such rapid changes from low to high to high to low
- Then he realized these changes were corresponding to either very strong break points or very fast corners
- It would be very interesting to measure VO2 and see if it has a commensurate change

Peter asks, “*What would you hypothesize?*”

- Olav thinks this could be similar in jet fighters as well
- If they are in a dog fight, they could be the same as a Formula One driver
- Olav thinks if you are pushing really high g-forces in one direction, you’re body is trying to counteract that
  - You’re mobilizing every bit of muscle in your body to stay exactly where you need to stay
- Peter thinks part of that **heart rate** is coming from the compromised venous return to the heart
  - Due to either the [Valsalva](https://en.wikipedia.org/wiki/Aortic_sinus) or the actual impeding of the [inferior vena cava](https://en.wikipedia.org/wiki/Inferior_vena_cava)
  - He would think at a high enough g-force, part of that high heart rate is **stroke volume has gone way down** because preload is way down
    - When you fill the heart less with blood, you don’t stretch the muscles out (that’s called preload)
    - The heart needs to be preloaded with lots of blood volume so it can get a good squeeze and anything that prevents that either dehydration or literally forces that are preventing the blood returning to the heart ***could make that high heart rate really a product of tiny, tiny little ineffective beats***
- Olav agrees

**Olav has done some studies on the VO****2** **comparing running to cycling**

- It’s interesting to see what happens with muscles when you do work and you produce a certain amount of power
- There are forces involved and velocity involved
- These forces require a certain amount of recruitment of muscle fibers, and at a certain point, these muscle fibers will actually start to cause vasoconstrictions (they actually start squeezing off the blood supply)
  - Normally they act as a pump, help pump blood around the body, promoting preloading

***When you get into the area of anaerobic threshold, what Olav sees is a point where you’re squeezing off the blood flow in the muscles***

- This happens around a ballpark figure of 30% of you [1RM](https://en.wikipedia.org/wiki/One-repetition_maximum)

Peter asks, “*You should never experience that on a bike, right? Because in theory, it’s hard to imagine you could ever come close to 30% of a 1RM force on a pedal stroke. Could you?*”

- Olav agrees that’s true for sustained efforts
- But for short efforts, you can get very, very close

*Coming back to running versus biking*

- Normally, you would have a higher VO2 max when running at submaximal efforts
- In people who have balanced training (spend some time on a bike and some time running), normally there are more muscles involved for a longer duration in cycling than it is in running

**When you test** [**Kristian**](https://en.wikipedia.org/wiki/Kristian_Blummenfelt) **or** [**Gustav**](https://en.wikipedia.org/wiki/Gustav_Iden)**, if you were to have them fresh on 2 separate days and on 1 day you put them on the bike and on 1 day you put them on the treadmill and you have them do a VO****2** **max test, what would be the approximate difference you would see in them?**

- When Olav started working with them, it was close to a significant difference between cycling and running, and even more of a difference in swimming (it was lowest in swimming)

*That comes back to preloading and how this affects VO**2* *max*

- Olav admits that he was stupid enough to teach Kristian and Gustav a long time ago that ***you can create an artificially high VO******2*** ***max if you try to restrict your breathing when you are close to your all-out effort***
  - For a short time, you will create a depth and this will boost the numbers higher

> “*This is the VO2 max hack for everybody watching this*.”‒ Peter Attia

- Peter’s hack for boosting VO2 max is weight loss: just figure out a way to lose 5 lbs in the week leading up to the test
  - And training in those intervals

***Olav explains that if you restrict breathing as you get close to that failure point, each breath you take becomes that much more of an oxygen explosion and you can spike your VO******2*** ***max numbers up to extreme levels if you practice this a little bit***

Olav adds a caveat, “*I think it is important here to remember that that’s not equivalent to getting fitter. It’s just a way of basically manipulating something in the body, and you’re cheating a protocol and it’s not your VO**2* *max.*”

Peter asks, “*How much of a boost would you get?*”

- Olav views VO2 max in the same way as power ‒ you can look at it in relative terms and absolute terms
- Let’s say you lost weight and it’s 5 liters based on the weight that comes out to 60
- If you practice this technique, Olav thinks you could boost it above 70

**Doesn’t that fly in the face of our definition of VO****2** **max?**

- Which is the highest oxygen consumption you can sustain for 1 minutes
- When Peter does his test, he’s always looking for the 60-second average, and he’s not ever just looking at the peak
  - It’s very noisy data

*With this breathing technique, don’t you just get a really big spike that is otherwise noise in the one-minute best effort?*

Olav explains, “*No. So it would be a little bit more prolonged than that if you create an oxygen debt in your body*.”

**Olav questions published research**

- One thing that is challenging when you read a lot of research is that we very often take for granted that the research is good, but there are a lot of things around it that we don’t know
- 1 – Is the technology they are using good for what they are doing?
  - You can get a lot of machines that measure some kind of oxygen uptake or ratios, but it doesn’t mean that it is necessarily a good instrument for what you want to do
- 2 – We have to understand where we are measuring
- In this case, when we do the oxygen measurement, we measure it on the exhaust and not in the muscles
  - That’s an important difference because if you look at cellular respiration the number are completely different
  - Peter remembers this from their last discussion [[episode #294](https://peterattiamd.com/olavaleksanderbu/#:~:text=doing%20longer%20intervals-,Physiological%20limitations%20on%20VO2%20max%20%5B2%3A02%3A15%5D,-To%20bring%20the) after 2:02:15] ‒ you’re not limited at the cell

> “*Here I think it comes down to just staying true to some principles that can guide us*.”‒ Olav Aleksander Bu

- The good thing with VO2 max testing is that there’s a generally accepted standard for doing this as a graded exercise test, and it will produce fairly comparable numbers

## Testing VO2 max: common mistakes and key factors to consider—preparation, warm-up, timing, and more [34:00]

**What are some of the mistakes you want people to look out for when testing VO****2** **max?**

- When Peter talks about needing to know the 10 parameters of the body for optimal health, VO2 max is on that list every day of the week

Peter explains, “*Even if you are listening to this and you don’t care about triathlons or cycling or swimming, but you just have the desire to live as long as you can and as well as you can, you have to know your VO**2* *max and you need to optimize it and make it frankly as high as you can with whatever time you’re willing to devote to training.*”

- Most people aren’t going to buy a [VO2 master](https://vo2master.com/), they’re going to go to a place where it is measured in a stationary fashion (on a treadmill or a bike)

*What are some things those folks need to be aware of when they go to a center to have their VO**2* *max tested?*

- Peter has talked to many people after testing and asks them, “*How exhausted were you at the end of the test?*”
- When they say they could have kept going he realizes they didn’t do a maximal test
- Other mistakes Peter has seen is people don’t have a long enough warm-up time
  - If the total test took 5 minutes

*Olav likes to create a standard protocol to use every time, and this includes what you do in the days before the test*

- This is probably impractical for most people
- One of the metrics to use in order to understand how the previous period has influenced you is to look for marginal changes
- 1 – Try to eat at the same time before testing every time, and that means making sure you are well-fueled as if you were going to do an important training session
  - You’re eating more carbohydrates and are well hydrated
- 2 – You’ve had proper sleep
- 3 – No training on the day before (or light training, use your experience and understanding of what sets you up for a good test day)
  - For athletes that are well-trained, it’s completely different
- 4 – On the day of the test, the timing of the test during the day is important (keep that consistent for each test)
  - Because of [circadian rhythm](https://en.wikipedia.org/wiki/Circadian_rhythm)
  - We know your **temperature level fluctuates**, and this is one of the most observable measures of circadian rhythm
    - The minimum point typically occurs in the morning just before you wake up, and then you have a maximal point in the afternoon
  - There’s plenty of research suggesting that aerobic exercises are best done in the afternoon, around the highest natural core temperature
- It’s become popular in the Tour de France and triathlons that people use this little temperature device on their body
- And if you use it 24/7, it’s very easy to observe when you minimum body temperatures occur
- The maximum point can be masked by noise and other activities, it’s harder to see

***It really doesn’t matter if you do the VO******2*** ***max test in the afternoon or morning as long as you keep it consistent***

*A proper warm-up is important*

- 5 – Do a warm-up the same way you would for a training session
- 6 – It can be a good thing to have something carbohydrate-based before you start (consume a little bit)
  - People worry that it will influence the [RQ](https://en.wikipedia.org/wiki/Respiratory_quotient), but Olav argues that it would for a submaximal effort but it won’t do much for a maximal effort
    - As you get closer to your maximal metabolic steady state things start to homogenize

**Olav’s suggested warm-up for VO****2** **max testing**

- 1 – Maybe start with 6 minutes very easy ‒ this can be walking of soft pedaling
- 2 – Then do 6 minutes with a little bit more effort
  - It should be something you would be comfortable doing as your longer sessions
  - The longest you should do is an hour
  - If you’re going all-out,that’s too hard
    - Some people say this is your marathon pace or what you would do for longer rides
- 3 – Then do a short effort (around 3 minutes) by feeling of where your threshold would normally be
- 4 – Do 2-3 efforts progressively towards VO2 max
  - Around 10-15 seconds with equal rest inbetween, but don’t exhaust yourself
- 5 – go back to a very short, easy effort

***This warm-up should be a total of about 20 minutes***

***\*Don’t rest too long after the warm-up before doing your VO******2*** ***max test (because you’re going to cool down)***

**Peter doesn’t do VO****2** **max testing on the same day as the fuel partitioning test**

- He wants to measure fat oxidation on a totally different day
- Do your VO2 max test on a Monday and you should have all the carbs in the world
- He likes to standardize the fat oxidation test to a fasting day, so that it’s always the same
  - Test it in the morning
  - It’s a submaximal effort ‒ we’re just pushing to see what your maximum fat oxidation is

## VO2 max testing continued: measuring instruments, testing protocols, and advanced insights gained from elite athletes [41:45]

**Olav is working with the edge cases, and one thing we have to consider when we do gas exchange measurements is to understand substrate metabolism**

- There are 2 devices he likes to use
- 1 – [Jaeger Oxycon-Pro](https://www.ntnu.edu/documents/221360533/221362168/oxypro.pdf/91b256f4-97d7-4408-8eec-53869132a03d) with a mixing chamber
  - He doesn’t use the Vyntus CPX, which is the successor of the Jaeger Oxycon-Pro
- 2 – [AEI MOXUS](https://aeitechnologies.com/moxus-modular-metabolic-system/)
- He also uses the [VO2 Master](https://vo2master.com/) more and more
  - He has been working with them and has the CO2 version as well, but it is in alpha-mode and requires completely different skills than what you would normally require
- The vVO2 max is a little bit different when you are out cycling as compared to in the laboratory

> “*We have to remember that VO2 max is … the highest oxygen consumption as they normalized over one minute. That is a result [of] how much muscles that are involved in the work there. So, obviously, modality will influence this quite a bit as well.*”‒ Olav Aleksander Bu

- This is why Peter was surprised when Olav said the guys [Kristian and Gustav] were lower in swimming than cycling and running
  - He realizes that their efficiency in swimming is relative to the world’s best less than it is in cycling and running (where they would be closer to the world’s elite)
  - But he thought that more muscles would’ve meant higher O2 consumption
- When Olav started working with Kristian and Gustav, that was true (their VO2 max was lower in swimming)
- Today, there is virtually no difference between swimming, cycling, and running

**You can manipulate your VO****2** **max with targeted training**

- Training with shorter duration efforts where you learn to recruit more muscle fibers, fibers that you’re not usually using so much

Olav explains about VO2 max, “*This is also something that is highly plastic, much more plastic than we ever have thought it was before*.”

*Interesting changes in Kristian and Gustav’s VO**2* *max when training switched from Olympic distance to Ironman distance*

- For decades in Norway, leading VO2 max researchers have [measured](https://pubmed.ncbi.nlm.nih.gov/16181253/) VO2 max on students in schools
- When Olav switched [Kristian and Gustav from training for the] Tokyo Olympics to the Ironman, they saw a decline in VO2 max
- Initially, they thought something had to be wrong
- For Olav, this was not unexpected
- Kristian’s measurements in absolute terms exceeded 7.7, 7.8 L/min oxygen uptake
  - At the time he was around 80 kg
  - Let’s say around 100 mL/min/kg oxygen uptake
- Gustav is a little bit smaller so he has a lower oxygen uptake than Kristin, he clocked in around 94 mL/min/kg
- These guys have the highest numbers ever measured

Peter replies, “*It doesn’t really compute that they could utilize that much oxygen.*”

- This is something that they reproduced over 3 months

Peter asks, “*But the training at that time was presumably geared specifically towards VO**2* *maximization. It was short distance, it was interval-based.*”

- Yes, it was

> “*VO2 max is the single best metric we probably have for anything that is related to human health and performance. But it is also where we understand that it’s a little bit more nuance than that.*”‒ Olav Aleksander Bu

- Olav is not talking about it as a predictor for your race performance because that’s a different domain

**Nuance of understanding VO****2** **max**

- You could also say that you could be healthier with a little bit lower VO2 max
  - Olav is not talking about the stress you put yourself through, where this becomes a negative in the longer term
- VO2 max is a one-dimensional unit
  - We talk about something on the Y-axis and normalize it as a mL/min
- You could say it has a second axis to it, an X-axis or **time-axis**
- But we don’t say how long, over what duration ‒ we don’t get into **capacity**

Olav explains, “*I would say that the very, very best predictor is capacity. Capacity is maybe the single best one for everything*.”

- But the problem is that testing for capacity is such a brute force endeavor that it’s not really practical
- And that’s why VO2 max is the single best predictor of everything measured in a practical way

**Working with Kristin, they are at the edge of research, where there are things that we don’t understand**

- Olav works in the applied world, and that means much more experimentation and understanding of what happens with some individuals
- His sample size doesn’t come from the population, it comes from the sheer amount of data that he gathers
  - It’s not a single VO2 max test, it’s so many VO2 max tests that there’s probably no other human in history who has undergone this many tests that we can correlate it to
  - He also has a range of other metrics to put this in context
- When Olav normally does testing, not only does he have Kristian in the lab, he has a minimum of 1-2 other athletes in the lab as well
- His protocols are quite extensive

*Olav discussed earlier how protocols can have an influence on testing*

- What you do before the protocol will have an influence on your VO2 max, and that’s why he discussed if you should warm up

***Yes, you should warm up because it will normally give you a better result***

- Olav normally ***does the VO******2*** ***max measurements at the end of the test*** because it normally simulates what they’re going to see racing
  - Normally what happens in a race is that you will go closer to complete exhaustion when you get towards the end of the race, and that’s why it’s interesting to test there
- He doesn’t just test VO2 max once, he repeats it

***He will do 2 or 3 VO******2*** ***max tests, 10 minutes apart***

*What Olav sees with multiple tests*

- You normally don’t get your highest VO2 max on the first test, even though you’re exhausted
- Even on that second test, you may intuitively think you might see higher carbon dioxide production
  - You don’t, it’s actually lower
  - Call it “**priming effects**”

## The influence of supplements like beetroot concentrate and adaptogens on VO2 max and performance [49:45]

**Olav sees that some substrates have an influence and some micronutrients can boost your VO****2** **max**

- Such as beetroot concentrate [discussed in this [newsletter](https://peterattiamd.com/nitrates-athletic-performance/)]
- The main thinking behind this is that beetroot is rich in [nitrate](https://en.wikipedia.org/wiki/Nitrate) and the body converts this to [nitric oxide](https://en.wikipedia.org/wiki/Nitric_oxide#Biological_functions), and this helps for [vasodilation](https://en.wikipedia.org/wiki/Vasodilation)
- Think of vasodilation almost like plumbing in our body
- In the [previous conversation](https://peterattiamd.com/olavaleksanderbu/#:~:text=doing%20longer%20intervals-,Physiological%20limitations%20on%20VO2%20max%20%5B2%3A02%3A15%5D,-To%20bring%20the), they said that cellular respiration is not the limitation to your VO2 max
- This means that the ability of your cardiovascular system to transport blood around your body is going to be important

***Beetroot concentrate being highly enriched in nitrates give you a nitric oxide boost that’s opening up the plumbing and allows your blood to circulate faster throughout your body***

- This is hard to reproduce in elite athletes
- In amateur athletes, we normally see this having a positive effect

Peter asks, “*How much of an effect? 5%, something measurable?*”

- Something like that ‒ take it with a grain of salt

Peter asks, “*Would it be anything that increases nitric oxide?*”

- Olav doesn’t see this effect in elite athletes
- One of the benefits of being able to do more longitudinal studies with granularity and in-depth measurements (as Olav does) is that when you do all these measurements you leave out the guesswork

***In all this testing, he doesn’t see a real effect [of beetroot concentrate] on VO******2*** ***max; maybe it has an effect in other places***

- Maybe it’s because the athletes have already optimized VO2 max
- Maybe there are other limiting factors instead

**Olav’s work with the company** [**PLASMAIDE**](https://plasmaide.com/)

- There is a cost to converting nitrate to nitric oxide
- From pine bark extracts, [PLASMAIDE](https://plasmaide.com/pages/frequently-asked-questions) made extracted an **adaptogen** that helps catalyze this process
- Olav is in a place where he can make repeated observations over time, and he can’t necessarily explain it yet, it’s more of a speculation
- Initially, he thought why should this make a difference (since they’ve tested nitrate and it didn’t help)
- Kristian and Gustav were quite positive about testing this

***Gustav was the first one to say immediately that he felt it did something with his respiration***

- Olav wondered how much of this was the [placebo effect](https://en.wikipedia.org/wiki/Placebo) and how much was real

***Kristian showed a little bit of a different effect: he felt ready for the next effort more quickly***

*The measurements they did were a little bit of a shock to Olav*

***They saw that the biochemical efficiency in the body went down***

- The [RQ](https://en.wikipedia.org/wiki/Respiratory_quotient) on the CO2 side was slightly reduced and the VO2 was heavily increased

## How respiratory quotient (RQ) reflects metabolic shifts during exercise, the challenges in measuring and interpreting RQ in elite athletes, and the physiological adaptations needed for prolonged endurance events [53:30]

**Tell folks what RQ is and what the reduction would imply**

- Normally, one of the criteria for a VO2 max test to be valid is that the RQ should be 1.1
  - [[RQ](https://en.wikipedia.org/wiki/Respiratory_quotient#Calculation) = CO2 eliminated/O2 consumed]
  - You should have 10% more production of CO2 than consumption of oxygen
- In elite athletes, sometimes bringing them up to 1.1 during the test is quite challenging
  - If you have a short warm-up protocol, they’re not warmed up very well, and then you would easily exceed this
  - But if you do it in a simulation like Olav did or have longer protocols before [testing], you normally see that this is a little bit suppressed
- For example, at the end of a VO2 max effort, Kristian will click in at 1.05

***Then after he started using these supplements, he dropped by 10 points (to 0.95)***

Peter asks, “*Preserving the VO**2**?*”

- The CO2 was basically unchanged, but the VO2 went up quite a bit

**Olav compared this to 2 other athletes in the lab at the same time**

- One athlete comes in before Kristian to do dynamic calibration of the machines
- They also use a lung simulator, just because they’re working with edge cases and want to independently validate the machines
  - This means that beyond what is used for calibration, they use a large gas tank with a reference gas
  - They have a separate system where a lung simulator will feed in for example 6 L of oxygen, 6 L of CO2
  - And they know the exact amount in the bottle (gravimetrically calibrated)
  - And if they don’t get this out of the machine then there’s something wrong with the machine independent of the calibration

***The good thing here is that the numbers were where you would expect them to be based on the training they did before***

- When Kristin came in, they started to see some numbers that are crazy and Olav wondered if he did something wrong in the calibration process
- When he validated it afterwards, he knew the numbers were good
- He measured this in December, January, and February over 9 tests

***Over time they saw that his VO******2*** ***max started to come down a little bit, and this indicated that this biochemical efficiency was not optimal***

- If you look at his oxygen consumption versus power, the power was higher but the ratio was not the same as it was before

***VO******2*** ***had gone up much more than the power, suggesting that efficiency is going down***

**Olav tries to understand this**

- These tests are using a temperature pill up their ass, and they also use multiple [CORE sensors](https://corebodytemp.com/collections/products/products/core) around the body to measure body temperature
- They basically see the same thing

***They see an increased heat production for the same power output***

*Indirect calorimetry is a measure of gas exchanges*

- [Eric Ravussin discussed indirect calorimetry in episode [#324](https://peterattiamd.com/ericravussin/)]
- Peter reasons, “*It’s not useful oxygen… Now you’ve created a scenario where for the same amount of power you need more oxygen (oxygen is free), you’re going to need more glucose*.”
- Olav explains that it’s not more glucose; the RQ here is in favor and you are actually able to oxidize more fats

***Peter’s summary: the RQ came in the same and you’re going to hold carbohydrate metabolism constant and increase fat oxidation***

Peter asks, “*And that works out perfectly in the stoichiometry?*”

- Pretty close
- Peter thinks this is counterintuitive
- Olav points out the difficulty with this is that if you look purely at the RQ, where the threshold sits, you’ll find several places in the research literature where they **use an RQ of 0.96 as a proxy for your anaerobic threshold**
- But if you train an athlete for **sprinting**, you will see they have an RQ that is higher than 0.96
- Extreme **endurance** athletes can get closer to 0.94, 93, 92
- The implication of this is that if you measure the lactate threshold, you’ll come into a zone where you will get a higher lactate concentration in the body, and if you take that lactate concentration and calculate the volume of lactate available in the body, ***you’ll see the volume of lactate now becomes a significant contributor to energy production***

Peter asks, “*But you have to know plasma volume pretty well to make that calculation, right?*”

- Yes
- Olav has a machine for measuring carbon monoxide, a rebreather
- He does regular testing of their blood volume, plasma volume, and hemoglobin mass
- The gold standard is probably [doubly labeled water](https://en.wikipedia.org/wiki/Doubly_labeled_water), and he’s done this as well

*For example*

- If you consider normal lactate levels, let’s say we take it into volumes that would mean the energy contribution from lactate could be 5
- If you stay there long enough, you’re now talking bout 13, 14% energy contribution from lactate
- The problem with this is that all the tables we have today which use RQ to say something about the ratio [of substrate utilization] between carbohydrates and fats
  - Normally you say it’s good up to a [RER](https://en.wikipedia.org/wiki/Respiratory_quotient#Respiratory_exchange_ratio) of 1.0, but above 1.0, we don’t do it anymore
    - Lactate and other things become too large a contributor

***This tells us to be cautious when we look at RQ, and the table is a crude estimate of the amount of fat metabolism and carbohydrate metabolism [when thinking about endurance and elite athletes]***

Peter asks, “*Do you feel we can do that safely up to 1.0?*”

- No
- If you’re an endurance athlete, Olav would start to be skeptical around the low 90s

**What** [**RQ**](https://en.wikipedia.org/wiki/Respiratory_quotient) **are you typically seeing for maximum fat oxidation?**

- Peter points out that the % of fat oxidation is low

*What do you see in absolute grams per minute for max fat oxidation in an elite athlete who’s on a high carb diet?*

- It’s been a long time since Olav paid attention to that
- Peter could imagine that corresponds very closely to their race pace
- No, it gets a little more complicated
- Olav does isotope tracing of substrates and has used [carbon-13](https://en.wikipedia.org/wiki/Carbon-13) a lot
  - He adds that as a tracer to glucose and fructose to look at how much of the carbohydrates ingested are you able to utilize
  - To distinguish what is ingested from your own glycogen and your own fatty acid
- With Kristian or Gustav this is a little less valuable
- If you tested them just before a race using the protocol discussed
  - Had them warm-up, do a short effort to make sure the body is ready, did hydrated exercise to test VO2 max
  - Then went out and did the race
- Then test again the moment  they come over the finish line (or even half an hour afterwards)

***You will see that the fuel utilization from the beginning of the race to the end of the race has completely changed (significantly changed)***

**For elite athletes**

- What got them onto this tangent was when Olav said, “*At the most elite level, their race pace is above 90% of their VO**2* *max*.”
- This is true for elite marathoners and Kristian and Gustav when they do Ironman racing

Peter adds, “*This is just impossible for me to wrap my head around. This means that someone whose VO**2* *max is 5 L/min (if they’re elite which means they’re obviously pretty light), they’re going to spend an entire Ironman at 4.5 L/min.*”

- Olav explains that what will happen is their VO2 max will come down (it’s declining)
- This has to do with priority and training

***The consequence of aiming for Ironman is you want to have minimal decline in this, and you need a lower VO******2*** ***max***

> “*You can’t prioritize having a high 1-minute power or 5-minute power simply because it’s too far away from the specificity of what you really need there.*”‒ Olav Aleksander Bu

- If you start building sessions where you are looking to increase your 1-minute power or 5-minute power, that’s going to have a cost for the whole week of training

## Triathlon training: the challenge of maintaining elite performance across triathlon distances, metabolic efficiency, and swimming challenges [1:03:15]

- Athletes like Kristian or Gustav want to be able to go between 3 distances: Olympic distance, Half Ironman, and Ironman
- **Olympic distance**: 1.5 km swim, 40 km bike, and 10 km run
  - Elite athletes are doing this in 1 hour 45-ish
- **Ironman distance**: 2.4 mile (3.8K) swim, 112 miles (180K) bike, and marathon run (26.2 miles or 42K)
  - [Kristian](https://en.wikipedia.org/wiki/Kristian_Blummenfelt) is still the record holder with a time of 7:21 (7.5-8 hours)
- **Half Ironman**: <2K swim, 90K bike, and call it 21K run
  - Roughly twice the Olympic distance in some regards, less in others
  - They’re doing this in 3.5 hours

**These are 3 different events. Is it possible to be elite in all of them?**

- One of the main differences in them as compared to specialists in sports is actually *not* their metabolism
- If you look at their VO2 max on running, cycling, and swimming, they are equal or higher than their peers in those sports but their efficiency is not the same
- This probably comes down to the fact that they have to do 3 different sports
  - You don’t get the same time of pure mechanical stimulus from doing something and optimizing it because you have to change
  - Priorities to consider: in running you don’t want to compromise on your leg stiffness whereas in cycling it is a little more beneficial to do this
  - You have to strike a balance between all 3 which makes it complex
- In swimming they have a higher VO2 max than the highest Olav has measured in elite swimmers (he measured the bronze medalist)
  - But their efficiency is so poor it’s actually funny
- Olav had one of the best swimmers in the world in the flume [an endless pool, stationary swimming pool] and tested him
  - A bug guy, 195, 100 kg; muscles all over
  - Kristian went into the flume at basically the same velocity
  - In an endless pool, people often think of it as a countercurrent, but it’s a lot of turbulence
    - It’s a big canal which is circulating water on the outside and it comes back in the front
    - It truly replicates swimming stationary
    - It’s the closest thing we have to an aero tunnel for swimming
- When you look at these 2 guys swimming at the same speed
  - Kristian is 80 kg
  - The lead swimmer is close to 100 kg, he’s lean and well-trained
    - All things equal, he should have a higher VO2 because he’s supporting much more muscle
    - But he’s utilizing 25% less oxygen than Kristian (in absolute terms, on a relative basis it’s ⅓ less oxygen)

## How reducing drag in swimming could revolutionize performance and the role of biofeedback tools in optimizing efficiency across various endurance sports [1:07:00]

**Peter’s thesis on swimming**

- Of the 3 big endurance sports, he feels like swimming has the most potential for radical change in performance, based on **drag avoidance**
  - Swimming and cycling in particular come down to propulsion versus drag
  - Running is less so because these speeds aren’t high enough relative to air
- Swimming is so much slower than running, but the density of water is 1300x that of air [[Wikipedia](https://en.wikipedia.org/wiki/Density_of_air) says is 800x] so you don’t need a high v2 to get a lot of drag just based on the density of the medium (water)
- In cycling and swimming, it really comes down to this ability to avoid drag
- That’s why a time trial position matters so much on a bike, and how can you generate power if you have to compromise your power there?

***In swimming there could be a massive breakthrough if a technique emerged that reduced forward propulsion by 10% but reduced drag by 20%***

- Remember this happened in cycling in the ‘80s
  - Prior to this nobody was paying attention to bike position
  - Then [Francesco Moser](https://en.wikipedia.org/wiki/Francesco_Moser) comes along in 1984 and smashes the 1-hour with all this crazy aero equipment
  - [Boardman](https://en.wikipedia.org/wiki/Chris_Boardman) and all these guys got more and more crazy aero positions where their power went down relative to what they could have been in a less kinked position
    - [one of his bikes is shown in the figure below]

But their speed went up because the [CdA](https://www.omnicalculator.com/physics/drag-equation#:~:text=The%20equation%20is,u%C2%B2%20%C3%97%20A%20%C3%97%20Cd) went down

![](https://peterattiamd.com/wp-content/uploads/2025/01/f3-olav2-1024x684.jpg)

**Figure 3. Crazy aero position of Boardman’s bike**. Image credit: [Paul Hudson from UK Design Museum](https://en.wikipedia.org/wiki/Chris_Boardman)

**Do you ever think about that in swimming, where some dramatic change in technique could have a bigger positive impact on frontal surface area than the negative effect it might have on propulsion?**

*This touches on one of Olav’s favorite areas: biofeedback*

- In cycling we have extremely good tools for biofeedback today: a **power meter** and a **GPS**
  - These 2 monitor speed and power perfectly
- Like they talked about [last time](https://peterattiamd.com/olavaleksanderbu/#:~:text=And%20each%20week%20we%20would%20see%20if%20we%20could%20get%20faster%20and%20faster%20while%20keeping%20the%20wattage%20at%20200) when Peter was training constantly at 200 watts and seeing himself get faster
- Olav explains that as you ride enough, you will get a good feeling for when you sit at a certain power
  - You will start to do different things to creep up in power by 0.5-1.0 kph
  - For people who do a lot of biking, this is where you start to pay attention
- Over time other factors make a difference, like wind

**Running is also a place where we have really good biofeedback tools: your watch, power meters**

- Some power meters in running today use an **insole** that measures the forces
- There are other ones that are more **motion capture devices** [such as [Stryd](https://blog.stryd.com/2024/10/08/a-closer-look-stryd-footpath-available-on-next-gen-stryd/)]
  - You input your body weight
  - When you’re touching the ground with 1 foot, you’re basically carrying your whole weight there
  - As long as you have a good enough motion capture device capable of capturing 3D accelerations, you can calculate the [force](https://en.wikipedia.org/wiki/Force) because you have to carry your weight [F=*m*a]
  - Motion captures are basically a small device that you attach to a shoe
- Both types of devices are commercially available
- Olav has been working for a long time with [Stryd](https://www.stryd.com/us/en) (since they were in the beta stage), and they are accurate

*Peter’s wife is running the Boston Marathon next year*

- After this podcast, he’s going to be on the computer ordering one of these devices, jamming them on her shoes
- He’s convinced she’s going to run it faster than she did the first time, 20 years ago because now she works with a running coach
- Her qualifying time this year was only 1 minute slower than it was 19 years earlier
- She’s more structured in her training
- She’s finally agreed to using heart rate and velocity for tempo training
- She’s not listening to the podcast, but he’s going to implement power training for her running
  - Even though she doesn’t want data

**How is every runner not doing this?**

- Olav thinks a lot of it has to do with tradition
- When power meters were introduced, it’s easy to look back and say, “*Why didn’t we have this before?*”

***There is so much information we can extract from a single power meter today ‒ it’s beyond people’s comprehension***

- Still, we only use the **power number** and we use it in a 1-dimensional context: **FTP** [functional threshold power] orcritical power
  - Olav isn’t going to talk about this today ‒ the amount of information you get out of it is crazy

**Do you still use normalized power?**

- No, Olav only goes by raw numbers (all the time)
- He doesn’t condense it down to a single metric
- The implication here is that even when you look at studies that only look at gross efficiency, one thing to consider is net mechanical power
  - [Discussed in the [previous episode](https://peterattiamd.com/olavaleksanderbu/#:~:text=A%20power%20meter%20on%20a%20bike%20(like%20the%20SRM)%20only%20measures%20net%20mechanical%20power) with Olav: a power meter on a bike measures **net mechanical power** or only the component of power used to move the crank arm]
    - [Not all of the energy is going into moving the crank arm of the bike, there is basal metabolism, heat production, other movements; and **gross mechanical power** considers everything]
    - [For elites, there is 20% efficiency]
- If you think about VO2, most people understand there’s a difference between net oxygen consumption and gross oxygen consumption
  - Ideally you would like to have net oxygen consumption [oxygen consumption used toward forward propulsion]

***In cycling, we only consider net mechanical power, you don’t consider gross mechanical power on your biochemical efficiency***

Olav cautions, “*You should not look at the net mechanical power. You should look at the gross mechanical power.*”

- We can extract from power meters: power vectors, force vectors, and other things in a 3D plane

**Reasons why power meters are not as widely adopted in running as it is in cycling**

- Peter points out, “*When running, you have more degrees of freedom, there’s more inefficiency, there’s probably a lower relationship, a more strained relationship between gross and net power.*”
- Olav adds questions still debated: What is running power? How do you quantify it?
- This is something Olav discussed with the team at [Stryd](https://www.stryd.com/us/en)

***If you want to translate this to running, then you have to look at only the propulsive power***

**Have they put these in Olympic sprinters (power numbers)?**

- No
- Commercially this has limitations: since you capture motion, you need to do a little bit of filtering
  - There’s a lot of noise because there are so many degrees of freedom

**If you had that force plate chip in their insole, you could at least capture force normalized to weight with each step, right?**

- Yes
- For example, if you run on a track or a specialized treadmill that has force plates integrated in it, you will see that the curves are the same
  - This is how they say it is externally validated in terms of the force curves it captures
  - And when you have motion capture devices, it can capture the footpath as well
- This is something we can visualize in 3D today after the running event
  - We can see what happened when the athlete was fresh, fatigued, throughout the race

***The reason why this is not widely adopted is because the science is still debated on how to capture and quantify the mechanical power for running***

- [Stryd](https://www.stryd.com/us/en) has taken a smart approach: they made it commercially available, and the output is **metabolic power**
- If you went on a treadmill and looked at it versus oxygen consumption, you would see that it matches perfectly with cycling
  - You could use this to predict the metabolic cost you would expect for a certain power

> “*I don’t like it because I don’t like modeled numbers. I want to have raw numbers… because I’m using it as an interface to gauge the difference*.”‒ Olav Aleksander Bu

- He has the VO2 Master and metabolic devices ‒ he doesn’t need a metabolic equivalent

*Comparison to a Formula One car*

- What really matters in the end: how fast you go around the tract for the full vent with a certain amount of fuel
- There is a limitation to how much fuel you can have in your car
- That’s the true input and the true output
- Your engine is actually secondary
  - A big engine without efficiency is still bad
- The engine becomes more of a device to measure: to look at power and efficiency of how you are able to translate fuel into speed (or velocity) over the event

**Having access to net mechanical power and gross mechanical power, and also having metabolic devices ‒ these allow Olav to have a more granular understanding when you change something**

- For example, when you change your shoes or change your training ‒ are you influencing the biomechanical or biochemical part of the training?
- To understand this, you need that interface that distinguishes between gross mechanical power and net mechanical power
  - To understand **work efficiency**: how efficiently are you working but not metabolizing or moving

***In the end you have to take this power and be able to output into velocity***

**For example, if you had 10 different cyclists**

- You did a VO2 max test on all of them, got a number, and normalized it to weight
- If you line them up from lowest to highest in mL/min/kg
- And then look at what power they were at when they achieved that VO2 max, and then normalize that to weight to watts/kg

*Peter thinks it’s not going to be a one-to-one match*

- Olav points out that when you are close to VO2 max, then it’s getting close to a one-to-one match
- But it doesn’t at a submaximal effort
- A submaximal you will normally see in running simply because it’s a weight-bearing sport

***In running and cycling at maximal effort, Olav has observed that the VO******2*** ***max is pretty much the same***

- There’s probably a lot of anaerobic contribution in there, and that supplies the gap you are observing

Peter asks, “*You’re saying I’m anaerobically not trained enough… I’m too aerobic and not anaerobic enough?*”

- Yeah

**For Kristian and Gustav**

- Being older, we are trying to keep executive training as balanced as possible between the 3 sports

***There you will see that at maximal efforts (VO******2*** ***max) the mechanical power is pretty much the same, but as you go at submaximal effort, that’s where you start to observe the big differences [in different sports]***

- In cycling, as you go from 15 to 16 kilometers of power to 17, 18, 19, 20 and so on ‒ this is observable from a metabolic cart
- When you go at low intensity, you will see that oxygen consumption is higher than the perceived lower intensity in running than it is in cycling because cycling is not weight-bearing
- In cycling, it’s easy to go down to a very low intensity and still keep a normal cadence (of 80, 90), and it feels comfortable
- Going down to those cadences in running is impractical because it means walking, and you’re not running anymore
  - That modality is changing more in running of what kinds of muscles are involved
  - It’s changed more in running than it is in cycling

**Back to the original question of why tracking power isn’t utilized more in running**

- It is gradually getting more and more attention
- A common standard for the output has yet to be determined

## How endurance athletes prioritize effort regulation using RPE, heart rate, and power output, and the role of lactate in cardiac and athletic efficiency [1:20:00]

**In cycling, when guys are doing a 4-hour ride in an Ironman, how are they prioritizing how they feel, heart rate, and power?**

*How are they regulating effort based on those things in a race?*

- Many more sensors are used in training than in racing, simply because it’s not practical for racing
- This is an interesting topic because it touches on psychology (a discussion for another time)
- Ironman racing is so long, and with all this practice, you shouldn’t be a slave to the numbers because you can suddenly have your hero day where you are able to go faster than what you normally do

***You need to listen to your body***

- Olav thinks [RPE](https://en.wikipedia.org/wiki/Rating_of_perceived_exertion) is the most important

*RPE is a place where you can talk about 2 dimensions*

- If you take [Kipchoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge), when he did a sub-2-hour marathon, and if you put him on a treadmill and did a normal step test on him
- For the sake of discussion, we’ll say his anaerobic threshold is around
- If you relate this to FTP (something a well-trained athlete would be able to hold for an hour, or what you would test for when you did a 20-min protocol and then you subtract the 5% to extrapolate it to that)
- When he is running 21 km/hr, if you asked him, “*How does this feel?*”
- He may give you an RPE score of 6
- If you ask him at the end of a marathon, when he’s still running the same pace
- He may say an RPC score of 9-10

***We forget that duration is another dimension ‒ that’s the fatigue component***

- Peter points out that his heart rate might be different there too
- This brings us back to **utilization**, because one of the things you probably would not be able to do at the end of a race is get yourself up to a maximum heart rate

*You may also wonder how it is possible to ride at 4.5 L when you have a 5 L VO**2* *max*

- This is key in an endurance sport: you want to increase this robustness
- You are tuning this so that where you start and end becomes far less [different]

**The problem with having a higher VO****2** **max coming into the race**

- The heart is a muscle and it’s not very efficient, it has significant energy consumption
- If your heart is trained for something different than what you need, it means your heart is going to use energy more inefficiently

Peter asks, “*How much lactate does the heart generate?*”

- Olav has never done any research on that
- He thinks about when we break the body down into components and look at energy consumption

Peter asks, “*What’s the mitochondrial density of cardiac muscle versus skeletal muscle? I mean, they’re both similar in some ways, they’re striated muscles.*”

- Olav’s intuition would be that it has to be very rich in mitochondria
- That’s also why the heart uses lactate as a fuel source
- He’s never done a muscle biopsy on the heart, but it would be interesting to see the ratio between type I and type II fibers
  - He would imagine it’s as close as possible to [type I fiber](https://en.wikipedia.org/wiki/Skeletal_muscle#Fiber_types:~:text=Properties-,Type%C2%A0I%20fibers,-Type%C2%A0IIA%20fibers)
- Peter learned recently in the [podcast with George Brooks](https://peterattiamd.com/georgebrooks/) that we can actually shuttle lactate into the mitochondria for [oxidative phosphorylation](https://en.wikipedia.org/wiki/Oxidative_phosphorylation)
  - That would explain why the heart could richly use lactate
  - Olav agrees and adds that it also comes down to the [Michaelis constant](https://en.wikipedia.org/wiki/Michaelis%E2%80%93Menten_kinetics#:~:text=given%20enzyme%20concentration.-,The%20Michaelis%20constant,m,-is%20defined%20as), where you look at the affinity for different substrates and for different muscles as well
  - And where lactate has the highest affinity for most of these muscles, especially the heart

**Olav does applied research and often they can’t use a lot of the research that is out their as a basis for their decisions**

- [Monocarboxylate transporters](https://en.wikipedia.org/wiki/Monocarboxylate_transporter) is one example of a place where if you want to understand something, you can go in and do a concentration measurement

***The problem with research is that very often we get a partial view of something and it’s not complete, and that means that most of the time for us to understand what really works (and doesn’t work), we have to work with raw numbers***

**We use calorimetry to understand what kind of substrates are being utilized**

- We can use isotope traces to dig into this
- We can talk about creating [lactate](https://en.wikipedia.org/wiki/Lactic_acid#Metabolism_and_exercise) as an artificial fuel in the same way that you create supplements based on fructose and glucose (or [ketones or beta-hydroxybutyrate](https://en.wikipedia.org/wiki/Ketone_bodies#:~:text=acid%20(acetoacetate)%2C-,beta%2Dhydroxybutyrate,-%2C%20and%20acetone%2C%20a))

## Lactate’s role as a fuel, buffering methods to combat lactic acidosis, and the variability in athlete response to bicarbonate supplementation [1:25:45]

***Lactate is very interesting because it is extremely energy efficient, and that in the end is a limitation for elite athletes***

**How difficult is it to deliver lactate orally? (Peter assumes it’s delivered in a salt)**

- As a salt it has a some of the same effects as [bicarbonate](https://en.wikipedia.org/wiki/Bicarbonate): you could use it as a buffer

*Let’s make sure folks understand the chemistry there*

- People say to Peter all the time, “*As my workload increases, my production of lactate increases, and as my production of lactate increases, my capacity starts to fall off because as lactate goes up… it’s married to a* [*hydrogen ion*](https://en.wikipedia.org/wiki/Acid#:~:text=(i.e.-,hydrogen%20ion%2C%20H%2B,-)%2C%20known%20as%20a)*, and that’s what creates the acid part of lactic acid*”

***Peter explains that the hydrogen ion is causing all the trouble, not the lactate ‒ we can tolerate endless amounts of lactate***

- Lactate is crucial in metabolism
- We just can tolerate the hydrogen [H+] that comes with it
- The hydrogen ion is what paralyzes [actin myosin filaments](https://en.wikipedia.org/wiki/Skeletal_muscle#:~:text=The%20myofibrils%20are%20composed%20of%20actin%20and%20myosin%20filaments), prevents them from disengaging, and that’s was leads to that seizing up that you feel (rigidity) when you exceed your lactate threshold

**The question becomes, can I buffer this [lactate]?**

- Everybody talks about taking Tums, anything to get sodium bicarbonate into our system
  - This strategy didn’t really pan out

Peter asks, “*What is the state of buffering agents to reduce and lessen the impact of lactic acidosis?*”

- This is complicated
- Olav has been fortunate to be involved in a lot of edge-case research over the last decade
  - Plenty that are years away from being published, simply because more work is needed to understand it
- Gustav’s highest VO2 max was done under bicarbonate utilization
- There’s a company in Sweden called [Maurten](https://www.maurten.com/products/bicarb-system), and why they did was create a **hydrogel** that allows you to bypass the gastric pH and get the bicarbonate into the intestine
  - Using the same mechanism as medicine
  - You can pack an agent into a vehicle to deliver it where you need it to go more efficiently
- This allows us to get concentrations [of bicarbonate] that are significant

**What difference have you seen in Gustav’s lactate tolerance with and without this buffering?**

- This is where the sample size is still limited
- Here Olav has 2 different cases ‒ some athletes have almost twice as high a lactate concentration when they’re using this
- Gustav can comfortably eat 160 g of carbohydrates per hour and he utilizes it (it’s doesn’t start packing up in the stomach)
  - Olav has quantified this using isotope traces
  - (we’ll come back to the topic of nutrition)

*Gustav seems to find a huge benefit from it, but it sounds like Kristian does not*

- It depends on the setting
- A triathlon is inherently complex in the sense that you have 3 sports that you put together, and with varying intensity

***The benefits: it increases your plasma volume fairly instantaneously (you’re pulling fluids into the plasma)***

- Early studies [unpublished] show there’s a positive effect of using bicarbonate (the [Maurten product](https://www.maurten.com/products/bicarb-system))
- We don’t fully understand why this is
- One hypothesis is that it increases the buffering capacity
  - The thought is that you can do more anaerobically; we’re fairly sure that you’ll  never run out of glycogen
  - When your body starts to sense that glycogen is really, really low, you’ll shut down

Peter asks, “*Is that easy to verify with a muscle biopsy at failure?*”

- No, the problem with that is that even in muscle biopsies, sampling across one muscle is so heterogenic
- You would need to biopsy multiple sites simultaneously, or make somebody radioactive and do nuclear resonance measurements
- It’s so impractical to study

***You have to go more by 1st-order principles: looking at gross efficiency and calculating how much substance you’re using***

- Already there are inaccuracies to it
- That’s why sometimes you say, “*Okay, we are going to look at oxygen consumption versus let’s say mechanical power output.*”
  - You don’t care whether the RQ correlates to this value
  - You just have to have the raw values

**Back to bicarbonate**

- Doing blood gas analysis, we can observe pH when athletes are exercising during a longer protocol
- Interestingly, Kristian does not double his lactate concentration
  - Kristin has almost unchanged lactate concentration in his blood even when he’s going all-out (at any given power)
- It’s easy to think that when an athlete has double the lactate concentration in his blood that there has to be double the contribution from glycolysis

***We have to remember that we measure in the blood: this is a concentration metric and the state can be completely different in other places in the body***

## The physiological mechanisms behind differences in performance between two elite athletes: lactate transport, cardiovascular efficiency, and compensatory systems [1:33:00]

Peter’s crazy idea, “*Have you ever done a muscle biopsy on the two of them to see the relative differences in monocarboxylate transport density on their muscles?*”

- No
- Peter explains that the MCT transporter on the muscle cell must play a significant role in determining the relationship between intracellular lactate and intra-plasma lactate
- It would be in an athlete’s best interest to increase the density of those (through training), because the more you can get lactate out of the cell, the more, presumably, you’re going to get the hydrogen [H+] with it out of the cell
- We probably have a greater capacity to buffer acid in the plasma (because we have the respiratory drive to adjust bicarb) than we do in the cell where that hydrogen is really poisonous

***This makes Peter wonder as a hypothesis if maybe Kristian has more MCT density and that’s why he is less impacted by this buffering strategy***

- It could be the other way around
- It’s just so hard to believe that 2 world-class athletes could be that different in their response
- Olav doubts it would be significant
- If he looks purely at the **biochemical efficiency** (1st-order principle), looking at oxygen [utilization] versus mechanical power output, this is so close that it can’t explain it alone

**One other difference: the blood volume in Kristin and Gustav is a significant difference**

- You can then ask if that would have implication on: VO2 max, stroke volume, and cardiac output
- If you talk about stroke volume, there is a massive difference, but not in cardiac output

Peter asks, “*What’s the max heart rate of each?*”

- Kristian is around 170, 180
- Gustav is around 200
- What’s more interesting is that Kristin has a much larger hemoglobin mass than Gustav
- If we create a performance stream and we put VO2 max on the top, where all these different factors are contributing

> “*That’s why we say the VO2 max is the ‘holy grail’ or such a good metric because if there’s something broken somewhere in the system, it trickles up*”‒ Olav Aleksander Bu

***The biggest difference is that Gustav has to circulate his blood much more quickly than Kristian (in absolute terms); so the absolute circulation of blood (cardiac output) has to be at least the same for Gustav, but it may actually be a little bit higher***

**But Kristian compensates in other ways**

- When we talk about all these different things, whether it’s MCTs or other things in the body
- There are so many mechanisms that we see when we come closer to the elite level, other systems start to compensate to take you to the next step (that’s a high priority)
- In people that are not well-trained, you can do whatever and the body will just prioritize to develop what is the easiest to develop

## Comparing interventions like acetaminophen to enhance performance in high-heat conditions versus natural adaptations to heat [1:37:15]

- Peter knows of reasonable data suggesting that a high dose of [acetaminophen](https://en.wikipedia.org/wiki/Paracetamol) can improve heat tolerance, race-pace tolerance in warm temperatures
- Nobody know why
  - Is it reducing and blunting body temperature, and the temperature itself becomes a bit of a governing mechanism on output?
  - Is it just blunting pain, and pain is part of the wall that we face

**Do you have any experience with high doses (1-1.5 g) of acetaminophen in these athletes?**

- No, Olav doesn’t use it
- The problem when you go in and try to acutely do something in the body ‒ you’re trying to target 1 part of 1 system and don’t consider the other ones
- He believes in a more natural approach
  - Build heat tolerance into your protocols

*Pain for example, is something that is trainable*

- There are many mechanisms involved
- After the doping scandals in the Tour de France, everybody thought it would become slower
  - It did for a short period
  - Then suddenly, it became faster and faster

***Olav doesn’t think this is because more people are doping now, instead they have found techniques and other things more powerful than using performance-enhancing drugs to get to this level***

## Advancements in nutrition science, changes in cyclist body composition, and the impact of fueling strategies on athletic performance and growth [1:39:30]

**Differences in the Tour de France today**

- Olav alluded to the fact that his athletes are routinely able to consume 160 g of carbohydrate per hour on the bike during competition
- Years ago, when Peter was competing in anything, we were stuck at 60 [g of carbohydrate per hour]
  - And for ultra-distance things, it became a bit of an energetics problem
  - You had to figure out ways to get fat into what you were consuming, just to get the additional calories (even though it was glucose that you were limited by)
- Recently, Peter asked [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) how many grams of glucose he was consuming per hour in the Tour
- He said, “*We didn’t even pay attention to it. We just ate when we were hungry*.”
- This is not saying that the only reason those guys were exceptional is because they were using blood products
  - They were using blood products, they were exceptional, and they trained very hard

***Their knowledge of nutrition was very pedestrian to what it is today***

> “*If you wait till you’re hungry to start fueling, you’re not fueling in an optimal strategy at all.*”‒ Peter Attia

- 1 – To Peter, this is one enormous advantage in the Peloton today: nutrition science has evolved so much
- He’s heard rumors that these guys can put down 200 g/hr (they’ve trained up to that level)
- 2 – People forget how big cyclists were 20 years ago relative to today
- If you look at the GC contenders in the era of Lance Armstrong: Jan Ullrich, Ivan Basso, and Lance himself ‒ these guys were 70 kilos
  - At the start of the Tour Lance was 74 and he finished at 72
  - These are normal-sized human beings
- If you look at GC contenders today, these guys are 58 kilos (very small)

***In cycling, if we think about it as watts per kilo, it’s not that they’ve gone up that much on watts, they’ve gone down so much on weight***

- Their absolute wattage is significantly lower than what it was 20 years ago

Peter asks, “I*‘m wondering what you think about those 2 factors that are clearly stark differences between the world’s best cyclist today and the world’s best cyclist 20 years ago as a way to bridge the gap between the use of drugs then versus not today*.”

- There are a couple of interesting topics there
- Nutrition: fuel in and speed out the other end is crucial
- It doesn’t help if you try to do something with our VO2 max and other things if you’re running out of fuel
- Olav agrees, the attention to nutrition in the Tour today is at a completely different level than it was long ago

**Another change over the last 5 years is there have become large teams**

- When they are trying to devise tools and methods, teams allow them to scale this a little bit more
- The benefit Olav has working with a couple of athletes is that they can go on a completely different level
  - They can use metabolic measurements out in the field just to see what’s happening
  - They have become very detailed on what they do
  - Even looking at meals pre- and post-exercise
  - What happens with your resting metabolic rate, because this changes throughout the day
    - To keep up the consistency over time, you need to fuel accordingly
- Coming back to the question, Olav agrees that nutrition is probably one of the main contributors to why they are racing faster today than 5, 19 years ago

**Watts per kilogram is a place where Olav feels we will see a change again**

- He thinks we will see the weight of athletes start to go up again

*Look to understand why we ended up with the training programs we have*

- It’s a very empirical approach (practical) which is often extremely good when it has enough time to evolve
- Training programs haven’t adopted strategies that use information, technology, and all the things that help us do better fueling

*Training for growth*

- In order for any growth to take place in the body, you need oxygen
- Oxygen is a proxy to understand metabolism (discussed earlier), and metabolism is a function of growth

***When you do training over time, you’re trying to signal to your body that you need more muscles to be more efficient, and if you start to limit fueling in order to drive down your weight, this will start to impair ideal growth***

Peter asks, “*Do we see this in triathletes?… How much effort do these guys put into their weight?*”

- Peter points out that cycling is an interesting sport because you don’t really get a benefit from weight reduction if you’re a time trialist
  - It’s the opposite: watts matter more than watts per kilo
- If you are in the Grand Tours (which are built around climbing), then watts per kilo is ultimately the metric
- Talking about watts/kg is interesting because as Kristian’s watts/kg have gone up with increasing his weight (he’s 80 kg)
- To convert it to FTP, it’s in the range of 400
- And if he had him do a 20-minute test, it would be something around 424
  - It’s hard to say because they don’t do FTP testing

**What would Kristian’s average power be in an Ironman for 4 hours?**

- They hold around 44-45 kph
- Aerodynamics come and and they are able to lower the number
- Staying at 360, 370 will have a big impact on energy utilization and heat production

**Coming back to the question of using supplements to mitigate pain or lower temperature ‒ we know that is not necessarily good**

- If you think about using supplements to try to lower your temperature, this is where it’s important to ask a 1st-order principle: where does that heat come from?
- It comes from mechanical power
- Peter thinks the argument of the acetaminophen literature is that the body is bumping up against a couple of set-points that are acting as governors to output: pain and temperature
  - The body does not want to let you get too hot and doesn’t want you to tolerate too much pain
  - Acetaminophen potentially blunts both of those

Peter adds, “*You’re arguing, ‘Yeah, but if part of the way it’s blunting energy output or temperature is by reducing mechanical work, gross mechanical work, then you’re going to probably pay a net mechanical work price.’”*

- Yes and also a capacity price in some regards
- Peter has no idea what the answer is and would want to test it in training
  - Alternate week with acetaminophen/without acetaminophen as a placebo test
- Because at the level Olav works with, a 1% difference matters

## Optimizing endurance performance with utilization of carbohydrates, and the potential role of ketones [1:48:00]

**Using a lot of carbohydrates**

- Let’s say you go to 160 grams [per hour]
  - Olav has measured in excess of 240 g/hr carbohydrate utilization (the highest numbers)

*Tell people what 240 g of carbohydrates looks like if it were food? How much pasta is 240 grams of carbohydrate?*

- To make it simple, fill a glass with [PURE gel](https://www.puresportsnutrition.com/collections/energy-gel-range) and drink it
  - Peter describes it as, “*disgusting energy gels and fill your 16-ounce glass there with it*”

*In what form are they consuming the carbohydrate in?*

- Normally in the form of a drink mix

*How do they get that much liquid in their body?*

- That’s part of it
- Normally they consume a minimum of 1.4 L, but say a little bit more than 2 L per hour
  - The glucose concentration is approximately 12%

Peter reacts, “*That also completely flies in the face of traditional nutrition science, which says 5 to 6% is the limit for gastric tolerability and is the sweet spot for absorption at 5 to 6%*.”

- That is optimizing for water absorption in the cell (not the primary goal here)
- Olav is trying to maximize the amount of glucose that gets into the cell

*Absorption is an interesting point, and Olav asks, “What is this research? Who is this research done on?”*

- It’s not done on trained athletes

**How long did it take you to train athletes to be able to tolerate that?**

- 12% carbohydrate concentration means 120 g of glucose per L
  - That’s twice what you’d see in an energy drink
  - And then drink 2 L of that every hour
- Peter thinks that a normal person would be puking their guts out within 2 hours

*Is this just like any other muscle where you can train yourself to exceed capacity?*

- Seems like it

> “*Seems like most things in our body is actually extremely trainable*.”‒ Olav Aleksander Bu

- This comes back to the nutrition part of training programs: training programs we have today have not seen the same change as nutrition strategies have done over the last years
- That means that the power numbers that were output 5, 10, 20 years ago may not be the limitation we are going to see
  - Especially late in races, and this is where it’s going to make a bigger difference

**How are you managing formulations**?

- Back when Peter was swimming great distances, one of the challenges he had over a 12-hour event was fatigue of the same flavor
  - After a while, sweet becomes horrible and you want something salty, but then salty becomes horrible
- [Maurten](https://www.maurten.com/products/gels) made their gels to be as neutral as possible, and because it’s formed as a hydrogel, it encapsulated the sugar inside the hydrogel
  - The perception of sweetness is much lower than of any other gels out there (slightly sweet)

Peter asks, “*This Maurten gel is a significant driver of their calories as well as the bicarb?*”

- No, there are 2 different products because Maurten has the [bicarb product](https://www.maurten.com/products/bicarb-system) encapsulated in hydrogel and also a [carbohydrate product](https://www.maurten.com/products/gels) encapsulated in hydrogel
- They also have a [drink mix](https://www.maurten.com/products/drink-mixes) which Kristian and Gustav are mainly using

Peter asks, “*The bicarb capsule, they’re swallowing a capsule while they’re on a bike drinking?*”

- This is a 3-component mixture: the hydrogel (a dry formulation in a sachet), the bicarb tablets, and water
  - You first add water to the hydrogel and mix to form the hydrogel, and then you mix in the bicarb
- 19 g of bicarb would be a standard dosage
- Even at 22 g of bicarb, it doesn’t require much training to take this

**What is the base of the carbohydrate in the brand that they seem to like?**

- Mainly fructose and glucose

*What’s the ratio?*

- It’s been some time since Olav has went through these details, let’s say 40/60

Peter asks, “*So it’s basically high-fructose corn syrup?*”

- Yeah
- The genius part of it is not the carbohydrates itself, it’s the vehicle (the packaging mechanism)

Olav explains, “*If you were consuming 60 grams per hour, spare the money and buy orange juice or even put honey inside and drink it. Where it differs itself is when you are really starting to push the limit of the concentration, but you can even train yourself today.*”

- You can even take honey and mix it, and you can train yourself to use higher values than what have previously be published [examples listed in the “selected links” section at the end of these notes]

***If you want to go to 160 g of carbohydrates per hour, this is where you need the [Maurten] technology***

**Do you need any fat, protein, or amino acids throughout that whole race?**

- No
- Olav has done research on this and ended up with pure glucose and fructose

*It has to do with how oxygen is being prioritized in the body*

- It’s easy to think that you are working at 80% of your VO2 max (or whatever %), but when we think of this as oxygen ‒ more oxygen is going to contribute to more heat
- It’s not [as simple as] you can race a % of your VO2 max, from the beginning everything will accumulate towards the end of your race
- That means from the beginning it’s critical how you **pace** yourself and your **efficiency**
- Every inefficiency you have (biochemical or anything) will end up towards the end of the race

***This means that the moment you start putting other substrates or nutrients into your mixture that the body has to prioritize somehow in the system, and there is going to be less oxygen***

- In the end it’s pure propulsion that really sets the winner apart
- You want to peel away absolutely everything that doesn’t contribute to forward propulsion

> “*Use every milliliter, every mole of oxygen purely for the purpose and nothing else because oxygen is one of the limitations*.”‒ Olav Aleksander Bu

**Different substrates other than glucose and fructose**

- This is a place where we don’t know, and Olav is doing some research

*Have you looked at* [*BHB (beta-hydroxybutyrate)*](https://en.wikipedia.org/wiki/%CE%92-Hydroxybutyric_acid)*?*

- He has and if you look purely at stoichiometry there are interesting things
- The problem is we can not only do stoichiometry: we need to know the [enthalpy](https://en.wikipedia.org/wiki/Enthalpy) and the [Gibbs free energy](https://en.wikipedia.org/wiki/Gibbs_free_energy) that is available
- Peter points out that the Gibbs free energy is much more complicated if you’re making BHB yourself

Peter asks, “*But if you take it [BHB] purely exogenously and consider it an additional substrate above and beyond glucose, do we have reason to believe that we’re going to get more ATP per mole of oxygen?*”

- No
- The practical limitation of this is that when you are racing, there is a certain amount of fuel that needs to go through the system

*In the context of glucose and fructose*

- We are trying to replace as much as possible in order not to run out of this fuel
- Glucose and fructose (carbohydrates) seem to be a very oxygen-efficient fuel source when you do movement
- This means trying to replace as much as possible to be able to race faster so you have this fuel source available
- [Work] at a certain power number, a certain duration will bring you close to depletion of this energy source
- When you think about **switching to other [energy] sources** (you’re always using other sources as well), trying to get more from that source means you have to replace more of the power

***We have to create an environment where more power can come from the same source***

- For simplicity, say at 80 g of carbohydrate you have a biochemical efficiency of 20% (for example)
- That means you’re getting out say 4.2
- Basically 1 gram would be the equivalent of 1 joule per signal or 1 watt (let’s say)
- If you double this from 80 to 160, now that means you can get double the amount [of energy] that’s coming from carbohydrates
- You don’t fuel with ketones in the same way: if you go to 70, 80, or even 100 mL of ketone consumption in an hour, you’re going to have such high levels of ketones in your body that you will start to feel almost like you are becoming diabetic (bonking)

***Ketones are more inducing a state in the body rather than actually fueling it***

- Let’s say the idea is to replace what you’re losing from your body because that’s driving your body out of homeostasis

***That would mean you would need to ingest so large an amount of ketones during a race***

- And then you have the issue with salt, if you’re bringing it in with a salt versus an ester

## Insights gained from elite performers in the 2020 and 2024 Olympics [1:58:30]

**Did both Kristian and Gustav compete in the** [**Tokyo Olympics**](https://en.wikipedia.org/wiki/Triathlon_at_the_2020_Summer_Olympics#)**?**

- Yes
- Kristian won and Gustav came in [8th](https://en.wikipedia.org/wiki/Norway_at_the_2020_Summer_Olympics#Triathlon)
- After the Olympics, they went back to the Ironman distance for the next 3 years
- In the [2024 Olympics in Paris](https://en.wikipedia.org/wiki/Triathlon_at_the_2024_Summer_Olympics#), Gustav did not compete because he had an injury and Kristian came in [12th](https://en.wikipedia.org/wiki/Norway_at_the_2024_Summer_Olympics#Triathlon)

**How much of that was the mismatch in distance?**

- That he’s more optimized for Ironman distances?
- Peter thinks that’s like asking a marathon runner to go and run a 5K

*What was the process like to get ready for that, and what was the difference in his personal performance between 2024 and 2021?*

- They went there because they thought it was possible to get back on the podium
- Even after disappointing results, Olav would say they are more convinced today that it’s possible to go back than they were (but there are other reasons that he’ll get to)
- Looking back, Kristian had in training far better performances than what he did on race day
- One of the differences leading into Tokyo was they took a massive shift in how they did **intensity control**
  - That is not necessarily talking about threshold
  - This means exactly pinpointing different intensities and working on them in order to optimize the human body
- It was a massive shift going from Rio to Tokyo ‒ going from an unknown to an Olympic champion
  - Getting good at controlling the intensity really made a difference
- Last year, maybe they got a little complacent and thought they were getting good at controlling the intensity
- Within the last year, they were much more sloppy simply because they had done intensity control for so long that they thought he had a good calibrated body for this
- They made the same error going from 2017 to 2018
- From 2016 to 2017 they saw massive improvements in performance, and this was a time they were doing so much measurement

***They have to go back to that practice of doing lots of measurements***

**In terms of performance, Kristian has put out performances that far exceed what he did on the run in Paris**

- In Paris he lost about 40 seconds over the 10K
- 4 second/ km was the difference between the 1st place and 12th place

**Another difference between Tokyo and Paris was the swim: the current in the river in Paris**

- Kristian actually sat when he came out of the water
- Swimming has never been his forte; that’s the worst discipline for him
- This was also the arena where would would see even bigger differences: some of the poor swimmers in Paris didn’t even finish

Peter asks, “*A lot of people heard about how disgusting the river was. How did that create more separation between the excellent and the good swimmers?*”

- There was a massive current in the water to the extent that most of the triathletes basically set the worlds record for swimming the first 400 meters
- The only problem is that you have to turn back and this is in a river
- If this were a place where you had laminar flow and it was homogenous everywhere, then you could say that it should not make a difference
- The challenge was that the flow is not homogeneous in Paris (and especially in Seine) ‒ it’s highly heterogeneous
  - Such that the fastest swimmer in front suddenly became second (or even down in the group)simply because people went 2 meters to the right and suddenly swam past
  - When they had to deviate out from a pillar, it basically became a tactical race

Peter asks, “*How far did he come out in the water after the leader in swimming?*”

- Olav doesn’t remember but it was quite significant
- What happened was instead of getting in a pack that is swimming, it gets into a long, long line
- Kristin came out as the last guy in the 1st group
  - He was 17, 20 seconds behind
- Out on the bike he was 40 seconds down from the lead group

**Racing strategy on the bike**

- One of the differences they anticipated from the 1st year to the 2nd year was how quickly groups behind were able to catch up with the lead groups on the bike
- People in the 1st group would benefit from going a little bit harder and maybe even start devising strategies where they got domestics

Olav explains, “*This is an individual race where people actually started getting domestics and sacrifice people in the races (from a nation perspective) to be able to keep up*.”

- In the short course triathlon you can draft; different from Ironman racing
- For Kristian, that meant in Paris versus Tokyo, he had to pedal 30% harder for 3/5ths of the race in order just to come back in the group
  - He didn’t get 30% for free for basically 25K (30% extra power)
  - 30%, Peter is surprised he could even do that
  - Yeah, here is not a time where you go all out on a bike ‒ it has an implication for the run

***Even though Kristian’s fitness has increased beyond what it was before, [Paris] was a place where the dynamics were completely different***

- If it were a pure time trial in normal swimming conditions, he would have been faster than what he was in Tokyo

**What was his 10K time?**

- Around 30 minutes (still fast)

## The use of artificial intelligence to optimizing training insights and performance [2:06:30]

**Where do you see AI going to make your insights better and your efficiency better?**

- With all the data he collects, one of the things he was able to discover more quickly with AI was that Kristian’s utilization went up too high in the month leading into the Olympics
- Meaning where he was trading away a little bit of anaerobic power in order to increase aerobic power
  - He was able to race sustainable at an even higher % of his VO2 max
  - That means substrate utilization would normally be improved as well
- Olav doesn’t know if that would have made a difference because of how the race played out

*Olav has been using AI for some time*

- Back in 2020 they started developing their own systems with all the data and in-depth research they have done
- They have a lot of data and interesting findings where they can build an AI system that allows them to take new data in real time and help them highlight what is important and what is not important
  - To help them know what to prioritize and pay attention to

***Olav thinks AI will supercharge research in longevity and human health to a completely different level***

**The potential for AI to help with the “work” of research**

- Many people say the type of work Olav does is insane, simply because of the sheer amount of work required to utilize all the data he collects
- A lot of work done in research today is still manual work
  - Plotting and measurements
- AI can really change this
- To the point where you can use a multitude of extra instruments and be able to dig into data on completely different levels

> “*AI will not replace the decision-making, but it will help us in terms of information.*”‒ Olav Aleksander Bu

***AI will be able to extract patterns you might not otherwise be able to direct your own statistical analysis towards***

**Olav has built an** [**Agentic**](https://www.ssonetwork.com/intelligent-automation/articles/what-is-agentic-ai) **system**

- [Large language models](https://en.wikipedia.org/wiki/Large_language_model) is basically an interface for them

- If he wanted to look at the data in a certain way, he might use the [LLM](https://en.wikipedia.org/wiki/Large_language_model) or [NLP](https://en.wikipedia.org/wiki/Natural_language_processing) to inform which agents should be utilized  to dig into the data
- He still has to produce the question

***For Olav, AI is an autonomous system***

**On the topic of how intelligent AI is**

- A [study](https://arxiv.org/html/2409.04109v1) came out of Stanford that concluded that AI has the possibility of producing novel ideas on par with humanity
- Olav thinks it depends on your perspective
- It depends on what data AI has (what it’s been trained on)
  - If it doesn’t have data for this, the best it can do is try to interpolate between data it has access to

***This means the results may greatly suffer for edge cases (in the domain where you need to extrapolate)***

**AI can empower people**

- Empower a group or even a single human with PhD-level capabilities in mathematics, biology, physics, all these kinds of things
- You use the [NLP](https://en.wikipedia.org/wiki/Natural_language_processing) and ask a question and it can target this kind of data

***With AI, suddenly now without necessarily skills and programming, you are able to formulate questions and these different agents can now employ extreme-level competence from multi-domains to dig into the data and give you insight into what would otherwise be impossible for a large research team***

**As you think about 2028, if you had to speculate wildly, what percentage improvement do you think this will bring to performance?**

- Norway has been a superpower in winter sports
- Much of the reason is because of the technology research that has gone into it
- For example, optimization of skis
  - You could come to the Olympics a better trained athlete but you won’t win simply because of the difference the technology makes on the skis

Olav explains, “*I’m convinced AI and the systems we are building now will have the same implication on purely human performance and training. Meaning that if you basically don’t employ AI at some point you will be at such a deficiency.*”

**AI is a tool for coaches**

- Coaches are often extremely advanced, almost super intelligent in the space of making people fitter
- But they are not remotely close to understanding everything discussed today in terms of knowing the definitions of widely used terminology like FTP
- Still they produce some excellent athletes because of their observational skills and the intuition they have developed of what works and doesn’t work
- They have a lot of experience, empery; they are brilliant, but AI is not a conflict

***Rather, AI is a superpower where coaches can employ their level of understanding into much better questions around what is happening with their athlete***

- AI shouldn’t change the way you do coaching, but it increases the precision of what you do in the coaching

Olav explains, “*The biggest change thus in performance will come true: even better consistency in the training. Not that single workout that is so much more brilliant, but purely in the consistency of the training and adaptations you do through the training programs.*”

**Is there an area in particular that you see the biggest gap between where your coaching insights are today versus where you hope AI is going to close a gap?**

- Being able to be far more proactive than what he is today
- Even though he considers himself as one of the leading people using technology and applied research when it comes to elite performance, in daily life, he is only able to utilize a fraction of the data they are collecting
- You may ask, “*Why do you collect all the other data?*”
- It often becomes an insight
- You come back and learn something from it that you otherwise wouldn’t be able to

***Being able make individual adjustments much more proactively will be one of the biggest differences, and this doesn’t only apply to elites, this applies even to amateurs or normal people***

---

## Selected Links / Related Material

**Episode of** ***The Drive*** **with Olav**: [#294 ‒ Peak athletic performance: How to measure it and how to train for it from the coach of the most elite athletes on earth](https://peterattiamd.com/olavaleksanderbu/) | Olav Aleksander Bu (March 18:2024) | [ 1:00, 1:03:15, 1:09:00]

**Portable VO****2** **analyzer**: [VO2 Master](https://vo2master.com/) | [23:00, 34:30, 42:30]

**Jaeger Oxycon-Pro to test VO****2** **max**: [Oxycon-Pro: The new features](https://www.ntnu.edu/documents/221360533/221362168/oxypro.pdf/91b256f4-97d7-4408-8eec-53869132a03d) (2004) | [42:30]

**AEI MOXUS to test VO****2** **max**: [MOXUS metabolic cart](https://aeitechnologies.com/moxus-modular-metabolic-system/) (2024) | [42:30]

**The company PLASMAIDE**: [PLASMAIDE](https://plasmaide.com/) (2024) | [51:45]

**CORE temperature sensor**: [CORE sensor](https://corebodytemp.com/collections/products/products/core) (2024) | [56:15]

**Stryd power meter for running**: [STRYD: A Closer Look: Stryd Footpath Available on Next Gen Stryd: Track the impact of Fatigue, Shoes, Performance, Injury Recovery, and Drills](https://blog.stryd.com/2024/10/08/a-closer-look-stryd-footpath-available-on-next-gen-stryd/) (2024) | [1:10:15]

**Stryd, running power meter**: [Stryd: Run with Power](https://www.stryd.com/us/en) (2024) | [1:10:30]

**Episode of** ***The Drive*** **with George Brooks**: [#312 – A masterclass in lactate: Its critical role as metabolic fuel, implications for diseases, and therapeutic potential from cancer to brain health and beyond | George A. Brooks, Ph.D.](https://peterattiamd.com/georgebrooks/) (August 5, 2024) | [1:24:00]

**Maurten bicarbonate hydrogel**: [Maurten Bicarb](https://www.maurten.com/products/bicarb-system) (2024)  | [1:28:15, 1:52:15]

**Maurten carbohydrate gels**: [Maurten Gels](https://www.maurten.com/products/gels) (2024) | [1:51:15]

**Maurten drink mixes**: [Maurten Drink Mixes](https://www.maurten.com/products/drink-mixes) | [1:52:00]

**Examples of studies where people trained themselves to consume more carbohydrates** [none were specifically mentioned]: [1:53:45]

- [Training the Gut for Athletes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5371619/) | *Sports Medicine* (A Jeukendrup 2017)
- [Two weeks of repetitive gut-challenge reduce exercise-associated gastrointestinal symptoms and malabsorption](https://pubmed.ncbi.nlm.nih.gov/28508559/) | Scandinavian Journal of Medicine & Science in SPorts (A Miall et al. 2017)
- [Assessing exogenous carbohydrate intake needed to optimize human endurance performance across sex: insights from modeling runners pursuing a sub-2-h marathon](https://pubmed.ncbi.nlm.nih.gov/38059288/) | *Journal of Applied Physiology* (C Lukasiewicz et al. 2024)

**The ability of AI to generate novel ideas**: [Can LLMs Generate Novel Research Ideas? A Large-Scale Human Study with 100+ NLP Researchers](https://arxiv.org/html/2409.04109v1) | *arXiv* (C Si, D Yang, T Hashimoto 2024) | [2:10:00]

**Companies Olav co-founded**:

- [ENTALPI](https://www.entalpi.com/)
- [Santara Tech](https://www.santaratech.com/)

---

## People Mentioned

- [Kristian Blummenfelt](https://en.wikipedia.org/wiki/Kristian_Blummenfelt) (Norwegian triathlete, won the gold medal in the men’s triathlon at the 2020 Summer Olympics, and 2021 Ironman World Champion) [1:30, 23:00, 29:15, 43:45, 1:04:00, 1:45:30]
- [Gustav Iden](https://en.wikipedia.org/wiki/Gustav_Iden) (Norwegian triathlete and 2022 Ironman World champion) [1:30, 23:00, 29:15, 43:45, 1:28:00]
- [Andrew Coggan](https://shhs.indianapolis.iu.edu/connect/directory/coggan-andrew.html) (Associate Professor of Kinesiology and Cellular and Integrative Physiology at Indiana University Indianapolis, defined FTP) [5:15]
- [Eliud Kipchoge](https://en.wikipedia.org/wiki/Eliud_Kipchoge) (world record holder for the marathon from 2018-2023 and first person to run a marathon in under 2 hours, at 1:59:40.2) [1:21:00]
- [Lance Armstrong](https://en.wikipedia.org/wiki/Lance_Armstrong) (former professional road racing cyclist, famous for winning the Tour de France 7 consecutive times) [1:40:15]

---

![](https://peterattiamd.com/wp-content/uploads/2025/01/olav-2-bio.jpg)

##### Guest name

Olav Aleksander Bu is the chief scientist and co-founder of the companies [ENTALPI](https://www.entalpi.com/) and [SANTARA TECH](https://www.santaratech.com/#about). He has worked as the head of performance for the Norwegian Olympic team in triathlon since 2015. As an internationally renowned coach, he has made solid contributions in revolutionizing the way top athletes train through his unique training methodology “Entalpi”. As head coach for the Olympic and world record-holding champion Kristian Blummenfelt and world champion Gustav Iden, he has been vital in making history within triathlon in recent years. With his athletes and the “Norwegian Method”, he has forever changed the swim-bike-run landscape. Olav has been essential in winning an Olympic gold medal, breaking world records, and sweeping all three podium places in WTS in Bermuda 2018.

Instagram: [olavaleksander](https://www.instagram.com/olavaleksander/?hl=en)