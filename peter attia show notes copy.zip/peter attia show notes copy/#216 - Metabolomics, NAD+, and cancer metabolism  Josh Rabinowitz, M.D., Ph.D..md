# #216 – Metabolomics, NAD+, and cancer metabolism | Josh Rabinowitz, M.D., Ph.D.

**Source:** [https://peterattiamd.com/joshrabinowitz/](https://peterattiamd.com/joshrabinowitz/)

---

Josh Rabinowitz is a Professor of Chemistry and Integrative Genomics at Princeton University, where his research focuses on developing a quantitative, comprehensive understanding of cellular metabolism through the study of metabolites and their fluxes. In this episode, Josh focuses the discussion on three main topics: metabolomics, NAD (and its precursors), and cancer metabolism. The metabolomics discussion starts with a broad definition of metabolism, metabolites, and fluxomics before diving deep into glucose metabolism, lactate as a fuel, movement of lactate, and the regulation of these substrates. He then gives a detailed explanation of the electron transport chain and Krebs cycle and their implications with respect to both drugs and nutrition while also explaining how NAD is central to the process of energy generation. He then discusses the age-related decline in NAD and what current literature says about efforts to increase NAD through intravenous or oral supplementation with the precursors NMN and NR, including whether doing so provides any advantage to lifespan or healthspan. Finally, Josh ends the conversation talking about cancer metabolism and how one particular intersection between cancer metabolism and immunotherapy might provide a hopeful outlook on the future of cancer treatment.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/joshrabinowitz/the_Drive_public.png)

Play

#216 - Metabolomics, NAD+, and cancer metabolism | Josh Rabinowitz, M.D., Ph.D.

#216 - Metabolomics, NAD+, and cancer metabolism | Josh Rabinowitz, M.D., Ph.D.

1x15s30s

0:002:11:37

## We discuss:

- Josh’s background and unique path to becoming a research scientist at Princeton [3:30];
- What sparked Josh’s early interest in metabolism [11:15];
- Metabolomics 101: defining metabolites and how they are regulated [16:30];
- Fluxomics: Metabolism as a system in action [26:00];
- The Randle Hypothesis: glucose and fatty acids compete as substrates for oxidation [33:30];
- The important role of lactate as an alternate fuel [36:30];
- Fasting lactate levels as a potential early indicator of metabolic dysfunction [48:00];
- The beauty of the Krebs cycle and the role of NAD in energy production [53:15];
- How the drug metformin acts on complex I of the electron transport chain [1:05:00];
- The difference between NADH and NADPH [1:08:45];
- NAD levels with age, and the efficacy of supplementing with intravenous NAD [1:10:45];
- The usefulness of restoring NAD levels and efficacy of oral supplementation with NAD precursors NR and NMN [1:22:15];
- Exploring the hypothesis that boosting NAD levels is beneficial [1:32:30];
- Cancer metabolism and the intersection with immunotherapy [1:39:00];
- Making cancer a chronic disease: exploiting the metabolic quirks of cancer, augmenting the immune system, and more [1:46:15]
- The challenge of treating pancreatic cancer [1:50:30];
- Epithelial cancers that might respond to metabolic approaches to therapy [1:56:30];
- Josh’s hopeful outlook on the future of cancer treatment [1:59:00];
- Nutritional approaches to cancer attenuation [2:00:15];
- What makes Princeton University special [2:06:15];
- More.

§

## Show Notes

**\*Notes from intro:**

- Josh Rabinowitz is a Professor of [Chemistry](https://chemistry.princeton.edu/faculty/joshua-rabinowitz) and [Integrative Genomics at Princeton University](https://lsi.princeton.edu/faculty/joshua-d.-rabinowitz)
- [His research](https://scholar.princeton.edu/rabinowitz) focuses on a quantitative, comprehensive understanding of cellular metabolism, through the study of metabolites and their fluxes
- He’s also the director of the Princeton branch of the [Ludwig Institute for Cancer Research](https://www.ludwigcancerresearch.org/) and a member of the [Rutgers Cancer Institute](https://www.cinj.org/)
- Josh earned his MD and PhD in biophysics from Stanford
  - He and Peter were in the same graduating class, although he started earlier, because he did 2 degrees
- In between earning his MD and PhD and joining the faculty at Princeton, Josh worked at [Alexza Pharmaceuticals](https://www.alexza.com/) as the co-founder and vice president of research (we’ll come back to this)
- Josh is the inventor of over 160 patents, including 5 drug products that are in the FDA-sanctioned clinical testing pipeline
- He has received numerous awards, including an [NSF CAREER award](https://beta.nsf.gov/funding/opportunities/faculty-early-career-development-program-career), an [NIH Pioneer Award](https://commonfund.nih.gov/pioneer) and was distinguished as an [Allen Distinguished Investigator](https://alleninstitute.org/what-we-do/frontiers-group/distinguished-investigators/) in 2019
- This is a pretty technical episode
- We focus on 3 things: metabolomics, NAD and it’s precursors, and cancer metabolism
- We open the discussion talking about metabolism, metabolomics and fluxomics
  - This includes a pretty in-depth conversation around glucose, glucose metabolism, lactate as a fuel, movement of lactate and the regulation of these substrates
- From there, we speak in more detail on the electronic transport chain and the Krebs cycle and what the implications are, both with respect to drugs and nutrition
  - This is an important segue into the second major pillar of our discussion, around NAD
- Most of you have heard of NAD, we certainly get a lot of questions about NAD
  - More questions about the NAD precursors: NR and NMN
  - We’ve also had previous podcasts where we’ve discussed this, including episodes with [David Sinclair](https://sinclair.hms.harvard.edu/) and [Rich Miller](https://www.richmillerlab.com/)
    - [#70 – David Sinclair, Ph.D](https://peterattiamd.com/davidsinclair2/).: How cellular reprogramming could slow our aging clock (and the latest research on NAD)
    - [#27 – David Sinclair, Ph.D](https://peterattiamd.com/davidsinclair/).: Slowing aging – sirtuins, NAD, and the epigenetics of aging
    - [#148 – Richard Miller, M.D., Ph.D](https://peterattiamd.com/richardmiller/).: The gold standard for testing longevity drugs: the Interventions Testing Program
- In this discussion, we talk about the intravenous use of NAD and the oral use of the precursors
- Spoiler alert, in this episode we’ll point you to something pretty significant which Peter learned, something he has been saying incorrectly for some time
  - So if you’ve heard Peter speak on this topic before, you might want to listen to this big correction
- We end the conversation talking about cancer metabolism
  - Particularly one way in which cancer metabolism and immunotherapy might intersect

## Josh’s background and unique path to becoming a research scientist at Princeton [3:30]

- Peter recently interviewed 2 of their classmates from med school: [Max Diehn](https://med.stanford.edu/diehnlab.html) and [Karl Deisseroth](https://profiles.stanford.edu/karl-deisseroth)
  - [#213 ‒ Liquid biopsies and cancer detection | Max Diehn, M.D. Ph.D.](https://peterattiamd.com/maxdiehn/)
  - [#191 – Revolutionizing our understanding of mental illness with optogenetics | Karl Deisseroth M.D., Ph.D.](https://peterattiamd.com/karldeisseroth/)
- He and Karl reminisced how they and Josh all started their surgical rotation together, in the same day almost 25 years ago
- Josh remembers Peter practicing a lot while he looked on
  - He thought practice was what you were supposed to be doing if you wanted to become a surgeon

**Josh’s PhD work**

- Josh did his PhD with [Harden McConnell](https://chemistry.stanford.edu/people/mcconnell) (one of the great physical chemists) together with [Mark Davis](https://med.stanford.edu/davislab.html) (the immunologist)
- His thesis was about the physical chemistry of [T-cell activation](https://en.wikipedia.org/wiki/T_cell#Activation)
- At that time, people had discovered that different antigens could activate T-cells differentially
- He was really interested in how that happened; he studied the process of antigens turning into peptides that combined to MHC
  - Then, how the kinetics of the interaction between the peptide antigen and the [major histocompatibility complex protein, MHC](https://en.wikipedia.org/wiki/Major_histocompatibility_complex), and then the interaction of that complex with the [T-cell receptor](https://en.wikipedia.org/wiki/T-cell_receptor) determined whether people have productive or failed immune responses
  - The hope was you could then manipulate those processes to promote better vaccination or disease clearance and also to potentially treat autoimmunity

**Did Josh also have an interest in cancer?  This work would be one of the hallmarks of how immunotherapy is effective in eradicating cancer**.

- At that point in his career, he didn’t think immunological approaches to cancer held much promise
- He was more focused on infectious disease and autoimmunity
- He remarks, “*Shows you what I know; it’s wonderful to see that the world has turned out to be a lot better than I dreamed it would be on that dimension*”
- Peter adds, this is such an interesting topic; he had [Steve Rosenberg](https://ccr.cancer.gov/staff-directory/steven-a-rosenberg) on the podcast last year
  - It was a beautiful and fun recap of how the immune system works
  - [#177 – Steven Rosenberg, M.D., Ph.D.: The development of cancer immunotherapy and its promise for treating advanced cancers](https://peterattiamd.com/stevenrosenberg/)
- The part of T cell activation that is amazing is the T cell receptor recognizes things that are [9-11 amino acids long](https://en.wikipedia.org/wiki/Epitope)
  - The peptides have to be just be right size to be presented and then recognized
  - This doesn’t seem to leave a lot of margin for error; it’s a really attuned system

**Do you have a sense of why evolution ended up with such a narrow fragment of peptides that were recognizable, as opposed to a broader/ different range?**

- Josh has an intuitive sense that our bodies work on the scale of billions of immune cells and billions of immune receptors that are made through [recombination](https://en.wikipedia.org/wiki/V(D)J_recombination)
  - That naturally pairs with billions of [antigens](https://en.wikipedia.org/wiki/Antigen)
  - You just think about this number 9 and you think about the number of amino acids, right?
  - There are 20 amino acids, so you’re talking about 20 to the 9th power of presentable peptide antigens

> “*These things are all tuned to be on the same scale, this scale of billions*”‒ Josh Rabinowitz

- If the T cell recognized 3-amino acid peptides, that would not provide enough information to selectively respond to a virus or bacteria
- If it was 25 peptides, this would provide too much information
- Josh thinks the system was built to work on a minimal, or just the right amount of information

**When in your training did Josh make the decision to be a full-time scientist, as opposed to a physician scientist?**

- He applied for an internship knowing that he really loved research
- As he spent more time in medicine, he realized it involves a lot of doing the same thing over and over again
  - There is a lot of following the standard of care
- His passion is to come in and try to do something different every day
  - To think differently than people ever have before
  - This is what led him to research
- He loved the patient interaction part of medicine, but doing things the same every day was challenging
- Peter agrees, “*I think those of us that chose the more medical side of things can also speak to the frustration of how creativity can often be stifled in medicine*”
  - This is in large part, for good reason
  - Surgery, probably more than other disciplines tends to frown upon creativity and novel approaches to problem solving

**Before joining the faculty at Princeton, did you go straight into industry from medical school?**

- Yes, Josh was fortunate enough to have the opportunity to work with one of the great early biotech entrepreneurs, [Alex Zaffaroni](https://en.wikipedia.org/wiki/Alejandro_Zaffaroni)
- They started [Alexza Pharmaceuticals](https://www.alexza.com/) when he was straight out of medical school that was focused on fast drug delivery
  - What could you do by being able to deliver medications noninvasively on the timescale of giving an IV Push in the hospital?
  - They did that through inhalation of small molecules
  - Building on the concept that if you smoke something like a cigarette, you get incredibly rapid access to the systemic circulation
  - That was Josh’s first job
- The company’s initial focus was on migraines
  - They never found the drug that had the perfect combination of safety with rapid delivery and efficacy
- They ultimately had a [drug approved](https://www.adasuve.com/) for [acute agitation](https://en.wikipedia.org/wiki/Psychomotor_agitation); it’s a [sedative](https://en.wikipedia.org/wiki/Sedative) [hypnotic](https://en.wikipedia.org/wiki/Hypnotic)
  - Patients come in the ER, they’re agitated and frustrated and want to stop feeling that way
  - Patients are eager to take a puff of something
  - They calm down in a couple minutes; it’s wonderful for them

## What sparked Josh’s early interest in metabolism [11:15]

*What made Josh decide to take this lateral step to go into academics?*

- He was lucky to go straight from that job into a faculty position at Princeton
- That’s a rare opportunity

**What was the first problem he wanted to build his lab around?**

- He learned about drugs in his work with Alexza Pharmaceuticals
  - They studied every medication in the pharmacopeia for whether it could be a candidate for rapid delivery
- He realized there were relatively few labs looking at metabolism broadly, compared to other really important areas of science
  - Like immunology, cancer, or neuroscience
- He started his lab with a really simple question, “***Could we measure the classic metabolites that you read about in a biochemistry textbook in one shot, quantitatively****?*”
- The second question he had in mind was, “***Can we measure the activities of those metabolic pathways?” How fast are those metabolites flowing? Where are they coming from and where are they going****?*”
- Recently Peter had lunch with one of their mutual friends, [Navdeep Chandel](https://www.chandellab.com/)
  - Former guest on the podcast: [#31 – Navdeep Chandel, Ph.D.: metabolism, mitochondria, and metformin in health and disease](https://peterattiamd.com/navchandel/)
  - Nav commented that his work was in the bottom 10th percentile, nobody finds metabolism interesting
    - In the ‘90s if you weren’t doing genomics, if you weren’t doing this other sexy stuff, immunology, you were really an uninteresting person
    - But he found metabolism interesting
    - Today we see this is where the action is
- Josh agrees, early in his career, metabolism as an area was out of favor
  - Metabolism was a “solved” problem
- The [Krebs cycle](https://en.wikipedia.org/wiki/Citric_acid_cycle) was the culmination of metabolism research
- At the same time, [metabolic syndrome](https://en.wikipedia.org/wiki/Metabolic_syndrome) was becoming worse and worse in the population
- Soon after he began working at Princeton 2 things began to shift
  - 1 – People realized that genomics as a standalone was not going to solve health problems
    - Genomics needed to be supplemented by other technologies that looked at biochemistry broadly
    - Metabolomics was one of those that proved enduring
  - 2 – The metabolic syndrome epidemic kept becoming more obvious
- Josh’s training as a physician becomes important b/c he saw the clinical problem
- Josh agrees, “*I just benefited so much from the breadth of biology and medicine that you learn in medical school. I mean, it allowed me to start my lab working on bacteria, which I had never worked on at all as a PhD student. Because you learn bacteriology as one of the things in medical school*.”

> “*That was the perfect starting point for building these technologies*”‒ Josh Rabinowitz

## Metabolomics 101: defining metabolites and how they are regulated [16:30]

- Metabolism is the process that converts the food we eat into usable energy and the building blocks our body needs to grow or regenerate itself, as well as waste along the way

***So what is metabolomics?***

- The bulk of metabolism (that makes most of our usable energy) involves something like a hundred metabolites
- The 1st thing Josh wanted to do was measure those 100 metabolites really well
- *Examples of metabolites*: This includes all the amino acids and other fundamental inputs we get from our diet
  - Glutamine
  - Acetate (in vinegar or produced by your [microbiome](https://en.wikipedia.org/wiki/Human_microbiome))
  - Fats
- Then there are **intermediary metabolites**
  - These are [glycolytic intermediates](https://en.wikipedia.org/wiki/Glycolysis) that people may have heard about in biochemistry
  - Fructose bisphosphate is a famous one of those
  - [Pyruvate](https://en.wikipedia.org/wiki/Pyruvic_acid) and [lactate](https://en.wikipedia.org/wiki/Lactic_acid)‒ a lot of people hear about from exercise
  - Members of the [Krebs cycle](https://en.wikipedia.org/wiki/Citric_acid_cycle) like [citrate](https://en.wikipedia.org/wiki/Citric_acid), is a famous one that exists in our circulation, and also comes from citrus fruits
- Then, there are the more **effector or energy-holding metabolites**‒ ATP, NADH, NADPH
- Josh explains, “*Part of the beauty of metabolism as a system is that, with some modest variation, there’s almost a singular solution on earth to how metabolism works. When we learn to measure the metabolites in E. coli, at the same time, we’re really learning how to measure metabolites all the way up to humans*”
- If you comprehensively survey the basic components of protein and nucleic acids and metabolic intermediates, there’s on the order of 1000 molecules that have a clear biological function
  - This is a big problem
  - But it’s on the scale of knowing all the kids who go to your highschool not everyone in the phone book in New York City
  - This problem is right at the interface between the human scale and the computational scale

**Do we know every single metabolomic element?**

- Is there a chance there are other metabolites that we don’t know about?
  - Because we haven’t looked for them?
  - Or they’re very short-lived?
- Josh and other groups around the world keep discovering new metabolites at a steady pace
  - But he doesn’t think there’s been a completely new and important metabolite discovered yet this century
- Science finished finding the major metabolites around the time of [Krebs](https://en.wikipedia.org/wiki/Hans_Krebs_(biochemist))

> *“In terms of understanding how the system really works, how to choose the right diet to be healthy given our genotype or disease, we haven’t scratched the surface yet.”* —Josh Rabinowitz

**Regulation of metabolites [21:15]**

*How many of these metabolites are tightly regulated?*

- Peter loves to explain regulation and homeostasis using [pH](https://en.wikipedia.org/wiki/PH) as an example
- The pH spectrum runs from 0 to 14, see the figure below

![](https://peterattiamd.com/wp-content/uploads/2022/07/f1-rabinowitz-599x1024.png)

**Figure 1. The pH scale**.  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/PH)

- Neutral pH is 7
- Peter explains, “*anybody who’s taking care of a patient in the hospital knows 7.4 is where we live as an organism, almost unsurvivable to have an acidosis that goes below seven or an alkalosis that exceeds about 7.7*”
- pH is tightly regulated to keep us at 7-7.7

*Which metabolites behave like pH and which ones do not?*

- Josh agrees, pH is a great example‒ it’s a giant logarithmic scale
  - So even when you talk about 7.1 to 7.4, you’re talking about something of a 2-3 fold change
- A lot of important metabolites live in that 2-3 fold range as being the preferred range
- For some there is a lot more active regulation (like glucose)
- For others, there is a relatively passive process that keeps them in that range
- There are all sorts of metabolites, some are made by plants that only some of use eat
  - So some people may have a lot while others have none
- For the big metabolites (in the biochemistry textbook), the **healthy range exists in this 2-3 fold range in the bloodstream**

***Are there common and consistent tools that the body uses to regulate metabolites?***

The most important principle is: *When it’s there, use it up*.

- In physics, you could say this is a linear consumption of circulating metabolites
- In chemistry, people call this [mass action](https://en.wikipedia.org/wiki/Law_of_mass_action)
- A lot of what you eat, after a little bit of processing, enters the bloodstream
  - Then it’s the job of the tissues that need these ingredients to use them, in proportion to their availability in the blood
- There’s a lot of regulation layered over top of that, to make the body work

**Insulin**—The most important regulatory hormone in mammals

- The most important regulatory hormone in mammals is [insulin](https://en.wikipedia.org/wiki/Insulin)
- There are 2 ways to look at insulin
- 1 – Insulin is a hormone that acts to control elevations in blood sugar
  - At the highest level, it does this by promoting uptake of glucose and preventing production of glucose
- An alternate view is‒ *we evolved mainly to be able to survive a lack of nutrients*
- 2 – Insulin is a hormone that says, you don’t have to use fat right now
  - It senses that there are enough carbohydrates around and therefore, it’s safe to not release fat from your adipose tissue

*Insulin has 2 equally important roles*

- 1 – ***The disposal of glucose into muscle and stopping glucose production in the liver***

- 2 – ***Stopping lipolysis to keep fat in your fat stores***

> “*The suppression of lipolysis is a primary, perhaps the primary, function of insulin*”‒ Josh Rabinowitz

## Fluxomics: Metabolism as a system in action [26:00]

**What do we know about the flux of metabolomics?**

- When Peter thinks back to biochemistry, 25 years ago, [Stryer’s classic textbook](https://en.wikipedia.org/wiki/Biochemistry_(book)), we studied biochemistry in a static way
- Josh thinks this static view of metabolism was never intended by Stryer but got codified in the textbooks
- This static view killed excitement around metabolism as a topic
- Metabolites are **intermediates in the process of converting what we eat into usable energy** and protein biomass
- These things, they’re really relatively low in abundance and they’re flowing very, very fast
- “Metabolism is a system in action” says Josh

- Metabolites are completely different from part of our bodies that are going to sit there for maybe our entire lifetime (like neurons)
- Metabolites are meant to be made and used on a timescale of a second to an hour (depending on the metabolite)

> *“The action is in the flow, and understanding where things are coming from, where they are going, and where we can learn about how metabolism works*.” —Josh Rabinowitz

**Example:** *Regulation and flow of blood glucose*

*If Peter did a finger prick and his glucose was 89 mg/dL, what does that mean?*

- Josh notes, this is a super healthy blood glucose level
- But, when you think of that absolute amount of glucose, if you took all the glucose in your bloodstream at that level, that’s a few minutes of glucose or energy
- That glucose has to be constantly replenished in order to feed tissues that depend on glucose
  - Such as your brain, activated immune cells, and other tissues

*Now let’s say Peter’s* [*fasting blood glucose*](https://en.wikipedia.org/wiki/Glucose_test) *comes back at 180 mg/dL*

- - This would be [type 2 diabetes](https://en.wikipedia.org/wiki/Type_2_diabetes)

- Peter asks, “*What’s the absolute difference in the amount of glucose in my bloodstream? It went from being 5 grams to 10 grams? Seems like a really trivial amount…. It’s only doubling the amount of glucose*”

- Type 2 diabetes more than doubles your risk of mortality and increases your risk of cancer, Alzheimer’s disease, and cardiovascular disease
- This disease becomes a problem with only a 2-fold increase in blood glucose levels
- The system has been built to have about the most circulating glucose that you can have safely
- Josh thinks a lot of the really important metabolites have been pushed to the edge this way
- We know that there are deleterious protein modification reactions, glycosylation reactions that occur when glucose gets above this point
- Evolution pushed right up to the highest in non-problematic glucose
- This didn’t happen for a lot of other metabolites and that’s part of why there isn’t a lot of other diseases like diabetes

***Having a good amount of glucose circulating is really valuable and evolution didn’t build in a lot of wiggle room for glucose levels to safely rise***

- Peter replies, “*This speaks to why the flux problem is the more interesting problem than the static problem*”
- The problem is not that your blood sugar is too high in that moment, the problem is the liver assumes, in part, that 190 mg/dL is the right level and it continues to do it
  - Because at that moment when you’re not eating, the liver is the only source by which glucose is getting into the bloodstream
  - It uses [gluconeogenesis](https://en.wikipedia.org/wiki/Gluconeogenesis) and hepatic glucose output to maintain this elevated level
- Production and consumption of glucose have to be balanced for your glucose to stay anywhere close to steady
- In a diabetic production and consumption are balanced, in a healthy person, production and consumption are balanced
- They can even be the same amount of production and consumption, but it can just be that you need a higher amount of glucose to achieve that same balance of production and consumption in the diabetic
  - To Josh, this reflects underlying issues with how fat is handled
  - Either you need more glucose to induce more insulin in order to suppress lipolysis in the diabetic
  - Or you need more glucose to out compete fat, to get burnt in tissues

## The Randle Hypothesis: glucose and fatty acids compete as substrates for oxidation [33:30]

- There’s a competition between the fuels glucose and fat; this is a very old idea called the [Randle Hypothesis](https://en.wikipedia.org/wiki/Randle_cycle)
  - Josh has a lot of data that’s consistent with this hypothesis
  - A lot of tissues make room for glucose to be burned by controlling the amount of fat that’s being used by tissues
- The essence of the Randle Hypothesis is that fat is somewhere between “A preferred and THE preferred” fuel for tissues and there’s competition between carbohydrates (classically glucose) and fat, for burning
  - When fat is available, then glucose tends not to be burned effectively; and that’s a possible cause of diabetes

*Fat here doesn’t mean fat within adipose tissue, it means fat available for use*

- Fat that’s available for use can come in multiple forms
  - 1 – Free fatty acids floating in the bloodstream (this may be the most important form)
  - 2 – Adipose stores within tissue, ectopic fat, for example, droplets of fat building up in muscle
    - Not subcutaneous white adipose, which is typically a healthy place to store fat molecules
    - These droplets of fat within tissue compete with carbohydrates for being burned
  - 3 – Breakdown of [lipoproteins](https://en.wikipedia.org/wiki/Lipoprotein#Plasma_lipoproteins_particles) from the bloodstream, things like VLDL, we desperately need to have broken down in order to have a good HDL and a low LDL cholesterol.

- Recent evidence that supports the Randle Hypothesis

**Josh’s experiments examines what can suppress glucose use in tissues**

- They see very clearly that fat suppresses glucose use
- There is a long history of this observation, but maybe it hasn’t been adequately appreciated, just how fundamental that result is
- If you turn off lipolysis in different ways, then you rapidly induce glucose consumption
- If you provide other alternative fuels, they will also compete with glucose to suppress glucose use
  - Josh has learned that lactate is a very important circulating fuel, and it also will suppress glucose use

***The fact that you can have multiple different types of fuels, either fat or lactate, and any of them will suppress glucose use, really makes Josh believe in this kind of competitive nutrient environment and that that plays a central role in determining whether you clear or don’t clear glucose and how high your glucose has to go in order to be cleared***

## The important role of lactate as an alternate fuel [36:30]

- When your demand for ATP gets high enough and quick enough, you’re going to basically take glucose and when you turn it into pyruvate, rather than take the efficient path of shuttling pyruvate into Acetyl-CoA through the Krebs Cycle, where you can generate lots of ATP (requiring oxygen), see the figure below
  - Conversion of glucose to lactate is a quicker path that’s less efficient, but doesn’t require the same cellular oxygen, and you won’t get nearly as much ATP
    - This also tends to generate a lot of lactate, which tends to gravitate with hydrogen ions, which tends to poison the muscle a little bit
    - That’s why it becomes rate limiting, in terms of how long you can sustain that level of output

![](https://peterattiamd.com/wp-content/uploads/2022/07/f2-rabinowitz-1019x1024.png)

**Figure 2.  Conversion of glucose to lactate compared to metabolism using the Krebs cycle.** Image Credit: [Darekk2](https://commons.wikimedia.org/w/index.php?curid=21712725), [Wikipedia](https://en.wikipedia.org/wiki/Fermentation)

*Why is this the tip of the iceberg?*

- Josh thinks this is all really important, only it’s just party of the picture
- The other part is that mammals have been wired to use lactate as a major circulating nutrient
  - It’s a super fast turnover nutrient
  - When you think of having a few minutes supply of glucose circulating in your blood, you have an even shorter supply of lactate
  - Lactate is constantly being made, released into the bloodstream, and consumed
    - Lactate enters the TCA/ Krebs cycle to be used as a fuel, see the figure below
  - There are [MCT transporters](https://en.wikipedia.org/wiki/Monocarboxylate_transporter) that will carry lactate into virtually any cell in your body
    - MCT stands for monocarboxylate, because lactate has 1 carboxylic acid (if you think of it from a chemistry perspective)

![](https://peterattiamd.com/wp-content/uploads/2022/07/f3-rabinowitz-1024x695.png)

**Figure 3.  Lactate is used as a fuel.**   Image credit: [*Nature Metabolism* 2021](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7983055/)

> “*It [lactate] serves as an almost universal nutrient*”‒ Josh Rabinowitz

- Peter notes, this already differs from what we learned in biochemistry class
  - We learned that lactate goes back to the liver and the [Cori Cycle](https://en.wikipedia.org/wiki/Cori_cycle) turns lactate back into glucose
  - Then the liver exports the glucose via the hepatic glucose output
- Jost points out, “I *think the really important thing about lactate is that glucose penetration into tissues is actually heavily regulated. It has to be heavily regulated so that if we go through a period of having low carb intake, there’s still glucose preserved for the brain and for other cells that particularly need it. Lactate is the universally available form of carbohydrate. In a healthy heart, at least in the fasted state, it basically will not touch glucose, but it will use lactate as fuel*.”
  - The preferred fuel of a healthy heart is free fatty acids
  - It probably also gets some fatty acids from lipoproteins
  - It definitely uses lactate and things like [ketone bodies](https://en.wikipedia.org/wiki/Ketone_bodies)
  - It is a clear example of a tissue (other than liver) that consumes lactate as a fuel for carbohydrate energy
- Peter notes, “*Lactate is another metabolite that I pay a lot of attention to… As regularly as I’m checking my glucose, I’m checking my lactate*.”
  - As compared to glucose, his range is much greater for lactate
  - The lowest glucose he ever measured in himself was 50 mg/dL
  - The highest was when [Jerry Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) had him do an insulin suppression test at stanford; he almost died
    - It was ridiculous because one of the IV got blown
    - They were pushing glucose and didn’t know; he was getting so hypoglycemic
    - In medical school, he learned what hypoglycemia feels like‒ you start sweating profusely
    - This was like nothing he had ever experienced
    - “*It felt like a bucket of water got dumped on me… I could feel the IV was blown*”
    - When they finally corrected it, his glucose got up to 240 mg/dL
    - That’s a 5x range in glucose levels
  - With lactate, Peter has measured it as low as 0.3 mmol and a high as 20 mmol in himself
    - That’s a 60-fold difference
- Josh agrees, this is a big range
  - It probably depends a lot on your physiological state
- Peter agrees, the 0.3 mmol was at rest and fasted
  - 20 mmol is kind of an all-out, 2-minute effort
- The point here is there is a much bigger range in blood lactate levels

**Are blood lactate levels regulated? Is there an upper limit to how high it can go or is it simply how much pain you can tolerate, in terms of what is necessary to generate lactate?**

- Josh is not sure
- Peter may be right on the pain side of the scale
- This has to do with how fast lactate is produced and consumed
  - You can have an exertion up to 20 mmol, and that can be cleaned up in a few minutes of rest
  - Lactate is a very flexible metabolite; it goes down very quickly

**Neurons use lactate**

- Peter remembers reading in 2011 that neurons might like lactate beside glucose
  - At that time, there were only 2 fuels a neuron would ingest
  - Normally, neurons exclusively used glucose
  - In the ‘60s, [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) showed they could use [ketone bodies](https://en.wikipedia.org/wiki/Ketone_bodies), beta-hydroxybutyrate and acetoacetate
    - Neurons could use maybe 60/40 in favor of ketone bodies to glucose
  - Then there were whisperings in animal studies that suggested neurons could consume lactate
- Josh replies that it’s still unclear which cell types in the brain use lactate versus produce lactate
  - There is certainly lactate use in the brain
  - This is an active area of investigation
  - Josh’s bias is, “*we are a neuron-centric form of thinker, we didn’t evolve to make glucose, a unique brain fuel, in order to feed astrocytes. We did it to feed neurons. I do think there’s a special neuronal dependence on glucose, but lactate goes everywhere. It probably goes into both astrocytes and neurons as a fuel in the right circumstances*.”
- The beauty of lactate is it allows a tremendous degree of flexibility that  wouldn’t exist otherwise
- [George Brooks](https://ib.berkeley.edu/people/faculty/brooksg) at Berkeley recognized the ubiquitous potential for lactate as a fuel
- Josh has contributed to that story by showing lactate is used throughout the whole body, using mass spectrometry

**Evolutionary reason for allowing most tissues to use lactate directly as a fuel instead of relying on the liver to mop it up**

- This is not easy to answer but Josh has done some experiments in yeast
  - Yeast makes ethanol as a waste from fermentation of glucose (see the figure below)

![](https://peterattiamd.com/wp-content/uploads/2022/07/f4-rabinowitz-1024x421.png)

**Figure 4.  Glucose can be fermented to lactic acid or ethanol.**  Image credit: [Darekk2](https://commons.wikimedia.org/w/index.php?curid=21712725), [Wikipedia](https://en.wikipedia.org/wiki/Fermentation)

- People think yeast have the same choice when you get to the level of pyruvate
  - 1 – Spit it as a [redox](https://en.wikipedia.org/wiki/Redox)-balanced waste; in humans that’s done as lactate and in yeast that’s done as ethanol (see fermentation in the figure above)
  - 2 – Take pyruvate into the TCA cycle (aka Kreb’s cycle, in the mitochondria)

***We see, going all the way back to yeast, that’s a false choice***

- Josh points out, “*The default is to spit out the redox balanced waste [lactate or ethanol] and then you can always pick the waste up and reuse it if you need energy from TCA cycle*”
- This goes back to the very earliest days of eukaryotic life‒ you want to be able to run glycolysis whenever you need to run glycolysis
  - Use glucose whenever you need to use glucose
  - That takes you to pyruvate
  - This creates a redox problem because you have electrons from the glucose that are not sitting on the pyruvate
  - The first priority is to solve that redox problem
  - That’s achieved in our bodies by spitting out lactate
  - “*You don’t really want to hold that problem within cells in your body, you want to get that all the way under the circulation so every cell in your body can work on this master metabolic challenge of keeping electrons balanced*”

**⇒** ***Now these electrons are a super valuable source of energy and whoever needs energy can pick them up in the form of lactate***

- The way biochemistry is taught puts forth a false coupling of oxidative and glycolytic metabolism
- In our bodies and in eukaryotes, all the way back to yeast, we’re designed to be much more flexible to allow these 2 processes to happen
  - In yeast they are completely independent; they can just spit out ethanol into the environment
  - In us they are quasi-independent
    - Independent at the level of individual cells in our body and this is good; if you have a bout of hypoxid you can release lactate and this will be cleaned up elsewhere in the body
    - In our bodies the lactate has to be cleaned up somewhere because we don’t have any master release valve for this
    - All of our cells together have solved this problem
- We can’t excrete lactate from the body; too much lactate in the blood can cause medical problems like [lactic acidosis](https://en.wikipedia.org/wiki/Lactic_acidosis)
  - This can occur with certain metabolic deficiencies
  - Or if you couldn’t breathe, then you end up in this crisis of redox imbalance
- We distribute the problem across the body
  - Through constant trading of lactate in and out of cells
  - This lets whatever cells need that carbohydrate energy use the lactate

***The system would be way less flexible if only the liver could clean this up***

- It would also be way less commensurate with effective bursts of exercise
  - The heart is super well perfused, more so than muscle
  - It’s okay if it’s hard to get oxygen to the muscle when it’s making a lot of lactate
  - This is advantageous for the  heart, which has more oxygen than it needs, to use lactate rather than fatty acids
    - As fatty acids are better for long term energy storage

## Fasting lactate levels as a potential early indicator of metabolic dysfunction [48:00]

**How is lactate use regulated locally?**

*How does a myocyte in the heart know the energy of the entire system so it can make this decision?*

- It may seem counterintuitive from a medical or textbook viewpoint, but from a physical chemistry viewpoint, it’s pure intuition
  - When lactate goes up, it gets burnt
- This decision is made on mass action and availability of substrates; there’s not decision

***If you have too much lactate, it flows out. If you are short on energy, it flows in.***

**Fasting lactate levels**

- Peter has become very interested in  the levels of fasting lactate in the population
- If you measure a person’s lactate level, first thing in the morning, you’re going to see a lot of variability
  - This seems to be proportional to their metabolic health
  - The higher that number, the less metabolically healthy they are
  - It’s not uncommon for someone who is insulin resistant to have a fasting lactate level approaching 2 mmol with no activity
  - In a healthy person, this will be below 0.5 mmol

*What does this tell us about fuel partitioning and this problem of metabolomics?*

- Josh thinks there’s a correlation between fasting glucose and fasting lactate
- Lactate may be harder to measure, but perhaps even more intimately tied to the essence of metabolic dysfunction
- Lactate levels tell us a few things
  - When **fasting lactate is high**, it reflects the fact that during these times of fasting, when glucose is not really supposed to be used much, you’re still using too much glucose
    - You’re converting too much glucose to lactate
    - At the same time that your lactate clearance system isn’t working very well
    - Typically, that’s because you’re having competition between lactate and fat to be burned

⇒ This all feeds into the syndrome of diabetes

*Peter asks about another interesting observation‒ if he checks his lactate when he wakes up in the morning (it’s 0.4 mmol), then eats the biggest carbohydrate meal he can, he doesn’t exercise and rechecks his lactate in 1 hour, it’s 1 mol.  What happened?*

- He understands the biochemistry, which is he has more glucose to metabolize
  - This suggests that his lactate should not have gone up
  - He’s using glucose to make pyruvate
  - He has endless cellular oxygen
  - He should be running that pyruvate through the Krebs cycle
  - He shouldn’t see any uptick in lactate
  - But this is not what he sees
- Josh explains, “***Circulating lactate is an intermediary in glucose catabolism. That’s just the way the body works. It’s not what we were taught in med school.***”
- His work is chipping away at this paradigm but he doesn’t know how much it’s shifting at the level of medical education yet
- He hopes the next generation of biochemistry textbooks talk about circulating lactate as an intermediary in glucose catabolism
  - This is fundamental for people who want to think about metabolism accurately
- Of [Jerry Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) 5 criteria for what was called Syndrome X (now called [metabolic syndrome](https://en.wikipedia.org/wiki/Metabolic_syndrome)), fasting glucose is still 1 of these criteria
  - The 5 criteria are: (1) waist circumference over 40 inches (men) or 35 inches (women), (2) blood pressure over 130/85 mmHg, (3) fasting triglyceride (TG) level over 150 mg/dl, (4) fasting high-density lipoprotein (HDL) cholesterol level less than 40 mg/dl (men) or 50 mg/dl (women), and (5) fasting blood sugar over 100 mg/dl

***Peter thinks a fasting lactate would be more telling***

- Josh thinks the challenge with lactate is that it is metabolizing up and down faster
- One response to stress is to rapidly convert glucose into lactate
  - That’s just part of your body activating
  - There are people who have stress at a blood draw and because lactate is fluctuating a little bit more this way, there are going to be pros and cons medically for using it as a biomarker
- Josh doesn’t think our problem with metabolic syndrome is diagnosing it
  - Our problem is preventing it
- Peter thinks we treat metabolic syndrome too discreetly; we come to it too late
  - We should be looking for things far before you actually have hypertension, truncal obesity, dyslipidemia, and hyperglycemia
- *Peter wonders if lactate dysregulation might be an earlier canary in the coal mine, indicating metabolic syndrome*
  - Josh agrees

## The beauty of the Krebs cycle and the role of NAD in energy production [53:15]

**Metabolism of aerobic respiration**

- Before discussing [NAD](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide) (and NADP, NADPH, NR, NMN and all the things people care about), let’s review how the [electron transport chain](https://en.wikipedia.org/wiki/Electron_transport_chain) works
  - What is the [Krebs cycle](https://en.wikipedia.org/wiki/Citric_acid_cycle) doing?
  - How is that feeding into this massive generation of energy currency?
  - Explain the concept of [redox](https://en.wikipedia.org/wiki/Redox)
- Fundamentally, you eat 3 macronutrients: carbs and protein and fat
- In a healthy adult first approximation, every carbon atom that you eat in any of those three forms needs to exit your body as exhaled carbon dioxide
- All of that exhaled carbon dioxide to a first approximation, is made in the TCA cycle (aka the Krebs cycle)
- The main way that nutrients flow into the TCA cycle to become carbon dioxide is first turning into pieces that are 2-carbon units in size
- From carbohydrates, the basic flow is glucose to lactate and then lactate to pyruvate (a 2-carbon piece that goes into the TCA cycle)
- Fat is basically composed of preassembled 2-carbon pieces
  - Fats just get chopped up 2-carbon pieces at a time
- The protein part is a little more complicated, we could probably skip it
- This really depends on the kind of diet you eat
- A carnivore diet is a very interesting side discussion
  - Ultimately, unless you’re gaining protein mass, whatever amino acid carbon you take in (in the form of protein) has to be balanced with [amino acid catabolism](https://en.wikipedia.org/wiki/Amino_acid#Catabolism)
  - Amino acid catabolism is not that different from carbs and fat, just a little in that it can enter the TCA cycle sometimes as  4-carbon pieces
  - A lot of amino acids are broken down in these same 2-carbon pieces
    - There’s just 20 of them (for the [20 amino acids](https://en.wikipedia.org/wiki/Amino_acid))
    - These 2-carbon pieces congeal with a 4-carbon piece to make [citrate](https://en.wikipedia.org/wiki/Citric_acid)
- One of the problems is that the Kreb’s cycle has 3 names
  - 1 – “Krebs” honors the amazing biochemist Hans Krebs who played a key role in figuring it out
  - 2 – The “citric acid cycle” is named for this condensation molecule of the 4-carbon and the 2-carbon piece, citrate
  - 3 – “TCA cycle” stands for tricarboxylic acid, that’s because citrate has 3 [carboxylic acids](https://en.wikipedia.org/wiki/Carboxylic_acid)

***The Krebs cycle is probably 3x as important as anything else in metabolism***

![](https://peterattiamd.com/wp-content/uploads/2022/07/f5-rabinowitz-1024x752.png)

**Figure 5.  The TCA cycle (Krebs cycle) and electron transport chain (ETC).**  Image credit: [*Nature Communications* 2020](https://www.nature.com/articles/s41467-019-13668-3)

- As the Krebs cycle turns, it spits off the 2-carbon pieces that came in as carbon dioxide
  - And in doing this, it takes the electrons that were part of those two carbon pieces and passes them to this famous cofactor ([NAD](https://en.wikipedia.org/wiki/Nicotinamide_adenine_dinucleotide)) to make NADH
  - The H in NADH stands for hydrogen
  - A [hydrogen](https://en.wikipedia.org/wiki/Hydrogen) is really 1 proton + 2 electrons
    - The nomenclature here is confusing
    - H sounds like H+ which is an acid
    - This is an H with 2 electrons stuck to it; *it’s really what we call a* [*hydride*](https://en.wikipedia.org/wiki/Hydride) *or electrical form of chemical energy*
- The H is picked up by NAD to make NADH

**The electron transport chain**

- NADH is what feeds into the electron transport chain
- Here those electrons then flow through a series of proteins that sit in the inner mitochondrial membrane (see the previous figure)

- The mitochondria has 2 membranes
  - The outer membrane is kind of leaky and not as important
  - The inner one is super tight and is highly regulated
  - Most importantly, the inner mitochondrial membrane can be used to pump protons to one side or the other

***Ultimately, it’s the pumping of protons out of the mitochondria that’s the function of the electron transport chain***

- There is a kind of metabolic flux (discussed earlier) where protons get pumped out then flow right back in
  - As they flow back in, they turn a turn style
  - As that turn style turns, it squeezes ADP together to make ATP
    - ADP is an inorganic phosphate

***ATP is the master energy currency used to power our neurons for thinking our muscles for moving and so on***

- Peter comments, “*One of the things about this system that is just so beautiful is the transition from chemical energy to electrical energy, back to chemical energy*”

**The NAD in oxidation reduction reactions central to energy production**

*The energy in chemical bonds*

- You eat a piece of bread, you’re eating glucose
- Glucose (shown below) has carbon to carbon bonds, carbon to hydrogen bonds, and carbon to oxygen bonds

![](https://peterattiamd.com/wp-content/uploads/2022/07/f6-rabinowitz-1024x669.png)

**Figure 6. Glucose, the cyclic and straight-chain structure.**  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Glucose)

*A carbon to oxygen bond is not very energetic, right?*

- CO double bonds are spectacular, they’re super high energy
  - That’s where physics and chemistry want to flow to
  - They want to make these high energy bonds
- In making high energy bonds, you can release a lot of energy
  - Those bonds are very energetically favorable; they’re the end state
- It’s the CH bonds that start out energetically loaded
  - They’re less energetically good in and of themselves
  - They have the potential to become better

**Peter’s takeaway**: **These carbon-carbon and carbon-hydrogen bonds have this potential that the Krebs cycle liberates**

- It takes that chemical energy, liberates it through the electron transport chain, then at the last second, it quickly shunts it back into a chemical bond
  - The chemical bond between the P and ADP to make ATP
- Now we have this energy currency (ATP); there are lots of different ways it can be used

## Explaining “redox” and the difference between oxidation and reduction in chemical terms [1:01:30]

- Oxidation and reduction are always coupled
  - They refer to the movement of electrons
- When electrons go from substance A to substance B, the one that gives up the electrons is oxidized
- The one that receives the electrons is reduced. It’s the subject of reduction.

**How does redox pairing work to facilitate the transfer of electrons down the electron transport chain, in the inner mitochondrial membrane?**

- This is a pair where NAD is the oxidized form, and NADH is the electron holding or reduced form
  - It normally exists in a biased ratio towards a lot of NAD and a small amount of NADH
  - The way nature works is that whenever any pair of chemicals is skewed in one direction, it’s favorable to turn the one that’s abundant into the one that’s less abundant
    - This makes NAD a decent electronic acceptor
    - It’s sitting there prepared to pick up electrons from these carbon intermediates of the TCA cycle that are coming from carbohydrate and fat and take the electrons, make NADH, which then can feed into electron transport chain
    - That backend has to happen fast in order to keep this ratio skewed, ***so you have mainly NAD and not too much NADH***
    - That’s really important because when that NADH starts creeping up, all sorts of things start going wrong
- When NADH goes up, this will drive too many electrons into the electron transport chain
- [Nav](https://www.chandellab.com/) has done a spectacular job showing how this leads to the production of [free radicals](https://en.wikipedia.org/wiki/Radical_(chemistry)#Reactive_oxygen_species)
- Secondly, it gums up metabolism
  - Too much NADH relative to NAD can lead to not having enough ATP and can make signaling things go awry
- Peter recalls, there are clinical scenarios in which we see this happen
  - Often they are a result of toxicities
  - The classic example he learned in medical school, to explain the significance of this whole system, is [cyanide](https://en.wikipedia.org/wiki/Cyanide)

**Cyanide**

- Cyanide is an electron transport chain inhibitor that leads the whole system just backing up bit by bit
  - You can’t then transfer electrons from NADH into the electron transport chain
  - NADH goes way up, NAD falls to the floor, and then you have no way to make ATP
  - That unfortunately leads to rapid mortality
- Peter points out, “*This comes back to the kinetics and the flux, which is, it’s not like cyanide kills you in an hour. I mean, it kills you in seconds. It’s really a sobering thought*.”
- Josh adds, “*ATP turnover, via this system, is on the time scale of a second. Same for NADH. These are things that are just whizzing through our bodies all the time and that we’re constantly dependent on*.”

## How the drug metformin acts on complex I of the electron transport chain [1:05:00]

**Are there less extreme examples of things that will put the NADH/NAD balance in the wrong direction, chronically?**

- Josh doesn’t want to give the misimpression that the right thing is to have as much NAD and as little NADH as possible
- First of all, it’s designed to be a dynamic system
  - If you undergo intense exercise, you’re going to drive NADH up
    - This is a very healthy context for doing this transiently
  - [Metformin](https://en.wikipedia.org/wiki/Metformin) is a super interesting medication and probably works mainly by slowing the conversion of NADH back to NAD, by impairing the [complex I of the electron transport chain](https://en.wikipedia.org/wiki/Electron_transport_chain#Complex_I)
    - Complex I does this initial electron offloading from NADH to make NAD

**How well is the effect of metformin on complex I understood?**

- If you talk to 5 different people who study Metformin, they’ll tell you 5 different things
- Josh explains “*There are many people who know more about this than me, but one thing that we tend to do in our lab sometimes is take these famous metabolic effects, like metformin inhibiting Complex I, and just do a quick test of it*.”
  - About half the time they look to be true and half the time they look to be dubious
  - And metformin was a shining star in our hands in inhibiting Complex I
    - It was one of the cases where I really felt like it may do other things, but it certainly does what it’s supposed to do there; it does that strongly
    - Josh thinks it’s probably the fact that it does it in a relatively liver-specific way due to the way that metformin enters cells of the body that leads to it being safe
    - Metformin may be the world’s most widely used medication is at some level the mechanistic analog of cyanide
- Metformin inhibits the electron transport chain
  - It’s a mechanistic analog of cyanide
  - You have one of the most acutely lethal substances and one of the most widely used drugs working in a remarkably similar way
  - Josh thinks the strong liver specificity of metformin is probably what makes it beneficial for at least a subset of people

**What change in the ratio of  NADH to NAD did Josh observe if you go off metformin and then go back on metformin?**

- Josh is not sure he did this in a way that is clinically applicable, but it’s crystal clear that it goes in the right direction

*Does it surprise you that metformin would raise fasting lactate levels?*

- No, it is certainly aligned to do that
- It’s creating a roadblock for the TCA cycle and electron disposal which gives you more lactate

*Do you think that that’s a neutral effect or do you think that’s a potentially deleterious effect of metformin that is probably offset in a patient with diabetes by the benefits that it has on hepatic glucose output?*

- Josh thinks this is a great question; he doesn’t know
- He thinks having more circulating lactate can be a challenge for clearing fat because they have some sort of competition
  - From that perspective, being in a lower state might have some benefits
  - On the flip side, lactate is a valuable fuel as long as its levels don’t get too high
  - He’s not sure how this all plays out in long-term health

## The difference between NADH and NADPH [1:08:45]

- NADP and NADPH are super important cofactors that live just on the edge of what people who take biochemistry in either undergrad or med school learn about
- Their intrinsic chemistry from the energy point of view is exactly the same as NAD/NADH, but they have a different handle on them chemically that allows biology to use them in a different way
- Their ratio is maintained at a very different level from NAD/NADH
  - So NAD/NADH is super biased towards NAD
    - This is much more of an even pairing, which means there’s much more driving force to dump the electrons off rather than to absorb them up
- NADPH is second only to ATP as a master energetic building material
  - The most important example, it’s used to assemble fat
  - Fat is made by taking 2-crobon pieces from carbohydrate and adding electrical energy in the form of NADPH
- NADPH is used in all sorts of other really interesting ways to fight [reactive oxygen species](https://en.wikipedia.org/wiki/Reactive_oxygen_species)
- It’s also used if you’re trying to kill bacteria, to intentionally make reactive oxygen species
  - Josh notes, “*This is where biology is freaking confusing and complicated, and there’s definitely the yin and yang that you have this awesome cofactor, that’s so important for fighting oxidative stress and also can be used to create boat loads of oxidative stress intentionally when it’s needed.*”

## NAD levels with age, and the efficacy of supplementing with intravenous NAD [1:10:45]

- 7-8 years ago it started to become fashionable for people to talk about supplementing with NAD

*Was part of the impetus for this the observation that as we age, cellular NAD levels decline?*

- We’ll put [sirtuins](https://en.wikipedia.org/wiki/Sirtuin) aside because that story keeps changing
- The first principles in this field are great‒ NAD plays this super central role in energy generation that we all want to feel more energetic
  - Whether you want to be a more extremely successful athlete at age 21
  - Or whether you want to feel at age 50, like you’re 21
- So you think, if we could just turn up the burner capacity, this would be absolutely fantastic
- Then we have this data that NAD is depleted with aging
  - Josh points out when he does these measurements, we agree that NAD is depleted with aging, but it is a lot more subtle than you would think looking at the literature
  - These are really quite subtle NAD depletions observed with aging, around 10-20%
    - This is in the 3-fold range discussed earlier, where a lot of metabolites live on a daily basis

> “*Oh, wow, I didn’t realize it was that little*”‒ Peter Attia

- Josh is not saying that in some tissue of an aged human, there might not be bigger effects

**Josh’s takeaway:**

- On one hand, it’s a robust finding that this is something that changes with aging with a central metabolic role
- On the other hand, it’s something that happens with a fair amount of subtlety
- This is the first caution he would give to people thinking that they’re going to fix everything through NAD

**How is NAD measured?**

- ATP is very difficult to measure because it doesn’t stick around a very long time
- NAD (unlike NADH) is not a super transient metabolites
- NADH measurement is wickedly difficult
- Most of this NADH/NAD para sits as NAD, and NAD tends to sit around for a hour-ish timescale
- You don’t have to flash freeze tissue or things like that
  - There is more flexibility in making those measurements, as long as you’re not irritating the tissue in a way that leads to massive NAD degradation
    - But many  people may do this sometimes by accident
- Like ATP, NAD is a tissue metabolite, not a circulating metabolite
  - So you need biopsy specimens to measure it
- Josh is not a master of the literature on NAD levels in human tissues
- His not-fully informed perspective is‒ we don’t have as many of these measurements as we should have
  - And that’s because it’s hard to get biopsies from people

*If you take whole blood, can you look at the NAD levels in* [*PBMCs*](https://en.wikipedia.org/wiki/Peripheral_blood_mononuclear_cell) *with relative ease?*

- Josh thinks this is a good question because there is quite active NAD metabolism in immune cells (PBMCs)
- He works a lot in mouse; they take tissues, freeze them, extract metabolites, and do [mass spectroscopy](https://en.wikipedia.org/wiki/Mass_spectrometry)
- He sees a consistent decline in NAD with the aging animal by 10-20%
  - It’s not a fold-reduction

**Peter’s hypothesis‒ if you restore NAD levels in an old organism to the level they had when they were young, will the old organism feel and perform like the young organism?**

- Similarly, if you induce super normal levels of NAD in any organism, will they feel super normal?
- 7-8 years ago, NAD clinics started popping up all of the the place saying they will give you and IV of NAD

*Why did they administer NAD intravenously?  Why not make a pill?*

- NAD (aka nicotinamide riboside) and its precursors are broken down in the gastrointestinal tract
  - If you take it NR orally, it will mainly enter the body in the form of [nicotinic acid (aka niacin)](https://en.wikipedia.org/wiki/Niacin)
    - This is a healthy substance, but your body is not seeing nicotinamide riboside (NAD)

> “*There’s no known absorption route for NAD*”‒ Josh Rabinowitz

**What happens when a person receives intravenous NAD?**

- One of the things in metabolism and biology is anytime you put something in a vein, you bypass the liver and the [first pass effect](https://en.wikipedia.org/wiki/First_pass_effect)
- NAD is going to get broken down partially because there are not clear uptake mechanisms known, to get NAD from the bloodstream into cells
- Nicotinamide mononucleotide (NAD) may be able to enter cells directly, or [nicotinamide riboside (NR)](https://en.wikipedia.org/wiki/Nicotinamide_riboside)
  - NR is a partially broken down form of NAD, but they are nevertheless meaningfully closer to NAD than the normal things that circulate in good amounts in our bloodstream
  - Partially broken down NAD precursors can be taken into cells and rebuild NAD in a shortcut manner that probably has a good chance to bolster NAD levels
- Certainly at least some important cell types in the body can take up NR and [NMN](https://en.wikipedia.org/wiki/Nicotinamide_mononucleotide), maybe pretty broadly, but Josh doesn’t know, off the top of his head

**Once NR or NMN gets into the cell, is it relatively straightforward to reconstitute NAD?**

- Yes, this is a favorite reaction and does not have a big energy demand
- The big energy flow is through this NAD and NADH exchange
- The making of NAD itself is not an expensive process per se
- NAD stands for nicotinamide adenine dinucleotide; It’s two kind of nucleotide pieces put together
- When you take in NR or NMN, it’s one of those two pieces
- But the more interesting side comes from ATP, and it’s there all the time, because all your cells have ATP
  - And so you just snap it together
- Josh thinks you probably end up with effective NAD supplementation when you go the IV route

**Peter’s takeaway: Taking IV NAD will probably increase intracellular NAD levels, though, not directly because there’s not a transporter**

- It goes through a circuitous route to get there

**This corrects a statement Peter has made in the past‒ “*****Intravenous NAD is not a good way to get NAD because we don’t have a transporter*****”**

- This statement is correct, but incomplete
- In other words, if you take 100 units of NAD intravenously infused, we don’t really know how many units ultimately make their way into a cell, but it’s probably not 100
  - Josh thinks there is a fair amount of loss in the process
- [CD38](https://en.wikipedia.org/wiki/CD38) is a very interesting protein; it’s designed to control these kind of pathways
  - It’s a suppressor of NAD levels
  - It works by breaking down NAD that’s outside of cells
    - In normal physiology, there isn’t meaningful amounts of NAD outside of cells, but there is NMN in meaningful amounts
  - This is a protein that’s super good at breaking down NMN; it leaves you with NR
    - So it’s one step further away from being NAD, but it’s still meaningfully closer than your typical physiological precursor
  - It’s positioned to boost NAD, at least in some places in the body

## The usefulness of restoring NAD levels and efficacy of oral supplementation with NAD precursors NR and NMN [1:22:15]

- Peter thinks the majority of efforts to increase intracellular NAD are done through oral precursors, [NR](https://en.wikipedia.org/wiki/Nicotinamide_riboside) and [NMN](https://en.wikipedia.org/wiki/Nicotinamide_mononucleotide)
  - These are pretty similar

*Is there a convincing argument as to why one should be the preferred substrate?*

- NR and NMN are approximately equivalent approaches

*What are the gastrointestinal effects of NR and NMN?*

- They get broken down all the way to the level of [nicotinic acid (aka niacin)](https://en.wikipedia.org/wiki/Niacin)
  - This is the main way they enter the body
  - It doesn’t mean that there can’t be a trickle of them entering some other way that has a physiological effect or that there’s some local effect or some effect on the microbiome of taking them
  - Biology is super complicated; there are ways that these could be doing interesting health-supporting things
- Josh doesn’t think they’re fundamentally different than taking a physician prescribed niacin pill from the perspective of providing NAD precursors
- Peter recalls that physicians used to prescribe niacin for [hyperbetalipoproteinemia (high cholesterol)](https://en.wikipedia.org/wiki/Familial_dysbetalipoproteinemia); he doesn’t remember to exact dose but it was on the order of grams not mg
  - It was not uncommon to get a real flush from niacin

*Is the reason people don’t experience a flush with NR and NMN, because they’re typically taking only 500 mg to 1 g?*

- Yes
- NR and NMN are also niacin [prodrugs](https://en.wikipedia.org/wiki/Prodrug), so their conversion to niacin is delayed and they may be better tolerated

**Josh’s lab has done some flux work with NR and NMN, what has he learned about what tissues they end up in when given orally?**

*What is the effect in the liver versus the muscle versus the plasma?*

- The main finding is both NR  and NMN are converted to niacin
  - They raise niacin levels in the portal circulation that connects your intestine to the liver
    - So heading out of the intestine and to the liver
- They boost their own circulating levels in a subtle or vanishing amount
- NR and NMN are less abundant in the bloodstream than [nicotinamide (NAM)](https://en.wikipedia.org/wiki/Nicotinamide)
- Nicotinamide (NAM) is what the liver normally produces to feed NAD precursor to the tissues of the body

***Josh’s conclusion from his research‒ there is no clear route for oral NR or NMN to produce circulating levels of NR or NMN that are high enough to compete at a standard concentration level with NAM***

- NAM is the body’s way of feeding NAD precursors to tissues

> “*They [NR and NMN] don’t change… what most of your tissues are seeing that much*”‒ Josh Rabinowitz

**What are the opportunities to be misled in these measurements?**

- There could be local effects of NR or NMN on the intestine that are really important
- The availability of NR and NMN could impact the microbiome in important ways
  - The microbiome can have big effects on health
- It could be that even with the small amounts of NR that reach the liver (or even lower amounts that reach the heart or something), there are a subset of cells there that may prefer to use NR
  - Maybe these cells are deficient in using NAM
  - So maybe getting even small amounts of NR to those cells is meaningful

***Josh’s base assumption is that often the obvious is true, and here the obvious would be the physiological system just isn’t that impacted by this particular type of oral supplement***

**Is there a chance that with chronic administration of NR or NMN you’d see something different?**

- Josh points out, “*Human can be different than mouse… We haven’t done these experiments in humans.  Chronic versus acute, there’s a bunch of variables that could alter things*.”

**If the hypothesis is true, that restoring intracellular NAD levels at age 50 to the level they were at age 20 would improve some measure of performance, what do you hypothesize would be the most efficient way to restore NAD levels?**

- IV is a promising way to do this restoration
- Josh is not very convinced about the first hypothesis
- In the big history of medicine, things are way more complicated than people can envision
  - Hormone replacement therapy is one of the great examples
  - Peter points out the [Women’s Health Initiative](https://www.ncbi.nlm.nih.gov/books/NBK236522/#_ddd0000074_) was a randomized experiment, but it was really misinterpreted and initial findings have been overturned

**Medicine is complicated, as exemplified by study of hormone replacement therapy and the Women’s Health Initiative [1:28:45]**

*Findings on breast cancer in the WHI*

- Epidemiological studies from the ‘80s and ‘90s showed giving women hormones, post menopause was a good thing
- Then the Women’s health initiative said this was a bad thing
  - Peter thinks this is misleading
- If you go back and look at the Women’s Health Initiative, it’s an awful example of how to misinterpret a study
- There was no increase in the risk of breast cancer
  - And if there was, it probably had nothing to do with the estrogen the women were given
- This study looked at 2 parallel groups, women with a uterus and women without a uterus
  - Women without a uterus were randomized into 2 groups:
    - Placebo or estrogen
  - Women with a uterus were randomized into 3 groups:
    - 1 – Placebo
    - 2 – [Estrogen only](https://en.wikipedia.org/wiki/Estrogen) in women
    - 3 -Estrogen + [MPA (the synthetic progesterone)](https://en.wikipedia.org/wiki/Medroxyprogesterone_acetate)
  - For women without a uterus, given estrogen the [hazard ratio for breast cancer was 0.77](https://jamanetwork.com/journals/jama/fullarticle/198540)
    - This didn’t quite reach statistical significance
    - This trended towards estrogen actually reduced the risk of breast cancer
  - In women with a uterus, given both estrogen and progesterone
    - The [hazard ratio for breast cancer was 1.26](https://jamanetwork.com/journals/jama/fullarticle/195120)
    - The *p-*value was around 0.05 or 0.049
    - This is about a 25% increase in the risk of breast cancer

***But to talk about an increase in relative risk without talking about the absolute risk is irresponsible; the change in absolute risk was 0.1% or 1 in 1,000***

- This difference in relative risk versus absolute risk is important
- This says nothing about a lot of other methodologic issues with the study
  - A more plausible hypothesis was that the MPA (progesterone) was more the issue than the estrogen
    - *But the estrogen gets all the attention‒ so estrogen causes breast cancer*
- These findings were not held up in subsequent studies

***Peter’s takeaway: in 10 years, we’ll look back and see what happened to a generation of women who were deprived of  hormone therapy as really unfair and  due to a poorly interpreted study***

**Findings on cardiovascular disease (CVD)**

- There probably is a slight increase in risk of CVD with oral estrogen because of the hypercoagulability
- Today, very few women on hormone replacement therapy are given oral estrogen
  - The preferred route of administration is a patch, something like a [Vivelle-Dot](https://en.wikipedia.org/wiki/Estradiol_(medication)) where you’re given topical estradiol, and this provides many benefits (below) without any of the hypercoagulability and cardiovascular risk
    - Reduction of vasomotor symptoms
    - Incredible benefits on bone health
- Now we actually see the reverse, a statistically significant reduction in cardiovascular mortality

*Josh points out this is a great example where the drug has to be given by the right route of administration to see a health benefit*

- Another example is [NSAID](https://en.wikipedia.org/wiki/Nonsteroidal_anti-inflammatory_drug) and [Advil](https://en.wikipedia.org/wiki/Ibuprofen)
  - People knew they had a lot of side effects but everyone assumed they were counterbalanced by the fact they were reducing coagulability, and that would be cardioprotective
    - Most people don’t believe this anymore

## Exploring the hypothesis that boosting NAD levels is beneficial [1:32:30]

**Josh’s take on the hypothesis that boosting NAD levels is beneficial**

- Josh accepts that a 10-20% reduction in NAD levels as we age is likely true
- But at this point in time, Josh does **NOT** think that if we could deliver 20% more NAD to a 50 year old, it would improve their quality or length of life

> “*These things involve such complicated interplay of different organ systems*”‒ Josh Rabinowitz

- Josh is open to the idea that NAD supplementation may turn out to be super valuable medically

**If NAD supplementation is beneficial**

- If this is true, he thinks it will be because there are select cell types that are severely NAD depleted
  - We will need to figure out how to restore NAD in those cell types
  - Then we may see big health benefits
- It’s also possible that the general intravenous supplementation is hitting those cells and correcting this depletion
- He  thinks it’s equally possible that it’s having some adverse effect that’s going to be net negative for people

***We don’t know the science well enough, and we certainly haven’t done the clinical experiment well enough to give good health guidance yet***

**Peter stands corrected**

- Peter remarks that he stands corrected, “*I just want to apologize to all the people over the years that I’ve said, intravenous NAD is not getting in your cell. I stand corrected. Indirectly… it may actually be getting into at least some cells*.”

**How would you begin to tackle the question‒ are there certain cell subtypes that may benefit from boosting NAD levels?**

- Peter hasn’t seen a single convincing clinical study in humans using either NR or NMN that has made him excited about this
- Peter is not a stranger to putting things in my body without absolute perfect information
  - [Rapamycin](https://en.wikipedia.org/wiki/Sirolimus) is a good example; he’s been taking it for 4-5 years
  - There is good evidence for rapamycin but it’s far from perfect
  - We’re never going to have a definitive human clinical trial
- Peter asks, “*If I’m willing to take rapamycin, why am I not taking NR? And why am I not taking NMN?*”
  - Because he can’t find a shred of compelling evidence to tell him to do so

*Josh’s recommendations*

- First we need to do a better job mapping the basic pharmacology of NAD in animals and humans
  - This is doable and something the field is doing
- *We need to look at cellular resolution rather than bulk resolution*
- Josh is working hard to develop the ability to take a slice of tissue and determine the heterogeneity of NAD levels across cells
- It will be helpful to know if there is a scattershot in aging and if it’s homogenous in young people
  - This will tell us if all we need is 1 in 10 cells at anytime to be NAD depleted
  - Is a 10% reduction in NAD levels 1 out of 10 cells depleted for NAD, instead of some tiny wiggle down?

> “*I think this is going to be a really important measurement*”‒ Josh Rabinowitz

- It will take the field a few years to get there
- Ultimately we need successful clinical experiments
- There have been persuasive experiments in animals
  - There are experiments on reversing bad outcomes after renal ischemia
  - It would be good if we could find niche experiments where there’s a very strong effect in animals, a very quick clinical readout of ischemic renal event
    - Then you can test to see if supplementation provides a benefit or not

**Josh’s takeaway:** ***Conceptually, we need to find the strongest animal proof of concept that can be translated into a small, but definitive clinical trial and prove that this really can do something beneficial in the right context. And then from there you can think about kind of expanding the indication to general health betterment.***

***Who would fund this?***

- Indirectly through the [ITP (Interventions Testing Program)](https://www.nia.nih.gov/research/dab/interventions-testing-program-itp), [Rich Miller](https://www.richmillerlab.com/), [Randy Strong](https://www.uthscsa.edu/academics/medicine/profile/strong) *et al.* have already done an NR test in their very rigorous tried and true model
  - This failed; NR did not extend life
- Josh’s group tries to hel the real NAD expert labs by doing the flux studies
  - They facilitate measurements
  - It’s not the bread and butter of his research
  - Broadly speaking, he’s an observer
- He believes there is money in the NIH for this question that is central to metabolism and health
- He also thinks biotech is interested in ways to do this pharmacologically
- For [CD38 inhibitors](https://en.wikipedia.org/wiki/CD38-IN-78c), there’s a whole different financial structure there if you can make a patent approved medicine

**What are the top labs studying NAD and its precursors or ways to increase it?**

- Josh replies, “I’m too much of an outsider to get into naming names on that… other than to credit [Jo Baur](https://www.med.upenn.edu/baurlab/people.html) for being a fantastic collaborator”

## Cancer metabolism and the intersection with immunotherapy [1:39:00]

**How did Josh become interested in cancer metabolism?**

- Peter and Josh reconnected 5-6 years ago at a conference on cancer metabolism
- Josh was fortunate to be at Princeton, which is this academic bubble where he could do experiments on *E. coli* and yeast, and set up these good metabolic measurements unmolested
- He got a call from the head of the Penn Cancer Center (at that point in time it was [Craig Thompson](https://www.mskcc.org/research/ski/labs/craig-thompson)), saying he wanted to visit
  - That was a life-changing call because it brought him into the world of biomedicine, in the context of working on cancer metabolism
  - Craig left Penn to go to [Memorial Sloan-Kettering](https://en.wikipedia.org/wiki/Memorial_Sloan_Kettering_Cancer_Center) shortly after

**There is a very natural connection between metabolism and cancer**

- The first great rational triumph in treating cancer was [antifolates](https://en.wikipedia.org/wiki/Antifolate) and [Sidney Farber](https://en.wikipedia.org/wiki/Sidney_Farber)
  - His name is memorialized on the [Dana-Farber Cancer Center](https://en.wikipedia.org/wiki/Dana%E2%80%93Farber_Cancer_Institute)

*This is really the origins of how cancer was rationally treated by targeting metabolism*

- This was under studied for so many years and it was a very natural reentry point for Josh because you can study cancer in isolated cells in a culture dish
  - Since his lab was studying *E. coli* and yeast that was much more comfortable to him in the 2008 than trying to work on mice
    - Though he’s delighted they got back to mice a few years after that

Peter notes cancer metabolism is a booming field today

- He would love to have Craig Thompson on the podcast; he’s had [Lew Cantley](https://research.cornell.edu/researchers/lewis-c-cantley) on  ([episode #110](https://peterattiamd.com/lewcantley/))
- Cancer metabolism and immunotherapy are really 2 of the most promising and exciting areas of cancer research today
  - And they didn’t hear a single word about either in medical school
  - Maybe there was something about antimetabolites for cancer hidden in a pharmacology book
- One of the most exciting things is going to be the interface of those 2 fields
- The composition of the [microbiome](https://en.wikipedia.org/wiki/Human_microbiome) is predictive of whether immunotherapy works
- [Jennifer Wargo](https://www.mdanderson.org/research/departments-labs-institutes/labs/wargo-laboratory.html) has amazing work showing that fiber can promote the effectiveness of immunotherapy
  - It remains to be determined if this is soluble or insoluble fiber

**What makes the metabolism in a cancer cell different?**

- Even when you compare cancer to their non-cancer counterparts in the same tissue, there are differences
- The 2 hallmarks of cancer are
  - 1 – The inability to respond to cell cycle signaling; this is why it keeps growing
  - 2 – The capacity to metastasis; cancer cells leave and grow in a new site
- Peter asks: *What is it about them metabolically that also is a piece of their signature*?
- *Cancers tend to be glucose users*, says Josh
- In the fasting state, glucose use is weird and not the default
  - The default is to use fat and lactate
- Cancer uses glucose in large part because they’re programmed internally to basically feel like they’re always seeing insulin
  - This occurs through mutations in the [PI3 kinase pathway](https://en.wikipedia.org/wiki/PI3K/AKT/mTOR_pathway) that Lew Cantley pioneered
- Cancer is positive on an [FDG PET scan](https://en.wikipedia.org/wiki/Positron_emission_tomography), so they’ll constantly take up and phosphorylate (to trap) glucose or glucose analogs
  - This is why FDG PET is the most sensitive way to detect most types of cancer
- Downstream from this, there are a ton of metabolic changes in cancer cells
- 1 – The most fundamental change is uncontrolled [nucleic acid](https://en.wikipedia.org/wiki/Nucleic_acid) synthesis
  - This is needed to support uncontrolled growth
  - This was targeted initially by Farber and by many subsequent medications that are still widely used today
    - [Pemetrexed](https://en.wikipedia.org/wiki/Pemetrexed) is first line treatment for lung cancer
- If you get these medications right, you can induce mutations through the metabolic stress on the nucleotide system and *this can make immunotherapy work better*
  - Immunotherapy as gotten understudied as cancer metabolism has returned to the fore
  - There’s been a lot of focus on fuel usage cutoff, which is tough because like most cells in the body, cancer cells can use a lot of different types of fuels depending on what’s available

**Why starving your body of glucose doesn’t totally kill cancer [1:44:30]**

*It’s natural when people hear that cancer loves glucose that they think the solution is to stop eating glucose*

- The problem with that logic is no matter how little glucose you eat, you still have plenty of glucose in your circulation, even if you’re in a complete state of starvation.
- [George Cahill’s](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.) work, 40 days of starvation, they still had 3 mmol of glucose in their circulation 40 days out

*So there is no way to eliminate glucose*

- Getting glucose below the healthy 89 mg/dL is very difficult

- Peter rationalizes that minimizing [insulin](https://en.wikipedia.org/wiki/Insulin) may be more important than minimizing glucose
- *The idea of starving cancer seems potentially overly simplistic*
- Even if you can get your glucose below 89, there are other fuels cancer can use
  - Glycogen, amino acids, fats, lactate, and ketone bodies
- You cannot cut off the fuel supply for cancer without affecting some other critical tissue
  - Disrupting the function of immune cells or the brain would be a more acute disaster

## Making cancer a chronic disease: exploiting the metabolic quirks of cancer, augmenting the immune system, and more [1:46:15]

*There is an idea about exploiting the metabolic quirks of cancer in a way that augments the immune system*

- Peter has a bias, which is cancer is going to be hard to control so a better strategy is to use multiple modes of action instead of pulling really hard on just 1 lever

*Josh points out there are lot of moves to try to make cancer into a chronic disease where the therapies are not so terrible*

- Hitting the nucleic acid side of cancer for people aiming for maintenance therapy
- We need a fresh approach to that whole side of cancer metabolism because think there are targets waiting to be developed
- If you can create nucleotide imbalances, which is a natural thing to do when you hit that system, then nucleotide imbalances are drivers of mutations and mutations in cancer cells are drivers of immune response to cancer
  - Interrupt the ability of cancer cells to synthesize DNA and this will result in more mutations
  - More mutations create more targets for the immune system
- Another exciting avenue is to apply a very strong stress to the cancer while putting pressure on their fuel supply
  - It will be difficult to put so much pressure on the fuel supply, that this alone will slow tumor growth
  - But if you combine it with chemotherapy, that’s already targeted to the tumor
  - And then you pair that with something like ketogenic diet, which is lowering insulin, lowering glucose
  - Studies in animal models show this can be a very powerful combination
- We see that the tumors start to deplete glucose in response to the chemotherapy, whether that’s because their vasculature is breaking down or whether that’s because they have hiding glucose demand because they’re having mitochondrial damage from the chemotherapy
  - Chemotherapy lowers glucose in the tumor intrinsically, and then if you come in with a diet that lowers glucose availability, this becomes stronger and then you can get to really low tumor glucose
  - Josh has seen some pretty big improvements in outcome in mouse experiments
    - Hopefully they’ll translate to the clinic
    - He has a clinical trial open on this now

**What’s the best tool we have to interfere with nucleic acid synthesis in cancer cells? Is it old school chemotherapeutics?**

- *For the moment, yes*
  - [Pemetrexed](https://en.wikipedia.org/wiki/Pemetrexed) is probably the most successful clinical agent
  - Other good ones are [gemcitabine](https://en.wikipedia.org/wiki/Gemcitabine), but we need to think fresh
- Josh reflects, “*When we were in medical school, I thought we would not see a cure in our lifetimes for hepatitis… but look at that now*”
  - [Nucleoside analogs](https://en.wikipedia.org/wiki/Nucleoside_analogue) have mainly cured hepatitis

> “*There’s clearly untapped potential there*”‒ Josh Rabinowitz

- Josh’s guess is that the chemistry has evolved a lot in the past 40 years and this area is ripe for rediscovery

## The challenge of treating pancreatic cancer [1:50:30]

**Pancreatic cancer**

- It’s interesting that Josh mentioned gemcitabine because this is one of the first line agents for pancreatic cancer
- Pancreatic adenocarcinoma is the cancer Josh has worked the most on
  - It’s a horrible disease
  - It’s the [4th leading cause of cancer death](https://www.cancer.gov/types/pancreatic/hp/pancreatic-treatment-pdq#_7_toc) in the US, in both men and women
  - It’s 95% lethal and Peter has heard it argued that the 5% who don’t die are misdiagnosed
- [FOLFIRINOX](https://en.wikipedia.org/wiki/FOLFIRINOX) is progress for treating pancreatic cancer
  - Even more patients respond if you combine [gemcitabine](https://en.wikipedia.org/wiki/Gemcitabine) and [abraxane](https://en.wikipedia.org/wiki/Protein-bound_paclitaxel) (an albumin-bound form of paclitaxel) with a [platinum agent](https://en.wikipedia.org/wiki/Platinum-based_antineoplastic)
  - That triple combination produces regressions in most patient’s tumors
  - But the regression is not durable and that’s what kills them

“*The duration of response is terrible right now, but the fact there’s response is promise*”‒ Josh Rabinowitz

- From Josh’s perspective, once you can start seeing a response, you’re on the road
- Now they have to figure out how to make the response durable
- He hopes that’s where the metabolic part becomes important

***There is going to be some interface of the metabolic part of treatment or the immune part or a harder hit with chemo or radiotherapy, or earlier diagnosis that fixes this***

**Other gastrointestinal adenocarcinomas**

- These are all really bad diseases
- Peter points out, “at least with those stage one, certainly stage one colorectal cancer is survivable. Hepatocellular is a bit tougher, but you’re better than a coin toss”
- 80-85% of patients with stage I pancreatic cancer die

*What is it about pancreatic adenocarcinoma that is so difficult, and is it simply that its rate of early metastasis is so early that stage I is just a misnomer term (there’s no such thing as stage I)?*

- Josh thinks this is a big part of it
- The pancreas is a soft organ and this cancer is very invasive
  - You can have local invasion in so many places in the body from that site
- Plus there is immediate access to the portal system that’s constantly seeding the liver
- Anatomically it’s problematic for keeping the cancer self-contained
- Metabolically it’s a very tricky cancer
  - It’s almost solely driven by mutations in the [ras proto-oncogene](https://en.wikipedia.org/wiki/KRAS)
  - Peter summarizes, “*This is an instruction manual for the cancer cells, not just to divide, but to do a bunch of metabolic things that involve scavenging nutrients from the environment and taking in nutrients in non-standard ways. And so it actually instructs the cancer cells to reach out arms, pull in nutrients, internalize them, degrade macromolecule nutrients from the environment and use this as a garbage recycling form of nutrient access that makes them very metabolically pernicious*.”
  - In mouse models of pancreatic cancer, they don’t have to be very metabolically active to be horribly lethal
- The pancreas is a master protein producing organ
  - Insulin is the most famous protein to come out of the pancreas
  - The bulk of the pancreas is not beta cells (that make insulin), it’s [exocrine pancreas](https://en.wikipedia.org/wiki/Pancreas)
- The exocrine pancreas is just making digestive enzymes like crazy
  - It does by far the fastest protein synthesis in the body
  - The cancer turns that protein synthesis way down so it’s not hyper metabolic
  - It has this huge capacity to make stuff that even when turned-down, it still has enough biosynthetic capacity to grow and divide and grow and divide
  - And because it’s turned down its main energy consuming, normal function of protein synthesis, it can function with much reduced [TCA](https://en.wikipedia.org/wiki/Citric_acid_cycle) activity, reduced ATP synthesis rates
    - It’s very, very efficient

## Epithelial cancers that might respond to metabolic approaches to therapy [1:56:30]

- [Pemetrexed](https://en.wikipedia.org/wiki/Pemetrexed) is being used effectively in lung cancer
- Cancers with mutational burdens are the ones where you’re getting the good immunotherapy responses
  - Whether they’re ones that are particularly susceptible intrinsically to metabolic effects, Josh doesn’t know
- Josh dosen’t think metabolic approaches are going to be the standalone part of treating any of these cancers
  - Instead, it’s more of a key piece of the puzzle in getting enough, either drug killing by preventing their metabolic escape mechanisms, or enough immune activity
    - And those may be opposites
    - So you may also need cyclic therapies where you go through rounds of metabolic suppression in order to keep things calm while you can, and then periods of metabolic augmentation that are really directed at augmenting the immune system

***I’m a big believer that there’s metabolic limitations on immune response to cancer and that if we can overcome them, we will have major therapeutic benefits***

**Ras in pancreatic carcinoma**

- Ras is a driver mutation in pancreatic cancer but the irony is, ras is rarely immunogenic
- You need more antigens for the immune system to target

**Do you have a sense of how many tumor infiltrating lymphocytes are typically identified in resected, pancreatic specimens?**

- *It’s typically quite the* [*lymphocyte*](https://en.wikipedia.org/wiki/Lymphocyte) *desert*
- There is a ton of macrophage activity in pancreatic cancer
  - Maybe [macrophage](https://en.wikipedia.org/wiki/Macrophage) rewiring is going to be a big part of allowing lymphocytes to enter
  - These are areas where Josh thinks metabolism can be impactful

## Josh’s hopeful outlook on the future of cancer treatment [1:59:00]

**⇒** ***Josh’s big hope on this front is that we’re going to be able to have some combination of directed, metabolic immune supplements, and diet that work with therapy to treat cancer***

- Because things are metabolically messed up in tumor cells, he’s hopeful that either some sort of supplement or diet will make immunotherapy work for the majority of patients
  - Currently immunotherapy only works for about 10% of patients

## Nutritional approaches to cancer attenuation [2:00:15]

*Besides reducing insulin, what are other metabolic levers to pull with diet?  Is there any evidence that amino acid restriction or other nutrient restriction could play a role?*

- Amino acids are complicated, but they hold a lot of potential
- The type of fat can be important
- [Saturated](https://en.wikipedia.org/wiki/Saturated_fat) and [unsaturated fat](https://en.wikipedia.org/wiki/Fat#Unsaturated_fat) are very different and will play different roles in cancer
- There is nice work from [Matt Vander Heiden’s](https://biology.mit.edu/profile/matthew-vander-heiden/) lab showing that a higher saturated fat [ketogenic diet](https://en.wikipedia.org/wiki/Ketogenic_diet) could be more tumor suppressive in some context because tumors have trouble making unsaturated fat in the context of [hypoxia](https://en.wikipedia.org/wiki/Hypoxia_(medical))
  - Matt is the head of the Koch at the MIT Cancer Institute
  - A ketogenic diet that was higher in saturated fat posed a greater problem for the cancer cells because they couldn’t make, presumably, the essential unsaturated fats
  - This is an interesting strategy
  - The effects were relatively subtle but could be part of the picture
- Josh thinks the exciting part of diet is how it connects to the [microbiome](https://en.wikipedia.org/wiki/Human_microbiome)
  - We need to understand the role of fiber and maybe total protein
- There are a lot of things we can do with the timing of macronutrients that can be interesting
  - Maybe we need to not just think about cycling fasting, and feeding
  - For example, maybe there’s a time maybe when you want to come in with a lot of carbs in the absence of protein and that may achieve something that creates a particular immune milia
    - And then you need protein in the right timing after that
- Peter replies, “*It seems like an eternity before we’d be ready to study this in a human clinical trial because the permutations are so many. Do you feel like we have high throughput animal models where we can test these hypotheses and say, we’ve looked at 10 ways to do this in animals, but these are the three most promising so we’re going to go ahead and do these now?*”
- The good animal models of cancer are still not that high throughput and there’s a lot of challenges converting animal diet and human diet
- Josh will come out with some work showing that some of the most exciting dietary combinations are absolutely effective in animals, but they’re not effective through the mechanisms that people thought before
  - *Because even in animals trying to get the diets aligned so that you really isolate variables is tough*
- Josh thinks the fact that we’re asking these questions that haven’t been asked before is going to build momentum and we’re going to build this interface out over the next 5 year period in animals
- And clinical work will take be done in this field in parallel
  - Josh hopes that will have an impact on patients lives within the 5 to 10-year timeline

**Do you worry about the challenges of patients adhering to the right diet?**

- Assume 10 years from now the answer is a cyclic ketogenic diet that has this much saturated fat, this much monounsaturated fat, this much polyunsaturated fat, this much glucose on this day, this much protein on that day.
- Josh replies that the diet has to be simple
  - *It has to be clinically actionable*
- He mentioned earlier the potential of immunotherapy and fiber
  - The question of is it soluble fiber or insoluble fiber is important
  - Then there are different flavors of soluble fiber
  - Maybe it’s the mix of fiber, maybe it’s one isolated molecule
- Josh has 1 tiny molecule/ metabolite that will more than double the number of complete responses to immunotherapy observed in mice

**Could this be nutritional supplements as opposed to wholesale dietary changes?**

- It could be supplements
- The dietary changes may be in an acute way, how the patient comes in the hospital for a tough bout chemotherapy or a tough surgery
  - Maybe we’re going to go to a place where we take people’s glucose in the hospital, almost down to zero for 12 hours with a deep ketosis and some pharmacotherapy at the time that we hit them really hard with chemo, and 24 hours of that it’s like night and day in terms of the overall effect
  - *But it can’t be asking patients to give up eating and giving up the joy of food*
- Another trial Josh’s group is starting now as a trial with a [SGLT2 inhibitor](https://en.wikipedia.org/wiki/SGLT2_inhibitor) plus a low carbohydrate diet (but not fully ketogenic diet), to see if it can put people in ketosis
  - This will assess if this is a way for cancer patients to get the benefits of ketosis while still allowing them to have a little bit of breaking bread with the family

## What makes Princeton University special [2:06:15]

**Princeton is the only Ivy League School that doesn’t have a medical school.  What is the reason for this?**

- At its heart, Princeton is a hybrid of a college and a university
- It is an institution that has the ultimate priority of undergraduate education
  - It’s committed to that, it’s best in world in that
  - In assessing how to be best in the world at undergraduate education, the Princeton administration many times has asked the question, *is having medicine on campus part of that?* And the answer has always been, *no*
  - They choose a somewhat more pure intellectual environment and keep their focus on providing the very best training for undergraduates

**Princeton doesn’t have a business school or law school either.  I guess it’s the same argument.**

- Correct; this makes it very special
- It’s good to have special places that are distinct

**Are you at all a fan of** [**Richard Feynman’s**](https://en.wikipedia.org/wiki/Richard_Feynman) **work?**

- At a very light level, yes
- Josh read a giant [biography of Oppenheimer](https://www.amazon.com/American-Prometheus-Triumph-Tragedy-Oppenheimer/dp/0375412026/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1654001864&sr=8-1) and the [film](https://en.wikipedia.org/wiki/Oppenheimer_(film)) of that on campus and became a small Oppenheimer fan after reading that intensive book
- Peter has 3 of Feynman’s books, meaning books that were actually his
  - Peter has his Table of Integrals from when he was in high school, and then two more books on advanced calculus
    - One from when he was at Princeton
    - One from when his first professorship at Cornell
  - His scribblings, his notes are sacred
  - He’s never made the pilgrimage to look for his eating club and things like that, it probably doesn’t even exist anymore

> “*There definitely have been some awesome Princetonians*”‒ Josh Rabinowitz

- Josh’s kids went to nursery school in the building where Von Neumann built the first computer
- It is amazing the amount of stuff that happened at Princeton

§

## Selected Links / Related Material

**Previous episodes of** ***The Drive*** **focused on NAD**:

- [#148 – Richard Miller, M.D., Ph.D.: The gold standard for testing longevity drugs: the Interventions Testing Program](https://peterattiamd.com/richardmiller/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (February 8, 2021) | [2:30]
- [#70 – David Sinclair, Ph.D.: How cellular reprogramming could slow our aging clock (and the latest research on NAD)](https://peterattiamd.com/davidsinclair2/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (September 9, 2019) | [2:30]
- [#27 – David Sinclair, Ph.D.: Slowing aging – sirtuins, NAD, and the epigenetics of aging](https://peterattiamd.com/davidsinclair/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (November 5, 2018) | [2:30]

**Episode of** ***The Drive*** **with Max Diehn**: [#213 ‒ Liquid biopsies and cancer detection | Max Diehn, M.D. Ph.D.](https://peterattiamd.com/maxdiehn/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (July 11, 2022) | [4:00]

**Episode of** ***The Drive*** **with Karl Deisseroth**: [#191 – Revolutionizing our understanding of mental illness with optogenetics | Karl Deisseroth M.D., Ph.D.](https://peterattiamd.com/karldeisseroth/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (January 17, 2022) | [4:00]

**Episode of** ***The Drive*** **with Steve Rosenberg**: [#177 – Steven Rosenberg, M.D., Ph.D.: The development of cancer immunotherapy and its promise for treating advanced cancers](https://peterattiamd.com/stevenrosenberg/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (September 27, 2021) | [6:30]

**Episode of** ***The Drive*** **with Navdeep Chandel**: [#31 – Navdeep Chandel, Ph.D.: metabolism, mitochondria, and metformin in health and disease](https://peterattiamd.com/navchandel/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (December 3, 2018) | [13:15]

**Review of the Randall Hypothesis**: [The Randle cycle revisited: a new head for an old hat](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2739696/#:~:text=In%201963%2C%20Lancet%20published%20a,been%20confirmed%20by%20many%20investigators.) | *American Journal of Physiology Endocrinology and Metabolism* (L Hue and H Taegtmeyer 2009) | [33:30]

**Discussion of the diagnostic criteria for metabolic syndrome**: [The metabolic syndrome: time to get off the merry-go-round?](https://onlinelibrary.wiley.com/doi/full/10.1111/j.1365-2796.2010.02325.x) | *Journal of Internal Medicine* (GM Reaven 2010) | [52:00]

**Biography of Oppenheimer**: [American Prometheus: The Triumph and Tragedy of J. Robert Oppenheimer](https://www.amazon.com/American-Prometheus-Triumph-Tragedy-Oppenheimer/dp/0375412026/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1654001864&sr=8-1) by Kai Bird and Martin J. Sherwin (2005) | [2:07:45]

**Rabinowitz lab website**: [Rabinowitz lab](https://scholar.princeton.edu/rabinowitz) | Open Scholar at Princeton University

§

## People Mentioned

- [David Sinclair](https://sinclair.hms.harvard.edu/) (Professor of Genetics at Harvard Medical School, expert on aging) [2:30]
- [Richard (Rich) Miller](https://www.richmillerlab.com/) (Professor of Pathology at the University of Michigan, expert on stress and aging) [2:45, 1:37:15]
- [Maximilian (Max) Diehn](https://med.stanford.edu/diehnlab.html) (Professor of Radiation Oncology at Stanford, expert in cancer detection with liquid biopsy) [4:00]
- [Karl Deisseroth](https://profiles.stanford.edu/karl-deisseroth) (Professor of Bioengineering and of Psychiatry and Behavioral Sciences at Stanford University, developed optogenetics) [4:00]
- [Harden McConnell](https://chemistry.stanford.edu/people/mcconnell) (former Professor of Chemistry at Stanford University, Josh’s PhD advisor) [5:00]
- [Mark Davis](https://med.stanford.edu/davislab.html) ( Professor, Microbiology & Immunology at Stanford University) [5:00]
- [Steven Rosenberg](https://ccr.cancer.gov/staff-directory/steven-a-rosenberg) (Chief of Surgery and Head of Tumor Immunology at the National Cancer Institute, pioneered immunotherapy for cancer) [6:30]
- [Alejandro (Alex) Zaffaroni](https://en.wikipedia.org/wiki/Alejandro_Zaffaroni) (Entrepreneur, founded several biotech companies) [10:00]
- [Navdeep (Nav) Chandel](https://www.chandellab.com/) ([Professor of Medicine and Biochemistry and Genetics](https://www.feinberg.northwestern.edu/faculty-profiles/az/profile.html?xid=11123) at Northwestern University) [13:15, 1:03:30]
- [Hans Krebs](https://en.wikipedia.org/wiki/Hans_Krebs_(biochemist)) (Physician and biochemist, won the 1953 Nobel prize for discovery of the Krebs cycle and urea cycle) [21:00]
- [Gerald (Jerry) Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) (was a Professor of Medicine at Stanford University and expert in insulin resistance) [40:15, 52:00]
- [George Cahill](https://en.wikipedia.org/wiki/George_F._Cahill_Jr.)  (Expert in metabolism, advanced research in diabetes and starvation) [42:15, 1:45:00]
- [George Brooks](https://ib.berkeley.edu/people/faculty/brooksg) (Professor at UC Berkeley, expert in exercise physiology and metabolism) [43:45]
- [Randy Strong](https://www.uthscsa.edu/academics/medicine/profile/strong) (Professor of Pharmacology at UT Health San Antonio Texas and aging expert) [1:37:15]
- [Joseph (Jo) Baur](https://www.med.upenn.edu/baurlab/people.html) (Professor at the Perelman School of Medicine at the University of Pennsylvania, NAD expert) [1:38:45]
- [Craig Thompson](https://www.mskcc.org/research/ski/labs/craig-thompson) (President and CEO, Memorial Sloan Kettering Cancer Center) [1:40:00]
- [Sidney Farber](https://en.wikipedia.org/wiki/Sidney_Farber) (father of modern chemotherapy) [1:40:30]
- [Lewis (Lew) Cantley](https://research.cornell.edu/researchers/lewis-c-cantley) (Professor of Cancer Biology at Cornell University) [1:41:15]
- [Jennifer Wargo](https://www.mdanderson.org/research/departments-labs-institutes/labs/wargo-laboratory.html) (Professor at the University of Texas MD Anderson Cancer Center) [1:41:45]
- [Matthew Vander Heiden](https://biology.mit.edu/profile/matthew-vander-heiden/) (Director, Koch Institute for Integrative Cancer Research, Professor of Biology at MIT) [2:01:00]
- [Richard Feynman](https://en.wikipedia.org/wiki/Richard_Feynman) (theoretical physicist and recipient of the Nobel Prize) [2:07:30]

§

![](https://peterattiamd.com/wp-content/uploads/2022/07/1x1-bio-pic-rabinowitz-500x500.jpeg)

##### Josh Rabinowitz, M.D., Ph.D.

Joshua Rabinowitz earned his BA in chemistry  and BA in Mathematics at the University of North Carolina at Chapel Hill.  He earned his PhD in Biophysics and MD at Stanford University.  After graduating from Stanford University, he co-founded Alexza Pharmaceuticals and served as its Vice President for Research until 2004, when he joined Princeton University, where he is now a Professor in the Department of Chemistry & Lewis-Sigler Institute for Integrative Genomics and the Director of the Ludwig Princeton Branch. Since 2008, He has also been a Member of the Rutgers Cancer Institute of New Jersey.

Josh has received several awards for his scientific contributions— including the Allen Distinguished Investigator Award, the NIH Pioneer Award, the CAREER Award of the National Science Foundation and the Beckman Young Investigator Award. [[Ludwig Cancer Research](https://www.ludwigcancerresearch.org/scientist/joshua-rabinowitz/)]