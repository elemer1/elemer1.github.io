# #351 ‒ Male fertility: optimizing reproductive health, diagnosing and treating infertility, and navigating testosterone replacement therapy | Paul Turek, M.D.

**Source:** [https://peterattiamd.com/paulturek/](https://peterattiamd.com/paulturek/)

---

This is part one of a two-part mini-series on fertility and reproductive health, with next week’s guest, Dr. Paula Amato, focusing on the female side of the equation. Paul Turek is a world-renowned expert in male fertility and reproductive health, the founder and medical director of the Turek Clinic, and host of the Talk with Turek podcast. In this episode, Paul explores the topic of male fertility, offering a detailed look at the complex and highly coordinated process of conception and the many challenges sperm face on their journey to fertilizing an egg. He shares fascinating insights into how sperm work together to navigate the female reproductive tract, how environmental factors like heat, stress, and toxins impact sperm quality, and what men can do to improve their reproductive health. Paul also dispels common myths about testosterone replacement therapy and its effects on fertility, providing strategies for preserving fertility while on TRT. The episode also highlights cutting-edge advances in reproductive medicine, from genetic testing and sperm sorting to emerging treatments for infertility.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/paulturek/the_Drive_public.png)

Play

#351 ‒ Male fertility: optimizing reproductive health, diagnosing and treating infertility, and navigating testosterone replacement therapy | Paul Turek, M.D.

#351 ‒ Male fertility: optimizing reproductive health, diagnosing and treating infertility, and navigating testosterone replacement therapy | Paul Turek, M.D.

1x15s30s

0:002:19:12

## We discuss:

- The incredibly complex and hostile journey sperm must take to fertilize an egg [3:00];
- How sperm are made: meiosis, genetic variation, and the continuous renewal influenced by environmental factors  [9:00];
- The built-in filter that weeds out genetically abnormal sperm [14:45];
- How sperm are finalized in form and function: tail formation, energy storage, and chemical sensing abilities [18:30];
- How to optimize conception through the timing of sex, ejaculation frequency, and understanding the sperm lifecycle [26:30];
- Male infertility and Paul’s diagnostic approach: detailed history, a physical exam, and identifying red flags [33:30];
- Viral infections that can affect the testes and potentially lead to sterility [40:30];
- Semen analysis: morphology, motility, and hormonal clues to male fertility [45:45];
- Effects of medication, microplastics, stress, and exercise on fertility [57:15];
- Testosterone replacement therapy (TRT) and male fertility [1:06:00];
- Restoring fertility after prolonged use of exogenous testosterone [1:25:00];
- Effects of heat and cold exposure on fertility and sperm quality [1:36:00];
- How different levels of exercise—especially cycling—affect male fertility [1:41:45];
- How alcohol, marijuana, and nicotine affect male fertility [1:46:00];
- Why Type 2 diabetes is a risk factor for male infertility [1:50:00];
- How varicoceles—a common cause of male infertility—are diagnosed and treated  [1:51:15];
- Genetic factors that affect fertility [1:54:00];
- The impact of lifestyle and environmental exposures on fertility [1:56:30];
- The evidence (or lack thereof) behind stem cell and PRP therapies for male infertility, and how lifestyle and non-invasive interventions often lead to successful conception [2:00:30];
- Considerations for sperm banking, and how paternal age impacts fertility planning and offspring health [2:05:00];
- Semen quality as a biomarker: linking male fertility, longevity, and preventative health through Medicine 3.0 and epigenetics [2:14:45]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dr. Paul Turek is a world renowned expert in male fertility and reproductive health
- You can think of this as part 1 of a 2-part miniseries on fertility and reproductive health
  - With this one on the male system
  - Next week, we’ll feature Dr. Paula Amato who is the female expert on this topic
- Paul is the founder and medical director of [The Turek Clinic](https://www.theturekclinic.com/), specializing in cutting-edge treatments for infertility and men’s health
- He is a pioneer in advancing research on sperm biology, genetics, and reproductive longevity
- He hosts the podcast [*Talk With Turek*](https://www.theturekclinic.com/talk-with-turek-podcast/)
- In this episode we explore the intricate and highly evolved process of conception
- Discussing the challenges sperm face on their journey to fertilization
  - This is important to understanding all the places where it can go wrong
  - It’s not just an interesting story, it also explains how challenging it actually is
- Paul shares insights into male fertility, including how sperm function in coordination to navigate the female reproductive tract
- We discuss how various factors such as heat exposure, stress, and environmental toxins impact sperm quality
- We talk about what men can do to optimize their reproductive health
- Paul explains the effects of testosterone replacement therapy on fertility
  - Debunking many myths
  - Offering strategies for men looking to preserve their ability to conceive while on hormone replacement therapy
- We talk about the emerging fertility technologies
  - Including advanced sperm sorting techniques
  - Genetic testing
  - Innovative treatments that could redefine reproductive medicine
- We talk about the differences between the risk in the aging male and the aging female
  - This was one of the most interesting things Peter learned in this podcast

## The incredibly complex and hostile journey sperm must take to fertilize an egg [3:00]

**Explain what’s involved in conception through the lens of sperm**

- Peter wonders how much of a challenge this is
- Obviously there’s an enormous evolutionary pressure for this to go as easily as possible
- But what is actually involved?
- What happens for a sperm to fuse with an egg?
- What are all the things that are standing in its way, so to speak?

Paul explains, “*Reproduction is an incredibly highly-evolved, million-year process, and remarkably conserved among mammalian species, even among land species and water species of animals.*”

Vaginas, cervixes, uteruses

- The question is, why is it so much work for a sperm to get into the vagina?
- And then have to go through a cervix
- The immune system in the uterus is very active, because there’s a hole in the woman to the abdomen, so it has to be highly protected
- Sperm have to go through the uterus, so there’s a 10-inch, 12-inch swim
  - Which is equivalent to about a 20-mile swim for a human
  - And they do that in minutes, which is crazy
- It’s an interesting challenge that nature has kept in place for a million years
- Paul really respects evolution, and it is why we’re here: to eat, sleep, reproduce

Basically with ejaculation, the penis is shaped to fit into the cervix

- Everyone wonders, is it getting to the right spot?
- It’s also interesting that the semen is coagulated, and then it liquefies
  - And that’s because there’s a lot of species of lower phyla that they have to leave as soon as they have sex, otherwise they’ll get killed (like praying mantises and black widow spiders)
  - Ejaculates in humans are sticky ‒  Paul has no idea why, no evolutionary explanation for this
- A lot of men think they’re having trouble placing things
- Paul doesn’t worry about it because the cervix and the penis expand to form a seal

Challenges sperm face and the numbers that make it

- 1 – Sperm have to go through a crypt (a channel), and only a few sperm make it
- So 100 million sperm may start out, maybe 5 million make it through the first barrier, which is the cervical barrier
- 2 – The vaginal fluid is acidic (pH 5)
  - Semen is pH 7
- It’s all buffered as a hostile environment, so it has to get out of there quickly
- As soon as the sperm liquefies (there’s sugars in there), they go through the cervical path
- So 5 million will make it
- 1 out of 20 makes it through the cervix
- Then 100 make it to the fallopian tube, and then 1 will make it to the egg
- These numbers were found by studies done in the 50s of women who had sex before hysterectomies
  - Then different parts of the reproductive tract were swabbed
  - These young women had hysterectomies for different reasons, not infertile
- This is the basis for our move to technology, from 5 million moving sperm when we start doing inseminations versus sex
  - Those are based on the numbers of sperm that reach the uterus
- Everyone thought the vanguard sperm wins
  - It’s the Phelps sperm that’s going to make it
- There’s a company out of Boston called [Arex Life Sciences](https://arexlifesciences.com/), and they’ve discovered that sperm work in phalanxes

Disclosure: Paul is consulting for Arex Biosciences

- Because the immune system is so vibrant in the uterus, the first round of sperm gets through the cervix and typically absorbs the immune system, secretes [Fc receptor](https://en.wikipedia.org/wiki/Fc_receptor)

Peter asks, “*We’ve referred to the immune system a couple of times now… What is the barrier?*”

- The full immune response: T cells, B cells, and antibodies
- There’s also a mucus plug that exists for 28 days a month to prevent anything from going through, because it’s a hole into the woman’s body, and [peritonitis](https://en.wikipedia.org/wiki/Peritonitis) is severe

**⇒** The cervical mucus thins, and that’s to let sperm through for 2 days a month

- It’s an incredibly detailed, perfectly-orchestrated system

***It looks like the first round of sperm get through the cervix, get into the uterus, and they get demolished like a Roman*** [***phalanx***](https://en.wikipedia.org/wiki/Phalanx)

- Maybe a second round goes through and they get demolished
- They’re secreting the [FCR receptor](https://en.wikipedia.org/wiki/Fc_receptor) on the immunoglobulin, because that’s what female antibodies bind to

***We don’t know how many phalanxes go through, but then it’s like a run up the middle, and then eventually a couple of sperm make it, and the immune system is deactivated and they get there (it’s wild)***

- That can be measured now, and there’s actually going to be an assay available to look at whether you’re doing this
  - They’re calling it a **sperm cycle**
  - Almost like ovulation, spermulation
  - It’s an hour and a half cycle when the phalanx is working, sperm are deactivating the immune system, and then maybe they don’t
  - There are jaculates (which is a group of sperm) and some of which do this well and some of which don’t

**⇒** That can be a whole reason for infertility ‒ if you’re not able to deactivate the system, you’re not going to be able to get through, because the immune system is active

*Summary of the numbers of sperm*

- 100 million ejaculated at the cervix
- 5 million get through the cervix, into the uterus
- 100-500 get to the fallopian tube
- 1 gets to the egg

*Paul jokes about why you need so many sperm*

- The classic answer he used to give is they don’t like to ask for directions
- But these numbers illustrate why

## How sperm are made: meiosis, genetic variation, and the continuous renewal influenced by environmental factors  [9:00]

- An important consideration for sperm is it can only have half the genetic information contained within all other cells in the man’s body

**When does that take place?**

- The testicle makes sperm
- It takes about 60-70 days, and it’s a process called [meiosis](https://en.wikipedia.org/wiki/Meiosis)
- So in a car assembly line, cars are mass produced, and you want it all to be the same
- In meiosis (which is unlike [mitosis](https://en.wikipedia.org/wiki/Mitosis)), you want things to be different and to be a little easy-peasy
  - You get what’s called [recombination](https://en.wikipedia.org/wiki/Homologous_recombination), and that’s the source of evolution
  - The chromosomes blend in a different way and separate in a different way

**⇒** Through that process, you get half the number of chromosomes, which is required to join the other half

- But it’s not always the same half

**Funny story about when Peter took the MCAT**

- Peter had to take the [MCAT](https://en.wikipedia.org/wiki/Medical_College_Admission_Test) before doing any of the pre-med stuff, because he had studied engineering before deciding he wanted to do medicine
- He didn’t want to spend 2 years preparing
  - 1 year taking the post-bac and then the MCAT
- He decided to just wing it and take the MCAT, having never taken a biology class since high school (he took freshman biology)
- He’s studying his heart out for this, and the physics and chemistry are fine, but the biology is killing him
- He bought this cheap study guide (he didn’t want to splurge for the official study guide)
- And every time he encountered the word meiosis and mitosis, he assumed it was a spelling mistake because he bought a knockoff book (he thought it was just mitosis)
- Finally, on the night before the exam, he realized they were 2 totally different things
  - There’s a big difference
- That realization might have gotten him into med school, because he thinks he barely got at 10 on the biology section
  - It’s hard to get into a good med school if you get below that

***To this day, Peter gets such a chuckle out of the confusion of the nomenclature***

**⇒** Mitosis happens when cells are dividing in our body, where they’re trying to create a perfect replica of the entire suite of DNA while meiosis only occurs in the creation of an egg or a sperm

**Are women born with all of their eggs?**

- 5 million eggs at conception
- 1 million eggs at birth
- You basically ovulate 1000 eggs in your lifetime
  - 1 a month
  - But you actually produce 10 a month, so you lose 10 eggs every month
- By the time you’re 45, you’re out of eggs
- There’s a lot of waste
- The eggs are stuck in a stage of perpetual space, and they get older but they don’t evolve
- They mature at the time they are asked to

**But sperm are constantly renewed**

Peter asks, “*Is that just a mass space problem? Because the testes, if we did the same thing women did, would we just have to have an enormous set of testes?*”

Paul jokes, “*Why do you think out of the box like that?*”

- He’s not sure
- There’s a whole issue of what’s the source of human evolution
- It’s really sperm because they are constantly dividing, constantly influenced by the environment
  - And they’re throwing off mutations and epigenetic changes

***What’s most interesting for Paul for this talk is that whatever happens in sperm, happens to offspring***

- It’s transgenerational

*Does that mean that the father is more likely to pass on environmental stressors than the mother?*

- Probably
- That’s definitely been shown

**⇒** The sperm is the actual cell

**Where do sperm get the little tail from, and what is the other part of the cocktail?**

> “*One of the most magnificent transformations of a cell in the body is the making of a sperm*.”‒ Paul Turek

- It starts with a [spermatogonial stem cell](https://en.wikipedia.org/wiki/Spermatogonial_stem_cell), which looks like other cells
- That spermatogonial stem cell is actually the first and the bottom of a tube
  - There’s 12 stages of [spermatogenesis](https://en.wikipedia.org/wiki/Spermatogenesis)
- That cell is remarkable; it’s actually the human male embryonic stem cell
- Paul has a patent on that cell, because if you take that cell and you put it in a niche environment like an embryonic stem cell, it’ll become embryonic almost like it can become multipotent
  - You can form tumors, and you can form bone, [mesoderm](https://en.wikipedia.org/wiki/Mesoderm), [ectoderm](https://en.wikipedia.org/wiki/Ectoderm), and [endoderm](https://en.wikipedia.org/wiki/Endoderm)
  - You can do all three layers of the body with that adult spermatogonial stem cell

Peter asks “*Is there any other cell in the body that is capable of that?*”

- No
- There are stem cells in the bone marrow
- There might be stem cells in fat, but none of this
- Paul has [shown](https://pubmed.ncbi.nlm.nih.gov/18927477/) that the capability of this cell is magnificent

***The male embryonic stem cell has yet to be taken advantage of with cell-based therapy ‒ it’s really incredible what this cell can do***

- And a man potentially has access to this cell his entire life
- The spermatogonial stem cell usually reproduces mitotically, and then at puberty, it’ll go down the path of meiosis
  - This involves halving and mixing up the chromosomes
  - And the newness of the genome introduces mutations
  - Most mutations are bad, and some are good

## The built-in filter that weeds out genetically abnormal sperm [14:45]

**When the cell that is becoming a sperm undergoes meiosis and it divides, what’s the fraction of times when this becomes an** [**aneuploidic**](https://en.wikipedia.org/wiki/Aneuploid) **sperm, and what’s the process by which that thing gets discarded?**

**⇒** If you look at healthy human sperm for chromosomal content and what’s correct and what’s incorrect, probably 2% of them are off

- They’ll still be made because it doesn’t really click the system to negate it
- We don’t know at what level of chromosome abnormalities the system will say, “*This is a bad product.*”
- Making sperm is very logarithmic
- Probably 1 out of 4 that are being made go through the [epididymis](https://en.wikipedia.org/wiki/Epididymis)
  - Which is a collecting duct after the testicle where it matures (for 10 days), gets epigenetically modified
  - You’ll see different epididymal zones
  - There’s a lot of post-production modification, not of DNA essentially,
- There’s a filter going on where a lot of the bad aneuploidy comes out, because if you look at the chromosomal abnormality rate in testicular sperm before it goes through the rest of the system and compared to ejaculate, it’s 2-3-fold higher
- When we talk about **aneuploid sperm**, instead of having 1 copy of each chromosome, an aneuploid sperm either has none, or 2, or anything that’s not 1 of each

*When aneuploidy occurs in the fusion of sperm and egg, can we figure out if it’s maternal or paternal in origin?*

- If you look at the embryo, it’s kind of hard to tell
- There are some markers of paternal and maternal origin
- It depends on where you’re going back in mitosis and meiosis
- You’re really going to have to look at the sperm, and if you see a translocation, some characteristic change in sperm, and you see it in the embryo, then you know it’s paternal, but not usually

**⇒** 98% of sperm are typically normal, and in a guy with infertility, it might be 95%

Example: you have a patient with [Kleinfelter syndrome](https://en.wikipedia.org/wiki/Klinefelter_syndrome), a male with an extra X chromosome in every cell in their body (or a transgenic model with that feature)

- This is a man who is XXY instead of XY (47 chromosomes not 46)
- Phenotypically, he had a distinctive look only 10% of the time
  - 90% of the time, you would never know
  - That’s a MCAT question

***Every cell in their body has an extra X chromosomes but only about 10% of their sperm will have an extra X chromosomes***

- Meaning most sperm will have an X or a Y, just like everyone else

Peter asks, “*The only difference is they have a two-thirds chance of producing an X and a one-third chance of producing a Y, I’m assuming, instead of 50/50?*”

- Paul doesn’t think we know that
- That’s math and biology is not math

Paul operated on 2 Kleinfelter’s patients yesterday

- They’re not doing pre-implantation genetic diagnosis of the embryos that they’re going to create from their sperm, because the chance is not that high
- In mice, there is a 0.1% chance of normal men having an XY sperm (or an aneuploid sperm) to 1% chance of abnormal sperm
- In humans it goes from 1% or so to 10%

***But 90% [of sperm is normal] and that is remarkable***

## How sperm are finalized in form and function: tail formation, energy storage, and chemical sensing abilities [18:30]

**Back to the process of how sperm is made in the testicle**

- The [testicle](https://en.wikipedia.org/wiki/Testicle) is an amazing machine

*Weird question: Why is it out in the breeze like that?*

- Peter assumed it was temperature related
- Why does it need to be a little cooler?
- Peter guesses that it’s so energetically demanding, that it’s giving off more heat in the process of creating something that is going to be so efficient to be able to swim 20 miles effectively
  - And that’s very glycolytic, he’s assuming (the amount of ATP that must be generated)

**⇒** There are 75 mitochondria per sperm ‒ that’s like an electric motor on each wheel

- It’s Peter’s guess that if you tried to keep those guys inside, you’d have an overheating problem
- Paul thinks overheating could be translated to oxidative stress, which is a cause of a lot of infertility
- We don’t know the answer
- It’s interesting that ovaries are inside
- Men get in hot baths and they’re cooked, women can get in hot baths and they’re okay

*Funny story*

- Peter had a buddy over who does not have kids but would like to have kids
- Before they went into the sauna, he went to the freezer and came down with ice packs
- They were sitting in the sauna and he’s got ice packs all over his groin
- Peter immediately understood why he was doing that
- They’ll come back to whether or not that is an important strategy for men in saunas who want to have kids

**Spermatogenesis is the whole process**

- Spermatogenesis is when you go from the round cell stage, and you get half the number of chromosomes
- Then you have to make a tail and then whole motor assembly
  - That is the most profound transformation of a cell in the body
  - It takes about 3 weeks to go from that stage
  - We’re learning now, a lot of it’s vitamin A driven
- The whole process is 6 or 7 weeks, then it’s complete and nonmotile and it’s packaged

*Give us some size comparison. Before the tail is on, what is the size of that cell?*

- Probably similar to half the size of a lymphocyte, or half the size of a red blood cell, a couple microns
- 35 micron tail

It’s really a magnificent engineering feat

- It’s got microtubules in the middle, and there’s these links to the tail
- It’s like a kite, and the engine runs it, and tail wags
- 300 genes control movement of sperm alone
- There’s mitochondrial DNA in there, all that stuff

**⇒** Sperm are wildly compact, 10x more compact than any other cell in the body

- From a mitochondrial density standpoint
- From a cytoplasmic standpoint
- From a nuclear standpoint, it goes from [histones](https://en.wikipedia.org/wiki/Histone) to [protamines](https://en.wikipedia.org/wiki/Protamine): that DNA is condensed a lot more
  - It’s got to be packaged really well to survive outside the body and be in good shape, because it’s transgenerational
- A lot of energy in that

Peter asks, “*Where is the ATP, or carbohydrate, or whatever, the glucose stored in the sperm?*”

- Probably in the cytoplasm and in the tail
- Peter compares it to a rocket ship with its payload ‒ it’s packaged for that one shot
  - He assumes it’s the same here, there’s no transporters to bring in glucose or anything
  - Correct ‒ it has solid fuel and one shot

There’s a 2 week period where sperm stay in the epididymis

- [B and C in the diagram below]

![](https://peterattiamd.com/wp-content/uploads/2025/05/f1-paulturek.png)

**Figure 1. Anatomy of the testicle showing the (A) head of epididymus, (B) body of epididymus, (C) tail of epididymus, and (D) vas dererens**. Image credit: [KDS444](https://commons.wikimedia.org/w/index.php?curid=19018077) at [Wikipedia](https://en.wikipedia.org/wiki/Epididymis#)

- The [epididymis](https://en.wikipedia.org/wiki/Epididymis) is a 35-foot tubule, with estrogen
- There’s a lot of post-modification of the sperm
- 700 feet of tubules are in the testis
- The epididymis is a comma-shaped organ in the back of the testis
- This is prone to infection, and that will factor into infertility
- The epididymis has been relatively understudied, but it has actually become very important, epididymisomes
  - And there’s a lot of modifications we don’t really understand
  - Paul wrote the chapter for a [textbook on reproductive physiology](https://www.mea.elsevierhealth.com/the-netter-collection-of-medical-illustrations-reproductive-system-volume-1-9780323880831.html), and it really is a lot of work in the ’50s and ’60s

**⇒** Now we’re beginning to understand DNA fragmentation and the quality of sperm is driven by the epididymis

- A lot of the quality of sperm, not the shape and stuff like that
- Meaning the residence time within the epididymis and other environmental factors there
- It’s more susceptible to drugs, exposures, heat, etc.
- The testis are very walled off
  - Very little happens in the testis, because the [Sertoli cells](https://en.wikipedia.org/wiki/Sertoli_cell) that line the tubules have a [blood-testis barrier](https://en.wikipedia.org/wiki/Sertoli_cell#Structural), same as the brain (blood-brain barrier)
- [Harvey Cushing](https://en.wikipedia.org/wiki/Harvey_Cushing#) at Yale did that in the late 19th century, took brain-dead patients, injected them with dye (maybe methylene blue)
  - The blood brain barrier came about when nothing went into the brain, and nothing went into the testicle
  - 2 areas of the body that were completely immune from normal transport processes

***The 2 things that we know happen in the epididymis after production of sperm are motility improves, and they learn how to smell***

- Sperm begin to learn progressive motility
  - They start moving forward, as opposed to not moving, or moving in circles
- And the most curious thing is they learn how to smell
  - They track a chemical signal in the follicular fluid
- If you take testicular sperm and inseminate it into a uterus with insemination technology, it’ll just be killed
- If you take an epididymal sperm, and you do that from the top of the epididymis, it’ll maybe run in circles, and it’ll be killed by the immune system of the female
- Once it’s at the end of the epididymis (where it is stored) ‒ that sperm knows where to go and it’ll move forward
  - It takes 10-14 days for sperm to make their way through the epididymis
  - 600 million sperm live in a bucket, a pot of soup called the epididymis, and you ejaculate from that pot
- That sperm is like a shark sensing blood in the water

**⇒** 1 part per billion of follicular fluid can be sensed by a sperm (that’s incredible)

- It’s literally an olfactory sense that sperm have for the follicular fluid so they know exactly where to go

Peter asks, “*Do we know what the chemoreceptor is?*”

- It was published in [*Nature*](https://pubmed.ncbi.nlm.nih.gov/28054671/); it’s an olfactory type receptor

Peter wonders, “*What is the most noxious thing that we can smell with our nose, and at what concentration can we detect it?*”

- Paul has no idea
- [discussed in [*Physiology and Behavior*](https://www.sciencedirect.com/science/article/abs/pii/S0031938408003053)]
- Peter has always thought about this because he likes to hunt
  - Anyone who’s ever bow hunted knows that animals can smell at a level that we can’t even fathom
  - They can smell us literally a mile away, if the wind is just blowing their direction
  - It’s always seemed like we have really, really insufficient noses
    - We were given lots of superpowers in many ways, but smell wasn’t really one of them
- If you block a sensory bank of the 5, the others increase remarkably
  - Paul is a micro surgeon and this stuff matters a lot, but he can’t read braille
  - He thinks about people who are deaf ‒ hearing and smell can crank up

**Back to sperm**

- Sperm detect 1 part per billion of follicular fluid

**⇒** The base of the epididymis is basically the launchpad where half a billion sperm are stored

- That’s enough for 5 ejaculations

Peter asks, “*What’s the time to rebuild that? What’s the rate at which you fill?*”

- Paul doesn’t know
- There must be a frequency of ejaculation that is too much

## How to optimize conception through the timing of sex, ejaculation frequency, and understanding the sperm lifecycle [26:30]

**If a guy is ejaculating every single day, is that insufficient to get a complete replenishment? Where if he’s having infertility, you would say, “*****You got to move it to every other day.*****”**

- Yes

**⇒** Typically, Paul recommends 2 days of abstinence, and sex every other day to optimize conception

- It depends how old you are and your biology
- Most men need a day or 2 to recharge completely, and that’s sort of a generalization
- Some men are fine every day
- Paul had a guy once who had to bank sperm for hepatitis treatment, and he was like Mickey Rourke, and he had a wooden leg and he’s about 50
  - When Paul told him to abstain for a couple days to do this semen analysis, he looked at his partner, and she grabs him and says, “*He can’t do that. He’s every day, he can’t do that. I don’t know what he’s going to do*.”
  - He was panicking that he had to hold off for a day
  - Paul asked, “*How often do you have sex?*”
  - He said, “*Twice a day, every day*.”
- Paul had another man, a wonderful orthopedic surgeon at Stanford, who he asked on his questionnaire, “*How often do you have sex?*”
  - He wrote 0.00001356 weekly (Avogadro’s number) ‒ which meant he was so frustrated

***For semen analysis, for diagnostics, for infertility, when you abstain longer, your sperm count will rise but your motility will fall (because it’s older)***

- There’s a min-max curve you’re optimizing for, and 3 days would be about right
  - You’re not going to lose that much motility after that

**There’s biological variability, which we try to minimize when we do the semen analysis**

- 2-4 days of abstinence
- That’s a different period than what we’re recommending for sex (which is every other day)
- That’s based on a [*NEJM* paper](https://pubmed.ncbi.nlm.nih.gov/7477165/) where they looked at about 700 couples
  - They had them keep diaries of how they had sex, when they ovulated, and when they got pregnant
  - They said, “*Do what you normally do and then give us the diaries.*”
  - Say ovulation is day 15 of the cycle, they found when people started having sex on days 9, 11, 13, there were significant pregnancy rates
  - And [having sex] every other day was the optimal interval
  - But if you waited until ovulation and then had sex, that accounted for about 20% of conceptions

**Paul’s advice ‒** ***when you get the [ovulation] kit, predict in front of it; it’s very important to front load the sex***

*Why is that?*

- There’s a reservoir effect in this uterus, it’s managed
- Sperm will survive for a day or 2

Peter asks, “*If ovulation is day 15, how could a day 11 sperm survive four days? It’s nurtured once it’s past the vagina. But how many of them are surviving? Is it literally the lone wolf, or is it the last hundred?*”

- Probably
- Maybe some of the sperm bind to the [oviduct](https://en.wikipedia.org/wiki/Oviduct) (the [fallopian tubes](https://en.wikipedia.org/wiki/Fallopian_tube)) and wait
  - They bind to the endothelium and just park
  - If there’s no egg, they’ll just sit there

**Going back to our moon [rocket] analogy, this is after you’ve done stage 1, stage 2, stage 3, you’re now out of gravity**

- It’s actually not an energetics problem anymore
- Sperm have escaped the hostile environment, in this case of gravity
- Now it’s in a fun place, the right pH, it’s warm

**Peter wonders what is the longest duration a sperm could survive for conception**

- If you had a large number of women that you knew were going to ovulate on day 15, and then you would have them have intercourse on day 7, 8, 9, 10
- And you create a distribution of the frequency of pregnancy across those days, and ask what’s the bottom 5th percentile (which is the theoretical possibility)?
- That experiment hasn’t been done
  - That’s a good one
- You want to develop the bell curve of the whole thing

**⇒** We know that once the egg is ovulated, after about 8 hours it’s over (it’s dead)

- The egg only survives for about 8 hours
- That’s a very left-tail curve

***You want the sperm there ahead of time***

Paul explains, “*80% of conceptions naturally who are at home occur when sex is front-loaded as opposed to reacting to ovulation. And most of the apps that are available nowadays will tell you that.*”

**More physiology about sperm**

*Studies of spermatogenesis*

- There was a [study](https://pubmed.ncbi.nlm.nih.gov/13953583/) published in Science in the ‘60s where men drank [tritiated water](https://en.wikipedia.org/wiki/Tritiated_water), and then they biopsied their testicles
  - Which would never be done nowadays
- Paul did a [study](https://pubmed.ncbi.nlm.nih.gov/16406920/) at Berkeley where he gave men [deuterated water](https://en.wikipedia.org/wiki/Heavy_water) for a week
  - That was not radioactive, but you could measure it
  - They gave them a dose of deuterated water and watched their ejaculates weekly
  - They looked for when the hydrogen showed up in the DNA, and it was an average of 74 days
  - Some men it was as quick as 42 days, and that’s going through the epididymis and getting ejaculated

**⇒** Normally it takes about 3 months to make a sperm (74 days on average)

- Paul mentioned early that sperm spend maybe 2 months in the testis and a week or 2 in the epididymis, and then maybe a couple of weeks to ejaculate

***So when you do anything to a man fertility-wise, you’re not going to expect to see any change for at least 2.5 months; and when you talk about full replacement of that semen, it probably takes 90 days***

- That’s the limitations in a man
- A 42-year-old woman wants now, but it takes 3-6 months

*Paul did a* [*study*](https://pubmed.ncbi.nlm.nih.gov/11912402/) *on fixing* [*varicocele*](https://en.wikipedia.org/wiki/Varicocele)

- This is an infertility problem in men, it’s surgery
- [Varicocele is discussed in [Paul’s blog](https://www.theturekclinic.com/blog/varicocele-varicoceles-bringing-grown-men-to-their-knees-scrotal-pain-varicocelectomy/)]

***He looked at the meantime to conception, and it was about 7 months after repair (which is 2 cycles of sperm production)***

## Male infertility and Paul’s diagnostic approach: detailed history, a physical exam, and identifying red flags [33:30]

**⇒** Infertility is defined as the inability to conceive after one year (using sex)

- It doesn’t have to be timed intercourse, just has to be whatever the couple does when they think they’re trying to conceive

**When someone shows up in your office, is it usually after they’ve gone down the rabbit hole of troubleshooting the female partner?**

*Or are people doing this in parallel?*

- There’s a large bias in Western worlds about how infertility is evaluated
- Paul’s practice is not typical
  - Most of his patients have been through a lot before they come to him
- Typically, [Keith Jarvi’s](https://www.sinaihealth.ca/physicians/keith-jarvi) data was good, and about 23% of men get a formal evaluation for infertility before couples go through IVF in North America

Peter asks, “*How does that differ from the rest of the world?*”

- That hasn’t been studied in the rest of the world, but there are countries like Germany and Spain with single insurers and the government pays
- It’s also recommended  that both partners get evaluated simultaneously
  - By society guidelines, like American Society of Reproductive Medicine, WHO, etc.
- But the bias is that the female gets very evaluated, for lots of money
- Men typically may get a semen analysis, but may not
  - And there’s a very complex reasoning there
  - It’s a different beast
  - There’s a lot of denial
  - It does get at your masculinity a little bit to get checked out and things, and it can be a little bit of a problem
- Lately, with large insurers coming in (Progeny, Maven, and things like that), you’re seeing a lot more men upfront
  - Which is fabulous

**Paul’s workup. What do you do when a guy comes in, and what are the things you want to know about him?**

- Usually a guy is dragged in by their partners
- Paul does 1 visit in person and everything else where they are
  - It’s a different kind of practice; he doesn’t ask them to come in a million times
  - He tries to get everything done in 1 visit because it’s rare to get them there
- He does a very thorough history (usually preceded by a questionnaire)
  - He give 200 questions, and that has all the hot bath stuff and all the exposures they have, and they have to do that before they see him
  - That’s a really important part of it
- If you could pick one in a multiple-choice question, what matters the most is probably the history
  - History of paternity matters, a history of exposures matters, etc.

**⇒** 1-5% of male infertility can be due to a major medical issue (testis cancer, diabetes, things like that)

- The physical exam, very important
  - [Varicocele](https://en.wikipedia.org/wiki/Varicocele) is very important
  - You can be missing a [vas deferens](https://en.wikipedia.org/wiki/Vas_deferens): 1 in 500 men have perfectly normal testicles, but they have a natural vasectomy
    - It’s a congenital absence of the vas, they’re going to be sterile or infertile

**We haven’t talked about how a vasectomy works and why a guy still ejaculates, but is infertile. Explain what the vas deferens, how the whole thing works and the plumbing**

*We also didn’t answer the question: what does semen consist of?*

- Semen is 10% basal fluid with sperm
- It’s about 80% seminal vesicle fluid, which is an accessory sex gland in the back of the prostate, and about 10% prostate
- Typically during ejaculation, prostatic fluid (which is clear and sticky) will grease the barrel of the urethra as “pre-cum”
- Then during the ejaculation process, the pellet of sperm gets pumped from the vas deferens into a chamber called the ejaculatory duct (this happens quickly)
  - [the figure below shows the male anatomy]
- Then the seminal vesicle (which is like a bladder) contracts, and sends sperm into the prostatic urethra
  - There’s two valves
  - One is the bladder neck ‒ it closes
  - One is the urethral sphincter that we pee through ‒ that opens and it gets forced out with muscular contractions in seconds

![](https://peterattiamd.com/wp-content/uploads/2025/05/f2-paulturek.png)

**Figure 2. Male reproductive anatomy**. Image credit: [K. D. Schroeder](https://commons.wikimedia.org/w/index.php?curid=100290476) at [Wikipedia](https://en.wikipedia.org/wiki/Male_reproductive_system)

- Therefore, if the vas deferens is clipped [in a [vasectomy](https://en.wikipedia.org/wiki/Vasectomy)], you’re getting essentially 90% of the volume
  - You’re just missing the 10% of the volume that contains the payload [the sperm]

Paul explains, “*In 3,000 men I’ve done vasectomies on in 30 years, 2 men have said, ‘My volume went down.*’”

- He had semen analysis before and after and he did go down by 15% (and he noticed)
- So it can be noticeable, but not usually
  - The color is the same
  - The opacity is the same
  - The whole process of liquefaction is the same
  - Viscosity, etc.

**For the physical exam, do you need an ultrasound?**

*How are you able to detect if a person is congenitally missing a vas deferens?*

- Pure physical exam
- You feel it
  - The vas deferens is like a piano wire
  - It is different than anything else in the cord
- Paul did a study: a third of his men with absent vas deferens only found out having procedures until he saw them
  - He usually does the exam; it’s an expertise thing
  - It’s not like the [PCP](https://en.wikipedia.org/wiki/Primary_care_physician) can figure this out ‒  you have to be doing this all day every day

**⇒** 1 in 500 men are congenitally missing their vas deferens

- The most common genetic disease in America is [cystic fibrosis](https://en.wikipedia.org/wiki/Cystic_fibrosis)
  - [[affecting](https://medlineplus.gov/genetics/condition/cystic-fibrosis/#frequency) 1 in 2,500-3,500 whites in the US, and most have congenital absence of the vas deferens]
- The big implication is these men can’t conceive naturally
  - They have a natural vasectomy
- Paul uses sperm retrieval techniques and IVF, but they definitely have the chance of passing on cystic fibrosis to a child
  - [because cystic fibrosis is an [autosomal recessive disease](https://medlineplus.gov/genetics/condition/cystic-fibrosis/#inheritance)]

Peter asks, “*What is the Venn diagram of cystic fibrosis and congenital lacking vas deferens?*”

- The [genes](https://en.wikipedia.org/wiki/Cystic_fibrosis#Causes) for that were discovered, and it’s at chromosome 7
  - There’s 17, 1,800 mutations, maybe 2,000
  - They cloned the genes and got the variants in the late ‘80s
- Then they found there’s another group of men who are perfectly healthy, do not have cystic fibrosis (which is a major metabolic disease with a short life expectancy)
- Those men had absent vas deferens in the absence of disease
  - They took the gene sets and looked at them, and they were the same, just not as many
  - So you have homozygous or heterozygous

***A carrier for cystic fibrosis will have an absent vas deferens, but a full-blown CF patient, cystic fibrosis patient, will have no vas deferens too***

*In other words, when you identify a man who does not have CF with a congenitally absent vas, there’s a very good probability he’s a carrier of CF?*

- Yes, and you can usually define it
- We can genetically test easily
- If you’re a carrier, there’s a 4% chance in America that your partner might carry it
- With 2 carriers there is a 1 in 4 chance of having an affected child [with cystic fibrosis]
- That’s a big concern in Paul’s practice, and he’s proud to say, “*In 30 years, we have no CF children. It’s all about good engineering and doing it right.*”

## Viral infections that can affect the testes and potentially lead to sterility [40:30]

***What else on the physical exam are you looking for?***

- Cancers, infections, epididymitis

*Tell me about* [*epididymitis*](https://en.wikipedia.org/wiki/Epididymitis) *(what’s the infection?)*

- [Mumps](https://en.wikipedia.org/wiki/Mumps)
- There’s aren’t many viruses that get into the testicle
- Very little gets into the testicle, similar to the brain
- But the mumps virus does it about a third of the time
- When you’re a child with mumps
  - The [parotid gland](https://en.wikipedia.org/wiki/Parotid_gland) infection
  - It’s a glandular disease
- It really only matters when you’re pubertal and you get mumps ‒ then it goes to lots of glands
  - It goes to your pancreas and causes diabetes
  - It can go to the salivary glands
  - It can go to the testicles

Peter adds this public service announcement, “*Just one more reason why everyone should really get the* [*MMR vaccine*](https://en.wikipedia.org/wiki/MMR_vaccine) *when they’re a child, notwithstanding the tragedy of children dying from preventable diseases. But this is another non-lethal, but significant complication of mumps*.”

- It will cause viral necrosis and edema of the testis
- Similar to a brain, it’s in a calvarium
  - The brain is in a fixed space; so when it swells, you got to do something because you can die if it swells too much
- The testicle’s a fixed cavity with the [tunica albuginea](https://en.wikipedia.org/wiki/Tunica_albuginea_of_testis)
  - If it swells too much, it necroses and then you get fibrosis, and then you get sterility
- Paul has techniques where he can find sperm in lots of these men (very little pockets)
- But most of it you’re ablating the testis
  - It’s going to scar and die from ischemic necrosis

**Other viruses that can affect the testis**

- [Zika](https://en.wikipedia.org/wiki/Zika_fever), [Ebola](https://en.wikipedia.org/wiki/Ebola), the CDC called Paul when these were coming around
- Zika’s been transmitted through semen
  - It causes the anencephaly issues when these pandemics recurring
- He got a call that there was an Ebola patient who survived, went to the institute, survived hemorrhagic fever and then a year later transmitted Ebola to a partner who transmitted it to 6 other men
  - It was another outbreak in South Africa

Peter asks, “*Meaning the patient that survived Ebola, the virus managed to survive in the testis?*”

- Somewhere, but was transmitted sexually a year later when he was well

Peter asks, “*When he was asymptomatic? He had already developed immunity?*”

- Right
- We don’t know about testis
- But we know that mumps will do that to the testis
- Zika is also persistent in the semen
- You have to think wherever the virus hung out, it had to be very immune privileged
  - Or at low levels, like low viral loads where there’s no disease
- These are concerning cases
- It may be [bulbourethral gland](https://en.wikipedia.org/wiki/Bulbourethral_gland)
- Maybe it’s [seminal vesicle](https://en.wikipedia.org/wiki/Seminal_vesicles); it’s hard to know
- But most viruses don’t go there
- The big one would be [COVID](https://en.wikipedia.org/wiki/COVID-19)
  - There was a big deal about the [ACE receptor](https://en.wikipedia.org/wiki/Angiotensin-converting_enzyme_2#Location_within_the_human_body) being in the lung and being in the testicle
  - And maybe COVID infection would make you sterile
- There was one [Zika paper](https://pubmed.ncbi.nlm.nih.gov/27798603/) in *Nature* that looked at if you infect mice with Zika, the testicles shrivel up and they get infertile
  - That caused a huge scare in the field, but we really didn’t see it
  - We’re not sure why it did it in mice
- It’s a blood-testis barrier thing
  - It’s an amazing barrier and nothing really gets through, including viruses, but mumps does, only at puberty
  - Zika does in animals, but we didn’t see it in humans
    - Zika could be seminal (just in the semen itself, not in the sperm)
  - Like Ebola is probably seminal, not testicular
    - It’s not on sperm; it’s around sperm or in the fluid
- For COVID, the big worry was when this Chinese [paper](https://pubmed.ncbi.nlm.nih.gov/38263068/) came out
  - It binds the ACE receptor in the lung
  - The testicle has this receptor too
  - Is it going to make men sterile forever?
  - [see also a [review](https://pubmed.ncbi.nlm.nih.gov/33719829/) Paul co-authored on the effects of COVID-19 on fertility]
- There were cases of infertility with bad infections
  - Was that just the fever, which typically does it even after a flu?
  - Or was that COVID specific? And we didn’t know
- A couple of Paul’s colleagues did some papers
- One which impressed him was [out of Cedars](https://pubmed.ncbi.nlm.nih.gov/35704934/) was a bunch of men (maybe not reproductive age) died with florid COVID
  - They got autopsies and they looked for virus in different locations in the body
  - Out of 10 men [it was 8 men], 1 had it in the testicle
  - So these are the men with the highest viral load you can imagine and only 1 of them had it [in his testicles]

***There’s a fertility risk with COVID, but of the 1,000 men Paul has seen since COVID, there were 2 cases [of infertility] that were unexplained***

- Where men were either fertile or had normal semen quality then had a bad COVID infection (maybe hospitalized), and 3 months later were sterile
- There’s a low perfusion rate there

Peter asks, “*What’s the phenotype of their sterility, aside from the presentation that they can’t get someone pregnant?*”

- No sperm in the semen
- It’s a primary problem

**Semen history is the 3rd thing Paul does when he sees patients**

- After gathering the history and conducting the physical

**The 4th thing is to check hormones**

- Production of sperm is driven by the brain
- Nothing nothing happens to sperm being made without the brain telling it what to do
  - Similar with eggs and controlling
  - It’s all a homeostatic mechanism with negative feedback

## Semen analysis: morphology, motility, and hormonal clues to male fertility [45:45]

**Back to** [**semen analysis**](https://en.wikipedia.org/wiki/Semen_analysis#)**, you’re looking for the count and motility. What else do you look for?**

*Paul considers it a sort of “poker hand”*

- There are [several features](https://en.wikipedia.org/wiki/Semen_analysis#Parameters)
- There’s the **volume** of semen
- There’s a **count**, concentration of sperm (numbers per mL)
- There’s **motility**, which is percent motion
  - You do a forward progression and see how good is the quality of motion
- Some measure of shape, called **morphology**
- There’s 3 liquid issues: liquefaction, agglutination, and viscosity
- Then you look for other cells that aren’t sperm
  - They are called **round cells**
  - Either they’re going to be puss cells or immature germ cells that are ejaculated early
  - Less than a million is normal

Paul explains how he looks at semen analysis, “*I look at it as a poker hand with each card has a meaning, but they have a look.*”

- If the volume is low, it’s one of 5 things
  - You’re always going to find something
  - 1 – It’s at the collection error (Paul calls this the first sample syndrome)
  - 2 -Low testosterone can cause it
  - 3 – There’s an absent vas deferens, which means you have an absent seminal vesicle
  - 4 – There’s ejaculatory obstruction
    - Peter asks, “*Do you ever have that on one side and not the other?*”
    - No
    - It’s very variable, segmental
- When Paul sees a low volume of semen, as a surgeon, he’s going to find something

***Semen analysis is a blunt instrument for fertility ‒ unless it’s zero, you can’t really say much about their fertility because people can conceive at all levels***

**Are there certain null states that don’t exist where everything is amazing, but this one thing is horrible?**

*Do you see scenarios where everything is remarkable, perfect motility but bad morphology?*

- Yes
- Or isolated things
- **Syndromic sperm shape problem**: you can have a perfectly normal semen analysis, count, motility volume, progression, and the sperm looked terrible
- There are rare conditions (1 in 5,000) where you might have [globozoospermia](https://en.wikipedia.org/wiki/Globozoospermia) or two-tailed sperm or pinhead sperm

**⇒** If you look at shape, 4% should look normal (which is terrible)

- That means 96% of the sperm don’t look normal (could be pinhead, double-tail, amorphous, or tapering)
  - Pinhead means there’s no nucleus
  - Most of them are going to be amorphous, head’s a little rounder, head’s a little narrower
    - Those are called stress patterns
    - Some things like hot baths and varicoceles and smoking will do that
- We can have a discussion about why 4% of human sperm being normal is normal when 99% of animal species in the wild have normal looking sperm
  - But it’s all a construct of someone decided what normal is
  - If you look at marine species, 99.9% look perfect in the wild
- In men who have large abnormal forms, if they’re 1% normal, you’ve got to look at the 99%
  - The story is in the [larger] chunk, and if they’re all looking the same, then it’s syndromic and then you have a problem
- The more homogeneous the failures are, the more likely that you have a clear etiology, and that’s hard to fix
  - They’ll fail with sex
  - They’ll fail with insemination
  - They’ll fail with IVF
- Sometimes with **globozoospermia** (where they’re called lollipop sperm), they just have a big round head with no acrosome, there’s all nucleus and there’s some of the components, they’ll just bounce off an egg
  - They’ll never work naturally
  - And to get them to work with IVF, you have to single sperm inject them into the egg and then shock the egg with calcium, do a calcium or piezoelectrics to get it to actually fertilize
  - Because the sperm is important, but fertilization, not only has to bind, but the calcium channels are regulated by sperm
  - And what shuts the doors to polyspermy in an egg is **calcium activation**
- This is the reason why even if you launch 100 sperm at an egg, it’s only one that can get in, because the first guy that breaches sets off the calcium channel that shuts the [egg to further sperm entry]

***Morphology can matter a lot, but it’s rarely the cause of infertility***

- Paul sees this in his practice maybe twice a year
- There’s not much he can do to treat it
  - He can try sperm sorting technologies (which are new in the market), microfluidics and things like that
  - Sometimes it works; sometimes it doesn’t

**Is that something that we know the genetic underpinning of?**

- We’re getting there
- [PLC-zeta deficiency](https://pmc.ncbi.nlm.nih.gov/articles/PMC9175550/) is one that was recently discovered
  - That runs the calcium channel
  - It tends to be associated with a certain look, like globozoospermia

Peter remarks, “*Think about that for a second from an evolutionary perspective. That is the single least desirable genetic mutation you could acquire… this is a dead end to the genome.*”

Peter asks, “*Does that mean it is only an acquired mutation, never inherited? I mean, it can’t be inherited presumably, unless it’s homozygous, but even still*.”

- That’s 1 of the 50 we throw off each generation (50 mutations)

***Paul emphasizes how fluid evolution actually is, and it’s sperm driven and it’s transgenerational***

> “*Sperm matter a lot. A lot. A lot more than we’ve given them credit for.*”‒ Paul Turek

**On the semen analysis, what if motility is the problem?**

- In Paul’s analogy of the poker hand, if everything looks good, but the motility is low, he thinks of **short-term toxins**, severity
  - Things like exposures, so medications
  - He would think about habits, behavior, lifestyle: pot, smoking, hot baths
  - He would look for an exposure in that individual, basically picked up on the history, **varicoceles** and exposure, things like that
- And if the count is down and the motility is down, he thinks of a longer severe exposure
- There’s royal flushes and there’s four of a kind

***Paul’s goal when he sees that semen analysis and sees that patient is to figure out, “If he’s not normal, why?”***

**Do you get that analysis the day he’s in the clinic with you? Or is that something you follow up on an appointment with?**

- Paul has this when he sees the patient

*Is this something that’s standardized and automated through microfluidics? How is the assay actually done?*

- It used to be done manually
- Now it’s done with the hemocytometers; it’s done with machines
  - Computer-assisted semen analysis does most of them in IVF groups
  - It’s standardized
- When Paul has semen analysis repeated, he usually has someone do it by hand because there’s observations he likes
  - For example, “*1% morphology, but all the others look like this*.”
  - Those comments are incredibly valuable that you don’t really get from a computer-assisted semen analysis
- But the computer-assisted semen analysis is faster and you don’t have a lot of human effort involved with a computer

*Are they using AI for this yet?*

- Some people are for sperm selection
- That will be really helpful for morphology to standardize it because one man named [Kruger](https://scholargps.com/scholars/95391916842199/thinus-f-kruger) in South Africa [correlated](https://pubmed.ncbi.nlm.nih.gov/2946611/) bad sperm shape with IVF outcomes and did not find that they were good when the sperm looked bad
  - That’s where the 4% came from
- But it’s really hard to do that every time and do it well
- Paul hopes AI, machine learning can help standardize the look, because sperm [morphology analysis] is hard

**LH and FSH are important. What else are you looking at? Testosterone?**

**⇒** To make normal amounts of sperm, you need proper amounts of testosterone and FSH

- Think of it as flowering a plant: you need the water and you need the sunlight
  - Testosterone, FSH are key

**⇒** To get normal amounts of testosterone, you’re going to need LH, which drives it

- Same in women
- These are all named in females
- There are cases of genetic infertility (like [Kallmann syndrome](https://en.wikipedia.org/wiki/Kallmann_syndrome)) where men aren’t making any sperm, but they’re just not sending the signals down
  - These men are not making FSH and LH
  - They have virtually no testosterone or sperm
- But you can just give them the signals with injections
  - Give them hCG, FSH injections, and they will be fertile

Peter asks, “*Is the problem in the pituitary, not the hypothalamus?*”

- No. It’s the olfactory node in the [hypothalamus](https://en.wikipedia.org/wiki/Hypothalamus)
  - So they don’t smell either

Peter asks, “*Could you give the* [*Clomid*](https://en.wikipedia.org/wiki/Clomifene#) *and they would make…”*

- No, the [pituitary](https://en.wikipedia.org/wiki/Pituitary_gland) is not working (the [GnRH](https://en.wikipedia.org/wiki/Gonadotropin-releasing_hormone) is not)

**Does estradiol play a role?**

- [Estradiol](https://en.wikipedia.org/wiki/Estradiol) is sort of a mild poison for male infertility
- Everyone needs an estradiol level (female hormone)
- Testosterone gets converted to estradiol
  - That’s a byproduct of it along with [DHT](https://en.wikipedia.org/wiki/Dihydrotestosterone)

**⇒** Estradiol goes to the brain and is a feedback for the brain to know how much testosterone it’s making

- It’s a negative feedback and will cause the body to make less testosterone
- High estradiol will lower your testosterone
- When estradiol is made, it gets metabolized differently than testosterone
  - It goes to the liver or to fat, and aromatases convert it to something else
  - Or testosterone gets converted to female hormone aromatases
- So you can get high levels [of estrogen] being obese or having liver dysfunction
  - So alcoholic cirrhosis, hepatitis will rev up the estradiol level
- Some medications that do it too
  - And that will act and lower your testosterone, which will lower sperm production because you’re not “watering the plant”

*If a guy has normal FSH, LH and testosterone, is there an estradiol level by itself that is problematic?*

- Not usually
- It’s really only high estradiol in the context of suppressed testosterone
  - That’s when  you could say, “*You need to lose 100 lbs.*”
  - You can also give [aromatase inhibitors](https://en.wikipedia.org/wiki/Aromatase_inhibitor) like weightlifters use to keep their [estrogen] levels down

## Effects of medication, microplastics, stress, and exercise on fertility [57:15]

**When investigating infertility, is there anything else besides the history, the exam, the semen analysis, and the hormones (the 4 big pillars)?**

> “*Usually do 2 semen analyses, 3 weeks apart or more to get a sense of things because it varies quite a bit… any feature of that semen analysis is varied by 50 to 100%*.”‒ Paul Turek

- Paul does a lot of consulting for the FDA and they do medications in reproductive age men
- They’re trying to show the semen analysis
- Paul tells them, “*Garbage in, garbage out*.”
  - There’s so much variability, you really can’t say anything
- You have to do at least two samples, and it still varies quite a bit
  - There’s inter-observer variability, who does the semen analysis
  - There’s biological variability on what your system’s like
- That’s the big problem with studies

**What percentage of drugs that are going through an FDA approval process are having a semen analysis as part of the evaluation?**

- Not many
- Usually the indications aren’t reproductive age men and women, for some of them
- If they do, they’ll do animal models
  - They won’t do human studies
  - They’ll do mice and beagles; and if there’s no fertility effects
  - They don’t really look at semen analysis in those
  - They’ll look at fertility effects in animals
- If there’s nothing there, then they’ll probably not require human studies
- If there’s any suggestion of a problem in the animal models, which is $1 million of work

**Why Paul patented the spermatogonial stem cell**

- He wanted an *in vitro* test for human infertility that we could use instead of animal models
- Save the animals; save $1 million

***Do an in vitro spermatogenesis model and see if there’s an effect at all***

- Peter points out that in this day and age, people are reproducing at older and older ages, we shouldn’t just assume that because we’ve developed a drug for blood pressure or diabetes that it’s not going to be used by people with fertility

**For example, have GLP-1 agonists been tested for fertility?**

- No, because it’s an off-label use of a diabetic medication
  - Even though it’s no longer off-label
- It looks like it might be helping with fertility
- But it’s just one example of a drug that was initially approved for people who were not thought to be having kids
- The truth is you’re going to have lots of people that are trying to reproduce on many of these drugs

***There are 80,000 chemicals out there that have not been studied reproductively that are commonly in use in industry***

- The European Commissions are a little better off
  - They’ve screened them and they’ve warned about them
- But America, negative
  - It’s attention to detail
  - It’s under the purview of the FDA and maybe the EPA
  - Or maybe everyone’s thinking it’s the other person’s job (Paul is not sure)
  - They’re untested and they’re out there

**Microplastics**

- Peter recently did a podcast on this topic ([AMA #67](https://peterattiamd.com/ama67/))
- He didn’t touch on fertility because he didn’t see any great evidence
- He talked more about things where there was a little bit more evidence
- With the microplastic story, there’s quite a bit of smoke, but there’s no real fire
- Peter’s conclusion from the analysis was there is enough smoke that takes steps where they are reasonable and reduce your exposure to these things

**⇒** So everything from microplastics to [PFAS chemicals](https://en.wikipedia.org/wiki/Per-_and_polyfluoroalkyl_substances) to [phthalates](https://en.wikipedia.org/wiki/Phthalates) and even the [PM2.5](https://en.wikipedia.org/wiki/Particulates) ‒ there’s no reason to expose yourself unnecessarily to this

***If you can take relatively straightforward steps to eliminate 60 to 80% of them in your life, do it***

**Tell me what your impression is of the effect of any or all of the above on fertility**

- Although sperm are made constantly and are susceptible to that, we know the testicles are a pretty good place and insulated from exposures
- There’s a lot of smoke there and it needs to be sorted out
- Especially with the 60 to 80,000 chemicals that are being used that aren’t really tested at all

***Paul thinks the only way to know is to do stem cell in vitro testing as much as you can before you put it on at the investigational drug stage***

- Not at the final stages for clinical trials, but early on do it
  - So you’re screening way in advance of getting into clinical trials and when the money gets big

**Paul thinks there are windows of susceptibility in men**

- Unlike maybe with women whose eggs are constantly exposed to toxins, men have windows

***One of those windows is birth and early development, the first 12 weeks of life***

- When all organ systems are developing, including testicles
- [Shanna Swan](https://www.shannaswan.com/about) did a [study](https://pubmed.ncbi.nlm.nih.gov/17392290/) on maternal beef consumption, estrogenized beef consumption
  - Their sons had lower sperm counts when they were 20 years later or something
- Paul thinks that’s a window of susceptibility

***He also thinks puberty is a window of susceptibility, when things turn on***

- Exposures in those moments are probably going to matter the most to men; he doesn’t know about other times

**What is your advice to a guy when you’re giving him counsel on everything he can do?**

- Should you stop drinking Starbucks coffee in those plastic cups with plastic lids
- Should you get a reverse osmosis filter in the house
- Where do you draw the line?
- Paul is not great at that because the stress level goes up so much, and the stress counterbalances any amount of microplastics you save

**⇒** You’ve doubled the stress in a man and his testosterone level will fall and then the sperm production falls for a whole different reason

- Peter recalls his testosterone level when he left residency
  - He was 33 and his total T was 220 ng/dL
  - He’s sure his FSH and LH were low but doesn’t remember what they were
  - Free testosterone of 3 to 4
  - The sleep deprivation, the stress

**Effects of stress**

- Stress is the [sympathetic nervous system](https://en.wikipedia.org/wiki/Sympathetic_nervous_system): it’s fight or flight
  - You’re running from a wooly mammoth
- It doesn’t know what you’re running from
- It doesn’t know whether it’s sleep or travel or financial or emotional
- It’s just the body
  - We are cats and dogs
  - We have the same binary nervous system
  - Either you’re on or you’re off

**⇒** And when you’re on, do you want testosterone? No. You want cortisol

- You’re running for your life
- And do you want fertility when you’re running for your life in any species? No
  - You’re trying to save your life
  - So cortisol goes on
  - Testosterone is nowhere to be found
  - Fertility’s nowhere. You turn off all that stuff
- Then when you outrun the wooly mammoth and you’re behind a rock and you grab the berries and you catch a nap, boom, testosterone shoots up because it’s rest and restore and you have to rebuild for the next run

Peter asks, “*How quickly do you think that occurs in humans?*”

- Days, easily
- Chronic stress is [the problem]
- We love acute stress
  - All species love acute stress
  - We love that starvation, intermittent fasting
  - It’s really healthy
- But not low-level chronic stress
  - Not connected to your computer, not your emails, not the workday that never ends
  - It’s terrible for us

**⇒** The best manifestation is erections because the erections will fall if you’re under stress too

- The penis has a mind of its own according to da Vinci

**Paul’s patient in San Francisco illustrates the effects of stress on the ability to maintain an erection**

- He was 25
- A startup guy
- He said, “*I lost my erection yesterday… It’s never happened to me before. I think something’s wrong*.”
- Paul asked, “*Tell me about yourself.*”
  - He’s just getting his A round of funding
  - He’s traveling a half a million miles a year
  - He sleeps 3-4 hours a night (if any), and he’s constantly running

Paul explained, “*Congratulations. Welcome to the human race. You’re not impervious. Stress has its effects.*”

**Exercise**

- There was a great [study](https://pubmed.ncbi.nlm.nih.gov/27645515/) on moderate exercise this went to extreme exercise
  - Extreme measured as 2 hours a day of 80% maximum capacity for 12 weeks
  - Exercise went from moderate to extreme and then back to moderate
- Paul wrote a blog on this called [*Can You Be Too Fit to Be Fertile?*](https://www.theturekclinic.com/blog/can-you-be-too-fit-to-be-fertile-male-infertility-exercise/)

***Sperm counts fell by 40% when moderate to extreme, and testosterone fell by 50% and then went back up***

- There’s also military studies of men under acute stress during “Hell Weeks” in training where they were taking their testosterones and LH
  - They were dropping by about 50% with severe stress
- And that’s okay for a day or two or a week, but when you’re doing it chronically, we’re not built for that

> “*We’re not built for chronic stress. That’s a longevity issue.*”‒ Paul Turek

## Testosterone replacement therapy (TRT) and male fertility [1:06:00]

**The 3 most commonly used approaches to testosterone replacement (TRT)**

- Are using either clomiphene or enclomiphene, using hCG, or using exogenous testosterone in one of its derivatives
- 1 – [Exogenous testosterone](https://en.wikipedia.org/wiki/Testosterone_(medication)), you’re just giving testosterone
  - The body senses it and immediately shuts down the hypothalamus, shuts down all natural production
  - [LH](https://en.wikipedia.org/wiki/Luteinizing_hormone) and [FSH](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone) will go to zero
  - Testosterone will be as high as you want it to be
  - Peter has had a couple of people on this podcast who have blown his mind with how much testosterone they’ve talked about taking
    - [episodes [#274](https://peterattiamd.com/derekmpmd/) and [#335](https://peterattiamd.com/mikeisraetel/)]
- 2 – [hCG](https://en.wikipedia.org/wiki/Human_chorionic_gonadotropin) is synthetic luteinizing hormone
  - So you give a person hCG and they will make testosterone
  - It’s endogenously produced, but they’re making so much of it that they’ll also suppress LH and FSH
  - So LH and FSH will come down
  - Testosterone will go up
- 3 – [Clomiphene](https://en.wikipedia.org/wiki/Clomifene) or [enclomiphene](https://en.wikipedia.org/wiki/Enclomifene) block the signal of estrogen at the level of the hypothalamus
  - So the hypothalamus thinks it doesn’t see any and needs to make more testosterone
  - It ramps up FSH and LH production, which has the same effect as making more testosterone
  - You’ll now see high normal FSH and LH
- The 2 different classes are the LH and the Clomid versus testosterone

Paul explains, “*Unlike testosterone shutting off the natural production (that LH), the hCG and the clomiphene, enclomiphene will stimulate natural production. So you keep your testicular size. You maintain your fertility. Whereas the others, you’re going to shrivel up your testicles and not maintain your fertility. And you can’t generate levels that you can with the exogenous testosterone with these. You’ll never get to 3,000. You can’t do that. It’s tightly regulated.*”

**If a guy has been taking exogenous testosterone for a few months, is he able to create sperm?**

- 95% chance he’s not while he’s on it

**Peter’s takeaway** ‒ even a couple of months on exogenous testosterone in any form, injection, topical, oral, whatever, you basically have shut off the ability to make sperm because your testes themselves have shut down

*Paul explains the nuance*

- There are formulations that are topical that are less potent that way, less inhibitory than injectables
- There are variations in the spectrum of exogenous testosterone that will maintain some of your fertility
- The marketing material is suggestive that the more frequently delivered variants, for example, the intranasal variant, which is delivered 3x a day
  - The oral variant, delivered twice a day, have less of a negative impact because they’re producing far lower surges than if you did a weekly injection
  - Correct
  - They’re in the normal range more
- What gives you side effects from testosterone (including sterility) is too much

***Men taking*** [***Natesto***](https://www.natesto.com/) ***3x a day (intranasal) keep their sperm counts***

*What about oral testosterone twice a day?*

- [Testosterone undecanoate](https://en.wikipedia.org/wiki/Testosterone_undecanoate) was not available in America for 50 years
- It was available in Europe
- [Study](https://pmc.ncbi.nlm.nih.gov/articles/PMC4168025/) out of UCLA on oral testosterone [that led to the FDA approval of oral testosterone replacement in  the US]
- We were worried when we took oral testosterone that it would go to the liver and cause liver cancer
  - There was no evidence this was happening in Europe for 50 years
- It’s FDA approved; the EEA approved it
- This group came up with a way to get it metabolized through the lymphatics
  - It is absorbed through the lymphatics and never hits the liver
- It’s really good, there is a non-response rate of around 10% of men
- Some men like gels too
  - 15% won’t respond
  - There’s groups that won’t respond that well, but it is really good
- Paul prescribes it

**Peter has prescribed testosterone undecanoate to maybe half a dozen patients, and one of the challenges is they don’t know when to time the blood drawl to see the level of testosterone**

- For example, if a guy takes the drug at 8:00 in the morning and then at 1:00 in the afternoon ‒ if he does his blood draw at 7:00 the next morning, he’s been 18 hours off drug
  - He has unmeasurable testosterone
  - He’s going to show up at 200
  - He’s going to look like Peter did 50, 20 years ago
  - His LSH and FSH are still completely suppressed because that doesn’t go away over 18 hours
- Peter doesn’t know how to interpret what is he walking around at during the day, which is what he cares about
- Paul explains that you usually want to give them a couple of weeks to stabilize hemostatically
  - You don’t want to test it right away
- Usually you can get pretty good levels because the half life isn’t that short
  - They say it peaks in 5 hours
  - The half life is probably more like 12 hours
  - You wouldn’t dose it at 100% decay; you would dose it at 50%
- Paul thinks he’s probably not responding
  - We can check it at different times, but it’s probably not much of a response

**What is Paul dosing testosterone undecanoate at? (It comes in 100 and 200)**

- He usually goes to the mid-dose 298 twice a day, and then you can double it or whatever
- He doesn’t start out at the lowest dose, and it depends what you’re trying to solve in the problem
  - If you’re not going to get them to 800 or 1000 very easily, you can get them 400 to 600, 600, 700 pretty well, but no side effects
- Paul hasn’t seen anything, maybe a couple dozen men, really well-tolerated

**Peter’s takeaway:** this is not something you use when you’re trying to get a guy from 300 to 1000

- You could, but this is not Paul’s first choice
- Because now you would be taking 500 twice a day or something crazy like that
- Twice a day is a big deal for men

**Are you using** [**Natesto**](https://www.natesto.com/)**?**

- Paul has never prescribed it
- No one tolerates that
- You have to spray it in each nostril 3x a day
  - And it’s gooey and it’s gel-like.
- Within a week, men will call and say they can’t do this
- Peter has had more luck getting women to use this

***The other big differences between the 2 types of testosterone replacement or supplements is the side effect profiles differ widely***

- Comparing what we call the natural ones versus the exogenous ones
- It’s very difficult to get [polycythemia](https://en.wikipedia.org/wiki/Polycythemia) (or thickening in your blood) with the physiologic levels
  - It just doesn’t happen very often
  - Paul has seen it once or twice
- But if you take testosterone exogenously you’re at risk for polycythemia or blood thickening
- Testosterone stimulates [erythropoietin](https://en.wikipedia.org/wiki/Erythropoietin) in the kidney, you make more blood
  - Athletes love it
  - But if you on a long flight and you’re dehydrated, you’re going to throw a clot
- People look at it for longevity, but you need to be careful
- Paul has seen 70-year-old men who want longevity in taking this stuff, and then they have a clot and they have a stroke and now they’re 71 and…

**⇒** The clot risk is proportional to hemoglobin hematocrit

- [Ramasamy](https://en.wikipedia.org/wiki/Ranjith_Ramasamy) just did another [paper](https://pubmed.ncbi.nlm.nih.gov/35050717/) on it
- The most significant event occurring with testosterone replacement or supplementation is polycythemia and events
- The high level for hemoglobin 17, hematocrit 50, you start seeing events happen about 18, definitely at 19

**Testosterone injection schedule**

- Some of Peter’s patients who are injecting testosterone cypionate, inject 10-15 mg every single day
  - They don’t have the polycythemia
  - They don’t hit those crazy peaks
- 10 years ago, everyone was prescribing 200 mg every 2 weeks (which is crazy)
  - Highest risk [for polycythemia]

*Paul’s typical injection schedule*

- Once a week
- Twice a week is a little safer
- Often patents want a pellet instead
  - He offers that too

**Testosterone pellets**

- Peter doesn’t know the kinetics of it but would imagine that you’re super physiologic for a month or so

Paul explains, “*Pellets are like the long-term contraceptives for women in the arm*.”

- They put it subcutaneously (he puts it in the butt), and it’s a couple minute procedure in the office
- You don’t have to worry about anything
  - There’s no compliance issues
  - You don’t have a lot of side effects or consequences from it
- It’s done with a trocar and a thick needle
- And pretty quickly within a couple days, you’ll get a level, and then it’ll slowly decay
  - Pretty much half of it by 3 months or so and then the rest by -f months
- It’s supposed to be a six-month physiologic level, but normally it’s 4 or 5
- Men feel great for a while and they can feel it because it’s slow, but it is even
- You do have this risk of polycythemia and things like that, but there’s a 3 month period of risk and then usually when you’re in the normal range, it kind of goes away
- Paul doesn’t see a lot of consequences with that if it’s 6 months

**Use case for Clomid (and the generic clomiphene), and levels of testosterone associated with different symptoms**

*Back to the Clomid-hCG route, what is the extent to which fertility is preserved when a man is on one of these agents?*

- Paul gives [Clomid](https://en.wikipedia.org/wiki/Clomifene) all the time for fertility
  - It might even improve it while hCG depends on the dose

**⇒** High doses of hCG suppress [FSH]

- Normally you want LH and FSH going to the testicle
  - Analogy: you want the water and the sunlight
- You want the testosterone
- If you’ve got the testosterone, but your FSH is [low] (if you don’t have any sunlight), you’re not going to bloom

**⇒** Paul usually adds Clomid to hCG if the dose is above 1500 units, 3x a week [to preserve fertility]

- Because that’s going to start suppressing the FSH
- And Clomid will keep it going, and then your fertility is preserved

Peter reacts, “*1500, 3x a week of hCG is a whopping dose. You’re saying beneath that you typically don’t have issues with FSH and LH suppression?*”

- Right
- You will because it’s LH but not FSH
- Maybe 1000 to 1500, you start seeing it
- That’s why you protect the fertility

*What dose of Clomid will you give on top of that regimen?*

- It depends
- Usually half a 50 mg pill a day
  - 25 mg every day
  - Peter thinks these are staggering doses

*How high does testosterone get for these guys?*

- The testosterone is driven mainly by the hCG
- Paul shoots for the normal range of 500-1000 (not anabolic)

*Peter’s experience prescribing clomiphene (the generic form of Clomid)*

- Peter doesn’t like clomiphene for a whole bunch of reasons that have to do with lipid stuff
- He would prescribe it 3x a week
  - About the same as 25 mg per day
- For most guys, that would be sufficient alone (even without hCG)
- Peter would give 12.5-25 mg for isolationist monotherapy

Paul explains, “*It’s hCG that’s driving the T. We’re just trying to protect it*.”

**Do you prefer Clomid or clomiphene?**

- Clomiphene is really good

*It’s an interesting FDA story*

- Clomid is not approved for men and neither is clomiphene
- Clomid is approved for women, and clomiphene is not approved for either
- Clomiphene is compounded
- Clomid has been available for 50 years so there’s a lot more data
- And once a cis isomer was a trans isomer ‒ they’re different, and the estrogenic effects are slightly different

*Paul has enormous experience*

- He has 560 men on Clomid
- He has fewer on clomiphene

*Clomiphene citrate was developed for older men to preserve their testosterone levels as they age*

- Because the signaling tends to get weaker, the pituitary tends to get lazier, and this is to keep your testosterone levels up more physiologically than taking testosterone
- It went through some very good randomized trials that were published
- It went to the FDA for approval for secondary hypogonadism
  - For age-related changes
  - Not for primary testicular failure in age-related androgen deficiency of the aging male (or ADAM)

***The FDA sat on it for a couple of years and said, nope (they didn’t approve it)***

**⇒** There are good trials; it’s safe; it’s as good as Clomid

*It’s hard to know why the FDA didn’t approve it*

> “*I think the reason was that there’s such an uproar about testosterone in America right now, and the FDA doesn’t like what’s happening*.”‒ Paul Turek

- What happened is you can advertise your drug to the consumer now
- So all the biological response modifiers for psoriasis, all those drugs go on and they give you 5 seconds on the benefits and the lesions go away and then 25 seconds of side effects
- If you do that with testosterone, what you hear is:
  - Are you falling asleep after dinner?
  - Are you not as athletic as you used to be?
  - Are your erections not as good as they used to be?
  - There’s 10 questions in the [ADAM questionnaire](https://themenshealthclinic.co.uk/adam-questionnaire/)

***Everyone who ages has those issues, and if they advertise on TV, they’re going to want this stuff***

- So now when any testosterone trial comes back, they’re going to point out the FDA, make sure that we point out the dangers of testosterone replacement

***This is part of that energy, which is we don’t want another testosterone***

*Peter thinks there another reason*

- It’s everything Paul just said
- But hCG and testosterone are [schedule IV](https://en.wikipedia.org/wiki/Controlled_Substances_Act#Schedule_IV)
- Which means you cannot prescribe them through these testosterone clinics that don’t even see patients and are literally just not being doctors
  - They’re just sort of giving it to anybody who shows up and pays
  - It’s a coin operated testosterone dispensary
- But Clomid (and Peter assumes by extension for clomiphene) is not scheduled, which means you can coin operate those
- That’s probably why the FDA is saying what it’s saying

***It’s already bad enough that the Clomid cat is out of the bag, but we don’t want to put another one of these unscheduled drugs out there in the land of shady medicine***

**⇒** The indications are pretty clear, and they’re really safe

**Paul’s use-case**

- When someone comes in who is young, who maybe wants kids but hasn’t had them and they have a low testosterone of 220
- You measure their LH (which no one does), and it’s low ‒ it’s secondary hypogonadism
  - It’s not testicle failing
  - It’s a signaling issue
  - That’s probably stress
- If Paul tells them, “*Get rid of your stress;*” they ask, “*How do I do that?*”
  - Exercise, acupuncture, massage, or yoga

> “*For men, I say physical activity is the best thing for sex*.”‒ Paul Turek

**Aside on the benefits of physical activity for improving sex**

- During COVID, everyone’s life was a mess, and Paul had 2 groups of men
- Half of them started drinking a lot
- The other half went out for runs or got a Peloton
- Then about six months later, these guys realized it’s not working, and they started shifting over to exercise
- Paul was very proud of them
- Because the best way to handle stress is when you have no control over things go for a run, go for a walk, get out there
  - It’s just decompressing, hold to get your mind off something, anything surfing, whatever
- When men don’t do that, Paul will give them Clomid
  - Hell ask them to try it for 3-6 months and see how they feel
- Sometimes it’s sexual health issues

**⇒** Erections aren’t typically that dependent on testosterone; typically it’s other things

- Paul gives them the benefit of the doubt ‒ maybe their testosterone was higher before (we don’t know that)
- Let’s do something pretty safe and easy to double or triple your testosterone [Clomid]
- He’ll check in with them at 3 and 6 months
  - Either they feel great or they feel the same (and it’s not testosterone related)
- We know the levels of testosterone above which you should not have symptoms
  - For erections it’s about 290

***Most guys that are having difficulty with erections have a testosterone level above 290, so there’s some other issue but you have to prove it to them***

- Paul is fine with that as long as it’s safe (you’re convincing them)

**The levels of testosterone above which you should not have symptoms**

- Erections: 290
- Libido: 350 range
- Fertility: 300
- Mood tends to be a lot more variable
- Other thresholds would be anabolic capacity, like muscle mass and things of that nature

Paul explains, “*I think there’s myths around testosterone and those are some of them, but is sort of a Morgentalor and equilibrium story where if you’re low, you have symptoms and you’re low, those symptoms will get better when you go up. But then there’s a point where it flattens out. There’s no increase or improvement in symptoms.*”

- Sexual health symptoms are classically ascribed to that
- For things like blood and muscle, it’s a linear relationship between testosterone
  - So more is better for blood doping and also for muscle

**What Peter recently learned talking to body builders who were taking 500-2,500 mg of testosterone a week**

- His initial reaction was, you’ve already saturated the androgen receptor, at least 1 or 2 logs earlier
- But they convinced him, no, no, no
- There’s a real difference between 500 and 1000 and 2500 in terms of muscle mass, which it sounds like Paul agrees with
- Peter doesn’t understand the physiology of how that’s possible
  - How many androgen receptors would you need?
  - You’d have to up regulate them when in fact you’d be down regulating them

***Paul is not sure, but thinks the effect of testosterone on muscle mass is indirect***

- It’s not that you’re going to do it and create mass
- You don’t just create mass

**⇒** What it allows you to do is recover from injury

- So if you push the system and you need 2 days to recover, you can go to 1 day, and you can push it again harder
  - That’s what testosterone does in the primitive world
  - Paul is not sure that’s receptor driven
- Peter recalls studies that show that high enough doses of testosterone will increase muscle protein synthesis absent the stimulus, absent the lifting stimulus
- It might be several pathways going on that are logarithmically better, but it allows you to push the system and go back and then push it again, and that’s how you build muscle

## Restoring fertility after prolonged use of exogenous testosterone [1:25:00]

- Let’s say he was given poor advice 3 years ago
- He went to some shady back alley website
- He was 27 years old at the time
- This is tragically a very common story
- This guy’s been on 200 milligrams of testosterone a week for the past 3 years
- He is now 30 years old; he’s met the love of his life, and they he can’t seem to get pregnant

**Tell me what his sperm analysis looks like**

- Peter presumes there are no sperm
- Paul has 95% confidence that he would have no sperm in his semen

**How are you going to solve this problem?**

- A lot of guys come in, they look good, they never put it on their medications or write it out in their history
  - You always have to get it out of them
  - Paul will look them in the eye and say, “*Are you taking testosterone?*”
  - He’ll look them in the eye until they answer
  - If they look down or don’t say anything, he knows they’re on it
  - If they look him in the eye and say no, he knows they’re not
  - But they’ll always look away
- Peter compares this to the ER ‒ people that come in with foreign rectal bodies and abdominal pain
  - That’s the one thing they omit from their history
  - You get the x-ray and there’s a candlestick in their colon
  - They’re like, “*I totally forgot to mention that, yes*.”

*Paul’s approach for guys taking testosterone for anabolics*

- Paul has been doing research on the lifespan of anabolic storage users (he’ll come back to these findings)

**⇒** If he’s been in constant use of injectables, that’s the most suppressive of fertility; and if you turn a gland like a testicle off long enough, it’s off

- Paul gave a lecture to the Endocrine Society on young men recovering from hypogonadism and asked a question at the end
- Paul’s procedure comes from steroid users and it’s called [*Getting Off the Juice*](https://www.theturekclinic.com/blog/juice-steroids-anabolics-azoospermia-sterility/)
  - He takes notes when he sees anabolic guys because they’re really smart, and they know a lot about reactions biology (some of them are PhDs)
  - His [blog](https://www.theturekclinic.com/blog/juice-steroids-anabolics-azoospermia-sterility/) includes a [PowerPoint](https://www.slideshare.net/slideshow/managing-the-young-hypogonadal-male/14422735)

**⇒** Recovery is usually possible in young men, but it depends on how much they took, how long they took it and how they took it

- If they do it like a cycling effort, that’s the best
  - If you cycle steroids, you recover the pituitary, you get back to normal and then you hit it again
  - That’s actually quite smart; constant use is not
- Constant use for longevity or whatever is not a good idea for fertility
  - That’s going to be much more suppressive
- Injections are worse than orals or any gels

Paul asked the Endocrine Society, “*Can you turn a testicle off like in a thyroid or an adrenal gland? If you suppress it enough, can you turn it off for good?*”

- They said that was one of their board questions
- They believe it’s always reversible in the field of infertility in men
- That got Paul worried

***He worries about 5-10 years of use: after 5-10 years of use, you may not get it back, either the ability to make sperm or the ability to make testosterone***

- Peter tells men in his practice that 2 years would be the absolute ceiling (at a dose of 50 twice a week)
  - That might be too conservative
  - It depends on the dosing and everything
  - Paul thinks it would take a while at this dose
- Paul published a [study](https://pubmed.ncbi.nlm.nih.gov/7714991/) when he was a fellow in Houston of a guy who took testosterone for 25 years
  - He treated him with gonadotropins such as hCG and FSH and didn’t get anything but a low number of sperm back
- Paul just had a guy from Louisiana come in with 25 years of chronic use
  - He did a mapping procedure to find sperm in his testicle, and he made a couple of sperm
  - He’s going to be having a kid
- You pump him full of hCG and synthetic FSH for a year and get nothing
- Then you have to look in the testicle because production can be low enough to be there but not coming out

***The rescue protocol is LH and FSH***

**There’s 3 ways to do it**

**⇒** Never stop the testosterone suddenly

- Because men will hit the doldrums, and they’ll flop over like they have the flu
- They’ll feel like shit, and they’ll get right back on it
- They’ll feel terrible because they have nothing going on [no T]
  - If you take the testosterone away, their system’s turned off, they’re not making their own. It takes time to get the system to reactivate

***That’s why Paul always tapers [down] testosterone over 6 weeks***

- Typically, you have the dose for 2, have the dose for 1, and then off for 2, and then you measure

1 – Taper alone

2 – Taper with Clomid or Enclomiphene, which is a little quicker getting the pituitary to turn back on

- That will soften the blow of the feeling of feeling completely fatigued

3 – Taper more aggressively with hCG and Clomid

- Then he usually checks them at about 6 weeks

Peter asks, “*If you give Clomid, the pituitary will make FSH and LH?*”

- Yeah, it takes a while
- That’s a more cost-effective approach than giving synthetic because synthetic FSH is pricey (a couple thousand a month)

**Is there any reason to do that over the Clomid approach or is it just that it’s faster?**

- You might gain a couple of weeks of time

**⇒** With that taper over a month or two, Paul usually checks their T-levels at around 2 weeks off of the last testosterone and that’s the lowest they’ll be

- And if they’re in a good range there, you can use that as a predictor of their response
  - A good response would be if they’re in the normal range
  - 300 would be okay to make sperm
- But then to get them to where they want to be depends on their symptoms and what they’re happy with
- You won’t know til you wait longer to see how high you can get them

**If they go along that taper and they’re not tolerating**

- Paul advises, “*Don’t go back. Just stay there because time will help you. You are not going to feel maybe that great, but try to do this because if you go back, then we have to start over. But if you just maintain it for a while, you’ll feel better*.”
- And some of them dip a little bit, but remarkably, most men do really well with that taper

**Do you ever advocate crazy ideas for guys that are using testosterone to use lower doses and then combine it with hCG? Just as we were talking about the Clomid plus hCG approach?**

- All the time
- It’s not an unreasonable approach to combine Clomid with testosterone at low doses to preserve testicular function
- Yesterday Paul operated on a man (testicular sperm retrieval) who was exospermic for genetic issues, and he was on testosterone for 10 years because he needed it
  - His testicles were failing
  - Paul told him he was not going to make sperm on this
- Paul put him on hCG (3000, 3x a week) for six months or maybe a year; the guy felt terrible and couldn’t maintain that
- So Paul added a low dose of testosterone gel and lowered the hCG to 500, 2x a week
- In the sperm retrieval he got plenty of sperm
- This guy was 35-years-old

> “*You can maintain whatever’s going on in the testicle with hCG and take any testosterone you want*.”‒ Paul Turek

- Peter agrees, “*That’s an important lesson*.”

**Here’s the catch though**

- Paul thinks this was shown in Finnish bodybuilders
- They were doing a cycle of steroids, huge amounts
- They took low dose hCG (500 twice a week)
- [John Amory](https://gim.uw.edu/people/faculty/john-amory) at the University of Washington, has [worked out](https://pubmed.ncbi.nlm.nih.gov/15713727/) all the exact doses, but 250-500 twice a week is a good dose for that
  - It keeps your intratesticular testosterone high, keeps your sperm production going
- They went on both concurrently for 12 weeks, and their sperm counts were normal the whole time at any dose of T
- Now what happened after that is people start saying, “*You can preserve your fertility on testosterone replacement*,” which is possible

***But it was only 12 weeks***

**Do you think that there’s a difference between hCG and Clomid in that effect as the adjunct?**

- Oh, yeah, Clomid doesn’t work
- hCG is the one
- Clomid doesn’t improve intratesticular testosterone levels like hCG does; it’s ineffective
- It will potentially make you more recoverable
- If you do it 80%, you’ll be zero even though you thought you might have a sperm count, but your recovery will be faster because it’s done something

Paul explains, “*The only way to maintain your current fertility is you have to be 100% compliant with dual therapy. You can’t go on monotherapy with testosterone.*”

**Outside of fertility, given the popularity of testosterone replacement therapy today, is there another advantage to just doing dual therapy?**

*As opposed to just being on testosterone injectable, to do the dual therapy versus just monotherapy*

- No, I think the only reason would be if you want testicles to be big

**Paul just created a new procedure to make testicles larger naturally**

- By putting a fat injection in the hydrocele space in men on testosterone
- For men that don’t like their small testicles
- Peter jokes, “*It’s the equivalent of the Brazilian butt procedure for the testes.*”
- Testes fat grafting is all natural and there’s no prosthetics, and you can’t tell
- It makes them nice and big

Peter asks, “Medicare *approved?*”

- No, creatively approved

## Effects of heat and cold exposure on fertility and sperm quality [1:36:00]

**Tell me about the impact of cold plunging and sauna and hot-tubbing on fertility for men**

- The testes are outside the body and 3 degrees cooler than the rest of the body (95 versus 98 degrees F)
- The reason for that is unknown
  - It may be that it’s an immunologic sanctuary, and that’s the only way to do it and that God or Darwin could figure out
- If you heat up the testicle
  - It’s also close to the skin; so it’s a radiator
- When the heat comes down, the arterial blood has to cool, so it raises and lowers
- There was an article in the [*Journal of Irreproducible Results*](https://en.wikipedia.org/wiki/Journal_of_Irreproducible_Results) about 20 years ago about a man who went to Big Sur and wore nothing [not available online]
  - He measured ambient temperature, and then he marked on this leg with a marker where his scrotum hung, how low it hung
  - He could tell the ambient temperature by how high or low his scrotum hung
  - He became a thermometer: it does go up and down

***It showed that the scrotum is very temperature sensitive and it goes up and down to regulate it***

- Closer to the body when you want it warmer, etc.
- You go into a cold shower or plunge and you’re testicles are way up there
- That’s all the cremasteric muscle, and it’s all temperature driven
- It spends all of its time regulating its temperature to stay at 95
- Saunas baths, hot tubs, jacuzzis, steam rooms change that

***The worst one of those is anything underwater, submerging underwater because you’re one centimeter away, you’re a liquid, it’s a liquid***

- It’s like little kids going into hot tubs ‒ they overheat

**⇒** Typically a hot tub is 105-110 F, and within a short period of time, you’re testes will assume that temperature

**Paul published a** [**study**](https://pubmed.ncbi.nlm.nih.gov/17335598/) **on wet heat exposure in the Brazilian Journal of Urology**

- Of the 200 studies he’s published, this was the hardest to get in
- It’s probably his most cited paper
  - Certainly not his best, but it’s very interesting

***He took infertile men with low sperm counts and stopped the hot baths ‒ semen quality went up 300%***

- These men were 35-years-old
- Total MOT count [sperm motility] went up 300% in 3 or 4 months and 600% in 6 months
  - You have to give it some time; that’s the recovery curve
- He didn’t look at fertility, we just looked at that recovery
  - Some were zero and went up to close to normal
  - [see also [Paul’s blog](https://www.theturekclinic.com/blog/hot-tubs-male-infertility-heat-azoospermia/) on this]

**What’s the lethal dose (to sperm) from a hot bath (the LD****50****)?**

- To Paul, the lethal dose means you’re at zero (you have no sperm)

***20 minutes of 104-degrees F, 3x a week would probably make you zero***

- Peter thinks there have to be a lot of guys out there who are doing this
- Paul adds, “*The largest group of people in tubs in Northern California, we did the study, were environmental lawyers. Is your job that stressful? They said yeah, it is.*”
- The only study ever done prior to that was a PhD thesis at Vassar College where someone had a guy dip their testicles into a bucket for 20 minutes at really hot and looked at their sperm counts or their fertility
  - Paul couldn’t even find it published, it was a thesis thing
  - But that’s how little was written about it
  - And they gave Paul so much flack for publishing this
- It’s funny, *The New York Times* had an [article](https://www.nytimes.com/2007/09/18/health/18real.html), drew a condom and it drew birth control pills and it drew a guy in a tub [shown below]
  - It said, pick your contraceptive: “*Regular exposure to hot tubs can hurt male fertility, though the effects can be reversed*.”

![](https://peterattiamd.com/wp-content/uploads/2025/05/f3-paulturek.png)

**Figure 3. Regular exposure to hot tubs can hurt male fertility**. Image credit: [*The New York Times* 2007](https://www.nytimes.com/2007/09/18/health/18real.html)

Paul explains the impact, “*It’s huge. I’d say 10% of my population’s in it.*”

**What about saunas?**

- A saunas is not underwater, it’s not submersion
- You’re in a hot room, it’s going to affect it
- Paul estimates the effect is ¼ to ⅓  of a hot bath (or submersion)

Peter reflects, “*So my friend was absolutely right to have those ice packs on his scrotum… He’s a smart guy.*”

***Paul thinks steam rooms and showers are probably fine***

- Urine and ambient temperature is normal
- For steam rooms, it depends on how much time you spend in one, but it’s not as bad as a hot bath
- Hot baths are terrible

**What about the cold?**

- Paul doesn’t worry about the cold
- He remembers *Surfer Magazine* called him and asked, “*Are surfers infertile?*”
  - He’s a Northern California surfer, not an LA surfer
  - California water is 60-degrees F
  - Paul has never met an infertile surfer, so he doesn’t think it’s bad at all

***It’s not bad, especially a plunge where you’re talking seconds ‒ your muscles are going to go up and you’re going to be able to maintain that heat***

- If you did it all the time, it would probably be bad because enzymes in the testicle work optimally at that one temperature

## How different levels of exercise—especially cycling—affect male fertility[1:41:45]

- Earlier Paul mentioned [one example](https://pubmed.ncbi.nlm.nih.gov/27645515/) of exercise that can be problematic: 2 hours a day, 5 days a week above 80% VO2 max
  - That was enough to put a dent in their fertility

**Tell me about riding a bicycle**

- Paul is a biker
- He has old vintage bikes he used to race in Connecticut
  - He had them rehabbed
  - They’re all Italian, all steel, and they weigh a ton
  - The seats are from Britain, they’ve got 10,000 miles on them, and they weigh 4 lbs. (Brooks leather saddles)
    - A saddle nowadays is about half the weight of a carbon bike
- It’s like golf clubs, Paul is going to be as bad a golfer with a $150 set of clubs as with a $1000 set of clubs
- In San Francisco, Paul bikes into work

*The problems with the bike seat*

- It got started that biking was bad for reproductive health with a Spanish competitive cycling [study](https://pubmed.ncbi.nlm.nih.gov/9018515/)
  - Competitive Spanish cyclists, Tour de France caliber cyclists, their sperm counts were examined
  - [the groups studied were: professional cyclists, elite triathletes, recreational marathon runners, and sedentary men]

***The cyclists sperm counts were low, their morphologies were off***

- And they’re extreme athletes
- Maybe they were on drugs, it’s a big industry, they’re super fit
- They’re certainly exercising 2 hours
- The study said, “*Look at these guys who are really healthy and look at their sperm counts.*”
- But this other data did come out
- Paul wrote a blog called [*Cycling Towards Childlessness?*](https://www.theturekclinic.com/blog/cycling-childlessness-sperm-counts-male-infertility/)
  - He looked at a more comparable [study](https://www.liebertpub.com/doi/abs/10.1089/jomh.2014.0012?journalCode=jomh) of British commuting cyclists, everyday people bicycling the work in Britain on different saddles
  - He looked at their fertility, and their fertility was far better than the average Brit

**Peter’s takeaway** ‒ even if they were taking some hit off the bike, it was more than compensated for by their healthy lifestyle (which included riding the bike)

- Obviously there’s a healthy user bias because anybody who’s riding their bike to work is probably consuming less Guinness, fewer fish and chips, smoking less
  - In other words, riding a bike is a proxy for being healthy, but in spite of that, it didn’t offset that health risk unless we found people who were equally healthy who didn’t ride a bike
  - Paul doesn’t remember what they controlled for

Peter asks, “*Is this a myth?*”

- Yes

***Paul is worried about bicycles: he worries about sexual health, worries about the*** [***pudendal nerve***](https://en.wikipedia.org/wiki/Pudendal_nerve)***, and worries about the seat anatom***y

- If you’re biking a lot, that’s good

**⇒** If you’re biking and you’re getting pelvic numbness, that’s bad ‒ you need to get a better seat

**The best seat was** [**studied**](https://www.cdc.gov/niosh/docs/2010-163/default.html) **by Dr. Schrader at the NIOSH**

- Bicycle seats that come into the middle where the arteries and nerves are to the penis are bad
  - Bad for your sit bones
  - It’s an erection issue

***The saddles with the two little tongs that hold your iliac crest bones with no nose are perfect [a no-nose bike seat]***

![](https://peterattiamd.com/wp-content/uploads/2025/05/f4-paulturek.png)

**Figure 4. Example of a noseless bicycle seat**. Image credit: [Amazon](https://www.amazon.com/Oversized-Noseless-Comfortable-Exercise-Replacement/dp/B0DQ134RSP/ref=sr_1_20?crid=16403X9ALLZ9Z&dib=eyJ2IjoiMSJ9.S98AKHgUgbJkqM61vwhxzfbsQIv8GvMw05l-ObR7lZpcDvX_0TP9qMUgz2Tu8mJusTCGkoTsmnoKMjx2tnelATyoXzdNO4uK6-FyosI7f7PO42nrI5FIRw69fA4Q84CpSw0IoSAxiWE8FAQgpAu6gPVP8DqBIm67bUw3YwDJ3gIo4dyx3ovahlbUH6ODqidNHy1KGvkT592HY99QDpNPms4_X5IF6r5THgA3OfRd1sQXn9Vl_bup3xGs5k4GhtslOJUIxnVbP-j4oQGUbefu8ovCzzPy1-4JjSVHJ_RLCQM.b6fP25wmCsJTl2XRJzhmzcPtka510pJx2o1iqODZ3gw&dib_tag=se&keywords=no-nose%2Bbicycle%2Bseat&qid=1745248957&s=sporting-goods&sprefix=no-nose%2Bbicycle%2Bseat%2Csporting%2C81&sr=1-20&th=1)

- The pressure is outside leaning in
- We gave those bike seats to police in Washington in the National Cathedral area, and they all gave the seats back a week later
  - They said, “*We’re not doing this. We don’t know where the seat is. We go to sit down and it lands somewhere*.”
- You have to have the nose for bicyclists, because they use it to guide where they sit

**Paul’s advice on the best bike seats for men**

- The best saddle is flat or gel in the back, cut out in the middle, and some kind of lean in
- So cut out saddles and then you should get your bones fit
  - You can do this online, you can ask them to send you a pressure pad and you sit on it and then you send it back and then measure the distance
  - There’s only a couple of different saddles, maybe 12 widths that you could do and you get it done
- Or like Paul, he’ll use a saddle for 30 years and it’s perfect, but it weighs 4 lbs.
  - It’s leather and it’s fit to him

## How alcohol, marijuana, and nicotine affect male fertility [1:46:00]

**Let’s talk specifically about the effects of alcohol on fertility**

- For men, the government considers less than 2 glasses of alcohol a day to be okay
  - 4 a day is binging

> “*Now, alcohol is a small molecule, goes right into the brain, goes right into the testicle, it’s definitely a poison… I worry about it a lot. The effects I see are direct, when it’s abused*.”‒ Paul Turek

**⇒** Paul sees a direct effect of alcohol on sperm morphology, motility, and count issues

- Alcohol is one of the few things that gets into the testicle

**⇒** The hormonal effect of alcohol: it tends to cause the liver to rev up estrogenization, so you tend to get low testosterone from that

***Alcohol has both a hormonal effect and a direct effect***

Peter asks, “*Any evidence that it’s having an epigenetic effect?*”

- Probably
- Paul doesn’t know about the evidence

**Marijuana**

- Marijuana ([THC](https://en.wikipedia.org/wiki/Tetrahydrocannabinol)) is the worst player for Paul
- The same problems on sperm count, motility, and morphology
- We know it has an effect on fragmentation, which is a quality measure of sperm
  - Not only the way it looks, descriptively, but quality
- It probably has an epigenetic effect
- Some of the early studies on sperm epigenetics showed alterations with nicotine and with pot

Paul adds, “*What I don’t like about pot is, you ingest it (and however you ingest it), you get a peak, you feel it, it goes away, you feel it’s out of your system (like nicotine), but it sits your fat…*”

- It sits in your fat for 3 weeks to a month, and it’s a depot effect (it keeps coming back)
- So you get a low level of toxicity
- Paul wrote a blog on this called [*Weed Worries*](https://www.theturekclinic.com/blog/weed-worries/): there’s compelling evidence from epidemiology that chronic use of pot is associated with testis cancer
  - Paul doesn’t know if it’s causal but it worries him

Peter replies, “*Interesting, given that it otherwise seems kind of benign. I personally can’t stand the stuff, but I know so many people that use it so frequently that seem to have relatively few effects*.”

- Medical marijuana means safe
- Paul asked pot growers in the Emerald City up in Northern California who have the artisanal stuff that wins awards, “*Which is worse for driving, being stoned or being drunk?*”
  - Being drunk
  - They said, “*We tend to stop at stoplights and wait for them to turn when we’re stoned*.”
- There are probably far fewer people that die at the hands of a stoned driver than a drunk driver

**What do you think is the mechanism of action by which THC is having these negative fertility impacts?**

- Paul is not sure
- He thinks it might just be the chronic exposure

***There is some evidence that THC acts like LH and bind the receptor so it blocks LH from binding; you can get low testosterone, but it’s not that profound***

**What are the effects of nicotine, either synthetic or in the form of tobacco?**

- It’s a bad actor at high doses (from either one)
- It doesn’t last as long as THC

***It does have effects on sperm count and motility and fertility***

**⇒** Both THC and nicotine are probably oxidants and it’s oxidizing things

## Why Type 2 diabetes is a risk factor for male infertility [1:50:00]

- Earlier Paul mentioned diabetes as part of the patient history and physical he collects

**What is it about diabetes? Is it the high levels of glucose? Is it the microvascular damage? Is it the inflammation that typically travels in parallel with it?**

- Probably all of them
- We don’t know exactly

**⇒** Paul diagnoses diabetes in a lot of infertile men

*What’s the physical finding you’re seeing in the testes that tells you, like you know how an ophthalmologist will often make the diagnosis because they’re looking into the eye?*

- It’s usually their weight and low motility count
- Paul looks for a chronic exposure and then they have polyuria or polydipsia
  - Or something like that, where they’re drinking a lot and they’re peeing a lot, because the sugar is dragging it out
  - You check their [UA](https://en.wikipedia.org/wiki/Urinalysis) and it’s full of sugar
- Some of them have an [A1C](https://en.wikipedia.org/wiki/Glycated_hemoglobin) that’s a little pre-diabetic
- A lot of it is neurogenic too
  - They can develop an [ED](https://en.wikipedia.org/wiki/Erectile_dysfunction)
  - A third of type 2 diabetics have low testosterone, and that’s secondary, so you can bend them right back

***Common indications of type 2 diabetes: the sugars and then the low T and the low sperm count***

## How varicoceles—a common cause of male infertility—are diagnosed and treated  [1:51:15]

**What are some of the other modifiable things that you see?**

*The most common is a* [*varicocele*](https://en.wikipedia.org/wiki/Varicocele)

- You could develop varicose veins in your leg and need treatment, and this is the same thing in the scrotum, but it’s not related
- It happens, typically at puberty
- You’ll develop this, you won’t know it sometimes, unless it hurts

**⇒** Varicocele is a reflux of blood in the wrong direction

- So the testicle drains to the kidney, which is uphill and it wants to drain back down
  - The reason why it drains back down is because as a species, we stood up a half a million years ago, maybe three quarters of a million years ago
  - And when you’re an animal, your kidney and your testicle drains this way, there’s no gravity
  - But when you stand up, you’re now draining uphill
  - The system was never made for valves
- If you asked Paul what’s the reason our sperm counts are falling, he would say we stood up as a species
  - That’s probably not a good idea for male fertility, because that blood that’s supposed to be staying up there, comes back down to the testicle, pulls around it like a hot bath
  - It is warmer and usually the first sign is the left testicle usually is smaller than the right

**Diagnosis**: the physical exam will be a testicular discrepancy in size, that’s the first thing you see; and then you feel above it, and you feel a bag of worms

Peter asks, “*There are no valves in that vein?*”

- Correct
- The blood has to climb 30 cm
- That’s a pretty big distance to travel without a valve
- They think it does it at night, Paul doesn’t know
- The growth spurt in puberty blows the angle of the renal vein (there’s a right angle)
  - The right side has a natural valve off the vena cava, so it kind of has to go around 270 degrees, so you don’t reflux on the right

**Usual presentation**: left-sided lesion, and you can be perfectly fertile with it

- If you look at statistically:
  - 85% of men conceive naturally, without varicocele
  - 80% will conceive naturally in about a year [with varicocele]
  - The curves are very similar, clinically, maybe insignificant, but there is a difference and it’s statistical
- But if you multiply that by millions of people, it becomes important
- The best way to figure that out is a physical exam
  - Paul doesn’t order an ultrasound
  - If he can palpate it, then it’s clinical

**Treatment**: it’s an outpatient microsurgery; it takes an hour

Peter asks, “*Is it more involved than a vasectomy?*”

- Yes, and you’re doing microsurgery at the level where you don’t cut muscle, you want to recover quicker
- It’s an involved area with lots of veins
- Paul uses twilight sedation (that’s the most common)

**⇒** 40% of men have a varicocele

- And most men are fertile
- Again, you look at the semen analysis as a “poker hand” and you see count motility being down, nothing else going on, and you see a varicocele and it’s implicated

***The major modifiable factors that affect fertility are the varicocele and hormonal issues***

- Varicocele is maybe 40 [% of men]
- Hormononal
- Maybe 10-15 genetics (so they’re non-modifiable now)

## Genetic factors that affect fertility [1:54:00]

**What are some factors on the genetic side that affect male fertility?**

- The most common one for zero sperm is [Klinefelter](https://en.wikipedia.org/wiki/Klinefelter_syndrome)
  - This is an extra X chromosome
- The most common one for low sperm count is [Y chromosome deletions](https://en.wikipedia.org/wiki/Y_chromosome_microdeletion#Infertility)
  - This is an interesting area
  - There’s no phenotype; they look normal
  - Because it’s only on the long arm of the chromosome
    - Analogy: it’s only a couple of floors on the building
    - There’s regions that are missing
- [Reijo](https://www.mclaughlinresearch.org/research-scientists/faculty/renee-reijo-pera)[found](https://pubmed.ncbi.nlm.nih.gov/7670487/) at MIT, 20, 30 years ago now, that the Y chromosome is a hall of mirrors
  - In meiosis, every chromosome has a partner, except the Y in the X in a man
  - The Y plays with itself, it combines with itself
  - Instead of finding a partner, it has to do the dance too
  - And so it changes a lot, so it’s very adaptable
- The Y chromosome actually comes from the X, through evolution
  - So there’s a lot of X genes that are on the Y and the Y
- We thought the Y chromosome was sort of a wasteland, maybe hairy ears and tooth decay and things like that, but now it’s probably more important regions on the long arm of the Y
- The short arm of the Y is very important, it has a gene called [*SRY*](https://en.wikipedia.org/wiki/Sex-determining_region_Y_protein), which makes you male
  - The *SRY* is a male sex determining gene
  - If you have that gene, your phenotype will be male
  - If you don’t have that gene, you’re probably going to be female
  - It’s complicated now, but that’s sort of what it is
- But the long arm has these genes that control fertility
  - Typically Paul ordered [analysis] in men with a low sperm count or below 5 million
  - That would be a pretty common cause of a sperm count lower than 5 million
  - [the figure below shows a genetic map of the Y chromosome]

![](https://peterattiamd.com/wp-content/uploads/2025/05/f5-paulturek.png)

**Figure 5. Structure of the Y chromosome**. Image credit: [*Reproductive Biology and Endocrinology* 2018](https://rbej.biomedcentral.com/articles/10.1186/s12958-018-0330-5)

- Paul published a [study](https://pubmed.ncbi.nlm.nih.gov/11248633/) that if you have a Y chromosome deletion and you have a varicocele (and they both cause low sperm counts) and you fix the varicocele, you’re not going to improve
  - Because it’s non-modifiable in all ways, it’s who you are
- But if you didn’t have the Y chromosome deletion and you fix the varicocele, you’ll expect a good response
  - ⅔ will improve, 1/3 or more will conceive naturally

***So you could take guys with low sperm counts and you can fix them or not, but the driver [of infertility] is genetics***

- The phenotype in offspring is simply inherited as a Y chromosome deletion
- Paul just had a couple from Texas and he had a Y chromosome deletion
  - He conceived with help of a technology, with a low sperm count
- Sons have it, they have no sperm
- So you can inherit the deletion, but it might increase
  - You’re going to get what your dad had or it might be worse, because mutations tend to get larger
- You would never know until you try to conceive because everything else is normal

## The impact of lifestyle and environmental exposures on fertility [1:56:30]

- For environmental/lifestyle things that affect fertility, obesity is the big one

**Do you think that that’s mostly propagated through the endocrine system then?**

- Yeah, that’s a big one, in terms of the percent of sperm with the lifestyle issues
- Lousy diet is probably something

***Obesity and diet, lifestyle, recreational drugs impact fertility***

**Toxic exposures at work**

- Any smelly solvents are really worrisome
  - Airport fuels, airline stuff, machine shop oils, anything, benzene, derivatives, used to be pesticides and stuff like that
  - But they’re pretty well controlled
- Environmental exposures are kind of an unknown

**Paul thinks viruses have a role**

- He saw that Peter recently [wrote](https://peterattiamd.com/hpv-and-male-infertility/) about HPV, and he’s been thinking about that for years
- With lifestyle issues and stuff like that, you can pretty much sort it out
- But there are men who we’re like, what is going on here?
  - He’s a perfectly healthy guy
  - When there’s obesity it’s always the elephant in the room, but everyone is so healthy
  - Paul pokes around places where no one else goes, because he has to explain it and there’s nowhere to go
- Paul [wrote](https://www.theturekclinic.com/blog/the-skinny-on-stis-and-male-infertility/) about STD’s: [HPV](https://en.wikipedia.org/wiki/Human_papillomavirus_infection) is the most common ‒ it’s hard to know if that’s the link
  - [Herpes](https://en.wikipedia.org/wiki/Herpes_simplex_virus_2) is very common
  - We know more about [chlamydia](https://en.wikipedia.org/wiki/Chlamydia) and [gonorrhea](https://en.wikipedia.org/wiki/Gonorrhea) and [syphilis](https://en.wikipedia.org/wiki/Syphilis), and they’re pretty obvious
  - Some like [trichomonas](https://en.wikipedia.org/wiki/Trichomonas) are pretty subtle
- 20 years ago, when Paul was a professor at UCSF, a guy sent him a picture of an electron photograph of a sperm with a hexagonal herpes virus in it and asked, “*Is this virus in a sperm?*”
  - Yeah, it looked like it
  - He didn’t know what was causing it
- Normally when you see infections (viral or bacterial) as a cause of semen analysis, you’ll see pus cells
  - So you’ll see what’s called [pyospermia or leukocytospermia](https://pmc.ncbi.nlm.nih.gov/articles/PMC8244362/), the round cells
  - This will show up in higher numbers in the semen analysis
  - They tend to be destructive and they tend to lower motility, so you tend to see a certain look to the semen analysis volume, normal count motility is really low
  - A lot of the sperm are dead, ’cause they’ve been wiped out by these cytokines and all the white cells
- Maybe you’ll find the pathogen somewhere or may not
- But culturing mycoplasma, CMV, all these viruses
- [Joe Derisi](https://profiles.ucsf.edu/joe.derisi) at UCSF analyzed semen from Paul’s patient in the 2000s
  - He had 2,000 mammalian viruses on his [chip](https://pubmed.ncbi.nlm.nih.gov/21559002/)
  - They tested sperm from fertile guys and infertile guys
  - 99% of the infertiles were positive for something, and 98% of the normals were positive for something

***The presence of viruses in sperm is ubiquitous, and you can’t really do much with that***

> “*I do agree with your assessment, that the pathologic phenotypes, the worst ones are probably doing something. The question is, how do we measure it?*”‒ Paul Turek

- Semen analysis is a blunt instrument
  - It varies a lot
  - It’s tough to do
- Would you do genotyping on sperm? Probably not
- When you look at HPV, it’s probably one of those things that might be in the ejaculate
  - It might be coming from another fluid source and not in the sperm itself
  - So its effect would be post ejaculation, which could still have a fertility effect, but it won’t be probably as deep

**What if a guy has prostatitis and the prosthetic fluid has pus in it?**

- That could sabotage the whole thing
- The problem with the male system is it’s all through the same tube, so urine comes through that tube and semen comes through that tube
- So you have to look for infections in the urinary tract in anything like that when you’re doing fertility, because pus cells kill whatever they see
- If your urine’s infected, that’s a big deal

## The evidence (or lack thereof) behind stem cell and PRP therapies for male infertility, and how lifestyle and non-invasive interventions often lead to successful conception [2:00:30]

**Have you done work with intratesticular PRP, and stem cells?**

- Just stem cells, but not [PRP](https://en.wikipedia.org/wiki/Platelet-rich_plasma)

Paul adds, “*Not a big fan, as a trained stem cell biologist and someone trying to make sperm from skin and working with some of the best stem cell scientists in the world, I have a lot of respect for them. But it’s not that simple.*”

- There’s 560 offshore stem cell companies in the world that will take your money and do things like stick PRP in there, they’ll stick bone marrow aspirates, fat in your testicle
- Paul’s experience has not been favorable, some of the toughest cases in the world
  - They come to Paul after that and Paul uses techniques and doesn’t find anything
- The trials aren’t really real
  - Come here, we’re going to do this, and then we’re going to do a microdissection on your testicle
  - But they didn’t have one beforehand, so the chance of finding it even without that, is X, and they’re finding X
  - So it’s just not well done
- Paul has his patients investigate all that
- Then he will call them and ask, “*Hi, I’m just wondering about, do you have any papers or what’s the science behind it?*”
- They usually hang up

***So far, the claims around stem cells are unfounded***

- Peter’s experience has been very similar with a few friends and patients who have wanted him to talk with their stem cell docs
  - He accepts the fact that they’re not going to have remarkable peer-reviewed data, but it is amazing, at how few individuals can provide even one cell layer of scientific reasoning
- It’s a topic Peter would like to explore more deeply on the podcast
- His guess is there are some indications for where it makes sense
  - He would like to figure it out with people wasting so much money

**For every 100 guys that walk into your office, who are struggling with infertility, what percentage of them will be able to conceive?**

- Assuming they are able to fully comply with the prescriptions that you provide, be it lifestyle or pharmaceutical, for example, hormone modulation, etc.
- Let’s exclude the 40% varicoceles, because you’re going to fix those guys and they’re fine
- So 100 people who don’t have a varicocele, who don’t have a genetic condition
  - Presumably they showed up with some iatrogenic reason for infertility

*How many of those guys are going to be able to conceive without resorting to IVF?*

***Most men will be able to conceive without IVF, and that is the goal of Paul’s practice***

- But the caveat is, you got to tell me about the woman
- The only data he can provide is a [paper](https://pubmed.ncbi.nlm.nih.gov/15385442/) where he saw men for their infertility evaluation, got it done, and he thought they were fine
  - They had varicoceles and stuff, but their semen analysis was normal and my investigation of their risk lifestyle, everything was good
  - They were fine/cleared, and no one’s ever said that before
  - They went home and they said, “*Turek, couldn’t figure out what was wrong with us*.”
  - And Paul said, “*That’s not what I said, I don’t do women*.”
  - Most people would say, I’m not sure why you’re not conceiving
  - Paul said, “*I’m pretty sure you’re not the problem*.” Didn’t get interpreted like that, that got him a little angry
- Paul did a [study](https://pubmed.ncbi.nlm.nih.gov/15385442/) with USC of the men he cleared and he called them up a year later
  - 65% had conceived naturally [shown in the figure below]
  - Another 15 to 20% conceived with IOI or IVF
  - These women were 35 years old, year and a half infertility, they weren’t going to wait around
  - Most conceptions occurred within 6 months

Paul didn’t do anything *for them, he didn’t fix their varicoceles, he didn’t give them medication “*You’re fine.”

![](https://peterattiamd.com/wp-content/uploads/2025/05/f6-paulturek.png)

**Figure 6. Mode of conception after a “cleared” male factor evaluation**. Image credit: [*Translational Andrology and Urology* 2021](https://pubmed.ncbi.nlm.nih.gov/33718064/)

- He published it as a lifestyle study
  - The idea was they probably made changes, they probably took a nutritional supplement, they probably timed their sex better, they probably got out of hot tubs and all that stuff
  - Paul has a list of what they did
  - A figure in that paper [reproduced above] reported a 65% natural pregnancy rate ‒  that is higher than anything he can offer as a treatment that we have published on
    - So if you fix their varicocele or, you rarely get a 65% natural conception rate
- This paper also included a table of all the published conception rates for the technologies that work [reproduced below]
  - Paul is saying, this is even better

![](https://peterattiamd.com/wp-content/uploads/2025/05/f7-paulturek.png)

**Figure 7. Male fertility treatments and associated pregnancy rates**. Image credit: [*Translational Andrology and Urology* 2021](https://pubmed.ncbi.nlm.nih.gov/33718064/)

## Considerations for sperm banking, and how paternal age impacts fertility planning and offspring health [2:05:00]

**What advice do you give a guy who comes to your practice and says he wants to bank/freeze his sperm?**

- Presumably he’ll get a lot of that if a guy is undergoing therapy for cancer or something like that

*Is there anything a guy needs to know*?

*And would you recommend a guy do that if he’s 40, doesn’t have a partner but says, “Look, I want to have kids,” and isn’t there something to the idea that my sperm are better today than they will be in a decade?*

- Paternal age and fertility is a huge issue
- Paul doesn’t place value judgements; he says, “*Good idea.*”

Disclosure: Paul is on the [board of Legacy](https://www.givelegacy.com/about/)

- He loves that they’re mission-driven and they’re going for military and exposed patients

***Paul thinks sperm banking is the lowest hanging fruit in the field for cancer survivors and things***

Disclosure: Paul started a nonprofit called [Banking on the Future](https://www.theturekclinic.com/blog/the-littlest-things-can-mean-the-most-sperm-banking-cancer-banking-on-the-future/#:~:text=non%2Dprofit%20program%20several%20years%20ago%20called%20Banking%20on%20the%20Future)

- To help 16-year-olds to 21-year-olds with cancer
  - They’ll pay for it [sperm banking] for 5 years

*Would you advise any male that hasn’t reproduced who might want to, who’s undergoing any chemotherapy for any cancer to play it safe and bank their sperm?*

- For cancer, yes
- Should anyone do it for any reason? Probably not
  - But again, Paul doesn’t pass judgement
  - If they’re worried about something, then they should

**What paternal age do you worry about?**

- National guidelines for sperm donation consider 40 as older paternal age
  - 50 for sure
- If you look at risks to offspring, miscarriages, stillborns, birth defects, things immediately related to conception, prematurity, those go up with paternal age
- Then you look at birth defects when they’re born, those go up 1-2-fold
- The worrisome ones, are the single gene defects and the epigenetics like psychiatric morbidity
  - Autism, schizophrenia, dyslexia, bipolar disorder, potentially Alzheimer’s in offspring and they’re not detectable young
- Paul has [published](https://pubmed.ncbi.nlm.nih.gov/29524155/) on it
  - He was actually having my second child at 50 when he was writing this thing with [Alex Yatsenko](https://www.obgyn.pitt.edu/people/alexander-n-yatsenko-md-phd) from University of Pittsburgh

> “*I think it’s a hockey stick curve for risk to offspring*.”‒ Paul Turek

*Do you think the inflection is 40 or 50?*

- Paul thinks it’s more like 60
- There’s a slow linear increase in risk to offspring from 25 to 50 or 60, and then there’s an inflection and then there’s the blade at the stick
- Paul thinks that’s logarithmic, same curve as women with chromosomal [abnormalities], but they’re shifted
  - For women, it’s a shorter curve: age 38-40 is the point where things really ramp up with chromosomes
- In men it’s not chromosomal
- If you take the curves together, they’re different spans, same shape
- Paul thinks the female curve is on top of the male curve
- This is not the same relative risk, so women, you go from 25 to 40, your chance of a miscarriage (it’s chromosomal) goes up quite significantly after that
- And the consequence of women’s issues with offspring-related health, is basically miscarriage
  - In many ways, it’s almost easier to detect
  - They’ve been doing it for years
  - Now it’s prevented with preimplantation genetic testing

**⇒** Men are different, you can’t detect these things, there’s single gene mutations

- In men, the machinery is constantly working, it’s getting old, the quality control of the process goes down and little gene mutations get in there that are always being spun off in the heat of the engine
  - So the machinery’s not doing a good job. So they’re getting through and they’re not going to be lethal, they’re going to be deleterious
- [Autism](https://en.wikipedia.org/wiki/Autism) is a classic one ‒ looks like paternal age is the biggest risk factor for
  - That worries Paul a lot

Paul explains, “*The facts are that human evolution is entirely driven by sperm*.”

- 50 mutations a generation get spit out ([*Nature* paper](https://pubmed.ncbi.nlm.nih.gov/39379474/))
- There’s always mutations occurring in 14-year-old fathers, but it goes way up with 60-year-old fathers

**⇒** So the rate of mutations goes way up with age, but it averages 50 over a human reproductive life

- Half of the mutations that we are throwing off as a species, are not ears or hands or feet or height, about half are neurodevelopmental
  - When you think about what we’re seeing, the Martians from the ‘50s in the movies with big heads?
  - That’s kind of where we’re headed
  - It’s autism, dyslexia, bipolar disorder, these are neurodevelopmental or neurodegenerative issues
  - Why is that? That’s where we’re being asked to evolve
- Look at the last 30 years
- One of the biggest investors in Salesforce said to Paul, “*I realized I was dyslexic when my son was born… but you know what? It helped me be the man I am to realize that Salesforce is going to fly… It let me focus*.”

**Paul’s thoughts on autism**

- Autism is one of the diseases where you ignore a lot of input and you find the gift and it’s amazing
- If you go down the rabbit hole of what they’re good at, it’s like their whole brain trust is there
- So is that a disease or is that where we’re headed?
- Peter thinks it exists on a spectrum
- Use ASD as an example, it has 3 categories now in the DSM-V, and the mildest version probably comes with more superpowers than limitations (or maybe equal amounts)
- But the more severe it gets, it’s pretty debiliting

Paul adds, “*Maybe it’s not disease, maybe it’s where we’re headed, maybe it’s the future. Maybe the non-sequiturs that come out of those brains. Look at who’s changing the world right now, at least in Silicon Valley*.”

- For class I not class III

**Back to sperm banking, what is the probability of thawing correctly?**

- If a guy is 40 and he freezes and banks his sperm, assuming he was good to go
- Freezing sperm is about a 200-year-old process, regularly used for about 75
  - Paul forgot who the Italian scientist was who froze sperm in snow and then thawed it, and it was alive (and moving) a couple of hundred years later after [Leeuwenhoek](https://en.wikipedia.org/wiki/Antonie_van_Leeuwenhoek) came up with the microscope
- Egg freezing and thawing is very new
- Everyone is thinking about sperm now because eggs are being frozen left and right

***This is much older technology and the [sperm] cell is much heartier than an egg, so it does a lot better typically***

- It’s the freezing process that kills sperm, be it from icicles on the inside
- And then while it’s frozen, there’s usually no issue
- There’s another problem when you thaw it, the  rapid temperature shifts is where the kill rate comes from

***In a good sample, half of it should survive***

**How much sperm would you tell a guy to bank?**

- It depends on what technology you’re going to use
- If your sperm count is normal, 3 ejaculates is 1 kid’s worth of sperm with insemination technology
  - Where you would thaw it and then turkey baster it

Paul jokes, “*10 ejaculates will give you most of China with IVF.*”

- Meaning IUI or something like that
- There are 3 levels of technology: sex (no technology), [IVF](https://en.wikipedia.org/wiki/In_vitro_fertilisation#) (high-tech), and [IUI](https://en.wikipedia.org/wiki/Artificial_insemination#Intrauterine_insemination) (is in the middle)

***3 ejaculates per kid would be more than enough if you’re normal***

- Cancer survivors, half of those will not be normal, and they’re looking at IVF
  - So they don’t need that many
  - But 3 is a good number, it’s an insurance policy

**Paul started his podcast last year,** [***Talk With Turek***](https://www.theturekclinic.com/talk-with-turek-podcast/)

- It’s Paul and his associate Rob Clyde, who’s a director in Hollywood

Paul explains, “We’re *going to be the anti-verdain of men’s health. We’re going to just take on the topics, testosterone, et cetera, penis myths, and just talk about stuff that everyone is asking questions about, but no one’s talking about. And, like you, data-driven answers.*”

**⇒** Paul has a [clinic](https://www.theturekclinic.com/) that he runs up and down the coast of California

**Advice for men**

> “*I think we’ve given folks a roadmap for their local urologist as well, if they’re getting the work up*.”‒ Peter Attia

- Basically, it sounds like if you’re being worked up for fertility with your urologist and they’re not going through the steps that we’ve described, maybe you should find somebody else
- That’s the first step

## Semen quality as a biomarker: linking male fertility, longevity, and preventative health through Medicine 3.0 and epigenetics [2:14:45]

**There’s a lot going on now that the biomarker concept relates a lot to Peter’s views on Medicine 3.0**

- A [paper](https://pubmed.ncbi.nlm.nih.gov/40037905/) came out two days ago, looking at longevity based on the semen analysis
  - Danish in the Rigshospitalet in Copenhagen looked at 74,000 men over 50 years and found that those guys with, say, normal semen quality, live 3 years longer (all causes) than men with low sperm counts when they were younger
  - This was a single-payer system, so they have all the data on it
  - It’s very much a landmark study
- Paul shares what excites him about the field, “*I would say, as the author of the biomarker concept early in my career, I would say I’m really happy that we’re scaring couples to realize that their fertility is a measure of their health*.”

- Now we have our food in the door
- If we can get a sperm count and get men in the office, we can actually tell them a little bit about their trajectory
  - And that’s becoming more and more every day
- We’ve never had a chance to do preventative medicine with young men
- So it’s a men’s health play in a big way, because their partners are bringing them in
  - But who cares? They’re in the office
- There’s metabolic stuff, you can pick up diabetes
  - This is the work of Paul’s nurse practitioner, [Molly Jessup](https://www.theturekclinic.com/meet-molly/)

***We have an opportunity here we’ve never had ever: to get men at younger ages***

- Paul was a professor at UCSF for 15 years, an endowed chair
- He left and went to [Yo San University of Traditional Chinese Medicine](https://yosan.edu/)
  - He lectures there now
- He likes it because he thinks western medicine is too reactive

> “*We’re always trying to get men out of trouble or get patients out of trouble, but we’re not thinking about getting them from unhealthy to healthy, which is the preventative aspect*.”‒ Paul Turek

**We’re just not very good at prevention**

- In general surgery, a guy is going to do something bad, and you get him back
- But you’ve got to think about the next step
- Like kidney stones, great urologists treat them all day
  - It’s fun, it’s endoscopic, it’s lasers, it’s shock waves
- But what are we doing about that stone?
- How come we’re not preventing these more?
  - It’s not on the radar

*Yo San University of traditional Chinese medicine is a fabulous place, and it’s all holistic*

- Paul sees patients who get referred by acupuncturists, and they come in, their diet’s under control, their stress is under control, they’re doing acupuncture, they’re sorted out
- What does Paul find? [Varicoceles](https://en.wikipedia.org/wiki/Varicocele)
  - Because they don’t find those
  - But the phenotype is totally different from the western referral
- Paul loves that, because that’s medicine 3.0, which they’re doing
- They’ve been doing it for 4,000 years

**The impact of epigenetics on fertility**

- It’s interesting how we don’t give a lot of street cred to it, but in Paul’s view, much of we don’t understand about fertility (certainly in men, possibly women) is epigenetic
- [Epigenetics](https://en.wikipedia.org/wiki/Epigenetics) are marks on the DNA, not DNA mutations
  - 50 DNA mutations a generation doesn’t explain it
  - There’s other stuff going on

**⇒** Epigenetics is all lifestyle and diet driven, it’s all lifestyle and diet driven. It’s everything in [Peter’s book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=sr_1_2?crid=2ZUVJGO5T6XFC&dib=eyJ2IjoiMSJ9.P2oZuRwhOizmZb9mpYCQtJ97Ok0_O7UqFybe23bzogUewKTnGy_-gZqfGAxfJlCIOWJi_fuOU92iLYcFpqh9R8ZRhXU2H-KBeWrnyQedps4sQ3WvkBxbBXEYV2D48K9wRyLsTaC8FB1S668ghAVjKztbWi7rGmr_u3naZb1AWxeNVoF9wz-MVCU0XeR-gKtFAnVol53XnHzKE0A4cw0n6l50MSrPDmJB0eXjJ1c4clr0FltxOKQ0N79tgrE-B-OPCw5b1GslT-_x6fPSzUw4r4FFYq4YKuyhbdgabXihHow.kOn3zwzVM4RJ_L6YxwvRYTsoZJ75DpVvOlZdqE3876s&dib_tag=se&keywords=outlive&qid=1744979353&sprefix=outliv%2Caps%2C91&sr=8-2)

---

## Selected Links / Related Material

**The Turek Clinic**: [The Turek Clinic](https://www.theturekclinic.com/) (2025) | [1:30, 2:14:15]

**Paul’s podcast**: [Talk With Turek](https://www.theturekclinic.com/talk-with-turek-podcast/) | Host Paul Turek (2025) | [1:30, 2:13:45]

**Paul’s blog**: [Dr. Turek’s Blog](https://www.theturekclinic.com/dr-tureks-blog/) | TheTurekClinic.com (2025) | [2:13:45]

**Arex Life Sciences**: [Arex Life Sciences](https://arexlifesciences.com/) (2025) | [6:45]

**Characterization of spermatogonial stem cells**: [Isolation and characterization of pluripotent human spermatogonial stem cell-derived cells](https://pubmed.ncbi.nlm.nih.gov/18927477/) | *Stem Cells* (N Kossack et al, 2009) | [14:00]

**Textbook on reproductive physiology**: [The Netter Collection of Medical Illustrations: Reproductive System](https://www.mea.elsevierhealth.com/the-netter-collection-of-medical-illustrations-reproductive-system-volume-1-9780323880831.html) by P Turek and R Smith (2024) | [22:15]

**Receptor on sperm that detects follicular fluid**: [Natriuretic peptide type C induces sperm attraction for fertilization in mouse](https://pubmed.ncbi.nlm.nih.gov/28054671/) | *Scientific Reports*(N Kong et al. 2017) | [25:00]

**Diaries of sex and pregnancy**: [Timing of sexual intercourse in relation to ovulation. Effects on the probability of conception, survival of the pregnancy, and sex of the baby](https://pubmed.ncbi.nlm.nih.gov/7477165/) | *NEJM*(A Wilcox, C Weinberg, D Baird 1995) | [28:30]

**1960s study of spermatogenesis**: [Spermatogenesis in man: an estimate of its duration](https://pubmed.ncbi.nlm.nih.gov/13953583/) | *Science* (C Heller, Y Clermont 1963) | [31:45]

**Study of spermatogenesis on men who drank deuterated water**: [A stable isotope-mass spectrometric method for measuring human spermatogenesis kinetics in vivo](https://pubmed.ncbi.nlm.nih.gov/16406920/) | *Journal of Urology* (L Misell et al. 2006) | [32:00]

**Paul’s study of fixing varicocele**: [Can varicocelectomy significantly change the way couples use assisted reproductive technologies?](https://pubmed.ncbi.nlm.nih.gov/11912402/) | *Journal of Urology* (S Cayan et al. 2002) | [33:15]

**Infection with Zika virus causes male infertility (in mice)**: [Zika virus infection damages the testes in mice](https://pubmed.ncbi.nlm.nih.gov/27798603/) | *Nature* (J Govero et al. 2016) | [43:30]

**Study of COVID infecting the testicle out of China**: [Does COVID-19 affect sperm quality in males? the answer may be yes, but only temporarily](https://pubmed.ncbi.nlm.nih.gov/38263068/) | *Virology Journal* (Q Zhang et al. 2024) | [44:15]

**Review on the impact of COVID-19 on fertility**: [COVID-19 and human reproduction: A pandemic that packs a serious punch](https://pubmed.ncbi.nlm.nih.gov/33719829/) | *Systems Biology in Reproductive Medicine* (G Anifandis et al. 2021)

**Autopsy of men who died from COVID and detection of virus in the testicle of 1 man**: [Case series – COVID-19 is unlikely to affect male fertility: Results of histopathological and reverse transcriptase polymerase chain reaction analysis](https://pubmed.ncbi.nlm.nih.gov/35704934/) | *Canadian Urological Association Journal* (J Masterson et al. 2022) | [44:30]

**Kruger morphology and IVF outcomes**: [Sperm morphologic features as a prognostic factor in in vitro fertilization](https://pubmed.ncbi.nlm.nih.gov/2946611/) | *Fertility and Sterility* (T Kruger et al 1986) | [49:00]

**Episode of** ***The Drive*** **on microplastics**: [#332 – AMA #67: Microplastics, PFAS, and phthalates: understanding health risks and a framework for minimizing exposure and mitigating risk](https://peterattiamd.com/ama67/) (January 20, 2025) | [1:00:15]

**Consumption of estrogenized beef by pregnant women linked to lower sperm counts in sons**: [Semen quality of fertile US males in relation to their mothers’ beef consumption during pregnancy](https://pubmed.ncbi.nlm.nih.gov/17392290/) | *Human Reproduction* (S Swan et al. 2007) | [1:02:00]

**Paul’s review on avoiding medications toxic to sperm**: [Avoiding toxins including spermatotoxic medications](https://pubmed.ncbi.nlm.nih.gov/23775384/) | *Seminars in Reproductive Medicine* (G Stearns, P Turek 2013)

**Paul’s blog on exercise and fertility**: [Can You Be Too Fit to Be Fertile?](https://www.theturekclinic.com/blog/can-you-be-too-fit-to-be-fertile-male-infertility-exercise/) | Dr. Turek’s Blog (2019) | [1:05:15]

**Effect of extreme exercise on fertility**: [The Impact of Intense Exercise on Semen Quality](https://pubmed.ncbi.nlm.nih.gov/27645515/) | *American Journal of Men’s Health* (P. Jozkow, M Rossato 2017) | [1:05:15, 1:41:45]

**Metabolism of oral testosterone**: [Reexamination of Pharmacokinetics of Oral Testosterone Undecanoate in Hypogonadal Men With a New Self-Emulsifying Formulation](https://pubmed.ncbi.nlm.nih.gov/21474786/) | *Journal of Andrology* (A Yin et al. 2012) | [1:09:45]

**Blood thickening in men on testosterone therapy**: [Secondary Polycythemia in Men Receiving Testosterone Therapy Increases Risk of Major Adverse Cardiovascular Events and Venous Thromboembolism in the First Year of Therapy](https://pubmed.ncbi.nlm.nih.gov/35050717/) | *Journal of Urology* (J Ory et al. 2022) | [1:13:45]

**ADAM questionnaire**: [ADAM screening questionnaire](https://themenshealthclinic.co.uk/adam-questionnaire/) | The Men’s Health Clinic (2025) | [1:19:15]

**Paul’s blog about getting off testosterone**: [Getting Off the Juice](https://www.theturekclinic.com/blog/juice-steroids-anabolics-azoospermia-sterility/) | Dr. Turek’s Blog (2012)| [1:27:45]

**Case study of a guy who took testosterone for 25 years**: [The reversibility of anabolic steroid-induced azoospermia](https://pubmed.ncbi.nlm.nih.gov/7714991/) | *Journal of Urology* (P Turek et al. 1995) | [1:29:00]

**hCG preserves fertility in men taking testosterone**: [Low-dose human chorionic gonadotropin maintains intratesticular testosterone in normal men with testosterone-induced gonadotropin suppression](https://pubmed.ncbi.nlm.nih.gov/15713727/) | *The Journal of Clinical Endocrinology and Metabolism* (A Coviello et al. 2005) | [1:33:30]

**Paul’s study on the effects of heat on sperm motility**: [Wet heat exposure: a potentially reversible cause of low semen quality in infertile men](https://pubmed.ncbi.nlm.nih.gov/17335598/) | *International Brazilian Journal of Urology* (S Shefi et al. 2007) | [1:38:00]

**Paul’s blog on the effect of hot tubs on sperm**: [Toxic Tubbing: Hot Tubs‘ Effects on Male Fertility](https://www.theturekclinic.com/blog/hot-tubs-male-infertility-heat-azoospermia/) | Dr. Turek’s Blog (2011)

**Study of sperm counts in Spanish competitive cyclists**: [Reproductive function in male endurance athletes: sperm analysis and hormonal profile](https://pubmed.ncbi.nlm.nih.gov/9018515/) | *Journal of Applied Physiology* (A Lucia et al. 1985) | [1:43:00]

**Paul’s blog on the effects of cycling on sperm**: [Cycling Toward Childlessness](https://www.theturekclinic.com/blog/cycling-childlessness-sperm-counts-male-infertility/)? | Dr. Paul Turek’s Blog (2014) | [1:43:45]

**Fertility of British who cycled to work**: [An Observational Study of Erectile Dysfunction, Infertility, and Prostate Cancer in Regular Cyclists: Cycling for Health UK Study](https://www.liebertpub.com/doi/abs/10.1089/jomh.2014.0012?journalCode=jomh) | *Journal of Men’s Health* (M Hollingworth, A Harper,  M Hamer 2014) | [1:43:45]

**NIOSH findings on bicycle seats and men’s sexual health**: [NIOSH Research Demonstrates the Effectiveness of No-Nose Bicycle Seats in Reducing Groin Pressure and Improving Sexual Health](https://www.cdc.gov/niosh/docs/2010-163/default.html) | NIOSH (2010) | [1:45:00]

**Paul’s blog on marijuana**: [Weed Worries](https://www.theturekclinic.com/blog/weed-worries/) | Dr. Paul Turek’s Blog (2010) | [1:48:00]

**Reijo Pera’s study of the Y chromosome**: [Diverse spermatogenic defects in humans caused by Y chromosome deletions encompassing a novel RNA-binding protein gene](https://pubmed.ncbi.nlm.nih.gov/7670487/) | *Nature Genetics* (R Reijo et al. 1995) | [1:54:45]

**Y chromosome deletions drives infertility more than varicocele**: [Response to varicocelectomy in oligospermic men with and without defined genetic infertility](https://pubmed.ncbi.nlm.nih.gov/11248633/) | *Urology* (S Cayan et al. 2001)  [1:55:30]

**Paul’s review on the genetics of male infertility**: [The genetics of male infertility](https://pubmed.ncbi.nlm.nih.gov/19247914/) | *Seminars in Reproductive Medicine* (T Walsh, R Reijo Pera, P Turek 2009)

**Peter’s newsletter on HPV and invertility**: [Concerning links between human papillomavirus (HPV) infection and male infertility](https://peterattiamd.com/hpv-and-male-infertility/) | PeterAttiaMD.com (K Birkenbach, P Attia 2025) | [1:57:15]

**Paul’s blog on STI’s**: [The Skinny on STIs and Male Infertility](https://www.theturekclinic.com/blog/the-skinny-on-stis-and-male-infertility/) | Dr. Turek’s blog (2019) | [1:57:45]

**Conception rates among men “cleared” of infertility**: [A study of pregnancy rates in “cleared” male factor couples](https://pubmed.ncbi.nlm.nih.gov/33718064/) | *Translational Andrology and Urology* (E Godart et al. 2021) | [2:03:30]

**Paul’s review of male fertility treatment**: [Practical approaches to the diagnosis and management of male infertility](https://pubmed.ncbi.nlm.nih.gov/16474834/) | *Nature Clinical Practices Urology* (P Turek 2005)

**Impact of paternal age**: [Reproductive genetics and the aging male](https://pubmed.ncbi.nlm.nih.gov/29524155/) | *Journal of Assisted Reproduction and Genetics* (A Yatsenko, P Turek 2018) | [2:07:15]

**Semen analysis and longevity**: [Semen quality and lifespan: a study of 78 284 men followed for up to 50 years](https://pubmed.ncbi.nlm.nih.gov/40037905/) | *Human Reproduction* (L Priskorn et al. 2025) | [2:14:45]

**Yo San University of Traditional Chinese Medicine**: [Yo San University of Traditional Chinese Medicine](https://yosan.edu/) (2025) | [2:16:15]

---

## People Mentioned

- [Harvey Cushing](https://en.wikipedia.org/wiki/Harvey_Cushing#) (1869-1939, American neurosurgeon, pathologist, and writer)  [23:00]
- [Keith Jarvi](https://www.sinaihealth.ca/physicians/keith-jarvi) (Professor of Surgery, Division of Urology, Department of Surgery at the University of Toronto where he established the fertility program in Urology) [34:00]
- [Thinus Kruger](https://scholargps.com/scholars/95391916842199/thinus-f-kruger) (Professor of Obstetrics and Gynaecology at Stellenbosch University; expert on sperm) [49:00]
- [Shanna Swan](https://www.shannaswan.com/about) (Environmental and reproductive epidemiologist, Professor of Environmental Medicine and Public Health at the Icahn School of Medicine at Mount Sinai) [1:02:00]
- [Ranjith Ramasamy](https://en.wikipedia.org/wiki/Ranjith_Ramasamy) (Urologist and former Director of the Reproductive Urology Fellowship program at the University of Miami Miller School of Medicine) [1:13:45]
- [John Amor](https://gim.uw.edu/people/faculty/john-amory)y (Professor of Medicine, Director of the Institute for Translational Health Sciences, and Associate Dean of Translational Science at UW Medicine) [1:33:30]
- [Steven Schrader](https://www.linkedin.com/in/steven-schrader-34456812/) (Research Biologist at NIOSH) [1:45:00]
- [Renee Reijo Pera](https://www.mclaughlinresearch.org/research-scientists/faculty/renee-reijo-pera) (President of the McLaughlin Research Institute for Biomedical Sciences and Professor at the Touro College of Osteopathic Medicine, Montana)  [1:54:45]
- [Joe Derisi](https://profiles.ucsf.edu/joe.derisi) (Professor of Biochemistry and Biophysics and Howard Hughes Investigator at UCSF) [1:59:00]
- [Alexander N Yatsenko](https://www.obgyn.pitt.edu/people/alexander-n-yatsenko-md-phd) (Associate Professor of Obstetrics, Gynecology & Reproductive Sciences and Director of the Pittsburgh Clinical Genomic Laboratory at the University of Pittsburgh) [2:07:15]
- [Molly Jessup](https://www.theturekclinic.com/meet-molly/) (Nurse Practitioner specializing in male fertility and reproductive health at the Turek Clinic) [2:15:45]

---

![](https://peterattiamd.com/wp-content/uploads/2025/05/bio-paulturek-600x600.png)

##### Paul Turek, M.D.

Paul Turek earned his undergraduate degree from Yale and medical degree from Stanford. He completed his residency in urology at the Hospital of the University of Pennsylvania. He also did a fellowship in male reproductive medicine and microsurgery at Baylor. He is a board-certified urologist and former Full Professor and Endowed Chair in Urology at the University of California San Francisco. As the inventor of [sperm mapping](https://www.theturekclinic.com/sperm-mapping/#:~:text=An%20Overview%20of%20Sperm%20Mapping%E2%84%A2), he is recognized as one of the world’s top male reproductive health and fertility physicians and surgeons. His research focuses on low sperm count, poor sperm motility, and hormonal imbalances related to infertility. He has published hundreds of papers in leading medical journals. Dr. Turek is the founder and Medical Director of [The Turek Clinic](https://www.theturekclinic.com/), which has offices in everly Hills and San Francisco. He is also the Co-Founder and Chief Scientist of [Alpha Sperm](https://alphasperm.com/), a company that developed the first prenatal vitamin and micronutrition supplement for men. [[AlphaSperm](https://alphasperm.com/pages/paul-turek)]

Blog: [Dr. Turek’s Blog](https://www.theturekclinic.com/dr-tureks-blog/)

Instagram: [@drpaulturek](https://www.instagram.com/drpaulturek/?hl=en)

Podcast: [Talk with Turek](https://www.theturekclinic.com/talk-with-turek-podcast/)