# #241 ‒ Living intentionally, valuing time, prioritizing relationships, and more keys to a rich life | Ric Elias (Part 2)

**Source:** [https://peterattiamd.com/ricelias2/](https://peterattiamd.com/ricelias2/)

---

Ric Elias, the founder of Red Ventures and [previous guest](https://peterattiamd.com/ricelias) on The Drive, returns to discuss his evolving insights on time, relationships, parenting, and how to make the most of the gift of life. In this episode, he reflects on the changes he’s made since his near-death experience during the crash landing of Flight 1549 on the Hudson River in 2009. Ric reveals many keys to living a rich life, such as aiming for continuous growth, approaching life with true intentionality, and valuing our time in accordance with that. He talks about relationships as the core of a rich life and provides insights on parenting and how we should think about our relationship with our kids as they grow older. Finally, Ric discusses the importance of staying true to yourself, the value in struggle, and finding meaning in helping others.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/ricelias2/the_Drive_public.png)

Play

#241 ‒ Living intentionally, valuing time, prioritizing relationships, and more keys to a rich life | Ric Elias (Part 2)

#241 ‒ Living intentionally, valuing time, prioritizing relationships, and more keys to a rich life | Ric Elias (Part 2)

1x15s30s

0:001:22:41

## We discuss:

- Reflecting on the tumultuous last few years and how his experience on Flight 1549 helped him [2:30];
- Parenting: a game of tug of war that you must ultimately lose [5:00];
- Importance of friendship and Ric’s motivation for his recent “Friends summit” [8:00];
- The impact of looking forward and focusing on growth on finishing life well [13:00];
- How our relationships with our children evolve as they grow, and a new perspective on purpose [21:15];
- Living with complete intention for a rich life, valuing your time, and other life lessons inspired by Ric’s near-death experience on Flight 1549 [31:15];
- How society’s relationship with work has changed, the pros and cons of remote and hybrid working environments, and an update on his company “Red Ventures” [37:45];
- Ric’s dedication to philanthropy [44:45];
- The Golden Door Scholars program aiming to help undocumented students with education and a future career [50:30];
- Ric’s journey in health and longevity [59:15]
- Letting go of guilt and loving yourself [1:02:30];
- The relationship between happiness and wealth [1:06:45];
- Playing the “infinite game,” staying true to oneself, and ignoring the negative [1:09:15];
- Speculating on the meaning of success, the drivers of greatness, and the value of struggle [1:16:00]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- You may remember Ric Elias; we released a [podcast with Ric](https://peterattiamd.com/ricelias/) back in November of 2019
  - We spoke at great length about his experience on [Flight 1549](https://en.wikipedia.org/wiki/US_Airways_Flight_1549), also known as the “Miracle on the Hudson”, in which his plane went down and was miraculously saved by Sully (the pilot) in the Hudson River
  - If you haven’t yet listened to that interview, Peter recommends going back and doing so prior to this conversation, because in this conversation we don’t really repeat any of that amazing story, and that that story alone is worth the price of admission
- In this episode we talk about what’s been new in Ric’s life since the last interview (which has been over three years)
- We talk about raising kids and how we should think about our relationship with them as they grow older
- We talk about the importance of looking forward and not looking backward, and how that ties into aging
  - There’s a line Peter uses in the epilogue of his book that came directly from a discussion about this with Ric
- We talk about the importance of true intentionality in how we live our lives and how we often don’t really value our time if we think about it in relation to that
- We talk about Ric’s view on relationships and the impact that you can have on others
- We talk about the importance of staying true yourself and the importance of struggles and more
- This conversation is a great follow up to the recent [podcast](https://peterattiamd.com/billperkins) with [Bill Perkins](https://www.diewithzerobook.com/welcome)
- Both Bill and Ric have a lot of insights to share as we think about how we live our lives, how we live every day
- Peter notes, “*Every time I speak with Ric, I learn something new and walk away with a new insight, something that I’m challenged by in something that I need to think about*”
- Ric’s the co-founder and CEO of [Red Ventures](https://www.redventures.com/), a portfolio of digital companies and host of his own podcast called [*3 Things with Ric Elias*](https://www.redventures.com/blog/categories/3-things?utm_source=podnews.net&utm_medium=web&utm_campaign=podcast-page)

## Reflecting on the tumultuous last few years and how his experience on Flight 1549 helped him [2:30]

**What have been the highs and lows for you over the last three years?**

- Ric remembers their conversation about leadership and how do leaders show up in a time of crisis
- Then 60-90 days later COVID hits and a lot changed
- The last three years have been the most tumultuous three years, no matter where you are in the world, and then you layer that with lots and lots of changes
- Ric’s kids have gone to college
- In this time his father-in law and aunt (who was like a second mom to him) passed away
- His business went aggressively into offense to take advantage of opportunities that came about when the market changed
  - They bought some very meaningful businesses
  - Then everything further imploded
  - Now we’re living in the middle of a war, in the middle of uncertainty in all of that

> “*The world always keeps changing and surprising us. We tend to project today’s reality into the future, but it’s always changing.*” —Ric Elias

**How much of your even keel (your perspective) around all of these events do you attribute to what happened in January of 2009?**  (referring to [Flight 1549](https://en.wikipedia.org/wiki/US_Airways_Flight_1549))

- A lot, he doesn’t have a lot of lows or high highs
- “*The understanding that “this too shall pass” and doing what you can in the moment when you can is really all you can do. And if you don’t tie yourself up to the outcome as much and you’re just really trying to stay in the process, I’m able to navigate this in great part because of that experience.*”

## Parenting: a game of tug of war that you must ultimately lose [5:00]

**How do you think about that metaphorical tug of war with your kids?**

- Their discussion of this is something that stuck with Peter from their previous conversation on the [podcast](https://peterattiamd.com/ricelias/)
  - Ric compared raising children to playing a game of tug of war that you eventually lose
  - You can’t lose it immediately, but by the time they’re off to college, they’ve pulled you over the line (metaphorically)
- Rics kids are off to college but Peter is in the middle of that game

**How Ric’s thinking on parenting has evolved in the last few years**

- Probably the last meaningful lesson Ric got from his mom as she had onset of Alzheimer’s disease was her advice about his teenage daughter
  - She looked at him and said, “*My son, raising teenagers is a tug of war… that you ultimately must lose*”
- It was such an an insightful, all-encompassing statement about parenting
- It’s really the transition from they’ll always be your kid, to you will not always be their parent
  - And it’s that transition from no longer being them parent and maybe being more of a coach, advisor, or friend
  - You will always treat them like your kid
- Ric doesn’t think of himself as the parent anymore
- Their conversations are very different and he loves it
- There have been times with both of his kids where they have said, “*I really appreciate your opinion, but this is what I’m choosing to do*”
  - To him this is a sign that they have a really good sense of their own decisions
  - He may disagree with them, but it’s good to see them in their journey of adulting on their own

**There is a difference in kids when they become teenagers and start pushing away**

- Peter has noticed this
- Ric always believed that the reason why teenagers are such a pain is so that you don’t miss them when they leave
- Ric and his wife love their kids and are lucky that their kids love them back, but they high-fived each other when they dropped them off
  - They did not cry
  - They were ready
- Empty nesting is a beautiful thing
  - They still talk to them all the time and see them and all that
  - The funny part is that they’re doing the same things that drove you crazy, but you just don’t see it; it doesn’t feel as intense

## Importance of friendship and Ric’s motivation for his recent “Friends summit” [8:00]

**What was your motivation for the get together you had last summer?**

- Early in the summer Ric called Peter to invite him to a get together in July
  - It was at Ric’s home for a couple of days
  - With 30 other guys, one of whom Peter knew, but most of whom Peter didn’t know
- Peter hates to travel and would have just come back from a trip and would need to leave the next day to attend
- Peter thought this was for a birthday, so he committed to think about it
  - He told his wife about the asymmetry of his regret
    - He would spend the flight there kicking himself for going
    - But if he didn’t go, months later he would kick himself for not going
- Peter went and it ended up being a really special time
- When you go back through your year and ask yourself what was truly memorable, he usually comes up with 8-10 things
  - He adds, “*What is universal is they’re usually experiences, and they’re experiences with people that you have a deep connection with*”

***Ric has become very focused on creating experiences with people he loves as a way to create memorable moments of the year because these memories with people are richer and what we grow old with***

- Memories alone are not enough, memories with people are richer
- Rick wanted to experiment with the concept of a **friends summit**, of bringing together 30 super interesting friends
  - The uniqueness of it is everybody’s been curated by him; they were all Ric’s friends
- Everyone arrived with the attitude that if these people are Ric’s friends, they would be open minded
  - The small talk wasn’t around “*What do you do? Who are you?*” but more of “*How do you know Ric?*”
- He curated an agenda, had a lot of the participants speak, had all sorts of things around food, had a magician, etc.
- One of the things Ric loves the most happened, his good friends became great friends with each other
  - He was with [Rick Hendrick](https://en.wikipedia.org/wiki/Rick_Hendrick) a week ago and they spent 15 minutes talking about Peter and [Matt Walker](https://www.sleepdiplomat.com/), and other people

> “*What greater currency in life than spreading love through friendship?*”‒ Ric Elias

- Everyone there left with the gift of new friends
- Ric adds, “*At our age, it’s not easy to make good new friends; and it is something that we can do by leveraging our own friendships.*”
- When Ric heard Peter’s interview with Matt Walker, he asked Peter to introduce them
  - They have become dear friends and talk all the time

***It’s all around this currency that friendships really matter in life; memories, memorable moments really matter, and how you bring all that together***

- Peter was surprised by the number of guys he met there who he couldn’t wait to see again
- There was some structure to the friends summit; it was effectively like a bunch of fireside chats

**What did you learn during that summit? Did anything surprise you?**

- Ric learned not to schedule something like this right after a vacation because he spent his whole vacation thinking about the interviews
  - The lesson was to create some gap between an event and your relaxing time

- He learned that all of us need moments like this where no matter who you are to the outside world, you are one and the same in the group
  - There were professional athletes, governors, CEOs‒ people who are exceptional in their field (like Peter)
  - But there everybody was the same
  - Everybody could let their guard down
- Ric got to hang out with 30 of his best friends and give lots of hugs and catch up and have moments and create memories
- Relationships take a lot of effort, and that was a really efficient way to make huge deposits into a bunch of important accounts

## The impact of looking forward and focusing on growth on finishing life well [13:00]

**A lesson from Marshall Rauch**

- Peter thinks one of the most interesting lessons came from [Marshall Rauch](https://en.wikipedia.org/wiki/Marshall_Rauch)
- Ric has known Marshall for about 20 years; he met him when Marshall was 81 or 82
- There is something about Marshall that is incredibly appealing and attractive
  - Every time you see him (once a month, every other month) he has a list of things that he has learned that he wants to talk about
  - He has ideas about things he wants to do
  - He’s constantly evolving and thinking

***What Ric has learned from Marshall is that your age really can be told by what you think about***

- Aging of our spirit, not of our bodies, not of our mind, but of our spirit, it’s really about which mirror you’re using
  - Are you using the rear view mirror or the windshield?
- Ric told a story where Marshall is asking for his opinion
  - Marshall was worried about his son (age 72) and thinking about giving them a tough lesson
  - The point was he never stopped thinking and doing that; this is how he lives
- Marshall will be 100 in February and he hopes to do something super special
- Peter remembers another story, when Marshall was 96 and he came to Ric with a pretty serious business idea
  - It was predicated on trends over the next 10 years
  - The idea was that it wasn’t necessarily an enormous opportunity today, but he had all the data for why 10 years from now this would be a home run
- Here is a guy who is 96, why is he thinking about a business opportunity that is going to mushroom in the next 10 years?
- He was a senator for North Carolina for 26 years
- He is unique
  - He’s Jewish, but he made all his money selling Christmas ornaments
  - He’s incredibly close to his kids and his grandkids
  - He sees the world so clearly; even when you talk about current events and politics today, he has a wisdom about
  - He literally played basketball at Duke in 1939
  - He went to World War II
  - He’s had tremendous hardships; he lost his wife, he lost some kids; and the dignity by which he handles it is just distilled in his wisdom of life that Ric finds super attractive
- Peter notes there is soft science and hard science; he has spent most of his life thinking about the hard science of living longer
  - The metrics and biomarkers we can measure
  - How we can predict our assumptions of risk based on X, Y, and Z
- But there is no question that there are soft metrics that we can’t quantify but they must matter
- Peter’s dad is an example
  - His dad is age 85, not the healthiest guy, but has outlived everybody in his completely unhealthy family by more than two decades
  - His dad wouldn’t listen to a thing Peter has said if his life depended on it

***But Peter believes his modest longevity comes down to this phenomenon‒ he is never looking back; he is planning; he has an idea***

- When he should have been retiring, he bought quarries with the idea that there would be a demand for high quality limestone, dolomite, and granite in the next 30 years
- He’s out in a quarry every day, barely able to walk because his knees are so messed up
- The idea of just sitting around couldn’t possibly occur to him, let alone be relaxing

**Ric has studied a lot of people that are finishing life well, in their 70s and 80s**

- He thinks we are all pretty predictable, we just have to find patterns that relate to us
- A good friend, [Henry Kravis](https://en.wikipedia.org/wiki/Henry_Kravis) is in his late 70s is a complete stud
  - He has changed and evolved a lot as one of the great leaders in Wall Street
  - When you sit down with him, he has more energy and passion; he’s thinking more about the future
- There is something to be said about staying in the arena, even if you downshift
- When your brain stays connected, you stay relevant, and you don’t feel old because you don’t feel irrelevant

**Have you read Arthur Brooks’s book** [***From Strength to Strength***](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)**?**

- Ric has read excerpts and listed to Peter’s [podcast](https://peterattiamd.com/arthurbrooks/) with him
  - He thought the podcast was tremendous
- He thinks a lot of what he says around **crystalized intelligence** relates to this
  - For Ric, crystallized intelligence is more about the evolution (and aging) of our brain in a way that allows us to stay productive for the tribe/ society
- Peter really enjoyed speaking with Arthur
- He enjoyed his book; he read it twice
  - It really hit home because even though Peter is not yet 50, there is no question that he doesn’t have the horsepower he had at age 20 or 25 (when he was at his cerebral peak)
  - His writing about the transition from fluid to crystallized intelligence gave Peter comfort in accepting this transition
- Peter brings this up because he agrees that it’s important to stay on in the field, but he also thinks it’s important to understand that it’s okay to move to a different position

***Ric thinks the importance of life is not necessarily looking forward, but to be constantly growing***

> “*The day you stop growing is the day you age*”‒ Ric Elias

## How our relationships with our children evolve as they grow, and a new perspective on purpose [21:15]

**Back to kids and parenting**

- Peter reflects, “*I am sad when I think about my kids not being little and I’m not sure what that’s about*”
- Ric got to see the boys in complete action/ high energy at dinner yesterday
  - He could feel Peter’s joy and love, seeing Peter hug the boys
- Yesterday the boys were well behaved, but there are an equal number of times when you’d think they are psychotic; you can’t believe how poorly they behave
  - The other day, Jill walked by the youngest and out of nowhere, he took his pencil and stabbed her in the butt, unprovoked
  - Those moments can be really hard

- Peter feels fortunate to be going through this a little later in life when he can appreciate it
  - Had he been presented with this 20 years earlier, he might not have had the maturity to embrace it as much
- Ric agrees, the trade-off with having kids later in life is you don’t have as much energy but you have a different perspective

> “*The great thing about having kids is we get to almost relive life*”‒ Ric Elias

- Ric finds something very subconscious about rediscovering things or seeing things through their eyes
  - It brings the child back in us
- He thinks that child is a safe place in all of our persona
- There’s also this notion of, “*This is how we are relevant in the world*”
  - Through them is how we are going to stay here when we’re no longer here
- Being a parent is such a powerful job and responsibility that is heightened in every sense of good and bad
- The reality is that all the things they are doing are just normal growth moment of their own brain development
- Peter’s youngest (Harry, age 5) is obsessed with math right now
  - He’s learning how to add
  - The other day they were sitting on the couch and he asked, “*When I am 100, is Reese going to be 103?*” (Reese is 3 years older)
  - Then he looks at Peter and asks how old he is going to be, 70?
  - Peter told him he would be long dead when he’s 100, but if he were alive, he bed 140 whatever
- It’s an amazing thought that Peter thinks kids today will quite easily live to be 100-years-old
- Today centenarians are exceedingly rare, about 0.004% of the population
- Kids born today will probably reach 100 at a far greater frequency
- For Peter it was a bit of a sobering thought, “*I’m looking at this little chubby, cute kid that I can’t stop wanting to squeeze and hug and kiss and realizing he’s going to be 100 year old man one day and I’ll be probably long gone*”

**For a person for whom a lot of purpose came from your kids, as they are older, do you feel less of that and has it caused you to put more of your sense of purpose into something else?**

- Ric is very challenged by the notion of how to help evolve his relationship with his kids into more of a coaching relationship
  - He wants to be a sounding board amongst other things
  - He gives them advice with the preface of, “*You got to do whatever you want, but I want you to know that I am a resource for you. You’re not alone in solving this problem… you have other people.*”
- He is enjoying the morphing of his relationship with his kids
- He thinks this is why people enjoy grandkids so much‒ it’s a chance to do it again with lower expectations

> “*We have this innate desire to perpetuate ourselves and we do that through our kids*”‒ Ric Elias

**The Centenarian Decathlon is one of the greatest motivations for Peter**

- This is also motivating for many of Peter’s patients
- This speaks to what people want to be able to do with their offspring and grandchildren
- Peter has an exercise where you build a timeline
  - Put your age down and your kids
  - Estimate when your kids will have kids
  - Then see what your age will be when the grandkids are different ages
- Very quickly you come to the realization that the things you want to be able to enjoy doing with your grandkids will range from the really extravagant to the really mundane
  - Take them on the greatest vacation, to see the pyramids in Egypt and go down the Nile
  - Play catch

**Flight 1549 gave Ric a new perspective on purpose and parenting**

*A story from after the plane crash that Ric hasn’t shared:*

- A couple weeks after the plane crash he was watching his daughter perform in kindergarten
- He had this intense realization that his most important purpose was to help his kids become adults
- He had the same emotion recently at her graduation from high school (she’s now a sophomore in college)
  - As the graduates were coming down the hallway he started bawling uncontrollably as he saw her
    - He didn’t expect it
    - It came out of nowhere
    - He’s not a crier
  - “*It was a realization that I had lived to the moment where she had become her own person*”
- The graduation from high school was a lot more meaningful than just the graduation
  - It was a realization that she can fly on her own now
  - It was also a realization that now he has the capacity to broaden his purpose

> “*I think we’re all seeking purpose… it’s not like you finish, it’s just you evolve it*”‒ Ric Elias

- Ric was very grateful to have this experience because seldom in life do you get to see the end of the circle come back

**Have you had any interactions or follow-up with the crew from that flight or Captain Sullenberger?**

- There were 154 people on US Airways Flight 1549 plus the crew (158 total)

*Do you all collectively celebrate that anniversary together?*

- There are Facebook groups and all that stuff; there’s always something
- Ric has participated in a couple things, but he has been more on the fringe
- He got a lot of what he needed at the time from his closest friends and family
- Peter asked Ric at the [last podcast](https://peterattiamd.com/ricelias/) if he had seen [Captain Sully Sullenberger](https://en.wikipedia.org/wiki/Sully_Sullenberger) enough
  - And Ric had told him he was planning to do something
- The plane itself is worth seeing because it’s banged up, as it had hit a wall at 150+ mph
- The shell of the plane sits in Charlotte (where US Airways was based out of)
  - The airport was going to move the plane to Dallas (for facility reasons)
- Normally after a wreck, the plane would be scrapped, but this one had significance
- A group of people in Charlotte rallied, and Ric made a donation asking for naming rights
- The thing he is going to do to honor Sully and the crew is to name the museum in Charlotte after him
  - It will be the “Sullenberger Aviation Museum” or “The Carolinas” or something like that
- Ric called Sully to ask for his permission
  - Interestingly he was hesitant at first
  - But he called him back and said, “*Ok, let’s do it*”
- The naming and big event will happen in January on the 14th anniversary
- It will be a beautiful day
- Ric wanted to find something that would outlast both of them as a way to honor Sully’s commitment to doing his craft and saving lives

## Living with complete intention for a rich life, valuing your time, and other life lessons inspired by Ric’s near-death experience on Flight 1549 [31:15]

**One thing that really stood out to Peter from the first podcast with Ric**

- If you haven’t familiarized yourself with the story of the crash landing of US Airways Flight 1549, you should go back and listen to that section of the [podcast](https://peterattiamd.com/ricelias/)
  - This is probably the longest version of this story Ric has told
  - Ric’s [TED talk](https://www.ted.com/talks/ric_elias_3_things_i_learned_while_my_plane_crashed?utm_campaign=tedspread&utm_medium=referral&utm_source=tedcomshare) is also really moving
- When the plane is going down and Ric realizes there is about 10 seconds until he is going to die, he said a couple things
- 1 – It’s very calm, you weren’t scared, you were sad, very sad
- 2 – You put your hand on your arm and said, “*I love you,*” so it would be the last thing you said to yourself before you would’ve died; and you closed your eyes
  - Peter couldn’t believe this
  - This is the last thing he would ever thing to say
  - He’d probably would have said nothing but felt very sad
  - He doesn’t think there would have been any gratitude

**Have you asked any of the other people on the flight what they did or said in the last 10 seconds?**

- Ric hasn’t but it would be interesting
- He points out that they had no suffering
- He imagines if you were dying in some level of distress, your mind would be in a very different place in terms of coping
- This was 90 seconds; a lot of people have a near death experience that lasts only one or two seconds

**Three regrets Ric had as the plane was going down**

- The [TED talk](https://www.ted.com/talks/ric_elias_3_things_i_learned_while_my_plane_crashed?utm_campaign=tedspread&utm_medium=referral&utm_source=tedcomshare) was a moment in time all about the three regrets he felt as the plane was coming down
  - Ric talked about these a lot in the other [podcast](https://peterattiamd.com/ricelias/)
- 1 – He realized that everything changes in an instant; so **time** really, really matters
  - Life is urgent, don’t postpone anything
- 2 – He realized that **relationships** are at the core of the richness of life
  - Yet we spend a lot of time letting our ego be in charge
- 3 – He realized that with his **kids**, he wasn’t living true to what he discovered was his main purpose (which is seeing his kids)

***He felt regret at the time of his impending death that he had missed knowing the key to living a better life***

**How Ric thinks about this now**

- As he reflects on all this, it is interesting that nothing has really changed
- Instead of focusing on everything changes in an instant and living in the moment, he has focused on the notion of having **true intentionality** about how he lives life

> “*How we live our life is a really big, deep bucket that I spend lots and lots of time thinking about*”‒ Ric Elias

- It has a lot to do with time
- The problem with time is the same problem that we have most things that are free, we don’t value it
  - If you spend real money on time, you would behave differently
- The problem with time (as we have learned about sleep) is you have to do a lot of things to extend your time so that you are more productive the next day
  - You need sleep, nutrition, and exercise so that you have more time

**For Ric, to live with intentionality is about a lot of things**

- Where we spend our energy
- The things that we stop doing
- How do we reverse things that we don’t want to do?
- “*I really think that this notion of having complete intention is really a decor of living a more rich life*”

**Rics exercises to help him live with intentionality**

- He has 242 weeks until he turns 60
  - At 60 he will have a different energy level and will probably be paying back a bunch of physical debts
- He uses lots of little exercises such as‒  “*What are my intentions this week?*”
- He realizes that everything is fleeting and chooses to live in chunks of his life with great intention
- This manifest itself when you talk about relationships
- Ric realized he wants to continue to meet new people he can learn from
  - He’s addicted to learning and growth, and the best way to do that is through other people
- He thinks about the amount of energy he puts into friendships (not relationships); when you’re in business you have a lot of deal friends
  - The key is how do you convert them into real friends?
  - Who do you want to convert into real friends?
  - To talk about a skill to be learned or to talk about it being a never ending journey; how do you approach that?
- Ric has an enormous amount of great friends (more than most) because he spends the bulk of his time on that

**Ric’s thoughts on time**

- There are only three things you can do with time
  - 1 – Waste it (a lot of teenagers do this)
  - 2 – Use it for things that have value
  - 3 – Invest it
- The ratio of what you do with those three components is important
- The question is, “*How much are you using it for things that gives you pleasure or things that you want to do and how much are you investing? And that will ultimately continue to pay dividends in life.*”
- If you’re using too much of your time on something, at some point it becomes wasteful
- Relationships are super rich
- The last thing is this notion of purpose and how do you expand that

***Ric has spent a lot of time trying to continue to evolve the gift [of Flight 1549] and not look at it as a moment in time but rather a map into the future***

## How society’s relationship with work has changed, the pros and cons of remote and hybrid working environments, and an update on his company “Red Ventures” [37:45]

**Remind people what Red Ventures is; it’s not an easy thing to explain**

- It’s funny because Ric explained it in the last [podcast](https://peterattiamd.com/ricelias/) (3 years ago) differently than he is going to now
- [Red Ventures](https://www.redventures.com/) is basically a private equity platform of companies
  - So instead of investing as a passive investor, they control a bunch of companies (about 17 companies)
  - They don’t own 100% of those companies, but they control all of them
  - These companies are all over the place‒ Europe, Brazil
    - They’re starting the first bank in Puerto Rico in 26 years
    - They own a bunch of brands in the US (mostly digital brands)
    - They own services companies
- It’s just really a platform of tech and data and digital and a really, really strong culture and a purposeful place to work
- They’re up to 4,500 employees

**How big was the company in 2015/2015?**

- 1200 employees
- They still have the same beautiful campus, but people are not going in as often

**How has our relationship with work changed?**

- Everything has pros and cons
- Ric thinks COVID did a lot of good for society in fixing the way we think about our relationship with work
  - Work doesn’t have to follow those rules that were established way early in the industrial age for control
  - And control is a false premise in every regard
- Ric thinks one of the unique things about the US is that it trains people between age 20-30
  - This is something that you don’t see this in a lot of other countries (having studied a lot of Latin American countries)
  - Many companies and corporations and hospital systems are really training people into their second and third decade of life
- You spend the first decade of your life learning a lot (hopefully, if you’re lucky to have good parents)
- Then school becomes a place you work
- Then, whatever your profession is, that third decade of life is incredibly important
  - That is where you build a lot of depth and learn on someone else’s nickel

**The downside of not being in an immersive culture**

- Ric worries that we’re going to look back in 10 years and the US would’ve lost a sense of competitiveness
  - Because a lot of these people coming into the workforce are getting a fraction of the tutoring and coaching and experiences and intuition that they would’ve had
  - So 30, 40 years from now we would’ve lost a lot at our age because we stopped investing in the people and their creativity and their skill

**Flexibility is king**

- Ric argues that one thing we learned in COVID is we should celebrate and look for flexibility
- We shouldn’t sacrifice raising kids if you’re a working parent
  - Or travel like crazy
- A lot of that is baked into changes in the rule of engagement
- But this is all a moment in time that may be lost if we go into a recession
- Some of these habits may never retire
  - Ric hopes we never lose the flexibility we gained
  - He doesn’t love going to work everyday at the same time

> “*I love having a lot more freedom, and I think most people do*”‒ Ric Elias

**Are there certain jobs that work really well remotely versus not?**

- Ric thinks there are 2 components to this
- 1 – Productivity, which in some functions is easy to measure
  - At Red Ventures they have a lot of editors that write real content, and they are as productive or more so
    - They don’t have to commute and do lots of things that are distracting at the office
  - There are some places in engineering where this is also true, when you’re not doing a lot of collaboration
- 2 – But this can be taxing on your mental health, to be home alone every day
  - We’re designed to be with others and Ric doesn’t think we know the real value or tax on that

**Advantages of a hybrid schedule**

- A hybrid schedule where you come in sometimes and work remote sometimes can be a healthier way to gain expertise
  - When you’re collaborating with people, learning experientially, and building intuition
- There are a lot of things we do during the week that you don’t need to be in a place

***Ric’s hope is that ultimately work evolves into what are the things that require people to be together versus what are not, and then depending on where you are in your career and your proficiency, you have more flexibility***

**How long do you think you’ll be at Red Ventures as your “day job” versus working on some of the other non-profit things you are interested in?**

- Ric feels super healthy thanks in great part to Peter
  - He feels he has slowed down a lot of aging and is really grateful
- So long as he feels healthy, he loves this perch
- He’s as happy as can be and doesn’t want to replace it
  - It will evolve and change
  - A lot of the companies at [Red Ventures](https://www.redventures.com/) will gain independence
- With COVID he got to do something for a second time, which we usually don’t do in life
  - He got to have his kids home for a year and a half, and it was wonderful
- Instead of Red Ventures being one thing, they will find the right outcomes and marriages of a lot of their businesses with the right partners and allow those people to become CEOs of their own businesses
  - This will create monetization and return for investors
  - But their ability to stay private and stay independent and stay away from all the other stuff that public companies have to deal with, it’s not negotiable
- Ric sees Red Ventures in a bizarre way returning to its truths in the next 25 years, to a much simpler thing where most of their businesses will evolve out
  - They’ll continue to buy businesses in the next 10 years, but his guess is when he turns 80, they’ll have 15 people and be hoping to give all their money away

## Ric’s dedication to philanthropy [44:45]

**Did you recently sign The Giving Pledge? Explain what this is.**

- Yes, about 1.5 years ago
- [The Giving Pledge](https://en.wikipedia.org/wiki/The_Giving_Pledge) is something [Bill](https://en.wikipedia.org/wiki/Bill_Gates) and [Melinda](https://en.wikipedia.org/wiki/Melinda_French_Gates) Gates and [Warren Buffett](https://en.wikipedia.org/wiki/Warren_Buffett) started
  - It’s around creating consciousness of the people that have had more luck than others in creating real wealth to create a commitment and responsibility that you will give at least 50% of that wealth back
- This pledge is not something he did without a lot ot trepidation
- Hundreds of people around the world have signed this pledge
- It’s a bit of a community too, where you learn how to give in ways that reflect what you want to do
- There’s real value to being part of the community
- When they first met, they had the privilege of having dinner in Omaha with Warren Buffet
  - Rics kids were still in high school and they didn’t want this burden because it creates negative energy around making public the amount of wealth you have
- Ric waited until his kids were in college to join
- They joined the pledge hoping that others will realize, “*This only works if it works for everybody, it doesn’t work if it works only for a few*”
- The idea is to give back to the system

**Podcast with John Arnold**

- Peter asks, “*Did you ever hear the* [*podcast*](https://peterattiamd.com/johnarnold/) *I did with John Arnold?*”
- No, Ric did not
- [John and Laura Arnold](https://www.arnoldventures.org/about), who’ve also signed the Giving Pledge, are probably two of the most deliberate philanthropists Peter has ever met
- John was, hands down the most successful energy trader in the history of energy trading
  - He was a trader at Enron, right out of college
  - His personal book of business was generating around a billion dollars a year for Enron (just his own personal trades)
  - When Enron imploded, he was handed a severance check of something like $5 million, and he took every penny of it, put it into his fund, and went on a 10 year tear of unparalleled returns (something like 30% per month)
  - At the time John shut his fund down (2011 or 2012), he was not yet 40-years-old, and he turned his career to focus on philanthropy
    - He applied his level of rigor and analytics to philanthropy
  - Peter notes, “*He’s done something that I think is really interesting and highlights something really hard, which is: it’s actually not that easy to give away billions of dollars*.”
    - It takes time to fund the sorts of projects John is interested in
  - John and his wife correctly came to the realization that they can’t wait until they’re 65 to start doing this
    - They will run out of time because they have too much money

**What things are you committed to funding?**

- 1 – Undocumented kids who are not born here but brought here, young, educated here, and then can’t work
- 2 – Disaster relief in Puerto Rico

**Ric’s take on philanthropy and solving problems**

- He thinks only governments have the muscle to really solve problems
- Even people with the wealth of Bill and Melinda Gates have come to this conclusion
- You can attack singular problems that maybe eradicate a disease or something like that if you have billions and billions of dollars
- But true systemic issues require the muscle of the government

**“*****The role of any nonprofit is to gain momentum, to create a roadmap, to create the case for governments to really put real funding behind things to create systemic changes. I don’t think that the illusion of we’re going to fix a real issue*****.”**

- Peter adds, “*The philanthropist can do something that the government won’t do, which is, you can take a risk financially… You can demonstrate a proof of principle*.”
  - The philanthropist can effectively function as the angel investor or the early stage VC
  - And the government comes in as the PE investor
- In this regard, Ric thinks he brings an entrepreneurial spirit and real business savviness
- A long time ago [Jeff Bezos](https://en.wikipedia.org/wiki/Jeff_Bezos) said something around philanthropy‒ you’re not really necessarily looking for the perfect business plan; if you’re helping somebody, you’re doing good
  - This is Ric’s approach‒ to do things that are good for the world
  - And if it’s good for one person then you’re trying to do it in scale and with purpose
- Ric’s approach keeps evolving

## The Golden Door Scholars program aiming to help undocumented students with education and a future career [50:30]

**Undocumented kids and Ric’s** [**Golden Door Scholars**](https://www.goldendoorscholars.org/) **program**

- This is focused on people who are 16 to 24 and under resourced
  - It’s more than undocumented kids
  - Every year about 80,000 kids graduating high school have no ability to get a work permit; it’s just insane
- Kids born in another country come here undocumented, grow up here, go to high school
  - They could go to college, but they can’t get financial aid because they’re not residents

**What happens to these kids?**

- Ric guesses that 95% of them end up taking minimum wage jobs or jobs that are underground
- There was a process there where you can get a [DACA](https://en.wikipedia.org/wiki/Deferred_Action_for_Childhood_Arrivals) permit to work
  - There’s 650,000 of these kids that have DACA permits
  - DACA was rescinded under the last administration so there are no new permits
- These kids grew up here, their families are here; going back to their home country is really hard because they have no roots or resources there
  - They may not even know the language

**What is the distribution of where these kids are from?**

- 90% are from Latin America
- Probably ⅔ of those are from Mexico
- You also see a lot from Southeast Asia and other places

**More about the Golden Door Scholars program**

- Ric’s yearly [scholarship grant](https://www.goldendoorscholars.org/) just closed and they got 1200 applicants
  - Over 300 of them have close to a 4.0 GPA (unweighted)
- These kids don’t get federal financial, aid and in about half of states, they don’t qualify for in-state tuition

**Is the investment you’re making that if these kids crush it in college, they could get a** [**H-1B visa**](https://en.wikipedia.org/wiki/H-1B_visa) **on the back end or land a legitimate** [**dual intent visa**](https://en.wikipedia.org/wiki/Dual_intent) **with a path to citizenship based on their education?**

- Until three years ago, they were all [DACA](https://en.wikipedia.org/wiki/Deferred_Action_for_Childhood_Arrivals), and they had a path to getting jobs
- There are 520 kids in the program, and about half of them are graduating
  - Now that the kids are graduating, they’re in limbo because they can’t get a work permit
  - The H-1B visa and all of that can’t do it
- Ric keeps thinking this is the last year, because Congress just needs to pass a law
- Ric points out, “*The crazy thing is we invest in them in primary school and secondary school. We don’t ask the question when they go to our school systems, but then we invest all that money. Why don’t we make them taxpayers? We have an issue*.”
- Further, there is a massive decline of kids applying to college
  - We have a massive college infrastructure with not enough students

***Why not educate these kids, make them pay taxes, and give them a path to citizenship?***

- This is one of those things that makes no sense to Ric

[**Road to Hire**](https://www.roadtohire.org/)

- After the [George Floyd](https://en.wikipedia.org/wiki/George_Floyd) event, Ric’s company expanded this scholarship program to find opportunities in our inner cities [called [Road to Hire](https://www.roadtohire.org/)]
- Road to Hire started teaching coding in North Carolina, mostly at [Title I](https://en.wikipedia.org/wiki/Elementary_and_Secondary_Education_Act) high schools to black and brown students
- They start teaching in high schools
- Then they do an apprenticeship program and partner with corporations in [Charlotte, NC](https://en.wikipedia.org/wiki/Charlotte,_North_Carolina)
  - These kids are not going to college
  - Road to Hire connects these kids with a two-year apprenticeship and pays them on behalf of the corporation
- They are graduating more black and brown kids with computer science expertise that the whole North Carolina system is now
- They have over 220 kids graduating and they all have jobs on the other end
- After two years of the apprenticeship these kids are as competent in technology as someone who graduated from NC State

**How do you think that [Road to Hire] can be scaled?**

- Ric points out, “*You start with the jobs… at the end of the day there’s hundreds of thousands of jobs that are unfilled because they don’t have the skills*”
- He sees the same things with high school teachers
  - The projected teaching vacancy is something on the order of 350,000
  - But yet most states pay these teachers $42,000‒ “*It’s crazy*”
- There’s a big gap in technology and the reason why his model works in Charlotte and North Carolina is because it rides on the rails of the system
  - It partners with the county, city, public high school systems
  - Then the corporations basically offer a job on the other end

***The key is to start with the job and then train into the job versus starting with education and hoping they get a job***

- Ric points out that this program also helps corporations solve the diversity challenge
- There’s a big initiative called [OneTen](https://oneten.org/) that a number of high profile CEOs have built to try to connect talented blacks to well-paying jobs
  - It just takes a long, long time
  - Ric’s concern is when the economy turns, these are the kinds of things that get scrapped, and we go back to this negative spiral that we tend to have

**Peter has a little bit of disbelief as to why the US would not as a country want to embrace an amazing asset. Do you see this changing?**

- Ric does, he’s super optimistic about our country

> “*For as flawed as we are, I would rather be nowhere else.*”‒ Ric Elias

- Unfortunately, these are things that just take time
- Ric is reading a book called [*Brothers*](https://www.amazon.com/Brothers-Hidden-History-Kennedy-Years/dp/0743269187) about the Kennedys and realized that there were real serious issues around the mob and all these things that we don’t hear about today
  - He views this as a similar trend
  - Progress is not linear and not fast enough
- Peter thinks back to the 60s‒ that was a more tumultuous era, there were political assassinations on US soil
  - We don’t have anything like that today
  - But the never ending cycle of nonsense news, cable, social media, makes it feel more dramatic
- Ric agrees, “*These are pendulums. I think we’re at a pendulum right now where the country’s super divided. I believe that there will be a series of leaders in our future that will bring us back together. We need a common enemy*.”
- Ric finds it interesting that when there is a real crisis (9/11 or even at the beginning of COVID), we all behave like Americans and not Republicans or Democrats
  - He thinks peaceful times allow a lot of room for us to subdivide

## Ric’s journey in health and longevity [59:15]

**How would you describe overall your mentality towards your health, your longevity? What changes have you made?**

- Peter has known Ric for 9 years; he knows he’s a health conscious guy
- Basketball used to be the only thing Ric did for exercise
  - It was great because it kept him running ,but he was prone to injuries
- One of Peter’s favorites is Ric’s approach to body weight
- Ric realizes that he wants to be here for as long as he can, and he wants to be as active as possible
- He’s committed to this, this notion of time; but it’s time on the other way
- In the last four years, he’s transitioned from playing basketball to going to the gym with a trainer
  - He doesn’t do the crazy stuff that Peter does
  - But this has made him stronger from grip to balance
  - He doesn’t consider himself an elite athlete but he feels so much better
  - His last pickup basketball game was about 3 months ago
  - He has now picked up tennis

**Why did you stop playing your favorite sport [basketball]?**

- Ric has watched a lot of people his age blow an achilles or a knee
  - He thinks these are signals he should listen to
- The more he played basketball, the more his knees were sore
  - His body was talking to him and he listened
- He wanted to leave on his terms, knowing that it served its purpose and it doesn’t control him
- He picked up tennis in the pandemic, and it’s something he does with his family
  - He has a coach and goes twice a week
  - He loves the apprenticeship, the struggle
  - It’s a great workout;  he gets his heart rate to 130 and stays in zone 2 for an hour
  - He’s not really good, but gets a lot of value out of it
  - Footwork is different and it’s a reminder of humility

> “*Everything that we now take for granted that we think we’re so good at, at some point was really, really hard*”‒ Ric Elias

- There is a list of things Ric wants to do
  - Learn to dance salsa‒ he can’t die as the only Puerto Rican who can’t dance salsa
  - Last night Peter grilled; he used to grill a lot more
  - He wants to keep learning things

**Was he sad about his last pick-up basketball game?**

- No
- He is grateful for what he had, not because it ended

## Letting go of guilt and loving yourself [1:02:30]

**Growth since the plane accident**

- Ric notes, “*The biggest self growth I’ve had since the plane was in that middle bucket of relationships.*”
- He also realizes that the most important relationship we have (the most important friend) is with ourselves
  - Unless we get that right, everything else will have a lot of friction
- He has also realized that guilt is the most useless emotion one can have
  - Most religions he knows are using guilt as a way of teaching us or as keeping us connected to something
  - He’s spent the last five years getting rid of guilt

> “*When you feel no guilt, what you realize is that you can change the dialogue that you have with yourself*”‒ Ric Elias

- Now Ric is super kind to himself
  - He constantly makes mistakes but has nothing but love for himself
  - He will say, “*Yeah, that wasn’t your best. Okay, next one it is.*”

**Do you ever come home in a bad mood and snap at your wife?**

- It happens
- Peter follows up with another question, “*I think it’s really easy to feel bad and feel shame for snapping at her and then that actually impairs your next interaction. But how do you break that cycle?*”
- Ric owns it, he will say, “*I’m sorry, I just took out something on you that it was not on you, that was unfair. I hope you forgive me.*”
  - It will take him maybe 20-30 minutes to man up to that
  - He can read body language and see what he did
  - More importantly is he doesn’t carry this notion of feeling bad
    - He recognizes it as part of being human, part of growing up, part of learning, part of your humanity

**Do you think that can only happen because you’re able to immediately make amends?**

- Ric thinks guilt is a pretty strong habit for a lot of people
- 98% of your thoughts are with yourself
- First of all, you’ve got to be very aware of all your thoughts and you’ve got to be able to objectivize what you’re hearing and be able to evaluate it and say, “*Is this productive? Is this helping me or am I doing this because I’ve always done it or because this is how my parents related to it?*”

**Ric thinks the more we move away from the emotion of guilt it becomes self-love**

- It becomes a notion of the safest place for us to be is with ourselves, and the kindest place to be is in our own heads
- And there’s no judgment,
- Life becomes so much simpler and then you give yourself and you can give to others

**Purpose**

- Ric thinks we’re lucky we can impact people
- Peter is impacting people through his platform
- Ric is impacting people with his company
- How you show up to the coffee shop in the morning
  - The type of connection that you make
  - The taking time
  - All of that is making an impact
- And the more that you feel at peace inside, the more you want to give it
- Ric is now addicted really to good energy
  - That doesn’t mean it’s maybe 95% of the time
  - But he loves that place and gives it freely expecting nothing in return
    - This is the happy place Ric lives in

## The relationship between happiness and wealth [1:06:45]

*Do you think they’re uncoupled? Do you think they’re correlated positively? Do you think they’re correlated negatively?*

- Ric thinks we decide what they are
- Some of the happiest people in the world have no wealth, so they cannot be coupled
- Wealth can give you a set of conveniences that allows you to solve for whatever your priorities are
  - That may heighten your ability to do that and therefore gives you more happiness
  - Or like in many people you pursue wealth your whole life because that’s what our society wants, and when you get there, you just feel so empty and then you feel so guilty for all you sacrifice for it
    - And you’re in the worst place, which is you got what you wanted and it was a mirage and it meant nothing

**We talk a lot in life around the best way to run a race**

- There are so many people out there that feel like, “*Oh my goodness, I was running the wrong race*”
- Ric thinks it’s important to reevaluate the race you’re running
- After the plane crash, Ric made it very clear he was going to run a different race than everybody else
  - He didn’t want to be in the public eye
  - He didn’t want to be the wealthiest
  - “*My race was to enjoy the race*”
- Ric loves growing, being challenged, competing
- He gives no power to anybody and tries really hard not to take power away from anybody

**What do you think are the ways that people even inadvertently take power away from people?**

- As leaders, we can over lead and not let other people be celebrated and take credit for things
  - On the contrary, we can take responsibility for things that may not have truly been our responsibility
- Ric thinks leaders have an ability to really manage the power equation with intentionality
- In their [last conversation](https://peterattiamd.com/ricelias/) they talked about how you treat somebody
- Ric thinks the best way we can parent is by showing our kids how to treat strangers and how we give people respect no matter who they are or what they’re doing
  - Everybody puts their pants on the same way
  - Everybody has insecurities, everybody has issues
  - We all are in this imperfect journey with imperfections
  - When you look at people through this lens, it just makes it a level field and simpler

## Playing the “infinite game,” staying true to oneself, and ignoring the negative [1:09:15]

**How do you implement the infinite game ethos into both your business and your life?**

- One of the really enjoyable highlights of the Friends Summit for Peter was when [Simon Sinek](https://en.wikipedia.org/wiki/Simon_Sinek) got up and talked about finite versus infinite games (he wrote [*The Infinite Game*](https://www.amazon.com/Infinite-Game-Simon-Sinek/dp/073521350X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1671469975&sr=8-1))
- Ric adds, “*When Simon sent me an early book and said, hey, what do you think? It was almost like he was writing what was in my brain*.”
- Simon was actually rewriting a book that had been written before in more modern terms
- The infinite game became codifying a language that Ric really believes in

***The core of the infinite game is that there’s no winning; the whole objective of the game is to stay in the game***

- The real ultimate objective is not just to stay in the game but to perpetuate the game
- What Peter is doing through the podcast, and his book that’s coming out, through your kids, through everything else, is perpetuating the game
  - Living with purpose
- When you give up winning or losing, you give away a lot of jealousy
  - Maybe sometimes he’s a little envious, but he doesn’t feel jealousy

***The infinite game makes it really, really simple not to get caught up on winning or losing; just play the game***

- This allows you to get away from this notion of, “*I came in second, I came in third*”
- And Ric doesn’t think it affects the outcome at all

**Do public markets demand winning?**

- Peter asks, “*Is that something that you have the luxury of playing because you run a private company?*”
- If [Red Ventures](https://www.redventures.com/) were a public company, would Ric be able to live by this ethos?
  - Or would quarterly earnings and other metrics change that?
    - Ric thinks yes
    - You could argue that many successful people are playing the infinite game
      - [Jeff Bezos](https://en.wikipedia.org/wiki/Jeff_Bezos) at Amazon f never made money even though the public markets were demanding that he did this
      - [Elon Musk](https://en.wikipedia.org/wiki/Elon_Musk) is playing the infinite game in many ways with the decisions he’s making
      - [Mark Zuckerberg](https://en.wikipedia.org/wiki/Mark_Zuckerberg) with Meta, he clearly has lost 75% of the value of the company

**The importance of staying true to yourself**

- Ric notes, “*You just have to have the temperament and the stomach to be unpopular*”
- One of the best ways to be unpopular is *not* to read
  - Ric doesn’t read anything about himself
  - The opinion of a stranger has zero value to him
- Now if Peter called him and said he heard he said this or did this and that doesn’t feel like you, Ric would listen because he knows Peter knows him and cares about him

> “*I have no desire to be popular with people I don’t know. I want to be respected by people that I care about*.”‒ Ric Elias

- Peter thinks this is an amazing lesson and a very difficult features of living in the world today

**Do you look at what people are saying about you on social media? Do you read comments?**

- Peter does a little
  - He is 95% compliant with the notion of ignoring it
  - When he does read it, he is rarely perturbed by it largely for the reasons Ric discussed (he understands it’s irrelevant)
- But Peter can’t imagine what this would be like on a real stage: What about Mark Zuckerberg for example?
  - Ric thinks he doesn’t care
  - To Ric, “*There’s no stage that it’s different or bigger than ours. There’s just different stages. Just because someone has a bigger platform than we do doesn’t make their stage more important than ours, we’re all the same.*”
  - Peter thinks the attacks are louder potentially
  - But, Ric points out, “*Does it matter if you don’t read them?*”
    - If you stay true to yourself, it is all circular logic

***Have you imparted a lesson like this to your kids?***

- They talked a little about this in their [previous conversation](https://peterattiamd.com/ricelias/)
- Ric made an interesting point that Peter has thought about a lot‒ there has been an inevitable trend that children exceed the accomplishments of their parents
  - Historically, Peter had thought that his kids have it much easier than they did because he came from very little
  - Their kids come from plenty
  - Ric came at this from a point of real empathy, he wanted to make sure his kids aren’t under unnecessary/ unrealistic pressure to do something their parents did
- Ric notes that their kids have a lot more comfort, access, experiences
- But this is different from defining the level of satisfaction with life (or level of happiness)
- Ric thinks it’s goofy to start with the premise that kids should achieve more financially than their parents

***Ric would love his kids to feel they were given the opportunity to really find their gift and do with it in a place of love***

- He wants them as a family to do good in the world
- People will comment, “*It’s hard when you are Peter Attia’s daughter or Peter Attia’s son*,” and we should be mindful of that
  - That’s a burden placed on them by others that they don’t know how to accept

## Speculating on the meaning of success, the drivers of greatness, and the value of struggle [1:16:00]

**What drives greatness?**

- Peter saw an interesting [clip](https://youtu.be/kd3bA1mRAn8) of a very young [Arnold Schwarzenegger](https://en.wikipedia.org/wiki/Arnold_Schwarzenegger)
  - It was late 70s/ early 80s
  - He had already accomplished a lot at this point
  - This was before he became a big movie star, before he was governor
  - In the interview he was asked, “*What accounts for your greatness?*”
  - He explained that his drive came from a place of hardship, that basically everything comes from  a singular focus of escaping and being better/ improving
  - The reality of it is, if your kids don’t come from this level of deprivation, they can’t be great; they can be very well adjusted, and that’s really the best thing you can hope for them
- Ric asks, “*But great in what? Great at lifting weights? Great at being a movie star? Being exceptional?*”
- Ric notes, “*That’s different because you can be a great human being. Being the elite 1% of something has a huge amount of attacks on other things*.”
- The problem with hyper successful people is as they try to repeat what they did, it ends up being more self-destructive
- Ric would argue that most people can’t handle greatness because it is addictive
  - Greatness, as reflected by being the best at something for a period of time

***Those who are able to accept the fact that greatness doesn’t matter, that it will change and evolve; they live better lives***

- Ric asks, “*What do you want for your kid? To be the greatest at something for a moment in time and miserable?*”
  - To be self-adjusted seems like a consolation prize
- Peter thinks being well adjusted is a fantastic objective
  - This is an extreme version of the yin and the yang between fluid and crystallized intelligence
  - The more extreme your fluid intelligence is, it might be harder to make that transition to crystallized intelligence
  - He thinks that’s even more true in what is it like to be [Tiger Woods](https://en.wikipedia.org/wiki/Tiger_Woods) or [Michael Jordan](https://en.wikipedia.org/wiki/Michael_Jordan)
- This is why Ric thinks really great 4.0, perfect students struggle to be super productive in life
  - Because they never had to deal with adversity
  - They never had to be coached
  - They’ve never had to be in a place where they’re forced to be good at it

> “*It is better to struggle so that you learn to struggle than to be great at something, because life is full of potential struggles*”‒ Ric Elias

§

## Selected Links / Related Material

**Previous episode of** ***The Drive*** **with Ric Elias**: [#79 – Ric Elias: Earning the gift of life](https://peterattiamd.com/ricelias/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (November 11, 2019) | [0:45, 5:00, 31:15, 33:15, 38:00]

**Ric’s company**: [Red Ventures](https://www.redventures.com/) | [2:15, 37:45]

**Ric’s podcast**: [3 Things with Ric Elias](https://www.redventures.com/blog/categories/3-things?utm_source=podnews.net&utm_medium=web&utm_campaign=podcast-page) | [2:15]

**Previous episodes of** ***The Drive*** **with Matt Walker**:

- [#47 – Matthew Walker, Ph.D., on sleep – Part I of III: Dangers of poor sleep, Alzheimer’s risk, mental health, memory consolidation, and more](https://peterattiamd.com/matthewwalker1/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (April 1, 2019) | [11:15]
- [#48 – Matthew Walker, Ph.D., on sleep – Part II of III: Heart disease, cancer, sexual function, and the causes of sleep disruption (and tips to correct it)](https://peterattiamd.com/matthewwalker2/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (April 8, 2019) | [11:15]
- [#49 – Matthew Walker, Ph.D., on sleep – Part III of III: The penetrating effects of poor sleep from metabolism to performance to genetics, and the impact of caffeine, alcohol, THC, and CBD on sleep](https://peterattiamd.com/matthewwalker3/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (April 15, 2019) | [11:15]
- [#58 – AMA with sleep expert, Matthew Walker, Ph.D.: Strategies for sleeping more, sleeping better, and avoiding things that are disrupting sleep](https://peterattiamd.com/matthewwalkerama/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (June 17, 2019) | [11:15]
- [#77 – AMA #2 with sleep expert, Matthew Walker, Ph.D.: short sleep mutants, optimal sleep environment, sleep apnea, & rapid fire questions](https://peterattiamd.com/matthewwalkerama2/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (October 28, 2019) | [11:15]
- [#126 – Matthew Walker, Ph.D.: Sleep and immune function, chronotypes, hygiene tips, and addressing questions about his book](https://peterattiamd.com/matthewwalker4/) | (August 31, 2020) | [11:15]
- [#127 – AMA #3 with sleep expert, Matthew Walker, Ph.D.: Fasting, gut health, blue light, caffeine, REM sleep, and more](https://peterattiamd.com/matthewwalkerama3/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (September 7, 2020) | [11:15]
- [#221 ‒ Understanding sleep and how to improve it](https://peterattiamd.com/understanding-sleep/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (September 5, 2022) | [11:15]

**Arthur’s book**: [From Strength to Strength: Finding Success, Happiness, and Deep Purpose in the Second Half of Life](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Arthur C. Brooks (2022) | [19:30]

**Previous episode of** ***The Drive*** **with Arthur Brooks**: [#226 ‒ The science of happiness](https://peterattiamd.com/arthurbrooks/) | Arthur Brooks, Ph.D. | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (October 10, 2022) | [19:30]

**Ric’s TED Talk**: [3 things I learned while my plane crashed](https://www.ted.com/talks/ric_elias_3_things_i_learned_while_my_plane_crashed?utm_campaign=tedspread&utm_medium=referral&utm_source=tedcomshare) | Ric Elias TED2011 | [31:30, 33:00]

**Previous episode of** ***The Drive*** **with John Arnold**: [#125 – John Arnold: The most prolific philanthropist you may not have heard of](https://peterattiamd.com/johnarnold/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (August 24, 2020) | [46:45]

**Philanthropic programs Ric started**:

- [Golden Door Scholars](https://www.goldendoorscholars.org/) | [50:30]
- [Road to Hire](https://www.roadtohire.org/) | [54:30]

**Initiative to connect blacks to well-paying jobs**: [OneTen](https://oneten.org/) | [57:00]

**Book about the Kennedy brothers and organized crime**:  [Brothers: The Hidden History of the Kennedy Years](https://www.amazon.com/Brothers-Hidden-History-Kennedy-Years/dp/0743269187) by David Talbot (May 8, 2007) | [57:45]

***The Infinity Game*****, Simon Sinek’s book**: [The Infinite Game](https://www.amazon.com/Infinite-Game-Simon-Sinek/dp/073521350X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1671469975&sr=8-1) by Simon Sinek (October 15, 2019) | [1:09:30]

§

## People Mentioned

- [Bill Perkins](https://www.diewithzerobook.com/welcome) (Hedge fund manager, entrepreneur and author of [*Die With Zero*](https://www.amazon.com/Die-Zero-Getting-Your-Money/dp/0358099765/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1669823704&sr=8-1)) [2:00]
- [Rick Hendrick](https://en.wikipedia.org/wiki/Rick_Hendrick) (businessman, owner of NASCAR team Hendrick Motorsports, founder of Hendrick Automotive Group) [10:45]
- [Matt Walker](https://www.sleepdiplomat.com/) (Professor of Neuroscience and Psychology at UC Berkeley, founder and director of the Center for Human Sleep Science) [11:00]
- [Marshall Rauch](https://en.wikipedia.org/wiki/Marshall_Rauch) (retired state senator for North Carolina) [13:15]
- [Henry Kravis](https://en.wikipedia.org/wiki/Henry_Kravis) (American businessman and philanthropist) [19:00]
- [Arthur Brooks](https://www.hbs.edu/faculty/Pages/profile.aspx?facId=1134664) (Professor at Harvard University, author of [*From Strength to Strength*](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=)) [19:30]
- [Sully Sullenberger](https://en.wikipedia.org/wiki/Sully_Sullenberger) (retired American fighter pilot, diplomat, and captain of US Airways flight 1549) [29:00]
- [Bill Gates](https://en.wikipedia.org/wiki/Bill_Gates) (co-founder of Microsoft and philanthropist) [45:00]
- [Melinda Gates](https://en.wikipedia.org/wiki/Melinda_French_Gates) (philanthropist) [45:15]
- [Warren Buffet](https://en.wikipedia.org/wiki/Warren_Buffett) (CEO of Berkshire Hathaway and philanthropist) [45:15]
- [John Arnold](https://www.arnoldventures.org/about) (American billionaire and philanthropist) [46:45]
- [Jeff Bezos](https://en.wikipedia.org/wiki/Jeff_Bezos) (Founder of Amazon) [50:15, 1:11:45]
- [George Floyd](https://en.wikipedia.org/wiki/George_Floyd) (African-American man who was murdered by a police officer in Minneapolis, Minnesota) [54:30]
- [Simon Sinek](https://en.wikipedia.org/wiki/Simon_Sinek) (Author and inspirational speaker) [1:09:30]
- [Elon Musk](https://en.wikipedia.org/wiki/Elon_Musk) (founder of SpaceX and angel investor, CEO of Tesla, owner of Twitter) [1:12:00]
- [Mark Zukerberg](https://en.wikipedia.org/wiki/Mark_Zuckerberg) (Co-founder of Facebook) [1:12:00]
- [Arnold Schwarzenegger](https://en.wikipedia.org/wiki/Arnold_Schwarzenegger) (retired professional bodybuilder and 38th governor of California) [1:16:00]
- [Tiger Woods](https://en.wikipedia.org/wiki/Tiger_Woods) (one of the greatest golfers of all time) [1:18:30]
- [Michael Jordan](https://en.wikipedia.org/wiki/Michael_Jordan) (one of the greatest basketball players of all time) [1:18:30]

§

![](https://peterattiamd.com/wp-content/uploads/2023/02/bio-image-ricelias2-500x500.png)

##### Ric Elias

Ric Elias was given the gift of a miracle: to face near-certain death, and then to come back and live differently.

A native of Puerto Rico, Elias attended Boston College and Harvard Business School before starting his career as part of GE’s Financial Management program. He cofounded [Red Ventures](https://www.redventures.com/) in 2000, just months before the dot-com bubble burst. The company weathered the storm; by 2007 it was ranked fourth on the Inc. 500 list, and in 2015 the company was valued at more than $1 billion. Elias has cultivated an award-winning company culture, ranking as a “Best Place to Work” in Charlotte, North Carolina, for ten years in a row.

Elias’s leadership style and personal life are deeply influenced by his experience as a survivor of Flight 1549, also known as the “Miracle on the Hudson.” He is devoted to using his platform to “leave the woodpile higher than he found it” — spinning out multiple nonprofits from Red Ventures over the years, all of which are aimed at creating educational opportunity and economic mobility for under-served groups. In 2018, Elias launched Forward787, a social enterprise committed to raising and deploying $100 million to build businesses in Puerto Rico that compete with the world’s top companies. In 2019, he launched a podcast, [*3 Things with Ric Elias*](https://www.redventures.com/blog/categories/3-things?utm_source=podnews.net&utm_medium=web&utm_campaign=podcast-page), as a continuation of the learning journey he shared on the [TED](https://www.ted.com/talks/ric_elias_3_things_i_learned_while_my_plane_crashed?utm_campaign=tedspread&utm_medium=referral&utm_source=tedcomshare) stage. [[TED](https://www.ted.com/speakers/ric_elias)]

Twitter: [@RicElias](https://twitter.com/ricelias?lang=en)

Instagram:  [@\_ricelias](https://www.instagram.com/_ricelias/?hl=en)