# #289 – AMA #56: Cancer screening: pros and cons, screening options, interpreting results, and more

**Source:** [https://peterattiamd.com/ama56/](https://peterattiamd.com/ama56/)

---

In this “Ask Me Anything” (AMA) episode, the conversation focuses on cancer screening, a topic often shrouded in confusion yet crucial to understand given that early identification of a cancer is an essential part of survival strategy. Peter examines the arguments both for and against cancer screening, including addressing why some trials may show no benefit to screening. He then delves into the various screening modalities available for different cancers, highlights the pros and cons associated with each, and explains how to interpret the results. Additionally, Peter provides guidance for navigating outside of the relatively narrow and confined screening guidelines for various types of screening tests.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #56 show notes page](https://peterattiamd.com/ama56). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Why understanding cancer screening is crucial [2:45];
- The prevalence of cancer diagnosis and mortality rates [4:30];
- Why cancer screening and early detection is such an important part of the strategy to survive a cancer diagnosis [11:00];
- The data on how cancer screening impacts survivability of cancer [16:30];
- Inconsistencies between cancer screening trials regarding benefits to survival rates [25:45];
- What are some of the reasons why clinical trials don’t always improve cancer-specific mortality? [30:15];
- What are the arguments against population-level cancer screening? [42:00];
- Cancer screening outside the recommended guidelines: risks and benefits, interpreting results, and other considerations [46:00];
- Understanding sensitivity and specificity when reviewing screening results [52:30];
- Risks and complications associated with colonoscopies [55:45];
- Cancer screening modalities: options for cancer screening both within standard recommendations and beyond [58:30];
- The strengths and limitations of various types of cancer screening [1:02:15];
- Understanding positive and negative predictive value using sensitivity, specificity, and pretest probability [1:11:45];
- Factors that influence an individual’s pretest probability of cancer [1:13:45];
- How to interpret cancer screening results [1:18:15];
- The importance of having an advocate when considering out-of-guideline cancer screening tests [1:23:30];
- How stacking multiple cancer screening modalities can decrease the risk of false positives [1:29:30];
- Advice and guidance for making decisions related to cancer screening [1:31:15]; and
- More.

§

The Peter Attia Drive

Cancer screening: pros and cons, screening options, interpreting results, and more

§

## Show Notes

§

## Why understanding cancer screening is crucial [2:45]

Today’s AMA is going to focus all around cancer screening

- Is it important?
- Is it beneficial?
- Sometimes articles in the news claim cancer screening is beneficial
- Others talking about how studies came out in cancer screenings not beneficial
- This creates a lot of confusion for people around this topic

Today’s AMA will go through:

- Cancer screening in general
- the cases for and against cancer screening
- why some trials may show benefit while others don’t
- What modalities do people have
- the different options for cancer screening, including the pros and cons of each of them
- also what should people think about when they get cancer screening, whether it’s within traditional guidelines or what we’re seeing more so now is if people are paying out of pocket outside of traditional guidelines

## The prevalence of cancer diagnosis and mortality rates [4:30]

**Cancer incidence and mortality rates**

- A rough, but not totally accurate, way to say this is that a person in the US has a lifetime incidence of cancer about one in three and about half the time it’s going to be fatal
  - Said another way, one in three chance of getting cancer in your lifetime, and one in six chance of dying from cancer
  - However, this is an underestimate
- What are the most recent numbers?
  - Men have a lifetime incidence of just under 41% and indeed about half of those are fatal, i.e., a 20.2% lifetime risk of dying from cancer
  - For women, the numbers are slightly better, 39.1% lifetime risk of cancer diagnosis with just under half of those being fatal, so a 17.7% of dying from cancer
- A more relevant way to look at this:
  - Cancer is the second leading cause of death in the United States and globally (ASCVD is #1)
  - And it’s probably more maybe insightful to compare this through decades of life

![](https://peterattiamd.com/wp-content/uploads/2024/02/f1-ama56.png)

**Figure 1.** *Source: CDC report on causes of death in 2021, omitting deaths attributable to COVID-19 where applicable.*

- This table is organized by decades—we’re looking at people aged 25 to 34, 35 to 44, et cetera, all the way up to 85+
- And we’re looking at three things
  - 1) What percentage of deaths in that decade are attributed to cancer?
  - 2) Then we’re looking at the actual rate of cancer death.
    - And this is always done in deaths per 100,000
    - So what is the number of deaths per 100,000 and what is the rank of cancer relative to other types of death within that decade?
  - 3) And for the cases where cancer is not number one, what is number one?

**Let’s start at the lowest end of the spectrum**: This is lowest in terms of lowest mortality because the number you really want to anchor to is what’s the absolute death rate, and that’s going to be in how many cases per 100,000

- In that first decade, 25 to 34, cancer accounts for 8 deaths per 100,000 individuals
  - Not many people fortunately are dying that young… it represents 6% of total deaths ranking third
  - There are two things that rank significantly higher and not surprisingly, the number one cause of death in that demographic is accidental death (typically overdose)
- You go up to the next category, 35 to 44, the percent of deaths attributed to cancer goes up from 6 to 13% and the rate of death goes up threefold
  - Goes to 26 deaths per 100,000
  - It is still the third leading cause of death, trailing accidental death (overdose, typically)
- We go into the next decade, 45 to 54, cancer now accounts for 23% of all deaths in someone Peter’s age
  - The rate of cancer deaths again jumps sharply from 26 to now 88 per 100,000, and it technically ranks second (asterisk here because here is where cancer and ASCVD are constantly switching with each other)
  - It ranks first or second here, and it’s either ASCVD or cancer that are in the number one spot
  - Then accidents tends to fall to number three
- So you go one decade up, 55 to 64, the percentage of deaths attributed to cancer is 30% of deaths
  - By the way, this is almost the maximum share of cancer deaths you’ll see
  - It now rises to the number one cause of death in that age group, and it now accounts for 267 deaths per 100,000
- Go up another decade, 65-74, and it basically is the same story
  - It’s 31% of deaths attributed
  - It is the leading cause of death, and it now has doubled to 553 deaths per 100,000
- Now you’ve made it to the age of 75, and what happens?
  - Well, it turns out that other diseases are exploding, and so cancer now falls to second
  - ASCVD takes over, but cancer still accounts for a quarter of deaths, but the absolute rate continues to rise
  - It doubles again to 1,036 deaths per 100,000 people
  - Again, ASCVD is number one
- And when you go out past 85…
  - ASCVD holds onto its number one spot
  - And cancer takes the number three spot
  - It tends to fall (now 12%), although it’s absolute numbers go up to 1,649 deaths per 100,000
  - So here, neurodegenerative disease tends to come up and take that place of cancer.

Why go through all of those stats?

- Well, the point to make here is there’s really no decade of life in which cancer is not at least top three causes of death
- And by extension, anybody listening to this is probably thinking of cancer
- It would be almost impossible to listen to this and not know someone who has either battled cancer or who has outright died of cancer

## Why cancer screening and early detection is such an important part of the strategy to survive a cancer diagnosis [11:00]

**Let’s take a step back and compare cancer to ASCVD**

*ASCVD:*

- ASCVD is the leading cause of death at this point
- We understand what drives ASCVD well
- We really understand the big four drivers of ASCVD—lipoproteins, hypertension, smoking and metabolic health
- There are certainly genetic things in there that one has to pay attention to, such as Lp(a), familial hypercholesterolemia and things like that
- But again, those tend to be relegated down into issues that can be managed pharmacologically
- In other words, we have a clear understanding of how that disease progresses
- We can monitor a person’s progress towards that disease because we have the biomarkers that predict risk
- We have tools like CT angiograms that allow us to at least somewhat roughly look at the anatomy of the coronary arteries and get a sense of how advanced disease might be.

*Cancer:*

- When it comes to cancer, none of that’s really true
- Outside of smoking, certain genetic conditions, and poor metabolic health, it’s still a little bit of a black box as to why people get cancer, and more importantly, what one can do to reduce risk
- What we have to acknowledge is that we have two things working AGAINST us in the cancer equation that we have working FOR us in the heart disease equation
- One is that we have far less command over the biology of the disease
- Secondly, we have far fewer effective treatments for the disease once it is advanced

**The easiest way to understand that is to look at both 5 and 10 year survival curves**:

![](https://peterattiamd.com/wp-content/uploads/2024/02/f2-ama56-1024x445.png)

**Figure 2.** Source: SEER database

These are the **five** leading causes of cancer death only in alphabetical order

- The rankings go lung first and pancreatic last
- When you look at five-year survival, you look at this in two stages
- You look at what we consider early stage one, stage two—so this is regional cancer or local cancer actually hasn’t even spread to a lymph node
- Stage three means that the cancer has spread to a lymph node, but no further
- Stage four means the cancer has now left the lymph node and gone to a distant site

*Breast cancer*:

- In breast cancer, for instance, we always think about this in two forms
- We think about HER2+ and HER2-, estrogen receptor positive (ER+) and negative (ER-), and triple negative (TNBC)
  - And if anybody who needs a refresher on that, we have a great [podcast on breast cancer](https://peterattiamd.com/haroldburstein/) that explains why these are three basically very different diseases
- You can see the difference in survival between all of these cancers at an early stage where it ranges from 92 to 100% stage I/II survival
- To stage IV where you have metastatic disease, it’s 13 to 40%
- By the way, those are much better numbers than they used to be—breast cancer is probably one of the bigger success stories of the past 20 years in terms of stretching out median survival

*Colorectal cancer*:

- If it’s a colorectal cancer that is caught before it’s gone to the lymph nodes, we’re talking about 88% for five years survival
- But if it’s gone to lymph nodes, that goes down to 70%
- And if it’s spread to the liver, it’s down to 16%.

*Lung cancer*: Lung cancer ranges from 59% early to 6% late

*Prostate cancer*:

- Prostate is 100% early, 33% if it spreads
- The worst of all of these is pancreatic cancer
- If you can at least catch it in stage one, stage two, it’s 38% five-year survival versus 3% if it’s distant

**Quick point about 10 year survival data**:

- With the data on 10 year survival, Peter points out that the trends are even more dramatic than 5 year survival
- In other words, the difference between stage one and stage two survival versus stage four survival at 10 years is even a bigger chasm

***Why is all this relevant?***

- Despite all of the advances we’ve had in the past 20 years, and clearly hormone therapy for breast cancer and immunotherapy for a number of other cancers (particularly [checkpoint inhibitors](https://peterattiamd.com/andrewhuberman3/)), still leaves us with a lot to be desired, especially when it comes to late stage cancer
- It’s very important to catch cancers in stage 1 or 2 versus stage 4

> “If you’re going to get cancer, you certainly do not want to be in the position where that diagnosis is being made once the cancer is advanced, once the cancer has had a chance to spread. You really want to be able to diagnose cancer and manage it when it’s in the stage one/stage two phase.” —Peter Attia

## The data on how cancer screening impacts survivability of cancer [16:30]

***Do clinical trials on cancer screening show any benefits in reducing cancer deaths?***

This is really the crux of what we’re here to talk about today because this has become a controversial topic

Peter says he used to have a “*young man’s naive view*” of cancer screening which was:

- “Back when I was clinically training, I was rather dismissive of cancer screening, and my knee-jerk view of the literature was cancer screening didn’t really matter that much. The biology of the cancer was the only factor that mattered, and any extension of lifespan we saw through cancer screening was probably just due to lead time bias, and we really shouldn’t spend any time on cancer screening. We really needed to focus on the biology of the tumors and cell guided therapies and things of that nature.”

But today, Peter has changed his tune

- You can still focus extensively on cancer screening
- and that doesn’t for a moment suggest that you shouldn’t be doing everything to understand the biology of the tumor and dedicating resources to understanding how to treat it
- “But sometimes the best offense is a really good defense”

**Let’s talk about screening and the data**:

- It’s quite clear that there is a distinct advantage to cancer screening, says Peter
- One of the most clear cases for that is the *use of mammography* for breast cancer
- There have been eight RCTs conducted from the 1960s to the 1980s to evaluate the efficacy of screening mammography with regard to reduced mortality from breast cancer
- 6 of these 8 trials showed a benefit of reduced breast cancer mortality
- The trials that showed this were:
  - [NY Health Insurance Plan (HIP) trial](https://pubmed.ncbi.nlm.nih.gov/9709271/)
  - 4 trials from Sweden
  - 1 trial from Edinborough (Scotland)
- The studies have largely held up under the rebuttal of the size of the effects relative to the reduction of breast cancer mortality

Some of the most compelling data that mammography reduces breast cancer have come from the [two county trial from Sweden](https://pubmed.ncbi.nlm.nih.gov/2512366/)

- - This study from 1989 was a randomized study that looked at two counties in Sweden
  - It had a 90% compliance
  - women age 50 to 69 at an average screening interval of just under three years—meaning they were screened almost every three years and it showed a 32% reduction in death from breast cancer over a 10 year follow-up.

- D*oes it say anything about all cause mortality*?

- - It’s such an important point
  - That study did not see a difference in a reduced all cause mortality
  - There was a 1/3 reduction in death from breast cancer over a decade, but that did not translate to a reduction in all cause mortality
  - If you think about it, *what is the probability that a woman is going to die of breast cancer over a 10 year period*?
    - The answer is it’s not that high over any 10 year period
    - So her lifetime risk of death is 8% over the entirety of her life, but over a 10 year period in that demographic, I’m making this up, but the answer is probably 3%
    - So if you reduce that from 3% to 1%, you have to ask yourself the question, how much do I need to power a study to detect a 1% reduction in all cause mortality across a 10 year period? ⇒ The answer is, you’re almost assuredly not powering the study to do that
    - (We’ll talk about that more in a moment)

**Let’s now talk about one of the null studies**:

There was a null study from the Canadian National Breast Cancer Screening study ([CNBSS-1 and 2 study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8892036/))

- There has been a real call to disregard these studies when making any recommendations because the validity of these trials have come into question with significant errors in research conduct
- Firsthand accounts of the data provide new information that these trials failed to meet the acceptable standards of an RCT
- So neither of these studies showed the benefit of mammography on breast cancer screening, But both of these trials have problems
- The first is underpowered
  - if you look at a study and it’s null, you want to know that it’s null because there was no difference, not because you didn’t sample enough
  - If the power analysis, which basically forces you a priority to say, I think the effect size is going to be X, and I think that the effect size with the treatment is going to be X- something or X+ something, and therefore I want 80% or 90% power to detect that difference
  - It will tell you how many subjects you need
  - So if that analysis hasn’t been done, you can’t tell the difference
- So why were these studies underpowered?
  - Given that era in which these studies were done, there was a fear of radiation and there was a very low compliance and there was high contamination
  - So there was a lot of mammography done in the control group that shouldn’t have been done, and there were a lot of patients lost to follow up.
- There are also eyewitness reports, believe it or not, of violations of the randomization process itself included in the assignment of women with physical signs of breast cancer to the screening arm
- Again, these two studies which people sometimes point to and say, “Well, not every study shows that there’s a benefit to screening.”
  - These studies are, at best, methodologically flawed And some of this stuff actually it borders on fraud
- There are a number of other issues that interfered with randomization and tampering
  - For example, some of the women underwent a breast exam before randomization, and the impact of that breast exam determined where they were randomized
- Another issue that they did was they were not recruiting women that were representative of a population of interest
  - They were recruiting women with lumps in their breast and using them through a breast surgery clinic as a recruitment site

Just to give you a sense of why these studies can be mostly disregarded…

- There were 24 women in the group, they were in their 40s had a certain type of cancer that had a very poor prognosis
- 19 of them ended up in the mammography group and 5 of them in the control group
- Let’s restate that: you have 24 women in the first cohort, the study that was women, 40 to 49, had just a very poor prognosis, breast cancer
- So they had advanced breast cancer, positive lymph nodes, etc. and 19 of them wound up in the mammo group and 5 in the control group
- So if this was a randomized control trial, it should have been 12 and 12 or something close to it.
- So what’s the probability that you would end up with a 19/5 split? Well, it turns out to be less than 1/3 of a percent
- So it’s analyses like these that have led most critics to believe that there was significant tampering that went into these studies

> “But the long and short of it is there has been a pretty clear and consistent benefit [to cancer screening] that has been demonstrated, and the exceptions I think have a pretty clear sense of why.” —Peter Attia

## Inconsistencies between cancer screening trials regarding benefits to survival rates [25:45]

***Outside of those studies (CNBSS-1 and 2 study), why don’t other trials consistently show the benefit of cancer screening?***

- We’ll just come back to why even studies that do show a benefit of screening don’t show the benefit of all cause mortality
- When you see improvements in all cause mortality, you really want to pay attention to that
- The critics of screening will argue, “*Hey, I don’t care if you’ve reduced my risk of breast cancer. I don’t even care if you’ve reduced my risk of death from breast cancer. If you haven’t reduced my risk of death period, why should I care?*”
- So if you have a study that is looking at cancer screening, well it’s looking at **a type of cancer**
- Think back to the table we discussed at the beginning with stats about cancer—that was cancer in aggregate
- And this is where cancer and ASCVD are quite different
- When we think about ASCVD, we’re thinking about largely a single disease
  - Of course there are different paths to get there. But for the most part, ASCVD is ASCVD
- And so if you reduce the mortality of ASCVD by 20% in a clinical trial, you are reducing the entire total
- If ASCVD accounts for 25% of deaths in that cohort and you reduce that by 20%, you’ve reduced the absolute death by 5% across that entire cohort
  - You have a much greater chance of measuring that
- Conversely, with cancer, even if you look at one of the larger decades in which death is represented by cancer, so where death is 30% of cancer, would be the maximum
  - Remember 30 or 31% is the decade in which you see the most cancer
  - But you’re going to focus on one cancer. You’re going to focus on colon cancer or breast cancer or prostate cancer
- Well, any one cancer with the possible exception of lung cancer is never going to represent 10% of total cancer deaths
- So if you pick a decade in which cancer deaths are 25% and breast cancer represents, say, 7% of those deaths, which by the way would be true
- So if you go back to one of those Canadian trials, for example.
  - In the ’70s and ’80s, breast cancer accounted for 7% of deaths women aged 40 to 74
  - So a 30% reduction in that. A 30% relative risk reduction is about a 2% reduction in all cause mortality
  - Well, that’s inside the confidence interval of the study
  - Furthermore, the follow-up on these is typically quite low
- “*In the case of that study, it was less than eight years. So it’s not really long enough to see a difference. And I think that that becomes the fundamental issue*.”

Peter was recently investigating this topic:

- He asked an analyst to pull the actuarial data from every cancer by decade to look at what the studies that find a reduction in cancer specific death would translate to in ACM
- And without exception, it always comes out that you would never be able to detect that—you would need a much larger study over a much longer period of time
- At that point, Peter said, “*Guys, the only thing I might have that might prove me wrong on that is lung cancer. So let’s go take a look at that*.”

Lung cancer screening

- Peter and the team came across this study: [ITALUNG](https://thorax.bmj.com/content/72/9/825.abstract)
- It’s a 4-year RCT of 3,206 smokers (>20 pack-years in the last 10 years), which reported a nearly significant ACM reduction of 17% (RR=0.83; 95% CI 0.67 to 1.03) in the group assigned to annual LDCT screening.
- However, lung cancer is certainly the most likely cancer to show significant differences in ACM with reasonable trial sizes/durations, as it accounts for a much higher proportion of overall deaths than other cancers.

## What are some of the reasons why clinical trials don’t always improve cancer-specific mortality? [30:15]

So just to make sure people understand why we’re now pivoting to this

- Hopefully, we’ve explained why studies that indeed find a reduction in the risk of death from cancer would be very unlikely because of their size and duration and the relatively few number of people that die from any one type of cancer in a short period of time to find a reduction in all cause mortality, which is clearly the gold standard
- Now, we’re asking an equally important question which is, “Well, hey, what about those trials that don’t even find a reduction in the risk of cancer death?”
- If you’re doing a breast cancer or prostate cancer or colon cancer study and you can’t even show me that you’re reducing the risk of death from those things, I got to be thinking twice about it

There are basically three really clear explanations for this and they often show up in combination:

- 1) issues with compliance and/or contamination of the control group
  - You’ll recall that in the Swedish Two-County study, we noted that the women were 90% compliant with their mammography recommendation. And that’s really great
  - Contamination was clearly the case in the Canadian studies where the game was fully, fully loaded against the group that was being screened—so you had a disproportionate number of higher risk patients there
- 2) the use of a very lousy biomarker
  - this primarily plays out in the world of prostate screening
  - absolute PSA level by itself stinks
  - if you look at other things around PSA, if you look at PSA density where you take the PSA and normalize it to the size of the prostate, if you look at PSA velocity, the rate at which the PSA changes, if you look at free PSA and measure it compared to PSA, or if you look at 4K testing or other markers like that, boy, we can really screen for prostate cancer
  - But if you’re going to design a study based around just PSA, which has a very, very low specificity, you could blow the trial altogether, and that certainly happened
  - And it would be a shame to then interpret that screening for prostate cancer doesn’t make sense.
- 3) differences in treatment after cancer diagnosis between the control and intervention groups

**Let’s look at an example**: [NORDICC trial](https://www.nejm.org/doi/full/10.1056/NEJMoa2208375) on colonoscopy

This was actually the first RCT to ask the question, *does colonoscopy screening reduce the risk of death from colon cancer?*

- And lo and behold, the study found a reduced incidence in colon cancer (18% reduction)
- However, no difference statistically in the difference of colorectal cancer death or all cause mortality

The biggest issue with this trial was twofold:

- And Peter doesn’t want to be terribly critical of this trial in that it was what we call an “effectiveness trial”, meaning it’s testing the effectiveness of a recommendation
- And the recommendation was, to half of the people, do nothing, meaning only seek medical attention if something is wrong.
- The other group was instructed to get one colonoscopy within the period of a decade
- And of that later group, 40% did what they were told, got the colonoscopy (Nearly 60% did not)
- And the result of that was they found a reduced incidence of colon cancer because those people that were getting colonoscopies were also finding polyps that were pre-cancerous. Those were getting taken out and they were getting less colon cancer.
- But amazingly, it didn’t result in a difference in colorectal cancer death, which therefore obviously meant it didn’t translate to a difference in all cause mortality

*Effectiveness trials and efficacy trials*

- It is very important to distinguish between effectiveness trials and efficacy trials
- In efficacy trial tests, it’s *how well does an intervention work if it is perfectly complied with*?
- The place where you’ll often discuss this is in nutrition studies
- E.g. *Does calorie restriction improve body weight*?
- Well, there are lots of studies where the answer turns out to be no. If you tell people to reduce their calories and they don’t do it, they’re not going to lose weight
- But does that mean that calorie restriction, if adhered to, doesn’t result in weight loss? Of course not.
- It might mean that calorie restriction is a hard strategy for people, and maybe time restriction or dietary restriction work better
- Those are separate questions
- But we always have to distinguish between efficacy and effectiveness
- One of the things that’s tempting to do in these studies is to look at a per protocol analysis as opposed to intention to treat
  - Intention to treat means, “Hey, we intend to treat everybody. If you don’t comply with the therapy, you’re still included in the analysis and you’re going to dilute the analysis.”
- If you’re doing an effectiveness study, you have to do that.
- If you’re doing efficacy, you would do this as a per protocol treatment, which is, you disregard the people who didn’t do the colonoscopy
- And using that analysis, there was indeed a 50% reduction in colorectal cancer specific death in the screened versus unscreened
- Peter wants to caution against using that because that also tends to select in favor of screening because, who are the people that are most likely to get the colonoscopy? They tend to be healthier people. They’re more health conscious. (healthy user bias)
- Instead, you have to look at the limitations of the study as it was done without looking at the per protocol

*There’s one other to point out about this study*, and it could just be that we were dealing with a remarkably healthy population, because the unscreened people in this study had a 10 year mortality of 0.3% for colorectal cancer

- That is a fraction of what we’d see in the US. The US would be 2.5 to 3% with an 11% all cause mortality rate
- Probably a couple of things going on here, which is, you had a much healthier population and probably too short of a study arm, coupled with low compliance

*Peter would add one more thing*: He doesn’t think every 10 years is sufficient for screening colonoscopy

***How Peter would redesign this study***:

- If I were going to design this study againI would do it in a US population
- I would do it and ensure that we had a higher compliance, because again, I’m interested in efficacy first, effectiveness second
- and I would recommend that the colonoscopies be done every five years as opposed to every 10 years
- This is exactly the kind of trial I would want to see done. But I don’t see anybody funding this trial. I don’t think anybody is going to do this experiment.
- And as it is, I think we’ll never know the answer as to whether or not every three years, every five years, every 10 years is going to make a difference in CRC mortality

*More insights from Peter*:

- Colorectal cancer is a very specific and special type of cancer, because with a good bowel prep, there’s absolutely no reason that a good endoscopist with frequent enough screening shouldn’t be able to detect every single polyp that is pre-cancerous
- Of course, the other side of that is that it’s also the riskiest type of cancer screening—this is the one where you can get hurt.
- So you also want to know what the minimum effective dose is. You don’t want to get a colonoscopy every year, even though that would clearly reduce your risk of colorectal cancer given the biology of this disease, given that it starts with a visible polyp
- The risk of that would be so high (we’ll talk about the risks in a moment)
- So, the NORDICC trial grossly misrepresents and understates the benefit of colonoscopy for the reason described

**Let’s touch on prostate cancer**:

- Prostate cancer is second leading cause of cancer death in men after lung cancer
- We have a biomarker that is pretty sensitive for prostate cancer. It’s 93% sensitive.
- Sensitive means, if you have cancer, it is positive
- Again, with numbers like PSA, you have to define what the cutoff is
- But it has a specificity of 20% which means if you don’t have cancer, it’s negative—And it’s that low specificity that makes it a very difficult tool by itself
- And it’s one of the reasons why a lot of the prostate cancer trials end up being kind of null
- So when it comes to prostate cancer, the name of the game is not, “Do you have prostate cancer?”
- You should be asking, “Do you have the type of prostate cancer that can spread and kill you?”
- That’s not true of breast cancer. That’s not true of pancreatic cancer. That’s not true of colorectal cancer. If you have those cancers, they must come out.
- But it is true with prostate cancer: The old adage holds true, most men will die with it.
- Fortunately, very few will die from it, but we have to identify who those men are
- PSA density, PSA velocity, free PSA, multiparametric MRI… these are the ways you need to be doing it

⇒ For more on prostate cancer and PSA, check out episodes [#39](https://peterattiamd.com/tedschaeffer/) and [#273](https://peterattiamd.com/tedschaeffer2/) with Ted Schaeffer

⇒ for more on interpreting studies, check out [AMA #30](https://peterattiamd.com/ama30/) and read the [Studying Studies series](https://peterattiamd.com/ns001/)

## What are the arguments against population-level cancer screening? [42:00]

***What are the arguments against population level screening outside of whether studies have shown benefit or not show benefit?***

***What are some of the reasons people would just say, “You know what? Either way, doing population level cancer screening is just not worth it.”?***

- So just to make sure people understand what we’re talking about here…
- We’re NOT talking about, “Okay, you have a very aggressive family history for breast cancer. We’re going to take your screening more seriously.”
- We’re also NOT talking about, “You have a very aggressive family history or other personal risk factors for colorectal cancer. We’re going to screen you more aggressively.”
- We ARE talking about, “You have average risk for these things. We’re going to be screening you for these cancers aggressively.”

**There are a couple of arguments**:

1 – One is overdiagnosis

- So you’re going to diagnose things that aren’t really worth being diagnosed
- Prostate cancer is the best example here
- The way prostate cancer used to be diagnosed made this very valid
- There was an era in which great harm was done to men who were overdiagnosed with the type of prostate cancer that was never going to kill them
- What is a Gleason 3+3? And should we be taking out Gleason 3+3’s?
  - The answer today is no, we should not
  - We watch those cancers. And many of those cancers will do absolutely nothing, meaning the man will go on to live a totally normal life or die from something else, and we should not be taking his prostate out
  - But if that 3+3 becomes a 3+4, we absolutely should take it out
- We have much better tools to make those decisions today than we used to
- So that argument made a lot of sense many years ago, but it makes less sense today
- For more on this, check out the episodes with Ted Schaeffer ([#39](https://peterattiamd.com/tedschaeffer/) and [#273](https://peterattiamd.com/tedschaeffer2/))

2 – The differential in life expectancy today between an early and a late stage cancer is shrinking

- That’s correct, but Peter doesn’t think it’s shrinking enough
- Again, the argument that that person is making is, “Hey, I will grant you that stage one and two cancers fare better than stage four, but treatments are good enough today that that gap is not big enough to justify screening.”
- If you go back to the tables we showed at the outset, that gap is narrow enough
- It’s absolutely more narrow than it was 20 years ago, so there is a 10% improvement in that survival gap between early and late
- But you know what? That’s still a big gap
- Will we, in our lifetime, get to a day when every patient with an epithelial tumor, a solid organ tumor, that is metastatic, can be cured?
- Because the answer right now is, only about 10% of those patients can
- If 90% of patients who presented with metastatic lung cancer, breast cancer, prostate cancer, pancreatic cancer, and colon cancer could be cured, then yes, a lot of this discussion might become moot

## Cancer screening outside the recommended guidelines: risks and benefits, interpreting results, and other considerations [46:00]

***If people are considering getting screenings that are outside of the recommended guidelines, what are some important things that they should think about as they’re making that decision?***

- You really have to have an **advocate** as you work through the system and think through these
- We understand that most patients, most people listening to this, might not be able to go and talk to their doctor in detail about this, and that’s why we’ve put so much effort into doing the heavy lifting here.
- But ultimately, what you have to be able to do is make decisions based on how you feel

Ask yourself: *What are the benefits of a given test and what are the risks? So what’s the upside? What’s the downside?*

- Starting with the upside:
- You have to understand these metrics of sensitivity, specificity, and then you have to layer in the prevalence of a given cancer for a group of people just like you.
- In other words, you have to know what your **pre-test probability** of cancer is to effectively guesstimate how valuable the test is going to be for you
- Sensitivity and specificity
  - Those are traits of the test and it’s not always black and white—there’s a huge range of sensitivities and specificities because technologies have changed
  - Certain populations look a little bit different than others, but the basic concepts are obviously immutable
  - So sensitivity is the probability that the test will be positive in the person who has the disease, in this case, cancer
    - In the persons who have cancer, if you have 1000 people who have cancer and you catch 900 of them, you have a 90% sensitivity
  - Specificity is the mirror image of that—it’s the probability that the test will return a negative value if the person does not have cancer
    - So if you took 1000 people who you could absolutely document don’t have cancer, and 5% of them come back being tested positive, you have a 95% true negative, your specificity is 95%
- What tends to get missed is you still have to know the probability that you have cancer when you get tested
  - And this is important when it comes to understanding what’s called the positive and negative predictive value
  - If your risk of cancer is higher going into the test (e.g., two people go into a test, one person has a 1% chance of having cancer, the other person has a 10% risk of having cancer before you do the test)
  - And you would know that because of differences in their age, their family history, certain genes, maybe modifiable factors such as smoking or metabolic syndrome
  - Well, that test is going to be far more valuable to the person who has a 10% pretest probability

*Costs/downside*

- On the other side of the ledger, you have to consider the costs or the risks
- So the first one we should start with is financial cost
  - Many of these things are being covered out of pocket
  - Fortunately, a lot of them are covered by health insurance once you are within the guidelines, which we’ll also talk about.
  - So if you have to pay out of pocket, you could be paying somewhere between $500 and $600 for a mammogram and you could be spending, on average, $2,700 for a colonoscopy.
  - A low-dose CT scan for the chest, $2,000
  - A whole body MRI, anywhere from $1000 to $5,000
  - A liquid biopsy is about $1000
- Physical risks
  - When it comes to colon cancer and colorectal cancer screening via colonoscopy
  - Within the risk of that, you have the risk of sedation, you have the risk of the bowel prep, you have the risk of bleeding, perforation, infection
- For most cancer screening, what you really want to think about is what are the **psychological** risks?
  - Are you the type of person who is going to be very anxious as you wait for the results of these, or perhaps, more destructively, when you get inconclusive results that require further testing?
- You also want to understand the **blind spots** of a cancer screening test
  - No test is 100% perfect and that includes even colonoscopy, which is one of the few screening tests that can look directly at the pre-cancerous lesion
  - But every cancer screening test can miss something so you need to understand those things and understand what’s your workaround or how do you hedge against that if you want to?

\*See how Peter looks after his colonoscopy on [instagram](https://www.instagram.com/peterattiamd/p/CdJlJb5OFL4/)

## Understanding sensitivity and specificity when reviewing screening results [52:30]

**Analogy to help explain sensitivity and specificity**

(This analogy was also used previously: [metal detector analogy](https://peterattiamd.com/how-to-interpret-screening-tests-video-spreadsheet-and-primer/) and in [AMA #25](https://peterattiamd.com/ama25/))

- Think about how a metal detector at the airport may have a movable sensitivity dial
- So you can make that test so sensitive that it will catch one microscopic particle of metal that’s going through the scanner—that would be a very, very sensitive test
- It would be NOT a very specific test because it’s going to go off on many people that it should not go off on
- The good news with that test is if there are bad guys in the airport and they’re carrying metal, you are absolutely going to catch them
- The problem is you’re going to catch a lot of people who are not bad guys, who shouldn’t be stopped at all in the airport

Let’s just assume that there’s one bad guy in the airport out of 1,000… Are you going to catch him? *Absolutely*

- The problem is if you’ve got that thing dialed so high, you might actually catch 950 good guys too
- Then you might say, “Well, let’s just dial this thing way, way, way, way, way down. I never want to inconvenience anybody. I never want the beeper to go off for someone unless they’re carrying like an AR-15 in the airport.”
- Okay, so the good news is most people will breeze through security. The days of your earrings, your keys, your phone, your watch, belt sending off the security are long gone.
- And if someone happens to have an AR-15, you will catch them
- The problem is what if somebody has a pistol? … They’re still going to get through
- This helps explain the trade-off between sensitivity and specificity. ***They do not exist in isolation***
- As you dial up the sensitivity of a test, you invariably drive down the specificity and vice versa

Cancer screening examples:

- MRI is a very sensitive test with very low specificity
- Same as PSA: high sensitivity, low specificity
- Liquid biopsies are the exact opposite, very low sensitivity but very high specificity

> “You have to know this stuff in advance, so you can make sense of your results and it can help you stack tests.” —Peter Attia

## Risks and complications associated with colonoscopies [55:45]

- Colonoscopies potentially have the most risk for complications (one reason why Peter doesn’t necessarily think getting one every year is appropriate)
- Colonoscopy has more complications than any other form of cancer screening, which is not to say it’s the only thing
- E.g., It’s possible that a mammography could rupture breast implants (though it’s rare)
- Also, something as routine as a pap smear can still result in light bleeding, discomfort, cramping, even at small, but non-zero risk of a yeast infection
- But really, colonoscopy is the one that makes Peter nervous

Possible complications of colonoscopy:

- When it comes to risk of bleeding, it’s just under 15 cases per 10,000—Not a huge number, but it’s not zero.
- Perforation is about three cases per 1,000.
- Death is 3 cases per 100,000
  - Note that, a lot of that is complications that result from complications.
  - So, that can be anywhere along the spectrum from people who are significantly elderly who become very dehydrated from the bowel prep, that leads to kidney failure, or people who are getting a bowel prep who get very dehydrated, who fall and bang their head.
  - This is typically in an older population.
  - But it can be even people who are not particularly sick who might have a significant bleeding event that is not captured or not recognized in time, or a perforation that is not recognized in time. That’s a really big number (3 per 100,000)
  - However, that’s nowhere near as high as the risk of cancer death, but again, that kind of keeps you up at night
- Other types of risks are risks from the sedation itself, so aspirations which could result in a pneumonia or even worse, 17 per 10,000,
- Any sort of infection from the endoscopy itself is about 10 or 11 cases per 10,000.
- So, one interesting point by the way, the [NORDICC trial](https://www.nejm.org/doi/full/10.1056/NEJMoa2208375) didn’t have any perforations in it
  - It had about 13 bleeding cases per 10,000, so that was not far off from the 14.6 number quoted earlier
  - It’s probably the case that they had zero perforations because those patients were scoped while they were awake
  - If you’re awake when you’re getting your colonoscopy, they can be done that way
  - It’s very difficult for the endoscopist to perforate the colon because the person’s going to feel it

## Cancer screening modalities: options for cancer screening both within standard recommendations and beyond [58:30]

![](https://peterattiamd.com/wp-content/uploads/2024/02/f3-ama56.png)

**Figure 3.** Cancer screening modalities. The “big four.”

- Basically, the big four are breast, lung, cervical, and colorectal which are most commonly recommended
- What’s decidedly missing from that in terms of big cancers is prostate
  - Prostate no longer even has an official recommendation from the United States Preventive Services Task Force or the American Cancer Society. The recommendation is to just discuss it with your doctor and make the decision collectively with him or her.
  - About that, Peter says, “*I hope you take the information we’re giving here and you go to your doctor, you say, ‘Here’s how I’m going to make an informed decision. Are you tracking my PSA velocity? Are you tracking my PSA density? Do you even know my prostate volume to make the assumption or the calculation of that?’ That’s how I want people to kind of be advocates*.”

Mammography:

- Broadly speaking with mammography is to start screening at age 40 in women who are of average risk.

Lung cancer screening:

- For low dose CT for lung cancer, it’s to screen people who are basically between 50 and 80, who are either current smokers or who have quit within the past 15 years or who have a 20-pack year history remotely.

Cervical cancer screening…

- For women in their 20s, it’s every three years.
- Women in their 30s to mid 60s, it’s every three years with a pap test as well,
- Or every five if replaced or supplemented with an HPV test.

Colorectal cancer screening

- This has recently been lowered from starting at age 50 and going every 10 years to now starting at age 45 and going every 10 years for those of average risk.

- CT colonography is recommended every five years (Peter doesn’t recommend this test, more on this below)
- And stool-based screening tests are recommended every year (if it’s a FIT test)
- Or every three years, if it’s a Cologuard test.

\*Check out the table above for more info

***Outside of the traditional screening guidelines, what other or newer tests are available for people that don’t maybe have those specific recommendations and guidelines? [1:01:25]***

So what other forms of screening do not have an official recommendation?

- The answer is most everything else
- Liquid biopsies is clearly nowhere near having an official recommendation yet
- Even skin cancer checks by a dermatologist, there is no official recommendation on that
- There is no official recommendation for prostate cancer screening
- There’s no official recommendation on using whole-body MRI, cystoscopy for bladder cancer, pelvic ultrasound for endometrial cancer

“*None of those things have any recommendation one way or the other, and therefore, if they want to do that type of screening, they’re going outside of guidelines, and therefore, they would need a physician who has a reason to believe or understand why that’s necessary*.” says Peter

## The strengths and limitations of various types of cancer screening  [1:02:15]

***What do these tests do well?***

Mammography:

- Mammography is really, really good
- It’s an X-ray, and X-rays are really good at picking up bones or calcification
- So, microcalcifications in the breast are the sweet spot of mammography
- A lot of times these calcifications turn out to be benign, but depending on the pattern, a really good radiologist, and presumably very soon, a really good AI is going to be able to tell if it’s more likely to be cancer than it is not.
- And the larger it is and the denser the calcification is, the better mammography is able to pick it up

Colonoscopy

- really just so good at detecting polyps
- there are two types of polyps
  - There are pedunculated polyps and those are ones that pop out,
  - and then there are sessile polyps that are flat
- With a good bowel prep, both of those are very visible to a good endoscopist, but obviously, the pedunculated polyps are easier to see.

Lung cancer screening via low-dose CT scan

- Low-dose CT scan is really good at detecting all sorts of things in the lung
- certainly more sensitive, better at detecting tumors than a chest X-ray, which used to be the standard

Pap smears

- Pap test, because you’re directly taking test cells from the cervix, is a great way to directly look for cellular abnormalities.

Prostate cancer screening via PSA

- it’s a sensitive test, it just lacks specificity and it’s basically looking at how much PSA is leaking into the bloodstream
- prostate cancers absolutely do leak PSA into the bloodstream, but unfortunately, so do a lot of benign situations of the prostate as well

Whole-body MRI

- A strength of that is that it’s a no-radiation, high-resolution scan to look at the entire body
- It’s very time-consuming compared to a CT scan—at a minimum, about an hour and 10 minutes of laying still
- There are other sequences that can be loaded into whole body such as diffusion-weighted imaging which allows you to better understand the firmness of tissue
- \*Check out [episode #61](https://peterattiamd.com/rajpaulattariwala/) for more on whole-body MRI

Specific MRIs

- There are specific MRIs that are used for body parts
- The two most common are prostate and breast, where a multiparametric MRI combines what we call really good visual anatomy, sequences of the MRI, with a diffusion-weighted image, with a contrast enhancement

Liquid biopsies

- It is a little too soon to say what their sweet spot is, but certainly, biologically their sweet spot is going to be any cell that is shedding cell-free DNA into circulation
- So, the sensitivity of the test is directly related to its ability to capture cell-free DNA
- A tumor that’s not secreting cell-free DNA is not going to be detected by a liquid biopsy
- The million-dollar question is: *Does that tell us about the biology of the cancer*?
  - Should we indeed not be worried about cancers that don’t shed cell-free DNA into the circulation?
  - Are those indeed the cancers that are going to largely stay put and we don’t need to be tracking them immediately?
  - Very early to say that, but those are kind of the questions that we have to ask ourselves.

**Limitations/blind spots of cancer screenings [1:05:45]**

Mammography

- mammography struggles with dense breast tissue. The denser the breast tissue, the more difficult mammography is
- as a woman gets older, mammography tends to become a better test. So, if you consider a woman before menopause and after menopause, her breast tissue is changing, it’s becoming less glandular as she ages and slightly less dense, and therefore, she’s going to have a better chance of mammography finding a tumor as she ages
- nevertheless, in any woman with dense breast tissue, we really always want to have a second modality
  - The go-to is ultrasound, but MRI is becoming more and more popular, especially if insurance is covering it

Colonoscopy

- Depending on the prep, you can miss a sessile polyp
- The ascending colon, which is on the right side, tends to be the most common site, probably just because it’s more difficult to visualize there
- When someone’s going to do a colonoscopy on Peter, he is asking the doctor what HIS numbers are in his patients
  - Okay, how many perforations have your patients had?
  - How many bleeds?
  - How many infections have you had in your patients?
  - What is your cecal intubation rate?
  - What is your typical transit time through the colon?
- Check out Peter’s [post](https://peterattiamd.com/colorectal-cancer-screening/) called: Colorectal cancer screening

Low-dose CT for lungs

- Size is where it’s going to be limited
- Something with an ill-defined margin versus a clear margin, something that’s really close to a blood vessel, those are going to be easier to mis
- It seems to have the highest sensitivity for adenocarcinomas, but less sensitivity for non-adenocarcinomas
- The problem with that, by the way, is if you’re a smoker, you’re very likely to get a non-adenocarcinoma
  - You can also get an adeno, but basically all non-adenos reside pretty much in smokers
  - Whereas most non-smokers, if they get cancer, and 15% of lung cancers are in non-smokers, those tend to be adenos, which paradoxically, this is not a screening modality we recommend for people who are not smokers.

Pap smears

- Pap smears are generally less good at detecting glandular pre-cancerous lesions, and so they can miss really early adenocarcinomas
- Better at a squamous

PSA

- It just has such low specificity
- If you’re only relying on PSA, you’re hosed. You’re going to be basically beeping that alarm at everybody who’s going through it, and you’re not going to know who to stop and who not to stop
- The other point that we should make is men who take 5-alpha-reductase inhibitors, so those are drugs that are like finasteride or dutasteride—many men take this for hair loss—these are going to reduce your PSA by about 50%.
  - The real risk of that is you can miss prostate cancers in these men due to an artificial lowering of their PSA.
  - \*Ted Schaeffer talked about this on [episode #273](https://peterattiamd.com/tedschaeffer2/)

MRI

- MRI really stinks when it comes to glandular tissue
- That’s what accounts for basically the horrible specificity
- It just struggles so much to look at the thyroid gland and know if that’s just a benign nodule or if it’s a cancer
- so, that’s where you get all these false positives coming up

## Understanding positive and negative predictive value using sensitivity, specificity, and pretest probability [1:11:45]

***Based on all this, if people are getting screened and then they’re getting results, whether positive or negative, how should they think about the results when they see it?***

- The only things that really matter is how do you assimilate the sensitivity, specificity and pretest probability into what matters? … And that’s the **positive and negative predictive value**
- positive predictive value is what you want to know
- If you have a positive test, what’s the chance that you actually have cancer?
- If you have a positive predictive value of 90% and the test comes back positive, well, you pay attention
- If the test has a positive predictive value of 5% and you test positive, okay, there’s a one in 20 chance you have cancer, but there’s a 19 in 20 chance you don’t
- And similarly, negative predictive value says if the test comes back negative, how confident are you in that negative result?
- you can’t calculate PPV and NPV without knowing the pretest probability
- the easiest way to do that is to know the prevalence of cancer in your age group, and then think about, just broadly, how would you adjust that up or down based on characteristics of yourself
- Broadly speaking, cancer prevalence is:
  - In ages 40-49: 2.1%,
  - Ages 50-59: 4.8%,
  - Ages 60-69: 9.5%
  - Ages 70-79: 15.9%
- So, you can use that as your starting pre-test probability, and then you can adjust that up or down based on other factors.

## Factors that influence an individual’s pretest probability of cancer [1:13:45]

The two most modifiable risk factors that factor into your risk of cancer

- Smoking is #1
- Metabolic syndrome/obesity is #2

Smoking:

- When you talk about smoking cigarettes, that’s increasing your risk of lung cancer 15 to 30 times more than someone who doesn’t smoke
- It’s also the only cancer for where a screening intervention is likely to not just impact your death from that cancer, but the overall length of your life

MetSyn

- If you have metabolic syndrome, you have a relative:
  - 58% increase in liver cancer
  - 25% increase in colorectal cancer (in women it is higher at a 34% increase)
  - 10% increase in bladder cancer in men
  - 61% increase in endometrial cancer (in women)
  - 58% increase in pancreatic cancer
  - 56% increase in breast cancer (in postmenopausal women)
  - 52% increase in rectal cancer
- Let’s just say your demographic puts you at a 4% prevalence of cancer. You can see that having metabolic syndrome might increase that from 4% to 6% as your pretest probability, if you would assume from that, that your increase in your risk of cancer is 50% higher.

Genetics

- The BRCA mutations basically increase your likelihood of developing breast cancer to somewhere between 50 and 80%
- So if the probability of breast cancer in the general population is 12% for your demographic, you might have to increase your probability significantly,
- This is why, for obvious reasons, women who are identified as having BRCA mutations are screened much more aggressively
- Frankly, you can then assume that you’re going to be stacking modalities as well (later we will talk about why that makes your positive and negative predictive values better)

A few other factors that are going to increase your pretest probability would be:

- Do you have a previous history of cancer? ⇒ if a person has colon cancer or breast cancer, the risk of a subsequent cancer is significantly higher
- Do you have exposure to a known carcinogen?
  - Asbestos is obviously well-documented in terms of its increase in the risk of lung cancer, mesothelioma, but also laryngeal cancer and ovarian cancer
  - Radon, by the way, probably the second leading cause of lung cancer and alcohol, arsenic
- Excessive alcohol consumption can also increase cancer risk

## How to interpret cancer screening results [1:18:15]

This table below is organized as if there are 100 cases per 10,000 people, so **1% prevalence** (average risk population)

![](https://peterattiamd.com/wp-content/uploads/2024/02/f4-ama56.png)

**Figure 4.**

**Mammography**

What if we are using mammography in a woman who has normal breasts?

- The sensitivity here is probably about 75%
- The specificity is quite high here, about 97 to 99%
- So you’re going to get a lot more **false positives** than false negatives
- Your positive predictive value is about 20%
- That means that if you have a mammography that’s getting flagged as being likely for breast cancer, there’s only a 1 in 5 chance you actually will have breast cancer
- In many cases, this might go to a subsequent test, such as an ultrasound or an MRI, or it might go to a needle biopsy to make that determination
- But your negative predictive value here is very high—99.7%
- To keep this in perspective, what was your probability of being negative before the test? ⇒ it was 99%, because your probability of having cancer is 1%
- This basically increased your NPV from a guess of 99% up to 99.7%
- So it’s very important to understand why NPV is very big in a low prevalence population, because you’re judging it relative to starting at, in this case, 99%.

Now let’s do the same exercise for mammography in women with *dense* breasts (remember, mammography is not as good if your breasts are dense)

- Well, your sensitivity comes down, but your specificity stays high, so it turns out your positive predictive value is only slightly less than before
- It goes down to maybe 19%, but your NPV also comes down (you’ve only improved from 99% to 99.5%)

**MRI**

- MRI has a very high sensitivity, 96%, but the specificity is very low.
- It’s actually quite difficult to find really good numbers for this, but Peter thinks 40% specificity is not an unreasonably low estimate
- Now let’s look at what this does as far as your negative predictive value
- With that very, very high sensitivity, your negative predictive value is 99.9%
- So if that test comes back negative, you do not have cancer
- But if that test comes back positive, you can relax as there’s only a 1.6% chance you actually have cancer
- In other words, it’s barely better than if you didn’t have the scan, because if you didn’t have the scan, there’s a 1% chance and now it takes you to 1.6%

Using the table below, let’s now contrast the above with a higher risk population where the pretest **probability is 5%**

![](https://peterattiamd.com/wp-content/uploads/2024/02/f5-ama56.png)

**Figure 5.**

- Now that same group of low or normal density breast tissue, the positive predictive value goes from 20% up to 57%
  - Now, because your pretest probability was higher, you have more reason to believe that there’s a positive
  - The negative predictive value comes down a little bit, but again, we’re now judging it versus a 95%, which is the guess going in, because it’s a 5% prevalence. So it goes from 95% up to 98.7%
- Conversely, if you look at mammo with dense breast tissue, you also see a huge improvement—it also basically brings it up to the same place of 54.8%
  - Mammography still really quite low in positive predictive value because that specificity is so low and you’re still in a relatively modest prevalence environment, your positive predictive value is only 7.8%

Note from Peter:

- He is a big advocate of whole-body MRI with diffusion weighted imaging
- However, he warns patients that there’s a really good chance you’re going to come out with a false positive of some sort, and if that is not going to be comfortable for you, which is totally understandable, we shouldn’t do this test

## The importance of having an advocate when considering out-of-guideline cancer screening tests [1:23:30]

- Some of these tests, whole body MRI being one of them, are a lot easier to acquire without a medical professional, meaning you don’t need to convince a doctor to write you a prescription. You can find places that will just set up an appointment, do these, you get the results
- There’s a lot of good that comes with that, but then there’s a lot of things that people need to be aware of and need to think through, and one of them, as you mentioned, was the need for an advocate

*If people are going to think about doing this stuff out of pocket, out of guideline, why is it so important to have an advocate and why is it something they need to really think about before they do it?*

- The real problem here is that these screening tests have really, really good negative predictive value, which is good
- If you get a negative test, you can be confident that you don’t have cancer, provided you understand the blind spots
- The issue is much less that you’re going to miss a cancer and much more that you’re going to catch something that’s not a cancer
- “***I just can’t overstate that you do not want to go through this process without a person, a physician, who is your advocate to help you correctly interpret the results***.”
- The advocate cannot be the person who works at the screening facility
- You have to have someone in your corner who knows you before and will know you after, and who is going to help you go through the system in doing this

[**Meta analysis**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7216394/) of patients who went in for whole body MRI screening in an asymptomatic population:

- 6,214 people went for routine whole body MRI exams
- They found nearly 18,000 abnormal findings on the MRIs (approx. three abnormal findings per person)
- 91% of 18,000 findings turned out to be noise
- But 9% of those 18,000 required further investigation
- Ultimately, 0.5%, or 112 cases, turned out to be suspicious enough for cancer that they required a biopsy or further imaging in which cases, nearly half of those were confirmed cancer
- So again, there’s a rationale for doing this, but it comes at a cost.
- \*NOTE: Peter advocates for a MRI with better software/hardware than the one used in this study where the numbers wouldn’t be as bad as will be revealed in this study

## How stacking multiple cancer screening modalities can decrease the risk of false positives [1:29:30]

*How does stacking multiple modalities then decrease that risk of false positives?*

Two ways to stack a test:

- You can stack using what we call the “OR rule” or the “AND rule”
- The “OR rule” says,  I have two tests, I’m going to run them, and if one or both of them are positive, then I have cancer
- The “AND rule” says, both of these must be positive for me to believe I have cancer

Few diagnostic tests are both highly sensitive and highly specific. For this reason, patients sometimes are diagnosed using two or more tests. These tests may be performed either in parallel (i.e., at the same time and interpreted together) or in series (i.e., the results of the first test determine whether the second test is performed at all)

- The math of combined sensitivity/specificity depends on how a positive/negative diagnosis is made
- Under “the OR rule,” a positive diagnosis is made if either of the two tests is positive, and a negative diagnosis if both tests are negative.
  - Overall sensitivity: (A)sen + (B)sen – (A)sen x (B)sen
  - Overall specificity: (A)spec x (B)spec
- Under “the AND rule,” yields a positive diagnosis only if both tests are positive and a negative diagnosis if either test is negative.
  - Overall sensitivity:  (A)sen x (B)sen
  - Overall specificity: (A)spec + (B)spec – (A)spec x (B)spec
- The math of combined sensitivity & specificity is the same whether tests are done serially or in parallel.
  - What changes is whether or not the second test is performed based on which logic is being used (“or” or “and”)
  - If done in parallel both tests will always be performed, but if done serially and the “and” logic is required to make a positive diagnosis:
    - If the first test is negative, then the second test will not be performed
    - Additionally, if there is a highly suspicious lesion on the first test, the pre-test probability goes up for the second test

One of the ways Peter likes to do this is to actually look at, say, a whole body MRI and liquid biopsy and say, “okay, will we consider it positive if and only if both of these are positive? What if one’s positive, one’s negative, etc.?”

> “We’re never really doing one test by itself. We’re always kind of stacking tests on top of each other, trying to make sure that there’s no place in all the Swiss cheeses where a pencil can go down.” —Peter Attia

## Advice and guidance for making decisions related to cancer screening [1:31:15]

People should start with the obvious question: *What’s your personal risk of cancer?*

- Is it high or low?
- Again, you’re going to go through your age, genetics, family history, modifiable factors, any other known risk factors, and really get a sense of what’s the probability you have cancer right now
- Therefore, what tests do you have at your disposal that will take you from a probability to a certainty
- So that gets into the whole screening discussion

From there, you can consider the financial and emotional costs

- What is your appetite for the financial costs associated with screening?
- More importantly, the emotional costs?
- Do you have it within your constitution to deal with the highs and lows, namely the lows that would come from a positive screen that turns out to not be cancer, but puts you through the ringer to figure that out?

Physical risks:

- Do you have an appetite for the risk, and do you feel that you can make your way to a good endoscopist for whom you are comfortable with their track record, both in terms of everything from sedation all the way to procedure?

Think about: *what would you even do with the information?*

- As you age, you also have to ask the question, what would you do if you found a cancer?
- Because there’s a certain point in a person’s life where they might say, “I’m not going to do anything about it anyway”
- If a person is old enough, they might not have an appetite physically to go through the treatment, be it surgical, chemo, radiation, etc.

The final point: Advocacy

- Do you have an advocate on this journey with you?
- Do you have a physician who is able to guide you through this process in a way that is nuanced?

§

## Selected Links / Related Material

**Episode of The Drive about breast cancer and explains the differences between HER2+ and HER2-, estrogen receptor positive (ER+) and negative (ER-), and triple negative (TNBC)**: [#278 ‒ Breast cancer: how to catch, treat, and survive breast cancer | Harold Burstein, M.D., Ph.D.](https://peterattiamd.com/haroldburstein/) | Peter Attia (peterattiamd.com) [14:00]

**Study showing a benefit to cancer screening in terms of lowering breast cancer mortality**: [Periodic screening for breast cancer: the HIP Randomized Controlled Trial. Health Insurance Plan](https://pubmed.ncbi.nlm.nih.gov/9709271/) (Shapiro 1997) [18:30]

**Compelling data that mammography reduces breast cancer**: [The Swedish two county trial of mammographic screening for breast cancer: recent results and calculation of benefit](https://pubmed.ncbi.nlm.nih.gov/2512366/) (Tabar et al., 1989) [19:15]

**An article about the badly done study showing no benefit of cancer screening for reducing breast cancer**: [The randomized trial of mammography screening that was not—A cautionary tale](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8892036/) (Yaffe et al., 2022) [21:15]

**Study showing benefit of cancer screening for reducing lung cancer mortality AND all-cause mortality**: [Mortality, survival and incidence rates in the ITALUNG randomised lung cancer screening trial](https://thorax.bmj.com/content/72/9/825.abstract) (Paci et al., 2016) [29:30]

**NORDICC trial on colonoscopy**: [Effect of Colonoscopy Screening on Risks of Colorectal Cancer and Related Death](https://www.nejm.org/doi/full/10.1056/NEJMoa2208375) (Bretthauer et al., 2022) [33:30]

**For more on interpreting studies, check out**: [41:30]

- [#188 – AMA #30: How to Read and Understand Scientific Studies](https://peterattiamd.com/ama30/) | Peter Attia (peterattiamd.com)
- [Studying Studies: Part I – relative risk vs. absolute risk](https://peterattiamd.com/ns001/) | Peter Attia (peterattiamd.com)
- [#197 – The science of obesity & how to improve nutritional epidemiology | David Allison, Ph.D.](https://peterattiamd.com/davidallison/) | Peter Attia (peterattiamd.com)

**Peter’s instagram post of himself after his colonoscopy**: [@peterattiamd](https://www.instagram.com/peterattiamd/p/CdJlJb5OFL4/) | (instagram.com) [51:45]

**Episode of The Drive about whole-body MRI with diffusion-weighted imaging**: [#61 – Rajpaul Attariwala, M.D., Ph.D.: Cancer screening with full-body MRI scans and a seminar on the field of radiology](https://peterattiamd.com/rajpaulattariwala/) | Peter Attia (peterattiamd.com) [1:04:00]

**Peter’s post about colorectal cancer screening**: [Colorectal cancer screening](https://peterattiamd.com/colorectal-cancer-screening/) | Peter Attia (peterattiamd.com) [1:07:00]

**Episode of The Drive with Ted Schaeffer talks PSA and prostate cancer**: [#273 ‒ Prostate health: common problems, cancer prevention, screening, treatment, and more | Ted Schaeffer, M.D., Ph.D.](https://peterattiamd.com/tedschaeffer2/) | Peter Attia (peterattiamd.com) [1:10:45]

**Meta analysis of patients who went in for whole body MRI screening in an asymptomatic population**: [Whole-body magnetic resonance imaging (WB-MRI) for cancer screening in asymptomatic subjects of the general population: review and recommendations](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7216394/) (Cancer Imaging. 2020) [1:25:15]

§

## People Mentioned

- [David Allison](https://publichealth.indiana.edu/research/faculty-directory/profile.html?user=allison) [41:30]
- [Ted Schaeffer](https://www.nm.org/doctors/1821134883/edward-m-schaeffer-md-phd) [1:10:45]

§