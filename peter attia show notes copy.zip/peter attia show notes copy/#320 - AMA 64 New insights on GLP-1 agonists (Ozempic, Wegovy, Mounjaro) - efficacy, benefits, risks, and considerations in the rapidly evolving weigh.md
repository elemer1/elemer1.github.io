# #320 – AMA 64: New insights on GLP-1 agonists (Ozempic, Wegovy, Mounjaro) – efficacy, benefits, risks, and considerations in the rapidly evolving weight-loss drug landscape

**Source:** [https://peterattiamd.com/ama64/](https://peterattiamd.com/ama64/)

---

In this “Ask Me Anything” (AMA) episode, Peter dives back into the increasingly popular topic of GLP-1 agonists, such as Ozempic and Mounjaro, which have garnered widespread attention for their ability to promote weight loss. Peter covers the latest findings in this rapidly evolving landscape, including new insights into their long-term efficacy, side effects, and what happens when the drug is discontinued. Peter also explores their impact on body composition and how resistance training interacts with these treatments. Additionally, he compares different GLP-1 receptor agonists and discusses promising new drugs in the pipeline. Finally, Peter addresses questions about the role of compounding pharmacies in the GLP-1 agonist market, compares oral vs. injectable options, and provides key considerations for anyone deciding whether to use a GLP-1 agonist for weight loss.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #64 show notes page](https://peterattiamd.com/ama64). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- The rapidly evolving landscape of GLP-1 agonists [2:15];
- The mechanism of GLP-1 agonists, their origin as diabetes treatments, and how they evolved into weight-loss drugs [6:45];
- Overview of the new data and open questions related to the benefits and risks of GLP-1 agonists [10:30];
- New insights into the long-term safety of GLP-1 agonists, side effects, and more [16:45];
- The long-term efficacy of GLP-1 agonists, financial barriers, and more [19:45];
- The mechanisms behind GLP-1 agonists’ ability to promote weight loss [22:00];
- New data on body weight changes after discontinuing the drug [26:00];
- Effects of GLP-1 agonists on lean mass and body composition, and the role of protein and resistance training in preserving muscle [31:30];
- Semaglutide vs. tirzepatide: comparing benefits and side effects [36:30];
- How compounding pharmacies affect availability of GLP-1 drugs and the types of formulations that are available [39:15];
- How do oral formulations of GLP-1 drugs compare to injectable formulations? [44:15];
- How do sublingual (under tongue) formulations of GLP-1 drugs compare to injectable formulations? [46:15];
- Guidance for using compounding pharmacies to purchase GLP-1 agonists [47:15];
- Data on retatrutide—a promising new triple receptor agonist in the pipeline [50:15];
- Can GLP-1 agonists be beneficial for sleep apnea and immune function? [57:00];
- Potential neuroprotective benefits of GLP-1 agonists: impact on dementia risk [1:00:45];
- Exploring why GLP-1 agonists may reduce the risk of cancer, kidney disease, and cardiovascular disease [1:04:00];
- How GLP-1 agonists might boost fertility in women [1:10:15];
- Early indications that GLP-1 agonists may help treat substance abuse disorders [1:12:00];
- Potential health risks of GLP-1 agonists: addressing thyroid cancer concerns and the unknowns due to lack of data [1:14:00];
- Examining the potential link between GLP-1 agonists and increased depression or suicidal ideation [1:16:00];
- Major remaining questions: the effects of cyclic use, rebound appetite, impact on adolescents’ development, and more [1:19:30];
- Key considerations when deciding whether to use a GLP-1 agonist for weight loss [1:23:45]; and
- More.

§

The Peter Attia Drive

New insights on GLP-1 agonists (Ozempic, Wegovy, Mounjaro)

§

## Show Notes

§

Previous episodes on GLP-1 agonists:

- [AMA #29](https://peterattiamd.com/ama29/)
- [AMA #45](https://peterattiamd.com/ama45/)
- [Episode #314 with David Allison](https://peterattiamd.com/davidallison2/)

## The rapidly evolving landscape of GLP-1 agonists [2:15]

**Episode overview**

- Typically, podcast episodes are recorded 10 to 12 weeks before release.
- This episode is an exception, being released ahead of schedule due to the rapidly evolving topic of GLP-1 agonists (e.g., Ozempic, tirzepatide).
- Peter first discussed GLP-1 agonists in November 2021 in a [previous episode](https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/).
- Did a follow-up [episode](https://peterattiamd.com/ama45/) in March 2023.
- The topic has gained massive interest and has seen significant developments over time.

**Growing Popularity**:

- When first discussed, GLP-1 agonists seemed overly technical and not widely known.
- Now, GLP-1 agonists are everywhere in the media, reflecting their growing prominence and relevance.

**Key Focus Areas of the Episode**:

- How the drugs work: A brief recap of their mechanisms, although more detailed discussions are available in previous AMAs.
- Differences between the drugs: Exploring how different GLP-1 agonists compare.
- Compounded injections: Discussing alternative formulations like compounded versions of these drugs.
- Weight regain: Examining what is known about weight regain after stopping the medication.
- Safety profiles: Updating listeners on the safety concerns and new findings.
- Changed perspectives: Host mentions that the ongoing conversations and growing data have caused him to revise his views on certain aspects.

Peter’s Perspective on GLP-1 Agonists

- Peter reflects on how much the understanding of GLP-1 agonists has evolved.
- He acknowledges that some of his earlier views have changed based on new evidence.

Long History of the Drug Class:

- Liraglutide: First prescribed by Peter in 2014, it was not very effective for most patients.
- Semaglutide: In fall 2020, Peter began prescribing semaglutide, which was a much different and more effective experience than liraglutide, even before semaglutide was approved for obesity.

The focus in this episode is more on what is newly known and relevant rather than repeating older, well-established information.

**Knowledge Gaps and Evolving Understanding**

- Changes in Understanding:
  - The field of GLP-1 agonists is continuously advancing, and Peter stresses that while they know much more now than before, there are still things left to learn.
  - Peter highlights the importance of acknowledging the unknowns and remaining open to new information.
- Caution with Early Drug Generations:
  - Earlier drugs like liraglutide did not have the same efficacy, highlighting how far the field has come with newer drugs like semaglutide.

GLP-1 Agonists’ Growing Importance:

- Once a niche and technical topic, GLP-1 agonists are now widely recognized and are expected to have a transformative impact on obesity and diabetes treatment.
- As research and data continue to emerge, the understanding of these drugs and their use cases will likely evolve, with more to cover in future episodes.

Focus of Upcoming Discussion

- The episode will dive into the new data on weight loss, differences between drugs, and how to approach these medications in light of new information.

## The mechanism of GLP-1 agonists, their origin as diabetes treatments, and how they evolved into weight-loss drugs [6:45]

**Overview of GLP-1 Agonists’ Origins and Role in Diabetes Management**

Initial Development:

- GLP-1 agonists were initially developed to manage Type 2 diabetes.
- These drugs mimic the hormone GLP-1 (glucagon-like peptide-1), which helps stimulate insulin release from the pancreas.
- This stimulation is vital for patients with Type 2 diabetes, as their pancreas is not producing enough insulin. Type 2 diabetes is largely managed through increasing insulin release and improving insulin sensitivity, which helps glucose enter the liver and muscles more effectively.

Why GLP-1 Agonists Became a Hot Topic:

- GLP-1 agonists were primarily seen as tools to lower blood sugar and hemoglobin A1c in diabetic patients.
- Semaglutide vs. Liraglutide:
  - Semaglutide’s key breakthrough was its ability to dramatically reduce patients’ weight, something that liraglutide did not accomplish as effectively.
  - This unexpected benefit led to a new question: Can these drugs be used as weight-loss medications for non-diabetic patients?
  - [Clinical trials](https://peterattiamd.com/ama29-glp1-agonists-the-future-of-treating-obesity/) conducted around three years ago answered this question with a resounding yes, marking a significant development in the perception of these drugs.

**Quick Summary of How GLP-1 Agonists Work**

Key Mechanisms:

- Pancreas:
  - Stimulates insulin secretion and reduces glucagon secretion, leading to lower blood sugar levels.
  - Jejunum and Ileum (Small Intestine):
  - Slows gastric emptying and reduces GI motility, which prolongs the feeling of fullness and slows glucose absorption.
- Liver:
  - Reduces hepatic glucose production, similar to how Metformin works.
- Brain:
  - Activates satiety signals and inhibits appetite-driving circuits, which plays a significant role in weight loss.
  - Early research underestimated how much this central regulation of appetite contributed to weight loss.
- GLP-1 Agonists’ Effects on Fat and Muscle Tissue
  - Fat Tissue:
    - GLP-1 agonists increase glucose uptake from the blood and boost lipolysis (the breakdown of fat), which helps burn fat while improving insulin sensitivity.
    - Though it may seem counterintuitive, the drugs do not make fat cells “fatter” but rather enhance the overall metabolic processing of fat.
  - Muscle Tissue:
    - Increases the muscles’ ability to oxidize glucose, further aiding in blood sugar control and energy use.

![](https://peterattiamd.com/wp-content/uploads/2024/10/f1-ama64-1024x717.png)

**Figure 1.** Source: [Saraiva and, Sposito Cardiovasc Diabetol. Oct 2014.](https://cardiab.biomedcentral.com/articles/10.1186/s12933-014-0142-7)

Peter briefly mentions that GLP-1 agonists likely have significant effects on the heart and kidneys, which will be discussed in more detail later in the podcast. These areas are considered topics of immense interest due to their potential broader health benefits.

## Overview of the new data and open questions related to the benefits and risks of GLP-1 agonists [10:30]

**Overview of Progress in GLP-1 Agonists Over 19 Months**

- Evolution of Knowledge Since Last Discussion:
- The last in-depth [discussion on GLP-1 agonists](https://peterattiamd.com/ama45/) was 19 months ago, with many unknowns at that time due to the newness of these drugs.
- The conversation was primarily about two drugs:
  - Semaglutide (Ozempic/Wegovy): Initially approved for Type 2 diabetes, later rebranded for obesity (Wegovy).
  - Tirzepatide (Mounjaro/Zepbound): A more potent drug that acts on both GLP-1 and GIP receptors. Mounjaro is for diabetes, while Zepbound is the obesity counterpart.
- Since then, there has been more clarity about how these drugs work, their safety, and additional benefits.

**New Data and Insights**

- Post-Approval Surveillance:
  - With more people taking these drugs, there is now more safety data available.
  - Ongoing phase 4 trials are crucial to monitor any long-term issues that may not have surfaced in the initial smaller phase 3 trials.
- Extended Benefits & Effectiveness Over Time:
  - There’s growing data on whether patients might develop resistance to the drug’s effects, and whether weight loss is sustained long-term.
  - Studies show no immediate evidence of weight rebound while the drug is still in use, but more research is ongoing.

**Mechanisms Behind Weight Loss**

- Mechanistic Studies:
  - There’s a better understanding now of how these drugs promote weight loss.
  - A critical unknown during the last discussion was the impact of body composition, specifically fat versus lean mass loss. Now, with DEXA scans, there is more precise data on this.
- Role of Exercise:
  - New data highlights the importance of exercise in not only supporting weight loss but also in maintaining muscle mass, which was previously unclear.

**Differences Between Semaglutide and Tirzepatide**

- Semaglutide vs. Tirzepatide:
  - Detailed comparison of the weight loss effects of both drugs is now available.
  - Tirzepatide appears more potent in terms of weight loss due to its dual action on GLP-1 and GIP.

**The Rise of Compounding Pharmacies**

- Increased Use of Compounding Pharmacies:
  - The growing use of compounding pharmacies to produce these drugs has increased, potentially offering cheaper alternatives but with some risks.
  - Importance of understanding the pros and cons of compounded formulations and ensuring safety and quality from reputable sources.
- (See [AMA #52](https://peterattiamd.com/ama52/) for more on compounding pharmacies)

Exploring Other Health Benefits

- Potential Broader Health Impacts:
  - Beyond weight loss and glycemic control, GLP-1 agonists are being discussed for their possible role in other health conditions, such as:
    - Reducing sleep apnea
    - Dementia prevention
    - Treating addictions/addictive behaviors
    - Enhancing immune function and cardiovascular health
  - The key question is whether these drugs offer benefits beyond the weight loss and metabolic improvements, or if these effects are tied directly to weight reduction and improved glucose control.

Suicidal Ideation Concerns

- Risk of Suicidal Ideation:
  - Recently, concerns have been raised about these drugs potentially increasing depression or suicidal thoughts.
  - The current evidence, including a [2024 review](https://www.sciencedirect.com/science/article/pii/S0924977X24001573), does not strongly support these claims, but more research is needed to rule out risks for certain individuals.

## New insights into the long-term safety of GLP-1 agonists, side effects, and more [16:45]

**Long-Term Safety of GLP-1 Agonists**

Historical Concerns:

- Liraglutide: Has been in use for over 10 years with no significant safety issues but is considered less potent compared to newer drugs like semaglutide.
- Semaglutide Approval: When semaglutide was first approved, there were theoretical concerns based on animal studies, particularly about an increased risk of thyroid cancer.
  - However, no substantial follow-up evidence has confirmed these concerns.

Current Safety Data:

- Absence of Major Toxicities: Given the widespread use of semaglutide, there have not been any significant or widespread reports of serious or life-threatening side effects, unlike historical cases with drugs like [fen-phen](https://en.wikipedia.org/wiki/Fenfluramine/phentermine) in the 1990s that caused fatal pulmonary hypertension.
- Life-Threatening Side Effects Are Rare: While serious side effects appear to be rare, common side effects remain, particularly gastrointestinal issues.

Common Side Effects:

- GI-related Side Effects: Many patients experience nausea, diarrhea, and paradoxical constipation, though these are usually transient.
  - About half of the patients taking GLP-1 agonists will deal with these side effects at least temporarily.
- Dose Titration: Gradually increasing the dose over 16 weeks, as done in clinical trials, helps mitigate these side effects.
  - The slower the increase, the fewer side effects tend to be experienced.

Contextual Safety:

- Risk vs. Benefit: It’s important to view the safety of these drugs relative to the alternative health risks they address.
  - For example, the side effects must be weighed against the benefits of reducing significant body weight and improving metabolic health.
- Comparative Analysis: The question is not just whether the drug is safe in isolation but whether its risks outweigh the dangers of remaining overweight or having poor metabolic control (e.g., elevated hemoglobin A1c levels).

## The long-term efficacy of GLP-1 agonists, financial barriers, and more [19:45]

**Long-Term Efficacy of GLP-1 Agonists**

- Previous Data:
  - Semaglutide: Initial studies of semaglutide followed patients for up to 24 months and showed sustained weight loss with no significant weight regain at that point.
  - Tirzepatide: Early data on tirzepatide followed patients for up to 12 months and also demonstrated continued weight loss.
    - At that time, it was unclear whether weight loss had reached its lowest point (nadir) since the data was relatively short-term.
- Updated Data on Semaglutide:
  - Four-Year Follow-Up: More [recent data](https://www.nature.com/articles/s41591-024-02996-7) includes four years of follow-up on semaglutide, showing that weight loss remains stable over this period, provided patients continue using the drug.

![](https://peterattiamd.com/wp-content/uploads/2024/10/f2-ama64-1024x678.png)

**Figure 2.** Source: [Ryan et al. Nat Med. Jul 2024.](https://www.nature.com/articles/s41591-024-02996-7)

- Future Data: Peter suggests checking the six-year data in the future to confirm longer-term effects, but as of now, weight loss appears to be sustained over four years without significant rebound.

Discontinuation Issues:

- Cost as a Major Factor: [Between 25% and 35% of patients who start on these drugs eventually discontinue them](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2819256?utm_source=silverchair&utm_medium=email&utm_campaign=article_alert-jamanetworkopen&utm_term=mostread&utm_content=olf-widget_06142024&adv=).
  - Interestingly, the primary reason for discontinuation is not side effects but out-of-pocket cost.
- High Cost: These drugs are expensive, with out-of-pocket costs averaging around $1,000 per month for those using them for weight loss without insurance coverage. This makes it challenging for many patients to continue long-term.
- Weight Regain: Patients who stop the drug due to cost or other reasons often experience weight regain.
  - Peter mentions that patients might regain much or all of the lost weight after discontinuing the drug.

Cost Comparison:

- Relative to Other Expensive Drugs: For context, the monthly cost of GLP-1 agonists is higher than other expensive drugs like PCSK9 inhibitors, which cost around $500 per month.

## The mechanisms behind GLP-1 agonists’ ability to promote weight loss [22:00]

**Mechanisms of Weight Loss with GLP-1 Agonists**

- Initial Skepticism:
  - Peter initially became interested in these drugs again in 2020 after being unimpressed by liraglutide in 2014.
  - His initial theory was that the primary benefit of these drugs might come from improving metabolic health, especially by increasing insulin sensitivity.
  - He hypothesized that as people became more insulin sensitive, their bodies could partition fuel more efficiently, leading to reduced appetite and less need for food.
- Appetite Control and Brain Mechanisms:
  - Key Discovery: [Studies in mice](https://www.jci.org/articles/view/72434) lacking GLP-1 receptors in the brain showed that these mice did not lose weight when taking liraglutide but still experienced glucose-lowering effects.
    - This finding suggests that appetite regulation in the brain plays a crucial role in the weight loss seen with these drugs.
  - Appetite can be driven by a couple of things:
    - 1) Homeostatic Hunger: Driven by a caloric deficit and depletion of energy stores.
    - 2) Hedonic Hunger: Driven by the pleasure and reward sensations of eating energy-dense, palatable foods.
  - GLP-1 receptor agonists affect both hunger pathways by:
    - Activating satiety signaling, making people feel fuller.
    - Inhibiting the pro-feeding, reward-driven signals that trigger overeating.
- Role of the Blood-Brain Barrier:
  - Interestingly, GLP-1 receptor agonists do not cross the blood-brain barrier.
  - Despite this, they still act on brain regions located outside of the blood-brain barrier and relay signals to areas responsible for appetite regulation.
  - This phenomenon is similar to the effect seen with other molecules, like Klotho, which impact brain functions without directly crossing into the brain.
- Side Effects and Aversions:
  - Recent Research: There is a distinct population of GLP-1 receptor neurons that drive aversion, which may not contribute to weight loss but are linked to the nausea that is a common side effect of these drugs.
  - This research opens the door for pharmaceutical companies to develop “cleaner” versions of these drugs that target the appetitive centers more precisely, potentially reducing the gastrointestinal (GI) side effects while maintaining efficacy.

## New data on body weight changes after discontinuing the drug [26:00]

**Effects of Discontinuing GLP-1 Agonists (Semaglutide, Tirzepatide)**

- Weight Regain After Discontinuation:
  - In the previous AMA on GLP-1 agonists, Peter discussed earlier [studies](https://www.nejm.org/doi/10.1056/NEJMoa2032183) on semaglutide cessation at 52 weeks. These studies showed that participants regained about two-thirds of their lost body weight after stopping the drug.
  - At the time, it was unclear whether the weight regain would continue or plateau, as the weight regain curves had not fully stabilized.
  - A more recent [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10550307/) on tirzepatide with a two-year follow-up showed that most participants regained the weight they had lost after stopping the drug, regardless of the dose they had been on.
    - Even patients who had lost significant weight on higher doses of tirzepatide regained much of their weight after stopping, within about 2 to 4 kilograms of their baseline weight.

![](https://peterattiamd.com/wp-content/uploads/2024/10/f3-ama64-1024x528.png)

**Figure 3.** Source: [Kubota et al. Cureus. Oct 2023.](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10550307/)

“*It’s safe to say that whether you’re talking about semaglutide or whether you’re talking about tirzepatide, for most people, when you stop the drug, you will likely regain much of the weight*.” says Peter

**Caveat: This is some variability in patient responses:**

- Despite the general trend of weight regain, Peter has personally seen a number of patients that have lost 20-25 lbs (i.e., they weren’t obese to start with) and were able to only regain 5-10 lbs
- These are patients who tapered off the drug and were able to maintain most of their weight loss.
- These patients remained in a caloric deficit, which might explain why they didn’t regain all the weight after discontinuing the drug.

Role of Exercise in Weight Maintenance:

- Peter speculated that exercise could explain why some patients are better able to maintain their weight after stopping GLP-1 agonists.
- Weight loss is primarily driven by diet, but exercise plays a critical role in weight maintenance after weight loss, especially post-exercise.
- He referenced a [study](https://www.thelancet.com/journals/eclinm/article/PIIS2589-5370(24)00054-3/fulltext) that looked at liraglutide and exercise:
  - In this study, subjects who combined exercise and liraglutide lost the most weight and regained it the slowest compared to other groups.
  - Even though all groups regained weight after discontinuing treatment, the exercise-plus-liraglutide group had better weight maintenance outcomes.

![](https://peterattiamd.com/wp-content/uploads/2024/10/f4-ama64-1024x702.png)

**Figure 4.** Source: [Jensen et al. EClinicalMedicine. Feb 2024.](https://www.thelancet.com/journals/eclinm/article/PIIS2589-5370(24)00054-3/fulltext)

- Study Limitations and Future Directions:
  - Peter emphasized that liraglutide is a less potent weight loss drug compared to semaglutide and tirzepatide.
  - He expressed interest in seeing similar studies conducted with tirzepatide or semaglutide to provide better insights into how exercise may affect weight maintenance post-drug discontinuation.

In conclusion, while most patients regain weight after stopping GLP-1 agonists, individual factors like exercise and maintaining a caloric deficit might allow for better long-term weight maintenance in certain cases. However, more research is needed, particularly with newer and more potent drugs like tirzepatide and semaglutide.

## Effects of GLP-1 agonists on lean mass and body composition, and the role of protein and resistance training in preserving muscle [31:30]

**Concerns About Muscle Mass Loss while taking these drugs**

- Peter’s initial concerns focused on the potential loss of lean mass (muscle) when patients lose weight on GLP-1 receptor agonists.
- He mentioned that in earlier discussions, there was concern that patients were losing not only fat but also a significant amount of muscle.
  - Anecdotally, he observed in patients that weight loss with these drugs could be 50% fat and 50% lean mass loss, which is suboptimal, particularly for people who want to maintain muscle.

Updated Data on Body Composition

- New [studies](https://dom-pubs.onlinelibrary.wiley.com/doi/full/10.1111/dom.15728) now offer better data on how GLP-1 agonists affect body composition.
  - The data show that weight loss with GLP-1 receptor agonists is comparable to dietary interventions or bariatric surgery in terms of lean mass lost.
- According to recent findings:
  - Roughly one-third of weight loss is lean mass, and two-thirds is fat mass. This distribution is similar across bariatric surgery, dietary interventions, and GLP-1 agonists.

![](https://peterattiamd.com/wp-content/uploads/2024/10/f5-ama64-1024x544.png)

**Figure 5.** Source: [Neeland et al. Diabetes Obes Metab. Sep 2024.](https://dom-pubs.onlinelibrary.wiley.com/doi/full/10.1111/dom.15728)

- For individuals looking to lose weight, a realistic expectation is that 10% of body weight loss could come from lean mass if the goal is to lose 20% of total body weight.

**Impact of Resistance Training and Protein Consumption**

- Resistance training and protein consumption can help mitigate lean mass loss during weight loss with GLP-1 agonists.
- Anecdotally and from clinical experience, patients who focus on resistance training and maintaining adequate protein intake tend to lose more fat than muscle.
  - This creates a favorable scenario where the individual preserves muscle mass while reducing fat.
- Peter emphasized that incorporating strength training into a weight loss regimen is crucial for improving body composition outcomes.

Notable Study on Body Composition Changes

- Peter referenced a [study](https://diabetesjournals.org/care/article-abstract/doi/10.2337/dci23-0100/154535/Incretin-Based-Weight-Loss-Pharmacotherapy-Can?redirectedFrom=fulltext) on tirzepatide:
  - Participants began with an average weight of around 104-105 kg (229-231 lbs) and lost about 24 kg (53 lbs) in total.
  - Out of this, they lost 6-7 kg (13-15 lbs) of lean mass and 17 kg (37 lbs) of fat mass.
  - The ratio of fat to muscle loss was nearly 3 to 1, which Peter considered an extremely favorable outcome in terms of body composition improvement.

![](https://peterattiamd.com/wp-content/uploads/2024/10/f6-ama64-1024x688.png)

**Figure 6.** Source: [Locatelli et al. Diabetes Care. Apr 2024.](https://diabetesjournals.org/care/article-abstract/doi/10.2337/dci23-0100/154535/Incretin-Based-Weight-Loss-Pharmacotherapy-Can?redirectedFrom=fulltext)

In conclusion, while lean mass loss is inevitable during weight loss with GLP-1 agonists, resistance training and adequate protein intake can help preserve muscle, leading to more favorable changes in body composition.

## Semaglutide vs. tirzepatide: comparing benefits and side effects [36:30]

**There are currently not any head-to-head comparison studies**

- Peter noted that semaglutide and tirzepatide have not yet been directly compared in head-to-head studies, and it is unclear if such a study will be done.
- Despite the lack of direct comparison, tirzepatide appears to be the more potent drug based on available [clinical trial data](https://link.springer.com/article/10.1007/s00125-024-06144-1#MOESM1) and physicians’ anecdotal experiences.
- Tirzepatide has demonstrated a greater amount of weight loss compared to semaglutide, even though both drugs show similar reductions in hemoglobin A1c levels (used to measure blood sugar control).

Dosage Differences

- Tirzepatide is typically dosed in a ramp-up approach, starting at 2.5 mg and increasing to 5 mg, 10 mg, or 15 mg.
- The 2.5 mg dose is often used as an initiation dose to help patients adjust to the drug, especially in the first few months.
- Semaglutide, by comparison, is dosed at 0.5 mg, 1 mg, and 2 mg, with its highest tested dose being 2.4 mg for weight loss.
- It’s important to be cautious when comparing doses directly, as the drugs differ in their mechanisms of action.

Adverse Effects and Discontinuation

- Both drugs have similar side effect profiles, especially regarding gastrointestinal (GI) complications, which include nausea, diarrhea, and constipation.
- The discontinuation rates due to side effects are comparable for both drugs.
- Cost is also a major factor contributing to discontinuation. Since both drugs cost about the same, many patients discontinue due to the high out-of-pocket expense.

Mechanism of Action

- Tirzepatide is a dual agonist, affecting two receptors: GLP-1 (glucagon-like peptide-1) and GIP (glucose-dependent insulinotropic polypeptide), which makes it more potent.
- Semaglutide only works on GLP-1 receptors, whereas tirzepatide’s dual action offers an additional mechanism to aid weight loss and metabolic control.
- Some anecdotal evidence suggests that patients who plateau on semaglutide and then switch to tirzepatide experience further benefits, possibly due to the additional GIP receptor activation.

## How compounding pharmacies affect availability of GLP-1 drugs and the types of formulations that are available [39:15]

For more, see [AMA #52](https://peterattiamd.com/ama52/) which had a section specifically on compounding pharmacies

\*\*\*

**Compounding Challenges and Why It’s Possible**

- Compounding pharmacies cannot legally create drugs that already exist on the market unless there is a modification to concentration, strength, or delivery method.
- For GLP-1 agonists like tirzepatide, which are sold in preloaded pens, compounding pharmacies can create vials or other delivery forms to circumvent this restriction.
  - Example: A 2.5 mg tirzepatide pen can only be bought in that dosage, meaning you cannot buy a 15 mg pen and use less of it.
- This situation is frustrating for many patients because the cost of the drug remains the same regardless of the dose, making it cost-inefficient to buy lower doses.

**Compounding Strategy and Cost-Reduction**

- Compounding pharmacies have started offering cheaper alternatives by providing the medication in vials, which can be administered using syringes rather than preloaded pens.
- The manufacturing of the pen is a significant cost driver in these medications, so eliminating the pen reduces overall costs.
- This method is similar to how drugs like testosterone or HCG are commonly administered.

**Two Main Drivers Behind the Rise in Compounding Pharmacies**

- 1) Cost Savings: Compounded versions are significantly cheaper.
  - Example: Wegovy’s sticker price is over $1,300 per month, while compounded versions cost much less.
- 2) Drug Scarcity: Periodic shortages of GLP-1 agonists have made compounding pharmacies a viable option for continued access to these medications.

**Price Comparisons of Market Drugs**

- Wegovy (semaglutide for weight loss): over $1,300 per month ($16,000 annually).
- Ozempic (for diabetes): $900–$1,200 per month.
- Zepbound (tirzepatide for weight loss): expected to cost $1,100 per month.

**Eli Lilly’s Upcoming Cheaper Alternatives**

- [Eli Lilly plans to release vials of tirzepatide](https://investor.lilly.com/news-releases/news-release-details/lilly-releases-zepboundr-tirzepatide-single-dose-vials-expanding) to compete with compounding pharmacies and reduce costs.
  - A 28-day supply of 2.5 mg is expected to cost $399, significantly lower than the current price (~$1,200).
- This move removes the need for single-use injector pens, contributing to cost savings.

**Regulatory Considerations and Potential Risks**

- Compounding pharmacies often blend additional drugs like B12 with GLP-1 agonists, which helps them get around some regulatory hurdles.
  - These combinations are generally benign but represent another way that compounding pharmacies navigate the rules.
- Forms of Drugs: These drugs can exist in salt or base forms, leading to variations in the compounded product.

**Risks Associated with Compounding**

- Patients should be aware of the potential risks of compounded drugs, especially regarding quality and efficacy.
- It’s essential to ensure that compounded medications are sourced from reputable pharmacies that adhere to strict regulatory guidelines.

## How do oral formulations of GLP-1 drugs compare to injectable formulations? [44:15]

**Oral Formulation of Semaglutide**

- Semaglutide is available in an oral form, but it requires a much higher daily dose compared to the injectable version.
- Oral doses are 3, 7, and 14 mg, whereas the injectable doses are 0.5, 1, or 2 mg weekly.

Reason for Higher Oral Doses

- Oral semaglutide has low bioavailability (about 1%) because much of it is metabolized by the liver before it can take effect.
- The gastric environment of the stomach breaks down peptides like semaglutide, requiring the drug to be coated to minimize destruction before entering circulation.

Comparison in Efficacy and Use Cases

- Injectable semaglutide is more potent and effective for weight loss, whereas oral semaglutide is approved for diabetes management, not weight loss.
- Injectable formulations are more effective in maintaining blood sugar levels and inducing weight loss.
- Oral semaglutide may still provide glycemic control benefits but doesn’t result in as significant weight loss.

Potential Applications for Oral Formulations

- The oral form might be appropriate for specific populations who don’t need to lose weight but can benefit from its metabolic and organ-specific improvements.
- Example: Patients with reduced ejection fraction or kidney disease who might not need weight loss but could benefit from enhanced metabolic health.

Different Therapeutic Goals

- Not everyone taking GLP-1 agonists requires weight loss. Some people might only need metabolic improvements, which could make the oral version a more suitable option in such cases.

## How do sublingual (under tongue) formulations of GLP-1 drugs compare to injectable formulations? [46:15]

Lack of FDA-Approved Sublingual Versions

- Currently, there are no FDA-approved sublingual formulations of GLP-1 agonists.
- However, sublingual delivery is commonly used in other medications because the drug is absorbed directly into circulation through the tissue under the tongue.
- This route bypasses the liver, avoiding first-pass metabolism, which could make the drug more efficient.

Potential Advantages of Sublingual Formulations

- Bypassing the liver: Absorption under the tongue bypasses liver metabolism, which can make the drug more effective at lower doses.
- Better side effect profile: There is speculation that sublingual formulations could result in fewer gastrointestinal side effects, but there is no data to confirm this yet.
- Cost efficiency and convenience: Sublingual formulations might be cheaper to produce and may also eliminate the need for refrigeration, which is required for the liquid forms of injectable GLP-1 agonists.

## Guidance for using compounding pharmacies to purchase GLP-1 agonists [47:15]

For more, see [AMA #52](https://peterattiamd.com/ama52/) which had a section specifically on compounding pharmacies

\*\*\*

**Risks of Illegitimate Online Pharmacies**

A recent [study](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2821882) in JAMA revealed that 42% of online vendors selling semaglutide were doing so illegally.

- These vendors were selling semaglutide without medical licensure, prescriptions, or legitimate FDA-branded medication.
- This does not include telemedicine sites that operate legally with physicians.
- Many of these illegal vendors were offering pre-filled pens that were not genuine or were selling generic formulations that didn’t meet standards.
- The study purchased vials from these illegal pharmacies and found alarming results:
- Some vials contained endotoxins, indicating contamination.
- The purity of the products was very low in many cases.
- In some instances, the drug concentration was only 10% of what was advertised, while in other cases, it was up to 29-39% higher than advertised.

Advice for Consumers: Stick with Physician Prescriptions

- It’s strongly recommended to avoid purchasing semaglutide from unlicensed vendors.
- Always find a physician who will prescribe the medication.
- If possible, opt for branded products.

(With [Eli Lilly introducing vial-based tirzepatide](https://investor.lilly.com/news-releases/news-release-details/lilly-releases-zepboundr-tirzepatide-single-dose-vials-expanding), compounding pharmacies may become less desirable.)

[**Checklist**](https://www.medscape.com/viewarticle/checklist-compounded-semaglutide-or-tirzepatide-2024a1000en1?form=fpf) **for Choosing a Reliable Compounding Pharmacy**

- For those who need to use a compounding pharmacy, here are the key steps to ensure the pharmacy is reputable:
  - Check the pharmacy’s state licensing board website: Verify that the pharmacy has no complaints or disciplinary actions.
  - State board inspection report: Request and review the pharmacy’s latest inspection report.
  - Accreditation: Ensure the pharmacy is accredited by the Pharmacy Compounding Accreditation Board (PCAB).
  - Certificate of analysis: Ask for this document to ensure the medication is what it claims to be.
  - Base vs. Salt Form: If buying semaglutide, make sure it’s the base form, not the salt form.
  - Third-party testing: Confirm the pharmacy conducts third-party testing for potency and sterility.
- While this might seem like a lot of work, it’s worth the effort if you’re going to be injecting something into your body.

## Data on retatrutide—a promising new triple receptor agonist in the pipeline [50:15]

**Introduction to Retatrutide**

- [Retatrutide](https://en.wikipedia.org/wiki/Retatrutide) is the newest drug in the GLP-1 agonist category.
- It is a triple agonist, working on GLP-1, GIP, and glucagon receptors.
- This distinguishes it from semaglutide (which targets only GLP-1) and tirzepatide (which targets both GLP-1 and GIP).

Phase 2 Trial Results

- The [phase 2 trial](https://www.nejm.org/doi/full/10.1056/NEJMoa2301972) for retatrutide was conducted in non-diabetic participants with a BMI of 30-50 or a BMI of 27-30 with a weight-related condition.
- The trial lasted 48 weeks with various dosing regimens (1 mg, 2-4 mg ramp-up, 4-8 mg ramp-up, and 2-12 mg ramp-up).
- Weight loss results were impressive:
  - Lowest dose (1 mg) resulted in 8.7% weight loss.
  - Highest dose (12 mg ramp-up) led to a 25% weight loss at 48 weeks.
- In comparison, retatrutide showed more potent weight loss than semaglutide (17.3% at max dose) and tirzepatide (22.5% at max dose).

![](https://peterattiamd.com/wp-content/uploads/2024/10/f7-ama64-1024x492.png)

**Figure 7.** Source: [Jastreboff et al. N Engl J Med. Aug 2023.](https://www.nejm.org/doi/full/10.1056/NEJMoa2301972)

Other Health Benefits of Retatrutide

- The drug also demonstrated improvements in metabolic markers such as:
  - Systolic blood pressure
  - Hemoglobin A1c
  - Fasting glucose, insulin, and lipids
- Retatrutide shows significant promise as a next-level weight-loss and metabolic health medication.

Side Effects

- The most frequent side effects were gastrointestinal:
  - Nausea, diarrhea, vomiting, and constipation were more common in patients taking retatrutide versus a placebo.
  - The highest doses experienced the highest frequency of these side effects.

**The Role of Glucagon in Retatrutide’s Effectiveness**

- A key question is whether adding glucagon into the receptor mix amplifies the drug’s effectiveness.
- Retatrutide’s unique receptor activity profile was analyzed:
  - For GLP-1, its relative strength is 0.4 (compared to 0.5 for semaglutide and 0.2 for tirzepatide).
  - For GIP, retatrutide is much stronger, with a relative strength of 8.9.
  - For glucagon, its relative strength is 0.3.
- Conclusion: While glucagon plays a role, it’s likely that retatrutide’s exceptional GIP activity is the primary driver behind its impressive weight loss and metabolic benefits.

## Can GLP-1 agonists be beneficial for sleep apnea and immune function? [57:00]

General Overview of Health Benefits

- GLP-1 agonists are frequently in the news for their supposed wide-ranging benefits beyond weight loss, including claims of improvements in areas like sleep apnea, immune function, and cardiovascular health.
- It’s common for drugs to be hailed as having numerous benefits beyond their primary use, but it’s important to analyze these claims systematically.

Evaluating the Benefits

- The key question to ask when confronted with any supposed benefit is: *Are these benefits occurring because of the weight loss and improved metabolic health that come with using these drugs, or are they direct, independent effects of the drug itself*?

**Sleep Apnea and GLP-1 agonists**

- Weak evidence beyond weight loss.
- Sleep apnea is strongly associated with obesity. Weight loss, whether through pharmacological or non-pharmacological means, generally leads to improvement in sleep apnea symptoms.
- However, there is no evidence that GLP-1 agonists independently reduce sleep apnea symptoms outside of the weight loss they promote.

**Immune Function (e.g., COVID-19 Outcomes) and GLP-1 agonists**

- Limited evidence beyond the effects of weight loss.
- The [SELECT trial](https://www.jacc.org/doi/10.1016/j.jacc.2024.08.007) found that patients on semaglutide had lower rates of death from infection and serious COVID-related complications than those on a placebo.
- The patients who experienced worse COVID outcomes also lost less weight, suggesting that the weight loss from GLP-1 agonists may be the primary factor improving immune function.
- Similarly, weight loss following bariatric surgery is associated with reduced rates of severe COVID complications, which supports the idea that the benefits seen with GLP-1s are likely tied to weight loss rather than any independent immune-boosting effects.

**Conclusion**

- While there are many headlines touting additional benefits of GLP-1 agonists, the current evidence suggests that most of the improvements seen in areas like sleep apnea and immune function are primarily driven by the weight loss and metabolic health improvements associated with these drugs, rather than any pleiotropic (independent) effects.

## Potential neuroprotective benefits of GLP-1 agonists: impact on dementia risk [1:00:45]

**GLP-1 Agonists and Alzheimer’s Disease/Dementia**

- There is moderate evidence suggesting that GLP-1 receptor agonists may provide neuroprotective benefits, particularly in relation to Alzheimer’s disease.
- Glucose intolerance and insulin resistance are major risk factors for Alzheimer’s, with some forms of the disease referred to as Type 3 diabetes or brain diabetes due to their metabolic underpinnings.
  - A subset of Alzheimer’s patients likely develops the disease due to metabolic dysfunction, which suggests that improving glucose metabolism through GLP-1 agonists could have a positive impact on preventing or slowing cognitive decline.

Systematic Review Findings on Dementia

- A [systematic review](https://alz-journals.onlinelibrary.wiley.com/doi/full/10.1002/trc2.12268) published in 2022 analyzed data from three randomized controlled trials (RCTs) involving patients with Type 2 diabetes and high cardiovascular disease (CVD) risk.
  - Results showed that patients taking GLP-1 agonists experienced a 53% reduction in the rate of dementia compared to those on a placebo over a follow-up period of just under four years.
  - However, when comparing GLP-1 agonists to other anti-diabetic drugs with similar glycemic control benefits, no significant differences in dementia risk reduction were observed.

Potential for Neuroprotective Benefits Beyond Diabetes

- Preclinical data suggest that GLP-1 agonists may reduce the risk of cognitive decline even outside of a diabetes context.
  - This points to the possibility that these drugs could offer neuroprotective benefits beyond their effects on glycemic control or weight loss.
- Two notable ongoing phase 3 trials, [EVOKE](https://clinicaltrials.gov/study/NCT04777396?cond=Alzheimer%20Disease&intr=Semaglutide&rank=3) and [EVOKE+](https://clinicaltrials.gov/study/NCT04777409?cond=Alzheimer%20Disease&intr=Semaglutide&rank=2), are specifically investigating the use of oral semaglutide in patients with early-onset Alzheimer’s disease.
  - These trials will help clarify whether the oral form of semaglutide provides similar cognitive benefits to the injectable version.

Clarifying the Role of GLP-1 Agonists in Disease Prevention

- While the current evidence suggests that GLP-1 agonists can improve metabolic health and reduce risk factors for diseases like dementia, weight loss and glucose homeostasis also provide many of the same benefits.
- Therefore, it’s important to question whether GLP-1 agonists should be a first-line treatment for individuals at risk of neurodegenerative diseases or whether other methods of improving metabolic health (such as lifestyle changes) could offer similar advantages.

Key Takeaways

- GLP-1 agonists clearly benefit people who lose weight and improve glucose homeostasis, but these benefits can also be achieved through other means, raising questions about the appropriate use of these drugs outside of Type 2 diabetes and weight loss.
- For individuals who may not need to lose weight but are at risk for metabolic or cognitive issues, more data is needed to determine whether GLP-1 agonists should be used in non-weight related, non-diabetic contexts.

## Exploring why GLP-1 agonists may reduce the risk of cancer, kidney disease, and cardiovascular disease [1:04:00]

**Cancer Risk and GLP-1 Agonists**

- Cancer Risk Reduction: GLP-1 receptor agonists can reduce the risk of cancer, particularly in patients with insulin resistance and Type 2 diabetes, which are significant drivers of cancer.
  - Insulin resistance is considered the second leading environmental risk for cancer, behind smoking.
  - Obesity-related cancers, which are associated with high BMI and insulin sensitivity, are particularly influenced by these drugs.
- A [study](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2820833#) published in JAMA found that GLP-1 agonists were linked to a significant reduction in 10 out of 13 obesity-related cancers in patients with Type 2 diabetes. These patients were prescribed GLP-1 agonists compared to those prescribed insulin.
  - Interpretation: While some may argue that both Metformin and GLP-1 agonists are cancer-protective, Peter suggests that it’s insulin resistance and hyperinsulinemia that primarily drive cancer risk, rather than a direct protective effect from these drugs.

**Kidney Disease and GLP-1 Agonists**

- Chronic kidney disease (CKD) is common among patients with Type 2 diabetes, with around 40% of patients developing CKD. However, not all progress to end-stage renal disease.
- A recent [study](https://www.nejm.org/doi/full/10.1056/NEJMoa2403347) in The New England Journal of Medicine showed that patients on 1 mg of semaglutide had a 24% lower risk of major kidney disease compared to those on a placebo.
  - Comparison to SGLT2 Inhibitors: When comparing GLP-1 agonists to SGLT2 inhibitors, no significant difference in renal protection was observed.
  - Comparison to Metformin: However, GLP-1 agonists appeared to offer better protection compared to Metformin.
- Challenges in Evaluating Kidney Disease Protection: Peter expressed the need for more studies to clarify these findings, ideally correcting for the weight loss associated with GLP-1 agonist use, which is a confounding factor.

Cardiovascular Disease (CVD) and GLP-1 Agonists

- CVD Risk Reduction: GLP-1 agonists have been shown to reduce the risk of major adverse cardiac events.
- The [SELECT trial](https://pubmed.ncbi.nlm.nih.gov/37952131/) demonstrated a significant reduction in major cardiac events in overweight and obese patients without Type 2 diabetes who were taking semaglutide.
  - The trial found a 20% relative risk reduction compared to the placebo group, but Peter cautioned that the difference in weight loss between the two groups may confound the results.
  - For context, bariatric surgery patients experience a 60% reduction in major adverse cardiac events, a benefit strongly correlated with weight loss.
- Heart Failure and GLP-1 Agonists: [Studies](https://pubmed.ncbi.nlm.nih.gov/38587233/) looking at heart failure in patients taking GLP-1 agonists have shown similarly promising results, though weight loss remains a confounding factor.
  - Interestingly, GLP-1 agonists have been found to raise heart rate, which initially raised concerns.
  - Despite this, the cardiovascular benefits of these drugs, such as lowering blood pressure and promoting weight loss, appear to outweigh the potential risks associated with increased heart rate.

Conclusion

- Weight Loss as a Confounder: Across the studies in cancer, kidney disease, and cardiovascular disease, Peter emphasized the challenge of disentangling the effects of GLP-1 agonists from the benefits of weight loss and glycemic control. While these drugs offer significant health benefits, it’s difficult to determine how much of the improvement is directly attributable to the drug versus the indirect effects of weight loss.

## How GLP-1 agonists might boost fertility in women [1:10:15]

Weight Loss and Fertility:

- Weight and obesity play a significant role in infertility, especially in women. Given that GLP-1 agonists like Ozempic lead to weight loss, it’s plausible that they could improve fertility by reducing obesity-related issues.

Leptin and Fertility:

- Leptin is a hormone that signals the brain about the body’s energy stores and influences reproduction. When leptin levels are high (as seen in leptin resistance in obesity), it can impair reproductive function.
- High leptin is often associated with hypogonadism and infertility, suggesting that lowering leptin levels through weight loss could improve fertility. GLP-1 agonists help reduce leptin as they promote weight loss, which may positively impact fertility.

Gastric Emptying and Oral Contraceptives:

- Another potential effect of GLP-1 agonists is their ability to delay gastric emptying, which could alter the absorption of oral contraceptives.
- This delayed absorption might impact how well contraceptives work in women taking these drugs, potentially influencing their fertility.

Conclusion:

- There is a possibility that GLP-1 agonists could affect fertility in women, primarily by improving factors related to weight loss and leptin regulation, along with a potential influence on contraceptive absorption. However, more specific research is needed to fully understand these effects.

## Early indications that GLP-1 agonists may help treat substance abuse disorders [1:12:00]

Mechanisms Linking Food and Reward Circuits:

- GLP-1 agonists impact both metabolic and hedonic (pleasure-driven) circuits related to food intake, which has led to interest in their potential effects on non-food addictions.

Evidence in Animal Studies:

- Experimental studies, particularly in mice and rats, have shown that semaglutide can dose-dependently reduce binge-like alcohol consumption, suggesting a possible role for GLP-1 agonists in combating alcohol use disorder.

Human Studies on Alcohol Use:

- Two small clinical studies investigated the effects of a weaker GLP-1 agonist on heavy drinking in humans, but the results were conflicting and the drug used was considered ineffective compared to semaglutide or tirzepatide. These findings are not particularly reliable, and further research with stronger GLP-1 agonists is needed.

Alternative Explanation: Appetite Suppression:

- Some researchers argue that the reduction in alcohol consumption may be due to a lower appetite rather than direct effects on addiction pathways. Alcohol is high in calories, and people may reduce their intake due to decreased caloric needs.

Observational Study on Nicotine and Stimulants:

- An observational [study](https://www.thelancet.com/journals/eclinm/article/PIIS2589-5370(24)00305-5/fulltext) compared semaglutide with three other anti-diabetic drugs, showing that only semaglutide was associated with a significant reduction in nicotine and stimulant use.
  - There were also trends towards reduced alcohol, cannabis, and opioid use, although these findings were not statistically significant.
- Since this is observational data, it lacks the rigor of randomized trials, and more research is needed to establish causality between GLP-1 agonists and reduced substance use.

\*Check out the [episode with Anna Lembke](https://peterattiamd.com/annalembke) (publishing 10/14/24) for more on addiction

## Potential health risks of GLP-1 agonists: addressing thyroid cancer concerns and the unknowns due to lack of data [1:14:00]

Thyroid Cancer Concerns:

- Early concerns about thyroid cancer risks were based on rat studies.
- However, a large [systematic review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC11050669/#:~:text=The%20review%20focused%20on%20thyroid,%25%2C%20suggesting%20no%20significant%20risk.) conducted over the last four years shows that the incidence of thyroid cancer in semaglutide-treated patients is less than 1%.
- While the current data suggests that the risk of thyroid cancer is not significant, the median follow-up in these studies is only 1-2 years. Therefore, it may still be too early to draw definitive conclusions about long-term risks.

Possible Small Long-Term Risks:

- Given the widespread use of these drugs, if there were any large, life-threatening signals, they likely would have emerged by now.
- However, over time, even small risks may become apparent if enough people are on the drugs for long periods.

Statins Comparison:

- Statins offer an analogy: when they were first introduced, 5% of patients experienced muscle soreness as a noticeable side effect.
- However, it took years to discover that a smaller subset of patients on statins were at risk of developing Type 2 diabetes.
- The same may apply to GLP-1 agonists—early side effects may be apparent now, but long-term, less obvious risks could surface after extended usage.

Overall Conclusion:

- While the data so far is reassuring, it is still too early to completely rule out small risks, especially as patients continue using the drugs for longer periods.

## Examining the potential link between GLP-1 agonists and increased depression or suicidal ideation [1:16:00]

**GLP-1 and mental health:**

- Recently, there has been growing concern that GLP-1 agonists may contribute to depression or suicidal ideation.
- A [review](https://www.sciencedirect.com/science/article/pii/S0924977X24001573) evaluated this relationship to determine if these drugs are responsible for such outcomes and concluded that evidence failed to meet the [Bradford Hill criteria](https://en.wikipedia.org/wiki/Bradford_Hill_criteria).
  - The Bradford Hill criteria is a set of questions used to assess whether observational data can establish causality.
- The review found that none of these criteria were met, which suggests that there is no evidence to support a causal link between GLP-1 agonists and increased suicidal ideation.

Potential for Individual Cases:

- Despite the findings, Peter noted that while on average these drugs may not lead to depression or suicidal thoughts, it’s important to consider whether certain individuals might still be at risk. This is a question that needs further investigation.

Impact of Rapid Weight Loss:

- Even if GLP-1 agonists aren’t directly causing these mental health concerns, the rapid weight loss associated with the drugs can be physiologically stressful, potentially leading to:
  - Mood disruptions
  - Cortisol and norepinephrine spikes
  - Feelings of anxiety
- Similar outcomes have been observed in bariatric surgery patients, where they showed a higher risk of suicidal thoughts compared to controls matched for age, sex, and BMI.

Challenge of Evaluating Risks:

- It is difficult to assess the true impact of these drugs without randomization, as factors like why one person chose to take the drug versus another who didn’t, or why one underwent surgery and another didn’t, can complicate the data.

Importance of Physician Oversight:

- Peter emphasized the importance of having these drugs prescribed by a physician who has experience in treating patients with weight loss medications. A physician can help manage side effects and intervene if suicidal ideation occurs.
- While some people may opt for cheaper, non-prescribed alternatives, the safety and oversight provided by a knowledgeable doctor are critical for those undergoing treatment, especially if psychological side effects arise.

## Major remaining questions: the effects of cyclic use, rebound appetite, impact on adolescents’ development, and more [1:19:30]

Cyclic Use of the Drugs:

- Peter raises concerns about cyclic use of GLP-1 agonists.
- Some patients report that the drug loses efficacy when cycling on and off the drug, suggesting that repeatedly stopping and restarting may reduce the drug’s effectiveness.
- He advises against taking high doses to achieve rapid weight loss, only to come off the drug, regain weight, and go back on.
  - Instead, it’s recommended to take a lower dose and achieve slower, more sustainable weight loss.
- Ideally, patients should consider staying on the drug long-term, or if they stop, ensuring that exercise and diet can maintain the results.

Rebound Appetite:

- Anecdotal reports suggest that after stopping the drug, some patients experience intense hunger and weight regain.
  - One woman noted she felt hungrier than ever, which made weight maintenance even more challenging.
- This raises questions about the long-term effects of the drug and the mental toll it can take on patients when trying to manage appetite post-treatment.

Experiment with Caloric Restriction:

- Peter would like to see an experiment where patients are given either the drug or placed on caloric restriction to achieve the same amount of weight loss.
- He would like to see comparisons between the two groups in terms of psychological suffering and physiological outcomes.
- Such a study could reveal whether drug-induced weight loss differs from diet-induced weight loss in terms of how macronutrients are restricted or metabolic responses.

Effect on Adolescents:

- Another key question is how GLP-1 agonists affect adolescents.
- Some parents are concerned but still opt to put their children on these drugs due to significant weight issues.
- Peter believes it’s important to study the use of these drugs in younger patients to understand any potential long-term consequences, especially given that adolescents are still undergoing puberty.
- He specifically raises concerns about the potential effects on bone mineral density formation during this critical developmental phase, which may differ from adults who start using the drugs later in life.
- It’s essential to understand whether the drugs have any unforeseen consequences and if they are appropriate for long-term use in patients who are still growing.

## Key considerations when deciding whether to use a GLP-1 agonist for weight loss [1:23:45]

**Moral judgement and stigma**:

- Peter addresses the moral judgment and stigma associated with using GLP-1 agonists, where some view it as a sign of weakness or failure in managing weight naturally.
- He compares it to taking other medications, like antidepressants or lipid-lowering drugs, stating that taking these medications does not make someone morally inferior.
- He encourages people to move beyond the “pharma is bad” narrative, pointing out that while big pharma has flaws, it has also saved lives and extended lifespans through various medications.

**Consider Weight Loss Tools Carefully**:

- When it comes to weight loss, retatrutide appears to be even more promising than tirzepatide, which is better than semaglutide.
- He discourages people from even considering the older generations of drugs like liraglutide for weight loss, as they serve little purpose compared to these newer options.
- He notes the massive growth in the pipeline of GLP-1 drugs and predicts that the next six years will bring significant advancements in this area.

Focus on Overall Health, Not Just Weight Loss:

- It’s important not to focus solely on weight loss but to also consider body composition and metabolic health.
- More weight loss isn’t always better, and managing muscle mass and overall health should be key considerations.
- For those using GLP-1 agonists, he stresses the importance of protein consumption and resistance training to avoid excessive muscle loss and maintain a healthy body composition.

Safety Concerns and Managing Risk:

- While the long-term safety of these drugs is still under review, Peter advises that people should only take these drugs if they are willing to assume the risk.
- He explains that people should be prepared to take the drug indefinitely if it remains safe or be willing to stop if adverse effects emerge, knowing they might regain weight.
- He discourages obtaining these medications from unregulated sources and instead advises working with a physician, whether through telemedicine or in person, to ensure the drug is real, pure, and safe.

Psychological and Physical Risks:

- Peter emphasizes the importance of monitoring the psychological toll of taking these drugs, as some people may be more susceptible to negative side effects, even if the average risk is low.
- He hopes for more data in the next 18 months to better identify which patients might be at risk for such side effects and how to potentially stratify patients who should avoid these drugs.
- Overall, Peter encourages a holistic approach to using GLP-1 agonists for weight loss, urging people to carefully consider the risks and benefits while focusing on long-term health beyond just shedding pounds.

§

## Selected Links / Related Material

**Previous episodes on GLP-1 agonists**: [3:00]

- [#184 – AMA #29: GLP-1 Agonists – The Future of Treating Obesity?](https://peterattiamd.com/ama29/)
- [#246 – AMA #45: Pros and cons of GLP-1 weight loss drugs and metformin as a geroprotective agent](https://peterattiamd.com/ama45/)
- [#314 ‒ Rethinking nutrition science: the evolving landscape of obesity treatment, GLP-1 agonists, protein, and the need for higher research standards | David Allison, Ph.D.](https://peterattiamd.com/davidallison2/)

**AMA episode of The Drive that discussed compounding pharmacies**: [#275 – AMA #52: Hormone replacement therapy: practical applications and the role of compounding pharmacies](https://peterattiamd.com/ama52/) | Peter Attia (peterattiamd.com) [14:15]

**Four years of follow-up data on semaglutide showing that weight loss remains for all 4 years if staying on the drug**: [Long-term weight loss effects of semaglutide in obesity without diabetes in the SELECT trial](https://www.nature.com/articles/s41591-024-02996-7) (Ryan et al., 2024) [20:00]

**Analysis showing that the number one reason for people to discontinue a GLP-1 agonists was actually not side effects, but out-of-pocket cost**: [GLP-1 Receptor Agonist Discontinuation Among Patients With Obesity and/or Type 2 Diabetes](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2819256?utm_source=silverchair&utm_medium=email&utm_campaign=article_alert-jamanetworkopen&utm_term=mostread&utm_content=olf-widget_06142024&adv=) (Do et al., 2024) [20:30]

**Mice that lack GLP-1 receptors specifically in the brain do not lose weight on liraglutide, but they still experience glucose lowering effects suggesting that appetite regulation in the brain plays a crucial role in the weight loss seen with these drugs**: [Neuronal GLP1R mediates liraglutide’s anorectic but not glucose-lowering effect](https://www.jci.org/articles/view/72434) (Sisley et al., 2014) [23:00]

**A 2023 study on tirzepatide with a two-year follow-up showed that most participants regained the weight they had lost after stopping the drug, regardless of the dose they had been on**: [Effect on Hemoglobin A1c (HbA1c) and Body Weight After Discontinuation of Tirzepatide, a Novel Glucose-Dependent Insulinotropic Peptide (GIP) and Glucagon-Like Peptide-1 (GLP-1) Receptor Agonist: A Single-Center Case Series Study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10550307/) (Kubota et al., 2023) [26:00]

**Study showing subjects who combined exercise and liraglutide lost the most weight and regained it the slowest compared to other groups**: [Healthy weight loss maintenance with exercise, GLP-1 receptor agonist, or both combined followed by one year without treatment: a post-treatment analysis of a randomised placebo-controlled trial](https://www.thelancet.com/journals/eclinm/article/PIIS2589-5370(24)00054-3/fulltext) (Jensen et al., 2024) [29:15]

**Peter’s book**: [OUTLIVE: THE SCIENCE & ART OF LONGEVITY](https://peterattiamd.com/outlive/) by Peter Attia | (peterattiamd.com) [31:00]

**Data show that weight loss with GLP-1 receptor agonists is comparable to dietary interventions or bariatric surgery in terms of** ***lean mass lost***: [Changes in lean body mass with glucagon-like peptide-1-based therapies and mitigation strategies](https://dom-pubs.onlinelibrary.wiley.com/doi/full/10.1111/dom.15728) (Needland et al., 2024) [32:30]

**Study of patients taking tirepatide showed extremely favorable outcome in terms of body composition improvement**: [Incretin-Based Weight Loss Pharmacotherapy: Can Resistance Exercise Optimize Changes in Body Composition?](https://diabetesjournals.org/care/article-abstract/doi/10.2337/dci23-0100/154535/Incretin-Based-Weight-Loss-Pharmacotherapy-Can?redirectedFrom=fulltext) (Locatelli et al., 2024) [35:00]

**Meta-analysis suggesting that tirzepatide appears to be the more potent drug**: [Subcutaneously administered tirzepatide vs semaglutide for adults with type 2 diabetes: a systematic review and network meta-analysis of randomised controlled trials](https://link.springer.com/article/10.1007/s00125-024-06144-1#MOESM1) (Karagiannis et al., 2024) [37:00]

**Study found that 42% of online vendors that were selling semaglutide were doing so illegally**: [Safety and Risk Assessment of No-Prescription Online Semaglutide Purchases](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2821882) (Ashraf et al., 2024) [47:15]

**A great checklist to use when picking a compounding pharmacy**: [A Checklist for Compounded Semaglutide or Tirzepatide](https://www.medscape.com/viewarticle/checklist-compounded-semaglutide-or-tirzepatide-2024a1000en1?form=fpf) | Beverly Tchang, MD (medscape.com) [48:45]

**A phase 2 trial showing that retatrutide showed more potent weight loss than semaglutide and tirzepatide**: [Triple–Hormone-Receptor Agonist Retatrutide for Obesity — A Phase 2 Trial](https://www.nejm.org/doi/full/10.1056/NEJMoa2301972) (Jastreboff et al., 2023) [50:15]

**The SELECT trial found that deaths from infection and deaths from serious Covid-related adverse events occur at lower rates in the semaglutide group versus the placebo group**: [The Effect of Semaglutide on Mortality and COVID-19–Related Deaths: An Analysis From the SELECT Trial](https://www.jacc.org/doi/10.1016/j.jacc.2024.08.007) (Scirica et al., 2024) [59:15]

**Systemic review found that patients taking GLP-1 agonists experienced a 53% reduction in the rate of dementia compared to those on a placebo over a follow-up period of just under four years**: [Treatment with glucagon-like peptide-1 receptor agonists and incidence of dementia: Data from pooled double-blind randomized controlled trials and nationwide disease and prescription registers](https://alz-journals.onlinelibrary.wiley.com/doi/full/10.1002/trc2.12268) (Nørgaard et al., 2022) [1:01:00]

**Study showed that the use of GLP-1 agonist was associated with a significant reduction in 10 of 13 obesity-related cancers in patients with Type 2 diabetes and a prescribed GLP-1, compared to patients with Type 2 diabetes who were prescribed insulin**: [Glucagon-Like Peptide 1 Receptor Agonists and 13 Obesity-Associated Cancers in Patients With Type 2 Diabetes](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2820833#) (Wang et al., 2024) [1:04:15]

**NEJM study taking a half dose of semaglutide (1 mg) had a 24% lower risk of major kidney disease compared to those on a placebo**: [Effects of Semaglutide on Chronic Kidney Disease in Patients with Type 2 Diabetes](https://www.nejm.org/doi/full/10.1056/NEJMoa2403347) (Perkovic et al., 2024) [1:06:00]

**The SELECT trial demonstrated a significant reduction in major cardiac events in overweight and obese patients without Type 2 diabetes who were taking semaglutide**: [Semaglutide and Cardiovascular Outcomes in Obesity without Diabetes](https://pubmed.ncbi.nlm.nih.gov/37952131/) (Lincoff et al., 2023) [1:07:45]

**Studies looking at heart failure in patients taking GLP-1 agonists have shown similarly promising results when taking semaglutide, though weight loss remains a confounding factor**: [Semaglutide in Patients with Obesity-Related Heart Failure and Type 2 Diabetes](https://pubmed.ncbi.nlm.nih.gov/38587233/) (Kasiborod et al., 2024) [1:08:00]

**An observational study compared semaglutide with three other anti-diabetic drugs, showing that only semaglutide was associated with a significant reduction in nicotine and stimulant use**: [12-month neurological and psychiatric outcomes of semaglutide use for type 2 diabetes: a propensity-score matched cohort study](https://www.thelancet.com/journals/eclinm/article/PIIS2589-5370(24)00305-5/fulltext) (Giorgi et al., 2024) [1:13:00]

**A large systematic review conducted over the last four years shows that the incidence of thyroid cancer in semaglutide-treated patients is less than 1%**: [Assessment of Thyroid Carcinogenic Risk and Safety Profile of GLP1-RA Semaglutide (Ozempic) Therapy for Diabetes Mellitus and Obesity: A Systematic Literature Review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC11050669/#:~:text=The%20review%20focused%20on%20thyroid,%25%2C%20suggesting%20no%20significant%20risk.) (Feier et al., 2024) [1:14:00]

**A 2024 review assessed the relationship between use of GLP-1 agonist and suicidal ideation and found that it failed to meet any of the Bradford Hill criteria of causality**: [GLP-1 agonists and risk of suicidal thoughts and behaviours: Confound by indication once again? A narrative review](https://www.sciencedirect.com/science/article/pii/S0924977X24001573) (Strumila et al., 2024) [1:16:00]

**Episode of The Drive with David Allison**: [#314 ‒ Rethinking nutrition science: the evolving landscape of obesity treatment, GLP-1 agonists, protein, and the need for higher research standards | David Allison, Ph.D.](https://peterattiamd.com/davidallison2/) | Peter Attia (peterattiamd.com) [1:24:00]

§

## People Mentioned

- [Eric Ravussin](https://en.wikipedia.org/wiki/Eric_Ravussin) [28:15]
- [Anna Lembke](https://www.annalembke.com/about) [1:11:30]
- [David Allison](https://en.wikipedia.org/wiki/David_B._Allison) [1:24:00]

§