# #27 – David Sinclair, Ph.D.: Slowing aging – sirtuins, NAD, and the epigenetics of aging

**Source:** [https://peterattiamd.com/davidsinclair/](https://peterattiamd.com/davidsinclair/)

---

In this episode, David A. Sinclair, Ph.D., a Professor in the Department of Genetics at Harvard Medical School and co-Director of the Paul F. Glenn Center for the Biological Mechanisms of Aging, provides insight into why we age and how to slow its effects based on his remarkable work on the role of sirtuins and NAD in health and diseases. He also presents the case that stabilizing the epigenetic landscape may be the linchpin in counteracting aging and disease.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/davidsinclair/the_Drive_public.png)

Play

#27 - David Sinclair, Ph.D.: Slowing aging – sirtuins, NAD, and the epigenetics of aging

#27 - David Sinclair, Ph.D.: Slowing aging – sirtuins, NAD, and the epigenetics of aging

1x15s30s

0:001:41:23

## We discuss:

- How and why David moved from Australia to Lenny Guarente’s lab at MIT [7:30];
- Sirtuins and aging [15:00];
- A series of experiments elucidating the mechanisms of sirtuins [20:45];
- How are sirtuins activated? [25:30];
- NAD and sirtuin activation [31:00];
- Nicotinamide, sirtuin inhibition, and *PNC1* [39:00];
- Resveratrol [43:00];
- The NIH/ITP studies on resveratrol [55:45];
- Does David take any compounds for longevity? [1:00:15];
- NAD precursors (NR, [NMN](/does-nmn-improve-metabolic-health-in-humans/)) and pterostilbene [1:02:45];
- Female fertility and NAD precursors [1:14:45];
- A unifying theory of aging [1:20:30];
- Waddington’s epigenetic landscape [1:23:00];
- If David had unlimited resources, what is the experiment he would do? [1:28:25];
- Testing combinations to extend lifespan [1:31:30];
- What made David aware of his mortality at such a young age? [01:33:45];
- What is David’s book going to cover? [01:37:15]; and
- More.

§

## Show Notes

**Abbreviations**: NAD, Nicotinamide Adenine Dinucleotide; NIH, National Institutes of Health; ITP, Interventions Testing Program; NR, Nicotinamide Riboside; NMN, Nicotinamide MonoNucleotide; PT, Pterostilbene; AMPK,  5′ Adenosine Monophosphate-activated Protein Kinase

## How and why David moved from Australia to Leonard Guarente’s lab at MIT [7:30]

- David’s been interested in aging since the age of four
- He went to seek out the greatest people in the world after getting a Ph.D. in yeast genetics
- Lenny Guarente came to Australia and had dinner with David and his Ph.D. supervisor
- He sold his car, flew from Australia to Boston for a five-minute interview with Doug Melton at MIT
- David never subscribed to the idea of death genes (i.e., group selection)
- David believed longevity genes could evolve — and he pitched Melton with this idea
- Got the position at MIT and studied aging in yeast

## Sirtuins and aging [15:00]

- Silent information regulator (Sir), Sir-2 in yeast (the mammalian homolog is SIRT3) seemed to regulate aging
- Sirtuins play a protective role in responding to energy and nutrients, similar to AMPK and the mTORC pathways
- Sir-2 was first found in yeast as a silencing protein that controlled the sex of a yeast cell
- Found out that sirtuins were also involved in DNA repair
- Sirtuins play a dual role: gene silencing and DNA repair — and they can’t do both simultaneously
- You don’t want to be mating and dividing if you have a broken chromosome: this system of coordination in the sirtuins ensures this doesn’t happen
- Sirtuins also target proteins in the cytoplasm and mitochondria
- They play a role in regulating the chromatin, histones, signaling, and metabolism

**Table 1. Mammalian sirtuins.** Image credit: [Ozawa et al., 2010](https://www.karger.com/Article/PDF/316484), *Ophthalmic Research*

![](https://peterattiamd.com/wp-content/uploads/2018/11/Sirtuins-location-targets-table.png)

## A series of experiments elucidating the mechanisms of sirtuins [20:45]

- Brian Kennedy and colleagues showing the movement of sirtuins to the *AGE* locus in 1996
- Kevin Mills and David stained the sirtuins and saw they were going to the nucleolus, and the ribosomal DNA (rDNA)
- David worked on Werner syndrome, looking at SGS1 (the mammalian homolog is WRN) and found they were exhibiting accelerated aging
- Knocking out Sir-2 led to accelerated aging
- They then tried the opposite: overexpressed Sir-2, with the prediction they would get more genomic stability at the rDNA in the nucleolus, and the yeast cell should live longer
- That experiment was [done](https://www.ncbi.nlm.nih.gov/pubmed/10521401) by Matt Kaeberlein and he confirmed lifespan extension

![](https://peterattiamd.com/wp-content/uploads/2018/11/sirt1-functions.png)

**Figure 1. Substrates and biological functions of sirtuins.** Image credit: [Nakagawa and Guarente, 2011](https://jcs.biologists.org/content/124/6/833), *Journal of Cell Science*

**Abbreviations**: AASIS, amino-acid-stimulated insulin secretion; AceCS, acetyl-CoA synthetase; ANT, a denine nucleotide translocase; AROS, active regulator of SIRT1; BER, base excision repair; BMAL1, brain and muscle Aryl hydrocarbon receptor nuclear translocator-like 1; CDK1, cyclin-dependent kinase 1; CPS1, carbamoyl phosphate synthetase 1; CR, calorie restriction; CRTC2, cAMP responsive element binding protein regulated transcription coactivator 2; CtBP, C-terminal binding protein; CypD, cyclophilin D; Cyt c, cyctochrome c; DBC1, deleted in bladder cancer protein 1; DNA-PK DNA-dependent protein kinase; DSB, double-strand break; E2F1, E2F transcription factor 1; eNOS, endothelial nitric oxide synthase; FOXO, forkhead box protein O; FXR, farnesoid X receptor; GDH, glutamate dehydrogenase; GSIS, glucosestimulated insulin secretion; HFD, high fat diet; HIC1, hypermethylated in cancer 1; HIF, hypoxia-inducible factor; HNF4α, hepatocyte nuclear factor 4-alpha; HSF1, heat shock factor protein 1; IDE, insulin-degrading enzyme; IDH2, isocitrate dehydrogenase 2; IVF, in vitro fertilization; KO, knock out; LCAD, long-chain specific acyl-CoA dehydrogenase; LKB1, serine/threonine-protein kinase 11; LXR, liver X receptor alpha; miR134, micro RNA 134; MRPL10, mitochondrial ribosomal protein L10; MyoD, myoblast determination protein; NAD, nicotinamide adenine dinucleotide; NADH, NAD reduced form; NAM, nicotinamide; Nampt, nicotinamide phosphoribosyltransferase; NDUFA9, NADH dehydrogenase (ubiquinone) 1 alpha subcomplex subunit 9; NF-κB, nuclear factor kappa-B; NMN, nicotinamid mononucleotide; Nmnat, nicotinamide mononucleotide adenylyltransferase; NBS1, nijmegen breakage syndrome protein 1; Ox2R, orexin receptor type 2; PARP1, poly (ADP-ribose) polymerase 1; PCAF, p300/CBP-associated factor; Per2, period circadian protein homolog 2; PGC1α, PPAR gamma coactivator 1-alpha; PIP5Kγ, phosphatidylinositol 4-phosphate 5-kinase type-1 gamma; PPAR, peroxisome proliferator-activated receptor; PTPB1, protein-tyrosine phosphatase 1B; Rb, retinoblastoma associated protein; rDNA, ribosomal DNA; RelA, reticuloendotheliosis viral oncogene homolog A; RARβ, retinoic acid receptor-beta; SDH, succinate dehydrogenase; Smad7, mothers against decapentaplegic homolog 7; SREBP, sterol regulatory element-binding protein; Suv39h1, suppressor of variegation 3-9 homolog 1; Tg, transgenic mice overexpressing a particular sirtuin; Tle1, transducin-like enhancer protein 1; TNFα, tumor necrosis factor-alpha; TSC2, tuberous sclerosis complex 2; UCP2, uncoupling protein 2; WAT, white adipose tissue; WB, whole body; WRN, Werner syndrome ATP-dependent helicase.

## How are sirtuins activated? [25:30]

- David found sirtuins were necessary and sufficient to get the full benefits of calorie restriction
- The whole family of sirtuins are important (yeast have five, mammals have seven)
- The biggest insult to any life form are chromosome breaks
- Sirtuins likely evolved 3.5 billion years ago
- Sirtuins sense biological stress in the environment (e.g., DNA damage, change in temperature, a lack of nutrients, a burst of cosmic rays) — and allow the organism to hunker down and survive (and stop breeding)
- They also talk to *MTOR* and *daf* (IGF-1 and FOXO are the mammalian homologs of DAF-2 and DAF-16 in worms [i.e., *Caenorhabditis elegans*])
- They may control which genes to turn on and off during adversity: we’ve settled on these genes and proteins as longevity pathways, but they didn’t evolve for longevity, the evolved for survival during adversity

![](https://peterattiamd.com/wp-content/uploads/2018/11/mitochondrial-sirtuins.png)

**Figure 2. Mitochondrial sirtuins.** Image credit: [Nakagawa and Guarente, 2011](https://jcs.biologists.org/content/124/6/833), *Journal of Cell Science*

## NAD and sirtuin activation [31:00]

- Nicotinamide adenine dinucleotide (NAD) is a coenzyme found in all cells
- NAD exists in two forms: NAD+ (oxidized form) and NADH (reduced form)
- David moved to Harvard in 1999
- A few major things happened in 1999
  - The DNA repair connection was found
  - NAD+ is a requirement for sirtuin activity was [determined](https://www.ncbi.nlm.nih.gov/pubmed/10693811)
  - Connection to CR was happening around that time
- NAD is the most important ubiquitous molecule in the cell: how could it possibly be varied?
- We now know NAD levels fluctuate and go down with age
- Learned in 2007 that NAD goes up and down not only in the cytoplasm but also in the mitochondria
- The mitochondrial oasis hypothesis: as long as the mitochondria stayed active with their NAD, the cell could survive, and recover from that stress, even when the NAD disappeared from the cell — mitochondrial NAD levels were more important than cytosolic NAD levels for survival
- NAD is made de novo in the cell, but you don’t get to shuttle NAD between cells
- NADP, NADH don’t activate sirtuins, only NAD+ will do that
- Combination of the charge and size that works to activate sirtuins

![](https://peterattiamd.com/wp-content/uploads/2018/11/enzymatic-reaction-of-sirtuins.png)

**Figure 3. Enzymatic reactions of sirtuins.** Image credit: [Nakagawa and Guarente, 2011](https://jcs.biologists.org/content/124/6/833), *Journal of Cell Science*

## Nicotinamide, sirtuin inhibition, and *PNC1* [39:00]

- David and his colleague fed nicotinamide (vitamin B3) to yeast to activate sirtuins
- They got inhibition instead, which was unexpected
- *PNC1*: [found](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4802858/) when they calorically restricted yeast cells, this *PNC1* was the most activated gene
- Stress response turning on NAD production and activating sirtuins
- *PNC1* is turned on by heat, CR, low AA, high salt
  - Defense pathways to deal with the stress

![](https://peterattiamd.com/wp-content/uploads/2018/11/other-sirtuins.png)

**Figure 4. Other sirtuins.** Image credit: [Nakagawa and Guarente, 2011](https://jcs.biologists.org/content/124/6/833), *Journal of Cell Science*

## Resveratrol [43:00]

- Konrad Howitz discovered two molecules that changed the activity of human *SIRT1*: piceatannol and quercetin
- Rob Zipkin saw the molecules and saw similarities in structure to resveratrol
- Found a Sir-2 dependent lifespan extending molecule
- The mouse [paper](https://www.ncbi.nlm.nih.gov/pubmed/17086191) in Nature in 2006 made the story go global: “Resveratrol improves health and survival of mice on a high-calorie diet”
- Resveratrol was also acting on AMPK (2006 supplemental of the Nature paper) at high doses
- Fat mice taking resveratrol were healthier and lived longer than ones who didn’t
- Resveratrol is not very soluble: you get better absorption with fat

![](https://peterattiamd.com/wp-content/uploads/2018/11/phenotypes-of-sirtuins.png)

**Figure 5. Phenotypes of sirtuin knockout or transgenic mice.** Image credit: [Nakagawa and Guarente, 2011](https://jcs.biologists.org/content/124/6/833), *Journal of Cell Science*

## The NIH/ITP studies on resveratrol [55:45]

- The first Interventions Testing Program (ITP) study on resveratrol showed treatment of resveratrol (at 50 and 200 mg/kg), beginning at 12 mo of age, did not have significant effects on survival in wild-type (WT) male or female mice
- The second ITP study showed treatment of resveratrol, beginning at 4 mo of age, did not have significant effects on the lifespan of male or female WT mice
- David says the studies showed what we already knew: If you give resveratrol in regular food it doesn’t extend lifespan

## Does David take any compounds for longevity? [1:00:15]

- NMN (750 mg)
- Resveratrol (1,000 mg)
- Metformin (1,500 mg)
- David likes experimenting: starting very low with compounds and slowly working up
- He [cautions](https://www.linkedin.com/pulse/advice-article-david-sinclair/?published=t) that this should not be taken as advice

## NAD precursors (NR, NMN) and pterostilbene [1:02:45]

- Nicotinamide riboside (NR) in the body is converted to NMN
- NMN is then immediately converted to NAD+
- There’s a dispute as to whether high plasma levels of NR translates into higher NAD levels in the cells
- Very difficult to determine if the NAD is being taken up by the muscle cells and the brain for example, and measuring if this is occurring
- NMN is more stable than NR according to David
- Pterostilbene (PT) is essentially methylated resveratrol
  - Lenny Guarente believes it’s a more active form than resveratrol
- Guarente’s company sells a supplement that contains NR and PT
- Another company, Chromadex, sells NR (Niagen)
- Sinclair is looking at NMN, but he’s going down a different route
- David receives a lot of claims via email from people taking NR or NMN and improving athletic performance
- David is working on NAD precursor molecules at Metro Biotech

## Female fertility and NAD precursors [1:14:45]

- [Jumpstart Fertility](https://www.linkedin.com/showcase/jumpstart-fertility/): effects of these molecules on patients with low fertility
- There’s a protein called BubR1 that regulates spindle quality
- This protein is regulated by the SIRT2 protein, which requires NAD+
- Eggs come out healthy and more numerous
- Fertility trials will start in the next year in fertility clinics

![](https://peterattiamd.com/wp-content/uploads/2018/11/null.png)

**Figure 6. The Hallmarks of Aging.** Image credit: [López-Otín, et al., 2013 in *Cell*](https://www.cell.com/cell/fulltext/S0092-8674(13)00645-4?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS0092867413006454%3Fshowall%3Dtrue)

The nine “hallmarks of aging” (Figure 6):

1. genomic instability,
2. telomere attrition,
3. epigenetic alterations,
4. loss of proteostasis,
5. deregulated nutrient sensing,
6. mitochondrial dysfunction,
7. cellular senescence,
8. stem cell exhaustion, and
9. altered intercellular communication.

## A unifying theory of aging [1:20:30]

- The compact disc (CD) of our lives (i.e., our genome) is still intact as we’re old, but it’s as if we have a scratched CD, and the cells don’t read the right genes (i.e., our epigenome) at the right times anymore, and they lose their identity
- The genome is digital information: the genome is fairly intact in old people and old animals
- So what’s going wrong? The other information you inherit from your parents is the epigenetic information: the pattern of gene expression: which genes are turned on and off, and at which time
- That is analog information, instead of just being a single code it has to operate in three dimensions
- Adapting to our environment
- What’s going on with aging is you’re getting a scratched CD
- Aging is just a loss of information (2nd law of thermodynamics), but it’s not the genome
- There are a lot of mutations that don’t accelerate aging
- If there was a loss of information in aging, we couldn’t sequentially clone animals as we do
- The genome is digital information, hard to lose that information
- There’s an analog system on top of that: that’s the reader of the CD
- In the cell, those are the readers of the gene
- So we don’t lose information in the genome, but the epigenome
- The structure of how the DNA is read
- If that’s true, it’s good news because mutations are pretty hard to reverse, but turning on and turning off genes is not hard to reverse, you just need to know how to tell the cell how to do it
- It’s the equivalent of getting a polish of your CD and fixing something of the scratches and the ability to read all of the DNA — If you’re 60-80, all of the information to be young is still in your body, your cells just lost the ability how to read it

## Waddington’s epigenetic landscape [1:23:00]

- Conrad Waddington’s landscape: our cells viewed as marbles that start at the top of a mountainscape (Figure 7)
- A cell that starts at embryogenesis is at the top of the mountain
- The embryo can roll down this mountain and become any cell
- The cells go down into valleys that determine the fate of the cell (i.e., differentiation)
- They settle into valleys, and this is how cells know what they are (e.g., hepatocyte, neuron)
- With aging, there is a vibration of noise over time, and we lose our patterns of gene expression, we lose that information, and these loops become dysregulated over time, and the cells change shape
- It’s as though the marbles start to drift into other valleys (e.g., the liver cells are behaving like neurons)
- How can we get the marbles to go back into the valleys in which they came from? That’s the secret to immortality: to get the cells to start acting the way they did when we were 20 years old
- David and his colleagues are writing up papers right now for this, showing they’re able to manipulate the epigenome in cells in mice
- The prediction is that you address all of the hallmarks of aging

![](https://peterattiamd.com/wp-content/uploads/2018/11/null.jpeg)

**Figure 7. Waddington’s landscape.** Image credit: [Waddington, 1957](https://www.amazon.com/Strategy-Genes-C-H-Waddington/dp/1138017310)

- Why do you get loss of gene regulation? DNA breaks in the broken chromosomes distract the SIR complex and they move away and you get the expression of genes that have no right being on
- Because the sirtuins are distracted from the deactivation function and they’re dealing with the repair function
- Insults to the genome: one of the major insults is a double-strand break
- Factors that control gene expression silencing and other things have a dual role
- Repair and other things such as responding to stresses
- This is the cells way of coordinating gene expression changes: hunkering down during times of adversity and going off to repair the system
- Eventually, these proteins will go repair those breaks and then go back to where they came from to settle down the response, to turn off the inflammation, to turn off the DNA repair when it’s not needed
- But the problem may be [antagonistic pleiotropy](https://en.wikipedia.org/wiki/Antagonistic_pleiotropy_hypothesis)
- Peter Medawar and others (like [George C. Williams](https://en.wikipedia.org/wiki/George_C._Williams_(biologist)) and [J.B.S. Haldane](https://en.wikipedia.org/wiki/J._B._S._Haldane)) in the 50s speculated that things that are really good for you when you’re young come back to bite you in the ass when you’re older
- Response to these stresses, like a DNA break, end up not just distracting these proteins but end up disrupting the actual structure of our chromatin, and these proteins don’t always go back to where they came from 100%
- Do that for 70 or 80 years, and it’s not surprising that the genes that were once perfectly programmed and turned on at the right time lose their ability to do that: and we’ve got remnants of that program when we’re 70 and 80
- What’s exciting is that information is still there to be accessed
- The question is how do you get the cells to remember to access the information at the right time

## If David had unlimited resources, what is the experiment he would do? [1:28:25]

- Take a group of 5,000 people, give them the potentially anti-aging medicine, and wait three 3-4 years, and you’d know from that number of people (in their 70s) that you’re changing the hazard ratio, the mortality rate
- Do multiple experiments

## Testing combinations to extend lifespan [1:31:30]

- There are several pathways (and overlap in those pathways) that may be involved in slowing the aging process
- Testing combinations of genes and combinations of molecules
- David has some early data on genetically modifying adult mice with [adeno-associated virus](https://en.wikipedia.org/wiki/Adeno-associated_virus) (AAV), put all seven sirtuin genes into old mice and also gave them NMN
- There are additive effects when you do both of those things
- In theory, all seven sirtuins should be good, and their lack of NAD+ could be the problem in older people
- Instead of just activating one sirtuin, activating all seven and replenishing what’s been lost over time: seven sirtuins should be better than one

## What made David aware of his mortality at such a young age? [01:33:45]

- It all started with David’s grandmother
- She very bluntly told David that everything is going to die
- While people generally don’t like to think about death, David thinks about it all the time

## What is David’s book going to cover? [01:37:15]

- Everything from what he’s learned in his career and his life with his kids
- Understanding why we age, a universal hypothesis of aging, how to combat aging, and the consequences of what happens when we do push it back
  - What happens to planet Earth? What happens to humanity? What happens to your family? What do we have to get ready for economically and socially?

§

§

## Selected Links / Related Material

**Richard Dawkins book**: [The Selfish Gene](https://www.amazon.com/Selfish-Gene-Popular-Science/dp/0192860925) by Richard Dawkins | (amazon.com) [6:00]

**Cynthia Kenyon and colleagues’ experiment showing increased lifespan in daf-2 mutant worms**: [A C. elegans mutant that lives twice as long as wild type](https://www.ncbi.nlm.nih.gov/pubmed/8247153/) (Kenyon et al., 1993) [6:00]

**Kenyon article describing the discovery of daf-2 that regulates aging**: [The first long-lived mutants: discovery of the insulin/IGF-1 pathway for ageing](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3001308/) (Kenyon, 2011) [6:00]

**Michael Hall investigating the action of rapamycin in yeast and TOR (target of rapamycin)**: [Targets for cell cycle arrest by the immunosuppressant rapamycin in yeast](https://www.ncbi.nlm.nih.gov/pubmed/1715094) (Heitman, Movva, and Hall, 1991) [9:00]

**Discovery of sirtuins and a string of *Cell* papers**: [17:00]

- [Redistribution of Silencing Proteins from Telomeres to the Nucleolus Is Associated with Extension of Life Span in S. cerevisiae](https://www.ncbi.nlm.nih.gov/pubmed/9150138) (Kennedy et al., 1997)
- [Extrachromosomal rDNA Circles— A Cause of Aging in Yeast](https://www.ncbi.nlm.nih.gov/pubmed/9428525) (Sinclair and Guarente, 1997)
- [Molecular mechanisms of yeast aging](https://www.ncbi.nlm.nih.gov/pubmed/9584615) (Sinclair, Mills, and Guarente, 1998)
- [Molecular Biology of Aging](https://www.ncbi.nlm.nih.gov/pubmed/9988222) (Johnson, Sinclair, and Guarente)
- [MEC1-Dependent Redistribution of the Sir3 Silencing Protein from Telomeres to DNA Double-Strand Breaks](https://www.ncbi.nlm.nih.gov/pubmed/10367890) (Mills, Sinclair, and Guarente)

***Science* paper**: [Accelerated Aging and Nucleolar Fragmentation in Yeast sgs1 Mutants](https://science.sciencemag.org/content/277/5330/1313) (Sinclair, Mills, and Guarente, 1997) [11:45]

**Sir2 identification**: [SIR2 and aging: an historical perspective](https://web.mit.edu/biology/guarente/yeast/sir2.html) | MIT (web.mit.edu) [12:15]

**Paper with Kevin Mills discovering sirtuins are also involved in DNA repair (included in the string of *Cell* papers above)**: [MEC1-Dependent Redistribution of the Sir3 Silencing Protein from Telomeres to DNA Double-Strand Breaks](https://www.ncbi.nlm.nih.gov/pubmed/10367890) (Mills, Sinclair, and Guarente) [13:30] [18:30]

***Cell* paper with Brian Kennedy showing the movement of sirtuins to the *AGE* locus (also included in the string of *Cell* papers above)**: [Redistribution of Silencing Proteins from Telomeres to the Nucleolus Is Associated with Extension of Life Span in S. cerevisiae](https://www.ncbi.nlm.nih.gov/pubmed/9150138) (Kennedy et al., 1997) [16:00]

**George Martin paper in *Science* where he cloned the gene responsible for Werner Syndrome**: [Positional cloning of the Werner’s syndrome gene](https://www.ncbi.nlm.nih.gov/pubmed/8602509) (Yu et al., 1996) [17:00]

**George Martin discussing the genes for Werner syndrome and Hutchinson-Gilford progeria**: [What do we know about the cause of Werner syndrome and progeria, the disease that leads to premature aging in children?](https://www.scientificamerican.com/article/what-do-we-know-about-the-1999-10-21/) | Scientific American (scientficamerican.com) [17:00]

***Science*** paper on sgs1 and accelerated aging (also included above in the string of papers): [Accelerated Aging and Nucleolar Fragmentation in Yeast sgs1 Mutants](https://science.sciencemag.org/content/277/5330/1313) (Sinclair, Mills, and Guarente, 1997) [17:30]

**Kaeberlein overexpressing the Sir2 gene in a yeast cell promoting longevity**: [The SIR2/3/4 complex and SIR2 alone promote longevity in Saccharomyces cerevisiae by two different mechanisms](https://www.ncbi.nlm.nih.gov/pubmed/10521401) (Kaberlein, McVey, and Guarente, 1999) [20:30]

**2003 paper on resveratrol and extension of lifespan in yeast**: [Small molecule activators of sirtuins extend Saccharomyces cerevisiae lifespan](https://www.ncbi.nlm.nih.gov/pubmed/12939617) (Howitz et al., 2003) [27:00]

**Sirtuins are NAD+-dependent deacetylases**: [Sirtuins: NAD(+)-dependent deacetylase mechanism and regulation](https://www.ncbi.nlm.nih.gov/pubmed/23102634) (Sauve and Youn, 2012) [29:00]

**2007 Paper showing an increase in mitochondrial NAD+**: [Nutrient-Sensitive Mitochondrial NAD+ Levels Dictate Cell Survival](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3366687/) (Yang et al., 2007) [31:15]

**Sirtuins are NAD-dependent**: [Transcriptional silencing and longevity protein Sir2 is an NAD-dependent histone deacetylase](https://www.ncbi.nlm.nih.gov/pubmed/10693811) (Imai et al., 2000) [32:45]

**The mitochondrial oasis effect**: referred to in [Yang et al., 2007](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3366687/) [33:26]

**Kevin Bitterman put nicotinamide on yeast**: [Inhibition of silencing and accelerated aging by nicotinamide, a putative negative regulator of yeast sir2 and human SIRT1](https://www.ncbi.nlm.nih.gov/pubmed/12297502) (Bitterman et al., 2002) [36:45]

**PNC1 can mimic caloric restriction and raise NAD+ availability**: [Nicotinamide and PNC1 govern lifespan extension by calorie restriction in Saccharomyces cerevisiae](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4802858/) (Anderson et al., 2003) [39:00]

**Study of the effects of resveratrol on worm and fly lifespan found to be Sir-2-dependent**: [Sirtuin activators mimic caloric restriction and delay ageing in metazoans](https://www.nature.com/articles/nature02789) (Wood et al., 2004) [45:00]

**Effects of resveratrol and yeast lifespan found to be Sir2-dependent**: [Small molecule activators of sirtuins extend Saccharomyces cerevisiae lifespan](https://www.ncbi.nlm.nih.gov/pubmed/12939617) (Howitz et al., 2003) [27:00]

**2006 *Nature* paper showing improved survival in fat mice taking resveratrol**: [Resveratrol improves health and survival of mice on a high-calorie diet](https://www.ncbi.nlm.nih.gov/pubmed/17086191) (Baur et al., 2006) [47:15]

**Resveratrol activating AMPK as well**: [Supplementary figure 3](https://media.nature.com/original/nature-assets/nature/journal/v444/n7117/extref/nature05354-s2.pdf) in “Resveratrol improves health and survival of mice on a high-calorie diet” (Baur et al., 2006) [50:00]

**Resveratrol and alternate day feeding (ADF) in mice**: [Resveratrol delays age-related deterioration and mimics transcriptional aspects of dietary restriction without extending lifespan](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2538685/) (Pearson et al., 2008) [50:30]

**First ITP study showing treatment of resveratrol (at 50 and 200 mg/kg), beginning at 12 mo of age, did not have significant effects on survival in WT male or female mice**: [Rapamycin, But Not Resveratrol or Simvastatin, Extends Life Span of Genetically Heterogeneous Mice](https://www.ncbi.nlm.nih.gov/pubmed/20974732) (Miller et al., 2009) [53:30]

**Second ITP study showing treatment of resveratrol, beginning at 4 mo of age, did not have significant effects on the lifespan of male or female WT mice**: [Evaluation of Resveratrol, Green Tea Extract, Curcumin, Oxaloacetic Acid, and Medium-Chain Triglyceride Oil on Life Span of Genetically Heterogeneous Mice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3598361/) (Strong et al., 2012) [53:30]

**Meta-analysis and systematic review of resveratrol studies in humans with type 2 diabetes**: [Effects of resveratrol on glucose control and insulin sensitivity in subjects with type 2 diabetes: systematic review and meta-analysis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5610395/) ([Zhu et al., 2017](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5610395/)) [56:15]

**Sirtuin-activating compounds (STACs) extends survival in mice on a standard diet**: [SRT2104 extends survival of male mice on a standard diet and preserves bone and muscle mass](https://www.ncbi.nlm.nih.gov/pubmed/24582957) (Mitchell et al., 2014) [58:30]

**What compounds David takes**: [This is not an advice article](https://www.linkedin.com/pulse/advice-article-david-sinclair/?published=t) | David Sinclair (linkedin.com) [1:00:15]

**Rabinowitz paper on NAD and getting into the body**: [Quantitative Analysis of NAD Synthesis-Breakdown Fluxes](https://www.cell.com/cell-metabolism/pdfExtended/S1550-4131(18)30196-7) (Liu et al., 2018) [1:09:45]

**Studies of NR (and PT) and PBMCs in humans and plasma**:

- [Repeat dose NRPT (nicotinamide riboside and pterostilbene) increases NAD+ levels in humans safely and sustainably: a randomized, double-blind, placebo-controlled study](https://www.nature.com/articles/s41514-017-0016-9) (Dellinger et al., 2017) [1:10:45]
- [Chronic nicotinamide riboside supplementation is well-tolerated and elevates NAD+ in healthy middle-aged and older adults](https://www.nature.com/articles/s41467-018-03421-7) (Martens et al., 2018) [1:10:45]

**Female fertility and NAD precursors**: [Rejuvenating the Chance of Motherhood?](https://www.technologyreview.com/s/603065/rejuvenating-the-chance-of-motherhood/) | Karen Weintraub (technologyreview.com) [1:14:45]

**BubR1, spindle assembly, and quality**: [SIRT2 induces the checkpoint kinase BubR1 to increase lifespan](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4194088/) (North et al., 2014) [1:15:15]

**Hallmarks of aging**: [The Hallmarks of Aging](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3836174/) (López-Otín et al., 2013) [1:19:30]

**The genome is digital information, Sinclair lecture**: [Live Longer, Live Better Lecture Series — Why Reversing Aging is Easier Than Reversing Baldness](https://www.youtube.com/watch?v=DofU0GRtM9w&t=2834s) | MDI Biological Laboratory (youtube.com) (Sinclair’s talks with the CD figure): [1:22:15]

**Waddington’s landscape**: [The Strategy of the Genes by Conrad Waddington](https://www.amazon.com/Strategy-Genes-Routledge-Library-Editions-dp-1138998133/dp/1138998133/ref=mt_paperback?_encoding=UTF8&me=&qid=) | (amazon.com) [1:23:00]

**David’s study proposal of NMN on a novel model of accelerated aging mice known as ICE mice (Induced Changes In Epigenome)**: [CAN NMN INCREASE LONGEVITY?](https://www.lifespan.io/campaigns/can-nmn-increase-longevity/) | lifespan.io (lifespan.io) [1:28:00]

**Peter Medawar and the mutation accumulation theory**: [An Unsolved Problem in Biology](https://www.amazon.com/unsolved-problem-biology-P-Medawar/dp/B0000CIFBD) by Peter Medawar | (amazon.com) [1:28:15]

**George Williams and antagonistic pleiotropy**: [Pleiotropy, Natural Selection, and the Evolution of Senescence](https://www.jstor.org/stable/2406060?seq=1#page_scan_tab_contents) (Williams, 1957) [1:28:15]

**Nir Barzilai’s effort to look at metformin as a treatment for aging**: [Metformin as a Tool to Target Aging](https://www.ncbi.nlm.nih.gov/pubmed/27304507) (Barzilai et al., 2016)[1:30:30]

**David’s TED Talk on aging**: [A Cure for Ageing?: David Sinclair at TEDxSydney](https://www.youtube.com/watch?v=vCCdmGKtxPA) | TEDx Talks (youtube.com)[1:37:15]

§

§

## People Mentioned

- [David M. Sabatini](https://peterattiamd.com/davidsabatini/) (professor of biology at MIT, seminal work on mTOR and rapamycin, mutual friends of Peter and David Sinclair) [6:30, 1:12:30]
- [Leonard “Lenny” Guarente](https://en.wikipedia.org/wiki/Leonard_P._Guarente) (professor of biology at MIT, seminal work on sirtuins, founder of Elysium) [7:30]
- [Nicanor Austriaco](https://twitter.com/friaronwater) (David’s colleague at MIT) [9:00]
- [Brian Kennedy](https://en.wikipedia.org/wiki/Brian_K._Kennedy) (Sir2 work at MIT) [9:00]
- [Doug Melton](https://en.wikipedia.org/wiki/Douglas_A._Melton) (endocrinology and stem cells at Harvard) [5:00] [10:45]
- [Richard Dawkins](https://twitter.com/RichardDawkins) (biologist, author, *The Selfish Gene*) [6:00] [11:45]
- [Cynthia Kenyon](https://en.wikipedia.org/wiki/Cynthia_Kenyon) (work on *C elegans*, daf-2 and daf-16, IGF-1 and FOXO homologs) [11:45]
- [Matt Kaeberlein](https://peterattiamd.com/mattkaeberlein/) (received Ph.D. at MIT with Guarente as advisor) [13:00]
- [Michael Hall](https://en.wikipedia.org/wiki/Michael_N._Hall) (TOR pioneer) [9:00] [14:30]
- [Solomon “Sol” Snyder](https://en.wikipedia.org/wiki/Solomon_H._Snyder) (Sabatini’s Ph.D. advisor, mTOR) [9:00] [14:30]
- [Kevin Mills](https://www.linkedin.com/in/kevin-mills-20783914/) (sirtuin work at MIT) [18:30]
- [George Martin](https://www.linkedin.com/in/george-martin-a6ab885/) ([Hutchinson-Gillford](https://ghr.nlm.nih.gov/condition/hutchinson-gilford-progeria-syndrome) gene cloning) [17:15]
- [Shin-ichiro Imai](https://www.linkedin.com/in/shin-ichiro-imai-5a19802a/) (discovered sirtuins are NAD-dependent) [32:45]
- [Anthony Sauve](https://www.linkedin.com/in/anthony-sauve-7453052b/) (mitochondrial oasis hypothesis, with Sinclair) [33:15]
- [Kevin Bitterman](https://twitter.com/KevinBitterman) (venture capitalist, worked with Sinclair) [36:45]
- [Konrad Howitz](https://www.linkedin.com/in/konrad-howitz-27b70516/) (formerly at Biomol) [40:00]
- [Rob Zipkin](https://www.linkedin.com/in/rob-zipkin-a3b8a52/) (formerly at Biomol) [42:00]
- [Marc Tatar](https://vivo.brown.edu/display/mtatarph) (Brown University, aging research) [45:15]
- [Stephen Helfand](https://vivo.brown.edu/display/shelfand) (Brown University, aging research) [45:15]
- [Rafael “Rafa” de Cabo](https://irp.nih.gov/pi/rafael-de-cabo) (NIH Senior Investigator, aging) [58:15]
- [Conrad Hal Waddington](https://en.wikipedia.org/wiki/C._H._Waddington) (Waddington’s landscape) [1:23:45]
- [Peter Medawar](https://en.wikipedia.org/wiki/Peter_Medawar) (antagonistic pleiotropy): [1:28:15]
- [Nir Barzilai](https://en.wikipedia.org/wiki/Nir_Barzilai) (Director of the Longevity Genes Project, spearheading a study on metformin to target aging [[TAME trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5943638/)]) [1:30:30]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/11/sinclair-bio-image-photo-pic-300x300.jpeg)

##### David Sinclair, Ph.D.

David A. Sinclair, Ph.D. is a Professor in the Department of Genetics at Harvard Medical School and co-Director of the Paul F. Glenn Center for the Biological Mechanisms of Aging.

He is best known for his work on understanding why we age and how to slow its effects. He obtained his Ph.D. in Molecular Genetics at the University of New South Wales, Sydney in 1995. He worked as a postdoctoral researcher at M.I.T. with Dr. Leonard Guarente where he co-discovered a cause of aging for yeast as well as the role of Sir2 in epigenetic changes driven by genome instability. In 1999 he was recruited to Harvard Medical School where his laboratory’s research has focused primarily on understanding the role of sirtuins in disease and aging, with associated interests in chromatin, energy metabolism, mitochondria, learning and memory, neurodegeneration, and cancer. He has also contributed to the understanding of how sirtuins are modulated by endogenous molecules and pharmacological agents such as resveratrol.

Dr. Sinclair is co-founder of several biotechnology companies (Sirtris, Ovascience, Genocea, Cohbar, MetroBiotech, ArcBio, Liberty Biosecurity) and is on the boards of several others. He is also co-founder and co-chief editor of the journal Aging. His work is featured in five books, two documentary movies, 60 Minutes, Morgan Freeman’s “Through the Wormhole” and other media.

He is an inventor on 35 patents and has received more than 25 awards and honors including the CSL Prize, The Australian Commonwealth Prize, Thompson Prize, Helen Hay Whitney Postdoctoral Award, Charles Hood Fellowship, Leukemia Society Fellowship, Ludwig Scholarship, Harvard-Armenise Fellowship, American Association for Aging Research Fellowship, Nathan Shock Award from the National Institutes of Health, Ellison Medical Foundation Junior and Senior Scholar Awards, Merck Prize, Genzyme Outstanding Achievement in Biomedical Science Award, Bio-Innovator Award, David Murdock-Dole Lectureship, Fisher Honorary Lectureship, Les Lazarus Lectureship, Australian Medical Research Medal, The Frontiers in Aging and Regeneration Award, Top 100 Australian Innovators, and TIME magazine’s list of the “100 most influential people in the world”. [[medapps.med.harvard.edu](https://medapps.med.harvard.edu/agingresearch/index.php/about/staff/sinclair)]

David on LinkedIn: [David A. Sinclair, Ph.D. A.O.](https://www.linkedin.com/in/sinclairda/)

David on Twitter: [@davidasinclair](https://twitter.com/davidasinclair?lang=en)