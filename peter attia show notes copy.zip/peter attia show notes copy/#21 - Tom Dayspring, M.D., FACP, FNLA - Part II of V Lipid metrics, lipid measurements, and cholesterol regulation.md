# #21 – Tom Dayspring, M.D., FACP, FNLA – Part II of V: Lipid metrics, lipid measurements, and cholesterol regulation

**Source:** [https://peterattiamd.com/tomdayspring2/](https://peterattiamd.com/tomdayspring2/)

---

##### Check out our 5-part series with Thomas Dayspring, M.D., FACP, FNLA, a world-renowned expert in lipidology:

- *(October 15, 2018)* [Part I of V: An introduction to lipidology](/tomdayspring1/)
- *(October 16, 2018)* [Part II of V: Lipid metrics, lipid measurements, and cholesterol regulation](/tomdayspring2/)
- *(October 17, 2018)* [Part III of V: HDL, reverse cholesterol transport, CETP inhibitors, and apolipoproteins](/tomdayspring3/)
- *(October 18, 2018)* [Part IV of V: statins, ezetimibe, PCSK9 inhibitors, niacin, cholesterol and the brain](/tomdayspring4/)
- *(October 19, 2018)* [Part V of V: Lp(a), inflammation, oxLDL, remnants, and more](/tomdayspring5/)
- *(September 21, 2020)* [**FOLLOW-UP:** The latest insights into cardiovascular disease and lipidology](/tomdayspring6/)

In this five-part series, Thomas Dayspring, M.D., FACP, FNLA, a world-renowned expert in lipidology, and one of Peter’s most important clinical mentors, shares his wealth of knowledge on the subject of lipids. In Part II, Tom provides a 101 on lipids and lipoproteins. Tom and Peter also discuss the history and techniques used to measure lipoproteins, and more.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/tomdayspring2/the_Drive_public.png)

Play

#21 - Tom Dayspring, M.D., FACP, FNLA – Part II of V: Lipid metrics, lipid measurements, and cholesterol regulation

#21 - Tom Dayspring, M.D., FACP, FNLA – Part II of V: Lipid metrics, lipid measurements, and cholesterol regulation

1x15s30s

0:001:26:55

We discuss:

- Lipoprotein basics [1:30];
- Gofman and the ultracentrifuge [5:15];
- Lipoprotein structure, function, metabolism [6:45];
- Lipoprotein and cholesterol measurement, and NMR technology [15:15];
- LDL-C vs LDL-P and apoB [30:45];
- Sterols and cholesterol synthesis [39:45]; and
- More.

§

## Show Notes

## Lipoprotein basics [1:30]

Peter Attia: Now, before we could measure anything that had to do with lipoproteins, if my memory serves me correctly, it would have been the late ’40s, very early ’50s, when the first assays were developed, maybe it was 1951, that could actually just measure total cholesterol. So, you would take plasma from a patient, you would presumably in an assay breakdown all of the lipoproteins, and just aggregate the total amount of cholesterol, and you would yield that number, which still amazingly shows up on a panel today. You go and get a blood test, and it might say your total cholesterol is 200 milligrams per deciliter. So, am I correct, that was the early ’50s maybe?

Tom Dayspring: No, I think they were analyzing cholesterol long before that, because that’s a molecule. You can take blood and dissolve whatever you got to dissolve and cholesterol appears, so they had cholesterol measurements for a long, long time ([Olsen, 1998](https://academic.oup.com/jn/article/128/2/439S/4724045)). It’s like the first lipid anybody could ever measure.

Tom Dayspring: What you’re talking about in the ’50s is where [John Gofman](https://en.wikipedia.org/wiki/John_Gofman) (Figure 1) discovered that, “Hey, wait a minute, there are no lipids floating around in plasma, because lipids are incredibly hydrophobic. Your plasma’s water. You can’t have lipids circulating in plasma” ([Gofman et al., 1949](https://www.ncbi.nlm.nih.gov/pubmed/18150027)). So, lipids obviously have to be within what I call, water-soluble lipid transportation vehicles. And that turns out of course to be a lipoprotein, a protein wrapped collection of hydrophobic and amphipathic lipids that just wouldn’t be in your plasma unless they’re attached to a protein.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-65.png)

**Figure 1. Dr John Gofman at the ultracentrifuge.**

Tom Dayspring: Peter mentioned albumin, and it’s a protein, so lipids can attach to albumin and be circulated around, and other types of proteins, but albumin is the most frequent protein in the blood, so it serves as a carrier. I think an albumin can carry like 17 molecules of cholesterol, a few phospholipids, too. So, it’s a player [in the lipid transportation system]. We got a ton of albumin in our plasma, so you’d be shocked to find out how much cholesterol is in it. Not quite as much as in lipoproteins ([Hellerstein and Turner, 2014](https://www.ncbi.nlm.nih.gov/pubmed/24362356)).

Peter Attia: Albumin is kind of an amazing protein, it’ll carry hormones, it’ll carry just about anything. It’s remarkable.

Tom Dayspring: Yeah. And it has everything to do with osmotic pressures and things like that. So albumin is kind of an essential protein to say the least, performing many, many functions. But when John Gofman, a physicist by the way, physicists have been playing with ultracentrifuges for a long time, separating their radioactive particles. He somehow wound up separating lipoproteins, or saw things floating around in a centrifuge test tube, that he then identified as the lipoproteins.

Tom Dayspring: So, if you learn nothing else today, the first thing is, lipids, for the most part, go nowhere in the human body, unless they’re a passenger inside a lipoprotein (note from Tom Dayspring: *this is the all-time lipid treatise*: [Fredrickson, Levy, and Lees, 1967](https://www.nejm.org/doi/full/10.1056/NEJM196701262760406)) (Figure 2). So, if you believe there are a lot of lipid-associated diseases, and I certainly believe atherosclerosis is one: you cannot have atherosclerosis without a sterol lipid being in your arterial wall ([Nathan, 2017](https://www.ncbi.nlm.nih.gov/pubmed/28663517)), and I know that arterial wall didn’t over-synthesize sterols, creating a sterol build-up. Somebody had to deliver those sterols there, and that turns out to be a lipoprotein.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-66.png)

**Figure 2. The classic, landmark editorial by Fredrickson, Levy and Lees in *Circulation* describing electrophoretic separation and nomenclature of lipoproteins.** Key point is that lipids are trafficked within protein enwrapped vehicles called lipoproteins.

Tom Dayspring: And one of the places a lipoprotein should never deliver sterols to, to any serious degree, of course, is your arterial wall intima. So, being a Jersey guy, one of my standard jokes on the lecture circuit, was atherosclerosis is just the evidence of illegal dumping where a lipoprotein, instead of bringing lipids to wherever it’s supposed to be bringing it, was bringing sterols to the arterial wall. And over decades you got a problem. You could do it for a few days, six months, you’re not going to die of atherosclerotic disease.

## Gofman and the ultracentrifuge [5:15]

Peter Attia: So Gofman figures out by first principles basically. He imputes that there’s got to be something that is transporting this very, very hydrophobic molecule through plasma (note from Tom Dayspring: *he imputed first, but then linked it to outcomes in this classic paper*: [Gofman et al., 1956](https://www.ahajournals.org/doi/pdf/10.1161/01.cir.14.4.689)). It’s easy in retrospect to make light of what an observation that is, but the next observation would be, it would need to be spherical, right? I mean, to optimize the volume in which you could transport, it would have to be spherical.

Tom Dayspring: Correct. You’re a mathematician. A volume of the sphere, the third power of the radius. So, if you’re going to devise a transportation vehicle, a sphere is better than a flatbed truck, you know?

Peter Attia: Yeah. I know the answer to this question, but I just have to sort of tee it up, who then went on to figure out these things occur in different densities, it’s not just one? There’s not just one spherical molecule that’s transporting these things. Because this is a beautiful story, right?

Tom Dayspring: Yeah. It was Gofman [note from Tom Dayspring: *ultracentrifugation separates particles by density*] (Figure 3). He noticed that – and they weren’t calling them apoB and apoA-I particles at the time – they were different densities. They were gigantic.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-67.png)

**Figure 3. Preparative ultracentrifugation – The “Gold Standard” methodology for determining LDL-cholesterol – called beta-quantification, is used in research settings.** In a slice tube the various lipoprotein fractions can be isolated, extracted and analyzed for their lipid content. Cole, T et al: Optimization of β-Quantification Methods for High-Throughput Applications Clinical Chemistry 47:4 712–721 (2001).

Peter Attia: So, explain what you mean by density, because this term. Everyone knows low-density lipoprotein, high-density lipoprotein, but tell me where that terminology actually came from.

Tom Dayspring: Well I think it has to do with water has a certain density, so it’s whether things float in water or sink in water. We know rocks sink if we throw it in a pond, so they’re very dense things, whereas other things float on top of water. They obviously are less dense than water is. So, everything is relative to water. If you establish what you think is the density of water, things that float.

## Lipoprotein structure, function, metabolism [6:45]

Tom Dayspring: So, when he separated these things in a centrifuge, the lipoproteins or these fat-balls that didn’t move at all, were obviously very buoyant. Some sunk just a little bit, so they were less buoyant, but still pretty buoyant, and others went right to the bottom of the test tube. Obviously incredibly dense.

Tom Dayspring: And it turns out, what makes a lipoprotein buoyant is a ratio of its lipid-fat content, because I think we all know fat floats on water. Where proteins, check out the molecular weights of proteins, really heavy, they sink. So, they’re the rocks. So your density of a specific particle here, a lipoprotein particle, is going to be related to its lipid content versus its protein content. So, our big monsters that are delivering, as I told you, triglycerides, but have a lot of phospholipids on the surface, they have some proteins, but they have so much lipids they float. They’re the buoyant ones. And as they lose the lipids, they become smaller (and denser), and they might lose a few proteins as they shrink, but they’re really losing the lipids. [Figure 4]

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-68.png)

**Figure 4. Separation of the apolipoprotein B and apolipoprotein A-I particles by buoyancy (density) using the ultracentrifuge.**

**Chylomicrons (intestinally produced)** containing one molecule of apolipoproteinB48 plus several other (multiple copies of) apoproteins: apoA-I, apoC-II, apoA-V, apoE, etc.

**Very Low Density Lipoproteins (VLDL)** are hepatic produced and carry one nontransferable molecule of apolipoprotein B100 plus several other (multiple copies of) apoproteins: apoC-II, apoA-V, apoE, etc.

**Intermediate density Lipoproteins (IDL)** may be hepatic produced or be the lipolytic remnant of an VLDL. They contain one nontransferable molecule of apolipoprotein B100 and also apolipoprotein E.

**Low density lipoproteins (LDL)** which contain one nontransferable molecule of apolipoprotein B100 may be hepatic produced or be the lipolytic remnant of an IDL. A small percentage ca carry other apolipoproteins like E, C-III, A-I.

**High Density Lipoproteins (HDL)** are a mixture of small particles ranging from unlipidated apoprotein A-I to discoid to spherical particles carrying very degrees of phospholipids, free and unesterified cholesterol. HDLs can carry from 1 to 5 molecules of apoA-I. Also present on HDLs may be apoA-II as well as a multitude of other transient trafficked apoproteins. The functionality of specific HDLs are related to their proteome. The largest HDL of which few exist is designated as HDL-1, with HDL-2 family being intermediate in size and HDL-3 the smallest.

**Lipoprotein(a)** is an LDL-like lipoprotein that also contains (bound to apoB100) a single molecule of apoprotein(a).

Note that size and buoyancy of the particle is related to its lipid content: Intestinally produced chylomicrons carry the largest lipid load, with HDLs carrying the least. With each class of lipoproteins are heterogeneous subclasses that vary in size, density and lipid composition. Under physiologic conditions the largest lipoproteins are characteristically TG-rich whereas the small (LDLs and HDLs) are TG-poor and cholesterol-rich. Small particles are always denser thqaqn larger particles, hence using the descriptive term small, dense is a redundancy.

Peter Attia: But they’re fundamentally concentrating protein. When you go from chylomicron, even though they’re not the same lineage, so I want to be very careful. You’ll explain this in detail. You do not go from a chylomicron to a VLDL, to an IDL, to an LDL, to an HDL. They’re three separate lineages I just described. But in size, they loosely track as the smaller they get, the more they’ve concentrated protein.

Tom Dayspring: Within every category of lipoproteins, whether you’re talking chylomicrons, which are intestinally produced, VLDLs (Figure 5), hepatically produced, and the classic teaching is, as VLDLs become smaller, you call them intermediate density (i.e., IDLs). And then low density we now know the liver can produce an LDL de novo.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-69.png)

**Figure 5. Schemata of hepatic secretion of VLDL and lipolysis (hydrolysis of core TG, and surface phospholipids.** Under conditions of TG <130 mg/dL ~40% of the apoB-containing lipoproteins excreted by the liver are LDLs. Thus not all LDLs result from lipolysis of VLDLs. ApoC-II, of which VLDLs carry several copies, is the main ligand for lipoprotein lipase (LPL) expressed in myocytes or adipocytes. ApoA-V helps anchor TG-rich VLDLs to areas where LPL is expressed. ApoE (several copies of which are on VLDLs and IDLs) is a ligand for the LDL receptor or LDL receptor-related protein which clear VLDL, IDLs and LDLs from plasma. LDL-P is a measurement of the number of LDLs, irrespective of size (in nmols) that exist per liter of serum. Also, note that both IDLs and LDLs can be directly produced and secreted by the liver and do not necessarily have to me lipolytic remnants of VLDLs.

Tom Dayspring: High-density lipoproteins (i.e., HDLs), which form themselves in the plasma, sort of go the opposite way, whereas the VLDLs and chylos (short for *chylomicrons*) come out as big fat monsters and lose lipids and become smaller and denser. The HDL, as it gathers lipids, becomes bigger and more buoyant. But, within every class of lipoproteins, you’re going to have a heterogeneous range of densities from big species to small species. And this is why to me, I like to tease, because you always hear people talk about the small, dense LDL. Within every lipoprotein classification, the smaller particle is always more dense. So that’s a redundancy.

Tom Dayspring: Just tell me dense LDL, just say small LDL. I know it has to be dense, or if it’s dense I know it has to be small compared to its sister particles within that family.

Tom Dayspring: So, somehow small has only been applied more frequently to LDLs, because that’s the killer one. Or HDLs, oh my God, you want to have the big HDLs. Another joke that’s turned out, but for the longest while, if you don’t have big HDLs you’re in big trouble. And if you got the small LDLs, you’re in the biggest trouble. That basically turns out to be, because if you have small LDLs you need a ton of them to carry whatever your lipid load is, so you’ve got a super high LDL particle concentration if you have small LDLs.

**[10:00]**

Tom Dayspring: And that’s more related to its pathology per se, than the size, not that *that* wouldn’t also relate with certain functional characteristics of the LDL. [Figure 6]

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-70.png)

**Figure 6. Data from the MESA Study demonstrating that LDLs consist of a heterogenous mixture of variously sized particles (small, medium and large).** Total LDL-P is the collective sum of all of the variously sized LDLs in nmol/L. Note that at all concentrations of small LDL particles, large particles exist and both small and large LDL particles relate to carotid IMT – the highest risk is in patients with increased numbers of both small and large LDL particles.

Tom Dayspring: But the VLDL, the chylos come out big and they shrink. Now, the reason though, that differentiate chylomicrons, and the VLDLs, IDLs, and LDLs, is they have a lot of apoproteins on their surface, which they do lose as they shrink. But there’s one protein they never lose, and it’s the one that has the most massive molecular weight apolipoprotein B.

Tom Dayspring: So, that’s why they are never going to be as dense as an HDL particle, because an HDL doesn’t have this monstrosity-high molecular weight apoB on it. It’s got other things, far less lipids, but to some: the LDLs, IDLs, VLDLs are always going to be way more buoyant, [because they have considerably more lipid molecules than do HDLs].

Tom Dayspring: As you study apoproteins ([Gursky, 2015](https://www.ncbi.nlm.nih.gov/pubmed/15891389)), and we’re probably up to 20 to 30 of them now, all of which have certain functions that it sort of directs a lipoprotein down which path it’s going, a catabolic path. The only apoprotein, by the way, let’s get definitions out the way, apoprotein, apolipoprotein, lipoprotein. An apoprotein is the protein your [hepatocytes or enterocytes] makes. Once it binds to lipids, it’s called an apolipoprotein. And of course, the whole particle itself is called the lipoprotein.

Peter Attia: So, let me re-synthesize that, the lipoprotein is a spherical structure whose membrane is made of mostly these phospholipids, but also other lipids. The apoprotein is the thing that kind of gives it its signature. So for example, the chylomicron has a B48, the IDL, VLDL, and LDL have a B100, etc. That’s just called the apoprotein. Once the apoprotein, and I assume it’s covalently bound to the lipoprotein, that becomes the apolipoprotein. And we abbreviate that Apo, fill in the blank.

Tom Dayspring: Yeah. So, if I took a VLDL particle, and later on I’ll tell you, “Boy, on a VLDL, you’re going to find apoC-I, apoC-II, apoC-III, apoA-V, including apoB. But it’s going to lose everything but apoB, as it sort of shrinks, or you lose most of the other ones, because they’re transferrable. They can jump on a different lipoprotein if they so desire. The apoB never does. For a bunch of reasons, it’s providing the structural integrity to that particle throughout its existence, but apoB also turns out to be the ligand for receptors that internalize those particles when your body don’t need them anymore. So, the LDL receptor that everybody knows about serves as an apoB100 particle clearing receptor.

Peter Attia: So the ligand, just as an analogy for some people listening, it’s like the key that fits into the lock. If the receptor is the lock, the ligand is the key. In Biology that’s sort of how everything works, the key has to fit the lock.

Tom Dayspring: Correct, and if it didn’t, then that lipoprotein is going to stay in your plasma and probably wind up going somewhere where it’s going to create a pathological state.

Peter Attia: So when was it figured out that apolipoproteins are going to come and go, but there’s one of these ones that not only always stays, but you have one. Because that’s a big deal, the realization that apoB100, if you knew that concentration, you had a proxy for how many particles you had.

Tom Dayspring: Yeah. So Gofman certainly figured out there were proteins involved here, but he wasn’t applying that nomenclature to them. It’s guys who a few years further down the road, [Fredrickson](https://en.wikipedia.org/wiki/Donald_S._Fredrickson), [Levy](https://en.wikipedia.org/wiki/Robert_A._Levy), [Lees](https://news.mit.edu/2017/robert-lees-cardiologist-former-mit-faculty-member-dies-0626), [note from Tom Dayspring: *and especially [Petar Alaupovic](https://www.ncbi.nlm.nih.gov/pubmed/24945028): see [Sacks and Brewer, 2014](https://www.ncbi.nlm.nih.gov/pubmed/24945028)*] starting to-

Peter Attia: We’ve talked about those with [Ron Krauss](https://profiles.ucsf.edu/ronald.krauss)–

Tom Dayspring: Realized there are some very important structural and functional proteins on these particles that we better start investigating and giving names to ([Sacks and Brewer, 2014](https://www.ncbi.nlm.nih.gov/pubmed/24945028); [Fredrickson, Levy, and Lees, 1967](https://www.nejm.org/doi/full/10.1056/NEJM196701262760406)). So, their research led to the identification of all of them. And ultimately, I mean, we know now the amino acid breakdown of every darn apoprotein that’s in our body or on our particles.

Tom Dayspring: So, when one researcher invents a little bit of the story, other ones pick up the pieces and start further elaborating on it with different studies. And technology improves and some of these things that were not assayable (i.e., measurable) at one point, become that you can measure them and identify their structure. So it’s one of these evolutionary, discoverable, things.

Tom Dayspring: And it just made such perfect sense too, because we knew these particles are changing, so they’re undergoing catabolic processes. Why? What’s doing that? And then all of a sudden, you figure out that these ligands, these apoproteins, are keys to various receptors. Some of those receptors pull the particle next to where there’s an expression of a lipid dissolving enzyme, a lipase [enabling particle catabolism or lipolysis], and it starts to all make perfect sense to you.

Tom Dayspring: So over time we’ve identified numerous of these enzymes that can catabolize lipoproteins, and numerous of the receptors that temporarily bind these particles in place so they can undergo this thing. Ligands that lipidate, fill the particles with the lipids, or de-lipidate them.

## Lipoprotein and cholesterol measurement, and NMR technology [15:15]

Peter Attia: So, if you’re listening to this and you’re confused at this point, it’s okay. One, there’s going to be killer show notes. But more importantly, we’re going to take a step back now.

Peter Attia: I’m a guy listening to this, I’m a girl listening to this, all I know is, every time I go to the doctor, he or she gets a blood test and it spits out the following: total cholesterol equals this, LDL equals this, HDL equals this, triglyceride equals this, and maybe, it will say non-HDL equals this. What do those things mean in relation to everything you just said?

Tom Dayspring: Yeah. First of all, the misinformation on labeling lipid metrics is one of the things that it’s a miracle hasn’t given me a stroke yet. I do a lot of peer review. I’m one of the associate editors of the Journal of Clinical Lipidology, and I will reject a paper instantly that uses improper lipid metrics. Don’t tell me the LDL is this, because LDL is a low density lipoprotein. It’s not a laboratory metric. You want to tell me what the LDL-cholesterol is, the LDL particle number is, the lipidomics of an LDL, is the LDL oxidized or not? Great. We do have assays that will measure all of those. Don’t identify yourself as an ignoramus. And look, I’ve told this to many of the top lipidologists in the country, well actually, “Stop telling people, what’s your LDL.” Ask them what is your LDL-cholesterol, [whatever specific metric you are alluding to]. If we don’t all talk the talk, you’re never going to understand the process.

Peter Attia: So this patient, almost assuredly, is talking about total cholesterol, LDL-cholesterol, HDL-cholesterol, and non-HDL cholesterol.

Tom Dayspring: Yes. And by the way, Peter did mention something very quickly before that I just wanted to expound, and he talked about apoB100, apoB48. ApoB is a giant, structural, non-transferrable apoprotein that’s on chylomicrons or VLDLs. The intestinal machinery that synthesizes a chylomicron, makes a certain type of apoB, and the apoB that is made in the liver makes a much bigger apoB. It has a higher molecular weight.

Tom Dayspring: So, they knew the apoB that’s being made in the intestine is much smaller. So it turns out to be that the apoB in the intestine is 48% of the molecular weight of the hepatic produced apoB. If you get into genetic disorders of apoB, you’ll see apoB31 that has 31% of the molecular weight of what’s considered a normal apoB. So, when you hear apoB48, that should identify it as an intestinally produced apoB particle. And a liver would be an [apoB100]. LDLs that come out of the liver — no, excuse me — the LDLs have apoB100 on it, like the VLDL. Or a VLDL that becomes an LDL, the apoB100 is still there. If you hear 100 or 48, what does that mean? It sort of tells us the origin [of the particle carrying it — hepatic or intestinal?]

Tom Dayspring: We are going to be talking about nuclear magnetic resonance spectroscopy (NMR), as one of the parameters the lab performing NMR used to give you a lot of information about, less so today, is VLDL particle concentration. When you analyze a lipoprotein using nuclear magnetic resonance, it cannot tell the difference between a chylomicron and a VLDL, because NMR doesn’t measure the proteins. It’s, hey, that’s a very big particle, so it has to be a VLDL or chylos. Most of your big particles are reported as VLDLs. And even in a postprandial state, chylomicrons have half-lives in minutes, they’re gone. So the vast majority of VLDL particle number, via NMR, is still VLDL particles [meaning *not* chylomicrons], but there could be some chylos there.

Peter Attia: All right, but I want to go back to our lady. So, her LDL-cholesterol is 190 milligrams per deciliter. What does that mean?

Tom Dayspring: So, you said her LDL-cholesterol?

Peter Attia: I’m sorry, I’m sorry, her total cholesterol is 190 milligrams per deciliter.

Tom Dayspring: So, total cholesterol, remember my premise that lipids go nowhere in the body unless they’re within a lipoprotein. It’s not exactly true, but for today’s purposes that is true, and certainly understanding lipid metrics, that’s true. So, total cholesterol would be the laboratory has separated all your lipoproteins from the serum, and they take how much cholesterol is in this serum tube.

Tom Dayspring: So, where would that cholesterol be that they’re analyzing? Well, it would be found in, if there were any chylomicrons there that were hanging around, or because they didn’t fast. A miniscule amount of it would be chylomicron cholesterol. Some of it would certainly be VLDL-cholesterol.

**[20:00]**

Tom Dayspring: A lesser amount, because there’s just so few of them that would be intermediate density cholesterol particles, and the rest would either be LDL particles, low-density lipoproteins, or the high-density lipoproteins. There are other types of LDL particles called Lp-little-a [i.e., Lp(a)], which we’ll talk about.

Tom Dayspring: So, total cholesterol is all of the cholesterol molecules in every single lipoprotein that’s in a deciliter of your plasma.

Peter Attia: And that is directly measured, it is not imputed.

Tom Dayspring: That’s an assay, that is not a calculation. That is assayed. But in any lab test there’s always a coefficient of variability that’s inaccurate. So, if you want to use cholesterol for anything nowadays, because let’s face it, that was the first parameter looked at in the epidemiology, and they certainly correlated total cholesterol levels with the risk for heart disease.

Tom Dayspring: But think about what I just told you, it’s the cholesterol within all the lipoproteins. If you counted particles, what is the most numerous particle in your bloodstream (i.e., which lipoproteins carry the most cholesterol)? The apoB particles. Well, actually the HDLs are more particles, but they’re so small they don’t carry much cholesterol.

Tom Dayspring: If you want to put [scare quotes] around it, “atherogenic cholesterol” would be within your apoB particles. So, if you want to ascribe any use to measuring total cholesterol, it represents a real poor man’s apoB level. In general, most people with very high total cholesterol levels will have a very high apoB level. And that’s the real reason they’re at risk for atherosclerosis, because those are the potentially atherogenic particles.

Peter Attia: Yeah, the original epidemiology basically said — and you have to sort of applaud them for doing the best they could with the tools they had — but let’s take total cholesterol, which is at the time the only thing we could measure clinically. Let’s take the patients who are in the top 5% and the patients in the bottom 5%, was there a difference in their risk of MI? And the answer was, yes.

Tom Dayspring: Correct.

Peter Attia: Now, it would be another at least decade until Framingham — this is kind of an interesting story, right? Part of the story got ignored in Framingham was that low HDL-cholesterol and high triglyceride turned out to be four times more predictive of MI, than high LDL-cholesterol. And again, this is still crude measurements, but people didn’t come back to try to explain why that might be the case, until [Jerry Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) had sort of done his work on metabolic syndrome.

Peter Attia: But I also realize, I’m going to get us off-topic. I want to go back to this other question. So, we’ve just explained what a 190 milligrams per deciliter means, when it says HDL, it really means HDL-cholesterol, as evidenced by the units. So this will either be in millimole or milligrams per deciliter. That’s a direct assay or an indirect assay?

Tom Dayspring: Yeah, so Framingham, of course, did measure total cholesterol, which was easily available, they did it. They measured triglycerides too, although they really had no clue what they were related to, but it was measurable. Glycerides, they called it glycerides back then, and they did have a direct assay for HDL-cholesterol.

Tom Dayspring: And you can centrifuge particles. You can take out the LDL fraction and analyze how much cholesterol is in them. That’s theoretically the gold standard [usually referred to as beta quantification]. You can separate the HDL, but that’s too time-consuming. Nobody’s got ultracentrifuges (Figures 1 and 3), so to have real-world tests, chemists had to develop direct assays.

Tom Dayspring: So HDL assays were developed real early on. So Framingham could not only measure total cholesterol, they could directly measure, not calculate HDL-cholesterol. What they could not measure, and it took a long time, was LDL-cholesterol-

Peter Attia: Without ultracentrifugation.

Tom Dayspring: Without ultracentrifugation, correct. In the ’70s, somebody ([Friedewald, Levy, and Fredrickson, 1972](https://www.ncbi.nlm.nih.gov/pubmed/4337382)) came up with a formula that here’s a way of at least estimating or calculating LDLs, which took fire because by the ’70s they realized the most numerous atherogenic lipoprotein were the low-density lipoproteins. So as Framingham started calculating LDL-cholesterol, like, “Whoa! This is the story here. So, they calculated it for the longest while.

Peter Attia: So, just to be clear, what they’re doing is they’re directly measuring total cholesterol, because you can just do that off serum. They precipitate out the HDL, right?

Tom Dayspring: Yep.

Peter Attia: So you could measure the HDL (note from Tom Dayspring: *to be precise, it is the HDL-*cholesterol *that is measured*) without ultracentrifugation, and you could measure triglycerides. So, now, the formula for estimating LDL-cholesterol became total cholesterol minus HDL-cholesterol minus triglycerides over five. Why the triglycerides over five?

Tom Dayspring: Yeah. So [Friedewald](https://www.mailman.columbia.edu/people/our-faculty/wtf1) put two and two together, and realized, hey total cholesterol is in essence VLDL-cholesterol, plus LDL-cholesterol, plus HDL-cholesterol. A equals B plus C plus D. So, if I know parameter A, and I know parameter D, and I know parameters, I can figure out what parameter C is.

Peter Attia: And so what he did was, he said, I’m going to ignore chylomicron, and IDL, and Lp(a). Well, Lp(a) was at that point probably being not even being included in the LDL.

Tom Dayspring: Chylos are counted as VLDLs, and the IDL is counted as LDL. So, therefore, if I know the HDL-cholesterol, and I know the total cholesterol, if I only knew VLDL-cholesterol, I could easily calculate what your LDL-cholesterol was. So, then it becomes, you have to know what is a VLDL particle. And at least, if you have a physiologically normal VLDL particle, most of those lipids are in the core of the particle. There’s no triglycerides on the surface, no cholesteryl ester on the surface. If I only knew the composition of these particles, I could figure out.

Tom Dayspring: So, they came to the realization that, on average, at least in the 1970s, a VLDL particle composition (Figure 7) had five times more triglyceride than it did cholesterol. And virtually in a fasting state, all of the triglycerides, they’re not in an HDL, they’re not in an LDL. We’re not measuring chylomicrons, because of the fasting state they’re in a VLDL.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-71.png)

**Figure 7. Very Low Density Lipoproteins are apoB-100, typically TG-rich particles produced and secreted by the liver.** In this graphic, their apolipoproteins are listed but not shown. Because of the size of the particle, the surface area is large and VLDLs are a major carrier of phospholipids. Under physiologic conditions VLDLs characteristically contain a 5 to 1 ratio of TG to cholesterol and VLDL-C is hence often estimated as TG/5.

Tom Dayspring: So, cholesterol in a VLDL has to be triglycerides divided by five, because there’s 1/5 as much cholesterol in a VLDL particle. So VLDL-C is triglycerides divided by five.

Tom Dayspring: So now, if I have HDL-cholesterol, VLDL-cholesterol, total cholesterol, you do the math, you’re a mathematician, Peter. It’s very easy to, “Aha! This is what your LDL-cholesterol is.” And once they calculated it, then they applied it to clinical trial data. Correlations are very, very good.

Tom Dayspring: And they knew that’s probably where the money is, because of our apoB particles, the particles that are the ones delivering these sterols to the artery wall. The overwhelming majority of them [i.e., the family of apoB-containing lipoproteins], 95%, at the lowest end 90%, are LDL particles. It’s where the money is. We need a metric of LDL (i.e., LDL-particle concentrations), and the calculated LDL-C was the earliest introduction to that.

Tom Dayspring: Now, down the road people have developed direct assays of LDL-cholesterol. But you know what? Turns out it’s not that much more accurate than the calculated [LDL-cholesterol], unless as you start to go up, up, up in triglycerides, that calculation falters so-

Peter Attia: Which is something we’re seeing more and more of today than we saw in the original Framingham.

Tom Dayspring: Yeah, and the original data who said, “Oh boy, if your triglycerides get above 400, don’t use that calculation, it’s ridiculous.” So they actually developed a direct LDL-C to give us an LDL-cholesterol metric. And people with triglycerides of 800, 1200, 4000, where now you know what their LDL-cholesterol is, whereas the formula would be useless there.

Tom Dayspring: We now know that formula starts to become kind of erroneous somewhere between a trig of 150 and 200. And the higher you go above 200, be careful with a calculated LDL-cholesterol. And rely on direct LDL-C.

Tom Dayspring: But, and here’s what nobody realizes, the only value that calculated or directly measured LDL-cholesterol brings to the table is they’re a better poor man’s estimate of your LDL particle concentration than it is total cholesterol. So, an LDL-cholesterol would correlate better with apoB or LDL particle concentration than it would a total cholesterol.

Tom Dayspring: Down the road a little bit, we’ve come to the realization that if we get another calculation called non-HDL cholesterol, that even better correlates with apoB or LDL particle concentration than does LDL-cholesterol. So, that’s why that’s the new thing that’s in vogue.

Tom Dayspring: I know you spent a little time down in Hopkins, some of the lipid guys down there have invented a much better calculated LDL-cholesterol [called the Martin-Hopkins calculation] ([Martin et al., 2013](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1001%2Fjama.2013.280532)), which they’re trying to get incorporated rather than the older calculation, the Friedewald, that we’ve been using forever, and most labs entirely use nowadays.

Peter Attia: My first exposure to NMR was in high school when we were taking organic chemistry. We had these tests. I still remember how fun these tests were, where they would show you an NMR spectroscopy, and you had to figure out what the molecule was, by knowing where those spikes were. So, was [Jim Otvos](https://en.wikipedia.org/wiki/Jim_Otvos) (Figure 8), the guy that first figured out that you could use that stuff to actually count the number of these apoBs?

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-72.png)

**Figure 8. James Otvos – developer of NMR spectroscopy as it applies to lipoproteins.**

Tom Dayspring: Yeah, I think Otvos was certainly one of the early pioneers ([Otvos et al., 1992](https://www.ncbi.nlm.nih.gov/pubmed/?term=CLIN.+CHEM.+38%2F9%2C+1632-1638)), and over time, the real pioneer who evaluated lipids and lipoprotein using nuclear magnetic resonance spectroscopy (NMR). He knew that lipids would emit specific spectra signals that he could analyze. And through very complex mathematics turn them into a whole variety of lipoprotein metrics, including, you can do an NMR, LDL-cholesterol level, and LDL-triglyceride level.

**[30:00]**

Tom Dayspring: In the future, that’s one of the ways we’re going to be measuring phospholipids on various lipoproteins is NMR spectroscopy, because as Peter says, every lipid has a different spectral signal, and if you know what you’re doing you can look at a spectral signal and know what its molecular composition is.

Tom Dayspring: As we had all these lipid metrics that we’re talking about, cholesterol, even triglyceride metrics, deep down the guys know these are just poor man’s way, easily assayable ways of quantifying lipoproteins. And it’s a [particle] quantification that matters in many cases.

Tom Dayspring: So, it turns out, in the long run, it’s the number of apoB particles (Figures 9 and 10) that primarily is what forces it into the artery wall. Very little else matters, I mean there are other factors, but that’s the number one factor.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-73.png)

**Figure 9. Within the circulation, lipids are trafficked on the surface and within the cores of protein enwrapped particles designated as lipoproteins.** A key concept is that lipid movement is therefore lipoprotein driven. Lipoproteins can also use lipid transfer proteins such as CETP, to exchange their core of neutral lipids (lipids that do not carry a charge). On the surface of all lipoproteins are collections of apolipoproteins. Although lipoproteins carry predominantly phospholipids, cholesterol and TG, hundreds of lipid species can be present (in much smaller concentrations than the “big 3.” Lipoproteins are classified by their buoyancy/density.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-74.png)

**Figure 10. Entry of apoB-containing lipoproteins is primarily driven by gradients, meaning the particle concentration.** By far the most numerous apoB-particles are LDLs. LDL entry into arteries is primarily driven by its concentration (particle number) not its size. Classically persons with predominantly small LDL particles typically if not treated have extremely high total LDL particle concentrations. LDL-P can be measured using NMR-spectroscopy, ion mobility transfer or approximated apolipoprotein B (apoB), and less accurately by LDL-cholesterol (LDL-C) or non-HDL-cholesterol (non-HDL-C). Once LDLs enter the artery, apoB binds to arterial wall proteoglycans and Is subject to reactive oxygen species and oxidation.

## LDL-C vs LDL-P and apoB [30:45]

Peter Attia: When was that pathophysiology first stumbled upon ([Contois et al., 2009](https://www.ncbi.nlm.nih.gov/pubmed/19168552)), that it even mattered how many of these particles you have. So let’s just take out the estimates, and let’s assume that you have the ability to measure the total cholesterol concentration within an LDL particle, which is what’s showing up when someone gets a blood test, and it says, “direct”. When it says, “LDL-C direct”, that means they’ve actually measured it. So now, it’s better than Friedewald’s estimation. But that’s different from, if you have an NMR, where it says LDL-P, nanomole per liter. And that’s counting the number of [nanomoles] of particles. So one is the number of particles, the other is the amount of cholesterol contained within them.

Peter Attia: A revisiting of MESA (Figure 11) and Framingham (Figure 12) made unambiguously clear, which is one of those predicts better than the other. But was that really the realization that it was a gradient-driven process by number? Or was that understood beforehand, or at least hypothesized beforehand, and then more verified by the experimental evidence?

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-75.png)

**Figure 11. Data from MESA which reveals that although LDL-C and LDL-P correlate, risk for having a CV event related better to particle numbers (LDL-P) than cholesterol content of LDLs.** When both LDL-P and LDL-P are high, normal, or low, they are said to be concordant. However, when one metric is high and the other is not, or vice versa (called discordance), CV risk and outcomes more closely follows particle concentrations. The only way to recognize that a given patient has discordant LDL-C/LDL-P is to measure both metrics. At extremely high (> 190 mg/dL) or extremely low (< 30-50 mg/dL) levels, LDL-C and LDL-P are almost always concordant.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-76.png)

**Figure 12. Kaplan-Meier survival curves from the Framingham Offspring Study relating CV outcomes to LDL-P and LDL-C.** Nicely demonstrates that risk more closely follows LDL-P than LDL-C. Notice that the persons with the worse survival curve (gold in color) had the lower LDL-C yet higher LDL-P compared to those in green cure with higher LDL-C but lower LDL-P.

Tom Dayspring: No, early on they discovered it was the apoB particles going into the artery wall, and delivering these sterols that set off this maladaptive inflammatory process ([Tabas, 2017](https://www.ncbi.nlm.nih.gov/pubmed/27979856); [Otvos et al., 1992](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1161%2F01.ATV.0000174795.62387.d3); [Williams and Tabas, 2005](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1161%2F01.ATV.0000174795.62387.d3)) that led to a whole other area of investigation. So, the particle number data came, once they sort of identified a way of assaying particle numbers. And they almost evolved that this maybe apoB came a little bit first, but then Jim Otvos’s work on LDL particles came at the same time. And it clearly became: evidence that apoB is a better risk factor than is LDL-C.

Tom Dayspring: And remember, there is one apoB on every VLDL, IDL, and LDL, but 95% of the apoB particles are LDL (Figure 13), so apoB is just a way for the labs to report to you what an LDL particle concentration is (Figure 14). Otvos identified an LDL particle concentration using these methyl signals coming out of the-

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-77.png)

**Figure 13. Classic study by Garvey showing that regardless of insulin sensitivity/resistance status or the presence of T2D, that vast majority of the apoB containing particles are low density lipoproteins (not IDLs or VLDLs).** This is why apoB measurement basically represents LDL-P and provides little information about the presence of VLDLs or VLDL remnants.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-78.png)

**Figure 14. A graphic that identifies ways laboratories can report LDL metrics: Total LDL-P vis NMR spectroscopy is by far the most validated (in clinical trials) metric.** ApoB, also well validated is another metric of LDL-P. LDL-C which represents all of the sterols trafficked in LDLs is simply a surrogate (often discordant from LDL-P and apoB) of LDL particle number. LDL-C can be measured directly by labs or estimated using various formulas. Realize that total LDL-P is the sum of all LDL (big and small) as well as Lp(a) particles and that LDL-C is (1) if calculated represents LDL-C + IDL-C + any Lp(a)-C that is present whereas (2) if directly measured LDL-C represents the cholesterol within LDLs and any Lp(a) particles that may be present. LDL size is the size of the LDLs at its peak distribution (“peak particle size’), It represents the average size of the heterogeneous collection of all LDLs.

Tom Dayspring: Penetration using these methyl signals coming out of the methyl groups that are on cholesteryl ester, and triglycerides and phospholipids, and convert it into a particle number, that wow either apoB or LDL particle number correlates a lot better with clinical events ([Cromwell et al., 2007](https://www.ncbi.nlm.nih.gov/pubmed/19657464)) (Figure 12) or the presence of atherosclerosis, you haven’t had an event but if we do some imaging we see plaque in your wall, than does the cholesterol measurement itself.

Tom Dayspring: So it’s not a surrogate of particle, they are particle measurements, apoB or LDL-P. So apoB is an LDL particle metric. What too many people get lost at, hey VLDL particles are an apoB particle, so VLDLs — and there’s no doubt that VLDLs can get in the artery wall and contribute to atherogenesis, but it’s minor — the number of VLDLs that get into the artery wall are infinitesimal, the number of chylos that get in are infinitesimal compared to the number of LDL particles, so yeah they’re all bad guys. A VLDL per particle may have significantly more cholesterol molecules in it than an LDL, but there are just so many more LDLs (Figure 15) that collectively the LDLs deliver more cholesterol to the artery wall.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-79.png)

**Figure 15. A graphic of the apoB-containing lipoproteins (collectively called the beta-lipoproteins).** Since these are the particles that have the potential to invade the arterial wall, they are often referred to as atherogenic or potentially atherogenic particles. There is one molecule of apolipoprotein B per particle. In a fasting state, chylomicrons are not typically present. However, their plasma residence time, even postprandially, is so small, chylomicrons do not contribute to apoB concentrations. Also, using NMR spectroscopy which evaluates lipid, not protein, spectral signals, Lp(a) cannot be differentiated from LDL. The total LDL-P represents LDL + Lp(a) particles. Of course, not every patient has Lp(a) particles. Even in those with elevations of Lp(a), only a minority of the LDL particles have apo(a).

Tom Dayspring: But an apoB, by the way, gives us no information on VLDLs, it’s an LDL particle metric (Figure 13), simply due to plasma residence times (i.e., 90-95% of apoB particles are LDL particles). You can’t use it for anything else, so don’t call me up and say my apoB is high because I got too many VLDL particle unless you have a rare lipid disorder where there are no LDL particles, the type III dysbetalipoproteinemia ([Sniderman et al., 2007](https://www.lipidjournal.com/article/S1933-2874(07)00197-3/abstract)). That’s the only time an apoB is measuring — it’s a VLDL measurement, or a remnant measurement — it’s not an LDL measurement, but in everybody else apoB, LDL-P those are the tests you need because, although they correlate very well with LDL-cholesterol, if they’re both high in a given person that person’s a terrible risk. But as you well know, and probably because of the metabolic makeup of our existing humans at least throughout the world now, is some people have a very high apoB LDL-P, very good LDL-cholesterol, some people have high LDL-cholesterol, perfect apoB LDL particle counts.

Tom Dayspring: When those metrics agree they’re said to be concordant, hey use them both. Either one will give you the same information. But what happens if you get a patient where they don’t agree, these metrics? In virtually every single trial ever looked at, the risk follows the particle metric more than the cholesterol metric ([Sniderman et al., 2014](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1097%2FMOL.0000000000000127)). So the only way to know who is discordant with a cholesterol metric and an apoB or an LDL particle metric is to do both of them. You could also say hey if I’m just doing apoB or an LDL particle count I don’t even need lipids. And I’d agree with you except I think there is value in knowing what a triglyceride is for other reasons (e.g., pancreatitis or genetic-related TG disorders).

Tom Dayspring: So that’s the real key, and if you ever go to a doctor and you’re told “I’m very happy because your LDL-cholesterol is normal,” say “Well so am I doc, but by the way, what was the apoB or LDL particle count (Figure 14)?” And if the doctor didn’t do it, you demand he do it instantly because otherwise, you don’t know your lipid-related risk.

Peter Attia: Yeah, we’re going to upset a lot of doctors here because I’ve already, and you’ve already been in the business of that, where people will hear you talk or read something you’ve written, or something I’ve written, and they’ll go to their doctor and say “Hey I want my LDL-P or my apoB,” and the doctor says “That’s nonsense,” fill in the blank, TBD, blah, blah blah. It puts patients in an awkward position, I really feel bad about this because, especially depending on what country they live in. At least in the United States, I think anybody can go to LabCorp directly and get the assay without a physician’s prescription, but it upsets me that patients even have to do that.

Peter Attia: It upsets me that something that is such an important metric — I would list LDL-P as one of the five most important metrics. I’ve talked about this, that every patient should know their LDL-P or apoB, and that that wouldn’t be sort of fundamentally a part of screening somebody for disease and that a patient would get into a position where they’re having to argue with their doc about that is disconcerting.

Peter Attia: And look hopefully this is sort of why I do these podcasts is I think it’s just as much to help physicians say, look just because I didn’t learn this in my training doesn’t mean I don’t need to pick it up today.

Tom Dayspring: Amen. And I’m sad there’s so much what I consider inferior lipid care being administered by healthcare professionals in the United States, but there’s nothing I can do about that as try and teach them one at the time or expose my writings and other people’s writings and the data on this as much as I can. It is tragic with public health problem number one or number two that this has lagged so far behind, in part retarded by guidelines and third-party payers who just don’t wanna pay for different metrics, so there are other reasons behind it.

Tom Dayspring: But a big part is they don’t understand that you have had cardiologists call you up, I have being recognized as maybe in northern New Jersey one of the few lipidologists — “Hey Tom, you told my patient that what I said about LDL-cholesterol doesn’t matter because you’ve done an LDL particle and apoB,” not everybody believes that, or they give you some horseshit like that and I said, again, “Hey doctor, would you like two hundred manuscripts delivered to your desktop tomorrow? I’ll do it if you promise me you’ll read them, every single one.”

Tom Dayspring: So it is what it is. I think the internet has helped people in certain ways and I think the internet has confused people in a lot of ways too. Because there are people out there who, what we just talked about and it’s pretty much fact, who become deniers of the particle concentrations because whatever else they’re exposing as their way to cure heart disease somehow aggravates LDL particle count and they just choose to ignore it. Look are there people with high LDL particle counts who don’t have atherosclerotic risk somehow? Yeah, they’re out there. But the overwhelming amount of literature says the odds, if you keep this for 20, 30 years, you’re at atherosclerotic event risk. Until somebody does a serious study showing there are people who can escape this for 20 — you’re playing with fire to ignore an elevated LDL particle count, apoB. I don’t have a way of identifying who might have a high metric area or is somehow protected against atherosclerosis.

Peter Attia: Well I have lots of thoughts on this myself, but and maybe we’ll come back to it, but we had this fun email string a while ago with you, Ron Krauss, me, [Allan Sniderman](https://www.mcgill.ca/expmed/dr-allan-d-sniderman), I think [Josh Knowles](https://profiles.stanford.edu/joshua-knowles) was on it as well. You guys were the first people to be exposed to my new model which is necessary but not sufficient, sufficient but not necessary, neither necessary nor sufficient, causalities. Because you can actually have causal metrics that fit each of those buckets. But we’ll come back to that.

## Sterols and cholesterol synthesis [39:45]

Peter Attia: I want to go back to one semantic thing. You used the world sterol a lot. I’m very comfortable with it. I wanna make sure the listener knows the difference between a sterol, a stanol, a zoosterol, a phytosterol. I think we’re going to touch on this later so let’s just hammer out the semantics.

Tom Dayspring: Right well cholesterol, of course, is the molecule we all fear because it’s been drummed into our head that cholesterol in an arterial wall is what is plaque. It’s a cholesterol core, and that cholesterol can cause impaired vascular biology resulting in clinical events. So what is cholesterol? And we certainly, in Peter’s notes here you’re going to have pictures of the cholesterol structure (Figure 16). It’s got four rings, it’s an aromatic compound, and off the fourth ring is a little tail sticking out which is a carbon chain. So a sterol — the precursor molecule is called the sterane. So you have the rings, the four rings, and you may or may not have this tail sticking off of the 17th carbon in the fourth ring. So if all of the bonds are saturated, that is called the sterane.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-80.png)

**Figure 16. Free (unesterified) cholesterol (amphiphilic) and its carbon atom numbering.** There are 4 rings (A, B, C and D). At carbon 3 is a hydrophilic hydroxy group (the dark triangle means the OH-moiety extends outward to the viewer in a 2-dimensional structure – this is called the β isomer of cholesterol). The dashed lines means the attached moiety is extending inward away from the viewer. Note methyl (CH3) groups are at carbon positions 18, and 19. At carbon 17 is a hydrophobic octane group. Cholesterol is actually a cholestene, not a cholestane, because of the double bond between carbon 5 and 6.

Tom Dayspring: So if you unsaturate it, one double bond in that sterene, it’s called the styrene. And if you then stick a hydroxy group on the third carbon in the first ring, it’s called the sterol. It’s an alcohol because you got a hydroxy group now sticking out on it (Figure 17).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-81.png)

**Figure 17. Structural representations of a sterane (in this case cholestane) (with its 4 rings), a sterene (in this case cholestene with its 4 rings and double bond at C5-6) and the sterol (in this case cholesterol with its methyl groups (C18 & 19) and octane group at C17.**

Peter Attia: Hydroxy being OH.

Tom Dayspring: OH is hydroxy, excuse me. Correct. So you’ll see the pictures in my illustrated diagrams there, and that little tail that sticks out on the other end of the molecule has a lot to do with what exactly type of sterol that is and how it will function in a cell or in a cell membrane. So cholesterol would be this four-ring structure, three of the rings have six carbons in it, the fourth ring has five carbons in it. You have this tail sticking off of carbon 17 that goes out and then cholesterol, that’s a totally saturated tail, every bond then it’s a saturated fatty acid. Then on the three position, you’d have this OH group, the hydroxy group (Figure 16).

Tom Dayspring: By the way, since OH is sort of soluble in water, that part of the cholesterol molecule is soluble in water, whereas that carbon chain sticking out are a little pure lipid, that’s all aliphatic carbon chain (hydrophobic) that’s not soluble in water. So when cholesterol does exist in a surface membrane like a cell membrane or lipoprotein, its cholesterol-

Tom Dayspring: The hydroxy group is sticking out and that aliphatic tail is sticking into the core of the particle. Now the cholesterol that’s in the middle of the particle, the OH moiety, the hydroxy group can’t be in the middle of the particle, that’s water (i.e., hydrophilic). So they stick a really long-chain fatty acid, they replace the hydroxy group with a long-chain, or really any chain (potentially any length), fatty acid. Mostly it’s a long chain. So you esterify cholesterol, remember I told you attaching a fatty acid (i.e., its acyl group) to something is called esterification. Cholesterol, which is the active form of cholesterol that can be changed into a hormone, a bile salt or function in a cell membrane, becomes a storage form of cholesterol or a lipid core transportable form of cholesterol called cholesteryl now it’s Y-L, it’s not O-L, ester. And we abbreviate that as CE (Figure 18).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-82.png)

**Figure 18. Cholestryl ester.** Free (unesterified) cholesterol (amphiphilic) and cholesteryl ester (in this case having a saturated fatty acid) making it hydrophobic or lipophilic. The fatty acid in this case has 16 carbons and is palmitic acid. The entire molecule is called cholesteryl palmitate.

Tom Dayspring: So free cholesterol is either going to be abbreviated as a C or an FC and cholesteryl ester, and it’s very difficult. If I’m an adrenal gland and I’ve got some cholesteryl ester stored and I wanna make a hormone because I got cholesterol (stored as cholesteryl ester) I have to de-esterify, that cholesteryl ester to free cholesterol. If the liver has cholesteryl ester storage pools, and it does, and it wants to make a bile acid it has to de-esterify cholesteryl ester. Cholesterol is stored in huge quantities in fat cells as cholesteryl ester, and it would have to be de-esterified to be utilized to do something else.

Peter Attia: One little story I’ll just tell before we get to the stanols and all the other stuff is, one of my prouder moments in front of [Bob Kaplan](https://twitter.com/bobkaplan) was when you sent an email, this was a couple of months ago, you sent us an email and you said, “See if you can spot the error in this figure,” and it was like a figure that had a million things on it. I was like “Oh I’m not getting up until I figure out where the mistake is.” And sure enough, somewhere in there, it took me about ten minutes, the illustrator had written, because this is on of a paper, they had written cholesterol O-L ester instead of cholesteryl Y-L ester, and when I responded to you and you responded in the affirmative I was like, “I’ve got my stripes.”

Tom Dayspring: And that figure he’s talking about came out of one of the productions for the company that I work for. We develop educational pieces for physicians and I obviously drew it and labeled it. But you send it off to a medical illustrator who formats it for the PDF or whatever labeled as cholesteryl is [edited to] cholesterol, and they make the mistake, even though I sent in the picture where I had it properly labeled. I felt like I had a “heart attack” the first time I saw it, and we’ve since changed that. But somehow Peter got a hold of an older version of something that probably even I sent out and didn’t recognize initially. But, yeah so it is cholesteryl ester, anything that’s esterified becomes a Y-L so you’ll see it in al esterified lipid nomenclature, why is it-

Peter Attia: This discussion illustrates one of the challenges of lipidology. I find this to be certainly among the two or three most complicated subject matters I’ve ever tried to master. And again, no one master’s anything in life, that’s sort of the beauty of this. You haven’t mastered this. But this journey of trying to learn it, I am constantly humbled by how hard it is. It’s just so goddamn complicated.

Tom Dayspring: Well that’s true, especially if you want to take it to the nth degree, but you need to invest yourself in some degree of education to at least be competent in today’s world. So you have to know some of this stuff.

Peter Attia: Well and that’s the thing. You have to be willing to learn some of this chemistry. You have to steep yourself in biochemistry and understand i because the significance becomes enormous. One double bond in one of these things completely changes its properties. And not to say that that’s not true in general in biochemistry, but it’s much easier to talk about blood pressure or to talk about elevated levels of uric acid or insulin or glucose, without getting into that level of minutiae. It is not possible to discuss lipids without that.

Tom Dayspring: That is the probably that a lot of people are spouting off on the internet and elsewhere about all this topic understanding of the complexity of all how this all works and fits together and why what you just said is wrong because there’s something going on stoichiometrically that you haven’t even considered.

Tom Dayspring: To finish the sterol, a steroid is a sterol that’s got another keto group stuck on it someplace ([Dayspring et al., 2015](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1016%2Fj.jacl.2015.08.003)). Look at all the hormones, you’ll see a double bond with oxygen attached. But a stanol is you take, and let’s take cholesterol as a sterol, and remember cholesterol the third carbon’s an OH group, there’s a double bond at carbon 5 to 6 in the first ring and then there’s that tail at carbon 17. If I de-saturate a cholesterol, the double bond at C-5 and 6 disappears, that’s called cholestanol, it’s a stanol. A stanol is essentially a saturated sterol. Changes the characteristics of that cholesterol. Free cholesterol can be readily absorbed in your intestinal wall. Stanols cannot be absorbed. And it’s kind of funny, our body, to get rid of cholesterol, sends it to the liver, the liver sends it through the bile to the intestinal pool as free cholesterol and your intestine’s more than capable of just reabsorbing that cholesterol that the liver’s trying to evict. Except, our little friendly microbes down there in the gut convert a ton of the biliary excreted cholesterol into a stanol called cholestanol or there is an isoform for it called coprostanol. It’s a stanol, it cannot be reabsorbed, so you poop it away. And that’s how the body gets rid of cholesterol it changes a lot of it to a stanol.

Tom Dayspring: Anthropologists have been measuring specimens for coprostanol that tells them humans lived there at one time because they find that in certain specimens, and that human had to excrete it. A stanol is simply a saturated sterol, and that has other applications because if stanols cannot be absorbed, and I would like to have a metric of whether you’re absorbing cholesterol or not, if I measured cholestanol in your blood, it shouldn’t be there to any appreciable degree.

Tom Dayspring: You cannot absorb it. If it is elevated in your blood for whatever reason, and we now know why, your intestine just absorbs that cholestanol. And if it’s absorbing cholestanol, which it tends not to, what is it absorbing in humongous excess? Cholesterol. So cholestanol serves as a biomarker of are you or are you not, or what degree of cholesterol absorption is going on in your intestines (actually, proximal small intestine). The last thing Peter did mention, he said phytosterols. He called it a *ZOO*-STEROL, I call it, ZOH-OL-OGY, so I call it a ZOH-OH-STEROL, so I don’t know who’s right on that.

Peter Attia: I’m going to go with you’re right. Yeah, I’m just going to give you that.

Tom Dayspring: And I do have a degree in Zo-ology. When I went to college that was one of my majors.

Peter Attia: And you’re wearing, just so everyone knows, you’re wearing your Rutgers t-shirt right now as well.

Tom Dayspring: I am.

Peter Attia: From college which is perfect, alright.

Tom Dayspring: I wouldn’t be here without Rutgers. Medical school was inconsequential. I learned everything in Rutgers premed, at least the biochemistry and the physiology, anyway.

**[50:00]**

Tom Dayspring: So phytosterols (Figure 19), well plants are full of sterols. Their cell membranes are not cholesterol, though there are some plants that do have cholesterol in them, most do not. But they have sterols that if I showed you here’s cholesterol and here’s what’s in this plant you would think you’re showing me a lot of cholesterol. But if you look closely, you’d see that tail that’s coming out of carbon 17 is constructed a little differently or wait a minute, there’s another double bond in one of those rings in there. So it looks like cholesterol but it’s close, but it’s really not.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-83.png)

**Figure 19. Shown are two phytosterols and the saturated stanol, called cholestanol (exact structure as cholesterol but without the double bond at C5-6).** Note that what differentiates the two phytosterols from the zoosterol cholesterol is the presence of an ethyl group at C24 in sitosterol and a methyl group at C-24 in campesterol. That seemingly minor structural change makes it very easy for the sterol-sensing domain of the Niemann-Pick C-1 Like 1 protein (NPC1L1) sterol influx transporter in enterocytes and hepatocytes to have much higher affinity for cholesterol than phytosterols. Vice versa it is why the ABCG5 and G8 sterol efflux transporters more readily expel phytosterols compared to cholesterol. Likewise, the lack of a double bond in cholestanol retards its identification and internalization by NPC1L1. Because they are absorbed in such minimal concentrations compared to cholesterol, these two phytosterols and cholestanol serve as markers of cholesterol absorption.

Tom Dayspring: And since it was made in a plant, collectively let’s call them phytosterols, but we hopefully all eat a few vegetables during the day, so you’re eating phytosterols unless you don’t eat any vegetables. And yet, you eat it even in other things, even if you’re eating shrimp, fish which themselves have eaten phytoplankton. So there are phytosterols in a bunch of foods. But your body knows, “the only sterol I need to function is cholesterol. I don’t need any plant sterols, why would I — a human — want to ever absorb the plant sterol?” They would get in the way, they could even be toxic ([Weingärtner et al., 2008](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1016%2Fj.jacc.2007.09.074); [Sudhop et al., 2002](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1053%2Fmeta.2002.36298)). So evolution must’ve figured out they were. So evolution made sure our intestine did not absorb phytosterols. Why? To me, it tells me there’s a certain level at which phytosterols are toxic.

**Note from Tom Dayspring**: Non-cholesterol sterols are detected in our body at very low concentrations (reviewed by [Olkkonen et al., 2015](https://www.ncbi.nlm.nih.gov/pubmed/26733205)):

“They can be employed as biomarkers for both of the major routes through which the body acquires cholesterol, absorption from the nutrition, and endogenous biosynthesis: Plant sterols, such as sitosterol and campesterol, are employed as biomarkers for sterol absorption, and cholesterol precursors, such as lathosterol and desmosterol, as markers of cholesterol synthesis (Figure 20). Oxysterol species arising via non-enzymatic cholesterol oxidation reflect oxidative stress. In addition, oxysterols arising through enzymatic oxidation of cholesterol can be employed to estimate how efficiently cholesterol is removed from certain tissues, such as the brain.”

[. . .]

“Cholesterol precursors and oxysterols are more hydrophilic than cholesterol. This is why their mobility in cells and capability of penetrating membranes are markedly higher than of cholesterol, and their half-life in the system much shorter ([Olkkonen and Hynynen, 2009](https://www.ncbi.nlm.nih.gov/pubmed/19248802)). The concentrations of these molecules therefore vary in a more dynamic manner than cholesterol, and they can be employed as sensitive indicators of cholesterol metabolism.”

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-30.png)

**Figure 20. Plasma absorption and synthesis markers (and ranges) by sterol markers.**

Peter Attia: Well this becomes interesting because I had a disagreement with a physician recently who jointly takes care of one of my patients because the physician wanted to put this patient on phytosterol supplements because this physician became convinced that it was such an elegant way to lower cholesterol. It turns out about 10 to 15% of people in whom you give massive doses of phytosterols, you do indeed lower their cholesterol. This physician felt that was a good idea, I felt otherwise for reasons you’ll explain I’m sure. And needless to say, after a long discussion we agreed to stop the phytosterols.

Tom Dayspring: Yes. And again, to me the best argument with that is if evolution thought we needed phytosterols, your intestine would be encouraged to absorb phytosterols. If somehow they brought some miraculous property to the human body that enhanced survival, you’d (i.e., evolution) want them in there. And everybody’s saying “Oh plants carry a lot of great stuff.” We’re only talking about the sterol that’s in the plant, the phytosterol. Other ingredients in plants do get absorbed and probably are good for you, but not phytosterols.

Peter Attia: Well there’s data to show that phytosterols on a per molecule basis are probably more atherogenic than cholesterol.

Tom Dayspring: There certainly is that data there ([Weingärtner et al., 2008](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1016%2Fj.jacc.2007.09.074); [Sudhop et al., 2002](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1053%2Fmeta.2002.36298)). But again, the people who are just so focused on lowering LDL-cholesterol don’t even entertain it, won’t even look at it, or dismiss it as nonsense. It’s never going to be studied in a proper type of trial that you’d have to study it in. And as Peter just hinted, if you’re not a hyperabsorber of sterols, probably giving a phytosterol supplement is good because it does compete with cholesterol, so you will absorb less cholesterol and maybe that’s one way of lowering LDL-cholesterol, but I would say who cares. But you would get a little bit of apoB reduction in certain people with that, but if you’re a hyperabsorber, I’m polluting your body with something that evolution didn’t want in your body. Why would I do that?

Tom Dayspring: So I beg anybody who’s a big advocate of supplementing phytosterols, please monitor phytosterols in the bloodstream. That’s how you’ll identify, oh my god you’re the one person I absolutely should not be giving this too, and I can send you a lot of data Peter’s talking about showing you phytosterol toxicity in humans.

Peter Attia: And when we say someone’s a hyperabsorber, I mean you and I both have written about this ad nauseam, so we’ll link to it ([von Bergmann et al., 2005](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1016%2Fj.amjcard.2005.03.014); [Iqbal and Hussain, 2009](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1152%2Fajpendo.90899.2008)) rather than get into a diatribe, but we’re basically talking about — and your analogy is my favorite, I’ve always borrowed it, outright stole it, hopefully I’ve always given you credit — you got the ticket taker in the bar ([Klett and Patel, 2004](https://science.sciencemag.org/content/303/5661/1149)) (Figure 21).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-84.png)

**Figure 21. Membrane sterol transporters.**

Peter Attia: Niemann-Pick C1-Like 1 transporter. He lets everybody in. If you can fit through the door-

Tom Dayspring: He lets a sterol in.

Peter Attia: Yeah he lets any sterol in. If you can fit through the door, you’re coming in. But then you’ve got this ATP-binding cassette G5/G8 ([Ajagbe et al., 2015](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4514516/)) and that’s the bouncer, that’s the enforcer. That’s the one who, in theory, probably informed by LXR ([Liver X receptor](https://en.wikipedia.org/wiki/Liver_X_receptor) — a nuclear transcription factor), is making some sort of decision about you’re a good guy, you’re a bad guy, you’ve got to go, you’ve got to stay. When someone is genetically a hyperabsorber, is the “defect” more on the ticket taker or on the bouncer?

Tom Dayspring: It turns out that it’s both because, now when we talk about absorption, let’s face it there’s a million molecules that can be absorbed by your intestine. We’re talking about sterol absorption right now and cholesterol is a key ingredient for human life. So evolution not only gave every cell in your body the wherewithal to synthesize cholesterol, it allowed your intestine to absorb cholesterol ([Sehayek et al., 1998](https://www.ncbi.nlm.nih.gov/pubmed/?term=J+Lip+Res+1998%3B39%3A2415-22)) because it certainly didn’t want any cellular deficiency of cholesterol, which has nothing to do with plasma cholesterol by the way, you can have an LDL-C of 3 and have perfect cellular cholesterol metrics ([Davis et al., 2007](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1161%2F01.ATV.0000257627.40486.46); [Stitziel et al., 2014](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1056%2FNEJMoa1405386)). Some people don’t understand that.

Peter Attia: Well, as evidenced by the hypofunctioning PCSK9 patients ([Abifadel et al., 2003](https://www.ncbi.nlm.nih.gov/pubmed/12730697); [Cohen et al., 2005](https://www.ncbi.nlm.nih.gov/pubmed/15654334); [Cohen et al., 2006](https://www.ncbi.nlm.nih.gov/pubmed/16554528)).

Tom Dayspring: So this Niemann-Pick C1-Like 1 protein in our proximal intestine recognizes sterols. There’s a sterol domain on there that binds tightly to sterols, but it binds most tightly to cholesterol because cholesterol has that structure. It has a less avid binding to a phytosterol and it has minimal bind to a stanol. Now ultimately it will bind to all of them, but cholesterol gets the first preference to be pulled into the enterocyte. Xenosterol as I call it rather than phytosterol, Xeno meaning other sterol, a sterol other than cholesterol, would get in secondarily. And a stanol, they get it, but at much lower concentrations ([Yu, 2008](https://www.ncbi.nlm.nih.gov/pubmed/?term=Yu+L+et+al.+Curr+Opin+Lipidol+19%3A263%E2%80%93269); [Calandra et al., 2011](https://www.ncbi.nlm.nih.gov/pubmed/?term=Calandra+S+et+al.+J.+Lipid+Res.+2011.+52%3A1885%E2%80%931926)).

Tom Dayspring: So now the enterocyte has this sterol you just absorbed. Now the enterocyte’s position is, I need to get this to the rest of the body, so I have to take this sterol and put it in a chylomicron that I’m going to make or I could also efflux any sterol out to a baby [i.e., small] HDL that’s looking for sterols, I could lipidate an HDL. So that’s how sterols get out of the intestine. Or the intestine can say we don’t need anymore sterols, I’m getting rid of you. And that’s where the bouncer comes in. So these ATP-binding cassette transporters G5 and G8 are a sterol efflux membrane transporter.

Peter Attia: And this is important to distinguish because, and again it might be confusing, but the diagrams will make it easier. There’s two effluxes you’ve referred to. There’s an efflux on the luminal side and then an efflux back into the body. Both of them are leaving an enterocyte. One ends up leaving the body, if it goes out the ATP-binding cassette, it’s going into the lumen, it’s being excreted with stool. If you efflux on the other side of the cell, into either the chylomicron or into the HDL, you’re actually putting it right back into circulation.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-85.png)

**Figure 22. The aromatization of squalene into the ringed sterol called lanosterol**. Note the position of the double bonds in lanosterol.

Tom Dayspring: And that is such a crucial point Peter. I’m glad you elucidated on that more. So yeah, remember we’re talking about the enterocyte. The liver and enterocytes have a lot of things they can do with sterols. So they can get rid of them or they can even use them. Remember enterocytes have cell membranes, they need some cholesterol for their own cell membranes. So they can ship it out, a body needs cholesterol in the chylomicron. They can lipidate an HDL, or they can return it to the lumen of the gut where it will go out your rear end. So these ABCG5 or G8 transporters as they’re called, then it’s a heterodimer so you have one of each, will efflux, and they also have different affinities.

Tom Dayspring: So unlike the Niemann-Pick which really wants cholesterol to come in, less so phytosterols and not so stanols which tells me evolution didn’t want those other products in your body, the ABC exporters, they number one, evict phytosterols first. That’s another evolutionary happenstance to me that tells me evolution didn’t want phytosterols in your damn body. Because why is it giving you a phytosterol efflux protein in your intestine? And the liver has it, too, just in case a phytosterol ever makes it as far as the liver, it gets evicted back to the bile. It’ll go back to your intestine.

Tom Dayspring: So second in line for exportation would be a stanol and third would be cholesterol. So your ability to absorb cholesterol is a happy working relationship between the expression of your Niemann-Pick C1-Like 1 protein and your ABCG5/G8 transporters ([Baldán et al., 2009](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1194%2Fjlr.R800044-JLR200)). So technically if you even had a good normal degree of absorption but you couldn’t evict any sterols because you’ve got a loss of function of an ABCG5 or G8, you’re going to be a hyperabsorber. Because then the only way those sterols could get out of the enterocyte is in a chylomicron or in an HDL (not efflux back to the gut lumen).

Tom Dayspring: And by the way, when you do measure these phytosterols in the blood, people it’s like when you measure cholesterol in the blood. Do you understand? I’ve already told you where that cholesterol measures, it’s the cholesterol within all the lipoproteins. So if I’m measuring sitosterol, stigmasterol, campesterol, which are some of the names of the 50 phytosterols that are in our plant products, what am I measuring? Well since the vast majority of lipoproteins are LDLs I’m measuring LDL-sitosterol, LDL-campesterol, like I’m measuring LDL-cholesterol. So you’re measuring there, but god forbid that particle invades an artery wall. The sterols go with it. And one last intriguing part of this story which better put the fear of God of phytosterols into you is that evolution didn’t want it in, so it gave you a protein that will not absorb phytosterols if it’s working right, it gave you a protein that immediately evicts phytosterols, but for any sterol to go in a chylomicron, what cholesteryl does it have to be? Esterified. How does the intestine esterify cholesterol into cholesteryl ester which is what makes up a giant part of the core of a chylomicron?

**[1:00:00]**

Tom Dayspring: There’s an esterifying enzyme acyl cholesterol acyltransferase, ACAT. Guess what is the favorite ligand for ACAT. Cholesterol. Guess what is not a favorite ligand for ACAT. Phytosterols. So you just don’t easily esterify phytosterols which retards them getting into your body. And you know another way they get in? That [membrane-located] ABCA1 efflux transporter which is what lipidates a baby HDL particle. It’s different from ABCG5/G8, ABCA1 exports sterols into baby (i.e., small, immature) HDL particles.

Peter Attia: And just for the listener, again, you’re saying ABC. What you’re saying is ATP-binding cassette. So when they hear you say ABC, that’s what you’re referring to.

Tom Dayspring: Yeah it’s an energy driven process so, yeah. So some of that phytosterols you’re measuring in the blood are HDL particles also so that’s a way they get in. And I always make, and you’d have to do a study and prove it, we’re going to be talking about HDL dysfunction. Suppose I measured phytosterols in your HDL and it’s very high, which is probably a type of dysfunctional HDL particle. So there’s all sorts of intriguing-

Peter Attia: It would also, and not to get too esoteric, but that would also suggest enterocyte dysfunction because the enterocyte should also “know better” that that’s not the direction of efflux I want.

Tom Dayspring: It is. But it’s relying on the ABC G5/G8 efflux then the sterol wouldn’t even get to an ABC A1 to efflux it on the other side. And ACAT is not going to esterify it if it’s all being evicted, there would be very little that would wind up being esterified (and incorporated into a chylomicron). And the last part of this puzzle is, Peter I thought you have a gut lumen side and you got a plasma side or a lymphatic side which is where chylomicrons exit. We probably talked about it somewhere today is this complicated process they used to call reverse cholesterol transport which is another one of these idiotic terms that should’ve disappeared a long time ago, at least if you think it’s mediated by solely by HDL, high-density lipoproteins, that’s the part that’s got to change ([Hellerstein and Turner, 2014](https://www.ncbi.nlm.nih.gov/pubmed/24362356)).

Tom Dayspring: A big pathway of how does the body get rid of cholesterol, we all thought, “oh, [lipoproteins carrying cholesterol] brought it back to the liver and the liver will get rid of [the cholesterol] in a certain way. Guess what? A ton of [the cholesterol] is just brought directly right back to the intestine and the cholesterol in the particle or the particle itself finds its way into the enterocyte through several putative mechanisms — and then the enterocyte has another supply of sterols all of a sudden that it didn’t absorb from the gut lumen, and so what. The intestine will do with that sterol what it wants. It can efflux it through ABCG5/G8 into your gut lumen and you can poop it away.

Tom Dayspring: So the process of a lipoprotein or some other trafficker, albumin, red blood cells, bringing cholesterol back to the small intestine, bypassing the liver gets right out into your stool, is called transintestinal cholesterol efflux, abbreviated as TICE, and it’s a major reverse cholesterol transport pathway now.

Peter Attia: Do we have a sense, because we’re going to talk about direct and indirect RCT in a moment. This is as good a foray into that as any. Do you have a sense of how much cholesterol is being reverse transported so to speak through TICE (Trans-Intestinal Cholesterol Efflux) versus the sum total of direct and non-direct reverse cholesterol transport?

Tom Dayspring: This has been studied even dynamically but you know they’re real small studies and it probably varies individually depending on the complexity of your lipid and lipoprotein transportation systems. In some people it’s probably 20% and in other people it’s been reported as high as 60% so it varies a lot. But [TICE is] a major player, it’s not this infinitesimal minor baby pathway that’s inconsequential except in some rat in a laboratory. This has been proven in humans now, I just was part of the review process on a really cool article coming out in the Journal of Clinical Lipidology where because of some biliary surgery the guy had the only way cholesterol gets out of this person’s body was through the intestine — so it shows your body can get rid of cholesterol without a biliary system.

Peter Attia: How many articles do you review a year?

Tom Dayspring: There’s two things. When you’re an associate editor, the main editor will say here’s a submitted paper. Do you think this is pretty good? If so send it out to four or five reviewers, they will send their review to you and then you make your decision and send it to me and I’ll make the ultimate decision. But then also, I’m also just a reviewer, where another associate editor would say I think Tom knows a lot about this subject so I’ll ask him would he please review this article to me. So I don’t know I probably get about 15 articles a year where I’m the associate editor and probably double that where, hey, I’m a reviewer.

Peter Attia: You’re one of the reviewers.

Tom Dayspring: And just one of several reviewers.

Peter Attia: But that’s still about 50 papers a year that are coming across your desk.

Tom Dayspring: Yeah it’s a lot, [as I also do reviews for other journals,] and I am blessed at my stage of the game to have a job where I don’t have to see patients anymore, I’m not traveling throughout the United States a hundred times a year on flights doing lectures here, there, and everywhere. So I am blessed in my current position at True Health Diagnostics, Peter probably when you hear this the first time you’ll get a list of my who I work for and who I don’t. That’s the only company I work for nowadays and I’m their scientific academic advisor. So my job is to stay on top of the literature, know all this stuff, and explain it. So I have the freedom every day to spend time reading and educating. And part of my educating — anybody who’s a reviewer or an editor will tell you — you learn a lot doing that because I don’t know everything that’s sent to me for review, but I’ll sure as heck know where to go and get it where I can study.

Peter Attia: Well there’s a small group

Tom Dayspring: To me for review, but I’ll sure as heck know where to go to get ’em.

Peter Attia: Well there’s a small group of us that are very lucky that we’re having dinner with [Jamie Underberg](https://twitter.com/lipiddoc) tonight, but you know Jamie, it’s like this group of like 10 people that you always send out the most interesting papers to. And about a year ago, I had forwarded a number of these on to Bob Kaplan and he was like, “Hey, can you put me on this email too?”

Peter Attia: We have to think about a way for you to create a special group where — because it strikes me that there’s a broader group of people who would actually like to get the once a week email from Tom, with the most interesting lipid paper I’ve read this week.

Tom Dayspring: Yeah, and I think the best way of doing that is [contacting me: [@DrLipid](https://twitter.com/Drlipid)].

Peter Attia: You put a lot of this stuff out on Twitter too.

Tom Dayspring: Yeah I do, so you can research.

Peter Attia: But you don’t get the commentary, because your emails are sometimes so great. What you’ll do is, you’ll say “Look, I know all of you aren’t going to read this 12 page paper, here’s like a 300 word summary of what you would learn,” and then for me to read that, then open the paper, it’s like, it’s quick.

Tom Dayspring: I don’t know how many people listen to Peter’s podcast, but it’s immense. I don’t want 4,000 emails tomorrow, saying put me on your email. And there’s two things as part of that email, one would be my interpretation which is fine. I can’t attach PDFs to it that I might to an isolated friend, because of copyrights and things like that.

Tom Dayspring: So that’s part of an issue also. So if it’s open access, great. If it is, I probably Tweeted it. And look, people aren’t afraid to ask me questions. A lot of them are asinine, I ignore them. But I will answer, my Twitter followers know, I’m responsive, and I can direct message you. And if I don’t, then there’s a reason.

Peter Attia: Okay, so let’s get back to the business of lipids here. So we’ve done a pretty good job explaining one side of the equation at how cholesterol is regulated.

Tom Dayspring: By the way, zoosterol would be cholesterol, it’s the only sterol the animal kingdom produces. Cholesterol is the zoosterol.

Peter Attia: Okay, so the other end of this regulatory pathway, so we’ve described the reabsorption side pretty well. There’s a synthetic side, which you’ve alluded to obviously, by making the statements, that hey, every cell in the body can make cholesterol, and most of the time it’s sufficient for its needs. Obviously exceptions, well I’ll let you explain what the exceptions are to that, or if certain scenarios and certain cells where they actually do need cholesterol from other tissues, but let’s just go back to the synthetic stuff. Just briefly, because I don’t want to give anybody too much headache. How do we make cholesterol?

Tom Dayspring: Very complexly, it’s a multistage process 20 to 30 individual steps, where one molecule is changing into another, into another, and at the end of the day cholesterol is made (Figure 22).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-86.png)

**Figure 23. Simplified version of the cholesterol synthesis pathways.** The path starts with acetate. The rate-limiting step is the transformation of HMG-CoA, catalyzed by HMG-CoA reductase into mevalonic acid. Squalene consists of isoprene units and start to aromatize forming the first ringed structure lanosterol, which after numerous steps is transformed into cholesterol. The penultimate sterols are desmosterol and lathosterol, which, if measured, serve as markers of the cholesterol synthetic pathways.

Peter Attia: And it starts very small. It’s basically a Acetyl-CoA, Acetyl-CoA, it’s a, two carbon ([Bloch and Rittenberg, 1942](https://www.jbc.org/content/145/2/625.full.pdf)).

Tom Dayspring: It really is, a small carbon chain molecule that keeps growing in length, because cholesterol has [27] (not 37, which would be one of the cholesteryl ester molecules) carbons in it. So it has to grow [from its small molecule origin]. Through much of that growth, it’s just a linear structure. And at a certain point, this linear structure is long enough that it bends and changes into a sterol configuration (i.e., ringed or aromatic), lanosterol being the first sterol that appears in the cholesterol synthesis chain (Figure 23).

Tom Dayspring: By the way, if I wanted a lab, and labs with liquid chromatography and mass spec, could give you a lanosterol measurement, and if it was up, hey you’re over synthesizing cholesterol. That’s not the one they focus on, they pick a more downstream cholesterol precursor to do that. But even you could pick some of the earlier ones, and they do serve as markers of cholesterol synthesis, you know.

Peter Attia: Now the cholesterol synthetic pathway is bifurcated. Tell me a little bit about that.

Tom Dayspring: So once you go through squalene, and then that bends into a ring structure, lanosterol has to become cholesterol.

**[1:10:00]**

Tom Dayspring: So lanosterol, and there’s crosstalk between the pathways, but it has one or two pathways that it’s going to go down. At the end of the day, both pathways, wind up with cholesterol (Figure 23).

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-87.png)

**Figure 24. Lanosterol progresses its conversion into cholesterol via two interrelated pathways: the Kandutsch-Russell path, which goes through the intermediate lathosterol (LAH-THOSS-TER-ALL), or the Bloch path, through the intermediate desm****osterol (DESS-MAHS-TER-ALL).** These paths may be organ-specific with the Bloch path being of utmost importance in the brain. Either or both penultimate sterols can be used as markers of cholesterol synthesis. CSF desmosterol correlates well with serum concentrations and can serve as a biomarker of cognitive impairment or dementia.

Peter Attia: And no good pathways don’t come with names.

Tom Dayspring: They do.

Peter Attia: What are the names of these pathways?

Tom Dayspring: Mr. Facetious here. Yes. Well, my favorite, of course, is the Bloch pathway. There’s a Twitter picture I put up recently (Figure 25). [[Konrad Bloch](https://en.wikipedia.org/wiki/Konrad_Emil_Bloch)] won the Nobel Prize for discovering this pathway in cholesterol. So [cholesterol is] probably important, they give you a Nobel Prize for discovering this pathway of cholesterol synthesis.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-88.png)

**Figure 25. The Nobel Prize for discover of the Cholesterol synthesis path went to Konrad Bloch and Feodor Lynen.**

Tom Dayspring: So the Bloch pathway would be lanosterol goes through a lot of precursors, and become something called desmosterol, D-E-S-M-O-S-T-E-R-O-L (Figures 26-28). Desmosterol looks exactly like cholesterol, except in carbon 24 there’s a double bond, there are no double bonds in that tail that are on the cholesterol molecule. So if I just saturated that double bond in desmosterol, I changed it into cholesterol. And of course, there’s a specific enzyme that does that.

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-90.png)

**Figure 26. The two paths of cholesterol synthesis and the multitude of enzymes involved.**

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-92.png)

**Figure 27. The Bloch (desmosterol) Pathway.**

![](https://peterattiamd.com/wp-content/uploads/2018/10/null-93.png)

**Figure 28. The Kandutsch-Russell (lathosterol) Pathway.**

Peter Attia: Can I guess it?

Tom Dayspring: Yes.

Peter Attia: So this is just so people can understand what these enzymes mean. I remember learning this in college, or med school not college. Enzymes always end in ACE [i.e., -ase] right? Now you just told me it was carbon 24, so it’s probably going to have something to do with, it’s going to have a 24 in there.

Tom Dayspring: It will.

Peter Attia: And we often throw deltas into these things, because delta denotes the position of the bond.

Tom Dayspring: Right.

Peter Attia: And did you say that desmosterol has a double bond at 24? And it has to be saturated [an alternative term is *reduced*].

Tom Dayspring: Saturated [an alternative term is *reduced*].

Peter Attia: So it would probably be something like a Delta-24 saturase or desaturase.

Tom Dayspring: Correct. [Also called the delta 24-dehydroreductase.]

Peter Attia: All right. So that would be the enzyme. So when you say that, when you rattle that off, it sounds crazy and intimidating, but it’s logical right?

Tom Dayspring: It is. And this is why what you were talking about before, you really have to know this stuff, or you might not be able to. And the presence, or the expression, or the lack of expression that that enzyme is going to — are you going to use that pathway. If you’re using that and you don’t convert desmosterol into cholesterol, you’re going to have a lot of desmosterol in your system. Are there consequences to that? There is a human disease called desmosterolosis ([Waterham et al., 2001](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1226055/)), that if it occurs in utero, that kid ain’t coming out alive, or if he does, he ain’t living for more than a few days.

Peter Attia: And is that disease a genetic deficiency in the enzyme, the Delta-24 saturase (officially called DHCR24)?

Tom Dayspring: It is. So now there’s another pathway, lanosterol doesn’t, and what determines that, is if you’ve got a double bond at that 24, because it’s going to go through that pathway. Now lanosterol has another pathway that that goes through, that’s going to wind up with cholesterol, and the pre-cholesterol and penultimate, the next to last cholesterol molecule in that chain is on called lathosterol. Some people call it LAY-THOS-TEROL, I call it lathosterol, LAH-THOSS-TER-ALL.

Tom Dayspring: That is called the Kandutsch-Russell pathway (Figures 26 and 28), obviously after the guys who discovered that. By the way, they didn’t get the Nobel Prize for some reason-

Peter Attia: I think the Nobel committee said, we already gave one of these. Also you can only have three people receive a Nobel Prize [note from Tom Dayspring: *actually, the Kandutsch-Russell pathway was the first discovered: they didn’t work in Bloch’s lab*].

Tom Dayspring: Oh, so that would be two, so yeah, so whatever. Everybody else I guess who worked in Bloch’s lab got no credit. But anyway, so it’s the Kandutsch-Russell pathway.

Tom Dayspring: And it’s kind of interesting, because in most people both pathways exist, and there are some ways of jumping from one pathway to another, so at the end of the day, you’re going to make cholesterol. But if you want to start interfering with these pathways, there are specific enzymes in each pathway that maybe that would be something you could play with, or maybe if you’re building too much of something there’s a lack of expression of enzyme in you, which maybe has consequences, maybe it doesn’t.

Tom Dayspring: So it’s all important to know. But some of this may be tissue specific. One of the things, I know it’s a big topic of yours and I hope we get into it today, is the brain. Everything I’ve talked about cholesterol today that we’re measuring in the blood has zero to do with cholesterol in the brain.

Tom Dayspring: Cholesterol, lipidology in the brain might as well be in another different body, it has nothing to do with the cholesterol going on in the rest of your body. The brain makes every cholesterol molecule it needs and therefore there are no LDL particles delivering cholesterol to your brain.

Peter Attia: And to be clear, this is because the LDL particle just doesn’t fit through the blood brain barrier.

Tom Dayspring: Correct. Even HDLs, where a little bit of cholesterol might get into, it’s delipidated through these ABC [transporters at the blood-brain barrier], and some of that might work it’s way in inconsequential amount. ApoB is too big. The brain doesn’t make apoB, but the brain has to traffic, or the central nervous system has to traffic lipids from brain cells to peripheral nerve cells, apoE is the protein transporter in the brain. So cholesterol or any sterol that’s attached to apoE in the brain, and that’s how it traffics around there so. And again, it’s got nothing to do with the apoE that’s involved with whatever lipoproteins are doing in the rest of your body also, so just understand that.

Peter Attia: This is such an important topic, but I absolutely want to come back to it, so I’m glad you brought it up. But that said, at the moment, I would love to go back to the synthetic stuff. Each cell in the body can basically start with the most simple carbon subunit, which is a two carbon subunit, acetyl-CoA, and through a process of carbon fixation go on to make these very complicated four ringed structures, they first and foremost the cell uses these things. They make the important part of the cell membrane.

Tom Dayspring: Organelle membranes and intracellular structures.

Peter Attia: That’s right, so everything from the Golgi apparatus to the ER, to the smooth ER, rough ER, et cetera. You don’t have to be a biochemist to look at a picture of a molecule like cortisol, estrogen, testosterone and I think you could show a four-year-old picture of those, and then a molecule of cholesterol, and they would be like, hey those look similar.

Tom Dayspring: Yeah, it’s like maybe I look like my mother and father, or did they have an origin, or did [the hormones] come from cholesterol. Sure, so certain cells can certainly transform cholesterol into reproductive hormones, or adrenocortical hormones. Certain cells, hepatocytes, can transform cholesterol into a bile acid. I don’t think there’s any other cell that can change cholesterol into anything else.

Tom Dayspring: So when people talk about cholesterol metabolism, there is no cholesterol metabolism that can be converted in specific tissues, but it can be excreted, that’s it, there’s no other way your body can handle cholesterol.

Peter Attia: So is there any evidence that we use cholesterol for energy?

Tom Dayspring: Zero. Energy is really coming out of the fats (i.e., beta-oxidation of fatty acids) that have no double bonds. They’re carrying the most ATP. Cholesterol is not producing energy. Cholesterol cannot be metabolized and produce ATP in the process.

Peter Attia: I mean to me, that’s the bigger issue. Some people get confused about this. It’s not that there isn’t energy in a carbon carbon bond, or a carbon hydrogen bond, because that’s exactly what’s being liberated in the metabolism of a fatty acid. The point is, we don’t have the enzymatic machinery to undergo the chemical process of breaking down those bonds and liberating the chemical energy into electrical energy.

Tom Dayspring: Can’t metabolize cholesterol. Cholesteryl ester, which carries that fat can be de-esterified, but your cells aren’t making cholesteryl ester, the liver is, the intestine is, the adipocyte are.

Peter Attia: My hypothesis for why that’s the case, which could be entirely bullshit, and I’m just making it up, but that’s what hypotheses are, they’re guesses. Is that it would have been evolutionarily dangerous if we could have metabolized cholesterol. Because in periods of fasting, which we all did evolutionarily, the last thing you want your body doing is going after cell membranes and hormones as a source of energy. So I think it’s actually a very deliberate “design”, I use design in quotes, to say, “Hey no matter what, your cholesterol and your hormones are off limits during starvation.” And instead we evolved this other remarkable pathway of ketosis, which takes an ample substrate of fats and goes down the path of metabolizing those, and actually saving our muscle from the catabolic destruction that we would undergo if we couldn’t undergo ketosis.

Tom Dayspring: This is the brilliance of Peter Attia to me, that he can come up with what sounds like a super plausible thing.

Peter Attia: It could be bullshit, so.

Tom Dayspring: I can tell you how the cell got cholesterol, what it can do, but he’s figured out what sounds like a really plausible reason. And everybody’s so worried about depleting cholesterol in the plasma as measured by LDL-cholesterol, which has nothing to do with anything. Because actually there’s more cholesterol in your red blood cells than there are in lipoproteins. And you’re not making that zero by any means, by using lipid drugs.

Tom Dayspring: But you can’t deplete a cell of cholesterol beyond a certain amount, because you’re going to hinder cellular function. And you can’t put too much cholesterol in that cell, because it’ll crystallize and kill that cell. So that’s why [cholesterol homeostasis] is so tightly regulated, synthesis, influx, and efflux.

Tom Dayspring: Now are there cells under circumstances for whatever reason can’t make enough cholesterol? Yeah, there are pediatric disorders where if you don’t synthesize cholesterol, things happen to you in utero ([Yang et al., 2018](https://www.sciencedirect.com/science/article/pii/S0009898118300342?via%3Dihub); [Kelley, 2000](https://www.ncbi.nlm.nih.gov/pubmed/10959439)).

Peter Attia: Well the other thing we see this in, and I don’t even know why I started noticing this, but this is one of the things I used to do in residency, that used to kind of piss off some of the attendings, is I would do little experiments. And it was always a measurement experiment, so it wasn’t like I was putting a patient at risk, other than a few more milliliters of blood were being drawn. But I remember once, happening on a finding, which was maybe by accident, I had checked a lipid panel on a patient in the ICU, and I saw something interesting and I kept rechecking it in other patients over and over again, and I kept seeing this.

**[1:20:00]**

Which was any time a patient was having a SIRS response, that’s S-I-R-S, systemic inflammatory response syndrome, so this is the vasometabolic response to sepsis, infection, trauma, you name it. Enormous drop in HDL-cholesterol.

Peter Attia: I think we could look at that today and say it’s very likely that what we were seeing was, in that period of profound physiologic stress, the body is greatly ramping up its hormone production, with corticoids, and others. And that would be one of the situations where HDL was now delivering cholesterol to adrenals glands in a period of, because that’s about the most physiologically stressful thing that an organism can respond to. Again, I don’t know if that’s been documented, but it seems to me pretty logical, that would be at least the most plausible explanation for why HDL could plummet in patients who are going through that degree of stress.

Tom Dayspring: Yes, and by the way it’s the reason you never do a lipid profile in an acute situation, because a lot of lipids are going to be transiently changed. Peter’s right, we know this for a lot of reasons. Clearly steroidogenic tissues need cholesterol to make their steroid hormones, be they reproductive organs or your adrenal cortex. And in the situations Peter is talking about, cortisone is a pretty useful hormone to have around, or other mineralocorticoids and things like that are.

Tom Dayspring: So clearly those organs, those tissues are going to need a lot of cholesterol pools to make all that. So they turn up their synthesis rates so they make a lot of cholesterol, but they would also tune up their, hey let’s gather some exogenous cholesterol so to speak, so those cells would upregulate LDL receptors. And that’s a case where there’s a tissue that might under certain circumstances, pull in LDL particles full of cholesteryl ester, they would de-esterify it and use it. But in a physiologic person who’s not in one of these acute situations, the adrenal gland most of the time just makes all the cholesterol it needs. But if it needs a secondary source, that’s why you have HDLs.

Tom Dayspring: HDLs have a half life of five days. One of the reasons they circulate for five days, is it’s a floating plasma reservoir of cholesterol for tissues that might actually need cholesterol. Now my nose cells that I talked about before doesn’t need HDLs or anybody else to deliver cholesterol to it, no other cell does, except those steroidogenic tissues.

Peter Attia: In other words, to be really clear and specific, you’re sloughing off endothelial cells in your nose every day, well you have to replace them, the lion’s share of the cholesterol requirement is to make a cell membrane. It’s just it has the machinery, it has the machinery within the nucleus to produce that, just as it’s producing other structural proteins.

Tom Dayspring: Right. And this is what people just translate low cholesterol plasma measurements to think you’re screwing up cells throughout the body, and you’re not (reviewed in [Dietschy et al., 1993](https://www.ncbi.nlm.nih.gov/pubmed/8245716)).

Peter Attia: Yeah, this is one of the challenges, I’ve never come up with a great way to explain this idea of flux. Which is, you do a lipid measurement at a moment in time, you’re getting a snapshot of what’s in the plasma at a moment in time, which doesn’t give you two pieces of information: How is it changing over time, and what’s the movement or the velocity. And secondly, it gives you no insight into what’s happening in the cell, or what’s happening in the endothelium for that matter, and instead that’s the nature of lipidology. You have to be able to extrapolate to these other things by indirect measurements.

Tom Dayspring: It gives you zero insight. The only usability of plasma measurements are as surrogates of lipoprotein defining whether you have apoB, apoA-I particles, and we know too many apoB particles, you are, over time, at eventual risk, at increased risk for atherosclerotic disease or events. Otherwise, why even measure lipids in the plasma, [as such metrics] tell you nothing. And what we’re talking about, you call it influx, efflux, and that nails it down. But it’s cholesterol homeostasis or sterol homeostasis. And your body has evolved a lot of ways to manage that.

Tom Dayspring: What’s interesting, too: say that a crisis is going on, adrenal needs continue, and it’s not just hey you cured yourself in 12 hours overnight, you survived whatever. If that catastrophic process was ongoing, the HDLs eventually would run out of cholesterol. You just said your HDL cholesterol level is plummeting, and that’s been documented many times. So the HDL all of a sudden has to go back and start grabbing cholesterol molecules from some other tissue and get it to the steroidogenic tissue.

Tom Dayspring: And the mega place where HDLs get most of their lipidation, is it goes right back to the liver and gets lipidated, or what is the biggest cholesterol storage organ in the body. Not the liver, your adipocytes. Everybody thinks adipocytes are just storing triglycerides. They’re a massive sterol storage organ. So, baby (i.e., immature, small) HDLs that are depleted, they run back to the adipocytes which express this ABCA1 (ATP-Binding Cassette Transporter A1) transporter that pumps out (i.e., effluxes) all their cholesterol to an HDL which, boom, right back to the adrenal gland. Bounces back and forth like a ping pong ball there.

§

§

## Selected Links / Related Material

**Cholesterol measurements**: [Discovery of the Lipoproteins, Their Role in Fat Transport and Their Significance as Risk Factors](https://academic.oup.com/jn/article/128/2/439S/4724045) (Olsen, 1998) [2:20]

**Using an ultracentrifuge to study lipoproteins**: [Ultracentrifugal studies of lipoproteins of human serum](https://www.ncbi.nlm.nih.gov/pubmed/18150027) (Gofman et al., 1949) [2:20]

**Cholesterol bound to albumin (3:20) and reverse cholesterol transport (2:11:20)**: [Reverse cholesterol transport fluxes](https://www.ncbi.nlm.nih.gov/pubmed/24362356) (Hellerstein and Turner, 2014) [3:20, 1:01:45]

**Lipid treatise (5-part series) by Fredrickson, Levy, and Lees**: [Fat Transport in Lipoproteins — An Integrated Approach to Mechanisms and Disorders](https://www.nejm.org/doi/full/10.1056/NEJM196701262760406) (Fredrickson, Levy, and Lees, 1967) [4:30, 13:45]

**You cannot have atherosclerosis without a sterol lipid being in your arterial wall**: [Cholesterol: the debate should be terminated](https://www.ncbi.nlm.nih.gov/pubmed/28663517) (Nathan, 2017) [4:30]

**Gofman first inputed a transporter, but then linked it in this paper**: [Evaluation of Serum Lipoproteins and Cholesterol Measurements as Predictors of Clinical Complications of Atherosclerosis – Cooperative Study of Lipoproteins and Atherosclerosis](https://www.ahajournals.org/doi/pdf/10.1161/01.cir.14.4.689) (Gofman et al., 1956) [5:30]

**Apoproteins**: [Apolipoprotein structure and dynamics](https://www.ncbi.nlm.nih.gov/pubmed/15891389) (Gursky, 2015) [11:00]

**Alaupovic & Fredrickson, Levy, and Lees start giving names to lipoproteins**: [Petar Alaupovic: The father of lipoprotein classification based on apolipoprotein composition](https://www.ncbi.nlm.nih.gov/pubmed/24945028) (Sacks and Brewer, 2014) [13:45]

**Friedewald’s estimation of LDL-C**: [Estimation of the concentration of low-density lipoprotein cholesterol in plasma, without use of the preparative ultracentrifuge](https://www.ncbi.nlm.nih.gov/pubmed/4337382) (Friedewald, Levy, and Fredrickson, 1972) [23:30]

**The Martin-Hopkins calculation**: [Comparison of a novel method vs the Friedewald equation for estimating low-density lipoprotein cholesterol levels from the standard lipid profile](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1001%2Fjama.2013.280532) (Martin et al., 2013) [28:45]

**NMR for measuring lipoprotein concentrations**: [Development of a proton nuclear magnetic resonance spectroscopic method for determining plasma lipoprotein concentrations and subspecies distributions from a single, rapid measurement](https://www.ncbi.nlm.nih.gov/pubmed/?term=CLIN.+CHEM.+38%2F9%2C+1632-1638) (Otvos et al., 1992) [29:30, 32:00]

**Pathophysiology first stumbled upon, that it even mattered how many of these particles you have**: [Apolipoprotein B and cardiovascular disease risk: Position statement from the AACC Lipoproteins and Vascular Diseases Division Working Group on Best Practices](https://www.ncbi.nlm.nih.gov/pubmed/19168552) (Contois et al., 2009) [30:45]

**Early on it was discovered the apoB particles going into the artery wall, and delivering these sterols that set off a maladaptive inflammatory process**: [2016 Russell Ross Memorial Lecture in Vascular Biology: Molecular-Cellular Mechanisms in the Progression of Atherosclerosis](https://www.ncbi.nlm.nih.gov/pubmed/27979856) (Tabas, 2017) [32:00]

**The apoB particles going into the artery wall**: [Lipoprotein retention–and clues for atheroma regression](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1161%2F01.ATV.0000174795.62387.d3) (Williams and Tabas, 2005) [32:00]

**The apoB particles going into the artery wall**: [2016 Russell Ross Memorial Lecture in Vascular Biology: Molecular-Cellular Mechanisms in the Progression of Atherosclerosis](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1161%2FATVBAHA.116.308036) (Tabas, 2017) [32:00]

**Either apoB or LDL particle number correlates a lot better with clinical events**: [LDL Particle Number and Risk of Future Cardiovascular Disease in the Framingham Offspring Study – Implications for LDL Management](https://www.ncbi.nlm.nih.gov/pubmed/19657464) (Cromwell et al., 2007) [33:00]

**Type III dysbetalipoproteinemia**: [Diagnosis of type III hyperlipoproteinemia from plasma total cholesterol, triglyceride, and apolipoprotein B](https://www.lipidjournal.com/article/S1933-2874(07)00197-3/abstract) (Sniderman et al., 2007) [34:15]

**LDL-P and LDL-C discordance**: [Discordance analysis and the Gordian Knot of LDL and non-HDL cholesterol versus apoB](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1097%2FMOL.0000000000000127) (Sniderman et al., 2014) [35:15]

**Circulating noncholesterol sterols/stanols (NCS) measurements**: [Biomarkers of cholesterol homeostasis in a clinical laboratory database sample comprising 667,718 patients](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1016%2Fj.jacl.2015.08.003) (Dayspring et al., 2015) [46:45]

**Plant sterols**: [Vascular effects of diet supplementation with plant sterols](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1016%2Fj.jacc.2007.09.074) (Weingärtner et al., 2008) [51:00, 52:30]

**Plant sterols**: [Serum plant sterols as a potential risk factor for coronary heart disease](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1053%2Fmeta.2002.36298) (Sudhop et al., 2002) [51:00, 52:30]

**Sterol absorption and synthesis**: [Plant sterols, cholesterol precursors and oxysterols: Minute concentrations-Major physiological effects](https://www.ncbi.nlm.nih.gov/pubmed/26733205) (Olkkonen et al., 2015)

**Sterol absorption and synthesis, and oxysteroles**: [Interactions of oxysterols with membranes and proteins](https://www.ncbi.nlm.nih.gov/pubmed/19248802) (Olkkonen and Hynynen, 2009)

**Cholesterol absorption**: [Cholesterol and plant sterol absorption: recent insights](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1016%2Fj.amjcard.2005.03.014) (von Bergmann et al., 2005) [53:30]

**Cholesterol absorption**: [Intestinal lipid absorption](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1152%2Fajpendo.90899.2008) (Iqbal and Hussain, 2009) [53:30]

**Niemann-Pick C1-Like 1 (NPC1L1) transporter**: [Will the Real Cholesterol Transporter Please Stand Up](https://science.sciencemag.org/content/303/5661/1149) (Klett and Patel, 2004) [53:30]

**ATP-binding cassette G5/G8 (ABCG5 & ABCG8)**: [Plant Sterols, Stanols, and Sitosterolemia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4514516/) (Ajagbe et al., 2015) [53:30]

**Cholesterol absorption**: [U-shape relationship between change in dietary cholesterol absorption and plasma lipoprotein responsiveness and evidence for extreme interindividual variation in dietary cholesterol absorption in humans](https://www.ncbi.nlm.nih.gov/pubmed/?term=J+Lip+Res+1998%3B39%3A2415-22) (Sehayek et al., 1998) [54:30]

**NPC1L1 deficiencies**: [Deficiency of Niemann-Pick C1 Like 1 prevents atherosclerosis in ApoE-/- mice](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1161%2F01.ATV.0000257627.40486.46) (Davis et al., 2007) [54:30]

**NPC1L1 deficiencies**: [Inactivating mutations in NPC1L1 and protection from coronary heart disease](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1056%2FNEJMoa1405386) (Stitziel et al., 2014) [54:30]

**People with hypofunctioning PCSK9**: [Mutations in PCSK9 cause autosomal dominant hypercholesterolemia](https://www.ncbi.nlm.nih.gov/pubmed/12730697) (Abifadel et al., 2003) [55:00]

**People with hypofunctioning PCSK9**: [Low LDL cholesterol in individuals of African descent resulting from frequent nonsense mutations in PCSK9](https://www.ncbi.nlm.nih.gov/pubmed/15654334) (Cohen et al., 2005) [55:00]

**People with hypofunctioning PCSK9**: [Sequence variations in PCSK9, low LDL, and protection against coronary heart disease](https://www.ncbi.nlm.nih.gov/pubmed/16554528) (Cohen et al., 2006) [55:00]

**NPC1L1 structure and function**: [The structure and function of Niemann-Pick C1-like 1 protein](https://www.ncbi.nlm.nih.gov/pubmed/?term=Yu+L+et+al.+Curr+Opin+Lipidol+19%3A263%E2%80%93269) (Yu, 2008) [55:30]

**NPC1L1 structure and function**: [Mechanisms and genetic determinants regulating sterol absorption, circulating LDL levels, and sterol elimination: implications for classification and disease risk](https://www.ncbi.nlm.nih.gov/pubmed/?term=Calandra+S+et+al.+J.+Lipid+Res.+2011.+52%3A1885%E2%80%931926) (Calandra et al., 2011) [55:30]

**ATP-binding cassette (ABC) transporters**: [The ABCs of sterol transport](https://www.ncbi.nlm.nih.gov/pubmed/?term=10.1194%2Fjlr.R800044-JLR200) (Baldán et al., 2009) [58:30]

**Acetyl CoA and cholesterol**: [ON THE UTILIZATION OF ACETIC ACID FOR CHOLESTEROL FORMATION](https://www.jbc.org/content/145/2/625.full.pdf) (Bloch and Rittenberg, 1942) [1:08:45]

**Demosterolosis**: [Mutations in the 3β-Hydroxysterol Δ24-Reductase Gene Cause Desmosterolosis, an Autosomal Recessive Disorder of Cholesterol Biosynthesis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1226055/) (Waterham et al., 2001) [1:12:00]

**Pediatric disorders where if you don’t synthesize cholesterol, things happen to you in utero**: [Smith-Lemli-Opitz Syndrome in a newborn infant with developmental abnormalities and low endogenous cholesterol](https://www.sciencedirect.com/science/article/pii/S0009898118300342?via%3Dihub) (Yang et al., 2018) [1:19:15]

**Pediatric disorders where if you don’t synthesize cholesterol, things happen to you in utero**: [Inborn errors of cholesterol biosynthesis](https://www.ncbi.nlm.nih.gov/pubmed/10959439) (Kelley, 2000) [1:19:15]

**Cholesterol homeostasis**: [Role of liver in the maintenance of cholesterol and low density lipoprotein homeostasis in different animal species, including humans](https://www.ncbi.nlm.nih.gov/pubmed/8245716) (Dietschy et al., 1993) [1:23:00]

§

§

## People Mentioned

- [John Gofman](https://en.wikipedia.org/wiki/John_Gofman) (a pioneer in clinical lipidology) [2:15]
- [Donald Fredrickson](https://en.wikipedia.org/wiki/Donald_S._Fredrickson) (a pioneer in lipid and cholesterol metabolism) [13:30]
- [Robert Levy](https://en.wikipedia.org/wiki/Robert_A._Levy) (a pioneer in lipid and cholesterol metabolism [13:30]
- [Robert Lees](https://news.mit.edu/2017/robert-lees-cardiologist-former-mit-faculty-member-dies-0626) (a pioneer in lipid and cholesterol metabolism [13:30]
- [Petar Alaupovic](https://www.ncbi.nlm.nih.gov/pubmed/24945028) (father of lipoprotein classification based on apolipoprotein composition) [13:30]
- [Ron Krauss](https://profiles.ucsf.edu/ronald.krauss) (a pioneer in lipid and cholesterol metabolism [13:30]
- [Gerald Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) (propounded the theory that central obesity, diabetes, and hypertension have a common cause in insulin resistance and impaired glucose tolerance: he initially titled it “syndrome X,” which came to be known as [metabolic syndrome](https://en.wikipedia.org/wiki/Metabolic_syndrome)) [22:15]
- [William Friedewald](https://www.mailman.columbia.edu/people/our-faculty/wtf1) (known for the Friedewald equation for estimating LDL-C) [24:30]
- [Jim Otvos](https://en.wikipedia.org/wiki/Jim_Otvos) (known for NMR, apoB, and research on LDL particles) [29:15]
- [Allan Sniderman](https://www.mcgill.ca/expmed/dr-allan-d-sniderman) (demonstrated apoB to be superior to LDL-C as a marker of risk of CVD) [39:30]
- [Josh Knowles](https://profiles.stanford.edu/joshua-knowles) (research into the genetic basis of CVD and familial hypercholesterolemia [FH] research) [39:30]
- [Bob Kaplan](https://twitter.com/bobkaplan) (Peter’s right-hand man and head analyst at Attia Medical) [44:00]
- [Jamie Underberg](https://twitter.com/lipiddoc) (lipidologist, past-president of the NLA, Director: Bellevue Hospital Lipid Clinic) [1:05:45]
- [Konrad Bloch](https://en.wikipedia.org/wiki/Konrad_Emil_Bloch) ([Shared the Nobel Prize with Feodor Lynen](https://www.nobelprize.org/prizes/medicine/1964/summary/) “for their discoveries concerning the mechanism and regulation of the cholesterol and fatty acid metabolism”) [1:10:15]

§

§

![](https://peterattiamd.com/wp-content/uploads/2018/10/tom-dayspring-300x300.jpg)

##### Thomas Dayspring, M.D., FACP, FNLA

Thomas Dayspring, MD, FACP, FNLA is the chief academic officer for True Health Diagnostics, LLC. He provides scientific leadership and direction for the company’s comprehensive educational programs. Dr. Dayspring is a fellow of both the American College of Physicians and the National Lipid Association. He is certified in internal medicine and clinical lipidology.

Before relocating to Virginia in 2012, Dr. Dayspring practiced medicine in New Jersey for 37 years. Over the last two decades, he has given over 4,000 domestic and international lectures, including over 600 CME programs on topics such as atherothrombosis, lipoprotein and vascular biology, biomarker testing, and women’s cardiovascular issues.

Dr Dayspring is an Associate Editor of the Journal of Clinical Lipidology. He has authored or co-authored numerous manuscripts published across leading journals such as the American Journal of Cardiology, the Journal of Clinical Lipidology, and several lipid-related book chapters. He was the recipient of the 2011 National Lipid Association President’s Award for services to clinical lipidology. [[truehealthdiag.com](https://truehealthdiag.com/leadership/thomas-dayspring/)]

Disclosures:

- Employed full time for last three years by True Health Diagnostics, LLC, which provides biomarker diagnostics and clinical services to clinicians, patients, and healthcare organizations
- 2017: small consulting project for Abbvie

Tom on Twitter: [@DrLipid](https://twitter.com/Drlipid)