# #373 – Thyroid function and hypothyroidism: why current diagnosis and treatment fall short for many, and how new approaches are transforming care | Antonio Bianco, M.D., Ph.D.

**Source:** [https://peterattiamd.com/antoniobianco/](https://peterattiamd.com/antoniobianco/)

---

Antonio Bianco is a world-renowned physician-scientist and expert in thyroid physiology and metabolism. In this episode, Antonio explores the complex biology of thyroid hormone production, conversion, and regulation—highlighting how deiodinase enzymes modulate hormone activity at the tissue level and why that matters for interpreting lab results. He discusses the shortcomings of relying solely on TSH as a marker of thyroid function, the ongoing debate around combination therapy with T3 and T4 versus standard T4 treatment, and how genetics, tissue sensitivity, and individual variability influence thyroid hormone metabolism. The conversation also examines how hypothyroidism affects energy, mood, cognition, and longevity; why some patients remain symptomatic despite “normal” labs; and how future research could reshape treatment paradigms.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/antoniobianco/the_Drive_public.png)

Play

#373 – Thyroid function and hypothyroidism: why current diagnosis and treatment fall short for many, and how new approaches are transforming care | Antonio Bianco, M.D., Ph.D.

#373 – Thyroid function and hypothyroidism: why current diagnosis and treatment fall short for many, and how new approaches are transforming care | Antonio Bianco, M.D., Ph.D.

1x15s30s

0:002:20:06

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- How the thyroid produces, stores, and activates hormones like T4 and T3 to finely regulate thyroid activity [A: 2:45, V: 0:11];
- How fasting alters thyroid hormones to conserve energy [A: 12:45, V: 11:08];
- Action of the deiodinases: how D1, D2, and D3 enzymes control the activation and inactivation of thyroid hormones [A: 19:15, V: 18:07];
- The normal function of thyroid hormone and the roles of the hypothalamus, pituitary gland, and deiodinases in maintaining hormonal balance [A: 23:30, V: 22:59];
- Why understanding thyroid physiology is essential for proper diagnosis and treatment of hypothyroidism [A: 33:45, V: 34:12];
- Testing for thyroid hormones: understanding free vs. total levels, the limitations of current T3 assays, best practices, and more [A: 36:00, V: 37:03];
- Genetic and sex-based variability in thyroid hormone regulation and their limited clinical significance [A: 43:45, V: 45:40];
- Hyperthyroidism: causes, symptoms, diagnosis, and treatment options [A: 46:00, V: 48:23];
- Hypothyroidism: diagnosis and autoimmune causes of hypothyroidism [A: 56:30, V: 1:00:10];
- More on hypothyroidism: diagnostic biomarkers, antibody patterns, and non-autoimmune presentations [A: 1:05:00, V: 1:09:34];
- Thyroid hormone replacement therapy [A: 1:15:15, V: 1:20:58];
- More on thyroid replacement strategies: exploring the evidence gaps, mortality signals, effects on lipids, and more [A: 1:28:00, V: 1:35:35];
- Hypothyroidism basics: causes, antibody implications (including pregnancy), and how to make the diagnosis before choosing therapy [A: 1:35:15, V: 1:43:25];
- Thyroid medication: compounded controlled-release T3, brand name versus generic, and what Antonio prescribes to newly diagnosed hypothyroid patients [A: 1:42:45, V: 1:52:11];
- Redefining treatment success: why normalizing TSH isn’t always enough for patients with hypothyroidism [A: 1:54:45, V: 2:05:26];
- Case studies: analysis of two unusual cases of thyroid disease [A: 1:57:00, V: 2:08:22];
- Dangers of supplementing with high levels of iodine, and female-specific risk of thyroid disease [A: 2:05:45, V: 2:18:45];
- Case study of a patient who presents with elevated TSH but no symptoms [A: 2:09:30, V: 2:23:09];
- How future research could reshape treatment, and Antonio’s new book called “Rethinking Hypothyroidism” [A: 2:13:15, V: 2:27:54]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Antonio Bianco is a physician-scientist and an internationally recognized expert in thyroid physiology and metabolism
- He is currently serving as the senior vice president and dean interim of the John Sealy School of Medicine and chief research officer at [UTMB](https://www.utmb.edu/provost/resources/academic-enterprise-announcements/article/academic-enterprise-announcements-and-information/2024/07/17/bianco-named-vice-president-and-vice-provost-for-research--chief-research-officer)
  - He previously served as the president of the American Thyroid Association
- He spent decades studying how thyroid hormones affect every cell in the body
  - With particular focus on the enzymes (called deiodinases) that activate or deactivate these hormones at the tissue level
- He is the author [*Rethinking Hypothyroidism*](https://www.amazon.com/Rethinking-Hypothyroidism-Treatment-Change-Patients/dp/0226823164/ref=sr_1_1?crid=14CPSL4YRAK54&dib=eyJ2IjoiMSJ9.Q1CVkWTYtWBY7PbsC1cS7nGrtdcCzUf0J1Fqf7rido6w0oKfPrISMlsuX279O-zC10bkf_Lx3uZhOQq0gbsf5fAr21NeqTPLmPihz2F2a2ua8XflP5vwdLDX16HE6We69or6xhHnNLDl5KggVu2mJV92lwpQoQk609L8ywLnGs5w1lnIw67L7md_eH8Jg0AW.DDjJuzWhTe5lgsKlnXD1M6oIVCD7xlxWwoQjf28XALg&dib_tag=se&keywords=rethinking+hypothyroidism&qid=1761155966&sprefix=rethinking+hypo%2Caps%2C112&sr=8-1), which explores the science, controversies, and patient experiences surrounding thyroid hormone replacement therapy

In this episode, we discuss

- The fundamental biology of thyroid hormone production, conversion, and action throughout the body
- How the deiodinase enzymes regulate the local thyroid activity, and why that matters for interpreting lab results
- The limitations of using only TSH as a marker of thyroid function
  - And what’s often missed in clinical practice
- Combination therapy: T3 and T4 versus standard levothyroxine (or T4) treatment
- The role of genetics, tissue sensitivity, and individual variability around thyroid metabolism
- How hypothyroidism affects energy, mood, metabolism, and cognitive function
- The complex relationship between thyroid hormones and mitochondrial efficiency, cardiovascular health, and longevity
- Why some patients continue to feel unwell despite “normal” thyroid labs
- How future research could reshape treatment approaches

## How the thyroid produces, stores, and activates hormones like T4 and T3 to finely regulate thyroid activity [A: 2:45, V: 0:11]

- Galveston is 3 hours away, where Antonio is dean of the medical school and runs a lab

**Tell me a little bit about what your research focuses on, and maybe even what got you interested in studying the thyroid system?**

- Antonio’s research is trying to understand what thyroid hormone does
  - And by understanding what it does in different tissues, we will be able to serve patients that don’t have sufficient thyroid hormone (patients with [hypothyroidism](https://en.wikipedia.org/wiki/Hypothyroidism))
- He focuses on the action of thyroid hormone at the tissue level: What does it do in the liver? What does it do in the heart?
- But then we go into the cell level, and we are currently looking at how thyroid hormone affects the folding of the chromatin
  - Because that’s how it regulates gene expression
- Basically that’s how T3 or thyroid hormone acts: by regulating different genes
  - And because the genes are basically the essence of the cell functioning, by regulating the expression of those genes, it changes the way the cell behaves, and that has an important consequence for the whole tissue, and for the organ, and for the body

**Let’s start with the stuff that is largely known about the thyroid**

- Many people know that they have a gland that sits over the voice box called the [thyroid gland](https://en.wikipedia.org/wiki/Thyroid) and that it produces a hormone
- Some people might know that the hormone is actually inactive ‒  it’s abbreviated [T4](https://en.wikipedia.org/wiki/Thyroxine), because it has 4 iodines on it
- And now we’re getting maybe past what most people would know, but [enzymes](https://en.wikipedia.org/wiki/Deiodinase) in the body take 1 of those iodines off, and make an active form of that hormone that we abbreviate [T3](https://en.wikipedia.org/wiki/Triiodothyronine)

**⇒** Peter suspects that a number of people watching or listening realize that this hormone [T3] is very important, and it has properties that regulate energy expenditure, body temperature, mood, sleep, all sorts of things

- The final thing that is probably common knowledge is that it is not entirely uncommon that some people don’t seem to make enough of that hormone for one reason or another, and that as a result of that they have to supplement that hormone
  - And that condition could be referred to as hypothyroidism
  - We’re going to talk about all of these things, of course
- Peter would venture that there are tens of thousands of people listening to us right now that would identify as having [hypothyroidism](https://en.wikipedia.org/wiki/Hypothyroidism), and that are taking some form of thyroid replacement

***Our objective today is to make sense of this whole thing, because there are so many different ways that people think about how to replace that hormone, there are so many different that people think about how to diagnose the condition, and it seems that it is a much more complex endocrine situation than the other major systems we think about***

- It doesn’t seem very difficult to understand what low testosterone is
  - You have a very simple assay, you understand the symptoms quite well
  - Replacing it is quite simple

**So, with that said, let’s go back to that meta-level, layer on as much detail as you’d like about the thyroid gland and what it’s doing**

- That was a great introduction
- The [thyroid gland](https://en.wikipedia.org/wiki/Thyroid), what it does is takes up iodine from the blood and uses that iodine to produce a hormone
  - That’s quite interesting, quite unique
  - We basically ingest iodine every day on our diet (for example, seafood is full of iodine), and we really need that iodine so that the thyroid can function

**⇒** Without iodine there’s no thyroid hormone. Luckily, what we do is we supplement the kitchen salt with iodine.

- This is not something that we have to worry, if you have a reasonable amount of iodine every day, it will provide sufficient amounts to make the thyroid hormone
- The thyroid traps iodine, and through a series of complicated reactions it makes up the thyroid hormone
- It also stores a large amount of hormone

**⇒** The thyroid is basically a large storage of thyroid hormone, mostly the pro-hormone, the inactive hormone, T4

- [T4](https://en.wikipedia.org/wiki/Thyroxine) has 4 atoms of iodine
- The thyroid slowly secretes T4 into circulation on a daily basis so the blood has a storage of T4

**⇒** Now, T4 doesn’t do much, when we talk about the importance of thyroid hormone, it’s important for the brain, important for the heart, for the bones, we’re not talking about T4, we are talking about the other hormone, the active hormone, [T3](https://en.wikipedia.org/wiki/Triiodothyronine)

- It’s amazing that by just removing one atom of iodine from the T4, it now becomes a fully active hormone
  - And why is that?
  - Because cells, tissues, have receptors
  - The [receptors](https://en.wikipedia.org/wiki/Thyroid_hormone_receptor) don’t like T4, they don’t bind T4 that much
  - Receptors love T3, they bind T3 with high affinity

Peter asks, “*This is just purely a conformational difference or is it electrostatic?*”

- It’s conformational, it doesn’t fit into the pocket of the receptor
  - The pocket of the receptor has low affinity for T4 ‒ if you put a lot of T4 then yes, you’re going to get some action, but normally those are extremely high levels

**From an evolutionary perspective (not that we can ever know for sure), do you suspect that the reason for this is that it makes more sense to secrete an inactive pro-hormone that has a long half-life that can go everywhere and then each tissue can selectively make its determination of how much active hormone it needs?**

- The evolutionary pressure is iodine deficiency
- The whole system evolved in a way to preserve iodine
- You see, the thyroid is full of thyroid hormone, it has 4 atoms of iodine, and then by removing one, it becomes active
  - So, it’s preserving iodine as much as possible
- And what happens with that iodine that was removed?
  - It’s taken back up again

***It’s all about preserving the iodine so that we don’t go into a situation that we don’t have enough iodine to produce that hormone***

**Presumably when iodine is abundant, you can stockpile more T4 within the gland**

- Absolutely, that’s right

**T3 is the active hormone**

- Once you remove the atom of iodine, what happens is that the molecule becomes T3 (the active hormone), but then it has a short half-life

**⇒** The contrast between T3 and T4 is dramatic: T4 has a half-life of about 8 days, T3 has a half-life of about 12 hours

- Once T3 is activated, it triggers its destruction
  - It has a brief action
  - It works potently, however it’s targeted for destruction (it’s just metabolized and cleared)
  - And that tells you that this is a way the body has to regulate the action of thyroid hormone
- So, once it’s activated, let’s make sure it’s still active 12 hours later (you still need to have all that activity)
- It slowly activates, and if for any reason we have to stop activating, after you stop, shortly after the action of T3 will decrease

***That’s a way of limiting the amount of exposure of the tissues to the active thyroid hormone***

**Peter has heard that there are different deiodinases**

- Just for the listener, the [deiodinases](https://en.wikipedia.org/wiki/Deiodinase) are enzymes that (as its name suggests) remove an iodine atom from T4 to [create] T3
- Correct

**But there is a molecule called reverse T3, say a little bit about that and how it differs from T3**

- [Reverse T3](https://en.wikipedia.org/wiki/Reverse_triiodothyronine) is AT3, an alternative form of T3
- It all depends on which iodine is removed from the molecule of T4
- The molecule of T4 has two rings, the inner ring and the outer ring [shown in the figure below]
  - If you remove the iodine from the outer ring, you make T3 [T3 is on the left side of the figure below]
  - If you remove the iodine from the inner ring, you make reverse T3 [rT3 is on the right side of the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/11/f1-antoniobianco.png)

**Figure 1. Synthesis of T3 and reverse T3 (rT3) from T4, and synthesis of T2**. Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Reverse_triiodothyronine#)

Peter asks, “*Does it matter which one from the inner ring and which one from the outer ring?*”

- No, it doesn’t
- Either one can do the trick
- And the amazing thing is that, whereas T3 is a super active molecule, ***reverse T3 is dead***, it has less activity than T4 even
  - You really need an astronomical amount of reverse T3 to do anything to the receptor (so, it’s really not active)

The thyroid is constantly secreting T4 into the circulation

- The deiodinases will take T4 and either make T3 or reverse T3
  - And so, either activates or inactivates thyroid hormone
  - And that constitutes an alternative pathway that can also be altered on a moment’s notice
- For example, all of a sudden you have all this T4 available, and let’s say the body wants to reduce the activation of thyroid hormone
  - Instead of putting the T4 through the T3 pathway, T4 will preferentially go through the reverse T3 pathway and will be completely inactive

## How fasting alters thyroid hormones to conserve energy [A: 12:45, V: 11:08]

**A very extreme case, but a true scenario**

- Peter used to do a lot of fasting (he would fast for up to 7-10 days every quarter)
- He would check his blood work before and after a fast
- His typical thyroid numbers at the beginning, before he started fasting, and at the end
  - Keeping in mind, we haven’t explained what TSH is yet, and we’ll come back to it
  - But just to get the T3/T4 part
- Before a fast, he might have a TSH of 2, a free T3 of 0.3, and a reverse T3 of 10
- After the fast, the TSH would go to 7, the free T3 would be 0.2 (so it would go down by 50%), the reverse T3 would be 35

*What is happening in my body that would lead to those dramatic changes in those thyroid hormones?*

- What’s happening is that the [hypothalamus](https://en.wikipedia.org/wiki/Hypothalamus) (which is the center in the brain that regulates the thyroid function) is detecting that you’re not eating
  - How does it detect that?
  - Your insulin levels are low, your leptin levels are coming down, and those are cues to the hypothalamus to say, well, wait a minute, there’s not a lot of food coming in here

**⇒** Thyroid hormone accelerates energy expenditure, thyroid hormone is all about burning energy, burning sugar, burning protein

- So, the hypothalamus says, “*Well, I have to reduce, take my foot off the gas here, so that even though there’s less food coming in, in your case, nothing, we’re going to reduce the rate at which I’m burning the fuel here.*”

***And so, your TSH, even though it is within the normal range, now it is inappropriately normal because your T4 came down***

- Antonio points out that Peter didn’t mention his T4, but T4 certainly would have come down, and that’s why the TSH went up (slightly)

Antonio points out, “*Normally, if you have a significant drop in T4, the TSH should go up much more.*”

- The TSH is not going up so much because the hypothalamus is telling TSH, “*Don’t go up, there’s no need, because right now we want to slow things down*.”
- So, your TSH is inappropriately normal, even though the T4 is down, the T3 is down
- Why is T3 down?
  - Your thyroid is secreting less T4, but also a little bit of T3, it’s making less T3 as well

***But most importantly, the*** [***deiodinases***](https://en.wikipedia.org/wiki/Iodothyronine_deiodinase) ***pathway: the T4 now is being converted preferentially to reverse T3, and not so much to T3, and that’s why reverse T3 goes up***

- Now, there’s another reason for why reverse T3 is up
  - Because reverse T3 has a very short half-life, just a few hours (even shorter than T3)

**⇒** Reverse T3 is cleared through the D1 pathway

- There are 3 deiodinases, and [D1](https://en.wikipedia.org/wiki/Iodothyronine_deiodinase#Types) is richly expressed in the liver, very sensitive to insulin and carbohydrates

**⇒** If you eating a lot of carbohydrates, your D1 in the liver is going to go up, and the opposite, when you don’t eat so much

- So, what’s happening is D1 activity is coming down in the liver because you’re not eating (insulin down, carbohydrates down)
- And because D1 metabolizes reverse T3, reverse T3 builds up in the blood
- So, not only is there more reverse T3 production, but there’s also less reverse T3 metabolism
  - That’s why reverse T3 goes up
- T3 is down, just because it’s not being produced so much, and your energy expenditure is going down

Antonio explains, “*It’s common to see individuals that fast, that in the first few days they lose a significant amount of body weight, but then it reaches a plateau. And a lot of people, some studies attribute this plateau to the fact that the thyroid hormone levels are down. You are equating the amount of calories you’re taking with your energy expenditure, you’re reducing it*.”

**Is that ratio of free T3 to reverse T3, the rising level of that ratio, is that a poor man’s proxy of aggregate thyroid activity in the body, or is that just too coarse a manner to look at it?**

- Peter looks back at his numbers
  - He started out at a ratio of 0.3/10 (call it 0.03 or 3%)
  - The it goes to 2/30 (it’s basically falling by 50%)
  - Peter suggests, “*That would maybe suggest a significant set of breaks on my metabolism.*”
- Correct

*Can we infer anything else in that?*

- Yes

***The ratio is a good surrogate of deiodinases activity***

- Because honestly, we can’t measure the deiodinases in humans
  - [To do that we would] need a biopsy, we need a tissue sample to measure deiodinases activity
  - This is not something we do in the blood, blood doesn’t have deiodinases
  - So, we need a surrogate

Antonio explains, “*How can we estimate what’s happening in terms of deiodinases metabolism here? And the T3 to reverse T3 ratio is the surrogate*.”

- If T3 to reverse T3 is going up, it means you’re activating and not so much inactivating
- The opposite happens when the ratio inverts

***The T3:reverse T3 one of the best ratios we have to estimate what’s happening, but again, remember, this is a good estimate because there are multiple factors affecting the T3 to reverse T3 ratio***

- The thyroid is still producing some
  - There’s the production and there’s the clearance
  - So this is not purely reflecting production, there’s also clearance, but it’s useful

## Action of the deiodinases: how D1, D2, and D3 enzymes control the activation and inactivation of thyroid hormones [A: 19:15, V: 18:07]

**You mentioned that this was D1, tell us about D2 and D3, where do they reside? What do they do?**

- [D2](https://en.wikipedia.org/wiki/Iodothyronine_deiodinase#Types) works very similarly to D1, however, D2 is a superb enzyme
  - D2 has 1000-fold more affinity for [T4](https://en.wikipedia.org/wiki/Thyroxine) than D1
  - D1 is a lousy enzyme
  - Even though D1 was the first one discovered in the liver and in the kidneys, but D2 is so much more efficient (it’s like a super charged enzyme)
- If you ask about the [T3](https://en.wikipedia.org/wiki/Triiodothyronine) that’s produced outside of the thyroid
  - Most T3 is produce outside of that
- Who produces T3 outside of that? Is it D1 or D2?
  - Studies done in the 70s show that it is D2 pathway

***D2 makes about 80% of the T3 that’s made outside of the thyroid gland, D1 makes only 20%***

- Although, when we talk about [hypothyroidism](https://en.wikipedia.org/wiki/Hypothyroidism), there could be a role for D1
  - D1 is making both T3 and a little bit of reverse T3
- But the king of reverse T3 is the third deiodinase (D3)

***D1 and D2, they activate thyroid hormone mostly, D3 only does one thing, inactivates thyroid hormone (D3 kills everything)***

- D3 takes T3 and transforms it into [T2](https://en.wikipedia.org/wiki/3,3%27-Diiodothyronine), a dead molecule
- So, where does T3 go?
  - T3 goes to D3, and it’s killed, completely
- D3 is a very effective enzyme, it has high affinity for T3
- D3 also takes T4 and makes [reverse T3](https://en.wikipedia.org/wiki/Reverse_triiodothyronine)

Antiono’s summarizes, “*So, D3 inactivates T3 and makes sure T4 doesn’t do anything (takes T4 and makes reverse T3).*”

- So, D1 makes reverse T3, but very little, because the affinity of D1 for T4 is not that great

> “*When you think about it, D3 and D2 are the most powerful deiodinases. D2 making T3, D3 eliminating, inactivating thyroid hormone.*”‒ Antonio Bianco

**Which enzyme makes the most reverse T3?**

- D3
- D3 is basically a dead pathway

Peter asks, “*And what determines if it goes down D2 (which just takes the hormone out of pocket) versus making reverse T3 (which actually puts another molecule in the receptor that prevents T3 from getting there)? It seems that making reverse T3 is actually more anti-thyroid.*”

**⇒** Reverse T3 doesn’t bind to the pocket

**What’s the difference in futility of reverse T3 and D2?**

- You have a molecule of T3, which has all of this biologic activity
- What is the difference between turning that into reverse T3 versus turning it into T2?

***No difference***

- T2 is dead, reverse T3 is dead
- T2 doesn’t do anything

**Could we measure T2 in a laboratory assay and also get useful information about the balance of thyroid active versus inactive thyroid?**

- Not really
- We could measure T2, but T2 has an extremely short half-life
- Because as you go down this diamond of metabolism, you learn less and less because there are multiple pathways converging to T2
  - You have different ways of getting to T2

**⇒** Reverse T3 is more useful to measure because it at least sticks around for a few hours

- Reverse T3 is the immediate metabolism of T4
- So, you really know that once reverse T3 is made, there’s nothing else that’s going to come out of there

**Does the body recycle that iodine back?**

- Yes, absolutely
- Most iodine is recycled back

**There’s no pathway to go from reverse T3 back to T3?**

- No
- It’s a one-way path

## The normal function of thyroid hormone and the roles of the hypothalamus, pituitary gland, and deiodinases in maintaining hormonal balance [A: 23:30, V: 22:59]

**Anything else we want to say about the normal function of thyroid hormone before we start to talk about the two extreme states, hyper and hypo?**

*We should probably go back and say a little bit more about the hypothalamus and TSH regulation*

- The [hypothalamus](https://en.wikipedia.org/wiki/Hypothalamus#Function) is the key to everything here
- The hypothalamus produces this hormone that’s called [TRH (or TSH releasing hormone)](https://en.wikipedia.org/wiki/Thyrotropin-releasing_hormone)
- TRH is a small peptide that is released in the blood that baits the hypothalamus and immediately comes into the pituitary gland

**⇒** The [pituitary gland](https://en.wikipedia.org/wiki/Pituitary_gland) is where TSH is made

- So, if the hypothalamus is somehow destroyed, either by an accident or by a tumor or by a surgery, then TSH is not going to be produced, because you need TRH to stimulate TSH, and that’s a problem, that’s called [central hypothyroidism](https://en.wikipedia.org/wiki/Hypothyroidism#Central)

**⇒** Central hypothyroidism is when the pituitary gland is not producing sufficient amounts of TSH

- And why is [TSH](https://en.wikipedia.org/wiki/Thyroid-stimulating_hormone) important?
- Because it stimulates the thyroid to function
- Something Antonio has seen in a lot in different patient groups, discussing, “*Oh, my TSH is this, TSH is doing…*”
  - No, TSH doesn’t do anything

> “*None of the symptoms of hypothyroidism can be attributed to changes in TSH, it has to work through the thyroid gland*.”‒ Antonio Bianco

**⇒** TSH stimulates the thyroid, to grow, to function, to secrete thyroid hormones

**Peter’s summary**

TSH is very, very high

- [in people with hypothyroidism]
- A **normal TSH range** in the laboratory is 0.5 to 4 (something like that)

If your TSH is unmeasurable [ very low]

- It means you have too much thyroid hormone (they’re going to talk about what this implies later)
- ***But the actual symptoms you have are from too much thyroid hormone, not from too little TSH***

Conversely, if a patient shows up and their TSH is 75

- Which Antonio and Peter have both seen
- ***The symptoms they feel (which are usually pretty significant) are not because of the high TSH, it’s because the complete lack of thyroid hormone***

**Summary of hormones needed for production of thyroid hormone**

- You have a hypothalamus, you have a pituitary, you have a thyroid
- The hypothalamus secretes *TRH* (thyroid releasing hormone) to the pituitary
- The pituitary secretes *TSH* (thyroid stimulating hormone) to the thyroid gland to secrete T4
- [summarized in the figure below]

![](https://peterattiamd.com/wp-content/uploads/2025/11/f2-antoniobianco-918x1024.png)

**Figure 2. The Hypothalamic Pituitary Thyroid Axis**. Image credit: [*The International Journal of Molecular Sciences* 2023](https://www.mdpi.com/1422-0067/24/12/9815)

**What’s unique about the thyroid is that its levels in circulation (T4 and T3) change very little during the day or during the week, even during the year**

- There’s some minimal fluctuation, maybe 10%, 15%
- Outside of these extreme events like illness or fasting or things like that
- And that is remarkable because if you think about insulin and the pancreas, that changes
  - You can have a 5, 6, 8-fold change of insulin levels after you eat (after you eat, insulin levels go up five, six-fold)
- The same with cortisol

**Tell me what you think of this advice**

*Peter usually tells patients there are 4 big hormone systems: you have the sex hormone system, you have the thyroid system, you have the adrenal system, and then you have the fuel partitioning system (that’s the insulin glucagon system)*

- Absolutely
- That’s how Antonio used to teach endocrine physiology for students

*And of those four, you are saying, outside of extreme scenarios of illness, the thyroid one is probably the most even and consistent?*

- That is correct
- Although, the male sex hormone (the male androgen system) is pretty stable
  - Although, sleep can really impact FSH and LH, and therefore testosterone
  - Testosterone does decline with age

Thyroid hormone doesn’t decline with age

- That’s unique and has puzzled a lot of physicians and scientists
  - Because if this hormone is so important, how come it’s always there?
  - What are the elements that can be regulated?

***If you’re not changing the hormone level, how can you regulate anything with thyroid hormone?***

- Peter thinks that’s a very interesting way to think about it
- You could argue the reverse, you could argue it is so important that you have to stay in this very narrow homeostatic band, like pH
  - If pH is so important, why is it always 7.4?
- But the other hormones don’t work like that
- For a few decades, people would just say, “*Oh, thyroid hormone has a permissive effect*.”
  - That upset a lot of thyroid studying people
- What do you mean permissive effect?
  - The thyroid hormone is super important, if you remove the thyroid, you die

***The whole thing became much more clear when the deiodinases came about, and we started to understand that even though the blood levels are normal, in the tissue (which is controlled a lot by the deiodinases), T3 levels can change 10-fold in a few hours***

- Antonio’s PhD thesis was on brown fat, which is this brown adipose tissue that serves to warm up the body
  - In a bat or any animal that’s waking up from a hibernation, the brown fat is going to produce a lot of heat

Brown fat has a lot of the type II deiodinase (D2)

- If you expose a mouse or a rat to the cold, or a waking animal from the hibernation, rapidly, in a few hours, the T3 levels increase by 10-fold
  - Not in the circulation though, the circulation, the levels are stable
  - If you’re looking at the blood, nothing is happening
  - But in the tissue, T3 went up 10-fold
  - And that’s important for the energy activation that’s happening in that tissue

Peter asks, “*So, the actual thermal signature that you would see when brown fat is activated is largely driven by T3 conversion?*”

- Yes, in the local tissue
- And you would not be able to measure that T3 systemically (absolutely not)
- In Antonio’s thesis work, he put rats in the cold room, and in 24 hours the amount of T3 skyrocketed in the brown fat, and didn’t change in the blood
  - About a 10-fold increase in T3 inside the brown fat
  - It saturated the receptors (you couldn’t have more because it was already fully saturated)
  - It’s really impressive
- Then when we knock out the D2 in the brown fat, then the amount of heat produced was much less
  - Showing that in fact, that surge in T3 localized in the brown fat was really important
- Now, people might think, “*Well, I don’t care about brown fat*.”
- The same thing happens in the brain
  - Most T3 in the brain does not come from the blood, it comes from being produced locally through the type II deiodinase (D2)

***What we learned from the brown fat, we actually took and used for brain studies. Most T3 in our brain is produced by the type II deiodinase (D2).***

**Now, the question that would immediately for Peter come from that is: Is the hypothalamus responding to that T3 as its signal to make TRH, or is it seeing anything in the periphery?**

- Both

*How does it see the periphery?*

- Through the blood that baits the hypothalamus

**⇒** The hypothalamus is outside of the [blood-brain barrier](https://en.wikipedia.org/wiki/Blood%E2%80%93brain_barrier) (at least the [median eminence](https://en.wikipedia.org/wiki/Median_eminence) is, where these neurons are)

- The [PVN (paraventricular nucleus)](https://en.wikipedia.org/wiki/Paraventricular_nucleus), where TRH is produced, it’s outside of the blood-brain barrier
  - So, T3 can get there from the blood, and T4 can get there

Peter wants to make sure people understand this, because not being a neurobiologist, he was assuming that the hypothalamus was entirely within the blood-brain barrier (BBB), and therefore only hormones that could traverse the blood-brain barrier were speaking to it

- The medial basal hypothalamus is outside the blood-brain barrier
  - Which is responsible for endocrine regulation
  - The hypothalamus is a little bigger and Antonio is not sure if the rest of the hypothalamus is outside of the BBB or not
- Peter thinks that makes sense, because presumably that’s how it’s also sensing estradiol, testosterone, and other hormones
  - That’s exactly right

***So the hypothalamus has access to everything it needs to measure (insulin, etc.)***

**Where do we have a lot of D2?**

- In the hypothalamus, and the pituitary gland
- Remember, T4 by itself, cannot trigger the negative feedback because it has to be converted to T3, to trigger the negative feedback
- And who converts it? The type II deiodinase (D2)

***The hypothalamus has a lot of D2, the pituitary gland has a lot of D2, and because they have this, they can sense at all times T3 and T4***

- They integrate both signals (T3 and T4), but T4 needs to be first locally converted to T3
- A of the discoveries we made in the brown fat, we actually used for the understanding T3 economy in the brain, and the hypothalamus and the pituitary gland

Antonio adds, “*There are huge implications for patients with hypothyroidism, and I’ll be happy to talk about it.*”

## Why understanding thyroid physiology is essential for proper diagnosis and treatment of hypothyroidism [A: 33:45, V: 34:12]

> “*For the folks listening now who are wondering, why are you guys going into so much physiology? You have to if you want to understand how to treat this.*”‒ Peter Attia

- Especially with all of the different schools of thought around treating this (to put it kindly)

***We must be able to understand this physiology, to understand what is a genuine therapy, what is voodoo medicine, and what is potentially harmful***

Antonio emphasizes how important this is

- Unfortunately, a lot of people that talk about treatment of hypothyroidism have an incomplete understanding of thyroid physiology
  - Antonio doesn’t mean to criticize any of his colleagues in saying that, but it’s a fact

For example, we talk about T3 so much

- T3 is the biologically active hormone, T3 is the one that…
- But a strong school of thought [erroneously] says, never measure T3, you don’t measure
  - Why would you measure T3? It makes absolutely no sense
- If you think about all we just discussed for this half hour, why would you *not* measure T3?
  - It’s the biologically active hormone

***Antonio attributes this to incomplete understanding of thyroid physiology, that’s it***

- Thyroid physiology is not simple, and Antonio has been studying the thyroid for about 45 years
  - It took him a while to understand
- It took him decades to put together the important dots because he was listening to exactly those lines of thought (don’t mind T3)
- But studies in Antonio’s lab, he looked at T3 (it’s the only thing he looked at), but when he goes to the clinic and talks to a patient, he doesn’t care about T3
- Then patients started asking him, “*Doctor, shouldn’t we measure T3?*”
  - “*Don’t worry about it. No, no, we just measured free T4 and TSH.*”
  - “*But why?*”
  - “*Don’t worry about it.*”

Antonio shares, “*This is so important. And I lived through this, and that’s why I became so focused on helping patients with hypothyroidism. Because I myself thought I did a disservice to them, to many of my patients, because I was just repeating what I learned from the people that, unfortunately, did not take into consideration thyroid physiology.*”

## Testing for thyroid hormones: understanding free vs. total levels, the limitations of current T3 assays, best practices, and more [A: 36:00, V: 37:03]

**When we do a blood test on a patient**

- Let’s say we are measuring 4 things: TSH, free T3, free T4, reverse T3
- There were 2 other things that are typically measured: T3 and T4

*Explain to people the difference between the T3/T4 assay and the free T3/free T4 assay*

- Earlier, when Peter gave his numbers, he didn’t even mention T3, he went straight to the free T3

TSH is not affected by what Antonio is going to explain, T3 and T4 are

- Most T3 and T4 in the circulation (99.5%) are not in the free form, they’re bound to proteins
- There are proteins in the blood that love T3 and T4, so they trap T3 and T4
  - Now, these are large proteins, albumin, there are other proteins, but these are large proteins

Peter asks, “*Is there an equivalent of* [*sex hormone-binding globulin*](https://en.wikipedia.org/wiki/Sex_hormone-binding_globulin)*?*”

- Yes, it’s very similar
- They’re produced in the liver
- The most important is [thyroxine-binding globulin (TBG)](https://en.wikipedia.org/wiki/Thyroxine-binding_globulin)
  - Which binds both T4 and T3
  - They like more T4 than they like T3, but for practical purposes, 99… this is all bound

***Once T3 and T4 are bound to protein, they’re not active ‒ they can’t go into the tissue***

- Because T3 and T4 have to go through the membrane, and if they’re bound, they can’t go
  - It’s like trying to drive a car through a door, you can’t
  - So you have to step out of the car to go through a door ‒ that’s exactly what thyroid hormone does

***There’s a tiny fraction of thyroid hormone that’s free, and that is the fraction that gets into the tissues, that is biologically active***

**There’s a problem with measuring total T3 (or free T3) and total T4 (or freeT4): these proteins [like TBG] can change**

- For example, [estrogen](https://en.wikipedia.org/wiki/Estrogen) affects the levels of [TBG](https://en.wikipedia.org/wiki/Thyroxine-binding_globulin)
- There are a number of conditions that can affect the total amount of T4 that’s bound, but it doesn’t affect the free fraction

***So then from a diagnostic point of view, we like to look at the free fraction because that’s telling you how much actually is getting into the tissues***

The extreme example is during pregnancy

- Because of the high levels of estrogen, TBG goes up, total T4 goes up
- T4 during pregnancy can be a normal 14, 15, even though the upper limit of normal is about 12

***But the free fraction is normal, so we don’t have to worry about it, it’s not a problem***

- Doctors like to ask for TSH,  free T4, and free T3

**We need to talk about measuring T3**

- None of the tests are good because we never cared about T3
  - The assays that we develop for T3 and free T3 are not gold standards
- Free T4 is a gold standard method
- Free T3 and T3 are not, they have a lot of variability
  - The interassay coefficient is high for these measurements

***T3 is a typical hormone that we need to use mass spec to measure***

- There are studies that have shown that using mass spec provides you with a real number for T3 in the circulation
- Now you can measure free T3 or total T3 for mass spec

Peter asks, “*You’re saying when you go to LabCorp, Quest, or all of the reputable labs out there and the doctor checks off T4, free T4, it defaults into a CLIA approved mass spec assay?*”

***No, the T4 is an immunoassay (all of these assays are immunoassays); however the immunoassays for T3 are not good***

- [limitations of immunoassays discussed in this [review](https://pmc.ncbi.nlm.nih.gov/articles/PMC5113291/)]

**⇒** But the immunoassay for T4 is good

- Peter points out, “*When I go to LabCorp… we never check estrogen, testosterone on an immunoassay…(we through that assay in the garbage). We specify* [*LC-MS*](https://en.wikipedia.org/wiki/Liquid_chromatography%E2%80%93mass_spectrometry) *(always).*”

***We need to measure T3 with LC-MS***

- [[labcorp test](https://www.labcorp.com/tests/503600/triiodothyronine-t3-free-dialysis-and-lc-ms-ms-endocrine-sciences) for free T3 with LC/MS-MS]
- Maybe there is a boutique lab somewhere that does that [[ARUP lab](https://ltd.aruplab.com/Tests/Pub/2011793), [Walk-In-Lab](https://www.walkinlab.com/products/view/triiodothyronine-t3-free-blood-test-dialysis-lc-ms), possibly others]
- [[labcorp](https://www.labcorp.com/tests/501902/thyroxine-t4-free-dialysis-mass-spectrometry-endocrine-sciences) also has a MS test for free T4, although Antonio said the immunoassay for T4 is good]

*Peter points out that this is disturbing for the following reason*

- When we run mass spec estradiol and testosterone by immunoassay, the immunoassay numbers are so bad that they serve no clinical use
  - You can’t make a decision based on them, they’re that useless
- So we’re just going to say, “*You know what? It’s worth paying the extra $20.*” [for the LC-MS assay]
- Antonio agrees, and this is the problem with T3
- Again, the free T4 immunoassay is good, we don’t need mass spec for that

*Why is it that the immunoassay works in T4 but not in T3?*

- Antonio wouldn’t know the specificity, what is the problem?
- All these assays depend on how good the antibodies are that bind [to free T3, or whatever the immunoassay detects]
- Peter’s takeaway: we don’t know if it’s technically not possible to develop an immunoassay for T3 or if the one that exists is just poor, but another one could be better
- Maybe there’s a better antibody out there that hasn’t been developed yet
- What Antonio has seen is that the assays have improved over time

***However, the immunoassays are far behind mass spec, especially when you have low levels of T3***

- There’s a [study](https://pmc.ncbi.nlm.nih.gov/articles/PMC4187214/) published in which comparing immunoassay with mass spec for T3
  - [results shown in the figure below, measurements with mass spec are on the right]
  - If you have a lot of T3, they’re sort of comparable
  - But if you’re going around 90-100 ng/dL, that’s where the mass spec becomes really important (there’s a divergence of the curves there)

![](https://peterattiamd.com/wp-content/uploads/2025/11/f3-antoniobianco.png)

**Figure 3. Free T3 measured by immunoassay and mass spec divided into 3 groups according to increasing serum TSH values (dashed lines indicate reference interval)**. Image credit: [*Clinical Biochemistry* 2014](https://pmc.ncbi.nlm.nih.gov/articles/PMC4187214/)

> “*We really need to use, as a routine, clinically a mass spec for T3. It’s really important.*”‒ Antonio Bianco

**Is the same true for the reverse T3 assay?**

- The reverse T3 is even worse than T3
- Antonio actually did a test (never published): we used 4 different sources of reverse T3 assays to measure the same sample, it was completely crazy (just noise)
- One would hope that when you go to the same lab (a repeatable lab), they will always use the same assay so that even though it might not be accurate in terms of the exact value, it’s going to be precise
  - Meaning it’s consistent over time

**Peter’s takeaway**

- We trust the TSH number especially when we’re staying with the same lab, we trust T4 and free T4
- For the T3 and reverse T3, we need to be mindful when we have low levels
  - Which is often when we care the most, in hypothyroidism

## Genetic and sex-based variability in thyroid hormone regulation and their limited clinical significance [A: 43:45, V: 45:40]

- Peter knows that genetics play a significant role in [androgens](https://en.wikipedia.org/wiki/Androgen) on the male side
  - We think maybe it has to do with androgen receptor density and that some people have more androgen receptors and therefore they need and make more testosterone than others, etc.

**How much genetic variability and sort of germline variability is there in thyroid hormone?**

- There’s a little bit
- Many years ago, Antonio would’ve said, “*Not much*.”
- But more recently, folks from the Netherlands have published [studies](https://pubmed.ncbi.nlm.nih.gov/38291025/) showing that there is some genetic importance, influence
- But is this clinically relevant? That is the question

***Antonio doesn’t think that we are changing anything based on genetics***

- He doesn’t think we need to look at your genes to say, “*Well, this TSH is normal or not*.”

Just look at the range in TSH: 0.4 to 4 or 5 is a broad range

- When you’re treating someone, where should I put this TSH?
  - Is a 4 okay or do I have to go to 0.8?
- That’s when genetics could help, but the magnitude of the effect is not that great
- It would be good to know how much my TSH was [in the case that] if I develop hypothyroidism, my previous TSH is where I want to be
  - We could do this with electronic medical records
  - But do we do this? Not so much
  - Maybe in some specific cases this is done

***So the answer is there is genetic influence. However, Antonio is not sure that this is going to be clinically relevant at this point.***

**What are the male-female differences in thyroid hormone levels?**

- There are not great differences between males and females
- The TSH range in women are broader than male
- Males tend to keep a tighter control of the thyroid gland
- You see more variability in terms of the female thyroid function tests
  - But again, is this clinically relevant? Antonio doesn’t believe so.

## Hyperthyroidism: causes, symptoms, diagnosis, and treatment options [A: 46:00, V: 48:23]

**What is the split between hyper-functioning thyroid and hypo-functioning thyroid?**

- It would seem to Peter as a non-endocrinologist, he would see more hypo than hyper, but what’s the division?

**⇒** There are about 20 million patients in this country with hypothyroidism

- The prevalence depends on the age of the population you’re looking at
  - It would be about 4-5% of the adult population

**⇒** The number of people with hyperthyroidism in this country is in the thousands, maybe a few hundred thousands (not millions)

***Hyperthyroidism is a much rarer condition than hypothyroidism***

- Antonio would see 1-2 hyperthyroid patients per month at the same time he would see 40 patients with hypothyroidism
  - Hyperthyroidism is not rare but it’s certainly less common

**What are common causes of hyperthyroidism?**

- You have 2 major causes

1 – Graves’ disease

- [Graves’ disease](https://en.wikipedia.org/wiki/Graves%27_disease) is when the body produces an antibody that binds through the thyroid gland and it binds to the same place where TSH binds
- So the thyroid thinks, “*There’s a lot of TSH, so let me start working*.”

***It’s an antibody that stimulates the thyroid: the thyroid doesn’t know the difference between this antibody and the TSH***

- So the whole thyroid gland grows homogeneously, producing a lot of thyroid hormone (you have a hyper-functioning)
  - It produces a lot and secretes a lot

**⇒** You have high levels of T4 and high levels of T3 in the circulation

- Now all of a sudden, all the tissues are exposed to an excess of thyroid hormone
- They were used to a situation in those hormones that never changed
  - Normally thyroid hormone is super stable and now they have 2 or 3-fold higher levels

*Symptoms*

- You will see patients complaining of **heart palpitation**, that’s the #1 symptom
  - With any exercise, the heart will just pound very heavily
- **Weakness** is also seen in hyperthyroid patients
- **Jittery**, patients are really agitated
  - They might have difficulty sleeping
  - They’re very triggered by anything
  - They’re very responsive
  - The reflexes are very rapid, very fast
- And they **lose weight**: typically a patient that has hyperthyroidism will lose a significant amount of weight

Antonio points out, “*It’s interesting, you frequently make the diagnosis as you shake hands with the patient. You’re going to see that hand that’s warm, very soft and wet because they’re sweating. They’re producing a lot of heat*.”

- Remember, the thyroid hormone stimulates energy expenditure
  - So they’re burning calories
  - You can just take their hand and you see that their uncontrolled hyperthyroidism is going on

*Diagnosis*

- You’re going to draw blood and see that their TSH is basically zero
- It’s suppressed because the brain is saying there’s too much thyroid hormone and let’s turn this off

*Are you going to draw [blood] for the antibody?*

- Yes, you should
- Yes, you will try to measure antibodies to confirm, because it could be another type of hyperthyroidism
- That’s how you’re going to distinguish
- But you’re going to measure free T4 and T3, and you’re going to see both elevated

***Free T4, free T3, and total T3: you’re going to see everything elevated and the antibody positivity***

- It’s called [TRAb](https://my.clevelandclinic.org/health/diagnostics/thyroid-antibodies#:~:text=Thyroid%2Dstimulating%20hormone%20(TSH)%20receptor%20antibodies%20(TRAb)) or there are different forms of antibodies, methods that you can measure; and that closes diagnosis of Grave disease

*Treatment*

- 1 – You’re going to give a drug that inhibits the thyroid gland
- There are basically 2 types of drug
- We try to use one type of drug that **inhibits the enzyme** that puts the iodine into the hormone
  - So there’s no way that gland is going to produce thyroid hormone because it’s inhibiting that step (that’s critical)
  - You’re going to reduce the production of thyroid hormone
- There are other forms of treatment as well
- 2 – There is surgical treatment
  - Patients can be use the drug for a couple of months, bring down the thyroid hormone levels, and then go into **surgery to remove**, either remove the whole thyroid or three-quarters of a thyroid because you’re going to reduce the amount of mass of gland that’s producing thyroid hormone
- 3 – The third form of treatment is radiation
  - You just take a dose of radioactive iodine, and that will just kill the thyroid gland because it concentrates only on the thyroid

**What are the pros and cons of complete surgical removal versus radioactive iodine?**

- That’s very interesting
- In this country, maybe 20 years ago, there was very little discussion about how to treat patients with hyperthyroid
- The #1 treatment was radioactive iodine
  - Patients would come to the office, the diagnosis was made, they would exit, already having received radioactive iodine
- In Europe and other countries, they didn’t have this preference
  - They would go for medical treatment with the drugs, the anti-thyroid medication that inhibits the thyroid
- The problem with the drugs is you have to take them for 1-3 years hoping that the patient will go into remission
  - As you slow down the production, you decrease the level of stress to your body, and the production of antibodies will reduce by itself so that you will go into remission
  - About 30, 40% of the patients going to remission
  - The longer you treat, the higher the percentage of patients

***So you would offer the patient, “I can either burn your thyroid right now, or you can take this drug for the next 2 or 3 years hoping that you’re going to get okay.”***

- People didn’t like **surgery** at all, who wants to have to go under anesthesia if you have these 2 other options?
  - Surgery was always the last preferred route

**⇒** Today, we know that radioactive iodine is not that safe

- There are lots of studies showing that you could have increased cancer, different types of cancer in those patients that take radioactive iodine
  - Antonio thinks it was breast cancer and lung cancer
  - [a [2019 study](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2737319) found increased mortality from breast and stomach cancer]

***There is increased incidence of cancer in patients that take radioactive iodine***

- So people are now moving away from giving radioactive iodine and they are going back to treatment with medicine, with the anti-thyroid drugs and the surgery now

Why surgery?

- Because surgeons are extremely skillful today
- We have surgeons that only do thyroid gland
- The best surgeons can do between 100 and 150 thyroidectomies per year
  - If you go see a surgeon, you don’t want to go to that surgeon that operates 10 patients per year, you want to have at least 100 cases
- Surgery became a very viable option, and this needs to be discussed with the patient
  - What is the best option for that patient considering age, considering a lot of things
  - But those are the 3 options [drugs, radioactive iodine, and surgery]

**When you do the surgical option, is it relatively easy based on the labs to figure out what volume of thyroid to remove?**

*Or do you always take basically three-quarters of the gland?*

- Antonio thinks they always take the same thing; he’s never seen a discussion of this
- The idea is to take enough of the thyroid to cure the patients, but they cannot guarantee that those patients might not need a little thyroid replacement
- Eventually they will because the autoimmune disease that stimulates the thyroid also has a component of destruction of the thyroid

**⇒** 10 years after surgery, you will have a great number of patients that evolve to hypothyroidism

**For people listening who had Graves’ disease 20 years ago and received radioactive iodine, should they be doing additional cancer screening?**

- They should talk to their doctor and ask what they should be doing at this point

**2 – The other form of hyperthyroidism [not Grave’s disease] usually shows up as hot nodules**

- It’s just a growth, a nodule, a lump in the thyroid that will, or maybe either a solitary one or a multi-nodular goiter that will produce autonomously, a large amount of thyroid hormone.

*Is this like a hyperfunctioning adenoma?*

- That’s correct

*Can this be treated surgically?* *Historically, do we medically treat this or use radioactive iodine?*

- The 3 forms of treatment [discussed earlier] can be used
- However, because it’s a growth, these things tend to grow ‒ it will never go in remission

***You can take the anti-thyroid drug, but there’s no chance that this is going to go into remission because it’s not an autoimmune disease***

- You would take the anti-thyroid drug to reduce the levels of thyroid hormone, and most likely that patient should go to surgery (depending on the age, depending on the whole thing of the patient)

*Can they be treated with radioactive iodine?*

- Yes, absolutely they can

Peter asks, “*Do you need a lower dose for this patient because it’s a single hot nodule?*”

- No
- Usually you would use similar dose
- And by the way, the dose is completely empirical
  - There are different formulas to calculate those, but in the end, it’s all between 8-10 millicuries

Antonio recommends, “*My bias is, if you have a nodule, I think that surgery is so good to today that you should strongly consider removing it surgically*.”

## Hypothyroidism: diagnosis and autoimmune causes of hypothyroidism [A: 56:30, V: 1:00:10]

- This is the so-called “bread and butter” of the endocrinologist
- There’s also many etiologies, including some for which there’s no identifiable cause
- Let’s start with the “horses” and go to the “zebras”

**How often is the diagnosis of hypothyroidism made from symptoms where a patient presents to their primary care doctor and says, “*****I feel bad for the following reasons;*****” versus on an annual screening test, something shows up (usually a very elevated TSH) that then warrants further investigation**

*What’s the breakdown between those two scenarios?*

- The answer evolved over time
- It used to be when Antonio started seeing patients decades ago, you would actually make the hypothesis, “*Oh, this patient might have hypothyroidism because of the symptoms.*”
- Today, he cannot tell you the last time he made the diagnosis of hypothyroidism [this way], just because TSH is used as a routine test
  - It’s so good, you pick up everything

Antonio explains, “*Even before it has clinical manifestations of hypothyroidism, you already have a TSH 7, 8, and you start to investigate. So it’s rare to see patients that come with symptoms of hypothyroidism to make the diagnosis. In most cases today we have a finding of elevated TSH.*”

- Now, it is possible that if you go to an underserved population that don’t have a primary care physician, they don’t go for annual checkups, those patients might develop hypothyroidism and present clinically to their patients, to their doctors

The “bread and butter” cause of hypothyroidism is an autoimmune disease

- Antibodies that are produced by the patient’s body against the thyroid
- The patient does not recognize the thyroid as self and wants to destroy it
  - The immune system will target the thyroid gland, will destroy that gland
- That’s called [Hashimoto’s disease](https://en.wikipedia.org/wiki/Hashimoto%27s_thyroiditis) or autoimmune disease of the thyroid gland
- There’s some level of cellular infiltration as well
  - You’re going to find lots of lymphocytes destroying the thyroid as well
- And as a result, the size of the thyroid reduces, it becomes atrophic
  - It can reduce by half or even more than that

***And because the thyroid is destroyed, the production is no longer there and the levels of thyroid hormone in the circulation will reduce***

- It is exactly the opposite of hyperthyroidism and the tissues now will be missing thyroid hormone

The problem with the typical treatment of autoimmune disease causing hypothyroidism

- Antonio compares it to how heart failure is treated
  - When a patient has heart failure, we try to treat the heart
  - We give drugs to make the heart pump more blood, reduce peripheral resistance
  - We want to help that heart to work
- We don’t do that for the thyroid
- We just forget about the thyroid
- We don’t say, “*Oh, let’s give an immune treatment.*”
- It became so easy to think, “*Let’s replace the hormone and let the thyroid die.*”
  - So that the treatment of hyperthyroidism is through replacement therapy
  - We think “*Let’s just give the body the hormone that the thyroid was producing.*”

Peter points out, “*The implication of that… is that the same autoimmune condition that is ravaging the thyroid is doing nothing else anywhere else in the body that is counterproductive.*”

- In other words, to believe that replacing the hormone that is being lost through the immune system’s attack on the thyroid gland, you have to believe that nothing else is being injured

***But that’s not actually correct***

- No, our thinking has evolved

**An example demonstrates that these auto-antibodies are doing something else too**

- A perfectly healthy woman with a healthy thyroid becomes pregnant
- And as a screening, we are going to detect the [TPO antibody](https://en.wikipedia.org/wiki/Antithyroid_autoantibodies#:~:text=anti%2Dthyroid%20peroxidase%20antibodies%20(anti%2DTPO%20antibodies), the one that destroys the thyroid and a finding
- She has positive antibodies (TPO positive), even though her thyroid is normal, but she’s pregnant and she has positive TPO

**⇒** We know that if you have positive TPO and you’re pregnant, your chances of having a miscarriage increase

- [[meta-analysis reports](https://pubmed.ncbi.nlm.nih.gov/21558126/) the odds ratio (OR) for miscarriage and preterm birth in women with thyroid peroxidase antibodies and miscarriage (OR, 3.90 and 95% confidence interval [CI], 2.48 to 6.12; P<0.001) and preterm birth (OR, 2.07; 95% CI, 1.17 to 3.68; P=0.01)]
- This risk is present even without rising TSH, without hypothyroidism

***So that in itself is a demonstration that either the TPO is doing something on its own or its presence is associated with something else that we don’t know***

- It happens that autoimmune diseases, they might come together with other autoimmune disease

Peter responds, “*In that situation, when you stated it that way, it seems far more likely that it’s the second of those two scenarios. The very same immune system that is now attacking the thyroid (which we can detect through the TPO), is also attacking the fetus.*”

- Because the fetus is foreign (or the placenta or whatever)

**⇒** We also know that 30% of patients who are TPO positive have positive antibodies against brain tissue or different parts of the body

Peter asks, “*Because obviously I know nothing about obstetrics, is this something where now any woman in her first trimester is getting a TPO screen? If it’s coming back positive, she’s being shuttled to a high-risk obstetrician?*”

- They should
- Antonio doesn’t know that they’re doing it, but he certainly would recommend that

**The other angle is just to address the question you made about not being a thyroid-specific disease**

- Once you have one autoimmune disease, you might have others
- So infertility might be related with positive TPO antibody
- Antonio says this from an anecdotal point of view
  - He used to see patients that once they become pregnant, they come see him for a thyroid follow up because they had a thyroid issue
  - So what was your thyroid issue?
  - Well, I had difficulty getting pregnant; my TPO antibody was positive, was high
  - I did not have hypothyroidism, but my infertility doctor thought the TPO antibody could be affecting
  - So I went through a course of [prednisolone](https://en.wikipedia.org/wiki/Prednisolone) to reduce the levels of TPO, and then I became pregnant, and now I’m here
- The first time Antonio heard that story, he had a hard time believing
  - He looked at the data and in fact, she had TPO-positive antibodies before, and after she took the steroids, it decreased dramatically and she became pregnant
  - He doesn’t have a 100 [-person] randomized control [trial], but he saw a lot of patients in that scenario
  - He doesn’t know if that’s just coincidence, but he has asked that question to a lot of infertility doctors, and they tell him it’s a standard

Peter adds, “*I think physicians such as yourself who live in the laboratory as well have a real luxury, which is, you get to interact with patients who are basically giving you hypotheses.*”

- Antonio agrees
- Peter thinks about his mentor who he trained with, and it was the same way for him
  - He’s an oncologist, but it was really what he saw taking care of patients that gave him his greatest ideas for what to go and do in the lab
  - You have to have that insane curiosity
  - It took Antonio 20 years to get there

## More on hypothyroidism: diagnostic biomarkers, antibody patterns, and non-autoimmune presentations [A: 1:05:00, V: 1:09:34]

**How Antonio became interested in hypothyroidism**

- He had a patient who told him, “*I’m a teacher. I lost my job because I became hypothyroid.*”
  - Her TSH was normal, free T4 was normal
  - She said, “*I cannot teach anymore. I had brain fog. I became unfocused. I don’t have that energy. I quit.*”
  - Antonio said what he told all his patients that presented with that scenario, “*You may need to do therapy, psychotherapy.*”
  - She started crying and goes home unhappy
- 2 weeks later, he saw another teacher that came and told him, “*I lost my job because I became hypothyroid.*”
- He thought this cannot be a coincidence
- They both had high functioning jobs taking care of kids, high school teachers, math teachers, and the hypothyroidism made it not possible for them to continue with their jobs

***He went to his lab and he changed what he was doing (he refocused his research)***

- Peter thinks that’s amazing and Antonio can’t be faulted for saying there could be many reasons why they’re having a hard time focusing when they have normal TSH, free T3, free T4 (all their biometric stuff is normal)

**What gave you the confidence to drop what you were doing and go and pursue that? (that’s a bold step)**

- They were both triggered by hypothyroidism
- They were functioning perfectly normal before they had hypothyroidism
- One of them had surgery; she said, “*The day I had surgery, I left the hospital taking levothyroxine. I could not, my brain did not work.*”
  - There was a fundamental change
- They were otherwise healthy, middle-aged women
- For Antonio, it was what Peter described with his mentor, exactly the same thing happened
  - He refocused his research carefully because he knew he was going into a controversial area, trying to understand what was happening with those patients

**Going back to hypothyroidism, just from a semantic perspective, autoimmune thyroiditis involves anything that is hyperthyroid or can that be hypo as well?**

- Hashimoto’s is an autoimmune disease and the prototypical hypothyroidism

*Are there non-Hashimoto’s autoimmune conditions that decrease thyroid as well?*

- Yes. We don’t have a name for them
- We don’t know exactly how this happens (there are all sorts of ways)
- For example, [subacute thyroiditis](https://en.wikipedia.org/wiki/Subacute_thyroiditis): patients develop huge inflammation of the thyroid, very painful
  - When you feel the thyroid gland and you try to make the diagnosis, you’re moving toward the patient, and the patient is moving far away from you because the neck is so painful
  - You don’t have to touch them because you already know
  - Clearly there is some autoimmunity going on or inflammation of the thyroid, and that destroys the thyroid very rapidly in most cases

***There are multiple forms, but the only one we have a name for is Hashimoto’s because it is identified by the TPO antibody ‒ there are other forms of antibodies***

**What are the other antibodies that we typically look at here besides TPO?**

- TPO is the most important one
- There’s another one that’s [antithyroglobulin](https://en.wikipedia.org/wiki/Thyroglobulin#Thyroglobulin_antibodies)
  - Which is also specific for [thyroglobulin](https://en.wikipedia.org/wiki/Thyroglobulin) (a protein that’s only produced in the thyroid)
  - Also anti-TPO antibodies are against the peroxidase that’s only produced in the thyroid
  - So these two antibodies are very specific; the antithyroglobulin is less important
  - Antithyroglobulin can be increased in Graves disease, for example

**When a patient has Hashimoto’s disease, is it important in conventional thinking to do anything about the autoimmunity or is it still the standard of care to just go after the thyroid replacement?**

*And what are the typical thyroid and thyroid related biomarkers when a patient presents with Hashimoto’s? In other words, are they likely to also have an elevated TSH, or do they often just present with the TPO and normal thyroid labs?*

- For the first question, we don’t normally focus on how to treat the autoimmunity

**⇒** However, there are several studies showing that patients taking selenium, vitamin D, or other antioxidants can reduce the levels of TPO, can actually prolong the honeymoon period, which is the amount of time that the thyroid will keep producing thyroid hormone even though it’s being destroyed

- Why do we think that happens?
- Because to put the iodine into the hormone, the thyroid catalyzes a very strong reaction, which is a peroxidation
  - So the iodine has to be oxidized in order to bind to the hormone
  - That’s so powerful that the thyroid does it outside of itself, it doesn’t do it inside the thyroid
  - It does in the lumen of the follicle because Antonio believes it could damage the thyroid

***Making thyroid hormone, it’s actually stressful and could be damaging to the thyroid***

Antonio explains, “*When you give someone an antioxidant, you’re actually slowing down that process or the free radicals that are produced as a byproduct of this reaction and you tone down, you may decrease the autoimmunity process. The antigenicity of the thyroid will decrease.*”

- We normally don’t do that from a clinical point of view
  - Some doctors do that, but this is not standard of care
- We would just go ahead and start replacement therapy

Now the second question about the biomarkers

- The only biomarker we use is TSH
- We also use free T4 levels, and that is it for the diagnosis

***We make the diagnosis measuring TSH and free T4 levels***

*How high does the TSH need to be for the diagnosis*

**⇒** A typical patient with hypothyroidism will have a TSH >10 with a reduced level of free T4

- This dyad is mandatory for the diagnosis of hypothyroidism or primary hypothyroidism

Peter asks, “*So a patient with a positive TPO and a TSH of 4 doesn’t meet criteria, and therefore we would say they’re in the honeymoon phase.*”

- That is correct
- Peter continues, “*And they’re probably going to see a rising TSH that we don’t treat*.”
- That’s why you need to measure: if the  free T4 is normal, it means the thyroid is still producing

**⇒** Remember, if you want to know if the thyroid working, measure free T4

***What does the thyroid do? Makes T4. So that makes perfect sense to focus on the free T4, because it’s a perfect marker of the thyroid function*****.**

- If the free T4 starts to come down, it means the thyroid is not working very well
- A normal free T4 with a TSH of 4, it’s okay even if the TPO is positive

> “*Now, every patient is different, and that’s why I’m sure AI is not going to replace us because we need to talk to the patient*.”‒ Antonio Bianco

- The doctor needs to have that relationship and say, “*How are you feeling? Is there hypothyroidism in your family? Let’s do a thyroid ultrasound*.”
  - Because usually when there’s thyroid destruction, you can see that through the thyroid ultrasound

**A number of factors may weigh into the decision whether or not to start treating**

- If a patient says, “*My whole family has hypothyroidism. My mother and my aunts, and my sister has hypothyroidism. Now I’m the youngest, and my TSH is rising, my TPO is positive,*” it’s pretty obvious that this patient will go into hypothyroidism
- Antonio will just say, “*Can we repeat this TSH in about 3 months, and then we’ll make a decision then*,” because that will give him assurance that the TSH remains high (it could even go higher) and he doesn’t let the patient suffer (who is minimally symptomatic at this point)

**How often do you see a very high TSH with a normal set of antibodies?**

- It’s not rare; it’s quite common

**⇒** Remember 60% of patients with hypothyroidism have positive TPO antibodies; you still have 40% of patients that don’t have positive TPO antibodies

Peter asks, “*What’s going on in those other cases?*”

- First it could be surgical removal of the thyroid, destruction of the thyroid with radioactive iodine
- It could be congenital hypothyroidism: the patient was born with a defect in the thyroid, that they can’t produce thyroid hormone
  - It’s not uncommon: 1 in every 2,500 or 3,000 live births will have congenital hypothyroidism
- And you do have other forms of autoimmune thyroid disease for which we just don’t know

**When you talk about an adult that’s been normal most of their life, but then sometime during adulthood, doesn’t have surgery, obviously doesn’t have congenital hypoplasia, but during adulthood starts to see a dramatically rising TSH without antibodies, are we now in the case of 10% of cases?**

- Maybe 20%
- It’s a significant minority of cases but not rare

## Thyroid hormone replacement therapy [A: 1:15:15, V: 1:20:58]

**Are there any clinical trials that are going on examining the use of steroids to try to eradicate what’s happening in Hashimoto’s as a first and foremost attempt, even during that honeymoon phase before the thyroid gets destroyed, or is that not being looked at and it’s still primarily accepted that we’re just going to replace the thyroid hormone?**

- Antonio has never heard of this being tried

**There are 2 FDA-approved therapies for exogenous replacement of the thyroid hormone**

*There is an FDA-approved molecule for T4 and an FDA-approved molecule for T3*

- Correct
- The branded name for the T4 is [Synthroid](https://en.wikipedia.org/wiki/Levothyroxine#Available_forms) (there are many brands)
- The point is, there are many formulations that are T4 and many formulations that are T3

*Is it safe to say that today physicians that would stick with only FDA-approved treatments would favor T4 monotherapy and that T3 has somewhat fallen out of favor?*

**⇒** T3 was never considered as standard of care for treatment of hypothyroidism; T4 is the standard of care

- [Levothyroxine](https://en.wikipedia.org/wiki/Levothyroxine#) is the standard of care
- T3 has been approved, first because it was discovered in 1952, someone patented it, and they didn’t know exactly when they treat it
  - They worked with the FDA and got approval
- T3 used to be used in patients that had thyroid cancer, and we didn’t have exogenous TSH to stimulate the thyroid gland
  - So we would draw [levothyroxine](https://en.wikipedia.org/wiki/Levothyroxine#)
  - And during a couple of weeks, we would put patients on [liothyronine](https://en.wikipedia.org/wiki/Liothyronine) (or T3) just as part of the diagnostic to hypothyroidism; you would look for cancer spread through the body

***As treatment of hypothyroidism only, there are no guidelines that recommend use of liothyronine or T3 as a standalone therapy***

- Although Antonio has seen significant number of patients that have convinced their doctors that they can only take T3 as a treatment for hypothyroidism
- Maybe he has seen in a number of years 10-20 patients, that they come and they said, “*This is what I take. I take T3. My body doesn’t take T4, doesn’t accept T4, and this is how I feel. Please help me maintain this.*”
  - So these patients exist

***We don’t know why they feel like that, but it’s extremely rare that someone will be treated with T3 monotherapy. It’s certainly not recommended to do that.***

**Part of the challenge with T3 monotherapy is that T3 has a short half-life and therefore when you take it, it really shows up**

- You get a real burst of energy and all of the both positive and negative side effects of T3
- And then, of course, you’re chasing it and you have to figure out how to give it at regular-enough doses
  - But then, of course, you can’t be giving it too late in the day because then it will impact sleep
- Whereas to Antiono’s point, **T4 has a very long half-life**, so it’s actually a very easy drug to take once a day
  - And frankly, even if you skip a day, it doesn’t really tend to matter that much
  - If you skip a day, you take 2 the next day, or you can even take 3 if you skip 2 days
  - So it’s a very convenient drug from that point of view

**Outside of the purview of the FDA, there are several other options that are quite popular. One of them is something called desiccated thyroid. Can you explain what that is?**

- Desiccated thyroid extract is a powder of pig’s thyroid
- It was the second treatment that was developed for hypothyroidism
- The first was a transplant in 1890
  - A surgeon transplanted a pig’s thyroid into a woman with hypothyroidism, and it worked for a few months
- Doctors around that time had the idea of, well, if the transplant worked, maybe we don’t have to transplant ‒ just dry it up, make a powder, and you start taking it
- And so it has been used since maybe 1900, for 125 years

Peter asks “*It must be FDA-approved because people do take it, right?*”

- Yes, but Antonio doesn’t understand because it’s under the control of the FDA but it’s not approved for the treatment of hypothyroidism
  - The issue is that this drug existed before the FDA existed
  - It was grandfathered in, but it doesn’t have an FDA indication (which today could not occur)
- It’s controlled because if you look at the FDA website, there are plenty of recalls for levothyroxine, for desiccated thyroid extract
  - So there is control over it

***The difference between the desiccated thyroid extract and levothyroxine, or T4, is that desiccated thyroid extract contains T4 and T3***

**⇒** When you just take levothyroxine, you only take the prohormone, hoping that the body will activate proper amounts of T4 into T3

**For reasons that aren’t entirely clear to Peter, this has become an example of something that is highly emotional and religious ‒ there are people on both sides of this debate**

- There are people that would say, “*Desiccated thyroid hormone replacement has no place in the treatment of humans with hypothyroidism.*”
- At the other end of that spectrum, there are people who say you give desiccated thyroid for all of these amazing reasons: you’re giving T4 and T3 simultaneously, the T3 is sort of time-released, therefore, the patients can tolerate it in a way that they can’t with just straight T3
  - They say doing anything but this is inhumane

*Can you steel-man both positions for me? Help make the case for why one should not use this, and make the case for why this is a good thing to use, independent of your case.*

The case for [desiccated thyroid](https://en.wikipedia.org/wiki/Desiccated_thyroid_extract)

- The normal thyroid makes T4 and T3, makes 80% of T4 and 20% of T3
- So if I want to replace what the thyroid does, it’s logical to assume that I just want to deliver 80% of T4 and 20% of T3
  - It makes perfect sense to think that this would be the way to replace what the thyroid is doing
- Now, the challenge is that T3 has a short half-life
  - This is not a problem when it’s being secreted from the thyroid because it’s secreting small amounts of T3 throughout the day
- If you take a tablet of desiccated thyroid extract, you can’t do that
  - It’s one shot, you take all T3 that you need for that day, and obviously that’s going to cause a spike in the circulation
  - So that is the challenge number one
- Doctors have claimed that that spike of T3 could be dangerous
  - So safety was a concern
  - Danger such as [tachycardia](https://en.wikipedia.org/wiki/Tachycardia)
  - Because you’re going through a period, according to the doctors, of hyperthyroidism (your T3 is very high)
  - You may be damaging your heart, your brain, your bones
- This is a completely unfounded concern
  - There’s no evidence that that’s the case, but that was the case that was presented
- Desiccated thyroid was made using a very old manufacturing process, and different manufacturers had different standards
  - So you would buy from one, it would have a certain potency
  - From another one, a different pig, a different way of preparing it
  - And even the same manufacturer could not preserve the stability of the potency
- Up until 1985, we did not have a good method of measuring the potency of this
- In 1985, the [USP (United States Pharmacopeia)](https://en.wikipedia.org/wiki/United_States_Pharmacopeia), established a mass-pack method for measuring T3 and T4 into the desiccated thyroid extract tablet, and that’s so we know how much we can calibrate the potency
- And that sort of appeased the FDA a little bit because we know how much is being given
- There’s stated the ratio [of T4 to T3] of 4 to 1 (± 10%) ‒ that’s what the specification says
- The potency was put aside; the guidelines were concerned with safety
- Today there are several studies showing that the safety is identical to levothyroxine
  - There’s not a single study showing, oh, desiccated thyroid extract causes this
  - No, they’re identical

The other point is that patients prefer combination therapy

- There are not a lot of studies of preference with desiccated thyroid extract
- There are preference studies with synthetic combinations of T4 and T3, which could be assumed to be the same, but patients do tend to prefer 2:1 when they don’t know what they’re taking
  - In blinded studies, they prefer combination therapy
- There are 2 studies showing that they prefer desiccated thyroid extract as opposed to levothyroxine alone
  - [[2013 double-blind crossover study](https://pubmed.ncbi.nlm.nih.gov/23539727/) comparing desiccated thyroid extract and levothyroxine (LT4) and a [2021 double-blind crossover study](https://pmc.ncbi.nlm.nih.gov/articles/PMC8530721/) comparing 3 treatment arms: 3 treatment arms, LT4, LT4 + LT3, and dessicated thyroid extract]

***So you have a product that its potency has been standardized and the effectiveness is similar, it’s safe, and the preference is for the combination therapy***

Let’s talk about [levothyroxine](https://en.wikipedia.org/wiki/Levothyroxine)

- The rationale is that you give the prohormone and let the deiodinases do their job, and that works for 80-90% of the patients
- It’s a single tablet
- The potency is not questionable: it’s always the same amount that you’re taking of micrograms
  - It’s synthesized
- You move on with your life: the major symptoms of hypothyroidism have been resolved, and all you have to do is to make sure the TSH is within the normal range

***From a practical point of view, the levothyroxine is the perfect treatment for hypothyroidism; and the reality is patients do feel well***

Peter notices, “*And the key, of course, is what you said at the outset, provided the deodinases are able to do their job. Because of course, we could never replicate what the body does when the body’s working perfectly.*”

The interesting question is (and Antonio wonders why the FDA never asked that question)

- The FDA approved levothyroxine without a trial, without clinical trials
- In a sense, levothyroxine has also been a grandfathered-in drug
  - It was crystalized in 1914 by [Ted Kendall](https://en.wikipedia.org/wiki/Edward_Calvin_Kendall) at the Mayo Clinic
- It normalizes TSH
- But clinical efficacy ‒ we never studied heart outcomes (mortality)
  - Compare a control population with people who have hypothyroidism treated with levothyroxine

**⇒** Mortality is 2.5 greater in the patients taking levothyroxine with hypothyroidism (we know that retrospectively)

- Peter finds this to be a really interesting and provocative observation

## More on thyroid replacement strategies: exploring the evidence gaps, mortality signals, effects on lipids, and more [A: 1:28:00, V: 1:35:35]

**It raises a question: is this 2.5-fold increase in mortality because of Synthroid [one brand of levothyroxine]?**

*Does it have some off-target effect?*

- Peter presumes it drives up sympathetic tone that leads to more adverse cardiac outcomes or something of that nature
- Or is it that if you have hypothyroidism, you are very likely to have something else that is driving up your mortality?
- And by the way, if left untreated, i.e. if you were not taking the thyroid replacement, the mortality difference could be 5x

*The causality is everything in this question*

- For sure there are other comorbidities to the hypothyroidism that are contributing to the increased mortality, other autoimmune diseases that we are not diagnosing and patients have (absolutely)

***Antonio doesn’t think levothyroxine is doing anything bad; he thinks that it’s restoring euthyroidism in an incomplete fashion***

Because what are these patients dying of?

- They die of cardiometabolic diseases
  - [Antonio has a currently under review that shows this; other [studies](https://pmc.ncbi.nlm.nih.gov/articles/PMC12527464/) report increased complications and risk of death in patients with hypothyroidism]
- They have **increased cholesterol**, so the number one co-medication that is prescribed with levothyroxine is a [statin](https://en.wikipedia.org/wiki/Statin)
  - As you know, cholesterol goes up in patients with hypothyroidism
  - But does it go back to normal after the TSH has been normalized? Answer, no
  - We have to give statin to ensure that the cholesterol remains [controlled]
  - So that tells you that the liver… Again, there isn’t proof of that because you cannot do a biopsy
  - In a rat, yes, ***the liver remains hypothyroid*** (in a rat with normal TSH treated with levothyroxine)

**Peter restates this important point**

- We didn’t discuss this earlier; we sort of took it for granted, but it’s worth pointing out

**⇒** In the hypothyroid state, the liver cannot clear LDL effectively

- So even though this isn’t on the top-5 list of things that doctors worry about or patients worry about, when you are hypothyroid, you are going to have an elevated LDL-cholesterol and apoB above what your baseline should be because of the lack of T3 and LDL receptor function
- What Antonio is saying, which Peter did not know, and that’s why he wants to restate it:

***Just because you fix TSH and T3 and free T3 in the periphery, which is what you’re measuring, you may not have fixed it in the liver, and therefore you may still have ineffective LDL clearance***

Antonio adds, “*Yes, but we don’t fix T3 or free T3… What we do is we fix TSH, we fix free T4, we think we fix T3, but we don’t know that for a fact.*”

- Stains are the #1 co-medication given with levothyroxine
- Patients with hypothyroidism, their cholesterol is slightly elevated
  - That patient has an issue and the metabolism has not returned to normal

***Antonio is positive that part of the mortality comes from the fact that we are not restoring systemic euthyroidism as much as we think we do based on TSH***

- To confirm this, Antonio just published a study comparing 1.1 million patients with hypothyroidism being replaced with 1.1 million patients that went for a checkup with a healthy thyroid
  - They were followed retrospectively but longitudinally for 20 years.
  - He did the same thing with about 90,000 patients taking levothyroxine and 90,000 patients taking combination therapy, T4 and T3
  - 50% of those taking combination therapy were taking dessicated thyroid extract and 50% were taking T3, T4

**⇒** There was a [30% reduction in mortality](https://pubmed.ncbi.nlm.nih.gov/40579157/) in those individuals taking combination therapy relative to levothyroxine

- Individuals on combination therapy still had elevated mortality
- That tells us about the comorbidities

> “*But it also confirms the fact that when you give a little bit of T3, you’re doing something good for your patient.*”‒ Antonio Bianco

**Peter plays devil’s advocate: with only a 30% relative risk reduction, there could be another confounder in there**

- He thinks it could be that the patients who seek out dual therapy are more health-conscious, and maybe they have more creative physicians who are providing better care in other dimensions and less rigidity
- And it could be that all of those things are what’s driving the 30% reduction, and not the addition of T3
- Antonio agrees and has thought about this

To address that, what we did was we looked at the year prior to the diagnosis of hypothyroidism, how many times they were admitted in the hospital

- And the number of times they were admitted in the hospital was similar
- There was no difference between the 2 populations, meaning that the patients taking one or the other were not sicker
- Then at baseline, we did propensity score matching with control for everything: for comorbidities, for BMI, for sex, for age
  - We did not control for the type of mindset of the physician (we don’t know that), there could be that fact as well

Antonio explains, “*As much as we could, we control from one year prior to the diagnosis of hypothyroidism and we could not find differences. So the two populations at the onset, they were very similar*.”

- Peter thinks this is a big enough difference that it’s actually a little shocking that the FDA doesn’t want to see this clinical trial run prospectively
  - Because with high enough numbers, you could get an answer within 4 or 5 years (you don’t need a decade to do this)
- Antonio agrees, and wouldn’t you say, “*Oh my goodness, these patients are dying. Why are they dying?*”
- We are approving a treatment for hypothyroidism that, in fact, it’s good
- They don’t die 100%, but they still have died
- And if you look at other diseases, they have dementia more frequently

> “*Hypothyroidism is not that naive disease that we thought it was. It’s a deadly disease. It can affect significantly the quality of life of patients.*”‒ Antonio Bianco

***Doctors should be thinking, “Oh, wait a minute. You have hypothyroidism. I’m taking care of you for your ‘x-disease,’ but you have hypothyroidism, so I need to pay extra attention to you because this is a more serious… It’s a complicating factor that you might have to your disease.”***

## Hypothyroidism basics: causes, antibody implications (including pregnancy), and how to make the diagnosis before choosing therapy [A: 1:35:15, V: 1:43:25]

- The other side of this pendulum is another school of thought in this idea of what sometimes gets referred to as “functional medicine”
  - It’s a term Peter doesn’t actually understand because he doesn’t know what the alternative is (which might be dysfunctional medicine)
- But in the school of functional medicine, it does seem that when Peter talks to individuals of this stripe, very often everybody has hypothyroidism
  - He’s being a little facetious, but not really

**Help me understand that point of view, which is one could listen to what you’re saying and say, “*****Wow, you’ve really made the case for how we can’t miss this diagnosis. We should just make sure that every single person doesn’t have hypothyroidism, even if they’re biochemically normal, and even if their symptoms are kind of vague and could belong to something else.*****”**

*How do we make sense of the other side of this?*

Now we’re talking about diagnosis

***It’s very important because what’s true for diagnosis, it’s not true for treatment when we assess the thyroid function***

**⇒** When you are assessing the thyroid function during diagnosis, normally we measure TSH and free T4

- Again, TSH is extremely sensitive
- Free T4 is sensitive

**⇒** T3: there’s no role in the diagnosis of hypothyroidism

- Because Antonio can guarantee that T3 is going to be normal,
  - Unless the patient does not have a thyroid or is an overt case of hypothyroidism
  - In a TSH 10, T3 is going to be normal
  - Because the system evolved to defend itself against iodine deficiency, so when the system is challenged, it does everything possible to maintain T3 normal: elevates TSH, free T4 comes down
- In the beginning of hypothyroidism, T3 is normal
- The same thing that happens when we deprive someone of iodine: in the beginning TSH starts to go up, T4 goes down, T3 is normal

***T3 has no role in diagnosis of hypothyroidism ‒ free T4 and TSH do***

- Patients will come with a normal free T4, a normal TSH, and say, “*I’m a hypothyroid because I feel tired. I looked it up. I have all the symptoms of hypothyroidism. My body temperature is low. I gain weight. My hair is falling. I’m very tired. My periods are altered. I don’t have energy to do anything. These are all symptoms of hypothyroidism*.”
- And then you say, “*Well, but your thyroid function, I’m looking here, it’s perfectly normal*.”
- [They will reply,] “*I have secondary hypothyroidism. My TSH doesn’t go up*.”

[Secondary hypothyroidism](https://www.ncbi.nlm.nih.gov/books/NBK519536/) is when the pituitary gland cannot produce or the hypothalamus, or the TSH is not working

- It’s a real clinical entity, the secondary hypothyroidism but very rare
  - Less than 1% of the cases of hypothyroidism are secondary hypothyroidism

***The important thing is the free T4 in these patients must be below normal, because otherwise you don’t have hypothyroidism***

- To have secondary hypothyroidism, you need to have hypothyroidism
  - The hallmark of hypothyroidism is a free T4 that’s below normal with a TSH that doesn’t go up
- If you have a low T4 or low free T4 and a normal TSH, okay, forget about TSH
  - Probably you do have secondary hypothyroidism, and Antonio would want to do some imaging studies of your pituitary gland or hypothalamus to make sure everything is okay, you don’t have a tumor or anything like that
  - But you do have to have a free T4 that’s below normal

Peter asks for clarification, “*The one distinguishing feature for secondary hypothyroidism, they’re going to have a normal TSH, they’re going to have normal antibodies, they’re going to have symptoms, but they need to have low free T4.*”

- That’s correct
- Because otherwise your thyroid is working well
  - If you have a normal free T4, you have a normal thyroid, from a functional point of view

How about the symptoms?

- Unfortunately, all symptoms of hypothyroid are not pathognomonic, meaning they’re not specific for hypothyroid
- They can be caused by anything, by other diseases, by comorbidities
  - Anemia, iron deficiency, obesity
  - [Menopausal syndrome](https://en.wikipedia.org/wiki/Menopause#Signs_and_symptoms) is the number one confounding factor

Antonio explains, “*You cannot distinguish menopausal symptoms from hypothyroidism, so much that my clinic always asks for* [*TSH*](https://en.wikipedia.org/wiki/Thyroid-stimulating_hormone) *and* [*FSH*](https://en.wikipedia.org/wiki/Follicle-stimulating_hormone) *for these kinds of patients because I want to know, how is the ovary working? Because the symptoms are not distinguishable.*”

- Many patients **measure the temperature** (it’s very popular)
  - The functional medicine doctors will recommend measuring temperature in the morning
  - It is true that patients with hypothyroidism have lower temperature
  - What’s not true is if you have a slightly lower temp, it doesn’t mean you have hypothyroidism

> “*All these clinical indicators (much to the frustration of many patients) are really not relevant when they compare with TSH and free T4*.”‒ Antonio Bianco

- You really need to rely on TSH and free T4 [to diagnose hypothyroidism]
- Because studies that rely on those symptoms just show that you cannot distinguish
  - They have done [double-blinded studies](https://pmc.ncbi.nlm.nih.gov/articles/PMC58535/) just based on symptoms; you cannot tell who has hypothyroid and who doesn’t

Peter responds, “*Let’s unpack all of that because there’s a lot there.*”

**The temperature issue**

- There was even a day when Peter was trying to wrap his arms around this when he was having patients check their temperature in the morning

*You’re saying that it’s true if you have hypothyroidism, you will very likely have a depressed morning temperature?*

- Absolutely, you will
- But the causality runs in one direction: it’s not bi-directional
  - Just because you have a low body temperature doesn’t mean you have low thyroid function

**You talked about a lot of confounding factors that can present symptoms that look very similar to hypothyroidism**

- Peter thinks the most important point here is in blinded analyses of symptom treatment, the association with symptoms by itself is insufficient
  - Antonio agrees
  - And it’s for that reason that we have to rely on biochemical testing [of TSH and free T4]
- Peter points out that this is quite different from how we fine-tune treatment in hormone therapy, in androgen therapy, where you sort of have to have symptoms to justify it
  - And you can have actually kind of low levels of testosterone, but if you have no complaints, we wouldn’t treat
  - And oftentimes if a person has even medium levels of hormones but complains of symptoms, and you replace [testosterone] and they feel better, you feel like you’re doing the good thing.
  - Part of it has to do with the variability of androgen receptor density and things like that

***For hypothyroidism, a low free T4 along with the TSH, is a big part of the anchoring on this diagnosis with or without antibodies***

- That is correct; the antibodies are not diagnostic
- The antibodies will tell you there is probably an autoimmune process happening

## Thyroid medication: compounded controlled-release T3, brand name versus generic, and what Antonio prescribes to newly diagnosed hypothyroid patients [A: 1:42:45, V: 1:52:11]

- The one therapeutic option we still have not addressed is the compounding of [control-release T3](https://pmc.ncbi.nlm.nih.gov/articles/PMC6700330/)
- You’re opening another can of worms here when we get into compounding because you have **compounding pharmacies** that are very reputable and do very good work and have FDA certificates for everything they put in, and then you have compounding pharmacies that you wouldn’t let make medications for your pets if you saw how unregulated they were and they’re the absolute scum of the earth
- So let’s only discuss this through the lens of good compounding pharmacies, which we’ve done a whole podcast [[AMA #52](https://peterattiamd.com/ama52/#:~:text=that.%E2%80%9D%20%E2%80%94Peter%20Attia-,What%20is%20a%20compounding%20pharmacy%3F%20%5B1%3A09%3A30%5D,-What%20is%20a) after 1:09:30] on this topic that will help you know if you’re dealing with a reputable compounding pharmacy or not

**If you’re dealing with a reputable compounding pharmacy, what is your view of the control-release T3, which is often given as an adjunct to people taking T4?**

- There’s no scientific basis for the control-release

**⇒** There’s not a single paper in which a compounded product that was made in a pharmacy exhibited slow-release profile

*You’re telling me no one’s ever run the pharmacokinetics of the control-release product?*

- There’s one study in which a company claimed they had a slow-release
  - Someone did the study, and it was proven to be identical to the T3 (normal T3)
  - The study showed that it was not a slow-release
  - So we don’t have a publication that says, “*This is the slow-release T3. Oh, it works perfectly.*” No, it doesn’t exist.
- Peter finds this mind-boggling, given how simple this is to test
  - We have pharmacokinetics on many medications that are delivered via slow-release formulations (it’s easy to do)

Peter adds, “*This could be the power of suggestion, I’ve seen many patients who can’t tolerate more than 5 micrograms of* [*Cytomel*](https://en.wikipedia.org/wiki/Liothyronine) *(which is the immediate-release T3), but they can easily take 15 micrograms of a control-release T3.*”

- Antonio points out that to measure T3 to put in those tablets (even by reputable pharmacies) is very difficult
  - We’re talking about measuring 5 micrograms
  - They can’t measure that, they have to dilute it
  - They mix T3 with pellets of glycerol, put in a vibrator, and that thing vibrates overnight
  - You assume that it’s a homogeneous mixture, and then you put on the tablet
  - You weight the mixture of glycerol plus T3
  - 5 micrograms is a very small amount
- Antonio explains how he prepares T3 in the lab: he prepares a stock solution and makes dilutions

Antonio doesn’t recommend using a compounding pharmacies

- If there’s all this controversy about desiccated thyroid extract that is under constant surveillance by the FDA
- Can you imagine in a compounding pharmacy: because the tablet is dry, it has to be a mixture with glycerol
- Where is the publication that shows, “*I’m using this pharmacy, and the amount of the T3 over the months, this lot has the same as the other one?*” (he hasn’t seen those data)

**You would basically say your preferred way to treat hypothyroidism would be just start with T4**

- Yes

**Peter’s takeaway on how to treat hypothyroidism**

- In 80% of cases (making that number up) where the deiodinases are are perfectly functioning in the periphery centrally
  - It’s important that they are centrally functioning because that’s how you’re going to regulate TSH and get the right feedback loop
  - If all the deiodinases are firing on all cylinders, and I give you T4, that should be the only thing I’m titrating up and down
- Now, for the 20% of patients (again making that number up, but hopefully it’s the minority of patients) in whom we cannot achieve biochemical and symptomatic amelioration, we’re going to have to add T3 somewhere
  - One opportunity might be to add it by itself in [Cytomel](https://en.wikipedia.org/wiki/Liothyronine) [one brand of liothyronine], but we know from experience that typically does not go well
  - It’s just too big a dose too quickly
  - So the alternative might be these **desiccated [thyroid] compounds** where you seem to be getting a favorable ratio that seems to allow patients to take a higher dose, and you could argue the main advantage of this is at least a reputable
  - The main advantage of this is at least a reputable company that formulates a desiccated compound is under the watchful eye of the FDA, more so than a compounding pharmacy

**Tony repeats his recommendation for treatment and adds comments**

***He will start most patients with*** [***levothyroxine***](https://en.wikipedia.org/wiki/Levothyroxine)

- But now, based on what he knows, he will consider hypothyroidism a risk factor for other diseases, and he would put that patient under more intense care
  - He would not say, “*You know what? Your TSH is normal, you’re taking 100 mgs, come back in a year or two*.”
  - He would think **hypothyroid is a risk factor for cardio-metabolic disease** and would make sure he’s constantly checking cholesterol, statin, LDL… for any signs of early cardiovascular disease
- For those patients that don’t feel well on levothyroxine, we would start combination therapy after eliminating all the comorbidities that cause symptoms similar to those residual symptoms
  - Someone might be undergoing menopause and started with hypothyroidism, so let’s start estrogen replacement therapy if appropriate, and then let’s address this

***He would first eliminate the comorbidities and then start combination therapy***

- Here he has a slightly different view that Peter’s takeaway: he thinks a **synthetic [hormone] combination** is as good as desiccated thyroid extract
  - The synthetic combination gives me the ability to change the ratio, and although studies have been done showing that the best ratio is around 4
  - Interestingly enough, the studies were done at the Brigham and Women’s Hospital in 1965 by Dr. Selenko (a highly reputable doctor at Harvard Medical School): he tested multiple combinations of T4 to T3, and he reached the conclusion that the best one was about 3.5 to 1
  - And by chance, desiccated thyroid extract from pig is a ratio of 3.5 or 4 to 1
  - So desiccated thyroid extract is fine
- We have in this country 1.5 million patients taking desiccated thyroid extract, and we have about 400,000 taking combination therapy with synthetic hormone

**How can patients be sure about the quality of desiccated thyroid extract?**

- Peter has only heard of 2 brands: [Nature-Throid](https://www.naturethroid.com/) and [Armor Thyroid](https://www.armourthyroid.com/), but there are a few more
- Some are even getting pulled off the market and have notifications from the FDA

*Is there an easy place that a patient can go and find out?*

- Look for recalls on the [FDA website](https://www.fda.gov/safety/recalls-market-withdrawals-safety-alerts)
  - The recalls not only affect the secreted thyroid extract, they affect levothyroxine as well
  - Just in July we had 40,000 bottles of generic levothyroxine were [recalled](https://www.drugs.com/news/fda-upgrades-recall-160-000-bottles-thyroid-125940.html)

**How strongly do you feel about using branded** [**Synthroid**](https://www.rxlist.com/synthroid-drug.htm)**?**

*Which company makes Synthroid?*

- [AbbVie](https://www.synthroid.com/support?cid=ppc_ppd_ggl_Synthroid_Branded_www__synthroid_Phrase_USSYNT210334)

**How do you feel about the use of branded Synthroid versus any of the generics?**

- Peter has heard arguments that say, “*Sandoz levothyroxine generic is the best one, and Synthroid has something in it that makes it not good.*”
- He wonders how you make sense of that
- The studies available show that they’re the same
  - There’s no difference
  - People have looked at this over and over, there’s no difference
- Especially with the fact that Antonio can prescribe a brand medication, and the pharmacists can change to generic, and if they do that, they don’t necessarily need to tell the patient that they did that
- He did a [study](https://pubmed.ncbi.nlm.nih.gov/37335236/) a couple of years ago showing that in the first year that the patient has been placed on levothyroxine, 20-30% already are using more than one format (generic versus brand)
  - The second year, it goes up to 40% to 50%

***The change is a reality. Those patients that stick to one brand are less and less***

> “*I think that the idea of the brand came from the marketing pressure from the manufacturers of the brand Synthroid, the brand levothyroxine.*”‒ Antonio Bianco

- Once manufacturers were faced with the existence of generics, they start saying, “*No, ours is better than the generic.*”
  - And they visited doctors with lectures, dinners saying branded is better

Antonio adds, “*This was so inserted into our minds that even one of the* [*guidelines*](https://www.liebertpub.com/doi/full/10.1089/thy.2014.0028#sec-2:~:text=levels%20(51).-,Choice%20of%20Levothyroxine%20Product,-2a.%E2%80%82Is%20there) *that were published by the American Thyroid Association on treatment of hypothyroidism… It says treatment of hypothyroidism needs to be done with branded levothyroxine.*”

- How would you say that with zero evidence? But we said it
- Peter interviewed Katherine Eban [[episode #71](https://peterattiamd.com/katherineeban/)] who wrote a lengthy expose on generic versus branded drugs
- He doesn’t recall where a thyroid hormone was, but she looked very broadly at generic versus branded drugs

***And there was a pretty significant discordance between what was in a drug versus what was not, depending on if it was a brand versus a generic***

- There were some incredibly nefarious companies that were out there making feedstock basically overseas that were leading to drugs that did not contain in total quantity what they were supposed to
- Peter would have to go back and look and see where that came out
- He doesn’t remember seeing if there was anything egregious on the thyroid side

Antonio explains, “*No, with levothyroxine, what happens is that the requirement is that the potency be around plus minus 5%.*”

- You need to have 100 micrograms, either 95 or 105, over the length of the life shelf of the medicine
  - This is pretty tight, and most drugs don’t have that
  - It used to be ±10%, but the FDA changed a few years ago to ±5% so there’s very strict control of levothyroxine
- And that’s pretty good because small changes will have a biological significance (that defines the therapy)

## Redefining treatment success: why normalizing TSH isn’t always enough for patients with hypothyroidism [A: 1:54:45, V: 2:05:26]

**What is the goal of therapy?**

*What are you targeting to tell you that we have now reached the correct dose?*

- If you ask the guidelines that are put together by the professional societies, it’s to normalize TSH (that’s the goal of the therapy)
- Or normalize free T4 because free T4 is usually going to be even in many cases above normal, but ***you’d have to normalize TSH and free T4***
  - You pay less attention to symptoms

***The goal of the therapy is to achieve biochemical euthyroidism. It’s not to achieve clinical euthyroidism.***

- And why do we say that?
- Because we know we cannot achieve clinical euthyroidism in all patients (we can’t)
- To make it easier for the doctor to provide some rationale for the doctor, just normalize TSH

> “*But I argue that if the patient continues to exhibit symptoms, we did not achieve an ideal therapy.*”‒ Antonio Bianco

- And this is not unheard of: depression
  - We don’t have a biomarker for depression
  - What is the anti-depressive medication that cures 100% of the patients? None

**Antonio’s recommendations for treatment of hypothyroidism**

- 1 – It would be easier if we started to take an unbiased approach and say, “*Okay, this treatment works well for most patients.*”
- 2 – Let’s consider hypothyroidism as a risk factor for cardiometabolic disease
- 3 – Let’s focus on the other patients that we can’t resolve and let’s try to fix that
- Most guidelines have migrated to that position, recognizing #1 that levothyroxine is not efficient for all patients
  - That’s already a major change because Antonio was told patients that are not feeling well, you should send them to psychotherapy
  - We moved from that position to saying levothyroxine is an incomplete treatment for those patients
- 4 – We might want to try combination therapy
  - Combination therapy is either synthetic or desiccated thyroid extract

## Case studies: analysis of two unusual cases of thyroid disease [A: 1:57:00, V: 2:08:22]

**Case study #1 (a patient of Peter’s)**

*What about the scenario where you fix the free T4? The symptoms are fine, the TSH is still markedly elevated. What do you do there?*

- Peter’s patient is a man in his early 50s, very healthy (no health issues at all), and 4 years ago he presented with a TSH of 74.7 4
  - Peter recalls that his free T4 was low normal (0.7-0.8-ish)

- Antonio points out that depending on the assay used, this is around a lower limit of normal
- Peter put him on T4 and within 6 months, his TSH is 23.7, but he is complaining of symptoms of hyperthyroidism
- We go through basically four years of constantly changing everything
  - We move to straight desiccated, we move to combination synthetic, control-release, you name it
  - We basically are at a point where TSH most recently was 13.3, free T4 0.86, free T3, (which I think we’re not going to be terribly excited about) 3.6

***Bottom line is we can’t get that TSH normal without him exhibiting all sorts of subjective signs of hypothyroidism***

*Do we just accept that his TSH is going to have to be elevated as long as his symptoms are okay, and his T4 is in the lower limit of normal?*

Antonio’s questions

- Did he have a goiter? No
- Did he ever have a normal TSH?
  - Yes, he had a history of a normal TSH as an adult
  - That’s really important, and that means it isn’t genetic
- When you test it [his thyroid hormones], did he always go to the same laboratory?
  - No, he probably used 2 different labs, but most of it would have been through Labcorp (which is pretty reputable)
- Did you do a thyroid ultrasound? Was that normal?
  - He has had thyroid MRI, which was normal
  - Peter doesn’t know if he’s had an ultrasound
- Antonio’s first choice would be **interference in the assay**: the food we eat, we have contact with rodents all the time in the food that we eat or everywhere we go, there are rodents, and we develop antibodies against proteins in rodents
  - We also develop antibodies against the rodent antibodies (it’s not frequent, but it’s not rare)
  - And the antibodies used in these assays are basically made in rodents
- What is slightly unusual about this case is that the TSH came down

***When you have this interference, the TSH hardly comes down, but maybe it’s because he went to a different lab, so he never went back to the 75?***

- Peter would have to go back and look when the switch was made from one lab to the other
  - He’s pretty sure that the 74.7 to the 23.7, which occurred within 5 months of each other, those measurements were in the same lab
- Antonio thinks that’s one strong possibility [that the 2 measurements were done by different labs]

**⇒** There’s a test you can do to check for [antibodies against mouse proteins](https://www.labcorp.com/tests/140657/human-antimouse-antibodies) [HAMA or human anti-mouse antibodies]

- Let’s say this comes back normal

What else could explain this?

- This is not a tumor in the pituitary gland producing TSH
  - The patient has no hyperthyroidism, and the thyroid is not increased
- There are some forms of **aggregated TSH molecules** that confound the assay
  - Sometimes TSH can aggregate with another molecule of TSH and another molecule of TSH and confound the assay
- There’s one more possibility: if a patient exhibited hyperthyroidism for a long time, sometimes you can never bring the TSH back to normal
  - Antonio had a few cases like this
  - Maybe **something changed in the regulation of the TSH gene** that you cannot bring [back to normal], but not at these levels

***Antonio thinks that these levels are astronomical; he would think that you are authorized to look at free T4 and forget about TSH in this case***

**Case study #2 (another patient of Peter’s)**

- A 58-year-old woman who presents with a very low TSH on thyroid therapy
- Peter doesn’t have all the labs here, but to be clear, she presents hypothyroid
- But when [T4 is] replaced, her TSH responds very extreme, so she goes from “on” to “off”
  - There seems to be no ability even going between say 100-112 micrograms, you just see a complete pivot between a TSH of as low as 0.06 to anything
  - If you lower the dose at all, TSH goes up, free T4 goes down, she becomes very symptomatic of hypothyroidism

Antonio’s questions

- TSH goes up?
  - Yes
- Peter’s question is why is her pituitary response so non-linear to the T4?
  - She’s on T4 monotherapy, but to keep her feeling good clinically, you have to give her a dose of about 112, which turns her TSH to basically zero
- What’s the free T4 in that dose?
  - He doesn’t have all the data in front of him
  - All he knows is her free T4 is low normal
- Antonio would think that there are cases like that
  - We don’t have a syndrome that will explain the molecular mechanism for that
  - He can’t think of a situation in which the TSH regulation is so exquisitely sensitive to T4
- Whereas we don’t have the molecular explanation, we know what we should do
- You’re not looking at TSH anymore because you don’t trust TSH anymore

***You have to confine yourself to looking at the free T4 and bring the free T4 within the normal range***

- When do we do this?
  - For example, we do this and during pregnancy: a woman with *hyper*thyroidism that becomes pregnant, we want to treat the woman with anti-thyroid medication, but we want to give as little as possible because the drugs cross the placenta and they can cause *hypo*thyroidism in the fetus

 Peter asks, “*You’ll let the TSH go as high as possible?*”

- No, they have hyperthyroidism

***Antonio allows the TSH to be suppressed ‒ he wants to give the amount of drug that’s going to keep the free T4 in the upper limit of normal. His reference becomes the free T4 and not the TSH anymore***

These are both rare cases in which you’re not looking at TSH anymore

- Use your clinical judgment and make sure the free T4 [is normal]
- Because once the free T4 or the free T3 are abnormal, you’re doing something wrong
- You don’t want to have someone with the elevated free T3 or a subnormal free
  - Antonio thinks that those are more robust measures when don’t have the TSH

## Dangers of supplementing with high levels of iodine, and female-specific risk of thyroid disease [A: 2:05:45, V: 2:18:45]

**Are there people out there that are supplementing iodine at very high levels?**

- Antonio mentioned earlier that if you eat even a modest amount of seafood and use table salt, you’re going to get iodine (this will provide enough)
- There are some people out there who think you should never use [iodized] table salt
  - You should only use non-iodized salt or Himalayan non-iodized salt
- Others think that you need to supplement with enormous amounts of iodine

*What is the risk of high dose iodine supplementation?*

Antonio explains, “*The daily iodine intake should be around 150 micrograms for adults. For pregnant women, we should have about 250 micrograms because you’re expanding your pool so you need a little bit more.*”

- In Japan, their normal diet gives them about 500-600 micrograms of iodine per day, and as a result they have an increased incidence of autoimmune thyroid disease

***One risk is autoimmune thyroid disease – we know that excess iodine is bad for the thyroid***

- Excess iodine will increase the antigenicity of the thyroid and trigger autoimmune disease
  - It will be autoimmune *hypo*thyroidism

We have to think about iodine-induced hyperthyroidism

- Sometimes you have a nodule in the thyroid
- And this basically provides substrate
- Then when you start taking pills of iodine, it’s going to be hyperthyroid

**Are there any other male-female differences that pertain to hyperthyroidism?**

- Peter presumes that women have a slightly higher incidence all things considered
- Oh yeah, 10 to 1 (it’s gigantic)
  - Wow, Peter didn’t know it was that big (he thought it was 4 to 1)

*Do we have an explanation for that because do women exhibit 10 to 1 higher autoimmunity?*

- We don’t have an explanation for that

*Has someone done the analysis to see if that’s dependent on pregnancy at all?*

- In other words, does pregnancy prime their immune system to go after their thyroid system?
- Antonio doesn’t think so
- Although there is a clinical entity known as [postpartum thyroiditis](https://en.wikipedia.org/wiki/Postpartum_thyroiditis) that is a woman will develop hyperthyroidism after giving birth
  - About 50% of the cases she will remain hyperthyroid
  - In other cases, thyroid function will be restored
- But other than that, Antonio doesn’t think it has to do with pregnancy

***He saw some studies showing that the female thyroid leaks a little bit more antigens than the male thyroid, and that would make it more antigenic***

*Why do you think that is? What’s causing the leak of thyroid antigens?*

- It has to do with sex hormones
- Antonio doesn’t think we have a consistent explanation for that

Peter reacts, “*It’s amazing. The deeper I explore corners of medicine, the more I’m amazed at the male-female differences and the lack of answers we have on why.*”

## Case study of a patient who presents with elevated TSH but no symptoms [A: 2:09:30, V: 2:23:09]

**Case study #3: a patient presents only with an elevated TSH**

- They have normal free T4
  - If you define normal as within the range, but let’s just say it’s lower half of the range for free T4
- Normal antibodies and no symptoms, but TSH is 8-9 (twice the upper limit)
- Let’s assume we’re talking about a 40-year-old male
  - And then a 40-year-old female

*What do you do?*

- That’s a case of subclinical hypothyroidism
  - Free T4 is normal, TSH is elevated
- Let’s find out: Why is the TSH elevated?
- The approach is pretty much similar [in males and females]

***It’s not normal to have an 8-9 TSH when you’re 40 years old ‒ this is defined as subclinical hypothyroidism***

- First, we need to ask [about] cases in the family
  - We know there are families that have hypothyroidism in many individuals
- We will do an ultrasound
  - Is the thyroid showing a patchy pattern, which is typical of [Hashimoto’s disease](https://en.wikipedia.org/wiki/Hashimoto%27s_thyroiditis), or do we have a perfectly bright normal thyroid?
- Obviously if the patient has no symptoms, what we do is first we repeat [the TSH assay]

*What’s the normal range on free T4?*

- Antonio doesn’t know

*Is 1.15 a normal?*

- It depends on the lab, but it sounds normal to Antonio
- This patients has a free T4 of 1.15, his last TSH was 7.1, free T3 2.3

We want to determine if this is going to evolve into hypothyroidism (or not)

- We would probably favor treatment if:
  - There is a patchy pattern [on the thyroid ultrasound]
  - The patient is [TPO](https://en.wikipedia.org/wiki/Antithyroid_autoantibodies#:~:text=anti%2Dthyroid%20peroxidase%20antibodies%20(anti%2DTPO%20antibodies) positive
  - If the family has hypothyroidism
- If we cannot find any other indication that this person is going to develop hypothyroidism, there are studies showing that they will benefit from treatment with levothyroxine
  - Especially what relates to metabolic disease, cholesterol and other things
  - There is some beneficial factor associated with treatment in this case

***In both cases, Antonio would favor treatment***

*Peter prescribed this patient* [*Synthroid*](https://en.wikipedia.org/wiki/Levothyroxine) *[a brand of levothyroxine], and he felt worse*

- He thinks he prescribed somewhere between 50-75 micrograms just to bring his TSH down
- With that he felt symptomatic; he felt better off the medication
  - So obviously, we stopped the medication, and now we let him walk around with a high TSH

*You’re saying basically just keep an eye on his free T4*

- Correct
- Because at some point, it’s likely it is going to actually dip and this will go from subclinical to clinical

Antonio points out one important thing

- If we were talking about a 60-year-old male or female, we wouldn’t treat at all

**⇒** Because after 50 years of age, your upper limit of normal TSH will increase by 1 point every 10 years

- For someone that is 80 years old, it’s okay to have the upper limit of normal of 8
- For 90 years old, it’s okay to have a 9
- For 100 years old, it’s okay to have a 10

***We allow the TSH from a diagnostic point of view to go up as you’re getting older***

- Peter did not know that

**Peter’s takeaway**

- So somebody who’s listening to this who’s 70, who has a TSH of 6, you’re totally normal
  - Don’t even think of putting anyone on levothyroxine in that case

## How future research could reshape treatment, and Antonio’s new book called “Rethinking Hypothyroidism” [A: 2:13:15, V: 2:27:54]

**What are our biggest blind spots in treating thyroid patients today ?**

*What should be known in a decade that’s going to change the lives of patients dealing with thyroid conditions (either in the hyper or hypo state)?*

- In other words:
  - Are we deficient in our diagnostic techniques?
  - Are we deficient in our treatment techniques?
  - Where are we most lacking?
  - Where would you like to see the most improvement in the next decade?
- We need to address hypothyroidism because there are 20 million individuals here in the US
- Antonio thinks we lack treatment; we have to improve treatment
- These patients suffer, a lot
  - We can’t ignore that
  - They’re vocal, we hear their stories

> “*We have to move from the idea that we can’t do anything but normalize TSH to try to do something. Where are we going to evolve?*”‒ Antonio Bianco

For patients with *hypo*thyroidism

- 1 – We have to have better methods of measuring T3: **mass spec for T3** is mandatory in his view
- We want to normalize T3 in the circulation, and we need a reliable, robust method [to measure free T3]
- 2 – The pharmaceutical industry needs to **develop a slow-release T3**
  - Although all these studies we’ve done is with short-lived T3 (even with the normal T3 standard), it’s [slow-release is] beneficial as opposed to levothyroxine
- Having a slow-release T3 will give that confidence to the physician that they’re not doing any harm
  - You’re just doing what the thyroid does
  - That’s what we need
- We have not moved very fast on that

There are 2 approaches to slow-release

- There’s a company that developed a polymer of T3 that slowly breaks down intestine [discussed in this [review](https://pmc.ncbi.nlm.nih.gov/articles/PMC10843736/#:~:text=these%20patients%2C%20new-,slow%2Drelease%20LT3%20formulations,-that%20provide%20stable) by Antonio]
- There’s another group in Italy that is treating patients with [T3 sulfate](https://pubmed.ncbi.nlm.nih.gov/31849843/) (that’s a very interesting strategy)
  - T3 sulfate is inactive (it doesn’t do anything) however, it is absorbed; and when it hits the liver, there’s a desulfatase that works at a steady-state velocity
  - So the liver becomes a source of T3 to the circulation that maxes out at the capacity of the desulfatase
  - The liver keeps secreting at a constant rate T3 as long as you give [T3 sulfate]

*Are both compounds available in Europe?*

- One of them is in the US ‒ they’re working with the FDA to have the polymer approved
- T3 sulfate is being developed in Europe

***They’re both in development***

- The one in the US: phase I was successful and they’re working with the FDA to get a short phase II

*What is going to be the end-point for phase III?*

- The FDA has a different pathway
  - Because it’s the same molecule, you go through a different pathway: [505(b)(2)](https://en.wikipedia.org/wiki/505(b)(2)_regulatory_pathway)
- Luckily, this will be a fast approval, but you never know what the FDA is going to ask
- Antonio hopes it goes faster

***Either one of them will be phenomenal; these are fabulous ideas; Antonio would like in 10 years to see this available for patients***

**Peter recommends Antonio’s book,** [***Rethinking Hypothyroidism: Why Treatment Must Change and What Patients Can Do***](https://www.amazon.com/Rethinking-Hypothyroidism-Treatment-Change-Patients/dp/0226823164/ref=sr_1_1?crid=2GWUNY17J8ZPU&dib=eyJ2IjoiMSJ9.2K3Vy-FbTTSIZFL6KRjPOVK0fomd9xBtsnrzZckNlyZvmW5DhsC8JLfl1eQ0ngvPuvv5I1zyGHNE53oSTRI5wk9TKWPIq1ZZQnMxK-GzHEafvNsjLWvKmKOmMGYKz_1_Faa1KcenyAdEvvcYPA_J8V92lwpQoQk609L8ywLnGs5w1lnIw67L7md_eH8Jg0AW.mpiItVZXZfUPyfg7Ig56gWJz7Ef7E5dCWzCUNFYr4zk&dib_tag=se&keywords=rethinking+hypothyroidism&qid=1761925668&sprefix=%2Caps%2C96&sr=8-1)

![](https://peterattiamd.com/wp-content/uploads/2025/11/f4-antoniobianco.png)

**Figure 4. Antonio’s recent book**. Image credit: [amazon.com](https://www.amazon.com/Rethinking-Hypothyroidism-Treatment-Change-Patients/dp/0226823164/ref=sr_1_1?crid=2GWUNY17J8ZPU&dib=eyJ2IjoiMSJ9.2K3Vy-FbTTSIZFL6KRjPOVK0fomd9xBtsnrzZckNlyZvmW5DhsC8JLfl1eQ0ngvPuvv5I1zyGHNE53oSTRI5wk9TKWPIq1ZZQnMxK-GzHEafvNsjLWvKmKOmMGYKz_1_Faa1KcenyAdEvvcYPA_J8V92lwpQoQk609L8ywLnGs5w1lnIw67L7md_eH8Jg0AW.mpiItVZXZfUPyfg7Ig56gWJz7Ef7E5dCWzCUNFYr4zk&dib_tag=se&keywords=rethinking+hypothyroidism&qid=1761925668&sprefix=%2Caps%2C96&sr=8-1)

- Peter points out that this is obviously written for patients, but really it’s also a helpful book for physicians

Peter adds, “*Folks should absolutely check that out because, again, you have a very nuanced view of this, which is why I wanted to have you on the podcast.*”

**There are these warring factions on how thyroid disease should be treated**

- 1 – One view is that all you need [to know] is TSH and all you need to do is give T4, and everybody fits in a nice neat box
- 2 – At the other end of the spectrum, everybody has hypothyroidism and we need to treat with a hundred different elixirs and lotions and potions and “*I have the special formula*”

Peter thinks, “*But in the middle, there’s probably the truth*.”

- Antonio agrees
- Peter hopes this podcast gets a lot of the information from Antonio’s book out there
- The book is helpful if people want to go into some other strategies and things

Antonio shares, “*Every day, I have an email telling a story or a patient that read the book, convinced the doctor to start combination therapy and now change their lives. Patients are very grateful, and they recognize the work that we do. Gives me a lot of pleasure.*”

---

## Selected Links / Related Material

**Antonio’s recent book**: [Rethinking Hypothyroidism: Why Treatment Must Change and What Patients Can Do](https://www.amazon.com/Rethinking-Hypothyroidism-Treatment-Change-Patients/dp/0226823164/ref=sr_1_1?crid=2GWUNY17J8ZPU&dib=eyJ2IjoiMSJ9.2K3Vy-FbTTSIZFL6KRjPOVK0fomd9xBtsnrzZckNlyZvmW5DhsC8JLfl1eQ0ngvPuvv5I1zyGHNE53oSTRI5wk9TKWPIq1ZZQnMxK-GzHEafvNsjLWvKmKOmMGYKz_1_Faa1KcenyAdEvvcYPA_J8V92lwpQoQk609L8ywLnGs5w1lnIw67L7md_eH8Jg0AW.mpiItVZXZfUPyfg7Ig56gWJz7Ef7E5dCWzCUNFYr4zk&dib_tag=se&keywords=rethinking+hypothyroidism&qid=1761925668&sprefix=%2Caps%2C96&sr=8-1) by Antonio Bianco (2022) | [1:30, 2:17:00]

**Limitations of immunoassays to measure TSH, free-T3, free-T4**: [How reliable are free thyroid and total T3 hormone assays?](https://pmc.ncbi.nlm.nih.gov/articles/PMC5113291/) | *European Journal of Endocrinology* (K Welsh, S Soldin 2017) | [40:30]

**LC-MS test for free T3**: [Triiodothyronine (T3), Free, Dialysis and LC/MS-MS (Endocrine Sciences)](https://www.labcorp.com/tests/503600/triiodothyronine-t3-free-dialysis-and-lc-ms-ms-endocrine-sciences) | labcorp | [40:30]

**Study comparing Immunoassay with mass spec for detection of T3**: [Total and free thyroxine and triiodothyronine: measurement discrepancies, particularly in inpatients](https://pmc.ncbi.nlm.nih.gov/articles/PMC4187214/) | *Clinical Biochemistry* (J Jonklass et al. 2014) | [42:15]

**Influence of genetics on levels of thyroid hormone**: [44:13]

- [The Genetic Basis of Thyroid Function: Novel Findings and New Approaches](https://pubmed.ncbi.nlm.nih.gov/32271924/) | *Journal of Clinical Endocrinology and Metabolism* (A Kus et al. 2020)
- [Multi-trait analysis characterizes the genetics of thyroid function and identifies causal associations with clinical implications](https://pubmed.ncbi.nlm.nih.gov/38291025/) | *Nature Communications* (R Sterenborg et al. 2024)

**Cancer risk from use of radioactive iodine to treat Graves’ disease**: [52:45]

- [Association of Radioactive Iodine Treatment With Cancer Mortality in Patients With Hyperthyroidism](https://jamanetwork.com/journals/jamainternalmedicine/fullarticle/2737319) | *JAMA Internal Medicine* (C Kitahara et al. 2019)
- [Cancer Risk After Radioactive Iodine Treatment for Hyperthyroidism: A Systematic Review and Meta-analysis](https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2784269) | *JAMA Network Open* (S Shim et al. 2021)

**Increased risk of miscarriage and pre-term birth in women with TPO antibodies**: [Association between thyroid autoantibodies and miscarriage and preterm birth: meta-analysis of evidence](https://pubmed.ncbi.nlm.nih.gov/21558126/) | *British Medical Journal* (S Thangaratinam et al. 2011) | [1:01:30]

**Preference for desiccated thyroid extract over levothyroxine**: [1:24:45]

- [Desiccated thyroid extract compared with levothyroxine in the treatment of hypothyroidism: a randomized, double-blind, crossover study](https://pubmed.ncbi.nlm.nih.gov/23539727/) | *Journal of Clinical Endocrinology and Metabolism* (T Hoang et al. 2013)
- [Comparative Effectiveness of Levothyroxine, Desiccated Thyroid Extract, and Levothyroxine+Liothyronine in Hypothyroidism](https://pmc.ncbi.nlm.nih.gov/articles/PMC8530721/) | *Journal of Clinical Endocrinology and Metabolism* (M Shakir et al. 2021)
- [Evaluating the effectiveness of combined T4 and T3 therapy or desiccated thyroid versus T4 monotherapy in hypothyroidism: a systematic review and meta-analysis](https://bmcendocrdisord.biomedcentral.com/articles/10.1186/s12902-024-01612-6) | *BMC Endocrine Disorders* (M Nassar et al. 2024)

**Increased mortality and adverse outcomes in patients with hypothyroidism**: [1:28:30]

- [Risk of Death and Adverse Effects in Patients on Liothyronine: A Multisource Systematic Review and Meta-analysis](https://pmc.ncbi.nlm.nih.gov/articles/PMC12527464/) | *The Journal of Clinical Endocrinology & Metabolism* (S Bahl et al. 2025)
- [Treatment of Hypothyroidism that Contains Liothyronine is Associated with Reduced Risk of Dementia and Mortality](https://pubmed.ncbi.nlm.nih.gov/40579157/) | *Journal of Clinical Endocrinology & Metabolism* (F de Lima Beltrano et al. 2025)
- [Adverse outcomes in patients with hypothyroidism undergoing bariatric surgery: A retrospective study using TriNetX](https://pubmed.ncbi.nlm.nih.gov/40971953/) | *Journal of Clinical Endocrinology and Metabolism* (V Meneghini et al. 2025)

**Double-blind studies of patients with hypothyroid symptoms confirm that symptoms alone cannot accurately diagnose hypothyroidism**: [1:40:45]

- [Thyroxine treatment in patients with symptoms of hypothyroidism but thyroid function tests within the reference range: randomised double blind placebo controlled crossover trial](https://pmc.ncbi.nlm.nih.gov/articles/PMC58535/) | *BMJ* (M Pollock et al. 2001)
- [THU664 Discontinuation Of Low-dose Levothyroxine Therapy For Patients With Subclinical Hypothyroidism Is Feasible: A Pilot, Randomized, Double-blind, Placebo-controlled Trial](https://pmc.ncbi.nlm.nih.gov/articles/PMC10555089/) | *Journal of the Endocrine Society* (S Maraka et al. 2023)
- [Hypothyroidism: The difficulty in attributing symptoms to their underlying cause](https://pmc.ncbi.nlm.nih.gov/articles/PMC9939761/) [review] | *Frontiers in Endocrinology* (H Jansen et al. 2023)

**There’s no data showing slow, sustained release of T3 in control-release T3**: [Sustained Release T3 Therapy: Animal Models and Translational Applications](https://pmc.ncbi.nlm.nih.gov/articles/PMC6700330/) | *Froontiers in Endocrinology* (T Idrees et al. 2019) | [1:42:45]

**Episode of** ***The Drive*** **on compounding pharmacies**: [#275 – AMA #52: Hormone replacement therapy: practical applications and the role of compounding pharmacies](https://peterattiamd.com/ama52/) (October 16, 2023) | discussed after 1:09:30 | [1:43:15]

**Many patients prescribed levothyroxine switch formulations within the first year**: [Levothyroxine Treatment Adequacy and Formulation Changes in Patients with Hypothyroidism: A Retrospective Study of Real-World Data from the United States](https://pubmed.ncbi.nlm.nih.gov/37335236/) | *Thyroid* (A Bianco et al. 2023) | [1:52:00]

**American Thyroid Association guidelines for the treatment of hypothyroidism**: [Guidelines for the Treatment of Hypothyroidism: Prepared by the American Thyroid Association Task Force on Thyroid Hormone Replacement](https://pubmed.ncbi.nlm.nih.gov/25266247/) | *Thyroid* (J Jonklaas et al. 2014) | [1:52:45]

**Episode of** ***The Drive*** **on generic versus branded drugs**: [#71 – Katherine Eban: Widespread fraud in the generic drug industry](https://peterattiamd.com/katherineeban/) (September 16, 2029) | [1:53:15]

**Review of slow-release T3 in development**: [Emerging Therapies in Hypothyroidism](https://pmc.ncbi.nlm.nih.gov/articles/PMC10843736/) | *Annual Reviews in Medicine* (A Bianco 2023) | [2:15:00]

**Group in Italy treating patients with T3 sulfate**: [2:15:15]

- [Steady-State Serum T3 Concentrations for 48 Hours Following the Oral Administration of a Single Dose of 3,5,3′-Triiodothyronine Sulfate (T3S)](https://pubmed.ncbi.nlm.nih.gov/24518178/#) | *Endocrine Practice* (F Santini et al. 2014)
- [Treatment of Hypothyroid Patients With L-Thyroxine (L-T4) Plus Triiodothyronine Sulfate (T3S). A Phase II, Open-Label, Single Center, Parallel Groups Study on Therapeutic Efficacy and Tolerability](https://pubmed.ncbi.nlm.nih.gov/31849843/) | *Frontiers in Endocrinology* (F Santini et al. 2019)

---

## People Mentioned

- [Edward Kendall](https://en.wikipedia.org/wiki/Edward_Calvin_Kendall) (1886-1972, Biochemist who worked at the Mayo Foundation when he received the Nobel Prize for Physiology or Medicine for his work on cortisone; he later joined the faculty of Princeton; he isolated thyroxine, glutathione, and several steroids from the adrenal gland) [1:27:00]

---

![](https://peterattiamd.com/wp-content/uploads/2025/11/bio-antoniobianco.png)

##### Antonio Bianco, M.D., Ph.D.

Antonio Bianco earned his M.D. at the Santa Casa Medical School and Ph.D. in human physiology at the University of São Paulo, both in Brazil. For 10 years he studied the biology of deiodinases at Brigham and Woman’s Hospital in Boston. After he served as Chief of the Thyroid Section, he moved to the University of Miami to lead the Division of Endocrinology. In 2014, he was appointed the Charles A. Weaver Professor of Cancer Research, Senior Vice President and Vice Dean of Clinical Affairs, and President of the Rush University Medical Group in Chicago. In 2018, he moved to the University of Chicago where he served as Professor in the Department of Medicine, Section of Adult and Pediatric Endocrinology, and Director of the Thyroid Study Unit. In 2024 he was recruited to the University of Texas Medical Branch at Galveston (UTMB) as the [Nelda C. and H. J. Lutcher Stark Chair in Internal Medicine](https://www.utmb.edu/internalmedicine/divisions/endocrinology/our-team/faculty/antonio-bianco) where he also maintains a NIH-funded laboratory. Currently, he also serves as the Vice President and Vice Provost for Research, and Chief Research Officer at UTMB.

Dr. Bianco is a physician-scientist who has published extensively in the area of thyroid hormone metabolism and action. His work has established the importance of local control of thyroid hormone metabolism via deiodinases and has inspired the modern paradigm that deiodinases regulate thyroid hormone signaling on a tissue-specific basis, playing critical roles in human health and disease. His research has focused on how T3 initiates or terminates critical biological steps while maintaining relatively stable plasma levels. Most recently, his laboratory has investigated the epigenetic mechanisms of T3 action and their implication for children with congenital hypothyroidism.

Dr. Bianco’s work has been recognized with numerous awards and elections to membership in prestigious professional societies. He served as a regular member of NIH study sections for almost 10 years and also served on the Board of Scientific Counselors of the NIDDK. He has held various administrative positions, including chief of endocrinology at the University of Miami and Rush University, where he also served as President of the Medical Practice. Dr. Bianco was elected and served as President of the American Thyroid Association in 2016. [[utmb Health](https://www.utmb.edu/provost/resources/academic-enterprise-announcements/article/academic-enterprise-announcements-and-information/2024/07/17/bianco-named-vice-president-and-vice-provost-for-research--chief-research-officer)]

X: [@bianco\_lab](https://x.com/Bianco_Lab)

Website: [BiancoLab](http://deiodinase.org/)