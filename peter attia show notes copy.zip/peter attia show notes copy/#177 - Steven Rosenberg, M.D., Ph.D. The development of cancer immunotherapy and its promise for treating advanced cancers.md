# #177 – Steven Rosenberg, M.D., Ph.D.: The development of cancer immunotherapy and its promise for treating advanced cancers

**Source:** [https://peterattiamd.com/stevenrosenberg/](https://peterattiamd.com/stevenrosenberg/)

---

Steve Rosenberg is the Chief of Surgery at the National Cancer Institute, a position he has held continuously for the past 47 years. Steve is a pioneer in the field of immunotherapies for cancer and a recipient of nearly every major award in science. In this episode, Steve discusses his inspiration for devoting his career to cancer research and describes his keen observation of two cases of spontaneous cancer remission, driving him to learn how to harness the immune system to treat cancer. Steve’s personal story essentially serves as a roadmap for the field of immunotherapy, from the very non-specific therapies such as interleukin-2, the discovery of tumor-infiltrating lymphocytes, checkpoint inhibitors, CAR T-cells, and adoptive cell therapy. Perhaps most importantly, Steve expresses his optimism for what lies ahead, especially in the face of some of the more recent discoveries with respect to tumor antigenicity. Finally, Steve discusses the human side of cancer which helps him to never lose sight of why he chose to become a physician.

\*[WATCH PODCAST ON YOUTUBE](https://youtu.be/pVMl0LgdnOU)\*

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/stevenrosenberg/the_Drive_public.png)

Play

#177 - Steven Rosenberg, M.D., Ph.D.: The development of cancer immunotherapy and its promise for treating advanced cancers

#177 - Steven Rosenberg, M.D., Ph.D.: The development of cancer immunotherapy and its promise for treating advanced cancers

1x15s30s

0:002:06:26

## We discuss:

- Steve’s childhood and inspiration to become a physician and medical researcher [3:15];
- Patients that influenced Steve’s thinking about cancer and altered the course of his career [13:15];
- The discovery of antigen presentation, Steve’s first job, and why he knew he wanted to study cancer [19:30];
- Cancer treatment in the early 1970’s and Steve’s intuition to utilize lymphocytes [26:45];
- Cancer cells vs. non-cancer cells, and why metastatic cancer is so deadly [31:45];
- The problem with chemotherapy and promise of immunotherapy [38:30];
- How the immune system works and why it seems to allow cancer to proliferate [43:15];
- Steve discovers how to use interleukin-2 to mediate cancer regression [52:00];
- The immunogenic nature of certain cancers and the role of mutations in cancer [1:03:45];
- The improbable story of how CAR T cell therapy was developed [1:16:30];
- The discovery of tumor infiltrating lymphocytes (TIL) and engineering of T cells to recognize specific antigens [1:28:00];
- Steve’s experience treating President Ronald Reagan’s colon cancer [1:36:00];
- Why Steve has turned down many tempting job offers to focus on his research at the National Cancer Institute [1:41:00];
- The role of checkpoint inhibitors in cancer therapy and the promise of adoptive cell therapy [1:43:00];
- Optimism for using immunotherapy to cure all cancers [1:48:00];
- The human side of cancer and the important lessons Peter learned from working with Steve [1:52:15];
- More

§

## Show Notes

## Steve’s childhood and inspiration to become a physician and medical researcher [3:15]

- Up until age 5 or 6 Steve wanted to be a cowboy.  He and his older brother would talk about going out west, riding horses, and doing exciting things
- At age 5 or 6 at the end of the Second World War he remembers clearly the tragedies of the Holocaust
  - This made a huge impression on him how evil people could be towards one another.
  - Around that time, he developed an almost spiritual desire to become a doctor, to do research and make progress in helping people, in alleviating suffering rather than causing suffering
  - Inspiration to become a doctor developed in response to the horrors of that time
  - His commitment to research aims to alleviate suffering in the future
- Steve’s education [6:10]
  - Accepted to [Johns Hopkins](https://www.hopkinsmedicine.org/som/), the very best medical school for a combined bachelor’s MD degree, a 6-year program
    - This was in the late fifties and early sixties
    - It was 3 years of college and 3 years of medical school

- At Hopkins there were brilliant people around, and Steve recounts “I think is probably one of the single most important components of a good education…being surrounded by people who know a lot more than you, can inspire you”
- After finishing his MD Steve wanted further education

> “But I knew from the very beginning that I wasn’t just going to try to practice today’s science, practice today’s medicine, but rather try to create the medicine of tomorrow and that stuck with me for these last 60 or 70 years or so.” – Steve Rosenberg

- He went on to get a Ph.D. in [biophysics at Harvard](https://gsas.harvard.edu/programs-of-study/all/biophysics)
  - He wanted to be able to grasp any area of science and use it to answer questions and thought maybe differential equations would be helpful
  - Ended up doing a lot a math in graduate school
  - For 2 years he did nothing but study, take classes, and learn
  - The last 2 years of his Ph.D. was focused on research, studying cell membranes, physical chemistry and protein chemistry
  - He wanted a good enough broad background in the sciences so if he encountered a problem he could get a good book, read some papers, and understand it.

> “I never wanted to be intimidated by what I did not know.” —Steve Rosenberg

- High school biology and college classes inspired his interest in cancer
- Timing of his Ph.D. and residency [10:00]
  - After medical school began his surgical residency at the [Peter Bent Brigham Hospital](https://www.brighamandwomens.org/)
  - Next he took four years off to get a Ph.D. in biophysics at Harvard
  - It was a year of internship, four years off to get a Ph.D., then back to the residency
  - Then came down to the NIH for several years to join the immunology branch in 1974 (during the Vietnam War)
    - It was unusual for someone to leave their internship to go into a Ph.D. program at that time

> “I was just not satisfied after medical school, the college of medical school that I really knew enough to do creditable, meaningful, impactful, research.” – Steven Rosenberg

- Peter asks if [Franny Moore](https://en.wikipedia.org/wiki/Francis_Daniels_Moore) the most significant figure in his life at that point in time as a mentor?
- Steve recounts “Franny Moore was the chief of surgery and an incredibly smart person,Franny stood out in that discussing a problem or patient it wouldn’t be at all surprising for him to come up with an idea or a perspective on a problem that most people had not considered. ”
- He got support to leave his residency to get a Ph.D.
  - He had a few extra meetings, but Franny was patient because Steve came back for a year then went to the NIH as part of the Vietnam draft obligation
  - Steve set a record at Brigham for taking 11 years from the time he started his internship to the time he finished the residency
    - This would have been old for a chief resident at the time

## Patients that influenced Steve’s thinking about cancer and altered the course of his career [13:15]

**The Transformed Cell**

- Steve made up for his late age by progressing quickly and writing what Peter describes as “one of the best books about science” in 1992 with [John Barry](https://en.wikipedia.org/wiki/John_M._Barry), [The Transformed Cell](https://www.amazon.com/Transformed-Cell-Stephen-Rosenberg/dp/0399137491)

> “I may have the record for most times reading it. I may also possess the record for most copies owned, which I know you got a kick out of that.” – Peter Attia

**In 1968, Steve met two patients in the ER that altered the course of his career…**

- Steve was a junior resident at the West Roxbury VA Hospital
- A 68-year-old fellow who came in complaining of right upper quadrant pain
- It looked like a typical gallbladder attack, and Steve was excited because he might be able to perform one of his first operations
- His chart contained a remarkable story
  - 11 or 12 years earlier, that patient had been seen at the West Roxbury VA Hospital
  - He had gastric cancer (a stomach cancer) and underwent a laparotomy
  - The surgeon at the time noted a tumor encompassing about three-quarters of the stomach; there were multiple liver metastasis deposits that were biopsied and shown to be the gastric cancer that had spread, multiple enlarged lymph nodes
  - Part of the stomach was removed and the rest of the disease was left in place
  - The patient recovered and about a week later, went home
  - This was now 12 years later; the patient has lived 10-11 years normally after this
  - Steve took part in removing his gallbladder and noticed his belly was completely clean of cancer

> “It was a cancer that had spontaneously disappeared over time in the absence of any therapy.  One of the rarest events in medicine, and that is to have the spontaneous regression of cancer without any treatments being given. ” – Steven Rosenberg

- *Steve wondered whether or not this patient who had somehow cured his own cancer could be somehow taken advantage of to treat other patients*

- - There just so happened to be another patient in the hospital with a gastric cancer, a veteran who also had the same blood type
  - Steve called up the head of the surgery department, [Brownie Wheeler,](https://americansurgical.org/transactions/Fellows/Memoirs/HewittBrownellWheeler.cgi) and said, “Hey, I want to take a blood transfusion from this patient who spontaneously was cured and give it to this other patient.”
    - It was approved, the [IRB](https://www.fda.gov/about-fda/center-drug-evaluation-and-research-cder/institutional-review-boards-irbs-and-protection-human-subjects-clinical-trials) (as it existed at that time)
    - He got blood from this one patient and infused it into the other veteran, but of course, it didn’t do anything and the other patient ended up dying of his gastric cancer

- *It planted the seed that in fact, maybe there was something in the immune system that caused the rejection of that cancer much as it would a foreign transplant*

- - The [immune system](https://en.wikipedia.org/wiki/Immune_system) is the body’s major defense mechanism against foreign invaders, and it got me thinking about potential immune manipulations
  - Steve was impacted by a second patient he saw about a year before he came to the Brigham as an intern
    - Patient received an early kidney transplant; the kidney inadvertently contained renal cancer
    - Under the influence of immunosuppressant medications, the cancer spread widely through his body
    - In an attempt to control this, the immunosuppressant medications were stopped
    - Of course, the kidney rejected and had to be removed, but the patient’s cancer then went away as well because it too was allogeneic; it too came from the genome of the original donor

- *For Steve, this was a huge inspiration that the immune system could be utilized to treat cancer*

> “A large invasive vascularized cancer could be caused to reject completely by the immune system if you had a strong enough stimulus that could mediate that rejection.”  – Steven Rosenberg

## The discovery of antigen presentation, Steve’s first job, and why he knew he wanted to study cancer [19:30]

**1950s-1970s**

- [MHC class I and class II molecules](https://en.wikipedia.org/wiki/Major_histocompatibility_complex) were discovered in the mid 70’s-80’s;
  - They present antigens to T lymphocytes and are essential for an adaptive immune response
- MHC class I and class II molecules were discovered in the mid 70’s – early 80’s
- Cancer antigens were unknown and there was no ability to measure an immune reaction against any cancer
- Very little immunology was understood at this time; Steve recalls
  - “*In the 1957 issue of the Journal of Immunology, the word lymphocyte was not in the index*.”

- In the 1950’s, there was no understanding of what lymphocytes do.
- In the 60’s it became know that one could transfer immunity in experimental animals by transferring lymphocytes, and this was different from transferring blood or serum

- In the 60’s one could immunize a mouse against a tumor by letting it grow and then removing it and cause that mouse to resist an implantation of the same tumor again. But once the tumor was growing, there was no maneuver that could keep it from growing, no immunologic maneuver that could keep it from growing
  - The field was desperately in need of more information

**Steve’s first job**

- Finished his residency June 30th, 1974 and was appointed the next day as Chief of Surgery at the National Cancer Institute
  - An usual first job
  - And a position he still holds 47 years later
- The NIH is a remarkable place

> “It’s a state-of-the-art hospital that provides outstanding care to patients, but it exists again, not only to practice the best of today’s medicine but to create the medicine of tomorrow and that always intrigued me from my first knowledge of the NIH when I came here in the midst of the residency during the Vietnam War.” – Steven Rosenberg

- Job offers: stay at [the Brigham at Harvard](https://hms.harvard.edu/affiliates/brigham-womens-hospital), go to [Dana-Farber](https://www.dana-farber.org/).
  - Steve was offered the position of chief of surgery at both places
  - Franny Moore at the Brighman at Harvard was extremely disappointed that Steve was leaving for the NIH to become Chief of Surgery at the [National Cancer Institute](https://www.cancer.gov/) (NCI)
  - Steve reminisces on his desire to study cancer stemming from early childhood

> “Cancer is a Holocaust and just seemed like the kind of thing I wanted to study.” —Steve Rosenberg

- The impact of  Richard Nixon’s War on Cancer
  - Would cancer be eradicated in the same way that man had gone to the moon?
- The National Cancer Act mainly influenced funding outside of the NIH
- From the perspective of a worker bee, the National Cancer Act didn’t have much impact where he was at NCI

## Cancer treatment in the early 1970’s and Steve’s intuition to utilize lymphocytes [26:45]

**Steve’s early research agenda at the NIH**

- In the early 70’s cancer was treated with simple surgery, radiation therapy, and chemotherapy; these were mostly used alone
  - The surgical approach was 3000 years old
  - Radiation therapy began immediately after [Wilhelm Röntgen](https://en.wikipedia.org/wiki/Wilhelm_R%C3%B6ntgen) discovered x-rays in 1895
  - Chemotherapy arose in biological and chemical warfare laboratories here at Fort Dietrich in Dietrich, Maryland in 1942 in a laboratory accident when lab technicians were inadvertently exposed to nitrogen mustard.
    - Lymphopenia and shrinking lymph nodes in these technicians was observed leading a Yale physician to use nitrogen mustard (now known as [melphalan](https://www.rxlist.com/alkeran-drug.htm)) as a chemotherapy agent.
- Advances in the use of chemicals to treat cancer were slow and incremental
- *Steve wanted something that would make a big difference and his intuition told him immunology was the key*
  - He knew immune cells were the key to [organ rejection](https://www.ncbi.nlm.nih.gov/books/NBK27163/)
  - He was focused on finding agents to stimulate the immune system to fight cancer

**Early experiment, a learning experience**

- Steve describes his first experiments as unbelievably naive [29:30]
- In 1974 there was no way to keep lymphocytes alive outside the body
- He began implanting tumors in [mini pigs](https://journals.sagepub.com/doi/full/10.1177/0192623315618292)
- His friend [Davis Sachs](https://en.wikipedia.org/wiki/David_Sachs) developed a mini pig colony that was partially inbred at the MHC loci
- Steve used these pigs to embed tumors in the [mesentery](https://en.wikipedia.org/wiki/Mesentery)
- Steve treated 6 patients by removing their tumor, implant it in the mesentery of a mini pig, remove nearby lymph nodes 2 weeks later, recover lymphocytes, and intravenously give these lymphocytes back to the patient
  - This was his first attempt to generate lymphocytes specific for a tumor
  - Nothing happened
  - Steve recalls the quote by Louis Pasteur saying that said chance favors the prepared mind and added to it

> “chance favors the prepared mind only if the mind is at work” – Steve Rosenberg

- - T-cell growth factor (later named [IL-2](https://www.ncbi.nlm.nih.gov/books/NBK12892/)) was [discovered in 1976](https://pubmed.ncbi.nlm.nih.gov/181845/) by Morgan, Ruscetti, and [Gallo](https://en.wikipedia.org/wiki/Robert_Gallo)

- *This allowed T lymphocytes (T-cells) to be grown outside the body and was something Steve began to study quite intensively*

## Cancer cells vs. non-cancer cells, and why metastatic cancer is so deadly [31:45]

**What separates a cancer cell from a non cancer cell?**

- *Steve notes there are two properties that separate cancer from other cells in the body*

- - - The first is uncontrolled growth
    - The second is it’s the only cell that can arise in one part of the body and spread and live and divide and grow in another part of the body ([metastasis](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/metastasis))

- *A normal cell becomes a cancer cell due to the accumulation of mutations in DNA as these cells divide*

- - Mistakes occur randomly during cell division
  - Cancer can be described but it doesn’t mean we understand it all
- Differences between epithelial tumors and hematologic tumors and the odds of survival
  - Hematological cancers are blood cancers; they begin from progenitors (stem cells) in the hematopoietic system
    - About 10% of all cancer deaths are due to hematological cancers
  - Epithelial cancers begin in the solid organs of the body
    - All organs have ducts, and it’s the epithelial lining of the ducts that are turning over that become the cancer
    - About 90% of all cancer deaths are due to epithelial cancers
    - Last year in the United States, there were about 600,000 deaths due to cancer, 550,000 were due to solid epithelial cancers
    - Operating on these patients to remove the cancer cures over half

**Deadly metastatic cancer**

> “a dirty little secret of oncology, and that is that if a cancer spreads from its local site and cannot be surgically removed, then the death rate in that patient is 100%” – Steve Rosenberg

- - There are virtually no treatments that can cure a patient with a metastatic, solid cancer (this is a cancer that has spread to another site in the body)

- *There were 2 exceptions (now 4)*

- - - Choriocarcinoma are cancers that begin in the placenta of a pregnant woman then spread; the chemotherapy drug [methotrexate](https://www.rxlist.com/trexall-drug.htm) will cause it to disappear, but we still don’t understand why
    - Germ cell tumors in testes of males can be treated with [platinum derived chemotherapy](https://en.wikipedia.org/wiki/Platinum-based_antineoplastic) regimens (such as [cisplatin](https://www.rxlist.com/cisplatin-drug.htm)) resulting in complete, durable regression of metastatic disease, no matter how much they’ve spread
    - With the application of IL-2 metastatic *melanoma* and *renal* cancer are now treatable
- Treatment of metastatic cancer improves survival but ultimately everyone succumbs to disease, median survival has been extended but not overall survival

## The problem with chemotherapy and promise of immunotherapy [38:30]

**How has survival changed over the last 50 years for common cancers?**

- Metastatic colorectal cancer – median survival in the mid-70’s would have been 8-10 months; now it’s 2.5 years
- Breast cancer patients go from one treatment regime to another causing temporary regression of cancer, each prolonging life by a few weeks
- Treating pancreatic cancer with [Erlotinib](https://www.rxlist.com/tarceva-drug.htm) prolongs survival by 6 weeks
  - Peter notes the cost of $40,000
  - Steve agrees, this comes with a huge, life altering expense and enormous toxicity
- The most frequently prescribed drug in oncology today is [Avastin](https://www.rxlist.com/avastin-drug.htm), bevacizumab, which can impact blood vessels and tumors
  - Combining Avastin with other treatments will prolong survival in patients with colorectal cancer by about 4.5 months
- How good is chemotherapy at killing cancer cells?
  - *The challenge is selectivity; how does one kill cancer and at the same time not kill normal cells?*

> “I think that’s an important point that many people don’t understand, which is how difficult it is to thread the needle of chemotherapy. It’s not the killing of cancer that’s hard. It’s the killing of cancer and not killing the non-cancer.” – Peter Attia

- *Selective killing of cancer without killing normal cells does not occur for virtually any cancer treatment: chemotherapy, radiation therapy, or even surgery*

- This is the promise of immunotherapy, its immense selectivity and sensitivity of recognition; it can recognize a single amino acid change in a protein and develop an immune response against it

## How the immune system works and why it seems to allow cancer to proliferate [43:15]

**Consider a viral infection, whether it’s the common cold or Coronavirus**

- - The virus infects respiratory epithelium and replicates in these cells
  - Infected cells express viral proteins
  - The immune system has evolved to detect proteins or other molecules that are not part of the normal cells of the body
  - B lymphocytes ([B cells](https://openstax.org/books/microbiology/pages/18-4-b-lymphocytes-and-humoral-immunity)) make antibodies
  - T lymphocytes ([T cells](https://openstax.org/books/microbiology/pages/18-3-t-lymphocytes-and-cellular-immunity)) act by directly interacting with other tissues
  - Every 14 or 15 seconds, the heart is pumping out lymphocytes, they are circulating through the vascular system, sometimes [extravasating](https://openstax.org/books/microbiology/pages/17-4-pathogen-recognition-and-phagocytosis?query=extravasation&target=%7B%22type%22%3A%22search%22%2C%22index%22%3A0%7D#fs-id1172098645723) into tissues, coming back into the lymphoid system and returning to the heart via the thoracic duct
  - When the lymphocyte encounters a foreign [antigen](https://openstax.org/books/microbiology/pages/18-1-overview-of-specific-adaptive-immunity?query=antigen&target=%7B%22index%22%3A0%2C%22type%22%3A%22search%22%7D#fs-id1167662504409) to which it can have reactivity that’s not cells
    - Lymphocytes encounter viral antigen in the respiratory epithelium; they stop at that location (this can be visualized with two-photon microscopy) they extravasate into the tissue then they begin to divide
    - As lymphocytes divide they further recognize viral protein and  start making molecules that can destroy the viral cell
    - They also call other cells into the area, [macrophages](https://openstax.org/books/microbiology/pages/17-3-cellular-defenses?query=macrophages&target=%7B%22index%22%3A0%2C%22type%22%3A%22search%22%7D#fs-id1172100993572) and [neutrophils](https://openstax.org/books/microbiology/pages/17-3-cellular-defenses?query=neutrophil&target=%7B%22type%22%3A%22search%22%2C%22index%22%3A0%7D#OSC_Microbio_17_05_GranTypes), etc.
    - This is an immune reaction
    - The antigen is eliminated by these cells
    - Now the cells leave; they’re not stimulated; they go back into circulation

- *There are now long lived lymphocytes patrolling the body for the rest of one’s life that can recognize these viral antigens*

- - This is why vaccination works

**How cancer cells are different from normal cells**

- - Cancer cells have unregulated growth because they don’t respond to cell cycle signaling
    - This is a result of [somatic mutations](https://en.wikipedia.org/wiki/Somatic_mutation); these are acquired mutations; people aren’t born with them

- *Mutations (changes in DNA) occur randomly as the cell divides; this can produce proteins that the immune system can recognize*

- Steve notes that only in the last 3-4 have doctors and scientists observed that these mutations are commonly recognized by the immune system
- The immune system in about 80% of patients with epithelial cancer recognizes mutations in this cancer
  - The problem is the immune reaction against the cancer is not rigorous enough
  - [Effector T cells](https://www.ncbi.nlm.nih.gov/books/NBK27149/) can be very aggressive in recognizing antigens
  - [Regulatory T cells](https://en.wikipedia.org/wiki/Regulatory_T_cell) act to suppress immune reactions
  - Like virtually every physiologic system in the body, there are stimulatory elements and inhibitory elements
- *For a tumor cell to grow and survive it develops certain properties such as suppressing the local immune reaction*
  - It can make molecules like transforming growth factor beta ([TBF-𝛽](https://en.wikipedia.org/wiki/Transforming_growth_factor_beta#Effects_on_immune_cells)) and interleukin 10 ([IL-10](https://en.wikipedia.org/wiki/Interleukin_10))

> “It’s the balance of the aggressive immune reaction against the inhibitory molecules that can prevent that immune reaction that is the holy grail of trying to find effective treatments” – Steve Rosenberg

## Steve discovers how to use interleukin-2 to mediate cancer regression [52:00]

- - nterleukin 2 ([IL-2](https://en.wikipedia.org/wiki/Interleukin_2)) is a [cytokine](https://en.wikipedia.org/wiki/Cytokine) allows the growth of lymphocytes (T cells) in culture
    - IL-2 is also something that could be given to patients [*in vivo*](https://en.wikipedia.org/wiki/In_vivo) to stimulate the immune system
  - Lots of questions about using IL-2
    - Would it keep T cells alive in a format that enabled them to have all of their immune recognition?
      - Tried to develop cells that would recognize [alloantigens](https://en.wikipedia.org/wiki/Alloimmunity), strong antigens present in one person that [inhibit the ability to transplant organs](https://openstax.org/books/microbiology/pages/19-3-organ-transplantation-and-rejection)
      - Initial experiments aimed to develop lymphocytes in culture to make experimental skin grafts in mice disappear faster
      - Found that lymphocytes they grew did retain their function *in vivo*
      - Next tried to develop cells that could react against cancer
      - Cells grown in IL-2 could destroy tissue-cultured cancer cells; these were called [LAK cells](https://www.mayoclinicproceedings.org/article/S0025-6196(12)65736-X/fulltext) for lymphokine activated killer cells
        - Studied LAK cells for 3-4 years and found they could only have an impact on tiny tumors in mice before they became vascularized
        - Once the tumor was vascularized, LAK cells would not work at all
  - It wasn’t until 1984 when Steve figured out how to use IL-2 to mediate cancer regression
    - Over 70 patients were treated with either IL-2 or cells grown in IL-2 before tumor regression was observed
    - The schedule of IL-2 was modified, knowing it’s pharmacokinetics, that it’s half life inside the body was only about 7 minutes.
      - High doses of IL-2 caused toxicity
    - In 1984 a patient with widespread melanoma received IL-2 and was the first to show tumor regression after over 70 other patients had been treated

- *This patient is now alive, over 35 years later, free of disease*

> “the first time that a deliberate immunologic maneuver could reproductively cause cancer regression. It was one of the few eureka moments that I’ve had in doing research.” – Steve Rosenberg

- - Comparing the process of fine-tuning the use of IL-2 in treating cancer to [Thomas Starzl’s](https://en.wikipedia.org/wiki/Thomas_Starzl) work in the 1960’s with liver transplantation
    - Many patients died before successful liver transplantation was achieved
    - There were many technical aspects to be worked out: perioperative care, postoperative care, the technical skill necessary, plus the immunosuppressive regimen
    - Steve notes that for liver transplantation there were technical problems to be overcome and immunotherapy for cancer is different
      - Didn’t know if if would ever work
  - Peter asks how many different histologies/ cancers was Steve treating with IL-2
    - Steve was treating all metastatic cancers hoping that there would be commonalities that could be attacked
    - The first patient treated with the revised regimen had melanoma
    - The third and forth patients had renal cancer

- *Steve found that 2 types of cancers would respond to IL-2: melanoma and renal cancer*

- - - The response rates turned out to be 15-20% with about a third of these patients having complete, durable regression of cancer

> “And so that first patient had an enormous impact on me and on the field because it showed that it was possible.” – Steve Rosenberg

- This led him to study cell transfer, gene modification, and so on
- How did Steve keep going in the face of those failures until this patient’s miraculous remission in 1984? [59:00]
  - Steve remembers the patient’s he failed to help more than those that did well
  - There was a remarkable number of tragedies, people of all ages
- A strong intuition based on all he had studied and the success of 2 early cancer patients kept him pursuing immunotherapy
- Steve quotes [Abraham Lincoln](https://en.wikipedia.org/wiki/Abraham_Lincoln) to describe his work ethic, “Success consists of moving from failure to failure without loss of enthusiasm”

> “And when that first patient responded, it all exploded in my brain. It does work. This can work.” – Steve Rosenberg

**How support from Steve’s family made his important work possible**

- Steve’s wife Alice was unbelievably supportive

> “There were probably, and I’m not exaggerating, 40 days in the first 40 years of my work here that I was in town, not traveling, that I was not in this hospital. I would come in every day, of course, I would come in every Saturday, Sunday; I would come in to go over research with some of the fellows, you probably remember that, or see some patients.” – Steve Rosenberg

- There are a lot of wives that would not have tolerated that but Alice took care of the burdens we commonly face as part of daily living

> “ I doubt I could’ve done it without that kind of support.” – Steve Rosenberg

##

## The immunogenic nature of certain cancers and the role of mutations in cancer [1:03:45]

**“Patient 67”**

- - This patient illuminated how melanoma and renal cancer are particularly immunogenic relative to the host of other epithelial cancers that were less reactive
  - Initially this was unknown, but 35 years later Steve thinks he understands what is different about melanoma
    - Saw responses to IL-2 in patients with melanoma and kidney cancer, but no other diseases
    - Learned the hard way by treating over 600 patients with IL-2 at the [Clinical Center](https://clinicalcenter.nih.gov/)

- *The success of treating melanoma with IL-2 had to do with the vast number of mutations in this type of cancer, about 400 mutations per tumor*

- - The immune system recognizes the products of mutations
  - Melanoma is induced by a [carcinogen](https://en.wikipedia.org/wiki/Carcinogen), UV light
    - Peter asks about [Lynch Syndrome](https://www.ncbi.nlm.nih.gov/books/NBK1211/) since patients with this disease would typically have many mutations as well
    - Steven explains they didn’t understand mutations were involved at the time
    - Steven doesn’t remember ever treating a patient with Lynch Syndrome

> “There’s no such thing as a standard cancer, right?” – Peter Attia

**What is the median number of mutations found in common cancers?**

- 80% of common cancers have between 60 to 70 and 150 mutations; the median would probably be around 110 but this would vary from cancer type to cancer type  [1:06:15]
- How many would be [driver mutations](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/driver-mutation)?
  - Mutations of [proto-oncogenes](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/proto-oncogene) or [tumor suppressor genes](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/tumor-suppressor-gene)?

> “about six years ago, we described an assay that would enable us to actually identify the exact molecular nature of these antigens that are recognized by T cells”  – Steve Rosenberg

- [This screening method](https://clincancerres.aacrjournals.org/content/20/13/3401.short) identified the antigen specificity of  tumor infiltrating lymphocytes ([TILs](https://en.wikipedia.org/wiki/Tumor-infiltrating_lymphocytes))
  - These tumor reactive T cells which bind specific antigens can then be purified, grown in culture, and used for adoptive cell therapy
- Some of these antigens that are recognized by T cells are recognizing the proteins that derived from driver mutations, which caused the cancer
  - Half of all cancers have a mutation in [p53](https://en.wikipedia.org/wiki/P53) but only about 2% of patients develop immune reactions against it
  - About 90% of pancreatic cancers have mutation of [KRAS](https://en.wikipedia.org/wiki/KRAS) as a driver mutation
  - In breast cancer mutation of  [PIK3CA](https://en.wikipedia.org/wiki/P110%CE%B1) acts as a driver mutation
  - In melanoma maybe mutation of [BRAF](https://en.wikipedia.org/wiki/BRAF_(gene)) acts as a driver mutation
  - The incidence of driver mutations as a cause of cancer is in the low single digits

> “But what’s stunning to me about oncology in the biology of cancer and that is how few of these shared cancer mutations exist.” – Steve Rosenberg

- - One mutation itself usually doesn’t cause cancer, it’s the action of many mutations in concert that causes cancer

- *Recently, Steve’s work has shown that targeting random somatic mutations, none of which had a driver function, could mediate complete, durable regression of breast cancer*

- - Published in [Nature Medicine](https://pubmed.ncbi.nlm.nih.gov/29867227/)

**What makes a mutation immunogenic?**

- - *Why are mutations in p53 or KRAS not immunogenic?*
  - A mutation is a change in DNA, this gives rise to a protein that is also changed
    - A protein is a string of amino acids
    - An altered protein, caused by a [nonsynonymous mutation](https://en.wikipedia.org/wiki/Nonsynonymous_substitution) is something not normal in the body and can be recognized by the immune system
  - Abnormal proteins are recognized by the immune system when they are broken down into small peptides (strings of amino acids) of which at least one happens to fit on the patient’s own [HLA molecule](https://en.wikipedia.org/wiki/Human_leukocyte_antigen)
  - Only in the past 5-6 years it has become known what cancer antigens are
    - Mutations lead to the production of altered proteins
    - These are broken down and presented on the surface of a patient’s tumor cells or [antigen presenting cells](https://en.wikipedia.org/wiki/Antigen-presenting_cell) via HLA molecules

- *Only 0.5-2% of mutations fit into a patient’s HLA molecule and therefore are immunogenic*

> “And the most stunning finding of recent years in my view in this field is that virtually every patient recognizes a unique antigen” – Steven Rosenberg

- - Steve is currently writing a paper now on 195 consecutive patients where they identified the the exact antigenic nature of what the T cell can recognize
    - 363 individual antigens were recognized in these 195 patients

- *No two patients shared the exact same antigen*

- - - One exception was 2 patients who had a KRAS mutation recognized on a very rare class I molecule CW802 HLA molecule
  - 80% of patients recognize at least 1 antigen from their tumor; these are different antigens for each patient
  - Driver mutations in p53 or otherwise are usually not recognized
- In 1985 Steve knew a cancer antigen existed; now after decades of research he can identify it
  - Cancers contain multiple mutations; this gives rise to antigens
  - The key is to figure out how to target these antigens
  - The possibility of developing a broadly applicable treatment exists but targeting mutations is highly individualized
- It is not yet known how to direct the immune system to the most minor antigens
- [Checkpoint](https://en.wikipedia.org/wiki/Immune_checkpoint) modulators have virtually no impact on the majority of solid epithelial cancers
- Stimulating an immune reaction to a cancer has to be individualized to the antigens of that cancer
  - Antigens in one patient are not present in other patients with the same cancer
  - This makes immunotherapies complex to develop

## The improbable story of how CAR T cell therapy was developed [1:16:30]

**The story of diffuse B-cell lymphomas that ultimately led to the biotech company KITE is fascinating**

- This is the story of how CAR T cell therapy was developed
- T cells have receptors ([TCR](https://en.wikipedia.org/wiki/T-cell_receptor)) that recognize antigens on the surface of a cancer cell
  - The T cell receptor is composed of alpha and beta chains
  - It binds the tiny peptides put on the surface of cancer cells on MHC class I molecules
- 10-12 years ago [Gideon Gross](https://www.migal.org.il/en/Gideon-Gross) at the [Weitzman Institute](https://weitzmaninstitute.org/) created an alternate way for a lymphocyte to recognize an antigen using [antibodies](https://en.wikipedia.org/wiki/Antibody)
  - Publication in [PNAS](https://www.pnas.org/content/86/24/10024?ijkey=5c06b90a1deef286030400f978398fc0d4c4505e&keytype2=tf_ipsecsha) of the production and function of T cells containing  immunoglobulin-T-cell receptors; this enables the T cell recognize an antigen with antibody specificity
  - Publication in [The Journal of Immunology](https://www.jimmunol.org/content/193/11/5733.long) a comparison of function between T cells with native T cell receptor and T cells with a chimeric antibody receptor
- Antibodies will recognize a 3-D structure on the surface of any cell, not a processed peptide displayed on MHC class I; “the antibody like a lock and a key will latch on to that antigen and recognize it”
- [Monoclonal antibodies](https://en.wikipedia.org/wiki/Monoclonal_antibody) are generated in the laboratory to all recognize a single antigen
  - The general structure of an antibody is shown below; it is made of 4 polypeptide chains and is shaped like a Y
  - The antigen-binding site (shown in the next two figures) is at the top of the Y and is a cleft between a variable light and variable heavy chain, VL and VH, respectively

![](https://peterattiamd.com/wp-content/uploads/2021/09/f1-rosenberg-887x1024.png)

**Figure 1. General structure of an antibody.**  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Antibody)

![](https://peterattiamd.com/wp-content/uploads/2021/09/f2-rosenberg-1024x877.png)

**Figure 2. Variable regions (V****L** **and V****H** **of an antibody are what bind to one antigen.** Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Antibody)

- - Chimeric T cells ([CAR-T cells](https://en.wikipedia.org/wiki/Chimeric_antigen_receptor_T_cell)) were created in which antibody recognition domains were added; several iterations are shown in the diagram below
    - The chimeric antigen receptor is part normal receptor (TCR, T cell receptor) ant part antibody; it utilizes the antigen-binding domains of the antibody
    - This allows the T cell (lymphocyte) to respond to what the antibody binds

- *The specificity of the CAR-T cell is determined by the antigen-binding domains of the antibody incorporated into the receptor (VH and VL)*

*![](https://peterattiamd.com/wp-content/uploads/2021/09/f3-rosenberg-1024x726.png)*

**Figure 3.  CAR-T cell receptors combine a TCR with the antigen-binding domains of a monoclonal antibody (VH and VL).** Image credit: [Considerations for the clinical application of chimeric antigen receptor (CAR) T Cells: observations from a recombinant DNA advisory committee (RAC) symposium June 15, 2010](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4128091/) | *Cancer Research*  (Hildegund C.J. Ertl *et al.* 2011)

- - There are very few molecules on the cell surface unique to a cancer and CAR-T cells can be designed to recognize them

- *The immune system will destroy a normal cell or a cancer cell; targeting antigens unique to cancer cells is essential*

- - One target antigen for [lymphomas](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/lymphoma) and [leukemias](https://www.cancer.gov/publications/dictionaries/cancer-terms/search/leukemia/?searchMode=Begins) is [CD19](https://en.wikipedia.org/wiki/CD19)
    - These cancers arise from aberrant B cells; they continue to express CD19
    - The function of CD19 is not understood
  - Worked to get CAR T cells to attack cancer cells

- [*Generation of CAR T cells that recognize CD19*](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6322669/) *(shown in the figure below) eliminated lymphomas, leukemias, and all normal B cells*

- - - One can live without B cells because antibodies can be provided with infusions
  - This work resulted in the first cell and gene therapy ever approved by the [FDA](https://www.fda.gov/news-events/press-announcements/fda-approval-brings-first-gene-therapy-united-states)

![](https://peterattiamd.com/wp-content/uploads/2021/09/f4-rosenberg-1024x684.png)

**Figure 4.  CAR-T cell that recognize CD19.**  Image credit:  [Treating B-cell cancer with T cells expressing anti-CD19 chimeric antigen receptors](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6322669/) | *Nature Reviews Clinical Oncology* (James N. Kochenderfer and Steven A. Rosenberg 2013)

- - The first person was treated with CAR-T cells in 2009
    - His lymphoma was spread throughout his chest
    - He had been treated with 4 different chemotherapy regimens
    - Treating him with CAR-R cells that recognize CD19 eliminated his tumor

- *12 years later he is completely disease free*

- - 7-8 more patients were treated in the next 2 years; all had complete disappearance of their lymphoma
    - [Diffuse, large B-cell lymphoma](https://en.wikipedia.org/wiki/Diffuse_large_B-cell_lymphoma) is the most aggressive and lethal form of lymphomas that people develop

- *Complete regressions were observed*

- - - Patients also lost their B cells; one can live without B cells
    - [Published](https://pubmed.ncbi.nlm.nih.gov/33021872/) a follow-up of anti-CD19 CAR T cell therapy of 43 patients

- *Complete remission lasting 3 years or more occurred in 51% of patients*

- - - - Some remissions are 9 years and ongoing
      - Adverse events are rare
  - In 2011 [Carl June](https://en.wikipedia.org/wiki/Carl_H._June) at the University of Pennsylvania used CD19 CAR T cells to treat leukemia patients
  - Contacted by a former fellow who wanted to commercialize CAR T cells; this led to the development of the pharmaceutical company [Kite](https://www.kitepharma.com/science-medicine/cell-therapy-technology)
    - In 2017, 5 years after Steve began working with Kite, Kite was sold to [Gilead](https://www.gilead.com/) for $11.9 billion

- *CAR T cell therapy is now available thanks to* [*Kite*](https://www.kitepharma.com/science-medicine/cell-therapy-technology) *and* [*Novartis*](https://www.hcp.novartis.com/products/kymriah/acute-lymphoblastic-leukemia-children/mechanism-of-action/) *as an effective treatment of B-cell lymphomas and leukemias*

- - It’s incredible this therapy developed so rapidly, in about 5 years

**Why CAR T cells cannot be used to treat solid cancers**

- - Currently CAR T cells cannot be used to treat solid cancers ([Non-hematologic cancers](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/nonhematologic-cancer))
  - A molecule on the cell surface unique to the cancer is needed for CAR T cell therapy
  - CAR T cells are exquisitely sensitive; patients died when molecules from normal cells were targeted

- *A monoclonal antibody unique to molecules on the surface of cancer cells, not found on normal cells is needed to develop CAR T cell therapy (to make a chimeric T cell receptor)*

- - Prostate specific molecule ([PSMA](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/psma)) was thought to be unique to the prostate, but it is not and resulted in patient deaths

## The discovery of tumor infiltrating lymphocytes (TIL) and engineering of T cells to recognize specific antigens [1:28:00]

- *T cells that infiltrate the tumor are called* [*TILs*](https://en.wikipedia.org/wiki/Tumor-infiltrating_lymphocytes)

- - Looked in melanoma patients for T cells that could recognize the tumor and grew these cells to large numbers *in vitro* by culturing them with IL-2
    - Treating patients with IL-2 alone yielded a response rate of 15%

- *Treating patients with these TILs grown in vitro in IL-2 yielded a response rate of 30-35%*

- - - - TILs were isolated from  melanoma patients, grown *in vitro* in the presence of IL-2 and given back to melanoma patients
      - The improvement seemed to be short-lived
      - Lymphocytes were the cause of these regressions
      - Now the question is, can these lymphocytes be modified to be more potent
  - Teamed up with scientists at the NIH, [French Anderson](https://en.wikipedia.org/wiki/William_French_Anderson) and [Michael Blaese](https://www.researchgate.net/profile/Ro-Blaese), to modify TILs
    - No one had introduced a gene into human cells yet
    - These scientists were trying to develop gene therapy to cure adenosine deaminase deficiency ([ADA-SCID](https://www.ncbi.nlm.nih.gov/books/NBK1483/)), a lethal disease in young children

- *Proof of principle experiment to see if introducing genetically modified cells to patients is safe; introduce bacterial gene neomycin into a patient’s normal lymphocytes*

- - Administer these modified cells and track them via the introduced neomycin gene
- Approval of these experiments was difficult
  - [Recombinant DNA Advisory Committee](https://osp.od.nih.gov/biotechnology/recombinant-dna-advisory-committee/) (RAC), the first vote was 13 to 4 to allow the experiments
  - Director of the NIH at the time, [James Wyngaarden](https://www.nih.gov/about-nih/what-we-do/nih-almanac/james-b-wyngaarden-md), insisted on unanimous consent; this was finally achieved
  - Permission for the clinical trial was given and biotechnology activists filed lawsuits against the NIH saying we shouldn’t be tampering with the human genome

> “It was immoral, it was ungodly, but we finally got permission to do it and inserted these lymphocytes that were genetically modified with this bacterial gene that did enable us to track the cells inside the body. “ – Steve Rosenberg

[1:32:42]

- - The safety and feasibility of using gene therapy to add genes to T cells was demonstrated by adding the bacterial gene for neomycin resistance
    - Published in the [New England Journal of Medicine](https://www.nejm.org/doi/full/10.1056/NEJM199008303230904) in 1990
    - 5 patients received genetically engineered TILs (tumor infiltrating lymphocytes)
    - This allowed these modified T cells to be tracked in patients

- *The safety of genetically engineered T cells was accessed and paved the way for modifying T cells in ways to improve their ability to kill cancer cells*

- - Added the gene for IL-2  to T cells, but it didn’t improve the treatment because there was no regulation on its expression
  - This was the beginning of genetically modified T cells that led to insertion of new receptors that could recognize molecules on lymphomas and leukemias, the development of CAR T cells

- *Removing regulatory T cells before administration of CAR T cells increased the response from about 25% to 55% in melanoma patients*

- - - Remission was complete in these patients
  - First [publication of T cells developed to target specific mutations](https://clincancerres.aacrjournals.org/content/20/2/331.long) was in 2014
    - The patient had bile duct cancer ([cholangiocarcinoma](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/cholangiocarcinoma)) widespread in lungs and liver
    - Administration of bulk TILs did not mork
    - Giving natural TIL that recognized her mutation resulted in remission
      - Not genetically modified CAR T cells
      - These natural TIL were selected for mutation reactivity
      - Given after the patient’s natural immune system was temporarily eliminated
    - All liver and lung disease was eradicated

- *She is still disease free 8 years later*

- - Have since published on T cells that recognize mutations and cause regression of:
    - Cervical cancer induced by human papilloma virus
    - Colon cancer; that patient recognized KRAS
    - Breast cancer; that patient recognized 4, random somatic mutations

- *Working now to more efficiently target the products of unique mutations*

> “Sort of ironic that the Achilles’ heel of the cancer is going to be the very abnormalities that caused it in the first place.” – Steve Rosenberg

- Now in 2021 we are working to take advantage of all this new biologic information about the role of mutations and T cells that target them
  - Working to genetically modify cells in large numbers using [retroviruses](https://en.wikipedia.org/wiki/Vectors_in_gene_therapy#Retroviruses)
  - Working to develop more effective immunotherapies

## Steve’s experience treating President Ronald Reagan’s colon cancer [1:36:00]

- - In 1985 Steve was asked to be part of the team that operated on [President Ronald Reagan’s](https://en.wikipedia.org/wiki/Ronald_Reagan) colon cancer
  - Peter asks “Why is it that you were a part of the team that would take care of the president? Why is it that the Chair of the National Cancer Institute would be involved in the president’s care? Is that something that’s mandated at the federal level?”
  - The chief of surgery at Bethesda Naval HOspital was an expert in vascular surgery, not oncology; an expert in oncology was needed
  - Steve got a call on a Friday evening to come to Bethesda Naval Hospital to help with a patient; it turned out to be President Regan
  - He was called simply because he was across the street and had previously gotten security clearance to take care of high government officials
  - Before the post-surgery press conference, Steve’s explanation that the president has colorectal cancer got him into all sorts of trouble
    - [Nancy Reagan](https://en.wikipedia.org/wiki/Nancy_Reagan) didn’t want the cancer word to be used
      - She didn’t want foreign officials to ignore him because he has cancer
  - The press conference went on and the surgeon read the pathology report, it’s an [adenocarcinoma](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/adenocarcinoma) in the distal portion of the colon
    - Nobody understood what he said
  - Steve was asked to explain this, so he said “The president has cancer.”
    - In response to this, the Director of the National Cancer Institute ([NCI](https://www.cancer.gov/)) at the time, [Vine DeVita](https://medicine.yale.edu/profile/vincent_devita/) (who later became the chief at  Memorial Sloan Kettering) took Steve off a short list for the next director of NCI

- *He was very upset that Steve used the word “has cancer” instead of “had cancer”*

- The president recovered and never had a recurrence of his colon cancer

## Why Steve has turned down many tempting job offers to focus on his research at the National Cancer Institute [1:41:00]

- Steve has remained in the same job for 47 years
- He is so mission focused, but 3 opportunities tempted him
- One at Georgetown because of a surgeon he collaborated with
- One as Chief of Surgery at Hopkins, he and John Cameron were on the short list
  - Steve knew he would not leave the NIH and did not go back for the 3rd interview
- One at the Brigham where his friend Marie Brennan was
  - Steve didn’t want an administrative job
  - He wanted to stay in the lab to mentor fellows, to make progress

> “I didn’t want to guide other people making it. I wanted to be there. I wanted to be doing it, I want to be guiding it, because I thought I could do it well.” – Steve Rosenberg

- - Steve refused all these offers and never looked at another job
    - He turned down opportunities to advance in the hierarchy at NCI because he wanted to remain where he was

- *He wanted to pursue the kinds of research he thought was needed*

- - The environment of NCI offered enormous resources to do research

## The role of checkpoint inhibitors in cancer therapy and the promise of adoptive cell therapy [1:43:00]

**Checkpoint inhibitors suppress T cell activity**

- [Checkpoint inhibitors](https://en.wikipedia.org/wiki/Cancer_immunotherapy#Immune_checkpoint_blockade) include targeting [CTLA-4](https://en.wikipedia.org/wiki/CTLA-4) and [PD-1](https://en.wikipedia.org/wiki/Programmed_cell_death_protein_1); these are called anti-CTLA-4 and anti-PD-1
- [James Allison](https://www.nobelprize.org/prizes/medicine/2018/allison/facts/) won the [Nobel Prize in physiology or medicine in 2018](https://www.nobelprize.org/prizes/medicine/2018/press-release/) for his discovery of these checkpoint inhibitors

![](https://peterattiamd.com/wp-content/uploads/2021/09/f5-rosenberg-1024x728.png)

**Figure 5. Checkpoint inhibitors block CTLA-4 and PD-1 thereby removing a signal that inhibits T cell activity.** Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Cancer_immunotherapy#Immune_checkpoint_blockade)

- - CTLA-4 and PD-1 put the brakes on inflammatory T cell activity
  - There are inhibitors in every physiologic system and one way this can occur is with molecules on the cell surface that can engage with receptors
  - CTLA-4 and PD-1 are often expressed by cancer cells and function to put the brakes on T cell activity

- *Releasing these brakes with anti-CTLA-4 and anti-PD-1 antibodies allows the T cells to be very active and attack certain cancers*

- - Melanoma is a common cancer to be attacked because it has so many mutations, each providing antigens for the T cell to recognize
  - The ‘brakes’ CTLA-4 and PD-1 can be blocked with antibodies; these are shown in the diagram above as green Y-shaped molecules

> “It was a startling discovery that simply attacking a single molecule on the cell surface could take the brakes off a lymphocyte and let it attack cancer.” – Steve Rosenberg

- - Cancers that have large numbers of mutations, often due to mutations in mismatch repair genes are: melanoma, kidney cancer, [Lynch syndrome](https://www.ncbi.nlm.nih.gov/books/NBK1211/), and microsatellite unstable tumors ([MSI](https://www.cancer.gov/publications/dictionaries/cancer-terms/search/microsatellite%20instability/?searchMode=Begins))
    - These cancers respond well to checkpoint inhibitor treatment
  - Common epithelial cancers respond poorly to checkpoint inhibitor treatment
    - These cancers result in 90% of deaths in patients

- *The majority of cancer patients do not respond do simply taking off the brakes CTLA-4 and PD-1 exert on T cells*

- - - Hopefully combinations of treatments using checkpoint modulators will be more effective in the future
  - Success of checkpoint inhibitors in some cancer patients was still a major step forward
    - It is easy to apply because it only requires injection of an antibody

- *Treatment of cancer with CAR-T cells targeting CD19 on B cells (to eradicate lymphoma), checkpoint modulators that target CTLA-4 and PD-1 have durable effects on cancers with a high number of mutations, in some cases IL-2 is effective; these are the low hanging fruit of immunotherapy which took 50 years of work to develop*

- These low hanging fruit are pillars of immunotherapy that will provide a path forward

**The promise of adoptive cell therapy**

- - Consider the half a million patients with solid organ metastatic cancer—80% have antigens unique to them but not occurring in high enough frequency to respond to a checkpoint inhibitor alone
  - Can patients be cured with adoptive cell therapy in a customized format?
    - Steve’s intuition is yes
    - Adoptive cell therapies are outlined in the figure below
      - They can utilize T cells isolated from the patients (TIL’s) and grown in culture
      - Or they could utilize gene modified T cells engineered to recognize specific cancer antigens

- *Adoptive cell therapy can work for multiple tumor types such as liver tumors, bile duct cancers breast cancer, colon cancer, and cervical cancer*

*![](https://peterattiamd.com/wp-content/uploads/2021/09/f6-rosenberg-1024x824.png)*

**Figure 6. Adoptive cell therapy can use TILs or T cells genetically engineered to recognize cancer-specific antigens.**  Image credit: [Adoptive Cell Transfer for Patients With Metastatic Melanoma: The Potential and Promise of Cancer Immunotherapy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6322197/) *|* *Cancer Control* (Giao Q. Phan and Steven A. Rosenberg 2013)

> “Before IL-2, we never knew that immunotherapy would work. Once it did, we knew the immune system could do it. Now we know that antigens recognized by T-cells are present on 80% of the common cancers. And if you can develop unique reactivities (lymphocytes), select reactivities against them and administer them, they can cause those regressions.” – Steve Rosenberg

- Now that we know the exact T-cell receptor sequences (it’s been cloned and isolated) targeting cancer antigens is almost an engineering problem
  - Libraries of receptors have been isolated that bind p53 and KRAS
  - These receptors can be used to turn a normal lymphocyte (T cell) into one that can attack cancer

> “We know it can work. And to tell you the truth, I finally feel like I have the hang of this kind of research, and that by sufficient work, creativity, this is going to be a problem that is solvable.” – Steve Rosenberg

- *The focus of his work is now how to utilize T cell reactivity to the unique mutations in solid epithelial cancers and get them to respond to immunotherapy*

- - These are the cancers that cause 90% of all cancer deaths

**Optimism for using immunotherapy to cure all cancers**

- - Peter asks “Of all the eureka moments in your career, of which you’ve had several, this one seems to be the most promising…do you see it that way?”
    - The recognition that virtually every solid tumor has novel peptides that can be recognized by a patient’s own immune system
  - Yes, many individual cases have been published but much of what was discussed is not
    - The first 40+ colorectal cancers showing each has unique mutations is [published](https://cancerdiscovery.aacrjournals.org/content/9/8/1022)
    - None of the breast cancer work is published, but 195 cases studied show unique mutations in each cancer

- *It’s a recent advancement to realize that these unique mutations in cancer cells are the antigens; T cells can recognize them thereby allowing the immune system to attack cancer cells*

- - Science works by incremental advances
  - Steve says “*I have every confidence that scientists around the world will figure out ways to make it work*”

## The human side of cancer and the important lessons Peter learned from working with Steve [1:52:15]

- Peter recalls “That reminds me of some of the important lessons that those of us who’ve been privileged enough to work alongside you have learned along the way. You never pounded the table to make these lessons, but it was abundantly clear”

**One lesson is no secrecy, data is shared before it is published**

- Secrecy is an ongoing problem, the need to protect intellectual property is holding back progress
- There is a need to bring lawyers and doctors together to figure out how to prevent this secrecy from being part of modern science

> “We’re trying to save the life of another human being. And I think when you take care of cancer patients, it puts a lot of things in perspective. And the idea of having a policy or a rule that you live by that inhibits your ability to help people who could potentially be helped is abhorrent to me.” – Steve Rosenberg

- - He has worked to try and change this, written a [correspondence to The New England Journal of Medicine](https://www.nejm.org/doi/full/10.1056/NEJM199607113350215) about the problem of secrecy, but things haven’t changed [1:54:30]

- *The first thing fellows in his lab hear is “anything you know, you share, any experimental result”*

> “Our goal is to help people that are involved in the suffering of cancer. There’s no excuse for not doing everything you can to try to help, and that means sharing what you know.” – Steve Rosenberg

**The second lesson is that one never retreats from the bedside**

- Peter lived this lesson too; when he was in medical school, he lived in the clinical ward and only went home on Sundays to get new clothes
- In oncology, 80-90% of people that walk in the door die; it’s hard to imagine
  - Patients that come to the NIH have gone through every standard therapy
  - Patients coming here our out of options
  - These patients have the most advanced, aggressive cancers imaginable
  - The patients probably wouldn’t be expected to live more than 6 months
  - Saving 20% of them is remarkable, but 80% still die
- Peter remembers the way Steve took care of those 80% and fought the urge to retreat from them because of failure to help them more

> “I have enormous respect for practicing oncologists who face this every day in their practice.” – Steve Rosenberg

- - Its difficult for oncologists
    - Some treatments don’t work but actually cause some harm
    - This is what happens when new therapies are being developed
    - They have limited tools but that’s all one has, day in and day out; it’s very trying
  - Steve always had the feeling that he was working hard to improve the situation and that kept him going, the idea of repairing the holocaust of what cancer is

- *Working toward better treatments gives hope to the difficult job oncologists face*

- Peter recalls how haunting it is to lose patients
  - A beautiful, newlywed girl, 25 years old with metastatic melanoma
    - She was married for only 3 months and she died
  - A single guy with metastatic melanoma
    - Tragically, everyone abandoned him at the end of his life
    - He was maybe 26

> “I feel like cancer takes families that are close and brings them closer, and takes families that are fractured and fractures them more.” – Peter Attia

- The motivation for cancer research is huge
- There is a depression that comes with taking care of patients and the death toll; not everyone can do that and it’s hard to find a balance
- Steve agrees, one thinks about the tragedies more than successes
  - It gets worse because some patients are killed by getting the wrong treatment or not understanding some of the underlying biology; that’s the hardest to deal with
- Being a doctor is an unbelievable privilege to have the opportunity to help people with skills one has developed

> “One of the first lines of the [prayer of Maimonides](https://en.wikipedia.org/wiki/Oath_of_Maimonides) goes, you have been given the wisdom to alleviate the suffering of your brothers” – Steve Rosenberg

- There is the satisfaction of trying hard, and spend a lot of time learning how to help people
  - There are though too, a lot of sleepless nights involved in that process
  - Despite being 81 Steve will continue research
- Peter reflects on the impact Steve has had on his life; the only picture of himself in his office is with Steve, taken about 16 years ago

> “I think the list of people who have had a greater impact on the course of my life than you is somewhere between zero and Epsilon. It’s a decidedly small list. So I feel forever in your debt.” – Peter Attia

§

## Selected Links / Related Material

**Steve’s book on cancer**: [The Transformed Cell](https://www.amazon.com/Transformed-Cell-Stephen-Rosenberg/dp/0399137491) | Steven A. Rosenberg and John M. Barry (1992) | [2:45, 13:15]

**Discovery of T cell growth factor interleukin 2 (IL-2)**:

- [Selective in vitro growth of T lymphocytes from normal human bone marrows](https://pubmed.ncbi.nlm.nih.gov/181845/) | *Science* (D A Morgan, F W Ruscetti, and R Gallo 1976) | [31:15]
- [Human T-cell growth factor: parameters for production.](https://pubmed.ncbi.nlm.nih.gov/6972470/) | *Journal of Supramolecular Structure* (F W Ruscetti, J W Mier, and R C Gallo 1980)

**First publication of LAK cells (lymphokine activated killer cells, leukocytes grown in interleukin 2 that destroy cancer cells**:  [Lymphokine-activated killer cells: lysis of fresh syngeneic natural killer-resistant murine tumor cells by lymphocytes cultured in interleukin2](https://cancerres.aacrjournals.org/content/canres/44/5/1946.full.pdf) | *Cancer Research* (Maury Rosenstein *et al.* 1984) | [53:00]

**Identification of the antigen specificity of tumor infiltrating lymphocytes (TILs)**:

- [Mining Exomic Sequencing Data to Identify Mutated Antigens Recognized by Adoptively Transferred Tumor-reactive T cells](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3757932/) | *Nature Medicine* (Paul F. Robbins *et al.* 2013)
- [Efficient Identification of Mutated Cancer Antigens Recognized by T Cells Associated with Durable Tumor Regressions](https://clincancerres.aacrjournals.org/content/20/13/3401.short) | *Clinical Cancer Research* (Yong-Chen Lu, *et al.* 2014) | [1:07:15]

**Targeting random somatic mutations in breast cancer mediates complete, durable regression**: [Immune recognition of somatic mutations leading to complete durable regression in metastatic breast cancer](https://pubmed.ncbi.nlm.nih.gov/29867227/) | *Nature Medicine* (Nikolaos Zacharakis *et al.* 2018) | [1:09:00]

**Engineering a T lymphocyte to recognize an antigen using an antibody:**

- [Expression of immunoglobulin-T-cell receptor chimeric molecules as functional receptors with antibody-type specificity](https://www.pnas.org/content/86/24/10024?ijkey=5c06b90a1deef286030400f978398fc0d4c4505e&keytype2=tf_ipsecsha) | *PNAS* (G Gross, T Waks, and Z Eshhar 1989) | [1:17:15]

- [Functional Comparison of Engineered T Cells Carrying a Native TCR versus TCR-like Antibody–Based Chimeric Antigen Receptors Indicates Affinity/Avidity Thresholds](https://www.jimmunol.org/content/193/11/5733.long) | *The Journal of Immunology* (Ravit Oren *et al.* 2014) | [1:17:30]

**Efficacy of using CAR T cells specific for CD19 to treat lymphoma**: [Long-Term Follow-Up of Anti-CD19 Chimeric Antigen Receptor T-Cell Therapy](https://pubmed.ncbi.nlm.nih.gov/33021872/) | *Journal of Clinical Oncology* (Kathryn M Cappell *er al.* 2020) | [1:21:30]

**Proof of principle experiment that engineered T cells are safe and feasible:** [Gene Transfer into Humans — Immunotherapy of Patients with Advanced Melanoma, Using Tumor-Infiltrating Lymphocytes Modified by Retroviral Gene Transduction](https://www.nejm.org/doi/10.1056/NEJM199008303230904?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200www.ncbi.nlm.nih.gov) | *The New England Journal of Medicine* (Steven A. Rosenberg *et al.* 1990) | 1:32:30

**First development of T cells that target mutations in cancer:** [Tumor-Reactive CD8+ T Cells in Metastatic Gastrointestinal Cancer Refractory to Chemotherapy](https://clincancerres.aacrjournals.org/content/20/2/331.long) | *Clinical Cancer Research* (Simon Turcotte *et al.* 2014) | [1:34:00]

**Colorectal cancers each contain mutations that are all unique:** [Unique Neoantigens Arise from Somatic Mutations in Patients with Gastrointestinal Cancers](https://cancerdiscovery.aacrjournals.org/content/9/8/1022) | *Cancer Discovery* (Maria R. Parkhurst *et al.* 2019) | [1:51:15]

**Support of open-access data sharing:** [Secrecy in Research](https://www.nejm.org/doi/full/10.1056/NEJM199607113350215) | *New England Journal of Medicine* (Steven Rosenberg 1996) | [1:54:30]

**Editorial about his life’s work developing cancer immunotherapies:** [Immersion in the search for effective cancer immunotherapies](https://molmed.biomedcentral.com/articles/10.1186/s10020-021-00321-3#Sec8) | *Molecular Medicine* (Steven A. Rosenberg 2021)

**Review of cancer research**: [Two Hundred Years of Cancer Research](https://www.nejm.org/doi/10.1056/NEJMra1204479?url_ver=Z39.88-2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200www.ncbi.nlm.nih.gov) | *The New England Journal of Medicine* (Vincent T. DeVita and Steven A. Rosenberg 2012)

**Gene therapy began with studies of gene altered T lymphocytes in patients with malignant melanoma:** [Gene therapy turns 30 years old](https://irp.nih.gov/catalyst/v27i3/gene-therapy-turns-30-years-old) | *The NIH Catalyst: a Publication about NIH Intramural Research* (Christopher Wanjek 2019)

**The development of CAR T cells:** [Treating Cancer with Genetically Engineered T Cells](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3193849/) | *Trends in Biotechnology* (Tristen S. Park, Steven A. Rosenberg, and Richard A. Morgan 2011)

**Evolution of CAR T cells and concerns the Recombinant DNA Advisory Committee discussed**: [Considerations for the Clinical Application of Chimeric Antigen Receptor (CAR) T Cells: Observations from a Recombinant DNA Advisory Committee (RAC) Symposium June 15, 2010](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4128091/) | *Cancer Research* (Hildegund C.J. Ertl *et al.* 2011)

**CAR T cells that recognize CD19 mediate remission in advanced B cell lymphoma:** [Treating B-cell cancer with T cells expressing anti-CD19 chimeric antigen receptors](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6322669/) | *Nature Reviews Clinical Oncology* (James N. Kochenderfer and Steven A. Rosenberg 2013)

**Comparison of TIL’s and gene-modified T cells to treat metastatic melanoma**: [Adoptive Cell Transfer for Patients With Metastatic Melanoma: The Potential and Promise of Cancer Immunotherapy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6322197/) | *Cancer Control* (Giao Q. Phan and Steven A. Rosenberg 2013)

**Adoptive transfer of CD4+ TIL mediates cancer regression**: [Cancer Immunotherapy Based on Mutation-Specific CD4+ T Cells in a Patient with Epithelial Cancer](https://www.science.org/doi/abs/10.1126/science.1251102) | *Science* (Eric Tran *et al.* 2014)

**The history of using CAR T cells to treat cancer**: [CCR 20th Anniversary Commentary: Chimeric Antigen Receptors—From Model T to the Tesla](https://clincancerres.aacrjournals.org/content/21/14/3099) | *Clinical Cancer Research* (Patrick Hwu 2015)

**Effective immunotherapy using adoptive transfer of CD8+ TIL**: [T-Cell Transfer Therapy Targeting Mutant KRAS in Cancer](https://www.nejm.org/doi/full/10.1056/nejmoa1609279) | *The New England Journal of Medicine* (Eric Tran *et al.* 2016)

**The future of cancer treatment using adoptive transfer of receptor-engineered T cells**: [Prospects for gene-engineered T cell immunotherapy for solid cancers](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6295670/) | *Nature Medicine* (Christopher A Klebanoff, Steven A Rosenberg, and Nicholas P Restifo 2016)

**Targeting random somatic mutations is the future of cancer immunotherapy**: [‘Final common pathway’ of human cancer immunotherapy: targeting random somatic mutations](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6295671/) | *Nature Immunology* (Eric Tran, Paul F Robbins, and Steven A Rosenberg 2017)

**Review of CAR T cell cancer immunotherapy**: [A brief history of CAR-T cells: from](https://journals.viamedica.pl/acta_haematologica_polonica/article/view/75176) [laboratory to the bedside](https://journals.viamedica.pl/acta_haematologica_polonica/article/view/75176) | *Acta Haematologica Polonica* (Jan Styczyński 2020)

§

## People Mentioned

- [Franny Moore](https://en.wikipedia.org/wiki/Francis_Daniels_Moore) [10:40, 12:15, 22:30]
- [John Barry](https://en.wikipedia.org/wiki/John_M._Barry) [2:00, 13:00]
- [Brownie Wheeler](https://americansurgical.org/transactions/Fellows/Memoirs/HewittBrownellWheeler.cgi) [16:30]
- [Wilhelm Röntgen](https://en.wikipedia.org/wiki/Wilhelm_R%C3%B6ntgen) [27:45]
- [Davis Sachs](https://en.wikipedia.org/wiki/David_Sachs) [29:30]
- [Thomas Starzl](https://en.wikipedia.org/wiki/Thomas_Starzl) [56:00]
- [Abraham Lincoln](https://en.wikipedia.org/wiki/Abraham_Lincoln) [1:00:15]
- [Carl June](https://en.wikipedia.org/wiki/Carl_H._June) [1:22:15]
- [French Anderson](https://en.wikipedia.org/wiki/William_French_Anderson) [1:30:45]
- [Michael Blaese](https://www.researchgate.net/profile/Ro-Blaese) [1:30:45]
- [James Wyngaarden](https://www.nih.gov/about-nih/what-we-do/nih-almanac/james-b-wyngaarden-md) [1:32:15]
- [President Ronald Reagan](https://en.wikipedia.org/wiki/Ronald_Reagan) [1:36:00]
- [James Allison](https://www.nobelprize.org/prizes/medicine/2018/allison/facts/) [1:43:15]

§