# #213 ‒ Liquid biopsies and cancer detection | Max Diehn, M.D. Ph.D.

**Source:** [https://peterattiamd.com/maxdiehn/](https://peterattiamd.com/maxdiehn/)

---

Max Diehn is a Professor of Radiation Oncology at Stanford and a clinical radiation oncologist specializing in lung cancer. Max’s research focuses on developing novel methods for detecting circulating tumor DNA in the blood of cancer patients and on elucidating the molecular pathways and genes associated with cancer. His interests also include uncovering biomarkers that can predict patient survival, responses to therapy, and disease recurrence. In this packed episode, Max discusses the history of blood-based cancer screening and the importance of understanding the predictive value of tests—sensitivity, specificity, negative predictive value, positive predictive value – and how these metrics play into cancer screening. Max then goes in depth on the topic of liquid biopsies, including the history, current landscape, and possible future of liquid biopsies as a cancer detection tool. He discusses how these non-invasive blood tests can detect DNA/RNA from tumor cells released into the blood as well as the different methods one can use to predict if a cancer is present. He gets granular on the topic of cell-free DNA/RNA signature, methylation patterns, and the importance of knowing mutation information, and he ends with a discussion on the exciting future of liquid biopsies and how we can possibly get to the panacea of cancer screening.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/maxdiehn/the_Drive_public.png)

Play

#213 ‒ Liquid biopsies and cancer detection | Max Diehn, M.D. Ph.D.

#213 ‒ Liquid biopsies and cancer detection | Max Diehn, M.D. Ph.D.

1x15s30s

0:002:06:54

## We discuss:

- Max’s training that planted the seeds for development of liquid biopsies [4:30];
- Max’s decision to specialize in radiation oncology [11:45];
- A culture at Stanford that values research and physician scientists [17:00];
- The motivation to develop liquid biopsies [19:15];
- History of blood-based cancer screening and understanding the predictive value of tests [25:30];
- Current state of lung cancer and the need for better screening [32:45];
- Low-dose CT scans: an important tool for managing lung cancer but with limitations [42:00];
- Using liquid biopsies to identify circulating tumor cells [47:00];
- Liquid biopsy research moves from circulating tumor cells to cell-free DNA [1:03:00];
- Zeroing-in on circulating tumor DNA in cell-free DNA [1:10:48];
- Cell-free RNA and Max’s vision for cancer detection from a blood sample [1:22:00];
- Methylation patterns and other informative signatures found in DNA [1:24:30];
- Mutation-based methods of liquid biopsies [1:26:30];
- Understanding the sensitivity and specificity of a diagnostic test [1:30:30];
- Existing clinical liquid biopsy tests and their limitations [1:37:30];
- The future of liquid biopsies [1:44:00];
- How we get to the panacea of cancer screening [1:52:00];
- More.

§

## Show Notes

**\*Notes from intro:**

- Max Diehn is a Professor of Radiation Oncology, Vice Chair of Research, and Division Chief of Radiation and Cancer Biology at Stanford University
- Max is a co-founder of [Foresight Diagnostics](https://foresight-dx.com/), a precision medicine company, developing novel liquid biopsy tests for measurement of minimal residual disease
- He’s also the co-founder of [CiberMed](https://cibermed.com/), a company that applies data science for biomarker discovery
- Max consults and advises a number of companies in similar spaces
- Max’s [current research](https://med.stanford.edu/diehnlab.html) involves the development of novel methods for detecting circulating tumor DNA in the blood of cancer patients
  - He also works to understand cancer cells by identifying molecular pathways and genes associated with disease
  - He’s interested in uncovering biomarkers that can predict response to therapy or predict patient survival and return of disease as early as possible, which is something we’ll get into in the discussion so you can understand why it’s so important to predict recurrence as soon as it happens
- Clinically, Max is a radiation oncologist and he specializes in lung cancer
- He manages a broad clinical research portfolio, and he focuses on improving these personalized therapies for patients with lung cancer
- Max and Peter were classmates in medical school
- In this episode, they talk about Max’s background and how he became interested in liquid biopsies
- We go into great detail here on sensitivity, specificity, negative predictive value, positive predictive value
  - These are things that everybody needs to understand if they want to be smart on diagnostics, and if they want to understand cancer screening
  - We talk about how they play into cancer screening, especially when it comes to understanding prevalence and pretest probability
- We spend some time talking about lung cancer, which is the number one killer for both men and women
  - It’s not just a smoker’s disease, 15% of people who die of lung cancer have never smoked a cigarette in their life
- We dive really deep into liquid biopsies; the landscape, the history, the possible future of liquid biopsies
  - In this episode, we get a lot more granular around the nuances of the different ways in which not just we can look at [circulating tumor cells](https://en.wikipedia.org/wiki/Circulating_tumor_cell) versus [cell-free DNA](https://en.wikipedia.org/wiki/Circulating_tumor_DNA)
- When looking at cell-free DNA, what are the different methods that can be used to predict if a cancer is present?
  - How can we look at the actual genes from the actual cancer that we know we’re searching for versus in a screening situation when we don’t know the gene that we have to look for other clues.
- We talk about these cell-free DNA, RNA signatures
- We talk about [methylation patterns](https://en.wikipedia.org/wiki/DNA_methylation)
- We talk about the importance of knowing mutation information
- We talk about the difference in some of the screenings being approved by the FDA versus those that are being permitted to use for patients without FDA approval formally
- We talk about the path to using blood alone as a screening for early detection and the use case for liquid biopsies
- We also talk about cancer screening beyond when you know the mutations
  - Peter thinks this question is the hardest one to get at because when you start to think about pan screening for early detection of cancer, it seems unlikely that you’re going to know the mutations
- There’s a lot packed into this episode, but it is truly one of the most important subjects given the difficulty in treating cancer when it becomes advanced

## Max’s training that planted the seeds for development of liquid biopsies [4:30]

**Max’s training at Stanford**

- Peter and Max were in medical school together at Stanford
- After the 1st 2 years of med school, Peter went off into the clinical stuff while Max went off into the lab
- Most MD PhD programs split medical school in half, focusing for the 1st 2+ years on medical school classes, then doing PhD work in the laboratory, and finally going back for clinical work
- There’s an important transition point there when you’re finishing the classroom part of the medical school and deciding what lab to work in
- Max chose to do his dissertation with [Pat Brown](https://en.wikipedia.org/wiki/Patrick_O._Brown), who was a professor in biochemistry
  - He was the founder and CEO of [Impossible Foods](https://impossiblefoods.com/) until recently
- What attracted Max to Pat Brown’s lab‒ Pat had invented technology for measuring the expression of basically all the genes in the genome with a technique called [DNA microarrays](https://en.wikipedia.org/wiki/DNA_microarray)
  - At the time, this was revolutionary
  - Before, only one or a handful of genes were measured at a time
  - This technology was opening up whole new fields that would allow us to learn so much
- Max’s dissertation was a little unusual; he worked on many different projects
- It was a unique time in the lab where a new technology is transformative
  - It opened up so many doors simultaneously
  - A new lens through which to view biology
  - He immediately thought of thousands of questions that would be interesting to ask

> “*You have this new tool that no one’s ever had before*”‒ Max Diehn

- His dissertation focused on 2 main areas‒ 1) immunology and 2) cancer biology
  - These were his 2 interests coming into medical school
  - One project focused on [T cells](https://en.wikipedia.org/wiki/T_cell), a critical part of the [adaptive immune system](https://en.wikipedia.org/wiki/Adaptive_immune_system)
  - He was interested to see what genes are turned on and off in T cells when they are activated
    - When they are stimulated through their [T cell receptor (TCR)](https://en.wikipedia.org/wiki/T-cell_receptor) alone or with a [co-stimulatory signal](https://en.wikipedia.org/wiki/Co-stimulation#T_cell_co-stimulation)
    - He measured RNA
- [RNA](https://en.wikipedia.org/wiki/RNA) is the intermediate between DNA and proteins
  - DNA microarrays are a way of measuring specific RNAs
- DNA microarrays allowed him to see hundreds and thousands of genes changing as he manipulated T cells
  - He was able to build a catalog of all the genes that turned on or turned off when T cells were activated using different signals
  - This catalog has been very helpful for understanding the mechanism of T cell activation
  - This has gotten more interesting with the advent of [immunotherapy](https://en.wikipedia.org/wiki/Immunotherapy)

**How difficult was it to keep the RNA intact as you cataloged the generation of mRNA from DNA as this signal of gene expression?**

*There’s a lot of things there that are interesting; one of them is the instability of RNA*

- RNA is chemically unstable when compared to DNA and one has to be very careful to prevent its degradation
  - This is a hurdle to overcome in working with RNA
- For example, in his experiments with T cell stimulation, the cells are alive
  - This maintains the RNA
  - Only once the cells die does degradation start to happen
  - The experiment is designed carefully to immediately add solutions to protect the RNA after the cells are killed at the end of the experiment
    - So there’s not time for chemical degradation of the RNA
- The other project Max worked on during his PhD was to develop a method to isolate RNA that’s stuck to the [endoplasmic reticulum (ER)](https://en.wikipedia.org/wiki/Endoplasmic_reticulum) inside cells
  - RNA encoding proteins that are secreted from cells or surface proteins, is sent to the ER
  - These RNAs (and proteins) are important for diagnostic and therapeutic purposes
  - He was interested in cataloging these RNAs
  - There was a long procedure to purify the subset of RNA stuck to the ER
    - It required a lot of work in a cold room (at 4o C) to maintain the integrity of the RNA
  - He did a lot of work on methods to stabilize RNA

**How much insight could you get into noncoding sequences of genes (the part that doesn’t encode protein)?**

- With the technique Max was using at the time, they were focused on measuring the coding portion of the genes (the RNA transcripts that code for proteins)
- They had to decide at the beginning of each experiment, which genes to measure
  - Because they had to create a [probe](https://en.wikipedia.org/wiki/Hybridization_probe) for each gene
- Subsequently, this approach was used in some of the early work on long noncoding RNAs
  - That was largely led by a former postdoc from Pat Brown’s lab who was there while Max was a grad student, named [Howard Chang](https://profiles.stanford.edu/howard-chang), who is professor at Stanford
- Max finished his PhD in 3.5 years then he went on to begin his clinical rotations

## Max’s decision to specialize in radiation oncology [11:45]

**Did you have a sense that you definitely wanted to be a clinician, which would mean not just finishing medical school, but then doing a residency?**

- Yes, he was set on doing a residency but wasn’t sure what the focus would be
- Before med school he thought he would go to graduate school for a PhD and focus on research for his career
- But when he was a junior in college, his father was diagnosed with lymphoma
- His interactions with oncologist and the medical team revealed how little we knew about many things related to cancer
- This convinced him to be on the doctor’s side to help people, not just on the patient side with his father
- He wanted to, “*Help patients at the time of their life where it might be the worst time of their life as well as to try to move the field forward to improve treatments that while they worked somewhat obviously were not good enough.*”
- He came to medical school with an inkling that oncology was where he wanted to be
- What he didn’t realize early on was how many options in that there are
  - He was looking at it mostly through the lens of medical oncology
  - There is surgical oncology, radiation oncology, and other sorts of avenues

**Max’s childhood**

- Max was born in Munich, Germany and came to the US when  he was 11 years old
- Initially his family moved to south Florida
- When he was a sophomore in high school, they moved to Connecticut
- He went to Harvard as an undergrad and lived in the Northeast until he came out to Stanford

**Max’s clinical training**

- He considered surgical oncology; he liked the procedural aspects of it
- Ultimately he decided on radiation oncology
  - Initially he was leaning towards medical oncology, because that’s what he had seen through his dad’s journey
  - He did a rotation in radiation oncology in large part because his wife (also a medical student at Stanford) did a year of research in the department of radiation oncology
  - He really enjoyed radiation oncology from a patient care standpoint
  - They would generally see less patients in a day than might be seen in medical oncology
    - This was very attractive to him

> “*Radiation oncologists had a little more time in clinic to spend with each patients*”‒ Max Diehn

- He also really liked the technology aspects
- This was a field where they do a lot of imaging to see where tumors are in the patient’s body and then we have fancy robots that deliver the radiation very precisely
- It seemed to combine his love of oncology and patient care with his interests in technology development
- There was an opportunity to do work in the laboratory at a molecular level where not so many people were working on this compared to medical oncology

**Was Max able to do any research during his residency?**

- Peter recalls discussing the last 2 years of medical school with [Karl Deisseroth](https://profiles.stanford.edu/karl-deisseroth?tab=bio) (in [episode #191](https://peterattiamd.com/karldeisseroth/)) the challenge of keeping his hand in the lab during his residency
- Max did an internship in medicine at Stanford then 4 years of radiation oncology (residency), 5 years in total
- He remembers trying to write some papers in the call room, to finish up work from his PhD
- Radiation oncology residency programs have a research track for individuals who are interested in laboratory based research called the home and pathway
  - In other fields this is called short tracking or fast tracking
  - *The idea is they can trade in some of the clinical training time for research time*
  - ***This gave him a postdoc time of about 2 years during his 4 years of radiation oncology residency***
  - During that postdoc time, he had clinic activities about half a day to a day a week and the other days were in the lab
    - It actually was a really good preview of what his life would be like once he finished all the training and became a faculty member

## A culture at Stanford that values research and physician scientists [17:00]

**How did you decide to stay at Stanford?**

*Was the department of radiation oncology at Stanford a natural fit for the type of problems you wanted to solve on the research side?*

- The department at Stanford was one of the very first departments of radiation oncology in the US
- Radiation oncology grew out of [radiology](https://en.wikipedia.org/wiki/Radiology), which is a diagnostic arm of radiology; where you do imaging to diagnose disease
- Their first chairman, [Henry Kaplan](https://nasonline.org/member-directory/deceased-members/53979.html), was a very famous radiation oncology physician scientist
  - He led the movement to develop radiation oncology as its own specialty
  - In the ‘50s he worked on curing Hodkin’s disease with radiotherapy, some of the 1st successes in curing young patients with lymphoma
- The radiation oncology department at Stanford has a history of strong interest in laboratory-based research
  - Thanks to Henry Kaplan who was doing laboratory research at the time also while seeing patients
- There were faculty in this department that were laboratory based
  - Even just PhD’s who were fully laboratory based; this isn’t the case in many radiation oncology departments
- Max really liked the research environment

> “*This was a place where I could see that the kind of research I wanted to do was valued*”‒ Max Diehn

- There were mentors who were successful physician scientists
  - This is important when you’re young, to have mentors that can show you how to overcome obstacles if you’re in trouble

## The motivation to develop liquid biopsies [19:15]

**When did he become interested in the idea of liquid biopsies?**

- Peter has been following liquid biopsies for about 6 years
- Obviously Max has been working on it for a lot longer
- For many people, liquid biopsies are still a bit of a black box
- Max did not start his lab with the idea of focusing on liquid biopsies
  - He got there by following the results from some experiments

> “*One of the keys to being a successful scientist… is following the data*”‒ Max Diehn

- All research projects begin with a clinical need
- He decided to specialize in treating lung cancer clinically
- He was in the clinic 1 day a week and saw lung cancer patients exclusively
- Treating early stage lung cancer patients left Max frustrated
  - Stage 1 or stage 2 lung cancer, which means the cancer hasn’t spread (as far as they could tell); the table and figure below summarize the stages of cancer

![](https://peterattiamd.com/wp-content/uploads/2022/07/f1-maxdiehn-1024x310.png)

**Figure 1. Stages of cancer.**  Image credit: [National Cancer Institute](https://www.cancer.gov/about-cancer/diagnosis-staging/staging)

![](https://peterattiamd.com/wp-content/uploads/2022/07/f2-maxdiehn-1024x497.png)

**Figure 2.  Cancer staging indicates its growth and spread.**  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Cancer_staging)

- He could cure the majority of these patients with targeted, high dose radiation
- But the cancer came back for 20-25% of these patients
- After he finished treatment, in the 1st follow-up visit 3 months after radiation, ***he couldn’t tell who was cured and who would have the cancer come back***
- State-of-the-art at the time was to have patients come back for scans every 3, 6, 12 months
- Max notes, “*It’s a very reactive approach and very unsatisfying, and this is something we went through with my dad*.”

**How small of a tumor can be detected with a CT scan?**

- It is hard to see things much smaller than ***one centimeter in diameter***, maybe eight millimeters
  - This will depend somewhat on the location in the body
  - As a general rule of thumb, this is ***about a billion cells‒ a vast number of cancer cells***
- Peter notes, “*anything at a centimeter is not posing a direct threat to the organism*”
  - With the rare exception of a badly placed brain tumor
  - 1 cm in most cancers would be irrelevant
  - A 10 cm x 10 cm tumor would be fatal
- Max explains, “*whether a tumor is fatal or not, as you point out, greatly depends on the location. In certain areas, one can have a ton of tumor without it being fatal. And in other areas you have very little room for that. It’s a volumetric. It grows by the cube, by the radius multiplied by itself three times. And that is, of course, non-linear. It grows much faster. The number of cells in a mass are much more than just the linear increase in the diameter of the lesion.*”
- Peter notes, this is the part that is hard to understand
  - We do a good job with linear thinking
  - We don’t think exponentially very well
  - The point here is, we are flying blind from a diagnostic standpoint when the cancer cells number from 0 to 1 billion cells
- Metastasis of cancer is ultimately what ends of killing patients; when the cancer spreads
- If the cancer is localized, a surgeon or radiation oncologist can cure the patient
- Once the cancer has spread to many places in the body, it cannot be removed or you can’t radiate it all

***The problem is what’s called micrometastatic disease or microscopic disease that has spread elsewhere in the body, you could have dozens or even hundreds of these micrometastatic deposits in different organs; and these are all under 0.5 cm***

- The detection of **micrometastatic disease** is beyond the limits of our imaging methods; we can’t see them all
- Max thought he could potentially get a handle on it if he had a test that could measure in the blood the contributions from all these dozens of micrometastatic deposits
  - This may provide higher sensitivity
  - This was his motivation to work on liquid biopsies

> “*I had no idea how I was going to do that when I started it*”‒ Max Diehn

## History of blood-based cancer screening and understanding the predictive value of tests [25:30]

**The history of blood-based tests for cancer**

- Peter notes, there are a couple areas where blood tests for specific proteins are being used for cancer screening; they’re not great
  - [PSA](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/psa) levels for prostate cancer
  - [CEA](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/cea) levels for colon cancer
  - [CA 19-9](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/ca-19-9) levels for pancreatic cancer
- When Max begin thinking about developing a blood-based test initially for lung cancer, he thought of these examples
  - These examples above are all protein biomarkers
  - Proteins made by cancer cells that are shed into the blood where they can be measured in a non-invasive fashion

**Shortcomings of protein biomarkers**

- Max points out, “*A large issue with these protein biomarkers is that they are actually not that specific for cancer, meaning that these are also proteins that normal cells can make*”
  - Cancers often make more of these proteins
  - The problem is knowing how to interpret low levels of these proteins

***Does the patient have a little bit of cancer or is it just the baseline of what their normal cells are making?***

> “*That lack of specificity… was the major Achilles’ heel of the protein-based biomarkers*”‒ Max Diehn

- A  lot of work had been previously done looking for biomarkers in lung cancer
  - CEA was a good biomarker in some patients
- Protein-based approaches were state-of-the art when Max began his research but their major weakness was a lack of specificity

**The difference between sensitivity and specificity in understanding the positive and negative predictive value of tests**

**Sensitivity** is a synonym for ***the true positive rate***, the likelihood of having a positive test when the patient has the actual condition

- If you have 100 cancer patients [they all have cancer], sensitivity of a test is how many of them show a positive blood test
- A perfect test would have 100% sensitivity, 100/ 100 cancer patients would test positive
- Mammography might have an 85% sensitivity, which means 85 of 100 women with breast cancer would be identified with a mammogram
  - This is giving a [false negative](https://en.wikipedia.org/wiki/False_positives_and_false_negatives#False_negative_error) result for 10 of the 100
- It’s important to realize that there are no perfect tests
- This is even more true when you start pushing the envelope to see smaller and smaller tumors
  - It’s unrealistic to have a test that’s 100% sensitive
  - No test will catch every cancer patient‒ this is hard for patients to understand and leads to a lot of frustration

*Peter’s anecdote on sensitivity and specificity*

- Peter’s former analyst, Bob Kaplan came up with a great thought experiment to explain this

***If you drive a test to high sensitivity, the specificity must go down***

- If you wrote a letter to 1000 random women and told each they had breast cancer (with no additional knowledge), this is technically a test with 100% sensitivity because you have identified every woman in this group with breast cancer
  - Let’s assume 50 of these women have breast cancer
  - There are no false negatives in this group
  - The problem is *the specificity of this test is horrible*
  - There are so many [false positives](https://en.wikipedia.org/wiki/False_positives_and_false_negatives#False_negative_error) that the test is useless

***This illustrates that you can have 100% sensitivity without any clinical utility***

- Max replies, “*That explains a lot of what happens in the research diagnostic research field in general. You try to push sensitivity, but that never is meaningful to report if you don’t also report on specificity*.”
- **Specificity** is the inverse of sensitivity, for patients that don’t have cancer it is the report that their test is negative

***It’s the reporting of true negatives***

- Sensitivity and specificity are connected, you can push the sensitivity higher if you ignore the specificity

## Current state of lung cancer and the need for better screening [32:45]

**What is the current state of lung cancer?**

> “*It’s the number one cause of cancer death*”‒ Max Diehn

- Outcomes in breast or prostate cancer are actually much better; we can cure a large fraction of these patients
- The vast majority of patients with lung cancer, historically, cannot be cured
  - This is why lung cancer is the #1 cause of cancer-related death
- The incidence of lung cancer is going down in men and now also in women due to a decrease in smoking
  - Secondly treatment have gotten better
  - Screening is slowly getting better
- While smoking is by far the largest risk factor for lung cancer, it’s not the only risk factor

> “*Anybody who has lungs can get lung cancer*”‒ Max Diehn

- Lung cancer can develop as a result of: pollution, radon gas or other things in the environment, genetic associations
- If we could magically make smoking go away, there would still be lung cancer

**The 2 major types are small cell and non-small cell lung cancer**

- [Non-small cell lung cancer](https://en.wikipedia.org/wiki/Non-small-cell_lung_carcinoma) involves [adenocarcinoma](https://en.wikipedia.org/wiki/Adenocarcinoma), [squamous cell carcinoma](https://en.wikipedia.org/wiki/Squamous-cell_carcinoma_of_the_lung), and [large cell](https://en.wikipedia.org/wiki/Large-cell_lung_carcinoma)
  - Adenocarcinoma is the most common lung cancer in the non-small cell subtype
  - When a non-smoker gets lung cancer, it’s usually adenocarcinoma
  - Squamous cell carcinoma also makes up a significant fraction of non-small cell lung cancers
- [Carcinoid](https://en.wikipedia.org/wiki/Pulmonary_carcinoid_tumour) is its own category, it’s not a [small cell lung cancer](https://en.wikipedia.org/wiki/Small-cell_carcinoma) and it’s not considered non-small cell lung cancer either

**What genes are thought to be involved in the risk of lung cancer?**

- - Asian women seem to have an elevated risk of lung cancer
    - Potentially related to differences in estrogen and testosterone

- This is a big mystery, we have not identified the genetic drivers of lung cancer in Asian women

- It’s multifactorial‒ it’s due to multiple genetic variants that aggregate to elevate risk
  - There may also be some further environmental factors that aren’t smoking that may interact with that genetic background to increase risk

**Radon is a big environmental exposure conferring risk**

- Particulate matter less than 2.5 microns is small enough to make its way into the most distal part of the lung
- There is an increase in all-cause mortality associated with exposure to 2.5 micron particulate matter (PM 2.5)
  - The graph below shows the size distribution of particulate matter in the atmosphere

![](https://peterattiamd.com/wp-content/uploads/2022/07/f3-maxdiehn-907x1024.png)

**Figure 3. Size of various types of particulate matter in the atmosphere.**  Image credit: [Wikipedia](https://en.wikipedia.org/wiki/Particulates)

- More cases of lung cancer is associated with living in cities versus rural environments and this correlates with particulates in the ambient environment
  - There is definitely an association in epidemiologic studies
  - To prove it in a human is difficult
- There is a biological rationale‒ particulates cause irritation and chronic inflammation
- There are also chemicals in smog that along the lines of what’s in tobacco smoke, can be direct carcinogens

**What is the dose-response curve in pack-years of tobacco smoking for the relative increase in risk of lung cancer?**

- Studies suggest there is increased risk as you go from zero to higher levels
- Risk plateaus around 20-30 pack-years; this may be saturating risk
- A [pack-year](https://en.wikipedia.org/wiki/Pack-year) is not an ideal clinical variable because you can’t measure it in a completely unbiased way
  - In reality, patients smoke different amounts of time and they don’t always remember perfectly

**What does the data say about secondhand smoke?**

- This is very difficult to measure, even harder than pack-years
- Some professions are exposed to a lot of smoking‒ waitresses/ waiters, stewardesses/ stewards
  - There are increases in lung cancer in these groups epidemiologically

***How to quantitate secondhand smoke exposure and determine when one’s risk is significantly elevated is a major problem***

- This is an areas where it would be very useful to have a biomarker that could be quantitatively measured, to actually measure one’s exposure
- Secondhand smoke is not a criteria for patient eligibility for cancer screening by [low-dose CT](https://en.wikipedia.org/wiki/Lung_cancer_screening)
  - This criteria is focused on people who have the highest risk in the population
  - You want to detect at least 0.5% of the cancer you are screening for because otherwise you will screen lots and lots of patients who will never get cancer
    - This is when specificity becomes a problem
    - Peter notes, “*You then need to know the prevalence or the pretest probability to know how to interpret the result. Without the prevalence, you can’t impute the positive and negative predictive value, which is what tells you when you have a positive, how confident are you it’s positive, and similarly, when you have a negative, how confident are you there?*”  (we’ll come back to this)
- Though exposure to pollutants and secondhand smoke are known to increase the risk of lung cancer, there are public health reasons why these are not the screening criteria
  - This can be frustrating for patients in these categories

## Low-dose CT scans: an important tool for managing lung cancer but with limitations [42:00]

- Low-dose [CT](https://www.cancer.gov/about-cancer/diagnosis-staging/ct-scans-fact-sheet) has been one of the major changes in the last 10 years in how lung cancer is managed
- There have been a lot of efforts to develop a screening test for lung cancer, given that it is the number one cause of cancer deaths
  - There have been a lot of failures
  - Initial studies focused on chest x-rays; there was little benefit due to low resolution
- The [National Lung Screening Trial](https://www.cancer.gov/types/lung/research/nlst) took patients and randomized them to get either a low-dose CT scan or a chest x-ray
  - There was a relative reduction of risk of about 20% in the patients who got the low-dose CT scan
    - This was viewed as a win for using low-dose CT as a screening test
  - The [absolute risk reduction](https://en.wikipedia.org/wiki/Risk_difference) was small, in the single digit %
    - Let’s say it was 5%, then the [NNT (# needed to treat)](https://en.wikipedia.org/wiki/Number_needed_to_treat) would be 20; you could save a life for every 20 people
    - Peter thinks this sounds good
    - Max notes the value is actually lower than that, maybe 0.5-1%
- A a low-dose CT scan is a more high resolution way of looking at the lungs; it can see smaller nodules than a chest x-ray
- The value of a low-dose CT scan gets complicated because you think you either see a nodule or you don’t, but it’s not that easy
  - A CT scan is complicated to read
  - Interpretation of the scan and what is considered positive will affect the sensitivity, specificity, and the NNT
- The way low-dose CT scans are read now is different than when the initial study was done because of a high risk of false positives
- Low-dose CT is not Max’s area of expertise

***Even though this test is a major home-run for screening (because we can save cancer deaths), it’s not a perfect test***

- The estimated amount of [radiation in a low-dose CT is 1.5 mSv](https://www.cancer.gov/about-cancer/diagnosis-staging/ct-scans-fact-sheet)
  - This is significantly less than scans used routinely for patients who already have cancer
  - This is an important concern because radiation can cause cancer; so the question becomes, is the risk worth it
  - The risk of causing cancer is much, much lower for a low-dose CT scan

**What would be your personal threshold for how much radiation you would want to receive a year from imaging?**

- Peter points out, “*The* [*NRC*](https://www.nrc.gov/) *says that we shouldn’t be exposed to more than 50 millisieverts in a year. Is that like saying you shouldn’t drink more than 10 drinks in a day?*”
- Being at sea level probably exposes you to 1-2 millisieverts a year
  - If you live in Colorado, you could probably double that

*Do you start to worry at 20 millisieverts in a year? Which is obviously pretty easy to do with a PET CT scan.*

- Max notes, they don’t routinely track this at the individual patient level
- The risk is really low and harm is actually very difficult to quantitate
  - It’s difficult to quantitate exactly how much risk of, let’s say, a second malignancy there is, a future malignancy there is, from a given protocol of a CT scan or whatnot
    - You could never get the data to randomize all those things

***The calculus of medical practitioners who order imaging studies is‒ will this test help manage the patient, will it benefit the patient***

- If the scans won’t change the course of treatment, then they shouldn’t be ordered
- The way practitioners think about scans is‒ are they worth doing?
- Some patients who have lung cancer and get radiation therapy receive very high doses of radiation
  - If they were not a cancer patient, one would never want those amount of radiation
  - But Max points out, “***The vast majority of those patients will not get a cancer from their imaging or radiation treatment; and their cancer, if we leave it untreated, will kill them.***”
- This comes back to the need to catch cancer early, to have a chance at a cure
- They don’t have patients wear radiation-detection badges to track their exposure, as if beyond a certain point no further imaging would be done
  - It’s always decided on a case-by-case basis

## Using liquid biopsies to identify circulating tumor cells [47:00]

**Liquid biopsy research began with collecting blood samples from lung cancer patients**

*A hypothetical cancer patient*

- A patient had either a resection and/or radiation following their NED (no evidence of disease)
- Let’s say the recurrence rate is 25%
  - So 25 of 100 of these people are going to have a recurrence of their cancer
- We know that the sooner we catch the recurrence, the better the odds are for treatment
  - There is a lower tumor burden
  - There is a lower burden of mutations
  - This gives greater odds for success of therapy
- If this were 200 years ago, we’d be hosed because we’d have to wait until the patient was coughing up blood
- But even with high-resolution CT scans, at best we have to wait until there are at least a billion cancer cells

**How did Max think of looking for a different type of biopsy, a liquid biopsy?**

> “*I was frustrated by not being able to diagnose a recurrence earlier*”‒ Max Diehn

- The inability to predict which of his patients was going to have their cancer recur was an unmet need that he wanted his lab to work on
- There are 2 ways to go about this
  - 1 – Build a mouse model (a preclinical model) to try to grow tumors in animals then see if  you could have a hypothesis for what might be a good biomarker
    - Test it in the mouse and then go back to the human
  - 2 – Translational research, do the research in the human; it’s the final model
    - This is where he began
    - They work directly on blood samples
    - If they find something, it should be directly applicable
- He began by just collecting blood samples
  - He didn’t know what he was actually going to do with them

*Was this funded by the NIH, a* [*R01*](https://en.wikipedia.org/wiki/NIH_grant#R01)*?*

- As a new faculty member, when you get that first job, you get startup funds
  - This provides the money to kickstart your research because you don’t have any grants yet
  - This is how he funded this initial work
- One of the things with academic research and funding is that oftentimes you have to show it already works before you can get funding for it
  - This is a very common story because grant funding is limited
  - Organizations that fund research are often quite conservative if the idea sounds great, but you have no proof that it works at all‒ they aren’t going to give you money
- Max used his startup funds to begin collecting blood and started thinking about what biomarkers would be good
  - He collected blood both prior to resection/ radiation treatment and in follow-up visits after treatment
- He read the literature on protein biomarkers
  - They didn’t seem very useful
- He spent a year looking at [circulating tumor cells (CTCs)](https://en.wikipedia.org/wiki/Circulating_tumor_cell), which is one subtype of the [liquid biopsy field](https://en.wikipedia.org/wiki/Liquid_biopsy)
  - These are intact cancer cells that can circulate in the blood of patients
- These cells are very complicated to measure for a variety of reasons
  - They are not very abundant so they’re difficult to purify
  - In a good purification there might still only be 1% or less of the purified sample

***Finding circulating tumor cells is like finding a needle in a haystack***

- Further with intact cells, they need to be processed on the same day or within 1-2 hours of the blood draw
  - This makes it very difficult to build up biobanks of frozen samples to provide a large enough cohort to study

*The last thing he did were some control experiments*

- These are critical
- You always want to ask, is the thing I’m working on really working?
- They drew blood from healthy individuals who don’t have cancer
  - They found circulating tumor cells even though these patients didn’t have cancer
  - This led him to realize they were picking up something else; there was a lack of specificity

***He realized looking for circulating tumor cells wasn’t going to make it into the clinic anytime soon***

- This led him to reevaluate and ask, what else could they do?

**Did you find any proteins that were expressed by lung cancer cells that were unique to them?**

- No
- They did not screen themselves, but other people had
- [Mass spectrometry](https://en.wikipedia.org/wiki/Mass_spectrometry) can be used to analyze the proteins in a blood sample; those studies did not find convincing markers unique to lung cancer cells
- Some markers were elevated in some patients
  - [CEA](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/cea) was one marker that can be elevated in lung cancer patients and can even be a marker for recurrence (like [PSA](https://www.cancer.gov/publications/dictionaries/cancer-terms/def/psa) can be in prostate cancer)
  - But there is a problem with specificity
- Many studies of protein biomarkers may be an artifact of the cohort or elevated due to something else going on
  - There was problems with reproducibility
  - Often the lack of reproducibility is not published
  - You need a very large study to definitively prove something doest work, and often this is not worth the time and cost

**The selection bias for publishing positive results**

- Peter notes the publication bias this creates
  - Positive results are published more
  - When scientists fail to reproduce the work of others, this is often not published
  - Peter comments on the system, “*That means that one finding gets disproportionately propagated as a positive finding, when in reality four labs have now found it to be highly unlikely, and that doesn’t get published*.”
- Max agrees this is a problem and points out, “I*n general, we don’t have a system where one lab could know that three other labs had done the same thing. Maybe, eventually, you find out over dinner at a conference or something, right? But because there is no place to look up to say what other people have done, there is no way to know. It would be great if we could fix it. It’s a very difficult problem, of course, because of many factors, including the economic parts of limited resources and time.*”
  - If a grad student were assigned to publish such a study, it would take 6 months of their time
  - That’s 6 months they’re not spending on their main project
- Reproducing published works is important to know that something really works

***It’s really helpful to see multiple studies from multiple groups, ideally with multiple methods, that find the same thing***

- This is where reading the literature can show if the finding is robust

**Back to circulating tumor cells‒ for patients that have stage II lung cancer, how much blood does Max sample before resection?**

- Around 10-20 ml, a few tablespoons of blood

*What’s the maximum number of circulating tumor cells (CTCs) would they find in these samples?*

- Often it’s zero for a stage I-II cancer patient
  - This means the sensitivity isn’t very good
- In stage IV patients they saw quite a lot, some patients had massive amounts
- Occasionally he would see early-stage patients with a lot of CTCs
  - [Caroline Dive](https://www.cruk.manchester.ac.uk/Our-Research/Cancer-Biomarker-Centre) from University of Manchester did a lot of these studies
    - Her group took blood from the draining veins at the time of the surgery (the lobectomy for lung cancer) and did circulating tumor cell assays
    - They found evidence that they could find more signals, meaning that sensitivity was better in that context
    - The hypothesis was that if you’re measuring the blood outflow of the tumor, you’re going to catch more cells
    - Once CTCs hit the systemic circulation, they get diluted all over the entire body

**If you had 2 stage II patients, one is typical and has no CTCs while the second patient has a reasonably high burden of CTCs, would you predict the second patient would have a recurrence over the first patient?**

- - Yes and there’s evidence of that
  - Studies show when you see high levels of CTCs, this is a bad thing; patients are at higher risk of recurrence
  - One complication in the CTC field is that even non-cancer patients can have circulating cells that look like CTCs using the markers available
  - The marker commonly used to identify white blood cells is [CD45](https://en.wikipedia.org/wiki/PTPRC#Clinical_importance)
    - White blood cells need to be differentiated from CTCs
  - A marker for CTCs should be expressed in cancer cells but not white blood cells
    - One marker is [cytokeratin](https://en.wikipedia.org/wiki/Cytokeratin), a structural protein specific to epithelial cells

- But, Max’s group and others have found healthy patients can also have cells that have cytokeratin expression but no white blood cell marker expression in circulating cells

- Other people have gone further to do single cell sequencing of those to show that their genomes are actually normal and not mutated like cancer cells are

***It appears that there can be epithelial cells circulating that are not cancer cells; this makes it complicated to look for the presence of tumor cells***

- This indicates that looking for CTCs is not a good cancer screening tool
- Maybe this approach holds some promise for determining the course of adjuvant therapy in a patient
  - If they see a high number of CTCs then they may want to give the patient additional chemotherapy because of the increased risk of recurrence
- This motivated Max to start work on liquid biopsies

***There is still a lot of work going on in the circulating tumor cell field, but more development is required to use it clinically***

## Liquid biopsy research moves from circulating tumor cells to cell-free DNA [1:03:00]

- After some work with CTCs, Max moved on to look at [cell-free DNA](https://en.wikipedia.org/wiki/Circulating_tumor_DNA)
  - This is DNA found in circulation, in the blood plasma, outside of cells
  - It’s called cell-free because it’s outside of cells; of course it originally comes from cells but now it’s circulating by itself
- Max became interested in this field after reading about [prenatal diagnostics](https://en.wikipedia.org/wiki/Prenatal_testing)
  - Work by a number of people like [Dennis Lo](https://www.cuhk.edu.hk/med/cpy/Research/DennisLo.htm) (in Hong Kong) and [Steve Quake](https://quakelab.stanford.edu/) (in the Stanford Engineering Department) have shown they can detect DNA from the fetus in the pregnant mother’s blood

***Max thought if this could be done in pregnancy, then why not in cancer patients***

Peter asks for clarification, “*When you take a tube of blood and you spin it, you get all of the cellular matter below the buffy coat, and then the plasma is above. Is the cell-free DNA in the clear plasma and not stuck within the cellular material?*”

- Correct, the cell-free DNA (cfDNA) is in the plasma, and that’s a critical technical aspect of isolating it
  - There may be more cfDNA mixed in the cellular compartment, but it would be harder to extract
    - This might be a future research direction
- There are low levels of cfDNA in the plasma
  - In a healthy person, there’s 1-5 ng/mL of cfDNA in the plasma
- This cfNDA is double-stranded DNA, but rather molecules of around 170 [base pairs](https://en.wikipedia.org/wiki/Base_pair)
  - This is the length of DNA you would expect if the DNA were wrapped around the core histones
    - [Histones](https://en.wikipedia.org/wiki/Histone) are the proteins that package DNA in our cells
    - They’re a scaffold that lets the long lengths of DNA compact to fit into the nucleus of a 10 micron cell
    - Shown in the figure below, 8 histones make up 1 [nucleosome core particle](https://en.wikipedia.org/wiki/Nucleosome) that winds up about 167 bp of DNA
    - Each nucleosome has 147-167 bp of DNA wound around it
    - The DNA that stretches between nucleosomes is called linker DNA

![](https://peterattiamd.com/wp-content/uploads/2022/07/f4-maxdiehn-1024x723.png)

**Figure 4.  DNA is wound on nucleosome core particles (composed of histone proteins) to allow it to compact into chromatin; linker DNA is the region of DNA between nucleosomes.**  Image credit: [*Nature Reviews Molecular Cell Biology* 2018](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5897046/)

- There is a high level of activity of [enzymes](https://en.wikipedia.org/wiki/Endonuclease) that chew up DNA in our blood and extracellular fluid
  - So cfDNA is only in the blood temporarily and it’s temporarily protected by these histones
  - *So the DNA that’s bound to the  histones is present at a higher frequency in the blood than DNA that’s between the histones [linker DNA]*
  - Histones are like pearls on a string, shown in the diagram above
  - And the DNA region between 2 pearls (linker DNA) is relatively depleted from the blood because of enzymes that chew up DNA
    - It’s because of these enzymes that there are low levels of DNA in the blood
    - There are lots of cell deaths, so you might imagine higher levels of DNA in our blood
    - But we have enzymes to degrade DNA
    - High concentrations of DNA become a snot-like substance; that would probably be bad to have in your blood

**Where does this cell-free DNA come from?**

- This is a mystery
- This is difficult to study because most, if not all tissues contribute to the pool of cfDNA

***It’s very difficult to study release of something from everywhere***

- cfDNA is chopped up in these small histone-bound fragments
- Historically most of the reviews and textbooks argue that cfDNA comes from [apoptosis](https://en.wikipedia.org/wiki/Apoptosis)
  - Cells that undergo apoptosis have their DNA chopped up as part of the process
- Apoptosis is a type of cell death
  - It’s a controlled, programmed cell death that gets rid of cells in a tidy way
  - This is a type of cell suicide that can get activated
  - It’s critical for our development because sometimes cells have to die to make room for other cells.
  - Apoptosis is part of our normal developmental homeostasis
  - It also is critical for getting rid of sick cells
- DNA inside a cell is chopped up during apoptosis
- DNA could also get released from cells through a non-apoptosis process, and it would likely become chopped up too
- [Necrosis](https://en.wikipedia.org/wiki/Necrosis) is another way a cell can die and release some of its contents into the blood

## Zeroing-in on circulating tumor DNA in cell-free DNA [1:10:45]

**How do you quantify the amount of cell-free DNA (cfDNA) you would get from 10 CC of blood?** ***And how are you distinguishing what is potentially cell-free DNA from a normal cell versus cell-free DNA that is from the cancer cell?***

- There is a laboratory procedure for isolating DNA from the plasma (the noncellular component of blood)
  - This has been optimized for low concentrations of DNA
  - The concentration of cfDNA is really low, in the single-digit ng/mL
  - Often in the lab we work with mg of DNA so working with ng (1000x less) quantities was one of the early challenges they had to overcome
    - Recall  the amount of cfDNA from cancer cells is less than 0.01 or 0.001% of what’s isolated from the blood [in the early stages of cancer]
- The most common method to quantify the amount of DNA uses a fluorescent dye that binds to the DNA and gives a specific fluorescence
  - This fluorescence can bread in a machine
  - You use a standard curve to read off how much DNA you have
- The more complicated thing they would do next is [quantitative PCR](https://en.wikipedia.org/wiki/Real-time_polymerase_chain_reaction)
  - This is an enzymatic method to amplify DNA
  - Again, you use a standard curve where the amount of DNA is known and compare to the amplification curve of your sample DNA to determine how much DNA is in the sample
- Most of the time they use the simple method‒ add dye to the DNA sample, put it in the machine, and get the result
  - It’s really fast
- You would get 10 mL of plasma from 20 mL of blood in most individuals
  - This would have between 1-5 ng/mL of cfDNA in healthy individuals
  - So that would mean a total of 10-50 ng cfDNA
- In some patients the level of cfDNA can be much higher (100’s ng/mL)  because there’s a lot of cell death happening in the body
  - Advanced cancer patients
  - Patients who have trauma
  - Patients with infection

**How do you distinguish cfDNA from a normal cell (presumably the majority of cfDNA) versus a cancer cell?**

***In the cancer field they focus on unique molecular properties of cancer cells that normal cells generally don’t have***

- These are the mutations that cause cancer; they are only present in cancer cells, not normal cells

*Cancer is a disease that is caused by mutation mistakes in the DNA of a normal cell that accumulate and ultimately lead to that cell, not being responsive to cues, to stop growing or to kill itself and just to grow uncontrollably*

> “*Those mutations… serve as really exquisitely specific markers of the cancer cell*”‒ Max Diehn

- These mutations are attractive biomarkers because 1) you’re tracking the cause of the disease
- 2) These mutations are highly specific biomarkers
  - Compare to [PSA](https://en.wikipedia.org/wiki/Prostate-specific_antigen), it can be made by normal prostate cells and by prostate cancer cells
  - But the mutations in the prostate cancer cell would *not* be present in normal prostate cells
- They look for mutations in these short DNA molecules that make up cfDNA
- Most of the cfDNA molecules come from normal cells and don’t have mutations
- There is a small subset of cfDNA molecules that do contain mutations
  - In a patient with advanced lung cancer 1% of their cfDNA may come from cancer cells
  - This is still a small amount
  - In early stage patients, the amount of cfDNA from cancer cells is less than 0.01 or 0.001% of what’s isolated

**How is such a small quantity of cfDNA from cancer cells detected?**

- [Next-generation sequencing](https://en.wikipedia.org/wiki/Massive_parallel_sequencing) is the most common method used
  - This is a high throughput molecular methods for sequencing DNA
  - It can identify the actual sequence of the bases (the AGTC bases) that make up DNA
  - It can provide the exact sequence for hundreds of millions of molecules or billions of molecules of DNA in parallel in one experiment
- They get millions of DNA sequences that are all about 170 bases in length
- They compare those sequences to the patient’s germline DNA (from a normal cell, purified from a [buccal swab](https://en.wikipedia.org/wiki/Buccal_swab) or the cellular compartment of the blood)
- They also start sequencing the actual tumor and compare this sequence to data from the patient’s cfDNA

**Using analysis of cfDNA to see which patients were cured of cancer after treatment**

- They have a piece of the patient’s tumor, sequence it, and learn the mutations it contains
  - They compare the DNA sequence from the tumor to the DNA sequence from the patient’s normal cells
- For example, they identify 10 mutations present in the patient’s tumor but not in their healthy cells
- Now they look in the database of sequences from the patient’s cfDNA for any of those 10 mutations

***That turns out to be exquisitely specific and sensitive for the presence of the cancer.  If we see even one or a handful of molecules that carry one of these mutations that… means there’s still cancer cells in the body.***

- The cfDNA fragments are very short, 170 bases long
- 99.9% of the cfDNA lines up to some segment of the patient’s germline DNA [from normal cells]; but no 2 of these segments are the same either
  - If you could lay their entire germline genome out, it would span miles and miles and miles
  - Peter remarks, “*So you have a whole bunch of 170 base segments that line up somewhere on that problem.  That’s a pretty interesting computational problem to me because 170 is not that big*.”
  - The cancer is only going to have maybe 100 mutations in the coding regions of the DNA
  - Having more than 10,000+ mutations in the whole genome would be unusual

***This process of finding mutations in cfDNA strikes Peter ase almost improbable given the few number of mutations that exist in the cancer… they would be easy to miss***

- Max agrees, this is one of the major challenges in the field
- His first paper in this field, back in 2014 addressed this problem
  - Published in *Nature Medicine*, [An ultrasensitive method for quantitating circulating tumor DNA with broad patient coverage](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4016134/)

![](https://peterattiamd.com/wp-content/uploads/2022/07/f5-maxdiehn.png)

**Figure 5.  Identifying mutations in a patient’s tumor and then looking for them in cfDNA to see if the cancer is still present.**  Image credit: [*Nature Medicine* 2014](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4016134/)

**History of work with cfDNA**

- cfDNA was first observed in the mid 1900s by a French group
- They could only find this in very advanced cancer patients because they were using very insensitive methods
- Even then they had the foresight to think this could potentially be useful
- Not much progress was made in the next 50-60 years because the amount of cfDNA was so small and methods were not available yet to measure it
- From 2005-2010 very sensitive [PCR](https://en.wikipedia.org/wiki/Polymerase_chain_reaction) methods were developed to look for single mutations
- For example, you look for a [p53](https://en.wikipedia.org/wiki/P53) mutation
  - The problem that arises is, how do you look for 1 mutation when there is less cancer genome present in the blood than normal/ germline genome?
  - There are lots of negative samples: it’s possible the mutation isn’t present in that particular blood draw
- The way they overcame this problem was fairly simple
  - They used next-generation sequencing technology to get the sequence for millions of molecules
  - Instead of looking for 1 mutation, they looked for dozens of mutations from the patient’s cancer in parallel
    - Compare looking for 1 to looking for 10
    - This actually increases the sensitivity by 10-fold (a whole order of magnitude)

***You don’t have to see all 10 mutations to know the cancer is there; you just need to see 1 mutation***

- These could be mutations in a coding or noncoding region of the genome
- What is beneficial is to have what’s called a truncal or clonal mutation
  - This is a mutation present in every cancer cell
- As cancer develops, it gets the first mutation then more and ultimately becomes cancer
  - It can have 10,000 mutations; these accumulate over time
  - Many of these mutations are present in all of the cells of the tumor
  - Even though they’re not driving the cancer, just because of the evolutionary history of the cancer, as cells divide these mutations are passed on to their progeny
  - Once the cell gets that final mutation that allows it to keep dividing forever, it keeps all those other 10,000 mutations

***It doesn’t matter which mutation they track, they just want a mutation that’s present in all the tumor cells***

- Peter notes, “*It’s interesting because driver mutations have surprising heterogeneity, right?*”
- Talking to [Steve Rosenberg](https://ccr.cancer.gov/staff-directory/steven-a-rosenberg) about this [on the podcast last year](https://peterattiamd.com/stevenrosenberg/), he was amazed at the nonoverlap of driver mutations
  - A lot of people have mutations in p53, but it wasn’t necessarily the driver
- This also gets back to the immunology‒ *how often are these mutations inducing antigens that are recognized by the immune system?*

## Cell-free RNA and Max’s vision for cancer detection from a blood sample [1:22:00]

**Cell-free RNA**

- There is also cell-free RNA (cfRNA)
- This field is much more nascent than the DNA field

*What advantages would cfRNA offer given the instability of RNA?*

- Max doesn’t think it has advantages in looking for mutations

**Max’s goal vision for cancer analysis from a blood sample**

- They want to determine as much as possible about a patient’s cancer from a blood draw
  - Even to the point where they don’t need to do a biopsy
  - This is currently science fiction
  - But if you extend their work decades into the future, that’s where they’re trying to go
- To get there they need to be able to measure things other than mutations
- Mutations are critical, but they’re only a small part of the puzzle
- Measuring RNA could tell you about which genes are on and off in the cancer theoretically
  - That is critically important too
- In the immunotherapy field, there are some markers expressed in the tumor cells that can basically hide the cancer from the immune system (like [PD-L1](https://en.wikipedia.org/wiki/PD-1_and_PD-L1_inhibitors))
  - This marker is not a mutational process in the majority of patients
  - It’s expressed from the [promoter](https://en.wikipedia.org/wiki/Promoter_(genetics)); expression is turned on in response to signaling or [epigenetic](https://en.wikipedia.org/wiki/Epigenetics) changes

*You can’t tell by looking at the sequence in DNA of PD-L1 whether the tumor has this marker*

- This is not a mutation marker
- They want to measure something in the blood to distinguish between an adenocarcinoma and a squamous cell carcinoma or between a lung cancer and a breast cancer
  - This could be done with cfDNA but using cfRNA might be better

- The use of cfRNA is fascination; they haven’t published their work yet but will soon

> “*In the future, RNA will be a big part of the liquid biopsy puzzle that doesn’t replace DNA, it offers complimentary pieces of information*”‒ Max Diehn

**Is there a difference between cell-free DNA and circulating tumor DNA or are these terms interchangeable?** [1:24:00]

- They are different
- Generally cfDNA refers to the total DNA in the circulation
  - That includes both the healthy cell-derived DNA and the cancer cell-derived DNA
- Circulating tumor DNA is a subfraction of the cfDNA, maybe 1% of the cfDNA is from the tumor

## Methylation patterns and other informative signatures found in DNA [1:24:30]

*What other signatures are helpful here?*

- They can look at the [DNA methylation](https://en.wikipedia.org/wiki/DNA_methylation) patterns in these 170 bp DNA fragments in circulation
- They can also look at chemical modifications of certain nucleotides (modified by enzymes)
- This is different in different types of cells
- Different cells, based on what tissue they are from will have different patterns of methylation
- DNA methylation influences which genes are turned on and off
  - You could envision that in a lung cell that needs to have the genes on for surfactant production or making alveoli or whatever, but it doesn’t need the to have the genes on to make fat because it’s not doing that (it’s not a fat cell)
  - Some genes are methylated and turned off in different cells, in different ways

***DNA methylation patterns can be exquisite marks of the origin of the DNA***

- Further, the methylation profile of 2 lung cancers is more similar than their mutation profile

**Peter’s takeaway:** *the methylation profile of 2 lung cancers is more similar than their mutation profile*

**The methylation profile could be used as a pan screen to identify a type of cancer**

- This is a different scenario than discussed earlier, different from wanting to know if the patient has been cured
- The sensitivity of the methylation-based approaches are significantly inferior to that of the mutation-based approaches
- But from a practical standpoint, the methylation approaches have some advantages for the screening question
  - The sensitivity and the practicality aren’t aligned
  - You’d want the most sensitive assay possible for screening because the tumors are tiny
    - This is not the current state in the field
    - Currently mutation-based methods are much more sensitive

## Mutation-based methods of liquid biopsies [1:26:30]

**Max recently published a new method, their 3rd-generation mutation-based method**

- Published in *Nature Biotechnology* in December 2021, [Enhanced detection of minimal residual disease by targeted sequencing of phased variants in circulating tumor DNA](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8678141/)
- It’s 100x more sensitive than than their prior methods (and other methods in the field)

***Now they can get down to 1 part in a million***

- With prior methods they were bottoming out at about 0.01%, so 1 in 10,000
- This 3rd-generation mutation-based method is a 2-log improvement in their diagnostic assay
- Now they are looking at samples left over from running their 1st-generation assay that came back negative‒ *asking which are false-negatives?*
  - How many of these samples can they now detect as positive?
  - It wasn’t that there was no ctDNA, they just couldn’t detect it before
- With the methylation-based assays, the data is still not very mature to know exactly what their sensitivity is
  - It’s probably closer to 1 in 1000, so 0.1% sensitivity

**Peter’s takeaway on mutation-based methods**

- With the mutation-based methods, you know what you’re looking for
- If you’re doing a pan screen for someone who doesn’t have cancer, you can’t know what mutation to look for
- A test like [GRAIL](https://grail.com/) looks at methylation patterns of cfDNA; they’re doing a pan screen
  - They take 10-20 ml of blood and look for all the cfDNA to identify if there’s cancer or non-cancer there
  - If they find cancer, they want to predict the origin of the tissue
  - The current sensitivity for all stages is probably 50% with a specificity of > 99%
  - But if you’re trying to catch an early cancer (stage 1), the sensitivity is maybe 20%

*How good are these tests?*

- We want a high specificity 95-99% and we want high sensitivity
- Max takes issue with studies that report sensitivity across stages because there is a bias to include more stage IV patients
  - You could include a single stage I patient and 99 stage IV patients and report a sensitivity of xyz for stages I-IV
- It’s important to report sensitivity for each stage
  - Within stage I it should be further broken down into stage IA, IB, and even stage IA1 and IA2
  - In lung cancer, actually the sensitivity for stage I lung cancer in the GRAIL data that’s been presented is actually 5% or less
- Peter points out, ***if the tumor is bigger than stage I, you don’t need a liquid biopsy because it can be seen with a low-dose CT scan… in theory, the only reason you’d care about a liquid biopsy is if we’re talking about fewer than a billion cells***

*Max sees an advantage in the blood-based tests because this is a way to get more patients screened*

## Understanding the sensitivity and specificity of a diagnostic test [1:30:30]

- If a test has 50% sensitivity and 99.5% specificity for detecting stage I cancer in an unbiased sample, that would be pretty good

**How Peter explains it to his patients**

- Say you’re 45, not a smoker, your family history is negative, and your colonoscopy is negative
  - You’re pretest probability of having cancer is 1%
- [Peter’s calculator](https://peterattiamd.com/how-to-interpret-screening-tests-video-spreadsheet-and-primer/) will allow you to plug in sensitivity, specificity, and prevalence, and it will spit out [positive and negative predictive values](https://en.wikipedia.org/wiki/Positive_and_negative_predictive_values)

⇒ Download the calculator [here](https://peterattiamd.com/wp-content/uploads/2020/04/BK-Testing-SEN-SPE-PPV-NPV-COVID-19-.xlsx)

⇒ Further discussion in [AMA #25](https://peterattiamd.com/ama25/)

EXAMPLE:

- For example with a test that has 55% sensitivity, 99% specificity and the prevalence is 1% the negative predictive value goes to 99.5%
- But this is only a little bit better than what was known without the test
  - With a 1% prevalence, this test moved you from 99% to 99.5% negative predictive value
- Also note that the positive predictive value is 40%
  - *The positive predictive value is the chance that the positive result is not a false positive*

***Peter never uses these tests in isolation for his patients***

**Are these liquid biopsies useful without the mutational information that makes them so sensitive?**

- Max agrees, these are excellent points
- Not only is the sensitivity and specificity of tests hard to understand for patients, but it’s not well understood by a lot of researchers and physicians
- 50% sensitivity and 99% specificity sounds great, evening ignoring the fact that stage I sensitivity is < 5%
- Even at a 50% sensitivity for a patient that has no risk of cancer (less than 1% of them will have cancer) this test isn’t really moving the needle significantly
  - It has a high risk of false positives because the positive predictive values isn’t so good
  - False positive results lead to a lot of testing anxiety
  - If follow-up tests can’t find anything, the patients are worried for years that something might be brewing

> “*I really strongly feel that we as the field need to do studies that prove cancer-specific survival benefits of these tests*”‒ Max Diehn

- Currently this is not on the roadmap
- There are many commercial efforts but they’re not planning [large randomized trials (RCTs) like were done for low-dose CT scans](https://www.nejm.org/doi/full/10.1056/NEJMoa1911793)
  - Why not?
  - Because they take years to complete and are expensive
  - It’s not attractive from an investment standpoint

***We need to do RCTs on these liquid biopsies to learn if they are good enough to save lives***

> “*We really want to be sure that we are helping our patients and we’re not just adding costs to the healthcare system*”‒ Max Diehn

- RCTs will help us do this

**The benefit of liquid biopsies is complicated and this is why we need randomized trials**

- Consider stage I lung cancer patients, there’s 2 types of stage I lung cancer
  - 1) Where the cancer cells have not left the lung; the surgeon removes the tumor and the patient is cured
  - 2) This type looks the same but there are microscopic tumor cells in the liver and brain that we don’t know about
- In order for a screening test to be useful, it has to catch a significant fraction of the 1st type of stage I, the type without micrometastases (which the surgeon can cure)
- The surgeon cannot cure the 2nd type
  - They can only cure what they can see
  - They don’t know about the micrometastases in the liver, brain, etc.

***That is why simply saying a test increases the number of patients diagnosed at earlier stages, doesn’t automatically prove that that test will save lives***

- You have to look at the granular  level and consider there are different kinds of stage In patients
- You can  envision a test that mainly catches the patient with micrometastatic disease
  - We have hints that the ctDNA assays preferentially catch those patients
- The way to prove that tests are not falling into that pitfall is to do randomized studies

> “*We don’t know yet if they’re going to save lives*”‒ Max Diehn

- People argue it isn’t unethical to use these tests because if we find out 5 or 10 years from now that they save lives and we didn’t use them, that’s 5-10 years of patients who didn’t have its benefit
- The problem with that argument (which sounds ethically reasonable) is this means we would never test anything new developed in medicine, because there’s always a possibility that this new thing could improve patient outcomes
- Peter notes, “*I think that’s why the FDA has taken the posture because right now there are only 4 approved liquid biopsies*”
  - [Guardant](https://guardanthealth.com/) and 3 others
- Max points out these tests are for very different things, for genotype
  - These are for identifying what mutations are present in patients with advanced disease

## Existing clinical liquid biopsy tests and their limitations [1:37:30]

**Guardant**

- The [Guardant assay](https://guardanthealth.com/) was one of the first in the field
- They use next-generation sequencing to measure circulating tumor DNA (ctDNA)
  - Similar to what Max’s group does
- Their initial test (that’s FDA approved), was developed for a very specific clinical problem
  - You have a patient with metastatic cancer, let’s say lung cancer
  - The cancer is in multiple parts of the body, and you want to identify what mutations that patient has
  - This is actionable because in lung cancer, there are drugs that work for patients with certain mutations
    - Historically, a biopsy was needed to get a piece of the tumor to identify the mutations
- Guardant (and Max and others) have shown that in many patients with advanced disease 1% of the ctDNA is from the cancer
  - And that’s enough to identify the mutations
  - No need for a biopsy

***This is useful in patients who can’t have a biopsy or where they had a biopsy, but all the tissue is used up; or where the biopsy missed the tumor (which happens a lot)***

- For example, the liquid biopsy may identify that the patient does have an [EGFR](https://en.wikipedia.org/wiki/Epidermal_growth_factor_receptor) mutation, so they should be treated with a EGFR [tyrosine kinase inhibitor](https://en.wikipedia.org/wiki/Tyrosine_kinase_inhibitor)
  - Max notes, “*That is the easiest problem in the liquid biopsy space, because you’re in stage four patients that are known to have cancer. They have… a high tumor burden.  And so, the tests are optimized for that; they work well for that*.”

***Liquid biopsies have an 80% agreement with a traditional biopsy; they’re a good test for this problem***

**Liquid biopsies are not designed for early cancer screening or detection**

- They are *not* designed for situations where the levels ctDNA are many logs lower

***They’re not designed for this question of is the patient cured or not after treatment***

- Again where the levels of tumor DNA are much lower, the FDA approved tests don’t detect this well

**Is this true of the other FDA-approved tests, CellSearch and FoundationOne?**

- Yes
- [Foundation](https://www.startwithstepone.com/about-the-test) has a liquid biopsy test, very similar to what we developed in Guardant and they do the same thing now
- [CellSearch](https://www.cellsearchctc.com/) is actually a circulating tumor cell assay
  - It was FDA approved before any ctDNA assay
  - We had talked about circulating tumor cells at the beginning of the liquid biopsy field
  - Circulating tumor cells were the focus of the field in the early 2000s, and so that’s why that was the first test

> “*No one really uses it because it doesn’t provide you actionable information*”‒ Max Diehn

- Your doctor runs that test; whatever the result is doesn’t impact how the patient is treated

***There is a difference between FDA approval and actually clinical usefulness***

**A test like GRAIL is not FDA approved yet its use is still permitted**

- This is a complicated area in diagnostics
- There are 2 ways the US government regulates tests
- 1) FDA approval
  - This focuses on approving drugs and diagnostic tests
  - The FDA evaluates them carefully, gives approval, and allows companies  to market them if they pass the bar of what they need to show
- 2) Set up the assay in a lab that is compliant with the [CLIA Act (Clinical Laboratory Improvement Amendments)](https://en.wikipedia.org/wiki/Clinical_Laboratory_Improvement_Amendments)
  - This is an easier way to get assays to patients
  - This relies on an act of Congress that focuses on regulating laboratories that do diagnostic tests
  - It is independent of the FDA
  - Labs get this designation and are inspected every year of 2 to make sure they’re doing things appropriately
  - These labs now have the blessing to develop any test they want and offer them to patients
  - They’re supposed to run controls but the FDA never reviews them
  - The laboratory is regulated but not the individual test
  - This is what Guardant did before they got their FDA approval
  - This is what [GRAIL](https://grail.com/) is doing

***This allows laboratories to sell tests to patients and providers long before they get FDA approval***

- Peter notes, there are 30 other companies out there doing this right now and from a technology standpoint, the holy grail is a blood test that will screen patients (who don’t think they have cancer) with enough sensitivity and specificity to identify cancer
  - If it were colon cancer, the patient would then get a colonoscopy to identify the tiny adenomatous polyp in early stage I
  - They would then get the smallest partial colectomy and be cured
  - Or a woman who had a negative mammogram 6 months ago could be identified with a blood test then go get a [diffusion weighted image MRI](https://en.wikipedia.org/wiki/Diffusion_MRI) to identify the cancer

> “*What would really be amazing is if we had the confidence in these things that even if they were never showing up on imaging, you could treat them*”‒ Peter Attia

- For something like [pancreatic adenocarcinoma](https://en.wikipedia.org/wiki/Pancreatic_cancer) this type of early detection would save lives
  - The 5 year survival rate of even a 1 cm pancreatic adenocarcinoma has a 25% five year survival is only 25%
    - This is a death sentence of a cancer, even at stage 1
    - So waiting until you can see a billion cells on a CT or MRI is not going to work
  - Peter notes, “*It’s either going to be much earlier detection or treatments that actually work… today we have neither of the above*”

## The future of liquid biopsies [1:44:00]

**Is there a path to this sci-fi world where using blood alone can detect cancer in patients 3-4 years earlier than what’s clinically possible now?**

- Max is hopeful and notes, “*It’s not going to come in one step, but we are already taking steps towards that, sort of building the bricks on top of each other*”
- The easier application of this is in patients who already have known cancer
  - We have super sensitive tests we can run after treatment to see whose cured or not
  - These detect the state that’s called minimal residual disease, meaning microscopic cells that are residual after your treatment and that have currently at least very high, positive, predictive value
    - If you detect ctDNA, that patient is very likely to have the cancer grow back
- There are clinical trials underway now to see how this can guide therapy
- Max has launched a couple trials recently at Stanford with early stage lung cancer patients
  - After their standard care (chemo &/or radiation) they get a blood test
  - If it’s positive, those patients get immunotherapy
    - Cancer cannot be detected in these patients, but the blood test indicates microscopic cells are left behind
    - This is the moment in the patient’s lifetime with their cancer, that they will have the least  number of tumor cells, the fewest mutations, the lowest heterogeneity
    - At this moment, they have the lowest chance of resistance

***Max is hopeful they will be able to cure more patients with this type of follow-up***

- It is known that giving even the same drug in [adjuvant therapy](https://en.wikipedia.org/wiki/Adjuvant_therapy) is more effective than when it’s used for treating metastatic cancer

**The value of early detection and early treatment**

> “*Early detection absolutely matters … less tumor burden, less heterogeneity equals better outcomes*”‒ Peter Attia

- Peter notes this is an important point that gets lots on many people in the field, the value of early detection
  - He’s never seen it refuted
  - Early detection equals better outcomes

*Why cancers respond better to treatment initially*

- Cancers become resistant because of genetic heterogeneity
- All cancer cells in the tumor are not the same; they already have mutations
- Max explains, “*The more cancer you have, the higher chance that one of those mutations will make the cancer resistant to whatever therapy you’re using.  So this idea of guiding adjuvant therapy based on ctDNA MRD I think is the first step towards the future that you’re envisioning.*”

**Using liquid biopsy after cancer treatment will be useful for guiding adjuvant therapy for some cancers**

- Peter notes, it won’t be useful in pancreatic cancer because everybody’s probably going to need adjuvant therapy
- It will certainly be relevant in lung cancer, breast cancer, colorectal cancer
  - Maybe even in prostate cancer, although the treatment is pretty bad
  - These are the big 5 in cancer
  - Max adds bladder cancer (the 6th or 7th most common cancer) and melanoma

> “*It’s going to be useful in the cases where a minority of patients develops recurrence*”‒ Max Diehn

- - A situation like pancreatic cancer, where the vast majority of most stage I patients will develop recurrence, that’s not the place to start developing this kind of a test
    - Because the tests aren’t ever going to be a 100% perfect
    - No test gives you 75% chance of recurrence
  - This test is useful where there’s a subset of patients that recur
  - For cancers where the vast majority of stage I patients develop recurrence (such as pancreatic cancer), this is *not* the place to develop this kind of test

- *When we know the probability of recurrence is high enough, everyone gets adjuvant therapy*

- - Tests are never going to be 100% perfect
  - No test give you a 75% chance of recurrence
  - Stage III colon cancer is another example where we don’t need the test, everyone gets treated
  - Stage I and stage II cancers are a different story

***Peter’s takeaway: we’ve identified one problem that can be addressed with liquid biopsies, identifying the high risk patient who needs adjuvant therapy.  Great progress has been made with lung cancer.***

**What is the state of the art for this problem in breast, prostate, and colorectal cancer?**

- There are active studies underway
- Colorectal cancer might be the furthest along
- There are some Medicare approved tests using ctDNA from a company called [Natera](https://www.natera.com/oncology/signatera-advanced-cancer-detection/) for colorectal cancer
  - This was recently approved even though proof of benefit hasn’t been shown yet
- There are trials in breast cancer to do similar things

**Challenges presented by breast and prostate cancer**

- 1) They have very low levels of ctDNA

***There’s difference between tumor types and how much ctDNA they shed***

- These require very, very sensitive mutation-based methods
- Studies are ongoing in breast cancer, Max is not aware of any for prostate cancer
- Peter notes, “*Prostate seems to be a very privileged site. Even the GRAIL test… doesn’t screen effectively for prostate because you’re just not getting enough cell-free DNA in the circulation.*”
- The development plan for [GRAIL](https://grail.com/our-products/) was initially focused on breast cancer but they pivoted to other cancers because the early results in breast didn’t go well

**Who is the next group of patients Max wants to develop a liquid biopsy for?**

*Would it be patients who have completed adjuvant therapy (or who were deemed low enough risk to not need adjuvant therapy) but are still higher risk in the population in whom you’re screening for recurrence?*

***We need results from these early studies to provide proof of principle that this approach works***

- This would be the next logical step
- Max can envision a future where patients at higher risk of recurrence are tested repeatedly, say every 3 months
  - They don’t get adjuvant therapy until the test is positive

***Maybe this can minimize missing patients and still catch them months before they have clinical recurrence***

- This would be better because you’re not giving toxic treatment to a big chunk of patients, only those who test positive

- A 2nd approach Max is excited about uses the same set of trials but looks at it the other way around

***Test patients to avoid overtreatment***

- One big problem in adjuvant therapy (breast cancer is a good example) is the [number needed to treat (NNT)](https://en.wikipedia.org/wiki/Number_needed_to_treat) is quite high
  - Most patients are cured by the surgeon and don’t have micrometastatic disease
- Second, the the aren’t perfect, some patients with micrometastatic disease don’t benefit
- Repeated liquid biopsy testing could help with the overtreatment situation and help treat only patients where there is substantial evidence they still have cancer cells in their body

## How we get to the panacea of cancer screening [1:52:00]

**We need a different approach to move to the panacea of cancer screening using a blood test**

- Imagine if every person got a test from their doctor each year which could tell them yes/no they have cancer from 10-20 mL of blood
- Further, this test could tell them the organ of the cancer’s origin
  - This would direct further diagnostics

*Thinking of mutation analysis, is it possible to develop a robust database of mutations for every given tumor?*

- Over a year ago Max’s group published a paper where they developed a mutation based lung cancer screening method using ctDNA called Lung CLiP
  - CLiP stands for **c**ancer **l**ikelihood **i**n **p**lasma
  - Published in *Nature* in 2020, [Integrating genomic features for noninvasive early lung cancer detection](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8230734/)
- This method is purely based on mutations
- How it works‒ sequence the plasma and the white blood cells of the patients you’re trying to screen
- 1) Sequence both the cfDNA, cell-free DNA, and the leukocyte DNA
  - They’ve learned (particularly in older individuals) that there are mutations present in the leukocytes often that have been acquired through age through a process called [clonal hematopoiesis](https://en.wikipedia.org/wiki/Clonal_hematopoiesis)
  - So those mutations that are in the white blood cells end up showing up in the plasma most of the time because the white blood cells die in the circulation and release their DNA and that’s part of the cfDNA
  - *These mutations are not coming from the cancer; so you want to get rid of these from the testing process*
- 2) Subtract the things that are in the white blood cells
- 3) Then use a machine learning algorithm that looks at the mutations that are left in the plasma and looks at things like the length of the cell-free DNA molecule (in base pairs, bp)
  - Max and others have shown, that the cancer derived cfDNA molecules are a little bit shorter than that 170 bp
  - 80-90% of the cfDNA in the blood comes from white blood cells, 10-20% comes from solid organs and cancer
  - Probably DNA from the cancer has to traverse longer to get into the blood; cells could die in the tissue and it takes the cfDNA a while to get into the blood where it is exposed to enzymes that cleave the DNA (discussed earlier)
    - It may also be something about the way the histones and chromatin is configured that contributes to the length of DNA

***They look at the mutation present, what gene is it in, how long is the cfDNA fragment and the machine learning model tells them if they have seen this mutation before in lung cancer and the model ultimately determines a probability that that blood sample was from a patient with lung cancer or not***

- Max envisions this mutation based screening approach where *you’re not actually using a catalog of mutations* because that won’t work because every cancer is unique and you can have a mutation in any gene in any position
- *The machine learning is used to predict what would be a cancer mutation or not*
- In the follow-up work, he is trying to add more features
  - *The more features you have that link with cancer, the better it is*
  - Could this be combined with methylation analysis?
  - Can it be combined with other analytes or approaches?

**Max’s takeaway:** “*We’re going to move forward to try to ultimately develop the best screening test and it very likely will be a combination of not just methylation or just mutation or just what’s called fragmentomics (which is this size of the molecules or their distribution).  It likely will be a combo method.  That’s still very much in the early research phase.”*

**What might be the theoretical limits of this?**

- Max doesn’t know
- One critical experiment (currently underway), is to take the 3rd generation method he mentioned (that has the 1 in a million sensitivity) and apply it to a large cohort of stage I patients and see how many of those patients they can detect dtDNA in, when they know the mutation
  - This is not a screening question but a preamble to it where they can definitively quantitate ctDNA in these patients in stage I
  - This experiment will tell how much ctDNA patients are shedding during stage I lung cancer
  - This will show the specificity of this approach
- Max is hopeful they can push it to above the 5% sensitivity discussed earlier
- Their [study](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8230734/) from a couple years ago showed they could get about 20% sensitivity
  - This included stage I non-small cell lung cancer in a validation cohort
  - The specificity was about 98%

**Back of the envelope math**

- If someone has a pretest probability of 1%, you’re going to need 80% sensitivity and 99.5% specificity to say that a test matters
  - You need a high enough positive predictive value to do something with
  - Just as important is the negative predictive value; this needs to be high enough to reassure that disease is not present
- Max replies, “*It’s possible we can’t get there with this approach. If you had asked this question in the fifties with some of the protein biomarker work, which was exciting, people would’ve said, well, okay, we’re not there but maybe in 10 years we will*.”
- Currently we don’t know the real distribution of ctDNA because most of the experiments used insensitive methods where most of them are negative
- Max is hopeful we can get to at least 50%
- Peter agrees, 50-75% detection in early stage I cancer would be a big step forward
  - If you can keep the specificity > 99%
- Some liquid biopsy groups have gone with 80 percent specificity
  - Because if we advertise it has a 99% specificity and a 20% sensitivity, but now you drop the specificity to 80, then your sensitivity management goes up by 20% because just the dumb luck part

***The problem is the negative predictive value goes out the window***

**The foreseeable future**

- There are 2 main ways to apply these types of liquid biopsies
- 1) In cancers that currently lack a screening test, where the bar of success is much lower
- Most screening methods aren’t perfect
  - Mammography, low-dose CT
  - Colonoscopy is a bit of an exception, it’s better
  - But these screening methods have been shown to save lives for lung cancer and colon cancer
  - Breast cancer screening is more controversial
- The ideal case would be pancreatic cancer (for reasons discussed earlier)
- There are other cancers we don’t screen for

*How this test compares to current screening tests will be important*

- ***Currently, the liquid biopsies aren’t as good as those tests***

**The use of liquid biopsies should start around some practical consideration or health system consideration**

- We know only a tiny minority of patients who are eligible for low-dose CT currently get one, in the US
  - People are concerned about radiation exposure and don’t get this test even though Medicare pays for it
  - Maybe the problem is  the difficulty in booking an appointment or access to the imaging facility
- If the patient is already at the doctor and having their [hemoglobin A1c](https://en.wikipedia.org/wiki/Glycated_hemoglobin) tested or whatever, it’s easy to draw another couple tubes of blood for a liquid biopsy
  - This is not the dream application of liquid biopsies but it is helpful
- *We still need to prove again that these tests decrease cancer-specific death*

**Do you know of any companies out there that are in pursuit of this dream scenario where you have a high sensitivity and high specificity test for early stage I cancer detection?**

- All companies working on this are trying to improve there tests constantly
- They’re being run in the CLiA environment and it’s much easier to change the test than if it’s under FDA approval
- Max’s group is working hard on this

***It’s too early to know how much they’re going to push the bar over what Max showed in that prior paper or what*** [***GRAIL showed in their recent papers***](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8304888/)

**How much money is the NIH putting into this?**

- Great question, Max has never seen numbers for how much funding they are putting into liquid biopsy research
  - It has increased dramatically
  - When he started working in this area (around 2012, their [first publication](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4016134/) was in 2014) and went to meetings, he would be the only person talking about ctDNA
    - There field was focused on diagnostic imaging and circulating tumor cells
  - Now the vast majority of presentations are focused on liquid biopsies
  - In the NIH study section he sits on (focused on cancer biomarkers), he sees lots and lots of liquid biopsy work submitted and often scoring high

> “*There’s a lot of interest at NCI and NIH; they see the value just like many of us do*”‒ Max Diehn

§

## Selected Links / Related Material

**Foresight Diagnostics, developing novel liquid biopsy tests**: [Foresight Diagnostics](https://foresight-dx.com/) | [1:00]

**CyberMed, biotech specializing in discovery of biomarkers**: [CiberMed](https://cibermed.com/) | [1:00]

**Episode of** ***The Drive*** **with Karl Deisseroth**: [#191 – Revolutionizing our understanding of mental illness with optogenetics | Karl Deisseroth M.D., Ph.D.](https://peterattiamd.com/karldeisseroth/)  | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (January 17, 2022) | [15:30]

**Method to identify cancer mutations in cfDNA**: [An ultrasensitive method for quantitating circulating tumor DNA with broad patient coverage](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4016134/) | *Nature Medicine* (AM Newman *et al.* 2014) | [1:19:00, 2:03:00]

**Episode of** ***The Drive*** **with Steve Rosenberg**: [#177 – Steven Rosenberg, M.D., Ph.D.: The development of cancer immunotherapy and its promise for treating advanced cancers](https://peterattiamd.com/stevenrosenberg/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (September 27, 2021) | [1:21:30]

**3rd-Generation detection of circulating tumor DNA**: [Enhanced detection of minimal residual disease by targeted sequencing of phased variants in circulating tumor DNA](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8678141/) | *Nature Biotechnology* (Dm Kurtz *et al.* 2021) | [1:26:45]

**AMA 25 of** ***The Drive*** **on cancer screening**: [#170 – AMA #25: Navigating the complexities and nuances of cancer screening](https://peterattiamd.com/ama25/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (July 26, 2021) | [1:31:15]

**Effect of low-dose CT screening for lung cancer on mortality, RCTs**: [Reduced Lung-Cancer Mortality with Volume CT Screening in a Randomized Trial](https://www.nejm.org/doi/full/10.1056/NEJMoa1911793) | *New England Journal of Medicine* (HD de Koning *et al.* 2020) | [1:34:00]

**CLiP, lung cancer screening using ctDNA**: [Integrating genomic features for noninvasive early lung cancer detection](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8230734/) | *Nature* (JJ Chabon *et al*. 2020) | [1:53:00, 1:58:15, 2:02:30]

**GRAIL’s Galleri multi-cancer early detection test, recent results**: [The PATHFINDER Study: Assessment of the Implementation of an Investigational Multi-Cancer Early Detection Test into Clinical Practice](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8304888/) | *Cancers* (JA Borgia *et al.* 2021) | [2:02:45]

**Max’s lab website**: [Diehn Lab](https://med.stanford.edu/diehnlab.html) | Stanford Medicine

**Max’s faculty profile**: [Maximilian Diehn, MD, PhD](https://profiles.stanford.edu/maximilian-diehn) | Stanford Profiles

3.5 min video on liquid biopsies [vimeo](https://vimeo.com/209107188)

**Recent news about publications by Max’s lab**: [In the News](https://med.stanford.edu/diehnlab/news.html) | Stanford Medicine: Diehn Lab

**Liquid biopsy tests are currently offered by**:

- [GRAIL](https://grail.com/), a pan screen of methylation patterns of cfDNA | *not* FDA approved
- [Guardant](https://guardanthealth.com/) uses next-generation sequencing to measure ctDNA | FDA approved
- [Foundation](https://www.startwithstepone.com/about-the-test) offers a test similar to Guardant | FDA approved
- [CellSearch](https://www.cellsearchctc.com/) is a circulating tumor cell assay, approved before any ctDNA assay | FDA approved]
- [Natera](https://www.natera.com/oncology/signatera-advanced-cancer-detection/) test detects ctDNA from colorectal cancer | *not* FDA approved

**Max’s recent work on epigenetic expression inference from cell-free DNA-sequencing (EPIC-seq) to classify lung cancer subtypes**: [Inferring gene expression from cell-free DNA fragmentation profiles](https://pubmed.ncbi.nlm.nih.gov/35361996/) | *Nature Biotechnology* (MS Esfahani *et al.* 2022)

**Max’s review of liquid biopsy analysis of ctDNA for predicting cancer relapse**: [Detecting Liquid Remnants of Solid Tumors: Circulating Tumor DNA Minimal Residual Disease](https://pubmed.ncbi.nlm.nih.gov/34785539/) | *Cancer Discovery* (EJ Moding *et al.* 2021)

**Max’s review of the technology used for liquid biopsy detection of cancer**: [Detection and Diagnostic Utilization of Cellular and Cell-Free Tumor DNA](https://pubmed.ncbi.nlm.nih.gov/33228464/) | *Annual Reviews of Pathology*(JC Dudley and M Diehn 2021)

§

## People Mentioned

- [Patrick (Pat) Brown](https://en.wikipedia.org/wiki/Patrick_O._Brown) ([Emeritus Professor of Biochemistry](https://profiles.stanford.edu/patrick-brown?tab=research-and-scholarship) at Stanford and founder of [Impossible Foods](https://impossiblefoods.com/)) [5:45]
- [Howard Chang](https://profiles.stanford.edu/howard-chang) (Professor of Cancer Research and Genetics at Stanford) [11:30]
- [Karl Deisseroth](https://profiles.stanford.edu/karl-deisseroth?tab=bio) (Professor of Bioengineering and of Psychiatry and Behavioral Sciences at Stanford) [15:30]
- [Henry Kaplan](https://nasonline.org/member-directory/deceased-members/53979.html) Chair of Stanford’s Radiology department from 1948-1972 and director of Stanford’s Cancer Biology Research Laboratory in 1975) [17:45]
- [Caroline Dive](https://www.cruk.manchester.ac.uk/Our-Research/Cancer-Biomarker-Centre) (Professor of Cancer Pharmacology at the University of Manchester, Deputy Director of the Cancer Research UK (CRUK) Manchester Institute) [59:00]
- [Dennis Lo](https://www.cuhk.edu.hk/med/cpy/Research/DennisLo.htm) (Director of the Li Ka Shing Institute of Health Sciences and Professor of Medicine at the Chinese University of Hong Kong) [1:03:30]
- [Stephen (Steve) Quake](https://quakelab.stanford.edu/) (Professor of Bioengineering and Applied Physics at Stanford University) [1:03:30]
- [Steven Rosenberg](https://ccr.cancer.gov/staff-directory/steven-a-rosenberg) (Chief of surgery and head of tumor immunology at NCI) [1:21:30]

§

![](https://peterattiamd.com/wp-content/uploads/2022/07/bio-image-maxdiehn.jpeg)

##### Max Diehn, M.D., Ph.D.

Max Diehn earned his Artium Baccalaureus (AB) in biochemical sciences at Harvard in 1997.  He earned his MD PhD at Stanford University in 2004, focusing on Biophysics.  He completed an internship in internal medicine at Stanford in 2005 and his residence in radiation oncology at Stanford in 2009.  He is a board certified radiation oncologist and Professor of Radiation Oncology at Stanford.  [[Stanford|Profiles](https://profiles.stanford.edu/maximilian-diehn?tab=bio)]

The overarching research goal of the Diehn lab is to develop and translate novel diagnostic assays and therapies to improve personalized treatment of cancer patients. Their main focus is on the development and application of liquid biopsy technologies for non-invasive detection, monitoring, and characterization of human cancers, with a special emphasis on lung cancer. Diehn’s group is an internationally recognized leader in this field and they collaborate with investigators from around the world to apply our assays to diverse clinical problems and patient cohorts. In parallel he also studies primary and acquired resistance to anti-cancer therapies, including radiotherapy, immunotherapy, and targeted agents. He has a particular interest in overcoming resistance mediated by the NRF2 (NFE2L2)/KEAP1 pathway. His research projects always begin by identifying an unmet need in the clinical management of cancer patients. His lab uses next generation sequencing, bioinformatics, genome editing, high throughput screening, and preclinical animal models to address their research goals. Discoveries from his group are currently being tested in multiple clinical trials at Stanford and elsewhere to attempt to translate them into the clinic. [[Diehn Lab](https://med.stanford.edu/diehnlab.html)]

Twitter: [@max\_diehn](https://twitter.com/max_diehn)