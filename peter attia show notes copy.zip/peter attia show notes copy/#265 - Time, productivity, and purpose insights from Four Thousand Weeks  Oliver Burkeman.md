# #265 – Time, productivity, and purpose: insights from Four Thousand Weeks | Oliver Burkeman

**Source:** [https://peterattiamd.com/oliverburkeman/](https://peterattiamd.com/oliverburkeman/)

---

Oliver Burkeman is the author of The *New York Times* best-seller [*Four Thousand Weeks: Time Management for Mortals*](https://www.amazon.com/Four-Thousand-Weeks-Management-Mortals/dp/1250849357/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1686916362&sr=8-1). In this episode, Oliver delves into the pervasive idea that time can be mastered, exploring whether maximizing productivity is an attainable goal or a perpetual trap. He discusses the allure of attempting to control time—and, therefore, the future—and shares his personal journey of experimenting with diverse time management techniques that failed to deliver the emotional satisfaction he sought. Ultimately, they explore the mismatch between being a finite human and existing in a world of infinite possibilities and how all of these concepts intertwine with finding a sense of purpose and meaning. Additionally, Oliver shares insights from his book on productivity, using our time wisely, and embracing our finitude to live a more fulfilling life.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](http://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://podcasts.google.com/search/peter%20attia%20drive) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](http://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/oliverburkeman/the_Drive_public.png)

Play

#265 - Time, productivity, and purpose: insights from Four Thousand Weeks | Oliver Burkeman

#265 - Time, productivity, and purpose: insights from Four Thousand Weeks | Oliver Burkeman

1x15s30s

0:001:50:09

## We discuss:

- Oliver’s experience that led him to write the book Four Thousand Weeks [3:15];
- Human’s relationship with time and the struggle with the finite nature of time [7:15];
- How productivity can be a trap [11:00];
- The fallacy that being more efficient will open up more time and bring a feeling of control [16:45];
- The paradoxical nature of trying too hard to be present in the current moment [22:45];
- The value of relationships in meaningful experiences and fulfillment, and how time gets its value from being shared [26:45];
- The importance of time synchronicity [36:00];
- Identifying your biggest priorities and the paradox of wanting to do more than you have time for [41:00];
- Oliver’s moment of clarity in 2014 [47:15];
- The role of a sense of purpose in fulfillment [50:15];
- Reconciling the finite nature of time and letting go of trying to master your time [59:00];
- Why we tend to have a future-focused attitude and how to combat that with atelic activities [1:05:45];
- The power of shifting your perspective about time and your experiences [1:12:45];
- How to operationalize the three principles for the dilemma of finite time [1:20:15];
- Harnessing the power of patience in the face of a problem or experience [1:28:00];
- The value of incrementalism for being productive [1:34:15];
- Embracing your finitude with curiosity [1:38:00];
- Acting on an idea in the moment rather than letting the idea be the obstacle [1:41:15]; and
- More.

§

## Show Notes

**\*Notes from intro**:

- Oliver Burkeman is a journalist and author of three books, including the *New York Times* bestseller [*Four Thousand Weeks: Time Management for Mortals*](https://www.amazon.com/Four-Thousand-Weeks-Management-Mortals/dp/1250849357/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1686916362&sr=8-1)
- If you listen to this podcast, you’ve most likely heard Peter talk about this book because it’s one of the four books that he consistently buys in bulk and gives out to friends
  - The other three being [*Stillness is The Key*](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1689697500&sr=8-1) by Ryan Holiday, [*From Strength to Strength*](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=sr_1_1?crid=1C63EK713ZM0X&keywords=from+strength+to+strength+arthur+brooks&qid=1689697618&sprefix=From+S%2Caps%2C109&sr=8-1) by Arthur Brooks, and [*Die With Zero*](https://www.amazon.com/Die-Zero-Getting-Your-Money/dp/0358099765/ref=sr_1_1?crid=2D0N2WRLFRIAV&keywords=die+with+zero+bill+perkins+hardcover&qid=1689697715&sprefix=die+with+zero+bill%2Caps%2C92&sr=8-1) by Bill Perkins
  - He’s been fortunate enough to have [Ryan](https://peterattiamd.com/ryanholiday/), [Arthur](https://peterattiamd.com/arthurbrooks/), and [Bill](https://peterattiamd.com/billperkins/) on the podcast to speak about their books, and so he’s really excited to round that out by having Oliver on as well
- In this episode, we focus our conversation around Oliver’s book *Four Thousand Weeks* and this idea that we want to try to master time and whether or not that’s an illusion or not
- We speak about:
  - The evolution of how people began to keep time and why that mattered
  - If productivity is a distraction or a trap that can never be attained
  - Why it always feels like we’re just about to master our time, but then we never quite get there
- We speak about the various techniques people try to employ to control their time better and the role of productivity tools
- We talk about our desire to control the future, but how we only have a finite amount of time and those two things seem in stark contrast
- Lastly, we talk about how all of this relates to the idea of sense of purpose
- Peter adds, “*Of the four books that I often gift to people with this being one of them, in many ways, this is the one that’s the hardest for me to wrap my head around, and it’s the one that I’ve read the most*.”
- At the conclusion of this discussion with Oliver, it finally hit him why he struggles so much to understand this concept
  - He won’t let the cat out of the bag on what that is
  - But he has an epiphany at the end of this podcast where he explains to Oliver where his lack of comfort comes with this subject matter
- Peter hopes this resonates with those of you who share much of the struggle he shares, which is this desire to be the masters of our time, the desire to be productive, and why letting go of some of this can probably lead to a much more fulfilling life

## Oliver’s experience that led him to write the book *Four Thousand Weeks* [3:15]

- When Peter read [Four Thousand Weeks](https://www.amazon.com/Four-Thousand-Weeks-Management-Mortals/dp/1250849357/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1686916362&sr=8-1), there was a lot he could relate to because he’s definitely a productivity geek
  - He’s always kept lists
  - He loves pens and journals
  - He loves to organize
- Even at a young age (growing up), it was clear that there is almost pathological consequences to this because if things were not done, there would be emotional consequences

**Tell me a little bit about your experience in this arena**

- This sounds alarmingly similar to Oliver as a young adult
  - Feeling very motivated
  - Not realizing at the time obviously that it wasn’t just the normal way to try to get your homework done and get your college assignments in on time
  - This real sense that there must be a way of getting on top of his time and structuring his time that would enable him to deal with everything that was thrown at him
  - To not have to make difficult decisions and fail to placate certain people who are making demands
  - To not have to make any choices about which direction he was going in because he would be so efficient that he would do it all
- Oliver adds, “*You get to this place where you often feel very nearly like you are there, right? You feel like it might only be a month or two of really disciplined work before you’re going to be at… effortless productivity, but instead you end up sort of making fresh starts, introducing a new system, downloading a new app, buying a new notebook every month or two.*”
- He got into a position professionally where he could write about a lot of this stuff and continue to go deep into it
- This book is what came from exhausting that
  - Realizing that he’d tried a hundred different productivity systems and they hadn’t given him the emotional thing he was seeking

> “*Maybe there was a problem with the question I was asking rather than that I just hadn’t found the right solution.*”‒ Oliver Burkeman

- Peter recalls a line in the book, something to the effect of “*We teach what we most need to learn.*”
- That message is from [Richard Bach](https://richardbach.com/bio), who wrote [*Jonathan Livingston Seagull*](https://www.amazon.com/Jonathan-Livingston-Seagull-Richard-Bach/dp/0684846845/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1689862139&sr=8-1)
  - This book had a whole bunch of advice that Oliver needed to hear (and stills needs to hear)
- Oliver find it a little bit funny/awkward when people assume the book describes the daily state of serenity in which he lives his live, because he doesn’t
  - He still struggles with all of this stuff, but that’s what makes it interesting

***This question of how you orient yourself inside time in a finite life is endlessly fascinating and Oliver doesn’t feel like he’s resolved it all***

## Human’s relationship with time and the struggle with the finite nature of time [7:15]

- Peter returns to something Oliver said a moment ago, “*All this productivity, all of these hacks didn’t give you what you were looking for emotionally*”
  - For someone who didn’t read the book, this is a bit counterintuitive because the purpose of productivity is to get stuff done, to be more efficient
  - But for those who have read it, it makes a lot of sense
- Peter thinks this comes down to whether we consciously think about finitude or not
  - Subconsciously we are all aware of it at at all times
- How Oliver wrote about this through the lens of evolution is helpful
  - And how we go from an era when we didn’t keep time through the industrial revolution when all of a sudden timekeeping became essential
- Oliver agrees that the historical lens is really illuminating

***Oliver’s working hypothesis is that everyone has always struggled with being finite***

> “*We are these unique creatures as humans who are both fully material animals and at the same time can think about and know about the fact that we’re going to die one day*.”‒ Oliver Burkeman

- We are in a unique anguished situation
- We haven’t always had the kind of ideas about time that enable us to then try to use time management (or productivity or planning or scheduling) to try to **engage in emotional avoidance of that scary issue of our finitude**
- All the way back through the record of philosophy back to the ancient Greeks and Romans, there are people grappling with the fact that there is death
- But it’s only since the time running up to the industrial revolution (and certainly after it) that most people have thought about **time as a resource**
- So time is *not* just the medium in which your life unfolds
- It’s almost like there’s you and there’s time and it’s your job somehow to try to handle time in the right way
- You feel like you have an adversarial relationship with time, right?
  - Most people feel either hounded by all the stuff they’ve got to do in the time available or that there’s not enough to fill their time with
- But all of these things imply a relationship between you and your time, which is actually quite an odd notion once you really start to think about it ‒ the idea that it should be something separate

***At the root of Oliver’s argument is the idea that most of the stress (and the trouble and the anxiety and the lack of meaning) and the things that we encounter in our relationship with time come from pathological versions of this idea that time something for us to try to use as well as we can (or handle or manage or master)***

- Most of our deepest experiences as humans of truly **meaningful and fulfilling moments** seem to involve a kind of falling away of those concepts, and we are falling back into presence in this one moment that we have
- Of course, you need to think about time as a resource in order to do all sorts of things that we do in modern society
- But a lot of the **problems arise from thinking**, “*That is all time is and that there is some place in the future we can get to where we have finally nailed our relationship with it*.”

## How productivity can be a trap [11:00]

- The idea that it’s a distraction from something else is even more interesting
- The idea that it can never be fully attained is sadly true
- Those of us that have kids clearly observe young children playing in a way that is untethered from time as a separate entity, and yet somewhere along the way we’ve become inculcated with (maybe it’s to varying degrees) this sense of time mastery being important

**How and when do you think that occurs?**

*That we become inoculated with this sense that time mastery is important*

- Oliver assumes that it occurs in all different ways at different stages
- His son is six, but he has absolutely seen some glimmers of his own unhelpful attitudes to time
  - Maybe it’s passed on in the genes or in sort of subtle ways that he can’t clearly control
  - Sometimes his son gets into this place of wanting to know exactly what’s happening over the next 24, 48, 72 hours
- Oliver thinks it’s useful to look at the perspective that psychotherapy and depth psychology would point to
  - Which is that in various different ways as we grow up (and even when we’re raised by basically excellent parents), there are things that are missing from our sense of things that give us less than a completely comfortable secure sense of self-worth and of everything being absolutely fine in the world
    - There are people who have this much more extremely than others
  - But there’s something that you’re trying to fill by the time you’re a young adult
  - There’s something that isn’t quite ideal there
    - We use all sorts of things, some people use substance abuse to try to grapple with these things that feel like they’re missing

**Productivity and peace of mind**

- For people who feel that their value as people (that their right to exist on the planet or to feel that they are enough as human beings) is somehow dependent on their output and on attaining certain levels of accomplishment
  - These are the people [David Brooks](https://www.nytimes.com/by/david-brooks) calls “*insecure overachievers*”
  - These people are naturally drawn to this idea that they’ve really got to double-down on the technologies of time control to try to get as efficient as they can and process as much as they can
- There are other people for whom are deeply psychologically invested in *not* accomplishing things
  - In making themselves feel that they’re not part of that whole process of accomplishment, of becoming sort of a slacker in a very sort of proactive and deliberate way
- Oliver thinks in all sorts of different ways, we’re trying to plug in a lax, and the problems with that are going to manifest in different ways

***The obvious problem with productivity as a way to get to that kind of state of peace of mind is that there’s a complete baked-in mismatch between being a finite human being and existing in a world of effectively infinite possibilities***

- Infinite emails
- You could answer infinite ambitions
- You could have infinite places you could go if your self-worth is staked on trying to get your arms around all of that
- It’s actually an infinite quantity that’s just going to be an unending struggle

**What would you say to somebody who says it’s different?** [14:45]

*What would you say to some who says they can do this ‒ juggle these five projects and get their inbox to zero*

*What would you say to someone who says, “I just need more time. I’m right on the cusp of doing it, and if I just put my head down for the next six months, it’s going to be okay?”*

*How would you explain to them that’s a fallacy?*

- There are two ways into that:
- 1 – In terms of self-change and self-knowledge, ask, “*How’s that working out for you so far?*”
  - To some extent, these are kind of revelations of the middle of life because you have to have tried this out for quite a while
  - If you’re 20, telling yourself that the real part of life is still coming makes a certain amount of sense
  - When you’re in your 40s and you’re still telling yourself that the real part of life is coming later and this is still a dress rehearsal for that moment, it might not be as credible
- 2 – There seems to be a universal law that if all you do is become more efficient in any system, with nothing else being done in terms of how you select your priorities, that will attract more and more stuff to do into your life
  - So getting better at processing email at a faster tempo basically attracts more email into your life for fairly straightforward reasons
    - You reply to more people and they reply to your replies and you have to reply to those replies and you get a reputation in your organization or wherever it is for being very responsive on email, so more people email you
  - There’s this kind of unending aspect to it that occurs in lots of other domains besides email

***You’re not going to get through an effectively infinite supply of something by processing it more efficiently***

- In fact, the opposite is going to happen
- That’s why it always feels like this moment of mastery is just over the horizon, but it’s never quite where you are

## The fallacy that being more efficient will open up more time and bring a feeling of control [16:45]

- Peter adds, “*It’s a very deceitful feeling for anyone who’s struggled with it [time management]… because you really do feel at times you’re so close to just nailing it and then it will be different*.”
- Peter is one of those guys who tires to inbox to zero (never successfully)
  - He uses the [Pomodoro technique](https://en.wikipedia.org/wiki/Pomodoro_Technique)

**What are some of the other techniques that people are exploring as ways to defy the gravitational inevitability of what we’re talking about?**

- The Pomodoro technique is an approach where you divide your work time into 25 minute periods interspersed with 5 minute breaks
  - After you’ve done 4 of those, you take a longer break
  - It’s a way of boxing up your time
- The classic approach of time boxing involves giving every segment of your calendar a specific job
- And there are a hundred other of these kinds of techniques
- Many, many of them (including the Pomodoro technique) are totally great
  - There’s absolutely nothing intrinsically wrong with using this or that protocol as a way of structuring your day that might help you make the right choices
    - Understand how much time you have available
    - And therefore decide that certain things are more important uses of  that time than not
- If you read the writing of the guy who invented the Pomodoro technique, he’s very on board with this idea that ***it’s about turning time from being an adversary to an ally*** by just sort of seeing that your time already is made up of 25 minute periods and you could look at it that way
  - So it’s just a question of being explicit about that and making choices about what you’re going to put in those times and taking appropriate rests
- All of these techniques work as a way of lending order to the day
- The real problem you see again and again is that people see them as a kind of path to this salvation
  - They think they can ride this approach to life to the point of finally feeling like they’re doing enough, finally feeling like they’re the air traffic controller of tier lives

**That’s the problem Oliver mentioned in the book**

- In his early experiments with [David Allen’s](https://en.wikipedia.org/wiki/David_Allen_(author)) book [*Getting Things Done*](https://www.amazon.com/Getting-Things-Done-Stress-Free-Productivity/dp/0143126563/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1689873371&sr=8-1), Oliver was so fixated in this idea that he was somehow going to be able to do everything that he completely missed what David says very clearly early in that book, “*It’s about having too much to do and staying calm in the middle of having too much to do*”
  - This book kickstarted the modern phase of productivity writing
  - There’s so much great stuff in that book
  - Oliver thought it was a way to help him not have too much to do because he would’ve been managing to do everything

***We’re a certain kind of person who is drawn to take anything and co-opt it into this psychological project of trying to feel like we’re fully in control of our lives in a way that we can’t be***

- Oliver is fascinated to talk to Peter about this because it seems he could easily see that a lot of the more physiological, physical, biological stuff could easily be dragooned into a similar kind of project of feeling in total control of our situation
- Peter absolutely agrees and he writes about this in the epilogue of his [book](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1689873935&sr=8-1)
  - He writes that his obsession with this topic began 10-15 years ago
  - An obsession with the question, “*How do I run from death?*”
  - It was basically, “*I’m going to put my head in the sand and march my way towards something that deep, deep, deep down I know is impossible (which is immortality), but I’m going to focus so much on this thing that I’m not going to confront my fear of death or I’m going to confront my fear of death by shouting louder at that fear with this thing. And this thing is all the things I’m going to do to live longer.*”
    - A lot of people can relate to that for different reasons
- Peter has a slightly different take on this today, but he still struggles to watch people die and gets very sad
  - Just recently, someone he had on the podcast died
    - He was in his early 80s, so by most people’s standards he lived to and maybe slightly beyond normal life expectancy
  - It always bothers him when someone dies
- Intellectually, Peter’s knows that’s a very bizarre way to feel that way because he had his 4,000 weeks and he did a lot with those 4,000 weeks
  - He had a wonderful family
  - There’s nothing to mourn other than the fact that he’s not here
  - And yet he still has a sense of sadness about that
- Peter understands that part of that produces a distraction from what’s happening today
  - If you dwell on that too much, you miss out on the fact that the best thing you can do to honor the legacy or the memory or whatever, is to do your thing today

## The paradoxical nature of trying too hard to be present in the current moment [22:45]

- It feels like it’s the natural reaction at first when you sort of begin to realize that you’ve been **running into the future** for so long through these kinds of techniques and this approach
- You think, “*Surely what I have to do is the opposite of that,*” and that’s be really, really present
- You read books on **mindfulness** that say, “*When you are washing the dishes, when you’re loading the dishwasher, just do that thing, be present in that moment.*”
- And then you find there’s something sort of paradoxical about how the mind works in those contexts
  - As soon as you’re self-consciously trying to will yourself into the moment, then you are not doing it because what you’re actually doing is thinking about whether you are in the moment enough

**Oliver tells this absurd story in the book about getting to witness the Northern Lights in Northern Canada**

- He had been getting excited about it for several days of his trip
- When it finally happened, he was dragged out of the place he was sleeping in by some neighboring guests at 2:00 in the morning to see the northern lights
- First, he found himself trying really hard to be there and being very much aware that as a result he was not
- Then, he had stray thoughts that it looked like an old PC screensaver
- All these terrible thoughts totally ruined the sacredness of the moment because he had been so cognitively engaged with trying to “be there”
- By contrast, we can all point to moments in life, that perfect afternoon and things like this that were not planned
  - They were not because we set out to have a perfect day

**There’s a theme that runs through all this**

- It comes up thinking about rest and recreation and leisure
- It sounds like an annoying paradox

***There’s a sense in which you do have to be willing to “waste” time to make the “most” of time***

- You have to be willing to care a bit less about whether a given afternoon/weekend is spent in a deeply meaningful way in order to maximize the chances of lucking out into one of those deeply meaningful times, ***because you need to not be fixated on trying to force the matter***

*Is this experience something that can only be appreciated in retrospect or is that something that will also be appreciated in the moment?*

- Peter notes, “*You’re not going to achieve that sense of meaning by achieving.*”
  - Getting more things done on the to-do list is not going to be the path to make that happen

*What is that thing that we’re trying to make happen and do we know it when it’s happening?*

- That’s a really good question
- In Oliver’s immediate direct experience, ***“The best times in life are either best in recollection, in hindsight, or they are flow states in the moment.”***
- Can you be aware that you are in a flow state?
  - In some bodily sense, yes
  - But you’re not in them once you’re thinking too hard about them in a verbal way
- One of the strangest parts of this is that **happiness** feels like the wrong framing for what we’re talking about here

## The value of relationships in meaningful experiences and fulfillment, and how time gets its value from being shared [26:45]

- Oliver is always fascinated by those moments in people’s lives where somebody close to you is going through some sort of immediate, serious crisis
  - There’s nothing good about what’s happening
  - If you could have chosen for it not to be happening, it wouldn’t be happening
  - And then in the middle of this emergency, it’s just obvious that you’ve got some sense of knowing that you are in exactly the right place
    - Maybe your job is to do their dry cleaning
    - It might not be being a shoulder to cry on
    - It might be your job is something very mundane to just make your contribution to somebody weathering this crisis
  - Oliver has a reputation among his friends of being quite good in a crisis
    - Which feels very flattering until you think about it
    - What it really means is you are just incredibly ambivalent and indecisive in all other times
- It’s when you have a choice about what you should be doing that there is this great sense of second guessing and fretting and being indecisive
- Yet we all have these experiences when choice is taken away, when it’s incredibly obvious what you should be doing to help in that moment
  - Which are in some sense deeply fulfilling, even though they’re not happy

***There’s a clue there to what we are looking for in other times of life; it’s this sense that there’s not any option of manipulating our experience (fitting a few more things in or worrying whether we’re missing out on something else)***

- All of that goes away in those times of crisis

**Can that fulfillment exist without some interaction with another person?**

- The examples Oliver gave require that you are there to help another person
- Peter rates himself as a 10 out of 10 introvert, but the truest joy he has is with others
- This makes him wonder if what we’re talking about is the relationship of *not* just time, but time with others
- For example, he plays this game with patients where he asks them, “*If  you could be in perfect health indefinitely, we’re going to grant you eternal life, but you have to do it on a desert island. Now it’s a great desert island because you don’t have to find your own coconuts. Like everything you want is there. So we’ve somehow solved every problem and away from the island there are robots churning away, giving you everything you need. So you’ve got your Netflix, you’ve got your food, you’ve got your, to your heart’s content, you can have anything. The only thing you can’t have is another human being. Are you happy?*”
  - Most people only think about this for a few minutes before they come to the conclusion, “*No. It would be very difficult to be happy.*”

*What do you think about that, and what does that tell us here?*

- Oliver thinks what they are talking about can only happen in some form or relationship
  - Even a relationship with parts of yourself
    - For example, when people are journaling they may be in a relation with unconscious parts of themselves
  - You can be in relationship with the natural world in certain ways
  - But by and large, the deepest ways in which we’re in relationship are with other people
- There’s a million different angles to endorse that point; it doesn’t sound controversial
- Where it connects to what Oliver is interested in and he’s writing about in the book is that there’s a sense in which other people, other consciousnesses are in some way an affront to any idea that we can use our intellects to control our world
- Because as soon as you’re in any kind of even slightly intimate relationship, a friendship with somebody else, it’s like people have their own agendas
- You are brought into an encounter with your limits, because you can’t just make the rhythms of family life go exactly as you want them to do
  - If you manage that, you find everyone else is very miserable and that’s not what you wanted

***We’re brought into this encounter with the fact that we are finite beings***

- Part of what is going wrong (at least in Oliver’s experience with the mastery of time approach) is some notion that he ought to be able to solve the problem of life with his intellect
  - That he ought to be able to figure out the workflow and the goal setting system to work life out

***Other people are a constant reminder that you can’t use your own intellect to work out life because everyone else is living their own lives and have their own agendas***

- Huge numbers of very practical things that mean anything to us can’t be done except in some form of relationship
  - Whether what you care about is raising a family, making music, playing sports, pursuing a religious faith or building a business or being a political activist

***There are a million different kinds of things that energize people, but they all have that in common ‒ that need to collaborate and that understanding that you don’t get to run life in the way that we often feel that we want to***

**Oliver gives some examples in the book**

- People who get into the position where they do have an extraordinary amount of control over how time unfolds in their own lives, and then find themselves kind of lonely and miserable

*The story of Mario* [33:00]

- Oliver doesn’t want to defame him
- In the book Oliver says he may be happy, but Oliver would *not* be happy in that situation
- Mario is this guy who is the subject of a *New York Times* short movie called [*The Happiest Guy in the World*](https://www.nytimes.com/2018/05/01/opinion/cruise-caribbean-retirement.html), which is how he describes himself
  - This is a really well-made short movie
- He’s a fellow who has constructed a life spent almost entirely living on board cruise ships as a sort of the ultimate loyal customer of the cruise line that he frequents
- And you can tell from the title that the filmmaker also is skeptical of his self-description as “*The happiest guy in the world*”
- Mario has total control in a sense of what he does with his time
  - He is not bound to a location
  - He is not bound to a job
  - He’s not bound to chores, because that’s all handled for him
- And there’s a deep poignancy that comes across in this short movie, a sense that he is out of sync
  - Oliver is not sure he’d agree; this is Oliver’s interpretation about what he would feel of what he would say is loneliness
  - He’s not synchronized with the rhythms of anybody else’s lives, and as a result, there are awkward moments in the film where he’s greeting the staff of the cruise ship referring to them as his friends
    - And you have a sense that they’re going along with being his friends because they’re the employees of the cruise line
    - They’re not going to be rude to him, but it’s not a friendship
- A lot of this has to do with what Oliver would say if here was in that position, “*I would say that I had made a major mistake in thinking that time is best understood as this thing that you should sort of hoard as much of as you can for yourself, achieve a kind of total sovereignty over it, if you can, as opposed to something that gets its value as a kind of network good. Gets its value from being shared.*”

> “*[Time] gets its value from being shared.*”‒ Oliver Burkeman

- There are all sorts of anecdotes from people who have become digital nomads and roam the world, running their businesses from their laptops
  - Lots of plus points to that
  - Maybe often a wonderful thing to do for a few years in your young adulthood
  - But they soon find that with all this freedom, they’ve kind of exiled themselves from the very normal routines that actually we find deeply **fulfilling**: of several friends meeting up for a drink or going for a bike ride or just very normal things that rely on **surrendering some of our control control over time**

## The importance of time synchronicity [36:00]

**Regular goods versus network goods**

- A classic **“regular good”** is money
  - All things equal, more of it is better than less of it
  - But even if you could hoard all the money in the world, it’s not going to make you happy
- An example of a **“network good”** are cell phones or telephones
  - You don’t want to have all the cell phones
  - You just need one and you want everyone else to have one of  them because that’s what makes the network work
- Peter adds, “*To think of time as money is missing the point a little bit, you need to think of time as cell phones.*”
  - You have time that everyone else has

**The great Soviet experiment about the asynchronicity of time**

- There was this extraordinary attempt in the early decades of the Soviet Union to leapfrog the state of economic development of the West by eliminating the seven-day week (five days of work, two days weekend) and replacing it with a five-day system (four days of work, one day of rest, four days of work, one day of rest)
- The ingenious idea here was that it wouldn’t be the same four days on one day off for everybody
  - Instead that the population was divided into color-coded cohorts and depending on which one you belonged to, your four days and one day would be different
  - The idea was that this would enable the factory machines to run every single day of the year and never need to stop, and this would result in extraordinary economic gains
- What it did very quickly was to desynchronized the whole population (among other unintended consequences)
  - Spouses were supposed to be assigned to the same cohort but it often didn’t happen
  - If you had somebody you wanted to spend time with and they were in a different cohort, you never had the same “weekend” to spend time
- It hugely disrupted the family and it disrupted the church
  - Both of these were features rather than bugs from the point of view of the Soviet leadership ‒ that you’re undermining these other centers of power in the society
- There’s an amazing letter to Pravda complaining that a holiday isn’t a holiday at all if nobody else in your life is available to spend the holiday with and you’ve just got to go to the cafe and drink a cup of coffee on your own

***It’s an extreme example of how damaging it is to our quality of life to be put in a situation where our time is not properly synchronized with other people’s***

- As the writer [Judith Shulevitz](https://www.judithshulevitz.com/author/) and various people have pointed out, “*All of us are all on different schedules than everybody else*”
  - We’ve done something like that to ourselves in the 21st century US and UK, because although we do not have that kind of deliberate top-down government messing with our attempts to synchronize our time
  - Pretty much everybody, for one reason or another has a different schedule
    - For example, the kind of people who are called into work irregular shifts in retail
    - Also the more privileged people who set their own hours and work on their laptops or whatever

***This is a real and growing problem the way we’ve completely fallen out of sync with each other***

- Oliver has written in the book about how much he’s gotten out of singing in amateur choirs over the years
  - But anything like that, you all need to agree that it’s going to be at the same time of the day, on the same day of the week, otherwise it’s not happening
- There’s a deep point there that has quite a few low-level, practical ramifications
- Peter points out, “*That’s the interesting thing, right? Without time you couldn’t do these things. We couldn’t synchronize, and synchronization is so important for civilization. And yet it’s potentially the thing that gets us back to this root problem, which is we now think we can master this thing called time. And as I think we’re learning, if you try to master time, time will master you. We need time to have a civilization. We can’t really synchronize it because of the success of civilization, ergo we try to gain control over it by mastering it, some of us more than others, and we end up feeling like we can’t.*”

## Identifying your biggest priorities and the paradox of wanting to do more than you have time for [41:00]

**Oliver points out the flaw in the logic of the story about the rocks, pebbles, and sand**

- The original story has probably been reproduced in a thousand time management books
- The anecdote has different versions, but basically a professor arrives in a classroom one day with some large rocks, some pebbles, some sand, and a big glass jar
  - He challenges the students to fit all of this stuff into the jar
  - The students (who have to be kind of dumb for the purposes of the story) start putting in the sand first, and then the pebbles, but then the rocks don’t fit
    - The pebbles first, and the sand, and the rocks don’t fit
  - The professor very smugly points out, “*No. No.  Look, if you put the big rocks in first, then the pebbles and the sand nestle in the spaces in between*.”
- The **moral of the story** is if you make time for your biggest priorities, then you’ll get them done and you’ll have other time for other things
  - But if you don’t, first of all, make time for your biggest priorities, you won’t find time for them because all this other stuff will fill up the finite space
- There are decisions to be made between things that really matter and things that don’t really matter
- But much more importantly is, “*It’s a scam, right?*”
  - It’s a rigged demonstration because he has only brought into the classroom the number of big rocks that he knows can be made to fit into this jar

> “T*he real problem that we have is that there are just far too many big rocks.*”‒ Oliver Burkeman

- There are far too many things that legitimately matter
- There are certainly marginal benefits to how you are arranging your day, and making sure that you are putting in the important stuff, and not spending too much time on stuff that doesn’t matter

***The really big challenge is seeing that there will always be more big rocks then we’ll have time for, and having the courage to neglect a whole lot of them in order to focus on a few of them***

- [Elizabeth Gilbert](https://www.elizabethgilbert.com/bio/) says this right; she has this great line about how we think that **saying “No”** is so important
  - Because if we say no to all the stuff we don’t want to do, we’ll have time for the things that we do want to do
  - But actually the true art of saying no is **saying no to things you DO want to do** in order to do some other things that you do want to do
- Deep in our minds there seems to be this assumption of some sort of natural law that says “*The number of things we’re going to feel like they matter has ultimately got to match up to the time that we have.*”
  - It just isn’t the case
  - We can feel that vastly more matters than we are going to have time for

> “*I think that really goes to the heart of this idea that figuring out what to neglect, being willing to let things go, waving goodbye to possibilities, this very dark kind of disappointment that’s baked into any life, handling that is the big challenge.”*‒ Oliver Burkeman

**The story about Warren Buffet speaking with his pilot**

- Peter recalls Oliver described it as, “*The allure of middling priorities*”
- Oliver points out, “*It’s pretty established now that it wasn’t* [*Warren Buffet*](https://en.wikipedia.org/wiki/Warren_Buffett) *or that Warren Buffet denies it and I make this clear in the book.*”
- He is asked, “*How should I set my priorities in life?*”
- He replies that you should make a list of the 25 things that matter to you most in your life (goals, priorities) and rank them in order from 1-25
  - The top 5 are **the ones that you should pour your time and energy and attention into**
  - The next 20 are **the ones you should avoid at all costs** because they’re the ones that matter to you enough to lure you away from the top 5, but don’t matter to you enough to be the top 5
    - This is where most of us might come to a different conclusion
    - Many people might say those are pretty important, so whenever you get a little corner of time, do something on one of those

***Even in this story, there is a little bit of not quite facing the truth of the matter because it could simply be that there are many, many things that all belong in the top 5 (more than 5 things)***

- You can still do that ranking, but what’s so important about it as a way of approaching life is you don’t have to convince yourself that all those things you’re going to decide *not to do* don’t really matter
  - We’re talking about all the things you’re going to neglect
  - They did matter, and it would’ve been good to do those things

***But finitude, our state as humans demands that we make some choices***

- Oliver thinks this is very comforting in the end because if you feel that you want to not only be great in your work and be a great parent and pursue a couple of leisure activities, but also do these other 20 things and you feel that that must be a way of doing it, that’s a very tormenting way to live
  - When you see that there’s always going to be more that you want to be doing than you can be doing, that allows you to let go of some of those other things
  - To see that it’s our job as human beings to pick a handful of the things that really compel us and focus on them rather than to somehow make infinity fit into a finite container

## Oliver’s moment of clarity in 2014 [47:15]

- This was around 2014, and Oliver writes about this moment of clarity when he was sitting on a bench in Brooklyn, in Prospect Park
- You can sometimes figure things out in an intellectual level but then it takes years to live them in a real way
- So it wasn’t like his life changed in that moment
- It was a winter morning, in the middle of the week, and Oliver had an even larger number of things he felt like he had to do by the end of that week
- He was on his way to work in Brooklyn and sitting on this bench trying to figure out what combination of scheduling and what order he could to things to do things, to really power through all of these obligations he had for the week
- He remembers being suddenly struck by the thought, “*Oh, it’s impossible… I’m trying to do something impossible… I can’t be expected to find a way to do all of this. I’ve taken on more things than I can do in the time I have to do them.*”
- This came with a feeling of a burden being lifted
- He was going to have to renegotiate things or fail to meet some deadlines and deal with those downsides because there is no alternative

**Oliver has written a lot about this ‒ this move where you see that your problem is worse than you thought it was**

- It’s incredibly liberating because you go from thinking that you face an incredibly hard challenge to seeing that actually it’s not really hard, it’s **impossible**
- And the shift from really hard to impossible is actually quite important, because you can stop beating yourself up for not being able to do something impossible
- Oliver is now thinking in terms of what Peter was saying before about the initial motivations for his interest in the physical stuff, and he thinks there is a similar liberation to go through in **finding a way to live forever** ‒ that’s impossible
  - Then you drop through into the ground of, “*One can maximize one’s chances of a longer life. You can certainly maximize the quality of the life that you have.*”
  - You drop away from the “me against the universe” thing that you can throw years of energy into but you’re never actually going to win
  - Then there’s something much more engaged with the world about being in the realm of the possible
  - “*It’s like you’re actually getting into the activity of doing real things in the world.*”

## The role of a sense of purpose in fulfillment [50:15]

**Peter’s goal to find a unifying theory on this aspect of life as it ties into these four books he’s read many times**

- He has tried and failed many times to come up with a unifying theory of what these four authors have written about: [Oliver Burkeman](https://www.oliverburkeman.com/about), [Bill Perkins](https://www.diewithzerobook.com/welcome), [Arthur Brooks,](https://www.hbs.edu/faculty/Pages/profile.aspx?facId=1134664) and [Ryan Holiday](https://ryanholiday.net/about/)
- 18 months before Peter turned 50, he set it as a goal to do before he turned 50
- He wants to limit himself to just these four things
- He thought it can’t be that hard, but that birthday came and went and this was just another thing he failed at
- One area where he’s really struggling is sense of purpose

**Sense of purpose is one area where Peter has vacillated in his life**

- There have been times when he had such a grandiose view of his role that he felt everyone should have a **legacy**
- He met his wife in Baltimore when he was in residence
  - Which was kind of a slog, working 110-120 hours a week (talk about asynchronous time)
  - His wife was working two jobs and they were virtually never together
  - He was either swimming or working on a surgical manual he wanted to write
- She questioned what he was doing and asked, “*Why don’t we just chill out?*”
- Peter was like, “*No. No. No. This thing’s going to be my legacy.*”
- She thought it was so funny that she got him a t-shirt that said, PA: “What’s your legacy?”
  - PA for Peter’s initials
  - She was mocking him with this t-shirt
- Now Peter is so far at the inter end of the spectrum that he worries it’s problematic
  - He doesn’t think there’s any such thing as legacy
  - We’re all going to die and none of it matters
  - If he dies tomorrow, nothing changes
  - The earth will continue to move on its axis with the exact same precision as if he lives to a hundred
    - Nothing will change
  - And if he lives another 40 years, no matter what he does in those 40 years, it won’t matter
    - Nothing will change in the universe
- Oliver writes about this idea of **cosmic insignificance therapy**

*Both of these seem problematic*

- The total lack of sense of purpose
  - Which Peter’s not saying he doesn’t have a sense of purpose
  - He’s just saying he feels so insignificant
  - He flirts with the idea of being so insignificant that there are days he struggles with doing things
    - He thinks, “*Well, I do them because I’m good at doing things*.”
    - But that’s very different
- Whereas Arthur Brooks in [*From Strength to Strength*](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=sr_1_1?crid=1C63EK713ZM0X&keywords=from+strength+to+strength+arthur+brooks&qid=1689697618&sprefix=From+S%2Caps%2C109&sr=8-1) would talk about this importance of sense of purpose
  - That the joy, the fulfillment that comes from having a purpose that’s larger than yourself

**How do you rectify that particular issue? Is what we’re talking about here too nihilistic?**

- What we’re circling around here is so interesting
- Oliver doesn’t think he’s going to solve the mystery of what unites the books
- We’re circling around this idea of finitude and reconciling ourselves to what it means to be finite
  - Obviously, that’s Oliver’s angle and he’s doing it from his perspective

***It’s this way of thinking about meaning in life that doesn’t accept this binary of either we are gods, either we do things that echo down the centuries forever, or if we can’t, that must mean that we’re nothing and there’s no point in it all***

- There’s something very seductive about it, and Oliver is as bad as anyone at falling into this
- But there’s something sort of inhuman about that because it doesn’t meet who we really are as humans
  - We are extraordinary and capable of extraordinary things and also very much not Gods
- In the section of the book on “Cosmic Insignificance Therapy”, it first explains how Oliver feels that it can be very energizing and empowering to drop the inner requirement that everything we do in our lives has to be extraordinarily important on a grand scale
  - Because if you zoom out far enough, you can make anybody’s life completely unimportant
    - You can do that with Mozart if you zoom out far enough
    - Some people might be remembered for several thousand years
    - Make it a million years instead, and there’s nothing we can do that matters in that sense

*That can be very liberating*

- It means that if you’re prone to indecision and spending time feeling like you’ve got to do things exactly right, then it’s a good reminder, “*That it doesn’t matter enough to worry about*”
- But yes, then the risk is that you’re lifted out of that terrible kind of, *“Oh, no. Am I doing things extraordinarily enough with my life? Am I getting things right or am I going the wrong way?*”
  - You’re lifted out of it so far that it becomes lighter than air and it’s like, “*Why am I even here? What’s the point?*”

**Thinking about what gives life meaning and purpose**

- Oliver has been really influenced here by the work of a philosopher called [Iddo Landau](https://www.psychologytoday.com/us/contributors/iddo-landau-phd), who wrote a book called [*Finding Meaning in an Imperfect World*](https://www.amazon.com/Finding-Meaning-Imperfect-World-Landau/dp/0190657669)
  - It’s strange when it comes to thinking about what meaning is, what purpose is
  - We insist on using these criteria there either no human (or maybe a tiny number of humans in each generation) could ever hope to meet
    - There’s something cruel in saying that meaning is only at this cosmic level
    - It’s slightly arbitrary
    - It’s probably motivated by our fear of death and wanting to feel like we’re immortal and that our legacy will last forever
- But if you can drop it to some extent and say, “*If what I’m doing with my life is making life better for a number of my contemporaries, or even just being a good parent, being a good member of my neighborhood…*”
- If I’m using a standard of meaning that is defining that as pointless, maybe I can **use a different standard**
- Oliver would argue that Landau is a [nihilist](https://en.wikipedia.org/wiki/Nihilism), a person who thinks there is no point in anything
- But in fact, he’s still clinging onto a fantasy
- The nihilist has got very high standards for what meaning should be
  - Then he finds that life doesn’t measure up to the standards so he’s like, “*Well, it’s all pointless.*”
- But Oliver contends that those standards don’t apply
- As discussed earlier, **meaningful times** when you’re helping a friend through a crisis or something like that
  - There’s a feeling of meaning in those times or a feeling perhaps of aliveness that kind of feels self-justifying
  - Sure, you can still point out that in any X number of thousands of years, it wouldn’t have mattered that you were there for that person, but it mattered then
- Landau has this great line about we are always doing this thing to ourselves where we’re saying, “*Well, it’s not a meaningful human existence because something that we couldn’t be expected to do as humans is something that we’re not doing.*”
  - If someone loves their dog, you don’t kind of correct them and tell them that actually their dog is no good because it can’t drive
  - If someone has a really nice chair in their house that’s a real pleasure to sit on, you don’t say, “*Well, no, it’s a useless chair because it can’t boil water for a cup of tea*.”
  - We don’t expect those things of those things, and maybe we can not expect of ourselves, as finite humans, these kind of God-like acts of cosmic meaning, and still find that the meaning that is available to us as finite humans is actually really, really something serious and important

***Perhaps becoming more and more wholeheartedly human is better goal in life than trying to escape the human condition and become a superhuman***

- To Peter, that makes a lot of sense, and he can only reconcile it in the big picture
  - He’s never going to bend the arc or the universe
  - But he matters to his kids, his wife, his friends

## Reconciling the finite nature of time and letting go of trying to master your time [59:00]

**This is the focus that brings us back full circle to the trap of productivity**

*Peter struggles with this real sense of urgency*

- He wants to control time because he knows the statistics: once his kids are 18, he has virtually no time left with them
  - “*They say on average, you have 19 years with your children; 18 of them occur in their first 18 years of their life, one year of total time with them occurs once they go off to college*.”
- It’s not just the finitude of his life, it’s an even greater finitude of the time he as with his kids
- Now he’s doubly whipping himself to make the most of his time
- Peter and his wife have this discussion all the time, “*God, I wish I didn’t have to do anything. I wish I could do nothing until our kids were all gone, and I wish I could do a reverse retirement. I wish I could retire for the next 15 years, and then I’ll work the remaining decades of my life when they’re gone anyway.*”
  - These are irrational thoughts
  - But this is the psychoses, neuroses that fuels it
- Oliver gets it and feels it too; he’s not sure there is a solution

**A lot of this discussion is about a shift from doing things unconsciously to doing things consciously**

- That is really important
- Knowing and seeing that there is this trade-off is in some ways the best that we can hope for
- Trying to solve the problem through **time mastery** is not going to make things better, because that’s going to be undertaken in the unconscious belief that there’s a way of maximizing your capacity so much that you can spend all the time that feels like it matters with your kids
  - And you can spend all the time that feels like it matters on the work
- First you make wiser decisions around the edges
  - Maybe you backpedal a little on certain work things in order to maximize more time with kids
  - Maybe you organize your time in strategic ways to make those gains around the edges and free up capacity
- More fundamentally, you see a sad truth about being someone fortunate enough to have these different domains of our lives that we value, that gives meaning to our lives (someone who is a parent and someone who works or whatever other things might be competing in their lives)
- This comes back to something Oliver wanted to say in response to Peter talking about the person who died and feeling sad about those things
- The person who thinks they’re going to find a way to master their time and make enough time for everything is trapped in this kind of **future-oriented anxiety**

**Oliver’s takeaway ‒**

- The person who sort of sees the truth about trade-offs and the truth about finitude doesn’t suddenly become happy and reconciled to it all, but it’s a different kind of feeling
  - It’s a kind of poignancy
  - There’s a sad tinge to life that you don’t get away from

***Part of living a meaningful life is to be conscious of the fact that we don’t get all the time we would wish to have***

**Back to Peter’s search for a unifying theory of these four books**

- This is why Peter has yet to construct a unifying theory, because a unifying theory in some ways suggests a solution
- Unifying theories in physics are equations
- He doesn’t think there is an equation here
  - Even though his engineering background wants one
- A lot of the physiologic stuff can be broken down into equations
  - We can talk about cardiac output as a function of contractility and stroke volume and heart rate and systemic vascular resistance and all these things
  - We can really talk about physiologic stuff that way
  - But at the cellular level, we’re still hosed
    - There’s a lot we can’t talk about in that regard, but we still have biological mechanisms that we somewhat understand
- This is much more difficult
- And if people are sitting here listening to this on a podcast that’s about longevity and asking, “*Why are we talking about this?*” Peter would argue if you’re not talking about this, what the hell does that other stuff matter?
- Oliver thinks Peter put his finger on it with the idea that a unifying theory suggests a solution

***It’s the acceptance of the fact that there isn’t a solution that is such a powerful psychological transition***

- It totally goes along with doing everything you possibly can to sort of maximize both the quality of your experience and the amount of time you can have
- But it’s steps away from this idea that one day you’re going to find the solution to the human condition

**There are all these great sayings and phrases and ways of putting it that come out of Zen Buddhism**

- Where people are pointing us to this notion that what drives us crazy is thinking that there has to be a solution to the condition in which we find ourselves
- A quote Oliver used at the beginning of the book is from [Joko Beck](https://www.ordinarymind.com/charlotte-joko-beck) (the American Zen teacher), “*What makes it unbearable is your mistaken belief that it can be cured*”
  - This is an interesting medical way of stating the problem
- A friend, who is also a meditation person said, “*From a certain point of view, everything is palliative care because none of us is getting out of this alive.*”
- There are plenty more cliche sayings that pinpoint this same problem

***Oliver doesn’t think that’s a recipe for nihilism, it’s a recipe for letting go of a quest that wasn’t possible in order to get involved in the quest that is possible***

## Why we tend to have a future-focused attitude and how to combat that with atelic activities [1:05:45]

**Say more about our aversion to being still, to being alone with ourselves, to being alone with our thoughts**

- Peter learned so much from Oliver’s book, and there are places where it overlaps with others and reinforces things he’s already seen the value in
- One of the most important is what Ryan Holiday writes about as stillness, and Oliver writes about as [atelic](https://en.wiktionary.org/wiki/atelic) activities
  - When Peter was reading this, he wrote at the bottom of that page, “*Atelic activity is the antidote.*”
    - The antidote was referring to the aversion we have to being still, to being alone with ourselves and our thoughts
- Ryan comes at this same conclusion from a different perspective, a purely [stoic](https://en.wikipedia.org/wiki/Stoicism#Logic) philosophy lens
- While Oliver comes at this conclusion through the lens of observation and [empiricism](https://en.wikipedia.org/wiki/Empiricism)

Oliver explains the **idea of atelic activity** was coined by the philosopher [Kieran Setiya](http://www.ksetiya.net/)

- This is the notion of an activity that is done for itself alone
  - Not to get somewhere, not to get something else
  - It’s not the kind of thing that you will ever have done enough of
- The example Oliver uses in the book is hiking (just because it’s something he enjoys a lot)
  - You can’t make hiking, in a meaningful sense, more efficient
  - Sure you can walk in more efficient ways than others, but the point is simply that the reason that people are drawn to an activity like that is for the experience itself
  - There are some ancillary health benefits, but you’re not trying to get somewhere either in terms of training or in terms of geographically trying to get somewhere
  - It’s just done for itself alone
- A lot of activities around arts, music, dance can be pursued in a more sort of way that culminates in something (but they don’t have to be), and a lot of the enjoyment people get is in itself alone
- What Ryan means by stillness is something that almost by definition can’t be an instrumental use of time

***Oliver thinks the unifying idea here is that there is something wrong with pursuing life in which time is considered exclusively instrumentally, so that you’re always assessing the value of how you’re using your time by where it’s leading you and how well it’s getting you to that goal***

- Because at some point, either this has to cash out in a present moment of meaning, or you are always postponing
- It has the effect of always postponing the moment of truth into the future
- There a great quote from [John Maynard Keynes](https://en.wikipedia.org/wiki/John_Maynard_Keynes) (the economist) that Oliver uses in his book
  - It gets at the point of why we do this, why we want to live for future activities
    - Even though it’s an anxious way to live
    - Even though we’re never quite at the moment of fulfillment
  - It’s because by projecting our interests in what we’re doing constantly into the future, you’re securing what Keynes calls “*A spurious immortality*” for them
- Keynes says, “*The purposive man does not love his cat, but only the cat’s kittens, nor in truth the kittens, but only the kittens’ kittens, and so on, forward, forever to the end of catdom*”
  - This is a terrible way to live because you never get to actually love your pet (or plug in whatever the value of an activity would be)
  - But it has this great advantage on a subconscious level ‒ as long as you’re still getting somewhere, then you don’t have to fully face that pain of the fact that this is not a dress rehearsal, this is the time you have to use meaningfully if you’re going to have a meaningful life

> “*This is the time you have to use meaningfully if you’re going to have a meaningful life*”‒ Oliver Burkeman

- Oliver falls into this trap all of the time
  - He catches himself after stuff has been completed, after he’s figured out how to do something, then he’ll start living in a present way and really getting the value of life

***Oliver agrees with Keynes about this, what we’re really doing is constantly projecting that moment forwards because it kind of feels like you don’t have to die***

- Peter agrees this is the jugular issue ‒ it is this connection to our mortality and our finitude that is underpinning all of this difficulty, because on the one hand, it just shouldn’t be this hard
- For example, Peter will have over the next month a number of things that are all enjoyable, but when he looks back at the month afterwards, he realizes that every time he was in one of those moments he was thinking about the next one
  - Something with his kids one day
  - Camping another day
  - A day to race his car on the track

***It’s tragic, and the point of doing that is because subconsciously he needs to avoid confronting the finite nature of time***

- In Oliver’s experience, he takes solace from the fact that the great philosophers of history haven’t found any alternative to this
- It’s just that you shift from an avoidant stance (which saps the meaning from life), to a stance that looks it in the face and feels kind of sad about it
- It’s not that you don’t want to get tripped up on the idea that you’re supposed to become totally zen about this awful human fate
- You just integrate, to some extent, that poignancy into the experience, and then you fall back into the moment you are in
- It’s tricky because those of us in this productivity mindset will have spent a lot of time beating ourselves up for not doing enough, and it’s very easy to take that same stance towards the challenge of reconciling yourself to it all
  - And then feeling that you’re somehow falling short because you don’t feel completely zen about mortality
  - Oliver doesn’t think there is any reason to believe anyone ever does

## The power of shifting your perspective about time and your experiences [1:12:45]

**The improbability of our existence**

- In the book Oliver refers to someone who had done the math on how improbable each of our existences is
  - Anybody who has thought through embryology can’t help but think about the probability that that sperm, on that day, hit that egg, on that month, to result in me being here
  - Peter took some comfort in knowing there was at least one other person who did the math
- You only need to think about this through the lens of siblings
  - You have siblings that are genetically similar, but they’re completely different people
  - Therefore, there’s a sub-trillion probability event that you even exist
  - And one of the things Oliver points out in his book is there’s no solution to this problem
    - It’s palliative care

**But what are some partial antidotes?**

- Peter suggests flipping the problem statement from not, “*Oh, I can’t believe I only have 4,000 weeks. How am I going to make the most of them?*” to, “*I can’t believe I even get one week. It’s just a miracle we’re here.*”
- Oliver agrees 100%
- Going to that idea of **getting to have the time** is such a powerful transition, partly because, and this is kind of [Heidegger](https://en.wikipedia.org/wiki/Martin_Heidegger) and all sorts of stuff Oliver grappled with in trying to write this book (and he doesn’t recommend anyone else grapples with Heidegger)
  - Partly because it shifts the attention from the specific content of experience to the fact of there being experience
    - And that is really helpful, because it means that actually you don’t need to spend quite so much time worrying about whether you’re doing the right things because you just get that sense that it’s a miracle that you’re doing anything
    - It potentially makes sitting in a traffic jam less enraging (if not pleasurable), because experience is happening
  - What are the chances? And that’s kind of amazing, even if you’re doing something that we would normally characterize as really frustrating
- Oliver mentioned somebody in the book who had this experience after a friend of his died unexpectedly and young
  - Finding himself in traffic jams or supermarket queues or waiting on hold on phone lines, whatever, and having that thought, “*What would my friend have given to be in this traffic jam now, to be waiting in this queue now?*”
  - And there’s a way of dialing into an appreciation of the fact that there is experience as opposed to exactly what it is you’re experiencing
- One of Peter’s friends said something very similar, “*We all sort of lament getting older… Well, consider the alternative, right? Being dead. Yeah, maybe it sucks to turn 65 and look in the mirror and not see the face that you saw when you were 25, but isn’t this better than having died when you were 25?*”
  - It’s another way to think about this problem

**Back to Martin Heidegger and this idea of having time versus “being” time**

- Oliver has read a bit of his writing, and Peter realized he’s not going to be smart enough to interpret what he writes (it’s way too obtuse for him even though it’s interesting)
- After the book came out, Oliver discovered (to his regret) a very similar outlook on this question in the work of one of the founder of Zen called [Dogen](https://en.wikipedia.org/wiki/D%C5%8Dgen) (writing from the 12th, 13th century)
  - He wasn’t a Nazi sympathizer (as Heidegger was)
  - He was the original, he thought of this centuries before
  - His work is much clearer, it’s puzzling but not aggressively impenetrable in the way that Heidegger often is
- It comes up again and again in this material, ***that maybe in some sense, being and time are the same thing***
  - Heidegger’s master work is called *Being and Time*
  - One of Dogen’s most famous works translates as *Being-Time*, with a hyphen, as if they’re the same thing
- It’s kind of strange to think about at first, but there’s something very true about it, this flawed notion that we have time, **you never really have time**
  - You never really have more than a single, present moment
  - You don’t get it to keep in the way that we have physical possessions

***There are all sorts of problems that come from treating time as this resource that we need to maximize***

- Then time starts doing strange things
  - You try to maximize it and you end up with more stuff to do and all these kind of perverse things because we’re treating it as something that it isn’t

**Maybe it makes more sense to think of the idea that you are time, that you are the moment**

- In hindsight, your life will have been a portion of the time that you were
- There is a powerful shift here that’s beyond words
- Oliver is just sort of pointing at it and hoping that some people hearing this will be able to feel the shift he’s talking about
- It returns to your life and it stops you engaging in this attempt to be the “air traffic controller” of your life from above, or trying to get out in front of your time and steer it
- It puts you back into the position of just being a portion of time
  - To Oliver, it feels really liberating

**There’s a very famous quote from a story by** [**Jorge Luis Borges**](https://en.wikipedia.org/wiki/Jorge_Luis_Borges) **(the novelist)**

- It goes something like, “*Time is a river which bears me along, but I am the river. Time is a fire that consumes me, but I am the fire. Time is a tiger that attacks me, but I am the tiger*.”
- Oliver thinks he’s making the same transition

***We’re constantly trying to fight time, but actually we just are time***

- Oliver thinks it’s probable that this is not just beyond words for him, but that it might be in some definitive systematic sense, beyond words, which is possibly also why it’s so hard to understand in the work of Heidegger
- But we are gesturing at something important here anyway

## How to operationalize the three principles for the dilemma of finite time [1:20:15]

- Peter thinks what they’re saying is, “*Look if you jump into the productivity hack space, it’s a fallacy. You’re going to chase your tail and you’re never going to be made whole.*”
  - For example, just as the alcoholic can never quench their thirst fully, just as no amount of alcohol can numb the pain that is at the root of that addition
  - No amount of productivity can  numb what is gnawing away at the need to achieve and be productive
- He knows people are out there who can’t relate to extreme appetites for either alcohol or productivity, but they’re going to have to take it on a leap of faith that those are very true statements
- As humans, we work with tools, we work with protocols, we work with procedures, we work with tactics
  - And we try to make the best of the situation
  - We try to [palliate](https://www.merriam-webster.com/dictionary/palliate)
  - Oliver writes about several of these, and Peter thinks we should talk about some of these things, because they make a lot of sense

**Three principles for the dilemma of finite time:**

- 1) Paying yourself first
- 2) Limiting work in progress, and
- 3) Resisting the allure of middling priorities

*How do we operationalize them?*

- Oliver adds, “*We’re getting at this question of, what is the role of a technique or a method or a productivity system once you have begun a little bit to go through this process of disenchantment with the lure of total productivity and infinite capacity?*”
  - That’s the moment at which to use these kinds of techniques
  - It’s once you’re no longer thinking that they’re going to save your soul, they’re just useful things to do
- Specific ones are well attuned to the job of embracing limitation and finitude
- They’re not the kind of techniques that are going to lead you astray back onto that treadmill

1 – **Paying yourself first** is a very well-known concept in personal finance, that when you get paid, you should take some money out of your paycheck and put it into savings and investments right away

- Then, your regular expenses come out of what’s left rather than spending what you need to spend and hoping that there’ll be some leftover at the end
  - Because there isn’t, because we live up to our means
- The same thing is true of time
- If you take the approach of clearing the decks, I’m going to get through all the stuff that I need to get through so that I get to this time when I can finally put real focused attention onto the things I care about, that’s never going to happen
  - For some of the reasons we’ve discussed
  - The decks will never be clear

***So paying yourself first is just the act of taking that important thing and doing at least a little bit on it now, first thing in the morning, right away***

- In other words, not trying to clear the space for it, but just claiming the time for it, and learning to tolerate the anxiety of the fact that while you do that, more emails will be coming in, more things will be filling up the decks, asking for your attention
  - And this can be work-related, but it could be something else
  - If there’s a project you want to work on, a creative pursuit, a relationship you want to nurture
  - It’s just the acceptance that at some point, you’re going to have to do that in a present moment, and it’s not going to feel like it’s the right time
    - It’s not going to feel like everything else is out of the way because everything is never going to be out of the way
- So you could operationalize that as spending the first hour of the workday doing your most important priority
- There are lots and lots of different ways to make that concrete

2 – **Limiting your work in progress** is one of these methods that just acknowledges up front that your bandwidth is incredibly limited, that your time is incredibly limited

- The idea of setting an upper limit to the number of tasks or projects that you’re going to allow to be on your plate at once
  - Oliver illustrates this in the book using this idea of **two to-do lists**
    - (1) an open list where you put absolutely anything and everything that’s on your plate (it could have like 400 items on it)
    - (2) the other is a closed list (it might only have five slots on it)
  - And the rule is that you feed tasks from the long list to the short list until those five slots are full, and then you can’t add any more until you’ve freed up a slot by completing one of those tasks
  - It’s an artificial bottleneck that you’re placing on your workflow
- All that’s happening is you’re taking a fact that is already true for all of us, which is we can only give our attention to a handful of things on a given day, in a given week, and you’re making it conscious and you’re saying, “*Okay. I’m going to make all these other things wait outside the door until these things have been done.*”
- There are lots of other ways of implementing this
  - Anyone who’s familiar with [Kanban methods of project management](https://en.wikipedia.org/wiki/Kanban_(development)) will recognize the resonances here
- It’s just a way of articulating and making conscious the limitations that we work with as humans
  - And the extraordinary thing is that when you do this, you actually find you do get more productive by being willing to make the other things wait
  - You do end up processing more tasks, more projects than if you didn’t

3 – The **middling priorities idea** is that there are lots of things that really feel like they matter

- And those are the ones you have to be aware of if they are not the ones that really matter the most
- Because the urge to try to find a way to make time for all of them and end up not doing any of them well is really strong

**Peter wants to reiterate this point made earlier, that there’s two types of saying, “No”**

- There’s saying no to *things you don’t actually want to do* that maybe on the surface might look like they’re worth doing, but deep down, you don’t want to do them
  - So you’re kind of happy to say no
- But then there’s saying no to *things that you do want to do* but you know are not top five
- About three years ago, Peter started to that that seriously
  - That became the substrate for his journaling
  - He kept a “no” journal of all the things he said no to with an emphasis on things he actually wanted to do
    - They were all [FOMO](https://en.wikipedia.org/wiki/Fear_of_missing_out) machines, but he has some strong FOMO genes
    - It was really difficult to do that
  - He created  a system of accountability where he had a person that he would show up with to discuss his “no list”
    - These are all the things he said no to that he actually wanted to do
- But Peter thinks that’s not a solution; it’s a Band-Aid

***Oliver agrees and it’s really important to zero-in on the discomfort we feel when we say no to something that we want to do***

- It’s very different to the kind of talked up feeling that you get when you’re racing through stuff to try to not have to say no to anything
- It’s unpleasant, but it’s an encounter with reality, and it’s good in the end

## Harnessing the power of patience in the face of a problem or experience [1:28:00]

- Peter also notes this aversion to idleness, “*And the flip side of that is the need to be patient and how impatient we are*.”

**The story of the Art Professor at Harvard and Oliver’s experience with her assignment**

- Professor [Jennifer Roberts](https://haa.fas.harvard.edu/people/jennifer-roberts) has her incoming art history students chose a painting or sculpture, then go and look at it for three hours straight
  - There are many, many venues to do that in the Harvard area
- Oliver did this with a painting by [Degas](https://en.wikipedia.org/wiki/Edgar_Degas) in the Harvard Art Museums
- The motivation for this assignment from seeing students coming into her course whose whole lives were geared to speed
  - Both generally because of the way the technological culture works, but also because of the pressures of a highly competitive university
  - There are incentives to get stuff done as fast as you can
- She wanted to influence the tempo of what students were doing, to slow them down

***The fascinating thing that you learn in this context is that if you can sit with the intense discomfort that is involved in looking at a painting for such an absurd amount of time, you are rewarded***

- She knows this is an outrageous length of time, and that’s the point
- It’s relevant beyond the context of art
- After the first hour or so (or whenever it happens for you), the discomfort begins to fall away a bit and you get into a different zone
  - You literally see things in the painting that you hadn’t noticed before
    - Not that you come up with smart, fancy-sounding new interpretations of what you’re seeing
    - You see literal objects in paintings that you apparently didn’t see for 45 minutes of looking and looking at that painting

***You’re giving the experience the time that it takes instead of trying to dictate the time that it takes***

- It’s extremely tempting for us in all sorts of contexts to dictate the time something will take

***Oliver uses this example in the book to illustrate the benefits of being willing to take experiences at the speed that they need***

**Reading is another really classic example**

- You can train yourself to read faster, more efficiently, but it’s very small amount of time before you start losing the experience, especially with fiction
- Oliver adds, “*A lot of the time, when people say that they don’t have time to read or that they don’t like reading anymore, what they mean is that they really hate that it needs them to slow down.*”
  - People are mind-conditioned to speed and to going faster
  - There is a kind of surrender to the fact that reading is just going to take a certain amount of time and that you just have to let it take

> “*It’s really striking how uncomfortable that feels, how deeply unpleasant it is to sort of give up control over the pace of something like that, because it doesn’t make any sense that it should be as painful as it is.*”‒ Oliver Burkeman

- The other side of that is there are huge rewards

**What do you think problems that we encounter tell us about how to become more patient?**

*In other words, what does our relationship with a problem have to do with becoming more patient?*

- What comes to mind for Oliver is there’s a patience involved in allowing a problem to be unresolved until a solution presents itself
  - And being willing to not hurry forward to resolutions just to get rid of the feeling of having a problem
- Oliver got this from the book, [*The Road Less Traveled*](https://www.amazon.com/Road-Less-Traveled-Timeless-Traditional/dp/0743243153/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1690206226&sr=8-1) by [Scott Peck](https://en.wikipedia.org/wiki/M._Scott_Peck), and he’s found this himself in a really mundane context
- For example, he remembers when there was a problem with the water supply to the dishwasher
  - He doesn’t know anything about plumbing, but it’s in the cupboard, under the sink, and then it connects to the dishwasher
  - The urge you have, Scott Peck writes about this in the context of fixing a car with no knowledge of how to fix cars
  - The urge that you have in those contexts is so often to just fiddle around in the hope that almost by chance, you would fix the problem
    - That never works, because it takes expertise or some understanding of what’s going on anyway to be able to fix the problem
  - Instead, being willing to look at the situation, to trace where the pipes go and where they connect and what the joints are
    - You don’t have to be a plumber in this process
    - But as you see the situation, the solution becomes clear

***This is a really mundane example, but it applies to all sorts of other problems where we hurry to solutions because we want to feel like we’re in control of the process (even if it leads to a terrible outcome)***

- [John Keats](https://en.wikipedia.org/wiki/John_Keats), the poet, called this “*Negative capability*”
  - Such an extraordinary phrase
  - The ability to stay in uncertainty and not having a resolution and not always to be fidgety, restlessly, trying to get things all tied up with a bow

## The value of incrementalism for being productive [1:34:15]

- Peter remembers the discussion in Oliver’s book of professors who are more or less productive in terms of writing done, “*The amount of writing done by the more productive people on any given day is rather unimpressive.*”
  - It’s a bit of a tortoise-and-hare thing
- [Professor Robert Boice](https://www.librarything.com/author/boicerobert) found that ***the most consistently productive writers were the ones who made their writing work only a modest, moderate part of their days and their weeks***
  - This meant that it didn’t become something intimidating
  - There weren’t these sort of huge psychodramas with having your life dominated by these tasks
  - For that reason, they didn’t start to resent it or to procrastinate
  - It was just this kind of modest thing, and then they’re consistently applied over days and days and days and weeks
  - The output really built up much more rapidly than the people who would sort of swing wildly back and forth between putting in huge numbers of hours and exhausting themselves and then not being able to do it for days after that because they were too tired
- In Oliver’s writing practice, this has really made a difference
  - Setting aside a modest amount of time to write each day (1-2 hours)
- **The power of stopping** ‒ what Boice emphasized was that if you find yourself on a roll at the end of your writing time, it’s incredibly tempting to keep going and ride that wave of motivation, but making yourself stop is just as important as making yourself start
  - If you stop the thing that you are doing sooner than you want to, it does something very helpful to the motivation
    - It makes you want to come back to it the next day in a way that is not the case if you let yourself get spent

***Boice makes the point that wanting to ride the wave of motivation is actually a kind of impatience***

- Instead of believing that you’ve got to grab the inspiration/energy while you have it (fearing that you might not get it again), it’s an act of great confidence to stop and return to it tomorrow
- Peter thinks this makes a ton of sense

**Peter has transitioned to more of an incremental type of relationship with exercise**

- His philosophy used to be the exact opposite, “*It was clearly a sense of every day, you had to burn every match.*”
- Today he has a healthier approach, he always leaves matches in the matchbox at the end of the workout
  - There’s an exception here and there
  - Some days you just really want to go for it and really see what your limit truly is
- Peter thinks it’s better from a longevity standpoint (physiologically and psychologically) to leave the workout with a little bit more of, “*I could do a little bit more and I can’t wait to get back and do it again*.”
  - Part of that is just preserving the drive to be back in there
  - Because if you’re burning every match every day, it gets awfully hard to show up; and in reality, you’re probably not actually doing as much good physically

## Embracing your finitude with curiosity [1:38:00]

- Peter won’t go through them because he wants people to read the [book](https://www.amazon.com/Four-Thousand-Weeks-Management-Mortals/dp/1250849357/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1686916362&sr=8-1)
  - He wants them to go through it the way he did with a highlighter and try to learn what can be done

**Are there any of those 10 that we haven’t peripherally touched on that you want to dive into?**

- We haven’t spoken so much in general about, “*The degree to which this desire for control over time manifests as a desire for control over the future*”
  - As an antidote to worry
  - As well as being a sort of productivity geek and all the rest of it
- Oliver is certainly an inveterate worrier about the future
- He writes in the book about the ways in which a lot of worry and obsessive planning can be understood as an attempt to throw a straitjacket over the future
  - From the standpoint of the present
  - To feel like you’ve got it under your control and you know what’s coming
- When in fact, another aspect of our being finite human beings is what’s been called our **total vulnerability to events**

> “*Anything could happen at any moment to anyone. That’s just the way it is to be human.*”‒ Oliver Burkeman

- In the appendix is this idea about **curiosity** as a stance to take towards life
  - Oliver is borrowing the advice of somebody else about being a researcher in relationships

***Instead of trying to get things to go in a certain way, take the stance of wondering how they’re going to go***

- This idea comes from how to relate best to small children as a parent or a caregiver
- Try to find out what you can about another person and have an open stance of wondering what is going to happen
  - Wondering what is this other person like
  - As opposed to that background attempt of seeing if they like up with what you feel you need to happen or how you need them to be

**You should be curious in life**

- The idea of being curious is a bit of a cliché these days
- Specifically, that kind of stance is agnostic (within limits) about what happens next or how a relationship with somebody turns out to be
- This is a resilient and helpful attitude to have in life
- It’s probably one of the least specific of those 10 at the back of the book, but it seemed like the one to mention here

## Acting on an idea in the moment rather than letting the idea be the obstacle [1:41:15]

**The idea of being instantaneously generous and not punting generosity until another day**

- This is one that Peter thinks about a lot and thinks it overlaps with Bill Perkin’s ethos in [*Die with Zero*](https://www.amazon.com/Die-Zero-Getting-Your-Money/dp/0358099765/ref=sr_1_1?crid=2D0N2WRLFRIAV&keywords=die+with+zero+bill+perkins+hardcover&qid=1689697715&sprefix=die+with+zero+bill%2Caps%2C92&sr=8-1)
- This is one of the three most important things Peter took away from the book
  - We have all these plans to do things tomorrow, for instance, “*God, this person has been so great in my life and I can’t wait to show them in 10 years how great they’ve been.*”
  - How about you show them today how much they’ve mattered to you

*What brought this on the list for you?*

- Oliver came across this extraordinary line from the meditation teacher [Joseph Goldstein](https://www.dharma.org/teacher/joseph-goldstein/) about his personal practice ‒ if a generous thought arises in his mind that implies some action (donating to a charity, sending a note to somebody to say you appreciate them), his practice is to try to do that thing immediately rather than later
- The idea of being more generous, more grateful, more kind really resonated with Oliver
  - It’s quite hard to will that kind of situation/thought
  - He’s always had a lot of difficulty with stuff coming out of mindfulness and Buddhism
- This is a way of saying, “*A lot of these urges in most decent people do arise all the time.*”
  - The problem is when you then say, “*Well, I’ll do it later when I get all these other things out of the way*”
  - The problem is not acting on it
- After reading about it, Oliver took this on board and tried to do it
- He thinks it goes beyond this one example of generosity
- Time and again, he finds himself in this situation of wanting to become the kind of person who does things in a different way
  - Who sends lots of generous notes to friends
  - Or it could be lots of other good habits in life
- But that desire to become that kind of person ends up being an obstacle to doing that thing because you tell yourself, “*Well, that’s going to take a whole reorganization of my schedule.*” or, “*I’m just a bit busy today.*”
- Oliver heard from somebody who said that he’d made a deal with himself that he was going to send 3 appreciative notes a week to people in his world
  - As a result of this plan, he was catching himself *not* sending an appreciative note because he was on track to becoming the kind of person who did it all the time

***It’s one of the downsides of the laudable aim of trying to develop good habits, is you can really let the kind of idea of development of a habit stand in the way of doing the thing***

- It’s daunting to consider that you might spend 20 minutes a day from now on meditating every day
  - The thought of doing it tomorrow can get in the way of just doing it once, now
  - Deal with tomorrow, tomorrow

**The instantaneous part of that is really important**

- You’ll find a way and a reason to postpone that thing, but it’s really powerful to try to make it your explicit practice be, “*I will do that kind of thing when the thought arises*.”

**These 10 steps are not the solution to this problem**

- Peter wants to make sure they’re not overselling this, “*You’re not going to go and adopt these 10 ideas or behaviors and somehow (at least if you’re me) presumably for you, be at complete peace with the duration of your life, never struggle again with trying to achieve something, never again struggle with trying to be productive.*”
- But if we can move the needle a little bit and focus on these experiences and enjoy the experiences that define those 4,000 weeks, there is something there
  - More than trying to grasp water, which is effectively what it’s like for Peter trying to master productivity
  - Peter adds, “*Coming to grips with getting a little bit better as opposed to being perfect is the best step I can take.*”
- Oliver defends the book for containing the solution to all of this, “*No other book contains it either, right?*”

***Moving the needle, that’s our job. That’s the thing that we can do. That’s the thing that’s available to us as finite humans.***

§

## Selected Links / Related Material

**Oliver’s latest book**: [Four Thousand Weeks: Time Management for Mortals](https://www.amazon.com/Four-Thousand-Weeks-Management-Mortals/dp/1250849357/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1686916362&sr=8-1) by Oliver Burkeman (August 2021) | [1:00]

**Other books by Oliver**:  [1:00]

- [HELP!: How to Become Slightly Happier and Get a Bit More Done](https://www.amazon.com/HELP-Become-Slightly-Happier-More/dp/0857860267/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=) by Oliver Burkeman (January 2011)
- [The Antidote: Happiness for People Who Can’t Stand Positive Thinking](https://www.amazon.com/Antidote-Happiness-People-Positive-Thinking/dp/0865479410/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=) by Oliver Burkeman (November 2012)

**Other books Peter hands out to friends**: [1:15]

- [Stillness is the Key](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1689697500&sr=8-1) by Ryan Holiday (October 2019)
- [From Strength to Strength: Finding Success, Happiness, and Deep Purpose in the Second Half of Life](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=sr_1_1?crid=1C63EK713ZM0X&keywords=from+strength+to+strength+arthur+brooks&qid=1689697618&sprefix=From+S%2Caps%2C109&sr=8-1) by Arthur Brooks (February 2022)
- [Die with Zero](https://www.amazon.com/Die-Zero-Getting-Your-Money/dp/0358099765/ref=sr_1_1?crid=2D0N2WRLFRIAV&keywords=die+with+zero+bill+perkins+hardcover&qid=1689697715&sprefix=die+with+zero+bill%2Caps%2C92&sr=8-1) by  Bill Perkins (July 2020)



**Previous episode of** ***The Drive*** **with Ryan Holiday**: [#90 – Ryan Holiday: Stillness, stoicism, and suffering less](https://peterattiamd.com/ryanholiday/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (January 27, 2020) | [1:30]

**Previous episode of** ***The Drive*** **with Arthur Brooks**: [#226 ‒ The science of happiness | Arthur Brooks, Ph.D.](https://peterattiamd.com/arthurbrooks/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (October 10, 2022) | [1:30]

**Previous episode of** ***The Drive*** **with Bill Perkins**: [#237 ‒ Optimizing life for maximum fulfillment | Bill Perkins](https://peterattiamd.com/billperkins/) | Host Peter Attia, [The Peter Attia Drive Podcast](https://peterattiamd.com/podcast/) (January 9, 2023) | [1:30]

**Richard Bach’s book**: [Jonathan Livngston Seagull](https://www.amazon.com/Jonathan-Livingston-Seagull-Richard-Bach/dp/0684846845/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1689862139&sr=8-1) by Richard Bach (September 1970) | [6:30]

**David Allen’s productivity book**: [Getting Things Done](https://www.amazon.com/Getting-Things-Done-Stress-Free-Productivity/dp/0143126563/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1689873371&sr=8-1) by David Allen (March 2015) | [19:30]

**Peter’s book**: [Outlive: The Science and Art of Longevity](https://www.amazon.com/Outlive-Longevity-Peter-Attia-MD/dp/0593236599/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1689873935&sr=8-1) by Peter Attia with Bill Gifford (March 2023) | [20:45]

**The story of Mario**: [The Happiest Guy in the World](https://www.nytimes.com/2018/05/01/opinion/cruise-caribbean-retirement.html) | Lance Oppenheim, *The New York Times* (May 1, 2018) | [33:30]

**Book about the philosophy of meaning and purpose:**  [Finding Meaning in an Imperfect World](https://www.amazon.com/Finding-Meaning-Imperfect-World-Landau/dp/0190657669) by Iddo Landau (August 2017) | [56:00]

**Book about patience**: [The Road Less Traveled](https://www.amazon.com/Road-Less-Traveled-Timeless-Traditional/dp/0743243153/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1690206226&sr=8-1) by [Scott Peck](https://en.wikipedia.org/wiki/M._Scott_Peck) (1978) | [1:28:15]

**Oliver’s TED talks**:

- [How to stop fighting against time](https://youtu.be/XtfCmhPr-J8) | TEDx (April 2, 2018)
- [Why patience is a superpower](https://youtu.be/42cwiP25ChI) | TEDxManchester (May 12, 2022)

**Oliver writes about his 10 steps**: [Ten Ways to Make Your Time Matter, Oliver Burkeman](https://greatergood.berkeley.edu/article/item/ten_ways_to_make_your_time_matter?), *Greater Good Magazine* (October 13, 2021)

§

## People Mentioned

- [Ryan Holiday](https://ryanholiday.net/about/) (Author of [*Stillness is the Key*](https://www.amazon.com/Stillness-Key-Ryan-Holiday/dp/0525538585/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1689697500&sr=8-1) and other books) [1:15]
- [Arthur Brooks](https://www.hbs.edu/faculty/Pages/profile.aspx?facId=1134664) (Author of [*From Strength to Strength*](https://www.amazon.com/Strength-Finding-Success-Happiness-Purpose/dp/059319148X/ref=sr_1_1?crid=1C63EK713ZM0X&keywords=from+strength+to+strength+arthur+brooks&qid=1689697618&sprefix=From+S%2Caps%2C109&sr=8-1) and Professor at Harvard Business School) [1:15]
- [Bill Perkins](https://www.diewithzerobook.com/welcome) (Author of [*Die with Zero*](https://www.amazon.com/Die-Zero-Getting-Your-Money/dp/0358099765/ref=sr_1_1?crid=2D0N2WRLFRIAV&keywords=die+with+zero+bill+perkins+hardcover&qid=1689697715&sprefix=die+with+zero+bill%2Caps%2C92&sr=8-1) and hedge fund manager) [1:30]
- [Richard Bach](https://richardbach.com/bio) (Author of [*Jonathan Livingston Seagull*](https://www.amazon.com/Jonathan-Livingston-Seagull-Richard-Bach/dp/0684846845/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=1689862139&sr=8-1) and pilot) [6:30]
- [David Brooks](https://www.nytimes.com/by/david-brooks) (Op-Ed columnist for *The New York Times* and commentator for *PBS NewsHour* and more) [13:30]
- [David Allen](https://en.wikipedia.org/wiki/David_Allen_(author)) (Author of [*Getting Things Done*](https://www.amazon.com/Getting-Things-Done-Stress-Free-Productivity/dp/0143126563/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1689873371&sr=8-1)) [19:30]
- [Judith Shulevitz](https://www.judithshulevitz.com/author/) (writer and Science Editor of *The New Republic*) [39:00]
- [Elizabeth Gilbert](https://www.elizabethgilbert.com/bio/) (Journalist and author) [43:30]
- [Warren Buffet](https://en.wikipedia.org/wiki/Warren_Buffett) (American business magnate, investor, and philanthropist) [44:30]
- [Iddo Landau](https://www.psychologytoday.com/us/contributors/iddo-landau-phd) (Professor of Philosophy at the University of Haifa and author of [*Finding Meaning in an Imperfect World*](https://www.amazon.com/Finding-Meaning-Imperfect-World-Landau/dp/0190657669)) [56:00]
- [Joko Beck](https://www.ordinarymind.com/charlotte-joko-beck) (American Zen teacher and author) [1:05:00]
- [Kieran Setiya](http://www.ksetiya.net/) (Professor of Philosophy at MIT and author) [1:06:45]
- [John Maynard Keynes](https://en.wikipedia.org/wiki/John_Maynard_Keynes) (An English economist whose writings were the basis of Keynesian economics) [1:08:30]
- [Martin Heidegger](https://en.wikipedia.org/wiki/Martin_Heidegger) (German philosopher) [1:14:15]
- [Dogen](https://en.wikipedia.org/wiki/D%C5%8Dgen) (13th century Japanese Buddhist priest, writer, poet, philosopher, and founder of the Sōtō school of Zen in Japan) [1:17:00]
- [Jorge Luis Borges](https://en.wikipedia.org/wiki/Jorge_Luis_Borges) (Argentinian novelist) [1:19:30]
- [Jennifer Roberts](https://haa.fas.harvard.edu/people/jennifer-roberts) (Drew Gilpin Faust Professor of the Humanities, American and Contemporary Art at Harvard) [1:28:15]
- [Scott Peck](https://en.wikipedia.org/wiki/M._Scott_Peck) (Psychiatrist and author of [*The Road Less Traveled*](https://www.amazon.com/Road-Less-Traveled-Timeless-Traditional/dp/0743243153/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1690206226&sr=8-1)) [1:28:30]
- [John Keats](https://en.wikipedia.org/wiki/John_Keats) (English poet) [1:34:00]
- [Robert Boice](https://www.librarything.com/author/boicerobert) (Emeritus Professor of Psychology at State University of New York at Stony Brook) [1:34:45]
- [Joseph Goldstein](https://www.dharma.org/teacher/joseph-goldstein/) (Meditation teacher and cofounder of Insight Meditation Society in Barre, Massachusetts) [1:42:00]

§

![](https://peterattiamd.com/wp-content/uploads/2023/08/bio-oliverburkeman-432x500.jpeg)

##### Oliver Burkeman

Oliver Burkeman is a British journalist and author. He wrote the highly popular former weekly column on psychology, “This Column Will Change Your Life*”*, for *The Guardian*. His books include [*HELP!: How to Become Slightly Happier and Get a Bit More Done*](https://www.amazon.com/HELP-Become-Slightly-Happier-More/dp/0857860267/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=), [*The Antidote: Happiness for People Who Can’t Stand Positive Thinking*](https://www.amazon.com/Antidote-Happiness-People-Positive-Thinking/dp/0865479410/ref=tmm_hrd_swatch_0?_encoding=UTF8&qid=&sr=), and most recently, [*Four Thousand Weeks: Time Management for Mortals*](https://www.amazon.com/Four-Thousand-Weeks-Management-Mortals/dp/1250849357/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=1686916362&sr=8-1) (now available in paperback). He was awarded the Foreign Press Association’s Young Journalist of the Year Award and was short-listed for the Orwell Prize. [[Oliver Burkeman](https://www.oliverburkeman.com/about)]

Website: [Oliver Burkeman](https://www.oliverburkeman.com/)

Twitter: [@oliverburkeman](https://twitter.com/oliverburkeman?lang=en)