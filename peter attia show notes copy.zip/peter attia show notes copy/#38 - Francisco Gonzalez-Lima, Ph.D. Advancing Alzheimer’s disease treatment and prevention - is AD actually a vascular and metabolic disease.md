# #38 – Francisco Gonzalez-Lima, Ph.D.: Advancing Alzheimer’s disease treatment and prevention – is AD actually a vascular and metabolic disease?

**Source:** [https://peterattiamd.com/franciscogonzalezlima/](https://peterattiamd.com/franciscogonzalezlima/)

---

In this episode, Francisco Gonzalez-Lima, a Professor of Neuroscience and Pharmacology & Toxicology, explains the vascular hypothesis of Alzheimer’s disease which says the central problem is a progressive neuronal energy crisis of impaired blood flow to the brain and impaired mitochondrial respiration. He walks us through the ways we can intervene in this process and also shares details of the exciting future of Alzheimer’s treatment and prevention.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [RSS](https://peterattiadrive.libsyn.com/rss) | [GOOGLE](https://play.google.com/music/listen?u=0#/ps/I62zf7gjwceppzhmrdrpmfbzhby) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive) | [STITCHER](https://www.stitcher.com/s?fid=200010)

![The Peter Attia Drive](images/franciscogonzalezlima/the_Drive_public.png)

Play

#38 - Francisco Gonzalez-Lima, Ph.D.: Advancing Alzheimer's disease treatment and prevention – is AD actually a vascular and metabolic disease?

#38 - Francisco Gonzalez-Lima, Ph.D.: Advancing Alzheimer's disease treatment and prevention – is AD actually a vascular and metabolic disease?

1x15s30s

0:002:31:55

## We discuss:

- Background and interest in the brain [5:15];
- The unique nature of the human brain [9:15];
- Why we’ve made so little progress in Alzheimer’s research [23:00];
- The amyloid beta hypothesis [28:30];
- Hypometabolism in the brain leading to cognitive decline [39:30];
- Early signs of AD, and deciphering between age-related decline versus something pathologic [47:45];
- The vascular hypothesis of Alzheimer’s disease [54:00];
- The relationship between mitochondria, cytochrome c oxidase, and Alzheimer’s disease [1:08:00];
- Chronic inhibition of cytochrome c oxidase leads to chronic neurodegenerative disease [1:22:45];
- Major risk factors for AD, head trauma, and other forms of dementia [1:33:45];
- Methylene blue for treating and preventing neurodegeneration [1:38:15];
- Current standard of care for AD, and the reasons for a lack of advancement [2:01:45];
- Near infrared light as a targeted treatment for cognitive decline [2:05:30];
- The ketogenic diet as a treatment and preventative measure [2:13:15];
- Exciting future research coming from Francisco [2:23:00];
- Methylene blue for traumatic brain injuries [2:25:15]; and
- More.

Featured image credit: Quasar Jarosz at English Wikipedia [[CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) or [GFDL](https://www.gnu.org/copyleft/fdl.html)]

§

## Show Notes

## Background and interest in the brain [5:15]

- Professor at the [University of Texas in Austin at the Institute for Neuroscience](https://neuroscienceinstitute.utexas.edu/) in the Department of Psychology as well as in the Department of Psychiatry at the Dell Medical School
- Considers himself a *behavioral neuroscientist*: someone who studies how the brain relates to behavior
- As a Humboldt fellow in Germany, he was using functional brain mapping to understand how behavioral functions reflected in brain activity which lead to the [FDG-PET](https://www.acrin.org/patients/aboutimagingexamsandagents/aboutpetscans.aspx) technology (the first functional imaging technique in humans)

Functional studies versus imaging studies

- *Functional*
  - PET, positron emission tomography being a great example of a *functional study*
  - functional resolution with respect to glucose uptake
  - Disease recognition: It allows you to see functional changes even before you have any other physical signs of a disease
  - f-MRI is more commonly recognized
- *Imaging*=Imaging studies are giving you anatomic resolution

Interest in the brain

- Born in Cuba
- Father was a veterinarian
- realized the nervous system was so important for the entire health of the animal and the behavior of the animals
- Started to move away from just a more general interest to something that had to do more with the brain
- Key influence was [Dr. Joan King](https://csu-cvmbs.colostate.edu/academics/bms/Pages/celebrating-joan-king-tobet.aspx) during his an undergraduate at Tulane University, joined her lab to do an honors thesis working on the relationship between the brain, hormones, and behavior in animal models

## The unique nature of the human brain [9:15]

- The brain physically looks much different than all other organs in the body
- Our knowledge of the brain is far behind that of any other organ at the physiologic signaling level

Great analogy:

- You can think of the heart as a mechanical engineer, or a hydraulic pump
- The brain is more of an electrical engineer where you have lots of circuits
- The liver will be a chemical engineer where we break down all of these substances that the body consumes
- The kidney would be a sanitation filtering engineer/environmental engineer
- And the brain also can be viewed as a computer science engineer

> “One cannot simply look at the brain the same way as you look at other organs. Because of that circuit property, it allows the developing of computational power. So the brain uses the circuits not just for communication, which is the most obvious function, but to determine and compute outcomes that there are used to guide the other tissues in the body.”

Convergency and redundancy:

*“The brain is a very redundant parallel system where there has to be a lot of convergency between different regions that are computing for that to be acknowledged as the way to go in a behavioral point of view.”*

- All of the anatomy is redundant and parallel ⇒ We have two arms, two legs, two parallel blood vessels where you can get the blood from one point to another in more than one way
- *The brain takes this redundancy to the extreme*: the redundancy is combined with the acquisition of new networks or circuit options
- The brain uses this redundancy and “converges” on the right action or strategy
- In other words, you have all these multiple parallel systems and they’re doing these computations,  but only the ones that *converge* on the same solutions are the ones that are acknowledged and move on for the next stage

Humans vs animal brains

- Most of the differences have to do where which of the networks are more developed than others
- In primates, the [cerebral cortex](https://en.wikipedia.org/wiki/Cerebral_cortex) is the dominant component in the brain
- With reptiles or amphibians, the [midbrain](https://en.wikipedia.org/wiki/Midbrain) (mesencephalon) is the largest part of the brain
  - A “reflex” is the lowest level of response
  - Example, a frog, who operates primarily through the midbrain, will only pursue a worm (as food) if the worm is moving in its typical fashion inching along the ground… if the worm were to stand up and be perpendicular to the ground, the frog would no longer pursue it… “the pattern isn’t recognized”
- In mammals,
  - We have to move information to the level of the thalamus, a bit higher than the midbrain
  - But the majority of the mass of the brain, in primates and humans, in particular, is in the cerebral cortex, so we pass information from the [thalamus](https://en.wikipedia.org/wiki/Thalamus) to the cerebral cortex and then feed that back down to the output systems

*A simplified summary of the process for humans:*

- The [brainstem](https://en.wikipedia.org/wiki/Brainstem) and the [spinal cord](https://en.wikipedia.org/wiki/Spinal_cord) are responsible for reflexes ⇒ we breathe without thinking because our brain stem allows us to (i.e. an automatic response to a stimulus)
- The midbrain took it up a notch by basically allowing for that stimulus-response
- But then thalamus then becomes the gateway to the cortex where we can do this higher process

The main role of the cerebral cortex

- It gives us the ability to delay a response and to try to compute what are the consequences if we were to make that response
- The majority of the influence of the cerebral cortex on subcortical levels is *inhibitory*
- This idea is actually a bit misunderstood in many cases
- What the brain is doing is inhibiting all possible vectors of movement in a space and then selectively releasing some of them by sending an inhibitory signal to the other possible responses
- “So the engineering of the brain requires more effort in order to achieve something that could have been achieved by a more simplified system because it wants that control”

⇒ **Nearly all of neurodegenerative diseases are seen in the cerebral cortex** (exception being [Parkinson’s](https://www.mayoclinic.org/diseases-conditions/parkinsons-disease/symptoms-causes/syc-20376055) which is mainly midbrain)

## Why we’ve made so little progress in Alzheimer’s research [23:00]

> “We have not made any significant progress in Alzheimer’s disease research. This is the largest failure of the biomedical research enterprise in the world during my lifetime.”

**Beginnings of AD discovery and research**

Alois Alzheimer

- The main reason we’ve made so little progress is that “we have remained faithful to an initial observation” in 1907 by [Alois Alzheimer](https://en.wikipedia.org/wiki/Alois_Alzheimer) looking at a [patient who died of early onset dementia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2993534/)
- He was surprised by this young patient that was showing these early signs of dementia in his 50s
- What Alzheimer described in the brain of that individual as Alzheimer’s disease is NOT the same disease that is happening in older people today
- **This has been the most basic misunderstanding from the very beginning**

Oskar Fischer

- The work of Fischer was long forgotten until recently being uncovered
- He looked at [16 brains from much older individuals](https://www.alzforum.org/papers/miliaere-nekrosen-mit-drusigen-wucherungen-der-neurofibrillen-eine-regelmassige-veraenderung#comments) (70-80) but had similar abnormalities as Alzheimer’s single patient
- He described them as having senile dementia, something different than Alois Alzheimer’s patient
- [Here’s a summary of Fischer’s work](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2668940/)

Emil Kraepelin

- Kraepelin was a rival of Fischer and he more or less squashed Fischer’s work
- He [published a book](https://www.amazon.com/Kraepelins-Psychiatrie-Foundations-Psychiatry-Neuroscience/dp/1855069709) argued that what they were seeing in older patients was the same thing that Alois Alzheimer described in his young patient

> “From there on, there was a moving away from factors that were related to aging, and [towards the argument] that this is a disease that is embedding somehow, and is not something that is building up over the years. Of course, this is actually not the case.”

Is AD an inherited disease?

- This is a misconception
- In the rare cases of early-onset Alzheimer’ disease, there is evidence for inheritance
- **In 9 out of 10 cases of Alzheimer’s disease, there is absolutely no inheritance or familial component**
- Instead, it develops very slowly over the decades, which it provides an opportunity to intervene to determine what are the risk factors that are behind and to do an intervention

## The amyloid beta hypothesis [28:30]

> “This hypothesis is completely and absolutely false. It has no relationship whatsoever with what we see in the older people that develop dementia.”

Early-onset Alzheimer’s Disease (EOAD)

- Alois Alzheimer’s case study of his patient in 1907 was likely a case of what we now refer to as Early-onset Alzheimer’s Disease (EOAD)
- This disease is characterized by a mutation in the [PSEN1](https://en.wikipedia.org/wiki/PSEN1) or PSEN2 gene causing dementia
- EOAD is a hereditary disease
- And it is clear that amyloid beta is playing a causal role in these cases
- **Less than 1% of the population is affected by EOAD**
- So even though a very small percentage of people that are described as having Alzheimer’s belongs to this early onset, over 90% of the research is focused on that group
- Many believe today that if we find out what’s happening in the early onset cases, and we model that in animals by doing this genetic manipulation, then we can fix the more common senile, older age late-onset dementia
- “And that false premise is what has been driving all these failures”

Flawed mouse model

- A native gene was taken from the mouse and replaced with a gene that was common in a patient with early onset Alzheimer’s
- But even before that gene could start any observable deposition of amyloid they had severe atrophy in certain regions including hippocampal formation which had lost one-third of its volume
- The intervention itself may have altered the resilience of the brain
- So of course then these animals show all kinds of behavioral abnormalities, but these things were happening even before there was any amyloid deposition
- So it was clear that having a gene with these abnormalities, even before you can see that problem building up is enough to destroy how the brain develops

> “There is absolutely no correlation, no relationship, between the amount of amyloid beta deposition and the onset of memory deficits, cognitive impairment, or the progression of the disease.”

**Is amyloid beta necessary for AD but just not sufficient?**

Francisco has [examined brains](https://www.jneurosci.org/content/21/13/4923.long) of individuals who were cognitively normal and compared them with individuals of those who were diagnosed with AD

⇒ The neuropathologists couldn’t differentiate the cognitively normal subjects from the ones with Alzheimer’s based on amyloid or neurofibrillary tangle depositions

- **Peter’s take:** “That’s an enormous statement. It doesn’t call into question the causality of amyloid. It just calls into it the necessity and sufficiency of it. In other words, it could be that you need to have amyloid beta deposition to cause dementia, but that is not sufficient. It is only a necessary condition. And that you might need other factors to coalesce around it. The obvious example that comes to my mind is LDL and ApoB, which is necessary for cardiovascular disease, but not alone sufficient. You still need an inflammatory response and an immune response.”
- **Francisco clarifies:** “It is not causally related to what we call primarily Alzheimer’s disease, which is this majority of late-onsets. That’s not true for the early-onset. What I’m saying is that they are two different diseases.”

*⇒ But then why do all patients who die with AD have amyloid beta deposition?*

- They all have it because it is an *age-related deposition*
- The only reason that they are labeled as Alzheimer’s is because they had characterics of dementia… the pathology cannot really tell them apart

## Hypometabolism in the brain leading to cognitive decline [39:30]

**Hypofunctioning metabolism in the brain**

- Hypometabolism means there is less glucose uptake in the brain
- Patients who are in the stages of cognitive decline have hypofunctioning metabolism

⇒ Francisco’s [2001 paper studying brains of AD patients](https://www.jneurosci.org/content/21/13/4923.long)

- Interested in what biochemical changes might account for this so-called hypometabolism
- Found that hypometabolism is primarily in the [posterior cingulate cortex](https://en.wikipedia.org/wiki/Posterior_cingulate_cortex)

Posterior cingulate cortex

- This region provides the major input to what is called the [entorhinal cortex](https://en.wikipedia.org/wiki/Entorhinal_cortex), which is the part of the temporal lobe that then feeds into the hippocampal formation
- So what essentially is happening, is you have a functional disconnection between the main input to the primary source of inputs to the hippocampal formation
- So when you functionally denervate a region in the brain, eventually that leads to atrophy from that region that receiving the stimulus
- Just like happens when you enervate a muscle in the periphery, there is atrophic action when action that that region survives because it’s being stimulated by the other one.
- “So people have missed this. When you started pathology, you don’t study these functional changes and you don’t look at the system as a network of pathways or influence. Functionality. You’re seeing the end result, what has happened after all these processes have taken place over the years. So by doing that, you cannot infer this other phenomenon.”

*What happens is you shut off posterior cingulate cortex?*

- If you functionally deactivate it simulates what is actually happening in AD patients
- You will be affecting the network that is providing the main input to the hippocampal formation
- And you get the same kind of memory deficits that are characteristic to the initial stages of dementia

*Why does this happen? Is that because of the role the hippocampus plays in the consolidation of memory?*

- The memory deficits are because you are affecting a network, rather than a single region
- It is interrupting the [Papez circuit](https://en.wikipedia.org/wiki/Papez_circuit) described by [James Papez](https://en.wikipedia.org/wiki/James_Papez) in the 1930s
- So if you affect this system anywhere in this system, you get a memory disease, and they just have different names

![](https://peterattiamd.com/wp-content/uploads/2019/01/Papez-circuit-1024x901.png)

**Figure 1. The Papez circuit.** Image credit: [drawittoknowit.com](https://www.drawittoknowit.com/course/neuroanatomy/glossary/physiological-process/the-papez-circuit)

## Early signs of AD, and deciphering between age-related decline versus something pathologic [47:45]

**Anterograde amnesia**

- Inability to form short-term memories
- This is the first sign of AD
- Main problem is in the NOT in the limbic circuit (which is down the road and you can see behavioral changes in the individual)
- But before that, in the prefrontal cortex, especially lateral, we call dorsolateral prefrontal cortex, you have a functional deficit that is interfering with what we call working memory

*Memories have 3 stages*

1. Immediate memory, where you can remember things for only a few seconds (remembering a phone number just given to you)
2. [Working memory](https://en.wikipedia.org/wiki/Working_memory), you can remember things that happened recently but it’s only held there temporarily
3. Permanent memory (or [long-term memory](https://en.wikipedia.org/wiki/Long-term_memory)), where knowledge is held indefinitely

**Retrograde amnesia**

- Losing access to long-term memories
- Problems in the limbic system
- So when you start to forget permanent memories (i.e. your own phone number which you’ve known your whole life), this is an example of retrograde amnesia
- This is when family members start to notice something is wrong
- But the patients tend to become concerned much sooner. The patients become concerned with the antegrade memory deficits.

**Differentiating between age-related decline in cognitive function vs. something pathologic**

- Hard to standardize because everyone is different
- Everybody goes through this cognitive decline, just to a different extent
- The only way to know for sure is to compare this to your own history, to compare it to yourself

**Francisco’s approach**

- *When to intervene?* ⇒ Start when the individual person notices changes in himself
- The main target at that point is to intervene in the prefrontal cortex, the region that is just behind your forehead
- This is the central executive network that for cognitive processing that is involving working memory, problem-solving, sustained attention and vigilance.
- Those are the things that you’re gonna be seeing first having a decline as you grow older

> “But it is possible to intervene before you get into the limbic system problems, and that’s the approach that we have done with our interventions. And I think that’s what’s gonna make the biggest difference.”

## The vascular hypothesis of Alzheimer’s disease [54:00]

> “The prevalence of late-onset Alzheimer’s disease is increasing at a rate disproportionate to the increase in our longevity”

Francisco uses five areas of study to understand AD

1. The epidemiology of the disease
2. The imaging of the disease
3. The pharmacologic response to the disease
4. The pathologic findings in the disease
5. The clinical course of the disease

**The vascular hypothesis**

- Francisco subscribes to this hypothesis
- This hypothesis applies to late-onset AD (not early-onset AD)
- **If you compromise circulation to the brain, you are always going to get a neurological deficit**
- There is a chronic hypoperfusion, that is, the brain is receiving less blood supply
- Between 22 years old through 60 years old, there is a decrease of about 20 percent on your supply of blood to the brain
- ⇒ *Why though?* Paradoxically as we age, we’re seeing an increase in our blood pressure typically. So you would think that should increase cerebral perfusion, not decrease it…
- But it’s because the vascular changes happen at the macroscopic *and* microscopic levels

Macroscopically:

- The carotid artery (the one in the neck that supplies the blood to the head) is where most of the blood is going to the brain
- There is a linear relationship between what we call the intima-media thickness, the layers of the artery, and the decline in cognitive function
- *Why linear?*
  - We have an auto-regulatory mechanism which dampens it from exponential problem to a linear problem
  - Kind of like putting your thumb partially over the end of a running hose to make the water spray faster
- This process results in a higher systolic blood pressure… resulting in microvascular issues

Microvascular problem:

- **The body’s automatic compensation for the macrovascular disease (increase in blood pressure) may actually be driving part of the damage at the microvascular disease**
- You’re pushing now with higher blood pressure through capillaries which subjects the endothelial walls to mechanical pressures that they were not designed to do
- Then the platelets start to coagulate and stick to the endothelial walls which are compromising some of the microcirculation as a consequence
- And that’s why we’re better off with less blood pressure by controlling your high blood pressure. . .even though you’re trying to make up for the decreased blood supply

[New guidelines have come out for blood pressure](https://www.health.harvard.edu/heart-health/reading-the-new-blood-pressure-guidelines)

- Old recommendation was to stay under 135/90 mmHg
- New recommendation is under 120/80 mmHg

**Vascular disease** ***in the heart***

- The arterial walls are thicker
- The inner walls are no longer smooth
- This creates turbulence
- White blood cells identify this area of turbulence as an area of injury, and they start aggregating there
- And because of all the turbulence itself, they start then dying out against the walls
- Cholesterol levels then can add to it, but they are not the problem, people are confusing causality
- “Lowering your total cholesterol is not going to really make a major difference in this progression. Which is I think one of the biggest misconceptions that is happening in medicine right now.”
- But in any case, you have a number of phenomena that are taking place, that are contributing to the vascular hypoperfusion.

On the other hand…

- You can have the similar type of insult to the brain not coming from this arteriosclerotic process
- If the heart muscle itself is compromised in its function, because of a process where it weakens its ability to operate as a pump, you’re going to have hypoperfusion developing
- So you can have heart disease that has affected the pumping, you know, the force of the pump, that can lead to the hypoperfusion.
- You can have arterial disease like arteriosclerosis that is causing similar kind of phenomenon with some more complications that are detected by this high blood pressure
- In the cardiac case you will not see the high blood pressure, but in the other one you will see that
- “The health of the heart, and the arterial circulation, in particular, is very closely related to the health of the brain. So whatever you do that improves cardiovascular health will also help the brain.”

*Peter’s summary*:

⇒ The differentiation between brain-related and heart-related diseases…

- First, ***the brain is more exposed to high blood pressure than the heart***
  - The brain is perfused during systole
  - The heart is the only organ that is actually perfused during diastole
  - So in that sense the coronary arteries themselves are less susceptible to hypertension compared to the brain, or the kidney for that matter, which would be the two organs which seem to be most damaged by hypertension
- Secondly, in the process of atherosclerosis in the heart, cholesterol does play a very important role, but you still need the initiation of the endothelial injury, which is necessary, but once the lipoprotein can get inside the subendothelial space and becomes oxidized, that’s what elicits the immune response, which is what does the damage

**See Peter’s post detailing this process: [When does heart disease begin (and what this tells us about prevention)?](https://peterattiamd.com/heart-disease-begin-tell-us-prevention/)**

⇒ Two distinct diseases in the brain

1. **The“brain attack”**: the way we think of a heart attack where cerebrovascular disease leads to strokes, occlusive or hemorrhagic that is the result of an acute hypoperfusion that usually produces a much more functional deficit
2. **Chronic hypoperfusion**: a different type of much more indolent, chronic hypoperfusion which has a slightly different pathophysiology from coronary physiology in that it doesn’t produce an acute event but rather a chronic disease

## The relationship between mitochondria, cytochrome c oxidase, and Alzheimer’s disease [1:08:00]

⇒ The epidemiology shows that there’s no greater association with Alzheimer’s disease (or cardiovascular) than age . . . but after age, reduced activity of [cytochrome c oxidase](https://en.wikipedia.org/wiki/Cytochrome_c_oxidase) in the brains of AD patients is next most heavily associated with cognitive decline

**Cytochrome c oxidase**

*Why is cytochrome c oxidase important?*

- It is the enzyme that is responsible for oxygen consumption at the cellular level
- Also known as [Complex IV](https://en.wikipedia.org/wiki/Electron_transport_chain#Complex_IV) in the [electron transport chain](https://en.wikipedia.org/wiki/Electron_transport_chain)
- Therefore without cytochrome c oxidase, the mitochondria have a difficult time creating [ATP](https://en.wikipedia.org/wiki/Adenosine_triphosphate) (energy)

*The electron transport chain is the key to life*

- The mitochondria has an inner and outer membrane
- There are four complexes
- Three of them span both the inner and outer membrane, that’s 1, 3, and 4
- Complex 2 is only on the inner membrane
- Interrupting their activity of these complexes for even moments at a time is the end of life

**Mitochondria**

*How do we create energy?*

- when we eat food we’re eating stored potential energy that is in a chemical form
- The mitochondria takes these units, breaks them apart into electron donors that can be moved the [ETC](https://en.wikipedia.org/wiki/Electron_transport_chain)
- The electron donors are NADH and FADH
- NADH donates to many parts of the ETC (whereas FADH only donates to complex 2)
- All of this is in service of creating an electron gradient to then fuel the generation of adenosine triphosphate, ATP
- “This is a biochemical key to this phenomenon because what we eat from an energy point of view is just becoming electron donors.”
- The question then becomes… *Can we donate electrons to the electron transport?* ⇒ If we could do that, we can accelerate respiration

*Peter summarizes what mitochondria do:*

“The whole purpose of eating is to convert chemical energy into chemical energy from one form to another, but to do it you need an intermediary to translate, that that intermediate has to turn the chemical energy into electrical energy that then facilitates a conversion back to chemical energy. That is the key to life and that is what the mitochondria do.”

*Every organism on the planet that uses oxygen to obtain energy relies on Cytochrome c oxidase (also known as complex IV in the ETC)*

- If you’re not getting enough oxygen, the process cannot move on to produce electron donations
- This might explain why dementia patients are driven to eat simple carbohydrates

*So do you think that this is the first insult then? How does that change ultimately impact the ability of the mitochondria to do its job and facilitate electron transfer?*

- This is what links this phenomenon regardless of whether the chronic hypoperfusion or the more acute, one of the things that happen is when we have a hypoxia situation cytochrome oxidase is an inducible enzyme
- What that means is that our body only maintains as much as is needed, as much as is demanded
- For example, you have an area of ischemia or you occlude the blood vessel, half an hour later you’ve lost a significant amount of cytochrome oxidase from

*But can it be reversed?*

- Yes, that’s the advantage of the system
- The system works on demand, it may not be immediately reversible, it depends on the level of regulation

*Mitochondria have a symbiotic relationship with the cells*

- This was created to develop a dependency
- the mitochondria are doing this but they cannot do it on their own
- The cell has to find a way to obtain the energy but it’s conditional on them contributing a component that is necessary for the entire machinery to work
- The important portion here is that these phenomena are a couple
- As soon as you have hypoxia, or ischemia, then this machinery gets downregulated

*Is that true of complex 1, 2, 3 as well? Are they also inducible the way complex 4 is?*

- Not as much as complex 4
- They are to a certain degree, if you keep taxing the system it’s going to happen, but the one that has more flexibility, from more immediate to long term, because of this role, is very limiting, is complex 4, and that’s the reason it’s referred to as the modulator of the system

> “This is the key that I have understood from our investigation of the Alzheimer’s brain. In those fresh frozen Alzheimer’s brains, the main problem was cytochrome oxidase inhibition. The protein levels of the enzymes were not compromised, but you could see that the enzyme was not in its catalytic functional state and you could demonstrate this viewing the enzyme histochemistry.”

## Chronic inhibition of cytochrome c oxidase leads to chronic neurodegenerative disease [1:22:45]

*What is the magnitude of deficit in cytochrome c oxidase that you need to result in the phenotype that we observe clinically?*

- If you inhibit cytochrome oxidase after about 40% in an organism, the organism dies
- Cyanide is an example
- It will kill you instantly even in low doses

*However, if cyanide is diluted enough it can be a chronic insult…*

⇒ Francisco [did this experiment](https://www.ncbi.nlm.nih.gov/pubmed/11346134) in collaboration with [Jack de la Torre](https://www.omicsonline.org/editor-profile/Jack_de_la_Torre/)

- Book rec: [Alzheimer’s Turning Point](https://www.amazon.com/Alzheimers-Turning-Point-Vascular-Prevention-dp-3319340565/dp/3319340565/ref=mt_hardcover?_encoding=UTF8&me=&qid=) by Jack de la Torre
- If you compromise the circulation by partially occluding blood vessels to the brain, you get a downregulation of cytochrome c oxidase and therefore mitochondrial respiration and ATP production
- Animal shows a picture that is analogous to what you see in neurocognitive disorders
- Decreasing cytochrome c oxidase up to 30% without seeing any neurological evident change
- The animals appear to be eating and behaving normally, but when you test them with cognitive memory test they cannot perform well ⇒ just like an AD patient

**Does inhibition of cytochrome c oxidase effect amyloid beta?**

- No, the amyloid beta would not be a good reflection of this processes
- The amyloid beta is primarily a process that is compensatory when the cells are showing atrophy
- When cells start showing signs of atrophy, we have a lot of amyloid beta that is released embryonically during the development of the nervous system and it’s because during development of the nervous system you have phases of large proliferation of neurons, but then you have other phases of trimming where there is a lot of neuronal death, and in those situations you see amyloid that is formed

**Apoptosis (programmed cell death)**

- A major signal for a cell to die in an aerobic organism is for the mitochondria to release cytochrome C (this cell death is called [apoptosis](https://en.wikipedia.org/wiki/Apoptosis))
- Cytochrome C is the protein that carries the electron to cytochrome C oxidase
- “So what I’m telling you is if you compromise the system you’re going to have neurodegeneration. You’re going to have cell death and not just in the nervous system. It just happens that there is more critical because in other systems we have other ways to get ATP, but in neurons, we don’t have any significant alternatives ways to get it.”

**Why is this happening more so in the brain than elsewhere?**

The brain has two problems…

1. *First it is an energetic problem* which is it is simply the most demanding and therefore it is the most susceptible to a reduction in total available energy. The brain weighs about 2% of our body weight and yet consumes about 20% of our total energy expenditure so that’s a grossly disproportionate amount of energy.
2. S*econdly, the brain has an over-reliance on oxidative phosphorylation* without an anaerobic escape route

> “If downregulation of cytochrome oxidase reaches a certain level, cytochrome C is going to start releasing … and cells start dying. So the direction of causality is completely different from the amyloid beta idea that the amyloid comes there because of the gene that is abnormal and then it’s creating these cascades that are leading to these changes … no.”

**Summarizing the vascular hypothesis:**

- What we have is problems with the supply of oxygen that happen to the brain and it’s this high energetic demand
- The vascular hypothesis of dementia is not exclusionary because you can have toxic insults that affect the mitochondria that will do something similar to these cardiovascular insults
- In other words, they’re going to lead also to downregulation of cytochrome oxidase and your inability to use oxygen to generate energy
- Vascular hypothesis of dementia also provides room for other insults to the brain that are going to be reflected at that level, and it’s only when they’re reflected at that level that then they, because of this energetic demand, this vulnerability that you eluded to, that then this is going to lead to a cognitive decline

*Why a cognitive problem and not something else?*

- These functions are not limited to one region of the brain, they are reliant on an interaction between different regions.
- So when you’re reading something, that information goes to your visual system, but then if you’re going to engage learning, you’re having to engage other systems, so the memory functions are more distributed.
- So when you have a more distributed metabolic insult they’re going to be affected.
- Somebody may get a blow to the head and then all of a sudden they may have retrograde amnesia and they may not remember what happened or who they even are… but you may not see any significant level of structural or functional damage, but you affected the way the systems interacted in a more global way
- **This is one of the reasons we detect this primarily as a memory problem initially, but later on, it becomes a neurodegenerative disorder when cells can no longer work without this mitochondrial machinery**

## Major risk factors for AD, head trauma, and other forms of dementia [1:33:45]

- **Blood pressure**
- **Atherosclerosis**
  - Looking at the major blood vessels such as the
  - carotid
  - ascending aorta
  - and the renal arteries
  - They are the main targets of the process especially at the bifurcation point
- **Generalized trauma to the brain**

*Head trauma*

- When getting hit in the head you’re having a transient interruption of blood flow and also it appears based on at least the animal models we’re seeing transient insulin resistance at the level of pyruvate dehydrogenase
- A blow to the head will transiently make it harder for pyruvate to turn into [acetyl CoA](https://en.wikipedia.org/wiki/Acetyl-CoA), which is the opening substrate in the [Krebs cycle](https://en.wikipedia.org/wiki/Citric_acid_cycle)
- The athletes who are suffering this type of injury are getting punctuated by spike functions of these and it doesn’t have to be a concussion every time. It could be each play on the field or something like that. Do you think there’s an overlap in these processes?
- Completely, this is what’s called the [dementia pugilistica](https://en.wikipedia.org/wiki/Chronic_traumatic_encephalopathy) which is often confused with Alzheimer’s and Parkinson’s disease
- [Parkinson’s disease](https://www.mayoclinic.org/diseases-conditions/parkinsons-disease/symptoms-causes/syc-20376055) is because when we the blows to the head, that is a rapid twisting of the head… that rapid twisting, bending of the head with respect to the neck affects the midbrain

> “All of these forms of dementia will have a common denominator at some point regardless of the many different ways that you can impact the system. The most likely common denominator will be at the level of the mitochondrial respiration.”

## Methylene blue for treating and preventing neurodegeneration [1:38:15]

**Methylene blue (MB)**

⇒ Francisco has shown in animals that MB can prevent degeneration in the brain (for example, [this paper](https://www.ncbi.nlm.nih.gov/pubmed/19384599) and [this paper](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2765788/))

⇒ You can sort through all of [Francisco’s publications on methylene blue here](https://www.ncbi.nlm.nih.gov/pubmed?term=Gonzalez-Lima%20F%20methylene%20blue)

- This is one of 2 approaches Francisco involving cytochrome c oxidase
- Methylene blue is a pharmacological approach
- It is able to act as an electron donor
- If you make a very low concentration it will also get electrons from other compounds and it will continue to feed into the electron transport as an alternate route
- For example, if you were to totally block complex I, it would be fatal in most cases… but methylene blue, you can still get electrons past the bottleneck of complex I using it as a bypass

Story behind methylene blue

- [Paul Ehrlich](https://en.wikipedia.org/wiki/Paul_Ehrlich)’s “magic bullet”
- Around 1886, they were manufacture clothing and there was a transition from using natural products for dyes to developing synthetic dyes (such as blue jeans)
- Paul Ehrlich injected methylene blue into a live rat
- He found out that the methylene blue primarily staining nervous tissue, the brain, and peripheral nervous tissue
- He created the concept of a [magic bullet](https://en.wikipedia.org/wiki/Magic_bullet_(medicine)), an idea that it could be possible to kill specific microbes (such as bacteria) that cause diseases without harming the body itself

Does it become toxic at a higher dose?

- It can become lethal
- At a higher dose instead of acting as an electron cycler, so it actually replaces oxygen and competes with oxygen

Other uses in medicine?

- The only currently FDA approved application⇒ Used for treating [methemoglobinemia](https://en.wikipedia.org/wiki/Methemoglobinemia) in the emergency room for someone who is exposed to carbon monoxide, acutely or even chronically over a longer period of time
  - This basically breaks it apart, so there you actually want to sort of “out-compete” oxygen
  - However, at too high concentrations, it can induce methemoglobinemia
  - MB is “bi-modal” ⇒ Essentially they do the opposite effects, low and high concentrations
- Past uses that have since been removed by the FDA:
  - Prior to antibiotics, it was used for a urinary or bladder infection
  - Malaria
  - Anti-psychotics

Chemotherapy and MB

- Many of the drugs are used for chemotherapy, have side effects that affect the brain in particular mitochondria respiration
- So methylene blue given before or during chemotherapy interventions are being found to be lifesaving
- One example is how MD can stop [ifosfamide-induced encephalopathy](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2363270/)

*Why isn’t it being made and approved in the US?*

- But there is no profit to be made because you cannot patent MB
- Impossible situation because the FDA can’t really consider it for approval until they can investigate it as new drug filing an indication
- But there is no company wanting to do that because they cannot protect it with a patent so anybody can manufacture methelyne blue and prescribe it

*Where can it be obtained? ⇒* In some countries like Canada, it’s freely available, and you can get it through the internet

*Beware: there are different purities, some of which are toxic*

- *Pharmaceutical grade (USP grade)*: the one that should be used by humans (like in the emergency room)
- *European MB*: have a similar, but the USP quality is actually more restricted than the European methylene blue
- *Chemical quality*: used in the lab for staining and it should not be given to live animals or humans, yet it is readily available
- *Industrial quality*: very toxic, used to make blue jeans

**A controversial study looking at methylene blue as an anti-tau agent for treating dementia**

*Several studies from a company called* [TauRx](https://taurx.com/)

- *2015:* [Tau aggregation inhibitor therapy: an exploratory phase 2 study in mild or moderate Alzheimer’s disease.](https://content.iospress.com/download/journal-of-alzheimers-disease/jad142874?id=journal-of-alzheimers-disease%2Fjad142874)
- 2016: [Efficacy and safety of tau-aggregation inhibitor therapy in patients with mild or moderate Alzheimer’s disease: a randomised, controlled, double-blind, parallel-arm, phase 3 trial.](https://taurx.com/uploads/Accepted%20Gauthier%20Nov2016%20FINAL.pdf)
- *2017:* [Potential of Low Dose Leuco-Methylthioninium Bis(Hydromethanesulphonate) (LMTM) Monotherapy for Treatment of Mild Alzheimer’s Disease: Cohort Analysis as Modified Primary Outcome in a Phase III Clinical Trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5734125/)

*The overview:*

- Took patients in early stages of dementia, randomize them to various interventions, and one of the groups was given LMTM (a derivative of MB)
- Very controversial part of the study was the primary endpoint of that study was a neuroimaging outcome and the primary output failed… there was no difference on neuroimaging
- But there was a secondary outcome on *cognitive function* in which a benefit was seen, which was about 15 percent

But are we being misled because the combination of methylene blue with other drugs obfuscates the results? ⇒ Yes, *however…*

⇒ The study designers presented **methylene blue as an anti-tau medication rather than as a metabolic enhancer acting on the mitochondria respiration.**

*Francisco’s take:*

- The hypothesis is completely wrong
- It is unfortunate that they have done it this way because they are undermining the potential benefits of methylene blue
- They found that it prevented the phosphorylation and agglutination of tau in vitro so they then infer or this an anti-tau agent
- If you test methylene blue with immediate different compounds depending on the concentration of methylene blue because he has reducing or an oxidation action, it will interfere with all kinds of phenomena, so there is nothing specific about its effect on tau
- So even though the data contradicted their hypothesis, they spun the story and results to fit their train of thought that this is an anti-tau agent

> “In other words, they did not change their hypothesis which was contradicted by their data. . .which is the same thing that’s been happening with the amyloid people. Their results do not support their hypothesis and yet they keep blindly moving forward.”

## Current standard of care for AD, and the reasons for a lack of advancement [2:01:45]

**Current standard of care for AD patients**

- Due to the lack of approval by the FDA for things like methylene blue, there are being prescribed to AD patients which have no benefit to the patients AND cause side effects
- The idea being, this is the standard of care and it would be “unethical” to take these patients off these agents even to allow them to enter another trial

Common drugs being prescribed:

- [Acetylcholinesterase inhibitor](https://en.wikipedia.org/wiki/Acetylcholinesterase) (most common)
- [Memantine](https://en.wikipedia.org/wiki/Memantine) (originally only for severe AD)

Ineffectiveness of these common drugs

- Subsequent [meta-analyses](https://www.ncbi.nlm.nih.gov/pubmed/30646339) all conclude very clearly that these are ineffective and they do not improve activities of daily living and that the disease continues to progress and people die
- Problems with *memantine*, specifically:
  - It is preventing some of the excited toxicity that is damaging hippocampal cells but you are essentially rescuing a dying a cell that is functionally incompetent
  - The problem with rescuing that dying cell is that you’re actually rescuing a cell that’s going to go on to send a signal that could cause more damage down the line
  - It is completely counterproductive and it’s based on the pathology oriented, that you can see more of these neurons they are when the people die

> “The real overarching challenge is triangulating between neurobiology, anatomy, and functional signaling. And then of course, ultimately, clinical outcomes matter more than any of these other things in the end.”

## Near infrared light as a targeted treatment for cognitive decline [2:05:30]

**Near** [**infrared light**](https://en.wikipedia.org/wiki/Infrared) **as an intervention**

- Infrared lights shined at the forehead can go through the tissue and skull and the photons in the near infrared light are absorbed by cytochrome oxidase
- This leads to the up-regulation of the mitochondrial enzymatic machinery to produce more energy

⇒ Francisco’s paper which shows the effect of methylene blue next to the effect of near-infrared light on mitochondria: [Protection against neurodegeneration with low-dose methylene blue and near-infrared light](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4428125/)

![](https://peterattiamd.com/wp-content/uploads/2019/01/MB-and-light-effect-on-mitochondria.jpg)

**Figure 2.** **Two neuroprotective interventions for enhancing mitochondrial respiration.** Low-dose methylene blue (MB) acts as an exogenous electron (e-) cycler, boosting oxygen consumption and cell respiration (molecular O2 reduced to H2O). Low-level red-to-near-infrared light directly energizes cytochrome oxidase (Complex IV) via photon absorption, facilitating its catalytic activity and leading to up-regulation of cytochrome oxidase levels. These interventions result in long-term increases in the amount of cytochrome oxidase in the electron transport chain by a process of enzymatic induction, which promotes oxidative energy metabolism and neuronal survival. Abbreviations: I–IV, refer to the four electron transport enzymatic complexes in the inner membrane of mitochondria; MB, is oxidized methylene blue (blue color); MBH2, is reduced methylene blue (colorless); H+, stands for the protons pumped by Complexes I, III, and IV that enter the mitochondrial matrix via ATP synthase, which results in ATP production. Image credit: [Gonzalez-Lima et al., 2015](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4428125/)

Challenges of the technology

- Getting through the skull is not a challenge
- Hemoglobin is the bigger challenge
- Hemoglobin can absorb and reflect much of this light before it actually reaches the neurons
- “What we try to do is we move away from this peak of absorption of oxyhemoglobin to one that still can be absorbed by cytochrome oxidase”

How many nanometers?

- We use 1064 nanometers wavelength
- the longer the wavelength, the more it penetrates through the tissues

How safe is this?

- They cannot really penetrate inside atoms like the ones that have short wavelengths
- They are good enough to penetrate to the tissues, not very deep and only about 1 to 2% actually goes through to the surface of the cerebral cortex

How does it work?

- The effect of the photons is primarily in the gray matter layer of the cerebral cortex.
- And what it does is it to donating these photons to the electron transport
- You’re bypassing the electron donors and giving them photons instead
- Photons are not identical to electrons, but they act in a similar way in the electron transport
- The more photons you send to cytochrome oxidase, the more of the enzymes quickly goes to the oxidized confirmation, and that oxidized confirmation is the one that has more affinity to bind oxygen

*How is this actually making its way systemically to the brain?* ⇒ Not systemic, it’s a targeted approach

*Is it enough to create a clinical improvement without impacting the mitochondrial function deeper in the midbrain or lower part of the cortex?*

- Yes, to create a **functional** improvement
- Not sure yet about clinically
- “I would not say that in somebody with the degree of atrophy that many of the Alzheimer’s patients have that we’re going to have enough substrate there to be able to stimulate and reverse the disease.”

Combing near-infrared lights combined with methylene blue?

- No, not for treating AD… they are separate approaches
- However, they can be combined them as a targeted treatment for things like cancer lesions, and even viruses that are hard to kill
- This is called [photodynamic therapy](https://en.wikipedia.org/wiki/Photodynamic_therapy)

Photodynamic therapy with MB

- Methylene blue can be used as a sensitizer to the light and make the target more susceptible to the laser
- It has many applications: HIV and herpes
  - If you have a virus that you have no the way to kill, you can always kill it this way:
  - Methylene blue is injected into blood so that you can then treat the blood with photodynamic therapy to kill viruses like the HIV or herpes

Methylene blue orally or IV?

- Orally is safer, slower release
- Successful in treating malaria, for example

## The ketogenic diet as a treatment and preventative measure [2:13:15]

> “The ketogenic diet will facilitate mitochondria respiration especially in the brain. . .because of the brain’s reliance on aerobic metabolism.”

Insulin resistance in the brain

- One of the problems that happens as the brain ages, even in normal people, is that the transport of glucose is affected
- Even though we can increase glucose levels in the blood or what we eat, we cannot get that glucose transported to the brain as effectively in the younger individuals

An alternate energy source

- Ketone bodies act as an alternative source for energy in the brain
- So even though glucose is a preferred substrate, this is compromised with aging
- Therefore, you could satisfy some of these nutritional requirements by adding the ketone bodies to the diet

Does it matter whether a person is on a ketogenic diet or if they’re on a non-ketogenic diet but they supplement with exogenous ketones?

- Francisco is hopeful that it doesn’t matter
- As long as you have the ketone bodies available, you don’t require to have the ketogenic diet itself
- “This eventually will have to be resolved empirically and there is no question that he’s going to promote mitochondrial respiration.”

**Quick summary of the interventions for cognitive decline**

1. Systematic/metabolic, pharmacological interventions that address mitochondria respiration (i.e. methylene blue)
2. Targeted interventions (near-infrared light)
3. Dietary interventions to address the insulin resistance in the brain (ketosis and ketone supplements)

What drives appetite?

- There is a natural developing of metabolic syndrome as we grow old
- This manifests itself then as less substrate for energy for the brain and then you have cognitive decline accelerated associated with obesity and hypertension and this insulin resistance
- It’s all part of the same age-related picture
- Probably people eat more because they are trying to make up for this lack of energy that the brain is consuming
- And if any organ is more liable to influence our eating behavior, it will be the neural tissue

⇒ Peter’s take:

- I’ve always believed that our appetite is driven by fundamentally important physiologic processes and starvation would be the most important among them
- Starvation in the modern world can be in the presence of obesity because we’re not talking about the obvious, **we’re talking about the cellular level**
- And so if cellular metabolism is deficient, which is often the case in insulin resistance, an individual can be functionally starving and that can drive it

Fasting

- Periods of fasting can produce ketones
- You can to use your body fat to feed, especially the brain
- The first thing that somebody has to do is start out by having episodic periods of fasting
- However, in the presence of [hyperinsulinemia](https://en.wikipedia.org/wiki/Hyperinsulinemia), it is a very painful transition into fasting
- The ketogenesis enzyme will not be upregulated unless you’re consuming your own fat, and these are trainable enzymes
- Somebody who is obese and suddenly stops eating is going to feel starving because he hasn’t trained his metabolic system to be “fat-adapted”

## Exciting future research coming from Francisco [2:23:00]

- It might be possible to combine these 3 interventions
- But still need to empirically determine how much methylene blue one can have systemically in order to not produce a photodynamic effect when doing transcranial laser stimulation

Is the future LEDs?

- We hope in the future we may be out to do these with LEDs
- It will be safer and cheaper than current laser techniques
- However, with the LEDs are commercially available, we haven’t been able to find the results that we get, but we are investing time in trying to change this

Latest in transcranially imaging with [near-infrared spectroscopy](https://en.wikipedia.org/wiki/Near-infrared_spectroscopy)

- Francisco [published a paper last year](https://www.ncbi.nlm.nih.gov/pubmed/28178891)
- Able to measure the concentration of cytochrome oxidase in vivo in the human brain
- Allows us to directly have a measurement that we are indeed engaging our target and this also will allow us to find what is the optimal dose response for that particular brain.
- Different people at different heads and the transmission would not be equivalent.

Three major grants funding additional research

1. [Brain Initiative Program](https://www.braininitiative.nih.gov/) funded by the NIH: Developing devices to monitor the physiological changes
2. Grant from the [National Institute on Aging](https://en.wikipedia.org/wiki/National_Institute_on_Aging): Testing these transcranial near infrared lights in older people and people with mild cognitive impairment
3. Grant from a benefactor to pursue this line of work with transcranial lasers

![](https://peterattiamd.com/wp-content/uploads/2019/01/endorsement-pic-768x1024.jpg)

**Figure 3. Encouraging note from Jack de la Torre.**

## Methylene blue for traumatic brain injuries [2:25:15]

- Methylene blue has the potential as a rescue agent during periods of traumatic brain injury (including smaller, repetitive blows in sports like football and boxing)
- Mechanistically, it’s at least plausible that you could salvage and rescue some of the transient insult and the damage
- For example, there’s been some interesting hypotheses around the presence of **ketones** in the system before traumatic injury and potentially as a salvage agent
- Peter concludes: “It seems to me that this methylene blue story probably deserves a bit more attention in other areas given these properties you’ve described.”

Francisco adds:

- It should be in every ambulance and given to anybody with an insult (ischemic attack, stroke, head injury)
- Low dose of one milligram per kilogram
- In animal models, he’s [shown that it can rescue the majority of the damage](https://www.ncbi.nlm.nih.gov/pubmed/?term=francisco+gonzalez+lima+carotid) produced in the infarct
- The problem is there’s no interest by the pharmaceutical companies because they cannot make money on it

Francisco and team was the first to [show effects of methylene blue in the human brain using fMRI](https://www.ncbi.nlm.nih.gov/pubmed/27351678) ⇒ *Memory testing showed a significant improvement in their memory retrieval just after an acute treatment with methylene blue in a blind and placebo-controlled study*

![](https://peterattiamd.com/wp-content/uploads/2019/01/first-effects-in-human-brain-with-MB.jpg)

**Figure 4. Analysis of delayed match-to-sample task performance change (after intervention to before intervention) during the retrieval phase shows a significant increase in correct responses only in the methylene blue (MB) group (P = .01).** Error bars = standard error of mean. Image credit: [Rodriguez et al, 2017](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5084971/)

§

## Selected Links / Related Material

**Where Francisco works**: [Institute for Neuroscience – University of Texas](https://neuroscienceinstitute.utexas.edu/) | (utexas.edu) [5:45]

**Also part of faculty at**: [Department of Psychiatry at the Dell Medical School](https://dellmed.utexas.edu/units/department-of-psychiatry) | (utexas.edu) [5:45]

**Fellowship at the prestigious foundation in Germany where he helped to develop FDG-PET**: [Alexander von Humboldt Foundation](https://en.wikipedia.org/wiki/Alexander_von_Humboldt_Foundation) | (wikipedia.org) [6:15]

**Recent promise in treatment of solid organ tumors**: [Checkpoint inhibitors](https://en.wikipedia.org/wiki/Checkpoint_inhibitor) | (wikpedia.org) [23:15]

**Alois Alzheimer’s original 1907 case report translated to english**: [About a Peculiar Disease of the Cerebral Cortex, Alzheimer’s Original Case Revisited](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2993534/) (Martin Strassnig et al., 2005) [24:45]

**Fischer’s actual studying 16 brains with senile dementia:** [Fischer O. Miliaere Nekrosen mit drusigen Wucherungen der Neurofibrillen, eine regelmassige Veraenderung der Hirnrinde bei seniler Demenz. Monatsschr Psychiat Neurol. 1907 Jan 1](https://www.alzforum.org/papers/miliaere-nekrosen-mit-drusigen-wucherungen-der-neurofibrillen-eine-regelmassige-veraenderung#comments) | ([alzforum.org](https://www.alzforum.org/)) [26:15]

**Summary of Oskar Fischer’s work**: [Oskar Fischer and the study of dementia](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2668940/) (Goedert, 2009) [26:15]

**Kraepelin’s textbook suggesting (wrongly) that AD is a disease that is embedding somehow and is not something that is building up over the years**: [Foundations of Psychiatry and Neuroscience](https://www.amazon.com/Kraepelins-Psychiatrie-Foundations-Psychiatry-Neuroscience/dp/1855069709) by Emil Kraepelin | (amazon.com) [27:00]

**Genetic mutation found in cases of EOAD**:  [PSEN and AD](https://en.wikipedia.org/wiki/PSEN1#Alzheimer's_disease) | (wikipedia.org) [29:30]

**Francisco examined the brains of the first amyloid precursor mouse model that was developed**: [Reduced corpus callosum, fornix and hippocampus in PDAPP transgenic mouse model of Alzheimer’s disease.](https://www.ncbi.nlm.nih.gov/pubmed/11496113) (Gonzalez-Lima et al., 2001) [32:15]

**First mouse model for amyloid beta hypothesis**: [Formation of beta-amyloid protein deposits in brains of transgenic mice.](https://www.ncbi.nlm.nih.gov/pubmed/1906990%20tk) (Quon et al. 1991) [32:15]

**Francisco’s 2001 paper studying brains from recently deceased Alzheimer’s patients**: [Energy hypometabolism in posterior cingulate cortex of Alzheimer’s patients: superficial laminar cytochrome oxidase associated with disease duration.](https://www.jneurosci.org/content/21/13/4923.long) (Valla et al, 2001) [39:15]

**Francisco’s early work in PET**: [Structural equation modeling and its application to network analysis in functional brain imaging](https://onlinelibrary.wiley.com/doi/abs/10.1002/hbm.460020104) (McLntosh and Gonzalez-Lima, 1994) [41:30]

**The circuit which connects the hypothalamus to the limbic lobe and is the basis for emotional experiences**: [Papez circuit](https://en.wikipedia.org/wiki/Papez_circuit) | (wikipedia.org) [45:15]

**New blood pressure target has moved to 120/80**: [Reading the new blood pressure guidelines](https://www.health.harvard.edu/heart-health/reading-the-new-blood-pressure-guidelines) | (health.harvard.edu) [1:01:15]

**Peter’s article detailing the process of heart disease**: [When does heart disease begin (and what this tells us about prevention)?](https://peterattiamd.com/heart-disease-begin-tell-us-prevention/) | Peter Attia (peterattiamd.com) [1:06:15]

**Studies collaborated on by Francisco and Jack de la Torre**:

- [Reduced cytochrome oxidase and memory dysfunction after chronic brain ischemia in aged rats.](https://www.ncbi.nlm.nih.gov/pubmed/?term=francisco+gonzalez-lima+de+la+Torre) (de la Torre et al., 1997) [1:25:15]
- [Chronic cerebrovascular ischemia in aged rats: effects on brain metabolic capacity and behavior.](https://www.ncbi.nlm.nih.gov/pubmed/10867207) (Cada et al., 2000) [1:25:15]

**Book recommendation on the vascular hypothesis**: [Alzheimer’s Turning Point: A Vascular Approach to Clinical Prevention](https://www.amazon.com/Alzheimers-Turning-Point-Vascular-Prevention-dp-3319340565/dp/3319340565/ref=mt_hardcover?_encoding=UTF8&me=&qid=) by Jack C. de la Torre | (amazon.com) [1:25:15]

**Francisco using chronic sodium azide to study effects in the brain**: [Effects of chronic sodium azide on brain and muscle cytochrome oxidase activity: a potential model to investigate environmental contributions to neurodegenerative diseases.](https://www.ncbi.nlm.nih.gov/pubmed/11346134)  (Berndt et al., 2001) [1:25:15]

**Francisco shows that methylene blue can prevent neurodegeneration**:

- [Methylene blue provides behavioral and metabolic neuroprotection against optic neuropathy.](https://www.ncbi.nlm.nih.gov/pubmed/19384599) (Rojas et al., 2009) [1:39:15]
- [Striatal neuroprotection with methylene blue.](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2765788/) (Rojas et al., 2010) [1:39:15]

**Methylene blue as an antipsychotic**: [The story of antipsychotics: Past and present](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2802385/) (Ramachandraiah et al., 2009) [1:50:15]

**How methylene blue can prevent side effects of chemotherapy**: [Methylene blue in the treatment and prevention of ifosfamide-induced encephalopathy: report of 12 cases and a review of the literature](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2363270/) (Pelgrims et al., 2000) [1:52:45]

**Company testing methylene blue as an anti-tau agent**: [TauRx](https://taurx.com/) [1:55:15]

**TauRx studies looking at methylene blue as an anti-tau agent**: [1:55:30]

- [Tau aggregation inhibitor therapy: an exploratory phase 2 study in mild or moderate Alzheimer’s disease.](https://content.iospress.com/download/journal-of-alzheimers-disease/jad142874?id=journal-of-alzheimers-disease%2Fjad142874) (Wischik et al., 2015)
- [Efficacy and safety of tau-aggregation inhibitor therapy in patients with mild or moderate Alzheimer’s disease: a randomised, controlled, double-blind, parallel-arm, phase 3 trial.](https://taurx.com/uploads/Accepted%20Gauthier%20Nov2016%20FINAL.pdf) (Gauthier et al., 2016)
- [Potential of Low Dose Leuco-Methylthioninium Bis(Hydromethanesulphonate) (LMTM) Monotherapy for Treatment of Mild Alzheimer’s Disease: Cohort Analysis as Modified Primary Outcome in a Phase III Clinical Trial](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5734125/) (Wilcock et al., 2017)

**Meta analysis of Cholinesterase Inhibitors and Memantine**: [Association of Concomitant Use of Cholinesterase Inhibitors or Memantine With Cognitive Decline in Alzheimer Clinical Trials: A Meta-analysis.](https://www.ncbi.nlm.nih.gov/pubmed/30646339) (Kennedy et al., 2018) [2:02:30]

**Francisco’s paper where you can see the effect of methylene blue and also the effect of near infrared light on mitochondria**: [Protection against neurodegeneration with low-dose methylene blue and near-infrared light.](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4428125/) (Gonzalez-Lima et al., 2015) [2:06:45]

**Studies of methylene blue for malaria**: [Efficacy and safety of methylene blue in the treatment of malaria: a systematic review](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5979000/) (Lu et al., 2018) [2:12:45]

**Peter’s interview Richard Isaacson regarding AD prevention**: [Richard Isaacson, M.D.: Alzheimer’s prevention (EP.18)](https://peterattiamd.com/richardisaacson/) | Peter Attia (peterattiamd.com) [2:13:30]

**Studies with intranasal insulin administration showing transient improvement in AD symptoms**: [Intranasal insulin in Alzheimer’s disease: Food for thought](https://www.ncbi.nlm.nih.gov/pubmed/29180222) (Chapman et al., 2017) [2:15:00]

**Bulletproof coffee**: [How to Make Bulletproof Coffee … And Make Your Morning Bulletproof](https://blog.bulletproof.com/how-to-make-your-coffee-bulletproof-and-your-morning-too/) | Bulletproof Staff ([bulletproof.com](https://www.bulletproof.com/)) [2:18:15]

**Paper describing a device that can transcranially do imaging with near infrared spectroscopy to measure the concentration of cytochrome oxidase in vivo in the human brain**: [Up-regulation of cerebral cytochrome-c-oxidase and hemodynamics by transcranial infrared laser stimulation: A broadband near-infrared spectroscopy study.](https://www.ncbi.nlm.nih.gov/pubmed/28178891) (Wang et al., 2017) [2:23:45]

**Methylene blue can rescue the majority of the brain damage in animal models**: [Therapeutic benefits of methylene blue on cognitive impairment during chronic cerebral hypoperfusion.](https://www.ncbi.nlm.nih.gov/pubmed/?term=francisco+gonzalez+lima+carotid) (Auchter et al., 2014) [2:26:45]

**First to show the effects of methylene blue in the human brain using fMRI**: [Multimodal Randomized Functional MR Imaging of the Effects of Methylene Blue in the Human Brain.](https://www.ncbi.nlm.nih.gov/pubmed/27351678) (Rodriguez et al, 2016) [2:28:45]

§

## People Mentioned

- [Dr. Joan King](https://csu-cvmbs.colostate.edu/academics/bms/Pages/celebrating-joan-king-tobet.aspx) (had early influence on Francisco, joined her lab at Tulane) [8:45]
- [Alois Alzheimer](https://en.wikipedia.org/wiki/Alois_Alzheimer) (famously studied a patient with early-onset dementia) [24:45]
- [Oskar Fischer](https://en.wikipedia.org/wiki/Oskar_Fischer) (studied senile dementia in elderly adults in early 1900s) [26:30]
- [Emil Kraepelin](https://en.wikipedia.org/wiki/Emil_Kraepelin) (colleague of Alois Alzheimer and furthered the amyloid beta hypothesis) [27:00]
- [James Papez](https://en.wikipedia.org/wiki/James_Papez) (1930s neuroanatomist, [Papez circuit](https://en.wikipedia.org/wiki/Papez_circuit)) [45:15]
- [Jack de la Torre](https://www.omicsonline.org/editor-profile/Jack_de_la_Torre/) (vascular hypothesis) [1:25:15, 1:34:30, 2:25:15]
- [Paul Ehrlich](https://en.wikipedia.org/wiki/Paul_Ehrlich) (methylene blue, magic bullet) [1:40:00, 1:48:30]
- [Santiago Ramón y Cajal](https://en.wikipedia.org/wiki/Santiago_Ram%C3%B3n_y_Cajal) (methylene blue, neuroscientist and one of Francisco’s idols) [1:42:45]
- [Richard Isaacson](https://weillcornell.org/risaacson) (previous [guest on The Drive](https://peterattiamd.com/richardisaacson/), “but as one of my friends who’s a neurologist would say anybody with a brain is at risk”) [2:13:30]
- [Hanli Liu](https://mentis.uta.edu/explore/profile/hanli-liu) (helping Francisco develop  devices to monitor the physiological changes funded by the NIH Brain Initiative program) [2:24:30]
- [Andreana P Haley](https://liberalarts.utexas.edu/psychology/faculty/aph355) (working with Francisco on transcranial infrared lights) [2:24:45]

§

![](https://peterattiamd.com/wp-content/uploads/2019/01/Screen-Shot-2019-01-26-at-10.44.22-PM-500x474.png)

##### Francisco Gonzalez-Lima, Ph.D.

Francisco Gonzalez-Lima holds the George I. Sanchez Centennial Professorship at The University of Texas at Austin, where he is a professor in the Departments of Psychology, Pharmacology and Toxicology, and Psychiatry, and the Institute for Neuroscience.

Gonzalez-Lima’s teaching experience includes undergraduate, medical, graduate and postdoctoral students, and he currently teaches the core graduate course in Functional Neuroanatomy. Gonzalez-Lima has been the research adviser of 22 Ph.D. students at UT Austin, and his trainees are world leaders in brain research on the relationship between brain energy metabolism, memory, and neurobehavioral disorders.

Gonzalez-Lima graduated with honors from Tulane University in New Orleans with B.S. (biology) and B.A. (psychology) degrees, and he earned his Ph.D. (anatomy and neurobiology) from the University of Puerto Rico School of Medicine, which honored him with a Distinguished Alumnus Award. He completed postdoctoral training (behavioral neuroscience) at the Technical University of Darmstadt, Germany, as an Alexander von Humboldt research fellow.

Gonzalez-Lima has been a visiting neuroscientist in Germany, England, Canada, and Spain, and he has delivered more than 120 invited lectures about his brain research around the world. His research has been funded for more than 30 years with federal and private funds, and he has contributed to more than 350 scientific publications in peer-reviewed journals, conference proceedings, chapters, and books.

Current research in the Gonzalez-Lima laboratory focuses on the beneficial neurocognitive and emotional effects of noninvasive human brain stimulation in healthy, aging and mentally ill populations. This research primarily uses transcranial infrared laser stimulation and multimodal imaging (EEG, fNIRS, and fMRI) in collaboration with colleagues at UT Austin, The University of Texas at Arlington and University of Texas Southwestern Medical Center. Gonzalez-Lima supervises and trains students and residents to contribute to these ongoing brain research projects. [[utexas.edu](https://dellmed.utexas.edu/directory/francisco-gonzalez-lima)]