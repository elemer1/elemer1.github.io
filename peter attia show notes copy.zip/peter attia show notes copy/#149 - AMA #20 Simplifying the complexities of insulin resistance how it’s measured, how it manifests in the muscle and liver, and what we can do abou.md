# #149 – AMA #20: Simplifying the complexities of insulin resistance: how it’s measured, how it manifests in the muscle and liver, and what we can do about it

**Source:** [https://peterattiamd.com/ama20/](https://peterattiamd.com/ama20/)

---

In this “Ask Me Anything” (AMA) episode, Peter and Bob discuss all things related to insulin resistance by revisiting the important points made in the fascinating, yet quite technical, episode of [The Drive with Gerald Shulman](https://peterattiamd.com/geraldshulman/). They devote the entire discussion to understanding the condition known as insulin resistance, how it’s measured, how it manifests in the muscle and liver, and ultimately, what we can do about it.

If you’re not a subscriber and listening on a podcast player, you’ll only be able to hear a preview of the AMA. If you’re a subscriber, you can now listen to this full episode on your [private RSS feed](https://peterattiamd.com/members/private-podcast-feed/) or on our website at the [AMA #20 show notes page](https://peterattiamd.com/ama20/). If you are not a subscriber, you can learn more about the subscriber benefits [here](https://peterattiamd.com/subscribe/).

## We discuss:

- Explaining the format of this AMA: Extracting insights from Gerald Shulman’s masterclass on insulin resistance (2:00);
- The basics of insulin, defining insulin resistance (IR), and gold-standard methods of quantifying IR in the muscle (7:15);
- Practical ways to test for insulin resistance in a normal clinical setting (15:45);
- How insulin resistance manifests in the muscle (23:00);
- The biochemical block in glycogen synthesis—drivers and mechanisms resulting in insulin resistance in the muscle (30:45);
- The disparity in fat oxidation between insulin-sensitive and insulin-resistant individuals (44:45);
- The fate of the ingested carbohydrate in someone who is insulin resistant (51:00);
- The prevalence and clinical phenotype of insulin resistance (1:00:15);
- The role of exercise in mitigating and reversing insulin resistance (1:05:00);
- How insulin resistance manifests in the liver (1:09:15);
- Biggest takeaways: what we can do to mitigate and prevent insulin resistance (1:20:45); and
- More.

§

The Peter Attia Drive

Simplifying the complexities of insulin resistance: how it's measured and what we can do about it

§

## Show Notes

## Explaining the format of this AMA: Extracting insights from Gerald Shulman’s masterclass on insulin resistance [2:00]

Peter recently did a podcast with Gerald Shulman: [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/)

- Listening to that discussion was like “drinking through a fire hose” with so much info, so many mechanisms, etc.
- Today’s AMA will be designated to going through the important points of that podcast in a slower way to unlock the takeaways
- Prep for this AMA largely came from Shulman’s [Banting Memorial Lecture](https://www.youtube.com/watch?v=TnvmEUUtoZw)

**Questions to answer today**:

*How does insulin work under normal circumstances?*

*What does insulin resistance really mean?*

*How do we even measure it?*

*How is insulin resistance manifested in muscle?*

*How is it manifested in the liver?*

*How are those the same or different, and what are the consequences of this?*

*What should you do about this?*

> “Once you understand the consequences of this, you’ll appreciate how central this is to your health.” —Peter Attia

## The basics of insulin, defining insulin resistance (IR), and gold-standard methods of quantifying IR in the muscle [7:15]

**The basics of insulin**

- Insulin is secreted as what’s called a pro-peptide
- The pancreas secretes something that is inactive and it gets split into insulin and C-peptide (insulin is the active thing)
- Insulin as a very anabolic (building/growing) hormone, and does the following:
  - Drives glucose into muscles where it can be turned into glycogen
  - Plays a role in glycogen synthesis in the liver
  - Increases fatty acid uptake into fat cells
- In short: **Insulin makes fat cells more fat, it makes muscle cells more glycogen rich, and it makes the liver more glycogen rich**.
- It’s a *pro-building* hormone

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-7-ama20-1024x472.png)

**Figure 1. Effects of Insulin on Glucose & Lipid metabolism (left,** [**2019**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6943204/)**); Critical actions & pathways controlled by insulin (right,** [**2018**](https://www.intechopen.com/books/blood-glucose-levels/role-of-pi3k-akt-pathway-in-insulin-mediated-glucose-uptake)**).**

**Defining insulin resistance (IR) and how it’s measured**

Definition:

- Insulin resistance is probably best defined as an impaired ability for insulin to do some of the things listed above
- E.g., if insulin’s job is to take glucose into a muscle so that a muscle can make glycogen, when that gets impaired, that is insulin resistance in the muscle
- However, fat cells and liver cells have a slightly different explanation/manifestation of insulin resistance

**How insulin is measured (***Focusing on the* ***muscle*** *for this discussion*)

There are a couple of gold standard ways to measure and quantify insulin resistance that are done in *clinical trials* (i.e., not something done at the doctor’s office as part of any regular checkup)

1-**Hyperinsulinemic-euglycemic clamp technique**

- Using to separate IV lines…
- The plasma insulin concentration is acutely raised and maintained at 100 μU/ml by a continuous infusion of insulin.
- Meanwhile, the plasma glucose concentration is held constant at basal levels by a variable glucose infusion.
- When the steady-state (i.e., euglycemic/normal) is achieved, the glucose infusion rate equals glucose uptake by all the tissues in the body (almost exclusively into their muscles)
- This is a measure of tissue insulin sensitivity, and *the more insulin sensitive you are, the higher that glucose disposal rate will be*

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-10-ama20-1024x622.png)

**Figure 2. [**[**UpToDate**](https://www.uptodate.com/contents/insulin-resistance-definition-and-clinical-spectrum?search=insulin%20resistance%20diagnosis&source=search_result&selectedTitle=2~150&usage_type=default&display_rank=2#H3260076063)**]**

- The figure above is actually showing glucose disposal, not glucose
- And that’s why the more insulin-sensitive person at a fixed level of insulin requires more and more glucose to maintain glucose homeostasis

2-**Insulin suppression test**

- Two IV lines
- In one of them you’re infusing epinephrine, propranolol (which suppress your endogenous insulin release) as well as insulin
- in the other IV, you’re infusing glucose
- This is done until you have a steady state level of glucose and insulin
- The way this test works is kind of the opposite of the euglycemic clamp, which is you **fix the level of glucose** and you’re trying to see **how much insulin is required to do that**
- Because the steady-state insulin level is the same in all subjects, the height of the steady-state plasma glucose level provides a direct estimate of insulin resistance.
- NOTE: When Peter did this test, he got very, very hypoglycemic and it got a little dangerous

## Practical ways to test for insulin resistance in a normal clinical setting [15:45]

*Popular ways*:

- Fasting insulin and fasting glucose are generally talked about as ways that people pay attention to insulin resistance
- But the reality of it is those things don’t tell us much
- And even something called the [HOMA-IR](https://care.diabetesjournals.org/content/25/7/1135#:~:text=In%20particular%2C%20an%20insulin%20resistance,insulin%20sensitivity%20(insulin%20resistance).) (homeostatic model assessment of insulin resistance) which uses a formula (fasting insulin in mIU/L x Fasting glucose in mg/dL / 405) is not much better than looking at fasting insulin

*The best way*: **Oral glucose tolerance test**

- Patients show up fasting and you draw blood to measure fasting glucose and insulin
- They then ingest 75 grams of glucose
- Then every 30 minutes for 2 hours you draw blood, checking glucose and insulin
- From that you generate two curves:
- Their glycemic response (how does their glucose change over the next two hours)
- Their insulin response over those 2 hours
- You’re trying to measure how much glucose gets taken up into the muscles, and that’s being measured by the glucose level over time, and then how much insulin was required to do it
- The earliest indication of insulin resistance is an elevation of those “postprandial” insulin levels
- Peter notes that he sees patients all the time that have **normal glucose levels but their insulin levels are sky high**

*The typical progression from normal to severely insulin resistant*:

 >Glucose stays relatively low after the ingestion and so does insulin (normal)

 >> insulin goes up while glucose stays down (first thing that usually goes wrong)

 >>>Glucose goes up while insulin stays up

 >>>>Fasting glucose going up and then fasting insulin going up (once fasting glucose gets high enough you’re very close to diabetes)

⇒ Check out this [AMA episode](https://peterattiamd.com/ama15/) with real case studies using OGTT

![](https://peterattiamd.com/wp-content/uploads/2021/02/example-OGTT-ama20-1024x752.png)

**Figure 3. Example OGTT results.** [[source](https://peterattiamd.com/ama15/)]

*Other ways of diagnosing IR*: Using the **criteria for metabolic syndrome**

The five criteria of metabolic syndrome:

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-12-ama20-1024x649.png)

**Figure 4. The five criteria of metabolic syndrome per the various authorities.** [[source](https://emedicine.medscape.com/article/122501-guidelines)]

- One should aspire to have **none** of them present
- Almost [90% of Americans](https://www.liebertpub.com/doi/10.1089/met.2018.0105) have at least one of these five factors present
- And if you have **three or more** of them present you are technically defined as having metabolic syndrome and your risk for all metabolic diseases, cancer, cardiovascular disease, Alzheimer’s disease, type 2 diabetes, etc. just goes through the roof

**How might Peter adjust these criteria?**

- Peter says this is really helpful on the *population basis* because it’s *directionally helpful*
- But the devil’s in the details on the individual level
  - Amount of [visceral fat is more important than subcutaneous fat](https://peterattiamd.com/ama17/)
  - Peter believes triglycerides should be always below 100 and always less than twice the HDL cholesterol
  - Peter is very aggressive with blood pressure — Anything over 120 over 80 is reason to start to pay attention
  - Peter is not particularly alarmed with fasting glucose above 100, depending on how it responds
    - For example, a fasting glucose of 105 is not terribly alarming if the average blood glucose is below 100 (which is not uncommon in people where they have a bit of a “dawn effect”)

⇒ See Gerald Reaven’s [1988 Banting Lecture](https://diabetes.diabetesjournals.org/content/37/12/1595)

**Insulin resistance is the thing that sits at the heart of metabolic syndrome**:

> “If you have an interest in being healthy you can’t be insulin resistant. If you are insulin resistant, you’re not going to be healthy. . .But if you’re in the business of wanting to live the healthiest life you can live, which means longer and better, you’ve got to be insulin sensitive, full stop.” —Peter Attia

## How insulin resistance manifests in the muscle [23:00]

Normal metabolism:

- You eat some carbs and plasma glucose increases
- The increase in plasma glucose stimulates insulin secretion
- And insulin secretion:
  - stimulates glucose uptake in muscle
  - Suppresses GNG by the liver
- In a healthy individual, 80-90% of consumed glucose is stored as glycogen (in muscle and liver)
- The **muscle is the predominant place where we dispose of glucose**
  - When Peter says “glucose disposal” he’s referring to muscle taking in glucose

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-15-ama20-1024x573.png)

**Figure 5.**

*What goes wrong from here?*

- It’s important to understand this is a continuum — on one end of the spectrum is just becoming insulin resistant and at the other end of the spectrum is full-blown type 2 diabetes
- The first thing that really goes wrong is the muscles take in less glucose, and by extension, the plasma insulin level has to rise to force that in
- The first sign of this is normal levels of glucose going in but at a higher level of insulin (and that’s easy to miss)
- The first thing that usually shows up is higher levels of plasma glucose — and that’s because the liver is becoming resistant to insulin
- The liver being resistant to insulin means it’s not slowing down glucose production, and therefore in the presence of glucose it’s still making glucose (very problematic)
- At some point there’s not even enough insulin that the pancreas can make to overcome the resistance resulting in a person needing medication to start to overcome this problem

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-16-ama20-1024x577.png)

**Figure 6.**

**What is it about the muscle that fails in this process of glucose disposal?**

Three fates of glucose within the muscle

1. Oxidative
2. Glycolytic
3. Glycogen

1-The oxidative fate of glucose says glucose comes into a muscle and immediately gets converted into ATP through the very efficient pathway

- Glucose gets converted to pyruvate, pyruvate gets converted to acetyl CoA, and that going into the mitochondria where ATP is generated under something called [oxidative phosphorylation](https://en.wikipedia.org/wiki/Oxidative_phosphorylation) (Krebs cycle — this is the most efficient way to generate ATP out of glucose)

2-The second potential fate of glucose is to undergo [glycolysis](https://en.wikipedia.org/wiki/Glycolysis)

- Take the glucose down to pyruvate
- But instead of taking the pyruvate towards the mitochondria and going through the Krebs cycle you turn it into lactate, which yields much less ATP

3-The third fate of glucose in the muscle is it can be stored as [glycogen](https://en.wikipedia.org/wiki/Glycogen)

- Glycogen is literally a lattice of glucose.
- Glucose is a single six carbon ring, but you can join these things in rows, and rows, and rows, and rows, and sheets, and sheets, and sheets covalently and that becomes a matrix of glucose, which is a very efficient way to store it

*When things go wrong…*

- When things go wrong, we know that *at least one of those three are not working*
- The question becomes, ***which one?***

Gerald Shulman did a [study](https://www.nejm.org/doi/full/10.1056/NEJM199001253220403) using a technique called NMR to try to answer this question:

- NMR, nuclear magnetic resonance, looks at labeled carbon atoms and using the magnetic fields that can be applied to them, it gets a sense of where these carbons go
- When they compared glucose uptake into glycogen synthesis using people who had type 2 diabetes versus people who were insulin sensitive, they found that those with type 2 diabetes made **50% less glycogen out of the same amount of glucose**
- Interestingly, there was virtually **no difference between their oxidative phosphorylation**
- *Said another way*, they basically had no difference in how much ATP they made out of that glucose, they had no difference between how much energy they made out of that glucose. They were both able to use the glucose and extract energy, but the lion’s share of the glucose that was disposed was disposed in the form of glycogen and the difference was profound.
- To put it in perspective…
  - The normal subjects disposed of about 180 units of glucose per kilogram of body weight compared to the diabetic subjects who were less than half that at 78
  - Given that there was no difference on the oxidative side, **the entire difference was effectively accounted for by glycogen synthesis**

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-21a-ama20-1024x574.png)

**Figure 7.** [[source]](https://www.nejm.org/doi/full/10.1056/NEJM199001253220403)

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-21b-ama20-1024x591.png)

**Figure 8.** [[source]](https://www.nejm.org/doi/full/10.1056/NEJM199001253220403)

## The biochemical block in glycogen synthesis—drivers and mechanisms resulting in insulin resistance in the muscle [30:45]

Gerald’s work established where the macro defect was — It’s that **an insulin resistant person can’t make glycogen effectively**, so something is blocking that process

Since there are a lot of things that drive glycogen synthesis, the next question became: **Where is that problem occurring?**

*Possible reasons for lack of glycogen synthesis*:

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-23-ama20-1024x572.png)

**Figure 9. Potential Rate-Controlling Steps in Muscle Glucose Glycogen Synthesis.**

-Plasma glucose has to enter the cell through a transporter called the [GLUT4 transporter](https://en.wikipedia.org/wiki/GLUT4) — so now you have intracellular glucose

-Many steps in a pathway are simplified in the figure to show that there are a few rate limiting pathways:

  1 – glucose being converted into glucose 6-phosphate (meaning = adding a phosphate group on the number six glucose via an enzyme called hexokinase)

  2 – Then you have a number of steps that take glucose 6-phosphate to UDP glucose

  3 – Then ultimately that gets wound into glycogen using another enzyme called glycogen synthase

- But if you’re looking at all of this and all you know is that plasma glucose is going up because of the insulin resistance and glycogen is going down, you don’t really know where it is
- It’s like looking at the starting point and the destination and realizing there’s a delay but not knowing where the traffic is exactly backing up (e.g., the bottleneck)
- But depending on **where** the roadblock is, you will see different scenarios of what goes up and what goes down
- If the defect is at glycogen synthase—the enzyme that makes glycogen—then glycogen would be low but everything upstream of that would be up
- Similarly, if the defect is at hexokinase you would expect glycogen to be low but **also glucose 6-phosphate to be low**, and intracellular glucose to be up
- Conversely, if the defect is at the *GLUT4 transporter*, then **everything inside this cell would be low** and the glucose outside the cell would be high

**What did Gerald’s** [**experiment**](https://www.nejm.org/doi/full/10.1056/nejm199907223410404) **find?**

- It was **glucose transport** that was the issue
- The NMR spectroscopy allowed them to look at each of these things in the cell, and they found intracellular glucose was low, glucose 6-phosphate was low, UDP low, glycogen low
- So, the issue was [GLUT4](https://en.wikipedia.org/wiki/GLUT4), meaning the “*glucose isn’t even getting in the door*”

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-29-ama20-1024x620.png)

**Figure 10.**

**What’s driving the glut4 block and what’s the mechanism of it?**

- One of the things that they speculated on was an association that they noticed — when looking at intramyocellular lipid (IMCL) content they saw that it correlates with muscle insulin resistance
- They noticed that the more lipid that is inside of a muscle cell, the more insulin resistant an individual was

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-31-ama20-1024x576.png)

**Figure 11.**

Important distinction: The lipid inside a muscle cell and the lipid outside a muscle cell—

- You can have lipid outside of a muscle cell, extracellular, and that did NOT seem to correlate
- But the amount of lipid inside the muscle cell DID correlate

*Could it have something to do with this intramyocellular lipid and could that be part of the roadblock?*

**A clever** [**experiment**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC507380/) **looked at this question**:

- They took hyperinsulinemic offspring of diabetic parents, but who were otherwise lean, and they infused a lipid along with [heparin](https://en.wikipedia.org/wiki/Heparin)
- Why heparin? ⇒ it’s a blood thinner, but it also activates an enzyme called lipoprotein lipase and really liberates the circulation of free fatty acid

\*\*\*

**Pausing to define triglyceride (TAG) and a free fatty acid (DAG)**

- A free fatty acid (FFA) is just a long hydrocarbon chain of carbons and hydrogens, it’s the densest manner in which we store energy
- We package FFAs in an even denser structure called triglycerides
- The term triglyceride, TG, and triacylglyceride, TAG, are used interchangeably (unfortunately)
- A TG or TAG is three of those hydrocarbon free fatty acids bound to one short molecule called glycerol that has three carbons
- A diacylglyceride is when that glycerol only has two carbons on it and one of them does not
- Typically a diacylglyceride has a hydroxyl group on that naked carbon that does not have a free fatty acid
- And a hydroxyl group is just an O, an oxygen, and an H, a hydrogen
- “*In a moment this is going to become a very important part of the story, because* ***that little hydroxyl group behaves badly*****.**”

\*\*\*

**Back to the** [**study**](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC507380/)**…**

- When you infuse lipid and heparin, heparin activates lipoprotein lipase, an enzyme that readily dissociates the glycerol and the free fatty acids
- It’s basically like giving someone **a huge infusion of free fatty acids which enter the muscle cells** very easily
- Gerry was able to demonstrate within a couple of hours of giving people lipid infusion with heparin, they were able to *induce profound insulin resistance*
- This further validated their hypothesis that something about intramuscular fat was part of the problem

*So if intramuscular fat was the problem, then* ***where is the defect*** *specifically?*

- The next thing to look at then is what is the path from insulin hitting an insulin receptor to glucose coming into a cell
- insulin binds to the insulin receptor that sits on the surface of a cell
- This receptor autophosphorylates (phosphorylates itself)
- Phosphorylation in biology means putting a phosphate on… which is usually activating something
- In this case, the presence of insulin binding to the insulin receptor leads the insulin receptor to become activated
- It then becomes a key substrate for something called insulin receptor substrate 1, or IRS1, which also gets phosphorylated
- That then activates something called [phosphoinositide 3-kinase (PI3K)](https://en.wikipedia.org/wiki/Phosphoinositide_3-kinase)
  - (Check out the [podcast with Lew Cantley](https://peterattiamd.com/lewcantley/) for more on PI3K)
- PI3K is the required step for the GLUT4 transporter — you can think of it as a tubule sitting in the cell to get launched up to the cell surface where it goes across the cell membrane and allows glucose to passively come across the surface
- Glucose comes in across a gradient, which is always greater outside the cell than inside the cell, it doesn’t need active transport, it just needs an open door.
- **In short**: Insulin binds to an insulin receptor, the insulin receptor leads to an increase in the activity of something called IRS1, which leads to an increase in the activity of something called PI 3-kinase, which puts these GLUT4 transporters on the surface of cells and drives glucose in

**What are the ways in which this can go wrong?**

-We’ve established that *something about fatty acids runs this awry*

-The question: *Is there some metabolite of a fatty acid that is causing trouble either at the site of the insulin receptor? Or maybe further down the road at the level of the GLUT4 transporter?*

- They did an [experiment](https://pubmed.ncbi.nlm.nih.gov/9916137/) to assess PI3K activity in the muscle of healthy volunteers before and after a lipid infusion

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-39-ama20-1024x575.png)

**Figure 12.** [[source](https://pubmed.ncbi.nlm.nih.gov/9916137/)]

- Under normal conditions, PI3K activity is low
- When you infuse insulin, PI3K goes up, so that becomes your control
- In other words, you know that when you give insulin, PI3K should go up
- However, when they gave *lipid plus insulin,* it came down
- So that tells you that **whatever is going on is happening at, or before, the PI3K step**

*What could be going on here?*

- The hypothesis that they launched was that it might NOT be a triglyceride, because triglycerides are generally inert
- But it turns out that **diacylglycerides are not so inert —** they have a free hydroxyl group, and that free hydroxyl group which has a couple of unbound electrons on the O might be what’s disrupting things

**The conclusion**

- It’s the fatty acids that come in that lead to an increase in something called **diacylglycerides**
- And these diacylglycerides increase the activity of something called [protein kinase C theta](https://en.wikipedia.org/wiki/PRKCQ) which actually impairs [IRS1](https://en.wikipedia.org/wiki/IRS1)
- Impairment of IRS1 leads to the reduction in PI3K, and **therefore the reduction in GLUT4 translocation**

## The disparity in fat oxidation between insulin-sensitive and insulin-resistant individuals [44:45]

The insulin sensitive person

- They can take a lot of fat and run it through their mitochondria
- They have high fat oxidation in their mitochondria (and when necessary they can oxidize glucose in their mitochondria)
- They can also store glucose as glycogen in the muscle

Contrast that with the person with type 2 diabetes

- They now have double defect—
  - They can’t store glucose in the form of glycogen
  - And their fat oxidation is dramatically reduced
- So they are now relying solely on glucose for oxidation
- They have less fat oxidation, it’s probably driving up their DAGs, which is further exacerbating their glucose transport problem

[**Athlete’s paradox**](https://pubmed.ncbi.nlm.nih.gov/30174227/)

- If you compare the intramyocellular lipid in…
  - healthy *sedentary* individuals
  - Elite endurance athletes, and
  - People with type 2 diabetes
- The type 2 diabetes see this increase in intramyocellular lipid
- In the normal healthy sedentary person you see a relatively low level, but there is some there in storage in muscle
- Then in these elite athletes you see type 2 diabetic levels (or even higher levels) of intramyocellular lipid
  - But these athletes, their mitochondria are in top form, they’re exercising for hours a day
  - And the idea is that their free fatty acids are increasing while they’re exercising so there’s a lot of it there,
  - But that’s just a screenshot of the muscle, and doesn’t take into account flux — the athletes can efficiently use FFA during exercise due to the enhanced state of their mitochondria
- But in the context of a sedentary person, Shulman once stated,  “*Intramyocellular lipid is the best predictor for muscle insulin resistance in virtually every sedentary population that we have studied to date, from children to the elderly*.”

**Flux**

- The underlying assumption here is a sedentary individual has minimal flux
- But the athlete has enormous flux — There are tons of triglycerides flowing into that muscle and there’s equally tons of it being oxidized in the mitochondria

## The fate of the ingested carbohydrate in someone who is insulin resistant [51:00]

**What have we learned from the decade of work in Gerry Shulman’s lab?**

- We’ve learned that insulin resistance, which can present with postprandial hyperinsulinemia, is a defect in glycogen synthesis
- That defect has to do with an inability to bring glucose into the muscle cells
- And more specifically, that defect seems to be mediated by intramuscular fat—specifically by the diacylglycerides
- Diacylglycerides effectively work through something called protein kinase C theta, which inhibits the ability of PI3K

So, if all of this is happening, ***what is the fate of the ingested carbohydrate?***

- If that glucose for the insulin-resistant person comes in and can’t go into the muscle to be turned into glycogen, it has to go someplace else. *So where is that someplace else?*

To answer this, they did a very clever [experiment](https://www.pnas.org/content/104/31/12587):

- 300 young healthy lean non-smoking **sedentary** individuals
- They wanted people who have no comorbidities but were at the earliest outset of metabolically ill health
- They performed an oral glucose tolerance test on these subjects
- After ingesting glucose, they would sample their glucose levels and divide them into quartiles and from most insulin-sensitive to most insulin-resistant
- They first discarded the two groups in the middle, and looked at the bottom quartile (most insulin resistant) and the top quartile (most insulin sensitive)

They then asked the question: *How do they differ when you give them glucose?*

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-44-ama20-1024x574.png)

**Figure 13. Meal tolerance test curve.**

- First they looked in the periphery, what actually happens
- Both groups basically had about the same glucose levels following their glucose meals
- The plasma glucose concentrations are virtually indistinguishable between the two groups before and after they drink their two high carbohydrate milkshakes.
- But the relatively normal glucose tolerance in the insulin-resistant subjects was maintained at the expense of severe hyperinsulinemia as shown in the right panel where plasma insulin concentrations are more than twofold higher during both meals.
- They then ingest a second glucose shake
- They have a second spike and then they all kind of come down again
- By the end of the day they’re all at the same spot, and there’s really no statistical difference between their glucose curves.
- Conversely, when you look at their insulin curves there’s about a **2X difference**
- What that tells us is **the insulin-resistant group needed twice the insulin** to make that happen

*What is actually happening to that ingested carbohydrate?*

- *Is it going into the same place?* ⇒ We think the answer is “no” because of what we know about insulin resistance

They then looked at the liver: *What happens to liver glycogen synthesis?*

- Muscle glycogen synthesis showed that they had a 60% reduction in glycogen synthesis within the muscle if they were in that lower quartile versus the insulin sensitive group
- What’s most interesting to Peter is that there’s *no difference in liver glycogen synthesis [Figure 14]*

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-46a-ama20-1024x574.png)

**Figure 14.**

What’s **most telling** is what happened in terms of liver fat accumulation and de novo lipogenesis (the novel creation of fat from carbohydrate) [Figure 16]

- There was more than a twofold difference in both

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-46b-ama20-1024x576.png)

**Figure 16.**

*\*Therein lies a very important point*: A question that is long at the heart of most people in terms of interest in nutrition and metabolic disease is: **Can carbohydrates be turned into fat, and if so, how much of a contribution is that to our overall fatness?**

- And the answer is that it really depends on the context and the metabolic condition of the individual
- In an insulin-sensitive individual, it turns out that the creation of liver fat is really not that much (especially when you’re eating more glucose than fructose)
- The more insulin resistant you are, and the more fructose you’re eating, the more de novo lipogenesis can become a huge part of the problem

**Fuel partitioning:**

Fuel partitioning is basically asking, *Where can you put this fuel?*

- If you have a lot of muscle, you’ve got a reservoir where you can put that glucose in a healthy person
- The glucose goes into the muscle more readily, and it can be reconstituted into glycogen more readily
- In the type 2 diabetics, that process happens to a much lower extent—it is not shut off completely, but their muscle sensitivity is lower

*The liver vs the muscle*:

- Shulman is basically showing that the liver isn’t as resistant as the muscle, and it can more readily take up some of this glucose
- And the reason we’re not seeing an impairment in liver glycogen synthesis is that insulin is not required to get glucose into hepatocytes
- The GLUT4 transporter is what brings glucose into muscles, it requires insulin
- The liver uses something called the GLUT2 transporter, and it is purely a gradient based transporter, it does not require insulin
- So that’s why I think we’re seeing this difference, is glucose makes its way into the liver, and you can make glycogen, but as you said, the partitioning of that fuel is different

## The prevalence and clinical phenotype of insulin resistance [1:00:15]

[**The role of skeletal muscle insulin resistance in the pathogenesis of the metabolic syndrome**](https://www.pnas.org/content/104/31/12587)

- In this study, they had an 80% higher triglyceride level if they were insulin resistant and 20% lower HDL cholesterol
- We see both of those metrics as being elevated and depressed respectively as part of a criteria for metabolic syndrome
- Triglycerides are exported from the liver in VLDL
- all of this kind of ties into what we see in metabolic syndrome—Elevated glucose, fat in the liver, low HDL cholesterol, high triglyceride, more fat in the muscle, and therefore more insulin resistant in the muscle
- A “vicious cycle”

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-46c-ama20-1024x577.png)

**Figure 17.**

**Prevalence of met-syn and NAFLD**

- About 25% of people globally have [non-alcoholic fatty liver disease](https://www.google.com/search?q=non-alcoholic+fatty+liver+disease+wiki&oq=non-alcoholic+fatty+liver+disease+wiki&aqs=chrome..69i57j0i390l5j69i60.909j0j7&sourceid=chrome&ie=UTF-8) (NAFLD), and over 80 million Americans have NAFLD ([2015](https://aasldpubs.onlinelibrary.wiley.com/doi/full/10.1002/hep.28431))
- Another study said 10-30% of Amercians have NAFLD, with similar rates reported from Europe and Asia ([2011](https://onlinelibrary.wiley.com/doi/full/10.1111/j.1365-2036.2011.04724.x); [2013](https://www.researchgate.net/profile/Vincent_Wong2/publication/235786198_NAFLD_in_Asia_-As_common_and_important_as_in_the_West/links/560c720408aea68653d36c1a/NAFLD-in-Asia-As-common-and-important-as-in-the-West.pdf))
- Over 100 million people have either pre-diabetes and diabetes ([2017](https://www.cdc.gov/media/releases/2017/p0718-diabetes-report.html))
- There’s also a nontrivial amount of NAFLD in children as well

*Huge genetic differences*:

- Hispanics are disproportionately affected (a Hispanic male is obese there’s a 50% chance he has NAFLD)
- African American disproportionally not affected

**NAFLD and NASH and liver transplants**

- NAFLD is fat that accumulates in the liver
- Non-alcoholic steatohepatitis (NASH) is when fat has accumulated such that the liver now becomes inflamed (reversible) until it becomes cirrhotic (irreversible)
- With growing epidemic of obesity and MetSyn, NAFLD has become the most common cause of chronic liver disease worldwide and will become one of the leading causes of cirrhosis ([2018](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6051295/))
- Cirrhotic means you need a liver transplant
- Within the next five years, NAFLD and NASH will be the leading indication for liver transplant in the United States — In 2020, the number of individuals with NAFLD cirrhosis is predicted to exceed that of those with hepatitis B- and C-related cirrhosis, and NAFLD cirrhosis will become the leading indication for liver transplantation ([2018](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6051295/))

⇒ See episode of [The Drive with Rob Lustig](https://peterattiamd.com/roblustig/) podcast where they discuss the impact of fructose

## The role of exercise in mitigating and reversing insulin resistance [1:05:00]

**An illuminating study was published in 1996 in the NEJM**: [Increased Glucose Transport–Phosphorylation and Muscle Glycogen Synthesis after Exercise Training in Insulin-Resistant Subjects](https://www.nejm.org/doi/full/10.1056/NEJM199610313351804)

- They looked at the impact of a single bout of exercise on insulin stimulated muscle glycogen synthesis
- They found that just one 45-minute bout of aerobic exercise—three 15-minute sets at ~65% of your maximal aerobic capacity—restored the concentration of glucose-6-phosphate and the rate of glycogen synthesis in the muscle of insulin resistant participants to that of the baseline or pre-exercise level of the insulin sensitive participants
- In other words, **exercise is boosting insulin sensitivity and glucose disposal**
- This is crucial because a big issue with insulin resistant/diabetic people is that it seems like they can’t put the glucose into the muscle and synthesize it into glycogen
- But this study showed that one bout of exercise made that possible

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-52-ama20-1024x575.png)

**Figure 18.**

When you compare the the insulin-sensitive to the insulin-resistant person…

- Their pre-exercise and post-exercise levels of glycogen synthesis are dramatically different (i.e., the insulin sensitive people also had a significant increase following exercise)
- However, the key takeaway is that you have an insulin resistant person exercise and make their muscles look like an insulin sensitive person at rest

*Two probable mechanisms by which exercise is boosting insulin sensitivity and glucose disposal*:

1 – The insulin-*dependent* way

2 – The insulin-*independent* way

- The insulin independent way is probably through AMP kinase
- AMP kinase can cause more translocation of GLUT4 transporters independent of PI 3-kinase

*Other things worth noting*:

- Peter has had patients with type 1 diabetes who used long duration, submaximal exercise to reduce their dependence on insulin
- Over time (i.e., chronically) more exercise reduces intramuscular lipid, increases oxidative phosphorylation, and therefore reduces TAG and DAG

**In summary**:

- The importance of exercise in this situation cannot be overstated
- Combine exercise with regulating carbohydrate level to your tolerance, reducing fructose intake, etc. for even better results
- This is great news because we now know metabolic syndrome, NAFLD, NASH, don’t need drugs to cure them

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-53-ama20-1024x575.png)

**Figure 19.** [[source](https://www.pnas.org/content/108/33/13705.long)]

## How insulin resistance manifests in the liver [1:09:15]

**Basics**:

- The liver doesn’t need insulin to bring glucose in
- Glucose can enter passively
- insulin still plays an important role in glycogen synthesis but also in gluconeogenesis
- if you look at the mechanism by which glucose and glycogen are managed in the liver
- you have something called insulin receptor substrate 2 instead of insulin receptor substrate 1, you still have the role of PI 3-kinase, you have something called AKT2, FOXO, a whole bunch of other things

\*The main point — The mechanisms are actually quite similar

- In other words, the diacylglycerides turned out to be a big part of the problem
- The diacylglyceride in the muscle worked by activating something called protein kinase C theta
- But in the liver, it also works via a protein kinase C, but a different one called epsilon
- So, diacylglycerides interfere with protein kinase Cs and that interferes with insulin signaling, and that’s what leads to this dysregulation
- Dysregulation then leads to is an increase in de novo lipogenesis, an increase in the accumulation of intrahepatic fat

*Why does this happen? Why does our body do something that seems so harmful to us?*

- Evolution is a lens in which to view this stuff because the environment we live in is so new — only about 100 years (less than 0.1% of our evolutionary history)
- We are now faced with highly refined crappy foods, and sedentary lifestyles
- During periods of pronounced food deprivation (i.e., fasting) out of necessity when food was not available you had to survive
- To survive meant a number of things, a couple of them being the ability to liberate more fatty acid out of fat cells while reserving more glucose for the brain

*So how does all of this fit in?*

- Starvation is going to lead to:
  - Lower insulin
  - Increase lipolysis at the fat cell
  - More hepatic accumulation of lipid
  - More insulin resistance in the liver, which would decrease hepatic glycogen storage because you don’t have any reason to be storing glucose at this point, you want to be kicking it out
  - You want to save glucose for the brain

**What regulates gluconeogenesis in the liver?**

![](https://peterattiamd.com/wp-content/uploads/2021/02/slide-70-ama20-1024x576.png)

**Figure 20.** [[source](https://pubmed.ncbi.nlm.nih.gov/25662011/)]

- - The fact that our liver can actually make glucose out of different stuff is remarkable: Out of amino acids, out of lactate, out of glycerol

- *But what regulates that whole process?*

- The figure shows the pathways through which lactate, alanine, which is an amino acid, pyruvate, oxaloacetate, glycerol, all of these things get brought into the pathway of gluconeogenesis

**Four mechanisms by which insulin might acutely regulate hepatic GNG**:

1-Transcriptional: through transcriptional regulation of the key gluconeogenic enzymes

- Since changes in genetic expression do not happen fast enough to explain turning GNG off within minutes, there must be another regulatory mechanism with a stronger influence

2-Substrate: alterations in substrate supply to the liver

- Glycerol, a byproduct of lipolysis, interestingly feeds GNG in an unregulated manner, which is related to Gerald’s team discovering that metformin decreases GNG by inhibiting conversion of glycerol to glucose

3-Redox: through modulation of the cytosolic redox state

- it could be effectively electrochemically regulated by the availability of substrates that work through electrode potential, and NADH and NAD, or NADPH, NADP, I mean, these are the most common things that we use
- For example, in the Krebs cycle, so much of it is redox run, where these steps are regulated by electron transfer

4-Allosteric: through changes in hepatic Acetyl-CoA. Acetyl-CoA is a potent allosteric activator of pyruvate carboxylase, which is a key rate-controlling step in GNG

- Related to glycerol and lipolysis, β-oxidation of fatty acids leads to production of acetyl-CoA, which feeds the citric acid cycle for energy production

Shulman’s conclusion is that it is **allosterically regulated:**

*-Regarding the transcriptional argument*: It is very difficult to see how this could be transcriptionally regulated given that genetic expression takes a little bit of time, typically on the order of hours, and the liver has the ability to turn on and off gluconeogenesis within minutes

*-Regarding the substrate argument*: we don’t see that being possible because glycerol, which is the most common substrate, especially in a period of starvation because it’s so freely liberated from lipolysis, is basically unregulated, meaning the more glycerol you pump into this system, the more gluconeogenesis you get out, it never seems to saturate

*-Regarding the redox argument*:

- Peter doesn’t recall exactly why Shulman didn’t believe redox was a predominant driver
- However, he did give insights related to metformin—
  - he thought that was a big part of how metformin might actually interfere with this, because obviously one of the things metformin does is it reduces hepatic glucose output,
  - metformin does reduce the ratio of NADH to NAD, which would slow down the path to gluconeogenesis
  - It not be the *major* player, but it must be *a* player—metformin increases the NADH to NAD plus ratio, and essentially it makes it like energetically impossible to convert the lactate into pyruvate, and that’s also why you would see an increase in levels of lactate
  - Shulman thinks that at a 1,000 times therapeutic concentrations for metformin, it’s a complex I inhibitor
  - But at “therapeutic” concentrations, it inhibits what’s called mitochondrial glycerol-3-phosphate dehydrogenase
  - Upshot of that is that less glycerol is being converted into DHAP, which goes into gluconeogenesis
  - So it lowers gluconeogenesis because you’re lowering the availability more or less of lactate and glycerol, but then there’s also other, I think it’s alanine. There’s other ways to make glucose from the liver, so the metformin is not going to stop you from gluconeogenesis, but it may dial it down
  - Nir Barzilai emailed Peter after the Shulman podcast and basically said “we’re not even sure if that’s the mechanism by which metformin induces longevity”
  - In other words, all of this might be true, but that might have nothing to do with the potential longevity benefit of metformin… it may have nothing to do with the reduction of gluconeogenesis and the reduction of hepatic glucose output.

*-Regarding the allosteric argument*:

- This basically turned out to be the most potent activator of pyruvate carboxylase, which turns out to be the rate controlling step of gluconeogenesis.
- So more acetyl-CoA, which is a byproduct of course of the beta oxidation of fatty acids (and glucose for that matter) leads to oxidation of fatty acids
- And the breakdown of glucose leads to more acetyl-CoA, which drives this.

**Last points:  [1:19:15]**

**-What is insulin doing directly in the liver cell?**

**-What’s happening outside the liver cell in response to insulin?**

**-And how does this all feed into the “starvation” phenotype? (**I.e., What do we think is happening when we’re not eating?)

- At the short-term level, insulin is coming into the cell and it’s leading to glycogen synthesis which reduces glycogen production or hepatic glucose output
- Outside the cell, insulin is impairing lipolysis, impairing a fat cell from releasing triglyceride and breaking it down into free fatty acids and glycerol
- That means you actually will have less glycerol and you’ll have less acetyl-CoA because you have less fatty acid to oxidize, which means you have less pyruvate carboxylase, which means you have less gluconeogenesis

> “*These two things together, less glycogen being synthesized and less gluconeogenesis, both lead to less glucose production*.” —Peter Attia

## Biggest takeaways: what we can do to mitigate and prevent insulin resistance [1:20:45]

First, you want to know that you’re insulin resistant long before it shows up in a traditional way

- You don’t want to wait until your hemoglobin A1C is 6.5 and you’re being diagnosed with T2D
- This means you need to be getting an oral glucose tolerance test

Second big takeaway, exercise really matters a lot

- 45 minutes of submaximal/zone 2 exercise
- Zone 2 means roughly 65% of VO2 max, and about at the limit of where you can still carry on a conversation
- This exercise had an immediate and direct effect on glucose disposal
- Over time, so chronically, that’s going to have an even greater effect

⇒ See [AMA #145](https://peterattiamd.com/ama19/) for more on zone 2 exercise

Thirdly, there is an enormous role for dietary intervention

- Specifically, fructose reduction and glucose reduction until a homeostasis is achieved

Next, liver function tests are key

- When we see the prevalence of NAFLD and NASH, doing a liver function test is helpful

Pharmacologic options

- The mitochondrial uncoupler has potential
- Worth noting that right now the drugs for NAFLD and NASH are some of the most high priorities in the pharma space.
- But most of them seem to come with undesired side effects
- Perhaps this new hepatic mitochondrial uncoupler will not have some of those problems, but historically mitochondrial uncouplers come with a lot of hyperthermic problems

In summary: **Exercise and nutrition are a first line of defense against metabolic syndrome**

§

## Selected Links / Related Material

**Episode of The Drive with Gerald Shulman that set the stage for this AMA**: [#140 – Gerald Shulman, M.D., Ph.D.: A masterclass on insulin resistance—molecular mechanisms and clinical implications](https://peterattiamd.com/geraldshulman/) | Peter Attia (peterattiamd.com) [2:15]

**Gerald Shulman’s Banting Memorial Lecture**: [Critical Viewing on Insulin Resistance – Banting Medal for Scientific Achievement – Gerald Shulman](https://www.youtube.com/watch?v=TnvmEUUtoZw) | Ivor Cummins (youtube.com) [4:30]

**About 90% of Americans have at least one of these five characteristics of metabolic syndrome**: [Prevalence of Optimal Metabolic Health in American Adults: National Health and Nutrition Examination Survey 2009–2016](https://www.liebertpub.com/doi/10.1089/met.2018.0105) (Araújo et al., 2019) [19:00]

**Gerald Reaven’s 1988 Banting Lecture**: [Role of Insulin Resistance in Human Disease](https://diabetes.diabetesjournals.org/content/37/12/1595) (Gerald M Reaven, 1988) [22:00]

**Shulman’s study using NMR which determined that an insulin resistant person can’t make glycogen effectively**: [Quantitation of Muscle Glycogen Synthesis in Normal Subjects and Subjects with Non-Insulin-Dependent Diabetes by 13C Nuclear Magnetic Resonance Spectroscopy](https://www.nejm.org/doi/full/10.1056/NEJM199001253220403) (Shulman et al., 1990) [28:00]

**Shulman’s experiment determining that the biochemical block of glycogen synthesis was at the GLUT4 transport**: [Impaired Glucose Transport as a Cause of Decreased Insulin-Stimulated Muscle Glycogen Synthesis in Type 2 Diabetes](https://www.nejm.org/doi/full/10.1056/nejm199907223410404) (Cline et al., 1999) [32:00]

**Shulman’s experiment that showed that intramyocellular lipid (IMCL) content correlated with muscle insulin resistance**: [Intramyocellular lipid concentrations are correlated with insulin sensitivity in humans: a 1H NMR spectroscopy study](https://pubmed.ncbi.nlm.nih.gov/10027589/) (Krssak et al., 1999) [33:30]

**Study that infused people with lipids and heparin and was able to demonstrate within a couple of hours of giving people lipid infusion with heparin, they were able to** ***induce profound insulin resistance***: [Mechanism of free fatty acid-induced insulin resistance in humans.](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC507380/) (Roden et al., 1996) [35:30]

**Peter’s podcast episode discussing PI3K with Lew Cantley**: [#110 – Lew Cantley, Ph.D.: Cancer metabolism, cancer therapies, and the discovery of PI3K](https://peterattiamd.com/lewcantley/) | Peter Attia (peterattiamd.com)  [41:00]

**Shulman’s experiment to assess PI3K activity in the muscle of healthy volunteers before and after a lipid infusion**: [Effects of free fatty acids on glucose transport and IRS-1-associated phosphatidylinositol 3-kinase activity](https://pubmed.ncbi.nlm.nih.gov/9916137/) (Dresner et al., 1999) [42:15]

**Peter’s podcast episode discussing zone 2 exercise with Iñigo San Millán**: [#85 – Iñigo San Millán, Ph.D.: Mitochondria, exercise, and metabolic health](https://peterattiamd.com/inigosanmillan/) | Peter Attia (peterattiamd.com) [46:15]

**AMA episode diving deep into zone 2 exercise**: [#145 – AMA #19: Deep dive on Zone 2 training, magnesium supplementation, and how to engage with your doctor](https://peterattiamd.com/ama19/) | Peter Attia (peterattiamd.com) [46:15]

**Athlete’s paradox studies looking at intramyocellular triglycerides**: [Distinct lipid droplet characteristics and distribution unmask the apparent contradiction of the athlete’s paradox](https://pubmed.ncbi.nlm.nih.gov/30174227/) (Daemen et al., 2018) [49:00]

**Shulman’s experiment to answer the question of the fate of the ingested carbohydrate**: [The role of skeletal muscle insulin resistance in the pathogenesis of the metabolic syndrome](https://www.pnas.org/content/104/31/12587) (Petersen et al., 2007) [52:15, 1:00:30]

**25% of people globally have NAFLD**: [Global epidemiology of nonalcoholic fatty liver disease—Meta‐analytic assessment of prevalence, incidence, and outcomes](https://aasldpubs.onlinelibrary.wiley.com/doi/full/10.1002/hep.28431) (Younossi et al., 2015) [1:01:30]

**Between 10% and 30% of American have NAFLD (similar in Europe and Asia)**: [1:01:30]

- [Systematic review: the epidemiology and natural history of non‐alcoholic fatty liver disease and non‐alcoholic steatohepatitis in adults](https://onlinelibrary.wiley.com/doi/full/10.1111/j.1365-2036.2011.04724.x) (Vernon et al., 2011)
- Similar rate in Europe and Asia: [NAFLD in Asia—as common and important as in the Wes](https://www.researchgate.net/profile/Vincent_Wong2/publication/235786198_NAFLD_in_Asia_-As_common_and_important_as_in_the_West/links/560c720408aea68653d36c1a/NAFLD-in-Asia-As-common-and-important-as-in-the-West.pdf)t (Farrell et al., 2013)

**Over 100 million people have either pre-diabetes and diabetes**:  [New CDC report: More than 100 million Americans have diabetes or prediabetes](https://www.cdc.gov/media/releases/2017/p0718-diabetes-report.html) (2017) [1:02:00]

**In 2020, the number of individuals with NAFLD cirrhosis is predicted to exceed that of those with hepatitis B- and C-related cirrhosis, and NAFLD cirrhosis will become the leading indication for liver transplantation**: [Nonalcoholic Fatty Liver Disease Cirrhosis: A Review of Its Epidemiology, Risk Factors, Clinical Presentation, Diagnosis, Management, and Prognosis](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6051295/) (Li et al., 2018) [1:04:00]

**Peter’s discussion about the impact of fructose consumption with Robert Lustig**: [#14 – Robert Lustig, M.D., M.S.L.: fructose, processed food, NAFLD, and changing the food system](https://peterattiamd.com/roblustig/) | Peter Attia (peterattiamd.com) [1:04:30]

**Study showing the impact of a single bout of exercise on insulin stimulated muscle glycogen synthesis**: [Increased Glucose Transport–Phosphorylation and Muscle Glycogen Synthesis after Exercise Training in Insulin-Resistant Subjects](https://www.nejm.org/doi/full/10.1056/NEJM199610313351804) (Perseghin et al., 1996) [1:05:00]

§

## People Mentioned

- [Gerald Shulman](https://medicine.yale.edu/profile/gerald_shulman/#:~:text=Shulman%20is%20the%20George%20R,the%20Yale%20Diabetes%20Research%20Center.&text=Shulman%20is%20the%20recipient%20of%20the%20Stanley%20J.) [2:15]
- [Gerald Reaven](https://en.wikipedia.org/wiki/Gerald_Reaven) [22:00]
- [Lew Cantley](https://en.wikipedia.org/wiki/Lewis_C._Cantley)  [41:00]
- [Iñigo San Millán](https://twitter.com/doctorinigo?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) [46:15]
- [Robert Lustig](https://profiles.ucsf.edu/robert.lustig) [1:04:30]
- [Nir Barzilai](https://en.wikipedia.org/wiki/Nir_Barzilai) [1:18:15]

§