# #374 – The evolutionary biology of testosterone: how it shapes male development and sex-based behavioral differences | Carole Hooven, Ph.D.

**Source:** [https://peterattiamd.com/carolehooven/](https://peterattiamd.com/carolehooven/)

---

Carole Hooven is a human evolutionary biologist whose research centers on testosterone, sex differences, and behavior. In this episode, she explores how prenatal testosterone orchestrates male development in the body and brain, how early hormonal surges shape lifelong behavioral tendencies, and what rare natural experiments—such as 5-alpha-reductase deficiency—reveal about the biology of sex differentiation. She discusses distinct male and female aggression styles through an evolutionary lens, how modern environments interact with ancient competitive drives, and the implications of attempting to suppress them. The conversation also covers testosterone across the lifespan, the role of hormone therapy in both men and women, and Carole’s own experience after surgical menopause, culminating in a broader discussion of masculinity, cultural narratives, and the consequences of denying biological sex differences.

Subscribe on: [APPLE PODCASTS](https://itunes.apple.com/us/podcast/the-peter-attia-drive/id1400828889?mt=2) | [SPOTIFY](https://open.spotify.com/show/63AWQmsSnFNFHUqnRAOFtD) | [RSS](http://peterattiadrive.libsyn.com/rss) | [OVERCAST](https://overcast.fm/itunes1400828889/the-peter-attia-drive)

![The Peter Attia Drive](images/carolehooven/the_Drive_public.png)

Play

#374 - The evolutionary biology of testosterone: how it shapes male development and sex-based behavioral differences, | Carole Hooven, Ph.D.

#374 - The evolutionary biology of testosterone: how it shapes male development and sex-based behavioral differences, | Carole Hooven, Ph.D.

1x15s30s

0:002:05:20

## We discuss:

**Timestamps**: There are two sets of timestamps associated with the topic list below. The first is audio (A), and the second is video (V). If you are listening to this podcast with the audio player on this page or in your favorite podcast player, please refer to the audio timestamps. If you are watching the video version on this page or YouTube, please refer to the video timestamps.

- How Carole became interested in exploring the biological and evolutionary roots of sex differences and the role of testosterone [A: 2:30, V: 0:11];
- How testosterone and other hormones influence sex differences in aggression and behavior across species [A: 9:45, V: 8:25];
- How chromosomes, the SRY gene, and early hormones direct embryonic sexual differentiation [A: 12:15, V: 11:09];
- A stark contrast of male social bonding compared to females, and evolutionary parallels in chimpanzees [A: 19:30, V: 20:04];
- How hormones like DHT shape sexual differentiation, and how 5⍺-reductase deficiency reveals the distinct roles of these hormones [A: 22:45, V: 23:43];
- How sex chromosomes and prenatal testosterone shape early brain development and explain sex differences in childhood behavior [A: 31:30, V: 34:20];
- How gamete differences shape reproductive strategies, energetic costs, and sex-specific behavior [A: 42:30, V: 47:13];
- How evolutionary biology shapes sex differences in play, aggression, and conflict resolution (and how modern environments and cultural messaging can disrupt those patterns) [A: 49:00, 55:04];
- Why males commit disproportionately more violent crime, and how cultural and environmental forces shape aggression [A: 1:01:00, V: 1:09:10];
- Why females evolved different behavioral strategies: nurturing, risk aversion, and the cultural norms that override biology [A: 1:04:00, V: 1:13:12];
- Whether male aggression is still necessary in modern society, why the underlying biological drives persist, and how modern society redirects these drives [A: 1:06:30, V: 1:15:59];
- How testosterone levels naturally shift to support fatherhood and caregiving [A: 1:13:30, V: 1:24:45];
- How testosterone shapes male mating strategies, and why long-term pair-bonding persists even when reproduction is no longer at stake [A: 1:18:30, V: 1:30:38];
- The distinct roles of estrogen in male development, mood, libido, and muscle [A: 1:25:00, V: 1:38:42];
- How evolution, health, lifestyle, and androgen receptor biology shape modern testosterone replacement therapy (TRT) [A: 1:34:15, V: 1:49:50];
- Carole’s experience with hormone replacement therapy (HRT), and the risks associated with TRT in younger men [A: 1:45:15, V: 2:02:44];
- How Carole rebuilt after controversy: leaving academia and recommitting to scientific honesty [A: 1:51:30, V: 2:10:32];
- Carole’s next book: examining masculinity, cultural narratives, and the cost of denying biological sex differences [A: 1:57:30, V: 2:17:40]; and
- More.

---

## Show Notes

\***Notes from intro**:

- Dr. Carole Hooven is a human evolutionary biologist, former Harvard lecturer, and non-resident senior fellow at the [American Enterprise Institute](https://www.aei.org/profile/carole-hooven/)
- Her research focuses on testosterone, sex differences, and behavior
- She holds a Ph.D. in biological anthropology (now human evolutionary biology) from Harvard University and is the author of [*T: The Story of Testosterone, the Hormone That Dominates and Divides Us*](https://www.amazon.com/Story-Testosterone-Hormone-Dominates-Divides/dp/1250236061/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.6lbcIlxbZc5Eqvj28-6Rxw.kt1G5aATixCnoKm4rN9C6EHxqB9i_x47n55W0JFZ_do&qid=1755519834&sr=8-1)

In this episode, we discuss

- How prenatal testosterone shapes the male body and brain, turning genetic signals into thousands of developmental changes that underlie later sex differences
- Critical hormone surges and why they matter for lifelong behavior
- DHT, androgen receptors, and rare natural experiments (for example, 5⍺-reductase deficiency) that reveal how external genitalia and the prostate masculanize
- Distinct male and female aggression styles: direct physical confrontation versus indirect or relational tactics
  - The evolutionary logic behind each
- Why modern life changes but doesn’t erase ancient drives (like male competitiveness), and the trade-off of trying to suppress them
- Testosterone, aging, and hormone therapy for both sexes
  - Including Carole’s personal experience after surgical menopause
- The cultural debate over masculinity and the cost of denying biological sex differences ‒  a theme of Carole’s forthcoming book

## How Carole became interested in exploring the biological and evolutionary roots of sex differences and the role of testosterone [A: 2:30, V: 0:11]

- Sex hormones are a topic that we talk a lot about on the podcast, but usually from a pretty narrow lens, which is in the form of replacement (both in men and women)
  - We talk about how they wax and wane as an individual ages
  - We talk about the medical use of them
- But we haven’t spent any time understanding the more basic fundamentals of these hormones
  - The role they play in our evolution

**Anecdotally, Peter shares an observation that any parent probably has, if they have male and female children**

- His first child was a girl, and his wife and he very stupidly and arrogantly thought they were the perfect parents, because she was so well-behaved
- They were like, “*What do all of these other parents with their boys running around misbehaving… What are they doing wrong? How could we teach them how to be as good as we are?*”
- They didn’t actually say that, but there was undoubtedly an annoying smugness to them
- And if you believe in a God, that God smacked them into their place with 2 boys that followed who were, for all intents and purposes, treated the same way, socialized the same way
- And there is a level of aggression in them, a fury in them that Peter has never seen, probably unless he were to go back and hear stories of what his mom said he was like
- His boys are now 8 and almost 11

Peter adds, “*I wouldn’t say they’re a different sex. I would say they’re a different species.”*

- Peter doesn’t feel that they did anything different [parenting the boys]
- And yet, they couldn’t be more different
- He appreciates that that’s not going to be the case for every parent

***What Peter hopes to learn is how much testosterone has to do with that***

- Because he is also under the impression that at this age, the testosterone levels wouldn’t be that much different
- We’ll probably talk about the differences in testosterone levels during the embryologic phase, because obviously that led to the differences
- That is a backdrop to this conversation

**How did you get interested in this topic?**

- Carole grew up with 3 older brothers, and they were different than she was in some consistent ways
  - Though she didn’t think much about it at the time

***That probably made her want to understand what motivates male behavior in general and why it’s different from female behavior***

- Studying this wasn’t an idea she had when she was in college
- But she did become intensely interested in the evolutionary origins of human behavior in general and what makes us different from other animals
- And that was because of traveling
  - She traveled by herself to a lot of different places in the world, during and after college
- There were extreme differences culturally ‒ Egypt was a place that really freaked her out
  - The cultural differences were so profound in terms of the incredibly important role that sex plays in social life and the segregation and different rules that applied to males and females
  - Carole was alone, traveling by herself as a young woman, totally ignorant of what she was getting into in Egypt
  - She was harassed endlessly
  - Some of that was her fault for not understanding the culture well enough and what she was getting into
- This combination of being immersed in, not only different societies that treated sex and sex roles very differently, but also different ecologies
- She spent some time in Africa and Kenya and Tanzania and got really interested in all of the animal behavior and why we are different from other animals
- She had a whole other career before graduate school, and she ended up leaving that career and applying to Harvard to try to do a graduate degree where she could do more to understand the evolutionary basis of human behavior
- She ended up getting rejected

***She just persisted and then was offered this job out in Uganda studying chimps for what was supposed to be a year ‒ that is what really triggered her interest in sex differences and testosteron***e

- Because to a certain extent, we are indoctrinated to believe that most human sex differences are cultural
  - Or if you think that they’re not, it’s better you don’t say that out loud to too many people or in the wrong place

**When she spent time with the chimps, she was really blown away by the ways that the sex differences in the chimps paralleled human sex differences**

- Of course, not exactly the same, but the very basic things that Peter just described in terms of energy and aggression, are present in the chimps in terms of being higher in the males and lower in the females
- The reasons for that are so profound and far-reaching and start with sperm and egg
- That’s what sex really is about
  - Not just the ability to produce sperm or eggs
  - But the way that the organism is designed and the reproductive phenotype including body and behavior
  - [explored more in this [essay](https://pubmed.ncbi.nlm.nih.gov/40199245/) Carole recommends]
- That, in humans, plays out in these really complex ways in terms of social systems
- Carole got interested in [testosterone](https://en.wikipedia.org/wiki/Testosterone) because this is one thing she could grab onto that links very clearly humans, chimpanzees, every other mammal in terms of males having much higher levels than females
  - And it’s not just mammals; there are other forms of steroid hormones that other species have
  - But this is pervasive and just a very powerful way to understand proximately that means what’s happening here and now in the organism, why the sexes are different

***There are these deep evolutionary pressures that have to do with reproductive strategies for organisms that produce sperm versus organisms that produce eggs***

- She ended up reapplying to Harvard and getting into the grad program there

**Carole did her dissertation on testosterone and sex differences in cognition, the way we think and process information**

- She had men watch sexy videos and also videos of dental surgery and collected their saliva and measured their testosterone in the lab
- Then she stayed on at Harvard, mostly just teaching

## How testosterone and other hormones influence sex differences in aggression and behavior across species [A: 9:45, V: 8:25]

- Peter wants to go back to the distinction between mammals and non-mammals
  - He never really thought of it until she mentioned this
  - Differences if he were to look at a male great white shark and a female great white shark

**Do great white sharks have testosterone in them as the androgen or sex hormone?**

- [Most vertebrates will have testosterone](https://pubmed.ncbi.nlm.nih.gov/31525432/) or something very close to it
- Peter points out that typically the female great white sharks are larger
- And he would reckon they’re just as aggressive as the males

*Is that aggression reflected in comparable levels of testosterone in those species?*

- Carole doesn’t know specifically about sharks

Body size

- First of all, males are not always bigger than females

**⇒** Males will do whatever they need to do, generally, to compete for mates, and in many species, it’s not to be larger

***There are differences in the ability to defend a territory or defend mates and air and water and land ‒ and that’s really an interesting way to understand some male competitive strategies***

- [Carole added by email this quote from a [review](https://pubmed.ncbi.nlm.nih.gov/327542/), “*The greater the potential for individuals to monopolize resources or mates, the greater the intensity of sexual selection, and the greater the environmental potential for polygamy.”*]

Maternal aggression

- But generally, in the species, if the female is just as aggressive, often, it’s maternal aggression and not necessarily mate competition

**⇒** Maternal aggression tends to be mediated more by [estrogen](https://en.wikipedia.org/wiki/Estrogen) than testosterone

- Even in hyenas, which are very difficult to tell apart, the females are very difficult to tell apart from the males
  - They have this clitoris that looks exactly like a penis, and experts often can’t even tell the difference
- They’re highly aggressive, and that seems not to be mediated in the adult by comparable levels of testosterone

***There seems to be potentially something going on in early development, but I don’t know of good evidence that testosterone acts similarly in females to mediate mating aggression***

Peter asks, “*Just to make sure I understand. In the hyenas, if you took an adult male and an adult female hyena, would they have similar levels of testosterone and estrogen?*”

- No, the [males would have higher levels of testosterone](https://pubmed.ncbi.nlm.nih.gov/11161886/)
- Despite the fact that phenotypically, they look the same and they’re equally aggressive
- Adult female hyenas are either just as aggressive (if not more so); she believes they are dominant to males
  - [Carole clarified by email that adult female spotted hyenas are socially dominant to all adult males not born in the female’s natal clan. Females are also substantially more aggressive than males. (explained further in [this recent review](https://pubmed.ncbi.nlm.nih.gov/34649923/))]

***There’s something going on with potentially maternal adrenal androgens when the fetus is developing that becomes the aggressive female***

- [Carole shared this [quote](https://pmc.ncbi.nlm.nih.gov/articles/PMC9248831/) by email, “*Exposure to androgens early in development appears to enhance aggressiveness in female spotted hyenas. In the wild, both juvenile and adult females whose mothers have higher androgen concentrations during gestation are considerably more aggressive than are same-age females exposed to lower androgen concentrations in utero*.”]

## How chromosomes, the SRY gene, and early hormones direct embryonic sexual differentiation [A: 12:15, V: 11:09]

**What are the steps that create the phenotypic sex differences in the human embryo and how do they involve sex hormones?**

- Peter recalls from medical school that 99.9% of cases are either XX or XY, in terms of humans
- We can talk about [Turner’s](https://en.wikipedia.org/wiki/Turner_syndrome) and [Klinefelter’s](https://en.wikipedia.org/wiki/Klinefelter_syndrome) and things like that later

Phenotypically, sticking to differences in development of the body

- Humans have a sex determination system that relies on chromosomes, but not every animal does
- So chromosomes do not equal sex
  - Birds use chromosomes, but they have a different system where the female is the one that has heterozygotic chromosomes
  - There’s temperature dependent sex determination

**⇒** People should not confuse the sex chromosomes themselves with the definition of sex

- In mammals, the chromosomes determine sex, but do not define sex
- Across almost all sexually reproducing organisms, it’s the gamete type that the organism is basically designed around, that the reproductive system is designed around that defines sex
- Other organisms can be hermaphroditic (produce both gamete types at the same time), or they can be sequential hermaphrodites
- In humans, the mother’s egg, the sex chromosome is always going to be an X that it donates in its egg, and it’s going to combine with a sperm
- 50% of the sperm are going to have a Y sex chromosome, and 50% of the sperm are going to have a X (in general)
- Those two combine and the developing embryo is going to be either XX and XY

Let’s start with the XY

- Peter is an XY
- Carole had a son who is an XY
  - Which is interesting for women because they will have something inside of them that has testicles that produce testosterone

**⇒** Both XY and XX fetuses are identical until around 5 or 6 weeks

- The Y chromosome has a gene on it called the [*sex determining region of the Y chromosome (SRY)*](https://en.wikipedia.org/wiki/Sex-determining_region_Y_protein) that produces a protein called the SRY protein

**⇒** The SRY protein is very important because it triggers the differentiation of the undifferentiated gonad

- What’s really cool and interesting is that before that time, we all have a gonad that can become either one
  - It can become testes or it can become ovaries
  - And that’s an [amazing design](https://en.wikipedia.org/wiki/Sexual_differentiation_in_humans): that’s evolution’s way of not wasting energy, not having to have 2 different systems (where one develops and the other gets discarded)
- In terms of **sexual differentiation**, that means that for XY individuals, the gonads are going to develop along the testicle route
- And without the SRY gene, they will by default
  - Default doesn’t mean that nothing else has to happen ‒ other genes have to be expressed, and that’s an active process (it’s not a passive process)
  - But without the SRY gene, those undifferentiated gonads will differentiate in the female direction to form ovaries

**Peter remembers from embryology class that we are by default female, and the** ***SRY*** **gene had to “turn on” to basically take the XYs and make them male, phenotypically (that’s obviously oversimplified)**

- In some ways, that’s true
- If you had an XY individual that’s missing the *SRY* region, they would phenotypically be female but chromosomally male [[Swyer syndrome](https://en.wikipedia.org/wiki/XY_gonadal_dysgenesis)]
  - You wouldn’t be able to develop functional ovaries because you would need 2 Xs to do that
  - But for all intents and purposes, you would look female (including external genitalia)
  - This is an **edge case**
- If you think about what the genitalia look like in an early developing fetus, it looks female
  - It doesn’t have to change that much, it gets bigger
- But if you take what looks like even adult female genitalia, basically, you modify the clitoris and the labia to get what looks like typical male genitalia
  - That has to do a lot of growing and changing, and it’s like that in the fetus
- If we’re going down the male route, you get the expression of *SRY*
  - And what that does is, it causes certain cells in this undifferentiated gonad to develop into first [Leydig cells](https://en.wikipedia.org/wiki/Leydig_cell) and then later [Sertoli cells](https://en.wikipedia.org/wiki/Sertoli_cell)
- Later, ovarian differentiation takes place

In males, 2 things happen

- The Leydig cells start producing testosterone first
- Carole goes back [to earlier in development] to talk about the [Wolffian ducts](https://en.wikipedia.org/wiki/Mesonephric_duct) and the [Mullerian ducts](https://en.wikipedia.org/wiki/Paramesonephric_duct)
  - We start out with these two primordial or primitive gonads that can become either [sex], and they’re high (almost in the chest)
  - In males, they have to descend into what becomes the scrotum
  - In females, they just stay there
- We still don’t completely understand why males take all this valuable stuff and keep it outside of their body
  - Maybe temperature regulation?
- Carole researched it pretty thoroughly and came up with no answer; she wrote about it in her [book](https://www.amazon.com/Story-Testosterone-Hormone-Dominates-Divides/dp/1250236061/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.6lbcIlxbZc5Eqvj28-6Rxw.kt1G5aATixCnoKm4rN9C6EHxqB9i_x47n55W0JFZ_do&qid=1755519834&sr=8-1)
  - Both [elephants and whales](https://www.smithsonianmag.com/science-nature/earliest-mammals-kept-their-cool-descended-testicles-180969476/#:~:text=four%20Afrotherian%20species%20lacking%20descended%20testicles%E2%80%94manatees%2C%20cape%20golden%20moles%2C%20cape%20elephant%20shrews%20and%20tenrecs) have their testes located inside their bodies, but for the majority of mammals, it’s outside
  - There certainly is temperature regulation, but then why don’t we have the system however it is that the elephants can get away with?

## A stark contrast of male social bonding compared to females, and evolutionary parallels in chimpanzees [A: 19:30, V: 20:04]

**Peter’s stupid detour for Carole’s next book**

- Peter was at his younger son’s baseball party at the end of the season
- Picture 20 7-year-old boys running around the pool, playing baseball, playing football, goofing off
- The dads were sitting there hanging out, observing their behavior
- Peter’s observation: there’s estimated to be about 110 billion humans that have lived over the past 250,000 years (inclusive, of the 8+ billion that are alive today)
  - And just watching this small group of 20, you could already see the number of times one boy would walk up to the other and flick him in the nuts
- To the dads, Peter was like, “*All right, how many times in the history of 250,000 years has one male gone up to another male to flick him in the nuts? What’s that number?*”
  - Whatever that number is, it’s enormous
- Now, what’s the number of females that have gone up to another female and gone, ping, and tried to flick them in the clitoris? Zero
  - Sometimes a little breast play in teenagers, but nothing like what men do (you’re talking a ratio of 0 to 87,432 million)

***Peter’s only hypothesis is: males are idiots. It’s such an evolutionary stupid thing to do. That’s a very precious part of real estate.***

Carole asks, “*That’s the point. So why would they do that?*”

- Peter thinks it’s like, “*I’m going to be dominant. I’m going to reduce your probability of reproduction*.”
- Carole points out that these are kids who are usually good friends, and only a good friend could get away with that
  - If a stranger did it, then you’re going to come to blows

***Carole points out that male intimacy involves insults***

- The harsher the insult, somehow, the more intimate
  - Unless it’s rejected, like you just described with the flick

**In chimps this was amazing to see because Carole didn’t know about it**

- When they’re in a high stress or conflict situation or there has been a conflict, the subordinate will cup the balls of the dominant one
- And they also play sex from behind
- But it’s this intimate, trusting, weird situation where Carole thinks it really is saying, “*I’m down for you. I’m not going to hurt you. I’m holding your testicles, and you can trust me*.”
  - That’s interesting
- This blows Peter’s minds, because again, the dads sat around and laughed hysterically at this
- Most of them have daughters and know their girls would never behave this way

**There’s all these things we don’t understand**

- One of them is: Why would you leave this precious real estate outside your body, if you could potentially thermoregulate inside the body?

## How hormones like DHT shape sexual differentiation, and how 5⍺-reductase deficiency reveals the distinct roles of these hormones [A: 22:45, V: 23:43]

**Back to the development of human males**

- Carole is going to go through the duct a little more quickly
- There are 2 different plumbing systems, 1 for males and 1 for females
  - The [Mullerian ducts](https://en.wikipedia.org/wiki/Paramesonephric_duct) become the female internal plumbing
  - The [Wolffian ducts](https://en.wikipedia.org/wiki/Mesonephric_duct) become the male internal plumbing

**⇒** What’s important is that the Leydig cells produce testosterone, which stabilizes the development of the Wolffian ducts

The testicles have to produce 2 hormones

- 1 – [Leydig cells](https://en.wikipedia.org/wiki/Leydig_cell) produce testosterone to stabilize the Wolffian ducts to connect the sperm producing organ to the delivery system (ultimately, which is the penis)
- [2 – [Sertoli cells](https://en.wikipedia.org/wiki/Sertoli_cell) produce [anti-Müllerian hormone (AMH)](https://en.wikipedia.org/wiki/Anti-M%C3%BCllerian_hormone) and that] causes the degeneration of the Mullerian ducts

***The testicles produce both anti-Müllerian hormone and testosterone to drive development of male genitalia***

- This is important when we talk about the disorders or differences of sexual development
- Healthy testes will have those effects
- And you can also think about what happens if they can’t produce anti-Müllerian hormone, or what happens if there’s no receptor for testosterone or no receptor for Müllerian hormone

**Is any of this testosterone being converted to DHT in any meaningful amount?**

- [Peter misspoke when he said [DHEA](https://en.wikipedia.org/wiki/Dehydroepiandrosterone), he meant [DHT](https://en.wikipedia.org/wiki/Dihydrotestosterone)]
- Not that Carole knows of

[***DHT***](https://en.wikipedia.org/wiki/Dihydrotestosterone) ***is extremely important, and that comes next***

**⇒** DHT is converted [from testosterone] via the enzyme [5⍺-reductase](https://en.wikipedia.org/wiki/5%CE%B1-Reductase) that is present in high concentrations in the genital tissue

- What’s interesting about this is that you have a mechanism to achieve high concentrations of a more potent androgen, without that having to circulate through the general circulation, which you do not want in a developing fetus
- You want to be able to control the development of the penis, say, which is one of the things that DHT does
- So the genital tubercle can become the clitoris or the penis
  - In the presence of testosterone, and functional 5⍺-reductase, it becomes a penis
  - The labia grow and then fuse to become the scrotum, and also the prostate
- DHT is necessary for full prostate development and can later sustain the function of the prostate

***So it is interesting because DHT is this solution to providing very*** [***strong androgenic signals***](https://www.ncbi.nlm.nih.gov/books/NBK557634/#:~:text=Mechanism,Go%20to:) ***in the tissues that need it without wasting energy on strong androgenic signals in the rest of the body***

Peter never thought about this until now and asks, “*Is that why DHT has such a high affinity for the androgen receptor?*”

- Yes

***It allows DHT to only have a local effect during embryologic development***

- It doesn’t matter in old age that DHT is much more potent that testosterone

**⇒** DHT is something like 2-5x more potent than testosterone [explained further in [StatPearls](https://www.ncbi.nlm.nih.gov/books/NBK557634/#:~:text=Compared%20to%20testosterone%2C%20DHT%20has,for%20the%20metabolism%20of%20DHT.)]

- What this means is that it binds the receptor more tightly, and it stays on for longer
- Which means that it produces more of whatever the protein is [whose expression is controlled by the [androgen recepto](https://en.wikipedia.org/wiki/Androgen_receptor)r]
  - Because it’s a steroid ‒ testosterone is a steroid, estrogen is a steroid
  - And steroids typically act by either inhibiting, but generally up-regulating androgenic genes
  - That’s super interesting

**There’s a disorder:** [**5⍺-reductase deficiency**](https://en.wikipedia.org/wiki/5%CE%B1-Reductase_2_deficiency) **where individuals are basically typical males, but they are** ***not*** **able to produce DHT**

***DHT is not what masculinizes the brain, but it does masculinize external genitalia***

- Without DHT, you’re going to have what look like female genitalia in a male who’s otherwise typical male
  - Because the testosterone works and the androgen receptors are present
- These are really rare conditions
  - In medical school, you come away thinking these things occur all the time, because of how much time you spend studying them
    - Fortunately, they’re not common
- Carole used to teach a lot about these cases because they really help to understand the typical pathway
  - They illustrate how powerful, even tiny little mutations in little genes can be
- And Carole thinks it increases compassion when we understand what the pathway is that leads to these differences or disorders

**⇒** An individual with 5⍺-reductase deficiency looks female at birth

- For this **edge case**, it depends on where they’re born
  - This will become relevant if they talk about sports
  - If they’re born in places without a modern medical care, often, they are sexed as female
- But it becomes apparent pretty quickly in childhood that they’re actually male
  - Because they look male everywhere else
  - The body will look male once puberty hits
  - But there is a lack of facial hair and other body hair

Peter asks, “*Do they have ovaries?*”

- They have testes, but they may or may not have descended
- People may believe that they’re female until puberty, when they start developing male musculature

**⇒** Sometimes they’re producing totally normal testosterone levels, just not DHT

***The point is, the testosterone is the determining factor (for muscle mass)***

Other physical characteristics controlled by DHT

- If you don’t make DHT, some body hair won’t be produced (certainly not facial hair)
- Without DHT you don’t have [male pattern baldness](https://en.wikipedia.org/wiki/Pattern_hair_loss)
- The lack of facial hair really makes a huge difference, because it gives a more feminine appearance to the facial skin
- So DHT is important

Back to female sports

- Part of why 5⍺-reductase deficiency is relevant now is because there are people who are sexed as female and are legally female who are coming from, say, [a rural town in South Africa](https://www.bbc.com/sport/athletics/67367157) and they’ve been running as a female on female sports teams or boxing, for instance
- It brings up complicated social issues about what to do
- And that means that we really do need to understand the science there

***The important thing from Carole’s point of view is that DHT has been pretty clearly shown not to be necessary for male typical patterns of musculature and other physical features that would give men an advantage over women***

- Which is difficult because sometimes these people have been in a female social role depending on where they were born

Peter proposes a thought experiment: giving a male a [5⍺-reductase inhibitor](https://en.wikipedia.org/wiki/5%CE%B1-Reductase_inhibitor) from age 5 on

- If you took a chromosomally, phenotypically normal male, and from the time they were 5 years old, you gave them a 5⍺-reductase inhibitor, all you’re doing is turning their DHT down to zero and doing nothing else
- You’re basically asking the question, will they develop normal musculature?
- Carole explains, “*Shalender Bahsin et al. have done that* [*experiment*](https://pubmed.ncbi.nlm.nih.gov/22396515/)*, and there’s no difference between blocking DHT… They did it in humans*.”

**Peter’s takeaway**

- XX and XY start out [in development] for about 5 weeks, indistinguishable
- At about that 5-week mark, a gene on the Y chromosome specifically begins to trigger the differentiation pattern
- That differentiation pattern triggers the transcription of genes that turn on hormones that are going to further activate and drive sex differentiation

## How sex chromosomes and prenatal testosterone shape early brain development and explain sex differences in childhood behavior [A: 31:30, V: 34:20]

**That differentiation pattern during development triggers the transcription of genes and is very important**

> “*The production of testosterone in the testes is really important and just fundamental to understanding sex differences*.”‒ Carole Hooven

- It’s not that we have so many different genes
- At the same time, we’re learning more about the role of the 70-100 genes on the Y chromosome
  - Many of which are crucial for typical development of male reproduction and reproductive function
- But also, it appears that there’s some role even prior to the production and action of [testosterone] on the body and brain
  - There may be early expression of genes on the Y chromosome that act in the brain to shape later patterns of behavior
  - There’s a lot of work going on there to understand that

**The genetic differences don’t just stop at the differences with those genes on the Y chromosome**

- All the other genes are the same, except for the sex chromosomes

***Having one X versus two Xs makes a huge difference; it’s extremely important***

- Females completely silence one of their X chromosomes in each cell, which is something that basically does happen, so that we don’t have a double dose of X chromosome genes compared to males
  - The silenced X chromosome is called the [Barr body](https://en.wikipedia.org/wiki/Barr_body)
- Peter points out that this must be more complicated [in females], or else you wouldn’t have [Turner syndrome](https://en.wikipedia.org/wiki/Turner_syndrome) [females that have only 1 X chromosome, 45 total chromosomes]

**⇒** Around 20% of the genes on the silenced X chromosome escape inactivation [read more in this 2023 [article in *Epigenomes*](https://www.mdpi.com/2075-4655/7/4/29#:~:text=Perhaps%20unexpectedly%2C%20the%20inactive%20X,from%20the%20otherwise%20inactive%20chromosome.)]

- There are some genes in females where the female needs the double dose of those genes
- And if she doesn’t have the double dose, as in Turner syndrome (folks that have a single X chromosome)
- Turner syndrome can be due to [lack of a sex chromosome] from mom or dad
- There are [imprinted genes](https://en.wikipedia.org/wiki/Genomic_imprinting) depending on the parental origin
  - Meaning certain genes are preferentially expressed or suppressed in the mom’s X versus the dad’s for [interesting evolutionary reasons](https://pubmed.ncbi.nlm.nih.gov/12728278/)
  - Because the mom and dad have competing interests in what happens to the kid
- Phenotypically, a woman with Turner syndrome appears phenotypically female but she is not able to reproduce
  - There’s some [evidence](https://www.sciencedirect.com/science/article/pii/S1083318815003575) that with technology she could reproduce
  - She is short in stature, has a wider neck, and a few other characteristics
  - But they are typical females in other ways
- There is research on which genes are escaping inactivation on the inactivated X chromosome [aka the Barr body]

**During fetal development and shortly after birth, males experience a surge in testosterone levels**

- Levels of testosterone in males during development is different from females

***There is a high level of testosterone in the fetus that is approaching concentrations in male puberty and this is not happening in the female (this is a huge difference)***

**⇒** Testosterone levels matter in the developing fetus because testosterone as a steroid is acting as a transcription factor when it binds with a receptor to alter gene transcription on thousands of genes (that is happening in males and not in females)

- This happens at about 8 weeks into development and peaks between weeks 15-20
  - Somewhere early in the second trimester
  - If a male in puberty has 1200 ng/dL testosterone, this could be maybe 400 ng/dL
  - It’s very high
- It goes down after birth
- But then it goes up again, peaking at 3 months after birth ‒ that’s called **“mini-puberty”**

***The point is, this testosterone is affecting the development of the brain***

**Carole is interested in behavior**

**⇒** From an evolutionary point of view, what’s going on in this early environment is extremely important

- The male body is realizing that it’s going to be a sperm producing animal
- We have very firm evidence, but we can’t do these experiments in humans
  - People don’t like it when all the evidence comes from non-human animals, but most of it does, and that’s just because we can’t manipulate genes and hormones and developing fetuses to see what happens
- We have some, quote, “natural” experiments

***All the*** [***evidence***](https://pubmed.ncbi.nlm.nih.gov/26972372/) ***shows that testosterone is a potent regulator of neural development and differentiation from females, which is why boys and girls aren’t the same***

- This is 100% the reason that explains the birthday party phenomenon [that Peter discussed earlier]
- All the evidence we have points to testosterone
- Socialization matters
  - If you punish your kid for not being masculine enough, for being too masculine, which happens because now toxic masculinity and rough-and-tumble play is supposed to be toxic (It’s not. It’s healthy, it’s necessary)

> “*Masculinity and rough-and-tumble play is supposed to be toxic. It’s not. It’s healthy, it’s necessary*.”‒ Carole Hooven

***There’s lots of evidence showing the impact of testosterone on behavior***

- [Carole discusses this in her [TED Talk](https://www.ted.com/talks/carole_k_hooven_how_testosterone_and_culture_shape_behavior)]
- Back to the chimps, the males play more roughly than the females
- In many mammals where there is a sex difference in play, the males are playing more roughly (there’s a reason)

**Peter’s takeaway**

- You have this real peak difference in testosterone during a critical window of development when the brain is developing, and so you have a female (XX) brain that is developing in the absence of testosterone
- The XY (male) brain is developing in the presence of high amounts of testosterone, and then testosterone falls
- By the time these two babies are born, they both have really low testosterone
- Then, unbeknownst to Peter until a few minutes ago, you have this little mini-puberty that comes 3 months later

**During different periods of male development, different parts of the brain and body are receptive to testosterone**

- This is extremely important and it’s been shown in non-human animals
- You’ve got the period where testosterone is being produced in the fetus, and within that, there are certain developmental periods where different parts of the brain and body are receptive to testosterone’s actions
- We know from [non-human primates](https://www.researchgate.net/publication/363119365_Prenatal_Steroid_Hormones_and_Sex_Differences_in_Juvenile_Rhesus_Macaque_Behavior) that there are different critical periods for, say, development of the genitalia, other parts of the reproductive system, and potentially for sexual and aggressive behavior separately

Carole explains, “*That’s interesting because when we want to understand certain aspects of male behavior or differences in male behavior, it’s helpful to know that possibly, aggressive and sexual behavior may have different thresholds for male typical versus female typical, and that there may be different critical periods, so that we don’t really know in humans*.”

- Also in males, once you hit your male typical level of testosterone
  - We’re just talking about male versus female typical patterns of behavior

**⇒** There isn’t a typical level of male testosterone (there isn’t really a dose-response relationship), it’s more that males at a level that’s 10 to 20x greater than in females

- Females have some testosterone exposure in utero and some females have more than would be typical
- In females, there is a dose-response relationship because our levels are so low and we’re sensitive to differences, but males have so much more, those differences don’t seem to make a difference once you cross this threshold

What Peter hears Carole saying is, “*When you observe 5-year-old boys and 5-year-old girls behaving completely differently, the most obvious explanation for the why is a behavioral difference, and the behavioral difference is driven by potentially the way their brains developed during that critical window of being bathed in testosterone as opposed to the differences in testosterone in a five-year-old boy versus a five-year-old girl, which are de minimis.*”

**There are some really important points here in what Peter just said**

- What we’re going to talk about in terms of childhood shows that you cannot judge anyone by their **current testosterone levels**
  - You can’t predict that much
  - [assessed in this [clinical trial](https://pubmed.ncbi.nlm.nih.gov/15181066/)]
  - You can’t attribute variation in behavior and individual differences in behavior necessarily to current testosterone levels
- If you do have current levels, often you can’t predict much in terms of, say, sexual behavior or aggressive behavior
  - You certainly can’t with kids because they don’t have any differences
  - Kids hardly have any testosterone at all

**⇒** There is tremendous variation in testosterone levels. The only thing that differentiates the sexes cleanly and essentially is the gamete production.

## How gamete differences shape reproductive strategies, energetic costs, and sex-specific behavior [A: 42:30, V: 47:13]

**Define that again. Peter wants to make sure the listener understands when you’re referring to gamete production**.

*What has evolution designed sperm and eggs for?*

***If you are XY and you’re going to be making sperm, there’s going to be a suite of characteristics generally that are going to be different from the suite of characteristics that a female who has ovaries and eggs will need to maximize reproduction***

- All evolution cares about is what portion of your genes are making it into future generations
- The design here is about reproductive strategies that coordinate how your body grows, what your body is like, what physical features you develop, coordinates the hormones, coordinate that with certain patterns of behavior on average
- All of the bodies and the behavior can vary across XX and XYs [females and males], but what we’re talking about is these **broad patterns, mostly to do with sex and aggression, that tend to differ** between males [and females], and this is across sexually reproducing organisms for the most part
- So all the other stuff can vary

***It’s not that all XY people are going to have a higher sex drive and be more aggressive. That’s just not the case. Bodies vary, behavior varies.***

**Do you have a sense of why the female gametes are all produced up front and you basically get your lot at birth and then that’s it?**

*It’s a rate of attrition, versus why the male gamete is just produced on demand? (Of course we don’t know this, but do you have an insight into why that’s the case?)*

- Carole is sure there is a better answer, but here is what she thinks

Making eggs is expensive calorically, in terms of time and calories

- What we are designed to do is convert energy into offspring
  - That’s basically what evolution put us here to do
  - And you want to do that as efficiently as possible
- So eggs are energetically expensive, sperm is less energetically expensive
- Carole doesn’t know what happens in terms of how the eggs that go atretic
- Females start out with about 10 million eggs [[7 million](https://www.merckmanuals.com/home/multimedia/table/how-many-eggs)]
- But most of them just die, so maybe there’s some selection process there
- There’s an overproduction, because for females, there’s so much that goes into the production of each egg and time and energy, and each egg that you produce is going to limit your ability [to produce future eggs]
- If it takes a long time, that means you can only have like 8 or 10 or however many kids over a lifetime, so they’re very valuable
- We’re talking about testes and sperm, testes being not so well protected, but the eggs are extraordinarily well protected if they’re made early and then just stored
- Eggs resume meiosis when they are [ovulated](https://en.wikipedia.org/wiki/Ovulation)

***So maybe there’s this store and then there’s a selection process that goes on throughout life***

**Peter’s takeaway**

- That’s a very interesting idea
- Let’s say you make a million eggs
- You have the first 18 years of life (or whatever it is or 16 years of life) to select the best of those
  - It’s not a stochastic process that takes you from the million to the 10,000 or whatever the number is
  - It’s truly a [winnowing down](https://pubmed.ncbi.nlm.nih.gov/29743337/) of the best of the best of the best

Peter clarifies, “*This is a teleologic BS discussion*.”

- It’s a super interesting question and Carole wishes she knew more about it

**This illustrates the reason why we have different strategies**

- It’s because the time and energy that females have to put into reproduction
- Imagine we’re living as hunter-gatherers, there’s no birth control
  - We’re not going through life getting our periods over and over and going to Whole Foods and having a job
  - We’re having kid after kid after kid
  - We’re nursing, we’re producing the milk with our own bodies
  - We have to grow the baby in a relatively energy-restricted environment

***The energetic and time burden for female mammals is enormous to produce each offspring***

- And if you don’t have the right egg or the right sperm, then you’ve lost a huge chunk of your potential reproductive output
- You should care about where you’re getting the sperm

***Men don’t lose a big chunk [of their reproductive output], and this is the sex difference in parental investment that shapes our bodies and our behaviors***

- That’s why eggs and sperm matter in terms of our bodies and our behaviors, because we have to do very different things and live in different ways to maximize our reproduction

**More about the mini-puberty and the impact of the increase in testosterone in males on behavior**

- That increase in testosterone starts within a month after birth but then peaks around 3 months
  - And it goes on until about 6 months

***That mini-puberty appears to have important effects on brain development and on lengthening the penis***

Peter asks, “*Does the female do it as well? In other words, does the female experience a rise in estrogen?*”

- Yes

> “*The mini-puberty in boys appears to also be associated with activity levels in the boys and even growth trajectories.*”‒ Carole Hooven

**⇒** The mini-puberty in boys is a very narrow window of time: 3-6 months

- In terms of the activity levels, it could be that this postnatal time, that the play in boys has something to do with differences in activity levels, differences in novelty seeking, different temperament, less fear also

## How evolutionary biology shapes sex differences in play, aggression, and conflict resolution (and how modern environments and cultural messaging can disrupt those patterns) [A: 49:00, 55:04]

**Differences in play and competition in boys versus girls**

- But if you think about it from an evolutionary point of view, in male mammals that have to **compete for status** and operate in a **dominance hierarchy**
  - A lot of male mammals have dominance hierarchies which tend to function to reduce aggression overall, because instead of duking it out every time there’s a fertile female or a delicious piece of fruit in a tree, you just signal, “*I’m not going to take your fruit. I’m subordinate to you,*” so you can get along as a group
  - Yes, there’s infighting just like humans have, but humans have dominance hierarchies also, and if you don’t learn how to compete physically with other males as a kid, this has been [shown](https://pubmed.ncbi.nlm.nih.gov/36755666/) in non-human animals and there’s some evidence for this in humans, that you have more trouble

It just occurred to Carole that this is happening with social media

- People are using their iPhones to compete instead of getting out in the yard and play fighting or fighting with other boys
- That’s actually healthy because it ends up reducing aggression

***It helps especially young boys and young men learn their place in the hierarchy, what they’re capable of physically, how to be threatening and when to be threatening, when to signal that they’re submitting***

- All of that happens and it’s fun, so they’re driven to do it because it’s adaptive for them evolutionarily

***Females tend to have more nurturing play***

- Carole had 3 older brothers
  - She was climbing trees, she was wrestling with them
- But the girls almost never  have a play date where they’re tackling each other
- Carole’s son is 16 now
  - He’s still doing it and he’s 6’ and his friends, one of them is 6’ 2”, and it makes her very, very nervous because they can really hurt each other now
  - But yeah, they’re still doing it
- Peter thinks this is a beautiful thing to watch

> “*It’s such a beautiful thing to watch if you just stop judging it for a moment and just ask yourself the why question, what is driving this behavior?*”‒ Peter Attia

- For whatever reasons that are tragic, this has become a political discussion, but it’s really not
- It’s simply a discussion of biology and it’s endlessly fascinating
- Peter adds, “*Why is it that when I walk into the pantry and I see a candy bar versus a cheese stick or something, I want to eat the candy bar?*”
  - Well, that’s evolution
  - He can make a choice not to do it
  - But it would be silly for him not to appreciate how much his brain looks at the candy bar and sees the sweetness, the energy density, the fat, the sugar, and it’s like, “*Yeah, that’s what I want*.” Versus pick the bland, healthier option

**Differences in behavior of boys and girls are apparent when you watch them play**

- This idea that if you let boys duke it out that it ultimately settles them down
- It’s probably too soon to tell what the results are of the natural experiment where kids play less
- There is no shortage of discussions about what happens
  - All the anxiety and things that come from endless social media

**The deeper, and more interesting questions: What does it teach us about aggression or lack thereof?**

*Peter is curious if people have been studying that as closely as they’ve been studying the effects of social media on anxiety and some of these other things*

- Carole is not sure what the current literature is on how social media is affecting play other than it’s not happening as much
  - Which she thinks is obviously bad
- [With physical play,] you’re out there, you’re being physical, you’re learning about your body
  - You’re developing relationships with other boys in particular that are trusting, but can involve physical aggression

The mismatch between our evolutionary drives and modern environment

Carol asks, “*You mentioned something about wanting to have, what did you say, the chocolate bar?*”

- Peter’s knee-jerk reaction is to always eat something that’s sweeter, more calorie dense
- Carole points out the mismatch
- We’re designed to be motivated to seek out these foods and we have to expend energy to get high calorie foods
  - Maybe we would’ve gotten honey, and that would’ve been super rewarding and we only would’ve had a little bit, and then we would’ve ran around and spent those calories
  - Now we have a chocolate bar ‒ that’s a mismatch situation that is maladaptive
- What’s interesting is that we’ve figured out what to do to some degree with the male
- Any women watching this who are super competitive and aggressive, that’s a thing too
  - It’s not that women are not this way
  - They certainly are and Carole sees more and more examples on her iPhone from basketball games and stuff recently
  - But women tend to be less physically competitive than men (on average)

We have **sports** that ritualize this [competitive] motivation or this desire, especially on the part of men

- And we have a lot more men who are interested in watching sports because they’re getting that need vicariously
  - They’re like jumping out of their chairs
  - Often, their [testosterone is responding](https://pubmed.ncbi.nlm.nih.gov/27720891/) also to even the vicarious participation in sports (which is interesting)

**Given that we evolved for the males to get this aggression out physically, what do we say about boys that play a ton of video games and get their aggression out there?**

- Peter points out that you could argue if they’re playing with their other friends, there are super aggressive video games where you’re killing each other and doing something in a virtual world that you would do if you were wrestling

*Is there a positive to that?*

- Aside from the fact that they’re not getting exercise of course, and not being physically active, do we know if that serves as even a reasonable proxy?

***As far as Carole knows, there isn’t any getting your aggression out/getting that need met (if it is a need)***

- [Carole shared this [study](https://faculty.washington.edu/jdb/345/345%20Articles/bushman(2002).pdf) by email which found, “*Venting to reduce anger is like using gasoline —it only feeds the flame. By fueling aggressive thoughts and feelings, venting also increases aggressive responding*.”]
- Some people don’t have that need
- Most men are not terribly physically aggressive ‒ there’s a competitive
- You could compare it to pornography and ask, are men getting out their sexual need?
  - There’s more evidence that maybe they are getting some need met there
- But in terms of aggression, Carole not sure it works the same way in a virtual world

**If a parent is listening to this, is there anything that they should be concerned about?**

- We know that siblings are a little bit different
- Peter’s 2 boys are different
- Clearly they’re both a step-function more aggressive and physical than their sister was at a comparable age
- The younger one is still a step ahead in aggression of the middle one
  - Meaning the younger boy is more aggressive than the older boy

Carol asks, “*Can you say what you mean when you say aggressive?*”

- There’s 3 years between them
- Obviously the older one is larger
- The younger one will instigate physically more
  - If he’s unhappy, he will attack the large, older boy
  - He’ll hit anything and anyone that stands in his way
- Whereas the middle one [the older boy] is not quite as bad
- Peter feels horrible saying all of this (his wife is going to kill him)
  - They’re not monsters, but they’re boys and this is what boys do
- With other kids, they’re more in control, but with each other, they’re at their worst
  - Which Peter thinks is normal for male siblings
- Peter’s point is: between them, there’s quite a difference in aggression, and maybe it’s **birth order**
  - Maybe when you’re the younger one, you have to stand your ground even more
- Carole used to hit her older brothers; she was a big hitter

Peter’s point, “*Should a parent just say, ‘Look, I’m going to let these kids do what they’re going to do,’ and understand that there are differences.*”

- Understand that some boys are going to be less aggressive
  - Some are going to play rough; some are not going to play that rough

*Is the best thing you can do as a parent from any available evidence, just let them do their thing?*

- This is an interesting question; Carole hadn’t thought about it in this way

***Generally with rough play, if they’re having fun, if they’re smiling and laughing ‒ let them go for it***

- They need to learn to work their stuff out, and the more play, the better

**⇒** Boys and girls are designed to play in different ways, and it helps us learn how to be social and have social relationships and respond physically

- All of that is so important, and if we’re not doing that, then we’re going to have more trouble as adults
- But where it’s not so much fun and people are getting hurt, then the parent… Carole doesn’t know, maybe you let them work that out too

**For example, are boys more likely to bully than girls?**

- Carole doesn’t think so
- There’s this difference where boys will insult you to your face and bully to your face
- Girls are very aggressive also, but what’s interesting is that they tend not to do it in a direct confrontational way where they’re exposing themselves as the perpetrator
  - So they can hide from physical harm, which is more adaptive
  - But they can denigrate the reputation of other girls, which they do because they’re their competition in terms of mating competition for, say, high status males
  - So they can denigrate the appearance or behavior, especially sexual behavior, and it’s extremely cruel
  - [[reviewed here](https://pmc.ncbi.nlm.nih.gov/articles/PMC3826208/)]

**Do we see that kind of behavior amongst other mammals?**

- We certainly see more face-to-face aggression among male mammals
- What we do see in female hierarchies sometimes is that there is harassment
  - In some [monkeys](https://en.wikipedia.org/wiki/Reproductive_suppression), there is harassment of a subordinate female by the dominant [leads to suppression of the [HPA axis](https://en.wikipedia.org/wiki/Hypothalamic%E2%80%93pituitary%E2%80%93adrenal_axis) in order to prevent hyper-activation of the axis (Carole explained by email)]
  - That is not necessarily a physical confrontation; it’s just harassment

**The sex difference in human aggression with females doing more of this passive aggression**

- Carole thinks part of that is that females have not evolved the same skills to resolve conflicts so that the hierarchy can be reinstated [[studied in 2014](https://pubmed.ncbi.nlm.nih.gov/24845881/)]
- Males can have a pickup game on the basketball court
  - It can get rough, they can insult each other, but by the end, they’ve worked it out
  - Maybe there’s a change in the status hierarchy, but they’ve worked it out, it’s over
  - It doesn’t go on for weeks
  - You don’t have to talk about it endlessly

***Females do not have the same ability to resolve those kinds of what for us would be very complex social conflicts***

- Peter finds this such an obvious statement even though he doesn’t think about it that way
  - He noticed even in high school that boys would get into huge fights and it would be over by the end of the day
- There’s something that feels fair about that, [as opposed to] to backstab and not give somebody the opportunity to work it out
  - To gossip behind people’s backs

Carole adds, “*Yes, there’s murder and rape and men are overrepresented in those horrible crimes, but we shouldn’t glorify feminine ways of interacting necessarily and try to get men to be more feminine because there’s a lot of issues also with typical feminine behavior.*”

## Why males commit disproportionately more violent crime, and how cultural and environmental forces shape aggression [A: 1:01:00, V: 1:09:10]

- Let’s talk a little about the pathology that Carole just alluded to
  - That there aren’t too many female murders and rapists
  - The disproportionate representation of men in violent crime, you don’t need statistics to understand that

**⇒** 95% of murders everywhere are committed by males and something like 98% of sexual assaults

**What role does testosterone play in that?**

Carole cautions, “*Just like with play, people aren’t going to like this so I want to make sure I say it clearly*.”

***The difference, this broad pattern is similar to what we see in non-human animals where the males are much more likely to kill each other than the females***

- There’s many more violent or physically aggressive interactions

Carole adds, “*If you look at both of us, we have different bodies. You are bigger and stronger. I started lifting weights because of you a year ago, so I’m getting there, but I’ll never get to where you are*.”

**⇒** Physically, men are developed for competition, essentially male-male competition for mates

- This plays out in this destructive way in society, and ***Carole believes that the ultimate reason for the difference is testosterone***
- However, men are committing fewer murders in Canada than they are in the US
- That’s not because of differences in testosterone level

***That difference is because socialization and culture, religion, the laws, all have a huge impact on what the values are in any particular society, what is tolerated, what is encouraged***

- Some societies basically allow men to beat and rape their wives, so you have higher rates of those male behaviors
- Where it’s not tolerated and the culture is totally different, you have lower rates of those behaviors

***But everywhere, you will have the sex difference with all of these behaviors higher in men***

- Carole is glad Peter asked this because she thinks **the main reason people don’t like biological explanations for sex differences** is because they misinterpret a tendency or a predisposition for a behavior or a biological explanation as suggesting that it’s impossible to change behavior. It’s not.
- Or that there’s no variation across the sexes in behavior
  - There is, just because there might be a biological explanation or even a genetic explanation

**The important thing to remember is that we develop within an environment**

- It’s gene-environment interactions, we develop within a society
- And how we develop and even how our hormones respond to different kinds of interactions is impacted by the social system and by the ecology and everything else

***It’s complicated, but Carole thinks that the ultimate reason is because of the genetic difference, which is the Y chromosome and the hormonal differences that it leads to***

## Why females evolved different behavioral strategies: nurturing, risk aversion, and the cultural norms that override biology [A: 1:04:00, V: 1:13:12]

**Female behavior**

- Nurturing: if you’re going to be growing and producing and holding and feeding and caring for a baby and you are the one who absolutely has to do it, and that’s the female
- Of course we get help from men
- And sometimes men even take over as the primary caregivers, which is extremely unusual in mammals
- So men are capable of all of that nurturing if the society values it
  - Because some societies don’t value that, and then they’re still capable but they’re not apt to do that
- For females, it just doesn’t pay reproductively in general to be super aggressive
- We need our bodies to be healthy and we have to live a long life
  - The longer our lives, the longer our reproductive output

**Differing impact of risk taking in males and females**

- Men can die young and have great reproductive success
  - Because they can see many more partners if they take risks

***Physical risks don’t have the same payoff for females***

**Differences in aggression in males and females**

- There are some primates, for instance, where the females are relatively aggressive, but it’s almost never to the same extent as males

**The impact of societal norms**

Peter points out, “*It’s so interesting when you think about how as humans, we hold ourselves to a higher standard than we would hold animals.*”

A very concrete example

- If we go back in time, 500 years
- First of all, neither of us would be alive ‒ forget that part of the discussion
- 500 years ago, if you had a male that was 25 years old, he would readily reproduce with a 14-year-old female
  - That would be completely normal and evolutionarily wise
- But we’ve made a decision, at least in our society that that’s unacceptable
- And most people think that that’s a good decision

***That’s an example of we have made a societal norm that says it’s unacceptable for a 14-year-old girl to be reproducing, certainly at the hands of an older man***

- If she gets pregnant from a 14-year-old boyfriend, that’s a different discussion and we can help them both out

The point of this story is we’ve made a decision that this is no longer acceptable

- Just as we’ve made a decision that a husband can’t rape his wife, we have just decided that maybe that was cool 200 years ago, it’s not cool today

## Whether male aggression is still necessary in modern society, why the underlying biological drives persist, and how modern society redirects these drives [A: 1:06:30, V: 1:15:59]

**To play the other side of some of these arguments**

- Is there someone watching us who’s saying, “*Peter, Carole, you guys are talking about all this aggression stuff, but we’re humans living in the 21st century. We have to change. We have to evolve as a species.*”

*Is there a case to be made that men should be less aggressive because all of these evolutionary reasons that you described aren’t as necessary?*

- Women and men are going to live through their reproductive lives
- We don’t have this urgency
- We don’t need this competition
- Peter is not saying he agrees with that or anything, but he’s just saying there’s a steel man for the other side of this
  - Just as in those extreme examples of we don’t have sex with 14-year-olds and we don’t rape our wives

Carole asks, “*What would it take for you to not eat that chocolate?*”

- Peter thinks food is a really tough one ‒ it can be done, it just takes a ton of willpower
- Food is a great way to think about it

Carole argues, “*There’s food and sex and aggression is for ultimately, in a way, for sex.*”

- For men more than women, aggression is more about sex
- Peter points out that he doesn’t need to be an alpha male to get as much food as he needs today
- Carole notices that he is an alpha male and asks, “*Were you competitive?*”
- We don’t need an alpha male to get food
- Peter is exploring if we should get rid of the drive
- Carole points out there’s physical competition, which we do not need

**There is a sex difference in certain drives**

***Men tend to be more driven to achieve specific and more narrow goals and hyper focused on certain goals and to achieve, to be the top of the heap in one thing***

Chess [is an example]

- Carole wrote an [article](https://quillette.com/2024/03/22/why-do-men-dominate-chess/) on sex differences in chess and learned a lot because she wondered why men are consistently better at chess than women? (and they are)
- She suspected it wasn’t explained by differences in cognition
- She thinks the driving force is that boys and men are much more willing to spend countless hours studying the moves and practicing and seeing their coach and trying to beat their competition
- And for women, there are other things to do that matter in their lives more
- Certainly there are some women who do that focus, but there are way more men
- Carole is saying this because that competitive drive, chess, she doesn’t know what we’re getting out of that
- She has played chess
  - Not super seriously, but her son was really into it for a while
  - She knows a lot of people who are obsessed with it

**Carole wonders what we’re getting socially from this competitive drive**

- She’s not saying that women are not competitive or haven’t made incredible social advances in all kinds of domains

> “*If we want to interfere with the male desire to compete, we are also interfering with whatever products we get or advances we get from that intense drive.*” —Carole Hooven

- Carole was in academia for 25 years
- There is a lot that is produced because people want to be first
  - They want to nail finding this gene or be the first to make a certain discovery
  - It’s tremendously productive, often that insane drive that men have
- Carole thinks women have less of it because we have kids
  - We are designed to have the kids
  - We don’t have the same, “*I must do something else, have to produce this other thing,*” with the same drive
  - Again, there’s tons of variation here
  - There’s tons of crossover

***This is just a pattern ‒ she thinks men have more of that [competitive drive] potentially because they’re not designed to have kids to produce them with their own bodies***

**Peter’s takeaway**

- For most of 250,000 years, male aggression was absolutely essential for males to reproduce and find and forage for food and protect
- The past 100 years or so has largely done away with that meaning a couple of things have become true
- We basically have domesticated crops and agriculture and livestock, and we’re no longer in a food scarce environment
- Certainly for the last 50 or 60 years, lifespans have extended enough that there isn’t a race to reproduce
  - You can actually live through your reproductive years
  - It’s not like you have to get this done before you die at the hands of a saber-toothed
- Third, infant mortality and maternal mortality rates have plummeted
- The success of your offspring skyrockets and basically all of the other reasons that we used to need to be hyperaggressive with each other to compete for mates, again, food and all these other things, have largely dwindled
- But that’s a fire that’s been burning for millennia
- We have to channel into something else

***And in many cases, in the most polished corridors of society, we’ve channeled that into professional excellence or things that would’ve been totally unnecessary and superfluous hundreds of years ago (sports are huge)***

- Nobody thought of discovering genes or trying the be the leading scorer in your favorite sport
- It’s been an easier or maybe more logical transition of aggression from evolutionary needs into gratuitous needs
  - Making more money, being more successful, being more famous, being more respected in some way

***And the maternal need of caring for the offspring hasn’t evolved as much in the sense away from its original goal***

- Which was making sure the offspring were perfectly protected
- There’s an asymmetry in this evolution of evolution

Carole agrees with the general thrust of this summary

- What is interesting is thinking about how we still need to nurture
- Her baby was not always with her when she was working
- But that nurturing drive is still super strong and valuable, and that is probably best for the kid
- And now parental attention can be given much more to kids

## How testosterone levels naturally shift to support fatherhood and caregiving [A: 1:13:30, V: 1:24:45]

- It’s interesting because even in hunter-gatherers, there’s very different traditions across hunter-gatherer societies in terms of expectations for paternal involvement

**⇒** When there’s high involvement in parenting, there’s lower testosterone in those males/fathers (that applies to humans)

> “*For fathers to be very attentive, the testosterone generally is suppressed, and that’s true in birds where the males are contributing*.”‒ Carole Hooven

- If you raise the father’s testosterone, they neglect their kids
  - [[seminal study](https://academic.oup.com/auk/article-abstract/104/3/462/5192737) in male house sparrows]
- There is a hormonal support there for parenting
  - That’s something that men can do to increase their reproductive success
  - This is not novel

Peter asks, “*If you’re a man out there listening now… If your T is low, you should ignore your kids to raise your T. Is that the implication?*”

- It doesn’t drop by that much and what matters is that you’re in an environment where you see your little kids
- If you’re a guy and you’re mated and you have a partner and you’re around your baby and you’re interacting with your baby, your T’s going to drop a little bit
  - And that’s a good thing

**⇒** There are so many different ways that male testosterone responds to and influences social dynamics, and this is one of them that’s really important

***You’re a better dad potentially, if your testosterone does drop ‒ you’re potentially a better husband and more attentive to your wife and your kids***

**Do we know that there’s causality here? This is a pretty bold statement.**

- We do [[*PNAS*: Longitudinal evidence that fatherhood decreases testosterone in human males](https://pubmed.ncbi.nlm.nih.gov/21911391/)]

*By what magnitude are we talking about here*

- Carole should have had the data, and she doesn’t have the answer
- But it’s shown across lots of different populations in humans and non-human animals that fatherhood
- First of all, mating, being in a pair bond
  - This is like what birds do when they finally…
  - They’re very aggressive when they’re setting up their territory, their testosterone is high in the males
  - When they find the female and establish a territory with her, the testosterone tends to drop because it’s not adaptive to have high testosterone all the time

***It’s why animals have mating seasons, because it’s expensive metabolically to have high testosterone all the time***

Peter asks, “*Because it would make us go out and look for other mates when we don’t need to?*”

- Yes
- You’re aggressing and fighting for status and singing or flexing your muscles or ignoring your kids or being an asshole to your wife
- You’re also not reinforcing adaptive behaviors with a bit of a testosterone spike
- Like if you’re around an attractive woman and you’re trying to seduce her, there’s very possibly going to be a [testosterone increase](https://pubmed.ncbi.nlm.nih.gov/17585911/), which stimulates a [dopamine surge](https://pubmed.ncbi.nlm.nih.gov/15488545/) and reinforces a behavior if you’re successful
- Carole explains that when you shut all that off, it’s like when women go on birth control and they don’t respond to men necessarily in the same way that they would have because they have just screwed up that entire hormonal system
  - That’s a whole other thing

**⇒** There’s a system in women and in men where those sex hormones are giving you signals about what’s happening in the environment and what your role is in your potential

- Carole doesn’t want to get away from the fatherhood because this is very well established

***This drop in testosterone, it happens not just in humans, but in other males where paternal investment increases survival of the offspring (which it does in humans)***

**Hypothetical scenario (and the effect on male testosterone)**

- Man and wife have a baby
- Man decides after a few years to stay home more and spend more time with his child, and forego whatever else he was doing
  - He was working 80 hours a week; now he’s going to work 30 hours a week
  - Carole thinks he’ll keep working 80
- But in this experiment, the guy decides to stay home half the time

*Will his testosterone drop?*

- No
- Because the kid is too old (5 at this point)

Carole points out

- He’ll start looking for other females
- There’s **serial monogamy** where the man is more likely to stay around during the early years, and that’s when maybe a critical period
  - Carole is not sure for this effect
  - It’s really when the offspring is dependent and young and the mother needs to be supplemented
  - Again in a hunter-gatherer situation, the woman is not just going to have one kid, she’s going to have several and she’s going to be nursing or weaning and/or about to get pregnant, and she’s in a situation where she can really benefit from investment from a male, and he benefits reproductively

Peter asks, “*He benefits reproductively because that’s a critical window in which his protection is producing his survival advantage?*”

- And protection

## How testosterone shapes male mating strategies, and why long-term pair-bonding persists even when reproduction is no longer at stake [A: 1:18:30, V: 1:30:38]

**There are different strategies that different men can use to maximize their fertility**

1 – Pair-up forever with 1 woman

- Mate guard her, be good to her, invest in her
- He had to compete and have certain status to get that woman
- You want a high-quality female, you want to keep her
- You can do very well reproductively for your lifetime output, and you’re not out on the mating market constantly being vigilant, constantly trying to take down other males, constantly fighting for status

2 – You can have sex with a lot of women

- Which is what you’re designed to want sex with more partners than females are designed want sex with [[study](https://pubmed.ncbi.nlm.nih.gov/12872886/)]
- But who knows how many of them are going to get pregnant and who knows how many of those babies are going to survive
- That is one strategy where if you’re a high status man, you can be very successful
- You can have way more than 8 kids
- But that’s a high risk strategy
  - A lot of men are going to fail and they won’t have the sure thing of the one female where they can invest in her

***That seems to be not a lower testosterone man strategy***

**Correlations between testosterone level and behavior**

**⇒** We know that when the kid is young, if the guy is physically involved with a small dependent offspring, that there will be suppression in testosterone (and that is a good thing)

That suppression in testosterone

- It doesn’t mean that your muscles will be smaller necessarily
- Carole is not sure how big the drop is

***But that lower testosterone level does facilitate potentially more contentment with that life***

If you have higher testosterone, what has been shown in non-human models is

- The attention to the mate and the offspring is reduced
- There’s more attention to status seeking, aggression, getting sex from other partners, etc.

> “*I think it’s worth trying to understand what the exogenous testosterone (which shuts down that system) does in men… there are potentially some very important behavioral and social effects that people don’t think about*.”‒ Carole Hooven

- People don’t think about the behavioral and social effects because they’re so psyched to get jacked and have more social status and have the dopamine (it feels good)

**These evolutionary discussions are so interesting**

- Peter imagines that most guys who have chosen the path of having as many partners as possible, are not doing that because of reproductive fitness
- Often they are choosing not to have kids

*How do we reconcile that?*

- From an evolutionary perspective, the desire to have as many partners as possible increases your probability of success
  - Even with serial monogamy where you’re in a relationship and then you move on and get a younger partner

Peter asks, “*Is that rooted in the evolution of reproduction or is that rooted in the evolution of status in a way that is distinct from reproduction?*”

- Carole doesn’t think status is distinct from reproduction

***Psychologically the driver is not reproduction, it’s sex***

- Peter points out this is interesting, “*This is the first time we’re basically talking about sex independent of reproduction.*”
- Carole thinks ultimately we have love and relationships for reproduction

Carole explains, “*That whole love thing is just to get your genes into the next generation via the kid and the love of the wife is to ensure that it maximizes chances of that happening*.”

**Is there any other species that does what we do as humans, which is… You and your husband have a 16-year-old?**

- In 2 years, Carole’s son will be off to college
- They will have done their job as parents
- Peter’s point is about the love they will have for each other
  - The support they will have for each other is really not in the service of making sure your genes survive anymore

*Are there other examples of animals that continue in that behavior, which is when they’re past the reproductive age, when their offspring are gone, they stay together?*

- There aren’t really too many other animals that get past their reproductive age
- Elephants and all these other long-lived mammals?

Menopause, you mean who has menopause?

- Some whales
- Rare captive chimps or maybe there’s some wild chimps who have had menopause

***It’s just very rare***

Peter asks, “*But this is another human socialization?*”

- Grandmothers make a massive contribution to their daughters and their daughter’s kids in terms of knowledge and support
- Someone who’s no longer capable of reproducing, that’s valuable
- You don’t want to be reproducing in your 80s because it’s a total waste of energy, and you’re likely to die potentially from trying [more about the [evolution of menopause](https://pubmed.ncbi.nlm.nih.gov/30779895/)]
- You can invest in your genes that are in your daughter and her kids
  - That makes a big difference
- Carole thinks Peter is saying why do we stay together in a bond?
  - Yes
  - Is there an evolutionary reason for why humans specifically stay monogamous even after it’s not necessary for the survival of their offspring?

***Humans stay together in a bond because it increases the survival of our offspring***

- That trust and commitment, even if you don’t have kids, you behave as though you do because you would have, there’s no way you wouldn’t have kids
- Any couple that’s having sex would’ve been having kids
  - There was no birth control
- And they’re still acting that way
- The same genes are being transcribed as though they had kids
- Carole’s son is 16 and he might’ve had a kid already
- Her bond with her husband, their experience, their relationship with their kid is going to help increase the survival of their grandkids

***Our genes are really going to potentially do much better if we stay together***

- But we are liberated from that ‒ people get divorced and find other partners

## The distinct roles of estrogen in male development, mood, libido, and muscle [A: 1:25:00, V: 1:38:42]

- Going back to testosterone and estrogen

**Estrogen is a very important hormone for men and women**

- It’s appreciated more in women than men
- There’s a [study](https://pubmed.ncbi.nlm.nih.gov/24024838/) from 2013 that Peter has talked about many times in the past (published in the [*New England Journal of Medicine*](https://www.nejm.org/doi/full/10.1056/NEJMoa1206168))
  - [discussed in [episode #274](https://peterattiamd.com/derekmpmd/#:~:text=Q%20is%20better-,The%20use%20of%20aromatase%20inhibitors%20to%20suppress%20estrogen%2C%20and%20the%20misconceptions%20around%20estrogen%20in%20men%20%5B2%3A16%3A00,-%5D) after 2:16:00]
  - A large group of men were chemically castrated, and then they were made replete with  different doses of testosterone (from low to high) with and without [anastrozole](https://en.wikipedia.org/wiki/Anastrozole#Pharmacology)
  - There were 5 groups of men given testosterone with and [5 groups] without anastrozole
  - Anastrozole would inhibit the conversion of testosterone to estradiol (it inhibits aromatase)
  - [400 men randomly assigned them to receive a placebo gel or 1.25 g, 2.5 g, 5 g, or 10 g of testosterone gel daily for 16 weeks with or without anastrozole for a total of 10 groups]

*The question was how did these 10 groups differ with respect to body composition, mood affect, sexual desire?*

- Peter doesn’t remember if bone density was studied
  - It might not have been a long enough study
  - [this data was collected but not included in this report; see this [later report](https://pubmed.ncbi.nlm.nih.gov/26901812/)]
  - [Results are shown below]

***The TLDR: the best outcome was the highest T with high estrogen***

![](https://peterattiamd.com/wp-content/uploads/2025/11/f1-carolehooven.png)

**Figure 1. Effects of restoring testosterone in chemically castrated men given alone (cohort 1) or with anastrozole (cohort 2, to prevent conversion of testosterone to estradiol)**. Image credit: [*NEJM* 2013](https://www.nejm.org/doi/full/10.1056/NEJMoa1206168)

![](https://peterattiamd.com/wp-content/uploads/2025/11/f2-carolehooven.png)

**Figure 2. Effects of restoring testosterone in chemically castrated men given alone (cohort 1) or with anastrozole (cohort 2, to prevent conversion of testosterone to estradiol)**. Image credit: [*NEJM* 2013](https://www.nejm.org/doi/full/10.1056/NEJMoa1206168)

- This was the best outcome for everything, body composition, mood, etc.
- This wasn’t surprising to Peter than higher testosterone was better than lower testosterone for all the metrics that were measured
- We understand this much more now

***At the time, the surprising insight was that more estrogen was better than less for men***

- Not just with respect to how the men felt, but even body composition

> “*This was a wake-up call because I think there were a lot of doctors out there who were prescribing aromatase inhibitors to keep estrogen as low as possible in men… who were taking testosterone.*”‒ Peter Attia

- We’re talking about men taking testosterone within physiologic norms
  - Putting aside bodybuilders who were taking 1000 mg of testosterone where you do have to block some of the aromatization
  - If you have a guy who’s taking 100 or 150 mg of testosterone a week, which would put him to a physiologic upper limit of normal, really, it seems that you ought to let estrogen go as high as necessary or as high as it goes, naturally shy of producing a symptom

**Let’s just spend a minute now talking about the role of estrogen and its role in the brain**

*What do we know about this and do we know about, for example, why at a minimum in some of these studies, and even anecdotally, if a male’s estrogen level is too low, it has a negative impact on his mood?*

- Carole doesn’t know this paper, but let’s say one of the outcomes was libido
- In male **rodents** during early development, testosterone is converted by aromatase [to estrogen] in the brain
  - If you block [aromatase](https://en.wikipedia.org/wiki/Aromatase), you essentially get a female rodent brain [explained in this [paper](https://pubmed.ncbi.nlm.nih.gov/611076/)]

Peter asks, “*Does that mean that you need aromatase to get testosterone in the brain, or does it mean that you need the testosterone to become estrogen to go into the brain?*”

- Yes, the testosterone gets into the brain
- Estrogen is prevented
  - The peripheral estrogen [Carole misspoke here saying testosterone] is prevented [from entering the brain] by a protein called [alpha-fetoprotein](https://en.wikipedia.org/wiki/Alpha-fetoprotein) in rodents
  - This protein also binds maternal estrogen so that females are not masculinized
- The testicular produced testosterone gets into the brain, it gets past the alpha-fetoprotein [because it is not bound in the blood]
  - Then in the brain, testosterone gets aromatized [to estrogen]

***In rodents, it’s estrogen acting via estrogen receptors that are masculinizing sexual and aggressive behavior***

- It’s clear in rodents because you have lordosis in females and mounting in males, and you have higher rates of male aggression, etc.

**This does NOT happen in humans**

- There is a misunderstanding about that
  - A lot of people think this applies also to humans
  - [[explained further](https://pubmed.ncbi.nlm.nih.gov/28818501/)]
- It can’t apply to humans because our alpha-fetoprotein does not effectively bind estrogen
- We also have men who can’t produce aromatase and don’t have estrogen, and they are fully typically masculine in their behavior
  - They have other issues like with bone
- We also have complete [androgen insensitivity syndrome](https://en.wikipedia.org/wiki/Androgen_insensitivity_syndrome) where you have XY individuals who have testicles but have a defective androgen receptor
  - They have testicles and XY sex chromosomes and high testosterone
  - But they develop as females because their testosterone is converted into estrogen
  - They have no testosterone whatsoever, yet they do have estrogen
  - They’re exposed to maternal estrogens
  - They’re very feminine [[psychological outcomes explained](https://pubmed.ncbi.nlm.nih.gov/12710824/)]
  - Peter finds this very interesting: they must have sky-high estrogen given that all of their testosterone is being converted to estradiol
  - They go through essentially female puberty, and many of them will discover that they have testes and XY sex chromosomes when they don’t get their period

***The point is, we know for sure that what happens in rodents does not happen in humans***

**More about individuals with androgen insensitivity syndrome**

*Do they develop with a male pattern of aggression or a female pattern of nurturing?*

- Totally feminine
- This is interesting because this is a [point mutation](https://medlineplus.gov/genetics/gene/ar/#conditions) in the androgen receptor gene, one small mutation
- Everything else is just typical male

***You just get the one mutation in the androgen receptor that is disabling it and the individual develops as a female***

- [with [complete androgen insensitivity syndrome (CAIS)](https://en.wikipedia.org/wiki/Androgen_insensitivity_syndrome)] you take what would have been a typical male, and you have someone with testes and XY sex chromosomes
- You have all the genes on the Y
- But you have a totally typical, for all intents and purposes, girl (and then a woman)
- [[explored more in this study](https://pubmed.ncbi.nlm.nih.gov/12710824/)]
- [by email Carole explains: feminine psychological development in women with CAIS who are XY but are unable to respond to androgens suggest that hormones can override chromosomal sex in determining human psychological sexual differentation]

*Outside of the sterility, does she go on to be a completely normal woman?*

- More feminine than other women who have testosterone
- It’s not a pathologic condition outside of sterility

**More about what hormone is masculizing in humans**

**⇒** There’s incontrovertible evidence that estrogen is not the masculinizing hormone acting via the estrogen receptor in early development in humans

- But then you’re raising all these questions about the role of estrogen in adulthood
- Carole thinks the study Peter mentioned is interesting and important, but she couldn’t say with authority exactly how

***Estrogen is important for bone, it’s important for the body, but in terms of behavior, Carole believes it’s important for sexual behavior***

- But we do have these guys who don’t make estrogen who seem to be normal

**Back to androgen insensitivity syndrome**

*Do they have aromatase capacity?*

- Yes
- These people seem to be sexually normal
  - There’s no difference in sex drive and orgasmic capacity, even though they have zero testosterone (that’s interesting)
- There’s limited data because it’s a rare condition [[2-5 cases in 100,000](https://medlineplus.gov/genetics/condition/androgen-insensitivity-syndrome/#frequency) newborn females]

***The data we do have suggests that they have estrogen and that the estrogen somehow compensates***

*Do they have the same libido?*

- From the [studies](https://pubmed.ncbi.nlm.nih.gov/34895859/) Carole has seen, yes
- She doesn’t know if maybe the peak isn’t as high in puberty or something like that

*Presumably they must have a little more difficulty putting on muscle mass. Do they shave their legs?*

- They don’t have to
- They have no acne
- They don’t have to shave
- Carole worked with a student very closely who had this condition
  - It’s a difficult condition when you’re a normal teenager and you learn [that you have this]

**Back to the** [**study**](https://pubmed.ncbi.nlm.nih.gov/24024838/) **of men Peter mentioned**

- To Peter, the most interesting outcome of the study was not that the men with higher testosterone felt better; it was that they actually put on **more muscle mass** **with the higher estrogen level**
- That is Carole’s understanding even though she doesn’t know exactly why that is and how it works

***Carole thinks estrogen is very important in adult men, and it may be important in early development in some ways that we don’t yet understand***

## How evolution, health, lifestyle, and androgen receptor biology shape modern testosterone replacement therapy (TRT) [A: 1:34:15, V: 1:49:50]

**Do you think all of this teaches us about the role of testosterone replacement therapy in both men and women?**

*Back to something Carole said earlier: if we didn’t muck around with nature, men would experience a pretty steady decline in testosterone from puberty on down*

- This is [observed](https://pubmed.ncbi.nlm.nih.gov/12456632/) in Western populations; hunter-gatherers tend not to have that
- Hunter-gatherers start out with lower testosterone because high testosterone is expensive to maintain
- Most animals keep it low and only raise it when females are fertile and they need to compete
  - That’s the [rut](https://en.wikipedia.org/wiki/Rut_(mammalian_reproduction))
  - Like the red deer grow their testicles, grow weapons on their head, and become horny
  - They become aggressive when the females are fertile
  - If the females aren’t fertile, all that stuff goes away (testosterone drops)
- Humans are also designed to keep testosterone low, which is why if there’s a competitive situation, testosterone might go up, but generally it’s going to be kept low when it can be
- But we are overnourished in Western populations
  - We have enough calories to run our immune system and to do everything else we need to do
  - We have the luxury of being able to elevate testosterone over what it would be naturally
- In the case of deer, Peter points out that all of the females go through [estrous](https://en.wikipedia.org/wiki/Estrous_cycle#) at the same time
  - The bucks don’t need testosterone for 9 months when the does are infertile
  - Once the does are going through estrous, the bucks go through the rut and it’s a party

With humans

- There’s some literature that says the more women are together, the more their cycle syncs (but that’s weak)
- Women are ovulating every month
- This is why guys are the hormonal ones ‒ guys have high testosterone all the time
  - We just don’t notice that you’re hormonal because it starts in utero and you’re permanently hormonal

***Guys are hormonal because there’s always going to be fertile females around***

- But given guys have to maintain high testosterone levels throughout their entire life, women only maintain our high estrogen through a fixed time (our reproductive career, which is when we’re most attractive)

**If you look at hunter-gatherers**

- They have a high pathogen load
- They have fewer calories coming in
- They have high energy expenditure
- They have other energetically stressful situations to deal with that we don’t necessarily
- So they keep their testosterone levels lower
  - The peak is significantly lower (at least a third lower)
- And then there’s no real drop off [in T levels] and they stay active and healthy, relatively healthy throughout the rest of their lives
  - They don’t have that 1% loss [of T] per year
  - And there’s no problem with fertility even though their levels are much, much lower than ours

This makes Carole skeptical about some of the explanations for the trend that we see of a drop in testosterone levels in men and a drop in fertility

- If you look at these natural fertility populations, you see that we are starting out really high
- Carole doesn’t see why there would be a reduction in fertility per se that isn’t caused by other health issues, for instance

***It’s hard for us to blame fertility in the Western world on just declining testosterone***

- Carole thinks the testosterone must be declining because of all these other things that are affecting fertility
  - It could be the inflammation that arises from the metabolic dysfunction
  - [Phthalates](https://en.wikipedia.org/wiki/Phthalates)

**Going back to Western society**

- We see roughly 1% per year drop in testosterone

**⇒** A guy in his 30s today has a lower testosterone than a guy in his 50s did 40 years ago

- So a guy in his 50s today has pretty low testosterone
- And we certainly know that medically, it’s a completely safe thing to replace
- We know that there are great outcomes with respect to bone health, with respect to frailty and many subjective findings
- And we know that it’s NOT increasing the risk of prostate cancer and heart disease and all the things we used to worry about outside of the edge case of hypertension (which can be managed)

**All of that said, is there a case to be made that we should NOT be replacing testosterone in men because it turns us backwards in terms of this aggression, and it’s more likely to make that 55-year-old guy want to find himself the 20-year-old girlfriend?**

- Carole doesn’t know if that’s been shown
- Peter is asking, “G*iven everything we’ve just learned about testosterone, is there a negative consequence to taking a 55-year-old guy and restoring his testosterone to what it was when he was 18.*”

The argument for what that should happen

- It depends on the man’s symptoms
- If a guy is having difficulty putting on muscle mass, if he’s complaining about low libido (one that does not match his wife’s)
- There isn’t a formula here, but that’s one example of how you’re trying to match the symptoms and what the patient is saying to what you can do

**⇒** There are some guys who have no difficulty putting on muscle mass despite having a testosterone in the 20th percentile

- It might be that their genetics are such that that was the case, or they put on a lot of muscle mass when they were younger, and it’s just easier to maintain it
- There’s certainly evidence that [insulin resistance](https://en.wikipedia.org/wiki/Insulin_resistance) can be ameliorated by correcting hypogonadism (a reason to consider doing it)

**What Peter is trying to get at is: are there negative consequences of** [**TRT**](https://en.wikipedia.org/wiki/Androgen_replacement_therapy) **from a behavioral standpoint**

- He’s not talking about roid rage and things like that
  - Which has largely been debunked outside of these edge cases where people are taking super physiologic doses
- In terms of being a productive non-assholic member of society and not being overly aggressive or engaging in harmful behavior, risky behavior

*What’s the pro and con case for that in your mind?*

- These doses are within the physiological range, even at the low end ‒ you don’t see changes in sexual or aggressive behavior
  - You do see differences in physical parameters

**If Peter could wave a magic want in medicine, what would he want?**

- 1 – A [PSA](https://en.wikipedia.org/wiki/Prostate-specific_antigen#Screening) equivalent for breast cancer
- 2 – An assay to measure androgen receptor density (not nearly as important as #1)
  - Patients want their doctors to just measure it, but we don’t have a test for it
- You could test for the CAG repeat
  - [[read more](https://pmc.ncbi.nlm.nih.gov/articles/PMC4491081/#:~:text=The%20gene%20coding%20the%20androgen,response%20to%20gonadotropins%20%5B30%5D.) about this; people with a lower # of CAG repeats have higher expression levels of the androgen receptor thereby increasing their sensitivity to testosterone]
  - [[read more](https://pubmed.ncbi.nlm.nih.gov/21722642/) about phenotypes associated with variation in CAG repeat in the androgen receptor]
  - [there is not a commercial test available]
- Someone should develop a CLIA-approved assay for this

***The point Peter really wants to make is: Why is it that one guy can have a testosterone of 400 and feel totally fine and another guy can have a testosterone of 400 and feel totally depleted?***

- If you took both of those guys up to 1000
  - The first guy wouldn’t feel any better
  - The second guy would be like, “*You changed my life.*”

Carole asks, “*If you have a guy who feels bad on 400, do you eliminate all other things (that could be causing him that) that are going on in his body?*”

- No, you can’t, but you can just change one variable at a time
- Carole wonders: if you change that one variable, is that overriding the potentially negative effects of inflammation or depressing situation in his social life or whatever it is?
- Peter explains that typically, T won’t fix a lot of those things
- The most obvious things you try to fix are sleep, nutrition, exercise, obesity
  - Regardless of what his testosterone level is
  - If it’s 400 (which is very low), especially if his free testosterone is equivalently low and he’s got these vague symptoms
  - If he’s not sleeping well, eating well and exercising well, let’s fix those first
- But you can’t always fix those things to the nth degree without wanting to at least experiment
  - Especially when it comes to body composition stuff or energy level
- So by making the one variable change at a time, you can say, look, “*Let’s do the experiment. If your T is now 900 and we haven’t made a change during that period of time, other than that T, and you’re telling me, ‘I don’t really feel that much different,’ my hypothesis is you have a pretty low density of androgen receptors and they’re largely saturated at 400, and therefore, this isn’t really the fix. There’s something else we need to be looking at*.”

**Carole is glad Peter brought up the androgen receptors**

- People don’t appreciate the fact that one person’s 400 is not another person’s 400
- Carole knows that Peter talks a lot about carrier proteins
- But also there’s the **genetic differences in the receptor itself**
  - Which is the CAG repeat, which predicts the efficiency of its ability to transcribe the androgen responsive proteins and the overall concentration
- Where are your androgen receptors and how highly concentrated are there?
  - Of course, it’s going to be different in different parts of your brain and body.

***All of that really makes much more complex, the interpretation of a single measurement***

- That being said, Carole doesn’t know
  - She’s coming from a place of thinking about how this all works naturally to promote behaviors that are adaptive

## Carole’s experience with hormone replacement therapy (HRT), and the risks associated with TRT in younger men [A: 1:45:15, V: 2:02:44]

Carole shares, “*I’m on progesterone, testosterone, and estrogen. I’m 59, and I had my ovaries out a couple years ago, and I have to say, I just want to say when that happened, I was 57, so I was already in menopause pretty much, and everything changed after that. It made a huge difference. My hair started falling out, my sex drive plummeted.*”

- She was not on hormone replacement therapy prior to that
- She’s supposed to be an expert in hormones, and when she had her ovaries out at 57, it had a huge impact
  - Even though she was already in menopause
  - She found out that she wasn’t in menopause because she had some fresh [corpus luteum](https://en.wikipedia.org/wiki/Corpus_luteum) in her ovaries

***Even when your ovaries are pumping out low levels of hormones they’re still pretty impactful***

**Why did you decide to only go on hormone replacement therapy (HRT) at the age of 57 when presumably you believed you were in menopause prior and didn’t go on HRT?**

- That’s a good question
- She felt fine and it was gradual
- Because of Peter she started lifting weights a year ago
  - She was a runner and Peloton and biker, and the weights have made a huge difference
  - She’s addicted to lifting now
  - But she has a back injury that she’ll get Peter to help her with later

She feels better on these hormones

- Carole thinks the testosterone must be helping in terms of her really getting into the workouts and how much she can lift potentially
- She definitely feels better when she’s working out (and the drive to do that)
- She has no issue with people doing what they need to feel better

> “*People don’t consider that especially testosterone, and I think also estrogen, these are hormones that give us signals about what’s going on in our own bodies.*”‒ Carole Hooven

**Hormones give us signals about what’s going on in our bodies**

- Are we making eggs?
- Are we making sperm?
- Are we healthy?
- Are we sick?

**Downsides of hormone replacement**

- If you’re sick, those systems are suppressed and your hormone levels are going to be lower, which is adaptive and will help you ‒ and that won’t happen if you’re taking it all exogenously
- There’s a lot of social signaling, so all of that goes away
- Carole thinks hormone replacement is for the individual to decide
- She thinks there should be some regulation around testosterone
  - Because it is addictive
  - It can permanently cause someone to become infertile
- And this is something that she doesn’t know if young people really understand
- It’s different when people are after the age of 40 or 50
  - This is a different situation from someone who’s young and healthy and getting addicted at younger ages

***Carole thinks we should be much more careful***

Peter adds

- Testosterone is a regulated scheduled drug hormone, whereas estrogen is not
  - Estrogen can be prescribed without any DEA scheduling
  - Testosterone is a [schedule III](https://www.dea.gov/drug-information/drug-scheduling#:~:text=ketamine%2C%20anabolic%20steroids%2C-,testosterone,-Schedule%20IV)
- That’s an interesting point, which is one reason to consider scheduling it is the **potential for abuse** is much more significant in younger men who might not realize

**⇒** Sadly, a number of younger men don’t realize if they take testosterone for 3 years in their 20s, it could significantly and potentially permanently affect their fertility

- Carole understands that it’s hard to come off
  - It’s hard to tolerate the transition and withdrawal
  - Where you can’t get an erection, your libido tanks
- Peter doesn’t have any experience with that because it’s simply not his patient population
- He would guess that everything Carole is describing would be more the result of abuse
  - He doesn’t like using a judgy term like that
  - He reserves that term for nonmedical use that is hyper physiologic

**Carole asks, “*****If there is a 25-year-old who’s just supplementing to get to the high end of normal range, is he still going to shut down his…*****”**

- He’s going to shut his [HPA](https://en.wikipedia.org/wiki/Hypothalamic%E2%80%93pituitary%E2%80%93adrenal_axis) down

**⇒** Here’s the thing, Peter has a really hard time believing that a 25-year-old should ever be on exogenous testosterone

- Carole reports that it’s really increasing at these younger ages
  - It is on social media

Peter shares, “*When I was 28, 29, 30, so when I was in my residency, my testosterone level was 220 ng/dL*.”

- He was 2x the level of a woman instead of 10x, 5x, or whatever
- Did that mean he should have been on TRT when he was 30?
- No
- It meant that he needed to get the hell out of residency and actually start sleeping at night
- Then 4 or 5 years later, he had normal testosterone

Peter’s approach, “*If a 25-year-old is walking around with a testosterone of 300 to 400, I would be much more inquisitive about fixing a whole bunch of things and much slower to move towards replacement.*”

- And even if he was going to replace it, he would not be using testosterone
  - He’d use [hCG](https://en.wikipedia.org/wiki/Human_chorionic_gonadotropin) to preserve gonadal function as opposed to completely suppressing it

Whereas if a guy is 60

- If he’s fine with testicular shrinkage
  - Which would be the fundamental difference in using exogenous T when you suppress his [HPA axis](https://en.wikipedia.org/wiki/Hypothalamic%E2%80%93pituitary%E2%80%93adrenal_axis)
- Then Peter thinks it’s less of an issue
- He doesn’t want to speak from any authority on treating young people; he simply doesn’t have that experience
  - He doesn’t have even a sense of how widely used it is
- It’s a good additional hurdle to have testosterone be DEA regulated, scheduled

## How Carole rebuilt after controversy: leaving academia and recommitting to scientific honesty [A: 1:51:30, V: 2:10:32]

**What are you up to right now?**

- Carole is trying to finish a book proposal
- She is spending a little more time with her son
  - It’s nice that she’s home when he gets home from school
- She has a part-time job at a DC think tank [[AEI](https://www.aei.org/profile/carole-hooven/)], which she is really enjoying
- She does some writing
- She has other things that she does

**Peter doesn’t want to go too far down the rabbit hole of what people are going to learn if they Google you, about the horrific experiences you had**

*How long ago was all of that?*

- That started in 2021
- [Carole explains why she left Harvard in this [op-ed](https://www.aei.org/op-eds/why-i-left-harvard/)]

*How has this experience been for you? You’re four years on the other side of, I think what any reasonable person would look at and say is just a complete and total injustice.*

- Thank you
- Peter notices that a lot of incredibly cowardly people that he’s sure at one point Carole felt were friends and colleagues completely sat by silently as a minority mob went after her

*How were you recovering from that experience?*

- It’s been really difficult because she was just reading her acknowledgments in her [book](https://www.amazon.com/Story-Testosterone-Hormone-Dominates-Divides/dp/1250236061/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.6lbcIlxbZc5Eqvj28-6Rxw.kt1G5aATixCnoKm4rN9C6EHxqB9i_x47n55W0JFZ_do&qid=1755519834&sr=8-1) on testosterone and she wrote, “*I have a great job. I have the privilege of interacting with these amazing young people*.”
- And teaching and advising undergraduates is hard
- She teaches about some really controversial and detailed and intricate topics
  - And she loves that
  - She loves putting in the effort and feeling the reward every day
  - She loves the relationships and changing people’s lives and having them change hers
  - It’s work that is challenging and so deeply rewarding, and it helps to provide a sense of meaning in life and a sense of accomplishment and all these things
- So not having that is hard, and it’s hard coping with the reason she doesn’t have that
- And all the people and the institution she trusted and gave so much to

***She feels that she was treated pretty horrifically ‒ it’s hard***

- She thought she’d be in that job forever

Carole shares, “*What it has done for me is made me much more committed to doing something like what you do*.”

- This is why she’s a huge fan of Peter’s
- It’s very rare that people get so into the scientific weeds
- She doesn’t detect any bias on Peter’s part
  - She detects that he is involved in a very open and honest struggle to understand the evidence and to talk about the evidence and where it points
  - And that’s what she always tried to do

> “*It’s so important to take ideology and bias out of our understanding of reality.*”‒ Carole Hooven

- Reality is there, whether we like it or not, it’s always to our benefit to understand it and to try to figure out then to use democratic processes to figure out what to do with reality or how to improve human health or whatever the issue is

***That experience has just made Carole much more committed to doing that and to advocate for that, which isn’t always easy***

- And some of the things she said today are controversial
- But she’d love to hear if people disagree, why
- That’s how we learn is by having our views and interpretation of evidence challenged

**Given how many ways you were successful as a professor, how much your undergraduate students loved you, it’s certainly one vehicle through which you can communicate this passion ‒ do you see yourself going back to that situation?**

*Do you see yourself winding up at a different university one day?*

*Or do you feel like the scars are sufficient that you don’t feel like being in that arena again?*

Carole explains what happened

- She wrote a book ([*T: The Story of Testosterone, the Hormone that Dominates and Divides Us*](https://www.amazon.com/Story-Testosterone-Hormone-Dominates-Divides/dp/1250236061/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.6lbcIlxbZc5Eqvj28-6Rxw.kt1G5aATixCnoKm4rN9C6EHxqB9i_x47n55W0JFZ_do&qid=1755519834&sr=8-1))
- And she went on *Fox News* and said that there are 2 sexes (male and female), and someone who was representing themselves as speaking on behalf of Harvard and her department accused her of transphobia
- Then there was other bad things that happened, and it resulted in Carole feeling she had no choice but to leave her job that she’d been in for over 20 years and loved

*Would you see yourself back?*

- No
- Because she was traumatized; she was in shock
- She could not believe how people were behaving
- She learned a lot, and one of the things she learned is that she was way too trusting

Carole shares, “*Whatever I do, I want to throw myself into it. And I threw myself into that job. And that’s why it hurt so much because that was me. That was like all of me.*”

- She kept some of herself for other parts of her life, but she really threw herself into it

***It feels way too risky; she won’t trust an institution like that again***

- She’s not a fan of academia right now

Peter thinks a lot of people can relate to that

- Anybody who’s put every bit of themselves
- For example, the first person you fall in love with
- If they break your heart, you’re going to sit there and say, “*That wasn’t worth it. I’m not doing that again. The bliss of that experience wasn’t worth the pain I’m experiencing today.*”
- Peter is not going to suggest that Carole has to do it again because look at all the students she was able to help
  - Because there’s other ways to do it
- Carole is writing another book

***The truth of the matter is being on a podcast probably reaches more people than she would reach in 10 years of teaching***

## Carole’s next book: examining masculinity, cultural narratives, and the cost of denying biological sex differences [A: 1:57:30, V: 2:17:40]

**What is your next book about?**

- She’s really excited about it

***It’s about what’s happening with masculinity, and she’s really interested in the cultural narrative***

Carole explains, “*Here’s why I also cry. And that’s how I knew I needed to write a book because why am I crying about masculinity and men being denigrated, which I get very upset about that*.”

She wants to really understand

- 1 – What was happening culturally, **why we are in a place where masculinity is not valued**
- 2 – To explore the interaction between biology and genes and hormones and what’s happening culturally
- 3 – Why is it that these cultural changes that we’ve had are affecting men in the ways that are different from how they’re affecting women
  - Like economic changes ‒ men are falling behind in education, for instance
  - What’s happening in schools and why are schools maybe less hospitable to typical male ways of behaving than typical females?
- 4 – To dive into that intersection and to explore some of the questions that Peter was asking today about aggression and about men’s need to compete
  - How it’s different from women
  - How that plays out socially
- 5 – To explore those issues with an eye to understanding what’s called the “masculinity crisis”
  - There’s a kind of backlash going on right now, which is interesting in that men and their needs and their right to be masculine has been under attack
  - And now Carole thinks some men are feeling freer to be more masculine today

- 6 – To explore the denial of sex differences and how that plays out socially
- Because if you believe that men and women are equally interested in engineering, then you don’t believe in sex differences
  - You don’t believe there are important meaningful differences between the sexes that play out in society that are not all the result of the patriarchy, say
  - Certainly there are social influences and that all matters
  - But there’s this denial of real differences that we need to grapple with socially
  - If you believe that all the differences are the result of society, then potentially you’re more justified in trying to create equal outcomes
  - But if you deny biological differences, then you have more of a reason to do that

***If you appreciate that biological sex differences are real and that we have to grapple with them socially, then it’s going to be more complicated***

Peter completely agrees

- He jokes about this with his wife all the time
  - The reaction she has to a naturally aspirated V8 engine screaming at 10,000 RPM versus his reaction
  - He goes towards and she goes away (basically)
  - It’s the greatest sound he’s ever heard, and she’s like, “*What is that awful noise?*”
  - There’s no socialization that creates that difference
- We can only talk about averages here, and on average men are way more hardwired to love that sound
  - There are YouTube videos where you can literally listen to every engine
  - It’s like [ASMR](https://en.wikipedia.org/wiki/ASMR)

> “*The V8 and V10 naturally aspirated engine screaming is the greatest sound ever.*”‒ Peter Attia

- Carol doesn’t know what naturally aspirated means
  - You don’t have forced induction of air so it revs very high

Peter adds, “*If I had my wife listen to that, first of all, she wouldn’t hear the difference between any of them… She would think they all sound awful. They’re too loud.*”

- Carol reminds listeners that we are definitely not saying that there are no women interested in cars or that they can’t be enthusiastic
- Peter knows plenty of them, but we’re talking about differences on average
  - Especially those not with the cars

**Carole explains, “*****Differences on average that persist throughout history, around the globe, and that are shared with non-human animals, and for which we have a mechanism which makes sense, and that is differences in sex hormones.*****”**

**How do you think as you write this book, you will be able to do this seemingly impossible task, which is to write about this in a manner that is scientifically objective without getting dragged into an ideological, political mud pit?**

- Carole pulled that off in the writing of her last [book](https://www.amazon.com/Story-Testosterone-Hormone-Dominates-Divides/dp/1250236061/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.6lbcIlxbZc5Eqvj28-6Rxw.kt1G5aATixCnoKm4rN9C6EHxqB9i_x47n55W0JFZ_do&qid=1755519834&sr=8-1)
- Being in academia and talking about: male and female are real
  - That was essentially taken as undermining the rights of a certain group, and there’s nothing you can do about that

***Carole thinks the way to respond is to encourage people to engage with arguments instead of assassinating character***

- Encouraging that and teaching that is very important to her
- That’s what she did in her classroom, in her teaching (and it was great)
  - There was really never an issue in her own classes, even though we got into the most controversial subjects

> “*I’ll just keep trying to stick to the evidence and always remembering these are people’s lives and being compassionate and emphasizing that biology is not destiny*.”‒ Carole Hooven

- There’s a huge amount of variation, and it’s perfectly normal to be a little boy who wants to play with dolls
- It’s even hard for Carole to talk about because it’s heartbreaking that people feel stigmatized for not being sex typical

> “*If you understand the science, you understand variation and you understand what is normal, and there’s this spectrum, a huge spectrum of behavior across the sexes.*”‒ Carole Hooven

***There’s just only two sexes, and we should learn to deal with that kind of reality***

Peter appreciates this discussion

- He thinks what Carole has been through is heartbreaking, and he knows several others who have been similarly decimated by the angry mob
- The good news is virtually all reasonable people can agree on a set of facts
- But you can’t please everybody, and there’s going to be certain individuals who are going to have their points of view

---

## Selected Links / Related Material

**Carol’s book**: [T: The Story of Testosterone, the Hormone that Dominates and Divides Us](https://www.amazon.com/Story-Testosterone-Hormone-Dominates-Divides/dp/1250236061/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.6lbcIlxbZc5Eqvj28-6Rxw.kt1G5aATixCnoKm4rN9C6EHxqB9i_x47n55W0JFZ_do&qid=1755519834&sr=8-1) by Carole Hooven (2021) | [1:15, 19:15, 1:52:30]

**Essay on the idea of biological sex**: [Biology should not dispense with sexes](https://pubmed.ncbi.nlm.nih.gov/40199245/) | *Current Biology* (P Griffiths, H Spencer 2025) | [8:15]

**Review on male competitive strategies for mates**: [Ecology, Sexual Selection, and the Evolution of Mating Systems](https://pubmed.ncbi.nlm.nih.gov/327542/) ([pdf](https://www.zoology.ubc.ca/~goheen/mammalogy%20course/emlen_and_oring.pdf)) | *Science* (A Emlen, L Oring 1977) | [10:45]

**RCT examining effects of testosterone in the presence of a 5⍺-reductase inhibitor (to prevent production of DHT)**: [Effect of testosterone supplementation with and without a dual 5α-reductase inhibitor on fat-free mass in men with suppressed testosterone production: a randomized controlled trial](https://pubmed.ncbi.nlm.nih.gov/22396515/) | *JAMA* (S Bhasin et al. 2012) | [30:30]

**The role of mini-puberty in neurobehavioral development**: [The early postnatal period, mini-puberty, provides a window on the role of testosterone in human neurobehavioural development](https://pubmed.ncbi.nlm.nih.gov/26972372/) | *Current Opinion in Neurobiology* (M Hines et al 2016) | [36:00]

**Carole’s TED Talk**: [How Testosterone and Culture Shape Behavior](https://www.ted.com/talks/carole_k_hooven_how_testosterone_and_culture_shape_behavior) | TED (2024) | [37:45]

**Testosterone levels don’t predict behavior**: [42:00]

- [Testosterone dose-response relationships in healthy young men](https://pubmed.ncbi.nlm.nih.gov/11701431/) | *American Journal of Physiology, Endocrinology, and Metabolism* (S Bhasin et al. 2001)
- [Effects of testosterone on mood, aggression, and sexual behavior in young men: a double-blind, placebo-controlled, cross-over study](https://pubmed.ncbi.nlm.nih.gov/15181066/) | *The Journal of Endocrinology and Metabolism* ( et al. 2004)

**The impact of mini-puberty on activity levels and growth of boys**: | [48:30]

- [Postnatal penile growth concurrent with mini-puberty predicts later sex-typed play behavior: Evidence for neurobehavioral effects of the postnatal androgen surge in typically developing boys](https://pubmed.ncbi.nlm.nih.gov/25597916/) | *Hormones and Behavior* (V Pasterski et al. 2015)
- [Decoding Mini-Puberty and Its Clinical Significance: A Narrative Review](https://www.mdpi.com/2673-396X/6/2/28) | *Endocrines* (A Serbis et al. 2025)

**Testosterone response in men when participating in or watching sports**: [Effects of competition outcome on testosterone concentrations in humans: An updated meta-analysis](https://pubmed.ncbi.nlm.nih.gov/27720891/) | *Hormones and Behavior* (S Geniole et al. 2017) | [54:15]

**Research on venting aggressive thoughts and feelings**: [Does venting anger feed or extinguish the flame? Catharsis, rumination, distraction, anger and aggressive responding](https://psycnet.apa.org/record/2002-13494-002) ([pdf](https://faculty.washington.edu/jdb/345/345%20Articles/bushman(2002).pdf)) | *Personality and Social Psychology Bulletin* (B Bushman 2002) | [54:45]

**Competition in females**: [The development of human female competition: allies and adversaries](https://pmc.ncbi.nlm.nih.gov/articles/PMC3826208/) | *Philosophical Transactions of The Royal Society of London B* (J Benenson 2013)  [58:15]

**Carole’s article on chess**: [Why Do Men Dominate Chess?](https://quillette.com/2024/03/22/why-do-men-dominate-chess/) | Quillette (C Hooven, 2024) | [1:08:15]

**Fatherhood decreases testosterone**: [Longitudinal evidence that fatherhood decreases testosterone in human males](https://pubmed.ncbi.nlm.nih.gov/21911391/) | *PNAS* (L Gettler et al. 2011) | [1:15:00]

**Testosterone increase in men around attractive women**: [Rapid endocrine responses of young men to social interactions with young women](https://pubmed.ncbi.nlm.nih.gov/17585911/) | *Hormones and Behavior* (J Roney et al. 2007) | [1:16:00]

**Link between rising testosterone and dopamine**: [Reinforcing aspects of androgens](https://pubmed.ncbi.nlm.nih.gov/15488545/) | *Physiology & Behavior* (R Wood 2004) | [1:16:00]

**Different desire for number of sex partners in men and women**: [Universal sex differences in the desire for sexual variety: tests from 52 nations, 6 continents, and 13 islands](https://pubmed.ncbi.nlm.nih.gov/12872886/) | *The Journal of Personality and Social Psychology* (D Schmitt et al. 2003) | [1:19:30]

**Study of men chemically castrated where testosterone was given at different doses with or without anastrozole**: [Gonadal steroids and body composition, strength, and sexual function in men](https://pubmed.ncbi.nlm.nih.gov/24024838/) | *NEJM* (J Finkelstein et al. 2013) | [1:25:15]

**Decline in male testosterone with age**: [Population variation in age-related decline in male salivary testosterone](https://pubmed.ncbi.nlm.nih.gov/12456632/) | *Human Reproduction* (P Ellison et al. 2002) | [1:34:30]

---

## People Mentioned

N/A

---

![](https://peterattiamd.com/wp-content/uploads/2025/11/bio-carolehooven.png)

##### Carole Hooven, Ph.D.

Carole Hooven earned a B.A. in Psychology from Antioch College and a Ph.D. in Biological Anthropology (which later became the department of Human Evolutionary Biology) from Harvard University. Until recently, Dr. Hooven taught in and co-directed the undergraduate program in the department of Human Evolutionary Biology. She explains her decision to leave Harvard in an [article](https://pubmed.ncbi.nlm.nih.gov/36344790/) published in the *Archives of Sexual Behavior* and on her [website](http://www.carolehooven.com/about.html). She is now an Associate in the Department of Psychology at [Harvard University](https://psychology.fas.harvard.edu/people/carole-hooven) in Steven Pinker’s Lab and an active member of the newly established [Council on Academic Freedom at Harvard](https://sites.harvard.edu/cafh/). Dr. Hooven also works as a nonresident senior fellow at the [American Enterprise Institute](https://www.aei.org/profile/carole-hooven/) where she focuses on issues related to sex and gender, human evolutionary biology, health, psychology, and academic freedom in higher education.

Dr. Hooven is an evolutionary biologist whose research focuses on behavioral neuroendocrinology—the relationship among hormones, the brain, and behavior in humans and other animals. She is particularly interested in how evolutionary forces and hormones shape the intricate interplay between human biology and culture, helping explain large patterns of behavior, such as in crime, education, and mating strategies. She is also a public advocate for free speech and evidence-based social, educational, and legal policies concerning sex and gender. Dr. Hooven is the author of the influential and widely praised book [*T: The Story of Testosterone, the Hormone That Dominates and Divides Us*](https://www.amazon.com/Story-Testosterone-Hormone-Dominates-Divides/dp/1250236061/ref=tmm_hrd_swatch_0?_encoding=UTF8&dib_tag=se&dib=eyJ2IjoiMSJ9.6lbcIlxbZc5Eqvj28-6Rxw.kt1G5aATixCnoKm4rN9C6EHxqB9i_x47n55W0JFZ_do&qid=1755519834&sr=8-1). [[AEI](https://www.aei.org/profile/carole-hooven/)]

Instagram: [@carole.hooven](https://www.instagram.com/carole.hooven/?hl=en)

TED talk: [How Testosterone and Culture Shape Behavior](https://www.ted.com/talks/carole_k_hooven_how_testosterone_and_culture_shape_behavior)

Website: [Carole Hooven](http://www.carolehooven.com/)

X: [@hoovlet](https://x.com/hoovlet?lang=en)